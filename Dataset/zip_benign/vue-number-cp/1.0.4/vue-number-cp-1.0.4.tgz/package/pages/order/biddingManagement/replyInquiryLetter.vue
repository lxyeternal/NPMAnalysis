<template>
  <div class="replyInquiryLetter">
    <Header :is-white-bg="true"></Header>
    <SearchBar :search-type="5" :progress="'回复询标函'" :is-border-bottom="true"></SearchBar>
    <div class="list-home">
      <Breadcrumb :breadcrumbList="breadcrumb" @refresh="handleGoBack()"></Breadcrumb>
      <div class="list-content" v-show="stepNum==0">
        <PanelTitle :title="'基本信息'"></PanelTitle>
        <ul class="content-list">
          <li>
            <div class="title grey">询标函主题：</div>
            <div class="info" style="max-width: calc(100% - 90px);">{{theme}}</div>
          </li>
          <li>
            <div class="title grey">发送者：</div>
            <div class="info">{{purchaserCorpName}}</div>
          </li>
          <li>
            <div class="title grey">回复截止时间：</div>
            <div class="info red">{{deadline && deadline.split(' ')[0]}}</div>
          </li>
        </ul>
        <!-- 回复与编辑 -->
        <div class="problem-all">
          <PanelTitle :title="'问题汇总'"></PanelTitle>
          <div class="problem-box" v-for="(a,index_a) in requestList" :key="index_a">
            <div class="problem-title" :class="{'active':a.isShowPanel}">
              <div class="left ellipsisOne">
                问题{{index_a+1}}：{{a.requestTheme}}
              </div>
              <div class="right switch hand blue" @click="a.isShowPanel=!a.isShowPanel">{{a.isShowPanel?'收起':'展开'}} <i class="arrow" :class="{active:!a.isShowPanel}"></i></div>
            </div>
            <ul class="content-list" v-show="a.isShowPanel">
              <li>
                <div class="title grey tr" style="min-width: 62px">详细描述：</div>
                <div class="info" v-html="a.requestDescription.replace(/\n/g, '<br/>')">{{a.requestDescription}}</div>
              </li>
              <li>
                <div class="title grey tr" style="min-width: 62px">分类：</div>
                <div class="info">{{a.requestClassify=='TECHNICALBID'?'技术标':'商务标'}}</div>
              </li>
              <li>
                <div class="title grey tr" style="min-width: 62px">附件：</div>
                <div class="info" v-if="!a.requestAttachInfoList.length">
                  <p class="grey">暂无附件</p>
                </div>
                <div class="info" v-else>
                  <p v-for="(b,index) in a.requestAttachInfoList" :key="index+'info'">{{b.attachName}}<span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span></p>
                </div>
              </li>
              <li>
                <div class="title grey tr" style="min-width: 62px">回复：</div>
                <div class="info" style="width:1128px;max-width: 1128px">
                  <el-input class="claim" show-word-limit type="textarea" placeholder="请输入" v-model="a.responseContent" maxlength="200">
                  </el-input>
                </div>
              </li>

              <!-- *重新设置模拟清单 -->
              <!-- <li v-if="a.quotationUptFlg == 'QUOTE'">
                <div class="uploadFileList">
                  <p><i class="red">*</i>重新设置模拟清单 <span class="f12 hand blue" @click="openUpload('quotationList'+index_a)">设置模拟清单</span></p>
                  <input class="uploadFile" :ref="'quotationList'+index_a" type="file" @change="inqRequestNo=a.inqRequestNo;handleUpload($event,'26',a.quotationList)">
                  <div class="fileList">
                    <p v-if="!a.quotationList.length" class="nodata">未上传附件！</p>
                    <p v-for="(b,index) in a.quotationList" :key="index">{{b.attachName}}<span class="hand blue" @click="handleView(b.attachUrl)">预览</span><span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span><span class="hand blue" @click="inqRequestNo=a.inqRequestNo;delOther(a.quotationList,index)">删除</span></p>
                  </div>
                </div>
              </li> -->

              <!-- 甲供直采招标设备技术偏离表 -->
              <!--<li v-if="a.quotationUptFlg == '25'">-->
              <li v-if="a.quotationUptFlg.indexOf('25') !== -1">
                <div class="uploadFileList">
                  <p><i class="red">*</i>甲供直采招标设备技术偏离表 <span class="f12 hand blue" @click="handleDownloadList(a.quoteAttachInfoList && a.quoteAttachInfoList.filter(i=>{return i.attachType == '25'}) || [])">下载原技术偏离表</span><span class="f12 hand blue" @click="openUpload('technicalDeviation'+index_a)">上传</span></p>
                  <p class="f12 grey" style="margin-top: 5px">根据招标文件提供的技术标文件资料，完善相关内容，并上传加盖公司公章的《甲供直采招标设备技术偏离表》，扫描件以PDF格式上传。</p>
                  <input class="uploadFile" :ref="'technicalDeviation'+index_a" type="file" @change="inqRequestNo=a.inqRequestNo;handleUpload($event,'25',a.technicalDeviation)">
                  <div class="fileList">
                    <p v-if="!a.technicalDeviation.length" class="nodata">未上传附件！</p>
                    <p v-for="(b,index) in a.technicalDeviation" :key="index">{{b.attachName}}<span class="hand blue" @click="handleView(b.attachUrl)">预览</span><span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span><span class="hand blue" @click="inqRequestNo=a.inqRequestNo;delOther(a.technicalDeviation,index)">删除</span></p>
                  </div>
                </div>
              </li>

              <!-- 报价清单 -->
              <!--<li v-if="a.quotationUptFlg == '26'">-->
              <li v-if="a.quotationUptFlg.indexOf('26') !== -1" class="quotationList">
                <div class="uploadFileList">
                  <p><i class="red">*</i>报价清单 <span class="f12 hand blue" @click="handleDownloadList(a.quoteAttachInfoList && a.quoteAttachInfoList.filter(i=>{return i.attachType == '26'}) || [])">下载原报价清单</span><span class="f12 hand blue" @click="openUpload('quotationList'+index_a)">上传</span></p>
                  <input class="uploadFile" :ref="'quotationList'+index_a" type="file" @change="inqRequestNo=a.inqRequestNo;handleUpload($event,'26',a.quotationList,a)">
                  <div class="fileList">
                    <p v-if="!a.quotationList.length" class="nodata">未上传附件！</p>
                    <p v-for="(b,index) in a.quotationList" :key="index">{{b.attachName}}<span class="hand blue" @click="handleView(b.attachUrl)">预览</span><span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span><span class="hand blue" @click="inqRequestNo=a.inqRequestNo;delOther(a.quotationList,index);delOther(a.quotationPDFList,index)">删除</span></p>
                  </div>
                </div>
                <div class="mockList" v-if="(isSupplyPicture=='1' && inventoryFlag != '0') || a.quotationUptFlg.indexOf('38') !== -1">
                  <div v-if="isSupplyPicture=='1' && inventoryFlag != '0'" class="f14 hand" @click="stepNum=1;sent('0');isFromPage=true;perfectProImg()">+完善商品图</div>
                  <div v-if="a.quotationUptFlg.indexOf('38') !== -1" class="f14 hand" @click="stepNum=2;sent('0');isFromPage=true">设置模拟清单</div>
                </div>
              </li>
              <!-- 报价清单展示 -->
              <li v-if="a.quotationUptFlg.indexOf('26') === -1 && a.quotationUptFlg.indexOf('38') !== -1" class="quotationList">
                <div class="uploadFileList">
                  <p>报价清单</p>
                  <div class="fileList">
                    <p v-for="(b,index) in (a.quoteAttachInfoList.filter(i=>{return i.attachType == '26'}))" :key="index">{{b.attachName}}<span class="hand blue" @click="handleView(b.attachUrl)">预览</span><span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span></p>
                  </div>
                </div>
                <div class="mockList" v-if="mockProdCntList.length">
                  <div class="f14 hand" @click="stepNum=2;sent('0');isFromPage=true">设置模拟清单</div>
                </div>
              </li>

              <!-- 报价清单PDF版 -->
              <!--<li v-if="a.quotationUptFlg == '26'">-->
              <li v-if="a.quotationUptFlg.indexOf('26') !== -1">
                <div class="uploadFileList">
                  <p><i class="red">*</i>报价清单PDF版 <span class="f12 hand blue" @click="openUpload('quotationPDFList'+index_a)">上传</span></p>
                  <p class="f12 grey" style="margin-top: 5px">根据报价清单，将该清单线下打印并加盖公司公章，扫描PDF格式上传。</p>
                  <input class="uploadFile" :ref="'quotationPDFList'+index_a" type="file" @change="inqRequestNo=a.inqRequestNo;handleUpload($event,'44',a.quotationPDFList)">
                  <div class="fileList">
                    <p v-if="!a.quotationPDFList.length" class="nodata">未上传附件！</p>
                    <p v-for="(b,index) in a.quotationPDFList" :key="index">{{b.attachName}}<span class="hand blue" @click="handleView(b.attachUrl)">预览</span><span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span><span class="hand blue" @click="delOther(a.quotationPDFList,index)">删除</span></p>
                  </div>
                </div>
              </li>

              <!-- 投标文件(基础版) -->
              <!--<li v-if="a.quotationUptFlg == '28'">-->
              <li v-if="a.quotationUptFlg.indexOf('28') !== -1">
                <div class="uploadFileList">
                  <p><i class="red">*</i>投标文件(基础版) <span class="f12 hand blue" @click="handleDownloadList(a.quoteAttachInfoList && a.quoteAttachInfoList.filter(i=>{return i.attachType == '28'}) || [])">下载原投标文件</span><span class="f12 hand blue" @click="openUpload('biddingDocuments'+index_a)">上传</span></p>
                  <p class="f12 grey" style="margin-top: 5px">根据招标文件提供的商务标《招标文件（基础版）》文件资料，完善相关内容，并上传加盖公司公章的《招标文件（基础版）》，扫描件以PDF格式上传。<br>该文件含：承诺表、全国业务代表人证明书、材料设备供应商厂家基本情况表、指定经销商或代理商名录。</p>
                  <input class="uploadFile" :ref="'biddingDocuments'+index_a" type="file" @change="inqRequestNo=a.inqRequestNo;handleUpload($event,'28',a.biddingDocuments)">
                  <div class="fileList">
                    <p v-if="!a.biddingDocuments.length" class="nodata">未上传附件！</p>
                    <p v-for="(b,index) in a.biddingDocuments" :key="index">{{b.attachName}}<span class="hand blue" @click="handleView(b.attachUrl)">预览</span><span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span><span class="hand blue" @click="inqRequestNo=a.inqRequestNo;delOther(a.biddingDocuments,index)">删除</span></p>
                  </div>
                </div>
              </li>

              <!-- 投标文件(专业版) -->
              <!--<li v-if="a.quotationUptFlg == '29'">-->
              <li v-if="a.quotationUptFlg.indexOf('29') !== -1">
                <div class="uploadFileList">
                  <p><i class="red">*</i>投标文件(专业版) <span class="f12 hand blue" @click="handleDownloadList(a.quoteAttachInfoList && a.quoteAttachInfoList.filter(i=>{return i.attachType == '29'}) || [])">下载原投标文件</span><span class="f12 hand blue" @click="openUpload('biddingDocumentsSpecialty'+index_a)">上传</span></p>
                  <p class="f12 grey" style="margin-top: 5px">根据招标文件提供的商务标《招标文件（专业版）》文件资料，完善相关内容，并上传加盖公司公章的《招标文件（专业版）》，扫描件以PDF格式上传。</p>
                  <input class="uploadFile" :ref="'biddingDocumentsSpecialty'+index_a" type="file" @change="inqRequestNo=a.inqRequestNo;handleUpload($event,'29',a.biddingDocumentsSpecialty)">
                  <div class="fileList">
                    <p v-if="!a.biddingDocumentsSpecialty.length" class="nodata">未上传附件！</p>
                    <p v-for="(b,index) in a.biddingDocumentsSpecialty" :key="index">{{b.attachName}}<span class="hand blue" @click="handleView(b.attachUrl)">预览</span><span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span><span class="hand blue" @click="delOther(a.biddingDocumentsSpecialty,index)">删除</span></p>
                  </div>
                </div>
              </li>

              <!-- 针对绿地各地分公司联系人 -->
              <!--<li v-if="a.quotationUptFlg == '30'">-->
              <li v-if="a.quotationUptFlg.indexOf('30') !== -1">
                <div class="uploadFileList">
                  <p><i class="red">*</i>针对绿地各地分公司联系人 <span class="f12 hand blue" @click="handleDownloadList(a.quoteAttachInfoList && a.quoteAttachInfoList.filter(i=>{return i.attachType == '30'}) || [])">下载原联系人文件</span><span class="f12 hand blue" @click="openUpload('companyContacts'+index_a)">上传</span></p>
                  <p class="f12 grey" style="margin-top: 5px">根据招标文件提供的商务标《针对绿地各地分公司联系人》文件资料，完善相关内容，并上传加盖公司公章的《招针对绿地各地分公司联系人》，扫描件以PDF格式上传。</p>
                  <input class="uploadFile" :ref="'companyContacts'+index_a" type="file" @change="inqRequestNo=a.inqRequestNo;handleUpload($event,'30',a.companyContacts)">
                  <div class="fileList">
                    <p v-if="!a.companyContacts.length" class="nodata">未上传附件！</p>
                    <p v-for="(b,index) in a.companyContacts" :key="index">{{b.attachName}}<span class="hand blue" @click="handleView(b.attachUrl)">预览</span><span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span><span class="hand blue" @click="inqRequestNo=a.inqRequestNo;delOther(a.companyContacts,index)">删除</span></p>
                  </div>
                </div>
              </li>

              <!-- 送样清单 -->
              <!-- <li v-if="a.quotationUptFlg == '31'">
                <div class="uploadFileList">
                  <p><i class="red">*</i>送样清单 <span class="f12 hand blue" @click="handleDownloadList(a.quoteAttachInfoList || [])">下载原送样清单</span><span class="f12 hand blue" @click="openUpload('sampleList'+index_a)">上传</span></p>
                  <p class="f12 grey" style="margin-top: 5px">请下载原送样清单投标文件，修改文件后再上传，格式为xlsx文档。</p>
                  <input class="uploadFile" :ref="'sampleList'+index_a" type="file" @change="inqRequestNo=a.inqRequestNo;handleUpload($event,'31',a.sampleList)">
                  <div class="fileList">
                    <p v-if="!a.sampleList.length" class="nodata">未上传附件！</p>
                    <p v-for="(b,index) in a.sampleList" :key="index">{{b.attachName}}<span class="hand blue" @click="handleView(b.attachUrl)">预览</span><span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span><span class="hand blue" @click="delOther(a.sampleList,index)">删除</span></p>
                  </div>
                </div>
              </li> -->

              <li style="margin-bottom:20px">
                <div class="uploadFileList">
                  <p>该回复内容的补充说明附件 <span class="f12 hand blue" @click="openUpload('responseAttachInfoList'+index_a)">上传</span></p>
                  <input class="uploadFile" :ref="'responseAttachInfoList'+index_a" type="file" @change="inqRequestNo=a.inqRequestNo;handleUpload($event,'35',a.responseAttachInfoList)">
                  <div class="fileList">
                    <p v-if="!a.responseAttachInfoList.length" class="nodata">未上传附件！</p>
                    <p v-for="(b,index) in a.responseAttachInfoList" :key="index">{{b.attachName}}<span class="hand blue" @click="handleView(b.attachUrl)">预览</span><span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span><span class="hand blue" @click="inqRequestNo=a.inqRequestNo;delOther(a.responseAttachInfoList,index)">删除</span></p>
                  </div>
                </div>
              </li>
            </ul>
            <div class="line" v-if="requestList.length != index_a+1 && a.isShowPanel"></div>
          </div>
        </div>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!requestList.length">
          <img src="@/assets/images/icon-no-product.png">
          <p>暂无回复询标函！</p>
        </div>
      </div>
      <FixBottom class="bottom" v-show="stepNum==0">
        <div class="tc">
          <el-button type="primary" @click="sent(1)">发送</el-button>
          <el-button @click="sent('0')">保存</el-button>
          <el-button @click="handleGoBack()">取消</el-button>
        </div>
      </FixBottom>

      <!-- 完善商品图 -->
      <PerfectProImg style="margin-top: -10px;" ref="perfectProImg" v-if="stepNum==1" :submitBidNo="submitBidNo" :bidNo="bidNo" @UpdateStep="UpdateStep"></PerfectProImg>
      <!-- 模拟清单 -->
      <SetMockList style="margin-top: -10px;" v-if="stepNum==2" :mockList="mockProdCntList" :submitBidNo="submitBidNo" :bidNo="bidNo" @updateData="supplierGetReplyDetail" @UpdateStep="UpdateStep"></SetMockList>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import Header from "@/components/base/Header";
import Breadcrumb from "@/components/base/Breadcrumb";
import SearchBar from "@/components/SearchBar";
import PanelTitle from "@/components/base/PanelTitle";
import FixBottom from "@/components/base/FixBottom";
import { viewFile } from '@/utils/orderUtil';
import SetMockList from "@/components/order/biddingManagement/SupplierBidding/setMockList";
import PerfectProImg from "@/components/order/biddingManagement/SupplierBidding/perfectProImg";
export default {
  components: {
    SearchBar,
    Loading,
    Breadcrumb,
    Header,
    PanelTitle,
    FixBottom,
    SetMockList,
    PerfectProImg
  },
  data() {
    return {
      isLoading: false,
      breadcrumb: [],

      inventoryFlag: '',// 是否需要招标模板清单（1-是，0-否）
      requestList: [],
      delFileList: [],

      theme: '',
      deadline: '',
      purchaserCorpName: '',
      // isPage: '', //'1'回复,'2'编辑,
      supplierBidInquireNo: '',//	供应商询标函编号
      bidInquireNo: '',//询标函编号
      inqRequestNo: '',// 询标函问题编号

      isReset: false,// 重新上传报价清单后是否 重新设置模拟清单与完善商品图
      stepNum: 0,// 0编辑回复函 1完善商品图 2模拟清单
      bidNo: '',
      submitBidNo: '',
      isSupplyPicture: '',//是否完善商品图(0,1)
      isFromPage: false,//是否来自回复询标函
      mockEntryStatus: '',//模拟清单商品添加状态（0：未添加商品；1：添加部分商品；2：完成商品添加）
      mockProdCntList: [],//mockProdCntList为空时表示发标没有勾选模拟清单
      spuAttachFlg: '0',//添加商品图(0,1)
    };
  },
  methods: {
    // 更新步数
    UpdateStep(list) {
      // 模拟清单
      if (list[0] == 'setMockList') {
        if (list[1] == 'on' && this.isSupplyPicture == '1' && !this.isFromPage) {
          this.stepNum = 1
          this.$nextTick(() => {
            this.$refs.perfectProImg.prodListType = '2'
            this.$refs.perfectProImg.init('on')
          })
        } else {
          this.stepNum = 0
          this.supplierGetReplyDetail()
          this.isFromPage = false
        }
      } else {
        if (list[1] == 'under' && this.mockProdCntList.length && !this.isFromPage) {
          this.stepNum = 2
        } else {
          this.stepNum = 0
          this.supplierGetReplyDetail()
          this.isFromPage = false
        }
      }
    },
    perfectProImg() {
      this.$nextTick(() => {
        this.$refs.perfectProImg.init()
      })
    },
    handleGoBack() {
      // this.$router.go(-1);\
      this.$confirm(
        '是否离开此页面',
        '',
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          type: 'warning',
          confirmButtonText: "离开",
          cancelButtonText: '取消',
        }).then(() => {
          window.opener = null;
          window.close();
        }).catch(() => {
        });
    },
    // 供应商查看回复函详情
    supplierGetReplyDetail() {
      let param = {
        supplierBidInquireNo: this.supplierBidInquireNo
      }
      InterfaceService.supplierGetReplyDetail(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          // 模拟清单
          this.inventoryFlag = data.respData.inventoryFlag || '0'
          this.spuAttachFlg = data.respData.spuAttachFlg || '0'
          this.mockEntryStatus = data.respData.mockEntryStatus || ''
          this.mockProdCntList = data.respData.mockProdCntList || []

          // 询标函
          this.bidInquireNo = data.respData.bidInquireNo || ''
          this.theme = data.respData.theme || ''
          this.deadline = data.respData.deadline || ''
          this.purchaserCorpName = data.respData.purchaserCorpName || ''
          this.requestList = data.respData.requestList || []
          // 分离投标文件和附件
          this.requestList.forEach(i => {
            this.$set(i, 'isShowPanel', true)

            let technicalDeviation = [] //甲供直采招标设备技术偏离表
            let quotationList = [] //报价清单
            let biddingDocuments = [] //招标文件(基础版)
            let biddingDocumentsSpecialty = [] //招标文件(专业版)
            let companyContacts = [] //针对绿地各地分公司联系人
            // let sampleList = [] //送样清单
            let quotationPDFList = [] //报价清单PDF版

            let responseAttachInfoList = [] //附件

            if (i.responseAttachInfoList && i.responseAttachInfoList.length) {
              i.responseAttachInfoList.forEach(j => {
                if (j.attachType == '25') {
                  technicalDeviation.push(j)
                } else if (j.attachType == '26') {
                  quotationList.push(j)
                } else if (j.attachType == '28') {
                  biddingDocuments.push(j)
                } else if (j.attachType == '29') {
                  biddingDocumentsSpecialty.push(j)
                } else if (j.attachType == '30') {
                  companyContacts.push(j)
                } else if (j.attachType == '44') {
                  quotationPDFList.push(j)
                } else {
                  responseAttachInfoList.push(j)
                }
              });
            }
            i.responseAttachInfoList = responseAttachInfoList
            this.$set(i, 'technicalDeviation', technicalDeviation)
            this.$set(i, 'quotationList', quotationList)
            this.$set(i, 'biddingDocuments', biddingDocuments)
            this.$set(i, 'biddingDocumentsSpecialty', biddingDocumentsSpecialty)
            this.$set(i, 'companyContacts', companyContacts)
            // this.$set(i, 'sampleList', sampleList)
            this.$set(i, 'quotationPDFList', quotationPDFList)
          });
          console.log(this.requestList)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 发送
    sent(type) {
      let content = this.requestList.every(i => !i.responseContent)
      if (content && this.stepNum === 0) {
        return this.$message.error('至少填写一条回复')
      }
      if (type == '0') {
        this.supplierSaveReply('0')
        return
      }
      const i = this.requestList
      let result = true
      let quotationUptFlg = ''//报价清单和模拟清单
      for (let j = 0; j < i.length; j++) {
        if (i[j].quotationUptFlg.indexOf('38') !== -1) {
          quotationUptFlg = i[j].quotationUptFlg
        }
        if (i[j].quotationUptFlg.indexOf('26') !== -1) {
          quotationUptFlg = i[j].quotationUptFlg
        }
        // if (i[j].quotationUptFlg == '25' && (!i[j].technicalDeviation.length || !i[j].technicalDeviation[0].attachUrl)) {
        if (i[j].quotationUptFlg.indexOf('25') !== -1 && (!i[j].technicalDeviation.length || !i[j].technicalDeviation[0].attachUrl)) {
          this.$message.error('请上传甲供直采招标设备技术偏离表')
          result = false
          break
          // } else if (i[j].quotationUptFlg == '26' && (!i[j].quotationList.length || !i[j].quotationList[0].attachUrl)) {
        } else if (i[j].quotationUptFlg.indexOf('26') !== -1 && (!i[j].quotationList.length || !i[j].quotationList[0].attachUrl)) {
          this.$message.error('请上传报价清单')
          result = false
          break
          // } else if (i[j].quotationUptFlg == '26' && (!i[j].quotationPDFList.length || !i[j].quotationPDFList[0].attachUrl)) {
        } else if (i[j].quotationUptFlg.indexOf('26') !== -1 && (!i[j].quotationPDFList.length || !i[j].quotationPDFList[0].attachUrl)) {
          this.$message.error('请上传报价清单PDF版')
          result = false
          break
          // } else if (i[j].quotationUptFlg == '28' && (!i[j].biddingDocuments.length || !i[j].biddingDocuments[0].attachUrl)) {
        } else if (i[j].quotationUptFlg.indexOf('28') !== -1 && (!i[j].biddingDocuments.length || !i[j].biddingDocuments[0].attachUrl)) {
          this.$message.error('请上传投标文件(基础版)')
          result = false
          break
          // } else if (i[j].quotationUptFlg == '29' && (!i[j].biddingDocumentsSpecialty.length || !i[j].biddingDocumentsSpecialty[0].attachUrl)) {
        } else if (i[j].quotationUptFlg.indexOf('29') !== -1 && (!i[j].biddingDocumentsSpecialty.length || !i[j].biddingDocumentsSpecialty[0].attachUrl)) {
          this.$message.error('请上传投标文件(专业版)')
          result = false
          break
          // } else if (i[j].quotationUptFlg == '30' && (!i[j].companyContacts.length || !i[j].companyContacts[0].attachUrl)) {
        } else if (i[j].quotationUptFlg.indexOf('30') !== -1 && (!i[j].companyContacts.length || !i[j].companyContacts[0].attachUrl)) {
          this.$message.error('请上传针对绿地各地分公司联系人')
          result = false
          break
          // } else if (i[j].quotationUptFlg == '44' && (!i[j].quotationPDFList.length || !i[j].quotationPDFList[0].attachUrl)) {
        } else if (i[j].quotationUptFlg.indexOf('44') !== -1 && (!i[j].quotationPDFList.length || !i[j].quotationPDFList[0].attachUrl)) {
          this.$message.error('报价清单PDF版')
          result = false
          break
        }
      }
      if (!result) {
        return
      }
      //  完善商品图和模拟清单
      if (this.isReset) {
        if (this.isSupplyPicture == '1') {
          return this.$message(this.mockProdCntList.length ? '您已更换报价清单,请重新完善商品图和设置模拟清单' : '您已更换报价清单,请重新完善商品图')
        } else {
          if (this.mockProdCntList.length) {
            return this.$message('您已更换报价清单,请重新设置模拟清单')
          }
        }
      }
      if (quotationUptFlg && quotationUptFlg.indexOf('26') !== -1) {
        if (this.isSupplyPicture == '1' && this.spuAttachFlg == '0') {
          return this.$message.error('您存在未完善的商品图,请先完成完善商品图')
        } else if (this.mockProdCntList.length && this.mockEntryStatus == '0') {
          return this.$message.error('您存在未完成信息的模拟清单,请先完成模拟清单的商品信息填写')
        }
      }
      // 
      const b = this.requestList.filter(i => !i.responseContent && i.responseAttachInfoList.length)
      console.log(b)
      if (b.length) {
        return this.$message('您有已上传附件,但未回复的问题【' + b[0].requestTheme + '】,请输入回复')
      }
      const c = this.requestList.some(i => !i.responseContent && !i.responseAttachInfoList.length)
      if (c) {
        this.$confirm( // 有未回复的问题
          '你有未回复的问题，请先去回复，若直接点击【确认发送】按钮即视作放弃回答相应问题。',
          '发送询标函',
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            dangerouslyUseHTMLString: true,
            type: 'warning',
            confirmButtonText: "确认发送",
            cancelButtonText: '取消',
          }).then(() => {
            this.supplierSaveReply('1')
          }).catch(() => {
          });
      } else {
        this.$confirm(
          '请检查该询标函问题均已回复，若无误，点击【确认发送】按钮即可。',
          '发送回复询标函',
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            dangerouslyUseHTMLString: true,
            type: 'warning',
            confirmButtonText: "确认发送",
            cancelButtonText: '取消',
          }).then(() => {
            this.supplierSaveReply('1')
          }).catch(() => {
          });
      }

    },
    // 供应商保存回复函
    supplierSaveReply(handleType) {
      let list = []
      if (this.requestList.length) {
        console.log(this.requestList)
        this.requestList.forEach(i => {
          let fileList = [...i.responseAttachInfoList, ...i.technicalDeviation, ...i.quotationList, ...i.quotationPDFList, ...i.biddingDocuments, ...i.biddingDocumentsSpecialty, ...i.companyContacts]
          let responseAttachInfoList = []
          fileList.forEach(j => {
            if (!j.ossFileId) {
              responseAttachInfoList.push({
                attachType: j.attachType,
                attachName: j.attachName,
                attachPath: j.fileUrl,
              })
            }
          });
          // 删除文件
          if (this.delFileList.length) {
            let a = this.delFileList.filter(k => k.inqRequestNo == i.inqRequestNo)
            responseAttachInfoList = [...responseAttachInfoList, ...a]
          }
          console.log(responseAttachInfoList)
          list.push(
            {
              inqRequestNo: i.inqRequestNo,
              responseContent: i.responseContent || '',
              responseAttachInfoList: responseAttachInfoList
            }
          )
        });
      } else {
        return
      }
      let param = {
        bidInquireNo: this.bidInquireNo,
        handleType: handleType,
        responseList: list
      }
      console.log(param);
      InterfaceService.supplierSaveReply(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.isReset = false
          this.delFileList = []
          if (handleType == '0') {
            this.$message.success('保存成功')
            this.supplierGetReplyDetail()
            if (window.opener) {
              window.opener.location.reload();
            }
          } else {
            this.$message.success('发布成功')
            this.$setRootLocalStorage('publishStatus', 'PUBLISH')
            if (window.opener) {
              window.opener.location.reload();
            }
            window.opener = null;
            window.close();
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 触发上传
    openUpload(item) {
      this.$refs[item][0].click()
    },
    // 上传文件
    handleUpload(e, type, list, obj) {
      const file = e.target.files[0];
      console.log(file)
      if (file) {
        let a = file.name.split(".")
        const fileType = a[a.length - 1];
        if (type == '26' && this.inventoryFlag != '0') {
          const reg = /(xlsx|XLSX)/i;
          if (!reg.test(fileType)) {
            this.$message.error("请上传xlsx格式文件");
            return;
          }
        } else {
          if (type != '35' && type != '26') {
            const reg = /(pdf|PDF)/i;
            if (!reg.test(fileType)) {
              this.$message.error("请上传PDF格式文件");
              return;
            }
          }
          // if (file.size > 20971520) {
          //   this.$message.error("单个附件大小不超过20MB");
          //   return;
          // }
        }
        this.uploadContractToOss(type, file).then(res => {
          // 获取文件全路径
          let param = {
            ossFile: [{
              fileType: type, filePath: res.url
            }],
            appName: "PROD"
          };
          InterfaceService.ossSignatureUrl(param, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              let ossFile = data.respData.ossFile || [];
              if (type != '35' && list.length) {
                list.forEach(i => {
                  if (i.ossFileId) {
                    this.delFileList.push({
                      ossFileId: i.ossFileId,
                      inqRequestNo: this.inqRequestNo,
                    })
                  }
                });
                list.splice(0, 1)
              }
              if (type == '26' && this.inventoryFlag !== '0') {
                this.isReset = true
                if (this.isSupplyPicture == '1') {
                  this.$message(this.mockProdCntList.length ? '您已更换报价清单,请重新完善商品图和设置模拟清单' : '您已更换报价清单,请重新完善商品图')
                } else {
                  if (this.mockProdCntList.length) {
                    this.$message('您已更换报价清单,请重新设置模拟清单')
                  }
                }
              }
              // 替换报价清单,报价清单PDF版重置
              if (type == '26' && obj.quotationPDFList.length) {
                obj.quotationPDFList.forEach(i => {
                  if (i.ossFileId) {
                    this.delFileList.push({
                      ossFileId: i.ossFileId,
                      inqRequestNo: this.inqRequestNo,
                    })
                  }
                });
                obj.quotationPDFList.splice(0, 1)
              }
              ossFile.forEach(i => {
                list.push({
                  attachName: file.name,
                  attachUrl: i.url,
                  fileUrl: i.filePath,
                  attachType: i.fileType,
                })
              });
              console.log(this.requestList)
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        })
      }
      e.target.value = "";
    },
    uploadContractToOss(type, file) {
      return new Promise((resolve, reject) => {
        InterfaceService.getOssSignatureDisposable(file.name, {
          type: type,
          appName: "PROD",
        }, (data) => {
          let signature = data;
          this.uploadHander(0, file, new Date().getTime() + '/', signature, (pos, file, dirType, signature) => {
            console.log(signature.dir);
            let u = signature.dir + dirType + file.name;
            console.log(u);
            resolve({ url: u });
            //图片上传到oss之后 提交注册信息
            // setTimeout(() => {
            //   this.isReject ? this.isRejectSubmigCompelet() : this.submitCompelet()
            // }, 800)
          }, () => { this.isLoading = true; }, () => { this.isLoading = false; })
        }, (data) => {
        },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          });
      })

    },
    uploadHander(pos, file, dirType, signature, callBack, loadingStartCb, loadingEndCb) {
      //去后端拿签名
      InterfaceService.uploadToOss(signature, file, dirType, pos, callBack, '', '', loadingStartCb, loadingEndCb)
    },
    // 预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    // 原投标文件下载
    handleDownloadList(list) {
      if (!list.length) {
        this.$message('暂无下载地址')
      }
      let attach = [];
      list.forEach(i => {
        // if (i.attachType === type) {
        attach.push({
          url: i.attachUrl,
          name: i.attachName
        });
        // }
      });
      if (attach.length) {
        this.$download(attach).then(res => {
          this.$message.success("已下载");
        }).catch(res => {
          this.$message.error("下载失败");
        })
      }
    },
    // 下载
    handleDownload(url, name, type) {
      let attach = [];
      attach.push({
        url: url,
        name: name
      });
      this.$download(attach).then(res => {
        this.$message.success("已下载");
      }).catch(res => {
        this.$message.error("下载失败");
      })
    },
    // 删除
    delOther(list, index) {
      if (!list[index]) return
      if (list[index].ossFileId) {
        this.delFileList.push({
          ossFileId: list[index].ossFileId,
          inqRequestNo: this.inqRequestNo,
        })
      }
      list.splice(index, 1)
      this.$message.success('已删除')
      console.log(this.delFileList)
    },
    init() {
      this.supplierBidInquireNo = this.$route.query.supplierBidInquireNo || ''
      this.isSupplyPicture = this.$route.query.isSupplyPicture || ''
      // this.isPage = this.$route.query.isPage || ''
      let obj = this.$route.query.obj || ''
      obj = JSON.parse(decodeURIComponent(obj))
      this.supplierGetReplyDetail()
      this.bidNo = obj.bidNo || ''
      this.submitBidNo = obj.submitBidNo || ''
      this.breadcrumb = [
        { name: '管理中心', path: '/vendorCenter/accountInfo' },
        { name: '投标管理', path: '/vendorCenter/participatingBiddingList' },
        { name: '参与的招标', path: '/vendorCenter/participatingBiddingList' },
        { name: '询标', path: '/biddingSignUpInfo?bidNo=' + obj.bidNo + '&submitBidNo=' + obj.submitBidNo + '&type=' + obj.type + '&tab=' + obj.tab + '' },
        { name: '回复询标函' },
      ]
    },
  },
  mounted() {
    this.init()
  },
};
</script>

<style lang="scss" scoped>
/deep/ .claim {
  width: 100%;
  min-height: 140px;
  .el-textarea__inner {
    min-height: 140px !important;
    resize: none;
    overflow: auto;
  }
}
.line {
  width: 100%;
  height: 1px;
  background-color: #eeee;
  margin: 34px 0 20px;
}
.uploadFile {
  position: absolute;
  left: -9999px;
  width: 0px;
  height: 0px;
  overflow: hidden;
  opacity: 0;
}
.replyInquiryLetter {
  padding-bottom: 60px;
  .list-home {
    width: 1190px;
    margin: 0 auto;
    .list-content {
      ul.content-list {
        > li {
          font-size: 12px;
          margin-bottom: 10px;
          display: flex;
          .title {
            display: inline-block;
            line-height: 17px;
          }
          .info {
            display: inline-block;
            line-height: 17px;
            word-break: break-all;
            > p {
              > span {
                margin-left: 6px;
              }
            }
          }
          &.quotationList {
            display: block;
            .mockList {
              width: 100%;
              display: flex;
              margin-top: 10px;
              > div {
                flex: 1;
                height: 34px;
                background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
                line-height: 34px;
                text-align: center;
                color: #df0a0a;
                font-weight: 600;
                &:nth-child(2) {
                  margin-left: 20px;
                }
              }
            }
            // .mockList {
            //   width: 100%;
            //   height: 34px;
            //   background: rgba(245, 245, 245, 1);
            //   line-height: 34px;
            //   text-align: center;
            //   margin-bottom: 1px;
            // }
          }
        }
      }
      .problem-all {
        margin-top: 30px;
        .problem-box {
          .problem-title {
            width: 100%;
            display: flex;
            height: 39px;
            background: rgba(247, 245, 255, 1);
            border: 1px solid rgba(221, 221, 221, 1);
            line-height: 37px;
            margin-bottom: 10px;
            &.active {
              margin-bottom: 14px;
            }
            > .left {
              width: 1140px;
              padding-right: 20px;
              padding-left: 10px;
              font-weight: 600;
            }
            > .right {
              &.switch {
                .arrow {
                  display: inline-block;
                  width: 0;
                  height: 0;
                  border-right: 4px solid transparent;
                  border-left: 4px solid transparent;
                  border-bottom: 6px solid #0082ff;
                  transition: transform 0.3s ease;
                  &.active {
                    transform-origin: 4px 3px;
                    transform: rotate(180deg);
                  }
                }
              }
            }
          }
          ul.content-list {
            li {
              .info {
                max-width: calc(100% - 80px);
              }
              .uploadFileList {
                width: 100%;
                margin-top: 20px;
                > p {
                  font-size: 14px;
                  line-height: 20px;
                  color: rgba(68, 68, 68, 1);
                  > span {
                    display: inline-block;
                    margin-right: 10px;
                  }
                }
                .fileList {
                  width: 100%;
                  border: 1px solid rgba(221, 221, 221, 1);
                  padding: 0 10px 14px 10px;
                  margin: 6px 0 0px;
                  > p {
                    margin-top: 14px;
                    font-size: 12px;
                    line-height: 17px;
                    color: rgba(68, 68, 68, 1);
                    &.nodata {
                      color: #bbb;
                    }
                    > span {
                      margin-right: 10px;
                      &:first-child {
                        margin-left: 6px;
                      }
                    }
                  }
                }
              }
              .reply-box {
                width: 1190px;
                border: 1px solid #c99f4f;
                padding: 15px 10px 10px;
                .reply-info {
                  border-bottom: 1px dashed rgba(238, 238, 238, 1);
                  padding-bottom: 10px;
                  display: flex;
                  > .left {
                    width: 53px;
                    display: inline-block;
                    padding-left: 6px;
                    font-size: 14px;
                    > span {
                      position: relative;
                      &.underline::before {
                        content: "";
                        position: absolute;
                        bottom: -3px;
                        left: -6px;
                        width: 36px;
                        height: 7px;
                        background: rgba(201, 159, 79, 0.7);
                        opacity: 1;
                      }
                    }
                  }
                  > .right {
                    width: calc(100% - 53px);
                    display: inline-block;
                    margin-left: -10px;
                    vertical-align: text-top;
                  }
                }
                .quiz {
                  display: flex;
                  justify-content: space-between;
                  color: #888;
                  .annex {
                    flex: 1;
                    margin: 10px 0 0px;
                    font-size: 12px;
                    color: #444;
                    display: flex;
                    .annex-file {
                      margin: 0 10px 6px 0;
                      &:last-child {
                        margin-bottom: 0;
                      }
                    }
                    > span {
                      &.hand.blue {
                        margin-left: 6px;
                      }
                    }
                  }
                  > .grey {
                    margin-top: 10px;
                    flex: 1;
                    text-align: right;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
</style>
