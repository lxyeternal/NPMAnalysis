<template>
  <div class="edit-tendering-container" :style="{minHeight:contentHeight+'px'}">
    <Header></Header>
    <SearchBar :search-type="5" :progress="''" :is-border-bottom="true" :product-create-process="2"></SearchBar>
    <div class="edit-tendering-center">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm form">
        <el-row>
          <el-col :span="24">
            <el-form-item label="编号" prop="tenderNo">
              <span class="ml12">{{ruleForm.tenderNo}}</span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="名称" prop="tenderName">
              <el-input class="w24" :style="{width: '950px'}" v-model="ruleForm.tenderName" :disabled="tenderStatus == 2" maxlength="64"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="类目" prop="categoryId">
              <DropdownTree :width="'340px'" v-model="ruleForm.categoryId" :disabled="tenderStatus == 2"></DropdownTree>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="清单递交时间" prop="replyEndDt">
              <el-date-picker type="date" value-format="yyyy-MM-dd" :picker-options="replyEndDtOptions" v-model="ruleForm.replyEndDt" style="width: 340px" :disabled="tenderStatus == 2"></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-if="false">
          <el-col :span="24" class="tendering-explain">
            <el-form-item label="说明" prop="explain">
              <el-input type="textarea" maxlength="1000" width="1000px" v-model="ruleForm.explain" :disabled="tenderStatus == 2"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="清单" class="required" prop="tenderingDetailed">
              <ul :class="['upfile-container', {mt11: tenderStatus==2}, 'last-upfile']">
                <li v-if="this.tenderStatus != 2">
                  <span class="red">您可以先下载模板, 进行编辑后上传</span>
                  <span class="blue" @click="handleDownoadTemplate">下载模板</span>
                </li>
                <li v-if="docList && docList.filter(fItem=>fItem.docType==='tenderList' && !fItem.delState).length" class="body">
                  <div class="file-exhibition-container" v-for="(item, idx) in docList.filter(fItem=>fItem.docType==='tenderList' && !fItem.delState)" :key="idx">
                    <span class="file-name">{{item.docName}}</span>
                    <span class="blue" v-if="item.docId" @click="handleFileDownload(item)">下载</span>
                    <span class="blue" v-if="tenderStatus != 2" @click="handleFileDel(item, idx)">删除</span>
                  </div>
                </li>
                <li v-if="tenderStatus != 2 && !docList.filter(fItem=>fItem.docType==='tenderList' && !fItem.delState).length" class="pl8">
                  <UpfileComponent :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :fileTypes="'xls, xlsx, xlsm'" :dirName="tenderListDirName" :docType="'tenderList'" @outputList="outputUpfileList($event, 1)"></UpfileComponent>
                </li>
              </ul>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row v-if="false">
          <el-col :span="24">
            <el-form-item label="说明文件" class="required" prop="otherAnnexes">
              <ul class="upfile-container">
                <li v-if="docList && docList.filter(fItem=>fItem.docType==='tenderAttach'  && !fItem.delState).length" class="body last-body">
                  <div class="file-exhibition-container" v-for="(item, idx) in docList.filter(fItem=>fItem.docType==='tenderAttach' && !fItem.delState)" :key="idx">
                    <span class="file-name">{{item.docName}}</span>
                    <span class="blue" v-if="item.docId" @click="handleFileDownload(item)">下载</span>
                    <span class="blue" v-if="tenderStatus != 2" @click="handleFileDel(item, idx)">删除</span>
                  </div>
                </li>
                <li v-if="tenderStatus != 2" class="pl8">
                  <UpfileComponent :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :dirName="tenderAttachDirName" :multiple="true" :docType="'tenderAttach'" @outputList="outputUpfileList($event, 2)"></UpfileComponent>
                </li>
              </ul>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row class="last-row">
          <el-col :span="24">
            <el-form-item label="负责人" prop="personLiables">
              <el-select v-model="ruleForm.personLiables" multiple placeholder="" :disabled="tenderStatus == 2">
                <el-option v-for="item in ruleForm.personLiableList" :key="item.acctId" :label="item.custName" :value="item.acctId">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <div class="btn-container" v-if="tenderStatus != 2">
        <el-button type="primary" @click="handleSubmitForm(1)">保存</el-button>
        <el-button type="primary" @click="handleSubmitForm(2)" v-if="true">确认发布</el-button>
        <el-button @click="handleSubmitForm(3)" v-else>撤回发布</el-button>
        <el-button @click="handleCancel">取消</el-button>
      </div>
      <div class="btm-notice" v-else>
        <p v-if="isViewMode">温馨提示: 负责人才能进行编辑</p>
        <p v-else>温馨提示: 如有问题, 请联系客服, 客服电话: {{$platformContact()['hotLine']}} {{$platformContact()['hotLineTime']}}</p>
      </div>
    </div>
    <!-- 文件上传提示 -->
    <el-dialog title="上传提示" :visible.sync="uploadDialogVisible" width="30%" :close-on-click-modal="false" center>
      <span class="upload-dialog-span">{{repeatFileName}} 相同文件名会覆盖, 是否继续上传</span>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="uploadDialogVisibleBtn&&uploadDialogVisibleBtn.confirm() || ''">确定</el-button>
        <el-button @click="uploadDialogVisibleBtn&&uploadDialogVisibleBtn.cancel() ">取消</el-button>
      </span>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Breadcrumb from "@/components/base/Breadcrumb";
import DropdownTree from "@/components/order/dropdownTree";
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";

import { InterfaceService } from "@/services/api"

const params = {
  tenderName: '', // 名称

  tenderNo: '', // 编号
  categoryId: '', // 类目
  replyEndDt: '', // 时间
  explain: '', // 说明
  tenderingDetailed: '', // 清单
  otherAnnexes: '', // 附件
  personLiables: [], // 负责人
  personLiableList: '', // 负责人List

};

export default {
  components: {
    Loading,
    Header,
    SearchBar,
    Breadcrumb,
    DropdownTree,
    UpfileComponent
  },
  watch: {
    'ruleForm.categoryId'() {
      this.$refs.ruleForm.validateField('categoryId')
    },
    'ruleForm.personLiables'() {
      this.$refs.ruleForm.validateField('personLiables')
    }
  },
  data() {
    return {
      isLoading: false,
      breadcrumb: [],
      ruleForm: Object.assign({}, params),
      rules: {
        tenderName: [{ required: true, message: '请输入名称', trigger: 'change' }, { required: true, message: '请输入名称', trigger: 'blur' }],
        categoryId: [{ required: true, message: '请选择类目', trigger: 'blur' }],
        replyEndDt: [{ required: true, message: '请选择清单递交时间', trigger: 'blur' }],
        personLiables: [{ required: true, message: '请选择负责人', trigger: 'blur' }],
      },
      tenderStatus: 2, // 状态 0: 新增 , 1: 编辑, 2: 查看
      tenderListDirName: '', // 清单 dirName
      tenderAttachDirName: '', // 附件 dirName
      tenderList: [], // 上传文件 - 清单
      tenderDelList: [], // 删除的文件list
      tenderAttach: [], // 上传文件 - 附件
      docList: [], // 创建/爆出 - 文件上传list
      replyEndDtOptions: { // 设置禁选时间
        disabledDate(time) {
          const nowTime = new Date(Date.now())

          return time.getTime() < new Date(`${nowTime.getFullYear()}-${nowTime.getMonth() + 1}-${nowTime.getDate()}`).getTime();
        },
      },
      isViewMode: false, // 该负责人人是否为查看模式
      uploadDialogVisible: false, // 同名文件 -上传提示框
      uploadDialogVisibleBtn: { confirm() { }, cancel() { }, }, // 同名文件 -上传提示框 按钮
      repeatFileName: '', // 重复文件名
      contentHeight: 814
    }
  },
  computed: {
    corpId() {
      return (
        this.$store.state.userInfo && this.$store.state.userInfo.corpId || ''
      )
    },
  },
  mounted() {
    this.init()
  },
  methods: {
    async init() {
      this.tenderStatus = this.$getRootScope('tenderingState') || 2
      const tenderingStateArr = ['新增', '编辑', '查看详情']

      await this.getSubRole()
      // 0: 新增
      if (this.tenderStatus == 0) {
        this.ruleForm.tenderNo = await this.getTenderNo()
      } else {
        this.ruleForm.tenderNo = this.$getRootScope('tenderNo') || ''
        await this.getInviteTenderDetail()
      }

      this.setDirName()

      // 编辑状态下 判断当前用户是否是负责人
      if (this.tenderStatus == 1) {
        const user = JSON.parse(this.$getRootScope('user'))
        this.tenderStatus = this.ruleForm.personLiables.includes(user.acctId) ? this.tenderStatus : 2
        if (this.tenderStatus === 2) this.isViewMode = true
      }

      this.breadcrumb = [
        { name: '比价管理', path: '/purchaserCenter/biddingMaterial' },
        { name: tenderingStateArr[this.tenderStatus] },
      ]

      this.setMinHeight()

    },


    /**
     * 设置DIV高度
     */
    setMinHeight() {
      let h = window.innerHeight ||
        document.documentElement.clientHeight ||
        document.body.clientHeight

      this.contentHeight = h - 155
    },

    /**
     * 设置上传dirname
     */
    setDirName() {
      this.tenderListDirName = `${this.ruleForm.tenderNo}/tenderList/${new Date().getTime()}/`
      this.tenderAttachDirName = `${this.ruleForm.tenderNo}/tenderAttach/${new Date().getTime()}/`
    },

    /**
     * 取消
     */
    handleCancel() {
      this.$router.push({ path: '/purchaserCenter/biddingMaterial' })
    },

    /**
     * 上传组件返回
     */
    outputUpfileList(ev, state) {
      this.setDirName()
      const evIitem = ev || []

      // 存储重复的文件
      let repeatItem = []

      // 找出重复文件
      evIitem.forEach(item => {
        const { type: docType, name: docName, url: docUrl } = item || {}

        for (let i = 0, len = this.docList.length; i < len; i++) {
          const docListItem = this.docList[i];
          // 如果删除状态为true 说明已经删除 不需要做比较
          if (!docListItem.delState && (docListItem.docName === docName && docListItem.docType === docType)) {
            // 存储重复的文件名
            repeatItem.push({ docName, docType, docUrl })
          }
        }
      })
      this.setFileList(evIitem, repeatItem)
    },

    /**
     * 设置文件列表显示数组
     */
    setFileList(evIitem, repeatItem) {
      const __this = this
      // 如果有重复数据
      if (repeatItem.length) {
        // 组装显示提示
        this.repeatFileName = ''
        this.repeatFileName = `有${repeatItem.length}个文件名重复 (`
        repeatItem.forEach(fItem => this.repeatFileName += ` [ ${fItem.docName} ] `)
        this.repeatFileName = this.repeatFileName.slice(0, this.repeatFileName.lastIndexOf(','))
        this.repeatFileName += ' ) ,'

        this.uploadDialogVisible = true


        // 填充docList
        const repeatDocListFun = () => {
          evIitem.map(mapItem => {
            const { type: docType, name: docName, url: docUrl } = mapItem || {},
              // 判断 该条填充数据 是否重复  isPush: true 未重复可添加, false 已重复无需添加
              isPush = !repeatItem.some(someItem => someItem.docType === docType && someItem.docName === docName)

            isPush && this.docList.push({ docType, docName, docUrl })
          })
        }

        this.uploadDialogVisibleBtn = {
          // 点击确认覆盖
          confirm: () => {
            // 查找重复文件
            repeatItem.map(rItem => {
              for (let idx = __this.docList.length - 1; idx >= 0; idx--) {
                const m = __this.docList[idx];
                // 如果 name  和 type  匹配 则说明是重复文件名
                if (rItem.docName === m.docName && rItem.docType === m.docType) {
                  console.log(__this.docList[idx], '替换文件删除');
                  if (m.docId) {
                    m.unSubState = false
                    __this.tenderDelList.push(m)
                  }
                  // 移除原数据,
                  __this.docList.splice(idx, 1)
                  // 添加新数据
                  __this.docList.push({ docType: rItem.docType, docName: rItem.docName, docUrl: rItem.docUrl })
                  break
                }
              }
              __this.uploadDialogVisible = false
            })
            repeatDocListFun()
          },
          // 取消
          cancel: () => {
            this.uploadDialogVisible = false
          }
        }
      } else {
        // 如果没有重复数据 直接添加
        evIitem.map(mapItem => {
          const { type: docType, name: docName, url: docUrl } = mapItem || {}
          this.docList.push({ docType, docName, docUrl })
        })

      }

    },

    /**
     * 格式化时间
     */
    formatTime(val) {
      return val < 10 ? `0${val}` : val
    },

    /**
     * 提交
     */
    handleSubmitForm(state) {
      if (this.ruleForm.personLiables.length > 7) {
        this.$message.error('最多只能选择7个负责人')
        return
      }

      try {
        if (!!this.ruleForm.replyEndDt) {
          // 判断时间 是否小于当前时间
          const nowDate = new Date(),
            nowTime = `${this.formatTime(nowDate.getFullYear())}-${this.formatTime(nowDate.getMonth() + 1)}-${this.formatTime(nowDate.getDate())}`,
            regEndDtList = this.ruleForm.replyEndDt.match(/^\d{2,4}-\d{1,2}-\d{1,2}/) || [],
            regEndDt = regEndDtList[0] || '0'

          console.log(regEndDt, nowTime, new Date(regEndDt).getTime() >= new Date(nowTime).getTime());
          // 如果 选择时间 不小于 当前时间 才允许提交
          if (new Date(regEndDt).getTime() < new Date(nowTime).getTime()) {
            this.$message.error('清单递交时间不能小于当前时间')
            return
          }
        }
      } catch (error) {
        console.warn(`清单递交时间不能小于当前时间 => ${error}`)
      }

      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          if (state === 2) {
            // 验证 清单 和 附件是否有提交
            console.log(this.docList.filter(f => f.docType === 'tenderList' && !f.delState).length, this.docList.filter(f => f.docType === 'tenderAttach' && !f.delState).length)

            if (!this.docList.filter(f => f.docType === 'tenderList' && !f.delState).length) {
              this.$message.error('请上传清单')
              return
            }

            // if (!this.docList.filter(f => f.docType === 'tenderAttach' && !f.delState).length) {
            //   this.$message.error('请上传说明文件')
            //   return
            // }
          }
          if (state === 1 || state === 2) {
            this.formatTenderInfoParams(state)
          }
        } else {
          this.$message.error('请填写必填信息')
          return false;
        }
      })
    },

    /**
     * 下载清单模板
     */
    handleDownoadTemplate() {
      if (!this.ruleForm.categoryId.length) {
        this.$message.error('请选择类目')
        return
      }
      const param = {
        categoryId: this.ruleForm.categoryId
      }
      InterfaceService.downloadInviteTenderTemp(param, data => {
        if (data && data.respData && data.respData.respCode === '0000') {
          const tempList = data.respData.tempList || []
          if (!tempList.length) return
          tempList.map(item => {
            item.url = item.attachUrl || ''
            item.name = `${item.tempName}.xlsx` || ''
          })
          this.$download(tempList, () => {this.isLoading = true}, () => {this.isLoading = false}).then(result => {
            this.$message.success('已下载')
          }).catch(err => {
            this.$message.error('下载失败')
          })

        } else {
          this.$message.error(data && data.respData && data.respData.respMsg || '')
        }

      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

    /**
     * 下载 文件
     */
    handleFileDownload(item) {
      item.url = item.attachUrl || ''
      item.name = item.docName || ''
      this.$download([item]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },

    /**
     * 删除 文件
     * @param item: 数据
     */
    handleFileDel(item) {
      // 如果没有docId 说明还没提交到后台
      console.log(!item.docId);

      if (!item.docId) {
        for (let i = 0, len = this.docList.length; i < len; i++) {
          const docItem = this.docList[i] || []
          // 通过 docUrl 匹配到对应数据 从原数组移除
          if (docItem.docUrl === item.docUrl) {
            this.docList.splice(i, 1)
            break
          }
        }
        return
      }
      // 标记 不需要提交state
      item.unSubState = false
      // 标记 被删除
      this.$set(item, 'delState', true)

    },

    /**
     * 获取标号
     */
    getTenderNo() {
      return new Promise(resolve => {
        InterfaceService.getTenderNo({type:"TENDER"}, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            resolve(data.respData.busiNo || '')
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => {
          this.Loading = true
        }, () => {
          this.Loading = false
        })
      })
    },

    /**
     * 设置 状态 为编辑
     */
    setTenderStatus() {
      this.$store.dispatch("setTenderingState", 1);
      this.$store.dispatch("setTenderNo", this.ruleForm.tenderNo || '');
      this.init()
    },

    /**
     * 新增 / 修改 入参格式化
     */
    formatTenderInfoParams(state) {
      const { tenderNo, tenderName, categoryId, explain, replyEndDt, personLiables: personInChargeList } = this.ruleForm,
        param = {
          tenderNo, //	Y	标号（调用标号采番接口获取）
          tenderName, //	Y	名称（最多64个字）
          categoryId, //	Y	类目ID（需要是叶子节点的类目）
          replyEndDt, //	Y 递交时间	回标结束时间（YYYY-MM-DD HH:MM:SS, 且需要是未来的时间，回标结束时间需大于回标开始时间）
          explain, //	Y	说明（最多1000字）
          personInChargeList, //<String>	Y	负责人账户ID列表
          tenderStatus: state === 1 ? 'unpublished' : 'published', //	Y	状态（unpublished：未发布 published：已发布）
          docList: [...this.docList, ...this.tenderDelList] // 文件
        }
      // 去掉不用上传的文件
      param.docList = param.docList.filter(fItem => {
        return !fItem.unSubState
      })
      console.log(param, '新增/修改');
      this.tenderStatus == 0 ? this.createInviteTenderInfo(param) : this.updateInviteTenderInfo(param)
    },

    /**
     * 创建&保存信息
     */
    createInviteTenderInfo(param) {
      InterfaceService.createInviteTenderInfo(param, data => {
        if (data && data.respData && data.respData.respCode === '0000') {
          this.$message.success(param.tenderStatus === 'unpublished' ? '已保存' : '信息发布成功')
          this.setTenderStatus()
          this.$router.push({ path: '/purchaserCenter/biddingMaterial' })
        } else {
          this.$message.error(data.respData.respMsg)
          if (!data.respData.attachUrl) return
          this.$download([{ url: data.respData.attachUrl || '', name: data.respData.attachName || '' }])

        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })

    },

    /**
     * 更新
     */
    updateInviteTenderInfo(param) {
      console.log('更新', param);
      InterfaceService.updateInviteTenderInfo(param, data => {
        if (data && data.respData && data.respData.respCode === '0000') {
          this.$message.success(param.tenderStatus === 'unpublished' ? '已保存' : '信息发布成功')
          this.getInviteTenderDetail()
          this.$router.push({ path: '/purchaserCenter/biddingMaterial' })
        } else {
          this.$message.error(data.respData.respMsg)
          if (!data.respData.attachUrl) return
          this.$download([{ url: data.respData.attachUrl || '', name: data.respData.attachName || '' }])
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

    /**
     * 查询详情
     */
    getInviteTenderDetail() {
      return new Promise(resolve => {
        const { tenderNo } = this.ruleForm,
          param = {
            tenderNo
          }
        InterfaceService.getInviteTenderDetail(param, data => {
          if (data && data.respData && data.respData.respCode === '0000') {
            this.ruleForm = Object.assign(this.ruleForm, data.respData)
            this.ruleForm.personLiables = []
            // 反显 和 格式化 负责人
            this.ruleForm.personInChargeList.map(item => {
              item.custName = item.name
              this.ruleForm.personLiables.push(item.acctId)
            })
            // unSubState  true: 未删除 ,  false: 已删除
            this.ruleForm.docList.map(item => item.unSubState = true)
            this.docList = [...this.ruleForm.docList] || []
            resolve(data.respData)
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })

    },

    /**
     * 获取负责人
     */
    getSubRole() {
      return new Promise(resolve => {
        const param = {
          corpId: this.corpId
        };
        InterfaceService.getQuerySubordinate(param, data => {
          if (data && data.respData && data.respData.respCode === '0000') {
            const itemList = data.respData.roleList || []
            itemList.forEach(item => item.roleId == '614' && (this.ruleForm.personLiableList = item.acctList || []))
            console.log(this.ruleForm, 'this.ruleForm');
            resolve(data.respData.roleList)
          } else {
            this.$message.error(data.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        });
      })
    },
  },
}
</script>
<style scoped lang="scss">
.edit-tendering-container {
  position: relative;
  margin-bottom: 100px;
  .edit-tendering-center {
    position: relative;
    width: 1190px;
    margin: 0 auto;
    .upfile-container {
      font-size: 12px;
      &.last-upfile {
        .body {
          line-height: 30px !important;
        }
      }
      ::-webkit-scrollbar {
        width: 1px !important;
      }
      ::-webkit-scrollbar-button {
        height: 0;
      }
      li {
        height: 30px;

        &.body {
          max-height: 200px;
          min-height: 30px;
          line-height: 20px;
          height: auto;
          overflow: auto;
          &.last-body {
            padding-top: 10px;
          }
        }
        .file-name {
          margin-right: 12px;
        }
        .red {
          margin-right: 4px;
        }
        .blue {
          cursor: pointer;
          margin-right: 4px;
        }
        & > span {
          &:first-child {
            margin-left: 12px;
          }
        }
      }
    }
    .form {
      $borderStyle: 1px solid #d1e1ea;
      border: $borderStyle;
      background: #f1f8fe;
      border-left: 0;
      border-top: 0;
      .tendering-explain {
        padding-bottom: 5px;
      }
      .last-row {
        &::before {
          content: "";
          display: block;
          background: #fff;
          border-top: $borderStyle;
          margin-right: -1px;
          height: 12px;
        }
      }
      /deep/ .el-row {
        overflow: inherit;

        .el-form-item {
          margin-bottom: 0;
          &.required {
            .el-form-item__label {
              &::before {
                content: "*";
                color: #f56c6c;
                margin-right: 4px;
              }
            }
          }
        }
        .el-input__inner {
          width: 340px;
        }
        .el-form-item__label {
          font-weight: bold;
          font-size: 12px;
          width: 122px !important;
        }
        .el-textarea__inner {
          min-height: 150px !important;
          margin-bottom: 5px;
        }
        .el-form-item__error {
          top: 29px;
          z-index: 11;
          left: 22px;
        }
        .el-form-item {
          height: 100%;
          display: flex;
          .el-form-item__label {
            height: 100%;
            padding: 5px 12px;
            width: 130px !important;
          }
          .el-form-item__content {
            border-left: $borderStyle;
            padding: 5px 12px;
            margin-left: 0 !important;
            width: 85%;
            .el-textarea__inner {
              width: 950px;
            }
          }
        }
        %temp-el-input-disable {
          background: transparent;
          border: 0;
          cursor: text;
          color: #606266;
          resize: none;
          padding-left: 13px;
        }
        .el-input.is-disabled .el-input__inner {
          @extend %temp-el-input-disable;
        }
        .el-textarea.is-disabled .el-textarea__inner {
          @extend %temp-el-input-disable;
        }
        .el-input.is-disabled .el-input__icon {
          display: none;
        }
        .el-select .el-tag {
          background: transparent;
        }
        .ml12 {
          margin-left: 12px;
        }
        .file-exhibition-container {
          font-size: 14px;
          margin-left: 12px;
        }
      }
      [class*="el-col-"] {
        padding: 0px 22px 0;
        border-left: $borderStyle;
        border-top: $borderStyle;
      }
    }
    .pl8 {
      padding-left: 8px;
    }
  }
  .btn-container {
    text-align: center;
    margin-top: 22px;
  }
  .btm-notice {
    margin-top: 14px;
    font-weight: bold;
    font-size: 14px;
  }
  .w24 /deep/ .el-input__inner {
    width: 100% !important;
  }
  /deep/ .el-input__inner {
    min-height: 42px !important;
    line-height: 42px !important;
    color: #444 !important;
  }
  /deep/ .el-tag {
    color: #444 !important;
    font-size: 14px !important;
  }
  .mt11 {
    margin-top: 11px;
  }
  .upload-dialog-span {
    display: block;
    font-size: 14px;
    text-align: center;
    line-height: 22px;
  }
  /deep/ .is-error {
    .title-container {
      border-color: #f56c6c !important;
      &::after {
        border-color: transparent transparent #f56c6c #f56c6c !important;
      }
    }
    .body-container {
      margin-top: 0;
    }
  }
  /deep/ .is-success {
    .title-container {
      border-color: #67c23a !important;
    }
  }
}
</style>
