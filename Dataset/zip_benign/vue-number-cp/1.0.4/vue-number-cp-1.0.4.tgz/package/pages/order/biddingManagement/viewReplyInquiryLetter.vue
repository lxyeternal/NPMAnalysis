<template>
  <div class="replyInquiryLetter">
    <Header :is-white-bg="true"></Header>
    <SearchBar :search-type="5" :progress="'回复询标函'" :is-border-bottom="true"></SearchBar>
    <div class="list-home">
      <Breadcrumb :breadcrumbList="breadcrumb" @refresh="handleGoBack()"></Breadcrumb>
      <div class="list-content">
        <PanelTitle :title="'基本信息'"></PanelTitle>
        <ul class="content-list">
          <li>
            <div class="title grey">询标函主题：</div>
            <div class="info" style="max-width: calc(100% - 90px);">{{theme}}</div>
          </li>
          <li>
            <div class="title grey">发送者：</div>
            <div class="info">{{purchaserCorpName}}</div>
          </li>
          <li>
            <div class="title grey">回复截止时间：</div>
            <div class="info">{{deadline && deadline.split(' ')[0]}}</div>
          </li>
        </ul>
        <!-- 查看 -->
        <div class="problem-all">
          <PanelTitle :title="'问题汇总'"></PanelTitle>
          <div class="problem-box" v-for="(a,index_a) in requestList" :key="index_a">
            <div v-show="(pageIndex-1)*pageSize<=index_a && index_a<pageIndex*pageSize">
              <div class="problem-title" :class="{'active':a.isShowPanel}">
                <div class="left ellipsisOne">
                  问题{{index_a+1}}：{{a.requestTheme}}
                </div>
                <div class="right switch hand blue" @click="a.isShowPanel=!a.isShowPanel">{{a.isShowPanel?'收起':'展开'}} <i class="arrow" :class="{active:!a.isShowPanel}"></i></div>
              </div>
              <ul class="content-list" v-show="a.isShowPanel">
                <li>
                  <div class="title grey tr" style="min-width: 62px">详细描述：</div>
                  <div class="info" v-html="a.requestDescription.replace(/\n/g, '<br/>')"></div>
                </li>
                <li>
                  <div class="title grey tr" style="min-width: 62px">问题分类：</div>
                  <div class="info">{{a.requestClassify=='TECHNICALBID'?'技术标':'商务标'}}<span>-{{a.requestClassifyName}}</span></div>
                </li>
                <li>
                  <div class="title grey tr" style="min-width: 62px">附件：</div>
                  <div class="info" v-if="!a.requestAttachInfoList.length">
                    <p class="grey">暂无附件</p>
                  </div>
                  <div class="info" v-else>
                    <p v-for="(b,index) in a.requestAttachInfoList" :key="index+'info'">{{b.attachName}}<span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span></p>
                  </div>
                </li>
                <li>
                  <div class="reply-box">
                    <div class="reply-info">
                      <div class="left">
                        <span class="underline">回复</span>
                      </div>
                      <div class="right f12" v-html="a.responseContent.replace(/\n/g, '<br/>')">
                      </div>
                    </div>
                    <p></p>
                    <div class="quiz">
                      <div>
                        <!-- 采购商创建询标函时只勾选模拟清单 -->
                        <div v-if="a.quotationUptFlg.indexOf('38') !== -1 && a.quotationUptFlg.indexOf('26') === -1" class="annex">
                          <span class="bold">重新提交模拟清单：</span>
                          <div>
                            <p class="annex-file">{{a.quoteAttachInfoList.filter(i=>{return i.attachType == '26'})[0].attachName}}
                              <span class="hand blue" @click="handleDownload(a.quoteAttachInfoList.filter(i=>{return i.attachType == '26'})[0].attachUrl,a.quoteAttachInfoList.filter(i=>{return i.attachType == '26'})[0].attachName)">下载</span>
                              <span style="margin-left: 10px;" class="blue hover-underline hand" @click="goViewMockList">查看模拟清单</span>
                            </p>
                          </div>
                        </div>

                        <div class="annex" v-for="(c,index) in a.requestClassifyList" :key="index+'requestClassifyList'">
                          <span class="bold">{{c.requestClassifyName}}：</span>
                          <div>
                            <p class="annex-file">{{c.attachName}}
                              <span class="hand blue" @click="handleDownload(c.attachUrl,c.attachName)">下载</span>
                              <span style="margin-left: 10px;" v-if="isSupplyPicture=='1' && c.attachType == '26'" class="blue hover-underline hand" @click="goViewProImg">查看商品图</span>
                              <span style="margin-left: 10px;" v-if="mockProdCntList.length && c.attachType == '26'" class="blue hover-underline hand" @click="goViewMockList">查看模拟清单</span>
                            </p>
                          </div>
                        </div>
                        <div class="annex"><span class="bold">附件：</span>
                          <div v-if="!a.responseAttachInfoList.length">
                            <p class="annex-file grey">暂无附件</p>
                          </div>
                          <div v-else>
                            <p v-for="(b,ind_b) in a.responseAttachInfoList" :key="ind_b" class="annex-file">{{b.attachName}} <span class="hand blue" @click="handleDownload(b.attachUrl,b.attachName)">下载</span></p>
                          </div>
                        </div>
                      </div>
                      <p class="grey f12">回复时间：{{a.responseTm}}</p>
                    </div>
                  </div>
                </li>
              </ul>
              <div class="line" v-if="requestList.length != index_a+1 && a.isShowPanel"></div>
            </div>

          </div>
        </div>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!requestList.length">
          <img src="@/assets/images/icon-no-product.png">
          <p>暂无回复询标函！</p>
        </div>
        <!-- 分页 -->
        <div class="table-pagination" v-if="requestList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="requestList.length" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import Header from "@/components/base/Header";
import Breadcrumb from "@/components/base/Breadcrumb";
import SearchBar from "@/components/SearchBar";
import PanelTitle from "@/components/base/PanelTitle";
import { viewFile } from '@/utils/orderUtil';
export default {
  components: {
    SearchBar,
    Loading,
    Breadcrumb,
    Header,
    PanelTitle,
  },
  data() {
    return {
      isLoading: false,
      breadcrumb: [],

      requestList: [],
      delFileList: [],

      theme: '',
      deadline: '',
      purchaserCorpName: '',
      supplierBidInquireNo: '',//	供应商询标函编号
      bidInquireNo: '',//询标函编号
      inqRequestNo: '',// 询标函问题编号
      isSupplyPicture: '',//是否完善商品图(0,1)
      mockProdCntList: [],//mockProdCntList为空时表示发标没有勾选模拟清单
      obj: {},

      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码
    };
  },
  methods: {
    goViewMockList() {
      this.$setRootScope('mockList', JSON.stringify(this.mockProdCntList))
      window.open(this.$router.resolve({
        path: "/viewMockList_s",
        query: {
          type: this.obj.type,
          bidNo: this.obj.bidNo,
          submitBidNo: this.obj.submitBidNo,
          tab: this.obj.tab,
        }
      }).href, '_blank')
    },
    goViewProImg() {
      window.open(this.$router.resolve({
        path: "/viewProImg",
        query: {
          type: this.obj.type,
          bidNo: this.obj.bidNo,
          submitBidNo: this.obj.submitBidNo,
          tab: this.obj.tab,
        }
      }).href, '_blank')
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
    },
    // 供应商查看回复函详情
    supplierGetReplyDetail() {
      let param = {
        supplierBidInquireNo: this.supplierBidInquireNo
      }
      InterfaceService.supplierGetReplyDetail(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.bidInquireNo = data.respData.bidInquireNo || ''
          this.theme = data.respData.theme || ''
          this.deadline = data.respData.deadline || ''
          this.purchaserCorpName = data.respData.purchaserCorpName || ''
          this.requestList = data.respData.requestList || []
          this.mockProdCntList = data.respData.mockProdCntList || []
          // 分离投标文件和附件
          this.requestList.forEach(i => {  //requestClassifyName
            this.$set(i, 'isShowPanel', true)
            // 判断是否有报价清单与模拟清单,有报价清单将模拟清单放到报价清单的后面
            if (i.quotationUptFlg.indexOf('38') !== -1) {
              let a = 0
              let b = i.responseAttachInfoList.some((item, index) => { if (item.attachType == '26') { a = index; return true } })
              if (b) {
                i.responseAttachInfoList.splice(a + 1, 0, { attachType: '38' })
              } else {
                i.responseAttachInfoList.push({
                  attachType: '38'
                })
              }
            }
            console.log(i.responseAttachInfoList)
            let technicalDeviation = [] //甲供直采招标设备技术偏离表
            let quotationList = [] //报价清单
            let biddingDocuments = [] //招标文件(基础版)
            let biddingDocumentsSpecialty = [] //招标文件(专业版)
            let companyContacts = [] //针对绿地各地分公司联系人
            // let sampleList = [] //送样清单
            let quotationPDFList = [] //报价清单PDF版

            let responseAttachInfoList = [] //附件
            let requestClassifyName = [] //问题分类
            let requestClassifyList = [] //问题分类
            if (i.responseAttachInfoList && i.responseAttachInfoList.length) {
              i.responseAttachInfoList.forEach(j => {
                if (j.attachType == '25') {
                  requestClassifyList.push(j)
                  j.requestClassifyName = '重新提交甲供直采招标设备技术偏离表'
                  requestClassifyName.push('重新提交甲供直采招标设备技术偏离表')
                } else if (j.attachType == '26') {
                  requestClassifyList.push(j)
                  j.requestClassifyName = '重新报价'
                  requestClassifyName.push('重新报价')
                } else if (j.attachType == '28') {
                  requestClassifyList.push(j)
                  j.requestClassifyName = '重新提交招标文件(基础版)'
                  requestClassifyName.push('重新提交招标文件(基础版)')
                } else if (j.attachType == '29') {
                  requestClassifyList.push(j)
                  j.requestClassifyName = '重新提交招标文件(专业版)'
                  requestClassifyName.push('重新提交招标文件(专业版)')
                } else if (j.attachType == '30') {
                  requestClassifyList.push(j)
                  j.requestClassifyName = '针对绿地各地分公司联系人'
                  requestClassifyName.push('针对绿地各地分公司联系人')
                } else if (j.attachType == '38') {
                  requestClassifyName.push('重新提交模拟清单')
                } else if (j.attachType == '44') {
                  requestClassifyList.push(j)
                  j.requestClassifyName = '重新报价PDF版'
                  requestClassifyName.push('重新报价PDF版')
                } else {
                  responseAttachInfoList.push(j)
                }
              });
            }
            i.responseAttachInfoList = responseAttachInfoList
            console.log(responseAttachInfoList)
            console.log(requestClassifyName)
            this.$set(i, 'requestClassifyName', (requestClassifyName.join('、') || ''))
            this.$set(i, 'requestClassifyList', requestClassifyList)
          });
          console.log(this.requestList)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    // 原投标文件下载
    handleDownloadList(list) {
      if (!list.length) {
        this.$message('暂无下载地址')
      }
      let attach = [];
      list.forEach(i => {
        // if (i.attachType === type) {
        attach.push({
          url: i.attachUrl,
          name: i.attachName
        });
        // }
      });
      if (attach.length) {
        this.$download(attach).then(res => {
          this.$message.success("已下载");
        }).catch(res => {
          this.$message.error("下载失败");
        })
      }
    },
    // 下载
    handleDownload(url, name, type) {
      let attach = [];
      attach.push({
        url: url,
        name: name
      });
      this.$download(attach).then(res => {
        this.$message.success("已下载");
      }).catch(res => {
        this.$message.error("下载失败");
      })
    },
    init() {
      this.isSupplyPicture = this.$route.query.isSupplyPicture || ''
      this.supplierBidInquireNo = this.$route.query.supplierBidInquireNo || ''
      let obj = this.$route.query.obj || ''
      this.obj = JSON.parse(decodeURIComponent(obj))
      this.supplierGetReplyDetail()
      this.breadcrumb = [
        { name: '管理中心', path: '/vendorCenter/accountInfo' },
        { name: '投标管理', path: '/vendorCenter/participatingBiddingList' },
        { name: '参与的招标', path: '/vendorCenter/participatingBiddingList' },
        { name: '询标', path: '/biddingSignUpInfo?bidNo=' + this.obj.bidNo + '&submitBidNo=' + this.obj.submitBidNo + '&type=' + this.obj.type + '&tab=' + this.obj.tab + '' },
        { name: '查看询标函' },
      ]
    },
  },
  mounted() {
    this.init()
  },
};
</script>

<style lang="scss" scoped>
/deep/ .claim {
  width: 100%;
  min-height: 140px;
  .el-textarea__inner {
    min-height: 140px !important;
    resize: none;
    overflow: auto;
  }
}
.line {
  width: 100%;
  height: 1px;
  background-color: #eeee;
  margin: 34px 0 20px;
}
.uploadFile {
  position: absolute;
  left: -9999px;
  width: 0px;
  height: 0px;
  overflow: hidden;
  opacity: 0;
}
.replyInquiryLetter {
  padding-bottom: 60px;
  .list-home {
    width: 1190px;
    margin: 0 auto;
    .list-content {
      ul.content-list {
        > li {
          font-size: 12px;
          margin-bottom: 10px;
          display: flex;
          .title {
            display: inline-block;
            line-height: 17px;
          }
          .info {
            display: inline-block;
            line-height: 17px;
            word-break: break-all;
            > p {
              > span {
                margin-left: 6px;
              }
            }
          }
        }
      }
      .problem-all {
        margin-top: 30px;
        .problem-box {
          .problem-title {
            width: 100%;
            display: flex;
            height: 39px;
            background: rgba(247, 245, 255, 1);
            border: 1px solid rgba(221, 221, 221, 1);
            line-height: 37px;
            margin-bottom: 10px;
            &.active{
              margin-bottom: 10px;
            }
            > .left {
              width: 1140px;
              padding-right: 20px;
              padding-left: 10px;
              font-weight: 600;
            }
            > .right {
              &.switch {
                .arrow {
                  display: inline-block;
                  width: 0;
                  height: 0;
                  border-right: 4px solid transparent;
                  border-left: 4px solid transparent;
                  border-bottom: 6px solid #0082ff;
                  transition: transform 0.3s ease;
                  &.active {
                    transform-origin: 4px 3px;
                    transform: rotate(180deg);
                  }
                }
              }
            }
          }
          ul.content-list {
            li {
              .info {
                max-width: calc(100% - 80px);
              }
              .uploadFileList {
                width: 100%;
                margin-top: 20px;
                > p {
                  font-size: 14px;
                  line-height: 20px;
                  color: rgba(68, 68, 68, 1);
                  > span {
                    display: inline-block;
                    margin-right: 10px;
                  }
                }
                .fileList {
                  width: 100%;
                  border: 1px solid rgba(221, 221, 221, 1);
                  padding: 0 10px 14px 10px;
                  margin: 6px 0 0px;
                  > p {
                    margin-top: 14px;
                    font-size: 12px;
                    line-height: 17px;
                    color: rgba(68, 68, 68, 1);
                    &.nodata {
                      color: #bbb;
                    }
                    > span {
                      margin-right: 10px;
                      &:first-child {
                        margin-left: 6px;
                      }
                    }
                  }
                }
              }
              .reply-box {
                width: 1190px;
                border: 1px solid #c99f4f;
                padding: 15px 10px 10px;
                .reply-info {
                  border-bottom: 1px dashed rgba(238, 238, 238, 1);
                  padding-bottom: 10px;
                  display: flex;
                  > .left {
                    width: 53px;
                    display: inline-block;
                    padding-left: 6px;
                    font-size: 14px;
                    > span {
                      position: relative;
                      &.underline::before {
                        content: "";
                        position: absolute;
                        bottom: -3px;
                        left: -6px;
                        width: 36px;
                        height: 7px;
                        background: rgba(201, 159, 79, 0.7);
                        opacity: 1;
                      }
                    }
                  }
                  > .right {
                    width: calc(100% - 53px);
                    display: inline-block;
                    margin-left: -10px;
                    vertical-align: text-top;
                  }
                }
                .quiz {
                  justify-content: space-between;
                  color: #888;
                  display: flex;
                  .annex {
                    flex: 1;
                    margin: 10px 0 0px;
                    font-size: 12px;
                    color: #444;
                    display: flex;
                    line-height: 17px;
                    .annex-file {
                      margin: 0 10px 6px 0;
                      &:last-child {
                        margin-bottom: 0;
                      }
                    }
                    > span {
                      &.hand.blue {
                        margin-left: 6px;
                      }
                    }
                  }
                  > .grey {
                    margin-top: 10px;
                    flex: 1;
                    text-align: right;
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
</style>
