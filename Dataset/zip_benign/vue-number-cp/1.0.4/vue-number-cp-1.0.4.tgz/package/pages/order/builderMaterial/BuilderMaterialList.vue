<template>
    <div>
        <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
        <div class="clearfloat panel-content panel-opt">
            <label class="file-upload-input" for="material-file">
                <input id="material-file" ref="fileInput" type="file" @change="handleChangeFile" />
                <i v-if="!fileName">请导入从平台下载的要料清单模板为基础，由施工方已完善填写的《施工方要料申请单》,格式为xlsm</i>
                <span v-if="fileName">{{fileName}}</span>
            </label>
            <label for="material-file" class="fl file-upload-btn">选择要料清单</label>
            <el-button style="width:100px;margin-left:5px" class="fl" type="primary" @click="handleUploadPlan">上传</el-button>
            <el-button style="width:150px" class="fl" @click="handleDownloadTemp">下载要料清单模版</el-button>
        </div>
        <div class="panel-content">
            <el-form class="form" :model="form" size="small" label-width="75px">
                <el-row>
                    <el-col :span="8">
                        <el-form-item label="施工单位">
                            <el-input v-model="form.applicantCorpName" placeholder="请输入施工单位"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24" class="tc">
                        <el-button type="primary" size="small" @click="handleSearch">搜索</el-button>
                        <el-button size="small" @click="handleClear">清除</el-button>
                    </el-col>
                </el-row>
            </el-form>
        </div>

        <div class="product-table">
            <table>
                <thead>
                    <tr>
                        <td width="150" class="pointer" @click="handleSort(0)">要求到货时间
                            <i class="el-icon-d-caret" v-if="sortList[0]==0"></i>
                            <i class="el-icon-caret-top active" v-if="sortList[0]==1"></i>
                            <i class="el-icon-caret-bottom active" v-if="sortList[0]==2"></i>
                        </td>
                        <td>施工单位</td>
                        <td>材料类别</td>
                        <td width="100">操作</td>
                    </tr>
                </thead>
                <tbody v-if="planList.length">
                    <tr v-for="(row,index) in planList" :key="index">
                        <td>{{row.requireDt|date}}</td>
                        <td>{{row.applicantCorpName}}
                            <div>
                                <el-popover popper-class="dark-popover" trigger="click" placement="right-end">
                                    <div class="price-popover">
                                        <div>
                                            <p>{{row.applyCustName}}</p>
                                            <p>{{row.applyCustMobile}}</p>
                                        </div>
                                    </div>
                                    <i slot="reference" class="el-icon-phone blue price-tip"></i>
                                </el-popover>
                            </div>
                        </td>
                        <td>{{row.categoryName}}</td>
                        <td>
                            <MaterialOperate :material="row" @refresh="handleRefresh"></MaterialOperate>
                        </td>
                    </tr>
                </tbody>
            </table>

            <div class="table-pagination" v-if="planList.length">
                <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                </el-pagination>
            </div>

            <!-- 空列表 -->
            <div class="product-empty" v-if="!planList.length&&!isLoading">
                <img src="@/assets/images/icon-no-product.png">
                <p>没有搜索到相关计划，请重新修改搜索条件搜索！</p>
            </div>
        </div>

        <!-- 下载最新模版提示 -->
        <MaterialTempDialog ref="materialTemp" @close="handleCloseMaterialTemp"></MaterialTempDialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import MaterialOperate from "@/components/order/builderMaterial/BuilderMaterialListOperate";
import MaterialTempDialog from "@/components/order/builderMaterial/MaterialTemplateDialog";
import { InterfaceService } from "@/services/api";
import file2md5 from "@/utils/file2md5";

const form = {
    applyStatus: "",
    applicantCorpName: "",
    sort: "",
    pageIndex: 1,
    pageSize: 10
};

export default {
    mixins: [accountMixin],
    components: {
        Loading,
        PanelTitle,
        MaterialOperate,
        MaterialTempDialog
    },
    data() {
        return {
            isLoading: false,
            tab: {},
            tabs: [
                {
                    label: "待处理",
                    index: 1,
                    status: "APPLY,PART_SUBMIT",
                    active: true
                },
                { label: "已完成", index: 2, status: "TOTAL_SUBMIT" }
            ],
            form: Object.assign({}, form),
            sortList: [0],
            planList: [],
            total: 0,
            tempUrl: "",
            fileName: "",
            materialFile: null,
            materialFileUrl: null,
            materialFileMd5: null
        };
    },
    methods: {
        handleChangeTab(tab) {
            this.tab = tab;
            this.form.pageIndex = 1;
            this.getList();
        },
        handleSearch() {
            this.getList();
        },
        handleClear() {
            this.form = Object.assign({}, form);
        },
        handleChangeFile(e) {
            const file = e.target.files[0];
            const fileType = file.name.split(".")[1];
            if (fileType === "xlsm") {
                this.fileName = file.name;
                this.materialFile = file;
            } else {
                this.$message.error("请上传xlsm格式文件");
            }
        },
        // 上传清单
        handleUploadPlan() {
            if (this.materialFile) {
                this.isLoading = true;
                file2md5(this.materialFile).then(md5 => {
                    this.uploadContractToOss().then(url => {
                        this.materialFileUrl = url;
                        this.materialFileMd5 = md5;
                        this.uploadFile(url, md5);
                    });
                });
            } else {
                this.$message.error("请导入要料清单");
            }
        },
        // 下载模版
        handleDownloadTemp() {
            this.downloadTemp();
        },
        // 分页跳转
        handleCurrentChange(page) {
            this.form.pageIndex = page;
            this.getList();
            window.scrollTo(0,0)
        },
        // 排序
        handleSort(index) {
            let arr = [].concat(this.sortList);
            this.sortList.forEach((item, i) => {
                if (index == i) {
                    if (item == 0) {
                        arr[i] = 2;
                    } else if (item == 2) {
                        arr[i] = 1;
                    } else {
                        arr[i] = 0;
                    }
                } else {
                    arr[i] = 0;
                }
            });
            this.sortList = arr;
            this.getList();
        },
        // 下载最新模版
        handleCloseMaterialTemp(type) {
            if (type === "download") {
                this.downloadTemp();
            } else if (type === "upload") {
                this.uploadFile(this.materialFileUrl, this.materialFileMd5, 1);
            }
        },
        // 刷新列表
        handleRefresh() {
            this.form.pageIndex = 1;
            this.getList();
        },
        uploadHander(data, pos, file, dirName, callBack) {
            InterfaceService.uploadToOss(data, file, dirName, pos, callBack);
        },
        fillZero(val) {
            return val <= 9 ? "0" + val : val;
        },
        // 文件上传到oss
        uploadContractToOss() {
            return new Promise((resolve, reject) => {
                //去后端拿签名
                InterfaceService.getOssSignature(
                    { type: "3" },
                    data => {
                        const now = new Date();
                        const date = {
                            y: now.getFullYear(),
                            m: this.fillZero(now.getMonth() + 1),
                            d: this.fillZero(now.getDate()),
                            h: this.fillZero(now.getHours()),
                            i: this.fillZero(now.getMinutes()),
                            s: this.fillZero(now.getSeconds())
                        };
                        let dirName = `${date.y}${date.m}${date.d}${date.h}${
                            date.i
                        }${date.s}/`;
                        this.uploadHander(
                            data,
                            1,
                            this.materialFile,
                            dirName,
                            (pos, file, dir, signature) => {
                                let u = signature.dir + dir + file.name;
                                resolve(u);
                            }
                        );
                    },
                    data => {}
                );
            });
        },
        // 上传清单
        uploadFile(url, md5, flg) {
            const params = {
                fileUrl: url,
                fileMd5Code: md5
            };
            if (flg) {
                params.confirmFlg = 1;
            }
            InterfaceService.uploadMaterialFile(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        const errorList = data.respData.errorMsgList || [];
                        const warningList = data.respData.warningMsgList || [];
                        // 无错误无警告
                        if (!errorList.length && !warningList.length) {
                            this.$message.success("上传成功");
                            this.getList();
                        } else if (errorList.length) {
                            this.$refs["materialTemp"].open("error", errorList);
                        } else if (warningList.length) {
                            this.$refs["materialTemp"].open(
                                "warning",
                                warningList
                            );
                        }
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                    this.$refs.fileInput.value = ''
                    this.fileName = "";
                    this.materialFile = null;
                    // this.materialFileUrl = null;
                    // this.materialFileMd5 = null;
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        // 下载模版
        downloadTemp() {
            if (!this.tempUrl || this.tempUrl.indexOf("upload") === -1) {
                this.$message.info("未找到要料清单模版，请先下单签章后下载");
                return;
            }
            let name = this.tempUrl.split("?")[0];
            name = name.split("/").pop();
            const files = [
                { name: decodeURIComponent(name), url: this.tempUrl }
            ];
            this.$download(files).then(() => {
                this.$message.success("已下载");
            });
        },
        getList() {
            this.form.applyStatus = this.tab.status;
            const params = {};
            for (let i in this.form) {
                if (this.form[i]) {
                    params[i] = this.form[i];
                }
            }
            params.purchaserCorpId = this.userinfo.corpId;
            params.sort = this.sortList.join("_");
            InterfaceService.getBuilderMaterialApplyList(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.planList = data.respData.peMaterialApplyList || [];
                        this.total = data.respData.totalCount;
                        this.form.pageSize = data.respData.pageSize;
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        getTempUrl() {
            InterfaceService.getBuilderMaterialTempUrl(
                {},
                data => {
                    if (data.respData.respCode === "0000") {
                        this.tempUrl = data.respData.attachUrl;
                    } else if (data.respData.respCode === "TRANS0132") {
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    },
    mounted() {
        this.tab = this.tabs.filter(item => {
            return item.active;
        })[0];
        this.getList();
        this.getTempUrl();
    }
};
</script>

<style lang="scss" scoped>
    .pointer {
        cursor: pointer;
    }

    .panel-content {
        margin-bottom: 20px;
        padding: 20px 10px;
        background: #f5f5f5;
    }

    .panel-opt {
        /deep/ .el-input {
            width: 600px;
        }

        /deep/ .el-button + .el-button {
            margin-left: 5px;
        }
    }

    .product-table {
        /deep/ .el-table__body-wrapper {
            font-size: 12px;
        }

        /deep/ .el-table th,
        .el-table td {
            padding: 14px 0;
        }

        /deep/ .el-button {
            font-size: 12px;
        }

        table {
            width: 100%;
            line-height: 23px;
            font-size: 12px;
            td {
                padding: 14px 10px;
                vertical-align: middle;
                word-break: break-word;
            }

            thead {
                font-size: 14px;
                text-align: center;
                white-space: nowrap;
                color: #909399;
                background: #f5f5f5;
            }

            .tbody-row:hover {
                background: #e8f3fd;
            }

            tbody {
                text-align: center;

                tr {
                    &.sign-content {
                        display: none;
                        background: #f0f8ff;

                        &:hover {
                            display: table-row;
                        }

                        td {
                            padding: 0;
                            border-bottom: none;
                        }
                    }

                    &.all-check {
                        text-align: left;

                        &:hover {
                            background: #ffffff;
                        }
                    }
                }

                tr:hover + tr.sign-content {
                    display: table-row;
                }

                td {
                    border-bottom: 1px solid #ebeef5;
                }
            }
        }
    }

    .product-empty {
        padding: 150px;
        text-align: center;
        line-height: 50px;
        color: #909399;
    }

    .price-popover {
        display: flex;
        color: #ababac;

        > div:first-child {
            margin-right: 10px;
        }

        p:first-child {
            padding: 0 5px;
            border-left: 3px solid #ffd64e;
            line-height: 15px;
        }

        p:last-child {
            margin-top: 10px;
            color: #ffffff;
        }
    }

    .price-tip {
        cursor: pointer;
        color: #0082ff;
    }

    .table-pagination {
        margin: 50px 0 80px;
        text-align: center;
        color: #888888;
    }

    .file-upload-input {
        float: left;
        display: inline-block;
        position: relative;
        width: 550px;
        padding: 12px 5px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        font-size: 12px;
        border: 1px solid #dcdfe6;
        cursor: pointer;
        line-height: 14px;
        background: #ffffff;

        input {
            position: absolute;
            width: 0;
            height: 0;
            opacity: 0;
        }

        i {
            color: #cccccc;
        }

        span {
            color: #444444;
        }
    }

    .file-upload-btn {
        display: inline-block;
        line-height: 1;
        white-space: nowrap;
        cursor: pointer;
        width: 120px;
        text-align: center;
        box-sizing: border-box;
        outline: none;
        margin: 0;
        padding: 12px 20px;
        font-size: 14px;
        transition: 0.1s;
        font-weight: 500;
        border: 1px solid #dcdfe6;
        background-color: #ffd64e;
        border-color: #ffd64e;

        &:hover {
            color: #000000;
            background-color: #f3c52f;
        }
    }
</style>
