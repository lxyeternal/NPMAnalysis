<!--suppress ALL -->
<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <SearchBar :search-type="5" :progress="'创建请款审批'" :is-border-bottom="true"
                   :product-create-process="2"></SearchBar>
        <div class="inner-container">
            <div class="borkerApprovalPrint">
                <div class="head">
                    <div class="body">
                        <el-form ref="approvalInfo" :model="approvalInfo" :rules="approvalRules" label-width="0" size="small" :inline-message="true">
                            <table width="100%" border="0" cellpadding="0" cellspacing="1">
                                <tr>
                                    <td w4 class="title">
                                        <em class="red">*</em>请款主题
                                    </td>
                                    <td w20 colspan="3">
                                        <el-form-item prop="applyTheme">
                                            <el-input placeholder="请输入请款主题，例如：《绿地香港上海五里桥111地块111期111桩基类供应合同》+第N笔+请款事由+请款"  v-model="approvalInfo.applyTheme"></el-input>
                                        </el-form-item>
                                    </td>
                                </tr>
                            </table>
                            <table class="mt0" width="100%" border="0" cellpadding="0" cellspacing="1">
                                <tr>
                                    <td w4 class="title">
                                        <em class="red">*</em>申请人
                                    </td>
                                    <td w8>
                                        <el-input v-model="approvalInfo.signAcctName" disabled></el-input>
                                    </td>
                                    <td w4 class="title">
                                        <em class="red">*</em>部门
                                    </td>
                                    <td w8>
                                        <el-input v-model="approvalInfo.department" disabled></el-input>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title">
                                        <em class="red">*</em>申请日期
                                    </td>
                                    <td w8>
                                        <el-input v-model="approvalInfo.applyTime" disabled></el-input>
                                    </td>
                                </tr>
                            </table>
                            <table width="100%" border="0" cellpadding="0" cellspacing="1">
                                <tr>
                                    <td w4 class="title" >
                                        城市公司
                                    </td>
                                    <td w8>
                                        <el-form-item prop="cityCompany">
                                            <!--<el-select  :disabled="selectDisabled" filterable allow-create default-first-option @change="handleChangeCity($event)" placeholder="请输入城市公司" v-model="approvalInfo.cityCompany" clearable>-->
                                            <el-select filterable allow-create default-first-option @change="handleChangeCity($event)" placeholder="请输入城市公司" v-model="approvalInfo.cityCompany" clearable>
                                                <el-option v-for="(item,index) in cityCompanyList" :value="item.cityCompany" :key="index"></el-option>
                                            </el-select>
                                        </el-form-item>
                                    </td>
                                    <td w4 class="title">
                                        <em class="red">*</em>项目名称
                                    </td>
                                    <td w8>
                                        <el-form-item prop="projectName">
                                            <!--<el-select :disabled="selectDisabled" filterable allow-create default-first-option @change="handleChangeProject($event)" placeholder="请输入项目名称" v-model="approvalInfo.projectName" clearable>-->
                                            <el-select filterable allow-create default-first-option @change="handleChangeProject($event)" placeholder="请输入项目名称" v-model="approvalInfo.projectName" clearable>
                                                <el-option v-for="(item,index) in projectList" :label="item.projectName" :value="item.projectName" :key="index"></el-option>
                                            </el-select>
                                        </el-form-item>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title">
                                        <em class="red">*</em>合同名称
                                    </td>
                                    <td w20 colspan="3">
                                        <el-form-item prop="contractName">
                                            <!--<el-select  :disabled="selectDisabled" @change="handleChangeContract($event)" filterable allow-create default-first-option placeholder="请输入关键词检索合同名称或直接输入完整合同名称" v-model="approvalInfo.contractName" clearable>-->
                                            <el-select @change="handleChangeContract($event)" filterable allow-create default-first-option placeholder="请输入关键词检索合同名称或直接输入完整合同名称" v-model="approvalInfo.contractName" clearable>
                                                <el-option v-for="(item,index) in contractNameList" :label="item.contractName" :value="item.orderNo" :key="index.orderNo"></el-option>
                                            </el-select>
                                        </el-form-item>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title">
                                        <em class="red">*</em>合同编号
                                    </td>
                                    <td w8 :class="{'bg-ddd':orderDisabled}">
                                        <el-form-item prop="orderNo">
                                            <el-input :disabled="orderDisabled" placeholder="请输入合同编号" v-model="approvalInfo.orderNo"></el-input>
                                            <!--<el-input placeholder="请输入合同编号" v-model="approvalInfo.orderNo"></el-input>-->
                                        </el-form-item>
                                    </td>
                                    <td w4 class="title">
                                        <em class="red">*</em>合同类别
                                    </td>
                                    <td w8>
                                        <el-form-item prop="contractCategories">
                                            <el-select placeholder="请选择合同类别" v-model="approvalInfo.contractCategories" clearable>
                                                <el-option v-for="(item,index) in contractCategoriesList" :value="item" :key="index"></el-option>
                                            </el-select>
                                        </el-form-item>
                                    </td>
                                </tr>
                            </table>
                            <table class="mt0" width="100%" border="0" cellpadding="0" cellspacing="1">
                                <tr>
                                    <td w4 class="title">
                                        合同价款(不含税)
                                    </td>
                                    <td w8 :class="{'bg-ddd':orderDisabled}">
                                        <el-form-item prop="outContractFee">
                                            <el-input placeholder="请输入合同价款(不含税)" :disabled="orderDisabled" v-model="approvalInfo.outContractFee" class="money"></el-input>元
                                            <!--<el-input placeholder="请输入合同价款(不含税)" v-model="approvalInfo.outContractFee" class="money"></el-input>元-->
                                        </el-form-item>
                                    </td>
                                    <td w4 class="title">
                                        税率
                                    </td>
                                    <td w8 :class="{'bg-ddd':orderDisabled}">
                                        <el-form-item prop="taxRate">
                                            <el-input @blur="validateRate($event)" :disabled="orderDisabled" placeholder="请输入税率" v-model="approvalInfo.taxRate" maxlength="10"></el-input>
                                            <!--<el-input @blur="validateRate($event)" placeholder="请输入税率" v-model="approvalInfo.taxRate" maxlength="10"></el-input>-->
                                        </el-form-item>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title">
                                        <em class="red">*</em>合同价款(税后)
                                    </td>
                                    <td w8 :class="{'bg-ddd':orderDisabled}">
                                        <el-form-item prop="outContractFeeWithTax">
                                            <el-input placeholder="请输入合同价款(税后)"  :disabled="orderDisabled" v-model="approvalInfo.outContractFeeWithTax" class="money"></el-input>元
                                            <!--<el-input placeholder="请输入合同价款(税后)"  v-model="approvalInfo.outContractFeeWithTax" class="money"></el-input>元-->
                                        </el-form-item>
                                    </td>
                                    <td w4 class="title">
                                        税额
                                    </td>
                                    <td w8 :class="{'bg-ddd':orderDisabled}">
                                        <el-form-item prop="outContractTax">
                                            <el-input placeholder="请输入税额"  :disabled="orderDisabled" v-model="approvalInfo.outContractTax" class="money"></el-input>元
                                            <!--<el-input placeholder="请输入税额" v-model="approvalInfo.outContractTax" class="money"></el-input>元-->
                                        </el-form-item>
                                    </td>
                                </tr>
                            </table>
                        </el-form>
                        <el-form ref="supplierForm" :model="supplierForm" :rules="supplierRules" label-width="0" size="small" :inline-message="true">
                            <table width="100%" border="0" cellpadding="0" cellspacing="1" style="border-top: none">
                                <tr h0>
                                    <td w4 class="title">
                                    </td>
                                    <td w8>
                                    </td>
                                    <td w4 class="title">
                                    </td>
                                    <td w8>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title" style="border-top: 1px solid #bbb">
                                        付款单位
                                    </td>
                                    <td w8 style="border-top: 1px solid #bbb">
                                        <el-form-item prop="pmtCorpName">
                                            <el-input placeholder="请输入付款单位" v-model="supplierForm.pmtCorpName" maxlength="128"></el-input>
                                        </el-form-item>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title">
                                        <em class="red">*</em>供应商开户名称
                                    </td>
                                    <td w8>
                                        <el-form-item prop="acctName">
                                            <el-input placeholder="请输入供应商开户名称" v-model="supplierForm.acctName" maxlength="128"></el-input>
                                        </el-form-item>
                                    </td>
                                    <td w4 class="title" style="border-top: 1px solid #bbb">
                                        <em class="red">*</em>供应商开户银行
                                    </td>
                                    <td w8 style="border-top: 1px solid #bbb">
                                        <el-form-item prop="bankName">
                                            <el-input placeholder="请输入供应商开户银行" v-model="supplierForm.bankName" maxlength="128"></el-input>
                                        </el-form-item>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title">
                                        供应商开户行地址
                                    </td>
                                    <td w8>
                                        <el-form-item prop="bankAddr">
                                            <el-input placeholder="请输入供应商开户行地址" v-model="supplierForm.bankAddr" maxlength="128"></el-input>
                                        </el-form-item>
                                    </td>
                                    <td w4 class="title">
                                        供应商开户行行号
                                    </td>
                                    <td w8>
                                        <el-form-item prop="bankCode">
                                            <el-input placeholder="请输入供应商开户行行号" @blur="formatCard('bankCode',$event)" v-model="supplierForm.bankCode" maxlength="15"></el-input>
                                        </el-form-item>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title">
                                        <em class="red">*</em>供应商银行账号
                                    </td>
                                    <td w8>
                                        <el-form-item prop="bankAcct">
                                            <el-input placeholder="请输入供应商银行账号" @blur="formatCard('bankAcct',$event)" v-model="supplierForm.bankAcct" maxlength="30"></el-input>
                                        </el-form-item>
                                    </td>
                                    <td w4 class="title">
                                        供应商纳税人识别号
                                    </td>
                                    <td w8>
                                        <el-form-item prop="taxPayId">
                                            <el-input placeholder="请输入供应商纳税人识别号" v-model="supplierForm.taxPayId" maxlength="38"></el-input>
                                        </el-form-item>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title">
                                        <em class="red">*</em>供应商联系人
                                    </td>
                                    <td w8>
                                        <el-form-item prop="contact">
                                            <el-input placeholder="请输入供应商联系人" v-model="supplierForm.contact" maxlength="32"></el-input>
                                        </el-form-item>
                                    </td>
                                    <td w4 class="title">
                                        <em class="red">*</em>供应商联系方式
                                    </td>
                                    <td w8>
                                        <el-form-item prop="phoneNo">
                                            <el-input placeholder="请输入供应商联系方式" v-model="supplierForm.phoneNo" maxlength="30"></el-input>
                                        </el-form-item>
                                    </td>
                                </tr>
                            </table>
                        </el-form>
                        <el-form ref="paymentForm" :model="paymentForm" :rules="paymentRules" label-width="0" size="small" :inline-message="true">
                            <table width="100%" border="0" cellpadding="0" cellspacing="1" style="border-top: none">
                                <tr h0>
                                    <td w4 class="title">
                                    </td>
                                    <td w8>
                                    </td>
                                    <td w4 class="title">
                                    </td>
                                    <td w8>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title bt">
                                        <em class="red">*</em>付款事由
                                    </td>
                                    <td w8 class="bt">
                                        <el-form-item  prop="paymentType">
                                            <el-select placeholder="请选择付款事由" @change="handleChangePt" v-model="paymentForm.paymentType" clearable >
                                                <el-option v-for="(item,index) in paymentTypeList" :value="item" :key="index"></el-option>
                                            </el-select>
                                        </el-form-item>
                                    </td>
                                    <td w4 class="title bt">
                                        <em class="red" v-if="paymentForm.paymentType === '结算款'">*</em>合同结算金额
                                    </td>
                                    <td w8 class="bt">
                                        <el-form-item prop="orderAuditAmt" ref="orderAuditAmt">
                                            <el-input placeholder="请输入合同结算金额" v-model="paymentForm.orderAuditAmt" class="money" maxlength="15"></el-input>元
                                        </el-form-item>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title">付款条款</td>
                                    <td w20 colspan="3">
                                        <el-form-item prop="pmtMethod">
                                            <el-input placeholder="请输入付款条款"
                                                      rows="4"
                                                      type="textarea"
                                                      maxlength="600" v-model="paymentForm.pmtMethod"></el-input>
                                        </el-form-item>
                                    </td>
                                </tr>
                            </table>
                            <table class="mt0" width="100%" border="0" cellpadding="0" cellspacing="1">
                                <tr>
                                    <td w4 class="title">
                                        本期产值
                                    </td>
                                    <td w8>
                                        <el-form-item prop="thisOutputValue">
                                            <el-input placeholder="请输入本期产值" v-model="paymentForm.thisOutputValue" class="money" maxlength="15"></el-input>元
                                        </el-form-item>
                                    </td>
                                    <td w4 class="title">
                                        <em class="red">*</em>累计完成产值
                                    </td>
                                    <td w8>
                                        <el-form-item prop="totalOutputValue">
                                            <el-input placeholder="请输入累计完成产值" v-model="paymentForm.totalOutputValue" class="money" maxlength="15"></el-input>元
                                        </el-form-item>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title">
                                        <em class="red">*</em>累计已付
                                    </td>
                                    <td w8>
                                        <el-form-item prop="totalPaidAmt">
                                            <el-input @input="handleComputed($event,'totalPaidAmt')"  placeholder="请输入累计已付" v-model="paymentForm.totalPaidAmt" class="money" maxlength="15"></el-input>元
                                        </el-form-item>
                                    </td>
                                    <td w4 class="title">
                                        <em class="red">*</em>累计应付
                                    </td>
                                    <td w8>
                                        <el-form-item prop="totalPayablesAmt">
                                            <el-input @input="handleComputed($event,'totalPayablesAmt')" placeholder="请输入累计应付" v-model="paymentForm.totalPayablesAmt" class="money" maxlength="15"></el-input>元
                                        </el-form-item>
                                    </td>
                                </tr>
                                <tr>
                                    <td w4 class="title">
                                        累计应付未付款
                                    </td>
                                    <td w8 style="background: #ddd;">
                                        <el-form-item prop="totalPayableAmt">
                                            <el-input disabled placeholder="请计算累计应付未付款" v-model="paymentForm.totalPayableAmt" class="money" maxlength="15"></el-input>元
                                        </el-form-item>
                                    </td>
                                    <td w4 class="title bold">
                                        <em class="red">*</em>本次申请金额
                                    </td>
                                    <td w8>
                                        <el-form-item prop="payablesAmtApply">
                                            <el-input @input="handleComputed($event,'payablesAmtApply')" placeholder="请输入本次申请金额" v-model="paymentForm.payablesAmtApply" class="money" maxlength="15"></el-input>元
                                        </el-form-item>
                                    </td>
                                </tr>
                            </table>
                        </el-form>
                        <!--<el-form ref="invoiceForm" :model="invoiceForm" :rules="invoiceRules" label-width="0" size="small" :inline-message="true">-->
                            <!--<table width="100%" border="0" cellpadding="0" cellspacing="1">-->
                                <!--<tr>-->
                                    <!--<td w4 class="title">-->
                                        <!--本次发票金额-->
                                    <!--</td>-->
                                    <!--<td w8>-->
                                        <!--<el-form-item prop="thisReceiptAmt">-->
                                            <!--<el-input placeholder="请输入本次发票金额" v-model="invoiceForm.thisReceiptAmt" class="money" maxlength="15"></el-input>元-->
                                        <!--</el-form-item>-->
                                    <!--</td>-->
                                    <!--<td w4 class="title">-->
                                        <!--累计发票金额-->
                                    <!--</td>-->
                                    <!--<td w8>-->
                                        <!--<el-form-item prop="totalReceiptAmt">-->
                                            <!--<el-input placeholder="请输入累计发票金额" v-model="invoiceForm.totalReceiptAmt" class="money" maxlength="15"></el-input>元-->
                                        <!--</el-form-item>-->
                                    <!--</td>-->
                                <!--</tr>-->
                            <!--</table>-->
                        <!--</el-form>-->
                    </div>
                </div>
            </div>
            <BrokerPaymentApproval ref="brokerPaymentApproval" @refresh="refresh"></BrokerPaymentApproval>
            <PaymentDataUpload :clearFiles="clearFiles" :orderNo="approvalInfo.orderNo" :execAttachList="execAttachList" :executionId="approvalInfo.executionId" @uplode="handleUpload"></PaymentDataUpload>
        </div>
        <FixBottom>
            <div class="fix-bottom tc">
                <el-button type="primary" style="width: 120px;" @click="handleConfirm()">提交审批</el-button>
                <el-button style="width: 120px;" @click="submitWarn('draft')">保存草稿</el-button>
                <el-button style="width: 120px" @click="$router.go(-1)">返回列表</el-button>
            </div>
        </FixBottom>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>
<script>
    import SearchBar from "@/components/SearchBar";
    import Header from "@/components/base/Header";
    import {InterfaceService} from "@/services/api";
    import FixBottom from "@/components/base/FixBottom";
    import Loading from "@/components/base/Loading";
    import PaymentDataUpload from "@/components/order/broker/PaymentDataUpload";
    import { MoneyUtil } from '@/utils/moneyUtil';
    import {calculationUtil} from '@/utils/calculationUtil';
    import BrokerPaymentApproval from "@/components/order/broker/dialog/BrokerPaymentApproval";

    const approvalInfo = {
        applyTheme:"",
        executionId:"",
        businessKey:"",
        signAcctName:"王宗水",
        department:"博置-工程部",
        applyTime:"",
        cityCompany:"",
        projectName:"",
        projectId:"",
        contractName:"",
        orderNo:"",
        contractCategories:"",
        outContractFee:"",
        taxRate:"",
        outContractFeeWithTax:"",
        outContractTax:"",
    };
    const supplierForm = {
        pmtCorpName: "上海博置实业有限公司",
        acctName: "",
        bankName: "",
        bankAcct: "",
        taxPayId: "",
        bankAddr: "",
        bankCode: "",
        contact: "",
        phoneNo: ""
    };
    const paymentForm = {
        payablesAmtApply: "",
        orderAuditAmt: "",
        pmtMethod: "",
        paymentType: "",
        totalPayablesAmt: "",
        totalOutputValue: "",
        totalPaidAmt: "",
        thisOutputValue: "",
        totalPayableAmt: "",
    };
    const invoiceForm = {
        thisReceiptAmt: "",
        totalReceiptAmt: "",
    };

    export default {
        components: {
            Header,
            SearchBar,
            FixBottom,
            Loading,
            PaymentDataUpload,
            BrokerPaymentApproval,
        },
        data() {
            const validateMoney = (rule, value, callback) => {
                const reg = new RegExp(/^[-]{0,1}(\d+)$|^[-]{0,1}(\d+\.\d+)$/);
                if ((value&&!reg.test(value) ||
                    (!value && (((this.paymentForm.paymentType === "结算款" && rule.fullField !== "thisOutputValue"))
                    ||this.paymentForm.paymentType !== "结算款" && rule.fullField !== "thisOutputValue" && rule.fullField !== "orderAuditAmt")))) {
                    return callback(new Error("金额填写有误，请确认后重新输入"));
                } else {
                    callback();
                }
            };
            const validateContractMoney = (rule, value, callback) => {
                const reg = new RegExp(/^[+]{0,1}(\d+)$|^[+]{0,1}(\d+\.\d+)$/);
                if ((value && (!reg.test(value) || +value <= 0)) || (!value && (rule.fullField === "outContractFeeWithTax" ))) {
                    return callback(new Error("金额填写有误，请确认后重新输入"));
                } else {
                    callback();
                }
            };
            const validateTotalPayableAmt = (rule, value, callback) => {
                if (+value < 0 && this.paymentForm.paymentType === "结算款") {
                    return callback(new Error("累计应付未付款计算有误，请重新计算"));
                } else {
                    callback();
                }
            };
            const validateBankAcctNo = (rule, value, callback) => {
                value = value && value.replace(/\s+/g, "");
                const reg = new RegExp(/^[0-9_-]{0,30}$/);
                if (!reg.test(value)) {
                    return callback(new Error("银行账号格式错误，必须为数字"));
                } else {
                    callback();
                }
            };
            const validateTaxPayer = (rule, value, callback) => {
                value = value && value.replace(/\s+/g, "");
                const reg = new RegExp(/^[0-9a-zA-Z]{15,20}$/);
                if (value && !reg.test(value)) {
                    return callback(new Error("识别号格式错误，15到20位字母或数字"));
                } else {
                    callback();
                }
            };
            const validateMobile = (rule, value, callback) => {
                const reg = new RegExp(/^[1][0-9][0-9]{9}$/);                    // 手机
                const reg1 = new RegExp(/^((0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/); // 座机
                if (!reg.test(value) && !reg1.test(value)) {
                    return callback(new Error("联系电话格式错误，请填写手机号或座机"));
                } else {
                    callback();
                }
            };
            const validateBankCode = (rule, value, callback) => {
                value = value && value.replace(/\s+/g, "");
                const reg = new RegExp(/^[0-9]{12}$/);
                if (value && !reg.test(value)) {
                    return callback(new Error("银行行号有误，请填写12位数字"));
                } else {
                    callback();
                }
            };
            const validateSupplierInfo = (rule, value, callback) => {
                if (!value) {
                    return callback(new Error("信息填写有误，请输入内容"));
                } else {
                    callback();
                }
            };
            return {
                data: [],
                formArr: [
                    'approvalInfo', 'paymentForm', 'supplierForm',
                ],
                resultArr: [], //接受验证返回结果数组
                //表单验证错误提示
                rejectObj: '信息填写有误或不完整，请重新检查！',
                isLoading: false,
                clearFiles: false,
                orderDisabled: false,
                selectDisabled: false,
                themeDisabled: false,
                hasContractName: true,
                executionId: "",
                type: "",
                approvalInfo: Object.assign({},approvalInfo),
                paymentForm: Object.assign({},paymentForm),
                invoiceForm: Object.assign({},invoiceForm),
                supplierForm: Object.assign({},supplierForm),
                contractCategoriesList: [
                    "土地类",
                    "顾问类",
                    "工程类",
                    "营销财务管理类",
                    "规费及其他类"
                ],
                paymentTypeList:[
                    "预付款",
                    "进度款",
                    "结算款",
                    "质保金",
                ],
                cityCompanyList:[],
                projectList:[],
                execAttachList:[],
                attachList:[],
                contractNameList:[],
                approvalRules: {
                    applyTheme: [
                        {
                            required: true,
                            message: "请输入请款主题"
                        },
                        { validator: validateSupplierInfo, trigger: "blur" }
                    ],
                    orderNo: [
                        {
                            required: true,
                            message: "请输入合同编号"
                        },
                        { validator: validateSupplierInfo, trigger: "blur" }
                    ],
                    contractName: [
                        {
                            required: true,
                            message: "请选择合同名称"
                        },
                        { validator: validateSupplierInfo, trigger: "change" }
                    ],
                    projectName: [
                        {
                            required: true,
                            message: "请选择项目名称"
                        },
                        { validator: validateSupplierInfo, trigger: "change" }
                    ],
                    cityCompany: [
                        {
                            // required: false,
                            message: "请选择城市公司"
                        },
                        // { validator: validateSupplierInfo, trigger: "change" }
                    ],
                    contractCategories: [
                        {
                            required: true,
                            message: "请选择合同类别"
                        },
                        { validator: validateSupplierInfo, trigger: "change" }
                    ],
                    taxRate:[
                        {
                            message: "请输入税率,且为0到1以内数字"
                        },
                        { message: "税率不得大于10个字符", trigger: "blur" }
                    ],
                    outContractFee:[
                        {
                            message: "请输入合同价款(不含税)",
                            trigger: "blur"
                        },
                        { validator: validateContractMoney, trigger: "blur" }
                    ],
                    outContractFeeWithTax:[
                        {
                            required: true,
                            message: "请输入合同价款(税后)",
                            trigger: "blur"
                        },
                        { validator: validateContractMoney, trigger: "blur" }
                    ],
                    outContractTax:[
                        {
                            message: "请输入税额",
                            trigger: "blur"
                        },
                        { validator: validateContractMoney, trigger: "blur" }
                    ]
                },
                supplierRules: {
                    acctName: [
                        {
                            required: true,
                            message: "请输入供应商开户名称",
                            trigger: "blur"
                        },
                        { validator: validateSupplierInfo, trigger: "blur" }
                    ],
                    pmtCorpName: [
                        {
                            message: "请输入付款单位",
                        },
                    ],
                    bankName: [
                        {
                            required: true,
                            message: "请输入开户银行",
                            trigger: "blur"
                        },
                        { validator: validateSupplierInfo, trigger: "blur" }
                    ],
                    bankAcct: [
                        {
                            required: true,
                            message: "请输入银行账号",
                            trigger: "blur"
                        },
                        { validator: validateBankAcctNo, trigger: "blur" }
                    ],
                    taxPayId: [
                        {
                            message: "请输入纳税人识别号",
                            trigger: "blur"
                        },
                        { validator: validateTaxPayer, trigger: "blur" }
                    ],
                    cityCode: [
                        {
                            message: "请选择地址信息"
                        },
                        // { validator: validateSupplierInfo, trigger: "blur" }
                    ],
                    districtCode: [
                        {
                            message: "请选择地址信息"
                        },
                        // { validator: validateSupplierInfo, trigger: "blur" }
                    ],
                    bankAddr: [
                        {
                            message: "请填写地址",
                            trigger: "blur"
                        },
                        // { validator: validateSupplierInfo, trigger: "blur" }
                    ],
                    bankCode: [
                        {
                            message: "请输入开户行行号",
                            trigger: "blur"
                        },
                        { validator: validateBankCode, trigger: "blur" }
                    ],
                    contact: [
                        {
                            required: true,
                            message: "请输入联系人", trigger: "blur"
                        },
                        { validator: validateSupplierInfo, trigger: "blur" }
                    ],
                    phoneNo: [
                        {
                            required: true,
                            message: "请输入联系电话",
                            trigger: "blur"
                        },
                        { validator: validateMobile, trigger: "blur" }
                    ]
                },
                paymentRules: {
                    paymentType: [
                        {
                            required: true,
                            message: "请选择付款事由",
                        },
                        { validator: validateSupplierInfo, trigger: "change" }
                    ],
                    orderAuditAmt: [
                        {
                            message: "请输入合同结算金额",
                            trigger: "blur"
                        },
                        { validator: validateMoney, trigger: "blur" }
                    ],
                    pmtMethod: [
                        {
                            message: "请输入付款条款",
                            trigger: "blur"
                        },
                        // { validator: validateSupplierInfo, trigger: "blur" }
                    ],
                    payablesAmtApply: [
                        {
                            required: true,
                            message: "请输入本次申请金额",
                            trigger: "blur"
                        },
                        { validator: validateMoney, trigger: "blur" }
                    ],
                    totalPayablesAmt: [
                        {
                            required : true,
                            message: "请输入累计应付款",
                            trigger: "blur"
                        },
                        { validator: validateMoney, trigger: "blur" }
                    ],
                    totalOutputValue: [
                        {
                            required : true,
                            message: "请输入累计完成产值",
                            trigger: "blur"
                        },
                        { validator: validateMoney, trigger: "blur" }
                    ],
                    totalPaidAmt: [
                        {
                            required : true,
                            message: "请输入累计已付款",
                            trigger: "blur"
                        },
                        { validator: validateMoney, trigger: "blur" }
                    ],
                    thisOutputValue: [
                        {
                            message: "请输入本期产值",
                            trigger: "blur"
                        },
                        { validator: validateMoney, trigger: "blur" }
                    ],
                    totalPayableAmt: [
                        { validator: validateTotalPayableAmt, trigger: "blur" }
                    ],
                },
                invoiceRules: {
                    thisReceiptAmt: [
                        {
                            message: "",
                            trigger: "blur"
                        },
                        { validator: validateMoney, trigger: "blur" }
                    ],
                    totalReceiptAmt: [
                        {
                            message: "",
                            trigger: "blur"
                        },
                        { validator: validateMoney, trigger: "blur" }
                    ],
                }
            };
        },
        computed:{
        },
        methods:{
            handleChangeCity(ev){
                this.cityCompanyList.forEach(item=>{
                    if (item.cityCompany === ev) {
                        this.projectList = item.projectList
                    }
                });
                this.approvalInfo.projectName = "";
                this.approvalInfo.projectId = "";
                this.contractNameList = [];
                this.approvalInfo.contractName = "";
                this.approvalInfo.orderNo = ""
                this.approvalInfo.outContractFee = "";
                this.approvalInfo.taxRate = "";
                this.approvalInfo.outContractFeeWithTax = "";
                this.approvalInfo.outContractTax = "";
                this.paymentForm.pmtMethod = ""
                if (!ev) {
                    this.projectList = [];
                }
            },
            handleChangePt(ev) {
                if (ev !== "结算款") {
                    this.$refs["orderAuditAmt"].$el.lastElementChild.lastChild.innerText = ""
                } else {
                    if (!this.paymentForm.orderAuditAmt) {
                        this.$refs["orderAuditAmt"].$el.lastElementChild.lastChild.innerText = "当付款事由为“结算款”时，请输入合同结算金额"
                    }
                }
            },
            //计算累计应付未付款
            handleComputed(ev,num){
                if (ev) {
                    this.paymentForm[num] = ev.replace(/,/g,'');
                    this.paymentForm.totalPayableAmt =
                        calculationUtil.sub(
                            calculationUtil.sub(this.paymentForm.totalPayablesAmt || 0,this.paymentForm.totalPaidAmt || 0), this.paymentForm.payablesAmtApply || 0
                        ) || 0;
                    this.paymentForm.totalPayableAmt =MoneyUtil.moneyFixed(this.paymentForm.totalPayableAmt,2)
                    console.log(this.paymentForm.totalPayableAmt);
                }
            },
            // 税率
            validateRate(ev) {
                // this.baseInfoForm.rate =
                //     this.baseInfoForm.rate &&
                //     this.baseInfoForm.rate.replace(/\D+/, "");
                // let value = Number(ev.target.value).toFixed(2);
                let value = ev && MoneyUtil.moneyFixed(ev.target.value,2) || "";
                if (value >= 1 || value < 0) {
                    this.approvalInfo.taxRate = ""
                } else {
                    // this.approvalInfo.taxRate = Number(value && value.replace(/\D+/, "")).toString();
                    this.approvalInfo.taxRate = value;
                    this.$forceUpdate();
                }

            },
            handleUpload(data){
                this.attachList = data || [];
            },
            handleChangeProject(ev,type){
                let projectIdList = [];
                this.projectList.forEach(item=>{
                    if (item.projectName == ev) {
                        ev && projectIdList.push(item.projectId);
                    }
                });
                projectIdList.length > 0 && InterfaceService.getPaymentConractList(
                    {
                        projectIdList : projectIdList
                    },
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.contractNameList = data.respData.contractList || []
                            this.contractNameList.forEach(item=>{
                                if (item.orderNo == this.approvalInfo.orderNo) {
                                    if (type) {
                                        this.orderDisabled = true
                                        this.selectDisabled = true
                                    }
                                }
                            })
                        }else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
                if (!type) {
                this.contractNameList = [];
                this.approvalInfo.contractName = "";
                this.approvalInfo.orderNo = ""
                this.approvalInfo.outContractFee = "";
                this.approvalInfo.taxRate = "";
                this.approvalInfo.outContractFeeWithTax = "";
                this.approvalInfo.outContractTax = "";
                    this.paymentForm.pmtMethod = ""
                }
                if (!ev) {
                    this.contractNameList = [];
                }
            },
            submitWarn(subType){
                this.approvalInfo.paymentType = this.paymentForm.paymentType || "";
                this.approvalInfo.supplierName = this.supplierForm.acctName || "";
                this.approvalInfo.pmtMethod = this.paymentForm.pmtMethod && this.paymentForm.pmtMethod.replace(/\n/g, '<br/>') || "";
                if (this.type === "init") {
                    this.approvalInfo.businessKey = "";
                }else {
                    this.approvalInfo.businessKey = this.approvalInfo.executionId;
                }
                if (subType == "draft" && (!this.approvalInfo.paymentType || !this.approvalInfo.applyTheme)) {
                    this.$message.error("请填写请款主题和付款事由！")
                    return
                }
                console.log(this.execAttachList);
                if (subType !== "draft" && (!this.attachList.length && !this.execAttachList.length)) {
                    this.$message.error("请上传审批附件")
                    return
                }
                // let str = "";
                // if (this.orderDisabled) {
                //     if (this.type == "init") {
                //         if (this.approvalInfo.contractName) {
                //             str = "保存草稿或提交审批后，该请款流程将无法修改请款主题、城市公司、项目名称及合同名称，是否继续保存或提交？"
                //         }else {
                //             str = "保存草稿后，该请款流程将无法修改请款主题，是否继续保存？"
                //         }
                //         this.$confirm(
                //             str,
                //             {
                //                 cancelButtonClass: "btn-custom-cancel",
                //                 confirmButtonClass: "btn-custom-confirm",
                //                 center: true,
                //                 type: 'warning',
                //                 confirmButtonText: "确认",
                //                 cancelButtonText: '取消',
                //             }).then(() => {
                //             this.handleSubmit(subType)
                //         }).catch(() => {
                //             this.$message({
                //                 type: 'info',
                //                 message: '已取消'
                //             });
                //         });
                //     }else {
                //         if (!this.hasContractName && this.approvalInfo.contractName) {
                //             str = "保存草稿或提交审批后，该请款流程将无法修改请款主题、城市公司、项目名称及合同名称，是否继续保存或提交？"
                //             this.$confirm(
                //                 str,
                //                 {
                //                     cancelButtonClass: "btn-custom-cancel",
                //                     confirmButtonClass: "btn-custom-confirm",
                //                     center: true,
                //                     type: 'warning',
                //                     confirmButtonText: "确认",
                //                     cancelButtonText: '取消',
                //                 }).then(() => {
                //                 this.handleSubmit(subType)
                //             }).catch(() => {
                //                 this.$message({
                //                     type: 'info',
                //                     message: '已取消'
                //                 });
                //             });
                //         }else {
                //             this.handleSubmit(subType)
                //         }
                //     }
                // }else {
                //     this.handleSubmit(subType)
                // }
                this.handleSubmit(subType)
            },
            handleSubmit(subType){
                let params = Object.assign({},this.approvalInfo);
                console.log(params);
                InterfaceService.updatePaymentInfo(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            if (this.attachList.length > 0) {
                                this.approvalDataAdd(subType);
                            }else {
                                this.editPaymentInfo(subType);
                            }
                        }else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            editPaymentInfo(subType){
                this.supplierForm.bankCode= this.supplierForm.bankCode && this.supplierForm.bankCode.replace(/\s+/g, "");
                this.supplierForm.bankAcct= this.supplierForm.bankAcct && this.supplierForm.bankAcct.replace(/\s+/g, "");
                this.arrangeParams("paymentForm");
                this.arrangeParams("invoiceForm");
                this.arrangeParams("supplierForm");
                let params = {
                    executionId : this.approvalInfo.executionId,
                    pmtBusiInfo : this.paymentForm,
                    pmtReceiptInfo : this.invoiceForm,
                    corpFinInfo : this.supplierForm,
                    orderNo : this.approvalInfo.orderNo||""
                };
                if (subType === "draft") {
                    params.isDraft = "1"
                }
                console.log(params);
                InterfaceService.approvalPaymentInfo(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            if (subType === "draft") {
                                this.$router.push({
                                    path : '/purchaserCenter/brokerPaymentList'
                                });
                                this.$message.success("草稿保存成功");
                            }else if (subType === "approval") {
                                const obj = {
                                    executionId : this.approvalInfo.executionId,
                                    procDefKey : "PMT_APPROVE_WF"
                                };
                                this.$refs["brokerPaymentApproval"].open(obj,"createPayment");
                            }
                        } else {
                            this.$message.error(data.respData.respMsg);
                            this.supplierForm.bankCode= this.supplierForm.bankCode && this.supplierForm.bankCode.replace(/(.{4})/g, "$1 ")
                            this.supplierForm.bankAcct= this.supplierForm.bankAcct && this.supplierForm.bankAcct.replace(/(.{4})/g, "$1 ")
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            arrangeParams(type){
                Object.keys(this[type]).map(key => {
                    if (this[type][key] == "") {
                        this[type][key] = null
                    }
                });
            },
            approvalDataAdd (subType){
                const params = {
                    executionId: this.approvalInfo.executionId ,
                    attachList: this.attachList,
                };
                InterfaceService.approvalDataAdd(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            // this.attachList = [];
                            this.editPaymentInfo(subType);
                            this.clearFiles = true
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            //formName 需要验证的表单  err验证不通过的提示信息
            refForm(formName, err) {
                let that = this;
                let result = new Promise(function (resolve, reject) {
                    that.$refs[formName].validate((valid) => {
                        if (valid) {
                            resolve();
                        } else {
                            reject(err)
                        }
                    })
                });
                that.resultArr.push(result)
            },
            handleConfirm() {
                this.resultArr = [];
                let that = this;
                this.formArr.forEach((item, index) => {
                    //根据表单的ref校验
                    this.refForm(item, this.rejectObj)
                });
                Promise.all(this.resultArr).then(function () {
                    that.submitWarn('approval')
                    //验证全部通过
                }).catch(function (data) {
                    //验证失败 提示reject失败状态的值
                    that.$message.error(data);
                });
            },
            handleChangeContract(ev){
                let onOff = false;
                this.orderDisabled = false
                this.contractNameList.forEach(item=>{
                    if (item.orderNo === ev) {
                        this.orderDisabled = true;
                        onOff = true;
                        this.approvalInfo = Object.assign(this.approvalInfo,item);
                        this.paymentForm.pmtMethod = item.pmtMethod && item.pmtMethod.replace(/<br\/>|<br>/g, '\n') || "";
                        this.supplierForm = Object.assign(this.supplierForm,item.corpFinInfo);
                        this.approvalInfo.taxRate = MoneyUtil.moneyFixed(this.approvalInfo.taxRate,2) || "";
                    }
                });
                if (!onOff) {
                    this.approvalInfo.orderNo = ""
                    this.approvalInfo.outContractFee = ""
                    this.approvalInfo.taxRate = ""
                    this.approvalInfo.outContractFeeWithTax = ""
                    this.approvalInfo.outContractTax = ""
                    this.paymentForm.pmtMethod = ""
                }
            },
            refresh(bool,approval) {
                if (bool) {
                    if (approval === "approval") {
                        this.$router.go(-1)
                    }else {
                        this.getApprovalDetail();
                    }
                }
            },
            formatCard(type,ev){
                this.supplierForm[type] = this.supplierForm[type] && this.supplierForm[type].replace(/\s+/g, "").replace(/(.{4})/g, "$1 ")
                if (ev && ev.target.value == "") {
                    this.supplierForm[type] = null
                }
            },
            getCityAndProject(){
                InterfaceService.getCityAndProject(
                    {},
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.cityCompanyList = data.respData.resultList || []
                        }else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            getApprovalId(){
                InterfaceService.getApprovalId(
                {
                    // EXE 流程ID采番
                    // PMT 请款单编号采番
                    type: 'EXE'
                },
                data => {
                    if (data.respData.respCode === "0000") {
                        console.log(data);
                        this.approvalInfo.executionId = data.respData.busiNo || "";
                        // this.cityCompanyList = data.respData.resultList || []
                    }else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                });
            },
            getApprovalDetail(){
                let params = {
                    executionId: this.approvalInfo.executionId,
                    procDefKey:"PMT_APPROVE_WF",
                    pageIndex: 1
                };
                InterfaceService.getApprovalDetail(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            let list = data.respData;
                            for (let key in this.approvalInfo) {
                                for (let _key in list) {
                                    if (key === _key && list[_key] !== "") {
                                        this.approvalInfo[key] = list[_key]
                                    }
                                }
                            }
                            this.type = "approval";
                            this.themeDisabled = true;
                            if (this.approvalInfo.contractName) {
                                this.hasContractName = true
                            }else {
                                this.hasContractName = false;
                            }
                            let tax = list.orderTaxRateRange && list.orderTaxRateRange.substr(0, list.orderTaxRateRange.length - 1) || "";
                            this.approvalInfo.taxRate = (tax && MoneyUtil.moneyFixed(+tax/100,2)) || "";
                            this.execAttachList = list.execAttachList || [];
                            this.supplierForm = Object.assign(this.supplierForm,list.corpFinInfo);
                            this.paymentForm = Object.assign(this.paymentForm,list.pmtBusiInfo);
                            this.paymentForm.paymentType = list.paymentType || "";
                            this.invoiceForm.thisReceiptAmt = this.paymentForm.thisReceiptAmt || "";
                            this.invoiceForm.totalReceiptAmt = this.paymentForm.totalReceiptAmt || "";
                            this.paymentForm.pmtMethod = list.pmtMethod && list.pmtMethod.replace(/<br\/>|<br>/g, '\n') || "";
                            this.cityCompanyList.forEach(item=>{
                                if (item.cityCompany === this.approvalInfo.cityCompany) {
                                    this.projectList = item.projectList || []
                                }
                            });
                            this.handleChangeProject(this.approvalInfo.projectName,"init");
                            console.log(this.projectList);
                            this.formatCard('bankAcct');
                            this.formatCard('bankCode');
                        }else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    });
            },
            fmtDate(obj){
                let date =  new Date(obj);
                let y = date.getFullYear();
                let m = "0"+(date.getMonth()+1);
                let d = "0"+date.getDate();
                this.approvalInfo.applyTime =  y+"-"+m.substring(m.length-2,m.length)+"-"+d.substring(d.length-2,d.length);
            },
            init(){
                this.getCityAndProject();
                this.type = this.$route.query.type || "";
                let timestamp =Date.parse(new Date());
                this.fmtDate(timestamp);
                if (this.type === "init") {
                    this.getApprovalId()
                }else {
                    this.themeDisabled = true
                    this.approvalInfo.executionId = this.$route.query.executionId || "";
                    this.getApprovalDetail()
                }
            }
        },
        mounted(){
            this.init()
        }
    }
</script>
<style lang="scss" scoped>
    .borkerApprovalPrint {
        font-size: 10pt;
        min-height: 9.7cm;
        /*width: 28.4cm;*/
        margin: 20px 0;
        .head {
            text-align: center;
            position: relative;
            .title {
                color: #000;
                padding: 0 5px;
                .top {
                    p {
                        font-size: 16pt;
                        margin-bottom: 8px;
                    }
                    span {
                        font-size: 13pt;
                    }
                }
                .bottom {
                    margin-top: 22px;
                    text-align: right;
                }
            }
            .body {
                $borderStyle: 1px solid #bbb;
                margin-top: 14px;
                box-sizing: border-box;
                color: #000;
                table {
                    border-top: $borderStyle;
                    margin-top: 24px;
                    table-layout:fixed;
                    [h0] {
                        height: 0 !important;
                        overflow: hidden;
                        border: none;
                        td {
                            height: 0;
                            padding: 0;
                            border: none;
                        }
                    }
                    .ofa{
                        overflow: visible;
                        white-space:nowrap;
                    }
                    .bln{
                        border-left: none;
                    }
                    td {
                        /*padding: 5px;*/
                        border-left: $borderStyle;
                        border-bottom: $borderStyle;
                        font-size: 10pt;
                        text-align: left;
                        vertical-align: middle;
                        &.bold {
                            font-weight: bold;
                        }
                        &[w3] {
                            width: calc(1000px / 24 * 3);
                        }
                        &[w4] {
                            width: calc(1000px / 24 * 4);
                        }
                        &[w6] {
                            width: calc(1000px / 24 * 6);
                        }
                        &[w8] {
                            width: calc(1000px / 24 * 8);
                        }

                        &[w14] {
                            width: calc(1000px / 24 * 14);
                        }
                        &[w20] {
                            width: calc(1000px / 24 * 20);
                        }
                        &[colspan="3"] {
                            p {
                                word-wrap: break-word;
                                width: 849px;
                            }
                        }
                        &.w173 {
                            width: 173px;
                        }
                        &:last-child {
                            border-right: $borderStyle;
                        }
                        &.title {
                            background: #e7f3fc;
                        }
                        p {
                            &:last-child {
                                margin-top: 4px;
                            }
                        }
                        pre {
                            line-height: 20px;
                            white-space: pre-line;
                        }
                    }
                }
                ul {
                    margin-top: 22px;
                    border: $borderStyle;
                    padding: 20px;
                    display: table;
                    width: 100%;
                    li {
                        text-align: left;
                        font-size: 10pt;
                        color: #000;
                        display: table-row;
                        width: 100%;
                        & > span {
                            display: block;
                        }
                        &:first-child {
                            font-size: 12pt;
                            span {
                                margin-bottom: 11px;
                            }
                        }
                        dl {
                            padding: 12px 0;
                            display: table-cell;
                            border-top: $borderStyle;
                            width: 20%;
                            &:nth-child(2) {
                                width: 20%;
                            }
                            &:nth-child(3) {
                                width: 60%;
                            }
                            dt {
                                margin-bottom: 4px;
                            }
                            dd {
                                word-break: break-all;
                            }
                        }
                        .color888 {
                            color: #888;
                        }
                    }
                }
                .mt0{
                    margin-top: 0;
                    border-top: 0;
                }
                /deep/ .el-form-item--small.el-form-item {
                    margin-bottom: 0;
                }
                /deep/ .el-input{
                    input{
                        border :none
                    }
                }
                /deep/ .el-select {
                    width: 100%;
                }
                .money{
                    width: 90%;
                }
            }
        }
        .foot {
            text-align: right;
            margin-top: 22px;
        }
        .bg-ddd{
            background: #ddd;
        }
    }
    /deep/ .el-message-box--center .el-message-box__content{
        text-align: left;
    }
    /deep/ .el-form-item__content {
        position: relative;
        .el-form-item__error--inline {
            position: absolute;
            background: #fff;
            padding-top: 2px;
            width: 100%;
            box-sizing: border-box;
            margin-left: 0;
            padding-left: 14px;
            left: 0;
            bottom: 0px;
        }
        .el-input--small .el-input__inner {
            height: 40px;
            line-height: 40px;
        }
    }
    .bt{
        border-top: 1px solid #bbb
    }

</style>

