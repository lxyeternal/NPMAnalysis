<template>
  <div class="product">
    <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
    <!-- 查询条件 -->
    <div class="panel-content" :style="{'margin-bottom' : brokerRole ? '40px' : '35px'}">
      <el-form class="form" :model="form" size="small" label-width="75px">
        <el-row>
          <el-col :span="24">
            <el-form-item label="合同名称：">
              <el-input style="width: 913px;" v-model.trim="form.contractName" placeholder="请输入合同关键词或合同编号"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <template v-if="role=='B'">
            <el-col :span="8">
              <el-form-item label="事业部：">
                <el-select filterable style="width: 240px;" :disabled="!brokerRole" @change="getBuyersList" v-model="form.groupCompanyCode" placeholder="请选择事业部" clearable>
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="(item,index) in groupCompanyList" :key="index" :label="item.value" :value="item.code"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <!-- label-width="92px" -->
              <el-form-item label="项目公司：">
                <el-select filterable style="width: 240px;" :disabled="!form.groupCompanyCode" v-model="form.purchaserCorpId" placeholder="请选择项目公司" clearable>
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="(item,index) in projectList" :key="index" :label="item.corpName" :value="item.corpId"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </template>
          <el-col :span="8" v-if="role=='S' || (role=='B' && !brokerRole)">
            <el-form-item label="采购商：" v-if="role=='S'">
              <el-input style="width: 240px;" v-model.trim="form.purchaserName" placeholder="请输入采购商"></el-input>
            </el-form-item>
            <el-form-item label="供应商：" v-if="role=='B' && !brokerRole">
              <el-input style="width: 240px;" v-model.trim="form.supplierName" placeholder="请输入供应商"></el-input>
            </el-form-item>
          </el-col>
          <template v-if="role=='S' && !isAgent">
            <el-col :span="8">
              <el-form-item label="代理商：">
                <el-input style="width: 240px;" v-model.trim="form.agentCorpName" placeholder="请输入代理商"></el-input>
              </el-form-item>
            </el-col>
          </template>
          <template v-else>
            <el-col :span="8" v-if="!brokerRole">
              <el-form-item label="合同状态：">
                <el-select style="width: 240px;" v-model="form.status" placeholder="请选择状态" clearable>
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="(item,index) in overStatusList" :key="index" :label="item.orderStatusDesc" :value="item.orderStatus"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </template>
          <el-col v-if="tab != 3" :span="8">
            <el-form-item label="结算状态：">
              <el-select style="width: 240px;" v-model="form.settleType" placeholder="请选择状态" clearable>
                <el-option label="全部" value=""></el-option>
                <el-option v-for="(item,index) in settleStatusList" :key="index" :label="item.value" :value="item.code"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="创建时间：">
              <div class="form-item date-picker">
                <el-date-picker style="width: 111px;" type="date" placeholder="选择时间" value-format="yyyy-MM-dd" :picker-options="pickerOptionsStart" v-model="form.orderTmFrom"></el-date-picker>
                <span>~</span>
                <el-date-picker style="width: 111px;" type="date" placeholder="选择时间" value-format="yyyy-MM-dd" :picker-options="pickerOptionsEnd" v-model="form.orderTmTo"></el-date-picker>
              </div>
            </el-form-item>
          </el-col>
          <template v-if="brokerRole || (role == 'S' && !isAgent)">
            <el-col :span="8" v-if="!brokerRole">
              <el-form-item label="合同状态：">
                <el-select style="width: 240px;" v-model="form.status" placeholder="请选择状态" clearable>
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="(item,index) in overStatusList" :key="index" :label="item.orderStatusDesc" :value="item.orderStatus"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8" v-else>
              <el-form-item label="供应商：">
                <el-input style="width: 240px;" v-model.trim="form.supplierName" placeholder="请输入供应商"></el-input>
              </el-form-item>
            </el-col>
          </template>
        </el-row>
        <el-row>
          <el-col :span="24" class="form-btns">
            <el-button type="primary" class="small-btn" @click="handleSearch">搜索</el-button>
            <el-button class="small-btn" @click="handleClear">清除</el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="batch-operation" v-if="brokerRole && tab == '1' && busiType !== 'ONEWAY_ORDER'">
      <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow" :disabled="!productList.filter(i=>{return !isDisabled(i)}).length">全选</el-checkbox>
      <el-button type="primary" class="small-btn" :disabled="!hasChecked || !productList.filter(i=>{return !isDisabled(i)}).length" @click="handleSign">批量签章</el-button>
      <div class="f12" style="margin-left: 20px;display: inline-block;"><span class="grey">※批量签章说明：为了更好的签章体验，</span><span class="red">请勾选≤5份合同进行批量签章。</span></div>
    </div>
    <div class="product-table">
      <!-- 列表 -->
      <table>
        <thead>
          <tr class="tl">
            <td style="width: 34px;" v-if="brokerRole && tab == '1' && busiType !== 'ONEWAY_ORDER'"></td>

            <td v-if="busiType !== 'ONEWAY_ORDER'" :style="{'width' : role == 'S' && !isAgent ? '152px' : brokerRole ?  tab == '1' ? '140px' : '174px' : '302px'}">合同编号/合同名称</td>
            <td v-else :style="{'width' : role == 'S' && !isAgent ? '212px' : brokerRole ?  tab == '1' ? '200px' : '234px' : '362px'}">合同编号/合同名称</td>
            <td style="width: 162px;" v-if="role == 'S' && !isAgent">
              代理商
            </td>

            <td v-if="busiType !== 'ONEWAY_ORDER'" :style="{'width' : role == 'S' && !isAgent ? '122px' : '140px'}">
              <span class="cr" v-if="role=='S'">采购商</span>
              <span class="cr" v-if="role=='B'">供应商</span>
            </td>
            <td v-else :style="{'width' : role == 'S' && !isAgent ? '162px' : '180px'}">
              <span class="cr" v-if="role=='S'">采购商</span>
              <span class="cr" v-if="role=='B'">供应商</span>
            </td>

            <td width="128" v-if="brokerRole">
              事业部/项目公司
            </td>
            <!-- <td>下单人</td> -->
            <!--<td style="width: 150px;" class="tr" @click="handleSort(2)">税前合同价款(元)-->
            <td :style="{'width': busiType !== 'ONEWAY_ORDER' ? '250px' : '150px','padding':'14px 10px'}" class="tr">合同价款(不含税)(元)
              <!--<i class="el-icon-d-caret" v-if="sortList[2]==0"></i>-->
              <!--<i class="el-icon-caret-top active" v-if="sortList[2]==1"></i>-->
              <!--<i class="el-icon-caret-bottom active" v-if="sortList[2]==2"></i>-->
            </td>
            <!--<td style="width: 100px;" @click="handleSort(0)">创建时间-->
            <td style="width: 100px;">创建时间
              <!--<i class="el-icon-d-caret" v-if="sortList[0]==0"></i>-->
              <!--<i class="el-icon-caret-top active" v-if="sortList[0]==1"></i>-->
              <!--<i class="el-icon-caret-bottom active" v-if="sortList[0]==2"></i>-->
            </td>
            <td style="width: 78px;">状态</td>
            <td style="width: 150px;" class="tr">操作</td>
          </tr>
        </thead>

        <template v-if="productList.length">
          <tbody>
          </tbody>
          <tbody v-for="(product,index) in productList" :key="index" class="tl tbody-row">
            <tr :class="{'border-none':showSignProcess(product) || showSupSignProcess(product)}">
              <td v-if="brokerRole && tab == '1' && busiType !== 'ONEWAY_ORDER'">
                <el-checkbox v-model="product.checked" @change="handleSelectTableRow(product,index)" :disabled="isDisabled(product)"></el-checkbox>
              </td>
              <td>
                <p>
                  <template v-if="brokerRole">{{product.clOrderNo}}/{{product.sybOrderNo}}</template>
                  <template v-if="role === 'B' && !brokerRole">
                    {{product.sybOrderNo}}
                  </template>
                  <template v-if="role === 'S'">
                    {{product.clOrderNo}}
                  </template>
                </p>
                <p v-if="product.contractName">《{{product.contractName}}》</p>
              </td>
              <td v-if="role == 'S' && !isAgent">
                {{product.corpDisplay}}
              </td>
              <!--<td>-->
              <!--<span v-if="product.contractName">《{{product.contractName}}》</span>-->
              <!--</td>-->
              <td>
                <span v-if="role=='S'">{{product.purchaserName}}</span>
                <span v-if="role=='B'">
                  {{product.supplierName}}
                </span>
                <p>
                  <span class="nailsupply" v-for="tag in product.tags && product.tags.slice(0,3)" :key="tag.tagId">{{tag.tagName}}</span>
                  <span class="nailsupply" v-if="product.tags && product.tags.length > 3">
                    <el-dropdown size="mini" placement="bottom-start">
                      <a style="color: #ffa300" class="el-dropdown-link">
                        ......
                      </a>
                      <el-dropdown-menu slot="dropdown">
                        <el-dropdown-item v-for="tag in product.tags.slice(3)" :key="tag.tagId">{{tag.tagName}}</el-dropdown-item>
                      </el-dropdown-menu>
                    </el-dropdown>
                  </span>
                </p>
              </td>
              <td v-if="brokerRole">
                <template v-if="product.groupCompanyName">
                  <p>{{product.groupCompanyName}}</p>
                  <p>{{product.purchaserName}}</p>
                </template>
                <template v-else>
                  -
                </template>
              </td>
              <!-- <td>{{product.orderAcctName}}</td> -->
              <td class="tr">
                <!--<p v-if="role=='S'">{{product.priceTypeDisp}}:</p>-->
                <p v-if="!(product.replenishOutContractFee || product.replenishInContractFee)">{{product.outContractFee || product.inContractFee | formatMoney}}</p>
                <template v-else>
                  <p>{{product.allOutContractFee || product.allInContractFee | formatMoney}}</p>
                  <p class="grey">(主合同金额：{{product.outContractFee || product.inContractFee | formatMoney}})</p>
                  <p class="grey">(补充合同金额：{{product.replenishOutContractFee || product.replenishInContractFee | formatMoney}})</p>
                </template>
                <p class="grey" v-if="product.settleAmt">(结算金额：{{product.settleAmt | formatMoney}})</p>
              </td>
              <td>{{product.orderTm | datetime}}</td>
              <td class="white-pre" :class="{'red':product.orderStatus=='14'}">
                <span v-if="role=='S'">{{product.sOrderStatusDisp}}</span>
                <span v-if="role=='B'">{{product.bOrderStatusDisp}}</span>
                <p>
                  <span>{{product.settleStatusPain}}</span>
                </p>
              </td>
              <td class="tr">
                <OrderListOperate :tab="tab" :order="product" @refresh="handleRefresh"></OrderListOperate>
              </td>
            </tr>
            <!--<tr class="sign-content" v-if="showSignProcess(product)">-->
            <tr class="sign-content" v-if="showSignProcess(product)">
              <td colspan="100">
                <SignProcessOrderList :order="product"></SignProcessOrderList>
              </td>
            </tr>
            <!-- 补充合同 -->
            <tr class="sign-content" v-if="showSupSignProcess(product)">
              <td colspan="100">
                <SignProcessOrderList :order="product.subOrderList[0]" isSupplementary="true"></SignProcessOrderList>
              </td>
            </tr>
            <!-- 结算单 -->
            <tr class="sign-content" v-if="showSettleProcess(product)">
              <td colspan="100">
                <SignProcessOrderList :order="product" type="settle"></SignProcessOrderList>
              </td>
            </tr>
            <tr v-if="product.orderStatus !== 'addProduct' && product.orderOperFlow && product.orderOperFlow.length && ['04','06','15', '16'].includes(product.orderOperFlow[0].operType)" class="error-msg">
              <td colspan="100" :class="{'fold':!product.foldFlag}">
                <span class="bold fl" v-if="['15', '16'].includes(product.orderOperFlow[0].operType)">退回{{product.terminateType == 'relieve' ? '解除' : '终止'}}合同原因：</span>
                <span class="bold fl" v-else>退回原因：</span>
                <span class="fl">{{product.orderOperFlow[0].operMsg}}</span>
                <span class="fr blue-pointer" @click="product.foldFlag = !product.foldFlag">{{product.foldFlag ? '展开':'收起'}}
                  <i v-if="product.foldFlag" class="el-icon-caret-bottom"></i>
                  <i v-else class="el-icon-caret-top"></i>
                </span>
                <div class="fl" v-if="!product.foldFlag" style="margin-top: 10px;">
                  <!-- <em class="grey" v-if="['15', '16'].includes(product.orderOperFlow[0].operType)">{{product.terminateType == 'relieve' ? '解除' : '终止'}}时间：</em> -->
                  <em class="grey">退回时间：</em>
                  {{product.orderOperFlow[0].operTime}}
                </div>
                <div style="clear: both"></div>
              </td>
            </tr>
            <tr v-if="product.orderStatus === 'addProduct' && ['04','06'].includes(subOrderListComputed(product).operType)" class="error-msg">
              <td colspan="100" :class="{'fold':!product.foldFlag}">
                <span class="bold fl">补充合同退回原因：</span>
                <span class="fl">{{subOrderListComputed(product).operMsg}}</span>
                <span class="fr blue-pointer" @click="product.foldFlag = !product.foldFlag">{{product.foldFlag ? '展开':'收起'}}
                  <i v-if="product.foldFlag" class="el-icon-caret-bottom"></i>
                  <i v-else class="el-icon-caret-top"></i>
                </span>
                <div class="fl" v-if="!product.foldFlag" style="margin-top: 10px;">
                  <em class="grey">补充合同退回时间：</em>
                  {{subOrderListComputed(product).operTime}}
                </div>
                <div style="clear: both"></div>
              </td>
            </tr>
            <!-- 结算退回 -->
            <tr v-if="showReturnSettleMegCp(product).settleMsg" class="error-msg">
              <td colspan="100" :class="{'fold':!product.foldFlag}">
                <span class="bold fl">{{showReturnSettleMegCp(product).settleType == '0' ? '结算申请' : showReturnSettleMegCp(product).settleType == '1' ? '结算申请撤回' : '结算申请终止'}}退回原因：</span>
                <span class="fl">{{showReturnSettleMegCp(product).settleMsg}}</span>
                <span class="fr blue-pointer" @click="product.foldFlag = !product.foldFlag">{{product.foldFlag ? '展开':'收起'}}
                  <i v-if="product.foldFlag" class="el-icon-caret-bottom"></i>
                  <i v-else class="el-icon-caret-top"></i>
                </span>
                <div class="fl" v-if="!product.foldFlag" style="margin-top: 10px;">
                  <em class="grey">{{showReturnSettleMegCp(product).settleType == '0' ? '结算申请' : showReturnSettleMegCp(product).settleType == '1' ? '结算申请撤回' : '结算申请终止'}}退回时间：</em>
                  {{showReturnSettleMegCp(product).settleTime}}
                </div>
                <div style="clear: both"></div>
              </td>
            </tr>
          </tbody>
        </template>
      </table>
      <div class="table-pagination" v-if="productList.length">
        <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
        </el-pagination>
      </div>

      <!-- 空列表 -->
      <div class="product-empty" v-if="!productList.length&&!listLoading">
        <img src="@/assets/images/icon-no-product.png">
        <p>没有搜索到相关合同，请重新修改搜索条件搜索！</p>
      </div>
    </div>
    <el-dialog class="sign-result-dialog" :title="signResultTitle" :append-to-body="true" :lock-scroll="true" :visible.sync="signResultDialogVisible" width="840px" center :close-on-click-modal="false" @close="handleSearch">
      <div class="f12 bold tl" v-if="signFailNum > 0 &&signFailNum < selectedSignLength">您于{{presentTime}}签署<em class="red">{{selectedSignLength}}</em>份合同，
        <span v-if="supSignLength || terminationSignLength || supTerSignLength">其中含有<span v-if="supSignLength"><em class='red'>{{supSignLength}}</em>份补充合同，</span><span v-if="terminationSignLength"><em class='red'>{{terminationSignLength}}</em>份合同终止，</span><span v-if="supTerSignLength"><em class='red'>{{supTerSignLength}}</em>份补充合同终止，</span></span>
        失败<em class="red">{{signFailNum}}</em>份，建议请重新签署，未签署成功的合同可在<span class="blue">【双向合同】-【待处理】</span>列表查看
      </div>
      <div class="f12 bold tl" v-if="signFailNum == selectedSignLength">您于{{presentTime}}签署<em class="red">{{selectedSignLength}}</em>份合同，
        <span v-if="supSignLength || terminationSignLength || supTerSignLength">其中含有<span v-if="supSignLength"><em class='red'>{{supSignLength}}</em>份补充合同，</span><span v-if="terminationSignLength"><em class='red'>{{terminationSignLength}}</em>份合同终止，</span><span v-if="supTerSignLength"><em class='red'>{{supTerSignLength}}</em>份补充合同终止，</span></span>
        全部签署失败，建议请重新签署，未签署成功的合同可在<span class="blue">【双向合同】-【待处理】</span>列表查看
      </div>
      <div class="f12 bold tl" v-if="signFailNum == 0">您于{{presentTime}}签署<em class="red">{{selectedSignLength}}</em>份合同，
        <span v-if="supSignLength || terminationSignLength || supTerSignLength">其中含有<span v-if="supSignLength"><em class='red'>{{supSignLength}}</em>份补充合同，</span><span v-if="terminationSignLength"><em class='red'>{{terminationSignLength}}</em>份合同终止，</span><span v-if="supTerSignLength"><em class='red'>{{supTerSignLength}}</em>份补充合同终止，</span></span>
        全部签署成功，签署成功的合同可在<span class="blue">【双向合同】-【进行中】</span>列表查看
      </div>
      <div v-if="signFailNum > 0">※若有疑问请联系平台客服：<em class="blue">{{$platformContact()['hotLine']}} {{$platformContact()['hotLineTime']}}</em></div>
      <div class="sign-result" v-if="selectedSignLength > 0 && signFailNum > 0">
        <el-button type="primary" class="normal-btn" @click="handleConfirm()">重新电子签章</el-button>
        <el-button class="normal-btn" @click="signResultDialogVisible=false" style="width: 120px;">取消</el-button>
      </div>
      <div class="sign-result" v-if="selectedSignLength > 0 && signFailNum == 0">
        <el-button type="primary" @click="confirmBtn(1)" class="normal-btn">确定</el-button>
        <el-button class="normal-btn" @click="confirmBtn(0)" style="width: 120px;">取消</el-button>
      </div>
    </el-dialog>
    <!-- 确认合同/批量确认合同 -->
    <OrderConfirm ref="orderConfirm" @close="handleCloseOrderConfirm"></OrderConfirm>
    <Signature ref="signature" @close="handleCloseSignature"></Signature>
    <Loading :is-loading="isLoading"></Loading>
    <!--<ConfluenceFloat :id="'4'"></ConfluenceFloat>-->
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import OrderListOperate from "@/components/order/OrderListOperate";
import OrderConfirm from "@/components/order/dialog/orderOperate/OrderConfirm";
import ContractOperate from "@/components/order/ContractOperate";
import SignProcessOrderList from "@/components/order/SignProcessOrderList";

import { InterfaceService } from "@/services/api";
import { filterEventByAcct } from '@/utils/orderUtil';
import ConfluenceFloat from '@/components/base/ConfluenceFloat'
import Signature from "@/components/order/dialog/Signature";
import { DateUtil } from '@/utils/dateUtil';

const params = {
  orderNo: "",
  orderAccName: "",
  contractName: "",
  orderStatus: [],
  status: "",
  purchaserName: "",
  supplierName: "",
  agentCorpName: "",
  orderTmFrom: "",
  orderTmTo: "",
  // priceType: "D", // 字段删除
  sort: "2_0_0",
  pageIndex: 1,
  pageSize: 10,
  // enterFrom: 1,
  searchType: '',
  groupCompanyCode: '',
  purchaserCorpId: '',
  settleType: ''
};

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    PanelTitle,
    OrderListOperate,
    OrderConfirm,
    ContractOperate,
    SignProcessOrderList,
    Signature,
    ConfluenceFloat
  },
  data() {
    return {
      tab: "1",
      tabs: [
        // { label: "待处理", index: "1", active: true },
        // { label: "进行中", index: "2" },
        // { label: "已结束", index: "3" },
      ],
      form: Object.assign({}, params),
      allChecked: false,
      signResultDialogVisible: false,
      disableAllCheck: false,
      hasChecked: false,
      sortList: [2, 0, 0],
      priceList: [
        { label: "全部", value: "" },
        { label: "战略价(税前)", value: "A" },
        { label: "市场价(税前)", value: "D" },
        { label: "协议价(税前)", value: "Negotiated" }
      ],
      pickerOptionsEnd: {
        disabledDate: time => {
          return time.getTime() <= new Date(this.form.orderTmFrom).getTime() - 86400000
        }
      },
      pickerOptionsStart: {
        disabledDate: time => {
          return this.form && this.form.orderTmTo && time.getTime() >= new Date(this.form.orderTmTo).getTime()
        }
      },
      statusList: [],
      overStatusList: [],
      settleStatusList: [],
      productList: [],
      groupCompanyList: [],
      projectList: [],
      total: 0,
      presentTime: '',
      signResultTitle: '',
      signFailNum: 0,
      selectedSignLength: 0, //签章合同总数量
      // mainSignLength: 0, //主合同数量
      supSignLength: 0,// 补充合同
      terminationSignLength: 0,// 终止合同数量
      supTerSignLength: 0,// 终止补充合同数量
      settleSignLength: 0,// 结算合同数量
      isLoading: false,
      listLoading: false,
      signFlag: false,
      storeParams: {},
      busiType: '',//ORDER(双向),ONEWAY_ORDER（单项）
    };
  },
  watch: {
    $route(to, from) {
      this.init()
    }
  },
  computed: {
    showReturnSettleMegCp() {
      return order => {
        const flows = order.tdSettlementFlows || [],
          obj = flows[flows.length - 1] || {}

        return ['3', '8'].includes(obj.settleStatus) && obj || {}
      }
    },
    subOrderListComputed() {
      return row => {
        let result = {}
        try {
          const obj = row.subOrderList && row.subOrderList[0] || {}
          result = obj.orderOperFlow && obj.orderOperFlow[0] || {}
        } catch (error) { console.error(error) }
        return result
      }
    },
  },
  methods: {
    handleCloseSignature(bool, num) {
      if (bool) {
        this.selectedSignLength = this.productList.filter(i => { return i.checked }).length;
        this.presentTime = DateUtil.dateToString();
        this.signFailNum = num;
        num == 0 ? this.signResultTitle = '签署成功' : this.signResultTitle = '签署失败';
        this.signResultDialogVisible = true;
      }
    },
    handleSign() {
      let num = this.productList.filter(i => { return i.checked }).length;
      // this.mainSignLength = this.productList.filter(i => { return i.checked }).filter(item => item.orderStatus == '05').length;
      this.supSignLength = this.productList.filter(i => { return i.checked }).filter(item => item.orderStatus == 'addProduct' && item.subOrderList && item.subOrderList.length && item.subOrderList[0].subOrderStatus === '05').length;
      this.terminationSignLength = this.productList.filter(i => { return i.checked }).filter(item => item.orderStatus == 'contractTerminating' && (item.externalSysList.find(i => { return i.operType === 'TERMINATED' }) || {}).approveStatus === '3').length;
      this.settleSignLength = this.productList.filter(i => { return i.checked }).filter(item => item.settleType == '0' && item.settleStatus == '4').length;
      // this.supTerSignLength = this.productList.filter(i => { return i.checked }).filter(item => item.orderStatus == 'contractTerminating' && (item.externalSysList.find(i => { return i.operType === 'TERMINATED' }) || {}).approveStatus === '3').length;
      let str = '';
      let title = '';
      if (!this.supSignLength && !this.terminationSignLength && !this.supTerSignLength) {
        str = `您已选中<span class='red'>${num}</span>份合同， 确认要批量签章吗？`;
      } else {
        str = `您已选中<span class='red'>${num}</span>份合同，其中含有
        ${this.supSignLength ? `<span class='red'>${this.supSignLength}</span>份补充合同，` : ''}
        ${this.terminationSignLength ? `<span class='red'>${this.terminationSignLength}</span>份合同终止，` : ''}
        ${this.supTerSignLength ? `<span class='red'>${this.supTerSignLength}</span>份补充合同终止，` : ''}
        ${this.settleSignLength ? `<span class='red'>${this.settleSignLength}</span>份结算单合同，` : ''}
        确认要批量签章吗？`;
      }

      title = '批量签章'
      this.$confirm(
        str,
        title,
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确认签章",
          cancelButtonText: '取消',
        }).then(() => {
          this.handleConfirm()
        }).catch(() => {
        });
    },

    confirmBtn(type) {
      this.signResultDialogVisible = false;
      if (type === 1) {
        this.tabs = [
          { label: "待处理", index: "1" },
          { label: "进行中", index: "2", active: true },
          { label: "已结束", index: "3" },
        ];
        this.tab = '2'
      }
    },
    // 批量确认合同完成
    handleConfirm() {
      let attach = [];
      this.productList.filter(i => { return i.checked }).forEach(item => {
        let list = []
        if (item.orderStatus == 'addProduct') { // 补充合同
          list = item.subOrderList[0].eventList
        } else {
          list = item.eventList
        }
        list.forEach(ev => {
          // ev.eventType == '5' 结算单
          if ((ev.eventType == 0 || ev.eventType == 'replenishSign' || ev.eventType == 'contractTerminateSign' || ev.eventType == '5') &&
            (ev.eventStatus == "0" || ev.eventStatus == "1")) {
            attach.push(ev)
          }
        })
      });
      console.log(attach, '-attach');

      this.$refs["signature"].open(attach, "order");
    },
    // 修改tab
    handleChangeTab(tab) {
      this.tab = tab.index;
      // this.recoverStatus(this.tab);
      this.form = Object.assign({}, params);

      // 非材料公司 只能查询 当前所在事业部
      if (!this.brokerRole) {
        this.form.groupCompanyCode = this.groupCompanyCode
      }
      this.getListConfig()

      this.getOrderList();
    },
    // 结算单 - 签章进度 type: settle - 结算单
    showSettleProcess(product) {
      return product.settleStatus === '4' && product.settleType != '1' && product.eventList && product.eventList.length
    },
    showSupSignProcess(product) {
      let item = product.subOrderList && product.subOrderList[0] || {}
      return item.subOrderStatus === '05' && item.eventList && item.eventList.length
    },
    showSignProcess(product) {
      let oaApprovalInfo = product.externalSysList && product.externalSysList.find(i => { return i.operType === 'TERMINATED' }) || {};
      return product.orderStatus === '05' && product.eventList && product.eventList.length || (product.orderStatus === 'contractTerminating' && oaApprovalInfo.approveStatus === '3')
    },
    // 清楚状态选择
    handleSelectClear() {
      // this.recoverStatus(this.tab);
    },
    // 清除
    handleClear() {
      const code = this.form.groupCompanyCode
      this.form = Object.assign({}, params)
      // 非材料公司 不清空 事业部
      if (!this.brokerRole) {
        this.form.groupCompanyCode = code
      }
      this.getOrderList()
    },
    // 搜索
    handleSearch() {
      this.form.orderStatus = [this.form.status];
      if (this.form.externalCode) {
        this.form.sysCode = 'ERP';
      } else {
        delete this.form.sysCode;
        delete this.form.externalCode;
      }

      if (this.tab > 3) {
        delete this.form.searchType;
      }
      this.form.pageIndex = 1;
      this.getOrderList();
    },
    // 排序
    handleSort(index) {
      let arr = [].concat(this.sortList);
      this.sortList.forEach((item, i) => {
        if (index == i) {
          if (item == 0) {
            arr[i] = 2;
          } else if (item == 2) {
            arr[i] = 1;
          } else {
            arr[i] = 0;
          }
        } else {
          arr[i] = 0;
        }
      });
      this.sortList = arr;
      this.getOrderList();
    },
    isDisabled(item) {
      let result = true
      // 主合同
      if (item.orderStatus == '05') {
        result = false
      }
      // 终止合同
      if (item.orderStatus == 'contractTerminating' && (item.externalSysList.find(i => { return i.operType === 'TERMINATED' }) || {}).approveStatus === '3') {
        result = false
      }
      // 补充合同
      if (item.orderStatus == 'addProduct' && item.subOrderList && item.subOrderList.length && item.subOrderList[0].subOrderStatus === '05') {
        result = false
      }
      // 结算合同
      if (item.orderStatus == '11' && item.settleStatus == '4' && item.settleType === '0') {
        result = false
      }
      return result
    },
    // 是否全选
    checkAllSelect() {
      this.allChecked = this.productList.filter(i => { return !this.isDisabled(i) }).every(item => {
        return item.checked;
      });
    },
    // 是否可批量
    checkBatch() {
      this.hasChecked = this.productList.filter(i => { return !this.isDisabled(i) }).some(item => {
        return item.checked;
      });
    },
    // 全选
    handleAllSelectTableRow(bool) {
      this.productList.filter(i => { return !this.isDisabled(i) }).forEach(item => {
        item.checked = bool;
      });
      this.checkBatch();
    },
    // 选中行
    handleSelectTableRow(product, index) {
      this.$set(this.productList, index, product);
      this.checkBatch();
      this.checkAllSelect();
    },
    // 刷新列表
    handleRefresh(operationType) {
      console.log(operationType, '刷新列表');

      //关闭、删除
      this.form.pageIndex = 1;
      if (operationType === '4') {
        this.handleChangeTab({ index: '3' });
        this.tabs = [
          { label: "待处理", index: "1" },
          { label: "进行中", index: "2" },
          { label: "已结束", index: "3", active: true },
        ]

      } else if (operationType === '5') {
        this.handleChangeTab({ index: '2' });
        this.tabs = [
          { label: "待处理", index: "1" },
          { label: "进行中", index: "2", active: true },
          { label: "已结束", index: "3" },
        ]
        //撤回
      } else if (operationType === '3' || operationType === '2' || operationType === 'reject') {
        this.handleChangeTab({ index: '1' });
        this.tabs = [
          { label: "待处理", index: "1", active: true },
          { label: "进行中", index: "2" },
          { label: "已结束", index: "3" },
        ]
      } else if (operationType === 'closeOrderRescind') {
        this.getOrderList();
      }
    },
    // 批量确认合同弹窗
    handleBatchOrderConfirm() {
      const orders = [];
      this.productList.forEach(item => {
        if (item.checked) {
          orders.push(item);
        }
      });
      this.$refs["orderConfirm"].open(orders, true);
    },
    // 批量确认合同完成
    handleCloseOrderConfirm(bool) {
      if (bool) {
        this.getOrderList();
      }
    },
    // 分页跳转
    handleCurrentChange(page) {
      this.form.pageIndex = page;
      this.getOrderList();
      window.scrollTo(0, 0)
    },
    // 恢复状态
    // recoverStatus(tab) {
    //   this.form.enterFrom = '1';
    //   if (tab == 1) {
    //     this.form.status = "";
    //     this.form.orderStatus = [];
    //   } else if (tab == 2) {
    //     this.form.status = "";
    //     this.form.orderStatus = ["01", "13"];
    //   } else if (tab == 3) {
    //     this.form.status = "";
    //     this.form.orderStatus = ["03", "11", "addProduct"];
    //   } else if (tab == 4) {
    //     this.form.status = "";
    //     this.form.orderStatus = ["02", "04", "12", "14", "contractTerminated"];
    //   }
    // },
    // 待签署合同
    waitSignContract(order) {
      let allow = false;
      let acctIdList = [];
      if (this.userinfo.accountList.length) {
        this.userinfo.accountList.forEach(item => {
          acctIdList.push(item.acctId)
        });
      } else {
        acctIdList.push(this.acctId)
      }
      if (order.eventList) {
        const list = filterEventByAcct(order.eventList, 0, acctIdList);
        list.forEach(item => {
          if (
            item.eventType == 0 &&
            (item.eventStatus == 0 || item.eventStatus == 1)
          ) {
            if (item.processList) {
              item.processList.forEach(process => {
                if (process.processFlg == 0) {
                  allow = true;
                }
              });
            }
          }
        });
      }
      if ((order.orderStatus == 'contractTerminating' || order.orderStatus == 'contractTerminated')) {
        allow = false;
      }
      return allow;
    },
    waitBrokerSign(order) {
      let allow = true;
      if (order.externalSysList && order.externalSysList.length > 0) {
        order.externalSysList.forEach(item => {
          if (item.approveStatus != "1") {
            allow = false
          }
        })
      } else {
        allow = false
      }
      return allow
    },
    async init() {
      this.busiType = this.$route.query.busiType || ''
      if (this.busiType === '0') {
        this.busiType = ''
      }
      this.getBusinessDepartmentList()
      // 非材料公司 只能查询 当前所在事业部
      if (!this.brokerRole) {
        this.form.groupCompanyCode = this.groupCompanyCode
        this.getBuyersList()
      }
      const tabsInfo = await this.getOrderListTabsInfo() || {}
      this.setShowTab(tabsInfo)

      if (this.$getRootScope('orderListTab') === '2') {
        this.handleChangeTab({ index: '2' });
        this.tabs = [
          { label: "待处理", index: "1" },
          { label: "进行中", index: "2", active: true },
          { label: "已结束", index: "3" },
        ]
        this.$removeRootScope('orderListTab')
      }

      this.getListConfig()
      this.getOrderList();
    },
    // tab 显示设置
    setShowTab(tabsInfo) {
      const { pendingListCount, processingListCount, finishedListCount } = tabsInfo || {}
      console.log(tabsInfo, '-tabsInfo');

      if (!pendingListCount && !processingListCount && !finishedListCount) {
        if (this.busiType === 'ONEWAY_ORDER' && this.brokerRole) {
          this.tabs = [
            { label: "进行中", index: "2", active: true },
            { label: "已结束", index: "3", },
          ]
          this.handleChangeTab({ index: '2' });
        } else {
          this.handleChangeTab({ index: '1' });
          this.tabs = [
            { label: "待处理", index: "1", active: true },
            { label: "进行中", index: "2", },
            { label: "已结束", index: "3", },
          ]
        }
        return
      }
      try {
        if (this.busiType === 'ONEWAY_ORDER' && this.brokerRole) {
          this.tabs = [
            { label: "进行中", index: "2", active: !!pendingListCount && !!processingListCount },
            { label: "已结束", index: "3", active: !pendingListCount && !processingListCount && !!finishedListCount },
          ]
        } else {
          this.tabs = [
            { label: "待处理", index: "1", active: !!pendingListCount },
            { label: "进行中", index: "2", active: !pendingListCount && !!processingListCount },
            { label: "已结束", index: "3", active: !pendingListCount && !processingListCount && !!finishedListCount },
          ]
        }

        this.tab = +this.tabs.find(f => f.active).index
      } catch (error) {
        throw new Error('setShowTabError', error)
      }
    },
    getOrderListTabsInfo() {
      return new Promise((resovle, reject) => {
        InterfaceService.getOrderListTabsInfo({}, data => {
          if (data.respData && data.respData.respCode === "0000") {
            // int pendingListCount;//待处理件数
            // int processingListCount;//进行中件数
            // int finishedListCount;//已结束件数
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
          }
          resovle(data.respData || {})
        }, data => {
          reject(data)
        }, () => {
          this.isLoading = true;
          this.listLoading = true;
        }, () => {
          this.isLoading = false;
          this.listLoading = false;
        })
      })
    },
    getOrderList() {
      this.form.sort = this.sortList.join("_");
      const params = Object.assign({}, this.form);
      params.searchType = this.tab;
      if (this.busiType) {
        params.busiType = this.busiType
      }
      InterfaceService.getOrderList(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.productList = data.respData.orders || [];
            let disableAllCheck = true;
            this.productList.forEach(item => {
              item.checked = false;
              if (item.orderStatus == "01") {
                disableAllCheck = false;
              }
              this.$set(item, 'foldFlag', true)

              // 补充合同
              if (item.subOrderList && item.subOrderList.length) {
                item.subOrderList.forEach(i => {
                  this.$set(i, 'orderStatus', i.subOrderStatus)
                })
              }
            });
            this.allChecked = false;
            this.disableAllCheck = disableAllCheck;
            this.hasChecked = false;
            this.overStatusList = data.respData.orderStatusList || [];
            // BUG #12432 料公司-交易合同：合同管理，选择事业部后，再选择项目公司，点击搜索，再点击项目公司的搜索框时 数据错误
            // this.projectList = data.respData.corpNameList || [];


            this.total = data.respData.totalCount;
            this.form.pageSize = data.respData.pageSize;
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
          this.listLoading = true;
        },
        () => {
          this.isLoading = false;
          this.listLoading = false;
        }
      );
    },
    // recordFormData() {
    //   let hasChange = false;
    //   Object.keys(this.storeParams).forEach(key => {
    //     if (this.storeParams[key] != this.form[key]) {
    //       hasChange = true;
    //     }
    //   });
    //
    //   if (hasChange) {
    //     this.form.pageIndex = 1;
    //   }
    //
    //   this.storeParams = this.$clone(this.form);
    //   delete this.storeParams.pageIndex;
    //   delete this.storeParams.pageSize;
    //   delete this.storeParams.orderStatus;
    // },
    arrangeStatusList(list) {
      let tab = this.tab;
      let arr = [],
        statusList = [];
      if (this.role == 'S') {
        if (this.isAgent) {
          if (tab == 1) {
            statusList = ["01", "04", "05", "06"];
          } else if (tab == 2) {
            statusList = ["07", "03", "05", "11"];
          } else if (tab == 3) {
            statusList = ["02", "12"];
          }
        } else {
          if (tab == 1) {
            statusList = ["01", "05", "06", "07"];
          } else if (tab == 2) {
            statusList = ["01", "03", "04", "05", "06", "11"];
          } else if (tab == 3) {
            statusList = ["02", "12"];
          }
        }
      } else {
        if (!this.brokerRole) {
          if (tab == 1) {
            statusList = ["03", "05"];
          } else if (tab == 2) {
            statusList = ["01", "04", "05", "06", "07", "11"];
          } else if (tab == 3) {
            statusList = ["02", "12"];
          }
        } else {
          if (tab == 1) {
            statusList = ["05"];
          } else if (tab == 2) {
            statusList = ["01", "03", "04", "05", "06", "07", "11"];
          } else if (tab == 3) {
            statusList = ["02", "12"];
          }
        }

      }
      if (!arr.length) {
        list.forEach(item => {
          if (statusList.indexOf(item.orderStatus) !== -1) {
            arr.push(item);
          }
        });
      }

      return arr;
    },

    // 查询事业部下拉
    getListConfig() {
      let groupIds = []
      // SETTLE_STATUS_PENDING_AGENT
      // SETTLE_STATUS_PROGRESS_AGENT

      // SETTLE_STATUS_PENDING_MANU
      // SETTLE_STATUS_PROGRESS_MANU

      // SETTLE_STATUS_PENDING_PUR
      // SETTLE_STATUS_PROGRESS_PUR

      // SETTLE_STATUS_PENDING_BRO
      // SETTLE_STATUS_PROGRESS_BRO
      console.log(this.tab, '--tab');
      if (this.tab == 3) return
      // 供应商
      if (this.role == 'S') {
        // 经销商
        if (this.isAgent) {
          this.tab == 1 ? groupIds.push('SETTLE_STATUS_PENDING_AGENT') : groupIds.push('SETTLE_STATUS_PROGRESS_AGENT')
          // 厂家
        } else {
          this.tab == 1 ? groupIds.push('SETTLE_STATUS_PENDING_MANU') : groupIds.push('SETTLE_STATUS_PROGRESS_MANU')
        }
        // 采购商
      } else {
        // 非材料公司
        if (!this.brokerRole) {
          this.tab == 1 ? groupIds.push('SETTLE_STATUS_PENDING_PUR') : groupIds.push('SETTLE_STATUS_PROGRESS_PUR')
        } else {
          this.tab == 1 ? groupIds.push('SETTLE_STATUS_PENDING_BRO') : groupIds.push('SETTLE_STATUS_PROGRESS_BRO')
        }
      }

      const params = {
        appName: 'TRANS',
        groupIds,
      }
      InterfaceService.getPaymentMethod(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          const resultMap = data.respData.configEntityListMap || {}

          // 供应商
          if (this.role == 'S') {
            // 经销商
            if (this.isAgent) {
              this.settleStatusList = this.tab == 1 ? resultMap.SETTLE_STATUS_PENDING_AGENT : resultMap.SETTLE_STATUS_PROGRESS_AGENT
              // 厂家
            } else {
              this.settleStatusList = this.tab == 1 ? resultMap.SETTLE_STATUS_PENDING_MANU : resultMap.SETTLE_STATUS_PROGRESS_MANU
            }
            // 采购商
          } else {
            // 非材料公司
            if (!this.brokerRole) {
              this.settleStatusList = this.tab == 1 ? resultMap.SETTLE_STATUS_PENDING_PUR : resultMap.SETTLE_STATUS_PROGRESS_PUR
            } else {
              this.settleStatusList = this.tab == 1 ? resultMap.SETTLE_STATUS_PENDING_BRO : resultMap.SETTLE_STATUS_PROGRESS_BRO
            }
          }

          console.log(this.settleStatusList, '-settleStatusList');

        } else {
          this.$message.error(data.respData && data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },

    getBuyersList() {
      this.form.purchaserCorpId = '';
      let param = {
        projectGroup: "REAL",
        // pageFrom	String	N	页面来源（CORP_MANAGEMENT:公司管理）
        groupCompanyCode: this.form.groupCompanyCode,
      };
      InterfaceService.getFkProjectList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.projectList = data.respData.corpInfoList || [];
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    getBusinessDepartmentList() {
      const params = {
        groupId: 'SYB_CONFIG'
      };
      InterfaceService.getBusinessDepartmentList(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          this.groupCompanyList = res.configList || [];
          this.projectList = [];
        } else {
          this.$message.error(data.respData && data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
  },
  mounted() {
    this.init();
  }
};
</script>

<style lang="scss" scoped>
.hand + .hand {
  margin-left: 10px;
}
.price-tip {
  cursor: pointer;
  color: #a9a9aa;

  &:hover {
    color: #0082ff;
  }
}

.product {
  font-size: 14px;
}

.pointer {
  cursor: pointer;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }

  .active {
    color: #ffd64e;
  }
}

.nowrap {
  white-space: nowrap;
}

.panel-content {
  padding: 20px 0 0 10px;
  background: #f9f9f9;
}

.form {
  min-height: 135px;

  /deep/ .el-col {
    height: 52px;
  }

  /deep/ .el-select {
    width: 100%;
  }

  /deep/ .el-date-editor {
    input.el-input__inner {
      padding: 0 15px;
    }
    .el-input__prefix {
      display: none;
    }
  }

  &:after {
    display: table;
    content: "";
    clear: both;
  }
}

.form-item {
  position: relative;
  display: inline-block;
  line-height: 32px;

  .float-right {
    position: absolute;
    top: 2px;
    right: 1px;
    height: 30px;
    padding: 0 7px;
    line-height: 30px;
    background: #ffffff;
  }
}

.error-info {
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
  position: absolute;
  top: 100%;
  left: 0;
}

.form-btns {
  text-align: center;
}

.product-table {
  /deep/ .el-table__body-wrapper {
    font-size: 12px;
  }

  /deep/ .el-table th,
  .el-table td {
    padding: 14px 0;
  }

  /deep/ .el-button {
    font-size: 12px;
  }

  table {
    table-layout: fixed;
    width: 100%;
    line-height: 23px;
    font-size: 12px;
    td {
      padding: 14px 15px;
      vertical-align: middle;
      word-break: break-all;
    }
    td:last-child {
      padding-right: 10px;
    }
    td:first-child {
      padding-left: 10px;
    }

    thead {
      font-size: 14px;
      text-align: center;
      white-space: nowrap;
      color: #909399;
      background: #f9f9f9;
    }

    .tbody-row {
      &:hover {
        background: #e8f3fd;
        .sign-content {
          background: #f0f8ff;
        }
      }
      .sign-content {
        display: table-row;
        background: #f9f9f9;
        td {
          padding: 0;
          border-top: none;
        }
      }
    }
    .tbody-row .nailsupply {
      display: inline-block;
      max-width: 100%;
      min-height: 14px;
      padding: 0 6px;
      line-height: 14px;
      border: 1px solid #ffa300;
      border-radius: 7px;
      color: #ffa300;
      margin-right: 6px;
    }
    tbody {
      text-align: center;

      tr {
        &.all-check {
          text-align: left;

          &:hover {
            background: #ffffff;
          }
        }
      }

      /*tr:hover + tr.sign-content {*/
      /*display: table-row;*/
      /*}*/

      tr {
        border-bottom: 1px solid #ebeef5;
      }
      .border-none {
        border-bottom: none;
      }
    }
    .error-msg {
      line-height: 30px;
      td {
        padding: 0 10px;
        background: #ffe9eb;
        border: 1px solid #db7575;
        height: 30px;
        span {
          &:nth-of-type(2) {
            width: 815px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            text-align: left;
          }
          &:last-child {
            width: 40px;
          }
        }
      }
      .fold {
        line-height: 17px;
        padding: 6px 10px;
        height: auto;
        span {
          &:nth-of-type(2) {
            width: 815px;
            /*overflow: hidden;*/
            text-overflow: ellipsis;
            white-space: normal;
          }
        }
      }
    }
  }

  .product-name {
    display: inline-flex;
    width: 100%;
    vertical-align: top;
    line-height: 20px;

    img {
      width: 75px;
      height: 75px;
    }

    .left {
      margin-right: 10px;
    }

    .right {
      text-align: left;

      p:first-child {
        margin-bottom: 10px;
      }
      p:last-child {
        word-break: break-all;
        max-height: 40px;
        overflow: hidden;
        color: #969799;
      }
    }
  }
}

.product-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}

.price-popover {
  display: flex;
  color: #ababac;

  > div:first-child {
    margin-right: 10px;
  }

  p:first-child {
    padding: 0 5px;
    border-left: 3px solid #ffd64e;
    line-height: 15px;
  }

  p:last-child {
    margin-top: 10px;
    color: #ffffff;
  }
}

.table-pagination {
  margin: 50px 0 80px;
  text-align: center;
  color: #888888;
}
/deep/ .el-dropdown-menu__item {
  min-height: 14px;
  line-height: 14px;
  border: 1px solid #ffa300;
  border-radius: 7px;
  color: #ffa300;
  cursor: default;
  margin-top: 5px;
  &:hover {
    color: #ffa300;
    background: #fff;
  }
  &:first-child {
    margin-top: 0;
  }
}
.w284 {
  width: 284px !important;
}
.subOrderMsgContainer {
  padding: 0 !important;
  span {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border: 0;
  }
}
.batch-operation {
  padding-left: 10px;
  margin-top: -10px;
  margin-bottom: 10px;
  .el-button {
    margin-left: 8px;
  }
}
.sign-result-dialog {
  /deep/ .el-dialog__body {
    width: 100%;
  }
  text-align: center;
  div {
    text-align: center;
    margin: 20px auto 20px;
  }
}
.white-pre {
  white-space: pre;
}
</style>




