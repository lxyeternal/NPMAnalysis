<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <div class="app-search-bar isWhiteBg">
            <div class="search-bar-container inner-container" style="position: relative;">
                <div class="index-logo">
                    <div class="logo">
                        <h1>
                            <a @click="go('/home')" class="logo-bd"></a>
                        </h1>
                    </div>
                </div>
                <ViceHeader title="批量发起要货" :flow="flow"></ViceHeader>
            </div>
        </div>
        <div class="inner-container">
            <div class="order-content" v-for="(order,index) in orderList" :key="index" :class="{['batch-goods-num-'+(index+1)]:true}">
                <div class="order-title">
                    <span class="big">{{index+1}}</span> 《{{order.contractName}}》—— 第{{order.batchNo}}批次
                </div>
                <!-- 基本信息 -->
                <div class="order-info">
                    <el-row>
                        <el-col :span="24">
                            <div class="order-info-title">合同基本信息</div>
                        </el-col>
                        <el-col :span="8">
                            <p>
                                <label>合同编号：</label>{{order.orderNo}}
                            </p>
                        </el-col>
                        <el-col :span="8">
                            <p>
                                <label>供应商：</label>{{order.supplierName}}
                            </p>
                        </el-col>
                        <el-col :span="8">
                            <p>
                                <label>备货周期：</label>
                                <span v-if="order.prepareCycle">{{order.prepareCycle}}日历天</span>
                            </p>
                        </el-col>
                        <el-col :span="8" v-for="(item,_index) in filterRole(order.contractStakeHolders)" :key="_index">
                            <p>
                                <label>{{item.roleName}}：</label>
                                <span>{{item.acctName}}&nbsp;
                                    <template v-if="item.mobile">(Tel:{{item.mobile}})</template>
                                </span>
                            </p>
                        </el-col>
                    </el-row>
                </div>
                <!-- 要货清单 -->
                <div class="order-list">
                    <el-row>
                        <el-col>
                            <div class="order-info-title">要货清单</div>
                        </el-col>
                    </el-row>

                    <div class="table">
                        <table>
                            <thead>
                                <tr>
                                    <td width="100">申请单序号</td>
                                    <td>商品名/型号</td>
                                    <td>剩余可要货数量</td>
                                    <td>本次要货数量</td>
                                    <td>使用标段或部位</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(row,_index) in order.requireDetailList" :key="_index">
                                    <td>{{row.no}}</td>
                                    <td>
                                        <div class="order-name">
                                            <div class="left">
                                                <img :src="row.picUrl" v-error-img>
                                            </div>
                                            <div class="right">
                                                <p>{{ row.skuName }}</p>
                                                <p>型号：{{row.skuModel}}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td>{{row.requireLeft}}{{row.unit}}</td>
                                    <td>{{row.applyCount}}{{row.unit}}</td>
                                    <td>{{row.location}}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="remarks">
                        <span>采购商留言</span>
                        <textarea maxlength="200" rows="1" v-model="order.requireMsg" placeholder="限制200字"></textarea>
                    </div>
                </div>
                <!-- 要货单信息 -->
                <div class="order-total">
                    <p style="font-weight:bold;color:#444;">要求到货时间：
                        <span class="red-font">{{order.requireTimeFrom|datetime}} ~ {{order.requireTimeTo|datetime}}</span>
                    </p>
                    <p>送货至：{{order.consigneeAddr}}</p>
                    <p>收货人：{{order.consigneeName}}&nbsp;{{order.consigneeMobile}}</p>
                </div>
            </div>
        </div>

        <FixBottom class="bottom">
            <p>共{{orderList.length}}款货品</p>
            <div class="fr">
                <el-button size="small" type="primary" @click="handleBatch">批量创建要货单</el-button>
            </div>
        </FixBottom>

        <Page-nav :navigation="navigation" :change="0"></Page-nav>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Header from "@/components/base/Header";
import ViceHeader from "@/components/base/ViceHeader";
import Loading from "@/components/base/Loading";
import PageNav from "@/components/order/PageNav";
import FixBottom from "@/components/base/FixBottom";

import { InterfaceService } from "@/services/api";
export default {
    components: {
        Header,
        ViceHeader,
        Loading,
        PageNav,
        FixBottom
    },
    data() {
        return {
            isLoading: false,
            flow: [
                {
                    name: "批量发起要货单",
                    active: true,
                    next: true
                },
                {
                    name: "确认并签署要货单",
                    active: false,
                    next: true
                },
                {
                    name: "提交要货单",
                    active: false,
                    next: false
                }
            ],
            navigation: [
                {
                    name: "第1组",
                    position: "batch-goods-num-"
                }
            ],
            orderList: [],
            applyNo: "",
            constructorCorpId: "",
        };
    },
    methods: {
        handleBatch() {
            this.batchLaunchGoods();
        },
        // 过滤角色
        filterRole(list = []) {
            const roles = ["00", "10", "21", "01", "30", "20"];
            return list.filter(item => {
                return roles.indexOf(item.role) !== -1;
            });
        },
        getList(list) {
            const params = {
                applyNo: this.applyNo,
                applyDetailList: list
            };
            InterfaceService.getInitRequireList(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.orderList = data.respData.requireList || [];
                        this.orderList.forEach(item => {
                            item.requireDetailList.forEach(_item => {
                                _item.requireLeft = +_item.requireLeft;
                                _item.applyCount = +_item.applyCount;
                            });
                        });
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        batchLaunchGoods() {
            let params = {
                applyList: []
            };
            this.orderList.forEach(item => {
                let requireList = [];
                if (item.requireDetailList) {
                    item.requireDetailList.forEach(_item => {
                        let _obj = {
                            id: _item.id,
                            applyNo: this.applyNo,
                            skuId: _item.skuId,
                            requireCount: _item.applyCount,
                            location: _item.location,
                            remark: _item.remark
                        };
                        requireList.push(_obj);
                    });
                }

                let obj = {
                    orderNo: item.orderNo,
                    addressId: item.addressId,
                    requireTimeFrom: item.requireTimeFrom,
                    requireTimeTo: item.requireTimeTo,
                    requireMsg: item.requireMsg,
                    constructorCorpId: this.constructorCorpId,
                    requireList: requireList
                };
                params.applyList.push(obj);
            });
            InterfaceService.requireDeliverGoods(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        const list = data.respData.requireList;
                        this.$router.push({
                            path: "/batchLaunchGoodsSuccess",
                            query: {
                                list: JSON.stringify(list)
                            }
                        });
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        init() {
            this.applyNo = this.$route.query.applyNo;
            this.constructorCorpId = this.$route.query.constructorCorpId;
            const list = this.$route.query.list
                ? JSON.parse(this.$route.query.list)
                : [];
            this.getList(list);
        }
    },
    mounted() {
        this.init();
    }
};
</script>

<style lang="scss" scoped>
.order-content {
    margin-bottom: 40px;
}
.order-info-title {
    margin: 5px -10px;
    margin-bottom: 20px;
    padding: 0 10px;
    font-size: 14px;
    border-left: 3px solid #000;
    line-height: 12px;
}

.table {
    margin-bottom: 2px;
    　 /deep/ .el-button {
        font-size: 12px;
    }

    width: 100%;
    line-height: 23px;
    font-size: 12px;
    table {
        width: 100%;
    }
    td {
        padding: 14px 10px;
        vertical-align: middle;
        word-break: break-word;
    }

    thead {
        text-align: center;
        white-space: nowrap;
        font-size: 14px;
        color: #909399;
    }

    tbody {
        text-align: center;

        tr:hover {
            background: #e8f3fd;
        }

        td {
            border-bottom: 1px solid #ffffff;
            background: #f5f5f5;
        }
    }

    tr.offline {
        background: #cccccc;
    }
}

.order-name {
    display: inline-flex;
    width: 100%;
    vertical-align: top;
    line-height: 20px;

    img {
        width: 75px;
        height: 75px;
    }

    a:hover {
        text-decoration: underline;
        color: #0082ff;
    }

    .left {
        margin-right: 10px;
    }

    .right {
        text-align: left;

        p:first-child {
            margin-bottom: 10px;
        }
        p:last-child {
            word-break: break-all;
            max-height: 40px;
            overflow: hidden;
            color: #969799;
        }
    }
}

.order-info {
    margin-bottom: 20px;
    padding-bottom: 20px;
    line-height: 25px;
    font-size: 12px;
    border-bottom: 1px solid #cccccc;

    /deep/ .el-col {
        padding: 0 10px;
    }

    p {
        width: 100%;
        display: flex;
        padding-right: 10px;
        word-break: break-word;
        white-space: normal;

        & > span {
            display: inline-block;
            flex: 1 1 0%;
        }
    }

    label {
        white-space: nowrap;
        color: #888888;
    }

    a {
        white-space: nowrap;
        color: #0082ff;
    }
}

.order-title {
    height: 50px;
    margin-bottom: 20px;
    border-bottom: 3px solid #ffd64e;
    font-size: 16px;
    font-weight: 700;
    line-height: 0;
    background-color: #f5f5f5;
    color: #555;

    .big {
        font-size: 80px;
        font-style: italic;
        font-weight: 900;
        transform: translateY(10px);
    }
}

.order-list {
    margin-bottom: 20px;

    /deep/ .el-col {
        padding: 0 10px;
    }
}

.order-total {
    padding: 20px 40px;
    border-top: 1px solid #e2e2e2;
    text-align: right;
    font-size: 12px;
    line-height: 25px;
    color: #888888;
    background: #f5f5f5;

    label {
        display: block;
        color: #444444;
    }

    .red-font {
        color: #e94650;
    }
}

.remarks {
    margin-top: 2px;
    padding: 20px;
    background: #f5f5f5;
    span {
        color: #909399;
    }

    textarea {
        width: 56%;
        height: 28px;
        border: 1px solid #ddd;
        background-color: #fff;
        text-indent: 12px;
        margin-left: 10px;
        margin-right: 18px;
        resize: none;
        vertical-align: middle;
        text-indent: 0px;
        line-height: 22px;
        overflow: auto;
    }
}

.bottom {
    p {
        float: left;
        padding: 10px 0;
        font-size: 14px;
        color: #ffffff;
    }
}
</style>
