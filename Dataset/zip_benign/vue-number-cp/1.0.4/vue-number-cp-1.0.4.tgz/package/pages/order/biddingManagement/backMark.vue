<template>
  <div class="back-mark-container">
    <Header></Header>
    <SearchBar :search-type="5" :progress="this.biddingName.length > 40 ? `${this.biddingName.slice(0,39)}...` : this.biddingName" :title="biddingName" :is-border-bottom="true" :product-create-process="2"></SearchBar>
    <div class="center" :style="{minHeight:contentHeight+'px'}">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <div class="btn-tab-center">
        <el-button type="primary" @click="handleBtnClick(1)" :title="tableGrid.rowData && !tableGrid.rowData.length ? '暂无数据' : !computedIsPrincipal ? '负责人才能查看比价' : computedBtnIsDisabled?'比价数据至少得有两条' : ''" :disabled="!computedIsPrincipal || computedBtnIsDisabled">智能比价</el-button>
        <el-button @click="handleBtnClick(2)" :title="tableGrid.rowData && !tableGrid.rowData.length ? '暂无数据' : !computedIsPrincipal ? '负责人才能下载清单' :''" :disabled="(tableGrid.rowData && !tableGrid.rowData.length) || !computedIsPrincipal">批量下载清单</el-button>
      </div>
      <!-- 表格数据显示 -->
      <OrderTable :columnDefs="tableGrid.columnDefs" :operation="tableGrid.operation" :rowData="tableGrid.rowData"></OrderTable>
    </div>

    <!-- 填写清单密码弹窗 -->
    <el-dialog class="dialog dialog-drafts" title="填写清单密码" :append-to-body="true" :lock-scroll="true" :visible.sync="showOpenBidCode" width="50%" center :close-on-click-modal="false">
      <div class="drafts-list">
        <p class="title">
          清单密码是由供应商设置, 确保报价不会过早泄露的密匙。
        </p>
        <div :class="['body', {inputError: inputError}]">
          <span>请输入清单密码</span>
          <div class="input-center">
            <el-input v-model="openBidCode" maxlength="6" @input="handleInput" />
            <p class="red">{{inputErrorMsg}}</p>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" class="w100" @click="handleDiaBtnConfim">确认</el-button>
        <el-button size="small" class="w100" @click="showOpenBidCode = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 在线智能清标 -->
    <el-dialog class="dialog dialog-drafts" title="智能比价" :append-to-body="true" :lock-scroll="true" :visible.sync="showOnlineIntelligence" width="50%" center :close-on-click-modal="false">
      <div class="drafts-list">
        <div :class="['body', {inputError: inputError}]">
          <span>比价模型</span>
          <div class="input-center">
            <el-select :style="{width:'300px'}" v-model="modelSelectValue" filterable placeholder="" @change="handleOnlineSelect(1)">
              <el-option v-for="(item, idx) in modelList" :key="idx" :label="item.modelName" :value="item.modelId">
              </el-option>
            </el-select>
          </div>
        </div>
        <div :class="['body', {inputError: inputError}]">
          <span>对比字段</span>
          <div class="input-center">
            <el-select :style="{width:'300px'}" v-model="compareKeySelectValue" filterable placeholder="" @change="handleOnlineSelect(2)">
              <el-option v-for="(item, idx) in modelList.filter(f=>f.modelId === modelSelectValue)[0] && modelList.filter(f=>f.modelId === modelSelectValue)[0].compareKeyList" :key="idx" :label="item.fieldName" :value="item.fieldId">
              </el-option>
            </el-select>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer clearfloat">

        <div>
          <el-button type="primary" size="small" class="w100 has-tips" @click="handleOnlineBtnConfim(1)">
            报告预览
            <div class="tips">
              <span class="hand">"<i class="red">报告预览</i>": 打开浏览窗口后文件生成较缓慢，请耐心等待!</span>
            </div>
          </el-button>
          <el-button type="primary" size="small" class="w100" @click="handleOnlineBtnConfim(2)">报告下载</el-button>
          <el-button size="small" class="w100" @click="showOnlineIntelligence = false">取消</el-button>
        </div>
      </div>

    </el-dialog>

    <!-- 下载全部清单 -->
    <el-dialog class="dialog dialog-drafts download-all-dialog" title="下载全部清单" :append-to-body="true" :lock-scroll="true" :visible.sync="showDownAllDetailed" width="50%" center :close-on-click-modal="false">
      <div class="drafts-list">
        <div :class="['body']">
          <el-checkbox-group v-model="downAllCheckList" @change="downAllCheckListChange">
            <el-checkbox :label="item.id" v-for="(item, idx) in downAllDetailedList" :key="idx"> {{item.docName}}</el-checkbox>
          </el-checkbox-group>
        </div>
        <div class="download-all-check">
          <el-checkbox v-model="allcheckDownload" @change="handleAllCheckChange">{{allcheckDownload ? '取消全选' : '全选'}}</el-checkbox>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" class="w100" @click="handleDownloadAllConfim">下载</el-button>
        <el-button size="small" class="w100" @click="showDownAllDetailed = false">取消</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import Loading from "@/components/base/Loading";
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Breadcrumb from "@/components/base/Breadcrumb";
import OrderTable from "@/components/order/orderTable"
import { InterfaceService } from "@/services/api"
import CryptoJS from 'crypto-js';
import { viewFile } from '@/utils/orderUtil';
import accountMixin from "@/mixins/account";

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    Header,
    SearchBar,
    Breadcrumb,
    OrderTable
  },
  data() {
    return {
      isLoading: false,
      breadcrumb: [],
      tableGrid: {},
      openBidCode: '', // 清单密码
      showOpenBidCode: false, // 是否展示填写清单密码
      inputError: false, // 输入错误
      inputErrorMsg: '',
      pageIndex: 1,
      pageSize: 10,
      total: 0,
      biddingCorpId: '',
      showOnlineIntelligence: false, // 在线智能清标弹窗
      showDownAllDetailed: false, // 下载全部清单弹窗
      modelList: [], // 比价模型
      modelSelectValue: '',
      compareKeySelectValue: '',
      modelList1: '',
      downAllCheckList: [],
      downAllDetailedList: [],
      downloadBatchList: [],
      allcheckDownload: false,
      tenderName: '', // 标名
      contentHeight: 900,
      biddingName: ''
    }
  },
  computed: {
    // 当前用户 acctId
    acctId() {
      return (
        this.$store.state.userInfo && this.$store.state.userInfo.acctId || ''
      )
    },
    // 是否可以比价
    computedIsFullyUnlocked() {
      // 已回标数量
      let biddingStatusLen = 0,
        // 已解锁数量
        checkCodeSettingFlgLen = 0

      this.tableGrid.rowData && this.tableGrid.rowData.map(rowItem => {
        rowItem.biddingStatus !== 'init' && biddingStatusLen++
        rowItem.checkCodeSettingFlg === '1' && checkCodeSettingFlgLen++
      })
      // 已回标数量 等于 已解锁数量 说明可以 比价
      return biddingStatusLen === checkCodeSettingFlgLen
    },
    // 是否能比价或下载
    computedBtnIsDisabled() {
      let resutl = true
      try {
        resutl = this.tableGrid.rowData && this.tableGrid.rowData.filter(f => f.checkCodeSettingFlg != '0' && f.biddingStatus != 'init').length < 2
      } catch (error) { console.warn(`computedBtnIsDisabled =>`, error) }

      return resutl
    },
    // 是否是负责人
    computedIsPrincipal() {
      return this.tableGrid.rowData && this.tableGrid.rowData.filter(f => f.personInChargeList.some(e => this.mxAcctIdList.includes(e.acctId))).length
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.breadcrumb = [
        { name: '比价管理', path: '/purchaserCenter/biddingMaterial' },
        { name: '查看供应商报价' },
      ]


      this.biddingName = this.$route.query && decodeURI(this.$route.query.biddingName) || ''

      this.getTenderList()
      this.setTableDataByTab()
    },

    setMinHeight() {
      let h = window.innerHeight ||
        document.documentElement.clientHeight ||
        document.body.clientHeight

      this.contentHeight = (h - 34 - 194) > 900 ? h - 34 - 160 : 900
    },
    /**
     * 输入框input事件
     */
    handleInput() {
      this.setInputError()
    },

    /**
     * 清单密码 确认点击
     */
    handleDiaBtnConfim() {
      if (!this.setInputError()) return
      this.unlockTenderCode()
    },

    /**
     * 在线智能清标 - 按钮
     * @param state 1: 报告预览  2: 报告下载
     */
    async handleOnlineBtnConfim(state) {

      if (!this.modelSelectValue) {
        this.$message.error('请选择比价模型')
        return
      }
      if (!this.compareKeySelectValue) {
        this.$message.error('请选择比价字段')
        return
      }

      const result = await this.getParityResult()

      if (!result) {
        this.$message.error('未找到报告')
        return
      }
      if (state === 1) {
          if (result.url) {
            viewFile(result.url)
          }
      } else {
        this.$download([{ url: result.url, name: result.name || '比价报告.xlsx' }])
      }

    },

    /**
     * 下载全部清单
     */
    handleDownloadAllConfim() {
      if (!this.downAllCheckList.length) {
        this.$message.error('请勾选需要下载的清单')
        return
      }
      const temp = []

      this.downAllCheckList.forEach(checkItem => {
        for (let i = 0, len = this.downAllDetailedList.length; i < len; i++) {
          const listItem = this.downAllDetailedList[i]
          if (listItem.id === checkItem) {
            listItem.url = listItem.attachUrl
            listItem.name = listItem.docName
            temp.push(listItem)
          }
        }
      })
      this.$download(temp).then(result => this.showDownAllDetailed = false)
    },

    /**
     * 在线智能清标 - 选择
     * @param state 1: 比价模型  2: 对比字段
     */
    handleOnlineSelect(state) {
      if (state === 1) {
        this.modelList.map(m => this.$set(m, 'selectState', false))
        this.modelList.map(m => m.modelId === this.modelSelectValue && (m.selectState = true))
        try {
          this.compareKeySelectValue = this.modelList.filter(f => f.selectState === true)[0].compareKeyList[0].fieldId
        } catch (error) {
          this.compareKeySelectValue = ''
          console.warn('try: compareKeySelectValue =>', error)
        }

      } else {
        console.log(this.modelSelectValue, this.compareKeySelectValue);
      }
    },

    /**
     * 设置错误提醒
     */
    setInputError() {
      let state = false

      if (this.openBidCode.replace(/\s*/g, '').length < 6) {
        this.inputError = true
        this.inputErrorMsg = '请输入6位数清单密码'
        // 请输入6位正确的清单密码
      } else {
        this.inputError = false
        this.inputErrorMsg = ''
        state = true
      }

      return state
    },

    /**
    * 根据点击tab 设置相应表格数据
    */
    setTableDataByTab() {
      let tableGrid = {}, rowData = []
      const __this = this

      tableGrid = {
        columnDefs: [
          { headerName: '序号', field: 'tenderSerial', w: '5%' },
          { headerName: '供应商', field: 'biddingCorpName', w: '30%' },
          { headerName: '是否上传清单', field: 'biddingStatus', w: '15%', filter(item) { return item.biddingStatus === 'init' ? '否' : '是' } },
          { headerName: '最新报送时间', field: 'biddingDt', w: '15%' },
          { headerName: '联系方式', field: 'biddingAcctName', w: '15%', filterCellHtml(item) { return `<b>${item.biddingAcctName || ''}</b><p>${item.biddingAcctMobile || '--'}</p>` } },
        ],
        operation: {
          enable: true,
          w: '20%',
          align: 'right',
          btnList: [
            {
              // BUG #4944 智能选型：回标文件列表，供应商未回标时，“填写清单密码”操作需置灰
              rowBtnCellFilter(item) { return item.checkCodeSettingFlg != '1' && item.biddingStatus != 'init' && !item.personInChargeList.every(e => !(__this.mxAcctIdList.includes(e.acctId))) },
              btnName: '填写清单密码',
              btnFn: (item) => {
                this.biddingCorpId = item.biddingCorpId
                this.openBidCode = ''
                this.showOpenBidCode = true
              }
            },
            {
              btnName: '下载最新清单',
              // 解锁状态 为 未解锁 || 回标转 为 初始化 || 不是负责人  不能查看
              disabled(item) { return item.checkCodeSettingFlg == '0' || item.biddingStatus == 'init' || item.personInChargeList.every(e => !(__this.mxAcctIdList.includes(e.acctId))) },
              disabledNotice(item) { return item.personInChargeList.every(e => !(__this.mxAcctIdList.includes(e.acctId))) ? '负责人才能下载' : item.checkCodeSettingFlg == '0' || item.biddingStatus == 'init' ? '尚未解锁清单, 不能下载' : '' },
              btnFn: (item) => {
                this.$download([{ name: item.documentName || '最新清单.xlsx', url: item.attachUrl || '' }]).then(result => {
                  this.$message.success('已下载')
                }).catch(err => {
                  this.$message.error('下载失败')
                })
              }
            },
            {
              btnName(item) {
                return `下载全部清单`
              },
              disabled(item) { return item.checkCodeSettingFlg == '0' || item.biddingStatus == 'init' || item.personInChargeList.every(e => !(__this.mxAcctIdList.includes(e.acctId))) },
              disabledNotice(item) { return item.personInChargeList.every(e => !(__this.mxAcctIdList.includes(e.acctId))) ? '负责人才能下载' : item.checkCodeSettingFlg == '0' || item.biddingStatus == 'init' ? '尚未解锁清单, 不能下载' : '' },
              btnFn: async (item) => {
                this.biddingCorpId = item.biddingCorpId
                const result = await this.getTenderFiles() || []
                result.map((m, idx) => m.id = idx)
                this.downAllDetailedList = result
                this.showDownAllDetailed = true
                // 初始化弹窗数据状态
                this.allcheckDownload = false
                this.downAllCheckList = []
              }
            }
          ]
        },
      }
      this.$set(this.tableGrid, 'columnDefs', tableGrid.columnDefs)
      this.$set(this.tableGrid, 'operation', tableGrid.operation)
    },

    /**
     * 头部按钮点击
     */
    handleBtnClick(state) {
      try {
        const accIdMatchState = this.tableGrid.rowData.some(m => m.personInChargeList.some(s => this.mxAcctIdList.includes(s.acctId)))
        if (!accIdMatchState) {
          this.$message.error(`负责人才能${state === 1 ? '比价' : '下载'}`)
          return
        }
      } catch (error) { console.warn(`handleBtnClick =>`, error) }
      switch (state) {
        case 1:
          if (!this.computedIsFullyUnlocked) {
            this.$message.error('请解锁全部清单密码, 再进行比价')
            return
          }

          if ((!this.tableGrid.rowData.length) || (this.tableGrid.rowData && this.tableGrid.rowData.length <= 1)) {
            this.$message.error('暂无数据可供比价')
            return
          }

          this.modelSelectValue = ''
          this.compareKeySelectValue = ''
          this.showOnlineIntelligence = true
          this.getRatioModel()
          break
        case 2:
          if (!this.downloadBatchList.length) {
            this.$message.error('暂无数据可供下载')
            return
          }
          this.downloadRenderPackage()
          break
      }
    },

    /**
     * 分页change
     */
    handleCurrentChange() {
      this.getTenderList()
    },

    /**
     * 下载全部清单 - 全选
     */
    handleAllCheckChange() {
      this.downAllCheckList = []
      if (this.allcheckDownload) {
        this.downAllDetailedList.forEach(m => {
          this.downAllCheckList.push(m.id)
        })
      }
    },

    /**
     * 下载全部清单 - 选择
     */
    downAllCheckListChange() {
      this.allcheckDownload = this.downAllCheckList.length === this.downAllDetailedList.length
    },

    /**
     * 查询回标文件list
     */
    getTenderList() {
      const param = {
        tenderNo: this.$getRootScope('tenderNo') || ''
      }

      InterfaceService.getTenderList(param, data => {
        if (data && data.respData && data.respData.respCode === '0000') {
          const respData = data.respData,
            rowData = respData.tenderList || []
          // downloadBatchList
          this.downloadBatchList = []
          this.tenderName = ''
          rowData.map((m, i) => {
            m.tenderSerial = i + 1
            this.tenderName = `${m.tenderName}.zip`
            if (m.checkCodeSettingFlg == '1' && m.biddingStatus != 'init') {
              // 组装批量下载数据
              this.downloadBatchList.push({
                docUrl: m.documentUrl || '',
                docName: m.documentName || '',
              })
            }

          })
          this.$set(this.tableGrid, 'rowData', rowData)
        } else {
          this.$message.error(data.respData && data.respData.respMsg || '')
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

    /**
     * 操作 - 下载
     */
    getTenderFiles() {
      return new Promise(resolve => {
        const param = {
          tenderNo: this.$getRootScope('tenderNo') || '',
          supplierId: this.biddingCorpId || '',
          docTypeList: ['biddingList']
        }

        InterfaceService.getTenderFiles(param, data => {
          if (data && data.respData && data.respData.respCode === '0000') {
            resolve(data.respData.docList)
          } else {
            this.$message.error(data.respData && data.respData.respMsg || '')
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
      })
    },

    /**
     * 解锁清单密码
     */
    unlockTenderCode() {
      const param = {
        tenderNo: this.$getRootScope('tenderNo') || '',
        checkCodeList: [{
          supplierId: this.biddingCorpId || '',
          checkCode: CryptoJS.MD5(this.openBidCode || '').toString()
        }]
      }

      InterfaceService.unlockTenderCode(param, data => {
        if (data && data.respData && data.respData.respCode === '0000') {
          const unlockList = data.respData.unlockList || []
          if (unlockList.length !== 0) {
            const itemList = unlockList.filter(f => f.supplierId === this.biddingCorpId)[0] || []
            if (itemList.unlocked === '0') {
              this.$message.error(itemList.failReason || '')
              return
            }
            this.$message.success('填写正确, 目标文件已解锁')
            this.showOpenBidCode = false
            this.getTenderList()
          }
        } else {
          this.$message.error(data.respData && data.respData.respMsg || '')
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },

    /**
     * 查询比价模型
     */
    getRatioModel() {
      const param = {
        tenderNo: this.$getRootScope('tenderNo') || ''
      }

      InterfaceService.getRatioModel(param, data => {
        if (data && data.respData && data.respData.respCode === '0000') {
          this.modelList = data.respData.modelList || []

          if (this.modelList.length) {
            try {
              this.modelSelectValue = this.modelList[0].modelId
              this.compareKeySelectValue = this.modelList[0].compareKeyList[0].fieldId
            } catch (error) {
              console.error('InterfaceService.getRatioModel=>', error);
            }
          }
        } else {
          this.$message.error(data.respData && data.respData.respMsg || '')
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },

    /**
     * 下载比价模型
     */
    getParityResult() {
      return new Promise(resolve => {
        const param = {
          tenderNo: this.$getRootScope('tenderNo') || '',
          modelId: this.modelSelectValue || '',
          fieldId: this.compareKeySelectValue || ''
        }

        InterfaceService.getParityResult(param, data => {
          if (data && data.respData && data.respData.respCode === '0000') {
            resolve({
              name: data.respData.attachName,
              url: data.respData.attachUrl
            })
          } else {
            this.$message.error(data.respData && data.respData.respMsg || '')
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })

      })
    },

    /**
     * 打包下载
     */
    downloadRenderPackage() {
      const param = {
        tenderNo: this.$getRootScope('tenderNo') || '',
        documentList: this.downloadBatchList || []
      }

      InterfaceService.downloadRenderPackage(param, data => {
        if (data && data.respData && data.respData.respCode === '0000') {
          this.$download([{
            url: data.respData.fileUrl || '',
            name: this.tenderName || '清单.zip'
          }])
        } else {
          this.$message.error(data.respData && data.respData.respMsg || '')
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  }
}
</script>
<style scoped lang="scss">
.has-tips {
  position: relative;
}
.tips {
  position: absolute;
  text-align: left;
  top: -20px;
  left: 0;
  color: #333 !important;
}
/deep/ .el-dialog__footer {
  padding-top: 40px;
}
.back-mark-container {
  position: relative;
  margin-bottom: 100px;
  .center {
    position: relative;
    width: 1190px;
    margin: 0 auto;
  }
  .btn-tab-center {
    margin-bottom: 12px;
  }
}
.dialog-drafts {
  font-weight: bold;
  .title {
    text-align: center;
  }

  /deep/ .el-checkbox + .el-checkbox {
    margin-left: 0 !important;
    margin-top: 10px !important;
  }
  .body {
    display: flex;
    width: 410px;
    margin: 40px auto 20px;
    align-items: center;
    & > span {
      width: 90px;
      display: block;
    }
    &.inputError {
      /deep/ .el-input__inner {
        border-color: #df0a0a;
      }
    }
  }
  .input-center {
    $labelWidth: 90px;
    width: calc(100% - #{$labelWidth});
    .red {
      margin-top: 6px;
      position: absolute;
    }
  }
  /deep/.download-all-dialog {
    ::-webkit-scrollbar-button {
      height: 0;
    }
    ::-webkit-scrollbar {
      width: 4px;
    }
    .el-dialog__header:before {
      height: 3px !important;
      background: #ffd64e !important;
    }
    .el-checkbox-group {
      label {
        margin-left: 0 !important;
        text-align: left;
      }
    }
    .el-dialog__header {
      padding-top: 40px !important;
    }
    .el-dialog__title {
      font-size: 14px !important;
      border-bottom: 3px solid #000 !important;
      position: absolute !important;
      left: 21px !important;
      padding-bottom: 6px !important;
      top: 21px !important;
      padding-left: 12px !important;
      padding-right: 12px !important;
    }
    .drafts-list {
      .body {
        margin: 10px auto;
        max-height: 300px;
        min-height: 32px;
        overflow: auto;
        width: 90%;
        align-items: self-start !important;
        .el-checkbox-group {
          display: flex;
          flex-direction: column;
        }
      }
      .download-all-check {
        border-top: 1px solid #eaeaea;
        padding-left: 46px;
        padding-top: 13px;
        text-align: left;
      }
    }
  }
  .w100 {
    width: 100px !important;
  }
}
</style>
