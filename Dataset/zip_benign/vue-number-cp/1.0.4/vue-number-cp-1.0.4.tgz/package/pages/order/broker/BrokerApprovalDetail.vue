<template>
    <div>
        <div class="unShowPrint">
        <Header :is-white-bg="false"></Header>
        <SearchBar :search-type="5" :progress="'详情页'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
        <div class="inner-container">
            <!-- 合同流程 -->
            <OrderProcess v-if="approvalInfo.approveFlowList" :isApproval="true" :orderStatus="approvalInfo.orderStatus" :processList="approvalInfo.approveFlowList"></OrderProcess>
             <!--合同状态 -->
            <ApprovalStatusInfo :executionId="executionId" :approvalInfo="approvalInfo" :fwStatus="this.approvalInfo&&this.approvalInfo.fwStatus||''" :canFwRoleList="canFwRoleList" :managerApproval="managerApproval" @refresh="handleRefreshStatus"  @dandleClickPrint="dandleClickPrint"></ApprovalStatusInfo>
            <!-- <div class="circulation-opinion" v-if="showRejectCommet">
                <div class="opinion-content">
                    <div class="fl">退回原因：</div>
                    <div class="fr" style="text-align: right">
                        <label>退回人：</label>
                        <span>{{lastFailOperator}}</span>
                    </div>
                    <div class="reason">{{lastFailComment}}</div>
                </div>
            </div>
            <div class="circulation-opinion" v-if="showCloseCommet">
                <div class="opinion-content">
                    <div class="fl">关闭原因：</div>
                    <div class="fr" style="text-align: right">
                        <label>关闭人：</label>
                        <span>{{lastFailOperator}}</span>
                    </div>
                    <div class="reason">{{lastFailComment}}</div>
                </div>
            </div> -->
             <!--合同信息 -->
            <PanelTitle :tabs="tabs" @select="handleSelectTab" class="panel-title"></PanelTitle>
            <div class="order-info" v-if="tab == '1'">
                <el-row>
                    <el-col :span="12">
                        <p>
                            <label>合同编号：</label>{{approvalInfo.orderNo}}
                        </p>
                    </el-col>
                    <el-col :span="12">
                        <p>
                            <label>合同名称：</label>
                            <span>
                            <span>《{{approvalInfo.contractName}}》</span>
                            <!--<span v-if="executionId" class="blue pointer"  @click="handleBatchDownload()">审批资料下载</span>-->
                            <span v-if="executionId" class="blue pointer"  @click="handleBatchDownload()">审批资料查看及下载</span>
                        </span>
                        </p>
                    </el-col>
                </el-row>
                <!--<el-row v-if="role==='B'" v-for="(item,index) in filterERP(approvalInfo.externalSysList)" :key="index">-->
                <el-row>
                    <el-col :span="12" v-for="(item,index) in filterERP(approvalInfo.externalSysList)" :key="index">
                        <p v-if="item.sysCode==='ERP'">
                            <label>明源ERP编号：</label>{{item.externalCode}}
                            <i class="red" v-html="filterExternalSys(item)"></i>&nbsp;&nbsp;
                        </p>
                    </el-col>
                    <el-col :span="12">
                        <p>
                            <a class="blue hand" @click="downloadContract()">查看合同文件</a>
                            <!--<em style="margin-right: 30px" @click="getContractInfo('S')">货物采购合同预览</em>-->
                            <!--<em @click="getContractInfo('B')">货物供应合同预览</em>-->
                        </p>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <p>
                            <label>合同类别：</label>{{projectCate}}
                        </p>
                    </el-col>
                    <el-col :span="12">
                        <p>
                            <label>合同创建时间：</label>
                            <span>
                                <span>{{approvalInfo.orderTime}}</span>
                            </span>
                        </p>
                    </el-col>
                </el-row><el-row>
                <el-col :span="12">
                    <p v-if="approvalInfo.cityCompany">
                        <label>合约经办人：</label>{{approvalInfo.cityCompany}}&nbsp;{{approvalInfo.orderAcctName}}
                        <span v-if="approvalInfo.orderAcctTel">(Tel:{{approvalInfo.orderAcctTel}})</span>
                    </p>
                    <p v-else>
                        <label>合约经办人：</label>{{approvalInfo.orderAcctName}}
                        <span v-if="approvalInfo.orderAcctTel">(Tel:{{approvalInfo.orderAcctTel}})</span>
                    </p>
                </el-col>
            </el-row>

                <div class="line"></div>
                <div class="order-info-title">合同价款</div>
                <table class="tax">
                    <tr>
                        <td>合同价款（不含税）：{{approvalInfo.outContractFee | formatMoney}}元</td>
                        <td>税率：{{approvalInfo.orderTaxRateRange}}</td>
                        <!--<td rowspan="2" align="center" class="add-tax">加价费率：<em class="red" style="font-size: 22px;" v-if="approvalInfo.addRate">{{approvalInfo.addRate|percent}}</em></td>-->
                    </tr>
                    <tr>
                        <td class="bold">合同价款（含税）：<em class="red">{{approvalInfo.outContractFeeWithTax | formatMoney}}元</em></td>
                        <td>税额：{{approvalInfo.outContractTax | formatMoney}}元</td>
                    </tr>
                </table>
                <div class="line"></div>
                <div class="order-info-title">合同签约信息</div>
                <el-row>
                    <el-col :span="12">
                        <p>
                            <label>甲方单位：</label>{{firstParty.corpName}}
                        </p>
                    </el-col>
                    <el-col :span="12">
                        <p>
                            <label>
                                <!--甲方单位合同用印人：</label>{{firstParty.acctName}}-->
                                甲方单位法定代表人或授权代理人：</label>{{firstParty.acctName}}
                        </p>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <p>
                            <label>乙方单位：</label>{{secondParty.corpName}}
                        </p>
                    </el-col>
                    <el-col :span="12">
                        <p>
                            <!--<label>乙方单位合同用印人：</label>{{secondParty.acctName}}-->
                            <label>乙方单位法定代表人或授权代理人：</label>{{secondParty.acctName}}
                        </p>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <p>
                            <label>签约日期：</label>{{approvalInfo.signTime}}
                        </p>
                    </el-col>
                    <el-col :span="12">
                        <p>
                            <label>合约申报经办人：</label>{{approvalInfo.signAcctName}}
                        </p>
                    </el-col>
                </el-row>
                <div class="line"></div>
                <div class="order-info-title">供货周期</div>
                <el-row>
                    <el-col :span="12">
                        <p>
                            <label>计划供货周期：</label>{{approvalInfo.supplyFrom}}至{{approvalInfo.supplyTo}}
                        </p>
                    </el-col>
                    <el-col :span="12">
                        <p>
                            <label>备货周期：</label><span v-if="approvalInfo.prepareCycle">{{approvalInfo.prepareCycle}}日历天</span>
                        </p>
                    </el-col>
                </el-row>
                <div class="line"></div>
                <div class="order-info-title">供应商收款账户信息</div>
                <el-row>
                    <el-col :span="8">
                        <p>
                            <label>开户名称：</label>{{bankAcctInfo.acctName}}
                        </p>
                    </el-col>
                    <el-col :span="8">
                        <p>
                            <label>开户行行号：</label>{{bankAcctInfo.bankCode | formatCardNum}}
                        </p>
                    </el-col>
                    <el-col :span="8">
                        <p>
                            <label>联系人：</label>{{bankAcctInfo.contact}}
                        </p>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8">
                        <p>
                            <label>开户银行：</label>{{bankAcctInfo.bankName}}
                        </p>
                    </el-col>
                    <el-col :span="8">
                        <p>
                            <label>银行账号：</label><span class="red">{{bankAcctInfo.bankAcctNo | formatCardNum}}</span>
                        </p>
                    </el-col>
                    <el-col :span="8">
                        <p>
                            <label>联系方式：</label>{{bankAcctInfo.mobile | formatPhoneNumber("3 4 4")}}
                        </p>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8">
                        <p>
                            <label>开户行地址：</label>{{bankAcctInfo.provCodeDisp}}{{bankAcctInfo.cityCodeDisp}}{{bankAcctInfo.districtCodeDisp}}{{bankAcctInfo.bankAddr}}
                        </p>
                    </el-col>
                    <el-col :span="8">
                        <p>
                            <label>纳税人识别号：</label>{{bankAcctInfo.taxPayerId}}
                        </p>
                    </el-col>
                </el-row>
                <div class="line"></div>
                <div class="order-info-title">付款方式</div>
                <div class="payment" v-html="approvalInfo.pmtMethod || approvalInfo.paymentDescribe">
                    <!--{{approvalInfo.paymentDescribe}}-->
                </div>
            </div>
            <BrokerGoodsList :approvalInfo="approvalInfo" v-if="tab == '2'"></BrokerGoodsList>
        </div>
        <FixBottom v-if="fixedBottomActive && approvalButton">
        <!--<FixBottom>-->
            <div class="fix-bottom">
                <el-button type="primary" style="width: 120px;" @click="batchApproavlDialogVisible=true">同意</el-button>
                <el-button style="width: 120px;" @click="rejectedDialogVisible=true">退回</el-button>
                <!--<el-button style="width: 120px;" @click="$router.go(-1)">返回列表</el-button>-->
            </div>
        </FixBottom>
        <!-- 确认审批 -->
        <el-dialog class="dialog" title="合同审批" :append-to-body="true" :lock-scroll="true" :visible.sync="batchApproavlDialogVisible" width="840px" center :close-on-click-modal="false" :show-close="false" @close="entryNum = 0;comment = ''">
            <div class="f14" style="text-align: center">确认通过此合同审批吗？</div>
            <el-input style="margin: 20px 0;" type="textarea" v-model="comment" placeholder="请填写审批意见，300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm('Y')">同意</el-button>
                <el-button size="small" style="width: 100px" @click="batchApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--审批退回-->
        <el-dialog class="dialog" title="退回原因" :append-to-body="true" :lock-scroll="true" :visible.sync="rejectedDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;rejectedReason = ''">
            <div class="f14" style="text-align: left;padding-top: 15px;border-top: 1px solid #eee;">请填写退回的原因</div>
            <el-input style="margin: 20px 0;" type="textarea" v-model="rejectedReason" placeholder="请填写退回的原因，300字以内" clearable  :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button v-if="!managerApproval" type="primary" :disabled="!rejectedReason" size="small" style="width: 100px" @click="handleConfirm('N')">退回</el-button>
                <el-button v-if="managerApproval" type="primary" :disabled="!rejectedReason" size="small" @click="handleConfirm('N')">退回到招采合约</el-button>
                <el-button v-if="managerApproval" type="primary" :disabled="!rejectedReason" size="small" @click="handleCloseConfirm()">退回到城市公司</el-button>
            <el-button size="small" style="width: 100px" @click="rejectedDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--<Page-nav :navigation="navigation" v-if="requireList.length"></Page-nav>-->
        <BrokerApproval ref="brokerApproval"></BrokerApproval>
        <AttachmentManage ref="attachmentManage"></AttachmentManage>
        <Loading :is-loading="isLoading"></Loading>
        </div>
        <!--<div class="showPrint">-->
            <!--<BorkerApprovalPrint></BorkerApprovalPrint>-->
        <!--</div>-->
    </div>
</template>
<script>
    import Header from "@/components/base/Header";
    import SearchBar from "@/components/SearchBar";
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import ApprovalStatusInfo from "@/components/order/broker/ApprovalStatusInfo";
    import BrokerGoodsList from "@/components/order/broker/BrokerGoodsList";
    import CirculationOpinion from "@/components/order/broker/CirculationOpinion";
    import BorkerApprovalPrint from "@/components/order/broker/BorkerApprovalPrint";
    import OrderProcess from "@/components/order/OrderProcess";
    import FixBottom from "@/components/base/FixBottom";
    import { InterfaceService } from "@/services/api";
    import BrokerApproval from "@/components/order/broker//BrokerApproval";
    import AttachmentManage from '@/components/order/dialog/AttachmentManage'
    import accountMixin from '@/mixins/account';

    export default {
        mixins:[accountMixin],
        components: {
            Header,
            SearchBar,
            Loading,
            PanelTitle,
            ApprovalStatusInfo,
            OrderProcess,
            FixBottom,
            BrokerGoodsList,
            CirculationOpinion,
            BrokerApproval,
            AttachmentManage,
            BorkerApprovalPrint
        },
        data() {
            return {
                navigation: [
                    {
                        name: "合同信息",
                        position: "order-data-message"
                    },
                    {
                        name: "要货单批次信息",
                        position: "require-order-info"
                    }
                ],
                tab:"1",
                tabs: [
                    { label: "合同信息", index: 1, active: true },
                    { label: "货品清单", index: 2, active: false }
                ],
                isLoading: false,
                order: {},
                status: "",
                executionId: "",
                comment: "",
                managerApproval: false,
                orderNo: "",
                approvalInfo: {},
                showHandleLink: false,
                fixedBottomActive:false,
                batchApproavlDialogVisible:false,
                rejectedDialogVisible:false,
                approvalButton:false,
                showRejectCommet:false,
                showCloseCommet:false,
                revokeReason:'',
                projectCate:'',
                rejectedReason:'',
                newExecutionId:'',
                firstParty:{},
                secondParty:{},
                projectCateList:[],
                execFlowList:[],
                goodsList:[],
                entryNum:0,
                lastFailExecStatus:"",
                lastFailComment:"",
                lastFailOperator:"",
                lastFailTm:"",
                purchaseContractUrl:"",
                supplierContractUrl:"",
                procDefKey:"",
                canFwRoleList: [], // 可转发角色
                fwStatus: '',
                bankAcctInfo: {},
            };
        },
        computed: {
            userinfo() {
                return this.$store.state.userInfo;
            },
            role() {
                return this.$store.state.userInfo
                    ? this.$store.state.userInfo.bs
                    : 0;
            }
        },
        filters: {
            percent(val) {
                return (val * 100)+ "%";
            }
        },
        methods: {
            downloadContract(){
                this.$refs["attachmentManage"].open(this.approvalInfo);

            },
            // 合同排序
            handleSelectTab(tab){
                this.tab = tab.index;
            },
            // 审批确认
            handleConfirm(type) {
                let comment ;
                this.comment ? comment = this.comment : comment = "同意";
                let executionList = [];
                if (type == 'Y') {
                    executionList.push({
                        executionId: this.executionId,
                        isAgree: "Y",
                        comment: comment
                    })
                } else if (type == 'N') {
                    executionList.push({
                        executionId: this.executionId,
                        isAgree: "N",
                        comment: this.rejectedReason
                    })
                }
                const params = {
                    executionList: executionList
                };
                InterfaceService.batchApprovalProcess(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            // window.opener.location.reload();
                            if (data.respData.respList) {
                                this.approvalResult = data.respData.respList;
                                this.approvalResult.forEach(item => {
                                    if (item.approveCode == "0000") {
                                        type == 'Y' ? this.$message.success("审批成功") : this.$message.success("退回操作完成");
                                        this.batchApproavlDialogVisible = false;
                                        this.rejectedDialogVisible = false;
                                        this.rejectedReason =  "";
                                        this.getApprovalDetail();
                                    } else {
                                        this.$message.error(item.approveMsg);
                                    }
                                });
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {
                    },
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleCloseConfirm(){
                let params = {};
                if (this.executionId) {
                    params = {
                        executionId : this.executionId,
                        procDefKey: this.procDefKey,
                        comment: this.rejectedReason,
                    };
                }
                InterfaceService.closeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("退回操作完成");
                            this.rejectedDialogVisible = false;
                            this.getApprovalDetail();
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleEntry(ev){
                this.entryNum = ev.length
            },
            handleBatchDownload() {
                this.$refs["brokerApproval"].open(this.executionId,"justView");
            },
            // 刷新状态
            handleRefreshStatus(executionId) {
                this.newExecutionId = executionId;
                this.getApprovalDetail();
            },
            // 子组件点击请求打印
            dandleClickPrint() {
                // const bdhtml = window.document.body.innerHTML,
                // sprnstr = "<!--startprint-->",
                // eprnstr = "<!--endprint-->"

                // let prnhtml = bdhtml.substr(bdhtml.indexOf(sprnstr) + 17)

                // prnhtml = prnhtml.substring(0, prnhtml.indexOf(eprnstr))

                // window.document.body.innerHTML = prnhtml;
                window.print();
            },
            handleOpenCirculationOpinion(){
                this.$refs["circulationOpinion"].open(this.execFlowList);
            },
            getApprovalDetail(type) {
                let execution = this.newExecutionId || this.executionId || '';
                let params = {};
                // 没有executionId（等待中的合同）入参orderNo；
                if (execution) {
                     params = {
                        executionId: execution,
                        procDefKey:this.procDefKey,
                        pageIndex: 1
                    };
                }else {
                    params = {
                        orderNo:this.orderNo,
                        procDefKey:this.procDefKey,
                        pageIndex: 1
                    };
                }
                // params = {
                //     // executionId: execution,
                //     procDefKey:this.procDefKey || "",
                //     orderNo:this.orderNo || "",
                //     pageIndex: 1
                // };
                InterfaceService.getApprovalDetail(
                    params,
                    data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            if (!type) {
                                if (window.opener) {
                                    window.opener.location.reload();
                                }
                            }
                            this.approvalInfo = data.respData || {};
                            this.execFlowList = data.respData.execFlowList || [];
                            this.goodsList = this.approvalInfo.orderList || [];
                            this.bankAcctInfo = this.approvalInfo.orderBankAcctInfo || {};
                            this.canFwRoleList = data.respData.canFwRole && data.respData.canFwRole.replace(/\s/g,"").split(',') || []

                            if (this.execFlowList.length > 0) {
                                // 最后一条退回原因
                                this.lastFailComment = this.execFlowList[0].comment;
                                //最后一条操作人
                                this.lastFailOperator = this.execFlowList[0].acctName;
                                let lastIsAgree = this.execFlowList[0].isAgree;
                                let firstApproveFlow = this.approvalInfo.approveFlowList[0];
                                // 当前节点是招采部且最近一条流水为退回，则显示退回原因
                                this.showRejectCommet = firstApproveFlow.isCurrentNode == "1" && firstApproveFlow.step == "1" && lastIsAgree == "N";
                                // 最近一条流水为关闭，则显示关闭原因
                                this.showCloseCommet = this.execFlowList[0].taskId == "closed";
                            }
                            if (this.approvalInfo.contractType == '1'){
                                this.projectCate = "施工类"
                            } else if (this.approvalInfo.contractType == '0') {
                                this.projectCate = "材料采购类";
                            }
                            // contractStakeHolders：40是甲方，32是乙方
                            this.approvalInfo.contractStakeHolders.forEach(role=>{
                                if (role.role == "40"){
                                    this.firstParty = role
                                }else if (role.role == "32") {
                                    this.secondParty = role
                                }
                            });
                            let status = this.approvalInfo.operateStatus;
                            status == "approve" ? this.approvalButton = true : this.approvalButton = false;
                        } else {
                            this.$message.error(res.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            init() {
                this.executionId = this.$route.query.executionId || "";
                this.orderNo = this.$route.query.orderNo || "";
                this.procDefKey = this.$route.query.procDefKey || "";
                this.roleIds.forEach(role=> {
                    if (role.roleId == "1001") {
                        this.managerApproval = true
                    }
                })
                this.$nextTick(function () {
                    window.addEventListener('scroll', this.onScroll)
                });
                this.getApprovalDetail("init");
            },
            filterERP(list = []) {
                let resList = list;
                if (list.length !=0){
                    const res = list.filter(item => {
                        return item.sysCode === "ERP";
                    });
                    if (!res.length) {
                        resList.unshift({
                            sysCode: "ERP"
                        });
                    }
                }
                return resList;
            },
            filterExternalSys(item) {
                let str = "";
                if (item.externalCode) {
                    let status = item.approveStatus == 1 ? "审批完成" : "审批中";
                    let data = item.approveFinishDate || "";
                    if (data) {
                        str = `(${item.sysCode}${status}<i style="padding-left: 6px">${data}</i>)`;
                    }else {
                        str = `(${item.sysCode}${status})`;
                    }
                    // str = "(" + item.sysCode + status + data +")";
                }
                return str;
            },
            //滚动超300后出现底部的审核按钮
            onScroll(){
                let scrolled = document.documentElement.scrollTop || document.body.scrollTop;
                this.fixedBottomActive = scrolled >= 300;
            },
            getContractInfo(type) {
                const params = {
                    orderNo: this.orderNo,
                    bs: type,
                };
                InterfaceService.getContractInfo(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            let list = data.respData.documentInfos || [];
                            list.forEach((item) => {
                                if (item.documentType == "10") {
                                    this.supplierContractUrl = item.attachUrl;
                                }else if (item.documentType == "00") {
                                    this.purchaseContractUrl = item.attachUrl;
                                }
                            });
                            if (type == "S") {
                                if (this.purchaseContractUrl) {
                                    window.open(this.purchaseContractUrl,"_blank")
                                } else {
                                    this.$message.error("暂未上传货物供应合同")
                                }
                            } else if (type == "B") {
                                if (this.supplierContractUrl) {
                                    window.open(this.supplierContractUrl,"_blank")
                                } else {
                                    this.$message.error("暂未上传货物采购合同")
                                }
                            }
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {
                    },
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
        },
        mounted() {
            this.init();

        },
        destroyed(){
            window.removeEventListener('scroll', this.onScroll)
        }
    };
</script>
<style lang="scss" scoped>
    .inner-container {
        margin-bottom: 100px;
        font-size: 14px;
    }

    .pointer {
        cursor: pointer;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }

        .active {
            color: #ffd64e;
        }
    }

    .table {
        /deep/ .el-button {
            font-size: 12px;
            span{
                line-height: 32px;
            }
        }

        width: 100%;
        line-height: 23px;
        font-size: 12px;
        table {
            width: 100%;
        }
        td {
            padding: 14px 10px;
            vertical-align: middle;
            word-break: break-word;
        }

        thead {
            text-align: center;
            white-space: nowrap;
            font-size: 14px;
            color: #909399;
            background: #f5f5f5;
        }

        tbody {
            text-align: center;

            tr:hover {
                background: #e8f3fd;
            }

            td {
                border-bottom: 1px solid #ebeef5;
            }
        }
    }

    .order-info {
        margin-bottom: 20px;
        line-height: 25px;
        font-size: 12px;

        /deep/ .el-col {
            padding: 0 10px;
        }

        p {
            width: 100%;
            display: flex;
            padding-right: 10px;
            word-break: break-word;
            white-space: normal;

            & > span {
                display: inline-block;
                flex: 1 1 0%;
            }
            em{
                cursor: pointer;
            }
        }

        label {
            white-space: nowrap;
            color: #888888;
        }

        a {
            color: #0082ff;
        }
    }

    .order-name {
        display: inline-flex;
        width: 100%;
        vertical-align: top;
        line-height: 20px;

        img {
            width: 75px;
            height: 75px;
        }

        a:hover {
            text-decoration: underline;
            color: #0082ff;
        }

        .left {
            margin-right: 10px;
        }

        .right {
            text-align: left;

            p:first-child {
                margin-bottom: 10px;
            }
            p:last-child {
                word-break: break-all;
                max-height: 40px;
                overflow: hidden;
                color: #969799;
            }
        }
    }

    .order-total {
        margin-bottom: 40px;
        padding: 20px 40px;
        border-top: 1px solid #e2e2e2;
        text-align: right;
        font-size: 12px;
        line-height: 25px;
        color: #888888;
        background: #f5f5f5;

        label {
            display: block;
            color: #444444;
        }

        .total-content {
            margin-bottom: 10px;
        }

        .total {
            font-weight: bold;
            font-size: 14px;
        }

        .bold {
            font-weight: bold;
        }

        .big {
            font-size: 20px;
        }

        .red-font {
            color: #e94650;
        }
    }

    .order-total-black {
        color: #444444;
    }

    .order-info-title {
        margin: 5px 0;
        margin-bottom: 15px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
    }

    .order-sign-role {
        margin-top: 20px;
        padding-top: 20px;
        border-top: 1px solid #f5f5f5;
        .order-info-title {
            margin-bottom: 5px;
        }
    }
    .pre-tax, .after-tax{
        padding:0 10px;
        display: flex;
        justify-items: center;
        justify-content: space-between;
        height: 30px;
        line-height: 30px;
    }
    .after-tax{
        height: 40px;
        line-height: 40px;
        font-weight: bold;
        background: #fef4f3;
        margin-bottom: 20px;
        em{
            font-size: 22px;
        }
    }
    .line{
        width: 100%;
        height: 1px;
        background: #f0f0f0;
        margin: 20px 0;
    }
    .fix-bottom{
        width: 100%;
        margin: 0 auto;
        text-align: center;
    }
    /deep/ .el-textarea__inner{
        height: 100px;
    }
    .tax{
        width: 100%;
        vertical-align:baseline;
        td{
            width: 40%;
            padding: 4px 10px;
            background: #fef4f3;
            vertical-align:middle;
        }
        .add-tax {
            width: 20%;
            border-left: 4px solid #fff;
            font-size: 14px;
            font-weight: bold;
        }
    }
    /deep/ .el-dialog__header:before {
        height: 0;
    }
    .line-top{
        width: 95%;
        height: 1px;
        background: #eee;
        position: absolute;
        top:65px;
    }
    .count{
        float: right;
        span.red{
            color: #f00;
        }
    }
    .payment{
        padding:0 10px;
    }
    .circulation-opinion{
        width: 1190px;
        min-height: 72px;
        height: auto;
        background: #ffeaeb;
        border: 1px solid #eb4854;
        margin-bottom: 40px;
        position: relative;
        line-height: 20px;
        button{
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .opinion-content{
            width: 1140px;
            height: auto;
            margin-top: 28px;
            margin-left: 20px;
        }
        .reason{
            width: 900px;
            margin: 0 80px 20px;
            line-height: 20px;
            word-break:break-all;
        }
        .reason-ellipsis{
            width: 800px;
            margin: 0 80px 20px;
            line-height: 20px;
            overflow:hidden;
            white-space:nowrap;
            text-overflow:ellipsis;
        }
    }
    .panel-title{
        margin-top: 40px;
    }
    .showPrint {
        display: none;
        width: 100%;
    }
    @media print {
        @page {
            size: A4;
        }
        .showPrint {
            display: block;
            width: 100%;
        }
        .unShowPrint {
            display: none
        }
        .printHead {
            position: fixed;
            bottom: 0px;
        }
    }
</style>
<style>
    @media print {
        .copy-right, .fixed-tool {
            display: none;
        }
    }
</style>

