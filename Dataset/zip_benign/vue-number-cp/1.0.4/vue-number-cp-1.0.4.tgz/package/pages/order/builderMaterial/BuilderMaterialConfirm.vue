<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <SearchBar :is-white-bg="true" :search-type="5" :progress="'确认要货清单'" :is-border-bottom="false" :product-create-process="2"></SearchBar>
        <div class="inner-container">
            <PanelTitle title="基本信息"></PanelTitle>
            <div class="material-info">
                <el-row>
                    <el-col :span="8">
                        <p>
                            <label>项目名称：</label>{{material.projectName}}
                        </p>
                        <p>
                            <label>要求到货时间：</label>{{material.requireDt|date}}
                        </p>
                    </el-col>
                    <el-col :span="8">
                        <p>
                            <label>施工单位：</label>{{material.constructorName}}
                        </p>
                    </el-col>
                    <el-col :span="8">
                        <p>
                            <label>申请人：</label>{{material.applyCustName}}
                            <template v-if="material.applyCustMobile">(Tel：{{material.applyCustMobile}})</template>
                        </p>
                    </el-col>
                </el-row>
            </div>
            <!-- 收货地址 -->
            <div class="address-info">
                <SelectAddress :onlyOne="addressOnlyOne" :hasDefault="addressShowDefault" @getAddresses="getAddresses" :drafts="material.addressId">
                    <div v-if="!addressOnlyOne" slot="header" class="tip">
                        <p>在您的地址库中
                            <span class="red">未匹配到此收货地址：{{material.deliveryAddr}} {{material.applyCustName? material.applyCustName+'收':''}} {{material.applyCustMobile||''}}</span>。</p>
                        <p>请确认地址的准确性，若该地址已与地址库中地址有重复表述，
                            <span class="red">请选择下列地址</span>。反之请点击右上角
                            <span class="red">“+新增收货地址”</span>。</p>
                    </div>
                    <div v-if="!addressOnlyOne" slot="dialog-header" class="header-tip">
                        <p>请将施工方填写的收货地址选择复制到下列信息栏中，方便管理。施工方地址：{{material.deliveryAddr}} {{material.applyCustName? material.applyCustName+'收':''}} {{material.applyCustMobile||''}}</p>
                    </div>
                </SelectAddress>
            </div>
            <!-- 匹配货品 -->
            <MatchGoods class="match-goods" :list="matchGoods" @move="handleMoveGoods('match',$event)"></MatchGoods>
            <!-- 待匹配货品 -->
            <MismatchGoods class="todo-goods" type="todo" :list="todoGoods" @move="handleMoveGoods('todo',$event)"></MismatchGoods>
            <!-- 线下货品 -->
            <MismatchGoods class="offline-goods" type="offline" :list="offlineGoods" @move="handleMoveGoods('offline',$event)"></MismatchGoods>
        </div>

        <FixBottom class="bottom">
            <p>{{ canRequireCount }}款货品，可发起要货</p>
            <div class="fr">
                <el-button size="small" style="width: 120px" @click="handleSave">保存</el-button>
                <el-button size="small" style="width: 120px" type="primary" @click="handleRequireGoods">确认并发起要货</el-button>
            </div>
        </FixBottom>

        <Page-nav v-if="showPageNav" :navigation="navigation" :change="0"></Page-nav>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import SelectAddress from "@/components/base/SelectAddress";
import PageNav from "@/components/order/PageNav";
import FixBottom from "@/components/base/FixBottom";
import MatchGoods from "@/components/order/builderMaterial/MatchGoods";
import MismatchGoods from "@/components/order/builderMaterial/MismatchGoods";

import { InterfaceService } from "@/services/api";
export default {
    components: {
        Header,
        SearchBar,
        PanelTitle,
        SelectAddress,
        PageNav,
        Loading,
        FixBottom,
        MatchGoods,
        MismatchGoods
    },
    data() {
        return {
            isLoading: false,
            showPageNav: false,
            addressOnlyOne: true,
            addressCount: 0,
            addressShowDefault: false,
            navigation: [
                {
                    name: "确认货品匹配区",
                    position: "match-goods"
                },
                {
                    name: "待匹配货品区",
                    position: "todo-goods"
                },
                {
                    name: "线下要货清单",
                    position: "offline-goods"
                }
            ],
            applyNo: "",
            constructorCorpId: "",
            material: {},
            matchGoods: [],
            todoGoods: [],
            offlineGoods: []
        };
    },
    computed: {
        canRequireCount() {
            let count = 0;
            if (this.matchGoods && this.matchGoods.length) {
                this.matchGoods.forEach(item => {
                    if (+item.requireLeft > 0) {
                        count++;
                    }
                });
            }
            return count;
        }
    },
    methods: {
        handleSave(cb) {
            const list = [];
            this.matchGoods.forEach(item => {
                list.push({
                    id: item.id,
                    matchStatus: 1,
                    applyCount: item.applyCount,
                    orderDetailId: item.orderDetailId
                });
            });
            this.todoGoods.forEach(item => {
                list.push({
                    id: item.id,
                    applyCount: item.applyCount,
                    matchStatus: 0
                });
            });
            this.offlineGoods.forEach(item => {
                list.push({
                    id: item.id,
                    applyCount: item.applyCount,
                    matchStatus: 2
                });
            });
            this.saveList(list, cb);
        },
        handleRequireGoods() {
            if (!this.matchGoods.length) {
                this.$message.error("未匹配到货品，请至少匹配一个货品");
                return;
            }

            if (!this.material.addressId) {
                this.$message.error("请选择收货地址");
                return;
            }

            const list = [];
            this.matchGoods.forEach(item => {
                if (item.requireLeft > 0) {
                    const obj = Object.assign({}, item);
                    if (obj.applyCount > obj.requireLeft) {
                        obj.applyCount = obj.requireLeft;
                    }
                    list.push(obj);
                }
            });

            if (!list.length) {
                this.$message.error("匹配货品数量超过合同可要货数量");
                return;
            }

            this.handleSave(() => {
                const applyList = [];
                list.forEach(item => {
                    applyList.push({
                        id: item.id,
                        no: item.no,
                        applyCount: item.applyCount
                    });
                });

                this.$router.push({
                    path: "/batchLaunchGoods",
                    query: {
                        applyNo: this.applyNo,
                        constructorCorpId: this.constructorCorpId,
                        list: JSON.stringify(applyList)
                    }
                });
            });
        },
        handleMoveGoods(from, material) {
            const map = {
                match: "matchGoods",
                todo: "todoGoods",
                offline: "offlineGoods"
            };
            let removeArr = this[map[from]];
            let addArr = this[map[material.position]];
            this.moveGoods(removeArr, addArr, material.index, material.data);
        },
        moveGoods(removeArr, addArr, index, data) {
            removeArr.splice(index, 1);
            addArr.push(data);
            addArr.sort((a, b) => {
                return a.no - b.no;
            });
        },
        filterGoods() {
            const list = this.material.applyDetailList || [];
            list.forEach(item => {
                // 匹配且未要完货
                if (
                    item.matchStatus == 1 &&
                    Number(item.submitCount) !== Number(item.applyCount)
                ) {
                    this.matchGoods.push(item);
                } else if (item.matchStatus == 0) {
                    this.todoGoods.push(item);
                } else if (item.matchStatus == 2) {
                    this.offlineGoods.push(item);
                }
            });
        },
        getAddresses(address) {
            this.addressCount++;
            // 初始触发事件过滤
            if (this.addressCount <= 1) return;
            this.addressShowDefault = true;
            this.material.addressId = address.addressId;
        },
        getDetail() {
            const params = {
                applyNo: this.applyNo
            };
            InterfaceService.getBuilderMaterialDetail(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.material = data.respData;
                        if (
                            this.material.applyDetailList &&
                            this.material.applyDetailList.length
                        ) {
                            this.material.applyDetailList.forEach(item => {
                                item.applyCount = +item.applyCount;
                                item.requireLeft = +item.requireLeft;
                            });
                        }
                        this.filterGoods();
                        this.showPageNav = true;
                        this.constructorCorpId = this.material.constructorCorpId || "";
                        this.addressOnlyOne = !!this.material.addressId;
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        saveList(list, cb) {
            const params = {
                applyNo: this.applyNo,
                applyDetailList: list,
                addressId: this.material.addressId
            };
            InterfaceService.saveMaterialGoods(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        if (typeof cb === "function") {
                            cb();
                        } else {
                            this.$message.success("保存成功");
                        }
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        init() {
            this.getDetail();
        }
    },
    mounted() {
        this.applyNo = this.$route.query.applyNo;
        this.init();
    }
};
</script>

<style lang="scss" scoped>
.bottom {
    p {
        float: left;
        padding: 10px 0;
        font-size: 14px;
        color: #ffffff;
    }
}

.inner-container {
    margin-bottom: 100px;
}

.address-info {
    margin-bottom: 10px;
    /deep/ .tip {
        margin-bottom: 20px;
        padding: 0 10px;
        line-height: 20px;
    }

    /deep/ .header-tip {
        line-height: 40px;
    }
}
.material-info {
    margin-bottom: 20px;
    line-height: 25px;
    font-size: 12px;

    /deep/ .el-col {
        padding: 0 10px;
    }

    p {
        width: 100%;
        display: flex;
        padding-right: 10px;
        word-break: break-word;
        white-space: normal;

        & > span {
            display: inline-block;
            flex: 1 1 0%;
        }
    }

    label {
        white-space: nowrap;
        color: #888888;
    }

    a {
        color: #0082ff;
    }
}
</style>
