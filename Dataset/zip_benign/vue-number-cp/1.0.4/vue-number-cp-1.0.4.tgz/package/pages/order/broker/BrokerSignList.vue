<template>
    <div class="product">
        <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
        <!-- 查询条件 -->
        <el-form ref="form" :model="form" label-width="auto">
            <el-form-item label="城市公司">
                <el-select placeholder="请选择城市公司" v-model="form.cityCompany" @change="getOrderList">
                    <el-option v-for="(item,index) in cityCompanyList" :value="item" :key="index"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="项目" v-if="tab == 3">
                <el-select placeholder="请选择项目" v-model="form.projectName" @change="getOrderList">
                    <el-option value=""></el-option>
                    <el-option v-for="(item,index) in projectNameList" :value="item" :key="index"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item label="合同名称" v-if="tab == 3">
                <el-input  placeholder="请选择合同名称" v-model="form.contractName" @focus="getOldContractName" @blur="handleSelectcontractName" @keyup.enter.native="handleBlur"></el-input>
            </el-form-item>
        </el-form>
        <div class="product-table">
            <!-- 列表 -->
            <div class="check-all" v-if="tab == 1">
                <div class="check">
                    <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow" :disabled="disableAllCheck"></el-checkbox><span>当页全选</span>
                </div>
                <div class="sign f18">
                    <span>您有<em v-if="total">{{total}}</em><em v-else>0</em>份合同待签章，</span>
                    <span>现已勾选<em>{{selectedSignLength}}</em>份</span>
                    <el-button v-if="allChecked || !hasChecked" size="mini" :disabled="!allChecked" @click="handleBatchOrderConfirm">一键全部签章</el-button>
                    <el-button v-if="!allChecked && hasChecked" size="mini" :disabled="!hasChecked" @click="handleBatchOrderConfirm">一键签章</el-button>
                </div>
            </div>
            <table>
                <thead>
                <tr>
                    <th width="60px" v-if="tab == 1">&nbsp;</th>
                    <th>城市公司</th>
                    <th>项目名称</th>
                    <th width="480px">合同名称</th>
                    <th v-if="tab ==2" width="120px">审批状态</th>
                    <th v-if="tab ==1" width="120px">备注</th>
                    <th style="text-align: right">操作</th>
                </tr>
                </thead>

                <!--<template v-if="productList.length">-->
                    <tbody>
                        <tr v-for="(item,index) in brokerOrderList" :key="index" class="tbody-row">
                            <td v-if="tab == 1" style="text-align: center">
                                <el-checkbox v-model="item.checked" :disabled="disableAllCheck"  @change="handleSelectTableRow(item,index)"></el-checkbox>
                            </td>
                            <td>{{item.cityCompany}}</td>
                            <td>{{item.projectName}}</td>
                            <td><span class="blue pointer" @click="handleOpen(item)">{{item.contractName}}</span></td>
                            <td v-if="tab === 2">
                                <!--<span class="order-sign" v-for="_item in item.externalSysList" v-if="_item.approveStatus != ''">{{_item.sysCode}}-->
                                    <!--&lt;!&ndash;<span><i class="icon-check-yes"></i></span>&ndash;&gt;-->
                                    <!--<span><i  :class="filterIconName(_item)"></i></span>-->
                        <!--&lt;!&ndash;<i :class="filterIconName(item.type)"></i></span>&ndash;&gt;-->
                                <!--</span>-->
                                <span class="order-sign" v-for="_item in item.externalSysList" v-if="_item.approveStatus != ''">{{_item.sysCode}}
                                    <span><i  :class="filterIconName(_item)"></i></span>
                                </span>
                                <p v-if="item.externalSignStatus == '0' && item.waitBsSign">等待甲/乙方签章</p>
                                <!--<span class="order-sign">OA-->
                                    <!--<span><i class="icon-check-no"></i></span>-->
                        <!--&lt;!&ndash;<i :class="filterIconName(item.type)"></i></span>&ndash;&gt;-->
                                <!--</span>-->
                            </td>
                            <td v-if="tab == 1 && item.orderStatus == 'contractTerminating'"><span class="red">合同解除</span></td>
                            <td v-if="tab == 1 && item.orderStatus != 'contractTerminating'"></td>
                            <td style="text-align: right"><span class="blue pointer" @click="handleBatchDownload(item)">资料打包下载</span></td>
                        </tr>
                    </tbody>
                <!--</template>-->
            </table>
            <div class="table-pagination" v-if="brokerOrderList.length">
                <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                </el-pagination>
            </div>

            <!--空列表-->
            <div class="product-empty" v-if="!brokerOrderList.length&&!isLoading">
                <img src="@/assets/images/icon-no-product.png">
                <p>没有搜索到相关合同，请重新修改搜索条件搜索！</p>
            </div>
        </div>
        <!-- 确认合同/批量确认合同 -->
        <el-dialog class="dialog" title="确认并签署合同" :append-to-body="true" :lock-scroll="true" :visible.sync="signAllDialogVisible" width="840px" center :close-on-click-modal="false">
            <div class="f14 tl">请确认签署以下<em class="red">{{selectedSignLength}}</em>份合同</div>
            <div class="contract-list tl">
                <p v-for="item in signBrokerOrderList">{{item.contractName}}<em v-if="item.orderStatus == 'contractTerminating'" class="red" style="margin-left: 10px;">合同解除</em></p>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm()">电子签章</el-button>
                <el-button size="small" style="width: 100px" @click="signAllDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <el-dialog class="sign-result-dialog" :title="signResultTitle" :append-to-body="true" :lock-scroll="true" :visible.sync="signResultDialogVisible" width="650px" center :close-on-click-modal="false" @close="getOrderList">
            <!--<div class="f14">您于签署{{selectedSignLength}}份合同，其中签署成功 <em class="red">{{selectedSignLength-signFailNum}}</em>份，签署失败 <em class="red">{{signFailNum}}</em>份。</div>-->
            <div class="f14 bold" v-if="signFailNum > 0 &&signFailNum < selectedSignLength">您于{{presentTime}}签署<em class="red">{{selectedSignLength}}</em>份合同，失败<em class="red">{{signFailNum}}</em>份，建议请重新签署，未签署成功的合同可在“待签章合同”栏内查看</div>
            <div class="f14 bold" v-if="signFailNum == selectedSignLength">您于{{presentTime}}签署<em class="red">{{selectedSignLength}}</em>份合同，全部签署失败，建议请重新签署，未签署成功的合同可在“待签章合同”栏内查看</div>
            <div class="f14 bold" v-if="signFailNum == 0">您于{{presentTime}}签署<em class="red">{{selectedSignLength}}</em>份合同，全部签署成功，签署成功的合同可在“归档合同”栏内查看</div>
            <div v-if="signFailNum > 0">※若有疑问请联系平台客服：<em class="blue">{{$platformContact()['hotLine']}} {{$platformContact()['hotLineTime']}}</em></div>
            <div class="sign-result" v-if="selectedSignLength > 0 && signFailNum > 0">
                <el-button size="mini" @click="handleConfirm()">重新电子签章</el-button>
                <el-button @click="signResultDialogVisible=false" size="mini" style="border: 1px solid #000;background: #fff">取消</el-button>
            </div>
            <div class="sign-result" v-if="selectedSignLength > 0 && signFailNum == 0">
                <el-button @click="signResultDialogVisible=false" size="mini" style="border: 1px solid #000;background: #fff">确定</el-button>
            </div>
        </el-dialog>
        <!-- 合同签章 -->
        <Signature ref="signature" @close="handleCloseSignature"></Signature>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    import accountMixin from "@/mixins/account";
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import OrderListOperate from "@/components/order/OrderListOperate";
    import ContractOperate from "@/components/order/ContractOperate";
    import SignProcessOrderList from "@/components/order/SignProcessOrderList";
    import Signature from "@/components/order/dialog/Signature";

    import { InterfaceService } from "@/services/api";
    import { filterEventByAcct } from '@/utils/orderUtil';
    import download from "@/utils/download";
    import {DateUtil} from '@/utils/dateUtil';

    const params = {
        orderNo: "",
        orderAccName: "",
        contractName: "",
        orderStatus: [],
        status: "",
        purchaserName: "",
        supplierName: "",
        orderTmFrom: "",
        orderTmTo: "",
        // priceType: "D", // 字段删除
        sort: "0_1_0",
        pageIndex: 1,
        pageSize: 10,
        enterFrom: 1,
        searchType: 1,
        cityCompany:"",
        projectName:"",
        approveStatus:"1"     //外部系统是否都已审核通过（"1":是；"2":否）
    };

    export default {
        mixins: [accountMixin],
        components: {
            Loading,
            PanelTitle,
            OrderListOperate,
            ContractOperate,
            SignProcessOrderList,
            Signature
        },
        data() {
            return {
                tab: "1",
                tabs: [
                    { label: "待签章合同", index: 1, active: true },
                    { label: "等待中合同", index: 2 },
                    { label: "归档合同", index: 3 },
                ],
                form: Object.assign({}, params),
                allChecked: true,
                disableAllCheck: false,
                hasChecked: true,
                sortList: [0, 1, 0],
                statusList: [],
                percentage: 0,
                overStatusList: [],
                productList: [],
                total: 0,
                isLoading: false,
                storeParams: {},
                signBrokerOrderList:[],
                brokerOrderList:[],
                signAllDialogVisible:false,
                selectedSignLength:0,
                cityCompanyList:[],
                projectNameList:[],
                oldContractName:"",
                externalSysList:[],
                signResultDialogVisible:false,
                signFailNum:"",
                signResultTitle:"",
                presentTime:""
            };
        },
        methods: {
            // 修改tab
            handleChangeTab(tab) {
                this.tab = tab.index;
                this.recoverStatus(this.tab);
                this.getOrderList();

            },
            handleOpen(item) {
                console.log(item);
                this.$router.push({
                    path: "/brokerSignPreview",
                    query: {
                        orderNo: item.orderNo,
                        tab:this.tab
                    }
                });
            },
            // 全选
            handleAllSelectTableRow(bool) {
                let arr = [];
                arr = [].concat(this.brokerOrderList);
                arr.forEach(item => {
                    item.checked = bool;
                });
                if (arr.length != 0){
                    this.brokerOrderList = arr;
                }else {
                    this.allChecked = false
                }
                this.checkBatch();
            },
            // 选中行
            handleSelectTableRow(item, index) {
                this.$set(this.brokerOrderList, index, item);
                this.checkBatch();
                this.checkAllSelect();
            },
            // 刷新列表
            // 批量确认合同弹窗
            handleBatchOrderConfirm() {
                this.signAllDialogVisible = true;
                const signBrokerOrderList = [];
                console.log(this.brokerOrderList);
                this.brokerOrderList.forEach(item => {
                    if (item.checked) {
                        signBrokerOrderList.push(item);
                    }
                });
                this.signBrokerOrderList = signBrokerOrderList;
                this.selectedSignLength = this.signBrokerOrderList.length
            },
            // 批量确认合同完成
            handleConfirm(){
                let attach = [];
                this.signBrokerOrderList.forEach(item=>{
                    item.eventList.forEach(ev=>{
                        if ((ev.eventType == 0 ||
                            ev.eventType == "contractTerminateSign" ||
                            ev.eventType == "goodsList") &&
                            (ev.eventStatus == "0" || ev.eventStatus == "1")) {
                            attach.push(ev)
                        }
                    })
                });
                console.log(attach);
                this.handleSignContract(attach);
                // this.signAllDialogVisible = false
            },
            // 合同签章
            handleSignContract(attach) {
                // events = attach
                // events.forEach(item=>{
                //     this.successAttachUrl = item.attachUrl
                // });
                this.$refs["signature"].open(attach, "order");
            },
            handleCloseSignature(bool,num) {
                console.log(num);
                if (bool) {
                    this.presentTime = DateUtil.dateToString();
                    this.signFailNum = num;
                    this.signFailNum == 0 ? this.signResultTitle = '签署成功' : this.signResultTitle = '签署失败';
                    this.signAllDialogVisible = false;
                    this.signResultDialogVisible = true;
                }
            },
            //资料打包下载
            handleBatchDownload(item) {

                let params = {};
                params = {
                    orderNo : item.orderNo,
                    documentType: "2"
                };
                InterfaceService.contractPackingDownload(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            console.log(data.respData);
                            let packingUrl = "";
                            packingUrl = data.respData.externalFileUrl;
                            // packingUrl = packingUrl.slice(0, 4) + "s" + packingUrl.slice(4);
                            console.log(packingUrl);
                            if (packingUrl == null){
                                this.$message.error("暂无资料")
                                return
                            }
                            this.handleDownload(item.contractName,packingUrl)
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleDownload(name,packingUrl) {
                const x = new XMLHttpRequest();
                console.log(packingUrl);
                x.open("GET",packingUrl, true);
                x.responseType = "blob";
                x.onload = e => {
                    download(
                        x.response,
                        name+".zip",
                        x.response.type
                    );
                };
                x.send();
            },
            // 分页跳转
            handleCurrentChange(page) {
                this.form.pageIndex = page;
                this.getOrderList();
                window.scrollTo(0,0)
            },
            getOldContractName(value){
                this.oldContractName = value.target.value
            },
            handleSelectcontractName(value){
                if (this.form.contractName != this.oldContractName) {
                    this.getOrderList()
                }
            },
            handleBlur(value){
                value.target.blur()
            },
            // 是否全选
            checkAllSelect() {
                this.allChecked = this.brokerOrderList.every(item => {
                    return item.checked;
                });
            },
            // 是否可批量
            checkBatch() {
                this.hasChecked = this.brokerOrderList.some(item => {
                    return item.checked;
                });
                let num = 0;
                this.brokerOrderList.forEach(item=>{
                    if (item.checked){
                        num++
                    }
                });
                this.selectedSignLength = num
            },
            filterContractName(item) {
                let name = "";
                if (this.tab == 1 || this.tab == 2 ) {
                    if (item.orderStatus == 'contractTerminating') {
                        name = "关于<" + item.contractName +">之解除协议"
                    } else {
                        name = item.contractName
                    }
                }else if (this.tab == 3) {
                    if (item.orderStatus == 'contractTerminated') {
                        name = "关于<" + item.contractName +">之解除协议"
                    }else {
                        name = item.contractName
                    }
                }
                return name
            },
            // 恢复状态
            recoverStatus(tab) {
                this.form.enterFrom = '1';
                if (tab == 1) {
                    this.form.status = "";
                    // this.form.orderStatus = [];
                    this.form.approveStatus="1";   //已全部审核
                    this.form.searchType = '1';
                    this.form.cityCompany="";
                    this.form.projectName=""
                } else if (tab == 2) {
                    this.form.status = "";
                    this.form.approveStatus="2"    //有待审核项
                    this.form.searchType = '1'
                    this.form.cityCompany="";
                    this.form.projectName=""
                } else if (tab == 3) {
                    this.form.status = "";
                    this.form.searchType = '2';
                    this.form.approveStatus="";
                    this.form.cityCompany="";
                }
            },
            // 待签署合同
            init() {
                this.getOrderList();
            },
            getOrderList() {
                this.brokerOrderList = [];
                this.total = 0;
                this.selectedSignLength = 0;
                this.form.sort = this.sortList.join("_");
                this.recordFormData();
                const params = {};
                for (let i in this.form) {
                    if (this.form[i]) {
                        params[i] = this.form[i];
                    }
                }

                delete params.status;

                InterfaceService.getOrderList(
                    params,
                    data => {
                        //console.log(data);
                        if (data.respData.respCode === "0000") {
                            this.brokerOrderList = data.respData.orders || [];
                            let num = 0;
                            this.brokerOrderList.forEach(item => {
                                item.checked = true;
                                num++
                            });
                            this.selectedSignLength = num;
                            if (this.brokerOrderList.length == 0){
                                this.allChecked = false;
                                this.hasChecked = false
                            }else {
                                this.allChecked = true;
                            }
                            this.cityCompanyList = data.respData.cityCompanyList;
                            this.projectNameList = data.respData.projectNameList;
                            // this.statusList = data.respData.orderStatusList || [];
                            // this.overStatusList = this.arrangeStatusList(
                            //     this.statusList
                            // );
                            this.brokerOrderList.forEach(item=>{
                                item.externalSysList && item.externalSysList.forEach(_item=>{
                                    _item.approveStatus == "1" ? item.waitBsSign = true : item.waitBsSign = false
                                })
                            });
                            this.total = data.respData.totalCount;
                            this.form.pageSize = data.respData.pageSize;
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            recordFormData() {
                let hasChange = false;
                Object.keys(this.storeParams).forEach(key => {
                    if (this.storeParams[key] != this.form[key]) {
                        hasChange = true;
                    }
                });

                if (hasChange) {
                    this.form.pageIndex = 1;
                }

                this.storeParams = this.$clone(this.form);
                delete this.storeParams.pageIndex;
                delete this.storeParams.pageSize;
                delete this.storeParams.orderStatus;
            },
            filterIconName(_item) {
                let icon = "";
                if (_item.approveStatus == "1"){
                    icon = "icon-check-yes"
                }else if (_item.approveStatus == "0"){
                    icon = "icon-check-no"
                }
                return {
                    [icon]: true
                };
            },
        },
        mounted() {
            this.init();
        }
    };
</script>

<style lang="scss" scoped>
    .hand + .hand {
        margin-left: 10px;
    }
    .price-tip {
        cursor: pointer;
        color: #a9a9aa;

        &:hover {
            color: #0082ff;
        }
    }

    .product {
        font-size: 14px;
        /deep/ .el-form-item{
            width: 33%;
            float: left;
        }
        /deep/ .el-input{
            width: 220px;
        }
    }

    .pointer {
        cursor: pointer;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }

        .active {
            color: #ffd64e;
        }
    }

    .nowrap {
        white-space: nowrap;
    }

    .panel-content {
        margin-bottom: 20px;
        padding: 20px 10px;
        background: #f5f5f5;
    }

    .form {
        min-height: 135px;

        /deep/ .el-col {
            height: 52px;
        }

        /deep/ .el-select {
            width: 100%;
        }

        /deep/ .el-date-editor {
            input.el-input__inner {
                padding: 0 15px;
            }
            .el-input__prefix {
                display: none;
            }
        }

        &:after {
            display: table;
            content: "";
            clear: both;
        }
    }

    .form-item {
        position: relative;
        display: inline-block;
        line-height: 32px;

        .float-right {
            position: absolute;
            top: 2px;
            right: 1px;
            height: 30px;
            padding: 0 7px;
            line-height: 30px;
            background: #ffffff;
        }
    }

    .error-info {
        color: #f56c6c;
        font-size: 12px;
        line-height: 1;
        padding-top: 4px;
        position: absolute;
        top: 100%;
        left: 0;
    }

    .form-btns {
        text-align: center;
    }

    .product-table {
        /deep/ .el-table__body-wrapper {
            font-size: 12px;
        }
        .check-all{
            width: 100%;
            height: 70px;
            line-height: 70px;
            background: #535864;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            em{
                color: #fa0202;
            }
            .check{
                span{
                    margin-left: 8px;
                }
                /deep/ .el-checkbox__inner::after{
                    border-bottom:2px #000 solid;
                    border-right:2px #000 solid;
                }
            }
            .sign{
                .el-button{
                    margin-left: 20px;
                    background: #ffd64e;
                    border: none;
                    width: 110px;
                    height: 34px;
                    padding-top: 12px;
                }
            }
        }
        .contract{
            span{
                color: #f00;
            }
        }
        /deep/ .el-table th,
        .el-table td {
            padding: 14px 0;
        }

        /deep/ .el-button {
            font-size: 12px;
        }

        table {
            width: 100%;
            line-height: 23px;
            font-size: 12px;
            td,th {
                padding: 14px 10px;
                vertical-align: middle;
                word-break: break-word;
                text-align: left;
            }
            thead {
                font-size: 14px;
                text-align: left;
                white-space: nowrap;
                color: #909399;
                background: #f5f5f5;
            }

            .tbody-row:hover {
                background: #e8f3fd;
            }

            tbody {
                text-align: left;

                tr {
                    &.sign-content {
                        display: none;
                        background: #f0f8ff;

                        &:hover {
                            display: table-row;
                        }

                        td {
                            padding: 0;
                            border-bottom: none;
                        }
                    }

                    &.all-check {
                        text-align: left;

                        &:hover{
                            background: #ffffff;
                        }
                    }
                }

                tr:hover + tr.sign-content {
                    display: table-row;
                }

                td {
                    border-bottom: 1px solid #ebeef5;
                }
            }
        }

        .product-name {
            display: inline-flex;
            width: 100%;
            vertical-align: top;
            line-height: 20px;

            img {
                width: 75px;
                height: 75px;
            }

            .left {
                margin-right: 10px;
            }

            .right {
                text-align: left;

                p:first-child {
                    margin-bottom: 10px;
                }
                p:last-child {
                    word-break: break-all;
                    max-height: 40px;
                    overflow: hidden;
                    color: #969799;
                }
            }
        }
    }

    .product-empty {
        padding: 150px;
        text-align: center;
        line-height: 50px;
        color: #909399;
    }

    .price-popover {
        display: flex;
        color: #ababac;

        > div:first-child {
            margin-right: 10px;
        }

        p:first-child {
            padding: 0 5px;
            border-left: 3px solid #ffd64e;
            line-height: 15px;
        }

        p:last-child {
            margin-top: 10px;
            color: #ffffff;
        }
    }

    .table-pagination {
        margin: 50px 0 80px;
        text-align: center;
        color: #888888;
    }
    /deep/ .el-dialog__title{
        font-size: 16px;
    }
    .contract-list{
        width: 800px;
        height: 286px;
        margin: 10px auto 30px;
        background: #eeeeee;
        overflow: auto;
        p{
            padding-left: 24px;
            height: 40px;
            line-height: 40px;
            border-bottom: 1px solid #fff;
        }
    }
    .order-sign {
        /*padding: 8px 15px;*/

        i {
            margin-right: 3px;
            margin-bottom: 3px;
            background-size: 100%;
            vertical-align: middle;
        }
    }
    /deep/ .el-pagination__jump{
        .el-input{
            width: auto;
        }
    }
    .sign-result-dialog{
        /deep/ .el-dialog__body{
            width: 100%;
        }
        text-align: center;
        div{
            text-align: center;
            margin: 20px auto 20px;
        }
        /deep/ .el-button{
            margin: auto;
        }
    }
    .sign-result{
        .el-button{
            margin-left: 20px;
            background: #ffd64e;
            border: none;
            width: 110px;
            height: 34px;
            padding-top: 12px;
            font-weight: bold;
        }

    }
</style>




