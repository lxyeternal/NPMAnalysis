<template>
  <div class="draftBox">
    <PanelTitle title="全部清单草稿"></PanelTitle>
    <div class="list-home">
      <div class="list-content">
        <div class="panel">
          <el-form class="form" size="small" label-width="76px" type="flex" justify="space-between">
            <el-row>
              <el-col>
                <el-form-item label="创建时间：">
                  <el-row class="two_label">
                    <el-col>
                      <el-date-picker value-format="yyyy-MM-dd" v-model="fromTime" size="" type="date" placeholder="选择时间" @change="handleChangeStartTm">
                      </el-date-picker>
                    </el-col>
                    <el-col class="tc">~</el-col>
                    <el-col>
                      <el-date-picker value-format="yyyy-MM-dd" v-model="toTime" size="" type="date" placeholder="选择时间" :picker-options="pickerOptionsEnd">
                      </el-date-picker>
                    </el-col>
                  </el-row>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <el-row>
            <el-col :span="24" align="center">
              <el-button class="small-btn" type="primary" size="small" @click="search()">搜索</el-button>
              <el-button class="small-btn" size="small" @click="clear()">清除</el-button>
            </el-col>
          </el-row>
        </div>
        <el-row>
          <el-col :span="12">
            <el-checkbox v-model="allChecked" :disabled="!draftBoxInfos.length" style="margin: 0 10px" @change="checkboxChange">全选</el-checkbox>
            <el-button class="small-btn" :class="{'isDisabled':draftBoxInfos.every(i=>!i.checked)}" :disabled="draftBoxInfos.every(i=>!i.checked)" size="small" @click="handleBarchDel">批量删除</el-button>
          </el-col>
        </el-row>
        <table class="table-default">
          <thead>
            <tr>
              <td class="checkbox">草稿名称</td>
              <td width="25%">创建时间</td>
              <td width="10%">操作</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in draftBoxInfos" :key="ind">
            <tr>
              <td>
                <div class="name">
                  <el-checkbox @change="handleSelectTableRow(item,ind)" v-model="item.checked"></el-checkbox>
                  <p class="ellipsisOne" :title="item.draftName">{{item.draftName}}</p>
                  <i class="tag" v-if="item.busiType === 'ONEWAY_ORDER'">单向合同</i>
                </div>
              </td>
              <td>
                <p>{{item.draftCreatTime}}</p>
              </td>
              <td>
                <p class="f12 blue hand" @click="handleEdit(item)">编辑</p>
                <p class="f12 blue hand" @click="handleDel(item)">删除</p>
              </td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!draftBoxInfos.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
        </div>
        <div class="table-pagination" v-if="draftBoxInfos.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
export default {
  components: {
    Loading, PanelTitle
  },
  data() {
    return {
      isLoading: false,

      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码
      draftBoxInfos: [],
      allChecked: false,
      fromTime: '',
      toTime: '',
      pickerOptionsEnd: {
        disabledDate: time => {
          if (this.fromTime) {
            return time.getTime() <= new Date(this.fromTime).getTime() - 86400000
          }
        }
      },
    };
  },
  methods: {
    // handleOpen(item) {
    //   this.$router.push({
    //     path:,
    //     query: {

    //     }
    //   });
    // },
    // 起始时间
    handleChangeStartTm(ev) {
      if (new Date(ev) > new Date(this.toTime)) {
        this.toTime = ""
      }
    },
    checkboxChange(bool) {
      console.log(bool);
      let arr = [];
      arr = [].concat(this.draftBoxInfos);
      arr.forEach(item => {
        item.checked = bool;
      });
      this.draftBoxInfos = arr;
      // this.draftBoxInfos.forEach(i => {
      //   this.$set(i, 'checkbox', this.allChecked)
      // });
    },
    // 选中行
    handleSelectTableRow(item, index) {
      this.$set(this.draftBoxInfos, index, item);
      this.checkAllSelect();
    },
    // 是否全选
    checkAllSelect() {
      this.allChecked = this.draftBoxInfos.every(item => {
        return item.checked;
      });
      if (!this.draftBoxInfos.length) {
        return false
      }
    },
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.getDraftsList()
      window.scrollTo(0, 0)
    },
    getDraftsList() {
      let param = {
        fromTime: this.fromTime,
        toTime: this.toTime,
        pageIndex: this.pageIndex
      };
      InterfaceService.getDraftsList(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.draftBoxInfos = data.respData.draftBoxInfos || []
          this.draftBoxInfos.forEach(i => {
            this.$set(i, 'checked', false)
          });
          this.allChecked = false
          this.total = data.respData.totalCount || 0;
          this.pageSize = data.respData.pageSize || 0;
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    handleDel(item) {
      this.$confirm(
        `是否确认删除草稿<sapn class="red">${item.draftName}</sapn>？删除后将无法恢复。`,
        "确认删除",
        {
          cancelButtonClass: "btn-custom-cancel width-auto",
          confirmButtonClass: "btn-custom-confirm width-auto",
          confirmButtonText: "确认删除",
          cancelButtonText: "取消",
          dangerouslyUseHTMLString: true,
          center: true,
        }).then(() => {
          this.deleteDrafts([item.id])
        }).catch(() => {
        });
    },
    handleBarchDel() {
      let ids = []
      this.draftBoxInfos.forEach(i => i.checked && ids.push(i.id))
      this.$confirm(
        '是否确认批量删除草稿？删除后将无法恢复。',
        "确认批量删除",
        {
          cancelButtonClass: "btn-custom-cancel width-auto",
          confirmButtonClass: "btn-custom-confirm width-auto",
          confirmButtonText: "确认批量删除",
          cancelButtonText: "取消",
          dangerouslyUseHTMLString: true,
          center: true,
        }).then(() => {
          this.deleteDrafts(ids)
        }).catch(() => {
        });

    },
    deleteDrafts(ids) {
      let param = {
        ids: ids
      };
      InterfaceService.deleteDrafts(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('删除成功')
          this.search()
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    handleEdit(item) {
      if (item.saveStep !== '2') {
        this.$router.push({
          path: '/draftOfCreateOrder',
          query: {
            draftsId: item.id,
            draftName: item.draftName,
            busiType: item.busiType
          }
        })
      } else {
        this.$router.push({
          path: '/confirmOrder',
          query: {
            draftsId: item.id,
            orderNo: item.orderNo || "",
            busiType: item.busiType
          }
        })
      }

    },
    search() {
      this.pageIndex = 1
      this.getDraftsList()
      window.scrollTo(0, 0)
    },
    clear() {
      this.fromTime = ''
      this.toTime = ''
      this.pageIndex = 1
      this.getDraftsList()
    },
    init() {
      this.getDraftsList()
    },
  },
  mounted() {
    this.init()
  },
};
</script>

<style lang="scss" scoped>
/deep/ .el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 100%;
}
.draftBox {
  /*width: 950px;*/
  margin: 0 auto;
  padding-bottom: 60px;
  .list-content {
    .panel {
      background-color: #fff;
      background: rgba(249, 249, 249, 1);
      padding: 20px 10px;
      margin: 20px 0;
      .two_label {
        .el-col {
          width: 130px;
          &:nth-child(2) {
            width: 20px;
          }
        }
      }
    }
    table {
      .name {
        display: flex;
        > p {
          max-width: 500px;
          line-height: 20px;
          margin-right: 5px;
        }
        .tag {
          width: 70px;
          height: 20px;
          background: #8b95ac;
          line-height: 20px;
          font-size: 14px;
          color: #fff;
          text-align: center;
          border-radius: 2px;
          display: inline-block;
          margin-top: 0px;
        }
      }
    }
  }
}
</style>
