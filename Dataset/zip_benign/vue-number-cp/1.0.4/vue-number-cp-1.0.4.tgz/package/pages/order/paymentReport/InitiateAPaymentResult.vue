<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :is-white-bg="true" :progress="title" :is-border-bottom="true"></SearchBar>
    <div class="inner-container" :style="{height:height,minHeight: '350px'}">
      <div class="content">
        <div class="icon-success"></div>
        <h3>发起成功</h3>
        <p class="tip">
          <br> 您可以点击【查看请款详情】查看请款计划详情，并进行签章。
        </p>
        <div>
          <el-button size="large" type="primary" @click="handleView">查看请款详情</el-button>
          <el-button size="large" @click="handleManage">请款管理列表</el-button>
        </div>
      </div>

    </div>

    <Footer></Footer>
  </div>
</template>
<script>
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Footer from "@/components/base/Footer";

export default {
  components: {
    Header,
    Footer,
    SearchBar
  },
  data() {
    return {
      type: "",
      executionId: "",
    };
  },
  computed: {
    title() {
      let str = `新增请款计划 - ${
        this.type === "progress" ? "进度款" : this.type === "advance" ? "合同预付款" : "材料进场预付款"
        }`;
      return str;
    },
    height() {
      let h =
        window.innerHeight ||
        document.documentElement.clientHeight ||
        document.body.clientHeight;
      return h - 200 - 55 - 34 - 160 + "px";
    },
    role() {
      return this.$store.state.userInfo
        ? this.$store.state.userInfo.bs
        : 0;
    }
  },
  methods: {
    handleView() {
      this.$router.push({
        path: "/paymentPlanDetail",
        query: {
          executionId: this.$route.query.executionId
        }
      });
    },
    handleManage() {
      let path = "";
      if (this.role == "S") {
        path = "/vendorCenter/paymentReport";
      } else if (this.role == "B") {
        path = "/purchaserCenter/paymentReport";
      }
      this.$router.push({
        path: path
      });
    },
    go(path) {
      this.$router.push({
        path: path
      });
    }
  },
  mounted() {
    this.type = this.$route.query.type;
    this.executionId = this.$route.query.executionId;
  }
};
</script>
<style lang="scss" scoped>
/deep/ .el-button {
  width: 200px;
}

h3 {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;
}
.content {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;

  p {
    margin-bottom: 20px;
  }
}

.icon-success {
  width: 56px;
  height: 80px;
  margin: auto;
  background: url(../../../assets/images/green_yes.png) no-repeat;
}

.tip {
  line-height: 18px;
}
</style>

