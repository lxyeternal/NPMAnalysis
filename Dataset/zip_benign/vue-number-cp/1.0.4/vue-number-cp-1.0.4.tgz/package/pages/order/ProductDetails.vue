<template>
  <div class="productDetails">
    <Header :is-white-bg="true"></Header>
    <SearchBar :search-type="5" progress="商品详情" :is-border-bottom="true" :isShowBigInfrastructure="false"></SearchBar>
    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <div class="page" v-if="spuBean.categoryId">
        <div class="product-info clearfloat">
          <div class="product-left fl">
            <!--<img v-if="spuBean.pdSpuAttachInfo && spuBean.pdSpuAttachInfo.length" :src="spuBean.pdSpuAttachInfo.filter(i=>i.type === '1')[0].url" alt="">-->
            <img v-if="!imagesOpts.normal_size.length" :src="null" v-error-img>
            <ProductZoomer v-if="imagesOpts.normal_size.length" :base-images="imagesOpts" :base-zoomer-options="zoomerOptions"></ProductZoomer>
          </div>
          <div class="product-right fl">
            <h1>{{spuBean.skuBeans[skuModelIndex].skuName}}</h1>
            <div class="product-content">
              <ul>
                <li>
                  <div style="padding-top: 38px;">基础价格(不含税)</div>
                  <template v-if="userInfo && userInfo.isLogin == '1'">
                    <div v-if="spuBean && spuBean.skuBeans && spuBean.skuBeans[skuModelIndex] && spuBean.skuBeans[skuModelIndex].skuPrice"><span style="color:#E93340">¥<i style="font-size: 50px;font-weight: 600;line-height: 70px;">{{spuBean.skuBeans[skuModelIndex].skuPrice | formatMoney}}</i></span></div>
                    <div v-else><span style="color:#E93340"><i style="font-size: 50px;font-weight: 600;line-height: 70px;">暂无报价</i></span></div>
                  </template>
                  <template v-else>
                    <div><span style="color:#E93340"><i style="font-size: 50px;font-weight: 600;line-height: 70px;">登录可见</i></span></div>
                  </template>
                </li>
                <!-- <li>
                  <div>价格有效期</div>
                  <div>{{spuBean.skuBeans[skuModelIndex].validityDateTo}}</div>
                </li> -->
                <li v-if="userInfo && userInfo.isLogin == '1' && templateList && templateList.length">
                  <span>运费(税前)</span>
                  <span class="freight-container">
                    <!-- <freightPopover v-if="templateList.length" :data="templateList"></freightPopover> -->
                    <span class="freight-btn" @click="handleClickFreightTemp">查看商品运费</span>
                  </span>
                </li>
                <li>
                  <div>税率</div>
                  <div>{{Number(spuBean.taxRate)*100}}%</div>
                </li>
                <li>
                  <div>品牌</div>
                  <div>{{spuBean.brandName}}</div>
                </li>
                <li v-if="spuBean.categoryId === '135'">
                  <div>计算方式</div>
                  <div>理计</div>
                </li>
              </ul>
            </div>
            <ul class="product-model">
              <div class="f14">型号</div>
              <li v-for="(item,index) in spuBean.skuBeans" :key="index+'skuBeans'" class="active" @click="skuModelIndex=index;handleTabs()">{{item.skuModel || '暂无'}}</li>
            </ul>
          </div>
        </div>
        <!-- <PanelTitle v-if="spuBean.skuBeans[skuModelIndex].isCombination === '1'" title="组价中的基础商品"></PanelTitle> -->
        <!-- <div class="title_tab">
          <div class="tabs__nav-prev" :class="{'active': translateX === 0}" v-show="isShowScroll" @click="scroll('left')"><i class="el-icon-caret-left"></i></div>
          <div class="tabs__nav clearfloat" :class="{'isShowScroll':isShowScroll}" ref="tabs__nav">
            <ul class="proList fl" ref="tabList">
              <li class="clearfloat" v-for="(item,index) in spuBean.skuBeans[skuModelIndex].combinationInfo" :key="index+'combinationInfo'">
                <div class="proBox hand fl" :title="item.skuName" @click="openNewPage(item)">
                  <div v-if="spuBean.skuBeans[skuModelIndex].isbasisMain" class="isbasisMain-yes">
                    <div class="main-img">
                      <img v-if="item.pdSkuAttachInfo.some(i=>i.type === '1')" :src="item.pdSkuAttachInfo.filter(i=>i.type === '1')[0].url" alt="">
                      <span v-else class="f12">暂无商品图</span>
                    </div>
                    <p class="f12 ellipsisTwo">{{item.skuName}}</p>
                  </div>

                  <div v-else class="isbasisMain-no">
                    <i>{{index+1}}</i>
                    <p class="f12 ellipsisTwo">{{item.skuName}}</p>
                  </div>
                </div>
                <i class="fl" :class="{'lh110':spuBean.skuBeans[skuModelIndex].isbasisMain}" v-if="index < spuBean.skuBeans[skuModelIndex].combinationInfo.length-1">+</i>
              </li>
            </ul>
          </div>
          <div class="tabs__nav-next" :class="{'active': translateX === -(scrollWidth - 1130)}" v-show="isShowScroll" @click="scroll('right')"><i class="el-icon-caret-right"></i></div>
        </div> -->
        <div class="product-detail">
          <div class="detail-left">
            <div class="supplier-info">
              <div class="top">{{productInfo.corpName}}</div>
              <div class="info">
                <p>经营模式：<span>{{productInfo.supplyTypeDisp}}</span></p>
                <p>联系人：<span v-if="productInfo.acCorpContactInfoBean">{{productInfo.acCorpContactInfoBean.name}}</span></p>
                <p>联系方式：<span v-if="productInfo.acCorpContactInfoBean">{{productInfo.acCorpContactInfoBean.mobile}}</span></p>
                <p>所在地区：<span v-if="productInfo.acCorpContactInfoBean">{{productInfo.acCorpContactInfoBean.cityCodeDisp || ''}}</span></p>
              </div>
            </div>
          </div>
          <div class="detail-right">
            <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
            <div class="detail-img" v-show="listType === '1'">
              <img v-for="(item,index) in spuBean.skuBeans[skuModelIndex].productDetailImgList" :key="index+'productDetailImgList'" :src="item.url" alt="">
            </div>
            <div class="specification-attributes" v-show="listType === '2'">
              <table class="standard-table" v-if="spuBean.skuBeans[skuModelIndex].attrInfos">
                <tbody v-for="(item,index) in spuBean.skuBeans[skuModelIndex].attrInfos" :key="index+'attrInfos'">
                  <tr v-if="index%2 === 0">
                    <td>{{item.attrInfoName}}</td>
                    <td>{{item.attrValueName + (item.unit || '')}}</td>
                    <td v-if="spuBean.skuBeans[skuModelIndex].attrInfos[index+1]">{{spuBean.skuBeans[skuModelIndex].attrInfos[index+1].attrInfoName}}</td>
                    <td v-if="spuBean.skuBeans[skuModelIndex].attrInfos[index+1]">{{spuBean.skuBeans[skuModelIndex].attrInfos[index+1].attrValueName + (spuBean.skuBeans[skuModelIndex].attrInfos[index+1].unit || '')}}</td>
                  </tr>
                </tbody>
              </table>
              <div class="basisPro" v-if="spuBean.skuBeans[skuModelIndex].combinationInfo">
                <div class="nakaYoko">
                  <p class="f12">基础商品属性说明</p>
                </div>
                <table class="standard-table" v-for="(item,index) in spuBean.skuBeans[skuModelIndex].combinationInfo" :key="index+'combinationInfo'">
                  <tbody>
                    <tr>
                      <td>基础商品名称{{index+1}}</td>
                      <td colspan='3'><span class="blue hand" @click="openNewPage(item)">{{item.skuName}}</span></td>
                    </tr>
                  </tbody>
                  <tbody v-for="(item1,index1) in item.attrInfos" :key="index1+'itemattrInfos'">
                    <tr v-if="index1%2 === 0">
                      <td>{{item1.attrInfoName}}</td>
                      <td>{{item1.attrValueName + (item1.unit || '')}}</td>
                      <td v-if="item.attrInfos[index1+1]">{{item.attrInfos[index1+1].attrInfoName}}</td>
                      <td v-if="item.attrInfos[index1+1]">{{item.attrInfos[index1+1].attrValueName + (item.attrInfos[index1+1].unit || '')}}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="attach" v-show="listType === '3'">
              <table class="standard-table" v-if="spuBean.skuBeans[skuModelIndex].bidSurchangeBeanList">
                <tbody v-for="(item,index) in spuBean.skuBeans[skuModelIndex].bidSurchangeBeanList" :key="index+'bidSurchangeBeanList'">
                  <tr>
                    <td width="125px">附加项{{index+1}}</td>
                    <td style="border-right: none">{{item.surchangeName}}</td>
                    <td style="border-right: none" width="100px">{{item.surchangeUnit}}</td>
                    <td width="140px" class="tr">
                      <template v-if="userInfo && userInfo.isLogin == '1'">
                        <div v-if="item.surchangeUnitPrice">
                          ¥ {{item.surchangeUnitPrice | formatMoney}}
                        </div>
                        <div v-else><span>暂无报价</span></div>
                      </template>
                      <template v-else>
                        <div><span>登录可见</span></div>
                      </template>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div class="basis-product" v-show="listType === '4'">
              <TableThead :TopDistance="660" width="930" left="260">
                <tr slot="tr">
                  <td width="40px">序号</td>
                  <td width="300px" style="padding-left: 80px">商品名称/型号</td>
                  <td class="tr" width="150px">不含税单价(元)</td>
                  <td width="230px" class="tr">数量</td>
                  <td class="tr" width="150px">小计(元)</td>
                </tr>
              </TableThead>
              <table class="table-default">
                <thead>
                  <tr>
                    <td width="40px">序号</td>
                    <td width="300px" style="padding-left: 80px">商品名称/型号</td>
                    <td class="tr" width="150px">不含税单价(元)</td>
                    <td width="230px" class="tr">数量</td>
                    <td class="tr" width="150px">小计(元)</td>
                  </tr>
                </thead>
                <tbody v-for="(item,ind) in spuBean.skuBeans[skuModelIndex].combinationInfo" :key="ind">
                  <tr v-if="item.isExtraFee === '1'">
                    <td>{{ind + 1}}</td>
                    <td style="padding-left: 81px;">
                      <p class="goods-name">{{item.skuName}}</p>
                    </td>
                    <td class="tr">{{NumberUtil.accMul(Number(item.skuPrice),100)}}%</td>
                    <td class="tr" colspan="2">
                      {{specialSubtotal(item,true)}}
                      <el-popover popper-class="dark-popover" trigger="hover" placement="top">
                        <div style="color: #fff;width: 185px;">
                          该{{item.skuName}}的小计：是所有子商品总价X比例
                        </div>
                        <i slot="reference" style="display: inline-block;width: 14px;text-align: center;height: 14px;line-height: 14px;background: linear-gradient(180deg, #101018 0%, #5A5858 100%);border-radius: 50%;color: #fff">?</i>
                      </el-popover>
                    </td>
                  </tr>
                  <tr v-else>
                    <td>
                      {{ind + 1}}
                    </td>
                    <td>
                      <div class="thumbnail fl" :class="{'active':item.pdSkuAttachInfo && item.pdSkuAttachInfo.every(j=>j.type !== '1')}">
                        <img v-if="item.pdSkuAttachInfo && !item.pdSkuAttachInfo.every(j=>j.type !== '1')" :src="item.pdSkuAttachInfo.find(j=>j.type === '1').url" alt="">
                      </div>
                      <div class="fr" style="width: calc(100% - 66px);margin-left: 6px;">
                        <p :title="item.skuName" class="goods-name hover-underline hand" @click="openNewPage(item)">{{item.skuName}}</p>
                        <p style="margin-top: 7px;">型号：{{item.skuModel ? item.skuModel : '-'}}</p>
                        <p class="tag" v-if="item.isCombination == '1'">组价商品</p>
                        <p class="tag bg-lightSteelBlue" v-if="item.bidSurchangeBeanList && item.bidSurchangeBeanList.length">含附加项</p>
                      </div>
                    </td>
                    <td class="tr">
                      <p>{{skuPriceAttach(item) | formatMoney}}</p>
                      <span class="grey f12" v-if="item.isCombination !== '1' && item.bidSurchangeBeanList && item.bidSurchangeBeanList.filter(i=>i.isCheck == '1').length">(含附加项费)</span>
                    </td>
                    <td class="tr">{{item.skuCount}}{{item.goodsUnit}}</td>
                    <td class="tr">{{subtotal(skuPriceAttach(item),item.skuCount,true)}}</td>
                  </tr>
                  <tr v-if="item.isCombination !== '1' && item.bidSurchangeBeanList && item.bidSurchangeBeanList.filter(i=>i.isCheck == '1').length">
                    <td colspan="5" style="padding: 0px;">
                      <div class="additional-items">
                        <div class="clearfloat">
                          <div class="fl f12 yellow" style="font-weight: 600;">附加项说明：</div>
                          <div class="fl" style="width: calc(100% - 90px);">
                            <p class="f12 tl" v-for="(a,index) in item.bidSurchangeBeanList.filter(i=>i.isCheck == '1')" :key="index+'bidSurchangeBeanList'">附加项{{index+1}}：{{a.surchangeName}}&nbsp;&nbsp;&nbsp;&nbsp;X{{a.surchangeUnitCnt + a.surchangeUnit}}<span class="purple">&nbsp;&nbsp;&nbsp;¥ {{subtotal(a.surchangeUnitPrice,a.surchangeUnitCnt,true)}}</span></p>
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
    <FreightPopoverDialog ref="freightPopoverDialog" v-if="templateList.length" :data="templateList"></FreightPopoverDialog>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import SearchBar from "@/components/SearchBar";
import Header from "@/components/base/Header";
import PanelTitle from "@/components/base/PanelTitle";
import Loading from "@/components/base/Loading";
import { NumberUtil } from '@/utils/numberUtil';
import Breadcrumb from "@/components/base/Breadcrumb";
import ProductZoomer from "@/components/ProductZoomer";
import TableThead from "@/components/base/TableThead";
import accountMixin from "@/mixins/account";
import FreightPopover from '@/components/product/FreightPopover';
import FreightPopoverDialog from '@/components/product/dialog/FreightPopoverDialog';

const form = {
  supplierType: '', //供应商性质（"0":厂家;"1":代理商;"2":经销商;"3":施工;"4":监理）
  spuName: '', // 组价商品名称
  spuModel: '',
  categoryId: [],
  brandId: '',
  goodsUnit: '',
  freightTemplateId: '',
};
export default {
  name: "CreateGroupGoods",
  components: {
    SearchBar,
    Header,
    PanelTitle,
    Breadcrumb,
    Loading,
    ProductZoomer,
    FreightPopover,
    FreightPopoverDialog,
    TableThead
  },
  mixins: [accountMixin],
  data() {
    return {
      templateList: [],
      isLoading: false,
      fromType: '',
      breadcrumb: [],
      imagesOpts: {
        normal_size: []
      },
      zoomerOptions: {
        zoomFactor: 3,
        pane: "pane",
        hoverDelay: 100,
        namespace: "zoomer",
        move_by_click: true,
        scroll_items: 5,
        choosed_thumb_border_color: "#ffd64e"
      },
      NumberUtil: NumberUtil,
      productInfo: {},
      listType: '1',
      tabs: [
        { label: "商品详情", listType: '1', active: true },
        { label: "规格属性", listType: '2' }
      ],
      skuModelIndex: 0,
      spuId: '',//商品spu_id（编辑时必传）
      skuId: '',//商品skuId（编辑时必传）
      spuBean: {},

      bs: 'B',
      isShowScroll: false,
      translateX: 0,
      scrollWidth: 0,
    }
  },
  computed: {
    userInfo() {
      console.log(this.$store.state.userInfo);
      return this.$store.state.userInfo || {}
    },
  },
  watch: {
    translateX(val) {
      this.$refs.tabList.style.transform = `translateX(${String(val)}px)`
    }
  },
  mounted() {
    this.bs = this.$store.state && this.$store.state.userInfo && this.$store.state.userInfo.bs
    this.spuId = this.$route.query.spuId
    this.skuId = this.$route.query.skuId
    this.fromType = this.$route.query.from
    this.getProductListDetail();
    if (this.fromType !== 'shelf') {
      this.breadcrumb = this.bs === 'B' ? [
        { name: `${this.bigInfrastructure ? '' : '采购商'}管理中心`, path: '/purchaserCenter/accountInfo' },
        { name: '商品管理', path: '/purchaserCenter/bidProduct' },
        { name: '商品详情' },
      ] : [
          { name: `${this.bigInfrastructure ? '' : '供应商'}管理中心`, path: '/vendorCenter/accountInfo' },
          { name: '商品管理', path: '/vendorCenter/authorizeSelfPro?pageType=1' },
          { name: '商品详情' },
        ];

    }

  },
  methods: {
    handleClickFreightTemp() {
      this.$refs.freightPopoverDialog && this.$refs.freightPopoverDialog.open(this.templateList || [])
    },
    openNewPage(item) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: item.spuId,
          skuId: item.skuId,
          corpId: this.$route.query.corpId || ''
        }
      }).href, '_blank')
    },
    // 放大镜
    hiddenVr(bool) {
      this.showVr = bool
    },
    // 判断是否出现滚动条
    // isScroll() {
    //   this.$nextTick(() => {
    //     this.$refs.tabList.offsetWidth > 1190 ? this.isShowScroll = true : this.isShowScroll = false
    //     this.translateX = 0
    //     this.scrollWidth = this.$refs.tabList.scrollWidth
    //   })
    // },
    // scroll(type) {
    //   if (type == 'left') {
    //     if (this.translateX < 0) {
    //       this.translateX = this.translateX >= -1130 ? 0 : this.translateX + 1130
    //     }
    //   } else {
    //     const scrollWidth = this.scrollWidth - 1130
    //     if (this.translateX > -scrollWidth) {
    //       this.translateX = this.translateX + scrollWidth >= 1130 ? this.translateX - 1130 : this.translateX - (this.translateX + scrollWidth)
    //     }
    //   }
    // },
    //   切换tab
    handleChangeTab(tab) {
      this.listType = tab.listType
    },
    handleTabs() {
      console.log(this.spuBean.skuBeans.length && this.spuBean.skuBeans[this.skuModelIndex].productDetailImgList);
      if (this.spuBean.skuBeans.length && this.spuBean.skuBeans[this.skuModelIndex].productDetailImgList.length) {
        this.listType = '1'
        this.tabs = [
          { label: "商品详情", listType: '1', active: true },
          { label: "规格属性", listType: '2' }
        ]
      } else {
        this.listType = '2'
        this.tabs = [
          { label: "规格属性", listType: '2', active: true }
        ]
      }
      // 附加项
      const obj = this.spuBean.skuBeans[this.skuModelIndex]
      if (obj.isCombination === '0' && obj.bidSurchangeBeanList && obj.bidSurchangeBeanList.length) {
        this.listType = '3'
        this.tabs[0].active = false
        this.tabs.push({ label: "附加项", listType: '3', active: true }, )
      }
      // 组价基础商品
      if (obj.isCombination === '1') {
        this.tabs.push({ label: "组价基础商品", listType: '4' }, )
      }
    },
    // 计算税前单价(元)	是否包含附加项费
    skuPriceAttach(item) {
      if (item.bidSurchangeBeanList && item.bidSurchangeBeanList.filter(i => i.isCheck == '1').length) {
        return this.surchangeBasis(item.bidSurchangeBeanList, item)
      } else {
        return item.skuPrice
      }
    },
    // 含附加项的税前单价
    surchangeBasis(list, info) {
      let num = 0;
      list.forEach(item => {
        if (item.isCheck == '1') {
          num = NumberUtil.numAdd(num, +NumberUtil.accMul(Number(item.surchangeUnitPrice), Number(item.surchangeUnitCnt)))
        }
      })
      const a = NumberUtil.numAdd(num, +info.skuPrice)
      return a
    },
    // 小计
    subtotal(skuPrice, skuCount, type) {
      let num
      if (skuPrice && skuCount) {
        num = NumberUtil.accMul(Number(skuPrice), Number(skuCount))
        if (type) num = NumberUtil.formatMoney(num)
      } else {
        num = '-'
      }
      return num
    },
    // 特殊商品小计
    specialSubtotal(data, type) {
      let num = 0;
      this.spuBean.skuBeans[this.skuModelIndex].combinationInfo.forEach(item => {
        if (item.isExtraFee !== '1' && item.isAddExtraFee == '1') {
          num = NumberUtil.numAdd(num, +NumberUtil.accMul(Number(this.skuPriceAttach(item)), Number(item.skuCount)))
        }
      })
      let result = NumberUtil.accMul(num, data.skuPrice)
      if (type) result = NumberUtil.formatMoney(result)
      if (result) {
        return result
      } else {
        return type ? '-' : result
      }
    },
    getProductListDetail() {
      const supplierCorpId = this.$route.query.corpId || ''
      const param = {
        supplierCorpId: supplierCorpId,
        spuId: this.spuId,
        skuId: this.skuId,
      };
      InterfaceService.getProductListDetail(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.spuBean = data.respData.spuBean || {}
          this.spuBean.skuBeans = this.spuBean.skuBeans || []
          this.spuBean.skuBeans.forEach(i => {
            let productDetailImgList = [];
            if (i.isCombination === '1' && i.combinationInfo) {
              if (this.spuBean.pdSpuAttachInfo && this.spuBean.pdSpuAttachInfo.filter(i => i.type !== '1').length) {
                productDetailImgList = this.spuBean.pdSpuAttachInfo.filter(i => i.type !== '1')
              } else {
                i.combinationInfo.forEach(j => {
                  if (j.pdSkuAttachInfo) {
                    j.pdSkuAttachInfo.forEach(k => k.type == '1' && productDetailImgList.push(k))
                  }
                })
              }
              // 基础商品是否有商品图
              const a = i.combinationInfo.some(j => j.pdSkuAttachInfo)
              this.$set(i, 'isbasisMain', a)
            } else {
              productDetailImgList = this.spuBean.pdSpuAttachInfo.filter(i => i.type !== '1') || []
            }
            productDetailImgList = productDetailImgList.sort(this.compare("position"));
            productDetailImgList.forEach(item => {
              item.url = item.url.replace("+", "%2B")
            })
            this.$set(i, 'productDetailImgList', productDetailImgList)
            console.log(productDetailImgList);
            this.spuBean.pdSpuAttachInfo.forEach((item, index) => {
              if (item.type == 1) {
                this.imagesOpts.normal_size.push({
                  id: index,
                  url: item.url
                });
                // if(item.vrFlg == "1"){
                //   this.hasVr = item.url
                //   this.showVr = true
                // }
                // console.log(this.hasVr,this.showVr)
              }
            });

          })

          console.log(this.spuBean, '----spuBeanyunf运费末班');

          // 运费模板
          if (this.spuBean && this.spuBean.carryModeList) {
            this.templateList = this.spuBean.carryModeList;
          }

          console.log(this.spuBean.skuBeans)
          this.handleTabs()
          this.productInfo = data.respData
          // this.isScroll()
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    compare(property) {
      return function (obj1, obj2) {
        var value1 = obj1[property];
        var value2 = obj2[property];
        return value1 - value2;
      }
    },
  }
}
</script>

<style scoped lang="scss">
.productDetails {
  .page {
    padding-bottom: 60px;
    .product-info {
      width: 100%;
      margin-bottom: 30px;
      .product-left {
        width: 400px;
        height: 400px;
        > img {
          width: 100%;
          max-width: 100%;
          max-height: 100%;
          height: auto;
        }
      }
      .product-right {
        margin-left: 10px;
        width: calc(100% - 410px);
        > h1 {
          font-size: 18px;
          font-weight: 600;
          line-height: 25px;
          color: #444444;
          margin-bottom: 6px;
        }
        .product-content {
          width: 100%;
          padding: 20px;
          background: #f5f5f5;
          border-top: 2px solid #444;
          ul {
            li {
              margin-bottom: 10px;
              display: flex;
              align-items: center;
              &:first-child {
                margin-bottom: 0px;
              }
              & > div:nth-child(1) {
                width: 118px;
                margin-right: 10px;
                font-size: 14px;
                line-height: 20px;
                color: #888;
              }
              & > div:nth-child(2) {
                font-size: 14px;
                line-height: 20px;
                color: #444;
              }
            }
          }
        }
        .product-model {
          display: flex;
          margin-top: 20px;
          > div {
            width: 48px;
            line-height: 46px;
            color: #888;
          }
          > li {
            min-width: 120px;
            padding: 0 20px;
            height: 46px;
            line-height: 46px;
            text-align: center;
            font-size: 14px;
            margin-right: 10px;
            &.active {
              color: #fff;
              background-color: #444;
            }
          }
        }
      }
    }
    .product-detail {
      width: 100%;
      display: flex;
      .detail-left {
        width: 240px;
        .top {
          background-color: #f5f5f5;
          font-size: 16px;
          line-height: 22px;
          padding: 8px 14px;
        }
        .info {
          border: 1px solid #f5f5f5;
          border-top: none;
          padding: 14px 11px 22px;
          > p {
            font-size: 12px;
            line-height: 17px;
            color: #888;
            margin-bottom: 10px;
            > span {
              color: #444;
            }
          }
        }
      }
      .detail-right {
        width: calc(100% - 260px);
        margin-left: 20px;
        .detail-img {
          width: 100%;
          > img {
            display: block;
            max-width: 100%;
          }
        }
        .specification-attributes {
          .standard-table {
            width: 100%;
            border-left: 1px solid #eee;
            border-top: 1px solid #eee;
            tr {
              td {
                padding: 12px 10px 11px;
                font-size: 12px;
                line-height: 17px;
                vertical-align: middle;
                word-break: break-all;
                border-right: 1px solid #eee;
                border-bottom: 1px solid #eee;
                &:nth-child(odd) {
                  width: 125px;
                  background: #f5f5f5;
                  color: #888;
                }
                &:nth-child(even) {
                  min-width: 342px;
                }
              }
            }
          }
          .basisPro {
            .standard-table {
              margin-bottom: 10px;
            }
          }
          .nakaYoko {
            height: 1px;
            width: 100%;
            background-color: #eee;
            position: relative;
            margin: 30px 0 20px;
            > p {
              color: #888888;
              position: absolute;
              left: 50%;
              transform: translateX(-50%) translateY(-50%);
              padding: 0 26px;
              background-color: #fff;
            }
          }
        }
        .attach {
          .standard-table {
            width: 100%;
            border-left: 1px solid #eee;
            border-top: 1px solid #eee;
            tr {
              td {
                padding: 12px 10px 11px;
                font-size: 12px;
                line-height: 17px;
                vertical-align: middle;
                word-break: break-all;
                border-right: 1px solid #eee;
                border-bottom: 1px solid #eee;
                &:first-child {
                  background: #f5f5f5;
                  color: #888;
                }
              }
            }
          }
        }
        .basis-product {
          .table-default {
            tbody {
              border-bottom: 1px solid #eee;
            }
            tr {
              border-bottom: none;
              td {
                .thumbnail {
                  width: 60px;
                  height: 60px;
                  position: relative;
                  overflow: hidden;
                  &.active {
                    background-color: #eee;
                  }
                  > img {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    pointer-events: none;
                    height: auto;
                  }
                }
                .goods-name {
                  width: 100%;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  display: -webkit-box;
                  -webkit-line-clamp: 2;
                  -webkit-box-orient: vertical;
                }
              }
            }
          }
          .additional-items {
            border-top: 1px dashed #eee;
            padding: 14px 0;
            width: 875px;
            margin-left: 58px;
            // > div {
            //   > div {
            //     > p {
            //       margin-bottom: 6px;
            //       &:last-child {
            //         margin-bottom: 0px;
            //       }
            //     }
            //   }
            // }
          }
        }
      }
    }
    // .title_tab {
    //   width: 100%;
    //   display: flex;
    //   overflow: hidden;
    //   margin-bottom: 30px;
    //   .tabs__nav-prev,
    //   .tabs__nav-next {
    //     width: 16px;
    //     height: 25px;
    //     margin: auto 0;
    //     cursor: pointer;
    //     background: linear-gradient(
    //       180deg,
    //       rgba(215, 176, 100, 1) 0%,
    //       rgba(236, 206, 139, 1) 100%
    //     );
    //     text-align: center;
    //     line-height: 25px;
    //     > i {
    //       color: #fff;
    //     }
    //     &.active {
    //       background: linear-gradient(180deg, #bbbbbb 0%, #dddddd 100%);
    //       cursor: no-drop;
    //     }
    //   }
    //   .tabs__nav {
    //     width: 100%;
    //     // overflow-x: auto;
    //     // overflow-y: hidden;
    //     overflow: hidden;
    //     .proList {
    //       white-space: nowrap;
    //       display: inline-block;
    //       white-space: nowrap;
    //       position: relative;
    //       transform: translateX(0px);
    //       transition: transform 0.3s;
    //       li {
    //         display: inline-block;
    //         .proBox {
    //           font-size: 12px;
    //           line-height: 17px;
    //           .isbasisMain-yes {
    //             flex-direction: column;
    //             > .main-img {
    //               width: 110px;
    //               height: 110px;
    //               line-height: 110px;
    //               text-align: center;
    //               border: 1px solid #eeeeee;
    //               position: relative;
    //               overflow: hidden;
    //               > img {
    //                 position: absolute;
    //                 top: 0;
    //                 left: 0;
    //                 width: 100%;
    //                 pointer-events: none;
    //                 height: auto;
    //               }
    //               > span {
    //                 color: #888;
    //               }
    //             }
    //             > p {
    //               height: 34px;
    //               margin-top: 8px;
    //             }
    //             &:hover {
    //               p {
    //                 color: #0082ff;
    //               }
    //             }
    //           }
    //           .isbasisMain-no {
    //             width: 136px;
    //             height: 43px;
    //             border: 1px solid #eeeeee;
    //             &:hover {
    //               border: 1px solid #0082ff;
    //               p {
    //                 color: #0082ff;
    //               }
    //             }
    //             > i {
    //               width: 15px;
    //               height: 15px;
    //               background: #0082ff;
    //               font-size: 12px;
    //               text-align: center;
    //               line-height: 15px;
    //               color: #fff;
    //             }
    //             > p {
    //               margin: 0 0 0 6px;
    //             }
    //           }
    //           > div {
    //             font-size: 12px;
    //             line-height: 17px;
    //             display: flex;
    //             align-items: center;
    //             height: 100%;
    //             > p {
    //               max-width: 110px;
    //               max-height: 34px;
    //               white-space: nowrap;
    //               white-space: initial;
    //               overflow: hidden;
    //             }
    //           }
    //         }
    //         > i {
    //           width: 36px;
    //           line-height: 45px;
    //           text-align: center;
    //           font-size: 12px;
    //           &.lh110 {
    //             line-height: 110px;
    //           }
    //         }
    //       }
    //     }
    //     &.isShowScroll {
    //       width: calc(100% - 60px);
    //       margin: 0 14px 0px;
    //     }
    //   }
    // }
  }
}
.freight-container {
  margin-left: 12px;
  .freight-btn {
    cursor: pointer;
    color: #0082ff;
  }
  & > div {
    display: flex;
    align-items: center;
    /deep/ .freight-text {
      min-width: 300px;
    }
  }
}
</style>