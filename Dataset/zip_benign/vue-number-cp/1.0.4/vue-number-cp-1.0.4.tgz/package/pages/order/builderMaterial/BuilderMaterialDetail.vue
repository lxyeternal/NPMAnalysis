<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <SearchBar :search-type="5" :progress="'施工要料单详情'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
        <div class="inner-container">
            <BuilderMaterialProcess v-if="material.operFlowList&&material.operFlowList.length" :process="material.operFlowList"></BuilderMaterialProcess>
            <div>
                <PanelTitle title="清单信息"></PanelTitle>
                <div class="material-info">
                    <el-row>
                        <el-col :span="8">
                            <p>
                                <label>施工单位：</label>{{material.constructorName}}
                            </p>
                            <p>
                                <label>要料单：</label>
                                <a @click="handleDownload(material.attachUrl)">下载</a>
                            </p>
                        </el-col>
                        <el-col :span="8">
                            <p>
                                <label>要料申请人：</label>{{material.applyCustName}}
                                <template v-if="material.applyCustMobile">(Tel：{{material.applyCustMobile}})</template>
                            </p>
                            <!-- <p>
                                <label>线下要货清单：</label>
                                <a>下载</a>
                            </p> -->
                        </el-col>
                        <el-col :span="8">
                            <p>
                                <label>创建时间：</label>{{material.creTm|datetime}}
                            </p>
                        </el-col>
                    </el-row>
                </div>
            </div>
            <div class="table">
                <table>
                    <thead>
                        <tr>
                            <td>申请单序号</td>
                            <td>材料类目</td>
                            <td>货品名称</td>
                            <td>使用标段</td>
                            <td>型号</td>
                            <td>物料描述</td>
                            <td>单位</td>
                            <td>本次申请数量</td>
                            <td>已发起数量</td>
                            <td>备注</td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(row,index) in material.applyDetailList" :key="index" :class="{'offline':row.matchStatus==2}">
                            <td>{{row.no}}
                                <div v-if="row.matchStatus==2" class="tip">需线下采购</div>
                            </td>
                            <td>{{row.categoryFullName}}</td>
                            <td>{{row.materialName}}</td>
                            <td>{{row.location}}</td>
                            <td>{{row.model}}</td>
                            <td>{{row.description}}</td>
                            <td>{{row.unit}}</td>
                            <td>{{row.applyCount}}</td>
                            <td>{{row.submitCount}}</td>
                            <td>{{row.remark}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="material-total">
                <p style="font-weight:bold;color:#444;">要求到货时间：
                    <span class="red-font">{{material.requireDt|datetime}}</span>
                </p>
                <p>送货至：{{material.deliveryAddr}}</p>
                <p>收货人：{{material.applyCustName}}&nbsp;{{material.applyCustMobile}}</p>
            </div>
        </div>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import BuilderMaterialProcess from "@/components/order/builderMaterial/BuilderMaterialProcess";

import { InterfaceService } from "@/services/api";
export default {
    components: {
        Header,
        SearchBar,
        PanelTitle,
        BuilderMaterialProcess,
        Loading
    },
    data() {
        return {
            isLoading: false,
            applyNo: "",
            material: {}
        };
    },
    methods: {
        handleDownload(attachUrl) {
            if (!attachUrl) return;
            let name = attachUrl.split("?")[0];
            name = name.split("/").pop();
            const files = [{ name: decodeURIComponent(name), url: attachUrl }];
            this.$download(files).then(() => {
                this.$message.success("已下载");
            });
        },
        getDetail() {
            const params = {
                applyNo: this.applyNo
            };
            InterfaceService.getBuilderMaterialDetail(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.material = data.respData;
                        if(this.material.applyDetailList&&this.material.applyDetailList.length){
                            this.material.applyDetailList.forEach(item=>{
                                item.applyCount = + item.applyCount;
                                item.submitCount = + item.submitCount;
                            })
                        }
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        init() {
            this.getDetail();
        }
    },
    mounted() {
        this.applyNo = this.$route.query.applyNo;
        this.init();
    }
};
</script>

<style lang="scss" scoped>
.table {
    /deep/ .el-button {
        font-size: 12px;
    }

    width: 100%;
    margin-bottom: 20px;
    min-height: 350px;
    line-height: 23px;
    font-size: 12px;
    table {
        width: 100%;
    }
    td {
        position: relative;
        padding: 25px 10px;
        vertical-align: middle;
        word-break: break-word;
    }

    thead {
        text-align: center;
        white-space: nowrap;
        font-size: 14px;
        color: #909399;
        background: #f5f5f5;
    }

    tbody {
        text-align: center;

        tr:hover {
            background: #e8f3fd;
        }

        td {
            border-bottom: 1px solid #ebeef5;
        }
    }

    tr.offline {
        color: #aaaaaa;

        .tip {
            position: absolute;
            top: 50%;
            left: 60%;
            padding: 5px;
            border: 1px solid #aaaaaa;
            line-height: 20px;
            white-space: nowrap;
            transform: translate(-50%, -50%) rotatez(-20deg);
            opacity: 0.8;
        }
    }
}

.material-info {
    margin-bottom: 20px;
    line-height: 25px;
    font-size: 12px;

    /deep/ .el-col {
        padding: 0 10px;
    }

    p {
        width: 100%;
        display: flex;
        padding-right: 10px;
        word-break: break-word;
        white-space: normal;

        & > span {
            display: inline-block;
            flex: 1 1 0%;
        }
    }

    label {
        white-space: nowrap;
        color: #888888;
    }

    a {
        color: #0082ff;
    }
}

.material-total {
    padding: 20px 40px;
    border-top: 1px solid #e2e2e2;
    text-align: right;
    font-size: 12px;
    line-height: 25px;
    color: #888888;
    background: #f5f5f5;

    label {
        display: block;
        color: #444444;
    }

    .total-content {
        margin-bottom: 10px;
    }

    .total {
        font-weight: bold;
        font-size: 14px;
    }

    .bold {
        font-weight: bold;
    }

    .big {
        font-size: 20px;
    }

    .red-font {
        color: #e94650;
    }
}
</style>
