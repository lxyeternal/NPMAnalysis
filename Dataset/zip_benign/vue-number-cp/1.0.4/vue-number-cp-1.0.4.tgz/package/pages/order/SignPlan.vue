<template>
    <div class="product">
        <PanelTitle :tabs="tabs"></PanelTitle>
        <div class="panel-content">
            <el-form class="form" size="small" label-width="100px">
                <el-row>
                    <el-col :span="8">
                        <el-form-item label="计划合同名称" size="small">
                                <el-input v-model="plan.contractName" placeholder="请输入计划合同名称"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="签约年度">
                                <el-date-picker type="year" placeholder="请选择签约年度" value-format="yyyy" v-model="plan.planYear" style="width: 100%;"></el-date-picker>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="签约季度" >
                            <el-select v-model="plan.season" placeholder="请选择签约季度">
                                <el-option label="1季度" value="1"></el-option>
                                <el-option label="2季度" value="2"></el-option>
                                <el-option label="3季度" value="3"></el-option>
                                <el-option label="4季度" value="4"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24" class="form-btns">
                        <el-button type="primary" size="small" @click="handleSearch"> 搜索</el-button>
                        <el-button size="small" @click="handleClear">清除</el-button>
                    </el-col>
                </el-row>
            </el-form>
        </div>
        <div class="product-table">
            <table>
                <thead>
                    <tr>
                        <td>签约季度</td>
                        <td>计划合同名称</td>
                        <td>计划供应商</td>
                        <!-- <td>下单人</td> -->
                        <td>计划金额
                            <!--<i class="el-icon-d-caret" v-if="sortList[2]==0"></i>-->
                            <!--<i class="el-icon-caret-top active" v-if="sortList[2]==1"></i>-->
                            <!--<i class="el-icon-caret-bottom active" v-if="sortList[2]==2"></i>-->
                        </td>
                    </tr>
                </thead>
                <template v-if="planList.length">
                    <tbody v-for="(item,index) in planList" :key="index" class="tc tbody-row">
                        <tr>
                            <td class="nowrap">
                                <span v-if="item.planYear && item.season">{{item.planYear}}年{{item.season}}季度</span>
                            </td>
                            <td>
                                <span v-if="item.contractName">《{{item.contractName}}》</span>
                            </td>
                            <td>
                                <span v-if="item.supplierName">{{item.supplierName}}</span>
                                <span v-else>-</span>
                            </td>
                            <td>
                                <span v-if="item.planAmount">{{item.planAmount|formatMoney}}元</span>
                            </td>
                        </tr>
                    </tbody>
                </template>
            </table>
            <div class="table-pagination" v-if="planList.length">
                <el-pagination @current-change="handleCurrentChange" :current-page="plan.pageIndex" :page-size="pageSize" :total="totalCount" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                </el-pagination>
            </div>
            <div class="product-empty" v-if="!planList.length&&!isLoading">
                <img src="@/assets/images/icon-no-product.png">
                <p>没有搜索到相关签约计划，请重新修改搜索条件搜索！</p>
            </div>
        </div>
        <Loading :is-loading="isLoading"></Loading>
    </div>

</template>

<script>
    import { InterfaceService } from "@/services/api";
    import Loading from "@/components/base/Loading";
    import PanelTitle from '@/components/base/PanelTitle';
    const plan = {
        purchaserId:'',
        supplierId:'',
        contractName:'',
        planYear:'',
        season:"",
        progress:"",
        pageIndex:1,
    };
    export default {
        name: "SignPlan",
        components:{
            Loading,
            PanelTitle
        },
        data(){
            return {
                tabs:[{ label: "签约计划", index: 1, active: true }],
                plan: Object.assign({}, plan),
                planList:[],
                totalCount:0,
                isLoading: false,
                pageSize: 10,
            }
        },
        computed: {
            corpId() {
                return this.$store.state.userInfo && this.$store.state.userInfo.corpId;
            }
        },
        methods: {
            init(){
                this.plan.purchaserId = this.corpId;
                this.getSignPlan();
            },
            handleSearch(){
                this.getSignPlan();
            },
            handleClear(){
                this.plan = Object.assign({}, plan);
            },
            getSignPlan(){    //获取签约计划
                const params={
                    purchaserId: this.corpId
                };
                for (let i in this.plan) {
                    if (this.plan[i]) {
                        params[i] = this.plan[i];
                    }
                }
                if (params.planYear){
                    params.planYear = params.planYear.slice(0,4)
                }

                params.enterFrom = 1;
                InterfaceService.getSignPlan(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.planList = data.respData.planList;
                            this.totalCount = data.respData.totalCount;
                            this.pageSize = data.respData.pageSize;
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            // handleSort(index) {
            //     let arr = [].concat(this.sortList);
            //     this.sortList.forEach((item, i) => {
            //         if (index == i) {
            //             if (item == 0) {
            //                 arr[i] = 2;
            //             } else if (item == 2) {
            //                 arr[i] = 1;
            //             } else {
            //                 arr[i] = 0;
            //             }
            //         } else {
            //             arr[i] = 0;
            //         }
            //     });
            //     this.sortList = arr;
            // },
            handleCurrentChange(page) {
                this.plan.pageIndex = page;
                this.getSignPlan();
                window.scrollTo(0,0)
            },
        },
        mounted(){
            this.init()
        }
    }
</script>

<style lang="scss" scoped>
    .hand + .hand {
        margin-left: 10px;
    }
    .price-tip {
        cursor: pointer;
        color: #a9a9aa;

        &:hover {
            color: #0082ff;
        }
    }

    .product {
        font-size: 14px;
    }

    .pointer {
        cursor: pointer;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }

        .active {
            color: #ffd64e;
        }
    }

    .nowrap {
        white-space: nowrap;
    }

    .panel-content {
        margin-bottom: 20px;
        padding: 20px 10px;
        background: #f5f5f5;
    }

    .form {
        height: 85px;

        /deep/ .el-row {
            height: 50px;
        }

        /deep/ .el-select {
            width: 100%;
        }

        /deep/ .el-date-editor {
            input.el-input__inner {
                padding: 0 15px;
            }
            .el-input__prefix {
                display: none;
            }
        }

        &:after {
            display: table;
            content: "";
            clear: both;
        }
    }

    .form-item {
        position: relative;
        display: inline-block;
        line-height: 32px;

        .float-right {
            position: absolute;
            top: 2px;
            right: 1px;
            height: 30px;
            padding: 0 7px;
            line-height: 30px;
            background: #ffffff;
        }
    }

    .error-info {
        color: #f56c6c;
        font-size: 12px;
        line-height: 1;
        padding-top: 4px;
        position: absolute;
        top: 100%;
        left: 0;
    }

    .form-btns {
        text-align: center;
    }

    .product-table {
        /deep/ .el-table__body-wrapper {
            font-size: 12px;
        }

        /deep/ .el-table th,
        .el-table td {
            padding: 14px 0;
        }

        /deep/ .el-button {
            font-size: 12px;
        }

        table {
            width: 100%;
            line-height: 23px;
            font-size: 12px;
            td {
                padding: 14px 10px;
                vertical-align: middle;
                word-break: break-word;
            }

            thead {
                font-size: 14px;
                text-align: center;
                white-space: nowrap;
                color: #909399;
                background: #f5f5f5;
            }

            .tbody-row:hover {
                background: #e8f3fd;
            }

            tbody {
                text-align: center;

                tr {
                    &.sign-content {
                        display: none;
                        background: #f0f8ff;

                        &:hover {
                            display: table-row;
                        }

                        td {
                            padding: 0;
                            border-bottom: none;
                        }
                    }

                    &.all-check {
                        text-align: left;

                        &:hover{
                            background: #ffffff;
                        }
                    }
                }

                tr:hover + tr.sign-content {
                    display: table-row;
                }

                td {
                    padding: 38px;
                    border-bottom: 1px solid #ebeef5;
                }
            }
        }

        .product-name {
            display: inline-flex;
            width: 100%;
            vertical-align: top;
            line-height: 20px;

            img {
                width: 75px;
                height: 75px;
            }

            .left {
                margin-right: 10px;
            }

            .right {
                text-align: left;

                p:first-child {
                    margin-bottom: 10px;
                }
                p:last-child {
                    word-break: break-all;
                    max-height: 40px;
                    overflow: hidden;
                    color: #969799;
                }
            }
        }
    }

    .product-empty {
        padding: 150px;
        text-align: center;
        line-height: 50px;
        color: #909399;
    }

    .price-popover {
        display: flex;
        color: #ababac;

        > div:first-child {
            margin-right: 10px;
        }

        p:first-child {
            padding: 0 5px;
            border-left: 3px solid #ffd64e;
            line-height: 15px;
        }

        p:last-child {
            margin-top: 10px;
            color: #ffffff;
        }
    }

    .table-pagination {
        margin: 50px 0 80px;
        text-align: center;
        color: #888888;
    }
</style>
