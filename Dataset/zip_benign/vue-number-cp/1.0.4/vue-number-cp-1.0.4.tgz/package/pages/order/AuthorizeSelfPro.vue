<template>
  <!-- 商品录入与上架商品页 -->
  <div class="authorizeSelfPro">
    <PanelTitle style="margin-bottom: 10px" :title="title"></PanelTitle>
    <div class="list-home">
      <div v-if="pageType ==='0'" class="tr panel-btn">
        <el-button v-if="isDirectSales" class="small-btn" @click="dialogVisible = true">下载商品导入模板</el-button>
        <el-button v-if="isDirectSales" class="small-btn" @click="getInitProduct">商品导入</el-button>
        <el-button v-if="isDirectSales" type="primary" class="small-btn" @click="handleCreateGoods({},'CreateGoods')">创建基础商品</el-button>
        <el-button type="primary" class="small-btn" @click="handleCreateGoods({},'CreateGroupGoods')">创建组价商品</el-button>
      </div>
      <div class="list-content">
        <div class="panel">
          <el-form class="form" size="small" label-width="96px" type="flex" justify="space-between">
            <el-row type="flex" justify="space-between">
              <el-col :span="8">
                <el-form-item label="商品名/型号：">
                  <el-input v-model.trim="skuNameOrModel" placeholder="请输入关键词" maxlength="64" clearable></el-input>
                </el-form-item>
              </el-col>
              <el-col style="width: 660px" v-if="pageType =='0'">
                <MultipleSelectorAll ref="multipleSelectorAll" @getData="getSupplierData" :isSearch="true" :dataList="projectList" :width="660" :selectWidth="1000" :paddingHight="8" :labelWidth="90" :pageSize="pageSizeSelector" :totalCount="projectList.length" :label="'使用项目'" :placeholder="'请搜索选择项目'"></MultipleSelectorAll>
              </el-col>

              <el-col class="two_label" v-if="pageType != '0'">
                <el-form-item label="销量：" label-width="70px">
                  <el-row>
                    <el-col>
                      <el-input v-model.trim="saleVolumeFor" placeholder="请输入销量" maxlength="9" @input="saleVolumeFor=saleVolumeFor.replace(/[^\d.]/g,'')">
                      </el-input>
                    </el-col>
                    <el-col class="tc">-</el-col>
                    <el-col>
                      <el-input v-model.trim="saleVolumeTo" placeholder="请输入销量" maxlength="9" @input="saleVolumeTo=saleVolumeTo.replace(/[^\d.]/g,'')">
                      </el-input>
                    </el-col>
                  </el-row>
                </el-form-item>
              </el-col>
              <el-col class="two_label" v-if="pageType != '0'">
                <el-form-item label="价格：" label-width="70px">
                  <el-row>
                    <el-col>
                      <el-input v-model.trim="priceFor" placeholder="请输入金额" class="right_padding" maxlength="9" @input="priceFor=priceFor.replace(/[^\d.]/g,'')">
                        <div slot="suffix" class="suffix">元</div>
                      </el-input>
                    </el-col>
                    <el-col class="tc">-</el-col>
                    <el-col>
                      <el-input v-model.trim="priceTo" placeholder="请输入金额" class="right_padding" maxlength="9" @input="priceTo=priceTo.replace(/[^\d.]/g,'')">
                        <div slot="suffix" class="suffix">元</div>
                      </el-input>
                    </el-col>
                  </el-row>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row v-if="pageType != '0'">
              <el-col :span="24">
                <MultipleSelectorAll ref="multipleSelectorAll" @getData="getSupplierData" :isSearch="true" :dataList="projectList" :width="1000" :paddingHight="8" :labelWidth="96" :pageSize="pageSizeSelector" :totalCount="projectList.length" :label="'使用项目'" :placeholder="'请输入项目名称搜索'"></MultipleSelectorAll>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8" v-if="!isDirectSales">
                <el-form-item label="代理厂家：">
                  <el-select v-model="supplierId" placeholder="请选择" clearable>
                    <el-option label="全部" value=""></el-option>
                    <el-option v-for="item in licensingCorpList" :key="item.supplierId" :label="item.supplierName" :value="item.supplierId">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col class="two_label">
                <el-form-item label="更新时间：">
                  <el-row>
                    <el-col :span="11">
                      <el-date-picker value-format="yyyy-MM-dd" v-model="skuUpdateStartTime" type="date" placeholder="请选择" @change="handleChangeStartTm">
                      </el-date-picker>
                    </el-col>
                    <el-col :span="2" class="tc">~</el-col>
                    <el-col :span="11">
                      <el-date-picker value-format="yyyy-MM-dd" v-model="skuUpdateEntTime" type="date" placeholder="请选择" :picker-options="pickerOptionsEnd">
                      </el-date-picker>
                    </el-col>
                  </el-row>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24">
                <el-form-item label="商品模式：" class="radio1">
                  <el-radio-group v-model="prodMobel">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'BASE_PROD'">基础商品</el-radio>
                    <!-- <el-radio :label="'2'">固定组价商品</el-radio> -->
                    <el-radio :label="'COM_PROD'">组价商品</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
            <!-- <el-row>
              <el-col :span="24">
                <el-form-item label="状态：" class="radio2">
                  <el-radio-group v-model="prodStatus">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'1'">已创建</el-radio>
                    <el-radio :label="'2'">待审核</el-radio>
                    <el-radio :label="'3'">已下架</el-radio>
                    <el-radio :label="'0'">已审核</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row> -->
          </el-form>
          <el-row>
            <el-col :span="24" align="center">
              <el-button class="small-btn" type="primary" size="small" @click="search()">搜索</el-button>
              <el-button class="small-btn" size="small" @click="clear()">清除</el-button>
            </el-col>
          </el-row>
        </div>
        <el-row v-if="pageType == '0'">
          <el-col :span="10">
            <!-- <el-checkbox v-model="checkboxAll" :disabled="!awredSpuBeans.length || awredSpuBeans.every(i=>(isDirectSales && i.oprFlag !== '1') || (supplieType !=='0' && i.approveStatus !== '0'))" style="margin: 0 10px" @change="checkboxChange">全选</el-checkbox> -->
            <el-checkbox v-model="checkboxAll" :disabled="!awredSpuBeans.length || awredSpuBeans.every(i=> !(i.approveStatus === '0'))" style="margin: 0 10px" @change="checkboxChange">全选(已选{{awredSpuBeans.filter(i=>i.checkbox).length}}款)</el-checkbox>
            <el-button class="small-btn" :disabled="awredSpuBeans.every(i=> !i.checkbox)" size="small" @click="handleBatchSetUseProject">批量设置限定使用项目</el-button>
            <el-button class="small-btn" :disabled="awredSpuBeans.every(i=> !i.checkbox)" size="small" @click="handlebatchDel">批量删除</el-button>
          </el-col>
          <el-col :span="14" v-if="pageType == '0'" class="clearfloat">
            <p class="f12 fr" style="margin-top: 9px;">※下架商品需至<span class="blue">
                <router-link to="/vendorCenter/shelfApplication">【商品管理】-【上架申请】</router-link>
              </span> 发起上架审核，商品审核通过后才能在【上架商品】中查看。</p>
          </el-col>
        </el-row>
        <TableThead :TopDistance="510" width="1020" left="240">
          <tr slot="tr">
            <td :width="pageType == '0' ? '290px' : '250px'" :style="{'padding-left': pageType == '0' ? '100px' : '76px'}">商品名称/型号</td>
            <td width="150px" class="tr">不含税单价(元)</td>
            <td width="150px" class="tr" v-if="pageType != '0'">销量</td>
            <td width="110px">更新时间</td>
            <td width="260px" class="tl">限定使用项目</td>
            <td v-if="pageType == '0'" width="110px">状态</td>
            <td width="100px">操作</td>
          </tr>
        </TableThead>
        <table class="table-default">
          <thead>
            <tr>
              <td :width="pageType == '0' ? '290px' : '250px'" :style="{'padding-left': pageType == '0' ? '100px' : '76px'}">商品名称/型号</td>
              <td width="150px" class="tr">不含税单价(元)</td>
              <td width="150px" class="tr" v-if="pageType != '0'">销量</td>
              <td width="110px">更新时间</td>
              <td width="260px" class="tl">限定使用项目</td>
              <td v-if="pageType == '0'" width="110px">状态</td>
              <td width="100px">操作</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in awredSpuBeans" :key="ind">
            <tr>
              <td class="flex">
                <el-checkbox v-if="pageType == '0'" :disabled="!(item.approveStatus === '0')" v-model="item.checkbox" @change="checkAllSelect"></el-checkbox>
                <div class="skuName">
                  <div class="attachImg" :class="{'active':!item.attUrl}">
                    <img v-if="item.attUrl" :src="item.attUrl" alt="">
                  </div>
                  <div class="model">
                    <p v-if="pageType == '1'" class="f12 ellipsisTwo blue-pointer word-bw" @click="handleGoproduct(item)" :title="item.skuName">{{item.skuName}}</p>
                    <p v-else class="f12 ellipsisTwo word-bw" :title="item.skuName">{{item.skuName}}</p>

                    <p class="f12" style="margin-top: 10px">型号：{{item.model ? item.model : '-'}}</p>

                    <p style="margin-top: 10px" v-if="item.specifications && item.specifications.length < 36">规格：{{item.specifications}}</p>
                    <el-popover popper-class="dark-popover" trigger="hover" placement="top" v-else-if="item.specifications && item.specifications.length >= 36">
                      <div style="color: #fff;width: 500px">
                        规格：{{item.specifications}}
                      </div>
                      <p style="margin-top: 10px" slot="reference" v-if="$isIE()">规格：{{item.specifications.slice(0,36) + "..."}}</p>
                      <p style="margin-top: 10px" slot="reference" v-else class="ellipsisTwo">规格：{{item.specifications}}</p>
                    </el-popover>
                    <p class="tag" v-if="item.isCombination=='1' && item.isNewCom !== '1'">组价商品</p>
                    <div class="tag bg-lightSteelBlue" style="width: 70px" v-if="item.isCombination !== '1' && item.bidSurchangeBeanList && item.bidSurchangeBeanList.length">含附加项</div>
                  </div>
                </div>
              </td>
              <td class="tr">{{item.unitPrice | formatMoney}}</td>
              <td class="tr" v-if="pageType != '0'">{{(item.salesVolume || '0') + (item.goodsUnit || '')}}</td>
              <td>
                <template v-if="item.skuUpdateTime">
                  {{item.skuUpdateTime.substring(0, 10)}}<br>{{item.skuUpdateTime.substring(11, item.skuUpdateTime.length)}}
                </template>
                <template v-else>-</template>
              </td>
              <td class="tl">
                <el-tooltip v-if="item.projectInfos !== '全部' && $isIE()" class="item" effect="dark" placement="bottom-start">
                  <div slot="content" style="overflow-x: hidden;overflow-Y: auto;max-height: 400px;">{{item.projectInfos}}</div>
                  <p class="ellipsisTwo">{{item.projectInfos.length > 44 ? (item.projectInfos.substring(0,44) + '...') : item.projectInfos}}</p>
                </el-tooltip>
                <el-tooltip v-else-if="item.projectInfos !== '全部'" class="item" effect="dark" placement="bottom-start">
                  <div slot="content" style="overflow-x: hidden;overflow-Y: auto;max-height: 400px;">{{item.projectInfos}}</div>
                  <p class="ellipsisTwo">{{item.projectInfos}}</p>
                </el-tooltip>
                <p v-else class="ellipsisTwo">{{item.projectInfos}}</p>
              </td>
              <td v-if="pageType == '0'" :class="{red:item.approveStatus === '3'}">{{item.approveExplain}}</td>
              <td>
                <template v-if="pageType == '0'">
                  <!-- 编辑商品 -->
                  <p v-if="item.approveStatus === '0' && item.approveType === '1'" class="f12 blue hand" @click="handleCreateGoods(item)">编辑</p>
                  <!-- 编辑商品图 -->
                  <p v-if="(isDirectSales || !isDirectSales && item.isExtraFee === '1') && item.approveStatus === '0' && item.approveType === '3'" class="f12 blue hand" @click="handleCreateGoods(item,'img')">编辑</p>

                  <p v-if="item.approveStatus === '0' && item.approveType === '1'" @click="handleDel(item)" class="f12 blue hand">删除</p>
                  <p v-if="(item.approveStatus === '1' || item.approveStatus === '3' || item.approveStatus === '5') && item.applyId" @click="handleApproveDetail(item,'1')" class="f12 blue hand">查看详情</p>
                </template>
                <!-- 厂家，施工，代理商（代理商创建的商品） -->
                <template v-if="pageType == '1' && (isDirectSales || (!isDirectSales && item.isAngent === '1'))">
                  <!-- 有额外费率的商品不能编辑商品图 -->
                  <p @click="handleCreateGoods(item,'img')" class="f12 blue hand">编辑</p>

                  <!-- <p v-if="item.isCombination === '1'" @click="handleDel(item)" class="f12 blue hand">删除</p> -->
                </template>
              </td>
            </tr>
            <!-- <tr v-if="item.approveStatus === '3' || item.approveStatus === '5'" class="error-msg">
              <td :colspan="6" :class="{'fold':!item.foldFlag}">
                <span class="bold fl">{{item.approveType === '1' ? '商品上架' : item.approveType === '2' ? '调价' : '图片'}}审核失败原因：</span>
                <span class="fl">{{item.approveMsg}}</span>
                <span class="fr blue-pointer" @click="item.foldFlag = !item.foldFlag">{{item.foldFlag ? '展开':'收起'}}
                  <i v-if="item.foldFlag" class="el-icon-caret-bottom"></i>
                  <i v-else class="el-icon-caret-top"></i>
                </span>
                <div class="fl" v-if="!item.foldFlag" style="margin-top: 10px;"><em class="grey">审核时间：</em>{{item.approveTime}}</div>
                <div style="clear: both"></div>
              </td>
            </tr> -->
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!awredSpuBeans.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
        </div>
        <div class="table-pagination" v-if="awredSpuBeans.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <!-- 下载商品导入模板 -->
    <el-dialog custom-class="dialog-box" title="下载商品导入模板" :append-to-body="true" :visible.sync="dialogVisible" width="840px" center :close-on-click-modal="false" @close="handleCategoryList">
      <el-form label-width="86px">
        <!-- <el-form-item label="选择品类：" required>
          <el-select v-model="categoryId" filterable placeholder="请搜索或者选择品类">
            <el-option v-for="item in categoryList" :key="item.categoryId" :label="item.fullName.replace(/_/g, '/')" :value="item.categoryId">
            </el-option>
          </el-select>
        </el-form-item> -->
        <el-form-item label="选择品类：" required>
          <el-cascader v-model="categoryId" :key="categoryId[0] || 1" placeholder="选择或输入关键词查找" popper-class="cascader-category" class="cascader-input" :options="categoryList" :props="{value:'categoryId',label:'categoryName'}" @change="handleChangeCate" filterable>
            <template slot-scope="{ node, data }">
              <span v-if="node.isLeaf" class="checked">
                <el-checkbox v-model="data.checked" @change="handleChecked"></el-checkbox>
              </span>
              <p :class="{text:node.isLeaf}">{{ data.categoryName }}</p>
            </template>
          </el-cascader>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" :disabled="!categoryId.length" class="normal-btn" @click="getGoodsTemplate">下载模板</el-button>
        <el-button class="normal-btn" @click="dialogVisible = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 商品导入 -->
    <el-dialog custom-class="dialog-box" title="商品导入" :append-to-body="true" :visible.sync="dialogVisible1" width="840px" center :close-on-click-modal="false" @close="freightTemplateId = '';goodsTemplateFile = {}">
      <p class="f12 bold" style="margin-bottom: 20px">同商品类目的模板不同，导入不同商品类目请分别下载对应模板，以确保导入不会报错。</p>
      <el-form label-width="126px">
        <el-form-item label="运费模板(税前)：" required>
          <el-select v-model="freightTemplateId" placeholder="请选择运费模板" clearable>
            <el-option value="商品价格含运费"></el-option>
            <el-option v-for="(item,index) in freightTemplateList" :key="index+'freightTemplateList'" :label="item.templateName" :value="item.templateId"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item class="upload" style="color: #000;" label="上传文件" label-width="70px" required>
          <DownloadAndUpload class="f12" style="position: absolute;left: 78px; top: 12px;"  :fileTypeReg="/(xlsx|XLSX)/i" fileTypeErrorMsg="请上传xlsx格式文件" :hasDownloadFlg="false" appName="PROD" :fromId="'61'" :uploadType="'61'" @outputValue="getAttachInfo"></DownloadAndUpload>
          <div class="enclosure-content" v-if="goodsTemplateFile.attachPath">
            <div>
              <span>{{goodsTemplateFile.attachName}}</span>
            </div>
          </div>
          <div v-else class="grey enclosure-content">
            未上传文件！
          </div>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" :disabled="!freightTemplateId || !goodsTemplateFile.attachPath" class="normal-btn" @click="uploadGoodsTemplate">导入</el-button>
        <el-button class="normal-btn" @click="dialogVisible1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 批量设置限定使用项目 -->
    <BatchSetUseProject ref="batchSetUseProject" :projectList="projectList" @upDate="getList"></BatchSetUseProject>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import TableThead from "@/components/base/TableThead";
import MultipleSelectorAll from "@/components/base/MultipleSelectorAll";
import BatchSetUseProject from "@/components/order/dialog/BatchSetUseProject";
import DownloadAndUpload from "@/components/base/DownloadAndUpload";
export default {
  components: {
    Loading, PanelTitle, TableThead, MultipleSelectorAll, BatchSetUseProject, DownloadAndUpload
  },
  data() {
    return {
      isLoading: false,
      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码

      title: '',
      pageType: '0',// '0'：商品录入, '1'：上架商品
      supplierId: '',
      licensingCorpList: [],
      supplieType: '0',//供应商性质（"0":厂家;"1":代理商;"2":经销商;"3":施工;"4":监理）
      skuNameOrModel: '',//商品名/型号
      saleVolumeFor: '',//销量开始值
      saleVolumeTo: '',//销量截至值
      priceFor: '',//价格开始值
      priceTo: '',//价格截至值
      prodMobel: '',//商品模式
      projectIds: [],// 限定使用项目
      awredSpuBeans: [],
      checkboxAll: false,
      categoryList: [],
      dialogVisible: false,

      categoryId: [],
      categoryName: '',
      projectList: [],
      pageSizeSelector: 10,
      totalSelector: 40,

      skuUpdateStartTime: '',
      skuUpdateEntTime: '',
      pickerOptionsEnd: {
        disabledDate: time => {
          if (this.skuUpdateStartTime) {
            return time.getTime() <= new Date(this.skuUpdateStartTime).getTime() - 86400000
          }
        }
      },

      freightTemplateId: '',
      dialogVisible1: false,
      freightTemplateList: [],
      goodsTemplateFile: {}
    };
  },
  watch: {
    $route(to, from) {
      this.init()
    }
  },
  computed: {
    isDirectSales() {
      return this.supplieType === '0' || this.supplieType === '3'
    },
    userInfo() {
      return this.$store.state.userInfo || {}
    },

  },
  methods: {
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.getList()
      window.scrollTo(0, 0)
    },

    // 起始时间
    handleChangeStartTm(ev) {
      if (new Date(ev) > new Date(this.skuUpdateEntTime)) {
        this.skuUpdateEntTime = ""
      }
    },

    handleCreateGoods(item, type) {
      if (type === 'CreateGoods') {//基础商品初始页
        window.open(this.$router.resolve({
          path: "/createProductCategs",
        }).href, '_blank')
      } else if (type === 'CreateGroupGoods') {//组价商品
        window.open(this.$router.resolve({
          path: "/createGroupGoods",
        }).href, '_blank')
      } else {
        let query = {
          pageType: '1',
          isEdit: '1',
          spuId: item.spuId,
          skuId: item.skuId,
          supplierId: item.supplierId,
          isAngent: item.isAngent,
          editType: type
        }
        if (this.pageType == '1') {
          query.isShelf = true
        }
        if (item.isCombination == '1') { //组价商品
          window.open(this.$router.resolve({
            path: "/createGroupGoods",
            query: query
          }).href, '_blank')
        } else { //基础商品详情页
          query.fromSource = '编辑基础商品'
          window.open(this.$router.resolve({
            path: "/createProductInfo",
            query: query
          }).href, '_blank')
        }
      }
    },
    // 商品详情
    handleGoproduct(item) {
      if (item.isExtraFee !== '1') {
        window.open(this.$router.resolve({
          path: "/productDetails",
          query: {
            spuId: item.spuId,
            skuId: item.skuId,
            corpId: item.supplierId,
          }
        }).href, '_blank')
      }
    },

    // 上架申请详情
    handleApproveDetail(item, pageType) {
      window.open(this.$router.resolve({
        path: "/productApproveDetail",
        query: {
          applyId: item.applyId,
          pageType: pageType,
        }
      }).href, '_blank')
    },
    // 获取项目列表
    getProjectInfo() {
      const params = {
        isNew: '1'
      }
      InterfaceService.getProjectInfo(
        params,
        data => {
          if (data.respData.respCode == "0000") {
            this.projectList = []
            const list = data.respData.projectBseInfos || []
            list.forEach((i, index) => {
              this.projectList.push(i)
              this.$set(this.projectList[index], 'index', i.index)
              this.$set(this.projectList[index], 'checked', false)
              // this.projectList.push({
              //   label: i.projectName, //projectName
              //   labelTwo: i.groupCompanyName, //groupCompanyName
              //   value: i.projectId, //projectId
              //   index: index,
              //   checked: false,
              // })
            })
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { }, () => { this.isLoading = true }, () => { this.isLoading = false }
      );
    },

    // 获取限定项目
    getSupplierData(val = []) {
      // console.log(val)
      this.projectIds = []
      if (val.length) {
        val.forEach(i => this.projectIds.push(i.projectId))
      }
    },
    checkboxChange() {
      this.awredSpuBeans.forEach(i => {
        if (!(i.approveStatus === '0')) {
          this.$set(i, 'checkbox', false)
        } else {
          this.$set(i, 'checkbox', this.checkboxAll)
        }
      });
    },
    // 是否全选
    checkAllSelect() {
      const list = this.awredSpuBeans.filter(i => i.approveStatus === '0');
      this.checkboxAll = list.every(item => {
        return item.checkbox;
      });
      if (!list.length) {
        this.checkboxAll = false
      }
    },
    // 批量设置限定项目
    handleBatchSetUseProject() {
      const list = this.awredSpuBeans.filter(i => i.checkbox)
      this.$refs.batchSetUseProject.open(list)
    },
    // 商品导入模板下载
    getGoodsTemplate() {
      let param = {
        categoryId: this.categoryId[2]
      };
      InterfaceService.getGoodsTemplate(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          const url = data.respData.attachUrl || ''
          if (url) {
            this.$download([{
              name: this.categoryName + '商品导入模板.xlsx',
              url: url
            }]).then(result => {
              this.$message.success('下载成功')
            }).catch(err => {
              this.$message.error('下载失败')
            })
            this.dialogVisible = false
          } else {
            this.$message.error('模板不存在，请联系平台管理员！')
          }

        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 获取运费模板
    getInitProduct() {
      const params = {
        corpId: this.userInfo.corpId,
        handleType: '6',
      }
      InterfaceService.getInitProduct(params, (data) => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.freightTemplateList = data.respData.freightTemplateList || []
          this.dialogVisible1 = true
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    getAttachInfo(info){
      this.goodsTemplateFile = this.$clone(info)
      console.log(this.goodsTemplateFile)
    },
    //商品导入
    uploadGoodsTemplate() {
      if (this.goodsTemplateFile.attachPath) {
        let param = {
          supplierCorpId: this.userInfo.corpId || '',
          attachUrl: this.goodsTemplateFile.attachPath,
          templateId: this.freightTemplateId === '商品价格含运费' ? '' : this.freightTemplateId
        };
        InterfaceService.uploadGoodsTemplate(param, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.$message.success('商品导入成功')
            this.search()
          } else {
            if (data.respData.attachUrl && data.respData.respCode === "PROD0288") {
              this.$message.error('商品导入失败')
              this.$download([{
                name: data.respData.failFileName,
                url: data.respData.attachUrl
              }]).then(result => {
                this.$message.success('已下载')
              }).catch(err => {
                this.$message.error('下载失败')
              })
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
      } else {
        this.$message.error('商品导入失败')
      }
    },
    handlebatchDel() {
      let list = []
      const a = list.filter(i => i.approveStatus !== '0' || i.approveType !== '1')
      if (a.length) {
        return this.$message.error(`‘‘${a[0].skuName}’’商品不能删除`)
      }
      this.awredSpuBeans.forEach(i => {
        if (i.checkbox) {
          list.push({
            spuId: i.spuId,
            skuId: i.skuId,
            isCombination: i.isCombination,
            approveType: i.approveType,
            approveStatus: i.approveStatus
          })
        }
      })
      let content = `确认删除勾选的${list.length}款商品？删除后，不再恢复`
      this.$confirm(
        content,
        '批量删除',
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确认批量删除",
          cancelButtonText: '取消',
        }).then(() => {
          this.batchDelproduct(list)
        }).catch(() => {
        });
    },
    handleDel(item) {
      this.$confirm(
        '您是否确认要删除该商品？',
        '删除',
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确认删除",
          cancelButtonText: '取消',
        }).then(() => {
          this.batchDelproduct([{
            spuId: item.spuId,
            skuId: item.skuId,
            isCombination: item.isCombination,
            approveType: item.approveType,
            approveStatus: item.approveStatus
          }])
        }).catch(() => {
        });
    },
    // 删除商品
    batchDelproduct(list) {
      let param = {
        supplieType: this.supplieType,
        deleteList: list
      };
      InterfaceService.batchDelproduct(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('删除成功');
          this.search()
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 代理商获取厂家
    getSuperiorSupplierList() {
      const params = {
        corpId: this.userInfo.corpId || ''
      }
      InterfaceService.getSuperiorSupplierList(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.licensingCorpList = data.respData.licensingCorpList || [];
          } else {
            this.$message.error(data.respData.respMsg);
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 获取品类
    getCategoryList() {
      let categoryList = this.$getRootScope('categoryList')
      if (categoryList && categoryList.length) {
        this.categoryList = JSON.parse(categoryList)
        this.handleCategoryList()
      } else {
        const params = { categoryId: "1", queryType: "2", }
        InterfaceService.getCategoryList(
          params,
          data => {
            if (data.respData.respCode === "0000") {
              this.categoryList = data.respData.categoryInfos || []
              this.handleCategoryList()
            } else {
              this.$message.error(data.respData.respMsg);
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
      }

    },
    handleCategoryList() {
      this.categoryId = []
      this.categoryName = ''
      this.categoryList.forEach(i => {
        if (i.children) {
          i.children.forEach(j => {
            if (j.children) {
              j.children.forEach(k => {
                this.$set(k, 'checked', false)
                this.$delete(k, 'children')
              })
            }
          })
        }
      })
    },
    handleChecked(val) {
      if (!val) {
        this.categoryId = []
      }
    },
    handleChangeCate(val) {
      this.categoryList.forEach(i => {
        i.children.forEach(j => {
          j.children.forEach(k => {
            if (k.categoryId == val[2]) {
              this.$set(k, 'checked', true)
              this.categoryName = k.categoryName
            } else {
              this.$set(k, 'checked', false)
            }
          })
        })
      })
    },
    getList(type) {//查询供应商商品列表(pageType:0-上架商品，1-下架商品) --- 查询被授权商品列表(pageType:0-商品库 1-授权商品页面 2-待审核页面)
      let url = this.isDirectSales ? 'getSupplierProductList' : 'getAuthorizeProductList'
      let param = {
        skuNameOrModel: this.skuNameOrModel,//商品名/型号
        saleVolumeFor: this.saleVolumeFor,//销量开始值
        saleVolumeTo: this.saleVolumeTo,//销量截至值
        priceFor: this.priceFor,//价格开始值
        priceTo: this.priceTo,//价格截至值
        prodMobel: this.prodMobel,//商品模式
        pageIndex: this.pageIndex,
        pageType: this.isDirectSales ? (this.pageType == '0' ? '1' : '0') : (this.pageType == '0' ? '2' : '1'),
        skuUpdateStartTime: this.skuUpdateStartTime ? (this.skuUpdateStartTime + ' 00:00:01') : '',
        skuUpdateEntTime: this.skuUpdateEntTime ? (this.skuUpdateEntTime + ' 23:59:59') : '',
      }
      if (type !== 'init') {
        if (this.projectIds.length !== this.projectList.length) {
          param.projectIds = this.projectIds
        } else {
          param.isUsedAll = '1'
        }
      }
      if (this.isDirectSales) {
        param.supplierId = this.userInfo.corpId || ''
      } else {
        param.supplierId = this.supplierId
        // param.prodStatus = this.prodStatus
      }

      InterfaceService[url](param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.awredSpuBeans = data.respData.awredSpuBeans || []
          this.awredSpuBeans.forEach(i => {
            this.$set(i, 'checkbox', false)
            this.$set(i, 'foldFlag', true)
            // if (!(i.approveType === '1' && (i.approveStatus === '3' || i.approveStatus === '0'))) {
            //   i.oprFlag = '0'
            // }
          });
          this.checkboxAll = false
          this.total = data.respData.totalCount
          this.pageSize = data.respData.pageSize
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    search() {
      this.pageIndex = 1
      this.getList()
    },
    clear(type) {
      this.skuNameOrModel = ''//商品名/型号
      this.saleVolumeFor = ''//销量开始值
      this.saleVolumeTo = ''//销量截至值
      this.priceFor = ''//价格开始值
      this.priceTo = ''//价格截至值
      this.prodMobel = ''//商品模式
      // this.prodStatus = ''//商品状态
      this.supplierId = ''//
      this.pageIndex = 1
      this.projectIds = []
      this.$refs.multipleSelectorAll.clear()
      this.skuUpdateStartTime = ''
      this.skuUpdateEntTime = ''
      this.getList(type)
    },
    init() {
      this.supplieType = this.$store.state.userInfo.supplyType;
      this.pageType = this.$route.query.pageType // '0'：商品录入, '1'：上架商品
      if (this.pageType == '0') {
        this.title = '非绿地建材集团商品库'
      } else {
        this.title = '上架商品'
      }
      this.clear('init')
      if (!this.isDirectSales) this.getSuperiorSupplierList()
      this.getProjectInfo()
      this.getCategoryList()
    },
  },
  mounted() {
    this.init()
  },
};
</script>
<style lang="scss">
// 兼容Ie10
.cascader-category {
  .el-cascader-node__label {
    height: 34px !important;
    display: inline-block;
    vertical-align: middle;
  }
}
</style>
<style lang="scss" scoped>
/deep/ .cascader-input {
  width: 100% !important;
}
.el-row {
  overflow: inherit;
}
/deep/ .el-date-editor.el-input,
.el-select,
.el-date-editor.el-input__inner {
  width: 100%;
}
/deep/ .right_padding {
  .el-input__inner {
    padding-right: 28px;
  }
  .suffix {
    color: #444;
    margin-right: 4px;
  }
}
/deep/ .two_label {
  &.el-col-24 {
    width: inherit;
    width: initial;
  }
  .el-col {
    width: 120px;
    &:nth-child(2) {
      width: 20px;
    }
  }
  .el-input--small .el-input__inner {
    padding: 0 15px;
  }
  .el-input__prefix {
    display: none;
  }
}
/deep/ .radio1 {
  .el-form-item__label {
    width: 76px !important;
  }
  .el-form-item__content {
    margin-left: 76px !important;
  }
}
/deep/ .radio2 {
  .el-form-item__label {
    width: 50px !important;
  }
  .el-form-item__content {
    margin-left: 50px !important;
  }
}
.upload{
  /deep/ .el-form-item__content{
    margin-left: 0px !important;
  }
}
.enclosure-content {
  font-size: 12px;
  margin-top: 40px;
  width: 100%;
  border: 1px solid rgba(221, 221, 221, 1);
  padding: 0 10px;
  line-height: 17px;
  padding: 14px 10px;
  > div {
    margin-top: 14px;
    &:first-child {
      margin-top: 0px !important;
    }
  }
}
.authorizeSelfPro {
  /*width: 950px;*/
  margin: 0 auto;
  padding-bottom: 60px;
  .box_type {
    width: 100%;
    //   height: 42px;
    background: rgba(255, 252, 240, 1);
    border: 1px solid rgba(250, 226, 165, 1);
    font-size: 12px;
    line-height: 17px;
    color: #444444;
    padding: 11px 10px;
  }
  .panel-btn {
    .el-button + .el-button {
      margin-left: 10px !important;
    }
  }
  .list-content {
    .panel {
      background-color: #fff;
      background: rgba(249, 249, 249, 1);
      padding: 20px 10px;
      margin: 10px 0 20px;
    }

    .table-default {
      // table-layout: auto;
      margin-top: 10px;
      td {
        line-height: 17px;
        &.flex {
          display: flex;
          align-items: center;
        }
        .skuName {
          display: flex;
          width: 100%;
          .attachImg {
            width: 60px;
            height: 60px;
            min-width: 60px;
            position: relative;
            overflow: hidden;
            &.active {
              background-color: #eee;
            }
            > img {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              pointer-events: none;
              height: auto;
            }
          }
          .model {
            width: calc(100% - 66px);
            margin-left: 6px;
          }
        }
      }
      // .error-msg {
      //   line-height: 30px;
      //   td {
      //     padding: 0 10px;
      //     background: #ffe9eb;
      //     border: 1px solid #db7575;
      //     height: 30px;
      //     span {
      //       &:nth-of-type(2) {
      //         width: 815px;
      //         overflow: hidden;
      //         text-overflow: ellipsis;
      //         white-space: nowrap;
      //         text-align: left;
      //       }
      //       &:last-child {
      //         width: 40px;
      //       }
      //     }
      //   }
      //   .fold {
      //     line-height: 17px;
      //     padding: 6px 10px;
      //     height: auto;
      //     span {
      //       &:nth-of-type(2) {
      //         width: 815px;
      //         /*overflow: hidden;*/
      //         text-overflow: ellipsis;
      //         white-space: normal;
      //       }
      //     }
      //   }
      // }
    }
  }
}
</style>
