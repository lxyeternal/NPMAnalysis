<template>
  <!-- 待审核列表页 -->
  <div class="goodsAuditList">
    <PanelTitle style="margin-bottom: 10px" :tabs="tabs" @select="handleChangeTab"></PanelTitle>
    <div class="list-home">
      <div class="list-content">
        <div class="panel">
          <el-form class="form" size="small" label-width="90px" type="flex" justify="space-between">
            <el-row style="overflow: initial;overflow: inherit">
              <el-col>
                <el-form-item>
                  <span slot="label">品类：</span>
                  <DropdownTree ref="dropdownTree" @categoryInfo="getCategoryInfo" :width="'910px'" :bodyWidth="'808px'"></DropdownTree>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="申请编号：">
                  <el-input v-model.trim="applyId" placeholder="请输入申请编号搜索" maxlength="64" clearable></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="供应商：">
                  <el-input v-model.trim="corpName" placeholder="请输入供应商名称搜索" maxlength="64" clearable></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="创建时间：">
                  <el-row class="two_label">
                    <el-col :span="11">
                      <el-date-picker value-format="yyyy-MM-dd" v-model="createTimeFrom" type="date" placeholder="请选择" @change="handleChangeStartTm">
                      </el-date-picker>
                    </el-col>
                    <el-col :span="2" class="tc">~</el-col>
                    <el-col :span="11">
                      <el-date-picker value-format="yyyy-MM-dd" v-model="createTimeTo" type="date" placeholder="请选择" :picker-options="pickerOptionsEnd">
                      </el-date-picker>
                    </el-col>
                  </el-row>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="招标经办人：">
                  <el-select v-model="bidAcctName" placeholder="请选择" clearable>
                    <el-option v-for="item in acctList" :key="item.acctId" :label="item.acctName" :value="item.acctName">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
          <el-row>
            <el-col :span="24" align="center">
              <el-button class="small-btn" type="primary" size="small" @click="search()">搜索</el-button>
              <el-button class="small-btn" size="small" @click="clear()">清除</el-button>
            </el-col>
          </el-row>
        </div>
        <TableThead :TopDistance="460" width="1020" left="240">
          <tr slot="tr">
            <td width="210px">申请编号</td>
            <td width="200px">供应商</td>
            <td>中标品类</td>
            <td width="110px">创建时间</td>
            <td v-if="showPage === '3'" width="90px">审核人</td>
            <td :width="showPage === '3' ? '90px' : '160px'">状态</td>
            <td width="60px">操作</td>
          </tr>
        </TableThead>
        <table class="table-default">
          <thead>
            <tr>
              <td width="210px">申请编号</td>
              <td width="200px">供应商</td>
              <td>中标品类</td>
              <td width="110px">创建时间</td>
              <td v-if="showPage === '3'" width="90px">审核人</td>
              <td :width="showPage === '3' ? '90px' : '160px'">状态</td>
              <td width="60px">操作</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in productList" :key="ind">
            <tr>
              <td>{{item.applyId}}</td>
              <td>{{item.applyCorpName}}</td>
              <td>
                <el-tooltip class="item" effect="dark" placement="bottom-start">
                  <div slot="content" style="overflow-x: hidden;overflow-Y: auto;max-height: 400px;">{{item.categoryNames}}</div>
                  <p class="ellipsisTwo">{{item.categoryNames}}</p>
                </el-tooltip>
              </td>
              <td>
                <p>{{item.applyCreateTime && item.applyCreateTime.substring(0,10)}}</p>
                <p>{{item.applyCreateTime && item.applyCreateTime.substring(11,19)}}</p>
              </td>
              <td v-if="showPage === '3'">{{item.applyAcctName}}</td>
              <td>{{item.applyExplain}}</td>
              <td>
                <p v-if="showPage === '1'"><span class="blue-pointer" @click="handleApproveDetail(item,'0',true)">审核</span></p>
                <p v-else><span class="blue-pointer" @click="handleApproveDetail(item,'0')">详情</span></p>
              </td>
            </tr>
            <tr v-if="item.applyStatus === '3' || item.applyStatus === '5'" class="error-msg">
              <td :colspan="6" :class="{'fold':!item.foldFlag}">
                <span class="bold fl">审核失败原因：</span>
                <span class="fl">{{item.applyMsg}}</span>
                <span class="fr blue-pointer" @click="item.foldFlag = !item.foldFlag">{{item.foldFlag ? '展开':'收起'}}
                  <i v-if="item.foldFlag" class="el-icon-caret-bottom"></i>
                  <i v-else class="el-icon-caret-top"></i>
                </span>
                <div class="fl" v-if="!item.foldFlag" style="margin-top: 10px;"><em class="grey">审核时间：</em>{{item.applyTime}}</div>
                <div style="clear: both"></div>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="noData" v-if="!productList.length">
          <p class="f14 grey">暂无信息，请重新修改搜索条件搜索！</p>
        </div>
        <div class="table-pagination" v-if="productList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import TableThead from "@/components/base/TableThead";
import DropdownTree from "@/components/order/dropdownTreeTender";

export default {
  components: {
    Loading, PanelTitle, TableThead, DropdownTree
  },
  data() {
    return {
      isLoading: false,
      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码

      showPage: '1',
      applyId: '',
      corpName: '',
      bidAcctName: '',
      productList: [],
      acctList: [],
      tabs: [
        { label: "待处理", showPage: '1', active: true },
        { label: "进行中", showPage: '2' },
        { label: "已结束", showPage: '3' },
      ],
      createTimeFrom: '',
      createTimeTo: '',
      pickerOptionsEnd: {
        disabledDate: time => {
          if (this.createTimeFrom) {
            return time.getTime() <= new Date(this.createTimeFrom).getTime() - 86400000
          }
        }
      },
      categoryIds: '',
    };
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo || {}
    },
  },
  methods: {
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.pendingList()
      window.scrollTo(0, 0)
    },
    // 上架申请详情
    handleApproveDetail(item, pageType, isApprove = false) {
      this.$setRootScope('categoryNames', JSON.stringify(item.categoryNames))
      window.open(this.$router.resolve({
        path: "/productApproveDetail",
        query: {
          applyId: item.applyId,
          pageType: pageType,
          isApprove: isApprove,
          applyStatus: item.applyStatus,
          approveName: item.approveName,
        }
      }).href, '_blank')
    },
    handleChangeTab(tab) {
      this.showPage = tab.showPage
      this.clear()
    },
    // 起始时间
    handleChangeStartTm(ev) {
      if (new Date(ev) > new Date(this.createTimeTo)) {
        this.createTimeTo = ""
      }
    },
    // 获取招标品类
    getCategoryInfo(info) {
      console.log(info)
      let categoryIds = []
      info.forEach(f => {
        // 入参处理
        categoryIds.push(f.categoryId)
      })
      this.categoryIds = categoryIds.join(',')
    },
    // 待审核列表查询
    pendingList() {
      let param = {
        categoryIds: this.categoryIds,
        applyId: this.applyId,
        corpName: this.corpName,
        createTimeFrom: this.createTimeFrom ? (this.createTimeFrom + ' 00:00:01') : '',
        createTimeTo: this.createTimeTo ? (this.createTimeTo + ' 23:59:59') : '',
        bidAcctName: this.bidAcctName,
        pageIndex: this.pageIndex,
        showPage: this.showPage,
      }
      InterfaceService.pendingList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.productList = data.respData.commodityApplyBeanList || []
          this.productList.forEach(i => { this.$set(i, 'foldFlag', true) })
          this.total = data.respData.totalCount
          this.pageSize = data.respData.pageSize
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    search() {
      this.pageIndex = 1
      this.pendingList()
    },
    // 查询公司下属账户信息
    getSubordinateData() {
      return new Promise((resolve, reject) => {
        InterfaceService.getQuerySubordinate({}, (data) => {
          if (data.respCode === "0000") {
            //console.log(data)
            let list = data.respData.acctList || [];
            this.acctList = [];
            list.forEach(item => {
              if (item.acctStatus == '0' && item.roleIds && item.roleIds.some(i => { return i.roleId === '1001' })) {
                this.acctList.push(item)
              }
            });
            this.acctList.forEach(item => {
              if (item.acctId === this.userInfo.acctId) {
                this.bidAcctName = this.userInfo.acctName || "";
              }
            });
            resolve(this.acctList);
          } else {
            this.$message.error(data.respMsg);
            reject(data.respData.respMsg || [])
          }
        },
          data => { },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          });
      })
    },
    clear() {
      this.categoryIds = ''
      this.$refs.dropdownTree.clear()
      this.applyId = ''
      this.corpName = ''
      this.createTimeFrom = ''
      this.createTimeTo = ''
      // this.bidAcctName = this.userInfo.acctName

      this.pageIndex = 1
      this.pendingList()
    },
    async init() {
      await this.getSubordinateData();
      this.pendingList()
    },
  },
  mounted() {
    this.$removeRootScope('categoryNames')
    this.init()
  },
  destroyed() {
  }
};
</script>

<style lang="scss" scoped>
/deep/.two_label {
  .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
  .el-input--small .el-input__inner {
    padding: 0 10px;
  }
  .el-input__prefix {
    display: none;
  }
}
/deep/ .seatchW-width {
  width: inherit;
  width: initial;
  .el-form-item__content {
    width: 240px !important;
  }
  &:nth-child(2) {
    .el-form-item__label {
      width: 130px !important;
    }
    .el-form-item__content {
      margin-left: 130px !important;
    }
  }
}
/deep/ .panel {
  .el-select {
    width: 100% !important;
  }
}
.goodsAuditList {
  /*width: 950px;*/
  margin: 0 auto;
  padding-bottom: 60px;
  .box_type {
    width: 100%;
    //   height: 42px;
    background: rgba(255, 252, 240, 1);
    border: 1px solid rgba(250, 226, 165, 1);
    font-size: 12px;
    line-height: 17px;
    color: #444444;
    padding: 11px 10px;
    margin: -10px 0;
  }
  .list-content {
    .panel {
      background-color: #fff;
      background: rgba(249, 249, 249, 1);
      padding: 20px 10px;
      margin: 10px 0 30px;
    }
    .table-default {
      table-layout: inherit;
      td {
        .spuName {
          display: flex;
          .attachImg {
            width: 60px;
            height: 60px;
            min-width: 60px;
            position: relative;
            overflow: hidden;
            &.active {
              background-color: #eee;
            }
            > img {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              pointer-events: none;
              height: auto;
            }
          }
          .model {
            margin-left: 6px;
          }
        }
      }
      .error-msg {
        line-height: 30px;
        td {
          padding: 0 10px;
          background: #ffe9eb;
          border: 1px solid #db7575;
          height: 30px;
          span {
            &:nth-of-type(2) {
              width: 815px;
              overflow: hidden;
              text-overflow: ellipsis;
              white-space: nowrap;
              text-align: left;
            }
            &:last-child {
              width: 40px;
            }
          }
        }
        .fold {
          line-height: 17px;
          padding: 6px 10px;
          height: auto;
          span {
            &:nth-of-type(2) {
              width: 815px;
              /*overflow: hidden;*/
              text-overflow: ellipsis;
              white-space: normal;
            }
          }
        }
      }
    }
    .noData {
      padding-top: 100px;
      > p {
        text-align: center;
        margin-bottom: 8px;
      }
    }
  }
}
</style>
