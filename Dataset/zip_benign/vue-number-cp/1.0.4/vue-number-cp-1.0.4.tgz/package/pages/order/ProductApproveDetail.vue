<template>
  <!-- 商品上架申请详情接口 与 商品上架申请商品详情接口 -->
  <div class="productApproveDetail">
    <Header :is-white-bg="true"></Header>
    <SearchBar :search-type="5" :progress="pageType==='0'? '审核详情' : '申请详情'" :is-border-bottom="true"></SearchBar>
    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <div class="steps-cont">
        <Steps :tenderList="tenderList" :active="activeNode" :space="396"></Steps>
      </div>
      <!-- 意见 -->
      <!-- <TransferOpinions v-if="pageType==='0' && oAOperFlow.length" :execFlowList="oAOperFlow" :isOA="true" :yellowText="'采购商流转意见'"></TransferOpinions> -->
      <TransferOpinions v-if="pageType==='0' && orderOperFlow.length" :execFlowList="orderOperFlow" :isOA="false"></TransferOpinions>
      <PanelTitle title="申请清单"></PanelTitle>
      <div class="top-box">
        <p><span>申请编号：</span><span v-if="commodityApplyDataBean.applyId">{{commodityApplyDataBean.applyId}}</span></p>
        <p><span>项目联系人：</span><span v-if="commodityApplyDataBean.projectContact" v-html="commodityApplyDataBean.projectContact.replace(/\n/g, '<br/>')"></span></p>
      </div>
      <div class="panel">
        <el-form class="form" size="small" label-width="96px" type="flex" justify="space-between">
          <el-row type="flex" justify="space-between" style="overflow: inherit;">
            <el-col :span="8">
              <el-form-item label="商品名/型号：">
                <el-input v-model.trim="skuNameOrModel" placeholder="请输入关键词" maxlength="64" clearable></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="16" style="overflow: inherit;">
              <MultipleSelectorAll ref="multipleSelectorAll" @getData="getSupplierData" :isSearch="true" :dataList="projectList" :selectWidth="780" :width="780" :paddingHight="8" :labelWidth="130" :pageSize="10" :totalCount="projectList.length" :label="'限定使用项目'" :placeholder="'请输入项目名称搜索，可多选'"></MultipleSelectorAll>
            </el-col>
          </el-row>
        </el-form>
        <el-row>
          <el-col :span="24" align="center">
            <el-button class="small-btn" type="primary" size="small" @click="search()">搜索</el-button>
            <el-button class="small-btn" size="small" @click="clear()">清除</el-button>
          </el-col>
        </el-row>
      </div>
      <div class="content">
        <TableThead :TopDistance="620">
          <tr slot="tr">
            <td width="90px" class="checkbox">序号</td>
            <td style="padding-left: 81px" width="306px">商品名称/型号</td>
            <td width="150px" class="tr">不含税单价(元)</td>
            <td style="padding-left: 50px">参数</td>
            <td width="180px" style="padding-left: 20px" class="tl">限定使用项目</td>
          </tr>
        </TableThead>
        <table class="table-default">
          <thead>
            <tr>
              <td width="90px" class="checkbox">序号</td>
              <td style="padding-left: 81px" width="306px">商品名称/型号</td>
              <td width="150px" class="tr">不含税单价(元)</td>
              <td style="padding-left: 50px">参数</td>
              <td width="180px" style="padding-left: 20px" class="tl">限定使用项目</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in goodsList" :key="ind">
            <tr>
              <td style="padding-left: 34px;">
                <!--<img class="new_ico" src="@/assets/images/icon/new_ico.png" alt="">-->
                {{(ind+1)+pageSize*(pageIndex-1)}}
              </td>
              <td style="display: flex;align-items: center;">
                <div class="skuName">
                  <div class="attachImg" :class="{'active':!item.spuAttachUrl}">
                    <img v-if="item.spuAttachUrl" :src="item.spuAttachUrl" alt="">
                  </div>
                  <div class="model">
                    <p class="f12 ellipsisTwo hover-underline hand" :title="item.spuName" @click="handleProductDetails(item)">{{item.spuName}}</p>
                    <p class="f12" style="margin-top: 10px">型号：{{item.spuModel || '-'}}</p>
                    <div class="tag" v-if="item.isNewProdflag != '1' && item.spuTagModel == '组价商品'" style="width: 70px">组价商品</div>
                    <p class="tag bg-lightSteelBlue" v-if="item.isSurFlag == '1'">含附加项</p>
                  </div>
                </div>
              </td>
              <td class="tr">
                <p v-if="item.oldSpuPrice && item.oldSpuPrice != item.spuPrice" style="text-decoration: line-through">{{item.oldSpuPrice | formatMoney}}</p>
                <p :class="{'red': item.oldSpuPrice && item.oldSpuPrice != item.spuPrice}">{{item.spuPrice | formatMoney}}</p>
                <span class="grey f12" v-if="item.isSurFlag == '1'">(含附加项费)</span>
              </td>
              <td style="padding-left: 50px">
                <p v-if="item.attrParams">{{item.attrParams}}</p>
                <p v-else-if="item.commodityCompareAttrBean">
                  <span v-for="(a,index) in (item.commodityCompareAttrBean.commodityAttrBeanList || [])" :key="index+'commodityCompareAttrBean'">
                    <span :class="{'red': a.oldAttrValue}">
                      {{a.attrName}}：<span v-if="a.oldAttrValue" style="text-decoration: line-through;color:#444 !important">{{a.oldAttrValue}}</span><span>{{a.attrValue}}</span>{{a.unit}}{{(index+1) === item.commodityCompareAttrBean.commodityAttrBeanList.length && !item.commodityCompareAttrBean.addAttrs ? '' : '；'}}
                    </span>
                  </span>
                  <span v-if="item.commodityCompareAttrBean.addAttrs" class="red">{{item.commodityCompareAttrBean.addAttrs}}</span>
                  <span v-if="item.commodityCompareAttrBean.lessAttrs" style="text-decoration: line-through">{{item.commodityCompareAttrBean.lessAttrs}}</span>
                </p>
                <p v-else-if="item.specifications">规格：{{item.specifications}}</p>
                <p v-else>-</p>
              </td>
              <td class="tl">
                <!-- <p v-if="item.pdProdProjectInfos" class="ellipsisTwo" :title="item.pdProdProjectInfos">
                  {{item.pdProdProjectInfos}}
                </p> -->
                <el-tooltip v-if="item.pdProdProjectInfos !== '全部' && $isIE()" class="item" effect="dark" placement="bottom-start">
                  <div slot="content" style="overflow-x: hidden;overflow-Y: auto;max-height: 400px;">{{item.pdProdProjectInfos}}</div>
                  <p class="ellipsisTwo">{{item.pdProdProjectInfos.length > 44 ? (item.pdProdProjectInfos.substring(0,44) + '...') : item.pdProdProjectInfos}}</p>
                </el-tooltip>
                <el-tooltip v-else-if="item.pdProdProjectInfos !== '全部'" class="item" effect="dark" placement="bottom-start">
                  <div slot="content" style="overflow-x: hidden;overflow-Y: auto;max-height: 400px;">{{item.pdProdProjectInfos}}</div>
                  <p class="ellipsisTwo">{{item.pdProdProjectInfos}}</p>
                </el-tooltip>
                <p v-else class="ellipsisTwo">{{item.pdProdProjectInfos}}</p>
              </td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!goodsList.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
        </div>
        <div class="table-pagination" v-if="goodsList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <!-- 直接入库 -->
    <el-dialog custom-class="dialog-box" title="确认直接入库" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible1" width="840px" center :close-on-click-modal="false">
      <p class="f12 bold tc">是否确认该商品审核申请单的商品无需OA审批，直接中标入库？点击【确认入库】按钮，商品直接入库不可撤销。</p>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" @click="postProOAapprove('1')">确认入库</el-button>
        <el-button class="normal-btn" @click="dialogVisible1 = false; dialogVisible3 = true">提交OA审核</el-button>
        <el-button class="normal-btn" @click="dialogVisible1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 退回原因 -->
    <el-dialog custom-class="dialog-box pr50" title="退回原因" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible2" width="840px" center :close-on-click-modal="false" @close="applyMsg=''">
      <el-form label-width="86px">
        <el-form-item label="退回原因：" required>
          <el-input type="textarea" class="resize-none" v-model="applyMsg" rows="4" maxlength="200" show-word-limit placeholder="请输入..."></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" :disabled="!applyMsg" class="normal-btn" @click="approveReturn">批量退回</el-button>
        <el-button class="normal-btn" @click="dialogVisible2 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--  提交OA审核 -->
    <el-dialog custom-class="dialog-box pr50" title="提交OA审核" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible3" width="840px" center :close-on-click-modal="false" @close="approveMsg=''">
      <p class="f12 tc" style="margin-bottom: 20px">确认提交OA审批吗？确认请点击【确认提交】。</p>
      <el-form label-width="86px">
        <el-form-item label="审核意见：">
          <el-input type="textarea" class="resize-none" v-model="approveMsg" rows="4" maxlength="200" show-word-limit placeholder="请输入..."></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" @click="accountInfo">确认提交</el-button>
        <el-button class="normal-btn" @click="dialogVisible3 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 底部按钮 -->
    <FixBottom class="bottom" v-if="isApprove">
      <div class="tc">
        <el-button type="primary" @click="dialogVisible3 = true">提交OA审核</el-button>
        <el-button type="primary" @click="dialogVisible1 = true">直接入库</el-button>
        <el-button @click="dialogVisible2 = true">退回</el-button>
      </div>
    </FixBottom>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import Header from "@/components/base/Header";
import Breadcrumb from "@/components/base/Breadcrumb";
import FixBottom from "@/components/base/FixBottom";
import Steps from "@/components/base/steps";
import TableThead from "@/components/base/TableThead";
import TransferOpinions from '@/components/order/TransferOpinions'
import PanelTitle from "@/components/base/PanelTitle";
import MultipleSelectorAll from "@/components/base/MultipleSelectorAll";

export default {
  components: {
    SearchBar,
    Loading,
    Header,
    FixBottom,
    Steps,
    TableThead,
    TransferOpinions,
    PanelTitle,
    MultipleSelectorAll,
    Breadcrumb
  },
  data() {
    return {
      isLoading: false,
      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码
      breadcrumb: [],

      pageType: '0',//0: 材料公司上架审核， 1：供应商申请详情
      applyId: '',
      activeNode: -1,
      tenderList: [],
      oAOperFlow: [],
      orderOperFlow: [],
      commodityApplyDataBean: {},
      goodsList: [],
      dialogVisible1: false,
      dialogVisible2: false,
      dialogVisible3: false,
      approveMsg: '',
      applyMsg: '',
      projectIds: [],
      breadcrumb: [],
      projectList: [],
      isApprove: false,
      approveName: '',
      applyStatus: '',
      skuNameOrModel: '',
      categoryNames: '',
    };
  },
  mounted() {
    this.init()
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo || {}
    },
  },
  methods: {
    handleProductDetails(item) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: item.spuId,
          skuId: item.skuId,
          corpId: item.corpId
        }
      }).href, '_blank')
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      window.scrollTo(0, 0)
      this.shelfApplicationDelList()
    },
    search() {
      this.pageIndex = 1
      this.shelfApplicationDelList()
    },
    clear() {
      this.skuNameOrModel = ''//商品名/型号
      this.projectIds = []
      this.$refs.multipleSelectorAll.clear()
      this.search()
    },
    // 获取项目列表
    getProjectInfo() {
      const params = {
        isNew: '1'
      }
      InterfaceService.getProjectInfo(
        params,
        data => {
          if (data.respData.respCode == "0000") {
            this.projectList = []
            const list = data.respData.projectBseInfos || []
            list.forEach((i, index) => {
              this.projectList.push(i)
              this.$set(this.projectList[index], 'index', i.index)
              this.$set(this.projectList[index], 'checked', false)
            })
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { }, () => { this.isLoading = true }, () => { this.isLoading = false }
      );
    },

    // 获取限定项目
    getSupplierData(val = []) {
      this.projectIds = []
      if (val.length) {
        val.forEach(i => this.projectIds.push(i.projectId))
      }
      // console.log(this.projectIds)
    },
    // 流转意见与退回原因，节点
    getShelfApplicatDetail() {
      let param = {
        applyId: this.applyId,
      }
      InterfaceService.getShelfApplicatDetail(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.commodityApplyDataBean = data.respData.commodityApplyDataBean || {}
          const list = this.commodityApplyDataBean.commodityFlowInfoList || []
          this.oAOperFlow = []
          this.orderOperFlow = []
          this.tenderList = []
          // "0":初始值，"1":供应商提交审核，"2":材料公司审核通过，提交oa审核中，"3":材料公司审核驳回，"4":oa审核通过，"5":oa审核驳回，"6":供应商已关闭
          list.forEach(i => {
            if (['1', '2', '4'].includes(i.applyStatus)) {
              this.oAOperFlow.push({
                // operTypeDisp: i.applyExplain,
                time: i.applyTime,
                department: '部门',
                name: i.applyAcctName,
                comment: i.applyExplain,
              })
            }
            if (['3', '5'].includes(i.applyStatus)) {
              this.orderOperFlow.push({
                // operTypeDisp: i.applyExplain,
                time: i.applyTime,
                department: '项目公司',
                name: i.applyAcctName,
                comment: i.applyMsg,
              })
            }
          })
          const nodePlanList = data.respData.nodePlanList || []
          nodePlanList.forEach((i, index) => {
            this.tenderList.push({
              top_info: i.nodeTime && i.nodeTime.substring(0, 10),
              top_end_info: i.nodeTime && i.nodeTime.substring(11, 19),
              foot_title: i.nodeName,
            })
            // 去没有时间的第一个为当前节点
            if (!i.nodeTime && this.activeNode === -1) {
              this.activeNode = index
              if (list.length && list[0].applyStatus === '3') {
                this.activeNode = 1
                this.$set(this.tenderList[1], 'top_info', '')
                this.$set(this.tenderList[1], 'top_end_info', '')
              }
            }
          });
          if (this.activeNode === -1) this.activeNode = 2.5
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 商品上架申请商品详情接口
    shelfApplicationDelList(type) {
      let param = {
        applyId: this.applyId,
        pageIndex: this.pageIndex,
        skuNameOrModel: this.skuNameOrModel
      }
      if (type !== 'init') {
        if (this.projectIds.length !== this.projectList.length) {
          param.projectIds = this.projectIds
        } else {
          param.isUsedAll = '1'
        }
      }
      if (this.applyStatus == '6' || this.applyStatus == '4') {
        param.queryStatus = this.applyStatus
      }
      InterfaceService.shelfApplicationDelList(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.goodsList = data.respData.applyProductBeanList || []
          this.total = data.respData.totalCount
          this.pageSize = data.respData.pageSize;
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })

    },
    // handleSubmitOa() {
    //   this.$confirm(
    //     "确认提交OA审批吗？确认请点击【确认提交】。",
    //     "提交OA审核",
    //     {
    //       cancelButtonClass: "btn-custom-cancel",
    //       confirmButtonClass: "btn-custom-confirm",
    //       center: true,
    //       dangerouslyUseHTMLString: true,
    //       confirmButtonText: "确认提交",
    //       cancelButtonText: '取消',
    //     }).then(() => {
    //       this.accountInfo()
    //     }).catch(() => {
    //     });
    // },
    accountInfo() {
      let param = {
        'acctId': this.userInfo.acctId
      }
      InterfaceService.accountInfo(param, (data) => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.submitOaApprove(data.respData)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      })
    },
    // 040001 获取资料信息
    // 提交oa审批
    submitOaApprove(obj = {}) {
      if (!obj.oaAapplicantId) {
        this.$confirm(
          '您还没有绑定集团OA账号，请先去绑定！',
          this.rejectBtn,
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            dangerouslyUseHTMLString: true,
            confirmButtonText: '去绑定',
            cancelButtonText: '取消',
          }).then(() => {
            this.$router.push({ path: '/purchaserCenter/accountInfo' })
          }).catch(() => {
          });
        return
      }
      let param = {
        approveId: this.commodityApplyDataBean.approveId || '',
        approveName: this.approveName || '', // 审批名称
        approveAcctName: this.userInfo.acctName || '',
        approveType: '9',
        // approveAttachInfos: approveAttachInfos,
        approveNo: this.commodityApplyDataBean.applyId,
        applyCorpName: this.commodityApplyDataBean.applyCorpName,
        categoryNames: this.categoryNames,
        // approveBill: '',//	申请单号				
        approveCreateId: obj.oaAapplicantId || '',
        approveDivisionId: obj.oaCompanyId || '',//	申请事业部ID				
        approveDivisionName: obj.oaCompanyName || '',//	申请事业部名称				
        approveDepartmentId: obj.oaDepartmentid || '',//	申请部门ID				
        approveDepartmentName: obj.oaDepartmentName || '',//	申请部门名称				
        approveUrgency: '0',//	紧急程度			
        approveMobile: obj.oaAapplicantMobile || '',//	申请人手机		
        // approveCompanyId: obj.companyId || '',//	申请公司ID				
        approveCompanyId: obj.oaCompanyId || '',//	申请公司ID				
        approveCompanyName: obj.companyName || '',//	申请公司名称				
        approveMsg: this.approveMsg.trim() || '',//	提交审核意见				
        // approveCreatetime: '',//	审批提交时间				
        // djcUrl: 'https://www.dajiacai.net',//	大家采网址				
        handleType: this.applyStatus == '5' ? '2' : '1',//	操作类型 0-保存，1-提交， 2-重新提交				
      }
      InterfaceService.submitOaApprove(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          const approveId = data.respData.approveId
          this.postProOAapprove('2', approveId)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })

    },
    // 直接入库与审批通过提交oa审批
    postProOAapprove(handleType, approveId = '') {
      let param = {
        applyId: this.applyId,
        applyAcctId: this.userInfo.acctId,
        applyAcctName: this.userInfo.acctName,
        handleType: handleType, //1-确认入库，2-提交oa审核
      }
      if (approveId) param.approveId = approveId
      InterfaceService.postProOAapprove(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.dialogVisible1 = false
          this.$message({
            showClose: true,
            message: '操作成功',
            type: 'success'
          });
          if (window.opener) {
            window.opener.location.reload();
          }
          setTimeout(() => {
            this.$router.push({
              path: '/purchaserCenter/goodsAuditList'
            })
          }, 1000)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 审批退回接口
    approveReturn() {
      let param = {
        applyId: this.applyId,
        applyMsg: this.applyMsg,
        applyAcctId: this.userInfo.acctId,
        applyAcctName: this.userInfo.acctName,
      }
      InterfaceService.approveReturn(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message({
            showClose: true,
            message: '批量退回成功',
            type: 'success'
          });
          this.dialogVisible2 = false
          // this.applyMsg = ''
          if (window.opener) {
            window.opener.location.reload();
          }
          setTimeout(() => {
            this.$router.push({
              path: '/purchaserCenter/goodsAuditList'
            })
          }, 1000)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    init() {
      this.applyId = this.$route.query.applyId
      this.pageType = this.$route.query.pageType || '0'
      this.isApprove = this.$route.query.isApprove === 'true' ? true : false
      this.applyStatus = this.$route.query.applyStatus
      this.approveName = this.$route.query.approveName
      this.getProjectInfo()
      this.shelfApplicationDelList('init')
      this.getShelfApplicatDetail()
      this.breadcrumb = [
        { name: '管理中心', path: this.pageType === '0' ? '/purchaserCenter/accountInfo' : '/vendorCenter/accountInfo' },
        { name: this.pageType === '0' ? '商品管理-待审核列表' : '商品管理-上架申请', path: this.pageType === '0' ? '/purchaserCenter/goodsAuditList' : '/vendorCenter/shelfApplication' },
        { name: this.pageType === '0' ? '审核详情' : '申请详情' },
      ];
      this.categoryNames = this.$getRootScope('categoryNames') || ''

    }
  },
  destroyed() {
    this.$removeRootScope('categoryNames')
  }
};
</script>

<style lang="scss" scoped>
.new_ico {
  position: absolute;
  left: 0;
  top: 0;
  width: 39px;
  height: 39px;
}
/deep/ .dialog-box {
  .el-dialog__header {
    font-weight: 600 !important;
  }
  .el-dialog__body {
    padding: 20px 20px 10px 20px !important;
  }
  .el-form-item {
    margin-bottom: 0px;
  }
}
.productApproveDetail {
  .inner-container {
    .steps-cont {
      padding: 20px 0;
      margin-bottom: 30px;
      box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
    }
    .top-box {
      width: 100%;
      padding: 0px 0 30px;
      border-bottom: 1px solid #eee;
      > p {
        font-size: 12px;
        line-height: 17px;
        margin-bottom: 10px;
        color: #888;
        display: flex;
        > span {
          &:nth-child(1) {
            flex-shrink: 0;
          }
          &:nth-child(2) {
            color: #444;
          }
        }
        &:last-child {
          margin-bottom: 0;
        }
      }
    }
    .panel {
      background-color: #fff;
      background: rgba(249, 249, 249, 1);
      padding: 20px 10px;
      margin: 20px 0;
    }
    .table-default {
      td {
        position: relative;
        .skuName {
          display: flex;
          .attachImg {
            width: 60px;
            height: 60px;
            min-width: 60px;
            position: relative;
            overflow: hidden;
            &.active {
              background-color: #eee;
            }
            > img {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              pointer-events: none;
              height: auto;
            }
          }
          .model {
            margin-left: 6px;
          }
        }
      }
    }
  }
}
</style>
