<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <SearchBar :search-type="5" :progress="'请款报告'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
        <div class="inner-container">
            <div class="order-info-title">基本信息</div>
            <div>
                <PaymentInfo :type="type" :info="order"></PaymentInfo>
            </div>
            <div class="order-info-title">当前签署情况及请款报告详情</div>
            <el-row :gutter="20">
                <el-col :span="8">
                    <PaymentAmtInfo :type="type" :info="order"></PaymentAmtInfo>
                </el-col>
                <el-col :span="16">
                    <SignProcessPayment :type="type" :info="order"></SignProcessPayment>
                </el-col>
            </el-row>
            <!-- 请款资料 -->
            <div class="table">
                <table>
                    <thead>
                        <tr>
                        </tr>
                    </thead>
                    <tbody v-for="(item,index) in orderList" :key="index">
                        <tr v-for="(row,_index) in item.deliveryDetail" :key="_index">

                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <FixBottom class="bottom">
            <div class="tc">
                <el-button @click="handleReject">驳回本次请款</el-button>
                <el-button @click="handlePreview">预览请款报告</el-button>
                <el-button type="primary" @click="handleConfirm">确认签章</el-button>
            </div>
        </FixBottom>

        <!-- 签章 -->
        <Signature ref="signature" @close="handleCloseSignature"></Signature>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import FixBottom from "@/components/base/FixBottom";
import PaymentInfo from "@/components/order/paymentReport/PaymentReportDetailInfo";
import PaymentAmtInfo from "@/components/order/paymentReport/PaymentReportDetailAmtInfo";
import SignProcessPayment from "@/components/order/paymentReport/SignProcessPaymentDetail";
import Signature from "@/components/order/dialog/Signature";
import { InterfaceService } from "@/services/api";
import { filterEventByAcct, allowByEvent } from "@/utils/orderUtil";
export default {
    mixins: [accountMixin],
    components: {
        Header,
        SearchBar,
        Loading,
        FixBottom,
        PaymentInfo,
        PaymentAmtInfo,
        SignProcessPayment,
        Signature
    },
    data() {
        return {
            isLoading: false,
            type: "",
            paymentNo: "",
            eventType: 3,
            order: {},
            orderList: [],
            attach: {}
        };
    },
    methods: {
        handlePreview() {
            let attachUrl = "";
            if (this.order && this.order.eventList) {
                this.order.eventList.forEach(item => {
                    if (item.eventType == this.eventType) {
                        attachUrl = item.attachUrl;
                    }
                });
            }
            if (!attachUrl) return this.$message.error("无下载地址");
            window.open(attachUrl, "_blank");
        },
        handleDownload() {
            let attachUrl = "";
            if (this.order && this.order.eventList) {
                this.order.eventList.forEach(item => {
                    if (item.eventType == this.eventType) {
                        attachUrl = item.attachUrl;
                    }
                });
            }

            if (!attachUrl) return this.$message.error("无下载地址");
            let name = attachUrl.split("?")[0];
            name = name.split("/").pop();
            const files = [{ name: decodeURIComponent(name), url: attachUrl }];
            this.$download(files).then(() => {
                this.$message.success("已下载");
            });
        },
        handleReject() {},
        handleConfirm() {
            let attach = {};
            const events = this.order.eventList || [];
            events.forEach(ev => {
                if (ev.eventType == this.eventType) {
                    attach = ev;
                }
            });
            this.handleSign(attach);
        },
        // 签章
        handleSign(attach) {
            const events = [];
            events.push(attach);
            this.attach = attach;
            this.$refs["signature"].open(events);
        },
        handleCloseSignature(bool) {
            if (bool) {
                this.$router.push({
                    path: "/signStatementSuccess",
                    query: {
                        type: this.type,
                        attachUrl: this.attach.attachUrl
                    }
                });
            }
        },
        // 对账单待签章
        allowSign() {
            let allow = false;
            if (this.order && this.order.eventList) {
                let acctIdList = [];
                if (this.userinfo.accountList.length) {
                    this.userinfo.accountList.forEach(item=>{
                        acctIdList.push(item.acctId)
                    });
                }else {
                    acctIdList.push(this.acctId)
                }
                const list = filterEventByAcct(
                    this.order.eventList,
                    this.eventType,
                    acctIdList
                );
                allow = allowByEvent(list, this.eventType);
            }
            return allow;
        },
        getDetail() {
            const params = {
                pageFlg: this.type === "pay" ? 1 : 0,
                paymentNo: this.paymentNo
            };
            InterfaceService.getStatementDetail(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        this.order = res || {};
                        this.orderList = res.statementDetails || [];
                    } else {
                        this.$message.error(res.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        init() {
            this.getDetail();
        }
    },
    mounted() {
        this.type = this.$route.query.type;
        this.eventType = this.type === "pay" ? 3 : 4;
        this.paymentNo = this.$route.query.paymentNo;
        this.init();
    }
};
</script>

<style lang="scss" scoped>
.link {
    color: #0082ff;
    &:hover {
        color: #0d83c7;
    }
}

.inner-container {
    font-size: 14px;
}

.table {
    /deep/ .el-button {
        font-size: 12px;
    }

    width: 100%;
    line-height: 23px;
    font-size: 12px;
    table {
        width: 100%;
    }
    td {
        padding: 14px 10px;
        vertical-align: middle;
        word-break: break-word;
    }

    thead {
        text-align: center;
        white-space: nowrap;
        font-size: 14px;
        color: #909399;
        background: #f5f5f5;
    }

    tbody {
        text-align: center;

        &:hover {
            background: #e8f3fd;
        }

        td {
            border-bottom: 1px solid #ebeef5;
        }

        .divide {
            border-left: 1px solid #ebeef5;
        }
    }
}

.order-info-title {
    margin-top: 40px;
    margin-bottom: 20px;
    padding: 0 10px;
    font-size: 14px;
    border-left: 3px solid #000;
    line-height: 12px;
}

.bottom {
    /deep/ .el-button {
        width: 120px;
    }
}
</style>
