<template>
  <div>
    <Header :is-white-bg="true"></Header>
    <SearchBar :search-type="5" :progress="biddingInfo.bidName" :is-border-bottom="true"></SearchBar>
    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <div class="steps-cont">
        <Steps :tenderList="tenderList" :active="biddingInfo.activeNode" :space="170"></Steps>
      </div>
      <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
      <template v-if="tab == 0">
        <el-row>
          <el-col :span="12">
            <label>招标编号：</label><span>{{biddingInfo.bidNo}}</span>
          </el-col>
          <el-col :span="12">
            <label>招标模式：</label><span>{{biddingInfo.bidModelName}}</span>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <label>招标名称：</label><span>{{biddingInfo.bidName}}</span>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <label>招标品类：</label>
            <span>
              {{threeCategoryNameList.join("、")}}
              <template v-if="biddingInfo.bidScope">（{{biddingInfo.bidScope}}）</template>
            </span>
          </el-col>
        </el-row>
        <el-row>
          <!-- <el-col :span="12">
            <label>招标经办人：</label><span>{{handleAcctNameList.join("、")}}</span>
          </el-col> -->
          <el-col :span="12">
            <label>报名截止时间：</label><span>{{biddingInfo.enterPlanEndTime}}</span>
          </el-col>
        </el-row>
        <el-row style="padding-bottom: 30px;border-bottom: 1px solid #eee;">
          <el-col :span="12">
            <label>招标年度：</label><span>{{biddingInfo.bidStartYear}}<template v-if="biddingInfo.bidEndYear">-{{biddingInfo.bidEndYear}}</template></span>
          </el-col>
          <el-col :span="12" v-if="biddingInfo.annualPurchaseVolume">
            <label>年度预计采购量：</label><span>{{biddingInfo.annualPurchaseVolume}}</span>
          </el-col>
        </el-row>
        <!--<el-row>-->
        <!--<el-col :span="12">-->
        <!--<label>价格有效期：</label><span>{{biddingInfo.bidName}} ~ {{biddingInfo.bidName}}</span>-->
        <!--</el-col>-->
        <!--</el-row>-->
        <template v-if="biddingInfo.categoryLevelThreeId && biddingInfo.categoryLevelThreeId !== '107' && isAgent">
          <div class="order-info-title">选择代理厂家</div>
          <el-row class="corporateStatement agent">
            <label :style="{'width': operationType !== 'detail' ? '7.5%':'auto'}" class="fl required">代理厂家：</label>
            <el-select v-model="agentManufacturerCorpId" placeholder="请选择代理厂家" ref="select" @change="handleChangeAgent" :class="{isError:operationType !== 'detail' && !agentManufacturerCorpId && checkAgent}" v-if="operationType !== 'detail'">
              <el-option v-for="(item,index) in agentList" :label="item.supplierName" :value="item.supplierId" :key="index"></el-option>
            </el-select>
            <div class="el-form-item__error" style="top: 40px;" v-if="operationType !== 'detail'">※请选择一家你所代理的厂家参与本次招标。</div>
            <div style="line-height: 34px;margin-left: 75px;" v-if="operationType === 'detail'">{{agentManufacturerCorpName}}</div>
          </el-row>
        </template>
        <div class="order-info-title">企业陈述</div>
        <el-row>
          要求：200字内陈述企业简介、经营范围、行业地位、经营优势等。
        </el-row>
        <el-row class="corporateStatement">
          <label :style="{'width': operationType !== 'detail' ? '7.5%':'auto'}" class="fl" :class="{required:operationType !== 'detail'}">企业陈述：</label>
          <el-input class="resizeNone" :class="{isError:operationType !== 'detail' && !corporateStatement.length && checkStatement}" v-if="operationType !== 'detail'" @blur="checkStatement = true" type="textarea" v-model="corporateStatement" :rows="4" placeholder="请输入..." maxlength="200" show-word-limit>
          </el-input>
          <div class="el-form-item__error" v-if="operationType !== 'detail' && !corporateStatement.length && checkStatement">必填</div>
          <div style="line-height: 17px;margin-left: 75px;" v-if="operationType === 'detail'" v-html="corporateStatement"></div>
        </el-row>
        <biddingContacts v-if="Object.keys(supplierBiddingInfo).length || operationType === 'submit'" :supplierBiddingInfo="supplierBiddingInfo" :checkForm="checkForm" @checkRes="checkRes" :isSubmit="operationType !== 'detail'" ref="biddingContacts"></biddingContacts>
        <div class="tc" style="margin-bottom: 70px;" v-if="supplierBiddingInfo.ibSupplierBidInfo && supplierBiddingInfo.ibSupplierBidInfo.submitBidStatus !=='WAIT_ENTER' && supplierBiddingInfo.ibSupplierBidInfo.submitBidStatus !=='NO_INVITED'">
          <el-button style="width: 260px;height: 50px;margin-top: -80px;margin-bottom: 70px;" @click="handleBatchDownload">打包下载资质附件</el-button>
        </div>
      </template>
      <template v-if="tab == 1">
        <SupplierQuestion v-if="biddingInfo.planList && biddingInfo.planList.length" :bidNo="bidNo" :nodePlan="nodePlan" :planList="biddingInfo.planList"></SupplierQuestion>
      </template>
      <template v-if="tab == 2">
        <SupplierBidding :hiddenUploadFlg="hiddenUploadFlg" :activeNode="biddingInfo.activeNode" :bidName="biddingInfo.bidName" :isSupplyPicture="biddingInfo.isSupplyPicture"></SupplierBidding>
      </template>
      <template v-if="tab == 3">
        <SupplierInquiry :nodePlan="nodePlan" :buyersNodePlan="buyersNodePlan" :isSupplyPicture="biddingInfo.isSupplyPicture"></SupplierInquiry>
      </template>
      <template v-if="tab == 4">
        <SupplierWinningBid :nodePlan="nodePlan" :bidName="biddingInfo.bidName" :ibBidCategoryInfos="biddingInfo.ibBidCategoryInfos"></SupplierWinningBid>
      </template>
      <!--<template v-else>-->
      <!--暂未开发-->
      <!--</template>-->
    </div>
    <FixBottom v-if="!supplierBiddingInfo.ibSupplierBidInfo || supplierBiddingInfo.ibSupplierBidInfo.submitBidStatus ==='WAIT_ENTER' || (supplierBiddingInfo.ibSupplierBidInfo.submitBidStatus ==='NO_INVITED' && supplierBiddingInfo.ibSupplierBidInfo.originCode =='2') ">
      <div class="fix-bottom tc">
        <el-button type="primary" @click="handleSubmit('1')">报名</el-button>
        <el-button @click="handleSubmit('0')">保存</el-button>
      </div>
    </FixBottom>
    <FixBottom v-if="operationType === 'detail' && biddingInfo.bidPhase === 'SUPPLIER_RECRUIT'">
      <div class="fix-bottom tc">
        <el-button type="primary" @click="handleSubmitAgain">重新报名</el-button>
      </div>
    </FixBottom>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import SearchBar from "@/components/SearchBar";
import Header from "@/components/base/Header";
import FixBottom from "@/components/base/FixBottom";
import PanelTitle from "@/components/base/PanelTitle";
import biddingContacts from "@/components/order/biddingManagement/biddingContacts";
import Breadcrumb from "@/components/base/Breadcrumb";
import Loading from "@/components/base/Loading";
import SupplierQuestion from "@/components/order/biddingManagement/SupplierQuestion";
import SupplierBidding from "@/components/order/biddingManagement/SupplierBidding";
import SupplierInquiry from "@/components/order/biddingManagement/SupplierInquiry";
import SupplierWinningBid from "@/components/order/biddingManagement/SupplierWinningBid";
import Steps from "@/components/base/steps";
import { Message, MessageBox } from 'element-ui';

export default {
  name: "biddingSignUpInfo",
  components: {
    SearchBar,
    Header,
    FixBottom,
    PanelTitle,
    biddingContacts,
    Breadcrumb,
    Loading,
    Steps,
    SupplierQuestion,
    SupplierBidding,
    SupplierInquiry,
    SupplierWinningBid,
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo;
    },
    isAgent() {
      return this.$store.state.userInfo && ['1', '5'].includes(this.$store.state.userInfo.supplyType)
    }
  },
  data() {
    return {
      buyersNodePlan: '',
      corporateStatement: "",
      tabs: [
        { label: "报名", type: 0, active: true, disabled: false },
        { label: "提问", type: 1, active: false, disabled: true },
        { label: "投标", type: 2, active: false, disabled: true },
        { label: "询标", type: 3, active: false, disabled: true },
        { label: "中标", type: 4, active: false, disabled: true },
      ],
      tab: 0,
      operationType: "",
      agentManufacturerCorpId: "",
      agentManufacturerCorpName: "",
      nodePlan: "",
      checkStatement: false,
      checkAgent: false,
      checkForm: false,
      isLoading: false,
      hiddenUploadFlg: false,
      num: 1,
      biddingInfo: {},
      tenderList: [],
      agentList: [],
      handleAcctNameList: [],
      threeCategoryNameList: [],
      supplierBiddingInfo: {},
      handleType: "",
      bidNo: "",
      submitBidNo: "",
      breadcrumb: []
    }
  },
  watch: {
    "$route": function (to, from) {
      console.log(to, from);
      if (from.fullPath != to.fullPath) {
        this.init()
      }
    },
    tab(newVal) {
      this.tabs.forEach(item => {
        if (item.type == newVal) {
          this.breadcrumb[3].name = item.label
        }
      })
    }
  },
  methods: {
    handleBatchDownload() {
      let fileInfoBeans = []
      if (this.supplierBiddingInfo.ibSupplierBidContactInfoList && this.supplierBiddingInfo.ibSupplierBidContactInfoList.length) {
        this.supplierBiddingInfo.ibSupplierBidContactInfoList.forEach((item, index) => {
          if (item.contactFileInfoList && item.contactFileInfoList.length) {
            item.contactFileInfoList.forEach((_item, _index) => {
              fileInfoBeans.push({
                archivePath: (index == 0 ? '投标负责人' : '投标对接人') + "/" + _item.attachName,
                fileUrl: _item.attachUrl,
              })
            })
          }
        })
      }
      if (this.supplierBiddingInfo.ossFileInfoList && this.supplierBiddingInfo.ossFileInfoList.length) {
        this.supplierBiddingInfo.ossFileInfoList.forEach(item => {
          if (item.fileType == "6") {
            fileInfoBeans.push({
              archivePath: '与其他房企战略合作中标证明/' + item.attachName,
              fileUrl: item.attachUrl,
            })
          } else if (item.fileType == "7") {
            fileInfoBeans.push({
              archivePath: '其他附件/' + item.attachName,
              fileUrl: item.attachUrl,
            })
          }
        })
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            // const files = [
            //   { name: this.biddingInfo.bidName + "附件.zip", url: url }
            // ];
            // this.$download(files, () => {this.isLoading = true}, () => {this.isLoading = false}).then(() => {
            //   this.$message.success("已下载");
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: this.biddingInfo.bidName + "附件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    handleChangeAgent() {
      this.agentList.forEach(item => {
        if (item.supplierId == this.agentManufacturerCorpId) {
          this.agentManufacturerCorpName = item.supplierName
        }
      })
      this.checkAgent = true
    },
    // 修改tab
    handleChangeTab(tab) {
      if (tab.active) {
        this.tab = tab.type;
      }
    },
    checkRes(bool, params) {
      this.checkForm = false;
      if (bool && this.corporateStatement && ((this.isAgent && this.biddingInfo.categoryLevelThreeId !== '107' && this.agentManufacturerCorpId) || !(this.isAgent && this.biddingInfo.categoryLevelThreeId !== '107'))) {
        if (this.handleType == '1') {
          this.$confirm(
            "确认已完善资质附件，并报名参与招标？",
            "确认报名",
            {
              cancelButtonClass: "btn-custom-cancel",
              confirmButtonClass: "btn-custom-confirm",
              center: true,
              confirmButtonText: "确认报名",
              cancelButtonText: '取消',
            }).then(() => {
              this.submit(params);
            }).catch(() => {
            });
        } else {
          this.submit(params)
        }
      }
    },
    submit(params) {
      params.bidNo = this.bidNo;
      params.submitBidNo = this.submitBidNo || "";
      params.corporateStatement = this.corporateStatement;
      if (this.isAgent && this.biddingInfo.categoryLevelThreeId !== '107') {
        params.agentManufacturerCorpId = this.agentManufacturerCorpId;
        params.agentManufacturerCorpName = this.agentManufacturerCorpName;
      }

      params.submitAcctName = this.userInfo.acctName || "";
      params.handleType = this.handleType;
      console.log(params);
      InterfaceService.supplierBiddingSignUp(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          let submitBidNo = data.respData.submitBidNo || "";
          if (this.handleType == '1') {
            MessageBox.alert(
              "报名成功！",
              {
                confirmButtonClass: "btn-alert",
                dangerouslyUseHTMLString: true,
                center: true,
                confirmButtonText: "知道了",
                callback: action => {
                  this.$router.push({
                    path: "/biddingSignUpInfo",
                    query: {
                      bidNo: this.bidNo,
                      submitBidNo: submitBidNo,
                      type: "detail",
                    },
                  })
                }
              }
            );
          } else {
            this.$message.success("保存成功！");
            this.submitBidNo = submitBidNo;
            this.supplierBidAnnDetail();
          }
          window.opener && window.opener.location.reload();
        } else {
          this.$message.error(data.respData.respMsg)
        }
      },
        data => { },
        () => { this.isLoading = true },
        () => { this.isLoading = false })
    },
    handleSubmit(type) {
      this.checkStatement = true;
      this.checkAgent = true;
      this.checkForm = true;
      this.handleType = type
    },
    handleSubmitAgain() {
      this.$confirm(
        "确认重新编辑报名信息吗？",
        "重新报名",
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          confirmButtonText: "确认",
          cancelButtonText: '取消',
        }).then(() => {
          InterfaceService.resumeRegistrationStatus(
            {
              bidNo: this.bidNo,
              submitBidNo: this.submitBidNo,
            },
            data => {
              if (data.respData.respCode === "0000") {
                let query = this.$router.history.current.query;
                let path = this.$router.history.current.path;
                //对象的拷贝
                let newQuery = JSON.parse(JSON.stringify(query));
                newQuery.type = 'continue';
                this.$router.push({ path, query: newQuery });
                this.init();
                window.opener && window.opener.location.reload();
              } else {
                this.$message.error(data.respData.respMsg);
              }
            },
            data => {
              this.$message.error(data.respData.respMsg);
            },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            }
          );
        }).catch(() => {
        });
    },
    getBuyersTenderDetail() {
      InterfaceService.getBuyersTenderDetail(
        { bidNo: this.bidNo },
        data => {
          if (data.respData.respCode === "0000") {
            this.biddingInfo = data.respData || {};
            this.handleAcctNameList = [];
            if (this.biddingInfo.handleInfos && this.biddingInfo.handleInfos.length) {
              this.biddingInfo.handleInfos.forEach(item => {
                this.handleAcctNameList.push(item.handleAcctName)
              })
            }
            let nodePlanInfoList = this.biddingInfo.nodePlanInfoList || []
            nodePlanInfoList.forEach((item, index) => {
              if (item.lightShow === '0') {
                this.buyersNodePlan = item.nodePlan;
              }
            });

            this.threeCategoryNameList = [];
            this.biddingInfo.ibBidCategoryInfos = this.biddingInfo.ibBidCategoryInfos || [];
            if (this.biddingInfo.ibBidCategoryInfos.length == 1) {
              this.threeCategoryNameList.push(this.biddingInfo.ibBidCategoryInfos[0].categoryLevelThreeName)
            } else {
              this.biddingInfo.ibBidCategoryInfos.forEach(i => {
                this.threeCategoryNameList.push(i.categoryLevelTwoName)
              });
              this.threeCategoryNameList = [...new Set(this.threeCategoryNameList)]
            }
            // console.log(data.respData);
            if (data.respData.planList) {
              this.hiddenUploadFlg = false;
              data.respData.planList.forEach(plan => {
                let datetime = new Date()
                let year = datetime.getFullYear();
                let month = datetime.getMonth() + 1 < 10 ? "0" + (datetime.getMonth() + 1) : datetime.getMonth() + 1;
                let date = datetime.getDate() < 10 ? "0" + datetime.getDate() : datetime.getDate();
                let now = year + '/' + month + '/' + date
                if (plan.nodePlan === "BACK_BID" && plan.planEndTime) {
                  let a = plan.planEndTime.replace(/-/g, "/")
                  // console.log('===' + a)
                  this.hiddenUploadFlg = a < now;
                  // console.log(this.hiddenUploadFlg)
                }
              });
              // console.log(this.hiddenUploadFlg)
            }
            //是代理商且不是钢筋品类才显示选择厂家
            if (this.isAgent && this.biddingInfo.categoryLevelThreeId !== '107') {
              this.getAgentList()
            } else {
              this.supplierBidAnnDetail()
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    supplierBidAnnDetail() {
      InterfaceService.supplierBidAnnDetail(
        {
          submitBidNo: this.submitBidNo,
          bidNo: this.bidNo,
        },
        data => {
          if (data.respData.respCode === "0000") {
            this.supplierBiddingInfo = data.respData || {};
            this.corporateStatement = this.supplierBiddingInfo.corporateStatement || ""
            this.submitBidNo = this.submitBidNo || data.respData.submitBidNo;
            if (this.supplierBiddingInfo.ibSupplierBidInfo &&
              this.supplierBiddingInfo.ibSupplierBidInfo.submitBidStatus !== 'WAIT_ENTER' &&
              (this.supplierBiddingInfo.ibSupplierBidInfo.submitBidStatus !== 'NO_INVITED' || this.supplierBiddingInfo.ibSupplierBidInfo.originCode !== '2')
            ) {
              this.operationType = "detail"
            } else {
              this.operationType = this.$route.query.type || "";
            }
            if (this.operationType == "detail") {
              this.corporateStatement = this.corporateStatement && this.corporateStatement.replace(/\n/g, '<br/>') || "";
            }
            if (this.supplierBiddingInfo.ibSupplierBidInfo && this.supplierBiddingInfo.ibSupplierBidInfo.agentManufacturerCorpId) {
              this.agentManufacturerCorpId = this.supplierBiddingInfo.ibSupplierBidInfo && this.supplierBiddingInfo.ibSupplierBidInfo.agentManufacturerCorpId || "";
              this.agentManufacturerCorpName = this.supplierBiddingInfo.ibSupplierBidInfo && this.supplierBiddingInfo.ibSupplierBidInfo.agentManufacturerCorpName || "";
            } else {
              if (this.operationType !== "detail") {
                if (this.agentList && this.agentList.length === 1) {
                  this.agentManufacturerCorpName = this.agentList[0].supplierName;
                  this.agentManufacturerCorpId = this.agentList[0].supplierId
                }
              }
            }

            if (data.respData.nodePlanInfoList) {
              this.tenderList = [];
              data.respData.nodePlanInfoList.forEach(item => {
                this.tenderList.push({
                  top_title: item.bidTimeTab,
                  top_info: item.planTime,
                  foot_title: item.nodePlanName,
                  nodePlan: item.nodePlan,
                  lightShow: item.lightShow,
                  hideFlg: item.hideFlg,
                })
              })
            }
            let limit = 0;
            let finish = true
            this.tenderList.forEach((item, index) => {
              if (item.lightShow === '0') {
                finish = false
                this.nodePlan = item.nodePlan;
                this.biddingInfo.activeNode = index;
                if (item.nodePlan == "ENTER" || item.nodePlan == "INVITED" || item.nodePlan == "ALREADY_INVITED" || item.nodePlan == "BID_ISSUANCE") {
                  limit = 0
                } else if (item.nodePlan == "QUIZ" || item.nodePlan == "BID") {
                  limit = 2
                } else if (item.nodePlan == "INQUIRY_BID") {
                  limit = 3
                } else if (item.nodePlan == "AWARDED" || item.nodePlan == "INCOMING") {
                  limit = 4
                }
              }
            });
            if (finish) {
              this.biddingInfo.activeNode = this.tenderList.length;
              limit = 4;
              this.nodePlan = this.tenderList[this.tenderList.length - 1].nodePlan
            }
            this.tabs.forEach((item, index) => {
              item.disabled = index > limit;
              if (index === limit && index === 4 && this.supplierBiddingInfo.ibSupplierBidInfo.submitBidStatus === 'NO_AWARDED') {
                item.disabled = true
              }
              item.active = item.type == this.tab;
            });
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    getAgentList() {
      InterfaceService.getSuperiorSupplierList(
        {},
        data => {
          if (data.respData.respCode === "0000") {
            this.agentList = data.respData.licensingCorpList || [];
            this.supplierBidAnnDetail()

          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    init() {
      this.bidNo = this.$route.query.bidNo || "";
      this.submitBidNo = this.$route.query.submitBidNo || "";
      this.tab = +this.$route.query.tab || 0;
      this.getBuyersTenderDetail();
      // this.supplierBidAnnDetail();
      this.breadcrumb = [
        { name: `${ this.userInfo.bs == 'S' ? '供应商' : '采购商'}管理中心`, path: `${ this.userInfo.bs == 'S' ? '/vendorCenter' : '/purchaserCenter'}/accountInfo` },
        { name: '投标管理', path: `${ this.userInfo.bs == 'S' ? '/vendorCenter' : '/purchaserCenter'}/participatingBiddingList` },
        { name: '参与的招标', path: `${ this.userInfo.bs == 'S' ? '/vendorCenter' : '/purchaserCenter'}/participatingBiddingList` },
        { name: '报名' },
      ]
    }
  },
  mounted() {
    this.init();
  }
}
</script>

<style scoped lang="scss">
.list-content {
  width: 1190px;
}
/deep/ .el-row {
  margin-bottom: 10px;
  label {
    color: #888888;
    width: 7.5%;
  }
  .el-col {
    span {
      color: #444444;
    }
  }
}
.order-info-title {
  margin: 20px 0;
  padding: 0 10px;
  font-size: 14px;
  border-left: 3px solid #000;
  line-height: 12px;
}
.el-textarea {
  display: inline-block;
  width: 92.5%;
}
.required {
  &::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}

.corporateStatement {
  margin-bottom: 0;
  padding-bottom: 30px;
  border-bottom: 1px solid #eeeeee;
  .el-form-item__error {
    position: absolute;
    padding-left: 7.5%;
    top: 100px;
  }
}
.agent {
  .el-select {
    height: 34px;
    width: 400px;
  }
  label {
    line-height: 34px;
  }
}
/deep/ .el-row {
  overflow: visible;
}
.resizeNone {
  /deep/ .el-textarea__inner {
    resize: none;
  }
}
.isError {
  /deep/ .el-textarea__inner,
  /deep/ .el-input__inner {
    border-color: #f56c6c;
  }
}
.steps-cont {
  padding: 20px 0;
  border: 1px solid #eee;
  box-shadow: 0px 0px 2px 0px #888888;
  margin-bottom: 30px;
  /deep/ .el-step__head {
    margin-bottom: 14px;
  }
}
</style>