<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :progress="`${isElectronicSignature ? '签署' : operType ==='edit' ? '编辑' : '创建'}验收单-第${orderInfo.requireBatchNo || 1}批`" :is-border-bottom="true" :product-create-process="2"></SearchBar>
    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <!-- 合同基本信息 -->
      <div class="order-info">
        <PanelTitle title="合同基本信息"></PanelTitle>
        <RequireOrderInfo :showOtherFile="false" v-if="Object.keys(orderInfo).length" :orderInfo="orderInfo" @refresh="getRequireOrderDetail"></RequireOrderInfo>
        <PanelTitle title="验收清单"></PanelTitle>
        <div class="list-content">
          <FixSearch :TopDistance="900">
            <div slot="center">
              <div class="search-container fix-search-container">
                <div class="left">
                  <span>商品名/型号：</span>
                  <el-input v-model.trim="searchKey" placeholder="请输入关键词" maxlength="30" clearable></el-input>
                </div>
                <div class="right">
                  <div class="radio-container">
                    <span>筛选：</span>
                    <el-radio-group v-model="tabValue">
                      <el-radio :label="'0'">全部</el-radio>
                      <el-radio :label="'1'" v-if="!isElectronicSignature">显示未填写实际验收的商品</el-radio>
                      <el-radio :label="'2'" v-else>显示已填写实际验收的商品</el-radio>
                    </el-radio-group>
                  </div>
                  <div class="btn-contaier">
                    <el-button type="primary" style="width: 80px;" @click="handleClickSearchSubmit">查询</el-button>
                    <el-button style="width: 80px;" @click="handleClickSearchResult">重置</el-button>
                  </div>
                </div>
              </div>
            </div>
          </FixSearch>
          <TableThead :TopDistance="900" :fixedTop="50">
            <tr slot="tr">
              <td width="80px" style="padding-left: 10px;">序号</td>
              <td width="500px">商品名称/型号</td>
              <!--<td width="150px" class="tr">累计已供货量(含本次)</td>-->
              <td width="150px" class="tr">本批次供货量</td>
              <td width="150px" class="tr">本批次要货量</td>
              <td width="200px" class="tr"><span class="required" v-if="!isElectronicSignature"></span>实际验收数量</td>
              <td class="tl opt">操作</td>
            </tr>
          </TableThead>
          <div class="search-container">
            <div class="left">
              <span>商品名/型号：</span>
              <el-input v-model.trim="searchKey" placeholder="请输入关键词" maxlength="30" clearable></el-input>
            </div>
            <div class="right">
              <div class="radio-container">
                <span>筛选：</span>
                <el-radio-group v-model="tabValue">
                  <el-radio :label="'0'">全部</el-radio>
                  <el-radio :label="'1'" v-if="!isElectronicSignature">显示未填写实际验收的商品</el-radio>
                  <el-radio :label="'2'" v-else>显示已填写实际验收的商品</el-radio>
                </el-radio-group>
              </div>
              <div class="btn-contaier">
                <el-button type="primary" style="width: 80px;" @click="handleClickSearchSubmit">查询</el-button>
                <el-button style="width: 80px;" @click="handleClickSearchResult">重置</el-button>
              </div>
            </div>
          </div>
          <table class="table-default">
            <thead>
              <tr>
                <td width="80px" style="padding-left: 10px;">序号</td>
                <td width="500px">商品名称/型号</td>
                <!--<td width="150px" class="tr">累计已供货量(含本次)</td>-->
                <td width="150px" class="tr">本批次供货量</td>
                <td width="150px" class="tr">本批次要货量</td>
                <td width="200px" class="tr"><span class="required" v-if="!isElectronicSignature"></span>实际验收数量</td>
                <td class="tl opt">操作</td>
              </tr>
            </thead>
            <tbody v-for="(item,ind) in goodsList" :key="ind" class="tbody-row" style="border-bottom: 1px solid #eee;">

              <!-- unLocation 无使用标段, isElectronicSignature 电子签章模式, checkDescription: 有验收情况的 -->
              <tr style="border-bottom-style: dashed;" :class="{unLocation: !item.location, isElectronicSignature: isElectronicSignature, checkDescription: item.details && item.details[0] && item.details[0].checkDescription}">
                <td style="padding-left: 10px;">
                  <el-checkbox v-if="!isElectronicSignature" v-model="item.select" @change="handleChangeParentSelect(item)"></el-checkbox>
                  {{ind + 1 + ((pageIndex - 1) * pageSize)}}
                </td>
                <td>
                  <div class="thumbnail fl" :style="{background:item.picUrl || item.picUrl ? 'url('+(item.picUrl || item.picUrl)+')' : '#eee'}"></div>
                  <div :ref="'goodsHeight' + ind" class="fl" style="margin-left: 6px;">
                    <p :title="item.skuName" class="goods-name hover-underline hand" @click="handleGoproduct(item)">{{item.skuName}}</p>
                    <p style="margin-top: 10px;">型号：{{item.model}}</p>
                    <p class="new-goods" v-if="item.isNewCom == '1'">新组价商品
                      <el-popover popper-class="dark-popover" trigger="hover" placement="right">
                        <div style="color: #fff;width: 185px;">
                          新组价商品是指，代理商创建合同时，新组的商品。
                        </div>
                        <i slot="reference"><em class="triangle-topright"></em></i>
                      </el-popover>
                    </p>
                    <p class="tag" v-if="item.isCombination=='1' && item.isNewCom !== '1'">组价商品</p>
                    <p class="tag bg-lightSteelBlue" v-if="item.bidSurchangeBeanList && item.bidSurchangeBeanList.length">含附加项</p>
                  </div>

                  <div class="text-textarea parent-text-textarea" v-if="!item.location && item.details && item.details[0]">
                    <el-input v-if="!isElectronicSignature" v-model="item.details[0].checkDescription" placeholder="请输入验收情况(选填)，限100字" maxlength="100"></el-input>
                    <p v-else-if="item.details[0].checkDescription">
                      <span class="yellow bold">验收情况：</span>{{item.details[0].checkDescription}}
                    </p>
                  </div>
                </td>

                <!--<td class="tr" :class="{color9452FF:isElectronicSignature}">-->
                  <!--<p class="">{{item.totalCnt}}{{item.details && item.details[0] && item.details[0].goodsUnit || ''}}</p>-->
                <!--</td>-->

                <td class="tr">
                  <p :class="{colorFF7D1D:!isElectronicSignature,color9452FF:isElectronicSignature}">{{item.thisTimeCnt}}{{item.details && item.details[0] && item.details[0].goodsUnit || ''}}</p>
                  <p class="red notice" v-if="+item.thisTimeCnt >totalCountCompured(item)">※供货量超过要货量</p>
                  <p class="red notice" v-if="+item.thisTimeCnt < totalCountCompured(item)">※供货量少于要货量</p>
                </td>

                <td class="tr">
                  <!-- 有location  取汇总 -->
                  <p class="color9452FF">{{totalCountCompured(item)}}{{item.details && item.details[0] && item.details[0].goodsUnit || ''}}</p>
                </td>

                <td class="tr">
                  <template v-if="!item.location && item.details && item.details[0] && !isElectronicSignature">
                    <el-input v-model="item.details[0].receiveCount" placeholder="请输入数量" class="right_padding" maxlength="13" @input="checkNum($event,item.details[0],'receiveCount',item)">
                      <div slot="suffix" class="suffix" :title="item.details[0].goodsUnit">{{item.details[0].goodsUnit}}</div>
                    </el-input>
                  </template>
                  <p v-else-if="item && item.details && item.details[0]" class="color9452FF">
                    {{item.location ? totalCountCompured(item, 'receiveCount') : item.details[0].receiveCount}}{{item.details[0].goodsUnit}}
                  </p>

                  <p class="red notice" v-if="!item.location && item.details && item.details[0] && !isElectronicSignature && item.details[0].errorMsg">{{item.details[0].errorMsg}}</p>
                  <p class="red notice" v-else-if="totalCountCompured(item, 'receiveCount') > +item.thisTimeCnt">※总验收数量不得超过供货量</p>
                </td>
                <td class="opt">
                  <template v-if="!item.location || isElectronicSignature">
                    <p>
                      <DownloadAndUpload v-if="!isElectronicSignature" appName="TRD" :hasDownloadFlg="false" :fromId="item.details[0].requireDetailId" uploadType="11" uploadName="上传验收附件" @outputValue="getAttachInfo"></DownloadAndUpload>
                    </p>
                    <p class="blue-pointer" @click="handleGoodsDetailDia(item)">查看要货信息</p>
                  </template>
                </td>
              </tr>
              <template v-if="item.location && !isElectronicSignature">
                <tr v-for="(dItem, dIdx) in item.details" :key="dIdx" class="details-tr" :class="{dItemCheckDescription: dItem.checkDescription || !isElectronicSignature}">
                  <td>
                    <el-checkbox v-if="!isElectronicSignature" v-model="dItem.select" @change="handleChangeDetailSelect(dItem)"></el-checkbox>
                    {{dItem.label}}
                  </td>
                  <td>
                    <p>{{dItem.location}}</p>
                    <div class="text-textarea">
                      <el-input v-if="!isElectronicSignature" v-model="dItem.checkDescription" placeholder="请输入验收情况(选填)，限100字" maxlength="100"></el-input>
                      <span v-else>{{dItem.checkDescription}}</span>
                    </div>
                  </td>
                  <td class="tr">
                    <p>{{dItem.thisTimeCnt}}{{dItem.goodsUnit}}</p>
                  </td>
                  <td class="tr">
                    <p>{{dItem.requireCount}}{{dItem.goodsUnit}}</p>
                  </td>
                  <td class="tr">
                    <template v-if="!isElectronicSignature">
                      <el-input v-model="dItem.receiveCount" placeholder="请输入数量" class="right_padding" maxlength="13" @input="checkNum($event,dItem,'receiveCount')">
                        <div slot="suffix" class="suffix" :title="dItem.goodsUnit">{{dItem.goodsUnit}}</div>
                      </el-input>
                      <!-- <p class="red notice pr4" v-if="acceptanceQuantityVerificationComputed(item)">※总验收数量不的超过供货量</p> -->
                      <p class="red notice tl" v-if="dItem.errorMsg">{{dItem.errorMsg}}</p>
                    </template>

                    <p v-else>{{dItem.receiveCount || ''}}{{dItem.goodsUnit}}</p>
                  </td>
                  <td class="tr">
                    <template v-if="!isElectronicSignature">
                      <p>
                        <DownloadAndUpload appName="TRD" :hasDownloadFlg="false" :fromId="dItem.requireDetailId" uploadType="11" uploadName="上传验收附件" @outputValue="getAttachInfo"></DownloadAndUpload>
                      </p>
                      <p class="blue-pointer" @click="handleGoodsDetailDia(item)">查看要货信息</p>
                    </template>
                  </td>
                </tr>
              </template>
              <template v-else-if="item.details && item.details.filter(f=> f.location).length">
                <tr class="attr-list-tr children-tr" v-for="(dItem, dIdx) in item.details" :key="dIdx" :class="{isElectronicSignature: isElectronicSignature}">
                  <td :rowspan="item.details && item.details.length || 1" v-if="dIdx == 0" class="bgfff va-t">
                    <span class="yellow bold">使用标段：</span>
                  </td>
                  <td colspan="2">
                    <span class="bold">{{dItem.label}}：</span>
                    <span>{{dItem.location}}</span>
                    <div class="text-textarea">
                      <span class="bold">验收情况：</span>
                      <span>{{dItem.checkDescription}}</span>
                    </div>
                  </td>
                  <td class="tr">
                    <p>{{dItem.requireCount}}{{dItem.goodsUnit}}</p>
                  </td>
                  <td class="tr">
                    <p>{{dItem.receiveCount || ''}}{{dItem.goodsUnit}}</p>
                  </td>
                  <td class="tr">

                  </td>
                </tr>
              </template>
              <template v-if="item.details.some(s=> s.acceptanceAnnexAttachList && s.acceptanceAnnexAttachList.length)">
                <tr class="attr-list-tr tdPb14" :class="{isElectronicSignature: isElectronicSignature}">
                  <td class="flex-vtop"><span class="colorC99F4F check-file bold" style="margin-top: 4px;">验收附件：</span></td>
                  <td colspan="4">
                    <ul>
                      <li v-for="(dItme, dIdx) in item.details.filter(f=> f.acceptanceAnnexAttachList && f.acceptanceAnnexAttachList.length)" :key="dIdx">
                        <font v-if="item.details && item.details.filter(f=> f.location).length">{{dItme.label}}：</font>
                        <span v-for="(aItem, aIdx) in dItme.acceptanceAnnexAttachList" :key="aIdx">
                          <em @click="handleDownloadFile(aItem)">{{aItem.attachName || ''}}</em>
                          <i class="el-icon-close" v-if="!isElectronicSignature" @click="handleDelFile(dItme, aItem, aIdx)"></i>
                          <i class="download blue-pointer" v-else>
                            <DownloadAndUpload appName="TRD" :templateFile="{templateFileName: aItem.attachName, url: aItem.attachUrl}" uploadType="11" :hasUpload="false" :hasDownloadFlg="true" downloadName="下载"></DownloadAndUpload>
                          </i>
                        </span>
                      </li>
                    </ul>
                  </td>
                  <td class="download-file">
                    <p class="blue-pointer" v-if="isElectronicSignature">
                      <span @click="handleBatchDownload(item)">下载验收附件</span>
                    </p>
                  </td>
                </tr>
              </template>
            </tbody>
          </table>
        </div>
        <div class="table-pagination" v-if="goodsList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
        <div class="product-empty" v-if="!goodsList.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <div>没有搜索到相关商品，请重新修改搜索条件搜索！</div>
        </div>
        <PanelTitle title="附件"></PanelTitle>
        <div class="f12 other-title">
          <span>其他附件</span>
          <DownloadAndUpload v-if="!isElectronicSignature" appName="TRD" fromId="other" uploadType="12" :hasDownloadFlg="false" @outputValue="getAttachInfoOther"></DownloadAndUpload>
          <span class="download blue-pointer" @click="handleOtherDownload" v-else>下载</span>
        </div>
        <div class="enclosure-content" v-if="deliveryAttachList.length" style="margin-top: 4px; margin-bottom: 112px;">
          <p v-for="(item,index) in deliveryAttachList" :key="index">
            {{item.attachName}}
            <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="item.viewUrl || item.attachUrl" :attachName="item.attachName"></DownloadAndView>
            <span class="blue-pointer del-other-file-btn" @click="handleDelOtherFile(item, index)" v-if="!isElectronicSignature">删除</span>
          </p>

        </div>
        <div class="enclosure-content" style="color: #bbb;margin-top: 4px; margin-bottom: 112px;" v-else>
          暂未上传附件！
        </div>
      </div>
    </div>
    <FixBottom>
      <div class="tc foot-fix-container" :class="{center: isElectronicSignature}">
        <template v-if="!isElectronicSignature">
          <div class="left-container">
            <label>
              <el-checkbox v-model="selectAll" @change="handleChangeSelectAll"></el-checkbox>
              <span>本页全选</span>
            </label>
            <span>已选{{selectCount}}款</span>
            <el-input v-model="acceptanceAll" placeholder="勾选商品，在此处输入需要批量填写验收情况，限100字" maxlength="100"></el-input>
            <el-button type="primary" style="width: 140px;" @click="handleClickAcceptance">批量填写验收情况</el-button>
          </div>
          <div class="btn-container">
            <el-button style="width: 120px;" @click="handleClickSaveSignRecipt">保存</el-button>
            <el-button type="primary" style="width: 120px;" @click="handleClickSubmitConfirm">提交验收单</el-button>
          </div>
        </template>
        <div v-else>
          <el-button type="primary" style="width: 120px;" @click="handleSign">电子签章</el-button>
        </div>
      </div>
    </FixBottom>
    <!-- 确认发货 -->
    <GoodsDetailDialog ref="goodsDetailDialog"></GoodsDetailDialog>

    <!--电子签章 -->
    <Signature ref="signature" :propCorpId="role=='B' ? orderInfo.purchaserId : ''" :propAcctId="role=='B' ? orderInfo.operAcctId : ''" :mainText="role=='B' ? orderInfo.purchaserName : ''" @close="handleCloseSignature"></Signature>

    <Loading :is-loading="isLoading"></Loading>
  </div>

</template>
<script>
import accountMixin from "@/mixins/account";
import Header from "@/components/base/Header";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import ViceHeader from "@/components/base/ViceHeader";
import InputNumber from "@/components/base/InputNumber";
import GoodsDetailDialog from "@/components/order/dialog/GoodsDetailDialog";
import { InterfaceService } from "@/services/api";
import Breadcrumb from "@/components/base/Breadcrumb";
import RequireOrderInfo from "@/components/order/RequireOrderInfo";
import SearchBar from "@/components/SearchBar";
import { NumberUtil } from '@/utils/numberUtil';
import FixBottom from "@/components/base/FixBottom";

import DownloadAndUpload from "@/components/base/DownloadAndUpload";
import DownloadAndView from '@/components/order/DownloadAndView'
import SignRecipt from "@/components/order/dialog/SignRecipt";
import TableThead from "@/components/base/TableThead";
import FixSearch from "@/components/base/FixSearch";
import Signature from "@/components/order/dialog/Signature";

import { filterEventByAcct } from '@/utils/orderUtil';


const deliverForm = {
  shippingMethod: "1",
  expressCompany: "",
  trackingNo: ""
};
export default {
  mixins: [accountMixin],
  components: {
    Header,
    Loading,
    PanelTitle,
    FixBottom,
    ViceHeader,
    InputNumber,
    RequireOrderInfo,
    Signature,
    GoodsDetailDialog,
    TableThead,
    FixSearch,
    SearchBar,
    SignRecipt,
    DownloadAndUpload,
    DownloadAndView,
    Breadcrumb
  },
  props: ["type"],
  data() {
    return {
      isLoading: false,
      submitConfirmDialog: false,
      allCheck: false,
      reciveText: "",
      selectAll: false,
      acceptanceAll: '',
      requireNo: "",
      operType: "",
      deliveryNo: "",
      orderInfo: {},
      requireList: [],
      deliveryAttachList: [],
      breadcrumb: [],
      goodsList: [],
      comfirmRequireList: [],
      storageGoodsList: [],
      delAttachList: [],
      flow: [
        {
          name: "确认发货信息",
          active: true,
          next: true
        },
        {
          name: "发货成功",
          active: false,
          next: false
        }
      ],
      showPageNav: false,
      systemTime: "",
      expressCompanyList: [],
      deliverForm: Object.assign({}, deliverForm),
      pageSize: 1,
      total: 0,
      pageIndex: 1,
      rules: {
        expressCompany: [
          {
            required: true,
            message: "请选择物流公司",
            trigger: "change"
          },
        ],
        trackingNo: [
          {
            required: true,
            message: "请填写运单号码",
            trigger: "blur"
          },
        ]
      },
      delOtherAttachList: [], // 删除 其他附件
      delAttachList: [], // 删除 附件
      searchKey: '',
      tabValue: '0',
      isElectronicSignature: false, // 电子签章
    };
  },
  computed: {

    // 精确计算
    numberUtilComputed() {
      return (key, val1, val2) => {
        return NumberUtil[key](val1, val2)
      }
    },

    totalCountCompured() {
      return (item, key) => {
        key = key || 'requireCount'
        let total = 0
        item.details.forEach(f => {
          total = this.numberUtilComputed('numAdd', total, Number(f[key]))
        })
        return total
      }
    },
    selectCount() {
      let count = 0
      this.goodsList.forEach(f => {
        if (f.details && f.details.some(f1 => {return f1.select})) {
          count++
        }
      })
      return count
    },
    computedReqCount() {
      return function (details) {
        let num = 0;
        details.forEach(i => {
          num = NumberUtil.numAdd(+i.requireCount, +num)
        })
        return String(num)
      }
    },
    title() {
      let str = "发货";
      str += " - 第" + (this.orderInfo.requireBatchNo || "") + "批";
      return str;
    },
    userInfo() {
      return this.$store.state.userInfo;
    },
    role() {
      return this.$store.state.userInfo
        ? this.$store.state.userInfo.bs
        : 0;
    },

    events() {
      const events = [];
      let acctIdList = [];
      if (this.userInfo.accountList.length) {
        this.userInfo.accountList.forEach(item => {
          acctIdList.push(item.acctId)
        })
      } else {
        acctIdList.push(this.userInfo.acctId)
      }
      const eventList = filterEventByAcct(this.orderInfo.eventList, 2, acctIdList);
      console.log(eventList, '----签章eventList');

      eventList.forEach(item => {
        if (
          item.eventType == 2 &&
          (item.eventStatus == 0 || item.eventStatus == 1)
        ) {
          events.push(item);
        }
      })
      console.log(events);
      return events
    }
  },
  methods: {
    async  handleClickSearchSubmit() {
      this.pageIndex = 1
      this.recordChecked();
      // 非电子签章才保存
      !this.isElectronicSignature && await this.handleClickSaveSignRecipt(true)
      this.getSignReciptDetail()
    },
    async handleClickSearchResult() {
      this.tabValue = '0'
      this.searchKey = ''
      this.handleClickSearchSubmit()
    },
    handleDelOtherFile(file, index) {
      if (file.attachId) {
        this.delOtherAttachList.push({
          attachId: file.attachId,
          attachOperFlg: "Del",
        })
      }
      this.deliveryAttachList.splice(index, 1)
    },

    // 批量下载其他附件
    handleOtherDownload() {
      console.log(this.deliveryAttachList, '-deliveryAttachList');
      if (!(this.deliveryAttachList && this.deliveryAttachList.length)) return
      let fileInfoBeans = []

      this.deliveryAttachList.forEach(f => {
        fileInfoBeans.push({
          archivePath: f.attachName,
          fileUrl: f.attachUrl
        })
      })

      this.packageDownload(fileInfoBeans, '其他附件.zip')

    },
    handleDownloadFile(f) {
      this.$download([{
        name: f.attachName || '',
        url: f.viewUrl || f.attachUrl || ''
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 批量下载验收单
    handleBatchDownload(item) {
      console.log(item);
      if (!(item && item.details)) return
      let fileInfoBeans = []

      // .reverse() 无效
      item.details.forEach(f => {
        f.acceptanceAnnexAttachList && f.acceptanceAnnexAttachList.some(s => {
          let archivePath = `${f.label}/`
          archivePath += s.attachName
          fileInfoBeans.push({
            archivePath,
            fileUrl: s.attachUrl
          })
        })
      })
      console.log(fileInfoBeans, '-fileInfoBeans');

      this.packageDownload(fileInfoBeans, `${item.skuName || '打包下载附件'}.zip`)
    },

    packageDownload(fileInfoBeans, fileName) {
      if (!(fileInfoBeans && fileInfoBeans.length)) return
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
      };
      InterfaceService.packageDownload(
        params,
        data => {          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            const files = [
              { name: fileName, url: res.externalFileUrl }
            ];
            this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
              this.$message.success("已下载");
            })
            this.dialogVisible = false;
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },

    handleGoproduct(item) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: item.spuId,
          skuId: item.skuId,
          corpId: this.orderInfo.supplierId,
        }
      }).href, '_blank')
    },

    handleDelFile(dItme, aItem, index) {
      console.log(dItme, aItem, '-删除');

      if (aItem.attachId) {
        this.delAttachList.push({
          deliveryDetailId: aItem.deliveryDetailId,
          attachId: aItem.attachId,
          attachOperFlg: "Del",
        })
      }
      dItme.acceptanceAnnexAttachList.splice(index, 1);
    },
    handleClickAcceptance() {
      this.goodsList.forEach(f => {
        // f.select = this.selectAll
        f.details && f.details.filter(i => { return i.select }).forEach(f1 => {
          f1.checkDescription = this.acceptanceAll
        })
      })
    },
    handleChangeSelectAll() {
      console.log(this.goodsList);
      this.goodsList.forEach(f => {
        f.select = this.selectAll
        f.details && f.details.forEach(f1 => {
          f1.select = this.selectAll
        })
      })
    },



    handleChangeParentSelect(item) {
      console.log(item, '--item');

      item.details && item.details.forEach(f1 => {
        f1.select = item.select
      })
      this.isSelectAll()
    },

    handleChangeDetailSelect(item) {
      console.log(item);
      this.goodsList.forEach(s => {
        if (s.orderDetailId == item.orderDetailId) {
          s.select = s.details && s.details.every(e => e.select)
          console.log(s.select);
          // return true
        }
      })
      this.isSelectAll()
    },

    isSelectAll() {
      this.selectAll = this.goodsList.every(e => e.details && e.details.every(e1 => e1.select)) && this.goodsList.every(e => e.select)
    },

    getAttachInfo(info) {
      console.log(info);
      this.goodsList.filter(i => { return !i.hidden }).forEach((item, ind) => {
        if (item.details && item.details.filter(i => { return i.operFlg !== 'Del' }).length) {
          item.details.filter(i => { return i.operFlg !== 'Del' }).forEach((_item, _ind) => {
            if (!_item.acceptanceAnnexAttachList) {
              this.$set(_item, 'acceptanceAnnexAttachList', []);
            }
            if (info.fromId == _item.requireDetailId) {
              let onOff = false;
              this.$set(_item, 'label', '标段' + (_ind + 1));
              _item.acceptanceAnnexAttachList.push({
                attachUrl: info.attachPath,
                attachName: info.attachName,
                viewUrl: info.attachUrl,
                attachOperFlg: 'Add',
                attachId: '',
                attachType: '2', // 单个商品
              })
            }
            item.details.filter(i => { return i.operFlg !== 'Del' }).forEach((i, index) => {
              i.label = '标段' + (index + 1)
            })
          })
        }
      })

      console.log(this.goodsList);
    },
    getAttachInfoOther(info) {
      this.deliveryAttachList.push({
        attachName: info.attachName,
        viewUrl: info.attachUrl,
        attachUrl: info.attachPath,
        attachType: '3',
        attachOperFlg: 'Add',
      })
      console.log(info);
    },
    checkNum(value, item, type, allItem, negative) {
      // if (negative) {
      //   // 负数
      //   value = value.replace(/[^\d.-]/g, ""); //清除"数字"和"."以外的字符
      // } else {
      //   value = value.replace(/[^\d.]/g, ""); //清除"数字"和"."以外的字符
      // }
      value = value.replace(/^\./g, ""); //验证第一个字符是数字
      value = value.replace(/\.{2,}/g, "."); //只保留第一个, 清除多余的
      // value = value.replace(/-{2,}/g,""); //只保留第一个, 清除多余的
      if (value.length > 1 && value[value.length - 1] == '-') {
        value = value.substring(0, value.length - 1)
      }
      value = value.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
      value = value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); //控制可输入的小数
      if (type == 'receiveCount') {
        console.log(value, value.length);
        if (value.indexOf(".") == -1 && value.length == 10) {
          console.log(value, value.length);
          console.log(value[9]);
          if (value[9] != '.') {
            value = value.substring(0, value.length - 1)
          }
        }
        let thisTimeCnt = allItem ? this.totalCountCompured(allItem) : item.requireCount
        if(value > +thisTimeCnt){
          this.$set(item, 'errorMsg', '※验收数量不得超过要货量')
          value = '0'
        }else{
          this.$set(item, 'errorMsg', '')
        }
      }
      item[type] = value;
      // console.log(value);
      // console.log(item[type]);
    },
    handleGoodsDetailDia(item) {
      console.log(item, '0-item');
      item.corpId = this.orderInfo.supplierId
      this.$refs.goodsDetailDialog.open(item, 'checkGoods')
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.acceptanceAll = ''
      this.selectAll = false
      this.recordChecked();
      // 非电子签章 才保存
      !this.isElectronicSignature && this.handleClickSaveSignRecipt(true)
      this.isElectronicSignature && this.getSignReciptDetail()
    },

    async handleClickSaveSignRecipt(isConfirm) {
      return new Promise(async (resolve) => {
        let deliveryList = []

        this.goodsList.forEach(f => {
          f.details.some(s => {
            const item = {
              skuId: s.skuId, // 	String	SKU ID
              requireDetailId: s.requireDetailId, // 	String	要货单详情ID
              deliveryDetailId: s.deliveryDetailId, // 	String	验收单详情ID
              receiveCount: s.receiveCount, // 	String	实收数量
              checkDescription: s.checkDescription, // 	String	验收情况
              deliveryCount: s.deliveryCount, // 	String	供货数量
              attachList: []
            }
            if (s.acceptanceAnnexAttachList && s.acceptanceAnnexAttachList.length) {
              s.acceptanceAnnexAttachList.map(m => {
                // 删除 附件 list, 标识删除附件, 后删除 删除list
                for (let index = this.delAttachList.length - 1; index >= 0; index--) {
                  const dItem = this.delAttachList[index]
                  if (+dItem.deliveryDetailId == +m.deliveryDetailId) {
                    item.attachList.push(dItem)
                    this.delAttachList.splice(index, 1)
                  }
                }
                // 非 删除 添加 则 不组装
                if (!m.attachOperFlg) return
                const attachItem = {
                  attachId: m.attachId, //	String	附件ID（新加入时不传值, 删除时必须传值）
                  attachName: m.attachName, //	String	附件名称
                  attachUrl: m.attachUrl, //	String	附件url
                  attachOperFlg: m.attachOperFlg, //	String	操作标识("Add:新加入;Del:删除")
                  attachType: m.attachType, //	String	附件标识("0：要货单明细附件；1：要货单附件；2：交割单明细附件；3：交割单附件")
                }

                item.attachList.push(attachItem)
              })
            }

            deliveryList.push(item)
          })
        })

        resolve(await this.saveSignRecipt(deliveryList, isConfirm))
      })
    },

    // 保存验收单
    saveSignRecipt(deliveryList, isConfirm) {
      return new Promise(resolve => {
        const deliveryAttachList = this.deliveryAttachList.concat(JSON.parse(JSON.stringify(this.delOtherAttachList))) || []

        const params = {
          deliveryNo: this.deliveryNo || '',
          deliveryAttachList: deliveryAttachList.filter(f => f.attachOperFlg),
          deliveryList: deliveryList,
        };
        InterfaceService.saveSignRecipt(params, data => {
          if (data.respData.respCode === "0000") {
            this.delOtherAttachList = []
            // isConfirm 走提交 不用再查询数据 和 提示信息
            this.getSignReciptDetail()
            !isConfirm && this.$message.success("保存成功");
            resolve(true)
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },

    handleClickSubmitConfirm() {
      // 因为无法判断其他页 验收情况 直接按全部签收 提示提醒,  后台会返回提示信息
      const html = `<p class='txt-left'>提交后将通知相关授权代表来签章验收。请确认已全部验收本批次要货单。</p>`
      this.$confirm(`${html}`, '验收商品确认', {
        dangerouslyUseHTMLString: true,
        customClass: 'qconfirmMessageBoxContainer',
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        closeOnClickModal: false,
        closeOnPressEscape: false,
        confirmButtonText: "确认并提交",
        cancelButtonText: '待供方补货',
      }).then(async () => {
        await this.handleClickSaveSignRecipt(true)
        this.handleSubmitComfirm()
      }).catch(() => {

      })
    },

    handleSubmitComfirm() {
      this.signReciptConfirm()
    },

    // 合同签章完成
    handleCloseSignature(ev) {
      console.log(ev, 'ev');
      if (!ev) return
      this.$router.push({
        path: '/resultsFeedback',
        query: {
          type: `${this.isElectronicSignature ? 'sign' : 'create'}Acceptance`,
          requireNo: this.requireNo,
        }
      })
      window.opener && window.opener.location.reload();
    },

    // 提交验收单
    signReciptConfirm(check) {
      const params = {
        deliveryNo: this.deliveryNo || '',
        isNeedReplenishment: '0', // 	String	是否需要补货("0:不需要;1:需要")
        check
      };
      InterfaceService.signReciptConfirm(params, data => {
        if (data.respData.respCode === "0000") {
          this.delOtherAttachList = []
          // this.handleCloseSignature(true)
          this.$router.push({
            path: '/requireOrderDetail',
            query: {
              requireNo: this.requireNo,
              orderNo: this.orderInfo.orderNo,
              corpId: this.orderInfo.supplierId,
            }
          })
          setTimeout(()=>{
            this.$message.success('提交验收单成功，请签署验收单')
          },3000)
        } else {
          if (data.respData && data.respData.respCode === "TRANS0463") {
            const html = `<p class='red txt-left'>您有未验收确认的商品，请确认（验收的商品有多页请检查）。</p>`
            this.$confirm(`${html}`, '验收商品确认', {
              dangerouslyUseHTMLString: true,
              customClass: 'qconfirmMessageBoxContainer',
              cancelButtonClass: "btn-custom-cancel",
              confirmButtonClass: "btn-custom-confirm",
              center: true,
              closeOnClickModal: false,
              closeOnPressEscape: false,
              confirmButtonText: "确认无误提交",
              cancelButtonText: '取消',
            }).then(() => {
              this.signReciptConfirm(true)
            }).catch(() => {

            })
            return
          }
          this.$message.error(data.respData && data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },


    // 获取要货单详情
    getRequireOrderDetail() {
      const params = {
        requireNo: this.requireNo,
        pageIndex: this.pageIndex
      };
      InterfaceService.getRequireOrderDetail(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.orderInfo = data.respData || {};
            this.systemTime = data.systemTime;

            this.expressCompanyList.forEach(item => {
              if (
                item.expressCode ==
                this.orderInfo.expressCompany
              ) {
                this.orderInfo.expressCompanyName =
                  item.expressName;
              }
            })
            // this.isElectronicSignature = this.checkEventRole(2) != 'unfinish'
            this.getSignReciptDetail();
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },

    // 检查角色事件
    checkEventRole(type) {
      let status = null;
      if (this.orderInfo && this.orderInfo.eventList) {
        let acctIdList = [];
        if (this.userInfo.accountList.length) {
          this.userInfo.accountList.forEach(item => {
            acctIdList.push(item.acctId)
          });
        } else {
          acctIdList.push(this.acctId)
        }
        const events = filterEventByAcct(this.orderInfo.eventList, type, acctIdList);
        events.forEach(ev => {
          if (ev.eventType == type) {
            if (ev.processList && ev.processList.length) {
              status = status || "finish";
              ev.processList.forEach(process => {
                if (process.processFlg == 0) {
                  status = "unfinish";
                }
              });
            }
          }
        });
      }
      return status;
    },

    recordChecked() {
      this.goodsList.forEach(item => {
        item.details.forEach(det => {
          this.storageGoodsList.forEach(_item => {
            if (det.id === _item.id) {
              _item.deliveryCount = item.deliveryCount
            }
          })
        })
      })
    },

    handleSign() {
      let events = this.events;
      console.log(events, '-handleSign');

      this.$refs["signature"].open(events);
    },

    // 获取验收单详情
    getSignReciptDetail() {
      const params = {
        deliveryNo: this.deliveryNo,
        pageIndex: this.pageIndex,
        searchKey: this.searchKey,
        tabValue: this.tabValue == '0' ? '' : this.tabValue
      }
      InterfaceService.getSignReciptDetail(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.goodsList = [];

            let attachList = data.respData.attachList || [];
            JSON.parse(JSON.stringify(data.respData.deliveryList || [])).forEach(item => {
              let onOff = false;
              this.goodsList.forEach(g => {
                if (+g.orderDetailId == +item.orderDetailId) {
                  onOff = true
                }
              })
              if (!onOff) {
                this.goodsList.push(item)
              }
            })
            this.goodsList.forEach(g => {
              this.$set(g, 'details', [])
              this.$set(g, 'select', false)
              // this.$set(g, 'errorMsg', '')
              JSON.parse(JSON.stringify(data.respData.deliveryList || [])).forEach((item, idx) => {
                if (+g.orderDetailId == +item.orderDetailId) {
                  item.sectionList.some(s => g.location = s.location)
                  item.sectionList.forEach((f, sIdx) => {
                    f.label = `标段${sIdx + 1}`
                    f.acceptanceAnnexAttachList = [] // 验收附件
                    f.attachList = [] // 验收附件
                    f.model = item.model
                    f.orderDetailId = item.orderDetailId
                    // 如果本次实收数量为 null 说明 没有填写过  数量初始化 本批次供货量
                    f.receiveCount = f.receiveCnt === null ? f.thisTimeCnt : f.receiveCnt
                    f.select = false
                  })
                  g.details = item.sectionList
                  g.details.forEach(i=> {
                    this.$set(i, 'errorMsg', '')
                  })
                }
              })
            })
            this.deliveryAttachList = []
            attachList.forEach(att => {
              // 其他附件
              if (+att.attachType === 3) {
                this.deliveryAttachList.push(att)
              }
            })

            this.goodsList.forEach((item, ind) => {
              attachList.forEach(att => {
                item.details.forEach((_item, _ind) => {
                  _item.label = '标段' + (_ind + 1)
                  if (+att.requireDetailId === +_item.requireDetailId) {
                    _item.attachList.push({
                      attachUrl: att.attachUrl,
                      attachName: att.attachName,
                      viewUrl: att.attachUrl,
                      requireDetailId: att.requireDetailId,
                      attachOperFlg: 'Update',
                      attachId: att.attachId,
                      attachType: att.attachType,
                    })
                  }

                  // 验收附件
                  if (+att.deliveryDetailId === +_item.deliveryDetailId) {
                    _item.acceptanceAnnexAttachList.push(att)
                  }
                })
              })
            })
            this.pageSize = data.respData.pageSize;
            this.total = data.respData.totalCount;
            this.$nextTick(() => {
              this.goodsList.forEach((item, index) => {
                this.$set(item, 'firstTdHeight', this.$refs['goodsHeight' + index][0].offsetHeight + 28)
              })
            })
            this.goodsList.forEach(_item => {
              _item.details.forEach(det => {
                let onOff = false;
                this.storageGoodsList.forEach(item => {
                  if (item.id === det.id) {
                    onOff = true;
                  }
                })
                if (!onOff) {
                  this.storageGoodsList.push(det)
                }
              })
            })

            console.log(this.goodsList, 'initGoodsList');
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    init() {
      this.getRequireOrderDetail();
    }
  },
  mounted() {

    this.requireNo = this.$route.query.requireNo;
    this.operType = this.$route.query.type || '';
    this.isElectronicSignature = this.$route.query.isElectronicSignature == 1;
    console.log(this.isElectronicSignature, '--this.isElectronicSignature');
    this.breadcrumb = [
      { name: '管理中心', path: this.userInfo.bs == 'B' ? '/purchaserCenter/accountInfo' : '/vendorCenter/accountInfo' },
      { name: '交易管理', path: this.userInfo.bs == 'B' ? '/purchaserCenter/orderList' : '/vendorCenter/orderList', },
      { name: '材料管理', path: this.userInfo.bs == 'B' ? '/purchaserCenter/requireOrderList' : '/vendorCenter/requireOrderList' },
      { name: `${this.isElectronicSignature ? '签署' : this.operType === 'edit' ? '编辑' : '创建'}验收单` },
    ];
    this.deliveryNo = this.$route.query.deliveryNo;
    this.init();
  }
};
</script>
<style lang="scss" scoped>
.link {
  text-decoration: underline;
  cursor: pointer;
  color: #0082ff;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }
}

.red-font {
  color: #e94650;
}

.nowrap {
  white-space: nowrap;
}

.btn-top {
  width: 100px;
}

.btn-bottom {
  width: 150px;
}

.inner-container {
  margin-bottom: 100px;
  font-size: 14px;
}

.order-info {
  margin-bottom: 20px;
  line-height: 30px;
  font-size: 12px;
  table {
    tr {
      td {
        p {
          margin-bottom: 0;
        }
      }
    }
  }
  p {
    padding-right: 10px;
    word-break: break-word;
    white-space: normal;

    & > span {
      display: inline-block;
      flex: 1 1 0%;
    }
  }

  label {
    white-space: nowrap;
    color: #888888;
  }
}

.cut,
.add {
  display: inline-block;
  width: 28px;
  height: 33px;
  background: white;
  text-align: center;
  line-height: 33px;
  border: 1px solid #dddddd;
  cursor: pointer;
  vertical-align: middle;
  user-select: none;
}

.cut.grey,
.add.grey {
  cursor: not-allowed;
  background: #eeeeee;
}

.add {
  margin-left: -3px;
}

.cut {
  margin-right: -3px;
}
.go-blue:hover {
  color: #0082ff;
  text-decoration: underline;
  cursor: pointer;
}
.required {
  &::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
.list-content {
  width: 1190px;
  margin: 0 auto 20px;
  table {
    table-layout: fixed;
    width: 100%;
    line-height: 17px;
    font-size: 12px;
    td {
      table {
        td {
        }
      }
      padding: 15px 5px;
      vertical-align: middle !important;
      word-break: break-all;
      position: relative;
      .error-msg {
        position: absolute;
        right: 10px;
        margin-top: 6px;
      }
      .add-flg {
        position: absolute;
        left: 10px;
        margin-top: 6px;
      }
      .thumbnail {
        width: 60px;
        height: 60px;
        background: #eee;
      }
      .goods-name {
        width: 100%;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
      }
      .fixed,
      .new-goods {
        position: relative;
        overflow: hidden;
        width: 100px;
        margin-top: 6px;
        height: 20px;
        line-height: 20px;
        background: #6598d3;
        text-align: center;
        font-size: 14px;
        color: #fff;
        border-radius: 2px;
      }
      .new-goods {
        background: #ff7d1d;
        .triangle-topright {
          width: 28px;
          height: 70px;
          position: absolute;
          background: #313131;
          top: -54px;
          right: -50px;
          -webkit-transform: rotate(45deg);
          transform: rotate(45deg);
        }
      }
      i {
        position: absolute;
        right: 16px;
        top: 50%;
        margin-top: -9px;
      }
      > p {
        line-height: 17px;
        & + p {
          margin-top: 4px;
        }
      }
    }
    .pt38 {
      padding-top: 38px !important;
    }
    thead {
      font-size: 14px;
      text-align: left;
      white-space: nowrap;
      background: #f9f9f9;
      color: #888;
      border-bottom: 1px solid #eee;
    }
    .tbody-row tr {
      &:hover {
        background: #f0f8ff;
      }
    }
    tbody {
      text-align: left;

      border-bottom: 1px solid #eee;
      tr {
        .tr {
          p {
            display: block;
          }
        }
      }
      .border-none {
        border-bottom: none;
      }
      .material-description {
        td {
          /deep/ .el-input {
            input {
              height: 34px;
            }
          }
        }
      }
    }
  }
}
/deep/ .right_padding {
  .el-input__inner {
    padding-right: 30px;
    height: 32px;
    line-height: 32px;
  }
  .suffix {
    width: 68px;
    text-align: right;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: #444;
    margin-right: 4px;
    line-height: 32px;
  }
}
.form-response-item {
  margin-top: -10px;
  /deep/ .el-input {
    width: 400px;
    input {
      height: 32px;
      line-height: 32px;
    }
  }
}
.opt {
  padding-right: 10px;
  text-align: right !important;
  p {
    padding-right: 0 !important;
  }
}
.colorFF7D1D {
  color: #ff7d1d;
}
.color9452FF {
  color: #9452ff;
}
.details-tr {
  &.dItemCheckDescription {
    td {
      padding-bottom: 68px !important;
    }
  }
  td {
    label {
      margin-left: 6px;
    }
  }
}
.notice {
  position: absolute;
  right: 0;
}
.pr4 {
  padding-right: 4px !important;
}
.foot-fix-container {
  display: flex;
  justify-content: space-between;
  &.center {
    justify-content: center;
  }
  .left-container {
    width: 700px;
    display: flex;
    align-items: center;
    label {
      display: flex;
      align-items: center;
    }
    span {
      white-space: pre;
      color: #fff;
      margin-left: 12px;
    }
    /deep/ .el-input {
      margin-left: 40px;
      margin-right: 12px;
      width: calc(100% - 320px);
      .el-input__inner {
        height: 34px;
        line-height: 34px;
      }
    }
  }
}

.text-textarea {
  position: absolute;
  width: calc(100% + 490px);
  margin-top: 28px;
  z-index: 1;
}
.unLocation {
  td {
    padding-bottom: 80px !important;
  }
  .text-textarea {
    width: calc(100% + 490px);
    margin-top: 82px;
  }
  // 电子签章的
  &.isElectronicSignature {
    td {
      padding-bottom: 18px !important;
    }

    .text-textarea {
      margin-top: 18px;
    }
    // 有验收情况的
    &.checkDescription {
      td {
        padding-bottom: 60px !important;
      }
      .text-textarea {
        &.parent-text-textarea {
          &::before {
            content: "";
            position: absolute;
            left: -80px;
            top: -14px;
            border-top: 1px dashed #eee;
            width: calc(100% + 234px);
          }
        }
        margin-top: 92px;
        span {
          margin-left: -77px;
          margin-right: 16px;
        }
      }
    }
  }
}

.enclosure-content {
  width: 1190px;
  background: #ffffff;
  border: 1px solid #dddddd;
  padding: 10px;
  line-height: 17px;
  font-size: 12px;
  margin-top: 6px;
}
.colorC99F4F {
  color: #c99f4f;
}
.attr-list-tr {
  .flex-vtop {
    display: flex;
    align-items: flex-start;
  }
  &.children-tr {
    &:last-child {
      border-bottom: 0;
    }
  }
  &.isElectronicSignature {
    border-bottom-style: dashed;
    &.tdPb14 {
      td {
        padding-bottom: 14px;
      }
    }
    td {
      &.va-t {
        vertical-align: top !important;
      }
      padding-bottom: 32px;
      .text-textarea {
        margin-top: 4px;
      }
    }
    li {
      span {
        color: #333;
        background: transparent;
        padding-right: 36px;
        margin-right: 22px;
        i {
          right: 0;
        }
        em:hover {
          font-weight: 100;
          text-decoration: dashed;
        }
      }

      font {
        font-weight: bold;
      }
    }
  }
  td {
    &.download-file {
      padding: 0 !important;
      p {
        padding: 0 !important;
      }
    }
    ul {
      li {
        margin-bottom: 10px;
        &:last-child {
          margin-bottom: 0;
        }
        font {
          margin-right: 4px;
        }
        span {
          position: relative;
          display: inline-block;
          background: #c99f4f;
          color: #fff;
          padding: 4px 18px 4px 4px;
          margin-right: 4px;
          margin-bottom: 1px;
          em:hover {
            // font-weight: 600;
            cursor: pointer;
            text-decoration: underline;
          }
          .el-icon-close {
            right: 3px !important;
            top: 17px !important;
          }
        }
      }
    }
  }
}
.search-container {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-size: 14px;
  color: #888888;
  white-space: pre;
  &.fix-search-container {
    margin-top: 10px;
    color: #fff;
  }
  .left {
    width: 49%;
    align-items: center;
    display: flex;
    span {
      margin-right: 4px;
    }
    .el-input {
      width: calc(100% - 90px);
    }
  }
  .right {
    width: 45%;
    align-items: center;
    display: flex;
    justify-content: space-between;
    .btn-contaier {
      .el-button {
        padding: 6px 20px !important;
        font-size: 12px;
      }
    }
  }
  /deep/ .el-input__inner {
    height: 34px !important;
    line-height: 34px !important;
    padding: 0 8px !important;
  }
}
.check-file {
  // margin-left: 12px;
}
.del-other-file-btn {
  padding-left: 6px;
}
/deep/ .el-pagination__editor.el-input .el-input__inner {
  height: 28px !important;
}
.bgfff {
  background: #fff;
}
.product-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
</style>
<style lang="scss">
.content {
  min-width: 1190px;
}
</style>
