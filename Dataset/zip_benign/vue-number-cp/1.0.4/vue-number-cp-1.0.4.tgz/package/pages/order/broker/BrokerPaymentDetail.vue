<template>
    <div>
        <div class="unShowPrint">

        <Header :is-white-bg="false"></Header>
        <SearchBar :search-type="5" :progress="'详情页'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
        <div class="inner-container">
            <!-- 合同流程 -->
            <OrderProcess v-if="approvalInfo.approveFlowList" :isApproval="true" :orderStatus="approvalInfo.orderStatus" :processList="approvalInfo.approveFlowList"></OrderProcess>
             <!--合同状态 -->
            <ApprovalStatusInfo :type = "'payment'" :executionId="executionId" :approvalInfo="approvalInfo" :fwStatus="fwStatus" :canFwRoleList="canFwRoleList" @refresh="handleRefreshStatus" @dandleClickPrint="dandleClickPrint" @close="closeWindow"></ApprovalStatusInfo>
            <PanelTitle :tabs="tabs" @select="handleSelectTab" class="panel-title"></PanelTitle>
            <div class="order-info" v-if="tab == '1'">
                <!--<span v-if="executionId" class="blue pointer download"  @click="handleBatchDownload()">审批资料查看及下载</span>-->
                <el-row>
                    <el-col :span="8">
                        <p>
                            <label>合同编号：</label>{{approvalInfo.orderNo}}
                        </p>
                    </el-col>
                    <el-col :span="16">
                        <p>
                            <label>合同名称：</label>
                            <span>
                                <span :class="{'blue':hasOrderNo,'hand':hasOrderNo}" @click="handleContractDetail()">《{{approvalInfo.contractName}}》</span>
                                <!--<span v-if="executionId" class="blue pointer"  @click="handleBatchDownload()">审批资料下载</span>-->
                             </span>
                        </p>
                    </el-col>
                </el-row>
                <!--<el-row v-if="role==='B'" v-for="(item,index) in filterERP(approvalInfo.externalSysList)" :key="index">-->
                <el-row>
                    <el-col :span="8">
                        <label>城市公司：</label>{{approvalInfo.cityCompany}}
                    </el-col>
                    <el-col :span="8">
                        <label>供应商：</label>{{approvalInfo.supplierName}}
                    </el-col>
                    <!--<el-col :span="8">-->
                        <!--<label>请款次数：</label>{{approvalInfo.orderTaxRateRange}}-->
                    <!--</el-col>-->
                </el-row>
                <el-row>
                    <el-col :span="8">
                        <label>项目名称：</label>{{approvalInfo.projectName}}
                    </el-col>
                    <el-col :span="8">
                        <label>ERP请款编号：</label>{{approvalInfo.erpBusiCode}}
                    </el-col>
                    <el-col :span="8">
                        <label>发起时间：</label>{{approvalInfo.signTime}}
                    </el-col>
                </el-row>
                <div class="line"></div>
                <div class="order-info-title">合同价款
                    <span style="margin-left: 10px;" v-if="startFlag && approvalInfo.canEditOrderAmount == '0'" class="blue pointer" @click="handleEditPaymentInfo('tax')">编辑</span>
                </div>
                <table class="tax" >
                    <tr>
                        <td>合同价款（不含税）：{{approvalInfo.outContractFee | formatMoney}}元</td>
                        <td>税率：{{approvalInfo.orderTaxRateRange}}</td>
                        <td>&nbsp;</td>
                        <!--<td rowspan="2" align="center" class="add-tax">加价费率：<em class="red" style="font-size: 22px;">{{approvalInfo.addRate|percent}}</em></td>-->
                    </tr>
                    <tr>
                        <td class="bold">合同价款（含税）：<em class="red">{{approvalInfo.outContractFeeWithTax | formatMoney}}元</em></td>
                        <td>税额：{{approvalInfo.outContractTax | formatMoney}}元</td>
                        <td>&nbsp;</td>
                    </tr>
                </table>
                <div class="order-info-title">请款明细
                    <span style="margin-left: 10px;" v-if="startFlag" class="blue pointer" @click="handleEditPaymentInfo('payment')">编辑</span>
                </div>
                <table class="tax" >
                    <tr>
                        <td colspan="3">请款事由：{{approvalInfo.paymentType}}</td>
                    </tr>
                    <tr>
                        <td>本期产值：{{pmtBusiInfo.thisOutputValue | formatMoney}}元</td>
                        <td>累计完成产值：{{pmtBusiInfo.totalOutputValue | formatMoney}}元</td>
                        <td>累计应付未付款：{{pmtBusiInfo.totalPayableAmt | formatMoney}}元</td>
                    </tr>
                    <tr>
                        <td>累计应付：{{pmtBusiInfo.totalPayablesAmt | formatMoney}}元</td>
                        <td>累计已付：{{pmtBusiInfo.totalPaidAmt | formatMoney}}元</td>
                        <td v-if="pmtBusiInfo.orderAuditAmt">合同结算金额：{{pmtBusiInfo.orderAuditAmt | formatMoney}}元</td>
                        <td v-else>合同结算金额：--元</td>
                    </tr>
                    <tr style="border-top: 1px solid #fff" v-if="approvalInfo.pmtMethod || approvalInfo.paymentDescribe">
                        <td colspan="3" class="payment-method">付款条款：<p><span v-html="approvalInfo.pmtMethod || approvalInfo.paymentDescribe"></span></p></td>
                    </tr>
                    <tr style="border-top: 1px solid #fff">
                        <td colspan="3">本次申请金额：<span class="red"><em style="font-size: 16px">{{pmtBusiInfo.payablesAmtApply | formatMoney}}</em>元</span></td>
                    </tr>
                </table>
                <div class="note" v-if="operateApproval">
                    <el-row style="border-bottom: 1px solid #fff;" v-for="(note,index) in remarkList" :key="index">
                        <el-col :span="20">
                            {{index+1}}、{{note.remark}}
                        </el-col>
                        <el-col :span="2">
                            <em class="grey">{{note.remarkDt}}</em>
                        </el-col>
                        <el-col :span="2">
                            <span @click="handleEditNote(note,'1')">编辑</span>
                            <span @click="handledelNote(note,'0')" style="padding-left: 10px;">删除</span>
                        </el-col>
                    </el-row>
                    <div class="edit-note">
                        <span @click="handleEditNote()"><i class="el-icon-plus"></i>添加记录</span>
                    </div>
                </div>
                <div class="line" v-if="pmtBusiInfo.thisReceiptAmt|| pmtBusiInfo.totalReceiptAmt || startFlag"></div>
                <div class="order-info-title" v-if="pmtBusiInfo.thisReceiptAmt|| pmtBusiInfo.totalReceiptAmt || startFlag">开票情况
                    <span v-if="startFlag" style="margin-left: 10px;" class="blue pointer" @click="handleEditPaymentInfo('invoice')">编辑</span>
                </div>
                <!--<el-row>-->
                    <!--<el-col :span="8" v-if="pmtBusiInfo.thisReceiptAmt|| startFlag">-->
                        <!--<label>本次发票金额：</label>{{pmtBusiInfo.thisReceiptAmt| formatMoney}}元-->
                    <!--</el-col>-->
                    <!--<el-col :span="8" v-if="pmtBusiInfo.totalReceiptAmt || startFlag">-->
                        <!--<label>累计发票金额：</label>{{pmtBusiInfo.totalReceiptAmt | formatMoney}}元-->
                    <!--</el-col>-->
                <!--</el-row>-->
                <div class="line"></div>
                <div class="order-info-title">供应商账户信息
                    <span v-if="startFlag" style="margin-left: 10px;" class="blue pointer"@click="handleEditPaymentInfo('account')">编辑</span>
                </div>
                <el-row class="bold">供应商账户信息</el-row>
                <el-row>
                    <el-col :span="8">
                        <label>开户名称：</label>{{corpFinInfo.acctName}}
                    </el-col>
                    <el-col :span="8">
                        <label>开户行行号：</label>{{corpFinInfo.bankCode | formatCardNum}}
                    </el-col>
                    <el-col :span="8">
                        <label>联系人：</label>{{corpFinInfo.contact}}
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="8">
                        <label>开户银行：</label>{{corpFinInfo.bankName}}
                    </el-col>
                    <el-col :span="8">
                        <label>银行账号：</label><em class="red">{{corpFinInfo.bankAcct | formatCardNum}}</em>
                    </el-col>
                    <el-col :span="8">
                        <label>联系方式：</label>{{corpFinInfo.phoneNo | formatPhoneNumber("3 4 4")}}
                    </el-col>
                </el-row>
                <el-row class="bold" style="margin-top: 6px;">付款方账户信息</el-row>
                <el-row>
                    <label>付款单位</label>：{{corpFinInfo.pmtCorpName}}
                </el-row>
                <PaymentApprovalInDetail :executionId="executionId" :procDefKey="procDefKey" :approvalInfo = approvalInfo :status = approvalInfo.operateStatus @refresh="refreshDetail" @close="closeWindow"></PaymentApprovalInDetail>
            </div>
        </div>
        <!--新增，编辑记录-->
        <el-dialog class="dialog" title="记录" :append-to-body="true" :lock-scroll="true" :visible.sync="noteDialogVisible" width="800px" center :close-on-click-modal="false">
            <!--<div class="line-top"></div>-->
            <el-input style="padding: 30px 0;border-top: 1px solid #eee;" type="textarea" class="textareaContainer" v-model="remark" placeholder="请输入内容,500字以内" clearable :maxlength="500" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 500}"> {{entryNum}}</span>/ 500
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button :disabled="!remark" type="primary" size="small" style="width: 100px" @click="handleConfirmRemark()">提交</el-button>
                <el-button size="small" style="width: 100px" @click="noteDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <FixBottom v-if="fixedBottomActive && approvalButton">
            <div class="fix-bottom" v-if="approvalButton">
                <el-button type="primary" style="width: 120px;" @click="batchApproavlDialogVisible=true">同意</el-button>
                <el-button style="width: 120px;" @click="rejectedDialogVisible=true">退回</el-button>
                <el-button style="width: 120px" @click="handleCloseWindow()">返回列表</el-button>
            </div>
        </FixBottom>
        <!-- 确认审批 -->
        <el-dialog class="dialog" title="请款审批" :append-to-body="true" :lock-scroll="true" :visible.sync="batchApproavlDialogVisible" width="840px" center :close-on-click-modal="false" :show-close="false"  @close="entryNum = 0;comment = ''">
            <div class="f14" style="text-align: center;padding-top: 15px;border-top: 1px solid #eee;">确认通过此合同请款审批吗？</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="comment" placeholder="请填写审批意见，300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm('Y')">同意</el-button>
                <el-button size="small" style="width: 100px" @click="batchApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--审批退回-->
        <el-dialog class="dialog padding10Dialog" title="退回原因" :append-to-body="true" :lock-scroll="true" :visible.sync="rejectedDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;rejectedReason = ''">
            <div class="f14" style="text-align: left;padding-top: 15px;border-top: 1px solid #eee;">请填写退回的原因</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="rejectedReason" placeholder="请填写退回的原因，300字以内" clearable  :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
            <el-button type="primary" :disabled="!rejectedReason" size="small" style="width: 100px" @click="handleConfirm('N')">退回</el-button>
            <el-button size="small" style="width: 100px" @click="rejectedDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--<Page-nav :navigation="navigation" v-if="requireList.length"></Page-nav>-->
        <ImprovePaymentInfo ref="improvePaymentInfo" @close="handleRefreshStatus"></ImprovePaymentInfo>
        <!--查看资料详情-->
        <Loading :is-loading="isLoading"></Loading>
        </div>
        <div class="showPrint">
            <BorkerApprovalPrint :approvalInfo="approvalInfo" :paymentInfo="pmtApproveInfos" :pmtBusiInfo="pmtBusiInfo" :corpFinInfo="corpFinInfo"></BorkerApprovalPrint>
        </div>
    </div>
</template>
<script>
    import Header from "@/components/base/Header";
    import SearchBar from "@/components/SearchBar";
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import ApprovalStatusInfo from "@/components/order/broker/ApprovalStatusInfo";
    import CirculationOpinion from "@/components/order/broker/CirculationOpinion";
    import OrderProcess from "@/components/order/OrderProcess";
    import FixBottom from "@/components/base/FixBottom";
    import { InterfaceService } from "@/services/api";
    import ImprovePaymentInfo from "@/components/order/broker/dialog/ImprovePaymentInfo";
    import BorkerApprovalPrint from "@/components/order/broker/BorkerApprovalPrint";
    import PaymentApprovalInDetail from "@/components/order/broker/PaymentApprovalInDetail";
    import { viewFile } from '@/utils/orderUtil';

    export default {
        components: {
            Header,
            SearchBar,
            Loading,
            PanelTitle,
            ApprovalStatusInfo,
            OrderProcess,
            FixBottom,
            CirculationOpinion,
            ImprovePaymentInfo,
            BorkerApprovalPrint,
            PaymentApprovalInDetail
        },
        data() {
            return {
                navigation: [
                    {
                        name: "合同信息",
                        position: "order-data-message"
                    },
                    {
                        name: "要货单批次信息",
                        position: "require-order-info"
                    }
                ],
                tab:"1",
                tabs: [
                    { label: "基本信息", index: 1, active: true }
                ],
                isLoading: false,
                order: {},
                status: "",
                executionId: "",
                comment: "",
                orderNo: "",
                startFlag: "",
                approvalInfo: {},
                showHandleLink: false,
                fixedBottomActive:false,
                batchApproavlDialogVisible:false,
                rejectedDialogVisible:false,
                approvalButton:false,
                showRejectCommet:false,
                showCloseCommet:false,
                noteDialogVisible:false,
                justView:true,
                revokeReason:'',
                projectCate:'',
                rejectedReason:'',
                newExecutionId:'',
                pmtApproveInfos:{},
                pmtBusiInfo:{},
                corpFinInfo:{},
                execFlowList:[],
                entryNum:0,
                lastFailComment:"",
                lastFailOperator:"",
                purchaseContractUrl:"",
                supplierContractUrl:"",
                procDefKey:"",
                canFwRoleList: [], // 可转发角色
                fwStatus: '',
                remark: '',
                remarkId: '',
                remarkFlag: '',
                operateApproval: false,
                remarkList:[]
            };
        },
        computed: {
            userinfo() {
                return this.$store.state.userInfo;
            },
            role() {
                return this.$store.state.userInfo
                    ? this.$store.state.userInfo.bs
                    : 0;
            },
            hasOrderNo(){
                // this.orderNo = "ORD2001928237232232"
                return this.orderNo.indexOf("ORD") != -1
            }
        },
        filters: {
            percent(val) {
                return (val * 100)+ "%";
            }
        },
        methods: {
            // 合同排序
            handleSelectTab(tab){
                this.tab = tab.index;
            },
            // 进入合同详情页
            handleContractDetail(){
                if (!this.hasOrderNo) {
                    return
                } else {
                    let orderNo = this.orderNo,
                        procDefKey = "CONTRACT_APPROVE_WF"
                        // executionId = this.executionId;

                    const {href} = this.$router.resolve({
                        path: "/brokerApprovalDetail",
                        query: {
                            orderNo,
                            procDefKey,
                            // executionId,
                        },
                    });
                    window.open(href, '_blank');
                }
            },
            // 编辑、新增记录
            handleEditNote(note,type){
                this.noteDialogVisible = true;
                if (note) {
                    this.remark = note.remark || "";
                    this.entryNum = note.remark.length || 0;
                    this.remarkId = note.remarkId || "";
                    this.remarkFlag = type
                }else {
                    this.remark = "";
                    this.remarkId = "";
                    this.entryNum = 0
                }
            },
            handledelNote(note,type){
                this.remarkId = note.remarkId || "";
                this.remark = note.remark || "";
                this.remarkFlag = type;
                this.$confirm(
                    "确认删除该记录吗?删除后该记录将无法恢复",
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认",
                        cancelButtonText: '取消',
                    }).then(() => {
                    this.handleConfirmRemark();
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            //  修改、删除、新增记录
            handleConfirmRemark(){
                let params = {};
                if (this.remarkId) {
                    params = {
                        remarkId : this.remarkId,
                        remark : this.remark,
                        executionId : this.executionId,
                        remarkFlag : this.remarkFlag,
                    }
                }else {
                    params = {
                        remark : this.remark,
                        executionId : this.executionId,
                    }
                }
                console.log(params);
                InterfaceService.approvalPaymentRemark(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            this.noteDialogVisible = false;
                            this.$message.success("操作成功！");
                            this.getApprovalDetail("init")
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {
                    },
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            // 子组件点击请求打印
            dandleClickPrint() {
                // const bdhtml = window.document.body.innerHTML,
                // sprnstr = "<!--startprint-->",
                // eprnstr = "<!--endprint-->"

                // let prnhtml = bdhtml.substr(bdhtml.indexOf(sprnstr) + 17)

                // prnhtml = prnhtml.substring(0, prnhtml.indexOf(eprnstr))

                // window.document.body.innerHTML = prnhtml;
                window.print();
            },
            // 编辑、修改请款信息
            handleEditPaymentInfo(type){
                this.$refs["improvePaymentInfo"].open(type,this.executionId,this.procDefKey );
            },
            handleView(url) {
                if (url) {
                  viewFile(url)
                }
            },
            //关闭窗口
            handleCloseWindow(){
                window.opener=null;
                window.close();
            },
            closeWindow(){
                this.getApprovalDetail();
                setTimeout(()=>{
                    this.handleCloseWindow()
                },1000)
            },
            // 审批确认
            handleConfirm(type) {
                let comment ;
                this.comment ? comment = this.comment : comment = "同意";
                let executionList = [];
                if (type == 'Y') {
                    executionList.push({
                        executionId: this.executionId,
                        isAgree: "Y",
                        comment: comment,
                        procDefKey : this.procDefKey,
                    })
                } else if (type == 'N') {
                    executionList.push({
                        executionId: this.executionId,
                        isAgree: "N",
                        comment: this.rejectedReason,
                        procDefKey : this.procDefKey,
                    })
                }
                const params = {
                    procDefKey : this.procDefKey,
                    executionList: executionList
                };
                InterfaceService.batchApprovalProcess(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            // window.opener.location.reload();
                            if (data.respData.respList) {
                                this.approvalResult = data.respData.respList;
                                this.approvalResult.forEach(item => {
                                    if (item.approveCode == "0000") {
                                        type == 'Y' ? this.$message.success("审批成功") : this.$message.success("退回操作完成");
                                        this.batchApproavlDialogVisible = false;
                                        this.rejectedDialogVisible = false;
                                        this.rejectedReason =  "";
                                        this.getApprovalDetail();
                                    } else {
                                        this.$message.error(item.approveMsg);
                                    }
                                });
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {
                    },
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleEntry(ev){
                this.entryNum = ev.length
            },
            // 刷新状态
            handleRefreshStatus() {
                this.getApprovalDetail();

            },
            handleOpenCirculationOpinion(){
                this.$refs["circulationOpinion"].open(this.execFlowList);
            },
            refreshDetail(type){
                this.getApprovalDetail(type)
            },
            getApprovalDetail(type) {
                console.log(type);
                let execution = this.newExecutionId || this.executionId || '';
                let params = {};
                // 没有executionId（等待中的合同）入参orderNo；
                if (execution) {
                     params = {
                        executionId: execution,
                        procDefKey:this.procDefKey,
                        pageIndex: 1
                    };
                }
                InterfaceService.getApprovalDetail(
                    params,
                    data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            if (!type) {
                                if (window.opener) {
                                    window.opener.location.reload();
                                }
                            }
                            this.approvalInfo = data.respData || {};
                            this.orderNo = this.approvalInfo.orderNo || ""
                            this.startFlag = this.approvalInfo.operateStatus == "start";
                            this.pmtApproveInfos = data.respData.pmtApproveInfos || {};
                            this.pmtBusiInfo = data.respData.pmtBusiInfo || {};
                            this.corpFinInfo = data.respData.corpFinInfo || {};
                            this.execFlowList = data.respData.execFlowList || [];
                            this.remarkList = data.respData.remarkList || [];
                            this.canFwRoleList = data.respData.canFwRole && data.respData.canFwRole.replace(/\s/g,"").split(',') || []
                            if (this.execFlowList.length > 0) {
                                // 最后一条退回原因
                                this.lastFailComment = this.execFlowList[0].comment;
                                //最后一条操作人
                                this.lastFailOperator = this.execFlowList[0].acctName;
                                let lastIsAgree = this.execFlowList[0].isAgree;
                                let firstApproveFlow = this.approvalInfo.approveFlowList[0];
                                // 当前节点是招采部且最近一条流水为退回，则显示退回原因
                                this.showRejectCommet = firstApproveFlow.isCurrentNode == "1" && firstApproveFlow.step == "1" && lastIsAgree == "N";
                                // 最近一条流水为关闭，则显示关闭原因
                                this.showCloseCommet = this.execFlowList[0].taskId == "closed";
                            }
                            let status = this.approvalInfo.operateStatus;
                            status == "approve" ? this.approvalButton = true : this.approvalButton = false;
                        } else {
                            this.$message.error(res.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            init() {
                this.executionId = this.$route.query.executionId;
                // this.fwStatus = this.$route.query.fwStatus;
                this.procDefKey = this.$route.query.procDefKey;
                // this.applyFlg = this.$route.query.applyFlg;
                this.operateApproval = this.$route.query.operateApproval == "true";
                this.$nextTick(function () {
                    window.addEventListener('scroll', this.onScroll)
                });
                this.getApprovalDetail("init");
            },
            filterERP(list = []) {
                let resList = list;
                if (list.length !=0){
                    const res = list.filter(item => {
                        return item.sysCode === "ERP";
                    });
                    if (!res.length) {
                        resList.unshift({
                            sysCode: "ERP"
                        });
                    }
                }
                return resList;
            },
            filterExternalSys(item) {
                let str = "";
                if (item.externalCode) {
                    let status = item.approveStatus == 1 ? "审批完成" : "审批中";
                    str = "(" + item.sysCode + status + ")";
                }
                return str;
            },
            //滚动超300后出现底部的审核按钮
            onScroll(){
                let scrolled = document.documentElement.scrollTop || document.body.scrollTop;
                this.fixedBottomActive = scrolled >= 300;
            }
        },
        mounted() {
            this.init();

        },
        destroyed(){
            window.removeEventListener('scroll', this.onScroll)
        }
    };
</script>
<style lang="scss" scoped>
    .inner-container {
        margin-bottom: 100px;
        font-size: 14px;
    }

    .pointer {
        cursor: pointer;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }

        .active {
            color: #ffd64e;
        }
    }

    .table {
        /deep/ .el-button {
            font-size: 12px;
            span{
                line-height: 32px;
            }
        }

        width: 100%;
        line-height: 23px;
        font-size: 12px;
        table {
            width: 100%;
        }
        td {
            padding: 14px 10px;
            vertical-align: middle;
            word-break: break-word;
        }

        thead {
            text-align: center;
            white-space: nowrap;
            font-size: 14px;
            color: #909399;
            background: #f5f5f5;
        }

        tbody {
            text-align: center;

            tr:hover {
                background: #e8f3fd;
            }

            td {
                border-bottom: 1px solid #ebeef5;
            }
        }
    }

    .order-info {
        margin-bottom: 20px;
        /*line-height: 25px;*/
        font-size: 12px;
        position: relative;
        /deep/ .el-row {
            height: 100%;
            margin-bottom: 14px;
        }
        /deep/ .el-col {
            padding: 0 10px;
        }

        p {
            width: 100%;
            display: flex;
            padding-right: 10px;
            word-break: break-word;
            white-space: normal;

            & > span {
                display: inline-block;
                flex: 1 1 0%;
            }
            em{
                cursor: pointer;
            }
        }

        label {
            white-space: nowrap;
            color: #888888;
        }

        a {
            color: #0082ff;
        }
    }

    .order-name {
        display: inline-flex;
        width: 100%;
        vertical-align: top;
        line-height: 20px;

        img {
            width: 75px;
            height: 75px;
        }

        a:hover {
            text-decoration: underline;
            color: #0082ff;
        }

        .left {
            margin-right: 10px;
        }

        .right {
            text-align: left;

            p:first-child {
                margin-bottom: 10px;
            }
            p:last-child {
                word-break: break-all;
                max-height: 40px;
                overflow: hidden;
                color: #969799;
            }
        }
    }

    .order-total {
        margin-bottom: 40px;
        padding: 20px 40px;
        border-top: 1px solid #e2e2e2;
        text-align: right;
        font-size: 12px;
        line-height: 25px;
        color: #888888;
        background: #f5f5f5;

        label {
            display: block;
            color: #444444;
        }

        .total-content {
            margin-bottom: 10px;
        }

        .total {
            font-weight: bold;
            font-size: 14px;
        }

        .bold {
            font-weight: bold;
        }

        .big {
            font-size: 20px;
        }

        .red-font {
            color: #e94650;
        }
    }

    .order-total-black {
        color: #444444;
    }

    .order-info-title {
        margin: 5px 0;
        margin-bottom: 14px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
    }

    .order-sign-role {
        margin-top: 20px;
        padding-top: 20px;
        border-top: 1px solid #f5f5f5;
        .order-info-title {
            margin-bottom: 5px;
        }
    }
    .pre-tax, .after-tax{
        padding:0 10px;
        display: flex;
        justify-items: center;
        justify-content: space-between;
        height: 30px;
        line-height: 30px;
    }
    .after-tax{
        height: 40px;
        line-height: 40px;
        font-weight: bold;
        background: #fef4f3;
        margin-bottom: 20px;
        em{
            font-size: 22px;
        }
    }
    .line{
        width: 100%;
        height: 1px;
        background: #f0f0f0;
        margin: 20px 0;
    }
    .fix-bottom{
        width: 100%;
        margin: 0 auto;
        text-align: center;
    }
    /deep/.textareaContainer {
        .el-textarea__inner {
            min-height: 140px !important;
        }
    }
    /deep/ .el-textarea__inner{
        height: 100px;
    }
    .tax{
        width: 100%;
        vertical-align:baseline;
        margin-bottom: 20px;
        table-layout:fixed;
        td{
            word-wrap:break-word;
            width: 33%;
            padding: 10px;
            background: #f5f5f5;
            vertical-align:middle;
            text-align: left;
        }
    }
    /deep/ .el-dialog__header:before {
        height: 0;
    }
    .line-top{
        width: 95%;
        height: 1px;
        background: #eee;
        position: absolute;
        top:65px;
    }
    .count{
        float: right;
        span.red{
            color: #f00;
        }
    }
    .payment{
        padding:0 10px;
    }
    .circulation-opinion{
        width: 1190px;
        min-height: 72px;
        height: auto;
        background: #ffeaeb;
        border: 1px solid #eb4854;
        margin-bottom: 40px;
        position: relative;
        line-height: 20px;
        button{
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .opinion-content{
            width: 1140px;
            height: auto;
            margin-top: 28px;
            margin-left: 20px;
        }
        .reason{
            width: 900px;
            margin: 0 80px 20px;
            line-height: 20px;
            word-break:break-all;
        }
        .reason-ellipsis{
            width: 800px;
            margin: 0 80px 20px;
            line-height: 20px;
            overflow:hidden;
            white-space:nowrap;
            text-overflow:ellipsis;
        }
    }
    .panel-title{
        margin-top: 40px;
    }
    .note{
        width: 100%;
        background: #f7f7ff;
        /deep/ .el-col{
            padding: 5px 10px;
        }
        .edit-note{
            width: 100%;
            text-align: center;
        }
        span{
            color: #0082ff;
            cursor: pointer;
        }
    }
    .download{
        position: absolute;
        right: 10px;
        top: -55px;
    }
    .showPrint {
        display: none;
        width: 100%;
    }
    @media print {
        @page {
            size: A4;
        }
        .showPrint {
            display: block;
            width: 100%;
        }
        .unShowPrint {
            display: none
        }
        .printHead {
            position: fixed;
            bottom: 0px;
        }
    }
    .payment-method{
        p{
            margin-top: 5px;
            line-height: 20px;
        }
    }
</style>
<style>
    @media print {
        .copy-right, .fixed-tool {
            display: none;
        }
    }
</style>
