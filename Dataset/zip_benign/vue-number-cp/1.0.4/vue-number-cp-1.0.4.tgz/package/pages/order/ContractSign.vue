<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :is-white-bg="true" :progress="title" :is-border-bottom="false"></SearchBar>
    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <PanelTitle :tabs="tabs" @select="handleSelectTab"></PanelTitle>
      <div class="tab-change" v-if="contractType == 'dt_00_contract_profession'">
        <ul>
          <li v-for="(i,index) in innerTabs" :key="index" :class="{active:i.active}" @click="handleSelectInnerTab(index)">
            <span>{{i.label}}</span>
          </li>
        </ul>
      </div>
      <div class="tab-change" v-else>
        <ul>
          <li v-for="(i,index) in outerTabs" :key="index" :class="{active:i.active}" @click="handleSelectOuterTab(index)">
            <span>{{i.label}}</span>
          </li>
        </ul>
      </div>
      <span class="role-content f14" v-if="roleList.length">您待签署：{{roleList.join('、')}}</span>

      <div class="tc iframe" v-show="contractOpened">
        <!-- <iframe :src="attach.attachUrl" frameborder="0" width="100%" :height="iframeHeight">
            您的浏览器不支持PDF预览
        </iframe> -->
        <PDFView :url="attach.attachUrl"></PDFView>

      </div>
      <div class="tc blue hand" style="margin-top: 20px;" v-if="orderType == 'contract' && goodsAttach.attachUrl" @click="handleShowGoods()">
        货品清单
        <i class="el-icon-caret-top active" v-if="!goodsOpened"></i>
        <i class="el-icon-caret-bottom active" v-if="goodsOpened"></i>
      </div>
      <div class="tc iframe" v-show="goodsOpened && goodsAttach.attachUrl">
        <PDFView :url="goodsAttach.attachUrl"></PDFView>
      </div>
      <div v-if="attachList&&attachList.length" class="table">
        <table>
          <tbody>
            <tr v-for="(attach,index) in attachList" :key="index">
              <td width="30">
                <el-checkbox v-model="attach.checked" @change="handleSelectTableRow(attach,index)"></el-checkbox>
              </td>
              <td>《{{attach.documentName}}》</td>
              <td width="60">
                <el-button size="small" @click="handleDownload(attach)">下载</el-button>
              </td>
            </tr>
          </tbody>
        </table>

        <p class="batch-ope">
          <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow"></el-checkbox>&nbsp;全选&nbsp;&nbsp;
          <el-button size="small" @click="handleBatchDownload">批量下载</el-button>
        </p>
      </div>
    </div>
    <FixBottom v-if="roleList.length && showFixBottom">
      <div class="tc">
        <el-button v-if="checkEventRole(contractType)=='unfinish'" type="primary" @click="handleConfirm">电子签章
        </el-button>
        <el-button @click="handleCancel">{{checkEventRole(contractType)=='unfinish' ? '取消' : '关闭'}}</el-button>
      </div>
    </FixBottom>
    <FixBottom v-if="checkEventRole(contractType)=='finish' && showFixBottom">
      <div class="tc">
        <el-button type="primary" style="width: 120px;" disabled>已签章</el-button>
        <el-button @click="handleCancel">{{checkEventRole(contractType)=='unfinish' ? '取消' : '关闭'}}</el-button>
      </div>
    </FixBottom>
    <!-- 合同签章 -->
    <Signature ref="signature" :propCorpId="role=='B' ? orderInfo.purchaserId : ''" :propAcctId="role=='B' ? order.operAcctId : ''" :mainText="role=='B' ? order.purchaserName : ''" @close="handleCloseSignature"></Signature>

    <!-- 下载全部清单 -->
    <el-dialog class="dialog" title="确认电子签章" :append-to-body="true" :lock-scroll="true" :visible.sync="secondaryConfirmation" width="840px" center :close-on-click-modal="false">
      <div class="tl">
        <p style="line-height: 17px;">您已阅读合同内容，并确认内容无误，请点击【电子签章】按钮，进行电子用印。若合同内容有疑义，请联系平台客服：{{$platformContact()['hotLine']}} {{$platformContact()['hotLineTime']}}</p>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" @click="handleSecondaryConfim">电子签章</el-button>
        <el-button class="normal-btn" @click="secondaryConfirmation = false">取消</el-button>
      </div>
    </el-dialog>

    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import FixBottom from "@/components/base/FixBottom";
import PDFView from "@/components/base/PDFView";
import GoodsListPDFView from "@/components/base/GoodsListPDFView";
import Signature from "@/components/order/dialog/Signature";

import download from "@/utils/download";
import { InterfaceService } from "@/services/api";
import { filterEventByAcct } from "@/utils/orderUtil";
import Breadcrumb from "@/components/base/Breadcrumb";

const subContractTabs = [
  { label: "材料补充合同", type: "externalReplenishAgreement", active: true },
  { label: "事业部补充合同", type: "internalReplenishAgreement", active: false }
];
const contractTabs = [
  { label: "材料合同", type: "dt_10_contract_profession", active: true },
  { label: "事业部合同", type: "dt_00_contract_profession", active: false }
];
const relieveTabs = [
  { label: "材料合同解除协议", type: "supplierContractTerminate_pdf", active: true },
  { label: "事业部合同解除协议", type: "purchaserContractTerminate_pdf", active: false }
];
const settleTabs = [
  { label: "材料合同结算单", type: "settle_supplier_File", active:  false},
  { label: "事业部合同结算单", type: "settle_purchaser_File", active: true }
];
export default {
  mixins: [accountMixin],
  components: {
    Header,
    SearchBar,
    Loading,
    PanelTitle,
    FixBottom,
    Signature,
    GoodsListPDFView,
    Breadcrumb,
    PDFView
  },
  data() {
    return {
      isLoading: false,
      contractOpened: true,
      innerTabs: [],
      outerTabs: [],
      goodsOpened: true,
      order: {},
      orderInfo: {},
      contractType: "",
      tabIndex: 0,
      innerIndex: '0',
      outerIndex: '0',
      orderNo: "",
      attach: {},
      goodsAttach: {},
      attachList: [],
      breadcrumb: [],
      tabs: [],
      allChecked: false,
      showFixBottom: false,
      showGoods: false,
      roleList: [],
      orderType: "",
      title: "",
      secondaryConfirmation: false, // 二次确认
      attachs: [],
      subOrderNo: '',
      settleNo: '', // 结算单号
    };
  },
  computed: {

  },
  methods: {
    open(data) {
      this.order = data;
      this.attach = {};
      this.attachList = [];
      this.init();
    },
    handleShowContract() {
      this.contractOpened = !this.contractOpened;
    },
    handleShowGoods() {
      this.goodsOpened = !this.goodsOpened;
    },
    handleCancel() {
      // window.opener = null;
      // window.close();
      if (window.opener) {
        window.opener = null;
        window.close();
      } else {
        this.$router.go(-1)
      }
    },
    handleConfirm() {
      let attachs = [];
      const events = this.order.eventList || [];
      if (this.orderType == "contract") {
        if (this.subOrderNo) {
          events.forEach(ev => {
            if (ev.eventType == 'replenishSign' && this.contractType == ev.documentType) {
              attachs.push(ev);
            }
          });
        } else {
          events.forEach(ev => {
            if ((ev.eventType == 0 && this.contractType.substring(0, 5) == ev.documentType.substring(0, 5)) ||
              (ev.eventType == "goodsList" && this.contractType == "dt_10_contract_profession" && ev.documentType == "supplierGoodsList_pdf") ||
              (ev.eventType == "goodsList" && this.contractType == "dt_00_contract_profession" && ev.documentType == "purchaserGoodsList_pdf")) {
              attachs.push(ev);
            }
          });
        }
      } else if (this.orderType == "relieve") {
        events.forEach(ev => {
          if (ev.eventType == "contractTerminateSign" && this.contractType == ev.documentType) {
            attachs.push(ev);
          }
        });
      } else if (this.orderType == "settle") {
        events.forEach(ev => {
          if (ev.eventType == '5' && this.contractType == ev.documentType) {
            attachs.push(ev);
          }
        });
      }
      this.attachs = attachs
      this.secondaryConfirmation = true
    },
    handleSecondaryConfim() {
      // 二次确认
      this.handleSignContract(this.attachs)
      this.secondaryConfirmation = false
    },
    handleSelectTab(tab) {
      this.contractType = tab.type;
      this.getContractInfo(tab.type);
      this.checkUnsignRole(tab.type);
      this.checkUnsignType(tab.type);
    },
    handleSelectInnerTab(index) {
      this.innerTabs.forEach((i, _index) => {
        i.active = index === _index
      })
      this.innerIndex = index
      this.getContractInfo(this.contractType);
    },
    handleSelectOuterTab(index) {
      this.outerTabs.forEach((i, _index) => {
        i.active = index === _index
      })
      this.outerIndex = index
      this.getContractInfo(this.contractType);
    },
    // 合同签章
    handleSignContract(attachs) {
      let events = [];
      events = attachs;
      attachs.forEach(item => {
        if (item.eventType == "goodsList") {
          this.goodsAttach = item
        } else {
          this.attach = item;
        }
      });
      console.log(events);
      this.$refs["signature"].open(events, "order", '', this.order);
    },
    // 合同签章完成
    handleCloseSignature(bool, respList) {
      if (bool) {
        this.$router.push({
          path: '/resultsFeedback',
          query: {
            type: 'sign',
            supplementOrderNo: this.subOrderNo || '',
            orderNo: this.orderNo || ''
          }
        })
        window.opener && window.opener.location.reload();
      } else {
        this.getOrderDetail();
      }
    },
    // 全选
    handleAllSelectTableRow(bool) {
      let arr = [];
      arr = [].concat(this.attachList);
      arr.forEach(item => {
        item.checked = bool;
      });
      this.attachList = arr;
    },
    // 选中行
    handleSelectTableRow(item, index) {
      this.$set(this.attachList, index, item);
      this.checkAllSelect();
    },
    handleDownload(item) {
      const x = new XMLHttpRequest();
      x.open("GET", item.attachUrl, true);
      x.responseType = "blob";
      x.onload = e => {
        download(
          x.response,
          item.documentName.split("?")[0],
          x.response.type
        );
      };
      x.send();
    },
    handleBatchDownload() {
      let valid = false;
      this.attachList.forEach(item => {
        if (item.checked) {
          valid = true;
        }
      });
      if (valid) {
        this.attachList.forEach(item => {
          if (item.checked) {
            this.handleDownload(item);
          }
        });
      } else {
        this.$message.error("请选择附件");
      }
    },
    // 是否全选
    checkAllSelect() {
      this.allChecked = this.attachList.every(item => {
        return item.checked;
      });
    },

    /**
     * 根据类型 判断 attach PDF 显示内容
     */
    selectContract(type, list) {
      this.attachList = [];
      const events = list;
      if (this.orderType == "contract") {
        if (this.subOrderNo) {
          events.forEach(ev => {
            if (type == "internalReplenishAgreement") {
              // 内部合同
              if (ev.documentType == "internalReplenishAgreement") {
                this.attach = ev;
              }
            } else if (type == "externalReplenishAgreement") {
              // 外部合同
              if (ev.documentType == "externalReplenishAgreement") {
                this.attach = ev;
              }
            }
          });
          console.log(this.attach)
        } else {
          events.forEach(ev => {
            if (type == "dt_00_contract_profession") {
              // 内部合同
              if (this.innerIndex == '0' && ev.documentType == "dt_00_contract_common") {
                this.attach = ev;
              } else if (this.innerIndex == '1' && ev.documentType == "dt_00_contract_profession") {
                this.attach = ev;
              }
            } else if (type == "dt_10_contract_profession") {
              // 外部合同
              if (this.outerIndex == '0' && ev.documentType == "dt_10_contract_common") {
                this.attach = ev;
              } else if (this.outerIndex == '1' && ev.documentType == "dt_10_contract_profession") {
                this.attach = ev;
              }
            }
          });
        }

        console.log(this.attach);
      } else if (this.orderType == "relieve") {
        events.forEach(ev => {
          if (type == "purchaserContractTerminate_pdf") {
            // 内部合同
            if (ev.documentType == "purchaserContractTerminate_pdf") {
              this.attach = ev;
            } else if (ev.documentType == "contractTerminateAttach") {
              this.attachList.push(ev);
            }
          } else if (type == "supplierContractTerminate_pdf") {
            // 外部合同
            if (ev.documentType == "supplierContractTerminate_pdf") {
              this.attach = ev;
            } else if (ev.documentType == "contractTerminateAttach") {
              this.attachList.push(ev);
            }
          }
        });
        // 结算合同 - 显示 电子签章 pdf
      } else if (this.orderType == "settle") {
        events.forEach(ev => {
          if (type == "settle_supplier_File") {
            // 内部合同
            if (ev.documentType == type) {
              this.attach = ev;
            }
          } else if (type == "settle_purchaser_File") {
            // 外部合同
            if (ev.documentType == type) {
              this.attach = ev;
            }
          }
        });
      }

    },
    // 检查角色事件
    checkEventRole(type) {
      let status = "";
      let eventType = "";
      if (this.orderType == "contract") {
        if (this.subOrderNo) {
          eventType = 'replenishSign'
        } else {
          eventType = 0
        }
      } else if (this.orderType == "relieve") {
        eventType = "contractTerminateSign"
      } else if (this.orderType == "settle") {
        eventType = "5"
      }
      if (this.order && this.order.eventList) {
        let acctIdList = [];
        if (this.userinfo.acctIdList.length) {
          this.userinfo.acctIdList.forEach(item => {
            acctIdList.push(item)
          });
        } else {
          acctIdList.push(this.acctId)
        }
        const events = filterEventByAcct(
          this.order.eventList,
          eventType,
          acctIdList
        );
        events.forEach(ev => {
          if (ev.eventType == eventType && ev.documentType.substring(0, 5) == type.substring(0, 5)) {
            if (ev.processList && ev.processList.length) {
              status = status || "finish";
              ev.processList.forEach(process => {
                if (process.processFlg == 0) {
                  status = "unfinish";
                }
              });
            }
          }
        });
        // 货品清单签署
        if (status == "finish") {
          let acctIdList = [];
          if (this.userinfo.acctIdList.length) {
            this.userinfo.acctIdList.forEach(item => {
              acctIdList.push(item)
            });
          } else {
            acctIdList.push(this.acctId)
          }
          const goodsEvents = filterEventByAcct(
            this.order.eventList,
            "goodsList",
            acctIdList
          );
          goodsEvents.forEach(ev => {
            if (ev.eventType == "goodsList") {
              if (type == "dt_10_contract_profession" && ev.documentType == "supplierGoodsList_pdf") {
                if (ev.processList && ev.processList.length) {
                  status = status || "finish";
                  ev.processList.forEach(process => {
                    if (process.processFlg == 0) {
                      status = "unfinish";
                    }
                  });
                }
              } else if (type == "dt_00_contract_profession" && ev.documentType == "purchaserGoodsList_pdf") {
                if (ev.processList && ev.processList.length) {
                  status = status || "finish";
                  ev.processList.forEach(process => {
                    if (process.processFlg == 0) {
                      status = "unfinish";
                    }
                  });
                }
              }
            }
          });
        }
      }
      return status;
    },
    // 检查未签署角色
    checkUnsignRole(documentType) {
      console.log(documentType, '-documentType');

      this.roleList = [];
      let acctIdList = [];
      if (this.userinfo.acctIdList.length) {
        this.userinfo.acctIdList.forEach(item => {
          acctIdList.push(item)
        });
      } else {
        acctIdList.push(this.acctId)
      }
      this.order.eventList.forEach(ev => {
        if (documentType == "dt_10_contract_profession") {
          if ((ev.documentType == "dt_10_contract_profession" || ev.documentType == "dt_10_contract_common" || ev.documentType == "supplierGoodsList_pdf" || ev.documentType == "settle_supplier_File") && ev.processList) {
            ev.processList.forEach(process => {
              acctIdList.forEach(id => {
                if (
                  process.processFlg == 0 &&
                  process.acctId == id &&
                  this.roleList.indexOf(process.roleName) === -1
                ) {
                  this.roleList.push(process.roleName);
                }
              })
            });
          }
        } else if (documentType == "dt_00_contract_profession") {
          if ((ev.documentType == "dt_00_contract_profession" || ev.documentType == "dt_00_contract_common" || ev.documentType == "purchaserGoodsList_pdf" || ev.documentType == "settle_purchaser_File") && ev.processList) {
            ev.processList.forEach(process => {
              acctIdList.forEach(id => {
                console.log(this.roleList.indexOf(process.roleName), '-----', this.roleList, process.roleName);
                if (
                  process.processFlg == 0 &&
                  process.acctId == id &&
                  this.roleList.indexOf(process.roleName) === -1
                ) {
                  this.roleList.push(process.roleName);
                }
              })
            });
          }
          // settle_supplier_File 材料合同
        } else if (this.contractType == ev.documentType) {
          ev.processList.forEach(process => {
            if (
              process.processFlg == 0 &&
              this.mxAcctIdList.includes(process.acctId) &&
              this.roleList.indexOf(process.roleName) === -1
            ) {
              this.roleList.push(process.roleName);
            }
          })
        } else {
          if (ev.documentType == documentType && ev.processList) {
            ev.processList.forEach(process => {
              acctIdList.forEach(id => {
                if (
                  process.processFlg == 0 &&
                  process.acctId == id &&
                  this.roleList.indexOf(process.roleName) === -1 &&
                  this.tab == "1"
                ) {
                  this.roleList.push(process.roleName);
                }
              })

            });
          }
        }
      });
      console.log(this.roleList);
    },
    //检查合同是否签署，若已签署，则收起只显示货品清单签署
    checkUnsignType(documentType) {
      let ownerEventList = []
      this.order.eventList.forEach(ev => {
        if (ev.documentType == documentType && ev.processList) {
          ev.processList.forEach(process => {
            if (this.mxAcctIdList.includes(process.acctId)) {
              ownerEventList.push(process)
            }
          });
        }
      });
      if (ownerEventList.length > 0) {
        this.contractOpened = ownerEventList.some(item => {
          return item.processFlg != 1
        })
      } else {
        this.contractOpened = true
      }
      this.goodsOpened = true
    },
    getOrderDetail() {
      InterfaceService.getOrderDetail(
        { orderNo: this.orderNo },
        data => {
          if (data.respData.respCode === "0000") {
            let res = data.respData || {}
            this.orderInfo = res
            if (this.subOrderNo) {
              this.order = res.replenishContractInfo.relContractList.find(i => i.orderNo === this.subOrderNo) || {}
            } else {
              this.order = res;
            }
            this.init()
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },

    /**
     * 获取签章 PDF
     */
    getContractInfo(type) {
      let bs;
      if (type == "dt_00_contract_profession" || type == "purchaserContractTerminate_pdf" || type == "internalReplenishAgreement" || type == "settle_purchaser_File") {
        bs = "B";
      } else if (type == "dt_10_contract_profession" || type == "supplierContractTerminate_pdf" || type == "externalReplenishAgreement" || type == "settle_supplier_File") {
        bs = "S";
      }
      const params = {
        orderNo: this.subOrderNo || this.orderNo,
        bs: bs
      };
      InterfaceService.getContractInfo(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            const list = data.respData.documentInfos || [];
            this.selectContract(type, list);
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    init() {
      let hasInner, hasOuter, hasInnerCommon, hasOuterCommon;
      const events = this.order.eventList || [];
      events.forEach(ev => {
        if (
          (ev.eventType == 0 || ev.eventType == "contractTerminateSign" || ev.eventType == "replenishSign")
        ) {
          if (ev.documentType == "dt_00_contract_profession" || ev.documentType == "dt_00_contract_common" || ev.documentType == "purchaserContractTerminate_pdf" || ev.documentType == "internalReplenishAgreement" || ev.documentType == "settle_purchaser_File") {
            hasInner = true;
            if (ev.documentev == "dt_00_contract_common") {
              hasInnerCommon = true
            }
          } else if (ev.documentType == "dt_10_contract_profession" || ev.documentType == "dt_10_contract_common" || ev.documentType == "supplierContractTerminate_pdf" || ev.documentType == "externalReplenishAgreement" || ev.documentType == "settle_supplier_File") {
            hasOuter = true;
            if (ev.documentType == "dt_10_contract_common") {
              hasOuterCommon = true
            }
          }
        }
      });
      if (this.orderType == "contract") {
        if (this.subOrderNo) { //补充合同
          if (this.role == "B") {
            if (hasInner && hasOuter) {
              this.tabs = [
                { label: "材料补充合同", type: "externalReplenishAgreement", active: false },
                { label: "事业部补充合同", type: "internalReplenishAgreement", active: true }
              ];
              this.contractType = "internalReplenishAgreement";
            } else if (hasInner) {
              this.tabs = [
                { label: "事业部补充合同", type: "internalReplenishAgreement", active: true }
              ];
              this.contractType = "internalReplenishAgreement";
            } else if (hasOuter) {
              this.tabs = [
                { label: "材料补充合同", type: "externalReplenishAgreement", active: true }
              ];
              this.contractType = "externalReplenishAgreement";
            }
          } else if (this.role == "S") {
            if (hasOuter) {
              this.tabs = [
                { label: "材料补充合同", type: "externalReplenishAgreement", active: true }
              ];
              this.contractType = "externalReplenishAgreement";
            }
          }
        } else {
          if (this.role == "B") {
            if (hasInner && hasOuter) {
              this.tabs = [
                { label: "材料合同", type: "dt_10_contract_profession", active: false },
                { label: "事业部合同", type: "dt_00_contract_profession", active: true }
              ];
              this.contractType = "dt_00_contract_profession";
            } else if (hasInner) {
              this.tabs = [
                { label: "事业部合同", type: "dt_00_contract_profession", active: true }
              ];
              this.contractType = "dt_00_contract_profession";
            } else if (hasOuter) {
              this.tabs = [
                { label: "材料合同", type: "dt_10_contract_profession", active: true }
              ];
              this.contractType = "dt_10_contract_profession";
            }
          } else if (this.role == "S") {
            if (hasOuter) {
              this.tabs = [
                { label: "材料合同", type: "dt_10_contract_profession", active: true }
              ];
              this.contractType = "dt_10_contract_profession";
            }
          }
          if (hasInnerCommon) {
            this.innerTabs = [
              { label: "合同通用版", type: "0", active: true },
              { label: "合同专业版", type: "1" }
            ]
            this.innerIndex = '0'
          } else {
            this.innerTabs = [
              { label: "合同专业版", type: "1", active: true },
            ]
            this.innerIndex = '1'
          }
          if (hasOuterCommon) {
            this.outerTabs = [
              { label: "合同通用版", type: "0", active: true },
              { label: "合同专业版", type: "1" }
            ]
            this.outerIndex = '0'
          } else {
            this.outerTabs = [
              { label: "合同专业版", type: "1", active: true },
            ]
            this.outerIndex = '1'
          }
        }
      } else if (this.orderType == "relieve") {
        if (this.role == "B") {
          if (hasInner && hasOuter) {
            this.tabs = [
              { label: "材料合同解除协议", type: "supplierContractTerminate_pdf", active: false },
              { label: "事业部合同解除协议", type: "purchaserContractTerminate_pdf", active: true }
            ];
            this.contractType = "purchaserContractTerminate_pdf";
          } else if (hasInner) {
            this.tabs = [
              { label: "事业部合同解除协议", type: "purchaserContractTerminate_pdf", active: true }
            ];
            this.contractType = "purchaserContractTerminate_pdf";
          } else if (hasOuter) {
            this.tabs = [
              { label: "材料合同解除协议", type: "supplierContractTerminate_pdf", active: true }
            ];
            this.contractType = "supplierContractTerminate_pdf";
          }
        } else if (this.role == "S") {
          if (hasOuter) {
            this.tabs = [
              { label: "材料合同解除协议", type: "supplierContractTerminate_pdf", active: true }
            ];
            this.contractType = "supplierContractTerminate_pdf";
          }
        }
      } else if (this.orderType == "settle") {
        if (this.role == "B") {
          if (hasInner && hasOuter) {
            this.tabs = this.$clone(settleTabs);
            this.contractType = "settle_purchaser_File";
          } else if (hasInner) {
            this.tabs = [
              { label: "事业部合同结算单", type: "settle_purchaser_File", active: true }
            ];
            this.contractType = "settle_purchaser_File";
          } else if (hasOuter) {
            this.tabs = [
              { label: "材料合同结算单", type: "settle_supplier_File", active: true }
            ];
            this.contractType = "settle_supplier_File";
          }
        } else if (this.role == "S") {
          if (hasOuter) {
            this.tabs = [
              { label: "材料合同结算单", type: "settle_supplier_File", active: true }
            ];
            this.contractType = "settle_supplier_File";
          }
        }
      }
      console.log(this.contractType)
      this.getContractInfo(this.contractType);
      this.checkUnsignRole(this.contractType);
      this.checkUnsignType(this.contractType);
      setTimeout(() => {
        this.showFixBottom = true;
      }, 500)
    }
  },
  mounted() {
    this.orderNo = this.$route.query.orderNo || "";
    this.orderType = this.$route.query.orderType || "";
    this.subOrderNo = this.$route.query.subOrderNo || "";
    this.settleNo = this.$route.query.settleNo || "";
    if (this.orderType == "contract") {
      this.title = this.subOrderNo ? '电子签章补充合同' : this.settleNo ? '电子签章结算单' : "签署合同";
      if (this.subOrderNo) {
        this.tabs = this.$clone(subContractTabs)
      } else if (this.settleNo) {
        this.tabs = this.$clone(settleTabs)
      } else {
        this.tabs = this.$clone(contractTabs)
      }
    } else if (this.orderType == "relieve") {
      this.tabs = this.$clone(relieveTabs);
      this.title = "电子签章解除协议"
    }
    this.attach = {};
    this.attachList = [];
    this.getOrderDetail();
    this.breadcrumb = [
      { name: '管理中心', path: this.role == 'B' ? '/purchaserCenter/accountInfo' : '/vendorCenter/accountInfo' },
      {
        name: '交易管理-双向合同',
        path: this.role == 'B' ? '/purchaserCenter/orderList' : '/vendorCenter/orderList',
      },
      { name: this.orderType === 'relieve' ? '电子签章解除协议' : `电子签章${this.subOrderNo ? '补充合同' : this.settleNo ? '结算单' : ''}` },
    ];
  }
};
</script>

<style lang="scss" scoped>
.iframe {
  min-height: 500px;
}

.inner-container {
  margin-bottom: 80px;
}

.table {
  margin-top: 20px;
  table {
    width: 100%;
    margin-bottom: 20px;
  }

  table td {
    padding: 10px 20px;
    background: #f5f5f5;
  }

  table tr td:first-child {
    padding-right: 0;
  }
}

.batch-ope {
  padding: 0 20px;
}

.role-content {
  font-weight: bold;
  display: block;
  margin-top: -10px;
  margin-bottom: 10px;
  color: #444;
}
.dialog-footer {
  margin-top: -10px;
}
.tab-change {
  height: 40px;
  margin-top: -10px;
  background: #f5f5f5;
  padding: 10px 20px;
  /*letter-spacing: 6px;*/
  font-size: 16px;
  margin-bottom: 15px;
  text-align: center;
  position: relative;
  color: #fff;
  & > ul {
    & > li {
      float: left;
      font-size: 14px;
      color: #888;
      margin-right: 50px;
      text-align: center;
      cursor: pointer;
      position: relative;
      transition: all 0.3s linear;
      &:hover,
      &.active {
        &::after {
          width: 40px;
        }
        span {
          color: #313131;
          font-weight: 600;
        }
      }

      &:hover {
        span {
          font-weight: normal !important;
        }
      }
      &::after {
        content: "";
        width: 0;
        height: 2px;
        border-radius: 2px;
        background: #c99f4f;
        position: absolute;
        bottom: -6px;
        left: 50%;
        transform: translate(-50%, 0);
        transition: all 0.3s linear;
      }
    }
  }
}
</style>
