<template>
    <div class="product">
        <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
        <!-- 查询条件 -->
        <el-form class="form" ref="form" :model="form" label-width="80px">
            <el-row>
                <el-col :span="2">
                    <span class="search-title">合同名称</span>
                </el-col>
                <el-col :span="19">
                        <el-input
                        v-model="form.contractName"
                        clearable
                        @keyup.enter.native="handleSearch"
                        ></el-input>
                </el-col>
                <el-col :span="3">
                    <el-button
                    type="primary"
                    size="small"
                    style="width: 100%"
                    @click="handleSearch"
                    >搜索</el-button
                    >
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="7">
                    <el-form-item label="城市公司">
                        <el-select placeholder="请选择城市公司" v-model="form.cityCompany" @change="handleDropdownSelectChange">
                            <el-option value="" label="全部"></el-option>
                            <el-option v-for="(item,index) in cityCompanyList" :value="item" :key="index"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="7">
                    <el-form-item label="项目名称">
                        <el-select placeholder="请选择项目" v-model="form.projectName" @change="handleDropdownSelectChange">
                            <el-option value="" label="全部"></el-option>
                            <el-option v-for="(item,index) in projectNameList" :value="item" :key="index"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="10" v-if="tab == 3 || tab == 4" class="third-col">
                    <el-col :span="14">
                        <el-form-item label="发起审批时间">
                            <el-col class="form-item">
                                <el-date-picker type="year" placeholder="请选择年份" value-format="yyyy" v-model="form.year" style="width:100%" @change="handleDropdownSelectChange"></el-date-picker>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <el-col class="tc" :span="2"><div style="text-align: center;height: 100%;line-height: 40px">~</div></el-col>
                    <el-col class="form-item" :span="8">
                        <el-select placeholder="请选择季度" v-model="form.season" @change="handleDropdownSelectChange"  style="width:92%">
                            <el-option v-for="(item,index) in seasonList" :label="item.season" :value="item.value" :key="index"></el-option>
                        </el-select>
                    </el-col>
                </el-col>
                <el-col :span="24" v-if="tab == 3">
                    <div class="specifications-choose clearfloat">
                        <ul>
                            <li :class="{'active':form.executionStatus === ''}" @click="changeExecutionStatus('')">全部</li>
                            <li :class="{'active':form.executionStatus === 'processing'}" @click="changeExecutionStatus('processing')">进行中</li>
                            <li :class="{'active':form.executionStatus === 'end'}" @click="changeExecutionStatus('end')">归档</li>
                            <li v-if="startApproval || managerApproval" :class="{'active':form.executionStatus === 'closed'}"  @click="changeExecutionStatus('closed')">已关闭</li>
                            <li v-if="!startApproval" :class="{'active':form.executionStatus === 'rejected'}" @click="changeExecutionStatus('rejected')">已退回</li>
                        </ul>
                    </div>
                </el-col>
                <el-col :span="24" v-if="tab == 2">
                    <div class="specifications-choose clearfloat">
                        <ul>
                            <li :class="{'active':form.approveStatus == ''}" v-model="form.approveStatus" @click="changeApproveStatus('')">全部</li>
                            <li :class="{'active':form.approveStatus == 'ERP'}" v-model="form.approveStatus" @click="changeApproveStatus('ERP')">ERP审批中</li>
                            <li :class="{'active':form.approveStatus == 'CHECKED'}" v-model="form.approveStatus" @click="changeApproveStatus('CHECKED')">预审核</li>
                        </ul>
                    </div>

                </el-col>
            </el-row>
        </el-form>
        <div class="product-table">
            <!-- 列表 -->
            <div class="check-all" v-if="tab == 1 && (operateApproval || financeApproval || managerApproval)">
                <div class="check">
                    <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow" :disabled="disableAllCheck"></el-checkbox><span>当页全选</span>
                </div>
                <div class="sign f18">

                    <el-button size="mini" :disabled="!hasChecked" @click="handleBatchOrderConfirm">批量审批</el-button>
                </div>
            </div>
                <!--</template>-->
            <table v-if="tab != 4">
                <thead>
                <tr>
                    <th width="40px">&nbsp;</th>
                    <th width="150px">城市公司</th>
                    <th width="150px">项目名称</th>
                    <th width="380px">合同名称</th>
                    <!--<th v-if="tab ==1" width="75px">加价费率</th>-->
                    <th v-if="tab ==2" width="120px">审批状态</th>
                    <th v-if="tab ==3" width="120px">状态</th>
                    <th width="100px" style="text-align: center">操作</th>
                </tr>
                </thead>

                <!--<template v-if="productList.length">-->
                <tbody v-for="(item,index) in contractApproveInfos" :key="index" class="tbody-row">
                <tr>
                    <td v-if="tab == 1 && item.status == 'processing' && item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF'" style="text-align: center">
                        <el-checkbox v-model="item.checked" :disabled="disableAllCheck"  @change="handleSelectTableRow(item,index)"></el-checkbox>
                    </td>
                    <td v-else width="60px">&nbsp;</td>
                    <td>{{item.cityCompany}}</td>
                    <td>{{item.projectName}}</td>
                    <td><span>{{item.contractName}}</span></td>
                    <!--<td v-if="tab == 1">{{item.addRate|percent}}</td>-->
                    <td v-if="tab == 2 && item.approveStatus == 'ERP'">ERP审批中</td>
                    <td v-if="tab == 2 && item.approveStatus == 'CHECKED'">待运营审查</td>
                    <td v-if="tab == 2 && item.approveStatus != 'ERP' && item.approveStatus != 'CHECKED'" ></td>
                    <td v-if="tab == 3">{{item.disc}}</td>
                    <td style="text-align: right">
                        <el-button type="primary" v-if="isShowAnnotation(item)" @click="handleAnnotation(item)">批注</el-button>
                        <el-button type="primary" v-if="tab == 1 && startApproval && (!item.status || item.status =='rejected' || item.status =='canceled' || item.status == 'processing') && item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF' " @click="handleApprovalConfirm(item)">审批</el-button>
                        <el-button type="primary" v-if="tab == 1 && (operateApproval || financeApproval || managerApproval) && item.status == 'processing' && item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF'" @click="handleOpenDetail(item)">审批</el-button>
                        <el-button type="primary" @click="handleConfirmRelieveDialog(item)"
                                   v-if="tab == 1 && item.procDefKey=='CONTRACT_TERMINATE_BROKER_WF' && item.contractSignStatus !='1' && item.status !='rejected'">
                            终止磋商
                        </el-button>
                        <el-button type="primary" @click="handleConfirmRelieveDialog(item)"
                                   v-if="tab == 1 && item.procDefKey=='CONTRACT_TERMINATE_BROKER_WF' && item.contractSignStatus =='1' && item.status !='rejected'">
                            合同解除
                        </el-button>
                        <el-button v-if="tab == 1&& item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF' && startApproval && (!item.status || item.status == 'canceled' || item.status == 'rejected')" @click="handleClose(item)">关闭</el-button>
                        <el-button @click="handleCloseRelveveOrder(item)"
                                   v-if="tab == 1 && item.procDefKey=='CONTRACT_TERMINATE_BROKER_WF' && item.status =='rejected'">
                            知道了
                        </el-button>

                        <el-button v-if="tab == 3 && startApproval && item.status == 'processing' && item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF'" @click="handleCanceled(item)">撤回</el-button>
                        <div v-if="tab == 1 && startApproval && (!item.status || item.status =='rejected' || item.status =='canceled' || item.status == 'processing')&& item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF'"><span  class="blue pointer" @click="handleOpenDetail(item)">查看详情</span></div>
                        <div v-if="tab != 1 && item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF'"><span class="blue pointer" @click="handleOpenDetail(item)">查看详情</span></div>
                        <div v-if="isShowAnnotation(item)"><span class="blue pointer" @click="handleOpenDetail(item)">查看详情</span></div>
                        <div v-if="item.executionId && item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF'"><span class="blue pointer" @click="handleBatchDownload(item)">审批资料下载</span></div>
                        <div v-if="item.executionId && item.fwStatus != '2' && item.procDefKey=='CONTRACT_TERMINATE_BROKER_WF'"><span class="blue pointer" @click="handleConfirmRelieveDialog(item,'look')">查看资料</span></div>
                    </td>
                </tr>
                <tr class="retreat" v-if="tab == 1 && item.status == 'rejected' && item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF'">
                    <td colspan="4">退回原因：{{item.comment}}</td>
                    <td colspan="1" style="text-align: left;text-indent:0"><span>退回人：{{item.acctName}}</span></td>
                </tr>
                <tr class="retreat" v-if="tab == 1 && item.status == 'rejected' && item.procDefKey=='CONTRACT_TERMINATE_BROKER_WF'">
                    <td colspan="5">供应商拒绝解除合同原因：{{item.comment}}</td>
                </tr>
                <tr class="retreat" v-if="tab == 1 && item.fwStatus == '1' || item.fwStatus == '2' || item.fwStatus == '3'">
                    <td :colspan="tab == 1?4:5" :title="item.comment"> {{item.fwStatus == '3' ? '转发留言：' : '批注：'}}{{item.comment}}</td>
                    <td colspan="1" style="text-align: left;text-indent:0"><span :title="item.acctName">{{item.fwStatus == '3' ? '转发人：' : '批注人：'}}{{item.acctName}}</span></td>
                </tr>
                </tbody>
                <!--</template>-->
            </table>
            <!--抄送流程-->
            <table v-if="tab == 4">
                <thead>
                <tr>
                    <th width="400px">合同名称</th>
                    <th width="150px">城市公司</th>
                    <th width="150px">项目名称</th>
                    <th width="120px">发起审批日期</th>
                    <th width="80px" style="text-align: center">操作</th>
                </tr>
                </thead>

                <!--<template v-if="productList.length">-->
                <tbody v-for="(item,index) in contractApproveInfos" :key="index" class="tbody-row">
                <tr>
                    <td><span>《{{item.contractName}}》</span></td>
                    <td>{{item.cityCompany}}</td>
                    <td>{{item.projectName}}</td>
                    <td>{{item.creTm}}</td>
                    <td style="text-align: right">
                        <div v-if="item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF'"><span class="blue pointer" @click="handleOpenDetail(item)">查看详情</span></div>
                    </td>
                </tr>
                <tr class="retreat" v-if="tab == 1 && item.status == 'rejected' && item.procDefKey!='CONTRACT_TERMINATE_BROKER_WF'">
                    <td colspan="5">退回原因：{{item.comment}}</td>
                    <td>退回人：{{item.acctName}}</td>
                </tr>
                </tbody>
                <!--</template>-->
            </table>

            <div class="table-pagination" v-if="brokerApprovalList.length">
                <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                </el-pagination>
            </div>

            <!--空列表-->
            <div class="product-empty" v-if="!brokerApprovalList.length&&!isLoading">
                <img src="@/assets/images/icon-no-product.png">
                <p>没有搜索到相关合同，请重新修改搜索条件搜索！</p>
            </div>
        </div>
        <!-- 批量确认审批合同 -->
        <el-dialog class="dialog" title="确认并进行合同审批" :append-to-body="true" :lock-scroll="true" :visible.sync="batchApproavlDialogVisible" width="840px" center :close-on-click-modal="false" @close="handleClear()">
            <div class="line-top"></div>
            <div class="f14 tl">确认进行已勾选的<em class="red">{{selectedSignLength}}</em>份合同审批</div>
            <div class="contract-list tl">
                <p v-for="item in signbrokerApprovalList">{{item.contractName}}</p>
            </div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="comment" placeholder="请填写批量审批或退回的原因,300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirmDialog('Y')">批量同意</el-button>
                <el-button :disabled="!comment" type="primary" size="small" style="width: 100px" @click="handleConfirmDialog('N')">批量退回</el-button>
                <el-button size="small" style="width: 100px" @click="batchApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--审批退回-->
        <el-dialog class="dialog" title="批量退回原因" :append-to-body="true" :lock-scroll="true" :visible.sync="rejectedDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;rejectedReason = ''">
            <div class="line-top"></div>
            <div class="f14" style="text-align: left">请填写批量退回的原因</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="rejectedReason" placeholder="请填写批量退回的原因,300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" :disabled="!rejectedReason" size="small" style="width: 100px" @click="handleConfirm('N')">批量退回</el-button>
                <el-button size="small" style="width: 100px" @click="rejectedDialogVisible = false;batchApproavlDialogVisible=true">取消</el-button>
            </div>
        </el-dialog>
        <!--审批结果-->
        <el-dialog class="sign-result-dialog" :title="approvalOrReject+'结果'" :append-to-body="true" :lock-scroll="true" :visible.sync="approavlResultDialogVisible" width="840px" center :close-on-click-modal="false" @close="getApprovalList">
            <div class="line-top" style="top:50px"></div>
            <div style="width: 344px;text-align: left">
                <div v-if="signFailNum > 0">
                    <div class="f14 bold"><em class="red">{{selectedSignLength}}</em>份合同{{approvalOrReject}}成功，<em class="red">{{signFailNum}}</em>份合同{{approvalOrReject}}失败。</div>
                    <div class="fail-reason-list">失败原因：{{failReasonList.join('；')}}。
                    </div>
                    <div style="color:#bbb">{{approvalOrReject}}失败的合同可以在【待处理】栏查看。</div>
                </div>
                <div class="f14 bold" v-if="signFailNum == 0">批量{{approvalOrReject}}成功！{{approvalOrReject}}成功的合同可在【已处理】栏内查看</div>
                <div v-if="signFailNum > 0">※若有疑问请联系平台客服：<em class="blue">{{$platformContact()['hotLine']}} （{{$platformContact()['hotLineTime']}}</em></div>
            </div>
            <div class="sign-result">
                <el-button @click="approavlResultDialogVisible=false" size="mini" style="border: 1px solid #000;background: #fff">知道了</el-button>
            </div>
         </el-dialog>
        <!--关闭审批-->
        <el-dialog class="dialog" title="关闭原因" :append-to-body="true" :lock-scroll="true" :visible.sync="closeApproavlDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;closeReason = ''">
            <div class="line-top"></div>
            <div class="f14" style="text-align: left;margin-bottom: 10px;">关闭后，系统会将关闭原因反馈给合同创建人。</div>
            <div class="f14" style="text-align: left">请填写关闭原因：</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="closeReason" placeholder="请填写关闭原因,300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button :disabled="!closeReason" type="primary" size="small" style="width: 100px" @click="handleCloseConfirm('approval')">提交关闭</el-button>
                <el-button size="small" style="width: 100px" @click="closeApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--确认撤回审批-->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="cancleApproavlDialogVisible" width="840px" center :close-on-click-modal="false" :show-close="false">
            <div class="f14 form-btns" style="margin-bottom: 10px">确认要撤回合同审批？撤回后的合同，在【待处理】中查看。</div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleCanceledConfirm()">确定撤回</el-button>
                <el-button size="small" style="width: 100px" @click="cancleApproavlDialogVisible = false">取消</el-button>
            </div>
         </el-dialog>
        <!--关闭解除合同流程-->
        <el-dialog class="dialog" title="供应商拒绝解除合同" :append-to-body="true" :lock-scroll="true" :visible.sync="closeRelveveOrderDialogVisible" width="840px" center :close-on-click-modal="false">
            <div class="line-top"></div>
            <div class="f14" style="text-align: left;margin-bottom: 10px;">
                合同拒绝解除原因：{{relieveComment}}
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button size="small" style="width: 100px" @click="handleCloseConfirm('relieve')">知道了</el-button>
                <!--<el-button size="small" style="width: 100px" @click="closeRelveveOrderDialogVisible = false">取消</el-button>-->
            </div>
        </el-dialog>
        <!--发起单个审批-->
        <BrokerApproval ref="brokerApproval" @close="handleCloseApproval(true)"></BrokerApproval>
        <!--合同解除-->
        <ConfirmRelieveOrder ref="confirmRelieveOrder" @close="handleCloseApproval"></ConfirmRelieveOrder>
        <!--资料下载-->
        <!-- 合同签章 -->
        <Loading :is-loading="isLoading"></Loading>
        <el-dialog class="dialog dialog-drafts" title="签字意见" :append-to-body="true" :lock-scroll="true" :visible.sync="isShwoAnnotationDialog" width="840px" center :close-on-click-modal="true">
            <div class="dialog-annotation">
                <el-input type="textarea" placeholder="请填写签字意见" v-model="signaturePpinion" maxlength="300"> </el-input>
                <div class="btn-container">
                    <el-button type="primary" size="small" style="width: 100px"  @click="handleClickSubmitAnnotation">
                        提交
                    </el-button>
                    <el-button size="small" style="width: 100px" @click="isShwoAnnotationDialog = false"
                        >取消
                    </el-button>
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import accountMixin from "@/mixins/account";
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import OrderListOperate from "@/components/order/OrderListOperate";
    import ContractOperate from "@/components/order/ContractOperate";
    import SignProcessOrderList from "@/components/order/SignProcessOrderList";
    import BrokerApproval from "@/components/order/broker//BrokerApproval";
    import { InterfaceService } from "@/services/api";
    import { filterEventByAcct } from '@/utils/orderUtil';
    import ConfirmRelieveOrder from "@/components/order/dialog/orderOperate/ConfirmRelieveOrder";
    import download from "@/utils/download";
    import {DateUtil} from '@/utils/dateUtil';

    const params = {
        procDefKeyList: ["CONTRACT_APPROVE_WF", "CONTRACT_TERMINATE_WF", "CONTRACT_TERMINATE_BROKER_WF"],
        cityCompany:"",
        projectName:"",
        year:"",
        season:"",
        tab:"",
        executionStatus:"",
        pageIndex: 1,
        approveStatus:"",
        pageSize:10,
        contractName: '', // 搜索
    };

    export default {
        mixins: [accountMixin],
        components: {
            Loading,
            PanelTitle,
            OrderListOperate,
            ContractOperate,
            SignProcessOrderList,
            BrokerApproval,
            ConfirmRelieveOrder
        },
        data() {
            return {
                tab: "",
                tabs: [],
                form: Object.assign({}, params),
                allChecked: true,
                disableAllCheck: false,
                hasChecked: true,
                sortList: [0, 1, 0],
                statusList: [],
                overStatusList: [],
                productList: [],
                total: 0,
                isLoading: false,
                storeParams: {},
                signbrokerApprovalList:[],
                brokerApprovalList:[],
                contractApproveInfos:[],
                batchApproavlDialogVisible:false,
                selectedSignLength:0,
                cityCompanyList:[],
                projectNameList:[],
                oldContractName:"",
                externalSysList:[],
                approavlResultDialogVisible:false,
                closeApproavlDialogVisible:false,
                cancleApproavlDialogVisible:false,
                rejectedDialogVisible:false,
                signFailNum:"",
                signResultTitle:"",
                presentTime:"",
                comment:"",
                AllorERP:"1",
                seasonList:[
                    {season:"全部季度",value:""},
                    {season:"第一季度",value:"1"},
                    {season:"第二季度",value:"2"},
                    {season:"第三季度",value:"3"},
                    {season:"第四季度",value:"4"},
                ],
                executionId:"",
                canceleExecutionId:"",
                closeExecutionId:"",
                closeOrderNo:"",
                handleCloseName:"",
                rejectedReason:"",
                closeReason:"",
                relieveComment:"",
                closeProcDefKey:"",
                closeRelveveExecutionId:"",
                startApproval:false,
                operateApproval:false,
                financeApproval:false,
                managerApproval:false,

                ccTabVisible:"0",
                approvalOrReject:"",
                ccTabVisibleType:true,
                closeRelveveOrderDialogVisible:false,
                formPath:{},
                entryNum:0,
                failReasonList:[],
                isShwoAnnotationDialog: false, // 是否显示批注弹窗
                signaturePpinion: '', // 签字意见
                annotationExecutionId: '', // 批注 -流程实例ID
            };
        },
        computed: {
            // 是否显示批注
            isShowAnnotation() {
              return (item) => {
                let mapState = false, state = false;
                this.$store.state.userInfo.roleIds.map(mapItem => {
                    if(mapItem.roleId == item.fwRole) {
                        mapState = true
                    }
                })
                if (this.tab == 1 && mapState && item.fwStatus == '3') {
                    state = true
                }
                return state;
              }

            }
        },
        filters: {
            percent(val) {
                return (val * 100)+ "%";
            }
        },
        methods: {
            // 下拉框改变
           handleDropdownSelectChange (){
                this.form.pageIndex = 1
                this.getApprovalList()
            },
            // 修改tab
            handleChangeTab(tab) {
                this.tab = tab.index;
                let date = new Date;
                let year = date.getFullYear();
                this.recoverStatus(this.tab);
                // 进入已处理时间默认显示当前年份
                this.tab == "3" || this.tab == "4" ? this.form.year = String(year) : this.form.year = "";
                this.form.pageIndex  = 1;
                this.getApprovalList();
            },
            // 查看详情
            handleOpenDetail(item) {
                // 记录进入详情页前的form参数
                // for (let i in this.form) {
                //     if (this.form[i]) {
                //         this.formPath[i] = this.form[i];
                //     }
                // }
                // this.formPath = this.$clone(this.form);
                // this.$setRootScope('formPath', JSON.stringify(this.formPath));
                let executionId = item.executionId,
                 orderNo = item.orderNo,
                 procDefKey = item.procDefKey;

                const { href } = this.$router.resolve({
                    path: "/brokerApprovalDetail",
                    query: {
                        executionId,
                        orderNo,
                        procDefKey,
                    },
                });
                window.open(href, '_blank');
            },
            // 全选
            handleAllSelectTableRow(bool) {
                let arr = [];
                arr = [].concat(this.contractApproveInfos);
                console.log(this.conItractApproveInfos);
                arr.forEach(item => {
                    item.checked = bool;
                });
                if (arr.length != 0){
                    this.contractApproveInfos = arr;
                }else {
                    this.allChecked = false
                }
                this.checkBatch();
            },
            // 选中行
            handleSelectTableRow(item, index) {
                this.$set(this.contractApproveInfos, index, item);
                this.checkBatch();
                this.checkAllSelect();
            },

            // 刷新列表
            // 批量确认合同弹窗
            handleBatchOrderConfirm() {
                this.batchApproavlDialogVisible = true;
                const signbrokerApprovalList = [];
                this.contractApproveInfos.forEach(item => {
                    if (item.checked) {
                        signbrokerApprovalList.push(item);
                    }
                });
                this.signbrokerApprovalList = signbrokerApprovalList;
                this.selectedSignLength = this.signbrokerApprovalList.length
            },
            // 批量确认合同完成
            handleApprovalConfirm(item){
                // this.brokerApprovalList.forEach(_item=>{
                //     if (_item.contractApproveInfos.executionId == item.executionId){
                //         order = _item
                //     }
                // });
                this.$refs["brokerApproval"].open(item.executionId);
            },

            /**
             * 流转意见 - 批注
             */
            handleAnnotation(item) {
                console.log(item,'--i')
                this.annotationExecutionId = item.executionId
                this.signaturePpinion = ''
                this.isShwoAnnotationDialog = true
            },

            /**
             *  流转意见 - 批注 - 提交
             */
            handleClickSubmitAnnotation() {
                this.handleConfirm('Annotation');
                // this.$message.success('批注操作成功!')
                this.isShwoAnnotationDialog = false;
            },
            handleConfirmDialog(type){
                let content = "";
                let message = "";
                if (type == "Y") {
                    content = "确认批量审核吗？";
                    message = "批量审核成功！"
                } else if (type == "N") {
                    content = "确认批量退回吗？";
                    message = "批量退回成功！";
                }
                this.$confirm(
                    content,
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认",
                        cancelButtonText: '取消',
                    }).then(() => {
                    this.handleConfirm(type);
                })
            },
            // 审批，非发起审批
            handleConfirm(type){
                let executionList = [];
                if (!this.comment) {
                    this.comment = "同意"
                }
                //同意
                if (type == 'Y'){
                    this.signbrokerApprovalList.forEach(item=>{
                        executionList.push({
                            executionId: item.executionId,
                            isAgree: "Y",
                            comment: this.comment
                        })
                    });
                // 退回
                }else if (type == 'N') {
                    this.signbrokerApprovalList.forEach(item=>{
                        executionList.push({
                            executionId: item.executionId,
                            isAgree: "N",
                            comment:this.comment
                        })
                    });
                } else if (type === 'Annotation') {
                    executionList.push({
                            executionId: this.annotationExecutionId || '',
                            isAgree: "Y",
                            comment: this.signaturePpinion || ''
                    })
                }

                const params = {
                    executionList: executionList
                };
                InterfaceService.batchApprovalProcess(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            this.approvalResult = data.respData.respList;
                            let failNum = 0;                              // 批量审批失败的数量
                            let successNum = 0;
                            let hash=[];
                            this.failReasonList = [];
                            this.approvalResult.forEach(item=>{
                                console.log(item.approveCode);
                                if (item.approveCode == "0000"){
                                    successNum ++;
                                } else {
                                    failNum ++;
                                    hash.push(item.approveMsg);
                                }
                            });
                            //  审批失败时返回的Msg去重
                            for (let i = 0; i < hash.length; i++) {
                                for (let j = i+1; j < hash.length; j++) {
                                    if(hash[i]===hash[j]){
                                        ++i;
                                    }
                                }
                                this.failReasonList.push(hash[i]);
                            }
                            if (failNum == 0) {
                                 let msg = ''
                                if(type === 'Annotation') {
                                    msg = "批注成功!";
                                } else {
                                    msg = "批量审批操作成功";
                                    type == 'Y' ? msg : msg = "批量退回操作完成";
                                }
                                this.$message.success(msg);
                                this.getApprovalList();
                            } else {
                                type == 'Y' ? this.approvalOrReject = "审批" : this.approvalOrReject = "退回";
                                this.approavlResultDialogVisible = true;
                            }
                            this.signFailNum = failNum;
                            this.selectedSignLength = successNum;
                            this.rejectedReason = "";
                            this.batchApproavlDialogVisible = false;
                            this.rejectedDialogVisible = false;
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            // 审批撤回弹窗
            handleCanceled(item){
                this.cancleApproavlDialogVisible = true;
                        this.canceleExecutionId = item.executionId
            },
            // 关闭流程弹窗
            handleClose(item){
                this.closeApproavlDialogVisible = true;
                this.closeExecutionId = item.executionId;
                this.handleCloseName = item.contractName;
                this.closeProcDefKey = item.procDefKey;
                this.closeOrderNo = item.orderNo

            },
            //关闭解除合同流程
            handleCloseRelveveOrder(item){
                this.closeRelveveOrderDialogVisible = true;
                this.closeRelveveExecutionId = item.executionId;
                this.relieveComment = item.comment
                this.closeProcDefKey = item.procDefKey
            },
            //  确认撤回
            handleCanceledConfirm(){
                const params = {
                    executionId : this.canceleExecutionId
                };
                InterfaceService.revokeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("撤回成功");
                            this.form.pageIndex = 1;
                            this.getApprovalList();
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
                this.cancleApproavlDialogVisible = false;

            },
            //  确认关闭
            handleCloseConfirm(type){
                let params = {};
                if (type == "approval") {
                    if (this.closeExecutionId) {
                        params = {
                            executionId : this.closeExecutionId,
                            procDefKey: this.closeProcDefKey,
                            comment: this.closeReason,
                        };
                    }
                } else if (type == "relieve") {
                    params = {
                        executionId : this.closeRelveveExecutionId,
                        procDefKey: this.closeProcDefKey,
                        comment: this.relieveComment,
                    };
                }
                InterfaceService.closeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            if (type == "approval") {
                                this.$message.success("关闭成功");
                                this.closeApproavlDialogVisible = false;
                                this.closeReason = "";
                            }else if (type =="relieve") {
                                this.$message.success("操作成功");
                                this.closeRelveveOrderDialogVisible = false;
                            }
                            this.form.pageIndex = 1;
                            this.getApprovalList();
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleConfirmRelieveDialog(item,type){
                this.$refs["confirmRelieveOrder"].open(item,"broker",type);
            },
            handleCloseApproval(bool) {
                if (bool) {
                    this.form.pageIndex = 1;
                    this.getApprovalList()
                }
            },
            handleClear(){
                this.comment = "";
                this.entryNum = 0
            },
            //资料下载
            handleBatchDownload(item) {
                let DownloadExecutionId = "";
                DownloadExecutionId = item.executionId;
                if (!DownloadExecutionId) {
                    return
                }else {
                    const params = {
                        executionId: DownloadExecutionId,
                        procDefKey:item.procDefKey
                    };
                    InterfaceService.approvalDataDownload(
                        params,
                        data => {
                            if (data.respData.respCode === "0000") {
                                let packingUrl = data.respData.attachUrl || "";
                                if (!packingUrl){
                                    return
                                }
                                window.open(packingUrl, "_blank");
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        },
                        data => {},
                        () => {
                            this.isLoading = true;
                        },
                        () => {
                            this.isLoading = false;
                        }
                    )
                }
            },
            handleEntry(ev){
                this.entryNum = ev.length
            },
            handleDownload(packingUrl) {
                let name = packingUrl.split("?")[0];
                name = name.split("/").pop();
                const files = [
                    { name: decodeURIComponent(name), url: packingUrl }
                ];
                this.$download(files).then(() => {
                    this.$message.success("已下载");
                });
            },
            // 分页跳转
            handleCurrentChange(page) {
                this.form.pageIndex = page;
                this.getApprovalList();
                console.log(
                this.form.pageIndex , '123')
                window.scrollTo(0,0);
            },
            //进行中、关闭、完结状态
            changeExecutionStatus(type){
                this.form.executionStatus = type;
                this.form.pageIndex = 1;
                this.getApprovalList()
            },
            //全部、ERP状态
            changeApproveStatus(type){
                this.form.approveStatus = type;
                this.form.pageIndex = 1;
                this.getApprovalList()
            },
            // 是否全选
            checkAllSelect() {
                this.allChecked = this.contractApproveInfos.every(item => {
                    return item.checked;
                });
            },
            // 是否可批量
            checkBatch() {
                this.hasChecked = this.contractApproveInfos.some(item => {
                    return item.checked;
                });
                let num = 0;
                this.contractApproveInfos.forEach(item=>{
                    if (item.checked){
                        num++
                    }
                });
                this.selectedSignLength = num
            },
            // 恢复状态
            recoverStatus(tab) {
                this.form.tab = tab;
                this.form.executionStatus = "";
                this.form.approveStatus = "";
                this.form.cityCompany="";
                this.form.projectName="";
                this.form.year="";
                this.form.season="";
                this.form.contractName = "";
            },
            // 待签署合同
            init() {
                this.getcTabVisible();
                this.getAccountInfo();
                // this.getApprovalList();
            },
            //第一次去看是否抄送可见
            getcTabVisible(){
                let params = {
                    "procDefKeyList":["CONTRACT_APPROVE_WF", "CONTRACT_APPROVE_WF", "CONTRACT_TERMINATE_BROKER_WF"],
                    "tab":"1",
                    "pageIndex":1
                };

                InterfaceService.getApprovalList(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.brokerApprovalList = data.respData.executionList || [];
                            this.ccTabVisible = data.respData.ccTabVisible;
                            this.ccTabVisibleType = this.ccTabVisible == "1";
                            if (this.ccTabVisibleType) {
                                this.tabs = [
                                    { label: "流程抄送", index: "4" , active: true},
                                ];
                                this.tab = "4";
                                this.form.tab = "4"
                            }else {
                                if (this.startApproval){
                                    this.tabs = [
                                        { label: "待处理", index: "1"},
                                        { label: "等待中", index: "2" },
                                        { label: "已处理", index: "3" },
                                    ];
                                } else if (this.managerApproval) {
                                    this.tabs = [
                                        { label: "待处理", index: "1"},
                                        { label: "已处理", index: "3" },
                                        { label: "抄送流程", index: "4" },
                                    ]
                                }else {
                                    this.tabs = [
                                        { label: "待处理", index: "1"},
                                        { label: "已处理", index: "3" },
                                    ]
                                }
                                this.tab = "1";
                                this.form.tab = "1";
                            }
                            this.getApprovalList();
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            filterContractName(item) {
                let name = "";
                    // if (item.orderStatus == 'contractTerminating' || item.orderStatus == 'contractTerminated') {
                    //     name = "关于<" + item.contractName +">之解除协议"
                    // } else {
                    //     name = item.contractName
                    // }
                if (item.procDefKey == 'CONTRACT_TERMINATE_BROKER_WF') {
                    name = "关于<" + item.contractName +">之解除协议"
                } else {
                    name = item.contractName
                }
                return name
            },
            getAccountInfo(){
                this.roleIds.forEach(role=> {
                    console.log(role, 'role');

                    //招采部
                    if (role.roleId == "1002") {
                        this.startApproval = true;
                    }
                    // //工程部
                    if (role.roleId == "1003") {
                        this.operateApproval = true;
                    }
                    // //财务部
                    if (role.roleId == "1004" ) {
                        this.financeApproval = true;
                    }
                    // 总经理 || 副总经理
                    if (["1000", "1001"].includes(role.roleId)) {
                        this.managerApproval = true
                    }
                })
            },
            getApprovalList() {
                this.brokerApprovalList = [];
                this.contractApproveInfos = [];
                // this.total = 0;
                // this.recordFormData();
                let params = {};
                // console.log();
                //  获取进入详情页的form参数
                // let oldApprovalPath = JSON.parse(this.$getRootScope('formPath'));
                // if (oldApprovalPath != null && Object.keys(oldApprovalPath).length != 0) {
                //     this.form = this.$clone(oldApprovalPath);
                //     this.tab = oldApprovalPath.tab;
                // }
                params = this.$clone(this.form);
                this.tabs.forEach((item) => {
                    if (item.index == this.tab) {
                        item.active = true
                    }
                });
                delete params.status;
                InterfaceService.getApprovalList(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.brokerApprovalList = data.respData.executionList || [];


                            console.log(this.brokerApprovalList, 'brokerApprovalList');

                            this.brokerApprovalList.forEach(item => {
                                item.contractApproveInfos.executionId = item.executionId;
                                item.contractApproveInfos.executionStatus = item.executionStatus;
                                item.contractApproveInfos.procDefKey = item.procDefKey;
                                if (item.creTm) {
                                    item.contractApproveInfos.creTm = item.creTm.substring(0,10);
                                }
                                if (item.comment){
                                    item.contractApproveInfos.comment = item.comment;
                                    item.contractApproveInfos.acctName = item.acctName
                                }

                                //   fwStatus	String	转发状态,1:转发，2：被转发（流程表）
                                item.contractApproveInfos.fwStatus = item.fwStatus
                                item.contractApproveInfos.fwRole = item.fwRole
                                // item.contractApproveInfos.comment = "大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦大撒旦撒旦"
                                // item.contractApproveInfos.acctName = "第三代的是大厦大厦"

                                // num++
                                if (item.procDefKey == "CONTRACT_APPROVE_WF") {
                                    if (item.executionStatus == 'processing'){
                                        item.contractApproveInfos.status = "processing";
                                        item.contractApproveInfos.disc = "进行中";
                                    }else if (item.executionStatus == 'end') {
                                        item.contractApproveInfos.status = "end";
                                        item.contractApproveInfos.disc = "已归档"
                                    }else if (item.executionStatus == 'closed'){
                                        item.contractApproveInfos.status = "closed";
                                        item.contractApproveInfos.disc = "已关闭"
                                    }else if (item.executionStatus == 'rejected'){
                                        item.contractApproveInfos.status = "rejected"
                                        item.contractApproveInfos.disc = "已退回";
                                    }else if (item.executionStatus == 'canceled'){
                                        item.contractApproveInfos.disc = "已撤回";
                                        item.contractApproveInfos.status = "canceled"
                                    }else if (item.executionStatus == 'forward'){
                                        item.contractApproveInfos.disc = "转发中";
                                        item.contractApproveInfos.status = "forward"
                                    }
                                }else if (item.procDefKey == "CONTRACT_TERMINATE_BROKER_WF") {
                                    if (item.contractApproveInfos.orderStatus == 'contractTerminating'){
                                        if (item.executionStatus == 'rejected'){
                                            item.contractApproveInfos.status = "rejected";
                                            item.contractApproveInfos.disc = "已退回";
                                        }else {
                                            item.contractApproveInfos.status = "end";
                                            item.contractApproveInfos.disc = "合同解除中";
                                        }
                                    }else if (item.contractApproveInfos.orderStatus == 'contractTerminated') {
                                        item.contractApproveInfos.status = "end";
                                        item.contractApproveInfos.disc = "已解除合同"
                                    }else {
                                        if (item.executionStatus == 'closed'){
                                            item.contractApproveInfos.status = "closed";
                                            item.contractApproveInfos.disc = "解除合同失败"
                                        }
                                    }
                                }
                                this.contractApproveInfos.push(item.contractApproveInfos)
                            });
                            console.log(this.contractApproveInfos);
                            this.contractApproveInfos.forEach(item=>{
                                item.checked = true;
                            });
                            this.allChecked = this.brokerApprovalList.some(item => {
                                return item.executionStatus == 'processing';
                            });
                            // this.selectedSignLength = num;
                            if (this.contractApproveInfos.length == 0){
                                this.allChecked = false;
                                this.hasChecked = false
                            }else {
                                this.allChecked = true;
                            }
                            this.cityCompanyList = data.respData.cityCompanyList;
                            this.projectNameList = data.respData.projectNameList;
                            this.total = data.respData.totalCount;
                            this.form.pageSize = data.respData.pageSize;
                            // this.$removeRootScope('formPath');

                            console.log(this.contractApproveInfos, 'this.contractApproveInfos');

                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },

            recordFormData() {
                let hasChange = false;
                Object.keys(this.storeParams).forEach(key => {
                    if (this.storeParams[key] != this.form[key]) {
                        hasChange = true;
                    }
                });

                if (hasChange) {
                    this.form.pageIndex = 1;
                }

                this.storeParams = this.$clone(this.form);
                delete this.storeParams.pageIndex;
                delete this.storeParams.pageSize;
                delete this.storeParams.executionStatus;
            },

            /**
             * 查询
             */
            handleSearch() {
                // console.log(this.contractName, '321')
                // if (!this.form.contractName) {
                //     this.$message.error('请输入合同名称!')
                //     return
                // }
                this.form.pageIndex = 1;
                this.getApprovalList();
            }
        },
        mounted() {
            if (!this.brokerRole) {
                if (this.role == 'B'){
                    this.$router.push({
                        path : '/purchaserCenter/orderList'
                    });
                }else if (this.role == 'S'){
                    this.$router.push({
                        path : '/vendorCenter/orderList'
                    });
                }
            }else {
                this.init();
            }
        }
    };
</script>

<style lang="scss" scoped>
    .hand + .hand {
        margin-left: 10px;
    }
    .price-tip {
        cursor: pointer;
        color: #a9a9aa;

        &:hover {
            color: #0082ff;
        }
    }

    .product {
        font-size: 14px;
        /deep/ .el-select {
            width: 100%;
        }
        /deep/ .el-col{
            height: 50px;
            margin-bottom: 10px;
            .el-button.active{
                background: #ffd64e;
            }
        }
        /deep/ .el-button--primary {
            height: 40px;
            width: 106px;
        }
        .search-title {
            margin-top: 12px;
            display: block;
            margin-left: 10px;
        }
    }

    .pointer {
        cursor: pointer;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }

        .active {
            color: #ffd64e;
        }
    }

    .nowrap {
        white-space: nowrap;
    }

    .panel-content {
        margin-bottom: 20px;
        padding: 20px 10px;
        background: #f5f5f5;
    }

    .form {
        /deep/ .el-col {
            text-align: left;
            height: 52px;
        }

        /deep/ .el-select {
            width: 100%;
        }
        /deep/ .el-date-editor {
            input.el-input__inner {
                padding: 0 15px;
            }
            .el-input__prefix {
                display: none;
            }
        }

        &:after {
            display: table;
            content: "";
            clear: both;
        }
        /deep/ .third-col{
            .el-form-item__label {
                width: 110px !important;
            }
            .el-form-item__content{
                margin-left: 110px !important;
            }
            .el-input__inner{
                width: 120px;
            }
        }
    }

    .form-item {
        position: relative;
        display: inline-block;
        line-height: 32px;

        .float-right {
            position: absolute;
            top: 2px;
            right: 1px;
            height: 30px;
            padding: 0 7px;
            line-height: 30px;
            background: #ffffff;
        }
    }

    .error-info {
        color: #f56c6c;
        font-size: 12px;
        line-height: 1;
        padding-top: 4px;
        position: absolute;
        top: 100%;
        left: 0;
    }

    .form-btns {
        text-align: center;
    }

    .product-table {
        /deep/ .el-table__body-wrapper {
            font-size: 12px;
        }
        .check-all{
            width: 100%;
            height: 70px;
            line-height: 70px;
            background: #535864;
            color: #fff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px;
            em{
                color: #fa0202;
            }
            .check{
                span{
                    margin-left: 8px;
                }
                /deep/ .el-checkbox__inner::after{
                    border-bottom:2px #000 solid;
                    border-right:2px #000 solid;
                }
            }
            .sign{
                .el-button{
                    margin-left: 20px;
                    background: #ffd64e;
                    border: none;
                    width: 110px;
                    height: 34px;
                }
            }
        }
        .contract{
            span{
                color: #f00;
            }
        }
        /deep/ .el-table th,
        .el-table td {
            padding: 14px 0;
        }

        /deep/ .el-button {
            font-size: 12px;
        }

        table {
            table-layout: fixed;
            width: 100%;
            line-height: 23px;
            font-size: 12px;
            td,th {
                padding: 14px 10px;
                vertical-align: middle;
                word-break: break-word;
                text-align: center;
            }
            thead {
                font-size: 14px;
                text-align: center;
                white-space: nowrap;
                color: #909399;
                background: #f5f5f5;
                th{
                    text-align: left;
                }
            }
            .tbody-row{
                td{
                    text-align: left;
                }
                /deep/ .el-button{
                    height: 28px;
                    width: 80px;
                    padding: 0;
                    margin:0 0 10px;
                    span{
                        line-height: 28px;
                    }
                }
            }
            .tbody-row:hover {
                background: #e8f3fd;
            }

            tbody {
                text-align: center;
                tr {
                    &.sign-content {
                        display: none;
                        background: #f0f8ff;

                        &:hover {
                            display: table-row;
                        }

                        td {
                            padding: 0;
                            border-bottom: none;
                        }
                    }

                    &.all-check {
                        text-align: left;

                        &:hover{
                            background: #ffffff;
                        }
                    }
                }

                tr:hover + tr.sign-content {
                    display: table-row;
                }

                td {
                    border-bottom: 1px solid #ebeef5;
                }
                .retreat{
                    height: 20px;
                    td:nth-of-type(1){
                        width: 600px;
                    }
                    td{
                        background: #eee;
                        text-align: left;
                        padding: 0;
                        text-indent: 2em;
                        overflow:hidden;
                        white-space:nowrap;
                        text-overflow:ellipsis;
                    }
                }
            }
        }

        .product-name {
            display: inline-flex;
            width: 100%;
            vertical-align: top;
            line-height: 20px;

            img {
                width: 75px;
                height: 75px;
            }

            .left {
                margin-right: 10px;
            }

            .right {
                text-align: left;

                p:first-child {
                    margin-bottom: 10px;
                }
                p:last-child {
                    word-break: break-all;
                    max-height: 40px;
                    overflow: hidden;
                    color: #969799;
                }
            }
        }
    }

    .product-empty {
        padding: 150px;
        text-align: center;
        line-height: 50px;
        color: #909399;
    }

    .price-popover {
        display: flex;
        color: #ababac;

        > div:first-child {
            margin-right: 10px;
        }

        p:first-child {
            padding: 0 5px;
            border-left: 3px solid #ffd64e;
            line-height: 15px;
        }

        p:last-child {
            margin-top: 10px;
            color: #ffffff;
        }
    }

    .table-pagination {
        margin: 50px 0 80px;
        text-align: center;
        color: #888888;
    }
    /deep/ .el-dialog__title{
        font-size: 16px;
    }
    .contract-list{
        width: 800px;
        height: 286px;
        margin: 10px auto 10px;
        background: #eeeeee;
        overflow: auto;
        p{
            padding-left: 24px;
            height: 40px;
            line-height: 40px;
            border-bottom: 1px solid #fff;
        }
    }
    .order-sign {
        /*padding: 8px 15px;*/

        i {
            margin-right: 3px;
            margin-bottom: 3px;
            background-size: 100%;
            vertical-align: middle;
        }
    }
    /deep/ .el-pagination__jump{
        .el-input{
            width: auto;
        }
    }
    .sign-result-dialog{
        /deep/ .el-dialog__body{
            width: 100%;
        }
        .fail-reason-list{
            line-height: 25px;
        }
        div{
            margin: 20px auto 20px;
        }
        /deep/ .el-button{
            margin: auto;
        }
    }
    .sign-result{
        text-align: center;
        .el-button{
            background: #ffd64e;
            border: none;
            width: 110px;
            height: 34px;
            /*padding-top: 12px;*/
            font-weight: bold;
        }
    }
    .specifications-choose {
        overflow: hidden;
    }
    .specifications-choose ul {
        width: 604px;
        overflow: hidden;
    }
    .specifications-choose ul li {
        padding: 8px;
        float: left;
        line-height: 20px;
        border: 1px solid #dddddd;
        color: #4f525a;
        margin-right: 20px;
        position: relative;
        cursor: pointer;
    }
    .specifications-choose ul li.active {
        padding: 8px;
        border: 2px solid #4f525a;
    }
    .specifications-choose ul li.active:after {
        content: "";
        position: absolute;
        height: 25px;
        width: 25px;
        bottom: -2px;
        right: -2px;
        background: url(../../../assets/images/detail/right.png) no-repeat;
        z-index: 5;
    }
    /deep/ .el-dialog__header:before {
        height: 0;
    }
    .line-top{
        width: 95%;
        height: 1px;
        background: #eee;
        position: absolute;
        top:65px;
    }
    /deep/ .el-pagination__editor.el-input .el-input__inner{
        width: 45px;
    }
    .count{
        float: right;
        width: 100%;
        text-align: right;
        margin-bottom: 20px;
        span.red{
            color: #f00;
        }
    }
    /deep/.textareaContainer {
        .el-textarea__inner {
            min-height: 140px !important;
        }
    }
    .dialog-annotation {
        /deep/ .el-textarea .el-textarea__inner {
            resize: none;
            width: 100%;
            height: 90px !important;
        }
        .btn-container {
            margin-top: 24px;
            text-align: center;
            padding-bottom: 12px;
        }
    }
</style>




