<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <div class="app-search-bar isWhiteBg">
            <div class="search-bar-container inner-container" style="position: relative;">
                <div class="index-logo">
                    <div class="logo">
                        <h1>
                            <router-link to="/home" class="logo-bd"></router-link>
                        </h1>
                    </div>
                </div>
                <ViceHeader :title="'发起要货 - 第'+ orderInfo.requireBatchNo +'批'" :flow="flow"></ViceHeader>

                <div class="order-process-top">
                    <template v-if="role === 'S'">
                        <label class="order-process-label" :class="{'active':item.active,'end':index===supplierProcess.length-1}" v-for="(item,index) in supplierProcess" :key="index" v-if="index!==0">{{item.label}}</label>
                    </template>
                    <template v-else>
                        <label class="order-process-label" :class="{'active':item.active,'end':index===proProcess.length-1}" v-for="(item,index) in proProcess" :key="index" v-if="index!==0">{{item.label}}</label>
                    </template>
                </div>
            </div>
        </div>
        <div class="inner-container">
            <!-- 要货单信息 -->
            <div class="order-info">
                <div class="order-info-header">
                    <PanelTitle title="当前签署情况"></PanelTitle>
                    <!--<a class="link" @click="handleViewNotice">《发货通知单》</a>-->
                </div>
                <SignProcessRequire type="1" :order="orderInfo"></SignProcessRequire>

                <PanelTitle title="合同基本信息"></PanelTitle>
                <el-row>
                    <el-col :span="8">
                        <p><label>合同编号：</label>
                            <span>{{orderInfo.orderNo}}</span>
                        </p>
                    </el-col>
                    <el-col :span="8">
                        <p><label>合同名称：</label>
                            <span>{{orderInfo.contractName}}</span>
                        </p>
                    </el-col>
                    <el-col :span="8">
                        <p v-if="role=='S'">
                            <label>采购商：</label>{{orderInfo.purchaserName}}</p>
                        <p v-if="role=='B'">
                            <label>供应商：</label>{{orderInfo.supplierName}}</p>
                    </el-col>
                    <el-col :span="8">
                        <p><label>备货周期：</label>
                            <span v-if="orderInfo.prepareCycle">{{orderInfo.prepareCycle}}日历天</span>
                        </p>
                    </el-col>
                    <el-col :span="8" v-for="(item,index) in filterRole(orderInfo.contractStakeHolders)" :key="index">
                        <p><label>{{item.roleName}}：</label>
                            <span>{{item.acctName}}&nbsp;
                                <template v-if="item.mobile">(Tel:{{item.mobile}})</template>
                            </span>
                        </p>
                    </el-col>
                </el-row>
            </div>
            <!-- 要货单列表 -->
            <div class="order-list">
                <PanelTitle title="确认要货货品"></PanelTitle>
                <div class="table">
                    <table>
                        <thead>
                            <tr>
                                <td width="260">商品名/型号</td>
                                <!-- <td>剩余可要货数量</td> -->
                                <td width="310">本批次要货数量</td>
                                <td width="310">使用标段或部位</td>
                                <td width="310">备注</td>
                            </tr>
                        </thead>
                        <tbody v-if="requireList.length">
                            <tr v-for="(row,index) in requireList" :key="index">
                                <td>
                                    <div class="order-name">
                                        <div class="left">
                                            <img :src="row.attachpicUrl" v-error-img>
                                        </div>
                                        <div class="right">
                                            <p>
                                                <router-link :to="{path:'/productDetail',query:{id:row.spuId}}">{{ row.skuName }}</router-link>
                                            </p>
                                            <p>型号：{{row.model}}</p>
                                        </div>
                                    </div>
                                </td>
                                <!-- <td>{{row.requireLeft||''}}{{row.goodsUnit||''}}</td> -->
                                <td>
                                    <p v-for="(req,ind) in row.goodsList" :key="ind">
                                        {{+req.requireCount||''}}{{req.goodsUnit||''}}
                                    </p>
                                </td>
                                <td>
                                    <p v-for="(req,ind) in row.goodsList" :key="ind">
                                        {{req.location || "无"}}
                                    </p>
                                </td>
                                <td>
                                    <p v-for="(req,ind) in row.goodsList" :key="ind">
                                        {{req.remark || "无"}}
                                    </p>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="table-pagination" v-if="requireList.length">
                        <el-pagination  @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                        </el-pagination>
                    </div>
                </div>
                <div class="order-list-message">
                    <label>采购商留言：</label>
                    <span>{{orderInfo.requireMsg}}</span>
                </div>
            </div>
            <!-- <div class="order-time">
                <PanelTitle title="确认要货信息"></PanelTitle>
                <p>
                    <label>要求到货时间：</label>
                    <span class="red-font">{{orderInfo.requireTimeFrom|datetime}} ~ {{orderInfo.requireTimeTo|datetime}}</span>
                </p>
            </div> -->
            <!-- 要货单信息 -->
            <div class="order-total">
                <!-- <p class="total-content">
                    <label>本批次总额(税前)：￥{{orderInfo.requireAmountTotal|formatMoney}}</label>
                    <label>本批次增值税税率：{{orderInfo.requireTaxRateRange}}</label>
                    <label>本批次增值税税额：￥{{orderInfo.requireTaxAmt|formatMoney}}</label>

                    <label class="total">本批次总额(含税)：
                        <span class="red-font">￥
                            <span class="big">{{orderInfo.requireAmountWithTax|formatMoney}}</span>
                        </span>
                    </label>
                </p> -->
                <p style="font-weight:bold;color:#444;">要求到货时间：
                    <span class="red-font">{{orderInfo.requireTimeFrom|datetime}} ~ {{orderInfo.requireTimeTo|datetime}}</span>
                </p>
                <p>送货至：{{orderInfo.consigneeAddr}}</p>
                <p>收货人：{{orderInfo.consigneeName}}&nbsp;{{orderInfo.consigneeMobile}}</p>
            </div>

            <div class="tr order-sign">
                <!--<p class="fl order-process">流水：-->
                    <!--<template v-if="role === 'S'">-->
                        <!--<label class="order-process-label" :class="{'active':item.active,'end':index===supplierProcess.length-1}" v-for="(item,index) in supplierProcess" :key="index">{{item.label}}</label>-->
                    <!--</template>-->
                    <!--<template v-else>-->
                        <!--<label class="order-process-label" :class="{'active':item.active,'end':index===proProcess.length-1}" v-for="(item,index) in proProcess" :key="index">{{item.label}}</label>-->
                    <!--</template>-->
                <!--</p>-->

                <!-- <span style="margin-right: 20px;">签署情况查看
                    <a class="link" @click="handleViewNotice">《发货通知单》</a>
                </span> -->
                <!-- <el-button v-if="role=='B'&&orderInfo.requireStatus=='01'" class="btn-bottom" type="primary" size="large" @click="handleSubmit">提交要货单</el-button> -->

            </div>
        </div>
        <FixBottom>
            <div class="fix-bottom">
                <div class="fr">
                    <el-button v-if="!checkEventRole()" class="btn-bottom" size="large" disabled>已创建</el-button>
                    <el-button v-if="checkEventRole()=='finish'" class="btn-bottom" size="large" disabled>已签章</el-button>
                    <el-button @click="handleViewNotice" class="btn-bottom" size="large">预览发货单</el-button>
                    <el-button v-if="checkEventRole()=='unfinish'" class="btn-bottom" type="primary" size="large" @click="handleSign">确认并签章</el-button>
                </div>
            </div>
        </FixBottom>
        <!-- 提交要货单 -->
        <SubmitRequireDialog ref="submitRequireDialog" @close="handleCloseSubmitRequire"></SubmitRequireDialog>

        <!-- 签章 -->
        <SignatureDialog ref="signatureDialog" @close="handleCloseSign"></SignatureDialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>
<script>
import accountMixin from "@/mixins/account";
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import ViceHeader from "@/components/base/ViceHeader";
import SubmitRequireDialog from "@/components/order/dialog/SubmitRequire";
import SignatureDialog from "@/components/order/dialog/Signature";
import SignProcessRequire from "@/components/order/SignProcessRequire";

import { InterfaceService } from "@/services/api";
import { filterEventByAcct } from "@/utils/orderUtil";
import FixBottom from "@/components/base/FixBottom";

const supplierProcess = [
    { label: "创建要货单", active: true },
    { label: "供应方授权代表签字", active: false, role: "30" },
    { label: "供应方盖章", active: false, role: "33" }
];

const proProcess = [
    { label: "创建要货单", active: true },
    { label: "城市公司授权代表签字", active: false, role: "21" },
    { label: "城市公司项目部盖章", active: false, role: "25" }
];

export default {
    mixins: [accountMixin],
    components: {
        Header,
        SearchBar,
        Loading,
        PanelTitle,
        ViceHeader,
        SubmitRequireDialog,
        SignatureDialog,
        FixBottom,
        SignProcessRequire
    },
    data() {
        return {
            isLoading: false,
            requireNo: "",
            orderInfo: {},
            requireList: [],
            flow: [
                {
                    name: "创建要货单",
                    active: false,
                    next: true
                },
                {
                    name: "确认并签署要货单",
                    active: true,
                    next: true
                },
                {
                    name: "提交要货单",
                    active: false,
                    next: false
                }
            ],
            supplierProcess: supplierProcess,
            proProcess: proProcess,
            eventList: [],
            attach: {},
            pageSize:1,
            total:0,
            pageIndex:1,
        };
    },
    methods: {
        // 过滤角色
        filterRole(list = []) {
            // const roles = ["00", "01", "10", "20", "21", "30"];
            const roles = ["00","01","10","21","30"];
            return list.filter(item => {
                return roles.indexOf(item.role) !== -1;
            });
        },
        // 查看发货通知单
        handleViewNotice() {
            let link = "";
            const events = this.orderInfo.eventList || [];
            events.forEach(ev => {
                if (ev.eventType == 1 && ev.attachUrl) {
                    link = ev.attachUrl;
                }
            });

            if (link) {
                window.open(link, "_blank");
            } else {
                this.$message.error("暂无发货通知单");
            }
        },
        handleCurrentChange(page) {
            this.pageIndex = page;
            this.getRequireOrderDetail();
            // window.scrollTo(0,0)
        },
        handleSubmit() {
            this.$refs["submitRequireDialog"].open(this.orderInfo);
        },
        handleCloseSubmitRequire(bool) {
            if (bool) {
                this.init();
            }
        },
        // 签署
        handleSign() {
            const events = [];

            this.eventList.forEach(item => {
                if (
                    item.eventType == 1 &&
                    (item.eventStatus == 0 || item.eventStatus == 1)
                ) {
                    events.push(item);
                    this.attach = item;
                }
            });
            this.$refs["signatureDialog"].open(events);
        },
        // 签署完成
        handleCloseSign(bool) {
            if (bool) {
                if (window.opener) {
                    window.opener.location.reload();
                }
                this.getRequireOrderDetail("checkAllSigned")
                this.$router.push({
                    path: "/signRequireSuccess",
                    query: {
                        requireNo: this.orderInfo.requireNo,
                        requireBatchNo: this.orderInfo.requireBatchNo,
                        attachUrl: this.attach.attachUrl
                    }
                });
            }
        },
        getRequireOrderDetail(checkAllSigned) {
            const params = {
                requireNo: this.requireNo,
                pageIndex: this.pageIndex
            };
            InterfaceService.getRequireOrderDetail(
                params,
                data => {
                    //console.log(data);
                    if (data.respData.respCode === "0000") {
                        this.orderInfo = data.respData || {};
                        // this.requireList = data.respData.requireList || [];
                        this.eventList = this.orderInfo.eventList || [];
                        if (checkAllSigned) {
                            this.eventList.forEach(item=>{
                                if (item.eventStatus === "2" && item.eventType === "1") {
                                    this.confirmRequire();
                                }
                            })
                        }
                        this.checkEventRole();
                        this.getOrderRequireGoodsList()
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        //确认要货单
        confirmRequire() {
            const params = {
                requireNo: this.orderInfo.requireNo
            };
            InterfaceService.requireOrderConfirm(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        getOrderRequireGoodsList() {
            InterfaceService.getOrderRequireGoodsList(
                {
                    requireNo : this.requireNo,
                    pageIndex: this.pageIndex
                },
                data => {
                    if (data.respData.respCode == '0000') {
                        this.total = data.respData.totalCount;
                        this.pageSize = data.respData.pageSize;
                        let list = data.respData.requireList || [];
                        let skuList = [];
                        list.forEach(item=>{
                            skuList.push({
                                skuId : item.skuId,
                                attachpicUrl : item.attachpicUrl,
                                model : item.model,
                                spuId : item.spuId,
                                skuName : item.skuName,
                            })
                        });
                        let obj = {};
                        skuList = skuList.reduce(function (item, next) {
                            obj[next.skuId] ? '' : obj[next.skuId] = true && item.push(next);
                            return item;
                        }, []);

                        skuList.forEach(_item=>{
                            _item.goodsList = [];
                            list.forEach(item=>{
                                if (_item.skuId === item.skuId) {
                                    _item.goodsList.push(item)
                                }
                            })
                        });
                        this.requireList = skuList;
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {
                },
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },

        checkEventRole() {
            let status = null;
            let acctIdList = [];
            if (this.userinfo.accountList.length) {
                this.userinfo.accountList.forEach(item=>{
                    acctIdList.push(item.acctId)
                });
            }else {
                acctIdList.push(this.acctId)
            }
            const events = filterEventByAcct(this.eventList, 1, acctIdList);
            events.forEach(ev => {
                if (ev.eventType == 1) {
                    if (ev.processList && ev.processList.length) {
                        status = status || "finish";
                        ev.processList.forEach(process => {
                            if (process.processFlg == 0) {
                                status = "unfinish";
                            }

                            this.arrangeProcessActive(process.role);
                        });
                    }
                }
            });
            return status;
        },
        // 整理角色流程状态
        arrangeProcessActive(role) {
            this.supplierProcess.forEach(item => {
                if (item.role == role) {
                    item.active = true;
                }
            });
            this.proProcess.forEach(item => {
                if (item.role == role) {
                    item.active = true;
                }
            });
        },
        init() {
            this.getRequireOrderDetail();
        }
    },
    mounted() {
        this.requireNo = this.$route.query.requireNo;
        this.init();
    }
};
</script>
<style lang="scss" scoped>
.link {
    text-decoration: underline;
    cursor: pointer;
    color: #0082ff;
    &:hover {
        color: #0082ff;
    }
    &:active {
        color: #4c9cdd;
    }
}

.red-font {
    color: #e94650;
}

.nowrap {
    white-space: nowrap;
}
.btn-top {
    width: 100px;
}

.btn-bottom {
    width: 200px;
    height: 32px;
    line-height: 8px;
}

.inner-container {
    margin-bottom: 100px;
    font-size: 14px;
}

.order-info {
    margin-bottom: 20px;
    line-height: 30px;
    font-size: 12px;

    /deep/ .el-col {
        padding: 0 10px;
    }

    p {
        display: flex;
        padding-right: 10px;
        word-break: break-word;
        white-space: normal;

        & > span {
            display: inline-block;
            flex: 1 1 0%;
        }
    }

    label {
        white-space: nowrap;
        color: #888888;
    }
}

.order-info-title {
    margin: 5px 0;
    margin-bottom: 20px;
    font-size: 14px;
    border-left: 3px solid #000;
    line-height: 12px;
}

.order-info-header {
    position: relative;

    .link {
        position: absolute;
        top: 5px;
        right: 10px;
    }
}

.pointer {
    cursor: pointer;
    &:hover {
        color: #0082ff;
    }
    &:active {
        color: #4c9cdd;
    }

    .active {
        color: #ffd64e;
    }
}

.table {
    margin-bottom: 2px;
    　 /deep/ .el-button {
        font-size: 12px;
    }

    width: 100%;
    line-height: 23px;
    font-size: 12px;
    table {
        width: 100%;
    }
    td {
        padding: 14px 10px;
        vertical-align: middle;
        word-break: break-word;
    }

    thead {
        text-align: center;
        white-space: nowrap;
        font-size: 14px;
        color: #909399;
    }

    tbody {
        text-align: center;

        tr:hover {
            background: #e8f3fd;
        }

        td {
            border-bottom: 1px solid #ffffff;
            background: #f5f5f5;
        }
    }
}

.order-name {
    display: inline-flex;
    width: 100%;
    vertical-align: top;
    line-height: 20px;

    img {
        width: 75px;
        height: 75px;
    }

    a:hover {
        text-decoration: underline;
        color: #0082ff;
    }

    .left {
        margin-right: 10px;
    }

    .right {
        text-align: left;

        p {
            word-break: break-all;
            max-height: 40px;
            overflow: hidden;
        }

        p:first-child {
            margin-bottom: 10px;
        }
        p:last-child {
            max-height: 30px;
            line-height: 15px;
            color: #969799;
        }
    }
}
.error-info {
    color: red;
}

.order-list {
    margin-bottom: 20px;
}

.order-list-message {
    display: flex;
    flex: 1;
    flex-shrink: 0;
    padding: 20px;
    font-size: 12px;
    line-height: 20px;
    color: #888888;
    background: #f5f5f5;
    span {
        display: inline-block;
        flex: 1 1 0%;
        color: #444;
    }

    label {
        white-space: nowrap;
    }
}

.order-time {
    padding: 20px 0;
    font-size: 12px;
    line-height: 25px;
    color: #888888;
}

.order-total {
    // margin-bottom: 40px;
    padding: 20px 40px;
    border-top: 1px solid #e2e2e2;
    text-align: right;
    font-size: 12px;
    line-height: 25px;
    color: #888888;
    background: #f5f5f5;
    p {
        color: #888;
        label {
            display: block;
            color: #444444;
        }
    }
    .total-content {
        margin-bottom: 10px;
    }

    .total {
        font-weight: bold;
        font-size: 14px;
    }

    .bold {
        font-weight: bold;
    }

    .big {
        font-size: 20px;
    }

    .red-font {
        color: #e94650;
    }
}

.order-process,
.order-process-top {
    line-height: 40px;
    .order-process-label {
        &.active {
            font-weight: 600;
            color: #444444;
        }

        &:after {
            content: "";
            display: inline-block;
            width: 30px;
            height: 1px;
            margin: 0 10px;
            vertical-align: middle;
            background: #888888;
        }

        &.end:after {
            display: none;
        }
    }
}

.order-process-top {
    position: absolute;
    bottom: 10px;
    right: 100px;
    padding: 5px 10px;
    line-height: 20px;
    color: #888888;
    background: #f5f5f5;

    &::before {
        content: "";
        position: absolute;
        top: -10px;
        right: 220px;
        border-bottom: 10px solid #f5f5f5;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
    }
}

.order-sign {
    color: #888888;
}
</style>

