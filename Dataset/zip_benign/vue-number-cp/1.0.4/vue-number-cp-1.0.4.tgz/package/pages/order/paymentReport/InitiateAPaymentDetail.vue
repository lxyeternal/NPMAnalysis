
<template>
  <div class="initiate-a-payment-wrap">
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :is-white-bg="true" :progress="`发起请款申请-${baseInfo.askForReasonsValue || ''}`"></SearchBar>
    <div class="inner-container">
      <div class="head-title">
        <span>请款基本信息</span>
      </div>
      <div class="row-container">
        <el-row :gutter="10">
          <el-col class="title" :span="1.5">合同编号：</el-col>
          <el-col :span="7">{{baseInfo.orderNo}}</el-col>
          <el-col class="title" :span="1.5">合同名称：</el-col>
          <el-col :span="14"><span>《{{baseInfo.contractName}}》</span><span class="blue" @click="handleOrderDetail(baseInfo)">查看合同详情</span></el-col>
        </el-row>
        <el-row :gutter="10">
          <el-col class="title" :span="1.5">付款事由：</el-col>
          <el-col :span="7">{{baseInfo.askForReasonsValue}}</el-col>
          <el-col class="title" :span="1.5">采购商：</el-col>
          <el-col :span="14">{{baseInfo.purchaserName}}</el-col>
        </el-row>
      </div>
    </div>

    <div class="inner-container" v-if="isAskForReasons('progress') && ['01', '03'].includes(baseInfo.orderCateCode)">
      <div class="head-title">
        <span>上报完成进度及工作量</span>
      </div>
      <div class="row-container">
        <p>注意：明确施工进度期内的完成面，核算出工程量，产值，并电子签章。</p>
        <el-row :gutter="10">
          <el-col :span="1.5"><i class="red">*</i>上报进度：</el-col>
          <el-col class="el-col-22_5">
            <el-input type="textarea" v-model="progressInfo.outputApplyDesc" :rows="4" placeholder="请输入..." maxlength="600" show-word-limit>
            </el-input>
          </el-col>
        </el-row>
        <dl class="workload-dl">
          <dt>
            <span><i class="red">*</i>上传附件</span>
            <span>
              <UpfileComponent ref="upfileRef" :btnName="'上传'" :immediateClearList="true" :immediateSubmit="true" :showMsg="false" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :dirName="dirNameComputed" :type="'12'" :id="'id'" @outputList="outputUpfileList($event)" />
            </span>
          </dt>
          <dd>
            <el-row class="head" v-if="completeScheduleFiles && completeScheduleFiles.length">
              <el-col :span="14">已上传附件</el-col>
              <el-col :span="6">上传时间</el-col>
              <el-col :span="4" class="txtRight">操作</el-col>
            </el-row>
            <el-row v-for="(item, idx) in completeScheduleFiles" :key="idx">
              <el-col :span="14">{{item.receiptFileName}}</el-col>
              <el-col :span="6">{{item.upfileDate || item.creTm}}</el-col>
              <el-col :span="4" class="txtRight"><span class="blue" @click="handleCompleteDelClick(idx)">删除</span></el-col>
            </el-row>
            <el-row v-if="!(completeScheduleFiles && completeScheduleFiles.length)">
              <el-col :span="24" class="txt-center">暂无附件</el-col>
            </el-row>
          </dd>
        </dl>
      </div>
    </div>

    <div class="inner-container mt40">
      <div class="head-title">
        <span>付款方式</span>
      </div>
      <div class="payment-method" v-html="paymentMethodComputed"> </div>
    </div>

    <div class="inner-container mt40">
      <div class="head-title">
        <span>请款金额</span>
      </div>
      <div class="row-container row-flex-item-align-center">
        <!-- 预付款 -->
        <el-row :gutter="10" v-if="isAskForReasons()">
          <el-col class="title" :span="1.5"><i class="red">*</i>预付比例：</el-col>
          <el-col :span="8" suffix-icon="el-icon-percentage">
            <input size="small" v-input-custom-reg="{reg:'^\\d{1,9}(\\.\\d{0,6})?$|^\s*$'}" placeholder="请输入预付比例" type="number" v-model="prepaymentRatioValue" />
          </el-col>
          <el-col class="title" :span="1.5" :offset="5">预付金额：</el-col>
          <el-col :span="8" suffix-icon="el-icon-yuan">
            <input size="small" :disabled="true" placeholder="系统根据输入比例自动算出预付金额" :value="prepaymentAmountValue" />
          </el-col>
        </el-row>
        <!-- 材料进场预付款 -->
        <el-row :gutter="10" v-else-if="isAskForReasons('preProgress')">
          <el-col class="title" :span="1.5"><i class="red">*</i>发货通知单</el-col>
          <el-col :span="8">
            <el-select v-model="shippingNoticeSelected" multiple placeholder="请选择发货通知单 可多选" class="w100" @change="handleShippingNoticeChange">
              <el-option v-for="(item, idx) in requirements" :key="idx" :label="`第${item.requireBatchNo}批次`" :value="item.requireNo">
                <span style="float: left">第{{ item.requireBatchNo }}批</span>
              </el-option>
            </el-select>
          </el-col>
          <el-col class="title" :span="1.5" :offset="5">预付金额：</el-col>
          <el-col :span="8" suffix-icon="el-icon-yuan">
            <input size="small" v-input-custom-reg="{reg:'^\\d{1,9}(\\.\\d{0,6})?$|^\s*$'}" placeholder="请输入预付金额" v-model="preProgressAmt" />
          </el-col>
        </el-row>
        <!-- 进度款 -->
        <el-row :gutter="10" v-else class="progress-payment-row">

          <el-col :span="2" class="title"><i class="red">*</i>本期产值：</el-col>
          <el-col :span="8" suffix-icon="el-icon-yuan">
            <input size="small" v-input-custom-reg="{reg:'^\\d{1,9}(\\.\\d{0,6})?$|^\s*$'}" placeholder="请输入本期产值" v-model="progressInfo.outputValue" />
          </el-col>
          <el-col :span="2" :offset="4" class="title"><i class="red">*</i>累计应付金额：</el-col>
          <el-col :span="8" suffix-icon="el-icon-yuan">
            <input size="small" v-input-custom-reg="{reg:'^\\d{1,9}(\\.\\d{0,6})?$|^\s*$'}" placeholder="请输入累计应付金额" v-model="progressInfo.totalPayablesAmt" />
          </el-col>

          <el-col :span="2" class="title"><i class="red">*</i>累计完成产值：</el-col>
          <el-col :span="8" suffix-icon="el-icon-yuan">
            <input size="small" v-input-custom-reg="{reg:'^\\d{1,9}(\\.\\d{0,6})?$|^\s*$'}" placeholder="请输入累计完成产值" v-model="progressInfo.totalOutputValue" />
          </el-col>
          <el-col :span="2" :offset="4" class="title"><i class="red">*</i>累计已付金额：</el-col>
          <el-col :span="8" suffix-icon="el-icon-yuan">
            <input size="small" v-input-custom-reg="{reg:'^\\d{1,9}(\\.\\d{0,6})?$|^\s*$'}" placeholder="请输入累计已付金额" v-model="progressInfo.totalPaidAmt" />
          </el-col>

          <el-col :span="2" class="title"><i class="red">*</i>本次应付金额：</el-col>
          <el-col :span="8" suffix-icon="el-icon-yuan">
            <input size="small" v-input-custom-reg="{reg:'^\\d{1,9}(\\.\\d{0,6})?$|^\s*$'}" placeholder="请输入本次应付金额" v-model="progressInfo.payablesAmt" />
          </el-col>
          <el-col :span="22" :offset="2">
            <p class="red">※本次应付 = 本期产值 * 进度款支付比例</p>
          </el-col>
        </el-row>
      </div>
    </div>

    <div class="inner-container mt40">
      <div class="head-title">
        <span>收款账户信息</span>
        <!-- <span class="blue" >收款账户管理</span> -->
      </div>
      <div class="row-container">
        <div class="account-tips" v-if="!(bankInfoList && bankInfoList.length)">
          <p>
            请确认以下收款银行账户信息，本请款对应款项将汇入以下银行账号。若无收款账户，请点击【+添加收款账户】去创建。
          </p>
          <el-button type="primary" size="small" @click="handleAddNewBank">+添加收款账户</el-button>
        </div>
        <div class="account-center" v-else>
          <p>
            请确认以下收款银行账户信息，本请款对应款项将汇入以下银行账号。若无收款账户，请点击【收款账户管理】去创建。
          </p>
          <div class="account-row-flex">
            <span>收款账户</span>
            <el-select :disabled="isDefaultBankAccount" :value="`${bankAccountInfo.bankName || ''} (${bankAccountInfo.bankAcctNo || ''}) ${bankAccountInfo.bankAcctName || ''}`" placeholder="请选择" size="small" @change="handleBankAccountChange">
              <el-option v-for="item in bankInfoList" :key="item.bankAcctId" :value="item.bankAcctId" :label="item.bankAcctName"></el-option>
            </el-select>
          </div>
          <div class="account-specific-information">
            <el-row :gutter="10">
              <el-col :span="8">
                <span class="title">开户名称：</span>
                <span>{{bankAccountInfo.bankAcctName}}</span>
              </el-col>
              <el-col :span="8">
                <span class="title">开户行行号：</span>
                <span>{{bankAccountInfo.bankNo | formatString('bank')}}</span>
              </el-col>
              <el-col :span="8">
                <span class="title">联系人：</span>
                <span>{{bankAccountInfo.name}}</span>
              </el-col>

              <el-col :span="8">
                <span class="title">开户银行：</span>
                <span>{{bankAccountInfo.bankName}}</span>
              </el-col>
              <el-col :span="8">
                <span class="title black">银行账号：</span>
                <span class="red">{{bankAccountInfo.bankAcctNo | formatString('bank')}}</span>
              </el-col>
              <el-col :span="8">
                <span class="title">联系方式：</span>
                <span>{{bankAccountInfo.mobile | formatString}}</span>
              </el-col>

              <el-col :span="8">
                <span class="title">开户行地址：</span>
                <span>{{bankAddress(bankAccountInfo)}}</span>
              </el-col>
              <el-col :span="8">
                <span class="title">纳税人识别号：</span>
                <span>{{bankAccountInfo.taxPayerId | formatString('bank')}}</span>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
    </div>
    <div class="inner-container mt40">
      <div class="foot-check-container">
        <label>
          <el-checkbox v-model="responsibilityChecked"></el-checkbox>
          <b>我司保证上述账号资料准确无误，若因以上信息有误，而因此产生的一切纠纷和责任均由我司承担。</b>
        </label>
      </div>
    </div>

    <div class="inner-container mt40 request-information" v-if="!isAskForReasons()">
      <div class="head-title" v-if="billInfoList && billInfoList.length">
        <span>请款资料</span>
      </div>
      <RequestInformation :dirNameComputed="dirNameComputed" :billInfoList="billInfoList" @outputList="outputRequestList" @outputDelItem="outputDelItem"> </RequestInformation>
    </div>

    <div class="bottom-btn-container">
      <div class="inner-container">
        <div>温馨提示：点击【确认发起请款申请】，我们会为您生成请款报告。</div>
        <div>
          <el-button size="small" style="width: 180px" @click="handleSaveClick">保存</el-button>
          <el-button size="small" type="primary" style="width: 180px" @click="handleConfirmPayment" :disabled="!responsibilityChecked">确认发起请款申请</el-button>
        </div>
      </div>
    </div>

    <el-dialog class="dialog" title="确认发起请款申请" :append-to-body="true" :lock-scroll="true" :visible.sync="confirmPaymentDialog" width="850px" center :close-on-click-modal="false">
      <div class="confirm-payment-container">
        <div class="dialog-title">请款基本信息</div>
        <ul>
          <li>请款合同：《{{baseInfo.contractName}}》</li>
          <li>请款事由：<span class="red">{{baseInfo.askForReasonsValue}}</span></li>
          <li>采购商：{{baseInfo.purchaserName}}</li>
        </ul>

        <template v-if="isAskForReasons('progress') && ['01', '03'].includes(baseInfo.orderCateCode)">
          <div class="dialog-title" v-if="isAskForReasons('progress') && ['01', '03'].includes(baseInfo.orderCateCode)">上报完成进度及工作量</div>
          <div class="dialog-textare" v-if="isAskForReasons('progress') && ['01', '03'].includes(baseInfo.orderCateCode)">
            {{progressInfo.outputApplyDesc}}
          </div>
        </template>

        <div class="dialog-title">请款金额</div>
        <div class="dialog-money" v-if="isAskForReasons()">
          <span>预付比例：{{prepaymentRatioValue}}%</span>
          <span class="bold">预付金额：<font class="red">{{prepaymentAmountValue}}元</font></span>
        </div>
        <div class="dialog-money" v-if="isAskForReasons('preProgress')">
          <span :title="formatShippingNoticeSelected">
            <font>发货通知单：</font>
            <font>{{formatShippingNoticeSelected}}</font>
          </span>
          <span class="bold">预付金额：<font class="red">{{preProgressAmt}}元</font></span>
        </div>

        <div class="dialog-money" v-if="isAskForReasons('progress')">
          <span>
            <font>本期产值：</font>
            <font>{{progressInfo.outputValue}}元</font>
          </span>
          <span>
            <font>累计应付金额：</font>
            <font>{{progressInfo.totalPayablesAmt}}元</font>
          </span>
          <span>
            <font>累计完成产值：</font>
            <font>{{progressInfo.totalOutputValue}}元</font>
          </span>
          <span>
            <font>累计已付金额：</font>
            <font>{{progressInfo.totalPaidAmt}}元</font>
          </span>
          <span>
            <font>本次应付金额：</font>
            <font class="red">{{progressInfo.payablesAmt}}元</font>
          </span>
        </div>
        <div class="dialog-title">收款账户</div>
        <el-row :gutter="20">
          <el-col :span="12"><span class="title">开户名称：</span>{{bankAccountInfo.bankAcctName}}</el-col>
          <el-col :span="12"><span class="title">联系人：</span>{{bankAccountInfo.name}}</el-col>
          <el-col :span="12"><span class="title">开户银行：</span>{{bankAccountInfo.bankName}}</el-col>
          <el-col :span="12"><span class="title">联系方式：</span>{{bankAccountInfo.mobile | formatString}}</el-col>
          <el-col :span="12"><span class="title">银行账号：</span><span class="red">{{bankAccountInfo.bankAcctNo | formatString('bank')}}</span></el-col>
        </el-row>

        <div class="btn-center">
          <el-button size="small" type="primary" style="width: 120px" @click="handleDialogConfirm">确认并发起</el-button>
          <el-button size="small" style="width: 120px" @click="confirmPaymentDialog = false">取消</el-button>
        </div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"> </Loading>
    <EditBankAcctDialog ref="editBankAcct" @close="handleCloseEdit"></EditBankAcctDialog>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api"
import Header from "@/components/base/Header"
import SearchBar from "@/components/SearchBar"
import Loading from '@/components/base/Loading'
import EditBankAcctDialog from "@/components/account/finance/EditBankAcctDialog"
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import RequestInformation from "@/components/order/askForMoney/RequestInformation";
export default {
  components: { Header, SearchBar, Loading, EditBankAcctDialog, UpfileComponent, RequestInformation },
  data() {
    return {
      isLoading: false,
      prepaymentRatioValue: '', // 预付比例
      collectionAccountValue: '',
      confirmPaymentDialog: false, // 确认发起请款申请
      baseInfo: {},
      executionId: '', // 番号
      bankInfoList: [], // 收款账户信息
      responsibilityChecked: false,
      bankAccountInfo: {}, // 收款账户信息
      progressInfo: {// 进度款 请款金额
        fromDt: '', //	String	N	请款周期开始日期（YYYY-MM-DD）（日期校验）
        toDt: '', //	String	N	请款周期截止日期（YYYY-MM-DD）（日期校验）
        outputValue: '', // String	N	本期产值（大于0的金额，两位小数）
        totalOutputValue: '', // String	N	累计完成产值（含本次，大于0的金额，两位小数）
        totalPayablesAmt: '', // String	N	累计应付金额（大于0的金额，两位小数）
        totalPaidAmt: '', // String	N	累计已付金额（金额，两位小数）
        payablesAmt: '', // String	N	本次应付金额（大于0的金额，两位小数）
        outputApplyDesc: '', // String	N	形象进度及工程量描述
      },
      preProgressAmt: '', // 材料进场 - 预付金额
      billInfoList: [], // 请款资料 - 文件信息
      billInfoListBackup: [], // 请款资料 - 文件信息
      completeScheduleFiles: [], // 完成进度 附件
      shippingNoticeSelected: [], // 发货通知单选中
      paymentOperFlg: 'Add', // 数据是否保存过 flag
      requirements: [], // 发货通知单
      upfileDelList: [], // 文件上传 - 删除的文件
    };
  },
  filters: {
    // 过滤 字符串显示 state: 默认 电话格式, bank: 银行卡格式
    formatString: (val, state) => {
      state = state || 'tel'
      val = val || ''

      let newVal = ''
      if (state === 'tel') {
        newVal = `${val.slice(0, 3)} ${val.slice(3, 7)} ${val.slice(7, val.length)}`
      } else {
        const len = Math.floor(val.length / 4)

        for (let i = 0; i < len; i++) {
          newVal += `${val.slice(4 * i, 4 * (i + 1))} `
          if (i + 1 >= len) newVal += val.slice(4 * (i + 1), val.length)
        }
      }

      return newVal
    }
  },
  computed: {
    // 格式化 发货通知单
    formatShippingNoticeSelected() {
      let val = ''

      this.shippingNoticeSelected.forEach(f => {
        this.requirements.some(s => s.requireNo === f && (val += `第${s.requireBatchNo}批次、`))
      })
      return val.slice(0, val.length - 1)
    },
    // 上传路径标识
    dirNameComputed() {
      return `${this.executionId}/${new Date().getTime()}/`
    },
    // 付款方式
    paymentMethodComputed() {
      // 先查询出 需要 插入 span 标签的条数
      let str = this.baseInfo.paymentMethod || ''
      try {
        const replaceArr = str.match(/\d*%/g) || []
        replaceArr.reverse && replaceArr.reverse().forEach(f => {
          // 从结尾开始找 数据出现位置
          const sIdx = str.lastIndexOf(f)
          // 如果已经替换过 则返回, 防止相同数据多次替换
          const sStr = str.slice(0, sIdx),
            eStr = str.slice(sIdx + f.length, str.length),
            // 改变数据%为≌
            percentStr = `${f.slice(0, f.length - 1)}$≌$`
          // 结束下标
          str = `${sStr}<span class="red">${percentStr}</span>${eStr}`

        })
        // 还原%
        str = str.replace(/\$\≌\$/g, '%')
      } catch (error) {
        console.error('tryCatch-paymentMethodComputed: ', error);
      }
      return str
    },
    // getPaymentReportBillList
    prepaymentAmountValue() {
      const value = this.$options.filters['formatMoney'](this.baseInfo.outContractFeeWithTax * this.prepaymentRatioValue / 100)
      return (value == '0.00' || !value) ? '' : value
    },
    // 是否预付款
    isAskForReasons() {
      return paymentType => this.baseInfo && this.baseInfo.askForReasonsValue && this.baseInfo.paymentType === (paymentType || 'advance')
    },
    isDefaultBankAccount() {
      let state = false
      // 是否有默认收款账户
      if (this.baseInfo && this.baseInfo.bankAcctInfo && this.baseInfo.bankAcctInfo.bankAcctId) {
        const list = this.bankInfoList.filter(f => f.bankAcctId === this.baseInfo.bankAcctInfo.bankAcctId)

        state = !!(list && list.length)
      }

      return state
    },
    bankAddress() {
      return item => {
        return `${item.provCodeDisp || ''} ${item.districtCodeDisp || ''} ${item.addr || ''}`
      }
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    async init() {
      this.baseInfo = JSON.parse(this.$getRootScope('initiateAnapplicationBaseInfo')) || {}
      this.toFixedRest()
      this.getBankList()

      //  获取 番号 - 上传文件需要
      await this.getApprovalId()

      // 材料进场 - 预付款 获取 发货通知单 下拉
      if (this.isAskForReasons('preProgress')) {
        await this.getRequireOrderList()
      }

      // 进度款 获取数据
      if (this.isAskForReasons('progress')) {
        await this.getPaymentReportBillList()
      }

      await this.getPlanDetail()
    },

    /**
     * 发货通知单 选择
     */
    handleShippingNoticeChange() {
      let noticeList = []
      // 匹配选中数据
      this.shippingNoticeSelected.forEach(f => {
        this.requirements.some(s => {
          if (s.requireNo === f) {
            // 只要 type  = 1 的
            s.eventList && s.eventList.map(m => m.eventType == '1' && (m.requireBatchNo = s.requireBatchNo) && noticeList.push(m))
          }
        })
      })

      const formatList = (list, receiptType) => {
        if (list && list.length) {
          list.map(m => {
            let operFlg = 'Add'
            this.$set(m, 'operFlg', operFlg)
            this.$set(m, 'receiptType', receiptType)
            this.$set(m, 'receiptNo', m.requireNo)
            this.$set(m, 'requireBatchNo', m.requireBatchNo)
            this.$set(m, 'receiptFileName', m.documentName)
            this.$set(m, 'receiptFileUrl', m.documentUrl || m.documentURL)
          })
        } else {
          list = []
        }

        return list
      }

      this.billInfoList.some(s => {
        if (s.receiptType === 'require') {
          try {
            // 移除 所有 非 自己上传的 file文件, 方便 直接替换文件
            let len = s.list && s.list.length || 0
            while (len > 0) {
              len--
              // 有 receiptNo 则可以清除
              if (s.list[len].receiptNo) {
                s.list.splice(len, 1)
              }
            }

            s.list = formatList(noticeList, 'require').concat(s.list)
          } catch (error) { console.log(error) }
          return true

        }
      })

    },

    /**
     * 上传 上报完成进度及工作量
     */
    outputUpfileList(ev) {
      const evObj = ev && ev[0] || {},
        addZero = (num, len = 2) => (`0${num}`).slice(-len),
        formaetDate = date => `${date.getFullYear()}-${addZero(date.getMonth() + 1)}-${addZero(date.getDate())} ${addZero(date.getHours())} : ${addZero(date.getMinutes())} `
      this.completeScheduleFiles.push({
        operFlg: 'Add',
        receiptType: 'progress',
        receiptFileName: evObj.name,
        receiptFileUrl: evObj.url,
        upfileDate: formaetDate(new Date())
      })
    },

    /**
     * 进度 附件 删除
     */
    handleCompleteDelClick(idx) {
      this.outputDelItem(this.completeScheduleFiles, idx)
    },

    /**
     * 请款资料返回
     */
    outputRequestList(ev, item) {
      const evObj = ev && ev[0] || {}

      this.billInfoList.some(s => {
        if (s.receiptType === item.receiptType) {
          s.list.push({
            operFlg: 'Add',
            receiptType: item.receiptType || '',
            receiptFileName: evObj.name,
            receiptFileUrl: evObj.url,
          })
          return true
        }
      })

      console.log(this.billInfoList, 'outputRequestList');

    },

    /**
     * 请款资料 - 附件删除
     */
    outputDelItem(itemList, index) {
      let item = itemList.splice(index, 1) || []
      item[0] && (item[0].operFlg = 'Del', item[0].receiptId = item[0].id)
      item[0].id && this.upfileDelList.push(item[0])
      console.log(this.upfileDelList, '====Del');
    },

    /**
     * 上传
     */
    handleUpload(e, item) {
      const file = e.target.files[0];
      if (file) {
        const fileType = file.name.split(".")[1];
        const reg = /(png|jpg|jpeg|xls|xlsx|pdf)/i;
        if (!reg.test(fileType)) {
          this.$message.error("请上传图片、PDF、EXCEL格式文件");
          return;
        }
        item.push({
          fileName: file.name,
          file: file
        });
        e.value = "";
      }
    },

    /**
     * 修复 toFixed 精度问题
     */
    toFixedRest() {
      // toFixed兼容方法
      Number.prototype.toFixed = function (len) {
        if (len > 20 || len < 0) {
          throw new RangeError('toFixed() digits argument must be between 0 and 20');
        }
        // .123转为0.123
        var number = Number(this);
        if (isNaN(number) || number >= Math.pow(10, 21)) {
          return number.toString();
        }
        if (typeof (len) == 'undefined' || len == 0) {
          return (Math.round(number)).toString();
        }
        var result = number.toString(),
          numberArr = result.split('.');

        if (numberArr.length < 2) {
          //整数的情况
          return padNum(result);
        }
        var intNum = numberArr[0], //整数部分
          deciNum = numberArr[1],//小数部分
          lastNum = deciNum.substr(len, 1);//最后一个数字

        if (deciNum.length == len) {
          //需要截取的长度等于当前长度
          return result;
        }
        if (deciNum.length < len) {
          //需要截取的长度大于当前长度 1.3.toFixed(2)
          return padNum(result)
        }
        //需要截取的长度小于当前长度，需要判断最后一位数字
        result = intNum + '.' + deciNum.substr(0, len);
        if (parseInt(lastNum, 10) >= 5) {
          //最后一位数字大于5，要进位
          var times = Math.pow(10, len); //需要放大的倍数
          var changedInt = Number(result.replace('.', ''));//截取后转为整数
          changedInt++;//整数进位
          changedInt /= times;//整数转为小数，注：有可能还是整数
          result = padNum(changedInt + '');
        }
        return result;
        //对数字末尾加0
        function padNum(num) {
          var dotPos = num.indexOf('.');
          if (dotPos === -1) {
            //整数的情况
            num += '.';
            for (var i = 0; i < len; i++) {
              num += '0';
            }
            return num;
          } else {
            //小数的情况
            var need = len - (num.length - dotPos - 1);
            for (var j = 0; j < need; j++) {
              num += '0';
            }
            return num;
          }
        }
      }
    },

    /**
     * 收款账户下拉选择
     */
    handleBankAccountChange(ev) {
      this.bankAccountInfo = this.bankInfoList.filter(f => f.bankAcctId === ev)[0] || {}
      console.log(this.bankAccountInfo, '-this.bankAcctInfo');

    },

    /**
     * 查看合同详情
     */
    handleOrderDetail(order) {
      // 取消增补 功能需要
      window.open(this.$router.resolve({
        path: "/orderDetail",
        query: {
          orderNo: order.orderNo,
        }
      }).href, '_blank')
    },

    /**
     * 创建账户
     */
    handleAddNewBank() {
      this.$refs["editBankAcct"].open(this.bankInfo);
    },

    /**
     * 创建账户 返回信息
     */
    handleCloseEdit(data) {
      if (!data) return
      this.getBankList()
      console.log(data, 'result data');
    },

    /**
     * 确认
     */
    async handleConfirmPayment() {
      if (!this.requireVerification()) return
      this.confirmPaymentDialog = true
    },

    /**
     * 弹窗确认
     */
    async handleDialogConfirm() {
      await this.saveMoneyApplication(true)
      const result = await this.submitPaymentReort()
      result && this.$router.push({
        path: '/initiateAPaymentResult',
        query: {
          executionId: this.executionId,
          type: this.baseInfo.paymentType
        }
      })
    },

    /**
     * 获取收款账户 list
     */
    getBankList() {
      InterfaceService.getBankList({}, data => {
        if (data.respData.respCode === "0000") {
          this.bankInfoList = data.respData.bankList

          // 如果 有默认账户
          if (this.baseInfo && this.baseInfo.bankAcctInfo && this.baseInfo.bankAcctInfo.bankAcctId) {
            const list = this.bankInfoList.filter(f => f.bankAcctId === this.baseInfo.bankAcctInfo.bankAcctId)
            this.bankAccountInfo = list[0] || {}
            return
          }

          // 如果 没有默认账户 选择第一条
          this.bankAccountInfo = this.bankInfoList[0] || {}
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },


    /**
     * 保存点击
     */
    handleSaveClick() {
      this.saveMoneyApplication()
    },

    /**
     * 格式化 保存 params
     */
    formatSaveParams() {
      // preProgress ： 材料进场预付款；
      if (this.baseInfo.paymentType === 'preProgress') {
        // 在备份文件中 检查 是否为 old 文件  如果是 则标记, 主要处理 材料进场-预付款 发货通知单 下拉 选中文件问题
        // 如果 有 orderNo  且 flag 为 old 的文件 过滤掉,
        this.billInfoList.some(s => {
          // 只在发货通知单中查找
          if (s.receiptType === "require") {
            s.list && s.list.some(s1 => {
              // 如果S1 在备份数据中找到了则标识为 old
              this.billInfoListBackup.some(s2 => s2.receiptNo === s1.receiptNo) && (s1.operFlg = 'old')
            })
            return true
          }
        })

        // 如果 在 数据显示数据中 没有找到 备份数据 则标记 flag 为 Del
        this.billInfoListBackup.some(s1 => {
          this.billInfoList.some(s2 => {
            // 只在发货通知单中查找
            if (s2.receiptType === 'require') {
              if (!s2.list.some(s3 => (s3.receiptNo === s1.receiptNo)) && s1.receiptType === 'require') {
                // 如果在删除数组中找到了 则不继续添加 否则添加进 删除数组
                s1.operFlg = 'Del'
                s1.receiptId = s1.id
                console.log(s1, '---s1');

                !this.upfileDelList.some(s4 => s4.receiptNo === s1.receiptNo) && this.upfileDelList.push(s1)
              }
            }
          })
        })
      }

      let billInfoList = []

      // 请款资料
      this.billInfoList.map(m => {
        m.list && m.list.forEach(f => {
          const {
            operFlg,
            receiptType,
            receiptNo,
            receiptFileName,
            receiptFileUrl,
            requireBatchNo
          } = f

          billInfoList.push({
            operFlg,
            receiptType,
            receiptNo,
            receiptFileName,
            receiptFileUrl,
            requireBatchNo
          })
        })
      })

      // 进度 上传
      this.completeScheduleFiles.forEach(f => {
        const {
          operFlg,
          receiptType,
          receiptNo,
          receiptFileName,
          receiptFileUrl,
          requireBatchNo
        } = f

        billInfoList.push({
          operFlg,
          receiptType,
          receiptNo,
          receiptFileName,
          receiptFileUrl,
          requireBatchNo
        })
      })

      const { orderNo, paymentNo, paymentType } = this.baseInfo,
        { bankAcctId } = this.bankAccountInfo,
        params = {
          orderNo,
          paymentNo,
          paymentOperFlg: this.paymentOperFlg, // paymentOperFlg	String	Y	请款单操作标识（Add：新增；Upd：更新；Del：删除）
          paymentType,
          applyTheme: '临时主题', // 暂无
          bankAcctId,
          receiptsList: billInfoList.filter(f => f.operFlg != 'old').concat(this.upfileDelList)
        }

      // paymentType	String	Y	请款事由（ advance ：合同预付款；  ）
      if (paymentType === 'advance') {
        params.advanceInfo = {
          advancePercent: this.prepaymentRatioValue / 100,
          advanceAmt: (this.prepaymentRatioValue / 100 * this.baseInfo.outContractFeeWithTax).toFixed(2)
        }
      } else if (paymentType === 'preProgress') {
        params.preProgressInfo = {
          preProgressAmt: this.preProgressAmt
        }
      } else {
        params.progressInfo = this.progressInfo
      }



      if (!this.requireVerification()) return

      return params
    },

    /**
     * 必填 验证
     */
    requireVerification() {
      const { paymentType } = this.baseInfo

      if (paymentType === 'advance' && !this.prepaymentRatioValue) {
        this.$message.error('请输入预付比例')
        return
      }

      // preProgress ： 材料进场预付款；
      if (paymentType === 'preProgress') {
        if (!this.shippingNoticeSelected.length) {
          this.$message.error('请选择发货通知单')
          return
        }
      }

      // progress ：进度款
      if (paymentType === 'progress') {

        this.progressInfo.fromDt = this.baseInfo.datePickerValueStart
        this.progressInfo.toDt = this.baseInfo.datePickerValueEnd

        const {
          fromDt,
          toDt,
          outputValue,
          totalOutputValue,
          totalPayablesAmt,
          totalPaidAmt,
          payablesAmt,
          outputApplyDesc
        } = this.progressInfo

        let state = true,
          msg = ''

        if (['01', '03'].includes(this.baseInfo.orderCateCode)) {
          if (outputApplyDesc === '' && state) (msg = '上报进度不能为空', state = false)
          if (!(this.completeScheduleFiles && this.completeScheduleFiles.length) && state) (msg = '请上传完成进度及工作量附件', state = false)
        }

        if (fromDt === '') (msg = '请款周期开始日期不能为空', state = false)
        if (toDt === '' && state) (msg = '请款周期结束日期不能为空', state = false)
        if (outputValue === '' && state) (msg = '本期产值不能为空', state = false)
        if (totalPayablesAmt === '' && state) (msg = '累计应付金额不能为空', state = false)
        if (totalOutputValue === '' && state) (msg = '累计完成产值不能为空', state = false)
        if (totalPaidAmt === '' && state) (msg = '累计已付金额不能为空', state = false)
        if (payablesAmt === '' && state) (msg = '本次应付金额不能为空', state = false)


        // 根据 type 查询对应文件上传 的长度
        const getUpfileLengthByType = (type) => {
          let len = 0
          this.billInfoList.some(s => {
            if (s.receiptType === type) {
              len = s.list.length
              return true
            }
          })
          return len
        }
        // "delivery" supplier_statement
        if (!(getUpfileLengthByType('require')) && state) (msg = '请上传发货通知单附件', state = false)
        if (!(getUpfileLengthByType('delivery')) && state) (msg = '请上传工地验收单附件', state = false)
        if (!(getUpfileLengthByType('supplier_statement')) && state) (msg = '请上传应付对账单附件', state = false)

        if (!state) {
          this.$message.error(msg)
          return
        }
      }
      return true
    },

    /**
     * 保存请款
     */
    async saveMoneyApplication(isSub) {
      return new Promise((resolve, reject) => {
        const params = this.formatSaveParams()
        console.log(params, 'params')
        if (!params) return
        InterfaceService.saveMoneyApplication(params, async data => {
          if (data.respData.respCode === "0000") {
            if (!isSub) {
              // 提交 不提示
              this.$message.error('保存成功')
              await this.getPlanDetail()
            }
            resolve(true)
          } else {
            resolve(false)
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },


    /**
     * 获取合同编号
     */
    getApprovalId() {
      return new Promise(resolve => {
        InterfaceService.getApprovalId({
          // EXE 流程ID采番
          // PMT 请款单编号采番
          type: 'PMT'
        }, data => {
          if (data.respData.respCode === "0000") {
            this.executionId = data.respData.busiNo || "";
            resolve(data.respData.busiNo)
          } else {
            this.$message.error(data.respData.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },

    /**
     * 进度款 获取数据
     */
    getPaymentReportBillList() {
      const params = {
        fromDt: this.baseInfo.datePickerValueStart,
        toDt: this.baseInfo.datePickerValueEnd,
        orderNo: this.baseInfo.orderNo
      }
      InterfaceService.getPaymentReportBillList(params, data => {
        if (data.respData.respCode === "0000") {
          const { requireList, deliveryList, statementList } = data.respData,
            // receiptType: 单据类型（require:发货通知单；delivery:验收单；supplier_statement:应付对账单；progress:施工进度附件；others:其他单据）
            formatList = (list, receiptType) => {

              if (list && list.length) {
                list.map(m => {
                  m.operFlg = 'Add'
                  m.receiptType = receiptType || ''
                  m.receiptNo = m.deliveryNo || m.requireNo || m.statementNo
                  m.receiptFileName = m.deliveryName || m.requireName || m.statementName || m.fileName
                  m.receiptFileUrl = m.documentUrl
                })
              } else {
                list = []
              }

              return list
            }

          this.billInfoList.push({
            name: '发货通知单',
            receiptType: 'require',
            list: formatList(requireList, 'require'),
            require: true
          })

          this.billInfoList.push({
            name: '工地验收单',
            receiptType: 'delivery',
            list: formatList(deliveryList, 'delivery'),
            require: true
          })

          this.billInfoList.push({
            name: '应付对账单',
            receiptType: 'supplier_statement',
            list: formatList(statementList, 'supplier_statement'),
            require: true
          })

          this.billInfoList.push({
            name: '其他附件',
            receiptType: 'others',
            list: []
          })

        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },

    /**
     * 判断是否保存过 - 及数据反显
     */
    getPlanDetail() { //获取页面初始化数据
      return new Promise(resolve => {
        let params = { //给予后端的入参
          paymentNo: this.baseInfo.paymentNo || ''
        }
        InterfaceService.getPaymentDetail(params, data => {
          this.paymentOperFlg = data.respData.respCode === 'TRANS0415' ? 'Add' : 'Upd'
          if (data.respData.respCode === '0000') {
            try {
              const { advanceInfo, preProgressInfo, progressInfo, receiptsList } = data.respData
              this.billInfoListBackup = this.$clone(receiptsList)
              this.upfileDelList = []

              // 数据反显
              if (advanceInfo) {
                // 合同 - 预付款 - 预付比例
                this.prepaymentRatioValue = advanceInfo.advancePercent * 100 || ''
              }

              if (preProgressInfo) {
                // 材料进场 - 预付金额
                this.preProgressAmt = preProgressInfo.preProgressAmt || ''
              }

              this.shippingNoticeSelected = []
              //  材料进场 - 发货通知单 - 标识已有数据 为老数据
              receiptsList && receiptsList.forEach(f => {
                f.operFlg = 'old'
                this.requirements.some(s => {
                  if (s.eventList && s.eventList.some(s1 => f.receiptNo === s1.requireNo)) {
                    this.shippingNoticeSelected.push(f.receiptNo)
                    return true
                  }
                })
              })

              // 进度款 - 请款金额/工作进度
              if (progressInfo) {
                this.progressInfo = progressInfo
              }

              // 上传文件反显
              this.billInfoList.forEach(f => {
                f.list = []
                receiptsList.map(m => {
                  if (f.receiptType === m.receiptType) {
                    f.list.push(m)
                  }
                })
              })

              // 上传文件反显 - 上报完成进度及工作量
              this.completeScheduleFiles = []
              receiptsList.map(m => {
                if (m.receiptType == 'progress') {
                  this.completeScheduleFiles.push(m)
                }
              })

            } catch (error) { console.log(error) }
          }
          resolve(this.paymentOperFlg)
        }, data => { }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },

    /**
     * 材料进场 - 预付款 - 发货通知单
     */
    getRequireOrderList() {
      return new Promise(resolve => {
        const params = {
          orderNo: this.baseInfo.orderNo || '',
          sort: '1_0_0'
        }
        InterfaceService.getRequireOrderList(params, data => {
          if (data.respCode === "0000") {
            this.requirements = data.respData.requirements || []
            this.billInfoList.push({
              name: '发货通知单',
              receiptType: 'require',
              list: [],
              require: true
            })

            this.billInfoList.push({
              name: '其他附件',
              receiptType: 'others',
              list: []
            })

            resolve(true)
          } else {
            this.$message.error(data.respMsg)
          }
        }, data => { }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },

    /**
     * 发起
     */
    submitPaymentReort() {
      return new Promise(resolve => {
        let params = {
          paymentNo: this.baseInfo.paymentNo
        };
        InterfaceService.submitPaymentReort(params, data => {
          if (data.respData.respCode === "0000") {
            resolve(true)
          } else {
            this.$message.error(data.respData.respMsg);
            resolve(false)
          }
        }, data => { }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },
  }
};
</script>

<style lang="scss" scoped>
.initiate-a-payment-wrap {
  padding-bottom: 140px;
  .mt40 {
    margin-top: 40px;
  }
  .head-title {
    height: 50px;
    line-height: 50px;
    position: relative;
    border-bottom: 2px solid #ffd64e;
    background-color: #f5f5f5;
    color: #4f525a;
    span {
      position: absolute;
      padding: 0 24px;
      left: 0;
      border-bottom: 2px solid #444;
      font-size: 14px;
      font-weight: bold;
      height: 50px;
      &.blue {
        right: 0;
        cursor: pointer;
        left: auto;
        border-bottom: 0;
      }
    }
  }
  .row-container {
    margin: 12px 0;
    .el-row {
      margin-top: 12px;
    }
    .title {
      color: #888;
      &.black {
        color: #000;
      }
    }
    .blue {
      cursor: pointer;
    }
    &.row-flex-item-align-center {
      .el-row {
        display: flex;
        align-items: center;
        flex-wrap: wrap;
        [class*="el-col-"] {
          margin-top: 8px;
        }
        /deep/ .el-icon-percentage {
          &::before {
            content: "%";
            color: #000;
          }
        }
        /deep/ .el-icon-yuan {
          &::before {
            content: "元";
            color: #000;
          }
        }
      }
    }
    .account-tips {
      text-align: center;
      p {
        text-align: left;
        margin-bottom: 20px;
      }
    }
    .account-center {
      .account-specific-information {
        margin-top: 22px;
        border-top: 1px dashed #ccc;
        [class*="el-col-"] {
          margin-top: 12px;
        }
      }
    }
  }
  .payment-method {
    padding: 12px;
    line-height: 20px;
  }
  .foot-check-container {
    background: #f5f5f5;
    padding: 8px 20px;
    user-select: none;
    b {
      font-weight: bold;
    }
  }
  .bottom-btn-container {
    height: 54px;
    line-height: 54px;
    background: #72757c;
    text-align: center;
    position: fixed;
    bottom: 0;
    left: 0;
    z-index: 9;
    width: 100%;
    display: flex;
    align-items: center;
    & > div {
      height: 30px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      color: #fff;
    }
  }
  .account-row-flex {
    display: flex;
    margin-top: 20px;
    align-items: center;
    .el-select {
      width: 95%;
      margin-left: 12px;
    }
  }
}
.confirm-payment-container {
  .el-dialog--center {
    padding-top: 0 !important;
  }
  .bold {
    font-weight: bold;
  }
  color: #000;
  .dialog-title {
    border-left: 4px solid #333;
    margin: 22px 0 10px;
    padding-left: 6px;
  }
  .dialog-textare {
    padding: 4px;
    line-height: 20px;
  }
  .btn-center {
    text-align: center;
    margin-top: 30px;
  }
  .dialog-money {
    padding: 0 22px 12px;
    background: #fef4f3;
    display: flex;
    flex-wrap: wrap;
    span {
      width: 370px;
      margin-top: 12px;
    }
    span:first-child {
      text-overflow: ellipsis;
      display: inline-block;
      display: flex;
      line-height: 15px;
      font:first-child {
        max-width: 84px;
      }
    }
    .bold {
      position: absolute;
      left: 435px;
    }
  }
  .title {
    color: #666;
  }
  ul {
    li {
      margin-top: 8px;
    }
  }
  [class*="el-col-"] {
    margin-top: 8px;
  }
}
.request-information {
  dl {
    margin-top: 20px;
    dt {
      display: flex;
      span:not(.blue) {
        font-weight: bold;
        margin-right: 4px;
      }
      .blue {
        cursor: pointer;
      }
    }
    dd {
      margin-top: 12px;
      border: 1px solid #eee;
      padding: 6px 12px 12px;
      p {
        margin-top: 8px;
        .blue {
          margin-left: 4px;
          cursor: pointer;
        }
      }
    }
  }
}
.progress-payment-row {
  .title {
    color: #000;
    text-align: right;
  }
}
.workload-dl {
  margin-top: 20px;
  dt {
    display: flex;
    span:not(.blue) {
      margin-right: 4px;
    }
  }
  dd {
    margin-top: 12px;
    .el-row {
      background: #f5f5f5;
      height: 30px;
      line-height: 30px;
      margin-top: 1px !important;
      padding: 0 12px;
      &.head {
        color: #999;
      }
      [class*="el-col-"] {
        &.txtRight {
          text-align: right;
        }
        &.txtLeft {
          text-align: left;
        }
        &.txtCenter {
          text-align: center;
        }
      }
    }
  }
}
.el-col-22_5 {
  width: 93.49%;
}
input:disabled {
  background: #ddd;
}
/deep/ .el-input.is-disabled {
  .el-input__suffix {
    display: none;
  }
}
[suffix-icon="el-icon-percentage"] {
  position: relative;
  input {
    padding-right: 30px;
  }
  &::after {
    content: "%";
    position: absolute;
    right: 14px;
    top: 13px;
    font-size: 14px;
  }
}
[suffix-icon="el-icon-yuan"] {
  position: relative;
  input {
    padding-right: 30px;
  }
  &::after {
    content: "元";
    position: absolute;
    right: 14px;
    top: 13px;
    font-size: 14px;
  }
}
.txt-center {
  text-align: center;
  color: #666;
}
.w100 {
  &.el-select {
    width: 100%;
  }
}
/deep/ .el-dialog--center .el-dialog__body {
  padding-top: 0;
}
</style>
