<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <SearchBar :search-type="5" :is-white-bg="true" :progress="'新增请款计划_进度款'" :is-border-bottom="true"></SearchBar>
        <div class="inner-container">
            <p class="title">
                第一步：选择需要请款的合同。</p>
            <div>
                <a v-if="!order" class="pointer" @click="handleSelect">请选择</a>
                <div v-else class="order-info">
                    <p class="order-title">
                        <span>
                            <el-radio checked></el-radio>&nbsp;合同名称： 《{{order.contractName}}》
                        </span>
                        <el-button class="fr" style="margin-top: -10px;" type="text" @click="handleSelect">修改</el-button>
                    </p>
                </div>
            </div>
            <br>
            <p class="title">
                第二步：请修改并确认请款周期，我们将会载入对应请款所需材料。PS：请款周期不可有重复。</p>
            <div class="date-info">
                <a class="pointer" @click="handleFocusPicker('fromPicker')">修改
                    <i class="el-icon-caret-bottom"></i>
                </a>
                <div class="tr date-item">
                    <p class="date-year">&nbsp;{{fromDt|formatYear}}</p>
                    <el-date-picker ref="fromPicker" class="tr" v-model="fromDt" :picker-options="pickerOptions" format="MM月dd日" value-format="yyyy-MM-dd" placeholder="--月--日" :clearable="false" @change="handleChangeFromDt"></el-date-picker>
                    <p class="tip">周期起始日期</p>
                </div>

                <div class="icon-echelon"></div>

                <div class="tl date-item">
                    <p class="date-year">&nbsp;{{toDt|formatYear}}</p>
                    <el-date-picker ref="toPicker" v-model="toDt" format="MM月dd日" :picker-options="pickerOptions" value-format="yyyy-MM-dd" placeholder="--月--日" :clearable="false" @change="handleChangeToDt"></el-date-picker>
                    <p class="tip">周期截止日期</p>
                </div>
                <a class="pointer" @click="handleFocusPicker('toPicker')">修改
                    <i class="el-icon-caret-bottom"></i>
                </a>
            </div>
            <br>
            <p class="title">
                第三步：请确认以下收款银行账户信息，本请款计划对应款项将汇入以下银行账号。</p>
            <div>
                <BankAcctInfo ref="bankAcctInfo" class="bank-info" @changePromise="handleChangePromise"></BankAcctInfo>
            </div>
        </div>

        <div class="tc bottom">
            <el-button type="primary" @click="handleNext" :disabled="!canNext">下一步</el-button>
        </div>

        <SelectOrder ref="selectOrder" :paymentType="'progress'" @close="handleCloseSelect"></SelectOrder>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import SelectOrder from "@/components/order/dialog/SelectOrderDialog";
import BankAcctInfo from "@/components/account/finance/BankAccountInfo";

import { InterfaceService } from "@/services/api";

export default {
    mixins: [accountMixin],
    components: {
        Header,
        SearchBar,
        Loading,
        SelectOrder,
        BankAcctInfo
    },
    data() {
        return {
            isLoading: false,
            canNext: true,
            order: null,
            fromDt: "",
            toDt: "",
            pickerOptions: {
                disabledDate(time) {
                    return time.getTime() > Date.now();
                }
            }
        };
    },
    filters: {
        formatYear(val) {
            if (!val) return "----年";
            const date = new Date(val);
            return date.getFullYear() + "年";
        }
    },
    methods: {
        handleChangeFromDt(val) {
            if (this.toDt && val > this.toDt) {
                this.toDt = "";
            }
        },
        handleChangeToDt(val) {
            if (this.toDt && val < this.fromDt) {
                this.fromDt = "";
            }
        },
        handleSelect() {
            this.$refs["selectOrder"].open({
                title: "选择需要请款的合同"
            });
        },
        handleCloseSelect(data) {
            if (data) {
                this.order = data;
            }
        },
        handleFocusPicker(ref) {
            this.$refs[ref].focus();
        },
        handleChangePromise(isChecked) {
            this.canNext = isChecked;
        },
        handleNext() {
            const bankAcctId = this.$refs["bankAcctInfo"].getBankAcct();
            if (!this.order) {
                this.$message.error("请选择合同");
            } else if (!this.fromDt) {
                this.$message.error("请选择起始日期");
            } else if (!this.toDt) {
                this.$message.error("请选择截止日期");
            } else if (!bankAcctId) {
                this.$message.error("请选择收款账号");
            } else {
                const order = Object.assign({}, this.order);
                order.fromDt = this.fromDt;
                order.toDt = this.toDt;
                this.$store.dispatch("setSelectOrder", order);
                this.$router.push({
                    path: "/progressPaymentConfirm",
                    query: {
                        orderNo: this.order.orderNo,
                        orderAmt: this.order.orderAmountWithTax,
                        contractCate: this.order.orderCateCode,
                        bankAcctId: bankAcctId,
                        fromDt: this.fromDt,
                        toDt: this.toDt
                    }
                });
            }
        }
    },
    beforeRouteEnter(to, from, next) {
        next(vm => {
            if (from.name === "ProgressPaymentConfirm") {
                const order = vm.$store.state.payment.selectOrder;
                vm.order = order && Object.assign({}, order);
                vm.fromDt = vm.order.fromDt;
                vm.toDt = vm.order.toDt;
            }
            vm.$store.dispatch("clearSelectOrder");
        });
    }
};
</script>

<style lang="scss" scoped>
$bg-color: #f0f8ff;
$border-color: #ececec;

.pointer {
    color: #0082ff;
}

.title {
    padding: 20px 0;
    margin: 20px 0;
    border-bottom: 1px solid $border-color;
}

.order-title {
    margin-top: 20px;
    padding: 20px 15px;
    border: 1px solid $border-color;
    background: $bg-color;
}

.date-info {
    padding: 20px;
    border: 1px solid $border-color;
    text-align: center;
    background: $bg-color;

    a {
        display: inline-block;
        margin-top: -55px;
        vertical-align: middle;
    }
}

.date-item {
    display: inline-block;

    p {
        margin: 5px 0;
    }

    /deep/ .el-date-editor {
        width: 120px;

        .el-input__inner {
            width: 120px;
            padding: 0;
            border: none;
            font-size: 25px;
            color: inherit;
            background: $bg-color;

            &::-webkit-input-placeholder {
                font-size: 25px;
            }
        }

        .el-input__prefix {
            display: none;
        }
    }

    /deep/ .el-date-editor.tr {
        .el-input__inner {
            text-align: right;
        }
    }
}

.date-year {
    color: #909399;
}

.icon-echelon {
    position: relative;
    display: inline-block;
    width: 150px;
    height: 10px;
    margin: 0 30px;
    margin-bottom: 30px;
    background: #c9ddef;
    &:before {
        content: "";
        position: absolute;
        top: 0;
        right: 0;
        width: 0;
        height: 0;
        border-top: 10px solid $bg-color;
        border-left: 10px solid transparent;
    }
}

.bottom {
    margin: 40px auto 400px;
    /deep/ .el-button {
        width: 150px;
    }
}
</style>
