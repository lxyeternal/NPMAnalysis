<template>
  <div class="index-porduct">
    <Header :is-white-bg="true"></Header>
    <SearchBar :search-type="5" :progress="'中标公示'" :is-border-bottom="true"></SearchBar>
    <div class="list-home">
      <div class="list-content">
        <h3 class="f20 bold">{{enterBidInfo.bidName}}</h3>
        <div style="margin-bottom: 20px;">
          <span>
            发布日期：{{enterBidInfo.publishTime}}
          </span>
          <span>
            招标公告编号：{{enterBidInfo.bidNo}}
          </span>
        </div>
        <div class="category">
          招标模式：{{enterBidInfo.bidModelName}}
        </div>
        <div class="closing-date">
          品类：{{threeCategoryNameList.join("、")}}
          <template v-if="enterBidInfo.bidScope">
            （{{enterBidInfo.bidScope}}）
          </template>
        </div>
      </div>
      <div class="list-content">
        <div class="winning-title">{{enterBidInfo.biddingWinningTitle}}</div>
        <ul class="successful-bidder" v-if="enterBidInfo.ibSupplierListInfos && enterBidInfo.ibSupplierListInfos.length">
          <li v-for="(a, index) in enterBidInfo.ibSupplierListInfos" :key="index+'ibSupplierListInfos'">
            <p class="f14 bold">{{a.supplierCorpName}}<span v-if="isViewBidLetter(a.supplierCorpId)" class="f12 blue hand" @click="viewBidLetter(a)">查看中标函</span></p>
            <p class="remark f12" v-if="a.remark">
              <span class="grey">备注：</span>
              <span v-html="a.remark.replace(/\n/g,'<br/>')"></span>
            </p>
          </li>
        </ul>
        <!-- <table>
          <tbody>
          <template v-for='(item,index) in enterBidInfo.ibSupplierListInfos' v-if='index%2==0'>
            <tr >
              <td class="tbody-row">
                {{item.supplierCorpName}}
              </td>
              <td class="tbody-row" v-if='index+1<enterBidInfo.ibSupplierListInfos.length'>
                {{enterBidInfo.ibSupplierListInfos[index+1].supplierCorpName}}
              </td>
              <td v-else>&nbsp;</td>
            </tr>
          </template>
          </tbody>
        </table> -->
        <div class="congratulate">
          {{enterBidInfo.enterBidContent}}
        </div>
        <template v-if="canView">
          <div class="info-title">
            联系人
          </div>
          <el-row style="margin-bottom: 20px;">
            <el-col :span="8">
              招标单位：{{enterBidInfo.corpName}}
            </el-col>
            <el-col :span="16" v-if="enterBidInfo.handleInfos">
              <el-row v-for="(item,index) in enterBidInfo.handleInfos.filter(i=>i.isContact === '1')" :key="index" style="margin-bottom: 10px;">
                <el-col :span="12">
                  联系人：{{item.handleAcctName}}
                </el-col>
                <el-col :span="8">
                  联系电话：{{item.landLine}}
                </el-col>
              </el-row>
            </el-col>
          </el-row>
          <el-row v-if="enterBidInfo.bidAgentOrgName" style="margin-bottom: 10px;">
            <el-col :span="8">
              招标代理机构：{{enterBidInfo.bidAgentOrgName}}
            </el-col>
            <el-col :span="8">
              联系人：{{enterBidInfo.bidAgentOrgHandlerName}}
            </el-col>
            <el-col :span="8">
              联系电话：{{enterBidInfo.bidAgentOrgHandlerMoble | formatPhoneNumber("3 4 4")}}
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              受理质疑邮箱：{{enterBidInfo.bidAgentOrgChallegePhone | formatPhoneNumber("3 4 4")}}
            </el-col>
          </el-row>
          <div class="explain red">{{enterBidInfo.bidExplain}}</div>
          <div class="info-title" v-if="confirmBidTemplate">
            中标模板附件
            <span class="f12 blue hand" style="padding-left: 6px;" @click="handleAllDownload">全部下载</span>
          </div>
          <h3 style="font-size: 14px;line-height: 20px;">中标附件模板</h3>
          <div style="padding-bottom: 30px" :class="{'border-bottom':!enterBidAttachInfos.length}" v-if="confirmBidTemplate">
            <div class="enclosure-content">
              <div v-for="(item,index) in confirmBidTemplate" :key="index">
                <span>{{item.attachName}}</span>
                <em class="hand blue" @click="handleView(item.attachUrl)">预览</em>
                <em class="hand blue" @click="handleDownload(item.attachUrl,item.attachName)">下载</em>
              </div>
            </div>
          </div>
          <h3 style="font-size: 14px;line-height: 20px;" v-if="enterBidAttachInfos.length">其他附件</h3>
          <div style="padding-bottom: 30px;border-bottom: 1px solid #eee;" v-if="enterBidAttachInfos.length">
            <div class="enclosure-content">
              <div v-for="(item,index) in enterBidAttachInfos" :key="index">
                <span>{{item.attachName}}</span>
                <em class="hand blue" @click="handleView(item.attachUrl)">预览</em>
                <em class="hand blue" @click="handleDownload(item.attachUrl,item.attachName)">下载</em>
              </div>
            </div>
          </div>
          <div class="info-title">
            价格有效期
          </div>
          <div>
            <label class="grey">价格有效期：</label><em>{{enterBidInfo.priceEffectiveStartDate}} ~ {{enterBidInfo.priceEffectiveEndDate}}</em>
          </div>
        </template>
      </div>
    </div>
    <!-- 查看中标函或感谢函 -->
    <ViewBidLetter ref="viewBidLetter"></ViewBidLetter>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import SearchBar from "@/components/SearchBar";
import Header from "@/components/base/Header";
import { viewFile } from '@/utils/orderUtil';
import Loading from "@/components/base/Loading";
import ViewBidLetter from "@/components/tender/dialog/ViewBidLetter";
// import FixedTool from '@/components/FixedTool'
export default {
  components: {
    SearchBar,
    Header,
    Loading,
    // FixedTool,
    ViewBidLetter
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo || {}
    }
  },
  watch: {
  },
  data() {
    return {
      enterBidInfo: {},
      isLoading: false,
      canView: false,
      bidNo: "",
      enterBidNo: "",
      confirmBidTemplate: [],
      enterBidAttachInfos: [],
      threeCategoryNameList: [],

    };
  },
  methods: {
    handleView(url) {
      viewFile(url)
    },
    isViewBidLetter(supplierCorpId) {
      let result = false
      const list = this.$winBidcorpInfo()
      list.forEach(i => { if (i.corpId === this.userInfo.corpId) { result = true } })
      if (!result && supplierCorpId === this.userInfo.corpId) { result = true }
      return result
    },
    handleDownload(url, name) {
      let attach = [];
      attach.push({
        url: url,
        name: name
      });
      this.$download(attach).then(res => {
        this.$message.success("已下载");
      }).catch(res => {
        this.$message.error("下载失败");
      })
    },
    handleAllDownload() {
      let fileInfoBeans = []
      this.confirmBidTemplate.forEach(item => {
        if (item.attachUrl) {
          fileInfoBeans.push({
            archivePath: '中标附件模板/' + item.attachName,
            fileUrl: item.attachUrl,
          })
        }
      });
      this.enterBidAttachInfos.forEach(item => {
        if (item.attachUrl) {
          fileInfoBeans.push({
            archivePath: '其他附件/' + item.attachName,
            fileUrl: item.attachUrl,
          })
        }
      });
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            // const files = [
            //   { name: this.enterBidInfo.bidName.replace('中标公示', '') + "中标模板附件.zip", url: url }
            // ];
            // this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
            //   this.$message.success("已下载");
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: this.enterBidInfo.bidName.replace('中标公示', '') + "中标模板附件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    bidBulletinDetail() {
      let params = {
        bidNo: this.bidNo,
        enterBidNo: this.enterBidNo,
      };
      InterfaceService.bidBulletinDetail(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.enterBidInfo = data.respData.enterBidInfo || {};
            this.confirmBidTemplate = this.enterBidInfo.confirmBidTemplate || [];
            this.enterBidAttachInfos = this.enterBidInfo.enterBidAttachInfos || [];
            this.getBuyersTenderDetail();
            let corpIdList = [];
            corpIdList.push(this.enterBidInfo.corpId);
            if (this.enterBidInfo.ibSupplierListInfos) {
              this.enterBidInfo.ibSupplierListInfos.forEach(item => {
                corpIdList.push(item.supplierCorpId)
              })
            }

            this.canView = corpIdList.some(item => { return item === this.userInfo.corpId })
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    viewBidLetter(a) {
      let info = {
        supplierCorpName: a.supplierCorpName,
        ibBidCategoryInfos: this.enterBidInfo.ibBidCategoryInfos,
        year: this.enterBidInfo.bidStartYear + '~' + this.enterBidInfo.bidEndYear + '年度',
        publishTime: this.enterBidInfo.publishTime || '',
        corpId: this.enterBidInfo.corpId,
        remark: a.remark || ''
      }
      this.$refs.viewBidLetter.open(info)
    },
    getBuyersTenderDetail() {
      InterfaceService.getBuyersTenderDetail(
        { bidNo: this.bidNo },
        data => {
          if (data.respData.respCode === "0000") {
            let info = data.respData || {};
            this.enterBidInfo.bidName = info.bidName + "中标公示";
            this.enterBidInfo.corpName = info.corpName;
            this.enterBidInfo.biddingWinningTitle = info.bidName.replace('供应商征集', '中标供应商名单');
            this.enterBidInfo.bidModelName = info.bidModelName;
            this.enterBidInfo.bidScope = info.bidScope;
            this.enterBidInfo.categoryType = info.categoryLevelOneName + '-' + info.categoryLevelTwoName + '-' + info.categoryLevelThreeName;
            this.enterBidInfo.handleInfos = info.handleInfos || [];
            this.threeCategoryNameList = [];
            this.enterBidInfo.ibBidCategoryInfos = info.ibBidCategoryInfos || [];
            if (this.enterBidInfo.ibBidCategoryInfos.length == 1) {
              this.threeCategoryNameList.push(this.enterBidInfo.ibBidCategoryInfos[0].categoryLevelThreeName)
            } else {
              this.enterBidInfo.ibBidCategoryInfos.forEach(i => {
                this.threeCategoryNameList.push(i.categoryLevelTwoName)
              });
              this.threeCategoryNameList = [...new Set(this.threeCategoryNameList)]
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {
          this.$message.error(data.respData.respMsg);
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    init() {
      this.bidBulletinDetail();
    }
  },
  mounted() {
    // this.enterBidInfo = JSON.parse(this.$getRootScope("enterBidInfo") || '{}');
    this.bidNo = this.$route.query.bidNo || "";
    this.enterBidNo = this.$route.query.enterBidNo || "";
    this.init();
  },
};
</script>

<style lang="scss" scoped>
.border-bottom {
  border-bottom: 1px solid #eee;
}
.list-home {
  .list-content {
    width: 1190px;
    margin: 20px auto;
    line-height: 17px;
    .successful-bidder {
      border-left: 1px solid #eee;
      border-top: 1px solid #eee;
      margin-bottom: 20px;
      > li {
        width: 100%;
        padding: 10px 17px;
        line-height: 17px;
        font-size: 12px;
        border-right: 1px solid #eee;
        border-bottom: 1px solid #eee;
        min-height: 38px;
        > p {
          > span {
            margin-left: 10px;
            font-weight: normal !important;
          }
          &.remark {
            margin-top: 10px;
            display: flex;
            > span {
              margin: 0px;
              word-break: break-all;
              word-wrap: break-word;
              &:first-child {
                flex-shrink: 0;
              }
              &:nth-child(2) {
                width: 1110px;
                display: inline-block;
              }
            }
          }
        }
      }
    }
    .unpublished {
      width: 70px;
      height: 20px;
      background: rgba(204, 191, 240, 1);
      color: #fff;
      text-align: center;
      line-height: 20px;
      margin-top: -4px;
      margin-bottom: 10px;
    }
    div {
      font-weight: 500;
      img {
        display: block;
      }
    }
    .f20 {
      font-size: 20px;
      margin-bottom: 12px;
    }
    span {
      font-size: 12px;
      font-weight: 500;
      line-height: 15px;
      margin-right: 56px;
      color: #888;
    }
    .category {
      margin-bottom: 10px;
      font-size: 14px;
      font-weight: bold;
      line-height: 17px;
    }
    .closing-date {
      font-size: 14px;
      margin-top: 10px;
      padding-bottom: 30px;
      font-weight: bold;
      border-bottom: 1px solid #eee;
    }
    .order-info-title {
      margin: 20px 0;
      padding: 0 10px;
      font-size: 14px;
      border-left: 3px solid #000;
      line-height: 12px;
    }
    table {
      margin: 20px 0;
      table-layout: fixed;
      width: 100%;
      line-height: 17px;
      font-size: 12px;
      td {
        padding: 11px 10px;
        vertical-align: middle;
        word-break: break-all;
      }

      thead {
        font-size: 14px;
        text-align: left;
        white-space: nowrap;
        border-bottom: 1px solid #eee;
        background: #313131;
        color: #fff;
      }
      .tbody-row {
        &:hover {
          background: #f0f8ff;
        }
      }
      tbody {
        text-align: left;
        border-bottom: 1px solid #eee;
        border-right: 1px solid #eee;
        tr {
          td {
            border-top: 1px solid #eee;
            border-left: 1px solid #eee;
          }
        }
        .border-none {
          border-bottom: none;
        }
      }
    }
  }
}
.winning-title {
  width: 100%;
  font-size: 16px;
  text-align: center;
  font-weight: bold !important;
  color: #444;
  margin-bottom: 20px;
}
.congratulate {
  padding-bottom: 25px;
  border-bottom: 1px solid rgba(238, 238, 238, 1);
}
.info-title {
  margin: 20px 0;
  padding: 0 10px;
  font-size: 14px;
  border-left: 3px solid #000;
  line-height: 12px;
  font-weight: 600 !important;
}
.el-row {
  margin-bottom: 5px;
}
.explain {
  margin-top: 15px;
  padding-bottom: 30px;
  border-bottom: 1px solid rgba(238, 238, 238, 1);
}
.enclosure-content {
  font-size: 12px;
  width: 1190px;
  border: 1px solid #ddd;
  padding: 13px 10px;
  line-height: 17px;
  margin-top: 6px;
  div {
    margin-bottom: 10px;
  }
  div:last-child {
    margin-bottom: 0;
  }
  span {
    margin-right: 6px !important;
    color: #444 !important;
  }
}
.info-tips {
  margin-top: 10px;
  width: 100%;
  line-height: 30px;
  padding-left: 10px;
  font-size: 12px;
  height: 30px;
  background: rgba(255, 252, 240, 1);
  border: 1px solid rgba(250, 226, 165, 1);
}
</style>
