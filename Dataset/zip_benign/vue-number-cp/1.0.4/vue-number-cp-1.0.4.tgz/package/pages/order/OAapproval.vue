<template>
  <div class="viewMockList">
    <Header :is-white-bg="true"></Header>
    <SearchBar :search-type="5" :progress="'确认合同详情'" :is-border-bottom="true"></SearchBar>
    <div class="page">
      <Breadcrumb :breadcrumbList="breadcrumb" @refresh="handleGoBack()"></Breadcrumb>
      <div class="table-box">
        <table class="table">
          <thead>
            <tr>
              <th colspan="4">CL_18_大家采“集中甲供直采双向合同”签订申请单</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td colspan="4" class="td-white">【申请信息】</td>
            </tr>
            <tr>
              <td>标题</td>
              <td colspan="3" class="td-white">
                <el-input class="table-input" v-model="approvalInfo.approveTitle" placeholder="请输入" maxlength="256">
                </el-input>
              </td>
            </tr>
            <tr>
              <td>申请单号</td>
              <td class="td-white">
                <el-input class="table-input" v-model="approvalInfo.sqdh" placeholder="请输入" maxlength="32">
                </el-input>
              </td>
              <td>紧急程度</td>
              <td class="td-white">
                <el-radio-group v-model="approvalInfo.zjjcd">
                  <el-radio label="0">正常</el-radio>
                  <el-radio label="1">重要</el-radio>
                  <el-radio label="2">紧急</el-radio>
                </el-radio-group>
              </td>
            </tr>
            <tr>
              <td>申请人</td>
              <td>{{approvalInfo.sqr}}</td>
              <td>申请人手机</td>
              <td class="td-white">
                <el-input class="table-input" v-model="approvalInfo.zsqrsj" placeholder="请输入" maxlength="11" @input="approvalInfo.zsqrsj=approvalInfo.zsqrsj.replace(/[^\d.]/g,'')">
                </el-input>
              </td>
            </tr>
            <tr>
              <td>申请事业部</td>
              <td>{{approvalInfo.sqsyb}}</td>
              <td>申请公司</td>
              <td>{{approvalInfo.sqgs}}</td>
            </tr>
            <tr>
              <td>申请部门</td>
              <td>{{approvalInfo.sqbm}}</td>
              <td>申请日期</td>
              <td>{{approvalInfo.sqrq}}</td>
            </tr>

            <tr>
              <td colspan="4" class="td-white">【基本信息】</td>
            </tr>
            <tr>
              <td colspan="4" class="tc">大家采页面</td>
            </tr>
            <tr>
              <td colspan="4" class="td-white"></td>
            </tr>
            <!-- <tr>
              <td>项目名称</td>
              <td>{{approvalInfo.xmmc}}</td>
              <td>分期名称</td>
              <td>{{approvalInfo.fqmc}}</td>
            </tr>
            <tr>
              <td>标段</td>
              <td>{{approvalInfo.bd}}</td>
              <td>竣工日期</td>
              <td class="td-white">
                <el-date-picker class="table-date-picker" v-model="approvalInfo.jgrq" type="date" placeholder="请选择" :clearable="false" :picker-options="{disabledDate(time) {return time.getTime() <= Date.now()}}">
                </el-date-picker>
              </td>
            </tr>
            <tr>
              <td>材料类别/产品名称</td>
              <td>{{approvalInfo.cllb}}</td>
              <td>签约品牌</td>
              <td>{{approvalInfo.qypp}}</td>
            </tr>
            <tr>
              <td>供应方名称</td>
              <td>{{approvalInfo.gyfmc}}</td>
              <td>材料公司名称</td>
              <td>{{approvalInfo.clgsmc}}</td>
            </tr>
            <tr>
              <td>项目公司名称</td>
              <td>{{approvalInfo.xmgsmc}}</td>
              <td>税率</td>
              <td>{{approvalInfo.sl}}</td>
            </tr>
            <tr>
              <td>工程量（主要产品）</td>
              <td class="td-white">
                <el-input class="table-input" v-model="approvalInfo.gcl" placeholder="请输入" maxlength="15">
                </el-input>
              </td>
              <td>合同清单工程量计算书</td>
              <td class="td-white hand" @click="uploadType='8'; $refs.downloadAndUpload.open()">
                <ul class="file-tab" v-if="htqdgcljssList.length">
                  <li class="li-tab" v-for="(a,index) in htqdgcljssList" :key="index+'htqdgcljssList'">{{a.attachName}} <i class="el-icon-close" @click.stop="delFile(htqdgcljssList,index)"></i></li>
                </ul>
                <p v-else class="grey">请上传</p>
              </td>
            </tr>

            <tr>
              <td colspan="4" class="td-white">【采购合同信息】</td>
            </tr>
            <tr>
              <td>采购合同编号</td>
              <td>{{approvalInfo.cghtbh}}</td>
              <td>采购合同名称</td>
              <td>{{approvalInfo.cghtmc}}</td>
            </tr>
            <tr>
              <td>采购合同金额（含税）元</td>
              <td>{{approvalInfo.cghtjehs}}</td>
              <td>采购合同金额（不含税）元</td>
              <td>{{approvalInfo.cghtjebhs}}</td>
            </tr>
            <tr>
              <td>供应方联系人</td>
              <td>{{approvalInfo.gyflxr}}</td>
              <td>供应方联系方式</td>
              <td>{{approvalInfo.gyflxfs}}</td>
            </tr>
            <tr>
              <td class="height87">采购合同付款方式</td>
              <td colspan="3" class="height87">
                <p v-if="approvalInfo.cghtfkfs" v-html="approvalInfo.cghtfkfs.replace(/\n/g, '<br/>')"></p>
              </td>
            </tr>
            <tr>
              <td>采购合同附件</td>
              <td>
                <span class="blue hand" v-for="(a,index) in computedContract('B')" :key="index" @click="handleDownload(a.documentName, a.attachUrl)">
                  {{a.documentName + (index+1 === computedContract('B').length ? '' :'；')}}
                </span>
                <span class="blue hand" v-if="fileFilter('otherFile').length" @click="handlePackDownload('otherFile')">
                  其他附件
                </span>
              </td>
              <td>组价附件</td>
              <td class="td-white hand" @click="uploadType='7'; $refs.downloadAndUpload.open()">
                <ul class="file-tab" v-if="zjfjList.length">
                  <li class="li-tab" v-for="(a,index) in zjfjList" :key="index+'zjfjList'">{{a.attachName}} <i class="el-icon-close" @click.stop="delFile(zjfjList,index)"></i></li>
                </ul>
                <p v-else class="grey">请上传</p>
              </td>
            </tr>

            <tr>
              <td colspan="4" class="td-white">【供应合同信息】</td>
            </tr>
            <tr>
              <td>供应合同编号</td>
              <td>{{approvalInfo.gyhtbh}}</td>
              <td>供应合同名称</td>
              <td>{{approvalInfo.gyhtmc}}</td>
            </tr>
            <tr>
              <td>供应合同金额（含税）元</td>
              <td>{{approvalInfo.gyhtjehs}}</td>
              <td>供应合同金额（不含税）元</td>
              <td>{{approvalInfo.gyhtje2}}</td>
            </tr>
            <tr>
              <td>项目公司联系人</td>
              <td>{{approvalInfo.xmgslxr}}</td>
              <td>项目公司联系方式</td>
              <td>{{approvalInfo.xmgslxfs}}</td>
            </tr>
            <tr>
              <td>供应合同付款方式</td>
              <td colspan="3" class="height87">
                <p v-if="approvalInfo.gyhtfkfs" v-html="approvalInfo.gyhtfkfs.replace(/\n/g, '<br/>')"></p>
              </td>
            </tr>
            <tr>
              <td>供应合同附件</td>
              <td>
                <span class="blue hand" v-for="(a,index) in computedContract('S')" :key="index" @click="handleDownload(a.documentName, a.attachUrl)">
                  {{a.documentName + (index+1 === computedContract('S').length ? '' :'；')}}
                </span>
                <span class="blue hand" v-if="fileFilter('otherFile').length" @click="handlePackDownload('otherFile')">
                  其他附件
                </span>
              </td>
              <td></td>
              <td></td>
            </tr>
            <tr>
              <td>合同金额建面指标</td>
              <td>{{approvalInfo.htjejmzb}}</td>
              <td>合同金额实物量指标</td>
              <td>{{approvalInfo.htjeswlzb}}</td>
            </tr>
            <tr>
              <td>目标成本该项预算*90%（元）</td>
              <td>{{approvalInfo.mbcbys}}</td>
              <td>集团限额或目标成本限额</td>
              <td>{{approvalInfo.jtxeyq}}</td>
            </tr>
            <tr>
              <td>SAP审批通过流程</td>
              <td colspan="3"></td>
            </tr> -->

            <tr>
              <td colspan="4" class="td-white">【流程信息】</td>
            </tr>
            <tr>
              <td>项目采购专员</td>
              <td>{{approvalInfo.xmcgzy}}</td>
              <td>事业部采购经理</td>
              <td class="td-white">
                <el-autocomplete popper-class="autocomplete-sybcgjl" class="table-input" v-model="approvalInfo.sybcgjl" :fetch-suggestions="getOAInfo" placeholder="请输入事业部采购经理姓名搜索" @select="handleSelect"></el-autocomplete>
                <!-- {{approvalInfo.sybcgjl}} -->
              </td>
            </tr>
            <tr>
              <td></td>
              <td class="td-white"></td>
              <td></td>
              <td class="td-white"></td>
            </tr>
            <tr>
              <td colspan="4" class="td-white">
                <p class="red">1、大家采：（代理商）→供应商→项目采购专员</p>
                <p class="red">2、OA：项目采购商专员→事业部采购经理→建材集团采购经理→建材集团采购总监→项目采购专员→建材集团经理助理 </p>
                <p class="red">3、大家采：电子用印</p>
              </td>
            </tr>
          </tbody>

          <tbody>
            <tr>
              <td class="height87">签字意见</td>
              <td colspan="3" class="td-white height87">
                <el-input @input="$forceUpdate()" type="textarea" class="resize-none" v-model="approvalInfo.signature" rows="4" maxlength="600" show-word-limit placeholder="请输入..."></el-input>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <FixBottom class="bottom">
      <div class="tc">
        <el-button type="primary" :class="{'isDisabled-primary': !approvalInfo.sqr}" @click="handleSubmit('save','submit')">确认提交OA审核</el-button>
        <el-button @click="supplierOaApprove('save')">保存</el-button>
        <el-button @click="handleGoBack">上一步</el-button>
      </div>
    </FixBottom>
    <Loading :is-loading="isLoading"></Loading>
    <DownloadAndUpload ref="downloadAndUpload" v-show="false" :hasDownloadFlg="false" appName="TRD" :fromId="uploadType" :uploadType="uploadType" @outputValue="getAttachInfo"></DownloadAndUpload>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import Header from "@/components/base/Header";
import Breadcrumb from "@/components/base/Breadcrumb";
import FixBottom from "@/components/base/FixBottom";
import DownloadAndUpload from "@/components/base/DownloadAndUpload";
export default {
  components: {
    SearchBar,
    Loading,
    Header,
    Breadcrumb,
    FixBottom,
    DownloadAndUpload
  },
  data() {
    return {
      isLoading: false,
      breadcrumb: [],

      orderNo: '',
      approvalInfo: {},
      attachList: [],
      htqdgcljssList: [],
      zjfjList: [],
      uploadType: '',
      isResubmit: false,
      approveId:'',
      // sybOrderNo:'',
      // clOrderNo:'',
      // autocompleteKey:''
    };
  },
  mounted() {
    this.init()
  },
  methods: {
    handleGoBack() {
      this.$router.go(-1);
    },
    init() {
      this.orderNo = this.$route.query.orderNo
      const approveStatus = this.$route.query.approveStatus
      this.isResubmit = (approveStatus == '2' || approveStatus == '4') ? true : false
      this.breadcrumb = [
        { name: '管理中心', path: '/purchaserCenter/accountInfo' },
        { name: '交易管理-合同管理', path: '/purchaserCenter/orderList' },
        { name: '确认合同' },
      ];

      this.getOAapprovalDetail()
    },
    computedContract(bs) {
      return this.attachList.filter(i => (i.documentType == 'contractProfession' || i.documentType == 'contractCommon') && i.bs == bs)
    },
    fileFilter(documentType) {
      return this.attachList.filter(i => i.documentType == documentType)
    },
    getAttachInfo(info) {
      console.log(info)
      if (info.fromId == '8') {
        this.htqdgcljssList.push({
          attachType: 'htqdgcljss',
          attachPath: info.attachPath,
          attachName: info.attachName,
          attachUrl: info.attachUrl,
        })
      } else {
        this.zjfjList.push({
          attachType: 'zjfj',
          attachPath: info.attachPath,
          attachName: info.attachName,
          attachUrl: info.attachUrl,
        })
      }
    },
    getOAInfo(keyWord, cd) {
      if (keyWord) {
        let param = {
          oaName: keyWord,
        }
        InterfaceService.getOAInfo(param, data => {
          this.isLoading = false;
          if (data && data.respData && data.respData.respCode === "0000") {
            let list = data.respData.oaAccountList || []
            list.forEach(i => {
              i.value = i.loginId + (i.loginId ? ' | ' : '') + i.lastName + (i.lastName ? ' | ' : '') + i.subcompanyName + (i.subcompanyName ? ' | ' : '') + i.departmentName + (i.departmentName ? ' | ' : '') + i.mobile + (i.mobile ? ' | ' : '') + i.jobTitle
            })
            cd(list)
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
      } else {
        cd([])
      }
    },
    handleSelect(item) {
      console.log(item)
      this.approvalInfo.purchasingManagerId = item.hrmId
      this.approvalInfo.sybcgjl = item.lastName
    },
    getOAapprovalDetail() {
      const params = {
        orderNo: this.orderNo
      };
      InterfaceService.getOAapprovalDetail(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          this.approveId = res.approveId || ''
          this.approvalInfo = res.askOaBussinessData || {}
          const sybOrderNo = this.$route.query.sybOrderNo || ''
          const clOrderNo = this.$route.query.clOrderNo || ''
          const contractName = this.$route.query.contractName || ''
          this.approvalInfo.approveTitle = this.approvalInfo.approveTitle || (sybOrderNo + (sybOrderNo ? '/' : '') + clOrderNo + '《' + contractName + '》')
          this.approvalInfo.sqdh = this.approvalInfo.sqdh || (sybOrderNo + (sybOrderNo ? '/' : '') + clOrderNo)

          this.approvalInfo.signature = this.approvalInfo.zqzyj || ''
          this.approvalInfo.zjjcd = this.approvalInfo.zjjcd || '0'
          this.attachList = res.attachList || []
          this.htqdgcljssList = []
          this.zjfjList = []

          const htqdgcljssList = this.fileFilter('htqdgcljss')
          this.handleFileData(htqdgcljssList, this.htqdgcljssList)
          const zjfjList = this.fileFilter('zjfjList')
          this.handleFileData(zjfjList, this.zjfjList)

          const toDay = (new Date()).getTime()
          this.approvalInfo.sqrq = this.$formatTime(toDay, 'yyyymmdd')
          this.$forceUpdate()
        } else {
          this.$message.error(res.respMsg);
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    handleFileData(dataList, list) {
      dataList.forEach(i => {
        list.push({
          attachType: i.documentType,
          attachPath: i.attachPath,
          attachName: i.documentName,
          attachUrl: i.attachUrl,
        })
      })
    },
    handleSubmit(operType, type = '') {
      if (!this.approvalInfo.sqr) {
        this.$confirm(
          '您还没有绑定集团OA账号，请先去绑定！',
          this.rejectBtn,
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            dangerouslyUseHTMLString: true,
            confirmButtonText: '去绑定',
            cancelButtonText: '取消',
          }).then(() => {
            this.supplierOaApprove(operType, 'bind')
          }).catch(() => {
          });
      } else {
        this.supplierOaApprove(operType, type)
      }
    },
    supplierOaApprove(operType, type = '') {
      const approveAcctName = this.$store.state.userInfo.acctName || ''
      const approveAttachInfos = this.htqdgcljssList.concat(this.zjfjList)
      // return console.log(type)
      const params = {
        approveId: this.approveId,
        requestLevel: this.approvalInfo.zjjcd || '',
        mobile: this.approvalInfo.zsqrsj || '',
        purchasingManagerName: this.approvalInfo.sybcgjl || '',
        purchasingManagerId: this.approvalInfo.purchasingManagerId || '',
        operType: operType === 'submit' ? (this.isResubmit ? 'resubmit' : 'submit') : operType,
        orderNo: this.orderNo,
        projectEndDt: this.approvalInfo.jgrq,
        approveTitle: this.approvalInfo.approveTitle,
        engineeringAmount: this.approvalInfo.gcl,
        approveNo: this.approvalInfo.sqdh,
        signature: this.approvalInfo.signature,
        approveAcctName: approveAcctName,
        sysCode: this.approvalInfo.sysCode,
        approveType: '1',
        approveAttachInfos: approveAttachInfos
      };
      
      InterfaceService.supplierOaApprove(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          if (operType == 'save' && type == 'bind') {
            return this.$router.push({ path: '/purchaserCenter/accountInfo' })
          }
          if (type != 'submit') {
            this.$message.success('操作成功')
          }
          if (operType == 'save') {
            type != 'submit' ? this.getOAapprovalDetail() : this.handleSubmit('submit')
          } else {
            this.pushOrder()
          }
        } else {
          this.$message.error(res.respMsg);
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    pushOrder() {
      const params = {
        orderNo: this.orderNo,
        operType: 'submit',
      };
      InterfaceService.pushOrder(
        params,
        data => {
          if (data.respData.respCode == "0000") {
            this.handleGoBack()
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false });
    },
    // 删除文件
    delFile(list, index) {
      list.splice(index, 1)
      this.$message.success('已删除')
    },
    // 下载
    handleDownload(name, url) {
      const files = [{
        name, url
      }]
      this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
        this.$message.success("已下载");
      });
    },
    // 其他附件打包下载
    handlePackDownload(documentType) {
      const list = this.attachList.filter(i => i.documentType == documentType)
      let fileInfoBeans = []
      list.forEach((item, index) => {
        fileInfoBeans.push({
          archivePath: '其他附件/' + item.documentName,
          fileUrl: item.attachUrl,
        })
      })
      if (!fileInfoBeans.length) {
        return this.$message('暂无附件可供下载')
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: "其他附件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false }
      )
    },
  },
};
</script>
<style>
.autocomplete-sybcgjl {
  width: 480px !important;
}
</style>
<style lang="scss" scoped>
/deep/ .table-input {
  input {
    border: none;
    height: 17px;
    line-height: 17px;
    font-size: 12px;
    padding-left: 0px;
  }
}
/deep/ .table-date-picker {
  > input {
    width: 100%;
    border: none;
    height: 17px;
    line-height: 17px;
    font-size: 12px;
    padding-left: 0px;
  }
  .el-input__prefix {
    display: none;
  }
}
.height87 {
  height: 87px !important;
}
.page {
  width: 1190px;
  margin: 0 auto;
  padding-bottom: 80px;
  .table-box {
    margin-top: 11px;
    .table {
      table-layout: fixed;
      width: 100%;
      tr {
        border-left: 1px solid #444;
        border-bottom: 1px solid #444;
        td {
          width: 25%;
          height: 31px;
          padding: 7px 10px 6px;
          vertical-align: middle;
          word-break: break-all;
          line-height: 17px;
          font-size: 12px;
          border-right: 1px solid #444;
          &:nth-child(odd) {
            background-color: #f9df9c;
          }
          &:nth-child(even) {
            background-color: #ddd;
          }
          &.td-white {
            background-color: white;
          }
          .file-tab {
            > li.li-tab {
              display: inline-block;
              min-width: 60px;
              background-color: #c99f4f;
              color: #fff;
              border-radius: 0;
              font-size: 12px;
              line-height: 17px;
              padding: 3px 4px 2px;
              margin-right: 6px;
              margin-bottom: 6px;
              > i {
                color: #fff;
                background-color: #c99f4f;
              }
              // &+.li-tab{
              //   margin-left: 6px;
              // }
            }
          }
        }
      }
      thead {
        font-size: 16px;
        font-weight: 600;
        text-align: center;
        white-space: nowrap;
        color: #444;
        tr {
          background-color: #f9df9c;
          border: 1px solid #444;
          th {
            padding: 16px 0;
          }
        }
      }
    }
  }
}
</style>
