<template>
  <div class="index-porduct">
    <Header :is-white-bg="true"></Header>
    <SearchBar :is-red-bg="true" :search-type="1" :scrollShowFixed="true" @listenIsShowFooter="listenIsShowFooter()"></SearchBar>
    <LightColorMenuBar :current-router="currentRouter"></LightColorMenuBar>
    <div class="bg-content">
      <div class="search">
        <el-input placeholder="请输入关键词搜索中标公示或招标品类" v-model="keyWord"></el-input>
        <el-button type="primary" class="normal-btn" @click="handleSearch">搜索</el-button>
      </div>
    </div>
    <div class="list-home">
      <div class="list-content">
        <table>
          <thead>
          <tr>
            <td width="230px">招标品类</td>
            <td width="300px">发布方</td>
            <td>中标公示名称</td>
            <td width="94px">发布日期</td>
          </tr>
          </thead>
          <tbody v-for="(item,ind) in biddingList" :key="ind" class="tbody-row">
          <tr>
            <td class="ellipsisOne" :title="item.categoryName">
              {{item.categoryName}}
            </td>
            <td>
              {{item.corpName}}
            </td>
            <td>
              <span class="hand blue" @click="handleOpen(item)">{{item.bidName}}</span>
            </td>
            <td>
              {{item.publishTime}}
            </td>
          </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="table-pagination" v-if="biddingList.length">
      <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="totalCount" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
      </el-pagination>
    </div>
    <Footer></Footer>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
  import { InterfaceService } from "@/services/api";
  import SearchBar from "@/components/SearchBar";
  import Loading from "@/components/base/Loading";
  import Footer from "@/components/base/Footer";
  import Header from "@/components/base/Header";
  import LightColorMenuBar from "@/components/LightColorMenuBar";
  // import FixedTool from '@/components/FixedTool'
  export default {
    components: {
      SearchBar,
      Loading,
      Footer,
      Header,
      LightColorMenuBar,
      // FixedTool,
    },
    watch:{
      // pageIndex(newVal){
      //   console.log(newVal);
      //   this.biddingList = []
      //   let maxPage = this.pageSize * newVal;
      //   if (maxPage >= this.total) {
      //     for (let i = this.pageSize * (newVal - 1); i < this.total;i++){
      //       this.biddingList.push(this.biddingList[i])
      //     }
      //   }else {
      //     for (let i = this.pageSize * (newVal - 1); i < maxPage;i++){
      //       this.biddingList.push(this.biddingList[i])
      //     }
      //   }
      // }
    },
    data() {
      return {
        isLoading:false,
        showDraftBoxList:false,
        currentRouter: "bidWinningAnnouncement",
        keyWord: "",
        totalCount: 0,
        pageSize: 10,
        pageIndex: 1,
        biddingList: [],
      };
    },
    methods: {
      handleSearch() {
        this.pageIndex = 1;
        this.getBidBulletinList()
      },
      listenIsShowFooter() {
        this.showDraftBoxList = true
      },
      handleOpen(item) {
        // this.$setRootScope('biddingInfo',JSON.stringify(item));
        window.open(this.$router.resolve({
          path: "/bidBulletinDetail",
          query: {
            bidNo : item.bidNo,
            enterBidNo : item.enterBidNo,
            type: '1',
          },
        }).href, '_blank')
      },
      handleCurrentChange(page) {
        this.pageIndex = page;
        this.getBidBulletinList();
        window.scrollTo(0, 0);
      },
      getBidBulletinList() {
        let params = {
          pageIndex :  this.pageIndex,
          keyWord : this.keyWord,
        };
        InterfaceService.getBidBulletinList(
          params,
          data => {
            if (data.respData.respCode === "0000") {
              this.biddingList = data.respData.bidCategoryNodeBeans || [];
              this.pageSize = data.respData.pageSize || 0;
              this.totalCount = data.respData.totalCount || 0;
              this.biddingList.forEach(item=>{
                item.categoryName = "";
                if (item.categoryInfos) {
                  if (item.categoryInfos.length === 1) {
                    item.categoryName = item.categoryInfos[0].threeCategoryName;
                  }else {
                    let list = []
                    item.categoryInfos.forEach(_item => {
                      list.push(_item.twoCategoryName)
                    });
                    list = [...new Set(list)];
                    item.categoryName = list.join('、')
                  }

                }
              });
            } else {
              this.$message.error(data.respData.respMsg);
            }
          },
          data => { },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      },
      init() {
        this.getBidBulletinList()
      },
    },
    mounted() {
      this.init()
    },
    destroyed() {
    }
  };
</script>

<style lang="scss" scoped>
  .list-home {
    .list-content {
      width: 1190px;
      margin: 0 auto;
      table {
        table-layout: fixed;
        width: 100%;
        line-height: 17px;
        font-size: 12px;
        td {
          padding: 20px 10px;
          vertical-align: middle;
          word-break: break-all;
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          border-bottom: 1px solid #eee;
          font-weight: bold;
        }
        .tbody-row {
          &:hover {
            background: #f0f8ff;
          }
        }
        tbody {
          text-align: left;
          tr {
            border-bottom: 1px solid #eee;
          }
          .border-none{
            border-bottom:none;
          }
        }
      }

    }
  }
  .bg-content{
    width: 100%;
    height: 150px;
    margin: 0 auto;
    background: url("../../../assets/images/bidding/bid-winning-bg.png") no-repeat center;
    .search{
      width: 1190px;
      margin: 0 auto;
      text-align: center;
      padding-top: 58px;
      /deep/ .el-input{
        width: 674px;
        height: 34px;
        input{
          height: 34px;
        }
      }
      /deep/ .el-button{
        margin-left: -4px;
      }
    }
  }

</style>
