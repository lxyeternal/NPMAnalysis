<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <div class="app-search-bar isWhiteBg">
            <div class="search-bar-container inner-container" style="position: relative;">
                <div class="index-logo">
                    <div class="logo">
                        <h1>
                            <a @click="go('/home')" class="logo-bd"></a>
                        </h1>
                    </div>
                </div>
                <ViceHeader :title="title" :flow="flow"></ViceHeader>
            </div>
        </div>
        <div class="inner-container" :style="{height:height,minHeight: '350px'}">
            <div class="content">
                <div class="icon-success"></div>
                <h3>《发货通知单》签署成功！</h3>
                <p>您可以点击【查看发货通知单】查看签署效果！</p>
                <div>
                    <el-button size="large" type="primary" @click="handleView">查看《发货通知单》</el-button>
                    <el-button size="large" @click="handleRequire">返回材料管理</el-button>
                    <!-- <el-button size="large" @click="go('/home')">返回首页</el-button> -->
                </div>
            </div>

        </div>

        <Footer></Footer>
    </div>
</template>
<script>
import Header from "@/components/base/Header";
import ViceHeader from "@/components/base/ViceHeader";
import PanelTitle from "@/components/base/PanelTitle";
import Footer from "@/components/base/Footer";

export default {
    components: {
        Header,
        ViceHeader,
        Footer,
        PanelTitle
    },
    data() {
        return {
            flow: [
                {
                    name: "创建要货单",
                    active: false,
                    next: true
                },
                {
                    name: "确认并创建要货单",
                    active: false,
                    next: true
                },
                {
                    name: "要货单创建成功",
                    active: true,
                    next: false
                }
            ],
            requireNo: "",
            requireBatchNo: "",
            attachUrl: ''
        };
    },
    computed: {
        title() {
            let str = `发起要货 - 第${this.requireBatchNo || ""}批`;
            return str;
        },
        height() {
            let h =
                window.innerHeight ||
                document.documentElement.clientHeight ||
                document.body.clientHeight;
            return h - 200 - 55 - 34 - 160 + "px";
        },
        role() {
            return this.$store.state.userInfo
                ? this.$store.state.userInfo.bs
                : 0;
        }
    },
    methods: {
        handleView() {
            window.open(this.attachUrl, "_blank");
        },
        handleRequire() {
            let path = "";
            if (this.role == "S") {
                path = "/vendorCenter/requireOrderList";
            } else if (this.role == "B") {
                path = "/purchaserCenter/requireOrderList";
            }
            this.$router.push({
                path: path
            });
        },
        go(path) {
            this.$router.push({
                path: path
            });
        }
    },
    mounted() {
        this.requireNo = this.$route.query.requireNo;
        this.requireBatchNo = this.$route.query.requireBatchNo;
        this.attachUrl = this.$route.query.attachUrl;
    }
};
</script>
<style lang="scss" scoped>
/deep/ .el-button {
    width: 200px;
}

h3 {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 10px;
}
.content {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    text-align: center;

    p {
        margin-bottom: 20px;
    }
}

.icon-success {
    width: 80px;
    height: 80px;
    margin: auto;
    background: url(../../assets/images/green_yes.png) no-repeat;
}
</style>

