<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <SearchBar :is-white-bg="true" :search-type="5" :progress="'修改协议价'" :is-border-bottom="false" :product-create-process="2"></SearchBar>
        <Loading :is-loading="isLoading"></Loading>

        <div class="inner-container">
            <div class="header">
                <ul>
                    <li class="active">货物列表</li>
                </ul>
            </div>
            <div class="order-list">
                <table>
                    <thead>
                        <tr>
                            <td width="150">
                                <i class="red">*</i>型号</td>
                            <td width="200">物料名称</td>
                            <td>供应商</td>
                            <td>
                                <i class="red">*</i>采购量</td>
                            <!-- <td>单价(税前)</td> -->
                            <td>协议价(税前)</td>
                            <td>运费(税前)</td>
                            <td width="200">总价(税前)</td>
                            <td width="80"></td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr v-for="(item,index) in orderList" :key="index">
                            <td>{{item.model}}</td>
                            <td>{{item.skuName}}</td>
                            <td>{{orderInfo.supplierName}}</td>
                            <td>{{item.buyCount}}{{item.goodsUnit}}</td>
                            <!-- <td>{{item.price | formatMoney}}元</td> -->
                            <td class="agree-price" @click="handleEdit(item,index)">
                                <!--<input v-if="item.isEdit" placeholder="请输入" v-model="item.price" @input="handleNumber(item)" v-input-number />-->
                                <input v-if="item.isEdit" placeholder="请输入" v-model="item.price" v-input-number />
                                <span v-if="!item.isEdit">{{item.price | formatMoney}}元</span>
                                <i class="error-msg red" v-if="item.showError&&(!item.price||item.price<=0)">协议价不能为0</i>
                            </td>
                            <td>{{item.freightAmt | formatMoney}}元</td>
                            <td>{{computeTotal(item) | formatMoney}}元</td>
                            <td>
                                <a v-if="!item.isEdit" @click="handleEdit(item,index)">编辑</a>
                                <a v-if="item.isEdit" @click="handleConfirm(item,index)">确定</a>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div style="margin-top: 10px;" class="red" v-if="isEdit">您当页还有未确定的协议价</div>
                <div class="table-pagination" v-if="orderList.length">
                    <el-pagination :disabled="isEdit" @current-change="handleOrderCurrentChange" :current-page="orderPageIndex" :page-size="orderPageSize" :total="orderTotal" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                    </el-pagination>
                </div>
                <div class="subtotal">
                    小计：共{{orderTotal}}件商品
                </div>
            </div>
            <div class="header">
                <ul>
                    <li class="active">合同信息</li>
                </ul>
            </div>
            <div class="contract-info">
                <p>
                    <label>合同名称：</label>《{{orderInfo.contractName}}》</p>
                <p>
                    <label>计划供货周期：</label>{{orderInfo.supplyFrom}}~{{orderInfo.supplyTo}}</p>
                <p v-if="orderInfo.expiration">
                    <label>货物的质量保证期：</label>{{orderInfo.expiration}}年</p>
            </div>
            <div class="order-total">
                <p class="total-content">
                    <label>合同价款(税前)：￥{{computeAllTotal()|formatMoney}}</label>
                    <label style="margin-bottom: 10px;">(含税前运费：￥{{computeAllAfreight()|formatMoney}})</label>
                    <label>税率：{{orderInfo.orderTaxRateRange}}</label>
                    <label>税额：￥{{computeAllTax()|formatMoney}}</label>

                    <label class="total">合同价款(含税)：
                        <span class="red-font">￥
                            <span class="big">{{computeAllAmount()|formatMoney}}</span>
                        </span>
                    </label>
                </p>
                <p>送货至：{{orderInfo.consigneeAddr}}</p>
                <p>收货人：{{orderInfo.consigneeName}}&nbsp;{{orderInfo.consigneeMobile}}</p>
            </div>
            <div class="tr">
                <el-button class="btn-bottom" type="primary" size="large" @click="handleOrder">
                    {{orderInfo.orderStatus=='01'?'确认修改':'重新提交合同'}}
                </el-button>
            </div>
        </div>
    </div>
</template>

<script>
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import accountMixin from "@/mixins/account";
import { MoneyUtil } from '@/utils/moneyUtil';

export default {
    mixins: [accountMixin],
    components: {
        Header,
        SearchBar,
        Loading
    },
    data() {
        return {
            isLoading: false,
            orderNo: "",
            orderInfo: {},
            orderList: [],
            comfirmOrderList: [],
            brokerCorpId:'',
            isEdit:false,
            orderPageIndex:1,
            orderTotal:0,
            orderPageSize:10
        };
    },
    methods: {
        handleConfirm(item, index) {
            if (!item.price || item.price <= 0) {
                item.showError = true;
                this.$set(this.orderList, index, item);
                return;
            } else {
                item.isEdit = false;
                this.isEdit = false;
                this.$set(this.orderList, index, item);
            }
            let valid = true;
            this.orderList.forEach(item => {
                if (item.isEdit) {
                    valid = false;
                }
            });
            this.isEdit = !valid;
        },
        handleOrderCurrentChange(page){
            this.orderPageIndex = page;
            this.recordOrder();
            this.getOrderDetail();
            window.scrollTo(0,0)
        },
        handleEdit(item, index) {
            item.isEdit = true;
            this.isEdit = true;
            this.$set(this.orderList, index, item);
        },
        handleOrder() {
            let valid = true;
            this.orderList.forEach(item => {
                if (item.isEdit) {
                    valid = false;
                }
            });
            if (valid) {
                if (this.orderInfo.orderStatus == "01") {
                    this.doOrder();
                } else {
                    this.reOrder();
                }
            } else {
                this.showMessage("您当页还有未确定的协议价");
            }
        },
        handleNumber(el) {
            if(!el.price){
                return;
            }
            if (!el.price.match(/^[\+]?\d*?\.?\d*?$/)){
                if(el.price.length == 1){
                    el.price = null;
                }else{
                    el.price = el.t_value || null;
                }
            }
            else {el.t_value = el.price;}
        },
        computeTotal(item) {
            return item.buyCount * item.price + Number(item.freightAmt);
        },
        computeAllAfreight() {
            let freight = 0;
            if (this.orderList && this.orderList.length) {
                this.orderList.forEach(item => {
                    freight += +item.freightAmt;
                });
            }
            return freight;
        },
        computeAllTotal() {
            let total = 0;
            if (this.orderList && this.orderList.length) {
                this.orderList.forEach(item => {
                    total += item.buyCount * item.price;
                });
            }
            total += this.computeAllAfreight();
            // return Number(total.toFixed(2));
            return Number(MoneyUtil.moneyFixed(total,2));
        },
        computeAllTax() {
            let tax = 0;
            if (this.orderList && this.orderList.length) {
                this.orderList.forEach(item => {
                    tax += (this.computeTotal(item))* item.taxRate;
                });
            }
            // return Number(tax.toFixed(2));
            return Number(MoneyUtil.moneyFixed(tax,2));
        },
        computeAllAmount() {
            let amount = 0;
            amount = this.computeAllTotal() + this.computeAllTax();
            return amount;
        },
        //记录已选择的订单
        recordOrder(){
            this.orderList.forEach(_item=>{
                let onOff = false;
                this.comfirmOrderList.forEach(item=>{
                    if (item.skuId == _item.skuId) {
                        item.price = _item.price;
                        onOff = true
                    }
                });
                if (!onOff) {
                    this.comfirmOrderList.push(_item)
                }
            });
        },
        showMessage(msg, cb) {
            this.$alert(msg, {
                dangerouslyUseHTMLString: true,
                customClass: "alert-box",
                center: true,
                confirmButtonText: "知道了",
                callback: cb || (action => {})
            });
        },
        getOrderDetail() {
            const params = {
                orderNo: this.orderNo,
                pageIndex : this.orderPageIndex,
                sort:"0_0_0"
            };
            InterfaceService.getOrderDetail(
                params,
                data => {
                    console.log(data);
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        this.orderInfo = data.respData || {};
                        this.orderList = data.respData.orderList || [];
                        this.orderPageSize = data.respData.pageSize;
                        this.orderTotal = data.respData.totalCount;
                        this.orderList.forEach(item => {
                            item.price = +item.price;
                        });
                        this.comfirmOrderList.forEach(item=>{
                            this.orderList.forEach(_item=>{
                                if (_item.skuId == item.skuId) {
                                    _item.price = item.price;
                                }
                            })
                        });
                    } else {
                        this.$message.error(res.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        doOrder() {
            this.recordOrder();
            let list = [];
            this.comfirmOrderList.forEach(item => {
                list.push({
                    id: item.id,
                    skuId: item.skuId,
                    price: +item.price
                });
            });
            const params = {
                orderNo: this.orderNo,
                orderList: list
            };
            InterfaceService.editAgreePrice(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        this.showMessage("修改协议价成功", () => {
                            this.$router.push({
                                path: "/purchaserCenter/orderList"
                            });
                        });
                    } else {
                        if (res.errorInfos) {
                            this.$message.error(res.errorInfos[0].message);
                        }
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        reOrder() {
            this.recordOrder();
            const order = this.orderInfo;
            const list = [];
            this.comfirmOrderList.forEach(item => {
                list.push({
                    id: item.id,
                    skuId: item.skuId,
                    price: +item.price
                });
            });
            const brokerCorpId = this.brokerCorpId; // 材料公司ID
            const params = {
                addressId: order.addressId,
                payType: 2,
                supplierId: order.supplierId,
                orderMsg: order.orderMsg,
                supplyFrom: order.supplyFrom,
                supplyTo: order.supplyTo,
                projectName: order.projectName,
                projectProvCode: order.projectProvCode,
                projectCityCode: order.projectCityCode,
                projectDistrictCode: order.projectDistrictCode,
                engineeringName: order.engineeringName,
                additionInfo: order.additionInfo,
                contractName: order.contractName,
                contractType: order.contractType,
                contractStakeHolders: order.contractStakeHolders,
                expiration: order.expiration,
                isNegotiatedPrice: "Y",
                itemList: list,
                brokerCorpId: brokerCorpId
        };
            InterfaceService.pushOrder(
                params,
                data => {
                    console.log(data);
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        this.showMessage("重新提交合同成功", () => {
                            this.$router.push({
                                path: "/purchaserCenter/orderList"
                            });
                        });
                    } else {
                        if (res.errorInfos) {
                            this.$message.error(res.errorInfos[0].message);
                        }
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
    },
    mounted() {
        this.orderNo = this.$route.query.orderNo;
        this.getOrderDetail();
        if (this.userinfo.brokerList.length > 0){
            this.brokerCorpId = this.userinfo.brokerList[0].brokerCorpId
        }
    }
};
</script>

<style lang="scss" scoped>
.inner-container {
    margin-bottom: 100px;
    font-size: 14px;
}
.header {
    margin-bottom: 20px;
    background: #f5f5f5;

    ul {
        width: 100%;
        height: 48px;
        border-bottom: 3px solid #ffd64e;
        font-weight: bold;

        li {
            width: 150px;
            height: 48px;
            line-height: 48px;
            text-align: center;
            float: left;
            cursor: pointer;
            position: relative;

            &:after {
                display: none;
                position: absolute;
                bottom: 0px;
                left: 0;
                content: "";
                width: 100%;
                height: 3px;
                background: #4f525a;
            }

            &.active:after {
                display: block;
            }
        }
    }
}
.order-total {
    padding: 20px 40px;
    border-top: 1px solid #e2e2e2;
    text-align: right;
    font-size: 12px;
    line-height: 25px;
    color: #888888;
    background: #f5f5f5;

    label {
        display: block;
        color: #444444;
    }

    .total-content {
        margin-bottom: 10px;
    }

    .total {
        font-weight: bold;
        font-size: 14px;
    }

    .bold {
        font-weight: bold;
    }

    .big {
        font-size: 20px;
    }

    .red-font {
        color: #e94650;
    }
}
.btn-bottom {
    width: 150px;
}

.contract-info {
    p {
        margin-bottom: 20px;
    }
    label {
        color: #888888;
    }
}

.order-list {
    table {
        width: 100%;
        text-align: center;

        thead td {
            height: 40px;
            vertical-align: middle;
            color: #888888;
        }

        tbody {
            background: #f5f5f5;

            td {
                height: 80px;
                vertical-align: middle;
                padding: 10px;
                overflow: hidden;
            }
        }

        a {
            color: #0082ff;
        }
    }

    .agree-price {
        position: relative;
        input {
            width: 100px;
            background: white;
            height: 34px;
            border: 1px solid #dddddd;
        }
        .error-msg {
            position: absolute;
            bottom: 2px;
            left: 0;
            right: 0;
        }
    }

    .subtotal {
        padding: 10px;
        text-align: right;
    }
}
</style>


