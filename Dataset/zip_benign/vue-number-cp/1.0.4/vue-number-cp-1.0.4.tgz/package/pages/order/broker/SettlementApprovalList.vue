<template>
    <div class="product">
        <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
        <!-- 查询条件 -->
        <el-form class="form" ref="form" :model="form" label-width="80px">
            <el-row>
                <el-col :span="2">
                    <span class="search-title">结算主题</span>
                </el-col>
                <el-col :span="19">
                    <el-input
                            v-model="form.settleTheme"
                            clearable
                            @keyup.enter.native="handleSearch"
                    ></el-input>
                </el-col>
                <el-col :span="3">
                    <el-button
                            type="primary"
                            size="small"
                            style="width: 100%"
                            @click="handleSearch"
                    >搜索</el-button
                    >
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="12">
                    <el-form-item label="城市公司">
                        <el-select placeholder="请选择城市公司" v-model="form.cityCompany" @change="handleDropdownSelectChange">
                            <el-option value="" label="全部"></el-option>
                            <el-option v-for="(item,index) in cityCompanyList" :value="item" :key="index"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="项目名称">
                        <el-select placeholder="请选择项目" v-model="form.projectName" @change="handleDropdownSelectChange">
                            <el-option value="" label="全部"></el-option>
                            <el-option v-for="(item,index) in projectNameList" :value="item" :key="index"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="12">
                    <el-form-item label="供应商">
                        <el-select placeholder="请选择供应商" v-model="form.supplierName" @change="handleDropdownSelectChange">
                            <el-option value="" label="全部"></el-option>
                            <el-option v-for="(item,index) in supplierNameList" :value="item" :key="index"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="24" v-if="tab == 1 && settlementRole">
                    <div class="specifications-choose clearfloat">
                        <ul class="fl">
                            <li :class="{'active':form.executionStatus === ''}" @click="changeExecutionStatus('')">全部</li>
                            <li :class="{'active':form.executionStatus === 'rejected'}" @click="changeExecutionStatus('rejected')">
                                被退回
                                <em class="red" v-if="rejectedRemind == '1'">●</em>
                            </li>
                            <li :class="{'active':form.isDraft === '1'}" @click="changeExecutionStatus('1')">已存草稿</li>
                        </ul>
                        <el-button size="small" style="width: 120px;margin-top: 4px;" class="fr" @click="handleDownloadList">
                            导出清单
                        </el-button>
                    </div>
                </el-col>
                <el-col :span="24" v-if="tab == 3">
                    <div class="specifications-choose clearfloat">
                        <ul class="fl">
                            <li :class="{'active':form.executionStatus === ''}" @click="changeExecutionStatus('')">全部</li>
                            <li :class="{'active':form.executionStatus === 'processing'}" @click="changeExecutionStatus('processing')">进行中</li>
                            <li :class="{'active':form.executionStatus === 'end'}" @click="changeExecutionStatus('end')">审批完成</li>
                            <li v-if="settlementRole" :class="{'active':form.executionStatus === 'closed'}"  @click="changeExecutionStatus('closed')">已关闭</li>
                        </ul>
                        <el-button v-if="settlementRole" size="small" style="width: 120px;margin-top: 4px;" class="fr" @click="handleDownloadList">
                            导出清单
                        </el-button>
                    </div>
                </el-col>
            </el-row>
        </el-form>
        <div class="product-table">
            <!-- 列表 -->
            <div class="check-all" v-if="tab == 1 && (recruitmentRole || operateRole || financeRole || managerRole)">
                <div class="check">
                    <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow" :disabled="disableAllCheck"></el-checkbox><span>当页全选</span>
                </div>
                <div class="sign f18">
                    <el-button size="mini" :disabled="!hasChecked" @click="handleBatchOrderConfirm">批量审批</el-button>
                </div>
            </div>
            <table>
                <thead>
                <tr>
                    <th width="40px">&nbsp;</th>
                    <th width="100px">城市公司</th>
                    <th width="130px">项目名称</th>
                    <th>结算主题</th>
                    <th width="120px">供应商</th>
                    <th width="100px">最终结算金额</th>
                    <th v-if="tab == 3" width="100px">状态</th>
                    <th width="100px" style="text-align: center">操作</th>
                </tr>
                </thead>
                <tbody v-for="(item,index) in settleApproveInfos" :key="index" class="tbody-row">
                <tr>
                    <td v-if="tab == 1 && item.status == 'processing'" style="text-align: center">
                        <el-checkbox v-model="item.checked" :disabled="disableAllCheck"  @change="handleSelectTableRow(item,index)"></el-checkbox>
                    </td>
                    <td v-else width="60px">&nbsp;</td>
                    <td>{{item.cityCompany}}</td>
                    <td>{{item.projectName}}</td>
                    <td><span>{{item.settleTheme}}</span></td>
                    <td>{{item.supplierName}}</td>
                    <td class="tr" v-if="item.outSettleInfoStatus === 'init'">{{item.erpSettleAmount | formatMoney}}</td>
                    <td class="tr" v-else>{{item.outSettleAmount | formatMoney}}元</td>
                    <td v-if="tab == 3">{{item.taskDisc}}</td>
                    <td style="text-align: right">
                        <SettlementListOperate v-if="item" :item="item" :tab="tab" @refresh="handleSearch"></SettlementListOperate>
                    </td>
                </tr>
                <tr class="retreat" v-if="tab == 1 && item.status == 'rejected'">
                    <td colspan="6">退回原因：{{item.comment}}</td>
                    <td colspan="1" style="text-align: left;text-indent:0"><span>退回人：{{item.acctName}}</span></td>
                </tr>
                </tbody>
            </table>
            <div class="table-pagination" v-if="brokerApprovalList.length">
                <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                </el-pagination>
            </div>
            <!--空列表-->
            <div class="product-empty" v-if="!brokerApprovalList.length&&!isLoading">
                <img src="@/assets/images/icon-no-product.png">
                <p>没有搜索到相关结算主题，请重新修改搜索条件搜索！</p>
            </div>
            <!-- 批量确认审批合同 -->
            <el-dialog class="dialog" title="确认并进行合同审批" :append-to-body="true" :lock-scroll="true" :visible.sync="batchApproavlDialogVisible" width="840px" center :close-on-click-modal="false" @close="handleClear()">
                <div class="line-top"></div>
                <div class="f14 tl">确认进行已勾选的<em class="red">{{selectedSignLength}}</em>份合同审批</div>
                <div class="contract-list tl">
                    <p v-for="item in signbrokerApprovalList">{{item.settleTheme}}</p>
                </div>
                <el-input style="margin: 20px 0;" type="textarea" v-model="comment" placeholder="请填写批量审批或退回的原因,300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
                <div class="count">
                    <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
                </div>
                <div slot="footer" class="dialog-footer">
                    <el-button type="primary" size="small" style="width: 100px" @click="handleConfirmDialog('Y')">批量同意</el-button>
                    <el-button :disabled="!comment" type="primary" size="small" style="width: 100px" @click="handleConfirmDialog('N')">批量退回</el-button>
                    <el-button size="small" style="width: 100px" @click="batchApproavlDialogVisible = false">取消</el-button>
                </div>
            </el-dialog>
            <!--审批退回-->
            <el-dialog class="dialog" title="批量退回原因" :append-to-body="true" :lock-scroll="true" :visible.sync="rejectedDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;rejectedReason = ''">
                <div class="line-top"></div>
                <div class="f14" style="text-align: left">请填写批量退回的原因</div>
                <el-input style="margin: 20px 0;" type="textarea" v-model="rejectedReason" placeholder="请填写批量退回的原因,300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
                <div class="count">
                    <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
                </div>
                <div slot="footer" class="dialog-footer">
                    <el-button type="primary" :disabled="!rejectedReason" size="small" style="width: 100px" @click="handleConfirm('N')">批量退回</el-button>
                    <el-button size="small" style="width: 100px" @click="rejectedDialogVisible = false;batchApproavlDialogVisible=true">取消</el-button>
                </div>
            </el-dialog>
            <!--审批结果-->
            <el-dialog class="sign-result-dialog" :title="approvalOrReject+'结果'" :append-to-body="true" :lock-scroll="true" :visible.sync="approavlResultDialogVisible" width="840px" center :close-on-click-modal="false" @close="getApprovalList">
                <div class="line-top" style="top:50px"></div>
                <div style="text-align: left">
                    <div v-if="signFailNum > 0">
                        <div class="f14 bold"><em class="red">{{selectedSignLength}}</em>份合同{{approvalOrReject}}成功，<em class="red">{{signFailNum}}</em>份合同{{approvalOrReject}}失败。</div>
                        <div class="fail-reason-list">失败原因：{{failReasonList.join('；')}}。
                        </div>
                        <div style="color:#bbb">{{approvalOrReject}}失败的合同可以在【待处理】栏查看。</div>
                    </div>
                    <div class="f14 bold" v-if="signFailNum == 0">批量{{approvalOrReject}}成功！{{approvalOrReject}}成功的合同可在【已处理】栏内查看</div>
                    <div v-if="signFailNum > 0">※若有疑问请联系平台客服：<em class="blue">{{$platformContact()['hotLine']}} （{{$platformContact()['hotLineTime']}}</em></div>
                </div>
                <div class="sign-result">
                    <el-button @click="approavlResultDialogVisible=false" size="mini" style="border: 1px solid #000;background: #fff">知道了</el-button>
                </div>
            </el-dialog>
        </div>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    import accountMixin from "@/mixins/account";
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import SettlementListOperate from "@/components/order/broker/SettlementListOperate";
    import BrokerApproval from "@/components/order/broker//BrokerApproval";
    import { InterfaceService } from "@/services/api";
    import {DateUtil} from '@/utils/dateUtil';

    const params = {
        procDefKeyList: ["SETTLE_APPROVE_WF"],
        cityCompany:"",
        projectName:"",
        supplierName:"",
        year:"",
        season:"",
        tab:"",
        executionStatus:"",
        pageIndex: 1,
        approveStatus:"",
        isDraft:"",
        pageSize:10,
        settleTheme: '', // 搜索
    };

    export default {
        mixins: [accountMixin],
        components: {
            Loading,
            PanelTitle,
            SettlementListOperate,
            BrokerApproval,
        },
        data() {
            return {
                tab: "",
                rejectedRemind: "",
                rejectedReason: "",
                comment: "",
                tabs: [],
                form: Object.assign({}, params),
                total: 0,
                entryNum: 0,
                signFailNum: 0,
                selectedSignLength: 0,
                isLoading: false,
                allChecked: true,
                hasChecked: true,
                disableAllCheck: false,
                batchApproavlDialogVisible: false,
                approavlResultDialogVisible: false,
                rejectedDialogVisible: false,
                brokerApprovalList:[],
                settleApproveInfos:[],
                failReasonList:[],
                cityCompanyList:[],
                projectNameList:[],
                supplierNameList:[],
                approvalResult:[],
                signbrokerApprovalList:[],
                executionId:"",
                approvalOrReject:"",
                ccTabVisible:"0",
                ccTabVisibleType:true,
            };
        },
        computed: {
        },
        filters: {
            percent(val) {
                return (val * 100)+ "%";
            }
        },
        methods: {
            // 下拉框改变
           handleDropdownSelectChange (){
                this.form.pageIndex = 1
                this.getApprovalList()
            },
            // 修改tab
            handleChangeTab(tab) {
                this.tab = tab.index;
                this.recoverStatus(this.tab);
                this.form.pageIndex  = 1;
                this.getApprovalList();
            },
            handleEntry(ev){
                this.entryNum = ev.length
            },
            handleClear(){
                this.comment = "";
                this.entryNum = 0
            },
            // 选中行
            handleSelectTableRow(item, index) {
                this.$set(this.settleApproveInfos, index, item);
                this.checkBatch();
                this.checkAllSelect();
            },
            //导出清单
            handleDownloadList() {
                InterfaceService.settlementApprovalExport(
                    {},
                    data => {
                        if (data.respData.respCode === "0000") {
                            let attachUrl = data.respData.attachUrl || "";
                            if (!attachUrl) {
                                this.$message.error("暂无清单数据！")
                                return
                            }
                            let name = attachUrl.split("?")[0];
                            name = name.split("/").pop();
                            const files = [
                                { name: decodeURIComponent(name), url: attachUrl }
                            ];
                            this.$download(files, () => {this.isLoading = true}, () => {this.isLoading = false}).then(result => {
                                this.$message.success('已下载')
                            }).catch(err => {
                                this.$message.error('下载失败')
                            })
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );

            },
            // 全选
            handleAllSelectTableRow(bool) {
                let arr = [];
                arr = [].concat(this.settleApproveInfos);
                arr.forEach(item => {
                    item.checked = bool;
                });
                if (arr.length != 0){
                    this.settleApproveInfos = arr;
                }else {
                    this.allChecked = false
                }
                this.checkBatch();
            },
            // 是否全选
            checkAllSelect() {
                this.allChecked = this.settleApproveInfos.every(item => {
                    return item.checked;
                });
            },
            // 是否可批量
            checkBatch() {
                this.hasChecked = this.settleApproveInfos.some(item => {
                    return item.checked;
                });
                let num = 0;
                this.settleApproveInfos.forEach(item=>{
                    if (item.checked){
                        num++
                    }
                });
                this.selectedSignLength = num
            },
            // 分页跳转
            handleCurrentChange(page) {
                this.form.pageIndex = page;
                this.getApprovalList();
                window.scrollTo(0,0);
            },
            handleConfirmDialog(type){
                let content = "";
                let message = "";
                if (type == "Y") {
                    content = "确认批量审核吗？";
                    message = "批量审核成功！"
                } else if (type == "N") {
                    content = "确认批量退回吗？";
                    message = "批量退回成功！";
                }
                this.$confirm(
                    content,
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认",
                        cancelButtonText: '取消',
                    }).then(() => {
                    this.handleConfirm(type);
                })
            },
            // 审批，非发起审批
            handleConfirm(type){
                let executionList = [];
                if (!this.comment) {
                    this.comment = "同意"
                }
                this.signbrokerApprovalList.forEach(item=>{
                    executionList.push({
                        executionId: item.executionId,
                        isAgree: type,
                        comment: this.comment,
                        procDefKey : "SETTLE_APPROVE_WF"
                    })
                });
                const params = {
                    executionList: executionList
                };
                InterfaceService.batchApprovalProcess(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            this.approvalResult = data.respData.respList;
                            let failNum = 0;                              // 批量审批失败的数量
                            let successNum = 0;
                            let hash=[];
                            this.failReasonList = [];
                            this.approvalResult.forEach(item=>{
                                if (item.approveCode == "0000"){
                                    successNum ++;
                                } else {
                                    failNum ++;
                                    hash.push(item.approveMsg);
                                }
                            });
                            //  审批失败时返回的Msg去重
                            for (let i = 0; i < hash.length; i++) {
                                for (let j = i+1; j < hash.length; j++) {
                                    if(hash[i]===hash[j]){
                                        ++i;
                                    }
                                }
                                this.failReasonList.push(hash[i]);
                            }
                            if (failNum == 0) {
                                let msg = "批量审批操作成功";
                                type == 'Y' ? msg : msg = "批量退回操作完成";
                                this.$message.success(msg);
                                this.getApprovalList();
                            } else {
                                type == 'Y' ? this.approvalOrReject = "审批" : this.approvalOrReject = "退回";
                                this.approavlResultDialogVisible = true;
                            }
                            this.signFailNum = failNum;
                            this.selectedSignLength = successNum;
                            this.rejectedReason = "";
                            this.batchApproavlDialogVisible = false;
                            this.rejectedDialogVisible = false;
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            //进行中、关闭、完结状态
            changeExecutionStatus(type){
                if (type == "1") {
                    this.form.executionStatus = null;
                    this.form.isDraft = type
                }else {
                    this.form.executionStatus = type;
                    this.form.isDraft = "";
                }
                if (type == "rejected") {
                    this.UpdateCacheInfos()
                }else {
                    this.form.pageIndex = 1;
                    this.getApprovalList()
                }

            },
            // 批量确认合同弹窗
            handleBatchOrderConfirm() {
                this.batchApproavlDialogVisible = true;
                const signbrokerApprovalList = [];
                this.settleApproveInfos.forEach(item => {
                    if (item.checked) {
                        signbrokerApprovalList.push(item);
                    }
                });
                this.signbrokerApprovalList = signbrokerApprovalList;
                this.selectedSignLength = this.signbrokerApprovalList.length
            },
            UpdateCacheInfos(){
                let params = {
                    userCaches:[{
                        targetId:"1008",
                        key:"SETTLEMENT_REJECTED_CACHE_KEY",
                        value:"0",
                    }]
                };
                InterfaceService.UpdateCacheInfos(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.rejectedRemind = "0";
                            this.form.pageIndex = 1;
                            this.getApprovalList()
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            //全部、ERP状态
            changeApproveStatus(type){
                this.form.approveStatus = type;
                this.form.pageIndex = 1;
                this.getApprovalList()
            },
            // 恢复状态
            recoverStatus(tab) {
                this.form.tab = tab;
                this.form.executionStatus = "";
                this.form.isDraft = "";
                this.form.approveStatus = "";
                this.form.cityCompany="";
                this.form.projectName="";
                this.form.year="";
                this.form.season="";
                this.form.settleTheme = "";
            },
            // 待签署合同
            init() {
                this.getcTabVisible();
                // this.getApprovalList();
            },
            //第一次去看是否抄送可见
            getcTabVisible(){
                let params = {
                    "procDefKeyList":["SETTLE_APPROVE_WF"],
                    "tab":"1",
                    "pageIndex":1
                };

                InterfaceService.getApprovalList(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.brokerApprovalList = data.respData.executionList || [];
                            this.ccTabVisible = data.respData.ccTabVisible;
                            this.ccTabVisibleType = this.ccTabVisible == "1";
                            if (this.ccTabVisibleType) {
                                this.tabs = [
                                    { label: "流程抄送", index: "4" , active: true},
                                ];
                                this.tab = "4";
                                this.form.tab = "4"
                            }else {
                                if (this.settlementRole){
                                    this.tabs = [
                                        { label: "待处理", index: "1"},
                                        { label: "已处理", index: "3" },
                                    ];
                                } else if (this.managerRole) {
                                    this.tabs = [
                                        { label: "待处理", index: "1"},
                                        { label: "已处理", index: "3" },
                                        { label: "抄送流程", index: "4" },
                                    ]
                                }else {
                                    this.tabs = [
                                        { label: "待处理", index: "1"},
                                        { label: "已处理", index: "3" },
                                    ]
                                }
                                this.tab = "1";
                                this.form.tab = "1";
                            }
                            this.getApprovalList();
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            getApprovalList() {
                this.brokerApprovalList = [];
                this.settleApproveInfos = [];
                let params = {};
                params = this.$clone(this.form);
                this.tabs.forEach((item) => {
                    if (item.index == this.tab) {
                        item.active = true
                    }
                });
                delete params.status;
                InterfaceService.getApprovalList(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.brokerApprovalList = data.respData.executionList || [];
                            this.brokerApprovalList.forEach(item => {
                                let infos = item.settleApproveInfos
                                infos.executionId = item.executionId;
                                infos.executionStatus = item.executionStatus;
                                infos.procDefKey = item.procDefKey;
                                if (item.creTm) {
                                    infos.creTm = item.creTm.substring(0,10);
                                }
                                if (item.comment){
                                    infos.comment = item.comment;
                                    infos.acctName = item.acctName
                                }
                                // 整理状态
                                if (item.taskId == "operation_apply") {
                                    infos.taskDisc = "招采合约部结算负责人审批"
                                }else if (item.taskId == "operation_confirm") {
                                    infos.taskDisc = "工程部审批"
                                }else if (item.taskId == "contract_confirm") {
                                    infos.taskDisc = "招采合约部负责人审批"
                                }else if (item.taskId == "finance_confirm") {
                                    infos.taskDisc = "财务部审批"
                                }else if (item.taskId == "vgm_confirm") {
                                    infos.taskDisc = "副总经理审批"
                                }else if (item.taskId == null) {
                                    infos.taskDisc = "审批完成"
                                }else if (item.taskId == "closed") {
                                    infos.taskDisc = "已关闭"
                                }
                                // num++
                                if (item.procDefKey == "SETTLE_APPROVE_WF") {
                                    if (item.executionStatus == 'processing'){
                                        infos.status = "processing";
                                        infos.disc = "进行中";
                                    }else if (item.executionStatus == 'end') {
                                        infos.status = "end";
                                        infos.disc = "已归档"
                                    }else if (item.executionStatus == 'closed'){
                                        infos.status = "closed";
                                        infos.disc = "已关闭"
                                    }else if (item.executionStatus == 'rejected'){
                                        infos.status = "rejected"
                                        infos.disc = "已退回";
                                    }else if (item.executionStatus == 'canceled'){
                                        infos.disc = "已撤回";
                                        infos.status = "canceled"
                                    }else if (item.executionStatus == 'forward'){
                                        infos.disc = "转发中";
                                        infos.status = "forward"
                                    }
                                }
                                this.settleApproveInfos.push(infos)
                            });
                            console.log(this.settleApproveInfos);
                            this.settleApproveInfos.forEach(item=>{
                                item.checked = true;
                            });
                            this.allChecked = this.brokerApprovalList.some(item => {
                                return item.executionStatus == 'processing';
                            });
                            // this.selectedSignLength = num;
                            if (this.settleApproveInfos.length == 0){
                                this.allChecked = false;
                                this.hasChecked = false
                            }else {
                                this.allChecked = true;
                                this.hasChecked = true
                            }
                            this.cityCompanyList = data.respData.cityCompanyList || [];
                            this.projectNameList = data.respData.projectNameList || [];
                            this.supplierNameList = data.respData.supplierNameList || [];
                            this.total = data.respData.totalCount;
                            this.form.pageSize = data.respData.pageSize;
                            if (this.settlementRole && this.tab == "1") {
                                this.getCacheInfos()
                            }
                            console.log(this.settleApproveInfos, 'this.settleApproveInfos');
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            //获取是否有新增被退回信息
            getCacheInfos(){
                let params = {
                    "targetId":"1008",
                    "key":"SETTLEMENT_REJECTED_CACHE_KEY",
                };
                // this.rejectedRemind = true
                InterfaceService.getCacheInfos(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.rejectedRemind = data.respData.value || "0"
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },

            /**
             * 查询
             */
            handleSearch(bool) {
                if (bool) {
                    this.form.pageIndex = 1;
                    this.getApprovalList();
                }
            }
        },
        mounted() {
            if (!this.brokerRole) {
                if (this.role == 'B'){
                    this.$router.push({
                        path : '/purchaserCenter/orderList'
                    });
                }else if (this.role == 'S'){
                    this.$router.push({
                        path : '/vendorCenter/orderList'
                    });
                }
            }else {
                this.init();
            }
        }
    };
</script>

<style lang="scss" scoped>
    .hand + .hand {
        margin-left: 10px;
    }
    .price-tip {
        cursor: pointer;
        color: #a9a9aa;

        &:hover {
            color: #0082ff;
        }
    }

    .product {
        font-size: 14px;
        /deep/ .el-select {
            width: 100%;
        }
        /deep/ .el-col{
            height: 50px;
            margin-bottom: 10px;
            .el-button.active{
                background: #ffd64e;
            }
        }
        /deep/ .el-button--primary {
            height: 40px;
            width: 106px;
        }
        .search-title {
            margin-top: 12px;
            display: block;
            margin-left: 10px;
        }
    }

    .form {
        /deep/ .el-col {
            text-align: left;
            height: 52px;
        }

        /deep/ .el-select {
            width: 100%;
        }
        /deep/ .el-date-editor {
            input.el-input__inner {
                padding: 0 15px;
            }
            .el-input__prefix {
                display: none;
            }
        }

        &:after {
            display: table;
            content: "";
            clear: both;
        }
        /deep/ .third-col{
            .el-form-item__label {
                width: 110px !important;
            }
            .el-form-item__content{
                margin-left: 110px !important;
            }
            .el-input__inner{
                width: 120px;
            }
        }
    }

    .form-item {
        position: relative;
        display: inline-block;
        line-height: 32px;

        .float-right {
            position: absolute;
            top: 2px;
            right: 1px;
            height: 30px;
            padding: 0 7px;
            line-height: 30px;
            background: #ffffff;
        }
    }
    .form-btns {
        text-align: center;
    }

    .product-table {
        /deep/ .el-table__body-wrapper {
            font-size: 12px;
        }
        /deep/ .el-table th,
        .el-table td {
            padding: 14px 0;
        }

        /deep/ .el-button {
            font-size: 12px;
        }

        table {
            table-layout: fixed;
            width: 100%;
            line-height: 23px;
            font-size: 12px;
            td,th {
                padding: 14px 10px;
                vertical-align: middle;
                word-break: break-word;
                text-align: center;
            }
            thead {
                font-size: 14px;
                text-align: center;
                white-space: nowrap;
                color: #909399;
                background: #f5f5f5;
                th{
                    text-align: left;
                }
            }
            .tbody-row{
                td{
                    text-align: left;
                }
                /deep/ .el-button{
                    height: 28px;
                    width: 80px;
                    padding: 0;
                    margin:0 0 10px;
                    span{
                        line-height: 28px;
                    }
                }
            }
            .tbody-row:hover {
                background: #e8f3fd;
            }

            tbody {
                text-align: center;
                tr {

                    &.all-check {
                        text-align: left;

                        &:hover{
                            background: #ffffff;
                        }
                    }
                }

                td {
                    border-bottom: 1px solid #ebeef5;
                }
                .retreat{
                    height: 20px;
                    td:nth-of-type(1){
                        width: 600px;
                    }
                    td{
                        background: #eee;
                        text-align: left;
                        padding: 0;
                        text-indent: 2em;
                        overflow:hidden;
                        white-space:nowrap;
                        text-overflow:ellipsis;
                    }
                }
            }
        }
    }

    .product-empty {
        padding: 150px;
        text-align: center;
        line-height: 50px;
        color: #909399;
    }

    .table-pagination {
        margin: 50px 0 80px;
        text-align: center;
        color: #888888;
    }
    /deep/ .el-dialog__title{
        font-size: 16px;
    }
    /deep/ .el-pagination__jump{
        .el-input{
            width: auto;
        }
    }
    .sign-result-dialog{
        /deep/ .el-dialog__body{
            width: 100%;
        }
        .fail-reason-list{
            line-height: 25px;
        }
        div{
            margin: 20px auto 20px;
        }
        /deep/ .el-button{
            margin: auto;
        }
    }
    .sign-result{
        text-align: center;
        .el-button{
            background: #ffd64e;
            border: none;
            width: 110px;
            height: 34px;
            /*padding-top: 12px;*/
            font-weight: bold;
        }
    }
    .specifications-choose {
        overflow: hidden;
    }
    .specifications-choose ul {
        width: 604px;
        overflow: hidden;
    }
    .specifications-choose ul li {
        padding: 8px;
        float: left;
        line-height: 20px;
        border: 1px solid #dddddd;
        color: #4f525a;
        margin-right: 20px;
        position: relative;
        cursor: pointer;
    }
    .specifications-choose ul li.active {
        padding: 8px;
        border: 2px solid #4f525a;
    }
    .specifications-choose ul li.active:after {
        content: "";
        position: absolute;
        height: 25px;
        width: 25px;
        bottom: -2px;
        right: -2px;
        background: url(../../../assets/images/detail/right.png) no-repeat;
        z-index: 5;
    }
    /deep/ .el-dialog__header:before {
        height: 0;
    }
    /deep/ .el-pagination__editor.el-input .el-input__inner{
        width: 45px;
    }
    .check-all{
        width: 100%;
        height: 70px;
        line-height: 70px;
        background: #535864;
        color: #fff;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 12px;
        em{
            color: #fa0202;
        }
        .check{
            span{
                margin-left: 8px;
            }
            /deep/ .el-checkbox__inner::after{
                border-bottom:2px #000 solid;
                border-right:2px #000 solid;
            }
        }
        .sign{
            .el-button{
                margin-left: 20px;
                background: #ffd64e;
                border: none;
                width: 110px;
                height: 34px;
            }
        }
    }
    .contract-list{
        width: 800px;
        height: 286px;
        margin: 10px auto 10px;
        background: #eeeeee;
        overflow: auto;
        p{
            padding-left: 24px;
            height: 40px;
            line-height: 40px;
            border-bottom: 1px solid #fff;
        }
    }
    .line-top{
        width: 95%;
        height: 1px;
        background: #eee;
        position: absolute;
        top:65px;
    }
</style>




