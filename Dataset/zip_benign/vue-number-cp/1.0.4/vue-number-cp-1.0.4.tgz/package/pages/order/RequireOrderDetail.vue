<template>
  <div>
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :progress="'要货详情'" :is-border-bottom="true" :product-create-process="2"></SearchBar>
    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <div class="steps-cont">
        <Steps :isShowLine="true" :tenderList="requireStepFlow" :active="activeNode" :space="132"></Steps>
      </div>
      <div class="opinions-content" v-if="requireOperFlow.length">
        <div class="top">
          <div class="fl f14 bold">流转意见</div>
          <div class="fr blue hand f12" @click="foldFlag = !foldFlag">
            {{foldFlag ? '展开':'收起'}}
            <i v-if="foldFlag" class="el-icon-caret-bottom"></i>
            <i v-else class="el-icon-caret-top"></i>
          </div>
          <div style="clear: both;"></div>
        </div>
        <div class="middle-cont">
          <div class="middle" v-for="(item, idx) in computedList" :key="idx">
            <el-row>
              <el-col :span="4">
                <p>姓名</p>
                <span>{{item.operAcctName}}</span>
              </el-col>
              <el-col :span="4">
                <p>{{item.operType === '25' ? '验收单' : '要货单'}}{{item.operType !== '21' && item.operType !== '25'? '审核失败' : '撤回'}}</p>
                <span>{{item.operTime}}</span>
              </el-col>
              <el-col :span="16">
                <p>{{item.operType !== '21' && item.operType !== '25' ? '退回' : '撤回'}}原因：</p>
                <span v-html="item.operMsg && item.operMsg.replace(/\n/g, '<br/>')"></span>
              </el-col>
            </el-row>
          </div>
        </div>
        <div class="bottom">
          <span class="blue hand f12" @click="foldFlag = !foldFlag">
            {{foldFlag ? '展开':'收起'}}
            <i v-if="foldFlag" class="el-icon-caret-bottom"></i>
            <i v-else class="el-icon-caret-top"></i>
          </span>
        </div>
      </div>
      <div class="purchasing-container" v-for="(item, idx) in deliverGoods" :key="idx">
        <PurchasingProgressComponent @clickFlg="getClickFlg" :progress="item" @refurbish="getRequireOrderDetail"></PurchasingProgressComponent>
      </div>
      <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
      <RequireOrderInfo :showLogisticsInfo="!['01','02','03','04','05','06'].includes(orderInfo.requireStatus)" :showTotal="true" v-if="tabIndex === 0 && Object.keys(orderInfo).length" :orderInfo="orderInfo"></RequireOrderInfo>
      <RequireGoodsList :updateHeight="updateHeight" :goodsItem="{}" :showAddrInfo="true" v-if="tabIndex === 1" :orderInfo="orderInfo"></RequireGoodsList>
      <FixBottom v-if="signFlg && computedCurrentSign">
        <div class="tc">
          <el-button type="primary" style="width: 120px;" @click="handleSign">电子签章</el-button>
          <el-button v-if="orderInfo.requireCreator != userInfo.acctId" style="width: 120px;" @click="handleReject">退回</el-button>
          <el-button v-else style="width: 120px;" @click="handleReject">撤回</el-button>
        </div>
      </FixBottom>
      <RequireListOperate v-else :isFixBottom="true" :fromPage="'detail'" :tab="1" :order="orderInfo" @refresh="handleCloseSignature"></RequireListOperate>
    </div>
    <!--电子签章 -->

    <Signature ref="signature" :propCorpId="role=='B' ? orderInfo.purchaserId : ''" :propAcctId="role=='B' ? orderInfo.operAcctId : ''" :mainText="role=='B' ? orderInfo.purchaserName : ''" @close="handleCloseSignature"></Signature>

    <!-- 签收退货 -->
    <SignReturnGoods ref="signReturnGoods"></SignReturnGoods>

    <!-- 收货 -->
    <TakeGoodsConfirm ref="takeGoodsConfirm"></TakeGoodsConfirm>

    <!-- 退货 -->
    <ReturnGoods ref="returnGoods"></ReturnGoods>

    <!-- 发货通知 -->
    <SendOrderNotice ref="sendOrderNotice"></SendOrderNotice>
    <RejectDialog ref="RejectDialog" :rejectBtn="rejectBtn" :dialogTitle="dialogTitle" :rejectContent="rejectContent" @refuseReason="getRefuseReason"></RejectDialog>

    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import accountMixin from "@/mixins/account";
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import RequireOrderStatusInfo from "@/components/order/RequireOrderStatusInfo";
import RequireOrderInfo from "@/components/order/RequireOrderInfo";
import RequireGoodsList from "@/components/order/RequireGoodsList";
import SignReturnGoods from "@/components/order/dialog/SignReturnGoods";
import TakeGoodsConfirm from "@/components/order/dialog/TakeGoodsConfirm";
import ReturnGoods from "@/components/order/dialog/ReturnGoods";
import SendOrderNotice from "@/components/order/dialog/SendOrderNotice";
import SignProcessRequireDetail from "@/components/order/SignProcessRequireDetail";
import { InterfaceService } from "@/services/api";
import delayDate from "@/filters/delayDate";
import Breadcrumb from "@/components/base/Breadcrumb";
import Steps from "@/components/base/steps";
import DownloadAndView from '@/components/order/DownloadAndView'
import PanelTitle from "@/components/base/PanelTitle";
import FixBottom from "@/components/base/FixBottom";
import Signature from "@/components/order/dialog/Signature";
import { filterEventByAcct } from '@/utils/orderUtil';
import RejectDialog from "@/components/base/dialog/RejectDialog";
import PurchasingProgressComponent from '@/components/order/PurchasingProgressComponent'
import RequireListOperate from '@/components/order/RequireListOperate';

export default {
  mixins: [accountMixin],
  components: {
    Header,
    SearchBar,
    Loading,
    RequireOrderStatusInfo,
    RequireOrderInfo,
    SignReturnGoods,
    TakeGoodsConfirm,
    RejectDialog,
    Signature,
    ReturnGoods,
    SendOrderNotice,
    RequireGoodsList,
    PanelTitle,
    DownloadAndView,
    FixBottom,
    Steps,
    Breadcrumb,
    SignProcessRequireDetail,
    RequireListOperate,
    PurchasingProgressComponent
  },
  data() {
    return {
      isLoading: false,
      foldFlag: true,
      orderNo: "",
      requireNo: "",
      rejectBtn: "",
      dialogTitle: "",
      rejectContent: "",
      corpId: "",
      breadcrumb: [],
      activeNode: 0,
      tabIndex: 0,
      updateHeight: 0,
      tabs: [
        { label: "基本信息", listType: 0, active: true },
        { label: "要货清单", listType: 1 }
      ],
      requireStepFlow: [],
      requireOperFlow: [],
      expressCompanyList: [],
      orderInfo: {},
      pageIndex: 1,
      deliverGoods: []
    };
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo;
    },
    computedList() {
      return this.requireOperFlow.filter((item, idx) => {
        if (this.foldFlag) {
          return idx < 1
        } else {
          return true
        }
      })
    },
    computedCurrentSign() {
      let bool = false;
      let processList = [];
      let currentInfo = {};
      if (this.orderInfo && this.orderInfo.eventList && this.orderInfo.eventList.length) {
        this.orderInfo.eventList[0].processList.forEach(pro => {
          if (pro.role === '28') {
            pro.ind = 0
          } else if (pro.role === '21') {
            pro.ind = 1
          } else if (pro.role === '29') {
            pro.ind = 2
          } else if (pro.role === '30') {
            pro.ind = 3
          } else if (pro.role === '33') {
            pro.ind = 4
          }
          processList.push(pro)
        })
      }
      processList = processList.sort(this.compare)
      currentInfo = processList.find(pro => {
        return pro.processFlg == '0'
      });
      if (this.userInfo.acctIdList.includes(currentInfo.acctId)) {
        bool = true
      }
      return bool
    },
    signFlg() {
      return this.events.some(i => {
        return i.processList.some(_i => {
          return _i.processFlg == '0'
        })
      })
    },
    events() {
      const events = [];
      let acctIdList = [];
      if (this.userInfo.accountList.length) {
        this.userInfo.accountList.forEach(item => {
          acctIdList.push(item.acctId)
        });
      } else {
        acctIdList.push(this.userInfo.acctId)
      }
      const eventList = filterEventByAcct(this.orderInfo.eventList, 1, acctIdList);
      eventList.forEach(item => {
        if (
          item.eventType == 1 &&
          (item.eventStatus == 0 || item.eventStatus == 1)
        ) {
          events.push(item);
        }
      });
      console.log(events);
      return events
    }
  },
  methods: {
    getClickFlg() {
      this.updateHeight++
    },
    compare(obj1, obj2) {
      let val1 = obj1.ind;
      let val2 = obj2.ind;
      if (val1 < val2) {
        return -1;
      } else if (val1 > val2) {
        return 1;
      } else {
        return 0;
      }
    },
    // 合同签章完成
    handleCloseSignature(close) {
      if (close) {
        this.$router.push({
          path: '/resultsFeedback',
          query: {
            type: 'demandList',
            requireNo: this.requireNo
          }
        })
        window.opener && window.opener.location.reload();
      } else {
        this.getRequireOrderDetail();
      }
      window.opener && window.opener.location.reload()
    },
    getRefuseReason(refuseReason) {
      let operType = '';
      if (this.userInfo.bs == 'B') {
        // 退回
        if (this.orderInfo.requireCreator != this.userInfo.acctId) {
          operType = '23'
        } else {
          //撤回
          operType = '21'
        }
      } else {
        operType = '0'
      }
      let param = {
        requireNo: this.requireNo,
        operType: operType,
        reason: refuseReason,//商品名/型号
      };
      InterfaceService[this.userInfo.bs == 'B' ? 'cancelOrRejectRequire' : 'confirmOrRejectRequire'](param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success(operType === '21' ? '撤回成功！' : '退回成功！');
          this.getRequireOrderDetail();
          setTimeout(() => {
            if (operType !== '21') {
              window.opener = null;
              window.open('', '_self');
              window.close();
            }

          }, 500)
          window.opener && window.opener.location.reload()
        } else {
          this.$message.error(data.respData && data.respData.respMsg || '')
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    handleReject() {
      let str = '';
      if (this.orderInfo.requireCreator === this.userInfo.acctId) {
        str = '撤回'
      } else {
        str = '退回'
      }
      this.rejectContent = "请确认" + str + "该要货单，并填写" + str + "原因，点击【确认" + str + "】按钮。";
      this.dialogTitle = str + '原因';
      this.rejectBtn = '确认' + str;
      this.$refs.RejectDialog.open();
    },
    handleSign() {
      let events = this.events;
      this.$refs["signature"].open(events, '', '', this.orderInfo);
    },
    handleChangeTab(tab) {
      this.tabIndex = tab.listType;
    },
    getRequireOrderDetail(type) {
      // let sort = this.orderSortList.join("_");
      const params = {
        requireNo: this.requireNo,
        pageIndex: this.pageIndex,
        sort: [0, 0, 0]
      };
      InterfaceService.getRequireOrderDetail(
        params,
        data => {
          //console.log(data);
          if (data.respData.respCode === "0000") {
            if (!type) {
              if (window.opener) {
                window.opener.location.reload();
              }
            }

            this.orderInfo = data.respData || {};
            console.log(this.orderInfo, '-------');

            if (this.orderInfo.eventList && this.orderInfo.eventList.length) {
              this.deliverGoods = []
              this.orderInfo.eventList.forEach(ev => {
                if (ev.documentType == '01') {
                  let deliveritem = {
                    documentId: ev.documentId,
                    stretchFlag: ev.processList.every(i => { return i.processFlg === '1' }), // 伸缩flag
                    attachName: ev.documentName,
                    attachUrl: ev.attachUrl,
                    fileFrom: ev.fileFrom,
                    isShowOpr: ev.isShowOpr,
                    speedOfProgressList: []
                  },
                    arr1 = [],
                    arr2 = []
                  ev.processList.forEach(pro => {
                    if (pro.role[0] === '3') {
                      // purchaserList[0] = purchaserList.splice(1, 1, purchaserList[0])[0];
                      arr2.push(pro)
                      console.log(pro, '---pro');

                    } else if (pro.role[0] === '2') {
                      arr1.push(pro)
                    }
                  })
                  deliveritem.speedOfProgressList = [
                    { title: '项目公司', dataList: arr1 },
                    { title: '供应方', dataList: arr2 },
                  ]

                  this.deliverGoods.push(deliveritem)
                }

                if (ev.documentType == '02') {
                  let deliveritem = {
                    documentId: ev.documentId,
                    stretchFlag: ev.processList.every(i => { return i.processFlg === '1' }), // 伸缩flag
                    attachName: ev.documentName,
                    attachUrl: ev.attachUrl,
                    fileFrom: ev.fileFrom,
                    isShowOpr: ev.isShowOpr,
                    speedOfProgressList: []
                  },
                    arr1 = [],
                    arr2 = [],
                    arr3 = []
                  ev.processList.forEach(pro => {
                    if (pro.role[0] === '3') {
                      // purchaserList[0] = purchaserList.splice(1, 1, purchaserList[0])[0];
                      arr2.push(pro)
                    } else if (pro.role[0] === '2') {
                      arr1.push(pro)
                    } else if (pro.role[0] === '0') {
                      arr3.push(pro)
                    }
                  })
                  deliveritem.speedOfProgressList = [
                    { title: '项目公司', dataList: arr1 },
                    { title: '供应方', dataList: arr2 },
                    { title: '施工方', dataList: arr3 },
                  ]

                  this.deliverGoods.push(deliveritem)
                }

              })

              console.log(this.deliverGoods, 'deliverGoods');
            }

            // 流程节点
            this.requireStepFlow = [];
            if (data.respData.requireStepFlow) {
              data.respData.requireStepFlow.forEach(item => {
                if (item.flowName.indexOf('采购商') != -1 || item.flowName.indexOf('供应商') != -1) {
                  item.foot_title = item.flowName.substring(0, 3);
                  item.foot_info = item.flowName.substring(3, item.flowName.length);
                } else {
                  item.foot_title = item.flowName
                }
                this.requireStepFlow.push({
                  foot_title: item.foot_title,
                  foot_info: item.foot_info,
                  lightShow: item.isCurrentNode,
                  top_info: item.operTime && item.operTime.substring(0, 10) || "",
                  top_end_info: item.operTime && item.operTime.substring(11, item.operTime.length) || "",
                })
              })
            }
            this.requireStepFlow.forEach((item, index) => {
              if (item.lightShow == '1') {
                this.activeNode = index;
              }
            });
            if (this.requireStepFlow.every(i => { return !i.lightShow })) {
              this.activeNode = this.requireStepFlow.length
            }
            console.log(this.activeNode);
            console.log(this.requireStepFlow);
            this.requireOperFlow = [];
            if (data.respData.requireOperFlow) {
              this.requireOperFlow = [];
              if (data.respData.requireOperFlow) {
                data.respData.requireOperFlow.forEach(item => {
                  if (['23', '24', '21', '25'].includes(item.operType)) {
                    item.operMsg && this.requireOperFlow.unshift(item)
                  }
                  // if (item.operType === '23' || item.operType === '24' || item.operType === '21') {
                  //   this.requireOperFlow.unshift(item)
                  // }
                })
              }
              // 退回流程
              // this.getOrderRequireGoodsList()
            }
            console.log(this.requireOperFlow, '---requireOperFlow');

          } else {
            this.$message.error(data.respData && data.respData.respMsg || '');
          }
        }, data => {
          this.$message.error(data.respData && data.respData.respMsg || '')
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    init() {
      this.getRequireOrderDetail('init');
    }
  },
  mounted() {
    this.orderNo = this.$route.query.orderNo || ''
    this.requireNo = this.$route.query.requireNo || ''
    this.corpId = this.$route.query.corpId || ''
    this.breadcrumb = [
      {
        name: '管理中心',
        path: this.userInfo.bs == 'B' ? '/purchaserCenter/accountInfo' : '/vendorCenter/accountInfo'
      },
      {
        name: '交易管理-材料进场',
        path: this.userInfo.bs == 'B' ? '/purchaserCenter/requireOrderList' : '/vendorCenter/requireOrderList',
      },
      { name: '查看要货详情' },
    ];
    this.init()
  }
};
</script>
<style lang="scss" scoped>
.steps-cont {
  margin: 10px 0 30px;
  padding: 20px 0;
  /*border:1px solid #eee;*/
  box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
}
.opinions-content {
  padding: 10px;
  width: 1190px;

  background: #fffcf0;
  border: 1px solid #fae2a5;
  margin-bottom: 20px;
  .middle-cont {
    min-height: 78px;
    max-height: 400px;
    overflow-y: auto;
  }
  .top {
    height: 30px;
    border-bottom: 1px solid #eee;
  }
  .middle {
    font-size: 12px;
    padding: 10px 0;
    min-height: 71px;
    border-bottom: 1px solid #eee;
    div {
      p {
        margin-bottom: 10px;
        font-size: 14px;
      }
      span {
        color: #888;
        line-height: 17px;
        float: left;
        word-break: break-all;
        &:first-child {
          width: 17%;
        }
        &:last-of-type {
          width: 83%;
        }
      }
    }
  }
  .bottom {
    padding-top: 10px;
    height: 27px;
    text-align: center;
  }
}
.require-content {
  border: 1px solid #ddd;
  padding: 0 10px 10px;
  margin-bottom: 20px;
  &.fold {
    height: 50px;
    line-height: 50px;
  }
  .require-title {
    height: 50px;
    line-height: 50px;
    border-bottom: 1px solid #eee;
    margin-bottom: 20px;
    .stretch {
      margin-top: 18px;
    }
  }

  .stake-holder-content {
    /deep/ .el-col {
      div {
        background: #f5f5f5;
        padding: 20px 10px;
      }
    }
  }
}
.inner-container {
  margin-bottom: 70px;
}
</style>

