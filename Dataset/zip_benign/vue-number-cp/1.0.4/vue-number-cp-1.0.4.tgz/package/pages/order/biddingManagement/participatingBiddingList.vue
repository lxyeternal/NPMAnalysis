<template>
  <div class="project">
    <PanelTitle :title="'全部'"></PanelTitle>
    <div class="panel-content">
      <el-form class="form" :model="form" size="small" label-width="93px">
        <el-row>
          <el-col :span="8">
            <el-form-item label="招标名称：">
              <el-input v-model="form.bidName" placeholder="请输入关键词"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="投标状态：">
              <el-select clearable v-model="form.submitBidStatus" placeholder="">
                <el-option value="" label="全部"></el-option>
                <el-option v-for="(item,index) in submitBidStatusList" :label="item.value" :value="item.code" :key="index"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="招标模式：">
              <el-select clearable v-model="form.bidModel" placeholder="">
                <el-option value="" label="全部"></el-option>
                <el-option v-for="(item,index) in bidModelList" :label="item.value" :value="item.code" :key="index"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="发布方：">
              <el-select clearable v-model="form.corpId" placeholder="">
                <el-option value="" label="全部"></el-option>
                <el-option v-for="(item,index) in purchaserList" :label="item.corpName" :value="item.corpId" :key="index"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <el-row>
        <el-col :span="24" class="tc">
          <el-button style="width: 80px;" type="primary" size="small" @click="handleSearch">搜索</el-button>
          <el-button style="width: 80px;" size="small" @click="handleClear">清除</el-button>
        </el-col>
      </el-row>
    </div>
    <div class="project-table">
      <div class="bidding-content" v-for="item in bidInfoList">
        <div class="bidding-header">
          <div class="fl acct-info">
            <span><label>报名人：</label>{{item.submitAcctName}}</span>
            <span v-for="time in item.timeList"><label>{{time.split("：")[0]}}：</label>{{time.split("：")[1]}}</span>
          </div>
          <div class="fr">
            <span style="padding-right: 40px"><label>投标状态：</label><span :class="{'red' : item.submitBidStatus == 'AWARDED'}">{{item.submitBidStatusDisp}}</span></span>
            <span class="hand blue" @click="handleSignUp(item,'0')">查看详情</span>
          </div>
          <div style="clear: both"></div>
        </div>
        <div class="bidding-info">
          <div class="info-left fl">
            <div class="info-left-top">
              <!--<span class="fl" style="width: 122px;">{{item.corpName}}</span>-->
              <span style="width: 489px;"><i class="hand blue" :title="item.bidName" @click="handleOpen(item)">{{item.bidName}}</i></span>
              <span :title="item.ibBidCategoryInfos | categoryFilters">{{item.ibBidCategoryInfos | categoryFilters}}</span>
            </div>
            <div class="info-left-bottom">
              <span style="padding-right: 80px;float: left;line-height: 68px;"><label>招标模式：</label>{{item.bidModelName}}</span>
              <!-- <span style="width: 280px;height: 68px;padding-top: 25px;"><label>招标经办人：</label>
                <div v-for="acct in item.handleAcctNameList" style="display: inline-block;padding-right: 30px;line-height: 17px;">
                  {{acct.name}} -->
              <!--<el-popover popper-class="dark-popover" trigger="hover" placement="right">-->
              <!--<div style="color: #fff">-->
              <!--Tel:{{acct.mobile || "暂无手机号"}}-->
              <!--</div>-->
              <!--<i slot="reference" ></i>-->
              <!--</el-popover>-->
              <!-- </div>
               </span> -->
            </div>
          </div>
          <div class="info-center fl">
            <Steps :tenderList="item.tenderList" :active="item.activeNode" :type="'small'"></Steps>
          </div>
          <div class="info-right f12">
            <!-- <p v-if="item.submitBidStatus == 'WAIT_ENTER'"><span class="hand blue" @click="handleSignUp(item,'0')">继续报名</span></p> -->
            <p v-if="item.submitBidStatus == 'WAIT_ENTER' || (item.submitBidStatus == 'NO_INVITED' && item.originCode =='2')"><span class="hand blue" @click="handleSignUp(item,'0')">报名</span></p>
            <p v-else-if="item.bidPhase == 'SUPPLIER_RECRUIT'" class="hand blue"><span @click="handleSignUp(item,'0')">重新报名</span></p>
            <template v-if="item.nodePlan == 'BID_ISSUANCE'">
              <p><span class="hand blue" @click="handleDownload(item)">下载招标文件</span></p>
            </template>
            <template v-if="item.nodePlan == 'QUIZ'">
              <p><span class="hand blue" @click="handleDownload(item)">下载招标文件</span></p>
              <p><span class="hand blue" @click="handleSignUp(item,'1')">提问</span></p>
              <p><span class="hand blue" @click="handleSignUp(item,'2')">上传投标文件</span></p>
            </template>
            <template v-if="item.nodePlan == 'BID'">
              <p><span v-if="!item.hiddenDownloadFlg" class="hand blue" @click="handleDownload(item)">下载招标文件</span></p>
              <p><span v-if="!item.hiddenUploadFlg" class="hand blue" @click="handleSignUp(item,'2')">上传投标文件</span></p>
            </template>
            <template v-if="item.submitBidStatus == 'AWARDED'">
              <p><span class="hand blue" @click="handleSignUp(item,'4')">{{item.supplierSignStatus === '0' ? '签署中标文件' :　'查阅中标文件'}}</span></p>
            </template>
            <template v-if="item.submitBidStatus == 'AWARDED' || item.submitBidStatus == 'NO_AWARDED'">
              <p><span class="hand blue" @click="handleOpenWinningDetail(item)">查看中标公示</span></p>
              <p v-if="item.submitBidStatus == 'AWARDED'"><span class="hand blue" @click="viewBidLetter(item)">查看中标函</span></p>
              <p v-else><span class="hand blue" @click="viewBidLetter(item,false)">查看感谢函</span></p>
            </template>
            <p v-if="item.isIssueInquiry === '1' && item.hasIssueInquiry === '1' && item.bidPhase != 'CONFIRM_BID'"><span class="hand blue" @click="handleSignUp(item,'3','ANNOUNCED')">回复询标函</span></p>
            <p v-if="item.isIssueInquiry === '1' && (item.hasIssueInquiry !== '1' || (item.hasIssueInquiry === '1' && item.bidPhase === 'CONFIRM_BID'))"><span class="hand blue" @click="handleSignUp(item,'3','PUBLISH')">查看询标函</span></p>
          </div>
          <div style="clear:both;"></div>
        </div>
      </div>
    </div>
    <div class="table-pagination" v-if="bidInfoList.length">
      <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
      </el-pagination>
    </div>
    <!-- 空列表 -->
    <div class="accout-empty" v-if="!bidInfoList.length&&!isLoading">
      <img src="@/assets/images/icon-no-product.png">
      <p>没有相关参与的招标，请重新修改搜索条件搜索！</p>
    </div>
    <!-- 查看中标函或感谢函 -->
    <ViewBidLetter ref="viewBidLetter"></ViewBidLetter>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import Steps from "@/components/base/steps";
import { InterfaceService } from "@/services/api";
import ViewBidLetter from "@/components/tender/dialog/ViewBidLetter";

const form = {
  bidName: "",
  submitBidStatus: "",
  bidModel: "",
  corpId: "",
  corpName: "",
};
export default {
  name: "participatingBiddingList",
  mixins: [accountMixin],
  components: {
    Loading,
    PanelTitle,
    Steps,
    ViewBidLetter
  },
  filters: {
    categoryFilters(list) {
      if (list && list.length) {
        if (list.length == 1) {
          return list[0].categoryLevelTwoName
        } else {
          let a = []
          list.forEach(i => {
            a.push(i.categoryLevelThreeName)
          });
          a = [...new Set(a)]
          return a.join('、')
        }
      } else {
        return ''
      }
    }
  },
  data() {
    return {
      submitBidStatusList: [],
      bidModelList: [],
      purchaserList: [],
      bidInfoList: [],
      isLoading: false,
      pageIndex: 1,
      pageSize: 10,
      total: 0,
      form: Object.assign({}, form),
    }
  },
  methods: {
    handleOpen(item) {
      const { href } = this.$router.resolve({
        path: "/biddingAnnDetail",
        query: {
          bidNo: item.bidNo,
          operationType: false
        },
      });
      window.open(href, '_blank');
    },
    handleOpenWinningDetail(item) {
      window.open(this.$router.resolve({
        path: "/bidBulletinDetail",
        query: {
          bidNo: item.bidNo,
          enterBidNo: item.enterBidNo,
          type: '1',
        },
      }).href, '_blank')
    },
    viewBidLetter(item, isAwaroed) {
      let info = {
        supplierCorpName: this.$store.state.userInfo.corpName,
        ibBidCategoryInfos: item.ibBidCategoryInfos,
        year: item.bidStartYear + '~' + item.bidEndYear + '年度',
        publishTime: item.publishTime || '',
        corpId: item.corpId,
        remark: item.remark || ''
      }
      this.$refs.viewBidLetter.open(info, isAwaroed)
    },
    // 分页跳转
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.getSupplierBidList();
      window.scrollTo(0, 0)
    },
    handleDownload(item) {
      let fileInfoBeans = [];
      let list = [];
      if (item.bidAttachbeans && item.bidAttachbeans.length) {
        let skillsRequirement = [],
          technicalDeviation = [],
          biddingDocuments = [],
          biddingDocumentsSpecialty = [],
          quotationList = [],
          companyContacts = [],
          sampleList = [],
          othersList = [];
        item.bidAttachbeans.forEach(i => {
          if (i.attachType == '9') {
            skillsRequirement.push(i)
          } else if (i.attachType == '18') {
            technicalDeviation.push(i)
          } else if (i.attachType == '16') {
            biddingDocuments.push(i)
          } else if (i.attachType == '17') {
            biddingDocumentsSpecialty.push(i)
          } else if (i.attachType == '13') {
            quotationList.push(i)
          } else if (i.attachType == '14') {
            companyContacts.push(i)
          } else if (i.attachType == '15') {
            sampleList.push(i)
          } else if (i.attachType == '54') {
            othersList.push(i)
          }
        });
        // item.bidAttachbeans.forEach(i => {
        //   if (i.attachType == '9') {
        //     list[0] = i
        //   } else if (i.attachType == '18') {
        //     list[1] = i
        //   } else if (i.attachType == '16') {
        //     list[3] = i
        //   } else if (i.attachType == '17') {
        //     list[4] = i
        //   } else if (i.attachType == '19') {
        //     list[2] = i
        //   } else if (i.attachType == '20') {
        //     list[5] = i
        //   } else if (i.attachType == '21') {
        //     list[6] = i
        //   }
        // });
        // list.forEach((_item, index) => {
        //   if (index <= 1 && _item.attachUrl) {
        //     fileInfoBeans.push({
        //       archivePath: '技术标/' + (_item.attachName || ''),
        //       fileUrl: _item.attachUrl,
        //     })
        //   } else if (index > 1) {
        //     if (index == 3 && !_item.attachUrl && this.basicEdition.attachUrl) {
        //       fileInfoBeans.push({
        //         archivePath: '商务标/' + (this.basicEdition.attachName || ''),
        //         fileUrl: this.basicEdition.attachUrl,
        //       })
        //     } else if (index == 3 && !_item.attachUrl && this.professionalEdition.attachUrl) {
        //       fileInfoBeans.push({
        //         archivePath: '商务标/' + (this.professionalEdition.attachName || ''),
        //         fileUrl: this.professionalEdition.attachUrl,
        //       })
        //     } else {
        //       fileInfoBeans.push({
        //         archivePath: '商务标/' + (_item.attachName || ''),
        //         fileUrl: _item.attachUrl,
        //       })
        //     }
        //   }
        // })
        skillsRequirement.forEach(i => {
          fileInfoBeans.push({
            archivePath: '技术标/' + (i.attachName || ''),
            fileUrl: i.attachUrl,
          })
        })
        technicalDeviation.forEach(i => {
          fileInfoBeans.push({
            archivePath: '技术标/' + (i.attachName || ''),
            fileUrl: i.attachUrl,
          })
        })
        biddingDocuments.forEach(i => {
          fileInfoBeans.push({
            archivePath: '商务标/' + (i.attachName || ''),
            fileUrl: i.attachUrl,
          })
        })
        biddingDocumentsSpecialty.forEach(i => {
          fileInfoBeans.push({
            archivePath: '商务标/' + (i.attachName || ''),
            fileUrl: i.attachUrl,
          })
        })
        quotationList.forEach(i => {
          fileInfoBeans.push({
            archivePath: '商务标/' + (i.attachName || ''),
            fileUrl: i.attachUrl,
          })
        })
        companyContacts.forEach(i => {
          fileInfoBeans.push({
            archivePath: '商务标/' + (i.attachName || ''),
            fileUrl: i.attachUrl,
          })
        })
        sampleList.forEach(i => {
          fileInfoBeans.push({
            archivePath: '商务标/' + (i.attachName || ''),
            fileUrl: i.attachUrl,
          })
        })
        othersList.forEach(i => {
          fileInfoBeans.push({
            archivePath: '其他附件/' + (i.attachName || ''),
            fileUrl: i.attachUrl,
          })
        })
        if (fileInfoBeans.length == 0) {
          return this.$message.error("暂无招标文件可供下载")
        }
      }
      if (fileInfoBeans.length == 0) {
        return this.$message.error("暂无下载资质附件地址")
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            // const files = [
            //   { name: item.bidName + "招标文件.zip", url: url }
            // ];
            // this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
            //   this.$message.success("已下载");
            //   this.supplierDownloadRecord(item.submitBidNo)
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: item.bidName + "招标文件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
                this.supplierDownloadRecord(item.submitBidNo)
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })

    },
    //记录记录供应商下载招标文件
    supplierDownloadRecord(submitBidNo) {
      const params = {
        submitBidNo
      };
      InterfaceService.supplierDownloadRecord(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.getSupplierBidList()
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    handleSignUp(item, tab, publishStatus = '') {
      const { href } = this.$router.resolve({
        path: "/biddingSignUpInfo",
        query: {
          bidNo: item.bidNo,
          submitBidNo: item.submitBidNo,
          enterBidNo: item.enterBidNo,
          submitBidStatus: item.submitBidStatus,
          type: "continue",
          tab: tab,
          publishStatus: publishStatus,
        },
      });
      window.open(href, '_blank');
    },
    handleSearch() {
      this.getSupplierBidList()
    },
    handleClear() {
      this.form = Object.assign({}, form);
      this.pageIndex = 1;
      this.getSupplierBidList();
    },
    getSupplierBidList() {
      let params = Object.assign({}, this.form);
      params.pageIndex = this.pageIndex;
      InterfaceService.getSupplierBidList(
        params,
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.bidInfoList = data.respData.bidInfoList || [];
            this.bidInfoList.forEach(item => {
              //招标经办人
              item.handleAcctNameList = [];
              if (item.handlerList && item.handlerList.length) {
                item.handlerList.forEach(_item => {
                  item.handleAcctNameList.push({
                    name: _item.handleAcctName,
                    mobile: _item.handleAcctMobile,
                  })
                })
              }
              item.tenderList = []
              item.timeList = []
              if (item.nodePlanList) {
                item.nodePlanList.forEach(_item => {
                  //节点
                  item.tenderList.push({
                    foot_info: _item.nodePlanName,
                    nodePlan: _item.nodePlan,
                    lightShow: _item.lightShow,
                    hideFlg: _item.hideFlg,
                  });
                  //各种截止时间
                  if (_item.lightShow === "0") {
                    _item.submitBidListTimeOne && item.timeList.push(_item.submitBidListTimeOne);
                    _item.submitBidListTimeTwo && item.timeList.push(_item.submitBidListTimeTwo);
                    _item.submitBidListTimeThree && item.timeList.push(_item.submitBidListTimeThree)
                  }
                })
              }
              // 当前节点
              let finish = true
              item.tenderList.forEach((_item, _index) => {
                if (_item.lightShow === '0') {
                  finish = false;
                  item.activeNode = _index
                  item.nodePlan = _item.nodePlan
                }
              });
              if (finish) {
                item.activeNode = item.tenderList.length;
              }
              // 是否隐藏下载标书按钮:回标前一天隐藏
              item.hiddenDownloadFlg = false;
              item.hiddenUploadFlg = false;
              if (item.planList) {
                item.planList.forEach(plan => {
                  let now = new Date().getTime();
                  let oneDay = 24 * 60 * 60 * 1000;
                  if (plan.nodePlan === "BACK_BID" && plan.planEndTime) {
                    item.hiddenDownloadFlg = plan.planEndTime - now < oneDay;
                    item.hiddenUploadFlg = plan.planEndTime - now <= 0;
                  }
                });
              }
            });
            this.pageSize = data.respData.pageSize || 10;
            this.total = data.respData.totoalCount || 0;
          } else {
            this.$message.error(data.respData.respMsg)
          }
        },
        data => {

        },
        () => {
          this.isLoading = true
        },
        () => {
          this.isLoading = false
        })
    },
    getListConfig() {
      const params = {
        appName: 'PRODUCT',
        groupIds: ['SUBMIT_BID_STATUS', 'BID_MODEL'],
      }
      InterfaceService.getPaymentMethod(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          let res = data.respData.configEntityListMap || {};
          this.submitBidStatusList = res.SUBMIT_BID_STATUS || []
          this.bidModelList = res.BID_MODEL || []
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    getPurchaserList() {
      InterfaceService.getPurchaserList({}, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          console.log(data);
          this.purchaserList = data.respData.corpInfoList || []
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    }
  },
  mounted() {
    this.supplierCorpNames = this.$store.state.userInfo.corpName
    this.getSupplierBidList()
    this.getListConfig()
    this.getPurchaserList()
  }
}
</script>

<style scoped lang="scss">
.project {
  position: relative;
  font-size: 14px;
}
.panel-content {
  margin-bottom: 20px;
  padding: 20px 10px;
  background: #f5f5f5;
}
/deep/ .el-form-item__content,
.el-select {
  width: 240px;
}
.project-table {
  margin-top: 20px;
  .bidding-content {
    margin-bottom: 10px;
    border: 1px solid #eee;
    padding: 13px 10px;
    .bidding-header {
      height: 30px;
      font-size: 12px;
      border-bottom: 1px solid #eee;
      .acct-info {
        span {
          padding-right: 45px;
          &:last-child {
            padding-right: 0;
          }
        }
      }
      span {
        display: inline-block;
        color: #444;
      }
      label {
        color: #888;
      }
    }
    .bidding-info {
      margin-top: 12px;
      .info-left {
        padding-right: 30px;
        width: 525px;
      }
      .info-left-top {
        min-height: 40px;
        max-height: 80px;
        span {
          display: inline-block;
          overflow: hidden;
          // height: 100%;
          margin-bottom: 10px;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          &:last-child {
            margin-bottom: 0px;
          }
        }
      }
      .info-left-bottom {
        height: 58px;
        span {
          font-size: 12px;
          display: inline-block;
          position: relative;
          color: #444;
          i {
            position: absolute;
            top: -10px;
            right: -12px;
            width: 12px;
            height: 12px;
            background: url("../../../assets/images/icon/phone.png") no-repeat;
          }
        }
        label {
          color: #888;
        }
      }
      .info-center {
        width: 365px;
        padding: 23px 0;
        border-right: 1px solid #eee;
      }
      .info-right {
        height: 98px;
        width: 108px;
        text-align: right;
        display: table-cell;
        vertical-align: middle;
        p {
          margin-bottom: 10px;
        }
        &:last-child {
          margin-bottom: 0;
        }
      }
    }
  }
  /deep/ .el-form-item__label {
    padding-right: 8px;
  }
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
</style>