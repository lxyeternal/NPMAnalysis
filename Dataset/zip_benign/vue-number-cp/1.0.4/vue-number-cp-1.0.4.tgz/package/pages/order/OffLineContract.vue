<template>
    <div class="product">
        <PanelTitle :tabs="tabs"></PanelTitle>
        <!-- 查询条件 -->
        <div class="tip">该板块列表内容为线下签约的历史订单合同（系统导入）。</div>
        <div class="panel-content">
            <el-form class="form" :model="form" size="small" label-width="75px">
                <el-row>
                    <el-col :span="8">
                        <el-form-item label="合同名称">
                            <el-input v-model="form.contractName" placeholder="请输入合同名称"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <el-form-item label="采购商名" v-if="role=='S'">
                            <el-input v-model="form.purchaserName" placeholder="请输入采购商名"></el-input>
                        </el-form-item>
                        <el-form-item label="供应商名" v-if="role=='B'">
                            <el-input v-model="form.supplierName" placeholder="请输入供应商名"></el-input>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8" v-if="form.enterFrom==1&&groupCompanyCode=='GREENLANDHK'">
                        <el-form-item label="ERP编号">
                            <el-input v-model="form.externalCode" :maxlength="256" placeholder="请输入ERP编号"></el-input>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8">
                        <el-form-item label="创建时间">
                            <el-col :span="11" class="form-item">
                                <el-date-picker type="date" placeholder="请选择日期" value-format="yyyy-MM-dd" v-model="form.orderTmFrom" style="width: 100%;"></el-date-picker>
                            </el-col>
                            <el-col :span="2" class="tc">~</el-col>
                            <el-col :span="11" class="form-item">
                                <el-date-picker type="date" placeholder="请选择日期" value-format="yyyy-MM-dd" v-model="form.orderTmTo" style="width: 100%;"></el-date-picker>
                            </el-col>
                        </el-form-item>
                    </el-col>
                    <!-- </el-row>
                    <el-row> -->
                    <el-col :span="8">
                        <el-form-item label="合同编号">
                            <el-input v-model="form.orderNo" placeholder="请输入合同编号"></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8" v-if="form.enterFrom==1 && role=='S'">
                        <el-form-item label="价款类型">
                            <el-select v-model="form.priceType" placeholder="请选择价款类型" clearable>
                                <el-option v-for="(price,index) in priceList" :key="index" :label="price.label" :value="price.value"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>

                    <el-col :span="8" v-if="form.enterFrom==1">
                        <el-form-item label="状态">
                            <el-select v-model="form.status" placeholder="请选择状态" clearable @clear="handleSelectClear">
                                <el-option v-for="(item,index) in overStatusList" :key="index" :label="item.orderStatusDesc" :value="item.orderStatus"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="24" class="form-btns">
                        <el-button type="primary" size="small" @click="handleSearch">搜索</el-button>
                        <el-button size="small" @click="handleClear">清除</el-button>
                    </el-col>
                </el-row>
            </el-form>
        </div>
        <div class="product-table">
            <!-- 列表 -->
            <table>
                <thead>
                <tr>
                    <td width="30" v-if="role=='S'"></td>
                    <td>合同编号</td>
                    <td width="180">合同名称</td>
                    <td>
                        <span v-if="role=='S'">采购商</span>
                        <span v-if="role=='B'">供应商</span>
                    </td>
                    <!-- <td>下单人</td> -->
                    <td class="pointer" @click="handleSort(0)">合同时间
                        <i class="el-icon-d-caret" v-if="sortList[0]==0"></i>
                        <i class="el-icon-caret-top active" v-if="sortList[0]==1"></i>
                        <i class="el-icon-caret-bottom active" v-if="sortList[0]==2"></i>
                    </td>
                    <td class="pointer" @click="handleSort(2)">合同价款(税前)
                        <i class="el-icon-d-caret" v-if="sortList[2]==0"></i>
                        <i class="el-icon-caret-top active" v-if="sortList[2]==1"></i>
                        <i class="el-icon-caret-bottom active" v-if="sortList[2]==2"></i>
                    </td>
                    <td>状态</td>
                    <td>操作</td>
                </tr>
                </thead>

                <template v-if="productList.length">
                    <tbody>
                    <tr v-if="role=='S'" class="all-check">
                        <td>
                            <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow" :disabled="disableAllCheck"></el-checkbox>
                        </td>
                        <td colspan="8">全选&nbsp;
                            <el-button size="mini" :disabled="!hasChecked" @click="handleBatchOrderConfirm">批量确认合同</el-button>
                        </td>
                    </tr>
                    </tbody>
                    <tbody v-for="(product,index) in productList" :key="index" class="tc tbody-row">
                    <tr>
                        <td v-if="role=='S'">
                            <el-checkbox v-model="product.checked" @change="handleSelectTableRow(product,index)" :disabled="product.orderStatus!='01'"></el-checkbox>
                        </td>
                        <td class="nowrap">
                            <p>{{product.orderNo}}</p>
                            <ContractOperate :order="product" @refresh="handleRefresh"></ContractOperate>
                        </td>
                        <td>
                            <span v-if="product.contractName">《{{product.contractName}}》</span>
                        </td>
                        <td>
                            <span v-if="role=='S'">{{product.purchaserName}}</span>
                            <span v-if="role=='B'">{{product.supplierName}}</span>
                        </td>
                        <!-- <td>{{product.orderAcctName}}</td> -->
                        <td>{{product.orderTm | datetime}}</td>
                        <td>
                            <p class="nowrap" v-if="role=='S'">{{product.priceTypeDisp}}:</p>
                            <p>{{product.orderAmountTotal | formatMoney}}元</p>
                        </td>
                        <td :class="{'red':product.orderStatus=='14'}">
                            <p v-if="waitSignContract(product)">合同待签章</p>
                            <span v-if="role=='S'">{{product.sOrderStatusDisp}}</span>
                            <span v-if="role=='B'">{{product.bOrderStatusDisp}}</span>
                        </td>
                        <td class="tc">
                            <OrderListOperate :order="product" @refresh="handleRefresh"></OrderListOperate>
                        </td>
                    </tr>
                    <tr class="sign-content" v-if="product.orderStatus >= '03' && product.orderStatus < '11' && product.orderStatus != '02' && product.orderStatus != '04'">
                        <td colspan="100">
                            <SignProcessOrderList :order="product"></SignProcessOrderList>
                        </td>
                    </tr>
                    </tbody>
                </template>
            </table>
            <div class="table-pagination" v-if="productList.length">
                <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                </el-pagination>
            </div>

            <!-- 空列表 -->
            <div class="product-empty" v-if="!productList.length&&!isLoading">
                <img src="@/assets/images/icon-no-product.png">
                <p>没有搜索到相关合同，请重新修改搜索条件搜索！</p>
            </div>
        </div>
        <!-- 确认合同/批量确认合同 -->
        <OrderConfirm ref="orderConfirm" @close="handleCloseOrderConfirm"></OrderConfirm>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    import accountMixin from "@/mixins/account";
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import OrderListOperate from "@/components/order/OrderListOperate";
    import OrderConfirm from "@/components/order/dialog/orderOperate/OrderConfirm";
    import ContractOperate from "@/components/order/ContractOperate";
    import SignProcessOrderList from "@/components/order/SignProcessOrderList";

    import { InterfaceService } from "@/services/api";
    import { filterEventByAcct } from '@/utils/orderUtil';

    const params = {
        orderNo: "",
        orderAccName: "",
        contractName: "",
        orderStatus: [],
        status: "",
        purchaserName: "",
        supplierName: "",
        orderTmFrom: "",
        orderTmTo: "",
        // priceType: "D", // 字段删除
        sort: "2_0_0",
        pageIndex: 1,
        pageSize: 10,
        enterFrom: "0"
    };

    export default {
        mixins: [accountMixin],
        components: {
            Loading,
            PanelTitle,
            OrderListOperate,
            OrderConfirm,
            ContractOperate,
            SignProcessOrderList,
        },
        data() {
            return {
                tab: "1",
                tabs: [
                    { label: "线下合同", index: 1, active: true }
                ],
                form: Object.assign({}, params),
                allChecked: false,
                disableAllCheck: false,
                hasChecked: false,
                sortList: [2, 0, 0],
                priceList: [
                    { label: "全部", value: "" },
                    { label: "战略价(税前)", value: "A" },
                    { label: "市场价(税前)", value: "D" },
                    { label: "协议价(税前)", value: "Negotiated" }
                ],
                statusList: [],
                overStatusList: [],
                productList: [],
                total: 0,
                isLoading: false,
                storeParams: {},
            };
        },
        methods: {
            // 修改tab
            // handleChangeTab(tab) {
            //     this.tab = tab.index;
            //     this.recoverStatus(this.tab);
            //     this.getOrderList();
            // },
            // 清楚状态选择
            handleSelectClear() {
                this.recoverStatus(this.tab);
            },
            // 清除
            handleClear() {
                this.form = Object.assign({}, params);
                this.recoverStatus(this.tab);
            },
            // 搜索
            handleSearch() {
                if (this.form.status) {
                    this.form.orderStatus = [this.form.status];
                }

                if (this.form.externalCode) {
                    this.form.sysCode = 'ERP';
                } else {
                    delete this.form.sysCode;
                    delete this.form.externalCode;
                }
                this.getOrderList();
            },
            // 排序
            handleSort(index) {
                let arr = [].concat(this.sortList);
                this.sortList.forEach((item, i) => {
                    if (index == i) {
                        if (item == 0) {
                            arr[i] = 2;
                        } else if (item == 2) {
                            arr[i] = 1;
                        } else {
                            arr[i] = 0;
                        }
                    } else {
                        arr[i] = 0;
                    }
                });
                this.sortList = arr;
                this.getOrderList();
            },
            // 全选
            handleAllSelectTableRow(bool) {
                let arr = [];
                arr = [].concat(this.productList);
                arr.forEach(item => {
                    item.checked = bool;
                });
                this.productList = arr;
                this.checkBatch();
            },
            // 选中行
            handleSelectTableRow(product, index) {
                this.$set(this.productList, index, product);
                this.checkBatch();
                this.checkAllSelect();
            },
            // 刷新列表
            handleRefresh() {
                this.getOrderList();
            },
            // 批量确认合同弹窗
            handleBatchOrderConfirm() {
                const orders = [];
                this.productList.forEach(item => {
                    if (item.checked) {
                        orders.push(item);
                    }
                });
                this.$refs["orderConfirm"].open(orders, true);
            },
            // 批量确认合同完成
            handleCloseOrderConfirm(bool) {
                if (bool) {
                    this.getOrderList();
                }
            },
            // 分页跳转
            handleCurrentChange(page) {
                this.form.pageIndex = page;
                this.getOrderList();
                window.scrollTo(0,0)
            },
            // 是否全选
            checkAllSelect() {
                this.allChecked = this.productList.every(item => {
                    return item.checked;
                });
            },
            // 是否可批量
            checkBatch() {
                this.hasChecked = this.productList.some(item => {
                    return item.checked;
                });
            },
            // 恢复状态
            recoverStatus(tab) {
                // this.form.enterFrom = '1';
                // if (tab == 1) {
                //     this.form.status = "";
                //     this.form.orderStatus = [];
                // } else if (tab == 2) {
                //     this.form.status = "";
                //     this.form.orderStatus = ["01", "13"];
                // } else if (tab == 3) {
                //     this.form.status = "";
                //     this.form.orderStatus = ["03", "11"];
                // } else if (tab == 4) {
                //     this.form.status = "";
                //     this.form.orderStatus = ["02", "04", "12", "14"];
                // } else if (tab == 5) {
                //     this.form.status = "";
                //     this.form.orderStatus = [];
                //     this.form.enterFrom = '0'
                // }
                if (tab == 1) {
                    this.form.status = "";
                    this.form.orderStatus = [];
                    this.form.enterFrom = '0'
                }
            },
            // 待签署合同
            waitSignContract(order) {
                let allow = false;
                if (order.eventList) {
                    let acctIdList = [];
                    if (this.userinfo.accountList.length) {
                        this.userinfo.accountList.forEach(item=>{
                            acctIdList.push(item.acctId)
                        });
                    }else {
                        acctIdList.push(this.acctId)
                    }
                    const list = filterEventByAcct(order.eventList, 0, acctIdList);
                    list.forEach(item => {
                        if (
                            item.eventType == 0 &&
                            (item.eventStatus == 0 || item.eventStatus == 1)
                        ) {
                            if (item.processList) {
                                item.processList.forEach(process => {
                                    if (process.processFlg == 0) {
                                        allow = true;
                                    }
                                });
                            }
                        }
                    });
                }
                return allow;
            },
            init() {
                this.getOrderList();
            },
            getOrderList() {
                this.form.sort = this.sortList.join("_");
                this.recordFormData();

                const params = {};
                for (let i in this.form) {
                    if (this.form[i]) {
                        params[i] = this.form[i];
                    }
                }

                delete params.status;
                console.log(params);
                InterfaceService.getOrderList(
                    params,
                    data => {
                        //console.log(data);
                        if (data.respData.respCode === "0000") {
                            this.productList = data.respData.orders || [];
                            let disableAllCheck = true;
                            this.productList.forEach(item => {
                                item.checked = false;
                                if (item.orderStatus == "01") {
                                    disableAllCheck = false;
                                }
                            });
                            this.allChecked = false;
                            this.disableAllCheck = disableAllCheck;
                            this.hasChecked = false;
                            this.statusList = data.respData.orderStatusList || [];
                            this.overStatusList = this.arrangeStatusList(
                                this.statusList
                            );
                            this.total = data.respData.totalCount;
                            this.form.pageSize = data.respData.pageSize;
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            recordFormData() {
                let hasChange = false;
                Object.keys(this.storeParams).forEach(key => {
                    if (this.storeParams[key] != this.form[key]) {
                        hasChange = true;
                    }
                });

                if (hasChange) {
                    this.form.pageIndex = 1;
                }

                this.storeParams = this.$clone(this.form);
                delete this.storeParams.pageIndex;
                delete this.storeParams.pageSize;
                delete this.storeParams.orderStatus;
            },
            arrangeStatusList(list) {
                let tab = this.tab;
                let arr = [],
                    statusList = [];
                if (tab == 1 || tab == 5) {
                    arr = list;
                } else if (tab == 2) {
                    statusList = ["01", "13"];
                } else if (tab == 3) {
                    statusList = ["03", "11"];
                } else if (tab == 4) {
                    statusList = ["02", "04", "12", "14"];
                }

                if (!arr.length) {
                    list.forEach(item => {
                        if (statusList.indexOf(item.orderStatus) !== -1) {
                            arr.push(item);
                        }
                    });
                }

                return arr;
            },
        },
        mounted() {
            this.init();
        }
    };
</script>

<style lang="scss" scoped>
    .hand + .hand {
        margin-left: 10px;
    }
    .price-tip {
        cursor: pointer;
        color: #a9a9aa;

        &:hover {
            color: #0082ff;
        }
    }

    .product {
        font-size: 14px;
    }

    .pointer {
        cursor: pointer;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }

        .active {
            color: #ffd64e;
        }
    }

    .nowrap {
        white-space: nowrap;
    }

    .panel-content {
        margin-bottom: 20px;
        padding: 20px 10px;
        background: #f5f5f5;
    }

    .form {
        min-height: 135px;

        /deep/ .el-row {
            min-height: 50px;
        }

        /deep/ .el-select {
            width: 100%;
        }

        /deep/ .el-date-editor {
            input.el-input__inner {
                padding: 0 15px;
            }
            .el-input__prefix {
                display: none;
            }
        }

        &:after {
            display: table;
            content: "";
            clear: both;
        }
    }

    .form-item {
        position: relative;
        display: inline-block;
        line-height: 32px;

        .float-right {
            position: absolute;
            top: 2px;
            right: 1px;
            height: 30px;
            padding: 0 7px;
            line-height: 30px;
            background: #ffffff;
        }
    }

    .error-info {
        color: #f56c6c;
        font-size: 12px;
        line-height: 1;
        padding-top: 4px;
        position: absolute;
        top: 100%;
        left: 0;
    }

    .form-btns {
        text-align: center;
    }

    .product-table {
        /deep/ .el-table__body-wrapper {
            font-size: 12px;
        }

        /deep/ .el-table th,
        .el-table td {
            padding: 14px 0;
        }

        /deep/ .el-button {
            font-size: 12px;
        }

        table {
            width: 100%;
            line-height: 23px;
            font-size: 12px;
            td {
                padding: 14px 10px;
                vertical-align: middle;
                word-break: break-word;
            }

            thead {
                font-size: 14px;
                text-align: center;
                white-space: nowrap;
                color: #909399;
                background: #f5f5f5;
            }

            .tbody-row:hover {
                background: #e8f3fd;
            }

            tbody {
                text-align: center;

                tr {
                    &.sign-content {
                        display: none;
                        background: #f0f8ff;

                        &:hover {
                            display: table-row;
                        }

                        td {
                            padding: 0;
                            border-bottom: none;
                        }
                    }

                    &.all-check {
                        text-align: left;

                        &:hover{
                            background: #ffffff;
                        }
                    }
                }

                tr:hover + tr.sign-content {
                    display: table-row;
                }

                td {
                    border-bottom: 1px solid #ebeef5;
                }
            }
        }

        .product-name {
            display: inline-flex;
            width: 100%;
            vertical-align: top;
            line-height: 20px;

            img {
                width: 75px;
                height: 75px;
            }

            .left {
                margin-right: 10px;
            }

            .right {
                text-align: left;

                p:first-child {
                    margin-bottom: 10px;
                }
                p:last-child {
                    word-break: break-all;
                    max-height: 40px;
                    overflow: hidden;
                    color: #969799;
                }
            }
        }
    }

    .product-empty {
        padding: 150px;
        text-align: center;
        line-height: 50px;
        color: #909399;
    }

    .price-popover {
        display: flex;
        color: #ababac;

        > div:first-child {
            margin-right: 10px;
        }

        p:first-child {
            padding: 0 5px;
            border-left: 3px solid #ffd64e;
            line-height: 15px;
        }

        p:last-child {
            margin-top: 10px;
            color: #ffffff;
        }
    }

    .table-pagination {
        margin: 50px 0 80px;
        text-align: center;
        color: #888888;
    }
    .tip{
        height: 20px;
        line-height: 20px;
        margin: 16px 0;
        padding-left: 40px;
        background: url("../../assets/images/icon/tip.png") no-repeat 11px center;
    }
</style>




