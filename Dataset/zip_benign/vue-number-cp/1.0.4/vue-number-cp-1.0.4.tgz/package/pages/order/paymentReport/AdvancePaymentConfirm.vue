<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <SearchBar :search-type="5" :is-white-bg="true" :progress="'新增请款计划_预付款'" :is-border-bottom="true"></SearchBar>
        <div class="inner-container">
            <p class="title">
                第三步：请确认完请款材料后，确认新增请款计划。</p>
            <div>
                <ProcessPaymentInfo ref="processInfo" type="advance" :info="payment">
                    <div slot="form" class="form">
                        <el-form ref="form" :model="form" :rules="rules" label-width="120px" label-position="left" size="small">
                            <el-form-item label="本次应付金额" prop="payablesAmt">
                                <el-input v-model="form.payablesAmt" v-input-number="{precision:2}" placeholder="请输入本次应付金额">
                                    <span slot="append">元</span>
                                </el-input>
                            </el-form-item>
                        </el-form>
                        <p>温馨提示：点击【确认新增请款计划】，我们会为您生成请款报告。</p>
                    </div>
                </ProcessPaymentInfo>
            </div>
        </div>

        <div class="tc bottom">
            <el-button @click="handlePre">上一步</el-button>
            <el-button type="primary" @click="handleSubmit">确认新增请款计划</el-button>
        </div>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Header from "@/components/base/Header";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import ProcessPaymentInfo from "@/components/order/paymentReport/ProcessPaymentInfo";

import { InterfaceService } from "@/services/api";

const form = {
    payablesAmt: "",
    totalPayablesAmt:''
};

export default {
    mixins: [accountMixin],
    components: {
        Header,
        SearchBar,
        Loading,
        ProcessPaymentInfo
    },
    data() {
        const validateAmt = (rule, value, callback) => {
            if (Number(value) > Number(this.orderAmt)) {
                callback(new Error("金额不能超过合同金额"));
            } else {
                callback();
            }
        };
        return {
            isLoading: false,
            orderNo: "",
            orderAmt: "",
            bankAcctId: "",
            payment: {},
            form: Object.assign({}, form),
            rules: {
                payablesAmt: [
                    {
                        required: true,
                        message: "请输入本次应付金额",
                        trigger: "blur"
                    },
                    { validator: validateAmt, trigger: "blur" }
                ]
            }
        };
    },
    methods: {
        handlePre() {
            this.$router.go(-1);
        },
        handleSubmit() {
            this.$refs["form"].validate(valid => {
                if (valid) {
                    this.submitPayment();
                }
            });
        },
        submitPayment() {
            let params = {
                paymentType: "advance",
                orderNo: this.orderNo,
                bankAcctId: this.bankAcctId
            };
            params = Object.assign(params, this.form);
            params.totalPayablesAmt = params.payablesAmt
            InterfaceService.submitPaymentReort(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        // const paymentNo = data.respData.paymentNo;
                        const executionId = data.respData.executionId;
                        this.$router.push({
                            path: "/paymentReportSuccess",
                            query: {
                                executionId: executionId,
                                type: "advance"
                            }
                        });
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    },
    mounted() {
        this.orderNo = this.$route.query.orderNo;
        this.orderAmt = this.$route.query.orderAmt;
        this.bankAcctId = this.$route.query.bankAcctId;
    }
};
</script>

<style lang="scss" scoped>
.title {
    padding: 20px 0;
    margin: 20px 0;
    border-bottom: 1px solid #ececec;
}

.form {
    width: 500px;

    /deep/ .el-input__inner {
        border-right: none;
    }

    /deep/ .el-input-group__append {
        border-radius: 0;
        background: #ffffff;
    }

    /deep/ .el-input__inner:hover + .el-input-group__append {
        border-color: #c0c4cc;
    }

    /deep/ .el-input__inner:focus + .el-input-group__append {
        border-color: #ffd64e;
    }

    /deep/ .el-form-item.is-error {
        .el-input-group__append {
            border-color: #f56c6c;
        }
    }

    /deep/ .el-form-item.is-success {
        .el-input-group__append {
            border-color: #67c23a;
        }
    }
}

.bottom {
    margin: 40px auto 400px;
    /deep/ .el-button {
        width: 150px;
    }
}
</style>
