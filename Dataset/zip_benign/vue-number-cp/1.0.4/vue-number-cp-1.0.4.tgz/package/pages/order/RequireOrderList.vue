<template>
  <div class="product">
    <PanelTitle :tabs="tabs" @select="handleChangeTab"></PanelTitle>
    <!-- 查询条件 -->
    <div class="panel-content">
      <el-form class="form" :model="form" size="small" label-width="90px">
        <el-row>
          <el-col :span="24">
            <el-form-item label="合同名称：">
              <el-input v-model.trim="form.keyword" placeholder="请输入合同名称或合同编号"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="要货单号：">
              <el-input style="width: 240px;" v-model.trim="form.requireNo" placeholder="请输入要货单号"></el-input>
            </el-form-item>
          </el-col>
          <template v-if="userinfo.contractCorpType !== 'broker'">
            <el-col :span="8">
              <el-form-item label="采购商：" v-if="userinfo&&userinfo.bs=='S'">
                <el-input style="width: 240px;" v-model.trim="form.purchaserName" placeholder="请输入采购商"></el-input>
              </el-form-item>
              <el-form-item label="供应商：" v-if="userinfo&&userinfo.bs=='B'">
                <el-input style="width: 240px;" v-model.trim="form.supplierName" placeholder="请输入供应商"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="创建时间：">
                <el-col :span="11" class="form-item">
                  <el-date-picker style="width: 110px;" type="date" placeholder="选择时间" value-format="yyyy-MM-dd" :picker-options="pickerOptionsStart" v-model="form.tradeTimeFrom"></el-date-picker>
                </el-col>
                <el-col :span="2" class="tc">~</el-col>
                <el-col :span="11" class="form-item">
                  <el-date-picker style="width: 110px;" type="date" placeholder="选择时间" value-format="yyyy-MM-dd" :picker-options="pickerOptionsEnd" v-model="form.tradeTimeTo"></el-date-picker>
                </el-col>
              </el-form-item>
            </el-col>
          </template>
          <template v-if="role=='B'">
            <el-col :span="8">
              <el-form-item label="事业部：">
                <el-select filterable :disabled="!brokerRole" style="width: 240px;" @change="getBuyersList" v-model="form.groupCompanyCode" placeholder="请选择事业部" clearable>
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="(item,index) in groupCompanyList" :key="index" :label="item.value" :value="item.code"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="项目公司：" label-width="92px">
                <el-select filterable style="width: 240px;" :disabled="!form.groupCompanyCode" v-model="form.purchaserCorpId" placeholder="请选择项目公司" clearable>
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="(item,index) in projectList" :key="index" :label="item.corpName" :value="item.corpId"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </template>
        </el-row>
        <el-row>
          <el-col :span="8" v-if="userinfo.contractCorpType === 'broker'">
            <el-form-item label="供应商：" v-if="userinfo&&userinfo.bs=='B'">
              <el-input style="width: 240px;" v-model.trim="form.supplierName" placeholder="请输入供应商"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="状态：">
              <el-select style="width: 240px;" v-model="form.status" placeholder="请选择状态" clearable @clear="handleSelectClear">
                <el-option label="全部" value=""></el-option>
                <el-option v-for="(item,index) in computedStatusList" :key="index" :label="item.requireStatusDesc" :value="item.requireStatus"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8" v-if="userinfo.contractCorpType === 'broker'">
            <el-form-item label="创建时间：" label-width="92px">
              <el-col :span="11" class="form-item">
                <el-date-picker style="width: 110px;" type="date" placeholder="选择时间" value-format="yyyy-MM-dd" :picker-options="pickerOptionsStart" v-model="form.tradeTimeFrom"></el-date-picker>
              </el-col>
              <el-col :span="2" class="tc">~</el-col>
              <el-col :span="11" class="form-item">
                <el-date-picker style="width: 110px;" type="date" placeholder="选择时间" value-format="yyyy-MM-dd" :picker-options="pickerOptionsEnd" v-model="form.tradeTimeTo"></el-date-picker>
              </el-col>
            </el-form-item>
          </el-col>
        </el-row>
        <div :span="24" class="form-btns">
          <el-button type="primary" class="small-btn" @click="handleSearch">搜索</el-button>
          <el-button class="small-btn" @click="handleClear">清除</el-button>
        </div>
      </el-form>
    </div>
    <div class="product-table">

      <RequireOrderTable :tab='tab' style="margin-bottom: 50px;" :data="requireList" :show-pagination="true" :pageIndex="form.pageIndex" :pageSize="form.pageSize" :total="total" @currentChange="handleCurrentChange" @sortChange="handleSort" @refresh="handleRefresh"></RequireOrderTable>

      <!-- 空列表 -->
      <div class="product-empty" v-if="!requireList.length&&!isLoading">
        <img src="@/assets/images/icon-no-product.png">
        <p>没有搜索到相关要货，请重新修改搜索条件搜索！</p>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import RequireOrderTable from "@/components/order/RequireOrderTable";
import { InterfaceService } from "@/services/api";

const params = {
  orderNo: "",
  keyword: "",
  requireNo: "",
  requireStatus: [],
  status: '',
  purchaserName: "",
  supplierName: "",
  requireBatchNo: "",
  tradeTimeFrom: "",
  tradeTimeTo: "",
  model: "",
  groupCompanyCode: "",
  purchaserCorpId: "",
  sort: "0_2_0",
  pageIndex: 1,
  pageSize: 10,
};

const tabs = [
  { label: "待处理", index: 1, active: true, searchType: '0' },
  {
    label: "进行中",
    index: 2,
    searchType: '1'
  },
  { label: "已结束", index: 3, searchType: '2' }
];
const brokerTabs = [
  {
    label: "进行中",
    index: 2,
    searchType: '1',
    active: true,
  },
  { label: "已结束", index: 3, searchType: '2' }
];
const specialTabs = [
  { label: '待处理', index: 1, active: true, searchType: 0, },
  { label: '进行中', index: 2, searchType: 1, },
  { label: '已结束', index: 3, searchType: 2, },
];

export default {
  components: {
    Loading,
    PanelTitle,
    RequireOrderTable
  },
  mixins: [accountMixin],
  data() {
    return {
      tab: "1",
      searchType: '0',
      tabs: [],
      form: Object.assign({}, params),
      sortList: [0, 2, 0],
      statusList: [],
      requireList: [],
      groupCompanyList: [],
      projectList: [],
      total: 0,
      isLoading: false,
      storeParams: {},
      selectContractForGoodsDialog: false, // 选择要货合同 dialog
      supplierSelectedValue: '', // 供应商名称
      contractSelectedValue: '', // 合同名称
      selectedList: [],
      internalRefuseDialogOptions: [],
      contractSelectedObj: {}, // 合同名称 选中值
      pickerOptionsEnd: {
        disabledDate: time => {
          return time.getTime() <= new Date(this.form.tradeTimeFrom).getTime() - 86400000
        }
      },
      pickerOptionsStart: {
        disabledDate: time => {
          return this.form && this.form.tradeTimeTo && time.getTime() > new Date(this.form.tradeTimeTo).getTime()
        }
      },
    };
  },
  computed: {
    computedStatusList() {
      let list = [];
      this.statusList.forEach(i => {
        if (this.userinfo.contractCorpType === 'broker') {
          if (this.searchType == '1') {
            if (['19', '21', '01', '04', '07', '15', '16', '25', '02', '03', '05', '06', '24'].includes(i.requireStatus)) {
              list.push(i)
            }
          }
        } else {
          if (this.userinfo.bs === 'B') {
            if (this.searchType == '0') {
              if (['19', '21', '01', '04', '07', '15', '16', '25', '23', '24'].includes(i.requireStatus)) {
                list.push(i)
              }
            } else if (this.searchType == '1') {
              if (['02', '03', '05', '06', '16'].includes(i.requireStatus)) {
                list.push(i)
              }
            }
          } else {
            if (this.searchType == '0') {
              if (['02', '03', '05', '06', '16'].includes(i.requireStatus)) {
                list.push(i)
              }
            } else if (this.searchType == '1') {
              if (['04', '07', '15', '16', '24', '25'].includes(i.requireStatus)) {
                list.push(i)
              }
            }
          }
        }
        if (this.searchType == '2') {
          if (['22', '18'].includes(i.requireStatus)) {
            list.push(i)
          }
        }
      })
      return list
    },
    role() {
      return this.$store.state.userInfo ? this.$store.state.userInfo.bs : 0;
    },
    userinfo() {
      return this.$store.state.userInfo;
    },
    specialRole() {
      return this.$store.state.userInfo &&
        (this.$store.state.userInfo.contractCorpType == "construction" ||
          this.$store.state.userInfo.contractCorpType == "supervisory")
    }
  },

  methods: {
    // 我要货点击
    async handleAddGoodsClick() {
      !(this.selectedList && this.selectedList.length) && await this.remoteSearchOrder()

      this.supplierSelectedValue = ''
      this.contractSelectedObj = {}
      this.selectContractForGoodsDialog = true
    },

    // 供应商 select
    handleSupplierSelectedValueChange() {
      this.contractSelectedValue = ''
    },

    // 合同名称 select
    handleContractSelectedValueChange(ev) {
      this.contractSelectedObj = this.internalRefuseDialogOptions.filter(f => f.orderNo === ev)[0]
    },

    // 查询供应商
    remoteSearchOrder() {
      return new Promise(resolve => {
        InterfaceService.searchSimpleOrderListLimit({
          searchKey: '',
          usage: "requireGoods"
        }, data => {
          if (data.respData.respCode == '0000') {
            const dataList = data.respData.contractList || []

            this.selectedList = []
            dataList.forEach(f => {
              this.selectedList.push(f.supplierName)
            })
            this.selectedList = [...new Set(this.selectedList)]
            this.internalRefuseDialogOptions = this.$clone(dataList)
            resolve(data.respData.contractList || [])
          } else {
            this.$message.error(data.respData.respMsg);
          }
        }, data => {
        }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },

    // 修改tab
    handleChangeTab(tab) {
      this.tab = tab.index;
      this.searchType = tab.searchType;
      this.form.status = ''
      // this.recoverStatus(this.tab);
      this.form.pageIndex = 1;
      this.handleClear();
    },
    // 清除状态选择
    handleSelectClear() {
      this.form.requireStatus = [];
      // this.recoverStatus(this.tab);
    },
    // 清除
    handleClear() {
      const code = this.form.groupCompanyCode
      this.form = Object.assign({}, params)
      // 非材料公司 不清空 事业部
      if (!this.brokerRole) {
        this.form.groupCompanyCode = code
      }
      this.handleSearch()
    },
    // 搜索
    handleSearch() {
      if (this.form.status) {
        this.form.requireStatus = [this.form.status];
        this.form.pageIndex = 1;
      } else {
        this.form.requireStatus = [];
        // this.recoverStatus(this.tab);
      }
      if (this.tab > 2 && !this.specialRole) {
        // delete this.form.searchType;
      }

      this.getRequireList();

    },
    // 排序
    handleSort(arr) {
      this.sortList = arr;
      this.getRequireList();
    },
    // 分页跳转
    handleCurrentChange(page) {
      this.form.pageIndex = page;
      this.getRequireList();
      window.scrollTo(0, 0)
    },
    handleRefresh() {
      this.getRequireList();
    },
    getBuyersList() {
      this.form.purchaserCorpId = '';
      let param = {
        projectGroup: "REAL",
        // pageFrom	String	N	页面来源（CORP_MANAGEMENT:公司管理）
        groupCompanyCode: this.form.groupCompanyCode,
      };
      InterfaceService.getFkProjectList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.projectList = data.respData.projectList || [];
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    getBusinessDepartmentList() {
      return new Promise((resolve, reject) => {
        const params = {
          groupId: 'SYB_CONFIG'
        };
        InterfaceService.getBusinessDepartmentList(params, data => {
          let res = data.respData;
          if (res.respCode === "0000") {
            this.groupCompanyList = res.configList || [];
            this.projectList = [];
            resolve(this.groupCompanyList);
          } else {
            reject(data.respData.respMsg || [])
            this.$message.error(data.respData && data.respData.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })

    },
    async init() {
      this.form.orderNo = this.$route.query.orderNo;

      if (this.specialRole) {
        this.tabs = this.$clone(specialTabs);
      } else {
        if (this.userinfo.contractCorpType === "broker") {
          this.tabs = this.$clone(brokerTabs);
          // this.tab = '2'
          this.searchType = '1'
        } else {
          this.tabs = this.$clone(tabs);
        }
      }
      await this.getBusinessDepartmentList();
      // 非材料公司 只能查询 当前所在事业部
      if (!this.brokerRole) {
        this.form.groupCompanyCode = this.groupCompanyCode
        this.getBuyersList()
      }

      this.getRequireList()
    },
    getRequireList() {
      this.form.sort = this.sortList.join("_");
      this.recordFormData();

      const params = {};
      for (let i in this.form) {
        if (this.form[i]) {
          params[i] = this.form[i];
        }
      }
      params.searchType = this.searchType
      delete params.status;
      InterfaceService.getRequireOrderList(
        params,
        data => {
          console.log(data);
          if (data.respData.respCode === "0000") {
            let res = data.respData;
            this.requireList = res.requirements || [];
            this.requireList.forEach(i => {
              this.$set(i, 'foldFlag', true)
            });
            this.statusList = res.requireStatusList || [];
            this.total = data.respData.totalCount;
            this.form.pageSize = data.respData.pageSize;
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    recordFormData() {
      let hasChange = false;
      Object.keys(this.storeParams).forEach(key => {
        if (this.storeParams[key] != this.form[key]) {
          hasChange = true;
        }
      });

      if (hasChange) {
        this.form.pageIndex = 1;
      }

      this.storeParams = this.$clone(this.form);
      delete this.storeParams.pageIndex;
      delete this.storeParams.pageSize;
      delete this.storeParams.requireStatus;
    },
    // // 恢复状态
    // recoverStatus(index) {
    //   this.tabs.forEach(item => {
    //     if (item.index == index) {
    //       if (this.specialRole) {
    //         this.form.searchType = item.searchType;
    //       }
    //     }
    //   });
    // }
  },
  mounted() {
    this.init();
  }
};
</script>

<style lang="scss" scoped>
.refuse-to-add {
  li {
    font-size: 14px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 22px;
    span {
      &.title {
        color: #999;
        width: 13%;
        text-align: right;
      }
      &.disabled {
        border: 1px solid #ddd;
        background: #eaeaea;
        width: 86%;
        padding: 10px 12px;
      }
    }
    /deep/ input.el-select__input:focus {
      border: none !important;
    }
    /deep/ .el-select {
      width: 86%;
    }
    /deep/ .el-textarea {
      textarea {
        width: 86%;
        float: right;
      }
    }
  }
}
.price-tip {
  cursor: pointer;
  color: #a9a9aa;

  &:hover {
    color: #0082ff;
  }
}

.product {
  font-size: 14px;
  position: relative;
  .head-btn-container {
    position: absolute;
    top: 8px;
    right: 10px;
    /deep/ button {
      width: 120px;
    }
  }
}

.pointer {
  cursor: pointer;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }
}

.nowrap {
  white-space: nowrap;
}

.panel-content {
  margin-bottom: 20px;
  padding: 20px 10px;
  background: #f9f9f9;
}

.form {
  /deep/ .el-col {
    height: 52px;
  }

  /deep/ .el-select {
    width: 100%;
  }

  /deep/ .el-date-editor {
    input.el-input__inner {
      padding: 0 15px;
    }
    .el-input__prefix {
      display: none;
    }
  }

  &:after {
    display: table;
    content: "";
    clear: both;
  }
}

.form-item {
  position: relative;
  display: inline-block;
  line-height: 32px;

  .float-right {
    position: absolute;
    top: 2px;
    right: 1px;
    height: 30px;
    padding: 0 7px;
    line-height: 30px;
    background: #ffffff;
  }
}

.form-btns {
  text-align: center;
}

.product-table {
  table {
    width: 100%;
    line-height: 23px;
    td {
      padding: 14px 10px;
      vertical-align: middle;
    }

    thead {
      text-align: center;
      white-space: nowrap;
      color: #909399;
      background: #f9f9f9;
    }

    tbody {
      text-align: center;

      tr:first-child {
        text-align: left;
      }

      tr:first-child:hover {
        background: #ffffff;
      }

      tr:hover {
        background: #e8f3fd;
      }

      td {
        border-bottom: 1px solid #ebeef5;
      }
    }
  }
}

.product-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
</style>