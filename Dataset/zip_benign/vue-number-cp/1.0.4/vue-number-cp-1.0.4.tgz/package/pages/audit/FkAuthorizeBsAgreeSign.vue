<template>
  <div id="authorizeBsAgreeSign">
    <Header :is-white-bg="false"></Header>
    <SearchBar :search-type="5" :is-white-bg="true" :progress="'电子签章项目经理授权书'" :is-border-bottom="false"></SearchBar>
    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <PanelTitle :tabs='[{ label: "项目经理授权书", type: "externalReplenishAgreement" , active: true }]'></PanelTitle>

      <div class="tc iframe">
        <iframe v-show="attachUrl" :src="'https://view.officeapps.live.com/op/view.aspx?src=' + encodeURIComponent(attachUrl)" style="width:1190px; height:748px;margin-bottom: 60px;"></iframe>
        <!-- <PDFView :url="newProjectManager && newProjectManager.approveAttachList && ((newProjectManager.approveAttachList || []).find(i=> i.attachType === 'auth_word') || {}).attachUrl"></PDFView> -->
      </div>
    </div>

    <!-- 同意 -->
    <el-dialog class="dialog dialog-drafts" :title="'确认项目授权书内容并签章授权'" :append-to-body="true" :lock-scroll="true" :visible.sync="showAgreeDialog" width="840px" center :close-on-click-modal="false">
      <div class="drafts-list">
        <p class="tc">
          请仔细阅读本项目授权书内容，确认无误请点击【确认电子签章】后被授权人授权生效。
        </p>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="adminAuditCompanyInfo('approve')">确认电子签章</div>
        <div class="clearBtn" @click="showAgreeDialog=false">取消</div>
      </div>
    </el-dialog>

    <FixBottom>
      <div class="tc">
        <el-button type="primary" style="width: 120px;" @click="showAgreeDialog = true">电子签章</el-button>
        <el-button @click="handleCancel">取消</el-button>
      </div>
    </FixBottom>
    <Loading :is-loading="isLoading"></Loading>

  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import { viewFile } from '@/utils/orderUtil';
import SearchBar from "@/components/SearchBar";
import Breadcrumb from "@/components/base/Breadcrumb";
// import PDFView from "@/components/base/PDFView";
import FixBottom from "@/components/base/FixBottom";

export default {
  components: {
    Loading,
    PanelTitle,
    SearchBar,
    Breadcrumb,
    // PDFView,
    FixBottom,
  },
  props: ["baseInfo"],
  data() {
    return {
      isLoading: false,
      breadcrumb: [
        { name: '管理中心', path: '/purchaserCenter/accountInfo' },
        { name: '项目经理审核列表', path: '/purchaserCenter/fkAuthorizeBsList' },
        { name: '电子签章结算单' },
      ],
      showAgreeDialog: false,
      newProjectManager: {},
      originalProjectManager: {},
      approveDefId: '',
      list: {},
      approveLst: [],
      attachUrl:'',
    }
  },
  methods: {
    init() {
      this.getAdminCompanyInfo()
    },
    handleCancel() {
      // window.opener = null;
      // window.close();
      this.$router.go(-1)
    },
    // 管理员审核公司信息
    adminAuditCompanyInfo(approveType) {
      if (approveType == 'reject' && !this.check()) {
        return
      }
      let param = {
        approveId: this.$route.query.approveId || '',
        approveType: approveType,
        approveMsg: '',
        projectCorpId: this.$route.query.projectCorpId || '',
        approveAttachList: this.fileList
      }

      InterfaceService.adminAuditCompanyInfo(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.showAgreeDialog = false
          this.$message.success('审核成功, 1秒后返回详情!')
          setTimeout(() => {
            let fkAuthorizeBaseInfo = this.$route.query.fkAuthorizeBaseInfo || ''
            if(fkAuthorizeBaseInfo){
              fkAuthorizeBaseInfo = decodeURIComponent(fkAuthorizeBaseInfo)
              this.$setRootScope('fkAuthorizeBaseInfo', fkAuthorizeBaseInfo)
              this.$router.push('/purchaserCenter/fkAuthorizeBsList')
            }
          }, 1000)
          // if (window.opener) {
          //   window.opener && window.opener.location.reload();
          // }
          // setTimeout(() => {
          //   window.opener = null;
          //   window.close();
          // }, 1000)
        } else {
          this.$message.error(data.respData && data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },

    // 查询公司审批流水信息
    getAdminCompanyInfo() {
      let param = {
        approveId: this.$route.query.approveId || ''
      }
      InterfaceService.fkReviewProjectAdminConfirm(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.list = data.respData
          this.approveLst = data.respData.applyFlowList
          this.originalProjectManager = data.respData.originalProjectManager || {}
          this.newProjectManager = data.respData.newProjectManager || {}
          this.attachUrl = this.newProjectManager.approveAttachList && ((this.newProjectManager.approveAttachList || []).find(i=> i.attachType === 'auth_word') || {}).attachUrl
          this.fileList = this.newProjectManager.approveAttachList
          this.approveDefId = data.respData.approveDefId || ''
        } else {
          this.$message.error(data.respData && data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  },
  mounted() {
    console.log('init');
    this.init()
  }
}
</script>

<style lang="scss" scoped>
/deep/ .panel-title {
  margin-bottom: 0 !important;
}
#authorizeBsAgreeSign {
  .content {
    padding-bottom: 60px;
  }
  .vertical-title {
    color: #444;
    font-size: 14px;
    font-weight: bold;
    border-top: 1px solid #eeeeee;
    margin-top: 30px;
    display: flex;
    align-items: center;
    padding-top: 20px;
    i {
      width: 3px;
      background: #444444;
      margin-right: 4px;
      height: 14px;
    }
  }
}
.searchbox {
  text-align: center;
  margin-top: 20px;
  display: flex;
  justify-content: center;
  .searchBtn {
    width: 120px;
    height: 34px;
    line-height: 34px;
    background: linear-gradient(
      122deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(255, 255, 255, 1);
    margin-right: 20px;
    display: inline-block;
    cursor: pointer;
  }
  .clearBtn {
    width: 120px;
    height: 34px;
    line-height: 32px;
    border: 1px solid rgba(201, 159, 79, 1);
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(201, 159, 79, 1);
    display: inline-block;
    cursor: pointer;
  }
}
/deep/ .panel-title .tabs {
  color: #444444 !important;
  background: transparent !important;
  &::before {
    background-color: #444 !important;
  }
}
.iframe {
  margin: 30px 0px;
}
</style>