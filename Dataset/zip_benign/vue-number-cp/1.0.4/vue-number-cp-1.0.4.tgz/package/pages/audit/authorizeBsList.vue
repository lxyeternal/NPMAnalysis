<template>
  <div class="authorizeBsList">
    <PanelTitle :title="'管理员账户激活审核列表'"></PanelTitle>
    <div class="list-home">
      <div class="list-content">
        <div class="panel">
          <el-form size="small" label-width="100px">
            <el-form-item label="项目名称：">
              <el-input v-model.trim="projectName" placeholder="请输入项目名称" maxlength="64" @keyup.enter.native="search()" clearable></el-input>
            </el-form-item>
          </el-form>
          <div class="searchbox">
            <div class="searchBtn" @click="search()">搜索</div>
            <div class="clearBtn" @click="clear()">清除</div>
          </div>
        </div>
        <table>
          <thead>
            <tr>
              <td width="30%">公司名称</td>
              <td width="30%">项目名称</td>
              <td width="10%">姓名</td>
              <td width="15%">申请事由</td>
              <td width="10%">提交时间</td>
              <td width="5%">操作</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in approveLst" :key="ind" class="tbody-row">
            <tr>
              <td>
                {{item.corpName}}
              </td>
              <td>
                {{item.projectName}}
              </td>
              <td>
                {{item.name}}
              </td>
              <td>
                {{item.approveDefId | approveDefIdFilter}}
              </td>
              <td>
                <p class="time">{{item.applyTm}}</p>
              </td>
              <td class="operate" @click="handleOpen(item.approveId,item.corpId,item.approveDefId, item.projectId)">
                审核
              </td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!approveLst.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
        </div>
        <div class="table-pagination" v-if="approveLst.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
export default {
  components: {
    Loading, PanelTitle
  },
  data() {
    return {
      isLoading: false,

      bs: '', // （"S"：供应商；"B"：采购商）
      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码
      approveLst: [],
      projectName: '',// 公司名称
    };
  },
  filters: {
    approveDefIdFilter(item) {
      let status = ''
      switch (item) {
        case 'ADMIN_ACTIVATE_APPROVE':
          status = '管理员账户激活'
          break;
        case 'ADMIN_UPDATE_APPROVE':
          status = '管理员账户变更'
          break;
        default:
          break;
      }
      return status
    }
  },
   watch:{
    "$route":function(to,from){
      console.log(to, from);
      if (from.name != to.name) {
        this.init()
      }
    }
  },
  methods: {
    handleOpen(item,corpId,approveDefId,projectId) {
      let params = {
        projectName: this.projectName,
        pageIndex: String(this.pageIndex),
      };
      this.$router.push({
        path: this.bs == "B" ? "/purchaserCenter/authorizeBsListDetailsP" : "/purchaserCenter/authorizeBsListDetailsV",
        query: {
          approveId: item,
          corpId: corpId,
          approveDefId: approveDefId,
          params:JSON.stringify(params),
          projectId: projectId
        }
      });
    },
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.getAdminWaitCompanyList()
      window.scrollTo(0, 0)
    },
    // 管理授权列表
    getAdminWaitCompanyList() {
      let param = {
        projectName: this.projectName,
        bs: this.bs,
        pageIndex: String(this.pageIndex),
        pageSize: String(this.pageSize),
      }
      InterfaceService.getAdminWaitCompanyList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.approveLst = data.respData.contactList
          this.total = Number(data.respData.totalCount)
          if (this.pageIndex > Math.ceil(this.total / this.pageSize))  {
            this.pageIndex = Math.ceil(this.total / this.pageSize)
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    search() {
      this.projectName = this.projectName.trim()
      this.pageIndex = 1
      this.getAdminWaitCompanyList()
    },
    clear() {
      this.projectName = ''
      this.pageIndex = 1
      this.getAdminWaitCompanyList()
    },
    init() {
      let params = JSON.parse(this.$route.query.params || '{}');
      console.log(params);
      this.projectName = params.projectName || ''
      this.pageIndex = +params.pageIndex || 1
      this.bs = this.$route.name == 'authorizeBsListV' ? 'S' : 'B';
      this.getAdminWaitCompanyList()
    },
  },
  mounted() {
    this.init()
  },
};
</script>

<style lang="scss" scoped>
.authorizeBsList {
  padding-bottom: 60px;
  .list-content {
    .panel {
      background-color: #fff;
      background: rgba(249, 249, 249, 1);
      padding: 20px 10px;
      margin: 20px 0;
      .searchbox {
        text-align: center;
        margin-top: 20px;
        .searchBtn {
          width: 80px;
          height: 26px;
          line-height: 26px;
          background: linear-gradient(
            122deg,
            rgba(215, 176, 100, 1) 0%,
            rgba(236, 206, 139, 1) 100%
          );
          font-size: 12px;
          font-family: PingFang SC;
          color: rgba(255, 255, 255, 1);
          margin-right: 20px;
          display: inline-block;
          cursor: pointer;
        }
        .clearBtn {
          width: 80px;
          height: 26px;
          line-height: 24px;
          border: 1px solid rgba(201, 159, 79, 1);
          font-size: 12px;
          font-family: PingFang SC;
          color: rgba(201, 159, 79, 1);
          display: inline-block;
          cursor: pointer;
        }
      }
    }

    table {
      margin-top: 20px;
      table-layout: fixed;
      width: 100%;
      line-height: 23px;
      font-size: 12px;
      td {
        padding: 16px 10px;
        vertical-align: middle;
        word-break: break-all;
        &:last-child {
          text-align: right;
        }
      }

      thead {
        font-size: 14px;
        text-align: left;
        white-space: nowrap;
        border-bottom: 1px solid #eee;
        background: rgba(249, 249, 249, 1);
        color: rgba(136, 136, 136, 1);
        tr {
          td {
            padding: 13px 10px;
            &:last-child {
              text-align: right;
            }
          }
        }
      }
      .tbody-row {
        &:hover {
          background: #f0f8ff;
        }
      }
      tbody {
        text-align: left;
        tr {
          border-bottom: 1px solid #eee;
          line-height: 18px;
        }
        td {
          span:hover {
            color: #0082ff;
            cursor: pointer;
            text-decoration: underline;
          }
          .time{
            width: 70px;
          }
        }
        .operate {
          color: rgba(0, 130, 255, 1);
          cursor: pointer;
        }
        .border-none {
          border-bottom: none;
        }
      }
    }
  }
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
</style>
