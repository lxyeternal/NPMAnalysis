<template>
  <div id="pendingReviewDetails">
    <PanelTitle :title="'审核详情'"></PanelTitle>
    <div class="content">
      <UsersManage v-if="corpId && bs" :currentRole="bs" :companyCorpId="corpId" :breadcrumb="breadcrumb"></UsersManage>
      <!-- <div class="line"></div> -->
      <div class="list-content">
        <div class="order-info-title">审核流水信息</div>
        <table>
          <thead>
            <tr>
              <td width="6%">序号</td>
              <td width="16%">信息提交时间</td>
              <td width="15%">审核状态</td>
              <td width="15%">操作人</td>
              <td width="48%">审核意见</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in approveLst" :key="ind" class="tbody-row">
            <tr>
              <td>
                {{ind+1}}
              </td>
              <td>
                <p class="time">{{item.creTm | formatLongTime('yyyymmddhhiiss')}}</p>
              </td>
              <td>
                {{item.approveStatusDisp}}
              </td>
              <td>
                {{item.operator}}
              </td>
              <td>{{item.approveMsg}}</td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!approveLst.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>暂无审核流水信息！</p>
        </div>
        <div class="searchbox">
          <div class="searchBtn" @click="showAgreeDialog=true">同意</div>
          <div class="clearBtn" @click="showBackDialog=true">退回</div>
        </div>
      </div>
    </div>
    <!-- 同意 -->
    <el-dialog class="dialog dialog-drafts" :title="'会员入驻申请（同意）'" :append-to-body="true" :lock-scroll="true" :visible.sync="showAgreeDialog" width="840px" center :close-on-click-modal="false">
      <div class="drafts-list">
        <p class="tc">
          您确定要通过该公司的{{bs=='S'?'供应商':'采购商'}}会员入驻申请吗？
        </p>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="auditCompanyInfo('2')">确定</div>
        <div class="clearBtn" @click="showAgreeDialog=false">取消</div>
      </div>
    </el-dialog>
    <!-- 退回 -->
    <el-dialog class="dialog dialog-drafts" :title="'会员入驻申请（退回）'" :append-to-body="true" :lock-scroll="true" :visible.sync="showBackDialog" width="840px" center :close-on-click-modal="false" @close="$refs['ruleForm'].resetFields()">
      <div class="drafts-list">
        <el-form :model="form" :rules="rules" ref="ruleForm">
          <el-form-item prop="approveMsg">
            <el-input type="textarea" v-model="form.approveMsg" :rows="4" placeholder="请输入退回原因..." maxlength="200" show-word-limit />
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="auditCompanyInfo('3')">确定</div>
        <div class="clearBtn" @click="$refs['ruleForm'].resetFields();showBackDialog=false">取消</div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import UsersManage from "@/components/company/CompanyMessageInfo";
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";

export default {
  components: {
    UsersManage,
    Loading,
    PanelTitle,
  },
  data() {
    return {
      isLoading: false,
      showAgreeDialog: false,
      showBackDialog: false,
      bs: '',// 采购，供应

      corpId: '',
      approveLst: [],
      params: {},
      form: {
        approveMsg: '',// 意见反馈
      },
      rules: {
        approveMsg: [
          { required: true, message: '请输入退回原因', trigger: 'blur' }
        ]
      },
      breadcrumb: [],
    }
  },
  methods: {
    // 查询公司审批流水信息
    getCompanyInfo() {
      let param = {
        corpId: this.corpId
      }
      InterfaceService.getCompanyInfo(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.approveLst = data.respData.approveFlowList
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 审核公司信息
    auditCompanyInfo(approveStatus) {
      if (approveStatus == '3' && !this.check()) {
        return
      }
      let param = {
        corpId: this.corpId,
        approveCode: '01',
        approveStatus: approveStatus,
        approveMsg: this.form.approveMsg || '',
      }
      InterfaceService.auditCompanyInfo(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('操作成功')
          if (approveStatus == '3') {
            this.$refs['ruleForm'].resetFields()
          }
          this.showAgreeDialog = false
          this.showBackDialog = false
          this.$router.push({
            path: this.bs == 'B' ? '/purchaserCenter/pendingReviewListP' : '/purchaserCenter/pendingReviewListV' ,
            query:{
              pageIndex : this.listPageIndex || 1
            }
          })
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 校验
    check() {
      let check = false
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          return check = true;
        } else {
          return check = false;
        }
      });
      return check
    },
  },
  mounted() {
    this.corpId = this.$route.query.corpId || '';
    this.params = JSON.parse(this.$route.query.params || '{}')
    this.bs = this.$route.name == 'pendingReviewDetailsV' ? 'S' : 'B';
    this.breadcrumb = [
      { name: '账户管理中心', path: '/purchaserCenter/accountInfo',},
      { name: this.bs == 'B' ? '采购商入驻审核列表' : '供应商入驻审核列表',
        path: this.bs == "B" ? "/purchaserCenter/pendingReviewListP" : "/purchaserCenter/pendingReviewListV",
        queryName: 'params',query: JSON.stringify(this.params)},
      { name: '审核详情' },
    ];
    this.getCompanyInfo()
  }
}
</script>

<style lang="scss" scoped>
/deep/ .panel-title {
  margin-bottom: 0 !important;
}
#pendingReviewDetails {
  .content {
    /*width: 950px;*/
    margin: 0 auto;
    padding-bottom: 60px;
    .list-content {
      // width: 950px;
      width: 100%;
      margin: 0 auto;
      padding-bottom: 60px;

      table {
        margin-top: 20px;
        table-layout: fixed;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        td {
          padding: 16px 10px;
          vertical-align: middle;
          word-break: break-all;
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          border-bottom: 1px solid #eee;
          background: rgba(249, 249, 249, 1);
          color: rgba(136, 136, 136, 1);
          tr {
            td {
              padding: 13px 10px;
            }
          }
        }
        .tbody-row {
          &:hover {
            background: #f0f8ff;
          }
        }
        tbody {
          text-align: left;
          tr {
            border-bottom: 1px solid #eee;
            line-height: 18px;
          }
          td {
            span:hover {
              color: #0082ff;
              cursor: pointer;
              text-decoration: underline;
            }
            .time {
              width: 70px;
            }
          }
          .operate {
            color: rgba(0, 130, 255, 1);
            cursor: pointer;
          }
          .border-none {
            border-bottom: none;
          }
        }
      }
    }
  }
  .order-info-title {
    margin: 5px 0;
    margin-bottom: 20px;
    padding: 0 10px;
    font-size: 14px;
    border-left: 3px solid #000;
    line-height: 12px;
  }
}
.searchbox {
  text-align: center;
  margin-top: 20px;
  display: flex;
  justify-content: center;
  .searchBtn {
    width: 120px;
    height: 34px;
    line-height: 34px;
    background: linear-gradient(
      122deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(255, 255, 255, 1);
    margin-right: 20px;
    display: inline-block;
    cursor: pointer;
  }
  .clearBtn {
    width: 120px;
    height: 34px;
    line-height: 32px;
    border: 1px solid rgba(201, 159, 79, 1);
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(201, 159, 79, 1);
    display: inline-block;
    cursor: pointer;
  }
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
.line {
  margin: 20px 0;
  height: 1px;
  width: 100%;
  background: rgba(238, 238, 238, 1);
}

</style>