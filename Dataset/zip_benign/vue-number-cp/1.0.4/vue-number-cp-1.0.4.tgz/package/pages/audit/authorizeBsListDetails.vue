<template>
  <div id="authorizeBsListDetails">
    <PanelTitle :title="'审核详情'"></PanelTitle>
    <div class="content">
      <Breadcrumb :breadcrumbList="breadcrumb" @refresh="handleGoBack()" v-if="approveDefId !='ADMIN_UPDATE_APPROVE'"></Breadcrumb>
      <UsersManage v-if="corpId && bs && approveDefId=='ADMIN_UPDATE_APPROVE'" :currentRole="bs" :companyCorpId="corpId" :breadcrumb="breadcrumb" :path="'authorizeBsListDetails'"></UsersManage>
      <div class="order-info">
        <div class="order-info-title">管理员账户信息</div>
        <ul class="company-top">
          <li class="clearfloat">
            <div class="company-left">
              <span>公司名称：</span>
              <div class="company-showtext">{{list.corpName || "无"}}</div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>姓名：</span>
              <div class="company-showtext">{{list.name || "无"}}</div>
            </div>
            <div class="company-left">
              <div class="company-left" style="width: auto;height: 26px;">
                <span>授权书：</span>
                <div class="box">
                  <div class="annex" v-for="(item,ind) in list.approveAttachList" :key="ind">
                    <p class="company-showtext" :title="item.attachName">{{item.attachName}}</p> <i style="padding-left: 10px;" class="fr hand blue" @click="handleOpenAuthorization(item.attachUrl)">查看</i>
                  </div>
                </div>
              </div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>手机号：</span>
              <div class="company-showtext">{{list.mobile || "无"}}</div>
            </div>
            <div class="company-left">
              <span>邮箱：</span>
              <div class="company-showtext">{{list.email || "无"}}</div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>部门：</span>
              <div class="company-showtext">{{list.department || "无"}}</div>
            </div>
            <div class="company-left">
              <span>职位：</span>
              <div class="company-showtext">{{list.position || "无"}}</div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>身份证号：</span>
              <div class="company-showtext">{{list.certNo || "无"}}</div>
            </div>
          </li>
        </ul>
        <div class="line"></div>
      </div>
      <div class="list-content">
        <div class="order-info-title">审核流水信息</div>
        <table>
          <thead>
            <tr>
              <td width="6%">序号</td>
              <td width="16%">信息提交时间</td>
              <td width="15%">审核状态</td>
              <td width="15%">操作人</td>
              <td width="48%">审核意见</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in approveLst" :key="ind" class="tbody-row">
            <tr>
              <td>
                {{ind+1}}
              </td>
              <td>
                <p class="time">{{item.operTm | formatLongTime('yyyymmddhhiiss')}}</p>
              </td>
              <td>
                {{item.operType | operTypeFilter}}
              </td>
              <td>
                {{item.operAcctName}}
              </td>
              <td>{{item.approveMsg}}</td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!approveLst.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>暂无审核流水信息！</p>
        </div>
        <div class="searchbox">
          <div class="searchBtn" @click="showAgreeDialog=true">同意</div>
          <div class="clearBtn" @click="showBackDialog=true">退回</div>
        </div>
      </div>
    </div>
    <!-- 同意 -->
    <el-dialog class="dialog dialog-drafts" :title="'授权申请（同意）'" :append-to-body="true" :lock-scroll="true" :visible.sync="showAgreeDialog" width="840px" center :close-on-click-modal="false">
      <div class="drafts-list">
        <p class="tc">
          您确定要通过该管理员的授权申请吗？
        </p>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="adminAuditCompanyInfo('approve')">确定</div>
        <div class="clearBtn" @click="showAgreeDialog=false">取消</div>
      </div>
    </el-dialog>
    <!-- 退回 -->
    <el-dialog class="dialog dialog-drafts" :title="'授权申请（退回）'" :append-to-body="true" :lock-scroll="true" :visible.sync="showBackDialog" width="840px" center :close-on-click-modal="false" @close="$refs['ruleForm'].resetFields()">
      <div class="drafts-list">
        <el-form :model="form" :rules="rules" ref="ruleForm">
          <el-form-item prop="approveMsg">
            <el-input type="textarea" v-model="form.approveMsg" :rows="4" placeholder="请输入退回原因..." maxlength="200" show-word-limit />
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="adminAuditCompanyInfo('reject')">确定</div>
        <div class="clearBtn" @click="showBackDialog=false;$refs['ruleForm'].resetFields()">取消</div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import UsersManage from "@/components/company/CompanyMessageInfo";
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import { viewFile } from '@/utils/orderUtil';
import Breadcrumb from "@/components/base/Breadcrumb";
export default {
  components: {
    UsersManage,
    Loading, PanelTitle, Breadcrumb
  },
  data() {
    return {
      isLoading: false,

      bs: '', // （"S"：供应商；"B"：采购商）
      showAgreeDialog: false,
      showBackDialog: false,

      list: [],
      listPageIndex: 1,
      approveId: '',
      approveLst: [],
      form: {
        approveMsg: '',// 意见反馈
      },
      fileList: [],
      params: {},

      breadcrumb: [],
      corpId: "",
      approveDefId: "",
      rules: {
        approveMsg: [
          { required: true, message: '请输入退回原因', trigger: 'blur' }
        ]
      }
    }
  },
  filters: {
    operTypeFilter(item) {
      let status = ''
      switch (item) {
        case 'apply':
          status = '提交申请'
          break;
        case 'approve':
          status = '审核通过'
          break;
        case 'reject':
          status = '被拒绝'
          break;
        default:
          break;
      }
      return status
    }
  },
  methods: {
    handleGoBack() {
      this.$router.go(-1);
    },
    handleOpenAuthorization(authorizationUrl) {
      if (authorizationUrl) {
        viewFile(authorizationUrl)
      } else {
        this.$message.error("暂无预览地址")
      }
    },
    // 查询公司审批流水信息
    getAdminCompanyInfo() {
      let param = {
        approveId: this.approveId
      }
      InterfaceService.getAdminCompanyInfo(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.list = data.respData
          this.approveLst = data.respData.applyFlowList
          this.fileList = data.respData.approveAttachList
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 管理员审核公司信息
    adminAuditCompanyInfo(approveType) {
      this.form.approveMsg = this.form.approveMsg.replace(/(^\s*)|(\s*$)/g, "")
      if (approveType == 'reject' && !this.check()) {
        return
      }
      let param = {
        approveId: this.approveId,
        approveType: approveType,
        approveMsg: this.form.approveMsg || '',
        approveAttachList: this.fileList,
        projectCorpId: this.corpId || ''
      }
      InterfaceService.adminAuditCompanyInfo(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('操作成功')
          if (approveType == 'reject') {
            this.$refs['ruleForm'].resetFields()
          }
          this.showAgreeDialog = false
          this.showBackDialog = false
          this.$router.push({
            path: this.bs == "B" ? "/purchaserCenter/authorizeBsListP" : "/purchaserCenter/authorizeBsListV",
            query:{
              pageIndex : this.listPageIndex || 1
            }
          })
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 校验
    check() {
      let check = false
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          return check = true;
        } else {
          return check = false;
        }
      });
      return check
    },
  },
  mounted() {
    this.bs = this.$route.name == 'authorizeBsListDetailsV' ? 'S' : 'B';
    this.approveId = this.$route.query.approveId || ''
    this.corpId = this.$route.query.corpId || ""
    this.approveDefId = this.$route.query.approveDefId || ""
    this.params = JSON.parse(this.$route.query.params || '{}')
    this.breadcrumb = [
      { name: '账户管理中心', path: '/purchaserCenter/accountInfo' },
      { name: '管理员账户激活审核列表',
        path: this.bs == "B" ? "/purchaserCenter/authorizeBsListP" : "/purchaserCenter/authorizeBsListV",
        queryName: 'params',query: JSON.stringify(this.params)},
      { name: '审核详情' },
    ];
    this.getAdminCompanyInfo()
  }
}
</script>

<style lang="scss" scoped>
/deep/ .panel-title {
  margin-bottom: 0 !important;
}
#authorizeBsListDetails {
  .content {
    padding-bottom: 60px;
    .order-info {
      margin-top: 14px;
      .order-info-title {
        margin: 5px 0;
        margin-bottom: 20px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
      }
      .company-top li {
        line-height: 26px;
        &.changeInfo {
          height: 48px;
          line-height: 48px;
        }
        .company-left {
          display: inline-block;
          width: 49%;
          line-height: 26px;
          vertical-align: top;
          span {
            display: inline-block;
            height: 26px;
            line-height: 26px;
            text-align: right;
            color: #adadad;
            vertical-align: top;
            em {
              color: #e93340;
            }
          }
          .box {
            max-width: 400px;
            display: inline-block;
            .annex {
              width: 100%;
              .company-showtext {
                width: auto;
                max-width: 254px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
              }
            }
          }
          .one {
            width: 100%;
            .company-showtext {
              width: 900px;
            }
          }
        }
        .company-showtext {
          display: inline-block;
        }
      }
    }
    .list-content {
      table {
        margin-top: 20px;
        table-layout: fixed;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        td {
          padding: 16px 10px;
          vertical-align: middle;
          word-break: break-all;
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          border-bottom: 1px solid #eee;
          background: rgba(249, 249, 249, 1);
          color: rgba(136, 136, 136, 1);
          tr {
            td {
              padding: 13px 10px;
            }
          }
        }
        .tbody-row {
          &:hover {
            background: #f0f8ff;
          }
        }
        tbody {
          text-align: left;
          tr {
            border-bottom: 1px solid #eee;
            line-height: 18px;
          }
          td {
            span:hover {
              color: #0082ff;
              cursor: pointer;
              text-decoration: underline;
            }
            .time {
              width: 70px;
            }
          }
          .operate {
            color: rgba(0, 130, 255, 1);
            cursor: pointer;
          }
          .border-none {
            border-bottom: none;
          }
        }
      }
    }
  }
}
.searchbox {
  text-align: center;
  margin-top: 20px;
  display: flex;
  justify-content: center;
  .searchBtn {
    width: 120px;
    height: 34px;
    line-height: 34px;
    background: linear-gradient(
      122deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(255, 255, 255, 1);
    margin-right: 20px;
    display: inline-block;
    cursor: pointer;
  }
  .clearBtn {
    width: 120px;
    height: 34px;
    line-height: 32px;
    border: 1px solid rgba(201, 159, 79, 1);
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(201, 159, 79, 1);
    display: inline-block;
    cursor: pointer;
  }
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
.line {
  margin: 20px 0;
  height: 1px;
  width: 100%;
  background: rgba(238, 238, 238, 1);
}
</style>