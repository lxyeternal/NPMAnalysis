<template>
  <div class="pendingReviewList">
    <PanelTitle :title="bs=='S'?'供应商入驻审核列表':'采购商入驻审核列表'" ></PanelTitle>
    <div class="list-home">
      <div class="list-content">
        <div class="panel">
          <el-row>
            <el-col :span="bs == 'B' ? 24 : 8">
              <el-form size="small" label-width="100px">
                <el-form-item label="公司名称：">
                  <el-input v-model.trim="corpName" placeholder="请输入公司名称" maxlength="64" @keyup.enter.native="search()" clearable></el-input>
                </el-form-item>
              </el-form>
            </el-col>
            <el-col :span="8" v-if="bs == 'S'" >
              <el-form size="small" label-width="100px">
                <el-form-item label="品类：">
                  <el-input v-model.trim="categoryName" placeholder="请输入品类" maxlength="64" @keyup.enter.native="search()" clearable></el-input>
                </el-form-item>
              </el-form>
            </el-col>
          </el-row>

          <div class="searchbox">
            <div class="searchBtn" @click="search()">搜索</div>
            <div class="clearBtn" @click="clear()">清除</div>
          </div>
        </div>
        <table>
          <thead>
            <tr>
              <td width="45%">公司名称</td>
              <td width="30%" v-if="bs == 'S'">品类</td>
              <td :style="{width:bs == 'S' ? '85px' : '30%'}">提交时间</td>
              <td width="10%">操作</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in approveLst" :key="ind" class="tbody-row">
            <tr>
              <td>
                {{item.corpName}}
                <!-- <span @click="handleOpen(item)">{{item.corpName}}</span> -->
              </td>
              <td v-if="bs == 'S'" class="ellipsisOne" :title="item.corpCategorys">
                {{item.corpCategorys}}
              </td>
              <td>
                <p>{{item.submitTime}}</p>
              </td>
              <td class="operate" @click="handleOpen(item.corpId)">
                审核
              </td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!approveLst.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
        </div>
        <div class="table-pagination" v-if="approveLst.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
export default {
  components: {
    Loading,PanelTitle
  },
  data() {
    return {
      isLoading: false,

      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码
      approveLst: [],
      bs: '', // （"S"：供应商；"B"：采购商）
      corpName: '',// 公司名称
      categoryName: '',
    };
  },
  watch:{
    "$route":function(to,from){
      console.log(to, from);
      if (from.name != to.name) {
        this.init()
      }
    }
  },
  methods: {
    handleOpen(item) {
      let params = {
        corpName: this.corpName,
        categoryName: this.categoryName,
        groupCompanyCode: this.groupCompanyCode,
        pageIndex: this.pageIndex,
      };
      //   this.$setRootScope('biddingInfo', JSON.stringify(item));
      // window.open(this.$router.resolve({
      //   path: "/pendingReviewDetails",
      //   query: {
      //     corpId: item
      //   }
      // }).href, '_blank')
      this.$router.push({
        path: this.bs == "B" ? "/purchaserCenter/pendingReviewDetailsP" : "/purchaserCenter/pendingReviewDetailsV",
        query: {
          corpId: item,
          params: JSON.stringify(params),
        }
      });
    },
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.getWaitCompanyList()
      window.scrollTo(0, 0)
    },
    getWaitCompanyList() {
      let param = {
        bs: this.bs,
        corpName: this.corpName,
        categoryName: this.categoryName,
        pageIndex: String(this.pageIndex),
      };
      InterfaceService.getWaitCompanyList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.approveLst = data.respData.list;
          this.total = Number(data.respData.totalCount)
          if (this.pageIndex > Math.ceil(this.total / this.pageSize))  {
            this.pageIndex = Math.ceil(this.total / this.pageSize)
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    search() {
      this.corpName = this.corpName.trim()
      this.pageIndex = 1
      this.getWaitCompanyList()
    },
    clear() {
      this.corpName = '';
      this.categoryName = '';
      this.pageIndex = 1;
      this.getWaitCompanyList()
    },
    init() {
      let params = JSON.parse(this.$route.query.params || '{}');
      this.corpName = params.corpName || ''
      this.categoryName = params.categoryName || ''
      this.pageIndex = +params.pageIndex || 1
      this.bs = this.$route.name == 'pendingReviewListV' ? 'S' : 'B';
      this.getWaitCompanyList()
    },
  },
  mounted() {
    this.init()
  },
  destroyed() {
  }
};
</script>

<style lang="scss" scoped>
.pendingReviewList {
  /*width: 950px;*/
  margin: 0 auto;
  padding-bottom: 60px;
  .list-content {
    .panel {
      background-color: #fff;
      background: rgba(249, 249, 249, 1);
      padding: 20px 10px;
      margin: 20px 0;
      .searchbox {
        text-align: center;
        margin-top: 20px;
        .searchBtn {
          width: 80px;
          height: 26px;
          line-height: 26px;
          background: linear-gradient(
            122deg,
            rgba(215, 176, 100, 1) 0%,
            rgba(236, 206, 139, 1) 100%
          );
          font-size: 12px;
          font-family: PingFang SC;
          color: rgba(255, 255, 255, 1);
          margin-right: 20px;
          display: inline-block;
          cursor: pointer;
        }
        .clearBtn {
          width: 80px;
          height: 26px;
          line-height: 24px;
          border: 1px solid rgba(201, 159, 79, 1);
          font-size: 12px;
          font-family: PingFang SC;
          color: rgba(201, 159, 79, 1);
          display: inline-block;
          cursor: pointer;
        }
      }
    }

    table {
      margin-top: 20px;
      table-layout: fixed;
      width: 100%;
      line-height: 23px;
      font-size: 12px;
      td {
        padding: 16px 10px;
        vertical-align: middle;
        word-break: break-all;
        &:last-child {
          text-align: right;
        }
      }

      thead {
        font-size: 14px;
        text-align: left;
        white-space: nowrap;
        border-bottom: 1px solid #eee;
        background: rgba(249, 249, 249, 1);
        color: rgba(136, 136, 136, 1);
        tr {
          td {
            padding: 13px 10px;
            &:last-child {
              text-align: right;
            }
          }
        }
      }
      .tbody-row {
        &:hover {
          background: #f0f8ff;
        }
      }
      tbody {
        text-align: left;
        tr {
          border-bottom: 1px solid #eee;
          line-height: 18px;
        }
        td {
          span:hover {
            color: #0082ff;
            cursor: pointer;
            text-decoration: underline;
          }
          .time{
            width: 70px;
          }
        }
        .operate {
          color: rgba(0, 130, 255, 1);
          cursor: pointer;
        }
        .border-none {
          border-bottom: none;
        }
      }
    }
  }
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
</style>
