<template>
  <div class="account-info-wrap">
    <Header :is-white-bg="isWhiteBg" :removeSysNoticeFlg="removeSysNoticeFlg" showType='bigIn' :isHome="true"></Header>
    <div class="pageTop">
      <div class="logo fl">
        <img src="@/assets/images/logo_s.png">
        <div class="company-info">
          <p>大基建-管理中心</p>
        </div>
        <div class="company-info f16" style="padding-left: 85px;">
          <p class="hand tab-btn-bg" @click="goIndex">大基建首页</p>
        </div>
        <!-- <div class="company-info f16" style="padding-left: 60px;">
          <p class="hand" @click="goConfluence">知识库</p>
        </div> -->
        <div class="company-info fr">
          <p class="hl22" style="margin-top: 10px;">{{userinfo.corpName}}</p>
          <p class="hl22"> {{userinfo.acctName}}</p>
        </div>
      </div>
    </div>
    <div class="account-info-inner" id="account-info-inner">
      <div class="contain inner-container">
        <div class="menu">
          <el-menu :default-active="$route.path" router @open="handleOpen" @close="handleClose" background-color="rgba(49,49,49,1)" text-color="#fff" active-text-color="rgb(250,226,165)" style="padding-bottom:140px;" :unique-opened="true">
            <!-- <el-submenu index="4" v-if="mixinsRoleIds && mixinsRoleIds.some(s=> s.roleId == '2001')"> -->
            <el-submenu index="4" v-if="isShowBigConstruct === 'ON'">
              <template slot="title">
                <i class="icon-order"></i>
                <span>招标管理</span>
              </template>
              <el-menu-item-group>
                <el-menu-item index="/tenderManagement">
                  招标列表
                  <i class="el-icon-arrow-right"></i>
                </el-menu-item>
              </el-menu-item-group>
            </el-submenu>

            <el-submenu index="1">
              <template slot="title">
                <i class="icon-order"></i>
                <span>公司管理</span>
              </template>
              <el-menu-item-group>
                <el-menu-item index="/bigInfrastructureCenter/ProjectManage">
                  工程管理
                  <i class="el-icon-arrow-right"></i>
                </el-menu-item>
                <el-submenu index="1-2">
                  <template slot="title">
                    <span>权限管理</span>
                  </template>
                  <el-menu-item-group>
                    <el-menu-item index="/bigInfrastructureCenter/bigAccountInfo">
                      个人资料及密码设置
                      <i class="el-icon-arrow-right"></i>
                    </el-menu-item>
                    <el-menu-item index="/bigInfrastructureCenter/roleList">
                      角色列表
                      <i class="el-icon-arrow-right"></i>
                    </el-menu-item>
                    <el-menu-item index="/bigInfrastructureCenter/accountList">
                      用户列表
                      <i class="el-icon-arrow-right"></i>
                    </el-menu-item>
                  </el-menu-item-group>
                </el-submenu>
              </el-menu-item-group>
            </el-submenu>

            <el-submenu index="2">
              <template slot="title">
                <i class="icon-order"></i>
                <span>供应商管理</span>
              </template>
              <el-menu-item-group>
                <el-menu-item index="/bigInfrastructureCenter/supplierDirectory">
                  供应商名录
                  <i class="el-icon-arrow-right"></i>
                </el-menu-item>
              </el-menu-item-group>
            </el-submenu>

            <el-submenu index="3">
              <template slot="title">
                <i class="icon-order"></i>
                <span>合约管理</span>
              </template>
              <el-menu-item-group>
                <el-menu-item index="/bigInfrastructureCenter/ContractList">
                  合同管理
                  <i class="el-icon-arrow-right"></i>
                </el-menu-item>
                <el-menu-item index="/bigInfrastructureCenter/workbench">
                  交易数据分析
                  <i class="el-icon-arrow-right"></i>
                </el-menu-item>
              </el-menu-item-group>
            </el-submenu>
          </el-menu>
        </div>

        <div class="rightList">
          <router-view></router-view>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { mapActions, mapState } from "vuex";
import Header from "@/components/base/Header";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import accountMixin from "@/mixins/account";

export default {
  mixins: [accountMixin],
  components: {
    Header,
    Loading
  },
  data() {
    return {
      isWhiteBg: true,
      errorText: "",
      loginWrapInner: 100,
      isLoading: false,
      isShowDialog: false,
      showInvoice: false,
      removeSysNoticeFlg: 0,
      contractCorpType: "",
      isShowBigConstruct: '',
    };
  },
  computed: {
    userinfo() {
      return this.$store.state.userInfo;
    },
    specialRole() {
      return this.$store.state.userInfo &&
        (this.$store.state.userInfo.contractCorpType == "construction" ||
          this.$store.state.userInfo.contractCorpType == "supervisory")
    },
    // 返回当前用户 持有的 权限
    mixinsRoleIds() {
      return this.roleListFilter(this.mxCorpId) || []
    },
  },
  methods: {
    goIndex() {
      window.open(this.$router.resolve({
        path: '/bigfrastructIndex',
      }).href, '_blank')
    },
    async goConfluence() {
      this.isLoading = true
      try {
        await this.toConfluence(this.id || '1')
      } catch (error) {
        console.log(error, 'ee---');
        this.$message.error('系统繁忙, 请稍后重试')
      }
      this.isLoading = false
    },
    handleOpen(key, keyPath) {

    },
    handleClose(key, keyPath) {
      // console.log(key, keyPath);
    },
    getPaymentMethod() {
      return new Promise(resolve => {
        const params = {
          appName: 'TRANS',
          groupIds: ['VIEW_SHOW'],
        }
        InterfaceService.getPaymentMethod(params, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let res = data.respData.configEntityListMap && data.respData.configEntityListMap.VIEW_SHOW && data.respData.configEntityListMap.VIEW_SHOW.find(i=> i.code === 'CAPITAL_CONSTRUCTION_BILL') || {};
            this.isShowBigConstruct = res.value
            resolve(true)
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
          }
        }, data => { }, () => { this.isLoading = true; }, () => { this.isLoading = false; })
      })
    },
    init() {
      this.contractCorpType = this.$store.state.userInfo.contractCorpType;
      this.roleIds.forEach(role => {
        if (role.roleId == "2000") {
          this.showInvoice = true
        }
      });
      let list = JSON.parse(this.$getRootScope("showMenuList"))
      console.log(list, '--菜单');
      this.getPaymentMethod()
    },
    ...mapActions(['setUserInfoAction']),
  },
  watch: {
    "$route": function (to, from) {
      console.log(to, from);
      if (from.name == 'sysNoticeV') {
        this.removeSysNoticeFlg++
      }
    }
  },
  mounted() {
    this.init()
  }
};
</script>

<style lang="scss" scoped>
.el-menu-item i,
.el-submenu__title i {
  color: #ffffff;
}
.el-submenu__title {
  &:hover {
    .icon-goods {
      background: url("../../assets/images/icon/goods_active.png") no-repeat;
      background-size: 100%;
    }
    .icon-freight {
      background: url("../../assets/images/icon/freight_active.png") no-repeat;
      background-size: 100%;
    }
    .icon-tendering {
      background: url(../../assets/images/icon/tendering_active.png) no-repeat;
      background-size: 100%;
    }
    .icon-account {
      background: url("../../assets/images/icon/account_acitve.png") no-repeat;
      background-size: 100%;
    }
    .icon-order {
      background: url("../../assets/images/icon/order_active.png") no-repeat;
      background-size: 100%;
    }
    .icon-payment {
      background: url("../../assets/images/icon/payment_active.png") no-repeat;
      background-size: 100%;
    }
    .icon-company {
      background: url("../../assets/images/icon/company_active.png") no-repeat;
      background-size: 100%;
    }
    .icon-seal {
      background: url("../../assets/images/icon/seal_active.png") no-repeat;
      background-size: 100%;
    }
    .icon-menu {
      background: url("../../assets/images/icon/menu_active.png") no-repeat;
      background-size: 100%;
    }
    .icon-wx {
      background: url("../../assets/images/icon/wx_active.png") no-repeat;
      background-size: 100%;
    }
    .icon-tool {
      background: url("../../assets/images/icon/tool_active.png") no-repeat;
      background-size: 100%;
    }
  }
}
.el-menu-item-group .el-menu-item i {
  display: none;
  float: right;
  margin-right: -30px;
  margin-top: 20px;
  color: #c99f4f;
}
.el-menu-item-group .el-menu-item.is-active {
  background: linear-gradient(
    116deg,
    rgba(16, 16, 24, 1) 0%,
    rgba(90, 88, 88, 1) 100%
  ) !important;
}
.el-icon-arrow-right {
  color: rgb(250, 226, 165) !important;
}
.el-menu-item-group .el-menu-item:hover {
  background: rgba(85, 85, 85, 1) !important;
}
.el-menu-item-group .el-menu-item.is-active i {
  display: inline-block;
}

.active {
  background-color: #c99f4f;
}

.account-info-wrap {
}

.account-info-inner {
  margin-top: -520px;
}

.account-info-wrap .pageTop {
  position: relative;
  width: 100%;
  margin: 0 auto;
  height: 60px;
  background: linear-gradient(134deg, #6424de 0%, #a36df8 100%);
  opacity: 1;
}

.account-info-wrap .pageTop .logo {
  position: absolute;
  left: 0;
  bottom: 0;
  right: 0;
  margin: auto;
  width: 1190px;
  height: 60px;
  line-height: 60px;
}

.pageTop {
  img {
    vertical-align: middle;
  }

  .company-info {
    display: inline-block;
    padding: 0 4px;
    font-size: 18px;
    line-height: 60px;
    vertical-align: top;
    color: #ffffff;
    .hl22 {
      line-height: 22px;
      font-size: 14px;
    }
  }
}

.contain {
  position: relative;
  margin-top: 540px;
  min-height: 800px;

  &:after {
    display: table;
    content: "";
  }

  .menu {
    position: absolute;
    // float: left;
    width: 230px;
    height: 100%;

    ul {
      height: 100%;
    }
  }
}

.contain .rightList {
  margin-left: 240px;
  width: 1020px;
}

.contain .rightList h4 {
  margin-bottom: 20px;
  font-size: 14px;
  font-weight: 900;
}

.contain .rightList ul li {
  height: 72px;
  width: 940px;
}

.contain .rightList ul li:nth-child(2n) {
  background-color: #fafafa;
}

.contain .rightList ul li:nth-child(2n + 1) {
  background-color: #f5f5f5;
}

.contain .rightList ul li .title1 {
  float: left;
  margin-left: 30px;
  line-height: 72px;
}

.contain .rightList ul li p {
  float: left;
  line-height: 72px;
  margin-left: 70px;
}

.contain .rightList ul li:nth-last-child(1) p {
  margin-left: 60px;
}

.contain .rightList ul li button {
  width: 92px;
  height: 36px;
  color: #4f525a;
  float: right;
  border: 0;
  margin-top: 24px;
  margin-right: 40px;
  background-color: #c99f4f;
}

/deep/ .el-submenu__icon-arrow {
  width: 18px;
  height: 18px;
  border: 1px solid #fff;
  border-radius: 20px;
  line-height: 18px;
  text-align: center;
}
/deep/ .el-submenu__title {
  i {
    color: #fff;
  }
}
.disabled-color {
  color: #646464 !important;
}
.tab-btn-bg {
  transition: all 0.3s linear;
  padding: 0 12px;
  &:hover {
    background: linear-gradient(119deg, #d7b064 0%, #ecce8b 100%);
    color: #fff;
  }
}
</style>