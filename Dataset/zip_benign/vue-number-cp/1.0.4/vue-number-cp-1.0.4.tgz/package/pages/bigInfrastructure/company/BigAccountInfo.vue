<template>
  <div class="account-info-wrap">
    <AccountInfo></AccountInfo>
  </div>
</template>
<script>

  import AccountInfo from '@/components/account/AccountInfo'
  export default {
    components: {
      AccountInfo
    },
    data() {

      return {}
    },
    computed: {},
    methods: {},
    watch: {

    },
    mounted() {}
  }
</script>

<style scoped lang="scss">

</style>