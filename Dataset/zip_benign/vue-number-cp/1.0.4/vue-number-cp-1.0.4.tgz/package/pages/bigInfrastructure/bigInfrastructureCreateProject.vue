<template>
  <div class="index-wrap">
    <Header showType='bigIn' :isHome="true"></Header>
    <SearchBar
      :search-type="5"
      :progress="pageName"
      :is-border-bottom="true"
      :product-create-process="1"
      :searchType="10"
    ></SearchBar>

    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb" style="padding-bottom: 20px;"></Breadcrumb>

      <el-form label-width="120px" ref="baseInfoForm" :model="baseInfoForm" :rules="baseInfoRules">
        <!-- 工程信息 -->
        <div class="info-panel" style="margin-top: 0;">
          <PanelTitle title="工程信息"></PanelTitle>
          <div class="info-panel-content">
            <el-row class="project-name">
              <el-col :span="24">
                <el-form-item prop="projectId" label="工程合同编码：">
                  <el-input
                    v-model.trim="baseInfoForm.projectId"
                    clearable
                    maxlength="70"
                    placeholder="请输入本公司系统的工程编码"
                    :disabled="!isEdit"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <div class="form-inline-item">
              <el-form-item prop="projectType" label="工程类型：">
                <el-select
                  v-model="baseInfoForm.projectType"
                  placeholder="请选择"
                  clearable
                  :disabled="!isEdit"
                >
                  <el-option
                    v-for="item in projectTypeOptions"
                    :key="item.code"
                    :label="item.value"
                    :value="item.code"
                    clearable
                  ></el-option>
                </el-select>
              </el-form-item>
              <el-form-item></el-form-item>
            </div>
            <div class="form-inline-item">
              <div class="bulid-company">
                <div class="required fl corp-name">施工单位：</div>
                <div class="corp-content fl">
                  <div
                    v-for="(corpItem,index) in corpIdLi"
                    :key="'corp'+index"
                    class="corp-item"
                    :class="{'last-corp':index == (corpIdLi.length - 1)}"
                  >
                    <el-select
                      v-model="corpItem.corpId"
                      placeholder="请输入关键词搜索选择施工单位"
                      clearable
                      filterable
                      remote
                      :remote-method="(query)=>{remoteQuickCompanyMethod(query,corpItem,index)}"
                      @change="handleSameCompany(corpItem.corpId,corpItem,index);checkBaseInfoForm('corp')"
                      :disabled="!isEdit"
                    >
                      <el-option
                        v-for="item in corpItem.corpOptions"
                        :key="item.code"
                        :label="item.value"
                        :value="item.code"
                        :disabled="item.disabled"
                      ></el-option>
                    </el-select>
                    <div
                      @click="handleDel(index)"
                      class="del-corp"
                      v-show="isEdit && (corpIdLi.length != 1)"
                    >删除</div>
                  </div>
                  <div class="add-newCorp" @click="handleAddcorp" v-show="isEdit">+添加施工单位</div>
                  <div v-if="isCorpList && isEdit" class="note-text">请添加施工单位</div>
                </div>
              </div>
              <div></div>
            </div>
            <el-row class="project-name">
              <el-col :span="24">
                <el-form-item prop="projectName" label="工程名称：" class="resize-none">
                  <el-input
                    v-model.trim="baseInfoForm.projectName"
                    clearable
                    placeholder="请输入工程名称"
                    maxlength="200"
                    :disabled="!isEdit"
                    :autosize="{ minRows: 1, maxRows: 5}"
                    type="textarea"
                  ></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <div class="form-inline-item">
              <el-form-item label="开工日期：" prop="startDate">
                <el-date-picker
                  v-model="baseInfoForm.startDate"
                  type="date"
                  placeholder="请选择日期"
                  value-format="yyyy-MM-dd"
                  clearable
                  :picker-options="pickerBeginOptions"
                  :disabled="!isEdit"
                ></el-date-picker>
              </el-form-item>
              <el-form-item label="竣工日期：" prop="endDate">
                <el-date-picker
                  v-model="baseInfoForm.endDate"
                  type="date"
                  placeholder="请选择日期"
                  value-format="yyyy-MM-dd"
                  clearable
                  :picker-options="pickerEndOptions"
                  :disabled="!isEdit"
                ></el-date-picker>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item prop="buildingArea" label="建筑面积：">
                <el-input
                  v-model="baseInfoForm.buildingArea"
                  clearable
                  class="handle-close-20"
                  placeholder="请输入建筑面积"
                  maxlength="10"
                  @input="checkNum($event,baseInfoForm,'buildingArea')"
                  :disabled="!isEdit"
                  @blur="handleDelHeadZero('baseInfoForm','buildingArea')"
                ></el-input>
                <i class="unit">㎡</i>
              </el-form-item>
            </div>
            <div class="bulid-company">
              <div class="required fl corp-name">工程地点：</div>
              <div class="fl frastructure-content">
                <Distpicker
                  :address="baseInfoForm"
                  @receive="getAddressCode"
                  :isDistrict="false"
                  :isdisabledBigFrastructure="!isEdit"
                ></Distpicker>
              </div>
            </div>
            <el-row class="project-name">
              <el-col :span="24">
                <el-form-item label class="resize-none">
                  <el-input
                    v-model.trim="baseInfoForm.address"
                    clearable
                    placeholder="请填写详细地址"
                    @blur="checkBaseInfoForm('address');"
                    :autosize="{ minRows: 1, maxRows: 5}"
                    :disabled="!isEdit"
                    type="textarea"
                    maxlength="200"
                  ></el-input>
                  <div class="el-form-item__error" v-if="isAddress">请完善工程地址信息</div>
                </el-form-item>
              </el-col>
            </el-row>
          </div>
        </div>
        <!-- 工程权限管理 -->
        <!-- <div class="info-panel" style="margin-top: 0;">
          <PanelTitle title="工程权限管理"></PanelTitle>
          <div class="info-panel-content">
            <div class="polite-note">※点击【分配工程权限】分配本工程下的角色权限。若添加多个用户，请分多次点击【分配工程权限】添加。</div>
          </div>
        </div>-->
      </el-form>

      <!-- 提交 -->
      <FixBottom>
        <div class="tc" v-show="isEdit">
          <el-button
            style="width: 120px;"
            type="primary"
            @click="addFrastructure('0')"
            v-show="isCreated"
          >创建工程</el-button>
          <el-button
            style="width: 120px;"
            type="primary"
            v-if="!isCreated"
            @click="addFrastructure('2')"
          >提交</el-button>
          <el-button style="width: 120px;" @click="addFrastructure('1')" v-if="isCreated">保存</el-button>
          <el-button style="width: 120px;" @click="handleClosePage">关闭</el-button>
        </div>
      </FixBottom>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { mapActions, mapState } from "vuex";
import accountMixin from "@/mixins/account";
import VPagenation from "@/components/base/Pagenation";
import { InterfaceService } from "@/services/api";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import Footer from "@/components/base/Footer";
import Header from "@/components/base/Header";
import Breadcrumb from "@/components/base/Breadcrumb";
import PanelTitle from "@/components/base/PanelTitle";
import download from "@/utils/download";
import FixBottom from "@/components/base/FixBottom";
import axios from "axios";
import qs from "qs";
import Distpicker from "@/components/base/Distpicker";

const baseInfoForm = {
  projectId: "",
  projectType: "",
  projectName: "",
  province: "",
  city: "",
  startDate: "",
  endDate: "",
  buildingArea: "",
  address: "",
  provCode: "",
  cityCode: ""
};
const baseInfoRules = {
  projectId: [
    {
      required: true,
      message: "请输入工程合同编码",
      trigger: "blur"
    }
  ],
  projectType: [
    {
      required: true,
      message: "请选择工程类型",
      trigger: "change"
    }
  ],
  startDate: [
    {
      required: true,
      message: "请选择开工日期",
      trigger: "change"
    }
  ],
  endDate: [
    {
      required: true,
      message: "请选择竣工日期",
      trigger: "change"
    }
  ],
  projectName: [
    {
      required: true,
      message: "请输入工程名称",
      trigger: "blur"
    }
  ]
};

export default {
  mixins: [accountMixin],
  components: {
    VPagenation,
    SearchBar,
    Footer,
    Header,
    Loading,
    Breadcrumb,
    PanelTitle,
    FixBottom,
    Distpicker
  },
  data() {
    return {
      isLoading: false,
      fromSource: "",
      breadcrumb: [], //面包屑
      baseInfoForm: Object.assign({}, baseInfoForm), //基本信息
      baseInfoRules: baseInfoRules,
      projectTypeOptions: [], //工程类型列表
      corpIdLi: [{ corpId: "", corpName: "", corpOptions: [] }], //施工单位列表
      corpOptions: [], //施工单位查询列表
      isCorpList: false, //是否存在施工单位
      isAddress: false, //工程地址
      pickerBeginOptions: {
        disabledDate: time => {
          if (this.baseInfoForm.endDate) {
            return (
              time.getTime() > new Date(this.baseInfoForm.endDate).getTime()
            );
          }
        }
      },
      pickerEndOptions: {
        disabledDate: time => {
          if (this.baseInfoForm.startDate) {
            return (
              time.getTime() <
              new Date(this.baseInfoForm.startDate).getTime() - 86400000
            );
          }
        }
      },
      isEdit: true, //是否可编辑
      isCreated: true, //是否为创建
      pageName: "",
      cprojId: "", //详情唯一字段
      tagList: [] //施工单位使用
    };
  },
  watch: {},

  computed: {},
  methods: {
    //添加施工单位
    handleAddcorp() {
      this.corpIdLi.push({ corpId: "", corpName: "" });
    },
    //删除施工单位
    handleDel(index) {
      if (index == 0 && this.corpIdLi.length == 1) {
        this.corpIdLi[0].corpId = "";
        let el = this.corpIdLi[0];
        el.corpId = "";
        el.corpName = "";
        this.$set(this.corpIdLi, 0, el);
      } else {
        this.corpIdLi.splice(index, 1);
      }
      this.checkBaseInfoForm("corp");
    },
    getAddressCode(res) {
      this.$set(this.baseInfoForm, "province", res.provinceCode);
      this.$set(this.baseInfoForm, "city", res.cityCode);
      this.checkBaseInfoForm("address");
    },
    //获取code列表
    getCodeList() {
      let params = {
        appName: "MEMBER",
        groupId: "PROJECT_TYPE"
      };
      InterfaceService.getPaymentMethod(
        params,
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.projectTypeOptions = data.respData.configEntityList || [];
            if (this.cprojId) {
              this.getDetail();
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {},
        () => {
          //this.isLoading = true;
        },
        () => {
          //this.isLoading = false;
        }
      );
    },
    //创建工程
    addFrastructure(type) {
      if (this.baseInfoForm.buildingArea == "-") {
        this.baseInfoForm.buildingArea = "";
      }
      let params = {};
      params = this.baseInfoForm;
      params.corpIdList = [];
      if (this.corpIdLi.length > 0) {
        this.corpIdLi.forEach((el, index) => {
          if (el.corpId) {
            let objBean = {};
            objBean.corpId = el.corpId;
            objBean.corpName = el.corpName;
            objBean.sort = index;
            params.corpIdList.push(objBean);
          }
        });
      }
      //校验文本
      this.checkBaseInfoForm("all");
      this.$refs.baseInfoForm.validate((Leasevalid, object) => {
        if (Leasevalid && !this.isCorpList && !this.isAddress) {
          if (type == 0) {
            params.isDraft = "0"; //保存时位1
            this.$confirm(
              "请检查填写的工程信息内容，确认无误后点击【确认创建工程】按钮，其他成员即可查看到该工程信息。",
              "确认创建工程",
              {
                cancelButtonClass: "btn-custom-cancel",
                confirmButtonClass: "btn-custom-confirm",
                center: true,
                confirmButtonText: "确认创建工程",
                cancelButtonText: "取消",
                type: "warning"
              }
            )
              .then(() => {
                this.createFrastructure(params, type);
              })
              .catch(() => {});
          } else if (type == "1") {
            params.isDraft = "1"; //保存时位1
            this.createFrastructure(params, type);
          } else if (type == "2") {
            //编辑
            this.$confirm(
              "请检查填写的工程信息内容，确认无误后点击【确认提交】按钮，其他成员即可查看到该工程信息。",
              "确认提交工程",
              {
                cancelButtonClass: "btn-custom-cancel",
                confirmButtonClass: "btn-custom-confirm",
                center: true,
                confirmButtonText: "确认提交",
                cancelButtonText: "取消",
                type: "warning"
              }
            )
              .then(() => {
                this.createFrastructure(params, type);
              })
              .catch(() => {});
          }
        } else {
          return false;
        }
      });
    },
    createFrastructure(params, type) {
      /* 清空空字段 */
      let kongList = [];
      this.corpIdLi.forEach((el, index) => {
        if (!el.corpId) {
          kongList.push(el);
        }
      });
      this.corpIdLi.forEach((a, index) => {
        kongList.forEach(b => {
          if (a.corpId == b.corpId) {
            this.corpIdLi.splice(index, 1);
          }
        });
      });
      /* 如果存在id,添加id */
      if (this.cprojId) {
        delete params.cprojId;
        params.cprojId = this.cprojId;
      }
      InterfaceService.frastructureCreate(
        params,
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            if (type == "0") {
              if (this.cprojId) {
                //创建成功
                this.$router.push({
                  path: "/resultsFeedback",
                  query: {
                    type: "bigInfrastructure",
                    orderNo: this.cprojId,
                    projectName: this.baseInfoForm.projectName
                  }
                });
              } else {
                //创建成功
                this.$router.push({
                  path: "/resultsFeedback",
                  query: {
                    type: "bigInfrastructure",
                    orderNo: data.respData.cprojId,
                    projectName: this.baseInfoForm.projectName
                  }
                });
              }
            } else if (type == "1") {
              this.cprojId = data.respData.cprojId || "";
              this.$message.success("保存成功");
            } else if (type == "2") {
              this.$message.success("更改成功！");
              this.isEdit = false;
              this.isCreated = false;
              this.breadcrumb = [
                // { name: "管理中心", path: "/bigInfrastructureCenter/workbench" },
                { name: "管理中心", path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/workbench` },
                {
                  name: "公司管理-工程管理",
                  // path: "/bigInfrastructureCenter/ProjectManage"
                  path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/ProjectManage`
                },
                { name: "工程详情" }
              ];
              this.pageName = "工程详情";
              if (!this.baseInfoForm.buildingArea) {
                this.$set(this.baseInfoForm, "buildingArea", "-");
              }
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {},
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    checkNum(value, item, type, negative) {
      if (negative) {
        // 负数
        value = value.replace(/[^\d.-]/g, ""); //清除"数字"和"."以外的字符
      } else {
        value = value.replace(/[^\d.]/g, ""); //清除"数字"和"."以外的字符
      }
      value = value.replace(/^\./g, ""); //验证第一个字符是数字
      value = value.replace(/\.{2,}/g, "."); //只保留第一个, 清除多余的
      // value = value.replace(/-{2,}/g,""); //只保留第一个, 清除多余的
      if (value.length > 1 && value[value.length - 1] == "-") {
        value = value.substring(0, value.length - 1);
      }
      value = value
        .replace(".", "$#$")
        .replace(/\./g, "")
        .replace("$#$", ".");
      value = value.replace(/^(\-)*(\d+)\.(\d\d).*$/, "$1$2.$3"); //控制可输入的小数
      if (value.length > 1 && Number(value) == 0 && value != "0." && value != "0.0") {
        value = "";
      }
      item[type] = value;
    },
    handleDelHeadZero(model, key) {
      if (this[model][key] && this[model][key] != 0) {
        this.$set(this[model], key, Number(this[model][key]));
        return;
      }
      if (this[model][key] == 0) {
        this.$set(this[model], key, "");
        return;
      }
    },
    //校验文本
    checkBaseInfoForm(type) {
      if (type == "all" || type == "corp") {
        //判读是否添加施工单位
        if (this.corpIdLi.length > 0) {
          let list = [];
          this.corpIdLi.forEach(el => {
            if (el.corpId) {
              list.push(el);
            }
          });
          list.length > 0
            ? (this.isCorpList = false)
            : (this.isCorpList = true);
        }
      }
      if (type == "all" || type == "address") {
        //校验工程地址
        if (
          this.baseInfoForm.province &&
          this.baseInfoForm.city &&
          this.baseInfoForm.address
        ) {
          this.isAddress = false;
        } else {
          this.isAddress = true;
        }
      }
    },
    //施工单位查询
    remoteQuickCompanyMethod(query, corpItem, index) {
      query.replace(/\s*/g, "").length &&
        this.searchCompany(query, corpItem, index);
    },
    //查询
    searchCompany(query, corpItem, index) {
      const params = {
        searchKey: query,
        pageIndex: 1,
        pageSize: 10,
        tagList: this.tagList
      };
      if (params.tagList.length == 0) {
        delete params.tagList;
      }
      InterfaceService.frastructureSearchCompany(
        params,
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let dataList = data.respData.corpList || [];
            if (dataList.length > 0) {
              corpItem.corpOptions = [];
              corpItem.corpOptions = dataList.map(el => {
                return {
                  value: el.corpName || "",
                  code: el.corpId || ""
                };
              });
              //防止与本公司相同
              if (this.corpIdLi.length > 0) {
                this.corpIdLi.forEach(a => {
                  corpItem.corpOptions.forEach((b, i) => {
                    if (a.corpId == b.code) {
                      corpItem.corpOptions.splice(i, 1);
                    }
                  });
                });
              }
              this.$set(this.corpIdLi, index, corpItem);
            } else {
              this.corpOptions = [];
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {},
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    //详情接口
    getDetail() {
      const params = {
        cprojId: this.cprojId
      };
      InterfaceService.frastructureDetail(
        params,
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.baseInfoForm = data.respData.projectInfo || {};
            this.$set(
              this.baseInfoForm,
              "projectType",
              this.baseInfoForm.projectType.toString()
            );
            this.$set(
              this.baseInfoForm,
              "provCode",
              this.baseInfoForm.province
            );
            this.$set(this.baseInfoForm, "cityCode", this.baseInfoForm.city);
            //制作施工单位列表
            this.corpOptions = [];
            if (
              this.baseInfoForm.corpLi &&
              this.baseInfoForm.corpLi.length > 0
            ) {
              /* 排序 */
              this.corpOptions = this.baseInfoForm.corpLi.map(el => {
                return {
                  code: el.corpId,
                  value: el.corpName
                };
              });
              this.corpIdLi = [];
              this.corpOptions.forEach(el => {
                let obj = {};
                obj.corpId = el.code;
                obj.corpName = el.value;
                obj.corpOptions = this.corpOptions.filter(b => {
                  return obj.corpId == b.code;
                });
                this.corpIdLi.push(obj);
              });
              //面积
              if (!this.baseInfoForm.buildingArea) {
                let buildingArea = "-";
                if (!this.isEdit && !this.isCreated) {
                  this.$set(this.baseInfoForm, "buildingArea", buildingArea);
                } else {
                  if (!this.baseInfoForm.buildingArea) {
                    this.$set(this.baseInfoForm, "buildingArea", "");
                  }
                }
              }
              /* 要创建 还是提交 */
              if (this.baseInfoForm.isDraft == "0") {
                this.isCreated = false;
              } else if (this.baseInfoForm.isDraft == "1") {
                this.isCreated = true;
              }
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {},
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    //关闭页面
    handleClosePage() {
      let tip = "";
      if (this.isCreated) {
        tip = "关闭本页后，该页面内容失效。";
      } else {
        tip = "关闭本页后，更改的内容不被更新。";
      }
      this.$confirm(tip, "确认关闭", {
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        confirmButtonText: "确认关闭",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          // this.$router.push({ path: "/bigInfrastructureCenter/ProjectManage" });
          this.$router.push({ path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/ProjectManage` });
        })
        .catch(() => {});
    },
    //获取公司基本信息的接口
    getCompanyInfo() {
      InterfaceService.frastructureObtainCompanyInfo(
        {},
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let beanObj = data.respData.corpInfoEntry || {};
            if (JSON.stringify(beanObj) != "{}") {
              this.corpIdLi = [{ corpId: "", corpName: "", corpOptions: [] }];
              this.corpIdLi[0].corpId = beanObj.key;
              this.corpIdLi[0].corpName = beanObj.value;
              this.corpIdLi[0].corpOptions = [
                { code: beanObj.key, value: beanObj.value }
              ];
            }
            this.getCodeList();
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {},
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    //去重
    handleSameCompany(corpId, item, index) {
      console.log(corpId);
      if(item.corpOptions && item.corpOptions.length > 0){
        item.corpOptions.forEach(a=>{
          if(a.code == corpId){
            item.corpName = a.value;
          }
        })
        this.$set(this.corpIdLi,index,item);
      }
      if (this.corpIdLi.length > 0) {
        this.corpIdLi.forEach((a, i) => {
          if (a.corpId == corpId && i != index && corpId) {
            item.corpId = "";
            this.$set(this.corpIdLi, index, item);
            this.$message.error("不能选择重复的施工单位！");
          }
        });
      }
    },
    //获取taglist
    getTagList() {
      let tagList = [];
      if (this.$store.state.userInfo) {
        tagList = this.$store.state.userInfo.corpTags || [];
        if (tagList.length > 0) {
          tagList.map(el => {
            if (el.tagId) {
              this.tagList.push(el.tagId);
            }
          });
        }
      }
    }
  },
  mounted() {
    this.getCompanyInfo();
    this.getTagList();
    this.cprojId = this.$route.query.projectId || "";
    if (this.$route.query.isEdit && this.$route.query.projectId) {
      //编辑
      this.isEdit = true;
      this.breadcrumb = [
        // { name: "管理中心", path: "/bigInfrastructureCenter/workbench" },
        { name: "管理中心", path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/workbench` },
        {
          name: "公司管理-工程管理",
          // path: "/bigInfrastructureCenter/ProjectManage"
          path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/ProjectManage`
        },
        { name: "编辑工程" }
      ];
      this.pageName = "编辑工程";
    } else if (this.$route.query.projectId) {
      //查看详情
      this.isEdit = false;
      this.isCreated = false;
      this.breadcrumb = [
        // { name: "管理中心", path: "/bigInfrastructureCenter/workbench" },
        { name: "管理中心", path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/workbench` },
        {
          name: "公司管理-工程管理",
          // path: "/bigInfrastructureCenter/ProjectManage"
          path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/ProjectManage`
        },
        { name: "工程详情" }
      ];
      this.pageName = "工程详情";
    } else {
      //创建
      this.isEdit = true;
      this.isCreated = true;
      this.breadcrumb = [
        // { name: "管理中心", path: "/bigInfrastructureCenter/workbench" },
        { name: "管理中心", path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/workbench` },
        {
          name: "公司管理-工程管理",
          // path: "/bigInfrastructureCenter/ProjectManage"
          path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/ProjectManage`
        },
        { name: "创建工程" }
      ];
      this.pageName = "创建工程";
    }
  },
  destroyed() {},
  updated() {}
};
</script>

<style lang="scss" scoped>
/deep/ .el-form .el-col {
  height: 62px;
}

/deep/ .el-form .el-select {
  width: 100%;
}

.el-form-item.is-error input {
  border-color: #f56c6c;
}

p {
  margin-bottom: 20px;
}
a.link {
  display: inline-block;
  vertical-align: middle;
  padding: 0 10px;
  color: #0082ff;
}

.error-info {
  position: absolute;
  top: 100%;
  left: 0;
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
}

.attr-col {
  position: relative;
}

.error-attr-info {
  position: absolute;
  top: 100%;
  left: 10px;
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
}

.inner-container {
  margin-bottom: 100px;
  font-size: 14px;
}

.form-inline-item {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  position: relative;
  &.noFlex {
    flex-direction: column;
  }
  & > div {
    flex-shrink: 0;
  }

  /deep/ .el-select {
    width: 100%;
  }

  div .error-info {
    display: none;
  }
  div.is-error .error-info {
    display: block;
  }
}

.form-inline-item.freight-item {
  justify-content: flex-start;
}

.sale-model-panel {
  div .error-info {
    display: none;
  }
  div.is-error .error-info {
    display: block;
  }
}

.form-item {
  position: relative;
  line-height: 40px;

  .float-right {
    position: absolute;
    top: 1px;
    right: 2px;
    bottom: 2px;
    padding: 0 10px;
    background: #fff;
  }

  input::-ms-clear {
    display: none;
  }
}

/deep/ .el-form-item__label {
  color: #909399;
}

.info-panel {
  margin-top: 30px;
}
.border-dashed {
  padding-top: 20px;
  border-top: 1px dashed #ccc;
}
/*.brand-other {*/
/*margin-top: 20px;*/
/*padding-left: 30px;*/
/*}*/

.info-panel-title {
  position: relative;
  border-left: 3px solid #000;
  margin: 10px 0;
  padding: 0 4px;
  padding-right: 0;
  font-weight: bold;
  color: rgb(41, 41, 41);

  i {
    font-size: 12px;
    color: rgb(143, 143, 143);
  }
  a {
    font-size: 12px;
    text-decoration: underline;
    color: #0082ff;
  }
  button {
    position: absolute;
    bottom: 0;
    right: 0;
  }
}

.info-panel-content {
  &.bottom {
    padding-bottom: 20px;
  }
  /deep/ .el-input {
    input {
      height: 34px;
      width: 400px;
    }
  }
  .w100 {
    /deep/ input {
      width: 100%;
    }
  }
}

.info-detail {
  position: relative;
  z-index: 1;
  max-height: 800px;
  // min-height: 500px;
}

.info-detail-img {
  padding: 10px 30px;
  border: 1px solid #e0e0e0;
  border-top: none;
  line-height: 30px;
  background: #f5f5f5;

  button {
    float: right;
    margin: 0 5px;
  }
}

.model-table {
  thead td {
    text-align: center;
  }

  td {
    padding: 10px;
    padding-left: 0;
  }
}

.model-content {
  margin-bottom: 1px;
  table {
    table-layout: fixed;
    thead {
      td {
        text-align: left;
        padding: 7px 10px;
      }
      background: #f5f5f5;
      font-size: 14px;
      color: #888;
    }
    tbody {
      tr {
        td {
          text-align: left;
          color: #444;
          padding: 4px 5px;
          /deep/ .right_padding {
            .suffix {
              line-height: 34px;
            }
          }
          &:first-child {
            color: #888;
          }
          &:last-child {
            padding-right: 0;
          }
          /deep/ .el-input {
            input {
              height: 34px;
            }
          }
        }
      }
    }
  }
}

.model-panel.bottom {
  padding-bottom: 0;
  line-height: 40px;
}
.model-panel.bottom:last-child {
  padding-bottom: 20px;
}

.model-panel.bottom.expand {
  margin-top: 1px;
  padding-bottom: 20px;
}

.model-head {
  line-height: 40px;
  color: #909399;
  span {
    margin-right: 5px;
  }
}
/deep/ .el-input.error {
  border: 1px solid #f00;
}

.model-expand {
  float: right;
  color: #0082ff;
}

.sale-model-panel {
  margin-top: 20px;
  padding: 20px 20px 0;
  border-top: 1px solid rgb(230, 229, 229);
}

.tooltip-name {
  color: #ccc;
  &:hover {
    color: #444444;
  }
}

.fix-bottom {
  position: fixed;
  bottom: 0;
  left: 0;
  z-index: 1;
  width: 100%;
  padding: 20px;
  text-align: center;
  background: rgba(79, 82, 90, 0.8);

  button {
    width: 150px;
  }
}

/deep/ .v-note-wrapper.fullscreen {
  max-height: inherit;
}

/deep/ .v-note-wrapper {
  em {
    font-style: italic;
  }

  sup {
    vertical-align: super;
    font-size: smaller;
  }

  sub {
    vertical-align: sub;
    font-size: smaller;
  }

  ul {
    list-style-type: disc;
  }

  ol {
    list-style-type: decimal;
  }
}

/deep/ .v-note-wrapper .v-note-read-model.show {
  width: 930px;
  padding: 0;
}

/deep/ .v-note-img-wrapper {
  z-index: 1;
}

.freight-price {
  margin: 0 10px;
  font-size: 15px;
  font-weight: bold;
}

.alert-reject {
  margin-top: 20px;
  padding: 30px 20px;
  border: 1px solid red;
  border-radius: 0;
  color: #444;

  /deep/ .el-alert__title {
    font-size: 14px;
    font-weight: bold;
  }
}

.float-price-content {
  position: relative;
  margin-bottom: 2px;

  /deep/ .el-input {
    width: 200px;
  }

  label {
    color: #909399;
  }

  .tip {
    color: #aaa;
  }

  .error-attr-info {
    left: 100px;
    bottom: 2px;
    top: auto;
  }
}

.form-float-price {
  padding-bottom: 22px;

  /deep/ .el-input {
    width: 990px;
  }

  .tip {
    color: #aaa;
  }
}

.brand-desc {
  margin-bottom: 22px;
  line-height: 40px;
  margin-left: -150px;
}
.brandNameNotice {
  color: #888;
  font-size: 12px;
  line-height: 20px;
  margin-top: 12px;
  white-space: pre;
}
/deep/ .right_padding {
  .el-input__inner {
    padding-right: 30px;
    height: 32px;
    line-height: 32px;
  }
  .suffix {
    width: 68px;
    text-align: right;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: #444;
    margin-right: 4px;
    line-height: 40px;
  }
}
.required {
  &::before {
    content: "*";
    color: #f56c6c;
    // margin-right: 4px;
  }
}
.info-panel-content {
  /deep/ .el-input input,
  .el-select,
  .el-date-editor {
    width: 400px;
  }
}
.add-newCorp {
  width: 90px;
  height: 17px;
  font-size: 12px;
  font-family: PingFang SC;
  font-weight: 400;
  line-height: 17px;
  color: #0082ff;
  cursor: pointer;
}
.corp-name {
  width: 120px;
  text-align: right;
  height: 34px;
  font-size: 14px;
  font-weight: 400;
  line-height: 34px;
  color: #888888;
}
.corp-content {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  flex-direction: column;
  width: calc(100% - 120px);
}
.unit {
  position: absolute;
  right: 8px;
  top: 50%;
  height: 36px;
  line-height: 36px;
  // font-size: 12px;
  color: #444;
  margin-top: -18px;
}
.handle-close-20 {
  /deep/ .el-input__suffix {
    right: 20px;
  }
}
.polite-note {
  font-size: 12px;
  font-family: PingFang SC;
  font-weight: 400;
  line-height: 30px;
  color: #444444;
  height: 30px;
  background: #fffcf0;
  border: 1px solid #fae2a5;
  padding-left: 10px;
}
.bulid-company-wrap {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  > div {
    flex: 1;
  }
}
.bulid-company {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  margin-bottom: 22px;
  .corp-item {
    position: relative;
    margin-bottom: 22px;
    /deep/ .el-select {
      width: 100%;
    }
  }
  .last-corp {
    margin-bottom: 5px;
  }
}
.project-name {
  max-height: 100px;
  /deep/ .el-input input,
  .el-select,
  .el-date-editor {
    width: 100%;
  }
  > div {
    height: auto !important;
  }
}
.del-corp {
  width: 50px;
  position: absolute;
  top: 10px;
  left: 410px;
  font-size: 12px;
  color: #0082ff;
  cursor: pointer;
}
.frastructure-content {
  width: 840px;
  /deep/ .linkage .el-select {
    width: 48%;
    margin-right: 10px;
  }
}
.note-text {
  color: #df0a0a;
  font-size: 12px;
  padding-top: 10px;
}
.current-company {
  margin-bottom: 22px;
}
/deep/ .el-input.is-disabled .el-input__inner {
  background-color: #f5f7fa;
}
/deep/ textarea::-webkit-input-placeholder {
  /* WebKit browsers */
  padding-top: 2px;
}
/deep/ textarea:-moz-placeholder {
  /* Mozilla Firefox 4 to 18 */
  padding-top: 2px;
}
/deep/ textarea::-moz-placeholder {
  /* Mozilla Firefox 19+ */
  padding-top: 2px;
}
/deep/ textarea::-ms-input-placeholder {
  /* Internet Explorer 10+ */
  padding-top: 2px;
}
/deep/ .el-textarea.is-disabled .el-textarea__inner {
  color: #606266;
}
</style>
