<template>
  <div class="supplierDirectoryDetails">
    <PanelTitle :title="'供应商名录'"></PanelTitle>
    <Breadcrumb :breadcrumbList="breadcrumb" style="padding: 0px;margin-top: -10px"></Breadcrumb>
    <div class="order-info-title" style="margin-bottom: 8px !important;">供应商信息</div>
    <div class="supplierInfo">
      <el-row>
        <el-col :span="12">
          <p>
            <label>供应商名称：</label>{{supplierInfo.supplierName}}
          </p>
        </el-col>
        <el-col :span="12">
          <p>
            <label>统一社会信用代码：</label>{{supplierInfo.creditCode}}
          </p>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <p>
            <label>法人代表：</label>{{supplierInfo.legalPersonName}}
          </p>
        </el-col>
        <el-col :span="12">
          <p>
            <label>注册资本：</label>
            {{supplierInfo.regCapital}}
            <!-- <template v-if="!isNaN(Number(supplierInfo.registCapital))">
              {{supplierInfo.registCapital | formatMoney}}万元
            </template>
            <template v-else>
              {{supplierInfo.registCapital}}
            </template> -->
          </p>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <p>
            <label>行业：</label>
            {{supplierInfo.industry}}
          </p>
        </el-col>
        <el-col :span="12">
          <p>
            <label>注册时间：</label>{{supplierInfo.estiblishTime}}
          </p>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <p>
            <label>营业期限：</label>{{supplierInfo.operatingPeriod}}
          </p>
        </el-col>
        <el-col :span="12">
          <p>
            <label>核准日期：</label>
            {{supplierInfo.approvedTime}}
          </p>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <p>
            <label>人员规模：</label>{{supplierInfo.managementCnt || supplierInfo.staffNumRange || ''}}
          </p>
        </el-col>
        <el-col :span="12">
          <p>
            <label>登记机关：</label>
            {{supplierInfo.regInstitute}}
          </p>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <p>
            <label>参保人数：</label>
            {{supplierInfo.socialStaffNum}}
          </p>
        </el-col>
        <el-col :span="12">
          <p>
            <label>联系人：</label>
            {{supplierInfo.contact}}
          </p>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <p>
            <label>联系电话：</label>
            {{supplierInfo.phoneNumber}}
          </p>
        </el-col>
      </el-row>
    </div>
    <div class="order-info-title" style="margin-bottom: 10px !important;">合同信息</div>
    <div class="list-content">
      <div class="panel">
        <el-form class="form" size="small" label-width="75px" type="flex" justify="space-between">
          <el-row>
            <el-col :span="24">
              <el-form-item label="合同名称：">
                <el-input v-model.trim="form.contractName" placeholder="请输入合同关键词或合同编号" maxlength="50" clearable></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="工程名称：">
                <el-input v-model.trim="form.projectName" placeholder="请输入关键词搜索工程" maxlength="50" clearable></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="签署时间：" class="seatch-width">
                <el-row class="two_label">
                  <el-col :span="11">
                    <el-date-picker value-format="yyyy-MM-dd" v-model="form.sginStartTm" type="date" placeholder="选择时间" :picker-options="pickerOptionsStart">
                    </el-date-picker>
                  </el-col>
                  <el-col :span="2" class="tc">~</el-col>
                  <el-col :span="11">
                    <el-date-picker value-format="yyyy-MM-dd" v-model="form.sginEndTm" type="date" placeholder="选择时间" :picker-options="pickerOptionsEnd">
                    </el-date-picker>
                  </el-col>
                </el-row>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="合同类型：" class="seatch-width fr">
                <el-select filterable v-model="form.contractType" placeholder="请选择合同类型" clearable>
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="(item,index) in contractTypeList" :key="index" :label="item.value" :value="item.code"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <!-- <el-col :span="8">
              <el-form-item label="公司：" class="seatch-width">
                <el-select filterable v-model="contractType" placeholder="请选择公司" clearable>
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="(item,index) in contractTypeList" :key="index" :label="item.value" :value="item.code"></el-option>
                </el-select>
              </el-form-item>
            </el-col> -->
            <el-col :span="8">
              <el-form-item label="公司：" class="seatch-width fr">
                <el-input v-model.trim="form.corpId" placeholder="请输入公司名称" clearable maxlength="50"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-row>
          <el-col :span="24" align="center">
            <el-button class="small-btn" type="primary" size="small" @click="search()">搜索</el-button>
            <el-button class="small-btn" size="small" @click="clear()">清除</el-button>
          </el-col>
        </el-row>
      </div>
      <TableThead :TopDistance="760" width="1020" left="240">
        <tr slot="tr">
          <td>合同编号/合同名称</td>
          <td width="170px">合同类型</td>
          <td width="170px">公司</td>
          <!-- <td width="170px">甲方</td> -->
          <td width="150px" class="tr">合同价款(含税)(元)</td>
          <td width="120px">签署时间</td>
          <td width="90px">操作</td>
        </tr>
      </TableThead>
      <table class="table-default">
        <thead>
          <tr>
            <td>合同编号/合同名称</td>
            <td width="170px">合同类型</td>
            <td width="170px">公司</td>
            <!-- <td width="170px">甲方</td> -->
            <td width="150px" class="tr">合同价款(含税)(元)</td>
            <td width="120px">签署时间</td>
            <td width="90px">操作</td>
          </tr>
        </thead>
        <tbody v-for="(item,ind) in dataList" :key="ind">
          <tr>
            <td>
              <p>{{item.contractNo || ""}}</p>
              <p v-if="item.contractName && item.contractName.length < 50">{{"《" + item.contractName + "》" || ""}}</p>
              <el-popover popper-class="dark-popover" trigger="hover" placement="top" v-else-if="item.contractName && item.contractName.length >= 50">
                <div style="color: #fff;width: 500px">
                  {{"《" + item.contractName + "》"}}
                </div>
                <p slot="reference" v-if="$isIE()">{{"《" + item.contractName.slice(0,50)+"...》"}}</p>
                <p slot="reference" v-else class="ellipsisTwo">{{"《" + item.contractName + "》"}}</p>
              </el-popover>
            </td>
            <td>
              {{item.contractTypeName}}
            </td>
            <td>
              <p>{{item.corpName}}</p>
              <!-- <p>{{item.supplierName}}</p> -->
            </td>
            <td class="tr">{{item.priceIncludingTax | formatMoney}}</td>
            <td>{{item.signingTm}}</td>
            <td>
              <p class="tr">
                <span class="blue-pointer" @click="handleGoDetail(item)">查看详情</span>
              </p>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="noData" v-if="!dataList.length">
        <p class="f14 grey">暂无信息，请重新修改搜索条件搜索！</p>
      </div>
      <div class="table-pagination" v-if="dataList.length">
        <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
        </el-pagination>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import TableThead from "@/components/base/TableThead";
import Breadcrumb from "@/components/base/Breadcrumb";
import accountMixin from "@/mixins/account";
const forms = {
  contractName: "",
  projectName: "",
  corpId: "",
  supplierName: "",
  contractType: "",
  sginStartTm: "",
  sginEndTm: "",
};
export default {
  components: {
    Loading, PanelTitle, TableThead, Breadcrumb
  },
  mixins: [accountMixin],
  data() {
    return {
      isLoading: false,
      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码

      breadcrumb: [],
      supplierId: '',
      id: '',
      supplierInfo: {},
      contractTypeList: [],
      form: Object.assign({}, forms),
      dataList: [],

      pickerOptionsStart: {
        disabledDate: time => {
          if (this.form.sginEndTm) {
            return time.getTime() > new Date(this.form.sginEndTm).getTime();
          }
        }
      },
      pickerOptionsEnd: {
        disabledDate: time => {
          if (this.form.sginStartTm) {
            return time.getTime() < new Date(this.form.sginStartTm).getTime() - 86400000;
          }
        }
      },
    }
  },
  methods: {
    handleGoDetail(item) {
      window.open(this.$router.resolve({
        path: "/bigInfrastructureEntry",
        query: {
          instrConid: item.instrConid,
          pageType: 'supplierDirectoryDetails',
        }
      }).href, '_blank')
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.getContractListData()
      window.scrollTo(0, 0)
    },
    search() {
      this.pageIndex = 1
      this.getContractListData()
    },
    clear() {
      this.form = Object.assign({}, forms);
      this.search()
    },
    // 供应商详情-供应商信息-工商信息
    supplierBusinessInfo() {
      let param = {
        id: this.id,
        supplierId: this.supplierId
      }
      InterfaceService.supplierBusinessInfo(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.supplierInfo = data.respData.supplierInfo || {}
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },

    getPaymentMethod() {
      const params = {
        appName: "TRANS",
        groupId: "LVDI_DJJ_CONTRACT_TYPE"
      }
      InterfaceService.getPaymentMethod(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.contractTypeList = data.respData.configEntityList || [];
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    getContractListData() {
      let params = Object.assign({}, this.form)
      params.pageSize = this.pageSize
      params.pageIndex = this.pageIndex
      params.supplierId = this.supplierId
      params.instrMember = this.$route.query.instrMember
      params.projectCorpId = this.$route.query.projectCorpId
      InterfaceService.contractListData(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.dataList = data.respData.contractInfoList || [];
            this.total = data.respData.totalCount;
            // this.form.pageSize = data.respData.pageSize;
          } else {
            this.$message.error(data.respData.respMsg);
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    init() {
      this.supplierId = this.$route.query.supplierId || ''
      this.id = this.$route.query.id || ''
      const supplierName = this.$route.query.supplierName || ''
      const pageType = this.$route.query.pageType || ''
      this.form.sginStartTm = this.$route.query.tmStart || ''
      this.form.sginEndTm = this.$route.query.tmEnd || ''

      if (pageType === 'Workbench') {
        this.breadcrumb = [
          // { name: "管理中心", path: "/bigInfrastructureCenter/workbench" },
          // { name: "交易数据分析", path: "/bigInfrastructureCenter/workbench" },
          { name: "管理中心", path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/workbench` },
          { name: "交易数据分析", path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/workbench` },
          { name: supplierName || '供应商名录' }
        ]
      } else {
        this.breadcrumb = [
          // { name: "管理中心", path: "/bigInfrastructureCenter/workbench" },
          // { name: "供应商管理-供应商名录", path: "/bigInfrastructureCenter/supplierDirectory" },
          { name: "管理中心", path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/workbench` },
          { name: "供应商管理-供应商名录", path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/supplierDirectory` },
          { name: supplierName || '供应商名录' }
        ]
      }
      this.supplierBusinessInfo()
      this.getPaymentMethod()
      this.getContractListData()
    },
  },
  mounted() {
    this.init()
  },
}
</script>
<style lang="scss" scoped>
/deep/ .seatch-width {
  .el-form-item__content {
    width: 240px !important;
    .el-select {
      width: 100%;
    }
  }
}
/deep/.two_label {
  .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 100%;
  }
  .el-input--small .el-input__inner {
    padding: 0 10px;
  }
  .el-input__prefix {
    display: none;
  }
}
.supplierDirectoryDetails {
  padding-bottom: 60px;
  .supplierInfo {
    padding-bottom: 25px;
    line-height: 27px;
    font-size: 12px;
    border-bottom: 1px solid #eeeeee;
    p {
      width: 100%;
      display: flex;
      padding-right: 10px;
      word-break: break-word;
      white-space: normal;

      & > span {
        display: inline-block;
        flex: 1 1 0%;
      }
    }

    label {
      white-space: nowrap;
      color: #888888;
    }

    a {
      white-space: nowrap;
      color: #0082ff;
    }

    i {
      font-style: normal;
    }
  }
  .list-content {
    .panel {
      background-color: #fff;
      background: rgba(249, 249, 249, 1);
      padding: 20px 10px;
      margin: 10px 0 30px;
    }
  }
  .noData {
    padding-top: 100px;
    > p {
      text-align: center;
      margin-bottom: 8px;
    }
  }
}
</style>