<template>
  <div class="supplierDirectory">
    <PanelTitle :title="'供应商名录'"></PanelTitle>
    <div class="list-content">
      <div class="panel">
        <el-form class="form" size="small" label-width="60px" type="flex" justify="space-between">
          <el-row>
            <el-col :span="8">
              <el-form-item label="供应商：" class="seatch-width" :class="{'pr10': !supplierKey}">
                <el-input v-model.trim="supplierKey" placeholder="请输入供应商名称或统一社会信用代码" maxlength="64" clearable></el-input>
              </el-form-item>
            </el-col>
            <el-col class="two_label">
              <el-form-item label="总签约金额：">
                <el-row>
                  <el-col>
                    <el-input v-model.trim="transAmountStart" placeholder="请输入" class="right_padding" maxlength="15" @input="transAmountStart=transAmountStart.replace(/[^\d.]/g,'')">
                      <div slot="suffix" class="suffix">元</div>
                    </el-input>
                  </el-col>
                  <el-col class="tc">~</el-col>
                  <el-col>
                    <el-input v-model.trim="transAmountEnd" placeholder="请输入" class="right_padding" maxlength="15" @input="transAmountEnd=transAmountEnd.replace(/[^\d.]/g,'')">
                      <div slot="suffix" class="suffix">元</div>
                    </el-input>
                  </el-col>
                </el-row>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="类型：" class="seatch-width fr">
                <el-select filterable style="width: 240px;" v-model="supplierType" placeholder="请选择类型" clearable>
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="(item,index) in supplierTypeList" :key="index" :label="item.value" :value="item.code"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-row>
          <el-col :span="24" align="center">
            <el-button class="small-btn" type="primary" size="small" @click="search()">搜索</el-button>
            <el-button class="small-btn" size="small" @click="clear()">清除</el-button>
          </el-col>
        </el-row>
      </div>
      <TableThead :TopDistance="300" width="1020" left="240">
        <tr slot="tr">
          <td>供应商名称</td>
          <td width="140px">类型</td>
          <td width="180px">统一社会信用代码</td>
          <td width="160px" class="tr">总签约金额(含税)(元)</td>
          <td width="150px" class="tr">签订合同数量(份)</td>
          <td width="90px">操作</td>
        </tr>
      </TableThead>
      <table class="table-default">
        <thead>
          <tr>
            <td>供应商名称</td>
            <td width="140px">类型</td>
            <td width="180px">统一社会信用代码</td>
            <td width="160px" class="tr">总签约金额(含税)(元)</td>
            <td width="150px" class="tr">签订合同数量(份)</td>
            <td width="90px">操作</td>
          </tr>
        </thead>
        <tbody v-for="(item,ind) in dataList" :key="ind">
          <tr>
            <td>
              {{item.supplierName}}
            </td>
            <td>
              {{item.supplierTypeName}}
            </td>
            <td>
              {{item.creditNo}}
            </td>
            <td class="tr">
              {{item.transAmount | formatMoney}}
            </td>
            <td class="tr">
              {{item.contractTotal | formatThreeDigits}}
            </td>
            <td>
              <p><span class="blue-pointer" @click="handleSupplierDirectoryDetails(item)">查看详情</span></p>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="noData" v-if="!dataList.length">
        <p class="f14 grey">暂无信息，请重新修改搜索条件搜索！</p>
      </div>
      <div class="table-pagination" v-if="dataList.length">
        <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
        </el-pagination>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import TableThead from "@/components/base/TableThead";
import accountMixin from "@/mixins/account";

export default {
  components: {
    Loading, PanelTitle, TableThead
  },
  mixins: [accountMixin],
  data() {
    return {
      isLoading: false,
      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码

      supplierKey: '',
      transAmountStart: '',
      transAmountEnd: '',
      supplierType: '',
      dataList: [],
      supplierTypeList: [],
      instrMember: '',
      projectCorpId: '',
    }
  },
  methods: {
    handleSupplierDirectoryDetails(item) {
      this.$router.push({
        // path: '/bigInfrastructureCenter/supplierDirectoryDetails',
        path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/supplierDirectoryDetails`,
        query: {
          supplierId: item.supplierId,
          id: item.id,
          supplierName: item.supplierName,
          instrMember: this.instrMember || '',
          projectCorpId: this.projectCorpId || '',
        }
      })
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.supplierDirectoryList()
      window.scrollTo(0, 0)
    },
    search() {
      this.pageIndex = 1
      this.supplierDirectoryList()
    },
    clear() {
      this.supplierKey = ''
      this.transAmountStart = ''
      this.transAmountEnd = ''
      this.supplierType = ''
      this.search()
    },
    getPaymentMethod() {
      return new Promise(resolve => {
        const params = {
          appName: 'TRANS',
          groupIds: ['SUPPLIER_TYPE', 'DATA_ANALYSE_ALL_ROLE'],
        }
        InterfaceService.getPaymentMethod(params, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let res = data.respData.configEntityListMap || {};
            this.supplierTypeList = res.SUPPLIER_TYPE || []

            if (this.bigInfrastructure) {
              // 用于判断 基建成员
              const allRoleItem = res.DATA_ANALYSE_ALL_ROLE && res.DATA_ANALYSE_ALL_ROLE[0] || {},
                roleList = this.roleListFilter(this.mxCorpId),
                isSysAdmin = roleList.some(s => s.roleId == allRoleItem.value)

              this.instrMember = this.userinfo.corpTags && this.userinfo.corpTags[0] && this.userinfo.corpTags[0].tagId || ''
              //  非系统管理员 需要设置 当前登录用户 项目公司
              if (!isSysAdmin) {
                this.projectCorpId = this.userinfo.corpTags && this.userinfo.corpTags[0] && this.userinfo.corpTags[0].corpId || ''
              }
            }
            resolve(true)

          } else {
            this.$message.error(data.respData.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },
    supplierDirectoryList() {
      let param = {
        supplierKey: this.supplierKey,
        transAmountStart: this.transAmountStart,
        transAmountEnd: this.transAmountEnd,
        supplierType: this.supplierType,
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
        instrMember: this.instrMember,
        projectCorpId: this.projectCorpId,
      }
      InterfaceService.supplierDirectoryList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.dataList = data.respData.suplierInfoList || []

          this.total = data.respData.totalCount
          //   this.pageSize = data.respData.pageSize
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    async init() {
      await this.getPaymentMethod()
      this.supplierDirectoryList()
    },
  },
  mounted() {
    this.init()
  },
}
</script>
<style lang="scss" scoped>
/deep/ .seatch-width {
  .el-form-item__content {
    width: 240px !important;
    .el-select {
      width: 100%;
    }
  }
  &.pr10 {
    .el-input--suffix {
      .el-input__inner {
        padding-right: 10px;
      }
    }
  }
}
/deep/.two_label {
  .el-form-item__label {
    width: 92px !important;
  }
  .el-form-item__content {
    margin-left: 92px !important;
  }
  display: flex;
  justify-content: flex-end;
  &.el-col-24 {
    width: inherit;
    width: initial;
  }
  .el-col {
    width: 110px;
    &:nth-child(2) {
      width: 20px;
    }
  }
  .el-form-item__label {
    width: 90px !important;
  }
  .el-form-item__content {
    margin-left: 90px !important;
  }
}
.supplierDirectory {
  .list-content {
    .panel {
      background-color: #fff;
      background: rgba(249, 249, 249, 1);
      padding: 20px 10px;
      margin: 10px 0 30px;
      .suffix {
        color: #444;
        margin-right: 4px;
      }
    }
  }
  .noData {
    padding-top: 100px;
    > p {
      text-align: center;
      margin-bottom: 8px;
    }
  }
}
</style>