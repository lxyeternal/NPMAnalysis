<template>
  <div class="index-wrap">
    <Header showType='bigIn' :isHome="true"></Header>
    <!-- <SearchBar
      :is-red-bg="true"
      :fromIndex="true"
      :progress="'上线入库'"
      :search-type="searchBarType"
      :scrollShowFixed="true"
      @listenIsShowFooter="clickPoint()"
      :inputShowPointNotice="true"
      @outputPointNotice="outputPointNotice"
    ></SearchBar>-->
    <SearchBar :progress="pageName" :is-border-bottom="true" :product-create-process="1" :searchType="10"></SearchBar>

    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb" style="padding-bottom: 20px;"></Breadcrumb>

      <el-form label-width="160px" ref="baseInfoForm" :model="baseInfoForm" :rules="baseInfoRules" v-show="(isEdit && isCreated) || isGetDetailData">
        <!-- 工程信息 -->
        <div class="info-panel" style="margin-top: 0;">
          <PanelTitle title="工程信息"></PanelTitle>
          <div class="info-panel-content">
            <el-row :gutter="20" class="frastructure-name">
              <el-col :span="24">
                <el-form-item label="工程名称：" prop="cprojId">
                  <PageSelect v-model="baseInfoForm.cprojId" :filterable="true" :popSelectItem="popSelectItem" :dataList="frastructureNameOptions" :disabled="!isEdit" :pageInfo="pageInfo" @getDataList="getCprojDataList" @change="handlePageSelectChange" @currentChange="selectCurrentChange"></PageSelect>
                </el-form-item>
              </el-col>
            </el-row>
            <div class="project-info" v-show="projectInfo">
              <div class="project-info-item">
                <div class="info-item">
                  <div class="item-name special-width">工程合同编码：</div>
                  <div class="item-content spcial-content" :title="projectInfo.projectId || ''">{{projectInfo.projectId || "-"}}</div>
                </div>
                <div class="info-item">
                  <div class="item-name special-width">开工竣工日期：</div>
                  <div class="item-content spcial-content">
                    {{projectInfo.startDate || ""}}
                    <span>~</span>
                    {{projectInfo.endDate || ""}}
                  </div>
                </div>
              </div>
              <div class="project-info-item">
                <div class="info-item">
                  <div class="item-name">工程类型：</div>
                  <div class="item-content project-width" :title="projectInfo.projectTypeName || ''">{{projectInfo.projectTypeName || "-"}}</div>
                </div>
                <div class="info-item">
                  <div class="item-name">建筑面积：</div>
                  <div class="item-content project-width" :title="projectInfo.buildingArea ? projectInfo.buildingArea + '㎡' : ''">
                    {{projectInfo.buildingArea || "-"}}
                    <span v-if="projectInfo.buildingArea || projectInfo.buildingArea == '0' ">㎡</span>
                  </div>
                </div>
              </div>
              <div class="project-info-item">
                <div class="info-item company-list-width">
                  <div class="item-name">施工单位：</div>
                  <div class="item-content company-content-width" :title="projectInfo.corpNameLi">{{projectInfo.corpNameLi || "-"}}</div>
                </div>
              </div>
              <div class="project-info-item">
                <div class="info-item company-list-width">
                  <div class="item-name">工程地点：</div>
                  <div class="item-content company-content-width" :title="projectInfo.province + projectInfo.city + projectInfo.address">{{projectInfo.province}}{{projectInfo.city}}{{projectInfo.address}}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- 合同信息 -->
        <div class="info-panel" style="margin-top: 8px;">
          <PanelTitle title="合同信息"></PanelTitle>
          <div class="info-panel-content">
            <div class="form-inline-item">
              <div>
                <el-form-item label="合同类型：" prop="contractType" class="fl min-width-form-190 contract-type">
                  <!--  -->
                  <el-select v-model="baseInfoForm.contractType" placeholder="请选择" @change="handleSubContractType();checkForm('all')" :disabled="!isEdit">
                    <el-option v-for="item in contractTypeOptions" :key="item.code" :label="item.value" :value="item.code" clearable></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item prop="secondLevelType" class="fl min-width-form-0 add-space contract-subtype" v-show="baseInfoForm.contractType == '0'">
                  <el-select v-model="baseInfoForm.secondLevelType" placeholder="请选择分类" :disabled="!isEdit">
                    <el-option v-for="item in subContractTypeOptions" :key="item.code" :label="item.value" :value="item.code" clearable></el-option>
                  </el-select>
                </el-form-item>
              </div>
              <el-form-item></el-form-item>
            </div>
            <el-row class="project-name" :gutter="20">
              <el-col :span="24">
                <el-form-item prop="contractNo" label="合同编号：" class="min-width-form-190 contract-name">
                  <el-input v-model.trim="baseInfoForm.contractNo" clearable placeholder="请输入本公司系统的合同编号" :disabled="!isEdit" maxlength="70"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <div class="form-inline-item" v-if="baseInfoForm.contractType.includes('1')">
              <div class="category-content">
                <el-form-item class="fl min-width-form-190" prop="levelTwo">
                  <span slot="label">品类：</span>
                  <template v-if="!isEdit && !isSearchLevelTwoCp">
                    <p class="other-category">其他品类</p>
                  </template>
                  <template v-else>
                    <el-cascader :disabled="!isEdit || (!!levelTwoConfig.length && baseInfoForm.contractType == '1,3')" v-model="baseInfoForm.levelTwo" :options="categoryOptions" :key="baseInfoForm.levelTwo[0] || 1" :props="{ expandTrigger: 'hover' }" @change="handleCategory();checkForm('levelTwo')" popper-class="pin-list" placeholder="请选择品类"></el-cascader>
                    <div class="el-form-item__error" v-if="errorRuleList['levelTwo']">{{errorRuleList['levelTwo']}}</div>
                  </template>
                </el-form-item>
                <el-form-item class="fl min-width-form-0 category-discribe">
                  <el-input v-model.trim="baseInfoForm.ownerPlName" clearable maxlength="38" :disabled="!isEdit" placeholder="填写自己企业系统对应的品类名称，限38字（非必填）"></el-input>
                </el-form-item>
              </div>
            </div>
            <el-row :gutter="20" class="project-name">
              <el-col :span="24">
                <el-form-item prop="contractName" label="合同名称：" class="min-width-form-190 contract-name resize-none">
                  <el-input :disabled="!isEdit" v-model.trim="baseInfoForm.contractName" clearable maxlength="200" placeholder="请输入合同名称" :autosize="{ minRows: 1, maxRows: 5}" type="textarea"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <div class="form-inline-item">
              <el-form-item :label="activeName('1')" prop="corpId" class="min-width-form-190">
                <el-select v-model="baseInfoForm.corpId" placeholder="请输入关键词搜索选择单位" clearable filterable remote :remote-method="remoteQuickCompanyMethod" @change="handleGetACompanyINfo" :disabled="!isEdit">
                  <el-option v-for="item in aUnitOptions" :key="item.code" :label="item.value" :value="item.code" clearable></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="合同签署时间：" prop="signingTm" class="min-width-form-185">
                <el-date-picker v-model="baseInfoForm.signingTm" type="date" placeholder="请选择时间" clearable value-format="yyyy-MM-dd" :disabled="!isEdit"></el-date-picker>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item :label="activeName('2')" prop="supplierId" class="min-width-form-190">
                <el-select v-model="baseInfoForm.supplierId" placeholder="请输入关键词搜索选择单位" autocomplete="false" clearable filterable remote :remote-method="remoteQuickSupplyMethod" @change="handleGetSupplyInfo" :disabled="!isEdit">
                  <el-option v-for="(item,index) in bUnitOptions" :key="item.code + index" :label="item.value" :value="item.trustCode"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item class="society-code min-width-form-185" required>
                <span slot="label"><span><span style="margin-right: 12px;">{{activeName('3').split(",")[0]}}</span><br><span>{{activeName('3').split(",")[1]}}</span></span><span class="fr" style="margin-top: -9px;">：</span></span>
                <!-- <span
                  slot="label"
                  class="society-code-slot society-required"
                  :class="{'society-double-required':baseInfoForm.contractType == '0'}"
                >
                  <span>
                    {{activeName('3').split(",")[0]}}
                    <br />
                    {{activeName('3').split(",")[1]}}
                  </span>
                  <span>：</span>
                </span> -->
                <!-- 应赵云和后台要求 改成 不管啥时候都不能编辑 -->
                <el-input v-model.trim="baseInfoForm.creditNo" clearable maxlength="18" placeholder="" @blur="checkForm('creditNo')" :disabled="true"></el-input>
                <div class="el-form-item__error" v-if="errorRuleList['creditNo']">{{errorRuleList['creditNo']}}</div>
              </el-form-item>
            </div>
            <div class="form-inline-item">
              <el-form-item label="合同价款(含税)：" prop="priceIncludingTax" class="min-width-form-190">
                <el-input v-model.trim="baseInfoForm.priceIncludingTax" clearable class="right_padding handle-close-20" :class="{familyAotu: !isEdit}" maxlength="15" placeholder="请输入金额" :disabled="!isEdit" @input="checkNum($event,baseInfoForm,'priceIncludingTax')" @blur="handleDelHeadZero('baseInfoForm','priceIncludingTax')"></el-input>
                <i class="unit">元</i>
              </el-form-item>
              <el-form-item label="税率：" prop="taxRate" class="min-width-form-185">
                <el-input v-model.trim="baseInfoForm.taxRate" clearable class="right_padding handle-close-20" maxlength="3" placeholder="请输入数字" :disabled="!isEdit" @input="checkTaxRate($event,baseInfoForm,'taxRate')" @blur="handleTaxRate('baseInfoForm','taxRate')"></el-input>
                <i class="unit">%</i>
              </el-form-item>
            </div>
          </div>
        </div>
        <!-- 合同附件 -->
        <div class="info-panel contract-file" style="margin-top: 8px;">
          <PanelTitle title="合同附件"></PanelTitle>
          <div class="info-panel-content">
            <div class="polite-note">温馨提示：附件可上传合同文本、商品清单等，格式不限。</div>
            <template v-if="showQuantities">
              <div class="other-title">
                <span>工程量清单</span>
                <DownloadAndUploadQuantities appName="TRD" v-if="isEdit" :hasDownloadFlg="false" fromId="quantities" :fileList="otherListQuantitlesCp" uploadType="62" @outputValue="handleUpFileResult"></DownloadAndUploadQuantities>
                <span class="f12 hand blue" @click="getOrderConfiguration()">下载模板</span>
              </div>

              <div class="files-list">
                <div v-if="otherListQuantitlesCp.length == 0" class="nodata">未上传附件！</div>
                <p v-for="(item, index) in otherListQuantitlesCp" :key="index" class="last-item">
                  {{item.attachName}}
                  <DownloadAndView downloadName="下载" viewName="预览" :hideRotate="false" :attachUrl="item.viewUrl || item.attachUrl" :attachName="item.attachName"></DownloadAndView>&nbsp;&nbsp;
                  <span class="hand blue" v-if="isEdit" @click="delOther(item)">删除</span>
                </p>
              </div>
            </template>
            <div class="other-title">
              <span>合同文本及其他附件</span>
              <DownloadAndUpload appName="TRD" v-if="isEdit" :hasDownloadFlg="false" fromId="other" :fileList="otherListEnclosureCp" uploadType="60" @outputValue="handleUpFileResult"></DownloadAndUpload>
              <span class="f12 hand blue" v-else-if="otherListEnclosureCp.length" @click="handleOtherDownload()">下载</span>
            </div>
            <div class="files-list">
              <div v-if="otherListEnclosureCp.length == 0" class="nodata">未上传附件！</div>
              <p v-for="(item, index) in otherListEnclosureCp" :key="index" class="last-item">
                {{item.attachName}}
                <DownloadAndView downloadName="下载" viewName="预览" :hideRotate="false" :attachUrl="item.viewUrl || item.attachUrl" :attachName="item.attachName"></DownloadAndView>&nbsp;&nbsp;
                <span class="hand blue" v-if="isEdit" @click="delOther(item)">删除</span>
              </p>
            </div>
          </div>
        </div>
      </el-form>

      <Loading :isLoading="isLoading"></Loading>
      <!-- 提交 -->
      <FixBottom>
        <div class="tc" v-show="isEdit">
          <el-button style="width: 120px;" type="primary" @click.native="submitContract('submit')" v-show="isCreated">创建合同</el-button>
          <el-button style="width: 120px;" type="primary" v-show="!isCreated" @click.native="submitContract('update')">提交合同</el-button>
          <!-- <el-button style="width: 120px;" @click.native="submitContract('restore')" v-show="isCreated">保存</el-button> -->
          <el-button style="width: 120px;" @click="handleClosePage">关闭</el-button>
        </div>
      </FixBottom>
    </div>
  </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import VPagenation from "@/components/base/Pagenation";
import { InterfaceService } from "@/services/api";
import { NumberUtil } from "@/utils/numberUtil";
import SearchBar from "@/components/SearchBar";
import Footer from "@/components/base/Footer";
import Header from "@/components/base/Header";
import Breadcrumb from "@/components/base/Breadcrumb";
import PanelTitle from "@/components/base/PanelTitle";
import FixBottom from "@/components/base/FixBottom";
import DownloadAndUpload from "@/components/base/DownloadAndUpload";
import DownloadAndUploadQuantities from "@/components/base/DownloadAndUpload";
import DownloadAndView from "@/components/order/DownloadAndView";
import PageSelect from "@/components/base/PageSelect";
import accountMixin from "@/mixins/account";

const baseInfoForm = {
  // projectName:"",
  contractType: "",
  levelTwo: [],
};
const baseInfoRules = {
  cprojId: [
    {
      required: true,
      message: "请选择工程",
      trigger: "change"
    }
  ],
  contractType: [
    {
      required: true,
      message: "请选择合同类型",
      trigger: "change"
    }
  ],
  contractNo: [
    {
      required: true,
      message: "请输入合同编号",
      trigger: "blur"
    }
  ],
  contractName: [
    {
      required: true,
      message: "请输入合同名称",
      trigger: "blur"
    }
  ],
  signingTm: [
    {
      required: true,
      message: "请选择合同签署时间",
      trigger: "change"
    }
  ],
  priceIncludingTax: [
    {
      required: true,
      message: "请输入合同价款(含税)",
      trigger: "blur"
    }
  ],
  taxRate: [
    {
      required: true,
      message: "请输入税率",
      trigger: "blur"
    }
  ],
  corpId: [
    {
      required: true,
      message: "请选择采购方(甲方)",
      trigger: "change"
    }
  ],
  supplierId: [
    {
      required: true,
      message: "请选择供应方(乙方)",
      trigger: "change"
    }
  ],
  levelTwo: [
    {
      required: true,
      message: "请选择品类",
      trigger: "change"
    }
  ]
};

export default {
  mixins: [accountMixin],
  components: {
    VPagenation,
    SearchBar,
    Footer,
    Header,
    Loading,
    Breadcrumb,
    PanelTitle,
    FixBottom,
    DownloadAndUpload,
    DownloadAndUploadQuantities,
    PageSelect,
    Loading,
    DownloadAndView
  },
  data() {
    return {
      breadcrumb: [], //面包屑
      baseInfoForm: Object.assign({}, baseInfoForm), //基本信息
      baseInfoRules: baseInfoRules,
      frastructureNameOptions: [], //工程名称列表
      projectInfo: "",
      contractTypeOptions: [], //合同类型
      subContractTypeOptions: [], //二级合同类型
      aUnitOptions: [], //甲方列表
      bUnitOptions: [], //乙方列表
      categoryOptions: [], //品类

      //图片上传
      otherList: [], //附件列表
      errorRuleList: {}, //报错提示
      instrConid: "", //详情id
      isCreated: true, //是否为创建
      isEdit: true, //是否可编辑
      pageName: "", //页面名称
      tagList: [], //shigong
      isLoading: false,
      pageInfo: {
        pageIndex: 1,
        pageSize: 10,
        pageTotal: 1
      },
      popSelectItem: {},
      isGetDetailData: false, //是否获取到了详情数据
      tempBillOfQuantities: {}, // 工程量清单模板
      showQuantities: [],
      levelTwoConfig: [],
    };
  },
  watch: {

  },

  computed: {
    role() {
      return this.$store.state.userInfo
        ? this.$store.state.userInfo.bs
        : 0;
    },
    otherListQuantitlesCp() {
      return this.otherList.filter((f, idx) => {
        if (f.fileType == '62') {
          this.$set(f, 'oIdx', idx)
          return true
        }
      }) || []
    },
    otherListEnclosureCp() {
      return this.otherList.filter((f, idx) => {
        if (f.fileType == '60') {
          this.$set(f, 'oIdx', idx)
          return true
        }
      }) || []
    },
    fileTypeIdCp() {
      return this.baseInfoForm.contractType == '1,3' ? 'lea' : this.baseInfoForm.contractType == '1,2' ? 'mat' : this.baseInfoForm.secondLevelType == 1 ? 'lab' : 'sub'
    },
    // 判断品类是否都能找打 找到返回true
    isSearchLevelTwoCp() {
      return this.baseInfoForm && this.baseInfoForm.levelTwo && this.baseInfoForm.levelTwo.every && this.baseInfoForm.levelTwo.every(e => {
        return this.categoryOptions.some(s => {
          if (s.value == e) {
            return s.value == e
          }
          // 未找到继续往下
          if (s.children && s.children.length) {
            return s.children.some(sChild => sChild.value == e)
          }
        })
      })
    },
  },
  methods: {
    searchBarType() { },
    outputPointNotice() { },
    selectCurrentChange(ev) {
      this.pageInfo = ev || {};
      this.getFrastructureList(true);
    },
    handlePageSelectChange() {
      this.handleChoseProject(this.baseInfoForm.cprojId);
    },
    //提交
    submitContract(type) {
      /* 删除必要的校验 */
      if (this.baseInfoForm.contractType.includes("1")) {
        //材料合同
        delete this.baseInfoRules["secondLevelType"]; //删除二级合同类型的校验
      } else if (this.baseInfoForm.contractType == "0") {
        //劳务合同
        this.$set(this.baseInfoForm, "levelTwo", "");
        this.$set(this.errorRuleList, "levelTwo", ""); //删除品类的校验
      }
      //附件为非必填项
      let fileList = [];
      console.log(this.otherList);
      if (this.otherList.length > 0) {
        this.otherList.forEach(el => {
          let objFile = {};
          objFile.ossFilePath = el.filesUrl;
          objFile.fileType = el.fileType || '60';
          if (el.ossFileId) {
            objFile.ossFileId = el.ossFileId;
          }
          fileList.push(objFile);
        });
      }
      let params = this.$clone(this.baseInfoForm) || {};
      params.ossFileRefList = fileList || [];
      //提交
      this.checkForm("all");
      let isError = false;
      for (let i in this.errorRuleList) {
        if (this.errorRuleList[i]) {
          isError = true;
        }
      }

      try {
        // 设置品类中文名称
        const findItem = this.categoryOptions && this.categoryOptions.find(f => f.value == params.levelTwo[0]) || {}
        params.categoryOneName = findItem.label || ''
        this.categoryOptions && this.categoryOptions.some(s => s.children && s.children.some(sChild => (sChild.value == params.levelTwo[1] && (params.categoryTwoName = sChild.label || ''))))
      } catch (error) {
        console.log("tryCatch-设置品类中文名称: ", error);
      }

      // 如果合同类型：有多个 进行拆分 一二级
      if (params.contractType.includes(',')) {
        const tempArr = params.contractType.split(',') || []
        params.contractType = tempArr[0] || ''
        params.secondLevelType = tempArr[1] || ''
      }
      console.log(params);
      this.$refs.baseInfoForm.validate((Leasevalid, object) => {
        console.log(object)
        if (Leasevalid && !isError) {
          if (type == "submit") {
            this.$confirm(
              "请检查填写的合同信息内容，确认无误后点击【确认创建合同】按钮即可。",
              "确认创建合同",
              {
                cancelButtonClass: "btn-custom-cancel",
                confirmButtonClass: "btn-custom-confirm",
                center: true,
                confirmButtonText: "确认创建合同",
                cancelButtonText: "取消",
                type: "warning"
              }
            )
              .then(() => {
                this.$nextTick(() => {
                  this.addContract(params, type);
                });
              })
              .catch(() => { });
          } else if (type == "restore") {
            //保存
            this.$nextTick(() => {
              this.addContract(params, type);
            });
          } else if (type == "update") {
            this.$nextTick(() => {
              this.updateContract(params);
            });
          }
        } else {
          return false;
        }
      });
    },
    //动态切换名称
    activeName(type) {
      let activeName = "";
      const flag = this.baseInfoForm && this.baseInfoForm.contractType && this.baseInfoForm.contractType.includes('1')
      if (type == "1") {
        flag ? (activeName = "采购方(甲方)：") : (activeName = "工程承包单位(甲方)：");
      }
      if (type == "2") {
        flag ? (activeName = "供应方(乙方)：") : (activeName = "专业(劳务)分包单位(乙方)：");
      }
      if (type == "3") {
        flag ? (activeName = "供应方(乙方),统一社会信用代码") : (activeName = "专业(劳务)分包单位(乙方),统一社会信用代码");
      }
      return activeName;
    },

    //详情接口 获取 反显 工程名称数据
    frastructureDetail() {
      return new Promise((resolve, reject) => {
        const params = {
          cprojId: this.baseInfoForm.cprojId
        };
        InterfaceService.frastructureDetail(
          params,
          data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              const projectInfo = data.respData.projectInfo || {},
                {
                  projectId: value = "",
                  projectName: label = ""
                } = projectInfo;

              this.popSelectItem = Object.assign({ value, label }, projectInfo);
              console.log(this.popSelectItem, "-selectItem");
              if (this.popSelectItem && JSON.stringify(this.popSelectItem) != "{}") {
                this.$set(this.popSelectItem, "province", this.popSelectItem.provinceName)
                this.$set(this.popSelectItem, "city", this.popSelectItem.cityName)
                this.$set(this, "projectInfo", this.popSelectItem);
                if (this.projectInfo.corpNameLi) {
                  let corpNameLi = this.projectInfo.corpNameLi;
                  if (corpNameLi.indexOf(",") != -1) {
                    corpNameLi = corpNameLi.replace(/\,/g, "；") + "；";
                    this.$set(this.projectInfo, "corpNameLi", corpNameLi)
                  }
                }
              }
            } else {
              this.$message.error(data.respData && data.respData.respMsg);
            }
            resolve(data);
          },
          data => {
            reject(data);
          },
          data => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      });
    },

    //过滤数字
    checkNum(value, item, type, negative) {
      if (negative) {
        // 负数
        value = value.replace(/[^\d.-]/g, ""); //清除"数字"和"."以外的字符
      } else {
        value = value.replace(/[^\d.]/g, ""); //清除"数字"和"."以外的字符
      }
      value = value.replace(/^\./g, ""); //验证第一个字符是数字
      value = value.replace(/\.{2,}/g, "."); //只保留第一个, 清除多余的
      // value = value.replace(/-{2,}/g,""); //只保留第一个, 清除多余的
      if (value.length > 1 && value[value.length - 1] == "-") {
        value = value.substring(0, value.length - 1);
      }
      value = value
        .replace(".", "$#$")
        .replace(/\./g, "")
        .replace("$#$", ".");
      value = value.replace(/^(\-)*(\d+)\.(\d\d).*$/, "$1$2.$3"); //控制可输入的小数

      if (
        value.length > 1 &&
        Number(value) == 0 &&
        value != "0." &&
        value != "0.0"
      ) {
        value = "";
      }
      item[type] = value;
    },
    checkTaxRate(value, item, type, negative) {
      if (negative) {
        // 负数
        value = value.replace(/[^\d.-]/g, ""); //清除"数字"和"."以外的字符
      } else {
        value = value.replace(/[^\d]/g, ""); //清除"数字"和"."以外的字符
      }
      item[type] = value;
    },
    handleDelHeadZero(model, key) {
      if (this[model][key] && this[model][key] != 0) {
        this.$set(this[model], key, Number(this[model][key]));
        return;
      }
      if (this[model][key] == 0) {
        this.$set(this[model], key, "");
        return;
      }
    },
    handleTaxRate(model, key) {
      if (this[model][key]) {
        if (this[model][key] == 0 || this[model][key] >= 100) {
          this.$set(this[model], key, "");
        }
      }
    },
    // 获取其他附件数据
    handleUpFileResult(e) {
      const { attachPath, attachName, attachUrl, uploadType } = e;
      // 工程量清单 直接替换
      if (e.uploadType == '62') {
        const result = this.otherList.some((s, sIdx) => {
          if (s.fileType == '62') {
            this.otherList.splice(sIdx, 1, {
              attachName: attachName,
              attachUrl: attachUrl,
              filesUrl: attachPath,
              fileTypeId: "otherFile",
              fileType: uploadType
            })
            return true
          }
        })
        if (result) {
          return
        }
      }
      this.otherList.push({
        attachName: attachName,
        attachUrl: attachUrl,
        filesUrl: attachPath,
        fileTypeId: "otherFile",
        fileType: uploadType
      });
      console.log("this.otherList", this.otherList);
    },

    getOrderConfiguration() {
      return new Promise(resolve => {
        // sub - 专业/分包
        // lea - 租赁
        // mat - 材料
        // lab - 劳务
        if (this.baseInfoForm.contractType == 0 && !this.baseInfoForm.secondLevelType) {
          this.$message.error('请先选择合同类型！')
          return
        }
        const params = {
          businessType: 'QUANTITIES',
          fileTypeId: this.fileTypeIdCp
        };
        InterfaceService.getOrderConfiguration(params, data => {
          let res = data.respData;
          if (res.respCode === "0000") {
            const uploadFileList = res.uploadFileList || [],
              item = uploadFileList.find(f => f.fileTypeId == this.fileTypeIdCp) || {}

            item.attachUrl && this.handleDownTemp({ name: item.templateFileName, url: item.attachUrl })
            resolve(uploadFileList)
          } else {
            this.$message.error(data.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },
    // 下载附件
    handleDownTemp(obj) {
      this.$download([{
        name: obj.name,
        url: obj.url
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },

    // 下载
    handleOtherDownload() {
      const fileInfoBeans = this.otherList.map(m => {
        return {
          archivePath: "其他附件/" + (m.attachName || ""),
          fileUrl: m.attachUrl
        };
      });
      let params = {
        fileInfoBeans,
        protocol: "https"
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl;
            InterfaceService.packageDownloadAsyn(
              url,
              data => {
                const files = [
                  {
                    name:
                      this.baseInfoForm &&
                      this.baseInfoForm.contractName + "其他附件.zip",
                    url: data
                  }
                ];
                this.$download(
                  files,
                  () => {
                    this.isLoading = true;
                  },
                  () => {
                    this.isLoading = false;
                  }
                ).then(() => {
                  this.$message.success("已下载");
                });
              },
              () => {
                this.$message.error(data.respData.respMsg);
              },
              () => {
                this.isLoading = true;
              },
              () => {
                this.isLoading = false;
              }
            );
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {
          this.$message.error(data.respData.respMsg);
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    //删除
    delOther(item) {
      this.otherList.splice(item.oIdx, 1);
    },
    //校验
    checkForm(key) {
      if (key == "creditNo" || key == "all") {
        let reg = this.$commonExpression("busiLicense"); //统一社会信用代码格式校验
        if (!this.baseInfoForm["creditNo"]) {
          if (this.baseInfoForm.contractType.includes('1')) {
            this.$set(
              this.errorRuleList,
              "creditNo",
              "请输入供应方(乙方)统一社会信用代码"
            );
          } else if (this.baseInfoForm.contractType == "0") {
            this.$set(
              this.errorRuleList,
              "creditNo",
              "请输入专业(劳务)分包单位(乙方)统一社会信用代码"
            );
          }
        } else if (!reg.test(this.baseInfoForm["creditNo"])) {
          this.$set(
            this.errorRuleList,
            "creditNo",
            "统一社会信用代码格式不正确"
          );
        } else {
          this.$set(this.errorRuleList, "creditNo", "");
        }
      }
      if (
        (key == "levelTwo" || key == "all") &&
        this.baseInfoForm.contractType.includes('1')
      ) {
        if (!this.baseInfoForm["levelTwo"]) {
          this.$set(this.errorRuleList, "levelTwo", "请选择品类");
        } else {
          this.$set(this.errorRuleList, "levelTwo", "");
        }
      }
    },
    //添加合同
    addContract(params, type) {
      type == "submit" ? (params.isDraft = "0") : (params.isDraft = "1");
      // if(!params.doubleCorpId){
      //   params.doubleCorpId = "empty"
      // }
      let supplierId = this.$clone(params.doubleCorpId);
      if (supplierId || supplierId == "0") {
        params.supplierId = this.$clone(supplierId);
      } else {
        params.supplierId = "";
      }
      delete params.doubleCorpId;
      // 品类问题修改
      if (params.contractType == "1") {
        params.levelTwo = this.$clone(params.doubleLevelTwo);
        delete params.doubleLevelTwo;
      } else {
        params.levelTwo = "";
      }
      console.log(params);
      InterfaceService.createContract(
        params,
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            if (type == "submit") {
              this.$router.push({
                path: "/resultsFeedback",
                query: {
                  type: "bigInfrastructureContract",
                  orderNo: data.respData.instrConid,
                  projectName: params.contractName
                }
              });
            } else if (type == "restore") {
              this.$message.success("保存成功");
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },

    // 远程搜索 程列表
    getCprojDataList(value) {
      this.getFrastructureList(false, value)
    },

    /**
     * 获取工程列表
     * @param isPage: 是否分页触发 默认false
     */
    getFrastructureList(isPage, projectName = '') {
      const { pageIndex = 1, pageSize = 10 } = this.pageInfo;
      let params = {
        pageIndex,
        pageSize,
        projectName,
        projectType: ""
      };
      InterfaceService.frastructureList(
        params,
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let dataList = data.respData.projectInfoList || [];
            this.pageInfo.pageTotal = data.respData.totalCount || 1;
            if (dataList.length > 0) {
              this.frastructureNameOptions = data.respData.projectInfoList;
              this.frastructureNameOptions.forEach(el => {
                // 组件传参 初始化
                el.value = el.cprojId;
                el.label = el.projectName;
                if (el.corpNameLi) {
                  if (el.corpNameLi.indexOf(",") != -1) {
                    el.corpNameLi = el.corpNameLi.replace(/\,/g, "；") + "；";
                  }
                }
              });
            } else {
              this.frastructureNameOptions = [];
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
          !isPage && this.getContractTypeList(); //合同类型接口
        },
        data => { },
        () => {
          // this.isLoading = true;
        },
        () => {
          // this.isLoading = false;
        }
      );
    },
    //工程选择
    handleChoseProject(val) {
      if (val) {
        let currentVal = "";
        this.frastructureNameOptions.forEach((el, index) => {
          if (el.value == val) {
            currentVal = el;
          }
        });
        // 如果 在列表 没找到 (有可能其他页数据), 再详情返回数据查找
        if (!currentVal) {
          currentVal =
            (this.popSelectItem.value == val && this.popSelectItem) || {};
        }
        this.$set(this, "projectInfo", currentVal);
      } else {
        this.$set(this, "projectInfo", "");
      }
    },
    //对二级的校验
    handleSubContractType() {
      this.$set(this.baseInfoForm, "secondLevelType", ""); //清空二级合同类型
      delete this.baseInfoRules["corpId"];
      delete this.baseInfoRules["supplierId"];
      delete this.baseInfoRules["secondLevelType"];
      //清空品类名称 和 说明
      this.checkWordChange();
      //情况品类数据
      this.$set(this.baseInfoForm, "levelTwo", ""); //品类数据
      this.$set(this.baseInfoForm, "doubleLevelTwo", "");
      this.$set(this.baseInfoForm, "ownerPlName", "");

      this.$set(this.baseInfoForm, "corpId", ""); //甲方数据
      this.$set(this.baseInfoForm, "corpName", "");

      this.$set(this.baseInfoForm, "supplierId", ""); //乙方数据
      this.$set(this.baseInfoForm, "supplerName", "");
      this.$set(this.baseInfoForm, "doubleCorpId", "");
      this.$set(this.baseInfoForm, "creditNo", "");

      // 设置租赁品类
      if (this.baseInfoForm.contractType == '1,3') {
        this.baseInfoForm.levelTwo = this.levelTwoConfig || []
        this.handleCategory()
      }
      this.$forceUpdate();
    },
    //校验文本变动
    checkWordChange() {
      if (this.baseInfoForm.contractType.includes("1")) {
        this.$set(this.baseInfoRules, "corpId", [
          {
            required: true,
            message: "请选择采购方(甲方)",
            trigger: "change"
          }
        ]);
        this.$set(this.baseInfoRules, "supplierId", [
          {
            required: true,
            message: "请选择供应方(乙方)",
            trigger: "change"
          }
        ]);
      } else if (this.baseInfoForm.contractType == "0") {
        //专业分包合同
        this.baseInfoRules["secondLevelType"] = [
          {
            required: true,
            message: "请选择分类",
            trigger: "change"
          }
        ];
        this.$set(this.baseInfoRules, "corpId", [
          {
            required: true,
            message: "请选择工程承包单位(甲方)",
            trigger: "change"
          }
        ]);
        this.$set(this.baseInfoRules, "supplierId", [
          {
            required: true,
            message: "请选择专业(劳务)分包单位(乙方)",
            trigger: "change"
          }
        ]);
      }
    },
    //施工单位查询
    remoteQuickCompanyMethod(query) {
      query.replace(/\s*/g, "").length && this.searchCompany(query);
    },
    //查询
    searchCompany(query) {
      const params = {
        searchKey: query,
        pageIndex: 1,
        pageSize: 10,
        tagList: this.tagList
      };
      if (params.tagList.length == 0) {
        delete params.tagList;
      }
      InterfaceService.frastructureSearchCompany(
        params,
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let dataList = data.respData.corpList || [];
            if (dataList.length > 0) {
              this.aUnitOptions = dataList.map(el => {
                return {
                  code: el.corpId,
                  value: el.corpName
                };
              });
              console.log("this.aUnitOptions", this.aUnitOptions);
            } else {
              this.aUnitOptions = [];
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    //乙方公司名称搜索
    remoteQuickSupplyMethod(query) {
      if (query) {
        query = query.trim();
      }
      if (query.length >= 2) {
        this.searchSupplyCompany(query);
      } else {
        this.bUnitOptions = [];
      }
    },
    searchSupplyCompany(query) {
      const params = { keyWord: query };
      InterfaceService.getSupplierMedicalChecklist(
        params,
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let dataList = data.respData.storageInfo || [];
            if (dataList.length > 0) {
              this.bUnitOptions = data.respData.storageInfo.map((el, index) => {
                return {
                  code: index,
                  value: el.supplierName || "",
                  corpId: el.corpId || "empty",
                  trustCode: el.trustCode || ""
                };
              });
              console.log("this.bUnitOptions", this.bUnitOptions);
            } else {
              this.bUnitOptions = [];
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    //合同类型接口
    getContractTypeList() {
      let params = {
        appName: "TRANS",
        groupIds: ["LVDI_DJJ_CONTRACT_TYPE", "LVDI_DJJ_SUB_CONTRACT_TYPE", "LVDI_DJJ_LEA_CONTRACT_CATEGORY", "VIEW_SHOW"]
      };
      InterfaceService.getPaymentMethod(
        params,
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            if (data.respData.configEntityListMap) {
              this.contractTypeOptions =
                data.respData.configEntityListMap["LVDI_DJJ_CONTRACT_TYPE"] ||
                [];
              this.subContractTypeOptions =
                data.respData.configEntityListMap[
                "LVDI_DJJ_SUB_CONTRACT_TYPE"
                ] || [];
              const VIEW_SHOW = data.respData.configEntityListMap["VIEW_SHOW"] || [],
                UPLOAD_QUANTITIES = VIEW_SHOW.find(f => f.code == 'UPLOAD_QUANTITIES') || {},
                LVDI_DJJ_LEA_CONTRACT_CATEGORY = data.respData.configEntityListMap["LVDI_DJJ_LEA_CONTRACT_CATEGORY"] || []

              this.showQuantities = UPLOAD_QUANTITIES.value == "ON"
              this.levelTwoConfig = LVDI_DJJ_LEA_CONTRACT_CATEGORY[0] && LVDI_DJJ_LEA_CONTRACT_CATEGORY[0].code && LVDI_DJJ_LEA_CONTRACT_CATEGORY[0].code.split(',') || []
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
          // contractType = '1,3'
          this.$set(this.baseInfoForm, "contractType", "1,3");
          this.getCategoryData(); //获取品类列表
        },
        data => { },
        () => {
          //this.isLoading = true;
        },
        () => {
          //this.isLoading = false;
        }
      );
    },
    //获取品类列表
    getCategoryData(levelTwo) {
      let params = {
        plName: "",
        pageIndex: 1,
        pageSize: 50
      };
      InterfaceService.getCategoryData(
        params,
        async data => {
          if (this.instrConid) {
            await this.getDetail();
          }
          if (data && data.respData && data.respData.respCode === "0000") {
            this.categoryOptions = data.respData.materInfoList || [];
            if (this.baseInfoForm.contractType == '1,3') {
              this.baseInfoForm.levelTwo = this.levelTwoConfig || []
              this.handleCategory()
            }
            // 如果是编辑状态 且 未找到该品类 重置品类 且 配置里面没查到值
            if (this.isEdit && !this.isSearchLevelTwoCp && !(this.levelTwoConfig && this.levelTwoConfig.length)) {
              this.baseInfoForm.levelTwo = []
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          //this.isLoading = true;
        },
        () => {
          //this.isLoading = false;
        }
      );
    },
    //获取甲方公司信息
    handleGetACompanyINfo(val) {
      if (!val) {
        return;
      }
      this.aUnitOptions.forEach(el => {
        if (el.code == val) {
          this.$set(this.baseInfoForm, "corpName", el.value);
        }
      });
      console.log(this.baseInfoForm.corpName);
    },
    //获取乙方公司
    handleGetSupplyInfo(val) {
      if (!val && val != "0") {
        this.$set(this.baseInfoForm, "supplerName", "");
        this.$set(this.baseInfoForm, "doubleCorpId", "");
        this.$set(this.baseInfoForm, "creditNo", "");
        return;
      }
      this.bUnitOptions.forEach(el => {
        if (el.trustCode == val) {
          this.$set(this.baseInfoForm, "supplerName", el.value);
          this.$set(this.baseInfoForm, "doubleCorpId", el.corpId);
          this.$set(this.baseInfoForm, "creditNo", el.trustCode);
        }
      });
      this.checkForm("creditNo");
    },
    //获取详情接口
    getDetail() {
      return new Promise(resolve => {
        let params = {
          instrConid: this.instrConid
        };
        InterfaceService.contractDetail(
          params,
          async data => {
            this.isGetDetailData = true;
            if (data && data.respData && data.respData.respCode === "0000") {
              this.baseInfoForm = data.respData.concatInfo || {};
              try {
                await this.frastructureDetail();
              } catch (error) {
                console.log("tryCatch-contractDetail: ", error);
              }
              console.log(this.categoryOptions)
              /* 工程信息 */
              // if (
              //   this.frastructureNameOptions &&
              //   this.frastructureNameOptions.length > 0 &&
              //   this.baseInfoForm.cprojId
              // ) {
              //   this.handleChoseProject(this.baseInfoForm.cprojId);
              // }
              /* 合同类型 - 组装 */
              // 如果是1开头的 需和二级组装成 1,2 / 1,3
              if (this.baseInfoForm && this.baseInfoForm.contractType == '1') {
                this.baseInfoForm.contractType = `${this.baseInfoForm.contractType},${this.baseInfoForm.secondLevelType}`
              } else {
                this.baseInfoForm.contractType = (this.baseInfoForm && this.baseInfoForm.contractType && this.baseInfoForm.contractType.toString()) || "";
              }
              if (
                this.baseInfoForm.secondLevelType ||
                this.baseInfoForm.secondLevelType == "0"
              ) {
                let secondLevelType = this.baseInfoForm.secondLevelType.toString();
                this.$set(this.baseInfoForm, "secondLevelType", secondLevelType);
              }
              /* 甲方列表 */
              let aUnitOptions = [
                {
                  code: this.baseInfoForm.corpId || "",
                  value: this.baseInfoForm.corpName || ""
                }
              ];
              this.$set(this, "aUnitOptions", aUnitOptions);
              /* 乙方列表 */
              let bUnitOptions = [];
              bUnitOptions = [
                {
                  // code: this.baseInfoForm.supplierId == "empty"? "empty" : this.baseInfoForm.creditNo,
                  code: this.baseInfoForm.supplierId,
                  value: this.baseInfoForm.supplierName || "",
                  // 赋值为corpId导致 未重新搜索 选择供应方(乙方)时  取的supplierId为 甲方的 corpId
                  // corpId: this.baseInfoForm.corpId || "",
                  corpId: this.baseInfoForm.supplierId || "",
                  trustCode: this.baseInfoForm.creditNo || "",
                }
              ];

              this.$set(this, "bUnitOptions", bUnitOptions);
              this.$set(
                this.baseInfoForm,
                "supplerName",
                this.bUnitOptions[0].value
              );
              this.$set(
                this.baseInfoForm,
                "doubleCorpId",
                this.bUnitOptions[0].code
              );
              this.$set(
                this.baseInfoForm,
                "supplierId",
                this.bUnitOptions[0].trustCode
              );
              /* 金额 */
              if (!this.isEdit && !this.isCreated) {
                let priceIncludingTax = 0;
                priceIncludingTax = NumberUtil.formatMoney(
                  this.baseInfoForm.priceIncludingTax
                );
                this.$set(
                  this.baseInfoForm,
                  "priceIncludingTax",
                  priceIncludingTax
                );
              }
              /* 附件处理 */
              if (
                this.baseInfoForm.ossFileRefList &&
                this.baseInfoForm.ossFileRefList.length > 0
              ) {
                this.otherList = this.baseInfoForm.ossFileRefList.map(el => {
                  return {
                    ossFileId: el.ossFileId || "",
                    filesUrl: el.ossFilePath || "",
                    fileType: el.fileType || "",
                    attachName: decodeURIComponent(
                      el.ossFilePath
                        .split("?")[0]
                        .split("/")
                        .slice(-1)[0]
                    ),
                    attachUrl: el.ossFilePath || ""
                  };
                });
                console.log(this.otherList);
              }
              this.$nextTick(() => {
                /* 品类处理 */
                if (this.baseInfoForm.levelTwo) {
                  let levelTwo = [];
                  levelTwo[0] = this.baseInfoForm.levelTwo.split(",")[0];
                  levelTwo[1] = this.baseInfoForm.levelTwo.split(",")[1];
                  this.$set(
                    this.baseInfoForm,
                    "doubleLevelTwo",
                    this.baseInfoForm.levelTwo
                  );
                  this.$set(this.baseInfoForm, "levelTwo", levelTwo);
                } else {
                  this.$set(this.baseInfoForm, "levelTwo", []);
                }
                this.$forceUpdate();
              });
              // 校验文本
              this.checkWordChange();
              this.checkForm("all");
              resolve(true)
            } else {
              this.$message.error(data.respData.respMsg);
            }
          },
          data => { },
          () => {
            //this.isLoading = true;
          },
          () => {
            //this.isLoading = false;
          }
        );
      })
    },
    //关闭
    handleClosePage() {
      let tip = "";
      if (this.isCreated) {
        tip = "关闭本页后，该页面内容失效。";
      } else {
        tip = "关闭本页后，更改的内容不被更新。";
      }
      this.$confirm(tip, "确认关闭", {
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        confirmButtonText: "确认关闭",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          // this.$router.push({ path: "/bigInfrastructureCenter/ContractList" });
          this.$router.push({ path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/ContractList` });
        })
        .catch(() => { });
    },
    //品类
    handleCategory() {
      if (this.baseInfoForm.levelTwo) {
        let levelTwo =
          this.baseInfoForm.levelTwo[0] + "," + this.baseInfoForm.levelTwo[1];
        this.$set(this.baseInfoForm, "doubleLevelTwo", levelTwo);
      }
    },
    //修改合同
    updateContract(params) {
      this.$confirm(
        "请检查填写的合同信息内容，确认无误后点击【确认提交合同】按钮即可。",
        "确认提交合同",
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          confirmButtonText: "确认提交合同",
          cancelButtonText: "取消",
          type: "warning"
        }
      )
        .then(() => {
          params.isDraft = "0";
          let supplierId = this.$clone(params.doubleCorpId);
          if (supplierId || supplierId == "0") {
            params.supplierId = this.$clone(supplierId);
          } else {
            params.supplierId = "";
          }
          delete params.doubleCorpId;
          // 品类问题修改
          if (params.contractType == "1") {
            params.levelTwo = this.$clone(params.doubleLevelTwo);
            delete params.doubleLevelTwo;
          } else {
            params.levelTwo = "";
          }
          InterfaceService.createContract(params, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              this.$message.success("更改成功！");
              this.isEdit = false;
              this.isCreated = false;
              this.breadcrumb = [
                // { name: "管理中心", path: "/bigInfrastructureCenter/workbench" },
                { name: "管理中心", path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/workbench` },
                {
                  name: "合约管理-合同管理",
                  // path: "/bigInfrastructureCenter/ContractList"
                  path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/ContractList`
                },
                { name: "合同详情" }
              ];
              this.pageName = "合同详情";
              /* 金额修改 */
              let priceIncludingTax = 0;
              priceIncludingTax = NumberUtil.formatMoney(
                this.baseInfoForm.priceIncludingTax
              );
              this.$set(
                this.baseInfoForm,
                "priceIncludingTax",
                priceIncludingTax
              );
            } else {
              this.$message.error(data.respData.respMsg);
            }
          });
        })
        .catch(() => { });
    },
    getTagList() {
      let tagList = [];
      if (this.$store.state.userInfo) {
        tagList = this.$store.state.userInfo.corpTags || [];
        if (tagList.length > 0) {
          tagList.map(el => {
            if (el.tagId) {
              this.tagList.push(el.tagId);
            }
          });
        }
      }
    }
  },
  mounted() {
    this.getFrastructureList(); //获取工程列表
    this.instrConid = this.$route.query.instrConid || "";
    let pageType = this.$route.query.pageType || "";
    if (this.$route.query.isEdit && this.$route.query.instrConid) {
      //编辑
      this.isEdit = true;
      this.isCreated = false;
      this.breadcrumb = [
        // { name: "管理中心", path: "/bigInfrastructureCenter/workbench" },
        { name: "管理中心", path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/workbench` },
        {
          name: "合约管理-合同管理",
          // path: "/bigInfrastructureCenter/ContractList"
          path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/ContractList`
        },
        { name: "合同编辑" }
      ];
      this.pageName = "合同编辑";
    } else if (this.$route.query.instrConid) {
      //详情
      this.isEdit = false;
      this.isCreated = false;
      this.breadcrumb = [
        // { name: "管理中心", path: "/bigInfrastructureCenter/workbench" },
        { name: "管理中心", path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/workbench` },
        {
          name: pageType === 'supplierDirectoryDetails' ? '供应商管理-供应商名录' : "合约管理-合同管理",
          // path: pageType === 'supplierDirectoryDetails' ? '/bigInfrastructureCenter/supplierDirectory' : "/bigInfrastructureCenter/ContractList"
          path: pageType === 'supplierDirectoryDetails' ? `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/supplierDirectory` : `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/ContractList`
        },
        { name: "合同详情" }
      ];
      this.pageName = "合同详情";
    } else {
      //创建
      this.isEdit = true;
      this.isCreated = true;
      if (pageType === 'bigfrastructIndex') {
        this.breadcrumb = [
          { name: "大基建", path: "/bigfrastructIndex" },
          { name: "上线入库" }
        ];
      } else {
        this.breadcrumb = [
          // { name: "管理中心", path: "/bigInfrastructureCenter/ContractList" },
          { name: "管理中心", path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/ContractList` },
          {
            name: "合约管理-合同管理",
            // path: "/bigInfrastructureCenter/ContractList"
            path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/ContractList`
          },
          { name: "上线入库" }
        ];
      }
      this.pageName = "上线入库";
    }
    this.getTagList();
  },
  destroyed() { },
  updated() { }
};
</script>

<style lang="scss" scoped>
/deep/ .el-form .el-col {
  height: 62px;
}

/deep/ .el-form .el-select {
  width: 100%;
}

.el-form-item.is-error input {
  border-color: #f56c6c;
}

p {
  margin-bottom: 20px;
}
a.link {
  display: inline-block;
  vertical-align: middle;
  padding: 0 10px;
  color: #0082ff;
}

.error-info {
  position: absolute;
  top: 100%;
  left: 0;
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
}

.attr-col {
  position: relative;
}

.error-attr-info {
  position: absolute;
  top: 100%;
  left: 10px;
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
}

.inner-container {
  margin-bottom: 100px;
  font-size: 14px;
}

.form-inline-item {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;
  position: relative;
  &.noFlex {
    flex-direction: column;
  }
  & > div {
    flex-shrink: 0;
  }

  /deep/ .el-select {
    width: 100%;
  }

  div .error-info {
    display: none;
  }
  div.is-error .error-info {
    display: block;
  }
  .familyAotu {
    /deep/ input {
      font-family: auto;
    }
  }
}

.form-inline-item.freight-item {
  justify-content: flex-start;
}

.sale-model-panel {
  div .error-info {
    display: none;
  }
  div.is-error .error-info {
    display: block;
  }
}

.form-item {
  position: relative;
  line-height: 40px;

  .float-right {
    position: absolute;
    top: 1px;
    right: 2px;
    bottom: 2px;
    padding: 0 10px;
    background: #fff;
  }

  input::-ms-clear {
    display: none;
  }
}

/deep/ .el-form-item__label {
  color: #909399;
}

.info-panel {
  margin-top: 30px;
}
.border-dashed {
  padding-top: 20px;
  border-top: 1px dashed #ccc;
}
/*.brand-other {*/
/*margin-top: 20px;*/
/*padding-left: 30px;*/
/*}*/

.info-panel-title {
  position: relative;
  border-left: 3px solid #000;
  margin: 10px 0;
  padding: 0 4px;
  padding-right: 0;
  font-weight: bold;
  color: rgb(41, 41, 41);

  i {
    font-size: 12px;
    color: rgb(143, 143, 143);
  }
  a {
    font-size: 12px;
    text-decoration: underline;
    color: #0082ff;
  }
  button {
    position: absolute;
    bottom: 0;
    right: 0;
  }
}

.info-panel-content {
  &.bottom {
    padding-bottom: 20px;
  }
  .frastructure-name {
    margin-bottom: 8px;
    border-bottom: 1px #eeeeee dashed;
    /deep/ .el-input input {
      width: 100%;
    }
  }
  /deep/ .el-input {
    input {
      height: 34px;
      width: 400px;
    }
  }
  /deep/ .el-date-editor.el-input,
  .el-date-editor.el-input__inner {
    width: 400px;
  }
  .w100 {
    /deep/ input {
      width: 100%;
    }
  }
}

.info-detail {
  position: relative;
  z-index: 1;
  max-height: 800px;
  // min-height: 500px;
}

.info-detail-img {
  padding: 10px 30px;
  border: 1px solid #e0e0e0;
  border-top: none;
  line-height: 30px;
  background: #f5f5f5;

  button {
    float: right;
    margin: 0 5px;
  }
}

.model-table {
  thead td {
    text-align: center;
  }

  td {
    padding: 10px;
    padding-left: 0;
  }
}

.model-content {
  margin-bottom: 1px;
  table {
    table-layout: fixed;
    thead {
      td {
        text-align: left;
        padding: 7px 10px;
      }
      background: #f5f5f5;
      font-size: 14px;
      color: #888;
    }
    tbody {
      tr {
        td {
          text-align: left;
          color: #444;
          padding: 4px 5px;
          /deep/ .right_padding {
            .suffix {
              line-height: 34px;
            }
          }
          &:first-child {
            color: #888;
          }
          &:last-child {
            padding-right: 0;
          }
          /deep/ .el-input {
            input {
              height: 34px;
            }
          }
        }
      }
    }
  }
}

.model-panel.bottom {
  padding-bottom: 0;
  line-height: 40px;
}
.model-panel.bottom:last-child {
  padding-bottom: 20px;
}

.model-panel.bottom.expand {
  margin-top: 1px;
  padding-bottom: 20px;
}

.model-head {
  line-height: 40px;
  color: #909399;
  span {
    margin-right: 5px;
  }
}
/deep/ .el-input.error {
  border: 1px solid #f00;
}

.model-expand {
  float: right;
  color: #0082ff;
}

.sale-model-panel {
  margin-top: 20px;
  padding: 20px 20px 0;
  border-top: 1px solid rgb(230, 229, 229);
}

.tooltip-name {
  color: #ccc;
  &:hover {
    color: #444444;
  }
}

.fix-bottom {
  position: fixed;
  bottom: 0;
  left: 0;
  z-index: 1;
  width: 100%;
  padding: 20px;
  text-align: center;
  background: rgba(79, 82, 90, 0.8);

  button {
    width: 150px;
  }
}

/deep/ .v-note-wrapper.fullscreen {
  max-height: inherit;
}

/deep/ .v-note-wrapper {
  em {
    font-style: italic;
  }

  sup {
    vertical-align: super;
    font-size: smaller;
  }

  sub {
    vertical-align: sub;
    font-size: smaller;
  }

  ul {
    list-style-type: disc;
  }

  ol {
    list-style-type: decimal;
  }
}

/deep/ .v-note-wrapper .v-note-read-model.show {
  width: 930px;
  padding: 0;
}

/deep/ .v-note-img-wrapper {
  z-index: 1;
}

.freight-price {
  margin: 0 10px;
  font-size: 15px;
  font-weight: bold;
}

.alert-reject {
  margin-top: 20px;
  padding: 30px 20px;
  border: 1px solid red;
  border-radius: 0;
  color: #444;

  /deep/ .el-alert__title {
    font-size: 14px;
    font-weight: bold;
  }
}

.float-price-content {
  position: relative;
  margin-bottom: 2px;

  /deep/ .el-input {
    width: 200px;
  }

  label {
    color: #909399;
  }

  .tip {
    color: #aaa;
  }

  .error-attr-info {
    left: 100px;
    bottom: 2px;
    top: auto;
  }
}

.form-float-price {
  padding-bottom: 22px;

  /deep/ .el-input {
    width: 990px;
  }

  .tip {
    color: #aaa;
  }
}

.brand-desc {
  margin-bottom: 22px;
  line-height: 40px;
  margin-left: -150px;
}
.brandNameNotice {
  color: #888;
  font-size: 12px;
  line-height: 20px;
  margin-top: 12px;
  white-space: pre;
}
/deep/ .right_padding {
  .el-input__inner {
    padding-right: 30px;
    height: 32px;
    line-height: 32px;
  }
  .suffix {
    width: 68px;
    text-align: right;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    color: #444;
    margin-right: 4px;
    line-height: 40px;
  }
}
.required {
  &::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
.multiple-select {
  .el-select-dropdown__item {
    padding: 0 10px;
  }
  .el-select-dropdown__item {
    color: #444 !important;
    font-weight: normal;
  }
  &.el-select-dropdown.is-multiple .el-select-dropdown__item.selected {
    color: #fff !important;
  }
  &.el-select-dropdown.is-multiple .el-select-dropdown__item.is-disabled {
    background: #fff !important;
    color: #444 !important;
  }
  &.el-select-dropdown.is-multiple .el-select-dropdown__item.selected::after {
    display: none !important;
  }
  .text {
    position: absolute;
    left: 0;
    z-index: 13;
    padding-left: 35px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: calc(100% -34px);
    line-height: inherit;
  }
}
/deep/ .multiple-tag {
  .el-tag.el-tag--info {
    // background-color: #c99f4f;
    border-color: #c99f4f;
    color: #fff;
    border-radius: 0;
    font-size: 12px;
    &:first-child {
      .el-tag__close {
        display: none;
      }
    }
    .el-tag__close {
      color: #fff;
      // background-color: #c99f4f;
    }
  }
}
/deep/ .el-checkbox__inner {
  background: #fff;
}
.project-info {
  padding: 10px 0px 30px 0px;
  .project-info-item {
    width: 100%;
    display: -webkit-box;
    display: -webkit-flex;
    display: -moz-box;
    display: -ms-flexbox;
    display: flex;
    margin-top: 10px;
    .info-item {
      max-width: 595px;
      display: -webkit-box;
      display: -webkit-flex;
      display: -moz-box;
      display: -ms-flexbox;
      display: flex;
      flex: 1;
      flex-shrink: 0;
      height: 17px;
      font-size: 12px;
      font-family: PingFang SC;
      font-weight: 400;
      line-height: 17px;
      .item-name {
        color: #888;
        padding-right: 10px;
        width: 70px;
      }
      .special-width {
        width: 94px;
      }
      .spcial-content {
        width: calc(100% - 104px);
      }
      .project-width {
        width: calc(100% - 80px);
      }
      .company-content-width {
        width: calc(100% - 80px);
      }
      .item-content {
        color: #444;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
    .company-list-width {
      max-width: 1190px !important;
    }
  }
}
// .info-panel-content{
//   /deep/ .el-input input,.el-select,.el-date-editor {
//     width: 100%;
//   }
// }
.min-width-form-190 {
  /deep/ .el-form-item__label {
    width: 190px !important;
  }
  /deep/ .el-form-item__content {
    margin-left: 190px !important;
  }
}
.min-width-form-0 {
  /deep/ .el-form-item__label {
    width: 0px !important;
  }
  /deep/ .el-form-item__content {
    margin-left: 0px !important;
  }
}
.min-width-form-185 {
  /deep/ .el-form-item__label {
    width: 185px !important;
  }
  /deep/ .el-form-item__content {
    margin-left: 185px !important;
  }
}
.society-code {
  position: relative;
  /deep/ .el-form-item__label {
    // width: 155px !important;
    line-height: 20px;
  }
  .society-code-slot {
    display: -webkit-box;
    display: -webkit-flex;
    display: -moz-box;
    display: -ms-flexbox;
    display: flex;
    align-items: center;
    justify-content: flex-end;
  }
}
.society-required {
  &::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
    position: absolute;
    left: 80px;
    top: 0px;
  }
}
.society-double-required {
  &::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
    position: absolute;
    left: -3px;
    top: 0px;
  }
}
.add-space {
  margin-left: 10px;
}
.handle-close-20 {
  /deep/ .el-input__suffix {
    right: 20px;
  }
}
.unit {
  position: absolute;
  right: 8px;
  top: 50%;
  height: 36px;
  line-height: 36px;
  // font-size: 12px;
  color: #444;
  margin-top: -18px;
}
.polite-note {
  font-size: 12px;
  font-family: PingFang SC;
  font-weight: 400;
  line-height: 30px;
  color: #444444;
  height: 30px;
  background: #fffcf0;
  border: 1px solid #fae2a5;
  padding-left: 10px;
}
.contract-file {
  padding-bottom: 40px;
}
.file-upload {
  display: -webkit-box;
  display: -webkit-flex;
  display: -moz-box;
  display: -ms-flexbox;
  display: flex;
  flex-direction: column;
  .file-name {
    // width: 100%;
    height: 40px;
    font-size: 14px;
    font-family: PingFang SC;
    font-weight: 400;
    line-height: 40px;
    color: #444444;
  }
  .upload-select-file {
    position: relative;
    .select-file {
      width: 60px;
      height: 40px;
      float: left;
      position: absolute;
      cursor: pointer;
    }
    .other-file-upload {
      // border: 1px dashed #0082ff;
      color: #0082ff;
      height: 40px;
      line-height: 40px;
      text-align: center;
      float: left;
      padding: 0 10px;
      margin-right: 10px;
      cursor: pointer;
      position: absolute;
      left: 0;
      top: 0;
      background: #fff;
      width: 60px;
      pointer-events: none;
    }
  }
}
.file-list-box {
  padding: 10px 0 20px;
  li {
    position: relative;
    color: #666;
    line-height: 30px;
    // width: 200px;
    height: 30px;

    &:hover {
      background: #f5f5f5;
    }
    span {
      color: red;
      position: absolute;
      width: 10px;
      height: 30px;
      line-height: 30px;
      top: 0px;
      right: 10px;
      cursor: pointer;
    }
  }
}
.contract-type /deep/ .el-select {
  width: 196px;
  .el-input input {
    width: 100% !important;
  }
}
.contract-subtype /deep/ .el-select {
  width: 194px;
  .el-input input {
    width: 100% !important;
  }
}
.category-discribe {
  width: calc(100% - 590px);
  padding-left: 10px;
  /deep/ .el-input input {
    width: 100% !important;
  }
}
.category-content {
  width: 100%;
  /deep/ .el-input.is-disabled .el-input__icon {
    display: none;
  }
  .other-category {
    border: 1px solid #dddddd;
    color: #606266;
    text-overflow: ellipsis;
    padding: 0px 14px;
    cursor: not-allowed;
    margin-bottom: 0;
    font-size: 14px;
    height: 34px;
    line-height: 34px;
    background-color: #f5f7fa;
    margin-top: 3px;
    width: 400px;
  }
}
.contract-name /deep/ .el-input input {
  width: 100% !important;
}
.other-title {
  margin: 15px 0px 6px 0px;
  height: 20px;
  font-size: 14px;
  font-weight: 400;
  line-height: 20px;
  color: #444444;
}
.category-required {
  &::before {
    content: "*";
    color: #f56c6c;
    margin-right: 0px;
  }
}
/deep/ .el-input.is-disabled .el-input__inner {
  background-color: #f5f7fa;
}
.files-list {
  border: 1px solid #dddddd;
  padding: 10px 0px 0px 10px;
  .last-item {
    margin-bottom: 10px;
  }
}
.nodata {
  width: 100%;
  background: #ffffff;
  font-size: 12px;
  font-weight: 400;
  padding-bottom: 10px;
  color: #bbbbbb;
}
.project-name {
  max-height: 100px;
  /deep/ .el-input input,
  .el-select,
  .el-date-editor {
    width: 100%;
  }
  > div {
    height: auto !important;
  }
}
/deep/ textarea::-webkit-input-placeholder {
  /* WebKit browsers */
  padding-top: 2px;
}
/deep/ textarea:-moz-placeholder {
  /* Mozilla Firefox 4 to 18 */
  padding-top: 2px;
}
/deep/ textarea::-moz-placeholder {
  /* Mozilla Firefox 19+ */
  padding-top: 2px;
}
/deep/ textarea::-ms-input-placeholder {
  /* Internet Explorer 10+ */
  padding-top: 2px;
}
/deep/ .el-textarea.is-disabled .el-textarea__inner {
  color: #606266;
}
</style>
