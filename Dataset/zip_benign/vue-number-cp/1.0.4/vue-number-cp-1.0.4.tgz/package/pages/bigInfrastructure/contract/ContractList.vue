<template>
  <div class="product">
    <!-- 工程列表 -->

    <PanelTitle :title="'全部合同'"></PanelTitle>
    <div class="clearfloat create-project">
      <el-button type="primary" class="fr small-btn" @click="handleCreateContract()">在线入库</el-button>
    </div>
    <!-- 查询条件 -->
    <div class="panel-content" :style="{'margin-bottom' : brokerRole ? '40px' : '35px'}">
      <el-form class="form" :model="form" size="small" label-width="75px">
        <el-row>
          <el-col :span="24">
            <el-form-item label="合同名称：">
              <el-input v-model.trim="form.contractName" placeholder="请输入合同关键词或合同编号" maxlength="50" clearable></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-form-item label="工程名称：">
              <el-input v-model.trim="form.projectName" placeholder="请输入关键词搜索工程" maxlength="50" clearable></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="甲方：">
              <!-- <el-select filterable style="width: 240px;" v-model="form.corpId" placeholder="请选择甲方" clearable>
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="(item,index) in corpIdList" :key="index" :label="item.value" :value="item.code"></el-option>
                </el-select> -->
              <el-input style="width: 240px;" v-model.trim="form.corpId" placeholder="请输入甲方名称" clearable maxlength="50"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="乙方：">
              <!-- purchaserCorpId -->
              <!-- <el-select filterable style="width: 240px;" v-model="form.supplierName" placeholder="请选择乙方" clearable>
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="(item,index) in supplierNameList" :key="index" :label="item" :value="item"></el-option>
                </el-select> -->
              <el-input style="width: 240px;" v-model.trim="form.supplierName" placeholder="请输入乙方名称" clearable maxlength="50"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8" align="right">
            <el-form-item label="合同类型：" class="min-width-93">
              <!-- purchaserCorpId -->
              <el-select filterable style="width: 240px;" v-model="form.contractType" placeholder="请选择合同类型" clearable>
                <el-option label="全部" value=""></el-option>
                <el-option v-for="item in contractTypeList" :key="item.code" :label="item.value" :value="item.code"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="13">
            <el-form-item label="签署时间：">
              <el-date-picker type="date" placeholder="请选择时间" :picker-options="startDtOptions" value-format="yyyy-MM-dd" v-model="form.sginStartTm" style="width: 110px" class="fl"></el-date-picker>
              <div style="width:20px;text-align:center;" class="fl">~</div>
              <el-date-picker type="date" placeholder="请选择时间" :picker-options="endDtOptions" value-format="yyyy-MM-dd" v-model="form.sginEndTm" style="width: 110px" class="fl"></el-date-picker>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24" class="form-btns">
            <el-button type="primary" class="small-btn" @click="handleSearch">搜索</el-button>
            <el-button class="small-btn limit-width" @click="handleClear">清除</el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="product-table">
      <!-- 列表 -->
      <table>
        <thead>
          <tr class="tl">
            <td style="width: 200px;">合同编码/合同名称</td>
            <td width="200">甲方/乙方</td>
            <td width="140">合同类型</td>
            <td width="170" style="text-align:right;">合同价款(含税)(元)</td>
            <td style="width: 200px;padding-left:50px;">签署时间</td>
            <td class="tr">操作</td>
          </tr>
        </thead>

        <template v-if="projectList.length">
          <tbody>
          </tbody>
          <tbody v-for="(product,index) in projectList" :key="index" class="tl tbody-row">
            <tr>
              <td>
                <p>{{product.contractNo || ""}}</p>
                <p v-if="product.contractName && product.contractName.length < 25">{{"《" + product.contractName + "》" || ""}}</p>
                <el-popover popper-class="dark-popover" trigger="hover" placement="top" v-else-if="product.contractName && product.contractName.length >= 25">
                  <div style="color: #fff;width: 500px">
                    {{"《" + product.contractName + "》"}}
                  </div>
                  <p slot="reference" v-if="$isIE()">{{"《" + product.contractName.slice(0,25)+"...》"}}</p>
                  <p slot="reference" v-else class="ellipsisTwo">{{"《" + product.contractName + "》"}}</p>
                </el-popover>
              </td>
              <td>
                <p>{{product.corpName}}</p>
                <p>{{product.supplierName}}</p>
              </td>
              <td>
                {{product.contractTypeName}}
                <!-- <div v-if="product.contractType == '0'">专业(劳务)分包合同</div>
                <div v-else-if="product.contractType == '1'">材料采购合同</div> -->
              </td>
              <td style="text-align:right;">{{product.priceIncludingTax | formatMoney}}</td>
              <td style="padding-left:50px;">{{product.signingTm}}</td>
              <td class="nowrap btn-space">
                <p class="tr"><span class="blue-pointer" @click="handleGoDetail(product,'isEdit')">编辑</span></p>
                <p class="tr"><span class="blue-pointer" @click="handleDelContract(product)">删除</span></p>
                <p class="tr"><span class="blue-pointer" @click="handleGoDetail(product)">查看详情</span></p>
              </td>
            </tr>
          </tbody>
        </template>
      </table>
      <div class="table-pagination" v-if="projectList.length">
        <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
        </el-pagination>
      </div>

      <!-- 空列表 -->
      <div class="product-empty" v-if="!projectList.length&&!listLoading">
        <img src="@/assets/images/icon-no-product.png">
        <p>没有搜索到相关合同，请重新修改搜索条件搜索！</p>
      </div>
    </div>

    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import { InterfaceService } from "@/services/api";
import { DateUtil } from '@/utils/dateUtil';
import { NumberUtil } from '@/utils/numberUtil';


const params = {
  contractName: "",
  projectName: "",
  corpId: "",
  supplierName: "",
  contractType: "",
  sginStartTm: "",
  sginEndTm: "",
  pageIndex: 1,
  pageSize: 10,
};

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    PanelTitle
  },
  data() {
    return {
      form: Object.assign({}, params),
      projectList: [

      ],//合同列表
      total: 0,
      supplierNameList: [],//乙方
      contractTypeList: [],//合同类型

      isLoading: false,
      listLoading: false,

      startDtOptions: {
        disabledDate: time => {
          if (this.form.sginEndTm) {
            return time.getTime() > new Date(this.form.sginEndTm).getTime();
          }
        }
      }, // 搜索开始时间配置
      endDtOptions: {
        disabledDate: time => {
          if (this.form.sginStartTm) {
            return time.getTime() < new Date(this.form.sginStartTm).getTime() - 86400000;
          }
        }
      }, // 搜索结束时间配置
      instrMember: '',
      projectCorpId: '',
    };
  },
  computed: {

  },
  methods: {
    //在线入库按钮
    handleCreateContract() {
      window.open(this.$router.resolve({
        path: '/bigInfrastructureEntry',
      }).href, '_blank')
    },
    // 清楚状态选择
    handleSelectClear() {
      // this.recoverStatus(this.tab);
    },
    // 清除
    handleClear() {
      this.form = Object.assign({}, params);
      this.getContractListData()
      // this.recoverStatus(this.tab);
    },
    // 搜索
    handleSearch() {
      this.form.pageIndex = 1;
      this.getContractListData();
    },

    // 刷新列表
    handleRefresh(operationType) {
      //关闭、删除
      this.form.pageIndex = 1;
    },
    // 分页跳转
    handleCurrentChange(page) {
      this.form.pageIndex = page;
      this.getContractListData();
      window.scrollTo(0, 0)
    },
    getContractListData() {
      const params = Object.assign({}, this.form);

      params.instrMember = this.instrMember || ''
      params.projectCorpId = this.projectCorpId || ''

      InterfaceService.contractListData(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.projectList = data.respData.contractInfoList || [];
            this.total = data.respData.totalCount;
            // this.form.pageSize = data.respData.pageSize;
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
          this.listLoading = true;
        },
        () => {
          this.isLoading = false;
          this.listLoading = false;
        }
      );
    },
    // //金额的格式化
    // formatMoney(val){
    //   if(!val && val != "0"){
    //     return;
    //   }else{
    //     let newVal = val.slice(0,-1);
    //     newVal = NumberUtil.formatMoney(newVal);
    //     return newVal;
    //   }
    // },
    //合同删除
    handleDelContract(product) {
      this.$confirm('请确认是否删除《' + product.contractName + '》？删除后将不再撤回。', '确认删除', {
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        confirmButtonText: "确认删除",
        cancelButtonText: "取消",
        // type: "warning"
      }).then(() => {
        this.handleDelItem(product);
      }).catch(() => {

      });
    },
    handleDelItem(product) {
      const params = {
        instrConid: product.instrConid
      };
      InterfaceService.delContract(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
          this.form.pageIndex = 1;
          this.getContractListData();
        } else {
          this.$message.error(data.respData.respMsg);
        }
      },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        })
    },
    //进入详情
    handleGoDetail(item, isEdit) {
      if (isEdit) {
        this.$router.push({
          path: "/bigInfrastructureEntry",
          query: {
            instrConid: item.instrConid,
            isEdit: isEdit
          }
        })
      } else {
        this.$router.push({
          path: "/bigInfrastructureEntry",
          query: {
            instrConid: item.instrConid
          }
        })
      }
    },
    getPaymentMethod() {
      return new Promise(resolve => {
        const params = {
          appName: 'TRANS',
          groupIds: ['LVDI_DJJ_CONTRACT_TYPE', 'DATA_ANALYSE_ALL_ROLE'],
        }
        InterfaceService.getPaymentMethod(params, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let res = data.respData.configEntityListMap || {};

            this.contractTypeList = res.LVDI_DJJ_CONTRACT_TYPE || [];

            if (this.bigInfrastructure) {
              // 用于判断 基建成员
              const allRoleItem = res.DATA_ANALYSE_ALL_ROLE && res.DATA_ANALYSE_ALL_ROLE[0] || {},
                roleList = this.roleListFilter(this.mxCorpId),
                isSysAdmin = roleList.some(s => s.roleId == allRoleItem.value)
                this.instrMember =  this.userinfo.corpTags && this.userinfo.corpTags.filter(i=> i.tagType == '03').length && this.userinfo.corpTags.filter(i=> i.tagType == '03')[0].tagId || ''
              //  非系统管理员 需要设置 当前登录用户 项目公司
              if (!isSysAdmin) {
                this.projectCorpId = this.userinfo.corpTags && this.userinfo.corpTags[0] && this.userinfo.corpTags[0].corpId || ''
              }
            }
            resolve(true)

          } else {
            this.$message.error(data.respData.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },
  },
  async mounted() {
    await this.getPaymentMethod()
    this.getContractListData();
  }
};
</script>

<style lang="scss" scoped>
.hand + .hand {
  margin-left: 10px;
}
.price-tip {
  cursor: pointer;
  color: #a9a9aa;

  &:hover {
    color: #0082ff;
  }
}

.product {
  font-size: 14px;
}

.pointer {
  cursor: pointer;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }

  .active {
    color: #ffd64e;
  }
}

.nowrap {
  white-space: nowrap;
}

.panel-content {
  padding: 20px 10px 0;
  background: #f9f9f9;
}

.form {
  min-height: 135px;

  /deep/ .el-col {
    height: 52px;
  }

  /deep/ .el-select {
    width: 100%;
  }

  /deep/ .el-date-editor {
    input.el-input__inner {
      padding: 0 15px;
    }
    .el-input__prefix {
      display: none;
    }
  }

  &:after {
    display: table;
    content: "";
    clear: both;
  }
}

.form-item {
  position: relative;
  display: inline-block;
  line-height: 32px;

  .float-right {
    position: absolute;
    top: 2px;
    right: 1px;
    height: 30px;
    padding: 0 7px;
    line-height: 30px;
    background: #ffffff;
  }
}

.error-info {
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
  position: absolute;
  top: 100%;
  left: 0;
}

.form-btns {
  text-align: center;
}

.product-table {
  /deep/ .el-table__body-wrapper {
    font-size: 12px;
  }

  /deep/ .el-table th,
  .el-table td {
    padding: 14px 0;
  }

  /deep/ .el-button {
    font-size: 12px;
  }

  table {
    table-layout: fixed;
    width: 100%;
    line-height: 23px;
    font-size: 12px;
    td {
      padding: 14px 15px;
      vertical-align: middle;
      word-break: break-all;
    }
    td:last-child {
      padding-right: 10px;
    }
    td:first-child {
      padding-left: 10px;
    }

    thead {
      font-size: 14px;
      text-align: center;
      white-space: nowrap;
      color: #909399;
      background: #f9f9f9;
    }

    .tbody-row {
      &:hover {
        background: #e8f3fd;
        .sign-content {
          background: #f0f8ff;
        }
      }
      .sign-content {
        display: table-row;
        background: #f9f9f9;
        td {
          padding: 0;
          border-top: none;
        }
      }
    }
    .tbody-row .nailsupply {
      display: inline-block;
      max-width: 100%;
      min-height: 14px;
      padding: 0 6px;
      line-height: 14px;
      border: 1px solid #ffa300;
      border-radius: 7px;
      color: #ffa300;
      margin-right: 6px;
    }
    tbody {
      text-align: center;

      tr {
        &.all-check {
          text-align: left;

          &:hover {
            background: #ffffff;
          }
        }
      }

      /*tr:hover + tr.sign-content {*/
      /*display: table-row;*/
      /*}*/

      tr {
        border-bottom: 1px solid #ebeef5;
      }
      .border-none {
        border-bottom: none;
      }
    }
  }

  .product-name {
    display: inline-flex;
    width: 100%;
    vertical-align: top;
    line-height: 20px;

    img {
      width: 75px;
      height: 75px;
    }

    .left {
      margin-right: 10px;
    }

    .right {
      text-align: left;

      p:first-child {
        margin-bottom: 10px;
      }
      p:last-child {
        word-break: break-all;
        max-height: 40px;
        overflow: hidden;
        color: #969799;
      }
    }
  }
}

.product-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}

.price-popover {
  display: flex;
  color: #ababac;

  > div:first-child {
    margin-right: 10px;
  }

  p:first-child {
    padding: 0 5px;
    border-left: 3px solid #ffd64e;
    line-height: 15px;
  }

  p:last-child {
    margin-top: 10px;
    color: #ffffff;
  }
}

.table-pagination {
  margin: 50px 0 80px;
  text-align: center;
  color: #888888;
}
/deep/ .el-dropdown-menu__item {
  min-height: 14px;
  line-height: 14px;
  border: 1px solid #ffa300;
  border-radius: 7px;
  color: #ffa300;
  cursor: default;
  margin-top: 5px;
  &:hover {
    color: #ffa300;
    background: #fff;
  }
  &:first-child {
    margin-top: 0;
  }
}
.w284 {
  width: 284px !important;
}
.subOrderMsgContainer {
  padding: 0 !important;
  span {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border: 0;
  }
}
.batch-operation {
  padding-left: 10px;
  margin-top: -10px;
  margin-bottom: 10px;
  .el-button {
    margin-left: 8px;
  }
}
.sign-result-dialog {
  /deep/ .el-dialog__body {
    width: 100%;
  }
  text-align: center;
  div {
    text-align: center;
    margin: 20px auto 20px;
  }
}
.limit-width {
  margin-left: 10px;
}
.btn-space /deep/ .el-button {
  padding-top: 2px !important;
  padding-bottom: 2px !important;
}
.create-project {
  margin-top: -20px;
  padding: 10px 0px;
}
.min-width-93 {
  /deep/ .el-form-item__label {
    width: 93px !important;
    text-align: right;
  }
  /deep/ .el-form-item__content {
    margin-left: 93px !important;
  }
}
</style>




