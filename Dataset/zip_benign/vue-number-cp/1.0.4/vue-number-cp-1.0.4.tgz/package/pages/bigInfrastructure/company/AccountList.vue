<template>
  <div class="users">
    <UsersManage></UsersManage>
  </div>
</template>

<script>
import {
  InterfaceService
} from "@/services/api";
import UsersManage from "@/components/auth/UserManage";


export default {
  components: {
    UsersManage
  },
  data() {
    return {

    };
  },
  methods: {

  },
  mounted() {
  }
};
</script>

<style lang="scss" scoped>
</style>