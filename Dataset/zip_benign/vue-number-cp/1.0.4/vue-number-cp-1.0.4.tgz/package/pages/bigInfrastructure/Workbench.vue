<template>
  <div class="workbench">
    <PanelTitle :title="'交易数据分析'"></PanelTitle>
    <div class="list-content">
      <div class="workbench-search-container">
        <span>基建成员：</span>
        <el-select filterable style="width: 474px;" :disabled="bigInfrastructure && !isSysAdmin" v-model="instrMember" placeholder="请输入关键词搜索选择基建成员" :clearable="!bigInfrastructure" @change="handleChangeSelectSearch(1)">
          <el-option v-if="!bigInfrastructure" label="全部" value=""></el-option>
          <el-option v-for="(item, idx) in instrMemberList" :key="item.tagId + idx" :label="item.tagName" :value="item.tagId"></el-option>
        </el-select>
        <el-select filterable :disabled="bigInfrastructure && !isSysAdmin" style="width: 474px; margin-left: 12px" v-model="projectCorpId" placeholder="请输入关键词搜索选择分公司/项目公司" clearable @change="handleChangeSelectSearch(2)">
          <el-option label="全部" value=""></el-option>
          <el-option v-for="(item, idx) in projectCorpIdList && projectCorpIdList.filter(f=> !notViewProjectCorp.includes(f.corpId))" :key="item.corpId+idx" :label="item.corpName" :value="item.corpId"></el-option>
        </el-select>
      </div>

      <div class="timeSelection">
        <!-- <TimeSelection :timeSel="timeSel" :realTime="realTime" :selTime="new Date()" @getSelectedTime="getSelectedTime"></TimeSelection> -->
        <div class="fl">
          统计时间：{{tmStart}}
          <template v-if="tmEnd">~</template>
          {{tmEnd}}
        </div>
        <div class="time-container">
          <span>时间选择：</span>
          <el-date-picker style="width: 140px;" type="date" placeholder="开始时间" @change="handleChangeDatePickerSearch" value-format="yyyy-MM-dd" :picker-options="pickerOptionsStart" v-model="tmStart"></el-date-picker>
          ~
          <el-date-picker style="width: 140px;" type="date" placeholder="结算时间" @change="handleChangeDatePickerSearch" value-format="yyyy-MM-dd" :picker-options="pickerOptionsEnd" v-model="tmEnd"></el-date-picker>
        </div>
      </div>
      <ul class="turnover">
        <li class="tc">
          <p class="grey f14 blod">合同总价款(含税)(万元)</p>
          <p class="amount purple">{{transAmounts | formatMoney}}</p>
        </li>
        <li class="tc">
          <p class="grey f14 blod">合同数量(份)</p>
          <p class="amount purple">{{contracts | formatThreeDigits}}</p>
        </li>
        <li class="tc">
          <p class="grey f14 blod">供应商数量(家)</p>
          <p class="amount purple">{{suppliers | formatThreeDigits}}</p>
        </li>
      </ul>
      <div class="category-row">
        <div class="order-info-title order-rankings" style="margin: 32px 0px 20px !important;">
          合同类型交易排行
          <span class="material-money">{{contractType == '1' ? "材料采购类总交易金额" : "专业(劳务)分包类总交易金额"}}：<span class="purple">{{metriAmount | formatMoney}}</span>万元</span>
          <ul class="order-rankings-tab">
            <li :class="{active: contractType == '1'}" @click="handleClickContractType('1')">材料采购类</li>
            <li :class="{active: contractType == '0'}" @click="handleClickContractType('0')">专业(劳务)分包类</li>
          </ul>
        </div>
        <table class="category-table">
          <thead>
            <tr>
              <td width="135px">一级品类</td>
              <td width="44px">排名</td>
              <td>交易金额</td>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item,ind) in categorySumList" :key="ind+'categorySumList'">
              <td>
                <p v-if="item.levelName && item.levelName.length < 16">{{item.levelName}}</p>
                <el-popover popper-class="dark-popover" trigger="hover" placement="top" v-else-if="item.levelName && item.levelName.length >= 16">
                  <div style="color: #fff;width: 500px">
                    {{item.levelName}}
                  </div>
                  <p slot="reference" v-if="$isIE()">{{item.levelName.slice(0,16) + "..."}}</p>
                  <p slot="reference" v-else class="ellipsisTwo">{{item.levelName}}</p>
                </el-popover>
              </td>
              <td>{{item.num}}</td>
              <td>
                <div class="progress-box">
                  <div class="progress" :style="{width: item.width + 'px','margin-right': item.width ? '13px' : '0px'}"></div>
                  <span class="f12 bold" ref="transAmounts">{{item.transAmounts | formatMoney}}万元</span>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="noData" v-if="!categorySumList.length" style="padding-top: 50px;">
          <p class="f14 grey">暂无信息，请重新修改搜索条件搜索！</p>
        </div>
      </div>
      <div class="supplier-row">
        <div class="header">
          <div class="order-info-title" style="margin: 0px !important;">供应商排名</div>
          <ul>
            <li v-for="(item, index) in supplierTypeList" :key="index+'supplierTypeList'" class="tc hand" @click="supplierTypeChenge(item)" :class="{'selected': supplierType === item.code}">
              {{item.value}}
            </li>
          </ul>
        </div>
        <TableThead :TopDistance="760" width="1020" left="240">
          <tr slot="tr">
            <td width="87px">排名</td>
            <td>供应商名称</td>
            <td width="210px">类型</td>
            <td width="210px" class="tr">总合同签约金额(含税)(万元)</td>
            <td width="90px">操作</td>
          </tr>
        </TableThead>
        <table class="table-default">
          <thead>
            <tr>
              <td width="87px">排名</td>
              <td>供应商名称</td>
              <td width="210px">类型</td>
              <td width="210px" class="tr">总合同签约金额(含税)(万元)</td>
              <td width="120px" v-if="bigInfrastructure">操作</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in supplierInfoList" :key="ind+'supplierInfoList'">
            <tr>
              <td>{{ind+1}}</td>
              <td>{{item.supplierName}}</td>
              <td>{{item.supplierTypeName}}</td>
              <td class="tr">{{item.transAmount | formatMoney}}</td>
              <td v-if="bigInfrastructure">
                <p class="tr">
                  <span class="blue-pointer" @click="handleSupplierDirectoryDetails(item)">查看详情</span>
                </p>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="noData" v-if="!supplierInfoList.length">
          <p class="f14 grey">暂无信息，请重新修改搜索条件搜索！</p>
        </div>
        <div class="table-pagination" v-if="supplierInfoList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import TableThead from "@/components/base/TableThead";
import { NumberUtil } from '@/utils/numberUtil';
import TimeSelection from "@/components/bigInfrastructure/TimeSelection";
import accountMixin from "@/mixins/account";

export default {
  components: {
    Loading, PanelTitle, TableThead, TimeSelection
  },
  mixins: [accountMixin],
  data() {
    return {
      isLoading: false,
      total: 0, //分页 总页数
      pageSize: 20, //分页 每页的长度
      pageIndex: 1, //当前页码

      contracts: '',
      transAmounts: '',
      suppliers: '',
      initSmStart: '2000-01-01', // 默认查询开始时间
      tmStart: '',
      tmEnd: '',
      supplierType: '',
      supplierTypeList: [],

      metriAmount: '',
      categorySumList: [],

      supplierInfoList: [],
      timeSel: 'year',
      realTime: true,

      instrMember: '',  // 基建成员
      instrMemberList: [],
      projectCorpId: '',  // 项目公司
      projectCorpIdList: [],
      contractType: "1", // ("0": 劳务合同（专业合同）、"1": 材料采购)
      isSysAdmin: false, // 是否系统管理员
      isInitState: true, // 首次加载
      notViewProjectCorp: [],

      pickerOptionsEnd: {
        disabledDate: time => {
          return time.getTime() <= new Date(this.tmStart).getTime() - 86400000
        }
      },
      pickerOptionsStart: {
        disabledDate: time => {
          return this.tmEnd && time.getTime() >= new Date(this.tmEnd).getTime()
        }
      },
    }
  },
  methods: {
    handleChangeSelectSearch(type) {
      this.realTime = false
      setTimeout(e => {
        console.log('selectChange', type);
        this.realTime = true
        if (type == 1) {
          this.projectCorpId = ''
          this.queryProjectCompany()
        }
      }, 30)
      this.initData()
    },
    handleClickContractType(type) {
      this.contractType = type || '0'
      this.categoryRanking()
    },
    handleSupplierDirectoryDetails(item) {
      this.$router.push({
        // path: '/bigInfrastructureCenter/supplierDirectoryDetails',
        path: `${this.role === 'S' ? '/vendorCenter' : '/purchaserCenter'}/supplierDirectoryDetails`,
        query: {
          supplierId: item.supplierId,
          id: item.id,
          supplierName: item.supplierName,
          pageType: 'Workbench',
          instrMember: this.instrMember,
          projectCorpId: this.projectCorpId,
          tmStart: this.tmStart,
          tmEnd: this.tmEnd,
        }
      })
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.supplierRanking()
      window.scrollTo(0, 0)
    },
    getSelectedTime(start, end, timeSelected, selectedTime) {
      console.log(start, end, timeSelected, selectedTime, 'start, end, timeSelected, selectedTime');

      this.tmStart = start
      this.tmEnd = end
      if (timeSelected === "year") {
        this.tmStart = this.tmStart.substring(0, 10)
        this.tmEnd = this.tmEnd.substring(0, 10)
      }
      this.init()
    },
    supplierTypeChenge(item) {
      this.supplierType = item.code
      this.pageIndex = 1
      this.supplierRanking()
    },
    /**
     * DATA_ANALYSE_ALL_ROLE
     */
    getPaymentMethod() {
      return new Promise(resolve => {
        const params = {
          appName: 'TRANS',
          groupIds: ['SUPPLIER_TYPE', 'DATA_ANALYSE_ALL_ROLE', 'NOT_VIEW_PROJUCT_CORP'],
        }
        InterfaceService.getPaymentMethod(params, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let res = data.respData.configEntityListMap || {};
            this.supplierTypeList = res.SUPPLIER_TYPE || []
            this.supplierTypeList.unshift({
              value: '全部',
              code: ''
            })


            // 用于判断 是否置灰 基建成员
            const allRoleItem = res.DATA_ANALYSE_ALL_ROLE && res.DATA_ANALYSE_ALL_ROLE[0] || {},
              roleList = this.roleListFilter(this.mxCorpId)

            this.isSysAdmin = roleList.some(s => s.roleId == allRoleItem.value)
            //  非系统管理员 需要设置 当前登录用户 项目公司
            if (this.bigInfrastructure && !this.isSysAdmin) {
              if(this.userinfo.corpTags && this.userinfo.corpTags.some(i=> i.tagType == '03')){
                this.projectCorpId =  this.userinfo.corpTags.find(i=> i.tagType == '03').corpId || ''
              }else{
                this.projectCorpId = this.userinfo.corpTags && this.userinfo.corpTags[0] && this.userinfo.corpTags[0].corpId || ''
              }
            }


            // 需要排除的项目公司
            this.notViewProjectCorp = res.NOT_VIEW_PROJUCT_CORP && res.NOT_VIEW_PROJUCT_CORP[0] && res.NOT_VIEW_PROJUCT_CORP[0].value && res.NOT_VIEW_PROJUCT_CORP[0].value.split(',') || []
            resolve(true)
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
          }
        }, data => { }, () => { this.isLoading = true; }, () => { this.isLoading = false; })
      })
    },
    workbenchData() {
      const params = {
        tmStart: this.tmStart || this.initSmStart,
        tmEnd: this.tmEnd || '',
        instrMember: this.instrMember,
        projectCorpId: this.projectCorpId,
      }
      InterfaceService.workbenchData(
        params,
        data => {
          if (data.respData && data.respData.respCode == "0000") {
            this.contracts = data.respData.contractSum.contracts || '0'
            this.transAmounts = data.respData.contractSum.transAmounts || '0'
            this.suppliers = data.respData.contractSum.suppliers || '0'
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
          }
        },
        data => { }, () => { this.isLoading = true }, () => { this.isLoading = false }
      );
    },
    categoryRanking() {
      const params = {
        tmStart: this.tmStart || this.initSmStart,
        tmEnd: this.tmEnd || '',
        instrMember: this.instrMember,
        projectCorpId: this.projectCorpId,
        contractType: this.contractType
      }
      InterfaceService.categoryRanking(
        params,
        data => {
          if (data.respData && data.respData.respCode == "0000") {
            this.metriAmount = data.respData.metriAmount || ''
            this.categorySumList = data.respData.categorySumList || []
            if (this.categorySumList.length) {
              this.$nextTick(() => {
                let transAmountsWidth = this.$refs.transAmounts[0].clientWidth
                this.categorySumList.forEach(i => {
                  if (+(i.transAmounts || '')) {
                    const transAmounts = this.categorySumList[0].transAmounts
                    let width = NumberUtil.divide(+(i.transAmounts || 0), +(transAmounts || 0))
                    width = NumberUtil.accMul(width, 813 - transAmountsWidth)
                    this.$set(i, 'width', width)
                  } else {
                    this.$set(i, 'width', 0)
                  }
                })
              })
            }
            console.log(this.categorySumList)
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
          }
        },
        data => { }, () => { this.isLoading = true }, () => { this.isLoading = false }
      );
    },
    supplierRanking() {
      const params = {
        tmStart: this.tmStart || this.initSmStart,
        tmEnd: this.tmEnd || '',
        instrMember: this.instrMember,
        projectCorpId: this.projectCorpId,
        supplierType: this.supplierType,
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
      }
      InterfaceService.supplierRanking(
        params,
        data => {
          if (data.respData && data.respData.respCode == "0000") {
            this.supplierInfoList = data.respData.supplierInfoList || []
            this.total = data.respData.totalCount || 0
            // this.pageSize = data.respData.pageSize
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
          }
        },
        data => { }, () => { this.isLoading = true }, () => { this.isLoading = false }
      );
    },

    handleChangeDatePickerSearch(){
      this.initData()
    },

    /**
     * 查询项目公司
     */
    queryProjectCompany() {
      const params = {
        tagId: this.instrMember
      }
      InterfaceService.queryProjectCompany(
        params,
        data => {
          if (data.respData && data.respData.respCode == "0000") {
            this.projectCorpIdList = data.respData.corpTagList || []
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
          }
        },
        data => { }, () => { this.isLoading = true }, () => { this.isLoading = false }
      );
    },
    initData() {
      this.pageIndex = 1
      this.supplierType = ''
      this.contractType = '1'
      this.workbenchData()
      this.categoryRanking()
      this.supplierRanking()
    },
    async init() {
      this.initDateFormat()
      this.tmEnd = new Date().Format("yyyy-MM-dd")
      if (this.isInitState) {
        this.isInitState = false
        await this.getPaymentMethod()
      }
      this.initData()
    },
    initDateFormat() {
      Date.prototype.Format = function (fmt) { //author: meizz
        let o = {
          "M+": this.getMonth() + 1, //月份
          "d+": this.getDate(), //日
          "h+": this.getHours(), //小时
          "m+": this.getMinutes(), //分
          "s+": this.getSeconds(), //秒
          "q+": Math.floor((this.getMonth() + 3) / 3), //季度
          "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (let k in o)
          if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
      };
    }
  },
  mounted() {
    // 大基建用户需要初始化数据
    if (this.bigInfrastructure) {
      if(this.userinfo.corpTags && this.userinfo.corpTags.some(i=> i.tagType == '03')){
        this.instrMember =  this.userinfo.corpTags.find(i=> i.tagType == '03').tagId || ''
      }
      this.queryProjectCompany()
    }
    this.instrMemberList = (this.userinfo && this.userinfo.corpTags || []).filter(i=> i.tagType == "03")
    this.init()
  },
}
</script>
<style lang="scss" scoped>
.timeSelection {
  font-size: 12px;
  margin-bottom: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  /deep/ .el-input__inner {
    height: 30px;
    line-height: 30px;
  }
  /deep/ .el-input__icon {
    line-height: 30px;
  }
}
.workbench {
  padding-bottom: 60px;
  .turnover {
    display: flex;
    justify-content: space-between;
    li {
      width: 330px;
      height: 121px;
      padding-top: 30px;
      box-shadow: 0px 0px 12px rgba(92, 92, 92, 0.16);
      .amount {
        font-size: 24px;
        line-height: 33px;
        font-weight: 600;
        margin-top: 8px;
        font-family: PingFang SC;
      }
    }
  }
  .category-row {
    padding-bottom: 15px;
    border-bottom: 1px solid #eee;
    .category-table {
      table-layout: fixed;
      width: 100%;
      font-size: 12px;
      line-height: 17px;
      thead {
        white-space: nowrap;
        background: #f5f5f5;
        tr {
          td {
            padding-top: 6px;
            padding-bottom: 5px;
            color: #888;
            font-weight: 600;
          }
        }
      }
      tr {
        td {
          padding: 15px 0 15px 10px;
          &:first-child {
            padding-left: 16px;
          }
          .progress-box {
            display: flex;
            align-items: center;
            .progress {
              width: 0px;
              transition: width 1s;
              height: 20px;
              background: linear-gradient(161deg, #6424de 0%, #a36df8 100%);
            }
          }
        }
      }
    }
  }
  .supplier-row {
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 20px 0 8px;
      .order-info-title {
        margin-bottom: 10px;
      }
      ul {
        display: flex;
        li {
          width: 100px;
          line-height: 24px;
          height: 26px;
          border: 1px solid #ddd;
          border-right: none;
          &:last-child {
            border-right: 1px solid #ddd;
          }
          &.selected {
            color: #fff;
            background: linear-gradient(119deg, #d7b064 0%, #ecce8b 100%);
          }
        }
      }
    }
    .table-default {
      margin-top: 0px;
    }
  }
  .noData {
    padding-top: 100px;
    > p {
      text-align: center;
      margin-bottom: 8px;
    }
  }
}
.workbench-search-container {
  display: flex;
  align-items: center;
  margin-bottom: 40px;
}

.order-info-title {
  padding-right: 0 !important;
}
.order-rankings {
  .material-money {
    margin-left: 10px;
    font-size: 12px;
  }
  .order-rankings-tab {
    float: right;
    display: flex;
    border-left: 1px solid #eaeaea;
    li {
      padding: 4px 12px;
      font-size: 12px;
      font-weight: normal;
      border: 1px solid #eaeaea;
      border-left: 0;
      cursor: pointer;
      &.active {
        color: #fff;
        background: linear-gradient(119deg, #d7b064 0%, #ecce8b 100%);
      }
    }
  }
}
</style>
