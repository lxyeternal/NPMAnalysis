<template>
  <div class="product">
    <!-- 工程列表 -->
    <div v-show="!manageRightVisiable">
      <PanelTitle :title="'全部工程'"></PanelTitle>
      <div class="clearfloat create-project">
        <el-button type="primary" class="fr small-btn" @click="handleCreateProject()">创建工程</el-button>
      </div>
      <!-- 查询条件 -->
      <div class="panel-content">
        <el-form class="form" :model="form" size="small" label-width="75px">
          <el-row>
            <el-col :span="24">
              <el-form-item label="工程名称：">
                <el-input v-model.trim="form.projectName" placeholder="请输入工程关键词或工程编码"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item label="施工单位：">
                <el-select filterable style="width: 240px;" v-model="form.corpIdList" placeholder="搜索选择施工单位" clearable>
                  <el-option v-for="item in groupCompanyList" :key="item.code" :label="item.value" :value="item.code"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="工程类型：">
                <!-- purchaserCorpId -->
                <el-select filterable style="width: 240px;" v-model="form.projectType" placeholder="请选择工程类型" clearable>
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="item in projectTypeList" :key="item.code" :label="item.value" :value="item.code"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8"></el-col>
          </el-row>
          <el-row>
            <el-col :span="24" class="form-btns">
              <el-button type="primary" class="small-btn" @click="handleSearch">搜索</el-button>
              <el-button class="small-btn limit-width" @click="handleClear">清除</el-button>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div class="clearfloat middle-height">
        <!-- <el-button type="primary" class="fr small-btn" @click="handleProjectRightManage()">工程权限管理</el-button> -->
      </div>
      <div class="product-table">
        <!-- 列表 -->
        <table>
          <thead>
            <tr class="tl">
              <td>工程编码/工程名称</td>
              <td width="270">施工单位</td>
              <td width="150">工程类型</td>
              <!-- <td style="width: 150px;" >工程管理员</td> -->
              <!-- <td style="width: 78px;">状态</td> -->
              <td style="width: 228px;">状态</td>
              <td style="width: 102px;" class="tr">操作</td>
            </tr>
          </thead>

          <template v-if="projectList.length">
            <tbody>
            </tbody>
            <tbody v-for="(product,index) in projectList" :key="index" class="tl tbody-row">
              <tr class="unit-data">
                <td>
                  <p>{{product.projectId || ""}}</p>
                  <p class="blue hand" @click="handleGoDetail(product)" v-if="product.projectName && product.projectName.length < 37 ">{{product.projectName || ""}}</p>
                  <el-popover popper-class="dark-popover" trigger="hover" placement="top" v-else-if="product.projectName && product.projectName.length >= 37">
                    <div style="color: #fff;width: 500px">
                      {{product.projectName}}
                    </div>
                    <span slot="reference" class="blue hand" @click="handleGoDetail(product)">{{product.projectName.slice(0,37)+"..."}}</span>
                  </el-popover>
                </td>
                <td>
                  <div v-if="product.corpNameLi && product.corpNameLi.length < 36">
                    {{product.corpNameLi || ""}}
                  </div>
                  <el-popover popper-class="dark-popover" trigger="hover" placement="top" v-else-if="product.corpNameLi && product.corpNameLi.length >= 36">
                    <div style="color: #fff;width: 500px">
                      {{product.corpNameLi}}
                    </div>
                    <span slot="reference">{{product.corpNameLi.slice(0,36)+"..."}}</span>
                  </el-popover>
                </td>
                <td>{{product.projectTypeName || ""}}</td>
                <!-- <td>
                  <p>{{product.creator}}</p>
                  <p>(Tel:{{product.adminTel || "-" | formatString}})</p>
                </td> -->
                <td>
                  <span v-if="product.isDraft == '1'">创建中</span>
                  <span v-if="product.isDraft == '0'">已创建</span>
                </td>
                <td class="nowrap btn-space">
                  <p class="tr"><span class="blue-pointer" @click="handleGoDetail(product,'isEdit')">编辑</span></p>
                  <p class="tr"><span class="blue-pointer" @click="handleDelete(product)">删除</span></p>
                </td>
              </tr>
            </tbody>
          </template>
        </table>
        <div class="table-pagination" v-if="projectList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>

        <!-- 空列表 -->
        <div class="product-empty" v-if="!projectList.length&&!listLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关工程，请重新修改搜索条件搜索！</p>
        </div>
      </div>
    </div>
    <!-- 工程权限配置 -->
    <div v-show="manageRightVisiable">
      <PanelTitle :title="'工程权限设置'"></PanelTitle>
      <div>
        <span class="blue">管理中心</span><span> > </span><span class="blue hand" @click="handleBackList">公司管理-工程管理</span><span> > </span><span>工程权限设置</span>
      </div>
      <!-- 查询条件 -->
      <div class="panel-content" :style="{'margin-bottom' : brokerRole ? '40px' : '35px'}">
        <el-form class="form" :model="form" size="small" label-width="75px">
          <el-row>
            <el-col :span="24">
              <el-form-item label="工程名称：">
                <el-input v-model.trim="form.contractName" placeholder="请搜索关键词选择工程或者搜索工程编码添加"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div class="product-table">
        <el-row style="margin-bottom: 10px;">
          <el-col :span="3">
            <div style="height: 28px;line-height: 28px;">
              <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow"></el-checkbox>&nbsp;全选
            </div>
          </el-col>
          <el-col :span="21">
            <el-button size="mini">批量设置角色</el-button>
            <el-button size="mini">批量删除</el-button>
          </el-col>
        </el-row>
        <!-- 列表 -->
        <table>
          <thead>
            <tr class="tl">
              <td width="30"></td>
              <td width="60">序号</td>
              <td>工程编码/工程名称</td>
              <td style="width: 200px;">角色</td>
              <td style="width: 102px;" class="tr">操作</td>
            </tr>
          </thead>

          <template v-if="projectList.length">
            <tbody>
            </tbody>
            <tbody class="tl tbody-row">
              <tr v-for="(product,index) in projectList" :key="index">
                <td>
                  <el-checkbox v-model="product.checked" @change="handleSelectTableRow(product,index)"></el-checkbox>
                </td>
                <td>1</td>
                <td>
                  <p>ORD202009908087087799</p>
                  <p class="blue">项目名称-哈哈哈哈啊哈哈哈啊哈哈哈哈哈哈哈哈哈啊哈哈哈啊哈哈哈啊哈哈哈啊哈哈哈啊哈哈哈啊哈哈</p>
                </td>
                <td>
                  合同录入人员、工程管理员
                </td>
                <td class="nowrap">
                  <p class="tr">
                    <el-button type="text">分配角色</el-button>
                  </p>
                  <p class="tr">
                    <el-button type="text" diasbled>删除</el-button>
                  </p>
                </td>
              </tr>
            </tbody>
          </template>
        </table>
        <div class="table-pagination" v-if="projectList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>

        <!-- 空列表 -->
        <div class="product-empty" v-if="!projectList.length&&!listLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关工程，请重新修改搜索条件搜索！</p>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import { InterfaceService } from "@/services/api";
import { DateUtil } from '@/utils/dateUtil';


const params = {
  pageIndex: 1,
  pageSize: 10,
  projectName: "",
  corpIdList: "",
  projectType: "",
};

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    PanelTitle
  },
  data() {
    return {
      form: Object.assign({}, params),
      statusList: [],

      projectList: [],
      groupCompanyList: [],
      projectTypeList: [],
      total: 0,

      isLoading: false,
      listLoading: false,


      manageRightVisiable: false,
      allChecked: false,

      roleId: "",//角色配置
      isLocalPerson: false,//是否为基建成员
      tagList: [],//施工单位
    };
  },
  computed: {

  },
  filters: {
    // 过滤 字符串显示 state: 默认 电话格式, bank: 银行卡格式
    formatString: (val, state) => {
      state = state || 'tel'
      val = val || ''

      let newVal = ''
      if (state === 'tel') {
        // 如果检测到 有 -  说明是座机 不做分割
        if (val.includes('-')) {
          newVal = val
        } else {
          newVal = `${val.slice(0, 3)} ${val.slice(3, 7)} ${val.slice(7, val.length)}`
        }
        newVal = val.length <= 3 ? val : newVal
      } else {
        const len = Math.floor(val.length / 4)

        for (let i = 0; i < len; i++) {
          newVal += `${val.slice(4 * i, 4 * (i + 1))} `
          if (i + 1 >= len) newVal += val.slice(4 * (i + 1), val.length)
        }

        newVal = val.length <= 4 ? val : newVal
      }

      return newVal
    }
  },
  methods: {
    // 全选
    handleAllSelectTableRow(bool) {
      // let arr = [];
      // arr = [].concat(this.productList);
      // arr.forEach(item => {
      //     item.checked = bool;
      // });
      // this.productList = arr;
      // this.$forceUpdate();
      // this.checkBatch();
    },
    // 选中行
    handleSelectTableRow(product, index) {
      if (product.checked) {
        this.selectProductNum++;
      } else {
        this.selectProductNum--;
      }
      this.$set(this.productList, index, product);
      this.checkBatch();
      this.checkAllSelect();
    },
    //面包屑
    handleBackList() {
      this.manageRightVisiable = false
      this.handleClear()
    },
    //工程权限管理
    handleProjectRightManage() {
      this.manageRightVisiable = true
    },
    //创建工程按钮
    handleCreateProject() {
      window.open(this.$router.resolve({
        path: '/bigInfrastructureCreateProject',
      }).href, '_blank')
    },
    // 清楚状态选择
    handleSelectClear() {
      // this.recoverStatus(this.tab);
    },
    // 清除
    handleClear() {
      this.form = Object.assign({}, params);
      this.getProjectList()
    },
    // 搜索
    handleSearch() {
      // this.form.orderStatus = [this.form.status];
      // if (this.form.externalCode) {
      //   this.form.sysCode = 'ERP';
      // } else {
      //   delete this.form.sysCode;
      //   delete this.form.externalCode;
      // }
      this.form.pageIndex = 1;
      this.getProjectList();
    },
    // 刷新列表
    handleRefresh(operationType) {
      //关闭、删除
      this.form.pageIndex = 1;
    },
    // 分页跳转
    handleCurrentChange(page) {
      this.form.pageIndex = page;
      this.getProjectList();
      window.scrollTo(0, 0)
    },
    getProjectList() {
      // this.recordFormData();

      const params = Object.assign({}, this.form);
      let corpIdList = [];
      if (params.corpIdList) {
        corpIdList.push(this.$clone(params.corpIdList));
        params.corpIdList = corpIdList;
      } else {
        delete params.corpIdList;
      }
      // for (let i in this.form) {
      //   if (this.form[i]) {
      //     params[i] = this.form[i];
      //   }
      // }
      // delete params.status;
      console.log(params)
      InterfaceService.frastructureList(
        params,
        data => {
          //console.log(data);
          if (data.respData.respCode === "0000") {
            this.projectList = data.respData.projectInfoList || [];
            if (this.projectList.length > 0) {
              this.projectList.forEach(el => {
                if (el.corpNameLi) {
                  if (el.corpNameLi.indexOf(",") != -1) {
                    el.corpNameLi = el.corpNameLi.replace(/\,/g, "；") + "；";
                  }
                }
              })
            }
            this.total = data.respData.totalCount;
            // this.form.pageSize = data.respData.pageSize;
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
          this.listLoading = true;
        },
        () => {
          this.isLoading = false;
          this.listLoading = false;
        }
      );
    },
    getBuyersList() {
      let param = {
        corpIds: [],
        groupCompanyCode: this.form.groupCompanyCode,
      };
      this.form.purchaserName = ''
      this.projectList = []
      console.log(this.form.groupCompanyCode, 'form.groupCompanyCode');

      if (!this.form.groupCompanyCode) return
      console.log('change');
      InterfaceService.getBuyersList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          const purchasers = data.respData.purchasers || [];
          purchasers.forEach(f => {
            f.corpName && this.projectList.push(f.corpName)
          })
          console.log(this.projectList, '-this.projectList');
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    //获取code列表
    getCodeList() {
      let params = {
        appName: 'MEMBER',
        groupId: "PROJECT_TYPE"
      };
      InterfaceService.getPaymentMethod(
        params,
        data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.projectTypeList = data.respData.configEntityList || [];
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          //this.isLoading = true;
        },
        () => {
          //this.isLoading = false;
        }
      );
    },
    //搜索施工单位
    remoteQuickPurchaseMethod(query) {
      query.replace(/\s*/g, '').length && this.searchCompany(query)
    },
    //搜索施工单位
    searchCompany(query) {
      const params = {
        searchKey: "",
        pageIndex: 1,
        pageSize: "10",
        tagList: this.tagList,
      }
      if (params.tagList.length == 0) {
        delete params.tagList;
      }
      InterfaceService.frastructureSearchCompany(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          let dataList = data.respData.corpList || [];
          if (dataList.length > 0) {
            this.groupCompanyList = dataList.map(el => {
              return {
                value: el.corpName || "",
                code: el.corpId || ""
              }
            })
          } else {
            this.groupCompanyList = [];
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },
    //进入详情
    handleGoDetail(item, isEdit) {
      if (isEdit) {
        this.$router.push({
          path: "/bigInfrastructureCreateProject",
          query: {
            projectId: item.cprojId,
            isEdit: isEdit
          }
        })
      } else {
        this.$router.push({
          path: "/bigInfrastructureCreateProject",
          query: {
            projectId: item.cprojId
          }
        })
      }
    },
    //删除按钮
    handleDelete(product) {
      if(product.delAbl == 0) {
        this.$message.error('该工程下有合同，无法删除!')
        return
      }
      this.$confirm('请确认是否删除' + product.projectName + '？删除后将不再撤回。', '确认删除', {
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        confirmButtonText: "确认删除",
        cancelButtonText: "取消",
        // type: "warning"
      }).then(() => {
        this.handleDelItem(product);
      }).catch(() => {

      });
    },
    //去删除
    handleDelItem(product) {
      const params = {
        cprojId: product.cprojId
      }
      InterfaceService.frastructureDelete(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message({
            type: 'success',
            message: '删除成功!'
          });
          this.form.pageIndex = 1;
          this.getProjectList();
        } else {
          this.$message.error(data.respData.respMsg);
        }
      },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        })
    },
    getTagList() {
      let tagList = [];
      if (this.$store.state.userInfo) {
        tagList = this.$store.state.userInfo.corpTags || [];
        if (tagList.length > 0) {
          tagList.map(el => {
            if (el.tagId) {
              this.tagList.push(el.tagId)
            }
          })
        }
      }
      this.searchCompany();
    }
  },
  mounted() {
    this.getCodeList();
    this.getProjectList();
    this.getTagList();
  }
};
</script>

<style lang="scss" scoped>
.hand + .hand {
  margin-left: 10px;
}
.price-tip {
  cursor: pointer;
  color: #a9a9aa;

  &:hover {
    color: #0082ff;
  }
}

.product {
  font-size: 14px;
}

.pointer {
  cursor: pointer;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }

  .active {
    color: #ffd64e;
  }
}

.nowrap {
  white-space: nowrap;
}

.panel-content {
  padding: 20px 10px 0;
  background: #f9f9f9;
}

.form {
  // min-height: 135px;

  /deep/ .el-col {
    height: 52px;
  }

  /deep/ .el-select {
    width: 100%;
  }

  /deep/ .el-date-editor {
    input.el-input__inner {
      padding: 0 15px;
    }
    .el-input__prefix {
      display: none;
    }
  }

  &:after {
    display: table;
    content: "";
    clear: both;
  }
}

.form-item {
  position: relative;
  display: inline-block;
  line-height: 32px;

  .float-right {
    position: absolute;
    top: 2px;
    right: 1px;
    height: 30px;
    padding: 0 7px;
    line-height: 30px;
    background: #ffffff;
  }
}

.error-info {
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
  position: absolute;
  top: 100%;
  left: 0;
}

.form-btns {
  text-align: center;
}

.product-table {
  /deep/ .el-table__body-wrapper {
    font-size: 12px;
  }

  /deep/ .el-table th,
  .el-table td {
    padding: 14px 0;
  }

  /deep/ .el-button {
    font-size: 12px;
  }

  table {
    table-layout: fixed;
    width: 100%;
    line-height: 23px;
    font-size: 12px;
    td {
      padding: 14px 15px;
      vertical-align: middle;
      word-break: break-all;
    }
    td:last-child {
      padding-right: 10px;
    }
    td:first-child {
      padding-left: 10px;
    }

    thead {
      font-size: 14px;
      text-align: center;
      white-space: nowrap;
      color: #909399;
      background: #f9f9f9;
    }

    .tbody-row {
      &:hover {
        background: #e8f3fd;
        .sign-content {
          background: #f0f8ff;
        }
        // /deep/ .el-button.is-disabled{
        //   background: #e8f3fd !important;
        // }
      }
      .sign-content {
        display: table-row;
        background: #f9f9f9;
        td {
          padding: 0;
          border-top: none;
        }
      }
    }
    .tbody-row .nailsupply {
      display: inline-block;
      max-width: 100%;
      min-height: 14px;
      padding: 0 6px;
      line-height: 14px;
      border: 1px solid #ffa300;
      border-radius: 7px;
      color: #ffa300;
      margin-right: 6px;
    }
    tbody {
      text-align: center;

      tr {
        &.all-check {
          text-align: left;

          &:hover {
            background: #ffffff;
          }
        }
      }

      /*tr:hover + tr.sign-content {*/
      /*display: table-row;*/
      /*}*/

      tr {
        border-bottom: 1px solid #ebeef5;
      }
      .border-none {
        border-bottom: none;
      }
    }
  }

  .product-name {
    display: inline-flex;
    width: 100%;
    vertical-align: top;
    line-height: 20px;

    img {
      width: 75px;
      height: 75px;
    }

    .left {
      margin-right: 10px;
    }

    .right {
      text-align: left;

      p:first-child {
        margin-bottom: 10px;
      }
      p:last-child {
        word-break: break-all;
        max-height: 40px;
        overflow: hidden;
        color: #969799;
      }
    }
  }
}

.product-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}

.price-popover {
  display: flex;
  color: #ababac;

  > div:first-child {
    margin-right: 10px;
  }

  p:first-child {
    padding: 0 5px;
    border-left: 3px solid #ffd64e;
    line-height: 15px;
  }

  p:last-child {
    margin-top: 10px;
    color: #ffffff;
  }
}

.table-pagination {
  margin: 50px 0 80px;
  text-align: center;
  color: #888888;
}
/deep/ .el-dropdown-menu__item {
  min-height: 14px;
  line-height: 14px;
  border: 1px solid #ffa300;
  border-radius: 7px;
  color: #ffa300;
  cursor: default;
  margin-top: 5px;
  &:hover {
    color: #ffa300;
    background: #fff;
  }
  &:first-child {
    margin-top: 0;
  }
}
.w284 {
  width: 284px !important;
}
.subOrderMsgContainer {
  padding: 0 !important;
  span {
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border: 0;
  }
}
.batch-operation {
  padding-left: 10px;
  margin-top: -10px;
  margin-bottom: 10px;
  .el-button {
    margin-left: 8px;
  }
}
.sign-result-dialog {
  /deep/ .el-dialog__body {
    width: 100%;
  }
  text-align: center;
  div {
    text-align: center;
    margin: 20px auto 20px;
  }
}
/deep/ .el-button.is-disabled {
  background-color: transparent !important;
  border: none !important;
}
.limit-width {
  margin-left: 10px;
}
.btn-space /deep/ .el-button {
  padding-top: 2px;
  padding-bottom: 2px;
}
.create-project {
  margin-top: -20px;
  padding: 10px 0px;
}
.middle-height {
  padding: 20px 0px 10px 0px;
}
</style>




