<template>
  <div class="authorizeManage">
    <Header :is-white-bg="true"></Header>
    <SearchBar :search-type="5" progress="授权管理" :is-border-bottom="true"></SearchBar>
    <div class="inner-container">
      <Breadcrumb :breadcrumbList="breadcrumb"></Breadcrumb>
      <div class="list-content">
        <PanelTitle title="授权代理商"></PanelTitle>
        <div class="top-box">
          <p class="f12"><span class="grey">代理商名称：</span>{{agentName}}</p>
        </div>
        <PanelTitle title="授权商品" style="margin-bottom: 10px"></PanelTitle>
        <div class="panel">
          <el-form class="form" size="small" label-width="96px" type="flex" justify="space-between">
            <el-row style="overflow: initial;overflow: inherit;" type="flex" justify="space-between">
              <el-col class="category">
                <el-form-item label="品类：">
                  <DropdownTree ref="dropdownTree" @categoryInfo="getCategoryInfo" :width="'1120px'" :bodyWidth="'808px'" :interface="'authorizeManageSupplierCat'"></DropdownTree>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row type="flex" justify="space-between">
              <el-col class="seatchW-width">
                <el-form-item label="商品名/型号：">
                  <el-input v-model.trim="skuNameOrModel" placeholder="请输入关键词" maxlength="64" clearable></el-input>
                </el-form-item>
              </el-col>
              <el-col class="two_label">
                <el-form-item label="销量：">
                  <el-row>
                    <el-col>
                      <el-input v-model.trim="saleVolumeFor" placeholder="请输入销量" class="right_padding" maxlength="9" @input="saleVolumeFor=saleVolumeFor.replace(/[^\d.]/g,'')">
                        <div slot="suffix" class="suffix">件</div>
                      </el-input>
                    </el-col>
                    <el-col class="tc">-</el-col>
                    <el-col>
                      <el-input v-model.trim="saleVolumeTo" placeholder="请输入销量" class="right_padding" maxlength="9" @input="saleVolumeTo=saleVolumeTo.replace(/[^\d.]/g,'')">
                        <div slot="suffix" class="suffix">件</div>
                      </el-input>
                    </el-col>
                  </el-row>
                </el-form-item>
              </el-col>
              <el-col class="two_label">
                <el-form-item label="价格：">
                  <el-row>
                    <el-col>
                      <el-input v-model.trim="priceFor" placeholder="请输入金额" class="right_padding" maxlength="9" @input="priceFor=priceFor.replace(/[^\d.]/g,'')">
                        <div slot="suffix" class="suffix">元</div>
                      </el-input>
                    </el-col>
                    <el-col class="tc">-</el-col>
                    <el-col>
                      <el-input v-model.trim="priceTo" placeholder="请输入金额" class="right_padding" maxlength="9" @input="priceTo=priceTo.replace(/[^\d.]/g,'')">
                        <div slot="suffix" class="suffix">元</div>
                      </el-input>
                    </el-col>
                  </el-row>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="商品模式：" class="radio1">
                  <el-radio-group v-model="prodMobel">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'BASE_PROD'">基础商品</el-radio>
                    <el-radio :label="'COM_PROD'">组价商品</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
              <el-col :span="8" style="margin-left: 35px;">
                <el-form-item label="状态：" class="radio1">
                  <el-radio-group v-model="prodStatus">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'1'">已授权</el-radio>
                    <el-radio :label="'0'">未授权</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>

          </el-form>
          <el-row>
            <el-col :span="24" align="center">
              <el-button class="small-btn" type="primary" size="small" @click="search()">搜索</el-button>
              <el-button class="small-btn" size="small" @click="clear()">清除</el-button>
            </el-col>
          </el-row>
        </div>
        <TableThead :TopDistance="620">
          <tr slot="tr">
            <td width="90px" class="checkbox">序号</td>
            <td style="padding-left: 81px">商品名称/型号</td>
            <td width="150px" class="tr">单价(不含税)(元)</td>
            <td width="180px" class="tr">销量</td>
            <td width="240px" style="padding-left: 50px">品类</td>
            <td width="140px" style="padding-left: 50px">商品模式</td>
            <td class="tl" width="90px">状态</td>
          </tr>
        </TableThead>
        <table class="table-default">
          <thead>
            <tr>
              <td width="90px" class="checkbox">序号</td>
              <td style="padding-left: 81px">商品名称/型号</td>
              <td width="150px" class="tr">单价(不含税)(元)</td>
              <td width="180px" class="tr">销量</td>
              <td width="240px" style="padding-left: 50px">品类</td>
              <td width="140px" style="padding-left: 50px">商品模式</td>
              <td class="tl" width="90px">状态</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in awredSpuBeans" :key="ind">
            <tr>
              <td>
                <el-checkbox v-model="item.checkbox" @change="checkChange(item)"></el-checkbox>
                {{(ind+1)+pageSize*(pageIndex-1)}}
              </td>
              <td style="display: flex;align-items: center;">
                <div class="skuName">
                  <div class="attachImg" :class="{'active':!item.attUrl}">
                    <img v-if="item.attUrl" :src="item.attUrl" alt="">
                  </div>
                  <div class="model">
                    <p class="f12 ellipsisTwo hover-underline hand" :title="item.skuName" @click="handleGoproduct(item)">{{item.skuName}}</p>
                    <p class="f12" style="margin-top: 10px">型号：{{item.model ? item.model : '-'}}</p>
                    <div class="tag bg-lightSteelBlue" style="width: 70px" v-if="item.isSurchangeFlag === '1'">含附加项</div>
                  </div>
                </div>
              </td>
              <td class="tr">{{item.skuPrice | formatMoney}}</td>
              <td class="tr">{{item.salesVolume + (item.goodsUnit || '')}}</td>
              <td style="padding-left: 50px">{{item.fullName}}</td>
              <td style="padding-left: 50px">{{item.tagName}}</td>
              <td class="tl">
                <p class="f12">{{item.grantExplain}}</p>
              </td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!awredSpuBeans.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
        </div>
        <div class="table-pagination" v-if="awredSpuBeans.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <FixBottom>
      <div class="flex">
        <div style="line-height: 35px;">
          <el-checkbox v-model="checkboxAll" :disabled="!awredSpuBeans.length" style="margin: 0 10px;color: #fff" @change="checkAllChange">全选</el-checkbox>
        </div>
        <div>
          <el-button @click="handleGoBack">取消</el-button>
          <el-button :disabled="!(checkList.length && !checkList.every(i=> i.grantStatus == '0'))" @click="handleAuthorize('0')">批量取消授权</el-button>
          <el-button type="primary" :disabled="!(checkList.length && !checkList.every(i=> i.grantStatus == '1'))" @click="handleAuthorize('1')">批量授权</el-button>
        </div>
      </div>
    </FixBottom>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import SearchBar from "@/components/SearchBar";
import Header from "@/components/base/Header";
import Breadcrumb from "@/components/base/Breadcrumb";
import FixBottom from "@/components/base/FixBottom";
import DropdownTree from "@/components/order/dropdownTreeTender";
import TableThead from "@/components/base/TableThead";
export default {
  components: {
    Loading, PanelTitle, SearchBar, Header, Breadcrumb, FixBottom, DropdownTree, TableThead
  },
  data() {
    return {
      isLoading: false,
      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码
      breadcrumb: [],

      licensingCorpList: [],
      checkList: [],
      supplierId: '',
      agentId: '',
      agentName: '',
      categoryIds: '',
      skuNameOrModel: '',//商品名/型号
      saleVolumeFor: '',//销量开始值
      saleVolumeTo: '',//销量截至值
      priceFor: '',//价格开始值
      priceTo: '',//价格截至值
      prodMobel: '',//商品模式
      prodStatus: '',//商品状态（1-已授权，0-未授权）
      awredSpuBeans: [],
      checkboxAll: false,
    };
  },
  methods: {
    handleGoBack() {
      this.$confirm(
        '是否离开此页面？',
        '离开',
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          // type: 'warning',
          confirmButtonText: "离开",
          cancelButtonText: '取消',
        }).then(() => {
          window.opener = null;
          window.close();
        }).catch(() => {
        });
    },
    handleGoproduct(item) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: item.spuId,
          skuId: item.skuId
        }
      }).href, '_blank')
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.authorizeManageSupplierPro()
      window.scrollTo(0, 0)
    },
    // 获取招标品类
    getCategoryInfo(info) {
      console.log(info)
      let categoryIds = []
      info.forEach(f => {
        // 入参处理
        categoryIds.push(f.categoryId)
      })
      this.categoryIds = categoryIds.join(',')
    },
    // 单选
    checkChange(item) {
      if (item.checkbox) {
        this.checkList.push({ skuId: item.skuId, spuId: item.spuId, grantStatus: item.grantStatus })
      } else {
        this.checkList.splice(this.checkList.findIndex(j => j.skuId === item.skuId && j.spuId === item.spuId), 1)
      }
      // console.log(this.checkList)
      this.checkAllSelect()
    },
    // 全选
    checkAllChange() {
      this.awredSpuBeans.forEach(i => {
        // if (i.isGrantOpr === '1') {
        this.$set(i, 'checkbox', this.checkboxAll)
        if (this.checkboxAll) {
          this.checkList.push({ skuId: i.skuId, spuId: i.spuId, grantStatus: i.grantStatus })
        } else {
          this.checkList.splice(this.checkList.findIndex(j => j.skuId === i.skuId && j.spuId === i.spuId), 1)
        }
        // }
      });
      // 数组对象去重
      let obj = {};
      this.checkList = this.checkList.reduce((cur, next) => {
        obj[next.skuId] ? "" : obj[next.skuId] = true && cur.push(next);
        return cur;
      }, [])
      console.log(this.checkList)
    },
    // 是否全选
    checkAllSelect() {
      this.checkboxAll = this.awredSpuBeans.every(item => {
        return item.checkbox;
      });
      if (!this.awredSpuBeans.length) {
        this.checkboxAll = false
      }
    },
    handleAuthorize(handleType) {

      let content = handleType === '0' ? `你已勾选${this.checkList.length}条商品，请确认是否批量取消授权` : `你已勾选${this.checkList.length}条商品，请确认是否批量授权`
      this.$confirm(
        content,
        handleType === '0' ? "批量取消授权" : "批量授权",
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          type: 'warning',
          confirmButtonText: handleType === '0' ? "确认批量取消授权" : "确认批量授权",
          cancelButtonText: '取消',
        }).then(() => {
          this.authorizeManageSupplierAut(handleType)
        }).catch(() => {
        });
    },
    // 授权管理-厂家商品授权或取消授权
    authorizeManageSupplierAut(handleType) {
      let param = {
        agentId: this.agentId,
        spuSkuBeanList: this.checkList,
        handleType: handleType,
      }
      InterfaceService.authorizeManageSupplierAut(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('操作成功');
          this.checkList = []
          this.search()
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 授权管理-厂家商品列表
    authorizeManageSupplierPro() {
      let param = {
        supplierId: this.supplierId,
        agentId: this.agentId,
        categoryIds: this.categoryIds,
        skuNameOrModel: this.skuNameOrModel,
        saleVolumeFor: this.saleVolumeFor,
        saleVolumeTo: this.saleVolumeTo,
        priceFor: this.priceFor,
        priceTo: this.priceTo,
        prodMobel: this.prodMobel,
        prodStatus: this.prodStatus,
        pageIndex: this.pageIndex,
      }

      InterfaceService.authorizeManageSupplierPro(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.awredSpuBeans = data.respData.awredSpuBeans || []
          this.awredSpuBeans.forEach(i => {
            this.$set(i, 'checkbox', false)
            this.checkList.forEach(j => {
              if (j.skuId === i.skuId && j.spuId === i.spuId) {
                this.$set(i, 'checkbox', true)
              }
            })
          });
          this.checkAllSelect()
          this.total = data.respData.totalCount
          this.pageSize = data.respData.pageSize
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    search() {
      this.pageIndex = 1
      this.authorizeManageSupplierPro()
    },
    clear() {
      this.categoryIds = ''//品类
      this.skuNameOrModel = ''//商品名/型号
      this.saleVolumeFor = ''//销量开始值
      this.saleVolumeTo = ''//销量截至值
      this.priceFor = ''//价格开始值
      this.priceTo = ''//价格截至值
      this.prodMobel = ''//商品模式
      this.prodStatus = ''//商品状态（1-已授权，0-未授权）
      this.$refs.dropdownTree.clear()

      this.pageIndex = 1
      this.authorizeManageSupplierPro()
    },
    init() {
      this.supplierId = this.$store.state.userInfo.corpId
      this.agentId = this.$route.query.agentId
      this.agentName = this.$route.query.agentName
      this.authorizeManageSupplierPro()
    },
  },
  mounted() {
    this.init()
    this.breadcrumb = [
      { name: '管理中心', path: '/vendorCenter/accountInfo' },
      { name: '代理商/经销商列表', path: '/vendorCenter/agentManagement' },
      { name: '授权管理' },
    ];
  },
  destroyed() {
  }
};
</script>

<style lang="scss" scoped>
/deep/ .seatchW-width {
  &.el-col-24 {
    width: inherit;
    width: initial;
  }
}
/deep/ .category {
  .el-form-item__label {
    width: 50px !important;
  }
  .el-form-item__content {
    margin-left: 50px !important;
  }
}
/deep/ .el-date-editor.el-input,
.el-select,
.el-date-editor.el-input__inner {
  width: 100%;
}
/deep/ .right_padding {
  .el-input__inner {
    padding-right: 30px;
  }
  .suffix {
    color: #444;
    margin-right: 4px;
  }
}
/deep/ .two_label {
  display: flex;
  justify-content: flex-end;
  &.el-col-24 {
    width: inherit;
    width: initial;
  }
  .el-col {
    width: 110px;
    &:nth-child(2) {
      width: 20px;
    }
  }
  .el-form-item__label {
    width: 90px !important;
  }
  .el-form-item__content {
    margin-left: 90px !important;
  }
}
/deep/ .radio1 {
  .el-form-item__label {
    width: 76px !important;
  }
  .el-form-item__content {
    margin-left: 76px !important;
  }
}
/deep/ .radio2 {
  .el-form-item__label {
    width: 50px !important;
  }
  .el-form-item__content {
    margin-left: 50px !important;
  }
}
.flex {
  display: flex;
  justify-content: space-between;
}
.authorizeManage {
  /*width: 950px;*/
  margin: 0 auto;
  padding-bottom: 60px;
  .list-content {
    .top-box {
      width: 100%;
      padding: 0 0 20px;
    }
    .panel {
      background-color: #fff;
      background: rgba(249, 249, 249, 1);
      padding: 20px 10px;
      margin: 10px 0 30px;
    }

    .table-default {
      td {
        .skuName {
          display: flex;
          .attachImg {
            width: 60px;
            height: 60px;
            min-width: 60px;
            position: relative;
            overflow: hidden;
            &.active {
              background-color: #eee;
            }
            > img {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              pointer-events: none;
              height: auto;
            }
          }
          .model {
            margin-left: 6px;
          }
        }
      }
    }
  }
}
</style>
