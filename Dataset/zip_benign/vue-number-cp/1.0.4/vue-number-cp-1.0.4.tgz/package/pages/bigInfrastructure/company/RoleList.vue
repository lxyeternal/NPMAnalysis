<template>
  <div class="users">
    <RoleManage></RoleManage>
  </div>
</template>

<script>
  import {
    InterfaceService
  } from "@/services/api";
  import RoleManage from "@/components/account/RoleManage";


  export default {
    components: {
      RoleManage
    },
    data() {
      return {

      };
    },
    methods: {

    },
    mounted() {
    }
  };
</script>

<style lang="scss" scoped>

</style>