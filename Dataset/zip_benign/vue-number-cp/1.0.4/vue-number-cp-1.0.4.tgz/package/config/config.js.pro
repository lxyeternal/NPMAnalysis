const ROOT_URL = 'https://mall.dajiacai.net';
const OSS_SERVICE_ADDRESS = "https://osscdn.dajiacai.net"
let BASE_CONFIG = {
    // 服务地址、页面地址
    ROOT_URL : ROOT_URL,
    // 接口超时断开时间
    REQUEST_TIMEOUT : '60000',
    // 弹窗消息延时时间
    MESSAGE_DURATION : '1500',
    // autofocus延时时间
    AUTOFOCUS_DURATION : '500',
    // modal关闭延时时间
    CLOSE_MODAL_DURATION : '200',
    // Key
    CRYPTO_KEY : 'HOPERUNFHDXLLSLZ',
    CRYPTO_KEY_OPEN : true,
    OFFICIAL_URL : "http://www.dajiacai.net",

    ATTACH_ADDRESS:ROOT_URL + '/front/downloadFile',
    // 图片验证码服务地址
    IMAGE_SERVLET : ROOT_URL + '/front/getRandomCode',
    // 主服务地址
    SERVICE_ADDRESS : ROOT_URL + '/front/mainactivity',
    //oss 阿里云的文件上传服务器
    OSS_SERVICE_ADDRESS:OSS_SERVICE_ADDRESS,
    OSS_CATEGORY:OSS_SERVICE_ADDRESS+"/djc/statics/category/pd_category_info.json",
    OSS_HOT_PRODUCT:OSS_SERVICE_ADDRESS+"/product/statics/homePageProduct.json",
    OSS_EXTRA_CONFIG:OSS_SERVICE_ADDRESS+"/djc/statics/extraConfig/extra_config.json",
    //CND 文件服务器
    STATICS_CDN_URL:'https://procdn.dajiacai.net',
    // confluence 密码
    OS_PASSWORD: 'Pass112233',
};
export {BASE_CONFIG};

