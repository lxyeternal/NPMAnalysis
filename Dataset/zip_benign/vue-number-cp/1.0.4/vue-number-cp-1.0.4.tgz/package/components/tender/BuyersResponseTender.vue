<template>
  <div class="buyersAnswerQuestions">
    <div class="list-home">
      <div class="list-content">
        <div class="panel">
          <el-form class="form" size="small">
            <div style="display: inline-block;width: 35.5%;">
              <el-form-item label="供应商：" label-width="80px">
                <el-input v-model.trim="form.supplierCorpName" placeholder="请输入关键词"></el-input>
              </el-form-item>
            </div>
            <div style="display: inline-block;width: 35.5%;">
              <el-form-item label="回标时间：" label-width="80px">
                <el-date-picker type="date" placeholder="选择日期" value-format="yyyy-MM-dd" v-model="form.submitBidTmFrom" style="width: 100%;" @change="handleChangeStartTm"></el-date-picker>~
                <el-date-picker :picker-options="pickerOptionsEnd" type="date" placeholder="选择日期" value-format="yyyy-MM-dd" v-model="form.submitBidTmTo" style="width: 100%;"></el-date-picker>
              </el-form-item>
            </div>
            <div style="display: inline-block;width: 35.5%;">
              <el-form-item label="回标情况：" label-width="80px">
                <el-radio-group v-model="form.submitBidFlg" @change="handleSearch">
                  <el-radio label="2">全部</el-radio>
                  <el-radio label="0">未回标</el-radio>
                  <el-radio label="1">已回标</el-radio>
                </el-radio-group>
              </el-form-item>
            </div>
            <div style="display: inline-block;width: 34.5%;">
              <el-form-item label="下载招标文件：" label-width="110px">
                <el-radio-group v-model="form.bidAttachDownloadFlg" @change="handleSearch">
                  <el-radio label="2">全部</el-radio>
                  <el-radio label="0">未下载</el-radio>
                  <el-radio label="1">已下载</el-radio>
                </el-radio-group>
              </el-form-item>
            </div>
            <div style="display: inline-block;width: 29%;" v-if="timeOut">
              <el-form-item label="标记通过情况：" label-width="110px">
                <el-radio-group v-model="form.keyMarkFlg" @change="handleSearch">
                  <el-radio label="2">全部</el-radio>
                  <el-radio label="0">未标记</el-radio>
                  <el-radio label="1">已标记</el-radio>
                </el-radio-group>
              </el-form-item>
            </div>
          </el-form>
          <el-row class="tc">
            <el-button type="primary" class="small-btn" @click="handleSearch">
              搜索
            </el-button>
            <el-button class="small-btn" @click="handleClear">
              清空
            </el-button>
          </el-row>
        </div>
        <div class="list-box">
          <div class="batch-select">
            <div class="fl" style="width: 85%;padding:0 10px;">
              <template v-if="timeOut">
                <!--<template>-->
                <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow" :disabled="!submitBidList.filter(i=>{return i.submitBidFlg === '1'}).length">全选</el-checkbox>
                <el-button class="small-btn" :disabled="!hasChecked || !submitBidList.length" @click="handleKeyMark('0')">批量标记通过</el-button>
                <el-button class="small-btn" :disabled="!hasChecked || !submitBidList.length" @click="handleKeyMark('1')">批量取消标记通过</el-button>
                <el-button class="small-btn" size="primary" :disabled="!hasChecked || !submitBidList.length || !batchDownloadFlg" @click="handleDownload('')">批量下载投标文件</el-button>
              </template>
              <template v-if="downloadFlg">
                <!--<template>-->
                <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow" :disabled="!submitBidList.filter(i=>{return i.submitBidFlg === '1'}).length">全选</el-checkbox>
                <el-button class="small-btn" size="primary" :disabled="!hasChecked || !submitBidList.length || !batchDownloadFlg" @click="handleDownload('')">批量下载投标文件</el-button>
              </template>
              <label :style="{'padding-left': timeOut ? '80px' : '0'}">回标数量：</label><span>{{submitBidCnt}}家</span>
              <label style="padding-left: 64px;">下载招标文件数：</label><span>{{attachDownloadCnt}}家</span>
            </div>
            <div class="fr tr" style="width: 15%;" v-if="timeOut">
              <el-button class="small-btn" :disabled="!submitBidList.length" @click="handleGetResumeOfReBidding()">重新回标履历</el-button>
            </div>
            <div style="clear:both;"></div>
          </div>
          <div class="list-content">
            <table>
              <thead>
                <tr>
                  <td width="34px" v-if="timeOut || downloadFlg">
                    &nbsp;
                  </td>
                  <td width="48px">序号</td>
                  <td width="475px">供应商</td>
                  <td width="207px">回标状况</td>
                  <td width="186px">是否已下载招标文件</td>
                  <td width="128px">最新回标时间</td>
                  <td v-if="timeOut || downloadFlg" class="tr">操作</td>
                  <!--<td>操作</td>-->
                </tr>
              </thead>
              <tbody v-for="(item,ind) in submitBidList" :key="ind" class="tbody-row">
                <tr>
                  <td v-if="timeOut || downloadFlg">
                    <el-checkbox :disabled="item.submitBidFlg !== '1'" v-model="item.checked" @change="handleSelectTableRow(item,ind)"></el-checkbox>
                  </td>
                  <td>{{pageSize * (pageIndex-1)  + ind + 1}}</td>
                  <td>
                    <span style="display: inline-block;width: 339px;">
                      <em class="hand blue" v-if="item.supplierStatus != '' && item.supplierStatus != 3 && item.selectStatus=='1'" @click="openNewPage(item.supplierCorpId,bidNo,item.submitBidNo)">{{item.supplierCorpName}}</em>
                      <em class="hand blue" v-else-if="item.supplierStatus != '' && item.supplierStatus != 3 && item.selectStatus=='0'" @click="openNewPage(item.supplierCorpId,bidNo)">{{item.supplierCorpName}}</em>
                      <em v-else>{{item.supplierCorpName}}</em>
                    </span>
                    <div>
                      <TagSourceList :corpTagList="item.corpTagList" @getData="buyersResponseTenderList"></TagSourceList>
                      <div class="signed" v-if="item.keyMarkFlg == '1'">标记通过</div>
                    </div>
                  </td>
                  <td>{{item.submitBidFlg === '1' ? "已回标" : "未回标"}}</td>
                  <td>{{item.bidAttachDownloadFlg === '1' ? "√" : ""}}</td>
                  <td>
                    <span style="display: inline-block;width: 68px;">
                      {{item.lastSubmitBidTm}}
                    </span>
                  </td>
                  <td v-if="timeOut" class="tr">
                    <!--<td>-->
                    <template v-if="item.submitBidFlg === '1'">
                      <p><span v-if="item.submitBidAttachList && item.submitBidAttachList.length" class="hand blue" @click="handleDownload(item.supplierCorpName,item.submitBidAttachList)">下载投标文件</span></p>
                      <p><span class="hand blue" @click="handleKeyMark(item.keyMarkFlg,item.submitBidNo)">{{item.keyMarkFlg == '1' ? "取消标记通过" : "标记通过"}}</span></p>
                      <p><span class="hand blue" v-if="isSupplyPicture == '1'" @click="openBuyersProductList(item.submitBidNo)">查看商品清单</span></p>
                    </template>
                  </td>
                  <td v-if="downloadFlg" class="tr">
                    <template v-if="item.submitBidFlg === '1'">
                      <p><span v-if="item.submitBidAttachList && item.submitBidAttachList.length" class="hand blue" @click="handleDownload(item.supplierCorpName,item.submitBidAttachList)">下载投标文件</span></p>

                    </template>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <!-- 空列表 -->
        <!--<div class="accout-empty" v-if="submitBidList.length == 0">-->
        <!--<img src="@/assets/images/icon-no-product.png">-->
        <!--<p>暂无公告！</p>-->
        <!--</div>-->
        <!-- 分页 -->
        <div class="table-pagination" v-if="submitBidList.length != 0">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <ResumeOfReBiddingDia ref="ResumeOfReBiddingDia"></ResumeOfReBiddingDia>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import UpfileComponent from "@/components/tender/upfileComponent";
import ResumeOfReBiddingDia from "@/components/tender/dialog/ResumeOfReBiddingDia";
import { viewFile } from '@/utils/orderUtil';
import TagSourceList from "@/components/tender/Prequalifica/tagSourceList";
const form = {
  supplierCorpName: '',
  submitBidFlg: '2',
  bidAttachDownloadFlg: '2',
  keyMarkFlg: '2',
  submitBidTmFrom: null,
  submitBidTmTo: null,
};
export default {
  components: {
    Loading,
    UpfileComponent,
    ResumeOfReBiddingDia,
    TagSourceList,
  },
  props: ['timeOut', 'isSupplyPicture','downloadFlg'],
  watch: {
    timeOut(newVal) {
      console.log(this.timeOut);
      if (newVal) {
        this.buyersResponseTenderList()
      }
    }
  },
  computed: {
    batchDownloadFlg() {
      let onOff = false;
      this.submitBidList.forEach(i => {
        if (i.checked) {
          if (i.submitBidAttachList && i.submitBidAttachList.length) {
            onOff = true
          }
        }
      })
      return onOff
    }
  },
  data() {
    return {
      isLoading: false,
      signed: false,
      allChecked: false,
      hasChecked: false,
      pickerOptionsEnd: {
        disabledDate: time => {
          if (this.form.submitBidTmFrom) {
            return time.getTime() <= new Date(this.form.submitBidTmFrom).getTime() - 86400000
          }
        }
      },
      submitBidList: [],
      bidNo: '',
      bidName: '',
      form: Object.assign({}, form),
      total: 0, //分页 总页数
      pageSize: 20, //分页 每页的长度
      pageIndex: 1, //当前页码
      attachDownloadCnt: 0,
      submitBidCnt: 0,
    };
  },
  methods: {
    openBuyersProductList(submitBidNo) {
      window.open(this.$router.resolve({
        path: "/buyersProductList",
        query: {
          bidName: this.bidName,
          submitBidNo: submitBidNo,
          bidNo: this.bidNo,
          tab: '7'
        }
      }).href, '_blank')
    },
    openNewPage(supplierCorpId, bidNo, submitBidNo) {
      window.open(this.$router.resolve({
        path: "/viewSupplierInfo",
        query: {
          corpId: supplierCorpId,
          bidNo: bidNo || '',
          submitBidNo: submitBidNo || ''
        }
      }).href, '_blank')
    },
    handleGetResumeOfReBidding() {
      let params = {
        bidNo: this.bidNo,
      };
      InterfaceService.resumeOfReBidding(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let resumeList = data.respData.bidSupplierResumes || [];
            if (!resumeList.length) {
              this.$message.error("暂无重新回标履历")
            } else {
              this.$refs['ResumeOfReBiddingDia'].open(resumeList)
            }
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    handleDownload(name, list) {
      let fileInfoBeans = [];
      if (name) {
        list.forEach(item => {
          if (item.attachUrl) {
            fileInfoBeans.push({
              archivePath: item.attachName,
              fileUrl: item.attachUrl,
            })
          }
        });
      } else {
        let list = [];
        this.submitBidList.forEach(item => {
          if (item.checked) {
            list.push(item)
          }
        });
        list.forEach(file => {
          if (file.submitBidAttachList && file.submitBidAttachList.length) {
            file.submitBidAttachList.forEach(bid => {
              if (bid.attachUrl) {
                fileInfoBeans.push({
                  archivePath: file.supplierCorpName + '/' + bid.attachName,
                  fileUrl: bid.attachUrl,
                })
              }
            })
          }
        })
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            // const files = [
            //   { name: name ? name + "投标文件.zip" : this.bidName + "投标文件.zip", url: url }
            // ];
            // this.$download(files, () => {this.isLoading = true}, () => {this.isLoading = false}).then(() => {
            //   this.$message.success("已下载");
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: name ? name + "投标文件.zip" : this.bidName + "投标文件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
            if (!name) {
              this.submitBidList.forEach(item => {
                item.checked = false
              })
            }
            this.allChecked = false;
            this.checkBatch();
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    handleKeyMark(currentMarkFlg, submitBidNo) {
      let param = {};
      let submitBidNoList = [];
      let keyMarkFlg = currentMarkFlg == '1' ? '0' : '1';
      if (submitBidNo) {
        submitBidNoList.push(submitBidNo)
      } else {
        this.submitBidList.forEach(item => {
          if (item.checked) {
            submitBidNoList.push(item.submitBidNo)
          }
        })
      }
      param = {
        submitBidNoList,
        keyMarkFlg,
        bidNo: this.bidNo
      };
      InterfaceService.buyersMarkPassed(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success("操作成功!")
          this.buyersResponseTenderList();
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 选中行
    handleSelectTableRow(item, index) {
      this.$set(this.submitBidList, index, item);
      this.checkBatch();
      this.checkAllSelect();
    },
    // 是否全选
    checkAllSelect() {
      this.allChecked = this.submitBidList.filter(i => { return i.submitBidFlg === '1' }).every(item => {
        return item.checked;
      });
    },
    handleChangeStartTm(ev) {
      console.log(ev);
      if (new Date(ev) > new Date(this.form.submitBidTmTo)) {
        this.form.submitBidTmTo = ""
      }
    },
    // 全选
    handleAllSelectTableRow(bool) {
      let arr = [];
      arr = [].concat(this.submitBidList);
      arr.forEach(item => {
        if (item.submitBidFlg === '1') {
          item.checked = bool;
        }
      });
      this.submitBidList = arr;
      this.checkBatch();
    },
    // 是否可批量
    checkBatch() {
      this.hasChecked = this.submitBidList.some(item => {
        return item.checked;
      });
    },
    handleSearch() {
      this.pageIndex = 1;
      this.buyersResponseTenderList()
    },
    handleClear() {
      this.form = Object.assign({}, form);
      this.pageIndex = 1;
      this.buyersResponseTenderList()
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      window.scrollTo(0, 0)
      this.buyersResponseTenderList()
    },
    buyersResponseTenderList() {
      let param = Object.assign({}, this.form);
      param.pageIndex = this.pageIndex;
      param.bidNo = this.bidNo;
      if (param.submitBidFlg == '2') {
        param.submitBidFlg = '';
      }
      if (param.bidAttachDownloadFlg == '2') {
        param.bidAttachDownloadFlg = '';
      }
      if (param.keyMarkFlg == '2') {
        param.keyMarkFlg = '';
      }
      InterfaceService.buyersResponseTenderList(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.submitBidList = data.respData.submitBidList || []
          this.submitBidList.forEach(i => {
            i.checked = false;
            if (i.corpTagList) {
              i.corpTagList.forEach(j => {
                this.$set(j, 'showRemark', false)
                this.$set(j, 'disabled', true)
                this.$set(j, 'showOperat', false)
              });
            }
          });
          this.allChecked = false;
          this.checkBatch();
          this.pageSize = +data.respData.pageSize || 0;
          this.total = +data.respData.totalCount || 0
          this.attachDownloadCnt = +data.respData.attachDownloadCnt || 0
          this.submitBidCnt = +data.respData.submitBidCnt || 0
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    init() {
      if(this.$parent){
        this.$parent.breadcrumb.push({ name: '回标/开标' })
      }
      this.bidNo = this.$route.query.bidNo || ''
      this.bidName = this.$route.query.bidName || ''
      // this.getDropDownList()
      this.buyersResponseTenderList()
    },
  },
  mounted() {
    this.init()
  },
};
</script>

<style lang="scss" scoped>
.list-box {
  margin-top: 20px;
}
.list-content {
  width: 1190px;
  margin: 0 auto;
  table {
    table-layout: fixed;
    width: 100%;
    line-height: 17px;
    font-size: 12px;
    td {
      padding: 20px 10px;
      vertical-align: middle;
      word-break: break-all;
      > p {
        line-height: 17px;
        & + p {
          margin-top: 4px;
        }
      }
    }

    thead {
      font-size: 14px;
      text-align: left;
      white-space: nowrap;
      background: #f9f9f9;
      border-bottom: 1px solid #eee;
    }
    .tbody-row {
      &:hover {
        background: #f0f8ff;
      }
    }
    tbody {
      text-align: left;
      tr {
        border-bottom: 1px solid #eee;
      }
      .border-none {
        border-bottom: none;
      }
    }
  }
  .signed {
    width: 76px;
    height: 20px;
    line-height: 20px;
    color: #fff;
    font-size: 14px;
    text-align: center;
    background: rgba(131, 11, 185, 1);
    border-radius: 2px;
    margin-top: 6px;
    display: inline-block;
  }
}
/deep/ .el-select {
  width: 100% !important;
}
/deep/ .el-form-item__label {
  padding: 0 !important;
  color: #888 !important;
}
/deep/ .seatchW-width {
  width: inherit;
  .el-form-item__content {
    width: 300px;
  }
}
/deep/ .business {
  .el-form-item__label {
    width: 52px !important;
  }
  .el-form-item__content {
    margin-left: 52px !important;
  }
}

.buyersAnswerQuestions {
  padding-bottom: 60px;
  .list-home {
    width: 1190px;
    margin: 0 auto;
    .box_steps {
      padding: 20px 0 30px;
      box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
    }
    .no-data {
      padding: 128px 100px;
      margin: 0 auto;
      text-align: center;
      font-size: 16px;
      line-height: 22px;
      color: #888;
    }
    .button-panel {
      .el-col {
        text-align: right;
      }
    }
    .list-content {
      margin: 10px 0;
      .panel {
        background: rgba(249, 249, 249, 1);
        padding: 20px 10px 20px 0px;
        .el-button + .el-button {
          margin-left: 18px;
        }
      }
    }
  }
  .el-select {
    width: 100%;
  }
  .table-pagination {
    margin: 24px 0 0;
    text-align: center;
    color: #888888;
  }
  .accout-empty {
    padding: 150px;
    text-align: center;
    line-height: 50px;
    color: #909399;
  }
}
/deep/ .batch-select {
  margin-bottom: 10px;
  .el-button {
    margin-left: 10px;
  }
  .el-checkbox {
    margin-right: 0px !important;
  }
  .el-checkbox__label {
    padding-left: 4px;
  }
}
.form {
  /deep/ .el-input {
    width: 300px;
  }
  /deep/ .el-date-editor {
    width: 140px !important;
    margin-right: 6px;
  }
}
</style>
