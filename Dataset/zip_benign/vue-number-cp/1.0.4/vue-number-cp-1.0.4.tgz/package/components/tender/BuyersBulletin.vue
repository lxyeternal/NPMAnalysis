<template>
  <div class="buyersAnswerQuestions">
    <div class="list-home">
      <!-- <div class="no-data" v-if="active==2">问题回答阶段未开始！</div> -->
      <!-- 列表操作按钮 -->
      <el-row class="button-panel">
        <el-col :span="24">
          <el-button class="btn" type="primary" size="small" @click="isEditBulletin='0';showBulletBox1=true">创建公告</el-button>
        </el-col>
      </el-row>

      <div class="list-content">
        <!-- tab栏 -->
        <div class="panel-switch">
          <ul>
            <li class="hand" :class="{active: publishStatus=='ANNOUNCED'}" @click="publishStatus='ANNOUNCED';clear();">待发布公告</li>
            <li class="hand" :class="{active: publishStatus=='PUBLISH'}" @click="publishStatus='PUBLISH';clear();">已发布公告</li>
          </ul>
          <div class="switch hand blue" @click="isShowPanel=!isShowPanel;isShowPanelChenge()">{{isShowPanel?'全部收起':'全部展开'}} <i class="arrow" :class="{active:!isShowPanel}"></i></div>
        </div>
        <!-- 刷选面板 -->
        <div class="panel">
          <el-form class="form" size="small" label-width="80px">
            <el-row>
              <el-col :span="24">
                <el-form-item label="主题搜索：">
                  <el-input v-model.trim="keyWord" placeholder="请输入关键词" maxlength="200" clearable></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="分类：" class="business">
                  <el-radio-group v-model="qaClassify" @change="search()">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'TECHNICALBID'">技术标</el-radio>
                    <el-radio :label="'COMMERCIALBID'">商务标</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24" class="form-btns" align="center">
                <el-button class="btn" type="primary" size="small" @click="search()">搜索</el-button>
                <el-button class="btn" size="small" @click="clear()">清除</el-button>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <div class="list-box">
          <el-row v-show="publishStatus=='ANNOUNCED'" class="list-operat">
            <el-col :span="24">
              <el-checkbox :disabled="!bidQAInfoList.length" v-model="checkboxAll" style="margin: 0 10px 0 0" @change="checkboxChange">全选</el-checkbox>
              <el-button class="btn" :disabled="isDisabled" :class="{'isDisabled':isDisabled}" size="small" @click="batchDel">批量删除</el-button>
              <el-button class="btn" :disabled="isDisabled" :class="{'isDisabled-primary':isDisabled}" type="primary" size="small" @click="batchRelease">批量发布</el-button>
            </el-col>
          </el-row>
          <ul class="replied" v-if="bidQAInfoList.length != 0">
            <li style="border: none" v-for="(a,ind) in bidQAInfoList" :key="ind">
              <!-- 多选 -->
              <div v-if="publishStatus=='ANNOUNCED'" class="checkbox">
                <el-checkbox v-model="a.checkbox" @change="checkboxChangeOne"></el-checkbox>
              </div>
              <div class="list-content-box">
                <!-- 公告问题· -->
                <div class="box" :class="{'isRelease':publishStatus=='ANNOUNCED'}">
                  <div class="header">
                    <div class="left">
                      <div class="number" :class="{'number-active':publishStatus=='PUBLISH'}">{{total-ind-pageSize*(pageIndex-1)}}</div>
                      <h1><span>【公告】主题：</span>{{a.qaTheme}}</h1>
                      <div v-if="a.tipQA=='1'" class="top-tag">置顶</div>
                    </div>
                    <div class="right">
                      <p>类别：<span>{{qaClassifyFilter(a.qaClassify)}}</span></p>
                      <div class="switch hand blue" @click="a.isShowPanel=!a.isShowPanel;isShowPanelChengeOne()">{{a.isShowPanel?'收起':'展开'}} <i class="arrow" :class="{active:!a.isShowPanel}"></i></div>
                    </div>
                  </div>
                  <!-- <transition name="el-zoom-in-top"> -->
                  <div class="content" v-show="a.isShowPanel">
                    <div class="left width1080">
                      <!-- 问题描述 -->
                      <div class="info" v-html="a.qaDescription"></div>
                    </div>
                    <div class="right">
                      <div class="operat" v-show="publishStatus=='PUBLISH' && active<=3">
                        <p class="hand blue" @click="delRetract([a.bidQaNo],'2')">撤回</p>
                      </div>
                      <div class="operat" v-show="publishStatus=='ANNOUNCED'">
                        <p class="hand blue" v-if="active<=3" @click="isEditBulletin='1';onBidQaNo = a.bidQaNo;buyersBulletinDetails(a.bidQaNo)">编辑</p>
                        <p class="hand blue" v-if="active<=3" @click="buyersBulletinOperat([a.bidQaNo],'1')">发布</p>
                        <p class="hand blue" @click="delRetract([a.bidQaNo],'3')">删除</p>
                      </div>
                    </div>
                  </div>
                  <!-- </transition> -->
                </div>
                <!-- 公告内容· -->
                <!-- <transition name="el-zoom-in-top"> -->
                <div class="box reply-content" :class="{'isRelease':publishStatus=='ANNOUNCED'}" v-show="a.isShowPanel">

                  <div class="content" v-for="(c,ind_c) in (a.qaAnswerInfoList || [])" :key="ind_c">
                    <div class="left">
                      <div class="info">
                        <div class="left">
                          <span class="underline">回复</span>
                        </div>
                        <div class="right" v-html="c.answerDescription"></div>
                      </div>
                      <div class="dotted-line"></div>
                      <div class="quiz">
                        <div class="annex"><span class="bold">附件：</span>
                          <div v-if="!c.qaAnswerAttachInfoList.length">
                            <p class="annex-file grey">暂无附件</p>
                          </div>
                          <div v-else>
                            <p v-for="(d,ind_d) in c.qaAnswerAttachInfoList" :key="ind_d" class="annex-file">{{d.attachName}} <span class="hand blue" @click="handleDownTemp(d.attachName,d.attachUrl)">下载</span></p>
                          </div>
                        </div>
                        <p class="grey">{{publishStatus=='ANNOUNCED'?'创建':'发布'}}时间：{{publishStatus=='ANNOUNCED'?(c.createTime && c.createTime.substring(0,19)):(c.publishTime && c.publishTime.substring(0,19))}}</p>
                      </div>
                    </div>
                  </div>

                </div>
                <!-- </transition> -->
              </div>
            </li>
          </ul>
        </div>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="bidQAInfoList.length == 0">
          <img src="@/assets/images/icon-no-product.png">
          <p>暂无公告！</p>
        </div>
        <!-- 分页 -->
        <div class="table-pagination" v-if="bidQAInfoList.length != 0">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <!-- 创建公告弹框 -->
    <el-dialog class="dialog dialog-drafts" :title="isEditBulletin == '0'?'创建公告':'编辑公告'" :append-to-body="true" :lock-scroll="true" :visible.sync="showBulletBox1" width="840px" center :close-on-click-modal="false" @close="close()">
      <div class="drafts-list tl">
        <el-form class="form" size="small" label-width="118px" :model="form" :rules="rules" ref="formBulletBox2">
          <div class="order-info-title">问题</div>
          <el-row>
            <el-col :span="24">
              <el-form-item label="【公告】主题：" prop="qaTheme">
                <el-input v-model.trim="form.qaTheme" placeholder="请输入标题，限54字" maxlength="54" clearable></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col style="width: 518px">
              <el-form-item label="分类：" prop="qaClassify">
                <el-select v-model="form.qaClassify" placeholder="请选择" clearable>
                  <el-option v-for="item in configList" :key="item.code" :label="item.value" :value="item.code">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="描述内容：">
                <el-input class="claim" type="textarea" placeholder="请输入详细描述" v-model="form.qaDescription" maxlength="200">
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <div class="order-info-title">回答</div>
          <el-row>
            <el-col :span="24">
              <el-form-item label="回答内容：" prop="answerDescription">
                <el-input class="claim" type="textarea" placeholder="请输入回答内容" v-model="form.answerDescription" maxlength="200">
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <div class="uploadFileList">
            <div class="title-info">
              <p>附件</p><span class="hand blue" @click="$refs.upfileRef.open()">上传</span>
            </div>
            <div class="fileList">
              <p class="noData" v-if="files.length == 0">未上传附件！</p>
              <p v-for="(item,ind_t) in files" :key="ind_t">{{item.attachName}}<span class="hand blue" @click="handleView(item.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(item.attachName,item.attachUrl)">下载</span><span class="hand blue" @click="delFiles(ind_t)">删除</span></p>
            </div>
          </div>
          <el-row>
            <el-col :span="8">
              <el-form-item label="本公告是否置顶：">
                <el-radio-group v-model="form.isTop">
                  <el-radio :label="'1'">是</el-radio>
                  <el-radio :label="'0'">否</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="editBulletin('1')">发布</div>
        <div class="clearBtn" @click="editBulletin('0')">保存</div>
        <div class="clearBtn" @click="showBulletBox1=false;close()">取消</div>
      </div>
    </el-dialog>
    <!-- 上传附件 -->
    <UpfileComponent ref="upfileRef" :immediateClearList="true" :btnName="'选择文件'" :dirName="`${new Date().getTime()}/`" :type="'10'" :fileTypes="''" :id="'123'" @outputList="handleUpFileResult($event)"></UpfileComponent>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import UpfileComponent from "@/components/tender/upfileComponent";
import { viewFile } from '@/utils/orderUtil';

export default {
  components: {
    Loading,
    UpfileComponent,
  },
  data() {
    return {
      isLoading: false,

      checkboxAll: false,
      isEditBulletin: '0',// 0创建，1编辑
      showBulletBox1: false, // 创建公告

      bidQAInfoList: [],
      publishStatus: 'ANNOUNCED', // 是否发布 'ANNOUNCED'">待发布 'PUBLISH'">已发布
      keyWord: '',// 主题搜索
      qaClassify: '',

      configList: [],//分类
      form: {
        qaTheme: '',
        qaClassify: '',
        qaDescription: '',
        answerDescription: '',
        isTop: '1',
      },
      rules: {
        qaTheme: [
          { required: true, message: '请输入标题，限54字', trigger: 'blur' }
        ],
        qaClassify: [
          { required: true, message: '请选择', trigger: 'change' }
        ],
        answerDescription: [
          { required: true, message: '请输入回答内容', trigger: 'blur' }
        ],
      },
      files: [], // 弹框附件列表
      delFileList: [],//删除的附件

      bidName: '',
      isDisabled: true, // 批量操作是否置灰
      isShowPanel: true, // 面板是否展开

      onBidQaNo: '', //提问编号

      total: 0, //分页 总页数
      pageSize: 20, //分页 每页的长度
      pageIndex: 1, //当前页码

      bidNo: '',//	招标编号
    };
  },
  methods: {
    goBuyersQuestions() {
      if (this.active >= 3) { // 回复问题
        this.$router.push({ path: '/buyersAnswerQuestions', query: { 'bidNo': this.bidNo, 'bidName': this.bidName } })
      } else {
        this.$router.push({ path: '/buyersCollectQuestions', query: { 'bidNo': this.bidNo, 'bidName': this.bidName } })
      }
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      window.scrollTo(0, 0)
      this.buyersCollectQuestions()
    },
    // 是否全部展开关闭
    isShowPanelChenge() {
      this.bidQAInfoList.forEach(i => {
        this.$set(i, 'isShowPanel', this.isShowPanel)
      });
    },
    // 单点收起展开
    isShowPanelChengeOne() {
      const a = this.bidQAInfoList.filter(i => i.isShowPanel == true)
      if (a.length == 0) {
        this.isShowPanel = false
      } else {
        this.isShowPanel = true
      }
    },
    // 过滤分类
    qaClassifyFilter(code) {
      let a = this.configList.filter(i => i.code === code)
      if (a.length) {
        return a[0].value
      } else {
        return ''
      }

    },
    // 采购商公告列表
    buyersCollectQuestions() {
      let param = {
        bidNo: this.bidNo, //	招标编号
        supplierCorpName: this.supplierCorpName, //	供应商名
        keyWord: this.keyWord, //	关键字
        pageIndex: String(this.pageIndex),//	页码
        qaClassify: this.qaClassify, //	问题分类
        answerStatus: '', //	回复状态(配置在pd_product_config，已回复，未回复)
        publishStatus: this.publishStatus, //	发布状态(配置在pd_product_config，待发布，已发布)
        qaType: 'NOTICE', //	问题类型（配置在pd_product_config，问题，公告）

      }
      InterfaceService.buyersCollectQuestions(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.bidQAInfoList = data.respData.bidQAInfoList || []
          this.bidQAInfoList.forEach(i => {
            this.$set(i, 'isShowPanel', true)
            this.$set(i, 'checkbox', false)
          });
          this.isShowPanel = true
          this.total = data.respData.totoalCount
          this.pageSize = data.respData.pageSize

          this.checkboxAll = false
          window.scrollTo(0, 0)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 公告分类
    getDropDownList() {
      let param = {
        groupId: 'QA_CLASSIFY'
      }
      InterfaceService.getDropDownList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.configList = data.respData.configList
          console.log(data.respData)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 是编辑还是创建
    editBulletin(handleType) {
      if (this.isEditBulletin == '0') { //回复
        this.buyersCreateBulletin(handleType)
      } else {
        this.buyersBulletinEdit(handleType)
      }
    },
    // 编辑公告详情
    buyersBulletinDetails(bidQaNo) {
      let param = {
        bidQaNo: bidQaNo,//	提问编号
      }
      InterfaceService.buyersBulletinDetails(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          let obj = data.respData
          this.form.qaTheme = obj.qaTheme
          this.form.qaClassify = obj.qaClassify
          this.form.isTop = obj.isTop
          this.form.qaDescription = obj.qaDescription || ''
          this.form.qaDescription = this.form.qaDescription.replace(/<br\/>/g, '\n')
          this.form.answerDescription = obj.answerDescription || ''
          this.form.answerDescription = this.form.answerDescription.replace(/<br\/>/g, '\n')
          this.files = obj.qaAttachInfoList

          this.showBulletBox1 = true
          this.onBidQaNo = bidQaNo
          console.log(data.respData)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 编辑公告
    buyersBulletinEdit(handleType) {
      this.$refs['formBulletBox2'].validate((valid) => {
        if (valid) {
          let qaAttachInfoList = []
          this.files.forEach(i => {
            if (!i.ossFileId && i.filesUrl) {
              qaAttachInfoList.push({
                attachName: i.attachName,
                attachPath: i.filesUrl,
              })
            }
          });
          if (this.delFileList != 0) {
            this.delFileList.forEach(i => {
              qaAttachInfoList.push({
                ossFileId: i
              })
            });
          }
          this.form.qaDescription = this.form.qaDescription.replace(/\n/g, '<br/>')
          this.form.answerDescription = this.form.answerDescription.replace(/\n/g, '<br/>')

          let param = {
            bidQaNo: this.onBidQaNo,//	提问编号
            qaType: 'NOTICE',//	公告
            qaTheme: this.form.qaTheme,//	问题主题
            qaClassify: this.form.qaClassify,//	问题分类（配置在pd_product_config，技术标，商务标）
            qaDescription: this.form.qaDescription,//	问题描述
            answerDescription: this.form.answerDescription,//	回复描述
            qaAttachInfoList: qaAttachInfoList,//提问附件信息列表
            isTop: this.form.isTop,//	0不，1置顶
          }
          InterfaceService.buyersBulletinEdit(param, data => {
            this.isLoading = false;
            if (data && data.respData && data.respData.respCode === "0000") {
              if (handleType == '1') { //发布
                this.buyersBulletinOperat([this.onBidQaNo], handleType)
              } else {
                this.$message.success('保存成功')
                this.showBulletBox1 = false
                this.close()
                this.buyersCollectQuestions()
              }
            } else {
              this.form.qaDescription = this.form.qaDescription.replace(/<br\/>/g, '\n') || ''
              this.form.answerDescription = this.form.answerDescription.replace(/<br\/>/g, '\n') || ''
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    // 创建公告
    buyersCreateBulletin(handleType) {
      this.$refs['formBulletBox2'].validate((valid) => {
        if (valid) {
          let qaAttachInfoList = []
          this.files.forEach(i => {
            if (i.filesUrl) {
              qaAttachInfoList.push({
                attachName: i.attachName,
                attachPath: i.filesUrl,
              })
            }
          });
          this.form.qaDescription = this.form.qaDescription.replace(/\n/g, '<br/>')
          this.form.answerDescription = this.form.answerDescription.replace(/\n/g, '<br/>')

          let param = {
            bidNo: this.bidNo,//	招标编号
            qaType: 'NOTICE',//	公告
            qaTheme: this.form.qaTheme,//	问题主题
            qaClassify: this.form.qaClassify,//	问题分类（配置在pd_product_config，技术标，商务标）
            qaDescription: this.form.qaDescription,//	问题描述
            answerDescription: this.form.answerDescription,//	回复描述
            qaAttachInfoList: qaAttachInfoList,//提问附件信息列表
            isTop: this.form.isTop,//	0不，1置顶
            handleType: handleType,//	0保存，1发布
          }
          InterfaceService.buyersCreateBulletin(param, data => {
            this.isLoading = false;
            if (data && data.respData && data.respData.respCode === "0000") {
              if (handleType == 0) {
                this.$message.success('保存成功')
                this.publishStatus = 'ANNOUNCED'
              } else {
                this.$message.success('发布成功')
                this.publishStatus = 'PUBLISH'
              }
              this.showBulletBox1 = false
              this.close()
              this.buyersCollectQuestions()
            } else {
              this.form.qaDescription = this.form.qaDescription.replace(/<br\/>/g, '\n') || ''
              this.form.answerDescription = this.form.answerDescription.replace(/<br\/>/g, '\n') || ''
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    // 获取其他附件数据
    handleUpFileResult(e) {
      // this.delFileInfo()
      const { file, name, targetValue, url, allUrl } = e[0]
      let authorizationInfo = {
        attachName: name,
        attachUrl: allUrl,
        filesUrl: url
      }
      this.files.push(authorizationInfo)
      console.log(this.files)
    },
    // 文件下载
    handleDownTemp(name, url) {
      console.log(name, url)
      this.$download([{
        name: name,
        url: url
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 在线预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    // 文件删除
    delFiles(index) {
      if (this.isEditBulletin == '0' || !this.files[index].ossFileId) {
        this.files.splice(index, 1)
      } else {
        this.delFileList.push(this.files[index].ossFileId)
        this.files.splice(index, 1)
      }
      this.$message.success('已删除')
    },
    // 清空弹框
    close() {
      if (this.$refs['formBulletBox2']) {
        this.$refs['formBulletBox2'].resetFields();
      }
      this.form = {
        qaTheme: '',
        qaClassify: '',
        qaDescription: '',
        answerDescription: '',
        isTop: '1',
      }
      this.onBidQaNo = ''
      this.files = []
      this.delFileList = []
    },
    search() {
      this.pageIndex = 1
      this.buyersCollectQuestions()
    },
    clear() {
      this.pageIndex = 1;
      this.keyWord = ''
      this.qaClassify = ''
      this.buyersCollectQuestions()
    },
    // 全选
    checkboxChange() {
      this.isDisabled = !this.checkboxAll
      this.bidQAInfoList.forEach(i => {
        this.$set(i, 'checkbox', this.checkboxAll)
      });
    },
    // 单选
    checkboxChangeOne() {
      const a = this.bidQAInfoList.filter(i => i.checkbox == true)
      if (a.length == 0) {
        this.isDisabled = true
        this.checkboxAll = false
      } else {
        this.isDisabled = false
        if (a.length != this.bidQAInfoList.length) {
          this.checkboxAll = false
        } else {
          this.checkboxAll = true
        }
      }
    },
    // 批量删除
    batchDel() {
      const a = this.bidQAInfoList.filter(i => i.checkbox == true)
      if (a.length == 0) {
        this.$message('请勾选')
        return
      }
      let list = []
      console.log(a)
      a.forEach(i => {
        list.push(i.bidQaNo)
      });
      this.$confirm(
        '请确认是否删除勾选的' + a.length + '条公告内容，删除后不能撤回。',
        '批量删除公告',
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          type: 'warning',
          confirmButtonText: "确认删除",
          cancelButtonText: '取消',
        }).then(() => {
          this.buyersBulletinOperat(list, 3)
        }).catch(() => {
        });
    },
    // 批量发布
    batchRelease() {
      const a = this.bidQAInfoList.filter(i => i.checkbox == true)
      if (a.length == 0) {
        this.$message('请勾选')
        return
      }
      let list = []
      a.forEach(i => {
        list.push(i.bidQaNo)
      });
      this.buyersBulletinOperat(list, 1)
    },
    // 单次删除和撤回
    delRetract(list, handleType) {
      let content = ''
      let title = ''
      if (handleType == '2') {
        content = '确认撤回本条回复内容，撤回后请在【待回复】列表查看。'
        title = '撤回'
      } else {
        content = '确认删除本条回复内容，删除后不能撤回。'
        title = '删除'
      }
      this.$confirm(
        content,
        title,
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          type: 'warning',
          confirmButtonText: "确认" + title,
          cancelButtonText: '取消',
        }).then(() => {
          this.buyersBulletinOperat(list, handleType)
        }).catch(() => {
        });
    },
    // 采购商公告发布/撤回/删除
    buyersBulletinOperat(bidQaNo, handleType) {
      let param = {
        bidQaNos: bidQaNo,
        handleType: handleType, // 1发布,2撤回，3删除
      }
      InterfaceService.buyersBulletinOperat(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          if (handleType == '1') {
            this.$message.success('发布成功')
            this.publishStatus = 'PUBLISH'
            this.showBulletBox1 = false
            this.close()
          } else if (handleType == '2') {
            this.$message.success('撤回成功')
            this.publishStatus = 'ANNOUNCED'
          } else if (handleType == '3') {
            this.$message.success('删除成功')
          }
          this.buyersCollectQuestions()
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    init() {
      if(this.$parent){
        this.$parent.breadcrumb.push({ name: '答疑-公告' })
      }

      this.bidNo = this.$route.query.bidNo || ''
      this.bidName = this.$route.query.bidName || ''
      this.getDropDownList()
      this.buyersCollectQuestions()
    },
  },
  mounted() {
    this.init()
  },
  props: ['active']
};
</script>

<style lang="scss" scoped>
/deep/ .claim {
  width: 100%;
  min-height: 140px;
  .el-textarea__inner {
    min-height: 140px !important;
    resize: none;
    overflow: auto;
  }
}
.el-button + .el-button {
  margin-left: 8px !important;
}
/deep/ .el-select {
  width: 100% !important;
}
/deep/ .el-form-item__label {
  // font-size: 12px !important;
  padding: 0 !important;
  color: #888 !important;
}
// /deep/ .el-input--small .el-select,
// .el-input--small .el-input__inner {
//   &::placeholder {
//     font-size: 12px !important;
//   }
//   font-size: 12px !important;
// }
/deep/ .seatchW-width {
  width: inherit;
  .el-form-item__content {
    width: 300px;
  }
}
/deep/ .business {
  .el-form-item__label {
    width: 52px !important;
  }
  .el-form-item__content {
    margin-left: 52px !important;
  }
}

// /deep/ .samll_label {
//   .el-form-item__label {
//     width: 70px !important;
//   }
//   .el-form-item__content {
//     margin-left: 70px !important;
//   }
// }
.width1080 {
  width: calc(100% - 70px) !important;
}
.w120 {
  width: 120px !important;
}
.line {
  width: 100%;
  height: 1px;
  background-color: #eee;
  margin-top: 30px;
}
.dotted-line {
  width: 100%;
  margin-top: 20px;
  border-bottom: 1px dashed #eee;
}
.buyersAnswerQuestions {
  padding-bottom: 60px;
  .list-home {
    width: 1190px;
    margin: 0 auto;
    .box_steps {
      padding: 20px 0 30px;
      box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
    }
    .no-data {
      padding: 128px 100px;
      margin: 0 auto;
      text-align: center;
      font-size: 16px;
      line-height: 22px;
      color: #888;
    }
    .button-panel {
      .el-col {
        text-align: right;
      }
    }
    .list-content {
      margin: 10px 0;
      // tab栏
      .panel-switch {
        width: 100%;
        height: 40px;
        background-color: #f5f5f5;
        padding-right: 10px;
        margin-bottom: 6px;
        display: flex;
        justify-content: space-between;
        > ul {
          height: 100%;
          display: flex;
          li {
            padding: 0 17px;
            font-size: 14px;
            font-weight: 600;
            line-height: 20px;
            color: #888;
            position: relative;
            margin-right: 6px;
            line-height: 40px;
            &.active {
              color: #444;
            }
            &.active::before {
              content: "";
              width: 50%;
              height: 3px;
              background: rgba(201, 159, 79, 1);
              position: absolute;
              left: 25%;
              bottom: 4px;
            }
          }
        }
        .switch {
          line-height: 40px;
          .arrow {
            display: inline-block;
            width: 0;
            height: 0;
            border-right: 4px solid transparent;
            border-left: 4px solid transparent;
            border-bottom: 6px solid #0082ff;
            transition: transform 0.3s ease;
            &.active {
              transform-origin: 4px 3px;
              transform: rotate(180deg);
            }
          }
        }
      }
      // 搜索面板
      .panel {
        background: rgba(249, 249, 249, 1);
        padding: 20px 10px 20px 0px;
        .el-button + .el-button {
          margin-left: 18px;
        }
      }
      // 列表
      .list-box {
        margin-top: 10px;
        .list-operat {
          margin-bottom: 10px;
          height: 26px;
          display: flex;
          align-items: center;
        }
        > ul {
          li {
            width: 100%;
            margin-bottom: 14px;
            border: 1px solid #ddd;
            &:hover {
              border: 1px solid #c99f4f;
            }
            .list-content-box {
              border: 1px solid #ddd;
              &:hover {
                border: 1px solid #c99f4f;
              }
            }
            .box {
              .header {
                width: 100%;
                height: 40px;
                display: flex;
                justify-content: space-between;
                border-bottom: 1px solid #eee;
                // border: 1px solid #c99f4f;
                // border-bottom: 1px solid #eee;
                padding-right: 10px;
                > .left {
                  display: flex;
                  .number {
                    width: 40px;
                    height: 40px;
                    text-align: center;
                    line-height: 40px;
                    background: linear-gradient(
                      180deg,
                      rgba(187, 187, 187, 1) 0%,
                      rgba(221, 221, 221, 1) 100%
                    );
                    font-size: 14px;
                    color: #fff;
                    &.number-active {
                      background: #c99f4f;
                    }
                  }
                  > h1 {
                    font-size: 14px;
                    color: #444;
                    margin-left: 10px;
                    line-height: 40px;
                    max-width: 860px;
                    overflow: hidden;
                    text-overflow: ellipsis;
                    white-space: nowrap;
                    > span {
                      font-weight: 700;
                    }
                  }
                  .top-tag {
                    font-size: 14px;
                    color: #fff;
                    width: 46px;
                    height: 20px;
                    background: rgba(103, 99, 201, 1);
                    opacity: 1;
                    border-radius: 2px;
                    line-height: 20px;
                    text-align: center;
                    margin: 10px 0 0 20px;
                  }
                }
                > .right {
                  line-height: 40px;
                  display: flex;
                  > p {
                    font-size: 12px;
                    color: #888;
                    margin-right: 30px;
                    > span {
                      color: #444;
                    }
                  }
                  .switch {
                    .arrow {
                      display: inline-block;
                      width: 0;
                      height: 0;
                      border-right: 4px solid transparent;
                      border-left: 4px solid transparent;
                      border-bottom: 6px solid #0082ff;
                      transition: transform 0.3s ease;
                      &.active {
                        transform-origin: 4px 3px;
                        transform: rotate(180deg);
                      }
                    }
                  }
                }
              }
              .content {
                padding: 10px 10px 19px;
                // border: 1px solid #c99f4f;
                border-top: none;
                display: flex;
                justify-content: space-between;
                > .left {
                  width: 100%;
                  & ~ .right {
                    margin-left: 10px;
                  }
                  .info {
                    font-size: 12px;
                    line-height: 17px;
                    color: #444;
                  }
                  .annex {
                    margin: 10px 0 0px;
                    font-size: 12px;
                    color: #444;
                    display: flex;
                    .annex-file {
                      margin: 0 10px 6px 0;
                      &:last-child {
                        margin-bottom: 0;
                      }
                    }
                    > span {
                      &.hand.blue {
                        margin-left: 6px;
                      }
                    }
                  }
                  .quiz {
                    display: flex;
                    justify-content: space-between;
                    color: #888;
                    .annex {
                      flex: 1;
                    }
                    > .grey {
                      margin-top: 10px;
                      flex: 1;
                      text-align: right;
                    }
                  }
                }
                > .right {
                  width: 60px;
                  border-left: 1px solid #eee;
                  font-size: 12px;
                  display: flex;
                  flex-direction: column;
                  justify-content: center;
                  .operat {
                    text-align: right;
                    p {
                      line-height: 17px;
                      margin-bottom: 4px;
                    }
                  }
                }
              }
            }
          }
        }
        // 已回复
        .replied {
          li {
            display: flex;
            .checkbox {
              width: 20px;
              padding-top: 12px;
            }
            .list-content-box {
              width: 100%;
            }
            .box {
              &.isRelease {
                width: 100%;
              }
              &.reply-content {
                .content {
                  border-top: 1px solid #ddd;
                  .info {
                    display: flex;
                    .left {
                      display: inline-block;
                      width: 53px;
                      padding-left: 6px;
                      font-size: 14px;
                      > span {
                        position: relative;
                        font-weight: 600;
                        &.underline::before {
                          content: "";
                          position: absolute;
                          bottom: -3px;
                          left: -6px;
                          width: 36px;
                          height: 7px;
                          background: rgba(201, 159, 79, 0.7);
                          opacity: 1;
                        }
                      }
                    }
                    .right {
                      width: calc(100% - 53px);
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
.el-select {
  width: 100%;
}
.btn {
  width: 80px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  padding: 0;
}

.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}

.tab_type {
  background: #f9f9f9;
  margin: 30px 0 10px;
  > ul {
    width: 100%;
    height: 50px;
    border-bottom: 2px solid #ffd64e;
    font-weight: bold;
    > li {
      width: 120px;
      height: 50px;
      line-height: 50px;
      text-align: center;
      float: left;
      position: relative;
      font-size: 14px;
      color: #888;
      > p {
        width: 100%;
        height: 48px;
        margin-bottom: 2px;
      }
      &.active {
        > p {
          background-color: #313131;
          color: #fae2a5;
        }
      }
      .chlid-list {
        width: 120px;
        min-height: 50px;
        position: absolute;
        left: 0;
        top: 0;
        z-index: 1;
        > ul {
          display: none;
        }
      }
      .chlid-list {
        &:hover {
          > ul {
            margin-top: 58px;
            position: relative;
            display: block;
            &::after {
              position: absolute;
              left: 10px;
              top: -5px;
              content: "";
              width: 0;
              height: 0;
              border-right: 6px solid transparent;
              border-left: 6px solid transparent;
              border-bottom: 5px solid #313131;
            }
            > li {
              width: 120px;
              height: 48px;
              line-height: 48px;
              text-align: center;
              background-color: #313131;
              color: #fff;
              &.chlid-active {
                background: linear-gradient(
                  0deg,
                  rgba(16, 16, 24, 1) 0%,
                  rgba(90, 88, 88, 1) 100%
                );
                color: #fae2a5;
              }
            }
          }
        }
      }
    }
  }
}
// 弹框
.drafts-list {
  .uploadFileList {
    margin: 20px 0 15px;
    > .title-info {
      font-size: 14px;
      line-height: 20px;
      color: rgba(68, 68, 68, 1);
      > p {
        margin-right: 6px;
        display: inline-block;
      }
      > span {
        font-size: 12px;
        margin-right: 10px;
      }
    }
    .fileList {
      width: 100%;
      border: 1px solid rgba(221, 221, 221, 1);
      padding: 0 10px 14px 10px;
      margin: 6px 0 0px;
      > p {
        margin-top: 14px;
        font-size: 12px;
        line-height: 17px;
        color: rgba(68, 68, 68, 1);
        &.noData {
          color: #bbb;
        }
        > span {
          margin-right: 10px;
          &:first-child {
            margin-left: 6px;
          }
        }
      }
    }
  }
}
.searchbox {
  text-align: center;
  margin-top: 20px;
  display: flex;
  justify-content: center;
  .searchBtn {
    width: 120px;
    height: 34px;
    line-height: 34px;
    background: linear-gradient(
      122deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(255, 255, 255, 1);
    display: inline-block;
    cursor: pointer;
  }
  .clearBtn {
    width: 120px;
    margin-left: 20px;
    height: 34px;
    line-height: 32px;
    border: 1px solid rgba(201, 159, 79, 1);
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(201, 159, 79, 1);
    display: inline-block;
    cursor: pointer;
  }
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
</style>
