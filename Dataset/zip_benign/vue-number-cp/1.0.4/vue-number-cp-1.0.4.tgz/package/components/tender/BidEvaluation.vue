<template>
  <div>
    <div class="info-title" style="margin-bottom: 0;">
      清标
      <span class="f12 blue hand" @click="handleDownload('0')" v-if="billAttachInfos.length">全部下载</span>
    </div>
    <div v-for="(item,index) in billAttachInfos" :key="index">
      <div class="f14" style="margin-top: 12px;">
        {{item.attachName}}
      </div>
      <div class="f12 red" style="margin-top: 6px;" v-if="updateTime">
        ※更新于{{updateTime}}
      </div>
      <div class="enclosure-content">
        <span>{{item.attachName}}</span>
        <span class="hand blue" @click="handleDownload(item.attachType)">下载</span>
      </div>
    </div>

    <!--<div class="f14" style="margin-top: 20px;">-->
    <!--模拟清单比价-->
    <!--</div>-->
    <!--<div class="f12 red" style="margin-top: 6px;">-->
    <!--※更新于2020-05-02 12：15-->
    <!--</div>-->
    <!--<div class="enclosure-content">-->
    <!--<span>啦啦啦阿拉啦啦啦</span>-->
    <!--<span class="hand blue" @click="handleDownload">下载</span>-->
    <!--</div>-->
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { viewFile } from '@/utils/orderUtil';
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";

export default {
  name: "BidEvaluation",
  components: {
    Loading
  },
  data() {
    return {
      isLoading: false,
      bidNo: "",
      bidName: "",
      updateTime: "",
      inventoryFlag: "",
      billAttachInfos: [],
    }
  },
  methods: {
    handleAllDownload() {
      let fileInfoBeans = []
      this.billAttachInfos.forEach(item => {
        fileInfoBeans.push({
          archivePath: item.attachName,
          fileUrl: item.attachUrl,
        })
      });
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl;
            // const files = [
            //   { name: this.bidName + "清单/评标附件.zip", url: url }
            // ];
            // this.$download(files, () => {this.isLoading = true}, () => {this.isLoading = false}).then(() => {
            //   this.$message.success("已下载");
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: this.bidName + "清单/评标附件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    handleView(url) {
      viewFile(url)
    },
    handleDownload(attachType) {
      if (this.inventoryFlag == '0') {
        return this.$message('请去线下比价')
      }
      const params = {
        bidNo: this.bidNo,
        type: attachType
      };
      InterfaceService.downloadPriceComparison(
        params,
        data => {
          if (data.respData.respCode == '0000') {
            let billAttachInfos = data.respData.billAttachInfos || [];
            if (attachType != '0') {
              if(attachType != '4'){
                let attach = [];
                if (billAttachInfos.length) {
                  attach.push({
                    url: billAttachInfos[0].resultUrl,
                    name: billAttachInfos[0].attachName
                  });
                }
                this.$download(attach).then(res => {
                  this.$message.success("已下载");
                }).catch(res => {
                  this.$message.error("下载失败");
                })
              }else{
                let attach = [];
                if (!billAttachInfos.length || !billAttachInfos[0].attachUrl) {
                  return this.$message.error("暂无下载地址");
                }
                InterfaceService.packageDownloadAsyn(billAttachInfos[0].attachUrl, data => {
                  const files = [
                    { name: billAttachInfos[0].attachName, url: data }
                  ];
                  this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                    this.$message.success("已下载");
                  });
                }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
              }
              
            } else {
              let fileInfoBeans = []
              if (billAttachInfos.length) {
                billAttachInfos.forEach(item => {
                  fileInfoBeans.push({
                    archivePath: item.attachName,
                    fileUrl: item.resultUrl,
                  })
                })
                let params = {
                  fileInfoBeans: fileInfoBeans,
                  protocol: "https",
                  isAsyn: true
                };
                InterfaceService.packageDownload(
                  params,
                  data => {
                    let res = data.respData || {};
                    if (data && data.respData && res.respCode === "0000") {
                      let url = res.externalFileUrl
                      // const files = [
                      //   { name: this.bidName + "清单/评标附件.zip", url: url }
                      // ];
                      // this.$download(files, () => {this.isLoading = true}, () => {this.isLoading = false}).then(() => {
                      //   this.$message.success("已下载");
                      // });
                      InterfaceService.packageDownloadAsyn(url, data => {
                        const files = [
                          { name: this.bidName + "清单/评标附件.zip", url: data }
                        ];
                        this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                          this.$message.success("已下载");
                        });
                      }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
                    } else {
                      this.$message.error(data.respData.respMsg)
                    }
                  }, data => {
                    this.$message.error(data.respData.respMsg)
                  }, () => {
                    this.isLoading = true
                  }, () => {
                    this.isLoading = false
                  }
                )
              }
            }
          } else {
            this.$message.error(data.respData.respMsg)
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );

    },
    getPriceComparisonList() {
      const params = {
        bidNo: this.bidNo
      };
      InterfaceService.getPriceComparisonList(
        params,
        data => {
          let res = data.respData;
          if (res.respCode == '0000') {
            this.inventoryFlag = res.inventoryFlag || '0';
            this.billAttachInfos = res.billAttachInfos || [];
            this.updateTime = res.updateTime || ""
            this.billAttachInfos.forEach(item => {
              if (item.type == '45') {
                item.title = "报价清单比价"
              }
            })
          } else {
            this.$message.error(res.respMsg)
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    init() {
      if(this.$parent){
        this.$parent.breadcrumb.push({ name: '清标/评标' })
      }
      this.getPriceComparisonList()
    }
  },
  mounted() {
    this.bidNo = this.$route.query.bidNo || "";
    this.bidName = this.$route.query.bidName || "";
    this.init();
  }
}
</script>

<style scoped lang="scss">
.tips {
}
.info-title {
  margin: 20px 0 !important;
  padding: 0 10px 0 4px !important;
  font-size: 14px !important;
  border-left: 3px solid #444 !important;
  line-height: 12px !important;
  font-weight: bold !important;
  color: #444 !important;
}
.upload {
  /deep/ .el-input,
  input {
    position: absolute;
    left: -9999px;
    width: 0px;
    height: 0px;
    overflow: hidden;
    opacity: 0;
  }
  .pl10 {
    padding-left: 10px;
  }
}
.enclosure-content {
  font-size: 12px;
  width: 1190px;
  border: 1px solid #ddd;
  padding: 14px 10px;
  line-height: 17px;
  margin-top: 6px;
  div {
    margin-bottom: 10px;
  }
  div:last-child {
    margin-bottom: 0;
  }
  span {
    margin-right: 6px;
  }
}
</style>