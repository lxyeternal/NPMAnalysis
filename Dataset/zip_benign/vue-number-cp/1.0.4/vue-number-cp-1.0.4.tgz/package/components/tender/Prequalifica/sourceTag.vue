<template>
  <div class="addSupplier">
    <el-dialog class="dialog dialog-drafts" :title="'来源标记'" :append-to-body="true" :lock-scroll="true" :visible.sync="showRelease" width="850px" center :close-on-click-modal="false">
      <div class="drafts-list tl">
        <p class="tl" style="margin: 16px 0 30px"><span class="grey">供应商名称：</span>{{supplierCorpName}}</p>
        <table class="table">
          <thead>
            <tr>
              <td width="134px">标签</td>
              <td>备注</td>
            </tr>
          </thead>
          <tbody class="tbody-row">
            <tr v-for="(a,index) in list" :key="index+'tbody'">
              <td>
                <el-checkbox v-model="a.checkBox" :disabled="a.disabled"></el-checkbox>
                <div class="tag">{{a.tagName}}</div>
              </td>
              <td>
                <el-input :disabled="a.disabled" v-model.trim="a.tagSup" placeholder="限52字" maxlength="52" clearable></el-input>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" :class="{'isDisabled-primary':!(list.some(i=>i.checkBox))}" @click="addMemberTag">确认</div>
        <div class="clearBtn" @click="showRelease=false">取消</div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
export default {
  components: {
    Loading,
  },
  data() {
    return {
      isLoading: false,
      bidNo: '',
      showRelease: false,
      supplierCorpName: '',
      supplierCorpId: '',
      list: [],
      selectedList: [],
    }
  },
  methods: {
    // 查询标签信息
    getTagInfo(a) {
      let param = {
        tagType: 'BID'
      }
      InterfaceService.getTagInfo(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.list = data.respData.tagMngList || []
          this.list.forEach(i => {
            this.$set(i, 'checkBox', false)
            this.$set(i, 'tagSup', '')
            if (a.corpTagList) {
              a.corpTagList.forEach(j => {
                if (j.tagId == i.tagId) {
                  this.$set(i, 'tagSup', j.tagSup)
                }
              });
            }
            this.$set(i, 'disabled', false)
            this.selectedList.forEach(j => {
              if (i.tagId == j.tagId) {
                this.$set(i, 'disabled', true)
              }
            })
          });
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 批量新增会员标签
    addMemberTag() {
      let tagList = []
      this.list.forEach(i => {
        if (i.checkBox) {
          tagList.push({
            tagId: i.tagId,
            tagSup: i.tagSup,
          })
        }
      });
      if (!tagList.length) { return }
      let param = {
        corpTagList: [{
          bidNo: this.bidNo,
          corpId: this.supplierCorpId,
          tagList: tagList
        }]
      }
      InterfaceService.addMemberTag(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('标记成功')
          this.showRelease = false
          this.$emit('getData')
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    open(bidNo, a) {
      this.bidNo = bidNo
      this.supplierCorpName = a.supplierCorpName
      this.supplierCorpId = a.supplierCorpId
      this.selectedList = a.corpTagList || []
      this.getTagInfo(a)
      this.showRelease = true

    },
  },
}
</script>
<style lang="scss" scoped>
.table {
  table-layout: fixed;
  width: 810px;
  line-height: 23px;
  font-size: 12px;
  td {
    vertical-align: middle;
    word-break: break-all;
  }

  thead {
    font-size: 14px;
    text-align: left;
    white-space: nowrap;
    // border-bottom: 1px solid #eee;
    background: #f5f5f5;
    color: #888;
    > tr {
      > td {
        padding: 7px 0;
        &:first-child {
          padding-left: 25px;
        }
        &:last-child {
          padding-left: 15px;
        }
      }
    }
  }

  tbody {
    text-align: left;
    tr {
      td {
        padding: 4px 0;
        .tag {
          width: 100px;
          height: 34px;
          background: rgba(221, 221, 221, 1);
          padding-left: 10px;
          line-height: 34px;
          font-size: 12px;
          margin-left: 6px;
          display: inline-block;
        }
      }
      /deep/ .el-input {
        .el-input__inner {
          height: 34px !important;
          line-height: 34px !important;
        }
      }
    }
  }
}
.searchbox {
  text-align: center;
  margin-top: 20px;
  display: flex;
  justify-content: center;
  .searchBtn {
    width: 120px;
    height: 34px;
    line-height: 34px;
    background: linear-gradient(
      122deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(255, 255, 255, 1);
    display: inline-block;
    cursor: pointer;
  }
  .clearBtn {
    width: 120px;
    margin-left: 20px;
    height: 34px;
    line-height: 32px;
    border: 1px solid rgba(201, 159, 79, 1);
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(201, 159, 79, 1);
    display: inline-block;
    cursor: pointer;
  }
}
</style>