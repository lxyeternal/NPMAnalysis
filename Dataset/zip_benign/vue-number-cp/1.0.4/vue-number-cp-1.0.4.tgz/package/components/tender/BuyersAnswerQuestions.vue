<template>
  <div class="buyersAnswerQuestions">
    <div class="list-home">
      <el-row class="button-panel">
        <el-col :span="24">
          <el-button v-if="active<=3" class="btn w120" type="primary" size="small" @click="id='1';fileTypes='xlsx',$refs.upfileRef.open()">上传批量回复</el-button>
          <el-button class="btn w120" size="small" @click="buyersDownloadQuestion()">下载问题汇总表</el-button>
        </el-col>
      </el-row>
      <div class="list-content">
        <div class="panel-switch">
          <ul>
            <li class="hand" :class="{active: answerStatus=='UNANSWERED'}" @click="answerStatus='UNANSWERED';clear();">待回复问题</li>
            <li class="hand" :class="{active: answerStatus=='REPLIED'}" @click="answerStatus='REPLIED';clear();">已回复问题</li>
          </ul>
          <div class="switch hand blue" @click="isShowPanel=!isShowPanel;isShowPanelChenge()">{{isShowPanel?'全部收起':'全部展开'}} <i class="arrow" :class="{active:!isShowPanel}"></i></div>
        </div>
        <div class="panel">
          <el-form class="form" size="small" label-width="100px">
            <el-row>
              <el-col :span="8">
                <el-form-item label="供应商：" class="samll_label">
                  <el-input v-model.trim="supplierCorpName" placeholder="请输入供应商名称" maxlength="200" clearable></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="主题搜索：">
                  <el-input v-model.trim="keyWord" placeholder="请输入关键词" maxlength="200" clearable></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8" v-if="answerStatus=='REPLIED'">
                <el-form-item label="回复发布情况：" class="businessone">
                  <el-radio-group v-model="publishStatus" @change="search()">
                    <el-radio :label="'ANNOUNCED'">未发布</el-radio>
                    <el-radio :label="'PUBLISH'">已发布</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="分类：" class="business">
                  <el-radio-group v-model="qaClassify" @change="search()">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'TECHNICALBID'">技术标</el-radio>
                    <el-radio :label="'COMMERCIALBID'">商务标</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24" class="form-btns" align="center">
                <el-button class="btn" type="primary" size="small" @click="search()">搜索</el-button>
                <el-button class="btn" size="small" @click="clear()">清除</el-button>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <div class="list-box">
          <!-- 待回复 -->
          <ul v-if="answerStatus=='UNANSWERED' && bidQAInfoList.length != 0">
            <li v-for="(a,ind) in bidQAInfoList" :key="ind">
              <div class="box">
                <div class="header">
                  <div class="left">
                    <div class="number">{{total-ind-pageSize*(pageIndex-1)}}</div>
                    <h1><span>主题：</span>{{a.qaTheme}}</h1>
                  </div>
                  <div class="right">
                    <p>类别：<span>{{a.qaClassify=='TECHNICALBID'?'技术标':'商务标'}}</span></p>
                    <div class="switch hand blue" @click="a.isShowPanel=!a.isShowPanel;isShowPanelChengeOne()">{{a.isShowPanel?'收起':'展开'}} <i class="arrow" :class="{active:!a.isShowPanel}"></i></div>
                  </div>
                </div>
                <!-- <transition name="el-zoom-in-top"> -->
                <div class="content" v-show="a.isShowPanel">
                  <div class="left width1080">
                    <!-- 问题描述 -->
                    <div class="info" v-html="a.qaDescription=a.qaDescription.replace(/\n/g, '<br/>')"></div>
                    <div class="dotted-line"></div>
                    <!-- 附件 -->
                    <div class="annex"><span class="bold">附件：</span>
                      <div v-if="!a.qaAttachInfoList">
                        <p class="annex-file grey">暂无附件</p>
                      </div>
                      <div v-else>
                        <p v-for="(b,ind_b) in a.qaAttachInfoList" :key="ind_b" class="annex-file">{{b.attachName}} <span class="hand blue" @click="handleDownTemp(b.attachName,b.attachUrl)">下载</span></p>
                      </div>
                    </div>

                    <div class="quiz">
                      <p>提问者：{{a.corpName+' '+a.createAcctName}}</p>
                      <p>提问时间：{{a.publishTime && a.publishTime.substring(0,19)}}</p>
                    </div>
                  </div>
                  <div class="right" v-if="active<=3">
                    <div class="operat">
                      <p class="hand blue" @click="isEditRetract='0';showBulletBox1=true;onBidQaNo = a.bidQaNo">回复</p>
                    </div>
                  </div>
                </div>
                <!-- </transition> -->
              </div>
            </li>
          </ul>

          <!-- 已回复 -->
          <el-row v-show="isPublishStatus=='ANNOUNCED' && answerStatus=='REPLIED'" style="margin-bottom: 10px;height: 26px">
            <el-col :span="24">
              <el-checkbox v-model="checkboxAll" style="margin: 0 10px 0 0" :disabled="!bidQAInfoList.length" @change="checkboxChange">全选</el-checkbox>
              <el-button class="btn" :disabled="isDisabled" :class="{'isDisabled':isDisabled}" size="small" @click="batchDel">批量删除</el-button>
              <el-button class="btn" :disabled="isDisabled" :class="{'isDisabled-primary':isDisabled}" type="primary" size="small" @click="batchRelease">批量发布</el-button>
            </el-col>
          </el-row>
          <ul class="replied" v-if="answerStatus=='REPLIED'  && bidQAInfoList.length != 0">
            <li style="border: none" v-for="(a,ind) in bidQAInfoList" :key="ind">
              <!-- 多选 -->
              <div v-if="isPublishStatus=='ANNOUNCED'" class="checkbox">
                <el-checkbox v-model="a.checkbox" @change="checkboxChangeOne"></el-checkbox>
              </div>
              <div class="list-content-box">
                <div class="box" :class="{'isRelease':isPublishStatus=='ANNOUNCED'}">
                  <div class="header">
                    <div class="left">
                      <div class="number">{{total-ind-pageSize*(pageIndex-1)}}</div>
                      <h1><span>主题：</span>{{a.qaTheme}}</h1>
                    </div>
                    <div class="right">
                      <p>类别：<span>{{a.qaClassify=='TECHNICALBID'?'技术标':'商务标'}}</span></p>
                      <div class="switch hand blue" @click="a.isShowPanel=!a.isShowPanel;isShowPanelChengeOne()">{{a.isShowPanel?'收起':'展开'}} <i class="arrow" :class="{active:!a.isShowPanel}"></i></div>
                    </div>
                  </div>
                  <!-- <transition name="el-zoom-in-top"> -->
                  <div v-show="a.isShowPanel" style="padding: 10px 10px 19px;">
                    <div class="content" style="padding: 0px">
                      <div class="left" :class="{'width1080':(isPublishStatus=='PUBLISH' && active==3)}">
                        <!-- 问题描述 -->
                        <div class="info" v-html="a.qaDescription=a.qaDescription.replace(/\n/g, '<br/>')"></div>
                        <div class="dotted-line"></div>
                        <!-- 附件 -->
                        <div class="annex"><span class="bold">附件：</span>
                          <div v-if="!a.qaAttachInfoList">
                            <p class="annex-file grey">暂无附件</p>
                          </div>
                          <div v-else>
                            <p v-for="(b,ind_b) in a.qaAttachInfoList" :key="ind_b" class="annex-file">{{b.attachName}} <span class="hand blue" @click="handleDownTemp(b.attachName,b.attachUrl)">下载</span></p>
                          </div>
                        </div>
                        <div class="quiz" v-if="isPublishStatus=='ANNOUNCED'">
                          <p>提问者：{{a.corpName+' '+a.createAcctName}}</p>
                          <p>提问时间：{{a.publishTime && a.publishTime.substring(0,19)}}</p>
                        </div>
                      </div>
                      <div class="right" v-if="isPublishStatus=='PUBLISH' && active==3">
                        <div class="operat">
                          <p class="hand blue" @click="onBidQaNo = a.bidQaNo;buyersReplyDetails('',a.bidQaNo)">回复</p>
                        </div>
                      </div>
                    </div>
                    <div class="quiz" v-if="isPublishStatus=='PUBLISH'" style="margin-top: 5px">
                      <p>提问者：{{a.corpName+' '+a.createAcctName}}</p>
                      <p>提问时间：{{a.publishTime && a.publishTime.substring(0,19)}}</p>
                    </div>
                  </div>
                  <!-- </transition> -->
                </div>
                <!-- 回复内容· -->
                <!-- <transition name="el-zoom-in-top"> -->
                <div class="reply-list-box" v-show="a.isShowPanel" :class="{'mask':(active!=3 && isPublishStatus=='ANNOUNCED')}">
                  <div class="box reply-content" :class="{'isRelease':isPublishStatus=='ANNOUNCED'}" v-for="(c,ind_c) in (a.qaAnswerInfoList || [])" :key="ind_c">
                    <div class="header">
                      <div class="left">
                        <h1><span class="underline">回复</span>{{c.answerTheme}}</h1>
                      </div>
                      <div class="right">
                        <p class="grey">回复时间：{{isPublishStatus=='ANNOUNCED'?(c.createTime && c.createTime.substring(0,19)):(c.publishTime && c.publishTime.substring(0,19))}}</p>
                      </div>
                    </div>

                    <div class="content">
                      <div class="left" :class="{'width1080':(isPublishStatus=='ANNOUNCED' || (isPublishStatus=='PUBLISH' && active==3))}">
                        <div class="info" v-html="c.answerDescription"></div>
                        <div class="dotted-line"></div>
                        <div class="annex"><span class="bold">附件：</span>
                          <div v-if="!c.qaAnswerAttachInfoList">
                            <p class="annex-file grey">暂无附件</p>
                          </div>
                          <div v-else>
                            <p v-for="(d,ind_d) in c.qaAnswerAttachInfoList" :key="ind_d" class="annex-file">{{d.attachName}} <span class="hand blue" @click="handleDownTemp(d.attachName,d.attachUrl)">下载</span></p>
                          </div>
                        </div>
                      </div>
                      <div class="right" v-if="active==3">
                        <div class="operat" v-show="isPublishStatus=='ANNOUNCED'">
                          <p class="hand blue" @click="isEditRetract='1';onBidQaNo = a.bidQaNo;buyersReplyDetails(c.bidAnswerNo,'')">编辑</p>
                          <p class="hand blue" @click="buyersQuestionsReplyOperat([c.bidAnswerNo],'1')">发布</p>
                          <p class="hand blue" @click="delRetract([c.bidAnswerNo],'3')">删除</p>
                        </div>
                        <div class="operat" v-show="isPublishStatus=='PUBLISH'">
                          <p class="hand blue" @click="delRetract([c.bidAnswerNo],'2')">撤回</p>
                        </div>
                      </div>
                      <div class="right" v-if="active!=3 && isPublishStatus=='ANNOUNCED'">
                        <div class="operat">
                          <p class="hand blue" @click="delRetract([c.bidAnswerNo],'3')">删除</p>
                        </div>
                      </div>
                    </div>

                  </div>
                </div>
                <!-- </transition> -->
              </div>
            </li>
          </ul>
        </div>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="bidQAInfoList.length == 0">
          <img src="@/assets/images/icon-no-product.png">
          <p>暂无回复问题！</p>
        </div>
        <!-- 分页 -->
        <div class="table-pagination" v-if="bidQAInfoList.length != 0">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <!-- 回复弹框 -->
    <el-dialog class="dialog dialog-drafts" :title="'回复'" :append-to-body="true" :lock-scroll="true" :visible.sync="showBulletBox1" width="840px" center :close-on-click-modal="false" @close="close()">
      <div class="drafts-list tl">
        <el-form class="form" size="small" label-width="90px" :model="form" :rules="rules" ref="formBulletBox1">
          <el-row>
            <el-col :span="24">
              <el-form-item label="回复：" prop="answerTheme">
                <el-input v-model.trim="form.answerTheme" placeholder="请输入标题，限54字" maxlength="54" clearable></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="">
                <el-input class="claim" show-word-limit type="textarea" placeholder="请输入详细描述" v-model="form.answerDescription" maxlength="200">
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <div class="uploadFileList">
            <div class="title-info tl">
              <p>该回复内容的补充说明附件</p><span class="hand blue" @click="id='2';fileTypes='',$refs.upfileRef.open()">上传</span>
            </div>
            <div class="fileList">
              <p class="noData" v-if="files.length == 0">未上传附件！</p>
              <p v-for="(item,ind_t) in files" :key="ind_t">{{item.attachName}}<span class="hand blue" @click="handleView(item.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(item.attachName,item.attachUrl)">下载</span><span class="hand blue" @click="delFiles(ind_t)">删除</span></p>
            </div>
          </div>
        </el-form>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="editRetract('1')">发布</div>
        <div class="clearBtn" @click="editRetract('0')">保存</div>
        <!-- <div v-if="isEditRetract == '1'" class="searchBtn" @click="editRetract()">编辑</div> -->
        <div class="clearBtn" @click="showBulletBox1=false;close()">取消</div>
      </div>
    </el-dialog>
    <!-- 上传附件 -->
    <UpfileComponent ref="upfileRef" :immediateClearList="true" :btnName="'选择文件'" :dirName="`${new Date().getTime()}/`" :type="'12'" :fileTypes="fileTypes" :id="id" @outputList="handleUpFileResult($event)"></UpfileComponent>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import UpfileComponent from "@/components/tender/upfileComponent";
import { viewFile } from '@/utils/orderUtil';

export default {
  components: {
    Loading,
    UpfileComponent,
  },
  data() {
    return {
      isLoading: false,

      fileTypes: '',
      checkboxAll: false,
      id: '', // 上传区分id
      isEditRetract: '0',// 0回复，1编辑
      showBulletBox1: false, // 回复弹框
      form: {
        answerTheme: '', //回复主题
        answerDescription: '', //回复描述
      },
      rules: {
        answerTheme: [
          { required: true, message: '请输入标题，限54字', trigger: 'blur' }
        ],
      },
      files: [], // 弹框附件列表
      delFileList: [],//删除的附件

      bidName: '',
      isDisabled: true, // 批量操作是否置灰
      isShowPanel: true, // 面板是否展开
      supplierCorpName: '',
      keyWord: '',
      qaClassify: '',
      answerStatus: 'UNANSWERED', // 回复状态 //REPLIED 已回复  UNANSWERED 未回复
      publishStatus: 'ANNOUNCED', // 发布状态 ANNOUNCED','待发布'   'PUBLISH','已发布'
      isPublishStatus: 'ANNOUNCED',

      bidQAInfoList: [],//数据列表
      onBidQaNo: '', //提问编号
      bidAnswerNo: '',//回复编号

      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码

      bidNo: '',//	招标编号	
    };
  },
  methods: {
    search() {
      this.pageIndex = 1
      this.buyersCollectQuestions()
      this.isPublishStatus = this.publishStatus
    },
    clear() {
      this.pageIndex = 1;
      this.supplierCorpName = ''
      this.keyWord = ''
      this.qaClassify = ''
      this.publishStatus = 'ANNOUNCED'
      this.isPublishStatus = 'ANNOUNCED'
      this.buyersCollectQuestions()
    },
    // 清空弹框
    close() {
      console.log(this.$refs['formBulletBox1'])
      if (this.$refs['formBulletBox1']) {
        this.$refs['formBulletBox1'].resetFields();
      }
      this.onBidQaNo = '';
      this.form = {
        answerTheme: '', //回复主题
        answerDescription: '', //回复描述
      };
      this.files = []
      this.delFileList = []
    },
    // 是否全部展开关闭
    isShowPanelChenge() {
      this.bidQAInfoList.forEach(i => {
        this.$set(i, 'isShowPanel', this.isShowPanel)
      });
    },
    // 单点收起展开
    isShowPanelChengeOne() {
      const a = this.bidQAInfoList.filter(i => i.isShowPanel == true)
      if (a.length == 0) {
        this.isShowPanel = false
      } else {
        this.isShowPanel = true
      }
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.buyersCollectQuestions()
    },

    // 采购商问题收集列表
    buyersCollectQuestions() {
      let param = {
        bidNo: this.bidNo, //	招标编号				
        supplierCorpName: this.supplierCorpName, //	供应商名				
        keyWord: this.keyWord, //	关键字				
        pageIndex: String(this.pageIndex),//	页码				
        qaClassify: this.qaClassify, //	问题分类				
        answerStatus: this.answerStatus, //	回复状态(配置在pd_product_config，已回复，未回复)				
        publishStatus: this.publishStatus, //	发布状态(配置在pd_product_config，待发布，已发布)				
        qaType: 'PROBLEM', //	问题类型（配置在pd_product_config，问题，公告）	

      }
      InterfaceService.buyersCollectQuestions(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.bidQAInfoList = data.respData.bidQAInfoList || []
          this.bidQAInfoList.forEach(i => {
            this.$set(i, 'isShowPanel', true)
            this.$set(i, 'checkbox', false)
          });
          this.isShowPanel = true
          this.total = data.respData.totoalCount
          this.pageSize = data.respData.pageSize

          this.checkboxAll = false
          this.isDisabled = true
          window.scrollTo(0, 0)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 获取其他附件数据
    handleUpFileResult(e) {
      // this.delFileInfo()
      const { file, name, targetValue, url, allUrl, id } = e[0]
      let authorizationInfo = {
        attachName: name,
        attachUrl: allUrl,
        filesUrl: url
      }
      console.log(id)
      if (id == '1') {
        this.buyersUploadReply(url, '0')
      } else {
        this.files.push(authorizationInfo)
      }
      console.log(this.files)
    },
    // 采购商上传批量回复
    buyersUploadReply(attachPath, isChecked) {
      let param = {
        bidNo: this.bidNo,//	编号				
        attachPath: attachPath,//	编号	
        isChecked: isChecked
      }
      InterfaceService.buyersUploadReply(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          let unpublishedCnt = data.respData.unpublishedCnt || 0
          if (unpublishedCnt > 0) {
            this.$confirm(
              '有' + unpublishedCnt + '个问题已回复但未发布，是否覆盖未发布的回复内容？',
              '上传批量回复',
              {
                cancelButtonClass: "btn-custom-cancel",
                confirmButtonClass: "btn-custom-confirm",
                center: true,
                dangerouslyUseHTMLString: true,
                type: 'warning',
                confirmButtonText: "直接覆盖",
                cancelButtonText: '取消',
              }).then(() => {
                this.buyersUploadReply(attachPath, '1')
              }).catch(() => {
              });
          } else {
            this.$message.success('上传成功')
            this.buyersCollectQuestions()
          }

        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 采购商下载问题汇总表
    buyersDownloadQuestion() {
      let param = {
        bidNo: this.bidNo,//	编号				
      }
      InterfaceService.buyersDownloadQuestion(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.handleDownTemp('问题汇总表.xlsx', data.respData.attachUrl)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 文件下载
    handleDownTemp(name, url) {
      console.log(name, url)
      this.$download([{
        name: name,
        url: url
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 在线预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    // 文件删除
    delFiles(index) {
      if (this.files[index].ossFileId) {
        this.delFileList.push(this.files[index].ossFileId)
      }
      this.files.splice(index, 1)
      this.$message.success('已删除')
    },
    // 是编辑还是回复
    editRetract(handleType) {
      if (this.isEditRetract == '0') { //回复
        this.buyersQuestionsReply(handleType)
      } else {
        this.buyersReplyEdit(handleType)
      }
    },
    // 采购商回复详情
    buyersReplyDetails(bidAnswerNo, bidQaNo) {
      let param = {
        bidAnswerNo: bidAnswerNo,//	回复编号	
        bidQaNo: bidQaNo, // 提问编号
      }
      InterfaceService.buyersReplyDetails(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          // isEditRetract='0';
          if (data.respData.qaAnswerBean) {
            this.form.answerTheme = data.respData.qaAnswerBean.answerTheme || ''
            this.form.answerDescription = data.respData.qaAnswerBean.answerDescription || ''
            this.form.answerDescription = this.form.answerDescription.replace(/<br\/>/g, '\n')
            this.files = data.respData.qaAnswerBean.qaAnswerAttachInfoList || []
            this.showBulletBox1 = true
            this.bidAnswerNo = data.respData.qaAnswerBean.bidAnswerNo
            this.isEditRetract = '1'
          } else {
            this.isEditRetract = '0'
            this.showBulletBox1 = true
          }

        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })

    },
    //  采购商回复
    buyersQuestionsReply(handleType) {
      this.$refs['formBulletBox1'].validate((valid) => {
        if (valid) {
          let acctName = this.$store.state.userInfo.acctName || ''

          let qaAnswerInfoList = []
          this.files.forEach(i => {
            if (i.filesUrl) {
              qaAnswerInfoList.push({
                attachName: i.attachName,
                attachPath: i.filesUrl,
              })
            }
          });
          this.form.answerDescription = this.form.answerDescription.replace(/\n/g, '<br/>')
          let param = {
            bidNo: this.bidNo,//	招标编号				
            bidQaNo: this.onBidQaNo,//	提问编号				
            answerTheme: this.form.answerTheme,//	回复主题				
            answerDescription: this.form.answerDescription,//	回复描述				
            acctName: acctName,//	登陆人姓名				
            qaAnswerInfoList: qaAnswerInfoList,//	回复附件信息列表					
            handleType: handleType,//	0保存，1发布
          }
          InterfaceService.buyersQuestionsReply(param, data => {
            this.isLoading = false;
            if (data && data.respData && data.respData.respCode === "0000") {
              if (handleType == 0) {
                this.$message.success('保存成功');
                this.answerStatus = "REPLIED"
                this.publishStatus = "ANNOUNCED"
                this.isPublishStatus = "ANNOUNCED"
              } else {
                this.$message.success('发布成功')
                this.answerStatus = "REPLIED";
                this.publishStatus = "PUBLISH"
                this.isPublishStatus = "PUBLISH"
              }
              this.showBulletBox1 = false
              this.close()
              this.buyersCollectQuestions()
            } else {
              this.form.answerDescription = this.form.answerDescription.replace(/<br\/>/g, '\n') || ''
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        } else {
          console.log('error submit!!');
          return false;
        }
      });

    },
    // 采购商回复编辑
    buyersReplyEdit(handleType) {
      this.$refs['formBulletBox1'].validate((valid) => {
        if (valid) {
          let acctName = this.$store.state.userInfo.acctName || ''

          let qaAnswerInfoList = []
          this.files.forEach(i => {
            if (!i.ossFileId && i.filesUrl) {
              qaAnswerInfoList.push({
                attachName: i.attachName,
                attachPath: i.filesUrl,
              })
            }
          });

          if (this.delFileList != 0) {
            this.delFileList.forEach(i => {
              qaAnswerInfoList.push({
                ossFileId: i
              })
            });
          }

          this.form.answerDescription = this.form.answerDescription.replace(/\n/g, '<br/>')
          let param = {
            bidNo: this.bidNo,//	招标编号				
            bidAnswerNo: this.bidAnswerNo,//	回复编号				
            answerTheme: this.form.answerTheme,//	回复主题				
            answerDescription: this.form.answerDescription,//	回复描述				
            acctName: acctName,//	登陆人姓名				
            qaAnswerInfoList: qaAnswerInfoList,//	回复附件信息列表					
            // handleType: handleType,//	0保存，1发布
          }
          InterfaceService.buyersReplyEdit(param, data => {
            this.isLoading = false;
            if (data && data.respData && data.respData.respCode === "0000") {
              if (handleType == '1') { //发布
                this.buyersQuestionsReplyOperat([this.bidAnswerNo], handleType)
              } else {
                this.publishStatus = "ANNOUNCED"
                this.isPublishStatus = "ANNOUNCED"
                this.$message.success('保存成功')
                this.showBulletBox1 = false
                this.close()
                this.buyersCollectQuestions()
              }
            } else {
              this.form.answerDescription = this.form.answerDescription.replace(/<br\/>/g, '\n') || ''
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        } else {
          console.log('error submit!!');
          return false;
        }
      });

    },
    // 全选
    checkboxChange() {
      this.isDisabled = !this.checkboxAll
      this.bidQAInfoList.forEach(i => {
        this.$set(i, 'checkbox', this.checkboxAll)
      });
    },
    // 单选
    checkboxChangeOne() {
      const a = this.bidQAInfoList.filter(i => i.checkbox == true)
      if (a.length == 0) {
        this.isDisabled = true
        this.checkboxAll = false
      } else {
        this.isDisabled = false
        if (a.length != this.bidQAInfoList.length) {
          this.checkboxAll = false
        } else {
          this.checkboxAll = true
        }
      }
    },
    // 批量删除
    batchDel() {
      const a = this.bidQAInfoList.filter(i => i.checkbox == true)
      if (a.length == 0) {
        this.$message('请勾选')
        return
      }
      let list = []
      let result = false
      a.forEach(i => {
        if (i.qaAnswerInfoList.length != 0) {
          // list.push(i.qaAnswerInfoList[0].bidAnswerNo)
          i.qaAnswerInfoList.forEach(j => {
            list.push(j.bidAnswerNo)
          });
        } else {
          console.log('没有回复数据')
        }
      });
      this.$confirm(
        '请确认是否删除勾选的' + list.length + '条回复内容，删除后不能撤回。',
        '批量删除回复',
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          type: 'warning',
          confirmButtonText: "确认删除",
          cancelButtonText: '取消',
        }).then(() => {
          this.buyersQuestionsReplyOperat(list, 3)
        }).catch(() => {
        });
    },
    // 批量发布
    batchRelease() {
      const a = this.bidQAInfoList.filter(i => i.checkbox == true)
      if (a.length == 0) {
        this.$message('请勾选')
        return
      }
      let list = []
      a.forEach(i => {
        if (i.qaAnswerInfoList.length != 0) {
          // list.push(i.qaAnswerInfoList[0].bidAnswerNo)
          i.qaAnswerInfoList.forEach(j => {
            list.push(j.bidAnswerNo)
          });
        } else {
          console.log('没有回复数据')
        }
      });
      this.buyersQuestionsReplyOperat(list, 1)
    },
    // 单次删除和撤回
    delRetract(list, handleType) {
      let content = ''
      let title = ''
      if (handleType == '2') {
        content = '确认撤回本条回复内容，撤回后请在【已回复问题】-【未发布】列表查看。'
        title = '撤回'
      } else {
        content = '确认删除本条回复内容，删除后不能撤回。'
        title = '删除'
      }
      this.$confirm(
        content,
        title,
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          type: 'warning',
          confirmButtonText: "确认" + title,
          cancelButtonText: '取消',
        }).then(() => {
          this.buyersQuestionsReplyOperat(list, handleType)
        }).catch(() => {
        });
    },
    //  采购商回复发布/撤回/删除
    buyersQuestionsReplyOperat(bidAnswerNos, handleType) {
      let param = {
        bidAnswerNos: bidAnswerNos,
        handleType: handleType, // 1发布,2撤回，3删除
        bidNo: this.bidNo,
      }
      InterfaceService.buyersQuestionsReplyOperat(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          if (handleType == '1') {
            this.$message.success('发布成功')
            this.showBulletBox1 = false
            this.close()
            this.publishStatus = "PUBLISH"
            this.isPublishStatus = "PUBLISH"
          } else if (handleType == '2') {
            this.$message.success('撤回成功')
            this.publishStatus = "ANNOUNCED"
            this.isPublishStatus = "ANNOUNCED"
          } else if (handleType == '3') {
            this.$message.success('删除成功')
          }
          this.buyersCollectQuestions()
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    init() {
      if(this.$parent){
        this.$parent.breadcrumb.push({ name: '答疑-问题汇总' })
      }
      this.bidNo = this.$route.query.bidNo || ''
      this.bidName = this.$route.query.bidName || ''
      this.buyersCollectQuestions()
    },
  },
  mounted() {
    this.init()
  },
  props: ['active']
};
</script>

<style lang="scss" scoped>
/deep/ .el-select {
  width: 100% !important;
}
.el-button + .el-button {
  margin-left: 8px !important;
}
// /deep/ .el-form-item__label {
//   // font-size: 12px !important;
//   padding: 0 !important;
//   color: #888 !important;
// }
// /deep/ .el-input--small .el-select,
// .el-input--small .el-input__inner {
//   &::placeholder {
//     font-size: 12px !important;
//   }
//   font-size: 12px !important;
// }
/deep/ .seatchW-width {
  width: inherit;
  .el-form-item__content {
    width: 300px;
  }
}
/deep/ .business {
  .el-form-item__label {
    width: 70px !important;
  }
  .el-form-item__content {
    margin-left: 70px !important;
  }
}
/deep/ .businessone {
  .el-form-item__label {
    width: 112px !important;
  }
  .el-form-item__content {
    margin-left: 112px !important;
  }
}

/deep/ .samll_label {
  .el-form-item__label {
    width: 70px !important;
  }
  .el-form-item__content {
    margin-left: 70px !important;
  }
}
.width1080 {
  width: calc(100% - 70px) !important;
}
.w120 {
  width: 120px !important;
}
.line {
  width: 100%;
  height: 1px;
  background-color: #eee;
  margin-top: 30px;
}
.dotted-line {
  width: 100%;
  margin-top: 10px;
  border-bottom: 1px dashed #eee;
}
.buyersAnswerQuestions {
  padding-bottom: 60px;
  .list-home {
    width: 1190px;
    margin: 0 auto;
    .box_steps {
      padding: 20px 0 30px;
      box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
    }
    .button-panel {
      .el-col {
        text-align: right;
      }
    }
    .list-content {
      margin: 10px 0;
      // tab栏
      .panel-switch {
        width: 100%;
        height: 40px;
        background-color: #f5f5f5;
        padding-right: 10px;
        margin-bottom: 6px;
        display: flex;
        justify-content: space-between;
        > ul {
          height: 100%;
          display: flex;
          li {
            padding: 0 17px;
            font-size: 14px;
            font-weight: 600;
            line-height: 20px;
            color: #888;
            position: relative;
            margin-right: 6px;
            line-height: 40px;
            &.active {
              color: #444;
            }
            &.active::before {
              content: "";
              width: 50%;
              height: 3px;
              background: rgba(201, 159, 79, 1);
              position: absolute;
              left: 25%;
              bottom: 4px;
            }
          }
        }
        .switch {
          line-height: 40px;
          .arrow {
            display: inline-block;
            width: 0;
            height: 0;
            border-right: 4px solid transparent;
            border-left: 4px solid transparent;
            border-bottom: 6px solid #0082ff;
            transition: transform 0.3s ease;
            &.active {
              transform-origin: 4px 3px;
              transform: rotate(180deg);
            }
          }
        }
      }
      // 搜索面板
      .panel {
        background: rgba(249, 249, 249, 1);
        padding: 20px 10px 20px 0px;
        .el-button + .el-button {
          margin-left: 18px;
        }
      }
      // 列表
      .list-box {
        margin-top: 10px;
        > ul {
          li {
            width: 100%;
            margin-bottom: 14px;
            border: 1px solid #ddd;
            &:hover {
              border: 1px solid #c99f4f;
            }
            .list-content-box {
              border: 1px solid #ddd;
              &:hover {
                border: 1px solid #c99f4f;
              }
            }
            .box {
              .header {
                width: 100%;
                height: 40px;
                display: flex;
                justify-content: space-between;
                border-bottom: 1px solid #eee;
                padding-right: 10px;
                .left {
                  display: flex;
                  .number {
                    width: 40px;
                    height: 40px;
                    text-align: center;
                    line-height: 40px;
                    background-color: #c99f4f;
                    font-size: 14px;
                    color: #fff;
                  }
                  > h1 {
                    font-size: 14px;
                    color: #444;
                    margin-left: 19px;
                    line-height: 40px;
                    > span {
                      font-weight: 700;
                    }
                  }
                }
                .right {
                  line-height: 40px;
                  display: flex;
                  > p {
                    font-size: 12px;
                    color: #888;
                    margin-right: 30px;
                    > span {
                      color: #444;
                    }
                  }
                  .switch {
                    .arrow {
                      display: inline-block;
                      width: 0;
                      height: 0;
                      border-right: 4px solid transparent;
                      border-left: 4px solid transparent;
                      border-bottom: 6px solid #0082ff;
                      transition: transform 0.3s ease;
                      &.active {
                        transform-origin: 4px 3px;
                        transform: rotate(180deg);
                      }
                    }
                  }
                }
              }
              .content {
                padding: 10px 10px 19px;
                display: flex;
                justify-content: space-between;
                .left {
                  width: 100%;
                  & ~ .right {
                    margin-left: 10px;
                  }
                  .info {
                    font-size: 12px;
                    line-height: 17px;
                    color: #444;
                  }
                }
                .right {
                  width: 60px;
                  border-left: 1px solid #eee;
                  font-size: 12px;
                  display: flex;
                  flex-direction: column;
                  justify-content: center;
                  .operat {
                    text-align: right;
                    p {
                      line-height: 17px;
                      margin-bottom: 4px;
                    }
                  }
                }
              }
              .annex {
                margin: 10px 0 20px;
                font-size: 12px;
                color: #444;
                display: flex;
                .annex-file {
                  margin: 0 10px 6px 0;
                  &:last-child {
                    margin-bottom: 0;
                  }
                }
                > span {
                  &.hand.blue {
                    margin-left: 6px;
                  }
                }
              }
              .quiz {
                display: flex;
                justify-content: space-between;
                color: #888;
              }
            }
          }
        }
        // 已回复
        .replied {
          li {
            display: flex;
            .checkbox {
              width: 20px;
              padding-top: 12px;
            }
            .list-content-box {
              width: 100%;
            }
            .reply-list-box {
              .box {
                &.isRelease {
                  width: 100%;
                }
                &.reply-content {
                  border-top: 1px solid #eee;
                  .header {
                    .left {
                      > h1 {
                        margin-left: 12px;
                        > span {
                          position: relative;
                          margin-right: 22px;
                          &.underline::before {
                            content: "";
                            position: absolute;
                            bottom: -3px;
                            left: -4px;
                            width: 36px;
                            height: 7px;
                            background: rgba(201, 159, 79, 0.7);
                            opacity: 1;
                          }
                        }
                      }
                    }
                    .right {
                      p.grey {
                        margin-right: 0;
                      }
                    }
                  }
                  .content {
                    border: none;
                  }
                  .annex {
                    margin-bottom: 0;
                  }
                }
              }
              &.mask {
                background-color: #ddd;
              }
            }
          }
        }
      }
    }
  }
}
.el-select {
  width: 100%;
}
.btn {
  width: 80px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  padding: 0;
}

.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}

.tab_type {
  background: #f9f9f9;
  margin: 30px 0 10px;
  > ul {
    width: 100%;
    height: 50px;
    border-bottom: 2px solid #ffd64e;
    font-weight: bold;
    > li {
      width: 120px;
      height: 50px;
      line-height: 50px;
      text-align: center;
      float: left;
      position: relative;
      font-size: 14px;
      color: #888;
      > p {
        width: 100%;
        height: 48px;
        margin-bottom: 2px;
      }
      &.active {
        > p {
          background-color: #313131;
          color: #fae2a5;
        }
      }
      .chlid-list {
        width: 120px;
        min-height: 50px;
        position: absolute;
        left: 0;
        top: 0;
        z-index: 1;
        > ul {
          display: none;
        }
      }
      .chlid-list {
        &:hover {
          > ul {
            margin-top: 58px;
            position: relative;
            display: block;
            &::after {
              position: absolute;
              left: 10px;
              top: -5px;
              content: "";
              width: 0;
              height: 0;
              border-right: 6px solid transparent;
              border-left: 6px solid transparent;
              border-bottom: 5px solid #313131;
            }
            > li {
              width: 120px;
              height: 48px;
              line-height: 48px;
              text-align: center;
              background-color: #313131;
              color: #fff;
              &.chlid-active {
                background: linear-gradient(
                  0deg,
                  rgba(16, 16, 24, 1) 0%,
                  rgba(90, 88, 88, 1) 100%
                );
                color: #fae2a5;
              }
            }
          }
        }
      }
    }
  }
}
/deep/ .claim {
  width: 100%;
  min-height: 140px;
  .el-textarea__inner {
    min-height: 140px !important;
    resize: none;
    overflow: auto;
  }
}
// 弹框
.drafts-list {
  .uploadFileList {
    margin-top: 20px;
    > .title-info {
      font-size: 14px;
      line-height: 20px;
      color: rgba(68, 68, 68, 1);
      > p {
        margin-right: 6px;
        display: inline-block;
      }
      > span {
        font-size: 12px;
        margin-right: 10px;
      }
    }
    .fileList {
      width: 100%;
      border: 1px solid rgba(221, 221, 221, 1);
      padding: 0 10px 14px 10px;
      margin: 6px 0 0px;
      > p {
        margin-top: 14px;
        font-size: 12px;
        line-height: 17px;
        color: rgba(68, 68, 68, 1);
        &.noData {
          color: #bbb;
        }
        > span {
          margin-right: 10px;
          &:first-child {
            margin-left: 6px;
          }
        }
      }
    }
  }
}
.searchbox {
  text-align: center;
  margin-top: 20px;
  display: flex;
  justify-content: center;
  .searchBtn {
    width: 120px;
    height: 34px;
    line-height: 34px;
    background: linear-gradient(
      122deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(255, 255, 255, 1);
    display: inline-block;
    cursor: pointer;
  }
  .clearBtn {
    width: 120px;
    margin-left: 20px;
    height: 34px;
    line-height: 32px;
    border: 1px solid rgba(201, 159, 79, 1);
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(201, 159, 79, 1);
    display: inline-block;
    cursor: pointer;
  }
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
</style>
