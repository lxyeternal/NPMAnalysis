<template>
  <div class="bid">
    <div class="page" v-show="stepNum==0">
      <!-- 审批状态 -->
      <div class="box_type" v-if="ibOaIssueAppBean.approveStatus">
        <p>状态：{{ibOaIssueAppBean.approveStatus}}</p>
        <div class="annex">
          <div class="left grey">OA流程编号：</div>
          <div class="right">{{ibOaIssueAppBean.approveId}}</div>
        </div>
        <div class="annex">
          <div class="left grey">OA审批凭证：</div>
          <div class="right">
            <p v-for="(a,ind) in ibOaIssueAppBean.approveAttachInfos" :key="ind+'p'">
              {{a.attachName}}
              <span class="hand blue" @click="handleView(a.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(a.attachName,a.attachUrl)">下载</span>
            </p>
          </div>
        </div>
      </div>

      <div class="order-info-title">技术标</div>
      <div class="uploadFileList">
        <div class="title-info">
          <p><i class="red" v-if="isBid=='0'">* </i>甲供直采招标技术要求</p><span v-if="isBid=='0'" class="hand blue" @click="openUpload('skillsRequirement')">上传</span>
          <input class="uploadFile" ref="skillsRequirement" type="file" @change="handleUpload($event,'9',skillsRequirement)">
        </div>
        <div class="fileList">
          <p class="noData" v-if="!skillsRequirement.length">未上传附件！</p>
          <p v-for="(a,index) in skillsRequirement" :key="index+'skillsRequirement'">{{a.attachName}}<span class="hand blue" @click="handleView(a.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(a.attachName,a.attachUrl)">下载</span><span class="hand blue" @click="del(skillsRequirement,index)" v-if="isBid=='0'">删除</span></p>
        </div>
      </div>
      <div class="uploadFileList">
        <div class="title-info">
          <p><i class="red" v-if="isBid=='0'">* </i>甲供直采招标设备技术偏离表</p><span v-if="isBid=='0'" class="hand blue" @click="openUpload('technicalDeviation')">上传</span>
          <input class="uploadFile" ref="technicalDeviation" type="file" @change="handleUpload($event,'18',technicalDeviation)">
        </div>
        <div class="fileList">
          <p class="noData" v-if="!technicalDeviation.length">未上传附件！</p>
          <p v-for="(a,index) in technicalDeviation" :key="index+'technicalDeviation'">{{a.attachName}}<span class="hand blue" @click="handleView(a.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(a.attachName,a.attachUrl)">下载</span><span class="hand blue" @click="del(technicalDeviation,index)" v-if="isBid=='0'">删除</span></p>
        </div>
      </div>
      <div class="line"></div>
      <div class="order-info-title">商务标</div>
      <div class="uploadFileList">
        <div class="title-info">
          <p><i class="red" v-if="isBid=='0'">* </i>报价清单</p><span v-if="isBid=='0'" class="hand blue" @click="openUpload('quotationList')">上传</span>
          <p>请上传格式为xlsx的文件。</p>
          <input class="uploadFile" ref="quotationList" type="file" @change="handleUpload($event,'13',quotationList)">
        </div>
        <div class="fileList">
          <p class="noData" v-if="!quotationList.length">未上传附件！</p>
          <p v-for="(a,index) in quotationList" :key="index+'quotationList'">{{a.attachName}}<span class="hand blue" @click="handleView(a.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(a.attachName,a.attachUrl)">下载</span><span class="hand blue" @click="del(quotationList,index)" v-if="isBid=='0'">删除</span></p>
        </div>
        <div class="mockList f14 hand" v-if="isBid=='0' && mockList.length && mockFlg == '1' && !isNextStep && !isResetMockList && inventoryFlag != '0'" @click="postBuyersBid('0',1)">设置/查看模拟清单</div>
        <div class="mockList f14 hand" v-if="isBid=='1' && mockFlg == '1' && inventoryFlag != '0'" @click="goViewMockList">查看模拟清单</div>
      </div>
      <div class="mock-list" v-if="inventoryFlag != '0'">
        <p><i class="red" v-if="isBid=='0'">* </i>是否要模拟清单：</p>
        <el-radio-group v-model="mockFlg" :disabled="isBid!='0'">
          <el-radio :label="'1'">是</el-radio>
          <el-radio :label="'0'">否</el-radio>
        </el-radio-group>
      </div>
      <div class="uploadFileList">
        <div class="title-info">
          <p><i class="red" v-if="isBid=='0'">* </i>招标文件(基本版)</p><span v-if="isBid=='0'" class="hand blue" @click="handleDownTemp(basicEdition.attachName,basicEdition.attachUrl)">下载模板</span><span v-if="isBid=='0'" class="hand blue" @click="openUpload('biddingDocuments')">上传</span>
          <p>招标文件含：承诺表、全国业务代表人证明书、材料设备供应商厂家基本情况表、指定经销商或代理商名录。格式为doc、docx的文件。</p>
          <input class="uploadFile" ref="biddingDocuments" type="file" @change="handleUpload($event,'16',biddingDocuments)">
        </div>
        <div class="fileList">
          <p class="noData" v-if="!biddingDocuments.length">未上传附件！</p>
          <p v-for="(a,index) in biddingDocuments" :key="index+'biddingDocuments'">{{a.attachName}}<span class="hand blue" @click="handleView(a.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(a.attachName,a.attachUrl)">下载</span><span class="hand blue" @click="del(biddingDocuments,index)" v-if="isBid=='0'">删除</span></p>
        </div>
      </div>
      <div class="uploadFileList">
        <div class="title-info">
          <p><i class="red" v-if="isBid=='0'">* </i>招标文件(专业版)</p><span class="hand blue" v-if="isBid=='0'" @click="handleDownTemp(professionalEdition.attachName,professionalEdition.attachUrl)">下载模板</span><span v-if="isBid=='0'" class="hand blue" @click="openUpload('biddingDocumentsSpecialty')">上传</span>
          <p>请上传格式为doc、docx的文件。</p>
          <input class="uploadFile" ref="biddingDocumentsSpecialty" type="file" @change="handleUpload($event,'17',biddingDocumentsSpecialty)">
        </div>
        <div class="fileList">
          <p class="noData" v-if="!biddingDocumentsSpecialty.length">未上传附件！</p>
          <p v-for="(a,index) in biddingDocumentsSpecialty" :key="index+'biddingDocumentsSpecialty'">{{a.attachName}}<span class="hand blue" @click="handleView(a.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(a.attachName,a.attachUrl)">下载</span><span class="hand blue" @click="del(biddingDocumentsSpecialty,index)" v-if="isBid=='0'">删除</span></p>
        </div>
      </div>
      <div class="uploadFileList">
        <div class="title-info">
          <p><i class="red" v-if="isBid=='0'">* </i>针对绿地各地分公司联系人</p><span v-if="isBid=='0'" class="hand blue" @click="openUpload('companyContacts')">上传</span>
          <p>请上传格式为xlsx的文件。</p>
          <input class="uploadFile" ref="companyContacts" type="file" @change="handleUpload($event,'14',companyContacts)">
        </div>
        <div class="fileList">
          <p class="noData" v-if="!companyContacts.length">未上传附件！</p>
          <p v-for="(a,index) in companyContacts" :key="index+'companyContacts'">{{a.attachName}}<span class="hand blue" @click="handleView(a.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(a.attachName,a.attachUrl)">下载</span><span class="hand blue" @click="del(companyContacts,index)" v-if="isBid=='0'">删除</span></p>
        </div>
      </div>
      <div class="uploadFileList">
        <div class="title-info">
          <p>送样清单</p><span v-if="isBid=='0'" class="hand blue" @click="openUpload('sampleList')">上传</span>
          <p>请上传送样清单，格式为xlsx。</p>
          <input class="uploadFile" ref="sampleList" type="file" @change="handleUpload($event,'15',sampleList)">
        </div>
        <div class="fileList">
          <p class="noData" v-if="!sampleList.length">未上传附件！</p>
          <p v-for="(a,index) in sampleList" :key="index+'sampleList'">{{a.attachName}}<span class="hand blue" @click="handleView(a.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(a.attachName,a.attachUrl)">下载</span><span class="hand blue" @click="del(sampleList,index)" v-if="isBid=='0'">删除</span></p>
        </div>
      </div>
      <div class="order-info-title">其他附件</div>
      <div class="uploadFileList">
        <div class="title-info">
          <p>其他附件</p><span v-if="isBid=='0'" class="hand blue" @click="openUpload('othersList')">上传</span>
          <input class="uploadFile" ref="othersList" type="file" @change="handleUpload($event,'54',othersList)">
        </div>
        <div class="fileList">
          <p class="noData" v-if="!othersList.length">未上传附件！</p>
          <p v-for="(a,index) in othersList" :key="index+'othersList'">{{a.attachName}}<span class="hand blue" @click="handleView(a.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(a.attachName,a.attachUrl)">下载</span><span class="hand blue" @click="del(othersList,index)" v-if="isBid=='0'">删除</span></p>
        </div>
      </div>
      <!-- 是否设置过模拟清单 -->
      <FixBottom class="bottom" v-if="isBid=='0'">
        <!-- 未设置过模拟清单 -->
        <div class="tc" v-if="mockFlg == '1' && (!mockList.length || isResetMockList) && inventoryFlag != '0'">
          <el-button type="primary" @click="postBuyersBid('0',1)" :disabled="isNextStep" :class="{'isDisabled-primary':isNextStep}">下一步</el-button>
          <el-button @click="postBuyersBid('0')">保存</el-button>
        </div>
        <!-- 设置过模拟清单 -->
        <div class="tc" v-else>
          <el-button type="primary" :class="{'isDisabled-primary':active<=1 && ((!ibOaIssueAppBean.approveStatus || ibOaIssueAppBean.approveStatus != '审批成功') || (!ibOaPreAppBean.approveStatus || ibOaPreAppBean.approveStatus != '审批成功'))}" @click="isBuyersBid('1')">发标</el-button>
          <el-button v-if="!ibOaIssueAppBean.approveStatus" type="primary" @click="postBuyersBid('0', null, 'submitBidding');">提交招标文件审批</el-button>
          <el-button v-else type="primary" :disabled="true" class="isDisabled-primary">已提交审批</el-button>
          <el-button @click="postBuyersBid('0')">保存</el-button>
          <el-button @click="packageDownload">打包下载招标文件</el-button>
        </div>
      </FixBottom>
      <!-- 发标后 -->
      <div class="butDownload" v-if="isBid=='1'">
        <div class="hand" @click="packageDownload">打包下载招标附件</div>
        <div class="hand" :class="{'isDisabled':active>1}" @click="editBid">编辑</div>
      </div>

    </div>
    <!-- 模拟清单 -->
    <SetMockList v-if="stepNum==1" :mockList="mockList" :bidNo="bidNo" @updateData="buyersBidDetails"></SetMockList>
    <!-- 提交招标文件审批 -->
    <el-dialog custom-class="dialog-box" :title="'提交招标文件审批'" :append-to-body="true" :lock-scroll="true" :visible.sync="showBulletBox1" width="840px" center :close-on-click-modal="false" @close="close()">
      <div class="drafts-list tl">
        <el-form class="form" size="small" label-width="100px" :model="form" :rules="rules" ref="formBulletBox1">
          <p class="f12 tc">请上传OA发标审批通过凭证附件。</p>
          <el-row>
            <el-col :span="24">
              <el-form-item label="OA流程编号：" prop="approveId">
                <el-input placeholder="请输入中标审批编号" v-model="form.approveId" clearable maxlength="32"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <div class="uploadFileList">
            <div class="title-info tl">
              <p>OA发标审批通过凭证</p><span class="hand blue" @click="openUpload('files')">上传</span>
              <input class="uploadFile" ref="files" type="file" @change="handleUpload($event,'37',form.files)">
            </div>
            <div class="fileList">
              <p class="noData" v-if="form.files.length == 0">未上传附件！</p>
              <p v-for="(item,ind_t) in form.files" :key="ind_t+'files'">{{item.attachName}}<span class="hand blue" @click="handleView(item.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(item.attachName,item.attachUrl)">下载</span><span class="hand blue" @click="del(form.files,ind_t)">删除</span></p>
            </div>
          </div>
        </el-form>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="documentApproval()">确认提交</div>
        <div class="clearBtn" @click="showBulletBox1=false;close()">取消</div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import { viewFile } from '@/utils/orderUtil';
import FixBottom from "@/components/base/FixBottom";
import SetMockList from "@/components/tender/bid/setMockList";
export default {
  components: {
    Loading,
    FixBottom,
    SetMockList,
  },
  computed: {
    isNextStep() {
      if (!this.skillsRequirement.length) {
        return true
      } else if (!this.technicalDeviation.length) {
        return true
      } else if (!this.quotationList.length) {
        return true
      } else if (this.mockFlg == '-1' && inventoryFlag != '0') {
        return true
      } else if (!this.biddingDocuments.length) {
        return true
      } else if (!this.biddingDocumentsSpecialty.length) {
        return true
      } else if (!this.companyContacts.length) {
        return true
      } else {
        return false
      }
    }
  },
  data() {
    return {
      isLoading: false,
      bidNo: '',
      stepNum: 0,
      inventoryFlag: '',// 是否需要招标模板清单（1-是，0-否）

      isResetMockList: false, // 重新上传报价清单后是否重新设置模拟清单
      mockFlg: '-1',// 是否设置模拟清单 1:是;0否
      mockList: [],// 模拟清单套餐名称列表
      skillsRequirement: [],
      technicalDeviation: [],
      quotationList: [],
      companyContacts: [],
      sampleList: [],
      othersList: [],
      biddingDocuments: [],
      biddingDocumentsSpecialty: [],
      type: '',
      isBid: '0', // 0:发标中 '1'发标后
      id: '', // 上传附件id
      bidName: '',
      basicEdition: {},//招标文件(基本版)
      professionalEdition: {},//招标文件(专业版)
      delList: [],
      ossFileBeanList: [],

      ibOaIssueAppBean: {}, // 发标审批信息
      ibOaPreAppBean: {}, // 资格预审入围审批
      // 提交招标文件审批
      showBulletBox1: false,
      form: {
        files: [],
        approveId: '',
      },
      rules: {
        approveId: [
          { required: true, message: '必填', trigger: 'blur' }
        ],
      },
    };
  },
  methods: {
    goViewMockList() {
      this.$setRootScope('mockList', JSON.stringify(this.mockList))
      window.open(this.$router.resolve({
        path: "/viewMockList_b",
        query: {
          bidName: this.bidName,
          bidNo: this.bidNo,
          tab: '1'
        }
      }).href, '_blank')
    },
    editBid() {
      this.$confirm(
        "若招标文件有严重问题需要替换，请联系平台客服申请开放该【编辑】入口。客服电话：400-0609-008",
        "编辑",
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          confirmButtonText: "确认",
          cancelButtonText: '取消',
        }).then(() => {
          this.submit(params)
        }).catch(() => {
        });
    },
    // 发标检验
    isBuyersBid(handleType) {
      if (this.active < 1) {
        return this.$message('未到发标阶段该功能未开放')
      }
      if (!this.ibOaIssueAppBean.approveStatus && !this.ibOaPreAppBean.approveStatus) {
        return this.$message({
          dangerouslyUseHTMLString: true,
          message: '<p>您未提交「入围审批」、「招标文件审批」的OA发标审批通过凭证附件，该功能不能操作，</br></br>请先提交审批通过附件。</p>'
        })
      }
      if (!this.ibOaPreAppBean.approveStatus) {
        return this.$message({
          dangerouslyUseHTMLString: true,
          message: '<p>您未提交「入围审批」的OA资格预审入围名单审批通过凭证附件，该功能不能操作，</br></br>请先提交审批通过附件。</p>'
        })
      }
      if (!this.ibOaIssueAppBean.approveStatus) {
        return this.$message({
          dangerouslyUseHTMLString: true,
          message: '<p>您未提交「招标文件审批」的OA发标审批通过凭证附件，该功能不能操作，</br></br>请先提交审批通过附件。</p>'
        })
      }
      this.postBuyersBid(handleType)
    },
    // 确认提交提交招标文件审批
    documentApproval() {
      // this.buyersBidDetails(true)
      // return
      this.$refs['formBulletBox1'].validate((valid) => {
        if (valid) {
          let approveAcctName = this.$store.state.userInfo.acctName || ''
          let approveAttachInfos = []

          this.form.files.forEach(i => {
            approveAttachInfos.push({
              attachPath: i.fileUrl,
              attachName: i.attachName,
              attachType: i.attachType,
            })
          });

          let param = {
            bidNo: this.bidNo,
            approveId: this.form.approveId,
            approveAcctName: approveAcctName,
            approveType: '2',//1-资格预审，2-发标，3-中标
            approveAttachInfos: approveAttachInfos,
            approveName: '', // 审批名称
          }
          InterfaceService.submitOaApprove(param, data => {
            this.isLoading = false;
            if (data && data.respData && data.respData.respCode === "0000") {
              this.$message.success('上传OA发标审批通过凭证成功')
              this.showBulletBox1 = false
              this.buyersBidDetails(true)
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        } else {
          console.log('error submit!!');
          return false
        }
      });
    },
    // 采购商发标初始化
    buyersBidData() {
      let param = {
        bidNo: this.bidNo,
        fileTypes: ['ISSUE_SPECIL_TEMPLATE', 'ISSUE_BASE_TEMPLATE']
      }
      InterfaceService.buyersBidData(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          let bidAttachbeans = data.respData.bidAttachbeans || []
          bidAttachbeans.forEach(i => {
            if (i.attachType == '22') {
              this.basicEdition = i
            } else if (i.attachType == '23') {
              this.professionalEdition = i
            }
          });
          this.$forceUpdate();
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 采购商发标
    postBuyersBid(handleType, stepNum, subType) {
      // 提交招标文件审批 需要验证
      if ((handleType != '0' && handleType != '4') || subType == 'submitBidding') {
        if (!this.skillsRequirement.length) {
          return this.$message("请上传甲供直采招标技术要求附件");
        } else if (!this.technicalDeviation.length) {
          return this.$message("请上传甲供直采招标设备技术偏离表附件");
        } else if (!this.quotationList.length) {
          return this.$message("请上传报价清单");
        } else if (this.mockFlg == '-1' && this.inventoryFlag != '0') {
          return this.$message("请选择是否要模拟清单");
        } else if (!this.biddingDocuments.length) {
          return this.$message("请上传招标文件(基本版)附件");
        } else if (!this.biddingDocumentsSpecialty.length) {
          return this.$message("请上传招标文件(专业版)附件");
        } else if (!this.companyContacts.length) {
          return this.$message("请上传针对绿地各地分公司联系人");
        }
      }
      let list = []
      let bidAttachBeans = []
      list = [...this.skillsRequirement, ...this.technicalDeviation, ...this.biddingDocuments, ...this.biddingDocumentsSpecialty, ...this.quotationList, ...this.companyContacts, ...this.sampleList, ...this.othersList]
      list.forEach(i => {
        if (!i.ossFileId && i.fileUrl) {
          bidAttachBeans.push({
            attachPath: i.fileUrl,
            attachName: i.attachName,
            attachType: i.attachType,
          })
        }
      });
      if (this.delList.length != 0) {
        bidAttachBeans = bidAttachBeans.concat(this.delList)
      }
      let param = {
        bidNo: this.bidNo,
        bidAttachBeans: bidAttachBeans,
        handleType: handleType, //0-保存，1-发标
        mockFlg: this.mockFlg == '-1' ? '' : this.mockFlg
      }
      InterfaceService.postBuyersBid(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          if (handleType == '0') {
            this.$message.success('保存成功')
            this.buyersBidDetails()
            if (stepNum) {
              this.stepNum = stepNum
              this.isResetMockList = false
            }
          } else {
            this.$message.success('发标成功')
            this.$router.push({ path: '/tenderManagement' })
          }
          if (subType == 'submitBidding') {
            this.showBulletBox1 = true
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 采购商发标详情
    buyersBidDetails(type) {
      let param = {
        bidNo: this.bidNo
      }
      InterfaceService.buyersBidDetails(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          // 获取
          this.inventoryFlag = data.respData.inventoryFlag || '0'
          this.ibOaIssueAppBean = data.respData.ibOaIssueAppBean || {}
          this.ibOaPreAppBean = data.respData.ibOaPreAppBean || {}
          this.mockFlg = data.respData.mockFlg || '-1'
          this.mockList = data.respData.mockList || []
          this.mockList.forEach(i => {
            this.$set(i, 'isViewTitleTab', false)
            this.$set(i, 'oldMockName', i.mockName)
          });
          if (!!type) { return }

          // 清空数据
          this.delList = []
          this.skillsRequirement = []
          this.technicalDeviation = []
          this.biddingDocuments = []
          this.biddingDocumentsSpecialty = []
          this.quotationList = []
          this.companyContacts = []
          this.sampleList = []
          this.othersList = []
          let list = data.respData.bidAttachBeans || []
          if (list.length != 0) {
            list.forEach(i => {
              if (i.attachType == '9') {
                this.skillsRequirement.push(i)
              } else if (i.attachType == '18') {
                this.technicalDeviation.push(i)
              } else if (i.attachType == '16') {
                this.biddingDocuments.push(i)
              } else if (i.attachType == '17') {
                this.biddingDocumentsSpecialty.push(i)
              } else if (i.attachType == '13') {
                this.quotationList.push(i)
              } else if (i.attachType == '14') {
                this.companyContacts.push(i)
              } else if (i.attachType == '15') {
                this.sampleList.push(i)
              } else if (i.attachType == '54') {
                this.othersList.push(i)
              }
            });
            this.$forceUpdate();
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 触发上传
    openUpload(item) {
      this.$refs[item].click()
    },
    // 上传文件
    handleUpload(e, type, list) {
      const file = e.target.files[0];
      console.log(list)
      if (file) {
        let a = file.name.split(".")
        const fileType = a[a.length - 1];
        if (type == '16' || type == '17') {
          const reg = /(docx|doc)/i;
          if (!reg.test(fileType)) {
            this.$message.error("请上传docx、doc格式文件");
            return;
          }
        } else if (type == '13' || type == '14' || type == '15') {
          const reg = /(xlsx|XLSX)/i;
          if (!reg.test(fileType)) {
            this.$message.error("请上传xlsx格式文件");
            return;
          }
        } else {
          // if (file.size > 20971520) {
          //   this.$message.error("单个附件大小不超过20MB");
          //   return;
          // }
        }
        this.uploadContractToOss(type, file).then(res => {
          // 获取文件全路径
          let param = {
            ossFile: [{
              fileType: type, filePath: res.url
            }],
            appName: "PROD"
          };
          InterfaceService.ossSignatureUrl(param, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              let ossFile = data.respData.ossFile || [];
              ossFile.forEach((i, index) => {
                if ((type == '16' || type == '17' || type == '13' || type == '14' || type == '15') && list.length) {
                  if (list[0].ossFileId) {
                    this.delList.push({
                      ossFileId: list[0].ossFileId,
                      attachType: list[0].attachType
                    })
                  }
                  list.splice(index, 1)
                }
                if (type == '13' && this.delList.some(j => j.attachType == '13') && this.mockFlg == '1') {
                  this.$message('您已更换报价清单,请重新设置模拟清单')
                  this.isResetMockList = true
                }
                list.push({
                  attachName: file.name,
                  attachUrl: i.url,
                  fileUrl: i.filePath,
                  attachType: i.fileType,
                })
              });
              console.log(list)
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        })
      }
      e.target.value = "";
    },
    uploadContractToOss(type, file) {
      return new Promise((resolve, reject) => {
        InterfaceService.getOssSignatureDisposable(file.name, {
          type: type,
          appName: "PROD",
        }, (data) => {
          let signature = data;
          this.uploadHander(0, file, new Date().getTime() + '/', signature, (pos, file, dirType, signature) => {
            console.log(signature.dir);
            let u = signature.dir + dirType + file.name;
            console.log(u);
            resolve({ url: u });
          }, () => { this.isLoading = true; }, () => { this.isLoading = false; })
        }, (data) => { }, () => { this.isLoading = true; }, () => { this.isLoading = false; });
      })

    },
    uploadHander(pos, file, dirType, signature, callBack, loadingStartCb, loadingEndCb) {
      //去后端拿签名
      InterfaceService.uploadToOss(signature, file, dirType, pos, callBack, '', '', loadingStartCb, loadingEndCb)
    },
    // 打包下载
    packageDownload() {
      let fileInfoBeans = []
      this.skillsRequirement.forEach(i => {
        fileInfoBeans.push({
          archivePath: '技术标/' + (i.attachName || ''),
          fileUrl: i.attachUrl,
        })
      })
      this.technicalDeviation.forEach(i => {
        fileInfoBeans.push({
          archivePath: '技术标/' + (i.attachName || ''),
          fileUrl: i.attachUrl,
        })
      })
      this.biddingDocuments.forEach(i => {
        if (!i.attachUrl && this.basicEdition.attachUrl) {
          fileInfoBeans.push({
            archivePath: '商务标/' + (this.basicEdition.attachName || ''),
            fileUrl: this.basicEdition.attachUrl,
          })
        } else {
          fileInfoBeans.push({
            archivePath: '商务标/' + (i.attachName || ''),
            fileUrl: i.attachUrl,
          })
        }
      })
      this.biddingDocumentsSpecialty.forEach(i => {
        if (!i.attachUrl && this.professionalEdition.attachUrl) {
          fileInfoBeans.push({
            archivePath: '商务标/' + (this.professionalEdition.attachName || ''),
            fileUrl: this.professionalEdition.attachUrl,
          })
        } else {
          fileInfoBeans.push({
            archivePath: '商务标/' + (i.attachName || ''),
            fileUrl: i.attachUrl,
          })
        }
      })
      this.quotationList.forEach(i => {
        fileInfoBeans.push({
          archivePath: '商务标/' + (i.attachName || ''),
          fileUrl: i.attachUrl,
        })
      })
      this.companyContacts.forEach(i => {
        fileInfoBeans.push({
          archivePath: '商务标/' + (i.attachName || ''),
          fileUrl: i.attachUrl,
        })
      })
      this.sampleList.forEach(i => {
        fileInfoBeans.push({
          archivePath: '商务标/' + (i.attachName || ''),
          fileUrl: i.attachUrl,
        })
      })
      this.othersList.forEach(i => {
        fileInfoBeans.push({
          archivePath: '其他附件/' + (i.attachName || ''),
          fileUrl: i.attachUrl,
        })
      })
      if (fileInfoBeans.length == 0) {
        return this.$message.error("暂无招标文件可供下载")
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            // const files = [
            //   { name: this.bidName + "招标文件.zip", url: url }
            // ];
            // this.$download(files, () => {this.isLoading = true}, () => {this.isLoading = false}).then(() => {
            //   this.$message.success("已下载");
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: this.bidName + "招标文件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    // 文件下载
    handleDownTemp(name, url) {
      console.log(name, url)
      this.$download([{
        name: name,
        url: url
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 在线预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    // 删除文件
    del(list, index) {
      if (list[index].ossFileId) {
        this.delList.push(list[index])
      }
      list.splice(index, 1)
      this.$message.success('已删除')
    },
    close() {
      this.$refs['formBulletBox1'].resetFields();
    },
    init() {
      this.bidName = this.$route.query.bidName || ''
      this.bidNo = this.$route.query.bidNo || ''
      console.log(this.active)
      if (this.active <= 1) {
        this.isBid = '0'
        this.buyersBidData()
      } else {
        this.isBid = '1'
      }
      if (this.$parent) {
        this.$parent.breadcrumb.push({ name: '发标' })
      }
      this.buyersBidDetails()
    },
  },
  mounted() {
    this.init()
  },
  props: ['active'],
  watch: {
    active(val) {
      if (this.active <= 1) {
        this.isBid = '0'
        this.buyersBidData()
      } else {
        this.isBid = '1'
      }
    }
  }
};
</script>

<style lang="scss" scoped>
.line {
  width: 100%;
  height: 1px;
  background-color: #eee;
  margin-top: 30px;
}
.bid {
  padding-bottom: 60px;
  .page {
    width: 1190px;
    margin: 0 auto;
    .box_steps {
      padding: 20px 0 30px;
      box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
    }

    .butDownload {
      margin: 40px auto 0;
      display: flex;
      justify-content: center;
      > .hand {
        width: 260px;
        height: 50px;
        background: rgba(255, 255, 255, 1);
        border: 1px solid rgba(201, 159, 79, 1);
        font-size: 14px;
        color: rgba(201, 159, 79, 1);
        line-height: 48px;
        text-align: center;
        margin-right: 20px;
      }
    }
  }
}
.tab_type {
  background: #f9f9f9;
  margin: 30px 0 20px;
  ul {
    width: 100%;
    height: 50px;
    border-bottom: 2px solid #ffd64e;
    font-weight: bold;
    li {
      width: 120px;
      height: 50px;
      line-height: 50px;
      text-align: center;
      float: left;
      position: relative;
      font-size: 14px;
      color: #bbb;
      > p {
        width: 100%;
        height: 48px;
        margin-bottom: 2px;
      }
      &.active {
        > p {
          background-color: #313131;
          color: #fae2a5;
        }
      }
      &.highlight {
        > p {
          color: #888;
          cursor: pointer;
          &:hover {
            color: #fae2a5;
            background-color: #555;
          }
        }
      }
    }
  }
}
.uploadFile {
  position: absolute;
  left: -9999px;
  width: 0px;
  height: 0px;
  overflow: hidden;
  opacity: 0;
}
.uploadFileList {
  margin-top: 20px;
  > .title-info {
    font-size: 14px;
    line-height: 20px;
    color: rgba(68, 68, 68, 1);
    > p {
      margin-right: 6px;
      display: inline-block;
      & + p {
        font-size: 12px;
        color: #888;
        line-height: 17px;
        display: block;
        margin-top: 6px;
      }
    }
    > span {
      font-size: 12px;
      margin-right: 10px;
      & + p {
        font-size: 12px;
        color: #888;
        line-height: 17px;
        display: block;
        margin-top: 6px;
      }
    }
  }
  .fileList {
    width: 100%;
    border: 1px solid rgba(221, 221, 221, 1);
    padding: 0 10px 14px 10px;
    margin: 4px 0 30px;
    > p {
      margin-top: 14px;
      font-size: 12px;
      line-height: 17px;
      color: rgba(68, 68, 68, 1);
      &.noData {
        color: #bbb;
      }
      > span {
        margin-right: 10px;
        &:first-child {
          margin-left: 6px;
        }
      }
    }
  }
  // .mockList {
  //   width: 100%;
  //   height: 34px;
  //   background: rgba(245, 245, 245, 1);
  //   line-height: 34px;
  //   text-align: center;
  //   margin: -29px 0 30px 0;
  // }
  .mockList {
    width: 100%;
    height: 34px;
    background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
    color: #df0a0a;
    line-height: 34px;
    text-align: center;
    margin: -19px 0 40px 0;
    font-weight: 600;
  }
}
.mock-list {
  margin-top: -16px;
  > p {
    display: inline-block;
    font-size: 14px;
    color: #888;
  }
}
// 对话框
/deep/ .dialog-box {
  .el-dialog__body {
    padding-bottom: 0 !important;
  }
  .el-dialog__footer {
    padding: 20px;
  }
  .el-form-item--small.el-form-item {
    margin-bottom: 30px !important;
  }
  .drafts-list {
    .f12.tc {
      margin-bottom: 18px;
    }
  }
  .uploadFileList {
    margin: 0;
    .fileList {
      margin-bottom: 0;
    }
  }
  .searchbox {
    text-align: center;
    margin-top: 20px;
    display: flex;
    justify-content: center;
    .searchBtn {
      width: 120px;
      height: 34px;
      line-height: 34px;
      background: linear-gradient(
        122deg,
        rgba(215, 176, 100, 1) 0%,
        rgba(236, 206, 139, 1) 100%
      );
      font-size: 12px;
      font-family: PingFang SC;
      color: rgba(255, 255, 255, 1);
      display: inline-block;
      cursor: pointer;
    }
    .clearBtn {
      width: 120px;
      margin-left: 20px;
      height: 34px;
      line-height: 32px;
      border: 1px solid rgba(201, 159, 79, 1);
      font-size: 12px;
      font-family: PingFang SC;
      color: rgba(201, 159, 79, 1);
      display: inline-block;
      cursor: pointer;
    }
  }
}
</style>
