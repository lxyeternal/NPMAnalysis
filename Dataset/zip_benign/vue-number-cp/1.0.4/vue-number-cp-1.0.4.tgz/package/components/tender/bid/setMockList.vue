<template>
  <div class="setMockList">
    <div class="page">
      <div class="order-info-title">设置模拟清单</div>
      <div v-show="stepNum == 1" class="createMockList-small hand" @click="save();showcreateMockList=true">创建模拟清单套餐</div>

      <!-- 设置模拟清单初始化 -->
      <div class="box1" v-show="stepNum == 0">
        <div class="createMockList hand" @click="showcreateMockList=true">创建模拟清单套餐</div>
        <p class="red f14">操作指引：模拟清单按套餐设置（如下图示例），可创建多个套餐，请先点击【创建模拟清单套餐】，输入套餐名称开始创建吧！</p>
        <p class="grey f14" style="margin: 16px 0 10px">示例图：</p>
        <img src="@/assets/images/tender/mockList.png" alt="">
      </div>

      <!-- 设置模拟清单 -->
      <div class="box2" v-show="stepNum == 1">
        <div class="title_tab" v-click-outside="saveTitle">
          <div class="tabs__nav-prev" v-show="isShowScroll" @click="scroll('left')"><i class="el-icon-caret-left"></i></div>
          <div class="tabs__nav" :class="{'isShowScroll':isShowScroll}" ref="tabs__nav">
            <ul ref="tabList">
              <li class="hand" v-for="(a,index) in mockList" :key="index+'li'" @click.stop="clickOne(a)" @dblclick="doubleClick(a,index)" :class="{active: mockNo==a.mockNo}">
                <span v-show="!a.isViewTitleTab">套餐：{{a.mockName}}</span>
                <!-- <input ref="inputTitle" class="mockProdList_title" v-show="a.isViewTitleTab" type="text" maxlength="30" v-model="a.mockName" @blur="editMockList(a)"> -->
                <input ref="inputTitle" class="mockProdList_title" v-show="a.isViewTitleTab" type="text" maxlength="30" v-model="a.mockName">
                <i v-if="a.isViewTitleTab && mockNo==a.mockNo" class="el-icon-circle-close title_tab_close" @click.stop="delMockList(a.mockNo,a.mockName)"></i>
              </li>
            </ul>
          </div>
          <div class="tabs__nav-next" v-show="isShowScroll" @click="scroll('right')"><i class="el-icon-caret-right"></i></div>
        </div>
        <TableThead :TopDistance="610">
          <tr slot="tr">
            <td width="46px">序号</td>
            <td width="206px"><i class="red">*</i>商品名称</td>
            <td width="98px" v-if="samplePicFlg=='1'">示例图片</td>
            <td width="48px">技术<br>标准</td>
            <td><i class="red">*</i>参数</td>
            <td width="58px">投标<br>品牌</td>
            <td width="58px">投标<br>型号</td>
            <td width="120px" class="tr"><i class="red">*</i>数量(单位)</td>
            <td width="96px">单价(不含税)(元)</td>
            <td width="96px">总价(不含税)(元)</td>
            <td width="80px" class="tr">操作</td>
          </tr>
        </TableThead>
        <table class="table">
          <thead>
            <tr>
              <td width="46px">序号</td>
              <td width="206px"><i class="red">*</i>商品名称</td>
              <td width="98px" v-if="samplePicFlg=='1'">示例图片</td>
              <td width="48px">技术<br>标准</td>
              <td><i class="red">*</i>参数</td>
              <td width="58px">投标<br>品牌</td>
              <td width="58px">投标<br>型号</td>
              <td width="120px" class="tr"><i class="red">*</i>数量(单位)</td>
              <td width="96px">单价(不含税)(元)</td>
              <td width="96px">总价(不含税)(元)</td>
              <td width="80px" class="tr">操作</td>
            </tr>
          </thead>
          <tbody class="tbody-row" v-for="(b,index) in mockProdList" :key="index+'mockProdList'">
            <tr>
              <td>{{index+1}}</td>
              <td class="textarea_box">
                <el-input type="textarea" placeholder="请输入商品名称，限60字" v-model="b.bidProdName" maxlength="60">
                </el-input>
              </td>
              <td v-if="samplePicFlg=='1'">
                <!-- 图片上传 -->
                <div class="info-master-img" v-if="b.samplePicFlg == '1'">
                  <div class="img-item" :class="{ 'has-img': b.ossUrl }">
                    <div class="img-item-cover">
                      <div class="img-item-add">
                        <label :for="'masterImg' + index" v-show="!b.ossUrl">
                          <i class="cross-add"></i>
                        </label>
                        <p v-show="!b.ossUrl" class="f12" style="line-height:17px;color: #bbb">点击上传图片</p>
                        <img v-if="b.ossUrl" :src="b.ossUrl" />
                        <input :id="'masterImg' + index" type="file" ref="imgFileBtn" @change="pushImg($event, b)" />
                      </div>
                      <div class="img-item-bottom clearfloat" v-if="b.ossUrl">
                        <a @click="dialogVisibleAttachUrl=b.ossUrl;dialogVisible=true">预览</a>
                        <a @click="clearImg(b)">删除</a>
                      </div>
                    </div>
                  </div>
                </div>
              </td>
              <td>要求</td>
              <td class="textarea_box">
                <el-input type="textarea" placeholder="请输入参数，限1000字" v-model="b.params" maxlength="1000">
                </el-input>
              </td>
              <td class="grey">供应商<br>填写</td>
              <td class="grey">供应商<br>填写</td>
              <td class="textarea_box prodCnt">
                <!-- @blur="checkCntUnit(b) -->
                <el-input type="textarea" placeholder="请输入数量" v-model.trim="b.prodCnt" maxlength="32" @input="b.prodCnt=b.prodCnt.replace(/[^\d.]/g,'')">
                </el-input>
                <p class="tr" style="margin-top: 7px">{{b.prodUnit}}</p>
              </td>
              <td class="grey tr">供应商填写</td>
              <td class="grey tr">供应商填写</td>
              <td class="tr">
                <p class="hand blue" style="margin-bottom: 4px;white-space: nowrap;" @click="$refs.addMockList.open([{id:b.id,mockNo:b.mockNo,bidProdNo:b.bidProdNo,operateType:'DELETE'}],mockNo)">重选商品</p>
                <p class="hand blue" @click="saveMockList([],'DELETE',[{id:b.id,mockNo:b.mockNo,bidProdNo:b.bidProdNo,operateType:'DELETE'}])">删除</p>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="addMockProduct hand" @click="save();$refs.addMockList.open([],mockNo)">新增模拟商品</div>
      </div>
      <!-- 底部按钮 -->
      <FixBottom class="bottom">
        <div class="tc">
          <el-button type="primary" :disabled="!stepNum || isUploadImg" :class="{'isDisabled-primary':(!stepNum || isUploadImg)}" @click="save();step('under')">下一步</el-button>
          <el-button @click="step('on')">上一步</el-button>
          <el-button :disabled="isUploadImg" :class="{'isDisabled':(isUploadImg)}" @click="save()">保存</el-button>
        </div>
      </FixBottom>
    </div>
    <!-- 新增模拟商品 -->
    <AddMockList ref="addMockList" @updateData="getMockList" :mockList="mockList"></AddMockList>
    <!-- 预览图片 -->
    <el-dialog title="图片预览" :visible.sync="dialogVisible" class="img-preview" width="840px">
      <div class="img-box">
        <img :src="dialogVisibleAttachUrl" alt="" />
      </div>
      <div class="shut-down hand" @click="dialogVisible=false">关闭</div>
    </el-dialog>
    <!-- 创建模拟清单 -->
    <el-dialog custom-class="dialog-box" :title="'创建模拟清单套餐'" :append-to-body="true" :lock-scroll="true" :visible.sync="showcreateMockList" width="840px" center :close-on-click-modal="false" @close="close()">
      <div class="drafts-list tl">
        <el-form class="form" size="small" label-width="90px" :model="formCreate" :rules="rulesCreate" ref="formcreateMockList">
          <el-row>
            <el-col :span="24">
              <el-form-item label="套餐名称：" prop="mockName">
                <el-input placeholder="请输入套餐名称，限30字" v-model="formCreate.mockName" clearable maxlength="30"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24" class="samplePicFlg">
              <el-form-item label="是否添加商品示例图：" prop="samplePicFlg">
                <el-radio-group v-model="formCreate.samplePicFlg">
                  <el-radio :label="'1'">是</el-radio>
                  <el-radio :label="'0'">否</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="createMockList()">确认提交</div>
        <div class="clearBtn" @click="showcreateMockList=false">取消</div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import { viewFile } from '@/utils/orderUtil';
import FixBottom from "@/components/base/FixBottom";
import { ImageUtil } from '@/utils/imageUtil';
import AddMockList from "@/components/tender/bid/addMockList";
import TableThead from "@/components/base/TableThead";
const clickOutside = {
  // 初始化指令
  bind(el, binding) {
    function clickHandler(e) {
      // 这里判断点击的元素是否是本身，是本身，则返回
      if (el.contains(e.target)) {
        return false;
      }
      // 判断指令中是否绑定了函数
      if (binding.expression) {
        // 如果绑定了函数 则调用那个函数，此处binding.value就是handleClose方法
        binding.value(e);
      }
    }
    // 给当前元素绑定个私有变量，方便在unbind中可以解除事件监听
    el.__vueClickOutside__ = clickHandler;
    document.addEventListener('click', clickHandler);
  },
  update() { },
  unbind(el, binding) {
    // 解除事件监听
    document.removeEventListener('click', el.__vueClickOutside__);
    delete el.__vueClickOutside__;
  },
};
export default {
  directives: { clickOutside },
  components: {
    Loading,
    FixBottom,
    AddMockList,
    TableThead
  },
  props: ['mockList', 'bidNo'],
  watch: {
    mockList(val) {
      console.log(val)
      val = val || []
      this.isScroll()
      if (!val.length) {
        this.stepNum = 0
      } else {
        this.stepNum = 1
        if (!this.mockNo) {
          this.mockNo = val[0].mockNo
          this.samplePicFlg = val[0].samplePicFlg
        } else {
          val.forEach(i => {
            if (this.mockNo == i.mockNo) {
              this.samplePicFlg = i.samplePicFlg
            }
          });
          this.$nextTick(() => {
            this.$refs.tabs__nav.scrollTo(this.$refs.tabs__nav.offsetWidth, 0)
          })
        }
        this.getMockList()
      }
    }
  },
  data() {
    return {
      isLoading: false,

      isShowScroll: false,
      stepNum: 0,
      showcreateMockList: false,
      mockNo: '',//当前模拟清单编号
      mockProdList: [],
      dialogVisibleAttachUrl: '',
      dialogVisible: false,
      samplePicFlg: '',// 列表是否显示示例图
      formCreate: {
        mockName: '',
        samplePicFlg: '',
      },
      rulesCreate: {
        mockName: [{ required: true, message: '必填', trigger: 'blur' }],
        samplePicFlg: [{ required: true, message: '必填', trigger: 'blur' }]
      },
      isUploadImg: false,
    }
  },
  methods: {
    saveTitle() {
      let a = this.mockList.filter(i => i.isViewTitleTab)
      if (a.length == 1 && !this.showcreateMockList) {
        this.editMockList(a[0])
      }
    },
    clickOne(a) {
      if (this.mockNo != a.mockNo) {
        this.mockList.forEach(i => {
          if (this.mockNo == i.mockNo && i.isViewTitleTab) {
            this.editMockList(i)
          }
        });
        this.save('1', a);
      }
    },
    doubleClick(a, index) {
      a.isViewTitleTab = true
      this.$nextTick(() => {
        this.$refs.inputTitle[index].focus()
      })
    },
    step(type) {
      if (type == 'on') {
        if (this.stepNum == 0) {
          this.$parent.stepNum = 0
        } else {
          this.save()
          this.mockList.length ? this.$parent.stepNum = 0 : this.stepNum--
        }
      } else {
        if (this.stepNum == 1) {
          this.$parent.stepNum = 0
        } else {
          this.stepNum++
        }
      }
    },
    // 判断套餐是否出现滚动条
    isScroll() {
      this.$nextTick(() => {
        this.$refs.tabList.offsetWidth > 1190 ? this.isShowScroll = true : this.isShowScroll = false
      })
    },
    scroll(type) {
      type == 'left' ? this.$refs.tabs__nav.scrollTo(this.$refs.tabs__nav.scrollLeft - 1190, 0) : this.$refs.tabs__nav.scrollTo(this.$refs.tabs__nav.scrollLeft + 1190, 0)
    },
    // 采购商创建模拟清单
    createMockList() {
      this.$refs['formcreateMockList'].validate((valid) => {
        if (valid) {
          let param = {
            bidNo: this.bidNo,
            mockName: this.formCreate.mockName,
            samplePicFlg: this.formCreate.samplePicFlg,
            operateType: 'ADD'
          }
          InterfaceService.createMockList(param, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              this.mockNo = data.respData.mockNo || this.mockList[0].mockNo
              this.$message.success('创建成功')
              this.showcreateMockList = false
              this.$emit('updateData')
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        } else {
          console.log('error submit!!');
          return false
        }
      });
    },
    editMockList(obj = {}) {
      if (obj.mockName == obj.oldMockName) {
        return obj.isViewTitleTab = false
      }
      let param = {
        bidNo: this.bidNo,
        mockName: obj.mockName,
        mockNo: obj.mockNo,
        samplePicFlg: obj.samplePicFlg,
        operateType: 'UPDATE'
      }
      InterfaceService.createMockList(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('编辑成功')
          this.$emit('updateData')
          obj.isViewTitleTab = false
        } else {
          // obj.isViewTitleTab = false
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 采购商查看模拟清单
    getMockList() {
      let param = {
        mockNo: this.mockNo,
      }
      InterfaceService.getMockList(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.mockProdList = data.respData.mockProdList || []
          this.mockProdList.forEach(i => {
            i.params = i.params.replace(/ +/gi, '') //去除字符串中的空格,保留换行
          });
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 采购商删除模拟清单
    delMockList(mockNo, mockName) {
      this.$confirm(
        "是否确认删除“" + mockName + "”内全部内容？删除后，不能撤回。",
        "删除套餐",
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确认删除",
          cancelButtonText: '取消',
        }).then(() => {
          let param = {
            mockNo: mockNo,
          }
          InterfaceService.delMockList(param, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              this.$message.success('删除成功')
              this.mockNo = ''
              this.$emit('updateData')
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        }).catch(() => {
        });
    },
    // 保存
    save(type, a) {
      // 列表无数据不保存
      if (!this.mockProdList.length) {
        if (type) {
          this.mockNo = a.mockNo;
          this.samplePicFlg = a.samplePicFlg;
        }
        this.getMockList();
        return console.log('禁止保存')
      }

      let listImg = [];
      this.mockProdList.forEach((i, index) => {
        if (i.file) {
          i.place = index
          listImg.push(i)
        }
      });

      if (listImg.length && this.samplePicFlg == '1') {
        this.isLoading = true
        let fileImgList = []
        listImg.forEach(i => {
          fileImgList.push(i.file)
        });
        ImageUtil.handleChangeMasterImg(fileImgList, 500, 1000, (files) => {
          // console.log(files)
          listImg.forEach((i, index) => {
            files.forEach(j => {
              if (i.file.name == j.name && i.file.type == j.type) {
                i.file = j
              }
            })
          })
          // console.log(listImg)
          this.isUploadImg = true
          this.getOssSignatureDisposable(listImg, 'UPDATE', type, a)
        })
      } else {
        this.saveMockList([], 'UPDATE', [], type, a)
      }

    },
    // 拿签名上传图片
    getOssSignatureDisposable(listImg, operateType, type, a) {
      let _this = this
      InterfaceService.getOssSignatureDisposable('',{ type: '1', appName: "PROD" }, (data) => {
        _this.isLoading = false;
        const promiseList = [];
        let signature = data
        for (let pos = 0; pos < listImg.length; pos++) {
          let file = listImg[pos] && listImg[pos].file
          let place = listImg[pos] && listImg[pos].place
          if (file) {
            let dirType = new Date().getTime() + '/'
            const promise = new Promise(_resolve => {
              // 上传OSS
              _this.uploadHander(pos, file, dirType, signature, (pos, file, dirType, signature) => {
                //let u = signature.host+'/'+signature.dir+dirType+file.name
                // console.log(place)
                let u = signature.dir + dirType + file.name;
                _resolve({ 'ossPath': u, 'fileName': file.name, 'place': place });
              }, () => { this.isLoading = true; }, () => { this.isLoading = false; })
            });
            promiseList.push(promise);
          }
        }
        // 上传所有图片后回调
        Promise.all(promiseList).then(values => {
          _this.saveMockList(values, operateType, [], type, a)
        });
      }, (data) => {
        _this.isLoading = false;
      },
        () => {
          _this.isLoading = true;
        },
        () => {
          //_this.isLoading = false;
        });
    },
    uploadHander(pos, file, dirType, signature, callBack, loadingStartCb, loadingEndCb) {
      //去后端拿签名
      InterfaceService.uploadToOss(signature, file, dirType, pos, callBack, '', '', loadingStartCb, loadingEndCb)
    },
    // 采购商保存模拟清单
    saveMockList(imgList = [], operateType, list, type, a) {
      this.isUploadImg = false
      let mockProdList = []
      if (operateType == 'UPDATE') {
        mockProdList = this.$clone(this.mockProdList || []);
        mockProdList.sort((a, b) => {
          return a.step - b.step;
        });
        mockProdList.forEach((i, index) => {
          imgList.forEach(j => {
            if (index == j.place) {
              i.fileName = j.fileName
              i.ossPath = j.ossPath
              i.ossUrl = ''
            }
          });
          i.operateType = operateType //ADD:新增；UPDATE:编辑；DELETE:删除
          delete i.file
          delete i.place
        });
        console.log(mockProdList)
        this.saveMockList1(mockProdList, operateType, type, a)
      } else { // 删除
        this.$confirm(
          "是否确认删除该条商品全部内容？删除后，不能撤回。",
          "删除商品",
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            dangerouslyUseHTMLString: true,
            confirmButtonText: "确认删除",
            cancelButtonText: '取消',
          }).then(() => {
            this.saveMockList1(list, operateType)
          }).catch(() => {
            result = false
          });
      }
    },
    saveMockList1(mockProdList, operateType, type, a) {
      let param = {
        mockProdList: mockProdList,
      }
      InterfaceService.saveMockList(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          // this.mockProdList = data.respData.mockProdList || []
          this.$message.success(operateType == 'UPDATE' ? '保存成功' : '删除成功')
          // console.log(type)
          if (type == '1') {
            this.mockNo = a.mockNo;
            this.samplePicFlg = a.samplePicFlg;
          }
          this.getMockList()
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 上传图片
    pushImg(event, data) {
      let _this = this;
      let file = event.target.files[0]
      if (file) {
        let checkTextList = JSON.parse(sessionStorage.getItem('checkTextList') || '[]');
        let onOff = false;
        let forbidText = ''
        checkTextList.forEach(i=>{
          if (i != '' && file.name.indexOf(i) != -1) {
            onOff = true
            forbidText = i
          }
        });
        if (onOff) {
          this.$message.error('文件名包含特殊字符【'+forbidText+'】,请修改文件名后再上传')
          return false
        }
        // base64
        let reader = new FileReader();
        reader.onloadend = function () {
          data.ossUrl = reader.result
          data.file = file;
        }
        if (file) {
          reader.readAsDataURL(file);
        }
      }
      event.target.value = ''
    },
    // 删除图片
    clearImg(data) {
      data.ossPath = ''
      data.ossUrl = ''
      data.fileName = ''
      data.file = ''
    },
    close() {
      this.$refs['formcreateMockList'].resetFields();
    },
  },
}
</script>
<style lang="scss" scoped>
.order-info-title {
  margin-bottom: 32px !important;
}
/deep/ .textarea_box {
  .el-textarea__inner {
    padding: 10px;
    resize: none;
    height: 80px;
    font-size: 12px;
    overflow-x: hidden;
  }
}
/deep/ .prodCnt {
  .el-textarea__inner {
    height: 56px;
  }
}

.setMockList {
  width: 100%;
  .page {
    position: relative;
    .createMockList-small {
      position: absolute;
      right: 0;
      top: 0;
      width: 120px;
      height: 26px;
      background: linear-gradient(
        117deg,
        rgba(215, 176, 100, 1) 0%,
        rgba(236, 206, 139, 1) 100%
      );
      font-size: 12px;
      line-height: 26px;
      text-align: center;
      color: #fff;
    }
    .box1 {
      .createMockList {
        width: 260px;
        height: 50px;
        background: linear-gradient(
          122deg,
          rgba(215, 176, 100, 1) 0%,
          rgba(236, 206, 139, 1) 100%
        );
        font-size: 14px;
        line-height: 50px;
        text-align: center;
        font-weight: 600;
        color: #fff;
        margin: 100px auto 130px;
      }
      > img {
        width: 100%;
        margin-bottom: 80px;
      }
    }
    .box2 {
      .title_tab {
        width: 100%;
        display: flex;
        overflow: hidden;
        .tabs__nav-prev,
        .tabs__nav-next {
          width: 16px;
          height: 25px;
          margin: 1px 0;
          cursor: pointer;
          background: linear-gradient(
            180deg,
            rgba(215, 176, 100, 1) 0%,
            rgba(236, 206, 139, 1) 100%
          );
          text-align: center;
          line-height: 25px;
          > i {
            color: #fff;
          }
        }
        .tabs__nav {
          width: 100%;
          overflow-x: auto;
          overflow-y: hidden;
          > ul {
            white-space: nowrap;
            display: inline-block;
            > li {
              min-width: 80px;
              height: 26px;
              line-height: 26px;
              color: #c99f4f;
              font-size: 12px;
              text-align: center;
              padding: 0 18px;
              border: 1px solid #c99f4f;
              border-radius: 4px 4px 0px 0px;
              position: relative;
              display: inline-block;
              &:hover,
              &.active {
                background: linear-gradient(
                  123deg,
                  rgba(215, 176, 100, 1) 0%,
                  rgba(236, 206, 139, 1) 100%
                );
                border: none;
                color: #fff;
              }
              .title_tab,
              > i {
                position: absolute;
                right: 2px;
                top: 4px;
              }
              .mockProdList_title {
                height: 22px;
                width: 160px;
              }
            }
          }
          &.isShowScroll {
            width: calc(100% - 40px);
            margin: 0 4px -10px;
          }
        }
      }
      .table {
        table-layout: fixed;
        width: 100%;
        font-size: 12px;
        td {
          padding: 10px;
          vertical-align: middle;
          word-break: break-all;
          line-height: 17px;
          position: relative;
          // 图片上传
          .info-master-img {
            .img-item {
              position: relative;
              display: inline-block;
              width: 80px;
              height: 80px;
              vertical-align: middle;
              border: 1px dashed #ccc;
              border-radius: 2px;
              &:nth-child(8n) {
                margin-right: 0;
              }
            }

            .img-item-add {
              display: flex;
              // justify-content: center;
              flex-direction: column;
              align-items: center;
              height: 100%;
              font-size: 30px;
              text-align: center;
              color: #ccc;
              position: relative;
              overflow: hidden;
              // > label {

              // }
              i {
                cursor: pointer;
                &.cross-add {
                  width: 40px;
                  height: 40px;
                  display: inline-block;
                  position: relative;
                  margin: 10px 0 6px;
                  &::before {
                    content: "";
                    width: 100%;
                    height: 1px;
                    position: absolute;
                    left: 0;
                    top: 0;
                    bottom: 0;
                    margin: auto 0;
                    background-color: #ddd;
                  }
                  &::after {
                    content: "";
                    width: 1px;
                    height: 100%;
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    margin: 0 auto;
                    background-color: #ddd;
                  }
                }
              }

              input[type="file"] {
                display: none;
              }
              img {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                // max-height: 100%;
                pointer-events: none;
                height: auto;
              }
            }

            .img-item-cover {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              height: 100%;
              background: rgba(255, 255, 255, 0);
              margin-bottom: 10px;

              .img-item-bottom {
                display: none;
                position: absolute;
                width: 100%;
                text-align: center;
                background: rgba(255, 255, 255, 0.8);
                bottom: 0;
                padding: 0;
                line-height: 24px;
                height: 24px;

                a {
                  width: 50%;
                  float: left;
                  vertical-align: middle;
                  color: #0082ff;
                  font-size: 12px;
                  text-align: center;
                  > img {
                    justify-content: center;
                    align-items: center;
                    width: 6px;
                    height: 6px;
                  }
                }
              }
            }

            .img-item:hover {
              .img-item-cover {
                background: rgba(255, 255, 255, 0.2);
              }
              .img-item-bottom {
                display: block;
              }
            }

            img {
              width: 100%;
              height: 100%;
              border: none;
            }

            .img-item.has-img {
              &:hover .img-item-add {
                display: flex;
              }
            }
          }
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          // border-bottom: 1px solid #eee;
          background: #f9f9f9;
          color: rgba(136, 136, 136, 1);
          tr {
            border-left: 1px solid #eee;
            td {
              border-right: 1px solid #eee;
              padding: 5px 10px;
            }
          }
        }

        tbody {
          text-align: left;
          tr {
            border-left: 1px solid #eee;
            border-bottom: 1px solid #eee;
            td {
              border-right: 1px solid #eee;
            }
            // &:hover {
            //   background: #f0f8ff;
            // }
          }
        }
      }
      .addMockProduct {
        margin-top: 5px;
        width: 100%;
        height: 34px;
        background: rgba(245, 245, 245, 1);
        line-height: 34px;
        text-align: center;
        font-size: 14px;
        color: #0082ff;
      }
    }
  }
}
/deep/ .dialog-box {
  .samplePicFlg {
    .el-form-item__label {
      width: 162px !important;
      white-space: nowrap;
    }
    .el-form-item__content {
      margin-left: 162px !important;
    }
  }
  .el-dialog__body {
    padding-bottom: 0 !important;
  }
  .el-dialog__footer {
    padding: 20px;
  }
  .el-form-item--small.el-form-item {
    margin-bottom: 20px !important;
  }
  .drafts-list {
    .f12.tc {
      margin-bottom: 18px;
    }
  }
  .searchbox {
    text-align: center;
    margin-top: 20px;
    display: flex;
    justify-content: center;
    .searchBtn {
      width: 120px;
      height: 34px;
      line-height: 34px;
      background: linear-gradient(
        122deg,
        rgba(215, 176, 100, 1) 0%,
        rgba(236, 206, 139, 1) 100%
      );
      font-size: 12px;
      font-family: PingFang SC;
      color: rgba(255, 255, 255, 1);
      display: inline-block;
      cursor: pointer;
    }
    .clearBtn {
      width: 120px;
      margin-left: 20px;
      height: 34px;
      line-height: 32px;
      border: 1px solid rgba(201, 159, 79, 1);
      font-size: 12px;
      font-family: PingFang SC;
      color: rgba(201, 159, 79, 1);
      display: inline-block;
      cursor: pointer;
    }
  }
}
/deep/ .img-preview {
  .el-dialog__body {
    padding: 10px 20px 80px;
  }
  .img-box {
    max-height: 500px;
    overflow: hidden;
    overflow-y: scroll;
    text-align: center;
    img {
      max-width: 800px;
    }
  }
  .shut-down {
    width: 120px;
    height: 34px;
    line-height: 34px;
    padding: 0;
    font-size: 12px;
    text-align: center;
    color: #fff;
    background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
    margin: 0 auto;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 30px;
  }
}
</style>