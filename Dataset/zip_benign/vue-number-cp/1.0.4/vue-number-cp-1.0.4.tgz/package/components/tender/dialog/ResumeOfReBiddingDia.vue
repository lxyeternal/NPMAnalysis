<template>
  <div v-if="dialogVisible">
    <el-dialog class="dialog" :title="'回标履历'" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="840px" center :close-on-click-modal="false" @close="handleClear">
      <div class="table-cont">
        <table>
          <thead>
            <tr class="grey">
              <td width="48px">序号</td>
              <td>供应商</td>
              <td class="tr" width="105px">重新回标次数</td>
              <td class="tr" width="160px">操作</td>
            </tr>
          </thead>
          <tbody v-for="(item,index) in resumeList" :key="index">
            <tr class="tbody-row">
              <td>{{index+1}}</td>
              <td>{{item.supplierCorpName}}</td>
              <td class="tr">{{item.repeatTime}}</td>
              <td class="tr"><span class="hand blue" @click="handleDownload(item)">下载投标文件</span></td>
            </tr>
          </tbody>
        </table>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
export default {
  name: "ResumeOfReBiddingDia",
  data() {
    return {
      dialogVisible: false,
      isLoading: false,
      resumeList: []
    }
  },
  components: {
    Loading
  },
  methods: {
    open(resumeList) {
      this.dialogVisible = true;
      this.resumeList = resumeList || []
    },
    handleClear() {

    },
    handleDownload(item) {
      let fileInfoBeans = [];
      if (item.bidSupplierAttachInfos) {
        item.bidSupplierAttachInfos.forEach(item => {
          if (item.attachUrls) {
            item.attachUrls.forEach(url => {
              let name = url.split("?")[0];
              name = name.split("/").pop();
              fileInfoBeans.push({
                archivePath: item.directoryPath + '/' + decodeURIComponent(name),
                fileUrl: url,
              })
            })
          }
        });
      }
      console.log(fileInfoBeans);
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            // const files = [
            //   { name:item.supplierCorpName + "重新投标履历.zip", url: url }
            // ];
            // this.$download(files, () => {this.isLoading = true}, () => {this.isLoading = false}).then(() => {
            //   this.$message.success("已下载");
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: item.supplierCorpName + "重新投标履历.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    }
  }
}
</script>

<style scoped lang="scss">
.table-cont {
  width: 800px;
  max-height: 600px;
  overflow-y: auto;
}
table {
  table-layout: fixed;
  width: 100%;
  line-height: 17px;
  font-size: 12px;
  td {
    vertical-align: middle;
    word-break: break-all;
  }
  thead {
    td {
      padding: 6px 10px;
    }
    font-size: 14px;
    text-align: left;
    white-space: nowrap;
    background: #f9f9f9;
    border-bottom: 1px solid #eee;
  }
  .tbody-row {
    &:hover {
      background: #f0f8ff;
    }
  }
  tbody {
    td {
      padding: 14px 10px;
    }
    text-align: left;
    tr {
      border-bottom: 1px solid #eee;
    }
    .border-none {
      border-bottom: none;
    }
  }
}
</style>