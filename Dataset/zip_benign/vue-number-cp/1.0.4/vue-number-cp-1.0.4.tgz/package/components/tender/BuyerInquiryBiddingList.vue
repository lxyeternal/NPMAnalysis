<template>
  <div>
    <div class="tab-change">
      <ul>
        <li :class="{active:publishStatus == 'ANNOUNCED'}" @click="handleChangeLoginType('ANNOUNCED')">
          <span>未发送</span>
        </li>
        <li :class="{active:publishStatus == 'PUBLISH'}" @click="handleChangeLoginType('PUBLISH')">
          <span>已发送</span>
        </li>
      </ul>
    </div>
    <div class="search-container">
      <el-form class="form" size="small">
        <div style="display: inline-block;width: 35.5%;">
          <el-form-item label="询标主题：" label-width="80px">
            <el-input v-model="form.theme" placeholder="请输入关键词"></el-input>
          </el-form-item>
        </div>
        <div style="display: inline-block;width: 38.5%;">
          <el-form-item label="回复截止时间：" label-width="130px">
            <el-date-picker type="date" placeholder="选择日期" value-format="yyyy-MM-dd" v-model="form.deadLineFrom" style="width: 100%;" @change="handleChangeStartTm"></el-date-picker>~
            <el-date-picker :picker-options="pickerOptionsEnd" type="date" placeholder="选择日期" value-format="yyyy-MM-dd" v-model="form.deadLineTo" style="width: 100%;"></el-date-picker>
          </el-form-item>
        </div>
      </el-form>
      <el-row class="tc">
        <el-button type="primary" class="small-btn" @click="handleSearch">
          搜索
        </el-button>
        <el-button class="small-btn" @click="handleClear">
          清空
        </el-button>
      </el-row>
    </div>
    <div class="list-box">
      <div class="batch-select">
        <div class="fl" style="width: 70%;padding:0 10px;" v-if="publishStatus === 'ANNOUNCED'">
          <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow" :disabled="!inquireList.length">本页全选</el-checkbox>
          <el-button class="small-btn" :disabled="!hasChecked || !inquireList.length" @click="handleOperation('del','3')">批量删除</el-button>
          <el-button type="primary" class="small-btn" :disabled="!hasChecked || !inquireList.length" @click="handleOperation('send','1')">批量发送</el-button>
        </div>
        <div class="fr tr" style="width: 30%;">
          <el-button v-if="publishStatus === 'ANNOUNCED' && canCreateInquiry" class="small-btn" size="primary" :disabled="false" @click="createInquiryBidding('')">创建询标函</el-button>
          <el-button v-if="publishStatus === 'PUBLISH' && canCreateInquiry" class="small-btn" size="primary" :disabled="false" @click="outputInquiry">导出回复函(汇总)</el-button>
        </div>
        <div style="clear:both;"></div>
      </div>
      <div class="list-content">
        <table>
          <thead>
            <tr>
              <td width="34px">
                &nbsp;
              </td>
              <td width="48px">序号</td>
              <td width="495px">询标函主题</td>
              <td :style="{width:publishStatus == 'PUBLISH' ? '270px' : '390px'}">发送对象</td>
              <td width="120px" v-if="publishStatus == 'PUBLISH'">回复情况</td>
              <td width="112px">回复截止时间</td>
              <td width="110px" class="tr">操作</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in inquireList" :key="ind" class="tbody-row">
            <tr>
              <td>
                <el-checkbox v-if="publishStatus === 'ANNOUNCED'" v-model="item.checked" @change="handleSelectTableRow(item,ind)"></el-checkbox>
              </td>
              <td>{{pageSize * (pageIndex-1)  + ind + 1}}</td>
              <td>
                <span style="display: inline-block;width: 339px;">{{item.theme}}</span>
              </td>
              <td>
                <p class="supplier-list" :title="item.supplierNameList.join('；')">{{item.supplierNameList.join('；')}}</p>
              </td>
              <td v-if="publishStatus == 'PUBLISH'">
                {{item.answerStatus}}
              </td>
              <td>
                <span style="display: inline-block;width: 68px;">
                  {{item.deadLine && item.deadLine.substring(0,10)}}
                </span>
              </td>
              <td class="tr">
                <template v-if="publishStatus === 'ANNOUNCED'">
                  <p v-if="canCreateInquiry"><span class="hand blue" @click="createInquiryBidding(item.bidInquireNo)">编辑</span></p>
                  <p v-if="canCreateInquiry"><span class="hand blue" @click="openSendDialog(item)">发送</span></p>
                  <p><span class="hand blue" @click="handleOperation('del','3',item.bidInquireNo)">删除</span></p>
                </template>
                <template v-else>
                  <p><span class="hand blue" @click="handleOpenInquiryBid(item)">查看回复函</span></p>
                  <p><span class="hand blue" @click="handleDownloadRespFiles(item)">下载回复附件</span></p>
                </template>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div class="table-pagination" v-if="inquireList.length">
        <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
        </el-pagination>
      </div>
      <div class="accout-empty" v-if="!inquireList.length&&!isLoading">
        <img src="@/assets/images/icon-no-product.png">
        <p>没有相关的询标函，请重新修改搜索条件搜索！</p>
      </div>
    </div>
    <el-dialog title="发送询标函" :visible.sync="sendDialogVisible" width="840px" class="addUser" :close-on-click-modal="false">
      <div class="tc" v-html="sendMsg">
      </div>
      <div class="dialog__footer tc">
        <el-button class="normal-btn" type="primary" @click="handleOperation('send','1',selectedBidInfo.bidInquireNo)">确认发送</el-button>
        <el-button class="normal-btn" type="primary" @click="createInquiryBidding(selectedBidInfo.bidInquireNo)">编辑</el-button>
        <el-button class="normal-btn" @click="sendDialogVisible = false">取消</el-button>
      </div>
    </el-dialog>
    <el-dialog class="dialog dialog-drafts" :title="'导出回复函'" :append-to-body="true" :lock-scroll="true" :visible.sync="outputInquiryDialog" width="840px" center :close-on-click-modal="false" @close="handleCancel">
      <div class="tc">
        <label>分类</label>
        <el-radio-group v-model="requestClassify">
          <el-radio label="2">全部</el-radio>
          <el-radio label="TECHNICALBID">技术标</el-radio>
          <el-radio label="COMMERCIALBID">商务标</el-radio>
        </el-radio-group>
      </div>
      <div slot="footer" class="tc" style="margin-top: 0">
        <el-button class="normal-btn" type="primary" @click="handleDownloadSummary">确认导出</el-button>
        <el-button class="normal-btn" @click="handleCancel">取消</el-button>
        <div class="searchBtn" @click="auditCompanyInfo('2')"></div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { DateUtil } from '@/utils/dateUtil';
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import {
  mapActions,
  mapState
} from 'vuex'
const form = {
  deadLineFrom: "",
  deadLineTo: "",
  theme: "",
}
export default {
  name: "BuyerInquiryBiddingList",
  props: ["endTenderTm", "canCreateInquiry", "isSupplyPicture"],
  data() {
    return {
      inventoryFlag: '',
      mockFlag: '',
      publishStatus: "ANNOUNCED",
      sendMsg: "",
      requestClassify: "2",
      bidName: "",
      bidNo: "",
      allChecked: false,
      isLoading: false,
      hasChecked: false,
      outputInquiryDialog: false,
      sendDialogVisible: false,
      inquireList: [],
      selectedBidInfo: {},
      pageIndex: 1,
      pageSize: 0,
      totalCount: 0,
      pickerOptionsEnd: {
        disabledDate: time => {
          if (this.form.deadLineFrom) {
            return time.getTime() <= new Date(this.form.deadLineFrom).getTime() - 86400000
          }
        }
      },
      form: Object.assign({}, form)
    }
  },
  components: {
    Loading
  },
  methods: {
    handleDownloadSummary() {
      let params = {
        bidNo: this.bidNo,
        requestClassify: this.requestClassify == "2" ? "" : this.requestClassify,
      }
      InterfaceService.getInquiryResponseSummary(
        params
        , data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let url = data.respData.loadUrl || ""
            if (url) {
              let str = "";
              if (this.requestClassify == "COMMERCIALBID") {
                str = "（商务标）"
              } else if (this.requestClassify == "TECHNICALBID") {
                str = "（技术标）"
              }
              const files = [
                { name: this.bidName + "询标函汇总表" + str, url: url }
              ];
              this.$download(files).then(() => {
                this.$message.success("导出成功");
                this.outputInquiryDialog = false;
                this.requestClassify = "2"
              });
            } else {
              this.$message.success("暂无下载地址")
            }
          } else {
            this.$message.error(data.respData.respMsg)
          }
        },
        data => {
          this.$message.error(data.respData.respMsg)
        },
        () => { this.isLoading = true },
        () => { this.isLoading = false })
    },
    handleCancel() {
      this.outputInquiryDialog = false;
      this.requestClassify = "2"
    },
    // 分页跳转
    handleCurrentChange(page) {
      this.pageIndex = page;
      window.scrollTo(0, 0)
      this.getInquiryBiddingList();
    },
    handleChangeLoginType(type) {
      this.publishStatus = type;
      this.pageIndex = 1;
      this.getInquiryBiddingList()
    },
    handleSearch() {
      this.pageIndex = 1;
      this.getInquiryBiddingList()
    },
    handleClear() {
      this.form = Object.assign({}, form)
      this.handleSearch()
    },
    handleSend() {
      this.$message.info("暂未开发")
      return false
    },
    outputInquiry() {
      this.outputInquiryDialog = true;
    },
    //下载回复附件
    handleDownloadRespFiles(item) {
      let fileInfoBeans = [];
      if (item.bidSupplierAttachInfos && item.bidSupplierAttachInfos.length) {
        item.bidSupplierAttachInfos.forEach(_item => {
          if (_item.attachUrls && _item.attachUrls.length) {
            _item.attachUrls.forEach(url => {
              let name = url.split("?")[0];
              name = name.split("/").pop();
              fileInfoBeans.push({
                archivePath: _item.supplierCorpName + "/" + decodeURIComponent(name),
                fileUrl: url,
              })
            })
          }
        })
      }
      if (!fileInfoBeans.length) {
        this.$message.error("暂无回复附件！")
        return false
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            // const files = [
            //   { name:this.bidName + item.theme + "附件.zip", url: url }
            // ];
            // this.$download(files, () => {this.isLoading = true}, () => {this.isLoading = false}).then(() => {
            //   this.$message.success("已下载");
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name:this.bidName + item.theme + "附件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    handleOpenInquiryBid(item) {
      let inquiryInfo = {
        theme: item.theme,
        supplierNameList: item.supplierNameList,
        deadLine: item.deadLine && item.deadLine.substring(0, 10),
      };
      const { href } = this.$router.resolve({
        path: "/inquiryBiddingDetail",
        query: {
          bidInquireNo: item.bidInquireNo,
          bidNo: this.bidNo,
          bidName: this.bidName,
          isSupplyPicture: this.isSupplyPicture,
          inquiryInfo: JSON.stringify(inquiryInfo),
        },
      });
      window.open(href, '_blank');
    },
    createInquiryBidding(bidInquireNo) {
      const { href } = this.$router.resolve({
        path: "/createInquiryBidding",
        query: {
          bidNo: this.bidNo,
          bidName: this.bidName,
          bidInquireNo: bidInquireNo || "",
          endTenderTm: this.endTenderTm || "",
          inventoryFlag: this.inventoryFlag || "",
          mockFlag: this.mockFlag || "",
        },
      });
      this.sendDialogVisible = false
      window.open(href, '_blank');
    },
    openSendDialog(item) {
      let closeTime = false
      let deadline = new Date(item.deadLine && item.deadLine.substring(0, 10)).getTime();
      let now = new Date(DateUtil.getTimesStr()).getTime();
      let threeDay = 24 * 60 * 60 * 1000 * 3;
      console.log(deadline);
      console.log(now);
      console.log(deadline - now < threeDay);
      closeTime = deadline - now < threeDay;
      this.selectedBidInfo = item
      if (!closeTime) {
        this.sendMsg = "请确认信息填写是否完善，若无误，点击【发送】按钮即可"
      } else {
        this.sendMsg = "<span class='red'>你设置的供应商回复截止时间很接近，请确认供应商回复时间！</span>若内容无误，点击【发送】按钮即可"
      }
      this.sendDialogVisible = true
    },
    handleOperation(type, handleType, bidInquireNo) {
      let str = '', title = '', btn = '', bidInquireNos = [];
      if (!bidInquireNo) {
        let num = 0;
        this.inquireList.forEach(item => {
          if (item.checked) {
            num++
            bidInquireNos.push(item.bidInquireNo)
          }
        });
        if (type == 'del') {
          str = "请确认是否删除勾选的" + num + "条询标函，删除后不能撤回";
          btn = "确认删除";
          title = "批量删除询标函"
        } else {
          str = "请确认" + num + "份询标函信息填写是否完善，若无误，点击【发送】按钮即可";
          btn = "确认发送";
          title = "批量发送询标函"
        }
      } else {
        bidInquireNos.push(bidInquireNo)
        if (type == 'del') {
          str = "请确认是否删除该询标函，删除后不能撤回";
          btn = "删除询标函";
          title = "确认删除"
        }
      }
      if (!bidInquireNo || type == 'del') {
        this.$confirm(
          str,
          title,
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            dangerouslyUseHTMLString: true,
            confirmButtonText: btn,
            cancelButtonText: '取消',
          }).then(() => {
            this.confirmSubmit(bidInquireNos, handleType, btn)
          }).catch(() => {
          });
      } else {
        this.confirmSubmit(bidInquireNos, handleType)
      }
    },
    confirmSubmit(bidInquireNos, handleType, btn) {
      InterfaceService.inquiryBiddingOperation({
        bidInquireNos,
        bidNo: this.bidNo,
        handleType: handleType
      }, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.sendDialogVisible = false
          this.$message.success(btn ? btn + "成功！" : '发送成功！')
          if (handleType == '1') {
            this.publishStatus = "PUBLISH"
          }
          this.pageIndex = 1;
          this.getInquiryBiddingList()
        } else {
        }
      },
        data => {
          this.$message.error(data.respData.respMsg)
        },
        () => { this.isLoading = true },
        () => { this.isLoading = false })
    },
    handleChangeStartTm(ev) {
      if (new Date(ev) > new Date(this.form.deadLineTo)) {
        this.form.deadLineTo = ""
      }
    },
    // 全选
    handleAllSelectTableRow(bool) {
      let arr = [];
      arr = [].concat(this.inquireList);
      arr.forEach(item => {
        item.checked = bool;
      });
      this.inquireList = arr;
      this.checkBatch();
    },
    // 选中行
    handleSelectTableRow(item, index) {
      this.$set(this.inquireList, index, item);
      this.checkBatch();
      this.checkAllSelect();
    },
    // 是否全选
    checkAllSelect() {
      this.allChecked = this.inquireList.every(item => {
        return item.checked;
      });
    },
    // 是否可批量
    checkBatch() {
      this.hasChecked = this.inquireList.some(item => {
        return item.checked;
      });
    },
    getInquiryBiddingList() {
      let params = Object.assign({}, this.form);
      params.pageIndex = this.pageIndex;
      params.publishStatus = this.publishStatus;
      params.bidNo = this.bidNo;
      InterfaceService.getInquiryBiddingList(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.inquireList = data.respData.bidInquiryListBeans || [];
          this.inventoryFlag = data.respData.inventoryFlag || '';
          this.mockFlag = data.respData.mockFlag || '';
          this.inquireList.forEach(item => {
            item.supplierNameList = [];
            if (item.ibSupplierBidInquiryInfos && item.ibSupplierBidInquiryInfos.length) {
              item.ibSupplierBidInquiryInfos.forEach(_item => {
                item.supplierNameList.push(_item.supplierCorpName)
              })
            }
            item.checked = false;
          });
          this.allChecked = false;
          this.checkBatch()
          this.pageSize = data.respData.pageSize || 0;
          this.total = data.respData.totalCount || 0;
        } else {
        }
      },
        data => { },
        () => { this.isLoading = true },
        () => { this.isLoading = false })
    },
    init() {
      let status = this.$getRootLocalStorage('createInquiryBidding') || "";
      this.publishStatus = status || this.$route.query.publishStatus || "ANNOUNCED";
      this.getInquiryBiddingList();
      this.$removeRootLocalStorage('createInquiryBidding')
    }
  },
  mounted() {
    this.bidNo = this.$route.query.bidNo || "";
    this.bidName = this.$route.query.bidName || "";
    if(this.$parent){
      this.$parent.breadcrumb.push({ name: '询标' })
    }
    this.init()
  }
}
</script>

<style scoped lang="scss">
.tab-change {
  height: 40px;
  background: #f5f5f5;
  padding: 10px 20px;
  /*letter-spacing: 6px;*/
  font-size: 16px;
  margin-bottom: 15px;
  text-align: center;
  position: relative;
  color: #fff;
  & > ul {
    & > li {
      float: left;
      font-size: 14px;
      color: #313131;
      margin-right: 44px;
      text-align: center;
      cursor: pointer;
      position: relative;
      transition: all 0.3s linear;
      span {
        font-weight: 600;
      }
      &:hover,
      &.active {
        &::after {
          width: 40px;
        }
      }
      &::after {
        content: "";
        width: 0;
        height: 2px;
        border-radius: 2px;
        background: #c99f4f;
        position: absolute;
        bottom: -6px;
        left: 50%;
        transform: translate(-50%, 0);
        transition: all 0.3s linear;
      }
    }
  }
}
.search-container {
  margin-top: 10px;
  margin-bottom: 20px;
  padding: 20px 10px;
  background: #f9f9f9;
  .form {
    /deep/ .el-input {
      width: 300px;
    }
    /deep/ .el-date-editor {
      width: 140px !important;
      margin-right: 6px;
    }
  }
}
.list-box {
  margin-top: 20px;
  /deep/ .batch-select {
    margin-bottom: 12px;
    .el-button {
      margin-left: 10px;
    }
    .el-checkbox__label {
      padding-left: 4px;
    }
  }
  .list-content {
    width: 1190px;
    margin: 0 auto;
    table {
      table-layout: fixed;
      width: 100%;
      line-height: 17px;
      font-size: 12px;
      td {
        padding: 20px 10px;
        vertical-align: middle;
        word-break: break-all;
      }

      thead {
        font-size: 14px;
        text-align: left;
        background: #f9f9f9;
        white-space: nowrap;
        border-bottom: 1px solid #eee;
      }
      .tbody-row {
        &:hover {
          background: #f0f8ff;
        }
      }
      tbody {
        text-align: left;
        tr {
          border-bottom: 1px solid #eee;
        }
        .border-none {
          border-bottom: none;
        }
      }
      .supplier-list {
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
      }
    }
  }
}
/deep/ .dialog__footer {
  padding-top: 20px;
}
/deep/ .el-dialog {
  display: flex;
  flex-direction: column;
  margin: 0 !important;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  /*height:600px;*/
  max-height: calc(100% - 30px);
  max-width: calc(100% - 30px);
  .el-dialog__header {
    font-size: 18px;
  }
  .el-dialog__body {
    flex: 1;
    padding: 20px;
    font-size: 14px;
    flex-basis: auto;
  }
}
</style>