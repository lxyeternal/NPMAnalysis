<template>
  <div class="countdown-content">
    <h4 class="f16">开标倒计时</h4>
    <p><span v-if="day > 0">{{day}}天</span>{{hr}}:{{min}}:{{sec}}</p>
  </div>
</template>

<script>
  import { DateUtil } from '@/utils/dateUtil';

  export default {
    name: "TenderCountDown",
    data() {
      return {
        hr: 0,
        min: 0,
        day: 0,
        timer: null,
        sec: 0
      }
    },
    props:["openTenderTm"],
    mounted: function () {
      this.countdown()
    },
    methods: {
      countdown: function () {
        // 定义结束时间戳 ,Date.parse兼容IE
        const end = new Date(Date.parse(new Date(this.openTenderTm.replace(/-/g,"/"))))
        // 定义当前时间戳
        const now = new Date(Date.parse(new Date(DateUtil.dateToString().replace(/-/g,"/"))))
        // 做判断当倒计时结束时都为0
        if (now >= end) {
          this.day = "0"
          this.hr = "00";
          this.min = "00";
          this.sec = "00";
          this.$emit('over');
          clearInterval(this.timer)
          return
        }
        // 用结束时间减去当前时间获得倒计时时间戳
        const msec = end - now
        let day = parseInt(msec / 1000 / 60 / 60 / 24) //算出天数
        let hr = parseInt(msec / 1000 / 60 / 60 % 24)//算出小时数
        let min = parseInt(msec / 1000 / 60 % 60)//算出分钟数
        let sec = parseInt(msec / 1000 % 60)//算出秒数
        //给数据赋值
        this.day = day
        this.hr = hr > 9 ? hr : '0' + hr
        this.min = min > 9 ? min : '0' + min
        this.sec = sec > 9 ? sec : '0' + sec
        //定义this指向
        // 使用定时器 然后使用递归 让每一次函数能调用自己达到倒计时效果
        this.timer = setTimeout(()=> {
          this.countdown()
        }, 1000)
      },
      delimiterConvert(val){  //格式化数据
        return val.replace('-','/').replace('-','/')
      }
    },
    destroyed() {
      clearInterval(this.timer)
    }
  }
</script>

<style scoped lang="scss">
.countdown-content{
  margin-top: 20px;
  height: 150px;
  width: 100%;
  border: 1px solid #E93340;
  /*background: linear-gradient(180deg,rgba(24,16,22,1) 0%,rgba(90,88,88,1) 100%);*/
  background: #fff;
  color: #E93340;
  font-size: 16px;
  text-align: center;
  h4{
    padding-top: 30px;
    line-height: 22px;
  }
  p{
    padding-top: 10px;
    line-height: 56px;
    font-size:40px;
    height:56px;
    font-weight: 600;
  }
}
</style>