<template>
  <div class="targetList">
    <div class="list-home">
      <!-- 审批状态 -->
      <div class="box_type" v-if="Object.keys(ibOaConfirmBean).length">
        <p>状态：{{ibOaConfirmBean.approveStatus}}</p>
        <div class="annex">
          <div class="left grey">OA流程编号：</div>
          <div class="right">{{ibOaConfirmBean.approveId}}</div>
        </div>
        <div class="annex">
          <div class="left grey">OA审批凭证：</div>
          <div class="right">
            <p v-for="(a,ind) in ibOaConfirmBean.approveAttachInfos" :key="ind+'p'">
              {{a.attachName}}
              <span class="hand blue" @click="handleView(a.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(a.attachName,a.attachUrl)">下载</span>
            </p>
          </div>
        </div>
      </div>
      <div class="list-content">
        <div class="panel">
          <el-form class="form" size="small" label-width="70px" type="flex" justify="space-between">
            <el-row>
              <el-col :span="9">
                <el-form-item label="供应商：">
                  <el-input style="width: 300px !important" v-model.trim="supplierCorpName" placeholder="请输入关键词" maxlength="64" clearable></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="9">
                <el-form-item label="重新回传时间：" class="time_label">
                  <el-row>
                    <el-col :span="10">
                      <el-date-picker value-format="yyyy-MM-dd" v-model="confirmBidForm" size="" type="date" placeholder="选择时间" @change="handleChangeStartTm">
                      </el-date-picker>
                    </el-col>
                    <el-col :span="2" class="tc">-</el-col>
                    <el-col :span="10">
                      <el-date-picker value-format="yyyy-MM-dd" v-model="confirmBidTo" size="" type="date" placeholder="选择时间" :picker-options="pickerOptionsEnd">
                      </el-date-picker>
                    </el-col>
                  </el-row>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="9">
                <el-form-item label="中标情况：" class="business">
                  <el-radio-group v-model="confirmBidFlag" @change="search()">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'0'">未中标</el-radio>
                    <el-radio :label="'1'">{{!Object.keys(ibOaConfirmBean).length?'拟中标':'已中标'}}</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
              <el-col :span="15">
                <el-form-item label="供应商回传中标附件情况：" class="mark">
                  <el-radio-group v-model="uploadConfirmattachFlag" @change="search()">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'0'">未回传</el-radio>
                    <el-radio :label="'1'">已回传</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24" class="form-btns" align="center">
                <el-button class="btn" type="primary" size="small" @click="search()">搜索</el-button>
                <el-button class="btn" size="small" @click="clear()">清除</el-button>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <el-row class="button-panel">
          <el-col :span="12">
            <el-checkbox v-model="checkboxAll" :disabled="!targetList.length || (Object.keys(ibOaConfirmBean).length != 0 && ibBidEnterInfo.publishStatus != 'PUBLISH')" style="margin: 0 10px" @change="checkboxChange">全选</el-checkbox>
            <el-button v-if="ibBidEnterInfo.publishStatus != 'PUBLISH'" class="btn w140" :class="{'isDisabled':!(targetList.some(i => i.checkbox === true))}" :disabled="!(targetList.some(i => i.checkbox === true))" size="small" @click="batchShortlisted('1')">批量设置拟中标单位</el-button>
            <el-button v-if="ibBidEnterInfo.publishStatus != 'PUBLISH'" class="btn w140" :class="{'isDisabled':!(targetList.some(i => i.checkbox === true))}" :disabled="!(targetList.some(i => i.checkbox === true))" size="small" @click="batchShortlisted('0')">批量取消拟中标单位</el-button>
            <el-button v-if="ibBidEnterInfo.publishStatus == 'PUBLISH'" class="btn w140" :class="{'isDisabled':!(targetList.some(i => i.checkbox === true))}" :disabled="!(targetList.some(i => i.checkbox === true))" size="small" @click="batchDownload()">批量下载中标附件</el-button>
          </el-col>
          <el-col :span="12">
            <el-button v-if="!Object.keys(ibOaConfirmBean).length" class="btn w120" type="primary" size="small" @click="$refs.sentBidApprove.open(bidNo)">提交中标审批</el-button>
            <el-button v-if="Object.keys(ibOaConfirmBean).length && !Object.keys(ibBidEnterInfo).length" class="btn w120" type="primary" size="small" @click="openNewPage('0')">创建中标公示</el-button>
            <el-button v-if="Object.keys(ibBidEnterInfo).length && ibBidEnterInfo.publishStatus != 'PUBLISH'" class="btn w120" type="primary" size="small" @click="openNewPage('1')">编辑中标公示</el-button>
            <el-button v-if="ibBidEnterInfo.publishStatus == 'PUBLISH'" class="btn w120" size="small" @click="openNewPage('2')">查看中标公示</el-button>
          </el-col>
        </el-row>
        <table>
          <thead>
            <tr>
              <td width="40px"></td>
              <td width="68px">序号</td>
              <td width="120px">中标情况</td>
              <td width="360px">供应商名称</td>
              <td width="210px">供应商回传中标附件</td>
              <td>最新回传时间</td>
              <td width="110px">操作</td>
            </tr>
          </thead>
          <tbody v-for="(a,ind) in targetList" :key="ind" class="tbody-row">
            <tr>
              <td>
                <el-checkbox v-model="a.checkbox" @change="checkboxChangeOne" :disabled="checkboxDisabled(a)"></el-checkbox>
              </td>
              <td>
                {{ind+1}}
              </td>
              <td :class="{'red':a.confirmBidFlag!='0'}">
                {{a.confirmBidFlag=='0'?'未中标':(!Object.keys(ibOaConfirmBean).length?'拟中标':'已中标')}}
              </td>
              <td>
                <p> {{a.supplierCorpName}}</p>
                <TagSourceList :corpTagList="a.corpTagList" @getData="buyersResponseTenderList"></TagSourceList>
                <div class="tag" v-if="a.keyMarkFlg == '1'">标记通过</div>
              </td>
              <td>
                {{a.uploadConfirmattachFlag=='0'?'':'√'}}
              </td>
              <td>
                {{a.uploadConfirmattachTime && a.uploadConfirmattachTime.substring(0,19)}}
              </td>
              <td>
                <p class="hand blue" v-if="a.confirmBidFlag == '0' && !Object.keys(ibOaConfirmBean).length" @click="buyersSetBidUnit([a.submitBidNo],'1')">设定拟中标单位</p>
                <p class="hand blue" v-if="a.confirmBidFlag == '1' && !Object.keys(ibOaConfirmBean).length" @click="buyersSetBidUnit([a.submitBidNo],'0')">取消拟中标单位</p>
                <p class="hand blue" v-if="ibBidEnterInfo.publishStatus == 'PUBLISH' && a.uploadConfirmattachFlag=='1'" @click="packageDownload([a])">下载附件</p>
              </td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!targetList.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
        </div>
        <div class="table-pagination" v-if="targetList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>

    <SentBidApprove ref="sentBidApprove" @getData="buyersResponseTenderList"></SentBidApprove>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
// import Breadcrumb from "@/components/base/Breadcrumb";
import { viewFile } from '@/utils/orderUtil';
import SentBidApprove from "@/components/tender/sentBidApprove";
import TagSourceList from "@/components/tender/Prequalifica/tagSourceList";
export default {
  components: {
    Loading,
    // Breadcrumb,
    SentBidApprove,
    TagSourceList
  },
  data() {
    return {
      isLoading: false,

      checkboxAll: false, // 全选
      isDisabled: true,

      supplierCorpName: '',
      confirmBidForm: '',
      confirmBidTo: '',
      uploadConfirmattachFlag: '',
      confirmBidFlag: '',

      total: 0, //分页 总页数
      pageSize: 20, //分页 每页的长度
      pageIndex: 1, //当前页码

      ibBidEnterInfo: {},//中标公示信息
      targetList: [], //中标列表

      bidNo: '',//	招标编号	
      bidName: '',
      ibOaConfirmBean: {}, // 

      pickerOptionsEnd: {
        disabledDate: time => {
          if (this.confirmBidForm) {
            return time.getTime() <= new Date(this.confirmBidForm).getTime()
          }
        }
      },
    };
  },
  methods: {
    checkboxDisabled(a) {
      if (Object.keys(this.ibOaConfirmBean).length != 0) {
        if (this.ibBidEnterInfo.publishStatus != 'PUBLISH') {
          return true
        } else if (this.ibBidEnterInfo.publishStatus == 'PUBLISH' && a.uploadConfirmattachFlag != '1') {
          return true
        } else {
          return false
        }
      } else {
        return false
      }
    },
    openNewPage(type) {
      this.$setRootScope('dataInfo', JSON.stringify(this.buyersTenderInfo))
      if (type == '2') {
        window.open(this.$router.resolve({
          path: "/bidBulletinDetail",
          query: {
            type: '1',
            enterBidNo: this.ibBidEnterInfo.enterBidNo || ''
          }
        }).href, '_blank')
        return
      }
      window.open(this.$router.resolve({
        path: "/cresteBidBulletin",
        query: {
          type: type || '0',
          enterBidNo: this.ibBidEnterInfo.enterBidNo || ''
        }
      }).href, '_blank')
    },
    // 全选
    checkboxChange() {
      this.targetList.forEach(i => {
        if (this.ibBidEnterInfo.publishStatus == 'PUBLISH') {
          if (i.uploadConfirmattachFlag == '1') {
            this.$set(i, 'checkbox', this.checkboxAll)
          }
        } else {
          this.$set(i, 'checkbox', this.checkboxAll)
        }
        if (!this.targetList.some(i => i.checkbox == true)) {
          this.checkboxAll = false
        }
      });
    },
    // 单选
    checkboxChangeOne() {
      const a = this.targetList.filter(i => i.checkbox == true)
      if (a.length == 0) {
        this.checkboxAll = false
      } else {
        if (a.length != this.targetList.length) {
          this.checkboxAll = false
        } else {
          this.checkboxAll = true
        }
      }
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      window.scrollTo(0, 0)
      this.buyersResponseTenderList()
    },
    // 起始时间
    handleChangeStartTm(ev) {
      if (new Date(ev) > new Date(this.confirmBidTo)) {
        this.confirmBidTo = ""
      }
    },
    search() {
      this.pageIndex = 1
      this.buyersResponseTenderList()
    },
    clear() {
      this.pageIndex = 1
      this.supplierCorpName = ''//	供应商名称				
      this.confirmBidForm = ''
      this.confirmBidTo = ''
      this.uploadConfirmattachFlag = ''
      this.confirmBidFlag = ''
      this.buyersResponseTenderList()
    },
    // 定标列表
    buyersResponseTenderList() {
      let param = {
        bidNo: this.bidNo,
        supplierCorpName: this.supplierCorpName,
        submitBidTmFrom: '',
        submitBidTmTo: '',
        submitBidFlg: '1',
        bidAttachDownloadFlg: '',
        keyMarkFlg: '',

        isConfirmPage: '1',
        confirmBidForm: this.confirmBidForm || '',
        confirmBidTo: this.confirmBidTo || '',
        uploadConfirmattachFlag: this.uploadConfirmattachFlag || '',
        confirmBidFlag: this.confirmBidFlag || '',

        pageIndex: this.pageIndex,
      };
      InterfaceService.buyersResponseTenderList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.ibOaConfirmBean = data.respData.ibOaConfirmBean || {}
          this.ibBidEnterInfo = data.respData.ibBidEnterInfo || {}

          this.targetList = data.respData.submitBidList || []
          if (this.targetList.length != 0) {
            this.targetList.forEach(i => {
              this.$set(i, 'checkbox', false)
              if (i.corpTagList) {
                i.corpTagList.forEach(j => {
                  this.$set(j, 'showRemark', false)
                  this.$set(j, 'disabled', true)
                  this.$set(j, 'showOperat', false)
                });
              }
            });
          }
          this.total = Number(data.respData.totalCount)
          this.pageSize = Number(data.respData.pageSize)
          this.checkboxAll = false
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 批量标记或取消拟中标单位
    batchShortlisted(handleType) {
      const a = this.targetList.filter(i => i.checkbox == true)
      if (a.length == 0) {
        return this.$message('请勾选')

      }
      if (handleType == '0') {
        const b = a.some(i => i.confirmBidFlag == '0')
        if (b) {
          return this.$message('您勾选的中标单位包含未中标的，请重新勾选')
        }
      } else {
        const c = a.some(i => i.confirmBidFlag == '1')
        if (c) {
          return this.$message('您勾选的中标单位包含拟中标的，请重新勾选')
        }
      }
      let list = []
      a.forEach(i => {
        list.push(i.submitBidNo)
      });
      this.buyersSetBidUnit(list, handleType)
    },
    //标记或取消拟中标单位
    buyersSetBidUnit(list, handleType) { // 1、预拟中标，0、取消中标
      let param = {
        bidNo: this.bidNo,
        submitBidNos: list,
        handleType: handleType,
      };
      InterfaceService.buyersSetBidUnit(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message({ message: (handleType == '0' ? '取消拟中标单位' : '设定拟中标单位') + '成功', type: 'success' });
          this.checkboxAll = false;
          this.buyersResponseTenderList()
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 文件下载
    handleDownTemp(name, url) {
      console.log(name, url)
      this.$download([{
        name: name,
        url: url
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 在线预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    // 批量下载中标附件
    batchDownload() {
      const a = this.targetList.filter(i => i.checkbox == true)
      if (a.length == 0) {
        this.$message('请勾选')
        return
      }
      this.packageDownload(a)
      // let result = false
      // for (let i = 0; i < a.length; i++) {
      //   result = true
      //   if (!a[i].resourceFile) {
      //     this.$message(a[i].supplierCorpName + '暂无下载中标附件地址')
      //     result = false
      //     break
      //   }
      // }
      // if (result) {
      //   this.packageDownload(a)
      // }
    },
    // 打包下载
    packageDownload(list) {
      let fileInfoBeans = []
      list.forEach(i => {
        if (!!i.submitConfirmAttachs) {
          let fileList = []
          i.submitConfirmAttachs.forEach((item, index) => {
            let name = ''
            if (item.attachType == '40') {
              name = '其他附件'
            } else if (item.attachType == '42') {
              name = '战略合作协议'
            } else if (item.attachType == '43') {
              name = '采购合同通用条款'
            } else if (item.attachType == '58' || item.attachType == '59' || item.attachType == '60') {
              name = '中标文件'
            }
            if (name) {
              fileList.push({
                archivePath: i.supplierCorpName + '/' + name + '/' + item.attachName,
                fileUrl: item.attachUrl,
              })
            } else {
              fileList.push({
                archivePath: i.supplierCorpName + '/' + item.attachName,
                fileUrl: item.attachUrl,
              })
            }
          })
          fileInfoBeans = fileInfoBeans.concat(fileList)
        }
      });
      if (!fileInfoBeans.length) {
        this.$message.error('暂无附件可供下载')
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            // const files = [
            //   { name: this.bidName + "中标附件.zip", url: url }
            // ];
            // this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
            //   this.$message.success("已下载");
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: this.bidName + "中标附件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    init() {
      if(this.$parent){
        this.$parent.breadcrumb.push({ name: '定标' })
      }
      this.buyersResponseTenderList()
    },
  },
  mounted() {
    this.init()
  },
  created() {
    this.bidNo = this.$route.query.bidNo || ''
    this.bidName = this.$route.query.bidName || ''
  },
  watch: {
    buyersTenderInfo(val) {
      this.buyersTenderInfo = val
    }
  },
  props: ['active', 'buyersTenderInfo'],
};
</script>

<style lang="scss" scoped>
/deep/ .el-input {
  width: initial !important;
}
/deep/ .business {
  .el-form-item__label {
    width: 84px !important;
  }
  .el-form-item__content {
    margin-left: 84px !important;
  }
}
/deep/ .mark {
  .el-form-item__label {
    width: 190px !important;
  }
  .el-form-item__content {
    margin-left: 190px !important;
  }
}
/deep/ .time_label {
  .el-form-item__label {
    width: 120px !important;
  }
  .el-form-item__content {
    margin-left: 120px !important;
  }
}
.w120 {
  width: 120px !important;
}
.w140 {
  width: 140px !important;
}
.targetList {
  padding-bottom: 60px;
  .list-home {
    width: 1190px;
    margin: 0 auto;
    .box_steps {
      padding: 20px 0 30px;
      box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
    }
    .list-content {
      .panel {
        background: rgba(249, 249, 249, 1);
        padding: 20px 10px 20px 0px;
        margin: 10px 0px 20px;
        .suffix {
          color: #444;
          margin-right: 4px;
        }
      }
      .button-panel {
        .el-button + .el-button {
          margin-left: 8px;
        }
        .el-col:last-child {
          height: 26px;
          text-align: right;
        }
      }
      table {
        margin-top: 10px;
        table-layout: fixed;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        td {
          padding: 16px 10px;
          vertical-align: middle;
          word-break: break-all;
          &:last-child {
            text-align: right;
          }
          .tag {
            width: 76px;
            height: 20px;
            background: rgba(131, 11, 185, 1);
            border-radius: 2px;
            line-height: 20px;
            text-align: center;
            color: #fff;
            margin-top: 6px;
            display: inline-block;
          }
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          border-bottom: 1px solid #eee;
          background: rgba(249, 249, 249, 1);
          color: rgba(136, 136, 136, 1);
          tr {
            td {
              padding: 13px 10px;
              &:last-child {
                text-align: right;
              }
            }
          }
        }
        .tbody-row {
          &:hover {
            background: #f0f8ff;
          }
        }
        tbody {
          text-align: left;
          tr {
            border-bottom: 1px solid #eee;
          }
          .border-none {
            border-bottom: none;
          }
        }
      }
    }
  }
}
.el-button + .el-button {
  margin-left: 18px;
}
.btn {
  width: 80px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  padding: 0;
}
.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
</style>
