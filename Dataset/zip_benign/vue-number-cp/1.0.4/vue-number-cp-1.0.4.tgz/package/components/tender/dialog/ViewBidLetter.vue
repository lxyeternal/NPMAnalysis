<template>
  <div>
    <el-dialog class="dialog dialog-drafts" :title="info.bidTitle + (isAwaroed ? '集中采购中标函' : '集中采购感谢函')" :append-to-body="true" :lock-scroll="true" :visible.sync="showBulletBox1" width="840px" center :close-on-click-modal="false">
      <div class="drafts-list tl">
        <h1 class="f12"><span class="bold">{{info.supplierCorpName}}</span> ：</h1>
        <div v-if="isAwaroed" class="content">
          <p class="f12">祝贺贵公司成为{{info.bidTitle}}集中采购中标单位<span v-if="isAwaroed && info.remark">（{{info.remark}}）</span>。</p>
          <p class="f12">附件为《战略框架协议》、《廉洁合作协议书》、《采购合同通用条款》，请在线电子签章后提交，届时我司收到用印版中标附件。请与附件内的各事业部联系人对接具体事宜。</p>
        </div>
        <div class="content" v-else>
          <p class="f12">首先非常感谢对绿地集团的厚爱！</p>
          <p class="f12">贵公司的投标文件建材集团组织开标小组，认真翻阅各家单位的投标资料，经过对比讨论，贵公司的报价较高及其他原因导致未入围集团的直采名单，希望未来还有机会和贵公司合作。</p>
          <p class="f12">原合作单位今年未中标，请继续履约原有合同。</p>
          <p class="f12">谢谢！</p>
        </div>
        <div class="sign">
          <p class="f12 tr" v-if="winBidcorpInfo.length">{{winBidcorpInfo[1].corpName}}/{{winBidcorpInfo[0].corpName}}</p>
          <p class="f12 tr">{{handlePublishTime(info.publishTime)}}</p>
          <img style="right: 196px;" src="../../../assets/images/tender/sh.png" alt="">
          <img src="../../../assets/images/tender/nb.png" alt="">
        </div>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <el-button class="normal-btn" size="small" @click="showBulletBox1=false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: "ViewBidLetter",
  data() {
    return {
      showBulletBox1: false,
      isAwaroed: true,
      info: {},
      winBidcorpInfo: {},
    }
  },
  methods: {
    handlePublishTime(time) {
      if (time) {
        const list1 = time.split(" ")
        const list2 = list1[0].split("-")
        return list2[0] + '年' + list2[1] + '月' + list2[2] + '日'
      } else {
        const day = new Date()
        return this.$formatTime(day, '年月日')
      }
    },
    open(info = {}, isAwaroed = true) {
      console.log(info)
      this.isAwaroed = isAwaroed ? true : false
      this.info = this.$clone(info)
      let category;
      if (this.info.ibBidCategoryInfos && this.info.ibBidCategoryInfos.length) {
        if (this.info.ibBidCategoryInfos.length == 1) {
          category = this.info.ibBidCategoryInfos[0].categoryLevelTwoName
        } else {
          let a = []
          this.info.ibBidCategoryInfos.forEach(i => {
            a.push(i.categoryLevelThreeName)
          });
          a = [...new Set(a)]
          category = a.join('、')
        }
      }

      const corpId = this.info.corpId || this.$store.state.userInfo.corpId
      this.winBidcorpInfo = this.$winBidcorpInfo()
      this.info.bidTitle = '绿地建材集团' + this.info.year + category
      this.showBulletBox1 = true
    },
  }
}
</script>

<style scoped lang="scss">
.dialog-drafts {
  /deep/ .el-dialog--center .el-dialog__body {
    padding-top: 10px;
  }
  .drafts-list {
    .content {
      margin: 10px 0 50px;
      > p {
        text-indent: 2em;
      }
    }
    .sign {
      margin-bottom: 35px;
      position: relative;
      > p {
        margin-bottom: 6px;
      }
      > img {
        width: 89px;
        height: 89px;
        position: absolute;
        right: 22px;
        top: -34px;
      }
    }
  }
  .searchbox {
    text-align: center;
    margin-top: 20px;
  }
}
</style>