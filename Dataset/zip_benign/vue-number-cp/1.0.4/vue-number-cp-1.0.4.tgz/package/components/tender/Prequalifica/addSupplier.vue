<template>
  <div class="addSupplier">
    <el-dialog class="dialog dialog-drafts" :title="'补充供应商'" :append-to-body="true" :lock-scroll="true" :visible.sync="showRelease" width="850px" center :close-on-click-modal="false" @close="close()">
      <div class="drafts-list tl">
        <p class="tl">请搜索选择供应商，点击【确认补充】按钮，系统统一发送给邀请通知给已入驻的供应商，未入驻的供应商，系统会自动记录该供应商，待采购商线下与未入驻供应商沟通邀其入驻后可直接参与招标。</p>
        <el-form class="form" size="small" label-width="110px">
          <el-row>
            <el-col :span="24">
              <el-form-item label="添加供应商：">
                <el-autocomplete v-model="ibSupplierBeans" :fetch-suggestions="buyersInviteSupplierFilter" placeholder="请输入关键词搜索并添加供应商，关键词输入越完整搜索到的概率越高" @select="handleSelect"></el-autocomplete>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div class="order-info-title bold tl">
          已添加的供应商
        </div>
        <el-row class="button-panel">
          <el-col :span="24">
            <el-checkbox v-model="checkboxAll" style="margin: 0 10px" @change="checkboxChange" :disabled="!list.length">全选</el-checkbox>
            <el-button :class="{'isDisabled':isDisabled || !list.length}" :disabled="isDisabled || !list.length" class="btn w100" size="small" @click="batchDel">批量删除</el-button>
          </el-col>
        </el-row>
        <table class="table">
          <thead>
            <tr>
              <td width="60px">序号</td>
              <td>预设入围供应商</td>
              <td width="160px">状态</td>
              <td width="60px">操作</td>
            </tr>
          </thead>
          <tbody class="tbody-row" v-for="(a,ind) in list" :key="ind">
            <tr v-if="(pageIndex-1)*pageSize<=ind && ind<pageIndex*pageSize">
              <td class="grey">
                <el-checkbox v-model="a.checkbox" @change="checkboxChangeOne"></el-checkbox>
                <span style="margin-left:10px">{{ind+1}}</span>
              </td>
              <td v-if="a.status=='1'" class="blue hand hover-underline" @click="goViewSupplierInfo(a)">{{a.supplierName}}</td>
              <td v-if="a.status=='0'">{{a.supplierName}}</td>
              <td>{{a.statusName}}</td>
              <td><span class="blue hand" @click="del(ind)">删除</span></td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!list.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>请添加供应商！</p>
        </div>
        <div class="table-pagination" v-if="list.length != 0">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="list.length" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" :class="{'isDisabled-primary': !list.length }" @click="buyersInviteSupplier">确认补充</div>
        <div class="clearBtn" @click="showRelease=false;close()">取消</div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
export default {
  components: {
    Loading,
  },
  data() {
    return {
      isLoading: false,

      isDisabled: true,
      ibSupplierBeans: '', // 供应商筛选列表
      checkboxAll: false,// 全选
      list: [],
      bidNo: '',
      showRelease: false,
      // total: 0, //分页 总页数
      pageSize: 8, //分页 每页的长度
      pageIndex: 1, //当前页码
    }
  },
  methods: {
    goViewSupplierInfo(a) {
      window.open(this.$router.resolve({
        path: "/viewSupplierInfo",
        query: { corpId: a.corpId, 'bidNo': this.bidNo }
      }).href, '_blank')
    },
    // 分页
    handleCurrentChange(page) {
      this.checkboxAll = false
      this.pageIndex = page;
      this.list.forEach((i, index) => {
        this.$set(i, 'checkbox', false)
      });
      //   window.scrollTo(0, 0)
    },
    // 采购商邀约供应商检索
    buyersInviteSupplierFilter(keyWord, cd) {
      if (keyWord) {
        let param = {
          bidNo: this.bidNo,
          keyWord: keyWord,
          pageIndex: 1,
          pageSize: 100
        }
        InterfaceService.buyersInviteSupplierFilter(param, data => {
          this.isLoading = false;
          if (data && data.respData && data.respData.respCode === "0000") {
            let list = data.respData.ibSupplierBeans || []
            list.forEach(i => {
              i.value = i.supplierName
            });
            console.log(list)
            cd(list)
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
      } else {
        cd([])
      }
    },
    // 采购商邀约供应商
    buyersInviteSupplier() {
      let corpInfo = []
      if (this.list.length != 0) {
        this.list.forEach(i => {
          corpInfo.push({
            corpId: i.corpId,
            corpName: i.supplierName,
            supplyType: i.supplyType,
          })
        });
      } else {
        return
      }
      let param = {
        bidNo: this.bidNo,
        corpInfos: corpInfo,
      }
      InterfaceService.buyersInviteSupplier(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('补充成功!')
          this.showRelease = false
          this.close()
          this.$emit('getData')
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    handleSelect(item) {
      console.log(item)
      if (!item.trustCode) {
        return this.$message.error('您所选的邀约供应商' + item.supplierName + '信息缺失，请核实')
      }
      if (this.list.length == 0) {
        this.list.push(item)
        this.processList()
      } else {
        let a = this.list.filter(i => i.supplierName === item.supplierName)
        if (a.length == 0) {
          this.list.push(item)
          this.processList()
        } else {
          this.$message('不能重复添加同一家供应商')
        }
      }
    },
    // 列表数据处理
    processList() {
      this.list.forEach(i => {
        this.$set(i, 'checkbox', false)
      });
    },
    // 全选
    checkboxChange() {
      if (this.checkboxAll) {
        this.list.forEach((i, index) => {
          if ((this.pageIndex - 1) * this.pageSize <= index && index < this.pageIndex * this.pageSize) {
            this.$set(i, 'checkbox', true)
          }
        });
        this.isDisabled = false
      } else {
        this.list.forEach((i, index) => {
          if ((this.pageIndex - 1) * this.pageSize <= index && index < this.pageIndex * this.pageSize) {
            this.$set(i, 'checkbox', false)
          }
        });
        this.isDisabled = true
      }
    },
    // 单选
    checkboxChangeOne() {
      const a = this.list.filter(i => i.checkbox == true)
      if (a.length == 0) {
        this.isDisabled = true
        this.checkboxAll = false
      } else {
        this.isDisabled = false
        if (a.length != this.list.length) {
          this.checkboxAll = false
        } else {
          this.checkboxAll = true
        }
      }
    },
    // 批量删除
    batchDel() {
      let a = this.list.some(i => i.checkbox === true)
      if (!a) {
        this.$message('请勾选')
      } else {
        console.log(this.list)
        let b = this.list.filter(i => i.checkbox === false)
        console.log(b)
        this.list = b
        this.checkboxAll = false
        this.$forceUpdate()
      }
    },
    del(index) {
      this.list.splice(index, 1)
    },
    open(bidNo) {
      this.bidNo = bidNo
      this.showRelease = true
    },
    close() {
      this.list = []
      this.ibSupplierBeans = ''
      this.checkboxAll = false
      this.pageIndex = 1
    },
  },
}
</script>
<style lang="scss" scoped>
.w100 {
  width: 100px !important;
}
.btn {
  width: 80px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  padding: 0;
}
.drafts-list {
  > .tl {
    font-size: 12px;
    line-height: 18px;
    margin: 3px 0 10px;
  }
  .button-panel {
    margin-bottom: 10px;
    .el-button + .el-button {
      margin-left: 8px;
    }
  }
}
.table {
  table-layout: fixed;
  width: 810px;
  line-height: 23px;
  font-size: 12px;
  td {
    padding: 14px 10px;
    vertical-align: middle;
    word-break: break-all;
  }

  thead {
    font-size: 14px;
    text-align: left;
    white-space: nowrap;
    border-bottom: 1px solid #eee;
    background: rgba(249, 249, 249, 1);
    color: rgba(136, 136, 136, 1);
    tr {
      td {
        padding: 4px 10px;
      }
    }
  }

  tbody {
    text-align: left;
    tr {
      border-bottom: 1px solid #eee;
      &:hover {
        background: #f0f8ff;
      }
    }
  }
}
.accout-empty {
  padding: 100px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
.searchbox {
  text-align: center;
  margin-top: 20px;
  display: flex;
  justify-content: center;
  .searchBtn {
    width: 120px;
    height: 34px;
    line-height: 34px;
    background: linear-gradient(
      122deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(255, 255, 255, 1);
    display: inline-block;
    cursor: pointer;
  }
  .clearBtn {
    width: 120px;
    margin-left: 20px;
    height: 34px;
    line-height: 32px;
    border: 1px solid rgba(201, 159, 79, 1);
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(201, 159, 79, 1);
    display: inline-block;
    cursor: pointer;
  }
}
</style>