<template>
  <div class="upfile-container">
    <input ref="upload" style="display: none" :multiple="multiple" name="my-upfile-component-input-name" type="file" v-if="!disabled" @change="handleUpload" />
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api"
export default {
  components: {
    Loading
  },
  props: {
    // 文件路径
    dirName: {
      type: String,
      default: '',
      required: true
    },
    // 上传type入参
    type: {
      type: String,
      default: '4'
    },
    // 指定上传文件类型 'exe,txt,jpg'
    fileTypes: {
      type: String,
      default: ''
    },
    // 上传文件格式错误提示, 默认提示为: 文件格式错误, 请上传后缀名为 [ xxx , xxx ] 的文件
    fileTypeMsg: {
      type: String,
      default: ''
    },
    // 是否即时提交 false : 不会添加就上传 需要外部调用 handleConfim 方法 实现统一提交
    immediateSubmit: {
      type: Boolean,
      default: true
    },
    // 实时清理 上传数组 true: 发送一次 emit 清理一次 上传数组, false: 提交后才清理
    immediateClearList: {
      type: Boolean,
      default: false
    },
    // 提示上传成功
    showMsg: {
      type: Boolean,
      default: true
    },
    // 区别文档<后台入参用>
    docType: {
      type: String,
      default: ''
    },
    // 是否允许上传多个
    multiple: {
      type: Boolean,
      default: false
    },
    // 是否禁用
    disabled: {
      type: Boolean,
      default: false
    },
    // 上传文件大小限制
    fileSize: {
      type: Number,
      default: 0
    },
    // 上传文件超过大小限制时 提示信息
    fileSizeMsg: {
      type: String,
      default: '上传文件太大'
    },
    // 上传文件超过大小限制时 提示信息
    btnName: {
      type: String,
      default: '上传文件'
    },
    fileNameList: {
      type: Array,
      default: () => []
    },
    // 多个上传组件区分
    id: {
      type: String,
      default: '0'
    },
    // 多施工单位上传组件区分
    constructorid: {
      type: String,
      default: '0'
    },
  },
  data() {
    return {
      form: {
        documentType: '10',
      },
      attachList: [],
      isLoading: false
    }
  },
  methods: {
    open() {
      this.$refs.upload.click()
    },
    /**
     * 文件上传
     */
    handleUpload(e) {
      //  检测是否文件已添加
      let state = ''
      try {
        console.log(e.target.value);
        state = this.attachList.filter(item => item.targetValue === e.target.value)
      } catch (error) { }

      if (state.length) {
        this.$message.error('请勿重复添加文件');
        return
      }

      // 格式化 文件指定上传格式
      const fileTypes = this.fileTypes ? this.fileTypes.replace(/\s*/g, '').split(',') : [],
        // 类型不符 提示信息
        fileTypeMsg = this.fileTypeMsg ? this.fileTypeMsg : `文件格式错误, 请上传后缀名为 [ ${this.fileTypes} ] 的文件`
      console.log(e.target.files);
      if (e.target.files.length === 1) {
        let reg = /\.\w+$/;
        let regLeft = /《/;
        let regRight = /》/;
        let file = e.target.files[0]
        let checkTextList = JSON.parse(sessionStorage.getItem('checkTextList') || '[]');
        console.log(checkTextList);
        let onOff = false;
        let forbidText = ''
        checkTextList.forEach(i=>{
          if (i != '' && file.name.indexOf(i) != -1) {
            onOff = true
            forbidText = i
          }
        });
        if (onOff) {
          this.$message.error('文件名包含特殊字符【'+forbidText+'】,请修改文件名后再上传')
          return false
        }
        // 获取当前上传文件名
        let name = file.name || ''
        // 截取当前上传文件后缀
        const fileType = name.slice(name.lastIndexOf('.') + 1, name.length),
          // 保存已添加文件名
          targetValue = e.target.value || '',
          fileName = name.replace(reg, '').replace(regLeft, '').replace(regRight, '');
        // 移除 input value 解决同一个文件不触发 change事件问题

        // 是否需要做文件格式限制
        let typeOnOff = true;
        let fileSizeOnOff = true;
        if (fileTypes.length && !fileTypes.includes(fileType)) {
          this.$message.error(fileTypeMsg);
          this.resetInputValue()
          typeOnOff = false
          return;
        }

        if (this.fileSize && file.size > this.fileSize) {
          this.$message.error(`${this.fileSizeMsg}`);
          this.resetInputValue()
          fileSizeOnOff = false
          return;
        }
        if (this.fileNameList.length > 0 && fileSizeOnOff && typeOnOff) {
          this.fileNameList.forEach(item => {
            // 带不带书名号《》
            if (item.str != fileName) {
              if (item.hasMarks) {
                this.$message.info(`由于你上传的文件名，不符合规范，系统将自动更改成：《${item.str}》.${fileType}`)
                name = "《" + item.str + "》." + fileType
              } else {
                this.$message.info(`由于你上传的文件名，不符合规范，系统将自动更改成：${item.str}.${fileType}`)
                name = item.str + "." + fileType
              }
            }
          })
        }
        this.attachList.push({
          type: this.docType,
          file: file,
          name: name,
          documentType: this.form.documentType,
          targetValue
        })
        this.resetInputValue()

        // 即时提交
        if (this.immediateSubmit) {
          this.handleConfim()
        } else {
          this.$emit('outputList', this.attachList || [])
          this.immediateClearList && (this.attachList = [])
        }
        // }
      } else if (e.target.files.length > 1) {
        const files = [...e.target.files] || []

        files.forEach(item => {
          const name = item.name,
            fileType = name.slice(name.lastIndexOf('.') + 1, name.length)

          // 是否需要做文件格式限制
          if (fileTypes.length && !fileTypes.includes(fileType)) {
            this.$message.error(fileTypeMsg);
            this.resetInputValue()
            return;
          }

          if (this.fileSize && item.size > this.fileSize) {
            this.$message.error(this.fileSizeMsg);
            this.resetInputValue()
            return;
          }

          this.attachList.push({
            type: this.docType,
            file: item,
            name: item.name,
            documentType: this.form.documentType
          })
        })
        // 即时提交
        if (this.immediateSubmit) {
          this.handleConfim()
        } else {
          this.$emit('outputList', this.attachList || [])
          this.immediateClearList && (this.attachList = [])
        }
      }
      // 清除value 防止选择相同文件 不触发 change事件

    },

    /**
     * 重置input value  防止 同一个文件连续提交 不触发 onchange事件
     */
    resetInputValue() {
      let isIE10 = false,
        uploadInputs = document.getElementsByName('my-upfile-component-input-name') || []

      if (window.navigator.userAgent.indexOf('MSIE') >= 1) { // 判断ie10以及以下
        isIE10 = true
      } else {
        isIE10 = false
      }
      for (let i = 0, len = uploadInputs.length; i < len; i++) {
        const element = uploadInputs[i];

        if (isIE10) {
          let form = document.createElement('form'),
            beforInput = element.nextSibling,
            parentInput = element.parentNode

          form.appendChild(element)
          form.reset()
          parentInput.insertBefore(element, beforInput)
        } else {
          element.value = ''
        }

      }
    },

    /**
     * 提交上传
     * @param fileList: 外部调用时, 可传人处理过的上传列表文件
     */
    handleConfim(fileList) {
      this.isLoading = true;
      this.uploadContractToOss(fileList).then(res => {
        this.isLoading = false;
        const itemList = fileList || this.attachList
        let ossFile = []
        itemList.forEach((item, index) => {
          res.forEach(oss => {
            if (index == oss.index) {
              item.url = oss.url;
              ossFile.push({ fileType: this.type, filePath: oss.url, })
            }
          })
        })
        // {"ossFile":[{"fileType":"","filePath":""},{"fileType":"","filePath":""}],"appName":"PROD"}
        let param = {
          ossFile: ossFile,
          appName: "PROD"
        }
        InterfaceService.ossSignatureUrl(param, data => {
          this.isLoading = false;
          if (data && data.respData && data.respData.respCode === "0000") {
            itemList[0].allUrl = data.respData.ossFile[0].url
            itemList[0].id = this.id
            console.log(itemList)
            this.$emit('outputList', itemList || [])
            //  发送完毕后 清理上传数据数组
            this.attachList = []
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        // ossSignatureUrl

      })
    },

    /**
     * 文件上传到oss
     */
    uploadHander(data, pos, file, callBack, customName) {
      InterfaceService.uploadToOss(data, file, this.dirName, pos, callBack, customName);
    },

    /**
     * 去后端拿签名
     */
    uploadContractToOss(fileList) {
      return new Promise((resolve, reject) => {
        // console.log(this.type, '--this.type ');

        InterfaceService.getOssSignature({ type: this.type, appName: "PROD" }, data => {
          const promiseList = [];
          const itemList = fileList || this.attachList
          itemList.forEach((item, index) => {
            const promise = new Promise(_resolve => {
              this.uploadHander(data, index, item.file, (pos, file, dir, signature) => {
                let u = signature.dir + dir + item.name;
                if (this.showMsg) {
                  this.$message.success('上传成功')
                }
                _resolve({ index: index, url: u });
              },
                item.name
              )
            });
            promiseList.push(promise);
          });
          // 上传所有图片后回调
          Promise.all(promiseList).then(values => {
            resolve(values);
          });
        }, data => { });
      });
    },
  }
}
</script>

<style lang="scss" scoped>
.upfile-container {
  text-align: left;
  .center {
    input {
      width: 0;
      height: 0;
      overflow: hidden;
      opacity: 0;
      border: 0;
      padding: 0;
    }
    label {
      float: left;
      cursor: pointer;
      user-select: none;
      outline: none;
    }
    .disabled {
      background-color: #dddddd !important;
      cursor: not-allowed;
    }
  }
  ::-webkit-scrollbar {
    width: 1px !important;
  }
}
</style>
