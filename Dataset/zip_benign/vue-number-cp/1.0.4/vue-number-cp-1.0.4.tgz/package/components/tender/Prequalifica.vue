<template>
  <div class="prequalifica">
    <div class="list-home">
      <!-- 审批状态 -->
      <div class="box_type" v-if="active >= 0 && ibOaPreAppBean.approveStatus">
        <p>状态：{{ibOaPreAppBean.approveStatus}}</p>
        <div class="annex">
          <div class="left grey">OA流程编号：</div>
          <div class="right">{{ibOaPreAppBean.approveId}}</div>
        </div>
        <div class="annex">
          <div class="left grey">OA审批凭证：</div>
          <div class="right">
            <p v-for="(a,ind) in ibOaPreAppBean.approveAttachInfos" :key="ind+'p'">
              {{a.attachName}}
              <span class="hand blue" @click="handleView(a.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(a.attachName,a.attachUrl)">下载</span>
            </p>
          </div>
        </div>
      </div>
      <p class="acctName">经办人：<span>{{ibBidHandlerInfos.join(";")}}</span></p>
      <div class="line"></div>
      <div class="list-content">
        <div class="panel">
          <el-form class="form" size="small" label-width="100px" type="flex" justify="space-between">
            <el-row>
              <el-col :span="8">
                <el-form-item label="供应商：" class="samll_label">
                  <el-input v-model.trim="supplierCorpName" placeholder="输入供应商名称" maxlength="64" clearable></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="注册资本：">
                  <el-input v-model.trim="regCapital" placeholder="请输入" maxlength="64" class="right_padding" type="number">
                    <div slot="suffix" class="suffix">万元以上</div>
                  </el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="第三方资信：">
                  <el-input v-model.trim="tianyanchaScore" placeholder="请输入" maxlength="64" class="right_padding" type="number">
                    <div slot="suffix" class="suffix">分以上</div>
                  </el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="来源：" class="samll_label">
                  <el-select v-model="originCode" placeholder="请选择" clearable>
                    <el-option v-for="item in configList" :key="item.code" :label="item.value" :value="item.code">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="营业范围是否含制造：" class="business">
                  <el-radio-group v-model="manufacturerFlag" @change="search()">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'1'">是</el-radio>
                    <el-radio :label="'0'">否</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="标记入围状态：" class="mark">
                  <el-radio-group v-model="selectStatus" @change="search()">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'0'">未入围</el-radio>
                    <el-radio :label="'1'">入围</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="供应商性质：" class="nature">
                  <el-radio-group v-model="supplierNature" @change="search()">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'0'">厂家</el-radio>
                    <el-radio :label="'1,2'">代销商</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24" class="form-btns" align="center">
                <el-button class="btn" type="primary" size="small" @click="search()">搜索</el-button>
                <el-button class="btn" size="small" @click="clear()">清除</el-button>
                <el-button class="btn w100" @click="exportSearch()">导出查询结果</el-button>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <el-row class="button-panel">
          <el-col :span="12" v-if="active === 0 || showSupplementarySupplier">
            <el-checkbox v-model="checkboxAll" :disabled="!ibSupplierListInfoList.length" style="margin: 0 10px" @change="checkboxChange">全选</el-checkbox>
            <el-button class="btn" :class="{'isDisabled':isDisabled || !ibSupplierListInfoList.length}" :disabled="isDisabled || !ibSupplierListInfoList.length" size="small" @click="batchDownload">批量下载</el-button>
            <el-button class="btn w120" :class="{'isDisabled':isDisabled || !ibSupplierListInfoList.length}" :disabled="isDisabled || !ibSupplierListInfoList.length" size="small" @click="batchSet">批量设置入围状态</el-button>
          </el-col>
          <el-col :span="active === 0 || showSupplementarySupplier ? 12:24">
            <p class="shortlisted">预设入围<span class="red"> {{selectCount}} </span>家</p>
            <el-button v-if="active>=0 || showSupplementarySupplier" :disabled="active>4" class="btn w100" :class="{'isDisabled':active>4}" size="small" @click="$refs.addSupplier.open(bidNo)">补充供应商</el-button>
            <el-button v-if="active === 0 && !ibOaPreAppBean.approveStatus " class="btn w100" type="primary" size="small" @click="$refs.sendPrequalifica.open(bidNo)">提交入围审批</el-button>
          </el-col>
        </el-row>
        <table>
          <thead>
            <tr>
              <td width="40px"></td>
              <td width="68px">序号</td>
              <td>标记入围状态</td>
              <td width="240px">供应商</td>
              <td width="120px">供应商性质</td>
              <td width="100px">
                <p>营业范围</p>
                <p>是否含制造</p>
              </td>
              <td width="140px" class="tr">第三方资信</td>
              <td width="140px" class="tr">注册资本</td>
              <td width="20px"></td>
              <td width="100px">来源</td>
              <td width="110px">操作</td>
            </tr>
          </thead>
          <tbody v-for="(a,ind) in ibSupplierListInfoList" :key="ind" class="tbody-row">
            <tr>
              <td>
                <el-checkbox v-if="active === 0 || showSupplementarySupplier" v-model="a.checkbox" @change="checkboxChangeOne" :disabled="a.selectStatus=='0' && a.originCode=='补充供应商'"></el-checkbox>
              </td>
              <td>
                {{ind + 1 + ((pageIndex - 1) * pageSize)}}
              </td>
              <td :class="{red:a.selectStatus=='1'}">
                {{a.selectStatus=='0'?'未入围':'入围'}}
                <el-popover popper-class="dark-popover" trigger="hover" placement="right">
                  <div style="color: #fff;width: 185px;">
                    {{a.rejectReason}}
                  </div>
                  <i v-show="a.selectStatus=='0' && a.rejectReason" slot="reference" class="cause-ico hand"></i>
                </el-popover>
              </td>
              <td>
                <span class="blue hand hover-underline" v-if="a.isEnter=='1'" @click="openNewPage(a.supplierCorpId,bidNo,a.submitBidNo)">{{a.supplierCorpName}}</span>
                <span v-else>{{a.supplierCorpName}}</span>
                <TagSourceList :corpTagList="a.corpTagList" @getData="prequalificaList"></TagSourceList>
              </td>
              <td>
                {{a.supplierNature}}
              </td>
              <td>
                {{a.manufacturerFlag=='0'?'不是':'是'}}
              </td>
              <td class="tr">
                {{a.tianyanchaScore}}
              </td>
              <td class="tr">
                {{a.regCapital}}
              </td>
              <td></td>
              <td>
                <!-- {{a.originCode=='PUBLIC_BID'?'公开招标':''}} -->
                {{a.originCode}}
              </td>
              <td>
                <p class="hand blue" @click="$refs.sourceTag.open(bidNo,a)">标记来源</p>
                <p class="hand blue" v-if="a.originCode!='补充供应商' || a.selectStatus!='0'" @click="packageDownload([a])">下载资质附件</p>
                <p class="hand blue" v-if="a.originCode!='补充供应商' && active === 0" @click="isBatch=false;submitBidNo = a.submitBidNo;supplierCorpNameCheck=a.supplierCorpName; showBulletBox1=true">设置入围状态</p>
              </td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!ibSupplierListInfoList.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
        </div>
        <div class="table-pagination" v-if="ibSupplierListInfoList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>

    <!-- 取消标记入围原因 -->
    <el-dialog class="dialog dialog-drafts" :title="isBatch?'批量设置入围状态':'设置入围状态'" :append-to-body="true" :lock-scroll="true" :visible.sync="showBulletBox1" width="840px" center :close-on-click-modal="false" @close="close()">
      <div class="drafts-list tl">
        <div class="supplierCorpName">供应商名称：<p>{{supplierCorpNameCheck}}</p>
        </div>
        <el-form class="form" size="small" label-width="118px" :model="form" :rules="rules" ref="formBulletBox1">
          <el-row>
            <el-col :span="24">
              <el-form-item label="标记入围状态：" prop="selectStatus">
                <el-radio-group v-model="form.selectStatus">
                  <el-radio :label="'1'">入围</el-radio>
                  <el-radio :label="'0'">未入围</el-radio>
                </el-radio-group>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row v-if="form.selectStatus === '0'">
            <el-col :span="24">
              <el-form-item label="" prop="rejectReason">
                <el-input class="claim" show-word-limit type="textarea" placeholder="请输入原因" v-model="form.rejectReason" maxlength="200">
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="confirm()">确认</div>
        <div class="clearBtn" @click="showBulletBox1=false;close()">取消</div>
      </div>
    </el-dialog>
    <SendPrequalifica ref="sendPrequalifica" @getData="prequalificaList"></SendPrequalifica>
    <AddSupplier ref="addSupplier" @getData="prequalificaList"></AddSupplier>
    <SourceTag ref="sourceTag" @getData="prequalificaList"></SourceTag>

    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
// import Breadcrumb from "@/components/base/Breadcrumb";
import SendPrequalifica from "@/components/tender/Prequalifica/sendPrequalifica";
import AddSupplier from "@/components/tender/Prequalifica/addSupplier";
import SourceTag from "@/components/tender/Prequalifica/sourceTag";
import TagSourceList from "@/components/tender/Prequalifica/tagSourceList";
import { viewFile } from '@/utils/orderUtil';
export default {
  components: {
    Loading,
    // Breadcrumb,
    SendPrequalifica,
    AddSupplier,
    SourceTag,
    TagSourceList
  },
  props: ['active', 'showSupplementarySupplier', 'categoryLevelTwoId'],
  data() {
    return {
      isLoading: false,

      isBatch: false,
      submitBidNo: '',
      supplierCorpNameCheck: '',
      showBulletBox1: false,
      form: {
        selectStatus: '', //标记入围状态
        rejectReason: '', //回复描述
      },
      rules: {
        selectStatus: [
          { required: true, message: '请选择', trigger: 'change' }
        ],
        // rejectReason: [
        //   { required: true, message: '请输入原因，限200字', trigger: 'blur' }
        // ],
      },

      checkboxAll: false, // 全选
      isDisabled: true,
      value: [],
      ibBidHandlerInfos: [], // 经办人信息
      configList: [],
      total: 0, //分页 总页数
      pageSize: 20, //分页 每页的长度
      pageIndex: 1, //当前页码

      selectCount: 0, //预设入围N家
      ibSupplierListInfoList: [],

      supplierCorpName: '',//	供应商名称
      regCapital: '',//	注册资本
      tianyanchaScore: '',//	天眼查分数
      originCode: '',//	来源
      manufacturerFlag: '',//	营业范围是否含	制造
      supplierNature: '',//	供应商性质：
      selectStatus: '',//	标记入围状态
      bidNo: '',//	招标编号
      bidName: '',
      acctId: false,
      ibOaPreAppBean: {}, // 资格预审入围审批
    };
  },
  methods: {
    openNewPage(supplierCorpId, bidNo, submitBidNo) {
      window.open(this.$router.resolve({
        path: "/viewSupplierInfo",
        query: {
          corpId: supplierCorpId,
          bidNo: bidNo || '',
          submitBidNo: submitBidNo || '',
          bidName: this.$route.query.bidName || ''
        }
      }).href, '_blank')
    },
    // 全选
    checkboxChange() {
      this.ibSupplierListInfoList.forEach(i => {
        if (i.selectStatus != '0' || i.originCode != '补充供应商')
          this.$set(i, 'checkbox', this.checkboxAll)
      });
      console.log(this.ibSupplierListInfoList)
      if (this.checkboxAll) {
        let a = this.ibSupplierListInfoList.some(i => i.checkbox === true)
        if (a) {
          this.isDisabled = false
        } else {
          this.isDisabled = true
          this.checkboxAll = false
        }
      } else {
        this.isDisabled = true
      }
    },
    // 单选
    checkboxChangeOne() {
      const a = this.ibSupplierListInfoList.filter(i => i.checkbox == true)
      if (a.length == 0) {
        this.isDisabled = true
        this.checkboxAll = false
      } else {
        this.isDisabled = false
        if (a.length != this.ibSupplierListInfoList.length) {
          this.checkboxAll = false
        } else {
          this.checkboxAll = true
        }
      }
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      window.scrollTo(0, 0)
      this.prequalificaList()
    },
    // 初始化供应商性质(搜索模块：除去钢筋品类，其余品类默认勾选「厂家」)
    // getSupplierNature(val) {
    //   let a = val.split(',')
    //   let b = a.some(i => i == '8')
    //   if (b) {
    //     this.supplierNature = ''
    //   }
    //   this.prequalificaList()
    // },
    // 资格预审列表
    prequalificaList(type) {
      console.log(type)
      if (type == '1') {
        this.$parent.getBuyersTenderDetail()
      }
      let param = {
        supplierCorpName: this.supplierCorpName,
        regCapital: this.regCapital,
        tianyanchaScore: this.tianyanchaScore,
        originCode: this.originCode,
        supplierNature: this.supplierNature == '' ? [] : this.supplierNature.split(','),
        manufacturerFlag: this.manufacturerFlag,
        selectStatus: this.selectStatus,
        bidNo: this.bidNo,
        pageIndex: this.pageIndex,
      };
      InterfaceService.prequalificaList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {

          this.ibOaPreAppBean = data.respData.ibOaPreAppBean || {}
          this.ibSupplierListInfoList = data.respData.ibSupplierListInfoList || []
          this.ibBidHandlerInfos = [];
          data.respData.ibBidHandlerInfos && data.respData.ibBidHandlerInfos.forEach(item => {
            if (item.handleAcctName) {
              // this.ibBidHandlerInfos.push(item.handleAcctName + '(Tel:' + (item.handleAcctMobile || '暂无手机号') + ')')
              this.ibBidHandlerInfos.push(item.handleAcctName)
            }
          });
          if (this.ibSupplierListInfoList.length != 0) {
            this.ibSupplierListInfoList.forEach(i => {
              this.$set(i, 'checkbox', false)

              if (i.corpTagList) {
                i.corpTagList.forEach(j => {
                  this.$set(j, 'showRemark', false)
                  this.$set(j, 'disabled', true)
                  this.$set(j, 'showOperat', false)
                });
              }
            });
          }
          // 入围N家
          this.selectCount = data.respData.selectCount || 0
          this.total = data.respData.totoalCount
          this.pageSize = data.respData.pageSize
          this.isDisabled = true
          this.checkboxAll = false
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 来源列表
    getDropDownList() {
      let param = {
        groupId: 'ORIGIN_CODE'
      }
      InterfaceService.getDropDownList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.configList = data.respData.configList
          this.configList.unshift({ value: '全部', code: '' })
          console.log(data.respData)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 文件下载
    handleDownTemp(name, url) {
      console.log(name, url)
      this.$download([{
        name: name,
        url: url
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 在线预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    // 批量下载
    batchDownload() {
      const a = this.ibSupplierListInfoList.filter(i => i.checkbox == true)
      if (a.length == 0) {
        this.$message('请勾选')
        return
      }
      let result = false
      for (let i = 0; i < a.length; i++) {
        result = true
        if (!a[i].ossFileBeanList) {
          this.$message(a[i].supplierCorpName + '暂无资质附件可供下载')
          result = false
          break
        }
      }
      if (result) {
        this.packageDownload(a)
      }
    },
    // 打包下载
    packageDownload(list) {
      let fileInfoBeans = []
      list.forEach(i => {
        if (i.ossFileBeanList) {
          i.ossFileBeanList.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: i.supplierCorpName + '/其他附件/' + item.fileName,
              fileUrl: item.ossUrl,
            })
          })
        }
        if (i.submitChargeAttach) {
          i.submitChargeAttach.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: i.supplierCorpName + '/负责人附件/' + item.fileName,
              fileUrl: item.ossUrl,
            })
          })
        }
        if (i.submitMeetAttach) {
          i.submitMeetAttach.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: i.supplierCorpName + '/对接人附件/' + item.fileName,
              fileUrl: item.ossUrl,
            })
          })
        }
      });
      if (!fileInfoBeans.length) {
        return this.$message.error('暂无资质附件可供下载')
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: this.bidName + "资质附件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },

    batchSet() {
      this.isBatch = true
      this.showBulletBox1 = true
      let handleList = []
      this.ibSupplierListInfoList.filter(i => i.checkbox == true && handleList.push(i.supplierCorpName));
      this.supplierCorpNameCheck = handleList.join('；')
    },
    // 清空弹框
    close() {
      if (this.$refs['formBulletBox1']) {
        this.$refs['formBulletBox1'].resetFields();
      }
      this.submitBidNo = ''
      this.supplierCorpNameCheck = ''
    },
    confirm() {
      let list = []
      if (this.isBatch) {
        const a = this.ibSupplierListInfoList.filter(i => i.checkbox == true)
        a.forEach(i => {
          list.push(i.submitBidNo)
        });
      }
      this.$refs['formBulletBox1'].validate((valid) => {
        if (valid) {
          this.isBatch ? this.buyersIsShortlisted(list, this.form.selectStatus) : this.buyersIsShortlisted([this.submitBidNo], this.form.selectStatus)
        } else {
          console.log('error submit!!');
          return false;
        }
      })
    },
    // 标记或取消入围
    buyersIsShortlisted(submitBidNoList, selectStatus) {
      let param = {
        bidNo: this.bidNo,
        submitBidNoList: submitBidNoList,
        selectStatus: this.form.selectStatus,//0-取消入围，1-标记入围
        rejectReason: this.form.rejectReason,//取消入围原因
      }
      InterfaceService.buyersIsShortlisted(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message({ message: (selectStatus == '0' ? '取消入围' : '标记入围') + '成功', type: 'success' });
          this.showBulletBox1 = false;
          this.checkboxAll = false;
          this.prequalificaList()
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    search() {
      this.pageIndex = 1
      this.prequalificaList()
    },
    exportSearch() {
      let param = {
        supplierCorpName: this.supplierCorpName,
        regCapital: this.regCapital,
        tianyanchaScore: this.tianyanchaScore,
        originCode: this.originCode,
        manufacturerFlag: this.manufacturerFlag,
        selectStatus: this.selectStatus,
        bidNo: this.bidNo, // String	招标编号（必填）
        supplierNature: this.supplierNature == '' ? [] : this.supplierNature.split(','),
      }
      InterfaceService.getDownloadPrequalificationList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          const item = data.respData || {}
          if (item.attachUrl) {
            this.handleDownTemp(item.attachName || '', item.attachUrl || '')
          } else {
            this.$message.error('暂无数据！')
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    clear() {
      this.pageIndex = 1
      this.supplierCorpName = ''//	供应商名称
      this.regCapital = ''//	注册资本
      this.tianyanchaScore = ''//	天眼查分数
      this.originCode = ''//	来源
      this.manufacturerFlag = ''//	营业范围是否含	制造
      this.selectStatus = ''//	标记入围状态
      this.supplierNature = ''
      this.prequalificaList()
    },
    init() {
      if(this.$parent){
        this.$parent.breadcrumb.push({ name: '资格预审' })
      }
    },
  },
  mounted() {
    this.init()
  },
  created() {
    this.bidNo = this.$route.query.bidNo || ''
    this.bidName = this.$route.query.bidName || ''
    this.getDropDownList()
    this.prequalificaList()
  },
};
</script>

<style lang="scss" scoped>
.el-dialog__footer {
  padding-top: 0px !important;
}
/deep/ .claim {
  width: 100%;
  min-height: 140px;
  .el-textarea__inner {
    min-height: 140px !important;
    resize: none;
    overflow: auto;
  }
}
/deep/ .right_padding {
  .el-input__inner {
    padding-right: 60px;
  }
}
/deep/ .el-select {
  width: 100% !important;
}
/deep/ .el-form-item__label {
  // font-size: 12px !important;
  padding: 0 !important;
  color: #888 !important;
}
// /deep/ .el-input--small .el-select,
// .el-input--small .el-input__inner {
//   &::placeholder {
//     font-size: 12px !important;
//   }
//   font-size: 12px !important;
// }
/deep/ .seatchW-width {
  width: inherit;
  .el-form-item__content {
    width: 300px;
  }
}
/deep/ .business {
  .el-form-item__label {
    width: 154px !important;
  }
}
/deep/ .mark {
  .el-form-item__label {
    width: 129px !important;
  }
}
/deep/ .nature {
  .el-form-item__label {
    width: 194px !important;
  }
  .el-form-item__content {
    margin-left: 194px !important;
  }
}
/deep/ .samll_label {
  .el-form-item__label {
    width: 70px !important;
  }
  .el-form-item__content {
    margin-left: 70px !important;
  }
}
.w100 {
  width: 100px !important;
}
.w120 {
  width: 120px !important;
}
.line {
  width: 100%;
  height: 1px;
  background-color: #eee;
  margin-top: 30px;
}
.prequalifica {
  padding-bottom: 60px;
  .list-home {
    width: 1190px;
    margin: 0 auto;
    .box_steps {
      padding: 20px 0 30px;
      box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
    }
    .acctName {
      font-size: 12px;
      line-height: 15px;
      color: #888888;
      margin-top: 20px;
      > span {
        color: #444;
      }
    }
    .list-content {
      .panel {
        background: rgba(249, 249, 249, 1);
        padding: 20px 10px 20px 0px;
        margin: 20px 0;
        .suffix {
          color: #444;
          margin-right: 4px;
        }
      }
      .button-panel {
        .el-button + .el-button {
          margin-left: 8px;
        }
        .el-col:last-child {
          height: 26px;
          text-align: right;
          .shortlisted {
            font-size: 14px;
            line-height: 20px;
            color: rgba(68, 68, 68, 1);
            display: inline-block;
            // margin-right: 48px;
            & + .btn {
              margin-left: 48px;
            }
          }
        }
      }
      table {
        margin-top: 10px;
        table-layout: fixed;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        td {
          padding: 16px 10px;
          vertical-align: middle;
          word-break: break-all;
          &:last-child {
            text-align: right;
          }
          .cause-ico {
            width: 12px;
            height: 11px;
            background: url("../../assets/images/icon/cause.png") no-repeat;
            background-size: 100%;
            margin-left: 2px;
            vertical-align: middle;
            display: inline-block;
          }
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          border-bottom: 1px solid #eee;
          background: rgba(249, 249, 249, 1);
          color: rgba(136, 136, 136, 1);
          tr {
            td {
              padding: 13px 10px;
              &:last-child {
                text-align: right;
              }
            }
          }
        }
        .tbody-row {
          &:hover {
            background: #f0f8ff;
          }
        }
        tbody {
          text-align: left;
          tr {
            border-bottom: 1px solid #eee;
          }
          .border-none {
            border-bottom: none;
          }
        }
      }
    }
  }
}
.dialog-drafts {
  /deep/ .el-dialog--center .el-dialog__body {
    padding-top: 10px;
  }
  .supplierCorpName {
    font-size: 14px;
    line-height: 20px;
    color: #888;
    margin-bottom: 14px;
    > p {
      display: inline-block;
      color: #444;
      width: calc(100% - 90px);
      vertical-align: text-top;
    }
  }
  .searchbox {
    text-align: center;
    margin-top: 20px;
    display: flex;
    justify-content: center;
    .searchBtn {
      width: 120px;
      height: 34px;
      line-height: 34px;
      background: linear-gradient(
        122deg,
        rgba(215, 176, 100, 1) 0%,
        rgba(236, 206, 139, 1) 100%
      );
      font-size: 12px;
      font-family: PingFang SC;
      color: rgba(255, 255, 255, 1);
      display: inline-block;
      cursor: pointer;
    }
    .clearBtn {
      width: 120px;
      margin-left: 20px;
      height: 34px;
      line-height: 32px;
      border: 1px solid rgba(201, 159, 79, 1);
      font-size: 12px;
      font-family: PingFang SC;
      color: rgba(201, 159, 79, 1);
      display: inline-block;
      cursor: pointer;
    }
  }
}

.el-button + .el-button {
  margin-left: 18px;
}
.el-select {
  width: 100%;
}
.btn {
  width: 80px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  padding: 0;
  &.w100 {
    width: 100px;
  }
}

.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
</style>
