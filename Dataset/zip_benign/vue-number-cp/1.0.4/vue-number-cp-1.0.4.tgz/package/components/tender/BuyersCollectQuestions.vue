<template>
  <div class="buyersCollectQuestions">
    <div class="list-home">
      <el-row class="button-panel">
        <el-col :span="24">
          <el-button class="btn w120" size="small" @click="buyersDownloadQuestion()">下载问题汇总表</el-button>
        </el-col>
      </el-row>
      <div class="list-content">
        <div class="panel-switch">
          <ul>
            <li class="active">待回复问题</li>
          </ul>
          <div class="switch hand blue" @click="isShowPanel=!isShowPanel;isShowPanelChenge()">{{isShowPanel?'全部收起':'全部展开'}} <i class="arrow" :class="{active:!isShowPanel}"></i></div>
        </div>
        <div class="panel">
          <el-form class="form" size="small" label-width="100px">
            <el-row>
              <el-col :span="8">
                <el-form-item label="供应商：" class="samll_label">
                  <el-input v-model.trim="supplierCorpName" placeholder="请输入供应商名称" maxlength="200" clearable></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="主题搜索：">
                  <el-input v-model.trim="keyWord" placeholder="请输入关键词" maxlength="200" clearable></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8">
                <el-form-item label="分类：" class="business">
                  <el-radio-group v-model="qaClassify" @change="search()">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'TECHNICALBID'">技术标</el-radio>
                    <el-radio :label="'COMMERCIALBID'">商务标</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24" class="form-btns" align="center">
                <el-button class="btn" type="primary" size="small" @click="search()">搜索</el-button>
                <el-button class="btn" size="small" @click="clear()">清除</el-button>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <div class="list-box">
          <ul v-if="bidQAInfoList.length != 0">
            <li v-for="(a,ind) in bidQAInfoList" :key="ind">
              <div class="header">
                <div class="left">
                  <div class="number">{{total-ind-pageSize*(pageIndex-1)}}</div>
                  <h1><span>主题：</span>{{a.qaTheme}}</h1>
                </div>
                <div class="right">
                  <p>类别：<span>{{a.qaClassify=='TECHNICALBID'?'技术标':'商务标'}}</span></p>
                  <div class="switch hand blue" @click="a.isShowPanel=!a.isShowPanel;isShowPanelChengeOne()">{{a.isShowPanel?'收起':'展开'}} <i class="arrow" :class="{active:!a.isShowPanel}"></i></div>
                </div>
              </div>
              <!-- <transition name="el-zoom-in-top"> -->
              <div class="content" v-show="a.isShowPanel">
                <!-- 问题描述 -->
                <div class="info" v-html="a.qaDescription=a.qaDescription.replace(/\n/g, '<br/>')"></div>
                <div class="dotted-line"></div>
                <!-- 附件 -->
                <div class="annex"><span class="bold">附件：</span>
                  <div v-if="!a.qaAttachInfoList">
                    <p class="annex-file grey">暂无附件</p>
                  </div>
                  <div v-else>
                    <p v-for="(b,ind_b) in a.qaAttachInfoList" :key="ind_b" class="annex-file">{{b.attachName}} <span class="hand blue" @click="handleDownTemp(b.attachName,b.attachUrl)">下载</span></p>
                  </div>
                </div>
                <div class="quiz">
                  <p>提问者：{{a.corpName+' '+a.createAcctName}}</p>
                  <p>提问时间：{{a.publishTime && a.publishTime.substring(0,19)}}</p>
                </div>
              </div>
              <!-- </transition> -->
            </li>
          </ul>
          <!-- 空列表 -->
          <div class="accout-empty" v-else>
            <img src="@/assets/images/icon-no-product.png">
            <p>暂无待回复问题！</p>
          </div>
        </div>
        <div class="table-pagination">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>

    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";

export default {
  components: {
    Loading,
  },
  data() {
    return {
      isLoading: false,

      bidName: '',
      bidNo: '',//	招标编号	
      supplierCorpName: '',
      keyWord: '',
      qaClassify: '',
      isShowPanel: true, // 面板是否展开
      bidQAInfoList: [],//数据列表

      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码
    };
  },
  methods: {
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.buyersCollectQuestions()
      window.scrollTo(0, 0)
    },

    // 采购商问题收集列表
    buyersCollectQuestions() {
      let param = {
        bidNo: this.bidNo, //	招标编号				
        supplierCorpName: this.supplierCorpName, //	供应商名				
        keyWord: this.keyWord, //	关键字				
        pageIndex: String(this.pageIndex),//	页码				
        qaClassify: this.qaClassify, //	问题分类				
        answerStatus: 'UNANSWERED', //	回复状态(配置在pd_product_config，已回复，未回复)				
        publishStatus: '', //	发布状态(配置在pd_product_config，待发布，已发布)				
        qaType: 'PROBLEM', //	问题类型（配置在pd_product_config，问题，公告）	

      }
      InterfaceService.buyersCollectQuestions(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.bidQAInfoList = data.respData.bidQAInfoList || []
          this.bidQAInfoList.forEach(i => {
            this.$set(i, 'isShowPanel', true)
          });
          this.isShowPanel = true
          this.total = data.respData.totoalCount
          this.pageSize = data.respData.pageSize
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 采购商下载问题汇总表
    buyersDownloadQuestion() {
      let param = {
        bidNo: this.bidNo,//	编号				
      }
      InterfaceService.buyersDownloadQuestion(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.handleDownTemp('问题汇总表.xlsx', data.respData.attachUrl)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 文件下载
    handleDownTemp(name, url) {
      console.log(name, url)
      this.$download([{
        name: name,
        url: url
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    isShowPanelChenge() {
      this.bidQAInfoList.forEach(i => {
        this.$set(i, 'isShowPanel', this.isShowPanel)
      });
    },
    // 单点收起展开
    isShowPanelChengeOne() {
      const a = this.bidQAInfoList.filter(i => i.isShowPanel == true)
      if (a.length == 0) {
        this.isShowPanel = false
      } else {
        this.isShowPanel = true
      }
    },
    search() {
      this.pageIndex = 1;
      this.buyersCollectQuestions()
    },
    clear() {
      this.pageIndex = 1;
      this.supplierCorpName = ''
      this.keyWord = ''
      this.qaClassify = ''
      this.buyersCollectQuestions()
    },
    init() {
      if(this.$parent){
        this.$parent.breadcrumb.push({ name: '答疑-问题汇总' })
      }
      this.bidNo = this.$route.query.bidNo || ''
      this.bidName = this.$route.query.bidName || ''
      this.buyersCollectQuestions()
    },
  },
  mounted() {
    this.init()
  },
  props: ['active']
};
</script>

<style lang="scss" scoped>
/deep/ .el-select {
  width: 100% !important;
}
/deep/ .el-form-item__label {
  // font-size: 12px !important;
  padding: 0 !important;
  color: #888 !important;
}
// /deep/ .el-input--small .el-select,
// .el-input--small .el-input__inner {
//   &::placeholder {
//     font-size: 12px !important;
//   }
//   font-size: 12px !important;
// }
/deep/ .seatchW-width {
  width: inherit;
  .el-form-item__content {
    width: 300px;
  }
}
/deep/ .business {
  .el-form-item__label {
    width: 58px !important;
  }
  .el-form-item__content {
    margin-left: 58px !important;
  }
}

/deep/ .samll_label {
  .el-form-item__label {
    width: 70px !important;
  }
  .el-form-item__content {
    margin-left: 70px !important;
  }
}
.w120 {
  width: 120px !important;
}
.line {
  width: 100%;
  height: 1px;
  background-color: #eee;
  margin-top: 30px;
}
.dotted-line {
  width: 100%;
  margin-top: 10px;
  border-bottom: 1px dashed #eee;
}
.buyersCollectQuestions {
  padding-bottom: 60px;
  .list-home {
    width: 1190px;
    margin: 0 auto;
    .box_steps {
      padding: 20px 0 30px;
      box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
    }
    .button-panel {
      .el-col {
        text-align: right;
      }
    }
    .list-content {
      margin: 10px 0;
      .panel-switch {
        width: 100%;
        height: 40px;
        background-color: #f5f5f5;
        padding-right: 10px;
        margin-bottom: 6px;
        display: flex;
        justify-content: space-between;
        > ul {
          height: 100%;
          display: flex;
          li {
            padding: 0 17px;
            font-size: 14px;
            font-weight: 600;
            line-height: 20px;
            color: rgba(49, 49, 49, 1);
            position: relative;
            margin-right: 6px;
            line-height: 40px;
            &.active::before {
              content: "";
              width: 50%;
              height: 3px;
              background: rgba(201, 159, 79, 1);
              position: absolute;
              left: 25%;
              bottom: 4px;
            }
          }
        }
        .switch {
          line-height: 40px;
          .arrow {
            display: inline-block;
            width: 0;
            height: 0;
            border-right: 4px solid transparent;
            border-left: 4px solid transparent;
            border-bottom: 6px solid #0082ff;
            transition: transform 0.3s ease;
            &.active {
              transform-origin: 4px 3px;
              transform: rotate(180deg);
            }
          }
        }
      }
      .panel {
        background: rgba(249, 249, 249, 1);
        padding: 20px 10px 20px 0px;
      }
      .list-box {
        margin-top: 10px;
        > ul {
          li {
            width: 100%;
            margin-bottom: 14px;
            border: 1px solid #ddd;
            &:hover {
              border: 1px solid #c99f4f;
            }
            .header {
              width: 100%;
              height: 40px;
              display: flex;
              justify-content: space-between;
              // border: 1px solid #c99f4f;
              border-bottom: 1px solid #eee;
              padding-right: 10px;
              // &.active {
              //   border-bottom: 1px solid #c99f4f;
              // }
              .left {
                display: flex;
                .number {
                  width: 40px;
                  height: 40px;
                  text-align: center;
                  line-height: 40px;
                  background-color: #c99f4f;
                  font-size: 14px;
                  color: #fff;
                }
                > h1 {
                  font-size: 14px;
                  color: #444;
                  margin-left: 19px;
                  line-height: 40px;
                  > span {
                    font-weight: 700;
                  }
                }
              }
              .right {
                line-height: 40px;
                display: flex;
                > p {
                  font-size: 12px;
                  color: #888;
                  margin-right: 30px;
                  > span {
                    color: #444;
                  }
                }
                .switch {
                  .arrow {
                    display: inline-block;
                    width: 0;
                    height: 0;
                    border-right: 4px solid transparent;
                    border-left: 4px solid transparent;
                    border-bottom: 6px solid #0082ff;
                    transition: transform 0.3s ease;
                    &.active {
                      transform-origin: 4px 3px;
                      transform: rotate(180deg);
                    }
                  }
                }
              }
            }
            .content {
              padding: 10px 10px 19px;
              // border: 1px solid #c99f4f;
              // border-top: none;
              .info {
                font-size: 12px;
                line-height: 17px;
                color: #444;
              }
              .annex {
                margin: 10px 0 20px;
                font-size: 12px;
                color: #444;
                display: flex;
                .annex-file {
                  margin: 0 10px 6px 0;
                  &:last-child {
                    margin-bottom: 0;
                  }
                }
                > span {
                  &.hand.blue {
                    margin-left: 6px;
                  }
                }
              }
              .quiz {
                display: flex;
                justify-content: space-between;
                color: #888;
              }
            }
          }
        }
      }
    }
  }
}
.el-button + .el-button {
  margin-left: 18px;
}
.el-select {
  width: 100%;
}
.btn {
  width: 80px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  padding: 0;
}

.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}

.tab_type {
  background: #f9f9f9;
  margin: 30px 0 10px;
  > ul {
    width: 100%;
    height: 50px;
    border-bottom: 2px solid #ffd64e;
    font-weight: bold;
    > li {
      width: 120px;
      height: 50px;
      line-height: 50px;
      text-align: center;
      float: left;
      position: relative;
      font-size: 14px;
      color: #bbb;
      > p {
        width: 100%;
        height: 48px;
        margin-bottom: 2px;
      }
      &.active {
        > p {
          background-color: #313131;
          color: #fae2a5;
        }
      }
      &.highlight {
        > p {
          color: #888;
          cursor: pointer;
          &:hover {
            color: #fae2a5;
            background-color: #555;
          }
        }
      }
      .chlid-list {
        width: 120px;
        min-height: 50px;
        position: absolute;
        left: 0;
        top: 0;
        z-index: 1;
        > ul {
          display: none;
        }
      }
      .chlid-list {
        &:hover {
          > ul {
            margin-top: 58px;
            position: relative;
            display: block;
            &::after {
              position: absolute;
              left: 10px;
              top: -5px;
              content: "";
              width: 0;
              height: 0;
              border-right: 6px solid transparent;
              border-left: 6px solid transparent;
              border-bottom: 5px solid #313131;
            }
            > li {
              width: 120px;
              height: 48px;
              line-height: 48px;
              text-align: center;
              background-color: #313131;
              color: #fff;
              &.chlid-active {
                background: linear-gradient(
                  0deg,
                  rgba(16, 16, 24, 1) 0%,
                  rgba(90, 88, 88, 1) 100%
                );
                color: #fae2a5;
              }
            }
          }
        }
      }
    }
  }
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
</style>
