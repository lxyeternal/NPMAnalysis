<template>
  <transition name="el-zoom-in-bottom">
    <div class="box" v-show="showBox">
      <div class="addMockList">
        <div class="content">
          <div class="title tc" v-if="mockNo">{{mockList.filter(i=>i.mockNo==mockNo)[0].mockName}}</div>
          <div class="center">
            <el-form class="form" size="small" label-width="76px" @submit.native.prevent>
              <el-row>
                <el-col :span="24">
                  <el-form-item label="商品名称：">
                    <el-input v-model.trim="prodName" @keyup.enter.native="pageIndex=1;getProMockList()" @blur="pageIndex=1;getProMockList()" placeholder="请输入商品名称关键词或型号搜索，输入的关键词越多，搜到的概率越大" clearable @clear="pageIndex=1;getProMockList()"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
            <div>
              <table>
                <thead>
                  <tr>
                    <td width="40px"></td>
                    <td width="50px">序号</td>
                    <td width="240px">商品名称/型号</td>
                    <td width="70px">单位</td>
                    <td class="tc" style="padding-right: 20px">属性</td>
                    <!-- <td width="90px" style="padding-right: 20px" class="tr">操作</td> -->
                  </tr>
                </thead>
                <tbody :class="{'tbody-active':bidProdList.length}">
                  <tr v-for="(a,ind) in bidProdList" :key="ind" class="tbody-row">
                    <td width="40px">
                      <el-checkbox v-model="a.checkBox" @change="checkBoxOne(a)"></el-checkbox>
                    </td>
                    <td width="50px">
                      {{(ind+1)+pageSize*(pageIndex-1)}}
                    </td>
                    <td width="240px">
                      <span class="ellipsisTwo" :title="a.prodName">{{a.prodName}}</span>
                      <span>型号：{{a.model?a.model:'-'}}</span>
                      <div class="tag" v-if="a.combinationProdFlag=='1'">组价商品</div>
                    </td>
                    <td width="70px">{{a.unit}}</td>
                    <td class="tl" :title="a.params"><span>{{a.params || '-'}}</span></td>
                    <!-- <td width="80px" class="tr">
                      <p class="hand blue">商品详情</p>
                    </td> -->
                  </tr>
                </tbody>
              </table>
            </div>
            <!-- 空列表 -->
            <div class="accout-empty" v-if="!bidProdList.length&&!isLoading">
              <img src="@/assets/images/icon-no-product.png">
              <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
            </div>
            <!-- 分页 -->
            <div class="table-pagination" v-if="bidProdList.length">
              <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
              </el-pagination>
            </div>
          </div>
        </div>
        <!-- 按钮 -->
        <div class="foot">
          <el-button type="primary" :disabled="bidProdList.every(i=>!i.checkBox)" :class="{'isDisabled-primary':bidProdList.every(i=>!i.checkBox)}" @click="saveMockList">添加</el-button>
          <el-button @click="showBox = false">取消</el-button>
        </div>
      </div>
    </div>
  </transition>

</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
export default {
  props: ['mockList'],
  data() {
    return {
      isLoading: false,
      total: 0, //分页 总页数
      pageSize: 20, //分页 每页的长度
      pageIndex: 1, //当前页码

      showBox: false,
      bidProdList: [],
      prodName: '',
      bidNo: '',
      mockNo: '',
      delList: [],
      checkList: [], // 新增模拟清单所有勾选的数据
    }
  },
  watch: {
    // 锁定父元素html的滚动
    showBox(val) {
      if (val) {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'hidden', 'important')
      } else {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'scroll', 'important')
      }
    }
  },
  methods: {
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.getProMockList()
    },
    // 单选
    checkBoxOne(a) {
      if (this.delList.length) {
        this.bidProdList.forEach(i => {
          if (i.id != a.id) {
            this.$set(i, 'checkBox', false)
          }
        });
      } else {
        if (a.checkBox) {
          this.checkList.push(a)
        } else {
          this.checkList.splice(this.checkList.findIndex(item => item.id === a.id), 1)
        }
      }
      // console.log(this.bidProdList)
    },
    // 获取清单商品列表
    getProMockList() {
      console.log('getProMockList')
      let param = {
        bidNo: this.bidNo,
        prodName: this.prodName || '',
        pageIndex: this.pageIndex,
      }
      InterfaceService.getProMockList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.bidProdList = data.respData.bidProdList || []
          this.bidProdList.forEach(i => {
            this.$set(i, 'checkBox', false)
            this.checkList.forEach(j => {
              if (i.id == j.id) {
                this.$set(i, 'checkBox', true)
              }
            });
          });
          this.total = data.respData.totalCount
          this.pageSize = Number(data.respData.pageSize)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })

    },
    // 采购商新增模拟清单
    saveMockList() {
      let mockProdList = []
      let list = []
      if (this.delList.length) {
        list = this.bidProdList
      } else {
        list = this.checkList
      }

      list.forEach((i, index) => {
        if (i.checkBox) {
          let params = []
          i.attrList.forEach(j => {
            params.push(j.attrName + '：' + j.attrValue + (j.attrUnit || ''))
          });
          params = params.join('，')
          mockProdList.push({
            mockNo: this.mockNo,
            bidNo: this.bidNo,
            bidProdNo: i.bidProdNo,
            bidProdName: i.prodName,
            prodUnit: i.unit,
            params: params,
            operateType: i.operateType = 'ADD' //ADD:新增；UPDATE:编辑；DELETE:删除
          })
        }
      });
      mockProdList = mockProdList.concat(this.delList)
      console.log(mockProdList)
      let param = {
        mockProdList: mockProdList,
      }
      InterfaceService.saveMockList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('添加成功')
          this.$emit('updateData')
          this.showBox = false
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    open(delList, mockNo) {
      this.bidNo = this.$route.query.bidNo || ''
      this.mockNo = mockNo || ''
      this.delList = delList || []
      this.prodName = ''
      this.pageIndex = 1
      this.bidProdList = []
      this.checkList = []
      this.getProMockList()
      this.showBox = true
    }
  },
  // mounted() {
  //   this.open()
  // },
}
</script>
<style lang="scss" scoped>
.box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .addMockList {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    .content {
      width: 1190px;
      margin: 0 auto;
      font-size: 14px;
      line-height: 17px;
      .title {
        padding: 20px 0;
        border-bottom: 1px solid #eee;
        margin-bottom: 20px;
      }

      table,
      thead,
      tbody {
        display: block;
      }

      thead,
      tbody tr {
        display: table;
        width: 100%;
        table-layout: fixed;
      }
      table {
        margin-top: 2px;
        table-layout: fixed;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        td {
          padding: 14px 10px;
          vertical-align: middle;
          word-break: break-all;
          &:last-child {
            text-align: right;
          }
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          border-bottom: 1px solid #eee;
          background: rgba(249, 249, 249, 1);
          color: rgba(136, 136, 136, 1);
          tr {
            td {
              padding: 15px 10px;
              &:last-child {
                text-align: right;
              }
            }
          }
        }
        .tbody-row {
          &:hover {
            background: #f0f8ff;
          }
        }
        tbody {
          text-align: left;
          &.tbody-active {
            height: 40vh;
            overflow-y: auto;
          }
          tr {
            border-bottom: 1px solid #eee;
            td {
              .tag {
                width: 90px;
                height: 20px;
                background: #6598d3;
                line-height: 20px;
                font-size: 14px;
                color: #fff;
                text-align: center;
                border-radius: 2px;
              }
            }
          }
          .border-none {
            border-bottom: none;
          }
        }
      }
    }
    .foot {
      width: 100%;
      margin-top: 40px;
      height: 57px;
      background: rgba(49, 49, 49, 0.9);
      line-height: 57px;
      text-align: center;
      .el-button {
        width: 120px;
        height: 34px;
        line-height: 34px;
        padding: 0;
        font-size: 12px;
      }
      .el-button--primary {
        color: #fff;
        border: none;
        background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
      }
    }
  }
}
.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
.accout-empty {
  padding: 15vh;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
</style>