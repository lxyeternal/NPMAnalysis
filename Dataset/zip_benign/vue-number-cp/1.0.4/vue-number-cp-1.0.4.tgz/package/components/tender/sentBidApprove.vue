<template>
  <div class="sendPrequalifica">
    <el-dialog class="dialog dialog-drafts" :title="'确认中标审批名单'" :append-to-body="true" :lock-scroll="true" :visible.sync="showRelease" width="850px" center :close-on-click-modal="false" :show-close="false">
      <div class="drafts-list tl">
        <div class="order-info-title bold tl">
          确认拟中标名单
        </div>
        <table class="table">
          <thead>
            <tr>
              <td width="48px">序号</td>
              <td>拟中标名单</td>
            </tr>
          </thead>
          <tbody class="tbody-row">
            <tr v-for="(a,ind) in ibSupplierListInfoList" :key="ind">
              <td>{{ind+1}}</td>
              <td class="blue hand hover-underline" @click="goViewSupplierInfo(a)">{{a.supplierCorpName}}</td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!ibSupplierListInfoList.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>暂无数据！</p>
        </div>
        <div class="table-pagination" v-if="ibSupplierListInfoList.length != 0">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn isDisabled not-allowed" v-if="!ibSupplierListInfoList.length">下一步</div>
        <div class="searchBtn" v-else @click="showRelease=false;showBulletBox1=true;">下一步</div>
        <div class="clearBtn" @click="showRelease=false">取消</div>
      </div>
    </el-dialog>
    <!-- 提交招标文件审批 -->
    <el-dialog custom-class="dialog-box" :title="'审批通过凭证'" :append-to-body="true" :lock-scroll="true" :visible.sync="showBulletBox1" width="840px" center :close-on-click-modal="false" @close="close()">
      <div class="drafts-list tl">
        <el-form class="form" size="small" label-width="100px" :model="form" :rules="rules" ref="formBulletBox1">
          <p class="f12 tc">请上传OA中标审批通过凭证附件。</p>
          <el-row>
            <el-col :span="24">
              <el-form-item label="OA流程编号：" prop="approveId">
                <el-input placeholder="请输入中标审批编号" v-model="form.approveId" clearable maxlength="32"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <div class="uploadFileList">
            <div class="title-info tl">
              <p>OA中标审批通过凭证</p><span class="hand blue" @click="$refs.upfileRef.open()">上传</span>
            </div>
            <div class="fileList">
              <p class="noData" v-if="form.files.length == 0">未上传附件！</p>
              <p v-for="(item,ind_t) in form.files" :key="ind_t+'files'">{{item.attachName}}<span class="hand blue" @click="handleView(item.attachUrl)">预览</span><span class="hand blue" @click="handleDownTemp(item.attachName,item.attachUrl)">下载</span><span class="hand blue" @click="delFiles(form.files,ind_t)">删除</span></p>
            </div>
          </div>
        </el-form>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="submit()">确认提交</div>
        <div class="clearBtn" @click="showBulletBox1=false;showRelease=true;close()">上一步</div>
      </div>
    </el-dialog>
    <!-- 上传附件 -->
    <UpfileComponent ref="upfileRef" :immediateClearList="true" :btnName="'选择文件'" :dirName="`${new Date().getTime()}/`" :type="'36'" :fileTypes="''" @outputList="handleUpFileResult($event)"></UpfileComponent>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import UpfileComponent from "@/components/tender/upfileComponent";
import { viewFile } from '@/utils/orderUtil';
export default {
  components: {
    Loading,
    UpfileComponent
  },
  data() {
    return {
      isLoading: false,
      ibSupplierListInfoList: [],
      bidNo: '',
      showRelease: false,
      showBulletBox1: false,
      form: {
        files: [],
        approveId: '',
      },
      rules: {
        approveId: [
          { required: true, message: '必填', trigger: 'blur' }
        ],
      },
      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码
      
    }
  },
  methods: {
    goViewSupplierInfo(a) {
      window.open(this.$router.resolve({
        path: "/viewSupplierInfo",
        query: { corpId: a.supplierCorpId, bidNo: a.bidNo, submitBidNo: a.submitBidNo }
      }).href, '_blank')
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.buyersShortlistedSupplier()
      //   window.scrollTo(0, 0)
    },
    // 确认中标审批名单
    buyersShortlistedSupplier() {
      let param = {
        bidNo: this.bidNo,
        confirmFlag: '1',
        pageSize: this.pageSize,
        pageIndex: this.pageIndex,
      }
      InterfaceService.buyersShortlistedSupplier(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.ibSupplierListInfoList = data.respData.ibSupplierListInfoList || []
          this.pageSize = data.respData.pageSize || 10
          this.total = data.respData.totoalCount
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 提交oa审批
    submit() {
      this.$refs['formBulletBox1'].validate((valid) => {
        if (valid) {
          let approveAcctName = this.$store.state.userInfo.acctName || ''
          let approveAttachInfos = []

          this.form.files.forEach(i => {
            approveAttachInfos.push({
              attachPath: i.fileUrl,
              attachName: i.attachName,
              attachType: i.attachType,
            })
          });

          let param = {
            bidNo: this.bidNo,
            approveId: this.form.approveId,
            approveAcctName: approveAcctName,
            approveType: '3',//1-资格预审，2-发标，3-中标
            approveAttachInfos: approveAttachInfos,
            approveName:'', // 审批名称

          }
          InterfaceService.submitOaApprove(param, data => {
            this.isLoading = false;
            if (data && data.respData && data.respData.respCode === "0000") {
              this.$message.success('上传OA资格预审入围名单审批通过凭证成功')
              this.showBulletBox1 = false
              this.$emit('getData')
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        } else {
          console.log('error submit!!');
          return false
        }
      });

    },
    // 获取其他附件数据
    handleUpFileResult(e) {
      // this.delFileInfo()
      const { file, name, targetValue, url, allUrl, id } = e[0]
      let authorizationInfo = {
        attachName: name,
        attachUrl: allUrl,
        fileUrl: url,
        attachType: '38',
      }
      this.form.files.push(authorizationInfo)
    },
    // 文件下载
    handleDownTemp(name, url) {
      console.log(name, url)
      this.$download([{
        name: name,
        url: url
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 在线预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    // 文件删除
    delFiles(list, index) {
      // if (list[index].ossFileId) {
      //   this.delFileList.push(list[index].ossFileId)
      // }
      list.splice(index, 1)
      this.$message.success('已删除')
    },
    close() {
      this.$refs['formBulletBox1'].resetFields();
      this.form.files = []
    },
    open(bidNo) {
      this.bidNo = bidNo
      this.buyersShortlistedSupplier()
      this.showRelease = true
    }
  },
}
</script>
<style lang="scss" scoped>
.order-info-title {
  margin-top: 6px !important;
}
.table {
  table-layout: fixed;
  width: 810px;
  line-height: 23px;
  font-size: 12px;
  td {
    padding: 14px 10px;
    vertical-align: middle;
    word-break: break-all;
  }

  thead {
    font-size: 14px;
    text-align: left;
    white-space: nowrap;
    border-bottom: 1px solid #eee;
    background: rgba(249, 249, 249, 1);
    color: rgba(136, 136, 136, 1);
    tr {
      td {
        padding: 4px 10px;
      }
    }
  }

  tbody {
    text-align: left;
    tr {
      border-bottom: 1px solid #eee;
      &:hover {
        background: #f0f8ff;
      }
    }
  }
}
.accout-empty {
  padding: 100px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
.searchbox {
  text-align: center;
  margin-top: 20px;
  display: flex;
  justify-content: center;
  .searchBtn {
    width: 120px;
    height: 34px;
    line-height: 34px;
    background: linear-gradient(
      122deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(255, 255, 255, 1);
    display: inline-block;
    cursor: pointer;
  }
  .clearBtn {
    width: 120px;
    margin-left: 20px;
    height: 34px;
    line-height: 32px;
    border: 1px solid rgba(201, 159, 79, 1);
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(201, 159, 79, 1);
    display: inline-block;
    cursor: pointer;
  }
}
// 对话框
/deep/ .dialog-box {
  .el-dialog__body {
    padding-bottom: 0 !important;
  }
  .el-dialog__footer {
    padding: 20px;
  }
  .el-form-item--small.el-form-item {
    margin-bottom: 30px !important;
  }
  .drafts-list {
    .f12.tc {
      margin-bottom: 18px;
    }
  }
  .uploadFileList {
    margin: 0;
    > .title-info {
      font-size: 14px;
      line-height: 20px;
      color: rgba(68, 68, 68, 1);
      > p {
        margin: 0 6px 6px 0;
        display: inline-block;
      }
      > span {
        font-size: 12px;
        margin-right: 10px;
      }
    }
    .fileList {
      width: 100%;
      border: 1px solid rgba(221, 221, 221, 1);
      padding: 0 10px 14px 10px;
      margin-bottom: 0;
      > p {
        margin-top: 14px;
        font-size: 12px;
        line-height: 17px;
        color: rgba(68, 68, 68, 1);
        &.noData {
          color: #bbb;
        }
        > span {
          margin-right: 10px;
          &:first-child {
            margin-left: 6px;
          }
        }
      }
    }
  }
  .searchbox {
    text-align: center;
    margin-top: 20px;
    display: flex;
    justify-content: center;
    .searchBtn {
      width: 120px;
      height: 34px;
      line-height: 34px;
      background: linear-gradient(
        122deg,
        rgba(215, 176, 100, 1) 0%,
        rgba(236, 206, 139, 1) 100%
      );
      font-size: 12px;
      font-family: PingFang SC;
      color: rgba(255, 255, 255, 1);
      display: inline-block;
      cursor: pointer;
    }
    .clearBtn {
      width: 120px;
      margin-left: 20px;
      height: 34px;
      line-height: 32px;
      border: 1px solid rgba(201, 159, 79, 1);
      font-size: 12px;
      font-family: PingFang SC;
      color: rgba(201, 159, 79, 1);
      display: inline-block;
      cursor: pointer;
    }
  }
}
</style>