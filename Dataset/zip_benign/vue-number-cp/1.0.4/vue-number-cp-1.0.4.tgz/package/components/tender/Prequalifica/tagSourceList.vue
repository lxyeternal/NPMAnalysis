<template>
  <div class="tagSourceList" v-show="list.length">
    <div class="tag hand" v-for="(a,index) in list" :key="index+'tag'" :class="{'active':!!a.tagSup}" @mouseenter="hover(a,'enter')" @mouseleave="hover(a,'leave')" @click="tagClick(a)">{{a.tagName}}
      <div class="remarkBox" v-if="a.showRemark" v-click-outside="closeDialog">
        <div class="box">
          <div class="left">
            <el-input type="textarea" :disabled="a.disabled" v-model="a.tagSup" maxlength="52" @blur="editMemberTag(a,'1')">
            </el-input>
          </div>
          <div class="right" @click.stop="a.showOperat = !a.showOperat">
            <i></i><i></i><i></i>
            <div class="operat" v-show="a.showOperat">
              <p class="blue f12 hand" style="margin-bottom: 5px" @click.stop="a.disabled = false;a.showOperat = false;autoFocus($event)">编辑备注</p>
              <p class="blue f12 hand" @click.stop="a.showOperat = false;delTagSource(a)">删除标记来源</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
const clickOutside = {
  // 初始化指令
  bind(el, binding) {
    function clickHandler(e) {
      // 这里判断点击的元素是否是本身，是本身，则返回
      if (el.contains(e.target)) {
        return false;
      }
      // 判断指令中是否绑定了函数
      if (binding.expression) {
        // 如果绑定了函数 则调用那个函数，此处binding.value就是handleClose方法
        binding.value(e);
      }
    }
    // 给当前元素绑定个私有变量，方便在unbind中可以解除事件监听
    el.__vueClickOutside__ = clickHandler;
    document.addEventListener('click', clickHandler);
  },
  update() { },
  unbind(el, binding) {
    // 解除事件监听
    document.removeEventListener('click', el.__vueClickOutside__);
    delete el.__vueClickOutside__;
  },
};

export default {
  directives: { clickOutside },
  components: {
    Loading,
  },
  props: {
    corpTagList: {
      type: Array,
      default: () => []
    },
  },
  watch: {
    corpTagList: {
      handler(val, oldVal) {
        this.init();
      },
      immediate: true
    }
  },
  data() {
    return {
      list: [],
      isClick: false,
      bidNo: '',
    }
  },
  methods: {
    closeDialog(val) {
      console.log(val)
      let a = this.list.some(i => i.showRemark)
      console.log(a)
      if (this.isClick && a) {
        this.list.forEach(i => {
          this.$set(i, 'showRemark', false)
          this.$set(i, 'disabled', true)
          this.$set(i, 'showOperat', false)
        })
        this.isClick = false
      }

    },
    tagClick(a) {
      setTimeout(() => {
        this.isClick = true; a.showRemark = true;
      }, 200);
      //  
    },
    hover(a, type) {
      if (!this.isClick && !!a.tagSup) {
        type == 'enter' ? a.showRemark = true : a.showRemark = false
      }
    },
    autoFocus(e) {
      console.log(e)
    },
    init() {
      this.list = this.$clone(this.corpTagList || []);
      this.list.sort((a, b) => {
        return a.step - b.step;
      });
    },
    // 删除标记来源
    delTagSource(a) {
      this.$confirm(
        '是否确认删除“' + a.tagName + '”？',
        '删除标记来源 ',
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          type: 'warning',
          confirmButtonText: "确认删除",
          cancelButtonText: '取消',
        }).then(() => {
          this.editMemberTag(a, '0')
        }).catch(() => {
        });
    },
    // 批量编辑或删除会员标签
    editMemberTag(a, processFlg) {
      let corpTagList = [
        {
          id: a.id || '1',//	会员标签表的主键		
          corpId: a.corpId,//	公司ID
          tagSup: a.tagSup,//	标签名补充内容				
          tagId: a.tagId,//	标签ID		
          // enjoyStartDt: '',//	享有标签开始日（YYYY-MM-DD HH:MM:SS）		
          // enjoyEndDt: '',//	享有标签结束日（YYYY-MM-DD HH:MM:SS）
          processFlg: processFlg,//	处理标志(0：删除；1：更新)
          bidNo: this.bidNo,
        }
      ]
      let param = {
        corpTagList: corpTagList
      }
      InterfaceService.editMemberTag(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success(processFlg == '0' ? '删除成功' : '编辑成功')
          // this.showRelease = false
          // 初始化
          a.showRemark = false
          a.showOperat = false
          a.disable = true

          this.$emit('getData')
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  },
  mounted() {
    this.bidNo = this.$route.query.bidNo || ''
  },
}
</script>
<style lang="scss" scoped>
.tagSourceList {
  display: inline-block;
  .tag {
    width: 100px;
    height: 20px;
    line-height: 20px;
    text-align: center;
    color: #fff;
    font-size: 14px;
    // margin-right: 5px;
    display: inline-block;
    background-color: #776c89;
    position: relative;
    margin: 5px 5px 0 0;
    &.active {
      &::after {
        content: "";
        position: absolute;
        right: -4px;
        top: -1px;
        width: 0;
        height: 0;
        border-right: 6px solid transparent;
        border-left: 6px solid transparent;
        border-bottom: 6px solid #ff7d1d;
        transform: rotate(45deg);
      }
    }
    // 备注框
    .remarkBox {
      position: absolute;
      left: 105px;
      top: -5px;
      background: rgba(49, 49, 49, 1);
      box-shadow: 0px 0px 4px rgba(0, 0, 0, 0.16);
      z-index: 1;
      // display: none;
      .box {
        display: flex;
        .left {
          width: 160px;
          /deep/ .el-textarea__inner {
            background-color: transparent;
            color: #fff;
            padding: 5px;
            min-height: 80px !important;
          }
        }
        .right {
          width: 20px;
          padding-top: 10px;
          position: relative;
          i {
            width: 4px;
            height: 4px;
            background-color: #fff;
            border-radius: 4px;
            display: block;
            margin: 0 0 2px 10px;
          }
          .operat {
            background-color: #fff;
            padding: 0 5px;
            position: absolute;
            width: 100px;
            right: 0;
            top: 30px;
            > p {
              line-height: 17px;
            }
          }
        }
      }
    }
  }
}
</style>