<template>
  <!-- 对账/预付明细（预付款/进度款与结算款） -->
  <div class="detailsTable">
    <el-row style="margin: -10px 0px">
      <el-col :span="12">
        <el-checkbox style="padding-left: 20px" v-model="checkedAll" :disabled="!notSubmitList.length || notSubmitList.every(i=> i.disabled)" @change="handleCheckedAll">全选</el-checkbox>
      </el-col>
      <el-col :span="12">
        <p class="f12 grey tr">※以下表单金额均为含税金额。</p>
      </el-col>
    </el-row>
    <TableThead :TopDistance="660" Height="80">
      <tr slot="tr">
        <td width="68px" class="checkbox">序号</td>
        <td width="120px">预付款/对账单编号</td>
        <td width="133px" class="tr">要货/收货金额<br>(含税)(元)</td>
        <td width="190px" class="tr">不含本次<br>累计应付款(含税)(元)</td>
        <td :width="['1','2'].includes(applyPayType) ? '160px':'180px'" class="tr">本次应付比例</td>
        <td width="190px" class="tr">本次应付款<br>(含税)(元)</td>
        <td width="190px" class="tr">含本次累计应付款<br>(含税)(元)</td>
        <td width="120px" class="tl">含本次累计应付<br>不能大于<br>对账/预付金额</td>
      </tr>
    </TableThead>
    <table class="table-default">
      <thead>
        <tr>
          <td width="68px" class="checkbox">序号</td>
          <td width="120px">预付款/对账单编号</td>
          <td width="133px" class="tr">要货/收货金额<br>(含税)(元)</td>
          <td width="190px" class="tr">不含本次<br>累计应付款(含税)(元)<br>
            <el-popover popper-class="dark-popover" trigger="hover" placement="top">
              <div style="color: #fff;width: 185px;">
                <template v-if="applyPayType === '0'">不含本次累计应付款(含税)(元)=已发起付款申请的本对账单申请金额合计数-预付款差额(若有)</template>
                <template v-else>不含本次累计应付款(含税)(元)=已发起付款申请的本对账单申请金额合计数-预付款金额</template>
              </div>
              <i slot="reference" style="display: inline-block;width: 14px;text-align: center;height: 14px;line-height: 14px;background: linear-gradient(180deg, #101018 0%, #5A5858 100%);border-radius: 50%;color: #fff">?</i>
            </el-popover>
          </td>
          <td :width="['1','2'].includes(applyPayType) ? '160px':'180px'" class="tr">本次应付比例<br>
            <el-popover popper-class="dark-popover" trigger="hover" placement="top">
              <div style="color: #fff;width: 185px;">
                <template v-if="applyPayType === '0'">本次应付比例请参考上方「合同基本信息」模块的「合同付款」方式填写。</template>
                <template v-else>本次应付款比例=本次应付款➗对账金额/要货金额</template>
              </div>
              <i slot="reference" style="display: inline-block;width: 14px;text-align: center;height: 14px;line-height: 14px;background: linear-gradient(180deg, #101018 0%, #5A5858 100%);border-radius: 50%;color: #fff">?</i>
            </el-popover>
          </td>
          <td width="190px" class="tr">本次应付款<br>(含税)(元)<br>
            <el-popover popper-class="dark-popover" trigger="hover" placement="top">
              <div style="color: #fff;width: 185px;">
                <template v-if="applyPayType === '0'">本次应付款(含税)(元)=要货金额/对账单金额*本次应付比例-预付款差额(若有)</template>
                <template v-else>填写本次应付的结算金额</template>
              </div>
              <i slot="reference" style="display: inline-block;width: 14px;text-align: center;height: 14px;line-height: 14px;background: linear-gradient(180deg, #101018 0%, #5A5858 100%);border-radius: 50%;color: #fff">?</i>
            </el-popover>
          </td>
          <td width="190px" class="tr">含本次累计应付款<br>(含税)(元)<br>
            <el-popover popper-class="dark-popover" trigger="hover" placement="top">
              <div style="color: #fff;width: 185px;">
                含本次累计应付款(含税)(元)=不含本次累计应付款(含税)(元)+本次应付款(含税)(元)
              </div>
              <i slot="reference" style="display: inline-block;width: 14px;text-align: center;height: 14px;line-height: 14px;background: linear-gradient(180deg, #101018 0%, #5A5858 100%);border-radius: 50%;color: #fff">?</i>
            </el-popover>
          </td>
          <td width="120px" class="tl">含本次累计应付<br>不能大于<br>对账/预付金额</td>
        </tr>
      </thead>
      <tbody v-for="(item,ind) in notSubmitList" :key="ind+'notSubmitList'">
        <tr class="tr">
          <td>
            <el-checkbox @change="handleSelectTableRow(item,ind)" :disabled="item.disabled" v-model="item.checked"></el-checkbox>
            {{ind + 1}}
          </td>
          <td>
            <p class="blue-pointer tl" style="white-space: nowrap" @click="handleAdvancePaymentRequesDetail(item)">{{item.statementNo}}</p>
            <p class="grey" style="white-space: nowrap" v-if="item.statementDate && item.statementType === '2'">账单期间：{{item.statementDate}}</p>
            <p class="clearfloat">
              <span class="purple fl">{{item.statementType === '1' ? '预付款' : '对账单'}}</span>
              <span class="yellow fr" v-if="['oaApproveSucc'].includes(item.statementStatus)">已审核</span>
              <span class="yellow fr" v-else>审核中</span>
            </p>
          </td>
          <!-- 要货/收货金额 -->
          <td class="tr">
            {{item.statementAmoutWithTax | formatMoney}}
          </td>
          <!-- 不含本次 累计应付款(含税)(元) -->
          <td class="tr">
            <p>{{item.totalExcludCurAmount | formatMoney}}</p>
            <p v-if="item.totalExcludCurApplyAmount" class="red">(含审核中金额：{{item.totalExcludCurApplyAmount | formatMoney}})</p>
            <SubsistTable v-if="item.statementType === '2' && item.totalExcludCurDeductAmount && ['oaApproveSucc'].includes(item.statementStatus) && item.statementPercent" :applyCreateDt="applyCreateDt" :text="`(扣除预付款差额：${item.totalExcludCurDeductAmount})`" :index="ind" :dataList="item.totalExcludCurDeductAmountInfo"></SubsistTable>
          </td>
          <!-- 本次应付比例 -->
          <td class="tr">
            <template v-if="applyPayType === '0'">
              <p v-if="item.statementPercent" class="orange-color" style="white-space: nowrap">※已申请{{item.statementPercent}}%</p>
              <template v-if="!['oaApproveSucc'].includes(item.statementStatus)">-</template>
              <template v-else>
                <el-input class="table-input" v-model="item.applyPayPrent" :maxlength="3" @input="handleApplyPayPrentCheck(item, 'applyPayPrent', ind)" :placeholder="item.statementType === '1' ? `最高可填${handlePrepaymentRatio(item)}%` : '请输入数字'">
                  <div slot="suffix" class="suffix">%</div>
                </el-input>
              </template>
              <p class="red tl" style="position: absolute;" v-if="item.error">{{item.error}}</p>
            </template>
            <p v-else>{{handleApplyPayPrent(item) + '%'}}</p>
          </td>
          <!-- 本次应付款<br>(含税)(元) -->
          <td class="tr">
            <template v-if="applyPayType === '0'">
              <p>{{handleApplyPayAmmount(item)}}</p>
              <SubsistTable v-if="item.statementType === '2' && item.totalExcludCurDeductAmount && item.applyPayPrent && ['oaApproveSucc'].includes(item.statementStatus) && !item.statementPercent" :applyCreateDt="applyCreateDt" :text="`(扣除预付款差额：${item.totalExcludCurDeductAmount})`" :index="ind" :dataList="item.totalExcludCurDeductAmountInfo"></SubsistTable>
              <!-- <p v-if="item.statementType === '2' && item.totalExcludCurDeductAmount && item.applyPayPrent && ['oaApproveSucc'].includes(item.statementStatus) && !item.statementPercent" class="hand"><span class="red">{{`(扣除预付款差额：${item.totalExcludCurDeductAmount})`}}</span></p> -->
            </template>
            <!-- 结算款、质保金 -->
            <template v-if="['1','2'].includes(applyPayType)">
              <p v-if="!['oaApproveSucc'].includes(item.statementStatus)">-</p>
              <el-input v-else class="table-input" v-model="item.applyPayAmmount" :maxlength="handleMaxlength(item, 'applyPayAmmount')" @input="checkNumber(item, 'applyPayAmmount', ind)" placeholder="请输入金额" clearable></el-input>
            </template>
          </td>
          <!-- 含本次累计应付款<br>(含税)(元) -->
          <td>
            <p>{{handleTotalIncludCurAmount(item)}}</p>
            <!-- <template v-if="applyPayType === '0'"> -->
              <p v-if="item.totalIncludCurApplyAmount" class="red">(含审核中金额：{{item.totalIncludCurApplyAmount | formatMoney}})</p>
              <SubsistTable v-if="item.statementType === '2' && item.totalIncludCurDeductAmount && (item.statementPercent || (!item.statementPercent && item.applyPayPrent)) && ['oaApproveSucc'].includes(item.statementStatus)" :applyCreateDt="applyCreateDt" :text="`(扣除预付款差额：${item.totalIncludCurDeductAmount})`" :index="ind" :dataList="item.totalIncludCurDeductAmountInfo"></SubsistTable>
            <!-- </template> -->
          </td>

          <td class="tl">{{item.isApplyOver}}</td>
        </tr>
        <!-- 预付款/进度款 -->
        <tr style="border-bottom: 1px solid #eee">
          <td colspan="8" style="padding:0px" v-if="item.isRelated && !item.applyPayPrent && applyPayType === '0'">
            <div class="box_type">
              <p>本{{item.statementType === '1' ? '预付款单' : '对账单'}}与你勾选的{{item.statementType === '1' ? '对账单' : '预付款单'}}（{{statementNo}}）有关联，请一并填写并发起申请！</p>
            </div>
          </td>
          <td colspan="8" style="padding:0px" v-if="item.isRelated && !item.applyPayAmmount && applyPayType !== '0'">
            <div class="box_type">
              <p>本{{item.statementType === '1' ? '预付款单' : '对账单'}}与你勾选的{{item.statementType === '1' ? '对账单' : '预付款单'}}（{{statementNo}}）有关联，请一并填写并发起申请！</p>
            </div>
          </td>
          <td colspan="8" style="padding:0px" v-if="applyPayType != '0' && +item.applyPayAmmount > +item.statementAmoutWithTax">
            <div class="box_type">
              <p>本账单含本次累计应付款不能大于要货/收货金额，请调整本次应付款！</p>
            </div>
          </td>
        </tr>
      </tbody>
      <!-- 已提交申请的请款单 -->
      <tbody v-if="submitList.length">
        <tr>
          <td colspan="8" class="grey tc">
            —— 以下是已提交申请的账单 ——
          </td>
        </tr>
        <tr v-for="(item,ind) in submitList" :key="ind+'submitList'">
          <td class="tr">
            {{notSubmitList.length + ind + 1}}
          </td>
          <td>
            <p class="blue-pointer" style="white-space: nowrap" @click="handleAdvancePaymentRequesDetail(item)">{{item.statementNo}}</p>
            <p class="grey" style="white-space: nowrap" v-if="item.statementDate && item.statementType === '2'">账单期间：{{item.statementDate}}</p>
            <p class="clearfloat">
              <span class="purple fl">{{item.statementType === '1' ? '预付款' : '对账单'}}</span>
              <span class="yellow fr" v-if="['oaApproveSucc'].includes(item.statementStatus)">已审核</span>
              <span class="yellow fr" v-else>审核中</span>
            </p>
          </td>
          <td class="tr">
            {{item.statementAmoutWithTax | formatMoney}}
          </td>
          <td class="tr">
            <p>{{item.totalExcludCurAmount | formatMoney}}</p>
            <p v-if="item.totalExcludCurApplyAmount" class="red">(含审核中金额：{{item.totalExcludCurApplyAmount | formatMoney}})</p>
          </td>
          <td class="tr">-</td>
          <td class="tr">-</td>
          <td class="tr">
            <p>{{item.totalIncludCurAmount | formatMoney}}</p>
            <p v-if="item.totalIncludCurApplyAmount" class="red">(含审核中金额：{{item.totalIncludCurApplyAmount | formatMoney}})</p>
          </td>
          <td class="tl">{{item.isApplyOver}}</td>
        </tr>
      </tbody>
      <!-- 累计 -->
      <tbody>
        <tr class="total">
          <td colspan="2" style="padding: 0px">
            <div class="total-text">合计</div>
          </td>
          <td>{{handleTotalStatementAmoutWithTax(dataList, 'statementAmoutWithTax')}}
            <el-popover popper-class="dark-popover" trigger="hover" placement="top">
              <div style="color: #fff;width: 185px;">
                对账单累计收货金额（生成对账单的预付款单金额不计入，仅计算验收单金额）+要货金额（未生成对账单的预付款单）
              </div>
              <i slot="reference" style="display: inline-block;width: 14px;text-align: center;height: 14px;line-height: 14px;background: linear-gradient(180deg, #101018 0%, #5A5858 100%);border-radius: 50%;color: #fff">?</i>
            </el-popover>
          </td>
          <td>{{handleTotal(dataList, 'totalExcludCurAmount')}}</td>
          <td></td>
          <td>{{handleTotal(dataList, 'applyPayAmmount')}}</td>
          <td>{{handleTotal(dataList, 'totalIncludCurAmount')}}</td>
          <td></td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import TableThead from "@/components/base/TableThead";
import SubsistTable from "@/components/paymentRequest/SubsistTable";
import { NumberUtil } from '@/utils/numberUtil';
import { MoneyUtil } from '@/utils/moneyUtil';

export default {
  name: "detailsTable",
  components: {
    Loading, TableThead, SubsistTable
  },
  props: ['applyPayType', 'applyPayDetalInfos', 'applyPayNo', 'applyCreateDt'], //applyPayType 0:预付款/进度款 ,1结算款, 2质保金
  data() {
    return {
      isLoading: false,

      checkedAll: false,
      dataList: [],
      statementNo: '',
    }
  },
  computed: {
    notSubmitList() {
      return this.dataList.filter(i => i.prepaymentRatio !== i.statementPercent || i.statementType == '2')
    },
    submitList() {
      return this.dataList.filter(i => i.prepaymentRatio === i.statementPercent && i.statementType != '2')
    },
    // 计算可申请的最高比例
    handlePrepaymentRatio() {
      return (item) => {
        let num = 0
        num = NumberUtil.numSub(item.prepaymentRatio, (item.statementPercent || 0))
        return num
      }
    },
    // 计算本次应付款(含税)(元)
    handleApplyPayAmmount() {
      return (item) => {
        let num = ''
        num = NumberUtil.accMul((+(item.applyPayPrent || 0)) / 100, +item.statementAmoutWithTax)
        if (this.applyPayType === '0' && item.statementType === '2' && !item.statementPercent && item.applyPayPrent) {
          num = NumberUtil.numSub(num, +item.totalExcludCurDeductAmount)
        }
        num = MoneyUtil.moneyFixed(num, 2)
        item.applyPayAmmount = num
        return NumberUtil.formatMoney(num)
      }
    },
    // 计算含本次累计应付款(含税)(元)(不含本次累计应付款(含税)(元)+本次应付款(含税)(元))
    handleTotalIncludCurAmount() {
      return (item) => {
        let num = ''
        num = NumberUtil.numAdd(+(item.totalExcludCurAmount || 0), +item.applyPayAmmount)
        // if (this.applyPayType === '0' && item.statementType === '2') {
        //   num = NumberUtil.numSub(num, +item.applyPayDeductAmmount)
        // }
        num = MoneyUtil.moneyFixed(num, 2)
        item.totalIncludCurAmount = num
        return NumberUtil.formatMoney(num)
      }
    },
    // 结算款质保金 计算本次应付比例
    handleApplyPayPrent() {
      return (item) => {
        let num = ''
        num = (NumberUtil.divide(+(item.applyPayAmmount || 0), +item.statementAmoutWithTax))
        num = NumberUtil.accMul(num, 100)
        num = MoneyUtil.moneyFixed(num, 2)
        item.applyPayPrent = num
        // console.log(num)
        return NumberUtil.formatMoney(num)
      }
    },
  },
  watch: {
    applyPayDetalInfos: {
      handler(n) {
        if (n.length) {
          this.dataList = this.$clone(n).sort((b, a) => { return b.index - a.index })
          this.dataList.forEach(i => {
            this.$set(i, 'error', '')
            this.$set(i, 'checked', false)
            this.$set(i, 'disabled', false)
            this.$set(i, 'isRelated', false)
            this.handlePercentageMultiply(i, 'statementPercent')
            this.handlePercentageMultiply(i, 'prepaymentRatio')
            this.handlePercentageMultiply(i, 'applyPayPrent')
            if (!['oaApproveSucc'].includes(i.statementStatus)) {
              this.$set(i, 'disabled', true)
            }
            if (!i.disabled && i.isCheck == '1') {
              this.$set(i, 'checked', true)
            }
            if (i.totalExcludCurDeductAmountInfo) {
              this.$set(i, 'totalExcludCurDeductAmountInfo', JSON.parse(i.totalExcludCurDeductAmountInfo))
            }
            if (i.applyPayDeductAmmountInfo) {
              this.$set(i, 'applyPayDeductAmmountInfo', JSON.parse(i.applyPayDeductAmmountInfo))
            }
            if (i.totalIncludCurDeductAmountInfo) {
              this.$set(i, 'totalIncludCurDeductAmountInfo', JSON.parse(i.totalIncludCurDeductAmountInfo));
              (i.totalIncludCurDeductAmountInfo || []).forEach(j => {
                this.$set(j, 'totalApplyPercentOld', j.totalApplyPercent)
              })
            }
          });
          console.log(this.dataList)
        }
        this.isCheckedAll()
      },
      immediate: true,
    },
    checkedAll(n, o) {
      this.$parent.checkedAll = n
    },
    dataList: {
      handler(n) {
        this.$emit('getDetailsTableList', n)
      },
      immediate: true,
      deep: true,
    }
  },
  methods: {
    handleAdvancePaymentRequesDetail(item) {
      const orderNo = this.$route.query.orderNo
      window.open(this.$router.resolve({
        path: item.statementType === '1' ? "/advancePaymentRequesDetail" : "statementDeclaredDetai",
        query: {
          orderNo: orderNo,
          statementNo: item.statementNo || '',
        }
      }).href, '_blank')
    },
    handleMaxlength(item, value) {
      return item[value] && String(item[value]).indexOf('.') != -1 ? 13 : 10
    },
    // 负数，正数，小数保留两位
    checkNumber(item, itemValue, ind) {
      // item[itemValue] = item[itemValue].match(/\d+(\.\d{0,2})?/) ? item[itemValue].match(/\d+(\.\d{0,2})?/)[0] : ''
      let result = item[itemValue]
      result = result.replace(/[^\d.-]/g, ""); //清除"数字"和"."以外的字符
      result = result.replace(/^\./g, ""); //验证第一个字符是数字
      result = result.replace(/\.{2,}/g, "."); //只保留第一个, 清除多余的
      // result = result.replace(/-{2,}/g,""); //只保留第一个, 清除多余的
      if (result.length > 1 && result[result.length - 1] == '-') {
        result = result.substring(0, result.length - 1)
      }
      result = result.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
      result = result.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); //控制可输入的小数
      item[itemValue] = result
      if (itemValue === 'applyPayAmmount') {
        // 填写数值默认勾选
        if (item[itemValue] && !item.checked) {
          item.checked = true
          this.handleSelectTableRow(item, ind)
        }
      }
    },
    // 处理本次应付比例
    handleApplyPayPrentCheck(item, itemValue, ind) {
      item[itemValue] = item[itemValue].replace(/\D/g, '')
      // 填写数值默认勾选
      if (item[itemValue] && !item.checked) {
        item.checked = true
        this.handleSelectTableRow(item, ind)
      }

      if (item.statementType === '1') {
        if (item.prepaymentRatio - item.statementPercent - item[itemValue] < 0) {
          item.error = '请填写合同约定可申请比例'
          item[itemValue] = ''
        } else {
          item.error = ''
          // 对账单中 预付款差额计算
          // if (item.statementAccount && this.applyPayType === '0') {
          //   this.notSubmitList.forEach(i => {
          //     if (i.statementNo == item.statementAccount && ['oaApproveSucc'].includes(i.statementStatus)) {
          //       // 本次对账单对应的预付款信息
          //       this.updateSubsist(i.applyPayDeductAmmountInfo, 'applyPayDeductAmmountInfo', item, itemValue)
          //       const applyPayDeductAmmount = this.difference(i.applyPayDeductAmmountInfo || [])
          //       console.log(applyPayDeductAmmount)
          //       this.$set(i, 'applyPayDeductAmmount', applyPayDeductAmmount)
          //       // // 含本次累计应付款含税（元）（扣除预付差额）详情信息
          //       this.updateSubsist(i.totalIncludCurDeductAmountInfo, 'totalIncludCurDeductAmountInfo', item, itemValue)
          //       const totalIncludCurDeductAmount = this.difference(i.totalIncludCurDeductAmountInfo || [])
          //       this.$set(i, 'totalIncludCurDeductAmount', totalIncludCurDeductAmount)
          //     }
          //   })
          // }
          // console.log(this.notSubmitList)
        }
      } else {
        if (100 - item.statementPercent - item[itemValue] < 0) {
          item.error = '请填写合同约定可申请比例'
          item[itemValue] = ''
        } else {
          item.error = ''
        }
      }
    },
    // 更新扣除预付差额）详情信息
    // updateSubsist(list, type, item, itemValue) {
    //   if (list && list.length) {
    //     list.forEach(i => {
    //       if (i.advancePaymentNo == item.statementNo) {
    //         if (type === 'applyPayDeductAmmountInfo') {
    //           this.$set(i, 'totalApplyPercent', (+item[itemValue]) / 100)
    //         } else { //累计
    //           let num = NumberUtil.numAdd((+item[itemValue]) / 100, +i.totalApplyPercentOld)
    //           num = MoneyUtil.moneyFixed(num, 2)
    //           this.$set(i, 'totalApplyPercent', num)
    //           console.log(i)
    //         }
    //       }
    //     })
    //   }
    // },
    // 计算差额
    // difference(list = []) {
    //   let num = 0
    //   list.forEach(i => {
    //     let a = NumberUtil.numSub(+(i.statementAmtWithTax || 0), +(i.deliveryAmount || 0))
    //     let b = NumberUtil.accMul(a, +(i.totalApplyPercent || 0))
    //     num = NumberUtil.numAdd(num, b)
    //   })
    //   num = MoneyUtil.moneyFixed(num, 2)
    //   console.log(num)
    //   return num
    // },
    // 要货/收货金额(含税)(元)合计
    handleTotalStatementAmoutWithTax(list = [], itemValue, isFormat = true) {
      let num = 0;
      let a = list.filter(i => i.statementType === '2')
      let b = list.filter(i => i.statementType === '1' && !i.statementAccount)
      let c = this.$arrayDeduplicat(b, 'requireNo')
      c.concat(a).forEach(i => {
        num = NumberUtil.numAdd(num, +i[itemValue])
      })
      num = MoneyUtil.moneyFixed(num, 2)
      if (isFormat) {
        return NumberUtil.formatMoney(num)
      } else {
        return num
      }
    },
    // 合计
    handleTotal(list = [], itemValue, isFormat = true) {
      let num = 0;
      list.forEach(item => {
        num = NumberUtil.numAdd(num, +item[itemValue])
      })
      if (itemValue === 'totalIncludCurAmount') {
        this.$emit('getTotalIncludCurAmount', num)
      }
      if (itemValue === 'applyPayAmmount') {
        this.applyIncludingTax()
      }
      num = MoneyUtil.moneyFixed(num, 2)
      // console.log(num)
      if (isFormat) {
        return NumberUtil.formatMoney(num)
      } else {
        return num
      }
    },
    // 本次应付款
    applyIncludingTax() {
      let num = 0
      this.notSubmitList.forEach(item => {
        if (item.checked) {
          num = NumberUtil.numAdd(num, +item.applyPayAmmount)
        }
      })
      num = MoneyUtil.moneyFixed(num, 2)
      this.$emit('getApplyIncludingTax', num)
    },
    handleCheckedAll(blo) {
      this.notSubmitList.forEach(i => {
        if (!i.disabled) {
          this.$set(i, 'checked', blo)
        }
        this.$set(i, 'isRelated', false)
      })
      this.isCheckedAll()
    },
    handleSelectTableRow(item, ind) {
      if (item.checked) {
        this.statementNo = item.statementNo
      }
      this.$set(item, 'isRelated', false)
      // 对账单勾选，关联旗下的预付款单
      if (item.statementType == '2') {
        if (item.totalExcludCurDeductAmountInfo && item.totalExcludCurDeductAmountInfo.length) {
          this.notSubmitList.forEach(i => {
            item.totalExcludCurDeductAmountInfo.forEach(j => {
              if (i.statementNo == j.advancePaymentNo && !i.disabled) {
                this.$set(i, 'checked', item.checked)
                this.$set(i, 'isRelated', item.checked)
              }
            })
          })
        }
      } else {// 预付款单勾选，关联对账单和平行的预付款单
        if (item.statementAccount) {
          this.notSubmitList.forEach(i => {
            if (i.statementNo == item.statementAccount && !i.disabled) {
              this.$set(i, 'checked', item.checked)
              this.$set(i, 'isRelated', item.checked)
            }
            if (i.statementAccount === item.statementAccount && i.statementNo !== item.statementNo && !i.disabled) {
              this.$set(i, 'checked', item.checked)
              this.$set(i, 'isRelated', false)
            }
          })
        }
      }
      this.isCheckedAll()
    },
    isCheckedAll() {
      const list = this.notSubmitList.filter(i => !i.disabled);
      this.checkedAll = list.every(item => {
        return item.checked;
      });
      if (!list.length) {
        this.checkedAll = false
      }
    },
    // 处理百分比*100
    handlePercentageMultiply(item, itemValue) {
      if (item[itemValue] === '' || item[itemValue] === null) {
        item[itemValue] = ''
      } else {
        item[itemValue] = +(item[itemValue] || 0)
        item[itemValue] = NumberUtil.accMul(item[itemValue], 100)
      }
    },
  },
}
</script>

<style scoped lang="scss">
.detailsTable {
  margin-bottom: 30px;
  /deep/ .table-input {
    width: 100%;
    .el-input__inner {
      line-height: 34px;
      height: 34px;
      padding: 0 8px;
    }
    .suffix {
      color: #444;
      margin-right: 4px;
      line-height: 34px;
    }
  }
  .table-default {
    tr {
      td {
        padding-left: 10px;
        padding-right: 10px;
      }
    }
    .box_type {
      background: #ffe9eb;
      border: 1px solid #db7575;
      color: #863838;
      margin-bottom: 0px;
    }
    tbody {
      .total {
        background: #ebf1ff;
        > td {
          padding-top: 7px;
          padding-bottom: 6px;
          font-weight: 600;
          font-size: 12px;
          line-height: 17px;
          text-align: right;
          .total-text {
            // width: 151px;
            height: 30px;
            background-color: #e3ecff;
            padding-left: 10px;
            text-align: left;
            line-height: 30px;
          }
        }
      }
    }
  }
}
</style>