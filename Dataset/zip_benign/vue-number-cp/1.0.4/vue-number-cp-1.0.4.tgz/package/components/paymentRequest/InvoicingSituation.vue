<template>
  <!-- 本次开票情况 -->
  <div class="invoicingSituation">
    <div class="tr" style="margin: -10px 0px 16px">
      <el-button class="normal-btn" @click="beenReconciled">开票信息</el-button>
    </div>

    <div class="inner-info">
      <el-row>
        <el-col :span="12">
          <p>
            <label>累计已开票金额(含税)(不含本次)
              <el-popover popper-class="dark-popover" trigger="hover" placement="top">
                <div style="color: #fff;width: 185px;">
                  <!-- 即已审核通过的开票金额(含税)汇总 -->
                  即付款申请时填写的开票信息已通过审核的开票金额汇总。
                </div>
                <i slot="reference" style="display: inline-block;width: 14px;text-align: center;height: 14px;line-height: 14px;background: linear-gradient(180deg, #101018 0%, #5A5858 100%);border-radius: 50%;color: #fff">?</i>
              </el-popover>
              ：
            </label>
            {{invoiceMoney | formatMoney}}元
          </p>
        </el-col>
        <el-col :span="12">
          <p>
            <label>累计已开票金额(含税)(含本次)：</label>{{totalTnvoiceMoney}}元
          </p>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <p>
            <label>发票是否齐全：</label>{{complete}}
          </p>
        </el-col>
      </el-row>
    </div>

    <template>
      <div style="width: 100%;height:1px;background: #EEEEEE;"></div>
      <div class="order-info-title">本次开票情况</div>
    </template>

    <div class="list-content">
      <table class="table-default">
        <thead>
          <tr>
            <td width="45px">序号</td>
            <td width="202px">发票号码</td>
            <td width="200px">金额(不含税)(元)</td>
            <td width="200px">税金(元)</td>
            <td width="200px">金额(含税)(元)</td>
            <td width="194px">开票日期</td>
            <td width="100px">税率(%)</td>
            <td width="60px">操作</td>
          </tr>
        </thead>
        <tbody>
          <tr v-if="repeatNumber">
            <td colspan="9" style="padding: 3px 0px;">
              <div class="repeat tl">您输入的发票号码：{{repeatNumber}}已提交过申请，请检查号码是否正确</div>
            </td>
          </tr>
          <tr v-for="(item,ind) in dataList" :key="ind">
            <td>{{ind + 1}}</td>
            <td>
              <el-input class="table-input" maxlength="32" :class="{'red': dataList.filter(i=> i.invoiceId === item.invoiceId).length === 2 ||  dataList.some(i=> i.invoiceId === item.invoiceId && i.isExists)}" v-model.trim="item.invoiceId" placeholder="请输入发票号码" @blur="checkInvoiceIsUse(item,ind)" clearable></el-input>
            </td>
            <td>
              <el-input class="table-input" v-model="item.invoiceAmount" :maxlength="handleMaxlength(item, 'invoiceAmount')" @input="checkNumber(item, 'invoiceAmount')" placeholder="请输入金额" clearable></el-input>
            </td>
            <td>
              <el-input class="table-input" v-model="item.invoiceTaxAmount" :maxlength="handleMaxlength(item, 'invoiceTaxAmount')" @input="checkNumber(item, 'invoiceTaxAmount')" placeholder="请输入金额" clearable></el-input>
            </td>
            <td>
              <el-input class="table-input" v-model="item.invoiceTotalAmount" :maxlength="handleMaxlength(item, 'invoiceTotalAmount')" @input="checkNumber(item, 'invoiceTotalAmount')" placeholder="请输入金额" clearable></el-input>
            </td>
            <td>
              <el-date-picker class="table-input" value-format="yyyy-MM-dd" v-model="item.invoiceBillingDate" type="date" style="width: 100%" placeholder="请选择日期">
              </el-date-picker>
            </td>
            <td>
              <el-input class="table-input" style="width: 100px;" v-model="item.invoiceTaxRate" :maxlength="handleMaxlength(item, 'invoiceTaxRate')" @input="checkNumber(item, 'invoiceTaxRate')" placeholder="请输入数字" clearable></el-input>
            </td>
            <td>
              <!-- <DownloadAndUpload appName="TRD" :fromId="String(ind)" uploadType="15" :isImg="true" :uploadName="'上传发票'" fileTypeErrorMsg="请上传图片格式文件" :hasDownloadFlg="false" @outputValue="getAttachInfo"></DownloadAndUpload> -->
              <!-- <span class="f12 blue-pointer" style="margin-right: 10px">上传发票</span> -->
              <span class="f12 blue-pointer" style="margin-left: 6px" @click="handleDel(ind)">删除</span>
            </td>
          </tr>
          <tr class="add">
            <td colspan="9" class="tc add-goods hand" style="background: #f5f5f5 !important" @click="handleAdd">
              <span class="f14 blue">+新增</span>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="invoiceFileContainer">
      <span class="mini-title f14">
        <font class="red">*</font>发票附件
      </span>
      <DownloadAndUpload :fileSize="157286400" :fileTypeReg="/(zip|rar)$/i" fileSizeErrorMsg="单个附件大小不超过150MB" appName="TRD" fromId="invoice" uploadType="15" :hasDownloadFlg="false" @outputValue="getInvoiceAttachInfo"></DownloadAndUpload>
      <p class="notice">请将发票扫描文件统一打包上传，格式为zip、rar，单个打包附件大小不超过150MB。可上传多个附件。请自行规范打包文件命名，方便查询。</p>
      <div class="enclosure-content" v-if="invoiceFileList.length" style="margin-bottom: 40px;">
        <p v-for="(file,ind) in invoiceFileList" :key="ind">
          {{file.attachName}}
          <DownloadAndView downloadName="下载" viewName="" :attachUrl="file.viewUrl" :attachName="file.attachName"></DownloadAndView>
          <span class="blue-pointer" style="padding-left: 10px;" @click="handleDelNew(invoiceFileList,ind)">删除</span>
        </p>
      </div>
      <div class="enclosure-content" v-else style="margin-bottom: 40px;color: #bbb;">
        未上传附件！
      </div>
    </div>

    <!-- 开票信息 -->
    <!-- <BillingInfo ref="billingInfo"></BillingInfo> -->
    <InvoicBaseInfoBottomComponent ref="invoicBaseInfoBottomComponentRef" :tabIndex="1" :orderDetailInfo="orderDetailInfo"></InvoicBaseInfoBottomComponent>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import DownloadAndUpload from "@/components/base/DownloadAndUpload";
import DownloadAndView from '@/components/order/DownloadAndView'
import { NumberUtil } from '@/utils/numberUtil';
import { MoneyUtil } from '@/utils/moneyUtil';
// import BillingInfo from "@/components/paymentRequest/BillingInfo";
import InvoicBaseInfoBottomComponent from "@/components/advanceCharge/advancePaymentRequest/InvoicBaseInfoBottomComponent";


export default {
  name: "invoicingSituation",
  data() {
    return {
      isLoading: false,

      dataList: [],
      complete: '否',
      total: 0,
      tnvoiceMoneyTotal: 0,
      invoiceFileList: [],
    }
  },
  components: {
    Loading,
    DownloadAndUpload,
    DownloadAndView,
    // BillingInfo
    InvoicBaseInfoBottomComponent
  },
  props: ['invoiceDetailInfos', 'orderNo', 'invoiceMoney', 'orderDetailInfo', 'applyPayInfo'],
  watch: {
    invoiceDetailInfos: {
      handler(n) {
        this.dataList = []
        if (n.length) {
          this.dataList = this.$clone(n).sort((b, a) => { return b.index - a.index })
          this.dataList.forEach(i => {
            this.$set(i, 'isExists', false)
            this.handlePercentageMultiply(i, 'invoiceTaxRate')
          });
        }
      },
      immediate: true,
    },
    applyPayInfo: {
      handler(n) {
        this.invoiceFileList = []
        n && n.applyAttachInfos && n.applyAttachInfos.forEach(f => {
          if (f.attachType == '15') {
            this.invoiceFileList.push({
              viewUrl: f.attachUrl,
              attachName: f.attachName,
              attachType: f.attachType,
              attachUrl: f.attachPath,
            })
          }
        })
      },
      immediate: true,
    }
  },
  computed: {
    repeatNumber() {
      let result = ''
      let list = []
      this.dataList.map(i => {
        if (i.isExists) {
          list.push(i.invoiceId)
        }
      })
      if (list.length) {
        result = [... new Set(list)].join('、')
      }
      return result
    },
    totalTnvoiceMoney() {
      let num = 0
      this.dataList.forEach(i => {
        num = NumberUtil.numAdd(num, +i.invoiceTotalAmount)
      })
      num = NumberUtil.numAdd(num, +(this.invoiceMoney || 0))
      num = MoneyUtil.moneyFixed(num, 2)
      this.tnvoiceMoneyTotal = num
      this.isComplete(this.total)
      return NumberUtil.formatMoney(num)
    },
  },
  methods: {
    getInvoiceAttachInfo(info) {
      this.invoiceFileList.push({
        attachName: info.attachName,
        viewUrl: info.attachUrl,
        attachUrl: info.attachPath,
        attachType: '15',
      });
      this.$emit('emitInvoiceFileList', this.invoiceFileList)
    },
    handleDelNew(file, ind) {
      file.forEach((item, index) => {
        if (index === ind) {
          file.splice(ind, 1)
        }
      })
    },
    // 文件下载
    handleDownTemp(name, url) {
      this.$download([{
        name: name,
        url: url
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 处理百分比*100
    handlePercentageMultiply(item, itemValue) {
      if (item[itemValue] === '' || item[itemValue] === null) {
        item[itemValue] = ''
      } else {
        item[itemValue] = +(item[itemValue] || 0)
        item[itemValue] = NumberUtil.accMul(item[itemValue], 100)
      }
    },
    // 发票是否齐全
    isComplete(num) {
      this.total = num
      if (+this.tnvoiceMoneyTotal >= num) {
        this.complete = '是'
      } else {
        this.complete = '否'
      }
    },

    beenReconciled() {
      const corpId = this.orderDetailInfo.brokerCorpId
      this.$refs["invoicBaseInfoBottomComponentRef"].open(corpId)
    },
    handleAdd() {
      this.dataList.push({
        invoiceId: '',
        invoiceAmount: '',
        invoiceTaxAmount: '',
        invoiceTotalAmount: '',
        invoiceBillingDate: '',
        invoiceTaxRate: '',
        invoiceAttachName: '',
        invoiceAttachUrl: '',
        invoiceOrder: '',
        viewUrl: '',
        isExists: false,
      })
    },
    getAttachInfo(info) {
      this.$set(this.dataList[+info.fromId], 'invoiceAttachUrl', info.attachPath)
      this.$set(this.dataList[+info.fromId], 'attachUrl', info.attachUrl)
      this.$set(this.dataList[+info.fromId], 'invoiceAttachName', info.attachName)
    },
    handleMaxlength(item, value) {
      return item[value] && String(item[value]).indexOf('.') != -1 ? 13 : 10
    },
    // 限制输入100 不可以为小数，不可以为0
    // check100(item, itemValue) {
    //   item[itemValue] = item[itemValue].replace(/\D/g, '')
    // if (+item[itemValue] > 100 || +item[itemValue] <= 0) {
    //   item[itemValue] = ''
    // }
    // },
    checkNumber(item, itemValue) {
      item[itemValue] = item[itemValue].match(/\d+(\.\d{0,2})?/) ? item[itemValue].match(/\d+(\.\d{0,2})?/)[0] : ''
      if (itemValue === 'invoiceTaxRate') {
        if (+item[itemValue] > 100 || +item[itemValue] < 0) {
          item[itemValue] = ''
        }
      }
    },
    // 检索发票是否已经使用
    checkInvoiceIsUse(item, ind) {
      // if (item.invoiceId === '123') {
      //   this.$set(this.dataList[ind], 'isExists', true)
      // }
      // return
      if (!item.invoiceId) return
      let param = {
        invoiceId: item.invoiceId,
        orderNo: this.orderNo,
      };
      InterfaceService.checkInvoiceIsUse(
        param,
        data => {
          let res = data.respData
          if (data.respData && data.respData.respCode === "0000") {
            if (data.respData.isExists === '1') {
              this.$set(this.dataList[ind], 'isExists', true)
            } else {
              this.$set(this.dataList[ind], 'isExists', false)
            }
          } else {
            this.$message.error(res.respMsg);
          }
        },
        data => { }, () => { this.isLoading = true; }, () => { this.isLoading = false; }
      );
    },
    handleDel(ind) {
      this.$confirm(
        "确认删除该条发票信息？",
        '删除',
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "删除",
          cancelButtonText: '取消',
        }
      ).then(() => {
        this.dataList.splice(ind, 1)
      }).catch(() => {
      });
    },
    delFile(ind) {
      this.$set(this.dataList[ind], 'invoiceAttachUrl', '')
      this.$set(this.dataList[ind], 'viewUrl', '')
      this.$set(this.dataList[ind], 'invoiceAttachName', '')
    },

  },
  mounted() {

  },
}
</script>

<style scoped lang="scss">
.invoicingSituation {
  margin-bottom: 30px;
  /deep/ .table-input {
    .el-input__inner {
      line-height: 34px;
      height: 34px;
      padding: 0 30px 0 8px;
    }
    .el-input__prefix {
      .el-icon-date {
        display: none;
      }
    }
    .el-input__suffix {
      .el-input__icon {
        line-height: 34px;
      }
    }
    &.red {
      .el-input__inner {
        color: #df0a0a;
      }
    }
  }
  .inner-info {
    margin-bottom: 26px;
    line-height: 25px;
    font-size: 12px;
    p {
      width: 100%;
      display: flex;
      padding-right: 10px;
      word-break: break-word;
      white-space: normal;

      & > span {
        display: inline-block;
        flex: 1 1 0%;
      }
    }

    label {
      white-space: nowrap;
      color: #888888;
    }

    a {
      white-space: nowrap;
      color: #0082ff;
    }

    i {
      font-style: normal;
    }
  }
  .list-content {
    .table-default {
      thead {
        tr {
          td {
            padding: 7px 3px;
          }
        }
      }
      tr {
        border: none;
        td {
          padding: 3px;
          &:first-child {
            padding-left: 10px;
          }
          &:last-child {
            padding-right: 10px;
          }
          .file-tab {
            > li.li-tab {
              display: inline-block;
              min-width: 60px;
              background-color: #c99f4f;
              color: #fff;
              border-radius: 0;
              font-size: 12px;
              line-height: 17px;
              padding: 3px 4px 2px;
              > p {
                max-width: 200px;
                display: inline-block;
              }
              > i {
                color: #fff;
                background-color: #c99f4f;
                vertical-align: text-top;
              }
            }
          }
          .repeat {
            width: 100%;
            //   height: 42px;
            background: #ffe9eb;
            border: 1px solid #db7575;
            font-size: 12px;
            line-height: 17px;
            color: #863838;
            padding: 6px 10px;
          }
        }
      }
    }
  }
}
.enclosure-content {
  width: 1190px;
  background: #ffffff;
  border: 1px solid #dddddd;
  padding: 10px;
  line-height: 17px;
  font-size: 12px;
  margin-top: 6px;
  p {
    margin-bottom: 10px;
  }
  p:last-of-type {
    margin-bottom: 0;
  }
}
.invoiceFileContainer {
  margin-top: 30px;
  .notice {
    color: #888888;
    margin: 8px 0;
  }
}
</style>