<template>
  <el-popover popper-class="subsistTable-popover" trigger="hover" placement="bottom" @show="getToday">
    <div>
      <p class="f12">※本数据截止于本对账单提交付款审核时间：{{applyCreateDt || today}}</p>
      <table class="table-default" :style="{'width': width +'px'}">
        <thead>
          <tr>
            <td width="160px">预付款单编号</td>
            <td width="150px" class="tr">要货金额(含税)(元)</td>
            <td width="110px" class="tr">预付比例</td>
            <td width="160px">验收单编号</td>
            <td width="150px" class="tr">验收金额(含税)(元)</td>
            <td width="150px">预付款差额(含税)(元)
              <el-popover popper-class="dark-popover" trigger="hover" placement="top">
                <div style="color: #fff;width: 185px;">
                  预付款差额=（验收单金额-要货单金额）*∑预付比例
                </div>
                <i slot="reference" style="display: inline-block;width: 14px;text-align: center;height: 14px;line-height: 14px;background: linear-gradient(180deg, #101018 0%, #5A5858 100%);border-radius: 50%;color: #fff">?</i>
              </el-popover>
            </td>
          </tr>
        </thead>
        <tbody :style="{'width': width +'px'}">
          <tr v-for="(item,ind) in dataList" :key="ind">
            <td width="160px" class="blue">
              <span class="blue-pointer" @click="handleAdvancePaymentRequesDetail(item,'0')">{{item.advancePaymentNo}}</span>
            </td>
            <td width="150px" class="tr">{{(tab == '0' ? item.statementAmtWithTax : item.statementAmtWithTaxIn)  | formatMoney}}</td>
            <td width="110px" class="tr">{{item.totalApplyPercent ? item.totalApplyPercent*100 + '%' : ''}}</td>
            <td width="160px" class="blue-pointer">
              <span class="blue-pointer" @click="handleAdvancePaymentRequesDetail(item,'1')">{{item.deliveryNo}}</span>
            </td>
            <td width="150px" class="tr">{{(tab == '0' ? item.deliveryAmount : item.deliveryAmountIn) | formatMoney}}</td>
            <td width="150px">{{difference(item)}}</td>
          </tr>
        </tbody>
      </table>
    </div>
    <p slot="reference" class="hand"><span class="red">{{text}}</span><i class="el-icon-caret-bottom blue"></i></p>
  </el-popover>
</template>
<script>
import { NumberUtil } from '@/utils/numberUtil';
export default {
  props: {
    tab: { // 0材料合同请款信息,1事业部合同请款信息
      type: String,
      default: '0'
    },
    text: {
      type: String,
      default: ''
    },
    dataList: {
      type: Array,
      default: []
    },
    width: {
      type: Number,
      default: 880
    },
    applyCreateDt: {
      type: String,
      default: ''
    },
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo;
    },
  },
  data() {
    return {
      today: '',
    }
  },
  mounted() { },
  methods: {
    getToday() {
      let today = new Date().getTime()
      today = this.$formatDateTime(today)
    },
    difference(item, isFormat = true) {
      let num = 0
      let a = NumberUtil.numSub(+((this.tab == '0' ? item.statementAmtWithTax : item.statementAmtWithTaxIn) || 0), +((this.tab == '0' ? item.deliveryAmount : item.deliveryAmountIn) || 0))
      num = NumberUtil.accMul(a, +(item.totalApplyPercent || 0))
      if (isFormat) {
        return NumberUtil.formatMoney(num)
      } else {
        return num
      }
    },
    handleAdvancePaymentRequesDetail(item, type) {
      const orderNo = this.$route.query.orderNo
      window.open(this.$router.resolve({
        path: type === '0' ? "/advancePaymentRequesDetail" : "/requireOrderDetail",
        query: {
          orderNo: orderNo,
          statementNo: this.userInfo.bs == 'B' ? item.purAdvancePaymentNo : item.advancePaymentNo,
          purchaserStatementNo: this.userInfo.bs == 'B' ? item.purAdvancePaymentNo : '',
          supplierStatementNo: this.userInfo.bs == 'B' ? item.advancePaymentNo : '',
          requireNo: item.requireNo || '',
        }
      }).href, '_blank')
    },
  }
}
</script>
<style lang="scss">
.subsistTable-popover {
  .table-default {
    padding: 10px 4px;
    // table-layout: auto;
    margin-top: 6px;
    thead {
      tr {
        td {
          font-size: 12px;
          line-height: 17px;
        }
      }
    }
    tbody {
      height: 270px;
      overflow-y: auto;
      display: block;
    }
  }
}
</style>