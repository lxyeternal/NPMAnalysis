<template>
  <div>
    <transition name="el-zoom-in-bottom">
      <div class="billingInfo" v-show="showBox">
        <div class="confirmContract" ref="confirmContract">
          <div class="content">
            <div class="title tc">开票信息</div>
            <div class="center">
              <div class="box_type">
                <p>温馨提示：若开票信息账号有误，请联系采购商更改开票信息。</p>
              </div>
              <p style="margin-bottom: 10px">票种：增值税发票</p>
              <div class="info">
                <ul class="clearfloat">
                  <li class="align-items">购买方</li>
                  <li style="width: 659px" class="purchaser">
                    <p>名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称：XXXXXX有限公司</p>
                    <p>纳税人识别号：91310000132206287R</p>
                    <p>工商注册地址：上海市浦东新区XX路111号</p>
                    <p>公司办公地址：上海市浦东新区XX路111号</p>
                    <p>电&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;话：151 9999 9999</p>
                    <p>开户行及账号：中国银行 1236 3726 3515 2321 321</p>
                  </li>
                  <li class="bbb align-items">密码方</li>
                  <li style="width: 450px"></li>
                </ul>
                <ul class="clearfloat">
                  <li class="bbb" style="width: 291px">货物或应税劳务、服务名称</li>
                  <li class="bbb" style="width: 165px">规格型号</li>
                  <li class="bbb" style="width: 69px">单位</li>
                  <li class="bbb" style="width: 109px">数量</li>
                  <li class="bbb" style="width: 168px">单价</li>
                  <li class="bbb" style="width: 168px">金额</li>
                  <li class="bbb" style="width: 68px">税率</li>
                  <li class="bbb" style="width: 151px">税额</li>
                </ul>
                <ul class="clearfloat">
                  <li class="bbb" style="width: 291px">价税合计（大写）</li>
                  <li class="bbb" style="width: 898px">（小写）</li>
                </ul>
                <ul class="clearfloat">
                  <li class="align-items">销售方</li>
                  <li style="width: 659px" class="purchaser">
                    <p class="bbb">名&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;称：</p>
                    <p class="bbb">纳税人识别号：</p>
                    <p class="bbb">地 址、 电 话：</p>
                    <p class="bbb">开户行及账号：</p>
                  </li>
                  <li class="align-items">备注</li>
                  <li style="width: 450px" class="purchaser">
                    <p>合 同 号：</p>
                    <p>项目名称：</p>
                    <p>项目地址：</p>
                    <p>其 他：</p>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <FixBottom class="bottom">
            <!-- 未设置过模拟清单 -->
            <div class="tc">
              <el-button @click="showBox = false">关闭</el-button>
            </div>
          </FixBottom>
        </div>
      </div>
    </transition>
  </div>
</template>
<script>
import FixBottom from "@/components/base/FixBottom";
export default {
  components: {
    FixBottom
  },
  data() {
    return {
      inf0: {},
      showBox: false,
    }
  },
  watch: {
    // 锁定父元素html的滚动
    showBox(val) {
      if (val) {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'hidden', 'important')
      } else {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'scroll', 'important')
      }
    },
  },
  methods: {
    open() {
      this.showBox = true
    }
  },
}
</script>
<style lang="scss" scoped>
.bbb {
  color: #bbb !important;
}
.billingInfo {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .confirmContract {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    height: 80%;
    overflow-x: hidden;
    overflow-y: auto;
    max-height: 610px;
    .content {
      width: 1190px;
      margin: 0 auto 100px;
      font-size: 14px;
      line-height: 17px;
      //   height: 500px;
      .title {
        padding: 20px 0;
        border-bottom: 1px solid #eee;
        margin-bottom: 10px;
      }
      .info {
        border-top: 1px solid #ddd;
        border-left: 1px solid #ddd;
        ul {
          //   min-height: 180px;
          li {
            // display: flex;
            // align-items: center;
            height: 180px;
            padding: 14px;
            border-bottom: 1px solid #ddd;
            border-right: 1px solid #ddd;
            line-height: 17px;
            font-size: 12px;
            color: #444;
            float: left;
            text-align: center;
            &:nth-child(odd) {
              width: 40px;
            }
            &.purchaser {
              text-align: left;
              > p {
                margin-bottom: 10px;
                &:last-child {
                  margin-bottom: 0px;
                }
              }
            }
            &.align-items {
              display: flex;
              align-items: center;
            }
          }
          &:nth-child(2) {
            min-height: 65px;
            > li {
              height: 65px;
            }
          }
          &:nth-child(3) {
            min-height: 40px;
            > li {
              height: 65px;
            }
          }
          &:nth-child(4) {
            min-height: 126px;
            > li {
              height: 126px;
            }
          }
        }
      }
    }
  }
}
</style>