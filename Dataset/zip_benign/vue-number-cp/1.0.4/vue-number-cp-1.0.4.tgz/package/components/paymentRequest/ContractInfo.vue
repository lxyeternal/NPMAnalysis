<template>
  <div class="contractInfo">
    <el-row>
      <el-col :span="12">
        <p>
          <label>品类：</label>{{dataInfo.categoryName}}
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>合同编号：</label>{{divisionContract ? dataInfo.sybOrderNo : dataInfo.clOrderNo}}
        </p>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <p>
          <label>合同名称：</label>
          <span>
            <span v-if="dataInfo.contractName">
              {{ divisionContract ? ('《'+ dataInfo.contractName.replace('采购合同','供应合同') + '》') : ('《'+ dataInfo.contractName + '》')}}
            </span>
            <span class='blue-pointer' @click="handleDownloadContract">下载合同</span>
            <span style="margin-left: 6px;" class='blue-pointer' @click="handleSeeDetails">查看合同详情</span>
          </span>
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>事业部：</label>{{dataInfo.groupCompanyName}}
        </p>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <p>
          <label>项目名称：</label>{{dataInfo.projectName}}
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>项目分期：</label>{{dataInfo.projectTerm}}
        </p>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <p>
          <label>标段：</label>{{dataInfo.building}}
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>项目公司名称：</label>{{dataInfo.purchaserName}}
        </p>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <p>
          <label>供应商名称：</label>{{dataInfo.supplierName}}
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>材料公司名称：</label>{{dataInfo.brokerCorpName}}
        </p>
      </el-col>
    </el-row>
    <el-row v-if="divisionContract">
      <el-col :span="12">
        <p>
          <label>合同金额(不含税)： </label>
          <span v-if="orderDetailInfo.replenishInContractFee" class="bold">{{Number(orderDetailInfo.allInContractFee) | formatMoney}}元(主合同价款{{Number(orderDetailInfo.inContractFee) | formatMoney}}元+补充合同价款{{Number(orderDetailInfo.replenishInContractFee) | formatMoney}}元)</span>
          <span v-else class="bold">{{Number(orderDetailInfo.inContractFee) | formatMoney}}元</span>
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>合同金额(含税)：</label>
          <span class="bold" v-if="orderDetailInfo.replenishInContractFeeWithTax">{{Number(orderDetailInfo.allInContractFeeWithTax) | formatMoney}}元(主合同价款{{Number(orderDetailInfo.inContractFeeWithTax) | formatMoney}}元+补充合同价款{{Number(orderDetailInfo.replenishInContractFeeWithTax) | formatMoney}}元)</span>
          <span class="bold" v-else>{{Number(orderDetailInfo.inContractFeeWithTax) | formatMoney}}元</span>
        </p>
      </el-col>
    </el-row>
    <el-row v-else>
      <el-col :span="12">
        <p>
          <label>合同金额(不含税)： </label>
          <span v-if="orderDetailInfo.replenishOutContractFee" class="bold">{{Number(orderDetailInfo.allOutContractFee) | formatMoney}}元(主合同价款{{Number(orderDetailInfo.outContractFee) | formatMoney}}元+补充合同价款{{Number(orderDetailInfo.replenishOutContractFee) | formatMoney}}元) </span>
          <span v-else class="bold">{{Number(orderDetailInfo.outContractFee) | formatMoney}}元</span>
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>合同金额(含税)：</label>
          <span v-if="orderDetailInfo.replenishOutContractFeeWithTax" class="bold"> {{Number(orderDetailInfo.allOutContractFeeWithTax) | formatMoney}}元(主合同价款{{Number(orderDetailInfo.outContractFeeWithTax) | formatMoney}}元+补充合同价款{{Number(orderDetailInfo.replenishOutContractFeeWithTax) | formatMoney}}元)</span>
          <span v-else class="bold">{{Number(orderDetailInfo.outContractFeeWithTax) | formatMoney}}元</span>
        </p>
      </el-col>
    </el-row>
    <el-row v-if="['1','2','3'].includes(pageType)">
      <el-col :span="12">
        <p>
          <label>合同支付比例：</label>
          <span :class="{'red': dataInfo.advancePercent != '80'}">
            {{dataInfo.advancePercent ? dataInfo.advancePercent + '%' : '-'}}
          </span>
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>结算支付比例：</label>
          <span :class="{'red': dataInfo.settlePercent != '95'}">
            {{dataInfo.settlePercent ? dataInfo.settlePercent + '%' : '-'}}
          </span>
        </p>
      </el-col>
    </el-row>
    <el-row style="padding-top: 15px;border-top: 1px dashed rgb(238, 238, 238);margin-top: 25px" v-if="['0','4','5','6'].includes(pageType) && dataInfo.paymentType">
      <el-col :span="24">
        <p>
          <label>付款方式：</label><span v-html="dataInfo.paymentType = dataInfo.paymentType.replace(/\n/g, '<br/>')"></span>
        </p>
      </el-col>
    </el-row>
    <el-row style="padding-top: 15px;border-top: 1px dashed rgb(238, 238, 238);margin-top: 25px" v-if="['0'].includes(pageType)">
      <el-col :span="12">
        <p>
          <label>合同支付比例：</label>
          <span :class="{'red': dataInfo.advancePercent != '80'}">
            {{dataInfo.advancePercent ? dataInfo.advancePercent + '%' : '-'}}
          </span>
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>结算支付比例：</label>
          <span :class="{'red': dataInfo.settlePercent != '95'}">
            {{dataInfo.settlePercent ? dataInfo.settlePercent + '%' : '-'}}
          </span>
        </p>
      </el-col>
    </el-row>
    <el-row v-if="!['5','6'].includes(pageType) && dataInfo.applySettlementAmount || ['2','3'].includes(pageType) && tab == '1'">
      <el-col :span="12" v-if="['2','3'].includes(pageType) && tab == '1'">
        <p>
          <label>合同加价率：</label>{{dataInfo.addRate ? dataInfo.addRate + '%' : '-'}}
        </p>
      </el-col>
      <el-col :span="12" v-if="!['5','6'].includes(pageType) && dataInfo.applySettlementAmount">
        <p>
          <label>结算金额：</label>{{dataInfo.applySettlementAmount | formatMoney}}元
        </p>
      </el-col>
    </el-row>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import { NumberUtil } from '@/utils/numberUtil';

export default {
  name: "contractInfo",
  components: {
    Loading
  },
  props: {
    pageType: {
      type: String, //(0,1,2,3详情；4，5，6创建编辑)
      default: '0' //'0':确认付款申请,'1': 供应商,'2': 采购商（材料公司）,'3': 采购商（项目公司）,'4': 付款申请-预付款/进度款, '5': 付款申请-结算款 '6': 质保金
    },
    contractInfo: {
      type: Object,
      default: {}
    },
    orderDetailInfo: {
      type: Object,
      default: {}
    },
    tab: {
      type: String,
      default: '0' //0材料合同对账单,1事业部合同对账单
    },
  },
  watch: {
    contractInfo(n) {
      this.dataInfo = this.$clone(n)
      this.handlePercentageMultiply(this.dataInfo, 'advancePercent')
      this.handlePercentageMultiply(this.dataInfo, 'settlePercent')
      this.handlePercentageMultiply(this.dataInfo, 'addRate')
      // this.$set(this.dataInfo, 'advancePercent', advancePercent)
      // this.$set(this.dataInfo, 'settlePercent', settlePercent)
      // this.$set(this.dataInfo, 'addRate', addRate)
      console.log(this.dataInfo)
    },
    'contractInfo.applySettlementAmount': {
      handler(n, o) {
        console.log(n);
        this.dataInfo.applySettlementAmount = n
      }
    }
  },
  data() {
    return {
      isLoading: false,
      orderNo: '',
      dataInfo: {},
    }
  },
  computed: {
    divisionContract() {
      return this.bs == 'B' && this.tab == '1'
    },
    bs() {
      return (
        this.$store.state.userInfo.bs
      );
    },
  },
  methods: {
    // 处理百分比*100
    handlePercentageMultiply(item, itemValue) {
      if (item[itemValue] === '' || item[itemValue] === null) {
        item[itemValue] = ''
      } else {
        item[itemValue] = +(item[itemValue] || 0)
        item[itemValue] = NumberUtil.accMul(item[itemValue], 100)
        // console.log(item[itemValue])
      }
    },
    handleSeeDetails() {
      window.open(this.$router.resolve({
        path: '/orderDetail',
        query: {
          orderNo: this.orderNo
        }
      }).href, '_blank')
    },
    // 下载合同
    handleDownloadContract() {
      const params = {
        orderNo: this.orderNo,
        bs: this.divisionContract ? 'B' : 'S',
        documentVersion: "",
        fileFrom: "userUpload,systemCreate",
        documentTypeList: []
      };
      InterfaceService.getContractInfo(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let attachList = [];
          let list = res.documentInfos || [];
          let hasPdf = list.some(item => {
            return item.documentType === 'dt_10_contract_profession' || item.documentType === 'dt_00_contract_profession'
          });
          list.forEach(item => {
            if (hasPdf) {
              // if (item.documentType === 'dt_10_contract_profession' || item.documentType === 'dt_00_contract_profession' || item.documentType === 'otherFile') {
              if (['dt_10_contract_profession', 'dt_00_contract_profession', 'dt_00_contract_common', 'dt_10_contract_common', 'otherFile'].indexOf(item.documentType) != -1) {
                let onOff = false;
                attachList.forEach(_item => {
                  if (item.documentId == _item.documentId) {
                    onOff = true
                  }
                });
                if (!onOff) {
                  attachList.push(item)
                }
              }
            } else {
              let onOff = false;
              attachList.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOff = true
                }
              });
              if (!onOff) {
                attachList.push(item)
              }
            }
          });
          this.handleBatchDownload(attachList, hasPdf)
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    handleBatchDownload(attachList, hasPdf) {
      let fileInfoBeans = []
      if (attachList.length) {
        if (!hasPdf) {
          attachList.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: item.documentName,
              fileUrl: item.attachUrl,
            })
          })
        } else {
          attachList.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: (item.documentType.indexOf('profession') != -1 ? '合同专业版/' : item.documentType.indexOf('common') != -1 ? '合同通用版/' : '') + item.documentName,
              fileUrl: item.attachUrl,
            })
          })
        }
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            // const files = [
            //   { name: (this.divisionContract ? (this.dataInfo.contractName.replace('采购合同','供应合同')) : (this.dataInfo.contractName))+ ".zip", url: url }
            // ];
            // this.$download(files).then(() => {
            //   this.$message.success("已下载");
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: (this.divisionContract ? (this.dataInfo.contractName.replace('采购合同', '供应合同')) : (this.dataInfo.contractName)) + ".zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
  },
  mounted() {
    this.orderNo = this.$route.query.orderNo || ''
  },
}
</script>

<style scoped lang="scss">
.contractInfo {
  margin-bottom: 26px;
  line-height: 25px;
  font-size: 12px;
  p {
    width: 100%;
    display: flex;
    padding-right: 10px;
    word-break: break-word;
    white-space: normal;

    & > span {
      display: inline-block;
      flex: 1 1 0%;
    }
  }

  label {
    white-space: pre;
    color: #888888;
  }

  a {
    white-space: nowrap;
    color: #0082ff;
  }

  i {
    font-style: normal;
  }
}
</style>