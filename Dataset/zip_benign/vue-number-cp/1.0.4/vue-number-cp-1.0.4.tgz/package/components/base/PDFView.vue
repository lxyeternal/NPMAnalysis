<template>
  <div id="container">
    <!--<vue-loading spinner="circles"></vue-loading>-->
    <div v-if='pdfDoc' class="toolbar">
      <button class='left' :class="{'grey':pageNum<=1}" @click="handleToPrevPage">上一页</button> <!-- v-if="pageNum>1" -->
      <button class='right' :class="{'grey':pageNum>=pdfDoc.numPages}" @click="handleToNextPage">下一页</button> <!-- v-if="pageNum<pdfDoc.numPages" -->
      <button class='right' @click="handleZoomMin()">缩小</button>
      <button class='right' @click="handleZoomMax()">放大</button>
    </div>
    <div class="loading" v-else>
      <div class="loading-inner"></div>
      <div class="loading-outer"></div>
    </div>
    <div style="overflow:auto;width: 100%;height: 100%">
      <canvas id="the-canvas" ref="canvas"></canvas>
    </div>
    <div v-if='pdfDoc' class="toolbar" style="margin-top: 10px;">
      <button class='left' :class="{'grey':pageNum<=1}" @click="handleToPrevPage('bottom')">上一页</button> <!-- v-if="pageNum>1" -->
      <button class='right' :class="{'grey':pageNum>=pdfDoc.numPages}" @click="handleToNextPage('bottom')">下一页</button> <!-- v-if="pageNum<pdfDoc.numPages" -->
      <button class='right' @click="handleZoomMin()">缩小</button>
      <button class='right' @click="handleZoomMax()">放大</button>
    </div>
  </div>
</template>

<script>
  import PDFJS from 'pdfjs-dist'
  import workerJs from 'pdfjs-dist/build/pdf.worker.js'
  export default {
    props: ['url'],
    data() {
      return {
        visible: false,
        title: '',
        loadding: false,
        pdfDoc: null,
        pageNum: 1,
        pageRendering: false,
        pageNumPending: null,
        scale: 1
      }
    },
    watch: {
      url(val) {
        console.log(val);
        this.loadFile(val)
      }
    },
    methods: {
      // 初始化pdfjs 解决 IE 下 不能预览BUG
      initThePDFJSLIB() {
        // 注释的为 可以解决  个人签章不显示 bug
        // PDFJS.GlobalWorkerOptions.workerSrc = '../../../static/js/pdf.worker.js' || ''
        PDFJS.GlobalWorkerOptions.workerSrc = workerJs || ''
      },
      renderPage(num, init, url) {
        this.pageRendering = true
        let _this = this
        this.pdfDoc.getPage(num).then(function (page) {
          let canvas = document.getElementById('the-canvas')
          if (init) {
            let initViewport = page.getViewport(1)
            let container = document.getElementById("container");
            _this.scale = container.offsetWidth / initViewport.width;
          }
          let viewport = page.getViewport(_this.scale)
          let ctx = canvas.getContext('2d')
          let dpr = window.devicePixelRatio || 1
          let bsr = ctx.webkitBackingStorePixelRatio ||
            ctx.mozBackingStorePixelRatio ||
            ctx.msBackingStorePixelRatio ||
            ctx.oBackingStorePixelRatio ||
            ctx.backingStorePixelRatio || 1
          let ratio = dpr / bsr
          canvas.height = viewport.height * ratio;
          canvas.width = viewport.width * ratio;
          canvas.style.width = viewport.width + "px";
          canvas.style.height = viewport.height + "px";
          ctx.setTransform(ratio, 0, 0, ratio, 0, 0)

          // let CSS_UNITS = 96.0 / 72.0
          // Render PDF page into canvas context
          var renderContext = {
            // transform: [CSS_UNITS,0,0,CSS_UNITS,0,0],
            canvasContext: canvas.getContext('2d'),
            viewport: viewport
          }
          var renderTask = page.render(renderContext)

          // Wait for rendering to finish
          renderTask.promise.then(function () {
            if (url && url.indexOf("medium/2016.pdf") != -1 && init) {
              _this.renderPage(1)
            }
            _this.pageRendering = false
            if (_this.pageNumPending !== null) {
              // New page rendering is pending
              _this.renderPage(_this.pageNumPending)
              _this.pageNumPending = null
            }
          })
        })
      },
      queueRenderPage(num) {
        if (this.pageRendering) {
          this.pageNumPending = num
        } else {
          this.renderPage(num)
        }
      },
      handleToPrevPage(type) {
        if (this.pageNum <= 1) {
          return
        }
        this.pageNum--
        this.queueRenderPage(this.pageNum)
        if (type === 'bottom') {
          window.scrollTo(0,0)
        }
      },
      handleToNextPage(type) {
        if (this.pageNum >= this.pdfDoc.numPages) {
          return
        }
        this.pageNum++;
        this.queueRenderPage(this.pageNum)
        if (type === 'bottom') {
          window.scrollTo(0,0)
        }
      },
      handleZoomMax() {
        this.scale = this.scale + 0.1;
        this.queueRenderPage(this.pageNum)
      },
      handleZoomMin() {
        this.scale = this.scale - 0.1;
        this.queueRenderPage(this.pageNum)
      },
      loadFile(url) {
        this.pageNum = 1;
        let _this = this;
        this.visible = false;
        // 引入pdf.js的字体,否则有些文字会丢失
        let CMAP_URL = 'https://unpkg.com/pdfjs-dist@2.0.943/cmaps/'
        PDFJS.getDocument({
          url: url,
          cMapUrl: CMAP_URL,
          cMapPacked: true
        }).then(function (pdf) {
          console.log(url);
          _this.visible = true;
          _this.pdfDoc = pdf
          _this.renderPage(1, "init", url)
        })
      }
    },
    mounted() {
      this.initThePDFJSLIB()
      // ie 兼容签名显示
      if (window.CanvasPixelArray) {
        CanvasPixelArray.prototype.set = function (arr) {
          var l = this.length, i = 0;

          for (; i < l; i++) {
            this[i] = arr[i];
          }
        };
      }
    }
  }
</script>

<style scoped>
  #the-canvas {
    display: block;
    width: 100%;
    margin: 0 auto;
  }
  .toolbar {
    text-align: center;
  }
</style>