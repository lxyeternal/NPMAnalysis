<template>
  <ul class="breadcrumb">
    <li v-for="(item, idx) in breadcrumbList" :key="idx" :title="item.name">
      <router-link :to="{path:item.path,query: {[item.queryName]: item.query,[item.queryName2]: item.query2,[item.queryName3]: item.query3,}}" v-if="item.path">{{item.name}}</router-link>
      <template v-else>
        <!--路径不变的情况下，取消-->
        <span class="hand" v-if="item.goBack" @click="handleGoBack(item.tab)">{{item.name}}</span>
        <span v-if="!item.goBack">{{item.name}}</span>
      </template>
    </li>
  </ul>
</template>
<script>
export default {
  // 面包屑
  props: {
    // 路径
    breadcrumbList: {
      type: Array,
      default() { return [
        // { name<string>: 显示名称 , path<string>: 点击后跳转路径, 不传代表不需要跳转, 显示样式为置灰
      ] }
    },
  },
  methods:{
      handleGoBack(tab = ''){
        if(tab){
          this.$emit("refresh", tab)
        }else{
          this.$emit("refresh","cancel")
        }
      },
  }
}
</script>
<style lang="scss" scoped>
.breadcrumb {
  padding: 12px 0;
  li {
    display: inline-block;
    color: #0082ff;
    cursor: context-menu;
    transition: all 0.3s linear;
    font-size: 14px;
    &:not(:last-child) {
      &:hover {
        color: #0082ff;
      }
    }
    &:not(:first-child) {
      &::before {
        content: ">";
        color: #888;
        margin: 0 4px;
      }
    }
    &:last-child {
      color: #888;
    }
  }
}
</style>

