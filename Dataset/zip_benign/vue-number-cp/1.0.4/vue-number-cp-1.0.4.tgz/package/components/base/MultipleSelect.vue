<template>
  <div class="multipleSelect">
    <el-select v-model="list" :placeholder="placeholder" multiple popper-class="multiple-select" @change="multipleChange" class="multiple-tag">
      <el-option v-for="(item,index_item) in handleList" :key="index_item" :label="item[label]" :value="item[value]">
        <el-checkbox :value="item.checkbox" class="checkbox"></el-checkbox>
        <span v-if="type === '1'" class="text f12">{{ item[label]+'(Tel:'+item.tel+')' }}</span>
        <span v-else class="text f12">{{ item[label] }}</span>
      </el-option>
      <slot name="prefix"></slot>
    </el-select>
  </div>
</template>

<script>
export default {
  name: "multipleSelect",
  props: {
    type: {
      type: String,
      default: ''
    },
    placeholder: {
      type: String,
      default: ''
    },
    label: {
      type: String,
      default: ''
    },
    value: {
      type: String,
      default: ''
    },
    handleList: {
      type: Array,
      default: () => []
    },
    dataList: {
      type: Array,
      default: () => []
    },
  },
  data() {
    return {
      list: [],
    }
  },
  watch: {
    dataList() {
      this.list = [...this.dataList]
    }
  },
  computed: {
  },
  methods: {
    handleEmit() {
      this.$emit("getData", this.list)
    },
    // 多选选中值发生变化时触发
    multipleChange(val) {
      this.handleList.forEach(i => {
        if (val.length) {
          for (let j = 0; j < val.length; j++) {
            if (i[this.value] == val[j]) {
              i.checkbox = true
              break
            } else {
              i.checkbox = false
            }
          }
        } else {
          i.checkbox = false
        }
      })
      // console.log(this.handleList)
    },
  },
}
</script>

<style lang="scss" scoped>
.multipleSelect {
  // 多选
  .multiple-tag {
    /deep/ .el-tag.el-tag--info {
      background-color: #c99f4f;
      border-color: #c99f4f;
      color: #fff;
      border-radius: 0;
      font-size: 12px;
      &:first-child {
        .el-tag__close {
          display: none;
        }
      }
      .el-tag__close {
        color: #fff;
        background-color: #c99f4f;
      }
    }
  }
}
.multiple-select {
  .el-select-dropdown__item {
    padding: 0 10px;
  }
  .el-select-dropdown__item {
    color: #444 !important;
    font-weight: normal;
  }
  &.el-select-dropdown.is-multiple .el-select-dropdown__item.selected {
    color: #fff !important;
  }
  &.el-select-dropdown.is-multiple .el-select-dropdown__item.is-disabled {
    background: #fff !important;
    color: #444 !important;
  }
  &.el-select-dropdown.is-multiple .el-select-dropdown__item.selected::after {
    display: none !important;
  }
  .text {
    position: absolute;
    left: 0;
    z-index: 13;
    padding-left: 35px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    width: calc(100% - 34px);
  }
}
</style>