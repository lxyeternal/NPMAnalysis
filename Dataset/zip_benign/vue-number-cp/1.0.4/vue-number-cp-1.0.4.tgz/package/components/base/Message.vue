<template>
  <div >
    <div class="dialog-wrap" v-if="isShow">
      <div class="dialog-cover"  ></div>
      <transition name="bounce">
        <div class="show-msg-content"  v-if="isShow">
          <slot>empty</slot>
        </div>
      </transition>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    isShow: {
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      
    }
  },
  methods: {
    closeMyself () {
      this.$emit('on-close')
    }
  },
  mounted () {
    let self = this;
    //消息弹窗 自动关闭
    setTimeout(function() {
       self.isShow = false;
    }, self.$getConfig().MESSAGE_DURATION);
  }
}
</script>

<style scoped>
.bounce-enter-active {
  animation: bounce-in .5s;
}
.bounce-leave-active {
  animation: bounce-in .5s reverse;
}
@keyframes bounce-in {
  0% {
    transform: scale(0);
  }
  50% {
    transform: scale(1.5);
  }
  100% {
    transform: scale(1);
  }
}



.dialog-wrap {
  position: fixed;
  width: 100%;
  height: 100%;
}
.dialog-cover {
  background: #000;
  opacity: .3;
  position: fixed;
  z-index: 5;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}
.show-msg-content {
  /*width: 50%;*/
  position: fixed;
  overflow: auto;
  background: #fff;
  top:50%;
  left: 50%;
  z-index: 10;
  border-radius: 10px;
  padding: 2%;
  line-height: 1.5;
  text-align: center;
  color: #444;
  font-size: 16px;
  /*transform: translate(-50%,-50%);
  -webkit-transform: translate(-50%,-50%);
  -o-transform: translate(-50%,-50%);
  -moz-transform: translate(-50%,-50%);*/
}


</style>
