<template>
  <div class="process-conent" v-if="list.length" :class="{box:type != 'small'}">
    <ul class="top_list">
      <li :style="{'width':space + 'px'}" class="top_desc" v-for="(item,index) in list" :key="index" :class="{borderR: isShowLine && (index+1)%3 == 0 && index+1 != list.length, waitColor:(index+1)>active,processColor:(active==index&&stepsIndex==-1),displayNone:item.hideFlg == '1'}">
        <p><span class="title bold" v-if="item.top_title">{{item.top_title}}</span></p>
        <p><span class="info" v-if="item.top_info">{{item.top_info}}</span></p>
        <p><span class="info" style="margin-top: 6px" v-if="item.top_end_info">{{item.top_end_info}}</span></p>
      </li>
    </ul>
    <el-steps :space="space" :active="active" align-center :class="{'small-steps':type == 'small'}">
      <el-step v-for="(item,index) in list" :key="index" :style="'width:'+space+'px'" :class="{displayNone:item.hideFlg == '1', borderR: isShowLine && (index+1)%3 == 0 && index+1 != list.length,}">
        <div slot="description" class="foot_desc" :class="{processColor:(active==index&&stepsIndex==-1)}">
          <p class="title">
            <span v-if="item.foot_title">{{item.foot_title}}</span>
          </p>
          <p><span class="info" :class="{width:stepsIndex==index}" v-if="item.foot_info">{{item.foot_info}}</span></p>
        </div>
      </el-step>
    </el-steps>
  </div>
</template>

<script>
export default {
  // props: ["tenderList", "active", "type", "space"],
  props: {
    tenderList: {
      type: Array,
      default: () => []
    },
    active: {
      type: Number,
      default: 0
    },
    type: {
      type: String,
      default: ""
    },
    space: {
      type: Number,
      default: 120
    },
    stepsIndex: {
      type: Number,
      default: -1
    },
    // 是否显示分割线
    isShowLine: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      list: []
    };
  },

  watch: {
    tenderList: {
      handler(val, oldVal) {
        this.init();
      },
      deep: true
    }

  },
  methods: {
    init() {
      this.list = this.$clone(this.tenderList);
      this.list.sort((a, b) => {
        return a.step - b.step;
      });
    }
  },
  mounted() {
    this.init();
  }
};
</script>

<style lang="scss" scoped>
/deep/ .el-step.is-center .el-step__description {
  padding: 0;
  position: relative;
}
/deep/ .small-steps {
  .el-step.is-horizontal .el-step__line {
    top: 11px !important;
  }
  .el-step__icon {
    width: 24px !important;
    height: 24px !important;
  }
  .el-step__head.is-process .el-step__icon.is-text .el-step__icon-inner {
    width: 10px !important;
    height: 10px !important;
  }
  .el-step__head.is-finish .el-step__icon.is-text {
    vertical-align: top !important;
  }
  .el-step__head.is-finish .el-step__icon.is-text .el-step__icon-inner {
    width: 20px !important;
    height: 20px !important;
    background-size: 120% !important;
    background-position: center !important;
    margin: 0 auto !important;
  }
  .foot_desc {
    margin-top: 10px !important;
    font-size: 12px !important;
    line-height: 17px !important;
    color: #444444 !important;
  }
  .el-step__description.is-wait {
    .foot_desc {
      color: #bbbbbb !important;
    }
  }
  .el-step__head.is-wait .process-desc {
    color: #bbbbbb !important;
  }
}
.top_list {
  width: 100%;
  display: flex;
  li {
    padding-bottom: 10px;
  }
  .top_desc {
    /*width: 148px;*/
    text-align: center;
    font-size: 12px;
    line-height: 17px;
    &.waitColor {
      color: #888888;
    }
    &.processColor {
      color: #c99f4f;
    }
    .title {
      margin-bottom: 12px;
      display: inline-block;
    }
    .info {
      display: inline-block;
      white-space: nowrap;
    }
  }
}
.foot_desc {
  margin-top: 20px;
  font-size: 14px;
  &.processColor {
    color: #c99f4f;
    font-weight: 600;
  }
}
.top-hidden {
  /deep/ .el-step__head {
    display: none;
  }
  /deep/ .el-step__description {
    margin-bottom: 14px;
  }
}
.width {
  margin: 0 auto;
  width: 46px;
  display: inline-block;
}
.displayNone {
  display: none;
}
/deep/ .el-step.is-horizontal {
  max-width: none !important;
}
.borderR {
  border-right: 1px dashed #bbb;
}
</style>
