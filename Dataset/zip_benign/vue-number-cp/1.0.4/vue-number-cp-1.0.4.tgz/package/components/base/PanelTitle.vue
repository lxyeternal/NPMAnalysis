<template>
  <div class="panel-title" :style="style" @click="handleToggleShow">
    <span v-if="title" class="title">{{title}}</span>
    <span v-if="features" @click="handleFeatures" class="features fr hand">{{features}}</span>
    <span class="tabs pointer" v-for="(tab,index) in tabs" :key="index" @click.stop="handleSelectTab(tab,index)" :class="{'active':tab.active,'disabled':tab.disabled}">
      {{tab.label}}
      <i class="noread" v-if="tab.label=='未读信息' && unreadNum>0">{{unreadNum}}</i>
    </span>
    <span v-if="subTitle" class="sub-title" v-html="subTitle" @click.stop="handleExtraBtn()"></span>
    <span v-if="link && link.text" class="link hand" @click.stop="handleGo(link.url)">{{link.text}}</span>
    <em v-if="showFold" class="fr fold hand" @click="handleFold()">{{opened == true? "收起" : "展开"}}
      <i class="el-icon-caret-top active" v-if="opened"></i>
      <i class="el-icon-caret-bottom active" v-if="!opened"></i>
    </em>
    <el-button type="primary" class="fr" icon="el-icon-circle-plus-outline" v-if="titleButton" @click="handleOpen()">{{titleButton}}</el-button>
  </div>
</template>

<script>
export default {
  props: ["title","features", "tabs", "bgColor", "textAlign", "subTitle", "link", "unreadNum", "showFold", "opened", "titleButton"],
  computed: {
    style() {
      return {
        backgroundColor: this.bgColor,
        textAlign: this.textAlign
      };
    }
  },
  data() {
    return {
    }
  },
  methods: {
    handleFeatures(){
      this.$emit('features')
    },
    handleSelectTab(tab, index) {
      if (tab.disabled) {
        return false
      }
      this.tabs.forEach((item, i) => {
        item.active = index == i;
        this.$set(this.tabs, i, item);
      });
      this.$emit("select", tab);

    },
    handleToggleShow(key) {
      this.$emit("click");
    },
    handleGo(url) {
      if (url) {
        this.$router.push({
          path: url
        })
      }
    },
    handleOpen() {
      this.$emit('handleOpen')
    },
    handleExtraBtn() {
      console.log("00008")
      this.$emit('extraBtnClick')
    },
    handleFold() {
      this.open = this.opened;
      this.open = !this.open;
      this.$emit('foldInfo', this.open)
    }
  },
  mounted() {
  }
};
</script>

<style lang="scss" scoped>
.pointer {
  cursor: pointer;
  user-select: none;
}
.panel-title {
  .title {
    position: relative;
    padding: 0 20px;
    display: inline-block;
    vertical-align: top;
    font-size: 14px;
    color: #444444;
    font-weight: 600;
    min-width: 120px;
    text-align: center;
    &:before {
      position: absolute;
      content: "";
      width: 100%;
      height: 2px;
      background-color: #222B43;
      left: 0;
      bottom: 0;
    }
    /*&:hover {*/
      /*color: #444444;*/
    /*}*/
  }
  .features{
    padding: 0 10px;
    font-size: 14px;
    color:#0082FF;
  }
  height: 50px;
  background-color: #f9f9f9;
  color: #888;
  font-size: 16px;
  line-height: 50px;
  border-bottom: 2px solid #FAE2A5;
  margin-bottom: 20px;
  /*font-weight: 700;*/
  position: relative;
  .tabs {
    position: relative;
    padding: 0 26px;
    display: inline-block;
    vertical-align: top;
    font-size: 14px;
    color: #888;
    min-width: 120px;
    text-align: center;
    &:before {
      position: absolute;
      content: "";
      width: 100%;
      height: 2px;
      background-color: #FAE2A5;
      left: 0;
      bottom: 0;
    }

    &.active,&:hover {
      color: #FAE2A5;
      font-weight: bold;
      background-color: #313131;
      /*height: 47px;*/
      /*&:before {*/
        /*background-color: #313131;*/
      /*}*/
    }
    &:hover{
      background-color: #555;
      /*&:before {*/
        /*background-color: #555;*/
      /*}*/
    }

    // &:hover {
    //   color: #313131;
    // }

    &.sub-title,
    &.link {
      font-weight: normal;
      font-size: 12px;
      position: absolute;
      right: 0;
      top: 0;
    }
    &.sub-title {
      &:before {
        height: 0px;
      }
    }
    .noread {
      margin-left: 5px;
      padding: 2px 10px;
      border-radius: 20px;
      font-size: 12px;
      color: #fff;
      background: red;
    }
  }
  .disabled {
    cursor: not-allowed;
    color: #bbb;
    &:hover {
      color: #bbb;
      font-weight: normal;
      background-color: #F9F9F9;
    }
  }
  .fold {
    font-size: 12px;
    line-height: 50px;
    padding-right: 20px;
    font-weight: normal;
  }
  /deep/ .el-button--primary {
    margin-top: 8px;
    text-align: center;
    height: 34px !important;
    width: auto !important;
    margin-right: 20px;
    line-height: 0;
    padding: 10px;
  }
}
.tender-list {
  .panel-title {
    .sub-title {
      display: inline-block;
      padding: 0 12px;
      height: 30px;
      line-height: 30px;
      background-color: #ffd64e;
      top: 50%;
      margin-top: -15px;
      cursor: pointer;

      &:hover {
        background-color: #f3c52f;
      }
    }
  }
}
</style>

