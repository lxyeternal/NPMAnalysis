<template>
    <el-input-number v-model="inputVal" :min="min" :max="max" :precision="6" label="请输入" @change="handleChange"></el-input-number>
</template>

<script>
export default {
    props: ["value", "min", "max"],
    data() {
        return {
            inputVal: 0
        };
    },
    methods: {
        handleChange(val) {
            this.$emit("change", val);
        }
    },
    created() {
        this.inputVal = this.value;
    }
};
</script>
