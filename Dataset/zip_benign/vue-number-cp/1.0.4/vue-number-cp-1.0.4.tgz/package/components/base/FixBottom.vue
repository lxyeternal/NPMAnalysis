<template>
  <div class="bottom">
    <div class="content">
      <slot></slot>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
.bottom {
  .el-button {
    width: 120px;
    height: 34px;
    line-height: 34px;
    padding: 0;
    font-size:14px;
  }
}

.bottom {
  position: fixed;
  bottom: 0;
  left: 0;
  z-index: 2000;
  width: 100%;
  padding: 11px 40px;
  background: rgba(49, 49, 49, .9);
  .content{
      margin-top: 1px;
  }
  &:after {
    display: table;
    content: "";
    clear: both;
  }
}

.content {
  max-width: 1190px;
  margin: 0 auto;
}
</style>
