<template>
  <div>
    <el-dialog class="dialog" :title="dialogTitle" :append-to-body="true" :lock-scroll="true" :visible.sync="rejectDialogVisible" width="840px" center :close-on-click-modal="false" @close="close">
      <div>
        <el-form :model="rejectForm" label-width="85px" ref="rejectForm">
          <div style="margin-bottom: 20px;line-height: 17px;text-align: center" v-html="rejectContent"></div>
          <el-form-item :label="dialogTitle + '：'" prop="refuseReason" :rules="{required: true,message:'必填'}">
            <el-input type="textarea" class="resize-none"  v-model="rejectForm.refuseReason" rows="4" :maxlength="maxlength" show-word-limit placeholder="请输入..."></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" :disabled="!rejectForm.refuseReason" @click="handleReject">{{rejectBtn}}</el-button>
        <el-button class="normal-btn" @click="rejectDialogVisible = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  const rejectForm = {
    refuseReason : ''
  };
  export default {
    name: "RejectDialog",
    props:{
      dialogTitle:{
        type: String,
        default:"退回原因"
      },
      rejectContent:{
        type: String,
        default:""
      },
      maxlength:{
        type: Number,
        default:200
      },
      rejectBtn:{
        type: String,
        default:"确认退回"
      }
    },
    data() {
      return {
        rejectDialogVisible:false,
        rejectForm : Object.assign({},rejectForm)
      }
    },
    watch:{
      rejectDialogVisible(newVal) {
        console.log(newVal);
      }
    },
    methods:{
      close() {
        this.rejectForm = Object.assign({},rejectForm)
      },
      open() {
        this.rejectDialogVisible = true
        this.$nextTick(()=> {
          this.$refs["rejectForm"].clearValidate();
        });
      },
      handleReject() {
        this.$confirm(
          this.rejectBtn+ "吗？确认请点击"+this.rejectBtn,
          this.rejectBtn,
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            dangerouslyUseHTMLString: true,
            confirmButtonText: this.rejectBtn,
            cancelButtonText: '取消',
          }).then(() => {
          this.$emit("refuseReason",this.rejectForm.refuseReason);
          this.rejectDialogVisible = false;
        }).catch(() => {
        });
      },
    }
  }
</script>

<style scoped lang="scss">
  .dialog {
    /deep/ .el-form-item__label {
      padding-right: 6px !important;
      line-height: 17px;
    }
    /deep/ .el-form-item {
      margin-bottom: 0;
    }
    /deep/ .el-dialog__footer{
      padding-top: 0;
    }
  }
</style>