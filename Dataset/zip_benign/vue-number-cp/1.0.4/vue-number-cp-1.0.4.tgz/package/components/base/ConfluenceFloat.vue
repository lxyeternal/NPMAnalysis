<template>
  <div class="confluence-container" v-if="showConfluenceFloat && isBuyers">
    <i class="close" @click="showConfluenceFloat = false" title="关闭">×</i>
    <div class="head-icon"> </div>
    <ul>
      <li>大家采知识库</li>
      <li>常见问题搜索既得</li>
      <li><span class="btn" @click="goConfluence">前往</span></li>
      <li><span class="blue" @click="handleClickHowToUse">如何使用大家采知识库></span></li>
    </ul>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import jumpConfluence from "@/mixins/jumpConfluence";
export default {
  mixins: [jumpConfluence],
  props: ['id'],
  components: {
    Loading
  },
  data() {
    return {
      isLoading: false,
      showConfluenceFloat: true,
      isBuyers: false, // 是否为采购商
    }
  },
  mounted() {
    const userInfo = this.$store.state.userInfo
    this.isBuyers = userInfo && userInfo.bs === 'B'
  },
  methods: {
    async goConfluence() {
      this.isLoading = true
      try {
        await this.toConfluence(this.id || '1')
      } catch (error) {
        console.log(error, 'ee---');
        this.$message.error('系统繁忙, 请稍后重试')
      }
      this.isLoading = false
    },
    // 如何使用知识库
    handleClickHowToUse() {
      let item = this.$store.state.bannerList
      item = item.filter(f => f.name === 'conflurence_Banner'),
        item = item && item[0] || {}
      const routeData = this.$router.resolve({
        path: `/${item.jumpPage || ''}`,
        query: {
          url: item.bannerDetailSrc || []
        }
      });
      window.open(routeData.href, "_blank");
    }
  }
}
</script>

<style lang="scss" scoped>
.confluence-container {
  position: fixed;
  right: 50px;
  bottom: 100px;
  width: 160px;
  height: 230px;
  background: #fff;
  box-shadow: 1px 5px 18px rgba(0, 0, 0, 0.15);
  z-index: 4440;
  text-align: center;
  .close {
    position: absolute;
    right: 3px;
    top: 0px;
    color: #bbb;
    font-size: 27px;
    cursor: pointer;
    font-style: normal;
    font-family: inherit;
  }
  .head-icon {
    background: #205081;
    margin: 25px auto 10px;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: url(../../assets/images/icon/confluenceIcon.png) no-repeat;
  }
  ul {
    li {
      font-size: 17px;
      font-weight: bold;
      margin-top: 6px;
      &:nth-child(2) {
        font-size: 14px;
        color: #afafaf;
        font-weight: normal;
        margin-bottom: 22px;
      }
      .btn {
        background: #3472b0;
        color: #fff;
        font-size: 13px;
        text-align: center;
        width: 98px;
        height: 34px;
        line-height: 34px;
        display: block;
        margin: auto;
        font-weight: normal;
        cursor: pointer;
        border-radius: 4px;
      }
      .blue {
        font-size: 12px;
        font-weight: normal;
        cursor: pointer;
      }
    }
  }
}
</style>
