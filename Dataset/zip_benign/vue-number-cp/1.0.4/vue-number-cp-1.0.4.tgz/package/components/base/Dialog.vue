<template>
  <div>
    <div class="dialog-wrap">
      <div class="dialog-cover"  v-if="isShow" @click="closeMyself"></div>
      <transition name="drop">
        <div class="dialog-content"  :class="{'isFile':isShowFile}" v-if="isShow">
          <p class="dialog-close" @click="closeMyself"><span class="remove icon"></span></p>
          <slot>empty</slot>
        </div>
      </transition>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    isShow: {
      type: Boolean,
      default: false
    },
    isShowFile:{
      type: Boolean,
      default: false
    }
  },
  data () {
    return {
      
    }
  },
  methods: {
    closeMyself () {
      this.$emit('on-close')
    }
  }
}
</script>

<style scoped>
.drop-enter-active {
  transition: all .5s ease;
}
.drop-leave-active {
  transition: all .3s ease;
}
.drop-enter {
  transform: translateY(-500px);
}
.drop-leave-active {
  transform: translateY(-500px);
}

.dialog-wrap {
  position: fixed;
  width: 100%;
  height: 100%;
}
.dialog-cover {
  background: #000;
  opacity: .3;
  position: fixed;
  z-index: 5;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
}
.dialog-content {
  width: 50%;
  position: fixed;
  overflow: auto;
  background: #fff;
  top: 20%;
  left: 50%;
  margin-left: -25%;
  z-index: 10;
  border-radius: 10px;
  padding: 2%;
  line-height: 1.6;
}
.dialog-content.isFile{
  padding:30px;
  height:70%;
  top:50%;
  transform: translate(0,-50%);
  -webkit-transform: translate(0,-50%);
  -o-transform: translate(0,-50%);
  -moz-transform: translate(0,-50%);
}
.dialog-close {
  position: absolute;
  right: 5px;
  top: 5px;
  width: 40px;
  height: 40px;
  text-align: center;
  cursor: pointer;
}
.dialog-close:hover {
  color: #4fc08d;
}

.remove.icon {
  color: #000;
  position: absolute;
  margin-left: 3px;
  margin-top: 10px;
}
.remove.icon:before {
      content: '';
    position: absolute;
    width: 20px;
    height: 1px;
    background-color: currentColor;
    -webkit-transform: rotate(45deg);
    transform: rotate(45deg);
    right: 5px;
    top: 6px;
}
.remove.icon:after {
        content: '';
    position: absolute;
    width: 20px;
    height: 1px;
    background-color: currentColor;
    -webkit-transform: rotate(-45deg);
    transform: rotate(-45deg);
    right: 5px;
    top: 5px;
  }
</style>
