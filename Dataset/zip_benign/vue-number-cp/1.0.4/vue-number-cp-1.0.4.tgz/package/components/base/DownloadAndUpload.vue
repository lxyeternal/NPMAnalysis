<template>
  <div class="cont">
    <span class="blue-pointer" @click="handleDownTemp" v-if="hasDownloadFlg">{{downloadName}}</span>
    <span :style="{'margin-left': hasDownloadFlg ? '10px' : '2px'}" v-if="hasUpload">
      <input ref="inputFile" :id="fromId" type="file" @change="handleUpload($event,uploadType)">
      <label class="hand blue f12" :for="fromId">{{uploadName}}</label>
    </span>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import { ImageUtil } from '@/utils/imageUtil';
import Loading from "@/components/base/Loading";

export default {
  name: "downloadAndUpload",
  data() {
    return {
      isLoading: false
    }
  },
  components: {
    Loading
  },
  props: {
    uploadName: {
      type: String,
      default: '上传',
      required: false
    },
    downloadName: {
      type: String,
      default: '下载模板',
      required: false
    },
    hasUpload: {
      type: Boolean,
      default: true,
      required: false
    },
    hasDownloadFlg: {
      type: Boolean,
      default: true,
      required: false
    },
    templateFile: {
      type: Object,
      default: () => ({}),
      required: false
    },
    // type类型
    uploadType: {
      type: String,
      default: '',
      required: true
    },
    // appName类型
    appName: {
      type: String,
      default: 'PROD',
      required: true
    },
    // 上传文件类型
    fileTypeReg: {
      type: RegExp,
      default: null,
      required: false
    },
    // 是否上传图片
    isImg: {
      type: Boolean,
      default: false,
      required: false
    },
    // 上传文件类型错误提示语
    fileTypeErrorMsg: {
      type: String,
      default: '文件类型上传错误',
      required: false
    },
    // 上传文件大小限制
    fileSize: {
      type: Number,
      default: 20971520,
      required: false
    },
    // 上传文件大小超出提示语
    fileSizeErrorMsg: {
      type: String,
      default: "单个附件大小不超过20MB",
      required: false
    },
    //区分是哪一个form-item的上传组件
    fromId: {
      type: String,
      default: "",
      required: false
    },
    // 用于判断文件是否上传重复
    fileList: {
      type: Array,
      default: () => [],
      required: false
    },
    //是否压缩图片
    isCompress: {
      type: Boolean,
      default: false,
      required: false
    },
  },
  methods: {
    handleDownTemp() {
      console.log(this.templateFile)
      this.$download([{
        name: this.templateFile.templateFileName || '',
        url: this.templateFile.url || ''
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    handleUpload(e, uploadType) {
      const file = e.target.files[0];
      if (file) {
        console.log(file, '-file');
        if (this.fileList && this.fileList.some(s => s.attachName == file.name)) {
          this.$message.error('不能上传文件名相同的文件!')
          this.resetInputValue(this.fromId)
          return
        }
        let a = file.name.split(".");
        const fileType = a[a.length - 1];
        const reg = this.fileTypeReg;

        if (this.isImg && (file.type).indexOf("image/") == -1) {
          this.$message.error(this.fileTypeErrorMsg);
          return;
        }
        if (reg) {
          if (!reg.test(fileType)) {
            this.$message.error(this.fileTypeErrorMsg);
            this.resetInputValue(this.fromId)
            return;
          }
        }
        if (file.size > this.fileSize) {
          if(this.isCompress){
            let fileImgList = [file]
            ImageUtil.handleChangeMasterImg(fileImgList, 800, 1000, (files) => {
              this.uploadFiles(uploadType, files[0])
              this.resetInputValue(this.fromId)
            })
            return;
          }else{
            this.$message.error(this.fileSizeErrorMsg);
            this.resetInputValue(this.fromId)
            return;
          }
        }
        if (file) {
          this.uploadFiles(uploadType, file)
        }
        this.resetInputValue(this.fromId)
      }
    },
    /**
     * 重置input value  防止 同一个文件连续提交 不触发 onchange事件
     */
    resetInputValue(id) {
      let isIE10 = false,
        uploadInputs = [document.getElementById(id)];
      console.log(uploadInputs);
      if (window.navigator.userAgent.indexOf('MSIE') >= 1) { // 判断ie10以及以下
        isIE10 = true
      } else {
        isIE10 = false
      }
      for (let i = 0, len = uploadInputs.length; i < len; i++) {
        const element = uploadInputs[i];

        if (isIE10) {
          let form = document.createElement('form'),
            beforInput = element.nextSibling,
            parentInput = element.parentNode

          form.appendChild(element)
          form.reset()
          parentInput.insertBefore(element, beforInput)
        } else {
          element.value = ''
        }
        console.log(element.value);
      }
    },
    uploadFiles(type, file) {
      this.uploadContractToOss(type, file).then(res => {
        let param = {
          ossFile: [{
            fileType: type, filePath: res.url
          }],
          appName: this.appName
        };
        InterfaceService.ossSignatureUrl(param, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let list = data.respData.ossFile || [];
            if (list.length) {
              let form = {};
              form.attachName = file.name;
              form.attachPath = res.url;
              form.attachUrl = list[0].url;
              form.fromId = this.fromId;
              form.uploadType = this.uploadType
              this.$emit('outputValue', form)
            }
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
      })
    },
    uploadContractToOss(type, file) {
      return new Promise((resolve, reject) => {
        InterfaceService.getOssSignatureDisposable(file.name, {
          type: type,
          appName: this.appName
        }, (data, checkTextList) => {
          console.log(data, checkTextList);
          let signature = data;
          this.uploadHander(0, file, new Date().getTime() + '/', signature, (pos, file, dirType, signature) => {
            console.log(signature.dir);
            let u = signature.dir + dirType + file.name;
            console.log(u);
            resolve({ url: u });
            //图片上传到oss之后 提交注册信息
            // setTimeout(() => {
            //   this.isReject ? this.isRejectSubmigCompelet() : this.submitCompelet()
            // }, 800)
          }, () => { this.isLoading = true; }, () => { this.isLoading = false; })
        }, (data) => {
        },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          });
      })

    },
    uploadHander(pos, file, dirType, signature, callBack, loadingStartCb, loadingEndCb) {
      //去后端拿签名
      InterfaceService.uploadToOss(signature, file, dirType, pos, callBack, '', '', loadingStartCb, loadingEndCb)
    },
    open() {
      this.$refs.inputFile.click()
    }
  }
}
</script>

<style scoped lang="scss">
.cont {
  display: inline-block;
}
/deep/ .el-input,
input {
  position: absolute;
  left: -9999px;
  width: 0px;
  height: 0px;
  overflow: hidden;
  opacity: 0;
}
</style>