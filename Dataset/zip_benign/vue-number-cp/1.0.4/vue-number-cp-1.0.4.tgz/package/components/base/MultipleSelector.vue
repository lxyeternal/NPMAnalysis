<template>
  <div class="multiple-selector-content">
    <label class="label" :class="{required:required}" :style="{'width':labelWidth+'px'}">{{label}}：</label>
    <div ref="selector" :class="{'content-active':contentActive}" @click="handleClick" class="selector hand" :style="{'width':width - labelWidth +'px','margin-left':labelWidth +'px',padding:selectedList.length ? '6px 10px 0' : '10px','border-color':errorMsg && checkData && !selectedList.length ? '#F56C6C' : '#ddd'}">
      <span class="placeholder" v-if="!selectedList.length">{{placeholder}}</span>
      <div v-else>
        <span class="selected-list" v-for="(sel,index) in selectedList" :key="index">
          {{sel.label}}<em class="signed" v-if="sel.keyMarkFlg === '1'">标记通过</em>
          <i class="el-icon-close" @click="handleDel(sel,index)"></i>
        </span>
        <div style="clear:both;"></div>
      </div>
      <span class="el-icon-caret-bottom"></span>
    </div>
    <div :style="{left:labelWidth +'px'}" class="el-form-item__error" v-if="errorMsg && checkData && !selectedList.length">{{errorMsg}}</div>
    <div v-if="contentActive" ref="selectOption" class="select-option" :style="{ 'width':this.width - this.labelWidth +'px','margin-left':this.labelWidth +'px'}">
      <div v-if="!selectionList.length" style="color: #bbb;cursor: not-allowed;line-height: 34px;padding-left: 10px;">暂无数据!</div>
      <div v-else>
        <ul>
          <li v-for="(item,index) in selectionList"
              :key="index"
              :class="{checked:item.checked}"
              v-show="item.index >= (pageIndex-1)*pageSize && item.index < pageIndex * (pageSize || 999)"
          >
            <el-checkbox v-model="item.checked" @change="handleSelectTableRow(item,index)"></el-checkbox>
            <span>{{item.label}}<em class="signed" v-if="item.keyMarkFlg === '1'">标记通过</em></span>
          </li>
        </ul>
        <div class="operation">
          <el-checkbox class="fl" v-model="allChecked" @change="handleAllSelectTableRow">全选</el-checkbox>
          <el-pagination v-if="pageSize" class="pagination fl" @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="totalCount" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
          <!--<el-button type="primary" class="small-btn fr" @click="handleAdd">添加</el-button>-->
          <div style="clear:both;"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "MultipleSelector",
    props:{
      labelWidth:{
        type: Number,
        default: 100
      },
      checkedSelectorNum:{
        type: Number,
        default: 100
      },
      label: {
        type: String,
        default: '请选择'
      },
      errorMsg: {
        type: String,
        default: '必填'
      },
      width:{
        type: Number,
        default: 1190
      },
      placeholder:{
        type: String,
        default: '请选择,可多选'
      },
      required:{
        type: Boolean,
        default: false
      },
      pageSize:{
        type:Number,
        default:0
      },
      totalCount:{
        type:Number,
        default:0
      },
      dataList:{
        type: Array,
        default: () => []
      },
    },
    data() {
      return {
        contentActive:false,
        allChecked:false,
        checkData: false,
        pageIndex:1,
        selectedList:[],
        selectionList:[],
      }
    },
    watch:{
      dataList: {
        handler(n,o){
          console.log(this.pageIndex);
          this.selectedList = []
          this.selectionList = JSON.parse(JSON.stringify(n)).sort((b,a)=>{return b.index - a.index})
          this.selectionList.forEach(item=>{
            if (item.checked) {
              this.selectedList.push(item)
            }
          });
          this.checkAllSelect()
          console.log(this.selectionList);
          this.$forceUpdate()
        },
        immediate: true,
        deep: true
      },
      checkedSelectorNum(newVal){
        if (newVal) {
          this.checkData = true
        }
      }
    },
    computed:{
    },
    methods:{
      handleEmit(){
        this.$emit("getData",this.selectedList)
      },
      handleDel(item,index){
        this.contentActive = true;
        this.selectionList.forEach(_item=>{
          if (_item.value === item.value){
            _item.checked = false
          }
        });
        this.checkData = true;
        this.selectedList.splice(index,1);
        this.checkAllSelect();

        this.$emit("getData",this.selectedList)
      },
      handleAdd() {
        // if (!item) {
          this.selectedList = [];
          this.selectionList.forEach(item=>{
            let onOff = false;
            if (item.checked) {
              this.selectedList.forEach(_item=>{
                if (item.value === _item.value){
                  onOff = true
                }
              });
              if (!onOff) {
                this.selectedList.push(item)
              }
            }
          });
        // }else {
        //   let onOff = false;
        //   if (item.checked) {
        //     this.selectedList.forEach(_item=>{
        //       if (item.value === _item.value){
        //         onOff = true
        //       }
        //     });
        //     if (!onOff) {
        //       this.selectedList.push(item)
        //     }
        //   }
        // }

        this.handleEmit()
      },
      // 分页跳转
      handleCurrentChange(page) {
        this.pageIndex = page;
        window.scrollTo(0, 0);
        this.$emit("handleCurrentChange",this.pageIndex)
        // this.getSupplierQAList();
      },
      handleClick(){
        this.contentActive = true
      },
      // 选中行
      handleSelectTableRow(item, index) {
        this.$set(item, 'checked', item.checked);
        this.$set(this.selectionList, index, item);
        this.$forceUpdate()
        // this.checkBatch();
        this.checkAllSelect();
        // if (item.checked == false) {
          this.handleAdd()
        // }
      },
      // 是否全选
      checkAllSelect() {
        let list = this.selectionList.filter(item=>{return item.index >= (this.pageIndex-1)*this.pageSize && item.index < this.pageIndex * (this.pageSize || 999)})
        this.allChecked = list.every(item => {
          return item.checked;
        });
      },
      // 是否可批量
      checkBatch() {
        let list = this.selectionList.filter(item=>{return item.index >= (this.pageIndex-1)*this.pageSize && item.index < this.pageIndex * (this.pageSize || 999)})
        this.hasChecked = list.some(item => {
          return item.checked;
        });
      },
      handleAllSelectTableRow(bool) {
        let arr = [];
        arr = [].concat(this.selectionList.filter(item=>{return item.index >= (this.pageIndex-1)*this.pageSize && item.index < this.pageIndex * (this.pageSize || 999)}));
        arr.forEach(item => {
          item.checked = bool;
        });
        // this.selectionList = arr;
        // this.checkBatch();
        this.handleAdd()
      },
      clickOutSide(ev) {
        // 是否点击在组件内部
        let state = false
        const searchParentNodeClassName = (offsetParentNode) => {
          const cName = offsetParentNode.className
          if (cName.indexOf('multiple-selector-content') != -1 || cName.indexOf('el-scrollbar') != -1) {
            state = true
          }
          if (offsetParentNode.offsetParent) {
            searchParentNodeClassName(offsetParentNode.offsetParent)
          }
        }
        searchParentNodeClassName(ev.target)
        // 如果未点在组件内 关闭 组件选择弹层
        if (!state) {
          this.handleClose()
        }
      },
      handleClose() {
        this.contentActive = false
        this.$emit('update:show', false)
      },
    },
    mounted(){
      this.$nextTick(() => {
        document.addEventListener('keyup', (e) => {
          if (e.keyCode == 27) {
            this.contentActive = false
          }
        })
        document.addEventListener('click', this.clickOutSide, true);
      })
      // this.init()
    }
  }
</script>

<style scoped lang="scss">
  .multiple-selector-content{
    width: 100%;
    margin-bottom: 18px;
    position: relative;
    .el-input{
      position: absolute;
      top: 0;
      right: 0;
      z-index: 99;
      opacity: 0;
    }
    .label{
      float: left;
      width: 100px;
      text-align: right;
      line-height: 34px;
      font-size: 14px;
      color: #888;
    }
    .selector{
      position: relative;
      min-height: 34px;
      border: 1px solid #ddd;
      .placeholder{
        font-size: small;
        color: #bbbbbb;
      }
      .selected-list {
        height: 22px;
        padding: 1px 20px 0 4px;
        background: #C99F4F;
        color: #fff;
        position: relative;
        line-height: 18px;
        float: left;
        margin-right: 6px;
        margin-bottom: 8px;
        .el-icon-close{
          width: 3px;
          height: 3px;
          position: absolute;
          top: 6px;
          right: 12px;
          color: #fff;
          cursor: pointer;
        }
      }
      .el-icon-caret-bottom{
        position: absolute;
        right: 10px;
        top: 14px;
        color: #bbb;
      }
    }
    .content-active{
      border-color: #C99F4F;
    }
    .select-option{
      margin-top: 4px;
      position: absolute;
      border: 1px solid #C99F4F;
      min-height: 34px;
      z-index: 99;
      background: #fff;
      ul{
        li{
          min-height: 34px;
          font-size: 14px;
          padding: 10px;
          span{
            padding-left: 10px;
          }
        }
      }
      .checked{
        background:linear-gradient(130deg,rgba(215,176,100,1) 0%,rgba(236,206,139,1) 100%);
        color: #fff;
      }
    }
    .operation{
      margin-top: 10px;
      border-top: 1px solid #eee;
      height: 46px;
      padding: 10px;
      /deep/ .el-pagination{
        position: absolute;
        text-align: center;
        width: 100%;
        button span,span{
          font-size: 12px;
        }
      }
    }
  }
  .required{
    &::before{
      content: '*';
      color: #F56C6C;
      margin-right: 4px;
    }
  }
.small-btn{
  position: relative;
  z-index: 22;
}
  .signed{
    width: 76px;
    height: 20px;
    line-height: 20px;
    color: #fff;
    font-size: 14px;
    text-align: center;
    background: #830bb9;
    border-radius: 2px;
    margin-left: 4px;
    display: inline-block;

  }
  .el-form-item__error{
    position: absolute;

  }
</style>