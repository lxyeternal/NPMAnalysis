<template>
    <label class="mo-upload">
        <input type="file" :accept="accepts" @change="upload">
        <slot></slot>
    </label>
</template>
<style scoped>
    .mo-upload {
        display: inline-block;
        position: relative;
        margin-bottom: 0;
        
    }
    input[type="file"] {
        display: none;
    }
    .mo-upload--label {
      display: inline-block;
      position: relative;
    }
</style>
<script>
    import { InterfaceService } from '@/services/api'
    import axios from 'axios'
    export default {
        name : 'MoUpload',
        props : {
            accepts : { //允许的上传类型
                type : String,
                default : '*'
            },
            flag : [String, Number], //当前上传标识,以便于在同一个监听函数中区分不同的上传域
            maxSize : {
                type : Number,
                default : 0 //上传大小限制
            }, 
        },
        methods: {
            upload (event) {
                let file = event.target.files[0]
                const self = this
                const flag = this.flag
                if (file) {
                    if (this.maxSize) {
                        //todo filter file
                    }
                    //filter file, 文件大小,类型等过滤
                    //如果是图片文件
                    // const reader = new FileReader()
                    // const imageUrl = reader.readAsDataURL(file)
                    // img.src = imageUrl //在预览区域插入图片

                    const formData = new FormData()
                    formData.append('file', file)
                    //console.log(formData)
                    

                    InterfaceService.exportOrder(formData,(url,jsonparams,reqParams)=>{
                        //创建xhr对象 
                        var xhr = new XMLHttpRequest();
                        //设置xhr请求的超时时间
                        xhr.timeout = 3000;
                        //设置响应返回的数据格式
                        xhr.responseType = "application/json";
                        //创建一个 post 请求，采用异步
                        xhr.open('POST',url+'?jsonparams='+encodeURI(jsonparams), true);
            
                        xhr.setRequestHeader("Content-type","multipart/form-data");
                        //注册相关事件回调处理函数
                        xhr.onload = function(e) { 
                          if(this.status == 200||this.status == 304){
                              alert(this.responseText);
                          }
                        };
                        xhr.ontimeout = function(e) { };
                        xhr.onerror = function(e) { };
                        xhr.upload.onprogress = function(e) { };
                        
                        //发送数据
                        xhr.send(formData);
                        //这种写法 发送请求 会报错
                       //  axios({
                       //      url:url,
                       //      method:'post',
                       //      headers:{'Content-type': 'multipart/form-data'},
                       //      params: {
                       //          jsonparams: jsonparams
                       //      },
                       //      data:reqParams ,//Qs.stringify(reqParams)
                       //      withCredentials:true
                       //  })
                       // .then(doneCallbacks,failCallbacks);
                      
                       //  function doneCallbacks(resp){
                       //      requestDone = true;
                       //      let data = resp.data;
                       //      self.$emit('uploadError')
                       //  }

                       //  function failCallbacks(resp){
                       //      requestDone = true;
                       //      self.$emit('uploadError')
                       //  }

                    
                    });


                }
            }
        }
    }
</script>