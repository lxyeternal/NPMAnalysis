<template>
  <div>
    <!-- 快速选型采购 - 选择供应商1 -->
    <el-dialog class="dialog dialog-drafts quick-purchase-dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="showDia" width="840px" center @close="diaClosed" :close-on-click-modal="false">
      <!--<div v-if="showDia1">-->
        <!--<div class="drafts-list">-->
          <!--&lt;!&ndash;<img src='@/assets/images/point/point1.png'>&ndash;&gt;-->
          <!--<img :src="imgSrc">-->
        <!--</div>-->
        <!--<div slot="footer" class="dialog-footer">-->
          <!--<el-button type="primary" size="small" style="width: 100px" @click="handleClick(1)">下一步</el-button>-->
        <!--</div>-->
      <!--</div>-->
      <!--<div v-if="showDia2">-->
        <!--<div class="drafts-list">-->
          <!--<img src='@/assets/images/point/point2.png'>-->
          <!--<label class="unnotice" v-if="!forceState">-->
            <!--<el-checkbox v-model="targetValue"></el-checkbox> 我已阅读本操作指引, 下次不再提醒。-->
          <!--</label>-->
        <!--</div>-->
        <!--<div slot="footer" class="dialog-footer">-->
          <!--<el-button type="primary" size="small" style="width: 100px" @click="handleConfirm(nextBtnName)">去采购</el-button>-->
          <!--<el-button size="small" style="width: 100px" @click="handleClick(2)">上一步</el-button>-->
          <!--<el-button size="small" style="width: 100px" @click="diaClosed">关闭</el-button>-->
        <!--</div>-->
      <!--</div>-->
      <div v-if="showDia1" v-for="(src,index) in filerList(imgSrcList,currentIndex)" >
      <!--<div v-if="showDia1" v-for="(src,index) in imgSrcList[currentIndex]" >-->
        <div>
          <!--<img src='@/assets/images/point/point1.png'>-->
          <img :src="src">
          <label class="unnotice" v-if="!forceState && imgNum === currentNum">
            <el-checkbox v-model="targetValue"></el-checkbox> 我已阅读本操作指引, 下次不再提醒。
          </label>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button v-if="currentNum < imgNum" type="primary" size="small" style="width: 100px" @click="handleClick('next',index)">下一步</el-button>
          <el-button v-if="currentNum === imgNum && imgPath === 'batchOrder'" type="primary" size="small" style="width: 100px" @click="handleConfirm(nextBtnName)">去采购</el-button>
          <el-button v-if="currentNum <= imgNum && currentNum > 1"  size="small" style="width: 100px" @click="handleClick('previous',index)">上一步</el-button>
          <el-button v-if="currentNum === imgNum && imgPath === 'batchOrder'"  size="small" style="width: 100px" @click="diaClosed">关闭</el-button>
          <el-button v-if="currentNum === imgNum && imgPath !== 'batchOrder'" type="primary"  size="small" style="width: 100px" @click="diaClosed">知道了</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import Loading from '@/components/base/Loading'
import { InterfaceService } from '@/services/api'
export default {
  props: [
    'value',
    'imgUrl',
    'hideConfirm',
    'cancelBtnName',
    'targetId',
    'targetKey',
    'forceState',
    'imgPath',
    'imgNum',
    'nextBtnName'
  ],
  data() {
    return {
      isLoading: false,
      showDia: false,
      showDia1: true,
      showDia2: false,
        // imgPath: this.imgUrl || '',
      targetValue: false,
      currentIndex: 0,
      currentNum: 1,
      imgSrcList:[]
      // imgSrc: require('@/assets/images/point/point1.png')
    }
  },

  async mounted() {
      for (let i = 1; i <= this.imgNum; i++) {
          this.imgSrcList.push(require('@/assets/images/point/'+this.imgPath+'/point'+i+'.png'))
      }
      console.log(this.imgSrcList);
      if (this.forceState) {
        this.showDia = true;
        return
      }

    const result = await this.getCacheInfos() || {}
    // 如果有值 说明不再提示
    if (result.value == 'true' && !this.forceState) {
      this.$emit('input', false)
      this.$emit('close', false)
      this.$emit('output', true)
      return
    }

    this.showDia = true
  },
  methods: {
    // handleClick(state) {
    //   if (state === 1) {
    //     this.showDia1 = false
    //     this.showDia2 = true
    //   }
    //   if (state === 2) {
    //     this.showDia2 = false
    //     this.showDia1 = true
    //   }
    // },
      handleClick(step,ind) {
          console.log(ind);
          if (step === "next") {
              this.currentIndex++;
              this.currentNum++
          }else {
              this.currentIndex--;
              this.currentNum--
          }

      },
    diaClosed() {
      this.$emit('close', false)
      this.showDia = false
      !this.forceState && this.UpdateCacheInfos()
      this.$emit('update:targetValue', false)
    },
      filerList(list,currentIndex) {
        return list.filter((item,ind)=>{
            return ind === currentIndex
        })
      },
    handleConfirm(handleConfirm) {
      this.$emit('output', handleConfirm)
        this.showDia = false
      this.$emit('input', handleConfirm)
      this.diaClosed()
    },
    cancel() {
      this.showDia = false
    },

    /**
     * 获取登录计数
     */
    getCacheInfos() {
      return new Promise(resolve => {
        let params = {
          targetId: this.targetId || '',
          key: this.targetKey || ''
        };
        InterfaceService.getCacheInfos(params, data => {
          if (data.respData.respCode === "0000") {
            resolve(data.respData)
          } else {
            this.$message.error(data.respData.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },

    /**
     * 存储计数
     */
    UpdateCacheInfos() {
      let params = {
        userCaches: [{
          targetId: this.targetId || '',
          key: this.targetKey || '',
          value: this.targetValue || false,
        }]
      }
      InterfaceService.UpdateCacheInfos(params, data => {
        if (data.respData.respCode === "0000") {
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      });
    },
  },
}
</script>
<style lang="scss" scoped>
.quick-purchase-dialog {
  img {
    width: 100%;
    display: block;
  }
  /deep/ .el-dialog__header {
    padding: 0;
    &:before{
      height: 0;
    }
    /*padding-top: 2px;*/
    .el-dialog__headerbtn .el-dialog__close {
      margin-right: 6px;
      color: #fff;
    }
  }
  /deep/ .el-dialog__body{
    padding: 0 0 20px 0 !important;
  }
  .dialog-footer {
    text-align: center;
    margin: 12px;
  }
  .unnotice {
    text-align: left;
    background: #eeeeee;
    display: block;
    line-height: 28px;
    padding: 2px 8px 1px;
    width: 800px;
    margin-left: 20px;
  }
}
</style>

