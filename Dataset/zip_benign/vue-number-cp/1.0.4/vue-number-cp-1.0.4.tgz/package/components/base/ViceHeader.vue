<template>
  <div class="checkorder-search">
    <p class="checkorder-search-title">{{title}}</p>
    <div class="checkorder-search-right">
      <em v-for="item,index in flow" :key="index">
        <span class="step-two" :class="{'active':item.active}">{{index+1}}</span>
        <span class="step-two-text" :class="{'active':item.active}">{{item.name}}</span>
        <span class="step-bar" v-if="item.next">
          <div></div>
        </span>
      </em>
    </div>
  </div>
</template>

<script>
export default {
  props:{
    title:{
      type: String
    },
    flow:{
      type: Array
    }
  },
  data () {
    return {
    }
  }
}
</script>

<style scoped>
.checkorder-search{
  padding-left: 300px;
  height: 100%;
  width: 100%;
  background-color:transparent;
}
.checkorder-search-title{
  float: left;
  height: 126px;
  line-height: 126px;
  font-size: 16px;
  color: #4f525a;
  font-weight: bold;
}
.checkorder-search-right{
  float: right;
  height: 126px;
  line-height: 126px;
}
.step-one,.step-two{
  width: 25px;
  height: 25px;
  background: #4f525a;
  color: #ffffff;
  display: inline-block;
  line-height: 25px;
  text-align: center;
  border-radius: 50%;
}
.step-two{
  background: #bbbbbb;
}
.step-two.active{
  background: #4f525a;
}
.step-two-text{
  color: #bbbbbb;
}
.step-two-text.active{
  color: #4f525a;
}
.step-bar{
  display: inline-block;
  height: 25px;
  width: 78px;
  vertical-align: middle;
  position: relative;
  margin:0 8px;
}
.step-bar div{
  position: absolute;
  width: 100%;
  height: 2px;
  background: #bbbbbb;
  top: 11px;
}
</style>
