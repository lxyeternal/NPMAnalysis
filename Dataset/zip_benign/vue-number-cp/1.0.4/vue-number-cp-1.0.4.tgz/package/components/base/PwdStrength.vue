<!-- 组件使用 <PwdStrength :pwd="" :type="" @received="getPwdStrength"></PwdStrength> -->
<template>
  <div>
      <!-- 注册 强弱色块为大号色块 -->
      <div class="check-strength" v-if="!type" >
        <span :class="{'active':strength >= 1}">弱</span><span :class="{'active':strength >= 2}">中</span><span :class="{'active':strength == 3}">强</span>
      </div>
      <!-- 悬浮框 强弱色块为小号色块 -->
      <div class="check-strength mini" v-if="type && type == 'mini'" >
        <span>密码强度</span><span :class="{'active':strength >= 1}"></span><span :class="{'active':strength >= 2}"></span><span :class="{'active':strength == 3}"></span>
      </div>
  </div>
</template>

<script>
export default {
  props: {
    pwd: {
      type: String,
      default: ''
    },
    type:{
      type: String,//默认为空 则是大色块表示 "mini":小号色块
      default: ''
    }
  },
  data () {
    return {
       strength:'',
       instant:''
    }
  },
  watch: {
    pwd (val) {
      if (val) {
        this.checkPwd(val)
      }else{
        this.strength = '';
        this.instant = ''
        this.$emit('instant',this.instant);
        this.$emit('received',this.strength);
      }
    },
  },
  methods:{
    checkPwd: function(pwd) {
      // 弱 ：全字母 或者 全数字
      // 中 ：字母加数字
      // 强 ：字母加数字加大写
      let reg1 = /(^\d{6,}$)|(^[A-Z]{6,}$)|(^[a-z]{6,18}$)/;
      let reg2 = /^(?=.*[a-z])(?=.*\d)[^]{6,18}$/
      let reg22 = /^(?=.*[A-Z])(?=.*\d)[^]{6,18}$/
      let reg3 = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[^]{6,18}$/ //至少1个大写字母，1个小写字母和1个数字
      if(!pwd){
        this.strength = '';
        this.instant = ''
        this.$emit('instant',this.instant);
        this.$emit('received',this.strength);
        return
      }

      //密码实时验证
      let reg4 = /^(?!([a-zA-Z]+|\d+)$)[a-zA-Z\d]{1,18}$/;  //数字字母
      let reg5 = /^(?!([a-zA-Z]+|\d+)$)[a-zA-Z\d]{6,18}$/; //6-18位 数字字母

      this.instant = '';
       
      if(reg4.test(pwd)){
        if(reg5.test(pwd)){
          //console.log('111')
          this.instant = 2;
          //通知父级
          //this.$emit('instant',this.instant);
         
        }else{
          //console.log('222')
          this.instant = 1;
          //通知父级
          //this.$emit('instant',this.instant);
        }
      }
      //通知父级
      this.$emit('instant',this.instant);

      this.strength = 1;
      //密码强度
      if(reg3.test(pwd)){
      
        this.strength = 3;
        //通知父级
        this.$emit('received',this.strength);
        return 
      }
      if(reg2.test(pwd) || reg22.test(pwd)){
       
        this.strength = 2;
        //通知父级
        this.$emit('received',this.strength);
        return
      }
      if(reg1.test(pwd)){
        this.strength = 1;
        //通知父级
        this.$emit('received',this.strength);
        return
      }
      this.$emit('received',this.strength);
    },
  
  },
  mounted () {
    
  }
}
</script>

<style scoped>
.check-strength{width: 100%;height: 100%}
.check-strength span{display: inline-block;width: 31.9%;height: 100%;background-color: #eeeeee;color:#444;font-size: 12px;text-align: center; margin-right: 10px;}
.check-strength.mini{position: relative;}
.check-strength.mini span{width: 40px;height: 4px;position: relative;top:-2px;}
.check-strength.mini span:first-child{width:60px;background: #fff;font-size: 12px;color: #888;top:0;}
.check-strength span:last-child{margin-right: 0}
.check-strength span.active{background: linear-gradient(120deg,rgba(215,176,100,1) 0%,rgba(236,206,139,1) 100%);color: #fff;}
</style>
