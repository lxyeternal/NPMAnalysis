<template>
    <label class="mo-upload">
        <!--点击按钮触发图片统一上传-->
        <button @click="uploadimg">upload</button>
        <mavon-editor ref=md @imgAdd="$imgAdd" @imgDel="$imgDel" v-model="value" :imgFilter="checkFile"></mavon-editor>

        <div style="width:200px;height:200px; position: relative;">
            <input type="file" @change="uploadFile">
            <div class="preview-box">
                <img alt="" :src="previewSrcr" v-if="previewSrcr">
            </div>
        </div>
        
    </label>
</template>

<script>
    import { InterfaceService } from '@/services/api'
    import { mavonEditor } from 'mavon-editor'
    import 'mavon-editor/dist/css/index.css'
    export default {
        components: { 
            mavonEditor
        },
        props : {
             
        },
        data(){
            return {
                img_file:{},
                value:'',
                expire:'',
                previewSrcr:''
            }
        },
        methods: {
            // 绑定@imgAdd event
            $imgAdd(pos, $file){
                // 缓存图片信息
                console.log($file)
                this.img_file[pos] = $file;
                console.log(JSON.stringify(this.img_file))
               
            },
            $imgDel(pos){
                delete this.img_file[pos];
            },
            uploadimg($e){ //编辑器获取文件 上传
                let _this = this;
                console.log(_this.img_file)
                for(var pos in _this.img_file){
                    console.log(pos)
                    let file =  _this.img_file[pos]
                    _this.uploadHander(pos,file,(pos,file,dirType,signature)=>{
                        console.log(signature)
                        let u = signature.host+'/'+signature.dir+dirType+'/'+file.name
                        console.log(u)
                        _this.$refs.md.$img2Url(pos,u)
                    })
                    
                    
                }
            },
            uploadFile(event){//input控件（自定义）获取文件 上传
                let _this = this;
                let file = event.target.files[0]
                let reader  = new FileReader();
                reader.onloadend = function () {
                    _this.previewSrcr = reader.result;

                }
                if (file) {
                    reader.readAsDataURL(file);
                } else {
                    _this.previewSrcr = "";
                }

                _this.uploadHander(0,file)
            },
            uploadHander(pos,file,callBack){
                let _this = this;
                //去后端拿签名
                InterfaceService.getOssSignature({}, (data) => {
                    InterfaceService.uploadToOss(data,file,'',pos,callBack)
                }, (data) => {

                });
            },
            checkFile(){

            }
        }
    }
</script>
<style scoped>
    .mo-upload {
        width:1000px;
        display: inline-block;
        position: relative;
        margin-bottom: 0;
        
    }
    input[type="file"] {
       width: 200px;height: 200px;
    }
    .mo-upload--label {
      display: inline-block;
      position: relative;
    }
    .preview-box{
        position:absolute;width:100%;height:100%;top:0;left:0;border:1px solid #ddd;background:#fff;
        pointer-events:none;
    }
    .preview-box:before{
        position: absolute;
        content: '';
        width: 100px;
        height: 1px;
        background-color: #ddd;
        top:50%;
        left:50%;
        margin-left: -50px;
    }
    .preview-box:after{
        position: absolute;
        content: '';
        width: 1px;
        height: 100px;
        background-color: #ddd;
        top:50%;
        left:50%;
        margin-top: -50px;
    }

    .preview-box img{width: 198px;margin:0 auto;}
</style>