<template>
  <div v-if="addFormVisible">
    <el-dialog title="添加用户" :visible.sync="addFormVisible" width="840px" class="addUser" :close-on-click-modal="false" @close="addCancle">
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px">
        <el-form-item label="姓名：" prop="acctName">
          <el-input v-model="ruleForm.acctName" placeholder="请输入真实姓名" v-popover:popoverAcct clearable></el-input>
        </el-form-item>
        <el-form-item label="身份证号：" prop="certNo">
          <el-input type="text" v-model="ruleForm.certNo" placeholder="请输入身份证号" clearable  @blur="upperCase('ruleForm')"></el-input>
        </el-form-item>
        <el-form-item label="手机号：" prop="mobile">
          <el-input type="text" v-model="ruleForm.mobile" placeholder="请输入手机号" clearable></el-input>
        </el-form-item>
        <el-form-item label="邮箱：" prop="email">
          <el-autocomplete ref="autocomplete" :fetch-suggestions="querySearch" :trigger-on-focus="false" v-model="ruleForm.email" placeholder="请输入邮箱" clearable></el-autocomplete>
        </el-form-item>
        <el-form-item label="部门：" prop="dept">
          <el-input v-model="ruleForm.dept" placeholder="请输入部门" clearable :maxlength="40"></el-input>
        </el-form-item>
        <el-form-item label="职务：" prop="title">
          <el-input v-model="ruleForm.title" placeholder="请输入职务" clearable></el-input>
        </el-form-item>
        <el-form-item label="分配角色：" prop="role">
          <el-select multiple v-model="ruleForm.role" placeholder="请选择角色" ref="select" class="selected">
            <el-option v-for="(item,index) in roleList" :disabled="item.value === targetRole"  :key="index" :label="item.label" :value="item.value"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" size="small" style="width: 100px" @click="addSubordinate('rules');">保存</el-button>
          <el-button size="small" style="width: 100px" @click="addCancle">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>

  </div>
</template>

<script>
  import { InterfaceService } from "@/services/api";
  import Loading from "@/components/base/Loading";

  const form = {
    acctName: '',
    mobile: '',
    email: '',
    certNo:'',
    title:'',
    dept:'',
    role: [],
  };

  export default {
    name: "AddNewPerson",
    components:{
      Loading
    },
    computed:{
      role() {
        return this.$store.state.userInfo
          ? this.$store.state.userInfo.bs
          : 0;
      },
    },
    data() {

      return　{
        addFormVisible:false,
        isLoading:false,
        ruleForm:JSON.parse(JSON.stringify(form)),
        roleList:[],
        targetRole:'',
        type:'',
        rules:{}
      }
    },
    methods:{
      querySearch(queryString, callback) {
        let commonMailbox = this.$commonMailbox()
        let results = this.$clone(commonMailbox)
        let value = ''
        if(queryString && queryString.indexOf('@') != -1){
          value = queryString.substring(0, queryString.indexOf('@'))
        }else{
          value = queryString
        }
        results.forEach((i,index) =>{
            i.value = value + '' + commonMailbox[index].value
        })
        callback(results)
        this.$refs.autocomplete.handleFocus()
      },
      open(roleList,info,targetRole,type) {
        console.log(this.role);
        const validataMobile = (rule, value, callback) => {
          // console.log(value)
          let mobileReg = /^[1][0-9]{10}$/;
          if (value === '') {
            callback(new Error('请输入手机号'));
          } else {
            if (!mobileReg.test(this.ruleForm.mobile)) {
              callback(new Error('手机号格式不正确'));
            }
            callback();
          }
        };
        const validataCertNo = (rule, value, callback) => {
          let certNoReg = this.$commonExpression('certNo'); // /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
          if (value === '') {
            callback(new Error('请输入身份证号'));
          } else {
            if (!certNoReg.test(this.ruleForm.certNo) && this.ruleForm.certNo) {
              callback(new Error('身份证号格式不正确'));
            }
            callback();
          }
        };
        const validataName = (rule, value, callback) => {
          let nameReg = this.$commonExpression('account');
          if (value === '') {
            callback(new Error('请输入姓名'));
          } else if (!nameReg.test(this.ruleForm.acctName)){
            callback(new Error('姓名设置不符合要求'));
          }
          callback();
        };
        const validataNameP = (rule, value, callback) => {
          let nameReg = this.$commonExpression('account');
          if (value === '') {
            callback(new Error(' '));
          } else if (!nameReg.test(this.ruleForm.acctName)){
            callback(new Error(' '));
          }else if(nameReg.test(this.ruleForm.acctName)){
          }
          callback();
        };
        this.rules= {
          acctName: [{
            required: true,
            validator: validataName,
            trigger: ['blur']
          },{
            validator: validataNameP,
            trigger: ['change']
          },{
            max:200,
            message: "姓名不得大于200个字",
            trigger: "blur" }],
            mobile: [
            {
              required: true,
              validator: validataMobile,
              trigger: 'blur'
            }],
            certNo: [
            {
              required: this.role === "S",
              validator: validataCertNo,
              trigger: 'blur'
            }],
            email: [{
            required: this.role === "S",
            type: 'email',
            message: '请输入正确的邮箱地址',
            trigger: ['blur', 'change']
          },{
            max:64,
            message: "邮箱不得大于64个字",
            trigger: "blur"
          }
          ],
            title: [{
            required: false
          }, {
            max:40,
            message: "职务不得大于40个字",
            trigger: "blur"
          }],
            role: [{
            required: true,
            type:"array",
            message: '请选择角色',
            trigger:  ['change']
          }]
        },
        console.log(roleList);
        this.addFormVisible = true;
        this.roleList = roleList;
        this.targetRole = targetRole || "";
        this.type = type || "";
        this.ruleForm = Object.assign(this.ruleForm,info)
        console.log(this.ruleForm);
        let unDelRoleName = ""
        this.roleList.forEach(item=>{
          console.log(item.value,this.ruleForm.role[0]);
          if (item.value === this.ruleForm.role[0]) {
            unDelRoleName = item.label
          }
        });
        setTimeout(()=>{
          this.$nextTick(()=>{
            let selectIconClass =  this.$refs["select"].$el.firstChild.childNodes[1].childNodes;
            for(let i in selectIconClass){
              let text = selectIconClass[i].innerText;
              console.log(text);
              // roleIds.forEach(item=>{
                if (text　===　unDelRoleName) {
                  let icon = selectIconClass[i].lastChild;
                  let classVal = icon.getAttribute("class");
                  icon.setAttribute("class",classVal.replace("el-icon-close",""));
                }
            }
          })

        },200)
      },
      upperCase(){
        this.ruleForm.certNo = this.ruleForm.certNo && this.ruleForm.certNo.toUpperCase();
      },
      addCancle() {
        this.addFormVisible = false;
        this.$refs.ruleForm.resetFields();
        this.ruleForm = JSON.parse(JSON.stringify(form))
      },
      // 新增公司下属账户信息
      addSubordinate(rules) {
        this.errorMsg = {};
        console.log(this.$refs.ruleForm);
        this.$refs.ruleForm.validate((valid) => {
          if (valid) {
            let params = {
              'roleIds': this.ruleForm.role,
              'acctName': this.ruleForm.acctName,
              'mobile': this.ruleForm.mobile,
              'email': this.ruleForm.email,
              'certNo':this.ruleForm.certNo,
              'title':this.ruleForm.title,
              'dept':this.ruleForm.dept,
            };
            console.log(params);
            InterfaceService.addSubordinate(
              params,
              data => {
                let res = data.respData
                if(res.respCode == '0000'){
                  this.addFormVisible = false;
                  this.$message.success("添加用户成功！");
                  this.$refs.ruleForm.resetFields();
                  this.$emit("saveSuccess",this.ruleForm.acctName,this.type);
                }else{
                 if(res.respCode == 'MEM0094'){
                    // 账号未激活
                    this.$alert(
                      "账号未激活",
                      {
                        customClass: "btn-alert",
                        center: true,
                        confirmButtonText: "知道了",
                        callback: action => {}
                      }
                    );
                  } else if(res.respCode == 'MEM0030'){
                    // 账号冻结
                    this.$alert(
                      "账号冻结",
                      {
                        customClass: "alert-box",
                        center: true,
                        confirmButtonText: "知道了",
                        callback: action => {}
                      }
                    );
                  }else{
                    this.$message.error(res.respMsg);
                  }
                }
              },
              data => {},
              () => {
                this.isLoading = true;
              },
              () => {
                this.isLoading = false;
              }
            );
          } else {
            console.log('error submit!!');
          }
        });
      },
    }
  }
</script>

<style scoped lang="scss">
  .addUser {
    /deep/ .el-dialog__title {
      font-size: 14px;
    }
    /deep/ .el-form {
      margin:0 140px;
    }
    /deep/ .el-form-item__content {
      width: 400px;
    }
    /deep/ .el-form-item__label {
      font-size: 12px;
    }
    /deep/ .el-input__inner {
      width: 400px;
    }
    /deep/ .el-button--primary {
      margin-left: 30px;
    }

  }
.selected{
  .el-select-dropdown__item .selected,.hover{
    color: #fff !important;
  }
}
</style>