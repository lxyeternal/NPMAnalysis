<template>
  <div class="page-select-container">
    <el-select :popper-class="'page-select-dropdown'" :filterable="filterable" :remote="filterable" :remote-method="remoteMethod" :value="selectItem.label" :title="selectItem.label" @change="handleChange" placeholder="请选择" clearable :disabled="disabled">
      <el-option-group>
        <el-option v-for="item in dataList" :key="item.value" :label="item.label" :value="item" :title="item.label">
          <slot name="option" :options="dataList"></slot>
        </el-option>
        <li class="table-pagination" v-if="pageInfo.pageSize && dataList && dataList.length">
          <el-pagination @current-change="handleCurrentChange" :currentPage="pageInfo.pageIndex" :pageSize="pageInfo.pageSize" :total="pageInfo.pageTotal" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </li>
      </el-option-group>
    </el-select>

  </div>
</template>

<script>
import { InterfaceService } from '@/services/api'
import accountMixin from "@/mixins/account";
export default {
  mixins: [accountMixin],
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    pageType: { // 分页类型 前端(frontEnd)/后端(默认 backEnd)
      type: String,
      default: 'backEnd'
    },
    value: { // 值
      type: String,
      default: ''
    },
    disabled: { // 置灰 默认不置灰
      type: Boolean,
      default: false
    },
    filterable: { // 远程搜索
      type: Boolean,
      default: false
    },
    dataList: { // 数据list
      type: Array,
      default() { return [] }
    },
    pageInfo: { // 分页信息
      type: Object,
      default() {
        return {
          pageIndex: 1,
          pageSize: 10,
          pageTotal: 1,
        }
      }
    },
    popSelectItem: { // 选中item 反显
      type: Object,
      default() {
        return {}
      }
    },
  },
  data() {
    return {
      selectItem: {},
    }
  },
  watch: {
    popSelectItem() {
      this.selectItem = this.$clone(this.popSelectItem)
    }
  },

  methods: {
    // 远程搜索
    remoteMethod(query) {
      this.$emit('getDataList', query)
    },

    handleChange(el) {
      el = el || {}
      this.selectItem = el
      this.$emit('change', el.value || '')
    },
    handleCurrentChange(pageIndex) {
      this.pageInfo.pageIndex = pageIndex
      this.$emit('currentChange', this.pageInfo)
    },
  },
}
</script>

<style lang="scss" scoped>
.page-select-container {
}
</style>
<style lang="scss">
.page-select-dropdown {
    border-color: #c99f4f;
  ::-webkit-scrollbar {
    width: 0;
  }
  .popper__arrow {
    border-bottom-color: #c99f4f !important;
  }
  .el-select-group__wrap {
    & > li::nth-child(2) {
      height: 340px;
    }
  }
  .el-select-dropdown__wrap {
    max-width: 1010px;
    max-height: 420px;
    overflow: hidden;
    margin: 0 10px !important;
  }
  .table-pagination {
    text-align: center;
    color: #888888;
    border-top: 1px solid #eee;
    padding: 10px 0;
    margin: 0;
  }
}
</style>

