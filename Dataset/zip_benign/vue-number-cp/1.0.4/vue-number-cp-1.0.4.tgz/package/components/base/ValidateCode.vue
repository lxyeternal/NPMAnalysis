<!-- 组件使用 <ValidateCode :is-show-validate="isShowValidate" @received="getCode"></ValidateCode> -->
<template>
  <div class='validate-code' :class="{'visible':isShowValidate}">
        <!-- <input
        type="tel" 
        ref="input"
        v-model="validateCode"
        placeholder="请输入验证码"
        @keyup="handleInput($event)"
        @blur="handleInput($event)"
        :maxlength="number"
        > -->
        <el-input
          type="tel" 
          placeholder="请输入验证码"
          v-model="validateCode"
          @keyup.native="checkPwd($event)"
          @keyup.enter.native="checkPwd($event,'enter')"
          clearable>
        </el-input>
        <img :src="imgUrl" class="code" @click = "changeCode">
  </div>
</template>

<script>
export default {
  props: ['isShowValidate','update'],
  data () {
    return {
        number:4,
        imgUrl: this.$getConfig().IMAGE_SERVLET+'?v=' + Math.random(),
        validateCode:''
    }
  },
  watch: {
    update (val) {
      if (val) {
        this.imgUrl = this.$getConfig().IMAGE_SERVLET+ '?v=' + Math.random();
        console.log(this.imgUrl)
        this.validateCode = ''
        this.$emit('received',this.validateCode);
      }
    },
  },
  methods:{
    checkPwd(ev,type){
      this.validateCode =this.validateCode.replace(/\D+/, '')
      if(this.validateCode.length >= this.number){
        this.validateCode = this.validateCode.substr(0,4)
        this.$emit('received',this.validateCode,type);
      }else{
        this.$emit('received','');
      }

    },
    // handleInput:function(e){
    //     this.$emit('received',this.validateCode);
    // },
    changeCode(){
      this.imgUrl = this.$getConfig().IMAGE_SERVLET+ '?v=' + Math.random();
      console.log(this.imgUrl)
    }
    
  },
  mounted () {
    //console.log('v')
  }
}
</script>

<style scoped>
.validate-code{position:relative;height:100%;width: 100%;}
.validate-code input{
    width: 100%;
    height: 34px;
    border: 1px solid #ddd;
    font-size: 12px;
    text-indent: 20px;
    box-sizing: border-box;
}
.validate-code img{ height: 90%; position: absolute; top: 50%; right: 2px;transform: translate(0,-50%);-webkit-transform: translate(0,-50%);-o-transform: translate(0,-50%);}

.validate-code input:focus{border-color:#ffd64e;}
</style>
