<template>
  <div class="multiple-selector-content">
    <label class="label" :class="{required:required}" :style="{'width':labelWidth+'px'}">{{label}}：</label>
    <!-- <div ref="selector" :class="{'content-active':contentActive}" @click="handleClick" class="selector hand" :style="{'width':width - labelWidth +'px','margin-left':labelWidth +'px',padding:selectedList.length ? '6px 10px 0' : '10px','border-color':errorMsg && checkData && !selectedList.length ? '#F56C6C' : '#ddd','padding': paddingHight + 'px 15px'}"> -->
    <div ref="selector" :class="{'content-active':contentActive,'disabled':disabled}" @click="handleClick" class="selector hand" :style="{'width':width - labelWidth +'px','margin-left':labelWidth +'px','border-color':errorMsg && !selectedList.length ? '#F56C6C' : '#ddd','padding': paddingHight + 'px 15px'}">
      <span class="placeholder" v-if="!selectedList.length">{{placeholder}}</span>
      <div v-else>
        <template v-if="selectedList.length !== cacheDataList.length">
          <span class="selected-list" v-for="(sel,index) in selectedList" :key="index">
            {{sel.projectName}}{{sel.projectStageName ? (' '+sel.projectStageName) : ''}}
            <i class="el-icon-close" @click="handleDel(sel,index)"></i>
          </span>
          <div style="clear:both;"></div>
        </template>
        <span v-else class="f12">全部</span>
      </div>
      <span class="el-icon-caret-bottom"></span>
      <!-- 置灰不可选 -->
      <!-- <div class="disabled"></div> -->
    </div>
    <!-- <div :style="{left:labelWidth +'px'}" class="el-form-item__error" v-if="errorMsg && checkData && !selectedList.length">{{errorMsg}}</div> -->
    <div :style="{left:labelWidth +'px'}" class="el-form-item__error" v-if="errorMsg && !selectedList.length">{{errorMsg}}</div>
    <div v-if="contentActive" ref="selectOption" class="select-option" :style="{ 'width': (selectWidth || (width - labelWidth)) +'px'}">
      <div class="search">
        <el-input v-if="isSearch" v-model.trim="searchKey" placeholder="请输入项目名称搜索" maxlength="64" clearable @input="searchFilter" @clear="searchFilter"></el-input>
      </div>
      <div class="tc" v-if="!selectionList.length" style="color: #bbb;cursor: not-allowed;line-height: 34px;padding-left: 10px;">暂无数据!</div>
      <div v-else>
        <el-checkbox style="margin: 0px 0px 10px 10px" v-if="isCheckedAllData && !searchKey" v-model="checkedAllData" @change="handleCheckedAllData">全部</el-checkbox>
        <ul>
          <li v-for="(item,index) in selectionList" :key="index" :class="{checked:item.checked}">
            <div v-if="(pageIndex-1)*pageSize<=index && index < pageIndex * (pageSize || 999)">
              <el-checkbox v-model="item.checked" @change="handleSelectTableRow(item,index)"></el-checkbox>
              <div>
                <span :title="item.projectName" :style="'width:calc('+selectOption1+'% - 10px)'" class="ellipsisOne">{{item.projectName}}</span>
                <!-- <span :title="item.groupCompanyName" :style="'width:'+selectOption2+'%'" class="ellipsisOne" v-if="item.groupCompanyName || item.projectStageName">{{item.groupCompanyName}}</span> -->
                <span :title="item.projectStageName" :style="'width:'+selectOption3+'%'" class="ellipsisOne" v-if="item.projectStageName">{{item.projectStageName}}</span>
              </div>
            </div>
          </li>
        </ul>
        <div class="operation">
          <el-checkbox class="fl" v-model="allChecked" @change="handleAllSelectTableRow">全选</el-checkbox>
          <el-pagination v-if="pageSize" class="pagination fl" @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="totalCountReal" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
          <!--<el-button type="primary" class="small-btn fr" @click="handleAdd">添加</el-button>-->
          <div style="clear:both;"></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "MultipleSelector",
  props: {
    labelWidth: {
      type: Number,
      default: 100
    },
    // checkedSelectorNum: {
    //   type: Number,
    //   default: 100
    // },
    label: {
      type: String,
      default: '请选择'
    },
    errorMsg: {
      type: String,
      default: ''
    },
    width: {
      type: Number,
      default: 1190
    },
    paddingHight: {
      type: Number,
      default: 10
    },
    placeholder: {
      type: String,
      default: '请选择,可多选'
    },
    required: {
      type: Boolean,
      default: false
    },
    pageSize: {
      type: Number,
      default: 0
    },
    totalCount: {
      type: Number,
      default: 0
    },
    dataList: {
      type: Array,
      default: () => []
    },
    isSearch: {
      type: Boolean,
      default: false
    },
    isCheckedAllData: {
      type: Boolean,
      default: true
    },
    selectWidth: {
      type: Number,
    },
    disabled: {
      type: Boolean,
      default: false
    },
    selectOption1: {
      type: Number,
      default: 50
    },
    selectOption2: {
      type: Number,
      default: 25
    },
    selectOption3: {
      type: Number,
      default: 50
    },
  },
  data() {
    return {
      contentActive: false,
      allChecked: false,
      checkedAllData: false,
      //   checkData: false,
      pageIndex: 1,
      selectedList: [],
      selectionList: [],
      cacheDataList: [],
      searchKey: '',
      totalCountReal: 0,
    }
  },
  watch: {
    dataList: {
      handler(n, o) {
        // console.log(this.pageIndex);
        this.selectedList = []
        this.selectionList = JSON.parse(JSON.stringify(n)).sort((b, a) => { return b.index - a.index })
        this.cacheDataList = JSON.parse(JSON.stringify(this.selectionList)).sort((b, a) => { return b.index - a.index })
        this.selectionList.forEach(item => {
          if (item.checked) {
            this.selectedList.push(item)
          }
        });
        this.totalCountReal = this.selectionList.length
        this.checkAllSelect()
        // console.log(this.selectionList);
        this.checkAllData()
        this.$forceUpdate()
      },
      immediate: true,
      deep: true
    },
    selectionList(val) {
      this.totalCountReal = val.length
    }
    // checkedSelectorNum(newVal) {
    //   if (newVal) {
    //     this.checkData = true
    //   }
    // }
  },
  computed: {
  },
  methods: {
    // 搜索
    searchFilter() {
      this.selectionList = this.$clone(this.cacheDataList)
      this.selectionList.forEach(i => {
        if (!this.checkedAllData) {
          this.$set(i, 'checked', false)
        }
        this.selectedList.forEach(j => {
          if ((i.projectStageId && i.projectId == j.projectId && i.projectStageId == j.projectStageId) || (!i.projectStageId && i.projectId == j.projectId)) {
            this.$set(i, 'checked', true)
          }
        })
      })
      if (this.searchKey) {
        let list = []
        this.selectionList.forEach(i => {
          // if (i.projectName.includes(this.searchKey) || (i.groupCompanyName && i.groupCompanyName.includes(this.searchKey))) {
          if (i.projectName.includes(this.searchKey)) {
            list.push(i)
          }
        })
        this.selectionList = list
      }
      this.pageIndex = 1
      // console.log(this.selectionList)
      this.checkAllSelect()
    },
    handleEmit() {
      this.$emit("getData", this.selectedList)
    },
    handleDel(item, index) {
      if (!this.disabled) {
        this.contentActive = true;
        this.selectionList.forEach(_item => {
          if ((item.projectStageId && _item.projectId == item.projectId && item.projectStageId == _item.projectStageId) || (!item.projectStageId && _item.projectId == item.projectId)) {
            _item.checked = false
          }
        });
        //   this.checkData = true;
        this.selectedList.splice(index, 1);
        this.checkAllSelect();

        this.$emit("getData", this.selectedList)
      }
    },
    handleAdd() {
      // if (!item) {
      this.selectedList = [];
      this.selectionList.forEach(item => {
        let onOff = false;
        if (item.checked) {
          this.selectedList.forEach(_item => {
            if ((item.projectStageId && _item.projectId == item.projectId && item.projectStageId == _item.projectStageId) || (!item.projectStageId && _item.projectId == item.projectId)) {
              onOff = true
            }
          });
          if (!onOff) {
            this.selectedList.push(item)
          }
        }
      });
      this.handleEmit()
    },
    // 分页跳转
    handleCurrentChange(page) {
      this.pageIndex = page;
      window.scrollTo(0, 0);
      this.$emit("handleCurrentChange", this.pageIndex)
      this.checkAllSelect()
      // this.getSupplierQAList();
    },
    // 全部选中
    handleCheckedAllData(blo) {
      if (blo) {
        this.selectedList = this.$clone(this.cacheDataList)
      } else {
        this.selectedList = []
      }
      this.selectionList.forEach(i => i.checked = blo)
      this.checkAllSelect()
      this.handleEmit()
    },
    handleClick() {
      if (!this.disabled) {
        this.contentActive = true
      }
    },
    // 选中行
    handleSelectTableRow(item, index) {
      this.$set(item, 'checked', item.checked);
      // console.log(item)

      if (item.checked) {
        if (!this.selectedList.some(_item => (item.projectStageId && _item.projectId == item.projectId && item.projectStageId == _item.projectStageId) || (!item.projectStageId && _item.projectId == item.projectId))) this.selectedList.push(item)
      } else {
        this.selectedList.forEach((_item, _index) => {
          if (((item.projectStageId && _item.projectId == item.projectId && item.projectStageId == _item.projectStageId) || (!item.projectStageId && _item.projectId == item.projectId)) && !item.checked) {
            this.selectedList.splice(_index, 1);
          }
        })
      }
      this.checkAllSelect()
      this.checkAllData()
      this.handleEmit()
    },
    // 是否全选
    checkAllData() {
      this.checkedAllData = this.selectedList.length == this.cacheDataList.length
    },
    // 是否本页全选
    checkAllSelect() {
      let list = this.selectionList.filter((item, index) => (this.pageIndex - 1) * this.pageSize <= index && index < this.pageIndex * this.pageSize)
      this.allChecked = list.every(item => {
        return item.checked;
      });
    },
    handleAllSelectTableRow(bool) {
      let arr = [];
      arr = [].concat(this.selectionList.filter((item, index) => (this.pageIndex - 1) * this.pageSize <= index && index < this.pageIndex * this.pageSize));
      // console.log(arr)
      arr.forEach(item => {
        item.checked = bool;

        if (item.checked) {
          if (!this.selectedList.some(_item => (item.projectStageId && _item.projectId == item.projectId && item.projectStageId == _item.projectStageId) || (!item.projectStageId && _item.projectId == item.projectId))) this.selectedList.push(item)
        } else {
          this.selectedList.forEach((_item, _index) => {
            if ((item.projectStageId && _item.projectId == item.projectId && item.projectStageId == _item.projectStageId) || (!item.projectStageId && _item.projectId == item.projectId)) {
              // console.log(i.projectId)
              this.selectedList.splice(_index, 1);
            }
          })
        }
      });
      this.checkAllData()
      this.handleAdd()
    },
    clickOutSide(ev) {
      // 是否点击在组件内部
      let state = false
      const searchParentNodeClassName = (offsetParentNode) => {
        const cName = offsetParentNode.className
        if (cName.indexOf('multiple-selector-content') != -1 || cName.indexOf('el-scrollbar') != -1) {
          state = true
        }
        if (offsetParentNode.offsetParent) {
          searchParentNodeClassName(offsetParentNode.offsetParent)
        }
      }
      searchParentNodeClassName(ev.target)
      // 如果未点在组件内 关闭 组件选择弹层
      if (!state) {
        this.handleClose()
      }
    },
    handleClose() {
      if (this.contentActive) {
        this.$emit('close', this.selectedList)
      }
      this.contentActive = false
    },
    clear() {
      this.selectionList = this.$clone(this.cacheDataList)
      this.selectedList = []
      this.searchKey = ''
      this.allChecked = false
      this.checkedAllData = false
      this.pageIndex = 1
    }
  },
  mounted() {
    this.$nextTick(() => {
      document.addEventListener('keyup', (e) => {
        if (e.keyCode == 27) {
          this.contentActive = false
        }
      })
      document.addEventListener('click', this.clickOutSide, true);
    })
    // this.init()
  }
}
</script>

<style scoped lang="scss">
.mask {
  background: #ddd;
  opacity: 0.7;
}
.multiple-selector-content {
  width: 100%;
  margin-bottom: 18px;
  position: relative;
  // .el-input{
  //   position: absolute;
  //   top: 0;
  //   right: 0;
  //   z-index: 99;
  //   opacity: 0;
  // }
  /deep/ .el-pagination__editor.el-input .el-input__inner {
    height: 28px;
    width: 100%;
  }
  .search {
    padding: 13px 10px;
    /deep/ .el-input {
      input {
        width: 100% !important;
        height: 34px;
        line-height: 34px;
      }
    }
  }
  .label {
    float: left;
    width: 100px;
    text-align: right;
    line-height: 34px;
    font-size: 14px;
    color: #888;
  }
  .selector {
    position: relative;
    // min-height: 34px;
    border: 1px solid #ddd;
    background: #fff;
    max-height: 66px;
    overflow-y: auto;
    &.disabled {
      cursor: no-drop !important;
      background-color: #dddddd;
    }
    // .disabled {
    //   position: absolute;
    //   left: 0;
    //   top: 0;
    //   width: 100%;
    //   height: 100%;
    //   // background-color: #dddddd;
    //   cursor: pointer;
    // }
    .placeholder {
      font-size: small;
      color: #bbbbbb;
    }
    .selected-list {
      height: 22px;
      padding: 3px 4px 2px 4px;
      background: #c99f4f;
      color: #fff;
      position: relative;
      line-height: 17px;
      float: left;
      margin-right: 6px;
      margin-bottom: 8px;
    }
    .el-icon-caret-bottom {
      position: absolute;
      right: 10px;
      // top: 14px;
      top: 50%;
      transform: translateY(-50%);
      color: #bbb;
    }
  }
  .content-active {
    border-color: #c99f4f;
  }
  .select-option {
    margin-top: 4px;
    position: absolute;
    border: 1px solid #c99f4f;
    min-height: 34px;
    z-index: 2;
    background: #fff;
    right: 0px;
    ul {
      li {
        > div {
          min-height: 34px;
          font-size: 14px;
          padding: 10px;
          display: flex;
          > div {
            width: calc(100% - 20px);
            padding-left: 10px;
            height: 17px;
            word-break: break-all;
            > span {
              line-height: 17px;
              display: inline-block;
            }
          }
        }
      }
    }
    .checked {
      background: linear-gradient(
        130deg,
        rgba(215, 176, 100, 1) 0%,
        rgba(236, 206, 139, 1) 100%
      );
      color: #fff;
    }
  }
  .operation {
    margin-top: 10px;
    border-top: 1px solid #eee;
    height: 46px;
    padding: 10px;
    /deep/ .el-pagination {
      position: absolute;
      text-align: center;
      width: 100%;
      button span,
      span {
        font-size: 12px;
      }
    }
  }
}
.required {
  &::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
.small-btn {
  position: relative;
  z-index: 3;
}
.signed {
  width: 76px;
  height: 20px;
  line-height: 20px;
  color: #fff;
  font-size: 14px;
  text-align: center;
  background: #830bb9;
  border-radius: 2px;
  margin-left: 4px;
  display: inline-block;
}
.el-form-item__error {
  position: absolute;
}
</style>