<template>
  <div class="app-header  f12" :class="{'white-bg':isWhiteBg}">
    <div class="app-header-inner inner-container" v-if="isLogin == '0'">
      <ul class="header-left">
        <li><span class="header-span" @click="handleChangeIndex">大家采官网</span></li>
        <template v-if="!showType && !bigInfrastructure">
          <li class="header-span header-span-right has-child has-who-box menu-list" :class="{'has-who-box-show':isShowMenu}" v-on:mouseenter="showWhoBox('isShowMenu')" v-on:mouseleave="hiddenshowWhoBox('isShowMenu')">
            <span class="home-login home-header-text header-span header-span-left ">
              <img src="../../assets/images/icon/itemize.png" width="20" style="top: 6px;display: inline-block;position: relative;">
              商品分类
            </span>
            <div class="show-menu-box inner-container" v-if="isShowMenu">
              <div class="show-menu-item" v-for="(treeLable,index) in categoryList()" :key="index">
                <p class="show-menu-item-title" :class="{hand: treeLable.existence}" @click="treeLable.existence && goProductList(treeLable.categoryName,treeLable.categoryId)">
                  {{treeLable.categoryName}}</p>
                <div class="show-menu-item-inner">
                  <span v-for="(treeItem,inde) in treeLable.children" :key="inde" :class="{existence: treeItem.existence}" @click="treeItem.existence && goProductList(treeItem.categoryName,treeItem.categoryId)">{{treeItem.categoryName}}</span>
                </div>
              </div>
            </div>
          </li>
        </template>
        <template v-if="showType=='bigIn' || bigInfrastructure">
          <li @click="goIndex()" class="header-span header-span-right has-child has-who-box menu-list"><a><span class="header-span header-span-right" style="padding-right: 0px">房地产采购</span></a></li>
        </template>
        <li v-if="isHome" class="go-center"><a @click="goAccountInfo()"><span style="margin-right: 0;" class="header-span header-span-right">管理中心</span></a></li>
        <li v-else><a @click="goIndex()"><span class="header-span header-span-right">建材集采</span></a></li>
      </ul>
      <ul class="header-right">
        <li class="hot-line"><span class="header-span header-span-right">客服电话：{{$platformContact()['hotLine']}} {{$platformContact()['hotLineTime']}}</span></li>
        <li><a @click="goRegister"><span class="home-register home-header-text header-span red">注册</span></a></li>
        <li><span style="font-size: 14px;line-height: 34px;" class="home-blank home-header-text header-span red">|</span></li>
        <li @click="goLogin()">
          <span class="home-login home-header-text header-span red">请登录</span>
          <i class="login-point-icon" v-if="showLoginOpint"></i>
        </li>
      </ul>
    </div>
    <div class="app-header-inner inner-container is-logined" v-if="isLogin == '1'">
      <ul class="header-left">
        <li><span class="header-span" @click="handleChangeIndex">大家采官网</span></li>
        <template v-if="!showType && !bigInfrastructure">
          <li class="header-span header-span-right has-child has-who-box menu-list hand" :class="{'has-who-box-show':isShowMenu}" v-on:mouseenter="showWhoBox('isShowMenu')" v-on:mouseleave="hiddenshowWhoBox('isShowMenu')">
            <span class="home-login home-header-text header-span header-span-left ">
              <img src="../../assets/images/icon/itemize.png" width="20" style="top: 6px;display: inline-block;position: relative;">
              商品分类
            </span>
            <div class="show-menu-box inner-container" v-if="isShowMenu">
              <div class="show-menu-item" v-for="(treeLable,index) in categoryList()" :key="index">
                <p class="show-menu-item-title" @click="treeItem.existence && goProductList(treeLable.categoryName,treeLable.categoryId)">
                  {{treeLable.categoryName}}</p>
                <div class="show-menu-item-inner">
                  <span v-for="(treeItem,inde) in treeLable.children" :key="inde" :class="{existence: treeItem.existence}" @click="treeItem.existence && goProductList(treeItem.categoryName,treeItem.categoryId)">{{treeItem.categoryName}}</span>
                </div>
              </div>
            </div>
          </li>
        </template>

        <template v-if="showType=='bigIn' || bigInfrastructure">
          <li @click="goIndex()" class="header-span header-span-right has-child has-who-box menu-list"><a><span class="header-span header-span-right" style="padding-right: 0px">房地产采购</span></a></li>
        </template>
        <li v-if="isHome" class="go-center"><a @click="goAccountInfo()"><span style="margin-right: 0;" class="header-span header-span-right">管理中心</span></a></li>
        <li v-else><a @click="goIndex()"><span class="header-span header-span-right">建材集采</span></a></li>
        <li v-if="showType!='bigIn' || bigInfrastructure" class="msgMail" style="margin-left: 4px;" @click="goSystemMail">站内信<span class="unReadNum" style="margin-left: 6px;" v-if="!(Number(unReadNum) == 0 || $store.state.msgIdList == 0)">{{$store.state.msgIdList >=0 ? $store.state.msgIdList : Number(unReadNum)}}</span></li>
      </ul>
      <ul class="header-right" v-if="userInfo.invoiceFlag != '1'">
        <li class="hot-line"><span class="header-span header-span-right">客服电话：{{$platformContact()['hotLine']}} {{$platformContact()['hotLineTime']}}</span></li>
        <li class="has-child has-who-box hand" :class="{'has-who-box-show':isShowWho}" v-on:mouseenter="showWhoBox('isShowWho')" v-on:mouseleave="hiddenshowWhoBox('isShowWho')">
          <span class="home-login home-header-text blue  header-span header-span-left">{{userInfo.acctName}}</span>
          <div class="who-i-am default-shadow" v-if="isShowWho" :style="{'width' : !accountList || !accountList.length ? '300px' : '310px'}">
            <div class="login-out" :style="{'width' :  !accountList || !accountList.length  ? '200px' : '210px'}">
              <span class="blue" @click="goAccountInfo" v-show="userInfo.invoiceFlag != '1'">{{userInfo.custStatus == 2 ? "账户激活":"账号管理"}}</span>
              <span class="login-out-blank" :style="{'padding' :  !accountList || !accountList.length  ? '0 10px' : '0 5px'}" v-show="userInfo.invoiceFlag != '1'">|</span>
              <span class="blue" @click="changeAccount" v-if="accountList && accountList.length > 1 && this.userInfo.bs != 'B'">切换账号</span>
              <span class="login-out-blank" v-if="accountList && accountList.length > 1 && this.userInfo.bs != 'B'">|</span>
              <span class="blue" @click="handleLoginOut()">退出</span>
            </div>

            <div class="header-photo fl"><img src="../../assets/images/member_photo.png" width="60" alt=""></div>
            <div class="header-custer fl">
              <p class="f14 custer-name">{{userInfo.acctName}}</p>
              <!-- <p class="f12 custer-belong" v-if="!brokerRole ? userInfo.groupCompanyName : userInfo.corpName">{{!brokerRole ? userInfo.groupCompanyName : userInfo.corpName}}</p> -->

              <p class="f12 custer-belong" v-if="companyComputed">{{companyComputed}}</p>

              <template v-if="userInfo.bs == 'B'">
                <p class="f12 custer-belong">采购商</p>
              </template>
              <template v-else>
                <p v-if="contractCorpType == 'construction'" class="f12 custer-belong">施工方</p>
                <p v-if="contractCorpType == 'supervisory'" class="f12 custer-belong">监理方</p>
                <p v-if="contractCorpType == null" class="f12 custer-belong">供应商</p>
              </template>
            </div>
          </div>
        </li>

      </ul>
    </div>
    <!-- 切换账号 -->
    <el-dialog class="dialog" title="切换账号" :append-to-body="true" :lock-scroll="true" :visible.sync="changeAccountDialogVisible" width="50%" center :close-on-click-modal="false">
      <div class="change-account ">
        <div class="change-account-inner clearfloat">
          <div class="fl" style="width:33%;height:100%;min-height:50px;"></div>
          <div class="fl" style="width:67%;">
            <el-radio-group v-model="accountCheckList">
              <el-radio :label="item.acctId" v-for="(item) in accountList" v-bind:key="item.acctId">
                {{item.corpName}}
              </el-radio>
            </el-radio-group>
          </div>
        </div>
        <div class="change-account-btns tc">
          <el-button size="" type="primary" @click="handleChangeAccount">确认登录</el-button>
          <el-button size="" @click="cancelChangeAccount">&nbsp;&nbsp;&nbsp;&nbsp;取消&nbsp;&nbsp;&nbsp;&nbsp;
          </el-button>
        </div>
      </div>

    </el-dialog>
  </div>
</template>

<script>
import {
  BASE_CONFIG
} from '@/config/config'
import {
  mapActions,
  mapState
} from 'vuex'
import { InterfaceService } from '@/services/api'
import accountMixin from "@/mixins/account";
import jumpConfluence from "@/mixins/jumpConfluence";
export default {
  mixins: [accountMixin, jumpConfluence],
  components: {},
  props: {
    isWhiteBg: {
      type: Boolean,
      default: false // 这样可以指定默认的值
    },
    showLoginOpint: {
      type: Boolean,
      default: true // 是否显示 登陆艇指引提示
    },
    isOfficialIndex: {
      type: Boolean,
      default: false // 是否是大家采官网头部
    },
    isHome: { // 是否是首页
      type: Boolean,
      default: false
    },
    showType: { // 类型  用于判断是否大基建: bigIn, 默认大家采
      type: String,
      default: ''
    }
  },
  data() {
    return {
      hello: '',
      isShowAbout: false,
      isShowReg: false,
      isShowFooter: true,
      // isLogin:'0',
      acctName: '',
      // custName: '',
      isPurchasers: true,
      isShowWho: false,
      isShowMenu: false,
      isShowMsg: false,
      menuTree: [],
      unReadMsgList: [],
      unReadNum: "",
      changeAccountDialogVisible: false,
      accountCheckList: '',
      defaultAccountId: '',
      canGoAccountInfo: true,
    }
  },
  computed: {
    companyComputed() {
      // 供应商显示公司名称, 材料公司显示材料集团, 事业部或多账户显示事业部名称, 单账户显示公司名称
      return this.role == 'S' ? this.userInfo.corpName : this.brokerRole ? '材料集团' : (this.userInfo.acctIdList && this.userInfo.acctIdList.length > 1 || this.division) ? this.userInfo.groupCompanyName : this.userInfo.corpName || ''
    },
    isLogin() {
      // console.log(this.$store.state.isLogin)
      return this.$store.state.isLogin
    },
    userInfo() {
      // console.log(this.$store.state.LoginedUser.custName)
      return this.$store.state.userInfo || {}
    },
    accountList() {
      return this.$store.state.userInfo ? this.$store.state.userInfo.accountList : []
    },
    contractCorpType() {
      return this.$store.state.userInfo.contractCorpType || null
    },
    categoryList() {
      return list => {
        console.log(list, 'headCategoryListChange', this.$store.state.categoryList)
        return list || this.$store.state.categoryList
      }
    },
    // unReadNum(){
    //     return this.$store.state.unReadMsgNum;
    // },
    // unReadMsgList() {
    //   console.log(this.$store.state);
    //   return this.$store.state.unReadMsgList;
    // },
    msgCenterPermissionFlag() {
      if (localStorage.getItem('msgCenterPermission') != null) {
        return localStorage.getItem('msgCenterPermission') == 'true' ? true : false;
      } else {
        return this.$store.state.msgCenterPermission == 'true' ? true : false;
      }
    }
  },

  methods: {

    ...mapActions(['setUserInfoAction']),
    // getCategory() {
    //     InterfaceService.getCategoryList(res => {
    //         this.menuTree = res['children'];
    //     });
    // },
    async goConfluence() {
      this.isLoading = true
      try {
        await this.toConfluence('1')
      } catch (error) {
        console.log(error, 'ee---');
        this.$message.error('系统繁忙, 请稍后重试')
      }
      this.isLoading = false
    },
    init() {
      //console.log(this.$props)
      //判断上午下午
      let now = new Date(), hour = now.getHours();
      if (hour < 6) {
        this.hello = "凌晨好！"
      }
      else if (hour < 9) {
        this.hello = "早上好！";
      }
      else if (hour <= 12) {
        this.hello = "上午好！";
      }
      else if (hour <= 14) {
        this.hello = "中午好！";
      }
      else if (hour <= 17) {
        this.hello = "下午好！";
      }
      else if (hour <= 19) {
        this.hello = "傍晚好！";
      }
      else {
        this.hello = "晚上好！";
      }
      //this.getCategory();
      setTimeout(() => {
        let info = JSON.parse(this.$getRootScope("watchUnreadInfo") || '{}');
        // console.log(info);
        // this.unReadMsgList = JSON.parse(this.$getRootScope("setSysMsgInf oList") || '');
        // this.unReadNum = Number(this.$getRootScope("setSysMsgInfo") || 0)
        this.unReadMsgList = info.unreadList || [];
        this.unReadNum = +info.unreadNum || 0

        // this.$store.dispatch('setUnreadNum', this.unReadNum)
      }, 1000)
    },
    goIndex() {
      this.$router.push('/home')
    },
    handleChangeIndex() {
      window.open(BASE_CONFIG.OFFICIAL_URL, "_blank");
    },
    showWhoBox(key) {
      console.log(key)
      this[key] = true
    },
    hiddenshowWhoBox(key) {
      this[key] = false
    },
    handleLoginOut() {
      //自主退出 清空记住的路径
      this.$removeRootScope('defaultGoRout');
      this.$removeRootScope('query');
      this.$removeRootScope('registerName')
      this.$removeRootScope('extraConfig');
      this.$removeRootScope('registerPath');
      this.$removeRootScope('limitTxCode');
      this.$removeRootScope('showMenuList');
      this.$removeRootScope('toFullPath');
      //站内信信息清除 begin
      this.$store.dispatch("setSysMsgInfo", 0);
      localStorage.setItem('msgCenterPermission', false);
      this.$removeRootScope('setSysMsgInfo')
      //站内信信息清除 end
      this.$removeRootScope('formPath');
      this.$removeRootScope('watchUnreadInfo');

      const user = this.$getRootScope('user') && JSON.parse(this.$getRootScope('user')) || {}
      user.acctId && this.$setRootScope('acctIdOld', user.acctId)

      this.goLogin()
    },
    goLogin() {

      InterfaceService.loginOut(
        {},
        data => {
          this.isShowWho = false
          this.$router.push('/login')
        },
        data => {
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );

    },
    goRegister() {
      this.$router.push('/register')
    },
    goAccountInfo() {
      if (this.isLogin == '0') {
        return this.$router.push('/login')
      }
      let res = this.$store.state.userInfo;
      let bs = res.bs && res.bs.toUpperCase();
      let corpId = res.corpId;
      let corpStatus = res.corpStatus;
      // let brokerApproval = false;
      // let publicOpinionMonitorsManage = false;
      // if ( res.roleIds) {
      //     res.roleIds.forEach(role=>{
      //         if (role.roleId == "1002" || role.roleId == "1003" || role.roleId == "1004") {
      //             brokerApproval = true
      //         }
      //     });
      // }
      let registerPath = JSON.parse(this.$getRootScope("registerPath") || "{}");
      if (Object.keys(registerPath).length > 0) {
        this.$router.push({ path: registerPath.path, query: registerPath.query });
      } else {
        //to do list
        // let test = "大基建"
        // if(test == "大基建"){
        //     this.$router.push('/bigInfrastructureCenter/ProjectManage')
        //     return;
        // }
        // if (res.custTags && res.custTags.length > 0) {
        //   let isConstruction = false;
        //   res.custTags.forEach(el => {
        //     if (el.tagId == "LVDI_CONSTRUCTION") {
        //       isConstruction = true;
        //     }
        //   })
        //   if (isConstruction) {
        //     // this.$router.push('/bigInfrastructureCenter/workbench')
        //     this.$router.push(`${bs == 'S' ? '/vendorCenter' : '/purchaserCenter'}/workbench`)
        //     return;
        //   }
        // }
        if (bs == 'B') {
          this.$router.push('/purchaserCenter/accountInfo')
        } else if (bs == 'S') {
          this.$router.push('/vendorCenter/accountInfo')
        }
      }
    },
    goProductList(name, id) {
      this.$setRootScope('forbidBack', 'true')
      if (id === '1000' || id === '10001' || id === '10002' || id === '100011' || id === '100021') {
        const routeData = this.$router.resolve({
          path: `/threeNew`,
          query: {
            scrollTop: (id === '10001' || id === '100011') ? 959 : (id === '10002' || id === '100021') ? 2080 : 0
          }
        });
        window.open(routeData.href, "_blank");
        return
      }
      this.$router.push({
        path: "/transfer",
        query: {
          query: JSON.stringify({ 'categoryId': id, 'categoryName': name }),
          path: '/productList'
        }
      });
    },
    changeAccount() {
      let acc_len = this.accountList.length;
      for (let i = 0; i < acc_len; i++) {
        if (this.accountList[i].selected) {
          this.accountCheckList = this.accountList[i].acctId
          this.defaultAccountId = this.accountCheckList
          break;
        }
      }

      this.changeAccountDialogVisible = true
    },
    handleChangeAccount() {
      if (this.defaultAccountId != this.accountCheckList) {
        //登录 缓存数据
        InterfaceService.login({ 'acctId': this.accountCheckList }, (data) => {
          // InterfaceService.loginNew({ 'acctId': this.accountCheckList }, (data) => {
          let resulstOuter = data.respData
          if (resulstOuter.respCode == "0000") {
            this.changeAccountDialogVisible = false
            this.$message({
              message: "切换账号成功",
              type: 'success'
            });
            this.$removeRootScope('registerPath');
            this.callMsgListData();
            this.$removeRootScope('acctIdOld')
            let accountList = []
            if (this.accountList.length > 1) {
              let acc_len = this.accountList.length
              for (let i = 0; i < acc_len; i++) {
                let item = this.accountList[i]
                if (item.acctId === this.accountCheckList) {
                  item.selected = true
                } else {
                  item.selected = false
                }
                accountList.push(item)
              }

            }

            let resInner = resulstOuter.acctInfos && resulstOuter.acctInfos[0]

            // 菜单改造
            try {
              resulstOuter.roleIds = resulstOuter.corpRoleList && resulstOuter.corpRoleList.find(f => f.corpId == resInner.corpId) && resulstOuter.corpRoleList.find(f => f.corpId == resInner.corpId).roleList || []
            } catch (error) {
              throw new TypeError('LoginTypeError: ', error)
            }


            let userInfo = {
              'mobileNo': resulstOuter.mobileNo,
              'email': resulstOuter.email,
              'invoiceFlag': resInner.invoiceFlag,
              'acctId': resInner.acctId,
              'acctName': resInner.acctName,
              'isLogin': '1',
              'corpId': resInner.corpId,
              'busiLicense': resInner.busiLicense,
              'corpName': resInner.corpName,
              'bs': resInner.bs,
              'contractCorpType': resInner.contractCorpType,
              'accountList': accountList,
              'regStep': resInner.regStep,
              'custStatus': resulstOuter.custStatus,
              'approveStatus': resInner.approveStatus,
              'corpStatus': resulstOuter.corpStatus,
              'attachUrl': resInner.attachUrl || "",
              'supplyType': resulstOuter.supplyType || "",
              'legalRepresent': resInner.legalRepresent || "",
              'approveId': resInner.approveId || "",
              'resulstOuter': resulstOuter.resulstOuter,
              'groupCompanyCode': resulstOuter.groupCompanyCode, // 是否绿地公司："GREENLANDHK"：绿地Group 其他: 非绿地Group
              'brokerList': resulstOuter.brokerList || [],
              'roleIds': resulstOuter.roleIds,
              'shortCorpName': resInner.shortCorpName || "",
              'corpTags': resulstOuter.corpTags || [],
              'custTags': resulstOuter.custTags || [],
              // 菜单改造
              'corpRoleList': resulstOuter.corpRoleList || [],
              'acctIdList': resulstOuter.acctIdList || [],
              'corpIdList': resulstOuter.corpIdList || [],
              'corpMenuList': resulstOuter.corpMenuList || [],
              'corpList': resulstOuter.corpList || [],
              'busitypeMng': resulstOuter.busitypeMng || [],
            }

            this.$setRootScope('user', JSON.stringify(userInfo))
            this.setUserInfoAction(userInfo)
            //权限树
            //获取menuList  menuAvailable!='1'则表示没有权限

            let limitTxCodeArr = [],
              menuList = []
            const corpMenuList = resulstOuter && resulstOuter.corpMenuList || [],
              findItme = corpMenuList.find(f => f.corpId == resulstOuter.corpId) || {}

            menuList = findItme.menuList || []
            if (menuList && menuList.length) {
              limitTxCodeArr = menuList[0] && menuList[0].menuList || []

              let treeToArray = this.treeToArray(limitTxCodeArr, []),
                limitTxCode = [],
                showMenuList = [];

              for (let i = 0; i < treeToArray.length; i++) {
                if (treeToArray[i].menuAvailable != '1') {
                  limitTxCode.push({ 'code': treeToArray[i].menuURL, 'type': treeToArray[i].menuType, 'name': treeToArray[i].menuName })
                } else {
                  if (treeToArray[i].menuType == '1') {
                    showMenuList.push({ 'code': treeToArray[i].menuURL, 'type': treeToArray[i].menuType, 'name': treeToArray[i].menuName })
                  }
                  showMenuList = this.treeToSimpleArray(limitTxCodeArr, [])
                }
              }
              this.$setRootScope('limitTxCode', JSON.stringify(limitTxCode))
              this.$setRootScope('showMenuList', JSON.stringify(showMenuList))
            } else {
              this.$setRootScope('limitTxCode', JSON.stringify([]))
              this.$setRootScope('showMenuList', JSON.stringify([]))
            }
            // 判断是否是管理员身份，如果是管理员身份但没授权书，先上传授权书
            let adminRoles = ['1000', '2000', '3000', '4000', '5000', '9000']
            let isAdmin = userInfo.roleIds && userInfo.roleIds.some(item => {
              return adminRoles.indexOf(item.roleId) != -1
            });

            // 显示 完善信息
            const corpItem = resulstOuter.corpList && resulstOuter.corpList.find(f => f.corpId == resulstOuter.corpId) || {}
            if (corpItem.enterFrom == '2') {
              if (resulstOuter.custStatus == '2') {//未激活
                this.$router.push('/activateac');
                return;
              }
              this.$setRootScope('sessionShowEsUserPerfectListDialog', '1')
              this.$router.push('/home');
              this.$emit('refresh', true)
              return
            }

            if (resInner.contractCorpType === 'broker' || !isAdmin || !resInner.approveStatus || resInner.approveStatus === 'approved') {
              if (resulstOuter.custStatus && resulstOuter.custStatus == '0') {//用户已激活
                // if (resInner.attachUrl)
                if (resulstOuter.corpStatus == '-1') {
                  // 审核失败
                  this.$router.push({ path: '/auditFailed', query: { approveMsg: resulstOuter.approveMsg } });
                  return;
                }
                //判断是否注册信息需要补充
                if (resInner.regStep == '2') {//注册信息完善 跳转到登录前的页面
                  if (resInner.corpStatus == '0') {//账号未激活
                    this.$router.push('/registerSuccess');
                    return;
                  }

                  let defaultGoRout = this.$getRootScope('defaultGoRout')
                  const toFullPath = sessionStorage.getItem('toFullPath')
                  let query = this.$getRootScope('query') && JSON.parse(this.$getRootScope('query'))

                  //是否跳转登录前记录的页面：注册页、更改过bs
                  let isChangeBs = false;
                  let rout = defaultGoRout ? defaultGoRout.toLocaleLowerCase() : ''

                  //施工单位 监理单位 或者 上次登出前的BS和本次登录不一致的 跳转到首页
                  if (resInner.bs == "C" || resInner.bs == "CS" || resInner.bs != this.$getRootScope('defaultBs')) {
                    isChangeBs = true
                  }
                  //从某些页面跳转到登录页  登录后不再回到原页面：注册相关页、忘记密码页 、发票页
                  if (rout.indexOf('register') > -1 ||
                    rout.indexOf('change') > -1 ||
                    rout.indexOf('forgetpwd') > -1 ||
                    rout.indexOf('error') > -1 ||
                    rout.indexOf('noright') > -1 ||
                    rout.indexOf('invoice') > -1 ||
                    rout.indexOf('activateac') > -1
                  ) {//从注册相关页、发票页 跳转登录后 不再回到注册相关页
                    isChangeBs = true
                  }
                  console.log(!isChangeBs && defaultGoRout, !isChangeBs, defaultGoRout, '!isChangeBs && defaultGoRout');
                  console.log(isChangeBs);
                  if (!isChangeBs) {
                    if (toFullPath.indexOf("biddingSignUpInfo") != -1) {
                      if (userInfo.bs == "B") {
                        this.$message.info("采购商不可报名招标！")
                        this.$router.push({
                          path: "/home"
                        });
                      } else {
                        this.$router.push({
                          path: toFullPath
                        });
                      }
                    } else {
                      this.judgeJumpHome(resInner, resulstOuter)
                    }
                    return
                  } else {
                    this.judgeJumpHome(resInner, resulstOuter)
                  }
                  if (!isChangeBs && defaultGoRout) {

                    // 当前新ID
                    const user = this.$getRootScope('user') && JSON.parse(this.$getRootScope('user')),
                      acctIdOld = this.$getRootScope('acctIdOld')

                    console.log(acctIdOld, user.acctId, '---');

                    this.$router.push({
                      // 如果 退出之前的人和现在登录的人是同一个人 进入之前页面, 否则去home
                      path: acctIdOld === user.acctId ? defaultGoRout : '/home',
                      query: query
                    });
                    // 如果 是 别的指定路径 跳转过来 需要登录的  登录后 跳转回原来路径
                  } else {
                    console.log(3);
                    this.$router.push('/home');
                  }


                } else if (resInner.regStep == '1') {//注册信息不完善 跳转到注册第三步
                  this.$router.push('/registerAdvanced');
                } else {
                  if (resInner.bs) {
                    this.$router.push(resInner.bs == 'B' ? '/PregisterPerfectInfo' : 'VregisterPerfectInfo');
                  }
                }

              } else if (resulstOuter.custStatus == '2') {//未激活
                this.$router.push('/activateac');
                return;
              } else {
                this.$router.push('/home');
                return;
              }
            } else {
              if (resInner.approveStatus == 'rejected') {
                this.$router.push({ path: '/auditFailed', query: { approveMsg: resInner.approveMsg, type: 'admin' } });
              } else if (resInner.approveStatus == 'submited') {
                this.$router.push({ path: '/registerSuccess', query: { type: 'admin' } });
              } else {
                this.$router.push('/activateac');
              }
            }


          } else {//多账号或者登录失败
            this.$message({
              message: "切换账号失败",
              type: 'warning'
            });
          }


        }, (data) => {
          //切换账号失败 不该清空原账号信息
          if (data && data.respMsg) {
            this.$message({
              message: data.respMsg,
              type: 'warning'
            });

          }
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        });
      }

    },
    judgeJumpHome(resInner, resulstOuter) {
      resInner = resInner || {}
      resulstOuter = resulstOuter || {}

      if (resulstOuter.custStatus == '2') {//未激活
        this.$router.push('/activateac');
        return;
      }

      //判断是否注册信息需要补充
      if (resInner.regStep == '2') {//注册信息完善 跳转到登录前的页面
        if (resInner.corpStatus == '0') {//账号未激活
          this.$router.push('/registerSuccess');
          return;
        }
        this.$router.push('/home');
      }
      if (resInner.regStep == '1') {//注册信息不完善 跳转到注册第三步
        this.$router.push('/registerAdvanced');
      }
      if (resInner.regStep == '1') {//注册信息不完善 跳转到注册第三步
        this.$router.push('/registerAdvanced');
      }
    },
    callMsgListData() {
      let params = {
        isRead: 0,
        pageIndex: 1,
        pageSize: 3,
        messageType: 'normal',
        messageParentClass: '01'
      }
      InterfaceService.getSysMsgList(
        params,
        data => {
          // let msgList;
          if (null == data.respData.msgList) {
            this.unreadList = [];//置空
            // return;
          } else {
            this.unreadList = data.respData.msgList
          }
          // this.msgList = data.respData.msgList;
          // this.$store.commit("setSysMsgInfoList", msgList);
          // this.$store.commit("setSysMsgInfo", data.respData.totalUnreadNums);
          let info = {
            unreadList: this.unreadList,
            unreadNum: +data.respData.totalUnreadNums || 0,
          };
          this.$setRootScope('watchUnreadInfo', JSON.stringify(info));
          setTimeout(() => {
            let info = JSON.parse(this.$getRootScope("watchUnreadInfo") || '{}');
            console.log(info);
            this.unReadMsgList = info.unreadList || [];
            this.unReadNum = +info.unreadNum || 0
          }, 1000)
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    cancelChangeAccount() {
      this.changeAccountDialogVisible = false
    },
    treeToArray(tree, arr) {
      let res = arr
      let len = tree.length
      for (let n = 0; n < len; n++) {
        let treeItem = tree[n]
        res.push({
          menuAvailable: treeItem.menuAvailable,
          menuDisplaySort: treeItem.menuDisplaySort,
          menuID: treeItem.menuID,
          menuLevel: treeItem.menuLevel,

          menuName: treeItem.menuName,
          menuParentID: treeItem.menuParentID,
          menuStatus: treeItem.menuStatus,
          menuType: treeItem.menuType,
          menuURL: treeItem.menuURL
        })

        if (treeItem.menuList && treeItem.menuList.length > 0) {
          this.treeToArray(treeItem.menuList, res)
        }
      }

      return res
    },
    treeToSimpleArray(tree, arr) {
      let res = arr
      let len = tree.length
      for (let n = 0; n < len; n++) {
        let treeItem = tree[n]
        res.push({
          menuAvailable: treeItem.menuAvailable,
          menuType: treeItem.menuType,
          menuID: treeItem.menuID,
          menuName: treeItem.menuName,
          menuList: treeItem.menuList,
          menuURL: treeItem.menuURL,
          menuIcon: treeItem.menuIcon || "",
          menuPath: treeItem.menuPath || ""
        })
      }
      res.forEach(item => {
        if (item.menuList && item.menuList.length > 0) {
          item.menuList = this.treeToSimpleArray(item.menuList, [])
        }
      });
      return res
    },
    goDraftsList() {
      this.$router.push('/purchaserCenter/orderDraftsList')
    },
    goSystemMail() {
      let registerPath = JSON.parse(this.$getRootScope("registerPath") || "{}");
      if (Object.keys(registerPath).length > 0) {
        this.$router.push({ path: registerPath.path, query: registerPath.query });
      } else {
        if (this.userInfo.bs == 'B') {
          this.$router.push('/purchaserCenter/sysNotice')
        } else {
          this.$router.push('/vendorCenter/sysNotice')
        }
        if (this.userInfo.bs == 'B') {
          this.$router.push('/purchaserCenter/sysNotice')
        } else {
          this.$router.push('/vendorCenter/sysNotice')
        }
      }
    },
    // 刷新类目
    getCategoryOfBidWinning() {
      return new Promise((resolve, reject) => {
        InterfaceService.getCategoryOfBidWinning({}, data => {
          if (data.respData && data.respData.respCode === "0000") {
            this.categoryBaseBeans = data.respData.categoryBaseBeans || []
            this.$setRootScope('categoryBaseBeans', JSON.stringify(this.categoryBaseBeans))
            this.initCategoryList()
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
          }
          resolve(true)
        }, data => { reject(data) }, () => { }, () => { });
      })
    },

    initCategoryList() {
      let categoryList = sessionStorage.getItem('categoryList')
      if (categoryList) {
        categoryList = JSON.parse(categoryList || '[]')
        this.findAlreadyExists(this.categoryBaseBeans, categoryList)
        this.$store.commit('changeCategoryList', categoryList)
        this.$setRootScope('categoryList', JSON.stringify(categoryList))
        console.log(this.$store.state.categoryList, 'this.$store.state.categoryList');
        console.log(this.categoryList(this.$store.state.categoryList), 'this.categoryList');
      } else {
        InterfaceService.getCategoryList(
          {
            categoryId: "1",
            queryType: "2",
          }, data => {
            if (data.respData && data.respData.respCode === "0000") {
              let res = data.respData.categoryInfos || []

              this.findAlreadyExists(this.categoryBaseBeans, res)

              this.$store.commit('changeCategoryList', res)
              this.$setRootScope('categoryList', JSON.stringify(res))

              console.log(this.$store.state.categoryList, 'this.$store.state.categoryList');
              console.log(this.categoryList(this.$store.state.categoryList), 'this.categoryList');

            } else {
              this.$message.error(data.respData && data.respData.respMsg);
            }
          }, data => { }, () => { }, () => { })
      }
    },

    /**
     * 查找已存在商品类目
     */
    findAlreadyExists(categoryBaseBeans, res) {
      categoryBaseBeans && categoryBaseBeans.forEach(f => {
        this.categoryInfosExternalCirculation(f.categoryId, res)
        if (f.children && f.children.length) {
          this.findAlreadyExists(f.children, res)
        }
      })
    },

    categoryInfosExternalCirculation(id, res) {
      res && res.some(s => {
        if (s.categoryId == id) {
          return s.existence = true
        }
        if (s.children && s.children.length) {
          this.categoryInfosExternalCirculation(id, s.children)
        }
      })
    },


  },
  created() {
    this.init()
  },
  mounted() {
    const path = ["/register",
      "/pregisterPerfectInfo",
      '/vregisterPerfectInfo',
      "/registerAdvanced",
      "/registerSupplement",
      "/activateac",
    ];
    this.canGoAccountInfo = this.userInfo.regStep == '2'
    // console.log(this.$store.state);
  }
}
</script>

<style scoped>
.inner-container {
  width: 1200px;
}
.msg-container {
  width: 300px;
  padding: 0 10px 30px !important;
  position: relative;
}
.change-account /deep/ .el-radio-group {
  width: 100%;
  padding-left: 4%;
}

.change-account /deep/ .el-radio {
  line-height: 30px;
  width: 100%;
  text-align: left;
}

.change-account /deep/ .el-radio + .el-radio {
  margin-left: 0;
}

.change-account /deep/ .el-radio__inner {
  border-radius: 2px;
}
.change-account /deep/ .el-radio__input.is-checked .el-radio__inner {
  background: #c99f4f !important;
}
.change-account /deep/ .el-radio__inner::after {
  display: none;
}

.change-account /deep/ .el-radio__inner::before {
  box-sizing: content-box;
  content: "";
  border: 1px solid #fff;
  border-left: 0;
  border-top: 0;
  height: 7px;
  left: 4px;
  position: absolute;
  top: 1px;
  transform: rotate(45deg) scaleY(0);
  width: 3px;
  transition: transform 0.15s ease-in 0.05s;
  transform-origin: center;
  transform: rotate(45deg) scaleY(1);
}

.change-account-btns {
  padding-top: 20px;
}

/*头部*/
.app-header {
  height: 34px;
  width: 100%;
  background-color: #f5f5f5;
}

.app-header.white-bg {
  background-color: #eeeeee;
}

.app-header.gold-bg {
  background-color: #f8c232;
}

.app-header-inner {
  height: 34px;
}

.header-left {
  float: left;
  width: 50%;
  height: 34px;
}

.header-left li {
  float: left;
  cursor: pointer;
  position: relative;
}

.header-right li {
  position: relative;
  float: right;
  text-align: right;
  cursor: pointer;
}
.header-left li .login-point-icon {
  position: absolute;
  background-image: url(../../assets/images/home/191119/login_point_icon.png);
  width: 130px;
  height: 31px;
  top: 30px;
  left: 0;
  background-repeat: no-repeat;
  z-index: 1;
  animation: noticeShake 0.8s infinite;
  animation-direction: alternate;
  -webkit-animation: noticeShake 0.8s infinite;
  -webkit-nimation-direction: alternate;
}

@keyframes noticeShake {
  0% {
    top: 30px;
  }
  50% {
    top: 25px;
  }
  100% {
    top: 30px;
  }
}
@-webkit-keyframes noticeShake {
  0% {
    top: 30px;
  }
  50% {
    top: 25px;
  }
  100% {
    top: 30px;
  }
}

.header-right {
  float: right;
  width: 50%;
  height: 34px;
  text-align: right;
}

.app-header span.header-span {
  color: #444;
  line-height: 34px;
}

/*.app-header span.home-header-text{color: #df0a0a}*/
.header-left span.header-span {
  margin-right: 20px;
  position: relative;
}
.header-left .msgMail {
  height: 34px;
  line-height: 34px;
  /* background: url(../../assets/images/msgCenter/envelope.png) no-repeat center left; */
}
.header-left .msgMail .msg-none {
  text-align: center;
  font-size: 12px;
  height: 60px;
  line-height: 60px;
  border-bottom: 1px solid #eeeeee;
}
.header-left .msgMail .msg-go {
  text-align: center;
  font-size: 12px;
  color: #0082ff;
  position: absolute;
  height: 30px;
  width: 100%;
  line-height: 30px;
  bottom: 0;
  left: 0;
  font-weight: bold;
}
.trivia {
  height: 34px;
  line-height: 34px;
  background: url(../../assets/images/msgCenter/collection.png) no-repeat center
    left;
  padding-left: 20px;
  margin-left: 32px;
  background-position: 0px 9px;
  background-size: 17%;
}
.header-left .msgMail .unReadNum {
  background: red;
  color: #fff;
  font-size: 12px;
  border-radius: 20px;
  padding: 2px 10px;
  line-height: 16px;
  margin-left: 10px;
}
.header-right span.header-span {
  margin-left: 4px;
}

.is-logined .header-right span.header-span {
  position: relative;
}

/*li.has-child span.header-span:before {*/
/*content: '';*/
/*position: absolute;*/
/*top: 50%;*/
/*right: 9px;*/
/*width: 6px;*/
/*height: 6px;*/
/*border-top: 1px solid #adadad;*/
/*border-right: 1px solid #adadad;*/
/*transform: rotate(135deg);*/
/*-webkit-transform: rotate(135deg);*/
/*-moz-transform: rotate(135deg);*/
/*-o-transform: rotate(135deg);*/
/*margin-top: -4px;*/
/*}*/

.is-logined .header-right li.has-child span.header-span:before {
  right: 10px;
}

.is-logined .header-right li.menu-list.has-child span.header-span:before {
  right: 6px;
}

.who-i-am {
  width: 310px;
  min-height: 120px;
  text-align: left;
  background-color: #fff;
  z-index: 998;
  position: absolute;
  top: 34px;
  left: 4px;
}

.show-menu-box {
  position: absolute;
  top: 34px;
  background: #fff;
  z-index: 9999;
  padding-top: 20px;
  padding-left: 20px;
  padding-bottom: 20px;
  box-shadow: 0 4px 12px 0 rgba(0, 0, 0, 0.1);
  -webkit-box-shadow: 0 4px 12px 0 rgba(0, 0, 0, 0.1);
  cursor: auto;
}

.has-who-box-show span.header-span:after {
  content: "";
  position: absolute;
  width: 100%;
  height: 10px;
  bottom: -4px;
  left: 0;
  background-color: #fff;
  z-index: 999;
}

.has-who-box {
  /*min-width: 100px;*/
}

.has-who-box span.header-span {
  display: inline-block;
  height: 34px;
  padding: 0 8px;
  /* padding-left: 8px;
        padding-right: 8px; */
  position: relative;
  z-index: 999;
}

.has-who-box.has-who-box-show span.header-span {
  background: #fff;
  -moz-box-shadow: 2px -2px 12px #e7e7e7;
  -webkit-box-shadow: 2px 0px 12px #e7e7e7;
  box-shadow: 2px 0px 12px #e7e7e7;
}

.has-who-box.has-who-box-show {
  position: relative;
}

.hot-line {
  margin-left: 20px;
}

.header-photo {
  width: 98px;
  min-height: 120px;
  padding-top: 30px;
  padding-left: 20px;
}

.header-photo img {
  width: 60px;
  height: auto;
}

.header-custer {
  padding-top: 35px;
  width: 192px;
}

.custer-name,
.custer-belong {
  line-height: 1.5;
  margin-top: 4px;
  margin-bottom: 4px;
}

.login-out {
  position: absolute;
  width: 210px;
  height: 32px;
  line-height: 32px;
  top: 8px;
  right: 0;
}

.login-out-blank {
  padding: 0 5px;
}

.show-menu-item {
  width: 33%;
  float: left;
  min-height: 388px;
}

.show-menu-item-title {
  font-size: 14px;
  color: #333;
  height: 52px;
  line-height: 52px;
  text-align: left;
}

.show-menu-item-inner {
  font-size: 12px;
  color: #888;
}

.show-menu-item-inner span {
  display: -moz-inline-stack;
  display: inline-block;
  vertical-align: middle;
  zoom: 1;
  line-height: 30px;
  min-width: 150px;
  text-align: left;
  font-size: 12px;
  float: left;
  white-space: nowrap;
  display: inline-block;
  word-wrap: break-word;
  word-break: normal;
  cursor: text;
}

.show-menu-item-inner span.existence {
  color: #0082ff;
  cursor: pointer;
}
.msg-container .show-msg-item {
  padding: 14px 0;
  border-bottom: 1px solid #eeeeee;
}
.msg-container .show-msg-item .show-msg-item-title {
  line-height: 17px;
}
.msg-container .show-msg-item:last-child {
  border-bottom: 0;
}
.go-center {
  padding: 0 20px;
  background: #313131;
  text-align: center;
  font-weight: bold;
  margin-right: 20px;
}
.go-center span {
  color: #c99f4f !important;
}
</style>
