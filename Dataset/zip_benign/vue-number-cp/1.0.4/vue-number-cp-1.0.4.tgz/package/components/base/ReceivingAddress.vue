<template>
    <!--<div class="edit-receiving-address">-->
    <el-dialog class="dialog" :title="'收货地址'" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="870px" center :close-on-click-modal="false">
      <!--<div class="receiving-address-wrap">-->
        <!--<i class="close el-icon-close" @click="closeModal"></i>-->
        <!--<p class="title">收货地址</p>-->
        <!--<slot name="dialog-header"></slot>-->
        <el-form ref="form" :model="form" :rules="rules" >
            <ul class="receiving-address-ul tl">
                <li>
                    <el-form-item label="收货人：" prop="name">
                      <el-input v-model="form.name" placeholder="请填写收货人"></el-input>
                    </el-form-item>
                </li>
                <li class="special">
                    <el-form-item class="shengshiqu is-success is-required" label="省市区：" prop="provCode">
                        <Distpicker :address="shengshiqu" @receive="getAddressCode"></Distpicker>
                    </el-form-item>
                </li>
                <li class="textarea-center">
                    <el-form-item label="详细地址：" prop="addr">
                      <el-input type="textarea" maxlength="100" rows='2' v-model="form.addr" placeholder="请如实填写详细地址"></el-input>
                    </el-form-item>
                </li>
                <li>
                    <el-form-item label="邮政编码：" prop="zipCode">
                      <el-input v-model="form.zipCode" placeholder="请填写邮政编码"></el-input>
                    </el-form-item>
                </li>
                <li>
                    <el-form-item label="手机号：" prop="mobile">
                      <el-input v-model="form.mobile" placeholder="请填写手机号"></el-input>
                    </el-form-item>
                </li>
                <el-form-item label="" prop="default">
                    <el-checkbox v-model="form.default" name="default" >设置为默认收货地址</el-checkbox>
                </el-form-item>
            </ul>
        </el-form>
        <div class="receiving-address-footer">
            <div class="receiving-footer-wrap">
                <div class="left" @click="submit('rules')">保存</div>
                <div class="right" @click="closeModal">取消</div>
            </div>
        </div>
      <!--</div>-->
    </el-dialog>
    <!--</div>-->
</template>

<script>
// import $ from 'jquery';
import Distpicker from "@/components/base/Distpicker";   
export default {
    props:{
        ifNew:{
          type:Object
        },
    },
    components:{
      Distpicker
    },
    data () {
        return {
          wrapHeight:0,
          nameList:{},
            dialogVisible:true,
            shengshiqu:{},
          form:{
            name:'',
            provCode:'',
            cityCode:'',
            districtCode:'',
            addr:'',
            zipCode:'',
            mobile:'',
            default:false,
          },
          rules:{
            name: [
                {
                    required: true,
                    message: "请填写收货人"
                },
                { pattern: /^[^\s]{1,20}$/, message: '收货人支持1-20个字' , trigger: "blur"}
            ],
            provCode: [
                {
                    required: true,
                    message: "请选择地址信息",
                }
            ],
            cityCode: [
                {
                    required: true,
                    message: "请选择地址信息",
                }
            ],
            districtCode: [
                {
                    required: true,
                    message: "请选择地址信息",
                }
            ],
            addr: [
                {
                    required: true,
                    message: "请填写详细地址"
                }
            ],
            zipCode: [
                {
                    required: true,
                    message: "请填写正确的邮政编码"
                },
                { pattern: /^\d{6}$/, message: '请填写正确的邮政编码' , trigger: "blur"}
            ],
            mobile:[
                {
                    required: true,
                    message: "请填写手机号"
                },
                { pattern: /^\d{11}$/, message: '请填写正确的手机号' , trigger: "blur"}
            ]
          }
        }
    },
    methods:{
        getAddressCode(res,list){
            let pro = res
            this.form.provCode = res.provinceCode || "";
            this.form.cityCode = res.cityCode || "";
            this.form.districtCode = res.blockCode || "";
            if( list ){
                this.nameList = list;
            }
        },
        closeModal(){
            this.$emit('closeModal', false)
        },
        submit(rules){
            this.$refs.form.validate( (valid)=>{
                if(valid){
                    let data = this.form;
                    if( this.form.default ){
                        data.defaultFlg = '1'
                    }else{
                        data.defaultFlg = '0'
                    }
                    if( this.ifNew.addressId ){
                        data.addressId = this.ifNew.addressId
                    }
                    data.provCodeDisp = this.nameList.provinceName
                    data.cityCodeDisp = this.nameList.cityName
                    data.districtCodeDisp = this.nameList.blockName
                    this.$emit('addressData',data)
                }else{
                    return
                }
            } )
        }
    },
    mounted(){
        let self = this

        // setTimeout(function(){
        // self.wrapHeight =  document.body.scrollHeight
        // },0)
        if( this.ifNew.name ){
            this.form.name = this.ifNew.name;
            this.form.addr = this.ifNew.addr || ""
            this.form.zipCode = this.ifNew.zipCode || ""
            this.form.mobile = this.ifNew.mobile || "";
            this.form.provCode = this.ifNew.provCode || "";
            this.form.cityCode = this.ifNew.cityCode || "";
            this.form.districtCode = this.ifNew.districtCode || "";
            this.shengshiqu.provCode = this.ifNew.provCode || "";
            this.shengshiqu.cityCode = this.ifNew.cityCode || "";
            this.shengshiqu.blockCode = this.ifNew.districtCode || "";
            // $('.special .el-form-item').addClass('is-success is-required')
            if( this.ifNew.defaultFlg == '1' ){
                this.form.default = true
            }
        }
    }
}
</script>

<style lang="scss" scoped>
.edit-receiving-address{
  width: 100%;
  height: 1412px;
  position: absolute;
  top: 0;
  left: 0;
  z-index: 99;
  background: rgba(0,0,0,0.5);
}
.receiving-address-wrap{
  width: 900px;
  height: 530px;
  background: white;
  /*position: absolute;*/
  top: 262px;
  left: 50%;
  margin-left: -450px;
  padding: 20px 40px 0;
  z-index:99;
}
.receiving-address-wrap .close{
    position: absolute;
    top: 14px;
    right: 14px;
    width: 16px;
    cursor: pointer;
}
.receiving-address-wrap .title{
    width: 100%;
    border-bottom: 1px solid #eeeeee;
    font-size: 14px;
    color: #444444;
    text-align: center;
    height: 54px;
    line-height: 54px;
}
.receiving-address-ul li{
    height: 66px;
    line-height: 66px;
}
.textarea-center{
    display: flex;
    align-items:center;
}
.receiving-address-ul /deep/ .el-form-item__label{
    width: 102px;
    padding: 0;
    display: inline-block;
}
.receiving-address-ul /deep/ .el-input{
    width: 200px;
}
.receiving-address-ul /deep/ .el-textarea{
    width: 620px;
}
.receiving-address-ul /deep/ .el-form-item{
    display: inline-block;
    width: 100%;
    margin: 0;
}
.receiving-address-ul /deep/ .el-textarea__inner{
    resize:none;
}
.receiving-address-ul /deep/ .el-form-item__content{
    margin-left: 102px;
}
.el-form-item.shengshiqu /deep/ .el-form-item__content .el-input{
  width: 200px;
}
.el-form-item.shengshiqu .linkage /deep/ .el-select{
  width: 29%;
}
.receiving-address-footer{
    margin-top: 16px;
    width: 100%;
    height: 34px;
    text-align: center;
}
.receiving-footer-wrap{
    display: inline-block;
    height: 100%;
    width: 240px;
}
.receiving-footer-wrap .left,.receiving-footer-wrap .right{
    float: left;
    height: 32px;
    width: 108px;
    border: 1px solid #4f525a;
    background: #f6f6f7;
    line-height: 32px;
    cursor: pointer;
}
.receiving-footer-wrap .left{
    background: #ffd64e;
    border: 1px solid #ffd64e;
}

.receiving-footer-wrap .right{
    float: right;
}
</style>
