<template>
    <label class="mo-upload">
        <input type="file" :accept="accepts" @change="upload">
        <slot></slot>
    </label>
</template>
<style scoped>
    .mo-upload {
        display: inline-block;
        position: relative;
        margin-bottom: 0;
        
    }
    input[type="file"] {
        display: none;
    }
    .mo-upload--label {
      display: inline-block;
      position: relative;
    }
</style>
<script>
    import { InterfaceService } from '@/services/api'
    export default {
        name : 'MoUpload',
        props : {
            accepts : { //允许的上传类型
                type : String,
                default : '*'
            },
            flag : [String, Number], //当前上传标识,以便于在同一个监听函数中区分不同的上传域
            maxSize : {
                type : Number,
                default : 0 //上传大小限制
            }, 
        },
        methods: {
            upload (event) {
                let file = event.target.files[0]
                let fileSize = file.size
                const self = this
                const flag = this.flag
                console.log(this.maxSize)
                if (file) {
                    if (this.maxSize) {
                        //todo filter file
                    }
                    //filter file, 文件大小,类型等过滤
                    //如果是图片文件
                    // const reader = new FileReader()
                    // const imageUrl = reader.readAsDataURL(file)
                    // img.src = imageUrl //在预览区域插入图片

                    const formData = new FormData()
                    formData.append('file', file)
                    //console.log(formData)
                    InterfaceService.exportOrder(formData,(data) => {
                        self.$emit('complete');
                    },data => {
                        self.$emit('uploadError');
                    },() => {
                        self.isLoading = true;
                    },() => {
                        self.isLoading = false;
                    },(data)=>{
                        self.$emit('progress',data);
                    });
                    
                }
            }
        }
    }
</script>