<template>
  <div class="app-footer" :style="{background: bgColor || ''}">
    <div class = "app-footer-header inner-container clearfloat">
      <div class="footer-wrapper">
        <div class="footer-item special-s">
          <h4 class="footer-item-title"><span>大家采官网</span></h4>
          <p><a @click="handleChangeIndex" target="_blank">> 绿地大家采</a></p>
        </div>
        <div class="footer-item special-s">
          <h4 class="footer-item-title"><span>关于我们</span></h4>
          <p @click="goAboutUs('1')">> 平台介绍</p>
          <p @click="goAboutUs('2')">> 绿地控股集团</p>
          <p @click="goAboutUs('3')">> 绿地大基建集团</p>
          <p @click="goAboutUs('4')">> 绿地建材集团</p>
        </div>
        <div class="footer-item special-m">
          <h4 class="footer-item-title"><span>招标信息</span></h4>
          <p @click="goBidPage('biddingAnnouncement')">> 招标公告</p>
          <p @click="goBidPage('bidWinningAnnouncement')">> 中标公司</p>

        </div>
        <div class="footer-item special-s">
          <h4 class="footer-item-title"><span>合作伙伴</span></h4>
          <p style="padding-right: 40px;" @click="goListOfPurchasers()">> 采购商合作</p>
        </div>
      </div>
      <div class="contact-info">
        <ul>
          <li class="first">
            <p class="f14">客服电话<span style="padding-left: 10px;font-size: 12px">{{$platformContact()['hotLine']}}</span></p>
            <p> {{$platformContact()['hotLineTime']}}</p>
          </li>
          <li class="second">
            <p class="f14" style="line-height: 32px;margin-bottom: 0;">客服微信<span style="padding-left: 10px;font-size: 12px">{{$platformContact()['wx']}}</span></p>
          </li>
          <li class="third">
            <p class="f14">合约监督电话 <span style="padding-left: 10px;font-size: 12px">021-23296223</span></p>
            <p class="f14">合约投诉邮箱 <span style="padding-left: 10px;font-size: 12px">hq_hy@ldjt.com.cn</span></p>
          </li>
        </ul>
      </div>
      <div class="contact-wx clearfloat">
        <div class="wx-qrcode">
          <p class="maer-title">微信客服</p>
          <div class="maer-img"><img src="../../assets/images/fixedTool/wechat_customer_code.png" alt=""></div>
        </div>
      </div>
      <div class="contact-wx clearfloat" style="margin-left: 25px;position: absolute;">
        <div class="wx-qrcode">
          <p class="maer-title">微信公众号</p>
          <div class="maer-img"><img src="../../assets/images/fixedTool/wechat_account_code.png" alt=""></div>
        </div>
      </div>
      <div class="contact-wx clearfloat" style="margin-left: 167px;position: absolute;">
        <div class="wx-qrcode">
          <p class="maer-title">合约监管投诉</p>
          <div class="maer-img"><img src="../../assets/images/fixedTool/complaint_code.png" alt=""></div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
  import {
    BASE_CONFIG
  } from '@/config/config'
  export default {
    props: ['bgColor'],
    data () {
      return {
      }
    },
    methods: {
      handleChangeIndex() {
        window.open(BASE_CONFIG.OFFICIAL_URL,"_blank");
      },
      goListOfPurchasers() {
        // https://sit.dajiacai.net/static/map/index.html#/
        window.open(BASE_CONFIG.OFFICIAL_URL + '/static/map/index.html', '_blank')
      },
      goBidPage(type) {
        this.$router.push('/' + type)
      },
      goAboutUs(index) {
        window.open(BASE_CONFIG.OFFICIAL_URL + '/#/aboutUs?aboutType=' + index,"_blank");
      },
      go(path){
        this.$router.push({
          path:path
        });
      }
    },
  }
</script>

<style scoped>
  /*.app-footer{width: 100%;background: url("../../assets/images/home/snow/bottom_bg.png");height:200px;}*/
  .app-footer {
    width: 100%;
    background: -webkit-linear-gradient(-245deg, #555, #000); /* Safari 5.1 - 6.0 */
    background: -o-linear-gradient(-245deg, #555, #000); /* Opera 11.1 - 12.0 */
    background: -moz-linear-gradient(-245deg, #555, #000); /* Firefox 3.6 - 15 */
    background: linear-gradient(-245deg, #555, #000); /* 标准的语法（必须放在最后） */
    height: 200px;
    position: relative;
    z-index: 999;
  }

  .footer-wrapper {
    float: left;
    height: 100%;
    padding-top: 20px;
  }

  .footer-item {
    position: relative;
    float: left;
    height: 100%;
  }
  .footer-item p {
    font-size: 12px;
    color: rgb(255, 255, 255);
    text-align: left;
    padding-right: 35px;
    height: 20px;
    line-height: 20px;
    cursor: pointer;
  }

  .footer-item-title {
    height: 44px;
    line-height: 44px;
    font-size: 14px;
    color: rgb(255, 255, 255);
    text-align: left;
  }

  .footer-item-title span {
    font-size: 14px;
  }

  .footer-item-bd {
    padding-top: 16px;
  }

  .footer-item-bd-left {
    width: 50%;
    height: 50px;
    float: left;
    padding-right: 10px;
    text-align: right;
    font-size: 14px;
    color: rgb(255, 255, 255);
  }

  .footer-item-bd-right {
    width: 50%;
    height: 50px;
    float: left;
    padding-left: 10px;
    text-align: left;
    font-size: 14px;
    color: rgb(255, 255, 255);
  }

  .footer-item-line {
    line-height: 25px;
    height: 25px;
    cursor: pointer
  }

  .contact-info {
    width: 352px;
    float: left;
    height: 100%;
    padding-top: 30px;
  }

  .contact-info ul {
    border-left: 1px solid rgba(255, 255, 255, .2);
  }

  .contact-info li {
    height: 32px;
    margin-bottom: 20px;
    padding-left: 55px;
    position: relative;
  }

  .contact-info li:before {
    content: '';
    background: url(../../assets/images/home/191119/service_first.png) no-repeat;
    background-position: 0 0;
    position: absolute;
    width: 32px;
    height: 32px;
    top: 50%;
    left: 15px;
    margin-top: -16px;
  }

  .contact-info li.second:before {
    background: url(../../assets/images/home/191119/service_second.png) no-repeat;
  }

  .contact-info li.third:before {
    background: url(../../assets/images/home/191119/complaint_icon.png) no-repeat;
    background-size: 32px;
  }

  /*.contact-info li:last-child:before{
    background:none;
  }*/
  .contact-info li p {
    line-height: 1;
    font-size: 12px;
    color: rgb(255, 255, 255);
    margin-bottom: 6px;
  }

  .contact-wx {
    width: 119px;
    display: inline-block;
    height: 100%;
    padding-top: 30px;
  }

  .wx-qrcode {
    float: right;
    height: 100%;
  }

  .maer-title {
    font-size: 14px;
    color: rgb(255, 255, 255);
    text-align: center;
    line-height: 1;
  }

  .maer-img img {
    display: block;
    margin: 10px auto 0;
    width: 112px;
    height: 112px;
  }
</style>
