<template>
    <div class="content">
        <canvas ref="canvas" width="600" height="300"></canvas>
        <i class="el-icon-delete" @click="handleDel"></i>
    </div>
</template>

<script>
import SignaturePad from "signature_pad/dist/signature_pad.umd";
export default {
    data() {
        return {
            signaturePad: {}
        };
    },
    methods: {
        clear() {
            this.signaturePad.clear();
        },
        getData() {
            return this.signaturePad.toDataURL();
        },
        handleDel() {
            this.signaturePad.clear();
        }
    },
    mounted() {
        this.signaturePad = new SignaturePad(this.$refs["canvas"]);
    }
};
</script>

<style lang="scss" scoped>
.content {
    position: relative;
    width: 600px;
    height: 300px;
    margin: auto;
    border: 1px solid #ccc;

    i {
        position: absolute;
        right: 0;
        bottom: 0;
        font-size: 30px;
        color: #ccc;
        cursor: pointer;
    }
}
</style>

