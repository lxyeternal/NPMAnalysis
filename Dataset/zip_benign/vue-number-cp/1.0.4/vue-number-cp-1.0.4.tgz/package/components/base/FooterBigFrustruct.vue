<template>
  <div class="app-footer" :style="{background: bgColor || ''}">
    <div class = "app-footer-header inner-container clearfloat">
      <div class="footer-wrapper">
        <div class="footer-item special-s">
          <h4 class="footer-item-title"><span>绿地大家采</span></h4>
          <p><a @click="handleChangeIndex" target="_blank">> 绿地大家采官网</a></p>
          <p><a @click="goIndex" target="_blank">> 建材集团</a></p>
        </div>
        <div class="footer-item special-s">
          <h4 class="footer-item-title"><span>绿地大基建集团</span></h4>
          <p @click="goOutUrl('http://www.gludgroup.cn')">> 绿地城建集团</p>
          <p @click="goOutUrl('http://www.gzjgjt.com')">> 贵州建工集团</p>
          <p @click="goOutUrl('http://www.xaceg.cn')">> 西安建工集团</p>
          <p @click="goOutUrl('http://www.gcjjt.com')">> 河南公路工程局</p>
        </div>
        <div class="footer-item special-s">
          <h4 class="footer-item-title"><span></span></h4>
          <p @click="goOutUrl('http://www.greenlandmi.com')">> 绿地城投集团</p>
          <p @click="goOutUrl('http://www.jpcec.com')">> 江苏省建集团</p>
          <p @click="goOutUrl('http://www.tjcon.cn')">> 天津建工集团</p>
          <p @click="goOutUrl('http://www.gxjgjt.cn')">> 广西建工集团</p>
        </div>
      </div>
      <div class="contact-info">
        <ul>
          <li class="first">
            <p class="f14">客服电话</p>
            <p>{{$platformContact()['hotLine']}}</p>
            <p> {{$platformContact()['hotLineTime']}}</p>
          </li>
          <li class="second">
            <p class="f14">客服微信</p>
            <p>{{$platformContact()['wx']}}</p>
          </li>
          <!--<li class="third">-->
          <!--<p class="f14">客服邮箱</p>-->
          <!--<p>{{$platformContact()['email']}}</p>-->
          <!--</li>-->

        </ul>
      </div>
      <div class="contact-wx clearfloat">
        <div class="wx-qrcode">
          <p class="maer-title">微信客服</p>
          <div class="maer-img"><img src="../../assets/images/fixedTool/wechat_customer_code.png" alt=""></div>
        </div>
      </div>
      <div class="contact-wx clearfloat" style="margin-left: 40px;position: absolute;">
        <div class="wx-qrcode">
          <p class="maer-title">微信公众号</p>
          <div class="maer-img"><img src="../../assets/images/fixedTool/wechat_account_code.png" alt=""></div>
        </div>
      </div>
    </div>

  </div>
</template>

<script>
  import {
    BASE_CONFIG
  } from '@/config/config'
  export default {
    props: ['bgColor'],
    data () {
      return {
      }
    },
    methods: {
      goOutUrl(url){
        window.open(url,"_blank");
      },
      handleChangeIndex() {
        window.open(BASE_CONFIG.OFFICIAL_URL,"_blank");
      },
      goListOfPurchasers() {
        // https://sit.dajiacai.net/static/map/index.html#/
        window.open(BASE_CONFIG.OFFICIAL_URL + '/static/map/index.html', '_blank')
      },
      goBidPage(type) {
        this.$router.push('/' + type)
      },
      goAboutUs(index) {
        window.open(BASE_CONFIG.OFFICIAL_URL + '/#/aboutUs?aboutType=' + index,"_blank");
      },
      go(path){
        this.$router.push({
          path:path
        });
      },
      goIndex() {
          this.$router.push('/home')
      },
    },
  }
</script>

<style scoped>
  /*.app-footer{width: 100%;background: url("../../assets/images/home/snow/bottom_bg.png");height:200px;}*/
  .app-footer {
    width: 100%;
    background: -webkit-linear-gradient(-245deg, #555, #000); /* Safari 5.1 - 6.0 */
    background: -o-linear-gradient(-245deg, #555, #000); /* Opera 11.1 - 12.0 */
    background: -moz-linear-gradient(-245deg, #555, #000); /* Firefox 3.6 - 15 */
    background: linear-gradient(-245deg, #555, #000); /* 标准的语法（必须放在最后） */
    height: 200px;
    position: relative;
    z-index: 999;
  }

  .footer-wrapper {
    float: left;
    height: 100%;
    padding-top: 20px;
  }

  .footer-item {
    position: relative;
    float: left;
    height: 100%;
  }
  .footer-item p {
    font-size: 12px;
    color: rgb(255, 255, 255);
    text-align: left;
    padding-right: 75px;
    height: 20px;
    line-height: 20px;
    cursor: pointer;
  }

  .footer-item-title {
    height: 44px;
    line-height: 44px;
    font-size: 14px;
    color: rgb(255, 255, 255);
    text-align: left;
  }

  .footer-item-title span {
    font-size: 14px;
  }

  .footer-item-bd {
    padding-top: 16px;
  }

  .footer-item-bd-left {
    width: 50%;
    height: 50px;
    float: left;
    padding-right: 10px;
    text-align: right;
    font-size: 14px;
    color: rgb(255, 255, 255);
  }

  .footer-item-bd-right {
    width: 50%;
    height: 50px;
    float: left;
    padding-left: 10px;
    text-align: left;
    font-size: 14px;
    color: rgb(255, 255, 255);
  }

  .footer-item-line {
    line-height: 25px;
    height: 25px;
    cursor: pointer
  }

  .contact-info {
    width: 352px;
    float: left;
    height: 100%;
    padding-top: 30px;
  }

  .contact-info ul {
    border-left: 1px solid rgba(255, 255, 255, .2);
  }

  .contact-info li {
    height: 32px;
    margin-bottom: 53px;
    padding-left: 55px;
    position: relative;
  }

  .contact-info li:before {
    content: '';
    background: url(../../assets/images/home/191119/service_first.png) no-repeat;
    background-position: 0 0;
    position: absolute;
    width: 32px;
    height: 32px;
    top: 50%;
    left: 15px;
    margin-top: -16px;
  }

  .contact-info li.second:before {
    background: url(../../assets/images/home/191119/service_second.png) no-repeat;
  }

  .contact-info li.third:before {
    background: url(../../assets/images/home/191119/service_third.png) no-repeat;
  }

  /*.contact-info li:last-child:before{
    background:none;
  }*/
  .contact-info li p {
    line-height: 1;
    font-size: 12px;
    color: rgb(255, 255, 255);
    margin-bottom: 6px;
  }

  .contact-wx {
    width: 119px;
    display: inline-block;
    height: 100%;
    padding-top: 30px;
  }

  .wx-qrcode {
    float: right;
    height: 100%;
  }

  .maer-title {
    font-size: 14px;
    color: rgb(255, 255, 255);
    text-align: center;
    line-height: 1;
  }

  .maer-img img {
    display: block;
    margin: 10px auto 0;
    width: 112px;
    height: 112px;
  }
</style>
