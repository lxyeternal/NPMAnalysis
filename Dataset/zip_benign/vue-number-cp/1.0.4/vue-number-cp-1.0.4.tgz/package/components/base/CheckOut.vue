<template>
  <div>
    <div class="buy-sumit">
      <slot name="whichTotal"></slot>
      <p class="re-add" v-show="receivingAddress">送货至: {{receivingAddress}}</p>
      <p class="re-add" v-show="consignee">收货人: {{consignee}}</p>
    </div>
    <div class="buy-agreement">
      <slot name="goback"></slot>
      <slot name="nextStep"></slot>
      <slot name="toDo"></slot>
    </div>
  </div>
</template>

<script>
export default {
  props:{
      receivingAddress:{
        type:String
      },
      consignee:{
        type:String
      },
  },
}
</script>

<style scoped>
.buy-sumit{
  position: relative;
  background: #f5f5f5;
  margin-top: 20px;
  border-top: 1px solid #dddddd;
  padding: 22px 46px 25px 0;
}
.buy-sumit .total{
  text-align: right;
  font-size: 14px;
  color: #4f525a;
  height: 34px;
  line-height: 34px;
}
.buy-sumit .total span{
  color: #e93340
}
.buy-sumit .total span i{
  font-size: 18px;
}
.buy-sumit .money{
  font-size: 12px;
  color: #888888;
  line-height: 24px;
  text-align: right;
}
.buy-sumit .margin-five{
  margin-bottom: 5px;
}
.buy-sumit .re-add{
  text-align: right;
  font-size: 12px;
  color: #888888;
  height: 22px;
  line-height: 22px;
  white-space:nowrap;
  max-width: 100%;
  overflow:hidden;
  text-overflow:ellipsis;
}
.buy-agreement{
  /* width: 100%;
  margin-bottom: 96px; */
  height: 50px;
}
.buy-agreement .goback-button{
  float: left;
  height: 50px;
  width: 1002px;
  background: #fff;
  text-align: right;
  line-height: 50px;
  cursor: pointer;
  font-size: 14px;
}
.buy-agreement .sub-button{
  float: right;
  height: 50px;
  width: 170px;
  background: #ffd64e;
  text-align: center;
  line-height: 50px;
  cursor: pointer;
  font-size: 14px;
}
.buy-agreement .sub-button.disabled{
  cursor: not-allowed;
  background: #ccc;
}
.buy-agreement .agree{
  float: right;
  height: 50px;
  line-height: 50px;
  margin-right: 20px;
}
.buy-agreement .agree span{
  color: #1690e0;
}
.buy-agreement .agree /deep/ .el-checkbox__label .black{
  color: black;
}
.agree /deep/ .el-checkbox__inner{
  z-index: 0;
}
.total-magin{
  margin-right: 120px;
}
</style>
