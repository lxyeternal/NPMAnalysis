<!-- 组件使用 <PhoneCode :is-show-validate="isShowValidate" :type="1" @received="getCode" @error=""></PhoneCode> -->
<template>
  <div class='phone-code'>
    <div v-if="type == '1'">
      <el-input type="tel" :placeholder="placeholder" v-model="validateCode" @keyup.native="checkPwd($event)" @blur="handleInput($event)" clearable>
      </el-input>
      <el-button class="verify-btn" :disabled='isStop || disable' :class="{'active':isStop || disable}" @click="getPhoneCode('SMS')"><span v-if="!isStop">{{btnContent}}</span><span v-if="isStop">{{duration}}秒后可重试</span></el-button>
    </div>
    <div v-if="type == '2'">
      <el-input type="tel" placeholder="请输入邮箱收到的验证码" v-model="validateCode" @keyup.native="checkPwd($event)" @blur="handleInput($event)" clearable>
      </el-input>
      <el-button class="verify-btn" :class="{'active':isStop || disable}" @click="getPhoneCode('EMAIL')"><span v-if="!isStop">获取邮箱验证码</span><span v-if="isStop">{{duration}}秒后可重试</span></el-button>
    </div>
    <el-dialog class="dialog" :title="'获取验证码'" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="840px" center :close-on-click-modal="false" @close="imgValidateCode = ''">
      <div style="width: 380px;margin: 0 auto;">
        <ValidateCode @received="handleChangeValidCode" :update="updateCode"></ValidateCode>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm" :disabled="imgValidateCode.length < 4">确认</el-button>
        <el-button size="small" style="width: 100px" @click="handleCancel">取消</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>

</template>

<script>
import { InterfaceService } from '@/services/api'
import Loading from "@/components/base/Loading";
import ValidateCode from '@/components/base/ValidateCode.vue';

export default {
  components: {
    Loading,
    ValidateCode,
  },
  props: {
    type: {  //1:手机验证码  2：邮箱验证码
      type: String,
      default: '1'
    },
    isShowPhoneCode: {//是否显示组件
      type: Boolean,
      default: false
    },
    update: {//监听更新组件
      type: Number,
      default: 0
    },
    phone: {//手机验证码：传入手机号  邮件验证码：传入邮件
      type: String,
      default: ''
    },
    disable: {//按钮是否可以点击
      type: Boolean,
      default: false
    },
    origTxCode: {//按钮是否可以点击
      // 'register':'010001' 注册； 'forgetPwd':'020004'忘记密码； 'acitveAccount':'020005'激活账户；
      // 'changePhone':'040010'修改手机号；'changeEmail':'040011修改邮箱；
      type: String,
      default: ''
    },
    imgCode: {//传入图片验证码
      type: String,
      default: ''
    },
    placeholder:{
      type: String,
      default: '请输入手机收到的验证码'
    },
    btnContent:{
      type: String,
      default: '获取短信验证码'
    }
  },
  data() {
    return {
      number: 4,
      validateCode: '',
      isStop: false,
      dialogVisible: false,
      imgValidateCode: "",
      showImgErr: "",
      updateCode: 0,
      duration: 60,
      timer: '',
      phoneCode: '',
      isLoading: false
    }
  },
  watch: {
    update(val) {
      if (val) {
        // this.isStop = false;
        // this.duration = 60
        //this.validateCode = ''
        //this.$emit('received',this.validateCode);
      }
    },
  },
  methods: {
    handleChangeValidCode(code) {
      console.log(code);
      this.imgValidateCode = code;
    },
    handleConfirm() {
      if (this.imgValidateCode.length == 4) {
        this.getPhoneCodeApi('SMS')
      }else {
        this.showImgErr = "请输入正确的图形验证码;"
      }
    },
    handleCancel() {
      this.dialogVisible = false;
      this.imgValidateCode = ""
    },
    getPhoneCodeApi(sendType) {
      let params = {
        'sendType': sendType,
        'target': this.phone,
        'origTxCode': this.$returnOrigTxCode(this.origTxCode),
        'validateCode': this.imgCode || this.imgValidateCode
      }
      InterfaceService.getPhoneCode(
        params,
        data => {
          console.log('MEM0063');

          if (this.origTxCode !== 'login') {
            this.isStop = true;
          }
          let res = data.respData;
          //console.log(data)
          if (res.respCode != "0000") {
            //console.log(res.respMsg)
            let errorMsg = '获取验证码错误'
            if (res.respMsg) {
              errorMsg = res.respMsg
            }
            //this.$message.error(errorMsg);
            if (this.origTxCode !== 'login') {
              this.$emit('error', errorMsg);
              this.isStop = false;
            }else {
              this.$message.error(errorMsg)
              this.updateCode++
            }
          }else {
            if (this.origTxCode === 'login') {
              this.isStop = true;
            }
            this.handleCancel();
          }
          this.duration = 60
          this.timedCount()

        },
        data => {
          // console.log(data)
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    handleInput: function (e) {
      // this.validateCode = this.validateCode.replace(/\D+/, '')
      //this.$emit('received',this.validateCode);
    },
    checkPwd() {
      this.validateCode = this.validateCode.replace(/\D+/, '')
      this.validateCode = this.validateCode.substr(0, 4)
      this.$emit('received', this.validateCode);
    },
    getPhoneCode(type) {
      if (this.phone && !this.isStop) {
        if (this.origTxCode === 'login'){
          this.dialogVisible = true;
          this.updateCode++
        } else {
          this.getPhoneCodeApi(type)
        }
      }
    },
    timedCount() {//保持禁用,倒计时
      clearTimeout(this.timer);
      if (this.duration == 0) {
        this.isStop = false;
        this.duration = 60
      } else {
        this.timer = setTimeout(() => {
          this.duration--;
          this.timedCount();
        }, 1000)
      }
    }

  },
  mounted() {
    clearTimeout(this.timer);
    console.log(1111);
  }
}
</script>

<style scoped>
.phone-code {
  position: relative;
  height: 100%;
  width: 100%;
}
.phone-code input {
  width: 100%;
  height: 100%;
  border: 1px solid #ddd;
  font-size: 12px;
  text-indent: 20px;
  box-sizing: border-box;
}
.phone-code input:focus {
  border-color: #c99f4f;
}
.verify-btn {
  height: 99%;
  position: absolute;
  top: 50%;
  right: 0;
  transform: translate(0, -50%);
  -webkit-transform: translate(0, -50%);
  -o-transform: translate(0, -50%);
  background: linear-gradient(120deg,rgba(215,176,100,1) 0%,rgba(236,206,139,1) 100%);
  color: #fff;
  font-size: 16px;
  padding: 0 30px;
  cursor: pointer;
}
.verify-btn.active {
  background-color: #bbb;
  color: #888;
  cursor: not-allowed;
}
/deep/ .el-button.is-disabled, .el-button.is-disabled:hover, .el-button.is-disabled:focus{
  background: linear-gradient(120deg,rgba(215,176,100,1) 0%,rgba(236,206,139,1) 100%);
}

</style>
