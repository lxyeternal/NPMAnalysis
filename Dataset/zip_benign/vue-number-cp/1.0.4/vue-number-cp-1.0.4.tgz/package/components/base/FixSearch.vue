 <template name="el-fade-in-linear">
  <div class="table-thead-fixed" v-show="isShowTableThead" :class="{'bg':width}">
    <div class="inner-container">
      <div :style="{'height' : Height + 'px','width' : width + 'px', 'left' : left + 'px',}" :class="{'bg':width}">
        <slot name="center"></slot>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    width: {
      type: String,
      default: ''
    },
    left: {
      type: String,
      default: '0'
    },
    Height: {
      type: String,
      default: '50'
    },
    TopDistance: {
      type: Number,
      default: 610
    }
  },
  data() {
    return {
      isShowTableThead: false
    }
  },
  mounted() {
    window.addEventListener('scroll', this.handleScroll, true)
  },
  destroyed() {
    window.removeEventListener("scroll", this.handleScroll, true);
  },
  methods: {
    handleScroll(e) {
      if (!e.target.documentElement || !e.target.body) return
      let scrollTop = e.target.documentElement.scrollTop || e.target.body.scrollTop;
      scrollTop > this.TopDistance ? this.isShowTableThead = true : this.isShowTableThead = false
    },
  }
}
</script>
<style lang="scss" scoped>
.table-thead-fixed {
  width: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 2;
  animation: showFixed 0.3s 1;
  top: 0;
  background-color: #000;
  &.bg {
    background-color: transparent;
  }
  @keyframes showFixed {
    0% {
      top: -100px;
    }
    50% {
      top: -50px;
    }
    100% {
      top: 0;
    }
  }
  .inner-container {
    > div {
      position: relative;
      &.bg {
        background-color: #000;
      }
    }
  }
}
</style>