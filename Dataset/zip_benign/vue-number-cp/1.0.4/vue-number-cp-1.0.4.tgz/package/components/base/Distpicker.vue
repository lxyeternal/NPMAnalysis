<!-- 组件使用 <ValidateCode :is-show-validate="isShowValidate" @received="getCode"></ValidateCode> -->
<template>
  <div>
    <div class="linkage" v-if="!isProjectOpt">
      <el-select
        v-model="provinceCode"
        @change="choseProvince"
        placeholder="省级地区"
        :disabled="isdisabledBigFrastructure"
        >
        <el-option
          v-for="(item,key) in province"
          :key="key"
          :label="item"
          :value="key">
        </el-option>
      </el-select>
      <el-select
        v-model="cityCode"
        @change="choseCity"
        :disabled="(Object.keys(city).length == 0) || isdisabledBigFrastructure"
        placeholder="市级地区"
        >
        <el-option
          v-for="(item,cid) in city"
          :key="cid"
          :label="item"
          :value="cid">
        </el-option>
      </el-select>
      <el-select
        v-show="isDistrict"
        v-model="blockCode"
        @change="choseBlock"
        :disabled="Object.keys(block).length == 0"
        placeholder="区级地区">
        <el-option
          v-for="(item,qid) in block"
          :key="qid"
          :label="item"
          :value="qid">
        </el-option>
      </el-select>
      <Loading :is-loading="isLoading"></Loading>
    </div>
    <div style="width: 100%;" v-if="isProjectOpt">
      <el-form class="form" :model="form" size="small" label-width="155px">
        <el-row>
          <el-col :span="8">
            <el-form-item label="项目省份：" >
              <el-select
                v-model="provinceCode"
                @change="choseProvince"
                placeholder="省级地区">
                <el-option
                  v-for="(item,key) in province"
                  :key="key"
                  :label="item"
                  :value="key">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="项目城市：" >
              <el-select
                v-model="cityCode"
                @change="choseCity"
                :disabled="Object.keys(city).length == 0"
                placeholder="市级地区">
                <el-option
                  v-for="(item,cid) in city"
                  :key="cid"
                  :label="item"
                  :value="cid">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="项目地区：" >
              <el-select
                v-model="blockCode"
                @change="choseBlock"
                :disabled="Object.keys(block).length == 0"
                placeholder="区级地区">
                <el-option
                  v-for="(item,qid) in block"
                  :key="qid"
                  :label="item"
                  :value="qid">
                </el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
  import Loading from "@/components/base/Loading";
  // import DISTRICTS from '@/utils/districts';
  import { InterfaceService } from "@/services/api";
  import {mapActions, mapState} from 'vuex'
  const DEFAULT_CODE = 100000;
  export default {
    props:{
      address:{
        type: Object,
        default: function () {
          return {'provCode':'','cityCode':'','blockCode':''}
        }
      },
      areaList:{
        type: Array,
        default: function () {
          return []
        }
      },
      isProjectOpt:{
        type: Boolean,
        default: false
      },
      isDistrict:{
        type: Boolean,
        default: true
      },
      isdisabledBigFrastructure:{
        type: Boolean,
        default: false
      }
    },
    components:{
      Loading
    },
    data () {
      return {
        province:'',
        isLoading:false,
        provinceCode: '',
        provinceName:'',
        city: [],
        DISTRICTS: {
          100000:{}
        },
        form:{},
        cityCode: '',
        cityName:'',
        block: [],
        blockCode: '',
        blockName:'',

        res:{},
        nameList:{}
      }
    },
    watch:{
      address(n,o){
        // this.init()
        this.provinceCode = this.address.provCode
        this.city = this.getDistricts(this.provinceCode)
        this.cityCode = this.address.cityCode
        this.block = this.getDistricts(this.cityCode)
        this.blockCode = this.address.blockCode
      }
    },
    mounted(){
      this.init()

    },
    methods:{
      ...mapActions(['setNationalRegionListAction']),
      arrangementDISTRICTSList(districtsList) {
        districtsList.forEach(item=>{
          if (item.level == "1") {
            this.DISTRICTS[100000][item.areaCode] = item.areaName;
            this.DISTRICTS[item.areaCode] = {}
          }
          if (item.level == "2"){
            for (let i in this.DISTRICTS[100000]) {
              if (i == item.p_areaCode){
                this.DISTRICTS[i][item.areaCode] = item.areaName
                this.DISTRICTS[item.areaCode] = {}
              }
            }
          }
        });
        districtsList.forEach(item=>{
          if (item.level == "3"){
            this.DISTRICTS[item.p_areaCode][item.areaCode] = item.areaName
          }
        });
        this.province = this.getDistricts(DEFAULT_CODE)
        let self = this;
        console.log(self.address);
        if(self.address.provCode && self.address.cityCode){
          setTimeout(()=>{
            self.provinceCode = self.address.provCode
            self.city = self.getDistricts(self.provinceCode)
            self.cityCode = self.address.cityCode
            self.block = self.getDistricts(self.cityCode)
            self.blockCode = self.address.blockCode
            if (Object.keys(this.block).length == 0) {
              this.res['provinceCode'] = self.provinceCode;
              this.res['cityCode'] = self.cityCode;
              this.res['blockCode'] = "noCode";
              this.$emit('receive', this.res)
            }
          },100)
        }
      },
      getDistrictsList() {
          let params = { //给予后端的入参
            level: "1,2,3",
          };
          InterfaceService.getDistrictsList(params, data => {
            if (data.respData.respCode === '0000') {
                let districtsList = data.respData.areaList || [];
                this.arrangementDISTRICTSList(districtsList)
                this.setNationalRegionListAction(districtsList)
              }
          }, data => {
          }, () => {
            this.isLoading = true
          }, () => {
            this.isLoading = false
          })
      },
      init() {
        if (!this.areaList.length) {
          if (this.$store.state.nationalRegionList && this.$store.state.nationalRegionList.length > 0) {
            let districtsList = this.$store.state.nationalRegionList;
            this.arrangementDISTRICTSList(districtsList)
          }else {
            this.getDistrictsList()
          }
        }else {
          this.arrangementDISTRICTSList(this.areaList)
        }
      },
      getDistricts(code) {
        return this.DISTRICTS[code] || []
      },
      // 选省
      choseProvince:function(e) {
        this.provinceName = this.province[this.provinceCode];
        this.res= {};
        this.res['provinceCode'] = this.provinceCode;
        this.$emit('receive', this.res)
        this.city = this.getDistricts(this.provinceCode)
        this.block = []
        this.cityCode = ''
        this.blockCode = ''
      },
      // 选市
      choseCity:function(e) {
        this.provinceName = this.province[this.provinceCode];
        this.cityName = this.city[this.cityCode]
        this.res = {};
        this.block = this.getDistricts(this.cityCode)
        if (Object.keys(this.block).length == 0) {
          this.blockCode = ''
          this.res['provinceCode'] = this.provinceCode;
          this.res['cityCode'] = this.cityCode;
          this.res['blockCode'] = "noCode";
          this.nameList['provinceName'] = this.provinceName;
          this.nameList['cityName'] = this.cityName;
          console.log(234234);
          this.$emit('receive', this.res,this.nameList)
        }else {
          this.res['provinceCode'] = this.provinceCode;
          this.res['cityCode'] = this.cityCode;
          this.$emit('receive', this.res);
          this.blockCode = ''
        }
      },
      // 选区
      choseBlock:function(e) {
        this.provinceName = this.province[this.provinceCode];
        this.cityName = this.city[this.cityCode]
        this.res= {};
        this.blockName = this.block[this.blockCode]
        this.res['provinceCode'] = this.provinceCode
        this.res['cityCode'] = this.cityCode
        this.res['blockCode'] = this.blockCode
        this.nameList['provinceName'] = this.provinceName;
        this.nameList['cityName'] = this.cityName;
        this.nameList['blockName'] = this.blockName;
        //通知父级 获取省市区code
        this.$emit('receive', this.res,this.nameList)
      },
    },
    created:function(){
      // console.log(this.province);
    }
  }
</script>

<style lang="scss" scoped>
  .linkage{
    width:100%;

    /deep/ .el-select {
      width: 32.9%
    }
  }
</style>
