 <template name="el-fade-in-linear">
  <div class="table-thead-fixed" :style="{top: `${fixedTop}px`, left: `-${offsetLeft}px`}" v-show="isShowTableThead" :class="{'bg':width}">
    <div class="inner-container">
      <div :style="{'height' : Height + 'px','width' : width + 'px', 'left' : left + 'px',}" :class="{'bg':width}">
        <table class="table-default">
          <thead>
            <slot name="tr"></slot>
          </thead>
        </table>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    fixedTop: {
      type: Number,
      default: 0
    },
    // 向左偏移量, 横向滚动时 匹配对应显示表格内容
    offsetLeft: {
      type: Number,
      default: 0
    },
    width: {
      type: String,
      default: ''
    },
    left: {
      type: String,
      default: '0'
    },
    Height: {
      type: String,
      default: '40'
    },
    TopDistance: {
      type: Number,
      default: 610
    }
  },
  data() {
    return {
      isShowTableThead: false
    }
  },
  mounted() {
    window.addEventListener('scroll', this.handleScroll, true)
  },
  destroyed() {
    window.removeEventListener("scroll", this.handleScroll, true);
  },
  methods: {
    handleScroll(e) {
      if (!e.target.documentElement || !e.target.body) return
      let scrollTop = e.target.documentElement.scrollTop || e.target.body.scrollTop;
      //   console.log(scrollTop, this.TopDistance)
      scrollTop > this.TopDistance ? this.isShowTableThead = true : this.isShowTableThead = false
    },
  }
}
</script>
<style lang="scss" scoped>
.table-thead-fixed {
  width: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 2;
  animation: showFixed 0.3s 1;
  top: 0;
  background-color: #000;
  &.bg {
    background-color: transparent;
  }
  @keyframes showFixed {
    0% {
      top: -100px;
    }
    50% {
      top: -50px;
    }
    100% {
      top: 0;
    }
  }
  .inner-container {
    > div {
      position: relative;
      &.bg {
        background-color: #000;
      }
    }
  }
  .table-default {
    margin-top: 0px;
    thead {
      border-bottom: none !important;
      tr {
        background-color: #000;
        td {
          padding-top: 10px !important;
          padding-bottom: 10px !important;
          color: #fff;
        }
      }
    }
  }
}
</style>