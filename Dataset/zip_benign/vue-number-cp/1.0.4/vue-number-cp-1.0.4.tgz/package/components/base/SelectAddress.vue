<template>
  <div class="quickbuy-adddress select-adddress">
    <div v-if="dialog">
      <div class="info-title tl">
        <span class="order-info-title bold fl">选择收货地址</span>
        <em v-if="!disabled" class="hand blue" @click="addNewAddress">+新增收货地址</em>
      </div>
    </div>
    <div v-else class="quickbuy-add-title">
      <span v-if="onlyOne">收货地址</span>
      <span v-else>选择收货地址</span>
      <i v-if="!onlyOne && !disabled" @click="addNewAddress">+新增收货地址</i>
    </div>
    <slot name="header"></slot>
    <p v-if="addressListArray.length == 0 && !disabled" class="no-quickbuy-add-list">没有找到已使用的收货地址，请先<span @click="addNewAddress">新增收货地址</span>。</p>
    <div class="quickbuy-add-list" :class="{'show-more':showMoreAddress,'add-two':!showMoreAddress}">
      <div class="quickbuy-adddress-bd clearfloat" :class="{'active':hasDefault&&address.choosed}" v-for="(address,index) in addressListArray" @click=" !disabled && selectAdress(index)" :key="index">
        <div class="quickbuy-adddress-bd-left">
          {{address.name}}
          <img src="../../assets/images/slected_active.png" />
        </div>
        <div class="quickbuy-adddress-bd-right">
          <span>{{address.provCodeDisp}}</span>
          <span>{{address.cityCodeDisp}}</span>
          <span>{{address.districtCodeDisp}}</span>
          <span class="limit-width">{{address.addr}}</span>
          <span>{{address.mobile}}</span>
          <span></span>
          <span v-if="!disabled" @click.stop="editAddress(index)" class="quickbuy-adddress-edit" style="margin-right: 20px;">修改</span>
          <span v-if="address.defaultFlg == '1' && !disabled" class="quickbuy-adddress-default">默认地址</span>
          <span @click.stop="setDefaultAdd(index)" v-if="address.defaultFlg == '0' && !disabled" class="quickbuy-adddress-edit">设为默认地址</span>
        </div>
        <div v-if="address.choosed" class="quickbuy-adddress-alert">
          <slot name="alert"></slot>
        </div>
      </div>
    </div>
    <div class="quickbuy-adddress-bd-more tl" :class="{'take-up':showMoreAddress}" v-if="!onlyOne&&addressListArray.length >1 && !disabled" @click="showMoreAdr()">
      <span class="tl" v-if="!showMoreAddress">显示更多 <i class="el-icon-d-arrow-left"></i></span><span v-else>收起 <i class="el-icon-d-arrow-right"></i></span>
    </div>
    <Receiving-address :ifNew="editAddressData" v-if="showEditAdd" @closeModal="ifShowModal" @addressData="getAddressData">
      <div v-if="$slots['dialog-header']" slot="dialog-header">
        <slot name="dialog-header"></slot>
      </div>
    </Receiving-address>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Loading from '@/components/base/Loading'
import ReceivingAddress from '@/components/base/ReceivingAddress'
import { InterfaceService } from '@/services/api'
export default {
  components: {
    Loading,
    ReceivingAddress
  },
  props: {
    drafts: {
      type: String,
      dafault: ''
    },
    // 通过传入 ID 设置默认选中
    addressId: {
      type: String,
      default: ''
    },
    onlyOne: {
      type: Boolean,
      default: false
    },
    hasDefault: {
      type: Boolean,
      default: true
    },
    dialog: {
      type: Boolean,
      default: false
    },
    // 是否disabled  默认 否
    disabled: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      isLoading: false,
      ifEdit: false, //是否需要编辑
      editAddressData: {}, //需要编辑的原数据
      showEditAdd: false, //弹出新增活着编辑收货地址弹层
      addressListArray: [], //收货地址列表
      showMoreAddress: false,
      storeShowMoreAddress: false,
      pushAddress: {}
    }
  },
  watch: {
    drafts(val, newVal) {
      if (newVal != val) {
        this.addressListArray.forEach((item, index, arr) => {
          if (item.addressId == this.drafts) {
            // item.choosed = true
            // this.pushAddress = item
            this.showMoreAddress = true
            this.selectAdress(index)
          }
        })
      }

    }
  },

  methods: {
    ifShowModal(res) {
      this.showEditAdd = res
      this.showMoreAddress = this.storeShowMoreAddress
    },
    addNewAddress() {
      this.ifEdit = false;
      this.editAddressData = {};
      this.showEditAdd = true;
      this.storeShowMoreAddress = this.showMoreAddress
      this.showMoreAddress = false;
      console.log(this.storeShowMoreAddress);
    },
    selectAdress(ind) {
      let add = null;
      this.addressListArray.forEach((item, index, arr) => {
        if (index === ind) {
          item.choosed = true
          this.pushAddress = item
          this.$emit('getAddresses', this.pushAddress)
        } else {
          item.choosed = false
        }
        this.$set(this.addressListArray, index, item);
      })
      if (this.showMoreAddress) {
        this.addressListArray.forEach((item, index, arr) => {
          if (ind === index) {
            add = item;
            arr.splice(index, 1);
            return;
          }
        })

        if (add) {
          this.addressListArray.unshift(add)
        }
        if (this.addressListArray.length > 1) {
          this.showMoreAddress = false;
        }
      }
    },
    handleAddressList() {
      if (this.addressListArray.length == 1) {
        this.addressListArray[0].choosed = true
        this.pushAddress = this.addressListArray[0]
      } else {
        if (this.drafts) {//草稿箱里有地址 则用草稿箱里的
          let matched = false
          this.addressListArray.forEach((item, index, arr) => {
            if (item.addressId == this.drafts) {
              // item.choosed = true
              // this.pushAddress = item
              this.showMoreAddress = true
              this.selectAdress(index)
              matched = true
            }
          })

          if (!matched) {//草稿箱里的地址不在地址列表里 则以默认地址为准
            this.addressListArray.forEach((item) => {
              if (item.defaultFlg == '1') {
                item.choosed = true
                this.pushAddress = item
              } else {
                item.choosed = false;
              }
            })
          }
        } else {
          this.addressListArray.forEach((item) => {
            if (item.defaultFlg == '1') {
              item.choosed = true
              this.pushAddress = item
            } else {
              item.choosed = false;
            }
          })
        }

      }
    },
    getAdrressList() {
      InterfaceService.addressList({}, (data) => {
        //this.addressListArray = []
        this.addressListArray = data.respData.shippingAddress || []

        if (this.addressListArray.length == 1) {
          this.addressListArray[0].choosed = true
          this.pushAddress = this.addressListArray[0]
        } else {
          if (this.drafts) {//草稿箱里有地址 则用草稿箱里的
            let matched = false
            this.addressListArray.forEach((item, index, arr) => {
              if (item.addressId == this.drafts) {
                // item.choosed = true
                // this.pushAddress = item
                this.showMoreAddress = true
                this.selectAdress(index)
                matched = true

                return;
              }
            })

            if (!matched) {//草稿箱里的地址不在地址列表里 则以默认地址为准
              this.addressListArray.forEach((item) => {
                if (item.defaultFlg == '1') {
                  item.choosed = true
                  this.pushAddress = item
                } else {
                  item.choosed = false;
                }
              })
            }
          } else {
            this.addressListArray.forEach((item) => {
              if (item.defaultFlg == '1') {
                item.choosed = true
                this.pushAddress = item
              } else {
                item.choosed = false;
              }
            })
          }

        }

        // 如果 有 addressId 则默认 选中此 ID
        let state = true

        if (this.addressId) {
          this.addressListArray.forEach((item, idx) => {
            if (item.addressId == this.addressId) {
              this.showMoreAddress = true
              this.selectAdress(idx)
              state = false
            }
          })
        }

        //this.handleAddressList()
      state && this.$emit('getAddresses', this.pushAddress)
      }, (data) => {

      }, () => {

        this.isLoading = true
      }, () => {

        this.isLoading = false
      })
    },
    editAddress(index) {
      this.ifEdit = true
      this.editAddressData = this.addressListArray[index] || []
      this.showEditAdd = true;
    },
    setDefaultAdd(ind) {
      let id = '';
      this.addressListArray.forEach((item, index) => {
        if (index === ind) {
          id = item.addressId
        }
      })
      InterfaceService.chengeDefaultAddress({ addressId: id }, (data) => {
        let add = null;
        this.addressListArray.forEach((item, index, arr) => {
          if (index === ind) {
            item.defaultFlg = '1'
            item.choosed = true
          } else {
            item.defaultFlg = '0'
            item.choosed = false
          }
        })
        if (this.showMoreAddress) {
          this.addressListArray.forEach((item, index, arr) => {
            if (ind === index) {
              add = item;
              arr.splice(index, 1);
              return;
            }
          })

          if (add) {
            this.addressListArray.unshift(add)
          }
          if (this.addressListArray.length > 1) {
            this.showMoreAddress = false;
          }
        }
      }, (data) => {

      }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },
    showMoreAdr() {
      this.showMoreAddress = !this.showMoreAddress
      this.$emit('shrink', '')
    },
    getAddressData(data) {
      let newAddress = {};
      newAddress = data;
      console.log(newAddress)
      this.showEditAdd = false;
      this.showMoreAddress = this.storeShowMoreAddress;
      if (!this.ifEdit) {
        InterfaceService.pushAddress(newAddress, (data) => {
          console.log(data.respData)
          newAddress.addressId = data.respData.addressId
          if (newAddress.defaultFlg == '0') {
            if (this.addressListArray.length == 0) {
              newAddress.choosed = true;
              this.pushAddress = newAddress
              this.$emit('getAddresses', this.pushAddress)
            }
            this.addressListArray.push(newAddress)
          } else {
            newAddress.choosed = true;
            this.pushAddress = newAddress
            this.$emit('getAddresses', this.pushAddress)
            this.addressListArray.forEach((item) => {
              item.choosed = false;
              item.defaultFlg = '0'
            })
            this.addressListArray.unshift(newAddress)
          }
          this.showEditAdd = false;
        }, (data) => {

        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      } else {
        InterfaceService.editReceiverAddressList(newAddress, (data) => {
          console.log(data.respData)
          let onOff = false;
          let ind = 0;
          this.addressListArray.forEach((item, index, arr) => {
            if (newAddress.addressId == item.addressId) {
              item.name = newAddress.name;
              if (newAddress.provCode != item.provCode) {
                item.provCodeDisp = newAddress.provCodeDisp;
                item.provCode = newAddress.provCode
              }
              if (newAddress.cityCode != item.cityCode) {
                item.cityCodeDisp = newAddress.cityCodeDisp;
                item.cityCode = newAddress.cityCode
              }
              if (newAddress.districtCode != item.districtCode) {
                item.districtCodeDisp = newAddress.districtCodeDisp;
                item.districtCode = newAddress.districtCode
              }
              item.addr = newAddress.addr;
              item.mobile = newAddress.mobile
              item.zipCode = newAddress.zipCode
              item.defaultFlg = newAddress.defaultFlg
              if (item.defaultFlg == '1') {
                onOff = true
                item.choosed = true
                ind = index
              }
            }
          })
          if (onOff) {
            this.addressListArray.forEach((item, index, arr) => {
              if (newAddress.addressId != item.addressId) {
                item.choosed = false;
                item.defaultFlg = '0';
              }
            })
          }
          let add = null;
          if (this.showMoreAddress && ind != 0) {
            this.addressListArray.forEach((item, index, arr) => {
              if (ind === index) {
                add = item;
                arr.splice(index, 1);
                return;
              }
            })

            if (add) {
              this.addressListArray.unshift(add)
            }
            if (this.addressListArray.length > 1) {
              this.showMoreAddress = false;
            }
          }

          this.$emit('getAddresses', this.pushAddress)
        }, (data) => {

        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      }
    }
  },
  mounted() {
    this.getAdrressList()
  }
}
</script>

<style scoped lang="scss">
.quickbuy-add-title {
  height: 50px;
  background-color: #f5f5f5;
  color: #4f525a;
  font-size: 16px;
  line-height: 50px;
  border-bottom: 2px solid #ffd64e;
  margin-bottom: 20px;
  font-weight: 700;
}
.quickbuy-add-title span {
  position: relative;
  padding: 0 26px;
  display: inline-block;
  vertical-align: top;
  font-size: 14px;
}
.quickbuy-add-title span:before {
  position: absolute;
  content: "";
  width: 100%;
  height: 2px;
  background-color: #444;
  left: 0;
  bottom: 0;
}
.quickbuy-add-title i {
  float: right;
  font-size: 14px;
  color: #1690e0;
  font-weight: normal;
  margin-right: 20px;
  cursor: pointer;
}

.quickbuy-adddress {
  margin-top: 20px;
}
.quickbuy-add {
  margin-top: 35px;
}
.quickbuy-adddress-hd {
  height: 50px;
  padding-top: 8px;
  line-height: 42px;
  font-size: 16px;
}
.quickbuy-adddress-hd-left {
  float: left;
}
.quickbuy-adddress-hd-right {
  float: right;
  color: #3388bb;
}
.quickbuy-adddress-bd {
  margin-bottom: 20px;
  cursor: pointer;
  position: relative;
}
.quickbuy-add-list {
  height: 70px;
  overflow: hidden;
}
.quickbuy-add-list.add-two {
  margin-bottom: 20px;
}
.quickbuy-add-list.show-more {
  height: auto;
}
.quickbuy-adddress-bd .quickbuy-adddress-bd-left {
  border: 1px solid #e2e2e2;
  font-size: 14px;
  background: white;
  position: relative;
}
.quickbuy-adddress-bd .quickbuy-adddress-bd-left img {
  position: absolute;
  right: 0;
  bottom: 0;
  display: none;
}
.quickbuy-adddress-bd.active .quickbuy-adddress-bd-left {
  border: 2px solid #4f525a;
}
.quickbuy-adddress-bd.active .quickbuy-adddress-bd-left img {
  display: block;
}
.quickbuy-adddress-bd-left {
  float: left;
  height: 50px;
  width: 15%;
  line-height: 50px;
  text-align: center;
  font-size: 14px;
  background: white;
}
.quickbuy-adddress-bd-right {
  float: right;
  width: 83%;
  margin-left: 10px;
  height: 50px;
  line-height: 50px;
  text-align: left;
  font-size: 14px;
  color: #444;
}
.quickbuy-adddress-bd-right span {
  margin-right: 10px;
}

.quickbuy-adddress-bd-more {
  width: 100%;
  cursor: pointer;
  font-size: 14px;
  display: inline-block;
  padding-right: 15px;
}
.quickbuy-adddress-bd-more.take-up {
}

.quickbuy-adddress-alert {
  position: absolute;
  left: 0;
  right: 0;
  bottom: -22px;
}
.quickbuy-adddress-alert::before {
  content: "";
  clear: both;
  display: block;
}

.no-quickbuy-add-list {
  text-align: center;
  line-height: 18px;
  height: 18px;
  font-size: 14px;
  color: #444444;
}
.no-quickbuy-add-list span {
  color: #1690e0;
  cursor: pointer;
}
.quickbuy-adddress-edit {
  float: right;
  color: #1690e0;
  opacity: 0;
  transition: all 0.5s;
}
.quickbuy-adddress-default {
  float: right;
  color: #888888;
  opacity: 0;
  transition: all 0.5s;
}
.quickbuy-adddress-bd:hover {
  background: #e8f3fd;
}
.quickbuy-adddress-bd:hover .quickbuy-adddress-edit {
  opacity: 1;
}
.quickbuy-adddress-bd:hover .quickbuy-adddress-default {
  opacity: 1;
}
.limit-width {
  max-width: 50%;
  display: inline-block;
  vertical-align: top;
  line-height: 50px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.info-title {
  margin-bottom: 9px;
  &:after {
    display: table;
    content: "";
    clear: both;
  }
  em {
    display: inline-block;
    margin: 6px 0 5px 10px;
  }
}
.order-info-title {
  margin: 5px 0;
  padding: 0 10px;
  font-size: 14px;
  border-left: 3px solid #000;
  line-height: 12px;
}
</style>
