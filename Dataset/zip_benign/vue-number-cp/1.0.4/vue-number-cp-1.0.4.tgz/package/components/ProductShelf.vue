<template>
  <div class="store-wrap">
    <div class="store-category">
      <div class="store-category-wrap inner-container">
        <div class="category-title">
          <div class="category-title-all"><a @click="handleAllCategory">所有分类</a>&nbsp;></div>
          <div class="category-title-name" v-if="categoryName || keywords">
            <!-- <span v-if="categoryName">{{categoryName}}</span> -->
            <span v-for="(item,index) in selectCategList" :key="index">
              <a @click="handleSelectCategory(index,item)">{{item.categoryName}}</a>&nbsp;<span v-if="index!=selectCategList.length-1">></span>&nbsp;</span>
            <div v-if="keywords" class="category-title-tag unfloat">
              <span>{{keywords}}</span>
              <i class="el-icon-close" @click="handleRemoveKeywords()"></i>
            </div>
          </div>
          <!-- 已选品牌 -->
          <div class="category-title-tag" v-if="brandSelectList.length">
            品牌:&nbsp;
            <span v-for="(brand,index) in brandSelectList" :key="index" v-if="brand.checked">{{brand.brandName}}</span>
            <i class="el-icon-close" @click="handleRemoveBrand()"></i>
          </div>
          <!-- 已选属性 -->
          <div class="category-title-tag" v-for="(attr,index) in attrSelectList" :key="index">
            {{attr.attrInfoName}}:&nbsp;
            <span v-for="(attrValue,index) in attr.attrValueInfos" :key="index" v-if="attrValue.checked">{{attrValue.attrValueName}} </span>
            <i class="el-icon-close" @click="handleRemoveAttr(index,attr)"></i>
          </div>

          <a class="category-title-tag-removeall" v-if="attrSelectList.length||brandSelectList.length" @click="handleRemoveAllAttr">清除所有</a>
          <a class="category-shrink" @click="handleCategoryShrink" v-if="brandList.length||attrList.length">
            <span v-if="!categoryFold">收起
              <i class="el-icon-arrow-up"></i>
            </span>
            <span v-if="categoryFold">展开
              <i class="el-icon-arrow-down"></i>
            </span>
          </a>
        </div>
        <!-- 店铺 -->
        <div class="key-shop-wrapper clearfloat" v-if="shopMenuFlg != '0' && shopMenuFlg" :class="{'fold':categoryFold}">
          <ul>
            <li class="active" v-for="(shop, index) in shopList" :key="index">
              <div class="show-jg" v-if="shop.showJg"></div>
              <div class="pro-store-home">
                <div class="pro-store-img">
                  <img src="../assets/images/pro_store_home.png" alt="">
                  <p style="font-size:14px;">{{shop.corpName?shop.corpName:'东方雨虹有限公司'}}</p>
                </div>
                <div class="pro-store-name">
                  <p>{{shop.corpName?shop.corpName:'东方雨虹有限公司'}}</p>
                  <el-button class="pro-store-button" @click="goStore(shop)">进入店铺</el-button>
                </div>
              </div>
            </li>

          </ul>
        </div>
        <div class="category-content" :class="{'fold':categoryFold}">
          <!-- 类目 -->
          <div class="category-bd clearfloat" v-if="categoryList.length">
            <div class="categroy-name">分类</div>
            <div class="categroy-list clearfloat" :class="{'append':categoryAttr.isExpand}">
              <ul ref="categoryUl">
                <li v-for="(category,index) in categoryList" :key="index">
                  <a @click="handleSelectCategory(index,category)">{{category.categoryName}}</a>
                </li>
              </ul>
            </div>
            <div class="category-icons f12">
              <div v-if="categoryAttr.isShowMore" class="category-more" @click="handleCategoryMore()">更多
                <i v-if="categoryAttr.isExpand" class="el-icon-arrow-up"></i>
                <i v-if="!categoryAttr.isExpand" class="el-icon-arrow-down"></i>
              </div>
            </div>
          </div>
          <!-- 品牌 -->
          <div class="category-bd clearfloat" v-if="brandList.length">
            <div class="categroy-name">品牌</div>
            <div class="categroy-list clearfloat" :class="{'append':brandAttr.isExpand}">
              <ul ref="brandUl">
                <li v-for="(brand,index) in brandList" :key="index">
                  <!-- 单选属性 -->
                  <a v-if="!brandAttr.isMulti" @click="handleSelectBrand(index,brand)">{{brand.brandName}}</a>
                  <!-- 多选属性 -->
                  <el-checkbox v-if="brandAttr.isMulti" v-model="brand.checked">{{brand.brandName}}</el-checkbox>
                </li>
              </ul>
              <div class="categroy-list-btns" v-if="brandAttr.isMulti">
                <el-button size="mini" type="primary" @click="handleSelectBrandMulti()">确定</el-button>
                <el-button size="mini" @click="handleCancelBrandMulti()">取消</el-button>
              </div>
            </div>
            <div class="category-icons f12">
              <div v-if="brandAttr.isShowMore" class="category-more" @click="handleBrandMore()">更多
                <i v-if="brandAttr.isExpand" class="el-icon-arrow-up"></i>
                <i v-if="!brandAttr.isExpand" class="el-icon-arrow-down"></i>
              </div>
              <div class="category-selects" v-if="!brandAttr.isMulti&&brandList.length>1" @click="handleBrandMulti()">多选
                <i class="el-icon-plus"></i>
              </div>
            </div>
          </div>
          <!-- 属性 -->
          <div v-for="(attr,index) in attrList" :key="index" class="category-bd clearfloat" v-if="index<4||!simpleFilter">
            <div class="categroy-name">{{attr.attrInfoName}}<span v-if="attr.unit">({{attr.unit}})</span></div>
            <div class="categroy-list clearfloat" :class="{'append':attr.isExpand}">
              <ul :id="'attr-'+ index">
                <li v-for="(attrValue,_index) in attr.attrValueInfos" :key="index+'_'+_index">
                  <!-- 单选属性 -->
                  <a v-if="!attr.isMulti" @click="handleSelectAttr(index,attr,attrValue)">{{attrValue.attrValueName}}</a>
                  <!-- 多选属性 -->
                  <el-checkbox style="font-size:12px;" v-if="attr.isMulti" v-model="attrValue.checked">{{attrValue.attrValueName}}</el-checkbox>
                </li>
              </ul>
              <div class="categroy-list-btns" v-if="attr.isMulti">
                <el-button size="mini" type="primary" @click="handleSelectAttrMulti(index,attr)">确定</el-button>
                <el-button size="mini" @click="handleCancelAttrMulti(index,attr)">取消</el-button>
              </div>
            </div>
            <div class="category-icons f12">
              <div v-if="attr.isShowMore" class="category-more" @click="handleAttrMore(index,attr)">更多
                <i v-if="attr.isExpand" class="el-icon-arrow-up"></i>
                <i v-if="!attr.isExpand" class="el-icon-arrow-down"></i>
              </div>
              <div class="category-selects" v-if="!attr.isMulti&&attr.attrValueInfos.length>1" @click="handleAttrMulti(index,attr)">多选
                <i class="el-icon-plus"></i>
              </div>
            </div>
          </div>

          <div class="category-bd clearfloat" v-if="attrList.length>4">
            <div class="categroy-name category-filter" @click="handleAttrFilter">
              <p v-if="simpleFilter">高级筛选 <i class="el-icon-arrow-down"></i></p>
              <p v-if="!simpleFilter">简单筛选 <i class="el-icon-arrow-up"></i></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="store-screen">
      <div class="store-screen-bd inner-container clearfloat">

        <div class="type-screen clearfloat">
          <ul>
            <li :class="{'active':sortObj.default}" @click="handleSort('default')">默认</li>
            <li :class="{'active':sortObj.newProduct}" @click="handleSort('newProduct')">新品
              <i class="icon-arrow" :class="{'down':!sortObj.newProduct||sortObj.newProduct=='DESC','up':sortObj.newProduct=='ASC'}"></i>
            </li>
            <li :class="{'active':sortObj.salesVolume}" @click="handleSort('salesVolume')">销量
              <i class="icon-arrow" :class="{'down':!sortObj.salesVolume||sortObj.salesVolume=='DESC','up':sortObj.salesVolume=='ASC'}"></i>
            </li>
          </ul>
        </div>
        <!-- 发货地 -->
        <!-- <el-popover placement="bottom-start" trigger="click" width="400">
                    <div class="place-screen-popper">
                        <ul>
                            <li v-for="(place,index) in placeList" :key="index">
                                <a>{{place}}</a>
                            </li>
                        </ul>
                    </div>
                    <div class="place-screen clearfloat" slot="reference">
                        发货地：
                        <input type="text" placeholder="请选择" disabled>
                    </div>
                </el-popover> -->
        <div class="prize-screen clearfloat" v-if="isLogin && role != 'S'">
          <ul>
            <li class="input-bd">
              <span>￥</span>
              <input type="number" v-input-number placeholder="请输入" v-model="params.priceFrom">
            </li>
            <li class="symbol">~</li>
            <li class="input-bd">
              <span>￥</span>
              <input type="number" v-input-number placeholder="请输入" v-model="params.priceTo">
            </li>
            <el-button style="margin-left: 20px;" type="primary" class="small-btn" @click="handleFilter">筛选</el-button>
          </ul>
        </div>
        <div v-if="groupCompanyCode == 'GREENLANDHK'">
          <div class="prize-nailsupply clearfloat" v-for="tag in showTagsForGreen" :key="tag.tagName">
            <input type="checkbox" @click="toShowTag(tag)" v-model="tag.choosed" />
            <span>显示{{tag.tagName}}</span>
          </div>
        </div>
        <div class="other-screen" v-if="total > 0">
          <ul>
            <li class="srcee-pagenations">{{params.pageIndex}}/{{total/params.pageSize|ceilNumber}}</li>
            <li class="scree-pagenation scree-pre" :class="{'disabled':params.pageIndex==1}" @click="handlePrePage">
              <i class="el-icon-arrow-left"></i>
            </li>
            <li class="scree-pagenation scree-next" :class="{'disabled':params.pageIndex== Math.ceil(total/params.pageSize)}" @click="handleNextPage">
              <i class="el-icon-arrow-right"></i>
            </li>
          </ul>
        </div>
      </div>
    </div>
    <div class="store-products">
      <div class="inner-container clearfloat" style="margin-top: 24px;">
        <div class="store-product" v-for="(product, index) in products" :key="index" @click="goProduct(product.spuId,product.skuId,product.corpId,index)" :class="{'no-margin':(index+1) % 5 === 0}">
          <div class="store-product-pic">
            <!-- <div class="pic-box-inner"><img :src="product.attachInfos[0].attachUrl"></div> -->
            <div class="pic-box-inner"><img :src="product.attachInfo&&product.attachInfo.url" v-error-img></div>
          </div>
          <div class="store-product-ctx">
            <div class="store-product-ctx-row-1">
              <div class="g-price">
                <span v-if="isLogin" class="f14">¥</span>
                <template v-if="isLogin&&product.priceModel != 'floatingPrice'">
                  <strong v-if="product.price" class="f18">{{product.price | formatMoney}}</strong>
                  <strong v-if="!product.price" class="f18">暂无报价</strong>
                </template>
                <template v-if="isLogin&&product.priceModel == 'floatingPrice'">
                  <!-- <strong style="font-size: 27px">{{product.priceTarget}}</strong> -->
                  <!--<strong style="font-size: 27px">浮动</strong>-->
                  <strong v-if="role == 'B' || product.corpId == userinfo.corpId" style="font-size: 27px">浮动</strong>
                  <strong v-if="role == 'S' && product.corpId != userinfo.corpId" style="font-size: 27px">暂无报价</strong>
                </template>

                <span v-if="!isLogin" class="f18">登录可见</span>
              </div>
              <!-- <div class="deal-cnt">销量：{{product.salesVolume || 0}}</div> -->
            </div>
            <div class="store-product-ctx-row-2 f14">
              <span :ref="'spuName'+index" class="spu-name fl" :title="`${product.spuName} ${product.spuName && product.spuName.includes(product.model)?'':product.model}`">{{product.spuName}}<template v-if="!(product.spuName && product.spuName.includes(product.model))">&nbsp;{{product.model}}</template></span>
              <div class="fr spu-tags">
                <span class="nailsupply" v-for="tag in product.skuTags" :key="tag.tagId">
                  <el-popover popper-class="dark-popover" trigger="hover" placement="right-end">
                    <div style="color: #fff">
                      {{tag.remark}}
                    </div>
                    <span slot="reference">{{tag.tagName}}</span>
                  </el-popover>
                </span>
              </div>
            </div>
            <div class="store-product-ctx-row-3 f12" @click.stop @click="goStore(product)">
              <i>{{product.corpName}}</i>
            </div>
            <div class="tag-conatainer">
              <span v-for="tag in product.tags && product.tags.slice(0,2)" :key="tag.tagId">{{tag.tagName}}</span>
              <span v-if="product.tags && product.tags.length > 2">
                <el-dropdown size="mini" placement="bottom-start">
                  <a style="color: #ffa300" class="el-dropdown-link">
                    ......
                  </a>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item v-for="tag in product.tags.slice(2)" :key="tag.tagId">{{tag.tagName}}</el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>
              </span>
            </div>
          </div>
        </div>

      </div>
      <div class="inner-container clearfloat">
        <!-- 无商品 -->
        <div class="product-empty" v-if="!isLoading&&!products.length">
          <!-- <img src="@/assets/images/icon-no-product.png"> -->
          <p><span><img src="@/assets/images/icon-no-product.png"></span>没找到相关的商品，请修改查询条件，重新筛选！
            <!-- <br>为您推荐如下商品。 -->
          </p>
          <!-- <p>没找到相关的商品，请修改搜索关键词，重新搜索！<br>为您推荐如下商品。</p> -->
        </div>
        <!-- 分页 -->
        <div class="table-pagination" v-if="products.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="params.pageIndex" :page-size="params.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
        <!-- 商品推荐 -->
        <div class="recommend-product" v-if="recommendList.length">
          <p class="title">为您推荐</p>
          <div class="recommend-content clearfloat" >
            <div class="store-product" v-for="(product, index) in recommendList" :key="index" @click="goProduct(product.spuId,product.skuId,product.corpId,index)" :class="{'no-margin':(index+1) % 5 === 0}">
              <div class="store-product-pic">
                <div class="pic-box-inner" v-if="product.attachInfo"><img :src="product.attachInfo.url"></div>
              </div>
              <div class="store-product-ctx">
                <div class="store-product-ctx-row-1">
                  <div class="g-price">
                    <span v-if="isLogin" class="f14">¥</span>
                    <strong v-if="isLogin" class="f18">{{product.price | formatMoney}}</strong>
                    <span v-if="!isLogin" class="f18">登录可见</span>
                  </div>
                  <div class="deal-cnt">销量：{{product.salesVolume || 0}}</div>
                </div>
                <div class="store-product-ctx-row-2 f14">{{product.spuName}}</div>
                <div class="store-product-ctx-row-3 f12" @click.stop @click="goStore(product)">{{product.corpName}}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import SearchBar from "@/components/SearchBar";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import { setTimeout } from 'timers';

// 参数
const params = {
  categoryIds: "",
  corpId: "",
  attrs: [],
  brandIds: "",
  priceFrom: "",
  priceTo: "",
  sort: [],
  pageIndex: 1,
  pageSize: 12,
  keyword: '',
  tags: ''
};

export default {
  mixins: [accountMixin],
  props: {
    store: {
      type: Boolean,
      default: false
    },
    supplierId: {
      type: String,
      default: ""
    }
  },
  components: {
    SearchBar,
    Loading
  },
  data() {
    return {
      isLogin: false,
      categoryFold: false,
      params: Object.assign({}, params),
      products: [],
      selectCategList: [],
      categoryList: [],
      categoryAttr: {},
      shopList: [],
      shopMenuFlg: '',
      wechartQrCode: '',
      brandList: [],
      cloneBrandList: [], // 记录第一次返回品牌
      brandAttr: {},
      attrList: [],
      placeList: ["北京", "上海", "天津", "重庆"],
      brandSelectList: [],
      attrSelectList: [],
      sortObj: {
        default: true,
        newProduct: "",
        salesVolume: ""
      },
      total: 0,
      recommendList: [],
      searchBarType: 4,
      isLoading: false,
      categoryId: '',
      categoryName: '',
      corpId: '',
      keywords: '',
      simpleFilter: true,
      storeAttr: {},
      fromHomeProductBrand: false,
      fromHomeProductAttr: false,
      showTagsForGreen: [],
      recordTag: []
    };
  },
  watch: {
    '$route'(to, form) {
      this.init();
    }
  },
  methods: {
    // 所有类目
    handleAllCategory() {
      if (this.store) {
        this.init("clearKeywords");
      } else {
        this.$router.push({ path: '/ProductList' });
        window.location.reload();
      }
    },
    // 类目分类更多
    handleCategoryMore() {
      this.$set(this.categoryAttr, "isExpand", !this.categoryAttr.isExpand);
    },
    // 品牌分类更多
    handleBrandMore() {
      this.$set(this.brandAttr, "isExpand", !this.brandAttr.isExpand);
      this.$set(this.brandAttr, "isMulti", false);
    },
    // 属性分类更多
    handleAttrMore(index, attr) {
      attr.isExpand = !attr.isExpand;
      attr.isMulti = false;
      this.$set(this.attrList, index, attr);
    },
    // 品牌分类多选
    handleBrandMulti() {
      this.$set(this.brandAttr, "isExpand", true);
      this.$set(this.brandAttr, "isMulti", true);
    },
    // 属性分类多选
    handleAttrMulti(index, attr) {
      attr.isExpand = true;
      attr.isMulti = true;
      this.$set(this.attrList, index, attr);
    },
    // 类目选择
    handleSelectCategory(index, category) {
      this.$router.push({
        path: '/productList',
        query: {
          categoryId: category.categoryId,
          categoryName: category.categoryName,
          keywords: this.keywords
        }
      });
      // this.params.pageIndex = 1;

      // this.categoryId = category.categoryId
      // this.categoryName = category.categoryName
      // this.storeAttr.attrInfos = []
      // this.getCategory()
      // this.getProductList(true);

      console.log(index, category);

      //   this.$router.push({
      //     path: "/transfer",
      //     query: {
      //       query: JSON.stringify({ 'keywords': this.keywords, 'categoryName': category.categoryName || "", 'categoryId': category.categoryId, }),
      //       path: '/productList'
      //     }
      //   });
    },
    // 品牌分类多选选择
    handleSelectBrandMulti() {
      this.$set(this.brandAttr, "isExpand", false);
      this.$set(this.brandAttr, "isMulti", false);
      this.brandList.forEach(item => {
        if (item.checked) {
          this.brandSelectList.push(item);
        }
      });

      this.getProductList(true);
    },
    // 属性分类多选选择
    handleSelectAttrMulti(index, attr) {
      attr.isExpand = false;
      attr.isMulti = false;
      this.attrSelectList.push(attr);
      this.getProductList(true);
    },
    // 品牌分类多选取消
    handleCancelBrandMulti() {
      this.$set(this.brandAttr, "isExpand", false);
      this.$set(this.brandAttr, "isMulti", false);
    },
    // 属性分类多选取消
    handleCancelAttrMulti(index, attr) {
      attr.isExpand = false;
      attr.isMulti = false;
      this.$set(this.attrList, index, attr);
    },
    // 品牌单选选择
    handleSelectBrand(index, brand) {
      console.log(index, brand, '-index, brand');

      brand.checked = true;
      this.$set(this.brandList, index, brand);
      this.brandList.forEach(item => {
        if (item.checked) {
          this.brandSelectList.push(item);
        }
      });
      this.getProductList(true);
    },
    // 属性单选选择
    handleSelectAttr(index, attr, attrValue) {
      attrValue.checked = true;
      this.attrSelectList.push(attr);
      this.getProductList(true);
    },
    handleRemoveCategory() {
      this.categoryId = ''
      this.categoryName = ''
      this.getProductList(true);
    },
    // 品牌分类移除
    handleRemoveBrand() {
      this.brandSelectList = [];
      this.getProductList(true);
    },
    // 清除关键字
    handleRemoveKeywords() {
      this.keywords = '';
      let url = window.location.href;  //获取当前页面的url
      console.log(url, '--', url.indexOf('keywords') != -1 && url.indexOf("?") != -1);

      // 清除了 keywords 后 浏览器 地址 移除
      if (url.indexOf('keywords') != -1 && url.indexOf("?") != -1) { //判断是否存在参数
        url = url.replace(/keywords=.*&c/, 'keywords=&c');  //去除参数
        window.history.pushState({}, 0, url);
      }
      this.getProductList(true);
    },
    // 属性分类移除
    handleRemoveAttr(index) {
      this.attrSelectList.splice(index, 1);
      this.getProductList(true);
    },
    // 分类移除所有
    handleRemoveAllAttr() {
      this.brandSelectList = [];
      this.attrSelectList = [];
      this.$route.query.brandIds = "";
      // this.categoryId = this.$route.query.categoryId || "";
      // 查询列表
      this.getProductList(true);
    },
    // 收起、展开分类
    handleCategoryShrink(bool) {
      this.categoryFold = !this.categoryFold;
    },
    // 排序
    handleSort(type) {
      let sort = {
        default: false,
        newProduct: "",
        salesVolume: ""
      };
      if (type == "default") {
        sort.default = true;
      } else if (type == "newProduct") {
        if (
          !this.sortObj.newProduct ||
          this.sortObj.newProduct == "ASC"
        ) {
          sort.newProduct = "DESC";
        } else {
          sort.newProduct = "ASC";
        }
      } else if (type == "salesVolume") {
        if (
          !this.sortObj.salesVolume ||
          this.sortObj.salesVolume == "ASC"
        ) {
          sort.salesVolume = "DESC";
        } else {
          sort.salesVolume = "ASC";
        }
      }
      this.sortObj = sort;

      this.getProductList(true);
    },
    // 高级筛选、简单筛选
    handleAttrFilter() {
      this.simpleFilter = !this.simpleFilter;
      setTimeout(() => {
        this.attrList.map((item, index) => {
          // item.isShowMore = false;
          this.showMore(index);
        });
      }, 0);
    },
    // 筛选
    handleFilter() {
      this.getProductList(true);
    },
    // 上一页
    handlePrePage() {
      if (this.params.pageIndex > 1) {
        this.params.pageIndex--;
        this.getProductList();
      }
    },
    // 下一页
    handleNextPage() {
      if (
        this.params.pageIndex <
        Math.ceil(this.total / this.params.pageSize)
      ) {
        this.params.pageIndex++;
        this.getProductList();
      }
    },
    // 分页跳转
    handleCurrentChange(index) {
      index = +index;
      this.params.pageIndex = index;
      this.getProductList();
      window.scrollTo(0, 0)
    },
    //勾选显示相应标签商品
    toShowTag(item) {
      setTimeout(() => {
        if (item.choosed) {
          this.recordTag.push(item.tagId)
        } else {
          this.recordTag.forEach((val, ind) => {
            if (val == item.tagId) {
              this.recordTag.splice(ind, 1)
            }
          })
        }
        this.getProductList(true)
      }, 0)
    },
    // 获取商品列表
    getProductList(init) {
      console.log(this.brandSelectList, '-brandSelectList');

      this.$setRootScope('productBrandSelectList', JSON.stringify(this.brandSelectList || []))
      if (init) {
        this.params.pageIndex = 1;
      }
      const param = Object.assign({}, this.params);
      let arrTags = []
      //单一标签
      //const param = this.params.tags ?  Object.assign({},this.params,{tags:['jg']}) :Object.assign({},this.params,{tags:null});
      this.showTagsForGreen.forEach((item) => {
        if (item.choosed) {
          if (!arrTags.find(val => val == (item.tagId + ':' + item.tagName))) {
            arrTags.push(item.tagId + ':' + item.tagName)
          }
        } else {
          if (arrTags.find(val => val == (item.tagId + ':' + item.tagName))) {
            arrTags.splice(arrTags.findIndex(val => val == (item.tagId + ':' + item.tagName)), 1)
          }
        }
      })
      if (arrTags.length == 1) {
        param.tags = arrTags[0]
      } else if (arrTags.length == 0) {
        param.tags = ''
      } else {
        param.tags = arrTags.join(',')
      }
      // 排序
      param.sort = [];
      for (let i in this.sortObj) {
        if (this.sortObj[i]) {
          if (!this.sortObj.default) {
            param.sort.push({
              sortKey: i,
              sort: this.sortObj[i]
            });
            break;
          }
        }
      }

      // 品牌
      const brandIds = [];
      // if (this.fromHomeProductBrand) {
      //     param.brandIds = this.$route.query.brandIds
      // }else {
      //     this.brandSelectList.forEach(item => {
      //         brandIds.push(item.brandId);
      //     });
      //     param.brandIds = brandIds.join("_");
      // }
      this.brandSelectList.forEach(item => {
        brandIds.push(item.brandId);
      });
      param.brandIds = brandIds.join("_");
      // 属性
      const attrs = [];
      this.attrSelectList.forEach(item => {
        item.attrValueInfos.forEach(_item => {
          if (_item.checked) {
            attrs.push({
              attrInfoId: item.attrInfoId,
              attrValueId: _item.attrValueId
            });
          }
        });
      });
      param.attrs = attrs;

      //console.log(param);
      param.categoryIds = this.categoryId
      param.corpId = this.corpId
      param.keyword = this.keywords
      console.log(param);
      console.log(this.products)
      InterfaceService.getProductList(
        param,
        data => {
          //console.log(data.respData);
          if (data.respCode === "0000") {
            // console.log(data.respData.spuInfos)
            this.isLogin = +data.respData.registFlg;
            this.products = data.respData.spuInfos || [];
            // this.products.forEach(item => {
            //     item.spuTags = [{
            //             tagId:"CONRUCTOR",
            //             tagName:"ES",
            //         }
            //         ,{
            //         tagId:"CONUCTOR",
            //         tagName:"HK",
            //     },{
            //             tagId:"CONU1CTOR",
            //             tagName:"HK",
            //         },{
            //             tagId:"CONU1C2TOR",
            //             tagName:"HK",
            //         },{
            //             tagId:"CONU1C33TOR",
            //             tagName:"HK",
            //         }
            //     ];
            // });
            // 根据商品标签判断商品名称的长度
            setTimeout(() => {
              this.products.forEach((item, index) => {
                let len = item.spuTags && item.spuTags.length || 0
                if (len === 0) {
                  this.$refs['spuName' + index][0].style.width = 100 + "%";
                } else if (len === 1) {
                  this.$refs['spuName' + index][0].style.width = 220 + "px"
                } else if (len === 2) {
                  this.$refs['spuName' + index][0].style.width = 185 + "px"
                }
              });
            }, 200);
            this.showTagsForGreen = data.respData.tags || [];
            this.showTagsForGreen.forEach((item) => {
              if (this.recordTag.length == 0) {
                item.choosed = false;
              } else {
                let onOff = false;
                this.recordTag.forEach((val) => {
                  if (val == item.tagId) {
                    onOff = true;
                  }
                })
                if (onOff) {
                  item.choosed = true
                } else {
                  item.choosed = false
                }
              }
            })
            this.shopMenuFlg = data.respData.shopMenuFlg || '';
            this.total = data.respData.totoalCount;
            this.params.pageSize = data.respData.pageSize || 12;

            // 记录属性
            this.storeAttr.brandInfos = data.respData.brandInfos || this.storeAttr.brandInfos;
            this.storeAttr.attrInfos = data.respData.attrInfos || this.storeAttr.attrInfos;
            this.storeAttr.shopList = data.respData.shopList || this.storeAttr.shopList;
            this.storeAttr.categoryInfos = data.respData.categoryInfos || this.storeAttr.categoryInfos;

            const itemBrandList = data.respData.brandInfos || this.storeAttr.brandInfos || [],
              // 是否在第一页
              isFirstPageIndex = Number(this.params.pageIndex) === 1;

            // 当分页在第一页时 克隆品牌数据
            this.cloneBrandList = isFirstPageIndex ? JSON.parse(JSON.stringify(data.respData.brandInfos)) : this.cloneBrandList;
            // 当分页不是在第一页后 使用克隆品牌数据
            this.brandList = isFirstPageIndex ? itemBrandList : this.cloneBrandList;

            this.attrList = data.respData.attrInfos || this.storeAttr.attrInfos || [];
            this.shopList = data.respData.shopList || this.storeAttr.shopList || [];
            this.shopList.forEach((item) => {
              if (item.tags && item.tags.length != 0) {
                item.tags.forEach((val) => {
                  if (val.tagName == '甲供') {
                    item.showJg = true;
                  }
                })
              }
            })
            this.categoryList = data.respData.categoryInfos || this.storeAttr.categoryInfos || [];
            if (this.shopList.length > 0) {
              this.wechartQrCode = this.shopList[0].wechartQrCode
            }
            if (this.fromHomeProductBrand) {    //首页热门大宗---品牌
              this.fromHomeProductBrand = false;
              this.brandList.forEach((item, index) => {
                console.log(item.brandId);
                if (this.$route.query.brandIds == item.brandId) {
                  this.handleSelectBrand(index, item)
                }
              });
              if (this.$route.query.brandIds && this.$route.query.brandIds.indexOf(",") != -1) {
                let brandIds = this.$route.query.brandIds.split(",")
                brandIds.forEach(item => {
                  this.brandList.forEach((_item, index) => {
                    if (item == _item.brandId) {
                      _item.checked = true;
                    }
                  })
                });
                this.handleSelectBrandMulti();
              }
            }
            if (this.fromHomeProductAttr) {    //首页热门大宗---属性
              this.fromHomeProductAttr = false;
              if (this.$route.query.attrs && this.$route.query.attrs.length == 1) {
                this.attrList.forEach((item, index, attr) => {
                  if (this.$route.query.attrs[0].attrInfoId == item.attrInfoId) {
                    item.attrValueInfos.forEach((_item, _index) => {
                      if (this.$route.query.attrs[0].attrValueId == _item.attrValueId) {
                        this.handleSelectAttr(index, item, _item)
                      }
                    })
                  }
                });
              } else if (this.$route.query.attrs.length >= 1) {
                this.attrList.forEach((item, index) => {
                  this.$route.query.attrs.forEach(_item => {
                    if (_item.attrInfoId == item.attrInfoId) {
                      item.attrValueInfos.forEach((attr, ind) => {
                        this.$route.query.attrs.forEach((_attr, _ind) => {
                          if (_attr.attrValueId == attr.attrValueId) {
                            attr.checked = true
                          }
                        });
                      })
                    }
                  })
                  this.handleSelectAttrMulti(index, item)
                });
              }

              if (this.$route.query.brandIds && this.$route.query.brandIds.indexOf(",") != -1) {
                let brandIds = this.$route.query.brandIds.split(",")
                brandIds.forEach(item => {
                  this.brandList.forEach((_item, index) => {
                    if (item == _item.brandId) {
                      _item.checked = true;
                    }
                  })
                });
              }
            }
            setTimeout(() => {
              this.attrList.map((item, index) => {
                item.isShowMore = false;
                this.showMore(index);
              });
              if (this.$refs.brandUl) {
                if (this.$refs.brandUl.offsetHeight < 38) {
                  this.brandAttr.isShowMore = false;
                  this.$set(this.brandAttr, 'isShowMore', false);
                } else {
                  this.brandAttr.isShowMore = true;
                  this.$set(this.brandAttr, 'isShowMore', true);
                }
              }

              if (this.$refs.categoryUl) {
                if (this.$refs.categoryUl.offsetHeight < 38) {
                  this.$set(this.categoryAttr, 'isShowMore', false);
                } else {
                  this.$set(this.categoryAttr, 'isShowMore', true);
                }
              }
            }, 100);
            let resData = data.respData.shopList[0] || {};
            resData.isLogin = this.isLogin;
            if (this.store) {
              this.$emit('receive', resData);
            }
            // this.fromHomeProductBrand = false
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    goProduct(spuId, skuId, corpId, index) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: spuId,
          skuId: skuId,
          corpId: corpId,
          from: 'shelf',
        }
      }).href, '_blank')
    },
    goStore(shop) {

      let store = {
        corpId: shop.corpId
      };
      this.$router.push({
        path: "/store",
        query: store
      });
    },
    arrangementList(res) {
      this.selectCategList = [];
      let loop = false;
      const list = res;
      list.map(item1 => {
        if (!loop && item1.categoryId == this.categoryId) {
          loop = true;
          this.selectCategList.push({
            categoryId: item1.categoryId,
            categoryName: item1.categoryName
          });
        } else {
          item1.children.map(item2 => {
            if (!loop && item2.categoryId == this.categoryId) {
              loop = true;
              this.selectCategList.push({
                categoryId: item1.categoryId,
                categoryName: item1.categoryName
              });
              this.selectCategList.push({
                categoryId: item2.categoryId,
                categoryName: item2.categoryName
              });
            } else {
              item2.children.map(item3 => {
                if (!loop && item3.categoryId == this.categoryId) {
                  loop = true;
                  this.selectCategList.push({
                    categoryId: item1.categoryId,
                    categoryName: item1.categoryName
                  });
                  this.selectCategList.push({
                    categoryId: item2.categoryId,
                    categoryName: item2.categoryName
                  });
                  this.selectCategList.push({
                    categoryId: item3.categoryId,
                    categoryName: item3.categoryName
                  });
                }
              });
            }
          });
        }
      });
    },
    // 获取类目列表
    getCategory() {
      let categoryList = this.$getRootScope('categoryList')
      if (categoryList) {
        this.categoryList = JSON.parse(categoryList)
        this.arrangementList(this.categoryList)
      } else {
        InterfaceService.getCategoryList(
          {
            categoryId: "1",
            queryType: "2",
          },
          data => {
            //console.log(data);
            if (data.respData.respCode === "0000") {
              let res = data.respData.categoryInfos || []
              this.$store.commit('changeCategoryList', res)
              this.$setRootScope('categoryList', JSON.stringify(res))
              this.categoryList = res
              this.arrangementList(this.categoryList)
            } else {
              this.$message.error(data.respData.respMsg);
            }
          },
          data => { },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      }
    },
    showMore(index) {
      const ele = document.getElementById('attr-' + index);
      if (ele) {
        let lineHeight = ele.offsetHeight;
        if (lineHeight <= 36) {
          this.attrList[index].isShowMore = false;
        } else {
          this.attrList[index].isShowMore = true;
        }
        this.$set(this.attrList, index, this.attrList[index]);
      }
    },
    init(clearKeywordes) {
      this.keywords = clearKeywordes ? "" : this.$route.query.keywords || "";
      this.categoryId = this.$route.query.categoryId || "";
      this.categoryName = this.$route.query.categoryName || "";
      this.corpId = this.$route.query.corpId || ""
      // this.brandIds = this.$route.query.brandIds || ""
      if (this.$route.query.isSessionBrandSelectList) {
        this.brandSelectList = JSON.parse(this.$getRootScope('productBrandSelectList') || '[]')
      }
      if (this.$route.query.brandIds) {
        this.fromHomeProductBrand = true
      }
      if (this.$route.query.attrs) {
        console.log(this.$route.query.attrs);
        this.fromHomeProductAttr = true
      }
      this.priceFrom = this.$route.query.priceFrom || "";
      this.priceTo = this.$route.query.priceTo || ""

      if (this.keywords ||
        this.categoryId ||
        this.categoryName ||
        this.corpId ||
        this.priceFrom ||
        this.priceTo
      ) {
        this.params.priceFrom = this.priceFrom
        this.params.priceTo = this.priceTo
        this.getProductList();
      }
      if (this.categoryId) {
        this.getCategory();
      }
    }
  },
  mounted() {
    this.init();
  },
};
</script>

<style lang="scss" scoped>
.store-products {
  min-height: 475px;
}
.store-category {
  border-top: 1px solid #f3c300;
}
.store-category-wrap {
  border-bottom: 1px solid #ddd;
  // width: 1200px
}
.category-title {
  position: relative;
  min-height: 76px;
  display: flex;
  align-items: center;
  padding: 30px 80px 14px 15px;
  // border-bottom: 1px solid #ddd;
  // padding-right: 80px;
  // line-height: 56px;
  line-height: 25px;
  font-weight: bold;
  font-size: 15px;
  &:after {
    display: table;
    content: "";
    clear: both;
  }

  .category-title-name {
    &.unfloat {
      float: initial;
    }
    float: left;
    position: relative;
    display: inline-block;
    /*max-width: 250px;*/
    padding: 2px 4px;
    vertical-align: middle;
    line-height: 22px;
    white-space: nowrap;

    /*overflow: hidden;*/
    /*text-overflow: ellipsis;*/
    color: #333;

    a:hover {
      color: #c99f4f;
    }
  }
  .category-title-tag {
    &.unfloat {
      float: initial;
    }
    float: left;
    position: relative;
    display: inline-block;
    max-width: 250px;
    margin: 0 10px 5px;
    padding: 0 30px 0 15px;
    vertical-align: middle;
    line-height: 22px;
    white-space: nowrap;
    border: 1px solid #bbb;
    overflow: hidden;
    text-overflow: ellipsis;
    color: #888;
    font-size: 12px;
    font-weight: 500;

    i {
      position: absolute;
      right: 10px;
      top: 5px;
      cursor: pointer;
    }

    &:hover {
      border-color: #c99f4f;
      color: #444;
      i {
        // color: #c99f4f;
        color: #444444;
      }
    }
    & > span:after {
      margin-right: 2px;
      content: ",";
    }
    & > span:nth-last-child(2):after {
      content: "";
    }
  }

  .category-title-tag-removeall {
    display: inline-block;
    white-space: nowrap;
    padding: 0px 10px;
    border-left: 2px solid #ddd;
    color: #888888;
    font-weight: 500;

    &:hover {
      color: #0082ff;
    }
  }
}
.category-title-all {
  float: left;
  a:hover {
    color: #c99f4f;
  }
}
.category-shrink {
  position: absolute;
  top: 0;
  right: 0;
  width: 55px;
  padding: 16px 0;
  padding-top: 30px;
  font-weight: 500;
  line-height: 22px;
}

.category-content {
  position: relative;
}

.category-content.fold {
  height: 0;
  overflow: hidden;
}

.category-filter:hover {
  cursor: pointer;
  color: #c99f4f;
}
.category-bd {
  position: relative;
  border-top: 1px solid #ddd;
  overflow: hidden;
}
.categroy-name {
  width: 125px;
  float: left;
  font-size: 14px;
  background-color: #f5f5f5;
  text-align: center;
  line-height: 36px;
  height: 100%;
  overflow: hidden;
  padding-bottom: 9999px;
  margin-bottom: -9999px;
}
.categroy-list {
  /* width: 100%; */
  background-color: #fff;
  margin-left: 125px;
  /* height: auto; */
  height: 37px;
  overflow: hidden;

  /deep/ .el-checkbox__label {
    font-size: 12px;
  }

  &.append {
    height: auto;
    overflow: auto;
  }
  ul {
    width: 80%;

    &:after {
      display: table;
      content: "";
      clear: both;
    }
  }
  li {
    float: left;
    padding: 0 20px;
    margin-right: 20px;
    height: 36px;
    line-height: 36px;
    &:hover,
    &.active {
      color: #c99f4f;
    }
  }
}

.categroy-list-btns {
  margin-left: -125px;
  padding: 20px 0 10px;
  text-align: center;
}
.category-icons {
  position: absolute;
  height: 22px;
  top: 7px;
  right: 0;
  overflow: hidden;
  color: #444;
  text-align: center;
}
.category-more,
.category-selects {
  float: left;
  width: 55px;
  height: 22px;
  line-height: 20px;
  border: 1px solid #888888;
  cursor: pointer;
  &:hover {
    border-color: #c99f4f;
  }
}
.category-selects {
  margin-left: 20px;
}
.store-screen {
  padding-top: 12px;
}
.store-screen-bd {
  background-color: #f5f5f5;
  padding: 10px;
}
.type-screen {
  float: left;
  // border-right: 1px solid #ddd;
  margin-right: 28px;
}
.place-screen {
  float: left;
  height: 34px;
  margin-right: 20px;
  padding: 5px;
  line-height: 25px;
  background: #fff;
  &:hover {
    outline: 1px solid #c99f4f;
  }
  input {
    background: #ffffff;
  }
}
.place-screen-popper {
  padding: 5px 0;
  &:after {
    display: table;
    content: "";
    clear: both;
  }
  ul li {
    float: left;
    padding: 5px;
    a:hover {
      color: #c99f4f;
    }
  }
}
.prize-screen {
  float: left;
}
.prize-nailsupply {
  float: left;
  height: 30px;
  line-height: 30px;
  padding-left: 10px;

  input {
    width: 16px;
    height: 16px;
    margin: 0;
    vertical-align: middle;
    -webkit-appearance: checkbox;
    background: none;
  }

  span {
    vertical-align: middle;
  }
}
.other-screen {
  float: right;
}
.type-screen li {
  float: left;
  height: 26px;
  width: 65px;
  background-color: #fff;
  color: #888;
  line-height: 17px;
  padding: 5px;
  border-right: 0;
  text-align: center;
  cursor: pointer;
  &.active {
    background: linear-gradient(
      120deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    color: #fff;
  }
}
.prize-screen li {
  float: left;
  background-color: #fff;
  color: #888;
  height: 26px;
  line-height: 26px;
}
.prize-screen li.input-bd {
  // border: 1px solid #ddd;
  padding-left: 5px;
  input {
    padding-left: 5px;
  }
}
.prize-screen li input {
  border: none;
  outline: 0;
  background: #fff;
  width: 62px;
  height: 24px;
  line-height: 24px;
}
.prize-screen li.do-screen {
  margin-left: 14px;
  background: linear-gradient(
    120deg,
    rgba(215, 176, 100, 1) 0%,
    rgba(236, 206, 139, 1) 100%
  );
  height: 30px;
  line-height: 30px;
  font-size: 14px;
  color: #444;
  padding: 0 14px;
  cursor: pointer;
}
.prize-screen li.do-screen:active {
  background-color: #c99f4f;
}
.prize-screen li.symbol {
  padding: 0 4px;
  background: #f5f5f5;
}
.other-screen li {
  float: left;
  height: 26px;
  line-height: 26px;
  color: #888;
  cursor: pointer;
}
.scree-pagenation {
  width: 26px;
  height: 26px;
  line-height: 26px;
  text-align: center;
  color: #ddd;
  background-color: #fff;
  margin-left: 7px;
  border: 1px solid #ddd;
  &:hover {
    background: linear-gradient(
      120deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
  }
  &:active {
    background-color: #c99f4f;
  }
  &.disabled {
    cursor: not-allowed;
    background-color: #ddd;
  }
}
.store-product {
  float: left;
  // border: 1px solid #ddd;
  width: 232px;
  height: 336px;
  margin-top: 6px;
  margin-right: 7px;
  cursor: pointer;
  &:hover {
    box-shadow: 0 0 8px rgba(158, 156, 156, 0.3);
  }
}
.store-product-pic {
  width: 224px;
  height: 224px;
  background: #ffffff;
  border: 1px solid #dddddd;
  margin: 4px auto 0;
}
.pic-box-inner {
  width: 100%;
  height: 100%;
  overflow: hidden;
  img {
    width: 100%;
    height: 100%;
  }
}
.store-product-ctx-row-1 {
  padding: 0 4px;
  margin-top: 6px;
  height: 25px;
  line-height: 25px;
  overflow: hidden;
}
.store-product-ctx-row-2 {
  padding: 0 4px;
  margin-top: 10px;
  height: 20px;
  line-height: 20px;
  font-weight: bold;
  color: #000;
  .spu-name {
    display: inline-block;
    width: 185px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: 14px;
  }
  .spu-tags {
    display: inline-block;
    width: 75px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
}
.store-product-ctx-row-3 {
  padding: 0 4px;
  height: 17px;
  line-height: 17px;
  margin-top: 10px;
  overflow: hidden;
  color: #888;

  i {
    text-decoration: underline;
  }
}
.tag-conatainer {
  padding: 0 12px 0 0;
  height: 18px;
  span {
    color: #ffab20;
    display: inline-block;
    height: 16px;
    line-height: 16px;
    padding: 0 6px 2px;
    text-align: center;
    border: 1px solid #ffab20;
    border-radius: 7px;
    font-size: 12px;
    margin-left: 6px;
  }
}

.store-product-ctx-row-3:hover {
  color: #0082ff;
}

.g-price {
  // float: left;
  // font-size: 28px;
  height: 25px;
  color: #ef3434;
  font-weight: bold;
}
.deal-cnt {
  float: right;
  font-size: 16px;
  color: #888;
}
.store-product.no-margin {
  margin-right: 0;
}

.table-pagination {
  margin: 50px 0 80px;
  text-align: center;
  color: #888888;

  &:before {
    display: table;
    content: "";
    clear: both;
  }
}

.product-empty {
  padding: 100px 150px;
  font-size: 14px;

  img {
    margin-right: 20px;
    vertical-align: middle;
  }
  p {
    // background-image: url(../assets/images/icon-no-product.png);
    // background-repeat: no-repeat;
    text-align: center;
    width: 100%;
    display: inline-block;
    vertical-align: middle;
    line-height: 60px;
    // background-position-y: 6px;
  }
}

.recommend-product {
  .title {
    margin-bottom: 10px;
    padding: 0 5px;
    border-left: 3px solid #444;
    font-size: 14px;
  }

  .recommend-content {
    margin-top: 24px;
    border-top: 1px solid #ddd;
    margin-bottom: 100px;
  }
}

.key-shop-wrapper {
  margin-top: 10px;
  margin-bottom: 10px;
  border-top: 1px solid #ddd;

  &.fold {
    margin-top: 0px;
    margin-bottom: 0px;
    height: 0;
    overflow: hidden;
  }
  li {
    width: 190px;
    // display: inline-flex;
    float: left;
    margin-top: 10px;
    margin-right: 10px;
    text-align: center;
    // background: url(../assets/images/pro_store_bg.png) repeat-x;
    background-color: #f6f8fd;
    height: 80px;
    position: relative;

    .show-jg {
      background: url(../assets/images/icon/default-jg.png) no-repeat;
      width: 100%;
      height: 80px;
      position: absolute;
      top: 0;
      left: 0;
    }

    .pro-store-home {
      padding-top: 15px;
      height: 80px;
      width: 100%;
      position: relative;
    }

    .pro-store-img {
      // width: 20px;
      // height:34px;
      // margin: 0 auto;
      img {
        width: 20px;
        // height:34px;
        display: block;
        margin: 0 auto 0;
        height: auto;
      }

      p {
        padding-top: 10px;
        width: 100%;
        line-height: 1.2;
      }
    }
    .pro-store-name {
      display: none;
      font-size: 14px;
      color: #444;
      margin: 0 auto;
      //padding-top: 10px;

      .pro-store-button {
        display: none;
      }
    }

    .pro-store-text {
      padding-left: 20px;
      color: #444;
      font-size: 14px;
      line-height: 1;
      margin-top: 10px;
    }

    .el-button {
      display: inline-block;
      background: rgba(0, 0, 0, 0);
      color: #fff;
      border: 1px solid #fff;
      padding: 6px 10px;
      font-size: 12px;
      position: absolute;
      bottom: 10px;
      left: 50%;
      transform: translate(-50%, 0);
      -webkit-transform: translate(-50%, 0);
      -o-transform: translate(-50%, 0);
      -moz-transform: translate(-50%, 0);
    }

    &:hover {
      background: url(../assets/images/productFile/product-list.png) no-repeat;

      .show-jg {
        background: url(../assets/images/icon/hover-jg.png) no-repeat;
      }

      .pro-store-img {
        display: none;
      }
      .pro-store-name {
        color: #fff;
        display: block;

        text-align: center;

        p {
          padding-top: 6px;
          white-space: nowrap;
          text-overflow: ellipsis;
          overflow: hidden;
        }
      }

      .pro-store-button {
        display: inline-block;
      }
    }
  }
  li:last-child {
    margin-right: 0px;
  }
}
/deep/ .el-dropdown-menu__item {
  min-height: 14px;
  line-height: 14px;
  border: 1px solid #ffa300;
  border-radius: 7px;
  color: #ffa300;
  cursor: default;
  margin-top: 5px;
  &:hover {
    color: #ffa300;
    background: #fff;
  }
  &:first-child {
    margin-top: 0;
  }
}
.nailsupply {
  display: inline-block;
  font-size: 12px;
  max-width: 100%;
  height: 30px;
  padding: 0 6px;
  line-height: 30px;
  border: 1px solid #04c93c;
  border-radius: 7px;
  color: #04c93c;
  margin-left: 6px;
}
.fs12 {
  font-size: 12px;
}
</style>
