<template>
  <div class="DetaillSettlementComponent">
    <div class="settlement-creat-timer">
      <div><span>结算发起时间：</span>{{contractInfo && contractInfo.orderBaseBean && contractInfo.orderBaseBean.settleApplyDt || ''}}</div>
      <div><span>结算状态：</span>{{contractInfo && contractInfo.orderBaseBean && contractInfo.orderBaseBean.settleStatusPain || ''}}</div>
    </div>
    <div class="vertical-title">
      <i></i>
      对账单汇总
    </div>
    <settlementApplyTableComponent :dataList="contractInfo && contractInfo.statementList || []" :outTypeIndex="outTypeIndex" :orderNo="orderNo"></settlementApplyTableComponent>
    <div class="vertical-title">
      <i></i>
      结算单
    </div>
    <div class="download-container">
      <el-button @click="handleDownloadList('2')">下载结算用印版</el-button>
      <el-button @click="handleDownloadList('1')">下载结算资料</el-button>
    </div>
    <div class="btm-table-container">
      <SettlementContractListComponent ref="settlementContractListComponentRef" :order="order" :isReview="true" :outTypeIndex="outTypeIndex" :propStatus="outTypeIndex == 0 ? '' : 'verify'" @emitData="emitData"></SettlementContractListComponent>
    </div>
  </div>
</template>

<script>

import settlementApplyTableComponent from "@/components/settlement/settlementApplyTableComponent";
import SettlementContractListComponent from "@/components/settlement/SettlementContractListComponent";
import { InterfaceService } from "@/services/api";

export default {
  components: {
    settlementApplyTableComponent,
    SettlementContractListComponent
  },
  props: {
    outTypeIndex: {
      type: Number,
      default: 0
    },
    order: {
      type: Object,
      default() { return {} }
    },
  },
  watch: {
  },
  data() {
    return {
      isLoading: false,
      orderNo: '',
      contractInfo: {},
      settleNo: '',
    }
  },
  computed: {
    bs() {
      return (
        this.$store.state.userInfo.bs
      );
    },
  },
  methods: {
    // handleType, //	String	Y	操作类型（1-下载结算资料，2-下载结算用印版）
    downloadFile(documentInfoList, handleType) {
      // 0 - 材料合同清单附件 ， 1 - 事业部合同清单附件 ，2 - 材料合同清单其他附件 ，3 - 事业部合同清单其他附件 ）
      // settle_supplier_File - 材料用印版
      // settle_purchaser_File - 事业部用印版
      let download = []
      documentInfoList.forEach(f => {
        switch (f.documentType) {
          case '0':
            download.push({
              archivePath: '材料合同清单附件/' + (f.documentName || ''),
              fileUrl: f.attachUrl,
            })
            break;
          case '1':
            download.push({
              archivePath: '事业部合同清单附件/' + (f.documentName || ''),
              fileUrl: f.attachUrl,
            })
            break;
          case '2':
            download.push({
              archivePath: '材料合同清单其他附件/' + (f.documentName || ''),
              fileUrl: f.attachUrl,
            })
            break;
          case '3':
            download.push({
              archivePath: '事业部合同清单其他附件/' + (f.documentName || ''),
              fileUrl: f.attachUrl,
            })
            break;
          case 'settle_supplier_File':
            download.push({
              archivePath: '材料用印版/' + (f.documentName || ''),
              fileUrl: f.attachUrl,
            })
            break;
          case 'settle_purchaser_File':
            download.push({
              archivePath: '事业部用印版/' + (f.documentName || ''),
              fileUrl: f.attachUrl,
            })
            break;

          default:
            break;
        }
      })

      this.packageDownload(download, `${this.outTypeIndex == 1 ? '事业部合同_' : '材料合同_'}${handleType == 2 ? '结算用印版' : '结算资料'}`)
    },


    // 打包下载
    packageDownload(fileInfoBeans, fileName) {
      console.log(fileInfoBeans, '打包下载');
      let params = {
        fileInfoBeans,
        protocol: "https",
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: `${fileName}.zip`, url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
                this.isLoading = false
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respMsg)
          }
        }, data => {
          this.$message.error(data.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },


    //导出清单
    handleDownloadList(handleType) {
      InterfaceService.settlementApprovalExport(
        {
          settleNo: this.settleNo, //	String	Y	结算单编号
          handleType, //	String	Y	操作类型（1-下载结算资料，2-下载结算用印版）
          downloadPage: this.outTypeIndex == 1 ? '0' : '1', //	String	Y	页面类型（0-事业部合同，1-材料合同）
        },
        data => {
          if (data.respData.respCode === "0000") {
            let documentInfoList = data.respData.documentInfoList || [],
              files = []

            if (!documentInfoList.length) {
              this.$message.error("暂无清单数据！")
              return
            }
            // 用印版直接下载PDF
            if (handleType == 2) {
              files = [{
                name: documentInfoList[0] && documentInfoList[0].documentName || '',
                url: documentInfoList[0] && documentInfoList[0].attachUrl || '',
              }]
            } else {
              // 下载结算资料
              const dItem = documentInfoList.find(f => f.documentType == 'settleFile') || {}
              files = [{
                name: dItem.documentName || '',
                url: dItem.attachUrl || '',
              }]
            }

            this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
              this.$message.success("已下载");
              this.isLoading = false
            });
            // this.downloadFile(documentInfoList, handleType)
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );

    },
    emitData(data) {
      this.contractInfo = data || {}
      console.log(data, '---');

      this.$emit('emitData', data)
    },
    // 获取结算单上传文件
    getStatementUpfile() {
      return this.$refs['settlementContractListComponentRef'].getStatementUpfile()
    },

    getInitData() {
      this.$refs['settlementContractListComponentRef'].init()
    },
    handleView(item) {
      console.log(item, '-');
      let encodeUrl = encodeURIComponent(item.attachUrl);
      const officeOpenTypeList = [".docx", ".dotx", ".doc", ".xlsx", ".xlsb", ".xlsm", ".xls", ".pptx", ".ppsx", ".ppt", ".pps", ".potx", ".ppsm"];
      let officeOpen = false;
      let userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
      let isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; //判断是否IE<11浏览器
      let isEdge = userAgent.indexOf("Edge") > -1 && !isIE; //判断是否IE的Edge浏览器
      let isIE11 = userAgent.indexOf('Trident') > -1 && userAgent.indexOf("rv:11.0") > -1;
      let IE = false;
      if (isIE || isEdge || isIE11) {
        IE = true
      } else {
        IE = false  //不是ie浏览器
      }
      officeOpenTypeList.some(item => {
        if (encodeUrl.indexOf(item) != -1) {
          return officeOpen = true
        }
      });
      if (officeOpen && !IE) {
        window.open("https://view.officeapps.live.com/op/view.aspx?src=" + encodeUrl, "_blank");
      } else {
        window.open(item.attachUrl, "_blank");
      }
    },
  },
  mounted() {
    this.orderNo = this.$route.query.orderNo || this.order.orderNo || ''
    this.settleNo = this.$route.query.settleNo || this.order.settleNo ||''
  },
}
</script>

<style scoped lang="scss">
.DetaillSettlementComponent {
  margin-bottom: 26px;
  line-height: 25px;
  font-size: 12px;
  .settlement-creat-timer {
    color: #444;
    display: flex;
    & > div {
      &:first-child {
        width: 550px;
      }
    }
    span {
      color: #888;
    }
  }
  .vertical-title {
    color: #444;
    font-size: 14px;
    font-weight: bold;
    border-top: 1px solid #eeeeee;
    margin-top: 10px;
    display: flex;
    align-items: center;
    padding-top: 20px;
    i {
      width: 3px;
      background: #444444;
      margin-right: 4px;
      height: 11px;
    }
  }
  .dis-flex {
    display: flex;
  }
  .download-container {
    display: flex;
    justify-content: flex-end;
    margin-top: -18px;
    /deep/ .el-button {
      height: 26px;
      padding: 0 !important;
      line-height: 26px !important;
      width: 120px;
    }
  }
}
</style>