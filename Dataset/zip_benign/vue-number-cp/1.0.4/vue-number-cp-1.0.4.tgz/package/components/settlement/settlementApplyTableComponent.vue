<template>
  <div class="settlementApplyTable">
    <div class="table-container">
      <table>
        <thead>
          <tr>
            <td width="100">序号</td>
            <td width="450">对账单编号</td>
            <td width="450">账单期间</td>
            <td width="450" class="tr">本次对账金额(含税)(元)</td>
          </tr>
        </thead>
      </table>
    </div>
    <div class="table-container">
      <table>
        <tbody v-if="!(dataList && dataList.length)">
          <tr>
            <td colspan="4" class="p0">
              <div class="tc">暂无数据</div>
            </td>
          </tr>
        </tbody>
        <tbody>
          <tr v-for="(item,index) in dataList" :key="index">
            <td width="100">
              <div>{{index + 1}}</div>
            </td>
            <td width="450">
              <div><span class="blue hand" @click="handleView(item)">{{item.statementNo || ''}}</span></div>
            </td>
            <td width="450">
              <div>{{item.statementDate || ''}}</div>
            </td>
            <td width="450" class="tr">
              <!--  -->
              <div>{{outTypeIndex == 1 ? item.statementAmoutWithTaxIn : item.statementAmoutWithTax | formatMoney}}</div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="table-collect">
      <table>
        <tr class="tr-bottom">
          <td width="550" class="tl">
            <div class="bg-blue">合计(对账单金额)</div>
          </td>
          <td class="tr">
            <span>{{toTalReconciliationMoneyCp | formatMoney}}元</span>
          </td>
        </tr>
      </table>
    </div>

  </div>
</template>

<script>

import { NumberUtil } from '@/utils/numberUtil';
import accountMixin from "@/mixins/account";
export default {
  mixins: [accountMixin],
  components: {
  },
  props: {
    dataList: {
      type: Array,
      default() { return [] }
    },
    // 内外事业部标识: 0: 材料合同, 1: 事业部合同
    outTypeIndex: {
      type: Number,
      default: 0
    },
    orderNo: {
      type: String,
      default: ''
    },
  },
  computed: {
    toTalReconciliationMoneyCp() {
      let total = 0
      this.dataList && this.dataList.forEach(f => {
        total = NumberUtil.numAdd(total, this.outTypeIndex == 1 ? f.statementAmoutWithTaxIn : f.statementAmoutWithTax)
      })
      return total || 0
    },
    NumberUtilCp() {
      return NumberUtil
    },
  },
  watch: {
  },
  data() {
    return {
      isLoading: false,
      dataInfo: {},
    }
  },
  methods: {
    handleView(item) {
      window.open(this.$router.resolve({
        path: '/statementDeclaredDetai',
        query: {
          orderNo: this.orderNo,
          statementNo: this.role == 'S' ? item.statementNo : item.purchaserStatementNo,
          purchaserStatementNo: item.purchaserStatementNo,
          supplierStatementNo: item.statementNo,
        }
      }).href, '_blank')
    },
  },
  mounted() {
  },
}
</script>

<style scoped lang="scss">
.settlementApplyTable {
  margin-bottom: 30px;
  line-height: 25px;
  font-size: 12px;
  .dis-flex {
    display: flex;
  }
  ::-webkit-scrollbar {
    width: 5px;
  }
  .table-container {
    line-height: 25px;
    font-size: 12px;
    max-height: 228px;
    overflow-x: hidden;
  }

  table {
    width: 1190px;
    margin: auto;
    .tl {
      text-align: left;
    }
    .tr {
      text-align: right;
    }
    td {
      height: 45px;
      line-height: 45px;
      padding: 0 12px;
      color: #444;
      font-size: 14px;
      border-bottom: 1px solid #eeeeee;
    }
    thead {
      tr {
        td {
          background: #f9f9f9;
          height: 50px;
          line-height: 50px;
          padding: 0 12px;
          color: #888888;
          font-size: 14px;
        }
      }
    }
    .tr-bottom {
      td {
        color: #444444;
        height: 30px;
        line-height: 30px;
        background: #ebf1ff;
        font-weight: bold;
        font-size: 12px;
        .bg-blue {
          width: 257px;
          background: #e3ecff;
        }
      }
    }
  }
}
</style>