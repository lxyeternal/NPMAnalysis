<template>
  <div class="contractInfo" :class="{reviewClass: isReview}">
    <div class="table-container">
      <div class="table-title">{{isCause ? '供货' : '采购'}}合同结算单</div>
      <table>
        <tr>
          <td class="title bgECE9FF">所属事业部</td>
          <td>{{orderBaseBeanCp.groupCompanyName}}</td>
          <td class="title bgECE9FF">材料大类</td>
          <td>{{orderBaseBeanCp.originalName}}</td>
        </tr>
        <tr>
          <td class="title bgECE9FF">材料类别</td>
          <td>{{orderBaseBeanCp.categoryName}}</td>
          <td class="title bgECE9FF">项目名称</td>
          <td>{{orderBaseBeanCp.projectName}}</td>
        </tr>
        <tr>
          <td class="title bgECE9FF">项目分期</td>
          <td>{{orderBaseBeanCp.projectTerm}}</td>
          <td class="title bgECE9FF">结算日期</td>
          <td>{{orderBaseBeanCp.settleDate || '-'}}</td>
        </tr>
        <tr v-if="propStatus == 'verify'">
          <td class="title bgECE9FF">双向合同实际差额比例</td>
          <td align="right" class="br">{{NumberUtilCp.accMul(100, orderBaseBeanCp.addRate + '')}}%</td>
        </tr>
      </table>

      <table>
        <tr>
          <template v-if="isCause">
            <td class="title bgF0F8FF">项目公司全称(签约法人)</td>
            <td colspan="3">{{orderBaseBeanCp.purchaserName}}</td>
          </template>
          <template v-else>
            <td class="title bgF0F8FF">材料公司</td>
            <td colspan="3">{{orderBaseBeanCp.brokerCorpName || orderBaseBeanCp.brokerName}}</td>
          </template>
        </tr>
        <tr>
          <td class="title bgF0F8FF">签约单位</td>
          <td colspan="3">{{isCause ? (orderBaseBeanCp.brokerCorpName || orderBaseBeanCp.brokerName) : orderBaseBeanCp.supplierName}}</td>
        </tr>
        <tr>
          <td class="title bgF0F8FF">结算单编号</td>
          <td colspan="3">{{isCause ? orderBaseBeanCp.purchaseSettleNo : orderBaseBeanCp.settleNo || provisionalSettleNo || ''}}</td>
        </tr>
        <tr>
          <td class="title bgF0F8FF">合同名称(与{{isCause ? '事业部' : '供应商'}})</td>
          <td colspan="3">{{isCause ? orderBaseBeanCp.sybOrderName : orderBaseBeanCp.ordeName || orderBaseBeanCp.contractName}}</td>
        </tr>
        <tr>
          <td class="title bgF0F8FF">合同编号</td>
          <td colspan="3">{{isCause ? orderBaseBeanCp.sybOrderNo : orderBaseBeanCp.clOrderNo}}</td>
        </tr>
        <tr>
          <td class="title bgF0F8FF">采购合同造价(元)</td>
          <td colspan="3" align="right">{{isCause ? orderBaseBeanCp.purchaserContractAmtIn : orderBaseBeanCp.purchaserContractAmt | formatMoney}}</td>
        </tr>
        <tr>
          <td class="title bgF0F8FF">对账单金额(元)</td>
          <td colspan="3" align="right">{{isCause ? toTalReconciliationMoneyCpIn : toTalReconciliationMoneyCp | formatMoney}}</td>
        </tr>
        <tr>
          <td class="title bgF0F8FF"><i class="red">*</i>违约罚款(元)</td>
          <td :class="{p0: !isReview, tr: isReview}" colspan="3">
            <input v-if="!isReview" v-model="orderBaseBeanCp.penaltyAmt" placeholder="请输入金额" v-input-custom-reg="{reg: inputNumberReg}" />
            <span v-else>{{isCause ? orderBaseBeanCp.penaltyAmtIn : orderBaseBeanCp.penaltyAmt | formatMoney}}</span>
          </td>
        </tr>
        <tr>
          <td class="title bgF0F8FF"><i class="red">*</i>其他应扣费用(元)</td>
          <td :class="{p0: !isReview, tr: isReview}" colspan="3">
            <input v-if="!isReview" v-model="orderBaseBeanCp.otherFeeAmt" placeholder="请输入金额" v-input-custom-reg="{reg: inputNumberReg}" />
            <span v-else>{{isCause ? orderBaseBeanCp.otherFeeAmtIn : orderBaseBeanCp.otherFeeAmt | formatMoney}}</span>
          </td>
        </tr>
        <tr>
          <td class="title bgF0F8FF">结算造价(元)</td>
          <td colspan="3" class="red tr">{{isCause ? settlementCostCpIn : settlementCostCp | formatMoney}}</td>
        </tr>
        <tr>
          <td class="title bgF0F8FF">核减(增)额(±元)</td>
          <td align="right" class="red">{{isCause ? cutAfterExaminationMoneyCpIn : cutAfterExaminationMoneyCp | formatMoney}}</td>
          <td class="title bgF0F8FF">核减(增)率(±%)</td>
          <td align="right" class="red">{{isCause ? cutAfterExaminationRateCpIn : cutAfterExaminationRateCp}}</td>
        </tr>
        <tr>
          <td class="title bgF0F8FF"><i class="red">*</i>合同对应建筑面积(平方米)</td>
          <td :class="{p0: !isReview, tr: isReview}">
            <input v-if="!isReview" v-model="orderBaseBeanCp.contractArea" placeholder="请输入数字" v-input-custom-reg="{reg: inputNumberReg}" />
            <span v-else>{{orderBaseBeanCp.contractArea}}</span>
          </td>
          <td class="title bgF0F8FF"><i class="red">*</i>平方米指标(平方米/元)</td>
          <td :class="{p0: !isReview, tr: isReview}">
            <input v-if="!isReview" v-model="orderBaseBeanCp.squareMeterIndex" placeholder="请输入数字" v-input-custom-reg="{reg: inputNumberReg}" />
            <span v-else>{{ isCause ? orderBaseBeanCp.squareMeterIndexIn : orderBaseBeanCp.squareMeterIndex | formatMoney}}</span>
          </td>
        </tr>
      </table>
    </div>
    <div class="download-container">
      <div>
        <span class="fs14">结算清单附件</span>
        <DownloadAndUpload appName="TRD" v-if="showUploadCp" :fileSize="153600000" :fileList="settlementListEnclosureCp" :fileSizeErrorMsg="'单个附件大小不超过150MB。'" :hasDownloadFlg="false" fromId="authorizationFile" uploadType="13" @outputValue="handleUpSettlementFileResult"></DownloadAndUpload>
        <span class="download blue-pointer" v-if="settlementListEnclosureCp && settlementListEnclosureCp.length" @click="handleOtherDownload">下载</span>
      </div>
      <p v-if="showUploadCp">单个附件大小不超过150MB。</p>
      <div class="fileList" v-if="settlementListEnclosureCp && settlementListEnclosureCp.length">
        <p v-for="(item,index) in settlementListEnclosureCp" :key="index">
          {{item.attachName}}
          <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="item.attachUrl" :attachName="item.attachName"></DownloadAndView>
          &nbsp;&nbsp;
          <span class="hand blue" v-if="!isReview || showUploadCp" @click="delSettlementOther(item)">删除</span>
        </p>
      </div>
      <div class="fileList nodata" v-else>
        未上传附件！
      </div>
    </div>

    <div class="settlementSignContainer" v-if="settleSingInfoCp.processList">
      <ul>
        <li class="mini-title">结算单签章情况</li>
      </ul>
      <table>
        <tr>
          <td rowspan="3" class="title"><span>签约单位(盖章)</span></td>
          <td>
            <span :class="{red: singContractorCp.processFlg == '0', green: singContractorCp.processFlg == '1'}">{{singContractorCp.processFlg == '1' ? '已' : '待'}}签章</span>
          </td>
          <td rowspan="3" class="title"><span>收货方(盖章)</span></td>
          <td>
            <span :class="{red: singShipToCp.processFlg == '0', green: singShipToCp.processFlg == '1'}">{{singShipToCp.processFlg == '1' ? '已' : '待'}}签章</span>
          </td>
        </tr>
        <tr>
          <td>
            <span>{{singContractorCp.custName || ''}}</span>
          </td>
          <td>
            <span>{{singShipToCp.custName || ''}}</span>
          </td>
        </tr>
        <tr>
          <td>
            <span>签章日期：{{singContractorCp.processFlg == '0' ? '' : singContractorCp.uptTm || ''}}</span>
          </td>
          <td>
            <span>签章日期：{{singShipToCp.processFlg == '0' ? '' : singShipToCp.uptTm || ''}}</span>
          </td>
        </tr>
      </table>
    </div>

    <div class="upload-container">
      <ul v-if="isReview">
        <li class="mini-title">其他附件({{isCause ? '采购商' : '供应商'}}上传)</li>
      </ul>
      <PanelTitle v-else title="附件"></PanelTitle>
      <div class="other-title">
        <span class="fs14">其他附件</span>
        <DownloadAndUpload appName="TRD" v-if="showUploadCp" :fileList="otherListCp" :hasDownloadFlg="false" fromId="otherFile" uploadType="13" @outputValue="handleUpOtherFileResult"></DownloadAndUpload>
        <span class="f12 hand blue" v-else-if="otherListCp && otherListCp.length" @click="handleOtherDownload('other')">下载</span>
      </div>
      <div class="fileList">
        <div v-if="otherListCp && otherListCp.length == 0" class="nodata">未上传附件！</div>
        <p v-for="(item, index) in otherListCp" :key="index">
          {{item.attachName}}
          <DownloadAndView downloadName="下载" viewName="预览" :hideRotate="true" :attachUrl="item.viewUrl || item.attachUrl" :attachName="item.attachName"></DownloadAndView>
          &nbsp;&nbsp;
          <span class="hand blue" v-if="!isReview || showUploadCp" @click="delOther(item)">删除</span>
        </p>
      </div>
    </div>

    <FixBottom v-if="(!$route.query.settleNo || (['0', '3', '8'].includes(orderBaseBeanCp.settleStatus) && orderBaseBeanCp.settleType == '0') && role == 'S') && !isReview">
      <div class="fl">
        <p class="f12 white" style="line-height: 36px;">
          <span>结算造价：{{settlementCostCp | formatMoney}}元</span>
        </p>
      </div>
      <div class="fr">
        <el-button @click="handleNextStep('0')">保存</el-button>
        <el-button @click="handlePreStep()">上一步</el-button>
        <el-button type="primary" @click="handleNextStep('1')">提交申请</el-button>
      </div>
    </FixBottom>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import { NumberUtil } from '@/utils/numberUtil';
import PanelTitle from "@/components/base/PanelTitle";
import DownloadAndUpload from "@/components/base/DownloadAndUpload";
import DownloadAndView from '@/components/order/DownloadAndView'
import FixBottom from "@/components/base/FixBottom";

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    PanelTitle,
    DownloadAndUpload,
    DownloadAndView,
    FixBottom,
    Loading
  },
  props: {
    // 使用状态 默认申请: apply, 审核: verify
    propStatus: {
      type: String,
      default: 'apply'
    },
    // 内外事业部标识: 0: 材料合同, 1: 事业部合同
    outTypeIndex: {
      type: Number,
      default: 0
    },
    // 是否查看模式, 默认非查看模式
    isReview: {
      type: Boolean,
      default: false
    },
    order: {
      type: Object,
      default() { return {} }
    },
  },
  data() {
    return {
      isLoading: false,
      inputNumberReg: '^[-]?(\\d{1,9}(\\.\\d{0,2})?)?$|^\\s*$',
      orderNo: '',
      settlementListEnclosure: [], // 结算清单附件
      otherList: [], // 其他附件
      contractInfo: {}, // 反显信息
      settleNo: '',
      purchaseSettleNo: '',
      provisionalSettleNo: '', // 新建时 临时 settleNo
    }
  },
  computed: {
    // 是否事业部, 返回是
    isCause() {
      return this.outTypeIndex == 1
    },
    // 是否显示上传
    showUploadCp() {
      return !this.isReview || (this.propStatus == 'verify' && ['5', '7'].includes(this.orderBaseBeanCp.settleStatus))
    },
    // 核减	（	增	）率	= 核减	（	增）	额	➗ 结算造价
    cutAfterExaminationRateCp() {
      this.initToFixed()
      return NumberUtil.accMul(NumberUtil.divide(Number(this.cutAfterExaminationMoneyCp), Number(this.settlementCostCp)) || 0, 100).toFixed(2)
    },

    // 内部 - 核减	（	增	）率	= 核减	（	增）	额	➗ 结算造价
    cutAfterExaminationRateCpIn() {
      this.initToFixed()
      return NumberUtil.accMul(NumberUtil.divide(Number(this.cutAfterExaminationMoneyCpIn), Number(this.settlementCostCpIn)) || 0, 100).toFixed(2)
    },

    // 核减	（	增	）额	=结算造价	-	对账单金额
    cutAfterExaminationMoneyCp() {
      return NumberUtil.numSub(this.settlementCostCp, this.toTalReconciliationMoneyCp) || 0
    },

    // 内部 - 核减	（	增	）额	=结算造价	-	对账单金额
    cutAfterExaminationMoneyCpIn() {
      return NumberUtil.numSub(this.settlementCostCpIn, this.toTalReconciliationMoneyCpIn) || 0
    },

    // 结算造价	= 对账单金额对账单金额	-	违约罚款违约罚款	-	其他应扣费用其他应扣费用
    settlementCostCp() {
      const penaltyAmt = isNaN(this.orderBaseBeanCp.penaltyAmt) ? this.orderBaseBeanCp.penaltyAmt && this.orderBaseBeanCp.penaltyAmt.replace(/[^\d]/g, '') : this.orderBaseBeanCp.penaltyAmt,
        otherFeeAmt = isNaN(this.orderBaseBeanCp.otherFeeAmt) ? this.orderBaseBeanCp.otherFeeAmt && this.orderBaseBeanCp.otherFeeAmt.replace(/[^\d]/g, '') : this.orderBaseBeanCp.otherFeeAmt

      return NumberUtil.numSub(Number(this.toTalReconciliationMoneyCp), NumberUtil.numAdd(Number(penaltyAmt), Number(otherFeeAmt))) || 0
    },

    // 内部 - 结算造价	= 对账单金额对账单金额	-	违约罚款违约罚款	-	其他应扣费用其他应扣费用
    settlementCostCpIn() {
      const penaltyAmtIn = this.orderBaseBeanCp.penaltyAmtIn,
        otherFeeAmtIn = this.orderBaseBeanCp.otherFeeAmtIn

      return NumberUtil.numSub(Number(this.toTalReconciliationMoneyCpIn), NumberUtil.numAdd(Number(penaltyAmtIn), Number(otherFeeAmtIn))) || 0
    },

    // 总对账金额
    toTalReconciliationMoneyCp() {
      let total = 0
      this.statementListCp.forEach(f => {
        total = NumberUtil.numAdd(total, Number(f.statementAmoutWithTax))
      })
      return total || 0
    },

    // 内部 - 总对账金额
    toTalReconciliationMoneyCpIn() {
      let total = 0
      this.statementListCp.forEach(f => {
        total = NumberUtil.numAdd(total, Number(f.statementAmoutWithTaxIn))
      })
      return total || 0
    },
    // 附件类型（0-材料合同清单附件，1-事业部合同清单附件，2-材料合同清单其他附件，3-事业部合同清单其他附件）
    settlementListEnclosureCp() {
      return this.settlementListEnclosure && this.settlementListEnclosure.filter((f, fIdx) => {
        f.sourceIdx = fIdx
        return this.isCause ? f.attachType == '1' : f.attachType == '0'
      }) || []
    },

    // 附件类型（0-材料合同清单附件，1-事业部合同清单附件，2-材料合同清单其他附件，3-事业部合同清单其他附件）
    otherListCp() {
      return this.otherList && this.otherList.filter((f, fIdx) => {
        f.sourceIdx = fIdx
        return this.isCause ? f.attachType == '3' : f.attachType == '2'
      }) || []
    },
    NumberUtilCp() {
      return NumberUtil
    },
    // 基本信息
    orderBaseBeanCp() {
      return this.contractInfo && this.contractInfo.orderBaseBean || {}
    },
    // 对账单汇总
    statementListCp() {
      return this.contractInfo && this.contractInfo.statementList || []
    },
    bs() {
      return (
        this.$store.state.userInfo.bs
      );
    },
    settleSingInfoCp() {
      let result = {}
      const eventList = this.order && this.order.eventList || []

      result = eventList.find(f => f.documentType == (this.outTypeIndex == '0' ? "settle_supplier_File" : "settle_purchaser_File")) || {}
      console.log(result, 'result');

      return result || {}
    },
    // 签约单位
    singContractorCp() {
      let result = {}
      if (this.outTypeIndex == '0') {
        result = this.settleSingInfoCp.processList && this.settleSingInfoCp.processList.find(f => f.role[0] == (this.outTypeIndex == '0' ? "3" : "2")) || {}
      } else {
        result = this.settleSingInfoCp.processList && this.settleSingInfoCp.processList.find(f => f.role[0] == '4') || {}
      }
      return result
    },
    // 收货方
    singShipToCp() {
      let result = {}
      // BUG #13091 合同结算：合同详情，事业部结算单，结算单签章情况人员信息需调换
      if (this.outTypeIndex == '1') {
        result = this.settleSingInfoCp.processList && this.settleSingInfoCp.processList.find(f => f.role[0] == (this.outTypeIndex == '0' ? "3" : "2")) || {}
      } else {
        result = this.settleSingInfoCp.processList && this.settleSingInfoCp.processList.find(f => f.role[0] == '4') || {}
      }
      return result
    }
  },
  methods: {
    init() {
      this.orderNo = this.$route.query.orderNo || ''
      this.settleNo = this.$route.query.settleNo || this.order.settleNo || ''
      this.purchaseSettleNo = this.$route.query.purchaseSettleNo || ''
      this.provisionalSettleNo = this.$route.query.provisionalSettleNo || ''
      this.initToFixed()
      // 如果 有材料公司合同结算单编号	调查询详情
      if (this.settleNo || this.purchaseSettleNo) {
        this.queryStatementSingle()
      } else {
        this.queryStateMentCondition()
      }
    },

    delOther(item) {
      this.otherList.splice(item.sourceIdx, 1)
      this.uploadSupplyCommodityStatementSingle()
    },


    handlePreStep() {
      this.$confirm("请确认数据是否保存，未保存的数据将会丢失，确认无误。点击【确认】按钮返回上一步。", "操作提示", {
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        confirmButtonText: "确认",
        cancelButtonText: '取消',
      }).then(async () => {
        this.$router.push({
          path: '/settlementApply',
          query: {
            orderNo: this.$route.query.orderNo,
            provisionalSettleNo: this.provisionalSettleNo || '',
            settleNo: this.orderBaseBeanCp.settleNo
          }
        })
      }).catch(() => {
      });
    },

    handleNextStep(type) {
      if (type == '0') {
        this.addUpdateStatementSingle(type)
        return
      }

      if (!this.orderBaseBeanCp.penaltyAmt || this.orderBaseBeanCp.penaltyAmt == '-') {
        this.$message.error('请输入违约罚款')
        return
      }
      if (!this.orderBaseBeanCp.otherFeeAmt || this.orderBaseBeanCp.otherFeeAmt == '-') {
        this.$message.error('请输入其他应扣费用')
        return
      }
      if (!this.orderBaseBeanCp.contractArea || this.orderBaseBeanCp.contractArea == '-') {
        this.$message.error('请输入合同对应建筑面积')
        return
      }
      if (!this.orderBaseBeanCp.squareMeterIndex || this.orderBaseBeanCp.squareMeterIndex == '-') {
        this.$message.error('请输入平方米指标')
        return
      }

      // 无清单附件
      if (!(this.settlementListEnclosureCp && this.settlementListEnclosureCp.length)) {
        this.$confirm("你目前还有结算清单未上传，请再次确认本结算单及相关信息是否有遗漏！确认无误后请点击【确认提交申请】按钮即可。", "结算清单未上传", {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          confirmButtonText: "确认提交申请",
          cancelButtonText: '取消',
        }).then(async () => {
          this.confirmOptNotice(type)
        }).catch(() => {
        });

        return
      }
      this.confirmOptNotice(type)
    },

    confirmOptNotice(type) {
      this.$confirm("请再次确认本结算单相关信息及金额，确认其内容没有疑议。点击【确认提交申请】按钮即可。", "确认提交结算单申请", {
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        confirmButtonText: "确认提交申请",
        cancelButtonText: '取消',
      }).then(async () => {
        const result = await this.addUpdateStatementSingle(type)
        result && this.resultsFeedback(result)
      }).catch(() => {
      });
    },
    resultsFeedback(settleNo) {
      this.$router.push({
        path: '/resultsFeedback',
        query: {
          type: 'settlementApply',
          orderNo: this.$route.query.orderNo,
          settleNo
        }
      })
      window.opener && window.opener.location.reload();
    },

    /**
     * 获取上传附件
     */
    getStatementUpfile() {
      return {
        settleNo: this.orderBaseBeanCp.settleNo, //	String	N	材料合同结算编号
        settlementAttachInfo: this.settlementListEnclosure, //	List	Y	结算清单附件
        settlementOtherAttachInfo: this.otherList, //	List	Y	其他附件
      }
    },

    /**
     * 查询详情
     */
    queryStatementSingle(settleNo, purchaserSettleNo) {
      return new Promise(resolve => {
        let params = {
          settleNo: settleNo || this.settleNo || '', //	String	Y	材料公司合同结算单编号
          purchaserSettleNo: purchaserSettleNo || this.purchaseSettleNo || '', //	String	N	事业部合同结算单编号
        };
        InterfaceService.queryStatementSingle(
          params,
          data => {
            let res = data && data.respData || {};
            if (res.respCode === "0000") {
              this.contractInfo = res
              if (this.contractInfo && this.contractInfo.orderBaseBean) {
                this.contractInfo.orderBaseBean.penaltyAmt = this.contractInfo.orderBaseBean.penaltyAmt === 0 ? '0' : this.contractInfo.orderBaseBean.penaltyAmt
                this.contractInfo.orderBaseBean.otherFeeAmt = this.contractInfo.orderBaseBean.otherFeeAmt === 0 ? '0' : this.contractInfo.orderBaseBean.otherFeeAmt
                this.contractInfo.orderBaseBean.contractArea = this.contractInfo.orderBaseBean.contractArea === 0 ? '0' : this.contractInfo.orderBaseBean.contractArea
                this.contractInfo.orderBaseBean.squareMeterIndex = this.contractInfo.orderBaseBean.squareMeterIndex === 0 ? '0' : this.contractInfo.orderBaseBean.squareMeterIndex

                this.$set(this.contractInfo.orderBaseBean, 'penaltyAmt', this.contractInfo.orderBaseBean && this.contractInfo.orderBaseBean.penaltyAmt || '')
                this.$set(this.contractInfo.orderBaseBean, 'otherFeeAmt', this.contractInfo.orderBaseBean && this.contractInfo.orderBaseBean.otherFeeAmt || '')
                this.$set(this.contractInfo.orderBaseBean, 'contractArea', this.contractInfo.orderBaseBean && this.contractInfo.orderBaseBean.contractArea || '')
                this.$set(this.contractInfo.orderBaseBean, 'squareMeterIndex', this.contractInfo.orderBaseBean && this.contractInfo.orderBaseBean.squareMeterIndex || '')
              }
              // 附件类型（0-材料合同清单附件，1-事业部合同清单附件，2-材料合同清单其他附件，3-事业部合同清单其他附件）
              const settlementAttachInfo = this.contractInfo.settlementAttachInfo || []

              this.settlementListEnclosure = settlementAttachInfo.filter(f => ['0', '1'].includes(f.attachType)) || [] //	List	Y	结算清单附件
              this.otherList = settlementAttachInfo.filter(f => ['2', '3'].includes(f.attachType)) || [] //	List	Y	其他附件
              this.$emit('emitData', this.contractInfo)
            } else {
              this.$message.error(res.respMsg)
            }
            resolve(true)
          }, data => {
            this.$message.error(data.respMsg)
          }, () => {
            this.isLoading = true
          }, () => {
            this.isLoading = false
          })
      })
    },

    /**
     * 结算单初始化处理 - 查询显示数据
     */
    queryStateMentCondition() {
      return new Promise(resolve => {
        let params = {
          orderNo: this.orderNo,
        };
        InterfaceService.queryStateMentCondition(
          params,
          data => {
            let res = data && data.respData || {};
            if (res.respCode === "0000") {
              this.contractInfo = res

              if (this.contractInfo && this.contractInfo.orderBaseBean) {
                this.$set(this.contractInfo.orderBaseBean, 'penaltyAmt', this.contractInfo.orderBaseBean && this.contractInfo.orderBaseBean.penaltyAmt || '')
                this.$set(this.contractInfo.orderBaseBean, 'otherFeeAmt', this.contractInfo.orderBaseBean && this.contractInfo.orderBaseBean.otherFeeAmt || '')
                this.$set(this.contractInfo.orderBaseBean, 'contractArea', this.contractInfo.orderBaseBean && this.contractInfo.orderBaseBean.contractArea || '')
                this.$set(this.contractInfo.orderBaseBean, 'squareMeterIndex', this.contractInfo.orderBaseBean && this.contractInfo.orderBaseBean.squareMeterIndex || '')
              }
            } else {
              this.$message.error(res.respMsg)
            }
            resolve(true)
          }, data => {
            this.$message.error(data.respMsg)
          }, () => {
            this.isLoading = true
          }, () => {
            this.isLoading = false
          })
      })
    },


    addUpdateStatementSingle(type) {
      return new Promise(resolve => {
        const params = {
          settleNo: this.orderBaseBeanCp.settleNo, //	String	N	材料合同结算编号
          purchaseSettleNo: this.purchaseSettleNo || '', //	String	N	事业部合同结算编号
          orderNo: this.orderNo, //	String	Y	合同编号
          originalName: this.orderBaseBeanCp.originalName, //	String	Y	材料大类
          categoryName: this.orderBaseBeanCp.categoryName, //	String	Y	材料类别
          purchaserContractAmt: this.orderBaseBeanCp.purchaserContractAmt, //	String	Y	采购合同造价
          purchaserContractAmtIn: this.orderBaseBeanCp.purchaserContractAmtIn, //	String	Y	内部采购合同造价
          statementAmt: this.toTalReconciliationMoneyCp, //	String	Y	对账单金额
          statementAmtIn: this.toTalReconciliationMoneyCpIn, //	String	Y	内部对账单金额
          penaltyAmt: this.orderBaseBeanCp.penaltyAmt, //	String	Y	违约罚款
          otherFeeAmt: this.orderBaseBeanCp.otherFeeAmt, //	String	Y	其他应扣费用
          settlementAmt: this.settlementCostCp, //	String	Y	结算造价
          deductionAmt: this.cutAfterExaminationMoneyCp, //	String	Y	核减（增）额
          deductionRate: this.cutAfterExaminationRateCp, //	String	Y	核减（增）率
          contractArea: this.orderBaseBeanCp.contractArea, //	String	Y	合同对应建筑面积
          squareMeterIndex: this.orderBaseBeanCp.squareMeterIndex, //	String	Y	平方米指标
          settlementAttachInfo: this.settlementListEnclosure, //	List	Y	结算清单附件
          settlementOtherAttachInfo: this.otherList, //	List	Y	其他附件
          statementList: this.statementListCp, //	List	N	对账单汇总信息
          handleType: type, //	String	Y	操作类型（1-提交，0-保存）
          provisionalSettleNo: this.provisionalSettleNo || '', // 临时编号

        };
        InterfaceService.addUpdateStatementSingle(params, data => {
          let res = data && data.respData || {};
          if (res.respCode === "0000") {
            if (type == '1') {

            } else {
              if (!this.settleNo) {
                window.opener && window.opener.location && window.opener.location.reload()
                window.history.pushState({}, 0, window.location.href + '&settleNo=' + res.settleNo + '&purchaseSettleNo=' + res.purchaseSettleNo);
              }
              this.queryStatementSingle(res.settleNo, res.purchaseSettleNo)
            }
            resolve(res.settleNo)
          } else {
            this.$message.error(res.respMsg)
            resolve(false)
          }
        }, data => { this.$message.error(data.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
      })
    },


    delSettlementOther(item) {
      console.log('idx', this.settlementListEnclosure, item);
      // 用 源index 在源数组中删除
      this.settlementListEnclosure.splice(item.sourceIdx, 1)

      this.uploadSupplyCommodityStatementSingle()
    },

    // 结算清单
    handleUpSettlementFileResult(e) {
      const { attachPath, attachName, attachUrl } = e
      this.settlementListEnclosure.push({
        attachName: attachName,
        attachUrl: attachUrl,
        filesUrl: attachPath,
        fileTypeId: "settlementListEnclosure",
        attachType: this.isCause ? '1' : '0'
      })

      this.uploadSupplyCommodityStatementSingle()
    },

    /**
    * 采购商上传结算清单附件
    */
    uploadSupplyCommodityStatementSingle() {
      // 内部查看时 才实时上传
      if (this.outTypeIndex != 1) {
        return
      }
      return new Promise(resolve => {
        const params = {
          settleNo: this.orderBaseBeanCp.settleNo, //	String	N	材料合同结算编号
          orderNo: this.orderNo, //	String	Y	合同编号
          settlementAttachInfo: this.settlementListEnclosureCp, //	List	Y	结算清单附件
          settlementOtherAttachInfo: this.otherListCp, //	List	Y	其他附件
        }
        InterfaceService.uploadSupplyCommodityStatementSingle(params, data => {
          let res = data && data.respData || {};
          if (res.respCode === "0000") {

            resolve(true)
          } else {
            this.$message.error(res.respMsg)
            resolve(false)
          }
        }, data => { this.$message.error(data.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
      })
    },

    // 获取其他附件数据
    handleUpOtherFileResult(e) {
      const { attachPath, attachName, attachUrl } = e
      // 采购商其他附件
      if (this.isCause) {
        // 如果已有数据. 需要提出 采购商其他附件  再push进去
        // let sIdx = 0
        // if (this.otherList && this.otherList.some((s, idx) => s.attachType == '3' && (sIdx = idx))) {
        //   this.otherList.splice(sIdx, 1)
        // }
        this.otherList.push({
          attachName: attachName,
          attachUrl: attachUrl,
          filesUrl: attachPath,
          fileTypeId: "otherFile",
          attachType: '3'
        })
      } else {
        if (!this.otherList.length) {
          this.otherList = []
        }
        this.otherList.push({
          attachName: attachName,
          attachUrl: attachUrl,
          filesUrl: attachPath,
          fileTypeId: "otherFile",
          attachType: '2'
        })
      }

      this.uploadSupplyCommodityStatementSingle()
    },

    handleOtherDownload(state) {
      if (state == 'other') {
        const fileInfoBeans = this.otherListCp.map(m => {
          return {
            archivePath: '其他附件/' + (m.attachName || ''),
            fileUrl: m.attachUrl,
          }
        })

        this.packageDownload(fileInfoBeans, '其他附件')
      } else {
        this.isLoading = true
        const fileInfoBeans = this.settlementListEnclosureCp.map(m => {
          return {
            archivePath: `${m.attachName}`,
            fileUrl: m.attachUrl,
          }
        })
        this.packageDownload(fileInfoBeans, '结算清单附件')
      }
    },

    // 打包下载
    packageDownload(fileInfoBeans, fileName) {
      console.log(fileInfoBeans, '打包下载');
      let params = {
        fileInfoBeans,
        protocol: "https",
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: `${fileName}.zip`, url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
                this.isLoading = false
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    initToFixed() {
      // 负数 精度 问题 修复 toFixed兼容方法
      Number.prototype.toFixed = function (s) {
        var that = this, changenum, index;
        // 负数
        if (this < 0) {
          that = -that;
        }

        changenum = (parseInt(that * Math.pow(10, s) + 0.5) / Math.pow(10, s)).toString();

        index = changenum.indexOf(".");

        if (index < 0 && s > 0) {

          changenum = changenum + ".";

          for (var i = 0; i < s; i++) {
            changenum = changenum + "0";
          }

        } else {

          index = changenum.length - index;

          for (var i = 0; i < (s - index) + 1; i++) {
            changenum = changenum + "0";
          }
        }

        if (this < 0) {
          return -changenum;
        } else {
          return changenum;
        }
      }
    }

  },
  mounted() {
    this.init()
  },
}
</script>

<style scoped lang="scss">
.contractInfo {
  margin-bottom: 26px;
  line-height: 25px;
  font-size: 12px;
  .dis-flex {
    display: flex;
  }

  .mini-title {
    border-left: 4px solid #444;
    font-size: 14px;
    color: #444;
    padding-left: 4px;
    height: 11px;
    line-height: 11px;
    display: inline-block;
    font-weight: bold;
  }

  .download-container,
  .upload-container {
    width: 1190px;
    margin: auto;
    .fileList {
      border: 1px solid #dddddd;
      padding: 14px 10px;
      margin-top: 10px;
      overflow: hidden;
      p {
        margin-top: 10px;
        &:first-child {
          margin-top: 0;
        }
      }
    }
  }
  .download-container {
    padding-bottom: 30px;
    margin: 20px auto;
    // border-bottom: 1px solid #eee;
  }
  .upload-container {
    margin-bottom: 60px;
    .other-title {
      margin-top: 10px;
    }
  }
  .nodata {
    color: #bbb;
    font-size: 12px;
  }
  .table-container {
    margin-top: 12px;
    .table-title {
      height: 54px;
      line-height: 54px;
      background: #f5f5f5;
      font-size: 18px;
      font-weight: 600;
      color: #444444;
      text-align: center;
      border: 1px solid #dddddd;
      border-bottom: 0;
    }
    table {
      width: 100%;
      border: 1px solid #dddddd;
      border-left: 0;
      border-bottom: 0;
      &:last-child {
        margin-top: 20px;
      }
      tr {
        td {
          border-bottom: 1px solid #dddddd;
          border-left: 1px solid #dddddd;
          background: #f5f5f5;
          color: #444444;
          padding: 6px 10px;
          width: 426px;
          &.p0 {
            padding: 0;
            /deep/ .el-input__inner {
              border: 0;
            }
          }
          &.title {
            width: 180px;
          }
          &.bgF0F8FF {
            background: #f0f8ff !important;
          }
          &.bgECE9FF {
            background: #ece9ff !important;
          }
        }
      }
      .br {
        border-right: 1px solid #dddddd;
      }
    }
  }
  &.reviewClass {
    .table-container {
      .table-title {
      }
      table {
        tr {
          td {
            background: #fff;
          }
        }
      }
    }
  }
}
.settlementSignContainer {
  border-bottom: 1px solid #eee;
  padding-bottom: 30px;
  margin-bottom: 20px;
  table {
    border: 1px solid #dddddd;
    border-left: 0;
    margin-top: 12px;
    td {
      &.title {
        width: 170px;
        background: #ece9ff;
        text-align: center;
        vertical-align: middle;
        color: #444444;
      }
      padding: 2px 8px;
      background: #f5f5f5;
      width: 437px;
      border-left: 1px solid #ddd;
      font-weight: 600;
      color: #888888;
    }
  }
}
.fs14 {
  font-size: 14px;
}
input[type="number"],
input {
  border: 0;
}
input:focus {
  border: 0;
}
</style>