<template>
  <div class="contractInfo">
    <el-row>
      <el-col :span="12">
        <div class="dis-flex">
          <label>合同名称：</label>
          <span class="orderNameTitle" :title="dataInfo.ordeName || ''">《{{dataInfo.ordeName || ''}}》</span>
          <a href="javascript:;" @click="handleDownloadContract">下载合同</a>
          &nbsp;
          &nbsp;
          <a href="javascript:;" @click="handleOrderDetail">查看合同详情</a>
        </div>
      </el-col>
      <el-col :span="12">
        <p>
          <label>合同编号：</label>
          <span>{{dataInfo.clOrderNo || ''}}</span>
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>品类：</label>
          <span>{{dataInfo.categoryName || ''}}</span>
        </p>
      </el-col>
      <!-- <el-col :span="12">
        <p>
          <label>双向合同实际差额比例：</label>
          <span>{{NumberUtilCp.accMul(100, Number(dataInfo.addRate))}}%</span>
        </p>
      </el-col> -->
      <el-col :span="12">
        <p>
          <label>项目名称：</label>
          <span>{{dataInfo.projectName || ''}}</span>
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>项目分期：</label>
          <span>{{dataInfo.projectTerm || ''}}</span>
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>事业部：</label>{{dataInfo.groupCompanyName}}
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>项目公司名称：</label>{{dataInfo.purchaserName}}
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>供应商名称：</label>{{dataInfo.supplierName}}
        </p>
      </el-col>
      <el-col :span="12">
        <p>
          <label>材料公司名称：</label>{{dataInfo.brokerName || dataInfo.brokerCorpName}}
        </p>
      </el-col>
    </el-row>

    <el-row style="padding-top: 15px;border-top: 1px dashed rgb(238, 238, 238);margin-top: 25px">
      <el-col :span="24">
        <p>
          <label>付款方式：</label><span v-if="dataInfo && dataInfo.pmtMethod" v-html="dataInfo.pmtMethod = dataInfo.pmtMethod.replace(/\n/g, '<br/>')"></span>
        </p>
      </el-col>
    </el-row>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import { NumberUtil } from '@/utils/numberUtil';

export default {
  components: {
    Loading
  },
  props: {
    contractInfo: {
      type: Object,
      default: {}
    },
  },
  watch: {
    contractInfo(n) {
      this.dataInfo = this.$clone(n)
    },
  },
  computed: {
    NumberUtilCp() {
      return NumberUtil || {}
    },
    divisionContract() {
      return this.bs == 'B'
    },
    bs() {
      return (
        this.$store.state.userInfo.bs
      );
    },
  },
  data() {
    return {
      isLoading: false,
      orderNo: '',
      dataInfo: {},
    }
  },
  methods: {
    /**
     * 查看合同详情
     */
    handleOrderDetail() {
      // 取消增补 功能需要
      window.open(this.$router.resolve({
        path: "/orderDetail",
        query: {
          orderNo: this.dataInfo && this.dataInfo.orderNo,
        }
      }).href, '_blank')
    },

    /**
     * 下载合同
     */
    handleDownloadContract() {
      const params = {
        orderNo: this.orderNo,
        bs: this.divisionContract ? 'B' : 'S',
        documentVersion: "",
        fileFrom: "userUpload,systemCreate",
        documentTypeList: []
      };
      InterfaceService.getContractInfo(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let attachList = [];
          let list = res.documentInfos || [];
          let hasPdf = list.some(item => {
            return item.documentType === 'dt_10_contract_profession' || item.documentType === 'dt_00_contract_profession'
          });
          list.forEach(item => {
            if (hasPdf) {
              // if (item.documentType === 'dt_10_contract_profession' || item.documentType === 'dt_00_contract_profession' || item.documentType === 'otherFile') {
              if (['dt_10_contract_profession', 'dt_00_contract_profession', 'dt_00_contract_common', 'dt_10_contract_common', 'otherFile'].indexOf(item.documentType) != -1) {
                let onOff = false;
                attachList.forEach(_item => {
                  if (item.documentId == _item.documentId) {
                    onOff = true
                  }
                });
                if (!onOff) {
                  attachList.push(item)
                }
              }
            } else {
              let onOff = false;
              attachList.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOff = true
                }
              });
              if (!onOff) {
                attachList.push(item)
              }
            }
          });
          this.handleBatchDownload(attachList, hasPdf)
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    handleBatchDownload(attachList, hasPdf) {
      let fileInfoBeans = []
      if (attachList.length) {
        if (!hasPdf) {
          attachList.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: item.documentName,
              fileUrl: item.attachUrl,
            })
          })
        } else {
          attachList.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: (item.documentType.indexOf('profession') != -1 ? '合同专业版/' : item.documentType.indexOf('common') != -1 ? '合同通用版/' : '') + item.documentName,
              fileUrl: item.attachUrl,
            })
          })
        }
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: (this.divisionContract ? (this.dataInfo.ordeName.replace('采购合同', '供应合同')) : (this.dataInfo.ordeName)) + ".zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
  },
  mounted() {
    this.orderNo = this.$route.query.orderNo || ''
  },
}
</script>

<style scoped lang="scss">
.contractInfo {
  margin-bottom: 26px;
  line-height: 25px;
  font-size: 12px;
  .dis-flex {
    display: flex;
  }
  p {
    width: 100%;
    display: flex;
    padding-right: 10px;
    word-break: break-word;
    white-space: normal;

    & > span {
      display: inline-block;
      flex: 1 1 0%;
    }
  }

  label {
    white-space: pre;
    color: #888888;
  }

  a {
    white-space: nowrap;
    color: #0082ff;
  }

  i {
    font-style: normal;
  }
}
.orderNameTitle {
    max-width: 330px;
    overflow: hidden;
    display: inline-block;
    white-space: pre;
    text-overflow: ellipsis;
}
</style>