<template>
  <div class="fixed-tool">
    <div class="fixed-tool-wrapper" :style="{height:fixedBarActive ? '226px' : '183px'}"  v-if="!showConfluence">
      <ul>
        <li class="toolbar-tab hand" @mouseover="selectStyle ('1') "
            :class="{'active':hoverFlag == '1'}"
            @mouseout="outStyle('1')">
          <div class="toolbar-tab-hd"><i class="arrow"></i><i class="fixed-icon icon-wechat"></i></div>
          <div class="toolbar-tab-bd">
            <img src="../assets/images/fixedTool/wechat_account_code.png" alt="">
            <p>扫一扫</p>
            <p>关注大家采官方公众号</p>
          </div>
        </li>
        <li class="toolbar-tab hand" @mouseover="selectStyle ('2') "
            :class="{'active':hoverFlag == '2'}"
            @mouseout="outStyle('2')">
          <div class="toolbar-tab-hd "><i class="arrow"></i><i class="fixed-icon icon-wechat-applet"></i></div>
          <div class="toolbar-tab-bd ">
            <img src="../assets/images/fixedTool/wechat_customer_code.png" alt="">
            <p>扫一扫 加微信好友</p>
            <p>立即联系大家采微信客服</p>
          </div>
        </li>
      </ul>
      <div class="top hand" @click="goTop" v-if="fixedBarActive">
        <div>
          <img src="../assets/images/fixedTool/top_icon.png" width="14.15px">
        </div>
        <span>TOP</span>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
  import { InterfaceService } from '@/services/api'
  import Loading from "@/components/base/Loading";
  import jumpConfluence from "@/mixins/jumpConfluence";

  export default {
    props:["path"],
    mixins: [jumpConfluence],
    components: {
      Loading
    },
    data() {
      return {
        fixedBarActive: false,
        showConfluence: false,
        showTop: false,
        isLoading: false,
        hoverFlag:''
      }
    },
    watch:{
      path(newVal){
        this.showConfluence = ['/advancePaymentRequestComfirm', '/advancePaymentRequesDetail', '/statementDeclaredComfirm', '/statementDeclaredDetai'].includes(newVal)
      }
    },
    computed: {
      isLogin() {
        // console.log(this.$store.state.isLogin)
        return this.$store.state.isLogin
      },
      userInfo() {
        // console.log(this.$store.state.LoginedUser.custName)
        return this.$store.state.userInfo || {}
      },

      categoryList() {
        // console.log(this.$store.state.LoginedUser.custName)
        let item = this.$store.state.categoryList
        return item
      }
    },
    methods: {
      selectStyle(flg){
        this.hoverFlag = flg
      },
      outStyle(flg){
        this.hoverFlag = ''
      },
      goProductList(name, id) {
        if (id === '1000') {
          const routeData = this.$router.resolve({
            path: `/threeNew`
          });
          window.open(routeData.href, "_blank");
          return
        }
        this.$router.push({
          path: "/productList",
          query: {
            categoryId: id,
            categoryName: name
          }
        });
      },
      async goConfluence() {
        let currentMainSelection = this.$getRootScope('selectionRole') || "false";
        let mainSelection = false
        this.userInfo.roleIds.forEach(item=>{
          if (item.roleId === "615") {
            mainSelection = true
          }
        });
        let id = "";
        if (this.path == "/purchaserCenter/modelSelectionList") {
          if (mainSelection) {
            id = "7"
          } else {
            id = "10"
          }
        }else if (this.path == "/createSelectionCategory") {
          id = "8"
        }else if(this.path == "/onlineSelectionDetail") {
          if (currentMainSelection === "true") {
            id = "9"
          } else {
            id = "10"
          }
        }
        this.isLoading = true;
        try {
          await this.toConfluence(id || '1')
        } catch (error) {
          console.log(error, 'ee---');
          this.$message.error('系统繁忙, 请稍后重试')
        }
        this.isLoading = false
      },
      // 如何使用知识库
      handleClickHowToUse() {
        let item = this.$store.state.bannerList
        item = item.filter(f => f.name === 'conflurence_Banner'),
          item = item && item[0] || {}
        const routeData = this.$router.resolve({
          path: `/${item.jumpPage || ''}`,
          query: {
            url: item.bannerDetailSrc || []
          }
        });
        window.open(routeData.href, "_blank");
      },
      goTop() {
        document.documentElement.scrollTop = 0
        document.body.scrollTop = 0
      },
      goCenter() {
        let res = this.$store.state.userInfo || {};
        let bs = res.bs && res.bs.toUpperCase();
        if (this.isLogin && this.isLogin != "0") {
          let registerPath = JSON.parse(this.$getRootScope("registerPath") || "{}");
          if (Object.keys(registerPath).length > 0) {
            this.$router.push({ path: registerPath.path, query: registerPath.query });
          }else {
            if (bs == 'B') {
              this.$router.push('/purchaserCenter/accountInfo')
            } else if (bs == 'S') {
              this.$router.push('/vendorCenter/accountInfo')
            }
          }
        }else {
          this.$router.push('/login');
        }


      },
      onScroll() {
        // 舆情页面不要出现滚动
        let scrolled = document.documentElement.scrollTop || document.body.scrollTop
        this.showTop = scrolled >= 200;

        const path = ["/contractDifferenceReport",
          "/performanceReport",
          '/evaluationReport',
          "/onlineSelectionDetail",
          "/purchaserCenter/modelSelectionList",
          "/createSelectionCategory",
          "/WordCheckReport",
        ];
        // if (this.$route.path === '/performanceReport' || this.$route.path === '/evaluationReport') returnshowTop
        if (path.indexOf(this.$route.path) !== -1) return;
        // 586、1063分别为第二个和第三个锚点对应的距离
        this.fixedBarActive = scrolled >= 500;
      },
    },
    mounted: function () {
      // if(this.menuTree && this.menuTree.length==0){
      //     InterfaceService.getCategoryList(res => {
      //         this.menuTree = res['children'];
      //         // for(let i in this.menuTree){
      //         //   this.menuTree[i].show = false;
      //         // }
      //         //console.log(this.menuTree)
      //     });
      // }

      this.$nextTick(function () {
        window.addEventListener('scroll', this.onScroll)
      })
    },
    //离开当前页面后执行
    destroyed: function () {
      window.removeEventListener('scroll', this.onScroll)
    }
  }
</script>

<style lang="scss" scoped>
  .fixed-tool {
    // position: fixed;
    // min-width: 35px;
    // height: 300px;
    // top: 50%;
    // right: 0;
    // margin-top: -150px;
    // z-index: 999;

    .fixed-tool-wrapper {
      position: fixed;
      width: 40px;
      height: 226px;
      background: #313131;
      top: 50%;
      right: 0;
      margin-top: -113px;
      z-index: 999;
      color: #fff;
      // position: relative;

      .toolbar-tab {
        position: relative;
        .icon-wechat{
          width: 30px;
          display: inline-block;
          height: 24px;
          background: url(../assets/images/fixedTool/wechat_icon.png) no-repeat center;
          background-size: contain;
        }
        .icon-wechat-applet{
          width: 30px;
          display: inline-block;
          height: 24px;
          background: url(../assets/images/fixedTool/customer.png) no-repeat center;
          background-size: contain;
        }
        .arrow {
          width: 0;
          height: 0;
          border: 5px solid transparent;
          border-left-color: rgba(120, 122, 128, 0.75);
          position: absolute;
          top: 50%;
          left: 0;
          margin-top: -3px;
          display: none;
        }

        .toolbar-tab-hd {
          text-align: center;
          height: auto;
          line-height: 20px;
          position: relative;
          padding:18px 0;


        }

        .toolbar-tab-bd {
          min-height: 200px;
          display: none;
          width: 187px;
          background: #AAAAAA;
          position: absolute;
          top: 0;
          right: 40px;


          img {
            width: 115px;
            height: auto;
            display: block;
            margin: 20px auto 10px;
          }
          p {
            color: #fff;
            font-size: 12px;
            line-height: 17px;
            text-align: center;
          }
          &.second {
            top: -65px;
          }
          &.third {
            top: -130px;
          }
          &.fourth {
            top: -195px;
          }
          &.five {
            top: -260px;
          }
        }
        .knowledge-tab{
          background: #7b7c82 !important;
          width: 200px;
          min-height: 240px;
          img{
            width: 60px !important;
          }
          p:nth-of-type(2){
            margin-bottom: 10px;
          }
          p:nth-of-type(3){
            margin-bottom: 5px;
          }
        }
        &.active {
          .arrow {
            display: inline-block;
          }
          .toolbar-tab-hd {
            background: linear-gradient(131deg, #D7B064 0%, #ECCE8B 100%);
            .text{
              color: #000;
            }


          }


          .toolbar-tab-bd {
            display: inline-block;

          }
        }
        .fixed-icon {
          margin-right: 0;
        }

        .category-item {
          height: 50px;

          line-height: 50px;
          color: #fff;
          padding-left: 64px;
          position: relative;

          .icon-small-24 {
            position: absolute;
            top: 50%;
            left: 24px;
            margin-top: -12px;
          }
          &:hover {
            background-color: #7b7d83;
          }
        }
      }
      .text{
        color: #fff;
        text-align: center;
      }
    }
    .knowledge {
      height: 140px;
    }
    .show-top {
      height: 180px;
    }
    .top {
      position: absolute;
      bottom: 0;
      left: 0;
      width: 40px;
      font-size: 14px;
      height: 43px;
      color: #fff;
      text-align: center;
      cursor: pointer;
      line-height: 20px;
      &:hover {
        background: linear-gradient(131deg, #D7B064 0%, #ECCE8B 100%);
      }
      div{
        height: 18px;
        width: 14px;
        margin: auto;
      }
    }
  }

</style>
