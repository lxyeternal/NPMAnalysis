<template>
    <div class="freight">
        <div v-if="tab==1">
            <div class="header">
                <ul>
                    <li>运费模板</li>
                </ul>
            </div>
            <div class="panel-content">
                <div class="panel-header">
                    <span class="red">*</span>模板名称:
                    <div class="form-input">
                        <input type="text" v-model="templateName" placeholder="请填写模板名称，不超过20个字">
                        <i v-if="showError&&!templateName">请填写模板名称</i>
                        <i v-if="showError&&templateName.length>20">模板名称不超过20个字</i>
                    </div>
                    <hr>
                </div>
                <div class="panel-body">
                    <p class="freight-position-tip">
                        <i class="el-icon-location"></i> 指定地区配置</p>
                    <table class="table">
                        <thead>
                            <tr>
                                <th class="tl" width="300">运送到</th>
                                <th>是否免运费</th>
                                <th>计费方式</th>
                                <th width="140">运费(税前)</th>
                                <th>运送方式</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr v-for="(row,index) in freightList" :key="index">
                                <td class="tl">
                                    <div class="td-area">
                                        <span v-if="row.defaultFlg==1">全国(指定地区除外)</span>
                                        <span v-if="row.defaultFlg==0">{{row.destinationLabel.join('、')}}</span>
                                    </div>
                                </td>
                                <td>{{row.freeShippingFlg==0?'否':'是'}}</td>
                                <td>
                                    <span v-if="row.freeShippingFlg==1">-</span>
                                    <span v-if="row.freeShippingFlg==0">{{row.pricingMode==0?'按计量单位':row.pricingMode==1?'固定运费':'按商品单价比例'}}</span>
                                </td>
                                <td>
                                    <span v-if="row.freeShippingFlg==1">-</span>
                                    <span v-if="row.freeShippingFlg==0">
                                        <span v-if="row.pricingMode==1">{{row.freightAmt}}元</span>
                                        <span v-if="row.pricingMode==0">{{row.startVol}}{{row.goodsUnitDisp}}以内{{row.freightAmt}}元，每增加{{row.increaseVol}}{{row.goodsUnitDisp}}加{{row.increaseFreightAmt}}元</span>
                                        <span v-if="row.pricingMode==2">按商品单价的{{+row.freightPercent}}%计算运费</span>
                                    </span>
                                </td>
                                <td>{{row.shippingMethod==0?'供应商自行配送':'物流配送'}}</td>
                                <td>
                                    <el-button type="text" @click="handleEdit(index,row)">编辑</el-button>
                                    <el-button type="text" @click="handleDel(index,row)">删除</el-button>
                                </td>
                            </tr>
                        </tbody>
                    </table>

                    <p>
                        <el-button type="text" icon="el-icon-plus" @click="handleAddFreight">指定地区配置运费</el-button>
                    </p>
                </div>
            </div>
            <div class="operate">
                <el-button type="primary" size="small" @click="handleConfirm">确认</el-button>
                <el-button size="small" @click="handleCancel">取消</el-button>
            </div>
        </div>

        <FreightPick v-if="tab==2" :data="selectFreight" :disabledAll="disabledAll" :disabledCode="disabledCode" :selectCode="selectCode" @confirm="handleFreightPick" @cancel="handleFreightCancel"></FreightPick>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import FreightPick from "@/components/freight/FreightPick";
import { InterfaceService } from "@/services/api";

export default {
    components: {
        Loading,
        FreightPick
    },
    data() {
        return {
            showError: false,
            tab: 1,
            isLoading: false,
            templateName: "",
            freightList: [],
            listIndex: null,
            disabledAll: false,
            disabledCode: [],
            selectCode: [],
            selectFreight: ""
        };
    },
    methods: {
        // 编辑
        handleEdit(index, row) {
            this.arrangeCode(row, index);
            this.listIndex = index;
            this.selectFreight = row;
            this.tab = 2;
        },
        // 删除
        handleDel(index) {
            this.freightList.splice(index, 1);
        },
        // 添加指定地区运费btn
        handleAddFreight() {
            this.arrangeCode();
            this.listIndex = null;
            this.tab = 2;
        },
        // 确定添加指定地区运费
        handleFreightPick(data) {
            console.log(data,"data")
            this.tab = 1;
            if (data.pricingMode == "2") {
                data.freightAmt = +data.freightPercent / 100
            }
            if (this.listIndex || this.listIndex == 0) {
                this.$set(this.freightList, this.listIndex, data);
            } else {
                this.freightList.push(data);
            }
        },
        // 取消指定地区运费选择
        handleFreightCancel() {
            this.tab = 1;
        },
        // 确认创建
        handleConfirm() {
            this.showError = true;
            if (!this.templateName) {
                return false;
            } else if (this.templateName.length > 20) {
                return false;
            } else if (!this.freightList.length) {
                this.$message.error("请填加指定地区运费");
                return false;
            }
            this.addFreight();
        },
        // 取消创建
        handleCancel() {
            this.$emit("cancel");
        },
        // 整理选中和禁用地区code
        arrangeCode(data, index) {
            this.selectCode = [];
            if (data && data.defaultFlg == "0") {
                this.selectCode = data.destination;
            }

            let arr = [];
            this.disabledAll = false;
            this.freightList.forEach((item, i) => {
                if (i != index) {
                    if (item.defaultFlg == "0") {
                        arr = arr.concat(item.destination);
                    }else if(item.defaultFlg == "1"){
                        this.disabledAll = true;
                    }
                }
            });
            this.disabledCode = arr;
        },
        init() {},
        addFreight() {
            const params = {
                templateName: this.templateName,
                carryModeList: this.freightList
            };
            InterfaceService.addVendorFreight(
                params,
                data => {
                    console.log(data);
                    if (data.respCode === "0000") {
                        if (data.respData.respCode == "0000") {
                            this.$message.success("新增运费模板成功");
                            this.$emit(
                                "confirm",
                                data.respData && data.respData.templateId
                            );
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    },
    mounted() {
        this.init();
    }
};
</script>

<style lang="scss" scoped>
.freight {
    margin-bottom: 50px;
}

.header {
    background: #fff;
}

.header ul {
    width: 100%;
    height: 28px;
    font-weight: bold;

    li {
        width: 80px;
        height: 28px;
        line-height: 28px;
        text-align: center;
        float: left;
        cursor: pointer;
        position: relative;
        font-size: 14px;

        &:after {
            width: 4px;
            height: 14px;
            background: #ffd64e;
            top: 50%;
            left: 0;
            margin-top: -7px;
            content: "";
            position: absolute;
        }
    }
}

.panel-content {
    margin: 20px 0;
    background: #f5f5f5;
}

.panel-header {
    padding: 20px;
    input {
        width: 260px;

        margin-left: 10px;
    }

    hr {
        margin-top: 20px;
        border: none;
        border-top: 1px solid #ccc;
    }
}

.panel-body {
    padding: 0 20px;
}

.form-input {
    display: inline-block;
    position: relative;

    i {
        position: absolute;
        top: 100%;
        left: 12px;
        padding-top: 2px;
        font-size: 12px;
        line-height: 1;
        color: #f56c6c;
    }
}

.freight-position-tip {
    font-size: 14px;
    font-weight: bold;
    color: #444;
    i {
        font-size: 16px;
    }
}

.table {
    width: 100%;
    margin-top: 10px;
    border: 1px solid #ececec;
    td,
    th {
        border-bottom: 1px solid #ececec;
    }
    thead {
        color: #909399;
        background: #f5f5f5;
        th {
            padding: 10px 15px;
        }
    }
    tbody {
        background: #fff;
        td {
            padding: 20px 15px;
            text-align: center;
            line-height: 18px;
            vertical-align: middle;
        }
    }

    .td-area {
        overflow: hidden;
        white-space: nowrap;
        max-width: 300px;
        text-overflow: ellipsis;
    }
}

.operate {
    button {
        width: 100px;
    }
}
</style>
