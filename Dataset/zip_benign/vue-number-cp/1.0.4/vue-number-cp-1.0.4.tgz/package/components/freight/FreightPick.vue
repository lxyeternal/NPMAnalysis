<template>
    <div>
        <div class="header">
            <ul>
                <li id="dom-click">指定地区运费</li>
            </ul>
        </div>
        <div class="panel-content">
            <el-form class="form" :model="form" label-width="120px" :rules="rules">
                <el-form-item label="选择地区：" prop="defaultFlg">
                    <el-radio v-model="form.defaultFlg" label="0">指定地区</el-radio>
                    <el-radio v-model="form.defaultFlg" label="1" :disabled="disabledAll">全国 | 设置除指定省份外，其余地区的运费</el-radio>
                </el-form-item>
                <div class="area-content" v-if="form.defaultFlg=='0'">
                    <div class="area" v-for="(area,index) in areaMap" :key="index">
                        <label>{{area.label}}</label>
                        <div class="province-content">
                            <div class="province" v-for="(province,_index) in area.provinces" :key="_index" :class="{'active':province.popover}">
                                <el-checkbox :indeterminate="province.isIndeterminate" v-model="province.checked" :disabled="province.disabled" @change="handleCheckAllProvince(province,index,_index)"></el-checkbox>

                                <el-popover popper-class="area-popover" trigger="click" placement="bottom-start" :offset="-22" :visible-arrow="false" :disabled="!province.citys.length" v-model="province.popover">
                                    <ul class="city-content">
                                        <li v-for="(city,__index) in province.citys" :key="__index">
                                            <el-checkbox v-model="city.checked" :disabled="city.disabled" @change="handleCheckCity(province)">{{city.label}}</el-checkbox>
                                        </li>
                                    </ul>
                                    <span class="province-label" slot="reference">
                                        {{province.label}}
                                        <span class="num" v-if="province.selectNum">({{province.selectNum}})</span>
                                        <i v-if="!province.popover" class="el-icon-caret-bottom"></i>
                                        <i v-if="province.popover" class="el-icon-caret-top"></i>
                                    </span>
                                </el-popover>
                            </div>
                        </div>
                    </div>
                    <hr>
                </div>

                <el-form-item label="是否免运费：" prop="freeShippingFlg">
                    <el-radio v-model="form.freeShippingFlg" label="0">否 | 自定义运费</el-radio>
                    <el-radio v-model="form.freeShippingFlg" label="1">是 | 供应商承担运费</el-radio>
                </el-form-item>
                <el-form-item label="计费方式：" style="margin-left: 20px;" v-if="form.freeShippingFlg=='0'">
                    <el-radio v-model="form.pricingMode" label="0" >按计量单位计价</el-radio>
                    <el-radio v-model="form.pricingMode" label="1">固定运费</el-radio>
                    <el-radio v-model="form.pricingMode" label="2">按商品单价百分比计价</el-radio>
                    <div class="price-model" v-if="form.pricingMode=='0'">
                        <p>
                            <label style="margin-left: 15px;">起步</label>
                            <span class="form-input">
                                <input v-model="form.startVol" type="number" @blur="handleBlur($event,'start')" placeholder="请填写数量" />
                                <i v-if="showError&&!form.startVol">请输入起步数量</i>
                            </span>

                            <span class="form-input">
                                <el-select placeholder="请选择单位" :value="form.goodsUnitDisp" v-if="!goodsUnitList.length">
                                </el-select>
                                <el-select placeholder="请选择单位" v-model="form.goodsUnit" v-if="goodsUnitList.length">
                                    <el-option v-for="(item,index) in goodsUnitList" :key="index" :label="item.unitName" :value="item.unitCode"></el-option>
                                </el-select>
                                <i v-if="showError&&!form.goodsUnit">请选择单位</i>
                            </span>
                            <label>，运费</label>
                            <span class="form-input">
                                <input v-model="form.freightAmt" type="number" v-input-number placeholder="请填写金额" />
                                <i v-if="showError&&!form.freightAmt">请输入金额</i>
                            </span>
                            <label>元</label>
                        </p>
                        <p>
                            <label>每递增</label>
                            <span class="form-input">
                                <input v-model="form.increaseVol" type="number" @blur="handleBlur($event,'add')" placeholder="请填写数量" />
                                <i v-if="showError&&!form.increaseVol">请输入递增数量</i>
                            </span>
                            <span class="form-input">
                                <el-select placeholder="请选择单位" :value="form.goodsUnitDisp" v-if="!goodsUnitList.length">
                                </el-select>
                                <el-select placeholder="请选择单位" v-model="form.goodsUnit" v-if="goodsUnitList.length">
                                    <el-option v-for="(item,index) in goodsUnitList" :key="index" :label="item.unitName" :value="item.unitCode"></el-option>
                                </el-select>
                                <i v-if="showError&&!form.goodsUnit">请选择单位</i>
                            </span>
                            <label>，递增运费</label>
                            <span class="form-input">
                                <input v-model="form.increaseFreightAmt" type="number" v-input-number placeholder="请填写金额" />
                                <i v-if="showError&&!form.increaseFreightAmt">请输入金额</i>
                            </span>
                            <label>元</label>
                        </p>
                    </div>
                    <div class="price-model" v-if="form.pricingMode=='1'">
                        <p>
                            <label>固定运费</label>
                            <span class="form-input">
                                <input v-model="form.freightAmt" type="number" v-input-number placeholder="请填写金额" />
                                <i v-if="showError&&!form.freightAmt">请输入金额</i>
                            </span>
                            <label>元</label>
                        </p>
                    </div>
                    <div class="price-model" v-if="form.pricingMode=='2'">
                        <p>
                            <label>按商品单价</label>
                            <span class="form-input">
                                <input v-model="form.freightPercent" type="number" v-input-number placeholder="请填写百分比" />
                                <i v-if="showError&&!form.freightPercent">请输入百分比</i>
                            </span>
                            <label>%</label>
                        </p>
                    </div>
                </el-form-item>

                <el-form-item label="运送方式：" prop="shippingMethod">
                    <el-radio v-model="form.shippingMethod" label="0">供应商自行配送</el-radio>
                    <el-radio v-model="form.shippingMethod" label="1">物流配送</el-radio>
                </el-form-item>
            </el-form>
        </div>
        <div class="operate">
            <el-button type="primary" size="small" @click="handleConfirm">确认</el-button>
            <el-button size="small" @click="handleCancel">取消</el-button>
        </div>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import { MoneyUtil } from '@/utils/moneyUtil';
const form = {
    defaultFlg: "0",
    destination: [],
    freeShippingFlg: "1",
    pricingMode: "0",
    startVol: null,
    freightAmt: null,
    freightPercent: null,
    increaseVol: null,
    increaseFreightAmt: null,
    goodsUnit: "",
    shippingMethod: "0"
};

export default {
    components: {
        Loading
    },
    props: ["disabledCode", "selectCode", "data", "disabledAll"],
    data() {
        return {
            isLoading: false,
            showError: false,
            form: Object.assign({}, form),
            rules: {
                defaultFlg: [{ required: true, message: "请选择地区" }],
                freeShippingFlg: [
                    { required: true, message: "请选择是否免运费" }
                ],
                shippingMethod: [{ required: true, message: "请选择运送方式" }]
            },
            areaMap: [],
            goodsUnitList: []
        };
    },
    methods: {
        handleConfirm() {
            const destination = this.arrangeDestinationCode();
            this.form.destination = destination.code;
            this.form.destinationLabel = destination.label;
            if (this.form.goodsUnit) {
                this.arrangeFormGoods();
            }
            if (this.checkValid()) {
                // if (this.form.freeShippingFlg == 1) {
                //     delete this.form.pricingMode;
                //     delete this.form.startVol;
                //     delete this.form.freightAmt;
                //     delete this.form.increaseVol;
                //     delete this.form.increaseFreightAmt;
                // }

                if (this.form.templateId && this.form.carryModeID) {
                    // 更新运送方式
                    this.updateTransport();
                } else if (this.form.templateId) {
                    // 新增运送方式
                    this.addTransport();
                } else {
                    // 新增
                    this.$emit("confirm", this.form);
                }
            }
        },
        handleBlur(ev,type){
            let val = Number(ev.target.value);
            // type == "start" ? this.form.startVol = +val.toFixed(2) : this.form.increaseVol = +val.toFixed(2);
            type == "start" ? this.form.startVol = +MoneyUtil.moneyFixed(val,2) : this.form.increaseVol = +MoneyUtil.moneyFixed(val,2) ;

        },
        handleCancel() {
            this.$emit("cancel");
        },
        // 选择省份
        handleCheckAllProvince(province) {
            if (province.disabled) {
                return;
            }

            province.popover = true;
            province.isIndeterminate = false;

            if (province.citys.length) {
                province.citys.forEach(item => {
                    if (!item.disabled) {
                        item.checked = province.checked;
                    }
                });

                const allCheck = province.citys.every(item => {
                    return item.checked;
                });

                const disabledCheck = province.citys.some(item => {
                    return item.disabled;
                });

                if (allCheck) {
                    province.checked = true;
                }

                if (
                    disabledCheck &&
                    !province.isIndeterminate &&
                    !province.checked &&
                    !allCheck
                ) {
                    province.isIndeterminate = true;
                }
            }

            if (province.disabled) {
                province.checked = true;
            }

            this.arrangeCityNum(province);
            this.$forceUpdate();
        },
        // 选择城市
        handleCheckCity(province) {
            const allCheck = province.citys.every(item => {
                return item.checked;
            });
            const someCheck = province.citys.some(item => {
                return item.checked;
            });
            const disabledCheck = province.citys.some(item => {
                return item.disabled;
            });
            province.isIndeterminate = false;
            if (allCheck) {
                province.checked = true;
            } else if (someCheck) {
                province.isIndeterminate = true;
            } else {
                province.checked = false;
            }

            if (disabledCheck && !province.isIndeterminate && !allCheck) {
                province.isIndeterminate = true;
            }

            this.arrangeCityNum(province);
            this.$forceUpdate();
        },
        // 计算选择城市数量
        arrangeCityNum(province) {
            let num = 0;
            province.citys.forEach(item => {
                if (item.checked) {
                    num++;
                }
            });
            province.selectNum = num;
        },
        // 整理目的地
        arrangeDestinationCode() {
            let arr = [],
                result = { code: [], label: [] };
            this.areaMap.forEach(area => {
                area.provinces.forEach(item => {
                    let cArr = [];
                    if (item.citys && item.citys.length) {
                        item.citys.forEach(_item => {
                            if (!_item.disabled && _item.checked) {
                                cArr.push(_item);
                            }
                        });
                    }
                    if (
                        !item.disabled &&
                        item.checked &&
                        cArr.length == item.citys.length
                    ) {
                        arr.push(item);
                    } else {
                        arr = arr.concat(cArr);
                    }
                });
            });
            arr.forEach(item => {
                result.code.push(item.code);
                result.label.push(item.label);
            });

            return result;
        },
        // 复现code选择和禁选
        recoverCode(code, type) {
            this.areaMap.forEach(area => {
                area.provinces.forEach(province => {
                    if (code.indexOf(province.code) !== -1) {
                        province[type] = true;
                        if (type == "disabled") {
                            province.checked = true;
                        }
                    }
                    if (province.citys && province.citys.length) {
                        province.citys.forEach(city => {
                            if (province[type]) {
                                city[type] = true;
                                if (type == "disabled") {
                                    city.checked = true;
                                }
                            } else if (code.indexOf(city.code) !== -1) {
                                city[type] = true;
                                if (type == "disabled") {
                                    city.checked = true;
                                }
                            }
                        });

                        const allCheck = province.citys.every(item => {
                            return item.checked;
                        });
                        const someCheck = province.citys.some(item => {
                            return item.checked;
                        });

                        if (allCheck) {
                            province.checked = true;
                        } else if (someCheck) {
                            province.isIndeterminate = true;
                        }
                    }

                    this.arrangeCityNum(province);
                });
            });
        },
        // 检查表单有效性
        checkValid() {
            const allDisabled = this.areaMap.every(area => {
                return area.provinces.every(prov => {
                    return prov.disabled;
                });
            });
            if (allDisabled) {
                this.$message.error("地区已全部添加");
                return false;
            }

            if (this.form.defaultFlg == "0" && !this.form.destination.length) {
                this.$message.error("请选择指定地区");
                return false;
            }

            if (this.form.freeShippingFlg == "0") {
                // 自定义运费
                this.showError = true;
                if (
                    this.form.pricingMode == "0" &&
                    (!this.form.startVol ||
                    !this.form.freightAmt ||
                    !this.form.goodsUnit ||
                    !this.form.increaseVol ||
                    !this.form.increaseFreightAmt)
                ) {
                    // 按计量单位
                    return false;
                } else if (
                    this.form.pricingMode == "1" &&
                    !this.form.freightAmt
                ) {
                    // 固定运费
                    return false;
                }
            }

            return true;
        },
        init() {
            this.areaMap = this.$getAreaMap();
            this.getGoodsUnit();
            if (this.disabledCode && this.disabledCode.length) {
                this.recoverCode(this.disabledCode, "disabled");
            }
            if (this.selectCode && this.selectCode.length) {
                this.recoverCode(this.selectCode, "checked");
            }

            this.form = Object.assign({}, form);
            this.form = Object.assign(this.form, this.data);
            if (this.form.pricingMode === "2") {
                this.form.freightPercent = this.form.freightAmt
            }
            console.log(this.form);
        },
        addTransport() {
            if (this.form.pricingMode === "2") {
                this.form.freightAmt = +this.form.freightPercent / 100;
            }
            const params = Object.assign({}, this.form);
            if(params.defaultFlg == '1'){
                delete params.destination;
            }
            console.log(params);
            delete params.destinationLabel;
            InterfaceService.addVendorTransport(
                params,
                data => {
                    console.log(data);
                    if (data.respCode === "0000") {
                        if (data.respData.respCode == "0000") {
                            this.$message.success("添加指定运费配置成功");
                            this.$emit("confirm");
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        updateTransport() {
            if (this.form.pricingMode === "2") {
                this.form.freightAmt = +this.form.freightPercent / 100;
            }
            const params = Object.assign({}, this.form);
            delete params.destinationCode;
            delete params.destinationName;
            if(params.defaultFlg == '1'){
                delete params.destination;
            }
            delete params.destinationLabel;
            console.log(params);
            InterfaceService.updateVendorTransport(
                params,
                data => {
                    console.log(data);
                    if (data.respCode === "0000") {
                        if (data.respData.respCode == "0000") {
                            this.$message.success("修改运费配置成功");
                            this.$emit("confirm");
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        getGoodsUnit() {
            this.isLoading = true;
            InterfaceService.getGoodsUnitList(data => {
                this.isLoading = false;
                this.goodsUnitList = data.goodsUnit;
                console.log(this.goodsUnitList)
            });
        },
        arrangeFormGoods() {
            this.goodsUnitList.forEach(item => {
                if (item.unitCode == this.form.goodsUnit) {
                    this.form.goodsUnitDisp = item.unitName;
                }
            });
        }
    },
    mounted() {
        this.init();
        // 多个el-popover点击事件页面卡顿(hide调用多次)，hack先触发点击
        setTimeout(() => {
            document.getElementById("dom-click").click();
        }, 0);
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-radio__input.is-checked + .el-radio__label {
    color: #444444;
}

.header {
    background: #fff;
}

.header ul {
    width: 100%;
    height: 28px;
    font-weight: bold;

    li {
        width: 110px;
        height: 28px;
        line-height: 28px;
        text-align: center;
        float: left;
        cursor: pointer;
        position: relative;
        font-size: 14px;

        &:after {
            width: 4px;
            height: 14px;
            background: #ffd64e;
            top: 50%;
            left: 0;
            margin-top: -7px;
            content: "";
            position: absolute;
        }
    }
}

.panel-content {
    margin: 20px 0;
    padding: 10px 0;
    background: #f5f5f5;
}

.operate {
    margin-bottom: 50px;
    button {
        width: 100px;
    }
}

.form {
    hr {
        margin: 0 20px;
        margin-left: -50px;
        border-top: 1px solid #ececec;
    }

    font-size: 12px;
    /deep/ .el-form-item__label {
        font-size: 12px;
    }

    /deep/ .el-form-item {
        margin-bottom: 0;
    }
}

.form-input {
    display: inline-block;
    position: relative;

    i {
        position: absolute;
        top: 100%;
        left: 0;
        padding-top: 2px;
        font-size: 12px;
        line-height: 1;
        color: #f56c6c;
    }

    input::-ms-clear{display:none;}
}
.area-content {
    padding: 20px 20px 20px 80px;
    .area {
        display: flex;
        margin-bottom: 15px;
        > label {
            width: 70px;
            padding: 5px;
        }
    }
}

.province-content {
    .province {
        display: inline-block;
        width: 100px;
        margin-left: 30px;
        padding: 5px;
        border-radius: 3px;
        white-space: nowrap;
        &.active {
            background: #ffffff;
        }
    }
    .province-label {
        white-space: nowrap;
        cursor: pointer;

        .num {
            color: #0082ff;
        }
    }
}

.city-content {
    li {
        float: left;
        width: 50%;
        margin: 5px 0;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }
}
.price-model {
    width: 600px;
    padding: 10px;
    border: 1px solid #d5e7f1;
    font-size: 12px;
    background: #f4fbff;
    p {
        margin-bottom: 15px;
        white-space: nowrap;
    }
    label {
        margin: 0 5px;
    }
    input {
        width: 120px;
    }
    /deep/ .el-select {
        width: 120px;
    }
}
</style>