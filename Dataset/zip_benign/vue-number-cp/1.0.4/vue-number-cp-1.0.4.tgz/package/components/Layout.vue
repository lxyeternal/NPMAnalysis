<template>
  <div>
    <div class="container-wrapper" :class="{'ie-browser':isIE}">
      <!-- <keep-alive> -->
      <router-view></router-view>
      <!-- </keep-alive> -->
      <FixedTool :path="$route.path"></FixedTool>
    </div>

    <div v-if="show()" class="copy-right">网络经营许可证 <a href="https://beian.miit.gov.cn/" target="_blank">沪ICP备20014012号-1</a> © Copyright 2020 上海绿地建筑材料集团有限公司 版权所有</div>

  </div>
</template>

<script>
import {
  InterfaceService
} from '@/services/api'
import FixedTool from '@/components/FixedTool'
export default {
  components: {
    FixedTool
  },
  data: function () {
    return {
      isIE: false,
      categoryBaseBeans: [], // 已有商品
    }
  },
  watch: {
    userInfo(info) {
      if (info) {
        this.initUser()
      }
    }
  },
  async  created() {
    this.initUser()
    try {
      await this.getCategoryOfBidWinning()
    } catch (error) {
      throw new TypeError('getCategoryOfBidWinning Error')
    }
    this.initCategoryList()
    //this.initHotProductList()
  },
  methods: {
    // 获取登录状态、设置用户信息
    initUser() {
      let userInfo = sessionStorage.getItem('user')
      if (userInfo) {
        this.$store.commit('setUserInfo', JSON.parse(userInfo))
      }
    },
    initCategoryList() {
      let categoryList = sessionStorage.getItem('categoryList')
      if (categoryList) {
        categoryList = JSON.parse(categoryList || '[]')
        this.findAlreadyExists(this.categoryBaseBeans, categoryList)
        this.$store.commit('changeCategoryList', categoryList)
        this.$setRootScope('categoryList', JSON.stringify(categoryList))
      } else {
        InterfaceService.getCategoryList(
          {
            categoryId: "1",
            queryType: "2",
          }, data => {
            if (data.respData && data.respData.respCode === "0000") {
              let res = data.respData.categoryInfos || []

              this.findAlreadyExists(this.categoryBaseBeans, res)

              this.$store.commit('changeCategoryList', res)
              this.$setRootScope('categoryList', JSON.stringify(res))
            } else {
              this.$message.error(data.respData && data.respData.respMsg);
            }
          }, data => { }, () => { }, () => { })
      }
    },

    /**
     * 查找已存在商品类目
     */
    findAlreadyExists(categoryBaseBeans, res) {
      categoryBaseBeans && categoryBaseBeans.forEach(f => {
        this.categoryInfosExternalCirculation(f.categoryId, res)
        if (f.children && f.children.length) {
          this.findAlreadyExists(f.children, res)
        }
      })
    },

    categoryInfosExternalCirculation(id, res) {
      res && res.some(s => {
        if (s.categoryId == id) {
          return s.existence = true
        }
        if (s.children && s.children.length) {
          this.categoryInfosExternalCirculation(id, s.children)
        }
      })
    },

    getCategoryOfBidWinning() {
      return new Promise((resolve, reject) => {
        const categoryBaseBeans = JSON.parse(this.$getRootScope('categoryBaseBeans') || '[]') || []
        if (categoryBaseBeans.length) {
          this.categoryBaseBeans = categoryBaseBeans
          resolve(true)
          return
        }
        InterfaceService.getCategoryOfBidWinning({}, data => {
          if (data.respData && data.respData.respCode === "0000") {
            this.categoryBaseBeans = data.respData.categoryBaseBeans || []
            this.$setRootScope('categoryBaseBeans', JSON.stringify(data.respData.categoryBaseBeans))
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
          }
          resolve(true)
        }, data => { reject(data) }, () => { }, () => { });
      })
    },
    show() {
      let bool = true;
      let path = this.$route.path;
      if (path == "/tenderingDetail" || path == "/GoTendering") {
        bool = false
      }
      return bool
    },
    // initHotProductList(){
    //   InterfaceService.getHotProductList(res => {
    //       this.$store.commit('changeHotProductList', res)
    //       this.$setRootScope('hotProductList', JSON.stringify(res))
    //   });
    // },
    // 根据sessionStorage 设置 localStorage
    setLocalStorageBySeeeionStorage() {
      this.$removeRootLocalStorage('user')
      const userInfo = this.$getRootScope('user')
      if (userInfo !== 'null') {
        this.$setRootLocalStorage('user', userInfo)
      }
    }
  },
  mounted() {
    this.setLocalStorageBySeeeionStorage()
    this.isIE = this.$isIE()
  },
  destroyed: function () {


  }
}
</script>

<style>
@import "../assets/style.css";
</style>
