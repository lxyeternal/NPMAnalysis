<template>
  <div>
    <div class="panel-content">
      <el-form class="form" :model="form" size="small" label-width="75px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="印章类型：">
              <el-select class="w400" clearable filterable v-model="form.sealIndex" placeholder="请选择签章类型">
                <el-option label="全部" value=""></el-option>
                <el-option v-for="(seal,index) in sealKindList" :key="index" :label="seal.sealKindName" :value="index + 1"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="状态：" label-width="100px">
              <el-select class="w400" clearable filterable v-model="form.sealStatus" placeholder="请选择状态">
                <el-option label="全部" value=""></el-option>
                <el-option v-for="(seal,index) in sealStatusList" :key="index" :label="seal.sealStatusName" :value="seal.sealStatus"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24" class="tc">
            <el-button type="primary" size="small" @click="handleSearch">搜索</el-button>
            <el-button size="small" @click="handleClear">清除</el-button>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="product-table">
      <!-- 列表 -->
      <table>
        <thead>
          <tr class="tl">
            <td width="150">印章类型</td>
            <td>用印人员</td>
            <td width="200">授权时间</td>
            <td>创建时间</td>
            <td>状态</td>
            <td width="100" class="tr">操作</td>
          </tr>
        </thead>
        <template v-if="sealList.length">
          <tbody v-for="(seal,index) in sealList" :key="index" class="tl tbody-row">
            <tr>
              <td width="150">
                {{seal.sealName || seal.sealKindName}}
              </td>
              <td>
                {{seal.sealAcctName}}
              </td>
              <td>
                {{seal.effectiveStartdate || ''}} ~ {{seal.effectiveEnddate || ''}}
              </td>
              <td>
                {{seal.creTm}}
              </td>
              <td>
                {{seal.sealStatusName}}
              </td>
              <td width="100" class="opreate tr">
                <div>
                  <span v-if="!['rejected', 'canceled'].includes(seal.sealStatus)" class="hand blue" @click="handleDownLoad(seal)">
                    授权书下载
                  </span>
                  <span v-else>-</span>
                  <span v-if="['applying'].includes(seal.sealStatus)" class="hand blue" @click="handleWithdraw(seal)">
                    撤回
                  </span>
                </div>
              </td>
            </tr>
            <tr v-if="seal.sealStatus === 'rejected' && seal.approveMsg">
              <td colspan="6" class="p0">
                <p class="reject_notice">
                  <span>申请失败原因：</span>
                  <span>{{seal.approveMsg}}</span>
                </p>
              </td>
            </tr>
          </tbody>
        </template>
      </table>
      <div class="product-empty" v-if="!sealList.length">
        <img src="@/assets/images/icon-no-product.png">
        <p>没有搜索到相关印章，请重新修改搜索条件搜索！</p>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>

    <!-- 撤回 -->
    <el-dialog class="dialog customize-column-dialog" title="撤回提示" :append-to-body="true" :lock-scroll="true" :visible.sync="withdrawDialog" width="900px" center :close-on-click-modal="false">
      <div class="confirm-del-center mr-auto txt-center">
        <!-- <el-input type="textarea" show-word-limit :maxlength="400" placeholder="请输入撤回意见" v-model="withdrawValue"></el-input> -->
        是否撤回电子印章申请? 撤回后, 该条申请关闭, 你要重新发起电子印章申请。
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 100px" @click="handleWithdrawSubmitReviewData()">是</el-button>
        <el-button size="small" style="width: 100px" @click="withdrawDialog = false">否</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

const form = {
  sealKind: "",
  sealStatus: "",
};
export default {
  name: "applicationRecordList",
  components: {
    Loading
  },
  props: {
    propAcctId: String, // 事业部 调用入参
    propCorpId: String, // 事业部 调用入参
  },
  data() {
    return {
      isLoading: false,
      form: Object.assign({}, form),
      sealList: [],
      sealKindList: [],
      sealStatusList: [],
      withdrawDialog: false, // 撤回
      withdrawValue: '',
      applyId: '',
      sealKindObj: {
        corp: '合同专用印章',
        project: '项目专用印章',
        legal: '法人代表章',
        personal: '个人名章',
        authorize: '被授权的个人名章',
        applying: '审核中',
        approved: '审核通过',
        rejected: '审核失败',
        replaced: '替换',
        canceled: '已撤回',
      },
    }
  },
  methods: {
    handleSearch() {
      this.searchSealApplicationList()
    },
    handleClear() {
      this.form = Object.assign({}, form)
      this.handleSearch()
    },

    /**
     * 撤回
     */
    handleWithdraw(item) {
      this.withdrawValue = ''
      this.applyId = item.applyNo
      this.withdrawDialog = true
    },


    /**
     * 下载
     */
    handleDownLoad(item) {
      this.$download([{
        name: item.attachName || '',
        url: item.attachUrl || ''
      }]).then(e => this.$message.success('下载完成'))
    },

    handleWithdrawSubmitReviewData() {
      let params = {
        acctId: this.propAcctId || '',
        applyId: this.applyId || '', //String	授权ID
        approveMsg: this.withdrawValue || '', //String	撤回意见
      };
      InterfaceService.postWithdraw(params, data => {
        this.withdrawDialog = false
        if (data.respCode === "0000") {
          if (data.respData.respCode == "0000") {
            this.$message.success('撤回成功');
            this.searchSealApplicationList()
          } else {
            this.$message.error(data.respData.respMsg);
          }
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },

    searchSealApplicationList() {
      let params = {};
      // console.log(this.form.sealIndex, this.sealKindList[this.form.sealIndex].sealKind, this.sealKindList[this.form.sealIndex].sealId);
      this.form['sealKind'] = this.form.sealIndex ? this.sealKindList[this.form.sealIndex - 1].sealKind : '';
      this.form['sealId'] = this.form.sealIndex ? this.sealKindList[this.form.sealIndex - 1].sealId : '';
      params = Object.assign(params, this.form);
      try {
        params.corpId = this.propCorpId || this.$route.query.propCorpId || this.$store.state.userInfo.corpId
      } catch (error) {
        console.error(error)
      }
      InterfaceService.searchSealApplicationList(
        params,
        data => {
          if (data.respCode === "0000") {
            if (data.respData.respCode == "0000") {
              this.sealList = data.respData.sealApproveList || [];
              if (this.sealKindList.length == 0) {
                this.sealKindList = data.respData.sealKindList || [];
              }
              this.sealStatusList = data.respData.sealStatusList || [];
            } else {
              this.$message.error(data.respData.respMsg);
            }
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    init() {
      this.tab = this.$removeRootLocalStorage('applicationState')
      this.searchSealApplicationList()
    }
  },
  mounted() {
    this.init()
  }
}
</script>

<style scoped lang="scss">
.w400{
  width: 400px !important;
}
.panel-content {
  margin: 20px 0;
  padding: 20px 10px;
  background: #f5f5f5;
  .form-item {
    position: relative;
    display: inline-block;
    line-height: 32px;

    .float-right {
      position: absolute;
      top: 3px;
      right: 1px;
      bottom: 2px;
      padding: 0 5px;
      line-height: 27px;
      background: #ffffff;
      height: 27px;
    }
  }
}
.product-table {
  margin-top: 20px;
  /deep/ .el-table__body-wrapper {
    font-size: 12px;
  }

  /deep/ .el-table th,
  .el-table td {
    padding: 14px 0;
  }
  table {
    table-layout: fixed;
    width: 100%;
    line-height: 23px;
    font-size: 12px;
    td {
      padding: 14px 20px;
      vertical-align: middle;
      word-break: break-all;
    }
    thead {
      font-size: 14px;
      text-align: center;
      white-space: nowrap;
      color: #909399;
      background: #f5f5f5;
    }
    .tbody-row {
      &:hover {
        background: #e8f3fd;
      }
    }
    tbody {
      text-align: center;
      tr {
        border-bottom: 1px solid #ebeef5;
      }
    }
    .opreate {
      div {
        text-align: right;
      }
      span {
        display: block;
      }
    }
  }
}
.product-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
.p0 {
  padding: 0 !important;
}
.reject_notice {
  text-align: left;
  background: #ffe9eb;
  padding: 4px 12px;
}
</style>