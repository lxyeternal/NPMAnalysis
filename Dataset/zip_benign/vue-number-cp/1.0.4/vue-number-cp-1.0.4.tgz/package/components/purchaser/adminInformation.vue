<template>
  <div class="company-address pad-bottom">
    <div class="order-info-title">管理员账户信息
      <template v-if="!isReview">
        <span v-if="(!adminInfo.approveStatus || ['init'].includes(adminInfo.approveStatus) && adminInfo.approveId)" style="padding-left: 10px;" class="blue hand f12" @click="handleChangeAddAdmin">提交管理员授权书</span>
        <span v-if="adminInfo.approveStatus === 'approved'" style="padding-left: 10px;" class="blue hand f12" @click="handleChangeAdmin">变更信息</span>
        <span v-if="adminInfo.approveStatus === 'submited'" style="padding-left: 10px;" class="blue hand f12" @click="handleChangeAdmin">管理员变更中，点击查看变更详情
        </span>
        <span v-if="adminInfo.approveStatus === 'rejected'" style="padding-left: 10px;" class="blue hand f12" @click="handleChangeAdmin"><em class="red">管理员变更被拒绝，</em>点击查看变更详情</span>
      </template>
    </div>
    <div>
      <ul class="company-top">
        <li class="clearfloat">
          <div class="company-left">
            <span>姓名：</span>
            <div class="company-showtext">{{adminInfo.name || "无"}}</div>
          </div>
          <div class="company-left">
            <div class="company-left" style="width: auto;height: 26px;">
              <span>授权书：</span>
              <div class="company-showtext a-text" :title="adminInfo.authorizationName">{{adminInfo.authorizationName}}</div> <i style="padding-left: 10px;" class="fr hand blue" @click="handleOpenAuthorization">查看</i>
            </div>
          </div>
        </li>
        <li class="clearfloat">
          <div class="company-left">
            <span>手机号：</span>
            <div class="company-showtext">{{adminInfo.mobile || "无"}}</div>
          </div>
          <div class="company-left">
            <span>邮箱：</span>
            <div class="company-showtext">{{adminInfo.email || "无"}}</div>
          </div>
        </li>
        <li class="clearfloat">
          <div class="company-left">
            <span>部门：</span>
            <div class="company-showtext">{{adminInfo.department || "无"}}</div>
          </div>
          <div class="company-left">
            <span>职位：</span>
            <div class="company-showtext">{{adminInfo.position || "无"}}</div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import { viewFile } from '@/utils/orderUtil';

export default {
  props: {
    adminInfo: {
      type: Object
    },
    isReview: {
      type: Boolean,
      default: false
    },
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo
    },
    isAdmin() {
      // 去除材料公司管理员（1000）
      let adminRoles = ['2000', '3000', '4000', '5000', '9000']
      return this.userInfo.roleIds && this.userInfo.roleIds.some(item => {
        return adminRoles && adminRoles.indexOf(item.roleId) != -1
      });
    }
  },
  methods: {
    handleChangeAddAdmin() {
      // window.open(this.$router.resolve({
      //   path: '/activateac',
      //   query: {
      //     path: 'companyMessage'
      //   }
      // }).href, "_blank")
      this.$router.push(
        {
          path: '/activateac',
          query: {
            path: 'companyMessage',
            approveId: this.adminInfo.approveId || ''
          }
        }
      )
    },
    handleChangeAdmin() {
      this.$emit('changeAdmin', true)
    },
    changeAdd() {
      this.changeCompanyAdd = false;
    },
    handleOpenAuthorization() {
      if (this.adminInfo.authorizationUrl) {
        viewFile(this.adminInfo.authorizationUrl)
      } else {
        this.$message.error("暂无预览地址")
      }
    },
  },
  mounted() {
  },

}
</script>

<style lang="scss" scoped>
.order-info-title {
  .f12 {
    line-height: 12px;
  }
}
.company-address-title p {
  display: inline-block;
  height: 43px;
  line-height: 43px;
}

.company-address-title p:first-child {
  width: 95px;
  font-size: 14px;
  color: #333333;
  text-align: center;
  border-bottom: 3px solid #4f525a;
}

.company-address-title p:last-child {
  width: 853px;
  font-size: 12px;
  color: #373737;
  text-align: center;
  border-bottom: 3px solid #ffd64e;
  height: 43px;
  text-align: right;
  padding-right: 20px;
}

.company-address-title p span {
  display: inline-block;
  height: 24px;
  padding-right: 12px;
  border: 1px solid #4f525a;
  line-height: 24px;
  text-align: left;
  padding-left: 30px;
  cursor: pointer;
}

.company-address-title p span.edit {
  background: url(../../assets/images/purchaser/edit_icon.png) no-repeat;
  background-position: 10px center;
}

.company-address-title p span.save {
  background: url(../../assets/images/purchaser/save_icon.png) no-repeat;
  background-position: 10px center;
}

.company-top {
  margin-top: 13px;
  font-size: 12px;
}
.company-top li {
  line-height: 26px;
}
.company-top li.changeInfo {
  height: 48px;
  line-height: 48px;
}
.company-top li .company-left {
  float: left;
  display: inline-block;
  width: 49%;
  line-height: 26px;
}
.company-top li .company-left span {
  display: inline-block;
  height: 26px;
  line-height: 26px;
  text-align: right;
  color: #888;
  vertical-align: top;
}
.company-top li .company-left span em {
  color: #e93340;
}
.company-top li .company-showtext {
  width: 270px;
  display: inline-block;
}
.company-information .el-input {
  width: 270px;
  height: 26px;
}
.canNotEdit /deep/ .el-input__inner {
  height: 32px;
  line-height: 32px;
  border: 1px solid #dddddd;
}
.el-input.is-disabled.canNotEdit /deep/ .el-input__inner {
  height: 26px;
  line-height: 26px;
  background: white;
  color: #333333;
  cursor: unset;
  border: 1px solid #ffffff;
  padding: 0;
}
.company-images {
  margin: 13px 0 14px;
  overflow: hidden;
}
.company-images li {
  width: 178px;
  height: 178px;
  border: 1px solid #dddddd;
  float: left;
  margin-left: 29px;
}
.company-images li img {
  width: 100%;
  height: auto;
}
.company-address,
.contact-data {
  margin-top: 13px;
}

.company-address-title {
  margin-bottom: 14px;
}
.company-add-edit li {
  line-height: 48px;
  height: 48px;
  width: 100%;
}
.company-add-edit-text {
  display: inline-block;
  width: 49%;
}
.company-add-edit-text /deep/ .el-form-item__label {
  width: 172px;
  padding: 0;
  font-size: 12px;
  color: #888888;
  line-height: 48px;
}
.company-add-edit-text /deep/ .el-input {
  height: 32px;
  position: relative;
}
.company-add-edit-text /deep/ .el-form-item__content {
  line-height: 48px;
  margin-left: 172px;
}
.company-add-edit-text /deep/ .el-input__inner {
  height: 32px;
  line-height: 32px;
}
.company-add-edit-text /deep/ .el-form-item__error {
  top: 82%;
}
.el-form-item.shengshiqu {
  height: 48px;
  line-height: 48px;
  margin-bottom: 0;
}
.el-form-item.shengshiqu /deep/ .el-form-item__label {
  line-height: 48px;
  font-size: 12px;
  color: #888888;
  width: 172px;
  padding: 0;
}
.el-form-item.shengshiqu /deep/ .el-form-item__content {
  line-height: 48px;
  margin-left: 172px;
}
.el-form-item.shengshiqu /deep/ .el-form-item__content .el-input {
  width: 198px;
  height: 32px;
}
.el-form-item.shengshiqu .linkage /deep/ .el-select {
  width: 27%;
}
.el-form-item.shengshiqu /deep/ .el-form-item__content .el-input__inner {
  height: 32px;
}
.el-form-item.shengshiqu /deep/ .el-form-item__error {
  top: 82%;
}
.pad-bottom {
  padding-bottom: 13px;
}
.a-text {
  display: inline-block;
  width: auto !important;
  max-width: 254px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>