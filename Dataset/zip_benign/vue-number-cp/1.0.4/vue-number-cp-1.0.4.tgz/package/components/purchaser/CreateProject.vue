<template>
  <div>
    <div class="content">
      <el-form ref="form" :model="projectInfo" :rules="rules" label-width="170px" size="small">
        <template v-if="operationType == 'create'">
          <el-row>
            <el-col :span="12">
              <el-form-item label="ERP项目编号：" prop="erpProjectCode">
                <el-input v-model.trim="projectInfo.erpProjectCode" type="text" placeholder="请输入" maxlength="256"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="项目名称：" prop="projectName">
                <el-input v-model.trim="projectInfo.projectName" type="text" placeholder="请输入" maxlength="128"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </template>
        <template v-else>
          <el-row>
            <el-col :span="12">
              <el-form-item label="项目分期编号："  prop="projectStageCode">
                <el-input v-model.trim="projectInfo.projectStageCode" type="text" placeholder="请输入" maxlength="32"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="分期名称："  prop="projectStageName">
                <el-input v-model.trim="projectInfo.projectStageName" type="text" placeholder="请输入" maxlength="128"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="建筑面积(m²)：" prop="floorArea">
                <el-input v-model.trim="projectInfo.floorArea" type="text" placeholder="请输入" maxlength="12" @blur="handleBlur($event)" @input="checkNum($event)"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <div class="form-inline-item-dispickter">
              <el-form-item label="项目详细地址：">
                <Distpicker :address="distpickerData" @receive="getAddressCode"></Distpicker>
                <div class="el-form-item__error" v-if="!regSelectedFlg">
                  请输入项目详细地址
                </div>
              </el-form-item>
            </div>
          </el-row><el-row>
          <el-col :span="24">
            <el-form-item label="" prop="projectDetailAddr">
              <el-input v-model="projectInfo.projectDetailAddr" type="text" placeholder="详细地址" maxlength="256"></el-input>
            </el-form-item>
          </el-col>
          </el-row>
          <!-- <el-row>
            <el-col :span="12">
              <el-form-item label="项目经理：" prop="projectManagerName">
                <el-input v-model="projectInfo.projectManagerName" type="text" placeholder="请输入" maxlength="200"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="项目经理电话：" prop="projectManagerMobile">
                <el-input v-model.trim="projectInfo.projectManagerMobile" type="text" placeholder="请输入" maxlength="11"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row> -->
            <el-col :span="12">
              <el-form-item label="是否合作项目：" prop="isCorprationProject">
                <el-select clearable v-model="projectInfo.isCorprationProject"  placeholder="请选择">
                  <el-option label="否" value="0"></el-option>
                  <el-option label="是" value="1"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="利润率5%以下项目：" prop="isProfitUnder5">
                <el-select clearable v-model="projectInfo.isProfitUnder5"  placeholder="请选择">
                  <el-option label="否" value="0"></el-option>
                  <el-option label="是" value="1"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24">
              <el-form-item label="各方利益：" prop="interest">
                <el-input v-model="projectInfo.interest" type="text" placeholder="请输入" maxlength="200"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="业态：" prop="projectType">
                <el-select clearable v-model="projectInfo.projectType"  placeholder="请选择">
                  <el-option v-for="(item,index) in projectTypeList" :value="item" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="装修类型：" prop="decorateType">
                <el-select clearable v-model="projectInfo.decorateType"  placeholder="请选择">
                  <el-option v-for="(item,index) in decorateTypeList" :value="item" :key="index"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="计划或实际开工时间：" prop="projectStartDt">
                <el-date-picker :picker-options="pickerOptionsStart" type="date" placeholder="请选择日期" value-format="yyyy-MM-dd" v-model="projectInfo.projectStartDt" style="width: 100%;" @change="handleChangeStartTm"></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="计划或实际竣工时间："  prop="projectEndDt">
                <el-date-picker :picker-options="pickerOptionsEnd" type="date" placeholder="请选择日期" value-format="yyyy-MM-dd" v-model="projectInfo.projectEndDt" style="width: 100%;"></el-date-picker>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="项目开发阶段："  prop="projectDevelopmentStage">
                <el-input v-model.trim="projectInfo.projectDevelopmentStage" type="text" placeholder="请输入" maxlength="200"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </template>
      </el-form>
      <div class="tc" style="margin: 20px 0 180px;">
        <el-button class="normal-btn" type="primary" @click="submit">保存</el-button>
        <el-button class="normal-btn" @click="handleCancel">取消</el-button>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
  import Distpicker from "@/components/base/Distpicker";
  import Loading from "@/components/base/Loading";
  import { InterfaceService } from "@/services/api";

  const rules = {
  erpProjectCode: [
    {
      required: true,
      message: "ERP项目编号",
      trigger: "blur"
    },
  ],
}
  export default {
    name: "CreateProject",
    props:['projectInfo','operationType',"distpickerData","projectType"],
    components: {
      Distpicker,
      Loading,
    },
    data() {
      return {
        regSelectedFlg: true,
        isLoading: false,
        rules:{
          erpProjectCode:[
            {
              required: true,
              message: "请输入ERP项目编号",
              trigger: "blur"
            },
          ],
          projectName:[
            {
              required: true,
              message: "请输入项目名称",
              trigger: "blur"
            },
          ],
          projectStageCode:[
            {required: true, message: '请输入项目分期编号',trigger: 'blur'}
          ],
          // projectDetailAddr:[
          //   {required: true, message: '请输入详细地址',trigger: 'blur'}
          // ],
          projectStageName:[
            {required: true, message: '请输入项目分期',trigger: 'blur'}
          ],
          projectManagerName:[
            {required: true, message: '请输入项目经理',trigger: 'blur'}
          ],
          // isCorprationProject:[
          //   {required: true, message: '请选择是否合作项目',trigger: 'change'}
          // ],
          // isProfitUnder5:[
          //   {required: true, message: '请选择是否利润率5以下项目',trigger: 'change'}
          // ],
          // interest:[
          //   {required: true, message: '请输入各方利益',trigger: 'blur'}
          // ],
          // projectType:[
          //   {required: true, message: '请选择业态',trigger: 'change'}
          // ],
          // decorateType:[
          //   {required: true, message: '请选择装修类型',trigger: 'change'}
          // ],
          // projectEndDt:[
          //   {required: true, message: '请选择计划或实际竣工时间',trigger: 'change'}
          // ],
          // projectStartDt:[
          //   {required: true, message: '请选择计划或实际开工时间',trigger: 'change'}
          // ],
          projectDevelopmentStage:[
            {required: true, message: '请输入项目开发阶段',trigger: 'blur'}
          ],
          floorArea:[
            { pattern: /^[+]{0,1}(\d+)$|^[+]{0,1}(\d+\.\d+)$/,
              message: "请输入数字",
              trigger: "blur" }
          ],
          projectManagerMobile:[
            {
              required: true,
              message: "请输入项目经理电话",
              trigger: "blur"
            },
            { pattern: this.$commonExpression('mobile'),
              message: "电话输入有误，请重新输入",
              trigger: "blur" }
          ]
        },
        projectTypeList:[
          "办公",
          "超高层",
          "酒店",
          "商业综合体",
          "学校",
          "住宅",
          "其他",
        ],
        decorateTypeList:[
          "部分精装",
          "精装",
          "毛坯",
        ],
        pickerOptionsStart: {
        },
        pickerOptionsEnd: {
          disabledDate: time => {
            if (this.projectInfo.projectStartDt) {
              return time.getTime() <= new Date(this.projectInfo.projectStartDt).getTime() - 86400000
            }
          }
        },
      }
    },
    methods:{
      handleBlur(ev) {
        let value = ev.target.value || ''
        console.log(value);
        if (+value == 0) {
          this.$message.error('建筑面积需大于0')
          value = '';
          this.projectInfo.floorArea = ''
        }
      },
      checkNum(value,type) {
        value = value.replace(/[^\d.]/g, ""); //清除"数字"和"."以外的字符
        value = value.replace(/^\./g, ""); //验证第一个字符是数字
        value = value.replace(/\.{2,}/g, "."); //只保留第一个, 清除多余的
        // value = value.replace(/-{2,}/g,""); //只保留第一个, 清除多余的
        if (value.length > 1 && value[value.length - 1] == '-') {
          value = value.substring(0, value.length - 1)
        }
        value = value.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
        value = value.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); //控制可输入的小数

        this.projectInfo.floorArea = value;
      },
      handleChangeStartTm(ev) {
        console.log(ev);
        if (new Date(ev) > new Date(this.projectInfo.projectEndDt)) {
          this.projectInfo.projectEndDt = ""
        }
      },
      submit() {
        if (!this.projectInfo.projectDistrictCode && this.operationType !== 'create') {
          this.regSelectedFlg = false;
          return false
        }
        this.$refs.form.validate((valid) => {
          if (valid) {
            let params = Object.assign({},this.projectInfo)
            const corpId = this.$route.query.corpId  || ''
            corpId && (params.corpId = corpId)
            InterfaceService[this.operationType == 'create' ?  (this.projectType === 'new' ? 'createProject' : 'editProject') : (this.projectType === 'new' ? 'addProjectStages' : 'editProjectStages')](params,data => {
              if (data.respData.respCode === '0000') {
                this.$message.success('操作成功！');
                this.$emit("submit",this.operationType)
              }else {
                this.$message.error(data.respData.respMsg)
              }
            }, data => {
              this.$message.error(data.respData.respMsg)
            }, () => {
              this.isLoading = true
            }, () => {
              this.isLoading = false
            })
          }
        })
      },
      getAddressCode(res) {
        this.projectInfo.projectProvCode = res.provinceCode;
        this.projectInfo.projectCityCode = res.cityCode;
        this.projectInfo.projectDistrictCode = res.blockCode;
        console.log(this.projectInfo,"this.projectInfo");
        if (this.projectInfo.projectDistrictCode) {
          this.regSelectedFlg = true
        }
      },
      handleCancel() {
        this.$emit("cancel",this.operationType)
      }
    }
  }
</script>

<style scoped lang="scss">
.content {
  margin-top: 13px;
  font-size: 12px;
}
  /deep/ .el-form-item__label {
    color: #888;
  }
  /deep/ .el-form-item--small.el-form-item{
    margin-bottom: 14px;
  }
  /deep/ .el-input--small .el-input__inner{
    height: 34px;
  }
  /deep/ .el-select{
    width: 100%;
  }
.form-inline-item-dispickter{
  .el-form-item{
    /deep/ .el-form-item__label:before{
      content: '*';
      color: #F56C6C;
      margin-right: 4px;
    }
  }
}
</style>