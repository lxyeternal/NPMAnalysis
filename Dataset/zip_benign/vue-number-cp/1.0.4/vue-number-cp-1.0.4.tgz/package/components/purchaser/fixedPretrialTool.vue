<template>
    <div class="fixed-tool">
        <div class="fixed-tool-wrapper knowledge" :class="{'show-top':showTop}">
            <ul v-if="!wordCheck">
                <li class="toolbar-tab">
                    <div class="toolbar-tab-hd">
                        <div class="line">—</div>
                        <div class="text">差异汇总信息</div>
                    </div>
                    <div class="toolbar-tab-bd knowledge-tab">
                        <p v-for="(item,ind) in gatherList[0].results" :key="ind" @click="handleGoResult('gatherList',ind,gatherList[0].results.length)">{{item.title}}</p>
                    </div>
                </li>
                <li class="toolbar-tab" v-if="detailList.length && filterList(detailList[0].results,'chapter').length">
                    <div class="toolbar-tab-hd">
                        <div class="line">—</div>
                        <div class="text">合同差异明细</div>
                    </div>
                    <div class="toolbar-tab-bd knowledge-tab">
                        <p v-for="(item,ind) in filterList(detailList[0].results,'chapter')" :key="ind" @click="handleGoResult('detailList',item.index,detailList[0].results.length)">{{item.chapter}}</p>
                    </div>
                </li>
            </ul>
            <ul v-else>
                <li class="toolbar-tab" v-if="detailList.length && filterList(detailList[0].results,'chapter').length">
                    <div class="toolbar-tab-hd">
                        <div class="line">—</div>
                        <div class="text">文本对比明细</div>
                    </div>
                    <div class="toolbar-tab-bd knowledge-tab">
                        <!--<p v-for="(item,ind) in filterList(detailList[0].results,'chapter')" :key="ind" @click="handleGoResult('detailList',item.index,detailList[0].results.length)">{{item.page.join("、")}}</p>-->
                        <p v-for="(item,ind) in detailList[0].results" :key="ind" @click="handleGoResult('detailList',ind,detailList[0].results.length)">{{item.page.join("、")}}</p>
                    </div>
                </li>
            </ul>
            <div class="top hand" @click="goTop" v-if="showTop">
                <span><i class="el-icon-arrow-up"></i>TOP</span>
            </div>
        </div>
    </div>
</template>

<script>
    import { InterfaceService } from '@/services/api'
    import Loading from "@/components/base/Loading";
    import jumpConfluence from "@/mixins/jumpConfluence";

    export default {
        props:["gatherList","detailList","wordCheck"],
        mixins: [jumpConfluence],
        components: {
            Loading
        },
        data() {
            return {
                showTop: false,
                isLoading: false,
            }
        },
        watch:{},
        computed: {
        },
        methods: {
            filterList(mainList,title) {
                let list = [];
                if (mainList && mainList.length) {
                    let obj = {};
                    list = mainList.reduce(function(item, next) {
                        obj[next[title]] ? '' : obj[next[title]] = true && item.push(next);
                        return item;
                    }, []);
                    mainList.forEach((item,index)=>{
                        list.forEach((_item,ind)=>{
                            if (item.otext=== _item.otext) {
                                _item.index = index
                            }
                            if (_item.chapter === "无内容变化") {
                                list.splice(ind,1)
                            }
                        })
                    })
                }
                return list
            },
            goTop() {
                document.documentElement.scrollTop = 0
                document.body.scrollTop = 0
            },
            handleGoResult(listType,ind,len) {
                console.log(ind);
                this.$emit("goResultRow",listType,ind,len)
            },
            onScroll() {
                // 舆情页面不要出现滚动
                let scrolled = document.documentElement.scrollTop || document.body.scrollTop
                this.showTop = scrolled >= 200;
            },
        },
        mounted: function () {
            this.$nextTick(function () {
                // window.addEventListener('scroll', this.onScroll)
            })
        },
        //离开当前页面后执行
        destroyed: function () {
            // window.removeEventListener('scroll', this.onScroll)
        }
    }
</script>

<style lang="scss" scoped>
    .fixed-tool {
        position: fixed;
        min-width: 35px;
        height: 300px;
        top: 50%;
        right: 0;
        margin-top: -150px;
        z-index: 9999;

        .fixed-tool-wrapper {
            width: 35px;
            height: 300px;
            background: #4f5259;
            position: relative;

            .toolbar-tab {
                height: 80px;
                position: relative;
                .toolbar-tab-hd {
                    text-align: center;
                    height: auto;
                    line-height: 17px;
                    position: relative;
                    padding-top:10px;
                    .line{
                        line-height: 10px;
                        color: #fff;
                    }
                }

                .toolbar-tab-bd {
                    max-height: 380px;
                    overflow-y: scroll;
                    display: none;
                    width: 244px;
                    background: rgba(79, 82, 89, 0.65);
                    position: absolute;
                    top: 0;
                    right: 34px;
                    p {
                        color: #fff;
                        font-size: 12px;
                        line-height: 16px;
                        text-align: center;
                        cursor: pointer;
                    }
                }
                .knowledge-tab{
                    width: 200px;
                    /*min-height: 240px;*/
                    margin: 10px 0;
                    p{
                        padding: 10px 15px;
                        text-align: left;
                    }
                    p:nth-child(1) {
                        margin-top: 10px;
                    }
                    & p:hover {
                        background: rgb(124, 124, 130);
                    }
                    img{
                        width: 60px !important;
                    }
                }
                &:hover {
                    .toolbar-tab-hd {
                        background-color: #ffd64e;
                        .text,.line{
                            color: #4f5259;
                        }
                    }
                    .toolbar-tab-bd {
                        display: inline-block;
                    }
                }
                .fixed-icon {
                    margin-right: 0;
                }

                .category-item {
                    height: 50px;

                    line-height: 50px;
                    color: #fff;
                    padding-left: 64px;
                    position: relative;

                    .icon-small-24 {
                        position: absolute;
                        top: 50%;
                        left: 24px;
                        margin-top: -12px;
                    }
                    &:hover {
                        background-color: #7b7d83;
                    }
                }
            }
            .text{
                color: #fff;
                text-align: center;
            }
        }
        .knowledge {
            height: 205px;
        }
        .show-top {
            height: 245px;
        }
        .top {
            position: absolute;
            bottom: 0;
            left: 0;
            width: 35px;
            height: 40px;
            color: #fff;
            text-align: center;
            cursor: pointer;
            padding-top: 8px;

            &:hover {
                background-color: #ffd64e;
            }
        }
    }
</style>
