<template>
  <div class="company-address">
    <div class="company-address-title">
      <p>{{type}}</p><p><span v-if="changeCompanyAdd" class="edit" @click="changeAdd('rules')">变更信息</span><span v-else class="save" @click="fromSubmit('rules')">保存</span></p>
    </div>
    <div v-if="changeCompanyAdd">
      <ul class="company-top">
        <li>
            <div class="company-left">
              <span><em>*</em> 姓名：</span>
              <div class="company-showtext">{{corpContact.name}}</div>
            </div>
            <div class="company-left">
              <span> 部门：</span>
              <div class="company-showtext">{{corpContact.department}}</div>
            </div>
          </li>
          <li>
            <div class="company-left">
              <span><em>*</em> 职位：</span>
              <div class="company-showtext">{{corpContact.position}}</div>
            </div>
            <div class="company-left">
              <span><em>*</em> 手机号：</span>
              <div class="company-showtext">{{corpContact.mobile}}</div>
            </div>
          </li>
          <li>
            <div class="company-left">
              <span><em>*</em> 邮箱：</span>
              <div class="company-showtext">{{corpContact.email}}</div>
            </div>
            <div class="company-left">
              <span><em>*</em> 省市区：</span>
              <div class="company-showtext">{{corpContact.provCodeDisp}} {{corpContact.cityCodeDisp}} {{corpContact.districtCodeDisp}}</div>
            </div>
          </li>
          <li>
            <div class="company-left">
              <span><em>*</em> 地址：</span>
              <div class="company-showtext">{{corpContact.contactAddr}}</div>
            </div>
          </li>
          <li v-if="qrCode" :class="{'has-img':qrCode && qrCodeUrl}">
            <div class="company-left" v-if="qrCodeUrl">
              <span><em></em> 微信二维码：</span>
              <img :src="qrCodeUrl" class="company-left-qrcode" />
            </div>
            <div class="company-left" v-else >
              <span><em></em> 微信二维码：</span>
              <div class="company-showtext">无</div>
            </div>
          </li>
      </ul>
    </div>
    <el-form ref="form" :model="form" :rules="rules" v-else >
      <ul class="company-add-edit">
        <li>
          <div class="company-add-edit-text">
            <el-form-item label="姓名：" prop="name">
              <el-input v-model="form.name" placeholder=""></el-input>
            </el-form-item>
          </div>
          <div class="company-add-edit-text">
            <el-form-item label="部门：" prop="department">
              <el-input v-model="form.department" placeholder=""></el-input>
            </el-form-item>
          </div>
        </li>
        <li>
          <div class="company-add-edit-text">
            <el-form-item label="职位：" prop="position">
              <el-input v-model="form.position" placeholder=""></el-input>
            </el-form-item>
          </div>
          <div class="company-add-edit-text">
            <el-form-item label="手机号：" prop="mobile">
              <el-input v-model="form.mobile" placeholder=""></el-input>
            </el-form-item>
          </div>
        </li>
        <li>
          <div class="company-add-edit-text">
            <el-form-item label="邮箱：" prop="email">
              <el-autocomplete ref="autocomplete" :fetch-suggestions="querySearch" :trigger-on-focus="false" v-model="form.email" placeholder=""></el-autocomplete>
            </el-form-item>
          </div>
        </li>
      </ul>
      <el-form-item class="shengshiqu" label="省市区：" prop="provCode">
        <Distpicker :address="shengshiqu" @receive="getAddressCode"></Distpicker>
      </el-form-item>
      <ul class="company-add-edit">
        <li>
          <div class="company-add-edit-text">
            <el-form-item label="地址：" prop="contactAddr">
              <el-input v-model="form.contactAddr" placeholder=""></el-input>
            </el-form-item>
          </div>
        </li>
        <li v-if="qrCode ">
          <div class="company-add-edit-text">
            <el-form-item label="微信二维码：">
              <div class="company-attach">
                请上传微信二维码图片 (图片大小不超过500K，jpg或png格式)
              </div>
            </el-form-item>
          </div>
        </li>
        <li v-if="qrCode " class="company-add-edit-attach">
          <el-form-item label="" prop="attachList">
            <div class="info-master-img">
              <div class="img-item" :class="{'has-img':img.previewSrcr}" v-for="(img,index) in imgList" :key="index">
                  <div class="img-item-cover">
                      <div class="img-item-add">
                          <label :for="'masterImg'+index">
                              <i class="el-icon-plus"></i>
                          </label>
                          <img v-if="img.previewSrcr" :src="img.previewSrcr">
                          <input :id="'masterImg'+index" type="file" @change="pushImg($event,index)">
                      </div>
                      <div class="img-item-bottom" v-if="img.previewSrcr">
                          <a @click="clearImg(index)">删除</a>
                          <a @click="reviewImg(index)">预览</a>
                      </div>
                  </div>
                  <el-dialog title="" :visible.sync="img.dialogVisible">
                      <img :src="img.previewSrcr" alt="">
                  </el-dialog>
              </div>
            </div>
          <div class="el-form-item__error">{{imgError}}</div>
          </el-form-item>
        </li>
      </ul>
    </el-form>
  </div>
</template>
<script>
  import Distpicker from "@/components/base/Distpicker";
  import { InterfaceService } from '@/services/api'
  export default {
    components:{
      Distpicker
    },
    data(){
      const emailReg = this.$commonExpression('email')

      var validatePass2 = (rule, value, callback) => {
        if (!emailReg.test(value)) {
          callback(new Error('邮箱格式不正确'));
        } else {
          const mail = value || '',
            mailSuffix = mail.slice(mail.lastIndexOf('.') + 1, mail.length)

          const errorMailSuffix = JSON.parse(this.$getRootLocalStorage('errorMailSuffix') || '[]')
          console.log(mailSuffix, errorMailSuffix, 'errorMailSuffix');
          if (errorMailSuffix.includes(mailSuffix)) {
            callback(new Error('邮箱后缀不正确'));
            return
          }
          callback();
        }
      }

      return {
        changeCompanyAdd:true,
        pcbCode:{},
        nameList:{},
        shengshiqu:{},
        isFirstSubmit:false,
        qrCodeUrl:'',
        imgList: [
            { 'previewSrcr':'','file':'','dialogVisible':false}
        ],
        imgError:'',
        form:{
          name:'',
          department:'',
          position:'',
          mobile:'',
          email:'',
          provCode:'',
          cityCode:'',
          districtCode:'',
          contactAddr:'',
          provCodeDisp:'',
          cityCodeDisp:'',
          districtCodeDisp:'',
          attachList:[]
        },
        rules:{
          name: [
              {
                  required: true,
                  message: "必填"
              },
              { max: 60, message: "姓名不得大于60个字", trigger: "blur" }
          ],
            department: [
                { max: 60, message: "部门不得大于60个字", trigger: "blur" }
            ],
          position: [
              {
                  required: true,
                  message: "必填"
              },
              { max: 60, message: "职位不得大于60个字", trigger: "blur" }
          ],
          mobile: [
              {
                  required: true,
                  message: "必填"
              },
              { pattern: /^\d{11}$/, message: '11位数字' , trigger: "blur"}
          ],
          email: [
              {
                  required: true,
                  message: "必填"
              },
              { validator: validatePass2, trigger: 'blur' },
              { max: 80, message: "邮箱不得大于80个字", trigger: "blur" }
          ],
          provCode: [
              {
                  required: true,
                  message: "必填"
              }
          ],
          contactAddr: [
              {
                  required: true,
                  message: "必填"
              },
              { max: 200, message: "地址不得大于200个字", trigger: "blur" }
          ]
        }
      }
    },
    props:{
        corpContact:{
            type:Object
        },
        type:{
          type:String
        },
        userType:{
          type:String
        },
        corpId:{
          type:String
        },
        qrCode:{
          type:Boolean
        }
    },
    methods:{
      querySearch(queryString, callback) {
        let commonMailbox = this.$commonMailbox()
        let results = this.$clone(commonMailbox)
        let value = ''
        if(queryString && queryString.indexOf('@') != -1){
          value = queryString.substring(0, queryString.indexOf('@'))
        }else{
          value = queryString
        }
        results.forEach((i,index) =>{
            i.value = value + '' + commonMailbox[index].value
        })
        callback(results)
        this.$refs.autocomplete.handleFocus()
      },
      changeAdd(){
        this.changeCompanyAdd = false;
        this.form.name = this.corpContact.name;
        if( this.corpContact.department == '无' ){
          this.form.department = ''
        }else{
          this.form.department = this.corpContact.department;
        }
        this.form.position = this.corpContact.position;
        this.form.mobile = this.corpContact.mobile;
        this.form.email = this.corpContact.email;
        this.form.contactAddr = this.corpContact.contactAddr;
        this.form.provCode = this.corpContact.provCode;
        this.form.provCodeDisp = this.corpContact.provCodeDisp;
        this.form.cityCodeDisp = this.corpContact.cityCodeDisp;
        this.form.districtCodeDisp = this.corpContact.districtCodeDisp;
        this.shengshiqu.provCode = this.corpContact.provCode;
        this.shengshiqu.cityCode = this.corpContact.cityCode;
        this.shengshiqu.blockCode = this.corpContact.districtCode;
      },
      uploadHander(pos,file,dirType,signature,callBack){
        // console.log(pos)
        // console.log(file)
        // console.log(callBack)
        let _this = this;
        //去后端拿签名
        InterfaceService.uploadToOss(signature,file,dirType,pos,callBack)
      },
      fromSubmit(){
        let _this = this;
        let _loadImg = []
        for(var i=0;i<_this.imgList.length;i++){
          let file = _this.imgList[i] &&  _this.imgList[i].file
          if(file){
            _loadImg.push(_this.imgList[i])
          }
        }
        if(_this.isFirstSubmit){//未上传过图片或者上传过但是更换过图片 则直接提交
          //先上传图片
          //去后端拿签名一次性
          if( _loadImg.length == 0 ){
            _this.isLoading = false;
            _this.submit(this.rules)
            return;
          }
          InterfaceService.getOssSignatureDisposable('',{}, (data) => {
            let signature = data
            _this.form['attachList'] = []
            for(var pos =0;pos< _loadImg.length;pos++){
              let file = _loadImg[pos] && _loadImg[pos].file
              if(file){
                  let dirType = 'company/'
                  _this.uploadHander(pos,file,dirType,signature,(pos,file,dirType,signature)=>{
                      //let u = signature.host+'/'+signature.dir+dirType+file.name
                      let u = "#url#" + '/'+signature.dir+dirType+file.name
                      _this.form['attachList'].push({'attachURL':u})
                      //图片上传到oss之后 提交注册信息
                      console.log(u)
                      // console.log(_this.form['attachList'])
                      if(pos >= _loadImg.length-1){
                         setTimeout(() => {
                              _this.submit(this.rules)
                          }, 800)
                      }
                  })
              }
            }
          }, (data) => {
            _this.isLoading = false;
          },
          () => {
              _this.isLoading = true;
          },
          () => {
              //_this.isLoading = false;
          });

        }else{//已经上传过图片 则直接提交
          _this.isLoading = false;
          _this.submit(this.rules)
        }
      },
      submit(rules){
        this.$refs.form.validate( (valid)=>{
          if(valid){
            let params = {};
            //console.log(this.form['attachList'][0])
            if( this.form['attachList'][0] ){
              params.bus_wechartQrCode = this.form['attachList'][0].attachURL
            }else{
              params.bus_wechartQrCode = ''
            }
            params.corpId = this.corpId
            if( this.type == '业务负责人' ){
              params.bus_name = this.form.name;
              params.bus_department = this.form.department;
              params.bus_position = this.form.position;
              params.bus_mobile = this.form.mobile;
              params.bus_email = this.form.email;
              params.bus_contactAddr = this.form.contactAddr;
              params.bus_provCode = this.form.provCode;
              params.bus_cityCode = this.form.cityCode;
              params.bus_districtCode = this.form.districtCode;
            }else{
              params.pic_name = this.form.name;
              params.pic_department = this.form.department;
              params.pic_position = this.form.position;
              params.pic_mobile = this.form.mobile;
              params.pic_email = this.form.email;
              params.pic_contactAddr = this.form.contactAddr;
              params.pic_provCode = this.form.provCode;
              params.pic_cityCode = this.form.cityCode;
              params.pic_districtCode = this.form.districtCode;
            }

            //这里发送请求给后端
            if( this.userType == 'vendor' ){
              InterfaceService.updataVendorMessage(params, (data)=>{
                //下面是请求成功后走的回调函数
                this.changeCompanyAdd = true;
                this.corpContact.provCodeDisp = this.nameList.provinceName || this.form.provCodeDisp
                this.corpContact.cityCodeDisp = this.nameList.cityName || this.form.cityCodeDisp
                this.corpContact.districtCodeDisp = this.nameList.blockName || this.form.districtCodeDisp
                this.corpContact.name = this.form.name;
                this.corpContact.department = this.form.department || '无'
                this.corpContact.position = this.form.position;
                this.corpContact.mobile = this.form.mobile
                this.corpContact.email = this.form.email
                this.corpContact.contactAddr = this.form.contactAddr
                if( this.isFirstSubmit ){
                  this.qrCodeUrl = this.imgList[0].previewSrcr;
                }
                this.isFirstSubmit = false
              },(data)=>{

              },()=>{
                this.isLoading = true
              },()=>{
                this.isLoading = false
              })
            }else{
              InterfaceService.updataPurchaserMessage(params, (data)=>{
                //下面是请求成功后走的回调函数
                this.changeCompanyAdd = true;
                this.corpContact.provCodeDisp = this.nameList.provinceName || this.form.provCodeDisp
                this.corpContact.cityCodeDisp = this.nameList.cityName || this.form.cityCodeDisp
                this.corpContact.districtCodeDisp = this.nameList.blockName || this.form.districtCodeDisp
                this.corpContact.name = this.form.name;
                this.corpContact.department = this.form.department || '无'
                this.corpContact.position = this.form.position;
                this.corpContact.mobile = this.form.mobile
                this.corpContact.email = this.form.email
                this.corpContact.contactAddr = this.form.contactAddr
                if( this.isFirstSubmit ){
                  this.qrCodeUrl = this.imgList[0].previewSrcr;
                }
                this.isFirstSubmit = false
              },(data)=>{

              },()=>{
                this.isLoading = true
              },()=>{
                this.isLoading = false
              })
            }
          }else{

          }
        } )
      },
      getAddressCode(res,list){
        if( res ){
          this.pcbCode = res;
          this.corpContact.provCode = this.form.provCode = this.pcbCode.provinceCode
          this.corpContact.cityCode = this.form.cityCode = this.pcbCode.cityCode
          this.corpContact.districtCode = this.form.districtCode = this.pcbCode.blockCode
          this.nameList = list;
        }
      },
      pushImg(event,index){//input控件（自定义）获取文件 上传
        let _this = this;
        _this.isFirstSubmit = true;//更改过图片 则视为第一次提交（需要上传图片)
        let file = event.target.files[0]
        console.log('1')
        if(file){
          let checkTextList = JSON.parse(sessionStorage.getItem('checkTextList') || '[]');
          let onOff = false;
          let forbidText = ''
          checkTextList.forEach(i=>{
            if (i != '' && file.name.indexOf(i) != -1) {
              onOff = true
              forbidText = i
            }
          });
          if (onOff) {
            this.$message.error('文件名包含特殊字符【'+forbidText+'】,请修改文件名后再上传')
            return false
          }
          _this.imgError = ''
          // 判断是否图片
          if((file.type).indexOf("image/")==-1){
            _this.imgError = '请选择图片!'
            return false
          }

          let fSize = Math.round(file.size/1024*100)/100;//取得图片文件的大小
          if(fSize >= 1024){//单位为KB
              _this.imgError = '照片最大尺寸为1024KB，请重新上传!'
              return false
          }

          for(var i in  _this.imgList){
              // name: "building.png"
              // size: 2731
              // type: "image/png"
              let cImg = _this.imgList[i] &&  _this.imgList[i].file
              //console.log(cImg)
              if(cImg){
                  if(file.name == cImg.name && file.size == cImg.size && file.type == cImg.type){
                      _this.imgError = '图片已经存在，请重新选择!'
                      return false
                  }
              }
          }

          let reader  = new FileReader();
          reader.onloadend = function () {
              _this.imgList[index].previewSrcr = reader.result
              _this.imgList[index].file = file
              _this.form['attachList'].push({'attachURL':file})

              _this.$forceUpdate();
              _this.$set(_this.imgList,_this.imgList);
          }

          if (file) {
            reader.readAsDataURL(file);
          } else {
              _this.previewSrcr = "";
          }
        }else{
          _this.imgError = '图片获取错误'
        }
      },
      clearImg(index){
          this.isFirstSubmit = true;//更改过图片 则视为第一次提交（需要上传图片)
          this.imgList[index] = {'previewSrcr':'','file':'','dialogVisible':false}
          this.$forceUpdate();
          this.$set(this.imgList,this.imgList);
          //清空input[file]
          let file = document.getElementById("masterImg"+index)
          file.value = "";
      },
      reviewImg(index){
        this.imgList[index].dialogVisible = true
      }
    },
    mounted(){
      let self = this
      setTimeout(()=>{
        self.qrCodeUrl = self.corpContact.wechartQrCode
        console.log(self.corpContact.wechartQrCode)
        self.imgList[0].previewSrcr = self.corpContact.wechartQrCode
      },400)

    }
  }
</script>

<style lang="scss" scoped>

.company-address-title p{
    display: inline-block;
    height: 43px;
    line-height: 43px;
  }

.company-address-title p:first-child{
  width: 95px;
  font-size: 14px;
  color: #333333;
  text-align: center;
  border-bottom: 3px solid #4f525a;
}

.company-address-title p:last-child{
    width: 853px;
    font-size: 12px;
    color: #373737;
    text-align: center;
    border-bottom: 3px solid #ffd64e;
    height: 42px;
    text-align: right;
    padding-right: 20px;
  }

.company-address-title p span{
    display: inline-block;
    height: 24px;
    padding-right: 12px;
    border: 1px solid #4f525a;
    line-height:24px;
    text-align: left;
    padding-left: 30px;
    cursor: pointer;
}

.company-address-title p span.edit{
  background: url(../../assets/images/purchaser/edit_icon.png) no-repeat;
  background-position: 10px center;
}

.company-address-title p span.save{
  background: url(../../assets/images/purchaser/save_icon.png) no-repeat;
  background-position: 10px center;
}

.company-top{
    margin-top: 13px;
    font-size: 12px;
  }
  .company-top li{
    height: 26px;
    line-height: 26px;
  }
  .company-top li.changeInfo{
    height: 48px;
    line-height: 48px;
  }
  .company-top li .company-left{
    display: inline-block;
    width: 49%;
    height: 26px;
    line-height: 26px;
  }
  .company-top li .company-left span{
    display: inline-block;
    width: 172px;
    height: 26px;
    line-height: 26px;
    text-align: right;
    color: #888;
    vertical-align: top;
  }
  .company-top li .company-left span em{
    color: #e93340;
  }
  .company-top li .company-showtext{
    width: 270px;
    display: inline-block;
  }
  .company-information .el-input{
  width: 270px;
  height: 26px;
  }
  .canNotEdit /deep/ .el-input__inner{
  height: 32px;
  line-height: 32px;
  border: 1px solid #dddddd;
  }
  .el-input.is-disabled.canNotEdit /deep/ .el-input__inner{
  height: 26px;
  line-height: 26px;
  background: white;
  color: #333333;
  cursor: unset;
  border: 1px solid #ffffff;
  padding: 0;
  }
  .company-images{
  margin:13px 0 14px;
  overflow: hidden;
  }
  .company-images li{
  width: 178px;
  height: 178px;
  border: 1px solid #dddddd;
  float: left;
  margin-left: 29px;
  }
  .company-images li img{
  width: 100%;
  }
  .company-address,.contact-data{
  margin-top: 13px;
  }


.company-address-title{
  margin-bottom: 14px;
}
.company-add-edit li{
  line-height: 48px;
  height: 48px;
  width: 100%;
}
.company-add-edit-text{
  display: inline-block;
  width: 49%;
}
.company-add-edit-text /deep/ .el-form-item__label{
  width: 172px;
  padding: 0;
  font-size: 12px;
  color: #888888;
  line-height: 48px;
}
.company-add-edit-text /deep/ .el-input{
  height: 32px;
  position: relative;
}
.company-add-edit-text /deep/ .el-form-item__content{
  line-height: 48px;
  margin-left: 172px;
}
.company-add-edit-text /deep/ .el-input__inner{
   height: 32px;
   line-height:32px;
}
.company-add-edit-text /deep/ .el-form-item__error{
  top: 38px;
}
.el-form-item.shengshiqu{
  height: 48px;
  line-height: 48px;
  margin-bottom: 0;
}
.el-form-item.shengshiqu /deep/ .el-form-item__label{
  line-height: 48px;
  font-size: 12px;
  color: #888888;
  width: 172px;
  padding: 0;
}
.el-form-item.shengshiqu /deep/ .el-form-item__content{
  line-height: 48px;
  margin-left: 172px;
}
.el-form-item.shengshiqu /deep/ .el-form-item__content .el-input{
  width: 198px;
  // height: 32px;
}
.el-form-item.shengshiqu .linkage /deep/ .el-select{
  width: 27%;
}
.el-form-item.shengshiqu /deep/ .el-form-item__content .el-input__inner{
  height: 32px;
  line-height: 32px;
}
.el-form-item.shengshiqu /deep/ .el-form-item__error{
  top: 82%;
}
.company-left-qrcode{
  display: inline-block;
  width:120px;
  height: auto;
  vertical-align:text-top;
}
.company-top li.has-img{
  height:138px;
}
.company-attach{
  width:700px;
}
.company-add-edit li.company-add-edit-attach{
  height:120px;
  line-height:initial;
  padding-left:172px
}
.info-master-img {
    .img-item {
        position: relative;
        display: inline-block;
        width: 120px;
        height: 120px;
        vertical-align: middle;
        margin-right: 20px;
        border: 1px dashed #ccc;
        border-radius: 2px;
    }

    .img-item-add {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        font-size: 30px;
        text-align: center;
        color: #ccc;
        position: relative;
        overflow: hidden;

        i {
            cursor: pointer;
        }

        input[type="file"] {
            display: none;
        }
        img{
            position:absolute;
            top:0;
            left:0;
            width:100%;
            pointer-events:none;
            height:auto;
        }
    }

    .img-item-cover {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(255, 255, 255, 0);

        .img-item-top,
        .img-item-bottom {
            display: none;
            position: absolute;
            width: 100%;
            padding: 10px;
            text-align: center;
            background: rgba(167, 166, 166, 0.2);
        }

        .img-item-top {
            top: 0;
        }

        .img-item-bottom {
            bottom: 0;
            padding: 0 10px;

            a {
                display: inline-block;
                width: 48%;
                padding: 10px 5px;
                vertical-align: middle;
                color: rgb(88, 167, 231);
            }
        }
    }

    .img-item:hover {
        .img-item-cover {
            background: rgba(255, 255, 255, 0.2);
        }

        .img-item-top,
        .img-item-bottom {
            display: block;
        }
    }

    img {
        width: 100%;
        height: 100%;
        border: none;
    }

    .img-item.has-img {
        border: none;

        .img-item-add {
            // display: none;
        }

        &:hover .img-item-add {
            display: flex;
        }
    }
}
</style>