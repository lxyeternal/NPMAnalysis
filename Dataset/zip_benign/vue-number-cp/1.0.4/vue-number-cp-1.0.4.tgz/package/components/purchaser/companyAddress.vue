<template>
  <div class="company-address">
    <div class="order-info-title">
      公司地址
      <span style="padding-left: 10px;" v-if="isAlter" class="blue hand f12" @click="handleChange">变更信息</span>
    </div>
    <div v-if="changeCompanyAdd">
      <ul class="company-top">
        <li class="clearfloat">
          <div class="company-left" style="width: 100%;">
            <span>工商注册地址：</span>
            <div class="company-showtext" v-html="region('reg')"></div>
          </div>
        </li>
        <li class="clearfloat">
          <div class="company-left" style="width: 100%;">
            <span>办公地址：</span>
            <div class="company-showtext" v-html="region('office')"></div>
          </div>
        </li>
        <li class="clearfloat">
          <div class="company-left">
            <span>邮编：</span>
            <div class="company-showtext">{{corpAddrInfo.officeZipCode}}</div>
          </div>
          <div class="company-left">
            <span>电话号码：</span>
            <div class="company-showtext">{{corpAddrInfo.officeTelNumber}}</div>
          </div>
        </li>
        <li class="clearfloat">
          <div class="company-left">
            <span> 传真号码：</span>
            <div class="company-showtext">{{corpAddrInfo.officeFaxNumber}}</div>
          </div>
        </li>
      </ul>
    </div>
    <el-form ref="form" :model="form" :rules="rules" v-else >
      <el-form-item class="shengshiqu" label="省市区：" prop="provCode">
        <Distpicker :address="shengshiqu" @receive="getAddressCode"></Distpicker>
      </el-form-item>
      <ul class="company-add-edit">
        <li>
          <div class="company-add-edit-text">
            <el-form-item label="办公地址：" prop="corpAddr">
              <el-input v-model="form.corpAddr" placeholder=""></el-input>
            </el-form-item>
          </div>
          <div class="company-add-edit-text">
            <el-form-item label="邮编：" prop="zipCode">
              <el-input v-model="form.zipCode" placeholder=""></el-input>
            </el-form-item>
          </div>
        </li>
        <li>
          <div class="company-add-edit-text">
            <el-form-item label="电话区号：" prop="telAreaCode">
              <el-input v-model="form.telAreaCode" placeholder=""></el-input>
            </el-form-item>
          </div>
          <div class="company-add-edit-text">
            <el-form-item label="电话号码：" prop="telNumber">
              <el-input v-model="form.telNumber" placeholder=""></el-input>
            </el-form-item>
          </div>
        </li>
        <li>
          <div class="company-add-edit-text">
            <el-form-item label="传真区号：" prop="faxAreaCode">
              <el-input v-model="form.faxAreaCode" placeholder=""></el-input>
            </el-form-item>
          </div>
          <div class="company-add-edit-text">
            <el-form-item label="传真号码：" prop="faxNumber">
              <el-input v-model="form.faxNumber" placeholder=""></el-input>
            </el-form-item>
          </div>
        </li>
      </ul>
    </el-form>
  </div>
</template>
<script>
  import Distpicker from "@/components/base/Distpicker";
  import { InterfaceService } from '@/services/api'
  export default {
    components:{
      Distpicker
    },
    data(){
      return {
        changeCompanyAdd:true,
        pcbCode:{},
        nameList:{},
        shengshiqu:{},
        form:{
          provCode:'',
          cityCode:'',
          districtCode:'',
          provCodeDisp:'',
          cityCodeDisp:'',
          districtCodeDisp:'',
          corpAddr:'',
          zipCode:'',
          telAreaCode:'',
          telNumber:'',
          faxAreaCode:'',
          faxNumber:''
        },
        rules:{
          provCode: [
              {
                  required: true,
                  message: "必填"
              }
          ],
          corpAddr: [
              {
                  required: true,
                  message: "必填"
              },
              { max: 200, message: "公司地址不得大于200个字", trigger: "blur" }
          ],
          zipCode: [
              {
                  required: true,
                  message: "必填"
              },
              { pattern: /^\d{6}$/, message: '6位数字' , trigger: "blur"}
          ],
          telAreaCode: [
              {
                  required: true,
                  message: "必填"
              },
              { pattern: /^\d{3,4}$/, message: '3-4位数字' , trigger: "blur"}
          ],
          telNumber: [
              {
                  required: true,
                  message: "必填"
              },
              { pattern: /^\d{7,8}$/, message: '7-8位数字' , trigger: "blur"}
          ],
          faxAreaCode:[
            { pattern: /^\d{3,4}$/, message: '请输入正确的传真区号' , trigger: "blur"}
          ],
          faxNumber:[
            { pattern:  /^[0-9\-]{0,32}$/, message: '请输入正确的传真号码' , trigger: "blur"}
          ]
        }
      }
    },
    props:{
        corpAddrInfo:{
          type:Object
        },
        userType:{
          type:String
        },
        isReview:{
          type:Boolean
        },
        isAlter:{
          type:Boolean
        }
    },
    computed:{
      region(){
        return function (type) {
          if (type == 'reg') {
            return `${this.corpAddrInfo.regProvCodeDisp || ""}&nbsp;&nbsp;${this.corpAddrInfo.regCityCodeDisp || ""}&nbsp;&nbsp;${this.corpAddrInfo.regDistrictCodeDisp || ''}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;${this.corpAddrInfo.regDetailAddr || ""}`
          } else {
            return `${this.corpAddrInfo.officeProvCodeDisp || ""}&nbsp;&nbsp;${this.corpAddrInfo.officeCityCodeDisp || ""}&nbsp;&nbsp;${this.corpAddrInfo.officeDistrictCodeDisp || ''}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;${this.corpAddrInfo.officeDetailAddr || ""}`
          }
        }
      }
    },
    methods:{
      handleChange() {
        if(this.isReview){
          this.$message.error('您没有变更信息的权限，请联系管理员！')
        }else{
          this.$emit("changeAddr",true)
        }
      },
      changeAdd(){
        this.changeCompanyAdd = false;
        this.form.corpAddr = this.corpAddrInfo.corpAddr;
        this.form.zipCode = this.corpAddrInfo.zipCode;
        this.form.telAreaCode = this.corpAddrInfo.telAreaCode;
        this.form.telNumber = this.corpAddrInfo.telNumber;
        if( this.corpAddrInfo.faxAreaCode == '无' ){
          this.form.faxAreaCode = ''
        }else{
          this.form.faxAreaCode = this.corpAddrInfo.faxAreaCode;
        }
        if( this.corpAddrInfo.faxNumber == '无' ){
          this.form.faxNumber = ''
        }else{
          this.form.faxNumber = this.corpAddrInfo.faxNumber;
        }
        this.form.provCode = this.corpAddrInfo.provCode;
        this.form.cityCode = this.corpAddrInfo.cityCode;
        this.form.districtCode = this.corpAddrInfo.districtCode;
        this.form.provCodeDisp = this.corpAddrInfo.provCodeDisp;
        this.form.cityCodeDisp = this.corpAddrInfo.cityCodeDisp;
        this.form.districtCodeDisp = this.corpAddrInfo.districtCodeDisp;
        this.shengshiqu.provCode = this.corpAddrInfo.provCode;
        this.shengshiqu.cityCode = this.corpAddrInfo.cityCode;
        this.shengshiqu.blockCode = this.corpAddrInfo.districtCode;
      },
      submit(rules){
        this.$refs.form.validate( (valid)=>{
          if(valid){
            let params = {};
            params.provCode = this.form.provCode;
            params.cityCode = this.form.cityCode;
            params.districtCode = this.form.districtCode;
            params.corpAddr = this.form.corpAddr;
            params.zipCode = this.form.zipCode;
            params.telAreaCode = this.form.telAreaCode;
            params.telNumber = this.form.telNumber;
            params.faxAreaCode = this.form.faxAreaCode;
            params.faxNumber = this.form.faxNumber;
            params.corpId = this.corpAddrInfo.corpId
            //这里发送请求给后端
            if( this.userType == 'vendor' ){
              InterfaceService.updataVendorMessage(params, (data)=>{
                //下面是请求成功后走的回调函数
                this.changeCompanyAdd = true;
                this.corpAddrInfo.provCodeDisp = this.nameList.provinceName || this.form.provCodeDisp
                this.corpAddrInfo.cityCodeDisp = this.nameList.cityName || this.form.cityCodeDisp
                this.corpAddrInfo.districtCodeDisp = this.nameList.blockName || this.form.districtCodeDisp
                this.corpAddrInfo.zipCode = this.form.zipCode;
                this.corpAddrInfo.corpAddr = this.form.corpAddr
                this.corpAddrInfo.telAreaCode = this.form.telAreaCode;
                this.corpAddrInfo.telNumber = this.form.telNumber
                this.corpAddrInfo.faxAreaCode = this.form.faxAreaCode || '无'
                this.corpAddrInfo.faxNumber = this.form.faxNumber || '无'
                this.corpAddrInfo.provCode = this.form.provCode
                this.corpAddrInfo.cityCode = this.form.cityCode
                this.corpAddrInfo.districtCode = this.form.districtCode
              },(data)=>{

              },()=>{
                this.isLoading = true
              },()=>{
                this.isLoading = false
              })
            }else{
              InterfaceService.updataPurchaserMessage(params, (data)=>{
                //下面是请求成功后走的回调函数
                this.changeCompanyAdd = true;
                this.corpAddrInfo.provCodeDisp = this.nameList.provinceName || this.form.provCodeDisp
                this.corpAddrInfo.cityCodeDisp = this.nameList.cityName || this.form.cityCodeDisp
                this.corpAddrInfo.districtCodeDisp = this.nameList.blockName || this.form.districtCodeDisp
                this.corpAddrInfo.zipCode = this.form.zipCode;
                this.corpAddrInfo.corpAddr = this.form.corpAddr
                this.corpAddrInfo.telAreaCode = this.form.telAreaCode;
                this.corpAddrInfo.telNumber = this.form.telNumber
                this.corpAddrInfo.faxAreaCode = this.form.faxAreaCode || '无'
                this.corpAddrInfo.faxNumber = this.form.faxNumber || '无'
                this.corpAddrInfo.provCode = this.form.provCode
                this.corpAddrInfo.cityCode = this.form.cityCode
                this.corpAddrInfo.districtCode = this.form.districtCode
              },(data)=>{

              },()=>{
                this.isLoading = true
              },()=>{
                this.isLoading = false
              })
            }
          }else{

          }
        } )
      },
      getAddressCode(res,list){
        this.pcbCode = res;
        this.form.provCode = this.pcbCode.provinceCode
        this.form.cityCode = this.pcbCode.cityCode
        this.form.districtCode = this.pcbCode.blockCode
        this.nameList = list;
      }
    }
  }
</script>

<style lang="scss" scoped>
.order-info-title{
  .f12{
    line-height: 12px;
  }
}
.company-address-title p{
    display: inline-block;
    height: 43px;
    line-height: 43px;
  }

.company-address-title p:first-child{
  width: 95px;
  font-size: 14px;
  color: #333333;
  text-align: center;
  border-bottom: 3px solid #4f525a;
}

.company-address-title p:last-child{
    width: 853px;
    font-size: 12px;
    color: #373737;
    text-align: center;
    border-bottom: 3px solid #ffd64e;
    height: 42px;
    text-align: right;
    padding-right: 20px;
  }

.company-address-title p span{
    display: inline-block;
    height: 24px;
    padding-right: 12px;
    border: 1px solid #4f525a;
    line-height:24px;
    text-align: left;
    padding-left: 30px;
    cursor: pointer;
}

.company-address-title p span.edit{
  background: url(../../assets/images/purchaser/edit_icon.png) no-repeat;
  background-position: 10px center;
}

.company-address-title p span.save{
  background: url(../../assets/images/purchaser/save_icon.png) no-repeat;
  background-position: 10px center;
}

.company-top{
    margin-top: 13px;
    font-size: 12px;
  }
  .company-top li{
    line-height: 26px;
  }
  .company-top li.changeInfo{
    height: 48px;
    line-height: 48px;
  }
  .company-top li .company-left{
    float: left;
    display: inline-block;
    width: 49%;
    line-height: 26px;
  }
  .company-top li .company-left span{
    display: inline-block;
    height: 26px;
    line-height: 26px;
    text-align: right;
    color: #888;
    vertical-align: top;
  }
  .company-top li .company-left span em{
    color: #e93340;
  }
  .company-top li .company-showtext{
    display: inline-block;
    width: auto;
  }
  .company-information .el-input{
  width: 270px;
  height: 26px;
  }
  .canNotEdit /deep/ .el-input__inner{
  height: 32px;
  line-height: 32px;
  border: 1px solid #dddddd;
  }
  .el-input.is-disabled.canNotEdit /deep/ .el-input__inner{
  height: 26px;
  line-height: 26px;
  background: white;
  color: #333333;
  cursor: unset;
  border: 1px solid #ffffff;
  padding: 0;
  }
  .company-images{
  margin:13px 0 14px;
  overflow: hidden;
  }
  .company-images li{
  width: 178px;
  height: 178px;
  border: 1px solid #dddddd;
  float: left;
  margin-left: 29px;
  }
  .company-images li img{
  width: 100%;
  }
  .company-address,.contact-data{
  margin-top: 13px;
  }



.company-address-title{
  margin-bottom: 14px;
}
.company-add-edit li{
  line-height: 48px;
  height: 48px;
  width: 100%;
}
.company-add-edit-text{
  display: inline-block;
  width: 49%;
}
.company-add-edit-text /deep/ .el-form-item__label{
  width: 172px;
  padding: 0;
  font-size: 12px;
  color: #888888;
  line-height: 48px;
}
.company-add-edit-text /deep/ .el-input{
  height: 32px;
  position: relative;
}
.company-add-edit-text /deep/ .el-form-item__content{
  line-height: 48px;
  margin-left: 172px;
}
.company-add-edit-text /deep/ .el-input__inner{
   height: 32px;
   line-height: 32px;
}
.company-add-edit-text /deep/ .el-form-item__error{
  top: 82%;
}
.el-form-item.shengshiqu{
  height: 48px;
  line-height: 48px;
  margin-bottom: 0;
}
.el-form-item.shengshiqu /deep/ .el-form-item__label{
  line-height: 48px;
  font-size: 12px;
  color: #888888;
  width: 172px;
  padding: 0;
}
.el-form-item.shengshiqu /deep/ .el-form-item__content{
  line-height: 48px;
  margin-left: 172px;
}
.el-form-item.shengshiqu /deep/ .el-form-item__content .el-input{
  width: 198px;
  // height: 32px;
}
.el-form-item.shengshiqu .linkage /deep/ .el-select{
  width: 27%;
}
.el-form-item.shengshiqu /deep/ .el-form-item__content .el-input__inner{
  height: 32px;
  line-height: 32px;
}
.el-form-item.shengshiqu /deep/ .el-form-item__error{
  top: 82%;
}
</style>