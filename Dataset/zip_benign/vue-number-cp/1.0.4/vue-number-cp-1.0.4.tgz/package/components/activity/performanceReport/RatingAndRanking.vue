<template>
  <div class="container">
    <div class="head-title">
      <p><i></i>{{data.itemName | nullValueConversion}}</p>
      <span>(共有{{data.providerCount | nullValueConversion}}家供应商参与排名)</span>
    </div>
    <div :gutter="20" class="bace-info-container row-center">
      <div class="col-center">
        <span>专业综合评分</span>
        <p>{{data.totalScore | nullValueConversion}}</p>
      </div>
      <div class="border-right-linear"></div>
      <div class="col-center">
        <span>专业综合排名</span>
        <p>No.{{data.totalNo | nullValueConversion}}</p>
      </div>
      <div class="col-center">
        <span>成本</span>
        <p>No.{{data.costNo | nullValueConversion}}</p>
      </div>
      <div class="col-center">
        <span>质量</span>
        <p>No.{{data.qualityNo | nullValueConversion}}</p>
      </div>
      <div class="col-center">
        <span>工期</span>
        <p>No.{{data.timeNo | nullValueConversion}}</p>
      </div>
      <div class="col-center">
        <span>设计还原度</span>
        <p>No.{{data.designNo | nullValueConversion}}</p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    data: {
      tyep: [],
      default() { return [] }
    }
  }
}
</script>
<style lang="scss" scoped>
.container {
  margin-top: 50px;
  font-size: 18px;
  color: #666;
  background: #fff;
  .head-title {
    margin-top: 50px;
    color: #333;
    position: relative;
    p {
      font-size: 32px;
      margin-bottom: 4px;
      padding-top: 20px;
      position: relative;
      i {
        position: absolute;
        width: 60px;
        height: 4px;
        background: #333;
        top: 0px;
        left: 50%;
        transform: translateX(-50%);
      }
    }
    span {
      font-size: 16px;
      color: #a9a9a9;
    }
  }
  .row-center {
    margin-top: 50px;
    .border-right-linear {
      width: 1px;
      height: 140px;
      background: #ddd;
      display: inline-block;
    }
    .col-center {
      display: inline-block;
      margin-top: 40px;
      width: 15%;
      &:first-child {
        width: 20%;
        margin-top: 0;
        p {
          font-size: 110px;
        }
      }
      &:nth-child(2) {
        p {
          font-size: 40px;
        }
      }
      span {
        font-size: 25px;
      }
      p {
        font-size: 30px;
        margin-top: 20px;
        font-family: cursive;
        color: #333;
      }
    }
  }
}
</style>


