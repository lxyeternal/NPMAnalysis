<template>
  <div class="container">
    <div class="head">
      <s></s>
      <s></s>
      <i class="pr-icon"></i>
      <p>
        合同项目: {{data.projectName | nullValueConversion}}
        <s></s>
      </p>
    </div>
    <!-- .filter((f, fIdx) => fIdx < 8) -->
    <ul class="body" v-for="(item, idx) in data.contractList" :key="idx">
      <li>{{item.contractName | nullValueConversion}}</li>
      <li>
        <!-- <span>实际承包人: 史蒂夫戴永明有限公司</span> -->
        <span>合同状态: {{item.contractStatus | nullValueConversion}}</span>
      </li>
      <li>
        <div class="row-center">
          <div>
            <p class="title mb0">综合评分</p>
            <span class="fs106">{{item.totalScore | nullValueConversion}}</span>
          </div>
          <div>
            <p class="title">成本</p>
            <span>{{item.costScore | nullValueConversion}}</span>
          </div>
          <div class="border-right-dashede"></div>
          <div>
            <p class="title">质量</p>
            <span>{{item.qualityScore | nullValueConversion}}</span>
          </div>
          <div class="border-right-dashede"></div>
          <div>
            <p class="title">工期</p>
            <span>{{item.timeScore | nullValueConversion}}</span>
          </div>
          <div class="border-right-dashede"></div>
          <div>
            <p class="title">设计还原度</p>
            <span>{{item.designScore | nullValueConversion}}</span>
          </div>
        </div>
      </li>
      <div class="body-border-bottom"></div>
    </ul>
  </div>
</template>
<script>
export default {
  props: {
    data: {
      tyep: [],
      default() { return [] }
    }
  }
}
</script>
<style lang="scss" scoped>
.container {
  margin-top: 20px;
  font-size: 18px;
  color: #666;
  background: #fff;
  text-align: left;
  .mb0 {
    margin-bottom: 0 !important;
  }
  .pr-icon {
    width: 50px;
    height: 50px;
    display: inline-block;
    background-image: url(../../../assets/images/activity/performanceReport/performance_report_icon.png);
    background-repeat: no-repeat;
    background-position: -85px -125px;
    background-size: 1300%;
    vertical-align: middle;
  }
  .head {
    height: 70px;
    line-height: 70px;
    position: relative;
    text-align: left;
    i {
      display: inline-block;
    }
    p {
      display: inline-block;
      margin-left: -50px;
      padding: 0 40px 0 60px;
      position: absolute;
      line-height: 60px;
      margin-top: 6px;
      position: relative;
      s {
        position: absolute;
        height: 4px;
        left: -5px;
        right: 0;
        background: #4f525b;
        bottom: -4px;
      }
    }
    & > s {
      position: absolute;
      bottom: 0;
      left: 0;
      height: 4px;
      &:nth-child(1) {
        background: #ffd64f;
        width: 100%;
      }
      // &:nth-child(2) {
      //   // background: #4f525b;
      //   // width: 340px;
      // }
    }
  }

  .body {
    .body-border-bottom {
      width: 100%;
      height: 2px;
      background-color: #ffd64f;
      margin-top: 30px;
    }
    li {
      padding: 0 30px;
      text-align: left;
      margin-top: 20px;
      &:first-child {
        font-size: 22px;
        color: #333;
      }

      .row-center {
        text-align: center;
        margin-top: 32px;
        overflow: hidden;
        .border-right-dashede {
          width: 3px;
          height: 60px;
          background-image: url(../../../assets/images/activity/performanceReport/performance_report_icon.png);
          background-repeat: no-repeat;
          background-position: -34px -909px;
          float: left;
        }

        div {
          margin-top: 34px;
          width: 17%;
          float: left;
          &:first-child {
            margin-top: 0;
            width: 25%;
            border-right: 0;
          }
          &:last-child {
            border-right: 0;
          }
        }
        p {
          margin-bottom: 14px;
        }
        span {
          font-size: 40px;
          color: #333;
          font-family: cursive;
          &.fs106 {
            font-size: 106px;
          }
        }
      }
    }
  }
}
</style>


