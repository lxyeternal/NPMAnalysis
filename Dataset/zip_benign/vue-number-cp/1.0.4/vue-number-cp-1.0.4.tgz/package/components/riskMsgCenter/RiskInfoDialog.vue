<template>
  <div class="riskInfo" :class="activeType==1||activeType==3?'cau':''">
      <el-dialog
        title="提示"
        :visible.sync="openRiskInfoFlag"
        width= "860px"
        center
        @close="dailogClosed">
            <template slot="title" >
                <div  v-if="activeType==1" class="header">{{providerName}}<div class="atten">合制风险警示</div></div>
                <div  v-if="activeType==2" class="r-header">提示</div>
                <div  v-if="activeType==3" class="n-header">{{providerName}}</div>
                <div  v-if="activeType==4" class="n-header">详情</div>
            </template>
            <div class="caution" v-if="activeType==1">
                <div v-show="!isLoading && typeList.length>0">
                    <div class="upTime">更新时间：{{upTime}}</div>
                    <div class="mid">
                        <el-collapse v-model="activeName" accordion  @change="handleChange">
                            <div class="p-type" v-for="(itm,typeli_idx) in typeList" :key="typeli_idx" v-if="itm.riskInfoDataList && itm.riskInfoDataList.length!=0">
                                    <div class="riskType"><i class="shu"></i>{{itm.name}}</div>
                                    <el-collapse-item   :name="itm.type+'_'+item1.id" v-for="(item1,rInfo_idx) in itm.riskInfoDataList" :key="rInfo_idx" class="r-parent">
                                        <template slot="title">
                                             <div class="t-name"><span class="t-compeny">该公司</span>{{item1.title}}<span class="t-num">({{item1.riskCount}})</span></div>
                                        </template>
                                        <RiskInfoCommonTable  :riskType="riskType" :riskDetailChildList="riskDetailChildList"></RiskInfoCommonTable>
                                        <div class="empty-data"  v-show="!riskDetailChildList || riskDetailChildList.length==0">{{emptyShowName}}</div>
                                        <el-pagination v-if="riskDetailChildList && riskDetailChildList.length>0"  @current-change="handleChangePageFuc" :current-page="riskDetailPageIndex" :page-size="10" :total="riskDetailCounts" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                                        </el-pagination>
                                    </el-collapse-item>
                            </div>
                        </el-collapse>
                    </div>
                </div>
                <div class="empty" v-show="!isLoading && typeList.length==0">
                    未检索到相关数据
                </div>
            </div>
            <!-- <div class="caution empty" v-if=" activeType==1 && typeList.length==0">未检索到相关数据</div> -->
            <div class="reminder" v-if="activeType==2">
                <div class="hdr">该公司经营状态为 <span>清算</span> , 并有<span>1条严重违法信息</span>，2条<span>失信信息</span>，已被绿地香港列为<span>黑名单供应商</span>。</div>
                <div class="r-contain">
                       <div class="r-li" v-for="(item2,index2) in 5" :key="index2">
                            <div class="r-title">严重违法 <span>(1)</span></div>
                            <table>
                                <tr class="tr-name">
                                    <td>序号</td>
                                    <td>日期</td>
                                    <td>裁判文书</td>
                                    <td>案由</td>
                                    <td>案件身份</td>
                                    <td>案号</td>
                                </tr>
                                <tr class="tr-contain">
                                    <td class="wtd10">1</td>
                                    <td class="wtd10">2019-03-03</td>
                                    <td class="wtd40">华为技术转发然的纳斯独家设计的基金奥斯迪捷爱士接地极阿斯顿基金奥斯迪捷爱士接地极阿斯的架势</td>
                                    <td class="wtd10">专利侵权</td>
                                    <td class="wtd15">-</td>
                                    <td class="wtd15">嘿嘿1111111111</td>  
                                </tr>
                            </table>
                        </div>
                </div>
                <div class="ifDo">您是否继续操作？</div>
                <div class="btns">
                    <div class="left">
                        <span>确定</span>
                    </div>
                    <div class="right">
                        <span @click="closeDialog">取消</span>
                    </div>
                </div>
            </div>
            <!-- 详情页的普通弹层 -->
            <div class="normal" v-if="activeType==3">
                 <table>
                        <tr>
                            <td class="c-name">工商注册号</td>
                            <td class="c-value"  v-if="infoBean.regNumber">{{infoBean.regNumber}}</td>
                            <td class="c-value"  v-if="!infoBean.regNumber">-</td>
                            <td class="c-name">组织机构代码</td>
                            <td class="c-value"  v-if="infoBean.orgNumber">{{infoBean.orgNumber}}</td>
                            <td class="c-value"  v-if="!infoBean.orgNumber">-</td>
                        </tr>
                        <tr>
                            <td class="c-name">统一社会信用代码</td>
                            <td class="c-value"  v-if="infoBean.creditCode">{{infoBean.creditCode}}</td>
                            <td class="c-value"  v-if="!infoBean.creditCode">-</td>
                            <td class="c-name">公司类型</td>
                            <td class="c-value"  v-if="infoBean.companyOrgType">{{infoBean.companyOrgType}}</td>
                            <td class="c-value"  v-if="!infoBean.companyOrgType">-</td>
                        </tr>
                        <tr>
                            <td class="c-name">纳税人识别号</td>
                            <td class="c-value"  v-if="infoBean.taxNumber">{{infoBean.taxNumber}}</td>
                            <td class="c-value"  v-if="!infoBean.taxNumber">-</td>
                            <td class="c-name">行业</td>
                            <td class="c-value"  v-if="infoBean.industry">{{infoBean.industry}}</td>
                            <td class="c-value"  v-if="!infoBean.industry">-</td>
                        </tr>
                        <tr>
                            <td class="c-name">营业期限</td>
                            <td class="c-value" v-if="infoBean.operatingPeriod">{{infoBean.operatingPeriod}}</td>
                            <td class="c-value" v-if="!infoBean.operatingPeriod">-</td>
                            <td class="c-name">核准日期</td>
                            <td class="c-value" v-if="infoBean.approvedTime">{{infoBean.approvedTime}}</td>
                            <td class="c-value" v-if="!infoBean.approvedTime">-</td>
                        </tr>
                        <tr>
                            <td class="c-name">纳税人资质</td>
                            <td class="c-value">-</td>
                            <td class="c-name">人员规模</td>
                            <td class="c-value"  v-if="infoBean.staffNumRange">{{infoBean.staffNumRange}}</td>
                            <td class="c-value"  v-if="!infoBean.staffNumRange">-</td>
                        </tr>
                        <tr>
                            <td class="c-name">实缴资本</td>
                            <td class="c-value"  v-if="infoBean.actualCapital">{{infoBean.actualCapital}}</td>
                            <td class="c-value"  v-if="!infoBean.actualCapital">-</td>
                            <td class="c-name">登记机关</td>
                            <td class="c-value"  v-if="infoBean.regInstitute">{{infoBean.regInstitute}}</td>
                            <td class="c-value"  v-if="!infoBean.regInstitute">-</td>
                        </tr>
                        <tr>
                            <td class="c-name">参保人数</td>
                            <td class="c-value"  v-if="infoBean.socialStaffNum">{{infoBean.socialStaffNum}}</td>
                            <td class="c-value"  v-if="!infoBean.socialStaffNum">-</td>
                            <td class="c-name">英文名称</td>
                            <td class="c-value"  v-if="infoBean.englishName">{{infoBean.englishName}}</td>
                            <td class="c-value"  v-if="!infoBean.englishName">-</td>
                        </tr>
                        <tr>
                            <td class="c-name">注册地址</td>
                            <td class="c-long" colspan="3" v-if="infoBean.regLocation">{{infoBean.regLocation}}</td>
                            <td class="c-long" colspan="3" v-if="!infoBean.regLocation">-</td>
                        </tr>
                        <tr>
                            <td class="c-name">经营范围</td>
                            <td class="c-long" colspan="3" v-if="infoBean.businessScope">{{infoBean.businessScope}}</td>
                            <td class="c-long" colspan="3" v-if="!infoBean.businessScope">-</td>
                        </tr>
                    </table>
            </div>
            <div class="caution msg" v-if="activeType==4" id="scrollContext">
                 <CommonRiskInfo :msg-info="msgInfo"></CommonRiskInfo>
            </div>
            <template slot="footer" >
            </template>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>

      
  </div>
</template>

<script>
import Loading from '@/components/base/Loading';
import { InterfaceService } from '@/services/api';
import RiskInfoCommonTable from '@/components/riskMsgCenter/CommonTable';
import CommonRiskInfo from "@/components/riskMsgCenter/CommonRiskInfo";

export default {
  props: {
    centerDialogVisible: {
      type: Boolean,
      default: true
    },
    activeType:{
        type: Number,
        default: 1
    },
    infoBean:{
        type:Object,
        default:{}
    }
  },
    components:{
        Loading,
        RiskInfoCommonTable,
        CommonRiskInfo
    },
    // watch: {
    //     centerDialogVisible(neww,old){
    //         if(neww ){
    //             this.openRiskInfoFlag = this.centerDialogVisible
    //         }
    //     }
    // },
  data () {
    return {
        msgInfo:{},
        isLoading:false,
        activeName: '1',
        openRiskInfoFlag:false,
        providerName:'',
        typeList:[],
         //下拉展开的页数及内容
        riskDetailPageIndex:1,
        riskDetailTotal:1,
        riskDetailCounts:1,
        riskDetailChildId:'',
        riskDetailChildList:[],
        typeIdNameArr:[],
        riskType:'',
        emptyShowName:'',
        pageSize:5,
        upTime:""

    }
  },
  methods: {
    handleChangePageFuc(pageIndex){
        this.isLoading = true;
        this.riskDetailChildList=[];
        this.riskDetailPageIndex =pageIndex;
        let params = {
            name:this.providerName,
            id:this.riskDetailChildId, 
            pageSize:this.pageSize,
            pageNum:pageIndex
        }
        InterfaceService.doGetProviderRiskTypeLiListInfo(
            params,
            data => {
                    if(data.respData.respCode=='0000'){
                       this.riskDetailTotal=data.respData.pageTotal;
                        this.riskDetailCounts =data.respData.count;
                        this.riskDetailChildList =data.respData.dataList || [];
                  }
                    
                },
            data => {},
            () => {
                this.isLoading = true;
            },
            () => {
                this.isLoading = false;
            }
        );

    },
    handleOpenUrlLink(url){
        window.open(url);
    },
    handleChange(id){
        console.log("进来了"+this.providerName)
            //切割
            this.typeIdNameArr =id.split('_');
            this.riskType =this.typeIdNameArr[0];
            this.riskDetailChildList=[];
            this.emptyShowName ='';
            this.riskDetailChildId =this.typeIdNameArr[1];
            if(id){
                this.isLoading = true;
                let params ={
                    name:this.providerName,
                    id:this.riskDetailChildId,
                    pageSize:this.pageSize,
                    pageNum:1
                }
                InterfaceService.doGetProviderRiskTypeLiListInfo(
                    params,
                    data => {
                          if(data.respData.respCode=='0000'){
                                this.riskDetailTotal=data.respData.pageTotal;
                                this.riskDetailCounts =data.respData.count;
                                this.riskDetailChildList =data.respData.dataList || [];
                                if( !this.riskDetailChildList || this.riskDetailChildList.length == 0){
                                    this.emptyShowName='未检索到数据..'
                                }
                          }
                        },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
        }
    },
    closeDialog(){
        this.openRiskInfoFlag=false;
    },
    calc(name){
        return name;
    },
    openActiveMsgDetail(messInfo){
        this.openRiskInfoFlag = true
        this.msgInfo = messInfo;
        console.log(this.msgInfo)
        this.activeType=4;
    },
    open(providerName){
        this.providerName =providerName;
        this.openRiskInfoFlag = true
        this.activeType=3;
    },
    //组装第一种数据类型
    getActiveTypeData(providerName,upTime){
        this.isLoading = true;
        // providerName='北京百度网讯科技有限公司';
        this.providerName =providerName;
        this.upTime =upTime;
        console.log(this.upTime)
        this.openRiskInfoFlag = true;
        this.typeList = []
        //请求数据
            var param ={
                name:this.providerName,
                riskTypes:[1,3,5,6,7,8,9,10],
                pageNum:1,
                pageSize:10000
            };
          InterfaceService.doGetProviderRiskTypeLiDetail(
                param,
                data => {
                          if(data.respData.respCode=='0000'){
                              this.typeList =data.respData.typeList || [];
                              //数据过滤
                              this.typeList.forEach(element1 => {
                                if(element1.riskInfoDataList){
                                    element1.riskInfoDataList.forEach(element2 => {
                                         console.log(element2.title.indexOf('该公司'))
                                        if(element2.title.indexOf('该公司')>-1){
                                            element2.title =element2.title.replace(/该公司/, "")
                                        }
                                     });
                                }
                                 
                              });
                          }else{
                             this.isLoading = false;
                          }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
    },
    dailogClosed(){
        //滚动条 重置
        if(document.getElementById('scrollContext')){
            document.getElementById('scrollContext').scrollTop =0;
        }
        
    }
  },
  mounted () {
     
  }
}
</script>

<style  lang="scss"  scoped>
.riskInfo {
        // /deep/ .el-dialog.el-dialog--center{
        //        height: 607px;
        //         overflow-y: scroll;
        // }
        /deep/ .el-dialog__headerbtn.el-dialog__close{
            color: #333;
        }
        /deep/ .el-dialog__header{
            padding: 0px;
        }
        /deep/ .el-icon-arrow-right:before {
            /*content: "\E605";*/
        }
        /deep/ .el-collapse-item__arrow.is-active{
                /*-webkit-transform: rotate(0deg);*/
                /*transform: rotate(0deg);*/
        }
        /deep/ .el-collapse-item__content{
            padding-bottom: 0px;
        }
        /deep/ .el-collapse-item__arrow{
            font-size: 20px;
            position: absolute;
            height: 35px;
            line-height: 35px;
            right: 10px;
            top: 0;
            color: #f68141;
            /*-webkit-transform: rotate(180deg);*/
            /*transform: rotate(180deg);*/
        }
        /deep/ .caution .el-dialog__body{
            overflow-y: scroll;
            height: 535px;
        }
        
        /deep/ .el-collapse-item__header{
            border: 0;
        }
        /deep/ .el-collapse-item.r-parent{
            position: relative;
        }
        /deep/ .el-collapse-item__header{
            height: auto;
           min-height:18px;
           display: contents;
           line-height:15px;
        }
         /deep/ .el-dialog__headerbtn{
                top: 10px;
            }
    .header{
            position: relative;
            height: 60px;
            line-height: 60px;
            font-size: 18px;
            text-align: center;
            background: #f1f4ff;
            .atten{
                background: url(../../assets/images/icon/icon_atten.png) no-repeat center center;
                font-size: 14px;
                background-size: 21px;
                position: absolute;
                left: 30px;
                padding-left: 104px;
                top: 50%;
                transform: translate(-50%,-50%);
            }
    }
    .r-header{
        height: 45px;
        line-height: 45px;
        font-size: 18px;
    }
    .n-header{
        height: 45px;
        line-height: 45px;
        font-size: 18px;
        background:#f9f9f9;
    }
    .caution{
        height: 400px;
        overflow-y: scroll;
        /deep/ .el-collapse-item__wrap{
            border-bottom: 0;
        }
        .upTime{
            color: #999;
            height: 35px;
            padding-top: 5px;
            text-align: center;
        }
        .mid{
            .riskType{
                font-size: 16px;
                height: 15px;
                position: relative;
                padding-left: 30px;
                margin-bottom: 10px;
                text-align: left;
                .shu{
                    position: absolute;
                    height: 18px;
                    width: 3px;
                    background: #fb7d2c;
                    left: 20px;
                    top: -2px;
                }
            }
            .empty-data{
                text-align: center;
                margin-top: 20px;
            }
            // .riskType::before{
            //     position: absolute;
            //     content: "|";
            //     color: #f95f5a;
            //     left: -10px;
            //     top: -2px;
            //     /* font-weight: 800; */
            //     background: #f95f5a;
            //     width: 4px;
            //     height: 20px;
            // }
            .r-parent{
                text-align: left;
                padding: 10px 30px;
                padding-right: 32px;
            }
            .el-collapse{
                border-top: 0;
                border-bottom: 0;
                .p-type{
                    margin-bottom: 20px;
                }
            }
            .t-name{
                color: #f95f5a;
                position: relative;
                .t-compeny{
                    color: #333;
                    padding-right: 10px;
                }
                .t-num{
                    padding-left: 10px;
                }
            }
            table{
                width: 100%;
                text-align: center;
                margin-top: 15px;
                .tr-name{
                    border-top: 1px solid #eee;
                    border-bottom: 1px solid #eee;
                }
                .tr-name td{
                    padding: 10px 0;
                }
                .tr-contain td{
                    
                    padding: 10px 5px;
                }
                .tr-contain{
                     .openlink{
                        cursor: pointer;
                        color: #0084ff;
                    }
                }
                .wtd4{
                    width: 4%;
                }
                .wtd10{
                    width: 10%;
                }
                .wtd40{
                    width: 40%;
                }
                .wtd15{
                    width: 15%;
                }
            }
            
        }
    }
    .empty{
        line-height: 400px;
        text-align: center;
        font-size: 16px;
    }
   .reminder{
        height: 500px;   
        .r-contain{
            height: 350px;
            overflow-y: scroll;
        }
        // .r-contain::-webkit-scrollbar-track {
        //     background-color: #f2f2f2;
        // }
        // .r-contain::-webkit-scrollbar-thumb {
        //     background: #3DB6A4;
        // }
        // .r-contain::-webkit-scrollbar {
        //     height: 20px;
        // }
        .hdr{
            font-size: 14px;
            height: 25px;
            span{
                color:#ff0000;
            }
        }
        .r-li{
            padding: 0 20px;
            background: #f6f6f6;
        }
        .r-title{
            height: 36px;
            line-height: 36px;
            span{
                color: #fa3f39;
            }
        }
        table{
            text-align: center;
            line-height: 14px;
            .tr-name{
                border-top: 1px solid #eee;
                border-bottom: 1px solid #eee;
                background: #fff;
            }
            .tr-name td{
                padding: 10px 0;
            }
            .tr-contain{
                border-bottom: 1px solid #eee;
            }
            .tr-contain td{
                padding: 30px 0;
            }
            .wtd10{
                width: 10%;
            }
            .wtd40{
                width: 40%;
            }
            .wtd15{
                width: 15%;
            }
        }
        .ifDo{
            text-align: center;
            font-size: 16px;
            height: 65px;
            line-height: 65px;
        }
        .btns{
            zoom: 1;
            font-size: 14px;
            height: 50px;
            line-height: 50px;
            width: 100%;
            .left{
                text-align: right;
                width: 50%;
                float: left;
                span{
                    cursor: pointer;
                    margin-right: 10px;
                    background: #ffd64e;
                    padding: 10px 50px;
                }
            }
            .right{
                text-align: left;
                width: 50%;
                float: left;
                span{
                    cursor: pointer;
                    margin-left: 10px;
                    background: #f6f6f7;
                    border: 1px solid #eee;
                    padding: 10px 50px;
                }
            }
        }
   }
   .normal{
       table{
           width:100%;
           text-align:left;
           font-size:14px;
           word-wrap: break-word;
            word-break: break-all;
            table-layout:fixed;
           tr{
               height:50px;
               td{
                   vertical-align: middle;
                   height:50px;
               }
           }
           .c-name{
               width:20%;
               padding-left:30px;
               color:#888;
               background:#f9f9f9;
           }
           .c-value{
               width:30%;
               padding-left:20px;
               padding-right: 20px;
           }
           .c-long{
               line-height: 20px;
               padding:16px 20px;
               width:80%;
           }
       }
   }
   .caution.msg{
        overflow-y: auto;
        
   }
}
.riskInfo.cau{
    /deep/ .el-dialog__body{
        padding: 0;
    }
}
.el-collapse-item.r-parent.is-active{
    margin-bottom: 20px;
}
.el-pagination{
    text-align: center;
}
// 滚动条样式
/*定义滚动条高宽及背景 高宽分别对应横竖滚动条的尺寸*/
// ::-webkit-scrollbar
// {
//     width: 16px;
//     height: 16px;
//     background-color: #F5F5F5;
// }
 
// /*定义滚动条轨道 内阴影+圆角*/
// ::-webkit-scrollbar-track
// {
//     -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
//     border-radius: 10px;
//     background-color: #F5F5F5;
// }
 
// /*定义滑块 内阴影+圆角*/
// ::-webkit-scrollbar-thumb
// {
//     border-radius: 10px;
//     -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,.3);
//     background-color: #555;
// }

</style>
