<template>
  <div class="riskInfo">
            <div v-if="msgInfo.messageSubClass==1">
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">列入日期：</div>
                        <div class="l-2">{{msgInfo.content.putDate|formatLongTime('yyyymmdd')}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">作出决定机关：</div>
                        <div class="r-2">{{msgInfo.content.putDepartment || '-'}}</div>

                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">列入原因：</div>
                        <div class="l-2">{{msgInfo.content.putReason ||'-'}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">移除日期：</div>
                        <div class="l-2">{{msgInfo.content.removeDate|formatLongTime('yyyymmdd')}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">决定移除部门：</div>
                        <div class="r-2">{{msgInfo.content.removeDepartment || '-'}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">移除原因：</div>
                        <div class="l-2">{{msgInfo.content.removeReason || '-'}}</div>
                    </div>
                </div>
            </div>
            <div v-if="msgInfo.messageSubClass==3">
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">失信公司：</div>
                        <div class="l-2">{{msgInfo.content.iname || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">法定代表人：</div>
                        <div class="r-2">{{msgInfo.content.businessentity || '-'}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">执行依据文号：</div>
                        <div class="l-2">{{msgInfo.content.gistid || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">省份：</div>
                        <div class="r-2">-</div>
                        <!-- <div class="r-2">{{msgInfo.content.businessentity || '-'}}</div> -->
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">组织机构代码：</div>
                        <div class="l-2">{{msgInfo.content.cardnum || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">执行法院：</div>
                        <div class="r-2">{{msgInfo.content.courtname || '-'}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">组织机构代码：</div>
                        <div class="l-2">{{msgInfo.content.iname || '-'}}</div>
                    </div>
                </div>
                    <div class="up">
                    <div class="left">
                        <div class="l-1 tr">做出执行依据单位：</div>
                        <div class="l-2">{{msgInfo.content.gistunit || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">法律生效文书确定的义务：</div>
                        <div class="r-2">{{msgInfo.content.duty || '-'}}</div>
                    </div>
                </div>
                    <div class="up">
                    <div class="left">
                        <div class="l-1 tr">被执行人的履行情况：</div>
                        <div class="l-2">{{msgInfo.content.performance || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">立案时间：</div>
                        <div class="r-2">{{msgInfo.content.regdate|formatLongTime('yyyymmdd')}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">案号：</div>
                        <div class="l-2">{{msgInfo.content.casecode || '-'}}</div>
                    </div>
                </div>
                <div class="down">
                    <div class="left tr">
                        失信被执行人行为具体情形：
                    </div>
                    <div class="right">
                    {{msgInfo.content.disrupttypename || '-'}}
                    </div>
                </div>

            </div>
            <div v-if="msgInfo.messageSubClass==5">
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">被执行人名称：</div>
                        <div class="l-2">{{msgInfo.content.pname || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">执行法院：</div>
                        <div class="r-2">{{msgInfo.content.execCourtName || '-'}}</div>

                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">组织机构代码：</div>
                        <div class="l-2">{{msgInfo.content.partyCardNum || '-'}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">案号：</div>
                        <div class="l-2">{{msgInfo.content.caseCode || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">立案时间：</div>
                        <div class="r-2">{{msgInfo.content.caseCreateTime|formatLongTime('yyyymmdd')}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">执行标的：</div>
                        <div class="l-2">{{msgInfo.content.execMoney || '-'}}</div>
                    </div>
                </div>
            </div>
            <div v-if="msgInfo.messageSubClass==6">
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">行政处罚内容：</div>
                        <div class="l-2">{{msgInfo.content.content || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">行政处罚决定书文号：</div>
                        <div class="r-2">{{msgInfo.content.punishNumber || '-'}}</div>

                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">注册号：</div>
                        <div class="l-2">{{msgInfo.content.regNum || '-'}}</div>
                    </div>
                        <div class="right">
                        <div class="r-1 tr">名称：</div>
                        <div class="r-2">{{msgInfo.content.name || '-'}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">省份：</div>
                        <!-- <div class="l-2">{{msgInfo.content.base || '-'}}</div> -->
                        <div class="l-2">-</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">作出行政处罚决定日期：</div>
                        <div class="r-2">{{msgInfo.content.decisionDate |formatLongTime('yyyymmdd')}}</div>
                    </div>
                </div>
                    <div class="up">
                    <div class="left">
                        <div class="l-1 tr">法定代表人（负责人）姓名：</div>
                        <div class="l-2">{{msgInfo.content.legalPersonName || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">作出行政处罚决定机关名称：</div>
                        <div class="r-2">{{msgInfo.content.departmentName || '-'}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">公示日期：</div>
                        <div class="l-2">{{msgInfo.content.publishDate|formatLongTime('yyyymmdd')}}</div>
                    </div>
                </div>
                <div class="down">
                    <div class="left tr">
                        违法行为类型：
                    </div>
                    <div class="right">
                    {{msgInfo.content.type || '-'}}
                    </div>
                </div>
                <div class="down">
                    <div class="left tr">
                        描述：
                    </div>
                    <div class="right">
                    {{msgInfo.content.description || '-'}}
                    </div>
                </div>

            </div>
            <div v-if="msgInfo.messageSubClass==7">
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">创建时间：</div>
                        <div class="l-2">{{msgInfo.content.createTime|formatLongTime('yyyymmdd')}}</div>
                    </div>

                </div>
                <div class="up">
                        <div class="left">
                        <div class="l-1 tr">决定列入部门：</div>
                        <div class="l-2">{{msgInfo.content.putDepartment || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">列入时间：</div>
                        <div class="r-2">{{msgInfo.content.putDate|formatLongTime('yyyymmdd')}}</div>
                    </div>
                </div>
                <div class="down">
                    <div class="left tr">
                        列入原因：
                    </div>
                    <div class="right">
                    {{msgInfo.content.putReason || '-'}}
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">移除时间：</div>
                        <div class="l-2">{{msgInfo.content.removeDate|formatLongTime('yyyymmdd')}}</div>
                    </div>
                        <div class="right">
                        <div class="r-1 tr">决定移除部门：</div>
                        <div class="r-2">{{msgInfo.content.removeDepartment || '-'}}</div>
                    </div>
                </div>

                <div class="down">
                    <div class="left tr">
                        移除原因：
                    </div>
                    <div class="right">
                    {{msgInfo.content.removeReason || '-'}}
                    </div>
                </div>


            </div>
            <div v-if="msgInfo.messageSubClass==8">

                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">提交时间：</div>
                        <div class="l-2">{{msgInfo.content.submittime|formatLongTime('yyyymmdd')}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">法院：</div>
                        <div class="r-2">{{msgInfo.content.court || '-'}}</div>

                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">案件类型：</div>
                        <div class="l-2">{{msgInfo.content.casetype || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">文书类型：</div>
                        <div class="r-2">{{msgInfo.content.doctype || '-'}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">案件号：</div>
                        <div class="l-2">{{msgInfo.content.caseno || '-'}}</div>
                    </div>
                </div>
                <div class="down">
                    <div class="left tr">
                        标题：
                    </div>
                    <div class="right">
                    {{msgInfo.content.title || '-'}}
                    </div>
                </div>
                <div class="down">
                    <div class="left tr">
                        代理人：
                    </div>
                    <div class="right">
                    {{msgInfo.content.agent || '-'}}
                    </div>
                </div>
                <div class="down">
                    <div class="left tr">
                        原文链接地址：
                    </div>
                    <div class="right">
                        <a @click="openUrl(msgInfo.content.url)">{{msgInfo.content.url || '-'}}</a>
                    </div>
                </div>


            </div>
            <div v-if="msgInfo.messageSubClass==9">
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">出质股权数额：</div>
                        <div class="l-2">{{msgInfo.content.equityAmount || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">登记编号：</div>
                        <div class="r-2">{{msgInfo.content.regNumber || '-'}}</div>

                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">质权人：</div>
                        <div class="l-2">{{msgInfo.content.pledgee || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">股权出质设立发布日期：</div>
                        <div class="r-2">{{msgInfo.content.putDate|formatLongTime('yyyymmdd')}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">股权出质设立登记日期：</div>
                        <div class="l-2">{{msgInfo.content.regDate|formatLongTime('yyyymmdd')}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">省份简称：</div>
                        <!-- <div class="r-2">{{msgInfo.content.base || '-'}}</div> -->
                        <div class="r-2">-</div>
                    </div>
                </div>
                    <div class="up">
                    <div class="left">
                        <div class="l-1 tr">状态：</div>
                        <div class="l-2">{{msgInfo.content.state || '-'}}</div>
                    </div>
                        <div class="right">
                        <div class="r-1 tr">出质人：</div>
                        <div class="r-2">{{msgInfo.content.pledgor || '-'}}</div>
                    </div>
                </div>
                    <div class="up">
                    <div class="left">
                        <div class="l-1 tr">质权人证照：</div>
                        <div class="l-2">{{msgInfo.content.certifNumberR || '-'}}</div>
                    </div>
                        <div class="right">
                        <div class="r-1 tr">出质人证照：</div>
                        <div class="r-2">{{msgInfo.content.certifNumber || '-'}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">变化情况：</div>
                        <div class="l-2">{{msgInfo.content.changeSituation || '-'}}</div>
                    </div>
                        <div class="right">
                        <div class="r-1 tr">注销日期：</div>
                        <div class="r-2">{{msgInfo.content.cancelDate|formatLongTime('yyyymmdd')}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">注销原因：</div>
                        <div class="l-2">{{msgInfo.content.cancel || '-'}}</div>
                    </div>
                </div>
            </div>
                <div v-if="msgInfo.messageSubClass==10">
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">变更事项：</div>
                        <div class="l-2"  @click="dialogTableVisibleFuc('0',msgInfo.content.changeInfoList)"><a>查看详情</a></div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">抵押人信息：</div>
                        <div class="r-2" @click="dialogTableVisibleFuc('1',msgInfo.content.peopleInfo)"><a>查看详情</a></div>

                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">被担保债权数额：</div>
                        <div class="l-2">{{msgInfo.content.baseInfo.amount || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">担保范围：</div>
                        <div class="r-2">{{msgInfo.content.baseInfo.scope || '-'}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">概况债务人履行债务的期限：</div>
                        <div class="l-2">{{msgInfo.content.baseInfo.overviewTerm || '-'}}</div>
                    </div>
                        <div class="right">
                        <div class="r-1 tr">登记机关：</div>
                        <div class="r-2">{{msgInfo.content.baseInfo.regDepartment || '-'}}</div>
                    </div>
                </div>
                    <div class="up">
                    <div class="left">
                        <div class="l-1 tr">备注：</div>
                        <div class="l-2">{{msgInfo.content.baseInfo.remark || '-'}}</div>
                    </div>
                        <div class="right">
                        <div class="r-1 tr">状态：</div>
                        <div class="r-2">{{msgInfo.content.baseInfo.status || '-'}}</div>
                    </div>
                </div>
                    <div class="up">
                    <div class="left">
                        <div class="l-1 tr">登记编号：</div>
                        <div class="l-2">{{msgInfo.content.baseInfo.regNum || '-'}}</div>
                    </div>
                        <div class="right">
                        <div class="r-1 tr">登记日期：</div>
                        <div class="r-2">{{msgInfo.content.baseInfo.regDate | formatLongTime('yyyymmdd')}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">省份简称：</div>
                        <!-- <div class="l-2">{{msgInfo.content.baseInfo.base || '-'}}</div> -->
                        <div class="l-2">-</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">被担保债权种类：</div>
                        <div class="r-2">{{msgInfo.content.baseInfo.type || '-'}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">公示日期：</div>
                        <div class="l-2">{{msgInfo.content.baseInfo.publishDate |formatLongTime('yyyymmdd')}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">债务人履行债务的期限：</div>
                        <div class="r-2">{{msgInfo.content.baseInfo.term || '-'}}</div>
                    </div>
                </div>
                    <div class="up">
                    <div class="left">
                        <div class="l-1 tr">概况种类：</div>
                        <div class="l-2">{{msgInfo.content.baseInfo.overviewAmount || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">概况数额：</div>
                        <div class="r-2">{{msgInfo.content.baseInfo.overviewScope || '-'}}</div>
                    </div>
                </div>
                    <div class="up">
                    <div class="left">
                        <div class="l-1 tr">概况担保的范围：</div>
                        <div class="l-2">{{msgInfo.content.baseInfo.overviewScope || '-'}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">概况备注：</div>
                        <div class="r-2">{{msgInfo.content.baseInfo.overviewRemark || '-'}}</div>
                    </div>
                </div>
                <div class="up">
                    <div class="left">
                        <div class="l-1 tr">注销日期：</div>
                        <div class="l-2">{{msgInfo.content.baseInfo.cancelDate|formatLongTime('yyyymmdd')}}</div>
                    </div>
                    <div class="right">
                        <div class="r-1 tr">注销原因：</div>
                        <div class="r-2">{{msgInfo.content.baseInfo.cancelReason || '-'}}</div>
                    </div>
                </div>
                    <div class="up">
                    <div class="left">
                        <div class="l-1 tr">抵押物信息：</div>
                        <div class="l-2"  @click="dialogTableVisibleFuc('2',msgInfo.content.pawnInfoList)"><a>查看详情</a></div>
                    </div>
                </div>
            </div>
            <div v-if="msgInfo.messageSubClass==99">
                <div class="up new" v-html="msgInfo&&msgInfo.content&&msgInfo.content.title ||'暂无'"></div>
            </div>
            <el-dialog :title="dialogTitle" :visible.sync="dialogTableVisible" :append-to-body="true">
                <el-table :data="gridData" v-show="tabDetailType==0">
                    <el-table-column property="changeDate" :formatter="dateFormat" label="变更时间"></el-table-column>
                    <el-table-column property="changeContent" label="变更内容"></el-table-column>
                </el-table>
                 <el-table :data="gridData" v-show="tabDetailType==1">
                    <el-table-column property="licenseNum" label="证照"></el-table-column>
                    <el-table-column property="peopleName" label="抵押权人名称"></el-table-column>
                    <el-table-column property="liceseType" label="抵押权人证照"></el-table-column>
                </el-table>
                 <el-table :data="gridData" v-show="tabDetailType==2">
                    <el-table-column property="pawnName" label="名称"></el-table-column>
                    <el-table-column property="ownership" label="所有权归属"></el-table-column>
                    <el-table-column property="detail" label="数量、质量、状况、所在地等情况"></el-table-column>
                    <el-table-column property="remark" label="备注"></el-table-column>
                </el-table>
            </el-dialog>
        </div>
</template>
<script>

export default {
    props: {
        msgInfo: {
            type: Object,
            default: {}
        }
    },
    components:{

    },
  data () {
    return {
             dialogTitle:'详情',
            tabDetailType:'',
            gridData:[],
            dialogTableVisible: false,
    }
  },
  watch:{
    // msgInfo(n,o){
    //     console.log(n)
    // }
  },
  methods: {
       openUrl(url){
           if(url){
                window.open(url)
           }
        },
         //时间格式化
        dateFormat:function(row,column){
            if(!row.changeDate){
                return;
            }
            var date = new Date(row.changeDate);
            var Y = date.getFullYear(),
                        m = date.getMonth() + 1,
                        d = date.getDate(),
                        H = date.getHours(),
                        i = date.getMinutes(),
                        s = date.getSeconds();
                if (m < 10) {
                    m = '0' + m;
                }
                if (d < 10) {
                    d = '0' + d;
                }
                if (H < 10) {
                    H = '0' + H;
                }
                if (i < 10) {
                    i = '0' + i;
                }
                if (s < 10) {
                    s = '0' + s;
                }
                var t = Y + '-' + m + '-' + d + ' ' + H + ':' + i;
                return t;

        },
        //显示详情列表
        dialogTableVisibleFuc(type,data){
            if(type==0){
                this.dialogTitle ='变更事项列表';
            }else if(type==1){
                this.dialogTitle ='抵押人信息详情';
            }else if(type==2){
                this.dialogTitle ='抵押物信息详情';
            }
            this.tabDetailType=type;
            this.gridData =data;
            this.dialogTableVisible=true;
        }
  }
}
</script>

<style  lang="scss"  scoped>
 .up{
                min-height: 40px;
                line-height: 16px;
                width: 100%;
                text-align: left;
                display: inline-block;
                .left{
                    width: 50%;
                    float: left;
                    .l-1{
                        width: 35%;
                        float: left;
                        padding: 15px 15px 15px 0;
                    }
                    .l-2{
                        text-align: left;
                        width: 65%;
                        float: left;
                        padding: 15px 15px 15px 0;
                        a{
                            cursor: pointer;
                            color: #0082ff;
                        }
                    }
                }
                .right{
                    float: left;
                    width: 50%;
                    .r-1{
                        width: 35%;
                        float: left;
                        padding: 15px 15px 15px 0;
                    }
                    .r-2{
                        width: 65%;
                        float: left;
                        padding: 15px 15px 15px 0;
                        a{
                            cursor: pointer;
                            color: #0082ff;
                        }
                    }
                }
            }
            .up.new{
                padding: 15px 0;
                text-align: left;
            }
            .down{
                 text-align: left;
                min-height: 40px;
                line-height: 16px;
                display: flex;
                .left{
                    float: left;
                    width:17.5%;
                    padding: 15px 15px 15px 0;
                }
                .right{
                    text-align: left;
                    float: left;
                    width:82.5%;
                    padding: 15px 15px 15px 0;
                    a{
                        cursor: pointer;
                        color: #0082ff;
                    }
                }
            }


</style>
