<template>
  <div class="riskInfo-table">
        <table  v-if="riskType==typeKey.seriousViolOfLaw && riskDetailChildList && riskDetailChildList.length>0">
            <tr class="tr-name">
                <td>列入日期</td>
                <td>列入原因</td>
                <td>作出决定机关</td>
                <td>移除时间</td>
                <td>移除原因</td>
                <td>决定移除部门</td>
            </tr>
            <tr class="tr-contain" v-for="(riskInfo,svfIndex) in riskDetailChildList" :key="svfIndex">
                <td class="wtd10">{{riskInfo.putDate|formatLongTime('yyyymmdd')}}</td>
                <td>{{riskInfo.putReason || '-'}}</td>
                <td>{{riskInfo.putDepartment || '-'}}</td>
                <td class="wtd10">{{riskInfo.removeDate|formatLongTime('yyyymmdd')}}</td>
                <td>{{riskInfo.removeReason || '-'}}</td>
                <td>{{riskInfo.removeDepartment || '-'}}</td>
            </tr>
        </table>
        <table  v-if="riskType==typeKey.brokenFaithCompany && riskDetailChildList && riskDetailChildList.length>0">
            <tr class="tr-name">
                <td>立案日期</td>
                <td>案号</td>
                <td>执行法院</td>
                <td>履行状态</td>
                <td>执行依据文号</td>
            </tr>
            <tr class="tr-contain" v-for="(riskInfo,bfcIndex) in riskDetailChildList" :key="bfcIndex">
                <td class="wtd10">{{riskInfo.regdate|formatLongTime('yyyymmdd')}}</td>
                <td>{{riskInfo.casecode || '-'}}</td>
                <td>{{riskInfo.courtname || '-'}}</td>
                <td>{{riskInfo.performance || '-'}}</td>
                <td>{{riskInfo.gistid || '-'}}</td>
            </tr>
        </table>
        <table  v-if="riskType==typeKey.executedCompany && riskDetailChildList && riskDetailChildList.length>0">
            <tr class="tr-name">
                <td >立案日期</td>
                <td>执行标的</td>
                <td>案号</td>
                <td>执行法院</td>
            </tr>
            <tr class="tr-contain" v-for="(riskInfo,ecIndex) in riskDetailChildList" :key="ecIndex">

                <td class="wtd10">{{riskInfo.caseCreateTime|formatLongTime('yyyymmdd')}}</td>
                <td>{{riskInfo.execMoney || '-'}}</td>
                <td>{{riskInfo.caseCode || '-'}}</td>
                <td>{{riskInfo.execCourtName || '-'}}</td>
            </tr>
        </table>
        <table  v-if="riskType==typeKey.administrativeSanction && riskDetailChildList && riskDetailChildList.length>0">
            <tr class="tr-name">
                <td>决定日期</td>
                <td>决定书文号</td>
                <td>类型</td>
                <td>决定机关</td>
            </tr>
            <tr class="tr-contain" v-for="(riskInfo,asIndex) in riskDetailChildList" :key="asIndex">
                <td class="wtd10">{{riskInfo.decisionDate|formatLongTime('yyyymmdd')}}</td>
                <td>{{riskInfo.punishNumber || '-'}}</td>
                <td>{{riskInfo.type || '-'}}</td>
                <td>{{riskInfo.departmentName || '-'}}</td>
            </tr>
        </table>
        <table  v-if="riskType==typeKey.abnormalOperation && riskDetailChildList && riskDetailChildList.length>0">
            <tr class="tr-name">
                <td>列入日期</td>
                <td>列入原因</td>
                <td>决定机关</td>
            </tr>
            <tr class="tr-contain" v-for="(riskInfo,aoIndex) in riskDetailChildList" :key="aoIndex">
                <td class="wtd10" >{{riskInfo.putDate|formatLongTime('yyyymmdd')}}</td>
                <td>{{riskInfo.putReason || '-'}}</td>
                <td>{{riskInfo.putDepartment || '-'}}</td>
            </tr>
        </table>
        <table  v-if="riskType==typeKey.legalProceedings && riskDetailChildList && riskDetailChildList.length>0">
            <tr class="tr-name">
                <td>日期</td>
                <td>裁判文书</td>
                <td class="wtd10">案件类型</td>
                <td>案件号</td>
            </tr>
            <tr class="tr-contain" v-for="(riskInfo,lpIndex) in riskDetailChildList" :key="lpIndex">
                <td class="wtd10">{{riskInfo.submittime|formatLongTime('yyyymmdd')}}</td>
                <td class="openlink" @click="handleOpenUrlLink(riskInfo.url)">{{riskInfo.title || '-'}}</td>
                <td>{{riskInfo.casetype || '-'}}</td>
                <td>{{riskInfo.caseno || '-'}}</td>
            </tr>
        </table>
        <table  v-if="riskType==typeKey.equityPledge && riskDetailChildList && riskDetailChildList.length>0">
            <tr class="tr-name">
                <td>公告时间</td>
                <td>登记编号</td>
                <td>出质人</td>
                <td>质权人</td>
                <td>状态</td>
            </tr>
            <tr class="tr-contain" v-for="(riskInfo,epIndex) in riskDetailChildList" :key="epIndex">
                <td class="wtd10">{{riskInfo.regDate|formatLongTime('yyyymmdd')}}</td>
                <td>{{riskInfo.regNumber || '-'}}</td>
                <td>{{riskInfo.pledgor || '-'}}</td>
                <td>{{riskInfo.pledgee || '-'}}</td>
                <td>{{riskInfo.state || '-'}}</td>
            </tr>
        </table>
        <table  v-if="riskType==typeKey.chattelMortgage && riskDetailChildList && riskDetailChildList.length>0">
            <tr class="tr-name">
                <td  class="wtd10">登记日期</td>
                <td>登记号</td>
                <td>被担保债权类型</td>
                <td>被担保债权数额</td>
                <td>登记机关</td>
                <td>状态</td>
            </tr>
            <tr class="tr-contain" v-for="(riskInfo,cmIndex) in riskDetailChildList" :key="cmIndex">
                <td class="wtd10">{{riskInfo.baseInfo.regDate|formatLongTime('yyyymmdd')}}</td>
                <td>{{riskInfo.baseInfo.regNum || '-'}}</td>
                <td>{{riskInfo.baseInfo.type || '-'}}</td>
                <td>{{riskInfo.baseInfo.amount || '-'}}</td>
                <td>{{riskInfo.baseInfo.regDepartment || '-'}}</td>
                <td>{{riskInfo.baseInfo.status || '-'}}</td>
            </tr>
        </table>
  </div>
</template>
<script>

export default {
  props: {
        riskDetailChildList: {
            type: Array,
            default: []
        },
        riskType:{
            type:String,
            default: 1
        }
    },
    components:{
        
    },
  data () {
    return {
        typeKey:{
          seriousViolOfLaw:1,//严重违法
          brokenFaithCompany:3,//失信公司
          executedCompany:5,//被执行公司
          administrativeSanction:6,//行政处罚
          abnormalOperation:7,//经营异常
          legalProceedings:8,//法律诉讼
          equityPledge:9,//股权出质
          chattelMortgage:10//动产抵押
        }
    }
  },
  methods: {
    handleOpenUrlLink(url){
        if(url){
            window.open(url);
        }
        
    }
  }
}
</script>

<style  lang="scss"  scoped>
.riskInfo-table {
        
            table{
                width: 100%;
                text-align: center;
                margin-top: 15px;
                .tr-name{
                    font-weight: bold;
                    border-top: 1px solid #eee;
                    border-bottom: 1px solid #eee;
                }
                .tr-name td{
                    padding: 10px 0;
                }
                .tr-contain td{
                    
                    padding: 10px 5px;
                }
                .tr-contain{
                     .openlink{
                        cursor: pointer;
                        color: #0084ff;
                    }
                }
                .wtd4{
                    width: 4%;
                }
                .wtd10{
                    width: 10%;
                }
                .wtd40{
                    width: 40%;
                }
                .wtd15{
                    width: 15%;
                }
            }
}
   
</style>
