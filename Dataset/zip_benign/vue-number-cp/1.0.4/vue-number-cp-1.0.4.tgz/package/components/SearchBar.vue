<template>
  <div class="app-search-bar-container" :class="{'app-search-bar-container-big-page': bigInfrastructure && isShowBigInfrastructure}">
    <div class="app-search-bar" v-if="!bigInfrastructure || !isShowBigInfrastructure" :class="{
        isWhiteBg: isWhiteBg,
        isRedBg: isRedBg,
        'border-bottom': isBorderBottom,
        fixedSearchActiveContainer: fixedSearchActive
      }">
      <div class="search-bar-container inner-container">
        <div class="index-logo">
          <div class="logo" v-if="!isRedBg">
            <h1><a @click="go(isOfficialIndex ? '/officialIndex':'/home')" class="logo-bd"></a></h1>
          </div>
          <div class="logo" v-if="isRedBg">
            <h1><a @click="go('/home')" class="logo-bd-new"></a></h1>
          </div>
        </div>
        <div class="index-search">
          <!-- index 首页、详情页  searchBar -->
          <div class="search-wrap" v-if="searchType == 1">
            <div class="search-bd clearfloat">
              <div class="search-panel">
                <div :class="{
                    'search-panel-bd-normal': !isRedBg,
                    'search-panel-bd': isRedBg
                  }">
                  <!-- <div class="search-panel-left">商品 <i class="el-icon-arrow-down"></i></div> -->
                  <form class="search-combobox">
                    <el-input v-show="isIE" placeholder="请输入搜索文字" v-model.lazy="queryByName" :maxlength="50" id="searchWords" ref="searchWords" clearable>
                    </el-input>
                    <el-input v-show="!isIE" placeholder="请输入搜索文字" v-model.lazy="queryByName" :maxlength="50" @keyup.enter.native="searchWholeStation" clearable>
                    </el-input>
                  </form>
                  <div class="hand" :class="{
                      'search-panel-button-normal': !isRedBg,
                      'search-panel-button': isRedBg
                    }" @click.stop="searchWholeStation()">
                    搜索
                  </div>
                </div>
              </div>
              <div class="fast-release-wrap" v-show="ifBs">
                <div class="fast-release-button" @click="goQuickBuy()">
                  <!--<div class="point-notice" @click.stop="stopFun" v-if="isShowPointNotice && inputShowPointNotice && !fixedSearchActive">-->
                  <!--<img src='@/assets/images/icon/point_notice_icon.png'>-->
                  <!--<span>-->
                  <!--操作指引-->
                  <!--<a class="blur" @click.stop="outputPointNotice">点击查看</a>-->
                  <!--</span>-->
                  <!--<i class="el-icon-error" title="关闭" @click.stop="isShowPointNotice = false"></i>-->
                  <!--</div>-->
                  <a>创建合同</a>
                </div>
              </div>
            </div>
            <div class="search-hot" v-if="!fixedSearchActive">
              <ul>
                <li class="search-hot-title" style="cursor: auto">
                  热门搜索：
                </li>
                <li class="words" @click="hotSearchHandler(search.spuName)" v-for="search in hotSearchList">
                  {{ search.spuName }}
                </li>
              </ul>
            </div>
          </div>
          <!-- login登录页 searchBar -->
          <div class="search-wrap" v-if="searchType == 2">
            <div class="search-bd clearfloat">
              <div class="search-panel">
                <div class="shedule-title" :title="title">{{ progress }}</div>
                <div class="contain-right clearfloat">
                  <span><img src="../assets/images/login/icon01.png" />降本增效赋能</span>
                  <span><img src="../assets/images/login/icon02.png" />交易规范透明</span>
                  <span><img src="../assets/images/login/icon03.png" />平台资源丰富</span>
                </div>
              </div>
            </div>
          </div>
          <!--<div class="search-wrap quick-buy-search-wrap" v-if="searchType == 3">-->
          <!--<div class="search-bd clearfloat">-->
          <!--<div class="search-panel">-->
          <!--<div class="shedule-title">批量采购</div>-->
          <!--<div class="contain-right clearfloat progress-only-1">-->
          <!--<div class="buy-progress-1 fr">添加商品并确认下单</div>-->
          <!--</div>-->
          <!--</div>-->
          <!--</div>-->
          <!--</div>-->
          <!-- 店铺 产品 -->
          <div class="search-wrap" v-if="searchType == 4">
            <div class="search-bd clearfloat">
              <div class="search-panel">
                <div class="search-panel-bd" style="padding-left: 14px;">
                  <form class="search-combobox">
                    <!-- <input type="text" placeholder="请输入搜索文字" v-model.lazy="queryByName"> -->
                    <el-input v-show="!isIE" placeholder="请输入搜索文字" v-model.lazy="queryByName" @keyup.enter.native="searchWholeStation()" :maxlength="50" clearable>
                    </el-input>
                    <el-input v-show="isIE" placeholder="请输入搜索文字" v-model.lazy="queryByName" id="searchWords" ref="searchWords" :maxlength="50" clearable>
                    </el-input>
                  </form>
                  <!--<div-->
                  <!--class="hand"-->
                  <!--:class="{-->
                  <!--'search-panel-button-normal': !isRedBg,-->
                  <!--'search-panel-button': isRedBg-->
                  <!--}"-->
                  <!--@click.stop="searchWholeStation()"-->
                  <!--&gt;-->
                  <!--搜索-->
                  <!--</div>-->
                  <!--</div>-->
                  <!--</div>-->
                  <!--<div class="fast-release-wrap" v-show="ifBs">-->
                  <!--<div class="fast-release-button" @click="goQuickBuy()">-->
                  <!--<a>批量采购</a>-->
                  <!--</div>-->
                  <!--</div>-->
                  <div class="search-panel-button" @click="searchWholeStation()">
                    搜全站
                  </div>
                </div>
              </div>
              <div class="fast-release-wrap">
                <div class="fast-release-button" @click="searchCurrentStore()">
                  搜本店
                </div>
              </div>
            </div>
          </div>
          <div class="search-wrap" v-if="searchType == 5">
            <div class="search-bd clearfloat">
              <div class="search-panel">
                <div class="shedule-title" :title="title">{{ progress }}</div>
                <div class="contain-right clearfloat contractName" :title="contractName" v-if="contractName">{{contractName}}</div>
              </div>
            </div>
          </div>
          <!-- 创建商品 -->
          <div class="search-wrap product-create" v-if="searchType == 6">
            <div class="search-bd clearfloat">
              <div class="search-panel">
                <div class="shedule-title" :title="title">{{ progress }}</div>
                <div class="contain-right clearfloat">
                  <div class="step" step="1" :class="{ disabled: productCreateProcess != 1 }">
                    选择类目
                  </div>
                  <div class="divide"></div>
                  <div class="step" step="2" :class="{ disabled: productCreateProcess != 2 }">
                    填写商品信息
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- 注册 -->
          <div class="search-wrap product-create" v-if="searchType == 7">
            <div class="search-bd clearfloat">
              <div class="search-panel">
                <div class="shedule-title" :title="title">{{ progress }}</div>
                <div class="contain-right clearfloat" v-if="progress != '提交授权委托书' && progress !='修改授权书'">
                  <div class="step" step="1" :class="{ disabled: productCreateProcess != 1 }">
                    公司基本信息
                  </div>
                  <div class="divide"></div>
                  <div class="step" step="2" :class="{ disabled: productCreateProcess != 2 }">
                    财务及联系人信息
                  </div>
                  <div class="divide"></div>
                  <div class="step" step="3" :class="{ disabled: productCreateProcess != 3 }">
                    完成
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="search-wrap" v-if="searchType == 8 && isLogin == '0'">
            <div class="search-bd clearfloat">
              <div class="search-panel right-icon">
                <p @click="">我是采购商</p>
                <p>我是供应商</p>
              </div>
            </div>
          </div>
          <div class="search-wrap" v-if="searchType == 9">
            <div class="search-bd clearfloat">
              <div class="search-panel" :style="{'padding-right':!oneBtn ? '152px' : '0'}">
                <div class="search-panel-bd" style="padding-left: 14px;">
                  <form class="search-combobox type9">
                    <!-- <input type="text" placeholder="请输入搜索文字" v-model.lazy="queryByName"> -->
                    <el-input v-show="!isIE" placeholder="请输入型号或商品名称搜索商品" v-model.trim="queryByName" @keyup.enter.native="searchSkuName()" :maxlength="50" clearable @clear="searchSkuName()">
                    </el-input>
                    <el-input v-show="isIE" placeholder="请输入型号或商品名称搜索商品" v-model.trim="queryByName" id="searchWords" ref="searchWords" :maxlength="50" clearable @clear="searchSkuName()">
                    </el-input>
                  </form>
                  <div class="search-panel-button f14" style="width: 140px;" @click="searchSkuName()">
                    搜索
                  </div>
                </div>
              </div>
              <div class="fast-release-wrap" v-if="!oneBtn">
                <div class="fast-release-button f14" style="background: #fff;color: #C99F4F;border-color: #C99F4F;" @click="goCreateGroupGoods()">
                  <a>创建组价</a>
                </div>
              </div>
            </div>
          </div>
          <!-- 大基建 -->
          <div class="search-wrap" v-if="searchType == 10">
            <div class="search-bd clearfloat">
              <div class="shedule-title fl" :title="title">{{ progress }}</div>
              <div class="online fr" v-if="isOnline">
                <span class="bid">在线招标</span>
                <span style="color: #eee">|</span>
                <span class="warehousing" @click="goBigInfrastructureEntry">上线入库</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- <div :class="['fixedSearchActiveContainer', { active: fixedSearchActive }]">
      <div class="center inner-container">
        <div class="logo">
          <h1><a @click="go('/home')" class="logo-bd"></a></h1>
        </div>
      </div>
    </div> -->
    </div>
    <div class="bigPageTop" v-else>
      <div class="logo fl">
        <img src="@/assets/images/logo_s.png">
        <div class="company-info">
          <p class="hand" @click="goControlCenter">大基建-管理中心</p>
        </div>
        <div class="company-info f16" style="padding-left: 85px;">
          <p class="hand tab-btn-bg" @click="goIndex">大基建首页</p>
        </div>
        <div class="company-info fr">
          <p class="hl22" style="margin-top: 10px;">{{userinfo.corpName}}</p>
          <p class="hl22"> {{userinfo.acctName}}</p>
        </div>
      </div>
    </div>
    <OrderDraftsListDialog :fromIndex="fromIndex" ref="OrderDraftsListDialog"></OrderDraftsListDialog>
  </div>
</template>

<script>
import OrderDraftsListDialog from "@/components/order/dialog/OrderDraftsListDialog";
import accountMixin from "@/mixins/account";

export default {
  mixins: [accountMixin],
  props: {
    searchType: { //10: 大基建
      type: Number,
      default: 1 //这样可以指定默认的值
    },
    progress: {
      type: String,
      default: ''
    },
    // 合同名称
    contractName: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    },
    isShowBigInfrastructure: {
      type: Boolean,
      default: true
    },
    isWhiteBg: {
      type: Boolean,
      default: true
    },
    // 是否取用 sessionStorage 里面的品牌数据, productList 里使用
    isSessionBrandSelectList: {
      type: Boolean,
      default: false
    },
    isRedBg: {
      type: Boolean,
      default: false
    },
    isBorderBottom: {
      type: Boolean,
      default: false
    },
    productCreateProcess: {
      type: Number,
      default: 1
    },
    scrollShowFixed: {
      type: Boolean,
      default: false // 滚动是否显示漂浮导航
    },
    inputShowPointNotice: {
      type: Boolean,
      default: false // 是否显示批量按钮 提示
    },
    isOfficialIndex: {
      type: Boolean,
      default: false
    },
    draftsId: {
      type: String,
      default: ""
    },
    supplierId: {
      type: String,
      default: ""
    },
    fromIndex: {
      type: Boolean,
      default: false
    },
    oneBtn: {
      type: Boolean,
      default: false
    },
    clearText: {
      type: Number,
      default: 0
    },
    isOnline: {
      type: Boolean,
      default: false
    },
  },
  data() {
    return {
      isIE: false,
      queryByName: '',
      timeout: '',
      recommend: [],
      hotSearchList: [
        { "spuName": "木材" },
        { "spuName": "瓷砖" },
        { "spuName": "空调" },
        { "spuName": "电梯" },
        { "spuName": "清漆" },
      ],
      fixedSearchActive: false, // 是否显示漂浮搜索
      isShowPointNotice: true, // 是否显示提示
    }
  },
  components: {
    OrderDraftsListDialog
  },
  watch: {
    clearText(val) {
      if (val) {
        this.queryByName = ''
      }
    }
  },
  computed: {
    ifBs() {
      // null  不显示批量采购 提示
      if (this.$store.state.userInfo) {
        if (this.$store.state.userInfo.bs == 'S') {
          return true
        } else {
          return false
        }
      }
    },
    isLogin() {
      // console.log(this.$store.state.isLogin)
      return this.$store.state.isLogin
    },
  },
  methods: {
    goIndex() {
      if (this.bigInfrastructure) {
        window.open(this.$router.resolve({
          path: '/bigfrastructIndex',
        }).href, '_blank')
        return
      }
    },
    goControlCenter(){
      if (this.role == 'B') {
        this.$router.push('/purchaserCenter/accountInfo')
      } else if (this.role == 'S') {
        this.$router.push('/vendorCenter/accountInfo')
      }
    },
    goBigInfrastructureEntry() {
      this.$router.push({
        path: '/bigInfrastructureEntry',
        query: {
          pageType: 'bigfrastructIndex'
        }
      });
    },
    goCreateGroupGoods() {
      this.$router.push({
        path: '/createGroupGoods',
        query: {
          pageType: '0',
          draftsId: this.draftsId,
          supplierId: this.supplierId,
        }
      });
    },
    goQuickBuy() {
      this.$refs['OrderDraftsListDialog'].open()
      // this.$router.push({
      //   path: '/draftOfCreateOrder'
      // });
      // this.$emit('listenIsShowFooter', true)
    },
    stopFun() { },
    outputPointNotice() {
      this.$emit('outputPointNotice', true)
    },
    hotSearchHandler(hot) {
      this.queryByName = hot
      this.searchWholeStation()
    },
    searchSkuName() {
      this.$emit('searchName', this.queryByName)
    },
    searchWholeStation() {
      if (!this.queryByName) {
        this.$message({
          message: '请输入关键字'
        });
        return false
      }

      this.$setRootScope('forbidBack', 'true')
      this.$router.push({
        path: "/transfer",
        query: {
          query: JSON.stringify({
            keywords: this.queryByName,
            categoryName: this.$route.query.categoryName || "",
            categoryId: this.$route.query.categoryId,
            isSessionBrandSelectList: this.isSessionBrandSelectList
          }),
          path: '/productList'
        }
      });

    },
    searchCurrentStore() {
      if (!this.queryByName) {
        this.$message({ message: '请输入关键字' });
        return false
      }

      let store = this.$route.query
      console.log(this.$route.query);
      store.brandIds = "";
      store.categoryId = "";
      store.categoryName = "";
      store.brandIds = "";
      store.attrs = "";
      store.keywords = this.queryByName

      this.$setRootScope('forbidBack', 'true')

      this.$router.push({
        path: "/transfer",
        query: {
          query: JSON.stringify(store),
          path: '/store'
        }
      });

    },
    querySearch(queryString, cb) {
      if (queryString) {
        var recommend = this.recommend;
        var results = queryString ? recommend.filter(this.createStateFilter(queryString)) : restaurants;
        cb(results);

      }

    },
    createStateFilter(queryString) {
      return (state) => {
        let str = ''
        for (let i in state) {
          str += state[i]
        }
        return (str.toLowerCase().indexOf(queryString.toLowerCase()) > -1);
      };
    },
    handleSelect(item) {

    },
    creatFilter(name) {
      return (state) => {
        for (let i in state) {
          let str = state[i]
        }
        return (state.toLowerCase().indexOf(name.toLowerCase()) > -1);
      };
    },
    go(path) {
      if (this.searchType == 10) {
        this.$router.push('/bigfrastructIndex');
      } else {
        this.$router.push(path);
      }
    },
    emitLogin() {
      this.$emit('login')
    },
    onScroll() {
      let scrolled = document.documentElement.scrollTop || document.body.scrollTop
      if (!this.scrollShowFixed) return
      if (scrolled >= 300) {
        this.fixedSearchActive = true
      } else {
        this.fixedSearchActive = false
      }
    },
    clearQueryByName() {
      console.log('clearQueryByName')
      this.queryByName = ''
    }
  },
  mounted() {
    this.$nextTick(function () {
      window.addEventListener('scroll', this.onScroll)
      this.isIE = this.$isIE()
      console.log(this.$refs["searchWords"]);
      if (this.isIE) {
        var lett = this;
        document.onkeydown = function (e) {
          var key = window.event.keyCode;

          if (key == 13) {
            // if ((lett.searchType == 1 || lett.searchType == 4) && $("#searchWords").length > 0) {
            //   $("#searchWords").blur()
            //   lett.searchWholeStation();
            // } else if (lett.searchType == 2) {
            //   lett.emitLogin()
            // }
            if ((lett.searchType == 1 || lett.searchType == 4) && lett.$refs["searchWords"]) {
              lett.$refs["searchWords"].blur()
              lett.searchWholeStation();
            } else if (lett.searchType == 2) {
              lett.emitLogin()
            }
          }
        }
      }
    })
    console.log(this.$route)
  },
  created: function () {
    // 主页添加键盘事件,注意,不能直接在焦点事件上添加回车

  },
  destroyed() {
    window.removeEventListener('scroll', this.onScroll)
  }

}
</script>

<style lang="scss" scoped>
.online {
  line-height: 50px;
  font-size: 16px;
  color: #bbb;
  .bid {
    margin-right: 16px;
  }
  .warehousing {
    color: #444;
    margin-left: 16px;
    &:hover {
      color: #0082ff;
      cursor: pointer;
    }
  }
}
.app-search-bar {
  /deep/ .el-input {
    height: 48px;
    line-height: 48px;
  }
  /deep/ .el-input__inner {
    height: 45px;
    line-height: 46px;
  }
}
.isRedBg {
  margin: auto;
  background: #fff;
}
.my-autocomplete {
  li {
    line-height: normal;
    padding: 7px;

    .name {
      text-overflow: ellipsis;
      overflow: hidden;
    }
    .addr {
      font-size: 12px;
      color: #b4b4b4;
    }

    .highlighted .addr {
      color: #ddd;
    }
  }
}
.fixedSearchActiveContainer {
  background: #fff;
  height: 90px;
  box-shadow: 0 5px 5px rgba(0, 0, 0, 0.1);
  position: fixed;
  left: 0;
  right: 0;
  z-index: 9999;
  display: flex;
  align-items: center;
  animation: showFixed 0.3s 1;
  top: 0;
  @keyframes showFixed {
    0% {
      top: -100px;
    }
    50% {
      top: -50px;
    }
    100% {
      top: 0;
    }
  }
  .index-logo {
    padding-top: 14px;
    .logo {
      width: 140px;
      height: 62px;
      a {
        width: 140px;
        height: 62px;
      }
    }
  }
  .search-bar-container {
    height: auto;
    padding-bottom: 24px;
    padding-top: 0;
  }
}
.fast-release-button {
  .point-notice {
    position: absolute;
    width: 171px;
    top: -39px;
    left: -15px;
    background: #fef4f3;
    font-size: 12px;
    color: #666;
    border-radius: 2px;
    height: 30px;
    padding: 2px;
    line-height: 30px;
    display: flex;
    align-items: center;
    box-shadow: 1px 1px 6px #555;
    &::after {
      content: "";
      width: 8px;
      height: 8px;
      background: #fef4f3;
      position: absolute;
      bottom: -4px;
      right: 33px;
      transform: rotate(45deg);
      box-shadow: 0px 0px 2px #eaeaea;
    }
    span {
      margin-left: 6px;
      .blur {
        color: #3ca0e3;
      }
    }
    i {
      margin: 0 6px;
      font-size: 14px;
      color: #bababa;
    }
    img {
      vertical-align: middle;
      margin-left: 6px;
    }
  }
}
.right-icon {
  padding-right: 0 !important;
  text-align: right;
  p {
    height: 100%;
    line-height: 60px;
    display: inline-block;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;
    margin-left: 50px;
    background-size: contain;
  }
}
/deep/ .el-input {
  ::-webkit-input-placeholder {
    /* WebKit browsers */
    font-size: 16px;
  }

  ::-moz-placeholder {
    /* Mozilla Firefox 19+ */
    font-size: 16px;
  }

  :-ms-input-placeholder {
    /* Internet Explorer 10+ */
    font-size: 16px;
  }
}
.type9 {
  /deep/ .el-input {
    ::-webkit-input-placeholder {
      /* WebKit browsers */
      font-size: 12px;
    }

    ::-moz-placeholder {
      /* Mozilla Firefox 19+ */
      font-size: 12px;
    }

    :-ms-input-placeholder {
      /* Internet Explorer 10+ */
      font-size: 12px;
    }
  }
}
.contractName {
  line-height: 50px;
  color: #4f525a;
  font-size: 18px;
  font-weight: 700;
  width: 730px;
  overflow: hidden;
  white-space: pre;
  padding: 0;
  text-overflow: ellipsis;
  text-align: right;
}

.app-search-bar-container {
  height: 160px;
}
.app-search-bar-container-big-page {
  height: 70px;
  .bigPageTop {
    position: relative;
    width: 100%;
    margin: 0 auto;
    height: 60px;
    background: linear-gradient(134deg, #6424de 0%, #a36df8 100%);
    opacity: 1;
    .logo {
      position: absolute;
      left: 0;
      bottom: 0;
      right: 0;
      margin: auto;
      width: 1190px;
      height: 60px;
      line-height: 60px;
    }
    img {
      vertical-align: middle;
    }

    .company-info {
      display: inline-block;
      padding: 0 4px;
      font-size: 18px;
      line-height: 60px;
      vertical-align: top;
      color: #ffffff;
      .hl22 {
        line-height: 22px;
        font-size: 14px;
      }
    }
  }
  .disabled-color {
    color: #646464 !important;
  }
  .tab-btn-bg {
    transition: all 0.3s linear;
    padding: 0 12px;
    &:hover {
      background: linear-gradient(119deg, #d7b064 0%, #ecce8b 100%);
      color: #fff;
    }
  }
}
</style>