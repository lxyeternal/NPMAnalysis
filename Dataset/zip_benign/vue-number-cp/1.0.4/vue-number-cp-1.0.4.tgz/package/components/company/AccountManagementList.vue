<template>
  <div class="product">
    <div v-if="fixedhead" class="fixedhead">
      <ul class="tl">
        <li style="width:180px;">开户银行</li>
        <li style="width:86px;">&nbsp;</li>
        <li style="width:180px">银行账号</li>
        <li style="width:64px">&nbsp;</li>
        <li style="width:190px">类型</li>
        <li style="width:90px">创建时间</li>
        <li style="width:110px">&nbsp;</li>
        <li style="text-align:right;width:120px;">操作</li>
      </ul>
    </div>
    <PanelTitle title="收款账户" :titleButton="showCreateBtn" @handleOpen="handleGoDetail('','ope')"></PanelTitle>
    <div class="accout-table">
      <!-- 列表 -->
      <table>
        <!--<thead :class="{fixedhead:fixedhead}" ref="head">-->
        <thead ref="head">
        <tr class="tl">
          <td style="width:180px;">开户银行</td>
          <td style="width:86px;">&nbsp;</td>
          <td style="width:180px">银行账号</td>
          <td style="width:64px">&nbsp;</td>
          <!--<td style="width:170px" class="pointer" @click="handleSort()">创建时间-->
          <!--<i class="el-icon-caret-top active" v-if="form.sort === '1'"></i>-->
          <!--<i class="el-icon-caret-bottom active" v-if="form.sort === '2'"></i>-->
          <!--</td>-->
          <td >类型</td>
          <td style="width:90px">创建时间</td>
          <td style="width:110px">&nbsp;</td>
          <td class="tr" style="width:120px;">操作</td>
        </tr>
        </thead>
        <template v-if="accountList.length">
          <tbody v-for="(acc,index) in accountList" :key="index" class="tl tbody-row">
          <tr>
            <td style="width:180px;">
              {{acc.bankName}}
              <p class="nailsupply" v-if="acc.defaultFlg === '1'">默认账户</p>
            </td>
            <td style="width:86px;">&nbsp;</td>
            <td style="width:180px">{{acc.bankAcctNo | formatCardNum}}</td>
            <td style="width:64px">&nbsp;</td>
            <td style="width:90px">{{acc.bankAcctType == "1" ? "承兑汇票账户" : (acc.bankAcctType == "0"?"基本户":"普通账户")}}</td>
            <td  style="width:90px">
              <p>{{acc.creTm && acc.creTm.substring(0,acc.creTm.length-8)}}</p>
              <p>{{acc.creTm && acc.creTm.substring(acc.creTm.length-8,acc.creTm.length-3)}}</p>
            </td>
            <td style="width:110px">&nbsp;</td>
            <td class="tr blue" style="width:45px;">
              <span class="hand" @click="handleGoDetail(acc,'see')">查看</span>
              <br>
              <span class="hand" @click="handleGoDetail(acc,'ope')">编辑</span>
              <br>
              <span class="hand" v-if="!['0', '1'].includes(acc.bankAcctType)" @click="handleDel(acc)">删除</span>
            </td>
          </tr>
          </tbody>
        </template>
      </table>

      <!-- 空列表 -->
      <div class="accout-empty" v-if="!accountList.length&&!isLoading">
        <img src="@/assets/images/icon-no-product.png">
        <p>没有相关收款账户，请创建账户！</p>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
  import accountMixin from "@/mixins/account";
  import Loading from "@/components/base/Loading";
  import PanelTitle from "@/components/base/PanelTitle";
  import { InterfaceService } from "@/services/api";

  export default {
    mixins: [accountMixin],
    components: {
      Loading,
      PanelTitle,
    },
    data() {
      return {
        accountList: [],
        showCreateBtn: "",
        isLoading: false,
        hasTypeOne: false,
        hasTypeZero: false,
        fixedhead: false, // 是否显示固定表头
      };
    },
    computed: {
    },
    methods: {
      handleGoDetail(item,type){
        let path = "";
        if (this.role == "B") {
          path = "/purchaserCenter/bankAccountInfo"
        } else if(this.role == "S") {
          path = "/vendorCenter/bankAccountInfo"
        }
        let createType = "";
        if (item) {
          createType = item.bankAcctType;
        }else {
          createType = this.hasTypeOne ? "0" : this.hasTypeZero ? "1" : "2"
        }
        console.log(item, '--item');

        console.log(type, 'type');

        this.$router.push({
          path: path,
          query: {
            info:JSON.stringify(item || {}),
            type:type,
            createType:createType,
          },
        });
      },
      handleDel(acc){
        this.$confirm(
          "删除该收款账户后不能恢复，确定要删除吗？",
          "确认删除",
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            confirmButtonText: "确认",
            cancelButtonText: '取消',
          }).then(() => {
          this.confirmDel(acc)
        }).catch(() => {
        });
      },
      compare (obj1, obj2) {
        let val1 = obj1.creTm;
        let val2 = obj2.creTm;
        if (val1 > val2) {
          return -1;
        } else if (val1 < val2) {
          return 1;
        } else {
          return 0;
        }
      },
      confirmDel(acc){
        const params = {
          bankAcctId : acc.bankAcctId || "",
          bankAcctNo : acc.bankAcctNo || "",
          del : "1"
        };
        InterfaceService.addBankInfo(
          params,
          data => {
            if (data.respData.respCode === "0000") {
              this.dialogVisible = false;
              this.$message.success( "收款账户删除成功！")
              this.getList();
            } else {
              this.$message.error(data.respData.respMsg);
            }
          },
          data => {},
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      },
      onScroll(){
        let scrolled = document.documentElement.scrollTop || document.body.scrollTop
        this.fixedhead = scrolled >= 300;
      },
      getList() {
        InterfaceService.getBankList(
          {},
          data => {
            if (data.respData.respCode === "0000") {
              this.accountList = data.respData.bankList || [];
              let list = data.respData.bankList && data.respData.bankList.filter(item=>{return item.bankAcctType != "2"});
              this.accountList = list.sort(this.compare);
              this.hasTypeOne =  this.accountList.some(item=>{
                return item.bankAcctType == "1"
              });
              this.hasTypeZero = this.accountList.some(item=>{
                return item.bankAcctType == "0"
              });
              this.showCreateBtn = !this.hasTypeOne || !this.hasTypeZero ? "创建账户" : "";
              // this.showCreateBtn = !this.hasTypeOne || !this.hasTypeZero ? "" : "创建账户";
            } else {
              this.$message.error(data.respData.respMsg);
            }
          },
          data => {},
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      },
      init() {
        this.getList();
      },
    },
    mounted() {
      this.init();
      this.$nextTick(function () {
        setTimeout(()=>{
          window.addEventListener('scroll', this.onScroll)
        },500)
      })
    },
    destroyed: function () {
      window.removeEventListener('scroll', this.onScroll)
    }
  };
</script>

<style lang="scss" scoped>

  .product {
    position: relative;
    font-size: 14px;
  }

  .pointer {
    cursor: pointer;
    &:hover {
      color: #0082ff;
    }
    &:active {
      color: #4c9cdd;
    }

    .active {
      color: #ffd64e;
    }
  }

  .accout-table {
    /deep/ .el-table__body-wrapper {
      font-size: 12px;
    }

    /deep/ .el-table th,
    .el-table td {
      padding: 14px 0;
    }

    /deep/ .el-button {
      font-size: 12px;
    }

    table {
      width: 100%;
      line-height: 26px;
      font-size: 12px;
      table-layout: fixed;
      td {
        padding: 14px 10px;
        vertical-align: middle;
        word-break: break-word;
        span{
          display: block;
          &.hand {
            display: inline;
          }
        }
      }

      thead {
        font-size: 14px;
        text-align: center;
        white-space: nowrap;
        color: #909399;
        background: #f5f5f5;
      }

      .tbody-row:hover {
        background: #e8f3fd;
      }
      .tbody-row .nailsupply{
        display: inline-block;
        max-width: 100%;
        min-height: 14px;
        padding: 0 6px;
        line-height: 14px;
        border: 1px solid #ffa300;
        border-radius: 7px;
        color: #ffa300;
        margin-right: 6px
      }
      tbody {
        text-align: center;

        tr {
          &.sign-content {
            display: none;
            background: #f0f8ff;

            &:hover {
              display: table-row;
            }

            td {
              padding: 0;
              border-bottom: none;

            }
          }

          &.all-check {
            text-align: left;

            &:hover{
              background: #ffffff;
            }
          }
        }

        tr:hover + tr.sign-content {
          display: table-row;
        }

        td {
          border-bottom: 1px solid #ebeef5;
        }
      }
    }
  }

  .accout-empty {
    padding: 150px;
    text-align: center;
    line-height: 50px;
    color: #909399;
  }
  .fixedhead{
    width: 1020px;
    height: 30px;
    position: fixed;
    text-align: center;
    top: 0;
    z-index: 9999;
    background: #535864;
    color: #fff;
    li{
      float: left;
      line-height: 30px;
      padding: 0 10px;
      font-size: 14px;
    }
  }
</style>




