<template>
  <div>
    <PanelTitle :title="title"></PanelTitle>
    <div class="container">
      <div class="bank-content">
        <el-form ref="form" :model="bankInfo" :rules="rules" label-width="110px" size="small" v-if="operationType === 'ope'">
          <el-row>
            <el-col :span="24">
              <el-form-item label="类型：" prop="bankAcctType">
                <el-select v-if="createType == '2'" v-model="bankInfo.bankAcctType" @change="handleChange" placeholder="请选择账户类型">
                  <el-option label="基本户" value="0"></el-option>
                  <el-option label="承兑汇票账户" value="1"></el-option>
                </el-select>
                <!--<el-input :value="bankInfo.bankAcctType == '0' ? '基本户' :bankInfo.bankAcctType == '1' ? '承兑汇票账户': '普通账户'" type="text" :disabled="true"></el-input>-->
                <el-input v-else :value="createType == '1' ? '承兑汇票账户' : '基本户'" type="text" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
            <!-- <el-col :span="24">
              <el-form-item label="开户名称：" prop="bankAccRadio">
                <el-input v-model.trim=" bankInfo.bankAcctName" type="text" placeholder="请输入开户名称" maxlength="30"></el-input>
              </el-form-item>
            </el-col> -->
            <el-col :span="12">
              <el-form-item label="开户名称：" prop="bankAcctName">
                <el-input v-model.trim=" bankInfo.bankAcctName" type="text" placeholder="请输入开户名称" maxlength="30"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="开户银行：" prop="bankName">
                <el-input v-model.trim=" bankInfo.bankName" type="text" placeholder="请输入开户银行" maxlength="30"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="银行账号：" prop="bankAcctNo">
                <el-input v-model.trim=" bankInfo.bankAcctNo" @focus="handleFocus('bankAcctNo',$event)" @blur="formatCard('bankAcctNo',$event)" type="text" placeholder="请输入银行账号" maxlength="30"></el-input>
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item label="开户行行号：" prop="bankNo">
                <el-input v-model.trim=" bankInfo.bankNo" @focus="handleFocus('bankNo',$event)" @blur="formatCard('bankNo',$event)" type="text" placeholder="请输入开户行行号" maxlength="12"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <!--<el-col :span="12">-->
            <!--<el-form-item label="开户行地址：" prop="addr">-->
            <!--<el-input v-model.trim=" bankInfo.addr" type="text" placeholder="请输入开户行地址" maxlength="128"></el-input>-->
            <!--</el-form-item>-->
            <!--</el-col>-->
            <!--<el-col :span="12">-->
            <!--<el-form-item label="纳税人识别号：" prop="taxPayerId">-->
            <!--<el-input v-model.trim=" bankInfo.taxPayerId" @blur="formatCard('taxPayerId',$event)" type="text" placeholder="请输入纳税人识别号" maxlength="38"></el-input>-->
            <!--</el-form-item>-->
            <!--</el-col>-->
            <el-form-item label="开户行地址：" prop="districtCode">
              <Distpicker :address="bankInfo" @receive="getAddressCode"></Distpicker>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="" prop="addr">
              <el-input v-model.trim=" bankInfo.addr" type="text" placeholder="请输入开户行地址" maxlength="200"></el-input>
            </el-form-item>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="联系人：" prop="name">
                <el-input v-model.trim=" bankInfo.name" type="text" placeholder="请输入联系人" maxlength="30"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="联系方式：" prop="mobile">
                <el-input v-model=" bankInfo.mobile" type="text" placeholder="请输入联系方式" maxlength="30"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <!--<div class="default-flg">-->
            <!--<label><el-checkbox v-model="defaultChecked" :disabled="bankInfo.bankAcctType == 1"></el-checkbox><span>设为默认收款账户</span></label>-->
          <!--</div>-->
        </el-form>
        <div class="detail" v-if="operationType === 'see'">
          <el-row>
            <el-col :span="12">
              <label><em class="red">*</em>开户名称：</label><span>{{bankInfo.bankAcctName}}</span>
            </el-col>
            <el-col :span="12">
              <label><em class="red">*</em>开户银行：</label><span>{{bankInfo.bankName}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <label><em class="red">*</em>开户行地址：</label><span>{{bankInfo.provCodeDisp}}{{bankInfo.cityCodeDisp}}{{bankInfo.districtCodeDisp}}{{bankInfo.addr}}</span>
            </el-col>
            <el-col :span="12">
              <label><em class="red">*</em>开户行行号：</label><span>{{bankInfo.bankNo | formatCardNum}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <label><em class="red">*</em>银行账号：</label><span>{{bankInfo.bankAcctNo | formatCardNum}}</span>
            </el-col>
            <el-col :span="12">
              <label><em class="red">*</em>纳税人识别号：</label><span>{{bankInfo.taxPayerId}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <label><em class="red">*</em>联系人：</label><span>{{bankInfo.name}}</span>
            </el-col>
            <el-col :span="12">
              <label><em class="red">*</em>联系方式：</label><span>{{bankInfo.mobile | formatPhoneNumber("3 4 4")}}</span>
            </el-col>
          </el-row>
          <!-- <el-row>
                        <el-col :span="12">
                            <label><em class="red">*</em>类型：</label><span>{{bankInfo.bankAcctType == "1" ? "承兑汇票账户" : (bankInfo.bankAcctType == "0"?"基本户":"普通账户")}}</span>
                        </el-col>
                    </el-row> -->
        </div>
      </div>
      <div slot="footer" class="footer">
        <el-button v-if="operationType === 'ope'" type="primary" size="small" style="width: 150px" @click="handleConfirm()">提交</el-button>
        <el-button size="small" style="width: 150px" @click="handleCancel()">{{operationType === "ope" ? "取消" : "返回列表"}}</el-button>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import PanelTitle from "@/components/base/PanelTitle";
import Distpicker from "@/components/base/Distpicker";

const validateSupplierInfo = (rule, value, callback) => {
  if (!value) {
    return callback(new Error("信息填写有误，请输入内容"));
  } else {
    callback();
  }
};
const validatebankAcctNo = (rule, value, callback) => {
  value = value && value.replace(/\s+/g, "");
  const reg = new RegExp(/^[0-9]{0,30}$/);
  if (!value || !reg.test(value)) {
    return callback(new Error("银行账号格式错误，必须为数字"));
  } else {
    callback();
  }
};
const validateTaxPayer = (rule, value, callback) => {
  value = value && value.replace(/\s+/g, "");
  const reg = new RegExp(/^[0-9a-zA-Z]{15,20}$/);
  if (!value || !reg.test(value)) {
    return callback(new Error("识别号格式错误，15到20位字母或数字"));
  } else {
    callback();
  }
};
const validatebankNo = (rule, value, callback) => {
  value = value && value.replace(/\s+/g, "");
  const reg = new RegExp(/^[0-9]{12}$/);
  if (!value || !reg.test(value)) {
    return callback(new Error("银行行号有误，请填写12位数字"));
  } else {
    callback();
  }
};
const validateMobile = (rule, value, callback) => {
  const reg = new RegExp(/^[1][0-9][0-9]{9}$/);                    // 手机
  const reg1 = new RegExp(/^[\d-\s\(\)\+\,]*$/); // 座机
  if (!reg.test(value) && !reg1.test(value)) {
    return callback(new Error("联系电话格式错误，请填写手机号或座机"));
  } else {
    callback();
  }
};
const bankInfo = {
  bankAcctName: "",
  bankName: "",
  bankAcctNo: "",
  taxPayerId: "",
  provCode: "",
  cityCode: "",
  blockCode: "",
  districtCode: "",
  addr: "",
  bankNo: "",
  name: "",
  mobile: "",
  defaultFlg: "0",
};
export default {
  components: {
    PanelTitle,
    Loading,
    Distpicker,
  },
  computed: {

  },
  data() {
    return {
      title: '创建账户',
      isLoading: false,
      defaultChecked: false,
      bankInfo: Object.assign({}, bankInfo),
      operationType: "",
      createType: "",
      bankAccRadio: '0',
      rules: {
        bankAcctName: [
          {
            required: true,
            message: "请输入开户名称，限制30字",
            trigger: ['blur']
          },
          { validator: validateSupplierInfo, trigger: ['blur'] }
        ],
        bankName: [
          {
            required: true,
            message: "请输入开户银行，限制20字",
            trigger: ['blur']
          },
          { validator: validateSupplierInfo, trigger: ['blur'] }
        ],
        bankAcctNo: [
          {
            required: true,
            message: "请输入银行账号",
            trigger: ['blur']
          },
          { validator: validatebankAcctNo, trigger: ['blur'] }
        ],
        bankNo: [
          {
            required: true,
            message: "请输入开户行行号，限制12位数字",
            trigger: ['blur']
          },
          { validator: validatebankNo, trigger: ['blur'] }
        ],
        bankAcctType: [
          {
            required: true,
            message: "请选择账户类型",
            trigger: ['change']
          },
        ],
        taxPayerId: [
          {
            required: true,
            message: "请输入纳税人识别号",
            trigger: ['blur']
          },
          { validator: validateTaxPayer, trigger: ['blur'] }
        ],
        addr: [
          {
            required: true,
            message: "请填写地址",
            trigger: ['blur']
          },
          { validator: validateSupplierInfo, trigger: ['blur'] }
        ],
        districtCode: [
          {
            required: true,
            message: "请选择地址信息"
          }
        ],
        name: [

          { required: true, message: "请输入联系人", trigger: ['blur'] },
          { validator: validateSupplierInfo, trigger: ['blur'] }
        ],
        mobile: [
          {
            required: true,
            message: "请输入联系电话",
            trigger: ['blur']
          },
          { validator: validateMobile, trigger: ['blur'] }
        ]
      },
    };
  },
  methods: {
    handleChange(ev) {
      console.log(ev);
      console.log(this.bankInfo.bankAcctType);
      if (this.bankInfo.bankAcctType == "1") {
        this.defaultChecked = false
      } else {
        this.defaultChecked = this.bankInfo.defaultFlg === "1"
      }
      this.$forceUpdate()
    },
    handleConfirm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          this.bankInfo.bankAcctNo = this.bankInfo.bankAcctNo && this.bankInfo.bankAcctNo.replace(/\s+/g, "");
          this.bankInfo.bankNo = this.bankInfo.bankNo && this.bankInfo.bankNo.replace(/\s+/g, "");
          // this.bankInfo.defaultFlg = this.defaultChecked ? "1" : "0";
          const params = Object.assign({}, this.bankInfo);
          if (params.districtCode == 'noCode') {
            delete params.districtCode
          }
          params.bankAcctType = this.bankInfo.bankAcctType || this.createType;
          params.defaultFlg = params.bankAcctType == "0" ? "1" : "0"
          // params.bankAcctType = "2"

          InterfaceService.addBankInfo(
            params,
            data => {
              if (data.respData.respCode === "0000") {
                this.dialogVisible = false;
                this.$message.success(this.bankInfo.bankAcctId ? "编辑账户成功！" : "新增账户成功！")
                this.handleCancel();
              } else {
                this.$message.error(data.respData.respMsg);
              }
            },
            data => { },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            }
          );
        }
      });
    },
    getAddressCode(res) {
      this.$set(this.bankInfo, "provCode", res.provinceCode);
      this.$set(this.bankInfo, "cityCode", res.cityCode);
      this.$set(this.bankInfo, "districtCode", res.blockCode);
    },
    handleCancel() {
      this.$router.go(-1)
    },
    formatCard(type, ev) {
      //   this.bankInfo[type] = this.bankInfo[type] && this.bankInfo[type].replace(/\s+/g, "").replace(/(.{4})/g, "$1 ");
      //   if (ev && ev.target.value == "") {
      //     this.bankInfo[type] = null
      //   }
    },
    handleFocus(type, ev) {
      this.bankInfo[type] = this.bankInfo[type] && this.bankInfo[type].replace(/\s+/g, "")
      if (ev && ev.target.value == "") {
        this.bankInfo[type] = null
      }
    },
    init() {
      this.operationType = this.$route.query.type || "";
      this.createType = this.$route.query.createType || "";
      let info = eval('(' + this.$route.query.info + ')');
      if (this.createType != "2") {
        this.bankInfo.bankAcctType = this.createType;
      }
      this.bankInfo = Object.assign(this.bankInfo, info);
      if (this.bankInfo.districtCode) {
        this.bankInfo.blockCode = this.bankInfo.districtCode;
      }
      if (this.operationType === "ope") {
        if (!this.bankInfo.bankAcctId) {
          this.title = "创建账户"
        } else {
          this.title = "编辑账户"
        }
        this.defaultChecked = this.bankInfo.defaultFlg === "1"
      } else {
        this.title = "查看账户"
      }
      this.formatCard('bankAcctNo');
      this.formatCard('bankNo');
    }
  },
  mounted() {
    this.init();
  }
};
</script>

<style lang="scss" scoped>
/deep/ .el-form-item__label {
  font-size: 12px;
}

/deep/ .el-form-item--mini.el-form-item {
  margin-bottom: 0;
}
.pointer {
  color: #0082ff;
}

.container {
  padding: 0 15px 20px;
}

.bank-title {
  padding-bottom: 20px;
  border-bottom: 1px solid #ececec;
}

.bank-title-label {
  width: 150px;
  display: inline-block;
}

.bank-content {
  color: #3a3a3a;
  margin: 10px 0;
  padding-bottom: 10px;
  font-size: 14px;
  .el-col-12 {
    line-height: 20px;
    margin-bottom: 10px;
  }
  .detail {
    em {
      margin-right: 4px;
    }
    span {
      word-break: break-word;
    }
    span {
      color: #444;
    }
  }
}

.footer {
  text-align: center;
}
.default-flg {
  text-align: left;
  height: 25px;
  line-height: 25px;
  padding-left: 10px;
  background-color: #eeeeee;
  span {
    margin-left: 6px;
  }
}
</style>
