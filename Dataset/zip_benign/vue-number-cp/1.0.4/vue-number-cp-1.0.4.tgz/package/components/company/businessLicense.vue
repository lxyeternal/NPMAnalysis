<template>
  <div class="businessLicense">
    <el-dialog class="dialog dialog-drafts" title="编辑营业执照" :append-to-body="true" :lock-scroll="true" :visible.sync="showRelease" width="850px" center :close-on-click-modal="false" :show-close="false" @close="close">
      <div class="drafts-list">
        <div class="form-upload-text">
          <span><i class="red">*</i> 营业执照：请上传工商营业执照、组织机构代码证、税务登记证或三证合一的营业执照 (单张图片大小不超过1M，建议方形尺寸500*500，jpg或png格式)</span>
        </div>
        <div class="form-upload-content">
          <el-form ref="form" label-width="0px">
            <el-form-item label="">
              <div class="info-master-img tc">
                <div class="img-item" :class="{ 'has-img': img.previewSrcr }" v-for="(img, index) in imgList" :key="index">
                  <div class="img-item-cover">
                    <div class="img-item-add">
                      <label :for="'masterImg' + index">
                        <i class="el-icon-plus"></i>
                      </label>
                      <img v-if="img.previewSrcr" :src="img.previewSrcr" />
                      <input :disabled='img.file != ""' :id="'masterImg' + index" type="file" @change="pushImg($event, index)" />
                    </div>
                    <div class="img-item-bottom" v-if="img.previewSrcr">
                      <a @click="clearImg(index)">删除</a>
                      <a @click="reviewImg(img)">预览</a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="el-form-item__error">{{ imgError }}</div>
            </el-form-item>
          </el-form>
        </div>
        <div slot="footer" class="tc">
          <el-button class="normal-btn" type="primary" :disabled="imgList.length < 2" @click="submit()">提交</el-button>
          <el-button class="normal-btn" @click="showRelease=false">取消</el-button>
        </div>
      </div>
    </el-dialog>
    <!-- 预览图片 -->
    <el-dialog title="图片预览" :visible.sync="dialogVisible" class="img-preview" width="840px">
      <div class="img-box">
        <img :src="dialogVisibleAttachUrl" alt="" />
      </div>
      <div class="shut-down hand" @click="dialogVisible=false">关闭</div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
export default {
  components: {
    Loading,
  },
  data() {
    return {
      isLoading: false,

      dialogVisible: false,
      dialogVisibleAttachUrl: '',
      showRelease: false,

      isFirstSubmit: true,
      imgError: '',
      imgList: [
        { 'previewSrcr': '', 'file': '', },
      ],
      delImgList: [],
      attachList: [],
      propCorpId: '', // 外部传入 corpId
    }
  },
  computed: {

  },
  methods: {
    clearImg(index) {
      this.isFirstSubmit = false;//上传过 则此标记为false
      // 存储被删除的ID
      if (this.imgList[index].id) {
        this.delImgList.push({ attachId: this.imgList[index].id });
      }
      let threeIpt = this.imgList.every((item) => {
        return item.file !== "" || item.previewSrcr !== ""
      });
      if (threeIpt && this.imgList.length == 3) {
        this.imgList.splice(index, 1, { 'previewSrcr': '', 'file': '', })
      } else {
        this.imgList.splice(index, 1)
      }
      // this.imgList[index] = { 'previewSrcr': '', 'file': '',}
      this.$forceUpdate();
      //清空input[file]
      let file = document.getElementById("masterImg" + index)
      file.value = "";

    },
    reviewImg(item) {
      this.dialogVisibleAttachUrl = item.previewSrcr
      this.dialogVisible = true
    },
    pushImg(event, index) {//input控件（自定义）获取文件 上传
      let _this = this;
      _this.isFirstSubmit = true;//更改过图片 则视为第一次提交（需要上传图片)
      let file = event.target.files[0]
      if (file) {
        let checkTextList = JSON.parse(sessionStorage.getItem('checkTextList') || '[]');
        let onOff = false;
        let forbidText = ''
        checkTextList.forEach(i => {
          if (i != '' && file.name.indexOf(i) != -1) {
            onOff = true
            forbidText = i
          }
        });
        if (onOff) {
          this.$message.error('文件名包含特殊字符【' + forbidText + '】,请修改文件名后再上传')
          return false
        }
        _this.imgError = ''
        // 判断是否图片
        if ((file.type).indexOf("image/") == -1) {
          _this.imgError = '请选择图片!'
          return false
        }

        let fSize = Math.round(file.size / 1024 * 100) / 100;//取得图片文件的大小
        if (fSize >= 1024) {//单位为KB
          _this.imgError = '照片最大尺寸为1024KB，请重新上传!'
          return false
        }

        for (var i in _this.imgList) {
          // name: "building.png"
          // size: 2731
          // type: "image/png"
          let cImg = _this.imgList[i] && _this.imgList[i].file

          if (cImg) {
            if (file.name == cImg.name && file.size == cImg.size && file.type == cImg.type) {
              _this.imgError = '图片已经存在，请重新选择!'
              return false
            }
          }
        }

        let reader = new FileReader();
        reader.onloadend = function () {
          _this.imgList[index].previewSrcr = reader.result
          _this.imgList[index].file = file
          // _this.attachList.push({
          //   'attachURL': file,
          //   'attachType': "0",
          // })
          if (_this.imgList.length < 3) {
            _this.imgList.push({ 'previewSrcr': '', 'file': '', })
          }
          _this.$forceUpdate();
          _this.$set(_this.imgList, _this.imgList);
          console.log(_this.imgList)
          // _this.$set(_this.form, _this.form);

        }
        if (file) {
          reader.readAsDataURL(file);
        } else {
          _this.previewSrcr = "";
        }
      } else {
        _this.imgError = '图片获取错误'
      }
    },
    uploadHander(pos, file, dirType, signature, callBack) {
      let _this = this;
      //去后端拿签名
      InterfaceService.uploadToOss(signature, file, dirType, pos, callBack)
    },
    submit() {
      let _this = this;
      let _loadImg = []
      let upLoadState = false; // 是否提示 - 请上传图片附件
      for (var i = 0; i < _this.imgList.length; i++) {
        if (!_this.imgList[i].id) {
          let file = _this.imgList[i] && _this.imgList[i].file
          if (file) {
            _loadImg.push(_this.imgList[i])
          }
        }
      }

      _this.imgList.forEach(item => {
        if (!!item.id) {
          upLoadState = true;
        }
      })
      if (!upLoadState && _loadImg.length == 0) {
        _this.imgError = '请上传图片附件'
        return false
      }
      _this.attachList = []

      if (_this.isFirstSubmit) {
        // 如果loadImg长度为0 , 说明用的是反显数据图片, 直接提交
        if (_loadImg.length === 0) {
          _this.submitImg()
          return
        }
        //先上传图片
        //去后端拿签名一次性
        InterfaceService.getOssSignatureDisposable('', {}, (data) => {
          console.log(_loadImg);
          let signature = data
          for (var pos = 0; pos < _loadImg.length; pos++) {
            let file = _loadImg[pos] && _loadImg[pos].file
            let fileFlag = false;
            _loadImg[pos].attachName ? fileFlag = true : fileFlag = false
            if (file) {
              let dirType = 'company/'
              _this.uploadHander(pos, file, dirType, signature, (pos, file, dirType, signature) => {
                let u = "#url#" + '/' + signature.dir + dirType + file.name
                if (!fileFlag) {
                  _this.attachList.push({
                    'attachContent': u,
                    'attachType': "0",
                  })
                }
                //图片上传到oss之后 提交注册信息
                if (pos >= _loadImg.length - 1) {
                  setTimeout(() => {
                    _this.submitImg()
                  }, 800)
                }
              })
            }
          }

          console.log(_this.form, '---_this.form');


        }, (data) => {
          _this.isLoading = false;
        },
          () => {
            _this.isLoading = true;
          },
          () => {
            //_this.isLoading = false;
          });


      } else {

        _this.isLoading = false;
        _this.submitImg()
      }
    },
    submitImg() {
      let bs = this.$store.state.userInfo.bs
      let acCorpAttachInfoList = []
      acCorpAttachInfoList = this.attachList.concat(this.delImgList)
      let params = {
        corpId: this.propCorpId || this.$store.state.userInfo.corpId,
        acCorpAttachInfoList: acCorpAttachInfoList
      }
      InterfaceService[bs == 'B' ? 'rejectUpdatePurchaser' : 'rejectUpdateSupplier'](params, (data) => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('提交成功')
          this.showRelease = false
          this.$emit('upData')
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => { }, () => { this.isLoading = true; }, () => { this.isLoading = false; });
    },
    close() {
      this.imgList = [
        { 'previewSrcr': '', 'file': '', },
      ]
      this.delImgList = []
      this.attachList = []
    },
    open(dataList = [], propCorpId) {
      this.propCorpId = propCorpId || ''
      console.log(dataList)
      this.showRelease = true
      if (dataList.length) {
        // this.imgList = []
        this.imgList = dataList.map(item => {
          return {
            previewSrcr: item.attachContent,
            id: item.attachId || '',
            file: '',
          }
        })
        if (this.imgList.length < 3) {
          this.imgList.push({ 'previewSrcr': '', 'file': '', })
        }
      }
    }
  },
}
</script>
<style lang="scss" scoped>
.dialog-drafts {
  /deep/ .el-dialog__body {
    padding: 20px 20px 30px !important;
  }
  line-height: 17px;
}
.form-upload-text {
  line-height: 17px;
  font-size: 12px;
  color: #888;
  margin-bottom: 20px;

  .form-upload-text-left {
    display: inline-block;
    width: 134px;
    padding-right: 12px;
    text-align: right;
  }
  .form-upload-text-right {
    display: inline-block;
    width: 100%;
    padding-left: 195px;
  }
}
.form-upload-content {
  margin-bottom: 22px;
}
.info-master-img {
  .img-item {
    position: relative;
    display: inline-block;
    width: 120px;
    height: 120px;
    vertical-align: middle;
    margin-right: 20px;
    border: 1px dashed #ccc;
    border-radius: 2px;
  }

  .img-item-add {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100%;
    font-size: 30px;
    text-align: center;
    color: #ccc;
    position: relative;
    overflow: hidden;
    i {
      cursor: pointer;
    }

    input[type="file"] {
      display: none;
    }

    img {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      pointer-events: none;
    }
  }

  .img-item-cover {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(255, 255, 255, 0);

    .img-item-top,
    .img-item-bottom {
      display: none;
      position: absolute;
      width: 100%;
      padding: 10px;
      text-align: center;
      background: rgba(167, 166, 166, 0.2);
    }

    .img-item-top {
      top: 0;
    }

    .img-item-bottom {
      bottom: 0;
      padding: 0 10px;

      a {
        display: inline-block;
        width: 46%;
        padding: 10px 5px;
        vertical-align: middle;
        color: rgb(88, 167, 231);
      }
    }
  }

  .img-item:hover {
    .img-item-cover {
      background: rgba(255, 255, 255, 0.2);
    }

    .img-item-top,
    .img-item-bottom {
      display: block;
    }
  }

  img {
    width: 100%;
    height: 100%;
    border: none;
  }

  .img-item.has-img {
    border: none;

    .img-item-add {
      //display: none;
    }

    &:hover .img-item-add {
      display: flex;
    }
  }
}
/deep/ .img-preview {
  .el-dialog__body {
    padding: 10px 20px 80px;
  }
  .img-box {
    max-height: 500px;
    overflow: hidden;
    overflow-y: scroll;
    text-align: center;
    img {
      max-width: 800px;
    }
  }
  .shut-down {
    width: 120px;
    height: 34px;
    line-height: 34px;
    padding: 0;
    font-size: 12px;
    text-align: center;
    color: #fff;
    background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
    margin: 0 auto;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 30px;
  }
}
</style>