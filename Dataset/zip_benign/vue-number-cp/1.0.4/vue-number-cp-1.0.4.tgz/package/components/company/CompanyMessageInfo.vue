<template>
  <div id="company-message">
    <Breadcrumb v-if="breadcrumb && breadcrumb.length" :breadcrumbList="breadcrumb" @refresh="handleGoBack()"></Breadcrumb>
    <div class="purchaser-company-information">
      <div class="company-information" v-if="path != 'authorizeBsListDetails'">
        <div class="order-info-title">公司信息</div>
        <ul class="company-top">

          <li>
            <div class="company-left">
              <span>公司名称：</span>
              <div class="company-showtext">{{acCorpInfoBean.corpName}}</div>
            </div>

            <div class="company-left">
              <span>统一社会信用代码：</span>
              <div class="company-showtext">{{acCorpInfoBean.busiLicense}}</div>
            </div>
            <div style="clear:both;"></div>
          </li>
          <li>
            <div class="company-left">
              <span>法人代表：</span>
              <div class="company-showtext">{{acCorpInfoBean.legalRepresent}}</div>
            </div>

            <div class="company-left">
              <span> 注册资本：</span>
              <div class="company-showtext" v-if="!isNaN(Number(acCorpInfoBean.registCapital))">{{acCorpInfoBean.registCapital | formatMoney}}万元</div>
              <div class="company-showtext" v-else>{{acCorpInfoBean.registCapital}}</div>
            </div>

            <div style="clear:both;"></div>
          </li>
          <li>
            <div style="clear:both;"></div>
            <div class="company-left">
              <span>企业类型：</span>
              <div class="company-showtext">{{acCorpInfoBean.corpTypeDisp}}</div>
            </div>
            <div class="company-left">
              <span>成立日期：</span>
              <div class="company-showtext">{{acCorpInfoBean.establishDtStr}}</div>
            </div>
          </li>
          <li>

            <div style="clear:both;"></div>
            <div class="company-left">
              <span>公司简称：</span>
              <div class="company-showtext">{{acCorpInfoBean.shortCorpName || '无'}}</div>
            </div>

            <div class="company-left">
              <span> 上级公司名称：</span>
              <div class="company-showtext">{{acCorpInfoBean.supCorpName}}</div>
            </div>
            <div style="clear:both;"></div>
          </li>
          <li>
            <div style="clear:both;"></div>
            <div class="company-left">
              <span>营业期限：</span>
              <div class="company-showtext">{{companyInfoBean.dealFromStr}}~{{companyInfoBean.dealToStr}}</div>
            </div>
            <div style="clear:both;"></div>
          </li>
          <li v-if="currentRole == 'S' && categoryNameList && categoryNameList.length">
            <div class="company-left one">
              <span>产品品类：</span>
              <div class="company-showtext">{{categoryNameList.join('、')}}</div>
            </div>
            <div style="clear:both;"></div>
          </li>
          <li>
            <div class="company-left">
              <span>营业执照：</span>
              <div>
                <div class="company-img" v-for="(item,index) in acCorpAttachInfoList" :key="index">
                  <img width="122" :src="item.attachContent" @click="showBigImg(index)" />
                  <el-dialog width="840px" title="" :visible.sync="item.dialogVisible">
                    <img :src="item.attachContent" alt="">
                  </el-dialog>
                </div>
              </div>
            </div>
            <div class="company-left" v-if="currentRole == 'B'">
              <span>所属事业部：</span>
              <div class="company-showtext">{{companyInfoBean.groupCompanyName}}</div>
            </div>
            <div style="clear:both;"></div>
          </li>
        </ul>
        <template v-if="brandList && brandList.length">
          <div class="line"></div>
          <div class="purchaser-company-information">
            <div class="order-info-title">经营品牌</div>
            <ul class="brand-container-ul" :class="{p0: idx==0, m0: idx==0}" v-for="(item, idx) in brandList" :key="idx">
              <li>
                <div class="head-title">
                  经营品牌{{idx + 1}}
                </div>
              </li>
              <li class="brand-li-body">
                <div class="brand-left">
                  <div><span class="title">品牌中文名：</span>{{item.brandNameCn}}</div>
                  <div><span class="title">品牌英文名：</span>{{item.brandNameEn}}</div>
                </div>
                <div class="brand-right">
                  <div class="title">品牌logo：</div>
                  <div class="logo-img-center hand">
                    <img :src="item.logoDisplayUrl" @click="item.logoDisplayUrl && (item.dialogVisible = true)">
                    <el-dialog width="840px" title="" :visible.sync="item.dialogVisible">
                      <img :src="item.logoDisplayUrl" alt="">
                    </el-dialog>
                  </div>
                </div>
              </li>
            </ul>
          </div>
          <div class="line"></div>
        </template>
      </div>
      <div class="company-address" v-if="path != 'authorizeBsListDetails'">
        <div class="order-info-title">
          公司地址
        </div>
        <ul class="company-top">
          <li class="clearfloat">
            <div class="company-left one">
              <span>工商注册地址：</span>
              <div class="company-showtext" v-html="region('reg')"></div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left one">
              <span>办公地址：</span>
              <div class="company-showtext" v-html="region('office')"></div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>邮编：</span>
              <div class="company-showtext">{{corpAddrInfo.officeZipCode}}</div>
            </div>
            <div class="company-left">
              <span>电话号码：</span>
              <div class="company-showtext">{{corpAddrInfo.officeTelNumber}}</div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span> 传真号码：</span>
              <div class="company-showtext">{{corpAddrInfo.officeFaxNumber}}</div>
            </div>
          </li>
        </ul>
        <div class="line"></div>
      </div>
      <!-- <admin-information :adminInfo="adminInfo" :title="'管理员账户信息'" :path="path"></admin-information> -->
      <!-- <div class="line" v-if="currentRole == 'B' && path != 'authorizeBsListDetails'"></div> -->
      <div class="company-address" :class="{pad_bottom:path == 'authorizeBsListDetails'}">
        <div class="order-info-title">{{path == 'authorizeBsListDetails'?'原管理员账户信息':'管理员账户信息'}}</div>
        <!-- <ul class="company-top" v-if="path == 'authorizeBsListDetails'">
          <li class="clearfloat">
            <div class="company-left">
              <span>姓名：</span>
              <div class="company-showtext">{{adminInfo.name || "无"}}</div>
            </div>
            <div class="company-left">
              <div class="company-left" style="width: auto;height: 26px;">
                <span>授权书：</span>
                <div class="company-showtext a-text" :title="adminInfo.authorizationName">{{adminInfo.authorizationName}}</div> <i style="padding-left: 10px;" class="fr hand blue" @click="handleOpenAuthorization">查看</i>
              </div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>手机号：</span>
              <div class="company-showtext">{{adminInfo.mobile || "无"}}</div>
            </div>
            <div class="company-left">
              <span>邮箱：</span>
              <div class="company-showtext">{{adminInfo.email || "无"}}</div>
            </div>
          </li>
          <li class="clearfloat" v-if="contractCorpType == 'broker'">
            <div class="company-left">
              <span>身份证号：</span>
              <div class="company-showtext">{{adminInfo.certNo || "无"}}</div>
            </div>
          </li>
        </ul> -->
        <ul class="company-top">
          <li class="clearfloat">
            <div class="company-left">
              <span>姓名：</span>
              <div class="company-showtext">{{adminInfo.name || "无"}}</div>
            </div>
            <div class="company-left">
              <div class="company-left" style="width: auto;height: 26px;">
                <span>授权书：</span>
                <div class="company-showtext a-text" :title="adminInfo.authorizationName">{{adminInfo.authorizationName}}</div> <i style="padding-left: 10px;" class="fr hand blue" @click="handleOpenAuthorization">查看</i>
              </div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>手机号：</span>
              <div class="company-showtext">{{adminInfo.mobile || "无"}}</div>
            </div>
            <div class="company-left">
              <span>邮箱：</span>
              <div class="company-showtext">{{adminInfo.email || "无"}}</div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>部门：</span>
              <div class="company-showtext">{{adminInfo.department || "无"}}</div>
            </div>
            <div class="company-left">
              <span>职位：</span>
              <div class="company-showtext">{{adminInfo.position || "无"}}</div>
            </div>
          </li>
          <li class="clearfloat" v-if="contractCorpType == 'broker'">
            <div class="company-left">
              <span>身份证号：</span>
              <div class="company-showtext">{{adminInfo.certNo || "无"}}</div>
            </div>
          </li>
        </ul>
        <div class="line"></div>
      </div>
      <div class="company-address" v-if="currentRole == 'B' && path != 'authorizeBsListDetails'">
        <div class="order-info-title">
          开票信息
          <!-- <span style="padding-left: 10px;" class="blue hand" @click="handleChangeInvoiceType">变更信息</span> -->
        </div>
        <ul class="company-top">
          <li class="clearfloat">
            <div class="company-left">
              <span>票种：</span>
              <div class="company-showtext">{{getTicketTypeComputed}}</div>
            </div>
          </li>
        </ul>
        <div class="line"></div>
      </div>
      <!-- <div class="company-address" v-if="path != 'authorizeBsListDetails'">
        <div class="order-info-title">
          银行信息
        </div>
        <ul class="company-top">
          <li class="clearfloat">
            <h3 class="f14" style="color: #444;font-weight: bold;margin-bottom:10px">基本户</h3>
            <div class="company-left">
              <span>基本户开户名称：</span>
              <div class="company-showtext">{{corpFinInfo.bankAcctName}}</div>
            </div>
            <div class="company-left">
              <span>基本户开户银行：</span>
              <div class="company-showtext">{{corpFinInfo.bankName}}</div>
            </div>
            <div class="company-left">
              <span>基本户开户行地址：</span>
              <div class="company-showtext">{{String(corpFinInfo.bankCompleteAddr).replace(/null/g, '')}}</div>
            </div>
            <div class="company-left">
              <span>基本户开户行行号：</span>
              <div class="company-showtext">{{corpFinInfo.bankCode | formatCardNum}}</div>
            </div>
            <div class="company-left">
              <span>基本户银行账号：</span>
              <div class="company-showtext">{{corpFinInfo.bankAcct | formatCardNum}}</div>
            </div>
            <div class="company-left">
              <span>基本户纳税人识别号：</span>
              <div class="company-showtext">{{corpFinInfo.taxPayerId}}</div>
            </div>
            <div class="company-left">
              <span>基本户联系人：</span>
              <div class="company-showtext">{{corpFinInfo.contact}}</div>
            </div>
            <div class="company-left">
              <span>基本户联系方式：</span>
              <div class="company-showtext">{{corpFinInfo.contactMobile}}</div>
            </div>
          </li>
          <li class="clearfloat" v-if="corpFinInfo.bankNameBA" style="border-top: 1px dashed #eeeeee;margin-top:20px;padding-top:20px">
            <h3 class="f14" style="color: #444;font-weight: bold;margin-bottom:10px">承兑汇票</h3>
            <div class="company-left">
              <span>承兑汇票开户名称：</span>
              <div class="company-showtext">{{corpFinInfo.bankAcctNameBA}}</div>
            </div>
            <div class="company-left">
              <span>承兑汇票开户银行：</span>
              <div class="company-showtext">{{corpFinInfo.bankNameBA}}</div>
            </div>
            <div class="company-left">
              <span>承兑汇票开户行地址：</span>
              <div class="company-showtext">{{String(corpFinInfo.bankCompleteAddrBA).replace(/null/g, '')}}</div>
            </div>
            <div class="company-left">
              <span>承兑汇票开户行行号：</span>
              <div class="company-showtext">{{corpFinInfo.bankCodeBA | formatCardNum}}</div>
            </div>
            <div class="company-left">
              <span>承兑汇票银行账号：</span>
              <div class="company-showtext">{{corpFinInfo.bankAcctBA | formatCardNum}}</div>
            </div>
            <div class="company-left">
              <span>承兑汇票纳税人识别号：</span>
              <div class="company-showtext">{{corpFinInfo.taxPayerId}}</div>
            </div>
            <div class="company-left">
              <span>承兑汇票联系人：</span>
              <div class="company-showtext">{{corpFinInfo.contactBA}}</div>
            </div>
            <div class="company-left">
              <span>承兑汇票联系方式：</span>
              <div class="company-showtext">{{corpFinInfo.contactMobileBA}}</div>
            </div>
          </li>
        </ul>
      </div> -->

      <div class="purchaser-company-information invoice-info-container" v-if="taxClassifyList && taxClassifyList.length">
        <div class="order-info-title">开票信息</div>
        <ul class="brand-container-ul">
          <li>
            <div class="head-title">
              发票类型
            </div>
            <div class="body-invoice-info">
              <span class="title">票种：</span>
              {{getTicketTypeComputed}}
            </div>
          </li>
          <li>
            <div class="head-title">
              货物与应税劳务
            </div>
            <div class="milling-body-head">
              <el-row>
                <el-col :span="9">
                  货物或应税劳务分类
                </el-col>
                <el-col :span="3">
                  税率
                </el-col>
                <el-col :span="12">
                  备注
                </el-col>
              </el-row>
            </div>
            <div class="milling-body-center">
              <el-row v-for="(item, idx) in taxClassifyList" :key="idx">
                <el-col :span="9" class="remark" :title="item.classify">
                  {{item.classify}}
                </el-col>
                <el-col :span="3" class="remark" :title="`${item.tax}%`">
                  {{item.tax}}%
                </el-col>
                <el-col :span="12" class="remark" :title="item.remark">
                  {{item.remark}}
                </el-col>
              </el-row>
            </div>
          </li>
        </ul>
      </div>

    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import Loading from '@/components/base/Loading'
import adminInformation from '@/components/purchaser/adminInformation'
import { InterfaceService } from '@/services/api'
import { viewFile } from '@/utils/orderUtil';
import accountMixin from "@/mixins/account";
import Distpicker from "@/components/base/Distpicker";
import Breadcrumb from "@/components/base/Breadcrumb";

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    adminInformation,
    Distpicker,
    Breadcrumb,
  },
  data() {
    return {
      corpId: '',
      isLoading: false,
      officeSelectedFlg: true,
      invoiceType: '',
      // currentRole: '',
      acCorpInfoType: '',
      acCorpInfoBean: {},
      initOfficeInfo: {},
      adminInfo: {},
      companyInfoBean: {},
      corpAddrInfo: {},
      corpContact: {},
      purchaseContact: {},
      corpFinInfo: {},
      formAddr: {},
      acCorpAttachInfoList: [],
      categoryNameList: [],
      brandList: [],
      authorizationName: "",
      authorizationUrl: "",
      contractCorpType: '',
      taxClassifyList: [],
    }
  },
  props: ['breadcrumb', 'companyCorpId', 'currentRole', 'path'],
  computed: {
    userInfo() {
      return this.$store.state.userInfo
    },
    getTicketTypeComputed() {
      return this.corpFinInfo.invoiceName || ''
    },
    region() {
      return function (type) {
        if (type == 'reg') {
          return `${this.corpAddrInfo.regProvCodeDisp || ""}&nbsp;&nbsp;${this.corpAddrInfo.regCityCodeDisp || ""}&nbsp;&nbsp;${this.corpAddrInfo.regDistrictCodeDisp || ''}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;${this.corpAddrInfo.regDetailAddr || ""}`
        } else {
          return `${this.corpAddrInfo.officeProvCodeDisp || ""}&nbsp;&nbsp;${this.corpAddrInfo.officeCityCodeDisp || ""}&nbsp;&nbsp;${this.corpAddrInfo.officeDistrictCodeDisp || ''}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;${this.corpAddrInfo.officeDetailAddr || ""}`
        }
      }
    }
  },
  methods: {
    //   handleChangeInvoiceType() {
    //     this.invoiceType = this.corpFinInfo.invoiceType;
    //     window.scrollTo(0,0)
    //   },
    handleGoBack() {
      this.$router.go(-1);
    },
    handleOpenAuthorization() {
      if (this.adminInfo.authorizationUrl) {
        viewFile(this.adminInfo.authorizationUrl)
      } else {
        this.$message.error("暂无预览地址")
      }
    },
    handleChangeAddr() {
      this.initOfficeInfo = {
        provCode: this.corpAddrInfo.officeProvCode,
        cityCode: this.corpAddrInfo.officeCityCode,
        blockCode: this.corpAddrInfo.officeDistrictCode
      };
      this.formAddr = {
        corpId: this.corpId,
        officeProvCode: this.corpAddrInfo.officeProvCode,
        officeCityCode: this.corpAddrInfo.officeCityCode,
        officeDistrictCode: this.corpAddrInfo.officeDistrictCode,
        officeTelNumber: this.corpAddrInfo.officeTelNumber,
        officeFaxNumber: this.corpAddrInfo.officeFaxNumber,
        officeZipCode: this.corpAddrInfo.officeZipCode,
        officeDetailAddr: this.corpAddrInfo.officeDetailAddr,
      };
      console.log(this.formAddr);
    },
    getOfficeAddressCode(res) {
      this.formAddr.officeProvCode = res.provinceCode
      this.formAddr.officeCityCode = res.cityCode
      this.formAddr.officeDistrictCode = res.blockCode
      if (this.formAddr.officeDistrictCode) {
        this.officeSelectedFlg = true
      }
    },
    getCompanyMessage() {
      let params = {};
      if (this.companyCorpId) {
        params.corpId = this.companyCorpId
      }
      console.log(this.currentRole);
      InterfaceService[this.currentRole == "S" ? "getVendorMessage" : "getPurchaserMessage"](params, (data) => {
        if (data.respData.respCode == "0000") {
          this.companyInfoBean = data.respData && (data.respData.acSupplierInfoBean || data.respData.acPurchaserInfoBean || {});
          this.taxClassifyList = data.respData && data.respData.corpTaxClassifyList || []
          if (!this.companyInfoBean.dealToStr) {
            this.companyInfoBean.dealToStr = '长期'
          }
          if (data.respData.acCorpAttachInfoList.length != 0) {
            data.respData.acCorpAttachInfoList.forEach((item, ind, arr) => {
              item.dialogVisible = false
            })
          }
          this.acCorpAttachInfoList = [];
          let list = data.respData.acCorpAttachInfoList || [];
          list.forEach(item => {
            if (item.attachType === "0") {
              this.acCorpAttachInfoList.push(item)
            } else if (item.attachType === "2") {
              this.authorizationName = item.attachName || "";
              this.authorizationUrl = item.attachUrl || ""
            }
          });
          if (data.respData.brandList && data.respData.brandList.length) {
            data.respData.brandList.forEach((item, ind, arr) => {
              item.dialogVisible = false
            })
            this.brandList = data.respData.brandList || [];
          }
          this.categoryNameList = [];
          if (data.respData.categoryList && data.respData.categoryList.length) {
            let categoryList = data.respData.categoryList;
            categoryList.forEach(item => {
              if (item.fullName) {
                this.categoryNameList.push(item.fullName)
              }
            });
          }
          this.acCorpInfoBean = data.respData.acCorpInfoBean || {};
          if (!this.acCorpInfoBean.supCorpName) {
            this.acCorpInfoBean.supCorpName = '无'
          }
          if (!this.acCorpInfoBean.registCapital) {
            this.acCorpInfoBean.registCapital = '无'
          }
          this.acCorpInfoType = data.respData.acCorpInfoBean.approveStatusDisp;
          this.corpId = data.respData.acCorpInfoBean.corpId
          data.respData.acCorpContactInfoList.forEach((item) => {
            if (item.contactType == '0') {
              this.corpContact = item
              if (!this.corpContact.department) {
                this.corpContact.department = '无'
              }
              if (!this.corpContact.provCodeDisp) {
                this.corpContact.provCodeDisp = ''
              }
              if (!this.corpContact.cityCodeDisp) {
                this.corpContact.cityCodeDisp = ''
              }
              if (!this.corpContact.districtCodeDisp) {
                this.corpContact.districtCodeDisp = ''
              }
            } else if (item.contactType == '1') {
              this.purchaseContact = item
              if (!this.purchaseContact.department) {
                this.purchaseContact.department = '无'
              }
              if (!this.purchaseContact.provCodeDisp) {
                this.purchaseContact.provCodeDisp = ''
              }
              if (!this.purchaseContact.cityCodeDisp) {
                this.purchaseContact.cityCodeDisp = ''
              }
              if (!this.purchaseContact.districtCodeDisp) {
                this.purchaseContact.districtCodeDisp = ''
              }
            } else if (item.contactType == '9') {
              this.adminInfo = item;
              this.adminInfo.authorizationName = this.authorizationName || "";
              this.adminInfo.authorizationUrl = this.authorizationUrl || "";
            }
          })
          this.corpAddrInfo = data.respData.corpAddrInfoRst || {};
          if (!this.corpAddrInfo.regFaxAreaCode) {
            this.corpAddrInfo.regFaxAreaCode = '无'
          }
          if (!this.corpAddrInfo.regFaxNumber) {
            this.corpAddrInfo.regFaxNumber = '无'
          }
          this.corpFinInfo = data.respData.acCorpFinInfoBean || {};

        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, (data) => {

      }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },
    showBigImg(ind) {
      this.acCorpAttachInfoList[ind].dialogVisible = true;
    }
  },
  mounted() {
    console.log(this.currentRole)
    let user = JSON.parse(this.$getRootScope('user')) || {}
    this.contractCorpType = user.contractCorpType
    // this.custId = user.custId || ''
    this.getCompanyMessage()
    // if (this.currentBs) {
    //   this.currentRole = this.currentBs
    // }else {
    //   this.currentRole = this.bs
    // }
  }
}
</script>

<style lang="scss" scoped>
/deep/ .order-info-title {
  margin: 5px 0;
  margin-bottom: 20px;
  padding: 0 10px;
  font-size: 14px;
  border-left: 3px solid #000;
  line-height: 12px;
}
.purchaser-right-title {
  width: 100%;
  height: 50px;
  line-height: 50px;
  font-size: 14px;
  color: #4f525a;
  background: #f5f5f5;
  padding: 0 20px;
}
.purchaser-right-title div {
  float: right;
  line-height: 50px;
}
.purchaser-right-title span {
  width: 88px;
  display: inline-block;
  height: 26px;
  line-height: 26px;
  background: #bbbbbb;
  color: #444444;
  text-align: center;
}
.purchaser-company-information {
  width: 100%;
  margin-top: 9px;
  overflow: hidden;
  //   margin-bottom: 20px;
}
.purchaser-company-information p {
  display: inline-block;
  height: 43px;
  line-height: 43px;
}
.purchaser-company-information p:first-child {
  width: 95px;
  font-size: 14px;
  color: #333333;
  text-align: center;
  border-bottom: 3px solid #4f525a;
}
.yellow-line {
  width: 853px;
  font-size: 12px;
  color: #373737;
  text-align: center;
  border-bottom: 3px solid #c99f4f;
  height: 43px;
  text-align: right;
  padding-right: 20px;
}
.purchaser-company-information p span {
  display: inline-block;
  height: 24px;
  padding-right: 12px;
  border: 1px solid #4f525a;
  line-height: 24px;
  text-align: left;
  padding-left: 30px;
  cursor: pointer;
}
.company-top {
  margin-top: 13px;
  font-size: 12px;
}
.company-top li {
  /*height: 26px;*/
  line-height: 26px;
}
.company-top li.changeInfo {
  height: 48px;
  line-height: 48px;
}
.company-top li .company-left {
  float: left;
  display: inline-block;
  width: 49%;
  /*height: 26px;*/
  line-height: 26px;
}
.company-top li .company-left span {
  display: inline-block;
  /*width: 172px;*/
  height: 26px;
  line-height: 26px;
  text-align: right;
  color: #888;
  vertical-align: top;
}
.company-top li .company-left span em {
  color: #e93340;
}
.company-top li .company-showtext {
  width: 360px;
  display: inline-block;
}
.company-information .el-input {
  width: 270px;
  height: 26px;
}
.canNotEdit /deep/ .el-input__inner {
  height: 32px;
  line-height: 32px;
  border: 1px solid #dddddd;
}
.el-input.is-disabled.canNotEdit /deep/ .el-input__inner {
  height: 26px;
  line-height: 26px;
  background: white;
  color: #333333;
  cursor: unset;
  border: 1px solid #ffffff;
  padding: 0;
}
.company-images {
  margin: 13px 0 14px;
  overflow: hidden;
}
.company-images li {
  width: 178px;
  border: 1px solid #dddddd;
  float: left;
  margin-left: 29px;
}
.company-images div img {
  width: 100%;
  cursor: pointer;
  height: auto;
  vertical-align: top;
}
.company-address,
.contact-data {
  margin-top: 13px;
}
.company-address.pad_bottom {
  margin-top: 0;
}
.a-text {
  display: inline-block;
  width: auto !important;
  max-width: 254px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.company-img {
  width: 122px;
  display: inline-block;
  padding-right: 10px;
  img {
    max-width: 800px;
    display: block;
    margin: 10px auto;
    padding-right: 10px;
    &:hover {
      cursor: pointer;
    }
  }
}
.line {
  margin: 20px 0;
  height: 1px;
  width: 100%;
  background: rgba(238, 238, 238, 1);
}
.form-inline-item {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;

  & > div {
    width: 40%;
    flex-shrink: 0;
  }

  &.col-3 > div {
    width: 32%;
  }

  /deep/ .el-select {
    width: 100%;
  }
}
.address-input {
  .el-form-item {
    width: 100% !important;
    /deep/ .el-form-item__label:before {
      content: none !important;
    }
  }
}
.form-inline-item-dispickter {
  .el-form-item {
    /deep/ .el-form-item__label:before {
      content: "*";
      color: #f56c6c;
      margin-right: 4px;
    }
  }
}
.header {
  margin-bottom: 20px;
  background: #f5f5f5;
}

.header ul {
  width: 100%;
  height: 48px;
  border-bottom: 3px solid rgb(250, 226, 165);
  font-weight: bold;
  li {
    padding-left: 20px;
    height: 48px;
    line-height: 48px;
    text-align: center;
    float: left;
    cursor: pointer;
    position: relative;

    &:after {
      display: none;
      position: absolute;
      bottom: 0px;
      left: 0;
      content: "";
      width: 110px;
      height: 3px;
      background: #4f525a;
    }

    &.active:after {
      display: block;
    }
  }
}
.submit-cont {
  margin-top: 38px;
  text-align: center;
  height: 30px;
}
.company-top {
  margin-top: 13px;
  font-size: 12px;
}
.company-top li {
  line-height: 26px;
}
.company-top li.changeInfo {
  height: 48px;
  line-height: 48px;
}
.company-top li .company-left {
  display: inline-block;
  width: 49%;
  line-height: 26px;
}
.company-top li .company-left span {
  display: inline-block;
  height: 26px;
  line-height: 26px;
  text-align: right;
  color: #888;
  vertical-align: top;
}
.company-top li .company-left span em {
  color: #e93340;
}
.company-top li .company-left.one {
  width: 100%;
  .company-showtext {
    width: 900px;
  }
}
.company-top li .company-showtext {
  display: inline-block;
}
/deep/ .panel-title {
  margin-bottom: 0 !important;
}

.purchaser-company-information {
  width: 100%;
  margin-top: 9px;
  overflow: hidden;
  margin-bottom: 20px;
  .invoice-info-container {
    .brand-container-ul {
      margin: 0;
      padding: 0;
      border: 0;
    }
  }
  .body-invoice-info {
    margin-top: 12px;
    margin-bottom: 22px;
    span {
      font-size: 12px;
      color: #888;
    }
  }

  .milling-body-head {
    margin-top: 22px;
    [class*="el-col-"] {
      height: 34px;
      background: #f5f5f5;
      line-height: 34px;
      color: #888;
      padding: 0 12px;
      font-size: 14px;
    }
  }
  .milling-body-center {
    .el-row {
      display: flex;
      border: 1px solid #eaeaea;
      border-top: 0;
      padding: 12px;
      align-items: center;
      font-size: 14px;
    }
    [class*="el-col-"] {
      color: #444;
      &:first-child {
        color: #888;
      }
    }
    .remark {
      word-wrap: break-word;
    }
  }
}
.purchaser-company-information p {
  display: inline-block;
  height: 43px;
  line-height: 43px;
}
.purchaser-company-information p:first-child {
  width: 95px;
  font-size: 14px;
  color: #333333;
  text-align: center;
  border-bottom: 3px solid #4f525a;
}
.brand-container-ul {
  border-top: 1px dashed #eeeeee;
  .head-title {
    color: #444;
    font-size: 14px;
    font-weight: bold;
    .opt-brand-btn {
      font-size: 12px;
      font-weight: normal;
    }
  }
  li {
    margin-top: 12px;
    &.brand-li-body {
      display: flex;
      & > div {
        width: 50%;
      }
    }
    .brand-left {
      & > div {
        margin-top: 12px;
        .title {
          color: #888;
          margin-right: 4px;
        }
      }
    }
    .brand-right {
      .title {
        color: #888;
        margin-top: -22px;
      }
      .logo-img-center {
        width: 60px;
        height: 60px;
        margin-top: 12px;
        img {
          width: 100%;
          height: 100%;
        }
      }
    }
  }
}
</style>