<template>
  <div class="app-nav-bar">
    <div class="nav-bar-container inner-container">
      <ul class="nav-bar-bd f16" ref="ul">
        <li @click="changeNavBar('home')" ><span class="li-item" >首页</span></li>
        <!-- <li @click="changeNavBar('')" ><span class="li-item" >产品与服务</span></li> -->
        <!--<li @click="changeNavBar('biddingAnnouncement')" :class="{'active':currentRouter=='biddingAnnouncement'}">-->
        <!-- <li @click="changeNavBar('biddingAnnouncement')" :class="{'active':currentRouter=='biddingAnnouncement'}">
          <span class="li-item">
            公告发布
            <span class="second-menu-item">
              <em @click="changeNavBar('biddingAnnouncement')">招标公告</em>
              <em>中标公示</em>
            </span>
          </span>
        </li> -->
        <li @click="changeNavBar('biddingAnnouncement')" :class="{'active':currentRouter=='biddingAnnouncement'}">
          <span class="li-item">
            招采信息
            <span class="second-menu-item">
              <em @click="changeNavBar('biddingAnnouncement')">招标公告</em>
              <em>中标公示</em>
            </span>
          </span>
        </li>
        <!-- <li>
          <span class="li-item" >
            建材商城
            <span class="second-menu-item">
              <em @click="changeNavBar('')">集采商城</em>
              <em>直采商城</em>
            </span>
          </span>
        </li> -->
        <li>
          <span class="li-item" >
            建材商城
            <span class="second-menu-item">
              <em @click="changeNavBar('')">产品优选</em>
              <em>建材直采</em>
            </span>
          </span>
        </li>
        <li slot="reference">
            <div slot="reference" class="project-intro-title">
              <!-- <span class="li-item" >供应商名录</span> -->
              <span class="li-item">供应商入住</span>
            </div>
        </li>
        <!-- <li @click="changeNavBar('partner')" :class="{'active':currentRouter=='partner'}"><span class="li-item"  :class="{'active':currentRouter=='partner'}">采购商名录</span></li> -->
        <li @click="changeNavBar('partner')" :class="{'active':currentRouter=='partner'}"><span class="li-item"  :class="{'active':currentRouter=='partner'}">采购商合作</span></li>
        <li @click="changeNavBar('HelpCenter')" :class="{'active':currentRouter=='helpCenter'}"><span class="li-item"  :class="{'active':currentRouter=='helpCenter'}">新闻资讯</span></li>
        <li @click="changeNavBar('HelpCenter')" :class="{'active':currentRouter=='helpCenter'}"><span class="li-item"  :class="{'active':currentRouter=='helpCenter'}">关于我们</span></li>
        <li>
          <span class="li-item" >
            帮助中心
          </span>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>

const projectList = [
  {
    province: '广西',
    link: 'http://www.greenlandhk.com/pages/gb/cityNN.html',
  },
  {
    province: '云南',
    link: 'http://www.greenlandhk.com/pages/gb/cityKM.html'
  },
  {
    province: '江苏',
    citys: [
      { city: '常熟', link: 'http://www.greenlandhk.com/pages/gb/cityCS.html' },
      // { city: '徐州', link: '' },
      { city: '无锡', link: 'http://www.greenlandhk.com/pages/gb/cityWX.html' },
    ]
  },
  {
    province: '苏州',
    link: 'http://www.greenlandhk.com/pages/gb/citySZ.html'
  },
  {
    province: '上海',
    link: 'http://www.greenlandhk.com/pages/gb/citySH.html'
  },
  {
    province: '浙江',
    link: 'http://www.greenlandhk.com/pages/gb/cityNB.html'
  },
  {
    province: '海南',
    link: 'http://www.greenlandhk.com/pages/gb/cityHK.html'
  },
  {
    province: '黄山',
    link: 'http://www.greenlandhk.com/pages/gb/cityHS.html'
  },
  {
    province: '太原',
    link: 'http://www.greenlandhk.com/pages/gb/cityTY.html'
  }
]

export default {
  props: {
    currentRouter: {
      type: String,
      default: '' //这样可以指定默认的值
    }
  },
  data() {
    return {
      snow1: false,
      snow2: false,
      snow3: false,
      snow4: false,
      snow5: false,
      projectList: this.$clone(projectList)
    }
  },
  computed: {

  },
  methods: {
    changeNavBar(type, newWindow) {
      if (newWindow) {
        const routeData = this.$router.resolve({
          path: `/${type}`
        });
        window.open(routeData.href, "_blank");
        return
      } else {

        this.$router.push('/' + type)
      }
    },
      handleGoProject() {
          window.open("http://www.greenlandhk.com/post?id=33", "_blank");
      },
  },
  mounted: function () {

  }
}
</script>
<style lang="scss" scoped>
  .app-nav-bar{
    background: #313131;
  }
  .nav-bar-bd li {
    color: #fff;
  }
  .nav-bar-bd li.active,
  .nav-bar-bd li:hover {
    color: #dcab50;
  }
  .nav-bar-bd li:first-child span.active,
  .nav-bar-bd li:first-child span:hover {
    border-bottom: 2px solid #c99f4f;
    color: #dcab50;
  }
  .nav-bar-bd li .li-item.active,
  .nav-bar-bd li .li-item:hover {
    border-bottom: 2px solid #c99f4f;
  }
  .nav-bar-bd li:first-child span{
    color: #fff;
  }
.project-intro {
  background-image: url("../assets/images/home/191119/star.png");
  background-repeat: no-repeat;
  background-position: 93px 5px;
  &:hover {
    background-image: url("../assets/images/home/191119/star_active.png");
  }
}

.project-content {
  width: 1190px;
  margin: auto;
  padding-bottom: 10px;
}

.project-item {
  float: left;
  height: 70px;
  width: 20%;
  padding: 15px;
  text-align: left;

  p {
    font-size: 15px;
    color: #000;
  }

  a:hover {
    color: #409eff;
  }

  .project-city {
    margin-right: 20px;
    font-size: 12px;
    line-height: 35px;
    color: #909399;
  }
}
.lh21 {
  line-height: 21px;
}
</style>