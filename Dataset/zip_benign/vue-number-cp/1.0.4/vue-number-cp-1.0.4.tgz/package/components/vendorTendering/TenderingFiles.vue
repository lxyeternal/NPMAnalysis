<template>
    <div>
        <div class="order-info">
            <el-row>
                <el-col :span="20">
                    <div class="order-info-title">文件</div>
                </el-col>
                <!--<el-col :span="4">-->
                    <!--<el-button type="primary" size="small" class="fr" @click="handleBatchDownload">批量下载</el-button>-->
                <!--</el-col>-->
            </el-row>
            <el-row>
                <div class="upload-record-title">
                    <span>文件名</span>
                    <span>操作</span>
                </div>
                <div class="record-wrap">
                    <ul>
                        <li v-for="(item,ind) in docList" :key="ind">
                            <span><i class="blue hand" @click="handleOpen(item.attachUrl)">{{item.docName}}</i></span>
                            <span><i class="blue hand" @click="handledownloadFile(item)">下载</i></span>
                        </li>
                    </ul>
                </div>
            </el-row>
        </div>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import PanelTitle from "@/components/base/PanelTitle";
import Loading from "@/components/base/Loading";
import { viewFile } from '@/utils/orderUtil';
import { InterfaceService } from "@/services/api";
export default {
    mixins: [accountMixin],
    components: {
        PanelTitle,
        Loading,
    },
    props: ["docList","tenderNo"],
    data() {
        return {
            roleList: [],
            isLoading:false,
            fold:true
        };
    },
    methods: {
        handleOpen(url){
            if (url) {
              viewFile(url)
            }
        },
        handledownloadFile(item){
            let attach = [];
            attach.push({
                url :item.attachUrl,
                name :item.docName.split("?")[0],
            });
            this.$download(attach).then(res=>{
                this.$message.success("已下载");
            })
        },
        handleBatchDownload(){
            let documentList = [];
            this.docList.forEach((item, index) => {
                documentList.push({
                    docUrl: item.docUrl,
                    docName: item.docName,
                });
            });
            let params = {
                tenderNo: this.tenderNo,
                documentList: documentList,
            };
            InterfaceService.downloadRenderPackage(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        let packingUrl = data.respData.fileUrl || "";
                        let name = packingUrl.split("?")[0];
                        name = name.split("/").pop();
                        const files = [
                            { name: decodeURIComponent(name), url: packingUrl }
                        ];
                        this.$download(files).then(() => {
                            this.$message.success("已下载");
                        });
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
    .order-info {
        margin-top: 10px;
        margin-bottom: 10px;
        line-height: 30px;
        font-size: 12px;

        /deep/ .el-col {
            padding: 0 10px;
        }
        .file-content {
            background: #fef4f3;
            margin: 0 10px;
            max-height: 234px;
            overflow-y: scroll;
        }
        p {
            width: 100%;
            display: flex;
            padding-right: 10px;
            word-break: break-word;
            white-space: normal;
        }
        label {
            white-space: nowrap;
            color: #888888;
        }
        .order-info-title {
            margin: 5px -10px;
            margin-bottom: 10px;
            padding: 0 10px;
            font-size: 14px;
            border-left: 3px solid #000;
            line-height: 12px;
        }
        /deep/ .el-button{
            height: 20px;
            line-height: 20px;
            padding-top: 0;
        }
    }
    .upload-record-title{
        width: 100%;
        border-top: 1px solid #eeeeee;
        margin-top: 10px;
        height: 34px;
        line-height: 34px;
        background: #f5f5f5;
        padding-left: 10px;

        span{
            display: inline-block;
            float: left;
            height: 34px;
            line-height: 34px;
            color: #888888;
            text-align:left;
            border-bottom: 1px solid #fff;
        }
        span:first-child{
            width: 96.4%;
        }
        span:last-child{
            text-align: right;
        }
    }
    .record-wrap{
        width: 100%;
        max-height: 234px;
        overflow-y: scroll;
        background: #f5f5f5;
        border-bottom: 1px solid #eee;
        margin-bottom: 20px;
        ul{
            padding-left: 10px;

            li{
                min-height: 32px;
                line-height: 32px;
                border-bottom: 1px solid #eeeeee;
                span:first-child{
                    width: 95%;
                }
                span:last-child{
                    width: 4%;
                    text-align: right;
                }
                span{
                    display: inline-block;
                    text-align: left;
                }
            }
        }

        p{
            padding-left: 10px;
            line-height: 30px;
        }
    }


</style>
