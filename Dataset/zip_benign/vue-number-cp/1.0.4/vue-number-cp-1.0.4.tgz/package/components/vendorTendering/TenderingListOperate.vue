<template>
    <div class="operate">
        <p v-if="tender.state === 'before'">
            <el-button type="primary" size="mini" @click="handleGoTendering(tender)">去报价</el-button>
        </p>
        <p v-if="tender.state === 'success'">
            <el-button type="primary" size="mini" @click="handlePutTenderInStorage(tender.tenderNo)">入选入库</el-button>
        </p>
        <p v-if="tender.state === 'tendering' || tender.state === 'clear'">
            <i class="blue hand" @click="handleTenderingDetail('modify')">修改清单</i>
        </p>
        <p v-if="tender.state !== 'before'">
            <i class="blue hand" @click="handleTenderingDetail('detail')">查看报价详情</i>
        </p>
        <p v-if="tender.state === 'tendering'">
            <i class="blue hand" @click="handleSetTenderCode(tender.tenderNo)">清单密码设置</i>
        </p>
        <TenderInStorage ref="tenderInStorage" @close="handleRefresh"></TenderInStorage>
        <SetTenderCode ref="setTenderCode" @close="handleRefresh"></SetTenderCode>
    </div>
</template>

<script>
    import accountMixin from "@/mixins/account";
    import TenderInStorage from "@/components/vendorTendering/dialog/TenderInStorage";
    import SetTenderCode from "@/components/vendorTendering/dialog/SetTenderCode";
    export default {
        mixins: [accountMixin],
        components: {
            TenderInStorage,
            SetTenderCode,
        },
        props: ["tender"],
        data() {
            return {
                attach: {},
            };
        },
        computed: {

        },
        methods: {
            // 中标入库
            handlePutTenderInStorage(tender) {
                this.$refs["tenderInStorage"].open(tender);
            },
            // 设置开标码
            handleSetTenderCode(tenderNo){
                this.$refs["setTenderCode"].open(tenderNo);
            },
            // 刷新
            handleRefresh(bool) {
                if (bool) {
                    this.$emit("refresh");
                }
            },
            // 查看投标详情
            handleTenderingDetail(modify) {
                this.$router.push({
                    name: 'TenderingDetail',
                    path: "/tenderingDetail",
                    query: {
                        tenderNo: this.tender.tenderNo,
                    },
                    params:{
                        modify: modify,
                    }
                });
            },
            // 去投标
            handleGoTendering() {
                this.$router.push({
                    path: "/GoTendering",
                    query: {
                        tenderNo: this.tender.tenderNo,
                        brokerCorpId: this.tender.brokerCorpId,
                        checkCodeSettingFlg: this.tender.checkCodeSettingFlg,
                    }
                });
            },
        },
        mounted() {

        }
    };
</script>

<style lang="scss" scoped>
    /deep/ .el-button {
        margin-bottom: 5px;
    }

    .operate {
        a {
            display: block;
            white-space: nowrap;
            padding: 5px 0 0 5px;
            line-height: 18px;
            color: #0082ff;
            font-size: 12px;
            text-align: right;
        }
        p{
            text-align: right;
        }
    }
    /deep/ .el-dropdown {
        width: 100%;
        text-align: right;
    }
    /deep/ .el-dropdown-menu__item {
        color: #0082ff;
        text-align: right;
        font-size: 12px;
        &:hover{
            color: #0082ff;
            background: #e8f3fd;
        }
        a{
            display: block;
            width: 100%;
            height: 100%;
        }
    }
</style>
