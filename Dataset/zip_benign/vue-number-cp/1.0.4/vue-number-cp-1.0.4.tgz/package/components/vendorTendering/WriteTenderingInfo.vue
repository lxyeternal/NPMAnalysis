<template>
    <div>
        <PanelTitle title="填写报价信息" class="order-data-message" @foldInfo = "handleFoldInfo"></PanelTitle>
        <div class="order-info">
            <el-row>
                <el-col>
                    <div class="order-info-title">上传报价清单</div>
                </el-col>
            </el-row>

            <el-row>
                <el-col :span="24">
                    <div>上传文件大小不要压缩,请<em class="red">严格按要求上传，切勿传错</em></div>
                    <div>报价清单入口：请根据采购商要求，下载 <em class="blue underline hand" @click="handleDownloadTemp()">报价清单模板</em>，在模板的基础上完善信息，并上传</div>
                    <!--<div>投标附件入口：除去投标清单文件外的其他文件，格式不限，大小在50MB以内</div>-->
                </el-col>
            </el-row>
            <el-row>
                <el-col :span="24">
                    <div class="uplode">
                        <el-form ref="contractForm" :model="form" label-width="80px">
                            <el-form-item :required="!modify" label="报价清单" class="contract-content">
                                <el-col :span="18">
                                    <div class="contract-list">
                                        {{contractName}}
                                    </div>
                                </el-col>
                                <input id="contract-list" ref="contract-list" type="file" @change="handleUploadContract" />
                                <label class="file-label" for="contract-list">选择文件</label>
                                <!--<el-button type="primary" for="contract-list" @click="handleSubmit('biddingList')">上传</el-button>-->
                                <el-button for="contract-list" @click="handleDownloadTemp()">下载报价清单模板</el-button>
                            </el-form-item>
                            <!--<el-form-item label="投标附件" class="contract-content">-->
                                <!--<el-col :span="18">-->
                                    <!--<div class="contract-list">-->
                                        <!--{{attachApprovalPlaceholder}}-->
                                        <!--<el-tag size="mini" closable v-for="(item,index) in attachList" :key="index"  @close="handleDelAttach(index)" v-if="item.docType=='biddingAttach'">{{item.docName}}</el-tag> &lt;!&ndash; v-if="item.docType=='biddingAttach'" &ndash;&gt;-->
                                    <!--</div>-->
                                <!--</el-col>-->
                                <!--<input id="contract-approval" multiple="multiple" ref="contract-approval" type="file" @change="handleUploadAttachApproval" />-->
                                <!--<label class="file-label" for="contract-approval">选择文件</label>-->
                                <!--&lt;!&ndash;<el-button type="primary" for="contract-list" @click="handleSubmit('biddingAttach')">上传</el-button>&ndash;&gt;-->
                            <!--</el-form-item>-->
                        </el-form>
                    </div>
                    <template v-if="biddingList && biddingList.length !=0">
                        <div class="upload-record-title">
                            <span>已上传的报价清单</span>
                            <span>上传时间</span>
                            <span class="tr">操作</span>
                        </div>
                        <div class="record-wrap">
                            <ul>
                                <li v-for="(item,ind) in biddingList" :key="ind" v-if="item.recStat == '1'"> <!-- v-if="item.docType == 'biddingList' && item.recStat == '1'" -->
                                    <span><i class="blue hand" @click="handleView(item.attachUrl)">{{item.docName}}</i></span>
                                    <span>{{item.uploadTime}}</span>
                                    <div class="buttons tr">
                                        <i class="blue hand" style="margin-right:10px;" @click="handeLoad(item)">下载</i>
                                        <i class="blue hand" @click="handleDel(item)">删除</i>
                                    </div>
                                </li>
                                <!-- <li v-for="(item,ind) in biddingList " :key="ind" v-if="item.docType != 'biddingList' && item.recStat == '1'">
                                    <span><i class="blue hand" @click="handleView(item.attachUrl)">{{ind}}***{{item.docName}}</i></span>
                                    <span>{{item.uploadTime}}</span>
                                    <div class="buttons tr">
                                        <i class=" blue hand" style="margin-right:10px;" @click="handeLoad(item)">下载</i>
                                        <i class=" blue hand" @click="handleDel(item)">删除</i>
                                    </div>
                                </li> -->

                            </ul>
                        </div>
                    </template>
                </el-col>
            </el-row>
            <template v-if="!modify && checkCodeSettingFlg != '1'">
                <el-row style="margin-top: 20px;">
                    <el-col>
                        <div class="order-info-title">完善报价信息</div>
                    </el-col>
                </el-row>
                <el-form ref="tenderingForm" class="form" :model="tenderingForm" :rules="rules" size="small" label-width="110px">
                    <el-row>
                        <el-col :span="12">
                            <el-form-item label="设置清单密码"  prop="checkCode">
                                <el-input v-model="tenderingForm.checkCode" placeholder="请输入6位数清单密码" maxlength="6"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form>
            </template>
        </div>
        <!-- 确认上传文件名称格式 -->
        <el-dialog class="confirm-dialog" title="确认上传文件名称" :append-to-body="true" :lock-scroll="true" :visible.sync="changeNameVisible" width="50%" center :close-on-click-modal="false">
            <p class="title-tip">为了便于您更好的管理报价清单，系统会自动将您上传的报价清单文件命名成《您的公司名称 + 类目 + 固定文字"报价清单" + 版本号》的形式。</p>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 120px" @click="handleChange">确认并上传</el-button>
                <el-button size="small" style="width: 120px" @click="changeNameVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <FixBottom>
            <div class="fix-bottom" :class="{'lh40':modify}">
                <el-button :disabled="attachList.length == '0' && modify" type="primary" style="width: 120px;" @click="handleSubmit">{{modify ? "确认并上传":"确认并报价"}}</el-button>
                <el-button style="width: 120px;" @click="handleCancel()">{{modify ? "返回":"取消"}}</el-button>
            </div>
        </FixBottom>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import PanelTitle from "@/components/base/PanelTitle";
import Loading from "@/components/base/Loading";
import SignProcessContract from "@/components/order/SignProcessOrderDetail";
import TenderingFiles from "@/components/vendorTendering/TenderingFiles";
import { InterfaceService } from "@/services/api";
import FixBottom from "@/components/base/FixBottom";
import CryptoJS from 'crypto-js';
import { viewFile } from '@/utils/orderUtil';

const tenderingForm = {
    // name : "",
    checkCode : "",
};
export default {
    mixins: [accountMixin],
    components: {
        PanelTitle,
        SignProcessContract,
        TenderingFiles,
        FixBottom,
        Loading
    },
    props: ["tenderInfo","modify","biddingList","checkCodeSettingFlg"],
    data() {
        const validate = (rule, value, callback) => {
            const reg = new RegExp(/\d{6}/);
            if (!reg.test(value)) {
                return callback(new Error("清单密码输入有误，请输入6位数字清单密码"));
            } else {
                callback();
            }
        };
        return {
            isLoading: false,
            attachList: [],
            upLoadRecordList: [],
            changeNameArr: [],
            arrContactName: [],
            fold:true,
            changeNameVisible:false,
            form:{},
            tenderingForm:Object.assign({}, tenderingForm),
            rules: {
                checkCode: [
                    {
                        required: true,
                        message: "请输入清单密码",
                        trigger: "blur"
                    },
                    { validator: validate, trigger: "blur" }
                ]
            }
        };
    },
    filters: {
    },
    computed: {
        corpName(){
            return this.$store.state.userInfo && this.$store.state.userInfo.corpName;
        },
        contractName() {
            let name = "请选择Excel清单文本";
            this.attachList.forEach(item => {
                if (item.docType == "biddingList") {
                    name = item.docName;
                }
            });
            return name;
        },
        attachApprovalPlaceholder(){
            let name = '请选择附件';
            this.attachList.forEach(item => {
                if (item.docType == "biddingAttach") {
                    name = "";
                }
            });
            return name;
        },
    },
    watch: {
        tenderInfo(newVal) {
        },
        modify(newVal,oldVal){
            if (!newVal) {
                this.$nextTick(() => {
                    this.$refs["tenderingForm"].clearValidate();
                });
            }
        }
    },
    methods: {
        filterAttachList(){
            return this.attachList.filter(item => {
                console.log(item)
                return item.docType=='biddingAttach'
            });
        },
        filterBiddingList(flg){
            return this.biddingList.filter(item => {
                //v-if="item.docType == 'biddingList' && item.recStat == '1'"
                if(flg){
                    return item.docType == 'biddingList' && item.recStat == '1'
                }else{
                    return item.docType != 'biddingList' && item.recStat == '1'
                }

            });
        },
        handeLoad(item){
            console.log(item)
            this.$download([{ url: item.attachUrl, name: item.docName }])

        },
        handleDownloadTemp(){
            let onOff = false;
            if (this.tenderInfo.docList && this.tenderInfo.docList.length > 0) {
                this.tenderInfo.docList.forEach(item=>{
                    if (item.docType == "tenderList") {
                        const files = [
                            { name: item.docName, url: item.attachUrl }
                        ];
                        this.$download(files).then(() => {
                            this.$message.success("已下载");
                        });
                        onOff = true;
                    }
                });
                if (!onOff) {
                    this.$message.error("暂无招标清单模板！")
                }
            }else {
                this.$message.error("暂无招标清单模板！")
            }
        },
        handleView(url){
            if (url) {
              viewFile(url)
            }
        },
        // 折叠投标信息
        handleFoldInfo(bool){
            this.fold = bool;
        },
        handleDel(item){
            this.$confirm(
                "删除后将无法恢复文件，确认删除吗?",
                {
                    cancelButtonClass: "btn-custom-cancel",
                    confirmButtonClass: "btn-custom-confirm",
                    center: true,
                    type: 'warning',
                    confirmButtonText: "确认",
                    cancelButtonText: '取消',
                }).then(() => {
                this.confirmDel(item);
            }).catch(() => {
                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });
        },
        confirmDel(item){
            let docList = [];
            docList.push({
                docId: item.docId,
                docType: item.docType,
                docName: item.docName,
            });
            let params = {
                tenderNo : this.tenderInfo.tenderNo,
                docList:docList
            };
            InterfaceService.uploadTenderFiles(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        this.$message.success("文件删除成功！");
                        this.$emit("refresh","del");
                        // this.getTenderFiles()
                    } else {
                        this.$message.error(res.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        handleUploadContract(e){
            const file = e.target.files[0];
            if (!file) {
                return;
            }
            let f_content = file.name;
            let fileext=f_content.substring(f_content.lastIndexOf("."),f_content.length);
            fileext=fileext.toLowerCase();
            if (fileext!='.xls' && fileext!='.xlsx' && fileext!='.xlsm' ) {
                this.$message.error("请上传EXCEL文件");
                return;
            }
            if (file.size > 52428800) {
                this.$message.error("您上传文件过大，请选择小于50MB的文件上传");
                this.$refs["contract-list"].value = null;
                return;
            }
            let hasContract = false;
            this.attachList.forEach(item => {
                if (item.docType === "biddingList") {
                    item.file = file;
                    item.docName = file.name;
                    hasContract = true;
                }
            });
            if (!hasContract) {
                this.attachList.push({
                    docType: "biddingList",
                    file: file,
                    docName: file.name,
                });
            }
            this.$refs["contract-list"].value = null
        },
        handleUploadAttachApproval(e){
            const files = e.target.files;
            if (!files || !files.length) {
                return;
            }
            let overSizeList = [];
            Array.prototype.forEach.call(files, file => {
                let onOff = true;
                if (file.size <= 52428800) {
                    if (this.attachList.length) {
                        this.attachList.forEach(item=>{
                            if (item.docType == "biddingAttach") {
                                if (item.docName == file.name) {
                                    this.$message.error("请勿上传相同文件");
                                    onOff = false
                                }
                            }
                        })
                    }
                    if (onOff) {
                        this.attachList.push({
                            file: file,
                            docName: file.name,
                            docType:"biddingAttach"
                        });
                    }
                }else {
                    overSizeList.push(file.name);
                }
            });
            if (overSizeList.length > 0) {
                this.$message.error("您上传的文件"+overSizeList.join("、")+"过大，请选择小于50MB的文件上传");
            }
            e.value = "";
            this.$refs["contract-approval"].value = null
        },
        handleSubmit() {
            if (!this.modify && this.checkCodeSettingFlg != "1"){
                this.$refs["tenderingForm"].validate(valid => {
                    if (valid) {
                        this.handleUploadTender();
                    }
                })
            }else {
                this.handleUploadTender();
            }
        },
        handleUploadTender(){
            let contractUploadFlag = "0";
            this.attachList.forEach(item=>{
                if (item.docType == "biddingList") {
                    contractUploadFlag = "1"
                }
            });
            if (contractUploadFlag === "1") {
                let reg = /\.\w+$/;
                let regLeft = /《/;
                let regRight = /》/;
                this.arrContactName = [] //显示
                this.changeNameArr = [] //临时存改变名字
                const attachList = [].concat(this.attachList);
                let d=new Date();
                let year=d.getFullYear();
                let month=change(d.getMonth()+1);
                let day=change(d.getDate());
                function change(t){
                    if(t<10){
                        return "0"+t;
                    }else{
                        return t;
                    }
                }
                let time=year+'年'+month+'月'+day+'日';
                attachList.forEach(item=>{
                    if (item.docType == "biddingList") {
                        // let fileName = item.docName.replace(reg, '').replace(regLeft, '').replace(regRight, '');
                        let fileName = item.docName;
                        let str = "《" + this.corpName + this.tenderInfo.categoryName + "配置清单" + time + "》";
                        // let str = this.order.contractName;
                        let fileExt = item.docName.replace(/.+\./,"");
                        if (str != fileName) {
                            this.arrContactName.push({
                                name: '报价清单文本：' + fileName + '，上传后系统自动命名成' + str
                            });
                            this.changeNameArr.push({
                                docType: item.docType,
                                docName: `${str}.${fileExt}`,
                            })
                        }
                    }
                });
                // if( this.changeNameArr.length !== 0 ){
                this.changeNameVisible = true;
                // }
            }else {
                this.handleConfirm();
            }
        },
        handleChange(){
            // this.concatAttach();
            // this.attachList.forEach((item)=>{
            //     this.changeNameArr.forEach((val)=>{
            //         if (val.docType) {
            //             if (item.docType === val.docType) {
            //                 item.docName = val.docName
            //             }
            //         }
            //     })
            // });
            this.handleConfirm()
        },
        handleDelAttach(index) {
            this.attachList.splice(index, 1);
        },
        handleCancel(){
            let cancelFlag = this.$route.params.modify;
            if (cancelFlag == "detail") {
                this.$emit("refresh","cancel")
            }else {
                this.$router.push({
                    path:"/vendorCenter/tenderingList"
                })
            }
        },
        handleConfirm(){
            let onOff = false;
            this.attachList.forEach(item=>{
                if (item.docType === "biddingList" || this.modify) {
                    onOff = true
                }
            });
            if (!onOff) {
                this.$message.error("请上传报价清单");
                return;
            }
            this.isLoading = true;
            this.uploadContractToOss().then(res => {
                this.isLoading = false;
                this.attachList.forEach((item, index) => {
                    res.forEach(oss => {
                        if (index == oss.index) {
                            item.docUrl = oss.url;
                        }
                    });
                });
                if ((!this.modify && this.checkCodeSettingFlg != "1")) {
                    this.setTenderCode();
                }else {
                    this.uploadTenderFiles()
                }
            });
        },
        // 文件上传到oss
        uploadContractToOss() {
            return new Promise((resolve, reject) => {
                //去后端拿签名
                InterfaceService.getOssSignature(
                    { type: "4" },
                    data => {
                        console.log(data);
                        const promiseList = [];
                        this.attachList.forEach((item, index) => {
                            let dirName;
                            let now = new Date().getTime()+index;
                            if( item.docType == 'biddingList'){
                                dirName = this.tenderInfo.tenderNo + "/biddingList/" + now + "/";
                            } else if (item.docType == 'biddingAttach') {
                                dirName = this.tenderInfo.tenderNo + "/biddingAttach/" + now + "/";
                            }
                            const promise = new Promise(_resolve => {
                                this.uploadHander(
                                    data,
                                    index,
                                    item.file,
                                    dirName,
                                    (pos, file, dir, signature) => {
                                        let u = signature.dir + dir + item.docName;
                                        _resolve({ index: index, url: u });
                                    },
                                    item.docName
                                )
                            });
                            promiseList.push(promise);
                        });
                        // 上传所有图片后回调
                        Promise.all(promiseList).then(values => {
                            resolve(values);
                        });
                    },
                    data => {}
                );
            });
        },
        uploadHander(data, pos, file, dirName, callBack,customName) {
            InterfaceService.uploadToOss(data, file, dirName, pos, callBack,customName);
        },
        setTenderCode(){
            let password = CryptoJS.MD5(this.tenderingForm.checkCode).toString();
            let params = {
                tenderNo:this.tenderInfo.tenderNo,
                checkCode: password
            };
            InterfaceService.setTenderCode(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        this.uploadTenderFiles()
                    } else {
                        this.$message.error(res.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        uploadTenderFiles(){
            // this.attachList.forEach(item=>{
            //     delete item.file
            // });
            let params = {
                tenderNo: this.tenderInfo.tenderNo,
                docList: this.attachList
            };
            InterfaceService.uploadTenderFiles(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        this.modify ? this.$message.success("修改清单成功！") : this.$message.success("报价成功！");
                        // this.$router.push({
                        //     path: "/vendorCenter/tenderingList",
                        //     query: {}
                        // });
                        this.changeNameVisible = false;
                        if (this.modify) {
                            this.$emit("refresh","success");
                        }else {
                            this.$router.push({
                                name: 'TenderingDetail',
                                path: "/tenderingDetail",
                                query: {
                                    tenderNo: this.tenderInfo.tenderNo,
                                },
                                params:{
                                    status:this.tenderInfo.state,
                                    modify: "detail",
                                    type: "success",
                                }
                            });
                        }
                    } else {
                        this.$message.error(res.respMsg);
                        let attachUrl = data.respData.attachUrl || "";
                        let attachName = data.respData.attachName || "";
                        if (attachUrl) {
                            const files = [{ name: attachName, url: attachUrl }];
                            this.$download(files).then(() => {
                            });
                        }
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
    .order-info {
        margin-bottom: 20px;
        line-height: 25px;
        font-size: 12px;

        /deep/ .el-col {
            /*padding: 0 10px;*/
        }

        p {
            width: 100%;
            display: flex;
            padding-right: 10px;
            word-break: break-word;
            white-space: normal;

            & > span {
                display: inline-block;
                flex: 1 1 0%;
            }
        }

        label {
            white-space: nowrap;
            color: #888888;
        }

        a {
            white-space: nowrap;
            color: #0082ff;
        }

        i {
            font-style: normal;
        }
    }

    .order-info-title {
        margin: 5px -10px;
        margin-bottom: 10px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
    }

    .tendering-content {
        background: #f5f5f5;
        width: 100%;
        height: auto;
        padding: 10px;
        margin-bottom: 5px;
    }
    .uplode{
        background: #fdf4f3;
        padding: 20px 10px 1px;
        width: 100%;
    }
    .contract-content {
        position: relative;
        input[type="file"] {
            position: absolute;
            width: 0;
            height: 0;
            overflow: hidden;
            opacity: 0;
        }

        .file-label {
            width: 98px;
            display: inline-block;
            padding: 12px 20px;
            line-height: 1;
            white-space: nowrap;
            cursor: pointer;
            font-size: 14px;
            border: 1px solid #ffd64e;
            background: #ffd64e;
            margin-right: 10px;
            color: #000;
        }
        .disable{
            /*padding: 12px 14px;*/
            border: 1px solid #dddddd;
            background: #dddddd;
            cursor: not-allowed;
            color: #afaeae;
        }
        /deep/ .el-button{
            padding: 6px;
            width: 100px;
            height: 40px;
        }
        /deep/ .el-button--default{
            width: 130px;
        }
        /deep/ .el-checkbox {
            padding: 0;
            margin-left: 0;
            border: none;
            background: none;
        }
        /deep/ .el-col-24 label:nth-of-type(2){
            margin-left: 10px;
        }
        .label-title{
            width: 100%;
            line-height: 18px;
        }

        .label-sub-title{
            width: 100%;
            line-height: 16px;
            font-size: 12px;
        }

        .contract-list {
            min-height: 38px;
            padding: 0 10px;
            border: 1px solid #dcdfe6;
            line-height: 38px;
            color: #888888;
            background: #fff;
        }

        a{
            margin-left: 10px;
            color: #0082ff;
        }
    }
    .upload-record-title{
        width: 100%;
        border-top: 1px solid #eeeeee;
        margin-top: 20px;
        height: 34px;
        line-height: 34px;
        background: #f5f5f5;
        padding-left: 10px;

        span{
            display: inline-block;
            float: left;
            height: 34px;
            line-height: 34px;
            color: #888888;

            border-bottom: 1px solid #fff;
            text-align: left;
        }
        span:first-child{
            width: 70.5%;
        }
        span:nth-of-type(2){
            width: 25%;
        }
        span:last-child{
            /*width: 10.7%;*/
            text-align: right;
        }
    }
    .record-wrap{
        width: 100%;
        max-height: 234px;
        overflow-y: scroll;
        background: #f5f5f5;
        border-bottom: 1px solid #eee;
        margin-bottom: 20px;
        ul{
            padding-left: 10px;

            li{
                min-height: 32px;
                line-height: 32px;
                border-bottom: 1px solid #eeeeee;
                span:first-child{
                    width: 71%;
                }
                span:nth-of-type(2){
                    width: 15.6%;
                }
                // span:last-child{
                //     /*width: 5%;*/
                //     text-align: right;
                // }
                span{
                    display: inline-block;
                    text-align: left;
                }
                .buttons{
                    width: 11.4%;
                    display: inline-block;
                    text-align: right;
                }
            }
        }

        p{
            padding-left: 10px;
            line-height: 30px;
        }
    }
    /deep/ .el-input{
        width: 215px;
    }
    .fix-bottom{
        width: 100%;
        height: 40px;
        margin: 0 auto;
        text-align: center;
        /deep/ .el-button{
            height: 40px;
        }
    }
    .lh40{
        /deep/ .el-button{
            line-height: 40px;
        }
    }
    /deep/ .el-col{
        padding: 0 10px;
    }
    .underline{
        text-decoration: underline;
    }
    .confirm-dialog{
        line-height: 25px;

        .title-tip{
            padding-bottom: 10px;
        }

        .confirm-title{
            position: relative;
            line-height: 20px;
            padding-left: 10px;
            text-align: left;

            .title-bg{
                width: 3px;
                height: 12px;
                position: absolute;
                background: #4f525a;
                top: 4px;
                left: 0;
            }
        }
        .upload-foot{
            width: 100%;
            text-align: center;
            margin-bottom: 10px;
        }
    }
    /deep/ .el-tag {
        max-width: 680px;
        min-height: 20px;
        word-break: break-all;
        white-space: normal;
    }
</style>
