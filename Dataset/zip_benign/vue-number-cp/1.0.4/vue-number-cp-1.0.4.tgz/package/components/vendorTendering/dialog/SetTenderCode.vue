<template>
    <div>
        <!-- 确认合同 -->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="840px" center :close-on-click-modal="false">
            <div slot="title" class="el-dialog__title">清单密码</div>
            <el-form class="form" :model="form" size="small" label-width="75px">
                <el-row>
                    <el-col :span="24">
                        <div class="tc">
                            您已设置过清单密码，确认要重置清单密码吗？
                        </div>
                    </el-col>
                </el-row>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleReset">重置</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="ResetDialogVisible" width="840px" center :close-on-click-modal="false" @close="form.checkCode = ''">
            <div slot="title" class="el-dialog__title">清单密码重置</div>
            <el-form ref="form"  class="form" :model="form" size="small" label-width="95px" :rules="rules">
                <el-row>
                    <el-col :span="24">
                        <el-form-item label="清单密码" prop="checkCode">
                            <el-input v-model="form.checkCode" placeholder="请输入6位数清单密码" maxlength="6"></el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm()">提交</el-button>
                <el-button size="small" style="width: 100px" @click="ResetDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import CryptoJS from 'crypto-js';
const form = {
    checkCode: "",
};

export default {
    mixins: [accountMixin],
    components: {
        Loading,
    },

    data() {
        const validate = (rule, value, callback) => {
                const reg = new RegExp(/\d{6}/);
                if (!reg.test(value)) {
                    return callback(new Error("清单密码输入有误，请输入6位数字清单密码"));
                } else {
                    callback();
                }
            };
        return {
            isLoading: false,
            dialogVisible: false,
            ResetDialogVisible: false,
            tenderNo: "",
            form:Object.assign({},form),
            rules: {
                checkCode: [
                    {
                        required: true,
                        message: "请输入清单密码",
                        trigger: "blur"
                    },
                    { validator: validate, trigger: "blur" }
                ]
            }
        };
    },
    methods: {
        open(tenderNo) {
            this.tenderNo = tenderNo || "";
            this.dialogVisible = true;
            this.init();
        },
        handleReset(){
            this.dialogVisible = false;
            this.ResetDialogVisible = true;
            this.$nextTick(() => {
                this.$refs["form"].clearValidate();
            });
        },
        handleConfirm(){
            this.$refs["form"].validate(valid => {
                if (valid) {
                    // 开标码MD5加密
                    let password = CryptoJS.MD5(this.form.checkCode).toString();
                    let params = {
                        tenderNo:this.tenderNo,
                        checkCode: password
                    };
                    InterfaceService.setTenderCode(
                        params,
                        data => {
                            let res = data.respData;
                            if (res.respCode === "0000") {
                                this.$message.success("清单密码重置成功！");
                                this.ResetDialogVisible = false
                            } else {
                                this.$message.error(res.respMsg);
                            }
                        },
                        data => {},
                        () => {
                            this.isLoading = true;
                        },
                        () => {
                            this.isLoading = false;
                        }
                    );
                }
            });
        },
        init() {
        },

    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-select {
    width: 100%;
}
.orderConfirmHead {
    margin-top: 12px;
    .isRequired {
        display: inline-block;
        &::before {
            content: '*';
            color: #f56c6c;
            margin-right: 4px;
        }
    }
}
hr {
    border: 1px dashed #ececec;
}

.tip {
    margin-top: 20px;
    margin-bottom: 10px;
}

.term-input.el-input {
    width: 200px;
}
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;

    a {
        text-decoration: underline;
        color: #0082ff;
    }

    a.bold {
        font-weight: bold;
        text-decoration: none;
        color: #444444;
        cursor: default;
    }
    span.red {
        color: #ef3338
    }
    span.blue {
        color: #58bcff;
        cursor: pointer;
    }
}
[class*="el-col-"]{
    display: inline-block;
    float: none;
}
</style>
