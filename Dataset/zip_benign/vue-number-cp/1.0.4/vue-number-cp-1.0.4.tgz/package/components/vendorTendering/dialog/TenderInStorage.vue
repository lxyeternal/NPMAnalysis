<template>
    <div>
        <!-- 确认合同 -->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="840px" center :close-on-click-modal="false">
            <div slot="title" class="el-dialog__title">入选入库</div>
            <div class="tl">
                <div>
                    入选入库是将已中标的货品清单，一键导入至您的【商品管理】-【已上架商品】中。在和采购商签订的战略协议期间内，入选货品一旦入库，将不能下架修改或删除。
                </div>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">一键入库</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="successDialogVisible" width="840px" center :close-on-click-modal="false" @close="handleClose()">
            <div slot="title" class="el-dialog__title">入库成功</div>
            <div class="tl">
                <div class="tc">
                    入选入库的货品，请至<em class="blue hand" @click="goProductListOnline()">【商品管理】-【已上架商品】</em>中查看。若有疑问请联系平台客服。
                </div>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button size="small" style="width: 100px" @click="successDialogVisible = false">关闭</el-button>
            </div>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

export default {
    components: {
        Loading,
    },

    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            successDialogVisible: false,
            tenderNo: "",
        };
    },
    methods: {
        open(tenderNo) {
            this.tenderNo = tenderNo || "";
            this.dialogVisible = true;
            this.init();
        },
        handleConfirm(){
            let params = {
                tenderNo:this.tenderNo
            };
            InterfaceService.putTenderInStorage(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.dialogVisible = false;
                        this.successDialogVisible = true;
                        // this.$emit("refresh")
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        handleClose(){
            this.successDialogVisible = false;
            this.$emit("close",true)
        },
        goProductListOnline(){
            this.$router.push({
                path: "/vendorCenter/productListOnline",
                query: {}
            });
        },
        init() {
        },

    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-select {
    width: 100%;
}

.dialog {
    line-height: 25px;
}

[class*="el-col-"]{
    display: inline-block;
    float: none;
}
</style>
