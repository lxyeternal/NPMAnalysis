<template>
    <div>
        <PanelTitle title="基本信息" class="order-data-message" @foldInfo = "handleFoldInfo" :showFold = showFold :opened = fold></PanelTitle>
        <div class="order-info">
            <template v-if="fold">
                <el-row>
                    <el-col>
                        <div class="order-info-title">基本信息</div>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <p>
                            <label>名称：</label>{{tenderInfo.tenderName}}
                        </p>
                    </el-col>
                </el-row>
                <el-row>
                    <el-col :span="12">
                        <p>
                            <label>编号：</label>
                            <span>
                            <span>{{tenderInfo.tenderNo}}</span>
                        </span>
                        </p>
                    </el-col>
                    <el-col :span="12">
                        <p>
                            <label>发布单位：</label><i>{{tenderInfo.corpName}}</i>
                        </p>
                    </el-col>

                </el-row>
                <el-row>
                    <el-col :span="12">
                        <p>
                            <label>类目：</label><i>{{tenderInfo.fullName}}</i>
                        </p>
                    </el-col>
                    <el-col :span="12">
                        <p>
                            <label>清单递交时间：</label><i v-if="tenderInfo.replyEndDt">{{tenderInfo.replyEndDt.slice(0,10)}}</i>
                        </p>
                    </el-col>
                </el-row>
                <el-row>
                </el-row>
                <!--<el-row>-->
                    <!--<el-col :span="24">-->
                        <!--<label>招标说明：</label>-->
                        <!--<div class="tendering-content">-->
                            <!--{{tenderInfo.explain}}-->
                        <!--</div>-->
                    <!--</el-col>-->
                <!--</el-row>-->
                <el-row>
                    <el-col :span="24">
                    <span>
                        <label>负责人：</label>
                        <i style="font-weight: bold;margin-right: 6px;" v-for="person in tenderInfo.personInChargeList" >
                            {{personInfo(person)}}
                            </i>
                    </span>
                    </el-col>
                </el-row>
            </template>
            <!-- 招标文件 -->
            <TenderingFiles v-if="fileListFold || fold" :docList="tenderInfo.docList" :tenderNo = "tenderInfo.tenderNo"></TenderingFiles>
        </div>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import PanelTitle from "@/components/base/PanelTitle";
import ContractOperate from "@/components/order/ContractOperate";
import SignProcessContract from "@/components/order/SignProcessOrderDetail";
import TenderingFiles from "@/components/vendorTendering/TenderingFiles";
import { InterfaceService } from "@/services/api";
export default {
    mixins: [accountMixin],
    components: {
        PanelTitle,
        ContractOperate,
        SignProcessContract,
        TenderingFiles,
    },
    props: ["tenderNo", "tenderInfo","showFold","opened","fileListFold"],
    data() {
        return {
            roleList: [],
            fold:true,
        };
    },
    computed: {
    },
    watch: {
        tenderInfo(newVal) {
        },
        opened(newVal){
            this.fold = newVal
        }
    },
    methods: {
        personInfo(person){
            let str = "";
            if (person.tel && !person.email) {
                str = person.name + "(Tel:"+person.tel+")"
            }else if (!person.tel && person.email) {
                str = person.name + "(Email:"+person.email+")"
            } else if (person.tel && person.email) {
                str = person.name + "(Tel:"+person.tel+"/Email:"+person.email+")"
            }else {
                str = person.name
            }
            return str
        },
        filterExternalSys(item) {
            let str = "";
            if (item.externalCode) {
                let status = item.approveStatus == 1 ? "审批完成" : "审批中";
                str = "(" + item.sysCode + status + ")";
            }
            return str;
        },
        handleRefresh() {
            this.$emit("refresh");
        },
        // 折叠投标信息
        handleFoldInfo(bool){
            this.fold = bool
        },
        //查看合同
        loadContract(contractNo) {
            InterfaceService.orderCotractDownload(
                { contractNo: contractNo },
                data => {},
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
    .order-info {
        margin-bottom: 20px;
        line-height: 25px;
        font-size: 12px;

        /deep/ .el-col {
            padding: 0 10px;
        }
        /deep/ .el-button{
            padding-top: 4px;
        }
        p {
            width: 100%;
            display: flex;
            padding-right: 10px;
            word-break: break-word;
            white-space: normal;

            & > span {
                display: inline-block;
                flex: 1 1 0%;
            }
        }

        label {
            white-space: nowrap;
            color: #888888;
        }

        a {
            white-space: nowrap;
            color: #0082ff;
        }

        i {
            font-style: normal;
        }
    }

    .order-info-title {
        margin: 5px -10px;
        margin-bottom: 10px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
    }

    .order-sign-role {
        margin-top: 20px;
        padding-top: 20px;
        border-top: 1px solid #f5f5f5;
        .order-info-title {
            margin-bottom: 5px;
        }
    }

    .tendering-content {
        background: #f5f5f5;
        width: 100%;
        height: auto;
        padding: 10px;
        margin-bottom: 5px;
    }

</style>
