<template>
    <div>
        <!-- 下载合同 -->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="downDialogVisible" width="800px" center :close-on-click-modal="false" @close="attachList = [];allCheck = false">
            <div class="tl">
                <PanelTitle :tabs="tabs" bg-color="#fff"></PanelTitle>
                <div class="attach-table">
                    <table>
                        <tr v-for="(row,index) in attachList" :key="index">
                            <template v-if="row.recStat == '1'">
                                <td width="50">
                                    <el-checkbox v-model="row.checked" @change="handleSelectRow(row,index)"></el-checkbox>
                                </td>
                                <td class="blue" @click="handleSeeContract(row)">{{row.docName}}</td>
                            </template>
                        </tr>
                    </table>
                    <el-checkbox v-model="allCheck" @change="handleAllCheck"></el-checkbox>&nbsp;&nbsp;<span>全选</span>
                </div>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleDownload">下载</el-button>
                <el-button size="small" style="width: 100px" @click="handleAllDownload">打包下载</el-button>
                <el-button size="small" style="width: 100px" @click="downDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    const tabs = [
        { label: "报价单", type: "1", active: true },
    ];
    import accountMixin from '@/mixins/account';
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import { InterfaceService } from "@/services/api";
    import download from "@/utils/download";
    import { viewFile } from '@/utils/orderUtil';
    export default {
        mixins:[accountMixin],
        components: {
            Loading,
            PanelTitle
        },
        props:['back'],
        computed: {
        },
        data() {
            return {
                isLoading: false,
                templateDialogVisible: false,
                downDialogVisible: false,
                tender: {},
                tabs: JSON.parse(JSON.stringify(tabs)),
                allCheck: false,
                attachList: [],
            };
        },
        methods: {
            open(data, type) {
                this.tender = data;
                if (type === "template") {
                    this.templateDialogVisible = true;
                } else if (type === "download") {
                    this.downDialogVisible = true;
                }
                this.attachList = [];
                this.getTenderFiles();
            },
            handleSelectRow(row, index) {
                this.$set(this.attachList, index, row);
                this.checkAllSelect();
            },

            /**
             * 查看合同
             */
            handleSeeContract(item) {
                if (item.attachUrl) {
                  viewFile(item.attachUrl)
                }
            },
            // 是否全选
            checkAllSelect() {
                let num = 0;
                this.allCheck = this.attachList.every(item => {
                    num++;
                    return item.checked;
                });

                this.allCheck = num > 0 && this.allCheck;
            },
            handleAllCheck() {
                this.attachList.forEach((item, index) => {
                    if (item.recStat == "1") {
                        item.checked = this.allCheck;
                        this.$set(this.attachList, index, item);
                    }
                });
            },
            handleAllDownload(){
                let documentList = [];
                this.attachList.forEach((item, index) => {
                    if (item.recStat == "1") {
                        documentList.push({
                            docUrl: item.docUrl,
                            docName: item.docName,
                        });
                    }
                });
                let params = {
                    tenderNo: this.tender.tenderNo,
                    documentList: documentList,
                };
                InterfaceService.downloadRenderPackage(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            let packingUrl = data.respData.fileUrl || "";
                            let name = packingUrl.split("?")[0];
                            name = name.split("/").pop();
                            const files = [
                                { name: decodeURIComponent(name), url: packingUrl }
                            ];
                            this.$download(files).then(() => {
                                this.$message.success("已下载");
                            });
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            packingDownload(name,packingUrl){
                const x = new XMLHttpRequest();
                x.open("GET",packingUrl, true);
                x.responseType = "blob";
                x.onload = e => {
                    download(
                        x.response,
                        name+"",
                        x.response.type
                    );
                };
                x.send();
                this.downDialogVisible = false;
                this.$message.success("已下载");
            },
            handleDownload() {
                const attachs = [];
                this.attachList.forEach((item, index) => {
                    if ( item.checked) {
                        attachs.push(item);
                    }
                    item.url = item.attachUrl;
                    item.name = item.docName.split("?")[0]
                });
                if (attachs.length) {
                    this.$download(attachs).then(res=>{
                        this.downDialogVisible = false;
                        this.$message.success("已下载");
                    })
                } else {
                    this.$message.info("请选择需要下载的文件");
                }
            },
            getTenderFiles(){
                let params = {
                    tenderNo: this.tender.tenderNo,
                    docTypeList: [
                        "biddingList","biddingAttach"
                    ]
                };
                InterfaceService.getTenderFiles(
                    params,
                    data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            this.attachList = res.docList || [];
                        } else {
                            this.$message.error(res.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            }
        }
    };
</script>

<style lang="scss" scoped>
    .info {
        color: #888888;
    }
    .dialog {
        line-height: 25px;

        /deep/ .el-dialog__header {
            padding: 0;

            &:before {
                display: none;
            }
        }
    }

    .attach-table {
        padding: 0 20px;

        table {
            width: 100%;
            margin-bottom: 20px;
            border-bottom: 1px solid #eeee;
            .blue {
                color: #58bcff;
                cursor: pointer;
            }
        }
    }
</style>
