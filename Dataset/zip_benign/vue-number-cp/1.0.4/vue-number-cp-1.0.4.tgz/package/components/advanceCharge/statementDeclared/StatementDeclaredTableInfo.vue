<template>
  <div class="statementDeciaredTableInfo" :class="{tdBgColorWhite: tdBgColor == 'white'}">
    <!-- 温馨提示 -->
    <div class="table-container" ref="tableContainer">
      <TableThead :TopDistance="TopDistance" :offsetLeft="this.tableOffsetLeft">
        <tr slot="tr">
          <template v-if="$isIE()">
            <th width="40">序号</th>
            <th width="68">材料大类</th>
            <th width="60">材料类别</th>
            <th width="82">产品名称</th>
            <th width="145">商品名称</th>
            <th width="120">附加项说明</th>
            <th width="110">物料描述</th>
            <th width="66">品牌</th>
            <th width="144">型号</th>
            <th width="212">规格</th>
            <th width="70">单位</th>
            <th width="110">使用标段或部位</th>
            <th width="110">数量</th>
            <th width="92">实际收货日期</th>
            <th width="118">收货编号</th>
            <th width="117">要料单位</th>
            <th width="117">采购单价(含税)(元)</th>
            <th width="">采购金额(含税)(元)</th>
          </template>
          <template v-else>
            <th width="40">序号</th>
            <th width="68">材料大类</th>
            <th width="68">材料类别</th>
            <th width="82">产品名称</th>
            <th width="150">商品名称</th>
            <th width="128">附加项说明</th>
            <th width="118">物料描述</th>
            <th width="66">品牌</th>
            <th width="114">型号</th>
            <th width="182">规格</th>
            <th width="70">单位</th>
            <th width="118">使用标段或部位</th>
            <th width="118">数量</th>
            <th width="86">实际收货日期</th>
            <th width="118">收货编号</th>
            <th width="117">要料单位</th>
            <th width="117">采购单价(含税)(元)</th>
            <th width="">采购金额(含税)(元)</th>
          </template>
        </tr>
      </TableThead>
      <div class="opt-container" v-if="showAboutOpt">
        <div class="left" title="点击向左滚动" v-if="showAboutLeft" @click="handleClickScroll(1)"></div>
        <div class="right" title="点击向右滚动" v-if="showAboutRight" @click="handleClickScroll(2)"></div>
      </div>
      <div class="table-center">
        <h2>应{{tabIndex == 1 ? '付' : '收'}}对账单</h2>
        <table>
          <thead class="thead-flag">
            <tr>
              <!-- th[width=120]{$}*18 -->
              <th width="40">序号</th>
              <th width="70">材料大类</th>
              <th width="70">材料类别</th>
              <th width="84">产品名称</th>
              <th width="152">商品名称</th>
              <th width="130">附加项说明</th>
              <th width="120">物料描述</th>
              <th width="70">品牌</th>
              <th width="114">型号</th>
              <th width="186">规格</th>
              <th width="70">单位</th>
              <th width="120">使用标段或部位</th>
              <th width="120">数量</th>
              <th width="94">实际收货日期</th>
              <th width="134">收货编号</th>
              <th width="120">要料单位</th>
              <th width="120">采购单价(含税)</th>
              <th width="110">采购金额(含税)</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td colspan="2" class="bg-purple">对账单编号</td>
              <td colspan="2">
                <div class="tl">{{tabIndex == 1 ? statementDetailInfo.supplierStatementNo : statementDetailInfo.statementNo || ''}}</div>
              </td>
              <td class="bg-purple">制单日期</td>
              <td>
                <div class="tl">{{statementDetailInfo.createStatementDate}}</div>
              </td>
              <td colspan="2" class="bg-purple">OA编号</td>
              <td colspan="2">
                <div class="tl">{{externalSysList.find(f=>f.externalCode) && externalSysList.find(f=>f.externalCode).externalCode || ''}}</div>
              </td>
              <td colspan="6"></td>
              <td colspan="2"><span class="hand blue" @click="beenReconciled">开票信息</span></td>
            </tr>
            <tr class="title">
              <td class="bg-blue" colspan="8">项目公司项目信息</td>
              <td class="bg-pink" colspan="6">合同及对账信息</td>
              <td class="bg-blue" colspan="4">供应方信息</td>
            </tr>
            <tr>
              <td class="bg-blue" colspan="2">所属事业部</td>
              <td class="bg-blue">所属城市</td>
              <td class="bg-blue" colspan="3">项目公司名称</td>
              <td class="bg-blue" colspan="2">项目经理/电话</td>

              <td class="bg-pink" colspan="2">合同名称</td>
              <td class="bg-pink" colspan="2">合同编号</td>
              <td class="bg-pink" colspan="2">累计对账金额(含税)(不含本次)</td>

              <td class="bg-blue" colspan="2">供应方名称</td>
              <td class="bg-blue">被授权人姓名/电话</td>
              <td class="bg-blue">被授权人电子邮箱</td>
            </tr>
            <tr>
              <td colspan="2">
                <div class="tl">{{orderDetailInfo.groupCompanyName || ''}}</div>
              </td>
              <td>
                <div class="tl">
                  {{orderDetailInfo.projectCityName || ''}}
                </div>
              </td>
              <td colspan="3">
                <div class="tl">{{orderDetailInfo.purchaserName || ''}}</div>
              </td>
              <td colspan="2">
                <div class="tl">
                  <p>
                    {{managerObject.length> 0 ? managerObject[0].acctName : ''}}
                  </p>

                  <p>
                    {{managerObject.length> 0 ? managerObject[0].mobile : ''}}
                  </p>
                </div>
              </td>

              <td colspan="2">
                <div class="blue hand" @click="handleClickJumpOrderDetai" v-if="orderDetailInfo.contractName">
                  《{{orderDetailInfo.contractName || ''}}》
                </div>
              </td>
              <!-- 合同编号 -->
              <td colspan="2">
                <div>
                  {{tabIndex == 1 ? orderDetailInfo.clOrderNo : orderDetailInfo.sybOrderNo || ''}}
                </div>
              </td>
              <!-- 累计对账金额(含税)(不含本次) -->
              <td colspan="2">
                <div class="tr">
                  {{tabIndex == 1 ? orderDetailInfo.statementAmtWithTaxTotal : orderDetailInfo.inStatementAmtWithTaxTotal || '' | formatMoney}}元
                </div>
              </td>

              <td colspan="2" rowspan="3">
                <div class="tl">{{orderDetailInfo.supplierName || ''}}</div>
              </td>
              <td rowspan="3">
                <div class="tl">
                  {{ currentObject.length > 0 ? currentObject[0].acctName : ''}}
                  <p>
                    {{ currentObject.length > 0 ? currentObject[0].mobile : ''}}
                  </p>
                </div>
              </td>
              <td rowspan="3">
                <div class="tl">{{ currentObject.length > 0 ? currentObject[0].email : ''}} </div>
              </td>
            </tr>

            <tr>
              <td class="bg-blue" colspan="2">项目标段</td>
              <td class="bg-blue">项目分期</td>
              <td class="bg-blue" colspan="3">项目名称</td>
              <td class="bg-blue" colspan="2">项目经理电子邮箱</td>

              <td class="bg-pink" colspan="2">合同金额(含税)</td>
              <td class="bg-pink" colspan="2">本次对账金额(含税)</td>
              <td class="bg-pink" colspan="2">累计对账金额(含税)(含本次)</td>

            </tr>
            <tr>
              <td colspan="2">
                <div class="tl"> {{orderDetailInfo.building || ''}} </div>
              </td>
              <td>
                <div class="tl">{{orderDetailInfo.projectTermName || ''}}</div>
              </td>
              <td colspan="3">
                <div class="tl"> {{orderDetailInfo.projectName || ''}} </div>
              </td>
              <td colspan="2">
                <div class="tl">{{managerObject.length> 0 ? managerObject[0].email : ''}} </div>
              </td>

              <!-- 合同金额(含税) -->
              <td colspan="2" class="tr">
                <div class="tr" v-if="!(orderDetailInfo && orderDetailInfo.replenishContractInfo && orderDetailInfo.replenishContractInfo.relContractList && orderDetailInfo.replenishContractInfo.relContractList.length)">{{tabIndex == 1 ? orderDetailInfo.outContractFeeWithTax : orderDetailInfo.inContractFeeWithTax || '' | formatMoney}}元</div>
                <div class="tr" v-else style="margin: 10px 8px 4px">
                  <p>{{tabIndex == 1 ? orderDetailInfo.allOutContractFeeWithTax : orderDetailInfo.allInContractFeeWithTax || '' | formatMoney}}元</p>
                  <p class="tr grey">(主合同金额：{{tabIndex == 1 ? orderDetailInfo.outContractFeeWithTax : orderDetailInfo.inContractFeeWithTax || '' | formatMoney}}元)</p>
                  <p class="tr grey">(补充合同金额：{{tabIndex == 1 ? orderDetailInfo.replenishOutContractFeeWithTax : orderDetailInfo.replenishInContractFeeWithTax || '' | formatMoney}}元)</p>
                </div>
              </td>
              <!-- 本次对账金额(含税) -->
              <!-- 对账单详情 返回 数据  减掉 本页数据 = 不含本页总和, 然后 用户输入后 把本页数之和 加上 不含本页总和 = 总金额 -->
              <td class="tr red" colspan="2">
                <!-- 因为 thisStatementAmtWithTax 已经别改过了 所以使用 thisStatementAmtWithTaxBackUp -->
                <span v-if="statementDetailInfo.enterFrom == '2'">{{thisStatementAmtWithTaxBackUp | formatMoney}}元</span>
                <span v-else>{{statementAmtWithTaxCp | formatMoney}}元</span>
              </td>
              <!-- 累计对账金额(含税)(含本次) -->
              <td colspan="2" class="tr">
                <span v-if="statementDetailInfo.enterFrom == '2'">{{thisStatementAmtWithTaxBackUp | formatMoney}}元</span>
                <span v-else>{{numberUtilCp.numAdd(Number(tabIndex == 1 ? orderDetailInfo.statementAmtWithTaxTotal : orderDetailInfo.inStatementAmtWithTaxTotal), Number(statementAmtWithTaxCp)) | formatMoney}}元</span>
              </td>

            </tr>
            <tr>
              <td class="bg-purple">序号</td>
              <td class="bg-purple">材料大类</td>
              <td class="bg-purple">材料类别</td>
              <td class="bg-purple">产品名称</td>
              <td class="bg-purple">商品名称</td>
              <td class="bg-purple">附加项说明</td>
              <td class="bg-purple">物料描述</td>
              <td class="bg-purple">品牌</td>
              <td class="bg-purple">型号</td>
              <td class="bg-purple">规格</td>
              <td class="bg-purple">单位</td>
              <td class="bg-purple">使用标段或部位</td>
              <td class="bg-purple">数量</td>
              <td class="bg-purple">实际收货日期</td>
              <td class="bg-purple">收货编号</td>
              <td class="bg-purple">要料单位</td>
              <td class="bg-purple">采购单价(含税)(元)</td>
              <td class="bg-purple">采购金额(含税)(元)</td>
            </tr>
          </tbody>
          <tbody class="tableDataListTbody">
            <tr v-for="(item, idx) in tableDataList" :key="idx">

              <td>
                <div class="tl">{{item.index}}</div>
              </td>
              <td>
                <div class="tl">{{item.datum || ''}}</div>
              </td>
              <td>
                <div class="tl">{{item.datumType || ''}}</div>
              </td>
              <td>
                <div class="tl">{{item.productName || ''}}</div>
              </td>
              <td>
                <div class="tl">{{item.skuName || '' }}</div>
              </td>
              <td>
                <div class="tl surchargeDetailListContainer h72">
                  <el-tooltip v-if="item.surchargeDetailList && item.surchargeDetailList.length" class="item" effect="dark" placement="top-start">
                    <div slot="content">
                      <p v-for="(sItem, sIdx) in  item.surchargeDetailList" :key="sIdx">
                        附加项{{sIdx + 1}}：{{sItem.surchangeName}}&nbsp;&nbsp;X{{sItem.surchangeUnitCnt}}{{sItem.surchangeUnit}} &nbsp;&nbsp;<span style="color: #c99f4f;">
                          ￥{{tabIndex == 1 ? sItem.outSurchangeUnitPrice : sItem.inSurchangeUnitPrice | formatMoney}}</span>
                      </p>
                    </div>
                    <div class="blue">
                      <p v-for="(sItem, sIdx) in  item.surchargeDetailList" :key="sIdx">
                        附加项{{sIdx + 1}}：{{sItem.surchangeName}}&nbsp;&nbsp;X{{sItem.surchangeUnitCnt}}{{sItem.surchangeUnit}} &nbsp;&nbsp;<span style="color: #c99f4f;">
                          ￥{{tabIndex == 1 ? sItem.outSurchangeUnitPrice : sItem.inSurchangeUnitPrice | formatMoney}}</span>
                      </p>
                    </div>
                  </el-tooltip>
                </div>
              </td>
              <td>
                <div class="tl h72">
                  <el-tooltip class="item" v-if="item.itemDescription" effect="dark" :content="item.itemDescription" placement="top-start">
                    <div class="blue"> {{item.itemDescription || ''}}</div>
                  </el-tooltip>
                </div>
                <!-- <div class="tl">{{item.itemDescription || ''}} </div> -->
              </td>
              <td>
                <div class="tl"> {{item. brandNameCn || ''}} </div>
              </td>
              <td>
                <div class="tl">{{item.model || ''}}</div>
              </td>
              <td>
                <div class="t">
                  <div class="tl h72">
                    <el-tooltip class="item" v-if="item.attrInfo" effect="dark" :content="item.attrInfo" placement="top-start">
                      <div class="blue"> {{item.attrInfo || ''}}</div>
                    </el-tooltip>
                  </div>
                  <!-- <div class="tl">{{item.attrInfo || ''}} </div> -->
                </div>
              </td>
              <td>
                <div class="tl">{{item.goodsUnit || ''}}</div>
              </td>
              <td>
                <div class="tl">{{item.location || ''}}</div>
              </td>
              <td>
                <div class="tr">{{item.requireCount || ''}}</div>
              </td>

              <td>
                <div class="tl">
                  <!-- whitePre -->
                  {{item.requireTimeFrom || ''}}
                </div>
              </td>
              <!-- 收货编号 -->
              <td>
                <div class="tl">
                  <!-- whitePre -->
                  {{item.deliveryNo || ''}}
                </div>
              </td>
              <td>
                <!-- 要料单位 -->
                <div class="tl">
                  {{item && item.constructorCorp && item.constructorCorp.corpName || ''}}
                </div>
              </td>
              <!-- 采购单价(含税)(元 -->
              <td class="edit-pricr-container" :class="{selectActive: !examine  && !isReview && item.priceModel == 'floatingPrice' && item.selectActive, floatingPriceSty: item.priceModel == 'floatingPrice'}" :ref="`td${item.skuId}`" :style="{height: getTdHeight($refs[`td${item.skuId}`]) + 'px'}" @contextmenu="openMenu($event, item, item.index)" @click="handleClickSelect(item, item.index)">
                <div>
                  <input v-if="!isReview && item.priceModel == 'floatingPrice'" type="text" :style="{textAlign: item.txtAlign == 'tr' ? 'right' : 'left'}" v-model="item.includeTaxPrice" :ref="item.skuId" v-input-custom-reg="{reg:'^\\d{0,9}(\\.\\d{0,2})?$|^\\s*$'}" @focus="handleEditInputFocus($refs[item.skuId], $event, item)" @blur="item.txtAlign = 'tr'">
                  <span v-else>{{item.includeTaxPrice | formatMoney}}</span>
                </div>
              </td>
              <!-- 采购金额(含税)(元) -->
              <td width="120">
                <div class="tr">{{purchasePriceComputed(item) | formatMoney}}</div>
                <!-- <div class="tr">{{ (tabIndex == 1 ? Number(item.totalAmtWithTax) : Number(item.inTotalAmtWithTax)) | formatMoney}}</div> -->
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="table-pagination" v-if="tableDataList && tableDataList.length">
      <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="form.pageTotal" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
      </el-pagination>
    </div>

    <div class="download-container">
      <div>
        <span class="title">相关单据</span>
        <span class="download blue-pointer" v-if="deliveryAttachList && deliveryAttachList.length" @click="handleOtherDownload">下载</span>
      </div>
      <div class="fileList" v-if="deliveryAttachList && deliveryAttachList.length">
        <p v-for="(item,index) in deliveryAttachList" :key="index">
          {{item.deliveryName || item.requireName}}
          <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="item.attachUrl" :attachName="item.deliveryName || item.requireName"></DownloadAndView>
        </p>
      </div>
      <div class="fileList" v-else>
        无
      </div>
    </div>

    <div class="upload-container">
      <ul>
        <li class="title">附件</li>
      </ul>
      <div class="other-title">
        <span>其他附件</span>
        <DownloadAndUpload appName="TRD" v-if="!isReview" :hasDownloadFlg="false" fromId="authorizationFile" :fileList="otherList" uploadType="13" @outputValue="handleUpFileResult"></DownloadAndUpload>
        <span class="f12 hand blue" v-else-if="otherList && otherList.length" @click="handleOtherDownload('other')">下载</span>
      </div>
      <div class="fileList">
        <div v-if="otherList.length == 0" class="nodata">未上传附件！</div>
        <p v-for="(item, index) in otherList" :key="index">
          {{item.attachName}}
          <DownloadAndView downloadName="下载" viewName="预览" :hideRotate="true" :attachUrl="item.viewUrl || item.attachUrl" :attachName="item.attachName"></DownloadAndView>
          &nbsp;&nbsp;
          <span class="hand blue" v-if="!isReview && !examine" @click="delOther(index)">删除</span>
        </p>
      </div>
    </div>
    <BaseFloatBottomComponent ref="baseFloatBottomRef" @close="handleCloseBaseFloatBottom"></BaseFloatBottomComponent>

    <InvoicBaseInfoBottomComponent :tabIndex="tabIndex" ref="invoicBaseInfoBottomComponentRef" :orderDetailInfo="orderDetailInfo" @close="handleCloseFloatBottom"></InvoicBaseInfoBottomComponent>
    <el-dialog class="dialog bulk-fill-price-container" :title="'批量设置采购单价(含税)'" :append-to-body="true" :lock-scroll="true" :visible.sync="bulkFillPriceDialog" width="850px" center :close-on-click-modal="false">
      <div class="container">
        <div class="center">
          <i class="red">*</i>
          <span>采购单价(含税)：</span>
          <div class="input-div">
            <input type="text" v-model="bulkFillPrice" v-input-custom-reg="{reg:'^\\d{0,9}(\\.\\d{0,2})?$|^\\s*$'}" placeholder="请输入单价">
            <em>元</em>
          </div>
        </div>
        <div class="btn-center">
          <el-button size="small" type="primary" style="width: 120px" :disabled="!bulkFillPrice.replace(/\s+/g,'')" @click="handleDialogConfirm">确认</el-button>
          <el-button size="small" style="width: 120px" @click="handleDialogCancel">取消</el-button>
        </div>
      </div>
    </el-dialog>

    <ul v-show="menuVisible" :style="{left:left+'px',top:top+'px'}" class="contextmenu">
      <!-- <li @click="handleClichEdit(1)">查询价格</li> -->
      <li @click="handleClichEdit(2)">批量填写单价</li>
      <li @click="handleClearActivedeliveryList">清空</li>
      <li @click="docClick">取消选择</li>
    </ul>

    <FixBottom v-if="!isReview" class="agreement_read_container">
      <div class="agreement_read" v-if="!isReview">
        <label>
          <el-checkbox v-model="readStatusChecked"></el-checkbox>
          <p>我承诺已仔细阅读本对账相关信息、账户信息及对账单物料明细，确认其内容没有疑议。</p>
        </label>
      </div>
    </FixBottom>
    <FixBottom v-if="!isReview">
      <div class="tc">
        <el-button type="primary" style="width: 120px;" :disabled="!readStatusChecked" @click="handleClickBottom(1)">提交</el-button>
        <el-button @click="handleClickBottom(2, true)">保存</el-button>
        <!-- <el-button @click="handleClickBottom(3)">上一步</el-button> -->
      </div>
    </FixBottom>
    <Loading :isLoading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import FixBottom from "@/components/base/FixBottom";
import { InterfaceService } from "@/services/api";
import UpfileComponent from "@/components/tender/upfileComponent";
import DownloadAndView from '@/components/order/DownloadAndView'

import BaseFloatBottomComponent from "@/components/advanceCharge/statementDeclared/BaseFloatBottomComponent";
import InvoicBaseInfoBottomComponent from "@/components/advanceCharge/advancePaymentRequest/InvoicBaseInfoBottomComponent";
import DownloadAndUpload from "@/components/base/DownloadAndUpload";
import { NumberUtil } from '@/utils/numberUtil'
import TableThead from "@/components/base/TableThead";

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    FixBottom,
    TableThead,
    DownloadAndUpload,
    DownloadAndView,
    BaseFloatBottomComponent,
    InvoicBaseInfoBottomComponent,
  },
  props: {
    // td 背景色
    tdBgColor: {
      type: String,
      default: ''
    },
    // 是否查看模式
    isReview: {
      type: Boolean,
      default: false
    },
    // 区分 0:材料合同对账单 , 1:事业部合同对账单
    tabIndex: {
      type: Number,
      default: 0
    },
    // 是否分页时调用保存
    pageSave: {
      type: Boolean,
      default: false
    },
    // table 表头偏移量
    TopDistance: {
      type: Number,
      default: 604
    },
    // 外部传入数据, 如果没有传 则自己发送请求
    dataList: {
      type: Array,
      default() {
        return []
      }
    },
  },
  data() {
    return {
      statementNo: '',
      tableOffsetLeft: 0,
      readStatusChecked: false,
      form: {
        pageSize: 10,
        pageIndex: 1,
        pageTotal: 1
      },
      orderDetailInfo: {},
      tableDataList: [],

      // 右键
      editPriceState: true,
      menuVisible: false,
      top: 0,
      left: 0,

      // 键盘 快捷键
      keyboard: 0,
      lastKeyIdx: -1,
      selectedList: [],

      // 上传下载
      deliveryAttachList: [],
      otherList: [],

      // 批量填写
      bulkFillPriceDialog: false,
      bulkFillPrice: '',

      currentObject: [],
      managerObject: [],
      projectObject: [],


      orderNo: '',

      statementDetailInfo: {},
      isInit: false,
      isLoading: false,
      examine: false,
      selectInputTimer: null, // 选择输入框


      showAboutOpt: false,
      showAboutLeft: true,
      showAboutRight: true,
      thisStatementAmtWithTaxBackUp: 0, // 本次对账金额(含税)
      isInitWatch: true,
    }
  },
  watch: {
    async tabIndex() {
      // 防止 初始化 和 watch 一起调用, 出现调用两次同接口请款,  单brokerRole (材料公司) 角色登录时 不会触发 tabIndex变化, 所以 不需要检测是否第一次加载
      if (!this.isInitWatch || this.brokerRole) {
        this.$nextTick(async e => {
          await this.orderDetails()
          this.form.pageIndex = 1
          this.getDetail()
        })
      }
      this.isInitWatch = false
    },
  },
  computed: {

    getTdHeight(domTd) {
      return domTd => {
        // IE 输入框 兼容
        if (this.$isIE() && domTd && domTd[0]) {
          domTd = domTd || []
          return domTd && domTd[0] && domTd[0].offsetHeight
        }
      }
    },
    externalSysList() {
      return this.statementDetailInfo && this.statementDetailInfo.externalSysList || []
    },
    comupSurchangeUnitPrice() {
      return function (price, num) {
        return Number(NumberUtil.accMul(price, +num))
      }
    },
    // 动态计算 本次对账金额(含税)
    statementAmtWithTaxCp() {
      // 暂时 不区分 内外部
      const stateTotal = this.tabIndex == 1 ? this.statementDetailInfo.thisStatementAmtWithTax : this.statementDetailInfo.thisStatementAmtWithTax
      // this.thePurchaseAmountComputed -- 这个值有误差

      // 二期 需要 动态计算 总金额
      return NumberUtil.numAdd(Number(stateTotal), Number(this.thePurchaseAmountComputed))
      // return stateTotal
    },
    // 本页 采购金额(含税)(元) 之和
    thePurchaseAmountComputed() {
      let total = 0
      this.tableDataList.forEach(f => {
        total = NumberUtil.numAdd(total, this.purchasePriceComputed(f) || 0).toFixed(2)
      })
      return total
    },
    // 采购金额(含税)(元)
    purchasePriceComputed() {
      return item => {
        return NumberUtil.accMul(Number(item.includeTaxPrice), Number(item.requireCount))
      }
    },
    numberUtilCp() {
      return NumberUtil
    },
    isMultipleData() {
      const filterList = this.tableDataList && this.tableDataList.filter(f => f.selectActive) || []
      return filterList.length >= 1
    }
  },
  methods: {
    init() {

      console.log(this.tabIndex, 'init  tabIndex');

      this.toFixedRest()
      // 从确认对账清单 过来 需要 初始化查询 验收单, 否则直接拿 保存过的数据
      this.isInit = this.$route.query.isInit || ''
      this.orderNo = this.$route.query.orderNo || ''
      this.statementNo = this.$route.query.statementNo || ''
      this.examine = this.$route.query.examine || false
      this.initAddEvent()
      this.$nextTick(async e => {
        await this.orderDetails()
        this.getDetail()

        this.$refs.tableContainer && this.setBrowser()
      })
    },

    setBrowser() {
      // div 滚动条 拖动 触发
      document.querySelector(".table-container") && (document.querySelector(".table-container").onscroll = (e) => {
        this.tableOffsetLeft = e.target && e.target.scrollLeft || 0
        this.setAboutShowHide()
      })
      // 初始化 是否显示 左右按钮
      this.showAboutOpt = this.$refs.tableContainer && this.$refs.tableContainer.offsetWidth < 1900
      this.setAboutShowHide()
      window.onresize = () => {
        this.showAboutOpt = this.$refs.tableContainer && this.$refs.tableContainer.offsetWidth < 1900
        this.setAboutShowHide()
      }
    },

    // 左右按钮显示条件判断
    setAboutShowHide() {
      this.showAboutLeft = this.showAboutOpt && this.$refs.tableContainer.scrollLeft > 10
      // clientWidth 浏览器 可显示宽度 + 滚动条滚动Left
      this.showAboutRight = this.$refs.tableContainer && (this.$refs.tableContainer.clientWidth + this.$refs.tableContainer.scrollLeft < 1900)
    },

    // 横向滚动
    handleClickScroll(state) {
      const oldScrollLeft = this.$refs.tableContainer.scrollLeft
      switch (state) {
        case 1:
          // 左
          this.$refs.tableContainer.scrollLeft = oldScrollLeft - 100
          break;

        case 2:
          // 右
          this.$refs.tableContainer.scrollLeft = oldScrollLeft + 100
          break;

        default:
          break;
      }
    },

    formatTableData() {
      this.tableDataList.forEach(f => {
        // 采购单价（含税）
        this.$set(f, 'includeTaxPrice', this.tabIndex == 1 ? f.unitPriceWithTax : f.inUnitPriceWithTax)
        this.$set(f, 'selectActive', false)
        this.$set(f, 'txtAlign', 'tr')
      })
    },

    orderDetails() {
      return new Promise(resovle => {
        const params = {
          orderNo: this.orderNo,
          statementNo: this.$route.query.supplierStatementNo || '',
        }
        InterfaceService.orderDetails(params, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.orderDetailInfo = data.respData || {}
            const contractStakeHolders = this.orderDetailInfo.contractStakeHolders || [],
              orderBankAcctInfo = this.orderDetailInfo.orderBankAcctInfo || []

            this.currentObject = contractStakeHolders.filter(item => item.role === '30')
            this.managerObject = contractStakeHolders.filter(item => item.role === '21')
            this.projectObject = orderBankAcctInfo.filter(item => item.acctBankType == 1)
          } else {
            this.$message.error(data && data.respData && data.respData.respMsg)
          }
          resovle(true)
        }, data => {
          this.$message.error(data.respData && data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },

    handleClickJumpOrderDetai() {
      window.open(this.$router.resolve({
        path: '/orderDetail',
        query: {
          orderNo: this.orderDetailInfo && this.orderDetailInfo.orderNo
        }
      }).href, '_blank')
    },


    // 获取其他附件数据
    handleUpFileResult(e) {
      const { attachPath, attachName, attachUrl } = e
      this.otherList.push({
        attachName: attachName,
        attachUrl: attachUrl,
        filesUrl: attachPath,
        fileTypeId: "otherFile",
      })
    },

    handleOtherDownload(state) {
      if (state == 'other') {
        const fileInfoBeans = this.otherList.map(m => {
          return {
            archivePath: '其他附件/' + (m.attachName || ''),
            fileUrl: m.attachUrl,
          }
        })

        this.packageDownload(fileInfoBeans, '其他附件')
      } else {
        this.isLoading = true
        const fileInfoBeans = this.deliveryAttachList.map(m => {
          return {
            archivePath: `相关单据/${m.deliveryName && '验收单' || m.requireName && '发货单' || ''}/${m.deliveryName || m.requireName || ''}`,
            fileUrl: m.attachUrl,
          }
        })
        this.packageDownload(fileInfoBeans, '对账单申报相关单据')
      }
    },

    // 打包下载
    packageDownload(fileInfoBeans, fileName) {
      let params = {
        fileInfoBeans,
        protocol: "https",
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: this.orderDetailInfo && this.orderDetailInfo.contractName + `${fileName}.zip`, url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
                this.isLoading = false
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },

    delOther(idx) {
      this.otherList.splice(idx, 1)
    },

    async handleCurrentChange(page) {
      // 供应商创建时 有浮动价的时候 才 触发保存
      // this.tableDataList && this.tableDataList.some(s => s.priceModel == 'floatingPrice')
      this.pageSave && this.tableDataList && this.tableDataList.some(s => s.priceModel == 'floatingPrice') && await this.handleClickBottom(2, false, true)
      this.form.pageIndex = page;
      this.getDetail(true)
    },
    // isPage分页触发
    handleClickBottom(state, showMsg, isPage) {
      switch (state) {
        case 1:
          this.$confirm("确认提交对账单吗？", "操作提示", {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            confirmButtonText: "确认",
            cancelButtonText: '取消',
          }).then(async () => {
            if (await this.generateStatements('save')) {
              this.generateStatements('submit')
            }
          }).catch(() => {
          });
          break;

        case 2:
          return new Promise(async resolve => {
            resolve(await this.generateStatements('save', showMsg, isPage))
          })
          break;
        case 3:
          this.$router.push({
            path: '/statementDeclaredFirst',
            query: {
              orderNo: this.$route.query.orderNo
            }
          })
          break;

        default:
          break;
      }
    },

    // isPage 分页触发
    generateStatements(operType, showMsg, isPage) {
      return new Promise((resolve, reject) => {
        const delArr = [],
          goodsList = []
        this.tableDataList.forEach(f => {
          delArr.push(f.deliveryNo)
          goodsList.push({
            deliveryDetailId: f.deliveryDetailId,
            updatePrice: f.includeTaxPrice || '' + '',
          })
        })

        // deliveryDetailId
        // updatePrice
        const params = {
          operType: operType,
          statementType: 2,
          orderNo: this.orderNo,
          goodsList,
          uploadFiles: this.$clone(this.otherList) || [],
          statementNo: this.statementNo || ''
        }
        if (params.uploadFiles.length) {
          params.uploadFiles.forEach(f => f.fileTypeId = "otherFile", )
        }

        InterfaceService.generateStatements(params, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.statementNo = data.respData.statementNo || ''
            if (operType == 'save') {
              if (showMsg) {
                this.$message.success('保存成功')
                // 分页触发的保存 不需要 获取数据, 因为分页会执行一次
                !isPage && this.getDetail()
                if (window.opener) {
                  window.opener.location.reload();
                }
              }
            } else {
              if (window.opener) {
                window.opener.location.reload();
              }
              this.$router.push({
                path: '/resultsFeedback',
                query: {
                  type: 'statementDeclaredTableInfo',
                  orderNo: this.orderNo,
                  statementNo: this.statementNo,
                  purchaserStatementNo: this.$route.query.purchaserStatementNo,
                  supplierStatementNo: this.$route.query.supplierStatementNo,
                }
              })
            }
            resolve(data.respData)
          } else {
            this.$message.error(data && data.respData && data.respData.respMsg)
            reject(data.respData)
          }
        }, data => {
          this.$message.error(data.respData && data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },

    initAddEvent() {
      if (this.examine || this.isReview) {
        return
      }

      const _this = this
      document.querySelector("body").addEventListener("keydown", this.keydown);
      document.querySelector("body").addEventListener("keyup", this.keyup);
      // document.querySelector("body").addEventListener("click", function (e) { _this.docClick(e) });
      window.onscroll = () => {
        this.closeMenu()
      }
      document.querySelector(".table-container").onscroll = () => {
        this.closeMenu()
      }
    },
    handleCloseFloatBottom() { },

    handleEditInputFocus(domIpt, ev, item) {
      item.txtAlign = 'tl'
    },
    beenReconciled() {
      const corpId = this.tabIndex == 1 ? this.orderDetailInfo.brokerCorpId : this.orderDetailInfo.purchaserId
      this.$refs["invoicBaseInfoBottomComponentRef"].open(corpId)
    },
    handleClearActivedeliveryList() {
      this.tableDataList.forEach(f => {
        f.selectActive && (f.includeTaxPrice = 0)
      })
      this.menuVisible = false
    },
    handleDialogConfirm() {
      // 去除无效0
      this.bulkFillPrice = this.bulkFillPrice.replace(/\b(0+)/gi, "")
      this.handleCloseBaseFloatBottom(this.bulkFillPrice)
      this.handleDialogCancel()
    },
    handleDialogCancel() {
      this.bulkFillPriceDialog = false
    },
    handleClichEdit(state) {
      if (state == 1) {
        this.$refs["baseFloatBottomRef"].open()
      } else if (state == 2) {
        // 批量修改

        if (this.tableDataList && this.tableDataList.some(s => s.priceModel == 'floatingPrice')) {
          this.bulkFillPrice = ''
          this.bulkFillPriceDialog = true
        }
      }
      this.menuVisible = false
    },

    handleCloseBaseFloatBottom(value) {

      this.tableDataList.forEach(f => {
        f.priceModel == 'floatingPrice' && f.selectActive && (f.includeTaxPrice = value || 0)
      })
      console.log(this.tableDataList, '-tableDataList');
    },


    // 右键
    openMenu(e, item, idx) {
      // 如果列表中 没有 可支持 修改 的 字段 就别显示右键了
      if (this.tableDataList && this.tableDataList.some(s => s.priceModel == 'floatingPrice')) {
        e && e.preventDefault && e.preventDefault()
        if (this.examine || this.isReview) {
          return
        }
        const X = e.pageX,
          Y = e.pageY,
          clW = document.documentElement.clientWidth // 浏览器宽度

        // 只有一条的时候 右键 默认选中此条数据
        if (!this.isMultipleData) {
          this.handleClickSelect(item, idx, true)
        }
        const scrollObj = this.getScrollbar() || {}
        this.top = Y - scrollObj.top
        if (clW - (X + 104) > 0) {
          this.left = X - scrollObj.left
        } else {
          this.left = clW - 130
        }
        this.menuVisible = true;
      }
    },
    closeMenu() {
      this.menuVisible = false;
    },

    /********************
     * 取窗口滚动条宽高
     ******************/
    getScrollbar() {
      let result = {}
      /*
        主要是做兼容处理
        这里必须时!=null 因为默认值和每次滚动的时侯  都可以值为0
        但是 if(0)为假  所以就只要不为null 就执行
      */
      if (window.pageYOffset != null) {
        /*IE9 和其他标准浏览器*/
        result = {
          left: window.pageXOffset,
          top: window.pageYOffset
        }
        /*声明了<!DOCTYPE html> */
      } else if (document.compatMode == "CSS1Compat") {
        result = {
          left: document.documentElement.scrollLeft,
          top: document.documentElement.scrollTop
        }
      } else {
        result = {
          left: document.body.scrollLeft,
          top: document.body.scrollTop
        }
      }

      return result
    },

    // addEvent 绑定快捷键

    clearAllActive() {
      this.tableDataList.forEach(item => {
        item.selectActive = false
      })
    },
    // state 右键情况  必须为选中状态
    handleClickSelect(selectItem, index, state) {

      if (selectItem.priceModel != 'floatingPrice') return
      clearTimeout(this.selectInputTimer)
      this.selectInputTimer = null
      if (this.examine || this.isReview) {
        return
      }
      this.closeMenu()

      this.selectInputTimer = setTimeout(e => {
        // shift
        if (this.keyboard === 2 && this.lastKeyIdx != -1) {
          this.clearAllActive()
          for (let i = Math.min(index, this.lastKeyIdx) - 1; i <= Math.max(index, this.lastKeyIdx) - 1; i++) {
            this.tableDataList.forEach((item, ind) => {
              if (ind == i) {
                if (item.priceModel != 'floatingPrice') return
                item.selectActive = true
              }
            })
          }
          // ctrl
        } else if (this.keyboard === 1) {
          selectItem.selectActive = state || !selectItem.selectActive;
          this.lastKeyIdx = index;
        } else {
          const selectActive = !selectItem.selectActive
          this.clearAllActive()
          selectItem.selectActive = state || selectActive;
          this.lastKeyIdx = index;
        }
      }, 0)


    },
    //ctrl、shift按下
    keydown(e) {
      if (e.ctrlKey) {
        this.keyboard = 1;
      } else if (e.shiftKey) {
        this.keyboard = 2;
      }
    },
    keyup(e) {
      this.keyboard = 0;
    },

    // 计算采购金额(含税) 总数, 本次对账金额(含税) = thisStatementAmtWithTax - total + 本页数据总和
    computedTotalAmtWithTax() {
      const isIn = this.tabIndex == 0 // 内部
      let total = 0
      this.tableDataList.forEach(f => {
        total = NumberUtil.numAdd(total, Number(isIn ? f.inTotalAmtWithTax : f.totalAmtWithTax))
      })

      if (this.thisStatementAmtWithTaxBackUp) {
        this.statementDetailInfo.thisStatementAmtWithTax = NumberUtil.numSub(Number(this.thisStatementAmtWithTaxBackUp), total)
      }
    },

    // 对账单详情
    // isChangePage 如果是分页, 只改标列表数据
    getDetail(isChangePage) {
      const params = {
        pageFlg: this.tabIndex,
        statementNo: (this.tabIndex == 1 ? this.$route.query.supplierStatementNo : this.statementNo) || this.statementNo,
        orderNo: this.orderNo,
        statementType: 2,
        pageIndex: this.form.pageIndex,
      };

      InterfaceService.getStatementDetail(
        params,
        data => {
          let res = data.respData || {}
          if (res.respCode === "0000") {
            // 只改标列表数据
            const item = res.statementDetails && res.statementDetails[0] || {}
            this.tableDataList = item.deliveryDetail || []
            this.form.pageTotal = item.totalCount || 1
            this.formatTableData()
            if (isChangePage) {
              this.computedTotalAmtWithTax()
              return
            }
            this.statementDetailInfo = res || {}
            this.thisStatementAmtWithTaxBackUp = this.statementDetailInfo.thisStatementAmtWithTax || 0

            // 接口返回后 先 thisStatementAmtWithTax - 本页数据
            this.computedTotalAmtWithTax()
            const { deliveryList = [], requireList = [] } = this.statementDetailInfo

            this.deliveryAttachList = deliveryList && deliveryList.concat(requireList || []) || requireList || []
            this.contractValue = res.requireNo || ''
            this.otherList = res.uploadFiles || []
            this.proportion = NumberUtil.accMul(+res.prepaymentRatio, 100) || ''
            this.proportion && (this.inputTxt = 'tr')

            // 向父级 返回数据
            let flowList = []
            if (res.processNodeList && res.processNodeList.length) {
              res.processNodeList.forEach(item => {
                flowList.push({
                  foot_title: item.flowName,
                  lightShow: item.isCurrentNode,
                  top_info: item.operTime && item.operTime.substring(0, 10) || "",
                  top_end_info: item.operTime && item.operTime.substring(11, item.operTime.length) || "",
                })
              })

            }

            let onOff = false,
              activeNode = 0

            flowList.forEach((item, index) => {
              if (item.lightShow === '1') {
                onOff = true
                // 判断到最后一步 + 1
                // index + 1 == flowList.length ? index + 1 :
                activeNode = index;
              }
            });
            if (!onOff) {
              activeNode = 3
            }


            //退回、拒绝流程节点
            let orderOperFlow = [];
            let list = res.statementOperFlowList || [];
            list.forEach(item => {
              if (item.operType == 'purchaserReturn') {
                orderOperFlow.push({
                  name: item.operAcctName,
                  comment: item.operMsg,
                  department: "",
                  time: item.operTime || "",
                })
              }
            })

            // res.statementDetails[0].deliveryDetail[0].priceModel = 'floatingPrice'
            this.$emit('refreshData', {
              flowList,
              activeNode,
              orderOperFlow,
              orderDetailInfo: this.orderDetailInfo || {},
              statementDetailInfo: res || {}
            })
          } else {
            this.$message.error(res.respMsg);
          }
        },
        data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        });
    },
    /**
    * 修复 toFixed 精度问题
    */
    toFixedRest() {
      // toFixed兼容方法
      Number.prototype.toFixed = function (len) {
        if (len > 20 || len < 0) {
          throw new RangeError('toFixed() digits argument must be between 0 and 20');
        }
        // .123转为0.123
        var number = Number(this);
        if (isNaN(number) || number >= Math.pow(10, 21)) {
          return number.toString();
        }
        if (typeof (len) == 'undefined' || len == 0) {
          return (Math.round(number)).toString();
        }
        var result = number.toString(),
          numberArr = result.split('.');

        if (numberArr.length < 2) {
          //整数的情况
          return padNum(result);
        }
        var intNum = numberArr[0], //整数部分
          deciNum = numberArr[1],//小数部分
          lastNum = deciNum.substr(len, 1);//最后一个数字

        if (deciNum.length == len) {
          //需要截取的长度等于当前长度
          return result;
        }
        if (deciNum.length < len) {
          //需要截取的长度大于当前长度 1.3.toFixed(2)
          return padNum(result)
        }
        //需要截取的长度小于当前长度，需要判断最后一位数字
        result = intNum + '.' + deciNum.substr(0, len);
        if (parseInt(lastNum, 10) >= 5) {
          //最后一位数字大于5，要进位
          var times = Math.pow(10, len); //需要放大的倍数
          var changedInt = Number(result.replace('.', ''));//截取后转为整数
          changedInt++;//整数进位
          changedInt /= times;//整数转为小数，注：有可能还是整数
          result = padNum(changedInt + '');
        }
        return result;
        //对数字末尾加0
        function padNum(num) {
          var dotPos = num.indexOf('.');
          if (dotPos === -1) {
            //整数的情况
            num += '.';
            for (var i = 0; i < len; i++) {
              num += '0';
            }
            return num;
          } else {
            //小数的情况
            var need = len - (num.length - dotPos - 1);
            for (var j = 0; j < need; j++) {
              num += '0';
            }
            return num;
          }
        }
      }
    },


    //点击页面其他地方清除选择
    docClick(e) {
      // const cName = ['edit-pricr-container', 'contextmenu', 'confirmContract', 'bulk-fill-price-container']
      // if (e.path && !(e.path && e.path.some(s => s.className && cName.some(s1 => s.className.includes(s1))))) {
      //   this.closeMenu()
      //   this.clearAllActive()
      //   this.selectedList = []
      // }
      this.closeMenu()
      this.clearAllActive()
      this.selectedList = []
    },
  },
  mounted() {
    this.init()
  },

  destroyed() {
    window.removeEventListener('keydown', this.keydown, false);
    window.removeEventListener('keyup', this.keyup, false);
    // window.removeEventListener('click', this.docClick, false);
  }
};
</script>


<style lang="scss" scoped>
.statementDeciaredTableInfo {
  position: relative;
  max-width: 1910px;
  margin: auto;
  padding-bottom: 30px;
  &.tdBgColorWhite {
    table {
      tr {
        td {
          background: #fff;
        }
      }
    }
  }
  .table-pagination {
    border-bottom: 1px solid #eee;
    width: 1190px;
    margin: 20px auto;
    padding-bottom: 25px;
  }
  .table-container {
    margin: 10px auto 0;
    overflow: auto;
    min-width: 1190px;
    &::-webkit-scrollbar {
      height: 6px;
    }
    &::-webkit-scrollbar-thumb {
      border-radius: 0px;
      background: #bbb;
    }
    &::-webkit-scrollbar-button {
      width: 0;
    }
    .table-center {
      width: 1903px;
    }
    h2 {
      height: 54px;
      background: #f5f5f5;
      color: #444;
      font-size: 18px;
      text-align: center;
      font-weight: bold;
      line-height: 54px;
      margin: 0;
      border: 1px solid #ddd;
    }
    .tableDataListTbody {
      tr {
        transition: all 0.3s linear;
        &:hover td {
          background: #f1f6fa;
        }
      }
    }
    .thead-flag {
      tr {
        th {
          height: 0;
          line-height: 0;
          overflow: hidden;
          padding: 0;
          margin: 0;
          vertical-align: top;
          border: 0;
        }
      }
    }
    tr {
      td {
        transition: all 0.3s linear;
        vertical-align: middle;
        & > div {
          margin: 0 8px;
          word-break: break-all;
        }
      }
      // 输入框
      .edit-pricr-container {
        &.selectActive {
          & > div {
            transition: all 0.3s linear;
            border: 1px solid #c99f4f;
            // height: calc(100% + 1px);
          }
        }
        &.floatingPriceSty {
          & > div {
            background: #fff;
          }
        }
        & > div {
          height: 100%;
          border: 1px solid transparent;
          margin: 0;
          label {
            height: 100%;
            display: flex;
            align-items: center;
            position: relative;
          }
          /deep/ input {
            // padding: 0 4px;
            // height: 30px;
            // line-height: 30px;
            border: 0 !important;
            height: 100%;
            padding-right: 4px;
          }
          span {
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: flex-end;
            margin: 0 4px;
          }
          .input-center {
            position: relative;
            width: 100%;
            justify-content: flex-end;
            align-items: center;
            display: flex;
            height: 100%;
            span {
            }
            em {
            }
          }
        }
      }

      &.title {
        td {
          height: 54px;
          line-height: 54px;
          font-weight: bold;
          font-size: 14px;
        }
      }
      td,
      th {
        transition: all 0.3s linear;
        color: #444;
        text-align: center;
        height: 30px;
        line-height: 18px;
        background: #f5f5f5;
        border: 1px solid #ddd;
        border-top: 0;
        // 紫色
        &.bg-purple {
          background: #ece9ff;
        }
        // 浅蓝色
        &.bg-blue {
          background: #f0f8ff;
        }
        // 粉色
        &.bg-pink {
          background: #ffe9eb;
        }

        span {
          margin: 0 4px;
        }
      }
    }

    /deep/ input,
    .el-input__inner {
      border: 0;
    }
  }
  .download-container,
  .upload-container {
    width: 1190px;
    margin: auto;
    .title {
      border-left: 4px solid #444;
      font-size: 14px;
      color: #444;
      padding-left: 4px;
      height: 14px;
      line-height: 14px;
      display: inline-block;
    }
    .fileList {
      border: 1px solid #dddddd;
      padding: 14px 10px;
      margin-top: 10px;
      overflow: hidden;
      p {
        margin-top: 10px;
        &:first-child {
          margin-top: 0;
        }
      }
    }
  }
  .download-container {
    border-bottom: 1px solid #eee;
    padding-bottom: 30px;
    margin: 24px auto;
  }
  .upload-container {
    margin-bottom: 60px;
    .other-title {
      margin-top: 10px;
    }
  }

  // 右键
  .contextmenu {
    margin: 0;
    background: #fff;
    z-index: 3000;
    position: fixed;
    list-style-type: none;
    padding: 5px 0;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 400;
    color: #333;
    box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, 0.3);
  }

  .contextmenu li {
    margin: 0;
    padding: 7px 16px;
    white-space: pre;
    cursor: pointer;
  }

  .contextmenu li:hover {
    background-color: rgb(3, 125, 243);
    color: white;
  }

  // 边框线

  .statementDeclaredComfirmContainer {
    font-family: PingFang SC;
    margin-bottom: 80px;
  }
}
.bulk-fill-price-container {
  .container {
    text-align: center;
  }
  .center {
    display: flex;
    width: 560px;
    margin: auto;
    align-items: center;
    margin-bottom: 18px;
    span {
      font-size: 14px;
      color: #888;
    }
    .input-div {
      display: flex;
      position: relative;
      width: calc(100% - 120px);
      em {
        position: absolute;
        right: 6px;
        top: 12px;
        color: #444;
      }
    }
    .btn-center {
      margin-bottom: 1px;
    }
  }
}
.agreement_read {
  width: 1190px;
  height: 30px;
  background: #ffe9eb;
  line-height: 30px;
  position: relative;
  margin: auto;
  label {
    display: flex;
    align-items: center;
    padding-left: 6px;
    /deep/ .el-checkbox__input {
      margin-top: 3px;
    }
    p {
      margin-left: 8px;
    }
  }
}
// 重置 悬浮 表头样式
/deep/ .table-thead-fixed {
  .inner-container {
    width: 1903px;
    td,
    th {
      border: 0 !important;
      background: #000 !important;
      font-size: 12px;
      padding: 0 !important;
      color: #fff !important;
      line-height: 40px !important;
    }
  }
}
.agreement_read_container {
  bottom: 54px !important;
  background: transparent !important;
}
.whitePre {
  white-space: pre;
}
.surchargeDetailListContainer {
  p {
    border-bottom: 1px dashed #ddd;
    line-height: 18px;
    &:last-child {
      border-bottom: 0;
    }
  }
}
.h120 {
  max-height: 120px;
  overflow: hidden;
  .blue {
    max-height: 120px;
    overflow: hidden;
  }
}
.h72 {
  max-height: 72px;
  overflow: hidden;
  .blue {
    max-height: 72px;
    overflow: hidden;
    display: block;
    display: -webkit-box;
    max-width: 400px;
    margin: 0 auto;
    -webkit-line-clamp: 4;
    -webkit-box-orient: vertical;
    text-overflow: ellipsis;
  }
}

.opt-container {
  width: 100%;
  display: flex;
  justify-content: space-between;
  height: 100%;
  & > div {
    background: rgba(255, 255, 255, 0.3);
    position: fixed;
    cursor: pointer;
    width: 50px;
    height: 50px;
    transition: all 0.3s linear;
    top: 50%;
    margin-top: -25px;
    border: 1px solid #ddd;
    border-radius: 50px;
    box-shadow: 0 0 4px rgba(0, 0, 0, 0.3);
    z-index: 1;
    &::before {
      content: "";
      width: 10px;
      height: 10px;
      border: 3px solid;
      border-radius: 2px;
      border-color: #ddd #ddd transparent transparent;
      position: absolute;
      transform: rotate(45deg);
      left: 50%;
      top: 50%;
      margin-left: -10px;
      margin-top: -8px;
      border-radius: 2px;
      transition: all 0.3s linear;
    }
    &:hover {
      background: rgba(255, 255, 255, 1);
      box-shadow: 0 0 4px rgba(0, 0, 8px, 0.7);
      &::before {
        border-color: #e1c079 #e1c079 transparent transparent;
      }
    }
    &.left {
      left: 10px;
      &::before {
        border-color: transparent transparent #ddd #ddd;
        margin-left: -5px;
      }
      &:hover {
        background: rgba(255, 255, 255, 1);
        &::before {
          border-color: transparent transparent #e1c079 #e1c079;
        }
      }
    }
    &.right {
      right: 10px;
    }
  }
}
</style>
