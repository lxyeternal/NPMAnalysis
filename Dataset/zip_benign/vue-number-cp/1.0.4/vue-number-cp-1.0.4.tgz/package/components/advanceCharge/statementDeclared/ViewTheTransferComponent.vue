<template>
  <div class="viewTheTransferComponent">
    <div class="opinions-content" v-if="computedList.length">
      <div class="top">
        <div class="fl f14 bold">流转意见</div>
        <div class="fr blue hand f12" @click="foldFlag = !foldFlag">
          {{foldFlag ? '展开':'收起'}}
          <i v-if="foldFlag" class="el-icon-caret-bottom"></i>
          <i v-else class="el-icon-caret-top"></i>
        </div>
        <div style="clear: both;"></div>
      </div>
      <div class="middle-cont">
        <div class="middle" v-for="(item, idx) in computedList.filter((f, fIdx)=>  foldFlag ? fIdx == 0 : true)" :key="idx">
          <el-row>
            <el-col :span="4">
              <p>姓名</p>
              <span>{{item.name}}</span>
            </el-col>
            <el-col :span="4">
              <p> 审核失败 </p>
              <span>{{item.time}}</span>
            </el-col>
            <el-col :span="16">
              <p>退回原因：</p>
              <span v-html="item.comment && item.comment.replace(/\n/g, '<br/>')"></span>
            </el-col>
          </el-row>
        </div>
      </div>
      <div class="bottom">
        <span class="blue hand f12" @click="foldFlag = !foldFlag">
          {{foldFlag ? '展开':'收起'}}
          <i v-if="foldFlag" class="el-icon-caret-bottom"></i>
          <i v-else class="el-icon-caret-top"></i>
        </span>
      </div>
    </div>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import FixBottom from "@/components/base/FixBottom";

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    FixBottom,
  },
  props: {
    computedList: {
      type: Array,
      default() {
        return []
      }
    },
  },
  data() {
    return {
      foldFlag: false
    };
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      // this.computedList = [
      //   {
      //     corpName: null,
      //     operAcctId: "ACCT2020102100000000000000030016",
      //     operAcctName: "李兰111",
      //     operMsg: "一般接口测试的用例分为以下几种：↵　　1、通过性验证，说白了就是传递正确的参数，是否返回正常的结果↵　　2、参数组合，因为参数有必传和非必传，参数的类型和长度，以及传递时可能业务上的一些限制，所以在设计用例时，就要排列组合这些情况，保证所有情况都能覆盖到↵　　3、接口的安全性，这个又分为几种情况：↵　　1)绕过验证，比如提交订单时，在传递商品价格参数时，修改商品价格，就要看后端有没有验证了。或者我",
      //     time: "2020-12-10 11:35:17",
      //     operType: "23",
      //     operTypeDisp: null,
      //   },
      //   {
      //     corpName: null,
      //     operAcctId: "ACCT2020102100000000000000030016",
      //     operAcctName: "李兰222",
      //     operMsg: "一般接口测试的用例分为以下几种：↵　　1、通过性验证，说白了就是传递正确的参数，是否返回正常的结果↵　　2、参数组合，因为参数有必传和非必传，参数的类型和长度，以及传递时可能业务上的一些限制，所以在设计用例时，就要排列组合这些情况，保证所有情况都能覆盖到↵　　3、接口的安全性，这个又分为几种情况：↵　　1)绕过验证，比如提交订单时，在传递商品价格参数时，修改商品价格，就要看后端有没有验证了。或者我",
      //     time: "2020-12-10 11:35:17",
      //     operType: "23",
      //     operTypeDisp: null,
      //   }
      // ]
    }
  }
};
</script>

<style lang="scss" scoped>
.viewTheTransferComponent {
  .opinions-content {
    padding: 10px;
    width: 1190px;

    background: #fffcf0;
    border: 1px solid #fae2a5;
    margin-bottom: 20px;
    .middle-cont {
      min-height: 78px;
      max-height: 400px;
      overflow-y: auto;
    }
    .top {
      height: 30px;
      border-bottom: 1px solid #eee;
    }
    .middle {
      font-size: 12px;
      padding: 10px 0;
      min-height: 71px;
      border-bottom: 1px solid #eee;
      div {
        p {
          margin-bottom: 10px;
          font-size: 14px;
        }
        span {
          color: #888;
          line-height: 17px;
          float: left;
          word-break: break-all;
          &:first-child {
            width: 17%;
          }
          &:last-of-type {
            width: 83%;
          }
        }
      }
    }
    .bottom {
      padding-top: 10px;
      height: 27px;
      text-align: center;
    }
  }
}
</style>
