<template>
  <div class="statementDeciaredTableInfo" :class="{tdBgColorWhite: tdBgColor == 'white'}">
    <!-- 温馨提示 -->
    <div class="table-container" ref="tableContainer">
      <div class="table-center">
        <h2>预付款申请单</h2>
        <TableThead :TopDistance="TopDistance" :offsetLeft="this.tableOffsetLeft">
          <tr slot="tr">
            <td width="40">序号</td>
            <td width=" 78">材料大类</td>
            <td width="78">材料类别</td>
            <td width="78">产品名称</td>
            <td width="137">商品名称</td>
            <td width="130">附加项说明</td>
            <td width="120">物料描述</td>
            <td width="70">品牌</td>
            <td width="117">型号</td>
            <td width="175">规格</td>
            <td width="70">单位</td>
            <td width="118">使用标段或部位</td>
            <td width="107">数量</td>
            <td width="79">
              <div class="lh21">
                <p>要求</p>
                <p>到货日期</p>
              </div>
            </td>
            <td width="110">采购单价(含税)(元)</td>
            <td width="110">采购金额(含税)(元)</td>
            <td width="114">本次预付比例</td>
            <td width="110">
              <div class="lh21">
                <p>本次预付金额</p>
                <p>(含税)(元)</p>
              </div>
            </td>
            <td width="80">
              <div class="lh21">
                <p>累计预付比例</p>
                <p>(含本次)</p>
              </div>
            </td>
          </tr>
        </TableThead>
        <div class="opt-container" v-if="showAboutOpt">
          <div class="left" title="点击向左滚动" v-if="showAboutLeft" @click="handleClickScroll(1)"></div>
          <div class="right" title="点击向右滚动" v-if="showAboutRight" @click="handleClickScroll(2)"></div>
        </div>
        <table>
          <thead class="thead-flag">
            <tr>
              <!-- th[width=120]{$}*18 -->
              <th width="42">序号</th>
              <th width="80">材料大类</th>
              <th width="80">材料类别</th>
              <th width="80">产品名称</th>
              <th width="140">商品名称</th>
              <th width="134">附加项说明</th>
              <th width="120">物料描述</th>
              <th width="70">品牌</th>
              <th width="120">型号</th>
              <th width="180">规格</th>
              <th width="70">单位</th>
              <th width="110">使用标段或部位</th>
              <th width="110">数量</th>
              <th width="80">实际收货日期</th>
              <th width="110">收货编号</th>
              <th width="110">要料单位</th>
              <th width="114">采购单价(含税)</th>
              <th width="110">采购金额(含税)</th>
              <th width="80">累计预付比例</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td colspan="2" class="bg-purple">预付款单编号</td>
              <td colspan="2">
                <div class="tl">{{tabIndex == 1 ? statementDetailInfo.supplierStatementNo : statementDetailInfo.statementNo || ''}}</div>
              </td>
              <td class="bg-purple">制单日期</td>
              <td>
                <div class="tl whitePre">{{statementDetailInfo.createStatementDate || ''}}</div>
              </td>
              <td colspan="1" class="bg-purple">要货单</td>
              <td colspan="3">
                <el-select v-if="!isReview" v-model="contractValue" @change="handleChangeContract" placeholder="请选择要货单" style="width:100%;">
                  <!-- item.contractName -->
                  <el-option v-for="(item, idx) in contractList" :key="idx" :label="formatContractName(item)" :value="item.requireNo">
                  </el-option>
                </el-select>
                <div class="tl" v-else>{{requisitionNameCp}}</div>
              </td>
              <td colspan="2" class="bg-purple">要货单编号</td>
              <td colspan="2">
                <div class="tl blue hand" @click="jumpRequireOrderDetail">{{contractValue}}</div>
              </td>
              <td class="bg-purple">OA编号</td>
              <td colspan="2">{{externalSysList.find(f=>f.externalCode) && externalSysList.find(f=>f.externalCode).externalCode || ''}}</td>
              <td colspan="2"><span class="hand blue" @click="beenReconciled">开票信息</span></td>
            </tr>
            <tr class="title">
              <td class="bg-blue" colspan="9">项目公司项目信息</td>
              <td class="bg-pink" colspan="5">合同及对账信息</td>
              <td class="bg-blue" colspan="5">供应方信息</td>
            </tr>
            <tr>
              <td class="bg-blue" colspan="2">所属事业部</td>
              <td class="bg-blue">所属城市</td>
              <td class="bg-blue" colspan="5">项目公司名称</td>
              <td class="bg-blue">项目经理/电话</td>

              <td class="bg-pink" colspan="2">合同编号/合同名称</td>
              <td class="bg-pink">本次要货预付比例</td>
              <td class="bg-pink" colspan="2">
                累计预付金额(含税)(不含本次)
                <el-tooltip effect="dark" placement="top-start">
                  <div slot="content" style="width: 200px">该要货单累计的预付金额（含税）（不含本次）且审核通过的金额 </div>
                  <i class="el-icon-question tooltip-name"></i>
                </el-tooltip>
              </td>

              <td class="bg-blue" colspan="2">供应方名称</td>
              <td class="bg-blue">被授权人姓名/电话</td>
              <td class="bg-blue" colspan="2">被授权人电子邮箱</td>
              <!--   <td class="bg-blue">票种</td>
              <td class="bg-blue" colspan="2">纳税人识别号</td> -->
            </tr>
            <tr>
              <td colspan="2">
                <div class="tl">{{orderDetailInfo.groupCompanyName || ''}}</div>
              </td>
              <td>
                <!-- 所属城市 -->
                <div class="tl">
                  {{orderDetailInfo.projectCityName || ''}}
                </div>
              </td>
              <td colspan="5">
                <div class="tl">
                  <p>
                    {{orderDetailInfo.purchaserName || ''}}
                  </p>
                </div>
              </td>
              <td>
                <div class="tl">
                  <p>
                    {{managerObject && managerObject.length> 0 ? managerObject[0].acctName : ''}}
                  </p>

                  <p>
                    {{managerObject && managerObject.length> 0 ? managerObject[0].mobile : ''}}
                  </p>
                </div>
              </td>

              <td colspan="2">
                <div class="lh22">
                  <p> {{tabIndex == 1 ? orderDetailInfo.clOrderNo : orderDetailInfo.sybOrderNo || ''}}</p>
                  <p class="blue hand" v-if="orderDetailInfo.contractName" @click="handleClickJumpOrderDetai">《{{orderDetailInfo.contractName}}》</p>
                </div>
              </td>
              <td class="h64">
                <label class="input-center-label">
                  <div class="input-center" :class="{tr: isReview}">
                    <!-- '^100$|^\\d{0,2}(\\.\\d{0,2})?$|^\\s*$' -->
                    <input v-if="!isReview" :class="{tl: inputTxt=='tl' || !proportion, tr: inputTxt=='tr' && proportion}" type="text" @input="handleInputProportion" v-model="proportion" @focus="inputTxt = 'tl'" @blur="inputTxt = 'tr'" v-input-custom-reg="{reg:'^100$|^\\d{0,2}$'}" :placeholder="proportionPlc">
                    <span v-else>{{proportion}}</span>
                    <em>%</em>
                    <p v-if="showProportionNotice" class="red notice">请填写合同约定可申请比例</p>
                  </div>
                </label>
              </td>
              <!-- 累计预付金额 -->
              <td colspan="2" class="tr">
                <span>{{statementAmtWithTaxTotalCp | formatMoney}}元</span>
              </td>

              <td colspan="2" rowspan="3">
                <div class="tl">{{orderDetailInfo.supplierName || ''}}</div>
              </td>
              <td rowspan="3">
                <div class="tl">
                  {{ currentObject && currentObject.length > 0 ? currentObject[0].acctName : ''}}
                  <p>
                    {{ currentObject && currentObject.length > 0 ? currentObject[0].mobile : ''}}
                  </p>
                </div>
              </td>
              <td colspan="2" rowspan="3">
                <div class="tl">{{ currentObject && currentObject.length > 0 ? currentObject[0].email : ''}} </div>
              </td>
            </tr>

            <tr>
              <td class="bg-blue" colspan="2">项目标段</td>
              <td class="bg-blue">项目分期</td>
              <td class="bg-blue" colspan="5">项目名称</td>
              <td class="bg-blue">项目经理电子邮箱</td>

              <td class="bg-pink" colspan="2">合同金额(含税)</td>
              <td class="bg-pink lh20">本次预付金额<br>(含税)</td>
              <!-- BUG #11534  -->
              <td class="bg-pink" colspan="2">累计预付金额(含税)(含本次)
                <el-tooltip effect="dark" placement="top-start">
                  <div slot="content" style="width: 200px">累计预付金额(含税)(不含本次)且审核通过的金额+本次预付金额(含税)</div>
                  <i class="el-icon-question tooltip-name"></i>
                </el-tooltip>
              </td>
            </tr>
            <tr>
              <td colspan="2">
                <div class="tl"> {{orderDetailInfo.building || ''}} </div>
              </td>
              <td>
                <div class="tl">{{orderDetailInfo.projectTermName || ''}}</div>
              </td>
              <td colspan="5">
                <div class="tl"> {{orderDetailInfo.projectName || ''}} </div>
              </td>
              <td>
                <div class="tl">{{managerObject && managerObject.length> 0 ? managerObject[0].email : ''}} </div>
              </td>

              <td colspan="2">
                <div v-if="!(orderDetailInfo.replenishContractInfo && orderDetailInfo.replenishContractInfo.relContractList && orderDetailInfo.replenishContractInfo.relContractList.length)" class="tr">{{tabIndex == 1 ? orderDetailInfo.outContractFeeWithTax : orderDetailInfo.inContractFeeWithTax || '' | formatMoney}}元</div>
                <div class="tr" style="margin: 10px 8px 4px" v-else>
                  <p>{{tabIndex == 1 ? orderDetailInfo.allOutContractFeeWithTax : orderDetailInfo.allInContractFeeWithTax || '' | formatMoney}}元</p>
                  <p class="tr grey">(主合同金额：{{tabIndex == 1 ? orderDetailInfo.outContractFeeWithTax : orderDetailInfo.inContractFeeWithTax || '' | formatMoney}}元)</p>
                  <p class="tr grey">(补充合同金额：{{tabIndex == 1 ? orderDetailInfo.replenishOutContractFeeWithTax : orderDetailInfo.replenishInContractFeeWithTax || '' | formatMoney}}元)</p>
                </div>
              </td>
              <td>
                <div class="tr red" v-if="statementDetailInfo.enterFrom == '2'">{{statementDetailInfo.thisStatementAmtWithTax | formatMoney}}元</div>
                <div class="tr red" v-else>{{prepaidAmountComputed | formatMoney}}元</div>
              </td>
              <td colspan="2">
                <div class="tr">
                  <template v-if="statementDetailInfo.enterFrom == '2'">
                    {{statementDetailInfo.thisStatementAmtWithTax | formatMoney}}元
                  </template>
                  <template v-else>
                    {{numberUtilCp.numAdd(+prepaidAmountComputed, +statementAmtWithTaxTotalCp) | formatMoney}}元
                  </template>
                </div>
              </td>
            </tr>
            <tr>

              <td class="bg-purple">序号</td>
              <td class="bg-purple">材料大类</td>
              <td class="bg-purple">材料类别</td>
              <td class="bg-purple">产品名称</td>
              <td class="bg-purple">商品名称</td>
              <td class="bg-purple">附加项说明</td>
              <td class="bg-purple">物料描述</td>
              <td class="bg-purple">品牌</td>
              <td class="bg-purple">型号</td>
              <td class="bg-purple">规格</td>
              <td class="bg-purple">单位</td>
              <td class="bg-purple">使用标段或部位</td>
              <td class="bg-purple">数量</td>
              <td class="bg-purple">
                <div class="lh21">
                  <p>要求</p>
                  <p>到货日期</p>
                </div>
              </td>
              <td class="bg-purple">采购单价(含税)(元)</td>
              <td class="bg-purple">采购金额(含税)(元)</td>
              <td class="bg-purple">本次预付比例</td>
              <td class="bg-purple">
                <div class="lh21">
                  <p>本次预付金额</p>
                  <p>(含税)(元)</p>
                </div>
              <td class="bg-purple">
                <div class="lh21">
                  <p>累计预付比例</p>
                  <p>(含本次)</p>
                </div>
              </td>

            </tr>
          </tbody>
          <tbody class="tableDataListTbody">
            <tr v-for="(item, idx) in tableDataList" :key="idx">
              <td>
                <div class="tl">{{item.index}}</div>
              </td>
              <td>
                <div class="tl">{{item.datum || ''}}</div>
              </td>
              <td>
                <div class="tl">{{item.datumType || ''}}</div>
              </td>
              <td>
                <div class="tl">{{item.productName || ''}}</div>
              </td>
              <td>
                <div class="tl">{{item.skuName || '' }}</div>
              </td>
              <td>
                <div class="tl surchargeDetailListContainer h72">
                  <el-tooltip v-if="item.surchargeDetailList && item.surchargeDetailList.length" class="item" effect="dark" placement="top-start">
                    <div slot="content">
                      <p v-for="(sItem, sIdx) in  item.surchargeDetailList" :key="sIdx">
                        附加项{{sIdx + 1}}：{{sItem.surchangeName}}&nbsp;&nbsp;X{{sItem.surchangeUnitCnt}}{{sItem.surchangeUnit}} &nbsp;&nbsp;<span style="color: #c99f4f;">
                          ￥{{tabIndex == 1 ? sItem.outSurchangeUnitPrice : sItem.inSurchangeUnitPrice | formatMoney}}</span>
                      </p>
                    </div>
                    <div class="blue">
                      <p v-for="(sItem, sIdx) in  item.surchargeDetailList" :key="sIdx">
                        附加项{{sIdx + 1}}：{{sItem.surchangeName}}&nbsp;&nbsp;X{{sItem.surchangeUnitCnt}}{{sItem.surchangeUnit}} &nbsp;&nbsp;<span style="color: #c99f4f;">
                          ￥{{tabIndex == 1 ? sItem.outSurchangeUnitPrice : sItem.inSurchangeUnitPrice | formatMoney}}</span>
                      </p>
                    </div>
                  </el-tooltip>
                </div>
              </td>
              <td>
                <div class="tl h72">
                  <el-tooltip class="item" v-if="item.itemDescription" effect="dark" :content="item.itemDescription" placement="top-start">
                    <div class="blue"> {{item.itemDescription || ''}}</div>
                  </el-tooltip>
                </div>
              </td>
              <td>
                <div class="tl"> {{item. brandNameCn || ''}} </div>
              </td>
              <td>
                <div class="tl">{{item.model || ''}}</div>
              </td>
              <td>
                <div class="tl h72">
                  <el-tooltip class="item" v-if="item.attrInfo" effect="dark" :content="item.attrInfo" placement="top-start">
                    <div class="blue"> {{item.attrInfo || ''}}</div>
                  </el-tooltip>
                </div>
              </td>
              <td>
                <div class="tl">{{item.goodsUnit || ''}}</div>
              </td>
              <td>
                <div class="tl">{{item.location || ''}}</div>
              </td>
              <td>
                <div class="tr">{{item.requireCount || ''}}</div>
              </td>
              <td>
                <div class="tl whitePre">{{item.requireTimeTo || ''}}</div>
              </td>
              <td>
                <!-- <div class="tr">{{purchaseUnitPriceCp(item) | formatMoney}}</div> -->
                <div class="tr">{{tabIndex == 1 ? item.unitPriceWithTax : item.inUnitPriceWithTax || '' | formatMoney}}</div>
              </td>
              <td>
                <div class="tr">{{purchaseUnitPriceCp(item) | formatMoney}}</div>
              </td>
              <td>
                <div class="tr" v-if="proportion">{{proportion}}% </div>
              </td>
              <td>
                <div class="tr">{{thePrepaidAmountComputed(item) | formatMoney}}</div>
                <!-- <div class="tr">{{tabIndex == 1 ? item.statementAmtWithTax : item.inStatementAmtWithTax || '' | formatMoney}}</div> -->
              </td>
              <td>
                <div class="tr" v-if="item.prepaymentRatioTotal">{{item.prepaymentRatioTotal}}%</div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
    <div class="table-pagination" v-if="tableDataList && tableDataList.length">
      <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="form.pageTotal" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
      </el-pagination>
    </div>

    <div class="upload-container">
      <ul>
        <li class="title">附件</li>
      </ul>
      <div class="other-title">
        <span>其他附件</span>
        <DownloadAndUpload appName="TRD" v-if="!isReview" :fileList="otherList" :hasDownloadFlg="false" fromId="authorizationFile" uploadType="13" @outputValue="handleUpFileResult"></DownloadAndUpload>
        <span class="f12 hand blue" v-else-if="otherList && otherList.length" @click="packageDownload">下载</span>
      </div>
      <div class="fileList">
        <div v-if="otherList && otherList.length == 0" class="nodata">无</div>
        <p v-for="(item, index) in otherList" :key="index">
          {{item.attachName}}
          <DownloadAndView downloadName="下载" viewName="预览" :hideRotate="true" :attachUrl="item.viewUrl || item.attachUrl" :attachName="item.attachName"></DownloadAndView>
          &nbsp;&nbsp;
          <span v-if="!isReview && !examine" class="hand blue" @click="delOther(index)">删除</span>
        </p>
      </div>
    </div>

    <BaseFloatBottomComponent ref="baseFloatBottomRef"></BaseFloatBottomComponent>

    <el-dialog class="dialog bulk-fill-price-container" :title="'批量设置采购单价(含税)'" :append-to-body="true" :lock-scroll="true" :visible.sync="bulkFillPriceDialog" width="850px" center :close-on-click-modal="false">
      <div class="container">
        <div class="center">
          <i class="red">*</i>
          <span>采购单价(含税)：</span>
          <div class="input-div">
            <input type="text" placeholder="请输入单价">
            <em>元</em>
          </div>
        </div>
        <div class="btn-center">
          <el-button size="small" type="primary" style="width: 120px">确认</el-button>
          <el-button size="small" style="width: 120px">取消</el-button>
        </div>
      </div>
    </el-dialog>

    <FixBottom v-if="!isReview" class="agreement_read_container">
      <div class="agreement_read" v-if="!isReview">
        <label>
          <el-checkbox v-model="readStatusChecked"></el-checkbox>
          <p>我承诺已仔细阅读本对账相关信息、账户信息及对账单物料明细，确认其内容没有疑议。</p>
        </label>
      </div>
    </FixBottom>
    <FixBottom v-if="!isReview">
      <div class="tc">
        <el-button type="primary" style="width: 120px;" :disabled="submitDisabledComputed || showProportionNotice" @click="handleClickBottom(1)">提交申请</el-button>
        <el-button @click="handleClickBottom(2, true)">保存</el-button>
      </div>
    </FixBottom>
    <InvoicBaseInfoBottomComponent :tabIndex="tabIndex" ref="invoicBaseInfoBottomComponentRef" :orderDetailInfo="orderDetailInfo" @close="handleCloseFloatBottom"></InvoicBaseInfoBottomComponent>
    <Loading :isLoading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import FixBottom from "@/components/base/FixBottom";
import { InterfaceService } from "@/services/api";
import DownloadAndView from '@/components/order/DownloadAndView'
import TableThead from "@/components/base/TableThead";
import { NumberUtil } from '@/utils/numberUtil'
import DownloadAndUpload from "@/components/base/DownloadAndUpload";

import BaseFloatBottomComponent from "@/components/advanceCharge/statementDeclared/BaseFloatBottomComponent";
import InvoicBaseInfoBottomComponent from "@/components/advanceCharge/advancePaymentRequest/InvoicBaseInfoBottomComponent";

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    FixBottom,
    DownloadAndView,
    BaseFloatBottomComponent,
    TableThead,
    InvoicBaseInfoBottomComponent,
    DownloadAndUpload,
  },
  props: {
    // td 背景色
    tdBgColor: {
      type: String,
      default: ''
    },
    // table 表头偏移量
    TopDistance: {
      type: Number,
      default: 604
    },
    // 是否查看模式
    isReview: {
      type: Boolean,
      default: false
    },
    // 是否分页保存
    pageSave: {
      type: Boolean,
      default: false
    },
    // 区分 0:材料合同对账单 , 1:事业部合同对账单
    tabIndex: {
      type: Number,
      default: 0
    },
    // 外部传入数据, 如果没有传 则自己发送请求
    dataList: {
      type: Array,
      default() {
        return []
      }
    },
  },
  watch: {
    tabIndex() {
      // 防止 初始化 和 watch 一起调用, 出现调用两次同接口请款,  单brokerRole (材料公司) 角色登录时 不会触发 tabIndex变化, 所以 不需要检测是否第一次加载
      if (!this.isInitWatch || this.brokerRole) {
        this.form.pageIndex = 1
        this.getDetail()
      }
      this.isInitWatch = false
    },
  },
  data() {
    return {
      // 用于判断 初始化时 是否 调用 详情接口, init 已经调用过一次
      isInitWatch: true,
      inputTxt: 'tl',
      isLoading: false,
      proportion: '',
      proportionPlc: '请输入比例',
      form: {
        pageSize: 10,
        pageIndex: 1,
        pageTotal: 1
      },
      tableDataList: [],
      isEditPrice: false,
      bulkFillPriceDialog: false,

      // 上传下载
      deliveryAttachList: [],
      otherList: [],

      contractList: [],
      contractValue: '',
      orderDetailInfo: {},
      currentObject: [],
      managerObject: [],
      projectObject: [],
      orderNo: '',
      readStatusChecked: false,
      tableOffsetLeft: 0,
      statementNo: '',
      statementDetailInfo: {},
      billFfLadingInfo: {},
      newToOrder: false, // 如果点击选择要货单后 分页就查询 新的要货单数据
      inputTimer: null,
      totalStatementAmtWithTax: '', // 本次预付金额
      inTotalStatementAmtWithTax: '',



      purchaserStatementNo: '',
      supplierStatementNo: '',

      prepaymentRatioTotal: 0,
      showProportionNotice: false,
      examine: false,

      showAboutOpt: false,
      showAboutLeft: true,
      showAboutRight: true,
    }
  },

  computed: {
    externalSysList() {
      return this.statementDetailInfo && this.statementDetailInfo.externalSysList || []
    },
    // 列表 - 采购借(含税)(元)
    purchaseUnitPriceCp() {
      return item => {
        // return (this.tabIndex == 1 ? NumberUtil.numAdd(+item.price, +item.taxAmt) : NumberUtil.numAdd(+item.inPrice, +item.inTaxAmt)) || 0
        return (this.tabIndex == 1 ? Number(item.totalAmtWithTax) : Number(item.inTotalAmtWithTax)) || 0
      }
    },

    // 累计预付金额(含税)(不含本次) - 要货单
    statementAmtWithTaxTotalCp() {
      const statementDetailInfo = this.statementDetailInfo || {}
      return (this.tabIndex == 1 ? statementDetailInfo.statementAmtWithTaxTotal : statementDetailInfo.inStatementAmtWithTaxTotal) || 0
    },
    // 要货单名称取值
    requisitionNameCp() {
      return this.formatContractName(this.contractList.find(f => f.requireNo == this.contractValue))
    },
    formatContractName() {
      return item => {
        let resultName = ''
        item = item || {}
        item.eventList && item.eventList.some(s => {
          if (s => s.eventType == 1 && s.eventStatus == 2) {
            const st = s.documentName || ''
            resultName = st.slice(0, st.lastIndexOf('.')) || ''
            return true
          }
        })

        return resultName
      }
    },

    // 0:材料合同对账单 , 1:事业部合同对账单
    thePrepaidAmountComputed() {
      return item => {
        // 采购金额 * 本次预付比例
        let result = NumberUtil.accMul(this.purchaseUnitPriceCp(item), +NumberUtil.divide(Number(this.proportion), 100).toFixed(2)) || 0
        // result * 数量
        // result = NumberUtil.accMul(+item.requireCount, result) || 0

        return result.toFixed(2)

      }
    },
    // 附加项金额取值
    comupSurchangeUnitPrice() {
      return function (price, num) {
        return Number(NumberUtil.accMul(price, +num))
      }
    },
    // 本次预付金额 (含税)
    prepaidAmountComputed() {
      // let total = 0
      // this.tableDataList.forEach(f => {
      //   total = NumberUtil.numAdd(total, this.thePrepaidAmountComputed(f))
      // })
      // return this.tabIndex == 1 ? this.totalStatementAmtWithTax : this.inTotalStatementAmtWithTax
      return this.totalStatementAmtWithTax
    },
    numberUtilCp() {
      return NumberUtil
    },
    submitDisabledComputed() {
      return !this.contractValue || !this.proportion || !this.readStatusChecked
    },
    contractFirstItem() {
      return this.contractList && this.contractList[0] || {}
    },
    isMultipleData() {
      const filterList = this.tableDataList && this.tableDataList.filter(f => f.selectActive) || []
      return filterList.length > 1
    },
    findContractItemByRequireNo() {
      return this.contractList.find(f => f.requireNo == this.contractValue) || {}
    },
    prepaymentRatioTotalCp() {
      return NumberUtil.numAdd(this.prepaymentRatioTotal, Number(this.proportion)) || 0
    },
  },
  methods: {
    async  init() {
      // this.tabIndex = this.role == 'S' ? 1 : this.tabIndex
      console.log(this.tabIndex, '---');
      this.toFixedRest()

      this.examine = this.$route.query.state == 'examine' || false
      this.orderNo = this.$route.query.orderNo || ''
      this.statementNo = this.$route.query.statementNo || ''
      this.purchaserStatementNo = this.$route.query.purchaserStatementNo || ''
      this.supplierStatementNo = this.$route.query.supplierStatementNo || ''


      this.getRequireOrderList()
      await this.orderDetails()
      this.statementNo && this.getDetail()
      this.$refs.tableContainer && this.setBrowser()
    },
    setBrowser() {
      // div 滚动条 拖动 触发
      document.querySelector(".table-container") && (document.querySelector(".table-container").onscroll = (e) => {
        this.tableOffsetLeft = e.target && e.target.scrollLeft || 0
        this.setAboutShowHide()
      })
      // 初始化 是否显示 左右按钮
      this.showAboutOpt = this.$refs.tableContainer && this.$refs.tableContainer.offsetWidth < 1900
      this.setAboutShowHide()
      window.onresize = () => {
        this.showAboutOpt = this.$refs.tableContainer && this.$refs.tableContainer.offsetWidth < 1900
        this.setAboutShowHide()
      }
    },

    // 左右按钮显示条件判断
    setAboutShowHide() {
      this.showAboutLeft = this.showAboutOpt && this.$refs.tableContainer.scrollLeft > 10
      this.showAboutRight = this.$refs.tableContainer && (this.$refs.tableContainer.clientWidth + this.$refs.tableContainer.scrollLeft < 1900)
    },

    // 横向滚动
    handleClickScroll(state) {
      const oldScrollLeft = this.$refs.tableContainer.scrollLeft
      switch (state) {
        case 1:
          // 左
          this.$refs.tableContainer.scrollLeft = oldScrollLeft - 100
          break;

        case 2:
          // 右
          this.$refs.tableContainer.scrollLeft = oldScrollLeft + 100
          break;

        default:
          break;
      }
    },
    judgePrepaymentRatioTota() {
      this.showProportionNotice = false
      if (this.prepaymentRatioTotalCp > 100) {
        this.showProportionNotice = true
      }
    },
    handleInputProportion() {
      clearTimeout(this.inputTimer)
      this.inputTimer = null
      this.judgePrepaymentRatioTota()
      if (this.showProportionNotice || !this.contractValue) {
        return
      }
      this.inputTimer = setTimeout(() => {
        this.newToOrder = true
        this.orderForm()
      }, 1000);
    },
    debounce(func, wait = 1000) {
      let timeout;
      return function (event) {
        clearTimeout(timeout)
        timeout = setTimeout(() => {
          func.call(this, event)
        }, wait)
      }
    },
    // 防抖

    jumpRequireOrderDetail() {
      window.open(this.$router.resolve({
        path: '/requireOrderDetail',
        query: {
          requireNo: this.contractValue
        }
      }).href, '_blank')
    },

    handleClickJumpOrderDetai() {
      window.open(this.$router.resolve({
        path: '/orderDetail',
        query: {
          orderNo: this.orderDetailInfo && this.orderDetailInfo.orderNo
        }
      }).href, '_blank')
    },
    /**
     * 修复 toFixed 精度问题
     */
    toFixedRest() {
      // toFixed兼容方法
      Number.prototype.toFixed = function (len) {
        if (len > 20 || len < 0) {
          throw new RangeError('toFixed() digits argument must be between 0 and 20');
        }
        // .123转为0.123
        var number = Number(this);
        if (isNaN(number) || number >= Math.pow(10, 21)) {
          return number.toString();
        }
        if (typeof (len) == 'undefined' || len == 0) {
          return (Math.round(number)).toString();
        }
        var result = number.toString(),
          numberArr = result.split('.');

        if (numberArr.length < 2) {
          //整数的情况
          return padNum(result);
        }
        var intNum = numberArr[0], //整数部分
          deciNum = numberArr[1],//小数部分
          lastNum = deciNum.substr(len, 1);//最后一个数字

        if (deciNum.length == len) {
          //需要截取的长度等于当前长度
          return result;
        }
        if (deciNum.length < len) {
          //需要截取的长度大于当前长度 1.3.toFixed(2)
          return padNum(result)
        }
        //需要截取的长度小于当前长度，需要判断最后一位数字
        result = intNum + '.' + deciNum.substr(0, len);
        if (parseInt(lastNum, 10) >= 5) {
          //最后一位数字大于5，要进位
          var times = Math.pow(10, len); //需要放大的倍数
          var changedInt = Number(result.replace('.', ''));//截取后转为整数
          changedInt++;//整数进位
          changedInt /= times;//整数转为小数，注：有可能还是整数
          result = padNum(changedInt + '');
        }
        return result;
        //对数字末尾加0
        function padNum(num) {
          var dotPos = num.indexOf('.');
          if (dotPos === -1) {
            //整数的情况
            num += '.';
            for (var i = 0; i < len; i++) {
              num += '0';
            }
            return num;
          } else {
            //小数的情况
            var need = len - (num.length - dotPos - 1);
            for (var j = 0; j < need; j++) {
              num += '0';
            }
            return num;
          }
        }
      }
    },

    // 打包下载
    packageDownload() {
      console.log(this.orderDetailInfo.contractName, '--this.orderDetailInfo.contractName');

      const fileInfoBeans = this.otherList.map(m => {
        return {
          archivePath: '其他附件/' + (m.attachName || ''),
          fileUrl: m.attachUrl,
        }
      })
      let params = {
        fileInfoBeans,
        protocol: "https",
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: this.orderDetailInfo && this.orderDetailInfo.contractName + "预付款申请附件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    handleCloseFloatBottom() {

    },
    beenReconciled() {
      const corpId = this.tabIndex == 1 ? this.orderDetailInfo.brokerCorpId : this.orderDetailInfo.purchaserId
      this.$refs["invoicBaseInfoBottomComponentRef"].open(corpId)
    },
    async handleClickBottom(state, showMsg) {
      if (state == 1) {
        this.$confirm("确认提交申请吗？", "操作提示", {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          confirmButtonText: "确认",
          cancelButtonText: '取消',
        }).then(async () => {
          if (await this.generateStatements('save')) {
            this.generateStatements('submit')
          }
        }).catch(() => {
        });

      } else {
        return new Promise(async resolve => {
          const result = await this.generateStatements('save', showMsg)
          // 分页 触发的保存 不要 调此查询接口, 因为分页会自己查
          showMsg && this.getDetail()
          console.log('保存');
          resolve(result)
        })
      }
      if (window.opener) {
        window.opener.location.reload();
      }
    },
    getDetail(isChangePage) {
      const params = {
        // pageFlg: this.role == 'B' ? 0 : 1,
        pageFlg: this.tabIndex,
        statementNo: (this.tabIndex == 1 ? this.supplierStatementNo : this.statementNo) || this.statementNo,
        orderNo: this.orderNo,
        pageIndex: this.form.pageIndex,
      };
      InterfaceService.getStatementDetail(
        params,
        data => {
          let res = data.respData || {}
          if (res.respCode === "0000") {

            // 只改标列表数据
            const item = res.statementDetails && res.statementDetails[0] || {}
            this.tableDataList = item.deliveryDetail || []
            this.form.pageTotal = item.totalCount || 1



            if (isChangePage) {
              // 分页 无法 组装累计预付比例修复
              this.formatTableDataList(data.respData.prepaymentRatioTotal || '0')
              return
            }

            this.statementDetailInfo = res || {}
            // 本次预付金额 (含税)
            // this.totalStatementAmtWithTax = this.statementDetailInfo.thisStatementAmtWithTax || ''
            this.totalStatementAmtWithTax = (this.tabIndex == 1 ? this.statementDetailInfo.totalStatementAmtWithTax : this.statementDetailInfo.inTotalStatementAmtWithTax) || ''

            this.contractValue = res.requireNo || ''
            this.otherList = res.uploadFiles || []
            this.proportion = NumberUtil.accMul(Number(res.prepaymentRatio), 100) || ''
            this.proportion && (this.inputTxt = 'tr')
            // 累计预付比例 - 第一次加载  this.proportion 未初始化值, 所以这里得 设置一次
            this.formatTableDataList(data.respData.prepaymentRatioTotal || '0')
            // 向父级 返回数据
            let flowList = []

            if (res.processNodeList && res.processNodeList.length) {
              res.processNodeList.forEach(item => {
                flowList.push({
                  foot_title: item.flowName,
                  lightShow: item.isCurrentNode,
                  top_info: item.operTime && item.operTime.substring(0, 10) || "",
                  top_end_info: item.operTime && item.operTime.substring(11, item.operTime.length) || "",
                })
              })

            }

            let onOff = false,
              activeNode = 0

            flowList.forEach((item, index) => {
              if (item.lightShow === '1') {
                onOff = true
                // 判断到最后一步 + 1
                activeNode = index;
              }
            });
            if (!onOff) {
              activeNode = 3
            }


            //退回、拒绝流程节点
            let orderOperFlow = [];
            let list = res.statementOperFlowList || [];
            list.forEach(item => {
              if (item.operType == 'purchaserReturn') {
                orderOperFlow.push({
                  name: item.operAcctName,
                  comment: item.operMsg,
                  department: "",
                  time: item.operTime || "",
                })
              }
            })

            this.$emit('refreshData', {
              flowList,
              activeNode,
              orderOperFlow,
              orderDetailInfo: this.orderDetailInfo || {},
              statementDetailInfo: res || {}
            })


          } else {
            this.$message.error(res.respMsg);
          }
        },
        data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        });
    },
    generateStatements(operType, showMsg) {
      return new Promise((resolve, reject) => {
        const params = {
          requireNo: this.contractValue,
          operType: operType || 'submit',
          statementType: 1,
          prepaymentRatio: NumberUtil.divide(Number(this.proportion), 100),
          orderNo: this.findContractItemByRequireNo.orderNo,
          statementNo: this.statementNo || undefined,
          prepaymentType: '2', //	String	预付款类型 1：合同预付款；2：材料预付款；
          uploadFiles: this.$clone(this.otherList) || []
        }
        if (params.uploadFiles.length) {
          params.uploadFiles.forEach(f => f.fileTypeId = "otherFile", )
        }
        InterfaceService.generateStatements(params, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.statementNo = data.respData.statementNo || ''
            if (operType == 'save') {
              if (showMsg) {
                this.$message.success('保存成功')
                if (window.opener) {
                  window.opener.location.reload();
                }
              }
            } else {
              let notificationName = ''
              try {
                notificationName = this.formatContractName(this.contractList.find(f => f.requireNo == this.contractValue))
              } catch (error) {
                console.error(error);
              }
              if (window.opener) {
                window.opener.location.reload();
              }
              this.$router.push({
                path: '/resultsFeedback',
                query: {
                  type: 'advanceCharge',
                  orderNo: this.orderNo,
                  statementNo: this.statementNo,
                  notificationName: encodeURIComponent(notificationName),
                  purchaserStatementNo: this.$route.query.purchaserStatementNo,
                  supplierStatementNo: this.$route.query.supplierStatementNo,
                }
              })
            }
            resolve(data.respData)
          } else {
            this.$message.error(data && data.respData && data.respData.respMsg)
            reject(data.respData)
          }
        }, data => {
          this.$message.error(data.respData && data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },
    handleChangeContract() {
      this.newToOrder = true
      this.form.pageIndex = 1
      // this.proportion  = ''
      this.orderForm()
    },


    /**
     * 材料进场 - 预付款 - 发货通知单
     */
    getRequireOrderList() {
      return new Promise(resolve => {
        const params = {
          orderNo: this.orderNo || '',
          requireStatus: [],
          status: '',
          searchType: '',
          // pageIndex: 3
        }
        InterfaceService.getRequireOrderList(params, data => {
          if (data.respCode === "0000") {
            this.billFfLadingInfo = data.respData || {}
            const requirements = this.billFfLadingInfo.requirements || []
            //  && (this.isReview ? true : f.requireStatus != '18') 不过滤 18 状态
            this.contractList = requirements.filter(f => f && f.eventList.some(s => s.eventType == 1 && s.eventStatus == 2)) || []
            console.log(this.contractList, 'this.contractList');

            resolve(true)
          } else {
            this.$message.error(data.respMsg)
          }
        }, data => { }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },

    orderDetails() {
      return new Promise(resolve => {
        const params = {
          orderNo: this.orderNo
        }
        InterfaceService.orderDetails(params, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.orderDetailInfo = data.respData || {}
            const contractStakeHolders = this.orderDetailInfo.contractStakeHolders || [],
              orderBankAcctInfo = this.orderDetailInfo.orderBankAcctInfo || []

            this.currentObject = contractStakeHolders.filter(item => item.role === '30')
            this.managerObject = contractStakeHolders.filter(item => item.role === '21')
            this.projectObject = orderBankAcctInfo.filter(item => item.acctBankType == 1)
            this.$emit('refreshOrderInfoData', {
              orderDetailInfo: this.orderDetailInfo || {},
            })
          } else {
            this.$message.error(data && data.respData && data.respData.respMsg)
          }
          resolve(true)
        })
      })
    },
    orderForm(isChangePage) {
      const params = {
        requireNo: this.contractValue,
        pageIndex: this.form.pageIndex,
        prepaymentRatio: NumberUtil.divide(Number(this.proportion), 100),
        operType: '0',
        statementNo: this.statementNo || undefined,
      }
      InterfaceService.orderForm(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.tableDataList = data.respData.requireList || []
          this.form.pageTotal = data.respData.totalCount || 1
          this.formatTableDataList(data.respData.prepaymentRatioTotal || '0')
          if (isChangePage) return
          // 选择要货单时  设置 累计预付金额(含税)(不含本次)
          this.$set(this.statementDetailInfo, 'statementAmtWithTaxTotal', data.respData.statementAmtWithTaxTotal)
          this.$set(this.statementDetailInfo, 'inStatementAmtWithTaxTotal', data.respData.inStatementAmtWithTaxTotal)
          this.totalStatementAmtWithTax = data.respData.totalStatementAmtWithTax || []
        } else {
          this.$message.error(data && data.respData && data.respData.respMsg)
        }
      })
    },
    formatTableDataList(value) {
      value = value || 0
      this.prepaymentRatioTotal = NumberUtil.accMul(Number(value), 100)
      const proportionPrepaymentRatioTotal = NumberUtil.numAdd(Number(this.proportion), this.prepaymentRatioTotal)
      this.tableDataList.forEach(f => {
        this.$set(f, 'prepaymentRatioTotal', proportionPrepaymentRatioTotal)
      })
      this.judgePrepaymentRatioTota()
    },
    async handleCurrentChange(page) {
      this.form.pageIndex = page;
      // this.pageSave && await this.handleClickBottom(2, false)
      console.log('分页查询');
      this.newToOrder ? this.orderForm(true) : this.getDetail(true)
    },
    handleOtherDownload() { },
    delOther(idx) {
      this.otherList.splice(idx, 1)
    },

    // 获取其他附件数据
    handleUpFileResult(e) {
      const { attachPath, attachName, attachUrl } = e
      this.otherList.push({
        attachName: attachName,
        attachUrl: attachUrl,
        filesUrl: attachPath,
        fileTypeId: "otherFile",
      })
    },
  },
  mounted() {
    this.init()
  },

  destroyed() {
  }
};
</script>


<style lang="scss" scoped>
.statementDeciaredTableInfo {
  position: relative;
  max-width: 1903px;
  margin: auto;
  &.tdBgColorWhite {
    table {
      tr {
        td {
          background: #fff;
        }
      }
    }
  }
  .lh25 {
    line-height: 25px !important;
  }
  .lh22 {
    line-height: 22px !important;
  }
  .lh21 {
    line-height: 21px !important;
  }
  .lh20 {
    line-height: 20px !important;
  }
  .lh17 {
    line-height: 17px !important;
  }

  .table-pagination {
    width: 1190px;
    margin: 20px auto 0;
    padding-bottom: 25px;
  }
  .table-container {
    margin: 10px auto 0;
    overflow: auto;
    min-width: 1190px;
    &::-webkit-scrollbar {
      height: 6px;
    }
    &::-webkit-scrollbar-thumb {
      border-radius: 0px;
      background: #bbb;
    }
    &::-webkit-scrollbar-button {
      width: 0;
    }
    .table-center {
      width: 1903px;
      /deep/ .el-select {
        .el-select__caret {
          margin-top: 6px;
        }
        .el-select__caret.is-reverse {
          margin-top: -2px;
        }
        .el-input__inner {
          height: 30px;
          line-height: 30px;
        }
      }
    }
    h2 {
      height: 54px;
      background: #f5f5f5;
      color: #444;
      font-size: 18px;
      text-align: center;
      font-weight: bold;
      line-height: 54px;
      margin: 0;
      border: 1px solid #ddd;
      border-bottom: 0;
    }
    .tableDataListTbody {
      tr {
        transition: all 0.3s linear;
        &:hover td {
          background: #f1f6fa;
        }
      }
    }
    .thead-flag {
      tr {
        th {
          height: 0;
          line-height: 0;
          overflow: hidden;
          padding: 0;
          margin: 0;
          vertical-align: top;
          border: 0;
        }
      }
    }
    tr {
      &.trlh17 {
        td {
          line-height: 17px;
        }
      }
      td {
        &.h54 {
          height: 54px;
        }
        &.h64 {
          height: 64px;
        }
        vertical-align: middle;
        &.tdlh17 {
          line-height: 17px;
        }
        transition: all 0.3s linear;
        // position: relative;
        color: #444;
        & > div.tl,
        div.tr {
          margin: 0 8px;
          word-break: break-all;
        }
        .surchargeDetailListContainer {
          p {
            border-bottom: 1px dashed #ddd;
            line-height: 18px;
            &:last-child {
              border-bottom: 0;
            }
          }
        }
      }
      // 输入框
      .edit-pricr-container {
        &.selectActive {
          & > div {
            transition: all 0.3s linear;
            border: 1px solid #c99f4f;
            // height: calc(100% + 1px);
          }
        }
        & > div {
          background: #fff;
          height: 100%;
          border: 1px solid transparent;
          label {
            height: 100%;
            display: flex;
            align-items: center;
          }
        }
      }

      &.title {
        td {
          height: 54px;
          line-height: 54px;
          font-weight: bold;
          font-size: 14px;
        }
      }
      td,
      th {
        transition: all 0.3s linear;
        color: #444;
        text-align: center;
        height: 30px;
        line-height: 18px;
        border: 1px solid #ddd;
        // border-top: 0;
        background: #f5f5f5;
        // 紫色
        &.bg-purple {
          background: #ece9ff;
        }
        // 浅蓝色
        &.bg-blue {
          background: #f0f8ff;
        }
        // 粉色
        &.bg-pink {
          background: #ffe9eb;
        }

        span {
          margin: 0 4px;
        }
        .input-center-label {
          display: block;
          height: 100%;
          .input-center {
            position: relative;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #fff;
            /deep/ input {
              padding: 0 15px 0 4px;
              width: 98px;
              text-align: right;
              display: inline-block;
            }
            .notice {
              position: absolute;
              bottom: 1px;
              line-height: 13px;
              text-align: left;
              left: 0;
            }
            span {
              width: calc(100% - 40px);
              text-align: right;
              display: inline-block;
            }
            em {
              position: absolute;
              top: calc(50% - 10px);
              right: 6px;
            }
            .tl {
              text-align: left !important;
            }
            .tr {
              text-align: right !important;
            }
          }
        }
      }
    }

    /deep/ input,
    .el-input__inner {
      border: 0;
    }
  }
  .download-container,
  .upload-container {
    width: 1190px;
    margin: auto;
    .title {
      border-left: 4px solid #444;
      font-size: 14px;
      color: #444;
      padding-left: 4px;
      height: 14px;
      line-height: 14px;
      display: inline-block;
    }
    .fileList {
      border: 1px solid #dddddd;
      padding: 14px 10px;
      margin-top: 10px;
      overflow: hidden;
      p {
        margin-top: 10px;
        &:first-child {
          margin-top: 0;
        }
      }
    }
  }
  .upload-container {
    border-top: 1px solid #eee;
    margin-top: 35px;
    padding-top: 20px;
    border-bottom: 1px solid #eee;
    padding-bottom: 30px;
    margin-bottom: 24px;
  }
}

.bulk-fill-price-container {
  .container {
    text-align: center;
  }
  .center {
    display: flex;
    width: 560px;
    margin: auto;
    align-items: center;
    margin-bottom: 18px;
    span {
      font-size: 14px;
      color: #888;
    }
    .input-div {
      display: flex;
      position: relative;
      width: calc(100% - 120px);
      em {
        position: absolute;
        right: 6px;
        top: 12px;
        color: #444;
      }
    }
    .btn-center {
      margin-bottom: 1px;
    }
  }
}
.agreement_read {
  width: 1190px;
  height: 30px;
  background: #ffe9eb;
  line-height: 30px;
  position: relative;
  margin: auto;
  label {
    display: flex;
    align-items: center;
    padding-left: 6px;
    /deep/ .el-checkbox__input {
      margin-top: 3px;
    }
    p {
      margin-left: 8px;
    }
  }
}
// 重置 悬浮 表头样式
/deep/ .table-thead-fixed {
  .inner-container {
    width: 1903px;
    td {
      border: 0 !important;
      background: #000 !important;
      font-size: 12px;
      padding: 0 !important;
    }
  }
}
.agreement_read_container {
  bottom: 54px !important;
  background: transparent !important;
}
.whitePre {
  white-space: pre;
}
.h120 {
  max-height: 120px;
  overflow: hidden;
  margin: 8px;
  .blue {
    max-height: 120px;
    overflow: hidden;
  }
}
.h72 {
  max-height: 72px;
  overflow: hidden;
  margin: 8px;
  .blue {
    max-height: 72px;
    overflow: hidden;
    display: block;
    display: -webkit-box;
    max-width: 400px;
    margin: 0 auto;
    -webkit-line-clamp: 4;
    -webkit-box-orient: vertical;
    text-overflow: ellipsis;
  }
}
.opt-container {
  width: 100%;
  display: flex;
  justify-content: space-between;
  height: 100%;
  & > div {
    background: rgba(255, 255, 255, 0.3);
    position: fixed;
    cursor: pointer;
    width: 50px;
    height: 50px;
    transition: all 0.3s linear;
    top: 50%;
    margin-top: -25px;
    border: 1px solid #ddd;
    border-radius: 50px;
    box-shadow: 0 0 4px rgba(0, 0, 0, 0.3);
    z-index: 1;
    &::before {
      content: "";
      width: 10px;
      height: 10px;
      border: 3px solid;
      border-radius: 2px;
      border-color: #ddd #ddd transparent transparent;
      position: absolute;
      transform: rotate(45deg);
      left: 50%;
      top: 50%;
      margin-left: -10px;
      margin-top: -8px;
      border-radius: 2px;
      transition: all 0.3s linear;
    }
    &:hover {
      background: rgba(255, 255, 255, 1);
      box-shadow: 0 0 4px rgba(0, 0, 8px, 0.7);
      &::before {
        border-color: #e1c079 #e1c079 transparent transparent;
      }
    }
    &.left {
      left: 10px;
      &::before {
        border-color: transparent transparent #ddd #ddd;
        margin-left: -5px;
      }
      &:hover {
        background: rgba(255, 255, 255, 1);
        &::before {
          border-color: transparent transparent #e1c079 #e1c079;
        }
      }
    }
    &.right {
      right: 10px;
    }
  }
}
</style>
