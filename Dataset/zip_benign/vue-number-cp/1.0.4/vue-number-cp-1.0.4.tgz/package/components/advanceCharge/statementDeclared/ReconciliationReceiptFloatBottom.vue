<template>
  <transition name="el-zoom-in-bottom">
    <div class="box" v-show="showBox">
      <div class="confirmContract" style="height: 600px">
        <div class="content">
          <div class="select-head">已对账的验收单</div>
          <table>
            <thead>
              <tr>
                <td width="122">序号</td>
                <td width="256">验收单据编号</td>
                <td width="250">验收单名称</td>
                <td width="252">关联发货单号</td>
                <td width="250">关联发货单</td>
              </tr>
            </thead>

            <tbody v-if="!(dataList(['supplierSubmit', 'purchaserPassed']) && dataList(['supplierSubmit', 'purchaserPassed']).length) && !(dataList(['oaApproveSucc']) && dataList(['oaApproveSucc']).length)">
              <tr>
                <td colspan="5" class="p0">
                  <div class="tc">暂无数据</div>
                </td>
              </tr>
            </tbody>

            <tbody v-if="dataList(['supplierSubmit', 'purchaserPassed']) && dataList(['supplierSubmit', 'purchaserPassed']).length">
              <tr>
                <td colspan="5" class="p0">
                  <div class="head-title">
                    <ul>
                      <li>
                        对账单编号：
                        <span>
                          {{dataList(['supplierSubmit', 'purchaserPassed']) && dataList(['supplierSubmit', 'purchaserPassed'])[0] && dataList(['supplierSubmit', 'purchaserPassed'])[0].statementNo || ''}}
                        </span>
                      </li>
                      <li>
                        创建时间：
                        <span>
                          {{dataList(['supplierSubmit', 'purchaserPassed']) && dataList(['supplierSubmit', 'purchaserPassed'])[0] && dataList(['supplierSubmit', 'purchaserPassed'])[0].createStatementDate || ''}}
                        </span>
                      </li>
                    </ul>
                    <div>
                      对账单状态：
                      <span>审核中</span>
                    </div>
                  </div>
                </td>
              </tr>
              <tr v-for="(item,index) in dataList(['supplierSubmit', 'purchaserPassed'])" :key="index">
                <td>{{index + 1}}</td>
                <td>{{item.deliveryNo || ''}}</td>
                <td class="blue hand" @click="handleView(item)">{{item.deliveryName || ''}}</td>
                <td>{{item.requireNo || ''}}</td>
                <td class="blue hand" @click="handleView(getRequirePdf(item))">{{getRequirePdf(item).requireName || ''}}</td>
              </tr>
            </tbody>
            <tbody v-if="dataList(['oaApproveSucc']) && dataList(['oaApproveSucc']).length">
              <tr>
                <td colspan="5" class="p0">
                  <div class="head-title">
                    <ul>
                      <li>
                        对账单编号：
                        <span>
                          {{dataList(['oaApproveSucc']) && dataList(['oaApproveSucc'])[0] && dataList(['oaApproveSucc'])[0].statementNo || ''}}
                        </span>
                      </li>
                      <li>
                        创建时间：
                        <span>
                          {{dataList(['oaApproveSucc']) && dataList(['oaApproveSucc'])[0] && dataList(['oaApproveSucc'])[0].createStatementDate || ''}}
                        </span>
                      </li>
                    </ul>
                    <div>
                      对账单状态：
                      <span>审核通过</span>
                    </div>
                  </div>
                </td>
              </tr>
              <tr v-for="(item,index) in dataList(['oaApproveSucc'])" :key="index">
                <td>{{index + 1}}</td>
                <td>{{item.deliveryNo || ''}}</td>
                <td class="blue hand" @click="handleView(item)">{{item.deliveryName || ''}}</td>
                <td>{{item.requireNo || ''}}</td>
                <td class="blue hand" @click="handleView(getRequirePdf(item))">{{getRequirePdf(item).requireName || ''}}</td>
              </tr>
            </tbody>
          </table>

          <!-- <div class="table-pagination">
            <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="form.pageTotal" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
            </el-pagination>
          </div> -->
        </div>
        <FixBottom class="bottom">
          <div class="tc">
            <el-button style="width: 120px;" @click="close">关闭</el-button>
          </div>
        </FixBottom>
      </div>
      <Loading :is-loading="isLoading"></Loading>
    </div>
  </transition>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import FixBottom from "@/components/base/FixBottom";

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    FixBottom,
  },
  computed: {
    getRequirePdf() {
      return item => {
        return this.dataItem.requireList && this.dataItem.requireList.find(f => f.requireNo == item.requireNo) || {}
      }
    },
    dataList() {
      // 供应商提交：supplierSubmit;
      // 采购商审核通过:purchaserPassed;
      // OA审核通过:oaApproveSucc;
      return statementStatus => {
        return this.dataItem.deliveryList && this.dataItem.deliveryList.filter(f => statementStatus.includes(f.statementStatus)) || []
      }
    },
  },
  data() {
    return {
      isLoading: false,
      showBox: false,
      options: [],
      value: '',
      form: {
        pageIndex: 1,
        pageSize: 10,
        pageTotal: 1,
      },
      dataItem: {}
    };
  },
  methods: {
    open(data) {
      this.dataItem = data || {}
      console.log(data);

      this.showBox = true
    },
    handleView(item) {
      console.log(item, '-');

      let encodeUrl = encodeURIComponent(item.attachUrl);
      const officeOpenTypeList = [".docx", ".dotx", ".doc", ".xlsx", ".xlsb", ".xlsm", ".xls", ".pptx", ".ppsx", ".ppt", ".pps", ".potx", ".ppsm"];
      let officeOpen = false;
      let userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
      let isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; //判断是否IE<11浏览器
      let isEdge = userAgent.indexOf("Edge") > -1 && !isIE; //判断是否IE的Edge浏览器
      let isIE11 = userAgent.indexOf('Trident') > -1 && userAgent.indexOf("rv:11.0") > -1;
      let IE = false;
      if (isIE || isEdge || isIE11) {
        IE = true
      } else {
        IE = false  //不是ie浏览器
      }
      officeOpenTypeList.some(item => {
        if (encodeUrl.indexOf(item) != -1) {
          return officeOpen = true
        }
      });
      if (officeOpen && !IE) {
        window.open("https://view.officeapps.live.com/op/view.aspx?src=" + encodeUrl, "_blank");
      } else {
        window.open(item.attachUrl, "_blank");
      }
    },
    handleCurrentChange() { },
    handleConfirm() {
      this.isLoading = true
      setTimeout(e => {
        this.isLoading = false
        this.showBox = false
        this.$emit('close', '--')
      }, 3000)
    },
    close() {
      this.showBox = false
    },
  }
};
</script>

<style lang="scss" scoped>
.box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .confirmContract {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    height: 400px;
    overflow-x: hidden;
    overflow-y: auto;
    .content {
      width: 1190px;
      margin: auto;
      background: #fff;
      opacity: 1;
      padding-bottom: 100px;
      padding-top: 10px;
      .select-head {
        color: #444;
        text-align: center;
        padding: 20px;
      }

      table {
        tr {
          border: 1px solid #eee;
          border-width: 1px 0;
        }
        thead {
          tr {
            td {
              background: #f9f9f9;
              height: 50px;
              line-height: 50px;
              padding: 0 12px;
              color: #888888;
              font-size: 14px;
            }
          }
        }
        tbody {
          tr {
            td {
              &.p0 {
                padding: 0;
                height: 30px;
                line-height: 30px;
              }
              .head-title {
                padding: 0 12px;
                background: #ece9ff;
                display: flex;
                justify-content: space-between;
                ul {
                  display: flex;
                  li {
                    margin-right: 50px;
                    color: #888888;
                    span {
                      color: #444;
                    }
                  }
                }
              }
              text-align: left;
              height: 34px;
              line-height: 34px;
              font-size: 12px;
              font-family: PingFang SC;
              font-weight: 400;
              color: #444444;
              padding: 0 12px;
            }
          }
        }
      }
    }
  }
}
</style>
