<template>
  <transition name="el-zoom-in-bottom">
    <div class="box" v-show="showBox">
      <div class="confirmContract">
        <div class="content">
          <h2>开票信息</h2>

          <div class="reminder">
            <p v-if="role=='S'">
              温馨提示：若开票信息账号有误，请联系采购商更改开票信息。
            </p>
            <p v-else>
              温馨提示：若开票信息账号有误，请至<span class="blue hand" @click="$router.push(`${role == 'S' ? '/vendorCenter' : '/purchaserCenter'}/enterpriseCertification`)">【管理中心】-【公司管理】-【企业实名认证】</span>页面，【基本户银行账户认证】重新认证成功后，系统自动替换。若票种有误，请登录ES修改。实际开票信息以本平台「基本户银行账户认证」的最新信息为准。
            </p>
          </div>

          <h3>票种：增值税发票</h3>
          <div class="table-container">
            <table>
              <thead>
                <tr>
                  <td width="40">1</td>
                  <td width="219">2</td>
                  <td width="165">3</td>
                  <td width="69">4</td>
                  <td width="64">5</td>
                  <td width="60">6</td>
                  <td width="40">7</td>
                  <td width="64">8</td>
                  <td width="168">9</td>
                  <td width="68">10</td>
                  <td width="151">11</td>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="endways color444"><span>购买方</span></td>
                  <td colspan="5" class="tl">
                    <ul class="color444">
                      <li><span>名&emsp;&emsp;&emsp;&emsp;称：</span>{{acCorpInfoBean.corpName || ''}}</li>
                      <li><span>纳税人识别号：</span>{{acCorpInfoBean.busiLicense || ''}}</li>
                      <li><span>工商注册地址：</span><em  v-html="region('reg')"></em></li>
                      <li><span>公司办公地址：</span><em  v-html="region('office')"></em></li>
                      <li><span>电&emsp;&emsp;&emsp;&emsp;话：</span>{{corpAddrInfo.officeTelNumber || '' | formatString}}</li>
                      <li><span>开户行及账号：</span>{{acCorpFinInfoBean.bankName}} {{acCorpFinInfoBean.bankAcct || '' | formatString('bank')}}</li>
                    </ul>
                  </td>
                  <td class="endways"><span>密码方</span></td>
                  <td colspan="5"></td>
                </tr>
                <tr>
                  <td colspan="2" height="65">货物或应税劳务、服务名称</td>
                  <td>规格型号</td>
                  <td>单位</td>
                  <td>数量</td>
                  <td colspan="3">单价</td>
                  <td>金额</td>
                  <td>税率</td>
                  <td>税额</td>
                </tr>
                <tr>
                  <td colspan="2">价税合计（大写）</td>
                  <td colspan="9">
                    <span>（小写）</span>
                  </td>
                </tr>
                <tr>
                  <td class="endways"><span>销售方</span></td>
                  <td colspan="5" class="tl">
                    <ul>
                      <li><span>名&emsp;&emsp;&emsp;&emsp;称：</span></li>
                      <li><span>纳税人识别号：</span></li>
                      <li><span>地 址、 电 话：</span></li>
                      <li><span>开户行及账号：</span></li>
                    </ul>
                  </td>
                  <td class="endways color444"><span>备注</span></td>
                  <td colspan="5" class="tl">
                    <ul class="color444">
                      <li><span>合&nbsp;同&nbsp;号&nbsp;：</span>{{tabIndex == 1 ? orderDetailInfo.clOrderNo : orderDetailInfo.sybOrderNo || ''}}</li>
                      <li><span>项目名称：</span>{{orderDetailInfo.projectName || ''}}</li>
                      <li><span>项目地址：</span>{{orderDetailInfo.projectFullAddr || ''}}</li>
                      <li><span>其&emsp;&emsp;他：</span>{{orderDetailInfo.other || ''}}</li>
                    </ul>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

        </div>
        <FixBottom class="bottom">
          <div class="tc">
            <el-button style="width: 120px;" @click="close">关闭</el-button>
          </div>
        </FixBottom>
      </div>
      <Loading :is-loading="isLoading"></Loading>
    </div>
  </transition>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import FixBottom from "@/components/base/FixBottom";

export default {
  mixins: [accountMixin],
  props: {
    isRebar: {
      type: Boolean,
      default: true
    },
    // 区分 0:材料合同对账单 , 1:事业部合同对账单
    tabIndex: {
      type: Number,
      default: 0
    },
    orderDetailInfo: {
      type: Object,
      default() {
        return {}
      }
    }
  },
  components: {
    Loading,
    FixBottom,
  },
  data() {
    return {
      isLoading: false,
      showBox: false,
      options: [],
      timeValue: '',
      billingBaseInfo: {},
    };
  },
  computed: {
    acCorpInfoBean() {
      return this.billingBaseInfo && this.billingBaseInfo.acCorpInfoBean || {}
    },
    corpAddrInfo() {
      return this.billingBaseInfo && this.billingBaseInfo.corpAddrInfoRst || {}
    },
    acCorpFinInfoBean() {
      return this.billingBaseInfo && this.billingBaseInfo.acCorpFinInfoBean || {}
    },
    region() {
      return function (type) {
        if (type == 'reg') {
          return `${this.corpAddrInfo.regProvCodeDisp || ""}&nbsp;&nbsp;${this.corpAddrInfo.regCityCodeDisp || ""}&nbsp;&nbsp;${this.corpAddrInfo.regDistrictCodeDisp || ''}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;${this.corpAddrInfo.regDetailAddr || ""}`
        } else {
          return `${this.corpAddrInfo.officeProvCodeDisp || ""}&nbsp;&nbsp;${this.corpAddrInfo.officeCityCodeDisp || ""}&nbsp;&nbsp;${this.corpAddrInfo.officeDistrictCodeDisp || ''}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;${this.corpAddrInfo.officeDetailAddr || ""}`
        }
      }
    }
  },
  filters: {
    // 过滤 字符串显示 state: 默认 电话格式, bank: 银行卡格式
    formatString: (val, state) => {
      state = state || 'tel'
      val = val || ''

      let newVal = ''
      if (state === 'tel') {
        // 如果检测到 有 -  说明是座机 不做分割
        if (val.includes('-')) {
          newVal = val
        } else {
          newVal = `${val.slice(0, 3)} ${val.slice(3, 7)} ${val.slice(7, val.length)}`
        }
        newVal = val.length <= 3 ? val : newVal
      } else {
        const len = Math.floor(val.length / 4)

        for (let i = 0; i < len; i++) {
          newVal += `${val.slice(4 * i, 4 * (i + 1))} `
          if (i + 1 >= len) newVal += val.slice(4 * (i + 1), val.length)
        }

        newVal = val.length <= 4 ? val : newVal
      }

      return newVal
    }
  },
  mounted() {
    this.$nextTick(() => {
      document.addEventListener('keyup', this.keyupEsc)
    })
  },
  methods: {
    open(corpId) {
      this.getVendorMessage(corpId)
      this.showBox = true
    },
    keyupEsc(e) {
      if (e.keyCode == 27) {
        this.close();
      }
    },
    handleConfirm() {
      this.isLoading = true
      setTimeout(e => {
        this.isLoading = false
        this.showBox = false
        this.$emit('close', '--')
      }, 3000)
    },
    close() {
      this.showBox = false
    },


    // 供应商公司详情
    getVendorMessage(corpId) {
      let param = {
        corpId: corpId,
      }
      InterfaceService.getVendorMessage(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.billingBaseInfo = data.respData || {}
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  },

  destroyed() {
    window.removeEventListener('keyup', this.keyupEsc, false);
  },
};
</script>

<style lang="scss" scoped>
.box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .confirmContract {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    height: 500px;
    overflow-x: hidden;
    overflow-y: auto;
    padding-bottom: 50px;
    .content {
      width: 1190px;
      margin: auto;
      background: #fff;
      opacity: 1;
      padding-bottom: 80px;
      padding-top: 10px;
      h2 {
        font-size: 14px;
        font-family: PingFang SC;
        color: #444;
        text-align: center;
      }

      .reminder {
        margin: 28px auto 20px;
        width: 1190px;
        background: #fffcf0;
        border: 1px solid #fae2a5;
        padding: 6px 10px 5px 10px;
        span {
          width: 1124px;
          height: 19px;
          font-size: 12px;
          font-family: PingFang SC;
          font-weight: 400;
          line-height: 17px;
          color: #444444;
          opacity: 1;
        }
      }
    }
  }
}
/deep/ .el-select {
  width: 400px;
  input {
    height: 32px;
    line-height: 32px;
  }
}
.authorized {
  /deep/ .el-form-item__label {
    line-height: 17px;
  }
}
.special-form-item {
  position: relative;
  /deep/ {
    .el-form-item__label {
      margin-bottom: 6px;
      text-align: left;
      color: #444 !important;
      line-height: 17px;
    }
    .el-form-item__content {
      margin-left: 0 !important;
      line-height: 22px;
    }
  }
}
.enclosure-content {
  width: 1185px;
  background: #ffffff;
  border: 1px solid #dddddd;
  padding: 10px;
  line-height: 17px;
  font-size: 12px;
  margin-top: 6px;
  p {
    margin-bottom: 10px;
  }
  p:last-of-type {
    margin-bottom: 0;
  }
}
h1 {
  margin-bottom: 20px;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  > span {
    font-weight: normal;
    margin: 0 20px 0 6px;
  }
  > i {
    font-weight: normal;
  }
}
.width-auto {
  width: 1185px;
  margin-left: -595px;
}
.margin-auto {
  margin-left: 0;
}
/deep/ .el-col {
  position: relative;
  .del-txt {
    position: absolute;
    top: 20px;
    right: 84px;
    font-size: 12px;
    z-index: 20;
  }
}
.is-disabled {
  color: #444;
  cursor: auto;
  font-size: 12px;
  text-align: center;
  padding-top: 3px;
  border-top: 1px solid #eee;
}
.chargeOfContract {
  position: absolute;
  left: 595px;
  /deep/ .el-select {
    width: 400px;
  }
}

.aegalAuthorizedClient {
  position: relative;
  /deep/ .el-form-item__label {
    margin-top: -8px;
  }
  &::after {
    content: "(法人代表或授权委托人)";
    position: absolute;
    width: 130px;
    text-align: right;
    color: #888;
    white-space: pre;
    left: 30px;
    top: 21px;
  }
  &.projectSigner {
    &::after {
      content: "(收发货公司项目章的电子用印人)";
      left: -27px;
    }
  }
  &.htzdzyyr {
    &::after {
      content: "(合同章电子用印人)";
      left: -48px;
    }
  }

  &.left52 {
    &::after {
      left: 52px !important;
    }
  }
  &.fLeft27 {
    &::after {
      left: -27px !important;
    }
  }
  &.fLeft83 {
    &::after {
      left: -83px !important;
    }
  }
}
.el-row {
  overflow: initial;
}
h3 {
  margin-bottom: 10px;
  color: #444;
}
table {
  width: 100%;
  thead {
    td {
      height: 0;
      line-height: 0;
      overflow: hidden;
      padding: 0;
      margin: 0;
      vertical-align: top;
      border: 0;
    }
  }
  td {
    text-align: center;
    border: 1px solid #ddd;
    padding: 11px;
    font-size: 14px;
    font-family: PingFang SC;
    color: #bbb;
    position: relative;

    ul {
      li {
        margin-top: 10px;
        &:first-child {
          margin-top: 0;
        }
      }
    }

    &.endways {
      vertical-align: middle !important;
    }
  }
}
.color444 {
  color: #444;
}
</style>
