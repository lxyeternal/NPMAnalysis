<template>
  <div>
    <div class="table">
      <!-- 列表 -->
      <table>
        <thead>
          <tr>
            <td width="270">预付款单号/合同名称</td>
            <td :width="160">{{role == 'B' ? `供应商${brokerRole && '/项目公司' || ''}` : '采购商'}}</td>
            <!-- 设计确认 都叫申报 -->
            <td width="100" v-if="tab != 1||role == 'B'">申报时间</td>
            <td width="100">预付类型</td>
            <td width="80" class="tr">预付比例</td>
            <!-- BUG #11534 -->
            <td width="120" class="tr">本次预付金额<br>(含税)(元)</td>
            <td width="70">状态</td>
            <td width="72" class="tr">操作</td>
          </tr>
        </thead>

        <template v-if="data.length">
          <tbody v-for="(item,index) in data" :key="index" class="tbody-row">
            <tr :class="{'border-none':position!='detail'}" class="tl">
              <td>
                <p class="order-no">
                  <!-- {{(role == 'B' ?item.purchaserStatementNo : item.supplierStatementNo) || ''}} -->
                  {{item.supplierStatementNo}}
                </p>
                <p class="order-no" :title="`《 ${item.contractName || '-'} 》`">《 {{item.contractName || '-'}} 》</p>
                <p></p>
              </td>
              <td>
                <span> {{(role == 'B' ? item.supplierName : item.purchaserName) || '-'}} </span>
                <p v-if="brokerRole">{{item.purchaserName}}</p>
              </td>
              <td v-if="tab != 1||role == 'B'">
                <span v-if="rejectionReasonComputed(item.statementOperFlowList, 'supplierSubmit').operTime">{{rejectionReasonComputed(item.statementOperFlowList, 'supplierSubmit').operTime || 0}}</span>
                <span v-else>-</span>
              </td>
              <td>
                <span>{{item.prepaymentTypeDesc || '-'}}</span>
              </td>
              <td class="tr">
                <span v-if="numberUtilComputed.accMul(item.prepaymentRatio, 100)">{{numberUtilComputed.accMul(item.prepaymentRatio, 100) || ''}}%</span>
                <span v-else>-</span>
              </td>
              <td class="tr">
                <span>{{(item.statementAmtWithTax || 0) | formatMoney}} </span>
              </td>
              <td>
                <span>{{item.statementStatusDesc || '-'}} </span>
              </td>
              <!-- 保存: supplierSave; 供应商提交: supplierSubmit; 采购商审核通过: purchaserPassed; 采购商审核退回:purchaserReturn; 供应商关闭:supplierClose; 供应商删除:supplierDeleteOA 审核通过:oaApproveSucc;）' -->
              <td class="tr">
                <template v-if="['supplierSave'].includes(item.statementStatus) && tab == 1">
                  <p>
                    <span class="blue hand" @click="handleClickEdit(item)">编辑</span>
                  </p>
                  <p>
                    <span class="blue hand" @click="handleClicDel(item)">删除</span>
                  </p>
                </template>
                <template v-if="['purchaserReturn'].includes(item.statementStatus) && tab == 1">
                  <p>
                    <span class="blue hand" @click="handleClickEdit(item)">编辑</span>
                  </p>
                  <p>
                    <span class="blue hand" @click="handleClicClose(item)">关闭</span>
                  </p>
                </template>
                <template v-if="['oaApproveFail'].includes(item.statementStatus)">
                  <template v-if="role == 'B' && tab == 1">
                    <p><span class="blue hand" @click="handleClickExamine(item)">重新审核</span></p>
                    <p><span class="blue hand" @click="handleClickReturn(item)">退回</span></p>
                  </template>
                  <p>
                    <span class="blue hand" @click="handleClickDetail(item)">查看详情</span>
                  </p>
                </template>
                <template v-if="['supplierSubmit', 'purchaserPassed', 'supplierClose', 'oaApproveSucc', 'purchaserReturn'].includes(item.statementStatus) && tab != 1">
                  <p>
                    <span class="blue hand" @click="handleClickDetail(item)">查看详情</span>
                  </p>
                </template>
                <template v-if="role == 'B' && ['supplierSubmit'].includes(item.statementStatus) && tab == 1">
                  <span class="blue hand" @click="handleClickExamine(item)">审核</span>
                </template>
              </td>
            </tr>
            <tr v-if="tab == 1 && rejectionReasonComputed(item.statementOperFlowList, 'purchaserReturn').operMsg && item.statementStatus=='purchaserReturn'" class="error-msg">
              <td :colspan="tab != 1||role == 'B' ? 8 :7" :class="{'fold':item.foldFlag}">
                <div>
                  <span class="bold fl">退回原因：</span>
                  <span class="fl">{{rejectionReasonComputed(item.statementOperFlowList, 'purchaserReturn').operMsg || ''}}</span>
                  <span class="fr blue-pointer" @click="item.foldFlag = $set(item, 'foldFlag', !item.foldFlag)">{{!item.foldFlag ? '展开':'收起'}}
                    <i v-if="!item.foldFlag" class="el-icon-caret-bottom"></i>
                    <i v-else class="el-icon-caret-top"></i>
                  </span>
                </div>
                <div class="fl" v-if="item.foldFlag" style="margin-top: 10px;"><em class="grey">退回时间：</em>{{rejectionReasonComputed(item.statementOperFlowList, 'purchaserReturn').operTime || 0}}</div>
                <div style="clear: both"></div>
              </td>
            </tr>
          </tbody>
        </template>
      </table>
    </div>

    <div class="table-pagination" v-if="pageSize && data.length">
      <el-pagination @current-change="handleCurrentChange" :currentPage="pageIndex" :pageSize="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
      </el-pagination>
    </div>

    <InvoicBaseInfoBottomComponent ref="invoicBaseInfoBottomComponentRef" @close="handleCloseFloatBottom"></InvoicBaseInfoBottomComponent>

    <el-dialog class="dialog returnDialogContainer pr50" title="退回原因" :append-to-body="true" :lock-scroll="true" :visible.sync="rejectDialogVisible" width="840px" center :close-on-click-modal="false" @close="rejectForm.refuseReason = ''">
      <div>
        <el-form :model="rejectForm" label-width="80px" ref="ruleForm" :rules="rules">
          <el-form-item label="退回原因：" prop="refuseReason">
            <el-input type="textarea" class="resize-none" v-model="rejectForm.refuseReason" rows="4" maxlength="200" show-word-limit placeholder="请输入..."></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" :disabled="!rejectForm.refuseReason.replace(/\s+/g,'')" @click="advanceExamineOperationReturn">退回</el-button>
        <el-button class="normal-btn" @click="rejectDialogVisible = false">取消</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import accountMixin from '@/mixins/account';
import { InterfaceService } from "@/services/api";
import { NumberUtil } from '@/utils/numberUtil'
import InvoicBaseInfoBottomComponent from "@/components/advanceCharge/advancePaymentRequest/InvoicBaseInfoBottomComponent";

export default {
  mixins: [accountMixin],
  components: {
    InvoicBaseInfoBottomComponent,
  },
  props: ["tab", "data", "pageIndex", "pageSize", "total", "showPagination", 'position'],
  data() {
    return {
      sortList: [0, 2, 0],
      isLoading: false,
      rejectDialogVisible: false,
      rejectForm: {
        refuseReason: ''
      },
      rules: {
        refuseReason: [{ required: true, message: '请填写退回原因', trigger: 'blur' }],
      },
    };
  },
  computed: {
    rejectionReasonComputed() {
      return (list, type) => list && list.find(f => f.operType == type) || {}
    },
    numberUtilComputed() {
      return NumberUtil
    },
  },
  methods: {
    handleCloseFloatBottom() {

    },
    beenReconciled() {
      this.$refs["invoicBaseInfoBottomComponentRef"].open()
    },
    handleClickExamine(item) {
      this.$router.push({
        path: '/advancePaymentRequesDetail',
        query: {
          orderNo: item.orderNo,
          statementNo: this.role == 'B' ? item.purchaserStatementNo : item.supplierStatementNo,
          purchaserStatementNo: item.purchaserStatementNo,
          supplierStatementNo: item.supplierStatementNo,
          state: 'examine'
        }
      })
      // window.open(this.$router.resolve({
      //   path: '/advancePaymentRequesDetail',
      //   query: {
      //     orderNo: item.orderNo,
      //     statementNo: this.role == 'B' ? item.purchaserStatementNo : item.supplierStatementNo,
      //     purchaserStatementNo: item.purchaserStatementNo,
      //     supplierStatementNo: item.supplierStatementNo,
      //     state: 'examine'
      //   }
      // }).href, '_blank')
    },
    handleClickDetail(item) {
      window.open(this.$router.resolve({
        path: '/advancePaymentRequesDetail',
        query: {
          orderNo: item.orderNo,
          statementNo: this.role == 'B' ? item.purchaserStatementNo : item.supplierStatementNo,
          purchaserStatementNo: item.purchaserStatementNo,
          supplierStatementNo: item.supplierStatementNo,
        }
      }).href, '_blank')
    },
    handleClickEdit(item) {
      this.$router.push({
        path: '/advancePaymentRequestComfirm',
        query: {
          orderNo: item.orderNo,
          statementNo: this.role == 'B' ? item.purchaserStatementNo : item.supplierStatementNo,
        }
      })
      // window.open(this.$router.resolve({
      //   path: '/advancePaymentRequestComfirm',
      //   query: {
      //     orderNo: item.orderNo,
      //     statementNo: this.role == 'B' ? item.purchaserStatementNo : item.supplierStatementNo,
      //   }
      // }).href, '_blank')
    },
    handleClickReturn(item) {
      this.statementNo = this.role == 'B' ? item.purchaserStatementNo : item.supplierStatementNo
      this.$refs['ruleForm'] && this.$refs['ruleForm'].resetFields();
      this.rejectDialogVisible = true
    },
    handleClicClose(item) {
      this.$confirm("关闭后不能恢复，确定要关闭吗？", "确认关闭", {
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        confirmButtonText: "确认",
        cancelButtonText: '取消',
      }).then(() => {
        this.advanceExamineOperation(this.role == 'B' ? item.purchaserStatementNo : item.supplierStatementNo, 'supplierClose')
      }).catch(() => {
      });
    },
    handleClicDel(item) {
      this.$confirm("删除后不能恢复，确定要删除吗？", "确认删除", {
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        confirmButtonText: "确认",
        cancelButtonText: '取消',
      }).then(() => {
        this.advanceExamineOperation(this.role == 'B' ? item.purchaserStatementNo : item.supplierStatementNo)
      }).catch(() => {
      });
    },
    advanceExamineOperation(statementNo, operType) {
      const params = {
        statementNo, // 预付款单编号
        operType: operType || 'supplierDelete', // 操作类型（删除:supplierDelete;审核通过:purchaserPassed;退回:purchaserReturn;关闭:supplierClose）
        returnReason: '', // 退回原因
      }
      InterfaceService.advanceExamineOperation(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success(`${operType == 'supplierClose' ? '关闭' : '删除'}成功!`)
          this.refreshData()
        } else {
          this.$message.error(data && data.respData && data.respData.respMsg)
        }
      })
    },

    // 退回
    advanceExamineOperationReturn() {
      const operType = 'purchaserReturn'
      const params = {
        statementNo: this.statementNo, // 预付款单编号
        operType, // 操作类型（删除:supplierDelete;审核通过:purchaserPassed;退回:purchaserReturn;关闭:supplierClose）
        returnReason: this.rejectForm.refuseReason, // 退回原因
        statementType: '2'
      }
      InterfaceService.advanceExamineOperation(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          switch (operType) {
            case 'purchaserPassed':
              this.$router.push({
                path: '/resultsFeedback',
                query: {
                  type: 'statementDeclaredDetai',
                  orderNo: this.$route.query.orderNo,
                  statementNo: this.$route.query.statementNo
                }
              })
              break;
            case 'purchaserReturn':
              this.rejectDialogVisible = false
              this.$message.success(`退回成功!`)
              this.$emit("refresh");
              this.statementNo = ''
              break;

            default:
              break;
          }
          if (window.opener) {
            window.opener.location.reload();
          }
        } else {
          this.$message.error(data && data.respData && data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

    // 分页
    handleCurrentChange(page) {
      this.$emit("currentChange", page);
      window.scrollTo(0, 0)
    },
    // 排序
    handleSort(index) {
      let arr = [].concat(this.sortList);
      this.sortList.forEach((item, i) => {
        if (index == i) {
          if (item == 0) {
            arr[i] = 2;
          } else if (item == 2) {
            arr[i] = 1;
          } else {
            arr[i] = 0;
          }
        } else {
          arr[i] = 0;
        }
      });
      this.sortList = arr;
      this.$emit("sortChange", this.sortList);
    },
    refreshData() {
      this.$emit("refresh");
    }
  },
  mounted() {
  }
};
</script>

<style lang="scss" scoped>
.pointer {
  cursor: pointer;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }

  .active {
    color: #ffd64e;
  }
}

.table {
  /deep/ .el-button {
    font-size: 12px;
  }

  width: 100%;
  line-height: 23px;
  font-size: 12px;
  table {
    table-layout: fixed;
    width: 100%;
  }
  td {
    padding: 14px 10px;
    vertical-align: middle;
    word-break: break-word;
  }

  thead {
    text-align: left;
    white-space: nowrap;
    font-size: 14px;
    color: #888;
    background: #f9f9f9;
  }

  tbody {
    text-align: center;

    tr:hover {
      background: #e8f3fd;
    }
    td {
      border-bottom: 1px solid #eee;
    }
  }
  .tbody-row {
    &:hover {
      background: #e8f3fd;
      .sign-content {
        background: #f0f8ff;
      }
    }
    .sign-content {
      display: table-row;
      background: #f9f9f9;
      &:hover {
        display: table-row;
      }
      td {
        padding: 0;
        border-top: none;
      }
    }
  }

  tbody {
    text-align: center;
    tr {
      border-bottom: 1px solid #ebeef5;
    }
    .border-none {
      border-bottom: none;
    }
  }
}

.table-pagination {
  margin: 50px 0 80px;
  text-align: center;
  color: #888888;
}

.order-no {
  height: 100%;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 2;
  overflow: hidden;
  max-height: 44px;
}

.deliver-dialog {
  margin: 0 30px;
  text-align: left;
  /deep/ .el-input {
    width: 180px;
  }
}

.form-response-item {
  display: inline-block;
  margin-left: 10px;
  vertical-align: bottom;
  label {
    display: inline-block;
    vertical-align: middle;
    width: 79px;
  }
}

@media (max-width: 1300px) {
  .form-response-item {
    width: 100%;
    margin-top: 10px;
    margin-left: 0;
  }
}
.error-msg {
  line-height: 30px;
  overflow: hidden;
  td {
    padding: 0 10px;
    background: #ffe9eb;
    height: 30px;
    span {
      &:nth-of-type(2) {
        width: calc(100% - 130px);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        text-align: left;
      }
      &:last-child {
        width: 40px;
      }
    }
  }
  .fold {
    line-height: 17px;
    padding: 6px 10px;
    height: auto;
    & > div {
      overflow: hidden;
    }
    span {
      &:nth-of-type(2) {
        width: calc(100% - 130px);
        text-overflow: ellipsis;
        white-space: normal;
      }
    }
  }
}
</style>
