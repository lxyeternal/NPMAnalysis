<template>
  <transition name="el-zoom-in-bottom">
    <div class="box" v-show="showBox">
      <div class="confirmContract">
        <div class="content">
          <div class="select-head">选择浮动基准</div>
          <div class="center">
            <p v-if="isRebar">※数据来源：“我的钢铁网”<span class="blue">www.mysteel.com</span>建筑钢材价格行情。</p>
            <p v-else>※数据来源：“有色金属网”<span class="blue">www.mysteel.com</span>电解铜电解铜价格行情。</p>
            <dl>
              <dd>价格：<span class="red">5370</span>元/吨 </dd>
              <dd>涨跌：<span class="red">-30</span> </dd>
            </dl>
          </div>
          <ul v-if="isRebar">
            <li>
              <span>地区：</span>
              <el-select v-model="timeValue" placeholder="请选择地区">
                <el-option v-for="item in options" :key="item.requireNo" :label="item.contractName" :value="item.requireNo">
                </el-option>
              </el-select>
            </li>
            <li>
              <span>日期：</span>
              <el-date-picker type="date" placeholder="请选择日期" value-format="yyyy-MM-dd" v-model="timeValue" style="width: 400px"></el-date-picker>
            </li>
            <li>
              <span>品名：</span>
              <el-select v-model="timeValue" placeholder="请选择品名">
                <el-option v-for="item in options" :key="item.requireNo" :label="item.contractName" :value="item.requireNo">
                </el-option>
              </el-select>
            </li>
            <li>
              <span>规格：</span>
              <el-select v-model="timeValue" placeholder="请选择规格">
                <el-option v-for="item in options" :key="item.requireNo" :label="item.contractName" :value="item.requireNo">
                </el-option>
              </el-select>
            </li>
            <li>
              <span>材质：</span>
              <el-select v-model="timeValue" placeholder="请选择材质">
                <el-option v-for="item in options" :key="item.requireNo" :label="item.contractName" :value="item.requireNo">
                </el-option>
              </el-select>
            </li>
            <li>
              <span>钢厂/产地：</span>
              <el-select v-model="timeValue" placeholder="请选择钢厂/产地">
                <el-option v-for="item in options" :key="item.requireNo" :label="item.contractName" :value="item.requireNo">
                </el-option>
              </el-select>
            </li>
          </ul>
          <ul v-else>
            <li>
              <span>日期：</span>
              <el-date-picker type="date" placeholder="请选择日期" value-format="yyyy-MM-dd" v-model="timeValue" style="width: 400px"></el-date-picker>
            </li>
          </ul>
        </div>
        <FixBottom class="bottom">
          <div class="tc">
            <!-- <el-button type="primary" @click="handleConfirm">确认</el-button> -->
            <el-button style="width: 120px;" @click="close">关闭</el-button>
          </div>
        </FixBottom>
      </div>
      <Loading :is-loading="isLoading"></Loading>
    </div>
  </transition>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import FixBottom from "@/components/base/FixBottom";

export default {
  mixins: [accountMixin],
  props: {
    isRebar: {
      type: Boolean,
      default: true
    }
  },
  components: {
    Loading,
    FixBottom,
  },
  data() {
    return {
      isLoading: false,
      showBox: false,
      options: [],
      timeValue: ''
    };
  },
  methods: {
    open() {
      this.showBox = true
    },
    handleConfirm() {
      this.isLoading = true
      setTimeout(e => {
        this.isLoading = false
        this.showBox = false
        this.$emit('close', '--')
      }, 3000)
    },
    close() {
      this.showBox = false
    },
  }
};
</script>

<style lang="scss" scoped>
.box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .confirmContract {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    height: 400px;
    overflow-x: hidden;
    overflow-y: auto;
    .content {
      width: 1190px;
      margin: auto;
      background: #fff;
      opacity: 1;
      padding-bottom: 30px;
      padding-top: 10px;
      .select-head {
        color: #444;
        text-align: center;
        padding: 20px;
        border-bottom: 1px solid #eee;
      }
      .center {
        display: flex;
        justify-content: space-between;
        color: #444;
        padding-top: 10px;
        dl {
          display: flex;
          dd {
            margin-left: 30px;
          }
        }
      }
      ul {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-between;
        li {
          padding: 0;
          display: flex;
          width: 50%;
          align-items: center;
          margin-top: 22px;
          justify-content: flex-end;
          &:nth-child(odd) {
            justify-content: flex-start;
            span {
              width: 44px;
            }
          }
          span {
            color: #888;
            font-size: 14px;
            width: 140px;
            text-align: right;
          }
          /deep/ .el-select input {
            height: 34px;
            line-height: 34px;
          }
        }
      }
    }
  }
}
/deep/ .el-select {
  width: 400px;
  input {
    height: 32px;
    line-height: 32px;
  }
}
.authorized {
  /deep/ .el-form-item__label {
    line-height: 17px;
  }
}
.special-form-item {
  position: relative;
  /deep/ {
    .el-form-item__label {
      margin-bottom: 6px;
      text-align: left;
      color: #444 !important;
      line-height: 17px;
    }
    .el-form-item__content {
      margin-left: 0 !important;
      line-height: 22px;
    }
  }
}
.enclosure-content {
  width: 1185px;
  background: #ffffff;
  border: 1px solid #dddddd;
  padding: 10px;
  line-height: 17px;
  font-size: 12px;
  margin-top: 6px;
  p {
    margin-bottom: 10px;
  }
  p:last-of-type {
    margin-bottom: 0;
  }
}
h1 {
  margin-bottom: 20px;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  > span {
    font-weight: normal;
    margin: 0 20px 0 6px;
  }
  > i {
    font-weight: normal;
  }
}
.width-auto {
  width: 1185px;
  margin-left: -595px;
}
.margin-auto {
  margin-left: 0;
}
/deep/ .el-col {
  position: relative;
  .del-txt {
    position: absolute;
    top: 20px;
    right: 84px;
    font-size: 12px;
    z-index: 20;
  }
}
.is-disabled {
  color: #444;
  cursor: auto;
  font-size: 12px;
  text-align: center;
  padding-top: 3px;
  border-top: 1px solid #eee;
}
.chargeOfContract {
  position: absolute;
  left: 595px;
  /deep/ .el-select {
    width: 400px;
  }
}

.aegalAuthorizedClient {
  position: relative;
  /deep/ .el-form-item__label {
    margin-top: -8px;
  }
  &::after {
    content: "(法人代表或授权委托人)";
    position: absolute;
    width: 130px;
    text-align: right;
    color: #888;
    white-space: pre;
    left: 30px;
    top: 21px;
  }
  &.projectSigner {
    &::after {
      content: "(收发货公司项目章的电子用印人)";
      left: -27px;
    }
  }
  &.htzdzyyr {
    &::after {
      content: "(合同章电子用印人)";
      left: -48px;
    }
  }

  &.left52 {
    &::after {
      left: 52px !important;
    }
  }
  &.fLeft27 {
    &::after {
      left: -27px !important;
    }
  }
  &.fLeft83 {
    &::after {
      left: -83px !important;
    }
  }
}
.el-row {
  overflow: initial;
}
</style>
