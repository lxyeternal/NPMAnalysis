<template>
    <div>
        <!-- 添加授权人信息 -->
        <el-dialog title="导入绿地香港用户" :visible.sync="addSystemInfoVisible" v-if="addSystemInfoVisible" width="700px" :modal='!dialog'  :close-on-click-modal="false" @close="handleClose">
            <el-row>
                <el-col :span="18">
                    <el-input placeholder="请输入真实姓名搜索" v-model.trim="custInfo" @keyup.enter.native="handleSearch(1)"></el-input>
                </el-col>
                <el-col :span="6">
                    <div  class="search">
                        <el-button type="primary" size="small" @click="handleSearch(1)" >搜索</el-button>
                        <el-button size="small" @click="handleClear()">清除</el-button>
                    </div>
                </el-col>
            </el-row>
            <ul class="content">
                <!--<li>-->
                    <!--<p><em class="bold">张三</em> <em>11232121211</em></p>-->
                    <!--<p>运营经理，徐州项目运营部</p>-->
                <!--</li>-->
                <li v-for="(item,index) in custList">
                    <el-radio v-model="radio" :label="index">
                        <span>
                            <em class="bold">{{item.custName}}</em>
                            <em v-if="item.mobileNo">{{item.mobileNo}}</em>
                            <em v-if="item.title">{{item.title}}{{item.deptName?"，"+item.deptName:""}}{{item.cityCompany?"，"+item.cityCompany:""}}</em>
                        </span>
                    </el-radio>
                </li>
                <div class="product-empty" v-if="!custList.length&&!isLoading">
                    <img src="@/assets/images/icon-no-product.png">
                    <p>没有搜索到相关用户，请重新修改搜索条件搜索！</p>
                </div>
            </ul>
            <div class="table-pagination" v-if="custList.length">
                <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                </el-pagination>
            </div>
            <div class="dialog-footer">
                <el-button type="primary" size="small" @click="handleComfirm">确认</el-button>
                <el-button size="small" @click="handleClose">取消</el-button>
            </div>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";


export default {
    components: {
        Loading
    },
    props:["dialog"],
    data() {
        return {
            isLoading: false,
            radio: -1,
            custInfo: "",
            custList: [],
            pageIndex: 1,
            pageSize: 5,
            total: 0,
            addSystemInfoVisible: false,
            order: {},
        };
    },
    methods: {
        open() {
            this.custInfo = "";
            this.addSystemInfoVisible = true;
            this.handleSearch(1);
        },
        handleCurrentChange(page){
            this.pageIndex = page;
            this.handleSearch();
            // this.getOrderList();
            // window.scrollTo(0,0)
        },
        handleClear(){
            this.custInfo = '';
            this.handleSearch(1)
        },
        handleClose() {
            this.addSystemInfoVisible = false;
            this.$emit("close")
        },
        handleComfirm() {
            if (this.custList && this.custList.length) {
                let onOff = false;
                this.custList.forEach((item,ind)=>{
                    if (ind === Number(this.radio)) {
                        onOff = true;
                        this.$emit("info",item);
                        this.addSystemInfoVisible = false;
                    }
                });
                if (!onOff) {
                    this.$message.error("请选择一条用户信息！")
                }
            }else {
                this.$message.error("请选择一条用户信息！")
            }
        },
        handleSearch(pageIndex){
            // if (!this.custInfo) {
            //     this.$message.error("请输入姓名！")
            //     return
            // }
            this.pageIndex = pageIndex || this.pageIndex;
            this.radio = -1;
            let params = {
                custName:this.custInfo,
                pageIndex: this.pageIndex,
            };
            InterfaceService.addHrSystemInfo(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        this.custList=res.custList || [];
                        this.custList.forEach(item=>{
                            Object.keys(item).map(key => {
                                if (item[key] == "null") {
                                    item[key] = null
                                }
                            });
                        })
                        this.total = res.totalCount || 0;
                        this.pageSize = res.pageSize || 0
                    } else {
                        this.$message.error(res.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
    .dialog {
        line-height: 25px;
    }
    .content{
        margin-top: 20px;
        text-align: left;
        border: 1px solid #dcdfe6;
        padding: 2px 20px;
        li{
            margin: 10px 0;
        }
        em{
            margin: 5px 0;
            font-size: 14px;
            padding-right: 10px;
            &:nth-of-type(1){
                display:inline-block;
                min-width: 70px;
                padding-right:0
            }
        }
        i{
            font-size: 12px;
            color: #8b8b8b;
        }

    }
    /deep/ .el-input__inner{
        height: 32px;
        line-height: 32px;
    }
    .table-pagination {
        text-align: center;
        color: #888888;
    }
    .dialog-footer{
        margin: 20px 0 0;
        text-align: center;
        /deep/ .el-button{
            width: 100px;
            margin-top: 0;
        }
    }
    /deep/ .table-pagination{
        margin: 10px 0;
    }
    .search {
        margin-left: 10px;
    }
    .product-empty {
        padding: 20px;
        text-align: center;
        line-height: 20px;
        color: #909399;
    }
</style>
