<template>
    <div>
        <!-- 添加授权人信息 -->
        <el-dialog class="dialog" title="添加授权人信息" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false">
            <div>
                <el-form ref="form" :model="form" :rules="ruleForm" label-width="120px">
                    <el-row :gutter="50">
                        <el-col :span="12">
                            <el-form-item prop="name" label="姓名：">
                                <el-input v-model="form.name" placeholder="请输入真实姓名"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item prop="certNo" label="身份证号：">
                                <el-input v-model="form.certNo" placeholder="请输入身份证号" @blur="upperCase"></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">添加并授权</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

const form = {
    acctType: "1",
    name: "",
    certType: "01",
    certNo: "",
};

export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            order: {},
            form: Object.assign({}, form),
            ruleForm: {
                name: { required: true, message: "请输入真实姓名" },
                certNo: { required: true, message: "请输入身份证号" }
            }
        };
    },
    methods: {
        open(data) {
            this.order = data;
            this.form = Object.assign({}, form);
            this.dialogVisible = true;
            this.$nextTick(() => {
                this.$refs["form"].clearValidate();
            });
        },
        handleConfirm() {
            this.$refs["form"].validate(valid => {
                if (valid) {
                    this.certify();
                }
            });
        },
        upperCase(){
            this.form.certNo = this.form.certNo.toUpperCase();
        },
        certify() {
            const params = Object.assign({}, this.form);
            InterfaceService.certifyAuthorizeAccount(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        const esignId = res.esignId;
                        this.dialogVisible = false;
                        this.$emit("close", esignId);
                    } else {
                        this.$message.error(res && res.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
</style>
