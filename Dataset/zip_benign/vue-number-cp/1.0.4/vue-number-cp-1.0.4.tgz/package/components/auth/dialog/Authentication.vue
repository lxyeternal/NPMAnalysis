<template>
    <div>
        <!-- 实名认证 填写信息 -->
        <el-dialog class="dialog" title="填写信息" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="840px" center :close-on-click-modal="false">
            <div>
                <el-form ref="form" :model="form" :rules="ruleForm" label-width="120px">
                    <el-row>
                        <el-col :span="24">
                            <el-form-item label="企业名称：">
                                <el-input :value="corpName" placeholder="请输入公司名称" disabled></el-input>
                            </el-form-item>
                        </el-col>
                    </el-row>
                    <el-col :span="12">
                        <el-form-item prop="name" label="姓名：">
                            <el-input v-model="form.name" placeholder="请输入真实姓名" disabled></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="12">
                        <el-form-item prop="certNo" label="身份证号：">
                            <el-input v-model="form.certNo" placeholder="请输入身份证号" @blur="upperCase" :disabled="!canEnterNo"></el-input>
                        </el-form-item>
                    </el-col>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确认并提交</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

const form = {
    acctType: "1",
    name: "",
    certType: "01",
    certNo: "",
    corpId: ""
};

export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            canEnterNo: false,
            signUserinfo: {},
            form: Object.assign({}, form),
            ruleForm: {
                name: { required: true, message: "请输入真实姓名" },
                certNo: { required: true, message: "请输入身份证号" }
            },
            esignId:''
        };
    },
    computed: {
        userinfo() {
            return this.$store.state.userInfo;
        },
        corpName() {
            return (
                this.$store.state.userInfo &&
                this.$store.state.userInfo.corpName
            );
        }
    },
    methods: {
        open(data) {
            this.signUserinfo = data;
            this.form = Object.assign({}, form);
            this.form.certNo = this.signUserinfo.certNo || "";
            this.canEnterNo = !this.signUserinfo.certNo;
            this.form.name = this.signUserinfo.custName || "";
            this.form.certType = this.signUserinfo.certType || "01";
            this.dialogVisible = true;
            this.$nextTick(() => {
                this.$refs["form"].clearValidate();
            });
        },
        handleConfirm() {
            this.$refs["form"].validate(valid => {
                if (valid) {
                    this.certify();
                }
            });
        },
        upperCase(){
            this.form.certNo = this.form.certNo.toUpperCase();
        },
        certify() {
            const params = Object.assign({}, this.form);
            InterfaceService.certifyAccount(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        this.esignId = res.esignId;
                        this.dialogVisible = false;
                        this.$emit("close",true,this.esignId);
                    } else {
                        this.$message.error(res && res.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
</style>
