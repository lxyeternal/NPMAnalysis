<template>
  <div class="product">
    <PanelTitle title="收货地址管理" type="primary" titleButton="添加收货地址" @handleOpen="addAddress"></PanelTitle>

    <Breadcrumb :breadcrumbList="propBreadcrumb" @refresh="$emit('refresh')"></Breadcrumb>

    <!-- 添加收货地址 -->
    <el-dialog title="添加收货地址" :visible.sync="dialogFormVisible" :close-on-click-modal="false" :close-on-press-escape="false" @close="handleClose" class="addUser">
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item label="收货人：" prop="name">
          <el-input v-model="ruleForm.name" placeholder="请填写收货人" clearable></el-input>
        </el-form-item>
        <el-form-item label="省市区：" prop="region">
          <Distpicker @receive="getAddressCode" :address="newDistpickerData"></Distpicker>
        </el-form-item>
        <el-form-item label="详细地址：" prop="addressdes" class="addressdes">
          <el-input type="textarea" v-model="ruleForm.addressdes" placeholder="请如实填写详细地址" clearable></el-input>
        </el-form-item>
        <el-form-item label="邮政编码：" prop="postcode">
          <el-input v-model="ruleForm.postcode" placeholder="请填写邮政编码" clearable></el-input>
        </el-form-item>
        <el-form-item label="手机号：" prop="mobile">
          <el-input type="text" v-model="ruleForm.mobile" placeholder="请填写手机号" clearable></el-input>
        </el-form-item>
        <el-form-item>
          <el-checkbox v-model="ruleForm.checked">设置为默认收货地址</el-checkbox>
        </el-form-item>
        <div class="tc">
          <el-button type="primary" size="small" style="width: 120px;" @click="submitForm('rules');">保存</el-button>
          <el-button size="small" style="width: 120px" @click="addCancle">取消</el-button>
        </div>
      </el-form>
    </el-dialog>
    <!-- 编辑收货地址 -->
    <el-dialog title="编辑收货地址" :visible.sync="editFormVisible" class="addUser">
      <el-form :model="editForm" :rules="editrule" ref="editForm" label-width="100px">
        <el-form-item label="收货人：" prop="name">
          <el-input v-model="editForm.name" placeholder="请填写收货人" clearable></el-input>
        </el-form-item>
        <el-form-item label="省市区：" prop="region">
          <Distpicker @receive="getAddressCode" :address="distpickerData"></Distpicker>
        </el-form-item>
        <el-form-item label="详细地址：" prop="addr" class="addressdes">
          <el-input type="textarea" v-model="editForm.addr" placeholder="请如实填写详细地址" clearable></el-input>
        </el-form-item>
        <el-form-item label="邮政编码：" prop="zipCode">
          <el-input v-model="editForm.zipCode" placeholder="请填写邮政编码" clearable></el-input>
        </el-form-item>
        <el-form-item label="手机号：" prop="mobile">
          <el-input type="number" v-model="editForm.mobile" placeholder="请填写手机号" clearable></el-input>
        </el-form-item>
        <el-form-item>
          <el-checkbox v-model="editForm.check">设置为默认收货地址</el-checkbox>
        </el-form-item>
        <div class="tc">
          <el-button type="primary" size="small" style="width: 120px;" @click="editAddress('editrule')">保存</el-button>
          <el-button size="small" style="width: 120px" @click="editCancle">取消</el-button>
        </div>
      </el-form>
    </el-dialog>

    <div class="address-table">
      <!-- 列表 -->
      <table>
        <thead>
          <tr v-if="this.addressList.length > 0">
            <td>
              <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow"></el-checkbox>
            </td>
            <td colspan="7" class="allCheck">全选 &nbsp;
              <el-button size="mini" :disabled="!hasChecked" @click="handleBatchDelDialog">批量删除</el-button>
            </td>
          </tr>
          <tr>
            <td width="6%"></td>
            <td width="15%">收货人</td>
            <td width="24%">所在区域</td>
            <td width="25%">地址</td>
            <td width="15%">手机号</td>
            <td width="15%">操作</td>
          </tr>
        </thead>

        <tbody v-if="this.addressList.length > 0">
          <tr v-for="(address,index) in addressList" :key="index">
            <td>
              <el-checkbox v-model="address.checked" @change="handleSelectTableRow(address,index)"></el-checkbox>
            </td>
            <td>
              <div class="address-name">
                <div class="right">
                  {{address.name}}
                </div>
              </div>
            </td>
            <td>{{address.provCodeDisp}} {{address.cityCodeDisp}} {{address.districtCodeDisp}}</td>
            <td>{{address.addr}}</td>
            <td>{{address.mobile}}</td>
            <td>
              <p class="text"><span @click="editAddressDialog(address)">编辑</span></p>
              <p class="text"><span @click="handleDelDialog(address)">删除</span></p>
              <p class="text default-address" v-if="address.defaultFlg == '1' ">默认地址</p>
              <p class="text" v-if="address.defaultFlg == '0' "><span @click="chengeDefaultFlg(address)">设为默认地址</span></p>
            </td>
          </tr>
        </tbody>

      </table>
      <!-- <div class="table-pagination">
        <el-pagination @current-change="handleCurrentChange" :current-page="params.pageIndex" :page-size="10" :total="total"
          layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
        </el-pagination>
      </div> -->

      <!-- 空列表 -->
      <div class="address-empty" v-if="!addressList.length && !isLoading">
        <p>暂无收货地址，请添加！</p>
      </div>
    </div>

    <!-- 收货地址超过20条 -->
    <el-dialog class="dialog" title="提示" :append-to-body="true" :lock-scroll="true" :visible.sync="moreDialogFormVisible" width="50%" center :close-on-click-modal="false">
      <div class="tc">最多可保留20条收货地址记录。
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 120px" @click="moreDialogFormVisible = false">确定</el-button>
        <el-button size="small" style="width: 120px" @click="moreDialogFormVisible = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 删除 -->
    <el-dialog class="dialog" title="确认删除" :append-to-body="true" :lock-scroll="true" :visible.sync="delDialogVisible" width="50%" center :close-on-click-modal="false">
      <div class="tc">删除该地址后不能恢复，确定要删除吗?
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 120px" @click="handleDel">确定</el-button>
        <el-button size="small" style="width: 120px" @click="delDialogVisible = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 批量删除 -->
    <el-dialog class="dialog" title="确认批量删除" :append-to-body="true" :lock-scroll="true" :visible.sync="batchDelDialogVisible" width="50%" center :close-on-click-modal="false">
      <div class="tc">您已勾选 {{checkTotal}} 个收货地址，删除地址后不能恢复，确定要删除吗?
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 120px" @click="handleBatchDel">确定</el-button>
        <el-button size="small" style="width: 120px" @click="batchDelDialogVisible = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 修改默认地址 -->
    <el-dialog class="dialog" title="提示" :append-to-body="true" :lock-scroll="true" :visible.sync="chengeDefaultAddress" width="50%" center :close-on-click-modal="false">
      <div class="tc">确定修改默认地址？
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 120px" @click="chengeDefaultAddressNew()">确定</el-button>
        <el-button size="small" style="width: 120px" @click="chengeDefaultAddress = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {
  InterfaceService
} from "@/services/api";
import PanelTitle from "@/components/base/PanelTitle";
import Distpicker from "@/components/base/Distpicker";
import Breadcrumb from "@/components/base/Breadcrumb";

const params = {
  pageIndex: 1,
  pageSize: 10
};
export default {
  props: ['propCorpId', 'propAcctId', 'propBreadcrumb'],
  components: {
    Distpicker,
    PanelTitle,
    Breadcrumb,
  },
  data() {
    var validataMobile = (rule, value, callback) => {
      let mobileReg = /^[1][0-9]{10}$/;
      if (value === '') {
        callback(new Error('请输入手机号'));
      } else {
        if (!mobileReg.test((this.ruleForm.mobile) || (this.editForm.mobile))) {
          callback(new Error('请填写正确的手机号'));
        }
        callback();
      }
    };
    var checkdistpickerData = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入地址'));
      } else {
        callback();
      }
    };
    return {
      params: Object.assign({}, params),
      form: {},
      allChecked: false,
      hasChecked: false,
      addressList: [],
      total: 0,
      checkTotal: 0,
      isLoading: false,
      dialogFormVisible: false,
      moreDialogFormVisible: false,
      editFormVisible: false,
      formLabelWidth: '120px',
      defaultFlg: '0',
      delDialogVisible: false,
      batchDelDialogVisible: false,
      chengeDefaultAddress: false,
      chengeDefaultAddressId: '',
      selectAddress: "",
      pageNum: 1,
      pageSize: 10,
      distpickerData: {},
      newDistpickerData: {},
      ruleForm: {
        name: '',
        postcode: '',
        addressdes: '',
        mobile: '',
        region: '',
        checked: false
      },
      rules: {
        name: [{
          required: true,
          message: '请填写收货人',
          trigger: 'blur'
        },
        { max: 60, message: "收货人姓名不得大于60个字", trigger: "blur" }
        ],
        region: [{
          required: true,
          message: '请选择地址信息',
          trigger: 'change'
        }],
        addressdes: [{
          required: true,
          message: '请填写详细地址',
          trigger: 'blur'
        },
        { max: 200, message: "详细地址不得大于200个字", trigger: "blur" }
        ],
        postcode: [{
          required: true,
          min: 6,
          max: 6,
          message: '请填写正确的邮政编码',
          trigger: ['change', 'blur']
        }],
        mobile: [
          {
            required: true,
            message: '请填写手机号',
            trigger: 'blur'
          },
          {
            validator: validataMobile,
            trigger: 'blur'
          }]
      },
      editForm: {},
      editrule: {
        name: [{
          required: true,
          message: '请填写收货人',
          trigger: 'blur'
        },
        { max: 60, message: "收货人姓名不得大于60个字", trigger: "blur" }
        ],
        region: [{
          required: true,
          message: '请选择地址信息',
          trigger: 'change'
        }],
        distpickerData: [{
          // required: true,
          validator: checkdistpickerData,
          trigger: 'blur'
        }],
        addr: [{
          required: true,
          message: '请填写详细地址',
          trigger: 'blur'
        },
        { max: 200, message: "详细地址不得大于200个字", trigger: "blur" }
        ],
        zipCode: [{
          required: true,
          min: 6,
          max: 6,
          message: '请填写正确的邮政编码',
          trigger: 'change'
        }],
        mobile: [
          {
            required: true,
            message: '请填写手机号',
            trigger: 'blur'
          },
          {
            validator: validataMobile,
            trigger: 'blur'
          }]
      },
      editFormItem: {}
    };
  },
  methods: {
    // 跳转
    handleCurrentChange() {
      // this.form.pageNum = page;
      // this.getAddressList();
    },
    handleClose(key, keyPath) {
      // console.log(key, keyPath);
      this.dialogFormVisible = false;
      this.ruleForm.checked = false;
      this.newDistpickerData = {};
      console.log(this.$refs.ruleForm);
      this.$refs.ruleForm.resetFields();
    },
    addCancle() {
      this.ruleForm.checked = false
      this.dialogFormVisible = false;
      this.$refs.ruleForm.resetFields();
    },
    editCancle() {
      this.editFormVisible = false;
    },

    // 添加收货地址
    addAddress() {
      if (this.addressList.length < 20) {
        this.dialogFormVisible = true;
        this.newDistpickerData = {
          provCode: '',
          cityCode: '',
          blockCode: ''
        }
        this.$nextTick(() => {
          this.$refs.ruleForm.resetFields();
        })
      } else {
        this.moreDialogFormVisible = true;
      }
    },

    //全选
    handleAllSelectTableRow(bool) {
      let arr = [];
      arr = [].concat(this.addressList);
      arr.forEach(item => {
        item.checked = bool;
      });
      this.addressList = arr;
      this.checkBatch();
    },
    // 是否全选
    checkAllSelect() {
      this.allChecked = this.addressList.every(item => {
        return item.checked;
      });
    },
    // 选中行
    handleSelectTableRow(address, index) {
      this.$set(this.addressList, index, address);
      this.checkBatch();
      this.checkAllSelect();
    },
    // 是否可批量
    checkBatch() {
      this.hasChecked = this.addressList.some(item => {
        return item.checked;
      });
    },

    // 批量删除弹窗
    handleBatchDelDialog() {
      let addressdes = []
      this.addressList.forEach(item => {
        if (item.checked) {
          addressdes.push(item)
        }
        this.checkTotal = addressdes.length;
      });
      this.batchDelDialogVisible = true;
    },
    // 批量删除
    handleBatchDel() {
      this.deleteAddress();
      this.batchDelDialogVisible = false;
    },
    // 删除弹窗
    handleDelDialog(address) {
      this.delDialogVisible = true;
      this.selectAddress = address;
    },
    // 删除
    handleDel() {
      this.deleteAddress(this.selectAddress.addressId);
      this.delDialogVisible = false;
    },

    // 编辑
    editAddressDialog(editAddress) {
      this.editFormItem = {}
      this.editFormItem.provinceCode = editAddress.provCode || ''
      this.editFormItem.cityCode = editAddress.cityCode || ''
      this.editFormItem.blockCode = editAddress.districtCode || ''
      this.editFormVisible = true;
      this.$nextTick(() => {
        this.$refs.editForm.clearValidate()
      })
      this.editForm = Object.assign({}, editAddress);
      console.log(this.editForm)
      if (editAddress.defaultFlg == 1) {
        this.$set(this.editForm, 'check', true)
      } else {
        this.$set(this.editForm, 'check', false)
      }
      this.editForm.region = {};
      this.editForm.region.provinceCode = editAddress.provCode || ''
      this.editForm.region.cityCode = editAddress.cityCode || ''
      this.editForm.region.blockCode = editAddress.districtCode || ''
      this.distpickerData = {
        provCode: editAddress.provCode,
        cityCode: editAddress.cityCode,
        blockCode: editAddress.districtCode
      }
    },

    // 修改默认地址弹框
    chengeDefaultFlg(address) {
      this.chengeDefaultAddress = true;
      this.chengeDefaultAddressId = address;
    },

    init() {
      this.getAddressList();
    },
    getAddressCode(res) {
      console.log(res)
      // console.log(this.editForm.region)
      this.ruleForm.region = res;
      // this.editForm.region = {};
      // this.ruleForm.region = {};
      // this.ruleForm.region.provinceCode = res.provinceCode;
      // this.ruleForm.region.cityCode = res.cityCode;
      // this.ruleForm.region.blockCode = res.blockCode;
      this.editForm.region = res;
      // this.editForm.region.provinceCode = res.provinceCode;
      // this.editForm.region.cityCode = res.cityCode;
      // this.editForm.region.blockCode = res.blockCode;
    },

    // 新增收货地址
    submitForm(ruleForm) {
      this.$refs.ruleForm.validate((valid) => {
        // console.log(this.ruleForm.region.sheng)
        if (valid) {
          if (!this.ruleForm.region.blockCode) {
            this.$message.error("请选择省市区")
            return
          }
          if (this.ruleForm.checked == true) {
            this.defaultFlg = '1'
          } else {
            this.defaultFlg = '0'
          }
          let params = {
            'name': this.ruleForm.name,
            'provCode': this.ruleForm.region.provinceCode,
            'cityCode': this.ruleForm.region.cityCode,
            'districtCode': this.ruleForm.region.blockCode,
            'addr': this.ruleForm.addressdes,
            'zipCode': this.ruleForm.postcode,
            'mobile': this.ruleForm.mobile,
            'defaultFlg': this.defaultFlg,
            'corpId': this.propCorpId,
          }
          console.log("新增收货地址")
          console.log(params)
          // 与后端请求
          if (this.isLoading) { return }
          InterfaceService.addReceiverAddressList(
            params,
            data => {
              console.log(data)
              if (data.respCode === "0000") {
                if (data.respData.respCode === "0000") {
                  this.ruleForm.checked = false
                  this.dialogFormVisible = false;
                  this.$refs.ruleForm.resetFields();
                  this.getAddressList();
                } else {
                  this.$message.error(data.respData && data.respData.respMsg);
                }
              } else {
                this.$message.error(data.respMsg);
              }
            },
            data => { },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            }
          );
        } else {
          console.log('error submit!!');
          // return false;
        }
      });
    },
    // 编辑收货地址
    editAddress(editrule) {
      // if (!this.editForm.region.provCode || !this.editForm.region.cityCode ||!this.editForm.region.districtCode) {
      //     this.$message.error("省市区不能为空")
      //     return
      // }
      console.log(this.editForm);
      this.$refs.editForm.validate((valid) => {
        if (valid) {
          console.log(this.editForm);
          if (!this.editForm.region.blockCode) {
            this.$message.error("请选择省市区")
            return
          }
          if (this.editForm.check == true) {
            this.editForm.defaultFlg = '1'
            console.log("true")
          } else {
            this.editForm.defaultFlg = '0'
            console.log("false")
          }
          let params = {
            'addressId': this.editForm.addressId,
            'name': this.editForm.name,
            'provCode': this.editForm.region.provinceCode || this.editFormItem.provinceCode,
            'cityCode': this.editForm.region.cityCode || this.editFormItem.cityCode,
            'districtCode': this.editForm.region.blockCode || this.editFormItem.blockCode,
            'addr': this.editForm.addr,
            'zipCode': this.editForm.zipCode,
            'mobile': this.editForm.mobile,
            'defaultFlg': this.editForm.defaultFlg,
            'corpId': this.propCorpId,
          }
          console.log("编辑")
          console.log(params)
          InterfaceService.editReceiverAddressList(
            params,
            data => {
              if (data.respCode === "0000") {
                if (data.respData.respCode === '0000') {
                  this.editFormVisible = false;
                  this.getAddressList();
                  this.$message.success('修改成功!');
                } else {
                  this.$message.error(data.respData.respMsg);
                }
              } else {
                this.$message.error(data.respMsg);
              }
            },
            data => { },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            }
          );
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    // 删除收货地址
    deleteAddress(id) {
      let addressIds = [];
      if (id) {
        addressIds.push({
          addressId: id
        });
      } else {
        this.addressList.forEach(item => {
          if (item.checked) {
            addressIds.push({
              addressId: item.addressId
            });
          }
        });
      }
      const params = {
        addressList: addressIds,
        corpId: this.propCorpId
      };
      console.log(params)

      InterfaceService.deleteReceiverAddressList(
        params,
        data => {
          console.log(data)
          if (data.respCode === "0000") {
            this.getAddressList();
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    // 修改默认地址
    chengeDefaultAddressNew() {
      let params = {
        'addressId': this.chengeDefaultAddressId.addressId,
      }
      params.corpId = this.propCorpId
      console.log("params")
      console.log(params)
      InterfaceService.chengeDefaultAddress(
        params,
        data => {
          console.log(data)
          if (data.respCode === "0000") {
            if (data.respData && data.respData.respCode === "0000") {
              this.chengeDefaultAddress = false
              this.getAddressList();
            } else {
              this.$message.error(data.respData && data.respData.respMsg);
            }
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    // 收货地址列表
    getAddressList() {
      const params = Object.assign({}, this.params);
      params.corpId = this.propCorpId
      InterfaceService.getReceiverAddressList(
        params,
        data => {
          //console.log(data)
          if (data.respCode === "0000") {
            this.addressList = data.respData.shippingAddress || [];
            this.total = this.addressList.length;
            this.addressList.forEach(item => {
              item.checked = false;
            });
            this.allChecked = false;
            this.hasChecked = false;
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    }
  },
  mounted() {
    this.init();
  }
};
</script>

<style lang="scss" scoped>
/deep/ .el-checkbox__input.is-checked + .el-checkbox__label {
  color: #444444;
}
.product {
  font-size: 14px;
}

.nowrap {
  white-space: nowrap;
}

.header {
  margin-bottom: 20px;
  background: #f5f5f5;
}

.header ul {
  width: 100%;
  height: 48px;
  border-bottom: 3px solid #ffd64e;
  font-weight: bold;

  .add {
    float: right;
    padding: 10px;
    margin: 6px;
  }

  li {
    width: 110px;
    height: 48px;
    line-height: 48px;
    text-align: center;
    float: left;
    cursor: pointer;
    position: relative;

    &:after {
      display: none;
      position: absolute;
      bottom: 0px;
      left: 0;
      content: "";
      width: 110px;
      height: 3px;
      background: #4f525a;
    }

    &.active:after {
      display: block;
    }
  }
}

.addUser {
  /deep/ .el-dialog {
    width: 840px;
  }

  /deep/ .el-dialog__title {
    font-size: 14px;
  }
  /deep/ .el-form {
    font-size: 12px;
  }
  /deep/ .el-input {
    width: 200px;
  }
  /deep/ .el-textarea {
    width: 627px;
  }
  .linkage /deep/ .el-select {
    width: 30%;
  }
  /deep/ .el-form-item__label {
    font-size: 12px;
    &:before {
      margin-top: 4px;
      margin-left: -8px;
      position: absolute;
    }
  }
  /deep/ .el-button--primary {
    margin-left: 30px;
  }
  /deep/ .addressdes {
    .el-textarea__inner {
      overflow: hidden !important;
    }
  }
}

.address-table {
  /deep/ .el-table__body-wrapper {
    font-size: 12px;
  }

  /deep/ .el-table th,
  .el-table td {
    padding: 14px 0;
  }

  table {
    width: 100%;
    line-height: 23px;

    .allCheck {
      text-align: left !important;
    }

    td {
      padding: 13px 10px;
      text-align: left;
      vertical-align: middle;
      word-break: break-all;
    }

    thead {
      font-size: 14px;
      text-align: left;
      white-space: nowrap;
      border-bottom: 1px solid #eee;
      background: #f9f9f9;
      color: #888;
      tr {
        td {
          &:last-child {
            text-align: right;
          }
        }
      }
    }

    tbody {
      tr:hover {
        background: #f0f8ff;
      }

      td {
        padding: 16px 10px;
        font-size: 12px;
        border-bottom: 1px solid #eee;
        &:last-child {
          text-align: right;
          p {
            span {
              color: #0082ff;
              cursor: pointer;
            }
          }
        }
      }
    }
  }

  .address-name {
    line-height: 20px;

    img {
      width: 75px;
      height: 75px;
    }

    .left {
      margin-right: 10px;
    }

    .right {
      p:first-child {
        margin-bottom: 10px;
      }
      p:last-child {
        color: #969799;
      }
    }
  }
}

.table-pagination {
  margin: 50px 0 80px;
  text-align: center;
  color: #888888;
}

.address-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}

.default-address {
  color: #888888;
}
/deep/ .el-dialog__title {
  font-size: 14px;
}
/deep/ .el-dialog--center .el-dialog__body {
  font-size: 12px;
}
</style>