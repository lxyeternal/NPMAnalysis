<template>
  <div>
    <div class="approval-info" v-if="adminInfo.approveStatus !== 'approved' ">
      <p v-if="adminInfo.approveStatus === 'submited'">审核状态：待材料公司审核</p>
      <template v-if="adminInfo.approveStatus === 'rejected'">
        <p style="margin-bottom: 10px;">审核状态：材料公司已拒绝</p>
        <p>拒绝原因：{{submitAdminInfo.approveMsg}}</p>
      </template>
    </div>
    <div class="info-title">
      原管理员信息
    </div>
    <ul class="company-top">
      <li class="clearfloat">
        <div class="company-left">
          <span>姓名：</span>
          <div class="company-showtext">{{adminInfo.name || "无"}}</div>
        </div>
        <div class="company-left">
          <div class="company-left" style="width: auto;height: 26px;">
            <span>授权书：</span>
            <div class="company-showtext a-text" :title="adminInfo.authorizationName">{{adminInfo.authorizationName}}</div> <i style="padding-left: 10px;" class="fr hand blue" @click="handleOpenAuthorization(adminInfo.authorizationUrl)">查看</i>
          </div>
        </div>
      </li>
    </ul>
    <div class="info-title">
      变更管理员
    </div>
    <div class="change-content">
      <el-form v-if="adminInfo.approveStatus !== 'submited'" ref="form" :model="form" label-width="108px">
        <el-form-item label="姓名：" prop="acctId" :rules="{ required:'true',message: '请选择新管理员姓名'}">
          <el-select clearable v-model="form.acctId" placeholder="请选择新管理员姓名" @change="handleChangeAcctName">
            <el-option v-for="(item,index) in acctList" :label="item.acctName" :value="item.acctId" :key="index"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="角色：">
          <div v-if="newAdminRoles.length">{{newAdminRoles.join("，")}}</div>
          <div v-else>{{form.acctId ? "无" : ""}}</div>
        </el-form-item>
        <el-form-item label="变更理由：" :rules="{ required:'true',message: '请填写变更理由'}" prop="approveMsg">
          <el-input type="textarea" v-model="form.approveMsg" :rows="4" placeholder="请填写变更理由..." maxlength="200" show-word-limit />
        </el-form-item>
        <el-form-item label="上传授权书：" :rules="{ required:'true',message: '请上传授权书'}" class="authorization" prop="attachUrl">
          <el-col :span="20">
            <ul class="neet-upload-upfile" :class="{isie:isIE11}">
              <li>
                <p class="input-file-p" :style="{height:isIE10?'38px':'40px'}">
                  <span class="gray">
                    请上传授权书
                  </span>
                </p>
              </li>
              <li>
                <div class="upfile-container">
                  <div class="center">
                    <label class="blue">
                      <UpfileComponent ref="upfileRef" :immediateClearList="true" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :btnName="'选择文件'" :dirName="`${new Date().getTime()}/`" :type="'13'" :fileTypes="uploadFileSuffix" :id="'123'" @outputList="handleUpFileResult($event)"></UpfileComponent>
                    </label>
                  </div>
                </div>
              </li>
            </ul>
          </el-col>
          <el-col :span="4">
            <el-button size="small" style="height: 40px;width: 120px;margin-left:20px;" @click="handleDownTemp">下载模板</el-button>
          </el-col>
        </el-form-item>
      </el-form>
      <div v-if="adminInfo.approveStatus !== 'submited'" class="upload-cont">
        <div>
          <div class="upload-title">
            <span>
              已上传文本
            </span>
            <span>
              上传时间
            </span>
            <span>
              操作
            </span>
          </div>
          <div class="upload-title tl" v-if="authorizationInfo.attachName">
            <span :title="authorizationInfo.attachName">
              <em :class="{blue:showFile, hand:showFile}" @click="handleOpenAuthorization(authorizationInfo.attachUrl)">{{authorizationInfo.attachName}}</em>
            </span>
            <span>
              {{authorizationInfo.creTm}}
            </span>
            <span>
              <i class="hand blue" @click="delFileInfo">删除</i>
            </span>
          </div>
        </div>
      </div>
      <template v-else>
        <ul class="company-top">
          <li class="clearfloat">
            <div class="company-left">
              <span style="width: 72px;">姓名：</span>
              <div class="company-showtext">{{submitAdminInfo.name}}</div>
            </div>
          </li>
          <li>
            <div>
              <span style="text-align:right;display: inline-block;width: 72px;color: #888;">角色：</span>
              <div class="company-showtext">{{newAdminRoles.join("，") || "无"}}</div>
            </div>
          </li>
          <li>
            <div>
              <span class="fl" style="text-align:right;display: inline-block;width: 72px;color: #888;">变更理由：</span>
              <div style="display: inline-block;width: 948px;">{{submitAdminInfo.approveMsg}}</div>
            </div>
          </li>
        </ul>
        <div class="upload-cont submited">
          <span class="fl" style="width: 72px;color: #888;">上传授权书：</span>
          <div style="display: inline-block;width: 948px;">
            <div class="upload-title">
              <span>
                已上传文本
              </span>
              <span>
                上传时间
              </span>
              <span>
                &nbsp;
              </span>
            </div>
            <div class="upload-title tl" v-if="authorizationInfo.attachName">
              <span>
                <em :title="authorizationInfo.attachName" class="hand blue" @click="handleOpenAuthorization(authorizationInfo.attachUrl)">{{authorizationInfo.attachName}}</em>
              </span>
              <span>
                {{authorizationInfo.creTm.substring(0,19)}}
              </span>
              <span>
                &nbsp;
              </span>
            </div>
          </div>
        </div>
      </template>
      <el-row style="margin-top: 60px;" v-if="adminInfo.approveStatus !== 'submited'">
        <el-col :span="24" class="tc">
          <el-button class="normal-btn" type="primary" @click="handleSubmit">{{adminInfo.approveStatus === 'rejected' ? "重新申请":"提交"}}</el-button>
          <el-button class="normal-btn" @click="handleCancel">取消</el-button>
        </el-col>
      </el-row>
      <el-row style="margin-top: 60px;" v-else>
        <el-col :span="24" class="tc">
          <el-button class="normal-btn" @click="handleCancel">返回</el-button>
        </el-col>
      </el-row>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { viewFile } from '@/utils/orderUtil';
import { InterfaceService } from '@/services/api'
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import { DateUtil } from '@/utils/dateUtil';
import Loading from '@/components/base/Loading'

const form = {
  acctId: "",
  approveMsg: "",
  attachUrl: "",
};
export default {
  name: "ChangeAdmin",
  props: ['adminInfo', 'approveId'],
  components: {
    UpfileComponent,
    Loading,
  },
  data() {
    return {
      acctList: [],
      newAdminRoles: [],
      uploadFileSuffix: "",
      isLoading: false,
      templateFileUrl: "",
      authorizationInfo: {},
      submitAdminInfo: {},
      delId: "",
      templateFileName: "",
      form: Object.assign({}, form)
    }
  },
  watch: {
    approveId: {
      handler(newName, oldName) {
        console.log(this.adminInfo.approveStatus);
        this.getSubordinateData()
      },
    }
  },
  computed: {
    isIE11() {
      let userAgent = navigator.userAgent;
      return userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; // ie11<11
    },
    isIE10() {
      return window.navigator.userAgent.indexOf('MSIE') >= 1
    },
    showFile() {
      return this.authorizationInfo && this.authorizationInfo.attachUrl && (this.authorizationInfo.attachUrl.indexOf("http://") != -1 || this.authorizationInfo.attachUrl.indexOf("https://") != -1)
    },
    userInfo() {
      return this.$store.state.userInfo
    }
  },
  methods: {
    // 查询公司下属账户信息
    getSubordinateData() {
      InterfaceService.getQuerySubordinate({}, (data) => {
        if (data.respCode === "0000") {
          let list = data.respData.acctList || [];
          this.acctList = [];
          list.forEach(item => {
            if (item.acctStatus == "0") {
              if (item.acctId != this.adminInfo.acctId) {
                this.acctList.push(item)
              }
            }
          });
          if (this.adminInfo.approveStatus !== 'approved') {
            this.getAdminCompanyInfo()
          }
        } else {
          this.$message.error(data.respMsg);
        }
      },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        });
    },
    handleChangeAcctName() {
      this.acctList.forEach(item => {
        if (item.acctId == this.form.acctId) {
          this.newAdminRoles = [];
          if (item.roleIds && item.roleIds.length) {
            item.roleIds.forEach(_item => {
              this.newAdminRoles.push(_item.roleName)
            })
          }
        }
      })
    },
    handleOpenAuthorization(url) {
      if (url.indexOf("http://") != -1 || url.indexOf("https://") != -1) {
        if (url) {
          viewFile(url)
        } else {
          this.$message.error("暂无预览地址")
        }
      }

    },
    handleUpFileResult(e) {
      this.delFileInfo()
      const { file, name, targetValue, url } = e[0]
      this.authorizationInfo = {
        file: file,
        attachName: name,
        creTm: DateUtil.dateToString(),
        targetValue,
        attachUrl: url,
      };
      this.form.attachUrl = this.authorizationInfo.attachUrl || "";
    },
    handleDownTemp() {
      this.$download([{
        name: this.templateFileName || '',
        url: this.templateFileUrl || ''
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    delFileInfo() {
      if (this.authorizationInfo.id) {
        this.delId = this.authorizationInfo.id;
      }
      this.authorizationInfo = {};
      this.form.attachUrl = ''
    },
    getOrderConfiguration() {
      const params = {
        businessType: 'AUTHORIZATION'
      };
      InterfaceService.getOrderConfiguration(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let list = res.uploadFileList || [];
          list.forEach(item => {
            if (item.fileTypeId === "regist_authorization") {
              this.templateFileUrl = item.attachUrl || "";
              this.templateFileName = item.templateFileName || "";
              this.uploadFileSuffix = item.uploadFileSuffix || "";
            }
          })
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    handleSubmit() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          let params = {
            acctId: this.form.acctId,
            approveDefId: "ADMIN_UPDATE_APPROVE",
            approveMsg: this.form.approveMsg,
            approveId: this.adminInfo.approveId,
            approveType: "apply",
            approveAttachList: [{
              attachType: "2",
              attachName: this.authorizationInfo.attachName,
              attachUrl: this.form.attachUrl,
            }],
          };
          console.log(params, '--params');

          InterfaceService.adminChange(params, data => {
            let res = data.respData;
            if (res.respCode === "0000") {
              if (this.userInfo.corpTags &&  this.userInfo.corpTags.length) {
                this.$message.success("提交成功，请等待审核！");
              }else {
                this.$message.success("变更成功！");
                let adminRoles = ['2000', '3000', '4000', '5000', '9000'];
                // return this.userInfo.roleIds && this.userInfo.roleIds.some(item => {
                //   return adminRoles && adminRoles.indexOf(item.roleId) != -1
                // });
                this.userInfo.roleIds.forEach((item,index)=>{
                  if (adminRoles.indexOf(item.roleId) != -1) {
                    this.userInfo.roleIds.splice(index)
                  }
                });
                this.$setRootScope('user', JSON.stringify(this.userInfo))
                this.$setRootLocalStorage('user', JSON.stringify(this.userInfo))
                console.log(this.userInfo);
              }
              this.$emit("refresh", true)
            } else {
              this.$message.error(data.respMsg);
            }
          }, data => { }, () => {
            this.isLoading = true;
          }, () => {
            this.isLoading = false;
          })
        }
      })
    },
    handleCancel() {
      if (this.form.attachUrl) {
        this.$confirm(
          `您确定取消变更管理员吗？取消后系统将不会保存已选择的文件。`,
          "确认取消",
          {
            cancelButtonClass: "btn-custom-cancel width-auto",
            confirmButtonClass: "btn-custom-confirm width-auto",
            confirmButtonText: "确定",
            cancelButtonText: "取消",
            dangerouslyUseHTMLString: true,
            center: true,
          }).then(() => {
            this.$emit("refresh")
          }).catch(() => {
          });
      } else {
        this.$emit("refresh")
      }
    },
    getAdminCompanyInfo() {
      let param = {
        approveId: this.adminInfo.approveId
      };
      InterfaceService.getAdminCompanyInfo(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.submitAdminInfo = data.respData || {};
          if (this.submitAdminInfo.roleList && this.submitAdminInfo.roleList.length) {
            this.submitAdminInfo.roleList.forEach(_item => {
              this.newAdminRoles.push(_item.roleName)
            });
          }
          if (this.submitAdminInfo.approveAttachList && this.submitAdminInfo.approveAttachList.length) {
            this.submitAdminInfo.approveAttachList.forEach(_item => {
              if (this.adminInfo.approveStatus !== 'submited') {
                this.form.attachUrl = _item.attachContent;
              }
              this.authorizationInfo.creTm = _item.attachCreTm;
              this.authorizationInfo.attachName = _item.attachName;
              this.authorizationInfo.attachUrl = _item.attachUrl;
            });
            console.log(this.authorizationInfo);
            console.log(this.form.attachUrl);
          }
          if (this.acctList && this.acctList.length) {
            this.acctList.forEach(item => {
              if (item.acctId === this.submitAdminInfo.acctId) {
                this.form.acctId = this.submitAdminInfo.acctId
              }
            })
          }
          if (this.submitAdminInfo.applyFlowList && this.submitAdminInfo.applyFlowList.length) {
            this.submitAdminInfo.applyFlowList.some(_item => {
              if (this.adminInfo.approveStatus === 'submited') {
                if (_item.operType == "apply") {
                  this.submitAdminInfo.approveMsg = _item.approveMsg;
                  return true
                }
              } else {
                if (_item.operType == "reject") {
                  this.submitAdminInfo.approveMsg = _item.approveMsg;
                  return true
                }
              }
            });
            this.submitAdminInfo.applyFlowList.some(_item => {
              if (_item.operType == "apply") {
                this.form.approveMsg = _item.approveMsg;
                return true
              }
            });
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  },
  mounted() {
    console.log(this.adminInfo, '--adminInfo');

    this.getSubordinateData();
    this.getOrderConfiguration();

  },
}
</script>

<style scoped lang="scss">
.approval-info {
  width: 100%;
  border: 1px solid #d7b064;
  margin-bottom: 20px;
  vertical-align: middle;
  font-size: 14px;
  padding: 20px;
}
.info-title {
  margin: 5px 0;
  margin-bottom: 20px;
  padding: 0 10px;
  font-size: 14px;
  border-left: 3px solid #000;
  line-height: 12px;
}
.company-top {
  margin-bottom: 20px;
}
.authorization {
  margin-bottom: 0 !important;
}
.neet-upload-upfile {
  box-sizing: border-box;
  display: flex;
  border-top: 1px solid transparent;

  &.disabled {
    /deep/ .center .blue {
      // background: #dddddd !important;
      // color: #a9a9a9 !important;
    }
  }

  & > li {
    width: 85%;

    &:nth-child(1) {
      .input-file-p {
        border: 1px solid #dcdfe6;
        box-sizing: border-box;
        padding: 0 12px;
        color: #606266;
        display: block;
        display: flex;
        flex-wrap: wrap;
        height: 38px;

        span {
          height: 38px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        & > .gray {
          color: #c0c4cc;
          font-size: 12px;
          outline: none;
          height: 38px;
        }

        .el-tag {
          margin: 4px;
          height: 30px;
        }
      }
    }

    &:nth-child(2) {
      width: 15%;
    }

    &:nth-child(3) {
      width: 33%;
    }

    .el-button--default {
      height: 40px;
      margin-left: 4px;
    }
  }

  .el-button--primary {
    width: 119px;
    margin-right: 12px;
  }

  /deep/ .upfile-container {
    .center {
      label {
        width: 120px;
        background: linear-gradient(
          120deg,
          rgba(215, 176, 100, 1) 0%,
          rgba(236, 206, 139, 1) 100%
        );
        color: #fff !important;
        text-align: center;
        height: 40px;
      }
    }
  }
}
.upload-cont {
  width: 910px;
  margin-left: 108px;
  margin-top: 20px;
}
.submited {
  width: 100%;
  margin-left: 0;
  margin-top: -15px;
}
.upload-title {
  background: #f5f5f5;
  border-bottom: 1px solid #fff;
  height: 35px;
  line-height: 35px;

  span {
    display: inline-block;
    padding-left: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  & span:nth-child(1) {
    width: 65%;
  }
  & span:nth-child(2) {
    width: 25%;
  }
}
.company-left {
  width: 100%;
}
.company-top li .company-showtext {
  width: 270px;
  display: inline-block;
}
.a-text {
  display: inline-block;
  width: auto !important;
  max-width: 254px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
</style>