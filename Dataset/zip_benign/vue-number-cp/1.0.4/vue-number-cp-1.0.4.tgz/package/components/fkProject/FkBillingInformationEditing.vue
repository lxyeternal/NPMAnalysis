<template>
  <div class="billing-information-editing">
    <div class="purchaser-company-information">
      <millingInformationCompontent :width="'1020px'" v-if="isShowCom" :taxClassifyList.sync="taxClassifyItem.taxClassifyList" :invoiceType.sync="taxClassifyItem.invoiceType"></millingInformationCompontent>
      <template v-if="role === 'B'">
       <el-form ref="formAddrZ" :model="formAddrZ" :rules="rules" label-width="108px" style="margin-top: 30px">
        <div class="form-inline-item-dispickter">
          <el-form-item label="开票地址：">
            <Distpicker :address="initOfficeInfo" @receive="getOfficeAddressCode"></Distpicker>
            <div class="el-form-item__error" v-if="!officeSelectedFlg">
              必填
            </div>
          </el-form-item>
        </div>
        <div class="form-inline-item address-input">
          <el-form-item label=" " prop="officeDetailAddr">
            <el-input v-model="formAddrZ.officeDetailAddr" placeholder="请填写地址" @focus="blurCheckForm('officeDetailAddr')" @blur="blurCheckForm('officeZipCode')"></el-input>
            <div class="el-form-item__error" v-if="errorRules['officeDetailAddr']">
              {{ errorRules["officeDetailAddr"] }}
            </div>
          </el-form-item>
        </div>
        <div class="form-inline-item">
          <el-form-item label="邮编：" prop="officeZipCode">
            <el-input v-model="formAddrZ.officeZipCode" placeholder="" @focus="blurCheckForm('officeZipCode')" @blur="blurCheckForm('officeZipCode')"></el-input>
            <div class="el-form-item__error" v-if="errorRules['officeZipCode']">
              {{ errorRules["officeZipCode"] }}
            </div>
          </el-form-item>
        </div>
        <div class="form-inline-item">
          <el-form-item label="电话号码：" prop="officeTelNumber">
            <el-input v-model="formAddrZ.officeTelNumber" placeholder="" @focus="blurCheckForm('officeTelNumber')" @blur="blurCheckForm('officeTelNumber')"></el-input>
            <div class="el-form-item__error" v-if="errorRules['officeTelNumber']">
              {{ errorRules["officeTelNumber"] }}
            </div>
          </el-form-item>
          <el-form-item label="传真号码：" prop="officeFaxNumber">
            <el-input v-model="formAddrZ.officeFaxNumber" placeholder="" @focus="blurCheckForm('officeFaxNumber')" @blur="blurCheckForm('officeFaxNumber')" maxlength="64"></el-input>
            <div class="el-form-item__error" v-if="errorRules['officeFaxNumber']">
              {{ errorRules["officeFaxNumber"] }}
            </div>
          </el-form-item>
        </div>
      </el-form>
      </template>
      <div class="btn-container">
        <el-button size="small" style="width: 120px;" type="primary" @click="invoiceTypeSubmit">保存</el-button>
        <el-button size="small" style="width: 120px;" @click="invoiceTypeCancel">取消</el-button>
      </div>
      <Loading :is-loading="isLoading"></Loading>
    </div>
  </div>
</template>

<script>
import Loading from '@/components/base/Loading'
import PanelTitle from "@/components/base/PanelTitle";
import { InterfaceService } from '@/services/api'
import accountMixin from "@/mixins/account";
import UsersManage from "@/components/company/CompanyMessage";
import millingInformationCompontent from "@/components/order/millingInformationCompontent";
import Distpicker from "@/components/base/Distpicker";

export default {
  mixins: [accountMixin],
  components: {
    PanelTitle,
    Loading,
    millingInformationCompontent,
    Distpicker
  },
  props: ["propCorpId"],
  data() {
    const validateMobile = (rule, value, callback) => {
      const reg = new RegExp(/^[1][0-9][0-9]{9}$/);                    // 手机
      const reg1 = new RegExp(/^[\d-\s\(\)\+\,]*$/); // 座机
      if (!reg.test(value) && !reg1.test(value)) {
        return callback(new Error("联系电话格式错误，请填写手机号或座机"));
      } else {
        callback();
      }
    };
    return {
      isLoading: false,
      isShowCom: false,
      resultPath: '',
      taxClassifyItem: {
        taxClassifyList: [],
        invoiceType: []
      },
      officeSelectedFlg: true,
      formAddrZ: {},
      initOfficeInfo: {},
      errorRules: [],
      rules: {
        officeDetailAddr: [
          { required: true, message: "必填" },
          { max: 200, message: "地址不得大于200个字", trigger: "blur" }
        ],
        officeZipCode: [
          {
            required: true,
            message: "必填"
          },
          { pattern: /^\d{6}$/, message: '请输入正确的邮编', trigger: "blur" }
        ],
        officeTelNumber: [
          {
            required: true,
            message: "必填"
          },
          { validator: validateMobile, trigger: "blur" },
        ],
        officeFaxNumber: [
          { pattern: /^[0-9\-]{0,32}$/, message: '请输入正确的传真号码', trigger: "blur" },
        ],
      },
    };
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.resultPath = this.$route.query.resultPath
      this.getCompanyMessage()
    },
    getOfficeAddressCode(res) {
      this.formAddrZ.officeProvCode = res.provinceCode
      this.formAddrZ.officeCityCode = res.cityCode
      this.formAddrZ.officeDistrictCode = res.blockCode
      if (this.formAddrZ.officeDistrictCode) {
        this.officeSelectedFlg = true
      }
    },
    blurCheckForm(key) {
      if (this.formAddrZ[key]) {
        delete this.errorRules[key]
      }
    },
    invoiceTypeSubmit() {
      const { invoiceType, taxClassifyList } = this.taxClassifyItem

      if (!(invoiceType && invoiceType.length)) {
        this.$message.error('请选择发票类型')
        return
      }
      if (!(taxClassifyList && taxClassifyList.length)) {
        this.$message.error('请添加货物与应税劳务')
        return
      }
      let state = true
      if (this.role === 'S' && taxClassifyList && taxClassifyList.length) {
        taxClassifyList.forEach(f => {
          if (f.classify === '') {
            this.$message.error('请填写货物或应税劳务分类')
            state = false
          }
          if (f.tax === '' && state) {
            this.$message.error('请填写税率')
            state = false
          }
        });
      }
      if (this.role === 'B'){
        if (!this.formAddrZ.officeDistrictCode) {
          this.officeSelectedFlg = false;
          state = false
        }
      }
      
      if (!state) return
      if(this.role === 'B'){
        this.$refs.formAddrZ.validate((valid) => {
          if (valid) {
            this.$confirm(`是否确认保存?`, '保存提示', {
              cancelButtonClass: "btn-custom-cancel",
              confirmButtonClass: "btn-custom-confirm",
              center: true,
              confirmButtonText: '确定',
              cancelButtonText: '取消',
            }).then(() => {
              this.rejectUpdatePurchaser()
            })
          }
        })
      }else{
        this.$confirm(`是否确认保存?`, '保存提示', {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          confirmButtonText: '确定',
          cancelButtonText: '取消',
        }).then(() => {
          this.rejectUpdatePurchaser()
        })
      }
    },
    invoiceTypeCancel() {
      this.$emit('refresh')
    },
    rejectUpdatePurchaser() {
      const bs = this.userinfo.bs || 'B',
        corpId = this.propCorpId || this.userinfo.corpId

      let params = {
        corpId,
        invoiceType: this.taxClassifyItem.invoiceType,
      };
      if (bs) {
        params.taxClassifyList = this.taxClassifyItem.taxClassifyList
        params.taxClassifyList.forEach(f => {
          f.tax = Number(f.tax).toString()
        })
      }
      if(bs == 'B'){
        params.invoicingProvCode= this.formAddrZ.officeProvCode
        params.invoicingCityCode= this.formAddrZ.officeCityCode
        params.invoicingDistrictCode= this.formAddrZ.officeDistrictCode
        params.invoicingTelNumber= this.formAddrZ.officeTelNumber
        params.invoicingFaxNumber= this.formAddrZ.officeFaxNumber
        params.invoicingZipCode= this.formAddrZ.officeZipCode
        params.invoicingDetailAddr= this.formAddrZ.officeDetailAddr
      }
      console.log(params);
      // 判断是否供应商
      const api = this.userinfo.bs == 'B' ? 'rejectUpdatePurchaser' : 'rejectUpdateSupplier'
      InterfaceService[api](
        params,
        data => {
          let result = data.respData;
          if (result.respCode == '0000') {
            this.$message.success("保存成功！")
            this.$emit('refresh')
            this.$removeRootScope('taxClassifyItem')
          } else {
            this.$message.error(result.respMsg)
          }
        },
        data => {
          this.$message.error(data.respData.respMsg)
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    getCompanyMessage() {
      InterfaceService[this.role == "S" ? "getVendorMessage" : "getPurchaserMessage"]({
        corpId: this.propCorpId || undefined
      }, (data) => {
        if (data.respData.respCode == "0000") {
          let invoiceType = []

          const acCorpFinInfoBean = data.respData && data.respData.acCorpFinInfoBean || {}

          if (typeof acCorpFinInfoBean.invoiceType === 'string') {
            let list = acCorpFinInfoBean.invoiceType.split('/') || [];
            list.forEach(item => {
              if (item !== '') {
                invoiceType.push(item)
              }
            })
          }

          console.log(data.respData.corpTaxClassifyList, 'data.respData.corpTaxClassifyList ');

          this.taxClassifyItem = {
            taxClassifyList: [123],
            invoiceType: []
          }

          this.$set(this.taxClassifyItem, 'taxClassifyList', data.respData && data.respData.corpTaxClassifyList || [])
          this.$set(this.taxClassifyItem, 'invoiceType', invoiceType || [])

          this.isShowCom = true
          if(this.role == "B"){
            let corpAddrInfoRst = data.respData && data.respData.corpAddrInfoRst || {}
            this.initOfficeInfo = {
              provCode: corpAddrInfoRst.invoicingProvCode,
              cityCode: corpAddrInfoRst.invoicingCityCode,
              blockCode: corpAddrInfoRst.invoicingDistrictCode
            };
            this.formAddrZ = {
              officeProvCode: corpAddrInfoRst.invoicingCityCode,
              officeCityCode: corpAddrInfoRst.invoicingCityCode,
              officeDistrictCode: corpAddrInfoRst.invoicingDistrictCode,
              officeDetailAddr: corpAddrInfoRst.invoicingDetailAddr,
              officeZipCode: corpAddrInfoRst.invoicingZipCode,
              officeFaxNumber: corpAddrInfoRst.invoicingFaxNumber,
              officeTelNumber: corpAddrInfoRst.invoicingTelNumber,
            };
            
          }

          console.log(this.taxClassifyItem, '-item');

        } else {
          this.$message.error(data.respMsg)
        }
      }, (data) => {
      }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    }
  },
};
</script>

<style lang="scss" scoped>
.form-inline-item {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;

  & > div {
    width: 40%;
    flex-shrink: 0;
  }

  &.col-3 > div {
    width: 32%;
  }

  /deep/ .el-select {
    width: 100%;
  }
}
.address-input {
  .el-form-item {
    width: 100% !important;
    /deep/ .el-form-item__label:before {
      content: none !important;
    }
  }
}
.form-inline-item-dispickter {
  .el-form-item {
    /deep/ .el-form-item__label:before {
      content: "*";
      color: #f56c6c;
      margin-right: 4px;
    }
  }
}
.billing-information-editing {
  .purchaser-company-information {
    /deep/ p.bold {
      border-left: 3px solid #444;
      padding-left: 6px;
    }
  }
  .btn-container {
    margin-top: 20px;
    text-align: center;
  }
}
</style>

<style lang="scss">
.billEditCompanyDelBarandNoticeBox {
  width: 400px !important;
  .el-message-box__btns {
    display: flex;
    justify-content: center;
    .el-button--primary {
      order: -1;
      margin: 0 10px 0 0;
      background: #d7b064 linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
      color: #fff;
    }
  }
}
</style>