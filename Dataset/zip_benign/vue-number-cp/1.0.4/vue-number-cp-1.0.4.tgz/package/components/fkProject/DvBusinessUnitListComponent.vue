<template>
  <div class="project">
    <PanelTitle v-if="![3,4].includes(tab)" :title="panelTitleCp" @handleOpen="handleCreate"></PanelTitle>
    <template v-if="tab == 1">
      <!-- 材料公司  不显示 -->
      <div class="panel-content" v-if="!(brokerRole)">
        <el-form class="form" :model="form" size="small" label-width="100px">
          <el-row>
            <el-col :span="12">
              <el-form-item label="事业部：">
                <!-- 非 材料公司置灰 -->
                <el-select filterable clearable v-model="form.groupCompanyCode" :disabled="!brokerRole" placeholder="请选择所属事业部" style="width: 100%;" :filter-method="handleGetValue" @visible-change="handleSelectedValueChange">
                  <el-option label="全部" value=""></el-option>
                  <el-option v-for="item in groupCompanySelList" :label="item.value" :value="item.code" :key="item.value"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="项目名称：">
                <el-input v-model.trim="form.projectName" placeholder="请输入项目名称"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <el-row>
          <el-col :span="24" class="tc">
            <el-button style="width: 80px;" type="primary" size="small" @click="handleSearch">搜索</el-button>
            <el-button style="width: 80px;" size="small" @click="handleClear">清除</el-button>
          </el-col>
        </el-row>
      </div>
      <div class="project-table">
        <!-- 实名认证列表 -->
        <template v-if="propType == 'dvEnterpriseRealNameProjectList'">
          <table>
            <thead ref="head">
              <tr class="tl">
                <td width="140">ERP项目编号</td>
                <td width="220">项目名称</td>
                <td width="160">事业部</td>
                <td width="220">项目公司名称</td>
                <td width="100">基本户认证</td>
                <td width="100">法人认证</td>
                <td class="tr">操作</td>
              </tr>
            </thead>
            <template v-if="projectList.length">
              <tbody v-for="(pro,index) in projectList.filter(f => f.corpId)" :key="index" class="tl tbody-row">
                <tr class="tl">
                  <td>
                    <p style="margin-bottom: 5px;">
                      {{pro.erpProjectCode}}
                    </p>
                  <td>
                    <p>
                      {{pro.projectName}}
                    </p>
                  </td>
                  <td>
                    <p>
                      {{pro.groupCompanyName}}
                    </p>
                  </td>
                  <td>
                    <p>
                      {{pro.corpName}}
                    </p>
                  </td>
                  <td>
                    <p class="red" :class="{green: pro.baseBankIsCertified == '1'}">
                      {{pro.baseBankIsCertified == '1' ? '√ 已认证' : '×未认证'}}
                    </p>
                  </td>
                  <td>
                    <p class="red" :class="{green: pro.legalIsCertified == '1'}">
                      {{pro.legalIsCertified == '1' ? '√ 已认证' : '×未认证'}}
                    </p>
                  </td>
                  <td class="blue tr">
                    <p style="margin-bottom: 4px;">
                      <span class="hand" @click="handleGoDetail(pro)">查看详情</span>
                    </p>
                  </td>
                </tr>
              </tbody>
            </template>
          </table>
        </template>

        <!-- 印章列表 -->
        <template v-if="['dvReceiverAddressList', 'dvSealManagementList'].includes(propType)">
          <table>
            <thead ref="head">
              <tr class="tl">
                <td width="140">ERP项目编号</td>
                <td width="300">项目名称</td>
                <td width="160">事业部</td>
                <td width="300">项目公司名称</td>
                <td class="tr">操作</td>
              </tr>
            </thead>
            <template v-if="projectList.length">
              <tbody v-for="(pro,index) in projectList.filter(f => f.corpId)" :key="index" class="tl tbody-row">
                <tr class="tl">
                  <td>
                    <p style="margin-bottom: 5px;">
                      {{pro.erpProjectCode}}
                    </p>
                  <td>
                    <p>
                      {{pro.projectName}}
                    </p>
                  </td>
                  <td>
                    <p>
                      {{pro.groupCompanyName}}
                    </p>
                  </td>
                  <td>
                    <p>
                      {{pro.corpName}}
                    </p>
                  </td>
                  <td class="blue tr">
                    <p style="margin-bottom: 4px;">
                      <span class="hand" @click="handleGoDetail(pro)">{{propType == 'dvSealManagementList' ? '查看印章信息' : '查看收货地址'}}</span>
                    </p>
                  </td>
                </tr>
              </tbody>
            </template>
          </table>
        </template>

        <div class="table-pagination" v-if="projectList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!projectList.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关项目，请重新修改搜索条件搜索！</p>
        </div>
      </div>
    </template>

    <!-- 实名认证 -->
    <template v-if="tab == 2">
      <Breadcrumb :breadcrumbList="breadcrumb" @refresh="handleBack()"></Breadcrumb>
      <DvEnterpriseCertification :propCorpId="propCorpId" :propAcctId="propAcctId" @refresh="handleBack()"></DvEnterpriseCertification>
    </template>
    <!-- 印章管理 -->
    <template v-if="tab == 3">
      <DvSealList :propCorpId="propCorpId" :propBreadcrumb="breadcrumb" :mainText="mainText" @refresh="handleBack()" :propAcctId="propAcctId"></DvSealList>
    </template>
    <!-- 收货地址 -->
    <template v-if="tab == 4">
      <DvReceiverAddress :propCorpId="propCorpId" :propBreadcrumb="breadcrumb" @refresh="handleBack()" :propAcctId="propAcctId"></DvReceiverAddress>
    </template>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import { InterfaceService } from "@/services/api";
import Breadcrumb from "@/components/base/Breadcrumb";
import DvEnterpriseCertification from "@/components/fkProject/DvEnterpriseCertification";
import DvSealList from "@/components/fkProject/DvSealList";
import DvReceiverAddress from "@/components/fkProject/DvReceiverAddress";

const form = {
  projectGroup: "REAL",
  // pageFrom	String	N	页面来源（CORP_MANAGEMENT:公司管理）
  pageFrom: 'CORP_MANAGEMENT',
  groupCompanyCode: "",
  projectName: "",
  pageSize: 10,
};
export default {
  mixins: [accountMixin],
  // propType 判断是哪个菜单进入: dvEnterpriseRealNameProjectList - 企业实名认证
  props: ['propType'],
  components: {
    Loading,
    PanelTitle,
    Breadcrumb,
    DvEnterpriseCertification,
    DvSealList,
    DvReceiverAddress,
  },
  watch: {
    tab(newVal, oldVal) {
      console.log(newVal, oldVal, '-newVal, oldVal');

      if (this.headBreadcrumb && this.headBreadcrumb.length) {
        this.breadcrumb = [
          { name: '公司管理', path: '/purchaserCenter/ProjectCompanyManagement' },
          { name: '项目公司管理', path: '/purchaserCenter/ProjectCompanyManagement' },
          { name: this.operationType == 'create' ? (this.projectType === 'new' ? '创建项目' : '编辑项目') : (this.projectType === 'new' ? '添加新的分期' : '查看项目及分期') },
        ]
        return
      }
      if (newVal == 2) {
        this.breadcrumb = [
          { name: '管理中心', path: '/purchaserCenter/accountInfo' },
          { name: '企业实名认证列表', goBack: true },
          { name: '企业实名认证' },
        ]
      }
      if (newVal == 3) {
        this.breadcrumb = [
          { name: '管理中心', path: '/purchaserCenter/accountInfo' },
          { name: '印章管理列表', goBack: true },
          { name: '印章列表' },
        ]
      }
      if (newVal == 4) {
        this.breadcrumb = [
          { name: '管理中心', path: '/purchaserCenter/accountInfo' },
          { name: '收货地址列表', goBack: true },
          { name: '收货地址管理' },
        ]
      }
    }
  },
  data() {
    return {
      projectList: [],
      projectTypeList: [
        "办公",
        "超高层",
        "酒店",
        "商业综合体",
        "学校",
        "住宅",
        "其他",
      ],
      fkCorpId: "",
      isLoading: false,
      detailInfo: {},
      detailbaseInfo: {},
      distpickerData: {},
      searchDistpickerData: {},
      operationType: "",
      projectType: "",
      breadcrumb: [
        { name: '管理中心', path: '/purchaserCenter' },
        { name: '公司管理信息-项目列表', goBack: true },
        { name: '项目详情' },
      ],
      headBreadcrumb: [],
      form: Object.assign({}, form),
      tab: 1,
      pageSize: 10,
      total: 0,
      pageIndex: 1,
      fixedhead: false, // 是否显示固定表头
      groupCompanyList: [],
      groupCompanySelList: [],
      corpList: [],
      isShowFkSelectSupplierAgent: false,
      adminInfo: {},
      projectManager: {}, // 项目分期Item

      propCorpId: '',
      propAcctId: '',
    };
  },
  computed: {
    // 是否事业部管理员
    isDivisionAdmin() {
      return this.detailbaseInfo && this.mixinsRoleIdsAdmin(this.detailbaseInfo.corpId || '')
    },
    // 返回当前用户 持有的 权限
    mixinsRoleIdsAdmin() {
      return corpId => {
        const ids = this.roleListFilter(corpId) || []
        // 是否为管理员2000
        return ids.some(s => s.roleId == '2000')
      }
    },

    panelTitleCp() {
      let title = ''

      switch (this.propType) {
        case 'dvEnterpriseRealNameProjectList':
          title = '企业实名认证列表'
          break;
        case 'dvSealManagementList':
          title = '印章列表'
          break;
        case 'dvReceiverAddressList':
          title = '收货地址列表'
          break;

        default:
          break;
      }
      return title
    },
  },
  methods: {

    handleBack(tab) {
      this.tab = tab;
      this.getProjectList();
      this.detailInfo = {};
    },


    getPurchaserMessage() {
      let params = {
        corpId: this.detailbaseInfo.corpId
      }
      InterfaceService.getPurchaserMessage(params, (data) => {
        if (data.respData && data.respData.respCode == "0000") {
          data.respData.acCorpContactInfoList && data.respData.acCorpContactInfoList.forEach((item) => {
            if (item.contactType == '9') {
              this.adminInfo = item;
              this.adminInfo.authorizationName = this.authorizationName || "";
              this.adminInfo.authorizationUrl = this.authorizationUrl || "";
            }
          });
        } else {
          this.$message.error(data.respMsg)
        }
      }, (data) => {
      }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

    changeAdmin(bool) {
      if (bool) {
        this.tab = 2;
        window.scrollTo(0, 0)
      }
    },
    handleSelectedValueChange(bool) {
      if (bool) {
        this.groupCompanySelList = this.groupCompanyList
      }
    },
    setProManager() {
      if (this.detailbaseInfo && this.detailbaseInfo.corpId) {
        // 变更项目管理员
        if (this.detailbaseInfo.adminMobile) {
          this.tab = 10
        } else { // 设置项目管理员
          this.tab = 5
        }
      } else {
        this.$message.error('请先设置项目公司!')
      }
    },
    handleGetValue(val) {
      val = val.replace(/\s+/g, "")
      if (val) {
        this.groupCompanySelList = this.groupCompanyList.filter(item => {
          return !!~item.value.indexOf(val) || !!~item.value.toUpperCase().indexOf(val.toUpperCase())
        })
      } else {
        this.groupCompanySelList = this.groupCompanyList
      }
    },
    getRegAddressCode(res) {
      this.form.projectProvCode = res.provinceCode
      this.form.projectCityCode = res.cityCode
      this.form.projectDistrictCode = res.blockCode
    },
    handleSearch() {
      this.searchDistpickerData = {
        provCode: this.form.projectProvCode || "",
        cityCode: this.form.projectCityCode || "",
        blockCode: this.form.projectDistrictCode || ""
      };
      this.pageIndex = 1;
      this.getProjectList();
    },
    // 变更项目公司
    handleClickChangeProject() {
      // this.getPurchaserMessage()
      // this.tab = 7
    },
    // 设置项目公司
    rejectQueryPurchaser(corpId, projectId, item) {
      console.log(item, '-this.detailbaseInfo.corpId', this.detailbaseInfo);
      this.detailInfo.projectName = item && item.projectName || this.detailbaseInfo && this.detailbaseInfo.projectName || '';
      if (!corpId) {
        this.detailInfo.projectId = projectId;

        this.isShowFkSelectSupplierAgent = true
        return
      } else {
        // 查看项目公司
        this.detailInfo.fkCorpId = corpId;
        this.tab = 6
        return
      }
      const params = {
        corpId
      }
      InterfaceService.rejectQueryPurchaser(params, (data) => {
        if (data && data.respData && data.respData.respCode === "0000") {

        } else {
          this.$message.error(data.respData && data.respData.respMsg);
        }

      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      });
    },

    // 查询事业部下拉
    getListConfig() {
      const params = {
        appName: 'MEMBER',
        groupIds: ["SYB_CONFIG"],
      }
      InterfaceService.getPaymentMethod(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          const configEntityListMap = data.respData.configEntityListMap && data.respData.configEntityListMap.SYB_CONFIG || []
          this.groupCompanyList = configEntityListMap || []
          this.groupCompanySelList = configEntityListMap || []
        } else {
          this.$message.error(data.respData && data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    handleClear() {
      this.searchDistpickerData = {};
      const code = this.form.groupCompanyCode
      this.form = Object.assign({}, form)
      // 非材料公司 不清空 事业部
      if (!this.brokerRole) {
        this.form.groupCompanyCode = code
      }
      this.handleSearch()
    },
    // 分页跳转
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.getProjectList();
      window.scrollTo(0, 0)
    },
    handleClickSetProManager(item) {
      if (this.detailbaseInfo && this.detailbaseInfo.corpId) {
        this.projectManager = item
        // 有项目经理
        if (item.projectManagerName) {
          this.tab = 9
        } else {
          this.tab = 8
        }
      } else {
        this.$message.error('请先设置项目公司!')
      }
    },
    handleCreate(type, pro) {
      this.operationType = "create"
      if (type === 'edit') {
        this.projectType = ""
        this.detailInfo = {
          corpId: this.userinfo.corpId || '',
          projectId: pro.projectId || '',
          erpProjectCode: pro.erpProjectCode || '',
          projectName: pro.projectName || '',
        }
      } else {
        this.detailInfo = {
          corpId: this.userinfo.corpId || '',
        }
        this.projectType = "new"
      }
      this.distpickerData = {}
      this.tab = 3;
    },
    onScroll() {
      let scrolled = document.documentElement.scrollTop || document.body.scrollTop
      this.fixedhead = scrolled >= 250;
    },


    handleGoDetail(item) {
      // DvEnterpriseCertification
      // 实名认证
      this.propCorpId = item.corpId || ''
      this.propAcctId = item.acctId || ''
      this.mainText = item.corpName || ''
      if (this.propType == 'dvEnterpriseRealNameProjectList') {
        this.tab = 2
      }
      if (this.propType == 'dvSealManagementList') {
        this.tab = 3
      }
      if (this.propType == 'dvReceiverAddressList') {
        this.tab = 4
      }

    },
    handleCancel(type) {
      if (type === 'create') {
        this.tab = 1;
      } else {
        this.tab = 2;
      }
      console.log(this.detailInfo);
    },

    // 在线预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },

    getProjectList(init) {
      let params = {};

      params = Object.assign({}, this.form);
      params.pageIndex = this.pageIndex;

      InterfaceService.getFkProjectList(params, data => {
        if (data.respData.respCode === '0000') {
          this.projectList = data.respData.projectList || [];
          this.tab = 1;
          this.pageSize = data.respData.pageSize || 10;
          this.total = +data.respData.totalCount || 0;
          if (init) {
            this.corpList = data.respData.corpList || [];
          }
        } else {
          this.$message.error(data.respData && data.respData.respMsg || '')
        }
      }, data => {
        this.$message.error(data.respData && data.respData.respMsg || '')
      }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },
  },
  mounted() {
    const headBreadcrumb = JSON.parse(this.$getRootScope('breadcrumb') || '[]')
    this.headBreadcrumb = (headBreadcrumb && headBreadcrumb.length) && headBreadcrumb || []
    // 非材料公司 只能查询 当前所在事业部
    if (!this.brokerRole) {
      this.form.groupCompanyCode = this.groupCompanyCode
    }
    this.getListConfig()
    this.getProjectList('init')
    this.$nextTick(function () {
      setTimeout(() => {
        window.addEventListener('scroll', this.onScroll)
      }, 500)
    })
  },
  destroyed: function () {
    window.removeEventListener('scroll', this.onScroll)
    this.$removeRootScope('breadcrumb')
  }
}
</script>

<style scoped lang="scss">
.panel-content {
  margin-bottom: 20px;
  padding: 20px 10px;
  background: #f5f5f5;
}
.project {
  position: relative;
  font-size: 14px;
}
.project-table {
  margin-top: 20px;
  /deep/ .el-table th,
  .el-table td {
    padding: 14px 0;
  }
  table {
    width: 100%;
    font-size: 12px;
    table-layout: fixed;
    td {
      padding: 10px;
      vertical-align: middle;
      word-break: break-all;
      span {
        display: block;
      }
    }
    thead {
      font-size: 14px;
      white-space: nowrap;
      color: #888;
      background: #f9f9f9;
    }
    .tbody-row:hover {
      background: #f0f8ff;
    }
    tbody {
      td {
        border-bottom: 1px solid #ebeef5;
      }
    }
  }
}
.fixedhead {
  width: 1020px;
  height: 30px;
  position: fixed;
  text-align: center;
  top: 0;
  z-index: 9999;
  background: #535864;
  color: #fff;
  li {
    text-align: left;
    float: left;
    line-height: 30px;
    padding: 0 10px;
    font-size: 14px;
  }
}
.detail-content {
  margin-top: 13px;
  font-size: 12px;
  line-height: 17px;
  label {
    color: #888;
  }
  span {
    color: #444;
  }
}
/deep/ .el-row {
  margin-bottom: 10px;
}
/deep/ .panel-title {
  margin-bottom: 0 !important;
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}

.table-pagination {
  margin: 50px 0 80px;
  text-align: center;
  color: #888888;
}
/deep/ .el-button--primary {
  color: #fff;
  border: none;
  background: linear-gradient(
    120deg,
    rgba(215, 176, 100, 1) 0%,
    rgba(236, 206, 139, 1) 100%
  );
  &:hover {
    border: none;
    color: #fff;
    background: linear-gradient(
      120deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
  }
}
/deep/ .el-row {
  overflow: hidden;
}
/deep/ .el-form-item--small.el-form-item {
  margin-bottom: 20px !important;
}
.panel-content {
  /deep/ .el-row {
    overflow: hidden;
  }
  /deep/ .el-form-item--small.el-form-item {
    margin-bottom: 10px !important;
  }
}
.project-num {
  em {
    padding-left: 10px;
  }
}
.blue-pointer {
  font-size: 12px;
  font-weight: normal;
  padding-left: 6px;
}
.project-item {
  margin-bottom: 20px;
  padding-bottom: 20px;
  border-bottom: 1px solid #eee;
}
.unWeight {
  font-weight: normal;
}
.admin-attach {
  display: flex;
  & > span {
    color: #888;
    white-space: pre;
  }
}
/deep/ {
  .company-top {
    margin-top: 13px;
    font-size: 12px;
  }
  .company-top li {
    /*height: 26px;*/
    line-height: 26px;
  }
  .company-top li.changeInfo {
    height: 48px;
    line-height: 48px;
  }
  .company-top li .company-left {
    float: left;
    display: inline-block;
    width: 49%;
    /*height: 26px;*/
    line-height: 26px;
  }
  .company-top li .company-left span {
    display: inline-block;
    /*width: 172px;*/
    height: 26px;
    line-height: 26px;
    text-align: right;
    color: #888;
    vertical-align: top;
  }
  .color888 {
    color: #888;
  }
  .company-top li .company-left span em {
    color: #e93340;
  }
  .company-top li .company-showtext {
    width: 270px;
    display: inline-block;
  }
  .company-information .el-input {
    width: 270px;
    height: 26px;
  }
  .green {
    color: green;
  }
}
</style>