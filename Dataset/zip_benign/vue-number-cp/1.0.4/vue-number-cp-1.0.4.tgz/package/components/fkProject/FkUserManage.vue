<template>
  <div class="users">
    <PanelTitle :title="type == 'division' ? '用户管理' : '项目账户管理'" :titleButton="(computedIsRoleId(['1000', '9000']) || isDivisionEdit) ? '添加账户' : ''" @handleOpen="handleOpenAddForm"></PanelTitle>

    <Breadcrumb :breadcrumbList="breadcrumb" @refresh="crumbRefresh"></Breadcrumb>
    <!-- 添加用户 -->
    <el-dialog title="添加用户" :visible.sync="addFormVisible" :modal='!dialog' v-if="addFormVisible || justAdd" :before-close="handleClose" class="addUser" :close-on-click-modal="false" @close="addCancle">
      <div class="tc" style="margin-bottom: 10px;" v-if="groupCompanyCode == 'GREENLANDHK' && role == 'B'">
        添加的用户若为绿地香港正式员工，可使用
        <el-button size="small" @click="addSystemInfo">导入绿地香港用户</el-button>
      </div>

      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px">
        <el-form-item label="姓名：" prop="acctName">
          <el-input v-model="ruleForm.acctName" placeholder="请输入真实姓名" v-popover:popoverAcct clearable></el-input>

          <div class="error-msg red" v-if="errorMsg.acctName">{{errorMsg.acctName}}</div>
        </el-form-item>
        <el-form-item v-if="!justAdd" label="身份证号：" prop="certNo">
          <el-input type="text" v-model="ruleForm.certNo" placeholder="请输入身份证号" clearable @blur="upperCase('ruleForm')"></el-input>
          <div class="error-msg red" v-if="errorMsg.certNo">{{errorMsg.certNo}}</div>
        </el-form-item>
        <el-form-item label="手机号：" prop="mobile">
          <el-input type="text" v-model="ruleForm.mobile" placeholder="请输入手机号" clearable></el-input>
          <div class="error-msg red" v-if="errorMsg.mobile">{{errorMsg.mobile}}</div>
        </el-form-item>
        <el-form-item label="邮箱：" prop="email">
          <el-autocomplete ref="autocomplete" :fetch-suggestions="querySearch" :trigger-on-focus="false" v-model="ruleForm.email" placeholder="请输入邮箱" clearable></el-autocomplete>
          <div class="error-msg red" v-if="errorMsg.email">{{errorMsg.email}}</div>
        </el-form-item>
        <el-form-item label="办公室电话：" prop="officePhone">
          <el-input v-model="ruleForm.officePhone" placeholder="请输入办公室电话" clearable></el-input>
          <div class="error-msg red" v-if="errorMsg.officePhone">{{errorMsg.officePhone}}</div>
        </el-form-item>
        <el-form-item label="部门：" prop="dept">
          <el-input v-model="ruleForm.dept" placeholder="请输入部门" clearable :maxlength="40"></el-input>
          <div class="error-msg red" v-if="errorMsg.dept">{{errorMsg.dept}}</div>
        </el-form-item>
        <el-form-item label="职务：" prop="title">
          <el-input v-model="ruleForm.title" placeholder="请输入职务" clearable></el-input>
          <div class="error-msg red" v-if="errorMsg.title">{{errorMsg.title}}</div>
        </el-form-item>

        <el-form-item label="分配角色：" prop="role">
          <el-select multiple v-model="ruleForm.role" placeholder="请选择角色" ref="select">
            <el-option v-for="(item,index) in noAllRoleList" :key="index" :label="item.label" :value="item.value"></el-option>
            <template slot="empty">
              <p class="select-undata-text">请先完成注册再进行添加用户</p>
            </template>
          </el-select>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" size="small" style="width: 100px" @click="addSubordinate('rules');">保存</el-button>
          <el-button size="small" style="width: 100px" @click="addCancle">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 编辑用户 -->
    <el-dialog v-if="!justAdd" title="编辑用户" :visible.sync="editFormVisible" class="addUser" :before-close="handleCloseEdit" :close-on-click-modal="false">

      <el-form :model="editForm" :rules="editrule" ref="editForm" label-width="100px">
        <el-form-item label="姓名：" prop="acctName">
          <el-input v-model="editForm.acctName" placeholder="请输入真实姓名" v-popover:popoverAcct clearable :disabled="!!oldEditForm.acctName"></el-input>
          <el-popover ref="popoverAcct" placement="right" title="" width="300" trigger="focus">
            <p class="guid-text guid-1"><i class="el-icon-circle-check" :class="{'green': popoverMsg}"></i>可使用字母、数字、汉字、下划线</p>
          </el-popover>
          <div class="error-msg red" v-if="errorMsg.acctName">{{errorMsg.acctName}}</div>
        </el-form-item>
        <el-form-item label="身份证号：" prop="certNo">
          <el-input type="text" v-model="editForm.certNo" placeholder="请输入身份证号" clearable :disabled="!!oldEditForm.certNo" @blur="upperCase('editForm')"></el-input>
          <div class="error-msg red" v-if="errorMsg.certNo">{{errorMsg.certNo}}</div>
        </el-form-item>
        <el-form-item label="手机号：" prop="mobile">
          <el-input type="text" v-model="editForm.mobile" placeholder="请输入手机号" clearable :disabled="!!oldEditForm.mobile"></el-input>
          <div class="error-msg red" v-if="errorMsg.mobile">{{errorMsg.mobile}}</div>
        </el-form-item>
        <el-form-item label="邮箱：" prop="email">
          <el-autocomplete ref="autocomplete" :fetch-suggestions="querySearch" :disabled="!!oldEditForm.email" :trigger-on-focus="false" v-model="editForm.email" placeholder="请输入邮箱" clearable></el-autocomplete>
          <div class="error-msg red" v-if="errorMsg.email">{{errorMsg.email}}</div>
        </el-form-item>
        <el-form-item label="办公室电话：" prop="officePhone">
          <el-input v-model="editForm.officePhone" placeholder="请输入办公室电话" clearable></el-input>
          <div class="error-msg red" v-if="errorMsg.officePhone">{{errorMsg.officePhone}}</div>
        </el-form-item>
        <el-form-item label="部门：" prop="dept">
          <el-input v-model="editForm.dept" placeholder="请输入部门" clearable :maxlength="40"></el-input>
          <div class="error-msg red" v-if="errorMsg.dept">{{errorMsg.dept}}</div>
        </el-form-item>
        <el-form-item label="职务：" prop="title">
          <el-input v-model="editForm.title" placeholder="请输入职务" clearable></el-input>
          <div class="error-msg red" v-if="errorMsg.title">{{errorMsg.title}}</div>
        </el-form-item>
        <el-form-item label="分配角色：" prop="roleIds">
          <el-select multiple v-model="editForm.roleIds" placeholder="请选择角色" ref="select">
            <el-option v-for="(item,index) in noAllRoleList" :disabled="!item.canEdit" :key="index" :label="item.label" :value="item.value"></el-option>
            <template slot="empty">
              <p class="select-undata-text">请先完成注册再进行添加用户</p>
            </template>
          </el-select>
          <div class="error-msg red" v-if="errorMsg.title">{{errorMsg.title}}</div>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" size="small" style="width: 100px" @click="editSubordinate('editrule');">保存</el-button>
          <el-button size="small" style="width: 100px" @click="handleCloseEdit">取消</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 查询条件 -->
    <div class="panel-content" v-if="!justAdd">
      <el-form class="form" :model="form" size="small" label-width="100px">
        <el-row>
          <el-col style="width: 308px">
            <el-form-item label="姓名：">
              <el-input v-model.trim="form.acctName" placeholder="请输入姓名" clearable></el-input>
            </el-form-item>
          </el-col>
          <el-col style="width: 308px" :offset="1">
            <el-form-item label="手机号：">
              <el-input v-model.trim="form.mobile" placeholder="请输入手机号" clearable></el-input>
            </el-form-item>
          </el-col>
          <el-col style="width: 308px" :offset="1">
            <el-form-item label="邮箱：">
              <el-input v-model.trim="form.email" placeholder="请输入邮箱" clearable maxlength="64"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col style="width: 308px">
            <el-form-item label="角色：">
              <el-select v-model="form.role" placeholder="请选择角色">
                <el-option v-for="(item,index) in roleList" :key="index" :label="item.label" :value="item.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col style="width: 308px" v-if="type=='division'" :offset="1">
            <el-form-item label="事业部：">
              <el-select disabled filterable clearable v-model="form.groupCompanyCode" placeholder="请选择所属事业部" style="width: 100%;" :filter-method="handleGetValue" @visible-change="handleSelectedValueChange">
                <el-option v-for="item in groupCompanySelList" :label="item.value" :value="item.code" :key="item.value"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col style="width: 308px" :offset="1" v-if="type != 'division'">
            <el-form-item label="项目名称：">
              <el-input v-model.trim="projectName" :title="projectName" disabled clearable maxlength="64"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24" class="form-btns">
            <div class="searchbox">
              <div class="searchBtn" @click="handleSearch">搜索</div>
              <div class="clearBtn" @click="handleClear">清除</div>
            </div>
          </el-col>
        </el-row>
      </el-form>
    </div>
    <div class="address-table" v-if="!justAdd">
      <!-- 列表 -->
      <table>
        <thead>
          <tr>
            <td width="160" class="textLeft text-left-padding">姓名
            </td>
            <td width="160">手机号
            </td>
            <td>邮箱
            </td>
            <td width="160">部门与职务
            </td>
            <td width="160">角色
            </td>
            <td width="100" class="textRight">
              操作
            </td>
          </tr>
        </thead>
        <tbody>
          <tr v-for="(item,index) in acctList" :key="index">
            <td class="textLeft">
              <div class="user-name">
                <div class="right">
                  <p>{{item.acctName}}</p>
                  <p>{{item.oaLoginId || '未关联OA账号'}}</p>
                </div>
              </div>
            </td>
            <td>{{item.mobile}}</td>
            <td>{{item.email}}</td>
            <td>
              {{item.dept}}<template v-if="item.title"><br />{{item.title}}</template>
            </td>
            <td>
              <span v-for="(it,index) in item.roleIds" :key="index">
                <span v-if="index <= item.roleIds.length-2">{{it.roleName}},</span>
                <span v-if="index == item.roleIds.length-1">{{it.roleName}}</span>
              </span>
            </td>
            <td class="textRight">
              <!-- 系统管理员角色才能操作 -->
              <template v-if="mixinsRoleIds.some(s=> ['1000', '9000'].includes(s.roleId)) || isDivisionEdit">
                <p type="text" v-if="computedIsRoleId(['1000','2000','3000','4000','5000','9000']) || isDivisionEdit" @click="editFormMessage(item)">编辑</p>
                <p type="text" :class="{'owner':item.acctId == userInfo.acctId}" @click="delSubordinateMessage(item)">删除</p>
              </template>
              <span v-else>-</span>
            </td>
          </tr>
        </tbody>
      </table>
      <div class="table-pagination" v-if="acctList.length">
        <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
        </el-pagination>
      </div>
      <div class="product-empty" v-if="!acctList.length&&!isLoading">
        <img src="@/assets/images/icon-no-product.png">
        <p>没有搜索到相关用户，请重新修改搜索条件搜索！</p>
      </div>
    </div>
    <!-- 删除 -->
    <el-dialog v-if="!justAdd" class="dialog" title="确认删除" :append-to-body="true" :lock-scroll="true" :visible.sync="delDialogVisible" width="50%" center :close-on-click-modal="false">
      <div class="tc">删除用户后不能恢复，确定要删除用户<span style="color: #e93340;">{{delMessage.acctName}}</span>吗?
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 100px" @click="delSubordinate">确定</el-button>
        <el-button size="small" style="width: 100px" @click="delDialogVisible = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 冻结 -->
    <el-dialog v-if="!justAdd" class="dialog" title="用户冻结确认" :append-to-body="true" :lock-scroll="true" :visible.sync="isFrozrn" width="50%" center :close-on-click-modal="false">
      <div class="tc">冻结用户操作将导致：该用户被拒绝登录大家采平台并被限制所有权限。确认要冻结用户<span style="color: #e93340;">{{frozrnMessage.acctName}}</span>吗?
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 100px" @click="frozrn(frozrnMessage)">确定</el-button>
        <el-button size="small" style="width: 100px" @click="isFrozrn = false">取消</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
    <!--<ConfluenceFloat :id="'6'" v-if="!justAdd"></ConfluenceFloat>-->
    <AddHrSystemInfo :dialog='dialog' ref="addHrSystemInfo" @close="addFormVisible = true;openSystemInfo=false" @info="handleFillInfo"></AddHrSystemInfo>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from '@/components/base/Loading'
import PwdStrength from '@/components/base/PwdStrength'
import CryptoJS from 'crypto-js';
import ConfluenceFloat from '@/components/base/ConfluenceFloat'
import AddHrSystemInfo from '@/components/auth/dialog/AddHrSystemInfo'
import PanelTitle from "@/components/base/PanelTitle";
import Breadcrumb from "@/components/base/Breadcrumb";
import accountMixin from "@/mixins/account";

const params = {
  acctName: '',
  mobile: '',
  email: '',
  role: '',
  certNo: '',
  dept: '',
  acctStatus: '',
  pageIndex: 1,
  pageSize: 10
};
export default {
  mixins: [accountMixin],
  components: {
    PwdStrength,
    Loading,
    AddHrSystemInfo,
    PanelTitle,
    Breadcrumb,
    ConfluenceFloat
  },
  // type: 事业部 - division , 默认项目列表, editAdmin可编辑
  props: {
    justAdd: String,
    dialog: Boolean,
    corpId: String,
    type: String,
    projectId: String,
    proGroupCompanyCode: String,
    editAdmin: Boolean,
    projectName: String,
    breadcrumb: {
      type: Array,
      default() {
        return [
          { name: '管理中心', path: '/purchaserCenter/accountInfo' },
          { name: '公司管理信息-项目管理', goBack: true },
          { name: '项目账户管理' },
        ]
      }
    }
  },
  data() {
    var validataMobile = (rule, value, callback) => {
      // console.log(value)
      let mobileReg = /^[1][0-9]{10}$/;
      if (value === '') {
        callback(new Error('请输入手机号'));
      } else {
        if (!mobileReg.test(this.ruleForm.mobile || this.editForm.mobile)) {
          callback(new Error('手机号格式不正确'));
        }
        callback();
      }
    };
    var validataCertNo = (rule, value, callback) => {
      // console.log(value)
      let certNoReg = this.$commonExpression('certNo'); // /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
      if (value === '') {
        // callback(new Error('请输入身份证号'));
        callback();
      } else {
        if (!certNoReg.test(this.ruleForm.certNo || this.editForm.certNo) && (this.ruleForm.certNo || this.editForm.certNo)) {
          callback(new Error('身份证号格式不正确'));
        }
        callback();
      }
    };
    var validataName = (rule, value, callback) => {
      let nameReg = this.$commonExpression('account');
      if (value === '') {
        callback(new Error('请输入姓名'));
      } else if (!nameReg.test(this.ruleForm.acctName || this.editForm.acctName)) {
        callback(new Error('姓名设置不符合要求'));
      }
      callback();
    };
    var validataNameP = (rule, value, callback) => {
      let nameReg = this.$commonExpression('account');
      if (value === '') {
        this.popoverMsg = false;
        callback(new Error(' '));
        // console.log( this.popoverMsg)
        //   console.log(333)
      } else if (!nameReg.test(this.ruleForm.acctName || this.editForm.acctName)) {
        this.popoverMsg = false;
        callback(new Error(' '));
        // console.log( this.popoverMsg)
        // console.log(444)
      } else if (nameReg.test(this.ruleForm.acctName || this.editForm.acctName)) {
        this.popoverMsg = true;
        // console.log( this.popoverMsg)
        // console.log(555)
      }
      callback();
    };
    var validataPwd = (rule, value, callback) => {
      // let pwdReg = this.$commonExpression('pwdStongMilddle');
      if (value === '') {
        callback(new Error('请输入密码'));
      } else {
        if (this.strength <= 1 || value == this.ruleForm.acctName) {
          callback(new Error('密码设置不符合要求，请重新设置'));
        }
        callback();
      }
    };
    var validataEditPwd = (rule, value, callback) => {
      if (value === '') {
      } else {
        if (this.strength <= 1 || value == this.ruleForm.acctName) {
          callback(new Error('密码设置不符合要求，请重新设置'));
        }
        callback();
      }
    };
    return {
      form: Object.assign({}, params),
      statusList: [
        { label: "全部", value: "" },
        { label: "正常", value: "0" },
        { label: "冻结", value: "1" },
        { label: "离职", value: "3" },
      ],
      roleList: [],
      noAllRoleList: [],
      acctList: [],
      total: 0,
      pageIndex: 1,
      pageSize: 5,
      isLoading: false,
      addFormVisible: false,
      editFormVisible: false,
      delDialogVisible: false,
      isFrozrn: false,
      openSystemInfo: false,
      fromContentBtn: false,
      delMessage: {},
      frozrnMessage: {},
      errorMsg: {},
      strength: '',
      instant: '',
      popoverMsg: false,
      ruleForm: {
        acctName: '',
        mobile: '',
        email: '',
        certNo: '',
        // loginPwd: '',
        title: '',
        dept: '',
        officePhone: '',
        role: [],
      },
      rules: {
      },
      editForm: {},
      oldEditForm: {},
      editrule: {},
      groupCompanyList: [],
      groupCompanySelList: [],
      isSetAdmin: false,  // 是否有设置过 管理员 (如果没有设置过 则所有用户可以设置管理员)
    };
  },
  computed: {

    // 事业部 - 只有 2000 权限 则 哪条数据满足 对应的 corpId 才能编辑哪条
    isDivisionEdit() {
      return this.mixinsRoleIdsAdmin(this.corpId || '')
    },

    // 返回当前用户 持有的 权限
    mixinsRoleIdsAdmin() {
      return (corpId, code = '2000') => {
        const ids = this.roleListFilter(corpId) || []
        // 是否为管理员2000
        return ids.some(s => s.roleId == code)
      }
    },

    // 返回当前用户 持有的 权限
    mixinsRoleIds() {
      console.log(this.roleListFilter(this.mxCorpId), '-this.roleListFilter(this.mxCorpId) ');

      return this.roleListFilter(this.mxCorpId) || []
    },
    computedIsRoleId() {
      return idList => {
        const roleIds = this.mixinsRoleIds || [];
        let bool = false;
        idList.forEach(id => {
          roleIds.forEach(item => {
            if (item.roleId === id) {
              bool = true;
            }
          })
        });
        return bool
      }
    },
    isLogin() {
      return this.$store.state.isLogin
    },
    userInfo() {
      return this.$store.state.userInfo
    },
    groupCompanyCode() {
      return this.$store.state.userInfo && this.$store.state.userInfo.groupCompanyCode;
    },
    role() {
      return this.$store.state.userInfo
        ? this.$store.state.userInfo.bs
        : 0;
    },
  },
  methods: {
    // 查询事业部下拉
    getListConfig() {
      const params = {
        appName: 'MEMBER',
        groupIds: ["SYB_CONFIG"],
      }
      InterfaceService.getPaymentMethod(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          const configEntityListMap = data.respData.configEntityListMap && data.respData.configEntityListMap.SYB_CONFIG || []
          this.groupCompanyList = configEntityListMap || []
          this.groupCompanySelList = configEntityListMap || []
        } else {
          this.$message.error(data.respData && data.respData.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    querySearch(queryString, callback) {
      let commonMailbox = this.$commonMailbox()
      let results = this.$clone(commonMailbox)
      let value = ''
      if(queryString && queryString.indexOf('@') != -1){
        value = queryString.substring(0, queryString.indexOf('@'))
      }else{
        value = queryString
      }
      results.forEach((i,index) =>{
          i.value = value + '' + commonMailbox[index].value
      })
      callback(results)
      this.$refs.autocomplete.handleFocus()
    },
    addSystemInfo() {
      this.$refs['addHrSystemInfo'].open();
      this.openSystemInfo = true;
      this.addFormVisible = false
    },
    handleOpenAddForm(name, list) {
      this.noAllRoleList = []
      const adminRoleList = ["1000", "2000", "2002", "3000", "4000", "5000", '9000'];
      this.roleList.forEach(item => {
        if (item.value) {
          if (adminRoleList.indexOf(item.value) === -1 || this.editAdmin) {
            this.noAllRoleList.push({
              label: item.label,
              value: item.value,
              canEdit: true
            });
          }
        }
      });
      if (list) {
        this.noAllRoleList = list;
      }
      this.openSystemInfo = false;
      this.popoverMsg = false;


      Object.keys(this.ruleForm).forEach(key => this.ruleForm[key] = '');
      // 事业部 默认选中 数据查阅者
      this.type == 'division' && (this.ruleForm.role = ['9001'])
      this.addFormVisible = true;
      console.log(this.noAllRoleList, 'noAllRoleList');


    },
    // 跳转
    handleCurrentChange(page) {
      this.form.pageIndex = page;
      this.getSubordinateData();
      window.scrollTo(0, 0)
    },
    // 填充绿地香港用户信息
    handleFillInfo(info) {
      this.addFormVisible = true;
      this.ruleForm.acctName = info.custName || "";
      this.ruleForm.mobile = info.mobileNo || "";
      this.ruleForm.email = info.email || "";
      this.ruleForm.title = info.title || "";
      this.ruleForm.certNo = info.certNo || "";
      this.ruleForm.dept = info.deptName || "";
      if (!this.justAdd) {
        this.ruleForm.role = "";
      }
      this.openSystemInfo = false;
    },
    handleClose(key, keyPath) {
      // console.log(key, keyPath);
      this.errorMsg = '';
      this.addFormVisible = false;
      !this.justAdd && this.$refs.ruleForm.resetFields();
    },
    handleCloseEdit() {
      this.errorMsg = '';
      this.$refs.editForm.resetFields();
      this.editFormVisible = false;
    },
    addCancle() {
      this.addFormVisible = false;
      !this.justAdd && this.$refs.ruleForm.resetFields();
      !this.openSystemInfo && this.$emit("cancle", this.ruleForm.acctName, this.fromContentBtn)
    },
    getPwdStrength(strength) {
      this.strength = strength
    },
    getPwdInstant(instant) {
      this.instant = instant
    },
    //清除
    handleClear() {
      // 不清除this.form.groupCompanyCode
      const code = this.form.groupCompanyCode
      this.form = Object.assign({}, params);
      this.form.groupCompanyCode = code
      this.handleSearch()
    },
    //搜索
    handleSearch() {
      this.getSubordinateData();
    },
    // 删除
    delSubordinateMessage(item) {
      if (item.acctId == this.userInfo.acctId) {
        return
      }
      this.delDialogVisible = true;
      this.delMessage = item;
    },
    // 冻结
    toTrozrn(item) {
      if (item.acctId == this.userInfo.acctId) {
        return
      }
      this.frozrnMessage = item;
      this.isFrozrn = true;
    },
    // 编辑
    editFormMessage(itemDate) {
      console.log(itemDate);
      console.log(this.acctList, 'acctList');

      // 所有数据 都没有设置过管理员 那么可以设置管理员
      this.isSetAdmin = this.acctList.some(s => s.roleIds && s.roleIds.some(s1 => s1.roleId == '9000'))

      let roleIds = itemDate.roleIds || []
      const adminRoleList = ["1000", "2000", "2002", "3000", "4000", "5000", '9000'];
      let onOff = false
      roleIds.forEach(item => {
        if (adminRoleList.indexOf(item.roleId) !== -1) {
          onOff = true;
        }
      });
      this.noAllRoleList = [];
      // 未设置管理员 可以 添加管理员选项   this.type == 'division': 事业部账户管理 不隐藏9000 事业部管理员选项
      if (onOff || !this.isSetAdmin || this.type == 'division') {
        this.roleList.forEach(item => {
          if (item.value) {
            this.noAllRoleList.push({
              label: item.label,
              value: item.value,
              canEdit: true
            });
          }
        });
      } else {
        this.roleList.forEach(item => {
          if (item.value) {
            if (adminRoleList.indexOf(item.value) === -1) {
              this.noAllRoleList.push({
                label: item.label,
                value: item.value,
                canEdit: true
              });
            }
          }
        });
      }
      this.noAllRoleList.forEach(item => {
        if (adminRoleList.indexOf(item.value) !== -1 && !this.editAdmin) {
          item.canEdit = false
        }
      });
      this.popoverMsg = true;
      this.editForm = JSON.parse(JSON.stringify(itemDate)); //对象赋值 地址引用
      this.oldEditForm = this.$clone(itemDate);
      this.editFormVisible = true;
      this.editForm.roleIds = []
      for (var i = 0; i < roleIds.length; i++) {
        this.editForm.roleIds.push(roleIds[i].roleId)
      }
      // 事业部 不设置 下拉框 x
      if (this.type != 'division') {
        setTimeout(() => {
          let selectIconClass = this.$refs["select"] && this.$refs["select"].$el.firstChild.childNodes[1].childNodes;
          for (let i in selectIconClass) {
            let text = selectIconClass[i].innerText;
            roleIds.forEach(item => {
              if (adminRoleList.indexOf(item.roleId) !== -1 && text === item.roleName) {
                let icon = selectIconClass[i].lastChild;
                console.log(selectIconClass[i]);
                console.log(icon);
                let classVal = icon.getAttribute("class");
                icon.setAttribute("class", classVal.replace("el-icon-close", ""));
              }
            })
          }
        }, 200)
      }
    },
    // 密码
    inputPwd() {
      this.editForm.loginPwd = '';
    },
    changePwd(Pwd) {
      if (Pwd) {
        this.editForm.loginPwd = Pwd;
        if (this.strength <= 1 || Pwd == this.userInfo.acctName) {
          this.$set(this.errorMsg, 'loginPwd', '密码设置不符合要求，请重新设置');
          return;
        } else {
          this.$set(this.errorMsg, 'loginPwd', '');
        }
      } else if (Pwd == '') {
        this.editForm.loginPwd = '``````';
        this.$set(this.errorMsg, 'loginPwd', '');
      }
    },

    // 新增公司下属账户信息
    addSubordinate(rules) {
      this.errorMsg = {};
      console.log(this.$refs.ruleForm);
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          // let loginPwd = CryptoJS.MD5(this.ruleForm.loginPwd).toString();

          let params = {
            'corpId': this.corpId,
            'roleIds': this.ruleForm.role,
            'acctName': this.ruleForm.acctName,
            'mobile': this.ruleForm.mobile,
            'email': this.ruleForm.email,
            'certNo': this.ruleForm.certNo,
            'title': this.ruleForm.title,
            'dept': this.ruleForm.dept,
            'officePhone': this.ruleForm.officePhone,
            // 'loginPwd': CryptoJS.MD5(this.ruleForm.loginPwd).toString()
            'projectId': this.projectId
          };
          this.justAdd && delete params.certNo
          // console.log(params)
          // 与后端请求
          InterfaceService.addSubordinate(
            params,
            data => {
              //console.log(data)
              let res = data.respData
              if (res.respCode == '0000') {
                this.addFormVisible = false;
                this.$message.success("添加用户成功！");
                this.$refs.ruleForm.resetFields();
                this.justAdd ? this.$emit("saveSuccess") : this.getSubordinateData()
              } else {
                if (res.respCode == 'MEM0064' || res.respCode == 'MEM0058' || res.respCode == 'MEM0062') {
                  this.$set(this.errorMsg, 'acctName', res.respMsg);
                } else if (res.respCode == 'MEM0053' || res.respCode == 'MEM0025' || res.respCode == 'MEM0051') {
                  this.$set(this.errorMsg, 'mobile', res.respMsg);
                } else if (res.respCode == 'MEM0065' || res.respCode == 'MEM0059' || res.respCode == 'MEM0063') {
                  this.$set(this.errorMsg, 'email', res.respMsg);
                } else if (res.respCode == 'MEM0060' || res.respCode == 'MEM0061') {
                  this.$set(this.errorMsg, 'loginPwd', res.respMsg);
                } else if (res.respCode == 'MEM0094') {
                  // 账号未激活
                  this.$alert(
                    "账号未激活",
                    {
                      customClass: "alert-box",
                      center: true,
                      confirmButtonText: "知道了",
                      callback: action => { }
                    }
                  );
                } else if (res.respCode == 'MEM0030') {
                  // 账号冻结
                  this.$alert(
                    "账号冻结",
                    {
                      customClass: "alert-box",
                      center: true,
                      confirmButtonText: "知道了",
                      callback: action => { }
                    }
                  );
                } else {
                  this.$message.error(res.respMsg);
                }
              }
            },
            data => { },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            }
          );
        } else {
          console.log('error submit!!');
        }
      });
    },
    //编辑公司下属账户信息
    editSubordinate(editrule) {
      this.errorMsg = {};
      // 判断密码有没有修改
      // let selfLoginPwd;
      // if(this.editForm.loginPwd == '``````') {
      //   selfLoginPwd = ''
      // }else if(this.editForm.loginPwd != '``````'){

      //   if(this.strength <= 1 || this.editForm.loginPwd == this.userInfo.acctName) {
      //     this.$set(this.errorMsg,'loginPwd','密码设置不符合要求，请重新设置');
      //     return;
      //   }else{
      //     selfLoginPwd = this.editForm.loginPwd;
      //     this.$set(this.errorMsg,'loginPwd','');
      //   }

      // }
      this.$refs.editForm.validate((valid) => {
        if (valid) {
          console.log(this.projectId, '-this.projectId');

          let params = {
            'corpId': this.corpId,
            'roleIds': this.editForm.roleIds,
            'acctId': this.editForm.acctId,
            'acctName': this.editForm.acctName,
            'mobile': this.editForm.mobile,
            'email': this.editForm.email,
            'certNo': this.editForm.certNo,
            'title': this.editForm.title,
            'dept': this.editForm.dept,
            'officePhone': this.editForm.officePhone,
            // 'loginPwd': selfLoginPwd ? CryptoJS.MD5(selfLoginPwd).toString() : null
            'projectId': this.projectId
          }
          // console.log(params)
          InterfaceService.editSubordinate(params, (data) => {
            let res = data.respData
            if (res.respCode === "0000") {
              //console.log(data)
              this.editFormVisible = false;
              this.$message.success("编辑用户成功！");
              this.justAdd ? this.$emit("saveSuccess") : this.getSubordinateData()
            } else {
              if (res.respCode == 'MEM0064' || res.respCode == 'MEM0058' || res.respCode == 'MEM0062') {
                this.$set(this.errorMsg, 'acctName', res.respMsg);
              } else if (res.respCode == 'MEM0053' || res.respCode == 'MEM0025' || res.respCode == 'MEM0051') {
                this.$set(this.errorMsg, 'mobile', res.respMsg);
              } else if (res.respCode == 'MEM0065' || res.respCode == 'MEM0059' || res.respCode == 'MEM0063' || res.respCode == 'MEM0116') {
                this.$set(this.errorMsg, 'email', res.respMsg);
              } else if (res.respCode == 'MEM0060' || res.respCode == 'MEM0061') {
                this.$set(this.errorMsg, 'loginPwd', res.respMsg);
              } else if (res.respCode == 'MEM0094') {
                // 账号未激活
                this.$alert(
                  "账号未激活",
                  {
                    customClass: "alert-box",
                    center: true,
                    confirmButtonText: "知道了",
                    callback: action => { }
                  }
                );
              } else if (res.respCode == 'MEM0030') {
                // 账号冻结
                this.$alert(
                  "账号冻结",
                  {
                    customClass: "alert-box",
                    center: true,
                    confirmButtonText: "知道了",
                    callback: action => { }
                  }
                );
              } else {
                this.$message.error(res.respMsg);
              }
            }
          },
            data => { },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            });
        } else {
          console.log('error submit!!');
          // return false;
        }
      });
    },
    upperCase(type) {
      if (type == "ruleForm") {
        this.ruleForm.certNo = this.ruleForm.certNo && this.ruleForm.certNo.toUpperCase();
      } else if (type == "editForm") {
        this.editForm.certNo = this.editForm.certNo && this.editForm.certNo.toUpperCase();
      }
    },
    // 冻结/解冻公司下属账户信息
    frozrn(itemDate) {
      this.isFrozrn = false;
      //console.log(itemDate)
      if (itemDate.acctId == this.userInfo.acctId) {
        return
      }
      let params = {
        acctId: itemDate.acctId,
        acctStatus: itemDate.acctStatus
      }
      InterfaceService.frozenSubordinate(params, (data) => {
        if (data.respCode === "0000") {
          //console.log(data)
          this.getSubordinateData()
        } else {
          this.$message.error(data.respMsg);
        }
      },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        });
    },
    // 删除公司下属账户信息
    delSubordinate() {
      this.delDialogVisible = false;
      //console.log(this.delMessage)
      let params = {
        corpId: this.corpId,
        acctId: this.delMessage.acctId,
        projectId: this.projectId || ''
      }
      InterfaceService.delSubordinate(params, (data) => {
        if (data.respData.respCode === "0000") {
          this.getSubordinateData()
        } else if (data.respData.respCode === "MEM0346") {
          let text = "";
          data.respData.incompleteEventList && data.respData.incompleteEventList.forEach(item => {
            text = text + `<div class="tl" style="word-wrap:break-word "><p class="f14 bold">${item.incompleteEventTypeMessage}:</p>
                                    <p class="f12">●&nbsp;&nbsp;${item.contractName.replace(/,/g, "<br>●&nbsp;&nbsp;")}</p>
                                 </div>
                                `
          });
          text = text + `<div class="tl" style="margin-top: 10px">请联系大家采官方客服：400-009-0506。</div>`;
          let msg = `${data.respData.respMsg}`;
          this.$alert(
            text,
            msg,
            {
              customClass: "alert-box",
              confirmButtonText: "知道了",
              dangerouslyUseHTMLString: true,
              center: true,
              callback: action => {
              }
            }
          );
        } else {
          this.$message.error(data.respData && data.respData.respMsg);
        }
      },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        });
    },
    // 查询公司下属账户信息
    getSubordinateData() {
      const params = {};
      for (let i in this.form) {
        if (this.form[i]) {
          params[i] = this.form[i];
        }
      }
      params.corpId = this.corpId
      this.noAllRoleList = [];
      InterfaceService.getQuerySubordinate(params, (data) => {
        if (data.respCode === "0000") {
          //console.log(data)
          this.acctList = data.respData.acctList || [];
          this.total = data.respData.totalCount;
          this.form.pageSize = data.respData.pageSize;

          let rlist = data.respData.roleList || [];
          this.roleList = [{ label: "全部", value: "" }];

          rlist.forEach(item => {
            this.noAllRoleList.push(
              {                label: item.roleName,
                value: item.roleId              }
            ),
              this.roleList.push(
                {                  label: item.roleName,
                  value: item.roleId                }
              )
          });
          rlist = [];
        } else {
          this.$message.error(data.respMsg);
        }
      },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        });
    },
    crumbRefresh() {
      this.$emit('refresh', true)
    },

    handleSelectedValueChange(bool) {
      if (bool) {
        this.groupCompanySelList = this.groupCompanyList
      }
    },

    handleGetValue(val) {
      val = val.replace(/\s+/g, "")
      if (val) {
        this.groupCompanySelList = this.groupCompanyList.filter(item => {
          return !!~item.value.indexOf(val) || !!~item.value.toUpperCase().indexOf(val.toUpperCase())
        })
      } else {
        this.groupCompanySelList = this.groupCompanyList
      }
    },

    init() {
      var validataMobile = (rule, value, callback) => {
        // console.log(value)
        let mobileReg = /^[1][0-9]{10}$/;
        if (value === '') {
          callback(new Error('请输入手机号'));
        } else {
          if (!mobileReg.test(this.ruleForm.mobile || this.editForm.mobile)) {
            callback(new Error('手机号格式不正确'));
          }
          callback();
        }
      };
      var validataCertNo = (rule, value, callback) => {
        console.log(value)
        let certNoReg = this.$commonExpression('certNo'); // /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;
        if (value === '') {
          // callback(new Error('请输入身份证号'));
          callback();
        } else {
          if (!certNoReg.test(this.ruleForm.certNo || this.editForm.certNo) && (this.ruleForm.certNo || this.editForm.certNo)) {
            callback(new Error('身份证号格式不正确'));
          }
          callback();
        }
      };
      var validataName = (rule, value, callback) => {
        let nameReg = this.$commonExpression('account');
        if (value === '') {
          callback(new Error('请输入姓名'));
        } else if (!nameReg.test(this.ruleForm.acctName || this.editForm.acctName)) {
          callback(new Error('姓名设置不符合要求'));
        }
        callback();
      };
      var validataNameP = (rule, value, callback) => {
        let nameReg = this.$commonExpression('account');
        if (value === '') {
          this.popoverMsg = false;
          callback(new Error(' '));
          // console.log( this.popoverMsg)
          //   console.log(333)
        } else if (!nameReg.test(this.ruleForm.acctName || this.editForm.acctName)) {
          this.popoverMsg = false;
          callback(new Error(' '));
          // console.log( this.popoverMsg)
          // console.log(444)
        } else if (nameReg.test(this.ruleForm.acctName || this.editForm.acctName)) {
          this.popoverMsg = true;
          // console.log( this.popoverMsg)
          // console.log(555)
        }
        callback();
      };
      var validataPwd = (rule, value, callback) => {
        // let pwdReg = this.$commonExpression('pwdStongMilddle');
        if (value === '') {
          callback(new Error('请输入密码'));
        } else {
          if (this.strength <= 1 || value == this.ruleForm.acctName) {
            callback(new Error('密码设置不符合要求，请重新设置'));
          }
          callback();
        }
      };
      var validataEditPwd = (rule, value, callback) => {
        if (value === '') {
        } else {
          if (this.strength <= 1 || value == this.ruleForm.acctName) {
            callback(new Error('密码设置不符合要求，请重新设置'));
          }
          callback();
        }
      };
      this.rules = {        acctName: [{
          required: true,
          validator: validataName,
          trigger: ['blur']
        }, {
          validator: validataNameP,
          trigger: ['change']
        }, {
          max: 200,
          message: "姓名不得大于200个字",
          trigger: "blur"        }],
        mobile: [
          {
            required: true,
            validator: validataMobile,
            trigger: 'blur'
          }],
        certNo: [
          {
            required: this.role === "S",
            trigger: 'blur',
            message: '请输入身份证号',
          }, {
            validator: validataCertNo,
            trigger: 'blur'
          }],
        email: [{
          required: this.role === "S",
          type: 'email',
          message: '请输入正确的邮箱地址',
          trigger: ['blur', 'change']
        }, {
          max: 64,
          message: "邮箱不得大于64个字",
          trigger: "blur"
        }
        ],
        officePhone: [
          { pattern: /^[\d-\s\(\)\+\,]*$/, message: "座机号填写错误，请重新填写", trigger: "blur" },
        ],
        title: [{
          required: false
        }, {
          max: 40,
          message: "职务不得大于40个字",
          trigger: "blur"
        }],
        role: [{
          required: true,
          message: '请选择角色',
          trigger: ['blur', 'change']
        }]      }
      this.editrule = {
        acctName: [{
          required: true,
          validator: validataName,
          trigger: ['blur']
        }, {
          validator: validataNameP,
          trigger: ['change']
        }, {
          max: 200,
          message: "姓名不得大于200个字",
          trigger: "blur"
        }],
        mobile: [
          {
            required: true,
            validator: validataMobile,
            trigger: 'blur'
          }],
        certNo: [
          {
            required: this.role === "S",
            trigger: 'blur',
            message: '请输入身份证号',
          }, {
            validator: validataCertNo,
            trigger: 'blur'
          }],
        officePhone: [
          { pattern: /^[\d-\s\(\)\+\,]*$/, message: "座机号填写错误，请重新填写", trigger: "blur" },
        ],
        email: [{
          required: this.role === "S",
          type: 'email',
          message: '请输入正确的邮箱地址',
          trigger: ['blur', 'change']
        }, {
          max: 64,
          message: "邮箱不得大于64个字",
          trigger: "blur"
        }],
        title: [{
          required: false
        }, {
          max: 40,
          message: "职务不得大于40个字",
          trigger: "blur"
        }],
        roleIds: [{
          required: true,
          message: '请选择角色',
          trigger: ['blur', 'change']
        }]
      }
    }
  },
  mounted() {
    this.init()
    this.form.groupCompanyCode = this.proGroupCompanyCode
    !this.justAdd && this.getSubordinateData();
    this.type == 'division' && this.getListConfig()
  }
};
</script>

<style lang="scss" scoped>
.owner {
  color: #aaaaaa;
}
.password::before {
  display: table;
  content: "*";
  top: 12px;
  position: absolute;
  left: 42px;
  color: #f56c6c;
}
.address-table table td {
  vertical-align: middle;
}
.guid-text {
  font-size: 12px;
  color: #888;
  line-height: 20px;
  i {
    margin-right: 8px;
  }
}
.users {
  font-size: 14px;
}

.addUser {
  /deep/ .el-dialog {
    width: 700px;
  }

  /deep/ .el-dialog__title {
    font-size: 14px;
    // margin-left: 300px;
  }
  /deep/ .el-form {
    margin-left: 100px;
  }
  /deep/ .el-form-item__content {
    width: 300px;
  }
  /deep/ .el-form-item__label {
    font-size: 12px;
  }
  /deep/ .el-input__inner {
    width: 300px;
  }
  /deep/ .el-button--primary {
    margin-left: 30px;
  }
}

.nowrap {
  white-space: nowrap;
}

.header {
  margin-bottom: 20px;
  background: #f5f5f5;
}

.header ul {
  width: 100%;
  height: 48px;
  border-bottom: 3px solid #ffd64e;
  font-weight: bold;

  .add {
    float: right;
    color: #4f525a;
    width: 130px;
    height: 26px;
    line-height: 26px;
    margin-right: 20px;
    background: #ffd64e;
    margin-top: 10px;
    font-weight: 500;
  }
  .add:hover {
    color: #000000;
    background-color: #f3c52f;
  }

  li {
    width: 94px;
    height: 48px;
    line-height: 48px;
    text-align: center;
    float: left;
    cursor: pointer;
    position: relative;

    &:after {
      display: none;
      position: absolute;
      bottom: 0px;
      left: 0;
      content: "";
      width: 94px;
      height: 3px;
      background: #4f525a;
    }

    &.active:after {
      display: block;
    }
  }
}
.add {
  text-align: center;
  cursor: pointer;
  color: #4f525a;
  width: 130px;
  height: 26px;
  line-height: 26px;
  margin-right: 20px;
  background: #ffd64e;
  margin-bottom: 10px;
  font-weight: 500;
}
.form {
  height: 170px;

  /deep/ .el-row {
    height: 50px;
  }

  /deep/ .el-select {
    width: 100%;
  }

  /deep/ .el-date-editor {
    input.el-input__inner {
      padding: 0 15px;
    }
    .el-input__prefix {
      display: none;
    }
  }

  &:after {
    display: table;
    content: "";
    clear: both;
  }
}

.address-table {
  /deep/ .el-table__body-wrapper {
    font-size: 12px;
  }

  /deep/ .el-table th,
  .el-table td {
    padding: 14px 0;
  }

  table {
    width: 100%;
    line-height: 23px;

    td {
      padding: 13px 10px;
      text-align: left;
    }
    td.textLeft {
      text-align: left;
    }
    td.textRight {
      text-align: right;
    }

    thead {
      text-align: left;
      color: #888;
      background: #f9f9f9;
      border-bottom: 1px solid #eee;
    }

    tbody {
      tr:hover {
        background: #f0f8ff;
      }

      td {
        border-bottom: 1px solid #eee;
        word-break: break-word;
        font-size: 12px;
        &:last-child.textRight {
          color: #0082ff;
          cursor: pointer;
        }
      }
    }
  }

  .address-name {
    line-height: 20px;

    img {
      width: 75px;
      height: 75px;
    }

    .left {
      margin-right: 10px;
    }

    .right {
      p:first-child {
        margin-bottom: 10px;
      }
      p:last-child {
        color: #969799;
      }
    }
  }
}

.panel-content {
  margin-bottom: 20px;
  padding: 20px 0px;
  background: #f9f9f9;
}

.form-btns {
  text-align: center;
}

.table-pagination {
  margin: 50px 0 80px;
  text-align: center;
  color: #888888;
}

/deep/ .el-dialog__title {
  font-size: 14px;
}
/deep/ .el-dialog--center .el-dialog__body {
  font-size: 12px;
}

/deep/ .el-select__tags {
  display: block;
}
.searchbox {
  text-align: center;
  margin-top: 20px;
  .searchBtn {
    width: 80px;
    height: 26px;
    line-height: 26px;
    background: linear-gradient(
      122deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(255, 255, 255, 1);
    margin-right: 20px;
    display: inline-block;
    cursor: pointer;
  }
  .clearBtn {
    width: 80px;
    height: 26px;
    line-height: 24px;
    border: 1px solid rgba(201, 159, 79, 1);
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(201, 159, 79, 1);
    display: inline-block;
    cursor: pointer;
  }
}
.product-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
/deep/ .el-form-item__label {
  padding-right: 6px !important;
}
.select-undata-text {
  padding: 12px;
  text-align: center;
  color: #666;
}
</style>