<template>
  <div id="authorizeBsListDetails">
    <div class="content">
      <!-- <DvCompanyMessageInfo v-if="corpId && bs && approveDefId=='PROJ_MANAGER_UPDATE_APPROVE'" :propType="approveDefId" :orAdminInfo="originalProjectManager"></DvCompanyMessageInfo> -->
      <div class="order-info">
        <div class="order-info-title">项目信息</div>
        <ul class="company-top">
          <li class="clearfloat">
            <div class="company-left">
              <span>ERP：</span>
              <div class="company-showtext">{{detailbaseInfo.erpProjectCode || "无"}}</div>
            </div>
            <div class="company-left">
              <span>项目名称：</span>
              <div class="company-showtext">{{detailbaseInfo.projectName || "无"}}</div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>所属事业部：</span>
              <div class="company-showtext">{{detailbaseInfo.groupCompanyName || "无"}}</div>
            </div>
            <div class="company-left">
              <span>项目公司名称：</span>
              <div class="company-showtext">{{detailbaseInfo.corpName || "无"}}</div>
            </div>
          </li>
        </ul>
      </div>
      <div class="order-info">
        <div class="order-info-title">项目分期信息</div>
        <ul class="company-top">
          <li class="clearfloat">
            <div class="company-left">
              <span>分期编号：</span>
              <div class="company-showtext">{{staging.projectStageCode || "无"}}</div>
            </div>
            <div class="company-left">
              <span>分期名称：</span>
              <div class="company-showtext">{{staging.projectStageName || "无"}}</div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>建筑面积(m²)：</span>
              <div class="company-showtext">{{staging.floorArea || "无"}}</div>
            </div>
            <div class="company-left">
              <span>所属城市：</span>
              <div class="company-showtext">{{staging.projectCityName || "无"}}</div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>项目详细地址：</span>
              <div class="company-showtext">{{staging.projectProvName}}{{staging.projectCityName}}{{staging.projectDistrictName}}{{staging.projectDetailAddr}}</div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>是否合作项目：</span>
              <div class="company-showtext">{{staging.isCorprationProject == '1' ? '是' : staging.isCorprationProject == '0' ? '否' : "无"}}</div>
            </div>
            <div class="company-left">
              <span>利润率5%以下项目：</span>
              <div class="company-showtext">{{staging.isProfitUnder5 == '1' ? '是' : staging.isProfitUnder5 == '0' ? '否' : "无"}}</div>
            </div>
          </li>
           <li class="clearfloat">
            <div class="company-left">
              <span>各方权益：</span>
              <div class="company-showtext">{{staging.interest || "无"}}</div>
            </div>
          </li>
           <li class="clearfloat">
            <div class="company-left">
              <span>业态：</span>
              <div class="company-showtext">{{staging.projectType || "无"}}</div>
            </div>
            <div class="company-left">
              <span>装修类型：</span>
              <div class="company-showtext">{{staging.decorateType || "无"}}</div>
            </div>
          </li>
           <li class="clearfloat">
            <div class="company-left">
              <span>计划或实际开工时间：</span>
              <div class="company-showtext">{{staging.projectStartDt || "无"}}</div>
            </div>
            <div class="company-left">
              <span>计划或实际竣工时间：</span>
              <div class="company-showtext">{{staging.projectEndDt || "无"}}</div>
            </div>
          </li>
           <li class="clearfloat">
            <div class="company-left">
              <span>项目开发阶段：</span>
              <div class="company-showtext">{{staging.projectDevelopmentStage || "无"}}</div>
            </div>
          </li>
        </ul>
      </div>
      <div class="order-info" v-if="corpId && bs && approveDefId=='PROJ_MANAGER_UPDATE_APPROVE'">
        <div class="order-info-title">原项目经理账户信息</div>
        <ul class="company-top">
          <li class="clearfloat">
            <div class="company-left">
              <span>姓名：</span>
              <div class="company-showtext">{{originalProjectManager.acctName || "无"}}</div>
            </div>
            <div class="company-left">
              <div class="company-left" style="width: auto;height: 26px;">
                <span>任命书：</span>
                <div class="box">
                  <template v-if="originalProjectManager.approveAttachList && originalProjectManager.approveAttachList.filter(i=> i.attachType === 'appointment').length">
                    <div class="annex" v-for="(item,ind) in originalProjectManager.approveAttachList.filter(i=> i.attachType === 'appointment')" :key="ind">
                    <p class="company-showtext" :title="item.attachName">{{item.attachName}}</p> 
                    <i style="padding-left: 10px;" class="fr hand blue" @click="handleOpenAuthorization(item.attachUrl)">查看</i>
                    <i style="padding-left: 10px;" class="fr hand blue" @click="handleDownload(item.attachName, item.attachUrl)">下载</i>
                  </div>
                  </template>
                  <span v-else>无</span>
                </div>
              </div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>手机号：</span>
              <div class="company-showtext">{{originalProjectManager.mobile || "无"}}</div>
            </div>
            <div class="company-left">
              <div class="company-left" style="width: auto;height: 26px;">
                <span>授权委托书：</span>
                <div class="box">
                  <template v-if="originalProjectManager.approveAttachList && originalProjectManager.approveAttachList.filter(i=> i.attachType === '2').length">
                    <div class="annex" v-for="(item,ind) in originalProjectManager.approveAttachList.filter(i=> i.attachType === '2')" :key="ind">
                      <p class="company-showtext" :title="item.attachName">{{item.attachName}}</p> <i style="padding-left: 10px;" class="fr hand blue" @click="handleOpenAuthorization(item.attachUrl)">查看用印版</i>
                    </div>
                  </template>
                  <span v-else>无</span>
                </div>
              </div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>邮箱：</span>
              <div class="company-showtext">{{originalProjectManager.email || "无"}}</div>
            </div>
            <div class="company-left">
              <span>部门：</span>
              <div class="company-showtext">{{originalProjectManager.department || "无"}}</div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>身份证号：</span>
              <div class="company-showtext">{{originalProjectManager.certNo || "无"}}</div>
            </div>
            <div class="company-left">
              <span>职位：</span>
              <div class="company-showtext">{{originalProjectManager.position || "无"}}</div>
            </div>
          </li>
        </ul>
      </div>
      <div class="order-info">
        <div v-if="approveStatus == 'approved'" class="order-info-title">现项目经理账户信息</div>
        <div v-else class="order-info-title">待审核项目经理账户信息</div>
        <ul class="company-top">
          <li class="clearfloat">
            <div class="company-left">
              <span>姓名：</span>
              <div class="company-showtext">{{newProjectManager.acctName || "无"}}</div>
            </div>
            <div class="company-left">
              <div class="company-left" style="width: auto;height: 26px;">
                <span>任命书：</span>
                <div class="box">
                  <template v-if="newProjectManager.approveAttachList && newProjectManager.approveAttachList.filter(i=> i.attachType === 'appointment').length">
                    <div class="annex" v-for="(item,ind) in newProjectManager.approveAttachList.filter(i=> i.attachType === 'appointment')" :key="ind">
                    <p class="company-showtext" :title="item.attachName">{{item.attachName}}</p> 
                    <i style="padding-left: 10px;" class="fr hand blue" @click="handleOpenAuthorization(item.attachUrl)">查看</i>
                    <i style="padding-left: 10px;" class="fr hand blue" @click="handleDownload(item.attachName, item.attachUrl)">下载</i>
                  </div>
                  </template>
                  <span v-else>无</span>
                </div>
              </div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>手机号：</span>
              <div class="company-showtext">{{newProjectManager.mobile || "无"}}</div>
            </div>
            <div class="company-left">
              <div class="company-left" style="width: auto;height: 26px;">
                <span>授权委托书：</span>
                <div class="box">
                  <template v-if="newProjectManager.approveAttachList && newProjectManager.approveAttachList.filter(i=> i.attachType === '2' || i.attachType === 'auth_word').length">
                    <div class="annex" v-for="(item,ind) in authorizeFile" :key="ind">
                      <p class="company-showtext" :title="item.attachName">{{item.attachName}}</p> <i style="padding-left: 10px;" class="fr hand blue" @click="handleOpenAuthorization(item.attachUrl)">查看</i>
                    </div>
                  </template>
                  <span v-else>无</span>
                </div>
              </div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>邮箱：</span>
              <div class="company-showtext">{{newProjectManager.email || "无"}}</div>
            </div>
            <div class="company-left">
              <span>部门：</span>
              <div class="company-showtext">{{newProjectManager.department || "无"}}</div>
            </div>
          </li>
          <li class="clearfloat">
            <div class="company-left">
              <span>身份证号：</span>
              <div class="company-showtext">{{newProjectManager.certNo || "无"}}</div>
            </div>
            <div class="company-left">
              <span>职位：</span>
              <div class="company-showtext">{{newProjectManager.position || "无"}}</div>
            </div>
          </li>
        </ul>
      </div>
      <div class="list-content">
        <div class="order-info-title">审核流水信息</div>
        <table>
          <thead>
            <tr>
              <td width="6%">序号</td>
              <td width="16%">信息提交时间</td>
              <td width="15%">审核状态</td>
              <td width="15%">操作人</td>
              <td width="48%">审核意见</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in approveLst" :key="ind" class="tbody-row">
            <tr>
              <td>
                {{ind+1}}
              </td>
              <td>
                <p class="time">{{item.operTm | formatLongTime('yyyymmddhhiiss')}}</p>
              </td>
              <td>
                {{item.operType | operTypeFilter}}
              </td>
              <td>
                {{item.operAcctName}}
              </td>
              <td>{{item.approveMsg}}</td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!approveLst.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>暂无审核流水信息！</p>
        </div>
        <div class="searchbox" v-if="baseInfo.searchType == '1'">
          <div class="searchBtn" @click="handleClickAgree">同意并签章</div>
          <div class="clearBtn" @click="showBackDialog=true">退回</div>
        </div>
      </div>
    </div>
    <!-- 同意 -->
    <el-dialog class="dialog dialog-drafts" :title="'授权申请（同意）'" :append-to-body="true" :lock-scroll="true" :visible.sync="showAgreeDialog" width="840px" center :close-on-click-modal="false">
      <div class="drafts-list">
        <p class="tc">
          您确定要通过该管理员的授权申请吗？
        </p>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="adminAuditCompanyInfo('approve')">确定</div>
        <div class="clearBtn" @click="showAgreeDialog=false">取消</div>
      </div>
    </el-dialog>
    <!-- 退回 -->
    <el-dialog class="dialog dialog-drafts" :title="'授权申请（退回）'" :append-to-body="true" :lock-scroll="true" :visible.sync="showBackDialog" width="840px" center :close-on-click-modal="false" @close="$refs['ruleForm'].resetFields()">
      <div class="drafts-list">
        <el-form :model="form" :rules="rules" ref="ruleForm">
          <el-form-item prop="approveMsg">
            <el-input type="textarea" v-model="form.approveMsg" :rows="4" placeholder="请输入退回原因..." maxlength="200" show-word-limit />
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="adminAuditCompanyInfo('reject')">确定</div>
        <div class="clearBtn" @click="showBackDialog=false;$refs['ruleForm'].resetFields()">取消</div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import DvCompanyMessageInfo from "@/components/fkProject/DvCompanyMessageInfo";
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import { viewFile } from '@/utils/orderUtil';
export default {
  components: {
    Loading,
    PanelTitle,
    DvCompanyMessageInfo,
  },
  props: ["baseInfo"],
  data() {
    return {
      isLoading: false,

      bs: '', // （"S"：供应商；"B"：采购商）
      showAgreeDialog: false,
      showBackDialog: false,

      list: [],
      listPageIndex: 1,
      approveId: '',
      approveLst: [],
      form: {
        approveMsg: '',// 意见反馈
      },
      fileList: [],
      params: {},

      corpId: "",
      approveDefId: "",
      rules: {
        approveMsg: [
          { required: true, message: '请输入退回原因', trigger: 'blur' }
        ]
      },
      originalProjectManager: {},
      newProjectManager: {},
      detailbaseInfo: {},
      authorizeFile:[],
      approveStatus: '',
    }
  },
  computed: {
    staging(){
      return this.detailbaseInfo && this.detailbaseInfo.projectStageInfoList && this.detailbaseInfo.projectStageInfoList.find(i=> i.projectStageId == this.baseInfo.projectStageId) || {}
    }
  },
  filters: {
    operTypeFilter(item) {
      let status = ''
      switch (item) {
        case 'apply':
          status = '提交申请'
          break;
        case 'approve':
          status = '审核通过'
          break;
        case 'reject':
          status = '被拒绝'
          break;
        default:
          break;
      }
      return status
    }
  },
  methods: {
    handleGoBack() {
      this.$router.go(-1);
    },
    handleDownload(name = '', url = ''){
      if(!url) return this.$message.error('暂无下载地址')
      this.$download([{
        name: name,
        url: url
      }]).then(e => this.$message.success('下载完成'))
    },
    handleOpenAuthorization(authorizationUrl) {
      if (authorizationUrl) {
        viewFile(authorizationUrl)
      } else {
        this.$message.error("暂无预览地址")
      }
    },
    // 查询公司审批流水信息
    getAdminCompanyInfo() {
      let param = {
        approveId: this.approveId
      }
      InterfaceService.fkReviewProjectAdminConfirm(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.list = data.respData
          this.approveLst = data.respData.applyFlowList
          this.approveStatus = data.respData.approveStatus
          this.fileList = data.respData.approveAttachList
          this.originalProjectManager = data.respData.originalProjectManager || {}
          this.newProjectManager = data.respData.newProjectManager || {}
          if(this.newProjectManager.approveAttachList){
            this.authorizeFile = this.newProjectManager.approveAttachList.filter(i=> i.attachType === 'auth_word')
            if(this.newProjectManager.approveAttachList.filter(i=> i.attachType === '2').length){
              this.authorizeFile = this.newProjectManager.approveAttachList.filter(i=> i.attachType === '2')
            }
          }
          this.approveDefId = data.respData.approveDefId || ''
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 获取项目详情
    getProjectDetail(){
      let params = { //给予后端的入参
        projectId: this.baseInfo.projectId,
      };
      InterfaceService.getProjectDetail(params, data => {
        if (data.respData.respCode === '0000') {
          this.detailbaseInfo = data.respData || {};
        } else {
          this.$message.error(data.respData && data.respData.respMsg || '')
        }
      }, data => {
        this.$message.error(data.respData && data.respData.respMsg || '')
      }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 同意并签章
    handleClickAgree() {
      // window.open(this.$router.resolve({
      //   path: '/fkAuthorizeBsAgreeSign',
      //   query: {
      //     approveId: this.approveId,
      //     projectCorpId: this.baseInfo && this.baseInfo.corpId || '',
      //   }
      // }).href, '_blank')
      this.$router.push({
        path: '/fkAuthorizeBsAgreeSign',
        query: {
          approveId: this.approveId,
          projectCorpId: this.baseInfo && this.baseInfo.corpId || '',
          fkAuthorizeBaseInfo: encodeURIComponent(JSON.stringify(
            {
              approveId: this.approveId,
              corpId: this.corpId,
              approveDefId: this.approveDefId,
              projectId: this.baseInfo.projectId,
              projectStageId: this.baseInfo.projectStageId,
              searchType: this.baseInfo.searchType,
            }
          ))
        }
      })
    },
    // 管理员审核公司信息
    adminAuditCompanyInfo(approveType) {
      if (approveType == 'reject' && !this.check()) {
        return
      }
      let param = {
        approveId: this.approveId,
        approveType: approveType,
        approveMsg: this.form.approveMsg || '',
        projectCorpId: this.baseInfo && this.baseInfo.corpId || '',
        approveAttachList: this.fileList
      }

      InterfaceService.adminAuditCompanyInfo(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.showAgreeDialog = false
          this.showBackDialog = false
          this.$message.success('操作成功, 1秒后返回列表!')
          if (approveType == 'reject') {
            this.$refs['ruleForm'].resetFields()
          }
          setTimeout(e => {
            this.$emit('refresh')
          }, 1000)
        } else {
          this.$message.error(data.respData && data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 校验
    check() {
      let check = false
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          return check = true;
        } else {
          return check = false;
        }
      });
      return check
    },
  },
  mounted() {
    console.log(this.baseInfo, '--baseInfo');

    this.bs = this.baseInfo && this.baseInfo.name == 'authorizeBsListDetailsV' ? 'S' : 'B';
    this.approveId = this.baseInfo && this.baseInfo.approveId || ''
    this.corpId = this.baseInfo && this.baseInfo.corpId || ""
    this.approveDefId = this.baseInfo && this.baseInfo.approveDefId || ""
    this.params = JSON.parse(this.baseInfo && this.baseInfo.params || '{}')

    this.getAdminCompanyInfo()
    this.getProjectDetail()
  }
}
</script>

<style lang="scss" scoped>
/deep/ .panel-title {
  margin-bottom: 0 !important;
}
#authorizeBsListDetails {
  .content {
    padding-bottom: 60px;
    .order-info {
      margin-top: 14px;
      border-bottom: 1px solid #EEEEEE;
      padding-bottom: 25px;
      .order-info-title {
        margin-bottom: 10px !important;
      }
      .company-top li {
        line-height: 26px;
        &.changeInfo {
          height: 48px;
          line-height: 48px;
        }
        .company-left {
          display: inline-block;
          width: 49%;
          line-height: 26px;
          vertical-align: top;
          span {
            display: inline-block;
            height: 26px;
            line-height: 26px;
            text-align: right;
            color: #adadad;
            vertical-align: top;
            em {
              color: #e93340;
            }
          }
          .box {
            max-width: 400px;
            display: inline-block;
            .annex {
              width: 100%;
              .company-showtext {
                width: auto;
                max-width: 254px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
              }
            }
          }
          .one {
            width: 100%;
            .company-showtext {
              width: 900px;
            }
          }
        }
        .company-showtext {
          display: inline-block;
        }
      }
    }
    .list-content {
      table {
        margin-top: 20px;
        table-layout: fixed;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        td {
          padding: 16px 10px;
          vertical-align: middle;
          word-break: break-all;
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          border-bottom: 1px solid #eee;
          background: rgba(249, 249, 249, 1);
          color: rgba(136, 136, 136, 1);
          tr {
            td {
              padding: 13px 10px;
            }
          }
        }
        .tbody-row {
          &:hover {
            background: #f0f8ff;
          }
        }
        tbody {
          text-align: left;
          tr {
            border-bottom: 1px solid #eee;
            line-height: 18px;
          }
          td {
            span:hover {
              color: #0082ff;
              cursor: pointer;
              text-decoration: underline;
            }
            .time {
              width: 70px;
            }
          }
          .operate {
            color: rgba(0, 130, 255, 1);
            cursor: pointer;
          }
          .border-none {
            border-bottom: none;
          }
        }
      }
    }
  }
}
.searchbox {
  text-align: center;
  margin-top: 20px;
  display: flex;
  justify-content: center;
  .searchBtn {
    width: 120px;
    height: 34px;
    line-height: 34px;
    background: linear-gradient(
      122deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(255, 255, 255, 1);
    margin-right: 20px;
    display: inline-block;
    cursor: pointer;
  }
  .clearBtn {
    width: 120px;
    height: 34px;
    line-height: 32px;
    border: 1px solid rgba(201, 159, 79, 1);
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(201, 159, 79, 1);
    display: inline-block;
    cursor: pointer;
  }
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
</style>