<template>
  <div class="activate-wrap">
    <div class="activate-wrap-inner" id="activate-wrap-inner">
      <div class="activate-wrap-inner">
        <div class="contain">
          <Breadcrumb :breadcrumbList="breadcrumb" @refresh="crumbRefresh"></Breadcrumb>
          <div class="approval-info" v-if="approveStatus && !['approved', 'init'].includes(approveStatus)">
            <p v-if="approveStatus === 'submited'">审核状态：待材料公司审核</p>
            <template v-if="approveStatus === 'rejected'">
              <p style="margin-bottom: 10px;">审核状态：材料公司已拒绝</p>
              <p>拒绝原因：{{applyFlowReject.approveMsg || ''}}</p>
            </template>
          </div>

          <template v-if="approveStatus !== 'submited'">
            <div style="margin-top: 20px;">
              <span class="order-info-title">公司授权管理员</span>
              <i class="red f12">需提供公司授权管理员以公司名义在大家采平台上进行操作的授权书。请点击【下载模板】，填写《大家采平台管理员授权委托书》并加盖公司公章后，上传授权书的PDF扫描件。</i>
            </div>
            <el-form ref="form" :model="form" :rules="formRules" label-width="195px">
              <div class="info-panel-content">
                <div class="form-inline-item">
                  <el-form-item label="管理员姓名：" prop="adminName">
                    <!-- <el-input v-model="form.adminName" placeholder="请输入姓名" @focus="checkForm('adminName')" maxlength="10"></el-input> -->

                    <el-select style="width: 100%;" clearable filterable default-first-option remote allow-create
                      v-model="form.adminName"
                      placeholder="请输入姓名"
                      @change="handleChangeRole($event)"
                      @focus="checkForm('adminName');acctList = acctListCopy"
                      :filter-method="handleGetValue"
                    >
                      <el-option v-for="(person,index) in acctList" :label="person.acctName" :value="person.acctId" :key="person.acctId + index">
                      </el-option>
                    </el-select>

                    <div class="el-form-item__error" v-if="errorRules['adminName']">
                      {{ errorRules["adminName"] }}
                    </div>
                  </el-form-item>
                  <el-form-item label="管理员身份证号：" prop="adminCertNo">
                    <el-input :disabled="adminCertNoDisabled && form.adminCertNo != ''" v-model="form.adminCertNo" placeholder="请输入身份证号" @focus="checkForm('adminCertNo')"></el-input>
                    <div class="el-form-item__error" v-if="errorRules['adminCertNo']">
                      {{ errorRules["adminCertNo"] }}
                    </div>
                  </el-form-item>
                </div>
                <div class="form-inline-item">
                  <el-form-item label="管理员手机号：" prop="adminMobile">
                    <el-input :disabled="adminMobileDisabled && form.adminMobile != ''" v-model="form.adminMobile" placeholder="请输入手机号" @focus="checkForm('adminMobile')"></el-input>
                    <div class="el-form-item__error">
                      ※该手机号将作为管理员登录大家采的账号
                    </div>
                  </el-form-item>
                  <el-form-item label="管理员邮箱：" prop="adminEmail">
                    <el-autocomplete ref="autocomplete" :disabled="adminEmailDisabled && form.adminEmail != ''" :fetch-suggestions="querySearch" :trigger-on-focus="false" v-model="form.adminEmail" placeholder="请输入邮箱" @focus="checkForm('adminEmail')"></el-autocomplete>
                    <div class="el-form-item__error" v-if="errorRules['adminEmail']">
                      {{ errorRules["adminEmail"] }}
                    </div>
                  </el-form-item>
                  <el-form-item label="部门：" prop="department">
                    <el-input :disabled="departmentDisabled && form.department != ''" v-model="form.department" placeholder="请输入部门" @focus="checkForm('department')" maxlength="50"></el-input>
                    <div class="el-form-item__error" v-if="errorRules['department']">
                      {{ errorRules["department"] }}
                    </div>
                  </el-form-item>
                  <el-form-item label="职务：" prop="position">
                    <el-input :disabled="positionDisabled && form.position != ''" v-model="form.position" placeholder="请输入职务" @focus="checkForm('position')" maxlength="40"></el-input>
                    <div class="el-form-item__error" v-if="errorRules['position']">
                      {{ errorRules["position"] }}
                    </div>
                  </el-form-item>
                </div>
                <div class="form-item" style="width:70%;">
                  <el-form-item label="授权委托期：" prop="effectiveStartdate">
                    <el-row>
                      <el-col :span="11">
                        <el-date-picker value-format="yyyy-MM-dd" v-model="form.effectiveStartdate" size="" type="date" placeholder="开始日期">
                        </el-date-picker>
                      </el-col>
                      <el-col :span="2" class="tc">~</el-col>
                      <el-col :span="11">
                        <el-date-picker value-format="yyyy-MM-dd" v-model="form.effectiveEnddate" size="" type="date" placeholder="结束日期">
                        </el-date-picker>
                      </el-col>
                    </el-row>
                    <div class="el-form-item__error" v-if="errorRules['effectiveStartdate']">
                      {{ errorRules["effectiveStartdate"] }}
                    </div>
                  </el-form-item>
                </div>
              </div>
              <el-form-item label="上传授权书" :rules="{ required:'true',message: '请上传授权书'}" class="authorization" prop="attachUrl" width="80px">
                <UpfileComponent :isWidth="true" ref="upfileRef" :immediateClearList="true" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :btnName="'上传'" :dirName="`${new Date().getTime()}/`" :type="'13'" :fileTypes="uploadFileSuffix" :id="'123'" @outputList="handleUpFileResult($event)"></UpfileComponent>
                <span class="hand blue ml14" @click="handleDownTemp">下载授权书模板</span>
              </el-form-item>
            </el-form>
            <div class="upload-cont">
              <div class="upload-title" v-if="authorizationInfo.attachName">
                <span :title="authorizationInfo.attachName">
                  <em :class="{blue:showFile, hand:showFile}" @click="showFile && handleOpenAuthorization(authorizationInfo.attachUrl)">{{authorizationInfo.attachName}}</em>
                </span>
                <span>
                  <i class="hand blue" @click="delFileInfo">删除</i>
                </span>
              </div>
              <div v-else class="undata">未上传附件！</div>
            </div>
            <div class="tc">
              <el-button type="primary" class="large-btn" @click="handleSubmit">{{approveStatus === 'rejected' ? '重新' : ''}}提交</el-button>
            </div>
          </template>
          <div class="change-content original-info" v-if="approveStatus == 'submited'">
            <div class="order-info-title">管理员账户信息</div>
            <el-row>
              <el-col :span="24">
                <span class="color888">公司名称：</span>
                <span>{{form.corpName || '无'}}</span>
              </el-col>
              <el-col :span="12">
                <span class="color888">姓名：</span>
                <span>{{form.adminName || '无'}}</span>
              </el-col>
              <el-col :span="12" class="display-flex">
                <span class="color888">授权书：</span>
                <ul v-if="authorizationInfo.attachName">
                  <li>
                    <span>{{authorizationInfo.attachName}}&emsp;</span>
                    <span v-if="authorizationInfo.attachName" class="hand blue" @click="handleOpenAuthorization(authorizationInfo.attachUrl)">查看</span>
                  </li>
                </ul>
                <span v-else>无</span>
              </el-col>

              <el-col :span="12">
                <span class="color888">手机号：</span>
                <span class="company-showtext">{{form.mobile || form.adminMobile || "无"}}</span>
              </el-col>

              <el-col :span="12">
                <span class="color888">邮箱：</span>
                <span class="company-showtext">{{form.email || form.adminEmail || "无"}}</span>
              </el-col>

              <el-col :span="12">
                <span class="color888">部门：</span>
                <span class="company-showtext">{{form.department || "无"}}</span>
              </el-col>

              <el-col :span="12">
                <span class="color888">职位：</span>
                <span class="company-showtext">{{form.position || "无"}}</span>
              </el-col>

              <el-col :span="12">
                <span class="color888">身份证号：</span>
                <span class="company-showtext">{{form.certNo || form.adminCertNo || "无"}}</span>
              </el-col>

              <!-- <el-col :span="12">
                <span class="color888">角色：</span>
                <span v-if="newAdminRoles.length">{{newAdminRoles.join("，")}}</span>
              </el-col> -->
            </el-row>

            <el-row style="margin-top: 60px;">
              <el-col :span="24" class="tc">
                <el-button class="normal-btn" @click="handleCancel">返回</el-button>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
    </div>

    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { mapActions, mapState } from "vuex";
import SearchBar from "@/components/SearchBar";
import Header from "@/components/base/Header";
import Loading from "@/components/base/Loading";
import PwdStrength from "@/components/base/PwdStrength";
import ValidateCode from "@/components/base/ValidateCode";
import PhoneCode from "@/components/base/PhoneCode";
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import { DateUtil } from "@/utils/dateUtil";
import Breadcrumb from "@/components/base/Breadcrumb";

import { InterfaceService } from "@/services/api";
import CryptoJS from "crypto-js";
import { viewFile } from "@/utils/orderUtil";

export default {
  props: ["corpId", "projectAdmin"],
  components: {
    SearchBar,
    Header,
    Loading,
    PwdStrength,
    ValidateCode,
    UpfileComponent,
    Breadcrumb,
    PhoneCode,
  },
  data() {
    var validateEffectiveStartdate = (rule, value, callback) => {
      if (value) {
        var thetimeFirst = value;
        var thetimeSecond = this.form.effectiveEnddate;
        if (thetimeSecond && thetimeFirst > thetimeSecond) {
          this.form.effectiveStartdate = "";
          // this.form.dealTo = ''
          callback(new Error("请选择有效的授权委托期"));
        } else {
          callback();
        }
      } else {
        callback();
      }
    };
    var validatePass = (rule, value, callback) => {
      if (value === "") {
        callback(new Error("请输入密码"));
      } else {
        this.ruleForm.inputPwd = this.ruleForm.inputPwd.replace(
          /[^\u4e00-\u9fa5\w]/g,
          ""
        );
        if (this.ruleForm.inputPwd.length >= 18) {
          this.ruleForm.inputPwd = this.ruleForm.inputPwd.substr(0, 18);
        }
        if (this.strength <= 1) {
          callback(new Error("密码设置不符合要求"));
        } else {
          callback();
        }
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (
        !/^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-zA-Z0-9]+[-a-z0-9]*[a-zA-Z0-9]+.){1,63}[a-zA-Z0-9]+$/.test(
          value
        )
      ) {
        callback(new Error("邮箱格式不正确"));
      } else {
        const mail = value || "",
          mailSuffix = mail.slice(mail.lastIndexOf(".") + 1, mail.length);

        const errorMailSuffix = JSON.parse(
          this.$getRootLocalStorage("errorMailSuffix") || "[]"
        );
        if (errorMailSuffix.includes(mailSuffix)) {
          callback(new Error("邮箱后缀不正确"));
          return;
        }
        callback();
      }
    };

    var identifyCodeValueChange = (rule, value, callback) => {
      console.log(this.ruleForm.identifyCode, "identifyCode-");
      if (
        this.ruleForm.identifyCode === "" ||
        this.ruleForm.identifyCode === undefined
      ) {
        callback(new Error("请输入验证码"));
      } else {
        callback();
      }
    };

    return {
      breadcrumb: [],
      updateCode: 0,
      validateCode: "", // 图片验证码
      isWhiteBg: true,
      pageName: "激活账户",
      searchType: 5,
      isLoading: false,
      strength: "",
      instant: "",
      errorRules: {},
      identifyCode: "", // 手机验证码
      errorMsg: {},
      form: {
        approveDefId: "ADMIN_ACTIVATE_APPROVE",
        effectiveStartdate: "",
        effectiveEnddate: "",
        adminName: "",
        adminCertNo: "",
        adminMobile: "",
        department: "",
        position: "",
        adminEmail: "",
        attachUrl: "",
      },
      ruleForm: {
        inputPwd: "", // 默认密码
        confirmPwd: "", // 新密码
      },
      rules: {
        inputPwd: [{ required: true, message: "请输入密码", trigger: "blur" }],
        confirmPwd: [
          { required: true, message: "请确认密码", trigger: "blur" },
        ],
        validateCode: [],
        // identifyCode:[{required: true, message: "请输入验证码",trigger: 'blur'}]
        identifyCode: [
          { validator: identifyCodeValueChange, trigger: "change" },
        ],
      },
      formRules: {
        adminName: [
          {
            required: true,
            message: "必填",
          },
          {
            pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]{2,200}$/,
            max: 200,
            message: "姓名设置不符合要求",
            trigger: "blur",
          },
        ],
        adminCertNo: [
          {
            required: true,
            message: "必填",
          },
          {
            pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/,
            max: 20,
            message: "身份证号码不正确",
            trigger: "blur",
          },
        ],
        adminMobile: [
          {
            required: true,
            message: "必填",
          },
          {
            pattern: /^[1][0-9][0-9]{9}$/,
            max: 11,
            message: "手机号格式不正确",
            trigger: "blur",
          },
        ],
        adminEmail: [
          {
            required: true,
            message: "必填",
          },
          { validator: validatePass2, trigger: "blur" },
        ],
        department: [
          {
            required: true,
            message: "必填",
          },
          { max: 50, message: "部门名称不得大于50个字", trigger: "blur" },
        ],
        position: [
          {
            required: true,
            message: "必填",
          },
          { max: 40, message: "职务名称不得大于40个字", trigger: "blur" },
        ],
        effectiveStartdate: [
          {
            required: true,
            message: "必填",
          },
          { validator: validateEffectiveStartdate, trigger: "blur" },
        ],
      },
      templateFileUrl: "",
      templateFileName: "",
      uploadFileSuffix: "",
      delId: "",
      authorizationInfo: {},

      originalProjectManager: {},
      newProjectManager: {},
      applyFlowList: [],
      applyFlowReject: {}, // 拒绝
      applyFlowApply: {}, // 申请
      newAdminRoles: [],
      submitAdminInfo: {},

      acctListCopy:[],
      acctList:[],
      adminCertNoDisabled: false,
      adminMobileDisabled: false,
      adminEmailDisabled: false,
      departmentDisabled: false,
      positionDisabled: false,
    };
  },
  computed: {
    showFile() {
      return (
        this.authorizationInfo &&
        this.authorizationInfo.attachUrl &&
        (this.authorizationInfo.attachUrl.indexOf("http://") != -1 ||
          this.authorizationInfo.attachUrl.indexOf("https://") != -1)
      );
    },
    projectApprove() {
      return (this.projectAdmin && this.projectAdmin.adminProjectApprove) || {};
    },
    approveStatus() {
      return this.projectApprove.approveStatus || "";
    },
    isLogin() {
      return this.$store.state.isLogin;
    },
    isIE11() {
      let userAgent = navigator.userAgent;
      return (
        userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1
      ); // ie11<11
    },
    userInfo() {
      // console.log(this.$store.state.LoginedUser.custName)
      return this.$store.state.userInfo;
    },
    canView() {
      return (
        this.authorizationInfo.attachUrl &&
        this.authorizationInfo.attachUrl.indexOf("https") != -1
      );
    },
  },

  methods: {
    ...mapActions(["setUserInfoAction"]),
    handleCancel() {
      this.$emit("refresh");
    },
    
    // 查询公司下属账户信息
    getQuerySubordinate(){
      let param = {
        corpId: this.corpId,
      };
      InterfaceService.getQuerySubordinate(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.acctListCopy = data.respData.acctList || [];
          this.acctList = data.respData.acctList || [];
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    handleGetValue(val) {
      this.inputValue = val;
      if (val) { //val存在
        this.acctList = this.acctListCopy.filter((item) => {
          if (!!~item.acctName.indexOf(val) || !!~item.acctName.toUpperCase().indexOf(val.toUpperCase())) {
            return true
          }
        })
      } else { //val为空时，还原数组
        this.acctList = this.acctListCopy;
      }
    },
    handleChangeRole(ev){
      console.log(ev)
      let off = true
      this.acctListCopy.forEach(item=>{
        if (item.acctId === ev) {
          this.form.adminName = item.acctName || ''
          this.form.adminCertNo = item.certNo || ''
          this.form.adminMobile = item.mobile || ''
          this.form.adminEmail = item.email || ''
          this.form.department = item.dept || ''
          this.form.position = item.title || ''
          this.handleDisabled()
          off = false
        }
      });
      if(off){
        this.form.adminCertNo = ''
        this.form.adminMobile = ''
        this.form.adminEmail = ''
        this.form.department = ''
        this.form.position = ''
        this.adminCertNoDisabled = false
        this.adminMobileDisabled = false
        this.adminEmailDisabled = false
        this.departmentDisabled = false
        this.positionDisabled = false
      }
    },

    querySearch(queryString, callback) {
      let commonMailbox = this.$commonMailbox()
      let results = this.$clone(commonMailbox)
      let value = ''
      if(queryString && queryString.indexOf('@') != -1){
        value = queryString.substring(0, queryString.indexOf('@'))
      }else{
        value = queryString
      }
      results.forEach((i,index) =>{
          i.value = value + '' + commonMailbox[index].value
      })
      callback(results)
      this.$refs.autocomplete.handleFocus()
    },
    handleSubmit() {
      // if (!this.authorizationInfo.attachName) {
      //   this.$message.error('请上传授权书')
      //   return false
      // }
      console.log(this.form.department, "--form.department");
      this.form.department = this.$trim(this.form.department);
      this.form.position = this.$trim(this.form.position);

      this.$refs.form.validate((valid) => {
        if (valid) {
          this.$confirm(
            `您是否确认将${this.form.adminName}设置为${
              (this.projectAdmin && this.projectAdmin.projectName) || ""
            }的项目管理员？`,
            "提示信息",
            {
              cancelButtonClass: "btn-custom-cancel",
              confirmButtonClass: "btn-custom-confirm",
              center: true,
              confirmButtonText: "确认",
              cancelButtonText: "取消",
            }
          )
            .then(() => {
              if (this.approveStatus === "rejected") {
                this.adminApproval();
                return;
              }
              this.fkApplyProjectAdmin();
            })
            .catch(() => {});
        }
      });
    },

    // 申请
    fkApplyProjectAdmin() {
      let params = Object.assign({}, this.form);
      params.approveType = "apply";
      params.corpId = this.corpId;
      params.approveAttachList = [
        {
          attachType: "2",
          attachName: this.authorizationInfo.attachName,
          attachUrl: this.authorizationInfo.attachPath,
        },
      ];

      params.approveId =
        (this.projectAdmin &&
          this.projectAdmin.adminProjectApprove &&
          this.projectAdmin.adminProjectApprove.approveId) ||
        "";

      InterfaceService.fkApplyProjectAdmin(
        params,
        (data) => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.$message.success("提交成功！");
            setTimeout((e) => {
              this.crumbRefresh();
            }, 1000);
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        (data) => {
          this.$message.error(data.respMsg);
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },

    // 拒绝后重新提交
    adminApproval() {
      let params = Object.assign({}, this.form);
      params.approveId =
        (this.projectAdmin &&
          this.projectAdmin.adminProjectApprove &&
          this.projectAdmin.adminProjectApprove.approveId) ||
        "";
      params.approveType = "apply";
      params.approveAttachList = [
        {
          attachType: "2",
          attachName: this.authorizationInfo.attachName,
          attachUrl:
            this.authorizationInfo.attachContent ||
            this.authorizationInfo.attachUrl ||
            this.authorizationInfo.attachPath ||
            "",
        },
      ];
      InterfaceService.adminApproval(
        params,
        (data) => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.$message.success("提交成功！");
            setTimeout((e) => {
              this.crumbRefresh();
            }, 1000);
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        (data) => {
          this.$message.error(data.respMsg);
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    handleViewFile() {
      if (this.canView) {
        viewFile(this.authorizationInfo.attachUrl);
      }
    },
    handleUpFileResult(e) {
      this.delFileInfo();
      const { file, name, targetValue, url } = e[0];
      this.authorizationInfo = {
        file: file,
        attachName: name,
        creTm: DateUtil.dateToString(),
        targetValue,
        attachPath: url,
        attachUrl: url,
      };
      this.form.attachUrl = this.authorizationInfo.attachUrl || "";
    },
    delFileInfo() {
      if (this.authorizationInfo.id) {
        this.delId = this.authorizationInfo.id;
      }
      this.authorizationInfo = {};
    },
    getOrderConfiguration() {
      const params = {
        businessType: "AUTHORIZATION",
      };
      InterfaceService.getOrderConfiguration(
        params,
        (data) => {
          let res = data.respData;
          if (res.respCode === "0000") {
            let list = res.uploadFileList || [];
            list.forEach((item) => {
              if (item.fileTypeId === "regist_authorization") {
                this.templateFileUrl = item.attachUrl || "";
                this.templateFileName = item.templateFileName || "";
                this.uploadFileSuffix = item.uploadFileSuffix || "";
              }
            });
          } else {
            this.$message.error(data.respMsg);
          }
        },
        (data) => {},
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    handleDownTemp() {
      this.$download([
        {
          name: this.templateFileName || "",
          url: this.templateFileUrl || "",
        },
      ])
        .then((result) => {
          this.$message.success("已下载");
        })
        .catch((err) => {
          this.$message.error("下载失败");
        });
    },
    checkForm(key) {
      //密码验证
      if (key == "inputPwd") {
        this.ruleForm[key] = this.ruleForm[key].replace(
          /[^\u4e00-\u9fa5\w]/g,
          ""
        );

        if (this.ruleForm[key].length >= 18) {
          this.ruleForm[key] = this.ruleForm[key].substr(0, 18);
        }

        if (!this.ruleForm[key]) {
          this.errorMsg[key] = "请输入密码";
        }
        if (this.ruleForm[key] && this.strength <= 1) {
          this.errorMsg[key] = "密码设置不符合要求";
          // if(this.model[key] == this.model['acctName']){
          //   this.loginPwdError = true
          // }
          this.$forceUpdate();
          this.$set(this.ruleForm, this.ruleForm);
          this.$set(this.errorMsg, this.errorMsg);
          return false;
        } else {
          delete this.errorMsg[key];
        }

        if (
          this.ruleForm.confirmPwd &&
          this.ruleForm.confirmPwd != this.ruleForm.inputPwd
        ) {
          this.errorMsg["confirmPwd"] = "两次输入的密码不一致，请重新输入";
        } else {
          //delete this.errorMsg['inputPwd']
          delete this.errorMsg["confirmPwd"];
        }
      }
      //密码验证
      if (key == "confirmPwd") {
        if (!this.ruleForm[key]) {
          this.errorMsg[key] = "请确认密码";
        }
        if (
          this.ruleForm.inputPwd &&
          this.ruleForm.confirmPwd != this.ruleForm.inputPwd
        ) {
          this.errorMsg[key] = "两次输入的密码不一致，请重新输入";
        } else {
          delete this.errorMsg[key];
        }
      }
      this.$forceUpdate();
      this.$set(this.ruleForm, this.ruleForm);
      this.$set(this.errorMsg, this.errorMsg);
    },
    getPwdStrength: function (strength) {
      //strength = 1弱
      this.strength = strength;
    },
    getPwdInstant(instant) {
      this.instant = instant;
    },
    getCode: function (code) {
      this.ruleForm.validateCode = code;
      this.$forceUpdate();
      code && delete this.errorMsg["validateCode"];
    },
    getPhoneCode(identifyCode) {
      // 输入时 移除 后台返回 错误提示
      this.errorMsg.identifyCode = "";
      this.ruleForm.identifyCode = identifyCode; // 手机验证码
      this.$forceUpdate();
    },
    // 判断图形验证码是否正确
    getError(msg) {
      this.ruleForm.validateCode = "";
      this.updateCode++;
      this.$set(this.errorMsg, "validateCode", msg);
      this.$forceUpdate();
    },
    onSubmit(rules) {
      for (let key in this.errorMsg) {
        if (this.errorMsg[key]) {
          return false;
        }
      }
      // if(this.errorMsg['confirmPwd']){
      //   return false
      // }
      this.$refs.ruleForm.validate((valid) => {
        this.errorMsg = {};
        console.log(valid);
        if (valid) {
          let inputPwd = CryptoJS.MD5(this.ruleForm.inputPwd).toString();
          let confirmPwd = CryptoJS.MD5(this.ruleForm.confirmPwd).toString();
          var params = {
            mobile: this.$store.state.userInfo.mobileNo,
            inputPwd: inputPwd,
            confirmPwd: confirmPwd,
            validateCode: this.ruleForm.validateCode,
            identifyCode: this.ruleForm.identifyCode,
          };
          console.log(this.userInfo.attachUrl);
          //没有授权书，先上传授权书

          InterfaceService.activateTheAccount(params, (data) => {
            console.log(data);
            let res = data.respData;
            if (res.respCode == "MEM0026" || res.respCode == "MEM0093") {
              // 密码错误
              this.$set(this.errorMsg, "inputPwd", res.respMsg);
            } else if (res.respCode == "MEM0092") {
              // 确认密码错误
              this.$set(this.errorMsg, "confirmPwd", res.respMsg);
            } else if (res.respCode == "MEM0025" || res.respCode == "MEM0141") {
              // 手机号错误
              this.$alert("手机号错误", {
                customClass: "alert-box",
                center: true,
                confirmButtonText: "知道了",
                callback: (action) => {},
              });
            } else if (res.respCode == "0000" || res.respCode == "MEM0029") {
              // 成功和已激活
              let adminRoles = [
                "1000",
                "2000",
                "3000",
                "4000",
                "5000",
                "9000",
              ];
              let isAdmin =
                this.userInfo.roleIds &&
                this.userInfo.roleIds.some((item) => {
                  return adminRoles.indexOf(item.roleId) != -1;
                });
              if (isAdmin && !this.userInfo.attachUrl) {
                window.scrollTo(0, 0);
                this.getOrderConfiguration();
              } else {
                this.userInfo.custStatus = "0";
                this.$removeRootScope("registerPath");
                if (this.userInfo && this.userInfo.bs == "B") {
                  this.$router.push("/purchaserCenter/accountInfo");
                } else {
                  this.$router.push("/vendorCenter/accountInfo");
                }
              }
            } else if (res.respCode == "MEM0028") {
              // 激活失败
              this.$alert("激活失败", {
                customClass: "alert-box",
                center: true,
                confirmButtonText: "知道了",
                callback: (action) => {},
              });
            }
            // else if (res.respCode == 'MEM0030') {
            //   // 账户冻结
            //   this.$alert(
            //     "账户冻结",
            //     {
            //       customClass: "alert-box",
            //       center: true,
            //       confirmButtonText: "知道了",
            //       callback: action => {}
            //     }
            //   );
            // }
            else if (res.respCode == "F000002") {
              this.$set(this.errorMsg, "validateCode", res.respMsg);
            } else if (res.respCode == "F000003" || res.respCode == "F000005") {
              this.$set(this.errorMsg, "identifyCode", res.respMsg);
              if (res.respCode == "F000005") {
                this.updateCode++;
              }
            }
          });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
    formatDate(datetime) {
      let date = new Date(datetime);
      let year = date.getFullYear(),
        month = ("0" + (date.getMonth() + 1)).slice(-2),
        sdate = ("0" + date.getDate()).slice(-2),
        hour = ("0" + date.getHours()).slice(-2),
        minute = ("0" + date.getMinutes()).slice(-2),
        second = ("0" + date.getSeconds()).slice(-2);
      // 拼接
      let result =
        year +
        "-" +
        month +
        "-" +
        sdate +
        " " +
        hour +
        ":" +
        minute +
        ":" +
        second;
      // 返回
      return result;
    },

    handleOpenAuthorization(authorizationUrl) {
      if (authorizationUrl) {
        viewFile(authorizationUrl);
      } else {
        this.$message.error("暂无预览地址");
      }
    },

    crumbRefresh() {
      this.$emit("refresh", true);
    },

    getAdminCompanyInfo(approveId) {
      let param = {
        approveId,
      };
      InterfaceService.getAdminCompanyInfo(
        param,
        (data) => {
          this.isLoading = false;
          if (data && data.respData && data.respData.respCode === "0000") {
            this.submitAdminInfo = data.respData || {};

            this.applyFlowList = data.respData.applyFlowList || [];
            // 拒绝 显示对象
            this.applyFlowReject =
              this.applyFlowList.find(
                (f) => f.approveId == approveId && f.operType == "reject"
              ) || {};
            // 申请 显示对象
            this.applyFlowApply =
              this.applyFlowList.find(
                (f) => f.approveId == approveId && f.operType == "apply"
              ) || {};

            // 新管理员
            this.newProjectManager.acctName = this.submitAdminInfo.name;
            this.newProjectManager.approveMsg =
              this.applyFlowApply.approveMsg || "";
            this.newProjectManager.approveAttachList =
              this.submitAdminInfo.approveAttachList || [];
            this.newAdminRoles = [];
            this.submitAdminInfo.roleList &&
              this.submitAdminInfo.roleList.forEach((f) => {
                this.newAdminRoles.push(f.roleName);
              });

            // 反显管理员数据
            if (["init", "submited", "rejected"].includes(this.approveStatus)) {
              this.form.acctId = this.submitAdminInfo.acctId || "";
              this.form.approveMsg = this.applyFlowApply.approveMsg || "";
              this.authorizationInfo =
                (this.submitAdminInfo.approveAttachList &&
                  this.submitAdminInfo.approveAttachList[0]) ||
                {};
              this.form.attachUrl = this.authorizationInfo.attachUrl || "";

              this.form.corpName = this.submitAdminInfo.corpName;
              this.form.adminName = this.submitAdminInfo.name;
              this.form.adminCertNo = this.submitAdminInfo.certNo;
              this.form.adminMobile = this.submitAdminInfo.mobile;
              this.form.adminEmail = this.submitAdminInfo.email;
              this.form.department = this.submitAdminInfo.department;
              this.form.position = this.submitAdminInfo.position;
              this.form.effectiveStartdate = this.submitAdminInfo.effectiveStartdate;
              this.form.effectiveEnddate = this.submitAdminInfo.effectiveEnddate;
              this.handleDisabled()
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        (data) => {},
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    handleDisabled(){
      if(this.form.adminCertNo){
        this.adminCertNoDisabled = true
      }
      if(this.form.adminMobile){
        this.adminMobileDisabled = true
      }
      if(this.form.adminEmail){
        this.adminEmailDisabled = true
      }
      if(this.form.department){
        this.departmentDisabled = true
      }
      if(this.form.position){
        this.positionDisabled = true
      }
    },
  },
  mounted() {
    console.log(this.projectAdmin, "projectAdmin");
    this.$setRootScope(
      "registerPath",
      JSON.stringify({ path: this.$route.path, query: this.$route.query })
    );
    let adminRoles = ["1000", "2000", "3000", "4000", "5000", "9000"];
    let isAdmin =
      this.userInfo.roleIds &&
      this.userInfo.roleIds.some((item) => {
        return adminRoles.indexOf(item.roleId) != -1;
      });

    this.breadcrumb = [
      { name: "管理中心", path: "/purchaserCenter/accountInfo" },
      { name: "公司管理信息-查看项目及分期", goBack: true },
      { name: "设置项目管理员" },
    ];

    // 如果是提交待审 查询详情 获取 替换 - 最新人员信息
    if (["init", "submited", "rejected"].includes(this.approveStatus)) {
      this.getAdminCompanyInfo(this.projectApprove.approveId || "");
    }

    this.getOrderConfiguration();
    this.getQuerySubordinate();
  },
  watch: {},
};
</script>

<style lang="scss" scoped>
.guid-text {
  font-size: 12px;
  color: #888;
  line-height: 20px;
  i {
    margin-right: 8px;
  }
}
.activate-wrap .search-bar-container {
  height: 100%;
  padding-top: 15px;
}

.activate-wrap-inner {
  height: 710px;
}

.activate-wrap .contain {
  position: relative;
  height: 100%;
}

.activate-wrap .form {
  width: 660px;
  position: absolute;
  right: 0;
  top: 0;
  left: 0;
  bottom: 0;
  margin: auto;
  margin-top: 110px;

  .el-button {
    width: 262px;
    height: 50px;
    border: 0;
    margin-left: 200px;
    margin-top: 40px;
  }
}

.activate-wrap .form .hint {
  font-size: 14px;
  line-height: 24px;
  font-weight: 900;
  margin-bottom: 30px;
  i {
    color: #5dc539;
    font-size: 16px;
  }

  .phone {
    color: red;
    font-weight: 700;
  }

  span:nth-last-child(1) {
    margin-left: 22px;
    font-weight: 700;
    color: #989898;
  }
}
.order-info-title {
  margin: 40px 0 20px;
  padding: 0 10px;
  font-size: 16px;
  border-left: 3px solid #000;
  line-height: 12px;
}
.neet-upload-upfile {
  box-sizing: border-box;
  padding-left: 20px;
  display: flex;
  border-top: 1px solid transparent;

  &.disabled {
    /deep/ .center .blue {
      // background: #dddddd !important;
      // color: #a9a9a9 !important;
    }
  }

  & > li {
    width: 82%;

    &:nth-child(1) {
      .input-file-p {
        border: 1px solid #dcdfe6;
        box-sizing: border-box;
        padding: 0 12px;
        color: #606266;
        display: block;
        display: flex;
        flex-wrap: wrap;
        min-height: 40px;

        span {
          height: 38px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        & > .gray {
          color: #c0c4cc;
          font-size: 12px;
          outline: none;
          height: 38px;
        }

        .el-tag {
          margin: 4px;
          height: 30px;
        }
      }
    }

    &:nth-child(2) {
      width: 15%;
    }

    &:nth-child(3) {
      width: 33%;
    }

    .el-button--default {
      height: 40px;
      margin-left: 4px;
    }
  }

  .el-button--primary {
    width: 119px;
    margin-right: 12px;
  }

  /deep/ .upfile-container {
    .center {
      label {
        width: 120px;
        background: linear-gradient(
          120deg,
          rgba(215, 176, 100, 1) 0%,
          rgba(236, 206, 139, 1) 100%
        );
        color: #fff !important;
        text-align: center;
        height: 40px;
      }
    }
  }
}
.upload-cont {
  margin: 20px 25px 30px 215px;
}
.upload-title {
  background: #f5f5f5;
  border-bottom: 1px solid #fff;
  height: 35px;
  line-height: 35px;

  span {
    display: inline-block;
    padding-left: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  & span:nth-child(1) {
    width: 65%;
  }
  & span:nth-child(2) {
    width: 25%;
  }
}
.authorization {
  margin-bottom: 0 !important;
  /deep/ .el-form-item__error {
    margin-top: -12px;
  }
}
.info-panel-content {
  padding: 20px;
  padding-bottom: 0;
  padding-right: 30px;
  background: #fff;
  &.bottom {
    padding-bottom: 20px;
  }
  /deep/ .el-form-item__error {
    background: #fff;
    width: 100%;
    height: 22px;
  }
}
.form-inline-item {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;

  & > div {
    width: 46%;
    flex-shrink: 0;
  }

  &.col-3 > div {
    width: 32%;
  }
}

.approval-info {
  width: 100%;
  border: 1px solid #d7b064;
  margin-bottom: 20px;
  vertical-align: middle;
  font-size: 14px;
  padding: 20px;
}
.original-info {
  font-size: 12px;
  padding-bottom: 10px;
  .el-col {
    margin-top: 10px;
  }
}
.display-flex {
  display: flex;
}

.line {
  height: 1px;
  background: #eeeeee;
  margin-bottom: 20px;
  margin-top: 10px;
}
.ml14 {
  margin-left: 8px;
}
.upfilenotice {
  font-size: 12px;
}

.upload-title {
  font-size: 12px;
  span {
    margin-right: 10px;
  }
}
.authorization {
  margin-bottom: 0 !important;
  /deep/ .el-form-item__label {
    text-align: left;
    color: #444 !important;
    width: 80px !important;
  }
  /deep/ .el-form-item__content {
    margin-left: 80px !important;
  }
}
.upload-cont {
  padding: 14px;
  border: 1px solid #ddd;
  margin-top: 8px;
  width: auto;
  margin-left: 0;
  .upload-title {
    font-size: 12px !important;
    background: #fff;
    height: auto;
    line-height: initial;
    span {
      padding-left: 0;
      &:nth-child(1) {
        width: auto;
      }
      &:nth-child(2) {
        width: auto;
      }
    }
  }
  .undata {
    font-size: 12px;
    color: #bbb;
  }
}
</style>