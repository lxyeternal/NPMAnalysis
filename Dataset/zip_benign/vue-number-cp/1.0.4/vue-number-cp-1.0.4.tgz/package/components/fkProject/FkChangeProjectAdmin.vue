<template>
  <div>
    <div class="approval-info" v-if="approveStatus && approveStatus !== 'approved' ">
      <p v-if="approveStatus === 'submited'">审核状态：待材料公司审核</p>
      <template v-if="approveStatus === 'rejected'">
        <p style="margin-bottom: 10px;">审核状态：材料公司已拒绝</p>
        <p>拒绝原因：{{applyFlowReject.approveMsg || ''}}</p>
      </template>
    </div>
    <template>
      <div class="info-title">
        原有项目管理员信息
      </div>
      <div class="change-content original-info">
        <el-row>
          <el-col :span="12">
            <span class="color888">姓名：</span>
            <span>{{projectAdmin && projectAdmin.adminCustName ||''}}</span>
          </el-col>
          <el-col :span="12" class="display-flex">
            <span class="color888">授权书：</span>
            <ul>
              <li class="or-name-li" v-for="item in projectAdmin && projectAdmin.adminAttachList || []" :key="item.attachId">
                <span class="or-name" :title="item.attachName">{{item.attachName}}</span>
                <span v-if="item.attachName" class="hand blue" @click="handleOpenAuthorization(item.attachUrl)">查看</span>
              </li>
            </ul>
          </el-col>
        </el-row>
      </div>
    </template>
    <div class="info-title">
      变更项目管理员
    </div>
    <div class="change-content" v-if="approveStatus !== 'submited'">
      <el-form ref="form" :model="form" :rules="formRules" label-width="130px">
        <div class="info-panel-content">
          <div class="form-inline-item">
            <el-form-item label="管理员姓名：" prop="adminName">
              <el-select style="width: 100%;" clearable filterable default-first-option remote allow-create
                v-model="form.adminName"
                placeholder="请输入姓名"
                @change="handleChangeRole($event)"
                @focus="acctList = acctListCopy"
                :filter-method="handleGetValue"
              >
                <el-option v-for="(person,index) in acctList" :label="person.acctName" :value="person.acctId" :key="person.acctId + index">
                </el-option>
              </el-select>

              <div class="el-form-item__error" v-if="errorRules['adminName']">
                {{ errorRules["adminName"] }}
              </div>
            </el-form-item>
            <el-form-item label="管理员身份证号：" prop="adminCertNo">
              <el-input :disabled="adminCertNoDisabled && form.adminCertNo != ''" v-model="form.adminCertNo" placeholder="请输入身份证号"></el-input>
              <div class="el-form-item__error" v-if="errorRules['adminCertNo']">
                {{ errorRules["adminCertNo"] }}
              </div>
            </el-form-item>
          </div>
          <div class="form-inline-item">
            <el-form-item label="管理员手机号：" prop="adminMobile">
              <el-input :disabled="adminMobileDisabled && form.adminMobile != ''" v-model="form.adminMobile" placeholder="请输入手机号"></el-input>
              <div class="el-form-item__error">
                ※该手机号将作为管理员登录大家采的账号
              </div>
            </el-form-item>
            <el-form-item label="管理员邮箱：" prop="adminEmail">
              <el-autocomplete ref="autocomplete" :disabled="adminEmailDisabled && form.adminEmail != ''" :fetch-suggestions="querySearch" :trigger-on-focus="false" v-model="form.adminEmail" placeholder="请输入邮箱"></el-autocomplete>
              <div class="el-form-item__error" v-if="errorRules['adminEmail']">
                {{ errorRules["adminEmail"] }}
              </div>
            </el-form-item>
            <el-form-item label="部门：" prop="department">
              <el-input :disabled="departmentDisabled && form.department != ''" v-model="form.department" placeholder="请输入部门" maxlength="50"></el-input>
              <div class="el-form-item__error" v-if="errorRules['department']">
                {{ errorRules["department"] }}
              </div>
            </el-form-item>
            <el-form-item label="职务：" prop="position">
              <el-input :disabled="positionDisabled && form.position != ''" v-model="form.position" placeholder="请输入职务" maxlength="40"></el-input>
              <div class="el-form-item__error" v-if="errorRules['position']">
                {{ errorRules["position"] }}
              </div>
            </el-form-item>
          </div>
          <div class="form-item" style="width:70%;">
            <el-form-item label="授权委托期：" prop="effectiveStartdate">
              <el-row>
                <el-col style="width: 220px">
                  <el-date-picker value-format="yyyy-MM-dd" v-model="form.effectiveStartdate" size="" type="date" placeholder="开始日期">
                  </el-date-picker>
                </el-col>
                <el-col :span="2" class="tc">~</el-col>
                <el-col style="width: 220px">
                  <el-date-picker value-format="yyyy-MM-dd" v-model="form.effectiveEnddate" size="" type="date" placeholder="结束日期">
                  </el-date-picker>
                </el-col>
              </el-row>
              <div class="el-form-item__error" v-if="errorRules['effectiveStartdate']">
                {{ errorRules["effectiveStartdate"] }}
              </div>
            </el-form-item>
          </div>

        <!-- <el-row>
          <el-col :span="12">
            <el-form-item label="姓名：" prop="acctId" :rules="{ required:'true',message: '请选择项目管理员姓名'}">
              <el-select clearable v-model="form.acctId" placeholder="请选择项目管理员姓名" @change="handleChangeAcctName">
                <el-option v-for="(item,index) in acctList" :label="item.acctName" :value="item.acctId" :key="index"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="项目经理手机号：">
              <span>{{ acctSelectItem.mobile || ''}}</span>
            </el-form-item>
          </el-col>
        </el-row>

        <el-form-item label="角色：">
          <div v-if="adminRoleIds.length">{{adminRoleIds.join(',')}}</div>
          <div v-else>{{acctSelectItem.acctId ? "无" : ""}}</div>
        </el-form-item> -->

          <el-form-item label="变更理由：" :rules="{ required:'true',message: '请填写变更理由'}" prop="approveMsg">
            <el-input type="textarea" v-model="form.approveMsg" :rows="4" placeholder="请填写变更理由..." maxlength="200" show-word-limit />
          </el-form-item>
        </div>
        <el-form-item label="上传授权书" :rules="{ required:'true',message: '请上传授权书'}" class="authorization" prop="attachUrl" width="80px">
          <UpfileComponent :isWidth="true" ref="upfileRef" :immediateClearList="true" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :btnName="'上传'" :dirName="`${new Date().getTime()}/`" :type="'13'" :fileTypes="uploadFileSuffix" :id="'123'" @outputList="handleUpFileResult($event)"></UpfileComponent>
          <span class="hand blue ml14" @click="handleDownTemp">下载授权书模板</span>
        </el-form-item>
      </el-form>
      <div class="upload-cont">
        <div class="upload-title" v-if="authorizationInfo.attachName">
          <span :title="authorizationInfo.attachName">
            <em :class="{blue:showFile, hand:showFile}" @click="showFile && handleOpenAuthorization(authorizationInfo.attachUrl)">{{authorizationInfo.attachName}}</em>
          </span>
          <span>
            <i class="hand blue" @click="delFileInfo">删除</i>
          </span>
        </div>
        <div v-else class="undata">未上传附件！</div>
      </div>

      <el-row style="margin-top: 60px;">
        <el-col :span="24" class="tc">
          <el-button class="normal-btn" type="primary" @click="handleSubmit">提交申请</el-button>
          <el-button class="normal-btn" @click="handleCancel">取消</el-button>
        </el-col>
      </el-row>
    </div>

    <div class="change-content original-info" v-if="approveStatus == 'submited'">
      <el-row>
        <el-col :span="24">
          <span class="color888">姓名：</span>
          <span>{{newProjectManager.acctName ||''}}</span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <span class="color888">角色：</span>
          <span v-if="newAdminRoles.length">{{newAdminRoles.join("，")}}</span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <span class="color888">变更理由：</span>
          <span>{{applyFlowApply.approveMsg ||''}}</span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12" class="display-flex">
          <span class="color888">授权书：</span>
          <ul>
            <li class="or-name-li" v-for="item in newProjectManager && newProjectManager.approveAttachList || []" :key="item.attachId">
              <span class="or-name" :title="item.attachName">{{item.attachName}}</span>
              <span v-if="item.attachName" class="hand blue" @click="handleOpenAuthorization(item.attachUrl)">查看</span>
            </li>
          </ul>
        </el-col>
      </el-row>

      <el-row style="margin-top: 60px;">
        <el-col :span="24" class="tc">
          <el-button class="normal-btn" @click="handleCancel">返回</el-button>
        </el-col>
      </el-row>
    </div>

    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { viewFile } from '@/utils/orderUtil';
import { InterfaceService } from '@/services/api'
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import { DateUtil } from '@/utils/dateUtil';
import Loading from '@/components/base/Loading'

const form = {
  acctId: "",
  approveMsg: "",
  attachUrl: "",

  effectiveStartdate: "",
  effectiveEnddate: "",
  adminName: "",
  adminCertNo: "",
  adminMobile: "",
  department: "",
  position: "",
  adminEmail: "",
};
export default {
  name: "ChangeAdmin",
  props: ['corpId', 'projectAdmin'],
  components: {
    UpfileComponent,
    Loading,
  },
  data() {
    var validateEffectiveStartdate = (rule, value, callback) => {
      if (value) {
        var thetimeFirst = value;
        var thetimeSecond = this.form.effectiveEnddate;
        if (thetimeSecond && thetimeFirst > thetimeSecond) {
          this.form.effectiveStartdate = "";
          // this.form.dealTo = ''
          callback(new Error("请选择有效的授权委托期"));
        } else {
          callback();
        }
      } else {
        callback();
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (
        !/^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-zA-Z0-9]+[-a-z0-9]*[a-zA-Z0-9]+.){1,63}[a-zA-Z0-9]+$/.test(
          value
        )
      ) {
        callback(new Error("邮箱格式不正确"));
      } else {
        const mail = value || "",
          mailSuffix = mail.slice(mail.lastIndexOf(".") + 1, mail.length);

        const errorMailSuffix = JSON.parse(
          this.$getRootLocalStorage("errorMailSuffix") || "[]"
        );
        if (errorMailSuffix.includes(mailSuffix)) {
          callback(new Error("邮箱后缀不正确"));
          return;
        }
        callback();
      }
    };
    return {
      acctList: [],
      acctListCopy: [],
      uploadFileSuffix: "",
      isLoading: false,
      templateFileUrl: "",
      authorizationInfo: {},
      submitAdminInfo: {},
      delId: "",
      templateFileName: "",
      form: Object.assign({}, form),


      originalProjectManager: {},
      newProjectManager: {},
      applyFlowList: [],
      applyFlowReject: {}, // 拒绝
      applyFlowApply: {}, // 申请
      newAdminRoles: [],

      adminCertNoDisabled: false,
      adminMobileDisabled: false,
      adminEmailDisabled: false,
      departmentDisabled: false,
      positionDisabled: false,
      errorRules: {},
      formRules: {
        adminName: [
          {
            required: true,
            message: "必填",
          },
          {
            pattern: /^(?!_)(?!.*?_$)[a-zA-Z0-9_\u4e00-\u9fa5]{2,200}$/,
            max: 200,
            message: "姓名设置不符合要求",
            trigger: "blur",
          },
        ],
        adminCertNo: [
          {
            required: true,
            message: "必填",
          },
          {
            pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/,
            max: 20,
            message: "身份证号码不正确",
            trigger: "blur",
          },
        ],
        adminMobile: [
          {
            required: true,
            message: "必填",
          },
          {
            pattern: /^[1][0-9][0-9]{9}$/,
            max: 11,
            message: "手机号格式不正确",
            trigger: "blur",
          },
        ],
        adminEmail: [
          {
            required: true,
            message: "必填",
          },
          { validator: validatePass2, trigger: "blur" },
        ],
        department: [
          {
            required: true,
            message: "必填",
          },
          { max: 50, message: "部门名称不得大于50个字", trigger: "blur" },
        ],
        position: [
          {
            required: true,
            message: "必填",
          },
          { max: 40, message: "职务名称不得大于40个字", trigger: "blur" },
        ],
        effectiveStartdate: [
          {
            required: true,
            message: "必填",
          },
          { validator: validateEffectiveStartdate, trigger: "blur" },
        ],
      },
    }
  },
  watch: {
    approveId: {
      handler(newName, oldName) {
        console.log(this.adminInfo.approveStatus);
        this.getSubordinateData()
      },
    }
  },
  computed: {
    // isFirstSetAdmin() {
    //   return approveStatus => {
    //     approveStatus = approveStatus || 'submited'
    //     return this.projectApprove.approveDefId == 'ADMIN_ACTIVATE_APPROVE' && this.projectApprove.approveStatus == approveStatus
    //   }
    // },
    projectApprove() {
      return this.projectAdmin && this.projectAdmin.adminProjectApprove || {}
    },
    approveStatus() {
      return this.projectApprove.approveStatus || ''
    },

    acctSelectItem() {
      return this.acctList.find(f => f.acctId == this.form.acctId) || {}
    },
    adminRoleIds() {
      let arr = []
      this.acctSelectItem && this.acctSelectItem.roleIds && this.acctSelectItem.roleIds.forEach(f => arr.push(f.roleName))
      return arr
    },
    isIE11() {
      let userAgent = navigator.userAgent;
      return userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; // ie11<11
    },
    isIE10() {
      return window.navigator.userAgent.indexOf('MSIE') >= 1
    },
    showFile() {
      return this.authorizationInfo && this.authorizationInfo.attachUrl && (this.authorizationInfo.attachUrl.indexOf("http://") != -1 || this.authorizationInfo.attachUrl.indexOf("https://") != -1)
    },
    userInfo() {
      return this.$store.state.userInfo
    }
  },
  methods: {
    getOrderConfiguration() {
      const params = {
        businessType: 'AUTHORIZATION'
      };
      InterfaceService.getOrderConfiguration(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let list = res.uploadFileList || [];
          list.forEach(item => {
            if (item.fileTypeId === "regist_authorization") {
              this.templateFileUrl = item.attachUrl || "";
              this.templateFileName = item.templateFileName || "";
              this.uploadFileSuffix = item.uploadFileSuffix || "";
            }
          })
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },

    handleOpenAuthorization(url) {
      if (url.indexOf("http://") != -1 || url.indexOf("https://") != -1) {
        if (url) {
          viewFile(url)
        } else {
          this.$message.error("暂无预览地址")
        }
      }
    },

    // 查询公司下属账户信息
    getSubordinateData() {
      InterfaceService.getQuerySubordinate({ corpId: this.corpId }, (data) => {
        if (data.respCode === "0000") {
          let list = data.respData.acctList || [];

          // 移除 原有 管理员 数据
          list.some((s, sIdx) => {
            if (s.acctId == this.projectAdmin.adminAcctId) {
              list.splice(sIdx, 1)
            }
          })
          this.acctList = list
          this.acctListCopy = list
        } else {
          this.$message.error(data.respMsg);
        }
      },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        });
    },
    handleGetValue(val) {
      this.inputValue = val;
      if (val) { //val存在
        this.acctList = this.acctListCopy.filter((item) => {
          if (!!~item.acctName.indexOf(val) || !!~item.acctName.toUpperCase().indexOf(val.toUpperCase())) {
            return true
          }
        })
      } else { //val为空时，还原数组
        this.acctList = this.acctListCopy;
      }
    },
    handleChangeRole(ev){
      console.log(ev)
      let off = true
      this.acctListCopy.forEach(item=>{
        if (item.acctId === ev) {
          this.form.acctId = item.acctId || ''
          this.form.adminName = item.acctName || ''
          this.form.adminCertNo = item.certNo || ''
          this.form.adminMobile = item.mobile || ''
          this.form.adminEmail = item.email || ''
          this.form.department = item.dept || ''
          this.form.position = item.title || ''
          this.handleDisabled()
          off = false
        }
      });
      if(off){
        this.form.acctId = ''
        this.form.adminCertNo = ''
        this.form.adminMobile = ''
        this.form.adminEmail = ''
        this.form.department = ''
        this.form.position = ''
        this.adminCertNoDisabled = false
        this.adminMobileDisabled = false
        this.adminEmailDisabled = false
        this.departmentDisabled = false
        this.positionDisabled = false
      }
    },
    handleDisabled(){
      if(this.form.adminCertNo){
        this.adminCertNoDisabled = true
      }
      if(this.form.adminMobile){
        this.adminMobileDisabled = true
      }
      if(this.form.adminEmail){
        this.adminEmailDisabled = true
      }
      if(this.form.department){
        this.departmentDisabled = true
      }
      if(this.form.position){
        this.positionDisabled = true
      }
    },
    querySearch(queryString, callback) {
      let commonMailbox = this.$commonMailbox()
      let results = this.$clone(commonMailbox)
      let value = ''
      if(queryString && queryString.indexOf('@') != -1){
        value = queryString.substring(0, queryString.indexOf('@'))
      }else{
        value = queryString
      }
      results.forEach((i,index) =>{
          i.value = value + '' + commonMailbox[index].value
      })
      callback(results)
      this.$refs.autocomplete.handleFocus()
    },

    handleChangeAcctName() {
      this.acctList.forEach(item => {
        if (item.acctId == this.form.acctId) {
          this.newAdminRoles = [];
          if (item.roleIds && item.roleIds.length) {
            item.roleIds.forEach(_item => {
              this.newAdminRoles.push(_item.roleName)
            })
          }
        }
      })
    },
    handleOpenAuthorization(url) {
      if (url.indexOf("http://") != -1 || url.indexOf("https://") != -1) {
        if (url) {
          viewFile(url)
        } else {
          this.$message.error("暂无预览地址")
        }
      }

    },
    handleUpFileResult(e) {
      this.delFileInfo()
      const { file, name, targetValue, url } = e[0]
      this.authorizationInfo = {
        file: file,
        attachName: name,
        creTm: DateUtil.dateToString(),
        targetValue,
        attachUrl: url,
      };
      this.form.attachUrl = this.authorizationInfo.attachUrl || "";
      console.log(this.form, '0this.form');

    },
    handleDownTemp() {
      this.$download([{
        name: this.templateFileName || '',
        url: this.templateFileUrl || ''
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    delFileInfo() {
      if (this.authorizationInfo.id) {
        this.delId = this.authorizationInfo.id;
      }
      this.authorizationInfo = {};
      this.form.attachUrl = ''
    },
    handleSubmit() {
      this.updateAdmin()
    },

    updateAdmin() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          if (this.form.approveMsg.replace(/(^\s*)|(\s*$)/g, "") == '') {
            this.$message.error('变更理由不能为空!')
            return
          }

          const newAdmin = this.acctList.find(f => f.acctId == this.form.acctId) || {}

          // this.$confirm(`您是否确认将管理员从${this.projectAdmin && this.projectAdmin.adminCustName || ''}变更为${newAdmin.acctName || ''}？`, "提示信息", {
          this.$confirm(`您是否确认将管理员从${this.projectAdmin && this.projectAdmin.adminCustName || ''}变更为${this.form.adminName || ''}？`, "提示信息", {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            confirmButtonText: "确认",
            cancelButtonText: '取消',
          }).then(() => {
            let params = {
              // acctId: this.acctSelectItem.acctId,

              acctId: this.form.acctId,
              approveMsg: this.form.approveMsg,
              effectiveStartdate: this.form.effectiveStartdate,
              effectiveEnddate: this.form.effectiveEnddate,
              adminName: this.form.adminName,
              adminCertNo: this.form.adminCertNo,
              adminMobile: this.form.adminMobile,
              department: this.form.department,
              position: this.form.position,
              adminEmail: this.form.adminEmail,

              corpId: this.corpId,
              approveDefId: "ADMIN_UPDATE_APPROVE",
              projectStageId: this.projectAdmin && this.projectAdmin.projectStageId,
              // 申请状态（审批操作"apply:提交申请；approve:审核通过；reject:拒绝"）
              approveType: "apply",
              approveAttachList: [{
                attachType: "2",
                attachName: this.authorizationInfo.attachName,
                attachUrl: this.authorizationInfo.attachContent || this.authorizationInfo.attachUrl || this.authorizationInfo.attachPath || '',
              }],
            };

            InterfaceService.fkChangeProjectAdmin(params, data => {
              let res = data.respData || {};
              console.log(res, 'res');

              if (res.respCode === "0000") {
                this.$message.success('提交申请成功!')
                this.$emit("refresh", true)
              } else {
                this.$message.error(res.respMsg);
              }
            }, data => { }, () => {
              this.isLoading = true;
            }, () => {
              this.isLoading = false;
            })
          }).catch(() => {
          });
        }
      })
    },
    handleCancel() {
      this.$emit("refresh")
    },

    getAdminCompanyInfo(approveId) {
      let param = {
        approveId
      };
      InterfaceService.getAdminCompanyInfo(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.submitAdminInfo = data.respData || {};

          this.applyFlowList = data.respData.applyFlowList || []
          // 拒绝 显示对象
          this.applyFlowReject = this.applyFlowList.find(f => f.approveId == approveId && f.operType == 'reject') || {}
          // 申请 显示对象
          this.applyFlowApply = this.applyFlowList.find(f => f.approveId == approveId && f.operType == 'apply') || {}

          // 新管理员
          this.newProjectManager.acctName = this.submitAdminInfo.name
          this.newProjectManager.approveMsg = this.applyFlowApply.approveMsg || ''
          this.newProjectManager.approveAttachList = this.submitAdminInfo.approveAttachList || []
          this.newAdminRoles = []
          this.submitAdminInfo.roleList && this.submitAdminInfo.roleList.forEach(f => {
            this.newAdminRoles.push(f.roleName)
          })

          // 反显管理员数据
          if (['rejected'].includes(this.approveStatus)) {
            this.form.acctId = this.submitAdminInfo.acctId || ''
            this.form.adminName = this.submitAdminInfo.name || ''
            this.form.adminCertNo = this.submitAdminInfo.certNo || ''
            this.form.adminMobile = this.submitAdminInfo.mobile || ''
            this.form.department = this.submitAdminInfo.department || ''
            this.form.position = this.submitAdminInfo.position || ''
            this.form.adminEmail = this.submitAdminInfo.email || ''
            this.form.effectiveStartdate = this.submitAdminInfo.effectiveStartdate || ''
            this.form.effectiveEnddate = this.submitAdminInfo.effectiveEnddate || ''

            this.form.approveMsg = this.applyFlowApply.approveMsg || ''
            this.authorizationInfo = this.submitAdminInfo.approveAttachList && this.submitAdminInfo.approveAttachList[0] || {}
            this.form.attachUrl = this.authorizationInfo.attachUrl || ''
          }


        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },

  },
  mounted() {
    // 如果是提交待审 查询详情 获取 替换 - 最新人员信息
    if (['submited', 'rejected'].includes(this.approveStatus)) {
      this.getAdminCompanyInfo(this.projectApprove.approveId || '')
    }
    this.getOrderConfiguration()
    this.getSubordinateData();
  },
}
</script>

<style scoped lang="scss">
.approval-info {
  width: 100%;
  border: 1px solid #d7b064;
  margin-bottom: 20px;
  vertical-align: middle;
  font-size: 14px;
  padding: 20px;
}
.info-title {
  margin: 5px 0;
  margin-bottom: 20px;
  padding: 0 10px;
  font-size: 14px;
  border-left: 3px solid #000;
  line-height: 12px;
}
.company-top {
  margin-bottom: 20px;
}
.authorization {
  margin-bottom: 0 !important;
}

.info-panel-content {
  padding: 20px;
  padding-bottom: 0;
  padding-right: 30px;
  background: #fff;
  &.bottom {
    padding-bottom: 20px;
  }
  /deep/ .el-form-item__error {
    background: #fff;
    width: 100%;
    height: 22px;
  }
}
.form-inline-item {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;

  & > div {
    width: 46%;
    flex-shrink: 0;
  }

  &.col-3 > div {
    width: 32%;
  }
}
.neet-upload-upfile {
  box-sizing: border-box;
  display: flex;
  border-top: 1px solid transparent;

  &.disabled {
    /deep/ .center .blue {
      // background: #dddddd !important;
      // color: #a9a9a9 !important;
    }
  }

  & > li {
    width: 85%;

    &:nth-child(1) {
      .input-file-p {
        border: 1px solid #dcdfe6;
        box-sizing: border-box;
        padding: 0 12px;
        color: #606266;
        display: block;
        display: flex;
        flex-wrap: wrap;
        height: 38px;

        span {
          height: 38px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        & > .gray {
          color: #c0c4cc;
          font-size: 12px;
          outline: none;
          height: 38px;
        }

        .el-tag {
          margin: 4px;
          height: 30px;
        }
      }
    }

    &:nth-child(2) {
      width: 15%;
    }

    &:nth-child(3) {
      width: 33%;
    }

    .el-button--default {
      height: 40px;
      margin-left: 4px;
    }
  }

  .el-button--primary {
    width: 119px;
    margin-right: 12px;
  }

  /deep/ .upfile-container {
    .center {
      label {
        width: 120px;
        background: linear-gradient(
          120deg,
          rgba(215, 176, 100, 1) 0%,
          rgba(236, 206, 139, 1) 100%
        );
        color: #fff !important;
        text-align: center;
        height: 40px;
      }
    }
  }
}
.upload-cont {
  width: 910px;
  margin-left: 108px;
  margin-top: 20px;
}
.submited {
  width: 100%;
  margin-left: 0;
  margin-top: -15px;
}
.upload-title {
  background: #f5f5f5;
  border-bottom: 1px solid #fff;
  height: 35px;
  line-height: 35px;

  span {
    display: inline-block;
    padding-left: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  & span:nth-child(1) {
    width: 65%;
  }
  & span:nth-child(2) {
    width: 25%;
  }
}
.company-left {
  width: 100%;
}
.company-top li .company-showtext {
  width: 270px;
  display: inline-block;
}
.a-text {
  display: inline-block;
  width: auto !important;
  max-width: 254px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.original-info {
  font-size: 12px;
  padding-bottom: 10px;
}
.display-flex {
  display: flex;
}
.or-name-li {
  display: flex;
}
.or-name {
  max-width: 400px;
  display: inline-block;
  overflow: hidden;
  white-space: pre;
  text-overflow: ellipsis;
  margin-right: 12px;
}

.line {
  height: 1px;
  background: #eeeeee;
  margin-bottom: 20px;
  margin-top: 10px;
}
.ml14 {
  margin-left: 8px;
}
.upfilenotice {
  font-size: 12px;
}

.upload-title {
  font-size: 12px;
  span {
    margin-right: 10px;
  }
}
.authorization {
  margin-bottom: 0 !important;
  /deep/ .el-form-item__label {
    text-align: left;
    color: #444 !important;
    width: 80px !important;
  }
  /deep/ .el-form-item__content {
    margin-left: 80px !important;
  }
  /deep/ .el-form-item__error {
    margin-top: -12px;
  }
}
.upload-cont {
  padding: 14px;
  border: 1px solid #ddd;
  margin-top: 8px;
  width: auto;
  margin-left: 0;
  .upload-title {
    font-size: 12px !important;
    background: #fff;
    height: auto;
    line-height: initial;
    span {
      padding-left: 0;
      &:nth-child(1) {
        width: auto;
      }
      &:nth-child(2) {
        width: auto;
      }
    }
  }
  .undata {
    font-size: 12px;
    color: #bbb;
  }
}
</style>