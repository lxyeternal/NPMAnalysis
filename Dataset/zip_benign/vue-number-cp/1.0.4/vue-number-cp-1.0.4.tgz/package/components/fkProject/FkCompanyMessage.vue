<template>
  <div id="company-message">
    <Breadcrumb v-if="breadcrumb && breadcrumb.length" :breadcrumbList="breadcrumb" @refresh="handleGoBack"></Breadcrumb>
    <div class="purchaser-company-information" v-if="tab == 1">
      <div class="company-information">
        <div class="order-info-title">公司信息</div>
        <ul class="company-top">
          <li>
            <div class="company-left">
              <span>公司名称：</span>
              <div class="company-showtext">{{acCorpInfoBean.corpName}}</div>
            </div>

            <div class="company-left">
              <span>统一社会信用代码：</span>
              <div class="company-showtext">{{acCorpInfoBean.busiLicense}}</div>
            </div>
            <div style="clear:both;"></div>
          </li>
          <li>
            <div class="company-left">
              <span>法人代表：</span>
              <div class="company-showtext">{{acCorpInfoBean.legalRepresent}}</div>
            </div>

            <div class="company-left">
              <span> 注册资本：</span>
              <div class="company-showtext" v-if="!isNaN(Number(acCorpInfoBean.registCapital))">{{acCorpInfoBean.registCapital | formatMoney}}万元</div>
              <div class="company-showtext" v-else>{{acCorpInfoBean.registCapital}}</div>
            </div>

            <div style="clear:both;"></div>
          </li>
          <li>
            <div style="clear:both;"></div>
            <div class="company-left">
              <span>企业类型：</span>
              <div class="company-showtext">{{acCorpInfoBean.corpTypeDisp}}</div>
            </div>
            <div class="company-left">
              <span>成立日期：</span>
              <div class="company-showtext">{{acCorpInfoBean.establishDtStr}}</div>
            </div>
          </li>
          <li>

            <div style="clear:both;"></div>
            <div class="company-left">
              <span>公司简称：</span>
              <div class="company-showtext">{{acCorpInfoBean.shortCorpName || '无'}}</div>
            </div>

            <div class="company-left">
              <span> 上级公司名称：</span>
              <div class="company-showtext">{{acCorpInfoBean.supCorpName}}</div>
            </div>
            <div style="clear:both;"></div>
          </li>
          <li>
            <div style="clear:both;"></div>
            <div class="company-left">
              <span>营业期限：</span>
              <div class="company-showtext">{{companyInfoBean.dealFromStr}}~{{companyInfoBean.dealToStr}}</div>
            </div>
            <div style="clear:both;"></div>
          </li>
          <li v-if="role == 'S' && !specialRole">
            <div class="company-left" style="width: 100%">
              <span>产品品类：</span>
              <div class="company-showtext" style="width: 936px;">{{categoryNameList.join('、')}} <span v-if="!isReview && !userInfo.contractCorpType" class="blue hand" @click="handleClickEditCategory">编辑</span></div>
            </div>
            <div style="clear:both;"></div>
          </li>
          <li>
            <div class="company-left">
              <span class="color888">营业执照：</span>
              <span class="blue-pointer" v-if="isDivisionAdmin || isDivisionEdit || isBrokerAdmin" @click="$refs.businessLicense.open(acCorpAttachInfoList, fkCorpId)">编辑</span>
              <div>
                <div class="company-img" v-for="(item,index) in acCorpAttachInfoList" :key="index">
                  <img width="122" :src="item.attachContent" @click="showBigImg(index)" />
                  <el-dialog width="840px" title="" :visible.sync="item.dialogVisible">
                    <img :src="item.attachContent" alt="">
                  </el-dialog>
                </div>
              </div>
            </div>
            <div class="company-left" v-if="role == 'B'">
              <span class="color888">所属事业部：</span>
              <div class="company-showtext">{{companyInfoBean.groupCompanyName}}</div>
            </div>
            <div style="clear:both;"></div>
          </li>
        </ul>
      </div>
      <BusinessLicense ref="businessLicense" @upData="getCompanyMessage()"></BusinessLicense>
      <template v-if="role == 'S' && (!userinfo.contractCorpType || userinfo.contractCorpType =='agent')">
        <div class="line"></div>
        <div class="purchaser-company-information">
          <div v-if="!isReview" class="order-info-title">经营品牌 <span v-if="!userInfo.contractCorpType" class="hand blue add-brand" @click="handleClickAdd">新增品牌</span></div>
          <ul class="brand-container-ul" :class="{p0: idx==0, m0: idx==0}" v-for="(item, idx) in brandList" :key="idx" v-if="brandList && brandList.length">
            <li>
              <div class="head-title">
                经营品牌{{idx + 1}}
                <template v-if="!userInfo.contractCorpType && !isReview">
                  <span @click="handleClickEdit(item)" class="hand blue opt-brand-btn">编辑</span>
                  <span v-if="brandList && brandList.length > 1" @click="handleClickDel(item, idx)" class="hand blue opt-brand-btn">删除</span>
                </template>
              </div>
            </li>
            <li class="brand-li-body">
              <div class="brand-left">
                <div><span class="title">品牌中文名：</span>{{item.brandNameCn}}</div>
                <div><span class="title">品牌英文名：</span>{{item.brandNameEn}}</div>
              </div>
              <div class="brand-right">
                <div class="title">品牌logo：</div>
                <div class="logo-img-center hand">
                  <img :src="item.logoDisplayUrl" @click="item.logoDisplayUrl && logoShowBigImg(idx)">
                  <el-dialog width="840px" title="" :visible.sync="item.dialogVisible">
                    <img :src="item.logoDisplayUrl" alt="">
                  </el-dialog>
                </div>
              </div>
            </li>
          </ul>
        </div>
        <div class="line"></div>
      </template>
      <companyAddress @changeAddr="handleChangeAddr" :isReview="!(isDivisionAdmin || isDivisionEdit || isBrokerAdmin)" :isAlter="true" :userType="'vendor'" :corpAddrInfo="corpAddrInfo"></companyAddress>
      <div class="line"></div>

      <adminInformation :adminInfo="adminInfo" :isReview="true" @changeAdmin="changeAdmin"></adminInformation>
      <div class="purchaser-company-information invoice-info-container">
        <!-- <div class="order-info-title">开票信息<span v-if="!isReview && (isDivisionEdit)" class="hand blue add-brand" @click="handleChangeInvoiceTypeNew">变更信息</span></div> -->
        <div class="order-info-title">开票信息<span v-if="!isReview" class="hand blue add-brand" @click="handleChangeInvoiceTypeNew">变更信息</span></div>
        <ul class="brand-container-ul">
          <li :class="{'box': role === 'B'}" class="clearfloat">
            <div class="head-title">
              发票类型
            </div>
            <div class="body-invoice-info">
              <span class="title">票种：</span>
              {{getTicketTypeComputed || ''}}
            </div>
            <div class="body-invoice-info" v-if="role === 'B'">
              <span class="title">开票地址：</span>
              {{corpAddrInfo.invoicingProvCodeDisp}}&nbsp;&nbsp;{{corpAddrInfo.invoicingCityCodeDisp}}&nbsp;&nbsp;{{corpAddrInfo.invoicingDistrictCodeDisp}}&nbsp;&nbsp;{{corpAddrInfo.invoicingDetailAddr}}
            </div>
          </li>
          <template v-if="role === 'B'">
            <li class="box clearfloat">
              <div class="body-invoice-info">
                <span class="title">邮编：</span>
                {{corpAddrInfo.invoicingZipCode}}
              </div>
              <div class="body-invoice-info">
                <span class="title">电话号码：</span>
                {{corpAddrInfo.invoicingTelNumber}}
              </div>
            </li>
            <li class="box clearfloat">
              <div class="body-invoice-info">
                <span class="title">传真号码：</span>
                {{corpAddrInfo.invoicingFaxNumber || ''}}
              </div>
            </li>
          </template>
          <li v-if="role === 'S'">
            <div class="head-title">
              货物与应税劳务
            </div>
            <div class="milling-body-head">
              <el-row>
                <el-col :span="9">
                  货物或应税劳务分类
                </el-col>
                <el-col :span="3">
                  税率
                </el-col>
                <el-col :span="12">
                  备注
                </el-col>
              </el-row>
            </div>
            <div class="milling-body-center">
              <el-row v-for="(item, idx) in taxClassifyList" :key="idx">
                <el-col :span="9" class="remark" :title="item.classify">
                  {{item.classify}}
                </el-col>
                <el-col :span="3" class="remark" :title="`${item.tax}%`">
                  {{item.tax}}%
                </el-col>
                <el-col :span="12" class="remark" :title="item.remark">
                  {{item.remark}}
                </el-col>
              </el-row>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <div v-if="tab == 2">
      <el-form ref="formAddr" :model="formAddr" :rules="rules" label-width="118px">
        <div class="form-inline-item-dispickter">
          <el-form-item label="工商注册地址：">
            <Distpicker v-if="areaList.length" :areaList="areaList" :address="initRegInfo" @receive="getRegAddressCode"></Distpicker>
            <div class="el-form-item__error" v-if="!regSelectedFlg">
              必填
            </div>
          </el-form-item>
        </div>
        <div class="form-inline-item address-input">
          <el-form-item label=" " prop="regDetailAddr">
            <el-input v-model="formAddr.regDetailAddr" placeholder="请输入工商登记详细地址" @focus="blurCheckForm('regDetailAddr')" @blur="blurCheckForm('regZipCode')"></el-input>
            <div class="el-form-item__error" v-if="errorRules['regDetailAddr']">
              {{ errorRules["regDetailAddr"] }}
            </div>
          </el-form-item>
        </div>
        <div class="form-inline-item-dispickter">
          <el-form-item label="办公地址：">
            <Distpicker v-if="areaList.length" :areaList="areaList" :address="initOfficeInfo" @receive="getOfficeAddressCode"></Distpicker>
            <div class="el-form-item__error" v-if="!officeSelectedFlg">
              必填
            </div>
          </el-form-item>
        </div>
        <div class="form-inline-item address-input">
          <el-form-item label=" " prop="officeDetailAddr">
            <el-input v-model="formAddr.officeDetailAddr" placeholder="请填写地址" @focus="blurCheckForm('officeDetailAddr')" @blur="blurCheckForm('officeZipCode')"></el-input>
            <div class="el-form-item__error" v-if="errorRules['officeDetailAddr']">
              {{ errorRules["officeDetailAddr"] }}
            </div>
          </el-form-item>
        </div>
        <div class="form-inline-item">
          <el-form-item label="邮编：" prop="officeZipCode">
            <el-input v-model="formAddr.officeZipCode" placeholder="" @focus="blurCheckForm('officeZipCode')" @blur="blurCheckForm('officeZipCode')"></el-input>
            <div class="el-form-item__error" v-if="errorRules['officeZipCode']">
              {{ errorRules["officeZipCode"] }}
            </div>
          </el-form-item>
        </div>
        <div class="form-inline-item">
          <el-form-item label="电话号码：" prop="officeTelNumber">
            <el-input v-model="formAddr.officeTelNumber" placeholder="" @focus="blurCheckForm('officeTelNumber')" @blur="blurCheckForm('officeTelNumber')"></el-input>
            <div class="el-form-item__error" v-if="errorRules['officeTelNumber']">
              {{ errorRules["officeTelNumber"] }}
            </div>
          </el-form-item>
          <el-form-item label="传真号码：" prop="officeFaxNumber">
            <el-input v-model="formAddr.officeFaxNumber" placeholder="" @focus="blurCheckForm('officeFaxNumber')" @blur="blurCheckForm('officeFaxNumber')" maxlength="64"></el-input>
            <div class="el-form-item__error" v-if="errorRules['officeFaxNumber']">
              {{ errorRules["officeFaxNumber"] }}
            </div>
          </el-form-item>
        </div>
      </el-form>
      <div class="submit-cont">
        <el-button size="small" style="width: 120px;" type="primary" @click="addrSubmit">保存</el-button>
        <el-button size="small" style="width: 120px;" @click="tab = 1">取消</el-button>
      </div>
    </div>
    <div v-if="tab == 3" class="f14">
      <label><span class="red" style="padding-right: 4px;">*</span>票种：</label>
      <el-checkbox-group v-model="invoiceType">
        <el-checkbox label="0">增值税普通发票</el-checkbox>
        <el-checkbox label="1">增值税专用发票</el-checkbox>
      </el-checkbox-group>
      <div class="submit-cont">
        <el-button size="small" style="width: 120px;" type="primary" @click="invoiceTypeSubmit">保存</el-button>
        <el-button size="small" style="width: 120px;" @click="tab = 1">取消</el-button>
      </div>
    </div>
    <div v-if="tab == 4">
      <ChangeAdmin :approveId="adminInfo.approveId" :adminInfo="adminInfo" :fkCorpId="fkCorpId" @refresh="handleRefresh"></ChangeAdmin>
    </div>
    <Loading :is-loading="isLoading"></Loading>

    <el-dialog class="dialog" title="经营品牌" :append-to-body="true" :lock-scroll="true" :visible.sync="brandManagementDialog" width="850px" center :close-on-click-modal="false">
      <div class="tc now">
        <ul class="brand-management-dialog-container">
          <li>
            <span>
              <i class="red">*</i>
              品牌中文名：
            </span>
            <el-input v-model="brandManagement.brandNameCn" placeholder="请输入" maxlength="50"></el-input>
          </li>
          <li>
            <span>
              <i class="red">*</i>
              品牌英文名：
            </span>
            <el-input v-model="brandManagement.brandNameEn" placeholder="请输入" maxlength="50"></el-input>
          </li>
          <li>
            <div class="logo-center">
              <i class="red">*</i>
              <font>&nbsp;品牌logo</font>
              <UpfileComponent ref="upfileRef" :immediateClearList="true" :fileSize="1048576" :fileSizeMsg="'上传文件不能超过1M, 请重新选择'" :btnName="'上传'" :dirName="`${new Date().getTime()}/`" :type="'2'" :appName="'MEM'" :fileTypes="'png,jpg,jpeg,bmp,gif'" @outputList="handleLogoUpFileResult($event)"></UpfileComponent>
            </div>
            <p>
              请上传品牌logo (单张图片大小不超过1M，建议方形尺寸500*500，jpg或png格式)
            </p>
            <div class="upfile-logo">
              <template v-if="brandManagement.logoImgUrl">
                <p>{{logoImgUrlComputed(brandManagement.logoImgUrl)}}</p>
                <span @click="handleClickDelBrandManagementLogoUrl(brandManagement)" class="blue hand">删除</span>
              </template>
              <div class="un-data" v-else>
                未上传附件！
              </div>
            </div>
          </li>
        </ul>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 100px" @click="handleClickBrandManagementConfirm">保存</el-button>
        <el-button size="small" style="width: 100px" @click="handleClickBrandManagementCancel">取消</el-button>
      </div>
    </el-dialog>

    <el-dialog class="dialog" title="产品品类" :append-to-body="true" :lock-scroll="true" :visible.sync="showMultipleDropdownTree" width="850px" center :close-on-press-escape="false" :close-on-click-modal="false">
      <div class="tc now">
        <multipleDropdownTree v-if="showMultipleDropdownTree" @categoryInfo="getCategoryInfo" :width="'808px'" :dataList="cateList"></multipleDropdownTree>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 100px" @click="handleClickshowMultipleDropdownTreeConfirm">保存</el-button>
        <el-button size="small" style="width: 100px" @click="handleClickshowMultipleDropdownTreeCancel">取消</el-button>
      </div>
    </el-dialog>
    <template v-if="tab == 5">
      <FkBillingInformationEditing :propCorpId="fkCorpId" @refresh="handleRefresh(true)"></FkBillingInformationEditing>
    </template>
  </div>
</template>
<script>
import Loading from '@/components/base/Loading'
import companyAddress from '@/components/purchaser/companyAddress'
import adminInformation from '@/components/purchaser/adminInformation'
import { InterfaceService } from '@/services/api'
import { viewFile } from '@/utils/orderUtil';
import accountMixin from "@/mixins/account";
import Distpicker from "@/components/base/Distpicker";
import PanelTitle from "@/components/base/PanelTitle";
import ChangeAdmin from "@/components/company/ChangeAdmin";
import BusinessLicense from "@/components/company/businessLicense";
import multipleDropdownTree from "@/components/order/multipleDropdownTree";
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import Breadcrumb from "@/components/base/Breadcrumb";
import FkBillingInformationEditing from "@/components/fkProject/FkBillingInformationEditing";
import { mapActions, mapState } from 'vuex'
export default {
  mixins: [accountMixin],
  components: {
    Loading,
    companyAddress,
    adminInformation,
    Distpicker,
    PanelTitle,
    ChangeAdmin,
    multipleDropdownTree,
    UpfileComponent,
    Breadcrumb,
    BusinessLicense,
    FkBillingInformationEditing,
  },
  props: ['fkCorpId', 'baseInfo'],
  computed: {
    // 材料公司 - 得有 1000 管理员权限 才能编辑
    isBrokerAdmin() {
      return this.mixinsRoleIdsAdmin(this.mxCorpId, '1000')
    },

    // 事业部 - 得有 9000 管理员权限 才能编辑
    isDivisionAdmin() {
      return this.mixinsRoleIdsAdmin(this.mxCorpId, '9000')
    },

    // 事业部 - 只有 2000 权限 则 哪条数据满足 对应的 corpId 才能编辑哪条
    isDivisionEdit() {
      return this.baseInfo && this.mixinsRoleIdsAdmin(this.fkCorpId || '')
    },

    // 返回当前用户 持有的 权限
    mixinsRoleIdsAdmin() {
      return (corpId, code = '2000') => {
        const ids = this.roleListFilter(corpId) || []
        // 是否为管理员2000
        return ids.some(s => s.roleId == code)
      }
    },

    userInfo() {
      return this.$store.state.userInfo
    },
    getTicketTypeComputed() {
      let list = this.corpFinInfo && this.corpFinInfo.invoiceName && this.corpFinInfo.invoiceName.split("、") || [];
      let outputList = [];
      list.forEach(item => {
        if (item !== 'null')
          outputList.push(item)
      });
      return outputList.join("、")
    },
    logoImgUrlComputed() {
      return url => {
        return url.slice(url.lastIndexOf('/') + 1, url.length) || ''
      }
    }
  },
  data() {
    const validateMobile = (rule, value, callback) => {
      const reg = new RegExp(/^[1][0-9][0-9]{9}$/);                    // 手机
      const reg1 = new RegExp(/^[\d-\s\(\)\+\,]*$/); // 座机
      if (!reg.test(value) && !reg1.test(value)) {
        return callback(new Error("联系电话格式错误，请填写手机号或座机"));
      } else {
        callback();
      }
    };
    return {
      breadcrumb: [
        { name: '管理中心', path: '/purchaserCenter/accountInfo' },
        { name: '公司管理信息-项目管理', goBack: true },
        { name: '查看项目公司' },
      ],
      corpId: '',
      isReview: false,
      showMultipleDropdownTree: false,
      brandManagementDialog: false,
      brandManagement: {},
      isLoading: false,
      regSelectedFlg: true,
      officeSelectedFlg: true,
      stayThisPage: false, // 创建合同时会根据query直接进入地址编辑tab，保存后将该页面设为true，不再回到编辑
      tab: 1,
      custId: '',
      invoiceType: [],
      acCorpInfoType: '',
      acCorpInfoBean: {},
      initRegInfo: {},
      initOfficeInfo: {},
      adminInfo: {},
      companyInfoBean: {},
      corpAddrInfo: {},
      corpContact: {},
      purchaseContact: {},
      corpFinInfo: {},
      formAddr: {},
      acCorpAttachInfoList: [],
      errorRules: [],
      categoryNameList: [],
      brandList: [],
      areaList: [],
      authorizationName: "",
      authorizationUrl: "",
      rules: {
        officeDetailAddr: [
          { required: true, message: "必填" },
          { max: 200, message: "地址不得大于200个字", trigger: "blur" }
        ],
        regDetailAddr: [
          { required: true, message: "必填" },
          { max: 200, message: "工商登记详细地址不得大于200个字", trigger: "blur" }
        ],
        officeZipCode: [
          {
            required: true,
            message: "必填"
          },
          { pattern: /^\d{6}$/, message: '请输入正确的邮编', trigger: "blur" }
        ],
        officeTelNumber: [
          {
            required: true,
            message: "必填"
          },
          { validator: validateMobile, trigger: "blur" },
        ],
        officeFaxNumber: [
          { pattern: /^[0-9\-]{0,32}$/, message: '请输入正确的传真号码', trigger: "blur" },
        ],
      },
      taxClassifyList: [],
      cateList: [],
      cateListOld: [],
      isAddBrand: false, // 点击的是新增品牌
    }
  },
  watch: {
    tab(newVal, oldVal) {
      console.log(newVal)
      if (newVal == 1) {
        this.breadcrumb = [
          { name: '管理中心', path: '/purchaserCenter/accountInfo' },
          { name: '公司管理信息-项目管理', goBack: true },
          { name: '查看项目公司'},
        ]
      } else if (newVal == 2) {
        this.breadcrumb = [
          { name: '管理中心', path: '/purchaserCenter/accountInfo' },
          { name: '公司管理信息-项目管理', goBack: true },
          { name: '查看项目公司', goBack: true, tab: 2},
          { name: '变更公司地址'},
        ]
      } else if (newVal == 3) {
        this.breadcrumb = [
          { name: '管理中心', path: '/purchaserCenter/accountInfo' },
          { name: '公司管理信息-项目列表', goBack: true },
          { name: '查看项目公司', goBack: true, tab: 3},
          { name: '变更开票信息'},
        ]
      } else if (newVal == 4) {
        this.breadcrumb = [
          { name: '管理中心', path: '/purchaserCenter/accountInfo' },
          { name: '公司管理信息-项目管理', goBack: true },
          { name: '查看项目公司', goBack: true, tab: 4},
          { name: '变更管理员账户信息'},
        ]
      } else if (newVal == 5) {
        this.breadcrumb = [
          { name: '管理中心', path: '/purchaserCenter/accountInfo' },
          { name: '公司管理信息-项目列表', goBack: true },
          { name: '查看项目公司', goBack: true, tab: 5},
          { name: '变更开票信息'},
        ]
      } 
    }
  },
  methods: {
    ...mapActions(['setNationalRegionListAction']),
    async handleLogoUpFileResult(ev) {
      this.$set(this.brandManagement, 'logoImgUrl', ev[0] && ev[0].url)

      // const imgBase64 = await this.imageToBase64(ev[0].file)

      // if (imgBase64) {
      //   // this.$set(this.brandManagement, 'imgBase64', imgBase64)
      // }
    },

    imageToBase64(file) {
      return new Promise(resolve => {
        var reader = new FileReader()
        reader.readAsDataURL(file)
        reader.onload = () => {
          resolve(reader.result)
        }
        reader.onerror = function (error) {
          console.log('Error: ', error)
        }
      })
    },
    handleClickEditCategory() {

      setTimeout(s => {
        console.log(this.cateListOld, '---cateListOld');
        // 初始化
        this.cateList = [...this.cateListOld]
        this.cateList.push({})
        this.cateList.splice(this.cateList.length - 1, 1)
        this.showMultipleDropdownTree = true
        // todu 触发 组件 watch 检测 <待优化>
        console.log(this.cateList, '--cateList');
      })

    },
    handleClickshowMultipleDropdownTreeConfirm() {
      let categoryList = []
      this.cateList.forEach(item => {
        if (item.categoryId && !item.delete) {
          categoryList.push(item)
        }
      });

      if (!categoryList.length) {
        this.$message.error('请选择产品品类！')
        return
      }
      this.showMultipleDropdownTree = false

      this.rejectUpdatePurchaser({
        categoryList: [...categoryList],
        message: '修改成功'
      })

    },
    handleClickshowMultipleDropdownTreeCancel() {
      this.showMultipleDropdownTree = false
    },
    handleClickDelBrandManagementLogoUrl(item) {
      item.logoImgUrl = ''
    },
    verifyBrandManagement() {
      let start = true
      if (!(this.brandManagement && this.brandManagement.brandNameCn) || this.brandManagement.brandNameCn.trim() === '') {
        this.$message.error('请填写品牌中文名')
        return start = false
      }
      if (!(this.brandManagement && this.brandManagement.brandNameEn) || this.brandManagement.brandNameEn.trim() === '') {
        this.$message.error('请填写品牌英文名')
        return start = false
      }
      if (!(this.brandManagement && this.brandManagement.logoImgUrl) || this.brandManagement.logoImgUrl.trim() === '') {
        this.$message.error('请上传品牌logo')
        return start = false
      }
      return start
    },
    handleClickBrandManagementConfirm() {
      if (!this.verifyBrandManagement()) return
      this.brandManagementDialog = false
      // private String brandCrudFlg; // 品牌处理标志（"insert:新增"，"update:更新"，"delete:删除"）
      this.brandManagement.brandCrudFlg = this.isAddBrand ? 'insert' : 'update'
      this.rejectUpdatePurchaser({
        brandList: [this.$clone(this.brandManagement)],
        message: this.isAddBrand ? '新增成功' : '修改成功'
      })

      // this.brandList.some(s => {
      //   if (s.index === this.brandManagement.index) {
      //     Object.assign(s, this.brandManagement)
      //     return true
      //   }
      // })
      this.isAddBrand = false
    },

    rejectUpdatePurchaser(paramObj) {
      const bs = this.userinfo.bs || 'B',
        corpId = this.userinfo.corpId

      let params = {
        corpId,
      };
      let message = paramObj.message
      delete paramObj.message
      params = Object.assign(params, paramObj)
      // 判断是否供应商
      const api = this.userinfo.bs == 'B' ? 'rejectUpdatePurchaser' : 'rejectUpdateSupplier'
      InterfaceService[api](
        params,
        data => {
          let result = data.respData;
          this.getCompanyMessage()
          if (result.respCode == '0000') {
            this.$message.success(message || '保存成功')

          } else {
            this.$message.error(result.respMsg)
          }
        },
        data => {
          this.$message.error(data.respData.respMsg)
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    handleClickBrandManagementCancel() {
      this.brandManagementDialog = false
      this.isAddBrand = false
    },

    handleClickAdd() {
      this.brandManagementDialog = true
      this.isAddBrand = true
      this.brandManagement = {}
    },
    handleClickEdit(item) {
      this.isAddBrand = false
      this.brandManagementDialog = true
      this.brandManagement = this.$clone(item)
    },

    getCategoryInfo(info) {

      info.forEach(f => {
        // 如果一条都没有 做添加处理
        if (!this.cateList.length) {
          this.cateList.push({
            categoryId: f.categoryId,
            fullName: f.brandName,
            parentId: f.parentId,
            originalId: f.originalId,
          })
        } else {
          // 如果没找到 做 新增处理
          if (!this.cateList.some(s => {
            // 如果 已有 做更新处理
            if (f.categoryId == s.categoryId) {
              s.fullName = f.brandName
              s.parentId = f.parentId
              s.originalId = f.originalId
              this.$set(s, 'delete', false)
              return true
            }
          })) {
            // 如果已经添加过 则 跳过
            if (this.cateList.some(s => s.categoryId == f.categoryId)) return
            this.cateList.push({
              categoryId: f.categoryId,
              fullName: f.brandName,
              parentId: f.parentId,
              originalId: f.originalId,
            })
          }
        }
      })

      // 如果 在cateList 没有找到该数据 说明已经删除
      this.cateList.forEach(f => {
        // 未找到
        if (!f.categoryId) return
        if (!info.some(s => f.categoryId == s.categoryId)) {
          this.$set(f, 'delete', true)
        }
      })

      console.log(this.$clone(this.cateList), '组装');
    },

    handleClickDel(item, idx) {
      this.$confirm(`此操作将永久删除${item.brandNameCn || ''}, 是否继续?`, '删除提示', {
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        confirmButtonText: '确定',
        cancelButtonText: '取消',
      }).then(() => {
        const item = this.brandList[idx]
        console.log(item, ';--item');

        this.brandManagementDialog = false
        item.brandCrudFlg = 'delete'
        this.rejectUpdatePurchaser({
          brandList: [this.$clone(item)],
          message: '删除成功'
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });
      });
    },
    changeAdmin(bool) {
      if (bool) {
        this.tab = 4;
        window.scrollTo(0, 0)
      }
    },
    handleRefresh(bool) {
      if (bool) {
        this.getCompanyMessage();
      }
      this.tab = 1;
    },
    handleChangeInvoiceType() {
      this.tab = 3;
      this.invoiceType = this.corpFinInfo.invoiceType
      window.scrollTo(0, 0)
    },
    handleChangeInvoiceTypeNew() {
      const invoiceType = this.corpFinInfo && this.corpFinInfo.invoiceType && this.corpFinInfo.invoiceType
      const item = {
        taxClassifyList: this.taxClassifyList,
        // invoiceType: typeof invoiceType === 'string' ? this.corpFinInfo.invoiceType.split('/') : invoiceType
        invoiceType: typeof invoiceType === 'string' ? this.corpFinInfo.invoiceType.split('/') : invoiceType
      }
      this.tab = 5
    },
    handleChangeBrankInfo() {
      const path = this.role === 'S' ? '/vendorCenter/accountManagementList' : '/purchaserCenter/bankAccountInfo'
      if (this.role === 'S') {
        this.$router.push(path)
      } else {
        console.log(this.$clone(this.corpFinInfo), '----');
        const {
          corpId,
          bankName,
          bankCode,
          bankAcctName,
          bankAcct,
          bankProvCode,
          bankCityCode,
          bankDistrictCode,
          bankDetailAddr,
          contact,
          contactMobile,
          bankNameBA,
          bankCodeBA,
          bankAcctNameBA,
          bankAcctBA,
          bankProvCodeBA,
          bankCityCodeBA,
          bankDistrictCodeBA,
          bankDetailAddrBA,
          contactBA,
          contactMobileBA,
          taxPayerId,
          taxPayerName,
          trustCode,
          contactTypeDisp,
          taxPayerLevel,
          invoiceType,
          invoiceName,
          invoiceList,
          bankAcctId
        } = this.corpFinInfo,

          item = {
            bankAcctId,
            corpId,
            bankAcctNo: bankAcct,
            bankAcctName,
            bankNo: bankCode,
            bankName,
            taxPayerId,
            provCode: bankProvCode,
            cityCode: bankCityCode,
            districtCode: bankDistrictCode,
            addr: bankDetailAddr,
            name: contact,
            mobile: contactMobile,
            // defaultFlg: "0",
            // creTm: "2020-07-02 11:39:09",
            // bankNameBa,
            // bankAcctBa,
            bankAcctType: "0",
          }
        this.$router.push({
          path,
          query: {
            info: JSON.stringify(item || {}),
            type: 'ope',
            backPath: '/purchaserCenter/companyMessage'
          }
        })
      }
    },
    blurCheckForm(key) {
      if (this.formAddr[key]) {
        delete this.errorRules[key]
      }
    },
    invoiceTypeSubmit() {
      if (this.invoiceType.length) {
        let params = {
          corpId: this.corpId,
          invoiceType: this.invoiceType,
          // taxClassifyList: []
        };
        InterfaceService.rejectUpdatePurchaser(
          params,
          data => {
            let result = data.respData;
            if (result.respCode == '0000') {
              this.$message.success("保存成功！")
              this.tab = 1;
              this.getCompanyMessage();
            } else {
              this.$message.error(result.respMsg)
            }
          },
          data => {
            this.$message.error(data.respData.respMsg)
          },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      } else {
        this.$message.error("请至少选择一种票种")
      }
    },
    addrSubmit() {
      if (!this.formAddr.regDistrictCode) {
        this.regSelectedFlg = false;
        return false
      }
      if (!this.formAddr.officeDistrictCode) {
        this.officeSelectedFlg = false;
        return false
      }
      this.$refs.formAddr.validate((valid) => {
        if (valid) {
          let params = {
            corpId: this.corpId,
            regProvCode: this.formAddr.regProvCode,
            regCityCode: this.formAddr.regCityCode,
            regDistrictCode: this.formAddr.regDistrictCode,
            regDetailAddr: this.formAddr.regDetailAddr,

            officeProvCode: this.formAddr.officeProvCode,
            officeCityCode: this.formAddr.officeCityCode,
            officeDistrictCode: this.formAddr.officeDistrictCode,
            officeTelNumber: this.formAddr.officeTelNumber,
            officeFaxNumber: this.formAddr.officeFaxNumber,
            officeZipCode: this.formAddr.officeZipCode,
            officeDetailAddr: this.formAddr.officeDetailAddr,
          };
          InterfaceService[this.role == "S" ? "rejectUpdateSupplier" : "rejectUpdatePurchaser"](
            params,
            data => {
              let result = data.respData;
              if (result.respCode == '0000') {
                this.$message.success("保存成功！")
                this.tab = 1;
                this.getCompanyMessage();
                // this.stayThisPage = true;
                let query = this.$router.history.current.query;
                let path = this.$router.history.current.path;
                //对象的拷贝
                let newQuery = JSON.parse(JSON.stringify(query));
                newQuery.type = null;
                this.$router.push({ path, query: newQuery });
                window.opener && window.opener.location.reload();
              } else {
                this.$message.error(result.respMsg)
              }
            },
            data => {
              this.$message.error(data.respData.respMsg)
            },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            }
          );
        }
      })
    },
    handleOpenAuthorization() {
      if (this.authorizationUrl) {
        viewFile(this.authorizationUrl)
      }
    },
    handleChangeAddr() {
      this.tab = 2;
      this.initRegInfo = {
        provCode: this.corpAddrInfo.regProvCode,
        cityCode: this.corpAddrInfo.regCityCode,
        blockCode: this.corpAddrInfo.regDistrictCode
      };
      this.initOfficeInfo = {
        provCode: this.corpAddrInfo.officeProvCode,
        cityCode: this.corpAddrInfo.officeCityCode,
        blockCode: this.corpAddrInfo.officeDistrictCode
      };
      this.formAddr = {
        corpId: this.corpId,
        regProvCode: this.corpAddrInfo.regProvCode,
        regCityCode: this.corpAddrInfo.regCityCode,
        regDistrictCode: this.corpAddrInfo.regDistrictCode,
        regDetailAddr: this.corpAddrInfo.regDetailAddr,

        officeProvCode: this.corpAddrInfo.officeProvCode,
        officeCityCode: this.corpAddrInfo.officeCityCode,
        officeDistrictCode: this.corpAddrInfo.officeDistrictCode,
        officeTelNumber: this.corpAddrInfo.officeTelNumber,
        officeFaxNumber: this.corpAddrInfo.officeFaxNumber,
        officeZipCode: this.corpAddrInfo.officeZipCode,
        officeDetailAddr: this.corpAddrInfo.officeDetailAddr,
      };
    },
    getRegAddressCode(res) {
      this.formAddr.regProvCode = res.provinceCode
      this.formAddr.regCityCode = res.cityCode
      this.formAddr.regDistrictCode = res.blockCode
      if (this.formAddr.regDistrictCode) {
        this.regSelectedFlg = true
      }
    },
    getOfficeAddressCode(res) {
      this.formAddr.officeProvCode = res.provinceCode
      this.formAddr.officeCityCode = res.cityCode
      this.formAddr.officeDistrictCode = res.blockCode
      if (this.formAddr.officeDistrictCode) {
        this.officeSelectedFlg = true
      }
    },
    getCompanyMessage() {
      const corpId = this.fkCorpId || this.$route.query.corpId || ''
      let params = {}
      corpId && (params.corpId = corpId)
      InterfaceService[this.role == "S" ? "getVendorMessage" : "getPurchaserMessage"](params, (data) => {
        if (data.respData.respCode == "0000") {
          this.companyInfoBean = data.respData && (data.respData.acSupplierInfoBean || data.respData.acPurchaserInfoBean || {});


          this.taxClassifyList = data.respData && data.respData.corpTaxClassifyList || []

          if (!this.companyInfoBean.dealToStr) {
            this.companyInfoBean.dealToStr = '长期'
          }
          if (data.respData.acCorpAttachInfoList.length != 0) {
            data.respData.acCorpAttachInfoList.forEach((item, ind, arr) => {
              item.dialogVisible = false
            })
          }
          this.acCorpAttachInfoList = [];
          let list = data.respData.acCorpAttachInfoList || [];
          list.forEach(item => {
            if (item.attachType === "0") {
              this.acCorpAttachInfoList.push(item)
            } else if (item.attachType === "2") {
              this.authorizationName = item.attachName || "";
              this.authorizationUrl = item.attachUrl || ""
            }
          });
          if (data.respData.brandList && data.respData.brandList.length) {
            data.respData.brandList.forEach((item, ind, arr) => {
              item.dialogVisible = false
              item.index = ind
            })
            this.brandList = data.respData.brandList || [];
          }
          this.categoryNameList = [];
          if (data.respData.categoryList && data.respData.categoryList.length) {
            let categoryList = data.respData.categoryList;
            this.cateList = data.respData.categoryList;
            this.cateListOld = [...data.respData.categoryList];
            categoryList.forEach(item => {
              if (item.fullName && !this.categoryNameList.includes(item.fullName)) {
                this.categoryNameList.push(item.fullName)
              }
            });
          }
          this.acCorpInfoBean = data.respData.acCorpInfoBean || {};
          if (!this.acCorpInfoBean.supCorpName) {
            this.acCorpInfoBean.supCorpName = '无'
          }
          if (!this.acCorpInfoBean.registCapital) {
            this.acCorpInfoBean.registCapital = '无'
          }
          this.acCorpInfoType = data.respData.acCorpInfoBean.approveStatusDisp;
          this.corpId = data.respData.acCorpInfoBean.corpId
          data.respData.acCorpContactInfoList.forEach((item) => {
            if (item.contactType == '0') {
              this.corpContact = item
              if (!this.corpContact.department) {
                this.corpContact.department = '无'
              }
              if (!this.corpContact.provCodeDisp) {
                this.corpContact.provCodeDisp = ''
              }
              if (!this.corpContact.cityCodeDisp) {
                this.corpContact.cityCodeDisp = ''
              }
              if (!this.corpContact.districtCodeDisp) {
                this.corpContact.districtCodeDisp = ''
              }
            } else if (item.contactType == '1') {
              this.purchaseContact = item
              if (!this.purchaseContact.department) {
                this.purchaseContact.department = '无'
              }
              if (!this.purchaseContact.provCodeDisp) {
                this.purchaseContact.provCodeDisp = ''
              }
              if (!this.purchaseContact.cityCodeDisp) {
                this.purchaseContact.cityCodeDisp = ''
              }
              if (!this.purchaseContact.districtCodeDisp) {
                this.purchaseContact.districtCodeDisp = ''
              }
            } else if (item.contactType == '9') {
              this.adminInfo = item;
              this.adminInfo.authorizationName = this.authorizationName || "";
              this.adminInfo.authorizationUrl = this.authorizationUrl || "";
            }
          });
          this.corpAddrInfo = data.respData.corpAddrInfoRst || {};
          if (!this.corpAddrInfo.regFaxAreaCode) {
            this.corpAddrInfo.regFaxAreaCode = '无'
          }
          if (!this.corpAddrInfo.regFaxNumber) {
            this.corpAddrInfo.regFaxNumber = '无'
          }
          this.corpFinInfo = data.respData.acCorpFinInfoBean || {};
          if (this.role == "B") {
            if (this.corpFinInfo.invoiceType == "") {
              this.corpFinInfo.invoiceType = [];
            } else if (this.corpFinInfo.invoiceType == "0") {
              this.corpFinInfo.invoiceType = ["0"];
            } else if (this.corpFinInfo.invoiceType == "1") {
              this.corpFinInfo.invoiceType = ["1"];
            } else {
              this.corpFinInfo.invoiceType = ["0", "1"];
            }
          }
          if (this.$route.query.type === 'addr' && !this.stayThisPage) {
            this.handleChangeAddr();
          }
          // const taxClassifyItem = JSON.parse(this.$getRootScope('taxClassifyItem') || '{}')

        } else {
          this.$message.error(data.respMsg)
        }
      }, (data) => {
      }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },
    getDistrictsList() {
      let params = { //给予后端的入参
        level: "1,2,3",
      };
      InterfaceService.getDistrictsList(params, data => {
        if (data.respData.respCode === '0000') {
          this.areaList = data.respData.areaList || [];
          this.setNationalRegionListAction(this.areaList)
        }
      }, data => {
      }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },
    showBigImg(ind) {
      this.acCorpAttachInfoList[ind].dialogVisible = true;
    },
    logoShowBigImg(ind) {
      console.log(this.brandList[ind].logoDisplayUrl, '-this.brandList[ind].logoDisplayUrl');

      this.brandList[ind].dialogVisible = true;
    },
    handleGoBack(val = '') {
      if(val && val != 'cancel'){
        this.tab = 1
      }else{
        this.$emit('refresh', true)
      }
    },

  },
  mounted() {
    let user = JSON.parse(this.$getRootScope('user')) || {}
    this.isReview = this.$route.query.isReview || false


    this.custId = user.custId || ''

    // this.breadcrumb = [
    //   { name: '管理中心', path: '/purchaserCenter/accountInfo' },
    //   { name: '公司管理信息-项目管理', goBack: true },
    //   { name: '查看项目公司' },
    // ]

    this.getDistrictsList()
    this.getCompanyMessage()
  },
  destroyed() {
    this.$removeRootScope('breadcrumb')
  }
}
</script>

<style lang="scss" scoped>
/deep/ .order-info-title {
  margin: 5px 0;
  margin-bottom: 20px;
  padding: 0 10px;
  font-size: 14px;
  border-left: 3px solid #000;
  line-height: 12px;
}
.purchaser-right-title {
  width: 100%;
  height: 50px;
  line-height: 50px;
  font-size: 14px;
  color: #4f525a;
  background: #f5f5f5;
  padding: 0 20px;
}
.purchaser-right-title div {
  float: right;
  line-height: 50px;
}
.purchaser-right-title span {
  width: 88px;
  display: inline-block;
  height: 26px;
  line-height: 26px;
  background: #bbbbbb;
  color: #444444;
  text-align: center;
}
.p0 {
  padding: 0 !important;
}
.m0 {
  margin: 0 !important;
}
.purchaser-company-information {
  width: 100%;
  margin-top: 9px;
  overflow: hidden;
  margin-bottom: 20px;
  .invoice-info-container {
    .brand-container-ul {
      margin: 0;
      padding: 0;
      border: 0;
    }
  }
  .body-invoice-info {
    margin-top: 12px;
    margin-bottom: 22px;
    span {
      font-size: 12px;
      color: #888;
    }
  }

  .milling-body-head {
    margin-top: 22px;
    [class*="el-col-"] {
      height: 34px;
      background: #f5f5f5;
      line-height: 34px;
      color: #888;
      padding: 0 12px;
      font-size: 14px;
    }
  }
  .milling-body-center {
    .el-row {
      display: flex;
      border: 1px solid #eaeaea;
      border-top: 0;
      padding: 12px;
      align-items: center;
      font-size: 14px;
    }
    [class*="el-col-"] {
      color: #444;
      &:first-child {
        color: #888;
      }
    }
    .remark {
      word-wrap: break-word;
    }
  }
}
.purchaser-company-information p {
  display: inline-block;
  height: 43px;
  line-height: 43px;
}
.purchaser-company-information p:first-child {
  width: 95px;
  font-size: 14px;
  color: #333333;
  text-align: center;
  border-bottom: 3px solid #4f525a;
}
.yellow-line {
  width: 853px;
  font-size: 12px;
  color: #373737;
  text-align: center;
  border-bottom: 3px solid #c99f4f;
  height: 43px;
  text-align: right;
  padding-right: 20px;
}
.purchaser-company-information p span {
  display: inline-block;
  height: 24px;
  padding-right: 12px;
  border: 1px solid #4f525a;
  line-height: 24px;
  text-align: left;
  padding-left: 30px;
  cursor: pointer;
}
/deep/ {
  .company-top {
    margin-top: 13px;
    font-size: 12px;
  }
  .company-top li {
    /*height: 26px;*/
    line-height: 26px;
  }
  .company-top li.changeInfo {
    height: 48px;
    line-height: 48px;
  }
  .company-top li .company-left {
    float: left;
    display: inline-block;
    width: 49%;
    /*height: 26px;*/
    line-height: 26px;
  }
  .company-top li .company-left span {
    display: inline-block;
    /*width: 172px;*/
    height: 26px;
    line-height: 26px;
    text-align: right;
    color: #888;
    vertical-align: top;
  }
  .color888 {
    color: #888;
  }
  .company-top li .company-left span em {
    color: #e93340;
  }
  .company-top li .company-showtext {
    width: 270px;
    display: inline-block;
  }
  .company-information .el-input {
    width: 270px;
    height: 26px;
  }
}
.company-top li {
  /*height: 26px;*/
  line-height: 26px;
}
.company-top li.changeInfo {
  height: 48px;
  line-height: 48px;
}
.company-top li .company-left {
  float: left;
  display: inline-block;
  width: 49%;
  /*height: 26px;*/
  line-height: 26px;
}
.company-top li .company-left span {
  display: inline-block;
  /*width: 172px;*/
  height: 26px;
  line-height: 26px;
  text-align: right;
  color: #888;
  vertical-align: top;
}
.company-top li .company-left span em {
  color: #e93340;
}
.company-top li .company-showtext {
  width: 360px;
  display: inline-block;
}
.company-information .el-input {
  width: 270px;
  height: 26px;
}
.canNotEdit /deep/ .el-input__inner {
  height: 32px;
  line-height: 32px;
  border: 1px solid #dddddd;
}
.el-input.is-disabled.canNotEdit /deep/ .el-input__inner {
  height: 26px;
  line-height: 26px;
  background: white;
  color: #333333;
  cursor: unset;
  border: 1px solid #ffffff;
  padding: 0;
}
.company-images {
  margin: 13px 0 14px;
  overflow: hidden;
}
.company-images li {
  width: 178px;
  border: 1px solid #dddddd;
  float: left;
  margin-left: 29px;
}
.company-images div img {
  width: 100%;
  cursor: pointer;
  height: auto;
  vertical-align: top;
}
.company-address,
.contact-data {
  margin-top: 13px;
}
.a-text {
  display: inline-block;
  width: auto !important;
  max-width: 254px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.company-img {
  width: 122px;
  display: inline-block;
  padding-right: 10px;
  img {
    max-width: 800px;
    display: block;
    margin: 10px auto;
    padding-right: 10px;
    &:hover {
      cursor: pointer;
    }
  }
}
.line {
  margin: 20px 0;
  height: 1px;
  width: 100%;
  background: rgba(238, 238, 238, 1);
}
.form-inline-item {
  display: flex;
  justify-content: space-between;
  flex-wrap: wrap;

  & > div {
    width: 40%;
    flex-shrink: 0;
  }

  &.col-3 > div {
    width: 32%;
  }

  /deep/ .el-select {
    width: 100%;
  }
}
.address-input {
  .el-form-item {
    width: 100% !important;
    /deep/ .el-form-item__label:before {
      content: none !important;
    }
  }
}
.form-inline-item-dispickter {
  .el-form-item {
    /deep/ .el-form-item__label:before {
      content: "*";
      color: #f56c6c;
      margin-right: 4px;
    }
  }
}
.header {
  margin-bottom: 20px;
  background: #f5f5f5;
}

.header ul {
  width: 100%;
  height: 48px;
  border-bottom: 3px solid rgb(250, 226, 165);
  font-weight: bold;
  li {
    padding-left: 20px;
    height: 48px;
    line-height: 48px;
    text-align: center;
    float: left;
    cursor: pointer;
    position: relative;

    &:after {
      display: none;
      position: absolute;
      bottom: 0px;
      left: 0;
      content: "";
      width: 110px;
      height: 3px;
      background: #4f525a;
    }

    &.active:after {
      display: block;
    }
  }
}
.submit-cont {
  margin-top: 38px;
  text-align: center;
  height: 30px;
}
.el-checkbox-group {
  display: inline-block;
}
.add-brand {
  margin-left: 10px;
  font-size: 12px;
}
.brand-container-ul {
  border-top: 1px dashed #eeeeee;
  margin-top: 32px;
  padding-top: 10px;
  .head-title {
    color: #444;
    font-size: 14px;
    font-weight: bold;
    .opt-brand-btn {
      font-size: 12px;
      font-weight: normal;
    }
  }
  li {
    margin-top: 12px;
    &.brand-li-body {
      display: flex;
      & > div {
        width: 50%;
      }
    }
    &.box{
      .head-title{
        margin-bottom: 12px;
      }
      margin-top: 0px;
      .body-invoice-info{
        display: inline-block;
        width: 49%;
        margin: 0 0 10px;
        font-size: 12px;
        line-height: 17px;
        float: left;
      }
    }
    .brand-left {
      & > div {
        margin-top: 12px;
        .title {
          color: #888;
          margin-right: 4px;
        }
      }
    }
    .brand-right {
      .title {
        color: #888;
        margin-top: -22px;
      }
      .logo-img-center {
        width: 60px;
        height: 60px;
        margin-top: 12px;
        img {
          width: 100%;
          height: 100%;
        }
      }
    }
  }
}
.brand-management-dialog-container {
  li {
    display: flex;
    margin-top: 16px;
    align-items: center;
    & > span {
      color: #888;
      width: 112px;
      font-size: 14px;
    }
    /deep/ .el-input {
      text-align: left;
    }
    /deep/ .el-input__inner {
      width: 711px;
    }
    .logo-center {
      color: #444444;
      font-size: 14px;
      display: flex;
      font {
      }
    }
    &:last-child {
      align-items: flex-start;
      flex-direction: column;
      & > p {
        color: #888;
        margin: 12px 0 4px;
      }
      .upfile-logo {
        border: 1px solid #eaeaea;
        height: 45px;
        line-height: 45px;
        padding: 12px;
        display: flex;
        width: 100%;
        align-items: center;
        p {
          margin-right: 12px;
        }
        .un-data {
          color: #bbbbbb;
        }
      }
    }
  }
}
</style>
<style lang="scss">
.companyDelBarandNoticeBox {
  width: 400px !important;
  .el-message-box__btns {
    display: flex;
    justify-content: center;
    .el-button--primary {
      order: -1;
      margin: 0 10px 0 0;
      background: #d7b064 linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
      color: #fff;
    }
  }
}
</style>