<template>
  <div>
    <div class="approval-info" v-if="approveStatus && approveStatus !== 'approved' ">
      <p v-if="approveStatus === 'submited'">审核状态：待材料公司审核</p>
      <template v-if="approveStatus === 'rejected'">
        <p style="margin-bottom: 10px;">审核状态：材料公司已拒绝</p>
        <p>拒绝原因：{{applyFlowReject.approveMsg || ''}}</p>
      </template>
    </div>
    <div class="info-title">
      设置项目经理
    </div>
    <div class="change-content" v-if="approveStatus != 'submited'">
      <el-form ref="form" :model="form" label-width="120px">
        <el-row>
          <el-col :span="12">
            <el-form-item label="姓名：" prop="acctId" :rules="{ required:'true',message: '请选择项目经理姓名'}">
              <el-select clearable v-model="form.acctId" placeholder="请选择项目经理姓名" @change="handleChangeAcctName">
                <el-option v-for="(item,index) in acctList" :label="item.acctName" :value="item.acctId" :key="index"></el-option>
              </el-select>
            </el-form-item>
          </el-col>
          <el-col :span="12">
            <el-form-item label="项目经理手机号：">
              <span>{{acctList.find(f=> f.acctId == form.acctId) && acctList.find(f=> f.acctId == form.acctId).mobile || ''}}</span>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="上传任命书" :rules="{ required:'true',message: '请上传任命书'}" class="authorization" prop="attachUrlappointment" width="80px">
          <DownloadAndUpload :fileSize="52428800" fileSizeErrorMsg="上传文件不能超过50M, 请重新选择" class="f12" style="position: absolute;left: 6px; top: 11px;" appName="MEM" :hasDownloadFlg="false" fromId="appointment" uploadType="3" @outputValue="handleUpFileResult"></DownloadAndUpload>
          <!-- <UpfileComponent ref="upfileRef" :immediateClearList="true" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :btnName="'上传'" :dirName="`${new Date().getTime()}/`" :type="'appointment'" :id="'appointment'" @outputList="handleUpFileResult($event)"></UpfileComponent> -->
          <!-- <span class="hand blue ml14" @click="handleDownTemp">下载授权书模板</span> -->
        </el-form-item>
        <p class="grey upfilenotice">请上传事业部认可的任命书，格式不限。</p>
        <div class="upload-cont">
          <div class="upload-title" v-if="isShowFile('appointment').attachName">
            <span :title="isShowFile('appointment').attachName">
              {{isShowFile('appointment').attachName}}
            </span>
            <span>
              <i class="blue-pointer" style="margin-right: 6px" @click="handleOpenAuthorization(isShowFile('appointment').attachUrl)">查看</i>
              <i class="hand blue" @click="delFileInfo('appointment')">删除</i>
            </span>
          </div>
          <div v-else class="undata">未上传附件！</div>
        </div>

        <!-- *上传被授权人身份证正面 -->
        <el-form-item style="margin-top: 30px" label="上传被授权人身份证正面" :rules="{ required:'true',message: '请上传被授权人身份证正面'}" class="authorization identity-card" prop="attachUrlidCardFront">
          <DownloadAndUpload :isCompress="true" :fileSize="1048576" fileSizeErrorMsg="上传图片不能超过1M, 请重新选择" class="f12" style="position: absolute;left: 90px; top: 11px;" appName="MEM" :hasDownloadFlg="false" fromId="idCardFront" uploadType="4" :fileTypeReg="/(jpg|png)/i" @outputValue="handleUpFileResult"></DownloadAndUpload>
          <!-- <UpfileComponent ref="upfileRef" :immediateClearList="true" :fileSize="1048576" :fileSizeMsg="'上传文件不能超过1M, 请重新选择'" :btnName="'上传'" :dirName="`${new Date().getTime()}/`" :type="'idCardFront'" :fileTypes="'jpg,png,pdf'" :id="'idCardFront'" @outputList="handleUpFileResult($event)"></UpfileComponent> -->
        </el-form-item>
        <p class="red upfilenotice">操作说明：要求被授权人的身份证正面扫描件或照片裁剪多余部分后上传，不得涂改，图片角度水平方正，四边角完整，图片清晰可辨，图片格式为jpg/png，图片不得超过1M。</p>
        <div class="upload-cont">
          <div class="upload-title" v-if="isShowFile('idCardFront').attachName">
            <span :title="isShowFile('idCardFront').attachName">
              {{isShowFile('idCardFront').attachName}}
            </span>
            <span>
              <i class="blue-pointer" style="margin-right: 6px" @click="handleOpenAuthorization(isShowFile('idCardFront').attachUrl)">查看</i>
              <i class="hand blue" @click="delFileInfo('idCardFront')">删除</i>
            </span>
          </div>
          <div v-else class="undata">未上传附件！</div>
        </div>

        <!-- *上传被授权人身份证背面 -->
        <el-form-item style="margin-top: 30px" label="上传被授权人身份证背面" :rules="{ required:'true',message: '请上传被授权人身份证背面'}" class="authorization identity-card" prop="attachUrlidCardObverse">
          <DownloadAndUpload :isCompress="true" :fileSize="1048576" fileSizeErrorMsg="上传图片不能超过1M, 请重新选择" class="f12" style="position: absolute;left: 90px; top: 11px;" appName="MEM" :hasDownloadFlg="false" fromId="idCardObverse" uploadType="5" :fileTypeReg="/(jpg|png)/i" @outputValue="handleUpFileResult"></DownloadAndUpload>
          <!-- <UpfileComponent ref="upfileRef" :immediateClearList="true" :fileSize="1048576" :fileSizeMsg="'上传文件不能超过1M, 请重新选择'" :btnName="'上传'" :dirName="`${new Date().getTime()}/`" :type="'idCardObverse'" :fileTypes="'jpg,png,pdf'" :id="'idCardObverse'" @outputList="handleUpFileResult($event)"></UpfileComponent> -->
        </el-form-item>
        <p class="red upfilenotice">操作说明：要求被授权人的身份证背面扫描件或照片裁剪多余部分后上传，不得涂改，图片角度水平方正，四边角完整，图片清晰可辨，图片格式为jpg/png，图片不得超过1M。</p>
        <div class="upload-cont">
          <div class="upload-title" v-if="isShowFile('idCardObverse').attachName">
            <span :title="isShowFile('idCardObverse').attachName">
              {{isShowFile('idCardObverse').attachName}}
            </span>
            <span>
              <i class="blue-pointer" style="margin-right: 6px" @click="handleOpenAuthorization(isShowFile('idCardObverse').attachUrl)">查看</i>
              <i class="hand blue" @click="delFileInfo('idCardObverse')">删除</i>
            </span>
          </div>
          <div v-else class="undata">未上传附件！</div>
        </div>

      </el-form>
     
      <el-row style="margin-top: 60px;">
        <el-col :span="24" class="tc">
          <el-button class="normal-btn" type="primary" @click="handleSubmit">{{approveStatus === 'rejected' && '重新' || ''}}提交</el-button>
          <el-button class="normal-btn" @click="handleCancel">取消</el-button>
        </el-col>
      </el-row>
    </div>

    <div class="change-content original-info" v-if="approveStatus == 'submited'">
      <el-row>
        <el-col :span="24">
          <span class="color888">姓名：</span>
          <span>{{newProjectManager.acctName ||''}}</span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12" class="display-flex">
          <span class="color888">任命书：</span>
          <ul>
            <li v-for="item in newProjectManager && (newProjectManager.approveAttachList || []).filter(i=> i.attachType === 'appointment')" :key="item.attachId">
              <span>{{item.attachName}}&emsp;</span>
              <span v-if="item.attachName" class="hand blue" @click="handleOpenAuthorization(item.attachUrl)">查看</span>
            </li>
          </ul>
        </el-col>
        <el-col :span="12" class="display-flex">
          <span class="color888">授权书：</span>
          <ul>
            <li v-for="item in newProjectManager && (newProjectManager.approveAttachList || []).filter(i=> i.attachType === 'auth_word')" :key="item.attachId">
              <span>{{item.attachName}}&emsp;</span>
              <span v-if="item.attachName" class="hand blue" @click="handleOpenAuthorization(item.attachUrl)">查看</span>
            </li>
          </ul>
        </el-col>
      </el-row>

      <el-row style="margin-top: 60px;">
        <el-col :span="24" class="tc">
          <el-button class="normal-btn" @click="handleCancel">返回</el-button>
        </el-col>
      </el-row>
    </div>

    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { viewFile } from '@/utils/orderUtil';
import { InterfaceService } from '@/services/api'
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import DownloadAndUpload from "@/components/base/DownloadAndUpload";
import { DateUtil } from '@/utils/dateUtil';
import Loading from '@/components/base/Loading'

const form = {
  acctId: "",
  approveMsg: "",
  attachUrl: "",
  attachUrlappointment: "",
  attachUrlidCardFront: "",
  attachUrlidCardObverse: "",
};
export default {
  name: "ChangeAdmin",
  props: ['corpId', 'projectManager', 'projectId'],
  components: {
    UpfileComponent,
    DownloadAndUpload,
    Loading,
  },
  data() {
    return {
      acctList: [],
      newAdminRoles: [],
      uploadFileSuffix: "",
      isLoading: false,
      templateFileUrl: "",
      authorizationInfo: [],
      submitAdminInfo: {},
      delId: "",
      templateFileName: "",
      form: Object.assign({}, form),

      originalProjectManager: {},
      newProjectManager: {},
      applyFlowList: [],
      applyFlowReject: {}, // 拒绝
      applyFlowApply: {} // 申请
    }
  },
  watch: {
    approveId: {
      handler(newName, oldName) {
        console.log(this.adminInfo.approveStatus);
        this.getSubordinateData()
      },
    }
  },
  computed: {
    projectApprove() {
      return this.projectManager && this.projectManager.projectApprove || {}
    },
    approveStatus() {
      return this.projectApprove.approveStatus || ''
    },
    isIE11() {
      let userAgent = navigator.userAgent;
      return userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; // ie11<11
    },
    isIE10() {
      return window.navigator.userAgent.indexOf('MSIE') >= 1
    },
    userInfo() {
      return this.$store.state.userInfo
    }
  },
  methods: {
    isShowFile(attachType = ''){
      let obj = {}
      console.log(this.authorizationInfo)
      if(this.authorizationInfo && this.authorizationInfo.find(i=> i.attachType === attachType)){
        obj = this.authorizationInfo.find(i=> i.attachType === attachType)
      }
      return obj
    },
    // 查询公司下属账户信息
    getSubordinateData() {
      InterfaceService.getQuerySubordinate({ corpId: this.corpId }, (data) => {
        if (data.respCode === "0000") {
          let list = data.respData.acctList || [];
          this.acctList = list

        } else {
          this.$message.error(data.respMsg);
        }
      },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        });
    },
    handleChangeAcctName() {
      this.acctList.forEach(item => {
        if (item.acctId == this.form.acctId) {
          this.newAdminRoles = [];
          if (item.roleIds && item.roleIds.length) {
            item.roleIds.forEach(_item => {
              this.newAdminRoles.push(_item.roleName)
            })
          }
        }
      })
    },
    handleOpenAuthorization(url) {
      if (url.indexOf("http://") != -1 || url.indexOf("https://") != -1) {
        if (url) {
          viewFile(url)
        } else {
          this.$message.error("暂无预览地址")
        }
      }

    },
    handleUpFileResult(info) {
      console.log(info)
      this.delFileInfo(info.fromId)
      this.authorizationInfo.push({
        attachName: info.attachName, 
        attachType: info.fromId, 
        attachUrl: info.attachUrl, 
        attachPath: info.attachPath, 
      })
      this.form['attachUrl'+info.fromId] = info.attachUrl || "";
      // this.delFileInfo()
      // const { file, name, targetValue, url } = e[0]
      // this.authorizationInfo = {
      //   file: file,
      //   attachName: name,
      //   creTm: DateUtil.dateToString(),
      //   targetValue,
      //   attachUrl: url,
      // };
      // this.form.attachUrl = this.authorizationInfo.attachUrl || "";
    },
    handleDownTemp() {
      this.$download([{
        name: this.templateFileName || '',
        url: this.templateFileUrl || ''
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    delFileInfo(attachType) {
      // if (this.authorizationInfo.id) {
      //   this.delId = this.authorizationInfo.id;
      // }
      // this.authorizationInfo = {};
      // this.form.attachUrl = ''
      this.form['attachUrl'+attachType] = ''
      let result = this.authorizationInfo.findIndex(i=> i.attachType === attachType)
      if(result != -1){
        this.authorizationInfo.splice(result ,1)
      }
    },
    handleSubmit() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          const newAdmin = this.acctList.find(f => f.acctId == this.form.acctId) || {}

          this.$confirm(`您是否确认将项目经理设置为为${newAdmin.acctName || ''}？`, "提示信息", {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            confirmButtonText: "确认",
            cancelButtonText: '取消',
          }).then(() => {
            let approveAttachList = []
            this.authorizationInfo.forEach(i=>{
              approveAttachList.push({
                attachType: i.attachType,
                attachName: i.attachName,
                attachUrl: i.attachPath,
              })
            })
            let params = {
              corpId: this.corpId,
              projectId: this.projectId,
              managerAcctId: this.form.acctId || '',
              approveDefId: "PROJ_MANAGER_CREATE_APPROVE",
              projectStageId: this.projectManager && this.projectManager.projectStageId,
              approveType: "apply",
              approveAttachList
            };
            console.log(params, '--params');

            InterfaceService.fkApplyProjectManager(params, data => {
              let res = data.respData || {};
              if (res.respCode === "0000") {
                this.$message.success('提交成功!')
                this.$emit("refresh", true)
              } else {
                this.$message.error(res.respMsg);
              }
            }, data => { }, () => {
              this.isLoading = true;
            }, () => {
              this.isLoading = false;
            })
          }).catch(() => {
          })
        }
      })
    },
    handleCancel() {
      this.$emit("refresh")
    },
    getOrderConfiguration() {
      const params = {
        businessType: 'AUTHORIZATION'
      };
      InterfaceService.getOrderConfiguration(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let list = res.uploadFileList || [];
          list.forEach(item => {
            if (item.fileTypeId === "manager_authorization") {
              this.templateFileUrl = item.attachUrl || "";
              this.templateFileName = item.templateFileName || "";
              this.uploadFileSuffix = item.uploadFileSuffix || "";

            }
          })
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },

    // 查询公司审批流水信息
    getAdminCompanyInfo(approveId) {
      let param = {
        approveId
      }
      InterfaceService.fkReviewProjectAdminConfirm(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.originalProjectManager = data.respData.originalProjectManager || {}
          this.newProjectManager = data.respData.newProjectManager || {}
          this.applyFlowList = data.respData.applyFlowList || []
          // 拒绝 显示对象
          this.applyFlowReject = this.applyFlowList.find(f => f.approveId == approveId && f.operType == 'reject') || {}
          // 申请 显示对象
          this.applyFlowApply = this.applyFlowList.find(f => f.approveId == approveId && f.operType == 'apply') || {}
          // 项目经理 拒绝 反显数据
          if (['rejected'].includes(this.approveStatus)) {
            this.form.acctId = this.newProjectManager.acctId || ''
            this.form.approveMsg = this.applyFlowApply.approveMsg || ''
            this.authorizationInfo = (this.newProjectManager.approveAttachList || []).filter(i=> ['appointment', 'idCardFront', 'idCardObverse'].includes(i.attachType))
            this.authorizationInfo.forEach(i=>{
              if(i.attachUrl && ['appointment', 'idCardFront', 'idCardObverse'].includes(i.attachType)){
                this.form['attachUrl'+i.attachType] = i.attachUrl
                this.$set(i, 'attachPath', i.attachContent) 
              }
            })
            // this.authorizationInfo = this.newProjectManager.approveAttachList && this.newProjectManager.approveAttachList[0] || {}
            // this.form.attachUrl = this.authorizationInfo.attachUrl || ''
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },

  },
  mounted() {
    // 如果是提交待审 查询详情 获取 替换 - 最新人员信息
    if (['submited', 'rejected'].includes(this.approveStatus)) {
      this.getAdminCompanyInfo(this.projectApprove.approveId || '')
    }
    this.getOrderConfiguration()
    this.getSubordinateData();
  },
}
</script>

<style scoped lang="scss">
.identity-card {
  /deep/ .el-form-item__label {
    width: 162px !important;
  }
}
.approval-info {
  width: 100%;
  border: 1px solid #d7b064;
  margin-bottom: 20px;
  vertical-align: middle;
  font-size: 14px;
  padding: 20px;
}
.info-title {
  margin: 5px 0;
  margin-bottom: 20px;
  padding: 0 10px;
  font-size: 14px;
  border-left: 3px solid #000;
  line-height: 12px;
}
.company-top {
  margin-bottom: 20px;
}
.authorization {
  margin-bottom: 0 !important;
}
.neet-upload-upfile {
  box-sizing: border-box;
  display: flex;
  border-top: 1px solid transparent;

  &.disabled {
    /deep/ .center .blue {
      // background: #dddddd !important;
      // color: #a9a9a9 !important;
    }
  }

  & > li {
    width: 85%;

    &:nth-child(1) {
      .input-file-p {
        border: 1px solid #dcdfe6;
        box-sizing: border-box;
        padding: 0 12px;
        color: #606266;
        display: block;
        display: flex;
        flex-wrap: wrap;
        height: 38px;

        span {
          height: 38px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        & > .gray {
          color: #c0c4cc;
          font-size: 12px;
          outline: none;
          height: 38px;
        }

        .el-tag {
          margin: 4px;
          height: 30px;
        }
      }
    }

    &:nth-child(2) {
      width: 15%;
    }

    &:nth-child(3) {
      width: 33%;
    }

    .el-button--default {
      height: 40px;
      margin-left: 4px;
    }
  }

  .el-button--primary {
    width: 119px;
    margin-right: 12px;
  }

  /deep/ .upfile-container {
    .center {
      label {
        width: 120px;
        background: linear-gradient(
          120deg,
          rgba(215, 176, 100, 1) 0%,
          rgba(236, 206, 139, 1) 100%
        );
        color: #fff !important;
        text-align: center;
        height: 40px;
      }
    }
  }
}
.upload-cont {
  width: 910px;
  margin-left: 108px;
  margin-top: 20px;
}
.submited {
  width: 100%;
  margin-left: 0;
  margin-top: -15px;
}
.upload-title {
  background: #f5f5f5;
  border-bottom: 1px solid #fff;
  height: 35px;
  line-height: 35px;

  span {
    display: inline-block;
    padding-left: 10px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  & span:nth-child(1) {
    width: 65%;
  }
  & span:nth-child(2) {
    width: 25%;
  }
}
.company-left {
  width: 100%;
}
.company-top li .company-showtext {
  width: 270px;
  display: inline-block;
}
.a-text {
  display: inline-block;
  width: auto !important;
  max-width: 254px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.approval-info {
  width: 100%;
  border: 1px solid #d7b064;
  margin-bottom: 20px;
  vertical-align: middle;
  font-size: 14px;
  padding: 20px;
}
.original-info {
  font-size: 12px;
  padding-bottom: 10px;
}
.display-flex {
  display: flex;
}

.line {
  height: 1px;
  background: #eeeeee;
  margin-bottom: 20px;
  margin-top: 10px;
}
.ml14 {
  margin-left: 8px;
}
.upfilenotice {
  font-size: 12px;
}

.upload-title {
  font-size: 12px;
  span {
    margin-right: 10px;
  }
}
.authorization {
  margin-bottom: 0 !important;
  /deep/ .el-form-item__label {
    text-align: left;
    color: #444 !important;
    // width: 80px !important;
  }
  /deep/ .el-form-item__content {
    margin-left: 80px !important;
  }
  /deep/ .el-form-item__error {
    margin-top: -12px;
  }
}
.upload-cont {
  padding: 14px;
  border: 1px solid #ddd;
  margin-top: 8px;
  width: auto;
  margin-left: 0;
  .upload-title {
    font-size: 12px !important;
    background: #fff;
    height: auto;
    line-height: initial;
    span {
      padding-left: 0;
      &:nth-child(1) {
        width: auto;
      }
      &:nth-child(2) {
        width: auto;
      }
    }
  }
  .undata {
    font-size: 12px;
    color: #bbb;
  }
}
</style>