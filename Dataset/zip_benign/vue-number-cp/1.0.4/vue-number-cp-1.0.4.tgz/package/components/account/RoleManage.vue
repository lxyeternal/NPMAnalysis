<template>
  <div class="users">
    <!--<ConfluenceFloat :id="'6'"></ConfluenceFloat>-->
    <div class="role-manage" v-if="showType == '1'">
      <div class="header">
        <ul>
          <li class="active">角色管理</li>
          <!--<li class="add" @click="addRole">-->
          <!--<i class="el-icon-circle-plus"></i>-->
          <!--添加角色-->
          <!--</li>-->
        </ul>
      </div>
      <div class="address-table">
        <!-- 列表 -->
        <table>
          <thead>
            <tr>
              <td width="340" class="textLeft">角色名称
                <!-- <i class="el-icon-d-caret"></i> -->
              </td>
              <!--  <td width="100">变更时间

              </td>
              <td style="width: 100px;">
                操作员

              </td> -->

              <td width="120">
                已分配人数
                <!-- <i class="el-icon-d-caret"></i> -->
              </td>
              <td>
                描述
              </td>
              <!-- <td width="140" class="textRight">
                操作
              </td> -->
            </tr>
          </thead>
          <tbody>
            <tr v-for="(item,index) in roleList" :key="index">
              <td class="textLeft">
                <div class="user-name">
                  <div class="right">
                    <p>{{item.roleName}}</p>
                  </div>
                </div>
              </td>
              <td>
                {{item.roleMemberCount}}
              </td>
              <td>{{item.roleDescription}}</td>
              <!-- <td>{{item.roleUpdateDT}}</td>
              <td style="width: 100px;">
                {{item.roleModifier}}
              </td> -->
              <!--<td class="textRight">-->
              <!--<el-button type="text" v-if="item.roleCanEdit == '1'" @click = "editeRole(item)">编辑</el-button>-->
              <!--<el-button type="text" v-if="item.roleCanDelete == '1'  && item.roleMemberCount == 0" @click = "deleteRole(item)">删除</el-button>-->
              <!--</td>-->
              <!-- <td class="textRight">
                <el-button type="text" @click = "editeRole(item)">查看</el-button>
              </td> -->
            </tr>
          </tbody>
        </table>
        <!--<el-dialog title="删除确认" :visible.sync="dialogVisible">-->
        <!--<div class="delet-text">角色删除后不能恢复，确认要删除么？</div>-->
        <!--<div class="form-btns">-->
        <!--<el-button type="primary" size="medium" @click="checkDelete()">确定</el-button>-->
        <!--<el-button size="medium" @click="dialogVisible=false;">取消</el-button>-->
        <!--</div>-->
        <!---->
        <!--</el-dialog>-->

        <!-- 空列表 -->
        <div class="record-empty" v-if="!roleList.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>暂无数据</p>
        </div>
      </div>
    </div>
    <!--<div class="add-role-box" v-if="showType == '2'">-->
    <!--<AddRole @cancel="goback"></AddRole>-->
    <!--</div>-->
    <div class="edite-role-box" v-if="showType == '3'">
      <EditeRole @cancel="goback" :role="editeRoleObj"></EditeRole>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import {
  InterfaceService
} from "@/services/api";
import Loading from '@/components/base/Loading'
import AddRole from '@/components/account/AddRole'
import EditeRole from '@/components/account/EditeRole'
import ConfluenceFloat from '@/components/base/ConfluenceFloat'

export default {
  components: {
    Loading,
    AddRole,
    EditeRole,
    ConfluenceFloat
  },
  props: {
    accountType: {
      type: String,
      default: ''
    }
  },
  data() {
    return {
      params: {},
      roleList: [],
      total: 0,
      pageIndex: 1,
      pageSize: 5,
      isLoading: false,
      formLabelWidth: '100px',
      dialogVisible: false,
      handerRole: '',
      showType: '1',
      editeRoleObj: {}
    };
  },
  computed: {
    userInfo() {
      // console.log(this.$store.state.LoginedUser.custName)
      return this.$store.state.userInfo
    },
  },
  methods: {
    // 跳转
    handleCurrentChange() { },

    init() {
      this.getRoleList();
    },
    getRoleList() {
      let params = {};

      InterfaceService.getRoleManageList(params, (data) => {
        let res = data.respData
        this.roleList = res.menuList
      },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    // addRole(){
    //   this.showType = '2'
    // if(this.userInfo && this.userInfo.bs && this.userInfo.bs == 'B') {
    //   this.$router.push({
    //       path: "/purchaserCenter/addRole"
    //   });
    // }else{
    //   this.$router.push({
    //       path: "/vendorCenter/addRole"
    //   });
    // }

    // },
    editeRole(role) {
      this.showType = '3'
      this.editeRoleObj = role

      // let path = "/vendorCenter/editeRole"
      // if(this.userInfo && this.userInfo.bs && this.userInfo.bs == 'B') {
      //   path = "/purchaserCenter/editeRole"
      // }
      // this.$router.push({
      //       path: path,
      //       query: {
      //           role: role
      //       }
      // });
    },
    goback() {
      this.editeRoleObj = {}
      this.showType = '1'
      this.init();
    },
    // goBack1(){
    //     this.$router.replace({path: '/'});
    //     //replace替换原路由，作用是避免回退死循环
    // },
    deleteRole(role) {
      this.handerRole = role
      //console.log(this.handerRole)
      this.dialogVisible = true
    },
    checkDelete() {
      let params = {
        'roleID': this.handerRole.roleId,
        'roleStatus': '2'
      }
      InterfaceService.frozenRole(params, (data) => {
        let res = data.respData
        this.dialogVisible = false
        if (res.respCode === '0000') {
          this.$message({
            message: '新增删除角色成功',
            type: 'success'
          });

          this.getRoleList();
        } else {
          this.$message({
            message: res.respMsg,
            type: 'warning'
          });
        }

      },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    }
  },
  mounted() {
    this.init();
  }
};
</script>

<style lang="scss" scoped>
.users {
  font-size: 14px;
}

.addUser {
  /deep/ .el-dialog {
    width: 700px;
  }
  /deep/ .el-dialog__title {
    font-size: 16px;
    margin-left: 300px;
  }
  /deep/ .el-form {
    margin-left: 100px;
  }
  /deep/ .el-form-item__content {
    width: 300px;
  }
  /deep/ .el-input__inner {
    width: 300px;
  }
  /deep/ button {
    margin-left: 100px;
  }
}

.nowrap {
  white-space: nowrap;
}

.header {
  margin-bottom: 20px;
  background: #f5f5f5;
}

.header ul {
  width: 100%;
  height: 48px;
  border-bottom: 3px solid #ffd64e;
  font-weight: bold;

  .add {
    float: right;
    color: #4f525a;
    width: 130px;
    height: 26px;
    line-height: 26px;
    margin-right: 20px;
    background: #ffd64e;
    margin-top: 10px;
    font-weight: 500;
  }
  .add:hover {
    color: #000000;
    background-color: #f3c52f;
  }

  li {
    width: 94px;
    height: 48px;
    line-height: 48px;
    text-align: center;
    float: left;
    cursor: pointer;
    position: relative;

    &:after {
      display: none;
      position: absolute;
      bottom: 0px;
      left: 0;
      content: "";
      width: 94px;
      height: 3px;
      background: #4f525a;
    }

    &.active:after {
      display: block;
    }
  }
}

.form {
  height: 140px;

  /deep/ .el-row {
    height: 50px;
  }

  /deep/ .el-select {
    width: 100%;
  }

  /deep/ .el-date-editor {
    input.el-input__inner {
      padding: 0 15px;
    }
    .el-input__prefix {
      display: none;
    }
  }

  &:after {
    display: table;
    content: "";
    clear: both;
  }
}

.address-table {
  /deep/ .el-table__body-wrapper {
    font-size: 12px;
  }

  /deep/ .el-table th,
  .el-table td {
    padding: 14px 0;
  }

  table {
    width: 100%;
    line-height: 23px;

    .allCheck {
      text-align: left;
    }

    td {
      padding: 13px 10px;
      text-align: left;
    }
    td.textLeft {
      text-align: left;
    }
    td.textRight {
      text-align: right;
    }

    thead {
      text-align: center;
      color: #909399;
      background: #f5f5f5;
    }

    tbody {
      tr:hover {
        background: #f5f7fa;
      }

      td {
        border-bottom: 1px solid #ebeef5;
      }
    }
  }

  .address-name {
    line-height: 20px;

    img {
      width: 75px;
      height: 75px;
    }

    .left {
      margin-right: 10px;
    }

    .right {
      p:first-child {
        margin-bottom: 10px;
      }
      p:last-child {
        color: #969799;
      }
    }
  }
}

.panel-content {
  margin-bottom: 20px;
  padding: 20px 10px;
  background: #f5f5f5;
}

.form-btns {
  text-align: center;
}

.table-pagination {
  margin: 50px 0 80px;
  text-align: center;
  color: #888888;
}

.delet-text {
  font-size: 12px;
  color: #333;
  text-align: center;
  padding: 0 0 40px 0;
}

.record-empty {
  padding: 100px 0;
  text-align: center;
}

/deep/ .el-dialog__title {
  font-size: 14px;
}
/deep/ .el-dialog--center .el-dialog__body {
  font-size: 12px;
}
</style>