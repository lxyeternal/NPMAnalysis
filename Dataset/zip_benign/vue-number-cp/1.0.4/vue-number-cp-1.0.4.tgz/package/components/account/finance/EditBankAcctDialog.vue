<template>
    <div>
        <!-- 新增/修改收款银行账户信息 -->
        <el-dialog class="dialog" :title="(form.bankAcctId? '编辑':'创建')+'收款银行账户信息'" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false" @close="handleClose">
            <div>
                <el-form ref="form" :model="form" :rules="rules" label-width="120px" size="small">
                    <el-form-item label="开户名称" prop="bankAcctName">
                        <el-input v-model.trim="form.bankAcctName" type="text" placeholder="请输入开户名称" maxlength="30"></el-input>
                    </el-form-item>
                    <el-form-item label="开户银行" prop="bankName">
                        <el-input v-model.trim="form.bankName" type="text" placeholder="请输入开户银行" maxlength="20"></el-input>
                    </el-form-item>
                    <el-form-item label="银行账号" prop="bankAcctNo">
                        <el-input v-model.trim="form.bankAcctNo" type="text" @focus="handleFocus('bankAcctNo',$event)"  @blur="formatCard('bankAcctNo',$event)" placeholder="请输入银行账号" maxlength="30"></el-input>
                    </el-form-item>
                    <!--<el-form-item label="纳税人识别号" prop="taxPayerId">-->
                        <!--<el-input v-model.trim="form.taxPayerId" type="text" placeholder="请输入纳税人识别号" maxlength="30"></el-input>-->
                    <!--</el-form-item>-->
                    <el-form-item label="开户行地址" prop="provCode">
                        <Distpicker :address="form" @receive="getAddressCode"></Distpicker>
                    </el-form-item>
                    <el-form-item label="" prop="addr">
                        <el-input v-model.trim="form.addr" type="text" placeholder="请填写详细地址" maxlength="128"></el-input>
                    </el-form-item>
                    <el-form-item label="开户行行号" prop="bankNo">
                        <el-input v-model.trim="form.bankNo" type="text" @focus="handleFocus('bankNo',$event)"  @blur="formatCard('bankNo',$event)" placeholder="请输入开户行行号" maxlength="64"></el-input>
                    </el-form-item>
                    <el-form-item label="联系人" prop="name">
                        <el-input v-model.trim="form.name" type="text" placeholder="请输入联系人" maxlength="10"></el-input>
                    </el-form-item>
                    <el-form-item label="联系方式" prop="mobile">
                        <el-input v-model.trim="form.mobile" type="text" placeholder="请输入联系方式" maxlength="30"></el-input>
                    </el-form-item>
                </el-form>
            </div>
            <div class="default-flg">
                <el-checkbox v-model="defaultChecked"></el-checkbox><span>设为默认收款账户</span>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 150px" @click="handleConfirm">确认</el-button>
                <el-button size="small" style="width: 150px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import Distpicker from "@/components/base/Distpicker";
import { InterfaceService } from "@/services/api";
const form = {
    bankAcctName: "",
    bankAcctId: "",
    bankName: "",
    bankAcctNo: "",
    // taxPayerId: "",
    provCode: "",
    cityCode: "",
    blockCode: "",
    districtCode: "",
    addr: "",
    bankNo: "",
    name: "",
    mobile: ""
};
export default {
    components: {
        Loading,
        Distpicker
    },
    data() {
        const validatebankAcctNo = (rule, value, callback) => {
            value = value && value.replace(/\s+/g, "");
            const reg = new RegExp(/^[0-9]{0,30}$/);
            if (!value || !reg.test(value)) {
                return callback(new Error("银行账号格式错误，必须为数字"));
            } else {
                callback();
            }
        };
        const validatebankNo = (rule, value, callback) => {
            value = value && value.replace(/\s+/g, "");
            const reg = new RegExp(/^[0-9]{12}$/);
            if (!value || !reg.test(value)) {
                return callback(new Error("银行行号有误，请填写12位数字"));
            } else {
                callback();
            }
        };
        const validateTaxPayer = (rule, value, callback) => {
            const reg = new RegExp(`^[a-zA-Z0-9]+$`);
            if (!reg.test(value)) {
                return callback(new Error("纳税人识别号格式错误，字母或数字"));
            } else {
                callback();
            }
        };
        const validateMobile = (rule, value, callback) => {
            const reg = new RegExp(/^[1][0-9][0-9]{9}$/);                    // 手机
            const reg1 = new RegExp(/^((0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/); // 座机
            if (!reg.test(value) && !reg1.test(value)) {
                return callback(new Error("联系电话格式错误，请填写手机号或座机"));
            } else {
                callback();
            }
        };
        return {
            isLoading: false,
            dialogVisible: false,
            defaultChecked: false,
            form: Object.assign({}, form),
            rules: {
                bankAcctName: [
                    {
                        required: true,
                        message: "请输入开户名称，限制30字",
                        trigger: "blur"
                    }
                ],
                bankName: [
                    {
                        required: true,
                        message: "请输入开户银行，限制20字",
                        trigger: "blur"
                    }
                ],
                bankAcctNo: [
                    {
                        required: true,
                        message: "请输入银行账号",
                        trigger: ['blur',"change"]
                    },
                    { validator: validatebankAcctNo, trigger: ['blur',"change"] }
                ],
                // taxPayerId: [
                //     {
                //         required: true,
                //         message: "请输入纳税人识别号",
                //         trigger: "blur"
                //     },
                //     { validator: validateTaxPayer, trigger: "blur" }
                // ],
                provCode: [
                    {
                        required: true,
                        message: "请选择地址信息"
                    }
                ],
                cityCode: [
                    {
                        required: true,
                        message: "请选择地址信息"
                    }
                ],
                districtCode: [
                    {
                        required: true,
                        message: "请选择地址信息"
                    }
                ],
                addr: [
                    {
                        required: true,
                        message: "请填写详细地址"
                    }
                ],
                bankNo: [
                    {
                        required: true,
                        message: "请输入开户行行号，限制12位数字",
                        trigger: ['blur',"change"]
                    },
                    { validator: validatebankNo, trigger: ['blur',"change"] }
                ],
                name: [
                    { required: true, message: "请输入联系人", trigger: "blur" }
                ],
                mobile: [
                    {
                        required: true,
                        message: "请输入联系方式",
                        trigger: "blur"
                    },
                    { validator: validateMobile, trigger: "blur" }
                ]
            }
        };
    },
    methods: {
        open(data) {
            this.form = Object.assign({}, form, data);
            this.$set(this.form, "blockCode", this.form.districtCode);
            this.dialogVisible = true;
            this.formatCard('bankAcctNo');
            this.formatCard('bankNo');
            this.$nextTick(() => {
                this.$refs["form"].clearValidate();
            });
        },
        handleConfirm() {
            this.$refs["form"].validate(valid => {
                if (valid) {
                    this.form.bankAcctNo= this.form.bankAcctNo && this.form.bankAcctNo.replace(/\s+/g, "");
                    this.form.bankNo= this.form.bankNo && this.form.bankNo.replace(/\s+/g, "");
                    // this.form.taxPayerId= this.form.taxPayerId && this.form.taxPayerId.replace(/\s+/g, "");
                    this.editBank();
                }
            });
        },
        handleClose() {
            this.$emit("close","");
        },
        getAddressCode(res) {
            this.$set(this.form, "provCode", res.provinceCode);
            this.$set(this.form, "cityCode", res.cityCode);
            this.$set(this.form, "blockCode", res.blockCode);
            this.$set(this.form, "districtCode", res.blockCode);
        },
        formatCard(type,ev){
            this.form[type] = this.form[type] && this.form[type].replace(/\s+/g, "").replace(/(.{4})/g, "$1 ");
            if (ev && ev.target.value == "") {
                this.form[type] = null
            }
        },
        handleFocus(type,ev) {
            this.form[type] = this.form[type] && this.form[type].replace(/\s+/g, "")
            if (ev && ev.target.value == "") {
                this.form[type] = null
            }
        },
        editBank() {
            let params = Object.assign({}, this.form);
            params.defaultFlg = this.defaultChecked ? "1" : "0";
            delete params.blockCode;
            InterfaceService.addBankInfo(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.form.bankAcctId = data.respData.bankAcctId;
                        this.dialogVisible = false;
                        this.$emit("close", this.form.bankAcctId);
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;
}
.default-flg{
    text-align: left;
    height: 25px;
    line-height: 25px;
    padding-left: 10px;
    background-color: #eeeeee;
    span{
        margin-left: 6px;
    }
}
</style>
