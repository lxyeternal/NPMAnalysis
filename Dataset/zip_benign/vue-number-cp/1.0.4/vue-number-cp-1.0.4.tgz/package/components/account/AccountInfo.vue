<template>
  <div class="account-info-wrap">
    <div class="account-info-inner" id="account-info-inner">
      <div class="contain inner-container">
        <div class="list">
          <div class="rightList">
            <h4>个人资料及密码设置</h4>
            <ul>
              <li>
                <span class="title1">姓&nbsp;&nbsp;&nbsp;&nbsp;名</span>
                <p>{{acctName}}</p>
                <!-- <button type="button">修改</button> -->
              </li>
              <li>
                <span class="title1">邮&nbsp;&nbsp;&nbsp;&nbsp;箱</span>
                <p>{{email}}</p>
                <el-button type="primary" @click="goChangeMail">修改</el-button>
              </li>
              <li>
                <span class="title1">手机号</span>
                <p>{{mobileNo}}</p>
                <el-button type="primary" @click="goChangeMobile">修改</el-button>
              </li>
              <li class="editPwd">
                <span class="title1">登录密码</span>
                <p>{{pwd}}</p>
                <el-button type="primary" @click="dialogFormVisible = true">修改</el-button>
                <el-dialog title="修改登录密码" :visible.sync="dialogFormVisible" :before-close="handleClose" class="dialog-title">
                  <div v-if="psdForm">
                    <el-form :model="ruleForm2" :rules="rules2" ref="ruleForm2" :label-width="formLabelWidth" class="demo-ruleForm">
                      <div class="errorMsg" v-if="errorMsg.false">
                        <img src="../../assets/images/login/notice.png" alt=""> {{errorMsg.false}}
                      </div>
                      <el-form-item label="原密码：" prop="pwd">
                        <el-input type="password" @focus="errorMsg.pwd = ''" v-model="ruleForm2.pwd" auto-complete="off" clearable></el-input>
                        <div class="error-msg red" v-if="errorMsg.pwd">{{errorMsg.pwd}}</div>
                      </el-form-item>
                      <el-form-item label="新密码：" prop="pass">
                        <el-input type="password" v-model="ruleForm2.pass" auto-complete="off" v-popover:popoverPwd1 clearable></el-input>
                        <el-popover ref="popoverPwd1" placement="right" title="" width="300" trigger="click">
                          <div>
                            <PwdStrength :pwd="ruleForm2.pass" :type="'mini'" @received="getPwdStrength" @instant="getPwdInstant"></PwdStrength>
                          </div>
                          <div class="guid-text guid-1"><i class="el-icon-circle-check" :class="{'green':instant && instant ==2}"></i>必须是6-18个字母和数字</div>
                          <div class="guid-text guid-2"><i class="el-icon-circle-check" :class="{'green':instant && instant >=1}"></i>同时包含字母和数字</div>
                          <!-- <div class="guid-text guid-3"><i :class="{'el-icon-circle-check':!ruleForm2.pass,'el-icon-circle-close green':ruleForm2.pass &&(ruleForm2.pass == userInfo.acctName ) ,'el-icon-circle-check green':ruleForm2.pass &&(ruleForm2.pass != userInfo.acctName )}"></i>密码不能与用户名相同</div> -->
                        </el-popover>
                        <div class="error-msg red" v-if="errorMsg.pass">{{errorMsg.pass}}</div>
                      </el-form-item>
                      <el-form-item label="新密码确认：" prop="checkPass">
                        <el-input type="password" v-model="ruleForm2.checkPass" auto-complete="off" clearable></el-input>
                      </el-form-item>
                      <el-form-item>
                        <el-button @click="cancle()">取消</el-button>
                        <el-button type="primary" @click="submitForm('rules2')">确认</el-button>
                      </el-form-item>
                    </el-form>
                  </div>

                  <div v-if="psdSuccess" class="psdSuccess">
                    <div class="success"><i class="el-icon-check"></i></div>
                    <div>修改登录密码成功！</div>
                    <div class="psdTrue">
                      <el-button type="primary" @click="submitSuccess">确认</el-button>
                    </div>
                  </div>
                </el-dialog>
              </li>
              <li v-if="userInfo.bs == 'B' && !bigInfrastructure">
                <span class="title1">集团OA账号</span>
                <p>{{oaLoginId}}</p>
                <el-button v-if="!oaLoginId" type="primary" @click="bindFormVisible = true">去绑定</el-button>
                <el-button v-else type="primary" @click="OArevise">修改</el-button>
                <!-- 集团OA账号绑定 -->
                <el-dialog title="集团OA账号绑定" :visible.sync="bindFormVisible" width="700px" class="dialog-title" :close-on-click-modal="false" @close="bindClose">
                  <el-form :model="bindForm" class="bindForm" :rules="bindRules" ref="bindForm" label-width="100px">
                    <el-autocomplete style="margin-bottom: 22px" v-model="autocompleteKey" :fetch-suggestions="getOAInfo" placeholder="请输入真实姓名或OA账号搜索" @select="handleSelect"></el-autocomplete>
                    <el-form-item class="OA-form-item" label="OA编号：">
                      <el-input type="text" v-model="bindForm.loginId" disabled></el-input>
                    </el-form-item>
                    <el-form-item class="OA-form-item" label="姓名：">
                      <el-input v-model="bindForm.lastName" v-popover:popoverAcct disabled></el-input>
                    </el-form-item>
                    <el-form-item class="OA-form-item" label="部门：">
                      <el-input v-model="bindForm.departmentName" disabled :maxlength="40"></el-input>
                    </el-form-item>
                    <el-form-item class="OA-form-item" label="岗位：">
                      <el-input v-model="bindForm.jobTitle" disabled></el-input>
                    </el-form-item>
                    <el-form-item class="OA-form-item" label="手机号：">
                      <el-input type="text" v-model="bindForm.mobile" maxlength="11" disabled></el-input>
                    </el-form-item>
                    <el-row>
                      <el-col class="tc" style="margin-bottom: 20px">
                        <el-button type="primary" size="small" style="width: 100px;float: none;" @click="confirmBind();">确认绑定</el-button>
                        <el-button size="small" style="width: 100px;float: none;" @click="bindClose">取消</el-button>
                      </el-col>
                    </el-row>
                  </el-form>
                </el-dialog>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import {
  mapActions,
  mapState
} from 'vuex'
import Header from '@/components/base/Header'
import Loading from '@/components/base/Loading'
import PwdStrength from '@/components/base/PwdStrength'
import accountMixin from "@/mixins/account"

import {
  InterfaceService
} from '@/services/api'
import CryptoJS from 'crypto-js'
export default {
  mixins: [accountMixin],
  components: {
    Header,
    Loading,
    PwdStrength
  },
  data() {
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请设置新登录密码'));
      } else if (this.strength <= 1 || this.strength > 18) {
        callback(new Error('密码设置不符合要求，必须是6-18个字母和数字'));
      } else {
        let reg = new RegExp(/[^\u4e00-\u9fa5\w]/g);
        if (reg.test(value)) {
          callback(new Error('密码设置不符合要求，必须是6-18个字母和数字'));
        } else {
          if (value == this.ruleForm2.pwd) {
            callback(new Error('新密码与原密码一致'))
          } else {
            callback();
          }
        }
      }
    };
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请再次确认登录密码'));
      } else if (value !== this.ruleForm2.pass) {
        callback(new Error('两次输入密码不一致!'));
      } else {
        callback();
      }
    };
    const validataMobile = (rule, value, callback) => {
      // console.log(value)
      let mobileReg = /^[1][0-9]{10}$/;
      if (value === '') {
        callback(new Error('请输入'));
      } else {
        if (!mobileReg.test(this.bindRules.mobile)) {
          callback(new Error('手机号格式不正确'));
        }
        callback();
      }
    };
    return {
      isWhiteBg: true,
      isLoading: false,
      isShowDialog: false,
      isShowValidate: false,
      mobileNo: '',
      pwd: '',
      email: '',
      acctName: '',
      dialogFormVisible: false,
      psdForm: true,
      psdSuccess: false,
      strength: '',
      instant: '',
      errorMsg: {},
      ruleForm2: {
        pwd: '',
        pass: '',
        checkPass: '',
      },
      rules2: {
        pwd: [{
          required: true,
          message: "原密码不能为空"
        },
        { pattern: /^[a-zA-Z0-9]{6,18}$/, message: '密码格式不正确，请输入正确的密码', trigger: "blur" }],
        pass: [{
          required: true,
          message: "请设置新登录密码"
        }, {
          validator: validatePass,
          trigger: 'blur'
        }],
        checkPass: [{
          required: true,
          message: "请再次确认登录密码"
        }, {
          validator: validatePass2,
          trigger: 'blur'
        }],
      },
      formLabelWidth: '120px',
      bindFormVisible: false,
      autocompleteKey: '',
      bindForm: {
        loginId: '',
        lastName: '',
        departmentName: '',
        subcompanyName: '',
        jobTitle: '',
        mobile: '',
        hrmId: '',
        custHrmId: '',
      },
      bindRules: {
        loginId: [{ required: true, message: "必填", trigger: "blur" }],
        lastName: [{ required: true, message: "必填", trigger: "blur" }],
        departmentName: [{ required: true, message: "必填", trigger: "blur" }],
        jobTitle: [{ required: true, message: "必填", trigger: "blur" }],
        mobile: [{ required: true, validator: validataMobile, message: "必填", trigger: "blur" }],
      },
      oaLoginId: '',
      info: {},
    }
  },
  computed: {
    isLogin() {
      return this.$store.state.isLogin
    },
    userInfo() {
      // console.log(this.$store.state.LoginedUser.custName)
      return this.$store.state.userInfo
    }
  },
  methods: {
    ...mapActions(['setUserInfoAction']),
    handleOpen(key, keyPath) {
      //console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      // console.log(key, keyPath);
      this.$refs.ruleForm2.resetFields();
      this.dialogFormVisible = false;
    },
    getPwdStrength(strength) {
      this.strength = strength
    },
    getPwdInstant(instant) {
      this.instant = instant
    },
    // 修改密码成功
    submitSuccess() {
      this.dialogFormVisible = false;
      this.psdForm = true;
      this.psdSuccess = false;
    },
    cancle() {
      this.$refs.ruleForm2.resetFields();
      this.dialogFormVisible = false;
    },
    getOAInfo(keyWord, cd) {
      if (keyWord) {
        let param = {
          oaName: keyWord,
        }
        InterfaceService.getOAInfo(param, data => {
          this.isLoading = false;
          if (data && data.respData && data.respData.respCode === "0000") {
            let list = data.respData.oaAccountList || []
            list.forEach(i => {
              i.value = i.loginId + (i.loginId ? ' | ' : '') + i.lastName + (i.lastName ? ' | ' : '') + i.subcompanyName + (i.subcompanyName ? ' | ' : '') + i.departmentName + (i.departmentName ? ' | ' : '') + i.mobile + (i.mobile ? ' | ' : '') + i.jobTitle
            });
            cd(list)
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
      } else {
        cd([])
      }
    },
    OArevise() {
      this.bindFormVisible = true
      this.bindForm.loginId = this.info.oaLoginId
      this.bindForm.lastName = this.info.oaAapplicantName
      this.bindForm.departmentName = this.info.oaDepartmentName
      this.bindForm.subcompanyName = this.info.oaCompanyName
      this.bindForm.jobTitle = this.info.oajobTitle
      this.bindForm.mobile = this.info.oaAapplicantMobile
      this.bindForm.hrmId = this.info.hrmId
      this.bindForm.custHrmId = this.info.custHrmId
    },
    handleSelect(item) {
      console.log(item)
      this.bindForm.loginId = item.loginId
      this.bindForm.lastName = item.lastName
      this.bindForm.departmentName = item.departmentName
      this.bindForm.subcompanyName = item.subcompanyName
      this.bindForm.jobTitle = item.jobTitle
      this.bindForm.mobile = item.mobile
      this.bindForm.hrmId = item.hrmId
    },
    confirmBind() {
      this.getOABind()
      // this.$refs.bindForm.validate((valid) => {
      //   if (valid) {
      //     this.getOABind()
      //   } else {
      //     console.log('error submit!!');
      //     return false;
      //   }
      // });
    },
    getOABind() {
      if (!this.bindForm.hrmId) {
        return this.$message('请输入真实姓名或OA账号搜索')
      }
      let param = {
        hrmId: this.bindForm.hrmId,
        lastName: this.bindForm.lastName,
        djcName: this.userInfo.acctName
      }
      InterfaceService.getOABind(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('绑定成功')
          this.init()
          this.bindClose()
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 集团OA账号绑定关闭
    bindClose() {
      this.autocompleteKey = ''
      this.bindForm.loginId = ''
      this.bindForm.lastName = ''
      this.bindForm.departmentName = ''
      this.bindForm.subcompanyName = ''
      this.bindForm.jobTitle = ''
      this.bindForm.mobile = ''
      this.bindForm.hrmId = ''
      // this.$refs.bindForm.resetFields();
      this.bindFormVisible = false;
    },
    init() {
      let params = {
        'acctId': this.$store.state.userInfo.acctId
      }
      InterfaceService.accountInfo(params, (data) => {
        // console.log(data)
        this.info = data.respData
        this.email = data.respData.email;
        this.mobileNo = data.respData.mobile;
        this.pwd = data.respData.loginPwd;
        this.acctName = data.respData.accName
        this.oaLoginId = data.respData.oaLoginId
      })
    },
    //更改密码
    submitForm(rules2) {
      this.errorMsg = {}
      this.$refs.ruleForm2.validate((valid) => {
        if (valid) {
          let pwd = CryptoJS.MD5(this.ruleForm2.pwd).toString();
          let newPwd = CryptoJS.MD5(this.ruleForm2.pass).toString();
          var params = {
            'pwd': pwd,
            'newPwd': newPwd
          }
          InterfaceService.changePassword(params, (data) => {

            //console.log(data)
            let res = data.respData
            if (res.respCode === "0000") {
              this.psdForm = false;
              this.$refs.ruleForm2.resetFields();
              this.psdSuccess = true;
            } else {
              if (res.respCode == 'MEM0026' || res.respCode == 'MEM0007' || res.respCode == 'MEM0062') {
                this.$set(this.errorMsg, 'pwd', res.respMsg);
              } else if (res.respCode == 'MEM0027' || res.respCode == 'MEM0033' || res.respCode == 'MEM0051') {
                this.$set(this.errorMsg, 'pass', res.respMsg);
              } else if (res.respCode == 'MEM0050') {
                //  修改失败
                this.$refs.ruleForm2.resetFields();
                this.$set(this.errorMsg, 'false', res.respMsg);
              }
            }

          }, (data) => {

          },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            })
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    goChangeMail() {
      this.$setRootScope('breadcrumb', JSON.stringify([
        { name: '账户管理中心', path: '/vendorCenter/accountInfo' },
        { name: '个人资料及密码设置', goBack: true },
        { name: '邮箱修改' },
      ]))
      this.$router.push('/changemail')
    },
    goChangeMobile() {
      this.$setRootScope('breadcrumb', JSON.stringify([
        { name: '账户管理中心', path: '/vendorCenter/accountInfo' },
        { name: '个人资料及密码设置', goBack: true },
        { name: '手机号修改' },
      ]))
      this.$router.push('/changemobile')
    }
  },
  watch: {

  },
  mounted() {
    this.init()
    //console.log(this.userInfo)
  }
}
</script>

<style scoped lang="scss">
/deep/ .bindForm {
  .OA-form-item {
    margin-left: 100px;
  }
  .el-form-item__content {
    width: 300px;
  }
}
.errorMsg {
  width: 70%;
  background-color: #ffdfe0;
  line-height: 20px;
  font-size: 14px;
  color: #e8323e;
  margin-bottom: 14px;
  position: relative;
  padding: 10px 10px 10px 35px;
  margin-left: 118px;
  img {
    position: absolute;
    top: 12px;
    left: 12px;
  }
}

.cancle {
  background-color: #f6f6f6 !important;
  border: 1px solid #000 !important;
  &:hover {
    border-color: #000000 !important;
    color: #000000 !important;
    background-color: #e4e2e2 !important;
  }
}

.psdSuccess {
  text-align: center;

  .success {
    margin: 10px auto 30px;
    width: 40px;
    height: 40px;
    border-radius: 20px;
    background: #5ea509;

    i {
      margin-top: 8px;
      color: #fff;
      font-size: 24px;
    }
  }
  // .el-button--warning:hover {
  //   color: #000000;
  //   background-color: #f3c52f;
  // }
  .psdTrue {
    width: 100%;
    height: 55px;
    margin-top: 20px;
    .el-button {
      float: none !important;
      margin-right: 0 !important;
    }
  }
}

.guid-text {
  font-size: 12px;
  color: #888;
  line-height: 20px;
  i {
    margin-right: 8px;
  }
}
.active {
  background-color: #ffd64e;
}

.account-info-wrap {
}

.account-info-inner {
  margin-top: -520px;
}

.account-info-wrap {
  .pageTop {
    .logo {
      width: 500px;
      margin-top: 35px;
      margin-left: 18.5%;
    }
  }
}

.contain {
  margin-top: 540px;
  /* margin-bottom: 540px; */
}

.contain .list .rightList {
}

.contain {
  .list {
    .rightList {
      h4 {
        margin-bottom: 14px;
        font-size: 14px;
        font-weight: 900;
        padding-top: 10px;
      }
    }
  }
}

.contain {
  .list {
    .rightList {
      ul {
        li {
          height: 72px;
          width: 1020px;
        }
      }
    }
  }
}

.contain {
  .list {
    .rightList {
      ul {
        li:nth-child(2n) {
          background-color: #fafafa;
        }
      }
    }
  }
}

.contain .list .rightList ul li:nth-child(2n + 1) {
  background-color: #f5f5f5;
}

.contain .list .rightList ul li .title1 {
  float: left;
  margin-left: 30px;
  line-height: 72px;
}

.contain .list .rightList ul li p {
  float: left;
  line-height: 72px;
  margin-left: 70px;
}

.contain .list .rightList ul li:nth-last-child(1) p {
  margin-left: 60px;
}

.contain .list .rightList ul li button {
  width: 100px;
  float: right;
  margin-top: 18px;
  margin-right: 28px;
}

.editPwd {
  /deep/ .el-dialog {
    width: 700px;
  }
  /deep/ .el-dialog__title {
    font-weight: 900;
  }
  /deep/ .el-form {
    width: 400px;
    margin-left: 80px;
  }
  /deep/ .el-button {
    width: 200px;
  }
}

.dialog-title {
  /deep/ .el-dialog__title {
    font-size: 14px;
    // margin-left: 300px;
    font-weight: 500;
  }
}
/deep/ .el-form-item__label {
  font-size: 12px;
}
/deep/ .el-dialog__body {
  padding: 30px 20px 10px;
}

// .contain {
//   .list {
//     .rightList {
//       .editPwd {
//         .el-button--primary {
//           margin-right: 95px;
//         }
//       }
//     }
//   }
// }

/*.login-wrap .app-search-bar{height:120px;}*/
</style>