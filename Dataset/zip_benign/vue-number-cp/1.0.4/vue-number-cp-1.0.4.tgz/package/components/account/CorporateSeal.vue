<template>
    <div class="product">
        <div class="header">
            <ul>
                <li class="active">公司印章</li>
            </ul>
        </div>
        <div class="tip">温馨提示：我们会安全妥善保管您的电子印章，也请您注意账户安全，不要将自己的账号密码或验证码信息告知他人。</div>
        <div class="preview-sign preview-seal" v-for="(item,index) in sealList" :key="index" v-if="checkSignVisible(item)">
            <div class="preview-seal-content"  :class="{'active':item.active}" @click="handleSelectSign(item,index)">
                <img v-if="item.sealData" :src="item.sealData? ('data:image/jpeg;base64,'+item.sealData):''">
                <i class="el-icon-plus wait-to-add" v-if="!item.sealData"></i>
                <em v-if="!item.sealData">点击添加印章</em>
            </div>
            <label>{{item.label}}</label>
        </div>
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="addCorporateDialogVisible" width="900px" center :close-on-click-modal="false" @close="handleclearText()">
            <PanelTitle :tabs="tabs" @select="handleChangeTab" bg-color="#fff" text-align="center"></PanelTitle>
            <template v-if="tab == 1">
                <div>
                    <div class="company-dialogs-tip f14 bold">温馨提示：我们会安全妥善保管您的电子印章，也请您注意账户安全，不要将自己的账号密码或验证码信息告知他人。</div>
                    <div class="company-seal-content">
                        <el-row>
                            <el-col :span="9">
                                <div class="preview-seal preview-company">
                                    <div class="preview-seal-content">
                                        <img :src="changeSealData? ('data:image/jpeg;base64,'+changeSealData):''">
                                    </div>
                                    <label class="blue hand" @click="contractSeal('refresh')" v-if="contractSealFlag">刷新预览</label>
                                    <label class="blue hand" @click="projectSeal('refresh')" v-else>刷新预览</label>
                                </div>
                            </el-col>
                            <el-col :span="14">
                                <el-form :model="changeSealParams" label-width="125px"  label-position="left" :rules="ruleForm">
                                    <el-form-item label="企业名称：" prop="mainText">
                                        <!--<el-input v-model="changeSealParams.mainText" placeholder="限25个字符/若无横向及下弦内容限60个字符" :maxlength="60"></el-input>-->
                                        <el-input v-model="changeSealParams.mainText" :disabled = "true"></el-input>
                                    </el-form-item>
                                    <el-form-item label="印章横向文内容：">
                                        <el-input ref="warning" v-model="changeSealParams.hText" :placeholder="hPlaceholder" :maxlength="8" ></el-input>
                                    </el-form-item>
                                    <el-form-item label="印章下弦文内容：">
                                        <el-input v-model="changeSealParams.qText" :placeholder="qPlaceholder" :maxlength="20"></el-input>
                                    </el-form-item>
                                </el-form>
                            </el-col>
                        </el-row>
                    </div>

                </div>
                <div slot="footer" class="dialog-footer">
                    <div class="check-container">
                        <label>
                            <el-checkbox v-model="selectChecked"
                                @change="handleSelectChecked">
                            </el-checkbox>
                            <span>我确认该印章式样无误，符合我司在合制平台进行电子签章时的使用需要。</span>
                        </label>
                    </div>
                    <el-button type="primary" :disabled="!selectChecked" size="small" @click="contractSeal('confirm')" v-if="contractSealFlag">确认生成印章</el-button>
                    <el-button type="primary" :disabled="!selectChecked" size="small" @click="projectSeal('confirm')" v-else>确认生成印章</el-button>
                    <el-button size="small" @click="addCorporateDialogVisible=false">取消</el-button>
                </div>
            </template>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>

    </div>
</template>
<script>
    import Loading from "@/components/base/Loading";
    import { InterfaceService } from "@/services/api";
    import PanelTitle from "@/components/base/PanelTitle";
    const sealList = [
        { label: "合同专用章", type: 1, sealData: "" },
        { label: "项目专用章", type: 2, sealData: "" }
    ];
    const changeSealParams = {
        esignId:'',
        acctType:"2",
        processFlg:'',
        sealType:'',
        mainText:'',
        hText:'',
        qText:'',
        sealData:'',
        sealParamFront:''
    };
    export default {
        name: "corporateSeal",
        components: {
            PanelTitle,
            Loading,
        },
        data(){
            return{
                tabs: [
                    { label: "系统生成", index: 1, active: true },
                ],
                isLoading: false,
                sealList: this.$clone(sealList),
                changeSealParams: Object.assign({}, changeSealParams),
                img:'',
                addCorporateDialogVisible:false,
                companySealList:[],
                tab : "1",
                hPlaceholder:"限8个字符",
                qPlaceholder:"限20个字符",
                changeSealData:'',
                signUserinfo:'',
                ruleForm: {
                    mainText: { required: true, message: "请输入企业名称" }
                },
                contractSealFlag:false,
                selectChecked: false // 是否勾选
            }
        },
        computed:{
            acctId() {
                return (
                    this.$store.state.userInfo && this.$store.state.userInfo.acctId
                );
            },
            corpName() {
                return (
                    this.$store.state.userInfo && this.$store.state.userInfo.corpName
                );
            },
            specialRole(){
                return this.$store.state.userInfo &&
                    (this.$store.state.userInfo.contractCorpType == "construction" ||
                        this.$store.state.userInfo.contractCorpType ==  "supervisory")
            }
            // canPreview(){
            //     if (this.changeSealParams.mainText.length > 25){
            //         this.changeSealParams.hText = this.changeSealParams.qText ="";
            //         this.hPlaceholder = "企业名称已超过25个字符，无法添加横向文内容";
            //         this.qPlaceholder = "企业名称已超过25个字符，无法添加下弦文内容";
            //         return false
            //     } else {
            //         this.hPlaceholder = "限8个字符";
            //         this.qPlaceholder = "限15个字符";
            //         return true
            //     }
            // }
        },

        methods:{
            init(){
                if (this.specialRole) {
                    this.sealList = [
                            { label: "项目专用章", type: 2, sealData: "" }
                        ];
                }
                this.getSealList();
                this.getAccountInfo();
            },
            handleSelectChecked() {
                this.contractSealFlag ? this.contractSeal('refresh') : this.projectSeal('refresh')
            },
            handleChangeTab(tab) {
                this.tab = tab.index;
            },
            getSealList(){
                let params = {
                    sealDataType:2 // 获取公司印章列表参数
                };
                InterfaceService.getSealList(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            if (data.respData.respCode == "0000") {
                                let sealDataList = data.respData.sealDataList || [];
                                if (sealDataList.length > 0) {
                                    sealDataList.forEach(item => {
                                        if (!this.specialRole) {
                                            if (item.sealParam == "41" ||item.sealParam == "22" ||item.sealParam == "31" ){
                                                this.sealList[0].sealData = item.sealData
                                                this.sealList[0].active = true
                                            }else if (item.sealParam == "25" ||item.sealParam == "33,02" ||item.sealParam == "11"){
                                                this.sealList[1].sealData = item.sealData
                                                this.sealList[1].active = true
                                            }
                                        }else {
                                            if (item.sealParam == "25" ||item.sealParam == "33,02" ||item.sealParam == "11"){
                                                this.sealList[0].sealData = item.sealData;
                                                this.sealList[0].active = true
                                            }
                                        }
                                    });
                                }
                                console.log(this.sealList);
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            checkSignVisible(){
                return true
            },
            handleSelectSign(item,index){
                this.selectChecked = false
                if (item.sealData){
                    return
                } else {
                    this.changeSealParams.mainText = this.corpName;
                    this.changeSealData = item.sealData;
                    this.addCorporateDialogVisible = true;
                    // this.changeSealParams.sealParamFront = index + 1;
                    this.changeSealParams.sealParamFront = item.type;
                    if (item.type == "1"){                                    //判断点击：1是合同章，2是项目章
                        this.contractSealFlag = true;
                        this.contractSeal("refresh")
                    }else {
                        this.contractSealFlag = false;
                        this.projectSeal("refresh")
                    }
                }
            },
            handleclearText(){
                this.changeSealParams.hText = "";
                this.changeSealParams.qText = "";
            },
            contractSeal(type){  //创建预览合同
                this.changeSealParams.esignId = this.signUserinfo.esignId;
                if (type == "refresh") {
                    this.changeSealParams.processFlg = "0";
                }else if(type == "confirm"){
                    this.changeSealParams.processFlg = "1";
                }
                let params = {};
                params = Object.assign(params, this.changeSealParams);
                InterfaceService.contractSeal(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            if (data.respData.respCode == "0000") {
                                const result = data.respData;
                                if (type == "refresh"){
                                    this.changeSealData = result.sealDataPreViewList[0].sealData
                                }
                                if (type == "confirm") {
                                    this.addCorporateDialogVisible = false;
                                    this.getSealList();
                                    this.$message.success("添加印章成功")
                                }
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            projectSeal(type){  //创建预览合同
                this.changeSealParams.esignId = this.signUserinfo.esignId;
                if (type == "refresh") {
                    this.changeSealParams.processFlg = "0";
                }else if(type == "confirm"){
                    this.changeSealParams.processFlg = "1";
                }
                let params = {};
                params = Object.assign(params, this.changeSealParams);
                InterfaceService.projectSeal(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            if (data.respData.respCode == "0000") {
                                const result = data.respData;
                                if (type == "refresh"){
                                    this.changeSealData = result.sealDataPreViewList[0].sealData
                                }
                                if (type == "confirm") {
                                    this.addCorporateDialogVisible = false;
                                    this.getSealList();
                                    this.$message.success("添加印章成功")
                                }
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            getAccountInfo(){
                const params = {
                    acctId: this.acctId
                };
                InterfaceService.accountInfo(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            const result = data.respData;
                            this.signUserinfo = result;
                            console.log(this.signUserinfo);
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
        },
        mounted(){
            this.init();
        }
    }
</script>

<style lang="scss" scoped>
    /deep/ .el-checkbox__input.is-checked + .el-checkbox__label {
        color: #444444;
    }
    .check-container {
        margin-bottom: 20px;
        margin-left: 200px;
        span {
            margin-left: 6px;
        }
    }
    .product {
        font-size: 14px;
        .tip{
            height: 20px;
            line-height: 20px;
            margin-top: 16px;
            padding-left: 40px;
            background: url("../../assets/images/icon/tip.png") no-repeat 11px center;
        }
    }

    .nowrap {
        white-space: nowrap;
    }


    .header {
        margin-bottom: 20px;
        background: #f5f5f5;
    }

    .header ul {
        width: 100%;
        height: 48px;
        border-bottom: 3px solid #ffd64e;
        font-weight: bold;

        .add {
            float: right;
            color: #4f525a;
            width: 130px;
            height: 26px;
            line-height: 26px;
            margin-right: 20px;
            background: #ffd64e;
            margin-top: 10px;
            font-weight: 500;
        }
        .add:hover {
            color: #000000;
            background-color: #f3c52f;
        }

        li {
            width: 110px;
            height: 48px;
            line-height: 48px;
            text-align: center;
            float: left;
            cursor: pointer;
            position: relative;

            &:after {
                display: none;
                position: absolute;
                bottom: 0px;
                left: 0;
                content: "";
                width: 110px;
                height: 3px;
                background: #4f525a;
            }

            &.active:after {
                display: block;
            }
        }
    }

    /deep/ .el-button {
        width: 100px;
    }

    p {
        margin: 10px 0;
    }

    .link {
        text-decoration: underline;
        cursor: pointer;
        color: #0082ff;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }
    }

    .preview-seal {
        position: relative;
        display: inline-block;
        vertical-align: middle;
        margin: 10px;
        text-align: center;
        .wait-to-add{
            width: 60px;
            height: 60px;
            font-size: 60px;
            color: #cccccc;
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 40px;
            margin: auto;
        }
        p{
            color: #ccc;
            margin-top: 0;
        }
        img {
            max-width: 218px;
            max-height: 218px;
            vertical-align: middle;
        }

        label {
            display: inline-block;
            margin: 10px 0;
            color: #888888;
        }

        i {
            font-size: 30px;
            color: #ccc;
        }

        .preview-seal-content {
            position: relative;
            width: 300px;
            height: 220px;
            line-height: 96px;
            border: 1px solid #ccc;
            cursor: pointer;
            overflow: hidden;
            em{
                color: #e7e7e7;
                position: absolute;
                left: 0;
                right: 0;
                margin: 100px auto 0;
                font-size: 18px;
            }
            .seal-change{
                position: absolute;
                left: 5px;
                bottom: -35px;
            }

            .preview-seal-text {
                position: absolute;
                top: 3px;
                left: -40px;
                display: block;
                width: 100px;
                line-height: 20px;
                font-size: 12px;
                background: #eee;
                transform: rotatez(-45deg);
            }

            &.active .preview-seal-text {
                background: #ffd64e;
            }
        }
    }

    .preview-company {
        margin: 0 10px;
        .preview-seal-content {
            width: 210px;
            height: 210px;
            line-height: 146px;
        }
    }

    .pic-code {
        width: 400px;
        margin: auto;
        margin-bottom: 20px;
    }

    .sms-btn {
        width: 150px;
    }

    .float-tip {
        position: absolute;
        top: -18px;
        z-index: 1;
        display: inline-block;
        left: -8px;
        padding: 5px 10px;
        border-radius: 5px;
        white-space: nowrap;
        color: #ffffff;
        background: #ff5917;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.3);
        animation: float-tip-animate ease 1s 0s infinite alternate;
        &:before {
            position: absolute;
            bottom: -5px;
            left: 50%;
            transform: translate(-50%);
            content: "";
            border-top: 10px solid #ff5917;
            border-left: 8px solid transparent;
            border-right: 8px solid transparent;
        }
    }

    @keyframes float-tip-animate {
        from {
            transform: translateY(-2px);
        }
        to {
            transform: translateY(2px);
        }
    }
    .dialog {
        line-height: 25px;

        /deep/ .el-dialog__header {
            padding: 0;

            &:before {
                display: none;
            }
        }
    }
    .company-dialogs-tip{
        text-align: center;
    }
    .company-seal-content{
        width: 100%;
        padding: 20px 70px 50px 60px;
        img{
            width: 100%;
            height: 100%;
        }
    }
    .uplode-seal-content{
        padding: 10px 50px;

        .wait-seal-content{
            position: relative;
            border: 1px dashed #dddddd;
            width: 280px;
            height: 220px;
            background: #f8f8f8;
            text-align: center;
            padding-top: 120px;
            color: #888888;
            span{
                font-size: 20px;
            }
            p{
                margin: 0;
            }
        }
        .upload-tips{
            display: flex;
            justify-content: center;
            flex-direction: column;
            height: 220px;
            h5{
                margin-bottom: 5px;
            }
            p{
                margin: 5px 0;
            }
        }
    }
    .preview-sign {
        .preview-seal-content {
            border: 1px dashed #eee;
            background: #f8f8f8;
            &.active {
                border-style: solid;
                background: #fff;
                cursor: auto;
            }
        }
    }
    /deep/ .panel-title span.active {
        float: left;
    }
    /deep/ .dialog-footer {
        position: absolute;
        left: 150px;
        margin-top: -106px;
    }
</style>