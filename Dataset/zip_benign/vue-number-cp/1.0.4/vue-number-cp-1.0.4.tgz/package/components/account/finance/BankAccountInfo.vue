<template>
    <div>
        <div v-if="bankInfo" class="container">
            <slot></slot>
            <p class="bank-title">
                <span class="bold bank-title-label">
                    <el-radio checked></el-radio>&nbsp;收款账号</span>
                {{corpName}} {{bankAcctNo}}<span style="margin-left: 20px;">{{bankInfo.name}} | {{bankInfo.mobile}}</span>

                <el-button class="fr" style="margin-top: -10px;" type="text" @click="handleEdit">修改</el-button>
            </p>
            <div class="bank-content">
                <el-form label-width="150px" size="mini" label-position="left">
                    <el-form-item label="开户名称：">
                        <span>{{bankInfo.bankAcctName}}</span>
                    </el-form-item>
                    <el-form-item label="开户银行：">
                        <span>{{bankInfo.bankName}}</span>
                    </el-form-item>
                    <el-form-item label="银行账号：">
                        <span>{{bankInfo.bankAcctNo}}</span>
                    </el-form-item>
                    <el-form-item label="纳税人识别号：">
                        <span>{{bankInfo.taxPayerId}}</span>
                    </el-form-item>
                    <el-form-item label="开户行地址：">
                        <span>{{bankInfo.provCodeDisp}}{{bankInfo.cityCodeDisp}}{{bankInfo.districtCodeDisp}}{{bankInfo.addr}}</span>
                    </el-form-item>
                    <el-form-item label="开户行行号：">
                        <span>{{bankInfo.bankNo}}</span>
                    </el-form-item>
                    <el-form-item label="联系人：">
                        <span>{{bankInfo.name}}</span>
                    </el-form-item>
                    <el-form-item label="联系方式：">
                        <span>{{bankInfo.mobile}}</span>
                    </el-form-item>
                </el-form>
            </div>
            <p>
                <el-checkbox checked @change="handleChangePromise"></el-checkbox>&nbsp; 我司保证上述账号资料准确无误，若因以上信息有误，而因此产生的一切纠纷和责任均由我司承担。
            </p>
        </div>
        <div v-else class="bank-add">
            <a class="pointer" @click="handleEdit">新增收款账号</a>
        </div>

        <!-- 新增/编辑收款账户信息 -->
        <EditBankAcctDialog ref="editBankAcct" @close="handleCloseEdit"></EditBankAcctDialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import EditBankAcctDialog from "@/components/account/finance/EditBankAcctDialog";
import { InterfaceService } from "@/services/api";
export default {
    components: {
        Loading,
        EditBankAcctDialog
    },
    computed: {
        corpName() {
            return this.$store.state.userInfo.corpName;
        },
        bankAcctNo() {
            let str = (this.bankInfo && this.bankInfo.bankAcctNo) || "";
            if (str) {
                return str[0] + "*********" + str.substr(-1);
            } else {
                return str;
            }
        }
    },
    data() {
        return {
            isLoading: false,
            bankInfo: null
        };
    },
    methods: {
        handleEdit() {
            this.$refs["editBankAcct"].open(this.bankInfo);
        },
        handleCloseEdit(data) {
            if (data) {
                this.bankInfo = data;
            }
        },
        handleChangePromise(val){
            this.$emit('changePromise', val);
        },
        getBankAcct() {
            return this.bankInfo && this.bankInfo.bankAcctId;
        },
        getList() {
            InterfaceService.getBankList(
                {},
                data => {
                    if (data.respData.respCode === "0000") {
                        const list = data.respData.bankList;
                        if (list && list.length > 0) {
                            this.bankInfo = list[0];
                        }
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    },
    mounted() {
        this.getList();
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-form-item__label {
    font-size: 12px;
}

/deep/ .el-form-item--mini.el-form-item {
    margin-bottom: 0;
}

// /deep/ .el-checkbox__input.is-disabled.is-checked .el-checkbox__inner {
//     background-color: #ffd64e;
//     border-color: #ffd64e;

//     &:after {
//         border-color: #ffffff;
//     }
// }

.pointer {
    color: #0082ff;
}

.container {
    padding: 20px 15px;
    border: 1px solid #ececec;
    background: #f0f8ff;
}

.bank-title {
    padding-bottom: 20px;
    border-bottom: 1px solid #ececec;
}

.bank-title-label {
    width: 150px;
    display: inline-block;
}

.bank-content {
    margin: 10px 0;
    padding-bottom: 10px;
    border-bottom: 1px solid #ececec;
}

.bank-add {
}
</style>
