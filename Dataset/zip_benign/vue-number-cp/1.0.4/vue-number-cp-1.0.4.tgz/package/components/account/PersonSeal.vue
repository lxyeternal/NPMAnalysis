<template>
    <div class="product">
        <div class="header">
            <ul>
                <li class="active">本人印章</li>
            </ul>
        </div>
        <div class="tip">添加本人印章指的是创建以自己名字命名的个人印章。</div>
        <div class="preview-sign preview-seal" style="width: 100%;" v-for="(item,index) in sealList" :key="index">
            <div class="preview-seal-content"  :class="{'active':item.active}" @click="handleSelectSign(item,index,'owner')">
                <img v-if="item.sealData" :src="item.sealData? ('data:image/jpeg;base64,'+item.sealData):''">
                <i class="el-icon-plus wait-to-add" v-if="!item.sealData"></i>
                <em v-if="!item.sealData">点击添加印章</em>
            </div>
            <div class="seal-label">{{item.label}}</div>
        </div>
        <template v-if="ableToAuthoriz">
            <div class="header" style="margin-top: 25px">
                <ul>
                    <li class="active">被授权的印章</li>
                </ul>
            </div>
            <div class="tip">添加被授权的印章指的是创建已经经过印章持有人同意的个人印章。</div>
            <div class="flex">
                <div class="preview-sign preview-seal" v-for="(item,index) in authorizSealList" :key="index+'-label'">
                    <div class="preview-seal-content" :class="{'active':item.active}" @click="handleSelectSign(item,index,'others')">
                        <img v-if="item.sealData" :src="item.sealData? ('data:image/jpeg;base64,'+item.sealData):''">
                        <i class="el-icon-plus wait-to-add" v-if="!item.sealData"></i>
                        <em v-if="!item.sealData">点击添加印章</em>
                    </div>
                    <div class="seal-label">{{item.label}}</div>
                </div>
            </div>
        </template>
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="addPersonDialogVisible" width="900px" center :close-on-click-modal="false" >
            <PanelTitle :tabs="tabs" @select="handleChangeTab" bg-color="#fff" text-align="center"></PanelTitle>
            <template v-if="tab == 1">
                <div>
                    <div class="company-dialogs-tip f14 bold">温馨提示：我们会安全妥善保管您的电子印章，也请您注意账户安全，不要将自己的账号密码或验证码信息告知他人。</div>
                    <div class="company-seal-content">
                        <el-row>
                            <el-col :span="24">
                                <div class="preview-seal preview-company tc">
                                    <div class="preview-seal-content" style="margin: 0 auto;">
                                        <img :src="changeSealData? ('data:image/jpeg;base64,'+changeSealData):''">
                                    </div>
                                </div>
                            </el-col>
                        </el-row>
                    </div>

                </div>
                <div slot="footer" class="dialog-footer">
                    <el-button type="primary" size="small" @click="setSeal('confirm')" v-if="!AuthorizButton">确认生成印章</el-button>
                    <el-button type="primary" size="small" @click="authorizeSeal('confirm')" v-else>确认生成印章</el-button>
                    <el-button size="small" @click="addPersonDialogVisible=false">取消</el-button>
                </div>
            </template>
        </el-dialog>
        <!-- 实名认证 -->
        <Authentication ref="authentication" @close="handleCloseAuth"></Authentication>
        <!-- 添加授权印章 -->
        <AddAuthorize ref="authorize" @close="handleCloseAuthorize"></AddAuthorize>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>
<script>
    import Loading from "@/components/base/Loading";
    import { InterfaceService } from "@/services/api";
    import PanelTitle from "@/components/base/PanelTitle";
    import Authentication from "@/components/auth/dialog/Authentication";
    import AddAuthorize from "@/components/auth/dialog/AddAuthorize";
    const sealList = [
        { label: "本人印章", type: 1, sealData: "" },
    ];
    const authorizSealList = [
        {label: "被授权的印章", sealData: ""}
    ];
    const changeSealParams = {
        esignId:'',
        acctType:"1",
        processFlg:'',
        sealType:'',
        mainText:'',
        hText:'',
        qText:'',
        sealData:'',
        sealParamFront:''
    };
    export default {
        name: "personSeal",
        components: {
            PanelTitle,
            Loading,
            Authentication,
            AddAuthorize
        },
        data(){
            return{
                tabs: [
                    { label: "系统生成", index: 1, active: true },
                ],
                isLoading: false,
                sealList: this.$clone(sealList),
                changeSealParams: Object.assign({}, changeSealParams),
                img:'',
                addPersonDialogVisible:false,
                companySealList:[],
                tab : "1",
                changeSealData:'',
                signUserinfo:'',
                authorizSealList:this.$clone(authorizSealList),
                ableToAuthoriz:false,
                AuthorizButton:false
            }
        },
        computed:{
            userInfo() {
                return (
                    this.$store.state.userInfo
                );
            },
            bs() {
                return (
                    this.$store.state.userInfo.bs
                );
            },
            acctId() {
                return (
                    this.$store.state.userInfo.acctId
                );
            },
            corpName() {
                return (
                    this.$store.state.userInfo && this.$store.state.userInfo.corpName
                );
            },
        },
        methods:{
            init(){
                this.getAccountInfo()
                this.getSealList();
            },
            handleChangeTab(tab) {
                this.tab = tab.index;
            },
            getSealList(type){
                let params = {
                    sealDataType:1 // 获取个人印章列表参数
                };
                InterfaceService.getSealList(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            if (data.respData.respCode == "0000") {
                                let result =  data.respData.sealDataList || [];
                                if (result.length > 0){
                                    result.forEach(item=>{
                                        if (item.isOwner == "1") {
                                            this.sealList[0].sealData = item.sealData;
                                            this.sealList[0].active = true;
                                            if (type){
                                                this.$message.success("添加印章成功！");
                                            }
                                        }
                                    });
                                    if (!type){
                                        result.forEach(item=>{
                                            if(item.isOwner == "0"){
                                                item.active = true;
                                                item.label = "被授权的印章";
                                                this.authorizSealList.unshift(item)
                                            }
                                        });
                                    } else {
                                        let onOff = false;
                                        this.authorizSealList.forEach(item=>{
                                            if (result[result.length - 1].sealId == item.sealId){
                                                this.addPersonDialogVisible = false;
                                                this.$message.error("您授权的身份证号已存在授权信息，请核实！");
                                                onOff = true;
                                            }
                                        });
                                        if (!onOff && result[result.length - 1].isOwner == "0"){
                                            result[result.length - 1].active = true;
                                            result[result.length - 1].label = "被授权的印章";
                                            this.authorizSealList.unshift(result[result.length - 1])
                                            this.$message.success("添加印章成功!")
                                        }
                                    }
                                }
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            checkSignVisible(){
                return true
            },
            handleSelectSign(item,index,type){
                if (item.sealData){
                    return
                } else {
                    if (this.signUserinfo.ecAcctIdFlg == "0"){
                        this.addPersonDialogVisible = false;
                        this.$refs["authentication"].open(this.signUserinfo);
                    }else if (this.signUserinfo.ecAcctIdFlg == "1"){
                        if (type == 'owner'){
                            this.changeSealParams.esignId = this.signUserinfo.esignId;
                            this.addPersonDialogVisible = true;
                            this.AuthorizButton = false;
                            this.setSeal("refresh")
                        }else if (type == 'others'){
                            this.$refs["authorize"].open();
                        }
                    }
                }
            },
            setSeal(type){  //创建个人预览合同
                let onOff = true;
                if (type == "refresh") {
                    this.changeSealParams.processFlg = "0";
                }else if(type == "confirm"){
                    this.changeSealParams.processFlg = "1";
                }
                let params = {};
                params = Object.assign(params, this.changeSealParams);
                console.log(params);
                InterfaceService.setSeal(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            if (data.respData.respCode == "0000") {
                                const result = data.respData;
                                if (type == "refresh"){
                                    this.changeSealData = result.sealDataPreViewList[0].sealData;
                                }
                                if (type == "confirm") {
                                    this.addPersonDialogVisible = false;
                                    this.getSealList(onOff);
                                }
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            authorizeSeal(type){  //创建授权预览合同
                let onOff = true;
                if (type == "refresh") {
                    this.changeSealParams.processFlg = "0";
                }else if(type == "confirm"){
                    this.changeSealParams.processFlg = "1";
                    this.AuthorizButton = false;
                }
                let params = {};
                params = Object.assign(params, this.changeSealParams);
                console.log(params);
                InterfaceService.authorizeSeal(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            if (data.respData.respCode == "0000") {
                                const result = data.respData;
                                if (type == "refresh"){
                                    this.changeSealData = result.sealDataPreViewList[0].sealData;
                                }
                                if (type == "confirm") {
                                    this.addPersonDialogVisible = false;
                                    this.getSealList(onOff);
                                }
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            getAccountInfo(){
                const params = {
                    acctId: this.acctId
                };
                InterfaceService.accountInfo(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            this.signUserinfo = data.respData;
                            if (this.bs == "B"){
                                if (this.signUserinfo.roleIds){
                                    this.signUserinfo.roleIds.forEach(role=>{
                                        if (role.roleId == "603" || role.roleId == "1005") {
                                            this.ableToAuthoriz = true
                                        }
                                    })
                                }
                            }
                            if (this.bs == "S"){
                                if (this.signUserinfo.roleIds){
                                    this.signUserinfo.roleIds.forEach(role=>{
                                        if (role.roleId == "621") {
                                            this.ableToAuthoriz = true
                                        }
                                    })
                                }
                            }
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleCloseAuthorize(esignId) {
                    this.changeSealParams.esignId = esignId;
                    this.addPersonDialogVisible = true;
                    this.authorizeSeal("refresh");
                    this.AuthorizButton = true;
            },
            handleCloseAuth(bool,esignId) {
                if (bool) {
                    this.getAccountInfo();
                    this.changeSealParams.esignId = esignId
                    this.addPersonDialogVisible = true;
                    this.AuthorizButton = false;
                    this.setSeal("refresh");
                }
            },
        },
        mounted(){
            this.init();
        }
    }
</script>

<style lang="scss" scoped>
    /deep/ .el-checkbox__input.is-checked + .el-checkbox__label {
        color: #444444;
    }
    .product {
        font-size: 14px;
        .tip{
            height: 20px;
            line-height: 20px;
            margin-top: 16px;
            padding-left: 40px;
            background: url("../../assets/images/icon/tip.png") no-repeat 11px center;
        }
    }

    .nowrap {
        white-space: nowrap;
    }


    .header {
        margin-bottom: 20px;
        background: #f5f5f5;
    }

    .header ul {
        width: 100%;
        height: 48px;
        border-bottom: 3px solid #ffd64e;
        font-weight: bold;

        .add {
            float: right;
            color: #4f525a;
            width: 130px;
            height: 26px;
            line-height: 26px;
            margin-right: 20px;
            background: #ffd64e;
            margin-top: 10px;
            font-weight: 500;
        }
        .add:hover {
            color: #000000;
            background-color: #f3c52f;
        }

        li {
            width: 110px;
            height: 48px;
            line-height: 48px;
            text-align: center;
            float: left;
            cursor: pointer;
            position: relative;

            &:after {
                display: none;
                position: absolute;
                bottom: 0px;
                left: 0;
                content: "";
                width: 110px;
                height: 3px;
                background: #4f525a;
            }

            &.active:after {
                display: block;
            }
        }
    }

    /deep/ .el-button {
        width: 100px;
    }

    p {
        margin: 10px 0;
    }

    .link {
        text-decoration: underline;
        cursor: pointer;
        color: #0082ff;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }
    }

    .preview-seal {
        position: relative;
        /*width: 100%;*/
        display: inline-block;
        vertical-align: middle;
        margin: 10px;
        text-align: center;
        .wait-to-add{
            width: 60px;
            height: 60px;
            font-size: 60px;
            color: #cccccc;
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 40px;
            margin: auto;
        }
        p{
            color: #ccc;
            margin-top: 0;
        }
        img {
            max-width: 100%;
            max-height: 100%;
            vertical-align: middle;
        }

        label {
            display: inline-block;
            margin: 10px 0;
            color: #888888;
        }

        i {
            font-size: 30px;
            color: #ccc;
        }

        .preview-seal-content {
            position: relative;
            width: 280px;
            height: 220px;
            line-height: 96px;
            border: 1px solid #ccc;
            cursor: pointer;
            overflow: hidden;

            .seal-change{
                position: absolute;
                left: 5px;
                bottom: -35px;
            }

            .preview-seal-text {
                position: absolute;
                top: 3px;
                left: -40px;
                display: block;
                width: 100px;
                line-height: 20px;
                font-size: 12px;
                background: #eee;
                transform: rotatez(-45deg);
            }

            &.active .preview-seal-text {
                background: #ffd64e;
            }
        }
    }

    .preview-company {
        width: 100%;
        margin: 0 10px;
        .preview-seal-content {
            width: 150px;
            height: 150px;
            line-height: 146px;
        }
    }

    .pic-code {
        width: 400px;
        margin: auto;
        margin-bottom: 20px;
    }

    .sms-btn {
        width: 150px;
    }

    .float-tip {
        position: absolute;
        top: -18px;
        z-index: 1;
        display: inline-block;
        left: -8px;
        padding: 5px 10px;
        border-radius: 5px;
        white-space: nowrap;
        color: #ffffff;
        background: #ff5917;
        box-shadow: 0 3px 10px rgba(0, 0, 0, 0.3);
        animation: float-tip-animate ease 1s 0s infinite alternate;
        &:before {
            position: absolute;
            bottom: -5px;
            left: 50%;
            transform: translate(-50%);
            content: "";
            border-top: 10px solid #ff5917;
            border-left: 8px solid transparent;
            border-right: 8px solid transparent;
        }
    }

    @keyframes float-tip-animate {
        from {
            transform: translateY(-2px);
        }
        to {
            transform: translateY(2px);
        }
    }
    .dialog {
        line-height: 25px;

        /deep/ .el-dialog__header {
            padding: 0;

            &:before {
                display: none;
            }
        }
    }
    .company-dialogs-tip{
        text-align: center;
    }
    .company-seal-content{
        width: 100%;
        padding: 20px 100px 10px;
        .company-seal-img{
            img{
                width: 150px;
                height: 150px;
            }
        }
        .center{
            margin-left: 255px;
        }
    }
    .uplode-seal-content{
        padding: 10px 50px;

        .wait-seal-content{
            position: relative;
            border: 1px dashed #dddddd;
            width: 280px;
            height: 220px;
            background: #f8f8f8;
            text-align: center;
            padding-top: 120px;
            color: #888888;
            span{
                font-size: 20px;
            }
            p{
                margin: 0;
            }
        }
        .upload-tips{
            display: flex;
            justify-content: center;
            flex-direction: column;
            height: 220px;
            h5{
                margin-bottom: 5px;
            }
            p{
                margin: 5px 0;
            }
        }
    }
    .preview-sign {
        .preview-seal-content {
            border: 1px dashed #eee;
            background: #f8f8f8;
            &.active {
                border-style: solid;
                background: #fff;
                cursor: pointer;
            }
            em{
                color: #e7e7e7;
                position: absolute;
                left: 0;
                right: 0;
                margin: 100px auto 0;
                font-size: 18px;
            }
        }
    }
    .flex{
        display: flex;
        justify-content: start;
        flex-wrap: wrap;
        div{
            margin-left: 10px;
        }
    }
    .seal-label{
        margin-top: 20px;
        width: 280px;
        text-align: center;
    }
</style>