<template>
  <div class="add-role">
      <div class="header">
        <ul>
          <!--<li class="active">编辑角色</li>-->
          <li class="active">查看角色</li>
        </ul>
      </div>
      <div class="add-role-content">
          <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="150px">
            <el-form-item label="角色名称：" prop="roleName" class="role-name" style="height:40px;">
              <el-input v-model="ruleForm.roleName" placeholder="请输入角色名称，不超过20字" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="描述：" class="role-name" style="height:40px;">
              <el-input v-model="ruleForm.roleDescription" :disabled="true"></el-input>
            </el-form-item>
            <el-form-item label="权限设置：" prop="menuList">
                <div class="role-tree el-col el-col-12">
                  <h4>所有权限</h4>
                  <div>
                      <el-tree
                        :disable="true"
                        :data="roleTree"
                        show-checkbox
                        default-expand-all
                        node-key="menuID"
                        ref="tree"
                        highlight-current
                        @check-change = "getRoleNode"
                        :props="defaultProps">
                      </el-tree>
                  </div>
                </div>
                <div class="selected-role el-col el-col-12">
                  <h4>角色权限</h4>
                  <div class="selected-role-wrapper scroll-style">
                    <div class="selected-role-text clearfloat">
                        <!--<span v-for="item in selectedTree" @click="deleSelectedTree(item.menuID)">{{item.menuName}}<i class="el-icon-close"></i></span>-->
                        <span v-for="item in selectedTree">{{item.menuName}}</span>
                    </div>
                  </div>
                </div>
            </el-form-item>
          </el-form>
      </div>
      <div class="add-role-btn">
            <!--<el-button type="primary" size="small" @click="handleSave(rules)">保存</el-button>-->
            <!--<el-button size="small" @click="cancle">取消</el-button>-->
            <el-button size="small" @click="cancle">返回</el-button>
      </div>
  </div>
</template>

<script>
  import {
    InterfaceService
  } from "@/services/api";
  import Distpicker from "@/components/base/Distpicker";
  import CryptoJS from 'crypto-js';

  export default {
    components: {
      Distpicker
    },
    props: {
      accountType: {
        type: String,
        default: ''
      },
      role:{
        type: Object,
        default: function () {
          return {}
        }
      },
    },
    data() {
      return {
        ruleForm: {
          roleName: '',
          roleDescription: '',
          menuList: '',
        },
        lastForm:{},
        rules: {
          roleName: [{
            required: true,
            message: '请输入角色名称',
            trigger: 'blur'
          }],
          menuList: [{
            required: true,
            message: '请选择',
            trigger: 'blur'
          }]
        },
        roleTree:[],
        updatedTree:[],
        defaultProps: {
          children: 'menuList',
          label: 'menuName',
        },
        selectedTree:[],
        findChild:[]
      };
    },
    computed:{
      userInfo(){
        // console.log(this.$store.state.LoginedUser.custName)
        return this.$store.state.userInfo
      },
    },
    methods: {
      init(){
        // this.ruleForm.roleName = (this.$route.query.role && this.$route.query.role.roleName) || '';
        // this.ruleForm.roleDescription = (this.$route.query.role && this.$route.query.role.roleDescription) || '';
        // this.ruleForm.roleID = (this.$route.query.role && this.$route.query.role.roleId) || ''
        // this.lastForm = this.$route.query.role || {}
        this.ruleForm.roleName = (this.role && this.role.roleName) || '';
        this.ruleForm.roleDescription = (this.role && this.role.roleDescription) || '';
        this.ruleForm.roleID = (this.role && this.role.roleId) || ''
        this.lastForm = this.role || {}
        this.lastForm.menuList = []
        this.getTreeSource()
      },
      getTreeSource(){
        InterfaceService.roleTreeByRoleId({'roleID':this.role.roleId || ''}, (data) => {
            let res = data.respData
            this.roleTree = res.menuList[0].menuList
                this.roleTree.forEach(item=>{
                    item.disabled = true;
                    item.menuList.forEach(_item=>{
                        _item.disabled = true
                    })
                });
            setTimeout(()=>{
               this.initTree(this.roleTree)
            },1);
            
          },
          data => {},
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
        
      },
      initTree(roleTree){
        
        for(var i in roleTree){
          let item = roleTree[i]
          if(item.menuAvailable == '1'){
            this.lastForm.menuList.push(item.menuID)
            this.$refs.tree.setChecked(item.menuID,true,false)
          }
          if(item.menuList){
            this.initTree(item.menuList)
          }
        }
      },
      getRoleNode(node,selfstatus,childstatus){
          this.selectedTree = []
          let halfCheckedNodes = this.$refs.tree.getHalfCheckedNodes()
          let checkedNodes = this.$refs.tree.getCheckedNodes()
          this.selectedTree = this.selectedTree.concat(halfCheckedNodes)
          this.selectedTree = this.selectedTree.concat(checkedNodes)
          this.ruleForm.menuList = ''
          if(this.selectedTree.length > 0){
            this.ruleForm.menuList = '1'
          }
          this.$forceUpdate();
      },
      cancle(){
        this.$emit('cancel');
        // if(this.userInfo && this.userInfo.bs && this.userInfo.bs == 'B') {
        //   this.$router.push({
        //       path: "/purchaserCenter/roleManage"
        //   });
        // }else{
        //   this.$router.push({
        //       path: "/vendorCenter/roleManage"
        //   });
        // }
      },
      deleSelectedTree(id){
        this.$refs.tree.setChecked(id,false,false)
        this.findId(id,this.roleTree)
        this.deleLeaf(this.findChild)

        this.ruleForm.menuList = ''
          if(this.selectedTree.length > 0){
            this.ruleForm.menuList = '1'
          }
          this.$forceUpdate(); 
      },
      findId(id,roleTree){
        for(let k = 0;k<roleTree.length;k++){
          let roleK = roleTree[k]
          if(roleK.menuID && id == roleK.menuID){
            this.findChild = roleK.menuList || []
            break;
          }else{
              if(roleK.menuList){
                this.findId(id,roleK.menuList)
              }
          }
        }
      },
      deleLeaf(roleTree){
        for(let j in roleTree){
          let role = roleTree[j]
          this.$refs.tree.setChecked(role.menuID,false,false)
          if(role.children){
            this.deleLeaf(role.children)
          }
        }
      },
      updateTreeToSubmit(availabeArr){

        let formArray = this.treeToArray(this.roleTree,[])
        //console.log(formArray)
        for(let k=0;k<formArray.length;k++){
          let formArrayItem = formArray[k]
          formArrayItem.menuAvailable = '0'
          for(let m = 0;m<availabeArr.length;m++){
            if(formArrayItem.menuID == availabeArr[m].menuID){
              formArrayItem.menuAvailable = '1'
            }
          }
        }

        return formArray
      },
      treeToArray(tree,arr){
          let res = arr
          for(let n=0;n<tree.length;n++){
            let treeItem = tree[n]
            res.push({
                menuAvailable: treeItem.menuAvailable,
                menuDisplaySort: treeItem.menuDisplaySort,
                menuID: treeItem.menuID,
                menuLevel: treeItem.menuLevel,

                menuName: treeItem.menuName,
                menuParentID: treeItem.menuParentID,
                menuStatus: treeItem.menuStatus,
                menuType: treeItem.menuType,
                menuURL:treeItem.menuURL
            })

            if(treeItem.menuList && treeItem.menuList.length > 0){
              this.treeToArray(treeItem.menuList,res)
            }
          }

          return res
      },
      handleSave(rules){
          let _this = this;

          _this.$refs.ruleForm.validate((valid) => {
            if (valid) {
                _this.ruleForm.menuList = []

                let lastForm = [].concat(_this.lastForm.menuList)
                let isEdited = false;
                //
                if(_this.selectedTree.length != _this.lastForm.menuList.length){
                  isEdited = true;
                }
                for(let i =0;i< _this.selectedTree.length;i++){
                  let item = _this.selectedTree[i] 
                  let menuItem = {'menuID':item.menuID}
                  _this.ruleForm.menuList.push(menuItem)

                  if(!isEdited){
                    for(let j=0;j<lastForm.length;j++){
                      let last = lastForm[j]
                      if(item.menuID == last){
                        _this.lastForm.menuList.splice(j, 1);
                      }
                    }
                  }
                  
                }
                //判断是否修改过
                if(_this.lastForm.roleName ===  _this.ruleForm.roleName &&
                   _this.lastForm.roleDescription ===  _this.ruleForm.roleDescription &&
                   (!isEdited && _this.lastForm.menuList && _this.lastForm.menuList.length > 0 )
                  ){
                  this.$emit('cancel');
                  return false
                  // if(this.userInfo && this.userInfo.bs && this.userInfo.bs == 'B') {
                  //   this.$router.push({
                  //       path: "/purchaserCenter/roleManage"
                  //   });
                  // }else{
                  //   this.$router.push({
                  //       path: "/vendorCenter/roleManage"
                  //   });
                  // }
                  // return false
                }

                //更新树 把原始树的menuAvailable更新 提交给后端
                //_this.ruleForm.menuList = _this.updateTreeToSubmit(_this.ruleForm.menuList)

                //console.log(_this.ruleForm)
                InterfaceService.editeRole(_this.ruleForm, (data) => {
                    let res = data.respData
                    if(res.respCode === '0000'){
                      this.$message({
                        message: '编辑角色成功',
                        type: 'success'
                      });
                      this.$emit('cancel');
                      // if(this.userInfo && this.userInfo.bs && this.userInfo.bs == 'B') {
                      //   this.$router.push({
                      //       path: "/purchaserCenter/roleManage"
                      //   });
                      // }else{
                      //   this.$router.push({
                      //       path: "/vendorCenter/roleManage"
                      //   });
                      // }
                    }else{

                    }
                    
                  },
                  data => {},
                  () => {
                    _this.isLoading = true;
                  },
                  () => {
                    _this.isLoading = false;
                  }
                );
            } else {
                
            }
          }) 
      }

    },
    mounted() {
      this.init();
        if (window.history && window.history.pushState) {
            history.pushState(null, null, document.URL);
            window.addEventListener('popstate', this.cancle, false);
        }
    },
      destroyed(){
          window.removeEventListener('popstate', this.cancle, false);
      }
  };
</script>

<style lang="scss" scoped>

  .header {
    background: #fff;
  }

  .header ul {
    width: 100%;
    height: 48px;
    font-weight: bold;

    .add {
      float: right;
      color: #4f525a;
      width: 130px;
      height: 26px;
      line-height: 26px;
      margin-right: 20px;
      background: #ffd64e;
      margin-top: 10px;
    }

    li {
      width: 80px;
      height: 48px;
      line-height: 48px;
      text-align: center;
      float: left;
      cursor: pointer;
      position: relative;
      font-size:14px;

      &:after{
        width:4px;height:14px;
        background:#ffd64e;
        top:50%;
        left:0;
        margin-top:-7px;
        content:'';
        position:absolute;
      }
    }
  }

  .add-role-content{
    background:#f5f5f5;
    padding-top:20px;
    padding-right:150px;
    padding-bottom:10px;
    
    /deep/ .el-form > .el-form-item{
      &:nth-child(1){
        .el-form-item__content{
          height:40px;
        }
      }

      &:nth-child(2){
        .el-form-item__content{
          height:40px;
        }
      }
    }
    
  }
  
  .selected-role-wrapper{
      height:410px;
      overflow-y:scroll;
    }
  .role-tree{
    height:450px;
    background:#fff;
    border-right:1px solid #eee;
    padding-left:20px;
    
    /deep/ .el-tree{
      height:410px;
      overflow-y:scroll;
    }

    h4{
      height:40px;
      line-height:40px;
      font-size:12px;
      color:#333;
      border-bottom:1px solid #eee;
    }
  }

  .selected-role{
    height:450px;
    background:#fff;
    padding-left:20px;

    h4{
      height:40px;
      line-height:40px;
      font-size:12px;
      color:#333;
      border-bottom:1px solid #eee;
    }

    .selected-role-text{
        padding-top:20px;

       span{
        padding:10px;
        background:#f5f5f5;
        font-size:12px;
        color:#333;
        line-height:1;
        float:left;
        margin-right:14px;margin-bottom:10px;
        /*cursor:pointer;*/

        
       }

       /deep/ .el-icon-close{
          margin-left:10px
        }
    }


  }
  .add-role-btn{padding-top:20px;}
</style>