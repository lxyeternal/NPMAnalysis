<template>
  <div class="add-role">
      <div class="header">
        <ul>
          <li class="active">添加角色</li>
        </ul>
      </div>
      <div class="add-role-content">
          <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="150px">
            <el-form-item label="角色名称：" prop="roleName" style="height:40px;">
              <el-input v-model="ruleForm.roleName" placeholder="请输入角色名称，不超过20字"></el-input>
            </el-form-item>
            <el-form-item label="描述：" style="height:40px;">
              <el-input v-model="ruleForm.roleDescription" placeholder="描述角色，非必填"></el-input>
            </el-form-item>
            <el-form-item label="权限设置：" prop="menuList">
                <div class="role-tree el-col el-col-12">
                  <h4>可选择权限</h4>
                  <div>
                      <el-tree
                        :data="roleTree"
                        show-checkbox
                        default-expand-all
                        node-key="menuID"
                        ref="tree"
                        highlight-current
                        @check-change = "getRoleNode"
                        :props="defaultProps">
                      </el-tree>
                  </div>
                </div>
                <div class="selected-role el-col el-col-12">
                  <h4>已选择权限</h4>
                  <div class="selected-role-wrapper scroll-style">
                    <div class="selected-role-text clearfloat">
                        <span v-for="item in selectedTree" @click="deleSelectedTree(item.menuID)">{{item.menuName}}<i class="el-icon-close"></i></span>
                    </div>
                  </div>
                </div>
            </el-form-item>
            
          </el-form>
      </div>
      <div class="add-role-btn">
            <el-button type="primary" size="small" @click="submit('rules')">保存</el-button>
            <el-button size="small" @click="cancle()">取消</el-button>
      </div>
  </div>
</template>

<script>
  import {
    InterfaceService
  } from "@/services/api";
  export default {
    components: {
      
    },
    props: {
      accountType: {
        type: String,
        default: ''
      }
    },
    data() {
      return {
        ruleForm: {
          roleName: '',
          roleDescription: '',
          menuList: '',
        },
        rules: {
          roleName: [{
            required: true,
            message: '请输入角色名称',
            trigger: 'blur'
          }],
          menuList: [{
            required: true,
            message: '请选择',
            trigger: 'blur'
          }]
        },
        roleTree:[],
        defaultProps: {
          children: 'menuList',
          label: 'menuName'
        },
        selectedTree:[]
      };
    },
    computed:{
      userInfo(){
        // console.log(this.$store.state.LoginedUser.custName)
        return this.$store.state.userInfo
      },
    },
    methods: {
      init(){
        this.getTreeSource()
      },
      //获取权限树原始数组
      getTreeSource(){
        InterfaceService.roleTree({}, (data) => {
            let res = data.respData
            this.roleTree = res.menuList[0].menuList
            //this.roleTree = this.$arrayToTree(res.menuList,'menuID','menuParentID')
            console.log(this.roleTree)
          },
          data => {},
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      },
      //获取选中的权限 显示在右边
      getRoleNode(node,selfstatus,childstatus){
          this.selectedTree = []
          let halfCheckedNodes = this.$refs.tree.getHalfCheckedNodes()
          let checkedNodes = this.$refs.tree.getCheckedNodes()
          this.selectedTree = this.selectedTree.concat(halfCheckedNodes)
          this.selectedTree = this.selectedTree.concat(checkedNodes)

          this.ruleForm.menuList = ''
          if(this.selectedTree.length > 0){
            this.ruleForm.menuList = '1'
          }
          this.$forceUpdate(); 
      },
      cancle(){
        this.$emit('cancel');
        // if(this.userInfo && this.userInfo.bs && this.userInfo.bs == 'B') {
        //   this.$router.push({
        //       path: "/purchaserCenter/roleManage"
        //   });
        // }else{
        //   this.$router.push({
        //       path: "/vendorCenter/roleManage"
        //   });
        // }
      },
      //根据右边的按钮 控制右边树的选中状态
      deleSelectedTree(id){
        this.$refs.tree.setChecked(id,false,false)
        this.findId(id,this.roleTree)
        this.deleLeaf(this.findChild)

        this.ruleForm.menuList = ''
          if(this.selectedTree.length > 0){
            this.ruleForm.menuList = '1'
          }
          this.$forceUpdate(); 
      },
      findId(id,roleTree){
        for(let k = 0;k<roleTree.length;k++){
          let roleK = roleTree[k]
          if(roleK.menuID && id == roleK.menuID){
            this.findChild = roleK.menuList || []
            break;
          }else{
              if(roleK.menuList){
                this.findId(id,roleK.menuList)
              }
          }
        }
      },
      deleLeaf(roleTree){
        for(let j in roleTree){
          let role = roleTree[j]
          this.$refs.tree.setChecked(role.menuID,false,false)
          if(role.menuList){
            this.deleLeaf(role.menuList)
          }
        }
      },
      submit(rules){
          let _this = this;
          _this.$refs.ruleForm.validate((valid) => {
          if (valid) {
              _this.ruleForm.menuList = []
              for(let i =0;i< _this.selectedTree.length;i++){
                let item = _this.selectedTree[i] 
                let menuItem = {'menuID':item.menuID}
                _this.ruleForm.menuList.push(menuItem)
              }
              InterfaceService.addRole(_this.ruleForm, (data) => {
                  let res = data.respData
                  if(res.respCode === '0000'){
                    this.$message({
                      message: '新增角色成功',
                      type: 'success'
                    });
                    this.$emit('cancel');
                    // if(this.userInfo && this.userInfo.bs && this.userInfo.bs == 'B') {
                    //   this.$router.push({
                    //       path: "/purchaserCenter/roleManage"
                    //   });
                    // }else{
                    //   this.$router.push({
                    //       path: "/vendorCenter/roleManage"
                    //   });
                    // }
                    
                  }else{

                  }
                  
                },
                data => {},
                () => {
                  _this.isLoading = true;
                },
                () => {
                  _this.isLoading = false;
                }
              );
          } else {
              
          }
          })     

        },

    },
    mounted() {
      this.init();
    }
  };
</script>

<style lang="scss" scoped>

  .header {
    background: #fff;
  }

  .header ul {
    width: 100%;
    height: 48px;
    font-weight: bold;

    .add {
      float: right;
      color: #4f525a;
      width: 130px;
      height: 26px;
      line-height: 26px;
      margin-right: 20px;
      background: #ffd64e;
      margin-top: 10px;
    }

    li {
      width: 80px;
      height: 48px;
      line-height: 48px;
      text-align: center;
      float: left;
      cursor: pointer;
      position: relative;
      font-size:14px;

      &:after{
        width:4px;height:14px;
        background:#ffd64e;
        top:50%;
        left:0;
        margin-top:-7px;
        content:'';
        position:absolute;
      }
    }
  }

  .add-role-content{
    background:#f5f5f5;
    padding-top:20px;
    padding-right:150px;
    padding-bottom:10px;

    /deep/ .el-form > .el-form-item{
      &:nth-child(1){
        .el-form-item__content{
          height:40px;
        }
      }

      &:nth-child(2){
        .el-form-item__content{
          height:40px;
        }
      }
    }
 
  }
  .selected-role-wrapper{
      height:410px;
      overflow-y:scroll;
    }
  .role-tree{
    height:450px;
    background:#fff;
    border-right:1px solid #eee;
    padding-left:20px;
    
    /deep/ .el-tree{
      height:410px;
      overflow-y:scroll;

     
    }

    h4{
      height:40px;
      line-height:40px;
      font-size:12px;
      color:#333;
      border-bottom:1px solid #eee;
    }
  }

  .selected-role{
    height:450px;
    background:#fff;
    padding-left:20px;

    h4{
      height:40px;
      line-height:40px;
      font-size:12px;
      color:#333;
      border-bottom:1px solid #eee;
    }

    .selected-role-text{
        padding-top:20px;

       span{
        padding:10px;
        background:#f5f5f5;
        font-size:12px;
        color:#333;
        line-height:1;
        float:left;
        margin-right:14px;margin-bottom:10px;
        cursor:pointer;

        
       }

       /deep/ .el-icon-close{
          margin-left:10px
        }
    }


  }
  .add-role-btn{padding-top:20px;}
</style>