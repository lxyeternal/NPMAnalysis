<template>
    <div class="content">
        <div class="order-info-title">
            <span class="bold f14">生成清单明细</span>
            <span v-if="!detail"  class="f12">符合条件的货品数量共<em class="red f18">{{totalGoods | formatMoney(0)}}</em>款</span>
            <span v-else class="f12">本项目可选型的货品数量共<em class="red f18">{{totalGoods | formatMoney(0)}}</em>款</span>
            <el-button size="small" v-if="!selectionInfo || selectionInfo.status !== 'canceled'" class="fr" @click="handleOpenBatchDl" :class="{'detail-btn':detail}">批量下载</el-button>
        </div>
        <div v-if="detail" class="f12" style="margin-bottom: 10px;">已提交选型的货品有<em class="red f18">{{selectionInfo.choiceSkuCnt | formatMoney(0)}}</em>款，供应商有<em class="red f18">{{selectionInfo.uploadFileSupplierCnt | formatMoney(0)}}</em>家</div>
        <div class="table">
            <table>
                <thead>
                <tr class="tc">
                    <td style="width: 50px;">序号</td>
                    <td style="width: 35px;">&nbsp;</td>
                    <td style="width: 340px">供应商</td>
                    <td>&nbsp;</td>
                    <td style="width: 100px;">符合条件的<p>货品数量(款)</p></td>
                    <td style="width: 30px;">&nbsp;</td>
                    <td style="width: 150px;">履约评估</td>
                    <td style="width: 30px;">&nbsp;</td>
                    <td style="width: 92px;">舆情评估</td>
                    <td style="width: 30px;">&nbsp;</td>
                    <td style="width: 170px;">操作</td>
                </tr>
                </thead>
                <template>
                    <tbody v-for="(item,index) in supplierDetailList" :key="index" class="tl tbody-row">
                    <tr>
                        <td align="right">{{index+1}}
                            <div class="tip" v-if="detail && (item.showPoint || item.mergeUploadFlg)">
                                <el-popover popper-class="dark-popover" trigger="hover" placement="right">
                                    <div class="tooltip-content">
                                        <p>该三角符号表示：该项目提交过选型记录的标识。</p>
                                    </div>
                                    <div slot="reference">
                                        <div class="tip-text">
                                        </div>
                                    </div>
                                </el-popover>
                            </div>
                        </td>
                        <td style="width: 35px;" v-if="item.lockFlg === '0' || !detail">&nbsp;</td>
                        <td style="width: 35px;" v-if="item.lockFlg === '1' && detail">
                            <el-popover popper-class="dark-popover" trigger="hover" placement="right">
                                <div class="tooltip-content">
                                    <p>主选型人已锁定选型。</p>
                                </div>
                                <div slot="reference">
                                    <img style="margin-top: 8px;" src="../../assets/images/icon/lock.png" >
                                </div>
                            </el-popover>
                        </td>
                        <td style="width: 340px">
                            <span>{{item.corpName}}</span>
                            <el-popover popper-class="dark-popover" trigger="hover" placement="right-end" v-if="item.corpStatus === '1'">
                                <div class="tooltip-content">
                                    <p><span>经营模式</span>：{{item.supplierType === "0" ? "厂家":"经销商"}}</p>
                                    <p><span>联&nbsp;&nbsp;系&nbsp;&nbsp;人</span>：{{item.contactName}}</p>
                                    <p><span>联系方式</span>：{{item.contactMobile}}</p>
                                    <p><span>邮&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;箱</span>：{{item.contactEmail}}</p>
                                    <p><span>所在地区</span>：{{item.city}}</p>
                                </div>
                                <span slot="reference" > <img style="vertical-align:top;" src="../../assets/images/icon/phone.png"></span>
                            </el-popover>
                            <div class="tl">
                                <span class="nailsupply" v-for="tag in item.tags && item.tags" :key="tag.tagId">{{tag.tagName}}</span>
                            </div>
                        </td>
                        <td>&nbsp;</td>
                        <td class="tr">{{item.skuCnt | formatMoney(0)}}</td>
                        <td style="width: 30px;">&nbsp;</td>
                        <td>{{item.assessLevelName}}</td>
                        <td style="width: 30px;">&nbsp;</td>
                        <td>{{item.riskLevelName}}</td>
                        <td style="width: 30px;">&nbsp;</td>
                        <td class="blue operation">
                            <template v-if="create">
                                <p>
                                    <span class="hand" @click="handleDownloadOrSee(item,'download')">下载</span>
                                    <span class="hand" style="margin: 0 10px;" @click="handleDownloadOrSee(item,'see')">预览</span>
                                </p>
                                <p>
                                    <span class="hand" @click="goPerformanceReport(item.corpId,item.corpStatus,item.corpName)">供应商评估报告</span>
                                </p>
                            </template>
                            <template v-else>
                                <template v-if="selectionInfo.status !== 'canceled'">
                                    <div>
                                        <!--<span class="hand" v-if="item.lockFlg !== '1' || mainSelection" @click="handleOperation(item)">下载/上传清单</span>-->
                                        <span class="hand" v-if="item.lockFlg !== '1' || mainSelection" @click="handleOperation(item,'download')">下载</span>
                                        <span class="hand" v-if="item.lockFlg !== '1' || mainSelection" @click="handleOperation(item,'upload')">上传</span>
                                        <span class="hand" v-if="item.lockFlg === '1' && subSelection" @click="handleDownloadOrSee(item,'download')">下载清单</span>
                                        <span class="hand" @click="handleDownloadOrSee(item,'see')">在线预览</span>
                                    </div>
                                    <div v-if="mainSelection">
                                        <span class="hand" v-if="hasSub" @click="setUpEndSelection(item)">{{item.lockFlg === '1'?"解锁":"锁定"}}选型</span>
                                        <span class="hand" @click="goPerformanceReport(item.corpId,item.corpStatus,item.corpName)">供应商评估报告</span>
                                    </div>
                                </template>
                                <template v-else>
                                    <div>
                                        <span class="hand" @click="handleDownloadOrSee(item,'see')">在线预览</span>
                                        <span v-if="mainSelection" class="hand" @click="goPerformanceReport(item.corpId,item.corpStatus,item.corpName)">供应商评估报告</span>
                                    </div>
                                </template>
                            </template>
                        </td>
                    </tr>
                    <tr v-if="detail && item.showTips && mainSelection" class="tips">
                        <td colspan="11">
                            <div>
                                <span>截止{{item.creTmList && item.creTmList.sort()[item.creTmList.length-1]}},</span>
                                <em>{{item.subPersonList && item.subPersonList.join("、")}}</em>
                                <span>已提交选型。请至【在线预览】或【下载】下载查看。</span>
                                <i class="el-icon-close fr" @click="handleCloseTip(item,index)"></i>
                            </div>
                        </td>
                    </tr>
                    </tbody>
                </template>
            </table>
            <div v-if="detail" class="red tip-cont" style="margin-top:10px">
                <p>
                    ※ 若选型范围中有未入驻合制平台的供应商，请向供应商提供合制平台客服信息并要求其入驻。
                </p>
                <p>
                    &nbsp;&nbsp;&nbsp;&nbsp;如需添加选型范围外的货品，请联系供应商或合制平台运营组上架相关商品。客服电话：400-009-0506(工作日9:00-18:00)
                </p>
            </div>
        </div>
        <el-dialog class="dialog import-list-dialog" :lock-scroll="true" title="下载资料" :modal-append-to-body='false' :visible.sync="dialogVisible" width="900px" center :close-on-click-modal="false" :close-on-press-escape="false">
            <el-row>
                <el-col :span="12" v-for="(item,ind) in packageList" :key="ind">
                    <el-checkbox v-model="item.checked"  @change="handleSelectRow(packageList,item,ind,'S')"><span class="f12 black"  :class="{'bold':item.checked}">{{item.disp}}</span></el-checkbox>
                </el-col>
            </el-row>
            <div class="dialog-footer tc" style="margin-top: 20px;">
                <el-button :disabled="!noSelected" type="primary" @click="handleBatchDownload">打包下载</el-button>
                <el-button @click="dialogVisible= false">取消</el-button>
            </div>
        </el-dialog>
        <SelectionAttachmentManage :mainSelection="mainSelection" ref="attachmentManage" @refresh = "handleRefresh"></SelectionAttachmentManage>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    import SelectionAttachmentManage from "@/components/onlineModelSelection/dialog/SelectionAttachmentManage";
    import { viewFile } from '@/utils/orderUtil';
    import { InterfaceService } from "@/services/api";
    import Loading from "@/components/base/Loading";
    import accountMixin from "@/mixins/account";

    export default {
        mixins: [accountMixin],
        name: "SupplierDetailList",
        props:["supplierDetailList","selectionName","create","selectionNo","mainSelection","subSelection","selectionInfo","hasSub","detail","lastNoticeTm"],
        components:{
            SelectionAttachmentManage,
            Loading,
        },
        data() {
            return {
                isLoading:false,
                dialogVisible:false,
                hasMergeList:false,
                packageList:[],
                attachList:[],
                lastCreTmList:[],
                showSendingBtn:false,
            }
        },
        watch:{
            supplierDetailList: {
                handler(newValue, oldValue) {
                    if (newValue && !this.detail) {
                        // this.createBatcDownloadhData();
                    }else if (this.detail) {
                        // newValue.forEach(item=>{
                        //
                        // });
                        // this.init();
                    }
                },
                deep: true
            },
        },
        computed: {
            totalGoods(){
                let num = 0;
                this.supplierDetailList.forEach(item=>{
                    num += Number(item.skuCnt)
                });
                return num
            },
            noSelected() {
                return this.packageList.some(item=>{return item.checked})
            }
        },
        methods:{
            handleOperation(item,openType){
                this.$refs["attachmentManage"].open(item,this.selectionNo,openType)
            },
            handleSelectRow(list,row, index) {
                this.$set(list, index, row);
            },
            handleOpenBatchDl() {
                if (this.detail) {
                    let list = [];
                    let listTypeList = [];
                    if (this.mainSelection) {
                        listTypeList = ["MERGE_LIST","SUB_RANGE_LIST"]
                    } else {
                        listTypeList = ["SUB_LIST","SUB_RANGE_LIST"]
                    }
                    if (this.supplierDetailList) {
                        this.supplierDetailList.forEach((item)=>{
                            list.push(item.corpId)
                        })
                    }
                    this.getSelectionFiles(list,listTypeList)
                }else {
                    this.selectionFileDownload()
                    // this.handleBatchDownload()
                }
            },
            createBatcDownloadhData(corpList) {
                this.attachList = [];
                if (corpList &&corpList.length) {
                    corpList && corpList.forEach(item=>{
                        item.selectionAttachList && item.selectionAttachList.forEach(_item=>{
                            this.attachList.push({
                                attachName:_item.attachName,
                                attachUrl:_item.attachUrl,
                                listType:_item.listType,
                                supplierName:item.corpName,
                            })
                        })
                    })
                }
                let list = [];
                this.packageList = [];
                this.attachList.forEach(_item=>{
                    list.push(_item.listType)
                });
                let unique = (arr)=> [...new Set(arr)];
                unique(list).forEach((item)=>{
                    if (item === "MERGE_LIST") {
                        this.packageList.push({
                            type : item,
                            disp : "所有选型清单(汇总版) | 选型记录汇总清单",
                        })
                    }else if (item === "SUB_LIST") {
                        this.packageList.push({
                            type : item,
                            disp : "所有选型清单(协同选型版) | 协同选型人员使用",
                        })
                    }
                });
                this.packageList.forEach(item=>{
                    item.checked = true
                });
                this.handleBatchDownload()
            },
            handleCloseTip(item,index) {
                item.showTips = false;
                this.$emit("operationTips",index)
                // this.lastCreTmList.forEach(_item=>{
                //     if (_item.ind === index) {
                //         _item.closed = true
                //     }
                // });
                this.$set(this.supplierDetailList, index, item);
            },
            async goPerformanceReport(corpId,status,corpName) {
                //'公司状态（0：新入驻；1：正常；;3:预注册）',
                let routeData = {}
                console.log(status);
                if (status == "0" || status == "3") {
                    routeData = this.$router.resolve({
                        path: `/evaluationReport`
                    });
                } else {
                    routeData = this.$router.resolve({
                        path: `/performanceReport`,
                        query: {
                            corpId: corpId
                        }
                    });
                }
                // 未入库供应商 先查询是否满足跳转条件
                if (status == "0" || status == "3") {
                    let result = false;
                    try {
                        result = await this.getNinvestedMedicalExamination(corpName)
                    } catch (error) { }

                    if (!result) return
                }
                window.open(routeData.href, "_blank");
                // const routeData = this.$router.resolve({
                //     path: `/performanceReport`,
                //     query: {
                //         corpId: corpId
                //     }
                // });
                // window.open(routeData.href, "_blank");
            },
            /**
             * 查询供应商评估报告
             */
            getNinvestedMedicalExamination(corpName) {
                return new Promise((resolve, reject) => {
                    const params = { supplierName: corpName || '' }
                    InterfaceService.getNinvestedMedicalExamination(params, data => {
                        if (data && data.respData && data.respData.respCode === "0000") {
                            this.$setRootScope('ninvestedMedicalExamination', JSON.stringify(data.respData))
                            resolve(data.respData)
                        } else {
                            this.$message.error(data.respData.respMsg)
                            reject(data.respData.respMsg)
                        }
                    }, data => { }, () => {
                        this.isLoading = true
                    }, () => {
                        this.isLoading = false
                    })
                })
            },
            handleBatchDownload() {
                let downloadList = []
                this.packageList.forEach(item=>{
                    if (item.checked) {
                        downloadList.push(item)
                    }
                });
                let fileInfoBeans = []
                this.attachList.forEach(item=>{
                    downloadList.forEach(_item=>{
                        if (_item.type === item.listType) {
                            fileInfoBeans.push({
                                archivePath : item.supplierName + "/" + item.attachName,
                                fileUrl : item.attachUrl,
                            })
                        }
                    })
                });
                let params = {
                    fileInfoBeans :fileInfoBeans,
                    protocol :"https",
                    isAsyn: true
                };
                InterfaceService.packageDownload(
                    params,
                    data => {let res = data.respData|| {};
                        if (data && data.respData && res.respCode === "0000") {
                            // const files = [
                            //     // { name: decodeURIComponent(name), url: url }
                            //     { name: this.selectionName + ".zip", url: res.externalFileUrl }
                            // ];
                            // this.$download(files, () => {this.isLoading = true}, () => {this.isLoading = false}).then(() => {
                            //     this.$message.success("已下载");
                            // });
                            let url = res.externalFileUrl
                            InterfaceService.packageDownloadAsyn(url, data => {
                                const files = [
                                    { name: this.selectionName + ".zip", url: data }
                                ];
                                this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                                    this.$message.success("已下载");
                                });
                                this.dialogVisible = false;
                            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
                        }else {
                            this.$message.error(data.respData.respMsg)
                        }
                    }, data => {
                        this.$message.error(data.respData.respMsg)
                    }, () => {
                        this.isLoading = true
                    }, () => {
                        this.isLoading = false
                    })
            },
            handleDownloadOrSee(item,type) {
                if (this.mainSelection) {
                    this.selectionFileDownload(item,type)
                }else {
                    if (item.showPoint) {
                        let hasUpload = false;
                        item.subListUpLoadInfos.forEach(_item=>{
                            if (this.mxAcctIdList.includes(_item.acctId)) {
                                hasUpload = true;
                            }
                        });
                        if (hasUpload) {
                            this.getSelectionFiles([item.corpId],["SUB_LIST"],type)
                        }else {
                            this.getSelectionFiles([item.corpId],["SUB_RANGE_LIST"],type)
                        }
                    }else {
                        this.getSelectionFiles([item.corpId],["SUB_RANGE_LIST"],type)
                    }
                }
            },
            selectionFileDownload(item,type) {
                const params = {
                    selectionNo : this.selectionNo,
                    supplierId : item ? item.corpId : "",
                };
                InterfaceService.selectionFileDownload(
                    params,
                    data => {
                        let res = data.respData|| {};
                        if (data && data.respData && res.respCode === "0000") {
                            let corpList = res.supplierDetailList || [];
                            if (item) {
                                corpList.forEach(_item=>{
                                    let url = _item.selectionAttachList && _item.selectionAttachList[0] && _item.selectionAttachList[0].attachUrl;
                                    let name = _item.selectionAttachList && _item.selectionAttachList[0] && _item.selectionAttachList[0].attachName;
                                    type === "see" ? this.handleSeeFile(url,name) : this.handleDownload(url,name)
                                });
                            }else {
                                this.createBatcDownloadhData(corpList)
                            }
                        } else {
                            this.$message.error(data.respData.respMsg)
                        }
                    }, data => {
                        this.$message.error(data.respData.respMsg)
                    },
                    () => {
                        this.isLoading = true
                    }, (

                    ) => {
                        this.isLoading = false
                    }
                )
            },
            handleDownload(url,name) {
                if (!url) {
                    this.$message.error("暂无下载内容")
                    return
                }
                const files = [
                    { name: name, url: url }
                ];
                this.$download(files).then(() => {
                    this.$message.success("已下载");
                });
            },
            handleSeeFile(url,name) {
                if (!url) {
                    this.$message.error("暂无预览内容")
                    return
                }
                if (url) {
                    viewFile(url)
                }
            },
            setUpEndSelection(item) {
                let params = {
                    selectionNo : this.selectionNo,
                    supplierId : item.corpId,
                    optFlg : item.lockFlg === "1" ? "unlock" : "lock",
                };
                InterfaceService.lockSelection(
                    params,
                    data => {
                        let res = data.respData|| {};
                        if (data && data.respData && res.respCode === "0000") {
                            this.$message.success(item.lockFlg === "1" ? "解锁成功" : "锁定成功")
                            this.$emit("refresh")
                        } else {
                            this.$message.error(data.respData.respMsg)
                        }
                    }, data => {
                        this.$message.error(data.respData.respMsg)
                    },
                    () => {
                        this.isLoading = true
                    }, (

                    ) => {
                        this.isLoading = false
                })
            },
            getSelectionFiles(corpList,listTypeList,type) {
                let params = {
                    selectionNo:this.selectionNo,
                    supplierList:corpList,
                    listTypeList:listTypeList,
                };
                InterfaceService.getSelectionFiles(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            if (!type) {
                                this.packageList = [];
                                this.attachList = [];
                                let resList =  data.respData.selectionAttachCoordinationList || [];
                                this.attachList = resList.filter(item=>{
                                    return item.recStat === "1"
                                });
                                let list = []
                                this.attachList.forEach(_item=>{
                                    list.push(_item.listType)
                                });
                                let unique = (arr)=> [...new Set(arr)];
                                unique(list).forEach((item)=>{
                                    if (item === "MERGE_LIST") {
                                        this.packageList.push({
                                            type : item,
                                            disp : "所有选型清单(汇总版) | 选型记录汇总清单",
                                        });
                                        this.hasMergeList = true;
                                    }else if (item === "SUB_LIST") {
                                        this.packageList.push({
                                            type : item,
                                            disp : "所有选型清单(协同选型版) | 已选型清单",
                                        })
                                    }else if (item === "SUB_RANGE_LIST") {
                                        this.packageList.push({
                                            type : item,
                                            disp : "所有选型清单(协同选型版) | 协同选型清单模板",
                                        })
                                    }
                                });
                                this.packageList.forEach(item=>{
                                    item.checked = true
                                });
                                this.dialogVisible = true;
                            }else {
                                let url = data.respData.selectionAttachCoordinationList[0].attachUrl || "";
                                let name = data.respData.selectionAttachCoordinationList[0].attachName || "";
                                type === "see" ? this.handleSeeFile(url,name) : this.handleDownload(url,name)
                            }
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {
                    },
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleRefresh(bool) {
                if (bool && this.detail) {
                    this.$emit("refresh");
                    // this.getSelectionFiles();
                }
            },
            init(initShowTips) {
                if (this.detail) {
                    // if (initShowTips) {
                        // this.getSelectionFiles();
                    // }
                    // this.supplierDetailList.forEach((item,ind)=>{
                    //     item.subPersonList = [];
                    //     item.creTmList = [];
                    //     item.subListUpLoadInfos && item.subListUpLoadInfos.forEach(_item=>{
                    //         item.subPersonList.push(_item.custName);
                    //         item.creTmList.push(_item.creTm);
                    //         if (initShowTips) {
                    //             this.lastCreTmList.push({
                    //                 creTm:item.creTmList.sort()[item.creTmList.length-1],
                    //                 ind:ind,
                    //             });
                    //             item.showTips = true;
                    //         }else {
                    //             // this.lastCreTmList.forEach(tm=>{
                    //             //     let onOff = true
                    //             //     if (tm.ind === ind) {
                    //             //         onOff = false;
                    //             //     }
                    //             //     if (onOff) {
                    //             //         this.lastCreTmList.push({
                    //             //             creTm:item.creTmList.sort()[item.creTmList.length-1],
                    //             //             ind:ind,
                    //             //         });
                    //             //     }
                    //             // });
                    //             this.lastCreTmList.forEach(__item=>{
                    //                 if (__item.ind === ind) {
                    //                     if (__item.creTm < item.creTmList.sort()[item.creTmList.length-1]) {
                    //                         item.showTips = true
                    //                         console.log(item.showTips);
                    //                         __item.creTm = item.creTmList.sort()[item.creTmList.length-1]
                    //                     } else {
                    //                         item.showTips = !__item.closed;
                    //                     }
                    //                 }
                    //             })
                    //         }
                    //         item.showPoint = true;
                    //         // this.$set(item,ind,this.supplierDetailList)
                    //         console.log(this.lastCreTmList);
                    //     });
                    // });
                } else {
                    // this.createBatcDownloadhData();
                }
            }
        },
        mounted (){
            this.init("initShowTips");
        }
    }
</script>

<style scoped lang="scss">
    .content {
        padding:20px;
        margin-bottom: 20px;
        background: #f6f5f5;
        .order-info-title {
            margin: 0 -10px;
            margin-bottom: 14px;
            padding: 0 10px;
            font-size: 14px;
            border-left: 3px solid #000;
            line-height: 12px;
            color: #959595;
            .el-button {
                margin-top: -6px;
                height: 30px;
            }
            span:nth-child(1) {
                margin-right: 10px;
                color: #000;
            }
            .detail-btn{
                margin-top: 22px;
            }
        }
        .list-num{
            height: 39px;
            line-height: 39px;
            border-bottom: 1px solid #fff;
        }
        .assessment {
            font-size: 12px;
            padding: 0 20px 10px;
            line-height: 30px;
            span {
                margin-right: 10px;
            }
            .el-checkbox-group {
                display: inline-block;
                width: 85%;
            }
            .el-checkbox {
                margin: 0 30px 0 0;
            }
        }
        .statement {
            margin-bottom: 20px;
        }
        .table {
            table {
                width: 1150px;
                line-height: 26px;
                font-size: 12px;
                background: #fff;
                table-layout:fixed;
                td {
                    padding: 10px 10px;
                    vertical-align: middle;
                    word-break: break-word;
                }
                thead {
                    font-size: 14px;
                    text-align: center;
                    white-space: nowrap;
                    color: #909399;
                    background: #dddddd;
                }
                .tbody-row:hover {
                    background: #e8f3fd;
                }
                .tbody-row .nailsupply{
                    display: inline-block;
                    max-width: 100%;
                    min-height: 14px;
                    padding: 0 6px;
                    line-height: 14px;
                    border: 1px solid #ffa300;
                    border-radius: 7px;
                    color: #ffa300;
                    margin-right: 6px
                }
                tbody {
                    text-align: center;
                    tr {
                        td {
                            position: relative;
                            padding: 10px 10px;
                                border-bottom: 1px solid #f5f5f5;
                            }
                        }
                    }
                    td {
                        border-bottom: 1px solid #ebeef5;
                    }
                }
            .tips{
                background: #fce9eb;
                height: 20px;
                line-height: 20px;
                text-align: center;
                color: #909399;
                i{
                    height: 20px;
                    line-height: 20px;
                    margin-right: 10px;
                    cursor: pointer;
                }
                em{
                    color: #000;
                }
            }
        }
    }
    .el-dropdown-menu--mini .el-dropdown-menu__item{
        min-height: 14px;
        line-height: 14px;
        border: 1px solid #ffa300;
        border-radius: 7px;
        color: #ffa300;
        cursor: default;
        margin-top: 5px;
        &:hover{
            color: #ffa300;
            background: #fff;
        }
        &:first-child {
            margin-top:  0;
        }
    }
    .tooltip-content {
        p {
            color: #fff;
            padding-left: 5px;
            margin-bottom: 5px;
        }
        & p:last-child{
            margin-bottom: 0;
        }
        span{
            width:4em;
            display: inline-block;

        }

    }
    .tip{
        position: absolute;
        width: 20px;
        height:100%;
        top: 0;
        left: 0;
        overflow: hidden;
        .tip-text  {
            position: absolute;
            width: 75px;
            font-size: 12px;
            height: 11px;
            line-height: 14px;
            background-color: #409be2;
            color: #fff;
            text-align: center;
            -webkit-transform: rotate(-40deg);
            transform: rotate(-40deg);
            top: -8px;
            left: -28px;
            p{
                margin: 0;
            }
        }
    }
    .black{
        color: #444;
    }
    .operation{
        span {
            margin-right: 5px;
        }
    }
    .import-list-dialog {
        /deep/ .el-dialog {
            .el-dialog__header {
                text-align: left;
                &:before {
                    height: 3px;
                    background: #ffd64e;
                }
                &::after {
                    content: '';
                    position: absolute;
                    height: 3px;
                    background: #333;
                    left: 10px;
                    bottom: 0;
                    width: 114px;
                }
                .el-dialog__title {
                    font-size: 16px;
                    font-weight: bold;
                    color: #333;
                    padding-left: 11px;
                }
            }
            .el-button {
                width: 120px !important;
                height: 30px;
                line-height: 5px;
            }
            .el-dialog__body {
                padding: 20px;
                .drafts-list {
                    .head {
                        p {
                            margin-top: 2px;
                            text-align: left;
                        }
                    }
                    .body {
                        margin-top: 22px;
                        text-align: left;
                        .file-name {
                            width: 510px;
                            padding-left: 12px;
                            border: 1px solid #ddd;
                            height: 34px;
                            line-height: 34px;
                            display: inline-block;
                            vertical-align: bottom;
                            margin-right: -5px;
                            margin-left: 12px;
                            text-align: left;
                            color: #aaa;
                            &.active {
                                color: #666;
                            }
                        }
                        .el-button + .el-button {
                            width: 120px;
                        }
                        .upfile-container {
                            display: inline-block;
                            width: 110px;
                            background: #ffd64e;
                            color: #333;
                            text-align: center;
                            border: 1px solid #ffd64e;
                            position: absolute;
                            .center label {
                                color: #333 !important;
                                float: inherit;
                                width: 100%;
                                display: block;
                                height: 33px;
                                line-height: 33px;
                            }
                        }

                    }
                }
            }
        }
    }
    .tip-cont{
        p {
            height: 20px;
            line-height: 20px;
        }
    }
</style>