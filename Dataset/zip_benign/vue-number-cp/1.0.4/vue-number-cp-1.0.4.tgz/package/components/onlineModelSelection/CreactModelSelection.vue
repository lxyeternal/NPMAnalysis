<!--suppress ALL -->
<template>
    <div class="content">
        <div class="order-info-title">
            <span class="bold f14">供应商筛选</span>
            <span class="f12">符合条件的供应商共<em class="red f18">{{supplierCnt | formatMoney(0)}}</em>家</span>
        </div>
        <div class="assessment">
            <span class="grey fl">履约评估</span>
            <el-checkbox class="fl" v-model="assessLevelCheckAll" @change="handleCheckAllChange($event,'assessLevel','supplierSelectionInfo')" ><em class="black" :class="{'bold':assessLevelCheckAll}">全选</em></el-checkbox>
            <el-checkbox-group v-model="assessLevelList" @change="handleCheckedChange($event,'assessLevel','supplierSelectionInfo')">
                <el-checkbox v-for="(item, idx) of supplierSelectionInfo.assessLevelList" :key="idx" :label="item.assessLevel" :value="item.assessLevelName"><em class="black" :class="{'bold':assessLevelList.some(_item=>{return _item == item.assessLevel})}">{{item.assessLevelName}}</em></el-checkbox>
            </el-checkbox-group>
        </div>
        <div class="assessment">
            <span class="grey">舆情评估</span>
            <el-checkbox v-model="riskLevelCheckAll" @change="handleCheckAllChange($event,'riskLevel','supplierSelectionInfo')"><em class="black" :class="{'bold':riskLevelCheckAll}">全选</em></el-checkbox>
            <el-checkbox-group v-model="riskLevelList" @change="handleCheckedChange($event,'riskLevel','supplierSelectionInfo')">
                <el-checkbox v-for="(item, idx) of supplierSelectionInfo.riskLevelList" :key="idx" :label="item.riskLevel" :value="item.riskLevelName">
                    <em class="black" :class="{'bold':riskLevelList.some(_item=>{return _item == item.riskLevel})}">
                        {{item.riskLevelName}}
                        <el-tooltip effect="dark" placement="top" v-if="item.riskLevel === 'class_medium' || item.riskLevel === 'class_high'">
                            <div slot="content">
                                <p class="tooltipPriceTarget">{{item.priceTarget}}</p>
                                <p v-if="item.riskLevel === 'class_medium'">根据第三方舆情评估信息，供应舆情情况一般，中度风险，需持续关注。</p>
                                <p v-if="item.riskLevel === 'class_high'">根据第三方舆情评估信息，供应舆情情况良好，风险低，无需特别关注。</p>
                            </div>
                            <i class="el-icon-question tooltip-name"></i>
                        </el-tooltip>
                    </em>
                </el-checkbox>
            </el-checkbox-group>
        </div>
        <div class="grey statement">
            ※免责声明：舆情评估仅作决策参考，所涉全部信息及数据均来源于第三方平台，本公司不控制、编辑或修改信息内容，不保证此类信息的真实性、完整性、及时性及准确性。使用本评估做出任何行为所产生之权利义务由行为人自行承担，与本公司无涉。
        </div>
        <div class="order-info-title">
            <span class="bold f14">货品属性筛选</span>
            <span class="f12">符合条件的货品数量共<em class="red f18">{{prodCnt | formatMoney(0)}}</em>款</span>
        </div>
        <div class="assessment">
            <span class="grey">货品档次</span>
            <el-checkbox v-model="prodLevelCheckAll" @change="handleCheckAllChange($event,'prodLevel','prodSelectionInfo')"><em class="black" :class="{'bold':prodLevelCheckAll}">全选</em></el-checkbox>
            <el-checkbox-group v-model="prodLevelList" @change="handleCheckedChange($event,'prodLevel','prodSelectionInfo')">
                <el-checkbox v-for="(item, idx) of prodSelectionInfo.prodLevelList" :key="idx" :label="item.prodLevel" :value="item.prodLevelName"><em class="black" :class="{'bold':prodLevelList.some(_item=>{return _item == item.prodLevel})}">{{item.prodLevelName}}</em></el-checkbox>
            </el-checkbox-group>
        </div>
        <div class="assessment">
            <span class="grey">货品来源</span>
            <el-checkbox v-model="prodFromCheckAll" @change="handleCheckAllChange($event,'prodFrom','prodSelectionInfo')"><em class="black" :class="{'bold':prodFromCheckAll}">全选</em></el-checkbox>
            <el-checkbox-group v-model="prodFromList" @change="handleCheckedChange($event,'prodFrom','prodSelectionInfo')">
                <el-checkbox v-for="(item, idx) of prodSelectionInfo.prodFromList" :key="idx" :label="item.prodFrom" :value="item.prodFromName"><em class="black" :class="{'bold':prodFromList.some(_item=>{return _item == item.prodFrom})}">{{item.prodFromName}}</em></el-checkbox>
            </el-checkbox-group>
        </div>
        <div class="grey statement" :class="{'dashed-border':attrList.length || showAttrList}">
            ※甲供直采货品数据，根据来源将同步更新。
        </div>
        <AttrListSelection v-if="attrList.length || showAttrList" :clearParam="changeAttr || clearParam" @attrData="attrData" :attrList="attrList" :form="form"></AttrListSelection>
    </div>
</template>

<script>
    import AttrListSelection from "@/components/onlineModelSelection/AttrListSelection";
    export default {
        name: "CreactModelSelection",
        props:["supplierSelectionInfo","prodSelectionInfo","form","attrList","supplierCnt","prodCnt","clearParam","fromsearch","initChangeCate"],
        components: {
            AttrListSelection
        },
        data() {
            return {
                assessLevelList:[],
                riskLevelList:[],
                prodLevelList:[],
                prodFromList:[],
                assessLevelCheckAll : false,
                riskLevelCheckAll : false,
                prodLevelCheckAll : false,
                prodFromCheckAll : false,
                showAttrList : false,
                changeAttr : false,
            }
        },
        watch:{
            // clearParam(newVal){
            //     if (newVal) {
            //         this.initChecked("assessLevel","supplierSelectionInfo");
            //         this.initChecked("riskLevel","supplierSelectionInfo");
            //         this.initChecked("prodLevel","prodSelectionInfo");
            //         this.initChecked("prodFrom","prodSelectionInfo");
            //         this.assessLevelCheckAll = false;
            //         this.riskLevelCheckAll = false;
            //         this.prodLevelCheckAll = false;
            //         this.prodFromCheckAll = false;
            //     }
            // },
            supplierSelectionInfo: {
                handler(newValue, oldValue) {
                    if (newValue && this.clearParam) {
                        this.initChecked("assessLevel","supplierSelectionInfo");
                        this.initChecked("riskLevel","supplierSelectionInfo");
                    }
                },
                deep: true
            },
            prodSelectionInfo: {
                handler(newValue, oldValue) {
                    if (newValue && this.clearParam) {
                        this.initChecked("prodLevel", "prodSelectionInfo");
                        this.initChecked("prodFrom", "prodSelectionInfo");
                    }
                },
                deep: true
            },
            initChangeCate(newVal) {
                if (!newVal) {
                    this.assessLevelList=[]
                    this.riskLevelList=[]
                    this.prodLevelList=[]
                    this.prodFromList=[]
                    this.assessLevelCheckAll = false
                    this.riskLevelCheckAll =false
                    this.prodLevelCheckAll = false
                    this.prodFromCheckAll = false
                    // this.showAttrList = false
                }
            },
        },
        methods : {
            handleCheckAllChange(val,type,info) {
                this[type+'List'] = []
                val ? this[info][type+'List'].forEach(item=>{this[type+'List'].push(item[type])}) : this[type+'List'] = [];
                this[type+'Indeterminate'] = false;
                this.$emit("selectedData",type,this[type+'List'])
                this.changeAttr = true;
            },
            handleCheckedChange(value,type,info) {
                let checkedCount = value.length;
                this[type+'CheckAll'] = checkedCount === this[info][type+'List'].length;
                this[type+'Indeterminate'] = checkedCount > 0 && checkedCount < this[info][type+'List'].length;
                this.$emit("selectedData",type,this[type+'List'])
                this.changeAttr = true;
            },
            attrData(res){
                this.$emit("selectedData","attrList",res)
                this.showAttrList = res.length > 0
                this.changeAttr = false
                // console.log(res);
            },
            initChecked(type,info) {
                this[type + "List"] = [];
                this[info][type + "List"] && this[info][type + "List"].forEach(item=>{
                    if (item.onCheck === "1") {
                        this[type + "List"].push(item[type])
                    }
                })
                this[type + "CheckAll"] = this[info][type + "List"] && this[info][type + "List"].every((item)=>{return item.onCheck === "1"})
                this.$emit("initFormParmas",type,this[type + "List"])
            },
            formChecked(type,info,list) {
                this[type + "List"] = [];
                this[info][type + "List"] && this[info][type + "List"].forEach(item=>{
                    this[type + "List"].push(item[type])
                })
                this[type + "CheckAll"] = this[list][type + "List"] && this[list][type + "List"].every((item)=>{return item.onCheck === "1"})
                this.$emit("initFormParmas",type,this[type + "List"])
            }
        },
        mounted(){
            if (this.fromsearch) {
                this.showAttrList = this.form.attrList.length > 0
                this.formChecked("assessLevel","form","supplierSelectionInfo");
                this.formChecked("riskLevel","form","supplierSelectionInfo");
                this.formChecked("prodLevel","form","prodSelectionInfo");
                this.formChecked("prodFrom","form","prodSelectionInfo");
            }else {
                this.initChecked("assessLevel","supplierSelectionInfo");
                this.initChecked("riskLevel","supplierSelectionInfo");
                this.initChecked("prodLevel","prodSelectionInfo");
                this.initChecked("prodFrom","prodSelectionInfo");
            }

        }
    }
</script>

<style scoped lang="scss">
.content{
    padding: 20px;
    background: #f5f5f5;
    .order-info-title {
        margin: 5px -10px;
        margin-bottom: 20px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
        span:nth-child(1){
            margin-right: 10px;
        }
        span:nth-child(2){
            color: #959595;
        }
    }
    .assessment {
        font-size: 12px;
        padding: 0 20px 10px;
        line-height: 30px;
        span{
            margin-right: 10px;
        }
        .el-checkbox-group{
            display: inline-block;
            width: 85%;
        }
        .el-checkbox {
            margin: 0 30px 0 0;
        }
    }
    .statement{
        padding-bottom: 20px;
        line-height: 20px
    }
    .dashed-border{
        border-bottom: 1px dashed #888;
    }
    .black{
        color: #444;
        .el-icon-question{
            color: #bbb;
        }
        .el-icon-question:hover{
            color: #444;
        }
    }
}
</style>