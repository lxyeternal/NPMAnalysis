<template>
    <div class="attr-content">
        <div class="category-title">
            <div class="category-title-all">所有分类&nbsp;&gt;</div>
            <div class="category-title-name hand" @click="handleRemoveAllAttr">&nbsp;{{form.categoryName}}</div>
            <a class="category-shrink" @click="handleCategoryShrink" v-if="attrList.length">
            <span v-if="!categoryFold">收起
                <i class="el-icon-arrow-up"></i>
            </span>
                <span v-if="categoryFold">展开
                <i class="el-icon-arrow-down"></i>
            </span>
            </a>
        </div>
        <div class="category-content" :class="{'fold':categoryFold}">
            <!-- 属性 -->
            <div v-for="(attr,index) in attrList" :key="index" class="category-bd clearfloat">
                <div class="categroy-name">{{attr.attrInfoName}}<span v-if="attr.unit">({{attr.unit}})</span></div>
                <div class="categroy-list clearfloat append">
                    <ul :id="'attr-'+ index">
                        <li>
                            <el-checkbox class="fl" style="margin-right: 30px;"
                                         v-model="attr.checkAll"
                                         @change="handleCheckAllChange(attr)"
                            >
                                <em class="black" :class="{'bold':attr.checkAll}">全选</em>
                            </el-checkbox>
                            <el-checkbox-group v-model="attrValueList" @change="handleCheckedChange(attr,index)">
                            <el-checkbox style="font-size:12px;"
                                         v-for="(attrValue,_index) in attr.attrValueList"
                                         :key="index+'_'+_index"
                                         :label="attrValue.attrValueId"
                                         :value="attrValue.attrValueName"
                            >
                                <em class="black" :class="{'bold':attrValueList.some(_item=>{return _item == attrValue.attrValueId})}">
                                    {{attrValue.attrValueName}}
                                </em>
                            </el-checkbox>
                            </el-checkbox-group>
                        </li>
                    </ul>
                </div>
                <div class="category-icons f12">
                </div>
            </div>
        </div>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    import { InterfaceService } from "@/services/api";
    import Loading from "@/components/base/Loading";

    // 参数
    const params = {
        categoryIds: "",
        corpId:"",
        attrs: [],
        brandIds: "",
        priceFrom: "",
        priceTo: "",
        sort: [],
        pageIndex: 1,
        pageSize: 12,
        keyword:'',
        tags:''
    };
    export default {
        props:["form","attrList","clearParam","changeAttr"],
        components: {
            Loading,
        },
        watch:{
            attrList:{
                handler(newValue) {
                    if (newValue) {
                        if (this.attrList.length) {
                            this.attrList.forEach(item=>{
                                item.checkAll = item.attrValueIds && item.attrValueIds.every(_attr=>{
                                    return this.attrValueList.some(item=>{
                                        return _attr === item
                                    })
                                });
                            });
                        }
                    }
                },
                deep: true,
            },
            clearParam(newVal){
                // console.log(newVal,"newVal");
                if (newVal) {
                    this.attrSelectList = [];
                    console.log(this.attrList);
                    this.attrList.forEach((attr)=>{
                        attr.checkAll = false;
                    });
                    this.attrValueList = [];
                }
            },
        },
        data() {
            return {
                brandSelectList:[],
                attrSelectList:[],
                brandList:[],
                storeAttr:[],
                categoryList:[],
                attrValueList:[],
                brandAttr:{},
                categoryFold : false,
                simpleFilter : true,
                isLoading : false,
                params: Object.assign({}, params),
            }
        },
        methods : {
            handleCheckedChange(attr,index) {
                this.attrSelectList = []
                this.attrList.forEach(attr=>{
                    this.attrValueList.forEach(item=>{
                        attr.attrValueIds && attr.attrValueIds.forEach(_attr=>{
                            if (_attr === item) {
                                this.attrSelectList.push(attr);
                            }
                        });
                    });
                });
                attr.checkAll = attr.attrValueIds && attr.attrValueIds.every(_attr=>{
                    return this.attrValueList.some(item=>{
                        return _attr === item
                    })
                });
                this.$set(this.attrList,index,attr);
                console.log(this.attrSelectList,"this.attrSelectList");
                this.getProductList(true);
            },
            compDisabled(list){
                console.log(list);
                return list.every(item=>{
                    return item.display === "0"
                })
            },
            handleCheckAllChange(attr) {
                if (attr.checkAll) {
                    attr.attrValueIds.forEach(id=>{
                        let hasId = false
                        this.attrValueList.forEach(item=>{
                            if (item === id) {
                                hasId = true
                            }
                        })
                        if (!hasId) {
                            this.attrValueList.push(id)
                        }
                    })
                }else {
                    attr.attrValueIds.forEach(id=>{
                        this.attrValueList.forEach((item,ind)=>{
                            if (item === id) {
                                this.attrValueList.splice(ind,1)
                            }
                        })
                    })
                }
                this.attrSelectList = []
                this.attrList.forEach(attr=>{
                    this.attrValueList.forEach(item=>{
                        attr.attrValueIds && attr.attrValueIds.forEach(_attr=>{
                            if (_attr === item) {
                                this.attrSelectList.push(attr);
                            }
                        });
                    });
                });
                this.getProductList(true);
            },
            // 品牌分类移除
            handleRemoveBrand() {
                this.brandSelectList = [];
                this.getProductList(true);
            },
            // 属性分类移除
            handleRemoveAttr(index) {
                this.attrSelectList.splice(index, 1);
                this.getProductList(true);
            },
            // 属性分类多选选择
            handleSelectAttrMulti(index, attr) {
                attr.isExpand = false;
                attr.isMulti = false;
                this.attrSelectList.push(attr);
                this.getProductList(true);
            },
            // 属性单选选择
            handleSelectAttr(index, attr, attrValue) {
                attrValue.checked = true;
                this.attrSelectList.push(attr);
                this.getProductList(true);
            },
            // 属性分类更多
            handleAttrMore(index, attr) {
                attr.isExpand = !attr.isExpand;
                attr.isMulti = false;
                this.$set(this.attrList, index, attr);
            },
            // 属性分类多选取消
            handleCancelAttrMulti(index, attr) {
                attr.isExpand = false;
                attr.isMulti = false;
                this.$set(this.attrList, index, attr);
            },
            // 收起、展开分类
            handleCategoryShrink(bool) {
                this.categoryFold = !this.categoryFold;
            },
            // 分类移除所有
            handleRemoveAllAttr() {
                this.brandSelectList = [];
                this.attrSelectList = [];
                this.$route.query.brandIds = "";
                this.getProductList(true);
            },


            // 品牌分类多选取消
            handleCancelBrandMulti() {
                this.$set(this.brandAttr, "isExpand", false);
                this.$set(this.brandAttr, "isMulti", false);
            },
            // 品牌分类更多
            handleBrandMore() {
                this.$set(this.brandAttr, "isExpand", !this.brandAttr.isExpand);
                this.$set(this.brandAttr, "isMulti", false);
            },
            // 品牌分类多选
            handleBrandMulti() {
                this.$set(this.brandAttr, "isExpand", true);
                this.$set(this.brandAttr, "isMulti", true);
            },
            // 品牌单选选择
            handleSelectBrand(index, brand) {
                brand.checked = true;
                this.$set(this.brandList, index, brand);
                this.brandList.forEach(item => {
                    if (item.checked) {
                        this.brandSelectList.push(item);
                    }
                });
                this.getProductList(true);
            },
            // 品牌分类多选选择
            handleSelectBrandMulti() {
                this.$set(this.brandAttr, "isExpand", false);
                this.$set(this.brandAttr, "isMulti", false);
                this.brandList.forEach(item => {
                    if (item.checked) {
                        this.brandSelectList.push(item);
                    }
                });
                this.getProductList(true);
            },
            // 高级筛选、简单筛选
            handleAttrFilter(){
                this.simpleFilter = !this.simpleFilter;
                setTimeout(()=>{
                    this.attrList.map((item,index)=>{
                        // item.isShowMore = false;
                        this.showMore(index);
                    });
                },0);
            },
            showMore(index){
                const ele = document.getElementById('attr-'+index);
                if (ele) {
                    let lineHeight = ele.offsetHeight;
                    if (lineHeight <= 36) {
                        this.attrList[index].isShowMore = false;
                    } else {
                        this.attrList[index].isShowMore = true;
                    }
                    this.$set(this.attrList,index,this.attrList[index]);
                }
            },
            // 属性分类多选
            handleAttrMulti(index, attr) {
                attr.isExpand = true;
                attr.isMulti = true;
                this.$set(this.attrList, index, attr);
            },
            getProductList(init) {
                // 属性
                let selectList = this.attrSelectList;
                selectList.forEach(item => {
                    item.attrList = []
                    item.attrValueList.forEach(_item=>{
                        this.attrValueList.forEach(__item=>{
                            if (_item.attrValueId === __item) {
                                item.attrList.push(_item.attrValueId)
                            }
                        })
                    });
                });
                let attrList = [];
                selectList.forEach(item=>{
                    attrList.push({
                        attrType:item.attrType,
                        attrId:item.attrInfoId,
                        attrValueList:item.attrList,
                    })
                });
                 let obj = {};
                attrList = attrList.reduce(function(item, next) {
                    obj[next.attrId] ? '' : obj[next.attrId] = true && item.push(next);
                    return item;
                }, []);
                this.$emit("attrData",attrList)
            },
        },
        mounted() {
            if (this.attrList.length) {
                this.attrSelectList = [];
                this.attrValueList = [];
                this.form.attrList.forEach(_item=>{
                    _item.attrValueList.forEach(__item=>{
                        this.attrValueList.push(__item)
                    });
                });
                this.attrList.forEach(attr=>{
                    this.attrValueList.forEach(item=>{
                        attr.attrValueIds && attr.attrValueIds.forEach(_attr=>{
                            if (_attr === item) {
                                this.attrSelectList.push(attr);
                            }
                        });
                    });
                });
                this.attrList.forEach(item=>{
                    item.checkAll = item.attrValueIds && item.attrValueIds.every(_attr=>{
                        return this.attrValueList.some(item=>{
                            return _attr === item
                        })
                    });
                });
                console.log(this.attrSelectList,"this.attrSelectList");
            }
        }
    }
</script>

<style scoped lang="scss">
    .attr-content{
        background: #f5f5f5;
        font-size: 12px;
        color: #888;
        .category-title-all {
            float: left;
        }
        .category-title-name{
            float: left;
            display: inline-block;
            vertical-align: middle;
            white-space: nowrap;
            color: #888;
            &:hover{
                color: #ffd64e;
            }
        }
    }
    .category-title {
        position: relative;
        min-height: 56px;
        padding: 20px 80px 14px 15px;
        // border-bottom: 1px solid #ddd;
        // padding-right: 80px;
        // line-height: 56px;
        line-height: 25px;
        font-weight: bold;
        font-size: 12px;
        &:after {
            display: table;
            content: "";
            clear: both;
        }

        .category-title-name{
            float: left;
            position: relative;
            display: inline-block;
            vertical-align: middle;
            white-space: nowrap;
            a:hover{
                color: #ffd64e;
            }
        }
        .category-title-tag {
            float: left;
            position: relative;
            display: inline-block;
            max-width: 250px;
            margin: 0 10px 5px;
            padding: 0 30px 0 15px;
            vertical-align: middle;
            line-height: 22px;
            white-space: nowrap;
            border: 1px solid #bbb;
            overflow: hidden;
            text-overflow: ellipsis;
            color: #888;
            font-size: 12px;
            font-weight: 500;

            i {
                position: absolute;
                right: 10px;
                top: 5px;
                cursor: pointer;
            }

            &:hover {
                border-color: #ffd64e;
                color: #444;
                i {
                    // color: #ffd64e;
                    color: #444444;
                }
            }
            & > span:after {
                margin-right: 2px;
                content: ",";
            }
            & > span:nth-last-child(2):after {
                content: "";
            }
        }

        .category-title-tag-removeall {
            display: inline-block;
            white-space: nowrap;
            padding: 0px 10px;
            border-left: 2px solid #ddd;
            color: #888888;
            font-weight: 500;

            &:hover {
                color: #0082ff;
            }
        }
    }
    .category-content {
        position: relative;
    }

    .category-content.fold {
        height: 0;
        overflow: hidden;
    }
    .category-bd {
        position: relative;
        overflow: hidden;
    }
    .categroy-list {
        /* width: 100%; */
        margin-left: 125px;
        /* height: auto; */
        height: 37px;
        overflow: hidden;
        color: #000;
        /deep/ .el-checkbox__label{
            font-size: 12px;
        }

        &.append {
            height: auto;
            /*overflow: auto;*/
        }
        ul {
            width: 100%;

            &:after {
                display: table;
                content: "";
                clear: both;
            }
        }
        li {
            width: 100%;
            float: left;
            padding: 0 20px;
            margin-right: 20px;
            /*height: 36px;*/
            line-height: 36px;
            &:hover,
            &.active {
                color: #ffd64e;
            }
        }
    }
    .categroy-list-btns {
        margin-left: -125px;
        padding: 20px 0 10px;
        text-align: center;
    }
    .category-icons {
        position: absolute;
        height: 22px;
        top: 7px;
        right: 0;
        overflow: hidden;
        color: #444;
        text-align: center;
    }
    .category-filter:hover{
        cursor: pointer;
        color:  #ffd64e;
    }
    .categroy-name {
        width: 125px;
        float: left;
        font-size: 14px;
        background-color: #f5f5f5;
        text-align: left;
        line-height: 36px;
        height: 100%;
        overflow: hidden;
        padding-bottom: 9999px;
        margin-bottom: -9999px;
    }
    .category-title-tag-removeall {
        display: inline-block;
        white-space: nowrap;
        padding: 0px 10px;
        border-left: 2px solid #ddd;
        color: #888888;
        font-weight: 500;

        &:hover {
            color: #0082ff;
        }
    }
    .category-shrink {
        position: absolute;
        top: 0;
        right: 0;
        width: 55px;
        padding: 16px 0;
        padding-top: 30px;
        font-weight: 500;
        line-height: 22px;
    }
    .category-more,
    .category-selects {
        float: left;
        width: 55px;
        height: 22px;
        line-height: 22px;
        border: 1px solid #888888;
        cursor: pointer;
        margin-left: 20px;
        &:hover {
            border-color: #ffd64e;
        }
    }
    .black{
        color: #444;
    }
</style>