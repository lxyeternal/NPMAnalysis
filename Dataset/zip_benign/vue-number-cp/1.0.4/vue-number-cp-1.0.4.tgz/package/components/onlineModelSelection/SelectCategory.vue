<template>
    <el-form class="form" :model="form" size="small" label-width="0">
        <el-row>
            <div class="label">
                <em v-if="required" class="red">*</em>{{label}}
            </div>
            <!--<el-col>-->
                <el-col :span="7">
                    <el-form-item>
                        <el-select filterable default-first-option no-data-text="请选择一级品类"
                                   no-match-text="请修改匹配关键词"
                                   v-model="form.firstCate"
                                   :disabled="disabled"
                                   @change="handleChangeCate($event,'categorySecondList')"
                                   ref="select1"
                                   placeholder="请选择一级品类">
                            <el-option v-for="(item,index) in categoryList" :label="item.title" :value="item.key" :key="index"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="7" :class="{[marginLeft]:marginLeft}">
                    <el-form-item label="" label-width="0" >
                        <el-select filterable default-first-option no-data-text="请选择类别"
                                   no-match-text="请修改匹配关键词"
                                   v-model="form.secondCate"
                                   :disabled="disabled"
                                   ref="select2"
                                   @change="handleChangeCate($event,'categoryThirdList')" placeholder="请选择二级品类">
                            <el-option v-for="(item,index) in categorySecondList" :label="item.title" :value="item.key" :key="index"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="7" :class="{[marginLeft]:marginLeft}">
                    <el-form-item label="" label-width="0">
                        <el-select filterable default-first-option no-data-text="请选择类别"
                                   no-match-text="请修改匹配关键词"
                                   v-model="form.categoryId"
                                   :disabled="disabled"
                                   ref="select3"
                                   @change="handleChangeCate($event)"
                                   placeholder="请选择三级品类">
                            <el-option v-for="(item,index) in categoryThirdList" :label="item.title" :value="item.key" :key="index"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
            <!--</el-col>-->

            <!--<el-col :span="15">-->
                <!--<el-col :span="12">-->
                    <!--<el-form-item label="" label-width="17px">-->
                        <!--<el-select filterable default-first-option no-data-text="请选择类别"-->
                                   <!--no-match-text="请修改匹配关键词"-->
                                   <!--v-model="form.secondCate"-->
                                   <!--:disabled="disabled"-->
                                   <!--ref="select2"-->
                                   <!--@change="handleChangeCate($event,'categoryThirdList')" placeholder="请选择二级品类">-->
                            <!--<el-option v-for="(item,index) in categorySecondList" :label="item.title" :value="item.key" :key="index"></el-option>-->
                        <!--</el-select>-->
                    <!--</el-form-item>-->
                <!--</el-col>-->
                <!--<el-col :span="12">-->
                    <!--<el-form-item label="" label-width="17px">-->
                        <!--<el-select filterable default-first-option no-data-text="请选择类别"-->
                                   <!--no-match-text="请修改匹配关键词"-->
                                   <!--v-model="form.categoryId"-->
                                   <!--:disabled="disabled"-->
                                   <!--ref="select3"-->
                                   <!--@change="handleChangeCate($event)"-->
                                   <!--placeholder="请选择三级品类">-->
                            <!--<el-option v-for="(item,index) in categoryThirdList" :label="item.title" :value="item.key" :key="index"></el-option>-->
                        <!--</el-select>-->
                    <!--</el-form-item>-->
                <!--</el-col>-->
            <!--</el-col>-->
        </el-row>
    </el-form>
</template>

<script>
    import { InterfaceService } from "@/services/api";
    export default {
        name: "SelectCategory",
        props:{
            form: {
                type: Object,
                default: ()=>{}
            },
            clear: {
                type: Boolean,
                default: false
            },
            label: {
                type: String,
                default: "品类"
            },
            required: {
                type: Boolean,
                default: false
            },
            changeWaring: {
                type: Boolean,
                default: false
            },
            fromDialog: {
                type: Boolean,
                default: false
            },
            disabled: {
                type: Boolean,
                default: false
            },
            initParams: {
                type: Boolean,
                default: false
            },
            marginLeft: {
                type: String,
                default: ""
            },
        },
        data() {
            return {
                isLoading: false,
                initChangeCate: true,
                categorySecondList: [],
                categoryList: [],
                categoryThirdList: [],
                storageCateId: "",
            };
        },
        watch: {
            clear(newVal){
                if (newVal) {
                    this.categorySecondList= [];
                    this.categoryThirdList= []
                }
            },
            // initParams(newVal) {
            //     if (newVal){
            //         this.initCategoryList()
            //     }
            // },
            // form: {
            //     handler(newValue) {
            //         console.log(newValue);
            //         this.getCategoryList(newValue);
            //     },
            //     deep: true
            // }
        },
        methods: {
            handleChangeCate(ev,list) {
                if (this.changeWaring && this.initChangeCate) {
                    this.$confirm(
                        "更改品类后会清除之前已筛选的条件和生成的清单明细,是否更改品类？",
                        {
                            cancelButtonClass: "btn-custom-cancel",
                            confirmButtonClass: "btn-custom-confirm",
                            center: true,
                            type: 'warning',
                            confirmButtonText: "确认",
                            cancelButtonText: '取消',
                        }).then(() => {
                            this.confirmChange(ev,list);
                            this.$nextTick(() =>{
                                this.$refs["select1"].blur();
                                this.$refs["select2"].blur();
                                this.$refs["select3"].blur();
                            });
                            if (list){
                                this.initChangeCate = false;
                                this.$emit("initChangeCate",this.initChangeCate)
                            }
                    }).catch(() => {
                        if (!list) {
                            this.categoryThirdList.forEach(item=>{
                                if (item.title === this.form.categoryName) {
                                    this.form.categoryId = item.key
                                }
                            });
                        }
                    });
                }else {
                    this.confirmChange(ev,list);
                }
            },
            getCategoryList(form){
                this.categorySecondList = [];
                this.categoryThirdList = [];
                this.categoryList.forEach(item1=>{
                    if (form.firstCate == item1.key) {
                        item1.children.forEach(_item=>{
                            if (_item.selectionFlg === "1") {
                                this.categorySecondList.push(_item)
                            }
                        });
                    }
                });
                if (this.categorySecondList.length ) {
                    this.categorySecondList.forEach(item2=>{
                        if (form.secondCate == item2.key) {
                            item2.children.forEach(_item=>{
                                if (_item.selectionFlg === "1") {
                                    this.categoryThirdList.push(_item)
                                }
                            });
                        }
                    });
                }
                if (this.categoryThirdList.length ) {
                    this.categoryThirdList.forEach(item=>{
                        if (item.key === this.form.categoryId) {
                            this.form.categoryName = item.title;
                        }
                    });
                }
            },
            confirmChange(ev,list){
                if (list) {
                    let match = false;
                    this[list] = [];
                    this.categoryList.forEach(item=>{
                        if (item.key == ev) {
                            item.children.forEach((_item)=>{
                                if (_item.selectionFlg === "1") {
                                    this[list].push(_item);
                                    match = true
                                }
                            })
                        }
                    });
                    if (!this[list].length) {
                        this.categorySecondList.forEach(item=>{
                            if (item.key == ev) {
                                item.children.forEach((_item)=>{
                                    if (_item.selectionFlg === "1") {
                                        this[list].push(_item);
                                        match = true
                                    }
                                })
                            }
                        });
                    }
                    if (!match) {
                        if (list === "categorySecondList") {
                            this[list] = [];
                            this.categoryThirdList = [];
                        }else if (list === "categoryThirdList") {
                            this[list] = [];
                        }
                    }
                    if (list === "categorySecondList") {
                        this.form.secondCate = '';
                        this.form.categoryId = '';
                        this.categoryThirdList = [];
                    }else if (list === "categoryThirdList") {
                        this.form.categoryId = '';
                    }
                }
                this.categoryThirdList.forEach(item=>{
                    if (item.key === this.form.categoryId) {
                        this.form.categoryName = item.title;
                        this.initChangeCate = true;
                        this.$emit("formData",this.form);
                        this.$emit("initChangeCate",this.initChangeCate)
                    }
                });
            },
            initCategoryList() {
                let list = []
                // let categoryList = this.$getRootScope('categoryList')
                // if (categoryList) {
                //     list = JSON.parse(categoryList)
                // } else {
                if (!this.categoryList.length) {
                    InterfaceService.getCategoryList(res => {
                        this.$store.commit('changeCategoryList', res['children'])
                        this.$setRootScope('categoryList', JSON.stringify(res['children']))
                        list = res['children'];
                        this.categoryList = [];
                        list.forEach(item=>{
                            if (item.selectionFlg === "1") {
                                this.categoryList.push(item)
                            }
                        });
                        this.getCategoryList(this.form);
                    });
                }
            },
        },
        mounted(){
            this.initCategoryList();
        }
    }
</script>

<style lang="scss" scoped>
    .form {
        height: 50px;
        .el-select {
        }
    /deep/ .el-col {
        height: 52px;
    }

    /deep/ .el-select {
        width: 100%;
    }

    /deep/ .el-date-editor {
    input.el-input__inner {
        padding: 0 15px;
    }
    .el-input__prefix {
        display: none;
    }
    }

    &:after {
         display: table;
         content: "";
         clear: both;
     }
    }
    .alert-box .el-button--primary{
        width: 100px;
        background-color: #ffd64e;
        border-color: #ffd64e;
    }
    .el-message-box{
        width: 500px;
    }
    .el-message-box__btns{
        position: relative;
    }
    .el-message-box__btns .btn-custom-cancel {
        position: absolute;
        right: 135px;
        width: 100px;
    }
    .el-message-box__btns .btn-custom-confirm{
        margin-right: 120px;
        width: 100px;
        background-color: #ffd64e;
        border-color: #ffd64e;
    }
    .label{
        float: left;
        width: 80px;
        padding-right: 12px;
        height: 32px;
        line-height: 32px;
        text-align: right;
        display: inline-block;
        em{
            margin-right: 4px;
        }
    }
    .margin18{
        margin-left: 18px;
    }
    .margin9{
        margin-left: 9px;
    }
    .margin31{
        margin-left: 31px;
    }
</style>