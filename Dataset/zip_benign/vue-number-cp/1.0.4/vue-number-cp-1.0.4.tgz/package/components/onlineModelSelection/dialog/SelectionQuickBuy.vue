<template>
    <div>
        <el-dialog v-show="showDialog" class="dialog" :title="fromQuickBox ? '选择收货地址':'快速采购'" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="840px" center :close-on-click-modal="false" @close="handleRefresh">
            <div class="info-title" v-if="!fromQuickBox">
                <span class="order-info-title bold fl">选择供应商</span>
            </div>
            <div class="drafts-list" v-if="!fromQuickBox">
                <span>选择供应商</span>
                <el-select v-model="quickPurchaseDialogValue"
                           filterable
                           default-first-option
                           placeholder="请输入关键词快速搜索选择供应商"
                           no-match-text="未匹配到供应商，请修改匹配关键词"
                           @change="handleChangeCorp"
                >
                    <el-option v-for="item in filterList(selectionSupplierList)" :key="item.corpId" :label="item.corpName" :value="item.corpId || ''">
                    </el-option>
                </el-select>
            </div>
            <p class="selected-Info" v-if="!fromQuickBox">
                选择清单: {{selectedAttach.attachName}} <em v-if="selectedAttach.attachUrl" class="blue hand" @click="handleSeeFile(selectedAttach.attachUrl)">在线预览</em>
            </p>
            <Select-address @getAddresses="getAddresses" :dialog="true"></Select-address>
            <div class="dialog-footer">
                <div>
                    <el-button :disabled="!selectedAttach.attachUrl" type="primary" size="small" style="width: 100px" @click.native="handleConfirmUpFileImportList()">下一步</el-button>
                    <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
                </div>
            </div>
        </el-dialog>
        <el-dialog class="dialog" :title="'报错信息'" :append-to-body="true" :lock-scroll="true" :visible.sync="errorDialogVisible" width="850px" center :close-on-click-modal="false" @close="handleCloseErrorDia">
            <div class="error-text">选型清单中有部分货品已下架或不在供应商的配送范围内，请【下载报错清单】查看具体的报错信息，并联系供应商上架货品或修改运费设置。<em class="hand blue" @click="handleSeeFile(errorInfo.attachUrl)">在线查看</em></div>
            <el-row class="error-sup">
                <el-col :span="6" class="bold">供应商联系方式</el-col>
                <el-col :span="6" >联系人：{{selectedInfo.contactName}}</el-col>
                <el-col :span="6" >联系方式：{{selectedInfo.contactMobile}}</el-col>
                <el-col :span="6" >邮箱：{{selectedInfo.contactEmail}}</el-col>
            </el-row>
            <div class="dialog-footer">
                <div>
                    <el-button size="small"  style="width: 110px"  type="primary" @click.native="handleDownload">下载报错清单</el-button>
                    <el-button size="small" style="width: 110px"  @click="errorDialogVisible = false;">关闭</el-button>
                </div>
            </div>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    import Loading from "@/components/base/Loading";
    import { InterfaceService } from "@/services/api";
    import accountMixin from "@/mixins/account";
    import { viewFile } from '@/utils/orderUtil';
    import SelectAddress from '@/components/base/SelectAddress'

    export default {
        mixins: [accountMixin],
        components: {
            Loading,
            SelectAddress,
        },
        props:['mainSelection'],
        data() {
            return {
                isLoading: false,
                dialogVisible: false,
                errorDialogVisible: false,
                showDialog: false,
                quickPurchaseDialogValue: "",
                selectedInfo: {},
                selectionInfo: {},
                getAddFromAssembly: {},
                selectedAttach: {},
                errorInfo: {},
                fromQuickBox: {},
                selectionSupplierList: [],
            };
        },
        computed: {
        },
        methods: {
            open(selectionInfo,fromQuickBox) {
                this.fromQuickBox = fromQuickBox || "";
                if (!fromQuickBox) {
                    this.selectionInfo = selectionInfo;
                    this.selectionSupplierList = this.selectionInfo.selectionSupplierList;
                    let num = 0;
                    this.selectionSupplierList.forEach(item=>{
                        if (item.mergeUploadFlg) {
                            num++;
                            this.quickPurchaseDialogValue = item.corpId;
                            this.selectedInfo = item;
                            this.selectedAttach = item.selectionAttachList[0] || {};
                        }
                    });
                    if (num !== 1) {
                        this.quickPurchaseDialogValue = "";
                        this.selectedAttach = {};
                        this.selectedInfo = {}
                    }
                }else {
                    this.selectedAttach.attachUrl = selectionInfo.attachUrl;
                    this.selectedAttach.shortAttachUrl = selectionInfo.shortAttachUrl;
                    this.selectedInfo = selectionInfo;
                    this.quickPurchaseDialogValue = selectionInfo.corpId;
                    this.queryCorpName = selectionInfo.corpName;
                }
                this.dialogVisible = true;
                this.showDialog = true
            },
            filterList(list) {
                return list.filter(item=>{
                    return item.mergeUploadFlg
                })
            },
            handleRefresh(){
                if (this.fromQuickBox) {
                    this.$emit("goBack",true)
                }
            },
            handleCloseErrorDia () {
                this.dialogVisible = true;
                this.showDialog = true
            },
            handleChangeCorp(val) {
                this.selectionSupplierList.forEach(item=>{
                    if (item.corpId === val) {
                        this.selectedAttach = item.selectionAttachList[0] || {};
                        this.selectedInfo = item|| {};
                    }
                })
            },
            handleSeeFile(url) {
                if (url) {
                  viewFile(url)
                }
            },
            getAddresses(res) {
                this.getAddFromAssembly = res;
            },
            handleDownload() {
                this.$download([{url:this.errorInfo.attachUrl || '', name:this.errorInfo.fileName || '导入失败的供方货品信息.xlsx'}])
            },
            handleConfirmUpFileImportList() {
                const params = {
                    supplierId: this.quickPurchaseDialogValue || '',
                    attachUrl: this.selectedAttach.shortAttachUrl || '',
                    destinationCode: this.getAddFromAssembly && this.getAddFromAssembly.districtCode || '',
                    provCode: this.getAddFromAssembly && this.getAddFromAssembly.provCode || '',
                    cityCode: this.getAddFromAssembly && this.getAddFromAssembly.cityCode || ''
                };
                InterfaceService.upFileImportGoodsList(params, data => {
                    if (data.respData.respCode == '0000') {
                        if (data.respData.skuList && data.respData.skuList.length) {
                            const skuList = data.respData.skuList;
                            let selectionNo = data.respData.selectionNo || "";
                            skuList.map(m=>{
                                m.corpId = this.quickPurchaseDialogValue
                                m.corpName = this.queryCorpName
                            });

                            const item = [{
                                "corpId": this.quickPurchaseDialogValue,
                                "corpName": this.queryCorpName,
                                "getAddFromAssembly": this.getAddFromAssembly,
                                "state": 'newList',
                                "vendorTagsList": this.vendorTagsList,
                                "draftsId": this.$route.query && this.$route.query.draftsId || '',
                                "toggle": false,
                                "floatToggle": false,
                                "selectionNo": selectionNo,
                                skuList
                            }]
                            let taxRateWaring = skuList.some(_item=>{
                                return +_item.taxRate !== 0.13
                            });
                            if (taxRateWaring) {
                                this.$confirm(
                                    "当前的清单中包含税率为13%以外的商品，您是否确认提交？",
                                    {
                                        cancelButtonClass: "btn-custom-cancel",
                                        confirmButtonClass: "btn-custom-confirm",
                                        center: true,
                                        type: 'warning',
                                        confirmButtonText: "确认",
                                        cancelButtonText: '取消',
                                    }).then(() => {
                                    this.$setRootScope('queryProductList', JSON.stringify(item))
                                    this.$router.push({
                                        path: '/quickPurchaseComfirm',
                                        query: {
                                            fast: true,
                                            selection: true,
                                            selectionInfo:JSON.stringify(this.selectedInfo),
                                        }
                                    });
                                    this.dialogVisible = false
                                }).catch(() => {
                                });
                            }else {
                                this.$setRootScope('queryProductList', JSON.stringify(item))
                                this.$router.push({
                                    path: '/quickPurchaseComfirm',
                                    query: {
                                        fast: true,
                                        selection: true,
                                        selectionInfo:JSON.stringify(this.selectedInfo),
                                    }
                                });
                                this.dialogVisible = false
                            }
                        }
                        if (data.respData.attachUrl) {
                            this.errorInfo.attachUrl = data.respData.attachUrl;
                            this.errorInfo.fileName = data.respData.fileName || '导入失败的供方货品信息.xlsx';
                            this.errorDialogVisible = true;
                            this.showDialog = false;
                        }
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                }, data => {
                }, () => {
                    this.isLoading = true;
                }, () => {
                    this.isLoading = false;
                })
            },
        }
    };
</script>

<style lang="scss" scoped>
    .info-title {
        margin-bottom: 9px;
        &:after {
            display: table;
            content: "";
            clear: both;
        }
        em {
            display: inline-block;
            margin: 6px 0 5px 10px;
        }
    }
    .order-info-title {
        margin: 6px 0;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
    }
    .drafts-list {
        display: flex;
        align-items: center;
        margin-top: 8px;
        & > span {
            width: 80px;
            display: block;
        }
        /deep/ .el-select {
            $topbar-height: 80px;
            width: calc(100% - #{$topbar-height});
            .el-select__input {
                border: 0;
            }
        }
    }
    .selected-Info{
        text-align: left;
        width: 100%;
        margin: 10px 0 20px;
        padding: 0 10px;
        height: 34px;
        line-height: 34px;
        background-color: #ffeaeb;
        em{
            margin-left: 10px;
        }
    }
    /deep/ .dialog-footer{
        text-align: center;
        margin-bottom: 20px;
        margin-top:20px;
    }
    .clear{
        clear: both;
    }
    .error-text{
        height: 25px;
        line-height: 25px;
        margin-bottom: 5px;
    }
    .error-sup{
        padding: 0 5px;
        background-color: #f5f5f5;
        height: 30px;
        line-height: 30px;
    }
    .el-dialog__body{
        padding-top: 20px;
    }
</style>
