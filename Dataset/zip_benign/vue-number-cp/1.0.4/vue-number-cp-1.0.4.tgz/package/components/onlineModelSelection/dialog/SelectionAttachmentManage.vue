<template>
    <div v-if="dialogVisible">

        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="870px" center :close-on-click-modal="false" @close="handleRefresh">
            <div class="tl">
                <PanelTitle v-if="tabs.length" :tabs="tabs" @select="handleSelectTab" bg-color="#fff"></PanelTitle>
                <div class="attach-wrapper">
                    <!-- 下载 -->
                    <div class="download-wrapper" v-if="attatchType == '00'">
                        <div class="attach-panel-title" v-if="role == 'B'">
                            <span class="hand attach-panel" :class="{'active':dTab.active}"
                                  v-for="(dTab,index) in downLoadTabs" :key="'d_t_'+index"
                                  @click="hanleTitleType('downLoadType','downLoadTabs',dTab.type,index)">{{dTab.label}}</span>
                        </div>
                        <div class="down-load-content clearfloat">
                            <el-row :gutter="20">
                                <el-col :span="24">
                                    <div class="buyer-attach-box">
                                        <div class="s-body">
                                            <!--<ul v-if="mainSelection && (downLoadType === '00')">-->
                                                <!--<li v-for="(contract,index) in upLoadFileList" :key="'b_'+index">-->
                                                    <!--<el-checkbox v-model="contract.checked"  @change="handleSelectRow(upLoadFileList,contract,index)"></el-checkbox>-->
                                                    <!--<span class="blue hand f12" @click="handleSeeFile(contract)">{{contract.attachName}}</span>-->
                                                <!--</li>-->
                                                <!--<li v-if="!(upLoadFileList && upLoadFileList.length)">暂无资料</li>-->
                                            <!--</ul>-->
                                            <!--<table v-if="mainSelection && (downLoadType === '01') || !mainSelection">-->
                                            <table>
                                                <thead>
                                                <tr>
                                                    <td width="30">&nbsp;</td>
                                                    <td>文件名称</td>
                                                    <td width="100">文件来源</td>
                                                    <td width="120">更新时间</td>
                                                    <td width="100">操作</td>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr v-for="(contract,index) in upLoadFileList" :key="'b_'+index">
                                                    <td>
                                                        <el-checkbox v-model="contract.checked"  @change="handleSelectRow(upLoadFileList,contract,index)"></el-checkbox>
                                                    </td>
                                                    <td>
                                                        <span class="blue hand" @click="handleSeeFile(contract)">{{contract.attachName}}</span>
                                                    </td>
                                                    <td>
                                                        {{contract.listType === "SUB_RANGE_LIST" ||  contract.listType === "MERGE_LIST"? "系统生成模板" : contract.uploadCustName+"上传"}}
                                                    </td>
                                                    <td>
                                                        {{contract.creTm && contract.creTm.substring(0,contract.creTm.length-3)}}
                                                    </td>
                                                    <td>
                                                        <!--<span class="blue hand" @click="uploadRecordVisible = true" v-if="upLoadFileList.length">查看上传履历</span>-->
                                                        <span class="blue hand" @click="handleOpenRecordDialog(contract)" v-if="upLoadFileList.length">查看上传履历</span>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                        <!--<div v-if="(downLoadType == '00' || downLoadType == '01') && upLoadFileList && upLoadFileList.length" style="padding-left:10px;margin-top:10px;">-->
                                            <!--<el-checkbox v-model="allCheck" @change="handleAllCheck()">全选</el-checkbox>-->
                                        <!--</div>-->
                                    </div>
                                </el-col>
                            </el-row>
                        </div>
                    </div>
                    <!-- 上传 -->
                    <div class="upload-wrapper" v-if="attatchType == '10'">
                        <div class="attach-panel-title">
                            <span class="hand attach-panel" :class="{'active':dTab.active}"
                                  v-for="(dTab,index) in upLoadTabs" :key="'s_t_'+index"
                                  @click="hanleTitleType('upLoadType','upLoadTabs',dTab.type,index)">{{dTab.label}}</span>
                        </div>
                        <div class="up-load-content">
                            <div class="up-load-warrant" v-if="upLoadType == file.type" v-for="(file,index) in upLoadList" :key="index">
                                <div class="up-load-contract-describe" v-html="mainSelection ? file.mainDescribe : file.subDescribe"  @click="downloadTemp($event)"></div>
                                <div class="up-load-contract-form">
                                    <el-form label="" :label-width="upLoadType === '00' && mainSelection ? '92px':'116px'">
                                        <el-form-item :label="item.fileTypeName" class="contract-content lh40" v-for="(item,ind) in file.uploadFileList" :key="ind">
                                            <el-col :span="24">
                                                <ul class="neet-upload-upfile" :class="{isie:isIE11}">
                                                    <li>
                                                        <p class="input-file-p">
                                                            <span v-if="!item.fileName" class="gray">
                                                              请上传: {{item&&item.fileTypeName||''}} ,
                                                              格式为Excel文件
                                                            </span>
                                                            <span v-else>{{item.fileName || ''}}</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <UpfileComponent
                                                                ref="upfileRef"
                                                                :immediateClearList="true"
                                                                :immediateSubmit="true"
                                                                :showMsg="false"
                                                                :fileSize="52428800"
                                                                :fileSizeMsg="'上传文件不能超过50M, 请重新选择'"
                                                                :btnName="'选择文件'"
                                                                :dirName="selectDirName(item)"
                                                                :type="'8'"
                                                                :fileTypes="item && item.uploadFileSuffix || ''"
                                                                :id="item.displaySort"
                                                                @outputList="outputUpfileList($event, item)">
                                                        </UpfileComponent>
                                                    </li>
                                                </ul>
                                            </el-col>
                                            <!--<el-col :span="4" v-if="mainSelection">-->
                                                <!--<el-button size="small" style="width: 100px;height:40px;margin-left:10px;" @click="handleDownTemp()">下载模板</el-button>-->
                                            <!--</el-col>-->
                                        </el-form-item>
                                    </el-form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dialog-footer">
                <!-- 下载button -->
                <div v-if="attatchType == '00'">
                    <el-button type="primary" size="small" style="width: 100px" @click="handleDownload()">下载</el-button>
                    <el-button size="small" style="width: 100px" @click="handleRefresh">取消</el-button>
                </div>
                <!-- 上传button -->
                <div v-if="attatchType == '10'">
                    <el-button :disabled="!filterFileList()" type="primary" size="small" style="width: 100px" @click.native="submitUpfile()">上传</el-button>
                    <el-button size="small" style="width: 100px" @click="handleRefresh">取消</el-button>
                </div>
            </div>
            <div class="record-table" v-if="attatchType == '10'">
                <table>
                    <thead class="upload-record-title">
                    <tr>
                        <td >已上传的文本</td>
                        <td>上传时间</td>
                    </tr>
                    </thead>
                    <tbody class="record-wrap">
                    <tr v-for="(item,index) in upLoadFileList" :key="'b_'+index">
                        <td>
                            <span class="blue hand" @click="handleSeeFile(item)">{{item.attachName}}</span>
                        </td>
                        <td>
                            {{item.creTm}}
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <!--<div class="uploaded-finished-list" v-if="attatchType == '10'">-->
                <!--<div class="upload-record-title" style="margin-top: 20px;">-->
                    <!--<span>已上传的文本</span>-->
                    <!--<span>上传时间</span>-->
                    <!--&lt;!&ndash;<span>操作</span>&ndash;&gt;-->
                    <!--&lt;!&ndash;<span class="tr" v-show="upLoadType !== '00'">操作</span>&ndash;&gt;-->
                <!--</div>-->
                <!--<div class="record-wrap">-->
                    <!--<ul>-->
                        <!--<li v-for="(item,index) in upLoadFileList" :key="index">-->
                            <!--<span>-->
                                <!--&lt;!&ndash;<em class="hand blue" @click="handleSeeFile(item)">{{item.attachName}}</em>&ndash;&gt;-->
                                <!--<em class="blue hand" @click="handleSeeFile(item)">{{item.attachName}}</em>-->
                            <!--</span>-->
                            <!--<span>{{item.creTm}}</span>-->
                            <!--&lt;!&ndash;<span class="blue hand" @click="uploadRecordVisible = true" v-if="upLoadFileList.length">查看上传履历</span>&ndash;&gt;-->
                        <!--</li>-->
                    <!--</ul>-->
                <!--</div>-->
            <!--</div>-->
            <div class="close-btn hand" @click="handleRefresh"><i class="el-icon-close"></i></div>
        </el-dialog>
        <el-dialog class="confirm-dialog" title="查看上传履历" :append-to-body="true" :lock-scroll="true"
                   :visible.sync="uploadRecordVisible" width="870px" center :close-on-click-modal="false">
            <!--<div class="upload-record-title">-->
                <!--<span>文件名称</span><span>上传时间</span><span>文件来源</span><span>操作</span>-->
            <!--</div>-->
            <!--<div class="record-wrap">-->
                <!--<ul v-if="upLoadRecordList.length !=0">-->
                    <!--<li v-for="(item,ind) in filterRecordList(upLoadRecordList)" :key="ind">-->
                        <!--<span>{{item.attachName}}</span>-->
                        <!--<span>{{item.creTm}}</span>-->
                        <!--<span>{{item.listType === "SUB_RANGE_LIST" ? "系统生成模板" : item.uploadCustName+"上传"}}</span>-->
                        <!--<span class="blue hand">-->
                            <!--<i style="margin-right: 6px;" @click="downloadFile(item)">下载</i>-->
                            <!--<i @click="handleSeeFile(item)">预览</i>-->
                        <!--</span>-->
                    <!--</li>-->
                <!--</ul>-->
                <!--<p v-else>暂无上传履历</p>-->
            <!--</div>-->
            <div class="record-table">
                <table>
                    <thead class="upload-record-title">
                    <tr>
                        <td>文件名称</td>
                        <td width="100">文件来源</td>
                        <td width="120">更新时间</td>
                        <td width="100">操作</td>
                    </tr>
                    </thead>
                    <tbody class="record-wrap">
                    <tr v-for="(contract,index) in filterRecordList(upLoadRecordList)" :key="'b_'+index">
                        <td>
                            <!--<span class="blue hand" @click="handleSeeFile(contract)">{{contract.attachName}}</span>-->
                            <span>{{contract.attachName}}</span>
                        </td>
                        <td>
                            {{contract.listType === "SUB_RANGE_LIST" ? "系统生成模板" : contract.uploadCustName+"上传"}}
                        </td>
                        <td>
                            {{contract.creTm && contract.creTm.substring(0,contract.creTm.length-3)}}
                        </td>
                        <td>
                            <span class="blue hand" style="margin-right: 6px;" @click="downloadFile(contract)">下载</span>
                            <span class="blue hand" @click="handleSeeFile(contract)">预览</span>
                        </td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="upload-foot tc">
                <el-button size="small" style="width: 120px" @click="uploadRecordVisible = false">关闭</el-button>
            </div>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import { InterfaceService } from "@/services/api";
    import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
    import accountMixin from "@/mixins/account";
    import { viewFile } from '@/utils/orderUtil';
    const tabs = [
        { label: "上传资料", type: "10", active: false },
        { label: "下载资料", type: "00", active: true }
    ];

    const subDownLoadTabs = [
        { label: "选型清单(协同选型版)", type: "00", active: true },
    ];
    const mainDownLoadTabs = [
        // { label: "选型清单(范围版)", type: "00", active: false },
        { label: "选型清单(汇总版)", type: "00", active: true },
        { label: "选型清单(协同选型版)", type: "01", active: true },
    ];
    const subUpLoadTabs = [
        { label: "上传选型清单", type: "00", active: true },
    ];
    const mainUpLoadTabs = [
        { label: "上传选型清单", type: "00", active: true },
        { label: "上传选型清单(协同选型版)", type: "01", active: false },
    ];
    const upLoadList = [
        {
//             mainDescribe:`<p>操作指引：</p>
//                   <p>1.待所有协同选型人都已提交过协同选型版的选型清单后，主选型人通过<span class="blue hand marge">【下载资料】-【选型清单（汇总版）】</span>下载选型清单（汇总版），作为线下选型会的选型清单。</p>
//                   <p>2.主选型人编辑选型清单（汇总版）,将线下选型会确定下来的材料设备那一行的"最终选型"列标记成"要"，不需要的材料设备请不要标记内容。</p>
//                   <p>3.确认材料设备都选择完成之后，保存文件。</p>
//                   <p>4.在本页面中点击"选择文件"按钮，选中您保存好的文件，然后点击"上传"按钮。（<em class="red">注意：上传的文件不要压缩。</em>）</p>
//                   <p>5.为了避免因反复上传导致清单的版本混乱，系统会在每次上传成功后将文件名称修改为"供应商公司名称"+"选型品类"+"选型人姓名"+"上传时间"的格式。您可以通过"查看上传履历"查阅到您之前上传过的每一个版本的文件。</p>
// `,
            mainDescribe:`<p>操作指引：</p>
                  <p>1.协同选型人提交选型清单后，主选型人通过<span class="blue hand marge">【下载】-【选型清单（汇总版）】</span>下载选型清单（汇总版），作为线下选型会的选型清单。</p>
                  <p>2.主选型人根据线下选型会的讨论结果，编辑确定需要的材料设备，将其"最终选型"列标记成"要"，编辑完成后保存文件。</p>
                  <p>3. 不需要的材料设备请不要标记内容。</p>
                  <p>4.在本页面中点击"选择文件"按钮，选中您编辑好的选型清单，然后点击"上传"按钮。（<em class="red">注意：请不要压缩上传文件。</em>）</p>
                  <p>5.上传成功后，系统将自动修改文件名称为《"供应商公司名称"+"选型品类"+"选型人姓名"+"上传时间"》。您可通过"查看上传履历"查阅已上传的选型清单。</p>
`,
            type : "00",
            uploadFileList:[{
                fileTypeName: "选型清单(汇总版)",
                uploadFileNameRule: "",
                uploadFileSuffix: "xlsx",
                uploadNecessary: "1",
                acctId: "",
                listType: "MERGE_LIST",
            }]
        },
        {
//             mainDescribe:`<p>请<span class="red">严格按要求上传，切勿传错</span>。上传文件大小不要压缩。在平台提供的选型清单模板基础上完善信息，确认无误后，点击“上传”即可。</p>
//                   <p>选型清单(协同选型版)：协同选型人使用的选型版本。</p>
//                   <p>选型清单(汇总版)：主选型人上传的选型清单(范围版/汇总版)+协同选型人选型结果的最新汇总表，且有数据汇总，该汇总版才会显示。</p>
//                   <p>1、若协同选型人不参与在线选型，主选型人可点击<span class="blue hand download">【下载模板】</span>下载选型清单(协同选型版)，发送给线下协同选型人，收集好协同选型人填写完的清单，再上传。</p>
//                   <p>2、上传后的协同选型清单信息，同意汇总至选型清单(汇总版)，请在<span class="blue hand marge">【下载资料】-【选型清单(汇总版)】</span>下载查看或在已生成的选型清单列表，点击<span class="blue hand view">【在线预览】</span>查看。</p>
// `,
            mainDescribe:`<p>操作指引：</p>
                  <p>1.下载<span class="blue hand download">【选型清单（协同选型版）】</span></p>
                  <p>2.将下载的候选清单文件发送给协同选型人</p>
                  <p>3.协同选型人在线下填写选型清单（协同选型版），完成之后发送给主选型人</p>
                  <p>4.主选型人在本页面中点击"选择文件"按钮，选中需要上传的文件，然后点击"上传"按钮。（<em class="red">注意：上传的文件不要压缩。</em>）</p>
                  <p>5.上传成功之后，系统会将该份协同选型清单汇总至选型清单（汇总版），请在<span class="blue hand marge">【下载】-【选型清单（汇总版）】查看。</span></p>
`,
            subDescribe:`<p>操作指引：</p>
                  <p>1.请在<span class="blue hand download">【下载】-【选型清单（协同选型版）】</span>中将候选材料设备清单下载到您的电脑中。</p>

                  <p>2.自行编辑候选材料设备清单，将您需要的材料设备那一行的"选型"列标记成"要"，不需要的材料设备请不要标记内容。</p>
                  <p>3.确认材料设备都选择完成之后，保存文件。</p>
                  <p>4.在本页面中点击"选择文件"按钮，选中您保存好的文件，然后点击"上传"按钮。（<em class="red">注意：上传的文件不要压缩。</em>）</p>
                  <p>5.为了避免因反复上传导致清单的版本混乱，系统会在每次上传成功后将文件名称修改为"供应商公司名称"+"选型品类"+"选型人姓名"+"上传时间"的格式。您可以通过"查看上传履历"查阅到您之前上传过的每一个版本的文件。</p>
`,

            type : "01",
            uploadFileList:[{
                fileTypeName: "选型清单(协同选型版)",
                uploadFileNameRule: "",
                uploadFileSuffix: "xlsx",
                uploadNecessary: "0",
                acctId: "",
                listType: "SUB_LIST",
            }]
        },
    ];
    export default {
        mixins: [accountMixin],
        components: {
            Loading,
            PanelTitle,
            UpfileComponent,
        },
        props:['mainSelection'],
        data() {
            return {
                isLoading: false,
                dialogVisible: false,
                tabs:JSON.parse(JSON.stringify(tabs)),
                downLoadTabs:[],
                upLoadTabs:JSON.parse(JSON.stringify(subUpLoadTabs)),
                attatchType:"10",//弹层标题
                downLoadType:"00",//合同审批版:00、合同用印版:01
                upLoadType:"00",//上传合同文本:00、上传技术标准:01,上传授权书:02
                uploadRecordVisible:false,
                failMessageVisible:false,
                allCheck:false,
                hasUpload:false,
                supplierInfo: {},
                recordType: "",
                recordAcctId: "",
                upLoadList: JSON.parse(JSON.stringify(upLoadList)),
                upLoadFileList: [],
                upLoadRecordList: [],
                selectionNo:"",
            };
        },

        computed: {
            isIE11() {
                let userAgent = navigator.userAgent;
                return userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; // ie11<11
            },

        },
        methods: {
            open(supplierInfo,selectionNo,openType){
                this.hasUpload = false;
                this.supplierInfo = supplierInfo;
                this.selectionNo = selectionNo;
                if (openType === "download") {
                    this.tabs= [{ label: "下载资料", type: "00", active: true }];
                    this.attatchType = "00";
                    if (this.mainSelection) {
                        this.downLoadTabs = JSON.parse(JSON.stringify(mainDownLoadTabs));
                    }else {
                        this.downLoadTabs = JSON.parse(JSON.stringify(subDownLoadTabs))
                    }
                    this.hanleTitleType('downLoadType','downLoadTabs',"00",0);
                }else {
                    this.tabs= [{ label: "上传资料", type: "10", active: true }];
                    this.attatchType = "10";
                    if (this.mainSelection) {
                        this.upLoadTabs = JSON.parse(JSON.stringify(mainUpLoadTabs));
                    }else {
                        this.upLoadList = JSON.parse(JSON.stringify(upLoadList));
                        this.upLoadList.shift();
                        this.upLoadList[0].type = "00";
                    }
                    this.hanleTitleType('upLoadType','upLoadTabs',"00",0);
                }
                this.dialogVisible = true;
                this.upLoadList[0].uploadFileList[0].acctId = this.acctId;
                this.upLoadList[0].uploadFileList[0].attachUrl = supplierInfo.selectionAttachList && supplierInfo.selectionAttachList[0] && supplierInfo.selectionAttachList[0].attachUrl || "";
                this.upLoadList[0].uploadFileList[0].templateFileName = supplierInfo.selectionAttachList && supplierInfo.selectionAttachList[0] && supplierInfo.selectionAttachList[0].attachName || "";
            },
            S4() {
                return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
            },
            guid() {
                return (this.S4()+this.S4()+"-"+this.S4()+"-"+this.S4()+"-"+this.S4()+"-"+this.S4()+this.S4()+this.S4());
            },
             handleSeeFile(item) {
                 if (item.attachUrl) {
                   viewFile(item.attachUrl)
                 }

            },
            filterFileList(){
                let bool = false;
                this.upLoadList.forEach(item=>{
                    item.uploadFileList.forEach(_item=>{
                        if (_item.upfileResultList && _item.upfileResultList.length > 0) {
                            bool = true
                        }
                    })
                });
                return bool
            },
            handleOpenRecordDialog(item){
                this.recordType = item.listType;
                this.recordAcctId = item.acctId;
                this.uploadRecordVisible = true
            },
            filterRecordList(list) {
                return list.filter(item=>{
                    return item.listType === this.recordType && item.acctId === this.recordAcctId
                }).sort(this.compare)
            },
            compare (obj1, obj2) {
                let val1 = obj1.creTm;
                let val2 = obj2.creTm;
                if (val1 > val2) {
                    return -1;
                } else if (val1 < val2) {
                    return 1;
                } else {
                    return 0;
                }
            },
            //弹层切换：上传、下载
            handleSelectTab(tab,titleType,tabListName,targetType,index) {
                return
                // this.attatchType = tab.type;
                // if (this.attatchType === "10") {
                //     this.hanleTitleType('upLoadType','upLoadTabs',"00",0)
                // }else {
                //     this.hanleTitleType(titleType || 'downLoadType',tabListName || 'downLoadTabs',targetType || "00",index || 0)
                // }
            },
            handleSelectRow(list,row, index) {
                this.$set(list, index, row);
            },
            downloadTemp(e){
                let info = {};
                this.upLoadFileList.forEach(item=>{
                    if (item.recStat == 1) {
                        info = {
                            attachName : item.attachName,
                            attachUrl : item.attachUrl,
                        }
                    }
                });
                if (e.target.className === "blue hand range") {
                    // this.getSelectionFiles(["RANGE_LIST"],"download")
                } else if (e.target.className === "blue hand marge") {
                    this.getSelectionFiles(["MERGE_LIST"],"download");
                } else if (e.target.className === "blue hand view") {
                    this.getSelectionFiles(["MERGE_LIST"],"download");
                } else if (e.target.className === "blue hand download") {
                    this.getSelectionFiles(["SUB_RANGE_LIST"],"download");
                }
            },
            downloadFile(info) {
                this.$download([{
                    name: info.attachName || '',
                    url: info.attachUrl || ''
                }], () => {this.isLoading = true}, () => {this.isLoading = false}).then(result => {
                    this.$message.success('已下载')
                }).catch(err => {
                    this.$message.error('下载失败')
                })
            },
            //上传切换： 上传合同文本、上传技术标准、上传授权书
            hanleTitleType(titleType,tabListName,targetType,index){
                this[titleType] = targetType
                this[tabListName].forEach((item, i) => {
                    item.active = index == i;
                    this.$set(this[tabListName], i, item);
                });
                let typeList = [];
                let operationFlg = "";
                if (tabListName === "downLoadTabs") {
                    if (targetType === "00") {
                        if (this.mainSelection){
                            typeList.push("MERGE_LIST")
                        }else {
                            typeList.push("SUB_RANGE_LIST","SUB_LIST")
                        }
                    }else if (targetType === "01"){
                        typeList.push("SUB_RANGE_LIST","SUB_LIST")
                    }
                }else {
                    if (targetType === "00") {
                        typeList.push(this.mainSelection ? "MERGE_LIST" : "SUB_LIST")
                    }else if (targetType === "01") {
                        typeList.push("SUB_LIST");
                        operationFlg = "oneself"
                    }
                }
                this.getSelectionFiles(typeList,"",operationFlg);
            },
            handleAllCheck() {
                this.upLoadFileList.forEach((item,index)=>{
                    item.checked = this.allCheck;
                })
            },
            // 是否全选
            checkAllSelect(list,type) {
                let num = 0;
                this.allCheck = list.every(item => {
                    num++;
                    return item.checked;
                });
                this.allCheck = num > 0 && this.allCheck;

            },
            selectDirName(item){
                let dirName = `${this.selectionNo}/${this.supplierInfo.corpId}/${this.guid()}/`;
                return dirName
            },
            handleDownTemp(){
                let typeList = [];
                if (this.mainSelection) {
                    if (this.upLoadType === "00") {
                        typeList.push("MERGE_LIST");
                    }else if (this.upLoadType === "01") {
                        typeList.push("SUB_RANGE_LIST");
                    }
                }else {
                    typeList.push("SUB_RANGE_LIST");
                    // let info = {
                    //     attachUrl : this.upLoadList[0].uploadFileList[0].attachUrl,
                    //     attachName : this.upLoadList[0].uploadFileList[0].templateFileName
                    // };
                    // this.downloadFile(info)
                }
                this.getSelectionFiles(typeList,"download")

            },
            handleDownload(){
                let downloadList = []
                this.upLoadFileList.forEach(item=>{
                    if (item.checked) {
                        downloadList.push(item)
                    }
                });
                const attachs = [];
                downloadList.forEach((item) => {
                    attachs.push(item);
                    item.url = item.attachUrl;
                    item.name = item.attachName
                });
                if(this.attatchType ==="00") {
                    if (attachs.length) {
                        this.$download(attachs, () => {this.isLoading = true}, () => {this.isLoading = false}).then(res=>{
                            this.$message.success("已下载");
                        })
                    } else {
                        this.$message.info("请选择需要下载的文件");
                    }
                }
            },
            handleRefresh(){
                this.dialogVisible = false;
                this.upLoadList = JSON.parse(JSON.stringify(upLoadList));
                this.hasUpload && this.$emit("refresh", true);
            },
            // 上传附件
            submitUpfile(num) {
                let params = {};
                let uploadNumList = [];
                if (!num) {
                    this.upLoadList.forEach((item,ind)=>{
                        item.uploadFileList.forEach(_item=>{
                            if (_item.upfileResultList && _item.upfileResultList.length > 0){
                                uploadNumList.push(ind)
                            }
                        })
                    });
                    this.upLoadList[uploadNumList[0]].uploadFileList.forEach(file=>{
                        if (file.upfileResultList && file.upfileResultList.length > 0) {
                            params = {
                                selectionNo : this.selectionNo,
                                supplierId : this.supplierInfo.corpId,
                                attachName : file.upfileResultList[0].name,
                                attachUrl:file.upfileResultList[0].url,
                                acctId : file.acctId,
                                listType : file.listType,
                            };
                        }
                    });
                    this.doSubmit(params,uploadNumList.length);
                }else {
                    this.upLoadList[uploadNumList[num]].uploadFileList.forEach(file=>{
                        if (file.upfileResultList && file.upfileResultList.length > 0) {
                            params = {
                                selectionNo : this.selectionNo,
                                supplierId : this.supplierInfo.corpId,
                                attachName : file.upfileResultList[0].name,
                                attachUrl:file.upfileResultList[0].url,
                                acctId : file.acctId,
                                listType : file.listType,
                            };
                        }
                    });
                    this.doSubmit(params);
                }
            },
            doSubmit(params,len){
                InterfaceService.uploadSelectionFiles(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("上传成功！");
                            this.upLoadList[0].uploadFileList.forEach(item=>{
                                if (item.fileName) {
                                    item.fileName = ""
                                }
                                if (item.upfileResultList) {
                                    item.upfileResultList = []
                                }
                            });
                            if (len && len == 2) {
                                this.submitUpfile(0);
                                return
                            }
                            // if (params.listType === "SUB_LIST") {
                            //     this.tabs[1].active = true;
                            //     this.tabs[0].active = false;
                            //     if (this.mainSelection) {
                            //         this.handleSelectTab({type:'00'},'downLoadType','downLoadTabs',"01",1)
                            //     } else {
                            //         this.handleSelectTab({type:'00'},'downLoadType','downLoadTabs',"00",0)
                            //     }
                            // }else {
                            //     this.tabs[1].active = true;
                            //     this.tabs[0].active = false;
                            //     this.handleSelectTab({type:'00'},'downLoadType','downLoadTabs',"00",0)
                            // }
                            let typeList = [];
                            let operationFlg = "";
                            if (this.upLoadType === "00") {
                                typeList.push(this.mainSelection ? "MERGE_LIST" : "SUB_LIST")
                            }else if (this.upLoadType === "01") {
                                typeList.push("SUB_LIST");
                                operationFlg = "oneself"
                            }
                            this.getSelectionFiles(typeList,"",operationFlg);
                            this.hasUpload = true
                        }else if (data.respData.respCode === "PROD0316"){
                            let text = "";
                            data.respData.failMessageList && data.respData.failMessageList.forEach(item=>{
                                text = text + `<div class="f12 tl">${item}</div>`
                            });
                            let msg = `${data.respData.respMsg}`;
                            this.$alert(
                                text,
                                msg,
                                {
                                    customClass: "alert-box",
                                    confirmButtonText: "知道了",
                                    dangerouslyUseHTMLString: true,
                                    center: true,
                                    callback: action => {
                                    }
                                }
                            );
                        }else {
                            this.$message.error(data.respData.respMsg);
                        }
                        this.upLoadList.forEach(_item=>{
                            _item.uploadFileList.forEach(item=>{
                                if (item.fileName) {
                                    item.fileName = ""
                                }
                                if (item.upfileResultList) {
                                    item.upfileResultList = []
                                }
                            });
                        })
                    },
                    data => {
                    },
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            outputUpfileList(ev, item) {
                ev = [...ev] || [];
                const name = ev[0] && ev[0].name && ev[0].name.slice(0, ev[0].name.lastIndexOf('.')) || '',
                    uploadFileNameRule = item && item.uploadFileNameRule || '',
                    getFileItem = item || {}
                // 文件名校验规则 包含/全等/不验证
                if (getFileItem.uploadFileNameRuleType === 'like')  {
                    if (!name.includes(uploadFileNameRule)) {
                        this.$message.error(`请上传文件名包含 ${getFileItem.uploadFileNameRule || ''} 的文件`)
                        return
                    }
                } else if (getFileItem.uploadFileNameRuleType === 'same') {
                    if (name !== uploadFileNameRule) {
                        this.$message.error(`请上传文件名为 ${getFileItem.uploadFileNameRule || ''} 的文件`)
                        return
                    }
                }

                this.$set(item, 'upfileResultList', ev);
                this.$set(item, 'fileName', ev[0] && ev[0].name)
            },
            compareBy(property) {
                return function (a, b) {
                    var value1 = a[property];
                    var value2 = b[property];
                    return value1 - value2;
                }
            },
            getSelectionFiles(typeList,temp,operationFlg) {
                let params = {
                    selectionNo:this.selectionNo,
                    supplierList:[this.supplierInfo.corpId],
                    listTypeList:typeList,
                    operationFlg:operationFlg,
                };
                InterfaceService.getSelectionFiles(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            if (!temp) {
                                this.upLoadFileList = [];
                                // this.upLoadRecordList = data.respData.selectionAttachCoordinationList && data.respData.selectionAttachCoordinationList.reverse() || [];
                                // let arr = ["2019-10-18 13:48","2019-10-18 10:22","2019-10-18 10:32"]
                                // console.log(arr.sort());
                                this.upLoadRecordList = data.respData.selectionAttachCoordinationList && data.respData.selectionAttachCoordinationList || [];
                                // this.upLoadRecordList = this.upLoadRecordList.sort(this.compareBy("creTm"))
                                this.upLoadRecordList.forEach(item=>{
                                    if (item.recStat === "1") {
                                        this.upLoadFileList.push(item)
                                    }
                                });
                                // this.upLoadFileList = this.filterList(this.upLoadFileList);
                                this.upLoadFileList = this.upLoadFileList.sort(this.compare);
                                this.upLoadFileList.forEach(item=>{
                                    item.checked = true
                                })
                            }else {
                                let info = {};
                                let list =  data.respData.selectionAttachCoordinationList || [];
                                list.forEach(item=>{
                                    if (item.recStat === "1") {
                                        info = {
                                            attachName:item.attachName,
                                            attachUrl:item.attachUrl,
                                        }
                                    }
                                });
                                if (!info.attachName && typeList[0] === "MERGE_LIST") {
                                    this.$message.error("该选型项目相关选型人员未提交选型，暂无汇总版清单。")
                                }else if (!info.attachName) {
                                    this.$message.error("暂无资料下载")
                                } else {
                                    this.downloadFile(info,typeList)
                                }
                            }
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {
                    },
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            }
        },
    };
</script>

<style lang="scss" scoped>
    .close-btn{
        width: 50px;
        height: 50px;
        position: absolute;
        top: 0;
        right: 0;
        text-align: center;
        line-height: 50px;
        .el-icon-close{
            font-size: 22px;
        }
    }
    table {
        width: 100%;

        thead {
            text-align: center;
        }
        tr {
            height: 26px;
            line-height: 26px;
            border-bottom: 1px solid #fff;
        }
        tbody {
            td {
                padding: 5px 10px;
            }
        }
    }
    .record-table{
        max-height: 300px;
        overflow-y: auto;
        margin-bottom: 20px;
        tbody{
            td{
                text-align: left;
            }
        }
    }
    .upload-record-title{
        width: 100%;
        border-top: 1px solid #eeeeee;
        height: 34px;
        line-height: 34px;
        background: #f5f5f5;
        padding-left: 10px;
        position: relative;
        margin-top: -15px;
    }
    .record-wrap{
        width: 100%;
        max-height: 300px;
        overflow-y: auto;
        background: #f5f5f5;
        border-bottom: 1px solid #eee;
        margin-bottom: 20px;
    }
    .panel-title{
        margin-bottom: 4px !important;
    }

    .attach-wrapper{
        /deep/ .el-checkbox__inner{
            border-radius: 0;
            background-color:#eee;
            border:1px solid #cacaca;
        }

        /deep/ .el-checkbox__input.is-checked .el-checkbox__inner{
            background-color: #ffd64e;
            border-color:#ffd64e;
        }

        /deep/ .el-checkbox__input.is-checked + .el-checkbox__label{
            color:#444 !important;
        }
        .attach-panel-title{
            height: 38px;
            width: 100%;
            background: #eee;
            overflow: hidden;
            margin-bottom: 10px;
            .attach-panel{
                font-size:14px;
                color: #888;
                font-weight: 500;
                line-height: 38px;
                height:38px;
                padding:0 20px;
                background: #eee;
                float: left;
                &.active{
                    color:#fff;
                    font-weight: 700;
                    background: #4f525a;
                }
            }
        }

    }
    .s-title{
        font-size: 14px;
        color:#444;
        margin:10px 0;
        border-left: 3px solid #4f525a;
        line-height: 1.2;
        padding-left: 6px;
    }
    .s-body{
        height:224px;
        background: #eee;
        overflow-y: auto;
        padding:4px 10px;
        li{
            width: 100%;

            font-size: 14px;
            color:#444;
            min-height: 28px;
            padding:7px 0 ;
            line-height: 1.2;
        }

    }
    .upload-wrapper{
        .up-load-contract-describe{
            padding-top:10px;
            line-height: 20px;
            font-size: 12px;
            color:#444;
        }
        .up-load-contract-form{
            padding-top: 20px;
            position: relative;
            input[type="file"] {
                position: absolute;
                width: 0;
                height: 0;
                overflow: hidden;
                opacity: 0;
            }

            .file-label {
                width: 98px;
                display: inline-block;
                padding: 12px 20px;
                line-height: 1;
                white-space: nowrap;
                cursor: pointer;
                font-size: 14px;
                border: 1px solid #ffd64e;
                background: #ffd64e;
                margin-left: 10px;
            }
            .disable{
                /*padding: 12px 14px;*/
                border: 1px solid #dddddd;
                background: #dddddd;
                cursor: not-allowed;
                color: #afaeae;
            }
            /deep/ .el-checkbox {
                padding: 0;
                margin-left: 0;
                border: none;
                background: none;
            }
            /deep/ .el-col-24 label:nth-of-type(2){
                margin-left: 10px;
            }
            .label-title{
                width: 100%;
                line-height: 18px;
            }

            .label-sub-title{
                width: 100%;
                line-height: 16px;
                font-size: 12px;
            }

            .contract-list {
                min-height: 38px;
                padding: 0 10px;
                border: 1px solid #dcdfe6;
                line-height: 38px;
                color: #888888;
                font-size: 12px;
            }

            a{
                margin-left: 10px;
                color: #0082ff;
            }
        }
        .hand {

        }

    }
    /deep/ .el-form-item__label{
        font-size: 12px!important;
    }
    .up-load-warrant{

        /deep/ .el-form-item__label{
            line-height: 1.2;
            font-size: 12px;
            padding-right: 0 !important;
        }
    }
    .el-tag + .el-tag {
        margin-left: 10px;
    }

    .dialog {
        line-height: 25px;

        /deep/ .el-dialog__header {
            padding: 0;

            &:before {
                display: none;
            }
        }
    }
    .neet-upload-upfile {
        box-sizing: border-box;
        padding-left: 12px;
        display: flex;
        border-top: 1px solid transparent;

        &.disabled {
            /deep/ .center .blue {
                // background: #dddddd !important;
                // color: #a9a9a9 !important;
            }
        }

        &>li {
            width: 86%;

            &:nth-child(1) {
                .input-file-p {
                    border: 1px solid #dcdfe6;
                    box-sizing: border-box;
                    padding: 0 12px;
                    color: #606266;
                    display: block;
                    display: flex;
                    flex-wrap: wrap;
                    min-height: 40px;

                    span {
                        height: 38px;
                        overflow: hidden;
                        text-overflow:ellipsis;
                        white-space: nowrap;
                    }

                    &>.gray {
                        color: #c0c4cc;
                        font-size: 12px;
                        outline: none;
                        height: 38px;
                    }

                    .el-tag {
                        margin: 4px;
                        height: 30px;
                    }
                }
            }

            &:nth-child(2) {
                width: 100px;
            }

            &:nth-child(3) {
                width: 33%;
            }

            .el-button--default {
                height: 40px;
                margin-left: 4px;
            }
        }

        .el-button--primary {
            width: 119px;
            margin-right: 12px;
        }

        /deep/ .upfile-container {
            .center {
                label {
                    width: 100%;
                    background-color: #ffd64e;
                    color: #000000 !important;
                    text-align: center;
                    height: 40px;
                }
            }
        }

    }

    .lh40{
        height: 40px;
        line-height: 40px;
    }
    .lh12{
        line-height: 1.2;
    }
    .lh40{
        /deep/ .el-form-item__label{
            height: 40px;
            line-height:40px;
        }
    }
    .isie{
        /deep/ .upfile-container {
            .center {
                label {
                    height: 42px;
                }
            }
        }
    }
    /deep/ .dialog-footer{
        text-align: center;
        margin-bottom: 20px;
        margin-top:20px;
    }
    .clear{
        clear: both;
    }
</style>
