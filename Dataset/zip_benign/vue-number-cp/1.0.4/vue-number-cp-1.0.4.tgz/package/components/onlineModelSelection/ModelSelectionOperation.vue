<template>
    <div class="operate">
        <div v-if="selectionInfo.status === 'draft'">
            <el-button type="primary" size="mini" @click="createSelectionProject(selectionInfo)">继续</el-button>
            <a @click="handleOpenCancelDialog(selectionInfo.selectionNo,'del')">删除</a>
        </div>
        <div v-if="selectionInfo.status === 'processing'">
            <el-button v-if="mainSelection" type="primary" size="mini" @click="handleOnlineSelection(selectionInfo)">在线选型</el-button>
            <a v-if="mainSelection" @click="createSelectionProject(selectionInfo)">编辑</a>
            <el-button v-if="subSelection" type="primary" size="mini" @click="handleOnlineSelection(selectionInfo)">去选型</el-button>
        </div>
        <div v-if="selectionInfo.status === 'confirmed' && mainSelection">
            <el-button type="primary" size="mini">快速采购</el-button>
            <a @click="handleOnlineSelection(selectionInfo)">在线选型</a>
        </div>
        <div v-if="selectionInfo.status === 'finished' || selectionInfo.status === 'canceled'">
            <a @click="handleOnlineSelection(selectionInfo,'detail')">查看详情</a>
        </div>
        <div v-if="selectionInfo.status === 'confirmed' && subSelection && !mainSelection">
            <a>下载清单</a>
        </div>
        <el-dropdown v-if="showMore && mainSelection && (selectionInfo.status === 'processing' || selectionInfo.status === 'confirmed' || selectionInfo.status === 'finished')">
            <a class="el-dropdown-link">
                更多功能<i class="el-icon-arrow-down el-icon--right"></i>
            </a>
            <el-dropdown-menu slot="dropdown">
                <template v-if="selectionInfo.status === 'processing'">
                    <el-dropdown-item>
                        <a type="text" @click="handleCoordination(selectionInfo)">协同选型设置</a>
                    </el-dropdown-item>
                    <el-dropdown-item>
                        <a type="text" @click="handleOpenCancelDialog(selectionInfo.selectionNo,'cancel')">撤销</a>
                    </el-dropdown-item>
                </template>
                <template v-if="selectionInfo.status === 'confirmed'">
                    <el-dropdown-item>
                        <a type="text" @click="createSelectionProject(selectionInfo)">编辑</a>
                    </el-dropdown-item>
                    <el-dropdown-item>
                        <a type="text">下载清单/报告</a>
                    </el-dropdown-item>
                </template>
                <template v-if="selectionInfo.status === 'finished'">
                    <el-dropdown-item>
                        <a type="text">快速采购</a>
                    </el-dropdown-item>
                    <el-dropdown-item>
                        <a type="text">下载清单/报告</a>
                    </el-dropdown-item>
                </template>
            </el-dropdown-menu>
        </el-dropdown>
        <el-dialog class="dialog" title="协同选型设置" :lock-scroll="true" :modal-append-to-body='false' :visible.sync="dialogVisible" :width="dialogWidth" center :close-on-click-modal="false" :close-on-press-escape="false" @close="handleCloseDialog">
            <CoordinationModelSelection v-if="selectionInfo" :closeDialog="closeDialog" :dialog="true" @close="handleChangeWidth" @getCoordinationList="getCoordinationList" :selectorList="selectorList" :open="dialogVisible"></CoordinationModelSelection>
            <el-row>
                <el-col :span="24" class="form-btns">
                    <el-button type="primary" @click="handleSaveCoordination()">提交</el-button>
                    <el-button @click="dialogVisible= false">取消</el-button>
                </el-col>
            </el-row>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>
        <!--撤销-->
        <el-dialog class="dialog" :title="cancelTitle" :append-to-body="true" :lock-scroll="true" :visible.sync="cancelDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;cancelReason = ''">
            <div class="f14 form-btns" :class="{'tl':cancelType !== 'delete'}" style="line-height: 20px">{{cancleText}}</div>
            <el-input v-if="cancelType !== 'delete'" style="margin: 20px 0;" type="textarea" v-model="cancelReason" :placeholder="canclePlaceholder+'200字以内'" clearable :maxlength="200" @input="handleEntry($event)"></el-input>
            <div v-if="cancelType !== 'delete'"  class="count">
                <span :class="{'red':entryNum >= 200}"> {{entryNum}}</span>/ 200
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" :disabled="!cancelReason && cancelType !== 'delete'" size="small" style="width: 100px" @click="handleCancelSelection(cancelType)">{{cancelType !== 'delete' ? "提交" : "删除"}}</el-button>
                <el-button size="small" style="width: 100px" @click="cancelDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import accountMixin from "@/mixins/account";
    import CoordinationModelSelection from "@/components/onlineModelSelection/CoordinationModelSelection";
    import { InterfaceService } from "@/services/api";
    import Loading from "@/components/base/Loading";

    export default {
        mixins: [accountMixin],
        components: {
            CoordinationModelSelection,
            Loading,
        },
        props: ["selectionInfo","mainSelection","subSelection"],
        data() {
            return {
                attach: {},
                dialogVisible:false,
                closeDialog:false,
                cancelDialogVisible:false,
                isLoading:false,
                entryNum:0,
                dialogWidth:"840px",
                cancelReason:"",
                cancleSelectionNo:"",
                cancelTitle:"",
                cancleText:"",
                canclePlaceholder:"",
                cancelType:"",
                coordinationList:[],
                selectorList:[],
                coordInfo:{},
            };
        },
        computed: {
            showMore(){
                return this.selectionInfo.status !== 'draft' && this.selectionInfo.status !== 'canceled'
            }
        },
        methods: {
            createSelectionProject(info) {
                const { href } = this.$router.resolve({
                    path: "/createSelectionCategory",
                    query: {
                        selectionNo:info.selectionNo
                    },
                });
                window.open(href, '_blank');
            },
            handleCloseDialog() {
                this.closeDialog = true
                this.coordinationList = []
            },
            getCoordinationList(list) {
                list.forEach(item=>{
                    delete item.label;
                });
                this.coordinationList = list;
            },
            handleOpenCancelDialog(selectionNo,type){
                if (type === "del") {
                    this.cancelTitle = "删除选型项目";
                    this.cancleText = "选型项目删除后，不再复原。是否要删除该选型项目？";
                    this.canclePlaceholder = "";
                    this.cancelType = "delete"
                }else if (type === "cancel") {
                    this.cancelTitle = "撤销选型项目";
                    this.cancleText = "选型项目撤销后，协同选型人将不能再继续操作该选型项目。撤销后的选型项目，请在已结束选型列表中查看。是否要撤回该选型项目？";
                    this.canclePlaceholder = "填写撤销选型原因，";
                    this.cancelType = "cancel"
                }
                this.cancleSelectionNo = selectionNo;
                this.cancelDialogVisible = true
            },
            handleEntry(ev){
                this.entryNum = ev.length
            },
            handleSaveCoordination() {
                let list = [];
                console.log(this.coordinationList);
                this.selectorList.forEach(item=>{
                    let onOff = false;
                    this.coordinationList.forEach((_item,ind)=>{
                        if (_item.acctId === item.acctId && _item.acctId) {
                            onOff = true;
                            _item.initPerson = true;
                        }
                    });
                    if (!onOff && item.selectionRole != "main") {
                        list.push({
                            acctId : item.acctId,
                            mobile : item.mobile,
                            optFlg : "del"
                        })
                    }
                });
                this.coordinationList.forEach(item=>{
                    if (!item.initPerson && item.acctId) {
                        list.push(item)
                    }
                })
                let params = {
                    selectionNo:this.coordInfo.selectionNo,
                    coordinationList:list,
                };
                InterfaceService.setCoordination(
                    params,
                    data => {
                        //console.log(data);
                        if (data.respData.respCode === "0000") {
                            this.dialogVisible = false;
                            this.$message.success("协同选型人员设置成功")
                            this.$emit("refrash",true)
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            //撤销
            handleCancelSelection(type) {
                InterfaceService.deleteSelectionProject(
                    {
                        selectionNo:this.cancleSelectionNo,
                        reason:this.cancelReason,
                        optFlg:type
                    },
                    data => {
                        //console.log(data);
                        if (data.respData.respCode === "0000") {
                            this.$message.success(type === "cancel" ? "已撤销选型" : "已删除选型");
                            this.cancelDialogVisible = false;
                            this.$emit("refrash",type,true)
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            //弹窗宽度设置
            handleChangeWidth(bool) {
                if (bool) {
                    this.dialogWidth = "840px"
                }else {
                    this.dialogWidth = "50%"
                }
            },
            handleOnlineSelection(info,detail) {
                let selectionInfo = {
                    selectionNo : info.selectionNo,
                    creTm : info.creTm,
                    categoryFullName : info.categoryFullName,
                };
                const { href } = this.$router.resolve({
                    path: "/onlineSelectionDetail",
                    query: {
                        selectionInfo:JSON.stringify(selectionInfo),
                        detail:detail || ""
                    },
                });
                window.open(href, '_blank');
            },
            handleCoordination(info) {
                this.coordInfo = info;
                this.selectorList = info.selectorList || [];
                this.closeDialog = false;
                this.dialogVisible = true
            },

        },
        mounted() {
        }
    };
</script>

<style lang="scss" scoped>
    /deep/ .el-button {
        margin-bottom: 5px;
    }

    .operate {
        a {
            display: block;
            white-space: nowrap;
            padding: 5px 5px 0 5px;
            line-height: 18px;
            color: #0082ff;
            font-size: 12px;
            text-align: right;
        }
        p{
            text-align: right;
        }
    }
    /deep/ .el-dropdown {
        width: 100%;
        text-align: right;
    }
    /deep/ .el-dropdown-menu__item {
        color: #0082ff;
        text-align: right;
        font-size: 12px;
        &:hover{
            color: #0082ff;
            background: #e8f3fd;
        }
        a{
            display: block;
            width: 100%;
            height: 100%;
        }
    }
    .form-btns{
        padding: 10px 0;
        text-align: center;
        .el-button{
            width: 120px;
            height: 30px;
            line-height: 6px;
        }
    }
    .count{
        float: right;
        width: 100%;
        text-align: right;
        margin-bottom: 20px;
        span.red{
            color: #f00;
        }
    }
</style>
