<template>
    <div>
        <div class="content" :class="{'dialog-content':dialog}" v-if="dontUserManage || !dialog">
            <div class="order-info-title" v-if="!dialog">
                <span class="bold f14">协同选型</span>
            </div>
            <p class="f12 tl tips" v-if="!dialog">添加仅对本选型项目开放的协同选型人员，点击【发布】按钮，可将创建后的选型项目信息及清单情况同步给相关选型人员。能搜索选择到的协同人员信息，均来自人力资源信息库，若没有协同选型人员可选，请<em class="blue hand" @click="addNewRole()">创建协同选型人员</em>。</p>
            <p class="f12 tl" v-else>设置仅对本选型项目开放的协同选型人员，点击【提交】按钮，会将选型项目信息及清单情况同步给相关选型人员。能搜索选择到的协同人员信息，均来自人力资源信息库，若没有协同选型人员可选，请<em class="blue hand" @click="addNewRole()">创建协同选型人员</em>。</p>
            <div class="coordination-content">
                <el-row>
                    <el-col :span="12" v-for="(item,ind) in coordinationList" :key="ind" :class="{'el-col-pt14':ind < 2}">
                        <span>协同选型人员{{ind+1}}</span>
                        <el-select allow-create clearable remote filterable default-first-option no-data-text="暂无数据"
                                   v-model="item.acctName"
                                   placeholder="请选择搜索协同选型人员"
                                   :remote-method="handleSearchRole"
                                   @visible-change="handleVisibleChange($event,item,ind)"
                                   @change="handleChangeRole($event,item,ind)"
                                   :ref="'select'+ind"
                        >
                            <!--<el-option v-for="(person,index) in filterPersonList(personList)" :label="person.acctName" :value="person.acctId" :key="person.acctId">-->
                            <el-option v-show="!searchRole" v-for="(person,index) in filterPersonList(personList)" :label="person.acctName" :value="person.acctName" :key="person.acctId">
                                 <span>{{person.acctName}}</span><span>{{person.dept}}</span><span>{{person.title}}</span>
                            </el-option>
                            <el-option v-for="(person,index) in hrRoleList" :label="person.acctName" :value="person.acctName" :key="index">
                                <span>{{person.acctName}}</span> <span>{{person.dept}}</span><span>{{person.title}}</span>
                            </el-option>
                        </el-select>
                        <span class="blue hand" @click="handleDel(ind)">删除</span>
                        <!--<span v-if="ind === coordinationList.length-1 && !dialog" class="blue hand" @click="addCoordinationPerson()">+添加协同选型人员</span>-->
                    </el-col>
                </el-row>
                <div class="add tc"><span class="blue hand" @click="addCoordinationPerson()">+添加协同选型人员</span></div>
            </div>
        </div>
        <UsersManage :dialog="dialog" :justAdd="true" ref="UsersManage" @cancle="cancleAdd" @saveSuccess = "getSubRole"></UsersManage>

    </div>

</template>

<script>
    import { InterfaceService } from "@/services/api";
    import UsersManage from "@/components/auth/UserManage";
    import accountMixin from "@/mixins/account";

    export default {
        name: "CoordinationModelSelection",
        mixins: [accountMixin],
        props:["dialog","closeDialog","selectorList","open"],
        data(){
            return{
                personList:[],
                noAllRoleList:[],
                hrRoleList:[],
                coordinationList:[{
                    optFlg:"add",
                    mobile:"",
                    acctName:""
                }],
                person1:"",
                storeInd:0,
                storeName:"",
                hrName:"",
                dontUserManage:true,
                searchRole:false,
                editeNum:0,
            }
        },
        components:{
            UsersManage,
        },
        watch:{
            closeDialog(newVal){
                if (newVal) {
                    this.coordinationList = [{
                        optFlg:"add",
                        mobile:"",
                        acctName:""
                    }]
                }
            },
            open(newValue) {
                if (newValue) {
                    this.coordinationList = [];
                    this.selectorList.forEach(item=>{
                        if (item.selectionRole === "sub" && item.custName && item.acctId) {
                            this.coordinationList.push({
                                acctName : item.custName,
                                acctId : item.acctId,
                                mobile : item.mobile||"",
                                optFlg : "add"
                            })
                        }
                    });
                    if (this.coordinationList.length === 0) {
                        this.coordinationList.push({
                            optFlg:"add",
                            mobile:"",
                            acctName:""
                        })
                    }
                    this.getSubRole();
                }
            }
        },
        computed:{
            acctId() {
                return (
                    this.$store.state.userInfo && this.$store.state.userInfo.acctId
                );
            },
        },
        methods:{
            filterPersonList(list) {
                let outList = [];
                list.forEach(item => {
                    let onOff = true;
                    this.coordinationList.forEach(_item=>{
                        if (item.acctId === _item.acctId) {
                            onOff = false
                        }
                    });
                    if (onOff) {
                        outList.push(item)
                    }
                });
                return outList
            },
            addCoordinationPerson() {
                this.coordinationList.push({acctName:"",optFlg:"add"})
            },
            handleDel(ind) {
                if (this.coordinationList.length > 1) {
                    this.coordinationList.splice(ind,1);
                } else {
                    this.coordinationList = [{
                        optFlg:"add",
                        mobile:"",
                        acctName:"",
                        acctId:""
                    }]
                }
                this.$emit("getCoordinationList",this.coordinationList);
            },
            // 查询项目部下属信息
            getSubRole() {
                this.dontUserManage = true;
                this.dialog && this.$emit("close",this.dontUserManage)
                InterfaceService.getQuerySubordinate(
                    {},
                    data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            // 正常状态的用户（acctStatus == "0"）才可以作为干系人参与合同
                            this.personList = [];
                            this.noAllRoleList = [];
                            res.acctList && res.acctList.forEach(i=>{
                                if (i.acctStatus == "0" && !this.mxAcctIdList.includes(i.acctId)  ) {
                                    i.checked = true;
                                    this.personList.push(i);
                                }
                            });
                            let rlist = data.respData.roleList || [];
                            rlist.forEach(item => {
                                this.noAllRoleList.push(
                                    {label: item.roleName,
                                        value: item.roleId}
                                )
                            });
                            this.coordinationList.forEach((item,ind)=>{
                                this.personList.forEach(_item=>{
                                    if (_item.acctName == this.storeName && ind == this.storeInd) {
                                        item.acctName = _item.acctName
                                    }
                                    if (item.acctName === _item.acctName){
                                        item.mobile = _item.mobile
                                    }
                                    if (item.mobile === _item.mobile) {
                                        item.acctId = _item.acctId
                                    }
                                });
                            });
                            this.$forceUpdate();
                            this.$emit("getCoordinationList",this.coordinationList);
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            //远程搜索绿地用户
            handleSearchRole(query) {
                if (query) {
                    this.searchRole = true
                    this.personList.forEach(item=>{
                        item.checked = item.acctName.indexOf(query) != -1;
                    });
                    let params = {
                        custName:query,
                        pageIndex: 1,
                    };
                    InterfaceService.addHrSystemInfo(
                        params,
                        data => {
                            let res = data.respData;
                            if (res.respCode === "0000") {
                                this.hrRoleList = res.custList || [];
                                this.personList.forEach(item=>{
                                    this.hrRoleList.forEach((_item,ind)=>{
                                        if (_item.custName === item.acctName) {
                                            this.hrRoleList.splice(ind,1);
                                        }
                                    })
                                });
                                this.hrRoleList =  this.hrRoleList.concat(this.personList.filter(item=>{return item.acctName.indexOf(query) != -1})).reverse();
                                this.hrRoleList.forEach((item,ind)=>{
                                    if (item.custName) {
                                        item.acctName = item.custName;
                                    }
                                    if (item.deptName) {
                                        item.dept = item.deptName;
                                    }
                                    item.keyVal = item.mobile || "HR" + ind+1;
                                    if (item.acctName) {
                                        item.keyVal = item.acctName
                                    }
                                    Object.keys(item).map(key => {
                                        if (item[key] == "null") {
                                            item[key] = null
                                        }
                                    });
                                })
                            } else {
                                this.$message.error(res.respMsg);
                            }
                        },
                        data => {},
                        () => {
                            this.isLoading = true;
                        },
                        () => {
                            this.isLoading = false;
                        }
                    );
                }
            },
            handleVisibleChange(ev,item,index) {
                this.personList.forEach(item=>{
                    item.checked = true
                });
                this.searchRole = false;
                if (ev) {
                    this.hrRoleList = [];
                }
            },
            addNewRole() {
                this.dontUserManage = false;
                this.dialog && this.$emit("close",this.dontUserManage);
                this.$refs.UsersManage.handleOpenAddForm("",this.noAllRoleList)
            },
            handleChangeRole(ev,item,ind){
                if (!ev) {
                    this.personList.forEach(item=>{
                        item.checked = true
                    });
                    item.acctId = ""
                    // if (this.coordinationList.length > 1) {
                    //     this.coordinationList.splice(ind,1);
                    // }
                }
                this.editeNum = ind;
                let hasRole = false;
                let fromHr = false;
                let acctIdList = [];
                let hrPersonInfo = {};
                this.coordinationList.forEach(_item=>{
                    this.personList.concat(this.hrRoleList).forEach(item=>{
                        if (_item.acctName === item.acctName) {
                            _item.mobile = item.mobile || ""
                        }
                    });
                    if (_item.acctName){
                        acctIdList.push(_item.acctName)
                    }
                });
                let repeatList = acctIdList.sort();
                for (let i = 0; i < acctIdList.length; i++) {
                    if (repeatList[i] == repeatList[i + 1] && repeatList[i] != "") {
                        this.$message.error("已存在该协同选型人员，请勿重复选择！");
                        item.acctName = "";
                        return
                    }
                }
                let newPerson = true;
                this.personList.concat(this.hrRoleList).forEach(_item=>{
                    if (_item.acctName === item.acctName) {
                        item.acctId = _item.acctId
                        newPerson = false;
                        hasRole = _item.roleIds && _item.roleIds.some(role => {
                            return role.roleId === "616";
                        });
                    }
                });
                this.hrRoleList.forEach(_item=>{
                    this.personList.forEach(__item=>{
                        if (_item.acctName === item.acctName && _item.custName) {
                            hrPersonInfo = _item;
                            newPerson = false;
                            fromHr = true;
                        }
                    });
                });
                this.$emit("getCoordinationList",this.coordinationList);
                if (item.acctName && newPerson) {
                    this.$confirm(
                        "查询不到此人员，是否创建此协同选型人员？",
                        {
                            cancelButtonClass: "btn-custom-cancel",
                            confirmButtonClass: "btn-custom-confirm",
                            center: true,
                            type: 'warning',
                            confirmButtonText: "确认",
                            cancelButtonText: '取消',
                        }).then(() => {
                        let id = item.acctName;
                        this.storeInd = ind;
                        this.storeName = item.acctName;
                        this.dontUserManage = false;
                        this.dialog && this.$emit("close",this.dontUserManage);
                        // this.$refs.UsersManage.handleOpenAddForm(item.acctId,this.noAllRoleList);
                        this.$refs.UsersManage.handleOpenAddForm(id,this.noAllRoleList);
                        this.$nextTick(() =>{
                            !this.dialog && this.$refs["select" + ind][0].blur();
                        });
                    }).catch(() => {
                        item.acctName = ""
                        item.acctId = ""
                    });
                }else if (item.acctName && !newPerson) {
                    if (!hasRole && !fromHr) {
                        this.$confirm(
                            "此人员没有协同选型权限，是否一键添加该人员协同选型权限？",
                            {
                                cancelButtonClass: "btn-custom-cancel",
                                confirmButtonClass: "btn-custom-confirm",
                                center: true,
                                type: 'warning',
                                confirmButtonText: "确认",
                                cancelButtonText: '取消',
                            }).then(() => {
                            this.$nextTick(() =>{
                                this.$refs["select" + ind][0].blur();
                            });
                            this.addRoles(item.acctId,"",ind,"editSubordinate");
                            !this.dialog && this.$refs["select" + ind][0].blur();
                        }).catch(() => {
                            console.log(item);
                            item.acctName = ""
                            item.acctId = ""

                        });
                    }else if (fromHr) {
                        this.hrName = hrPersonInfo.acctName;
                        // this.hrName = hrPersonInfo.acctName;
                        this.checkHrPersonForm(hrPersonInfo,ind,"addSubordinate")
                    }
                }
            },
            checkHrPersonForm(info,ind,type) {
                let ruleForm = {
                    roleIds:[]
                };
                // if (info.noCertNo) {
                //     info.certNo = "";
                // }
                ruleForm.acctName = info.custName || "";
                ruleForm.mobile = info.mobileNo || "";
                ruleForm.email = info.email || "";
                ruleForm.title = info.title || "";
                ruleForm.dept = info.dept || "";
                // ruleForm.certNo = info.certNo || "";
                ruleForm.roleIds.push("616");
                this.addRoles(ruleForm,"hr",ind,type)
            },
            cancleAdd(name,fromContentBtn) {
                this.dontUserManage = true;
                this.dialog && this.$emit("close",this.dontUserManage);
                this.coordinationList.forEach((item,ind)=>{
                    if (ind === this.editeNum && !fromContentBtn) {
                        item.acctName = ""
                        item.acctId = ""
                    }
                });
            },
            manualAdd(params,ind) {
                this.$confirm(
                    "该人员信息有误，是否手动添加权限？",
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认",
                        cancelButtonText: '取消',
                    }).then(() => {
                    this.storeInd = ind;
                    this.storeName = params.acctName;
                    delete params.roleIds;
                    this.$refs.UsersManage.handleOpenAddForm(params,this.noAllRoleList);
                    this.$refs["select" + ind][0].blur();
                }).catch(() => {
                    this.coordinationList.forEach((item,ind)=>{
                        if (ind === this.editeNum) {
                            item.acctName = ""
                            item.acctId = ""
                        }
                    });
                });
            },
            //添加协同选型角色
            addRoles(acctIdOrInfo,hr,ind,type){
                let params = {};
                if (!hr) {
                    this.personList.forEach(item=>{
                        if (item.acctId === acctIdOrInfo) {
                            params.acctId = item.acctId;
                            params.acctName = item.acctName;
                            params.mobile = item.mobile;
                            params.email = item.email;
                            // params.certNo = item.certNo;
                            params.title = item.title;
                            params.dept = item.dept;
                            params.roleIds = [];
                            item.roleIds.forEach(role=>{
                                params.roleIds.push(role.roleId);
                                params.roleIds.push("616");
                            })
                        }
                    });
                }else {
                    params = acctIdOrInfo
                }
                InterfaceService[type](
                    params,
                    (data) => {
                    let res = data.respData;
                        if (res.respCode === "0000") {
                        this.$message.success("编辑用户成功！");
                        this.getSubRole()
                    } else{
                        if(res.respCode == 'MEM0094'){
                            // 账号未激活
                            this.$alert(
                                "账号未激活",
                                {
                                    customClass: "alert-box",
                                    center: true,
                                    confirmButtonText: "知道了",
                                    callback: action => {}
                                }
                            );
                        } else if(res.respCode == 'MEM0030'){
                            // 账号冻结
                            this.$alert(
                                "账号冻结",
                                {
                                    customClass: "alert-box",
                                    center: true,
                                    confirmButtonText: "知道了",
                                    callback: action => {}
                                }
                            );
                        }else{
                            this.manualAdd(params,ind)
                        }
                    }
                },
                data => {
                    this.manualAdd(params,ind)
                },
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                });
            },
        },
        mounted(){
            if (this.selectorList.length > 0) {
                this.coordinationList = [];
                this.selectorList.forEach(item=>{
                    if (item.selectionRole === "sub" && item.custName && item.acctId) {
                        this.coordinationList.push({
                            acctName : item.custName,
                            mobile : item.mobile,
                            acctId : item.acctId,
                            optFlg : "add"
                        })
                    }
                });
                if (this.coordinationList.length === 0) {
                    this.coordinationList.push({
                        optFlg:"add",
                        acctName:"",
                        mobile:""
                    })
                }
            }
            this.getSubRole();
        },
    }
</script>

<style scoped lang="scss">
    .content {
        margin-top: 30px;
        .order-info-title {
            margin: 0 0 14px;
            padding: 0 10px;
            font-size: 14px;
            border-left: 3px solid #000;
            line-height: 12px;
            span:nth-child(1) {
                margin-right: 10px;
            }
            span:nth-child(2) {
                color: #959595;
            }
        }
        .coordination-content{
            margin: 14px 0;
            background: #f5f5f5;
            .el-col {
                padding: 14px 0 0 20px;
            }
            .el-select{
                width: 250px;
            }
            .el-col-pt14 {
                padding-top: 20px;
            }
        }
        .add{
            margin-top: 20px;
            height: 30px;
            line-height: 30px;
            border-top: 1px solid #fff;
        }
        .underline{
            text-decoration: underline;
        }
        .tips{
            line-height: 22px;
        }
    }
    .dialog-content{
        margin-top: 0;
    }
    .el-select-dropdown {
        span{
            margin-right: 10px;
        }
        span:last-child {
            margin-right: 0;
        }
    }
</style>