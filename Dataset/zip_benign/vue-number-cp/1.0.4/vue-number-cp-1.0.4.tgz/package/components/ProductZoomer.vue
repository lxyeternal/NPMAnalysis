<template>
<div :class="zoomer_box" class="zoomer-container">
    <div class="preview-box" >
        <img :src="previewImg.url"
             :data-zoom="previewLargeImg.url"
             class="responsive-image"
             draggable="false"
        />
    </div>
    <div class="control-box" v-show="false">
        <!-- <div @click="moveThumbs('left')" class="control">
          <font-awesome-icon :icon="move_button.left"></font-awesome-icon>
        </div> -->
        <div class="thumb-list">
              <img @mouseover="chooseThumb(thumb, $event)"
                  draggable="false"
                  v-show="key < options.scroll_items"
                  :key="key"
                  :src="thumb.url"
                  @click="handleChooseThumb(thumb, $event,key)"
                  v-for="(thumb, key) in thumbs"
                  class="responsive-image"
                  v-bind:style="{'boxShadow' : thumb.id === choosedThumb.id ? '0px 0px 0px 2px ' + options.choosed_thumb_border_color : ''}"
                  :class="{'choosed-thumb': thumb.id === choosedThumb.id}">


        </div>
        <!-- <div @click="moveThumbs('right')" class="control">
          <font-awesome-icon :icon="move_button.right"></font-awesome-icon>
        </div> -->
    </div>
    <div :id="pane_id" class="pane-container"></div>
</div>
</template>

<script>
import Drift from "@/assets/drift-zoom/src/js/Drift.js"

export default {
  name: "ProductZoomer",
  props: {
    baseZoomerOptions: {
      type: Object,
      default: function() {
        return {};
      }
    },
    baseImages: {
      type: Object,
      required: true,
      default: function() {
        return {};
      }
    },
    hasVr:{
      type: String,
      default: ""
    },
  },
  data() {
    return {

      previewImg: {},
      previewLargeImg: {},
      thumbs: [],
      normal_size: [],
      large_size: [],
      choosedThumb: {},
      drift: null,
      options: {
        'zoomFactor': 4,
        'pane': 'container',
        'hoverDelay': 300,
        'namespace': 'container-zoomer',
        'move_by_click':true,
        'scroll_items': 4,
        'choosed_thumb_border_color': "#ff3d00",
        'move_button_style': 'chevron'
      },
        _t:null
    };
  },
  computed: {
    zoomer_box: function() {
      return this.options.namespace + "-zoomer-box";
    },
    pane_id: function() {
      return this.options.namespace + "-pane-container";
    },
    move_button: function() {
      return this.options.move_button_style === 'chevron' ?
              {
                "left": "chevron-left",
                "right": "chevron-right"
              }
              :
              {
                "left": "angle-double-left",
                "right": "angle-double-right"
              }
    }
  },
  mounted() {
    document
      .querySelector("." + this.zoomer_box + " .thumb-list")
      .setAttribute(
        "style",
        "grid-template-columns: repeat(" +
          this.baseZoomerOptions.scroll_items +
          ", auto)"
      );
    this._t = setInterval(() => {
      if (document.readyState === "complete") {
        if (this.options.pane === "container-round") {
          this.options.inlinePane = true;
        } else {
          this.options.inlinePane = false;
          this.options.paneContainer = document.getElementById(this.pane_id);
          let rect = document
            .querySelector("." + this.zoomer_box)
              if(!rect){
                  return
              }else {
                  rect = rect.getBoundingClientRect();
              }
          let customStyle = "";
          if (this.options.pane === "pane") {
            customStyle =
              "width:" +
              rect.width * 1.2 +
              "px;height:" +
              rect.height +
              "px;left:" +
              (rect.right + window.scrollX + 5) +
              "px;top:" +
              (rect.top + window.scrollY) +
              "px;";
          } else {
            customStyle =
              "width:" +
              rect.width +
              "px;height:" +
              rect.height +
              "px;left:" +
              (rect.x + window.scrollX) +
              "px;top:" +
              (rect.top + window.scrollY) +
              "px;";
          }
          this.options.paneContainer.setAttribute("style", customStyle);
        }

        this.options.injectBaseStyles = true;
        let previewImg = "." + this.zoomer_box + ">div>img";
        this.drift = new Drift(
          document.querySelector(previewImg),
          this.options
        );
        clearInterval(this._t);
      }
    }, 500);
  },
  watch: {
    choosedThumb: function(thumb) {
      let matchNormalImg = this.normal_size.find(img => {
        return img.id === thumb.id;
      });
      let matchLargeImg = this.large_size.find(img => {
        return img.id === thumb.id;
      });
      this.previewLargeImg = Object.assign({}, matchLargeImg);
      this.previewImg = Object.assign({}, matchNormalImg);
      if (this.drift !== null) {
        this.drift.setZoomImageURL(matchLargeImg.url);
      }
    }
  },
  created() {
    // vue-product-zoom 组件ie兼容
    window.scrollX = window.scrollX || window.pageXOffset;
    window.scrollY = window.scrollY || window.pageYOffset;

    if (Object.keys(this.baseImages).length > 0) {
      for (const key in this.baseImages) {
        if (this.baseImages.hasOwnProperty(key)) {
          this[key] = this.baseImages[key];
        }
      }
    }

    if (this.normal_size.length === 0) {
      console.log("Product Zoomer Need Normal Size Image At Least!!!");
      return;
    }

    // this.hasVr = this.thumbs.some(item => {
    //     console.log(item)
    //     return item.vrFlg == "1"
    // });
    // console.log(this.hasVr)
    if (this.thumbs.length === 0) {
      this.thumbs = Object.assign([], this.normal_size);
    }
    if (this.large_size.length === 0) {
      this.large_size = Object.assign([], this.normal_size);
    }
    this.choosedThumb = this.thumbs[0];

    if (Object.keys(this.baseZoomerOptions).length > 0) {
      for (const key in this.baseZoomerOptions) {
        if (this.baseZoomerOptions.hasOwnProperty(key)) {
          const element = this.baseZoomerOptions[key];
          this.options[key] = element;
        }
      }
    }

    if (
      this.options.pane === "container-round" ||
      this.options.pane === "container"
    ) {
      this.options.hoverBoundingBox = false;
    } else {
      this.options.hoverBoundingBox = true;
      // this.options.hoverBoundingBox = false;
    }
  },
  methods: {
    moveThumbs(direction) {
      let len = this.thumbs.length;
      if (direction === "right") {
        const moveThumb = this.thumbs.splice(len - 1, 1);
        this.thumbs = [moveThumb[0], ...this.thumbs];
      } else {
        const moveThumb = this.thumbs.splice(0, 1);
        this.thumbs = [...this.thumbs, moveThumb[0]];
      }
    },
    chooseThumb(thumb, event) {
      let eventType = event.type;
      if (eventType === "mouseover") {
        if (this.options.move_by_click !== true) {
          this.choosedThumb = thumb;
        }
      } else {
        this.choosedThumb = thumb;
      }

      //this.switchVr(false)
    },
   handleChooseThumb(thumb, event,index){
      this.chooseThumb(thumb, event)
      let showvr = false
      if(index == 0 && this.hasVr){
        showvr = true
      }
      console.log(this.hasVr)
      this.$emit("switchVr",showvr)
   }
  },
    destroyed(){
      clearInterval(this._t);
    }
};
</script>

<style>
@import "../assets/drift-zoom/src/css/drift-basic.css";
.zoomer-container {
  width: 100%;
  height: 100%;
}
.preview-box {
  margin-bottom: 1vh;
}
.control {
  display: grid;
  display: inline-block;
  align-items: center;
  font-size: x-large;
  cursor: pointer;
  justify-content: center;
}
.control-box {
  display: grid;
  display: inline-block;
  grid-template-columns: 1fr auto 1fr;
  grid-column-gap: 5px;
}
.control-box .thumb-list {
  display: grid;
  grid-column-gap: 4px;
}
.choosed-thumb {
  border-radius: 0px;
}
.pane-container {
  display: none;
  position: absolute;
  z-index: 10000;
  pointer-events: none;
}
.responsive-image {
  height: auto;
  width: 100%;
  width: 50px;
}

.preview-box .responsive-image{
  width: 100%;
}
</style>
