<template>
    <div>
        <!-- 新增运费模板弹窗 -->
        <el-dialog class="dialog" title="新增运费模板" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="80%" center :close-on-click-modal="false">
            <div class="tl">
                <CreateFreight @confirm="handleAddTemplate" @cancel="handleConfirm"></CreateFreight>
            </div>
        </el-dialog>
    </div>
</template>

<script>
import CreateFreight from "@/components/freight/CreateFreight";
export default {
    components: {
        CreateFreight
    },
    data() {
        return {
            dialogVisible: false
        };
    },
    methods: {
        open() {
            this.dialogVisible = true;
        },
        handleAddTemplate(templateId){
            this.dialogVisible = false;
            this.$emit("close", templateId);
        },
        handleConfirm() {
            this.dialogVisible = false;
            this.$emit("close");
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;

    a {
        text-decoration: underline;
        color: #0082ff;
    }
}
</style>
