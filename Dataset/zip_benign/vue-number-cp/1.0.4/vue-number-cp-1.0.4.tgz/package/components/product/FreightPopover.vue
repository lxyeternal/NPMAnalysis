<template>
    <div>
        运送至
        <el-popover placement="bottom-start" :offset="-160" :visible-arrow="false" width="710" trigger="click">
            <div class="area-template clearfloat">
                <ul>
                    <li v-for="(temp,index) in templateList" :key="index" :class="{'active':temp.active,'active-height':temp.show&&temp.cityList&&temp.cityList.length}">
                        <a @click="handleSelectProv(index,temp)">{{temp.provName}}</a>
                        <div class="city-template clearfloat" v-if="temp.cityList&&temp.cityList.length" :class="{'active':temp.show}">
                            <ul>
                                <li v-for="(city,_index) in temp.cityList" :key="_index">
                                    <a @click="handleSelectCity(city,index,_index)" :class="{'active': city.active}">{{city.cityName}}</a>
                                </li>
                            </ul>
                        </div>
                    </li>
                </ul>
            </div>
            <a slot="reference" class="area-link">{{selectTemp.provName||selectTemp.cityName||'请选择'}}
                <i class="el-icon-arrow-down"></i>
            </a>
        </el-popover>
        <span v-if="selectTemp.shippingMethod=='0'">供应商自行配送：</span>
        <span v-if="selectTemp.shippingMethod=='1'">物流配送：</span>
        <span v-if="selectTemp.freeShippingFlg=='1'">免运费</span>
        <span v-if="selectTemp.freeShippingFlg=='0'" class="freight-text">
            <span v-if="selectTemp.pricingMode=='2'">按商品单价的{{parseFloat(selectTemp.freightAmt) * 100}}%计算运费</span>
            <span v-if="selectTemp.pricingMode=='1'">{{parseFloat(selectTemp.freightAmt)}}元</span>
            <span v-if="selectTemp.pricingMode=='0'">
                {{selectTemp.startVol}}{{selectTemp.goodsUnitDisp}}以内{{parseFloat(selectTemp.freightAmt)}}元，每增加{{selectTemp.increaseVol}}{{selectTemp.goodsUnitDisp}}加{{parseFloat(selectTemp.increaseFreightAmt)}}元
            </span>
        </span>
    </div>
</template>

<script>
export default {
    props: ["data", "num"],
    data() {
        return {
            selectTemp: {},
            templateList: []
        };
    },
    watch: {
        data() {
            this.templateList = this.arrangeTemplate(this.data);
        }
    },
    methods: {
        // 选择省
        handleSelectProv(index, province) {
            const arr = [];
            this.templateList.forEach((item, i) => {
                if (index == i) {
                    item.show = !item.show;
                    item.active = true;
                } else {
                    item.show = false;
                    item.active = false;
                }
                arr.push(item);
            });

            if (province.isSingleProvince) {
                this.selectTemp = province;
                arr.forEach((item, i) => {
                    if (i != index && !item.isSingleProvince) {
                        item.cityList.forEach((_item, _i) => {
                            _item.active = false;
                        });
                    }
                });
            }

            this.templateList = arr;
        },
        // 选择城市
        handleSelectCity(city, index, _index) {
            this.templateList.forEach((item, i) => {
                if(!item.isSingleProvince){
                    item.cityList.forEach((_item, _i) => {
                        if (index == i && _index == _i) {
                            _item.active = true;
                        } else {
                            _item.active = false;
                        }
                    });
                }
            });
            this.selectTemp = city;
            this.$forceUpdate();
        },
        // 整理运费模板
        arrangeTemplate(list) {
            let arr = [],
                otherProvince = "";
            const attrList = [
                "defaultFlg",
                "freeShippingFlg",
                "freeShippingFlgDisp",
                "pricingMode",
                "pricingModeDisp",
                "startVol",
                "freightAmt",
                "increaseVol",
                "increaseFreightAmt",
                "goodsUnit",
                "goodsUnitDisp",
                "shippingMethod",
                "shippingMethodDisp"
            ];
            const provinceList = [
                "北京市",
                "天津市",
                "上海市",
                "重庆市",
                "台湾省",
                "香港特别行政区",
                "澳门特别行政区"
            ];
            list.forEach(item => {
                // 指定省份
                if (item.defaultFlg == "0") {
                    if (item.destinationList && item.destinationList.length) {
                        item.destinationList.forEach(_item => {
                            if (provinceList.indexOf(_item.provName) !== -1) {
                                // 直辖市
                                _item.isSingleProvince = true;
                                attrList.forEach(attr => {
                                    _item[attr] = item[attr];
                                });
                            } else {
                                if (_item.cityList && _item.cityList.length) {
                                    _item.cityList.forEach(city => {
                                        attrList.forEach(attr => {
                                            city[attr] = item[attr];
                                        });
                                    });
                                }
                            }
                            arr.push(_item);
                        });
                    }
                } else if (item.defaultFlg == "1") {
                    otherProvince = item;
                }
            });

            if (otherProvince) {
                otherProvince.provName = arr.length ? "全国(其他)" : "全国";
                otherProvince.provCode = "0000";
                otherProvince.isSingleProvince = true;
                arr.push(otherProvince);
            }

            // 同省市城市合并
            const copyObj = {},
                result = [];
            arr.forEach(item => {
                if (!copyObj[item.provCode]) {
                    copyObj[item.provCode] = item;
                } else {
                    copyObj[item.provCode].cityList = copyObj[
                        item.provCode
                    ].cityList.concat(item.cityList);
                }
            });
            Object.keys(copyObj).forEach(key => {
                result.push(copyObj[key]);
            });

            return result;
        }
    },
    mounted() {
        this.templateList = this.arrangeTemplate(this.data);
    }
};
</script>

<style lang="scss" scoped>
.area-template {
    position: relative;
    font-size: 12px;
    li {
        float: left;
        a {
            display: block;
            margin: 0 10px;
            padding: 5px 10px;
        }

        &.active {
            color: #0082ff;
        }

        &.active-height {
            height: 120px;
        }
    }
}

.city-template {
    display: none;
    position: absolute;
    left: 0;
    right: 0;
    padding: 12px;
    border: 1px solid #ccc;
    color: #444444;
    background: #e9f3fd;

    &.active {
        display: block;
    }

    li a {
        padding: 2px 5px;
        border-radius: 3px;
    }
    a.active {
        color: #ffffff;
        background: #0082ff;
    }
}

.area-link {
    display: inline-block;
    margin-left: 5px;
    padding: 2px 5px;
    border: 1px solid #ffffff;
    line-height: 20px;

    &:hover {
        border-color: #ccc;
        background: #f5f5f5;
        i {
            color: #0082ff;
        }
    }
}

.freight-text{
    max-width: 200px;
    display: inline-block;
    vertical-align: text-top;
    line-height: 15px;
}
</style>

