<template>
  <div>
    <!-- 运费模板 -->
    <el-dialog class="dialog freightPopoverDialog" title="商品运费" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false">
      <div class="center">
        <table>
          <thead>
            <tr>
              <th width="400">配送地址</th>
              <th width="200" class="tr">不含税单价(元)</th>
              <th width="200" class="tr">商品单位</th>
            </tr>
          </thead>
        </table>
        <div class="table-body">
          <table>
            <tbody>
              <tr v-for="(item, idx) in dataList" :key="idx">
                <td width="400">
                  {{cityAddressCp(item)}}
                </td>
                <td width="200" class="tr">
                  {{item.freightAmt | formatMoney}}
                </td>
                <td width="200" class="tr">
                  {{item.goodsUnit}}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      dialogVisible: false,
      dataList: []
    };
  },
  computed: {
    cityAddressCp() {
      return data => {
        let addressName = ''
        const destination = data && data.destinationList && data.destinationList[0] || {}
        addressName = destination.provName
        if (destination.cityList) {
          const city = destination.cityList[0] || {}
          addressName += city.cityName ? ` - ${city.cityName || ''}` : ''
        }

        return addressName
      }
    },
  },
  methods: {
    open(data) {
      this.dialogVisible = true
      this.dataList = data.filter(f => f.destinationList && f.destinationList[0] && f.destinationList[0].provName) || []
    },
    handleConfirm() {
      this.dialogVisible = false
      this.$emit('close', true)
    }
  }
};
</script>

<style lang="scss" scoped>
.dialog {
  line-height: 25px;

  a {
    text-decoration: underline;
    color: #0082ff;
  }
  &.freightPopoverDialog {
    .table-body {
      max-height: 390px;
      overflow: auto;
    }
    .tr {
      text-align: right;
    }
    table {
      td,
      th {
        padding: 2px 12px;
        border-bottom: 1px solid #eaeaea;
        font-size: 14px;
      }
      th {
        background: #f9f9f9;
        color: #333;
        text-align: left;
      }
      td {
        color: #666;
        font-size: 12px;
      }
    }
  }
}
</style>
