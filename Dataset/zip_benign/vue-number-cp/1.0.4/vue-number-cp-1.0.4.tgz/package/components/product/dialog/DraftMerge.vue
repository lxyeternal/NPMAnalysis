<template>
    <div>
        <!-- 清单草稿覆盖 -->
        <el-dialog class="dialog" :title="mergeTitle || '清单草稿命名重复，是否覆盖？'" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false">
            <div class="tl">
                <p>您编辑的清单草稿名称，在清单草稿箱中有重复命名草稿，请确认是否要覆盖之前草稿？</p>
                <table class="table">
                    <tbody>
                        <tr v-for="(row,index) in draftList" :key="index">
                            <td width="300">{{row.draftName}}</td>
                            <td>创建时间：{{row.draftCreateTime}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">覆盖</el-button>
                <el-button type="primary" size="small" style="width: 100px" @click="handleCancel">取消</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
export default {
    props: ['mergeTitle'],
    data() {
        return {
            dialogVisible: false,
            draftList: []
        };
    },
    methods: {
        open(data = []) {
            this.draftList = data;
            this.dialogVisible = true;
        },
        handleConfirm() {
            this.dialogVisible = false;
            this.$emit("close", true);
        },
        handleCancel() {
            this.dialogVisible = false;
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;

    a {
        text-decoration: underline;
        color: #0082ff;
    }
}

.table {
    width: 100%;
    td {
        padding: 20px;
    }
}
</style>
