<template>
    <div>
        <!-- 上架信息弹窗 -->
        <el-dialog class="dialog" title="上架申请已接收" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="50%" center :close-on-click-modal="false">
            <div>您的上架申请，审核人员已收到，审核人员会尽快完成审核工作。审核通过后，商品直接上架展示。上架商品，请在
                <router-link to="/vendorCenter/productListOnline">【管理中心】-【商品管理】-【已上架商品】</router-link>中查看。审核中及未通过审核的商品， 请在
                <router-link to="/vendorCenter/productListOnline">【管理中心】-【商品管理】-【已下架商品】</router-link>中查看。
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确定</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
        return {
            dialogVisible: false
        };
    },
    methods: {
        open() {
            this.dialogVisible = true;
        },
        handleConfirm() {
            this.dialogVisible = false;
            this.$emit('close',true);
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;

    a {
        text-decoration: underline;
        color: #0082ff;
    }
}
</style>
