<template>
    <div>
        <!-- 保存信息弹窗 -->
        <el-dialog class="dialog" title="已全部保存成功" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="50%" center :close-on-click-modal="false">
            <div class="tc">您编辑的该商品信息已全部保存，您可继续编辑该商品信息；若您关闭此创建商品页面，请在
                <router-link to="/vendorCenter/productListOffline">【管理中心】-【商品管理】-【已下架商品】</router-link>中查看
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确定</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
        return {
            dialogVisible: false
        };
    },
    methods: {
        open() {
            this.dialogVisible = true;
        },
        handleConfirm() {
            this.dialogVisible = false;
            this.$emit('close',true);
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;

    a {
        text-decoration: underline;
        color: #0082ff;
    }
}
</style>
