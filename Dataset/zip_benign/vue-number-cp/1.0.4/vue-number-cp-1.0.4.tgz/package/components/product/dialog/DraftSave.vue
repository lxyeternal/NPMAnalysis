<template>
    <div>
        <!-- 保存清单草稿 -->
        <el-dialog class="dialog" title="保存清单草稿" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false">
            <div class="tl">
                <el-form ref="form" :model="form" :rules="rules" label-width="120px">
                    <el-form-item label="设置草稿名称：" prop="draftName">
                        <el-input v-model="form.draftName" :maxlength="20" placeholder="输入草稿名称，限20字"></el-input>
                        <el-button type="text" @click="handleClear">清除</el-button>
                    </el-form-item>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确定</el-button>
                <el-button type="primary" size="small" style="width: 100px" @click="handleCancel">取消</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
const form = {
    draftName: ""
};

export default {
    data() {
        return {
            dialogVisible: false,
            form: Object.assign(form),
            rules: {
                draftName: [
                    {
                        required: true,
                        message: "请输入草稿名称",
                        trigger: "blur"
                    }
                ]
            }
        };
    },
    methods: {
        open(data = {}) {
            this.form = Object.assign(this.form, data);
            this.dialogVisible = true;
        },
        handleClear() {
            this.form.draftName = "";
        },
        handleConfirm() {
            this.$refs["form"].validate(valid => {
                if (valid) {
                    this.dialogVisible = false;
                    this.$emit("close", this.form);
                }
            });
        },
        handleCancel() {
            this.dialogVisible = false;
        }
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-input {
    width: 400px;
}

.dialog {
    line-height: 25px;

    a {
        text-decoration: underline;
        color: #0082ff;
    }
}
</style>
