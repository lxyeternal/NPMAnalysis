<template>
  <div class="agreement">
    <h6>电商平台会员管理暂行办法</h6>
    <p class="title">第一章 总则</p>
    <p class="content"><i class="bold">第一条</i> 为加强会员的管理，保障会员的合法权益，规范会员在绿地大家采电商平台（以下简称“平台”）的规范合作、高效运转，防范运营风险，最大限度地实现会员和平台的利益，特制定本办法。</p>
    <p class="content"><i class="bold">第二条</i> 会员是指经平台审核批准，有权在平台从事与电商交易相关的业务法人或其他经济组织。</p>
    <p class="content"><i class="bold">第三条</i> 会员及其授权代表从事与电商交易相关的业务，必须遵守国家相关法律法规及本办法。</p>
    <p class="title">第二章 会员种类 </p>
    <p class="content"><i class="bold">第四条</i> 会员分为供应商会员和采购商会员。</p>
    <p class="content"><i class="bold">第五条</i> 供应商会员是指在中国大陆合法注册的企业单位，经营范围包含建筑材料、设备设施制造、销售、批发零售，与房地产开发、承包施工、室内外装修装饰工程等相关行业的业务或可提供的有关证明。</p>
    <p class="content"><i class="bold">第六条</i> 采购商会员是指在中国大陆合法注册的企业单位，有明确的采购需求，并且所需采购的产品符合国家标准的产品范围。采购商对采购需求具有决策权或执行权。</p>
    <p class="content"><i class="bold">第七条</i> 通过平台审核后，会员可在平台从事商品销售、采购活动，会员在未通过平台资质审核前，不得从事获得审核后方可从事的业务。</p>
    <p class="title">第三章 会员资质的申请</p>
    <p class="content"><i class="bold">第八条</i> 符合下列条件的申请企业经审核通过后，可成为供应商会员：</p>
    <p class="content">（一）中华人民共和国境内注册登记；</p>
    <p class="content">（二）具有良好的信誉与经营历史，近三年内无重大违法、失信行为记录；</p>
    <p class="content">（三）所提供的证件有单位盖公章，并在有效期内。</p>
    <p class="content"><i class="bold">第九条</i> 申请成为供应商会员应该向平台提交下列会员资格申请书面材料：</p>
    <p class="content">（一）经法人或法人授权联系人签署的《电商平台供应商入会申请》；</p>
    <p class="content">（二）“三证合一”证照复印件（盖公章），如未完成“三证合一”业务办理的，可分别提交工商营业执照、组织机构代码证和税务登记证复印件（盖章）；</p>
    <p class="content">（三）法定代表人及授权联络人身份证复印件（需签名、盖章）；</p>
    <p class="content">（四）授权委托书（需签名、盖章）。</p>
    <p class="content"><i class="bold">第十条</i> 符合下列条件的申请企业经审核通过后，可成为采购商会员：</p>
    <p class="content">（一）中华人民共和国境内注册登记；</p>
    <p class="content">（二）有明确的采购需求，并且所需采购的产品符合国家标准的产品范围。采购商对采购需求具有决策权或执行权；</p>
    <p class="content">（三）具有良好的信誉与经营历史，且持续经营，近三年内无重大违法、失信行为记录；</p>
    <p class="content">（四）所提供的证件有单位盖公章，并在有效期内。</p>
    <p class="content"><i class="bold">第十一条</i> 申请成为采购商会员应该向平台提交下列会员资格申请书面材料：</p>
    <p class="content">（一）经法人或法人授权联系人签署的《电商平台采购商入会申请》；</p>
    <p class="content">（二）“三证合一”证照复印件（盖公章），如未完成“三证合一”业务办理的，可分别提交工商营业执照、组织机构代码证和税务登记证复印件（盖公章）；</p>
    <p class="content">（三）法定代表人及授权联络人身份证复印件（需签名、盖章）；</p>
    <p class="content">（四）授权委托书（需签名、盖章）。</p>
    <p class="content"><i class="bold">第十二条</i> 平台收到符合要求的会员资格书面申请材料后， 于三个工作日内完成资料审核。</p>
    <p class="title">第四章 会员资格的变更、转让及终止</p>
    <p class="content"><i class="bold">第十三条</i> 会员不得转让、出租其会员资格或以任何方式将会员相关业务委托给他人管理或承包给他人经营。</p>
    <p class="content"><i class="bold">第十四条</i> 会员申请变更或增加会员种类的，应当符合本办法规定的相应会员资格的条件，并向平台提交书面申请及相应的申请材料。</p>
    <p class="content"><i class="bold">第十五条</i> 同一总公司名下的多个分公司（包括不限于代理商、经销商等）申请会员资格的，各个分公司（包括不限于代理商、经销商等）应分别提供总公司的授权书及相应会员资格申请材料，平台逐个进行审核认定。</p>
    <p class="content"><i class="bold">第十六条</i> 会员不再符合平台所规定的会员资格条件时，平台有权自主决定取消其会员资格。</p>
    <p class="content"><i class="bold">第十七条</i> 供应商会员有义务向平台提供商品信息、及时安排发货、处理商品质量问题等，如供应商会员拒不配合，平台有权自主决定取消其会员资格。</p>
    <p class="content"><i class="bold">第十八条</i> 会员资格发生变更或终止时，会员在其资格存续期间发生的交易或行为不受影响。会员资格发生变更或终止后，任何人以该会员名义从事的任何行为的一切责任均由其自行承担。</p>
    <p class="title">第五章 会员管理</p>
    <p class="content"><i class="bold">第十九条</i> 发生下列情况之一的，影响平台或其他相关会员正常经营或在平台进行交易的情况的，会员应当立即向平台提供书面报告，并持续报告进展情况：</p>
    <p class="content">（一）重大业务风险；</p>
    <p class="content">（二）不可抗力事件；</p>
    <p class="content">（三）可能影响平台正常经营的情况；</p>
    <p class="content">（四）可能影响平台其他相关会员正常经营或在平台进行交易的情况。</p>
    <p class="content"><i class="bold">第二十条</i> 会员有下列情况之一的，应当在五个工作日内向平台提交以下书面报告：</p>
    <p class="content">（一）变更法定代表人；</p>
    <p class="content">（二）变更注册资本或股权结构；</p>
    <p class="content">（三）变更名称、住所或营业场所、经营范围及联系方式；</p>
    <p class="content">（四）设立、合并或者终止分支机构；</p>
    <p class="content">（五）变更分支结构的营业场所、负责人或者经营范围；</p>
    <p class="content">（六）经营状况发生重大变化；</p>
    <p class="content">（七）发生重大诉讼案件或经济纠纷；</p>
    <p class="content">（八）因涉嫌违法、违规受到相关机关立案调查、处罚。</p>
    <p class="content"><i class="bold">第二十一条</i> 平台会员有效期为一年，如到期后未发生以下情形的，无需重新提交会员申请，视为自动续期，有效期为一年。</p>
    <p class="content">（一）会员未主动提出终止会员资格的；</p>
    <p class="content">（二）会员有效期内未发生取消其会员资格的；</p>
    <p class="title">第六章 会员评级制度</p>
    <p class="content"><i class="bold">第二十二条</i> 平台暂不实行会员分级管理，不同的会员享受相同的会员福利。后续若有会员平级制度，平台将在网站予以公告。</p>
    <p class="title">第七章 会员收费标准</p>
    <p class="content"><i class="bold">第二十三条</i> 平台暂不收取供应商及采购商会员入会费。后续若需收取相关费用的，平台将在网站予以公告。</p>
    <p class="title">第八章 会员监督管理</p>
    <p class="content"><i class="bold">第二十四条</i> 平台对会员进行监督、管理，定期或不定期对会员执行的各项交易进行检查，对违反规定的会员进行相应的处罚。</p>
    <p class="content"><i class="bold">第二十五条</i> 出现以下行为1次，平台暂停合作6个月；合同期内累计出现2 次，平台暂停合作1年。</p>
    <p class="content">（一）因供应商原因造成供货或工期严重延误；</p>
    <p class="content">（二）供应商产品出现质量问题，严重影响观感或使用，引发采购商投诉。</p>
    <p class="content">（三）其他违反《货物采购合同》的违约行为。</p>
    <p class="content"><i class="bold">第二十六条</i> 出现以下行为1次，平台暂停合作2年。</p>
    <p class="content">（一）供应商会员或采购商会员出现商业贿赂的行为；</p>
    <p class="content">（二）因供应商原因影响采购商项目交付，造成实质性交付延期；</p>
    <p class="content">（三）供应商交付产品与合同不符，或存在以次充好未达到合同约定标准的情况；</p>
    <p class="content">（四）供应商出现产品严重质量问题或质量事故，给采购商造成经济损失及声誉负面影响；</p>
    <p class="content">（五）供应商会员或采购商会员单方面毁约。</p>
    <p class="content">（六）其他违反《货物采购合同》的违约行为。</p>
    <p class="content"><i class="bold">第二十七条</i> 平台有权将会员处罚情况在网站上进行公告。</p>
    <p class="title">第九章 附则</p>
    <p class="content"><i class="bold">第二十八条</i> 本办法由上海绿地建筑材料集团有限公司制定，最终解释权归上海绿地建筑材料集团有限公司所有。</p>
    <p class="content"><i class="bold">第二十九条</i> 本办法于2020年06月30日生效后执行。</p>

  </div>
</template>

<script>
// import $ from 'jquery'
export default {
  props: {

  },
  watch: {

  },
  data() {
    return {

    }
  },
  methods: {},
  mounted() {
  }
}
</script>

<style scoped>
.agreement {
  padding-right: 10px;
}
h6 {
  text-align: center;
  font-size: 16px;
  font-weight: bold;
}
.title {
  text-align: center;
  padding-top: 20px;
  color: #333;
  font-weight: bold;
}
</style>
