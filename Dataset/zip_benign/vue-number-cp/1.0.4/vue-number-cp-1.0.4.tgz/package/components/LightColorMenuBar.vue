<template>
  <div class="app-nav-bar">
    <div class="nav-bar-container inner-container">
      <ul class="nav-bar-bd f16" ref="ul">
        <li style="position: absolute;left: 60px;" @click="changeNavBar('')" :class="{'active':currentRouter ===''}">
          <span class="li-item" :class="{'active':currentRouter ===''}">
            <img class="itemize-icon" src="../assets/images/icon/itemize_active.png" height="25" style="display:inline-block;">
            全部商品分类
          </span>
        </li>
        <li style="margin-left: 290px" :class="{'active':currentRouter ==='biddingAnnouncement'}">
          <span class="li-item" :class="{'active':currentRouter ==='biddingAnnouncement' || currentRouter ==='bidWinningAnnouncement'}">
            招采信息
            <span class="second-menu-item">
              <em @click="changeNavBar('biddingAnnouncement')">招标公告</em>
              <em @click="changeNavBar('bidWinningAnnouncement')">中标公示</em>
            </span>
          </span>
        </li>
        <li>
          <span class="li-item">
          行家精选
            <span class="second-menu-item">
              <em @click="handleGoHotProd">爆款产品</em>
              <em>绿色新材</em>
            </span>
          </span>
        </li>
        <!-- <li> <span class="li-item">B2C采购</span></li> -->
        <!-- <li><span class="li-item" :class="{'active':currentRouter=='partner'}">金融服务</span></li> -->
        <!-- <li><span class="li-item" :class="{'active':currentRouter=='helpCenter'}">我要合作</span></li> -->
        <li><span class="li-item" :class="{'active':currentRouter=='helpCenter'}" @click="$router.push('/helpCenter')">帮助中心</span></li>
      </ul>
    </div>
  </div>
</template>

<script>

const projectList = [
  {
    province: '广西',
    link: 'http://www.greenlandhk.com/pages/gb/cityNN.html',
  },
  {
    province: '云南',
    link: 'http://www.greenlandhk.com/pages/gb/cityKM.html'
  },
  {
    province: '江苏',
    citys: [
      { city: '常熟', link: 'http://www.greenlandhk.com/pages/gb/cityCS.html' },
      // { city: '徐州', link: '' },
      { city: '无锡', link: 'http://www.greenlandhk.com/pages/gb/cityWX.html' },
    ]
  },
  {
    province: '苏州',
    link: 'http://www.greenlandhk.com/pages/gb/citySZ.html'
  },
  {
    province: '上海',
    link: 'http://www.greenlandhk.com/pages/gb/citySH.html'
  },
  {
    province: '浙江',
    link: 'http://www.greenlandhk.com/pages/gb/cityNB.html'
  },
  {
    province: '海南',
    link: 'http://www.greenlandhk.com/pages/gb/cityHK.html'
  },
  {
    province: '黄山',
    link: 'http://www.greenlandhk.com/pages/gb/cityHS.html'
  },
  {
    province: '太原',
    link: 'http://www.greenlandhk.com/pages/gb/cityTY.html'
  }
]

export default {
  props: {
    currentRouter: {
      type: String,
      default: '' //这样可以指定默认的值
    }
  },
  data() {
    return {
      snow1: false,
      snow2: false,
      snow3: false,
      snow4: false,
      snow5: false,
      projectList: this.$clone(projectList)
    }
  },
  computed: {

  },
  methods: {
    changeNavBar(type, newWindow) {
      if (newWindow) {
        const routeData = this.$router.resolve({
          path: `/${type}`
        });
        window.open(routeData.href, "_blank");
        return
      } else {

        this.$router.push('/' + type)
      }
    },
      handleGoProject() {
          window.open("http://www.greenlandhk.com/post?id=33", "_blank");
      },
    handleGoHotProd() {
      const { href } = this.$router.resolve({
        path:"/hotProductView",
      });
      window.open(href, '_blank');
    }
  },
  mounted: function () {

  }
}
</script>
<style lang="scss" scoped>
.project-intro {
  background-image: url("../assets/images/home/191119/star.png");
  background-repeat: no-repeat;
  background-position: 93px 5px;
  &:hover {
    background-image: url("../assets/images/home/191119/star_active.png");
  }
}
.nav-bar-bd{
  text-align: left;
}
.project-content {
  width: 1190px;
  margin: auto;
  padding-bottom: 10px;
}
.project-item {
  float: left;
  height: 70px;
  width: 20%;
  padding: 15px;
  text-align: left;

  p {
    font-size: 15px;
    color: #000;
  }

  a:hover {
    color: #409eff;
  }

  .project-city {
    margin-right: 20px;
    font-size: 12px;
    line-height: 35px;
    color: #909399;
  }
}
.lh21 {
  line-height: 21px;
}
</style>