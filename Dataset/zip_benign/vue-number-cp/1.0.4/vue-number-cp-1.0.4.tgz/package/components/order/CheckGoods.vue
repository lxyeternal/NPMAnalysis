<template>
    <div>
        <Header :is-white-bg="false"></Header>
        <div class="app-search-bar isWhiteBg">
            <div class="search-bar-container inner-container" style="position: relative;">
                <div class="index-logo">
                    <div class="logo">
                        <h1>
                            <a @click="go('/home')" class="logo-bd"></a>
                        </h1>
                    </div>
                </div>
                <ViceHeader :title="title" :flow="flow"></ViceHeader>

                <div class="order-process-top">
                    <template v-if="userinfo.contractCorpType ==='construction'">
                        <label class="order-process-label" :class="{'active':item.active,'end':index===buildProcess.length-1}" v-for="(item,index) in buildProcess" :key="index" v-if="index!==0">{{item.label}}</label>
                    </template>
                    <template v-if="userinfo.contractCorpType ==='supervisory'">
                        <label class="order-process-label" :class="{'active':item.active,'end':index===supervisoryProcess.length-1}" v-for="(item,index) in supervisoryProcess" :key="index" v-if="index!==0">{{item.label}}</label>
                    </template>
                    <template v-if="!specialRole && role ==='B'">
                        <label class="order-process-label" :class="{'active':item.active,'end':index===bProcess.length-1}" v-for="(item,index) in bProcess" :key="index" v-if="index!==0">{{item.label}}</label>
                    </template>
                    <template v-if="!specialRole && role ==='S'">
                        <label class="order-process-label" :class="{'active':item.active,'end':index===sProcess.length-1}" v-for="(item,index) in sProcess" :key="index" v-if="index!==0">{{item.label}}</label>
                    </template>
                </div>
            </div>
        </div>
        <div class="inner-container">
            <!-- 验收单基本信息 -->
            <div class="order-info">

                <div v-if="type=='confirm'">
                    <div class="order-info-header">
                        <PanelTitle title="当前签署情况"></PanelTitle>
                        <a class="link" @click="handleViewCheckOrder">《工地验收单》</a>
                    </div>



                    <SignProcessRequire type="2" :order="orderInfo"></SignProcessRequire>
                </div>

                <PanelTitle title="验收单基本信息" class="order-data-message"></PanelTitle>
                <el-row>
                    <el-col :span="8">
                        <p>
                            <label>对方发货通知单编号：</label>
                            <span>{{orderInfo.requireNo}}</span>
                        </p>
                        <p>
                            <label>发货通知单日期：</label>
                            <span>{{orderInfo.tradeTime|datetime}}</span>
                        </p>
                        <p v-if="role=='S'">
                            <label>采购商：</label>{{orderInfo.purchaserName}}</p>
                        <p v-if="role=='B'">
                            <label>供应商：</label>{{orderInfo.supplierName}}</p>
                        <p>
                            <label>收货(要料)单位：</label>
                            <span>{{userinfo.corpName}}</span>
                        </p>
                        <p>
                            <label>所属城市公司：</label>
                            <span>{{orderInfo.cityCompany}}</span>
                        </p>
                    </el-col>
                    <el-col :span="8">
                        <p>
                            <label>合同编号：</label>
                            <span>{{orderInfo.orderNo}}</span>
                        </p>
                        <p>
                            <label>合同名称：</label>
                            <span>《{{orderInfo.contractName}}》</span>
                        </p>
                        <p>
                            <label>项目分期：</label>
                            <span>{{orderInfo.projectTerm}}</span>
                        </p>
                        <p>
                            <label>所属城市：</label>
                            <span>{{orderInfo.provCodeDisp}}&nbsp;{{orderInfo.cityCodeDisp}}</span>
                        </p>
                    </el-col>
                    <el-col :span="8">
                        <p v-for="(item,index) in filterRole(orderInfo.contractStakeHolders)" :key="index">
                            <label>{{item.roleName}}：</label>
                            <span>{{item.acctName}}&nbsp;
                                <template v-if="item.mobile">(Tel:{{item.mobile}})</template>
                            </span>
                        </p>
                    </el-col>
                </el-row>
            </div>
            <!-- 联系地址 -->
            <div>
                <PanelTitle title="各方联系地址" class="select-adddress"></PanelTitle>
                <div class="order-address">
                    <p>
                        <label>供&nbsp;&nbsp;应&nbsp;方：</label>
                        <label style="margin-right: 20px;">{{orderInfo.supplierName}}</label>
                        <label>{{orderInfo.supplierCorpAddr}}</label>
                    </p>
                    <p>
                        <label>项目公司：</label>
                        <label style="margin-right: 20px;">{{orderInfo.purchaserName}}</label>
                        <label>{{orderInfo.purchaserCorpAddr}}</label>
                    </p>
                    <p>
                        <label>收货地址：</label>
                        <label>{{orderInfo.consigneeAddr}}</label>
                    </p>
                </div>
            </div>
            <!-- 要货单清单 -->
            <div class="order-list">
                <PanelTitle title="要货单清单" class="require-list"></PanelTitle>
                <div class="table">
                    <table>
                        <thead>
                            <tr>
                                <td v-if="type==='create'" width="50"></td>
                                <td width="260">商品名/型号</td>
                                <td>使用标段或部位</td>
                                <td>本批次供货数量</td>
                                <td>累计已供货量(含本次)</td>
                                <td width="200">本次实收数量</td>
                                <td width="210">验收情况</td>
                                <!-- <td v-if="type==='create'" width="80"></td> -->
                            </tr>
                        </thead>
                        <tbody v-if="requireList.length">
                            <tr v-for="(row,index) in requireList" :key="index">
                                <td v-if="type==='create'">
                                    <el-checkbox v-model="row.checked" @change="handleSelectRow(row,index)"></el-checkbox>
                                </td>
                                <td>
                                    <div class="order-name">
                                        <div class="left">
                                            <img :src="row.picUrl" v-error-img>
                                        </div>
                                        <div class="right">
                                            <p>
                                                <router-link :to="{path:'/productDetail',query:{id:row.spuId}}">{{ row.skuName }}</router-link>
                                            </p>
                                            <p>型号：{{row.model}}</p>
                                        </div>
                                    </div>
                                </td>
                                <td>{{row.location}}</td>
                                <td>{{+row.thisTimeCnt}}{{(row.goodsUnit||'')}}</td>
                                <td>{{+row.totalCnt}}{{(row.goodsUnit||'')}}</td>
                                <td class="require-goods-num">
                                    <!--<InputNumber v-if="!row.confirm" :value="+row.receiveCnt" :min='0' :max="+row.thisTimeCnt" @change="handleChangeCount($event,row)"></InputNumber><em>{{+row.receiveCnt}}</em>-->
                                    <template v-if="!row.confirm">
                                        <span class="cut" :class="{'grey':row.receiveCnt == 0}" @click.stop="cutNum(index)">-</span>
                                        <input type="number" v-input-number @blur="ctrlNum(index,row.receiveCnt)" v-model="row.receiveCnt" name="" maxlength="14">
                                        <span :class="{'grey':row.thisTimeCnt == row.receiveCnt}" class="add" @click.stop="addNum(index)">+</span>
                                    </template>
                                    <span v-if="row.confirm">{{+row.receiveCnt}}</span>
                                </td>
                                <td>
                                    <el-input v-if="!row.confirm" v-model="row.checkDescription" placeholder="请输入验收情况" :maxlength="20"></el-input>
                                    <span v-if="row.confirm">{{row.checkDescription}}</span>
                                </td>
                                <!-- <td v-if="type==='create'">
                                    <a v-if="!row.confirm" class="pointer" @click="handleConfirm(row,index,true)">确认</a>
                                    <a v-if="row.confirm" class="pointer" @click="handleConfirm(row,index,false)">编辑</a>
                                </td> -->
                            </tr>
                        </tbody>
                    </table>
                    <div class="table-pagination" v-if="requireList.length">
                        <el-pagination  @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                        </el-pagination>
                    </div>
                </div>
                <div v-if="type==='create'" class="all-opt">
                    <el-checkbox v-model="allCheck" @change="handleAllCheck"></el-checkbox>&nbsp;当页全选
                    <el-input v-model="reciveText" :maxlength="20" placeholder="勾选货品，在此输入需要批量标注的验收情况，限20个字符"></el-input>
                    <el-button type="primary" @click="handleBatchReciveText">批量填写验收情况</el-button>
                    <!-- <el-button type="primary" @click="handleBatchConfirm">批量确认</el-button> -->
                </div>
            </div>

            <div class="tr order-sign">
                <!-- <p v-if="type==='confirm'" class="fl order-process">签署情况查看
                    <a class="link" @click="handleViewCheckOrder">《工地验收单》</a>
                </p> -->

                <!-- <span v-if="role=='B' && type==='confirm'" style="margin-right: 20px;">
                    <a class="link" @click="handleEditCheckGoods">编辑签收单</a>
                </span> -->
                <el-button v-if="type!=='create'&&checkEventRole()==='unfinish'" class="btn-bottom" type="primary" size="large" @click="handleSign">电子签章</el-button>
                <template v-if="type==='create'">
                    <a v-if="role=='B'" class="link btn-bottom" style="margin-right: 20px" @click="handleSave">保存签收单</a>
                    <el-button v-if="role=='B'" class="btn-bottom" type="primary" size="large" @click="handleSubmit">提交签收单</el-button>
                </template>
            </div>
        </div>

        <!-- 签章 -->
        <SignatureDialog ref="signatureDialog" @close="handleCloseSignature"></SignatureDialog>

        <!-- 提交签收单 -->
        <SignRecipt ref="signRecipt" @close="handleCloseSignRecipt"></SignRecipt>

        <Page-nav :navigation="navigation" v-if="showPageNav" :change="0"></Page-nav>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>
<script>
import accountMixin from '@/mixins/account';
import Header from "@/components/base/Header";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import PageNav from "@/components/order/PageNav";
import ViceHeader from "@/components/base/ViceHeader";
import InputNumber from "@/components/base/InputNumber";
import SignatureDialog from "@/components/order/dialog/Signature";
import SignRecipt from "@/components/order/dialog/SignRecipt";
import SignProcessRequire from "@/components/order/SignProcessRequire";
import { InterfaceService } from "@/services/api";
import { filterEventByAcct } from '@/utils/orderUtil';

const buildProcess = [
    { label: "创建要货单", active: true },
    { label: "施工单位项目经理签字", active: false, role: "01" },
    { label: "施工单位盖章", active: false, role: "02" }
];
const supervisoryProcess = [
    { label: "创建要货单", active: true },
    { label: "监理单位授权代表签字", active: false, role: "10" },
    { label: "监理单位盖章", active: false, role: "11" }
];
const bProcess = [
    { label: "创建要货单", active: true },
    { label: "城市公司授权代表签字", active: false, role: "21" },
    { label: "城市公司项目部盖章", active: false, role: "25" }
];
const sProcess = [
    { label: "创建要货单", active: true },
    { label: "供应方授权代表签字", active: false, role: "30" },
    { label: "供应方盖章", active: false, role: "33" }
];
export default {
    mixins:[accountMixin],
    components: {
        Header,
        Loading,
        PanelTitle,
        PageNav,
        ViceHeader,
        InputNumber,
        SignatureDialog,
        SignRecipt,
        SignProcessRequire
    },
    props: ["type"], // 'create' or 'confirm'
    data() {
        return {
            isLoading: false,
            allCheck: false,
            reciveText: "",
            requireNo: "",
            orderInfo: {},
            requireList: [],
            comfirmRequireList: [],
            flow: [
                {
                    name: "创建签收单",
                    active: false,
                    next: true
                },
                {
                    name: "确认并签章",
                    active: false,
                    next: true
                },
                {
                    name: "签收成功",
                    active: false,
                    next: false
                }
            ],
            showPageNav: false,
            navigation: [
                {
                    name: "验收单基本信息",
                    position: "order-data-message"
                },
                {
                    name: "各方联系地址",
                    position: "select-adddress"
                },
                {
                    name: "要货清单",
                    position: "require-list"
                }
            ],
            buildProcess: buildProcess,
            supervisoryProcess: supervisoryProcess,
            bProcess: bProcess,
            sProcess: sProcess,
            eventList: [],
            deliveryList: [],
            attach: {},
            pageSize:1,
            total:0,
            pageIndex:1,
        };
    },
    computed: {
        title() {
            let str = this.type === "create" ? "创建验收单" : "验收要货单";
            str += " - 第" + (this.orderInfo.requireBatchNo || "") + "批";
            return str;
        }
    },
    methods: {
        // 过滤角色
        filterRole(list = []) {
            const roles = ["00", "10", "21", "30"];
            return list.filter(item => {
                return roles.indexOf(item.role) !== -1;
            });
        },
        // 查看验收单
        handleViewCheckOrder() {
            let link = "";
            const events = this.orderInfo.eventList || [];
            events.forEach(ev => {
                if (ev.eventType == 2 && ev.attachUrl) {
                    link = ev.attachUrl;
                }
            });

            if (link) {
                window.open(link, "_blank");
            } else {
                this.$message.error("暂无工地验收单信息");
            }
        },
        handleSelectRow(item, index) {
            this.$set(this.requireList, index, item);
            this.checkAllSelect();
        },
        //分页跳转
        handleCurrentChange(page) {
            this.pageIndex = page;
            this.recordOrder();
            this.getSignReciptDetail();
            // window.scrollTo(0,0)
        },
        recordOrder(){
            this.requireList.forEach(_item=>{
                let onOff = false;
                this.comfirmRequireList.forEach(item=>{
                    if (item.requireDetailId == _item.requireDetailId) {
                        item.receiveCnt = _item.receiveCnt;
                        item.receiveCount = _item.receiveCount;
                        item.requireDetailId = _item.requireDetailId;
                        item.checkDescription = _item.checkDescription;
                        item.confirm = _item.confirm
                        onOff = true
                    }
                });
                if (!onOff) {
                    this.comfirmRequireList.push(_item)
                }
            });
            // console.log(this.comfirmRequireList);
            console.log(this.requireList);
        },
        // 是否全选
        checkAllSelect() {
            this.allCheck = this.requireList.every(item => {
                return item.checked;
            });
        },
        // 全选
        handleAllCheck() {
            this.requireList.forEach((item, index) => {
                item.checked = this.allCheck;
                this.$set(this.requireList, index, item);
            });
        },
        handleChangeCount(val, item) {
            item.receiveCnt = val;
        },
        handleConfirm(item, index, bool) {
            if (bool && item.receiveCnt < 0) {
                this.$message.error("请输入本次实收数量");
                return;
            }
            item.confirm = bool;
            this.$set(this.requireList, index, item);
        },
        // 批量填写情况
        handleBatchReciveText() {
            let hasOne = false;
            this.requireList.forEach((item, index) => {
                if (item.checked) {
                    hasOne = true;
                    item.checkDescription = this.reciveText;
                }
                this.$set(this.requireList, index, item);
            });
            if (!hasOne) {
                this.$message.info("请选择商品");
            }
        },
        cutNum(res) {
            this.requireList.forEach((item, index) => {
                // if( index == res && item.requireLeft != 0 ){
                if (index == res) {
                    item.receiveCnt--;
                    if (item.receiveCnt < 0) {
                        item.receiveCnt = 0
                    }
                }
                this.$set(this.requireList, index, item);
            })
        },
        addNum(res) {
            this.requireList.forEach((item, index) => {
                if (index == res) {
                    item.receiveCnt++;
                    if (item.receiveCnt >= item.thisTimeCnt) {
                        item.receiveCnt = item.thisTimeCnt
                    }
                    this.$set(this.requireList, index, item);
                }
                // if( index == res && item.requireLeft != 0 ){
                //   item.num++;
                //   if( item.num > item.requireLeft ){
                //     item.num  = item.requireLeft
                //   }
                // }
                this.$set(this.requireList, index, item);
            })
        },
        ctrlNum(res, num) {
            this.requireList.forEach((item, index) => {
                if (index == res) {
                    item.receiveCnt = +num;
                    if (item.receiveCnt >= +item.thisTimeCnt) {
                        item.receiveCnt = +item.thisTimeCnt
                    } else if (+item.receiveCnt < 0) {
                        item.receiveCnt = 0
                    }
                    // if(item.num.length==1){
                    //   item.num=item.num.replace(/[^1-9]/g,'')
                    // }else{
                    //   item.num=item.num.replace(/\D/g,'')
                    // }
                    this.$set(this.requireList, index, item);
                }
            })
        },
        // 批量确认
        // handleBatchConfirm() {
        //     let valid = true;
        //     this.requireList.forEach(item => {
        //         if (item.receiveCnt < 0) {
        //             valid = false;
        //         }
        //     });
        //
        //     if (valid) {
        //         let hasOne = false;
        //         this.requireList.forEach((item, index) => {
        //             if (item.checked) {
        //                 hasOne = true;
        //                 item.confirm = true;
        //                 this.$set(this.requireList, index, item);
        //             }
        //         });
        //         if (!hasOne) {
        //             this.$message.info("请选择商品");
        //         }
        //     } else {
        //         this.$message.error("请输入本次实收数量");
        //     }
        // },
        // 编辑验收单
        handleEditCheckGoods() {
            this.$router.push({
                path: "/createCheckGoods",
                query: {
                    deliveryNo: this.deliveryNo
                }
            });
        },
        // 提交验收单
        handleSubmit() {
            if (this.checkGoodsValid()) {
                let isFull = true;
                this.recordOrder();
                let count = 0;
                console.log(this.comfirmRequireList);
                this.comfirmRequireList.forEach((item, index) => {
                    // if (item.leftCnt > item.receiveCnt) {
                    //     isFull = false;
                    // }
                    item.receiveCnt = +item.receiveCnt;
                    item.requireDetailId = +item.requireDetailId;
                    count += +item.receiveCnt;
                });
                console.log(this.orderInfo.unReceiveCnt);
                console.log(count);
                isFull = count >= this.orderInfo.unReceiveCnt;

                const data = {
                    deliveryNo: this.deliveryNo,
                    deliveryList: this.comfirmRequireList
                };
                this.$refs["signRecipt"].open(data, isFull);
            }
        },
        // 提交验收单完成
        handleCloseSignRecipt(bool) {
            if (bool) {
                if (window.opener) {
                    window.opener.location.reload();
                }
                this.$router.push({
                    path: "/requireOrderDetail",
                    query: {
                        requireNo: this.orderInfo.requireNo
                    }
                });
            }
        },
        // 保存验收单
        handleSave() {
            this.saveSignRecipt();
        },
        // 签章
        handleSign() {
            const events = [];
            let acctIdList = [];
            if (this.userinfo.accountList.length) {
                this.userinfo.accountList.forEach(item=>{
                    acctIdList.push(item.acctId)
                });
            }else {
                acctIdList.push(this.acctId)
            }
            const eventList = filterEventByAcct(this.eventList, 2, acctIdList);
            eventList.forEach(item => {
                if (
                    item.eventType == 2 &&
                    (item.eventStatus == 0 || item.eventStatus == 1)
                ) {
                    events.push(item);
                    this.attach = item;
                }
            });
            this.$refs["signatureDialog"].open(events);
        },
        // 签章完成
        handleCloseSignature(bool) {
            if (bool) {
                if (window.opener) {
                    window.opener.location.reload();
                }
                this.$router.push({
                    path: "/signSuccess",
                    query: {
                        requireNo: this.orderInfo.requireNo,
                        requireBatchNo: this.orderInfo.requireBatchNo,
                        deliveryList: JSON.stringify(this.deliveryList || []),
                        attachName: this.attach.documentName,
                        attachUrl: this.attach.attachUrl
                    }
                });
            }
        },
        // 检查物品合法
        checkGoodsValid() {
            let valid = true;
            // this.requireList.forEach((item, index) => {
            //     if (!item.confirm) {
            //         valid = false;
            //     }
            // });
            // if (!valid) {
            //     this.$message.error("请确认本次实收数量");
            // }
            return valid;
        },
        getHeight() {
            let documentHeight = document.documentElement.scrollHeight;
            let documentClientHeight = document.documentElement.clientHeight;
            this.showPageNav = documentClientHeight * 2 < documentHeight;
        },
        // 检查角色事件
        checkEventRole() {
            let status = null;
            if (this.eventList) {
                let acctIdList = [];
                if (this.userinfo.accountList.length) {
                    this.userinfo.accountList.forEach(item=>{
                        acctIdList.push(item.acctId)
                    });
                }else {
                    acctIdList.push(this.acctId)
                }
                const events = filterEventByAcct( this.eventList , 2, acctIdList);
                events.forEach(ev => {
                    if (ev.eventType == 2) {
                        if (ev.processList && ev.processList.length) {
                            status = status || "finish";
                            ev.processList.forEach(process => {
                                if (process.processFlg == 0) {
                                    status = "unfinish";
                                }

                                this.arrangeProcessActive(process.role);
                            });
                        }
                    }
                });
            }
            return status;
        },
        // 整理角色流程状态
        arrangeProcessActive(role) {
            this.buildProcess.forEach(item => {
                if (item.role == role) {
                    item.active = true;
                }
            });
            this.supervisoryProcess.forEach(item => {
                if (item.role == role) {
                    item.active = true;
                }
            });
            this.buildProcess.forEach(item => {
                if (item.role == role) {
                    item.active = true;
                }
            });
            this.sProcess.forEach(item => {
                if (item.role == role) {
                    item.active = true;
                }
            });
        },
        // 获取验收单详情
        getSignReciptDetail() {
            const params = {
                deliveryNo: this.deliveryNo,
                pageIndex: this.pageIndex
            };
            InterfaceService.getSignReciptDetail(
                params,
                data => {
                    //console.log(data);
                    if (data.respData.respCode === "0000") {
                        this.orderInfo = data.respData || {};
                        this.requireList = data.respData.deliveryList || [];
                        this.pageSize = data.respData.pageSize;
                        this.total = data.respData.totalCount;
                        this.requireList.forEach(item => {
                            if (this.type === "confirm") {
                                item.confirm = true;
                            } else if (this.type === "create") {
                                item.receiveCnt =
                                    item.receiveCnt || +item.thisTimeCnt;
                            }
                        });
                        this.comfirmRequireList.forEach(item=>{
                            this.requireList.forEach(_item=>{
                                if (_item.requireDetailId == item.requireDetailId) {
                                    _item.confirm = item.confirm
                                    _item.receiveCnt = item.receiveCnt;
                                    _item.receiveCount = item.receiveCount;
                                    _item.requireDetailId = item.requireDetailId;
                                    _item.checkDescription = item.checkDescription;
                                }
                            })
                        });
                        this.eventList = this.orderInfo.eventList || [];

                        let info = this.orderInfo.deliveryBasicInfo || {};
                        this.orderInfo = Object.assign(this.orderInfo, info);
                        console.log(this.orderInfo);
                        this.getHeight();
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        // 保存验收单
        saveSignRecipt() {
            const list = [];
            this.recordOrder();
            this.comfirmRequireList.forEach(item => {
                list.push({
                    skuId: item.skuId,
                    receiveCount: +item.receiveCnt,
                    requireDetailId: item.requireDetailId,
                    checkDescription: item.checkDescription
                });
            });
            const params = {
                deliveryNo: this.deliveryNo,
                deliveryList: list
            };
            console.log(params);
            InterfaceService.saveSignRecipt(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        if (window.opener) {
                            window.opener.location.reload();
                        }
                        this.$message.success("保存成功");
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        init() {
            if (this.type === "create") {
                this.flow[0].active = true;
            } else if (this.type === "confirm") {
                this.flow[1].active = true;
            }
            this.getSignReciptDetail();
        },
        go(path) {
            this.$router.push(path);
        }
    },
    mounted() {
        this.deliveryNo = this.$route.query.deliveryNo;
        const deliverys = this.$route.query.deliveryList;
        this.deliveryList = deliverys && JSON.parse(deliverys);
        this.init();
    }
};
</script>
<style lang="scss" scoped>
.link {
    text-decoration: underline;
    cursor: pointer;
    color: #0082ff;
    &:hover {
        color: #0082ff;
    }
    &:active {
        color: #4c9cdd;
    }
}

.red-font {
    color: #e94650;
}

.nowrap {
    white-space: nowrap;
}
.btn-top {
    width: 100px;
}

.btn-bottom {
    width: 150px;
}

.inner-container {
    margin-bottom: 100px;
    font-size: 14px;
}

.order-info {
    margin-bottom: 20px;
    line-height: 30px;
    font-size: 12px;

    p {
        display: flex;
        padding-right: 10px;
        word-break: break-word;
        white-space: normal;

        & > span {
            display: inline-block;
            flex: 1 1 0%;
        }
    }

    label {
        white-space: nowrap;
        color: #888888;
    }
}

.order-info-title {
    margin: 5px 0;
    margin-bottom: 20px;
    font-size: 14px;
    border-left: 3px solid #000;
    line-height: 12px;
}


.order-info-header {
    position: relative;

    .link {
        position: absolute;
        top: 5px;
        right: 10px;
    }
}

.pointer {
    cursor: pointer;
    color: #0082ff;
    &:hover {
        color: #127fbe;
    }
    &:active {
        color: #4c9cdd;
    }

    .active {
        color: #ffd64e;
    }
}

.table {
    margin-bottom: 2px;
    　 /deep/ .el-button {
        font-size: 12px;
    }

    width: 100%;
    line-height: 23px;
    font-size: 12px;
    table {
        width: 100%;
    }
    td {
        padding: 14px 10px;
        vertical-align: middle;
        word-break: break-word;
    }

    thead {
        text-align: center;
        white-space: nowrap;
        font-size: 14px;
        color: #909399;
    }

    tbody {
        text-align: center;

        tr:hover {
            background: #e8f3fd;
        }

        td {
            border-bottom: 1px solid #ffffff;
            background: #f5f5f5;
        }
    }
}

.order-name {
    display: inline-flex;
    width: 100%;
    vertical-align: top;
    line-height: 20px;

    img {
        width: 75px;
        height: 75px;
    }

    a:hover {
        text-decoration: underline;
        color: #0082ff;
    }

    .left {
        margin-right: 10px;
    }

    .right {
        text-align: left;

        p {
            word-break: break-all;
            max-height: 40px;
            overflow: hidden;
        }

        a {
            max-width: 160px;
            display: inline-block;
            white-space: normal;
            word-break: break-all;
        }

        p:first-child {
            margin-bottom: 10px;
        }
        p:last-child {
            max-height: 30px;
            line-height: 15px;
            color: #969799;
        }
    }
}
.error-info {
    color: red;
}

.order-list {
    margin-bottom: 20px;
}

.order-process,
.order-process-top {
    line-height: 40px;
    .order-process-label {
        &.active {
            font-weight: 600;
            color: #444444;
        }

        &:after {
            content: "";
            display: inline-block;
            width: 30px;
            height: 1px;
            margin: 0 10px;
            vertical-align: middle;
            background: #888888;
        }

        &.end:after {
            display: none;
        }
    }
}

.order-process-top {
    position: absolute;
    bottom: 10px;
    right: 100px;
    padding: 5px 10px;
    line-height: 20px;
    color: #888888;
    background: #f5f5f5;

    &::before{
        content: '';
        position: absolute;
        top: -10px;
        right: 165px;
        border-bottom: 10px solid #f5f5f5;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
    }
}

.order-sign {
    padding-left: 20px;
    color: #888888;
    background: #f5f5f5;
}

.order-address {
    margin-bottom: 20px;
    line-height: 25px;

    label {
        display: inline-block;
        min-width: 80px;
        vertical-align: middle;
        margin-right: 10px;
    }
}

.all-opt {
    margin-bottom: 20px;
    padding: 10px 20px;

    /deep/ .el-input {
        margin-left: 20px;
        width: 400px;
    }
}
.cut,
.add {
    display: inline-block;
    width: 28px;
    height: 33px;
    background: white;
    text-align: center;
    line-height: 33px;
    border: 1px solid #dddddd;
    cursor: pointer;
    vertical-align: middle;
    user-select: none;
}
.cut.grey,
.add.grey {
    cursor: not-allowed;
    background: #eeeeee;
}
.add{
    margin-left: -3px;
}
.cut{
    margin-right: -3px;
}
.require-goods-num input {
    width: 87px;
    border-top: 1px solid #dddddd;
    border-bottom: 1px solid #dddddd;
    height: 33px;
    line-height: 33px;
    text-align: center;
    border-right: none;
    border-left: none;
    vertical-align: middle;
}
.require-goods-num input:focus {
    border-right: none;
    border-left: none;
}
.require-goods-num input::-ms-clear {
    display: none;
}

.require-goods-num .tip {
    position: absolute;
    width: 100%;
    left: 0;
    bottom: 10px;
};

.go-blue:hover {
    color: #0082ff;
    text-decoration: underline;
    cursor: pointer;
}

</style>

