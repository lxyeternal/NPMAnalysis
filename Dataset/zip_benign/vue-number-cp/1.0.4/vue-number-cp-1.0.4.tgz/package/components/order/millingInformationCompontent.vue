<template>
  <div class="milling-information-compontent" :style="{width}">
    <p class="order-info-title" style="margin: 0 0 12px !important">发票类型</p>
    <p class="red">※多选：可提供的发票类型必须全部选中</p>
    <div class="info-panel-content">
      <div class="form-inline-item-dispickter">
        <span>
          <i class="red">*</i>发票类型：
        </span>
        <el-checkbox-group v-model="invoiceTypeModel" @change="invoiceTypeChange">
          <el-checkbox label="0">增值税专票</el-checkbox>
          <el-checkbox label="1">增值税普票</el-checkbox>
          <el-checkbox label="2">其他类型</el-checkbox>
        </el-checkbox-group>
      </div>
    </div>

    <template v-if="role === 'S'">
      <p class="order-info-title" style="margin: 32px 0 12px !important">货物与应税劳务</p>
      <div class="milling-body-head">
        <el-row>
          <el-col :span="8">
           <i class="red">*</i>货物或应税劳务分类
          </el-col>
          <el-col :span="3">
           <i class="red">*</i>税率(%)
          </el-col>
          <el-col :span="11">
            备注
          </el-col>
          <el-col :span="2">
            <span class="txt-center opt-btn">操作</span>
          </el-col>
        </el-row>
      </div>
      <div class="milling-body-center">
        <el-row v-for="(item, idx) in invoiceList" :key="idx">
          <el-col :span="8">
            <el-input v-model="item.classify" placeholder="限60字" maxlength="60"></el-input>
          </el-col>
          <el-col :span="3">
            <div class="el-input tax-input">
              <input v-model="item.tax" class="el-input__inner" placeholder="请输入数字" v-input-custom-reg="{reg:'^\\d{1,2}(\\.{1}\\d{0,2})?$'}" />
            </div>
          </el-col>
          <el-col :span="11">
            <el-input v-model="item.remark" placeholder="限200字" maxlength="200"></el-input>
          </el-col>
          <el-col :span="2">
            <span class="blue txt-center hand del-btn" :class="{disabled: invoiceList.length <= 1}" @click="handleDelInvoice(item, idx)">删除</span>
          </el-col>
        </el-row>
      </div>
      <div class="milling-body-foot">
        <el-row>
          <el-col :span="24">
            <span class="blue hand" @click="handleAddInvoice">+新增</span>
          </el-col>
        </el-row>
      </div>
    </template>
  </div>
</template>
<script>
import accountMixin from "@/mixins/account";
export default {
  mixins: [accountMixin],
  props: ['width', 'taxClassifyList', 'invoiceType', 'show'],
  data() {
    return {
      invoiceList: [],
      invoiceTypeModel: [],
      invoiceListFirstLoading: true, // 第一次加载 初始化数据 后不再继续赋值
    }
  },
  watch: {
    taxClassifyList: {
      deep: true,
      handler(newVal, oldVal) {

        if (this.invoiceListFirstLoading) {

          this.invoiceList = [...this.taxClassifyList]
          if (!this.invoiceList.length) {
            this.invoiceList = [{
              classify: '',
              tax: '',
              remark: ''
            }]
          }
          this.invoiceListFirstLoading = false
        }
      }
    },
    invoiceList: {
      deep: true,
      handler(newVal, oldVal) {
        console.log(newVal, 'newVal');

        const arr = [...newVal]
        // arr.some(s => {
        //   s.tax = Number(s.tax).toString()
        // })

        this.$emit('update:taxClassifyList', arr)
      }
    },
    invoiceType: {
      deep: true,
      handler(newVal, oldVal) {
        this.invoiceTypeModel = [...this.invoiceType]
      }
    },
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      console.log(this.taxClassifyList, '-----taxClassifyList');

      this.invoiceList = [...this.taxClassifyList];
      console.log(this.invoiceType);
      this.invoiceTypeModel = [...this.invoiceType]

      if (!this.invoiceList.length) {
        this.invoiceList = [{
          classify: '',
          tax: '',
          remark: ''
        }]
      }
    },


    invoiceTypeChange(ev) {
      let outputVal = []
      if (ev.length) {
        ev.forEach((i,index)=>{
          if (i !== "/") {
            outputVal.push(i)
          }
        })
      }
      console.log(outputVal, '--ev');
      this.$emit('update:invoiceType', [...outputVal])
    },

    /**
     * 新增
     */
    handleAddInvoice() {
      this.invoiceList.push({
        classify: '',
        tax: '',
        remark: ''
      })
    },

    /**
     * 删除
     */
    handleDelInvoice(item, idx) {
      if (this.invoiceList.length <= 1) return
      this.$confirm('此操作将永久删除该数据, 是否继续?', '提示', {
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        closeOnClickModal: false,
        confirmButtonText: '确定',
        cancelButtonText: '取消',
      }).then(() => {
        this.invoiceList.splice(idx, 1)
        this.$message({
          type: 'success',
          message: '删除成功!'
        });
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
  },
}
</script>
<style lang="scss" scoped>
.milling-information-compontent {
  .opt-btn {
    display: block;
  }
  .bold {
    font-weight: bold;
  }
  .hand {
    user-select: none;
  }
  .txt-center {
    text-align: center;
  }
  & > p {
    margin-bottom: 12px;
    &.red {
      font-size: 12px;
    }
  }
  .form-inline-item-dispickter {
    display: flex;
    color: #444444;
    & > span {
      margin-right: 12px;
    }
    /deep/ .el-checkbox {
      margin-right: 20px;
    }
  }
  .milling-body-title {
    margin-top: 32px;
  }
  .milling-body-head {
    [class*="el-col-"] {
      height: 34px;
      background: #f5f5f5;
      line-height: 34px;
      color: #888888;
      padding: 0 12px;
    }
  }
  .milling-body-center {
    margin: 0 0 8px;
    .del-btn {
      display: block;
      height: 100%;
      margin-left: 12px;
      &.disabled {
        color: #888888 !important;
        cursor: context-menu !important;
      }
    }
    .el-row {
      margin-top: 8px;
    }
    [class*="el-col-"] {
      height: 34px;
      line-height: 34px;
      padding-right: 12px;
    }
    /deep/ .el-input__inner {
      height: 33px;
      line-height: 33px;
    }
  }
  .milling-body-foot {
    [class*="el-col-"] {
      height: 34px;
      background: #f5f5f5;
      line-height: 34px;
      padding: 0 12px;
      text-align: center;
    }
  }
}
.tax-input {
  position: relative;
  &::after {
    content: "%";
    position: absolute;
    right: 7px;
    font-size: 12px;
    color: #888;
  }
}
</style>


<style lang="scss">
.millingDelBarandNoticeBox {
  width: 400px !important;
  .el-message-box__btns {
    display: flex;
    justify-content: center;
    .el-button--primary {
      order: -1;
      margin: 0 10px 0 0;
      background: #d7b064 linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
      color: #fff;
    }
  }
}
</style>