<template>
  <div style="margin-bottom: 120px;">
    <div class="order-info-title">投标对接人</div>
    <div class="f14 bold" style="margin-bottom: 5px;">投标负责人</div>
    <el-form :class="{detail:!isSubmit}" class="form" ref="formOne" :model="formOne" :rules="isSubmit ? rules : {}" label-width="110px" size="small" >
      <el-row v-if="isSubmit" style="margin-bottom: 20px;">
        <el-col :span="24" class="enclosure" >
          <el-form-item ref="form31" class="upload pickPepoleCardUrl" style="color: #000;" label="对接人名片（请上传jpg、png格式附件）" prop="pickPepoleCardUrl1" label-width="268px">
            <!--<template v-if="isSubmit && !formOne.pickPepoleCardName">-->
            <template>
              <input :id="'pickPepoleCardUrlFileOne'" type="file" @change="handleUpload($event,'31',formOne,'pickPepoleCardUrlFileOne')">
              <label style="position:absolute;left: 0;" class="hand blue f12" :for="'pickPepoleCardUrlFileOne'">上传</label>
            </template>
            <div class="grey f12" style="margin-top: 20px;margin-left: -268px;">说明：请保证名片图片高清不模糊。</div>
            <div class="enclosure-content" style="margin-top: 0;margin-left: -268px;" v-if="formOne.pickPepoleCardName">
              <span>{{formOne.pickPepoleCardName}}</span>
              <span class="hand blue" @click="handleView(formOne.pickPepoleCardAttachUrl)">预览</span>
              <span class="hand blue" @click="handleDownload(formOne.pickPepoleCardAttachUrl,formOne.pickPepoleCardName)">下载</span>
              <span class="hand blue" @click="handleDel(formOne,'pickPepoleCard')" v-if="isSubmit">删除</span>
            </div>
            <div v-else class="grey enclosure-content" style="margin-top: 0;margin-left: -268px;">
              未上传附件！
            </div>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :class="{contacts : !isSubmit}">
        <el-col :span="12">
          <el-form-item label="对接人姓名：" prop="supplierBidContactAcctId">

            <el-select v-if="isSubmit" clearable filterable default-first-option remote allow-create
                       v-model="formOne.supplierBidContactAcctId"
                       placeholder="请选择对接人姓名"
                       @change="handleChangeRole($event,formOne,1)"
                       @focus="handleFocus"
                       :filter-method="handleGetValue"
                       :ref="'select1'"
            >
              <div slot="empty" class="empty-text hand" v-html="noDataText" @click="handleAddBiddingRole(1)">

              </div>
              <el-option v-for="(person,index) in acctList" :label="person.acctName" :value="person.acctId" :key="person.acctId"></el-option>
            </el-select>
            <div style="position:absolute;line-height: 17px;font-size:12px;" v-if="isSubmit && showIdentifyError1">
              <!--<span class="red" v-if="!isAdmin">对接人{{identifyInfo1.acctName}}未加入平台，请联系管理员添加该对接人账户后再来选择添加！</span>-->
              <!--<span class="red" v-if="isAdmin">对接人{{identifyInfo1.acctName}}未加入平台！-->
                <!--<span @click="handleAddBiddingRole(1,identifyInfo1)" class="blue hand" style="padding-left: 10px">+快速添加对接人账户</span>-->
              <!--</span>-->
              <span class="red" v-if="!Object.keys(identifyInfo1).length">名片未识别，请自行添加投标负责人</span>
            </div>
            <span v-if="!isSubmit">{{formOne.supplierBidContactName}}</span>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="身份证号："  prop="certNo" label-width="196px">
            <el-input :disabled="disabled1" v-if="isSubmit" type="text" clearable v-model="formOne.certNo"  placeholder="请输入身份证号"></el-input>
            <span v-else>{{formOne.certNo}}</span>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :class="{contacts : !isSubmit}">
        <el-col :span="12">
          <el-form-item label="手机号："  prop="mobile">
            <el-input :disabled="disabled1" v-if="isSubmit" type="text" clearable v-model="formOne.mobile"  placeholder="请输入手机号" maxLength="11"></el-input>
            <span v-else>{{formOne.mobile}}</span>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="办公室电话："  prop="officePhone" label-width="196px">
            <el-input v-if="isSubmit" :disabled="disabledPhone1" type="text" clearable v-model="formOne.officePhone"  placeholder="请输入办公室电话"></el-input>
            <span v-else>{{formOne.officePhone}}</span>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :class="{contacts : !isSubmit}">
        <el-col :span="12">
          <el-form-item label="邮箱地址："   prop="email">
            <el-autocomplete ref="autocomplete" :fetch-suggestions="querySearch" :trigger-on-focus="false" :disabled="disabled1" v-if="isSubmit" type="text" clearable v-model="formOne.email"  placeholder="请输入邮箱地址"></el-autocomplete>
            <span v-else>{{formOne.email}}</span>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row v-if="!isSubmit">
        <el-col :span="24" class="enclosure" >
          <el-form-item ref="form31" class="upload pickPepoleCardUrl" style="color: #000;" label="对接人名片（请上传jpg、png格式附件）" prop="pickPepoleCardUrl" label-width="268px">
            <div class="grey f12" style="margin-top: 20px;margin-left: -268px;">说明：请保证名片图片高清不模糊。</div>
            <div class="enclosure-content" style="margin-top: 0;margin-left: -268px;" v-if="formOne.pickPepoleCardName">
              <span>{{formOne.pickPepoleCardName}}</span>
              <span class="hand blue" @click="handleView(formOne.pickPepoleCardAttachUrl)">预览</span>
              <span class="hand blue" @click="handleDownload(formOne.pickPepoleCardAttachUrl,formOne.pickPepoleCardName)">下载</span>
              <span class="hand blue" @click="handleDel(formOne,'pickPepoleCard')" v-if="isSubmit">删除</span>
            </div>
            <div v-else class="grey enclosure-content" style="margin-top: 0;margin-left: -268px;">
              未上传附件！
            </div>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24" class="enclosure" >
          <el-form-item ref="form41" class="upload"  style="color: #000;" label="社保证明（近三个月以上本公司缴纳的社保记录）" prop="socialCertificateUrl1" label-width="333px">
            <!--<template v-if="isSubmit && !formOne.socialCertificateName">-->
            <template v-if="isSubmit">
              <input :id="'pickSocialCertificateUrlOne'" type="file" @change="handleUpload($event,'41',formOne,'pickSocialCertificateUrlOne')">
              <label style="position:absolute;left: 0;" class="hand blue f12" :for="'pickSocialCertificateUrlOne'">上传</label>
            </template>
            <div class="grey f12" style="margin-top: 20px;margin-left: -333px;">说明：加盖社保中心印章的社保证明PDF文件，可从社保中心官网下载。</div>
            <div class="enclosure-content" style="margin-top: 0;margin-left: -333px;" v-if="formOne.socialCertificateName">
              <span>{{formOne.socialCertificateName}}</span>
              <span class="hand blue" @click="handleView(formOne.socialCertificateAttachUrl)">预览</span>
              <span class="hand blue" @click="handleDownload(formOne.socialCertificateAttachUrl,formOne.socialCertificateName)">下载</span>
              <span class="hand blue" @click="handleDel(formOne,'socialCertificate')" v-if="isSubmit">删除</span>
            </div>
            <div v-else class="grey enclosure-content" style="margin-top: 0;margin-left: -333px;">
              未上传附件！
            </div>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row style="margin-top: 0;padding-bottom: 30px;border-bottom: 1px dashed #EEEEEE">
        <el-col :span="24" class="enclosure" >
          <el-form-item ref="form51" class="upload biddingAuthorizationUrl"  style="color: #000;" label="对接人投标委托书（公司线下用印的扫描文件,请上传jpg、png、PDF格式附件）" prop="biddingAuthorizationUrl1" label-width="514px">
            <!--<template v-if="isSubmit && !formOne.biddingAuthorizationName">-->
            <template v-if="isSubmit">
              <input :id="'pickBiddingAuthorizationUrlOne'" type="file" @change="handleUpload($event,'51',formOne,'pickBiddingAuthorizationUrlOne')">
              <label style="position:absolute;left: 0;" class="hand blue f12" :for="'pickBiddingAuthorizationUrlOne'">上传</label>
            </template>
            <div class="enclosure-content biddingAuthorization" style="margin-left: -514px;" v-if="formOne.biddingAuthorizationName">
              <span>{{formOne.biddingAuthorizationName}}</span>
              <span class="hand blue" @click="handleView(formOne.biddingAuthorizationAttachUrl)">预览</span>
              <span class="hand blue" @click="handleDownload(formOne.biddingAuthorizationAttachUrl,formOne.biddingAuthorizationName)">下载</span>
              <span class="hand blue" @click="handleDel(formOne,'biddingAuthorization')" v-if="isSubmit">删除</span>
            </div>
            <div v-else class="grey enclosure-content" style="margin-left: -514px;">
              未上传附件！
            </div>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div class="f14 bold" style="margin-top: 20px;margin-bottom: 5px;">投标对接人</div>
    <el-form class="form" ref="formTwo" :model="formTwo" :rules="isSubmit ? rules : {}" label-width="110px" size="small" >
      <el-row v-if="isSubmit" style="margin-bottom: 20px;">
        <el-col :span="24" class="enclosure" >
          <el-form-item ref="form32" class="upload pickPepoleCardUrl"  style="color: #000;" label="对接人名片（请上传jpg、png格式附件）" prop="pickPepoleCardUrl2" label-width="268px">
            <!--<template v-if="isSubmit && !formTwo.pickPepoleCardName">-->
            <template>
              <input :id="'pickPepoleCardUrlTwo'" type="file" @change="handleUpload($event,'32',formTwo,'pickPepoleCardUrlTwo')">
              <label style="position:absolute;left: 0;" class="hand blue f12" :for="'pickPepoleCardUrlTwo'">上传</label>
            </template>
            <div class="grey f12" style="margin-top: 20px;margin-left: -268px;">说明：请保证名片图片高清不模糊。</div>
            <div class="enclosure-content" style="margin-top: 0;margin-left: -268px;" v-if="formTwo.pickPepoleCardName">
              <span>{{formTwo.pickPepoleCardName}}</span>
              <span class="hand blue" @click="handleView(formTwo.pickPepoleCardAttachUrl)">预览</span>
              <span class="hand blue" @click="handleDownload(formTwo.pickPepoleCardAttachUrl,formTwo.pickPepoleCardName)">下载</span>
              <span class="hand blue" @click="handleDel(formTwo,'pickPepoleCard')" v-if="isSubmit">删除</span>
            </div>
            <div v-else class="grey enclosure-content" style="margin-top: 0;margin-left: -268px;">
              未上传附件！
            </div>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :class="{contacts : !isSubmit}">
        <el-col :span="12">
          <el-form-item label="对接人姓名：" prop="supplierBidContactAcctId">
            <el-select v-if="isSubmit" clearable filterable default-first-option remote allow-create
                       v-model="formTwo.supplierBidContactAcctId"
                       placeholder="请选择对接人姓名"
                       @change="handleChangeRole($event,formTwo,2)"
                       @focus="handleFocus"
                       :remote-method="handleGetValue"
                       :ref="'select2'"
            >
              <div slot="empty" class="empty-text hand" v-html="noDataText" @click="handleAddBiddingRole(2)">

              </div>
              <el-option v-for="(person,index) in acctList" :label="person.acctName" :value="person.acctId" :key="person.acctId">
              </el-option>
            </el-select>
            <div style="position:absolute;line-height: 17px;font-size:12px;" v-if="isSubmit && showIdentifyError2">
              <!--<span class="red" v-if="!isAdmin">对接人{{identifyInfo2.acctName}}未加入平台，请联系管理员添加该对接人账户后再来选择添加！</span>-->
              <!--<span class="red" v-if="isAdmin">对接人{{identifyInfo2.acctName}}未加入平台！-->
                <!--<span @click="handleAddBiddingRole(2,identifyInfo2)" class="blue hand" style="padding-left: 10px">+快速添加对接人账户</span>-->
              <!--</span>-->
              <span class="red" v-if="!Object.keys(identifyInfo2).length">名片未识别，请自行添加投标对接人</span>
            </div>
            <span v-if="!isSubmit">{{formTwo.supplierBidContactName}}</span>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="身份证号："  prop="certNo" label-width="196px">
            <el-input :disabled="disabled2" v-if="isSubmit" type="text" clearable v-model="formTwo.certNo"  placeholder="请输入身份证号"></el-input>
            <span v-else>{{formTwo.certNo}}</span>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :class="{contacts : !isSubmit}">
        <el-col :span="12">
          <el-form-item label="手机号："  prop="mobile">
            <el-input :disabled="disabled2" v-if="isSubmit" type="text" clearable v-model="formTwo.mobile"  placeholder="请输入手机号" maxLength="11"></el-input>
            <span v-else>{{formTwo.mobile}}</span>
          </el-form-item>
        </el-col>
        <el-col :span="12">
          <el-form-item label="办公室电话："  prop="officePhone" label-width="196px">
            <el-input :disabled="disabledPhone2" v-if="isSubmit" type="text" clearable v-model="formTwo.officePhone"  placeholder="请输入办公室电话"></el-input>
            <span v-else>{{formTwo.officePhone}}</span>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row :class="{contacts : !isSubmit}">
        <el-col :span="12">
          <el-form-item label="邮箱地址："   prop="email">
            <el-autocomplete ref="autocomplete" :fetch-suggestions="querySearch" :trigger-on-focus="false" :disabled="disabled2" v-if="isSubmit" type="text" clearable v-model="formTwo.email"  placeholder="请输入邮箱地址"></el-autocomplete>
            <span v-else>{{formTwo.email}}</span>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row v-if="!isSubmit">
        <el-col :span="24" class="enclosure" >
          <el-form-item ref="form32" class="upload pickPepoleCardUrl"  style="color: #000;" label="对接人名片（请上传jpg、png格式附件）" prop="pickPepoleCardUrl" label-width="268px">
            <div class="grey f12" style="margin-top: 20px;margin-left: -268px;">说明：请保证名片图片高清不模糊。</div>
            <div class="enclosure-content" style="margin-top: 0;margin-left: -268px;" v-if="formTwo.pickPepoleCardName">
              <span>{{formTwo.pickPepoleCardName}}</span>
              <span class="hand blue" @click="handleView(formTwo.pickPepoleCardAttachUrl)">预览</span>
              <span class="hand blue" @click="handleDownload(formTwo.pickPepoleCardAttachUrl,formTwo.pickPepoleCardName)">下载</span>
              <span class="hand blue" @click="handleDel(formTwo,'pickPepoleCard')" v-if="isSubmit">删除</span>
            </div>
            <div v-else class="grey enclosure-content" style="margin-top: 0;margin-left: -268px;">
              未上传附件！
            </div>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24" class="enclosure" >
          <el-form-item ref="form42" class="upload"  style="color: #000;" label="社保证明（近三个月以上本公司缴纳的社保记录）" prop="socialCertificateUrl2" label-width="333px">
            <!--<template v-if="isSubmit && !formTwo.socialCertificateName">-->
            <template v-if="isSubmit">
              <input :id="'socialCertificateUrlTwo'" type="file" @change="handleUpload($event,'42',formTwo,'socialCertificateUrlTwo')">
              <label style="position:absolute;left: 0;" class="hand blue f12" :for="'socialCertificateUrlTwo'">上传</label>
            </template>
            <div class="grey f12" style="margin-top: 20px;margin-left: -333px;">说明：加盖社保中心印章的社保证明PDF文件，可从社保中心官网下载。</div>
            <div class="enclosure-content" style="margin-top: 0;margin-left: -333px;" v-if="formTwo.socialCertificateName">
              <span>{{formTwo.socialCertificateName}}</span>
              <span class="hand blue" @click="handleView(formTwo.socialCertificateAttachUrl)">预览</span>
              <span class="hand blue" @click="handleDownload(formTwo.socialCertificateAttachUrl,formTwo.socialCertificateName)">下载</span>
              <span class="hand blue" @click="handleDel(formTwo,'socialCertificate')" v-if="isSubmit">删除</span>
            </div>
            <div v-else class="grey enclosure-content" style="margin-top: 0;margin-left: -333px;">
              未上传附件！
            </div>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row style="margin-top: 0;padding-bottom: 30px;border-bottom: 1px dashed #EEEEEE">
        <el-col :span="24" class="enclosure" >
          <el-form-item ref="form52" class="upload biddingAuthorizationUrl"  style="color: #000;" label="对接人投标委托书（公司线下用印的扫描文件,请上传jpg、png、PDF格式附件）" prop="biddingAuthorizationUrl2" label-width="514px">
            <!--<template v-if="isSubmit && !formTwo.biddingAuthorizationName">-->
            <template v-if="isSubmit">
              <input :id="'biddingAuthorizationUrlTwo'" type="file" @change="handleUpload($event,'52',formTwo,'biddingAuthorizationUrlTwo')">
              <label style="position:absolute;left: 0;" class="hand blue f12" :for="'biddingAuthorizationUrlTwo'">上传</label>
            </template>
            <div class="enclosure-content" style="margin-left: -514px;" v-if="formTwo.biddingAuthorizationName">
              <span>{{formTwo.biddingAuthorizationName}}</span>
              <span class="hand blue" @click="handleView(formTwo.biddingAuthorizationAttachUrl)">预览</span>
              <span class="hand blue" @click="handleDownload(formTwo.biddingAuthorizationAttachUrl,formTwo.biddingAuthorizationName)">下载</span>
              <span class="hand blue" @click="handleDel(formTwo,'biddingAuthorization')" v-if="isSubmit">删除</span>
            </div>
            <div v-else class="grey enclosure-content" style="margin-left: -514px;">
              未上传附件！
            </div>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <div class="order-info-title">其他资料</div>
    <div class="enclosure-tip">单个附件大小不超过20MB</div>
    <el-form class="form" :model="formEnclosure" :rules="rules" label-width="170px" size="small" >
      <el-row>
        <el-col :span="24" class="enclosure" >
          <el-form-item class="upload"  style="color: #000;" label="与其他房企战略合作中标证明（如有）" label-width="268px">
            <template v-if="isSubmit">
              <input :id="'cooperationCertificateUrl'" type="file" @change="handleUpload($event,'6',formEnclosure.cooperationList,'cooperationCertificateUrl')">
              <label style="position:absolute;left: -16px;" class="hand blue f12" :for="'cooperationCertificateUrl'">上传</label>
            </template>
            <div class="enclosure-content" v-if="formEnclosure.cooperationList.length">
              <div v-for="(item,index) in formEnclosure.cooperationList">
                <span>{{item.name}}</span>
                <span class="hand blue" @click="handleView(item.attachUrl)">预览</span>
                <span class="hand blue" @click="handleDownload(item.attachUrl,item.name)">下载</span>
                <span class="hand blue" v-if="isSubmit" @click="handleDelOthers(formEnclosure.cooperationList,item,index)">删除</span>
              </div>
            </div>
            <div v-else class="grey enclosure-content">
              未上传附件！
            </div>
          </el-form-item>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24" class="enclosure" >
          <el-form-item class="upload"  style="color: #000;" label="其他附件" label-width="268px">
            <template v-if="isSubmit">
              <input :id="'others'" type="file" @change="handleUpload($event,'7',formEnclosure.othersList,'others')">
              <label style="position:absolute;left: -198px" class="hand blue f12" :for="'others'">上传</label>
            </template>
            <div class="enclosure-content" v-if="formEnclosure.othersList.length">
              <div v-for="(item,index) in formEnclosure.othersList">
                <span>{{item.name}}</span>
                <span class="hand blue" @click="handleView(item.attachUrl)">预览</span>
                <span class="hand blue" @click="handleDownload(item.attachUrl,item.name)">下载</span>
                <span class="hand blue" v-if="isSubmit" @click="handleDelOthers(formEnclosure.othersList,item,index)">删除</span>
              </div>
            </div>
            <div v-else class="grey enclosure-content">
              未上传附件！
            </div>
          </el-form-item>
        </el-col>
      </el-row>
    </el-form>
    <AddNewPerson ref="AddNewPerson" @saveSuccess="saveSuccess"></AddNewPerson>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
  import { InterfaceService } from "@/services/api";
  import Loading from "@/components/base/Loading";
  import { viewFile } from '@/utils/orderUtil';
  import AddNewPerson from '@/components/base/dialog/AddNewPerson';
  import { ImageUtil } from '@/utils/imageUtil';

  const form = {
    supplierBidContactName : "",
    supplierBidContactAcctId : "",
    certNo : "",
    mobile : "",
    officePhone : "",
    email : "",
    biddingAuthorizationName : "",
    biddingAuthorizationUrl : "",
    biddingAuthorizationAttachUrl : "",
    socialCertificateName : "",
    socialCertificateUrl : "",
    socialCertificateAttachUrl : "",
    pickPepoleCardName : "",
    pickPepoleCardUrl : "",
    pickPepoleCardAttachUrl : "",
  }
  export default {
    name: "biddingContacts",
    props:["supplierBiddingInfo","isSubmit","checkForm"],
    components:{
      Loading,
      AddNewPerson,
    },
    data() {
      var validataPickPepoleCardUrl1 = (rule, value, callback) => {
        if (!this.formOne.pickPepoleCardUrl) {
            callback(new Error('必填'));
        }
        callback();
      };
      var validataSocialCertificateUrl1 = (rule, value, callback) => {
        if (!this.formOne.socialCertificateUrl) {
          callback(new Error('必填'));
        }
        callback();
      };
      var validataBiddingAuthorizationUrl1 = (rule, value, callback) => {
        if (!this.formOne.biddingAuthorizationUrl) {
          callback(new Error('必填'));
        }
        callback();
      };
      var validataPickPepoleCardUrl2 = (rule, value, callback) => {
        if (!this.formTwo.pickPepoleCardUrl) {
          callback(new Error('必填'));
        }
        callback();
      };
      var validataSocialCertificateUrl2 = (rule, value, callback) => {
        if (!this.formTwo.socialCertificateUrl) {
          callback(new Error('必填'));
        }
        callback();
      };
      var validataBiddingAuthorizationUrl2 = (rule, value, callback) => {
        if (!this.formTwo.biddingAuthorizationUrl) {
          callback(new Error('必填'));
        }
        callback();
      };
      return{
        isLoading:false,
        showIdentifyError1:false,
        showIdentifyError2:false,
        disabled1:true,
        disabled2:true,
        disabledPhone1:true,
        disabledPhone2:true,
        hasRole1:false,
        hasRole2:false,
        itemInfo1:{},
        itemInfo2:{},
        formOne :Object.assign({},form),
        formTwo:Object.assign({},form),
        acctList:[],
        identifyInfo1:{},
        identifyInfo2:{},
        copyAcctList:[],
        acctListCopy:[],
        ossFiles:[],
        roleList:[],
        inputValue : "",
        formEnclosure:{
          cooperationList:[],
          othersList:[],
        },
        rules:{
          supplierBidContactAcctId:[{
            required : true,
              message: "必填",
              trigger: "change"
            }],
          certNo:[
            { pattern: this.$commonExpression('certNo'), message: "身份证号填写错误，请重新填写", trigger: "blur" },
            {
              required: true,
              message: "必填",
              trigger: "blur"
          }],
          mobile:[
            { pattern: this.$commonExpression('mobile'), message: "手机号填写错误，请重新填写", trigger: "blur" },
            {
              required: true,
              message: "必填",
              trigger: "blur"
            }],
          email:[
            { pattern: this.$commonExpression('email'), message: "邮箱填写错误，请重新填写", trigger: "blur" },
            {
              required: true,
              message: "必填",
              trigger: "blur"
            }],
          officePhone:[
            { pattern: /^[\d-\s\(\)\+\,]*$/, message: "座机号填写错误，请重新填写", trigger: "blur" },
            {
              required: true,
              message: "必填",
              trigger: "blur"
            }],
          pickPepoleCardUrl1:[{
            required: true,
            validator: validataPickPepoleCardUrl1,
            message: "必填",
          }],
          socialCertificateUrl1:[{
            required: true,
            message: "必填",
            validator: validataSocialCertificateUrl1,
          }],
          biddingAuthorizationUrl1:[{
            required: true,
            validator: validataBiddingAuthorizationUrl1,
            message: "必填",
          }],
          pickPepoleCardUrl2:[{
            required: true,
            validator: validataPickPepoleCardUrl2,
            message: "必填",
          }],
          socialCertificateUrl2:[{
            required: true,
            message: "必填",
            validator: validataSocialCertificateUrl2,
          }],
          biddingAuthorizationUrl2:[{
            required: true,
            validator: validataBiddingAuthorizationUrl2,
            message: "必填",
          }]
        }
      }
    },
    computed:{
      isAgent() {
        return this.$store.state.userInfo && this.$store.state.userInfo.supplyType !== '0'
      },
      isAdmin() {
        let adminRoles = ['1000', '2000', '3000', '4000', '5000', '9000']
        return this.$store.state.userInfo.roleIds && this.$store.state.userInfo.roleIds.some(item => {
          return adminRoles.indexOf(item.roleId) != -1
        });
      },
      noDataText() {
          let str = "";
          if (this.isAdmin) {
            str = `未找到对应的对接人!<span class="blue" style="padding-left: 10px">+快速添加对接人账户</span>`
          }else {
            str = `未找到对应的对接人，请联系管理员添加该对接人账户后再来选择添加！</span>`
          }
          return str
      }
    },
    watch:{
      supplierBiddingInfo: {
        deep: true,
        handler(newVal, oldVal) {
          this.init()
        }
      },
      checkForm(newVal) {
        if (newVal) {
          console.log(this.formOne);
          console.log(this.formTwo);
          this.$refs.formOne.validate((valid) => {
            this.$refs.formTwo.validate((_valid) => {
              if (valid && _valid) {
                if (!this.disabled1) {
                  this.addSubordinate(this.formOne,1)
                }else if (!this.disabled2) {
                  this.addSubordinate(this.formTwo,2)
                }else {
                  this.acctListCopy.forEach(item=>{
                    if (item.acctId === this.formOne.supplierBidContactAcctId) {
                      this.itemInfo1 = item;
                      if (item.roleIds) {
                        this.hasRole1 = item.roleIds.some(role=>{
                          return role.roleId === "3001" || role.roleId === "4001"
                        }) && item.officePhone
                      }
                    }
                    if (item.acctId === this.formTwo.supplierBidContactAcctId) {
                      this.itemInfo2 = item;
                      if (item.roleIds) {
                        this.hasRole2 = item.roleIds.some(role=>{
                          return role.roleId === "3001" || role.roleId === "4001"
                        }) && item.officePhone
                      }
                    }
                  });
                  if (!this.hasRole1) {
                    this.editSubordinate(this.itemInfo1,1)
                  } else if (!this.hasRole2) {
                    this.editSubordinate(this.itemInfo2,2)
                  }else {
                    this.arrangementParams(valid,_valid)
                  }
                }
              }else {
                this.$emit("checkRes",false)
              }
            })
          })
        }
      }
    },
    methods:{
      querySearch(queryString, callback) {
        let commonMailbox = this.$commonMailbox()
        let results = this.$clone(commonMailbox)
        let value = ''
        if(queryString && queryString.indexOf('@') != -1){
          value = queryString.substring(0, queryString.indexOf('@'))
        }else{
          value = queryString
        }
        results.forEach((i,index) =>{
            i.value = value + '' + commonMailbox[index].value
        })
        callback(results)
        this.$refs.autocomplete.handleFocus()
      },
      arrangementParams(valid,_valid) {
        let ibSupplierBidContactInfoList = [];
        let formO = this.$clone(this.formOne);
        delete formO.biddingAuthorizationName;
        delete formO.biddingAuthorizationAttachUrl;
        delete formO.socialCertificateName;
        delete formO.socialCertificateAttachUrl;
        delete formO.pickPepoleCardName;
        delete formO.pickPepoleCardAttachUrl;
        // if (formO.biddingAuthorizationOssFileId) {
        //   delete formO.biddingAuthorizationUrl;
        // }
        // if (formO.socialCertificateOssFileId) {
        //   delete formO.socialCertificateUrl;
        // }
        // if (formO.pickPepoleCardOssFileId) {
        //   delete formO.pickPepoleCardUrl;
        // }
        let formT = this.$clone(this.formTwo);
        delete formT.biddingAuthorizationName;
        delete formT.biddingAuthorizationAttachUrl;
        delete formT.socialCertificateName;
        delete formT.socialCertificateAttachUrl;
        delete formT.pickPepoleCardName;
        delete formT.pickPepoleCardAttachUrl;
        // if (formT.biddingAuthorizationOssFileId) {
        //   delete formT.biddingAuthorizationUrl;
        // }
        // if (formT.socialCertificateOssFileId) {
        //   delete formT.socialCertificateUrl;
        // }
        // if (formT.pickPepoleCardOssFileId) {
        //   delete formT.pickPepoleCardUrl;
        // }
        formO.contactType = "0";
        formT.contactType = "1";
        ibSupplierBidContactInfoList.push(formO,formT);
        ibSupplierBidContactInfoList.forEach(item=>{
          if (item.contactFileInfoList && item.contactFileInfoList.length) {
            delete item.contactFileInfoList
          }
        });
        let cooperationCertificateUrl = [],otherAppendix = [];
        this.formEnclosure.cooperationList.forEach(item=>{
          if (!item.ossFileId) {
            cooperationCertificateUrl.push(item.url)
          }
        });
        console.log(this.formEnclosure.othersList);
        this.formEnclosure.othersList.forEach(item=>{
          if (!item.ossFileId) {
            otherAppendix.push(item.url)
          }
        });
        let params = {
          ibSupplierBidContactInfoList,
          cooperationCertificateUrl,
          otherAppendix,
          ossFiles : this.ossFiles,
        };
        console.log(params);
        this.$emit("checkRes",valid && _valid,params)
      },
      // 新增公司下属账户信息
      addSubordinate(form,type) {
        this.errorMsg = {};
        let params = {
          'roleIds': [this.isAgent ? "4001" : "3001"],  //投标负责人角色3001
          'acctName': form.supplierBidContactName,
          'mobile': form.mobile,
          'email': form.email,
          'certNo':form.certNo,
          'officePhone':form.officePhone,
        };
        InterfaceService.addSubordinate(
          params,
          data => {
            let res = data.respData
            if(res.respCode == '0000'){
              this['disabled' + type] = true;
              if (!this.disabled2) {
                this.addSubordinate(this.formTwo,2)
              }else {
                this.getQuerySubordinate('edit')
              }
            }else{
              this.$message.error(type == 1 ? '投标负责人信息错误：' + res.respMsg : '投标对接人信息错误：' + res.respMsg);
              this.$emit("checkRes",false)
            }
          },
          data => {},
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      },
      editSubordinate(info,type) {
        let params = {
          'roleIds': [this.isAgent ? "4001" : "3001"],
          'acctId' : info.acctId,
          'acctName': info.acctName,
          'mobile': info.mobile,
          'email': info.email,
          'certNo': info.certNo,
          'title': info.title,
          'dept': info.dept,
          'officePhone': type == 1 ? this.formOne.officePhone : this.formTwo.officePhone,
        };
        if (info.roleIds && info.roleIds.length) {
          info.roleIds.forEach(item=>{
            params.roleIds.push(item.roleId)
          })
        }
        InterfaceService.editSubordinate(params, (data) => {
          let res = data.respData;
          if (res.respCode === "0000") {
            this['hasRole' + type] = true;
            this.acctListCopy.forEach(item=>{
              if (type == 1) {
                if (item.acctId === this.formOne.supplierBidContactAcctId) {
                  item.officePhone = this.formOne.officePhone
                }
              }else {
                if (item.acctId === this.formTwo.supplierBidContactAcctId) {
                  item.officePhone = this.formTwo.officePhone
                }
              }
            });
            this['disabledPhone' + type] = true;
            if (!this.hasRole2) {
              this.editSubordinate(this.itemInfo2,2)
            }else {
              this.$refs.formOne.validate((valid) => {
                this.$refs.formTwo.validate((_valid) => {
                  this.arrangementParams(valid,_valid)
                })
              })
            }
          } else{
            this.$message.error(type == 1 ? '投标负责人信息错误：' + res.respMsg : '投标对接人信息错误：' + res.respMsg);
            this.$emit("checkRes",false)
          }
        },
        data => {},
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        });
      },
      handleAddBiddingRole(type,identifyInfo) {
        if (this.isAdmin) {
          let role = "3001";
          let info = {};
          if (!identifyInfo) {
            info = {
              acctName:this.inputValue || "",
              role:["3001"],
            };
          } else {
            info = identifyInfo;
            info. role = ["3001"]
          }
          this.$refs['AddNewPerson'].open(this.roleList,info,role,type)
        }
      },
      saveSuccess(acctName,type) {
        this["identifyInfo"+type] = {};
        this['showIdentifyError'+type] = false;
        this.getQuerySubordinate(acctName,type,'edit')
      },
      handleChangeRole(ev,form,type) {
        if (ev) {
          this['showIdentifyError'+type] = false;
          if (type == 1 && ev == this.formTwo.supplierBidContactAcctId) {
            this.$message.error("该人员已选择为投标对接人，请重新选择")
            this.formOne.supplierBidContactAcctId = "";
            this.formOne.supplierBidContactName = "";
            this.formOne.mobile = "";
            this.formOne.email = "";
            this.formOne.certNo = "";
            this.formOne.officePhone =  "";
            return false
          } else if (type == 2 && ev == this.formOne.supplierBidContactAcctId) {
            this.$message.error("该人员已选择为投标负责人，请重新选择")
            this.formTwo.supplierBidContactAcctId = "";
            this.formTwo.supplierBidContactName = "";
            this.formTwo.mobile = "";
            this.formTwo.email = "";
            this.formTwo.certNo = "";
            this.formTwo.officePhone =  "";
            return false
          }
          let onOff = true;
          this.acctListCopy.forEach(item=>{
            if (item.acctId === ev) {
              onOff = false;
              this['disabled'+ type] = true;
              form.supplierBidContactName = item.acctName;
              form.supplierBidContactAcctId = item.acctId;
              form.mobile = item.mobile;
              form.email = item.email;
              form.certNo = item.certNo;
              form.officePhone = item.officePhone || "";
              this['disabledPhone' + type] = !!item.officePhone;
            }
          });
          if (onOff) {
            this['disabled'+ type] = false;
            this['disabledPhone' + type] = false;
            form.supplierBidContactName = ev;
            form.supplierBidContactAcctId = ev;
            form.mobile = "";
            form.email = "";
            form.certNo = "";
            form.officePhone =  "";
          }
          if (type == 1){
            this.$refs.formOne.validate((valid) => {})
          }else {
            this.$refs.formTwo.validate((valid) => {})
          }
        }else {
          form.supplierBidContactName = "";
          form.supplierBidContactAcctId = "";
          form.mobile = "";
          form.email = "";
          form.certNo = "";
          form.officePhone = ""
        }
      },
      handleFocus(ev) {
        this.acctList = this.acctListCopy
      },
      handleGetValue(val,type) {
        this.inputValue = val;
        // this.formOne.supplierBidContactAcctId = val;
        if (val) { //val存在
          this.acctList = this.acctListCopy.filter((item) => {
            if (!!~item.acctName.indexOf(val) || !!~item.acctName.toUpperCase().indexOf(val.toUpperCase())) {
              return true
            }
          })
        } else { //val为空时，还原数组
          this.acctList = this.acctListCopy;
        }
        // this.getQuerySubordinate(ev,type)
      },
      handleView(url) {
        viewFile(url)
      },
      handleDel(form,type) {
        // if (form[type+'OssFileId']) {
        //   this.ossFiles.push(form[type+'OssFileId'])
        // }
        form[type + 'AttachUrl'] = "";
        form[type + 'Name'] = "";
        form[type + 'Url'] = "";
        form[type + 'OssFileId'] = "";
        this.$forceUpdate();
        console.log(form,this.ossFiles);
      },
      handleDelOthers(list,item,index) {
        if (item.ossFileId) {
          this.ossFiles.push(item.ossFileId);
        }
        list.splice(index,1)
        this.$forceUpdate();
        console.log(list,this.ossFiles);
      },
      handleDownload(url,name) {
        let attach = [];
        attach.push({
          url :url,
          name : name
        });
        this.$download(attach).then(res=>{
          this.$message.success("已下载");
        }).catch(res=>{
          this.$message.error("下载失败");
        })
      },
      handleUpload(e,type,form,id) {
        const file = e.target.files[0];
        if (file) {
          let a = file.name.split(".");
          const fileType = a[a.length - 1];
          if (type[0] == '3') {
            const reg = /(png|jpg)/i;
            if (!reg.test(fileType)) {
              this.$message.error("请上传jpg、png格式文件");
              return;
            }
          }else if (type[0] == '4') {
            const reg = /(pdf|PDF)/i;
            if (!reg.test(fileType)) {
              this.$message.error("请上传pdf格式文件");
              return;
            }
          }else if (type[0] =='5') {
            const reg = /(png|jpg|pdf|PDF)/i;
            if (!reg.test(fileType)) {
              this.$message.error("请上传jpg、png、pdf格式文件");
              return;
            }
          }else if (type[0] =='6' || type[0] =='7') {
            if (file.size > 20971520) {
              this.$message.error("单个附件大小不超过20MB");
              return;
            }
          }
          if (file) {
            if (type[0] == "3") {
              let fileImgList = []
              fileImgList.push(file);
              ImageUtil.handleChangeMasterImg(fileImgList, 500, 2000, (resFiles) => {
                console.log(resFiles);
                let resFile = resFiles && resFiles[0];
                // 拿签名上传图片
                this.uploadFiles(type,form,resFile)
              })
            }else {
              this.uploadFiles(type,form,file)
            }
          }
          this.resetInputValue(id)
        }
      },
      /**
       * 重置input value  防止 同一个文件连续提交 不触发 onchange事件
       */
      resetInputValue(id) {
        let isIE10 = false,
          uploadInputs = [document.getElementById(id)];
        console.log(uploadInputs);
        if (window.navigator.userAgent.indexOf('MSIE') >= 1) { // 判断ie10以及以下
          isIE10 = true
        } else {
          isIE10 = false
        }
        for (let i = 0, len = uploadInputs.length; i < len; i++) {
          const element = uploadInputs[i];

          if (isIE10) {
            let form = document.createElement('form'),
              beforInput = element.nextSibling,
              parentInput = element.parentNode

            form.appendChild(element)
            form.reset()
            parentInput.insertBefore(element, beforInput)
          } else {
            element.value = ''
          }
          console.log(element.value);
        }
      },
      uploadFiles(type,form,file){
        this.uploadContractToOss(type,file).then(res => {
          let param = {
            ossFile: [{
              fileType: type[0], filePath: res.url
            }],
            appName: "PROD"
          };
          InterfaceService.ossSignatureUrl(param, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              let list =  data.respData.ossFile || [];
              if (list.length) {
                if (type[0] == "3") {
                  console.log(file);
                  form.pickPepoleCardName = file.name;
                  form.pickPepoleCardUrl = res.url;
                  form.pickPepoleCardAttachUrl = list[0].url;
                  console.log(form);
                  this.identifyPepoleCardInfo(type[1],form)
                }else if (type[0] == '4') {
                  form.socialCertificateName = file.name;
                  form.socialCertificateUrl = res.url;
                  form.socialCertificateAttachUrl = list[0].url;
                }else if (type[0] == '5') {
                  form.biddingAuthorizationName = file.name;
                  form.biddingAuthorizationUrl = res.url;
                  form.biddingAuthorizationAttachUrl = list[0].url;
                }else if (type == '6' || type == '7') {
                  form.push({
                    name:file.name,
                    url:res.url,
                    attachUrl:list[0].url,
                  })
                }
              }
              this.$refs['form'+type] && this.$refs['form'+type].clearValidate();
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        })
      },
      uploadContractToOss(type,file) {
        return new Promise((resolve, reject) => {
          InterfaceService.getOssSignatureDisposable(file.name,{
              type:type[0],
              appName:"PROD",
            }, (data) => {
              let signature = data;
              this.uploadHander(0, file, new Date().getTime() + '/',signature, (pos, file, dirType, signature) => {
                console.log(signature.dir);
                let u = signature.dir + dirType+ file.name;
                console.log(u);
                resolve({url: u });
                //图片上传到oss之后 提交注册信息
                // setTimeout(() => {
                //   this.isReject ? this.isRejectSubmigCompelet() : this.submitCompelet()
                // }, 800)
              },() => { this.isLoading = true; }, () => { this.isLoading = false; })
            }, (data) => {
            },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            });
        })

      },
      uploadHander(pos, file, dirType, signature, callBack, loadingStartCb, loadingEndCb) {
        //去后端拿签名
        InterfaceService.uploadToOss(signature, file, dirType, pos, callBack, '', '', loadingStartCb, loadingEndCb)
      },
      identifyPepoleCardInfo(type,form) {
        const param = {
          attachUrl : form.pickPepoleCardUrl
        };
        InterfaceService.identifyPepoleCardInfo(param, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let businessCardInfos = data.respData.businessCardInfos && JSON.parse(data.respData.businessCardInfos || '') || [];
            console.log(businessCardInfos);
            if (businessCardInfos.length) {
              this['identifyInfo'+type] = {};
              businessCardInfos.forEach(item=>{
                if (item.Name === '英文姓名') {
                  this['identifyInfo'+type].acctName = this['identifyInfo'+type].acctName || item.Value;
                  // this.handleGetValue(item.Value)
                } else if (item.Name === '姓名') {
                  this['identifyInfo'+type].acctName = item.Value;
                  // this.handleGetValue(item.Value)
                } else if (item.Name.indexOf("身份证") !== -1) {
                  // form.certNo = item.Value;
                  this['identifyInfo'+type].certNo = item.Value
                }else  if (item.Name === '手机') {
                  item.Value = item.Value.replace(/\s+/g,"");
                  // if (item.Value.substring(0,2) === "86") {
                  //   this['identifyInfo'+type].mobile = item.Value.substring(2,item.Value.length)
                  // }else if (item.Value.substring(0,3) === "+86") {
                  //   this['identifyInfo'+type].mobile = item.Value.substring(3,item.Value.length)
                  // }else {
                  //   this['identifyInfo'+type].mobile = item.Value;
                  // }
                  this['identifyInfo'+type].mobile = item.Value.substring(item.Value.length-11,item.Value.length);
                }else  if (item.Name === '邮箱') {
                  this['identifyInfo'+type].email = item.Value
                }else  if (item.Name === '电话') {
                  this['identifyInfo'+type].officePhone = item.Value
                }else  if (item.Name === '职位') {
                  this['identifyInfo'+type].title = item.Value
                }else  if (item.Name === '部门') {
                  this['identifyInfo'+type].dept = item.Value
                }
              });
              this.acctList = this.acctListCopy;
              this['showIdentifyError' + type] = this.acctList.every(item=>{
                return item.acctName !== this['identifyInfo'+type].acctName
              });
              console.log(this['showIdentifyError' + type]);
              if (!this['showIdentifyError' + type]) {
                this.acctList.forEach(item=>{
                  if (item.acctName === this['identifyInfo'+type].acctName) {
                    this.handleChangeRole(item.acctId,form,type)
                  }
                });
                this['disabled' + type] = true;
              } else {
                this['disabled' + type] = false;
                this['disabledPhone' + type] = false;
                form.supplierBidContactName = this['identifyInfo'+type].acctName;
                form.supplierBidContactAcctId = this['identifyInfo'+type].acctName;
                form.mobile = this['identifyInfo'+type].mobile || "";
                form.email = this['identifyInfo'+type].email || "";
                form.certNo = this['identifyInfo'+type].certNo || "";
                form.officePhone = this['identifyInfo'+type].officePhone || ""
              }
            } else {
              this['showIdentifyError' + type]= true
            }
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
      },
      getQuerySubordinate(edit){
        let param = {
          acctStatus: '0',
        };
        InterfaceService.getQuerySubordinate(param, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            // this.acctList = data.respData.acctList || [];
            this.acctListCopy = data.respData.acctList || [];
            this.acctList = data.respData.acctList || [];
            this.copyAcctList = data.respData.acctList || [];
            let rlist = data.respData.roleList || [];
            this.roleList = [];
            rlist.forEach(item => {
              this.roleList.push(
                {label: item.roleName,
                  value: item.roleId}
              )
            });
            if (edit) {
              // let form = type == 1 ? 'formOne' : 'formTwo';
              this.acctList.forEach(item=>{
                if (item.acctName === this.formOne.supplierBidContactName) {
                  item.officePhone = this.formOne.officePhone;
                  this.handleChangeRole(item.acctId,this.formOne,1)
                }
                if (item.acctName === this.formTwo.supplierBidContactName) {
                  item.officePhone = this.formTwo.officePhone;
                  this.handleChangeRole(item.acctId,this.formTwo,2)
                }
              })
              this.$refs.formOne.validate((valid) => {
                this.$refs.formTwo.validate((_valid) => {
                  this.arrangementParams(valid,_valid)
                })
              })
            }
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
      },
      init() {
        if (Object.keys(this.supplierBiddingInfo).length){
          this.formOne = this.supplierBiddingInfo.ibSupplierBidContactInfoList && JSON.parse(JSON.stringify(this.supplierBiddingInfo.ibSupplierBidContactInfoList[0])) || Object.assign({},form);
          this.formTwo = this.supplierBiddingInfo.ibSupplierBidContactInfoList && JSON.parse(JSON.stringify(this.supplierBiddingInfo.ibSupplierBidContactInfoList[1])) || Object.assign({},form);
          // if (!this.formOne.supplierBidContactAcctId) {
          //   this.formOne.supplierBidContactAcctId = ""
          // }
          // if (!this.formTwo.supplierBidContactAcctId) {
          //   this.formTwo.supplierBidContactAcctId = ""
          // }
          if (this.formOne.contactFileInfoList) {
            this.formOne.contactFileInfoList.forEach(item=>{
              if (item.fileType == "3") {
                this.formOne.pickPepoleCardName = item.attachName;
                this.formOne.pickPepoleCardUrl = item.attachContent;
                this.formOne.pickPepoleCardAttachUrl = item.attachUrl;
                this.formOne.pickPepoleCardOssFileId = item.ossFileId;
                // this.formOne.pickPepoleCardOssDelId = "";
              }else if (item.fileType == "4") {
                this.formOne.socialCertificateName = item.attachName;
                this.formOne.socialCertificateUrl = item.attachContent;
                this.formOne.socialCertificateAttachUrl = item.attachUrl;
                this.formOne.socialCertificateOssFileId = item.ossFileId;
                // this.formOne.socialCertificateOssDelId = "";
              }else if (item.fileType == "5") {
                this.formOne.biddingAuthorizationName = item.attachName;
                this.formOne.biddingAuthorizationUrl = item.attachContent;
                this.formOne.biddingAuthorizationAttachUrl = item.attachUrl;
                this.formOne.biddingAuthorizationOssFileId = item.ossFileId;
                // this.formOne.biddingAuthorizationOssDelId = "";
              }
            })
          }
          if (this.formTwo.contactFileInfoList) {
            this.formTwo.contactFileInfoList.forEach(item=>{
              if (item.fileType == "3") {
                this.formTwo.pickPepoleCardName = item.attachName;
                this.formTwo.pickPepoleCardUrl = item.attachContent;
                this.formTwo.pickPepoleCardAttachUrl = item.attachUrl;
                this.formTwo.pickPepoleCardOssFileId = item.ossFileId;
                // this.formTwo.pickPepoleCardOssDelId = "";
              }else if (item.fileType == "4") {
                this.formTwo.socialCertificateName = item.attachName;
                this.formTwo.socialCertificateUrl = item.attachContent;
                this.formTwo.socialCertificateAttachUrl = item.attachUrl;
                this.formTwo.socialCertificateOssFileId = item.ossFileId;
                // this.formTwo.socialCertificateOssDelId = "";
              }else if (item.fileType == "5") {
                this.formTwo.biddingAuthorizationName = item.attachName;
                this.formTwo.biddingAuthorizationUrl = item.attachContent;
                this.formTwo.biddingAuthorizationAttachUrl = item.attachUrl;
                this.formTwo.biddingAuthorizationOssFileId = item.ossFileId;
                // this.formTwo.biddingAuthorizationOssDelId = "";
              }
            })
          }
          this.formEnclosure.cooperationList = [];
          this.formEnclosure.othersList = [];
          if (this.supplierBiddingInfo.ossFileInfoList) {
            this.supplierBiddingInfo.ossFileInfoList.forEach(item=>{
              if (item.fileType == "6") {
                this.formEnclosure.cooperationList.push({
                  name:item.attachName,
                  attachUrl:item.attachUrl,
                  url:item.attachContent,
                  ossFileId:item.ossFileId,
                  del:false,
                })
              }else if (item.fileType == "7") {
                this.formEnclosure.othersList.push({
                  name:item.attachName,
                  attachUrl:item.attachUrl,
                  url:item.attachContent,
                  ossFileId:item.ossFileId,
                  del:false,
                })
              }
            })
          }
        }
      }
    },
    mounted() {
        this.$nextTick(()=>{
          this.$refs.formOne.clearValidate();
          this.$refs.formTwo.clearValidate();
        })
      this.getQuerySubordinate();
        this.init();

    }
  }
</script>

<style scoped lang="scss">
  /deep/ .el-row{
    overflow: visible;
  }
.contacts{
    margin-bottom: 0;

  /deep/ .el-col{
    height: 25px;
    line-height: 25px;
    font-size: 12px;
    /deep/ .el-form-item__label {
      font-size: 12px;
      width: auto !important;
    }
    /deep/ .el-form-item__content{
      font-size: 12px;
      margin-left: 0 !important;
    }
  }
}
.form{
  .el-form-item{
    margin-bottom: 12px !important;
  }
  /deep/ .el-input {
    width: 400px;
  }
}
  .enclosure{

    margin-top: 20px;
    /deep/ .el-form-item--small .el-form-item__label{
      line-height: 20px;
    }
    .el-form-item {
      margin-bottom: 0 !important;
    }
    /deep/ .el-form-item__label{
      color: #444 !important;
      width: 1100px !important;
      text-align: left;
    }
    /deep/ .el-form-item__content{
      position: relative;
    }
    /deep/ .el-form-item__error{
      position: absolute;
      left: -333px;
    }
    .pickPepoleCardUrl{
      /deep/ .el-form-item__error{
        position: absolute;
        left: -268px;
      }
    }
    .biddingAuthorizationUrl{
      /deep/ .el-form-item__error{
        position: absolute;
        left: -514px;
      }
    }
    a{
      position: absolute;
    }
    /deep/ .enclosure-content{
      font-size: 12px;
      margin-left: -268px;
      margin-top: 25px;
      width: 1190px;
      border: 1px solid #ddd;
      padding: 13px 10px;
      line-height: 17px;
      span{
        margin-right: 12px;
      }
    }
  }
  .enclosure-tip{
    width:100%;
    padding: 0 10px;
    height:30px;
    background:rgba(255,252,240,1);
    border:1px solid rgba(250,226,165,1);
    line-height: 30px;
    font-size: 12px;
  }
.detail{
  .el-form-item {
    margin-bottom: 0 !important;
  }
  .el-row {
    margin-bottom: 0;
  }
}
  .upload{

    /deep/ .el-input,input {
      position: absolute;
      left: -9999px;
      width: 0px;
      height: 0px;
      overflow: hidden;
      opacity: 0;
    }
  }
  .empty-text {
    height: 45px;
    line-height: 45px;
    text-align: center;
  }
</style>