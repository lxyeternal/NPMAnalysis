<template>
  <div class="paymentMethodContainer">
    <div class="head" v-if="isShowHead">
      <span>请选择或修改付款方式</span>
      <template>
        <el-radio-group v-model="paymentRadio">
          <el-radio v-for="item in configEntityList" :key="item.index" :label="item.index">{{item.code}}</el-radio>
        </el-radio-group>
      </template>
    </div>
    <div class="body" v-if="isShowHead">
      <div v-for="item in configEntityList.filter(fItem => fItem.index == paymentRadio)" :key="item.index">
        <textarea rows="6" maxlength="600" placeholder="请输入付款方式" class="el-textarea__inner" :value="item.value" @input="txtChange($event, item)" />
        </div>
    </div>
    <div class="body" v-else>
      <el-input rows="6" type="textarea" placeholder="请输入付款方式" ref="ipt" v-model="textValue" maxlength="600">
      </el-input>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    configEntityList: {
      type: Array
    },
    selectedKey: {
      type: Number,
      default: 0
    },
    isShowHead: {
      type: Boolean,
      default: true
    },
    inputValue: {
      type: String,
      default: ''
    },
    inputPaymentRadio: {
      type: Number,
      default: 0
    },
  },
  data() {
    return {
      paymentRadio: 0, // 单选按钮值
      textValue: this.inputValue, // 文本框值
    }
  },
  watch: {
    inputPaymentRadio: {
      handler() {
        this.paymentRadio = this.inputPaymentRadio || 0
      },
    },
    paymentRadio() {
      this.$emit('outRadioValue', this.paymentRadio)
      this.setEmit()
    },
    configEntityList: {
      handler() {
        this.setEmit()
      },
      // 深度监听 监听对象，数组的变化
      deep: true,

      // 初始化也监听
      immediate: true
    },
    selectedKey: {
      handler(newValue) {
        newValue && newValue.length && (this.paymentRadio = newValue)
      },

      // 初始化也监听
      immediate: true
    },
    textValue: {
      handler(newValue) {
        this.$emit('outValue', newValue.replace(/\n/g, '<br/>'))
      },
      // 初始化也监听
      immediate: true
    }
  },
  methods: {
    txtChange(ev, item) {
      this.$set(item, 'value', ev.target.value)
      this.$emit('outValue', item.value.replace(/\n/g, '<br/>'))
    },
    setEmit() {
      if (!this.configEntityList) return
      this.configEntityList.map((fItem, index) => {
        fItem.index = index
        if (fItem.index == this.paymentRadio) {
          this.$emit('outValue', fItem.value.replace(/\n/g, '<br/>'))
        }
      })
    }
  }
}
</script>
<style scoped lang="scss">
.paymentMethodContainer {
  /deep/ .el-textarea__inner {
    min-height: 144px !important;
  }
  .head {
    span {
      white-space: nowrap;
      color: #909399;
      font-size: 12px;
      margin-right: 32px;
      &::before {
        content: "*";
        color: #df0a0a;
        margin-right: 3px;
      }
    }
  }
  .body {
  }
}
</style>
