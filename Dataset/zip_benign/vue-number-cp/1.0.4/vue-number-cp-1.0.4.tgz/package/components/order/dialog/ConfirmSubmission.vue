<template>
  <div>
    <el-dialog class="dialog" title="确认提交合同" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="50%" center :close-on-click-modal="false">
      <p class="title">
        <span class="title-bg"></span>
        合同基本信息
      </p> 
      <div class="contract-info">
        <p>合同名称：{{confirmData.contractName}}</p>
        <p>合同类别：<span class="red">{{confirmData.orderCateFullName}}</span></p>
        <p>供应商：{{confirmData.corpName}}</p>
      </div>
      <p class="title money">
        <span class="title-bg"></span>
        合同价款
      </p>
      <div class="money-info">
        <div class="left" :class="{noRight:!confirmData.addRate || confirmData.majorCode === 'C63'}">
          <p class="left-info">
            <span class="left-fir">合同价款（不含税）：{{confirmData.totalSubmitMoney| formatMoney}}元</span><span class="left-sec">税率：{{confirmData.tax}}</span>
          </p>
          <p class="left-info">
            <span class="left-fir">合同价款（含税）：<i class="red">{{confirmData.totalSubmitMoney + confirmData.totalTax | formatMoney}}元</i></span><span class="left-sec">税额：{{confirmData.totalTax | formatMoney}}元</span>
          </p>
        </div>
        <div class="right" v-if="confirmData.addRate && confirmData.majorCode !== 'C63'">
          <p>
            货物供应合同加价费率：
          </p>
          <p class="big red">{{confirmData.addRate}}%</p>
        </div>
      </div>
      <template v-if="confirmData.isAgreementPrice">
        <p class="title money">
          <span class="title-bg"></span>
          授权码
        </p>
        <div class="contract-info">
          <div>货品清单包含协议价商品，请联系平台客服（
            <span class="red">客服电话：{{$platformContact()['hotLine']}}</span>）获取授权码（授权码10分钟内有效），才能创建协议价商品合同。</div>
          <!--<p>合同类别：<span class="red">{{confirmData.orderCateFullName}}</span></p>-->
          <!--<p>供应商：{{confirmData.corpName}}</p>-->
          <el-form ref="form" :model="form" :rules="rules" label-width="70px">
            <el-form-item label="授权码" prop="code">
              <el-input v-model="form.code" type="text" maxlength="10" placeholder="请输入平台客服给与的授权码"></el-input>
            </el-form-item>
          </el-form>
        </div>
      </template>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 120px" @click="handleConfirm">确定并提交</el-button>
        <el-button size="small" style="width: 120px" @click="dialogVisible = false">取消</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
export default {
  components: {
    Loading
  },
  props:{
    confirmData:{
      type: Object
    }
  },
  data() {
    return {
      isLoading: false,
      dialogVisible: false,
        form: {
            code: ""
        },
        rules: {
            code: [
                {
                    required: true,
                    message: "请输入授权码",
                    trigger: "blur"
                }
            ]
        }
    };
  },
  methods: {
    open(data) {
        this.dialogVisible = true;
    },
    handleConfirm() {
        if (this.confirmData.isAgreementPrice) {
            this.$refs["form"].validate(valid => {
                if (valid) {
                    this.dialogVisible = false;
                    this.$emit("goToSub", this.form.code);
                    // this.$emit('goToSub');
                }
            });
        }else {
            this.dialogVisible = false;
            this.$emit("goToSub");
        }
    }
  }
};
</script>

<style lang="scss" scoped>
.dialog {
  line-height: 25px;
}
.title{
  position: relative;
  height: 12px;
  line-height: 12px;
  padding-left: 10px;
  text-align: left;

  .title-bg{
    width: 3px;
    height: 12px;
    position: absolute;
    background: #4f525a;
    top: 0;
    left: 0;
  }
}
.title.money{
  height: 34px;
  line-height: 34px;

  .title-bg{
    top: 11px;
    left: 0;
  }
}
.contract-info{
  padding-left: 10px;
  margin-top: 6px;
  text-align: left;
  margin-bottom: 10px;
  p{
    line-height: 26px;
    height: 26px;
  }
  div{
    margin-bottom: 10px;
  }
}
.money-info{
  width: 100%;
  height: 82px;
  overflow: hidden;

  .left{
    float: left;
    width: 75%;
    background: #fef4f3;
    height: 82px;
    padding: 16px 0 0 12px;

    .left-info{
      height: 26px;
      line-height: 26px;

      .left-fir{
        float: left;
        width: 60%;
      }
      .left-sec{
        float: left;
        width: 30%;
      }
    }
  }

  .left.noRight{
    width: 100%;
  }

  .right{
    float: right;
    width: 24%;
    background: #fef4f3;
    height: 82px;
    padding-top: 16px;
    text-align: center;

    p{
      height: 26px;
      line-height: 26px;
    }
    p.big{
      font-size: 16px;
    }
  }
}
.red{
  color: #e93d49;
}
</style>
