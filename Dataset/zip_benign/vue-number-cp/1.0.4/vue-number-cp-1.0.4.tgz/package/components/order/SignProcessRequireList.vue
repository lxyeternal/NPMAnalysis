<template>
  <div class="tl">
    <div class="process-content" v-if="processType=='delivery'">
      <div class="tl inline">
        <div class="tc inline yellow">要货单签署进度&nbsp;|&nbsp;</div>采购商：
        <template v-for="(p) in dPurchaserList">
          <span :class="{green : p.processFlg == '1',red:p.processFlg == '0'}">{{p.roleName}}{{p.processFlg == '1' ? p.sealType !== '1' ? '已盖章' : '已签字' : p.sealType !== '1' ? '待盖章' : '待签字' }}</span><i>→</i>
        </template>
        <!--<span>项目部材料管理员已签字</span><i>→</i>-->
        <!--<span>项目部授权代表待签字</span><i>→</i>-->
        <!--<span>项目部待盖章</span><i>→</i>-->
        <!--<el-tooltip v-for="(item,index) in projectList" :key="index" effect="dark" :content="showTipText(item)" placement="top" :enterable="false">-->
        <!--<i :class="filterIconName(item)"></i>-->
        <!--</el-tooltip>-->
      </div>
      <div class="tl inline">供应商：
        <template v-for="(p,index) in dSupplierList">
          <span :class="{green : p.processFlg == '1',red:p.processFlg == '0'}">{{p.roleName}}{{p.processFlg == '1' ? p.sealType !== '1' ? '已盖章' : '已签字' : p.sealType !== '1' ? '待盖章' : '待签字' }}</span><i v-if="index === 0">→</i>
        </template>
      </div>
    </div>
    <div class="process-content" v-if="processType=='receive'">
      <div class="tl inline">
        <div class="tc inline yellow">验收单签署进度&nbsp;|&nbsp;</div>采购商：
        <template v-for="(p,index) in dPurchaserList">
          <span :class="{green : p.processFlg == '1',red:p.processFlg == '0'}">{{p.roleName}}{{p.processFlg == '1' ? p.sealType !== '1' ? '已盖章' : '已签字' : p.sealType !== '1' ? '待盖章' : '待签字' }}</span><i>{{index === 0 ? '→' : index === dPurchaserList.length-1 ? '' : '-'}}</i>
        </template>
        <!--<span>项目部材料管理员已签字</span><i>→</i>-->
        <!--<span>项目部授权代表待签字</span><i>→</i>-->
        <!--<span>项目部待盖章</span><i>→</i>-->
        <!--<el-tooltip v-for="(item,index) in projectList" :key="index" effect="dark" :content="showTipText(item)" placement="top" :enterable="false">-->
        <!--<i :class="filterIconName(item)"></i>-->
        <!--</el-tooltip>-->
      </div>
      <div class="tl inline">供应商：
        <template v-for="(p,index) in dSupplierList">
          <span :class="{green : p.processFlg == '1',red:p.processFlg == '0'}">{{p.roleName}}{{p.processFlg == '1' ? p.sealType !== '1' ? '已盖章' : '已签字' : p.sealType !== '1' ? '待盖章' : '待签字' }}</span><i v-if="index === 0">-</i>
        </template>
      </div>
      <div class="tl inline">施工单位：
        <template v-for="(p,index) in constructionList">
          <span :class="{green : p.processFlg == '1',red:p.processFlg == '0'}">{{p.roleName}}{{p.processFlg == '1' ? p.sealType !== '1' ? '已盖章' : '已签字' : p.sealType !== '1' ? '待盖章' : '待签字' }}</span><i v-if="index === 0">-</i>
        </template>
      </div>
    </div>
    <!--<div class="process-content" v-if="processType=='receive'">-->
    <!--<div class="tc inline">{{receiveName}}</div>-->
    <!--<div class="tl inline">要料施工单位-->
    <!--<el-tooltip v-for="(item,index) in builderList" :key="index" effect="dark" :content="showTipText(item)" placement="top" :enterable="false">-->
    <!--<i :class="filterIconName(item)"></i>-->
    <!--</el-tooltip>-->
    <!--</div>-->
    <!--<div class="tl inline">监理单位-->
    <!--<el-tooltip v-for="(item,index) in supervisorList" :key="index" effect="dark" :content="showTipText(item)" placement="top" :enterable="false">-->
    <!--<i :class="filterIconName(item)"></i>-->
    <!--</el-tooltip>-->
    <!--</div>-->
    <!--<div class="tl inline">项目公司-->
    <!--<el-tooltip v-for="(item,index) in projectList" :key="index" effect="dark" :content="showTipText(item)" placement="top" :enterable="false">-->
    <!--<i :class="filterIconName(item)"></i>-->
    <!--</el-tooltip>-->
    <!--</div>-->
    <!--<div class="tl inline">供应商-->
    <!--<el-tooltip v-for="(item,index) in vendorList" :key="index" effect="dark" :content="showTipText(item)" placement="top" :enterable="false">-->
    <!--<i :class="filterIconName(item)"></i>-->
    <!--</el-tooltip>-->
    <!--</div>-->
    <!--</div>-->
  </div>
</template>

<script>
import { getSealRoles } from "@/utils/orderUtil";
export default {
  data() {
    return {
      processType: "", // 'delivery': 发货，'receive': '验收'
      dPurchaserList: [],
      dSupplierList: [],
      constructionList: [],
      projectList: [],
      supervisorList: [],
      vendorList: []
    };
  },
  props: ["order"],
  watch: {
    order() {
      this.init();
    }
  },
  methods: {
    init() {
      this.processType = "";
      this.dPurchaserList = [];
      this.dSupplierList = [];
      this.constructionList = [];
      if (this.order.eventList && this.order.eventList) {
        this.order.eventList.forEach(ev => {

          if (ev.documentType == '01' && ev.eventStatus != 2) {
            ev.processList.forEach(pro => {
              if (pro.role[0] === '3') {
                this.dSupplierList.push(pro)
              } else if (pro.role[0] === '2') {
                this.dPurchaserList.push(pro)
              }
            })
          } else if (ev.documentType == '02' && ev.eventStatus != 2) {
            ev.processList.forEach(pro => {
              if (pro.role[0] === '3') {
                this.dSupplierList.push(pro)
              } else if (pro.role[0] === '2') {
                this.dPurchaserList.push(pro)
              } else if (pro.role[0] === '0') {
                this.constructionList.push(pro)
              }
            })
          }
          if (ev.eventType == 1 && ev.eventStatus != 2) {
            this.processType = "delivery";
          } else if (ev.eventType == 2 && ev.eventStatus != 2) {
            this.processType = "receive";
          }
        })
      }
      // this.dSupplierList.forEach(item=>{
      //   let num = 0;
      //   item.processFlg = this.order.eventList.forEach(ev=>{
      //     if (ev.eventType == 1) {
      //       ev.processList.forEach(pro=>{
      //         if (item.role === pro.role && pro.processFlg === '1'){
      //           num ++
      //         }
      //       })
      //     }
      //   });
      //   item.processFlg = num === 2
      // });
      // this.dPurchaserList.forEach(item=>{
      //   let num = 0;
      //   item.processFlg = this.order.eventList.forEach(ev=>{
      //     if (ev.eventType == 1) {
      //       ev.processList.forEach(pro=>{
      //         if (item.role === pro.role && pro.processFlg === '1'){
      //           num ++
      //         }
      //       })
      //     }
      //   });
      //   item.processFlg = num === 2
      // });
      // this.dPurchaserList[0] = this.dPurchaserList.splice(1, 1, this.dPurchaserList[0])[0];
    }
  },
  mounted() {
    this.init();
  }
};
</script>

<style lang="scss" scoped>
.process-content {
  padding: 5px;
  color: #888888;
  display: flex;
  div {
    margin-left: 16px;
    &:first-child {
      margin-left: 0;
    }
  }
}
.inline {
  display: inline-block;
  /*margin-right: 18px;*/
  /*i {*/
  /*width: 20px;*/
  /*height: 20px;*/
  /*margin-left: 5px;*/
  /*vertical-align: middle;*/
  /*}*/
}
.inline:first-child {
}
</style>
