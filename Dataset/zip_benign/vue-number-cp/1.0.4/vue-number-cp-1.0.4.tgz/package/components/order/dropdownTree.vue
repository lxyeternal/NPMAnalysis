<template>
  <div class="tendering-category" :style="{width}">
    <div :class="['title-container' ,{active: isShowSelector}, {disabled},{'color-ccc': biddingCategoryTitle == '请选择'}]" :title="biddingCategoryTitle" @click="!disabled && (isShowSelector = !isShowSelector)">
      {{biddingCategoryTitle || ''}}
    </div>
    <div class="body-container" v-if="isShowSelector">
      <div class="head">
        <el-select v-model="selectValue" filterable placeholder="请输入关键字" @change="handleQickSelect">
          <el-option v-for="item in quickSeach" :key="item.value" :label="item.label" :value="item">
          </el-option>
        </el-select>
        <i class="close el-icon-circle-close" @click="handleClose" title="关闭"></i>
      </div>
      <div class="center">
        <ul>
          <li v-for="item in treeData" :key="item.categoryId" @click="handleClick(treeData, item, 1)" :class="{active: item.active}">
            <span :title="item.categoryName">{{item.categoryName}}</span>
          </li>
        </ul>
        <ul>
          <li v-for="item in treeData2.children" :key="item.categoryId" @click="handleClick(treeData2.children, item, 2)" :class="{active: item.active}">
            <span :title="item.categoryName">{{item.categoryName}}</span>
          </li>
        </ul>
        <ul>
          <li v-for="item in treeData3Computed" :key="item.categoryId" @click="handleClick(treeData3.children, item, 3)" :class="{active: item.active}">
            <span :title="item.categoryName">{{item.categoryName}}</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
  import { InterfaceService } from "@/services/api"

  export default {
    props: {
      value: {
        // 反显值 - 最后一类被选中的值
        default: ''
      },
      // 宽度
      width: {
        type: String,
        default: '200px'
      },
    // 反显 list
    dataList: {
      type: Array,
      default: () => {
        return []
      }
    },
      // 是否禁用
      disabled: {
        type: Boolean,
        default: false
      },
      // 是否显示加工费
      isShowprocessingFee: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        treeData: [], // 一级目录
        treeData2: [], // 二级目录
        treeData3: [], // 三级目录
        quickSeach: [], // 查询目录
        selectValue: '', // 搜索结果
        selectItem: {}, // 选中对象
        biddingCategoryTitle: '请选择 ', // 招标类目名称
        isShowSelector: false, // 是否展示选择器
        timer: null, // 定时器
        outputValue: '', // 向父组件传递数据
        firstLoding: false, // 首次加载
      }
    },
    computed: {
      treeData3Computed() {
        let item = this.treeData3 && this.treeData3.children || []
        // 是否过滤加工费
        if (!this.isShowprocessingFee) {
          item = item.filter(f => f.type !== 'processingFee') || []
        }
        return item
      }
    },
    watch: {
      treeData: {
        deep: true,
        handler(newVal, oldVal) {
          let firstOnOff = this.treeData.some(item=>{
            return item.active
          })
          let secondOnOff
          this.treeData.forEach(item=>{
            secondOnOff = item.children.some(item=>{
              return item.active
            })
          })
          this.biddingCategoryTitle = firstOnOff ||  secondOnOff ? '' : '请选择 ';
          this.getSelectValue(this.treeData || [])
          this.biddingCategoryTitle = this.biddingCategoryTitle.slice(0, this.biddingCategoryTitle.length - 1)
          // 去前后空格
          this.biddingCategoryTitle.replace(/(^\s*)|(\s*$)/g, "")
          this.getFullCategoryInfo(this.outputValue)
          this.firstLoding && this.$emit('input', this.outputValue)
          this.firstLoding = true
        }
      },

    dataList: {
      deep: true,
      handler(newVal, oldVal) {
        if (!this.unUpdate) return
        console.log('watch - dataList', newVal, oldVal);
        if (this.firtDataList) {
          // 设置第三级显示
          let treeItem = {
            key1: [],
            key2: [],
            key3: []
          }

          this.dataList.forEach(f => {
            treeItem.key3.push(f.categoryId)
            // 通过 parentId 查找 categoryId
            const searchParentId = (list, parentId) => {
              list.some(s => {
                // 通过 parentId 匹配 父级
                if (s.categoryId == parentId) {

                  treeItem[`key${Number(s.categoryLevel)}`].push(s.categoryId)

                  // 如果不是 第一级 继续往上查找
                  if (s.parentId != '1') {
                    searchParentId(this.treeData, s.parentId)
                  }
                  return true
                }
                if (s.children && s.children.length) {
                  searchParentId(s.children, parentId)
                }
              })
            }
            searchParentId(this.treeData, f.parentId)

          })
          if (this.treeData && this.treeData.length) {
            this.firtDataList = false
          }
          treeItem = {
            key1: [...new Set(treeItem.key1)],
            key2: [...new Set(treeItem.key2)],
            key3: [...new Set(treeItem.key3)],
          }
          this.initResultData(treeItem)
          this.installSelectValues(this.treeData)
        }
      }
    },

      value(val, newVal) {
        if (this.value) {
          this.initTreeData()
        }
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      async init() {
        await this.getCategory()
        this.initTreeData()
      },

      /**
       * 初始化类目树
       */
      initTreeData() {
        let inputItem = []
        for (let i = 0, len = this.quickSeach.length; i < len; i++) {
          const item = this.quickSeach[i]
          // 在数组中找出与传入数据相匹配的类目 数据
          if (item.value == this.value) {
            inputItem = item
            break
          }
        }
        this.handleQickSelect(inputItem)
      },
      handleClose() {
        if (!this.value) {
          this.biddingCategoryTitle = '请选择 ';
        }
        this.isShowSelector = false
      },
      getFullCategoryInfo(categoryId) {
        if (categoryId) {
          this.treeData.forEach((i,ind)=>{
            i.children.forEach((item,index)=>{
              item.children.forEach((_item,_index)=>{
                if (_item.categoryId == categoryId) {
                  let categoryInfo = {
                    categoryId : categoryId,
                    fullName : this.biddingCategoryTitle.split('/').join('-'),
                    parentId : item.categoryId,
                    originalId : i.categoryId,
                  };
                  this.$emit("categoryInfo",categoryInfo)
                }
              })
            })
          })
        }
      },
      arrangementList() {
        this.treeData.map((item1, idx1) => {
          this.$set(item1, 'active', false)
          item1.children.map((item2, idx2) => {
            this.$set(item2, 'active', false)
            item2.children.map((item3, idx3) => {
              this.$set(item3, 'active', false)
              // `CATEGORY_TYPE` varchar(32) DEFAULT NULL COMMENT '类目类型（materialType:材料类型, processingFee:加工费类型）',
              // 显示加工费 - 快速搜索关键字显示
              if (this.isShowprocessingFee) {
                this.quickSeach.push({
                  label: `${item1.categoryName}-${item2.categoryName}-${item3.categoryName}`,
                  value: item3.categoryId,
                  key1: item1.categoryId,
                  key2: item2.categoryId
                })
              } else if (item3.type !== 'processingFee') {
                this.quickSeach.push({
                  label: `${item1.categoryName}-${item2.categoryName}-${item3.categoryName}`,
                  value: item3.categoryId,
                  key1: item1.categoryId,
                  key2: item2.categoryId
                })
              }
            })
          })
        })
      },
      /**
       * 获取类目
       */
      getCategory() {
        return new Promise(resolve => {
          let categoryList = this.$getRootScope('categoryList')
          if (categoryList) {
            this.treeData = JSON.parse(categoryList)
            this.arrangementList()
          } else {
            InterfaceService.getCategoryList(
              {
                categoryId:"1",
                queryType:"2",
              },
              data => {
                //console.log(data);
                if (data.respData.respCode === "0000") {
                  let res = data.respData.categoryInfos || []
                  this.$store.commit('changeCategoryList', res)
                  this.$setRootScope('categoryList', JSON.stringify(res))
                  this.treeData = res;
                  this.arrangementList();
                } else {
                  this.$message.error(data.respData.respMsg);
                }
              },
              data => { },
              () => {
                this.isLoading = true;
              },
              () => {
                this.isLoading = false;
              }
            );
          }
          // InterfaceService.getCategoryList(res => {

          console.log(this.treeData);
          resolve(this.treeData)
          // })
        })
      },

      /**
       * 类目被点击重置及设置选中状态
       * @param list: 同级list
       * @param dataItem: 当前对象
       * @param state: 点击层级 - 1 第一级  2 第二级
       */
      handleClick(list = [], dataItem, state) {
        this.selectValue = ''
        // 先重置选中状态
        list.forEach(item => {
          item.active = false
          const treeData = item.children || []
          this.resetTreeData(treeData)
        })
        dataItem.active = true
        switch (state) {
          case 1:
            this.treeData2 = dataItem
            this.treeData3 = []
            break
          case 2:
            this.treeData3 = dataItem
            break
          case 3:
            this.isShowSelector = false
            break
        }
      },

      /**
       * 重置数据状态
       */
      resetTreeData(treeData = []) {
        treeData.forEach((item, idx) => {
          this.$set(item, 'active', false)
          if (item.children && item.children.length) {
            this.resetTreeData(item.children)
          }
        })
      },

      /**
       * 快速搜索 或 初始化数据反显
       */
      handleQickSelect(inputValue) {
        const { value, key1, key2 } = inputValue || this.selectValue,
          treeData = this.treeData || []
        this.resetTreeData(treeData)
        this.setTreeDataStateBySearch(key1, treeData, 1)
        this.setTreeDataStateBySearch(key2, treeData, 2)
        this.setTreeDataStateBySearch(value, treeData)

        Object.keys(inputValue).length && (this.isShowSelector = false)
      },

      /**
       * 通过搜索设置数据状态
       */
      setTreeDataStateBySearch(key, treeData, state) {
        treeData.map(item => {
          if (key === item.categoryId) {
            item.active = true
            switch (state) {
              case 1:
                this.treeData2 = item
                break
              case 2:
                this.treeData3 = item
                break
            }
          }

          if (item.children && item.children.length) {
            this.setTreeDataStateBySearch(key, item.children, state)
          }
        })
      },

      /**
       * 获取选中数据
       */
      getSelectValue(treeData = []) {
        treeData.map(item => {
          if (item.active) {
            this.outputValue = ''
            this.biddingCategoryTitle += `${item.categoryName}/`
            // 找到最后一级
            if (!item.children || !item.children.length) {
              this.outputValue = item.categoryId
            }
          }

          if (item.children && item.children.length) {
            this.getSelectValue(item.children)
          }
        })
      },
    }
  }
</script>

<style lang="scss" scoped>
  .tendering-category {
    $borderStyle: 1px solid #e2e2e2;
    .title-container {
      background: #fff;
      border: 1px solid #dcdfe6;
      transition: all 0.3s linear;
      box-sizing: border-box;
      padding: 0 12px;
      position: relative;
      height: 42px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      &::after {
        content: "";
        display: inline-block;
        border-style: solid;
        border-width: 4px;
        border-color: transparent transparent #dcdfe6 #dcdfe6;
        position: absolute;
        right: 12px;
        top: 14px;
        transform: rotate(-45deg);
        transition: all 0.3s linear;
      }
      &.active {
        border-color: #ffd64e;
        &::after {
          top: 20px;
          transform: rotate(135deg);
        }
      }
      &.disabled {
        border: 0;
        background: transparent;
        &::after {
          display: none;
        }
      }
    }
    .body-container {
      background: #fff;
      border: 1px solid #e2e2e2;
      box-shadow: 0 5px 5px rgba(0, 0, 0, 0.1);
      width: 500px;
      margin-top: -1px;
      z-index: 12;
      position: absolute;
      padding: 12px;
      .close {
        border-radius: 50%;
        position: absolute;
        right: 10px;
        top: 10px;
        border: 1px solid #eaeaea;
        transition: all 0.3s linear;
        cursor: pointer;
        &:hover {
          border-color: #ffd64e;
        }
      }
      .center {
        border: $borderStyle;
        border-right-width: 0;
        margin-top: 12px;
        display: flex;
        /deep/ ::-webkit-scrollbar {
          width: 4px;
        }
        ul {
          height: 300px;
          overflow: auto;
          width: 33.3333%;
          border-right: $borderStyle;
          scrollbar-track-color: #fff; // 背景
          scrollbar-arrow-color: #fff; // 箭头
          scrollbar-shadow-color: #fff; // 滚动条边框
          &:not(:last-child) {
            li {
              &::after {
                content: ">";
                position: absolute;
                color: #606266;
                right: 20px;
              }
            }
          }
          li {
            padding: 0 20px;
            height: 35px;
            cursor: pointer;
            position: relative;
            &.active {
              background: linear-gradient(120deg,rgba(215,176,100,1) 0%,rgba(236,206,139,1) 100%);
              &::after {
                font-weight: bold;
                color: #fff;
              }
              span {
                font-weight: bold;
                color: #fff;
              }
            }
            span {
              color: #606266;
              font-size: 14px;
              overflow: hidden;
              width: 90%;
              white-space: nowrap;
              display: inline-block;
              text-overflow: ellipsis;
              text-align: left;
            }
          }
        }
      }
    }
    .color-ccc{
      color: #ccc;
    }
    /deep/ .el-input__inner {
      border-color: #dcdfe6 !important;
    }
  }
</style>
