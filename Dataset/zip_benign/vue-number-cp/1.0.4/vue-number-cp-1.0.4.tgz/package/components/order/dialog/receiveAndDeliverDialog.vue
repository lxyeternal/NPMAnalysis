<template>
  <transition name="el-zoom-in-bottom">
    <div class="box" v-show="showBox">
      <div class="addMockList">
        <div class="content">
          <div class="title tc">收发货明细</div>
          <div class="center">
            <RequireGoodsListItem v-if="Object.keys(goodsItem).length" :showAddrInfo="false" :goodsItem="goodsItem"></RequireGoodsListItem>
          </div>
        </div>
        <!-- 按钮 -->
        <div class="foot">
          <template v-if="goodsItem.details && goodsItem.details.some(i=>{return i.attachList.length})">
            <el-button type="primary" @click="handleBatchDownload">下载附件</el-button>
          </template>
          <el-button @click="showBox = false">关闭</el-button>
        </div>
      </div>
      <Loading :is-loading="isLoading"></Loading>
    </div>
  </transition>
</template>
<script>
  import { InterfaceService } from "@/services/api";
  import RequireGoodsListItem from "@/components/order/RequireGoodsListItem";
  import Loading from '@/components/base/Loading'

  export default {
    data() {
      return {
        showBox: false,
        isLoading: false,
        isCheckGoods: false,
        deliverFlg: false,
        goodsItem: {},
      }
    },
    components:{
      RequireGoodsListItem,
      Loading,
    },

    methods: {
      handleBatchDownload() {
        let fileInfoBeans = []
        this.goodsItem.details.forEach(f => {
          f.attachList && f.attachList.some(s => {
            if (s.attachType === '0') {
              fileInfoBeans.push({
                archivePath : '要货附件/' + `${f.label}/` + s.attachName,
                fileUrl: s.attachUrl
              })
            }else if (s.attachType === '2') {
              fileInfoBeans.push({
                archivePath : '验收附件/' + `${f.label}/` + s.attachName,
                fileUrl: s.attachUrl
              })
            }
          })
        })
        console.log(fileInfoBeans, '-fileInfoBeans');

        this.packageDownload(fileInfoBeans, `${this.goodsItem.skuName}.zip`)
      },

      packageDownload(fileInfoBeans, fileName) {
        if (!(fileInfoBeans && fileInfoBeans.length)) return
        let params = {
          fileInfoBeans: fileInfoBeans,
          protocol: "https",
        };
        InterfaceService.packageDownload(
          params,
          data => {          let res = data.respData || {};
            if (data && data.respData && res.respCode === "0000") {
              const files = [
                { name: fileName, url: res.externalFileUrl }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              })
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => {
            this.$message.error(data.respData.respMsg)
          }, () => {
            this.isLoading = true
          }, () => {
            this.isLoading = false
          })
      },
      open(item,isCheckGoods,deliverFlg) {
        this.goodsItem = item || {};
        this.showBox = true;
        this.isCheckGoods = isCheckGoods === 'checkGoods'
        this.deliverFlg = deliverFlg === 'deliverFlg'
      },
    },

    mounted() {
    }
  }
</script>
<style lang="scss" scoped>
  .box {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    overflow: auto;
    margin: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 2001;
    .addMockList {
      max-height: 80%;
      overflow: auto;
      position: absolute;
      left: 0;
      bottom: 0;
      width: 100%;
      background-color: #fff;
      .content {
        width: 1190px;
        margin: 0 auto;
        font-size: 14px;
        line-height: 17px;
        .title {
          padding: 20px 0;
          // border-bottom: 1px solid #eee;
          // margin-bottom: 20px;
        }

      }
      .foot {
        width: 100%;
        margin-top: 40px;
        height: 57px;
        background: rgba(49, 49, 49, 0.9);
        line-height: 57px;
        text-align: center;
        .el-button {
          width: 120px;
          height: 34px;
          line-height: 34px;
          padding: 0;
          font-size: 12px;
        }
        .el-button--primary {
          color: #fff;
          border: none;
          background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
        }
      }
    }
  }
</style>