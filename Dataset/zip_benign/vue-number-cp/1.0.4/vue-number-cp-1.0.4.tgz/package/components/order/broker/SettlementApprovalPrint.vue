<template>
    <div class="borkerApprovalPrint">
        <div class="head">
            <img src="../../../assets/images/logo.png" alt=""/>
            <div class="title">
                <div class="top">
                    <p>上海博置结算审批</p>
                    <span>Settlement Approval</span>
                </div>
                <!--<div class="bottom">-->
                    <!--编号(ERP编号): {{settleInfo.erpBusiCode}}-->
                <!--</div>-->
            </div>
            <div class="body">
                <table width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            结算主题
                        </td>
                        <td w20 colspan="3">
                            {{settleInfo.settleName}}
                        </td>
                    </tr>
                </table>
                <table class="mt0" width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            申请人
                        </td>
                        <td w8>
                            {{settleInfo.signAcctName}}
                        </td>
                        <td w4 class="title">
                            部门
                        </td>
                        <td w8>
                            博置-招采合约部
                        </td>
                    </tr>
                </table>
                <table width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            合同名称
                        </td>
                        <td w20 colspan="3">
                            《{{settleInfo.contractName}}》
                        </td>
                    </tr>
                    <tr>
                        <td w4 class="title">
                            合同编号
                        </td>
                        <td w20 colspan="3">
                            {{settleInfo.orderNo}}
                        </td>
                    </tr>
                </table>
                <table class="mt0" width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            城市公司
                        </td>
                        <td w8>
                            {{settleInfo.cityCompany}}
                        </td>
                        <td w4 class="title">
                            项目名称
                        </td>
                        <td w8>
                            {{settleInfo.projectName}}
                        </td>
                    </tr>

                    <tr>
                        <td w4 class="title">
                            甲方
                        </td>
                        <td w8>
                            <p>{{settleInfo.brokerName}}元</p>
                        </td>
                        <td w4 class="title">
                            乙方
                        </td>
                        <td w8>
                            {{settleInfo.supplierName}}
                        </td>
                    </tr>
                    <tr>
                        <td w4 class="title">
                            合同金额（含税）
                        </td>
                        <td w8>
                            <p>{{settleInfo.outContractAmount || settleInfo.erpContractAmount | formatMoney}}元</p>
                            <p>{{capitalization(settleInfo.outContractAmount || settleInfo.erpContractAmount)}}</p>
                        </td>
                        <td w4 class="title">
                            最终结算金额
                        </td>
                        <td w8>
                            <p>{{settleInfo.outSettleAmount || settleInfo.erpSettleAmount | formatMoney}}元</p>
                            <p>{{capitalization(settleInfo.outSettleAmount || settleInfo.erpSettleAmount)}}</p>
                        </td>
                    </tr>
                </table>
                <table width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            结算变动率
                        </td>
                        <td w8>
                            <template v-if="startFlag">
                                {{compRateOfChange()}}
                            </template>
                            <template v-else>
                                {{Number(settleInfo.outSettleChgRate).toFixed(2) * 100 + '%' }}
                            </template>
                        </td>
                        <td w4 class="title">
                            竣工日期
                        </td>
                        <td w8>
                            {{settleInfo.completionDt}}
                        </td>
                    </tr>
                    <tr>
                        <td w4 class="title">
                            保修到期日期
                        </td>
                        <td w8>
                            {{settleInfo.guaranteeDt}}
                        </td>
                        <td w4 class="title">
                            结算提报日期
                        </td>
                        <td w8>
                            {{settleInfo.outSettleDt}}
                        </td>
                    </tr>
                </table>
                <table width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            结算说明
                        </td>
                        <td w20 colspan="3">
                            {{settleInfo.outSettleRemark || settleInfo.erpSettleRemark}}
                        </td>
                    </tr>
                </table>
                <ul>
                    <li><span>流转意见</span></li>
                    <li  v-for="(item,index) in settleInfo.execFlowList" :key="index" :class="{'isAgree': computedCirculationState(item).isAgree}">
                        <dl>
                            <dt>{{item.acctName}}</dt>
                            <dd class="color888888">{{item.roleName}}</dd>
                        </dl>
                        <dl>
                            <dt>{{computedCirculationState(item).state}}</dt>
                            <!--  -->
                            <dd class="color888888">{{item.finishTm}}</dd>
                        </dl>
                        <dl v-if="item.comment">
                            <dt>{{computedCirculationState(item).reason}}:</dt>
                            <dd :title="item.comment" v-html="item.comment.replace(/\n/g, '<br/>')"></dd>
                        </dl>
                    </li>
                </ul>
            </div>

            <div class="foot">
                编号(ERP编号): {{settleInfo.erpBusiCode}}
            </div>
        </div>
    </div>
</template>

<script>
    import { capitalizationAmount } from '@/utils/moneyUtil';
    export default {
        props: ["settleInfo","startFlag"],
        data() {
            return {
                data: []
            };
        },
        computed:{
            computedCirculationState() {
                return (item) => {
                    // item.isAgree === "Y" ? "审批意见" : "退回原因"
                    let result = {};
                    if (item.taskId === 'canceled') {
                        result.state = '撤回审批'
                        result.reason = '审批意见'
                    } else {
                        if (item.fwStatus == '1' || item.fwStatus == '2' ) {
                            result.state = item.fwStatus == '1' ? `转发${item.fwRoleName || ''}` : '批注'
                            result.reason =  item.fwStatus == '1' ? `转发内容` : '批注内容'
                        } else {
                            result.state = item.isAgree === "Y" ? "审批通过" : "审批退回"
                            result.reason = item.isAgree === "Y" ? "审批意见" : "退回原因"
                            result.isAgree = item.isAgree === "N"
                        }
                    }
                    return result
                }
            },

            capitalization(){
                return (item) =>{
                    let fuhao = "";
                    let text = item + "";
                    if (text.indexOf("-") > -1) {
                        item = text.replace("-", "");
                        fuhao = "负"
                    }
                    let money1 = new Number(item);
                    let monee = Math.round(money1 * 100).toString(10);
                    let leng = monee.length;
                    let monval = "";
                    for (let i = 0; i < leng; i++) {
                        monval = monval + capitalizationAmount.to_upper(monee.charAt(i)) + capitalizationAmount.to_mon(leng - i - 1)
                    }
                    return fuhao + capitalizationAmount.repace_acc(monval)
                }
            }
        },
        methods:{
            compRateOfChange(){
                let num = 0
                if (this.settleInfo.outSettleInfoStatus === 'init') {
                    num = ((Number(this.settleInfo.erpSettleAmount) - Number(this.settleInfo.erpContractAmount)) / Number(this.settleInfo.erpContractAmount)).toFixed(2) * 100
                }else {
                    num = ((Number(this.settleInfo.outSettleAmount) - Number(this.settleInfo.outContractAmount)) / Number(this.settleInfo.outContractAmount)).toFixed(2) * 100
                }
                if (isNaN(num)) {
                    return "合同金额（含税）或最终结算金额填写有误，请确认后重新填写"
                }else {
                    return num + "%"
                }
            },
        },
        mounted(){
        }
    }
</script>

<style scoped lang="scss">
    .PageNext {
        page-break-before: always;
    }

    .borkerApprovalPrint {
        font-size: 10pt;
        min-height: 9.7cm;
        width: 28.4cm;
        margin-top: 42px;
        .head {
            text-align: center;
            position: relative;
            img {
                position: absolute;
                width: 135px;
                height: 58px;
                left: 10px;
            }
            .title {
                color: #000;
                .top {
                    p {
                        font-size: 16pt;
                        margin-bottom: 8px;
                    }
                    span {
                        font-size: 13pt;
                    }
                }
                .bottom {
                    margin-top: 22px;
                    text-align: right;
                }
            }
            .body {
                $borderStyle: 1px solid #bbb;
                margin-top: 14px;
                box-sizing: border-box;
                color: #000;
                table {
                    border-top: $borderStyle;
                    margin-top: 24px;
                    table-layout:fixed;
                    [h0] {
                        height: 0 !important;
                        overflow: hidden;
                        td {
                            height: 0;
                            padding: 0;
                            border: 0;
                        }
                    }
                    .ofa{
                        overflow: visible;
                        white-space:nowrap;
                    }
                    .bln{
                        border-left: none;
                    }
                    td {
                        padding: 5px;
                        border-left: $borderStyle;
                        border-bottom: $borderStyle;
                        font-size: 10pt;
                        text-align: left;
                        vertical-align: middle;
                        &.bold {
                            font-weight: bold;
                        }
                        &[w3] {
                            width: calc(1000px / 24 * 3);
                        }
                        &[w4] {
                            width: calc(1000px / 24 * 4);
                        }
                        &[w6] {
                            width: calc(1000px / 24 * 6);
                        }
                        &[w8] {
                            width: calc(1000px / 24 * 8);
                        }

                        &[w14] {
                            width: calc(1000px / 24 * 14);
                        }
                        &[w20] {
                            width: calc(1000px / 24 * 20);
                        }
                        &[colspan="3"] {
                            p {
                                word-wrap: break-word;
                                width: 849px;
                            }
                        }
                        &.w173 {
                            width: 173px;
                        }
                        &:last-child {
                            border-right: $borderStyle;
                        }
                        &.title {
                            background: #e7f3fc;
                        }
                        p {
                            &:last-child {
                                margin-top: 4px;
                            }
                        }
                        pre {
                            line-height: 20px;
                            white-space: pre-line;
                        }
                    }
                }
                ul {
                    margin-top: 22px;
                    border: $borderStyle;
                    padding: 20px;
                    display: table;
                    width: 100%;
                    li {
                        text-align: left;
                        font-size: 10pt;
                        color: #000;
                        display: table-row;
                        width: 100%;
                        & > span {
                            display: block;
                        }
                        &:first-child {
                            font-size: 12pt;
                            span {
                                margin-bottom: 11px;
                            }
                        }
                        dl {
                            padding: 12px 0;
                            display: table-cell;
                            border-top: $borderStyle;
                            width: 20%;
                            &:nth-child(2) {
                                width: 20%;
                            }
                            &:nth-child(3) {
                                width: 60%;
                            }
                            dt {
                                margin-bottom: 4px;
                            }
                            dd {
                                line-height: 18px;
                                word-break: break-all;
                            }
                        }
                        .color888 {
                            color: #888;
                        }
                    }
                }
                .mt0{
                    margin-top: 0;
                    border-top: 0;
                }
            }
        }
        .foot {
            text-align: right;
            margin-top: 22px;
        }
    }
</style>