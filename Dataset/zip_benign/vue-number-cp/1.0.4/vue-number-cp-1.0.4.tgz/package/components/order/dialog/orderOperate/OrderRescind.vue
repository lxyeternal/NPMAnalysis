<template>
  <div>
    <!-- 解除合同与终止合同 -->
    <el-dialog class="dialog" :title="dialogVisible1Title" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible1" width="840px" center :close-on-click-modal="false">
      <div class="tc f12" style="margin-top: 6px" v-if="isRescind">确认已和采购商达成一致，同意并解除{{isSupplementary ? '补充' : ''}}合同，点击【确认并发起】按钮，待相关方确认后，{{isSupplementary ? '补充' : ''}}合同{{isRescind ? '解除' : '终止'}}。</div>
      <div class="tl" style="margin-top: 6px" v-else>
        <!-- 结算单 -->
        <template v-if="operType == 'settle'">
          <p style="margin-bottom: 20px;" class="f12">
            确认已和采购商达成一致，同意解除合同结算单，并下载查阅过合同结算单解除协议，点击【确认并发起】。就视作同意以下合同协议内容。
          </p>

          <p class="f12" style="color: #888">材料合同：
            <span style="color: #444">{{supplierFile.documentName}}</span>
          </p>

          <p style="margin-top: 6px;padding-left: 68px;">
            <span class="blue-pointer" @click="handleDownTemp(supplierFile.documentName,supplierFile.attachUrl)">下载合同结算单解除用印版</span>
            <span class="blue-pointer" style="margin: 0px 6px 0px" @click="handleView(supplierFile.attachUrl)">下载合同结算单解除用印版</span>
            <span class="blue-pointer" @click="handleDownTemp(supplierFileAttch.documentName,supplierFileAttch.attachUrl)">下载附件</span>
          </p>
        </template>

        <template v-else>
          <p style="margin-bottom: 20px;" class="f12">确认已和采购商达成一致，同意{{isRescind ? '解除' : '终止'}}{{isSupplementary ? '补充' : ''}}合同，并下载查阅过{{isSupplementary ? '补充' : ''}}合同{{isRescind ? '解除' : '终止'}}协议，点击【确认并发起】按钮，就视作同意以下{{isSupplementary ? '补充' : ''}}合同协议内容。
            <span class="red" v-if="!isRescind && !isSupplementary">【注意】合同终止后，不能在大家采平台就原合同发起任何流程及操作。请确认已按照原合同规定完成已履行部分的结算和付款流程。</span>
          </p>
          <p class="f12" style="color: #888">材料{{isSupplementary ? '补充' : ''}}合同：
            <span style="color: #444">{{supplierFile.documentName}}</span>
          </p>
          <p style="margin-top: 6px;padding-left: 68px;">
            <span class="blue-pointer" @click="handleDownTemp(supplierFile.documentName,supplierFile.attachUrl)">下载{{isSupplementary ? '补充' : ''}}合同终止用印版</span>
            <span class="blue-pointer" style="margin: 0px 6px 0px" @click="handleView(supplierFile.attachUrl)">查看{{isSupplementary ? '补充' : ''}}合同终止用印版</span>
            <span class="blue-pointer" @click="handleDownTemp(supplierFileAttch.documentName,supplierFileAttch.attachUrl)">下载附件</span>
          </p>
        </template>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" @click="initiateOrderRescind">确认并发起</el-button>
        <el-button v-if="operType == 'settle'" class="normal-btn" @click="dialogVisible1 = false">下载解除协议</el-button>
        <el-button class="normal-btn" @click="dialogVisible1 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 确认解除合同与确认终止合同 -->
    <el-dialog class="dialog" :title="dialogVisible2Title" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible2" width="840px" center :close-on-click-modal="false">
      <div class="tc f12" style="margin-top: 6px" v-if="isRescind">
        <template v-if="operType == 'settle'">
          <!-- 厂家审核 -->
          <span v-if="userInfo.bs === 'S'">
            确认已和采购商达成一致，同意并{{isRescind ? '解除' : '终止'}}合同结算单，点击【确认并{{isRescind ? '解除' : '终止'}}】按钮，待相关方确认后，合同结算单{{isRescind ? '解除' : '终止'}}。
          </span>
          <span v-else>确认已和采购商达成一致，同意并{{isRescind ? '解除' : '终止'}}合同结算单，点击【发起OA{{isRescind ? '解除' : '终止'}}合同审批】按钮，待相关方确认后，合同结算单{{isRescind ? '解除' : '终止'}}。</span>
        </template>
        <template v-else>确认已和采购商达成一致，同意并{{isRescind ? '解除' : '终止'}}{{isSupplementary ? '补充' : ''}}合同，点击【确认并{{isRescind ? '解除' : '终止'}}】按钮，待相关方确认后，{{isSupplementary ? '补充' : ''}}合同{{isRescind ? '解除' : '终止'}}。</template>
      </div>
      <div class="tl" style="margin-top: 6px" v-else>
        <p style="margin-bottom: 20px;" class="f12">确认已和{{userInfo.bs === 'S' ? '采购商' : '供应商'}}达成一致，同意{{isRescind ? '解除' : '终止'}}{{isSupplementary ? '补充' : ''}}合同，并下载查阅过{{isSupplementary ? '补充' : ''}}合同{{isRescind ? '解除' : '终止'}}协议，点击【确认并发起】按钮，就视作同意以下{{isSupplementary ? '补充' : ''}}合同协议内容。
          <span class="red" v-if="!isRescind && !isSupplementary">【注意】合同终止后，不能在大家采平台就原合同发起任何流程及操作。请确认供应商已按照原合同规定完成已履行部分的结算和付款流程。</span>
        </p>
        <p class="f12" style="color: #888">材料{{isSupplementary ? '补充' : ''}}合同：
          <span style="color: #444">{{supplierFile.documentName}}</span>
        </p>
        <p style="margin-top: 6px;padding-left: 68px;">
          <span class="blue-pointer" style="margin-left:6px" @click="handleDownTemp(supplierFile.documentName,supplierFile.attachUrl)">下载{{isSupplementary ? '补充' : ''}}合同终止用印版</span>
          <span class="blue-pointer" style="margin: 0px 6px 0px" @click="handleView(supplierFile.attachUrl)">查看{{isSupplementary ? '补充' : ''}}合同终止用印版</span>
          <span class="blue-pointer" @click="handleDownTemp(supplierFileAttch.documentName,supplierFileAttch.attachUrl)">下载附件</span>
        </p>
        <template v-if="userInfo.bs === 'B'">
          <p class="f12" style="color: #888;margin-top: 14px">事业部{{isSupplementary ? '补充' : ''}}合同：
            <span style="color: #444">{{purchaserFile.documentName}}</span>
          </p>
          <p style="margin-top: 6px;padding-left: 68px;">
            <span class="blue-pointer" style="margin-left:6px" @click="handleDownTemp(purchaserFile.documentName,purchaserFile.attachUrl)">下载{{isSupplementary ? '补充' : ''}}合同终止用印版</span>
            <span class="blue-pointer" style="margin: 0px 6px 0px" @click="handleView(purchaserFile.attachUrl)">查看{{isSupplementary ? '补充' : ''}}合同终止用印版</span>
            <span class="blue-pointer" @click="handleDownTemp(purchaserFileAttch.documentName,purchaserFileAttch.attachUrl)">下载附件</span>
          </p>
        </template>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button v-if="userInfo.bs === 'S'" type="primary" class="normal-btn" @click="confirmOrderRescind(true)">确认并{{isRescind ? '解除' : '终止'}}</el-button>
        <el-button style="width: 170px" v-if="userInfo.bs === 'B'" type="primary" class="normal-btn" @click="initiateOARescind">发起OA{{isRescind ? '解除' : '终止'}}{{isSupplementary ? '补充' : ''}}合同审批</el-button>
        <el-button class="normal-btn" @click="dialogVisible2 = false;dialogVisible3 = true">退回</el-button>
        <el-button class="normal-btn" @click="dialogVisible2 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 退回 -->
    <el-dialog class="dialog" :title="dialogVisible3Title" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible3" width="840px" center :close-on-click-modal="false" @close="close">
      <div>
        <el-form ref="rescindForm" :model="rescindForm" label-width="90px">
          <el-form-item label="退回原因：" prop="refuseReason" :rules="{required: true,message:'请填写退回原因'}">
            <el-input type="textarea" class="resize-none" v-model="rescindForm.refuseReason" rows="4" maxlength="200" show-word-limit placeholder="请输入..."></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" :disabled="!rescindForm.refuseReason.trim()" @click="confirmOrderRescind(false)">确认退回</el-button>
        <el-button class="normal-btn" @click="dialogVisible3 = false">取消</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import { viewFile } from '@/utils/orderUtil';

const rescindForm = {
  refuseReason: ""
};

export default {
  mixins: [accountMixin],
  components: {
    Loading
  },
  data() {
    return {
      isLoading: false,

      type: '1',//1发起，2确认，3退回
      isRescind: true,//true: 解除，false：终止
      isSupplementary: false, //是否是终止合同

      dialogVisible1: false,
      dialogVisible2: false,
      dialogVisible3: false,
      order: {},
      orderNo: '',
      rescindForm: Object.assign({}, rescindForm),
      supplierFile: {},
      supplierFileAttch: {},
      purchaserFile: {},
      purchaserFileAttch: {},

      operType: ''
    };
  },
  computed: {
    // 是否终止结算单
    isSettleEnd() {
      // 厂家退回 || 采购商退回
      return (this.order.settleStatus === '1' && this.order.settleType === '2') || (this.order.settleStatus === '7' && this.order.settleType === '2')
    },
    // 解除结算单
    isSettleRelieve() {
      // 厂家退回 || 采购商退回
      return (this.order.settleStatus === '1' && this.order.settleType === '1')
    },
    // 厂家 - 结算退回
    isSettleReturn() {
      return this.order.settleStatus == '5' && this.order.settleType == '0'
    },
    dialogVisible1Title() {
      let title = this.isRescind ? `解除${this.isSupplementary ? '补充' : ''}合同` : `终止${this.isSupplementary ? '补充' : ''}合同`
      if (this.operType == 'settle') {
        title = this.isRescind ? '发起解除结算单' : '发起终止结算单'
      }
      return title
    },
    dialogVisible2Title() {
      let title = this.isRescind ? `确认解除${this.isSupplementary ? '补充' : ''}合同` : `确认终止${this.isSupplementary ? '补充' : ''}合同`

      if (this.operType == 'settle') {
        title = this.isRescind ? '确认解除结算单' : '确认终止结算单'
      }
      return title
    },
    dialogVisible3Title() {
      let title = this.isRescind ? `退回解除${this.isSupplementary ? '补充' : ''}合同原因` : `退回终止${this.isSupplementary ? '补充' : ''}合同原因`

      if (this.operType == 'settle') {
        // 结算退回
        if (this.isSettleReturn) {
          title = '结算退回原因'
        } else {
          title = this.isRescind ? '退回解除结算单原因' : '退回终止结算单原因'
        }
      }
      return title
    },
    userInfo() {
      return this.$store.state.userInfo || {};
    },
    approveStatus() {
      let status = ''
      let oaApprovalInfo = this.order.externalSysList && this.order.externalSysList.find(i => { return i.operType === 'TERMINATED' }) || {};
      status = oaApprovalInfo.approveStatus
      console.log(status);
      return status
    },
    approveNo() {
      let status = ''
      let oaApprovalInfo = this.order.externalSysList && this.order.externalSysList.find(i => { return i.operType === 'TERMINATED' }) || {};
      status = oaApprovalInfo.approveNo
      console.log(status);
      return status
    },
  },
  methods: {
    close() {
      this.rescindForm.refuseReason = '';
      this.$refs['rescindForm'].resetFields()
    },
    // operType: settle-结算单
    open(order, type, isRescind, isSupplementary, operType) {
      this.order = order;
      this.orderNo = order.orderNo;
      this.isSupplementary = isSupplementary
      this.operType = operType
      this.rescindForm = Object.assign({}, rescindForm);
      this.type = type
      this.isRescind = isRescind

      if ((type == '1' || type == '2') && !isRescind) {
        this.handleDownloadContract()
      } else {
        this['dialogVisible' + type] = true
      }
    },
    // supplierContractTerminate   purchaserContractTerminate
    // supplierContractTerminate_pdf    purchaserContractTerminate_pdf
    // supplier   外部的
    // 获取合同解除用印版
    handleDownloadContract() {
      const bs = this.userInfo.bs
      const params = {
        orderNo: this.order.orderNo,
        // bs: bs === 'S' ? 'S' : "",
        documentVersion: "",
        fileFrom: "userUpload,systemCreate",
        documentTypeList: ['supplierContractTerminate_pdf', 'supplierContractTerminate', 'purchaserContractTerminate_pdf', 'purchaserContractTerminate']
      };
      InterfaceService.getContractInfo(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            if (data.respData.documentInfos && data.respData.documentInfos.length) {
              this.supplierFile = data.respData.documentInfos.find(i => { return i.documentType === 'supplierContractTerminate_pdf' || i.documentType === 'supplierContractTerminate_pdfFack' }) || {}
              this.supplierFileAttch = data.respData.documentInfos.find(i => { return i.documentType === 'supplierContractTerminate' || i.documentType === 'supplierContractTerminateFack' }) || {}
              this.purchaserFile = data.respData.documentInfos.find(i => { return i.documentType === 'purchaserContractTerminate_pdf' || i.documentType === 'purchaserContractTerminate_pdfFack' }) || {}
              this.purchaserFileAttch = data.respData.documentInfos.find(i => { return i.documentType === 'purchaserContractTerminate' || i.documentType === 'purchaserContractTerminateFack' }) || {}
            }
            this['dialogVisible' + this.type] = true
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 文件下载
    handleDownTemp(name, url) {
      this.$download([{
        name: name,
        url: url
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 在线预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    // 解除或终止合同（代理商与厂家）
    initiateOrderRescind() {
      if (this.operType == 'settle') {
        this.relivevTerminationStatementSingle('1')
        return
      }
      let params = {
        orderNo: this.orderNo,
      };
      InterfaceService.initiateOrderRescind(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            this.$message.success('操作成功')
            this.dialogVisible1 = false
            this.$emit("close")
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },

    /**
     * 解除/终止结算单
     */
    relivevTerminationStatementSingle(handleType) {
      return new Promise(resolve => {
        let params = {
          settleNo: this.order.settleNo || '', //	String	Y	结算单编号
          handleType,  //操作类型（0-解除，1-终止）
        };
        InterfaceService.relivevTerminationStatementSingle(
          params,
          data => {
            let res = data && data.respData || {};
            if (res.respCode === "0000") {
              this.dialogVisible1 = false
              this.$message.success(`${handleType === '0' ? '发起解除' : '发起终止'}结算单成功!`)
              this.$emit("close")
            } else {
              this.$message.error(res.respMsg)
            }
            resolve(true)
          }, data => {
            this.$message.error(data.respMsg)
          }, () => {
            this.isLoading = true
          }, () => {
            this.isLoading = false
          })

      })
    },

    // 确认/拒绝解除与退回合同（厂家与采购商退回）
    confirmOrderRescind(isAgree) {
      if (this.operType == 'settle') {
        if (isAgree) {
          // 终止解除合同结算单
          this.launchOaExaminationStatementSingle({}, this.isRescind ? '1' : '2')
        } else {
          // 退回解除/终止合同结算单
          this.confirmReturnStatementSingle(this.isSettleReturn ? '0' : this.isSettleEnd ? '2' : '1')
        }
        return
      }
      let params = {
        orderNo: this.orderNo,
        isAgree: isAgree ? 'Y' : 'N',//确认/拒绝（Y/N）
        comment: isAgree ? '' : this.rescindForm.refuseReason,
      };
      InterfaceService.confirmOrderRescind(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            this.$message.success('操作成功')
            this.dialogVisible2 = false
            this.dialogVisible3 = false
            this.$emit("close")
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },


    /**
    * 退回 结算单
    */
    confirmReturnStatementSingle(handleType) {
      return new Promise(resolve => {
        let params = {
          settleNo: this.order.settleNo, //	String	Y	结算单编号
          handleType, //	String	Y	操作类型（0-提交退回，1-解除退回，2-终止退回）
          rejectReason: this.rescindForm.refuseReason, //	String	Y	退回原因
          rejectAcctName: this.userInfo.acctName, //	String	Y	审核人姓名

        };
        InterfaceService.returnStatementSingle(
          params,
          data => {
            const res = data && data.respData || {};
            if (res.respCode === "0000") {
              this.$message.success(`退回${handleType == '0' ? '' : handleType == '2' ? '终止' : '解除'}结算单成功!`);
              this.dialogVisible3 = false
              this.$emit("close")
            } else {
              this.$message.error(res.respMsg)
            }
            resolve(true)
          }, data => {
            this.$message.error(data.respMsg)
          }, () => { this.isLoading = true }, () => { this.isLoading = false })
      })
    },

    // 提交解除OA审核/重新提交解除OA审核（采购商）
    initiateOARescind() {
      if (this.operType == 'settle') {
        // 重新提交
        if (this.order.settleStatus == '5' && this.order.approveStatus == '4') {
          this.accountInfo()
          return
        }
        this.launchOaExaminationStatementSingle({}, this.isSettleEnd ? '2' : '1')
        return
      }
      let params = {
        orderNo: this.orderNo,
        operType: ['2', '4'].includes(this.approveStatus) ? 'resubmit' : 'submit',// submit 提交 resubmit 重新提交
        approveNo: this.approveNo,// 申请单号
      };
      InterfaceService.initiateOARescind(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            this.$message.success('操作成功')
            this.dialogVisible2 = false
            this.$emit("close")
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },


    /**
     * 重新提交时 需要查询
     */
    accountInfo() {
      let param = {
        'acctId': this.userInfo.acctId
      }
      InterfaceService.accountInfo(param, (data) => {
        if (data && data.respData && data.respData.respCode === "0000") {
          const obj = data.respData || {}
          if (!obj.oaAapplicantId) {
            this.$confirm(
              '您还没有绑定集团OA账号，请先去绑定！',
              this.rejectBtn,
              {
                cancelButtonClass: "btn-custom-cancel",
                confirmButtonClass: "btn-custom-confirm",
                center: true,
                dangerouslyUseHTMLString: true,
                confirmButtonText: '去绑定',
                cancelButtonText: '取消',
              }).then(() => {
                this.$router.push({ path: '/purchaserCenter/accountInfo' })
              }).catch(() => {
              });
            return
          }

          this.launchOaExaminationStatementSingle(obj, this.isSettleEnd ? '2' : '1')
        } else {
          this.$message.error(data.respData.respMsg)
        }
      })
    },

    /**
     * 结算合同 - 发起oa审核
     */
    launchOaExaminationStatementSingle(obj = {}, applyType = '0') {
      return new Promise(resolve => {
        let params = {
          settleNo: this.order.settleNo,//	String	Y	结算单编号
          orderNo: this.order.settleNo,//	String	Y	合同编号
          approveId: '',//	String	N	oa流程编号
          approveName: '',//	String	N	审批流程名称
          approveNo: this.order.settleNo,//	String	Y	申请单号（暂时和结算单编号一样）

          approveCreateId: obj.oaAapplicantId || '',//	申请人
          approveDivisionId: obj.oaCompanyId || '',//	申请事业部ID
          approveDivisionName: obj.oaCompanyName || '',//	申请事业部名称
          approveDepartmentId: obj.oaDepartmentid || '',//	申请部门ID
          approveDepartmentName: obj.oaDepartmentName || '',//	申请部门名称
          approveUrgency: '0',//	紧急程度
          approveMobile: obj.oaAapplicantMobile || '',//	申请人手机
          // approveCompanyId: obj.companyId || '',//	申请公司ID
          approveCompanyId: obj.oaCompanyId || '',//	申请公司ID
          approveCompanyName: obj.companyName || '',//	申请公司名称
          approveMsg: '审核意见',//	提交审核意见

          applyAcctId: this.userInfo.acctId,//	String	Y	审核人账号
          applyAcctName: this.userInfo.acctName,//	String	Y	审核人名称
          handleType: obj.oaAapplicantId ? '2' : '1',//	String	Y	操作类型 1-提交， 2-重新提交
          applyType,//	String	Y	操作类型（0-提交审核，1-解除审核，2-终止审核）
          approveId: this.order.settleApplyNo || ''
        };
        InterfaceService.launchOaExaminationStatementSingle(
          params,
          data => {
            const res = data && data.respData || {};
            if (res.respCode === "0000") {
              if (applyType == '2' && this.role == 'S') {
                this.$message.success(`已确认终止合同结算单！`);
              } else if (applyType == '1' && this.role == 'S') {
                this.$message.success(`已确认解除合同结算单！`);
              } else {
                this.$message.success(`已提交OA审核！`);
              }
              this.dialogVisible2 = false
              this.$emit("close")
            } else {
              this.$message.error(res.respMsg)
            }
            resolve(true)
          }, data => {
            this.$message.error(data.respMsg)
          }, () => { this.isLoading = true }, () => { this.isLoading = false })
      })
    },

  }
};
</script>

<style lang="scss" scoped>
.info {
  color: #888888;
}
.dialog {
  /deep/ .el-form-item {
    margin-bottom: 0;
  }
  /deep/ .el-form-item__label {
    padding-right: 6px !important;
    line-height: 17px;
  }
  /deep/ .el-dialog__footer {
    padding-top: 0 !important;
  }
}
.error-info {
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
  position: absolute;
  top: 100%;
  left: 0;
}
</style>
