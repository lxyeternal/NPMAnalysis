<template>
    <div class="logistics">
        <!-- 物流详情 -->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="50%" :close-on-click-modal="false">
            <div slot="title" class="dialog-header">
                <label>运单号码：</label>{{logistics.trackingNo}}
                <label>物流公司：</label>{{logistics.expressCompanyName}}
                <label>客服电话：</label>95554
            </div>
            <div>
                <p class="no-data" v-if="!logisticsList.length">暂无物流信息</p>
                <el-row v-for="(row,index) in logisticsList" :key="index">
                    <el-col :span="4">
                        <span class="bold" v-if="row.showDate">{{row.date|date}}</span>
                    </el-col>
                    <el-col :span="4">
                        <span class="bold" v-if="row.showDate">{{row.date|weekDay}}</span>
                    </el-col>
                    <el-col :span="2">{{row.time}}</el-col>
                    <el-col :span="12">{{row.context}}</el-col>
                </el-row>
            </div>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import fillZero from "@/filters/fillZero";
import date from "@/filters/date";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            logistics: {},
            logisticsList: []
        };
    },
    methods: {
        arrangeTime(arr) {
            const result = [];
            arr.sort((a, b) => {
                // return a.time > b.time ? 1 : 0;
                return +new Date(a.time.replace(/-/g, "/")) - +new Date(b.time.replace(/-/g, "/"));
            });
            let temp = "1970-01-01";
            arr.forEach(item => {
                if (date(temp) != date(item.time)) {
                    temp = item.time;
                    item.date = item.time;
                    item.showDate = true;
                }
                item.time = this.getTime(item.time);
                result.push(item);
            });
            return result;
        },
        getTime(_date) {
            if (!_date) {
                return _date;
            }

            let dateStr = _date;
            if (dateStr.length == 21) {
                dateStr = dateStr.substring(0, dateStr.length - 2);
            }
            const date = new Date(Date.parse(dateStr.replace(/-/g, "/")));

            return (
                fillZero(date.getHours()) + ":" + fillZero(date.getMinutes())
            );
        },
        getExpressName(arr) {
            arr.forEach(item => {
                if (item.expressCode == this.logistics.expressCompany) {
                    this.logistics.expressCompanyName = item.expressName;
                }
            });
        },
        init(data) {
            this.logistics = data;
            if (this.logistics.expressList) {
                this.getExpressName(this.logistics.expressList);
            } else {
                this.getExpressList();
            }

            this.getLogistics();
        },
        getExpressList() {
            InterfaceService.getExpressList(data => {
                const arr = data.expressList;
                this.getExpressName(arr);
            });
        },
        getLogistics() {
            const params = {
                expressCompany: this.logistics.expressCompany,
                trackingNo: this.logistics.trackingNo
            };
            InterfaceService.getLogisticsDetail(
                params,
                data => {
                    console.log(data);
                    if (data.respCode === "0000") {
                        if (data.respData.respCode === "0000") {
                            this.logisticsList =
                                JSON.parse(data.respData.data) || [];
                            this.logisticsList = this.arrangeTime(
                                this.logisticsList
                            );
                            this.dialogVisible = true;
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    },
    mounted() {
        this.$on("init", data => {
            this.init(data);
        });
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-row {
    padding-left: 15px;
    padding-bottom: 15px;
    line-height: 18px;
    letter-spacing: 0.5px;

    &::before {
        content: "";
        float: left;
        display: inline-block;
        width: 8px;
        height: 8px;
        margin-top: 4px;
        margin-right: 15px;
        border-radius: 50%;
        background: #eee;
    }
    &:after {
        clear: both;
        content: "";
        position: absolute;
        top: 10px;
        left: 19px;
        height: 100%;
        bottom: 2px;
        border-right: 1px solid #eee;
        z-index: 8;
        display: block;
    }
}
/deep/ .el-row:last-child {
    &::before {
        width: 6px;
        height: 6px;
        border: 2px solid rgb(245, 161, 64);
        background: rgb(247, 244, 66);
    }
    &:after {
        display: none;
    }
}
/deep/ [class*="el-col-"] {
    min-height: 1px;
}
.dialog-header {
    text-align: left;
    font-weight: bold;
    label {
        margin-left: 50px;
        font-weight: 500;
    }
    label:first-child {
        margin-left: 0;
    }
}

.bold {
    font-weight: bold;
}

.no-data {
    line-height: 150px;
    text-align: center;
    color: #eee;
}
</style>
