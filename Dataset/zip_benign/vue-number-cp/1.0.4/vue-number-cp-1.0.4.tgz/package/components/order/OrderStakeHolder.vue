<template>
    <div class="order-info">
        <el-row>
            <div class="order-info-title">项目合同人员信息</div>
        </el-row>
        <el-row class="role-row" :gutter="10" v-for="(item,index) in roleList" :key="index">
            <el-col class="role-row-title" :span="24">
                {{item.label}}
                <a v-if="filterRoleAuth(item) && item.role != '0'" @click="handleEditStakeHolder(item)" style="margin-left: 10px;">修改</a>
                <a v-if="filterRoleAuth(item,'add') && item.role == '0' && userinfo.bs == 'B'" @click="handleAddStakeHolder(item)" style="margin-left: 10px;">+增加</a>
            </el-col>
            <el-col :span="8" v-for="(child,_index) in filterRole(item.children)" :key="_index" v-if="item.role != '0'">
                <label>{{child.roleName}}：</label>
                <template v-if="child.acctId">
                    {{child.acctName}}
                    <span v-if="filterShowMobile(child)">(Tel:{{child.mobile}})</span>
                </template>
                <template v-else>无</template>
            </el-col>
            <template v-if="item.role == '0'" v-for="(_item,_ind) in construction" >
                <el-col :span="24" >
                    企业：<em v-if="_item.corpName">{{_item.corpName}}</em>
                    <em v-else>无</em>
                    <a v-if="filterRoleAuth(_item)" @click="handleEditStakeHolder(_item)" style="margin-left: 10px;">修改</a>
                </el-col>
                <template v-for="(__item) in _item.children">
                    <el-col :span="8">
                        <label>{{__item.roleName}}：</label>
                        <template v-if="__item.acctId">
                            {{__item.acctName}}
                            <span v-if="filterShowMobile(__item)">(Tel:{{__item.mobile}})</span>
                        </template>
                        <template v-else>无</template>
                    </el-col>
                </template>
            </template>
        </el-row>

        <!-- 新增/修改干系人 -->
        <UpdateStakeHolder ref="updateStakeHolder" @close="handleCloseUpdateStakeHolder"></UpdateStakeHolder>
    </div>
</template>

<script>
    import accountMixin from "@/mixins/account";
    import UpdateStakeHolder from "@/components/order/dialog/UpdateStakeHolder";

    const roleList = [
        {
            role: "2",
            label: "采购商",
            children: []
        },
        {
            role: "0",
            label: "供应商(代理商)",
            children: []
        },
        {
            role: "3",
            label: "要料施工单位",
            children: []
        }
    ];

    export default {
        mixins: [accountMixin],
        components: {
            UpdateStakeHolder
        },
        data() {
            return {
                roleList: this.$clone(roleList),
                construction:[]
            };
        },
        props: ["order"],
        watch: {
            order() {
                this.init();
            }
        },
        methods: {
            // 过滤角色
            filterRole(list) {
                // const roles = ["23", "24", "22", '31', "32", "40", "41"];
                let roles = ["23", '40', "41"];
                if (this.role === "B") {
                    roles.push("31","32")
                }else if (this.role === "S") {
                    roles.push("22","24")
                }
                return list.filter(item => {
                    return roles.indexOf(item.role) == -1;
                });
            },
            // 过滤印章管理员电话
            filterShowMobile(role) {
                const seals = ["02", "11", "22", "25", "31", "33", "41", "44"];
                if (role.mobile && seals.indexOf(role.role) == -1) {
                    return true;
                }
                return false;
            },
            // 过滤修改权限
            filterRoleAuth(item,type) {
                let bool = false;
                let hasConstruction = false;
                hasConstruction = type == "add" && this.construction.every(item=>{return item.corpId == null});
                if (item.role == "2" || item.role == "1") {
                    bool = this.role == "B";
                } else if (item.role == "3") {
                    bool = this.role == "S";
                } else if (item.role == "0") {
                    let vendorImple = false; // 判断供应商是否为施工方
                    this.construction.forEach(item => {
                        item.children.forEach(_item => {
                            if (
                                _item.role[0] == "0" &&
                                _item.corpId == this.order.supplierId
                            ) {
                                vendorImple = true;
                            }
                        });
                    });

                    if (vendorImple) {
                        bool = this.order.supplierId == this.userinfo.corpId;
                    } else {
                        bool = this.role == "B" && !hasConstruction;
                    }
                }
                return bool;
            },
            handleEditStakeHolder(item) {
                if (item.role == "0" && item.corpId != null) {
                    this.$refs["updateStakeHolder"].open(item.children, item.role,"change");
                } else {
                    this.$refs["updateStakeHolder"].open(item.children, item.role);
                }
            },
            handleAddStakeHolder(item) {
                this.$refs["updateStakeHolder"].open(this.order.contractStakeHolders, item.role,"add",this.order.supplierId);
            },
            // 更新干系人完成
            handleCloseUpdateStakeHolder(bool) {
                if (bool) {
                    this.$emit("refresh");
                }
            },
            init() {
                this.stakeHolder = this.order.contractStakeHolders;
                this.roleList = this.$clone(roleList);
                let cList = [];
                let construction = [];
                this.construction = [];
                if (this.stakeHolder) {
                    this.stakeHolder.forEach(item => {
                        this.roleList.forEach(_item => {
                            if (item.role[0] == _item.role && _item.role[0] != "0") {
                                _item.children.push(item);
                            } else if (item.role[0] == _item.role && _item.role[0] == "0") {
                                cList.push(item)
                            }
                        });
                    });
                    cList.forEach(item=>{
                        construction.push(item.corpId)
                    });
                    for(let i = 0; i < construction.length; i++) {
                        if(construction.indexOf(construction[i]) == i){
                            this.construction.push({
                                corpId :construction[i],
                                children:[],
                                corpName:"",
                                role: "0",
                                label:"要料施工单位"
                            })
                        }
                    }
                    cList.forEach(item=>{
                        this.construction.forEach(_item=>{
                            if (item.corpId == _item.corpId) {
                                _item.children.push(item)
                                if (item.corpName) {
                                    _item.corpName = item.corpName
                                }
                            }
                        })
                    });
                }
            }

        },
        mounted() {
            this.init();
        }
    };
</script>

<style lang="scss" scoped>
    .order-info {
        line-height: 25px;
        font-size: 12px;

        /deep/ .el-col {
            padding: 0 10px;
        }

        p {
            width: 100%;
            display: flex;
            padding-right: 10px;
            word-break: break-word;
            white-space: normal;

            & > span {
                display: inline-block;
                flex: 1 1 0%;
            }
        }

        label {
            white-space: nowrap;
            color: #888888;
        }

        a {
            white-space: nowrap;
            color: #0082ff;
        }
    }

    .order-info-title {
        margin: 5px -10px;
        margin-bottom: 20px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
    }

    .role-row {
        margin-bottom: 15px;
    }

    .role-row-title {
        color: #444444;
        font-weight: bold;
        font-size: 14px;
    }
</style>
