<template>
  <div class="tendering-category-container" v-if="show" :style="{width}" :class="{multiple: multiple}">
    <div class="btn-close" :class="{active: isShowSelector}" @click.stop="!disabled && (isShowSelector = !isShowSelector)"></div>
    <div class="bidding-category-list-class" :style="{maxHeight: `${contentMaxHeight}px`}" :class="['title-container' ,{active: isShowSelector}, {disabled},{'color-ccc': biddingCategoryTitle == '请选择'}]" @click="!disabled && (isShowSelector = true)">
      <span v-for="(item, idx) in biddingCategoryList" :key="idx">
        {{item.brandName}}
        <i class="el-icon-close hand" @click.stop="handleClearBrand(item)"></i>
      </span>
    </div>
    <div class="body-container" :style="{width:bodyWidth || width}" v-if=" isShowSelector">
      <div class="head">
        <!-- 先把removeTag 使用起来, 知道取消的选项 <el-select v-model="selectValue" multiple collapse-tags filterable placeholder="请输入关键字" @change="handleQickSelect" @remove-tag="removeTag">
          <el-option v-for="item in quickSeach" :key="item.value" :label="item.label" :value="item">
          </el-option>
        </el-select> -->
        <i class="close el-icon-circle-close" @click="handleClose" title="关闭"></i>
      </div>
      <div class="center">
        <ul>
          <li v-for="item in treeData" :key="item.categoryId" @click="handleClick(treeData, item, 1)" :class="{active: item.active}">
            <i :class="{active: item.selected == 2, half: item.selected == 1}" @click.stop="handleClickCheckBox(treeData, item, 1)"></i>
            <span :title="item.categoryName">{{item.categoryName}}</span>
          </li>
        </ul>
        <ul>
          <li v-for="item in treeData2.children" :key="item.categoryId" @click="handleClick(treeData2.children, item, 2)" :class="{active: item.active}">
            <i :class="{active: item.selected == 2, half: item.selected == 1}" @click.stop="handleClickCheckBox(treeData2.children, item, 2)"></i>
            <span :title="item.categoryName">{{item.categoryName}}</span>
          </li>
        </ul>
        <ul>
          <li v-for="item in treeData3Computed" :key="item.categoryId" @click="handleClickCheckBox(treeData3.children, item, 3)" :class="{active: item.active}">
            <i :class="{active: item.selected == 2}" @click.stop="handleClickCheckBox(treeData3.children, item, 3)"></i>
            <span :title="item.categoryName">{{item.categoryName}}</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api"

export default {
  props: {
    value: {
      // 反显值 - 最后一类被选中的值
      default: ''
    },
    // 反显 list
    dataList: {
      type: Array,
      default: () => {
        return []
      }
    },
    // 限制 list, 只显示 这里面有的数据
    limitCategoryList: {
      type: Array,
      default: () => {
        return []
      }
    },
    //  宽度
    width: {
      type: String,
      default: '200px'
    },
    // 弹出选择宽度
    bodyWidth: {
      type: String,
      default: ''
    },
    // 是否多选
    multiple: {
      type: Boolean,
      default: true
    },
    // 是否禁用
    disabled: {
      type: Boolean,
      default: false
    },
    // 是否显示加工费
    isShowprocessingFee: {
      type: Boolean,
      default: false
    },
    // 是否展示组件
    show: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      treeData: [], // 一级目录
      treeData2: {}, // 二级目录
      treeData3: {}, // 三级目录
      quickSeach: [], // 查询目录
      selectValue: [], // 搜索结果
      selectItem: {}, // 选中对象
      biddingCategoryTitle: '请选择 ', // 招标类目名称
      biddingCategoryList: [], // 招标类目名称List
      isShowSelector: false, // 是否展示选择器
      timer: null, // 定时器
      outputValue: '', // 向父组件传递数据
      firstLoding: false, // 首次加载
      firtDataList: true, // 首次加载dataList
      contentMaxHeight: 201.1, // 解决IE 显示bug
      unUpdate: true, // 数据更新
    }
  },
  computed: {
    treeData3Computed() {
      let item = this.treeData3 && this.treeData3.children || []
      // 是否过滤加工费
      if (!this.isShowprocessingFee) {
        item = item.filter(f => f.type !== 'processingFee') || []
      }
      return item
    }
  },
  watch: {
    treeData: {
      deep: true,
      handler(newVal, oldVal) {
        if (!this.unUpdate) return
        console.log('watch - treeData');
        let firstOnOff = this.treeData.some(item => {
          return item.active
        })
        let secondOnOff
        this.treeData.forEach(item => {
          secondOnOff = item.children.some(item => {
            return item.active
          })
        })
        this.biddingCategoryTitle = firstOnOff || secondOnOff ? '' : '请选择 ';
        this.biddingCategoryList = []
        this.getSelectValue(this.treeData || [], '')

        this.biddingCategoryTitle = this.biddingCategoryTitle.slice(0, this.biddingCategoryTitle.length - 1)
        // 去前后空格
        this.biddingCategoryTitle.replace(/(^\s*)|(\s*$)/g, "")
        // 发送 选中数据
        this.$emit("categoryInfo", this.$clone(this.biddingCategoryList))

        this.firstLoding && this.$emit('input', this.outputValue)
        this.firstLoding = true

        this.setLimitCategoryList()
      }
    },

    dataList: {
      deep: true,
      handler(newVal, oldVal) {
        if (!this.unUpdate) return
        console.log('watch - dataList');
        if (this.firtDataList) {
          // 设置第三级显示
          let treeItem = {
            key1: [],
            key2: [],
            key3: []
          }

          this.dataList.forEach(f => {
            treeItem.key3.push(f.categoryId)
            // 通过 parentId 查找 categoryId
            const searchParentId = (list, parentId) => {
              list.some(s => {
                // 通过 parentId 匹配 父级
                if (s.categoryId == parentId) {

                  treeItem[`key${Number(s.categoryLevel)}`].push(s.categoryId)

                  // 如果不是 第一级 继续往上查找
                  if (s.parentId != '1') {
                    searchParentId(this.treeData, s.parentId)
                  }
                  return true
                }
                if (s.children && s.children.length) {
                  searchParentId(s.children, parentId)
                }
              })
            }
            searchParentId(this.treeData, f.parentId)

          })
          if (this.treeData && this.treeData.length) {
            this.firtDataList = false
          }
          treeItem = {
            key1: [...new Set(treeItem.key1)],
            key2: [...new Set(treeItem.key2)],
            key3: [...new Set(treeItem.key3)],
          }
          this.initResultData(treeItem)
          this.installSelectValues(this.treeData)
        }
      }
    },
    value(val, newVal) {
      if (this.value) {
        this.initTreeData()
      }
    }
  },
  mounted() {
    this.$nextTick(() => {
      document.addEventListener('keyup', (e) => {
        if (e.keyCode == 27) {
          this.isShowSelector = false
        }
      })
      document.addEventListener('click', this.clickOutSide, true);
    })
    this.init()
  },
  methods: {
    async   init() {
      await this.getCategory()
      this.initTreeData()
    },

    /**
     * 点击body
     */
    clickOutSide(ev) {
      // 是否点击在组件内部
      let state = false
      const searchParentNodeClassName = (offsetParentNode) => {
        const cName = offsetParentNode.className
        if (cName.indexOf('tendering-category-container') != -1 || cName.indexOf('el-scrollbar') != -1) {
          state = true
        }
        if (offsetParentNode.offsetParent) {
          searchParentNodeClassName(offsetParentNode.offsetParent)
        }
      }
      searchParentNodeClassName(ev.target)
      // 如果未点在组件内 关闭 组件选择弹层
      if (!state) {
        this.handleClose()
      }
    },

    /**
     * 设置 限制数据,  只显示相应数据
     */
    setLimitCategoryList() {
      if (!(this.limitCategoryList && this.limitCategoryList.length)) return
      try {
        // 检测 移除 二级 目录
        for (let i = this.treeData.length - 1; i >= 0; i--) {
          const itemLevel1 = this.treeData[i] || {};
          if (itemLevel1.children && itemLevel1.children.length) {
            for (let i2 = itemLevel1.children.length - 1; i2 >= 0; i2--) {
              const itemLevel2 = itemLevel1.children[i2] || {};
              let level2State = false
              if (itemLevel2.children && itemLevel2.children.length) {
                // 如果找到了了 不删除 否则删除该数据
                level2State = itemLevel2.children.some(s => this.limitCategoryList.some(s1 => s1.categoryId == s.categoryId))
                if (itemLevel2.children && itemLevel2.children.length) {
                  for (let i3 = itemLevel2.children.length - 1; i3 >= 0; i3--) {
                    const itemLevel3 = itemLevel2.children[i3];
                    if (!this.limitCategoryList.some(s => s.categoryId == itemLevel3.categoryId)) {
                      // 移除三级 无用数据
                      itemLevel2.children.splice(i3, 1)
                    }
                  }
                }
              }
              // 找不到 删除无用父级数据 二级
              if (!level2State) {
                itemLevel1.children.splice(i2, 1)
              }
            }
          }
        }

        // 检测 移除 一级 目录
        for (let i = this.treeData.length - 1; i >= 0; i--) {
          const itemLevel1 = this.treeData[i] || {};
          if (!(itemLevel1.children && itemLevel1.children.length)) {
            this.treeData.splice(i, 1)
          }
        }

        console.log(this.treeData, '---setLimitCategoryList');
        // 停止数据更新

      } catch (error) {
        console.error('try: ', error);
      }
    },

    /**
     * 初始化类目树
     */
    initTreeData() {
      let inputItem = []
      for (let i = 0, len = this.quickSeach.length; i < len; i++) {
        const item = this.quickSeach[i]
        // 在数组中找出与传入数据相匹配的类目 数据
        if (item.value == this.value) {
          inputItem = item
          break
        }
      }
    },

    /**
     * 反显 返回 数据
     */
    initResultData(treeItem) {
      console.log(treeItem, 'treeItem');
      let tree3children = []
      // 先查找 对应 的三级 菜单
      treeItem.key1.forEach(f => {
        this.setTreeDataStateBySearch(f, this.treeData, 1, data => {
          data && data.dataItem && (data.dataItem.active = false)
          this.handleClick(data.list, data.dataItem, 1)
        })
      })
      // 先查找 对应 的三级 菜单
      treeItem.key2.forEach(f => {
        this.setTreeDataStateBySearch(f, this.treeData, 2, data => {
          data && data.dataItem && (data.dataItem.active = false)
          this.handleClick(data.list, data.dataItem, 2)
          if (data.dataItem.children && data.dataItem.children.length) {
            // 设置第三级数据
            data.dataItem.children.forEach(f1 => {
              treeItem.key3.some(s => {

                if (s == f1.categoryId) {
                  // 第三级菜单 直接设置为 选中状态
                  f1.selected = 2
                  f1.active = true
                  // 设置父级选中状态
                  this.setParentSelectByParentId(this.treeData, f1.parentId)
                }
              })

              tree3children.push(f1)
            })
          }
        })
      })
      // // 先查找 对应 的三级 菜单

      this.treeData3 = { children: tree3children }
    },

    handleClose() {
      if (!this.value) {
        this.biddingCategoryTitle = '请选择 ';
      }
      this.isShowSelector = false
      this.$emit('update:show', false)
    },

    arrangementList() {
      this.treeData.map((item1, idx1) => {
        this.$set(item1, 'active', false)
        // selected: 0 未选中, 1 半选, 2 选中
        this.$set(item1, 'selected', 0)
        item1.children.map((item2, idx2) => {
          this.$set(item2, 'active', false)
          this.$set(item2, 'selected', 0)
          item2.children.map((item3, idx3) => {
            this.$set(item3, 'active', false)
            this.$set(item3, 'selected', 0)
            // `CATEGORY_TYPE` varchar(32) DEFAULT NULL COMMENT '类目类型（materialType:材料类型, processingFee:加工费类型）',
            // 显示加工费 - 快速搜索关键字显示
            if (this.isShowprocessingFee) {
              this.quickSeach.push({
                label: `${item1.categoryName}-${item2.categoryName}-${item3.categoryName}`,
                value: item3.categoryId,
                key1: item1.categoryId,
                key2: item2.categoryId,

              })
            } else if (item3.type !== 'processingFee') {
              this.quickSeach.push({
                label: `${item1.categoryName}-${item2.categoryName}-${item3.categoryName}`,
                value: item3.categoryId,
                key1: item1.categoryId,
                key2: item2.categoryId
              })
            }
          })
        })
      })
    },

    /**
     * 获取类目
     */
    getCategory() {
      return new Promise(resolve => {
        InterfaceService.getCategoryList(
          {
            categoryId: "1",
            queryType: "2",
          },
          data => {
            if (data.respData.respCode === "0000") {
              let res = data.respData.categoryInfos || []
              this.$store.commit('changeCategoryList', res)
              this.$setRootScope('categoryList', JSON.stringify(res))
              this.treeData = res;
              this.arrangementList();
              resolve(this.treeData)
              console.log(this.treeData);
            } else {
              this.$message.error(data.respData.respMsg);
            }
          },
          data => { },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      })
    },




    /**
     * 标题 点击 移除
     */
    handleClearBrand(item) {
      this.setTreeDataStateBySearch(item.categoryId, this.treeData, 3, data => {
        data && data.dataItem && (data.dataItem.selected = 2)
        this.handleClickCheckBox(data.list, data.dataItem, 3)
      })
    },

    /**
     * 复选框点击
     * @param list: 同级list
     * @param dataItem: 当前对象
     * @param state: 点击层级 - 1 第一级  2 第二级
     */
    handleClickCheckBox(list = [], dataItem, state) {
      dataItem.selected = dataItem.selected == 2 ? 0 : 2
      dataItem.active = dataItem.selected == 2 ? true : false
      this.setDataChildren(list, dataItem, state)
      // 如果点击 的是 子级 需要 设置 父级选中状态
      if (dataItem.parentId != '1') {
        this.setParentSelectByParentId(this.treeData, dataItem.parentId)
      }
      // 解决 IE 隐藏下拉框 bug
      setTimeout(e => {
        this.contentMaxHeight = this.contentMaxHeight === 201.1 ? 201.2 : 201.1
      })
      this.selectValue = []
      this.installSelectValues(this.treeData)
    },

    /**
     * 组装 下拉选择器选中值
     */
    installSelectValues(data) {
      data.forEach(f => {
        if (f.categoryLevel == '3') {
          this.quickSeach.some(s => f.selected == 2 && s.value == f.categoryId && this.selectValue.push(s))
        }
        if (f.children && f.children.length) this.installSelectValues(f.children)
      })
    },

    /**
     * 根据 父级 选中子级
     */
    setUpChildrenSelectedByParent(list = [], dataItem) {
      list.forEach(f => {
        f.selected = dataItem.selected == 2 ? 2 : 0
        // 如果是 复选框 选中
        f.active = dataItem.selected == 2 ? true : false
        if (f.children && f.children.length) {
          this.setUpChildrenSelectedByParent(f.children, dataItem)
        }
      })
    },

    /**
     * 根据parentId 设置 父级选中状态
     */
    setParentSelectByParentId(list = [], parentId) {
      list.some(s => {
        // 通过 parentId 匹配 父级
        if (s.categoryId == parentId) {

          if (s.categoryLevel != '3') {
            // 父级反查子级 数据状态, 全都=0 说明不选 全都=2 说明全选, 否则为半选, 第三级没有半选, 第三级半选就属于0 未选中
            s.selected = s.children.every(e => e.selected == 2) ? 2 : s.children.every(e => e.selected == 0) ? 0 : 1
          }

          // 如果不是 第一级 继续往上查找
          if (s.parentId != '1') {
            this.setParentSelectByParentId(this.treeData, s.parentId)
          }
          return true
        }
        if (s.children && s.children.length) {
          this.setParentSelectByParentId(s.children, parentId)
        }
      })
    },

    /**
     * 类目被点击重置及设置选中状态
     * @param list: 同级list
     * @param dataItem: 当前对象
     * @param state: 点击层级 - 1 第一级  2 第二级
     * @param init 初始化 显示 第3级 目录
     */
    handleClick(list = [], dataItem, state, init) {
      // 先重置选中状态
      dataItem.active = !dataItem.active
      // 如果 选中状态 为 false 则复选框 也设置为 fasle
      !dataItem.active && (dataItem.selected = 0)

      this.setDataChildren(list, dataItem, state, init)
      setTimeout(e => {
        this.contentMaxHeight = this.contentMaxHeight === 201.1 ? 201.2 : 201.1
      })
    },

    /**
     * 设置子级显示数据
     */
    setDataChildren(list = [], dataItem, state, init) {
      // 设置 选中状态
      if (dataItem.children && dataItem.children.length) {
        this.setUpChildrenSelectedByParent(dataItem.children, dataItem)
      }

      // 把选中的 项  子级 组装在一个 list 里面 显示
      const setActiveItem = (dataList) => {
        const activeItem = {
          children: []
        }
        dataList.forEach(f => f.active && f.children && f.children.length && (activeItem.children = activeItem.children.concat(f.children)))

        return activeItem
      }

      const item = setActiveItem(list)

      // 如果 选中的是 第一级  需要组装 第三级 list 否则 第三级 不显示
      if (state === 1 && !init) {
        let treeData3Item = {
          children: []
        }
        item && item.children && item.children.forEach(f => {
          f.active && f.children && f.children.length && (treeData3Item.children = treeData3Item.children.concat(f.children))
        })
        this.treeData3 = treeData3Item
      }

      switch (state) {
        case 1:
          this.treeData2 = item
          break
        case 2:
          // 如果 是初始化 且 第二级是 组装第三级数据
          if (init) {
            this.treeData3.children = this.treeData3.children.concat(item.children)
            return
          }
          this.treeData3 = item
          break
      }
    },

    /**
     * 重置数据状态
     */
    resetTreeData(treeData = []) {
      treeData.forEach((item, idx) => {
        this.$set(item, 'active', false)
        if (item.children && item.children.length) {
          this.resetTreeData(item.children)
        }
      })
    },

    /**
     * 搜索框隐藏/显示
     */
    visibleChange(state) {
    },

    /**
     * 快速搜索 或 初始化数据反显
     */
    handleQickSelect() {
      if (this.selectValue && this.selectValue.length) {
        // this.treeData3.children.forEach(f => (f.selected = 0, f.active = false))
        // this.selectValue.forEach(f => {
        //   this.treeData3.children.some(s => s.categoryId == f.value && (s.selected = 2, f.active = true))
        // })
      }
    },

    removeTag(rTag) {

    },

    /**
     * 通过搜索 查询出 第三级菜单 对应数据
     */
    searchTreeData3ItemByValue(data) { },

    /**
     * 通过搜索 返回 对应数据
     */
    setTreeDataStateBySearch(key, treeData, state, resultItem) {
      treeData.some(item => {
        if (key == item.categoryId) {
          resultItem({
            list: treeData || [],
            dataItem: item,
            state,
          })

          return true
        }
        if (item.children && item.children.length) {
          this.setTreeDataStateBySearch(key, item.children, state, resultItem)
        }
      })
    },

    /**
     * 获取选中数据
     */
    getSelectValue(treeData = [], brandName1, brandName2) {
      treeData.map(item => {
        if (item.active) {
          this.outputValue = ''
          if (item.categoryLevel == '3') {

            this.biddingCategoryList.push({
              item: item,
              categoryId: item.categoryId,
              brandName: brandName1 + brandName2 + item.categoryName,
              parentId: item.parentId,
              originalId: item.originalId,
            })
          } else if (item.categoryLevel == '1') {
            brandName1 = `${item.categoryName}-`
          } else if (item.categoryLevel == '2') {
            brandName2 = `${item.categoryName}-`
          }
          // 找到最后一级
          if (!item.children || !item.children.length) {
            this.outputValue = item.categoryId
          }
        }

        if (item.children && item.children.length) {
          this.getSelectValue(item.children, brandName1, brandName2)
        }
      })
    },
  }
}
</script>

<style lang="scss" scoped>
.tendering-category-container {
  position: relative;
  $borderStyle: 1px solid #e2e2e2;
  &.multiple {
    .center {
      ul {
        li {
          i {
            display: block !important;
          }
          span {
            margin-left: 30px;
          }
        }
      }
    }
  }
  .title-container {
    background: #fff;
    border: 1px solid #dcdfe6;
    transition: all 0.3s linear;
    box-sizing: border-box;
    padding: 0 12px;
    position: relative;
    max-height: 202px;
    min-height: 42px;
    overflow-y: auto;
    padding: 0 0;
    text-align: left;
    &.bidding-category-list-class {
      span {
        color: #fff;
        background: #c99f4f;
        margin-left: 8px;
        padding: 0 6px;
        margin-top: 8px;
        margin-top: 8px;
        height: 22px;
        line-height: 22px;
        display: inline-block;
        i {
          font-size: 12px;
        }
      }
    }
  }
  .body-container {
    background: #fff;
    border: 1px solid #e2e2e2;
    box-shadow: 0 5px 5px rgba(0, 0, 0, 0.1);
    margin-top: -1px;
    z-index: 12;
    position: absolute;
    padding: 12px;
    .head {
      min-height: 10px;
    }
    .el-select {
      width: calc(100% - 82px);
    }
    .close {
      border-radius: 50%;
      position: absolute;
      right: 10px;
      top: 10px;
      border: 1px solid #eaeaea;
      transition: all 0.3s linear;
      cursor: pointer;
      &:hover {
        border-color: #ffd64e;
      }
    }
    .center {
      border: $borderStyle;
      border-right-width: 0;
      margin-top: 12px;
      display: flex;
      /deep/ ::-webkit-scrollbar {
        width: 4px;
      }
      ul {
        height: 300px;
        overflow: auto;
        width: 33.3333%;
        border-right: $borderStyle;
        scrollbar-track-color: #fff; // 背景
        scrollbar-arrow-color: #fff; // 箭头
        scrollbar-shadow-color: #fff; // 滚动条边框
        &:not(:last-child) {
          li {
            &::after {
              content: "";
              position: absolute;
              right: 20px;
              top: 14px;
              border: 4px solid transparent;
              border-color: #bbb #bbb transparent transparent;
              transform: rotate(45deg);
            }
          }
        }
        li {
          padding: 0 20px;
          height: 35px;
          line-height: 35px;
          cursor: pointer;
          position: relative;
          i {
            position: absolute;
            width: 20px;
            height: 20px;
            border: 1px solid #ccc;
            margin-top: 9px;
            background: #fff;
            display: none;
            &::before {
              content: "";
              width: 2px;
              height: 7px;
              position: absolute;
              border: 2px solid transparent;
              transform: rotate(45deg);
              left: 6px;
              margin-top: 2px;
              transition: all 0.3s linear;
            }
            &.active {
              border-color: #eacb87;
              background: #d7b064
                linear-gradient(
                  120deg,
                  rgba(215, 176, 100, 1) 0%,
                  rgba(236, 206, 139, 1) 100%
                );
              &::before {
                border-color: transparent #fff #fff transparent;
              }
            }
            &.half {
              &::before {
                content: "";
                width: 8px;
                height: 0px;
                position: absolute;
                border: 1px solid #eacb87;
                transform: rotate(0deg);
                margin-top: 8px;
                left: 4px;
                background: #eacb87;
              }
            }
          }
          &.active {
            background: linear-gradient(
              120deg,
              rgba(215, 176, 100, 1) 0%,
              rgba(236, 206, 139, 1) 100%
            );
            &::after {
              border-color: #fff #fff transparent transparent;
            }
            span {
              font-weight: bold;
              color: #fff;
            }
          }
          span {
            color: #606266;
            font-size: 14px;
            overflow: hidden;
            width: 90%;
            white-space: nowrap;
            display: inline-block;
            text-overflow: ellipsis;
            text-align: left;
          }
        }
      }
    }
  }
  .color-ccc {
    color: #ccc;
  }
  /deep/ .el-input__inner {
    border-color: #dcdfe6 !important;
  }
}
.btn-close {
  width: 30px;
  height: 100%;
  position: absolute;
  right: 10px;
  cursor: pointer;
  z-index: 123;
  top: 50%;
  transform: translateY(-50%);
  &::after {
    content: "";
    display: inline-block;
    border-style: solid;
    border-width: 4px;
    border-color: transparent transparent #dcdfe6 #dcdfe6;
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%) rotate(-45deg);
    transition: all 0.3s linear;
  }
  &.active {
    border-color: #ffd64e;
    &::after {
      transform: translateY(-50%) rotate(135deg);
    }
  }
  &.disabled {
    border: 0;
    background: transparent;
    &::after {
      display: none;
    }
  }
}
.el-select-dropdown__item {
  border-top: 1px solid transparent;
  font-weight: normal;
  &.selected {
    color: #fff !important;
    background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%) !important;
    border-top: 1px solid #fff;
  }
}
/deep/ .el-select__input {
  padding: 0 2px;
  &:focus {
    border: 1px solid transparent;
  }
}
</style>
