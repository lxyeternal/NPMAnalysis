<template>
    <div>
        <!-- 删除模版提示 -->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="600px" center :close-on-click-modal="false">
            <div class="tc">
                <p>确认删除该模版清单？</p>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确定</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
        return {
            isLoading: false,
            dialogVisible: false
        };
    },
    methods: {
        open(data) {
            this.dialogVisible = true;
        },
        handleConfirm() {
            this.dialogVisible = false;
            this.$emit("close", true);
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;

    /deep/ .el-dialog__header {
        padding: 0;

        &:before {
            display: none;
        }
    }
}
</style>


