<template>
  <div class="receivePayrecord">
    <TableThead :TopDistance="660" Height="60">
      <tr slot="tr">
        <td width="78px">序号</td>
        <td width="200px">{{handleType == '0' ? '付款' : '收款'}}日期</td>
        <td width="250px">{{handleType == '0' ? '付款' : '收款'}}方式</td>
        <td width="260px">合同签约单位</td>
        <td>本次{{handleType == '0' ? '付款' : '收款'}}金额(含税)(元)</td>
      </tr>
    </TableThead>
    <table class="table-default">
      <thead>
        <tr>
            <td width="78px">序号</td>
            <td width="200px">{{handleType == '0' ? '付款' : '收款'}}日期</td>
            <td width="250px">{{handleType == '0' ? '付款' : '收款'}}方式</td>
            <td width="260px">合同签约单位</td>
            <td>本次{{handleType == '0' ? '付款' : '收款'}}金额(含税)(元)</td>
        </tr>
      </thead>
      <tbody v-for="(item,ind) in tdBillInfoList" :key="ind">
        <tr>
          <td>
            {{ind + 1}}
          </td>
          <td>{{item.receivedDate}}</td>
          <td>{{item.receivedType}}</td>
          <td>{{item.receivedName}}</td>
          <td>{{item.receivedAmt | formatMoney}}</td>
        </tr>
      </tbody>
      <!-- 累计 -->
      <tbody>
        <tr class="total">
          <td colspan="2" style="padding: 0px">
            <div class="total-text">合计</div>
          </td>
          <td colspan="2"></td>
          <td class="bold">{{receivedAmtTotal}}</td>
        </tr>
      </tbody>
    </table>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import TableThead from "@/components/base/TableThead";
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import { NumberUtil } from '@/utils/numberUtil';

export default {
  name: "detailsTable",
  components: {
    TableThead, Loading
  },
  data() {
    return {
      isLoading: false,

      tdBillInfoList:[]
    }
  },
  props:['handleType','orderNo'], //0付款记录; 1收款记录
  computed: {
    role() {
      return this.$store.state.userInfo
        ? this.$store.state.userInfo.bs
        : 0;
    },
    userInfo() {
      return this.$store.state.userInfo;
    },
    receivedAmtTotal(){
        let num = 0
        this.tdBillInfoList.forEach(i=> {
          num = NumberUtil.numAdd(num, +i.receivedAmt)
        })
        return NumberUtil.formatMoney(num)
    }
  },
  watch: {
    handleType(n,o){
        console.log(n)
        this.getReceivePay()
    }
  },
  mounted() {
    this.getReceivePay()
  },
  methods: {
    getReceivePay(){
      let param = {
        orderNo: this.orderNo || '',
        handleType: this.handleType || '',
      }
      InterfaceService.getReceivePay(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.tdBillInfoList = data.respData.tdBillInfoList || []
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  },
}
</script>

<style scoped lang="scss">
.receivePayrecord {
  margin-bottom: 30px;
  .table-default {
    thead {
      tr {
        td {
          font-size: 14px;
          line-height: 20px;
        }
      }
    }
    tr {
      td {
        padding-left: 10px;
        padding-right: 10px;
        font-size: 12px;
        line-height: 17px;
      }
    }
    .box_type {
      background: #ffe9eb;
      border: 1px solid #db7575;
      color: #863838;
      margin-bottom: 0px;
    }
    .total {
      background: #ebf1ff;
      > td {
        padding-top: 7px;
        padding-bottom: 6px;
        font-weight: 600;
        font-size: 12px;
        line-height: 17px;
        text-align: right;
        .total-text {
          // width: 151px;
          height: 30px;
          background-color: #e3ecff;
          padding-left: 10px;
          text-align: left;
          line-height: 30px;
        }
      }
    }
    .operat {
      > p {
        > a {
          display: block;
          color: #0082ff;
          font-size: 12px;
          line-height: 17px;
          margin-bottom: 4px;
          &:last-child {
            margin-bottom: 0px;
          }
        }
      }
    }
  }
}
</style>