<template>
    <div>
        <!-- 手动匹配 -->
        <el-dialog class="dialog" title="手动匹配" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false">
            <div>
                <div class="table">
                    <table>
                        <thead>
                            <tr>
                                <td>材料类目</td>
                                <td>货品名称</td>
                                <td>型号</td>
                                <td>物料描述</td>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>{{material.categoryFullName}}</td>
                                <td>{{material.materialName}}</td>
                                <td>{{material.model}}</td>
                                <td>{{material.description}}</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="clearfloat match-search">
                    <el-input class="fl" clearable v-model="keyword" :autofocus="false" placeholder="请输入货品名称、规格型号、供应商等关键词搜索，关键词越多，匹配率越高" @keyup.enter="handleMatch"></el-input>
                    <el-button class="fl" type="primary" style="width:130px;" @click="handleMatch">匹配</el-button>
                </div>
                <div v-if="matchList.length">
                    <p class="match-res-title">
                        <label>匹配结果</label>
                    </p>
                    <div class="table">
                        <table>
                            <thead>
                                <tr>
                                    <td width="50"></td>
                                    <td>货品名称</td>
                                    <td>型号</td>
                                    <td>供应商</td>
                                    <td>合同名称</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(row,index) in matchList" :key="index">
                                    <td>
                                        <el-checkbox v-model="row.checked" @change="handleSelectRow(row,index)"></el-checkbox>
                                    </td>
                                    <td>
                                        <div class="material-name">
                                            <div class="left">
                                                <img :src="row.picUrl" v-error-img>
                                            </div>
                                            <div class="right">
                                                <p>{{ row.skuName }}</p>
                                                <p>规格：{{row.model}}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td>{{row.model}}</td>
                                    <td>{{row.supplierName}}</td>
                                    <td>{{row.contractName}}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 120px" :disabled="disabledMatch" @click="handleConfirm">确认匹配</el-button>
                <el-button size="small" style="width: 120px" @click="dialogVisible = false">返回</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            matchList: [],
            material: {},
            keyword: ""
        };
    },
    computed: {
        disabledMatch() {
            let bool = true;
            if (this.matchList.length) {
                bool = this.matchList.every(item => {
                    return !item.checked;
                });
            } else {
                return true;
            }
            return bool;
        }
    },
    methods: {
        open(data) {
            this.keyword = "";
            this.material = data;
            this.matchList = [];
            this.dialogVisible = true;
        },
        handleSelectRow(row, i) {
            this.matchList.forEach((item, index) => {
                if (i != index) {
                    item.checked = false;
                }
                this.$set(this.matchList, index, item);
            });
        },
        handleMatch() {
            if (this.keyword) {
                this.matchGoods();
            } else {
                this.$message.error("请输入匹配关键词");
            }
        },
        handleConfirm() {
            const matchs = this.matchList.filter(item => {
                return item.checked;
            });
            let data = matchs[0];
            delete data.checked;
            data.materialName = data.skuName;
            data = Object.assign(this.material, data);
            this.dialogVisible = false;
            this.$emit("close", data);
        },
        matchGoods() {
            const params = {
                searchKey: this.keyword
            };
            InterfaceService.searchMaterialSkuList(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.matchList = data.respData.skuList || [];
                        this.matchList.forEach(item => {
                            item.checked = false;
                        });
                        if (!this.matchList.length) {
                            this.$message.error("未匹配到货品");
                        }
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;
}

.table {
    /deep/ .el-button {
        font-size: 12px;
    }

    width: 100%;
    max-height: 350px;
    margin-bottom: 20px;
    line-height: 23px;
    font-size: 12px;
    overflow: auto;

    table {
        width: 100%;
    }
    td {
        padding: 14px 10px;
        vertical-align: middle;
        word-break: break-word;
    }

    thead {
        text-align: center;
        white-space: nowrap;
        font-size: 14px;
        color: #909399;

        td {
            padding: 5px 10px;
        }
    }

    tbody {
        text-align: center;

        td {
            border-bottom: 1px solid #ffffff;
            background: #f5f5f5;
        }
    }
}

.material-name {
    display: inline-flex;
    width: 100%;
    vertical-align: top;
    line-height: 20px;

    img {
        width: 75px;
        height: 75px;
    }

    a:hover {
        text-decoration: underline;
        color: #0082ff;
    }

    .left {
        margin-right: 10px;
    }

    .right {
        text-align: left;

        p:first-child {
            margin-bottom: 10px;
        }
        p:last-child {
            word-break: break-all;
            max-height: 40px;
            overflow: hidden;
            color: #969799;
        }
    }
}

.match-search {
    /deep/ .el-input {
        width: 620px;
    }
}

.match-res-title {
    margin-top: 40px;
    border-top: 1px solid #ececec;
    text-align: center;
    font-size: 14px;

    label {
        display: inline-block;
        padding: 10px 50px;
        transform: translateY(-22px);
        background: #ffffff;
    }
}
</style>


