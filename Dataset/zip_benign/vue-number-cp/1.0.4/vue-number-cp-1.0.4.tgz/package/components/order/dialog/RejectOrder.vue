<template>
    <div>
        <!-- 拒绝合同 -->
        <el-dialog class="dialog" title="填写选择拒绝合同原因" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="50%" center :close-on-click-modal="false">
            <div>
                <el-form :model="rejectForm" label-width="100px">
                    <el-form-item label="拒绝原因" prop="label">
                        <el-select v-model="rejectForm.label" placeholder="请选择拒绝原因" style="width:100%;">
                            <el-option v-for="(option,index) in reasonList" :key="index" :label="option" :value="option"></el-option>
                        </el-select>
                        <i class="error-info" v-if="showError&&!rejectForm.label">请选择拒绝原因</i>
                    </el-form-item>
                    <el-form-item prop="reason" v-if="rejectForm.label=='其他'">
                        <el-input type="textarea" v-model="rejectForm.reason" rows="8" placeholder="请输入..."></el-input>
                        <i class="error-info" v-if="showError&&!rejectForm.reason">请输入拒绝原因</i>
                    </el-form-item>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确定并提交</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

const rejectForm = {
    label: "",
    reason: ""
};

const reasonList = [
    "生产周期太紧，短期无法安排合同生产",
    "原料不足，来不及生产",
    "成本上涨，此单做不了",
    "此款已停产，不能接合同",
    "其他"
];

const reasonAgreeList = [
    "生产周期太紧，短期无法安排合同生产",
    "原料不足，来不及生产",
    "成本上涨，此单做不了",
    "此款已停产，不能接合同",
    "协议价不符，拒绝确认合同，请重新填写协议价",
    "其他"
];
export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            order: {},
            orderNo: '',
            rejectForm: Object.assign({}, rejectForm),
            reasonList: [].concat(reasonList),
            showError: false
        };
    },
    methods: {
        open(data, type) {
            this.order = data;
            this.orderNo = data.orderNo;
            this.showError = false;
            this.rejectForm = Object.assign({}, rejectForm);

            if (type == "Negotiated") {
                this.reasonList = [].concat(reasonAgreeList);
            } else {
                this.reasonList = [].concat(reasonList);
            }
            this.dialogVisible = true;
        },
        handleConfirm() {
            if (!this.rejectForm.label) {
                this.showError = true;
                return;
            } else if (
                this.rejectForm.label == "其他" &&
                !this.rejectForm.reason
            ) {
                this.showError = true;
                return;
            }
            this.rejectOrder();
        },
        rejectOrder() {
            let reason = this.rejectForm.label;
            if (reason == "其他") {
                reason = this.rejectForm.reason;
            }

            const orders = [];
            orders.push({
                orderNo: this.orderNo,
                refuseReason: reason
            });
            const params = {
                orders: orders
            };

            InterfaceService.rejectOrder(
                params,
                data => {
                    console.log(data);
                    if (data.respCode === "0000") {
                        this.dialogVisible = false;
                        this.$emit("close", true);
                        // this.getOrderList();
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
.error-info {
    color: #f56c6c;
    font-size: 12px;
    line-height: 1;
    padding-top: 4px;
    position: absolute;
    top: 100%;
    left: 0;
}
</style>
