<template>
  <transition name="el-zoom-in-bottom">
    <div class="box" v-show="showBox">
      <!-- 采购商授权代表(城市公司项目经理) 没有这么多显示字段  所以高度 改低一点 -->
      <div class="confirmContract" :style="{height: roleList.some(s=> s.role == '21')? '300px':'500px'}">
        <div class="content">
          <div class="title tc">项目人员变更</div>
          <div class="center">
            <h1 v-if="editRole == '0' && role == 'B'">施工单位
              <span v-if="roleList.length > 1" class="f12 blue hand" @click="addConstructionCompany">添加施工单位</span>
              <i class="f12 red">若搜索不到施工单位，请先联系施工单位入驻本平台并设置好相关角色人员后再来添加。</i>
            </h1>
            <el-form :rules="rules" ref="form">
              <el-row :gutter="10">
                <el-col :span="(item.role == '00' || item.role == '21' || item.role == '30') && roleList.every(i=>{return i.role.length > 1}) ? 24 : 12" v-for="(item,index) in roleList" :key="index">
                  <el-form-item label="企业名称：" v-if="item.role.length==1" :error="showErrorMsg(item)" :rules="[{required: true}]" :label-width="item.labelWidth">
                    <el-select v-model="item.corpId" placeholder="请搜索或选择企业名称" no-data-text="无数据" filterable remote :remote-method="handleFilterCorp" @change="handleChangeCorp(item,index)" @visible-change="handleVisibleChage($event,item,index)">
                      <el-option v-if="roleList.length <= 4" :key="index + 'option'" label="暂无" value="0"></el-option>
                      <el-option v-for="(option,ind) in item.corpList" :key="option.corpId + ind" :label="option.corpName" :value="option.corpId" v-show="option.show"></el-option>
                    </el-select>
                  </el-form-item>
                  <span class="blue-pointer del-txt" v-if="item.role == '0' && roleList.filter(i=>{return i.role === '0'}).length > 1 && role == 'B'" @click="handleDelConstructor(item,index)">删除</span>

                  <!-- || item.role == '21'移除 -->
                  <el-form-item :class="{
                                  authorized : item.role == '21',
                                  aegalAuthorizedClient: ['22', '29', '31', '33'].includes(item.role),
                                  projectSigner: ['29', '33'].includes(item.role),
                                  htzdzyyr: ['22', '31'].includes(item.role),
                                  fLeft27: ['33'].includes(item.role),
                                }" :label="item.label" v-if="item.role.length==2 && item.role != '21'" :error="showErrorMsg(item)" :rules="[{required: true}]" :label-width="item.labelWidth">
                    <el-select v-model="item.acctId" :placeholder="'请选择'+item.label" @change="handleChangeRole($event,item,index)">
                      <el-option v-if="item.role == '21'" label="暂无" value="暂无"></el-option>
                      <el-option class="role-option" v-for="option in filterCurrentRole(item,item.acctList)" :key="option.acctId" :label="option.acctName" :value="option.acctId">
                        <span style="line-height: 30px" v-html="option.acctName" @click="handlegoUsersManage(option)">{{option.acctName}}</span>
                        <span v-if="option.mobile">(Tel:{{option.mobile}})</span>
                      </el-option>
                      <el-option class="is-disabled" :style="{'border-top' : filterCurrentRole(item,item.acctList).length ? '1px solid #eee' : 'none'}" :disabled="true" value="1">
                        <div>若无可选之人，请联系<template v-if="item.corpId && item.corpId !== userinfo.corpId">相关公司</template>管理员至<span class="blue hand" @click="handleGoUsersManage(item.corpId)">【权限管理】</span>编辑添加</div>
                      </el-option>
                    </el-select>
                  </el-form-item>

                  <!-- || item.role == '21'移除 -->
                  <el-form-item v-if="(item.role == '00' || item.role == '30') && (item.acctId != '0' && item.acctId != '暂无')" class="special-form-item" :rules="[{required: true}]" :label="item.role == '30' ? '供应商授权代表授权书：' : item.role == '00' ? '施工方授权代表授权书：' : '采购商授权代表授权书：'" label-width="1185px" :class="{'width-auto':(item.role == '00' || item.role =='21')  && role === 'B','margin-auto' : item.role =='21'}" :error="showFileErrorMsg(item)">
                    <div class="f12" style="position: absolute;left: 170px; top: -2px;" v-if="item.role != '00' || (item.role == '00' && item.corpName)">
                      <DownloadAndUpload appName="TRD" :fromId="String(index)" :uploadType="item.role == '30' ? '1' : item.role == '00' ? '5' : '3'" :fileTypeReg="/(pdf|PDF)/i" :templateFile="templateFile" fileTypeErrorMsg="请上传pdf格式文件" @outputValue="getAttachInfo"></DownloadAndUpload>
                    </div>
                    <div class="grey f12" v-if="item.role == '30'">请先下载模板，根据模板内容完善相关信息，然后打印加盖公司公章，扫描该文件并以PDF格式上传。该授权书的人员信息必须与所填的供应商授权代表用户信息一致。</div>
                    <div class="grey f12" v-if="item.role == '00'">请先下载模板，根据模板内容完善相关信息，然后打印加盖公司公章，扫描该文件并以PDF格式上传。该授权书的人员信息必须与所填的施工方授权代表(指定收货人)用户信息一致。</div>
                    <div class="grey f12" v-if="item.role == '21'">请先下载模板，根据模板内容完善相关信息，然后打印加盖公司公章，扫描该文件并以PDF格式上传。该授权书的人员信息必须与所填的采购商授权代表(城市公司项目经理)用户信息一致。</div>

                    <div class="enclosure-content" v-if="item.uploadFile && item.uploadFile.attachName">
                      {{item.uploadFile.attachName}}
                      <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="item.uploadFile.viewUrl" :attachName="item.uploadFile.attachName"></DownloadAndView>
                    </div>
                    <div class="enclosure-content" style="color: #bbb;" v-else>
                      暂未上传授权书！
                    </div>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </div>
        </div>
        <FixBottom class="bottom">
          <div class="tc">
            <el-button type="primary" @click="handleConfirm">确认变更</el-button>
            <el-button style="width: 120px;" @click="close">取消</el-button>
          </div>
        </FixBottom>
      </div>
      <Loading :is-loading="isLoading"></Loading>
    </div>
  </transition>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import FixBottom from "@/components/base/FixBottom";
import DownloadAndUpload from "@/components/base/DownloadAndUpload";
import DownloadAndView from '@/components/order/DownloadAndView'

const stakeTitle = {
  "2": "修改材料进场人员",
  "0": "修改要料施工单位材料进场人员",
  "1": "修改施工监理单位材料进场人员",
  "3": "修改材料进场人员"
};

const roleList = [
  {
    role: "21",
    roleId: "2002",
    label: "采购商授权代表：（城市公司项目经理）",
    showLabel: "采购商授权代表（城市公司项目经理）",
    corpId: "",
    acctId: "",
    corpList: [],
    labelWidth: '144px',
    acctList: []
  },
  {
    role: "22",
    roleId: "2004",
    label: "合同盖章人：",
    showLabel: "合同盖章人",
    corpId: "",
    acctId: "",
    corpList: [],
    labelWidth: '144px',
    acctList: [],
  },

  // {
  //   role: "24",
  //   roleId: "2003",
  //   label: "合同签字人：",
  //   showLabel: "合同签字人",
  //   labelWidth: '190px',
  //   corpId: "",
  //   acctId: "",
  //   corpList: [],
  //   acctList: [],
  // },
  {
    role: "28",
    roleId: "2010",
    label: "项目部材料员：",
    showLabel: "项目部材料员",
    corpId: "",
    acctId: "",
    corpList: [],
    acctList: []
  },
  {
    role: "29",
    roleId: "2006",
    label: "收发货印章管理员：",
    showLabel: "收发货印章管理员",
    labelWidth: '144px',
    corpId: "",
    acctId: "",
    corpList: [],
    acctList: []
  },
  {
    role: "0", // 施工单位企业名称
    roleId: "0",
    label: "企业名称：",
    showLabel: "企业名称",
    corpId: "",
    acctId: "",
    corpList: [],
    acctList: []
  },
  {
    role: "00",
    roleId: "3002",
    label: "授权代表：",
    showLabel: "授权代表",
    labelWidth: '190px',
    corpId: "",
    acctId: "",
    corpList: [],
    acctList: []
  },
  {
    role: "01",
    roleId: "3009",
    label: "项目经理：",
    showLabel: "项目经理",
    corpId: "",
    acctId: "",
    corpList: [],
    acctList: []
  },
  {
    role: "02",
    roleId: "2006",
    label: "项目盖章人：",
    showLabel: "项目盖章人",
    corpId: "",
    acctId: "",
    labelWidth: '190px',
    corpList: [],
    acctList: []
  },
  {
    role: "1", // 监理单位企业名称
    roleId: "1",
    label: "企业名称：",
    showLabel: "企业名称",
    corpId: "",
    acctId: "",
    corpList: [],
    acctList: []
  },
  {
    role: "10",
    roleId: "660",
    label: "授权代表：",
    showLabel: "授权代表",
    corpId: "",
    acctId: "",
    corpList: [],
    acctList: []
  },
  {
    role: "11",
    roleId: "661",
    label: "项目盖章人：",
    showLabel: "项目盖章人",
    corpId: "",
    acctId: "",
    corpList: [],
    acctList: []
  },
  {
    role: "30", // 供应商
    label: "供应商授权代表：",
    showLabel: "供应商授权代表（代理商）",
    labelWidth: '144px',
    corpId: "",
    acctId: "",
    corpList: [],
    acctList: [],
    roleId: "3002"
  },
  // {
  //   role: "32",
  //   label: "供应商合同签字人：",
  //   showLabel: "供应商合同签字人",
  //   corpId: "",
  //   acctId: "",
  //   corpList: [],
  //   acctList: [],
  //   roleId: "3003",
  // },
  {
    role: "31",
    label: "供应商合同盖章人：",
    showLabel: "供应商合同盖章人",
    corpId: "",
    labelWidth: '144px',
    acctId: "",
    corpList: [],
    acctList: [],
    roleId: "2004",
  },
  {
    role: "33",
    label: "供应商项目盖章人：",
    showLabel: "供应商项目盖章人",
    labelWidth: '187px',
    corpId: "",
    acctId: "",
    corpList: [],
    acctList: [],
    roleId: "2006",
  }
];

export default {
  mixins: [accountMixin],
  components: {
    Loading,
    FixBottom,
    DownloadAndUpload,
    DownloadAndView,
  },
  data() {
    return {
      isLoading: false,
      showBox: false,
      title: "",
      editRole: "",
      orderNo: "",
      beforeChangeCorpId: "",
      roleList: [],
      corpList: [],
      showError: false,
      showFileError: false,
      remoteTypeRole: null,
      fileTypeId: "",
      supplierId: "",
      orderStatus: "",
      corpIdLists: [],
      uploadFiles: [],
      templateFile: {},
      orderInfo: {},
      rules: {
      }
    };
  },
  computed: {
    computedRole() {
      return function (roleId = [], acctList) {
        if(this.role === 'B'){
          if(roleId[0] === '2006'){
            roleId = ['2006', '3010']
          }
        }
        let outputList = [];
        acctList.forEach(item => {
          if (item.roleIds && item.roleIds.length) {
            let onOff = item.roleIds.some(_item => {
              return roleId.includes(_item.roleId)
            });
            if (onOff) {
              outputList.push(item)
            }
          }
        });
        return outputList
      }
    },
    isAdmin() {
      let adminRoles = ['1000', '2000', '3000', '4000', '5000', '9000'];
      return this.userinfo.roleIds && this.userinfo.roleIds.some(item => {
        return adminRoles.indexOf(item.roleId) != -1
      });
    },
  },
  methods: {
    handleGoUsersManage(corpId) {
      if (corpId != this.userinfo.corpId) {
        return false
      }
      if (this.isAdmin) {
        this.$router.push({
          path: this.role == 'S' ? "/vendorCenter/usersManage" : "/purchaserCenter/usersManage",
          query: {
          }
        })
      }
    },
    addConstructionCompany() {
      this.showError = this.showFileError = false;
      this.roleList.push({
        role: "0", // 施工单位企业名称
        roleId: "0",
        label: "企业名称：",
        showLabel: "企业名称",
        corpId: "",
        acctId: "",
        corpList: this.corpList || [],
        acctList: []
      }, {
          role: "00",
          roleId: this.role === 'S' ? this.isAgent ? '3008' : '3008' : '3002',
          label: "授权代表：",
          showLabel: "授权代表",
          labelWidth: '190px',
          corpId: "",
          acctId: "",
          mobile: "",
          stakeHolderId: "",
          corpList: [],
          uploadFile: {},
          acctList: []
        }, {
          role: "01",
          roleId: this.role === 'S' ? this.isAgent ? '3009' : '3009' : '3009',
          label: "项目经理：",
          showLabel: "项目经理",
          corpId: "",
          acctId: "",
          mobile: "",
          stakeHolderId: "",
          corpList: [],
          acctList: []
        }, {
          role: "02",
          roleId: this.role === 'S' ? this.isAgent ? '3010' : '3010' : '2006',
          label: "项目盖章人：",
          showLabel: "项目盖章人",
          labelWidth: '190px',
          corpId: "",
          acctId: "",
          mobile: "",
          stakeHolderId: "",
          corpList: [],
          acctList: []
        });
      // this.uploadFiles.push({
      //   attachName:"",
      //   viewUrl:"",
      //   businessType:"CONTRACT_FORMATION",
      //   fileTypeId:"authorityConstructor",
      //   corpId:"",
      //   attachUrl:"",
      // })
    },
    close() {
      this.roleList = []
      this.uploadFiles = []
      this.$refs['form'].resetFields()
      this.showBox = false
    },
    getAttachInfo(info) {
      this.roleList.forEach((item, ind) => {
        if (info.fromId == ind && (item.role == '00' || item.role == '30' || item.role == '21')) {
          if ((info.attachName != this.templateFile.uploadFileNameRule + '.' + this.templateFile.uploadFileSuffix)) {
            if (this.templateFile.uploadFileNameRuleType === 'same') {
              this.$message.info("已将文件名更改为【" + this.templateFile.uploadFileNameRule + "】");
              item.uploadFile.attachName = this.templateFile.uploadFileNameRule + '.' + this.templateFile.uploadFileSuffix
            } else if (this.templateFile.uploadFileNameRuleType === 'like') {
              this.$message.info("已将文件名更改为【" + this.templateFile.uploadFileNameRule + '-' + item.corpName + "】");
              item.uploadFile.attachName = this.templateFile.uploadFileNameRule + '-' + item.corpName + '.' + this.templateFile.uploadFileSuffix;
            }
          } else {
            if (this.templateFile.uploadFileNameRuleType === 'same') {
              item.uploadFile.attachName = info.attachName;
            } else if (this.templateFile.uploadFileNameRuleType === 'like') {
              this.$message.info("已将文件名更改为【" + this.templateFile.uploadFileNameRule + '-' + item.corpName + "】");
              item.uploadFile.attachName = this.templateFile.uploadFileNameRule + '-' + item.corpName + '.' + this.templateFile.uploadFileSuffix;
            }
          }
          item.uploadFile.viewUrl = info.attachUrl;
          item.uploadFile.attachUrl = info.attachPath;
          item.uploadFile.corpId = item.corpId;
        }
      });
      this.$forceUpdate()

    },
    open(stakeHolders, role, fileTypeId, orderStatus, purchaserId, orderInfo) {
      this.editRole = role;
      // 初始化
      this.orderInfo = orderInfo || {}
      this.orderNo = stakeHolders[0] && stakeHolders[0].orderNo || '';
      this.fileTypeId = fileTypeId;
      this.orderStatus = orderStatus;
      let corpId = "";
      this.roleList = [];
      let corpIdLists = [];
      this.corpIdLists = [];
      // 获取已经存在的施工单位corpId，用于判断新增的与已存在的是否重复
      stakeHolders.forEach((item) => {
        if (item.role[0] == "0" && item.corpId) {
          corpIdLists.push(item.corpId)
        }
      });
      for (let i = 0; i < corpIdLists.length; i++) {
        if (corpIdLists.indexOf(corpIdLists[i]) == i) {
          this.corpIdLists.push(corpIdLists[i])
        }
      }
      if (role !== '0') {
        roleList.forEach(item => {
          if (item.role[0] == role) {
            const obj = Object.assign({}, item);
            console.log(obj);
            if (stakeHolders) {
              stakeHolders.forEach(stake => {
                if (item.role == stake.role) {
                  corpId = stake.corpId;
                  obj.stakeHolderId = stake.stakeHolderId;
                  obj.corpId = stake.corpId || '';
                  obj.acctId = stake.acctId;
                  obj.acctName = stake.acctName;
                  obj.mobile = stake.mobile;
                  obj.uploadFile = stake.uploadFile || {
                    attachName: "",
                    viewUrl: "",
                    businessType: "CONTRACT_FORMATION",
                    fileTypeId: this.fileTypeId,
                    corpId: stake.corpId || "",
                    attachUrl: "",
                  };
                } else if (item.role == stake.role[0]) {
                  // 企业名称初始化公司id
                  obj.corpId = stake.corpId || "";
                }
              });
            }
            this.roleList.push(obj);
          }
        });
      } else {
        console.log(stakeHolders, '--stakeHolders');
        stakeHolders.forEach(stake => {
          corpId = stake.corpId;
          if (stake.role == '00') {
            if (this.role === 'B') {
              this.roleList.push({
                role: "0", // 施工单位企业名称
                roleId: "0",
                ind: stake.ind,
                corpName: stake.corpName || '',
                label: "企业名称：",
                showLabel: "企业名称",
                corpId: stake.exist == '1' ? '0' : stake.corpId || '',
                acctId: "",
                corpList: [],
                acctList: []
              })
            }
            this.roleList.push({
              role: "00",
              roleId: this.role === 'S' ? this.isAgent ? '3008' : '3008' : '3002',
              ind: stake.ind,
              label: "授权代表：",
              showLabel: "授权代表",
              labelWidth: this.role === 'S' ? '' : '190px',
              corpId: stake.corpId || "",
              corpName: stake.corpName || '',
              acctId: stake.acctId,
              mobile: stake.mobile,
              stakeHolderId: stake.stakeHolderId,
              uploadFile: stake.uploadFile || {
                attachName: "",
                viewUrl: "",
                businessType: "CONTRACT_FORMATION",
                fileTypeId: this.fileTypeId,
                corpId: stake.corpId || "",
                attachUrl: "",
              },
              corpList: [],
              acctList: []
            });

          } else if (stake.role == '01') {
            this.roleList.push({
              role: "01",
              roleId: this.role === 'S' ? this.isAgent ? '3009' : '3009' : '3009',
              label: "项目经理：",
              ind: stake.ind,
              showLabel: "项目经理",
              corpId: stake.corpId || "",
              acctId: stake.acctId,
              mobile: stake.mobile,
              stakeHolderId: stake.stakeHolderId,
              corpList: [],
              acctList: []
            })
          } else if (stake.role == '02') {
            this.roleList.push({
              role: "02",
              roleId: this.role === 'S' ? this.isAgent ? '3010' : '3010' : '2006',
              ind: stake.ind,
              label: "项目盖章人：",
              showLabel: "项目盖章人",
              labelWidth: '190px',
              corpId: stake.corpId || "",
              acctId: stake.acctId,
              mobile: stake.mobile,
              stakeHolderId: stake.stakeHolderId,
              corpList: [],
              acctList: []
            })
          }
        });
        this.roleList.forEach(item => {
          stakeHolders.forEach(_item => {
            if (item.role === '0') {
              item.corpList.push({
                corpId: _item.corpId,
                corpName: _item.corpName,
              })
            }
          });
          if (item.role === '0') {
            if (item.corpId == '0') {
              this.roleList.splice(1, 3)
            } else {
              if (item.corpId && this.userinfo.corpId != item.corpId) {
                this.getSubRole(item.corpId);
              }
            }
          }
        });
        this.roleList = this.roleList.sort(this.compare)
      }
      console.log(corpId);
      console.log(this.roleList, '--roleList');
      if (role == "2" || role == "3" || this.role == "S") {
        // 优先使用 详情 传入的 corpId(purchaserId)
        console.log(purchaserId, '----purchaserId');
        this.getSubRole(purchaserId || this.userinfo.corpId);
      }
      this.getOrderConfiguration();
      this.showBox = true
    },
    compare(obj1, obj2) {
      var val1 = obj1.ind;
      var val2 = obj2.ind;
      if (val1 < val2) {
        return -1;
      } else if (val1 > val2) {
        return 1;
      } else {
        return 0;
      }
    },
    filterCurrentRole(role, acctList) {
      let roleId = [role.roleId]
      console.log(role, acctList)
      if(this.role === 'B'){
        // if(roleId[0] === '5002'){
        //   roleId = ['5002', '4008', '3008']
        // }
        // if(roleId[0] === '5003'){
        //   roleId = ['5003', '4009', '3009']
        // }
        if(roleId[0] === '2006'){
          roleId = ['2006', '3010']
        }
      }

      let arr = [];
      acctList.forEach(item => {
        if (item.roleIds) {
          item.roleIds.forEach(__item => {
            if (roleId.includes(__item.roleId)) {
              console.log(roleId);
              arr.push(item);
            }
          })
        }
      });
      if (roleId.includes('2002')) {
        console.log(arr);
      }
      // if (arr.length == 0 && this.userinfo.corpId == role.corpId) {
      //   arr.push({
      //     acctName: `<p style="color: #aaa">暂无${role.label}&nbsp;&nbsp;请设置<em style="cursor: pointer;color: #3a8ee6" @click="go()">权限管理</em>添加</p>`
      //   })
      // }
      return arr
    },
    //删除施工单位
    handleDelConstructor(item, index) {
      console.log(index);
      this.roleList.splice(index, 4)
      console.log(this.roleList);
    },
    handlegoUsersManage(option) {
      if (option.acctName.indexOf("暂无") != -1) {
        this.$router.push('/vendorCenter/usersManage')
      }
    },
    filterRoleName(list) {
      const arr = [];
      if (list && list.length) {
        list.forEach(item => {
          if (item.roleName) {
            arr.push(item.roleName);
          }
        });
      }

      return arr.join(",");
    },
    showFileErrorMsg(item) {
      if (!this.showFileError) return;
      let msg = "";
      if (!item.uploadFile.attachUrl) {
        msg = "请上传授权书";
      }
      return msg;
    },
    // 显示错误信息
    showErrorMsg(item) {
      if (!this.showError) return;
      let msg = "";
      if (item.role.length == 1 && !item.corpId) {
        msg = "请选择" + item.showLabel;
      } else if (item.role.length > 1 && !item.acctId) {
        msg = "请选择" + item.showLabel;
      }
      return msg;
    },
    handleChangeRole($event, item, index) {
      console.log(item);
      if (item.role == '00' || item.role == '21' || item.role == '30') {
        item.uploadFile.attachName = '';
        item.uploadFile.attachUrl = '';
        item.uploadFile.viewUrl = '';
      }
    },
    handleVisibleChage($event, item, index) {
      if (!$event) return;
      this.beforeChangeCorpId = item.corpId || "";
      console.log(this.beforeChangeCorpId);
      this.remoteTypeRole = item.role;
      if (item.role[0] == 0) {
        // this.getCorpList("construction", "");
      } else if (item.role[0] == 1) {
        this.getCorpList("supervisory", "");
      }
    },
    // 远程搜索施工、监理企业名称
    handleFilterCorp(keyword) {
      if (this.remoteTypeRole[0] == 0 && keyword != "") {
        this.getCorpList("construction", keyword);
      } else if (this.remoteTypeRole[0] == 1) {
        this.getCorpList("supervisory", keyword);
      }
    },
    handleChangeCorp(item, index) {
      if (item.corpId !== '0') {
        let corpIdLists = [];
        item.corpList.forEach(corp => {
          if (corp.corpId === item.corpId) {
            item.corpName = corp.corpName
          }
        });
        this.roleList.forEach((rol, ind) => {
          if (rol.corpId === item.corpId) {
            rol.corpName = item.corpName
          }
          if (rol.role == '0' && rol.corpId && ind !== index) {
            corpIdLists.push(rol.corpId)
          }
        });
        let onOff = false
        corpIdLists.forEach(id => {
          if (id === item.corpId) {
            onOff = true;
            this.$message.error("已存在此要料施工单位，请重新选择");
            item.corpId = this.beforeChangeCorpId;
          }
        });
        if (!onOff) {
          if (this.beforeChangeCorpId === '0') {
            this.roleList.splice(index + 1, 0, {
              role: "00",
              roleId: "3002",
              label: "授权代表：",
              showLabel: "授权代表",
              corpId: "",
              acctId: "",
              mobile: "",
              stakeHolderId: "",
              uploadFile: {
                attachName: "",
                viewUrl: "",
                businessType: "CONTRACT_FORMATION",
                fileTypeId: this.fileTypeId,
                corpId: "",
                attachUrl: "",
              },
              corpList: [],
              acctList: []
            }, {
                role: "01",
                roleId: "3009",
                label: "项目经理：",
                showLabel: "项目经理",
                corpId: "",
                acctId: "",
                mobile: "",
                stakeHolderId: "",
                corpList: [],
                acctList: []
              }, {
                role: "02",
                roleId: "3009",
                label: "项目盖章人：",
                showLabel: "项目盖章人",
                corpId: "",
                acctId: "",
                mobile: "",
                stakeHolderId: "",
                corpList: [],
                acctList: []
              });
          }
          item.corpList.forEach(corp => {
            if (corp.corpId === item.corpId) {
              this.$set(this.roleList[index + 1], 'corpName', corp.corpName)
            }
          });
          for (let i = index + 1; i < index + 4; i++) {
            this.roleList[i].corpId = item.corpId;
            this.roleList[i].acctId = "";
            this.roleList[i].mobile = "";
            this.roleList[i].stakeHolderId = "";
            if (this.roleList[i].uploadFile) {
              this.roleList[i].uploadFile = {
                attachName: "",
                viewUrl: "",
                businessType: "CONTRACT_FORMATION",
                fileTypeId: this.fileTypeId,
                corpId: "",
                attachUrl: "",
              }
            }
          }
          this.getSubRole(item.corpId, "search");
        }
      } else {
        if (this.roleList.length > 4) {
          this.roleList.splice(index, 4);
        } else {
          this.roleList.splice(index + 1, 3)
        }
      }
    },
    handleConfirm() {
      let valid1 = true;
      let valid2 = true;
      this.roleList.forEach(item => {
        // 排除 item.role == 21 项目经理
        if (item.role == '21') {
          return
        }
        if (item.role.length > 1 && !item.acctId) {
          valid1 = false;
          this.showError = true;
        }
        if ((item.role == '00' || item.role == '30' || (item.role == '21' && item.acctId !== '暂无')) && !item.uploadFile.viewUrl) {
          valid1 = false;
          this.showFileError = true;
        }
      });
      if (valid1 && valid2) {
        this.saveStakeHolder();
      }
    },
    // 查询施工或监理公司信息
    getCorpList(type, corp) {
      const params = {
        contractCorpType: type,
      };
      if (corp) {
        params.corpName = corp;
      }

      InterfaceService.getStakeHolderCorp(
        params,
        data => {
          let res = data.respData;
          if (res.respCode === "0000") {
            this.corpList = data.respData.corpInfos;
            let corpList = data.respData.corpInfos;
            corpList.forEach(item => {
              this.$set(item, 'show', true)
            });
            let existList = [];
            this.roleList.forEach(item => {
              if (item.role.length == 1) {
                existList.push(item.corpId)
              }
            });
            this.roleList.forEach(item => {
              if (item.role.length == 1) {
                // item.corpList.forEach(_item=>{
                //   if (_item.corpId === item.corpId) {
                //     let onOff = false;
                //     corpList.forEach(corp=>{
                //       if (corp.corpId == _item.corpId) {
                //         onOff = true;
                //       }
                //     })
                //     if (!onOff) {
                //       this.$set(_item,'show',true)
                //       corpList.push(_item)
                //     }
                //   }
                // });
                // if (init) {
                if (item.corpId === this.beforeChangeCorpId) {
                  item.corpList = [];

                  corpList.forEach(corp => {
                    let exist = false;
                    existList.forEach(exi => {
                      console.log(exi, corp.corpId);
                      if (exi === corp.corpId) {
                        exist = true;
                      }
                    })
                    if (!exist) {
                      item.corpList.push(corp)
                    }
                  });
                  if (item.corpId && item.corpId != '0') {
                    let onOff = item.corpList.some(corp => {
                      return corp.corpId === item.corpId
                    });
                    if (!onOff) {
                      item.corpList.push({
                        corpId: item.corpId,
                        corpName: item.corpName,
                        show: true,
                      })
                    }
                  }
                }
                // }
              }
            });

            console.log(this.roleList);
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => {
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    noDataText(label, role) {
      let str = "";
      if (role[0] == "0") {
        str = `暂无${label},请联系施工方管理员`
      } else if (role[0] == "1") {
        str = `暂无${label},请联系监理单位管理员`
      }
      return str
    },
    // 查询项目部下属信息
    getSubRole(corpId, type) {
      const params = {
        corpId: corpId
      };
      InterfaceService.getQuerySubordinate(
        params,
        data => {
          let res = data.respData;
          if (res.respCode === "0000") {
            let roles = [];
            res.acctList && res.acctList.forEach(i => {
              if (i.acctStatus == "0") {
                roles.push(i)
              }
            });
            // let arr = [];
            this.roleList.forEach(item => {
              if (item.corpId == corpId) {
                item.acctList = this.$clone(roles)
              }
            });
            console.log(this.roleList, '--roleList');
            this.arrangementRole(corpId);
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => {
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    arrangementRole(corpId) {
      this.roleList.forEach(item => {
        if (this.role === 'S') {
          if (this.isAgent) {
            if (item.roleId === '3002') {
              item.roleId = '3002'
            } else if (item.roleId === '3003') {
              item.roleId = '4003'
            } else if (item.roleId === '2004') {
              item.roleId = '2004'
            } else if (item.roleId === '3008') {
              item.roleId = '3008'
            } else if (item.roleId === '3009') {
              item.roleId = '3009'
            } else if (item.roleId === '3010') {
              item.roleId = '3010'
            } else if (item.roleId === '3009') {
              item.roleId = '3009'
            }
          } else {
            if (item.roleId === '3002') {
              // 乙方信息 项目人员变更 供应商授权代表 - 显示不正确 修复
              // item.roleId = '3008'
            } else if (item.roleId === '3009') {
              item.roleId = '3009'
            }
          }
        }
      });
      this.roleList.forEach(item => {
        if (item.corpId === corpId && item.acctId != '暂无') {
          let currentRoleList = this.computedRole([item.roleId], item.acctList);
          console.log(currentRoleList)
          let onOff = currentRoleList.some(_item => {
            return _item.acctId === item.acctId;
          });
          if (!onOff) {
            item.acctId = ''
          }
          if (currentRoleList.length === 1) {
            item.acctId = currentRoleList[0].acctId
          }
        }
      })
      console.log(this.roleList, '----暂无');

    },
    saveStakeHolder() {
      // let params = {
      //     orderNo: this.orderNo,
      //     stakeholders : []
      // };
      // this.roleList.forEach(item => {
      //     if (item.role.length > 1 && item.acctId) {
      //         params.stakeholders.push({
      //             id: item.stakeHolderId,
      //             role: item.role,
      //             corpId: item.corpId,
      //             acctId: item.acctId,
      //             participant:item.role[0]
      //         });
      //     }
      // });
      const params = {},
        arr = [];
      params.uploadFiles = [];
      //施工单位暂无
      this.roleList.forEach(item => {
        if (item.role === '21' && item.acctId === '0') {
          item.acctId = ''
        }
      });
      if (this.roleList.length == 1) {
        arr.push({
          exist: "1",
          role: "00",
          corpId: "",
          acctId: ""
        }, {
            exist: "1",
            role: "01",
            corpId: "",
            acctId: ""
          }, {
            exist: "1",
            role: "02",
            corpId: "",
            acctId: ""
          })
      } else {
        this.roleList.forEach(item => {
          item.acctName = item.acctId;
          if (item.role.length > 1) {
            arr.push({
              id: item.stakeHolderId,
              role: item.role,
              corpId: item.corpId,
              acctId: item.acctName,
              exist: '0'
            });
          }
          if ((item.role == '00' || item.role == '30' || item.role == '21') && item.acctId !== '') {
            if (item.uploadFile && item.uploadFile.attachUrl) {
              params.uploadFiles.push(item.uploadFile)
            }
          }
        });
      }
      params.orderNo = this.orderNo
      params.stakeholders = arr;
      console.log(params);
      // return
      InterfaceService.saveStakeHolder(
        params,
        data => {
          console.log(data);
          if (data.respCode === "0000") {
            if (data.respData.respCode === "0000") {
              this.showBox = false;
              this.$message.success("修改成功");
              this.$emit('close', true);
              console.log(this.orderInfo, 'this.orderInfo');

              if (['03'].includes(this.orderStatus) || (['05'].includes(this.orderStatus) && ['2', '4'].includes(this.orderInfo.approveStatus))) {
                this.getOrderTemplate();
              }
            } else {
              this.$message.error(data.respData.respMsg);
            }
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => {
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    getOrderTemplate() {
      const params = {
        orderNo: this.orderNo
      };
      InterfaceService.getOrderTemplate(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
        } else {
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    getOrderConfiguration() {
      const params = {
        businessType: 'CONTRACT_FORMATION'
      };
      InterfaceService.getOrderConfiguration(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let uploadFileList = res.uploadFileList || []
          uploadFileList.forEach(i => {
            // if (i.fileTypeId === 'authorityPurchaser') {
            if (i.fileTypeId === this.fileTypeId) {
              this.templateFile.name = i.fileTypeName;
              this.templateFile.url = i.attachUrl;
              this.templateFile.uploadFileNameRule = i.uploadFileNameRule;
              this.templateFile.uploadFileSuffix = i.uploadFileSuffix;
              this.templateFile.uploadFileNameRuleType = i.uploadFileNameRuleType;
              this.templateFile.templateFileName = i.templateFileName;
            }
          });
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  }
};
</script>

<style lang="scss" scoped>
.box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .confirmContract {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    height: 500px;
    overflow-x: hidden;
    overflow-y: auto;
    .content {
      width: 1185px;
      margin: 0 auto 100px;
      font-size: 14px;
      line-height: 17px;
      .title {
        padding: 20px 0;
        border-bottom: 1px solid #eee;
        margin-bottom: 20px;
      }
      .box-gray {
        padding: 15px 10px;
        font-size: 14px;
        line-height: 20px;
        background: #dddddd;
      }
      .address {
        width: 100%;
        > li {
          margin-bottom: 14px;
          > div {
            display: flex;
          }
          .left {
            width: 140px;
            border: 1px solid #dddddd;
            height: 50px;
            font-size: 14px;
            line-height: 50px;
            text-align: center;
          }
          .right {
            width: calc(100% - 140px);
            height: 50px;
            padding: 0 50px 0 10px;
            position: relative;
            > p {
              font-size: 14px;
              line-height: 50px;
              > i {
                display: inline-block;
                width: 17px;
                height: 17px;
                background: url("../../../assets/images/icon/check.png")
                  no-repeat;
                background-size: contain;
                margin-left: 2px;
                visibility: hidden;
              }
            }
            > span {
              position: absolute;
              right: 10px;
              top: 16px;
              display: none;
            }
          }
          &.active,
          &:hover {
            .left {
              background: linear-gradient(122deg, #d7b064 0%, #ecce8b 100%);
              color: #fff;
              border: none;
            }
            .right {
              border: 1px dashed #444;
              background-color: #f0f8ff;
              > p {
                > i {
                  visibility: visible;
                }
              }
              > span {
                display: block;
              }
            }
          }
        }
      }
      .enclosure {
        margin-bottom: 22px;
        .upload {
          /deep/ .el-input,
          input {
            position: absolute;
            left: -9999px;
            width: 0px;
            height: 0px;
            overflow: hidden;
            opacity: 0;
          }
        }
        /deep/ .el-form-item {
          margin-bottom: 0 !important;
          label {
            width: auto !important;
            line-height: 20px;
            font-size: 14px;
          }
        }
        /deep/ .el-form-item__label {
          color: #444 !important;
          text-align: left;
          width: auto !important;
        }
        /deep/ .el-form-item__content {
          position: relative;
          margin-left: 0 !important;
        }
        /deep/ .el-form-item__error {
          position: absolute;
        }
        .pickPepoleCardUrl {
          /deep/ .el-form-item__error {
            position: absolute;
          }
        }
        .biddingAuthorizationUrl {
          /deep/ .el-form-item__error {
            position: absolute;
          }
        }
        a {
          position: absolute;
        }
        /deep/ .enclosure-content {
          font-size: 12px;
          margin-top: 34px;
          width: 1185px;
          border: 1px solid rgba(221, 221, 221, 1);
          padding: 0 10px;
          // line-height: 45px;
          line-height: 17px;
          padding: 14px 10px;
          > div {
            margin-top: 14px;
            &:first-child {
              margin-top: 0px !important;
            }
          }
          // span {
          //   margin-right: 12px;
          // }
        }
        .tip-text {
          margin-top: 26px;
          line-height: 17px;
        }
        .has-text {
          margin-top: 5px;
        }
      }
    }
  }
}
/deep/ .el-select {
  width: 400px;
  input {
    height: 32px;
    line-height: 32px;
  }
}
.authorized {
  /deep/ .el-form-item__label {
    line-height: 17px;
  }
}
.special-form-item {
  position: relative;
  /deep/ {
    .el-form-item__label {
      margin-bottom: 6px;
      text-align: left;
      color: #444 !important;
      line-height: 17px;
    }
    .el-form-item__content {
      margin-left: 0 !important;
      line-height: 22px;
    }
  }
}
.enclosure-content {
  width: 1185px;
  background: #ffffff;
  border: 1px solid #dddddd;
  padding: 10px;
  line-height: 17px;
  font-size: 12px;
  margin-top: 6px;
  p {
    margin-bottom: 10px;
  }
  p:last-of-type {
    margin-bottom: 0;
  }
}
h1 {
  margin-bottom: 20px;
  font-size: 14px;
  font-weight: 600;
  line-height: 20px;
  > span {
    font-weight: normal;
    margin: 0 20px 0 6px;
  }
  > i {
    font-weight: normal;
  }
}
.width-auto {
  width: 1185px;
  margin-left: -595px;
}
.margin-auto {
  margin-left: 0;
}
/deep/ .el-col {
  position: relative;
  .del-txt {
    position: absolute;
    top: 20px;
    right: 84px;
    font-size: 12px;
    z-index: 20;
  }
}
.is-disabled {
  color: #444;
  cursor: auto;
  font-size: 12px;
  text-align: center;
  padding-top: 3px;
  border-top: 1px solid #eee;
}
.chargeOfContract {
  position: absolute;
  left: 595px;
  /deep/ .el-select {
    width: 400px;
  }
}

.aegalAuthorizedClient {
  position: relative;
  /deep/ .el-form-item__label {
    margin-top: -8px;
  }
  &::after {
    content: "(法人代表或授权委托人)";
    position: absolute;
    width: 130px;
    text-align: right;
    color: #888;
    white-space: pre;
    left: 30px;
    top: 21px;
  }
  &.projectSigner {
    &::after {
      content: "(收发货公司项目章的电子用印人)";
      left: -70px;
    }
  }
  &.htzdzyyr {
    &::after {
      content: "(合同章电子用印人)";
      left: 6px;
    }
  }

  &.left52 {
    &::after {
      left: 52px !important;
    }
  }
  &.fLeft27 {
    &::after {
      left: -27px !important;
    }
  }
  &.fLeft83 {
    &::after {
      left: -83px !important;
    }
  }
}
.el-row {
  overflow: initial;
}
</style>
