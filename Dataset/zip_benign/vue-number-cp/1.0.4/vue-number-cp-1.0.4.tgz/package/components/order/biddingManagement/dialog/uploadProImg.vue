<template>
  <div class="uploadProImg">
    <el-dialog class="dialog dialog-drafts" :title="isGroupPrice=='1'?'上传商品图':'上传组价商品图'" :append-to-body="true" :lock-scroll="true" :visible.sync="showRelease" width="850px" center :close-on-click-modal="false" :show-close="false">
      <div class="drafts-list tl">
        <div class="order-info-title bold tl" style="margin-top: 0px">商品主图</div>
        <div class="main">
          <div class="left tr"><i class="red" v-if="isPictureIsFlag=='1'">*</i> 上传图片：</div>
          <div class="right">
            <div class="info-master-img">
              <div class="img-item" :class="{ 'has-img': mainimg.attachUrl }">
                <div class="img-item-cover">
                  <div class="img-item-add">
                    <label for="masterImg" v-show="!mainimg.attachUrl">
                      <i class="cross-add"></i>
                    </label>
                    <p v-show="!mainimg.attachUrl" class="f12" style="line-height:17px;color: #bbb">点击上传图片</p>
                    <img v-if="mainimg.attachUrl" :src="mainimg.attachUrl" />
                    <input id="masterImg" name="masterImg" type="file" ref="imgFileBtn" @change="pushImg($event,'','main')" />
                  </div>
                  <div class="img-item-bottom clearfloat" v-if="mainimg.attachUrl">
                    <a @click="dialogVisibleAttachUrl=mainimg.attachUrl;dialogVisible=true">预览</a>
                    <a @click="clearImg('','main')">删除</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="info f12">
              主图：图片大小500K以内，规格 800X800像素， 72分辨率（dpi），格式 JPG/png/gif。<br>
              商品图片清晰不失真，不得出现拉伸、变形、压缩等非等比例缩放情况。<br>
              图片不得拼接、不得出水印、不包含夸大描述等文字说明，图片中不包含其他任何非本平台以外的文字说明，比如其他网站名、其他公司地址等。
            </div>
          </div>
        </div>

        <div v-if="isGroupPrice=='1'" class="order-info-title bold tl" style="margin-top: 30px">商品详情图</div>
        <p v-if="isGroupPrice=='1'" class="f12" style="margin-bottom: 20px">详情页可用图文结合方式表现，图片清晰不失真，不得出现拉伸、变形、压缩等非等比例缩放情况。<br>
          图片尺寸，宽度930px，高度自定义，格式jpg/png/gif，每张图片大小不超过500K。</p>
        <div class="detail" v-if="isGroupPrice=='1'">
          <div class="left tr"><i class="red" v-if="isPictureIsFlag=='1'">*</i> 上传图片：</div>
          <div class="right">
            <div class="info-master-img">
              <div class="img-item" :class="{ 'has-img': img.attachUrl }" v-for="(img, index) in imgList" :key="index">
                <div class="img-item-cover">
                  <div class="img-item-add">
                    <label :for="'masterImg' + index" v-show="!img.attachUrl">
                      <i class="cross-add"></i>
                    </label>
                    <p v-show="!img.attachUrl" class="f12" style="line-height:17px;color: #bbb">点击上传图片</p>
                    <img v-if="img.attachUrl" :src="img.attachUrl" />
                    <input :name="'masterImg' + index" :id="'masterImg' + index" type="file" ref="imgFileBtn" @change="pushImg($event, index)" />
                  </div>
                  <div class="img-item-bottom clearfloat" v-if="img.attachUrl">
                    <a v-show="index!=0" @click="switchImg(index,index-1)" style="width: 20%"><img src="@/assets/images/icon/left-arrow-blue.png" alt=""></a>
                    <a class="not-allowed" v-show="index==0" style="width: 20%"><img src="@/assets/images/icon/left-arrow-grey.png" alt=""></a>
                    <a class="tl" @click="dialogVisibleAttachUrl=img.attachUrl;dialogVisible=true">预览</a>
                    <a class="tr" @click="clearImg(index)">删除</a>
                    <a v-show="index!=4" @click="switchImg(index,index+1)" style="width: 20%"><img src="@/assets/images/icon/right-arrow-blue.png" alt=""></a>
                    <a class="not-allowed" v-show="index==4" style="width: 20%"><img src="@/assets/images/icon/right-arrow-grey.png" alt=""></a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div slot="footer" class="searchbox">
          <el-button type="primary" :disabled="submitCheck" :class="{'isDisabled-primary':submitCheck}" @click="submit('0')">提交</el-button>
          <!-- <el-button @click="submit('1')">预览</el-button> -->
          <el-button @click="showRelease=false">取消</el-button>
        </div>
      </div>
    </el-dialog>
    <!-- 预览图片 -->
    <el-dialog title="图片预览" :visible.sync="dialogVisible" class="img-preview" width="840px">
      <div class="img-box">
        <img :src="dialogVisibleAttachUrl" alt="" />
      </div>
      <div class="shut-down hand" @click="dialogVisible=false">关闭</div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import { ImageUtil } from '@/utils/imageUtil';
export default {
  components: {
    Loading,
  },
  data() {
    return {
      isLoading: false,

      isGroupPrice: '1',//'1':上传基本商品图 '2':上传组价商品图
      spuId: [], //商品id
      dialogVisible: false,
      dialogVisibleAttachUrl: '',
      showRelease: false,
      mainimg: {  //主图
        attachUrl: '',
        attachName: '',
        position: '0',
        file: '',
        id: '',
        type: '1'
      },
      delMainimg: [],//主图删除的id
      imgList: [],// 详情图
      delImgList: [],//详情图删除的id
      switchImgList: [],// 提交后从列表获取数据的图片列表
      isUploadImg: false, // 是否开始上传
      isPictureIsFlag: ''//商品图片是否必传0-否，1-是
    }
  },
  computed: {
    submitCheck() {
      if (this.isUploadImg) {
        return true
      } else {
        if (this.isPictureIsFlag == '0') {
          return false
        }
        // console.log(this.imgList.some(i => i.attachUrl))
        if (this.isPictureIsFlag == '1' && this.isGroupPrice == '1' && this.mainimg.attachUrl && this.imgList.some(i => i.attachUrl)) {
          return false
        } else if (this.isPictureIsFlag == '1' && this.isGroupPrice == '2' && this.mainimg.attachUrl) {
          return false
        } else {
          return true
        }
      }
    }
  },
  methods: {
    // 初始化图片列表
    imgListData() {
      this.imgList = []
      for (let i = 0; i < 5; i++) {
        this.imgList.push({
          'attachUrl': '', //全路径
          'position': String(i), // 图片位置
          'attachName': '',//图片名称
          'id': '',//oss图片id
          'file': '',// 图片文件流
          'type': '2'
        })
      }
    },
    submit(btnType) { // 0:提交 1:预览
      if (btnType == '1') {
        return
      }

      let listImg = [];
      // 详情
      this.imgList.forEach(i => {
        if (!i.id && i.file) {
          listImg.push(i)
        }
      })
      // 主图
      if (this.mainimg.file && !this.mainimg.id) {
        listImg.push(this.mainimg)
      }
      // console.log(listImg.length)
      // console.log(btnType)
      // 图片数据整理
      if (listImg.length && btnType != 1) {
        // 去压缩
        let fileImgList = []
        listImg.forEach(i => {
          fileImgList.push(i.file)
        });
        this.isLoading = true
        ImageUtil.handleChangeMasterImg(fileImgList, 500, 1000, (files) => {
          listImg.forEach((i, index) => {
            files.forEach(j => {
              if (i.file.name == j.name && i.file.type == j.type) {
                i.file = j
              }
            })
          })

          this.isUploadImg = true
          this.getOssSignatureDisposable(listImg)
        })
        // } else {//已经上传过图片 则直接提交
        //   this.isLoading = false;
        //   this.judgebtnType(btnType)
        // }
      } else {
        this.isLoading = false;
        this.supplierUpload()
      }
    },
    // 拿签名上传图片
    getOssSignatureDisposable(listImgs) {
      let _this = this
      InterfaceService.getOssSignatureDisposable('',{}, (data) => {
        _this.isLoading = false;
        const promiseList = [];
        let signature = data
        // 处理多组spuId图片上传(批量商品图)
        let listImg = []
        this.spuId.forEach(i => {
          listImgs.forEach(j => {
            listImg.push({
              spuId: i,
              attachName: j.attachName,
              attachUrl: j.attachUrl,
              file: j.file,
              id: j.id,
              position: j.position,
              type: j.type,
            })
          });
        });
        for (let pos = 0; pos < listImg.length; pos++) {
          let file = listImg[pos] && listImg[pos].file
          let position = listImg[pos] && listImg[pos].position || ''
          let spuId = (listImg[pos] && listImg[pos].spuId + '/') || ''
          // console.log(position)
          let type = listImg[pos] && listImg[pos].type
          if (file) {
            let dirType = 'product/' + spuId
            const promise = new Promise(_resolve => {
              // 上传OSS
              _this.uploadHander(pos, file, dirType, signature, (pos, file, dirType, signature) => {
                //let u = signature.host+'/'+signature.dir+dirType+file.name
                // console.log(signature)
                let u = '#url#/' + signature.dir + dirType + file.name;
                _resolve({ 'attachUrl': u, 'attachName': file.name, 'position': position, 'type': type, spuId: dirType.split('/')[1] });
              },() => { this.isLoading = true; }, () => { this.isLoading = false; })
            });
            promiseList.push(promise);
          }
        }
        // 上传所有图片后回调
        Promise.all(promiseList).then(values => {
          console.log(values)
          //图片上传到oss之后 提交注册信息
          _this.supplierUpload(values)
        });
      }, (data) => {
        _this.isLoading = false;
      },
        () => {
          _this.isLoading = true;
        },
        () => {
          //_this.isLoading = false;
        });
    },
    uploadHander(pos, file, dirType, signature, callBack, loadingStartCb, loadingEndCb) {
      InterfaceService.uploadToOss(signature, file, dirType, pos, callBack, '', '', loadingStartCb, loadingEndCb)
    },
    // 供应商上传商品图片 接口
    supplierUpload(values = []) {
      this.isUploadImg = false
      let spuAttachList = values
      // 获取移动过得图片列表
      let switchList = [] // 位置移动的图片列表
      if (this.isGroupPrice == '1') {
        let a = this.imgList.filter(i => i.id)
        // console.log(a)
        // console.log(this.switchImgList)
        if (a.length) {
          a.forEach(i => {
            this.switchImgList.forEach(j => {
              if (i.attachName == j.attachName && i.id == j.id && i.position != j.position) {
                switchList.push({
                  id: i.id,
                  position: i.position,
                })
              }
            });
          });
        }
      }
      spuAttachList = spuAttachList.concat(this.delMainimg, this.delImgList, switchList)
      // console.log(spuAttachList)
      let param = {
        spuAttachList: spuAttachList,
      }
      InterfaceService.supplierUpload(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('提交成功')
          this.$emit('updateData')
          this.showRelease = false
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 图片上传
    pushImg(event, index, type) {//input控件（自定义）获取文件 上传
      let file = event.target.files[0]
      // console.log(event);
      // console.log(file);
      if (file) {
        let checkTextList = JSON.parse(sessionStorage.getItem('checkTextList') || '[]');
        let onOff = false;
        let forbidText = ''
        checkTextList.forEach(i=>{
          if (i != '' && file.name.indexOf(i) != -1) {
            onOff = true
            forbidText = i
          }
        });
        if (onOff) {
          this.$message.error('文件名包含特殊字符【'+forbidText+'】,请修改文件名后再上传')
          return false
        }
        // 判断是否图片
        if ((file.type).indexOf("image/") == -1) {
          this.$message.error('请选择图片')
          return false
        }
        // base64
        let reader = new FileReader();
        reader.onloadend = () => {
          // console.log(type)
          if (type == 'main') {
            this.mainimg.attachUrl = reader.result
            this.mainimg.file = file;
          } else {
            this.imgList[index].attachUrl = reader.result
            this.imgList[index].file = file;
          }
          this.$forceUpdate();
        }
        if (file) {
          reader.readAsDataURL(file);
        }

      }
      this.resetInputValue('masterImg'+index);
      // event.target.value = ''
    },
    /**
     * 重置input value  防止 同一个文件连续提交 不触发 onchange事件
     */
    resetInputValue(name) {
      let isIE10 = false,
        uploadInputs = document.getElementsByName(name) || []
      isIE10 = window.navigator.userAgent.indexOf('MSIE') >= 1;
      for (let i = 0, len = uploadInputs.length; i < len; i++) {
        const element = uploadInputs[i];
        if (isIE10) {
          let form = document.createElement('form'),
            beforInput = element.nextSibling,
            parentInput = element.parentNode

          form.appendChild(element)
          form.reset()
          parentInput.insertBefore(element, beforInput)
        } else {
          element.value = ''
        }

      }
    },
    // 图片切换位置
    switchImg(index1, index2) { // index1: 当前位置 ,index2: 交换的位置
      let arr = this.imgList
      arr[index1] = arr.splice(index2, 1, arr[index1])[0];
      this.imgList.forEach((i, index) => {
        i.position = String(index)
      });
      // console.log(this.imgList)
    },
    // 文件删除
    clearImg(index, type) {
      let file = '';
      if (type == 'main') {
        // 储存删除图片的id
        if (this.mainimg.id) {
          this.delMainimg.push({ id: this.mainimg.id })
        }
        this.mainimg = {  //主图
          attachUrl: '',
          attachName: '',
          position: '0',
          file: '',
          id: '',
          type: '1'
        }
        file = document.getElementById("masterImg")
      } else {
        // 储存删除图片的id
        if (this.imgList[index].id) {
          this.delImgList.push({ id: this.imgList[index].id })
        }
        this.imgList.splice(index, 1, {
          'attachUrl': '', //全路径
          'attachName': '',//图片名称
          'id': '',//oss图片id
          'file': '',// 图片文件流
          'position': String(index), // 图片位置
          'type': '2'
        })
        // this.imgList[index] = {
        //   'attachUrl': '', //全路径
        //   'attachName': '',//图片名称
        //   'id': '',//oss图片id
        //   'file': '',// 图片文件流
        //   'position': String(index), // 图片位置
        //   'type': '2'
        // }
        file = document.getElementById("masterImg" + index)
      }
      file.value = "";
      this.$forceUpdate();
      this.$message.success('删除成功')
    },
    close() {

    },
    // 批量上传时不需要从列表带图片数据
    open(dataList = [], isGroupPrice) {
      this.spuId = []
      this.delMainimg = []
      this.delImgList = []
      this.switchImgList = []
      this.isGroupPrice = isGroupPrice
      this.mainimg = {  //主图
        attachUrl: '',
        attachName: '',
        position: '0',
        file: '',
        id: '',
        type: '1'
      }
      // console.log(dataList)
      this.imgListData()
      if (dataList.length < 2) { // 单商品上传回显数据
        this.isPictureIsFlag = dataList[0].pictureIsFlag
        this.spuId = [dataList[0].spuId]
        if ((dataList[0].spuAttachList || []).length) {
          let a = dataList[0].spuAttachList.filter(i => i.type == '1')
          let b = dataList[0].spuAttachList.filter(i => i.type == '2')
          if (a.length) {
            this.mainimg = {  //主图
              attachUrl: a[0].attachUrl,
              attachName: a[0].attachName,
              position: '0',
              file: '',
              id: a[0].id,
              type: '1'
            }
          }
          b.forEach((i, index) => {
            this.imgList.forEach(j => {
              if (i.position == j.position) {
                j.attachUrl = i.attachUrl
                j.attachName = i.attachName
                j.position = i.position
                j.id = i.id
              }
            });
          });
        }
      } else {
        this.isPictureIsFlag = '1'
        dataList.forEach(i => {
          this.spuId.push(i.spuId)
          if ((i.spuAttachList || []).length) {
            i.spuAttachList.forEach(j => {
              if (j.type == '2' && isGroupPrice == '1') {
                this.delImgList.push({ id: j.id })
              } else {
                this.delMainimg.push({ id: j.id })
              }
            });
          }
        });
      }
      this.switchImgList = this.$clone(this.imgList)
      // this.imgList.forEach(i => {
      //   this.switchImgList.push(i)
      // });
      // console.log(this.mainimg)
      // console.log(this.imgList)
      // console.log(this.switchImgList)
      this.showRelease = true

    }
  },
}
</script>
<style lang="scss" scoped>
.dialog-drafts {
  /deep/ .el-dialog__body {
    padding: 10px 20px 30px !important;
  }
  line-height: 17px;
  .main {
    display: flex;
    .left {
      min-width: 77px;
      white-space: nowrap;
    }
    .right {
      display: flex;
      .info-master-img {
        width: 126px;
        .img-item-cover {
          .img-item-bottom {
            a {
              width: 50% !important;
            }
          }
        }
      }
      .info {
        margin-left: 40px;
        max-width: 566px;
      }
    }
  }
  .detail {
    display: flex;
    .left {
      min-width: 77px;
      white-space: nowrap;
    }
  }
  .info-master-img {
    .img-item {
      position: relative;
      display: inline-block;
      width: 126px;
      height: 126px;
      vertical-align: middle;
      margin: 0 25px 0px 0;
      border: 1px dashed #ccc;
      border-radius: 2px;
      &:last-child {
        margin-right: 0;
      }
    }

    .img-item-add {
      display: flex;
      // justify-content: center;
      flex-direction: column;
      align-items: center;
      height: 100%;
      font-size: 30px;
      text-align: center;
      color: #ccc;
      position: relative;
      overflow: hidden;
      // > label {

      // }
      i {
        cursor: pointer;
        &.cross-add {
          width: 40px;
          height: 40px;
          display: inline-block;
          position: relative;
          margin: 30px 0 12px;
          &::before {
            content: "";
            width: 100%;
            height: 1px;
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            margin: auto 0;
            background-color: #ddd;
          }
          &::after {
            content: "";
            width: 1px;
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            margin: 0 auto;
            background-color: #ddd;
          }
        }
      }

      input[type="file"] {
        display: none;
      }
      img {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        // max-height: 100%;
        pointer-events: none;
        height: auto;
      }
    }

    .img-item-cover {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(255, 255, 255, 0);
      margin-bottom: 10px;

      .img-item-bottom {
        display: none;
        position: absolute;
        width: 100%;
        text-align: center;
        background: rgba(255, 255, 255, 0.8);
        bottom: 0;
        padding: 0;
        line-height: 24px;
        height: 24px;

        a {
          width: 30%;
          float: left;
          vertical-align: middle;
          color: #0082ff;
          font-size: 12px;
          text-align: center;
          > img {
            justify-content: center;
            align-items: center;
            width: 6px;
            height: 6px;
          }
        }
      }
    }

    .img-item:hover {
      .img-item-cover {
        background: rgba(255, 255, 255, 0.2);
      }
      .img-item-bottom {
        display: block;
      }
    }

    img {
      width: 100%;
      height: 100%;
      border: none;
    }

    .img-item.has-img {
      &:hover .img-item-add {
        display: flex;
      }
    }
  }
  /deep/ .searchbox {
    text-align: center;
    margin-top: 20px;
    display: flex;
    justify-content: center;

    .el-button.el-button--primary {
      width: 120px;
      height: 34px;
      line-height: 34px;
      background: linear-gradient(122deg, #d7b064 0%, #ecce8b 100%);
      padding: 0;
    }
    .el-button.el-button--default {
      width: 120px;
      height: 34px;
      line-height: 32px;
      padding: 0;
    }
    .el-button + .el-button {
      margin-left: 20px;
    }
  }
}
/deep/ .img-preview {
  .el-dialog__body {
    padding: 10px 20px 80px;
  }
  .img-box {
    max-height: 500px;
    overflow: hidden;
    overflow-y: scroll;
    text-align: center;
    img {
      max-width: 800px;
    }
  }
  .shut-down {
    width: 120px;
    height: 34px;
    line-height: 34px;
    padding: 0;
    font-size: 12px;
    text-align: center;
    color: #fff;
    background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
    margin: 0 auto;
    position: absolute;
    left: 0;
    right: 0;
    bottom: 30px;
  }
}
</style>