<template>
  <div>
    <div class="box_type">{{isQUESTIONS?('当前招标提问开始时间为：'+planStartTime+'；结束时间为：'+planEndTime):'发起提问前请先查看「全部问题」，避免重复问题的提问。'}}</div>
    <div class="tr" :style="{height: nodePlan == 'QUIZ' ? '50px' : '0'}">
      <el-button type="primary" class="small-btn" v-if="nodePlan == 'QUIZ'" :disabled="isQUESTIONS" @click="handleCreateQuestion('create',bidNo)">创建问题</el-button>
    </div>
    <div class="tab-change">
      <ul>
        <li :class="{active:publishStatus == 'PUBLISH'}" @click="handleChangeLoginType('PUBLISH')">
          <span>全部问题</span>
        </li>
        <li :class="{active:publishStatus == 'ANNOUNCED'}" @click="handleChangeLoginType('ANNOUNCED')">
          <span>待发布的提问</span>
        </li>
      </ul>
      <div class="fold-btn blue hand f12" @click="handleAllFold">{{allFoldFlag ? '全部展开' : '全部收起'}}
        <i v-if="allFoldFlag" class="el-icon-caret-bottom"></i>
        <i v-else class="el-icon-caret-top"></i>
      </div>
    </div>
    <div class="search-container">
      <el-form class="form" ref="formOne" :model="form" label-width="80px" size="small" >
        <el-row>
          <el-form-item label="主题搜索：">
            <el-input v-model="form.keyWord"  placeholder="请输入关键词" style="height: 34px;"></el-input>
          </el-form-item>
        </el-row>
        <!--<el-row>-->
          <!--<el-col :span="8">-->
        <div style="display: inline-block;width: 41.5%;" v-if="publishStatus == 'PUBLISH'">
          <el-form-item label="提问类型：">
            <el-radio @change="refresh" v-model="form.selfQA" label="2">全部</el-radio>
            <el-radio @change="refresh" v-model="form.selfQA" label="1">我方提问</el-radio>
            <el-radio @change="refresh" v-model="form.selfQA" label="0">其他参与方提问</el-radio>
            <el-radio @change="refresh" v-if="nodePlan && nodePlan !== 'QUIZ'" v-model="form.selfQA" label="3">公告</el-radio>
          </el-form-item>
        </div>
        <div style="display: inline-block;width: 30.5%;">
          <el-form-item label="分类："  label-width="50px">
            <el-radio-group v-model="form.qaClassify" @change="refresh">
              <el-radio v-model="form.qaClassify" label="0">全部</el-radio>
              <template v-if="nodePlan == 'QUIZ'">
                <el-radio v-for="(item,index) in QAClassifyList.filter(i=>{return i.code != 'NOTICE'})" :key="index" :label="item.code">{{item.value}}</el-radio>
              </template>
              <template v-else>
                <el-radio v-for="(item,index) in QAClassifyList" :key="index" :label="item.code">{{item.value}}</el-radio>
              </template>
            </el-radio-group>
          </el-form-item>
        </div>
      <!--</el-col>-->
      <!--<el-col :span="8" v-if="publishStatus == 'PUBLISH'">-->
        <div style="display: inline-block;width: 27%;" v-if="publishStatus == 'PUBLISH'">
          <el-form-item label="回复情况：">
            <el-radio-group v-model="form.answerStatus" @change="refresh">
              <el-radio label="0">全部</el-radio>
              <el-radio v-for="(item,index) in reverseList" :key="index" :label="item.code">{{item.value}}</el-radio>
            </el-radio-group>
          </el-form-item>
        </div>
          <!--</el-col>-->
          <!--<el-col :span="8" v-if="publishStatus == 'PUBLISH'">-->

          <!--</el-col>-->
        <!--</el-row>-->
        <el-row class="tc">
          <el-button type="primary" class="small-btn" @click="refresh">
            搜索
          </el-button>
          <el-button class="small-btn" @click="handleClear">
            清除
          </el-button>
        </el-row>
      </el-form>
    </div>
    <div class="batch-select" v-if="publishStatus == 'ANNOUNCED'">
      <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow" :disabled="!bidQAInfoList.length">全选</el-checkbox>
      <el-button class="small-btn" :disabled="!hasChecked || !bidQAInfoList.length" @click="handleOperation(3)">批量删除</el-button>
      <el-button class="small-btn" v-if="nodePlan == 'QUIZ'" size="primary" :disabled="!hasChecked || !bidQAInfoList.length" @click="handleOperation(1)">批量发布问题</el-button>
    </div>
    <div class="question-container" :class="{'tab-two':publishStatus == 'ANNOUNCED','disabled-bg':nodePlan !== 'QUIZ' && publishStatus == 'ANNOUNCED'}" v-for="(item,index) in bidQAInfoList" :key="index">
      <el-checkbox v-if="publishStatus == 'ANNOUNCED'" class="item-checked" v-model="item.checked" @change="handleSelectTableRow(item,index)"></el-checkbox>
      <div class="title">
        <span class="ques-index" :class="{'self-bg':item.selfQA == '1','not-self-bg':item.selfQA == '0','notice-bg': item.qaType == 'NOTICE','grey-bg':publishStatus == 'ANNOUNCED'}">{{item.index}}</span>
        <span class="ques-title" :title="item.qaTheme">
          <b class="bold fl"><em v-if="item.qaType == 'NOTICE'">【公告】</em>主题：</b><span class="text">{{item.qaTheme}}</span>
          <em class="tip-qa" v-if="item.tipQA == '1'">置顶</em>
        </span>
        <span class="f12"><label class="grey f12">类别：</label><em>{{item.qaClassifyDesc}}</em></span>
        <div style="clear: both"></div>
        <div class="fold-btn blue hand f12" @click="handleItemFold(item)">
          {{item.foldFlag ? '展开':'收起'}}
          <i v-if="item.foldFlag" class="el-icon-caret-bottom"></i>
          <i v-else class="el-icon-caret-top"></i>
        </div>
      </div>
      <div style="display: table;" v-if="!item.foldFlag">
        <div class="content" :class="{'others-content':item.selfQA == '0'}">
          <div class="text lh17" v-html="item.qaDescription">
          </div>
          <div class="files" :style="{margin:item.selfQA == '1' ? '10px 0 20px' : '10px 0 0'}">
            <div class="files-left fl" style="width: 80%;">
              <b class="bold fl">附件：</b>
              <template v-if="item.qaAttachInfoList.length" >
                <p v-for="file in item.qaAttachInfoList">{{file.attachName}}<span class="hand blue" @click="handleDownload(file.attachUrl,file.attachName)">下载</span></p>
              </template>
              <p v-else>暂无附件</p>
            </div>
            <div class="fr">
              <p class="fr grey"  v-if="publishStatus == 'PUBLISH'">提问时间：{{item.publishTime && item.publishTime.substring(0,19)}}</p>
              <p class="fr grey" v-else>创建时间：{{item.createTime && item.createTime.substring(0,19)}}</p>
            </div>
            <p style="clear: both;"></p>
          </div>
          <div class="grey" v-if="item.selfQA == '1'">
            <p class="fl">提问者：{{item.createAcctName}}</p>
            <p style="clear: both;"></p>
          </div>
        </div>
        <div class="operation" v-if="item.selfQA == '1' && nodePlan == 'QUIZ'">
          <p><span class="hand blue" @click="handleOperation(2,item.bidQaNo)" v-if="publishStatus == 'PUBLISH'">撤回</span></p>
          <p><span class="hand blue" @click="handleCreateQuestion('edit',bidNo,item.bidQaNo)" v-if="publishStatus == 'ANNOUNCED'">编辑</span></p>
          <p><span class="hand blue" @click="handleOperation(1,item.bidQaNo)" v-if="publishStatus == 'ANNOUNCED'">发布</span></p>
          <p><span class="hand blue" @click="handleOperation(3,item.bidQaNo)" v-if="publishStatus == 'ANNOUNCED'">删除</span></p>
        </div>
        <div class="operation" v-if="item.selfQA == '1' && nodePlan !== 'QUIZ'">
          <p><span class="hand blue" @click="handleOperation(3,item.bidQaNo)" v-if="publishStatus == 'ANNOUNCED'">删除</span></p>
        </div>
      </div>
      <div v-if="!item.foldFlag" class="answer-content" v-for="(ans,ind) in item.qaAnswerInfoList">
        <p class="fl f14" style="width: 82%;" :title="ans.answerTheme"><span class="answer-theme">回复：</span><i></i>{{ans.answerTheme}}</p>
        <p class="fr grey" style="line-height: 18px;">回复时间：{{ans.publishTime && ans.publishTime.substring(0,19)}}</p>
        <p style="clear: both;padding-bottom: 0;"></p>
        <div class="answer-content-text lh17" v-html="ans.answerDescription">
        </div>
        <div class="answer-content-files">
          <b class="bold fl">附件：</b>
          <template v-if="ans.qaAnswerAttachInfoList.length">
            <p v-for="anFile in ans.qaAnswerAttachInfoList">{{anFile.attachName}}<span class="hand blue" @click="handleDownload(anFile.attachUrl,anFile.attachName)">下载</span></p>
          </template>
          <p v-else></p>
        </div>
      </div>
    </div>
    <div class="table-pagination" v-if="bidQAInfoList.length">
      <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="totalCount" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
      </el-pagination>
    </div>
    <div class="accout-empty" v-if="!bidQAInfoList.length&&!isLoading">
      <img src="@/assets/images/icon-no-product.png">
      <p>没有相关的问题，请重新修改搜索条件搜索！</p>
    </div>
    <putQuestion ref="putQuestion" @refresh="refresh"></putQuestion>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
  import accountMixin from "@/mixins/account";
  import Loading from "@/components/base/Loading";
  import { InterfaceService } from "@/services/api";
  import putQuestion from "@/components/order/biddingManagement/dialog/putQuestion"
  const form = {
    keyWord:"",
    qaClassify:"0",
    selfQA:"2",
    answerStatus:"0",
  }
  export default {
    mixins: [accountMixin],
    components: {
      Loading,
      putQuestion,
    },
    name: "SupplierQuestion",
    props:["bidNo","nodePlan","planList"],
    data() {
      return {
        publishStatus : "PUBLISH",
        pageIndex : 1,
        isLoading : false,
        allChecked : false,
        hasChecked: false,
        pageSize : 10,
        totalCount : 0,
        bidQAInfoList:[],
        answerStatusList:[],
        publishStatusList:[],
        QAClassifyList:[],
        QATypeList:[],
        allFoldFlag : false,
        form : Object.assign({},form),
        isQUESTIONS: false,
        planStartTime: '',
        planEndTime: '',
      }
    },
    computed:{
      reverseList() {
        return this.answerStatusList.reverse()
      }

    },
    methods:{
      handleDownload(url,name) {
        let attach = [];
        attach.push({
          url :url,
          name : name
        });
        this.$download(attach).then(res=>{
          this.$message.success("已下载");
        }).catch(res=>{
          this.$message.error("下载失败");
        })
      },
      handleOperation(type,bidQaNo) {
        let title = "",str = "",btn="";
        if (bidQaNo) {
          if (type == 1){
            title = "确认发布问题";
            str = "确认要发布问题吗？";
            btn = "确认发布"
          } else if (type == 2) {
            title = "撤回问题";
            str = "确认撤回本条提问内容，撤回后请在【待发布的提问】列表查看。";
            btn = "确认撤回"
          }else {
            title = "删除问题";
            str = "删除问题后将无法恢复，确认要删除问题吗？";
            btn = "确认删除"
          }
        }else {
          let list = []
          // 点击「批量删除」给与弹层二次确认： 标题：批量删除回复 内容：请确认是否删除勾选的N条提问，删除后不能撤回。 按钮：确认删除 取消
          // 点击「批量发布提问」给与弹层二次确认： 标题：批量发布提问 内容：请确认勾选的N条提问内容表述完善，若无误，点击【发送】按钮即可。 按钮：发送 取消
          this.bidQAInfoList.forEach(item=>{
            if (item.checked) {
              list.push(item)
            }
          });
          if (type == 1) {
            title = "确认批量发布问题";
            str = "请确认勾选的"+list.length+"条提问内容表述完善，若无误，点击【发送】按钮即可。 ";
            btn = "发送"
          } else {
            title = "批量删除问题";
            str = "请确认是否删除勾选的"+list.length+"条提问，删除后不能撤回。";
            btn = "确认删除"
          }
        }
        this.$confirm(
          str,
          title,
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center:true,
            confirmButtonText: btn,
            cancelButtonText: '取消',
          }).then(() => {
          let params = {};
          let bidQaNos = [];
          if (bidQaNo)  {
            bidQaNos.push(bidQaNo)
          }else {
            this.bidQAInfoList.forEach(item=>{
              if (item.checked) {
                bidQaNos.push(item.bidQaNo)
              }
            });
          }
          params = {
            bidQaNos,
            handleType:type
          };
          InterfaceService.supplierQustionOperation(params, data => {
              if (data && data.respData && data.respData.respCode === "0000") {
                this.$message.success("操作成功！");
                if (type == 1) {
                  this.publishStatus = "PUBLISH"
                }else if (type == 2) {
                  this.publishStatus = "ANNOUNCED"
                }
                if (!bidQaNo) {
                  this.allChecked = false
                }
                this.refresh()
              } else {
                this.$message.error(data.respData.respMsg)
              }
            },
            data => { },
            () => { this.isLoading = true },
            () => { this.isLoading = false })
        }).catch(() => {
        });
      },
      handleBatchDel() {

      },
      handleBatchCreate() {

      },
      // 选中行
      handleSelectTableRow(item, index) {
        this.$set(this.bidQAInfoList, index, item);
        this.checkBatch();
        this.checkAllSelect();
      },
      // 是否全选
      checkAllSelect() {
        this.allChecked = this.bidQAInfoList.every(item => {
          return item.checked;
        });
      },
      // 全选
      handleAllSelectTableRow(bool) {
        let arr = [];
        arr = [].concat(this.bidQAInfoList);
        arr.forEach(item => {
          item.checked = bool;
        });
        this.bidQAInfoList = arr;
        this.checkBatch();
      },
      // 是否可批量
      checkBatch() {
        this.hasChecked = this.bidQAInfoList.some(item => {
          return item.checked;
        });
      },
      handleCreateQuestion(type,bidNo,bidQaNo) {
        this.$refs["putQuestion"].open(type,bidNo,bidQaNo,this.QAClassifyList)
      },
      // 分页跳转
      handleCurrentChange(page) {
        this.pageIndex = page;
        window.scrollTo(0, 0)
        this.getSupplierQAList();
      },
      handleChangeLoginType(type) {
        this.publishStatus = type;
        this.form.selfQA = type == 'ANNOUNCED' ? '1' : '2'
        this.pageIndex = 1;
        this.bidQAInfoList = []
        this.getSupplierQAList()
      },
      handleItemFold(item) {
        item.foldFlag = !item.foldFlag;
        this.$set(item,"foldFlag",item.foldFlag)
        this.$forceUpdate();
        this.allFoldFlag = this.bidQAInfoList.every(item=>{
          return item.foldFlag
        })
      },
      handleAllFold() {
        this.allFoldFlag = !this.allFoldFlag;
        this.bidQAInfoList.forEach(item=>{
          item.foldFlag = this.allFoldFlag;
        })
      },
      refresh(operationType) {
        this.pageIndex = 1;

        this.getSupplierQAList()
      },
      handleClear() {
        this.form = Object.assign({},form);
        this.refresh()
      },
      getSupplierQAList() {
        let params = Object.assign({},this.form);
        params.bidNo = this.bidNo;
        params.pageIndex = this.pageIndex;
        params.publishStatus = this.publishStatus;
        params.answerStatus === "0" && delete params.answerStatus;
        params.qaClassify === "0" && delete params.qaClassify;
        params.selfQA = this.publishStatus === 'ANNOUNCED' ? '1' : params.selfQA
        params.selfQA === "2" && delete params.selfQA;
        if (params.selfQA === "3") {
          delete params.selfQA;
          params.qaType = "NOTICE"
        }
        InterfaceService.getSupplierQAList(params, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              this.bidQAInfoList = data.respData.bidQAInfoList || [];
              this.totalCount = data.respData.totoalCount || 0;
              this.pageSize = data.respData.pageSize || 0;
              this.bidQAInfoList.forEach((item,ind)=>{
                item.foldFlag = item.selfQA == "0";
                this.QAClassifyList.forEach(_item=>{
                  if (_item.code === item.qaClassify) {
                    item.qaClassifyDesc = _item.value
                  }
                });
                item.index = this.totalCount - this.pageSize * (this.pageIndex-1)  - ind;
                item.qaDescription = item.qaDescription.replace(/\n/g, '<br/>');
                item.checked = false
              });
              this.allChecked = false
              this.checkBatch()
            } else {
              this.$message.error(data.respData.respMsg)
            }
          },
          data => { },
          () => { this.isLoading = true },
          () => { this.isLoading = false })
      },
      getListConfig() {
        const params = {
          appName: 'PRODUCT',
          groupIds: ["QA_TYPE","QA_CLASSIFY","ANSWER_STATUS","PUBLISH_STATUS"],
        }
        InterfaceService.getPaymentMethod(params, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let res = data.respData.configEntityListMap || {};
            this.answerStatusList = res.ANSWER_STATUS || [];
            this.publishStatusList = res.PUBLISH_STATUS || [];
            this.QAClassifyList = res.QA_CLASSIFY || [];
            this.QATypeList = res.QA_TYPE || [];
            this.getSupplierQAList();
          } else {
            this.$message.error(data.respData.respMsg);
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      },
      init(){
        this.getListConfig();
        console.log(this.planList)
        let planStartTime
        let planEndTime
        this.planList.forEach(i=>{
          if(i.nodePlan == 'QUESTIONS'){
            this.planStartTime = i.planStartTime
            this.planEndTime = i.planEndTime
            planStartTime = i.planStartTime.replace(/-/g,'/')+' 00:00:00'
            planEndTime = i.planEndTime.replace(/-/g,'/')+' 23:59:59'
          }
        })
        planStartTime = new Date(planStartTime).getTime()
        let toDay =  new Date().getTime()
        planEndTime = new Date(planEndTime).getTime()
        if(planStartTime<=toDay && toDay<=planEndTime){
          this.isQUESTIONS = false
        }else{
          this.isQUESTIONS = true
        }
      }
    },
    mounted() {
      this.init()
    },
    watch: {
      // planList(val){
      //   console.log(val);
      //   if(val.length){
      //
      //     console.log(this.isQUESTIONS);
      //   }
      // }
    },
  }
</script>

<style scoped lang="scss">
.box_type {
  width: 100%;
  //   height: 42px;
  background: rgba(255, 252, 240, 1);
  border: 1px solid rgba(250, 226, 165, 1);
  font-size: 12px;
  line-height: 17px;
  color: #444444;
  padding: 6px 10px;
  margin: -10px 0 10px;
}
.tab-change{
  height: 40px;
  background: #f5f5f5;
  padding: 10px 20px;
    /*letter-spacing: 6px;*/
    font-size: 16px;
    margin-bottom: 15px;
    text-align: center;
    position: relative;
    color: #fff;
    & > ul {
      & > li {
        float: left;
        font-size: 14px;
        color: #313131;
        margin-right: 44px;
        text-align: center;
        cursor: pointer;
        position: relative;
        transition: all 0.3s linear;
        span{
          font-weight: 600;
        }
        &:hover,&.active {
          &::after {
            width: 40px;
          }
        }
        &::after {
          content: "";
          width: 0;
          height: 2px;
          border-radius: 2px;
          background: #C99F4F;
          position: absolute;
          bottom: -6px;
          left: 50%;
          transform: translate(-50%, 0);
          transition: all 0.3s linear;
        }
      }
    }
}
  .search-container{
    margin-top: 10px;
    margin-bottom: 20px;
    padding: 20px 10px;
    background: #f9f9f9;
    
  }
  /deep/ {
    .el-form-item__label{
      padding: 0 4px 0 0;
    }
    .el-row{
      margin-bottom: 0;
    }
    .el-form-item--small.el-form-item{
      margin-bottom: 20px;
    }
    .el-row label{
      width: auto;
    }
    .el-radio{
      margin-right: 20px;
    }
    .el-radio__label{
      color: #888;
      padding-left: 4px;
    }
  }
  .container-height {
    min-height: 206px;
  }
  .question-container {
    margin-bottom: 14px;
    border: 1px solid rgba(221,221,221,1);
    position: relative;
    &:hover{
      border-color: #C99F4F;
    }
    .title{
      height: 40px;
      font-size: 14px;
      color: #444;
      margin-right: 10px;
      border-bottom: 1px solid #eee;
      span{
        float: left;
        line-height: 40px;
      }
      .ques-index{
        width: 40px;
        text-align: center;
        color: #fff;
      }
      .self-bg {
        background: #928ef0;
      }
      .not-self-bg{
        background: #C99F4F;
      }
      .notice-bg{
        background: #EB8E8E !important;
      }
      .grey-bg{
        background: linear-gradient(0deg,#ddd 0%,#bbb 100%) !important
      }
      .ques-title{
        width: 980px;
        padding:0 20px;
        .text{
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          max-width: 750px;
        }
      }
    }
    .content{
      display: inline-block;
      width: 1115px;
      margin: 10px 0 20px;
      border-right: 1px solid #eee;
      padding: 0 20px 0 10px;
      .text{
        padding-bottom: 20px;
        border-bottom: 1px dashed #eee;
      }
      .files{
        margin: 10px 0 20px;
        p{
          padding-left: 40px;
          span{
            padding-left: 6px
          }
        }
      }
    }
    .others-content{
      width: 1190px;
      border-right: none;
    }
    .operation{
      display: table-cell;
      vertical-align: middle;
      padding-right: 10px;
      text-align: right;
      width: 75px;
      p{
        margin-bottom: 10px;
      }
      p:last-child{
        margin-bottom: 0;
      }
    }
  }
  .tab-two{
    width: 98%;
    margin-left: 2%;
    position: relative;
    .item-checked{
      position: absolute;
      left: -24px;
      top: 12px;
    }
  }
  .disabled-bg{
    background: #ddd;
  }
.fold-btn{
  position: absolute;
  right: 10px;
  top: 12px;
}
.accout-empty {
  padding: 24px 0 72px;
  text-align: center;
  line-height: 50px;
  color: #909399;
  /deep/ .el-input{

  }
}
.answer-content{
  border-top: 1px solid #ddd;
  padding: 10px;
  position: relative;
  .answer-theme{
    font-size: 14px;
    font-weight: 600;
    position: relative;
    z-index: 1;
  }
  &>p{
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    padding-bottom: 10px;
  }
  i{
    content: "";
    height: 7px;
    position: absolute;
    top: 22px;
    left: 6px;
    width: 36px;
    background: #c99f4f;
  }
  .answer-content-text{
    padding: 10px;
    border-top: 1px solid #eee;
    border-bottom: 1px dashed #eee;
  }
  .answer-content-files{
    min-height: 30px;
    padding: 10px 10px 7px;
    p{
      padding-left: 40px;
      span{
        padding-left: 6px
      }
    }
  }
}
  /deep/ .batch-select{
    margin-bottom: 10px;
    .el-button{
      margin-left: 10px;
    }
    .el-checkbox__label{
      padding-left: 4px;
    }
  }
.tip-qa{
  margin-left: 10px;
  color: #fff;
  border-radius: 2px;
  background: #6763c9;
  font-size: 14px;
  text-align: center;
  padding: 2px 6px;
  height: 20px;
}
</style>