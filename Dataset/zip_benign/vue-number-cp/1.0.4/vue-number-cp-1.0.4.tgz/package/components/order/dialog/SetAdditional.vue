<template>
  <transition name="el-zoom-in-bottom">
    <div class="box" v-show="showBox">
      <div class="addMockList">
        <div class="content">
          <div class="title tc">设置附加项</div>
          <p class="f12" style="margin: 10px 0px">请勾选附加项，根据实际需求填写数量，点击【确认】即可。</p>
          <div class="center">
            <table>
              <thead>
                <tr>
                  <td style="padding-left: 30px">商品名称/型号</td>
                  <td width="160px" class="tr">基础价(不含税)(元)</td>
                  <td width="340px" style="padding-right: 20px" class="tr">附加项总价(不含税)(元)</td>
                  <td width="200px" class="tr">单价(不含税)(元)</td>
                </tr>
              </thead>
              <tbody class="'tbody-active'">
                <tr>
                  <td style="padding-left: 30px">
                    <div class="skuName">
                      <div class="attachImg" :class="{'active':!info.attUrl}">
                        <img v-if="info.attUrl" :src="info.attUrl" alt="">
                      </div>
                      <div class="model">
                        <p class="f12 ellipsisTwo" :title="info.skuName">{{info.skuName}}</p>
                        <p class="f12" style="margin: 9px 0 6px">型号：{{info.skuModel ? info.skuModel : info.model ? info.model : '-'}}</p>
                      </div>
                    </div>
                  </td>
                  <td class="tr" width="160px">{{info.skuPrice | formatMoney}}</td>
                  <td class="tr" width="340px" style="padding-right: 20px" v-if="info.bidSurchangeBeanList">{{surchangeTotalPrice}}</td>
                  <td class="tr" width="200px" v-if="info.bidSurchangeBeanList">{{surchangeBasis}}</td>
                </tr>
              </tbody>
            </table>
            <el-row style="margin: 30px 0 10px">
              <el-col>
                <el-checkbox v-model="checkboxAll" style="margin: 0px 10px 0px 26px;" @change="checkboxChange">全选</el-checkbox>
              </el-col>
            </el-row>
            <table>
              <thead>
                <tr>
                  <td width="40px" style="padding: 0 0 0 26px"></td>
                  <td width="100px">序号</td>
                  <td>附加项名称</td>
                  <td width="160px" class="tr">单价(不含税)(元)</td>
                  <td width="340px" style="padding-right: 20px" class="tr"><i class="red">*</i>数量</td>
                  <td width="200px" class="tr">小计(元)</td>
                </tr>
              </thead>
              <tbody class="tbody-active" v-if="info.bidSurchangeBeanList">
                <tr v-for="(a,index) in info.bidSurchangeBeanList" :key="index" class="tbody-row">
                  <td width="40px" style="padding: 0 0 0 26px">
                    <el-checkbox v-model="a.checkBox" @change="isAllcheck"></el-checkbox>
                  </td>
                  <td width="100px">
                    {{index+1}}
                  </td>
                  <td>
                    <p class="f12 ellipsisTwo" :title="info.surchangeName">{{a.surchangeName}}</p>
                  </td>
                  <td width="160px" class="tr">{{a.surchangeUnitPrice | formatMoney}}</td>
                  <td width="340px" class="tr" style="padding-right: 20px">
                    <el-input style="width: 200px;" v-model="a.surchangeUnitCnt" placeholder="请输入数字" maxlength="64" class="right_padding" @input="a.surchangeUnitCnt=a.surchangeUnitCnt.match(/\d+(\.\d{0,2})?/) ? a.surchangeUnitCnt.match(/\d+(\.\d{0,2})?/)[0] : ''">
                      <div slot="suffix" class="suffix">{{a.surchangeUnit || ''}}</div>
                    </el-input>
                    <p v-show="Number(a.surchangeUnitCnt) === 0 && a.checkBox" class="red f12 tl" style="margin-left: 110px">商品数量不能为空或为0</p>
                  </td>
                  <td width="200px" class="tr">{{subtotal(a.surchangeUnitPrice,a.surchangeUnitCnt)}}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <FixBottom>
          <div class="tc">
            <el-button type="primary" @click="confirm">确认</el-button>
            <el-button @click="showBox = false">取消</el-button>
          </div>
        </FixBottom>
        <!-- 按钮 -->
        <!--<div class="foot" v-if="info.bidSurchangeBeanList">-->
        <!--<el-button type="primary" @click="confirm">确认</el-button>-->
        <!--<el-button @click="showBox = false">取消</el-button>-->
        <!--</div>-->
      </div>
    </div>
  </transition>

</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import { NumberUtil } from '@/utils/numberUtil';
import FixBottom from "@/components/base/FixBottom";

export default {
  props: ['mockList'],
  data() {
    return {
      isLoading: false,
      showBox: false,
      checkboxAll: false,
      info: {},
      goodsList: [],
      index: 0,
    }
  },
  components: {
    FixBottom
  },
  watch: {
    // 锁定父元素html的滚动
    showBox(val) {
      if (val) {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'hidden', 'important')
      } else {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'scroll', 'important')
      }
    }
  },
  computed: {
    surchangeBasis() {
      let num = 0;
      this.info.bidSurchangeBeanList.forEach(item => {
        if (item.checkBox) {
          num = NumberUtil.numAdd(num, +NumberUtil.accMul(Number(item.surchangeUnitPrice), Number(item.surchangeUnitCnt)))
        }
      })
      const a = NumberUtil.numAdd(num, +this.info.skuPrice)
      return NumberUtil.formatMoney(a)
    },
    surchangeTotalPrice() {
      let num = 0;
      this.info.bidSurchangeBeanList.forEach(item => {
        if (item.checkBox) {
          num = NumberUtil.numAdd(num, +NumberUtil.accMul(Number(item.surchangeUnitPrice), Number(item.surchangeUnitCnt)))
        }
      })
      return NumberUtil.formatMoney(num)
    }
  },
  methods: {
    subtotal(skuPrice, skuCount) {
      let num
      if (skuPrice && skuCount) {
        num = NumberUtil.accMul(Number(skuPrice), Number(skuCount))
        num = NumberUtil.formatMoney(num)
      } else {
        num = '-'
      }
      return num
    },
    // 全选
    checkboxChange() {
      this.info.bidSurchangeBeanList.forEach(i => {
        this.$set(i, 'checkBox', this.checkboxAll)
      })
      this.isAllcheck()
    },
    isAllcheck() {
      this.checkboxAll = this.info.bidSurchangeBeanList.every(i => i.checkBox)
    },
    confirm() {
      let result = true
      this.info.bidSurchangeBeanList.find(i => { if ((i.checkBox && !Number(i.surchangeUnitCnt))) { this.$message.error(`“${i.surchangeName}”商品数量不能为空或为0！`); result = false } })
      console.log(result)
      if (result) {
        // if (this.goodsList.length) {
        //   let hasSameGoods = false
        //   let list = this.info.bidSurchangeBeanList.filter(i=>{return i.checkBox});
        //   this.goodsList.forEach(item=>{
        //     console.log(item.skuId, this.info.skuId);
        //     if (item.skuId == this.info.skuId) {
        //       let itemList = item.bidSurchangeBeanList && item.bidSurchangeBeanList.filter(i=>{return i.checkBox}) || [];
        //       console.log(JSON.stringify(itemList),JSON.stringify(list));
        //       if (JSON.stringify(itemList) === JSON.stringify(list)) {
        //         hasSameGoods = true
        //       }
        //     }
        //   });
        //   if (hasSameGoods) {
        //     this.$message.error('已存在相同商品且附加项相同的商品，请重新设置附加项。')
        //   }else {
        //     this.$emit('updateData', this.index, this.info)
        //     this.showBox = false
        //   }
        // }else {
        this.$emit('updateData', this.index, this.info)
        this.showBox = false
        // }
      }
    },
    open(item, index, goodsList) {
      this.showBox = true
      this.index = index;
      this.goodsList = goodsList;
      this.info = this.$clone(item)
      this.info.bidSurchangeBeanList.forEach(i => {
        // if (!i.surchangeUnitCnt) {
        //   i.surchangeUnitCnt = ''
        // }
        if (!i.checkBox) {
          this.$set(i, 'checkBox', false)
          this.$set(i, 'surchangeUnitCnt', '')
          // i.surchangeUnitCnt = ''
        }
        // if (this.info.pdSkuCombinationSurchargeInfos && this.info.pdSkuCombinationSurchargeInfos.length) {
        //   this.info.pdSkuCombinationSurchargeInfos.forEach(j => {
        //     if (i.surchangeNo === j.surchangeNo) {
        //       this.$set(i, 'checkBox', true)
        //       i.surchangeUnitCnt = j.surchangeUnitCnt
        //     }
        //   })
        // }
      })
      console.log(this.info)
    },
  },
}
</script>
<style lang="scss" scoped>
.box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .addMockList {
    height: 80%;
    overflow-y: auto;
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    .content {
      width: 1190px;
      margin: 0 auto;
      font-size: 14px;
      line-height: 17px;
      padding-bottom: 80px;
      .title {
        padding: 20px 0;
        border-bottom: 1px solid #eee;
        // margin-bottom: 20px;
      }

      table,
      thead,
      tbody {
        display: block;
      }

      thead,
      tbody tr {
        display: table;
        width: 100%;
        table-layout: fixed;
      }
      table {
        margin-top: 2px;
        table-layout: fixed;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        td {
          padding: 14px 10px;
          vertical-align: middle;
          word-break: break-all;
          &:last-child {
            text-align: right;
          }
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          border-bottom: 1px solid #eee;
          background: rgba(249, 249, 249, 1);
          color: rgba(136, 136, 136, 1);
          tr {
            td {
              padding: 15px 10px;
              &:last-child {
                text-align: right;
              }
            }
          }
        }
        .tbody-row {
          &:hover {
            background: #f0f8ff;
          }
        }
        tbody {
          text-align: left;
          &.tbody-active {
            /*height: 40vh;*/
            overflow-y: auto;
          }
          tr {
            border-bottom: 1px solid #eee;
            td {
              .tag {
                width: 90px;
                height: 20px;
                background: #6598d3;
                line-height: 20px;
                font-size: 14px;
                color: #fff;
                text-align: center;
                border-radius: 2px;
              }
              .skuName {
                display: flex;
                .attachImg {
                  width: 60px;
                  height: 60px;
                  min-width: 60px;
                  position: relative;
                  overflow: hidden;
                  &.active {
                    background-color: #eee;
                  }
                  > img {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    pointer-events: none;
                    height: auto;
                  }
                }
                .model {
                  margin-left: 6px;
                }
              }
            }
          }
          .border-none {
            border-bottom: none;
          }
        }
      }
    }
    .foot {
      width: 100%;
      margin-top: 40px;
      height: 57px;
      background: rgba(49, 49, 49, 0.9);
      line-height: 57px;
      text-align: center;
      .el-button {
        width: 120px;
        height: 34px;
        line-height: 34px;
        padding: 0;
        font-size: 12px;
      }
      .el-button--primary {
        color: #fff;
        border: none;
        background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
      }
    }
  }
}
</style>