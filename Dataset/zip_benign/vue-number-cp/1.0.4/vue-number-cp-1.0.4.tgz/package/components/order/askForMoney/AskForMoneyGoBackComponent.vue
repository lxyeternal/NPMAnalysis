<template>
  <div class="component-container">
    <el-dialog class="dialog" :title="'退回原因'" :append-to-body="true" :lock-scroll="true" :before-close="handleDialogCancel" :visible.sync="visible" width="900px" center :close-on-click-modal="false">
      <div class="confirm-payment-container">
        <div class="center">
          <el-row :gutter="10">
            <el-col :span="24">
              <span>
                指定退回对象
              </span>
              <el-select v-model="goBackSelected" placeholder="请选择退回对象">
                <el-option v-for="(item, idx) in list" :key="idx" :value="item.taskId" :label="`${item.taskDescription || ''}    ${item.acctName || ''}`">
                  <span>{{item.taskDescription}} &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; {{item.acctName}}</span>
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="24">
              <span>
                退回原因
              </span>
              <el-input type="textarea" v-model="description" :rows="4" placeholder="请输入..." maxlength="200" show-word-limit />
            </el-col>
          </el-row>
        </div>
        <div class="btn-center">
          <el-button size="small" type="primary" style="width: 120px" @click="handleDialogConfirm">退回</el-button>
          <el-button size="small" style="width: 120px" @click="handleDialogCancel">取消</el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
export default {
  props: ['visible', 'order'],
  data() {
    return {
      description: '',
      goBackSelected: '',
      list: []
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.list = this.order && this.order.other && this.order.other.paymentReturnBeans || []
      console.log(this.order, this.list);

    },
    handleDialogConfirm() {
      if (!this.goBackSelected) {
        this.$message.error('请选择退回对象')
        return
      }
      this.submitPaymentDetail()
    },
    handleDialogCancel() {
      this.$emit('update:visible', false)
    },

    /**
     * 提交
     */
    submitPaymentDetail() {
      const params = {
        executionId: this.order && this.order.other && this.order.other.executionId,
        isAgree: 'N',
        comment: this.description, //  理由
        rollBackTaskId: this.goBackSelected, // 退回到的taskID
      }

      InterfaceService.submitPaymentDetail(params, data => {
        if (data.respData.respCode === "0000") {
          this.$message.success('退回成功')
          this.$emit('refresh', true)
          this.$emit('update:visible', false)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

  }
}
</script>
<style lang="scss" scoped>
.confirm-payment-container {
  .el-row {
    .el-col {
      display: flex;
      width: 100%;
      $titleWidth: 120px;
      margin: 12px 0 30px;
      overflow: hidden;
      & > span {
        margin-right: 12px;
        text-align: right;
        width: 90px;
        margin-top: 12px;
        float: left;
      }
      .el-select {
        width: calc(100% - #{$titleWidth});
      }
      .el-textarea {
        width: calc(100% - #{$titleWidth});
      }
    }
  }
  .btn-center {
    text-align: center;
  }
}
</style>
