<template>
  <div class="operate">
    <!-- 双向合同 -->
    <template v-if="order.busiType !== 'ONEWAY_ORDER'">
      <!--供应商-->
      <template v-if="userInfo.bs == 'S'">
        <!--厂家-->
        <template v-if="userInfo.supplyType == '0'">
          <!--待处理-->
          <template v-if="tab == 1">
            <!-- 结算单 bg-->
            <!-- 电子签章结算单 Bg -->
            <p v-if="order.settleStatus === '4' && order.settleType === '0' && eventListSearchAcctIdCp">
              <a @click="handleSign(order, 'settle')">电子签章</a>
            </p>
            <!-- 电子签章结算单 Ed -->
            <!-- 合同结算 -->
            <template v-if="['0', '3'].includes(order.settleStatus) && order.settleType === '0' && isSettleLaunchCp(order)">
              <a @click="handleClickSettlementEdit(order)">编辑合同结算</a>
              <a v-if="order.settleStatus == '0'" @click="handleClickSettlementCloseAndDel('0', order)">删除合同结算</a>
              <a v-if="order.settleStatus == '3'" @click="handleClickSettlementCloseAndDel('1', order)">关闭合同结算</a>
            </template>

            <template v-if="
                ['7'].includes(order.settleStatus) &&
                !order.manufacturerCorpId &&
                order.settleType === '0'
              ">
              <a @click="handleClickWthdrawSettment(order)">撤回结算申请</a>
            </template>

            <!-- 合同结算 - 解除 -->
            <template v-if="order.settleStatus == '1' && order.settleType === '1'">
              <a @click="handleOrderRescind('2', true, 'settle')">确认解除结算单</a>
              <a @click="handleOrderRescind('3', true, 'settle')">退回解除结算单</a>
            </template>

            <!-- 厂家审核结算 临时添加 3 , 后面直接退回到 经销商 -->
            <template v-if="
                ['1'].includes(order.settleStatus) && order.settleType == '0'
              ">
              <a @click="handleClickExamineSettment(order)">审核结算</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </template>

            <!-- 厂家 -已退回解除结算单 -->
            <template v-if="
                ['3'].includes(order.settleStatus) && order.settleType == '1'
              ">
              <!-- <a @click="handleClickAettleAccountsRelieve(order)">解除结算单</a> -->
              <a @click="handleClickSettlementCloseAndDel('1', order)">关闭解除结算单</a>
            </template>
            <!-- 结算单 ed -->

            <p v-if="order.orderStatus == '01'">
              <a @click="handleDraftOfCreateOrder(order)">编辑合同</a>
              <a @click="handleDel('2', order)">删除合同</a>
            </p>
            <p v-if="order.orderStatus == '07'">
              <a @click="handleOrderDetail(order, 0, false)">审核合同</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
            </p>
            <p v-if="order.orderStatus == '06'">
              <a @click="handleDraftOfCreateOrder(order)">编辑合同</a>
              <a @click="handleDel('4', order)">关闭合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
              <el-dropdown>
                <a class="el-dropdown-link">
                  更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                </a>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>
                    <a @click="handleDownloadContract(order)">下载合同</a>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </p>
            <p v-if="order.orderStatus == '05'">
              <a @click="handleSign(order, 'contract')" v-if="approveStatus === '3'">电子签章</a>
              <a @click="handleReject()" v-if="approveStatus === '4' || approveStatus === '2'">拒绝合同</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <!-- 终止合同协议电子签章 -->
            <p v-if="
                order.orderStatus === 'contractTerminating' &&
                approveStatusTermination === '3'
              ">
              <a @click="handleSign(order, 'relieve')">电子签章</a>
            </p>

            <!-- 补充合同 -->
            <p v-if="order.orderStatus == 'addProduct'">
              <template v-if="order.supplierId === userInfo.corpId">
                <a v-if="
                    subOrderObj.subOrderNo &&
                    ['01', '04', '06'].includes(subOrderObj.subOrderStatus)
                  " @click="handleSupplementOrder('1', subOrderObj)">编辑补充合同</a>
                <a v-if="
                    subOrderObj.subOrderNo &&
                    subOrderObj.subOrderStatus === '01'
                  " @click="handleDel('2', order, subOrderObj.subOrderNo)">删除补充合同</a>
                <a v-if="
                    subOrderObj.subOrderNo &&
                    ['04', '06'].includes(subOrderObj.subOrderStatus)
                  " @click="handleDel('4', order, subOrderObj.subOrderNo)">关闭补充合同</a>
              </template>

              <a v-if="subOrderObj.subOrderStatus === '07'" @click="handleOrderDetail(order, 2, false)">审核补充合同</a>
              <a v-if="
                  order.supplierId === userInfo.corpId &&
                  subOrderObj.subOrderStatus === '05' &&
                  isSignature
                " @click="handleSign(order, 'contract')">电子签章补充合同</a>
              <a v-if="
                  !(
                    subOrderObj.subOrderNo &&
                    ['01', '04', '06'].includes(subOrderObj.subOrderStatus)
                  )
                " @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>

              <el-dropdown v-if="
                  subOrderObj.subOrderNo &&
                  ['01', '04', '06'].includes(subOrderObj.subOrderStatus)
                ">
                <a class="el-dropdown-link">
                  更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                </a>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>
                    <a @click="handleDownloadContract(order)">下载合同</a>
                  </el-dropdown-item>
                  <el-dropdown-item>
                    <a @click="handleClickAettleAccounts(order)">合同结算</a>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </p>

            <!-- 解除与终止合同 -->
            <p v-if="order.supplierId === userInfo.corpId">
              <el-dropdown v-if="order.orderStatus == '05' && approveStatus === '3'">
                <a class="el-dropdown-link">
                  更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                </a>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>
                    <a @click="handleOrderRescind('1', true)">合同解除</a>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>

              <template v-if="order.orderStatus == '11' && approveStatus === '3'">
                <a v-if="isNotSettle(order)" @click="handleOrderRescind('1', false)">终止合同</a>
                <a @click="handleDownloadContract(order)">下载合同</a>
                <a @click="handleOrderDetail(order)">查看合同详情</a>
              </template>
            </p>
            <p v-if="order.orderStatus === 'contractTerminating'">
              <template v-if="order.terminatingStatus === '08'">
                <a v-if="order.terminateType == 'relieve'" @click="handleOrderRescind('2', true)">确认解除合同</a>
                <a v-if="order.terminateType == 'relieve'" @click="handleOrderRescind('3', true)">退回解除合同</a>
                <a v-if="order.terminateType == 'terminate'" @click="handleOrderRescind('2', false)">确认终止合同</a>
                <a v-if="order.terminateType == 'terminate'" @click="handleOrderRescind('3', false)">退回终止合同</a>
              </template>
              <template v-if="
                  ['15', '16'].includes(order.terminatingStatus) &&
                  order.supplierId === userInfo.corpId
                ">
                <a @click="
                    handleOrderRescind(
                      '1',
                      order.terminateType == 'relieve' ? true : false
                    )
                  ">继续{{
                  order.terminateType == "relieve" ? "解除合同" : "终止合同"
                  }}</a>
                <a @click="withdrawContract('1')">{{
                  order.terminateType == "relieve"
                  ? "关闭解除合同"
                  : "关闭终止合同"
                  }}</a>
              </template>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
          <!--进行中-->
          <template v-if="tab == 2">
            <p v-if="order.orderStatus == '01'">
              <a style="color: #444; cursor: default">-</a>
            </p>

            <!-- 电子签章结算单 -->
            <p v-if="order.settleStatus === '4' && order.settleType === '0' && eventListSearchAcctIdCp">
              <a @click="handleSign(order, 'settle')">电子签章</a>
            </p>

            <!-- 合同结算 -->
            <template v-if="['0', '3'].includes(order.settleStatus) && order.settleType === '0' && isSettleLaunchCp(order)">
              <a @click="handleClickSettlementEdit(order)">编辑合同结算</a>
              <a v-if="order.settleStatus == '0'" @click="handleClickSettlementCloseAndDel('0', order)">删除合同结算</a>
              <a v-if="order.settleStatus == '3'" @click="handleClickSettlementCloseAndDel('1', order)">关闭合同结算</a>
            </template>

            <template v-if="
                ['7'].includes(order.settleStatus) &&
                !order.manufacturerCorpId &&
                order.settleType === '0'
              ">
              <a @click="handleClickWthdrawSettment(order)">撤回结算申请</a>
            </template>

            <!-- 合同结算 - 解除 -->
            <template v-if="order.settleStatus == '1' && order.settleType === '1'">
              <a @click="handleOrderRescind('2', true, 'settle')">确认解除结算单</a>
              <a @click="handleOrderRescind('3', true, 'settle')">退回解除结算单</a>
            </template>

            <!-- 厂家审核结算 临时添加 3 , 后面直接退回到 经销商 -->
            <template v-if="
                ['1'].includes(order.settleStatus) && order.settleType == '0'
              ">
              <a @click="handleClickExamineSettment(order)">审核结算</a>
            </template>

            <!-- 厂家 -已退回解除结算单 -->
            <template v-if="
                ['3'].includes(order.settleStatus) && order.settleType == '1'
              ">
              <!-- <a @click="handleClickAettleAccountsRelieve(order)">解除结算单</a> -->
              <a @click="handleClickSettlementCloseAndDel('1', order)">关闭解除结算单</a>
            </template>

            <p v-if="
                order.orderStatus == '03' ||
                order.orderStatus == '04' ||
                order.orderStatus == '05' ||
                order.orderStatus == '06' ||
                order.orderStatus == '11'
              ">
              <a v-if="
                  order.orderStatus == '03' &&
                  order.supplierId === userInfo.corpId
                " @click="handleDel('3', order)">撤回合同</a>

              <!-- 补充合同 -->
              <template v-if="
                  (order.orderStatus == '11' && order.supplierId === userInfo.corpId)">
                <a v-if=" isNotSettle(order) && ( !subOrderObj.subOrderNo || (subOrderObj.subOrderNo && ['02', '11' ].includes(subOrderObj.subOrderStatus))) " @click=" handleSupplementOrder('', subOrderObj)">发起补充合同</a>
              </template>

              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>

            <!-- 解除与终止合同 -->
            <p v-if="order.supplierId === userInfo.corpId">
              <a v-if="order.orderStatus == '05' && approveStatus === '3'" @click="handleOrderRescind('1', true)">合同解除</a>

              <template v-if="isNotSettle(order) && order.orderStatus == '11' && approveStatus === '3'">
                <el-dropdown v-if="
                    !subOrderObj.subOrderNo ||
                    (subOrderObj.subOrderNo &&
                      ['02', '11'].includes(subOrderObj.subOrderStatus))
                  ">
                  <a class="el-dropdown-link">
                    更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                  </a>
                  <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item>
                      <a @click="handleOrderRescind('1', false)">终止合同</a>
                    </el-dropdown-item>
                    <el-dropdown-item>
                      <a @click="handleClickAettleAccounts(order)">合同结算</a>
                    </el-dropdown-item>
                  </el-dropdown-menu>
                </el-dropdown>

                <a v-else @click="handleOrderRescind('1', false)">终止合同</a>
              </template>

              <el-dropdown v-else-if="
                  (['11'].includes(order.orderStatus) &&
                  !order.settleStatus) ||
                  ['4', '9'].includes(order.settleStatus)
                ">
                <a class="el-dropdown-link">
                  更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                </a>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item v-if=" !order.settleStatus">
                    <a @click="handleClickAettleAccounts(order)">合同结算</a>
                  </el-dropdown-item>

                  <el-dropdown-item v-if="['4', '9'].includes(order.settleStatus)">
                    <!-- 合同结算 - 解除 -->
                    <!-- <a @click="handleClickAettleAccountsRelieve(order)">解除结算单</a> -->
                  </el-dropdown-item>

                </el-dropdown-menu>
              </el-dropdown>
            </p>
            <p v-if="order.orderStatus === 'contractTerminating'">
              <template v-if="order.terminatingStatus === '08'">
                <a v-if="order.terminateType == 'relieve'" @click="handleOrderRescind('2', true)">确认解除合同</a>
                <a v-if="order.terminateType == 'relieve'" @click="handleOrderRescind('3', true)">退回解除合同</a>
                <a v-if="order.terminateType == 'terminate'" @click="handleOrderRescind('2', false)">确认终止合同</a>
                <a v-if="order.terminateType == 'terminate'" @click="handleOrderRescind('3', false)">退回终止合同</a>
              </template>
              <a v-if="isSupplierWithdraw" @click="withdrawContract('0')">{{
                order.terminateType == "relieve"
                ? "撤回解除合同"
                : "撤回终止合同"
                }}</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>

            <!-- 补充合同 -->
            <p v-if="order.orderStatus === 'addProduct'">
              <a v-if="
                  subOrderObj.subOrderStatus === '03' &&
                  order.supplierId === userInfo.corpId
                " @click="handleDel('3', order, subOrderObj.subOrderNo)">撤回补充合同</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>

              <el-dropdown>
                <a class="el-dropdown-link">
                  更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                </a>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item v-if="!order.settleStatus || (order.settleStatus == '6' && order.settleType == '0') || (order.settleStatus == '4' && order.settleType == '1')">
                    <a @click="handleClickAettleAccounts(order)">合同结算</a>
                  </el-dropdown-item>

                  <el-dropdown-item v-if="['4', '9'].includes(order.settleStatus)">
                    <!-- 合同结算 - 解除 -->
                    <!-- <a @click="handleClickAettleAccountsRelieve(order)">解除结算单</a> -->
                  </el-dropdown-item>

                </el-dropdown-menu>
              </el-dropdown>
            </p>
          </template>
          <!--已关闭-->
          <template v-if="tab == 3">
            <template v-if="order.settleStatus === '1' && order.settleType === '2'">
              <a @click="handleOrderRescind('2', false, 'settle')">确认终止结算单</a>
              <a @click="handleOrderRescind('3', false, 'settle')">退回终止结算单</a>
            </template>
            <!-- 电子签章结算单 -->
            <p v-if="
              ((order.settleStatus === '10' && order.settleType === '0') ||
                (order.settleStatus === '3' && order.settleType === '2')) &&
                order.supplierId == this.mxCorpId
              ">
              <!-- <a @click="handleOrderRescind('1', false, 'settle')">终止结算单</a> -->
            </p>
            <!-- 电子签章结算单 -->
            <p v-if="order.settleStatus === '1' && order.settleType === '2' && order.supplierId == this.mxCorpId">
              <a @click="handleClickWthdrawSettment(order, '2')">撤回终止结算单</a>
            </p>

            <p v-if="order.orderStatus == '12'">
              <a @click="handleDownloadContract(order)">下载合同</a>
            </p>
            <p v-if="order.orderStatus == 'contractTerminated' || ['10'].includes(order.settleStatus)">
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
        </template>
        <!--代理商-->
        <template v-else>
          <!--待处理-->
          <template v-if="tab == 1">
            <!-- 结算单 bg -->
            <!-- 电子签章结算单 Bg -->
            <p v-if="order.settleStatus === '4' && order.settleType === '0' && eventListSearchAcctIdCp">
              <a @click="handleSign(order, 'settle')">电子签章</a>
            </p>
            <!-- 电子签章结算单 Ed -->

            <!--经销商 -已退回解除结算单 -->
            <template v-if="['3', '8'].includes(order.settleStatus) && order.settleType == '1'">
              <!-- <a @click="handleClickAettleAccountsRelieve(order)">解除结算单</a> -->
              <a @click="handleClickSettlementCloseAndDel('1', order)">关闭解除结算单</a>
            </template>

            <!-- 合同结算 - 解除 -->
            <!-- <template v-if="['1'].includes(order.settleStatus) && order.settleType == '1'">
              <a @click="handleClickConfirmEndSettment(order, '1')">撤回解除结算单</a>
            </template> -->

            <!-- 合同结算 - 经销商 -->
            <template v-if="['0', '3', '8'].includes(order.settleStatus) && order.settleType == '0' && isSettleLaunchCp(order)">
              <a @click="handleClickSettlementEdit(order)">编辑合同结算</a>
              <a v-if="order.settleStatus == '0'" @click="handleClickSettlementCloseAndDel('0', order)">删除合同结算</a>
              <a v-if="['3', '8'].includes(order.settleStatus)" @click="handleClickSettlementCloseAndDel('1', order)">关闭合同结算</a>
            </template>

            <template v-if="['1'].includes(order.settleStatus) && order.settleType == '0'">
              <a @click="handleClickWthdrawSettment(order)">撤回结算申请</a>
            </template>
            <!-- 结算单 ed -->

            <p v-if="order.orderStatus == '01'">
              <a @click="handleDraftOfCreateOrder(order)">编辑合同</a>
              <a @click="handleDel('2', order)">删除合同</a>
            </p>

            <p v-if="order.orderStatus == '04' || order.orderStatus == '06'">
              <a @click="handleDraftOfCreateOrder(order)">编辑合同</a>
              <a @click="handleDel('4', order)">关闭合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
              <el-dropdown>
                <a class="el-dropdown-link">
                  更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                </a>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>
                    <a @click="handleDownloadContract(order)">下载合同</a>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </p>

            <p v-if="order.orderStatus == '05'">
              <a @click="handleSign(order, 'contract')" v-if="approveStatus === '3'">电子签章</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>

              <!-- 解除与终止合同 -->
              <el-dropdown v-if="approveStatus === '3'">
                <a class="el-dropdown-link">
                  更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                </a>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>
                    <a @click="handleOrderRescind('1', true)">合同解除</a>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </p>

            <!-- 补充合同 -->
            <p v-if="order.orderStatus === 'addProduct'">
              <a v-if="
                  subOrderObj.subOrderNo &&
                  ['01', '04', '06'].includes(subOrderObj.subOrderStatus)
                " @click="handleSupplementOrder('1', subOrderObj)">编辑补充合同</a>
              <a v-if="
                  subOrderObj.subOrderNo && subOrderObj.subOrderStatus === '01'
                " @click="handleDel('2', order, subOrderObj.subOrderNo)">删除补充合同</a>
              <a v-if="
                  subOrderObj.subOrderNo &&
                  ['04', '06'].includes(subOrderObj.subOrderStatus)
                " @click="handleDel('4', order, subOrderObj.subOrderNo)">关闭补充合同</a>
              <a v-if="subOrderObj.subOrderStatus === '05' && isSignature" @click="handleSign(order, 'contract')">电子签章补充合同</a>
              <a v-if="
                  !(
                    subOrderObj.subOrderNo &&
                    ['01', '04', '06'].includes(subOrderObj.subOrderStatus)
                  )
                " @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>

              <el-dropdown v-if="
                  subOrderObj.subOrderNo &&
                  ['01', '04', '06'].includes(subOrderObj.subOrderStatus)
                ">
                <a class="el-dropdown-link">
                  更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                </a>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>
                    <a @click="handleDownloadContract(order)">下载合同</a>
                  </el-dropdown-item>
                  <el-dropdown-item>
                    <a @click="handleClickAettleAccounts(order)">合同结算</a>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </p>
            <p v-if="order.orderStatus == '11' && approveStatus === '3'">
              <a v-if="isNotSettle(order)" @click="handleOrderRescind('1', false)">终止合同</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <p v-if="order.orderStatus === 'contractTerminating'">
              <!-- 终止合同协议电子签章 -->
              <a v-if="approveStatusTermination === '3'" @click="handleSign(order, 'relieve')">电子签章</a>

              <template v-if="['15', '16'].includes(order.terminatingStatus)">
                <a @click="
                    handleOrderRescind(
                      '1',
                      order.terminateType == 'relieve' ? true : false
                    )
                  ">继续{{
                  order.terminateType == "relieve" ? "解除合同" : "终止合同"
                  }}</a>
                <a @click="withdrawContract('1')">{{
                  order.terminateType == "relieve"
                  ? "关闭解除合同"
                  : "关闭终止合同"
                  }}</a>
              </template>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>

            <!-- 结算单 -->
            <el-dropdown v-if="['4', '9'].includes(order.settleStatus) && order.settleType == '0' && isSettleLaunchCp(order)">
              <a class="el-dropdown-link">
                更多功能<i class="el-icon-arrow-down el-icon--right"></i>
              </a>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item>
                  <!-- 合同结算 - 解除 -->
                  <!-- <a @click="handleClickAettleAccountsRelieve(order)">解除结算单</a> -->
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
            <!-- 结算单 -->
          </template>
          <!--进行中-->
          <template v-if="tab == 2">
            <!--经销商 -已退回解除结算单 -->
            <template v-if="['3', '8'].includes(order.settleStatus) && order.settleType == '1'">
              <!-- <a @click="handleClickAettleAccountsRelieve(order)">解除结算单</a> -->
              <a @click="handleClickSettlementCloseAndDel('1', order)">关闭解除结算单</a>
            </template>

            <!-- 合同结算 - 解除 -->
            <!-- <template v-if="['1'].includes(order.settleStatus) && order.settleType == '1'">
              <a @click="handleClickConfirmEndSettment(order, '1')">撤回解除结算单</a>
            </template> -->

            <!-- 合同结算 - 经销商 -->
            <template v-if="['0', '3', '8'].includes(order.settleStatus) && order.settleType == '0' && isSettleLaunchCp(order)">
              <a @click="handleClickSettlementEdit(order)">编辑合同结算</a>
              <a v-if="order.settleStatus == '0'" @click="handleClickSettlementCloseAndDel('0', order)">删除合同结算</a>
              <a v-if="['3', '8'].includes(order.settleStatus)" @click="handleClickSettlementCloseAndDel('1', order)">关闭合同结算</a>
            </template>

            <template v-if="['1'].includes(order.settleStatus) && order.settleType == '0'">
              <a @click="handleClickWthdrawSettment(order)">撤回结算申请</a>
            </template>

            <!-- 电子签章结算单 -->
            <p v-if="order.settleStatus === '4' && order.settleType === '0' && eventListSearchAcctIdCp">
              <a @click="handleSign(order, 'settle')">电子签章</a>
            </p>

            <p v-if="order.orderStatus == '03'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <p v-if="order.orderStatus == '07'">
              <a @click="handleDel('3', order)">撤回合同</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>

            <!-- 补充合同 -->
            <p v-if="order.orderStatus == '11'">
              <a v-if="isNotSettle(order) && (
                  !subOrderObj.subOrderNo ||
                  (subOrderObj.subOrderNo &&
                    ['02', '11'].includes(subOrderObj.subOrderStatus)))
                " @click="handleSupplementOrder('', subOrderObj)">发起补充合同</a>
            </p>

            <!-- 解除与终止合同 -->
            <p v-if="
                approveStatus === '3' &&
                ['05', '11'].includes(order.orderStatus)
              ">
              <a v-if="order.orderStatus == '05'" @click="handleOrderRescind('1', true)">合同解除</a>
              <a v-if="isNotSettle(order) && order.orderStatus == '11'" @click="handleOrderRescind('1', false)">终止合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
              <el-dropdown v-if="
                  order.orderStatus == '11' &&
                  (!subOrderObj.subOrderNo ||
                    (subOrderObj.subOrderNo &&
                      ['02', '11'].includes(subOrderObj.subOrderStatus)))
                ">
                <a class="el-dropdown-link">
                  更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                </a>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item v-if="['4', '9'].includes(order.settleStatus) && order.settleType == '0'">
                    <!-- 合同结算 - 解除 -->
                    <!-- <a @click="handleClickAettleAccountsRelieve(order)">解除结算单</a> -->
                  </el-dropdown-item>
                  <el-dropdown-item>
                    <a @click="handleDownloadContract(order)">下载合同</a>
                  </el-dropdown-item>
                  <!-- order.settleStatus == '6' && order.settleType == '0' 供应商关闭 || order.settleStatus == '4' && order.settleType == '1' 解除完成-->
                  <el-dropdown-item v-if="!order.settleStatus || (order.settleStatus == '6' && order.settleType == '0') || (order.settleStatus == '4' && order.settleType == '1')">
                    <a @click="handleClickAettleAccounts(order)">合同结算</a>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
              <a v-else @click="handleDownloadContract(order)">下载合同</a>
            </p>
            <p v-else-if="order.orderStatus === '05'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>

            <!-- 解除与终止合同 -->
            <p v-if="order.orderStatus === 'contractTerminating'">
              <a @click="withdrawContract('0')" v-if="order.terminatingStatus === '08'">{{
                order.terminateType == "relieve"
                ? "撤回解除合同"
                : "撤回终止合同"
                }}</a>
              <template v-if="['15', '16'].includes(order.terminatingStatus)">
                <a @click="
                    handleOrderRescind(
                      '1',
                      order.terminateType == 'relieve' ? true : false
                    )
                  ">继续{{
                  order.terminateType == "relieve" ? "解除合同" : "终止合同"
                  }}</a>
                <a @click="withdrawContract('1')">{{
                  order.terminateType == "relieve"
                  ? "关闭解除合同"
                  : "关闭终止合同"
                  }}</a>
              </template>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>

            <!-- 补充合同 -->
            <p v-if="order.orderStatus === 'addProduct'">
              <a v-if="subOrderObj.subOrderStatus === '07'" @click="handleDel('3', order, subOrderObj.subOrderNo)">撤回补充合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
              <el-dropdown>
                <a class="el-dropdown-link">
                  更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                </a>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item v-if="!order.settleStatus || (order.settleStatus == '6' && order.settleType == '0') || (order.settleStatus == '4' && order.settleType == '1')">
                    <a @click="handleClickAettleAccounts(order)">合同结算</a>
                  </el-dropdown-item>

                  <el-dropdown-item v-if="['4', '9'].includes(order.settleStatus)">
                    <!-- 合同结算 - 解除 -->
                    <!-- <a @click="handleClickAettleAccountsRelieve(order)">解除结算单</a> -->
                  </el-dropdown-item>

                </el-dropdown-menu>
              </el-dropdown>
            </p>
          </template>
          <!--已关闭-->
          <template v-if="tab == 3">
            <p v-if="order.orderStatus == '12'">

              <!-- <a v-if="(order.settleStatus === '10' && order.settleType === '0') || (['3', '8'].includes(order.settleStatus) && order.settleType === '2') && order.supplierId == this.mxCorpId" @click="handleOrderRescind('1', false, 'settle')">终止结算单</a> -->
              <a v-if="order.settleStatus === '1' && order.settleType === '2' && order.supplierId == this.mxCorpId" @click="handleClickWthdrawSettment(order, '2')">撤回终止结算单</a>

              <a @click="handleDownloadContract(order)">下载合同</a>
            </p>
            <p v-if="order.orderStatus == 'contractTerminated' || ['10'].includes(order.settleStatus)">
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
        </template>
      </template>
      <!--采购商-->
      <template v-else>
        <!-- 博置 或 全是事业部账户 不让进-->
        <!-- isAllDivision -->
        <template v-if="!brokerRole">
          <!-- 待处理· -->
          <template v-if="tab == 1">
            <!-- 结算大 bg -->
            <!-- 电子签章结算单 Bg -->
            <p v-if="order.settleStatus === '4' && order.settleType === '0' && eventListSearchAcctIdCp">
              <a @click="handleSign(order, 'settle')">电子签章</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
              <!-- BUG #12949 【高】【双向合同】 法务角色的签章列表，缺少「查看合同详情」请加上 -->
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <!-- 电子签章结算单 Ed -->


            <p v-if="order.orderStatus == '03'">
              <a @click="handleOrderDetail(order, 0, false)">审核合同</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
            </p>
            <p v-if="order.orderStatus == '05'">
              <a @click="handleSign(order, 'contract')" v-if="approveStatus === '3'">电子签章</a>
              <a @click="handleOrderDetail(order, 0, false)" v-if="approveStatus === '4' || approveStatus === '2'">重新提交审核</a>
              <a @click="handleReject()" v-if="approveStatus === '4' || approveStatus === '2'">拒绝合同</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>


            <!-- 采购商审核结算 -->
            <template v-if="['5', '7'].includes(order.settleStatus) && order.settleType == '0'">
              <a v-if="['7'].includes(order.settleStatus)" @click="handleClickExamineSettment(order)">审核结算</a>
              <a v-if="!['5'].includes(order.settleStatus)"  @click="handleDownloadContract(order)">下载合同</a>
              <template v-if="['5'].includes(order.settleStatus)">
                <a @click="handleClickExamineSettment(order)">提交结算审核</a>
                <a @click="handleOrderRescind('3', false, 'settle')">结算退回</a>
              </template>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </template>
            <!-- 采购商-发起OA解除结算单审批/退回解除结算单 -->
            <template v-if="
                ['2', '5', '7'].includes(order.settleStatus) &&
                order.settleType == '1'
              ">
              <a :class="{ disabled: ['2'].includes(order.settleStatus) }" @click="
                  ['5', '7'].includes(order.settleStatus) &&
                    handleOrderRescind('2', true, 'settle')
                ">发起OA解除结算单审批</a>
              <a v-if="['5', '7'].includes(order.settleStatus)" @click="handleOrderRescind('3', true, 'settle')">退回解除结算单</a>
            </template>

            <!-- 结算单 ed -->

            <!-- 补充合同 -->
            <p v-if="order.orderStatus == 'addProduct'">
              <a v-if="
                  subOrderObj.subOrderStatus === '03' ||
                  (subOrderObj.subOrderStatus === '05' &&
                    ['2', '4'].includes(subApproveStatus))
                " @click="handleOrderDetail(order, 2, false)">审核补充合同</a>
              <a v-if="subOrderObj.subOrderStatus === '05' && isSignature" @click="handleSign(order, 'contract')">电子签章补充合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>

            <!-- 终止合同协议电子签章 -->
            <p v-if="
                order.orderStatus === 'contractTerminating' &&
                approveStatusTermination === '3'
              ">
              <a @click="handleSign(order, 'relieve')">电子签章</a>
            </p>
            <!-- 解除与终止合同 -->
            <p v-if="
                order.orderStatus === 'contractTerminating' &&
                order.terminatingStatus === '09'
              ">
              <a v-if="
                  order.terminateType == 'relieve' &&
                  (!approveStatusTermination ||
                    ['2', '4'].includes(approveStatusTermination))
                " @click="handleOrderRescind('2', true)">发起OA解除合同审批</a>
              <a v-if="
                  order.terminateType == 'relieve' &&
                  (!approveStatusTermination ||
                    ['2', '4'].includes(approveStatusTermination))
                " @click="handleOrderRescind('3', true)">退回解除合同</a>
              <template v-if="order.terminateType == 'terminate'">
                <template v-if="
                    approveStatusTermination !== '3' &&
                    (!approveStatusTermination ||
                      ['2', '4'].includes(approveStatusTermination))
                  ">
                  <a @click="handleOrderRescind('2', false)">发起OA终止合同审批</a>
                  <a @click="handleOrderRescind('3', false)">退回终止合同</a>
                </template>
              </template>
              <span class="grey" v-if="['0', '1', '5'].includes(approveStatusTermination)">已发起OA{{
                order.terminateType == "relieve" ? "解除" : "终止"
                }}合同审批</span>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
          <!--进行中-->
          <template v-if="tab == 2">
            <!-- 采购商审核结算 -->
            <template v-if="
                ['5', '7'].includes(order.settleStatus) && order.settleType == '0'
              ">
              <a v-if="['7'].includes(order.settleStatus)" @click="handleClickExamineSettment(order)">审核结算</a>
              <template v-if="['5'].includes(order.settleStatus)">
                <a @click="handleClickExamineSettment(order)">提交结算审核</a>
                <a @click="handleOrderRescind('3', false, 'settle')">结算退回</a>
              </template>
            </template>
            <!-- 采购商-发起OA解除结算单审批/退回解除结算单 -->
            <template v-if="['2', '5', '7'].includes(order.settleStatus) && order.settleType == '1'">
              <a :class="{ disabled: ['2'].includes(order.settleStatus) }" @click="
                  ['5', '7'].includes(order.settleStatus) &&
                    handleOrderRescind('2', true, 'settle')
                ">发起OA解除结算单审批</a>
              <a v-if="['5', '7'].includes(order.settleStatus)" @click="handleOrderRescind('3', true, 'settle')">退回解除结算单</a>
            </template>

            <!-- 电子签章结算单 -->
            <p v-if="order.settleStatus === '4' && order.settleType === '0' && eventListSearchAcctIdCp">
              <a @click="handleSign(order, 'settle')">电子签章</a>
            </p>

            <!-- 解除与终止合同 -->
            <p v-if="order.orderStatus === 'contractTerminating' && order.terminatingStatus === '09'">
              <span class="grey" v-if="['0', '1', '5'].includes(approveStatusTermination)">已发起OA{{
                order.terminateType == "relieve" ? "解除" : "终止"
                }}合同审批</span>
            </p>

            <p v-if="order.orderStatus !== '01'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a v-if="order.orderStatus != '02'" @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <!-- 解除与终止合同 -->
            <!-- <p v-if="order.orderStatus === 'contractTerminating' && order.terminatingStatus === '09'">
              <a v-if="order.terminateType == 'relieve' && (!approveStatusTermination || ['2', '4'].includes(approveStatusTermination))" @click="handleOrderRescind('2',true)">发起OA解除合同审批</a>
              <a v-if="order.terminateType == 'relieve' && (!approveStatusTermination || ['2', '4'].includes(approveStatusTermination))" @click="handleOrderRescind('3',true)">退回解除合同</a>

              <template v-if="order.terminateType == 'terminate'">
                <template v-if="approveStatusTermination !== '3' && (!approveStatusTermination || ['2', '4'].includes(approveStatusTermination))">
                  <a @click="handleOrderRescind('2',false)">发起OA终止合同审批</a>
                  <a @click="handleOrderRescind('3',false)">退回终止合同</a>
                </template>
              </template>
              <span class="grey" v-if="['0','1'].includes(approveStatusTermination)">已发起OA{{order.terminateType == 'relieve' ? '解除' : '终止'}}合同审批</span>
            </p> -->
          </template>
          <!--已关闭-->
          <template v-if="tab == 3">
            <!-- 发起OA解除结算单审批 -->
            <p v-if="order.settleType === '2'">
              <a :class="{ disabled: ['2'].includes(order.settleStatus) }" @click="['7'].includes(order.settleStatus) && handleOrderRescind('2', false, 'settle')">发起OA终止结算单审批</a>
              <a v-if="order.settleStatus === '7'" @click="handleOrderRescind('3', true, 'settle')">退回终止结算单</a>
            </p>

            <p v-if="order.orderStatus == '12'">
              <a @click="handleDownloadContract(order)">下载合同</a>
            </p>
            <p v-if="order.orderStatus == 'contractTerminated' || ['10'].includes(order.settleStatus)">
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
        </template>
        <!-- 材料公司 -->
        <template v-else>
          <!-- 待处理· -->
          <template v-if="tab == 1">
            <!-- 电子签章结算单 Bg -->
            <p v-if="['2', '4'].includes(order.settleStatus) && order.settleType === '0' && eventListSearchAcctIdCp">
              <a v-if="order.settleStatus === '4'" @click="handleSign(order, 'settle')">电子签章</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <!-- 电子签章结算单 Ed -->

            <p v-if="
                order.orderStatus == '05' &&
                order.orderStatus !== 'contractTerminating'
              ">
              <a @click="handleSign(order, 'contract')" v-if="approveStatus === '3'">电子签章</a>

              <a @click="handleDownloadContract(order)">下载合同</a>
              <!-- BUG #12949 【高】【双向合同】 法务角色的签章列表，缺少「查看合同详情」请加上 -->
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>

            <!-- 补充合同 -->
            <p v-if="order.orderStatus == 'addProduct'">
              <a v-if="subOrderObj.subOrderStatus === '05' && isSignature" @click="handleSign(order, 'contract')">电子签章补充合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>

            <!-- 终止合同协议电子签章 -->
            <p v-if="
                order.orderStatus === 'contractTerminating' &&
                approveStatusTermination === '3'
              ">
              <a @click="handleSign(order, 'relieve')">电子签章</a>
            </p>
          </template>
          <!--进行中-->
          <template v-if="tab == 2">
            <!-- 电子签章结算单 -->
            <p v-if="order.settleStatus === '4' && order.settleType === '0' && eventListSearchAcctIdCp">
              <a @click="handleSign(order, 'settle')">电子签章</a>
            </p>

            <p v-if="order.orderStatus !== '01'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a v-if="order.orderStatus != '02'" @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
          <template v-if="tab == 3">
            <p v-if="['10'].includes(order.settleStatus)">
              <a @click="handleDownloadContract(order)">下载合同</a>
            </p>
            <p v-if="order.orderStatus == 'contractTerminated' || ['10'].includes(order.settleStatus)">
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
        </template>
        <p v-if="order.orderStatus == '01'">
          <a style="color: #444; cursor: default">-</a>
        </p>
      </template>
    </template>
    <!-- 单向合同 -->
    <template v-else>
      <!--供应商-->
      <template v-if="userInfo.bs == 'S'">
        <!--厂家-->
        <template v-if="userInfo.supplyType == '0'">
          <!--待处理-->
          <template v-if="tab == 1">
            <p v-if="order.orderStatus == '01'">
              <a @click="handleDraftOfCreateOrder(order)">编辑合同</a>
              <a @click="handleDel('2', order)">删除合同</a>
            </p>
            <p v-if="order.orderStatus == '05'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <p v-if="order.orderStatus == '07'">
              <a @click="handleOrderDetail(order)">审核合同</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
            </p>
            <p v-if="order.orderStatus == '06'">
              <a @click="handleDraftOfCreateOrder(order)">编辑合同</a>
              <a @click="handleDel('4', order)">关闭合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
              <el-dropdown>
                <a class="el-dropdown-link">
                  更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                </a>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>
                    <a @click="handleDownloadContract(order)">下载合同</a>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </p>
          </template>
          <!--进行中-->
          <template v-if="tab == 2">
            <p v-if="order.orderStatus == '01'">
              <a style="color: #444; cursor: default">-</a>
            </p>
            <p v-if="
                order.orderStatus == '03' ||
                order.orderStatus == '04' ||
                order.orderStatus == '05' ||
                order.orderStatus == '06' ||
                order.orderStatus == '11'
              ">
              <a v-if="
                  order.orderStatus == '03' &&
                  order.supplierId === userInfo.corpId
                " @click="handleDel('3', order)">撤回合同</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
          <!--已关闭-->
          <template v-if="tab == 3">
            <!-- <p v-if="order.orderStatus == '12'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <p v-if="order.orderStatus == '05'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p> -->
            <p v-if="order.orderStatus != '02'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
        </template>
        <!--代理商-->
        <template v-else>
          <!--待处理-->
          <template v-if="tab == 1">
            <p v-if="order.orderStatus == '01'">
              <a @click="handleDraftOfCreateOrder(order)">编辑合同</a>
              <a @click="handleDel('2', order)">删除合同</a>
            </p>
            <p v-if="order.orderStatus == '05'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <p v-if="order.orderStatus == '04' || order.orderStatus == '06'">
              <a @click="handleDraftOfCreateOrder(order)">编辑合同</a>
              <a @click="handleDel('4', order)">关闭合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
              <el-dropdown>
                <a class="el-dropdown-link">
                  更多功能<i class="el-icon-arrow-down el-icon--right"></i>
                </a>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>
                    <a @click="handleDownloadContract(order)">下载合同</a>
                  </el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </p>
          </template>
          <!--进行中-->
          <template v-if="tab == 2">
            <p v-if="order.orderStatus == '03'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <p v-if="order.orderStatus == '07'">
              <a @click="handleDel('3', order)">撤回合同</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <p v-if="order.orderStatus == '05'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <p v-if="order.orderStatus == '11'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
          <!--已关闭-->
          <template v-if="tab == 3">
            <!-- <p v-if="order.orderStatus == '12'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
            <p v-if="order.orderStatus == '05'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p> -->
            <p v-if="order.orderStatus != '02'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
        </template>
      </template>
      <!--采购商-->
      <template v-else>
        <!-- 博置 或 全是事业部账户 不让进-->
        <!-- isAllDivision -->
        <template v-if="!brokerRole">
          <!-- 待处理· -->
          <template v-if="tab == 1">
            <p v-if="order.orderStatus == '03'">
              <a @click="handleOrderDetail(order, 0, false)">审核合同</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
            </p>
            <p v-if="order.orderStatus == '05'">
              <a @click="handleOrderDetail(order, 0, false)" v-if="approveStatus === '4' || approveStatus === '2'">重新提交审核</a>
              <a @click="handleReject()" v-if="approveStatus === '4' || approveStatus === '2'">拒绝合同</a>
              <a @click="handleDownloadContract(order)">下载合同</a>
            </p>
          </template>
          <!--进行中-->
          <template v-if="tab == 2">
            <p v-if="order.orderStatus !== '01'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a v-if="order.orderStatus != '02'" @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
          <!--已关闭-->
          <template v-if="tab == 3">
            <!-- <p v-if="order.orderStatus == '12'">
              <a @click="handleDownloadContract(order)">下载合同</a>
            </p>
            <p v-if="order.orderStatus == '05'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p> -->
            <p v-if="order.orderStatus != '02'">
              <a @click="handleDownloadContract(order)">下载合同</a>
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
        </template>
        <!-- 材料公司 -->
        <template v-else>
          <!-- 待处理· -->
          <template v-if="tab == 1"> </template>
          <!--进行中-->
          <template v-if="tab == 2">
            <p v-if="order.orderStatus !== '01'">
              <!-- <a @click="handleDownloadContract(order)">下载合同</a> -->
              <a v-if="order.orderStatus != '02'" @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
          <template v-if="tab == 3">
            <!-- <p v-if="order.orderStatus == '05'">
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p> -->
            <p v-if="order.orderStatus != '02'">
              <!-- <a @click="handleDownloadContract(order)">下载合同</a> -->
              <a @click="handleOrderDetail(order)">查看合同详情</a>
            </p>
          </template>
        </template>
        <p v-if="order.orderStatus == '01'">
          <a style="color: #444; cursor: default">-</a>
        </p>
      </template>
    </template>
    <p v-if="order.orderStatus == '02' && isShow">
      <!-- <a @click="handleDownloadContract(order)">下载合同</a> -->
      <a @click="handleOrderDetail(order)">查看合同详情</a>
    </p>
    <!-- 确认合同 -->
    <OrderConfirm ref="orderConfirm" @close="handleCloseOrderConfirm"></OrderConfirm>
    <!-- 拒绝合同 -->
    <RejectOrder ref="rejectOrder" @close="handleCloseRejectOrder"></RejectOrder>
    <!-- 取消合同 -->
    <CancelOrder ref="cancelOrder" @close="handleCloseCancelOrder"></CancelOrder>

    <!-- 取消合同 -->
    <RelieveOrder ref="relieveOrder" @close="handleCloseRelieveOrder"></RelieveOrder>
    <!--供应商确认解除合同-->
    <ConfirmRelieveOrder ref="confirmRelieveOrder" @close="handleCloseRelieveOrder"></ConfirmRelieveOrder>

    <!-- 合同解除 -->
    <OrderRescind ref="orderRescind" @close="handleCloseOrderRescind"></OrderRescind>

    <!-- 确认解除合同结算单 -->
    <OrderSettleRelieveDialog ref="orderSettleRelieveDialog" @close="handleCloseOrderRescind"></OrderSettleRelieveDialog>

    <!-- 合同结算 -->
    <el-dialog class="aettle-accounts-dialog" title="未满足合同结算发起条件" :append-to-body="true" :lock-scroll="true" :visible.sync="aettleAccountsDialog" width="850px" center :close-on-click-modal="false">
      <div class="f12">
        <!-- 结算金额为0 -->
        <p class="txt-center" v-if="
            initStateMentCondition &&
            initStateMentCondition.queryResultType == '2'
          ">
          合同没有结算数据，请先去要货！
        </p>
        <template v-else>
          <div class="table-container txt-center">
            <p class="txt-left mb10">
              本合同有未完成的流程或账单，全部完成后可发起合同结算，未完成的流程或账单如下：
            </p>
            <table width="811">
              <thead>
                <tr>
                  <th width="100px">序号</th>
                  <th width="520px">编号</th>
                  <th>类型</th>
                </tr>
              </thead>
            </table>
            <div class="data-center">
              <table width="811">
                <tbody>
                  <tr v-for="(item, idx) in (initStateMentCondition &&
                      initStateMentCondition.billDetails) ||
                    []" :key="idx">
                    <td width="100px">{{ idx + 1 }}</td>
                    <td width="520px" class="blue">
                      <span class="hand" @click="handleClickGotoBill(item)">
                        {{ item.billNo }}
                      </span>
                      <template v-if="item.billType == '要货单'">&nbsp;
                        <span class="red" v-if="item.billStatus == '1'">要货单被撤回或退回，请联系采购商重新发起或关闭该要货单！</span>
                        <template v-else>
                          <span class="red">货物未验收，请先去验收！</span>
                          <span class="hand" @click="handleClickGotoBill(item)">去验收></span>
                        </template>
                      </template>
                      <template v-if="item.billType == '验收单'">&nbsp;
                        <template v-if="item.billStatus == '3'">
                          <span class="red">未发起对账单申请，请先去发起对账单申报！</span>
                          <span class="hand" @click="handleClickGotoStatementDeclaredList(item)">去申报></span>
                        </template>
                        <template v-else>
                          <span class="red">货物未验收，请先去验收！</span>
                          <span class="hand" @click="handleClickGotoBill(item)">去验收></span>
                        </template>
                      </template>
                    </td>
                    <td>{{ item.billType }}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div class="table-pagination" v-if="
              initStateMentCondition &&
              initStateMentCondition.billDetails &&
              initStateMentCondition.billDetails.length
            ">
            <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
            </el-pagination>
          </div>
        </template>
      </div>

      <div class="sign-result txt-center">
        <el-button class="normal-btn" @click="aettleAccountsDialog = false" style="width: 120px">关闭</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import OrderConfirm from "@/components/order/dialog/orderOperate/OrderConfirm";
import RejectOrder from "@/components/order/dialog/orderOperate/RejectOrder";
import CancelOrder from "@/components/order/dialog/orderOperate/CancelOrder";
import RelieveOrder from "@/components/order/dialog/orderOperate/RelieveOrder";
import ConfirmRelieveOrder from "@/components/order/dialog/orderOperate/ConfirmRelieveOrder";
import OrderRescind from "@/components/order/dialog/orderOperate/OrderRescind";
import { filterEventByAcct } from "@/utils/orderUtil";
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";

import OrderSettleRelieveDialog from "@/components/order/dialog/orderOperate/OrderSettleRelieveDialog";

export default {
  mixins: [accountMixin],
  components: {
    OrderConfirm,
    RejectOrder,
    CancelOrder,
    RelieveOrder,
    ConfirmRelieveOrder,
    OrderRescind,
    Loading,

    OrderSettleRelieveDialog,
  },
  props: ["order", "tab"],
  data() {
    return {
      attach: {},
      rejectionListReasons: "", // 拒绝清单 理由
      selectedList: [],
      isLoading: false,
      refuseDialogOptions: [], // 取消原因

      aettleAccountsDialog: false, // 合同结算
      pageIndex: 1,
      pageSize: 10,
      total: 1,
      initStateMentCondition: {}, // 结算单初始化

      aettleAccountsTerminationDialog: false, // 发起终止结算单 弹窗

      isShow: false,
    };
  },
  computed: {
    // 是否结算合同创建人 返回 是
    isSettleLaunchCp() {
      return order => order.supplierId == this.mxCorpId
    },
    // 没有发起结算单 或者 已关闭结算单, 返回 未发起/关闭 true
    isNotSettle() {
      // 无 settleType = 未发起,  0, 6 为关闭  || 1, 4 解除完成
      return order => (!order.settleType) || (order.settleType == '0' && order.settleStatus == '6') || (order.settleStatus == '4' && order.settleType == '1')
    },
    // 结算合同 - 判断电子签章是否显示
    eventListSearchAcctIdCp() {
      let result = false
      this.order && this.order.eventList && this.order.eventList.forEach(ev => {
        if (["settle_supplier_File", "settle_purchaser_File"].includes(ev.documentType)) {
          ev.processList.forEach(process => {
            if (process.processFlg == 0) {
              // 如果是供应商 只用当前登录 的acctId 判断, 采购商则用多账户判断
              if (this.role == 'S' ? this.acctId == process.acctId : this.mxAcctIdList.includes(process.acctId))
                result = true
            }
          })
        }
      })
      return result
    },
    subOrderObj() {
      let obj = {};
      if (this.order.subOrderList && this.order.subOrderList.length) {
        obj = this.order.subOrderList[0];
      }
      return obj;
    },
    subApproveStatus() {
      let status = "";
      let oaApprovalInfo =
        (this.subOrderObj.externalSysList &&
          this.subOrderObj.externalSysList.find((i) => {
            return i.sysCode === "OA";
          })) ||
        {};
      status = oaApprovalInfo.approveStatus;
      console.log(status);
      return status;
    },
    isSignature() {
      let result = false;
      if (this.subOrderObj.eventList) {
        let obj =
          this.subOrderObj.eventList.find((i) => i.bs === this.role) || {};
        if (obj.eventStatus !== "2" && obj.processList) {
          result = obj.processList.some(
            (i) =>
              this.userInfo.acctIdList.includes(i.acctId) && i.processFlg == "0"
          );
        }
      }
      return result;
    },
    isSupplierWithdraw() {
      let result = false;
      let list =
        this.order.externalSysList &&
        this.order.externalSysList.filter((i) => {
          return i.operType === "TERMINATED";
        });
      if (
        this.order.supplierId === this.userInfo.corpId &&
        this.order.orderStatus === "contractTerminating" &&
        this.order.terminatingStatus === "09" &&
        !list.length
      ) {
        result = true;
      }
      console.log(result);
      return result;
    },
    // 多账户 是否 全部为 事业部 返回: 全部为事业部 返回 true
    isAllDivision() {
      const corpRoleList = this.userInfo.corpRoleList || [];
      return corpRoleList.some((e) => e.contractCorpType == "division");
    },
    approveStatus() {
      let status = "";
      let oaApprovalInfo =
        (this.order.externalSysList &&
          this.order.externalSysList.find((i) => {
            return i.sysCode === "OA";
          })) ||
        {};
      status = oaApprovalInfo.approveStatus;
      console.log(status);
      return status;
    },
    approveStatusTermination() {
      let status = "";
      let oaApprovalInfo =
        (this.order.externalSysList &&
          this.order.externalSysList.find((i) => {
            return i.operType === "TERMINATED";
          })) ||
        {};
      status = oaApprovalInfo.approveStatus || "";
      console.log(status);
      return status;
    },
    unconfirmedOrderNosComputed() {
      return (subOrderList) => {
        return subOrderList.filter((f) => f.subOrderStatus == "01") || [];
      };
    },
    cancelSupplementList() {
      return (data) => {
        let item = [];
        data &&
          data.subOrderList &&
          data.subOrderList.map((m) => {
            if (m.subOrderStatus == "01") {
              const count =
                Number(
                  m.subOrderNo &&
                  m.subOrderNo.split("-") &&
                  m.subOrderNo.split("-")[1]
                ) || 1;
              item.push(Object.assign(m, { orderCount: count }));
            }
          });
        return item;
      };
    },
    userInfo() {
      return this.$store.state.userInfo || {};
    },
  },
  methods: {
    init() {
      this.refuseDialogOptions = [
        "不想要了",
        "订单下多了",
        "订单重复了",
        "其他",
      ];
    },
    handleClickGotoStatementDeclaredList() {
      window.open(
        this.$router.resolve({
          path: "/vendorCenter/statementDeclaredList",
        }).href,
        "_blank"
      );
    },
    handleClickGotoBill(item) {
      if (item.billType == "发货单") {
        window.open(
          this.$router.resolve({
            path: "/requireOrderDetail",
            query: {
              requireNo: item.selectBillNo || item.billNo || "",
            },
          }).href,
          "_blank"
        );
      }

      if (item.billType == "验收单") {
        window.open(
          this.$router.resolve({
            path: "/requireOrderDetail",
            query: {
              requireNo: item.selectBillNo || item.billNo || "",
            },
          }).href,
          "_blank"
        );
      }

      if (item.billType == "对账单") {
        window.open(
          this.$router.resolve({
            path: "/statementDeclaredDetai",
            query: {
              orderNo: this.order.orderNo,
              statementNo: item.selectBillNo || item.billNo || '',
            },
          }).href,
          "_blank"
        );
      }

      if (item.billType == "未发起对账单") {
        window.open(
          this.$router.resolve({
            path: "/vendorCenter/statementDeclaredList",
          }).href,
          "_blank"
        );
      }

      if (item.billType == "未发起预付款单") {
        window.open(
          this.$router.resolve({
            path: "/vendorCenter/advancePaymentRequestList",
          }).href,
          "_blank"
        );
      }

      if (item.billType.includes("预付款")) {
        window.open(
          this.$router.resolve({
            path: "/advancePaymentRequesDetail",
            query: {
              orderNo: this.order.orderNo,
              statementNo: item.selectBillNo || item.billNo || '',
            },
          }).href,
          "_blank"
        );
      }

      if (item.billType.includes("补充合同")) {
        window.open(
          this.$router.resolve({
            path: "/orderDetail",
            query: {
              orderNo: this.order.orderNo,
              draftId: this.order.draftId, // 是否为中间商判断条件
              busiType: this.order.busiType, //
              statementNo: item.selectBillNo || item.billNo || '',
            },
          }).href,
          "_blank"
        );
      }
    },
    queryStateMentCondition() {
      return new Promise((resolve) => {
        let params = {
          orderNo: this.order.orderNo,
          pageIndex: this.pageIndex,
        };
        InterfaceService.queryStateMentCondition(
          params,
          (data) => {
            let res = (data && data.respData) || {};
            if (res.respCode === "0000") {
              this.initStateMentCondition = res;
              resolve(true);
            } else {
              this.$message.error(res.respMsg);
              resolve(false);
            }
          },
          (data) => {
            this.$message.error(data.respMsg);
          },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      });
    },
    handleClickSettlementEdit(order) {
      this.$router.push({
        path: "/settlementApplyNextStep",
        query: {
          orderNo: order.orderNo,
          settleNo: order.settleNo,
        },
      })
    },

    /**
     * 审核结算单
     */
    handleClickExamineSettment(order) {
      this.$router.push({
        path: "/orderDetail",
        query: {
          orderNo: this.order.orderNo,
          draftId: this.order.draftId, // 是否为中间商判断条件
          busiType: this.order.busiType, //
          tabIndex: "3", //
          settleNo: order.settleNo,
          settleStatus: order.settleStatus,
          settleType: order.settleType,
        },
      })
    },

    /**
     * 删除/关闭结算单
     */
    handleClickSettlementCloseAndDel(type, order) {
      this.$confirm(
        `确认${type === "0" ? "删除" : "关闭"}结算申请吗？`,
        "操作提示",
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          confirmButtonText: "确认",
          cancelButtonText: "取消",
        }
      )
        .then(async () => {
          this.delCloseStatementSingle(type, order.settleNo);
        })
        .catch(() => { });
    },

    handleClickConfirmEndSettment(order, type) {
      this.$confirm(
        `确认撤回解除结算单吗？`,
        "操作提示",
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          confirmButtonText: "确认",
          cancelButtonText: "取消",
        }
      ).then(async () => {
        this.settleNo = order.settleNo;
        this.submitSettlementInfo(type);
      }).catch(() => { });
    },

    handleClickRetureEndSettment(order) {
      this.$confirm(
        `确认退回结算申请吗？`,
        "操作提示",
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          confirmButtonText: "确认",
          cancelButtonText: "取消",
        }
      ).then(async () => {
        this.settleNo = order.settleNo;
        this.submitSettlementInfo(type);
      }).catch(() => { });
    },

    /**
     * 撤回合同结算
     * @param type: 0-合同结算, 2终止结算单
     */
    handleClickWthdrawSettment(order, type = "0") {
      this.$confirm(
        `确认撤回${
        type == "2" ? "终止结算申请" : type == "0" ? "结算申请" : ""
        }吗？`,
        "操作提示",
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          confirmButtonText: "确认",
          cancelButtonText: "取消",
        }
      )
        .then(async () => {
          this.settleNo = order.settleNo;
          this.submitSettlementInfo(type);
        })
        .catch(() => { });
    },
    postWthdrawSettment() { },

    /**
     * 删除、关闭结算单
     */
    delCloseStatementSingle(handleType, settleNo) {
      return new Promise((resolve) => {
        let params = {
          settleNo, //	String	Y	结算单编号
          handleType, //	String	Y	操作类型（0-删除，1-关闭）
        };
        InterfaceService.delCloseStatementSingle(
          params,
          (data) => {
            let res = (data && data.respData) || {};
            if (res.respCode === "0000") {
              this.$message.success(`${handleType == '1' ? '关闭' : '删除'}成功！`)
              this.$emit("refresh", "closeOrderRescind");
            } else {
              this.$message.error(res.respMsg);
            }
            resolve(true);
          },
          (data) => {
            this.$message.error(data.respMsg);
          },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      });
    },

    /**
     * 解除结算单
     */
    handleClickAettleAccountsRelieve(order) {
      this.$refs["orderSettleRelieveDialog"].open(this.order);
    },

    /**
     * 撤回结算单
     */
    submitSettlementInfo(handleType) {
      return new Promise((resolve) => {
        let params = {
          settleNo: this.settleNo, //	String	Y	结算单编号
          handleType, //String	Y	操作类型（0-提交申请撤回，1-解除申请撤回，2-终止申请撤回）
        };
        InterfaceService.submitSettlementInfo(
          params,
          (data) => {
            let res = (data && data.respData) || {};
            if (res.respCode === "0000") {
              this.$message.success(
                `${
                handleType === "0"
                  ? "撤回"
                  : handleType === "1"
                    ? "撤回解除结算单"
                    : "撤回终止结算单"
                }成功!`
              );
              this.$emit("refresh", "closeOrderRescind");
            } else {
              this.$message.error(res.respMsg);
            }
            resolve(true);
          },
          (data) => {
            this.$message.error(data.respMsg);
          },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      });
    },

    /**
     * 发起终止结算单
     */
    handleClickAettleAccountsTermination(order) {
      this.aettleAccountsTerminationDialog = true;
    },

    /**
     * 合同结算
     */
    async handleClickAettleAccounts(order) {
      const result = await this.queryStateMentCondition();
      // queryResultType 查询返回类型（1-满足条件发起结算；2-未满足结算条件，并且无发货单；3-未满足条件，有发货单等账单信息，不过未全部审核通过
      if (result && this.initStateMentCondition.queryResultType === "0") {
        this.$router.push({
          path: "/settlementApply",
          query: {
            orderNo: order.orderNo,
            provisionalSettleNo: this.initStateMentCondition.settlementNo || ''
          },
        })
      } else if (result) {
        // 合同结算金额为0时，让用户先去要货
        this.aettleAccountsDialog = true;
      }
    },

    /**
     * 查询 结算状态
     */
    queryAettleAccounts() { },

    handleCurrentChange(page) {
      this.pageIndex = page;
    },

    handleSign(order, orderType) {
      let query = {
        orderNo: order.orderNo,
        orderType: orderType,
      };
      if (orderType === "contract") {
        query.subOrderNo = this.subOrderObj.subOrderNo || "";
      }
      if (orderType === "settle") {
        query.settleNo = order.settleNo || "";
      }
      if (this.brokerRole) {
        query.tab = this.tab;
        this.$router.push({
          path: "/brokerSignPreview",
          query,
        });
      } else {
        this.$router.push({
          path: "/contractSign",
          query,
        });
      }
    },
    handleDraftOfCreateOrder(order) {
      console.log(order.creator, order.creator !== this.userInfo.acctId);
      if (order.creator && order.creator !== this.userInfo.acctId) {
        this.$message.error("您不是该合同的创建人，无法编辑合同！");
      } else {
        if (order.saveStep !== "2") {
          this.$router.push({
            path: "/draftOfCreateOrder",
            query: {
              draftsId: order.draftId,
              orderNo: order.orderNo,
              busiType: order.busiType,
              edit: "1",
            },
          });
        } else {
          this.$router.push({
            path: "/confirmOrder",
            query: {
              draftsId: order.draftId,
              orderNo: order.orderNo,
            },
          });
        }
      }
    },
    // 补充合同
    handleSupplementOrder(edit = "", subOrderObj = {}) {
      if (this.order.creator && this.order.creator !== this.userInfo.acctId) {
        this.$message.error(
          `您不是该补充合同的创建人，无法${edit ? '编辑' : '发起'}补充合同！`
        );
        return false;
      }
      this.$router.push({
        path: "/draftOfCreateOrder",
        query: {
          orderNo: this.order.orderNo,
          supplementOrderNo: edit ? subOrderObj.subOrderNo : "",
          edit: edit,
          isSupplement: true,
          busiType: this.order.busiType,
          orderCnt: subOrderObj.orderCnt || "",
        },
      });
    },
    handleDel(operationType, order, subOrderNo = "") {
      if (order.creator && order.creator !== this.userInfo.acctId) {
        this.$message.error(
          `您不是该${subOrderNo ? "补充" : ""}合同的创建人，无法` +
          (operationType == "2"
            ? "删除"
            : operationType == "3"
              ? "撤回"
              : "关闭") +
          `${subOrderNo ? "补充" : ""}合同！`
        );
        return false;
      }
      let str = "";
      let title = "";
      let confirmBtn = "";
      if (operationType == "2") {
        str = `${subOrderNo ? "补充" : ""}合同删除后将无法恢复，确认要删除${
          subOrderNo ? "补充" : ""
          }合同吗？`;
        title = `删除${subOrderNo ? "补充" : ""}合同`;
        confirmBtn = `确认删除`;
      } else if (operationType == "4") {
        str = `${subOrderNo ? "补充" : ""}合同关闭后将无法恢复，确认要关闭${
          subOrderNo ? "补充" : ""
          }合同吗？`;
        title = `关闭${subOrderNo ? "补充" : ""}合同`;
        confirmBtn = "确认关闭";
      } else if (operationType == "3") {
        str = `确认要撤回${subOrderNo ? "补充" : ""}合同吗？`;
        title = `撤回${subOrderNo ? "补充" : ""}合同`;
        confirmBtn = "确认撤回";
      }
      this.$confirm(str, title, {
        cancelButtonClass: "btn-custom-cancel",
        confirmButtonClass: "btn-custom-confirm",
        center: true,
        dangerouslyUseHTMLString: true,
        confirmButtonText: confirmBtn,
        cancelButtonText: "取消",
      })
        .then(() => {
          let params = {
            orderNo: subOrderNo || this.order.orderNo,
            operationType: operationType,
          };
          InterfaceService.submitContract(
            params,
            (data) => {
              let res = data.respData || {};
              if (data && data.respData && res.respCode === "0000") {
                if (operationType == "2") {
                  this.$message.success("删除成功！");
                } else if (operationType == "4") {
                  this.$message.success("关闭成功！");
                } else if (operationType == "3") {
                  this.$message.success("撤回成功！");
                }
                if (operationType == "4" && subOrderNo) {
                  //补充合同关闭
                  operationType = "5";
                }
                this.$emit("refresh", operationType);
              } else {
                this.$message.error(data.respData.respMsg);
              }
            },
            (data) => {
              this.$message.error(data.respData.respMsg);
            },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            }
          );
        })
        .catch(() => { });
    },

    /**
     * 供应商拒绝订单
     */
    cancelOrder(itemList) {
      let orders = [];

      itemList.map((m) => {
        orders.push({
          orderNo: m,
          cancelReason: this.rejectionListReasons,
        });
      });

      const params = {
        orders,
      };
      InterfaceService.cancelOrder(
        params,
        (data) => {
          if (data.respCode === "0000") {
            if (data.respData.respCode === "0000") {
              const result = data.respData.confirmRst || [];
              this.handleResultFun(result, "取消");
            } else {
              this.$message.error(data.respData.respMsg);
            }
          } else {
            this.$message.error(data.respMsg);
          }
        },
        (data) => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },

    /**
     * 处理结果返回
     */
    handleResultFun(result, notcieFont) {
      this.$emit("refresh");
      // 如果有失败消息 用 alert 提示
      if (result.some((s) => s.result == 0)) {
        let html = "";
        result.map((m) => {
          html += `<p style="color: ${
            m.result == 0 ? "black" : "green"
            }"><span>${m.orderName || ""}${
            (m.orderName && "：") || ""
            }</span> <span>${m.confirmMsg || "处理失败"}</span></p>`;
        });
        this.$alert(html, `${notcieFont}订单提示信息`, {
          dangerouslyUseHTMLString: true,
        });
      } else {
        this.$message.success("处理成功");
      }
    },

    // 确认合同弹窗
    handleConfirmOrderDialog() {
      const orders = [];
      orders.push(this.order);
      this.$refs["orderConfirm"].open(orders);
    },
    // 确认合同完成
    handleCloseOrderConfirm(bool) {
      if (bool) {
        this.$emit("refresh");
      }
    },
    // 拒绝合同弹窗
    handleRejectOrderDialog() {
      this.$refs["rejectOrder"].open(this.order, this.order.priceType);
    },
    // 确认解除合同弹窗
    handleConfirmRelieveDialog() {
      this.$refs["confirmRelieveOrder"].open(this.order, "S");
    },
    // 拒绝合同完成
    handleCloseRejectOrder(bool) {
      if (bool) {
        this.$emit("refresh", "reject");
      }
    },
    // 解除合同弹窗
    handleRelieveOrderDialog() {
      console.log(this.order, "0this.order");

      this.$refs["relieveOrder"].open(this.order);
    },
    // 拒绝合同完成
    handleCloseRelieveOrder(bool) {
      if (bool) {
        this.$emit("refresh");
      }
    },
    // 取消合同弹窗
    handleCancelDialog() {
      this.$refs["cancelOrder"].open(this.order);
    },
    // 取消合同完成
    handleCloseCancelOrder(bool) {
      if (bool) {
        this.$emit("refresh");
      }
    },
    // 合同解除与终止
    handleOrderRescind(type, isRescind, operTpye) {
      this.$refs["orderRescind"].open(
        this.order,
        type,
        isRescind,
        "",
        operTpye
      );
    },
    handleCloseOrderRescind() {
      this.$emit("refresh", "closeOrderRescind");
    },
    // 撤回解除或终止合同
    withdrawContract(operateType = "") {
      this.$confirm(
        `确认要${
        this.order.terminateType == "relieve"
          ? `${operateType === "0" ? "撤回" : "关闭"}解除合同`
          : `${operateType === "0" ? "撤回" : "关闭"}终止合同`
        }吗？`,
        `确认${operateType === "0" ? "撤回" : "关闭"}`,
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: `确认${operateType === "0" ? "撤回" : "关闭"}`,
          cancelButtonText: "取消",
        }
      )
        .then(() => {
          let params = {
            orderNo: this.order.orderNo,
            operateType: operateType, //0撤回；1关闭
          };
          InterfaceService.withdrawContract(
            params,
            (data) => {
              let res = data.respData || {};
              if (data && data.respData && res.respCode === "0000") {
                this.$message.success("操作成功");
                this.$emit("refresh", "closeOrderRescind");
              } else {
                this.$message.error(data.respData.respMsg);
              }
            },
            (data) => { },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            }
          );
        })
        .catch(() => { });
    },
    // 要货
    handleRequire() {
      this.$router.push({
        path: "/launchGoodsNew",
        query: { orderNo: this.order.orderNo },
      });
    },
    goInitiateASupplement() {
      let corpId = "";

      this.$router.push({
        path: "/initiateASupplement",
        query: {
          state: "newList",
          supplierId: this.order.supplierId,
          supplierName:
            (this.order && encodeURIComponent(this.order.supplierName)) || "",
          orderNo: (this.order && this.order.orderNo) || "",
          contractName:
            (this.order && encodeURIComponent(this.order.contractName)) || "",
          subOrderListCount:
            (this.order &&
              this.order.subOrderList &&
              this.order.subOrderList.length + 1) ||
            1,
          orderCateCode: this.order && this.order.orderCateCode,
          addressId: this.order && this.order.addressId,
        },
      });
    },
    handleConfirmSupplement() {
      const item =
        this.unconfirmedOrderNosComputed(this.order.subOrderList || []) || [];
      let unconfirmedOrderNos = [];
      item.forEach((f) => unconfirmedOrderNos.push(f.subOrderNo));
      this.$router.push({
        path: "/supplierConfirmInitiateASupplement",
        query: {
          unconfirmedOrderNos: encodeURIComponent(
            unconfirmedOrderNos.toString()
          ),
        },
      });
    },
    // 修改协议价
    handleModifyPrice() {
      this.$router.push({
        path: "/modifyPrice",
        query: { orderNo: this.order.orderNo },
      });
    },
    // 查看合同详情
    handleOrderDetail(order, tabIndex = 0, isOpen = true) {
      // 取消增补 功能需要
      if (isOpen) {
        window.open(
          this.$router.resolve({
            path: "/orderDetail",
            query: {
              orderNo: this.order.orderNo,
              draftId: this.order.draftId, // 是否为中间商判断条件
              busiType: this.order.busiType, //
              tabIndex: tabIndex, //
              settleNo: order.settleNo || "",
              settleStatus: order.settleStatus,
              settleType: order.settleType,
            },
          }).href,
          "_blank"
        );
      } else {
        this.$router.push({
          path: "/orderDetail",
          query: {
            orderNo: this.order.orderNo,
            draftId: this.order.draftId, // 是否为中间商判断条件
            busiType: this.order.busiType, //
            tabIndex: tabIndex, //
            settleNo: order.settleNo || "",
            settleStatus: order.settleStatus,
            settleType: order.settleType,
          },
        });
      }
    },
    handleReject() {
      this.$refs["rejectOrder"].open(this.order);
    },
    handleDownloadContract() {
      const params = {
        orderNo: this.order.orderNo,
        bs: this.role === "S" ? "S" : "",
        documentVersion: "",
        fileFrom: "userUpload,systemCreate",
        documentTypeList: [],
      };
      InterfaceService.getContractInfo(
        params,
        (data) => {
          let res = data.respData;
          if (res.respCode === "0000") {
            console.log(res);
            let list = [];
            let documentInfos = res.documentInfos || [];
            if (res.subDocumentInfos) {
              documentInfos = documentInfos.concat(res.subDocumentInfos);
            }
            let attachListB = [];
            let attachListS = [];
            let hasPdf = documentInfos.some((item) => {
              return (
                item.documentType === "dt_10_contract_profession" ||
                item.documentType === "dt_00_contract_profession"
              );
            });
            documentInfos.forEach((file) => {
              if (hasPdf) {
                // if (file.documentType === 'dt_10_contract_profession' || file.documentType === 'dt_00_contract_profession' || file.documentType === 'otherFile') {
                if (
                  [
                    "dt_10_contract_profession",
                    "dt_00_contract_profession",
                    "dt_00_contract_common",
                    "dt_10_contract_common",
                    "otherFile",
                    "purchaserContractTerminate_pdf",
                    "supplierContractTerminate_pdf",
                    "internalReplenishAgreement",
                    "externalReplenishAgreement",
                    "settle_purchaser_File",
                    "settle_supplier_File",
                  ].indexOf(file.documentType) != -1 ||
                  (["contractTerminated"].includes(this.order.orderStatus) &&
                    [
                      "purchaserContractTerminate_pdf",
                      "supplierContractTerminate_pdf",
                    ].indexOf(file.documentType) != -1)
                ) {
                  list.push(file);
                }
              } else {
                list.push(file);
              }
            });
            list.forEach((item) => {
              if (item.bs === "S") {
                let onOff = false;
                attachListS.forEach((_item) => {
                  if (item.documentId == _item.documentId) {
                    onOff = true;
                  }
                });
                if (!onOff) {
                  attachListS.push(item);
                }
              } else if (item.bs === "B") {
                let onOff = false;
                attachListB.forEach((_item) => {
                  if (item.documentId == _item.documentId) {
                    onOff = true;
                  }
                });
                if (!onOff) {
                  attachListB.push(item);
                }
              } else {
                let onOffB = false;
                let onOffS = false;
                attachListB.forEach((_item) => {
                  if (item.documentId == _item.documentId) {
                    onOffB = true;
                  }
                });
                attachListS.forEach((_item) => {
                  if (item.documentId == _item.documentId) {
                    onOffS = true;
                  }
                });
                if (!onOffB) {
                  attachListB.push(item);
                }
                if (!onOffS) {
                  attachListS.push(item);
                }
              }
            });
            console.log(attachListS);
            console.log(attachListB);
            if (this.role === "S") {
              this.handleBatchDownload(attachListS, [], hasPdf);
            } else {
              if (this.order.busiType !== "ONEWAY_ORDER") {
                this.handleBatchDownload(attachListS, attachListB, hasPdf);
              } else {
                this.handleBatchDownload(attachListS, [], hasPdf);
              }
            }
          } else {
            this.$message.error(data.respMsg);
          }
        },
        (data) => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    handleBatchDownload(attachList1, attachList2, hasPdf) {
      let fileInfoBeans = [];
      if (attachList1.length) {
        if (!hasPdf) {
          attachList1.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: item.documentName,
              fileUrl: item.attachUrl,
            });
          });
        } else {
          attachList1.forEach((item, index) => {
            if (item.documentType.indexOf("profession") != -1) {
              fileInfoBeans.push({
                archivePath: "合同专业版/" + item.documentName,
                fileUrl: item.attachUrl,
              });
            }
            if (item.documentType.indexOf("common") != -1) {
              fileInfoBeans.push({
                archivePath: "合同通用版/" + item.documentName,
                fileUrl: item.attachUrl,
              });
            }
            if (item.documentType.indexOf("settle") != -1) {
              fileInfoBeans.push({
                archivePath: "合同结算/" + item.documentName,
                fileUrl: item.attachUrl,
              });
            }
            if (
              [
                "purchaserContractTerminate_pdf",
                "supplierContractTerminate_pdf",
              ].includes(item.documentType)
            ) {
              fileInfoBeans.push({
                archivePath: "合同终止协议/" + item.documentName,
                fileUrl: item.attachUrl,
              });
            }
            if (
              [
                "internalReplenishAgreement",
                "externalReplenishAgreement",
              ].includes(item.documentType)
            ) {
              fileInfoBeans.push({
                archivePath: "合同补充协议/" + item.documentName,
                fileUrl: item.attachUrl,
              });
            }
          });
        }
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true,
      };
      console.log(fileInfoBeans, 'fileInfoBeans');
      InterfaceService.packageDownload(
        params,
        (data) => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl;
            InterfaceService.packageDownloadAsyn(
              url,
              (data) => {
                const files = [
                  {
                    name:
                      (attachList2.length
                        ? this.order.contractName
                        : this.role == "S"
                          ? this.order.contractName
                          : (this.order.busiType !== "ONEWAY_ORDER" ? this.order.contractName.replace(
                            "采购合同",
                            "供应合同"
                          ) : this.order.contractName) + ".zip"),
                    url: data,
                  },
                ];
                this.$download(
                  files,
                  () => {
                    this.isLoading = true;
                  },
                  () => {
                    this.isLoading = false;
                  }
                ).then(() => {
                  this.$message.success("已下载");
                  if (attachList2.length) {
                    this.handleBatchDownload(attachList2, [], hasPdf);
                  }
                });
              },
              () => {
                this.$message.error(data.respData.respMsg);
              },
              () => {
                this.isLoading = true;
              },
              () => {
                this.isLoading = false;
              }
            );
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        (data) => {
          this.$message.error(data.respData.respMsg);
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    // 查看要货单
    handleRequireList(prouct) {
      let path;
      if (this.role == "S") {
        path = "/vendorCenter/requireOrderList";
      } else if (this.role == "B") {
        path = "/purchaserCenter/requireOrderList";
      }
      this.$router.push({
        path: path,
        query: { orderNo: this.order.orderNo },
      });
    },
    // 合同预览
    handleContractPreview(orderType) {
      // this.$refs["contractPreview"].open(this.order);

      this.$router.push({
        path: "/contractSign",
        query: {
          // order: JSON.stringify(this.order),
          orderNo: this.order.orderNo,
          orderType: orderType,
        },
      });
    },
    // 合同签章完成
    handleCloseSignature(bool) {
      if (bool) {
        this.$router.push({
          path: "/signOrderSuccess",
          query: {
            attachUrl: this.attach.attachUrl,
          },
        });
      }
    },
    // 是否允许要货
    allowRequire() {
      let allow = false;
      const order = this.order;
      // allow =
      //     order.itemCount != order.requireCount &&
      //     (order.orderStatus == "03" || order.orderStatus == "11");

      allow = order.orderStatus == "03" || order.orderStatus == "11";
      allow = allow && !this.brokerRole;

      if (allow && order.eventList) {
        allow = false;
        order.eventList.forEach((ev) => {
          // 外部采购合同签署后可以要货
          if (
            ev.eventType == 0 &&
            ev.eventStatus == 2 &&
            ev.documentType == "00"
          ) {
            allow = true;
          }
        });
      }
      return allow;
    },
    signFlag() {
      let allow = true;
      // let hasbroker = this.order.brokerCorpId && this.order.brokerCorpId.length > 0;
      // if (hasbroker) {
      if (this.order.externalSysList && this.order.externalSysList.length > 0) {
        this.order.externalSysList.forEach((item) => {
          if (item.approveStatus != "1") {
            allow = false;
          }
        });
      } else {
        allow = false;
      }
      // }else {
      //     allow = true
      // }
      return allow;
    },
    contractSignStatus() {
      let allow = true;
      if (this.order.eventList && this.order.eventList.length > 0) {
        this.order.eventList.forEach((item) => {
          if (item.eventStatus != "2") {
            allow = false;
          }
        });
      } else {
        allow = false;
      }
      return allow;
    },
    // 是否允许签署合同
    allowSignContract(type) {
      let allow = false;
      if (this.order && this.order.eventList) {
        let acctIdList = [];
        if (this.userinfo.accountList.length) {
          this.userinfo.accountList.forEach((item) => {
            acctIdList.push(item.acctId);
          });
        } else {
          acctIdList.push(this.acctId);
        }
        const list = filterEventByAcct(
          this.order.eventList,
          type,
          // this.acctId
          acctIdList
        );
        list.forEach((item) => {
          if (
            item.eventType == type &&
            (item.eventStatus == 0 || item.eventStatus == 1)
          ) {
            if (item.processList) {
              item.processList.forEach((process) => {
                if (process.processFlg == 0) {
                  allow = true;
                }
              });
            }
          }
        });
      }
      if (
        (this.order.orderStatus == "contractTerminating" ||
          this.order.orderStatus == "contractTerminated") &&
        type == "0"
      ) {
        allow = false;
      }
      return allow;
    },
  },
  mounted() {
    if (
      this.$route &&
      ["PurchaserOrderList", "VendorOrderList"].includes(this.$route.name)
    ) {
      this.isShow = true;
    }
    this.init();
  },
};
</script>

<style lang="scss" scoped>
/deep/ .el-button {
  margin-bottom: 5px;
}

.operate {
  .disabled {
    color: #888;
  }
  a {
    display: block;
    white-space: nowrap;
    padding: 5px 0 0 5px;
    line-height: 18px;
    color: #0082ff;
    font-size: 12px;
    text-align: right;
  }
  p {
    text-align: right;
  }
}
/deep/ .el-dropdown {
  width: 100%;
  text-align: right;
}
/deep/ .el-dropdown-menu__item {
  color: #0082ff;
  text-align: right;
  font-size: 12px;
  &:hover {
    color: #0082ff;
    background: #e8f3fd;
  }
  a {
    display: block;
    width: 100%;
    height: 100%;
  }
}
</style>
<style lang="scss">
.aettle-accounts-dialog {
  color: #444444;
  &.relieve-dialog {
    dl {
      display: flex;
      dt {
        color: #888888;
      }
      dd {
        color: #444;
      }
    }
    .download-dialog-container {
      padding-left: 62px;
      margin-top: 12px;
      span {
        margin-right: 6px;
      }
    }
  }
  /deep/ .el-dialog--center .el-dialog__body {
    padding: 20px 20px 20px 20px;
  }
  .txt-center {
    text-align: center;
  }
  .txt-left {
    text-align: left;
  }
  .sign-result {
    margin-top: 20px;
  }
  .mb10 {
    margin-bottom: 10px;
  }
  .table-container {
    th,
    td {
      text-align: left;
    }
    th {
      height: 34px;
      line-height: 34px;
      padding: 0 12px;
      background: #f9f9f9;
      font-weight: bold;
    }
    td {
      font-size: 12px;
      height: 45px;
      line-height: 45px;
      padding: 0 12px;
      border-bottom: 1px solid #eee;
    }
    .data-center {
      overflow: hidden;
      overflow-y: auto;
      max-height: 232px;
    }
  }
  .table-pagination {
    margin: 20px 0 20px;
  }
  ::-webkit-scrollbar {
    width: 4px;
  }
}
</style>
