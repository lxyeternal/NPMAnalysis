<template>
    <div>
        <!-- 确认合同 -->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="850px" center :close-on-click-modal="false">
            <div slot="title" class="el-dialog__title">{{isBatch? '批量确认合同':'确认合同'}}</div>
            <div class="tl">
                <div>
                    请确认查阅过<span class="blue" @click="handleOpenContractTemplate">合同模板</span>，并<span class="red">确认合同模板中合同金额、货品清单数量及合同条款等重要内容</span>，同意履行货品供应合同。
                    若合同内容<span class="red">有疑议</span>，请<span class="red">直接联系</span>采购商，若无疑义，请填写下列合同信息，点击【确认】即可。

                </div>
                <div class="orderConfirmHead">
                    <span class="isRequired">备货周期为</span>
                    <el-input class="term-input" type="number" v-model="term" placeholder="请输入备货时长"  @keyup.native="validateTerm($event)"></el-input>日历天
                    <span class="info">(即供应商收到发货通知单之日起至供应商将货物送达采购商指定地点的时间周期)。</span>
                </div>
                <el-form class="form" label-width="160px">
                    <el-row>
                        <el-col :span="12" v-for="(item,index) in filterLength(roleList,0,5)" :key="index">
                            <el-form-item :label="item.label+':'" :error="showErrorMsg(item)" :rules="[{required: true, message: '', trigger: 'change'}]">
                                <el-select v-model="item.defaultChoose" :placeholder="'请选择'+item.label" @change="getAcctId(item)">
                                    <el-option class="role-option" v-for="option in filterCurrentRole(item,item.acctList)" :key="option.acctId" :label="option.acctName" :value="option.acctId">
                                        <span style="line-height: 30px" v-html="option.acctName" @click="handlegoUsersManage(option)">{{option.acctName}}</span>
                                        <span v-if="option.mobile">(Tel:{{option.mobile}})</span>
                                        <p v-if="filterRoleName(option.roleIds)" :title="filterRoleName(option.roleIds)">{{filterRoleName(option.roleIds)}}</p>
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>

                    <div v-if="roleList.length>5">
                        <hr>
                        <p class="tip">※本合同为货物供应合同，请添加施工人员（施工单位人员可与供应商人员信息一致），才能为采购商提供供货及安装服务。</p>
                        <el-row>
                            <el-col :span="12" v-for="(item,index) in filterLength(roleList,5)" :key="index">
                                <el-form-item :label="item.label+':'" :error="showErrorMsg(item)" :rules="[{required: true, message: '', trigger: 'change'}]">
                                    <el-select v-model="item.defaultChoose" :placeholder="'请选择'+item.label"  @change="getAcctId(item)">
                                        <el-option class="role-option" v-for="(option,index) in filterCurrentRole(item,item.acctList)" :key="option.acctId" :label="option.acctName" :value="option.acctId">
                                            <span style="line-height: 30px" v-html="option.acctName" @click="handlegoUsersManage(option)">{{option.acctName}}</span>
                                            <span v-if="option.mobile">(Tel:{{option.mobile}})</span>
                                            <p v-if="filterRoleName(option.roleIds)" :title="filterRoleName(option.roleIds)">{{filterRoleName(option.roleIds)}}</p>
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                        </el-row>
                    </div>
                </el-form>
                <div class="order-info-title">
                    收款账户
                    <span class="hand blue" @click="handleAddNewBank">创建账户</span>
                </div>
                <el-form label-width="160px">
                    <el-row class="special-col">
                        <el-col :span="24">
                            <el-form-item label="收款账户" :required="true">
                                <el-select v-model="bankAcctId" :placeholder="'请选择收款账户'" :required="true">
                                    <el-option v-for="(item,index) in accountList"
                                               :key="item.bankAcctId"
                                               :value="item.bankAcctId"
                                               :label="compLabel(item)"
                                    >
                                        <p class="opt-cont">
                                            <span class="fl">{{item.bankName}}({{item.bankAcctNo | formatCardNum }})</span>
                                            <span class="contract fr">{{item.name}}<template v-if="item.mobile">({{item.mobile}})</template></span>
                                        </p>
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确认合同</el-button>
                <el-button size="small" style="width: 100px"  @click="handleOpenContractTemplate">查看合同模板</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <EditBankAcctDialog ref="editBankAcct" @close="handleCloseEdit"></EditBankAcctDialog>
        <Loading :is-loading="isLoading"></Loading>
        <!-- 下载合同 -->
        <ContractDownload ref="contractDownload" :downloadOrder="orders[0]"></ContractDownload>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import ContractDownload from "@/components/order/dialog/ContractDownload";
import EditBankAcctDialog from "@/components/account/finance/EditBankAcctDialog";

const vendorList = [
//     1.供应商
// ·供应商授权代表=>620角色
// ·合同签字人=>621
// ·合同盖章人=>622
// 2.施工单位(如果有的话)
// ·授权代表(指定收货人)=>640角色
// ·项目经理=>641角色
// ·项目盖章人=>642角色
    {
        role: "30",
        label: "供应商授权代表",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"620"
    },
    {
        role: "33",
        label: "项目盖章人",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"623",
    },
    // {
    //     role: "32",
    //     label: "合同签字人",
    //     acctId: "",
    //     acctList: [],
    //     defaultChoose:"",
    //     roleId:"621"
    // },
    {
        role: "31",
        label: "合同盖章人",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"622"
    },
    {
        role: "34",
        label: "故障报修联系人",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"625"
    }
];

const impleList = [
    {
        role: "00",
        label: "施工单位授权代表",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"640"
    },
    {
        role: "01",
        label: "施工单位项目经理",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"641"
    },
    {
        role: "02",
        label: "施工单位项目盖章人",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"642"
    }
];

export default {
    mixins: [accountMixin],
    components: {
        Loading,
        ContractDownload,
        EditBankAcctDialog,
    },

    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            accountDialogVisible: false,
            isBatch: false,
            canEditRole: true,
            orders: [],
            term: "",
            acctList: [],
            accountList: [],
            bankAcctId: "",
            roleList: this.$clone(vendorList),
            showError: false
        };
    },
    methods: {
        /**
         * 打开查看合同弹窗
         */
        handleOpenContractTemplate() {
            // this.$refs["contractDownload"].open(this.orders[0], "download", "hideBtn");
            this.downloadTemp()
        },
         downloadTemp() {
            const params = {
                orderNo: this.orders[0].orderNo || '',
                bs: "S"
            };
            InterfaceService.orderCotractDownload(params, data => {
                }, data => {

                }, () => {
                    this.isLoading = true;
                }, () => {
                    this.isLoading = false;
                }
            );
        },
        compLabel(item) {
            let str = item.bankName+'('+item.bankAcctNo.replace(/\s+/g, "").replace(/(.{4})/g, '$1 ')+')';
            return item.bankName+'('+item.bankAcctNo.replace(/\s+/g, "").replace(/(.{4})/g, '$1 ')+')    '+ item.name;
        },
        // compSpaceLenght(len) {
        //     let space = "  ";
        //     for (let i = 0;i < 55 - len;i++) {
        //         space += " "
        //     }
        //     return space
        // },
        open(orders, isBatch) {
            this.isBatch = isBatch;
            this.orders = orders || [];
            this.term = "";
            this.getSubRole();
            this.roleList = this.$clone(vendorList);
            this.dialogVisible = true;
            this.init();
        },
        filterLength(list, start, end) {
            return this.roleList.slice(start, end);
        },
        handleAddNewBank() {
            this.$refs["editBankAcct"].open(this.bankInfo);
            this.dialogVisible = false
        },
        handleCloseEdit(data) {
            this.dialogVisible = true;
            if (data) {
                this.getBankList(data);
            }
        },
        filterCurrentRole(role,acctList){
            let arr = [];
            acctList.forEach(item =>{
                if (item.roleIds) {
                    item.roleIds.forEach(__item=>{
                        // console.log(__item);
                        if (__item.roleId == role.roleId) {
                            arr.push(item)
                        }
                    })
                }
            });
            if (arr.length == 0) {
                let str = "";
                if (this.canEditRole) {
                    str = `<p style="color: #aaa">暂无${role.label}&nbsp;&nbsp;请设置<em style="cursor: pointer;color: #3a8ee6" @click="go()">权限管理</em>添加</p>`
                } else {
                    str = `<p style="color: #aaa">暂无${role.label},请联系管理员添加该用户</p>`
                }
                arr.push({
                    acctName:str
                })
            }
            return arr
        },
        filterRoleName(list) {
            const arr = [];
            if (list && list.length) {
                list.forEach(item => {
                    if (item.roleName) {
                        arr.push(item.roleName);
                    }
                });
            }

            return arr.join(",");
        },
        showErrorMsg(item) {
            if (!this.showError) return "";
            let msg;
            if (!item.defaultChoose) {
                msg = "请选择" + item.label;
            }
            return msg;
        },
        handlegoUsersManage(option){
            if (option.acctName.indexOf("暂无") != -1){
                this.$router.push('/vendorCenter/usersManage')
            }
        },
        handleConfirm() {
            if (!this.term) {
                this.$message.error("请输入备货时长");
                return;
            }
            if (!this.bankAcctId) {
                this.$message.error("请选择收款账户");
                return;
            }
            let valid = true;
            this.roleList.forEach(item => {

                if (!item.defaultChoose) {
                    valid = false;
                }
            });

            if (!valid) {
                this.showError = true;
            } else {
                this.confirmOrder();
            }
        },
        validateTerm(ev){
            let val = ev.target.value;
            this.term = val.substring(0, 4);
        },
        // 查询项目部下属信息
        getSubRole() {
            const params = {};
            InterfaceService.getQuerySubordinate(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        // this.acctList = data.respData.acctList || [];
                        let arr = [];
                        // 正常状态的用户（acctStatus == "0"）才可以作为干系人参与合同
                        let roles = [];
                        res.acctList && res.acctList.forEach(i=>{
                            if (i.acctStatus == "0") {
                                roles.push(i)
                            }
                        });
                        this.roleList.forEach(item => {
                            item.acctList = roles;
                            item.acctList.forEach(_item=>{
                                if (_item.roleIds){
                                    _item.roleIds.forEach(role=>{
                                        if (role.roleId == item.roleId){
                                            arr.push({
                                                "id":role.roleId,
                                                "acctName":_item.acctName,
                                                "acctId":_item.acctId
                                            })
                                        }
                                    })
                                }
                            })
                        });
                        //下属员工有且仅有一个与label对应的角色时，默认选中
                        let arr1 = [];
                        arr.forEach(item=>{
                            arr1.push(item.id);
                        });
                        const filterNonUnique = arr => arr.filter(i => arr.indexOf(i) === arr.lastIndexOf(i))
                        arr.forEach(item=>{
                            filterNonUnique(arr1).forEach(_item=>{
                                if (item.id == _item) {
                                    this.roleList.forEach(__item=>{
                                        if (__item.roleId == item.id){
                                            __item.defaultChoose = item.acctName
                                            __item.acctId = item.acctId
                                        }
                                    })
                                }
                            })
                        });
                        this.roleList.forEach(item=>{
                            if (!item.defaultChoose){
                                item.defaultChoose = "";
                            }
                            if (item.acctList) {
                                item.acctList.forEach(_item=>{
                                    if (item.defaultChoose == _item.acctId){
                                        item.acctId = _item.acctId
                                    }
                                })
                            }else {
                                item.defaultChoose = ""
                            }
                        });
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        canOperateRole(){
            //判断是否有权限编辑添加用户
            let limitTxCode = sessionStorage.getItem('limitTxCode') || '[]';
            limitTxCode = JSON.parse(limitTxCode)
            for(let i = 0;i<limitTxCode.length ;i++) {
                let limit = limitTxCode[i];
                if (limit.code.indexOf("040013") > -1) {
                    this.canEditRole = false
                }
            }
        },
        getAcctId(item){
            item.acctId = item.defaultChoose
            if (!item.acctId) {
                item.defaultChoose = ""
            }
        },
        confirmOrder() {
            const stakeHolder = [];

            this.roleList.forEach(item => {
                if (item.defaultChoose) {
                    stakeHolder.push({
                        role: item.role,
                        corpId: this.userinfo.corpId,
                        acctId: item.acctId
                    });
                }
            });

            const orders = [];
            this.orders.forEach(item => {
                orders.push(item.orderNo);
            });

            const params = {
                orders: orders,
                prepareCycle: this.term,
                bankAcctId: this.bankAcctId,
                contractStakeHolders: stakeHolder
            };
            InterfaceService.confirmOrder(
                params,
                data => {
                    if (data.respCode === "0000") {
                        if (data.respData.respCode === "0000") {
                            this.dialogVisible = false;
                            this.$emit("close", true);
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        getBankList(diaId) {
            InterfaceService.getBankList(
                {},
                data => {
                    if (data.respData.respCode === "0000") {
                        this.accountList = data.respData.bankList || [];
                        this.accountList.forEach(item=>{
                            if (!diaId) {
                                if (item.defaultFlg === "1") {
                                    this.bankAcctId = item.bankAcctId;
                                }
                            }else {
                                if (diaId === item.bankAcctId) {
                                    this.bankAcctId = item.bankAcctId;
                                }
                            }
                        })
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        init() {
            let vendorImple = false; // 供应商为施工方
            if (this.orders) {
                this.orders.forEach(item => {
                    if(vendorImple) return;
                    let vendorCorpId = "";
                    // 查找供应商
                    item.contractStakeHolders.forEach(_item => {
                        if (!vendorCorpId && _item.role[0] == "3") {
                            vendorCorpId = _item.corpId;
                        }
                    });

                    if (vendorCorpId) {
                        item.contractStakeHolders.forEach(_item => {
                            if (_item.role[0] == "0" && _item.corpId == vendorCorpId) {
                                vendorImple = true;
                            }
                        });
                    }
                });
            }
            if (vendorImple) {
                this.roleList = this.roleList.concat(this.$clone(impleList));
            }
            this.getBankList()
            this.canOperateRole()
        },

    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-select {
    width: 240px;
}
.el-col-12 {
    width: 49%;
    .el-input__inner{
        height: 34px;
    }
}
.orderConfirmHead {
    margin-top: 12px;
    .isRequired {
        display: inline-block;
        &::before {
            content: '*';
            color: #f56c6c;
            margin-right: 4px;
        }
    }
}
hr {
    border: 1px dashed #ececec;
}

.tip {
    margin-top: 20px;
    margin-bottom: 10px;
}

.term-input.el-input {
    width: 200px;
}
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;

    a {
        text-decoration: underline;
        color: #0082ff;
    }

    a.bold {
        font-weight: bold;
        text-decoration: none;
        color: #444444;
        cursor: default;
    }
    span.red {
        color: #ef3338
    }
    span.blue {
        color: #58bcff;
        cursor: pointer;
    }
}

.form {
    margin-top: 20px;

}

.role-option {
    height: auto;
    p {
        height: 30px;
        max-width: 210px;
        line-height: 20px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
}
[class*="el-col-"]{
    display: inline-block;
    float: none;
}
.order-info-title {
    margin: 5px 0 20px;
    padding: 0 10px;
    font-size: 14px;
    border-left: 3px solid #000;
    line-height: 12px;
    text-align: left;
    span{
        margin-left: 10px;
    }
}
    .special-col{
        .el-select {
            width: 638px;
        }
    }
    .opt-cont{
        .contract {
            min-width: 200px;
            text-align: left;
        }
    }

</style>
