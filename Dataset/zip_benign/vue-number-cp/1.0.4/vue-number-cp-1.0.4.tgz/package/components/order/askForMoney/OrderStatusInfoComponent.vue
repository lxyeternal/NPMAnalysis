<template>
  <div class="order-status">
    <div class="status-info-content">
      <div class="left-container">
        <span>当前状态： </span>
        <span class="big">{{statusName || ''}}</span>
      </div>
      <div class="right-container">
        <PaymentReportBtnClickComponent :order="order" @handleOptBtnClick="handleOptBtnClick" @refresh="refresh"></PaymentReportBtnClickComponent>
      </div>
    </div>
  </div>
</template>
<script>
import PaymentReportBtnClickComponent from "@/components/order/askForMoney/PaymentReportBtnClickComponent";
export default {
  props: ['order', 'statusName'],
  components: {
    PaymentReportBtnClickComponent, // 按钮
  },
  methods: {
    handleOptBtnClick() {

    },
    refresh() {
      this.$emit('refresh', true)
    }
  }
}
</script>
<style lang="scss" scoped>
.order-status {
  height: 120px;
  margin: 20px 0;
  padding: 40px 20px 40px 80px;
  border: 1px solid #fddd74;
  background: url("../../../assets/images/order-detail-bg.jpg") no-repeat;
  background-size: 100% 100%;
  display: flex;
  align-items: center;
  .status-info-content {
    display: flex;
    justify-content: space-between;
    align-content: center;
    font-size: 14px;
    width: 100%;
    .left-container {
      span {
        color: #888888;
      }
      .big {
        font-size: 18px;
        color: #333;
      }
    }
  }
}
</style>
