<template>
  <div>
    <!-- 快速选型采购 - 选择项目公司 -->
    <el-dialog class="dialog dialog-drafts quick-purchase-dialog" title="选择项目公司" :append-to-body="true" :lock-scroll="true" @close="cancel" :visible.sync="draftsDialogVisible" width="800px" center :close-on-click-modal="false">
      <div class="drafts-list">
        <span>选择项目公司</span>
        <el-select v-model="quickPurchaseDialogValue" clearable filterable remote reserve-keyword placeholder="请输入关键词快速搜索选择项目公司" :remote-method="remoteQuickPurchaseMethod">
          <el-option v-for="(item, idx) in quickPurchaseDialogOptions" :key="idx" :disabled="optionDisabled(item)" :label="item.supplierName" :value="item.trustCode || ''">
            <span>{{item.supplierName}}<em class="signed" v-if="item.status == '1'">已入驻</em></span>
          </el-option>
        </el-select>
      </div>

      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 100px" :disabled="!quickPurchaseDialogValue" @click="quickPurchaseConfirm">下一步</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from '@/services/api'
import Loading from '@/components/base/Loading'
import accountMixin from "@/mixins/account";
export default {
  mixins: [accountMixin],
  components: {
    Loading
  },
  computed: {
    userInfo() {
      return this.userinfo || {}
    },
    optionDisabled() {
      return item => {
        // return (item.status == 1 && !['1', '2'].includes(item.supplyType)) || (item.supplierCorpList && item.supplierCorpList.some(s => s == this.userInfo.corpId))
        return item.bs === 'S' || item.corpId === this.proCorpId
      }
    },
  },
  props: ['value', 'projectId', 'proCorpId', 'detailInfo'],
  data() {
    return {
      isLoading: false,
      quickPurchaseDialogOptions: [],
      quickPurchaseDialogValue: '',
      queryCorpName: '', // 供应商名称
      draftsDialogVisible: this.value || false,
      nextDisabled: true,
    }
  },

  mounted() {
  },
  methods: {
    /**
     * 取消
     */
    cancel() {
      this.draftsDialogVisible = false
      this.$emit('input', false)
    },

    /**
     * 快速搜索 - 输入
     */
    remoteQuickPurchaseMethod(query) {
      query.replace(/\s*/g, '').length && this.getSupplierMedicalChecklist(query)
    },

    /**
     * 重置-弹窗数据
     */
    resetQuickPurchaseData() {
      this.quickPurchaseDialogValue = ''
      this.quickPurchaseDialogOptions = []
    },

    /**
     * 快速选型采购 - 确认
     */
    quickPurchaseConfirm() {
      if (!this.quickPurchaseDialogValue) {
        this.$message.error('请选择项目公司')
        return
      }
      let item = {};
      let isManufactor = '0';
      this.quickPurchaseDialogOptions.some(s => {
        if (s.trustCode === this.quickPurchaseDialogValue) {
          item = s;
          isManufactor = s.supplyType === '0' ? '1' : '0'
          return true
        }
      })

      const agentUserInfo = {
        acctName: item.supplierName,
        legalRepresent: item.legalPersonName,
        registCapital: item.regCapital,
        establishDt: item.estiblishDt,
        busiLicense: item.trustCode,
        corpId: item.corpId,
        corpName: item.supplierName,
        contactName: item.legalPersonName,
        isManufactor: isManufactor,
        bs: item.bs,
        projectId: this.projectId,
        projectName: this.detailInfo && this.detailInfo.projectName || ''
      };

      this.$setRootScope('agentUserInfo', JSON.stringify(agentUserInfo))

      window.open(this.$router.resolve({
        path: '/fkAregister',
        query: {
          proCorpId: this.proCorpId
        }
      }).href, '_blank')

      this.cancel()
    },



    /**
     * 查询
     */
    getSupplierMedicalChecklist(keyWord) {
      const params = { keyWord: keyWord }
      InterfaceService.getSupplierMedicalChecklist(params, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          try {
            this.quickPurchaseDialogOptions = data.respData && data.respData.storageInfo && data.respData.storageInfo.filter(f => f.trustCode) || []
          } catch (error) {
            console.error(error)
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },
  },
}
</script>
<style lang="scss" scoped>
.quick-purchase-dialog {
  .drafts-list {
    display: flex;
    align-items: center;
    & > span {
      width: 80px;
      display: block;
    }
    /deep/ .el-select {
      $topbar-height: 80px;
      width: calc(100% - #{$topbar-height});
      .el-select__input {
        border: 0;
      }
    }
  }
}
.signed {
  width: 76px;
  height: 20px;
  line-height: 20px;
  color: #fff;
  font-size: 14px;
  text-align: center;
  background: #830bb9;
  border-radius: 2px;
  margin-left: 4px;
  display: inline-block;
}
</style>

