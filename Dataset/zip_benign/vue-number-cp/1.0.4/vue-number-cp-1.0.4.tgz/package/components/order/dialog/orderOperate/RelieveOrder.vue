<template>
    <div>
        <!-- 取消合同 -->
        <el-dialog class="dialog" :title="title" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="870px" center :close-on-click-modal="false">
            <template v-if="!contractSignStatus()">
                <div style="text-align: center">
                    是否确认已和供应商达成一致？
                </div>
            </template>
            <template v-if="((orderStatus == '11' || orderStatus == 'addProduct'))&& contractSignStatus()">
                <div class="tl">
                    <div class="tip">
                        确认已和供应商达成一致，同意解除合同。<span class="red">点击【确认并发起】按钮，就视作同意以下所有合同内容</span>。
                    </div>
                    <div class="relieve-title">
                        合同解除协议
                        <span class="pointer" @click="handleDownload">下载</span>
                    </div>
                    <p v-for="(item,index) in attachList" style="margin-bottom: 14px">
                        {{item.documentName}}
                        <span class="pointer" @click="handlePreview(item)">点击预览</span>
                    </p>
                    <div class="uplode">
                        <div style="margin-bottom: 10px">※请严格使用平台提供的合同解除模板，先<span class="red">下载平台提供的</span><em class="pointer" style="text-decoration: underline" @click="handleDownload">合同解除协议模板</em>，在这份模板的基础上去完善条款，确认无误后再上传。上传合同解除协议时，系统将自动规范合同解除协议命名。</div>
                        <el-form ref="contractForm" label-width="154px">
                            <el-form-item label="货物供应合同解除协议" class="contract-content" v-if="hasBroker">
                                <el-col :span="20">
                                    <div class="contract-list">
                                        {{ScontractName}}
                                    </div>
                                </el-col>
                                <input id="S-contract" ref="contract-list" type="file" @change="handleUploadContract($event,'B')" />
                                <label for="S-contract">上传文件</label>
                            </el-form-item>
                            <el-form-item label="货物采购合同解除协议" class="contract-content">
                                <el-col :span="20">
                                    <div class="contract-list">
                                        {{BcontractName}}
                                    </div>
                                </el-col>
                                <input id="B-contract" ref="contract-approval" type="file" @change="handleUploadContract($event,'S')"/>
                                <label for="B-contract">上传文件</label>
                            </el-form-item>
                        </el-form>
                    </div>
                    <div class="relieve-title">
                        解除协议凭证附件
                    </div>
                    <p style="margin-bottom: 10px">
                        若有解除协议相关凭证及已通知对方的证据等附件，请上传，格式不限，可上传多份。
                    </p>
                    <el-form ref="contractForm" label-width="154px">
                        <el-form-item label="合同解除凭证附件" class="contract-content">
                            <el-col :span="20">
                                <div class="contract-list">
                                    {{enclosurePlaceholder}}
                                    <el-tag size="mini" closable v-for="(item,index) in documentInfos" :key="index" v-if="item.bs=='BS'" @close="handleDelAttach(index)">{{item.documentName}}</el-tag>
                                </div>
                            </el-col>
                            <input multiple="multiple" id="other-contract" ref="contract-list" type="file" @change="handleUploadEnclosure" />
                            <label for="other-contract">上传文件</label>
                        </el-form-item>
                    </el-form>
                </div>
            </template>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 120px" @click="handleConfirm" v-if="!contractSignStatus()">确认，终止磋商</el-button>
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm" v-if="(orderStatus == '11' || orderStatus == 'addProduct') && contractSignStatus()">确认并发起</el-button>
                <el-button size="small" style="width: 100px" @click="handleCloseDialog">取消</el-button>
            </div>
        </el-dialog>
        <!-- 确认上传文件名称格式 -->
        <el-dialog class="confirm-dialog" title="确认上传文件名称" :append-to-body="true" :lock-scroll="true" :visible.sync="confirmVisible" width="50%" center :close-on-click-modal="false">
            <p class="title-tip">由于你上传的文件名，不符合规范，系统将自动更改成规范命名，请确认上传的文件对应的文件名称：</p>
            <p class="confirm-title" v-for="(text,index) in arrContactName" :key="index">
                <span class="title-bg"></span>
                {{text.name}}
            </p>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 120px" @click="handleChange">确认更改并上传</el-button>
                <el-button size="small" style="width: 120px" @click="confirmVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import { viewFile } from '@/utils/orderUtil';

export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            order: {},
            orderNo: "",
            title: "",
            orderStatus: "",
            hasBroker: false,
            documentInfos:[],
            changeNameArr:[],
            arrContactName:[],
            attachList:[],
            confirmVisible: false
    };
    },
    computed: {
        /**
         * @return {string}
         */
        ScontractName() {
            let name = "请选择word文件";
            this.documentInfos.forEach(item => {
                if (item.bs == "B") {
                    name = item.documentName;
                }
            });
            return name;
        },
        /**
         * @return {string}
         */
        BcontractName() {
            let name = "请选择word文件";
            this.documentInfos.forEach(item => {
                if (item.bs == "S") {
                    name = item.documentName;
                }
            });
            return name;
        },
        enclosurePlaceholder(){
            let name = '请上传，格式不限，可上传多份';
            this.documentInfos.forEach(item => {
                if (item.bs == "BS") {
                    name = "";
                }
            });
            return name;
        }
    },
    methods: {
        open(data) {
            this.order = data;
            console.log(this.order);
            this.documentInfos = [];
            this.orderNo = data.orderNo;
            this.orderStatus = data.orderStatus;
            if (this.order.brokerCorpId && this.order.brokerCorpId.length > 0) {
                this.hasBroker = true;
            }
            if ((data.orderStatus == "11" || data.orderStatus == "addProduct") && this.contractSignStatus()) {
                this.title =  "发起合同解除通知";
                this.getRelieveTemplate()
            }else {
                this.title = "终止磋商"
            }
            this.dialogVisible = true;
        },
        contractSignStatus(){
            let allow = true;
            if (this.order.eventList && this.order.eventList.length > 0) {
                this.order.eventList.forEach(item=>{
                    if (item.eventStatus != "2") {
                        allow = false;
                    }
                })
            }else {
                allow = false
            }
            return allow
        },
        handlePreview(item){
            if (item.attachUrl) {
              viewFile(item.attachUrl)
            }
        },
        handleCloseDialog(){
            this.dialogVisible = false;
            this.documentInfos = []
        },
        handleDownload(){
            this.attachList.forEach(item => {
                let attachUrl = item.attachUrl;
                if (!attachUrl) return this.$message.error("无下载地址");
                let name = attachUrl.split("?")[0];
                name = name.split("/").pop();
                const files = [{ name: decodeURIComponent(name), url: attachUrl }];
                this.$download(files).then(() => {
                    this.$message.success("已下载");
                });
            });
        },
        handleConfirm() {
            if (!this.contractSignStatus()) {
                this.relieveOrder("beforeSign");
            }else if ((this.orderStatus == '11' || this.orderStatus == 'addProduct')&& this.contractSignStatus()) {
                let onOff = true;
                let contractUploadFlag = "0";
                this.documentInfos.forEach(item=>{
                    if (item.bs == "B" || item.bs == "S") {
                        if (this.hasBroker) {
                            onOff = !onOff;
                        }
                        contractUploadFlag = "1"
                    }
                });
                if (!onOff) {
                    this.$message.error("请同时上传货物供应合同解除协议与货物采购合同解除协议")
                } else {
                    if (contractUploadFlag === "1") {
                        let reg = /\.\w+$/;
                        let regLeft = /《/;
                        let regRight = /》/;
                        this.arrContactName = [] //显示
                        this.changeNameArr = [] //临时存改变名字
                        const documentInfos = [].concat(this.documentInfos);
                        documentInfos.forEach(item=>{
                            if (item.bs == "B" || item.bs == "S") {
                                // let fileName = item.documentName.replace(reg, '').replace(regLeft, '').replace(regRight, '');
                                let fileName = item.documentName;
                                let str = "";
                                this.attachList.forEach(_item => {
                                    if (_item.documentType == item.documentType) {
                                        str = _item.documentName
                                    }
                                });
                                // let str = this.order.contractName;
                                let type = item.bs;
                                if (str != fileName) {
                                    this.arrContactName.push({
                                        name: '合同文本：' + fileName + '，上传后系统自动命名成' + str
                                    });
                                    this.changeNameArr.push({
                                        type: item.documentType,
                                        documentName: str,
                                        bs: type
                                    })
                                }
                            }
                        });
                        // let contractName = this.order.contractName;
                        // if( contractName && contractName.match('专业分包') ){
                        //     onOff = false
                        // }
                        // if( contractName && contractName.match('供应及安装') ){
                        //     SupplyAndInstallation = false
                        // }
                        // const documentInfos = [].concat(this.documentInfos);
                        // documentInfos.forEach(item=>{
                        //     if (item.bs == "B" || item.bs == "S") {
                        //         let fileName = item.documentName.replace(reg,'').replace(regLeft,'').replace(regRight,'');
                        //         let fileExt = item.documentName.replace(/.+\./,"");
                        //         let str = this.order.contractName;
                        //         let type = item.bs;
                        //         if (!onOff) {
                        //             if ( str != fileName) {
                        //                 this.arrContactName.push({
                        //                     name:'合同文本：'+ fileName +'，上传后系统自动命名成《'+str+'》解除合同'
                        //                 });
                        //                 this.changeNameArr.push({
                        //                     type:'purchaserContractTerminate',
                        //                     documentName:`《${str}解除合同》.${fileExt}`,
                        //                     bs: type
                        //                 })
                        //             }
                        //         }else {
                        //             if( type == 'B' ){
                        //                 if( !SupplyAndInstallation ){
                        //                     let SupplyAndInstallationStr = str.replace('供应及安装合同','供应及安装供应合同')
                        //                     if( SupplyAndInstallationStr != fileName ){
                        //                         this.arrContactName.push({
                        //                             name:'合同文本：'+fileName+'，上传后系统自动命名成《'+SupplyAndInstallationStr+'解除合同》'
                        //                         })
                        //                         this.changeNameArr.push({
                        //                             type:'supplierContractTerminate',
                        //                             documentName: `《${SupplyAndInstallationStr}解除合同》.${fileExt}`,
                        //                             bs: type
                        //                         })
                        //                     }
                        //                 }else{
                        //                     str = str && str.replace('供应合同','货物供应合同')
                        //                     if( str != fileName ){
                        //                         this.arrContactName.push({
                        //                             name:'合同文本：'+fileName+'，上传后系统自动命名成《'+str+'解除合同》'
                        //                         })
                        //                         this.changeNameArr.push({
                        //                             type:'supplierContractTerminate',
                        //                             documentName: `《${str}解除合同》.${fileExt}`,
                        //                             bs: type
                        //                         })
                        //                     }
                        //                 }
                        //             }else{
                        //                 if( !SupplyAndInstallation ){
                        //                     let SupplyAndInstallationStr = str && str.replace('供应及安装合同','供应及安装采购合同')
                        //                     if( SupplyAndInstallationStr != fileName ){
                        //                         this.arrContactName.push({
                        //                             name:'合同文本：'+fileName+'，上传后系统自动命名成《'+SupplyAndInstallationStr+'解除合同》'
                        //                         })
                        //                         this.changeNameArr.push({
                        //                             type:'purchaserContractTerminate',
                        //                             documentName:  `《${SupplyAndInstallationStr}解除合同》.${fileExt}`,
                        //                             bs: type
                        //                         })
                        //                     }
                        //                 }else{
                        //                     str = str && str.replace('供应合同','货物采购合同')
                        //                     if( str != fileName ){
                        //                         str = str && str.replace('供应合同','采购合同')
                        //                         this.arrContactName.push({
                        //                             name:'合同文本：'+fileName+'，上传后系统自动命名成《'+str+'解除合同》'
                        //                         })
                        //                         this.changeNameArr.push({
                        //                             type:'purchaserContractTerminate',
                        //                             documentName: `《${str}解除合同》.${fileExt}`,
                        //                             bs: type
                        //                         })
                        //                     }
                        //                 }
                        //             }
                        //         }
                        //     }
                            // console.log(fileName, str);
                        // });
                        if( this.changeNameArr.length != 0 ){
                            this.confirmVisible = true;
                        }else{
                            // this.concatAttach();
                            this.handleUplode()
                        }
                    }else {
                        this.handleUplode();
                    }
                }
            }
        },
        handleUplode() {
            if (this.documentInfos.length > 0) {
                this.isLoading = true;
                this.uploadContractToOss().then(res => {
                    this.isLoading = false;
                    this.documentInfos.forEach((item, index) => {
                        res.forEach(oss => {
                            if (index == oss.index) {
                                item.documentUrl = oss.documentUrl;
                            }
                        });
                    });
                    this.relieveOrder('afterSign');
                });
            } else {
                this.relieveOrder("beforeSign")
            }

        },
        uploadHander(data, pos, file, dirName, callBack,customName) {
            InterfaceService.uploadToOss(data, file, dirName, pos, callBack,customName);
        },
        uploadContractToOss() {
            return new Promise((resolve, reject) => {
                //去后端拿签名
                InterfaceService.getOssSignature(
                    { type: "1" },
                    data => {
                        const promiseList = [];
                        let now = new Date().getTime();
                        this.documentInfos.forEach((item, index) => {
                            let dirName;
                            // dirName = this.order.orderNo + "/internalFiles/" + now + "/";
                            if( item.bs == 'B'){
                                dirName = this.order.orderNo + "/internalFiles/" + now + "/";
                            } else if (item.bs == 'S' || item.bs == 'BS') {
                                dirName = this.order.orderNo + "/externalFiles/" + now + "/";
                            }
                            const promise = new Promise(_resolve => {
                                this.uploadHander(
                                    data,
                                    index,
                                    item.file,
                                    dirName,
                                    (pos, file, dir, signature) => {
                                        let u = signature.dir + dir + item.documentName;
                                        _resolve({ index: index, documentUrl: u });
                                    },
                                    item.documentName
                                )
                            });
                            promiseList.push(promise);
                        });
                        // 上传所有图片后回调
                        Promise.all(promiseList).then(values => {
                            resolve(values);
                        });
                    },
                    data => {}
                );
            });
        },
        handleChange(){
            // this.concatAttach();
            this.documentInfos.forEach((item)=>{
                this.changeNameArr.forEach((val)=>{
                    if( val.bs == item.bs ){
                        if (val.documentType) {
                            if (item.documentType === val.documentType) {
                                item.documentName = val.documentName
                            }
                        } else {
                            item.documentName = val.documentName;
                        }
                    }
                })
            });
            this.handleUplode();
            this.confirmVisible = false;
        },
        handleUploadContract(e,type) {
            const file = e.target.files[0];
            if (!file) {
                return;
            }
            if (!file.type.match("word")) {
                this.$message.error("请上传word文件");
                return;
            }
            if (type == "S") {
                let hasContract = false;
                this.documentInfos.forEach(item => {
                    if (item.bs == "S") {
                        item.file = file;
                        item.documentName = file.name;
                        item.documentType = "supplierContractTerminate";
                        hasContract = true;
                    }
                });
                if (!hasContract) {
                    this.documentInfos.push({
                        bs: "S",
                        file: file,
                        documentName: file.name,
                        documentType: "supplierContractTerminate"
                    });
                }
            } else if (type == "B") {
                let hasContract = false;
                this.documentInfos.forEach(item => {
                    if (item.bs == "B") {
                        item.file = file;
                        item.documentName = file.name;
                        item.documentType = "purchaserContractTerminate";
                        hasContract = true;
                    }
                });
                if (!hasContract) {
                    this.documentInfos.push({
                        bs: "B",
                        file: file,
                        documentName: file.name,
                        documentType: "purchaserContractTerminate"
                    });
                }
            }
        },
        handleUploadEnclosure(e){
            const files = e.target.files;
            if (!files || !files.length) {
                return;
            }
            Array.prototype.forEach.call(files, file => {
                let onOff = true
                if (this.documentInfos.length) {
                    this.documentInfos.forEach(item=>{
                        if (item.documentType == "contractTerminateAttach") {
                            if (item.documentName == file.name) {
                                console.log(item.documentName);
                                this.$message.error("请勿上传相同文件");
                                onOff = false
                            }
                        }
                    })
                }
                if (onOff) {
                    this.documentInfos.push({
                        bs: "BS",
                        file: file,
                        documentName: file.name,
                        documentType:"contractTerminateAttach"
                    });
                }
            });
            e.value = "";
        },
        handleDelAttach(index) {
            this.documentInfos.splice(index, 1);
        },
        relieveOrder(type) {
            let params = {};
            if (type == "beforeSign"){
                params = {
                    orderNo : this.orderNo,
                    documentInfos: this.documentInfos
                }
            } else if (type == "afterSign") {
                // this.documentInfos.forEach(item=>{
                //     delete item.file
                // });
                params = {
                    orderNo : this.orderNo,
                    documentInfos: this.documentInfos
                }
            }
            console.log(params);
            InterfaceService. ApplyRelieveOrder(
                params,
                data => {
                    console.log(data);
                    if (data.respCode === "0000") {
                        if (data.respData.respCode === "0000") {
                            this.dialogVisible = false;
                            this.confirmVisible = false;
                            this.$message.success("发起合同解除通知成功");
                            this.$emit("close", true);
                        }else {
                            this.$message.error(data.respData.respMsg);
                        }
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        getRelieveTemplate(){
            let params = {}
            // this.attachList = [];
            if (this.hasBroker) {
                params = {
                    orderNo: this.order.orderNo,
                    documentTypeList:["purchaserContractTerminate","supplierContractTerminate"]
                };
            } else {
                params = {
                    orderNo: this.order.orderNo,
                    bs:"S",
                    documentTypeList:["supplierContractTerminate"]
                };
            }
            InterfaceService.getContractInfo(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.attachList = data.respData.documentInfos || []
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
.error-info {
    color: #f56c6c;
    font-size: 12px;
    line-height: 1;
    padding-top: 4px;
    position: absolute;
    top: 100%;
    left: 0;
}
/deep/ .el-dialog__body{
    padding-top: 20px;
}
.contract-content {
    position: relative;
    input[type="file"] {
        position: absolute;
        width: 0;
        height: 0;
        overflow: hidden;
        opacity: 0;
    }

    label {
        display: inline-block;
        padding: 12px 20px;
        line-height: 1;
        white-space: nowrap;
        cursor: pointer;
        font-size: 14px;
        border: 1px solid #ffd64e;
        background: #ffd64e;
        margin-left: 10px;
    }
    /deep/ .el-checkbox {
        padding: 0;
        margin-left: 0;
        border: none;
        background: none;
    }
    /deep/ .el-col-24 label:nth-of-type(2){
        margin-left: 10px;
    }
    .label-title{
        width: 100%;
        line-height: 18px;
    }

    .label-sub-title{
        width: 100%;
        line-height: 16px;
        font-size: 12px;
    }

    .contract-list {
        min-height: 38px;
        padding: 9px 10px;
        border: 1px solid #dcdfe6;
        line-height: 20px;
        color: #888888;
    }

    a{
        margin-left: 10px;
        color: #0082ff;
    }
}
    .relieve-title{
        margin: 30px 0 14px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
        p{
            margin-bottom: 14px;
        }
    }
.pointer{
    margin-left: 5px;
    cursor: pointer;
    color: #0082ff;
}
    .uplode{
        border-top: 1px #ccc dashed;
        /*margin: 10px 0;*/
        padding-top: 20px;
        /deep/ .el-form-item__label{
            text-align: left;
        }
    }
.confirm-dialog{
    line-height: 25px;

    .title-tip{
        padding-bottom: 10px;
    }

    .confirm-title{
        position: relative;
        line-height: 20px;
        padding-left: 10px;
        text-align: left;

        .title-bg{
            width: 3px;
            height: 12px;
            position: absolute;
            background: #4f525a;
            top: 4px;
            left: 0;
        }
    }
    .upload-foot{
        width: 100%;
        text-align: center;
        margin-bottom: 10px;
    }

}
/deep/ .el-tag {
    max-width: 550px;
    min-height: 20px;
    word-break: break-all;
    white-space: normal;
}
</style>
