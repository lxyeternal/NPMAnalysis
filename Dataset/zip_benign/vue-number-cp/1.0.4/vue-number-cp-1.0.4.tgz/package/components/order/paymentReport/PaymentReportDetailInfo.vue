<template>
    <div>
        <div class="info">
            <el-row>
                <el-col :span="8">
                    <p>
                        <label>合同名称：</label>
                        <span>
                            <span v-if="info.contractName">《{{info.contractName}}》</span>
                        </span>
                    </p>
                    <p>
                        <label>合同编号：</label>{{info.orderNo}}
                    </p>
                </el-col>
                <el-col :span="8">
                    <p>
                        <label>供应商：</label>{{info.supplierName}}
                    </p>
                    <p>
                        <label>采购商：</label>{{info.purchaserName}}
                    </p>
                </el-col>
                <el-col :span="8">
                    <p>
                        <label>请款报告号：</label>{{info.paymentReportNo}}
                    </p>
                    <p>
                        <label>发起时间：</label>{{info.paymentCt|datetime}}
                    </p>
                    <p>
                        <label>入账周期：</label>{{info.startDt}} ~ {{info.endDt}}
                    </p>

                </el-col>
            </el-row>
        </div>
    </div>
</template>

<script>
export default {
    props: ["type", "info"]
};
</script>

<style lang="scss" scoped>
.info {
    margin-bottom: 20px;
    line-height: 25px;
    font-size: 12px;

    /deep/ .el-col {
        padding: 0 10px;
    }

    p {
        width: 100%;
        display: flex;
        padding-right: 10px;
        word-break: break-word;
        white-space: normal;

        & > span {
            display: inline-block;
            flex: 1 1 0%;
        }
    }

    label {
        white-space: nowrap;
        color: #888888;
    }

    a {
        white-space: nowrap;
        color: #0082ff;
    }

    i {
        font-style: normal;
    }
}
</style>
