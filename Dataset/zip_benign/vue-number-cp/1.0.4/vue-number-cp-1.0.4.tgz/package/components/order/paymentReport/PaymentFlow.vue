<template>
  <div class="process-conent">
    <div class="process-tr" v-for="(line,ind) in lines" :key="ind">
      <div class="short-line" v-if="ind%2 == 1"></div>
      <div class="step" :style="{width:stepWidth}" v-for="(item , index) in line" :key="index">
        <div class="bar" v-show="item.showBar"></div>
        <div class="header-bar" v-if="ind != 0 && ind%2 == 0 && index == 0"></div>
        <span :class="{'active':item.isCurrentNode == '1'}">{{item.step}}</span>
        <p :class="{'active':item.isCurrentNode == '1'}">{{item.flowName}}</p>
        <div class="show-tail" v-if="item.showTail"></div>
      </div>
      <div class="fold-line" v-if="ind < (lines.length - 1) && ind%2 == 0">
        <div class="long-line"></div>
      </div>
      <div class="even-line" v-if="ind < (lines.length - 1) && ind%2 == 1"></div>
      <div class="odd-line" v-if="ind != 0 && ind%2 == 0"></div>
    </div>
  </div>
</template>

<script>
export default {
  props: {
    flowList:{
      type: Array
    },
    lineNum:{
      type:Number
    },
  },
  data() {
    return {
      ceil:0,
      lines:[],
      stepWidth:'112px'
    };
  },
  methods: {
    init() {
      let ceil = Math.ceil(this.flowList.length / this.lineNum)
      for(let i=0;i<ceil;i++){
        if( i === 0){
          this.lines.push([...this.flowList.slice(0,this.lineNum)])
        }else if( i == (ceil-1) ){
          this.lines.push([...this.flowList.slice(i*this.lineNum)])
        }else{
          this.lines.push([...this.flowList.slice(i*this.lineNum,(i+1)*this.lineNum)])
        }
      }
      this.lines.forEach((item,index)=>{
        if(((index+1)%2) == 0){ //偶数
          item.forEach((val,ind,arr)=>{
            val.showBar = true; //默认每个状态栏都会出现一条灰色横杠线
            if( index < (this.lines.length - 1) && ind == (this.lineNum - 1)  ){ //但是有个特殊情况，当有下面一行的时候，那么最后一个横杠还是要出现
              val.showTail = true;
            }
          })
        }else{ //奇数
          item.forEach((val,ind,arr)=>{
            val.showBar = true; //默认每个状态栏都会出现一条灰色横杠线
            if( ind == arr.length - 1 ){ //因为最后一个了后面没有了，所以去除最后一个状态下的横杠线
              val.showBar = false;
            }
            if( index < (this.lines.length - 1) && ind == (this.lineNum - 1) ){ //但是有个特殊情况，当有下面一行的时候，那么最后一个横杠还是要出现
              val.showBar = true;
            }
          })
        }
      })
      console.log(this.lines)
    }
  },
  mounted() {
    setTimeout(()=>{
      let processTrLength = document.getElementsByClassName('process-tr')[0].clientWidth
      this.stepWidth = `${Math.floor(processTrLength / this.lineNum) - 20}px`;
    },100)
    this.init(); 
  }
};
</script>

<style lang="scss" scoped>
.process-conent{
  width: 100%;
  position: relative;

  .fold-line{
    width: 2px;
    height: 100%;
    position: absolute;
    top: 0;
    right: 0;
    padding-top: 74px;

    .long-line{
      width: 100%;
      height: 100%;
      background: #eeeeee;
    }
  }

  .even-line{
    width: 2px;
    height: 100%;
    position: absolute;
    top: 20px;
    left: 0;
    background: #eeeeee;
  }

  .odd-line{
    width: 2px;
    height: 75px;
    position: absolute;
    top: 0px;
    left: 0;
    background: #eeeeee;
  }

  .process-tr:nth-of-type(2n-1){
    width: 100%;
    overflow: hidden;
    padding-top: 64px;
    padding-bottom: 40px;
    position: relative;

    .step{
      float: left;
    }
    .step:first-child{
      margin-left: 0;
    }
  }

  .process-tr:nth-of-type(2n){
    width: 100%;
    overflow: hidden;
    position: relative;
    padding-top: 10px;

    .step{
      float: right;
      margin-right: 20px;
      margin-left: 0;
    }

    .short-line{
      width: 2px;
      height: 20px;
      background:#eeeeee;
      position: absolute;
      right: 0;
      top: 0;
    }
  }

  .step{
    width: 112px;
    text-align: center;
    position: relative;
    margin-left: 20px;

    .bar{
      width: 135px;
      height: 2px;
      background: #eeeeee;
      position: absolute;
      top: 10px;
      left: 60px;
      z-index: 1;
    }

    .show-tail{
      width: 56px;
      height: 2px;
      background: #eeeeee;
      position: absolute;
      top: 10px;
      left: 0px;
      z-index: 1;
    }

    .header-bar{
      width: 56px;
      height: 2px;
      background: #eeeeee;
      position: absolute;
      top: 10px;
      left: 0;
      z-index: 1;
    }

    span{
      width: 24px;
      height: 24px;
      display: inline-block;
      line-height: 24px;
      border-radius: 50%;
      background: #ffd64e;
      color: white;
      position: relative;
      z-index: 10;
    }
    span.active{
      background: #f87a31;
      width: 32px;
      height: 32px;
      line-height: 32px;
      position: relative;
      top: -5px;
    }

    p{
      line-height: 22px;
      margin-top: 18px;
    }
    p.active{
      margin-top: 10px;
    }
  }
}
</style>
