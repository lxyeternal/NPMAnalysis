<template>
    <div>
        <!-- 生成对账单 -->
        <el-dialog class="dialog" title="请选择请款事由" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="700px" center :close-on-click-modal="false">
            <div>
                <p>合制平台暂时仅支持“预付款”及“进度款”的请款申请。</p>
                <div class="card-content">
                    <el-row :gutter="10">
                        <el-col :span="12">
                            <el-card shadow="hover" class="card-item" @click.native="handleSelect('advance')">
                                <img src="@/assets/images/paymentReport/advance_charge.png" class="image">
                                <span>预付款</span>
                            </el-card>
                        </el-col>
                        <el-col :span="12">
                            <el-card shadow="hover" class="card-item" @click.native="handleSelect('progress')">
                                <img src="@/assets/images/paymentReport/progress_payment.png" class="image">
                                <span>进度款</span>
                            </el-card>
                        </el-col>
                        <el-col :span="12">
                            <el-card shadow="hover" class="card-item ignore">
                                <img src="@/assets/images/paymentReport/completion.png" class="image">
                                <span>竣工验收款</span>
                            </el-card>
                        </el-col>
                        <el-col :span="12">
                            <el-card shadow="hover" class="card-item ignore">
                                <img src="@/assets/images/paymentReport/settlement.png" style="width:21%" class="image">
                                <span>结算款</span>
                            </el-card>
                        </el-col>
                        <el-col :span="12">
                            <el-card shadow="hover" class="card-item ignore">
                                <img src="@/assets/images/paymentReport/premium.png" class="image">
                                <span>质保金</span>
                            </el-card>
                        </el-col>
                    </el-row>
                </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
        return {
            dialogVisible: false
        };
    },
    methods: {
        open() {
            this.dialogVisible = true;
        },
        handleSelect(type) {
            if (type === "advance") {
                this.$router.push({
                    path: "/advancePaymentChoose"
                });
            } else if (type === "progress") {
                this.$router.push({
                    path: "/progressPaymentChoose"
                });
            }
        }
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-col {
    // ie 兼容固定高度
    height: 85px;
}

.ignore {
    cursor: not-allowed;
    color: #c0c4cc;
}

.dialog {
    line-height: 25px;
}

.card-content {
    padding: 20px 80px;
}

.card-item {
    height: 80px;
    margin-bottom: 10px;
    font-size: 16px;
    font-weight: bold;
    cursor: pointer;

    .image {
        vertical-align: middle;
    }
    span {
        vertical-align: middle;
        margin-left: 10px;
    }
}
</style>
