<template>
  <div style="margin-bottom: 120px;">
    <div class="box_type" v-if="activeNode>=6">询标阶段需要重新提交的文件请在对应的回复询标函中提交，回复提交后，重新提交的文件会在【投标】页面里对应的替换更新。</div>
    <div v-show="stepNum==0" style="position: relative">
      <el-form class="form" ref="formEnclosure" :model="formEnclosure" :rules="rules" label-width="170px" size="small">
        <el-button class="btn" type="primary" @click="getSystemOperationManual()">下载操作指引</el-button>
        <div class="order-info-title">技术标</div>
        <div class="content">
          <!-- <el-row>
            <el-col :span="24" class="enclosure">
              <el-form-item class="upload" style="color: #000;" label="甲供直采招标技术要求" label-width="268px" prop="skillsRequirement">
                <input ref="skillsRequirement" type="file" @change="handleUpload($event,'24',formEnclosure.skillsRequirement)">
                <label style="position:absolute;" v-if="activeNode<=5 && !hiddenUploadFlg" class="hand blue f12" @click.stop="openUnLoad('skillsRequirement',true)">上传</label>
                <div class="grey f12 tip-text">根据招标文件提供的技术标文件资料，完善相关内容，并上传加盖公司公章的《甲供直采招标技术要求》，扫描件以PDF格式上传。</div>
                <div class="enclosure-content has-text" v-if="formEnclosure.skillsRequirement.length">
                  <div v-for="(item,index) in formEnclosure.skillsRequirement" :key="index+'a'">
                    <span>{{item.attachName}}</span>
                    <span class="hand blue" @click="handleView(item.attachUrl)">预览</span>
                    <span class="hand blue" @click="handleDownload(item.attachUrl,item.attachName)">下载</span>
                    <span class="hand blue" v-if="activeNode<=5 && !hiddenUploadFlg && (submitBidStatus=='0' || (submitBidStatus=='1' && formEnclosure.skillsRequirement.length >1))" @click="delFiles(formEnclosure.skillsRequirement,index,'0','24')">删除</span>
                  </div>
                </div>
                <div v-else class="grey enclosure-content has-text">
                  未上传附件！
                </div>
              </el-form-item>
            </el-col>
          </el-row> -->
          <el-row>
            <el-col :span="24" class="enclosure">
              <el-form-item class="upload" style="color: #000;" label="甲供直采招标设备技术偏离表" label-width="268px" prop="technicalDeviation">
                <input ref="technicalDeviation" type="file" @change="handleUpload($event,'25',formEnclosure.technicalDeviation)">
                <label style="position:absolute;" v-if="activeNode<=5 && !hiddenUploadFlg" class="hand blue f12" @click.stop="openUnLoad('technicalDeviation',true)">上传</label>
                <div class="grey f12 tip-text">根据招标文件提供的技术标文件资料，完善相关内容，并上传加盖公司公章的《甲供直采招标设备技术偏离表》，扫描件以PDF格式上传。</div>
                <div class="enclosure-content has-text" v-if="formEnclosure.technicalDeviation.length">
                  <div v-for="(item,index) in formEnclosure.technicalDeviation" :key="index+'b'">
                    <span>{{item.attachName}}</span>
                    <span class="hand blue" @click="handleView(item.attachUrl)">预览</span>
                    <span class="hand blue" @click="handleDownload(item.attachUrl,item.attachName)">下载</span>
                    <span class="hand blue" v-if="activeNode<=5 && !hiddenUploadFlg && (submitBidStatus=='0' || (submitBidStatus=='1' && formEnclosure.technicalDeviation.length >1))" @click="delFiles(formEnclosure.technicalDeviation,index,'0','25')">删除</span>
                  </div>
                </div>
                <div v-else class="grey enclosure-content has-text">
                  未上传附件！
                </div>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
        <div class="order-info-title">商务标</div>
        <div class="content" style="padding-bottom: 10px; border-bottom: 1px dashed #eee;">
          <el-row style="margin-bottom:0px">
            <el-col :span="24" class="enclosure">
              <el-form-item class="upload" style="color: #000;" label="报价清单" label-width="268px" prop="quotationList">
                <input ref="quotationList" type="file" @change="handleUpload($event,'26',formEnclosure.quotationList)">
                <label style="position:absolute;" v-if="activeNode<=5 && !hiddenUploadFlg" class="hand blue f12" @click.stop="openUnLoad('quotationList',false,'26')">上传</label>
                <div class="grey f12 tip-text">根据招标文件提供的报价清单模板，完善相关内容上传，格式为xlsx。</div>
                <div class="enclosure-content has-text" v-if="formEnclosure.quotationList.length">
                  <div v-for="(item,index) in formEnclosure.quotationList" :key="index+'c'">
                    <span>{{item.attachName}}</span>
                    <span class="hand blue" @click="handleView(item.attachUrl)">预览</span>
                    <span class="hand blue" @click="handleDownload(item.attachUrl,item.attachName)">下载</span>
                    <span class="hand blue" v-if="activeNode<=5 && !hiddenUploadFlg && submitBidStatus=='0'" @click="delFiles(formEnclosure.quotationList,index,'0')">删除</span>
                  </div>
                </div>
                <div v-else class="grey enclosure-content has-text">
                  未上传附件！
                </div>
              </el-form-item>
            </el-col>
          </el-row>
          <div style="margin: 10px 0 20px 0;" class="mockList" v-if="activeNode <= 5 && !hiddenUploadFlg && submitBidStatus == '0' && inventoryFlag != '0'">
            <div v-if="mockEntryStatus != '0' && isSupplyPicture == '1' && !isReset" class="f14 hand" @click="handleSubmit('0',1);isFromPage=true">设置/查看商品图</div>
            <div v-if="mockEntryStatus != '0' && mockProdCntList.length && !isReset" class="f14 hand" @click="handleSubmit('0',2);isFromPage=true">设置/查看模拟清单</div>
          </div>
          <div style="margin: 10px 0 20px 0;" class="mockList" v-else>
            <div v-if="activeNode<=5 && !hiddenUploadFlg && isSupplyPicture == '1' && inventoryFlag != '0'" class="f14 hand" @click="handleSubmit('0',1);isFromPage=true">设置商品图</div>
            <div v-if="(activeNode>5 || hiddenUploadFlg) && isSupplyPicture == '1' && inventoryFlag != '0'" class="f14 hand" @click="goViewProImg">查看商品图</div>
            <div v-if="activeNode<=5 && !hiddenUploadFlg && mockProdCntList.length && inventoryFlag != '0'" class="f14 hand" @click="handleSubmit('0',2);isFromPage=true">设置模拟清单</div>
            <div v-if="(activeNode>5 || hiddenUploadFlg) && mockProdCntList.length && inventoryFlag != '0'" class="f14 hand" @click="goViewMockList">查看模拟清单</div>
          </div>
          <el-row>
            <el-col :span="24" class="enclosure">
              <el-form-item class="upload" style="color: #000;" label="报价清单PDF版" label-width="268px" prop="quotationPDFList">
                <input ref="quotationPDFList" type="file" @change="handleUpload($event,'44',formEnclosure.quotationPDFList)">
                <label style="position:absolute;" v-if="activeNode<=5 && !hiddenUploadFlg" class="hand blue f12" @click.stop="openUnLoad('quotationPDFList')">上传</label>
                <div class="grey f12 tip-text">根据报价清单，将该清单线下打印并加盖公司公章，扫描PDF格式上传。<i class="red">请确保报价清单PDF版的内容与您上传的报价清单xlsx版的内容是一致的，否则您本次的投标将被视为作废。</i></div>
                <div class="enclosure-content has-text" v-if="formEnclosure.quotationPDFList.length">
                  <div v-for="(item,index) in formEnclosure.quotationPDFList" :key="index+'c'">
                    <span>{{item.attachName}}</span>
                    <span class="hand blue" @click="handleView(item.attachUrl)">预览</span>
                    <span class="hand blue" @click="handleDownload(item.attachUrl,item.attachName)">下载</span>
                    <span class="hand blue" v-if="activeNode<=5 && !hiddenUploadFlg && submitBidStatus=='0'" @click="delFiles(formEnclosure.quotationPDFList,index,'0')">删除</span>
                  </div>
                </div>
                <div v-else class="grey enclosure-content has-text">
                  未上传附件！
                </div>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
        <div class="content" style="margin-top: 20px;border-bottom: 1px dashed #eee;">
          <el-row>
            <el-col :span="24" class="enclosure">
              <el-form-item class="upload" style="color: #000;" label="投标文件(基本版)" label-width="268px" prop="biddingDocuments">
                <input ref="biddingDocuments" type="file" @change="handleUpload($event,'28',formEnclosure.biddingDocuments)">
                <label style="position:absolute;" v-if="activeNode<=5 && !hiddenUploadFlg" class="hand blue f12" @click.stop="openUnLoad('biddingDocuments')">上传</label>
                <div class="grey f12 tip-text">根据招标文件提供的商务标《招标文件（基本版）》文件资料，完善相关内容，并上传加盖公司公章的《招标文件（基本版）》，扫描件以PDF格式上传。<br>该文件含：承诺表、全国业务代表人证明书、材料设备供应商厂家基本情况表、指定经销商或代理商名录。</div>
                <div class="enclosure-content has-text" v-if="formEnclosure.biddingDocuments.length">
                  <div v-for="(item,index) in formEnclosure.biddingDocuments" :key="index+'e'">
                    <span>{{item.attachName}}</span>
                    <span class="hand blue" @click="handleView(item.attachUrl)">预览</span>
                    <span class="hand blue" @click="handleDownload(item.attachUrl,item.attachName)">下载</span>
                    <span class="hand blue" v-if="activeNode<=5 && !hiddenUploadFlg && submitBidStatus=='0'" @click="delFiles(formEnclosure.biddingDocuments,index,'0')">删除</span>
                  </div>
                </div>
                <div v-else class="grey enclosure-content has-text">
                  未上传附件！
                </div>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24" class="enclosure">
              <el-form-item class="upload" style="color: #000;" label="投标文件(专业版)" label-width="268px" prop="biddingDocumentsSpecialty">
                <input ref="biddingDocumentsSpecialty" type="file" @change="handleUpload($event,'29',formEnclosure.biddingDocumentsSpecialty)">
                <label style="position:absolute;" v-if="activeNode<=5 && !hiddenUploadFlg" class="hand blue f12" @click.stop="openUnLoad('biddingDocumentsSpecialty')">上传</label>
                <div class="grey f12 tip-text">根据招标文件提供的商务标《招标文件（专业版）》文件资料，完善相关内容，并上传加盖公司公章的《招标文件（专业版）》，扫描件以PDF格式上传。</div>
                <div class="enclosure-content has-text" v-if="formEnclosure.biddingDocumentsSpecialty.length">
                  <div v-for="(item,index) in formEnclosure.biddingDocumentsSpecialty" :key="index+'f'">
                    <span>{{item.attachName}}</span>
                    <span class="hand blue" @click="handleView(item.attachUrl)">预览</span>
                    <span class="hand blue" @click="handleDownload(item.attachUrl,item.attachName)">下载</span>
                    <span class="hand blue" v-if="activeNode<=5 && !hiddenUploadFlg && submitBidStatus=='0'" @click="delFiles(formEnclosure.biddingDocumentsSpecialty,index,'0')">删除</span>
                  </div>
                </div>
                <div v-else class="grey enclosure-content has-text">
                  未上传附件！
                </div>
              </el-form-item>
            </el-col>
          </el-row>
        </div>
        <div class="content" style="margin-top: 20px;border-bottom: 1px solid #eee;">
          <el-row>
            <el-col :span="24" class="enclosure">
              <el-form-item class="upload" style="color: #000;" label="针对绿地各地分公司联系人" label-width="268px" prop="companyContacts">
                <input ref="companyContacts" type="file" @change="handleUpload($event,'30',formEnclosure.companyContacts)">
                <label style="position:absolute;" v-if="activeNode<=5 && !hiddenUploadFlg" class="hand blue f12" @click.stop="openUnLoad('companyContacts')">上传</label>
                <div class="grey f12 tip-text">根据招标文件提供的商务标《针对绿地各地分公司联系人》文件资料，完善相关内容，并上传加盖公司公章的《招针对绿地各地分公司联系人》，扫描件以PDF格式上传。</div>
                <div class="enclosure-content has-text" v-if="formEnclosure.companyContacts.length">
                  <div v-for="(item,index) in formEnclosure.companyContacts" :key="index+'g'">
                    <span>{{item.attachName}}</span>
                    <span class="hand blue" @click="handleView(item.attachUrl)">预览</span>
                    <span class="hand blue" @click="handleDownload(item.attachUrl,item.attachName)">下载</span>
                    <span class="hand blue" v-if="activeNode<=5 && !hiddenUploadFlg && submitBidStatus=='0'" @click="delFiles(formEnclosure.companyContacts,index,'0')">删除</span>
                  </div>
                </div>
                <div v-else class="grey enclosure-content has-text">
                  未上传附件！
                </div>
              </el-form-item>
            </el-col>
          </el-row>
          <!-- <el-row>
          <el-col :span="24" class="enclosure">
            <el-form-item class="upload" style="color: #000;" label="送样清单" label-width="268px" prop="sampleList">
              <input ref="sampleList" type="file" @change="handleUpload($event,'31',formEnclosure.sampleList)">
              <label style="position:absolute;" v-if="activeNode<=5 && !hiddenUploadFlg" class="hand blue f12" @click.stop="openUnLoad('sampleList')">上传</label>
              <div class="grey f12 tip-text">根据招标文件提供的资料对应上传，格式为xlsx文档。</div>
              <div class="enclosure-content has-text" v-if="formEnclosure.sampleList.length">
                <div v-for="(item,index) in formEnclosure.sampleList" :key="index+'h'">
                  <span>{{item.attachName}}</span>
                  <span class="hand blue" @click="handleView(item.attachUrl)">预览</span>
                  <span class="hand blue" @click="handleDownload(item.attachUrl,item.attachName)">下载</span>
                  <span class="hand blue" v-if="activeNode<=5 && !hiddenUploadFlg && submitBidStatus=='0'" @click="delFiles(formEnclosure.sampleList,index,'0')">删除</span>
                </div>
              </div>
              <div v-else class="grey enclosure-content has-text">
                未上传附件！
              </div>
            </el-form-item>
          </el-col>
        </el-row> -->
        </div>
        <div class="order-info-title">其他附件</div>
        <el-row>
          <el-col :span="24" class="enclosure">
            <el-form-item class="upload" style="color: #000;" label="其他附件" label-width="268px">
              <input ref="others" type="file" @change="handleUpload($event,'32',formEnclosure.othersList)">
              <label style="position:absolute;" v-if="activeNode<=5 && !hiddenUploadFlg" class="hand blue f12" @click.stop="openUnLoad('others',true)">上传</label>
              <div class="enclosure-content" v-if="formEnclosure.othersList.length">
                <div v-for="(item,index) in formEnclosure.othersList" :key="index+'i'">
                  <span>{{item.attachName}}</span>
                  <span class="hand blue" @click="handleView(item.attachUrl)">预览</span>
                  <span class="hand blue" @click="handleDownload(item.attachUrl,item.attachName)">下载</span>
                  <span class="hand blue" v-if="activeNode<=5 && !hiddenUploadFlg" @click="delFiles(formEnclosure.othersList,index,'0','32')">删除</span>
                </div>
              </div>
              <div v-else class="grey enclosure-content">
                未上传附件！
              </div>
            </el-form-item>
          </el-col>
        </el-row>
      </el-form>
      <FixBottom v-if="activeNode<=5 && !hiddenUploadFlg && submitBidStatus=='0'">
        <div class="fix-bottom tc" v-if="(((isSupplyPicture == '1' && spuAttachListStatus != '1') || (mockProdCntList.length && mockEntryStatus == '0')) || isReset) && inventoryFlag != '0'">
          <el-button type="primary" @click="step()">下一步</el-button>
          <el-button @click="handleSubmit('0')">保存</el-button>
        </div>

        <div class="fix-bottom tc" v-else>
          <el-button type="primary" @click="handleSubmit('1')">确认投标</el-button>
          <el-button @click="handleSubmit('0')">保存</el-button>
        </div>
      </FixBottom>
      <div v-else>
        <FixBottom v-if="(isReset || spuAttachListStatus != '1') && inventoryFlag != '0'">
          <div class="fix-bottom tc">
            <el-button type="primary" @click="step()">下一步</el-button>
            <el-button @click="handleSubmit('0')">保存</el-button>
          </div>
        </FixBottom>
        <div v-else class="butDownload hand" @click="packageDownload">打包下载投标附件</div>
      </div>
    </div>
    <!-- 完善商品图 -->
    <PerfectProImg ref="perfectProImg" v-if="stepNum==1" :submitBidNo="submitBidNo" :bidNo="bidNo" @UpdateStep="UpdateStep"></PerfectProImg>
    <!-- 模拟清单 -->
    <SetMockList v-if="stepNum==2" :mockList="mockProdCntList" :submitBidNo="submitBidNo" :bidNo="bidNo" @updateData="supplierBiddingDetail" @UpdateStep="UpdateStep"></SetMockList>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import { viewFile } from '@/utils/orderUtil';
import FixBottom from "@/components/base/FixBottom";
import SetMockList from "@/components/order/biddingManagement/SupplierBidding/setMockList";
import PerfectProImg from "@/components/order/biddingManagement/SupplierBidding/perfectProImg";
export default {
  name: "SupplierBidding",
  props: ["activeNode", "bidName", "hiddenUploadFlg", "isSupplyPicture"],
  components: {
    Loading,
    FixBottom,
    SetMockList,
    PerfectProImg
  },
  data() {
    return {
      isLoading: false,

      inventoryFlag: '',// 是否需要招标模板清单（1-是，0-否）

      submitBidNo: '',
      bidNo: '',
      isReset: false,// 重新上传报价清单后是否 重新设置模拟清单与完善商品图
      stepNum: 0, // 0:投标 1:完善商品图 2:模拟清单
      submitBidStatus: '0', //投标状态
      formEnclosure: {
        // skillsRequirement: [],
        technicalDeviation: [],
        quotationList: [],
        quotationPDFList: [],
        // biddingGoods: [],
        biddingDocuments: [],
        biddingDocumentsSpecialty: [],
        companyContacts: [],
        // sampleList: [],
        othersList: [],
      },
      delFileList: [],
      rules: {
        // skillsRequirement: [{
        //   required: true,
        //   message: "必填",
        //   trigger: "blur"
        // }],
        technicalDeviation: [{
          required: true,
          message: "必填",
          trigger: "change"
        }],
        quotationList: [{
          required: true,
          message: "必填",
          trigger: "change"
        }],
        quotationPDFList: [{
          required: true,
          message: "必填",
          trigger: "change"
        }],
        // biddingGoods: [{
        //   required: true,
        //   message: "必填",
        //   trigger: "change"
        // }],
        biddingDocuments: [{
          required: true,
          message: "必填",
          trigger: "change"
        }],
        biddingDocumentsSpecialty: [{
          required: true,
          message: "必填",
          trigger: "change"
        }],
        companyContacts: [{
          required: true,
          message: "必填",
          trigger: "change"
        }],
        // sampleList: [{
        //   required: true,
        //   message: "必填",
        //   trigger: "change"
        // }],
      },
      isFromPage: false,
      mockEntryStatus: '0',//模拟清单商品添加状态（0：未添加商品；1：添加部分商品；2：完成商品添加）
      mockProdCntList: [],//mockProdCntList为空时表示发标没有勾选模拟清单
      spuAttachListStatus: '',//是否上传完商品图 1: 已上传
      // spuAttachListStatus: false,//是否上传完商品图 spuAttachList( pictureIsFlag='1',attachId不为空,商品图上传完成)
    }
  },
  methods: {
    getSystemOperationManual() {
      InterfaceService.getSystemOperationManual(data => {
        if (typeof data === 'string') {
          this.handleDownload(data + '/djc/statics/operationManual/supplier/绿地大家采电商平台供应商系统操作手册V1.pdf', '绿地大家采电商平台供应商系统操作手册V1.pdf')
        }
      });
    },
    goViewMockList() {
      this.$setRootScope('mockList', JSON.stringify(this.mockProdCntList))
      window.open(this.$router.resolve({
        path: "/viewMockList_s",
        query: {
          // bidName: this.bidName,
          bidNo: this.bidNo,
          submitBidNo: this.submitBidNo,
          type: this.$route.query.type || '',
          tab: '1'
        }
      }).href, '_blank')
    },
    goViewProImg() {
      window.open(this.$router.resolve({
        path: "/viewProImg",
        query: {
          // bidName: this.bidName,
          bidNo: this.bidNo,
          submitBidNo: this.submitBidNo,
          type: this.$route.query.type || '',
          tab: '1'
        }
      }).href, '_blank')
    },
    // 下一步
    step() {
      this.$refs['formEnclosure'].validate((valid) => {
        if (valid) {
          if (this.isSupplyPicture == '1') {
            this.handleSubmit('0', 1)
          } else if (this.isSupplyPicture == '0' && this.mockProdCntList.length) {
            this.handleSubmit('0', 2)
          }
        } else {
          return this.$message.error('您还有未上传的文件！')
        }
      });
    },
    // 更新步数
    UpdateStep(list) {
      // console.log(this.activeNode, this.hiddenUploadFlg)
      // 模拟清单
      if (list[0] == 'setMockList') {
        if (list[1] == 'on' && this.isSupplyPicture == '1' && !this.isFromPage) {
          this.stepNum = 1
          this.$nextTick(() => {
            this.$refs.perfectProImg.prodListType = '2'
            this.$refs.perfectProImg.init('on')
          })
        } else {
          this.stepNum = 0
          this.supplierBiddingDetail()
          this.isFromPage = false
        }
      } else {
        if (list[1] == 'under' && this.mockProdCntList.length && !this.isFromPage) {
          this.stepNum = 2
        } else {
          this.stepNum = 0
          this.supplierBiddingDetail()
          this.isFromPage = false
        }
      }
    },
    perfectProImg() {
      this.$nextTick(() => {
        this.$refs.perfectProImg.init()
      })
    },
    // 投标
    handleSubmit(type, stepNum) {
      if (type == '1') {
        this.$refs['formEnclosure'].validate((valid) => {
          if (valid) {
            let title = ''
            let content = ''
            let a = this.mockProdCntList.some(i => i.mockProdCnt != i.supplierMockPordCnt)
            if (this.mockProdCntList.length && a) {
              title = '你有未添加的商品'
              content = '模拟清单有未添加的商品，请检查，若点击【确认提交】，未添加的商品，视作自动放弃。'
            } else {
              title = '投标'
              content = '确认已完善并上传投标所需资料，确认无误请点击【确认提交】按钮即可？'
            }
            this.$confirm(
              content,
              title,
              {
                cancelButtonClass: "btn-custom-cancel",
                confirmButtonClass: "btn-custom-confirm",
                center: true,
                confirmButtonText: "确认提交",
                cancelButtonText: '取消',
              }).then(() => {
                this.supplierBidding(type, stepNum)
              }).catch(() => {

              });
          } else {
            console.log('error submit!!');
            return false
          }
        });
      } else {
        this.supplierBidding(type, stepNum)
      }
    },
    // 上传覆盖
    openUnLoad(item, isMultiple, type) {
      if (this.submitBidStatus == '1') {
        if (type == '26') {
          this.$confirm(
            '是否直接替换报价清单？替换后，模拟清单和商品图需重新设置，报价清单PDF版重新上传。',
            "是否替换报价清单",
            {
              cancelButtonClass: "btn-custom-cancel",
              confirmButtonClass: "btn-custom-confirm",
              center: true,
              confirmButtonText: "直接替换",
              cancelButtonText: '取消',
            }).then(() => {
              this.$refs[item].click()
            }).catch(() => {

            });
        } else {
          this.$confirm(
            isMultiple ? '是否直接上传投标文件，点击【上传】按钮，即直接提交投标文件？' : "是否直接覆盖未已投标文件，点击【直接覆盖】按钮，即直接提交替换原投标文件？",
            "投标",
            {
              cancelButtonClass: "btn-custom-cancel",
              confirmButtonClass: "btn-custom-confirm",
              center: true,
              confirmButtonText: isMultiple ? "上传" : "直接覆盖",
              cancelButtonText: '取消',
            }).then(() => {
              this.$refs[item].click()
            }).catch(() => {

            });
        }
      } else {
        this.$refs[item].click()
      }

    },
    supplierBidding(type, stepNum) {
      // let list = [...this.formEnclosure.skillsRequirement, ...this.formEnclosure.technicalDeviation, ...this.formEnclosure.quotationList, ...this.formEnclosure.biddingGoods, ...this.formEnclosure.biddingDocuments, ...this.formEnclosure.biddingDocumentsSpecialty, ...this.formEnclosure.companyContacts, ...this.formEnclosure.sampleList, ...this.formEnclosure.othersList]
      let list = [...this.formEnclosure.technicalDeviation, ...this.formEnclosure.quotationList, ...this.formEnclosure.quotationPDFList, ...this.formEnclosure.biddingDocuments, ...this.formEnclosure.biddingDocumentsSpecialty, ...this.formEnclosure.companyContacts, ...this.formEnclosure.othersList]
      let submitBidAttachInfo = []
      list.forEach(i => {
        if (!i.ossFileId && i.attachPath) {
          delete i.attachUrl
          submitBidAttachInfo.push(i)
        }
      });
      submitBidAttachInfo = submitBidAttachInfo.concat(this.delFileList)
      let param = {
        submitBidNo: this.submitBidNo, //	投标编号				
        bidNo: this.bidNo, //	投标编号				
        submitBidAttachInfo: submitBidAttachInfo, //	招标文件				
        handleType: type, // "0"：保存；"1"：发布
      }
      InterfaceService.supplierBidding(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success(type == '0' ? '保存成功' : '发布成功')
          this.supplierBiddingDetail()
          if (stepNum) {
            this.stepNum = stepNum
            this.isReset = false
            if (stepNum == 1) this.perfectProImg()
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 投标详情详情
    supplierBiddingDetail() {
      let param = {
        submitBidNo: this.submitBidNo, //	投标编号				
      }
      InterfaceService.supplierBiddingDetail(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.inventoryFlag = data.respData.inventoryFlag || '0'
          this.mockEntryStatus = data.respData.mockEntryStatus || '0'
          this.mockProdCntList = data.respData.mockProdCntList || []
          let spuAttachList = data.respData.spuAttachList || []
          this.spuAttachListStatus = data.respData.spuAttachFlg || ''
          // if (!spuAttachList.length || this.isSupplyPicture == '0') {
          //   this.spuAttachListStatus = false
          // } else {
          //   this.spuAttachListStatus = spuAttachList.some(i => i.pictureIsFlag == '1' && !i.attachId)
          // }
          this.delFileList = []
          this.submitBidStatus = data.respData.submitBidStatus == 'BIDDED' ? '1' : '0'

          let ossFileInfoList = data.respData.ossFileInfoList || []
          this.formEnclosure = {
            // skillsRequirement: [],
            technicalDeviation: [],
            quotationList: [],
            quotationPDFList: [],
            // biddingGoods: [],
            biddingDocuments: [],
            biddingDocumentsSpecialty: [],
            companyContacts: [],
            // sampleList: [],
            othersList: [],
          }
          if (ossFileInfoList.length) {
            ossFileInfoList.forEach(i => {
              switch (i.attachType) {
                // case '24':
                //   this.formEnclosure.skillsRequirement.push(i)
                //   break;
                case '25':
                  this.formEnclosure.technicalDeviation.push(i)
                  break;
                case '26':
                  this.formEnclosure.quotationList.push(i)
                  break;
                case '44':
                  this.formEnclosure.quotationPDFList.push(i)
                  break;
                // case '27':
                //   this.formEnclosure.biddingGoods.push(i)
                //   break;
                case '28':
                  this.formEnclosure.biddingDocuments.push(i)
                  break;
                case '29':
                  this.formEnclosure.biddingDocumentsSpecialty.push(i)
                  break;
                case '30':
                  this.formEnclosure.companyContacts.push(i)
                  break;
                // case '31':
                //   this.formEnclosure.sampleList.push(i)
                //   break;
                case '32':
                  this.formEnclosure.othersList.push(i)
                  break;
                default:
                  break;
              }
            })
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    // 下载
    handleDownload(url, name) {
      let attach = [];
      attach.push({
        url: url,
        name: name
      });
      this.$download(attach).then(res => {
        this.$message.success("已下载");
      }).catch(res => {
        this.$message.error("下载失败");
      })
    },
    // 删除附件
    delFiles(list, index, type, isRefresh) {
      // if (this.submitBidStatus == '1' && (isRefresh == '24' || isRefresh == '25' || isRefresh == '32')) {
      if (this.submitBidStatus == '1' && (isRefresh == '25' || isRefresh == '32')) {
        this.$confirm(
          "是否删除文件？",
          "删除",
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            confirmButtonText: "确定删除",
            cancelButtonText: '取消',
          }).then(() => {
            if (list[index].ossFileId) {
              this.delFileList.push({ 'ossFileId': list[index].ossFileId, 'attachType': list[index].attachType })
            }
            list.splice(index, 1)
            this.supplierBidding('1')
          }).catch(() => {

          });
      } else {
        if (list[index].ossFileId) {
          this.delFileList.push({ 'ossFileId': list[index].ossFileId, 'attachType': list[index].attachType })
        }
        list.splice(index, 1)
        type == '0' ? this.$message.success('已删除') : ''
      }
    },
    // 上传附件
    handleUpload(e, type, form) {
      console.log(e)
      const file = e.target.files[0];
      if (file) {
        let a = file.name.split(".")
        const fileType = a[a.length - 1];
        if (type == '26' && this.inventoryFlag != '0') {
          const reg = /(xlsx|XLSX)/i;
          if (!reg.test(fileType)) {
            this.$message.error("请上传xlsx格式文件");
            return;
          }
        } else {
          if (type != '32' && type != '26') {
            const reg = /(pdf|PDF)/i;
            if (!reg.test(fileType)) {
              this.$message.error("请上传PDF格式文件");
              return;
            }
          }
          // if (file.size > 20971520) {
          //   this.$message.error("单个附件大小不超过20MB");
          //   return;
          // }
        }
        if (file) {
          this.uploadContractToOss(type, file).then(res => {
            let param = {
              ossFile: [{
                fileType: type, filePath: res.url
              }],
              appName: "PROD"
            };
            InterfaceService.ossSignatureUrl(param, data => {
              if (data && data.respData && data.respData.respCode === "0000") {
                let ossFile = data.respData.ossFile || [];
                let obj = {
                  attachType: type,
                  attachName: file.name,
                  attachPath: res.url,
                  attachUrl: ossFile[0].url,
                }
                if (ossFile.length) {
                  switch (type) {
                    // case '24':
                    //   if (this.formEnclosure.skillsRequirement.length) {
                    //     this.delFiles(this.formEnclosure.skillsRequirement, 0, '1')
                    //     this.formEnclosure.skillsRequirement.push(obj)
                    //   } else {
                    //     this.formEnclosure.skillsRequirement.push(obj)
                    //   }
                    //   this.$refs.formEnclosure.clearValidate('skillsRequirement')
                    //   break;
                    case '25':
                      if (this.formEnclosure.technicalDeviation.length) {
                        this.delFiles(this.formEnclosure.technicalDeviation, 0, '1')
                        this.formEnclosure.technicalDeviation.push(obj)
                      } else {
                        this.formEnclosure.technicalDeviation.push(obj)
                      }
                      this.$refs.formEnclosure.clearValidate('technicalDeviation')
                      break;
                    case '26':
                      if (this.formEnclosure.quotationList.length) {
                        this.delFiles(this.formEnclosure.quotationList, 0, '1')
                        // 重新上传报价清单,底部按钮重置为下一步
                        if (this.delFileList.some(j => j.attachType == '26') && (this.isSupplyPicture == '1' || this.mockProdCntList.length)) {
                          if (this.isSupplyPicture == '1') {
                            this.$message(this.mockProdCntList.length ? '您已更换报价清单,请重新完善商品图和设置模拟清单' : '您已更换报价清单,请重新完善商品图')
                          } else {
                            this.$message('您已更换报价清单,请重新设置模拟清单')
                          }
                          this.isReset = true
                        }
                        this.formEnclosure.quotationList.push(obj)
                      } else {
                        // 重新上传报价清单,底部按钮重置为下一步
                        if (this.delFileList.some(j => j.attachType == '26') && (this.isSupplyPicture == '1' || this.mockProdCntList.length)) {
                          if (this.isSupplyPicture == '1') {
                            this.$message(this.mockProdCntList.length ? '您已更换报价清单,请重新完善商品图和设置模拟清单' : '您已更换报价清单,请重新完善商品图')
                          } else {
                            this.$message('您已更换报价清单,请重新设置模拟清单')
                          }
                          this.isReset = true
                        }
                        this.formEnclosure.quotationList.push(obj)
                      }
                      if (this.formEnclosure.quotationPDFList.length) {
                        this.delFiles(this.formEnclosure.quotationPDFList, 0, '1')
                      }
                      this.$refs.formEnclosure.clearValidate('quotationList')
                      break;
                    case '44':
                      if (this.formEnclosure.quotationPDFList.length) {
                        this.delFiles(this.formEnclosure.quotationPDFList, 0, '1')
                        this.formEnclosure.quotationPDFList.push(obj)
                      } else {
                        this.formEnclosure.quotationPDFList.push(obj)
                      }
                      this.$refs.formEnclosure.clearValidate('quotationPDFList')
                      break;
                    // case '27':
                    //   if (this.formEnclosure.biddingGoods.length) {
                    //     this.delFiles(this.formEnclosure.biddingGoods, 0, '1')
                    //     this.formEnclosure.biddingGoods.push(obj)
                    //   } else {
                    //     this.formEnclosure.biddingGoods.push(obj)
                    //   }
                    //   this.$refs.formEnclosure.clearValidate('biddingGoods')
                    //   break;
                    case '28':
                      if (this.formEnclosure.biddingDocuments.length) {
                        this.delFiles(this.formEnclosure.biddingDocuments, 0, '1')
                        this.formEnclosure.biddingDocuments.push(obj)
                      } else {
                        this.formEnclosure.biddingDocuments.push(obj)
                      }
                      this.$refs.formEnclosure.clearValidate('biddingDocuments')
                      break;
                    case '29':
                      if (this.formEnclosure.biddingDocumentsSpecialty.length) {
                        this.delFiles(this.formEnclosure.biddingDocumentsSpecialty, 0, '1')
                        this.formEnclosure.biddingDocumentsSpecialty.push(obj)
                      } else {
                        this.formEnclosure.biddingDocumentsSpecialty.push(obj)
                      }
                      this.$refs.formEnclosure.clearValidate('biddingDocumentsSpecialty')
                      break;
                    case '30':
                      if (this.formEnclosure.companyContacts.length) {
                        this.delFiles(this.formEnclosure.companyContacts, 0, '1')
                        this.formEnclosure.companyContacts.push(obj)
                      } else {
                        this.formEnclosure.companyContacts.push(obj)
                      }
                      this.$refs.formEnclosure.clearValidate('companyContacts')
                      break;
                    // case '31':
                    //   if (this.formEnclosure.sampleList.length) {
                    //     this.delFiles(this.formEnclosure.sampleList, 0, '1')
                    //     this.formEnclosure.sampleList.push(obj)
                    //   } else {
                    //     this.formEnclosure.sampleList.push(obj)
                    //   }
                    //   this.$refs.formEnclosure.clearValidate('sampleList')
                    //   break;
                    case '32':
                      this.formEnclosure.othersList.push(obj)
                      break;
                    default:
                      break;
                  }
                }

                // 已投标过直接上传
                if (this.submitBidStatus == '1') {
                  this.supplierBidding('0')
                }
              } else {
                this.$message.error(data.respData.respMsg)
              }
            }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
          })

        }
        e.target.value = "";
      }
    },
    // 上传OSS
    uploadContractToOss(type, file) {
      return new Promise((resolve, reject) => {
        InterfaceService.getOssSignatureDisposable(file.name, {
          type: type,
          appName: "PROD",
        }, (data) => {
          let signature = data;
          this.uploadHander(0, file, new Date().getTime() + '/', signature, (pos, file, dirType, signature) => {
            // console.log(signature.dir);
            let u = signature.dir + dirType + file.name;
            // console.log(u);
            resolve({ url: u });
          }, () => { this.isLoading = true; }, () => { this.isLoading = false; })
        }, (data) => {
        },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          });
      })

    },
    // 拿签名
    uploadHander(pos, file, dirType, signature, callBack, loadingStartCb, loadingEndCb) {
      //去后端拿签名
      InterfaceService.uploadToOss(signature, file, dirType, pos, callBack, '', '', loadingStartCb, loadingEndCb)
    },
    // 打包下载
    packageDownload() {
      // let list = [...this.formEnclosure.skillsRequirement, ...this.formEnclosure.technicalDeviation, ...this.formEnclosure.quotationList, ...this.formEnclosure.biddingGoods, ...this.formEnclosure.biddingDocuments, ...this.formEnclosure.biddingDocumentsSpecialty, ...this.formEnclosure.companyContacts, ...this.formEnclosure.sampleList, ...this.formEnclosure.othersList]
      let list = [...this.formEnclosure.technicalDeviation, ...this.formEnclosure.quotationList, ...this.formEnclosure.quotationPDFList, ...this.formEnclosure.biddingDocuments, ...this.formEnclosure.biddingDocumentsSpecialty, ...this.formEnclosure.companyContacts, ...this.formEnclosure.othersList]
      let fileInfoBeans = []
      // console.log(list)
      list.forEach((item, index) => {
        // if ((item.attachType == '24' || item.attachType == '25') && item.attachUrl) {
        if (item.attachType == '25' && item.attachUrl) {
          fileInfoBeans.push({
            archivePath: '技术标/' + (item.attachName || ''),
            fileUrl: item.attachUrl,
          })
        } else if (item.attachType == '32' && item.attachUrl) {
          fileInfoBeans.push({
            archivePath: '其他附件/' + (item.attachName || ''),
            fileUrl: item.attachUrl,
          })
        } else if (item.attachUrl) {
          fileInfoBeans.push({
            archivePath: '商务标/' + (item.attachName || ''),
            fileUrl: item.attachUrl,
          })
        }
      })
      if (fileInfoBeans.length == 0) {
        return this.$message.error("暂无投标附件可供下载")
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            // const files = [
            //   // { name: decodeURIComponent(name), url: url }
            //   { name: this.bidName + "投标文件.zip", url: url }
            // ];
            // this.$download(files, () => {this.isLoading = true}, () => {this.isLoading = false}).then(() => {
            //   this.$message.success("已下载");
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: this.bidName + "投标文件.zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
  },
  mounted() {
    this.submitBidNo = this.$route.query.submitBidNo || "";
    this.bidNo = this.$route.query.bidNo || "";
    // console.log(this.submitBidNo)
    this.supplierBiddingDetail()
  }
}
</script>

<style scoped lang="scss">
.btn {
  width: 120px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  padding: 0;
  position: absolute;
  right: 0;
  top: -10px;
}
.box_type {
  width: 100%;
  //   height: 42px;
  background: rgba(255, 252, 240, 1);
  border: 1px solid rgba(250, 226, 165, 1);
  font-size: 12px;
  line-height: 17px;
  color: #444444;
  padding: 11px 10px;
}
/deep/ .el-row {
  overflow: visible;
}
.content {
  padding-bottom: 10px;
  border-bottom: 1px solid #eee;
  line-height: 17px;
}
.mockList {
  width: 100%;
  display: flex;
  > div {
    flex: 1;
    height: 34px;
    background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
    line-height: 34px;
    text-align: center;
    color: #df0a0a;
    font-weight: 600;
    &:nth-child(2) {
      margin-left: 20px;
    }
  }
}
.enclosure {
  /deep/ .el-form-item {
    margin-bottom: 0 !important;
    label {
      width: auto !important;
      line-height: 20px;
      font-size: 14px;
    }
  }
  /deep/ .el-form-item__label {
    color: #444 !important;
    text-align: left;
    width: auto !important;
  }
  /deep/ .el-form-item__content {
    position: relative;
    margin-left: 0 !important;
  }
  /deep/ .el-form-item__error {
    position: absolute;
  }
  .pickPepoleCardUrl {
    /deep/ .el-form-item__error {
      position: absolute;
    }
  }
  .biddingAuthorizationUrl {
    /deep/ .el-form-item__error {
      position: absolute;
    }
  }
  a {
    position: absolute;
  }
  /deep/ .enclosure-content {
    font-size: 12px;
    margin-top: 34px;
    width: 1190px;
    border: 1px solid rgba(221, 221, 221, 1);
    padding: 0 10px;
    // line-height: 45px;
    line-height: 17px;
    padding: 14px 10px;
    > div {
      margin-top: 14px;
      &:first-child {
        margin-top: 0px !important;
      }
    }
    span {
      margin-right: 12px;
    }
  }
  .tip-text {
    margin-top: 26px;
    line-height: 17px;
  }
  .has-text {
    margin-top: 5px;
  }
}

.enclosure-tip {
  width: 100%;
  padding: 0 10px;
  height: 30px;
  background: rgba(255, 252, 240, 1);
  border: 1px solid rgba(250, 226, 165, 1);
  line-height: 30px;
  font-size: 12px;
  margin-bottom: 15px;
}
.detail {
  .el-form-item {
    margin-bottom: 0 !important;
  }
  .el-row {
    margin-bottom: 0;
  }
}
.upload {
  /deep/ .el-input,
  input {
    position: absolute;
    left: -9999px;
    width: 0px;
    height: 0px;
    overflow: hidden;
    opacity: 0;
  }
}
/deep/ .el-input {
  width: 400px;
}
.business-bid {
  position: relative;
  margin-top: 10px;
  width: 100%;
  height: 194px;
  border: 1px solid rgba(250, 226, 165, 1);
  background: rgba(255, 252, 240, 1);
  padding: 12px 0;
  font-size: 12px;
  margin-left: 0 !important;
  margin-right: 0 !important;
  .business-bid-img {
    width: 100%;
    height: 182px;

    background: url("../../../assets/images/bidding/business-bid-tip.png")
      no-repeat left 4px;
  }
  .fold-btn {
    position: absolute;
    right: 10px;
    top: 12px;
  }
}
.butDownload {
  width: 260px;
  height: 50px;
  background: rgba(255, 255, 255, 1);
  border: 1px solid rgba(201, 159, 79, 1);
  font-size: 14px;
  color: rgba(201, 159, 79, 1);
  line-height: 48px;
  margin: 40px auto 0;
  text-align: center;
}
.el-row {
  margin-bottom: 20px;
}
</style>