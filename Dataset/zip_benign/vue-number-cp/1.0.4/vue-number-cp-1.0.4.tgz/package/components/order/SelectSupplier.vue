<template>
  <div>
    <!-- 快速选型采购 - 选择供应商 -->
    <el-dialog class="dialog dialog-drafts quick-purchase-dialog" title="供应商选择" :append-to-body="true" :lock-scroll="true" @close="cancel" :visible.sync="draftsDialogVisible" width="800px" center :close-on-click-modal="false">
      <div class="drafts-list">
        <span>选择供应商</span>
        <el-select v-model="quickPurchaseDialogValue" clearable filterable remote reserve-keyword placeholder="请输入关键词快速搜索选择供应商" :remote-method="remoteQuickPurchaseMethod">
          <el-option v-for="item in quickPurchaseDialogOptions" :key="item.supplierId" :label="item.supplierName" :value="item.supplierId || ''">
          </el-option>
        </el-select>
      </div>

      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 100px" :disabled="!quickPurchaseDialogValue" @click="quickPurchaseConfirm">下一步</el-button>
        <el-button size="small" style="width: 100px" :disabled="!!quickPurchaseDialogValue" @click="handleClickReg">去新增</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from '@/services/api'
import Loading from '@/components/base/Loading'
export default {
  components: {
    Loading
  },
  props: ['value', 'addAgent'],
  data() {
    return {
      isLoading: false,
      quickPurchaseDialogOptions: [],
      quickPurchaseDialogValue: '',
      queryCorpName: '', // 供应商名称
      draftsDialogVisible: this.value || false,
      nextDisabled: true,
    }
  },

  mounted() {
    this.getQuickSelectionSupplier()
  },
  methods: {
    /**
     * 取消
     */
    cancel() {
      this.draftsDialogVisible = false
      this.$emit('input', false)
    },

    /**
     * 快速搜索 - 输入
     */
    remoteQuickPurchaseMethod(query) {
      query.replace(/\s*/g, '').length && this.getQuickSelectionSupplier(query)
    },

    /**
     * 重置-弹窗数据
     */
    resetQuickPurchaseData() {
      this.quickPurchaseDialogValue = ''
      this.quickPurchaseDialogOptions = []
    },
    handleClickReg() {
      window.open(this.$router.resolve({
        path: '/aregister'
      }).href, '_blank')
    },
    /**
     * 快速选型采购 - 确认
     */
    quickPurchaseConfirm() {
      if (!this.quickPurchaseDialogValue) {
        this.$message.error('请选择供应商')
        return
      }
      this.quickPurchaseDialogOptions.some(s => {
        if (s.supplierId === this.quickPurchaseDialogValue) {
          this.queryCorpName = s.supplierName
          return true
        }
      })
      if (!this.addAgent) {
        this.addNewDrafts()
      } else {
        console.log("chazhao");
      }
    },

    /**
     * 新建草稿
     */
    addNewDrafts() {
      this.$setRootScope('forbidBack', 'true')
      this.$setRootScope('newest', true)
      this.$router.push({
        path: "/transfer",
        query: {
          query: JSON.stringify({
            state: 'newList',
            supplierId: this.quickPurchaseDialogValue,
            supplierName: this.queryCorpName
          }), // 打开新清单
          path: '/quickPurchase'
        }
      })
      console.log('tz');

    },

    /**
     * 快速查询 接口
     */
    getQuickSelectionSupplier(supplierName) {
      if (!supplierName) return
      InterfaceService.getQuickSelectionSupplier({ supplierName }, data => {
        if (data.respData.respCode == '0000') {
          this.quickPurchaseDialogOptions = data.respData.supplierList || []
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => {
      }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
  },
}
</script>
<style lang="scss" scoped>
.quick-purchase-dialog {
  .drafts-list {
    display: flex;
    align-items: center;
    & > span {
      width: 80px;
      display: block;
    }
    /deep/ .el-select {
      $topbar-height: 80px;
      width: calc(100% - #{$topbar-height});
      .el-select__input {
        border: 0;
      }
    }
  }
}
</style>

