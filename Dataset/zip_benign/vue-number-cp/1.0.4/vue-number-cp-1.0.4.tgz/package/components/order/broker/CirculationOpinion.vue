<template>
    <div>
        <!-- 取消合同 -->
        <el-dialog class="dialog" title="流转意见" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="60%" center :close-on-click-modal="false">
            <div class="data-content">
                    <div class="data-list">
                        <table>
                            <tbody>
                            <tr style="background: #f6f5f5;">
                                <td width="15%">部门</td>
                                <td width="15%">干系人</td>
                                <td width="15%">操作时间</td>
                                <td width="15%">状态</td>
                                <td width="40%">原因</td>
                            </tr>
                            <tr v-for="(item,index) in execFlowList" :key="index" class="tbody-row">
                                <!--<td width="15%">{{item.department}}</td>-->
                                <td width="15%">{{item.roleName}}</td>
                                <td width="15%">{{item.acctName}}</td>
                                <td width="15%">{{item.finishTm}}</td>
                                <td width="15%">{{item.state}}</td>
                                <td width="40%">{{item.comment}}</td>
                            </tr>
                            </tbody>
                        </table>
                        <el-button size="small" style="width: 120px" @click="dialogVisible = false">关闭</el-button>
                    </div>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    export default {
        name: "circulationOpinion",
        data() {
            return {
                dialogVisible: false,
                execFlowList:[]
            };
        },
        methods:{
            open(execFlowList){
                this.dialogVisible = true;
                this.execFlowList = execFlowList;
                this.execFlowList.forEach(item=>{
                    if (item.taskId == "contract_apply" || item.taskId == "operation_confirm" || item.taskId == "finance_confirm" || item.taskId == "vgm_confirm") {
                        // item.department = "招采合约部";
                        item.isAgree == "Y" ? item.state = "审批通过" : item.state = "审批退回"
                    } else if (item.taskId == "canceled") {
                        // item.department = "招采合约部";
                        item.state = "招采合约部撤回审批";
                    } else if (item.taskId == "closed") {
                        // item.department = "招采合约部";
                        item.state = "招采合约部关闭审批";
                    } else if (item.taskId == "end") {
                        // item.department = "财务部";
                        item.state = "归档";
                    }
                })
            }
        }
    }
</script>

<style scoped lang="scss">
    .data-content{
        .data-list{
            width: 100%;
            overflow: auto;
            margin-bottom: 30px;
            text-align: center;
        }
    }
    table {
        table-layout: fixed;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        display: table;
        margin-bottom: 30px;
        td,th {
            padding: 14px 10px;
            vertical-align: middle;
            word-break: break-word;
            text-align: left;
        }
        .tbody-row{
            /deep/ .el-button{
                height: 20px;
                width: 80px;
                padding: 0;
                margin:0 0 10px;
            }
        }
        .tbody-row:hover {
            background: #e8f3fd;
        }
        tbody {
            text-align: center;
            display: block;
            /*width: 500px;*/
            overflow-y: auto;
            height: 320px;
            tr {
                display: table;
                width: 100%;
                table-layout: fixed;
            }
            td {
                border-bottom: 1px solid #ebeef5;
            }
        }
    }
    /deep/ .el-dialog__body{
        padding-top: 0;
    }
</style>