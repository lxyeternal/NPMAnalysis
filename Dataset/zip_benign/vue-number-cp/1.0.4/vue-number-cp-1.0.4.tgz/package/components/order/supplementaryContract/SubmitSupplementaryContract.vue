<template>
  <transition name="el-zoom-in-bottom">
    <div class="batchSetUseProject" v-show="showBox">
      <div class="confirmContract" ref="confirmContract">
        <div class="content">
          <div class="title tc">{{pageType === '1' ? '确认提交补充合同商品清单' : '确认审核通过'}}</div>
          <div class="center">
            <template v-if="pageType === '1'">
              <p class="f12" v-if="userInfo.supplyType == '0'">请确认补充协议信息及清单内容是否无误，点击【确认并提交】后，等待采购商确认。</p>
              <p class="f12" v-else>请确认补充协议信息及清单内容是否无误，点击【确认并提交】后，等待厂家及采购商确认。</p>
            </template>
            <p v-else class="f12">请确认下载并查阅<span class="blue-pointer" @click="handleDownloadContract('1')">补充协议用印版</span>(待电子用印的PDF版)或<span class="blue-pointer" @click="handleDownloadContract('2')">下载附件</span>(附件为补充协议word版本及商品清单Excel版本)，并确认补充协议中的金额、商品清单及合同条款等重要内容。若无问题，点击【{{pageType === '2' ? '确认通过' : '确认提交OA审核'}}】按钮即可{{pageType === '2' ? '' : '同步发起OA审批'}}。</p>
            <div style="border-bottom: 1px dashed #eee;margin: 20px 0px"></div>
            <div class="order-info-title" style="margin-bottom: 12px !important;">基本信息</div>
            <div class="contractInfo" style="padding-bottom: 4px">
              <el-row>
                <el-col :span="24">
                  <p>
                    <label>补充合同名称：</label>
                    <span v-if=" relContractObj.contractName">{{ divisionContract ? ('《'+ relContractObj.contractName.replace('采购合同','供应合同') + '》') : ('《'+ relContractObj.contractName + '》')}}
                      <DownloadAndView v-if="pdfList.length && role !== 'B'" :format="false" :viewName="'查看补充协议用印版'" :downloadName="'下载补充协议用印版'" :paddingLeft="'6px'" :attachUrl="pdfList[0].attachUrl" :attachName="pdfList[0].documentName"></DownloadAndView>
                      <span v-if="role === 'B'" class="blue-pointer" style="margin-left: 4px" @click="handleDownloadContract('1')">下载补充协议用印版</span>
                      <span class="blue-pointer" @click="handleDownloadContract('2')" style="margin-left: 4px">下载附件</span>
                    </span>
                  </p>
                </el-col>
              </el-row>
              <el-row style="margin-bottom: 6px">
                <el-col :span="12">
                  <p>
                    <label>供应商：</label>{{orderInfo.supplierName}}
                  </p>
                </el-col>
                <el-col :span="12">
                  <p>
                    <label>增补次数：</label>第{{relContractObj.orderCnt}}笔
                  </p>
                </el-col>
              </el-row>
            </div>
            <div style="border-bottom: 1px dashed #eee"></div>
            <div class="order-info-title" style="margin-bottom: 10px !important;">合同价款</div>
            <p class="f14 bold" style="margin-bottom: 10px">原合同价款（含已生效的补充合同价款）</p>
            <div class="contractInfo">
              <el-row>
                <el-col :span="12">
                  <p v-if="divisionContract"><label>合同价款(不含税)：</label>{{Number(orderInfo.allInContractFee) | formatMoney}}元(主合同价款{{Number(orderInfo.inContractFee) | formatMoney}}元+补充合同价款{{Number(orderInfo.replenishInContractFee) | formatMoney}}元)</p>
                  <p v-else>
                    <label>合同价款(不含税)：</label>{{Number(orderInfo.allOutContractFee) | formatMoney}}元(主合同价款{{Number(orderInfo.outContractFee) | formatMoney}}元+补充合同价款{{Number(orderInfo.replenishOutContractFee) | formatMoney}}元)
                  </p>
                </el-col>
                <el-col :span="12">
                  <p>
                    <label>税率：</label>{{orderInfo.orderTaxRateRange}}
                  </p>
                </el-col>
                <el-col :span="12">
                  <p v-if="divisionContract">
                    <label>合同价款(含税)：</label>{{Number(orderInfo.allInContractFeeWithTax) | formatMoney}}元(主合同价款{{Number(orderInfo.inContractFeeWithTax) | formatMoney}}元+补充合同价款{{Number(orderInfo.replenishInContractFeeWithTax) | formatMoney}}元)
                  </p>
                  <p v-else>
                    <label>合同价款(含税)：</label><span class="red"><span class="bold">{{Number(orderInfo.allOutContractFeeWithTax) | formatMoney}}</span>元(主合同价款{{Number(orderInfo.outContractFeeWithTax) | formatMoney}}元+补充合同价款{{Number(orderInfo.replenishOutContractFeeWithTax) | formatMoney}}元)</span>
                  </p>
                </el-col>
                <el-col :span="12">
                  <p v-if="divisionContract">
                    <label>税额：</label>{{Number(orderInfo.allInContractTax) | formatMoney}}元(主合同价款{{Number(orderInfo.inContractTax) | formatMoney}}元+补充合同价款{{Number(orderInfo.replenishInContractTax) | formatMoney}}元)
                  </p>
                  <p v-else>
                    <label>税额：</label>{{Number(orderInfo.allOutContractTax) | formatMoney}}元(主合同税额{{Number(orderInfo.outContractTax) | formatMoney}}元+补充合同税额{{Number(orderInfo.replenishOutContractTax) | formatMoney}}元)
                  </p>
                </el-col>
              </el-row>
            </div>
            <p class="f14 bold" style="margin-bottom: 6px">本补充合同价款</p>
            <div class="introduction-center">
              <ul>
                <li>
                  <span class="grey"> 补充合同价款(不含税)：</span>
                  <span v-if="divisionContract"> {{Number(relContractObj.inContractFee)|formatMoney}} 元 </span>
                  <span v-else> {{Number(relContractObj.outContractFee) | formatMoney}} 元 </span>
                </li>
                <li>
                  <span class="grey"> 税率：</span> <span>{{orderInfo.orderTaxRateRange}}</span>
                </li>
                <li>
                  <span class="grey"> 补充合同价款(含税)：</span>
                  <span v-if="divisionContract" class="bold"> <span class="red">{{Number(relContractObj.inContractFeeWithTax) | formatMoney}}</span> 元 </span>
                  <span v-else class="bold red"> {{Number(relContractObj.outContractFeeWithTax) | formatMoney}} 元 </span>
                </li>
                <li>
                  <span class="grey"> 税额：</span>
                  <span v-if="divisionContract">{{Number(relContractObj.inContractTax) | formatMoney}} 元</span>
                  <span v-else>{{Number(relContractObj.outContractTax) | formatMoney}} 元</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <FixBottom class="bottom">
          <div class="tc">
            <el-button v-if="pageType === '1' " type="primary" @click="confirmSubmit">确认提交</el-button>
            <template v-else>
              <el-button type="primary" @click="confirmSubmit">{{pageType === '2' ? '确认通过' : '确认提交OA审核'}}</el-button>
              <!-- <el-button @click="handleDownloadContract()">下载补充协议模板</el-button> -->
            </template>
            <el-button @click="close">取消</el-button>
          </div>
        </FixBottom>
      </div>
      <Loading :is-loading="isLoading"></Loading>
    </div>
  </transition>
</template>
<script>
import FixBottom from "@/components/base/FixBottom";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import DownloadAndView from '@/components/order/DownloadAndView';
export default {
  components: {
    FixBottom, Loading, DownloadAndView
  },
  data() {
    return {
      isLoading: false,
      showBox: false,

      relContractObj: {},
      pageType: '' // 1: 确认提交补充合同商品清单， 2：确认审核通过（厂家） 3：确认审核通过（采购商）
    }
  },
  props: {
    orderInfo: {
      type: Object,
      default: () => ({}),
      required: false
    },
    tab: {
      type: Number,
      default: 0,
      required: false
    },
  },
  watch: {
    // 锁定父元素html的滚动
    showBox(val) {
      if (val) {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'hidden', 'important')
      } else {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'scroll', 'important')
      }
    },
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo
    },
    role() {
      return this.$store.state.userInfo
        ? this.$store.state.userInfo.bs
        : 0;
    },
    pdfList() {
      let list = []
      list = this.relContractObj.documentInfoList.filter(i => !this.divisionContract && i.documentType === 'externalReplenishAgreement' || (this.divisionContract && i.documentType === 'internalReplenishAgreement')) || []
      return list
    },
    // 采购商 - 事业部
    divisionContract() {
      return this.userInfo.bs == 'B' && this.tab == 1
    },
  },
  methods: {
    confirmSubmit() {
      if (this.pageType === '2') {
        this.confirmOrder()
      } else {
        this.showBox = false
        this.$emit('confirmSubmit')
      }

    },
    confirmOrder() {
      let params = {
        orderNo: this.relContractObj.orderNo,
      };
      InterfaceService.confirmOrder(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            this.$message.success(`补充合同审核成功！`);
            this.showBox = false
            this.$parent.handleOperation('5', this.relContractObj.orderNo);
            window.opener && window.opener.location.reload();
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    // 下载合同模板
    handleDownloadContract(type = '') {
      let attachListS = []
      let attachListB = []
      let list = this.relContractObj.documentInfoList || []
      list.forEach(i => {
        if (type === '1') { // 补充协议用印版
          if (i.bs === 'B' && ['internalReplenishAgreement'].includes(i.documentType)) {
            attachListB.push(i)
          } else if (i.bs === 'S' && ['externalReplenishAgreement'].includes(i.documentType)) {
            attachListS.push(i)
          }
        } else if (type === '2') {// 下载附件
          if (i.bs === 'B' && ['replenishAgreement', 'goodsList'].includes(i.documentType)) {
            attachListB.push(i)
          } else if (i.bs === 'S' && ['replenishAgreement', 'goodsList'].includes(i.documentType)) {
            attachListS.push(i)
          }
        } else {
          if (i.bs === 'B') {
            attachListB.push(i)
          } else if (i.bs === 'S') {
            attachListS.push(i)
          }
        }
      })

      if (this.role === 'S') {
        this.handleBatchDownload(attachListS, [], type)
      } else {
        this.handleBatchDownload(attachListS, attachListB, type)
      }
    },

    // handleDownloadContract(documentTypeList = [], type = '') {
    //   const params = {
    //     orderNo: this.relContractObj.orderNo,
    //     bs: this.role === 'S' ? 'S' : "",
    //     documentVersion: "",
    //     fileFrom: "userUpload,systemCreate",
    //     documentTypeList: []
    //   };
    //   InterfaceService.getContractInfo(params, data => {
    //     let res = data.respData;
    //     if (res.respCode === "0000") {
    //       console.log(res);
    //       let list = [];
    //       let documentInfos = res.documentInfos || [];
    //       let attachListB = [];
    //       let attachListS = [];
    //       documentInfos.forEach(i => {
    //         if (documentTypeList.length) {
    //           if (i.bs === 'B' && documentTypeList.includes(i.documentType)) {
    //             attachListB.push(i)
    //           } else if (i.bs === 'S' && documentTypeList.includes(i.documentType)) {
    //             attachListS.push(i)
    //           }
    //         } else {
    //           if (i.bs === 'B') {
    //             attachListB.push(i)
    //           } else if (i.bs === 'S') {
    //             attachListS.push(i)
    //           } else {
    //             attachListB.push(i)
    //             attachListS.push(i)
    //           }
    //         }
    //       })
    //       if (this.role === 'S') {
    //         this.handleBatchDownload(attachListS)
    //       } else {
    //         this.handleBatchDownload(attachListS, attachListB)
    //       }
    //     } else {
    //       this.$message.error(data.respMsg);
    //     }
    //   }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false });
    // },
    handleBatchDownload(attachList1, attachList2 = [], type = 0) {
      let fileInfoBeans = [];
      if (attachList1.length) {
        attachList1.forEach((item, index) => {
          fileInfoBeans.push({
            archivePath: '采购合同/' + item.documentName,
            fileUrl: item.attachUrl,
          })
        })
      }
      if (attachList2.length) {
        attachList2.forEach((item, index) => {
          fileInfoBeans.push({
            archivePath: '供应合同/' + item.documentName,
            fileUrl: item.attachUrl,
          })
        })
      }

      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl;
            const contractNameCount = this.relContractObj.contractName;
            let nameList = ['', '补充协议用印版', '附件']
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: contractNameCount.replace('采购合同', '合同') + nameList[+type] + ".zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
                // if (attachList2) {
                //   this.handleBatchDownload(attachList2)
                // }
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false });
    },
    close() {
      this.showBox = false
    },
    open(obj = {}, pageType = '') {
      this.relContractObj = obj
      this.pageType = pageType
      this.showBox = true
    }
  },
}
</script>
<style lang="scss" scoped>
// .batchSetUseProject {
//   .el-col {
//     width: inherit;
//   }
// }
.batchSetUseProject {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .confirmContract {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    height: 80%;
    overflow-x: hidden;
    overflow-y: auto;
    max-height: 610px;
    .content {
      width: 1190px;
      margin: 0 auto 100px;
      font-size: 14px;
      line-height: 17px;
      height: 500px;
      .title {
        padding: 40px 0 20px;
        border-bottom: 1px solid #eee;
        margin-bottom: 10px;
      }

      .contractInfo {
        padding-bottom: 20px;
        border-bottom: none;
        p {
          width: 100%;
          display: flex;
          padding-right: 10px;
          word-break: break-word;
          white-space: normal;
          line-height: 17px;
          font-size: 12px;
          margin-bottom: 10px;
          & > span {
            display: inline-block;
            flex: 1 1 0%;
          }
        }

        label {
          white-space: nowrap;
          color: #888888;
        }
        i {
          font-style: normal;
        }
      }
      .introduction-center {
        background: #fef4f3;
        padding: 20px 10px 10px;
        margin-bottom: 30px;
        position: relative;
        ul {
          display: flex;
          flex-wrap: wrap;
          li {
            width: 50%;
            margin-bottom: 10px;
            &.bold {
              font-weight: bold;
            }
          }
        }
        .has-rate {
          li {
            width: 33%;
          }
        }
      }
    }
  }
}
</style>