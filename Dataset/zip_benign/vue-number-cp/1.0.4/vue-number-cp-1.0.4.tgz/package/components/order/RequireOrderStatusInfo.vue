<template>
    <div>
        <div v-if="position==='top'" class="order-status">
            <div class="status-info">
                <div class="status-info-content">
                    <div>
                        <p>
                            <label>第{{orderInfo.requireBatchNo}}批次要货单当前状态：</label>
                            <span class="big">{{orderInfo.requireStatusDisp}}</span>
                        </p>
                        <p v-if="orderInfo.requireStatus=='01'||orderInfo.requireStatus=='03'">
                            <label>创建时间：</label>
                            <span>{{ orderInfo.tradeTime|datetime}}</span>
                        </p>
                        <p v-else-if="orderInfo.requireStatus=='04'&&role=='B'">
                            <label>通知内容：</label>
                            <span>供应商已备货完毕，准备发货，预计到货时间{{orderInfo.requireTimeFrom|datetime}} ~ {{orderInfo.requireTimeTo|datetime}}
                                <br> <span style="margin-left: 75px;">将货物送到指定地点。请确认是否发货？</span>
                            </span>
                        </p>

                        <p v-else-if="orderInfo.requireStatus=='06'">
                            <label>延缓到货时间：</label>
                            <span>请于 <span class="red">{{orderInfo.requireTimeFrom|datetime}} ~ {{orderInfo.requireTimeTo|datetime}}</span>到货</span>
                        </p>

                        <template v-else-if="orderInfo.requireStatus=='07'">
                            <p>
                                <label>发货时间：</label>
                                <span>{{operateTime('07')|datetime}}</span>
                            </p>
                            <p>
                                <label>物流信息：</label>
                                <span v-if="orderInfo.shippingMethod=='1'">{{orderInfo.expressCompanyName||'-'}}
                                    <span style="margin-left: 10px;color: #888888cc;">运单号：</span>{{orderInfo.trackingNo||'-'}}
                                    <a style="margin-left: 20px" v-if="role=='S'" @click="handleEditLogistics">修改</a>
                                    <a style="margin-left: 10px" v-if="orderInfo.expressCompany&&orderInfo.trackingNo" @click="handleLogisticsDetail">详情</a>
                                </span>
                                <span v-else-if="orderInfo.shippingMethod=='0'">
                                    <span>供应商自行配送</span>
                                    <a style="margin-left: 20px" v-if="role=='S'&&!specialRole" @click="handleEditLogistics">修改</a>
                                </span>
                                <span v-else>
                                    <a v-if="role=='S'&&!specialRole" @click="handleEditLogistics">填写物流</a>
                                </span>
                            </p>
                        </template>
                        <p v-else-if="orderInfo.requireStatus=='08'">
                            <label>签收货时间：</label>
                            <span>{{operateTime('08')|datetime}}</span>
                        </p>
                        <p v-else-if="orderInfo.requireStatus=='09'">
                            <label>取消原因：</label>
                            <template v-for="(flow,index) in orderInfo.requireOperFlow">
                                <span v-if="flow.operType=='09' && flow.operMsg" :key="index">{{flow.operMsg}}</span>
                                <span v-if="flow.operType=='09' && !flow.operMsg" :key="index">无</span>
                            </template>
                        </p>
                        <p v-else-if="orderInfo.requireStatus=='10'">
                            <label>签收时间：</label>
                            <span>{{operateTime('10')|datetime}}</span>
                        </p>
                        <p v-else>
                            <label>要求到货时间：</label>
                            <span>{{orderInfo.requireTimeFrom|datetime}} ~ {{orderInfo.requireTimeTo|datetime}}</span>
                        </p>
                    </div>
                </div>

                <div class="status-info-content">
                    <!-- 采购商操作 -->
                    <template v-if="role=='B'&&!specialPurChaseRole">
                        <!-- <el-button v-if="orderInfo.requireStatus=='01'" type="primary" size="small" @click="handleSubmitRequireDialog">提交要货单</el-button> -->
                        <el-button v-if="orderInfo.requireStatus=='02'" size="small" disabled>已提交</el-button>
                        <el-button v-if="orderInfo.requireStatus=='04'" size="small" @click="handleSendOrderNoticeConfirmDialog('delay')">延缓发货</el-button>
                        <el-button v-if="orderInfo.requireStatus=='04'" type="primary" size="small" @click="handleSendOrderNoticeConfirmDialog()">确认发货通知</el-button>
                        <el-button v-if="orderInfo.requireStatus=='05'" size="small" disabled>已确认发货通知</el-button>
                        <el-button v-if="orderInfo.requireStatus=='06'" size="small" disabled>已延缓发货</el-button>
                        <!-- <el-button v-if="orderInfo.requireStatus=='07'" type="primary" size="small" @click="handleHarvestDialog">收货</el-button> -->
                        <!-- <div class="tr" v-if="orderInfo.requireStatus=='08'">
                        <template v-for="(flow,index) in orderInfo.requireOperFlow" v-if="flow.operType=='08'">
                            <div :key="index" v-if="handledelayDate(flow.operTime,7)">
                                <el-button size="small" @click="handleReturnDialog()">退货</el-button>
                                <br>
                                <label>可退货时效：</label>{{flow.operTime|delayDate(7)}}
                            </div>
                            <el-button :key="index" v-else size="small" disabled>已收货</el-button>
                        </template>
                    </div>
                    <el-button v-if="orderInfo.requireStatus=='07'" size="small" @click="handleReturnDialog()">退货</el-button>
                    <el-button v-if="orderInfo.requireStatus=='09'" size="small" disabled>已退货</el-button> -->
                        <el-button v-if="orderInfo.requireStatus=='07'" type="primary" size="small" @click="handleCreateRecipt">创建验收单</el-button>
                        <el-button v-if="orderInfo.requireStatus=='15'" type="primary" size="small" @click="handleCreateRecipt">编辑验收单</el-button>
                        <!-- <el-button v-if="orderInfo.requireStatus=='16'" size="small" disabled>已验收</el-button> -->
                        <!-- <el-button v-if="orderInfo.requireStatus=='17'" type="primary" size="small" @click="handleCreateRecipt">继续验收</el-button> -->
                    </template>
                    <!-- 供应商操作 -->
                    <template v-if="role=='S'&&!specialRole&&corpId == this.userinfo.corpId">
                        <!--<el-button v-if="orderInfo.requireStatus=='02'" type="primary" size="small" @click="handleRequireOrderConfirm">确认要货单</el-button>-->
                        <el-button v-if="orderInfo.requireStatus=='03'||orderInfo.requireStatus=='06'" type="primary" size="small" @click="handleSendOrderNoticeDialog">发货通知</el-button>
                        <el-button v-if="orderInfo.requireStatus=='04'" size="small" disabled>已发送通知</el-button>
                        <el-button v-if="orderInfo.requireStatus=='05'||orderInfo.requireStatus=='17'" type="primary" size="small" @click="handleDeliverDialog">发货</el-button>
                        <el-button v-if="orderInfo.requireStatus=='07'" size="small" disabled>已发货</el-button>
                        <p v-if="orderInfo.requireStatus=='08'">
                            <template v-for="(flow,index) in orderInfo.requireOperFlow" v-if="flow.operType=='08'">
                                <label :key="index">采购商可退货时效：</label>至{{flow.operTime|delayDate(7)}}结束
                            </template>
                        </p>
                        <el-button v-if="orderInfo.requireStatus=='09'" type="primary" size="small" @click="handleSignReturnDialog">签收退货</el-button>
                        <el-button v-if="orderInfo.requireStatus=='10'" size="small" disabled>已签收退货</el-button>
                    </template>
                    <!-- 专属角色操作 -->
                    <el-button v-if="checkEventRole(1)=='unfinish'" size="small" @click="handleSignDialog(1)">签署要货单</el-button>
                    <el-button v-if="checkEventRole(1)=='finish'" size="small" disabled>已签章</el-button>
                    <el-button v-if="checkEventRole(2)=='unfinish'" type="primary" size="small" @click="handleSignDialog(2)">签署验收单</el-button>
                    <el-button v-if="checkEventRole(2)=='finish'" size="small" disabled>已验收</el-button>
                </div>
            </div>
        </div>

        <div v-if="position==='bottom'" class="status-bottom">

            <div class="tr">
                <!-- 采购商操作 -->
                <template v-if="role=='B'&&!specialPurChaseRole">
                    <!-- <el-button v-if="orderInfo.requireStatus=='01'" type="primary" size="large" @click="handleSubmitRequireDialog">提交要货单</el-button> -->
                    <el-button v-if="orderInfo.requireStatus=='02'" size="large" disabled>已提交</el-button>
                    <el-button v-if="orderInfo.requireStatus=='04'" size="large" @click="handleSendOrderNoticeConfirmDialog('delay')">延缓发货</el-button>
                    <el-button v-if="orderInfo.requireStatus=='04'" type="primary" size="large" @click="handleSendOrderNoticeConfirmDialog()">确认发货通知</el-button>
                    <el-button v-if="orderInfo.requireStatus=='05'" size="large" disabled>已确认发货通知</el-button>
                    <el-button v-if="orderInfo.requireStatus=='06'" size="large" disabled>已延缓发货</el-button>
                    <el-button v-if="orderInfo.requireStatus=='07'" type="primary" size="large" @click="handleCreateRecipt">创建验收单</el-button>
                    <el-button v-if="orderInfo.requireStatus=='15'" type="primary" size="large" @click="handleCreateRecipt">编辑验收单</el-button>
                    <!-- <el-button v-if="orderInfo.requireStatus=='16'" size="large" disabled>已验收</el-button> -->
                </template>
                <!-- 供应商操作 -->
                <template v-if="role=='S'&&!specialRole&&corpId == this.userinfo.corpId">
                    <!--<el-button v-if="orderInfo.requireStatus=='02'" type="primary" size="large" @click="handleRequireOrderConfirm">确认要货单</el-button>-->
                    <el-button v-if="orderInfo.requireStatus=='03'||orderInfo.requireStatus=='06'" type="primary" size="large" @click="handleSendOrderNoticeDialog">发货通知</el-button>
                    <el-button v-if="orderInfo.requireStatus=='04'" size="large" disabled>已发送通知</el-button>
                    <el-button v-if="orderInfo.requireStatus=='05'||orderInfo.requireStatus=='17'" type="primary" size="large" @click="handleDeliverDialog">发货</el-button>
                    <el-button v-if="orderInfo.requireStatus=='07'" size="large" disabled>已发货</el-button>
                    <el-button v-if="orderInfo.requireStatus=='09'" type="primary" size="large" @click="handleSignReturnDialog">签收退货</el-button>
                    <el-button v-if="orderInfo.requireStatus=='10'" size="large" disabled>已签收退货</el-button>
                </template>
                <!-- 专属角色操作 -->
                <el-button v-if="checkEventRole(1)=='unfinish'" size="large" @click="handleSignDialog(1)">签署要货单</el-button>
                <el-button v-if="checkEventRole(1)=='finish'" size="large" disabled>已签章</el-button>
                <el-button v-if="checkEventRole(2)=='unfinish'" type="primary" size="large" @click="handleSignDialog(2)">签署验收单</el-button>
                <el-button v-if="checkEventRole(2)=='finish'" size="large" disabled>已验收</el-button>
            </div>
        </div>

        <!-- 手动提交要货单 -->
        <SubmitRequire ref="submitRequire" @close="handleCloseSubmitRequire"></SubmitRequire>

        <!-- 确认发货通知 -->
        <SendOrderNoticeConfirm ref="sendOrderNoticeConfirm" @close="handleCloseSendOrderNoticeConfirm"></SendOrderNoticeConfirm>

        <!-- 确认要货单 -->
        <RequireOrderConfirm ref="requireOrderConfirm" @close="handleCloseRequireOrderConfirm"></RequireOrderConfirm>

        <!-- 确认发货 -->
        <SendOrderConfirm ref="sendOrderConfirm" @close="handleCloseSendOrderConfirm"></SendOrderConfirm>

        <!-- 签收退货 -->
        <SignReturnGoods ref="signReturnGoods" @close="handleCloseSignReturnGoods"></SignReturnGoods>

        <!-- 收货 -->
        <TakeGoodsConfirm ref="takeGoodsConfirm" @close="handleCloseTakeGoodsConfirm"></TakeGoodsConfirm>

        <!-- 退货 -->
        <ReturnGoods ref="returnGoods" @close="handleCloseReturnGoods"></ReturnGoods>

        <!-- 发货通知 -->
        <SendOrderNotice ref="sendOrderNotice" @close="handleCloseSendOrderNotice"></SendOrderNotice>

        <!-- 物流信息 -->
        <logistics ref="logistics"></logistics>

        <!-- 批量签章签收单 -->
        <SignBatchRecipt ref="signBatchRecipt" @close="handleCloseSignBatchRecipt"></SignBatchRecipt>
    </div>
</template>

<script>
import accountMixin from '@/mixins/account';
import Logistics from "@/components/order/Logistics";
import SubmitRequire from "@/components/order/dialog/SubmitRequire";
import SendOrderNoticeConfirm from "@/components/order/dialog/SendOrderNoticeConfirm";
import SendOrderConfirm from "@/components/order/dialog/SendOrderConfirm";
import RequireOrderConfirm from "@/components/order/dialog/RequireOrderConfirm";
import SignReturnGoods from "@/components/order/dialog/SignReturnGoods";
import TakeGoodsConfirm from "@/components/order/dialog/TakeGoodsConfirm";
import ReturnGoods from "@/components/order/dialog/ReturnGoods";
import SendOrderNotice from "@/components/order/dialog/SendOrderNotice";
import SignBatchRecipt from "@/components/order/dialog/SignBatchRecipt";
import { InterfaceService } from "@/services/api";
import delayDate from "@/filters/delayDate";
import { filterEventByAcct } from '@/utils/orderUtil';

export default {
    mixins:[accountMixin],
    components: {
        Logistics,
        SubmitRequire,
        SendOrderNoticeConfirm,
        SendOrderConfirm,
        RequireOrderConfirm,
        SignReturnGoods,
        TakeGoodsConfirm,
        ReturnGoods,
        SendOrderNotice,
        SignBatchRecipt
    },
    props: ["position","corpId", "requireNo", "orderInfo", "expressCompanyList"],
    data() {
        return {};
    },
    methods: {
        operateTime(type) {
            let operTime = '';
            if(this.orderInfo.requireOperFlow) {
                this.orderInfo.requireOperFlow.forEach(flow => {
                    if(flow.operType == type) {
                        operTime = flow.operTime;
                    }
                })
            }
            return operTime;
        },
        // 处理日期延迟
        handledelayDate(date, delay) {
            if (
                new Date(delayDate(date, delay)).getTime() >
                new Date(this.systemTime).getTime()
            ) {
                return true;
            } else {
                return false;
            }
            //return delayDate(date, delay);
        },
        // 确认签章/ 签章验收
        handleSignDialog(type) {
            if (type == 1) {
                this.$router.push({
                    path: "/signRequireOrder",
                    query: {
                        requireNo: this.orderInfo.requireNo
                    }
                });
            } else if (type == 2) {
                const events = [];
                let acctIdList = [];
                if (this.userinfo.accountList.length) {
                    this.userinfo.accountList.forEach(item=>{
                        acctIdList.push(item.acctId)
                    });
                }else {
                    acctIdList.push(this.acctId)
                }
                const eventsList = filterEventByAcct(this.orderInfo.eventList, 2, acctIdList);
                eventsList.forEach(ev => {
                    let valid = false;
                    if (ev.eventType == 2) {
                        const pros = ev.processList || [];
                        pros.forEach(process => {
                            if (process.processFlg == 0) {
                                valid = true;
                            }
                        });
                    }
                    if (valid) {
                        events.push(ev);
                    }
                });

                if (events.length > 1) {
                    this.$refs["signBatchRecipt"].open(events);
                } else if (events.length == 1) {
                    this.$router.push({
                        path: "/checkGoods",
                        query: {
                            deliveryNo: events[0].deliveryNo
                        }
                    });
                }
            }
        },
        // 批量确认签章完成
        handleCloseSignBatchRecipt(bool) {
            if (bool) {
                this.$emit("refresh");
            }
        },
        // 手工提交要货单
        handleSubmitRequireDialog() {
            this.$refs["submitRequire"].open(this.orderInfo);
        },
        // 提交要货单完成
        handleCloseSubmitRequire(bool) {
            if (bool) {
                this.$emit("refresh");
            }
        },
        // 确认发货通知
        handleSendOrderNoticeConfirmDialog(type) {
            this.$refs["sendOrderNoticeConfirm"].open(
                this.orderInfo,
                type == "delay"
            );
        },
        // 确认发货通知完成
        handleCloseSendOrderNoticeConfirm(bool) {
            if (bool) {
                this.$emit("refresh");
            }
        },
        // 创建验收单
        handleCreateRecipt() {
            this.$router.push({
                path: "/createCheckGoods",
                query: {
                    deliveryNo: this.orderInfo.lastDeliveryNo
                }
            });
        },
        // 确认要货单
        handleRequireOrderConfirm() {
            this.$refs["requireOrderConfirm"].open(this.orderInfo);
        },
        // 确认要货单完成
        handleCloseRequireOrderConfirm(bool) {
            if (bool) {
                this.$emit("refresh");
            }
        },
        // 发货通知
        handleSendOrderNoticeDialog() {
            this.$refs["sendOrderNotice"].open(this.orderInfo);
        },
        // 发货通知完成
        handleCloseSendOrderNotice(bool) {
            if (bool) {
                this.$emit("refresh");
            }
        },
        // 发货弹窗
        handleDeliverDialog() {
            this.$router.push({
                path: "/deliverGoods",
                query: {
                    requireNo: this.orderInfo.requireNo
                }
            });
        },
        // 发货完成
        handleCloseSendOrderConfirm(bool) {
            if (bool) {
                this.$emit("refresh");
            }
        },
        // 签收退货弹窗
        handleSignReturnDialog() {
            this.$refs["signReturnGoods"].open(this.orderInfo);
        },
        // 签收退货完成
        handleCloseSignReturnGoods(bool) {
            if (bool) {
                this.$emit("refresh");
            }
        },
        // 收货弹窗
        handleHarvestDialog() {
            this.$refs["takeGoodsConfirm"].open(this.orderInfo);
        },
        // 收货完成
        handleCloseTakeGoodsConfirm(bool) {
            if (bool) {
                this.$emit("refresh");
            }
        },
        // 退货弹窗
        handleReturnDialog() {
            this.$refs["returnGoods"].open(this.orderInfo);
        },
        // 退货完成
        handleCloseReturnGoods(bool) {
            if (bool) {
                this.$emit("refresh");
            }
        },
        // 修改物流信息
        handleEditLogistics() {
            const data = {
                requireNo: this.requireNo,
                shippingMethod: this.orderInfo.shippingMethod,
                expressCompany: this.orderInfo.expressCompany,
                trackingNo: this.orderInfo.trackingNo
            };
            this.$refs["sendOrderConfirm"].open(data, true);
        },
        // 物流信息详情
        handleLogisticsDetail() {
            this.$refs.logistics.$emit("init", {
                expressList: this.expressCompanyList,
                expressCompany: this.orderInfo.expressCompany,
                trackingNo: this.orderInfo.trackingNo
            });
        },
        // 检查角色事件
        checkEventRole(type) {
            let status = null;
            if (this.orderInfo && this.orderInfo.eventList) {
                let acctIdList = [];
                if (this.userinfo.accountList.length) {
                    this.userinfo.accountList.forEach(item=>{
                        acctIdList.push(item.acctId)
                    });
                }else {
                    acctIdList.push(this.acctId)
                }
                const events = filterEventByAcct(this.orderInfo.eventList, type, acctIdList);
                events.forEach(ev => {
                    if (ev.eventType == type) {
                        if (ev.processList && ev.processList.length) {
                            status = status || "finish";
                            ev.processList.forEach(process => {
                                if (process.processFlg == 0) {
                                    status = "unfinish";
                                }
                            });
                        }
                    }
                });
            }
            return status;
        }
    }
};
</script>
<style lang="scss" scoped>
.order-status {
    height: 120px;
    margin: 20px 0;
    padding: 40px 20px 40px 80px;
    border: 1px solid #fddd74;
    background: url("../../assets/images/order-detail-bg.jpg") no-repeat;
    background-size: 100% 100%;

    /deep/ .el-button {
        width: 100px;
    }
}

.status-info {
    display: flex;
    justify-content: space-between;
    height: 100%;
    line-height: 25px;
}

.status-info-content {
    display: flex;
    justify-content: center;
    align-content: center;
    font-size: 14px;
    a {
        color: #0082ff;
    }

    label {
        color: #888888;
    }

    button {
        align-self: center;
    }
    & > div {
        display: inline-block;
        align-self: center;
    }

    .big {
        font-size: 20px;
        color: #333;
    }
}

.status-bottom {
    /deep/ .el-button {
        width: 150px;
    }
}
</style>


