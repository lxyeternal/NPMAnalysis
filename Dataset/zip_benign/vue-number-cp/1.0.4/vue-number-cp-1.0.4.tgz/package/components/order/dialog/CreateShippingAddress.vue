<template>
  <transition name="el-zoom-in-bottom">
    <div class="box" v-show="showBox">
      <div class="createShippingAddress">
        <div class="content">
          <div class="title tc">{{isEdit?'修改收货地址':'创建收货地址'}}</div>
          <div class="center">
            <el-form ref="form" :model="form" :rules="rules" label-width="130px" size="small">
              <el-row>
                <el-col class="seatchW-width" :span="12">
                  <el-form-item label="收货人：" prop="name">
                    <el-input placeholder="请输入" v-model="form.name" clearable>
                    </el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-form-item label="收货地址：" prop="districtCode">
                  <Distpicker v-if="showBox" :address="form" @receive="getAddressCode"></Distpicker>
                </el-form-item>
              </el-row>
              <el-row type="flex" justify="space-between">
                <el-col>
                  <el-form-item label="" prop="addr">
                    <el-input placeholder="请输入详细地址" v-model="form.addr" maxlength="100" clearable>
                    </el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row type="flex" justify="space-between">
                <el-col class="seatchW-width" :span="12">
                  <el-form-item label="手机号：" prop="mobile">
                    <el-input placeholder="请输入" v-model="form.mobile" maxlength="11" clearable @input="form.mobile=form.mobile.replace(/[^\d.]/g,'')">
                    </el-input>
                  </el-form-item>
                </el-col>
                <el-col class="seatchW-width" :span="12">
                  <el-form-item label="邮政编码：" prop="zipCode">
                    <el-input placeholder="请输入" v-model="form.zipCode" maxlength="6" clearable @input="form.zipCode=form.zipCode.replace(/[^\d.]/g,'')">
                    </el-input>
                  </el-form-item>
                </el-col>
              </el-row>
               <el-row type="flex" justify="space-between" v-if="!noSaveFlg">
                <el-col class="seatchW-width">
                  <el-form-item label="是否设为默认地址：">
                    <!--<el-checkbox v-model="defaults">设置为默认收货地址</el-checkbox>-->
                    <el-radio-group
                      v-model="defaults"
                    >
                      <el-radio label="1">设为默认</el-radio>
                      <el-radio label="0">不默认</el-radio>
                    </el-radio-group>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </div>
        </div>
        <FixBottom class="bottom">
          <!-- 未设置过模拟清单 -->
          <div class="tc">
            <el-button type="primary" @click="submit()">确认</el-button>
            <el-button @click="clear()">取消</el-button>
          </div>
        </FixBottom>
      </div>
      <Loading :is-loading="isLoading"></Loading>
    </div>
  </transition>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import FixBottom from "@/components/base/FixBottom";
import Distpicker from "@/components/base/Distpicker";
const formList = {
  name: '',
  provCode: '',
  cityCode: '',
  districtCode: '',
  addr: '',
  zipCode: '',
  mobile: '',
  blockCode: '',
  addressId: '',
  provinceName: '',
  cityName: '',
  blockName: '',
}
export default {
  components: {
    FixBottom, Loading, Distpicker
  },
  data() {
    return {
      isLoading: false,

      isEdit: false,
      showBox: false,
      noSaveFlg: false,
      defaults: '0',
      form: JSON.parse(JSON.stringify(formList)),
      orderInfo: {},
      rules: {
        name: [
          {
            required: true,
            message: "请填写收货人"
          },
          { pattern: /^[^\s]{1,20}$/, message: '收货人支持1-20个字', trigger: "blur" }
        ],
        provCode: [
          {
            required: true,
            message: "请选择地址信息",
          }
        ],
        cityCode: [
          {
            required: true,
            message: "请选择地址信息",
          }
        ],
        districtCode: [
          {
            required: true,
            message: "请选择地址信息",
          }
        ],
        addr: [
          {
            required: true,
            message: "请输入详细地址",
            trigger: "blur",
          }
        ],
        zipCode: [
          {
            required: true,
            message: "请填写正确的邮政编码"
          },
          { pattern: /^\d{6}$/, message: '请填写正确的邮政编码', trigger: "blur" }
        ],
        mobile: [
          {
            required: true,
            message: "请填写手机号"
          },
          { pattern: /^[1][0-9][0-9]{9}$/, message: '请填写正确的手机号', trigger: "blur" }
        ]
      },
    }
  },
  methods: {
    //   获取地址
    getAddressCode(res, nameList) {
      console.log(res)
      console.log(nameList)
      this.$set(this.form, "provCode", res.provinceCode);
      this.$set(this.form, "cityCode", res.cityCode);
      this.$set(this.form, "districtCode", res.blockCode);
      if (nameList) {
        this.$set(this.form, "provinceName", nameList.provinceName);
        this.$set(this.form, "cityName", nameList.cityName);
        this.$set(this.form, "blockName", nameList.blockName);
      }
    },
    submit() {
      if (this.noSaveFlg) {
        this.$refs.form.validate((valid) => {
          if (valid) {
            const params = this.$clone(this.form)
            this.$message.success('创建成功')
            this.$emit('upDate', params)
            this.clear()
          }
        })
      } else {
        this.confirm()
      }
    },
    confirm() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          const url = this.isEdit ? 'editReceiverAddressList' : 'addReceiverAddressList'
          const params = { ...this.form }
          params.defaultFlg = this.defaults
          params.corpId = this.orderInfo && this.orderInfo.purchaserId || ''
          InterfaceService[url](
            params,
            data => {
              //console.log(data)
              if (data && data.respData && data.respData.respCode === "0000") {
                this.$message.success(this.isEdit ? '编辑成功' : '创建成功')
                this.$emit('upDate', data.respData.addressId)
                this.clear()
              } else {
                this.$message.error(data && data.respData && data.respData.respMsg)
              }
            },
            data => { },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            }
          );
        } else {
          return console.log('error submit!!')
        }
      })
    },
    clear() {
      this.form = this.$clone(formList)
      this.$refs.form.resetFields()
      this.showBox = false
      console.log(this.form)
    },
    open(data,noSave,defaultFlg,orderInfo) {
      this.orderInfo = orderInfo || {}
      this.noSaveFlg = !!noSave;
      this.showBox = true
      this.isEdit = data ? true : false
      if (this.isEdit) {
        this.form = { ...data };
        this.defaults = defaultFlg || '0';
        // console.log(this.defaults)
        this.form.blockCode = this.form.districtCode
      }
    },
  },
}
</script>
<style lang="scss" scoped>
/deep/ .linkage .el-select {
  width: 32.9% !important;
}
.box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .createShippingAddress {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    overflow-x: hidden;
    overflow-y: auto;
    .content {
      width: 1190px;
      margin: 0 auto 90px;
      font-size: 14px;
      line-height: 17px;
      .title {
        padding: 20px 0;
        border-bottom: 1px solid #eee;
        margin-bottom: 20px;
      }
    }
  }
}
</style>