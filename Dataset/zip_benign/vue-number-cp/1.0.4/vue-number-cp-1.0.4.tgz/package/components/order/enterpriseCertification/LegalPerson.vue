<template>
  <div class="BankAccount">
    <div class="container">
      <div class="bank-content">
        <el-form ref="form" :model="bankInfo" :rules="rules" label-width="110px" size="small">
          <el-row>
            <el-col :span="12">
              <el-form-item label="法人姓名：">
                <div>{{infoData.legalRepresent}}</div>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="法人身份证号：" v-if="infoData.legalCertNo">
                <div>{{infoData.legalCertNo}}</div>
              </el-form-item>
              <el-form-item label="法人身份证号：" prop="legalCertNo" v-else>
                <el-input v-model.trim="bankInfo.legalCertNo" @focus="handleFocus('legalCertNo',$event)"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="法人手机号：" prop="legalMobile">
                <el-input v-model.trim="bankInfo.legalMobile" @focus="handleFocus('legalMobile',$event)" maxlength="11"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item :label="`验证码：`" prop="validateCode">
                <div class='validate-code'>
                  <ValidateCode :is-show-validate="true" @received="getCode" :update="update"></ValidateCode>
                  <div class="error-msg red" v-if="errorMsg.validateCode">{{errorMsg.validateCode}}</div>
                </div>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="法人手机验证码：" prop="authcode">
                <div class="ver-mobile-input">
                  <el-input v-model.trim="bankInfo.authcode" @input="checkPwd($event,'authcode')">
                    <div slot="suffix" class="suffix">
                      <el-button type="primary" class="normal-btn" :disabled="!bankInfo.legalMobile || !bankInfo.validateCode || isCountdown" :class="{'isDisabled-primary':!bankInfo.legalMobile || !bankInfo.validateCode || isCountdown}" @click="operationThreeCer">{{isCountdown ? duration+'秒后可重试' : '获取短信验证码'}}</el-button>
                    </div>
                  </el-input>
                  <!-- <div class="error-msg red" v-if="errorMsg.authcode">{{errorMsg.authcode}}</div> -->
                </div>
                <p class="eqb-notice bold">※输入由 [e签宝] 发送的短信验证码。</p>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div slot="footer" class="footer">
        <el-button type="primary" class="normal-btn" @click="handleConfirm">提交核验</el-button>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import ValidateCode from '@/components/base/ValidateCode'

const bankInfo = {
  legalCertNo: "",
  legalMobile: "",
  validateCode: "",
  authcode: "",
};
export default {
  components: {
    Loading, ValidateCode,
  },
  props: ['info', 'propAcctId', 'propCorpId'],
  watch: {
    info: {
      handler(val) {
        // console.log(val)
        this.infoData = this.$clone(val)
      },
      immediate: true,
    }
  },
  data() {
    const validataCertNo = (rule, value, callback) => {
      let certNoReg = this.$commonExpression('certNo');
      if (value === '') {
        callback(new Error('必填'));
      } else {
        if (!certNoReg.test(this.bankInfo.legalCertNo) && this.bankInfo.legalCertNo) {
          callback(new Error('法人身份证号格式不正确'));
        }
        callback();
      }
    };
    const validateMobile = (rule, value, callback) => {
      const reg = new RegExp(/^[1][0-9][0-9]{9}$/);
      if (!reg.test(value)) {
        return callback(new Error("法人手机号格式错误"));
      } else {
        callback();
      }
    };
    return {
      isLoading: false,

      infoData: {},
      individualAuthNo: '',
      update: '',
      errorMsg: {},
      isCountdown: false,
      duration: 60,
      bankInfo: Object.assign({}, bankInfo),
      rules: {
        legalCertNo: [
          { required: true, message: "必填", trigger: ['blur'] },
          { required: true, validator: validataCertNo, trigger: ['blur'] }
        ],
        legalMobile: [
          { required: true, message: "必填", trigger: ['blur'] },
          { validator: validateMobile, trigger: ['blur'] }
        ],
        validateCode: [{ required: true, message: "请输入图片验证码", trigger: 'blur' }],
        authcode: [{ required: true, message: "请输入手机验证码", trigger: 'blur' }]
      },
    };
  },
  methods: {
    handleFocus(type, ev) {
      this.bankInfo[type] = this.bankInfo[type] && this.bankInfo[type].replace(/\s+/g, "")
      if (ev && ev.target.value == "") {
        this.bankInfo[type] = null
      }
    },
    checkPwd(e, item) {
      this.bankInfo[item] = this.bankInfo[item].replace(/\D+/, '')
      this.bankInfo[item] = this.bankInfo[item].substr(0, 6)
    },
    getCode: function (code) {
      this.bankInfo.validateCode = code
      code && (delete this.errorMsg['validateCode']);
      this.$forceUpdate();
    },
    // 发起短信认证
    operationThreeCer() {
      this.$refs["form"].validateField(['legalMobile'], valid => {
        if (!valid) {
          const param = {
            certNo: this.infoData.legalCertNo ? this.infoData.legalCertNo : this.bankInfo.legalCertNo,
            name: this.info.legalRepresent,
            mobileNo: this.bankInfo.legalMobile,
            validateCode: this.bankInfo.validateCode,
            origTxCode: '040085',
          };
          InterfaceService.operationThreeCer(param, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              if (data.respData.status === '1') {
                this.$message.success('发送成功')
                this.isCountdown = true
                this.duration = 60
                this.timedCount()
                this.individualAuthNo = data.respData.individualAuthNo
              } else {
                this.$message.error(data.respData.message)
              }
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        } else {
          // console.log(valid)
        }
      });
    },
    timedCount() {//保持禁用,倒计时
      clearTimeout(this.timer);
      if (this.duration == 0) {
        this.isCountdown = false;
        this.duration = 60
      } else {
        this.timer = setTimeout(() => {
          this.duration--;
          this.timedCount();
        }, 1000)
      }
    },
    handleConfirm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          this.verificationCodeCer()
        }
      });
    },
    // 填写短信码进行认证
    verificationCodeCer() {
      const param = {
        corpId: this.propCorpId || this.$store.state.userInfo.corpId,
        individualAuthNo: this.individualAuthNo,//	Y	个人核身编号
        legalRepresent: this.infoData.legalRepresent,//	Y	法人
        legalMobile: this.bankInfo.legalMobile,//	Y	法人手机号
        legalCertNo: this.infoData.legalCertNo ? this.infoData.legalCertNo : this.bankInfo.legalCertNo,//	Y	法人身份证
        authcode: this.bankInfo.authcode,//	Y	6位验证码
        acctId: this.propAcctId || undefined, // 事业部列表传入
      };
      InterfaceService.verificationCodeCer(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          if (data.respData.status === '1') {
            this.$message.success('核验成功')
            this.$emit('upDate', true)
          } else {
            this.$message.error(data.respData.message)
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 查询未入库体检对象供应商
    doGetProviderRiskDetail() {
      const params = {
        name: this.info.corpName,
        type: "baseInfo"
      }
      InterfaceService.doGetProviderRiskDetail(params, (data) => {
        const result = data.respData;
        if (result.respCode == '0000') {
          const obj = result.evaluationInfo || {}
          this.infoData.legalRepresent = obj.legalPerson || this.infoData.legalRepresent
        } else {
          this.$message.error(result.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  },
};
</script>

<style lang="scss" scoped>
/deep/ .el-form-item__label {
  font-size: 12px;
}
/deep/ .el-select {
  width: 100%;
}
/deep/ .el-form-item--mini.el-form-item {
  margin-bottom: 0;
}
.ver-mobile-input {
  /deep/ .el-input__suffix {
    right: 0px !important;
  }
  /deep/ .el-input--suffix .el-input__inner {
    padding-right: 130px !important;
  }
  .suffix {
    .normal-btn {
      padding: 0px !important;
      height: 32px;
      line-height: 32px;
    }
  }
}
.BankAccount {
  .container {
    padding: 0 15px 20px;
    .footer {
      text-align: center;
      margin-top: 22px;
    }
    .default-flg {
      text-align: left;
      height: 25px;
      line-height: 25px;
      padding-left: 10px;
      background-color: #eeeeee;
      span {
        margin-left: 6px;
      }
    }
  }
}
</style>
