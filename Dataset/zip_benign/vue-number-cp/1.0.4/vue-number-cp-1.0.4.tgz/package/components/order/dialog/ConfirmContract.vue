<template>
  <div>
    <transition name="el-zoom-in-bottom">
      <div class="box" v-show="showBox">
        <div class="confirmContract" ref="confirmContract">
          <div class="content">
            <div class="title tc">确认合同</div>
            <div class="center">
              <el-form ref="form" :model="form" :rules="rules" label-width="160px" size="small">

                <p class="f12" style="margin-bottom: 20px;">请确认查阅过合同，并确认合同中的金额、商品清单及合同条款等重要内容。若合同内容有疑议，直接和供应商沟通或点击【拒绝合同】。若无异议，完善以下信息，点击【确认合同】即可。</p>
                <el-row type="flex" justify="space-between">
                  <el-col class="seatchW-width">
                    <el-form-item label="项目名称：" prop="projectId">
                      <el-select v-model="form.projectId" filterable placeholder="选择或输入关键词查找" @change="form.projectStageCode='';projectStageName = ''">
                        <el-option v-for="item in projectList" :key="item.projectId" :label="item.projectName" :value="item.projectId">
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col class="seatchW-width">
                    <el-form-item label="项目分期：" prop="projectStageCode">
                      <!-- <el-input v-model.trim="form.projectTerm" placeholder="请输入数字" maxlength="4" class="right_padding" type="text" @input="handleInputNum('projectTerm')">
                        <div slot="suffix" class="suffix">期</div>
                      </el-input> -->
                      <el-select v-model="form.projectStageCode" placeholder="请选择项目分期" @change="handleChangeProjectStage">
                        <!-- <el-option v-if="!projectStageList.length" label="全期" value="全期"></el-option> -->
                        <el-option v-for="item in projectStageList" :key="item.projectStageCode" :label="item.projectStageName" :value="item.projectStageCode">
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row type="flex" justify="space-between">
                  <el-col class="seatchW-width">
                    <el-form-item label="标段：">
                      <el-input v-model="form.building" placeholder="请输入标段" @blur="checkFileName" clearable maxlength="20">
                      </el-input>
                    </el-form-item>
                  </el-col>
                  <el-col class="seatchW-width" v-if="orderInfo.busiType != 'ONEWAY_ORDER'">
                    <el-form-item label="签约主体：">
                      <el-input v-model="orderInfo.brokerCorpName" disabled>
                      </el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row v-if="orderInfo.busiType != 'ONEWAY_ORDER'">
                  <el-col class="seatchW-width">
                    <el-form-item label="合同加价率：">
                      <el-input v-model.trim="orderInfo.addRate" @input="addRateCompured" :maxlength="5" class="right_padding">
                        <div slot="suffix" class="suffix">%</div>
                      </el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <div class="box-gray">
                  预览合同名称： {{contractNameCount}}
                </div>
                <p class="f12" style="margin:10px 0 30px">※合同命名规则：事业部+项目名+分期+标段(可选)+材料类别</p>
                <div class="solid"></div>

                <div class="order-info-title">合同及项目信息</div>
                <h1>采购商</h1>
                <el-row type="flex" justify="space-between">
                  <el-col class="seatchW-width">
                    <el-form-item prop="handleAcctId" class="label-two">
                      <span slot="label">采购商授权代表：<br><span style="margin-right: 12px" class="f12">(城市公司项目经理)</span></span>
                      <el-select v-model="form.handleAcctId" placeholder="请选择授权代表" @change="form.handleAcctId === '暂无' ? (form.authorizationFile = []) : ''">
                        <!-- <el-option label="暂无" value="暂无"></el-option> -->
                        <el-option v-for="item in handleAcctList(acctList, ['2002'], 'handleAcctId')" :key="item.acctId" :label="item.acctName" :value="item.acctId">
                          <span style="float: left">{{ item.acctName+'(Tel:'+ formatPhoneNumber(item.mobile,'3 4 4') +')' }}</span>
                        </el-option>
                        <div style="padding: 14px 10px 8px;border-top: 1px solid #eee;">
                          <p class="tc f12" style="line-height: 17px;">若无可选之人，请联系管理员至<span class="blue">【权限管理】</span>编辑添加</p>
                        </div>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row v-if="form.handleAcctId !== '暂无'">
                  <el-col :span="24" class="enclosure">
                    <el-form-item class="upload" style="color: #000;" label="采购商授权代表授权书" label-width="268px" prop="authorizationFile">
                      <DownloadAndUpload class="f12" style="position: absolute;left: 154px; top: 0px;" :hasUpload="form.handleAcctId ? true : false" appName="TRD" fromId="authorizationFile" uploadType="3" :fileTypeReg="/(pdf|PDF)/i" :templateFile="supplierTemplate" fileTypeErrorMsg="请上传pdf格式文件" @outputValue="getAttachInfo"></DownloadAndUpload>
                      <div class="grey f12 tip-text">请先下载模板，根据模板内容完善相关信息，然后打印加盖公司公章，扫描该文件并以PDF格式上传。该授权书的人员信息必须与所填的采购商授权代表(城市公司项目经理)用户信息一致。</div>
                      <div class="enclosure-content has-text" v-if="form.authorizationFile.length">
                        <div v-for="(item,index) in form.authorizationFile" :key="index+'b'">
                          <span>{{item.attachName}}</span>
                          <DownloadAndView :format="false" :viewName="'预览'" :downloadName="'下载'" :paddingLeft="'6px'" :attachUrl="item.viewUrl" :attachName="item.attachName"></DownloadAndView>
                        </div>
                      </div>
                      <div v-else class="grey enclosure-content has-text">
                        未上传附件！
                      </div>
                      <!-- <div class="grey f12 tip-text"></div>
                      <div class="enclosure-content has-text" v-if="form.authorizationFile.length">
                        <div v-for="(item,index) in form.authorizationFile" :key="index+'b'">
                          <span>{{item.attachName}}</span>
                          <DownloadAndView :format="false" :viewName="'预览'" :downloadName="'下载'" :paddingLeft="'6px'" :attachUrl="item.viewUrl" :attachName="item.attachName"></DownloadAndView>
                        </div>
                      </div>
                      <div v-else class="grey enclosure-content has-text">
                        未上传附件！
                      </div> -->
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row type="flex" justify="space-between">
                  <el-col class="seatchW-width">
                    <el-form-item label="合同盖章人：" prop="contractSealer" class="aegalAuthorizedClient contractSealer">
                      <el-select v-model="form.contractSealer" placeholder="请选择合同盖章人">
                        <el-option v-for="item in handleAcctList(acctList, ['2004'], 'contractSealer')" :key="item.acctId" :label="item.acctName" :value="item.acctId"></el-option>
                        <div style="padding: 14px 10px 8px;border-top: 1px solid #eee;" slot="empty">
                          <p class="tc f12" style="line-height: 17px;">若无可选之人，请联系管理员至<span class="blue">【权限管理】</span>编辑添加</p>
                        </div>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <!-- <el-col class="seatchW-width">
                    <el-form-item label="合同签字人：" prop="contractSigner" class="aegalAuthorizedClient">
                      <el-select v-model="form.contractSigner" placeholder="请选择合同签字人">
                        <el-option v-for="item in handleAcctList(acctList, ['2003'], 'contractSigner')" :key="item.acctId" :label="item.acctName" :value="item.acctId"></el-option>
                        <div style="padding: 14px 10px 8px;border-top: 1px solid #eee;" slot="empty">
                          <p class="tc f12" style="line-height: 17px;">若无可选之人，请联系管理员至<span class="blue">【权限管理】</span>编辑添加</p>
                        </div>
                      </el-select>
                    </el-form-item>
                  </el-col> -->
                </el-row>
                <el-row type="flex" justify="space-between">
                  <el-col class="seatchW-width">
                    <el-form-item label="项目部材料员：" prop="materialClerk">
                      <el-select v-model="form.materialClerk" placeholder="请选择项目部材料员">
                        <el-option v-for="item in handleAcctList(acctList, ['2010'], 'materialClerk')" :key="item.acctId" :label="item.acctName" :value="item.acctId"></el-option>
                        <div style="padding: 14px 10px 8px;border-top: 1px solid #eee;" slot="empty">
                          <p class="tc f12" style="line-height: 17px;">若无可选之人，请联系管理员至<span class="blue">【权限管理】</span>编辑添加</p>
                        </div>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col class="seatchW-width">
                    <el-form-item label="收发货印章管理员：" prop="sealManager" class="aegalAuthorizedClient projectSigner">
                      <el-select v-model="form.sealManager" placeholder="请选择收发货印章管理员">
                        <el-option v-for="item in handleAcctList(acctList, ['2006'], 'sealManager')" :key="item.acctId" :label="item.acctName" :value="item.acctId"></el-option>
                        <div style="padding: 14px 10px 8px;border-top: 1px solid #eee;" slot="empty">
                          <p class="tc f12" style="line-height: 17px;">若无可选之人，请联系管理员至<span class="blue">【权限管理】</span>编辑添加</p>
                        </div>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <div v-if="orderInfo.constructionContent != '1'" class="dashed" style="margin: 12px 0 20px 0"></div>
                <h1 v-if="orderInfo.constructionContent != '1'">施工单位<span v-if="!form.constructionCompany.some(i=>i.companyId === '暂无')" class="f12 blue hand" @click="addConstructionCompany">添加施工单位</span><i class="f12 red" style="margin-left: 20px">若搜索不到施工单位，请先联系施工单位入驻本平台并设置好相关角色人员后再来添加。</i></h1>
                <div v-if="orderInfo.constructionContent != '1'">
                  <div v-for="(a, index) in form.constructionCompany" :key="index+'constructionCompany'">
                    <el-row type="flex" justify="space-between">
                      <el-col class="seatchW-width">
                        <el-form-item label="企业名称：" :prop="'constructionCompany.'+index+'.companyId'" :rules="{required: true, message: '必填', trigger: 'change'}">
                          <el-select v-model="a.companyId" filterable remote :remote-method="handleFilterCorp" @change="handlecompanyId(a,index)" placeholder="请选择要料施工单位或输入关键词查找" no-data-text="无数据">
                            <el-option label="暂无" value="暂无"></el-option>
                            <el-option v-for="item in contractCorpList" :key="item.corpId" :label="item.corpName" :value="item.corpId"></el-option>
                          </el-select>
                        </el-form-item>
                        <div v-show="form.constructionCompany.length > 1" class="f12 hand blue" style="line-height: 32px;position: absolute;right: -30px;top: 0;" @click="delConstructionCompany(index)">删除</div>
                      </el-col>
                      <el-col class="seatchW-width" v-if="a.companyId !== '暂无'">
                        <el-form-item :prop="'constructionCompany.'+index+'.handleAcctId'" class="label-two" :rules="{required: true, message: '必填', trigger: 'change'}">
                          <span slot="label">授权代表：<br><span style="margin-right: 8px" class="f12">(指定收货人)</span></span>
                          <el-select v-model="a.handleAcctId" placeholder="请选择授权代表" @change="a.handleAcctId === '暂无' ? (a.authorizationFile=[]) : ''">
                            <!-- <el-option label="暂无" value="暂无"></el-option> -->
                            <el-option v-for="item in handleAcctList(a.acctList, ['3002'], 'handleAcctId', a)" :key="item.acctId" :label="item.acctName" :value="item.acctId">
                              <span style="float: left">{{ item.acctName+'(Tel:'+ formatPhoneNumber(item.mobile,'3 4 4') +')' }}</span>
                            </el-option>
                            <div style="padding: 14px 10px 8px;border-top: 1px solid #eee;" slot="empty">
                              <p class="tc f12" style="line-height: 17px;">若无可选之人，请联系施工单位管理员</p>
                            </div>
                          </el-select>
                        </el-form-item>
                      </el-col>
                    </el-row>
                    <!-- <el-row v-if="a.companyId !== '暂无' && a.handleAcctId !== '暂无'"> -->
                    <el-row v-if="a.companyId !== '暂无'">
                      <el-col :span="24" class="enclosure">
                        <el-form-item class="upload" style="color: #000;" label="施工单位授权代表授权书" label-width="268px" :prop="'constructionCompany.'+index+'.authorizationFile'" :rules="{required: true, message: '必填', trigger: 'change'}">
                          <DownloadAndUpload class="f12" style="position: absolute;left: 166px; top: 0px;" :hasUpload="a.companyId ? true : false" appName="TRD" :fromId="String(index)" uploadType="5" :fileTypeReg="/(pdf|PDF)/i" :templateFile="contractCorpTemplate" fileTypeErrorMsg="请上传pdf格式文件" @outputValue="getAttachInfo"></DownloadAndUpload>
                          <div class="grey f12 tip-text">请先下载模板，根据模板内容完善相关信息，然后打印加盖公司公章，扫描该文件并以PDF格式上传。该授权书的人员信息必须与所填的施工方授权代表(指定收货人)用户信息一致。</div>
                          <div class="enclosure-content has-text" v-if="a.authorizationFile.length">
                            <div v-for="(item,index1) in a.authorizationFile" :key="index1+'b'">
                              <span>{{item.attachName}}</span>
                              <DownloadAndView :format="false" :viewName="'预览'" :downloadName="'下载'" :paddingLeft="'6px'" :attachUrl="item.viewUrl" :attachName="item.attachName"></DownloadAndView>
                            </div>
                          </div>
                          <div v-else class="grey enclosure-content has-text">
                            未上传附件！
                          </div>
                        </el-form-item>
                      </el-col>
                    </el-row>
                    <el-row type="flex" justify="space-between" v-if="a.companyId !== '暂无'">
                      <el-col class="seatchW-width">
                        <el-form-item label="项目经理：" :prop="'constructionCompany.'+index+'.contractSealer'" :rules="{required: true, message: '必填', trigger: 'change'}">
                          <el-select v-model="a.contractSealer" placeholder="请选择项目经理">
                            <el-option v-for="item in handleAcctList(a.acctList, ['3009'], 'contractSealer', a)" :key="item.acctId" :label="item.acctName" :value="item.acctId"></el-option>
                            <div style="padding: 14px 10px 8px;border-top: 1px solid #eee;" slot="empty">
                              <p class="tc f12" style="line-height: 17px;">若无可选之人，请联系施工单位管理员</p>
                            </div>
                          </el-select>
                        </el-form-item>
                      </el-col>
                      <el-col class="seatchW-width">
                        <el-form-item label="项目盖章人：" :prop="'constructionCompany.'+index+'.contractSigner'" :rules="{required: true, message: '必填', trigger: 'change'}">
                          <el-select v-model="a.contractSigner" placeholder="请选择项目盖章人">
                            <el-option v-for="item in handleAcctList(a.acctList, ['2006', '3010'], 'contractSigner', a)" :key="item.acctId" :label="item.acctName" :value="item.acctId"></el-option>
                            <div style="padding: 14px 10px 8px;border-top: 1px solid #eee;" slot="empty">
                              <p class="tc f12" style="line-height: 17px;">若无可选之人，请联系施工单位管理员</p>
                            </div>
                          </el-select>
                        </el-form-item>
                      </el-col>
                    </el-row>
                    <div v-if="index+1 != form.constructionCompany.length" class="dashed" style="margin: 12px 0 20px 0"></div>
                  </div>
                </div>
                <div class="solid" style="margin: 12px 0 0 0"></div>
                <div class="order-info-title">付款方式（必填）</div>
                <div class="resize-none-container">
                  <el-form-item label="" prop="inPmtMethod" label-width="0">
                    <el-input class="resize-none" type="textarea" v-model="form.inPmtMethod" :rows="4" placeholder="请输入..." maxlength="800" show-word-limit></el-input>
                  </el-form-item>
                </div>
                <div class="solid" style="margin: 12px 0 0 0"></div>

                <div class="order-info-title">付款账户</div>
                <el-row>
                  <el-col :span="24" class="account">
                    <el-form-item label="付款账户：">
                      <el-select v-model="form.bankAcctId" disabled>
                        <el-option v-for="item in bankList" :key="item.bankAcctId" :label="(item.bankName || '')+'('+ formatCardNum(item.bankAcctNo) +')    '+ (item.bankAcctName || '')" :value="item.bankAcctId">
                        </el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <div class="solid" style="margin: 12px 0 0 0"></div>
                <div class="order-info-title">事业部合同数据录入</div>
                <el-row type="flex" justify="space-between">
                  <el-col class="seatchW-width">
                    <el-form-item prop="constructionCostIndex" class="label-two">
                      <span slot="label"><span><span style="margin-right: 12px;">合同金额</span><br><span>建面成本指标</span></span><span class="fr" style="margin-top: -9px;">：</span></span>
                      <el-input v-model="form.constructionCostIndex" placeholder="请输入" clearable maxlength="9" @input="handleInputNum('constructionCostIndex')">
                      </el-input>
                    </el-form-item>
                  </el-col>
                  <el-col class="seatchW-width">
                    <el-form-item label="合同金额实物量成本指标：" prop="amountCostIndex" label-width="178px">
                      <el-input v-model="form.amountCostIndex" placeholder="请输入" clearable maxlength="9" @input="handleInputNum('amountCostIndex')">
                      </el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row type="flex" justify="space-between">
                  <el-col class="seatchW-width">
                    <el-form-item prop="targetCost" class="label-two">
                      <span slot="label"><span><span style="margin-right: 12px;">目标成本</span><br><span>该项核算*90%</span></span><span class="fr" style="margin-top: -9px;">：</span></span>
                      <el-input v-model="form.targetCost" placeholder="请输入" clearable maxlength="9" @input="handleInputNum('targetCost')">
                      </el-input>
                    </el-form-item>
                  </el-col>
                  <el-col class="seatchW-width">
                    <el-form-item prop="groupLimit" class="label-two" label-width="178px">
                      <span slot="label"><span><span style="margin-right: 12px;">集团限额或目标成本</span><br><span>限额要求</span></span><span class="fr" style="margin-top: -9px;">：</span></span>
                      <el-input v-model="form.groupLimit" placeholder="请输入" clearable maxlength="9" @input="handleInputNum('groupLimit')">
                      </el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="24" class="enclosure">
                    <el-form-item class="upload" style="color: #000;" label="合同清单工程计算书" label-width="268px" prop="calculationFile">
                      <DownloadAndUpload class="f12" style="position: absolute;left: 142px; top: 0px;" appName="TRD" :hasDownloadFlg="false" fromId="calculationFile" uploadType="8" @outputValue="getAttachInfo"></DownloadAndUpload>
                      <div class="enclosure-content" v-if="form.calculationFile.length">
                        <div v-for="(item,index) in form.calculationFile" :key="index+'b'">
                          <span>{{item.attachName}}</span>
                          <DownloadAndView :format="false" :viewName="'预览'" :downloadName="'下载'" :paddingLeft="'6px'" :attachUrl="item.viewUrl" :attachName="item.attachName"></DownloadAndView>
                          <!-- <span class="blue-pointer f12" style="padding-left: 10px;" @click="delFile(form.calculationFile,index)">删除</span> -->
                        </div>
                      </div>
                      <div v-else class="grey enclosure-content">
                        未上传附件！
                      </div>
                    </el-form-item>
                  </el-col>
                </el-row>

                <!-- 单向合同 -->
                <template v-if="orderInfo.busiType === 'ONEWAY_ORDER'">
                  <div class="order-info-title">附件</div>
                  <el-row>
                    <el-col :span="24" class="enclosure">
                      <el-form-item class="upload" style="color: #000;" label="比价清单" label-width="268px" prop="comparePriceFileList">
                        <DownloadAndUpload :fileSize="157286400" fileSizeErrorMsg="单个附件大小不超过150MB。" class="f12" style="position: absolute;left: 70px; top: 0px;" appName="TRD" :hasDownloadFlg="false" fromId="comparePrice" uploadType="16" @outputValue="getAttachInfo"></DownloadAndUpload>
                        <p class="f12 tip-text">单个附件大小不超过150MB。</p>
                        <div class="enclosure-content" style="margin-top: 4px" v-if="form.comparePriceFileList.length">
                          <div v-for="(item,index) in form.comparePriceFileList" :key="index+'b'">
                            <span>{{item.attachName}}</span>
                            <DownloadAndView :format="false" :viewName="'预览'" :downloadName="'下载'" :paddingLeft="'6px'" :attachUrl="item.viewUrl" :attachName="item.attachName"></DownloadAndView>
                            <span class="blue-pointer f12" style="padding-left: 10px;" @click="delFile(form.comparePriceFileList,index)">删除</span>
                          </div>
                        </div>
                        <div v-else class="grey enclosure-content" style="margin-top: 4px">
                          未上传附件！
                        </div>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="24" class="enclosure">
                      <el-form-item class="upload" style="color: #000;" label="其他附件" label-width="268px">
                        <DownloadAndUpload :fileSize="157286400" fileSizeErrorMsg="单个附件大小不超过150MB。" class="f12" style="position: absolute;left: 70px; top: 0px;" appName="TRD" :hasDownloadFlg="false" fromId="purchaserOtherFile" uploadType="19" @outputValue="getAttachInfo"></DownloadAndUpload>
                        <p class="f12 tip-text">单个附件大小不超过150MB。</p>
                        <div class="enclosure-content" style="margin-top: 4px" v-if="form.otherFileList.length">
                          <div v-for="(item,index) in form.otherFileList" :key="index+'b'">
                            <span>{{item.attachName}}</span>
                            <DownloadAndView :format="false" :viewName="'预览'" :downloadName="'下载'" :paddingLeft="'6px'" :attachUrl="item.viewUrl" :attachName="item.attachName"></DownloadAndView>
                            <span class="blue-pointer f12" style="padding-left: 10px;" @click="delFile(form.otherFileList,index)">删除</span>
                          </div>
                        </div>
                        <div v-else class="grey enclosure-content" style="margin-top: 4px">
                          未上传附件！
                        </div>
                      </el-form-item>
                    </el-col>
                  </el-row>
                </template>

                <div class="order-info-title">收货地址</div>
                <div class="address f12">
                  <span class="grey"><i class="red"></i>收货地址：</span>
                  <span>{{orderInfo.consigneeAddr + ' ' + orderInfo.consigneeName + ' ' + orderInfo.consigneeMobile || '暂无'}}</span>
                </div>
                <!-- <div class="order-info-title">选择收货地址<span class="f12 blue hand" style="margin-left: 6px;font-weight: normal;" @click="$refs.createShippingAddress.open();showBox=false">创建收货地址</span></div>
                <ul class="address">
                  <li v-for="(item,index) in addressList" :key="index+'addressList'" :class="{'active':addressId===item.addressId}" @click="addressId=item.addressId" class="hand">
                    <div v-if="index < (isShowMore?addressList.length:2)">
                      <div class="left">{{item.name}}</div>
                      <div class="right">
                        <p>{{item.provCodeDisp}} {{item.cityCodeDisp}} {{item.districtCodeDisp}} {{item.addr}} {{item.mobile}} <i></i></p>
                        <span class="blue f12 hand" :class="{'active':item.defaultFlg === '0'}" @click.stop="$refs.createShippingAddress.open(item);showBox=false">修改</span>
                        <span v-if="item.defaultFlg === '0'" class="blue f12 hand" @click="handleDefaultAddress(item)">设为默认地址</span>
                      </div>
                    </div>
                  </li>
                </ul>
                <p class="f12 blue hand" v-if="addressList.length > 2" @click="isShowMore=!isShowMore">{{isShowMore?'收起':'显示更多'}}>></p> -->
              </el-form>
            </div>
          </div>
          <FixBottom class="bottom">
            <!-- 未设置过模拟清单 -->
            <div class="tc">
              <el-button type="primary" @click="confirm('submit')">下一步</el-button>
              <!-- <el-button @click="handleDownloadContract">下载合同</el-button> -->
              <el-button @click="confirm('save')">保存</el-button>
              <el-button @click="close">取消</el-button>
            </div>
          </FixBottom>
        </div>
        <!-- OA合同审批 -->
        <!-- <OaApprove ref="oaApprove" :orderNo="orderNo" :fileType="'4'" :appName="'TRD'" :content="'请填写OA流程编号和上传OA合同审批通过凭证附件，点击【确认提交】按钮即可。'" :label="'OA流程编号'" :fileLabel="'OA合同审批通过凭证'" @upDate="pushOrder"></OaApprove> -->
        <Loading :is-loading="isLoading"></Loading>
      </div>
    </transition>
    <!-- 收货地址 -->
    <!-- <CreateShippingAddress ref="createShippingAddress" @upDate="upDate"></CreateShippingAddress> -->
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import FixBottom from "@/components/base/FixBottom";
// import CreateShippingAddress from "@/components/order/dialog/CreateShippingAddress";
import { viewFile } from '@/utils/orderUtil';
import DownloadAndView from '@/components/order/DownloadAndView';
import DownloadAndUpload from "@/components/base/DownloadAndUpload";
import formatPhoneNumber from '@/filters/formatPhoneNumber'
import formatCardNum from '@/filters/formatCardNum'
import { NumberUtil } from '@/utils/numberUtil';

// import OaApprove from '@/components/order/dialog/OaApprove'
const formList = {
  projectName: '',//项目名称
  projectId: '', //项目ID
  projectStageCode: '',//项目分期
  building: '',//标段
  bankAcctId: '',//付款账户ID
  contractName: '',// 合同名称
  authorizationFile: [],
  calculationFile: [],
  comparePriceFileList: [],
  otherFileList: [],

  handleAcctId: '',//城市公司项目经理
  contractPrincipal: '',//合约负责人
  contractSealer: '',//合同盖章人
  // contractSigner: '',//合同签字人
  materialClerk: '',//项目部材料员
  sealManager: '',//收发货印章管理员
  constructionCostIndex: '',//合同金额建面成本指标：
  amountCostIndex: '',//合同金额实物量成本指标：
  targetCost: '',//目标成本该项核算
  groupLimit: '',//集团限额或目标成本限额要求：
  purchaserId: '', // 外部传入 corpId

  constructionCompany: [
    {
      companyId: '',
      handleAcctId: '',
      contractSealer: '',
      contractSigner: '',
      authorizationFile: [],
      acctList: [],
    }
  ],
  inPmtMethod: '', // 付款方式
}
export default {
  components: {
    FixBottom, Loading, viewFile,
    // CreateShippingAddress,
    DownloadAndView, DownloadAndUpload,
    // OaApprove,
  },
  props: ['orderNo', 'verifyCorpId'],
  data() {
    return {
      isLoading: false,
      orderInfo: {},
      isShowMore: false,
      showBox: false,
      projectList: [],//项目列表
      acctList: [],
      contractCorpList: [],//施工单位列表
      bankList: [],//付款账户列表
      // addressId: "",//收货地址ID
      addressList: [],// 公司地址列表
      // delFile: [],
      supplierTemplate: {},//采购商授权模板
      contractCorpTemplate: {},//施工单位授权模板
      projectStageName: '',
      projectStageList: [],

      form: { ...formList },
      rules: {
        inPmtMethod: [
          { required: true, message: "必填", trigger: "blur" },
        ],
        projectId: [
          { required: true, message: '必填', trigger: 'change' }
        ],
        projectStageCode: [
          { required: true, message: '必填', trigger: 'change' }
        ],
        // building: [
        //   { required: true, message: '必填', trigger: 'blur' }
        // ],
        handleAcctId: [
          { required: true, message: '必填', trigger: 'change' }
        ],
        // contractPrincipal: [
        //   { required: true, message: '必填', trigger: 'change' }
        // ],
        contractSealer: [
          { required: true, message: '必填', trigger: 'change' }
        ],
        // contractSigner: [
        //   { required: true, message: '必填', trigger: 'change' }
        // ],
        materialClerk: [
          { required: true, message: '必填', trigger: 'change' }
        ],
        sealManager: [
          { required: true, message: '必填', trigger: 'change' }
        ],
        // authorizationFile: [
        //   { required: true, message: '必填', trigger: 'change' }
        // ],
        calculationFile: [
          { required: true, message: '必填', trigger: 'change' }
        ],
        comparePriceFileList: [
          { required: true, message: '必填', trigger: 'change' }
        ],
        constructionCostIndex: [
          { required: true, message: '必填', trigger: 'blur' }
        ],
        amountCostIndex: [
          { required: true, message: '必填', trigger: 'blur' }
        ],
        targetCost: [
          { required: true, message: '必填', trigger: 'blur' }
        ],
        groupLimit: [
          { required: true, message: '必填', trigger: 'blur' }
        ],
      },
    }
  },
  computed: {
    addRateCompured() {
      return e => {
        const val1 = this.orderInfo.addRate.replace(/[^\d.]/g, ''),
          // 保留一位小数
          val2 = val1.match(/.*\.+\d{1}/)

        let result = 0

        if (!(val2 && val2[0])) {
          result = val1
        } else {
          result = val2[0]
        }
        if (+result > 99.9) {
          result = 99.9
        }
        this.orderInfo.addRate = result

        return result
      }
    },
    contractNameCount() {
      let result = ''
      result = '绿地集团' + (this.orderInfo.groupCompanyName || '') + (this.form.projectName ? this.form.projectName : 'XX项目') + (this.projectStageName ? this.projectStageName : 'XX期') + (this.form.building ? (this.form.building + '标段') : '') + this.orderInfo.categoryName + '采购合同'
      this.form.contractName = result
      // console.log(this.form.contractName)
      return result
    },
    userInfo() {
      return this.$store.state.userInfo || {};
    },
  },
  watch: {
    // 锁定父元素html的滚动
    showBox(val) {
      if (val) {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'hidden', 'important')
      } else {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'scroll', 'important')
      }
    },
    'form.projectId': {
      handler() {
        if (!this.form.projectId) return
        this.projectList.forEach(i => {
          if (i.projectId === this.form.projectId) {
            this.form.projectName = i.projectName
            this.projectStageList = this.$clone(i.projectStageList)
            // console.log(i, '---选中的 分期');

          }
        })
        // console.log(this.projectStageList)
        // this.$forceUpdate()
      },
    },
    'form.projectStageCode': {
      handler() {
        if (!this.form.projectStageCode) return
        this.projectStageList.forEach(i => {
          if (i.projectStageCode === this.form.projectStageCode) {
            this.projectStageName = i.projectStageName
          }
        })
      },
    }
  },
  filters: {
    addRateFilter(val) {
      // console.log(val);
      if (val) {
        return Number(val) * 100 + '%'
      } else {
        return ''
      }
    }
  },
  methods: {
    // 合同名称
    checkFileName() {
      let reg = new RegExp('^[^\\\\\\/:*?\\"<>|，,：]+$');
      if (!reg.test(this.form.building) && this.form.building != "") {
        this.form.building = "";
        this.$message.error("标段不能包含下列字符：\\ / ：* ？\" < > | ，, ：");
      }
    },

    // handleProjectStageList() {
    //   console.log('11111111111')
    //   let obj = this.projectList.find(i => i.projectId === this.form.projectId) || {}
    //   if (obj.projectStageList && obj.projectStageList.length) {
    //     return obj.projectStageList
    //   } else {
    //     return []
    //   }
    // },
    handleChangeProjectStage() {
      // console.log(this.projectStageList, 'form.projectStageCode', this.form.projectStageCode);
      const item = this.projectStageList.find(f => f.projectStageCode == this.form.projectStageCode) || {}
      item.projectManagerAcctId && (this.form.handleAcctId = item.projectManagerAcctId)
      // 授权书 - 如果没有 attachUrl 就不初始化值了, 防止保存的时候 保存一个空的数据回去
      if (item.attachUrl) {
        this.form.authorizationFile = [{
          attachName: item.attachName,
          viewUrl: item.attachUrl,
          attachUrl: item.attachPath,
          fileTypeId: 'authorityPM',
          businessType: 'CONTRACT_FORMATION',
        }] || []
      } else {
        this.form.authorizationFile = []
      }
      // console.log(this.form.authorizationFile, '选取 赋值');
    },
    changeValue(e) {
      // console.log(e);
      this.$forceUpdate()
    },
    handleDel(file, ind) {
      file.forEach((item, index) => {
        if (index === ind) {
          file.splice(ind, 1)
        }
      })
    },
    handleInputNum(type) {
      // console.log(this.form[type]);
      this.form[type] = this.form[type].replace(/[^\d.]/g, '')
    },
    formatPhoneNumber(val, type) {
      return formatPhoneNumber(val, type)
    },
    formatCardNum(val) {
      return formatCardNum(val)
    },
    // upDate(addressId) {
    //   this.showBox = true
    //   this.getAddressList()
    //   this.addressId = addressId
    // },
    // 添加施工单位
    addConstructionCompany() {
      this.form.constructionCompany.push(
        {
          companyId: '',
          handleAcctId: '',
          contractSealer: '',
          contractSigner: '',
          authorizationFile: [],
          acctList: []
        }
      )
    },
    delConstructionCompany(index) {
      this.form.constructionCompany.splice(index, 1)
    },
    // 远程搜索施工、监理企业名称
    handleFilterCorp(keyword) {
      if (keyword != "") {
        this.getStakeHolderCorp(keyword);
      }
    },
    // 施工单位(企业名称)change
    handlecompanyId(obj, index) {
      // console.log('iooooo')
      if (obj.companyId !== '暂无' && this.form.constructionCompany.filter(i => i.companyId === obj.companyId).length >= 2) {
        obj.companyId = ''
        return this.$message.error('不能选择相同的企业！')
      }
      if (obj.companyId === '暂无' && this.form.constructionCompany.length >= 2) {
        this.form.constructionCompany.splice(index, 1)
      }
      obj.handleAcctId = ''
      obj.contractSealer = ''
      obj.contractSigner = ''
      obj.authorizationFile = []
      obj.acctList = []
      if (obj.companyId !== '暂无' && obj.companyId) this.getQuerySubordinate(obj)
    },
    // 删除文件
    delFile(list = [], index) {
      list.splice(index, 1)
      this.$message.success('已删除')
    },
    // 获取上传文件
    getAttachInfo(info) {
      if (info.fromId == "authorizationFile") {
        if (!this.form.authorizationFile.length) this.form.authorizationFile.push({})
        if (info.attachName != (this.supplierTemplate.fileTypeName + '.pdf')) {
          this.$message.info("已将文件名更改为【" + this.supplierTemplate.fileTypeName + ".pdf】")
          this.form.authorizationFile[0].attachName = this.supplierTemplate.fileTypeName + '.pdf'
        } else {
          this.form.authorizationFile[0].attachName = info.attachName;
        }
        this.form.authorizationFile[0].viewUrl = info.attachUrl;
        this.form.authorizationFile[0].attachUrl = info.attachPath;
        this.form.authorizationFile[0].fileTypeId = 'authorityPM';
        this.form.authorizationFile[0].businessType = 'CONTRACT_FORMATION';
        this.$refs['form'].clearValidate('authorizationFile')
      } else if (info.fromId == "calculationFile") {
        if (!this.form.calculationFile.length) this.form.calculationFile.push({})
        // if (info.attachName != (this.supplierTemplate.fileTypeName + '.pdf')) {
        //   this.$message.info("已将文件名更改为【" + this.supplierTemplate.fileTypeName + ".pdf】")
        //   this.form.authorizationFile[0].attachName = this.supplierTemplate.fileTypeName + '.pdf'
        // } else {
        // this.form.calculationFile.push({
        //   attachName : info.attachName,
        //   viewUrl : info.attachUrl,
        //   attachUrl : info.attachPath,
        //   fileTypeId : 'contractOaHtqdgcljss',
        //   businessType : 'CONTRACT_FORMATION',
        // })
        this.form.calculationFile[0].attachName = info.attachName;
        // }
        this.form.calculationFile[0].viewUrl = info.attachUrl;
        this.form.calculationFile[0].attachUrl = info.attachPath;
        this.form.calculationFile[0].fileTypeId = 'contractOaHtqdgcljss';
        this.form.calculationFile[0].businessType = 'CONTRACT_FORMATION';
        this.$refs['form'].clearValidate('calculationFile')
      } else if (info.fromId == "comparePrice") {
        this.form.comparePriceFileList.push({
          attachName: info.attachName,
          viewUrl: info.attachUrl,
          attachUrl: info.attachPath,
          fileTypeId: 'comparePrice',
          businessType: 'CONTRACT_FORMATION',
          bs: 'B'
        })
        this.$refs['form'].clearValidate('comparePriceFileList')
      } else if (info.fromId == "purchaserOtherFile") {
        this.form.otherFileList.push({
          attachName: info.attachName,
          viewUrl: info.attachUrl,
          attachUrl: info.attachPath,
          fileTypeId: 'purchaserOtherFile',
          businessType: 'CONTRACT_FORMATION',
          bs: 'B'
        })
        this.$refs['form'].clearValidate('otherFileList')
      } else {
        const fromId = Number(info.fromId)
        // console.log(info.fromId)
        // console.log(this.form.constructionCompany)
        if (!this.form.constructionCompany[fromId].authorizationFile.length) this.form.constructionCompany[fromId].authorizationFile.push({})

        const corpName = this.contractCorpList.filter(i => i.corpId === this.form.constructionCompany[fromId].companyId)[0].corpName
        const fileName = this.contractCorpTemplate.fileTypeName + '-' + corpName + '.pdf'
        if (info.attachName != fileName) {
          this.$message.info("已将文件名更改为【" + fileName + "】")
          this.form.constructionCompany[fromId].authorizationFile[0].attachName = fileName
        } else {
          this.form.constructionCompany[fromId].authorizationFile[0].attachName = info.attachName;
        }
        this.form.constructionCompany[fromId].authorizationFile[0].viewUrl = info.attachUrl;
        this.form.constructionCompany[fromId].authorizationFile[0].attachUrl = info.attachPath;
        this.form.constructionCompany[fromId].authorizationFile[0].fileTypeId = 'authorityConstructor';
        this.form.constructionCompany[fromId].authorizationFile[0].businessType = 'CONTRACT_FORMATION';
        this.$refs['form'].clearValidate('constructionCompany.' + fromId + '.authorizationFile')
      }
      // console.log(this.form.constructionCompany)
      this.$forceUpdate()
    },
    // 获取采购商项目列表
    getProjectList() {
      const params = {
        corpId: this.form.purchaserId || this.userInfo.corpId
      };
      InterfaceService.getProjectList(
        params,
        data => {
          if (data.respData.respCode == "0000") {
            this.projectList = data.respData.projectList || []
            if (this.projectList.length === 1 && !this.form.projectId) {
              this.form.projectId = this.projectList[0].projectId
              this.projectStageList = this.$clone(this.projectList[0].projectStageList)
            }
            this.projectList.forEach(i => {
              if (i.projectId === this.form.projectId) {
                this.projectStageList = this.$clone(i.projectStageList)
                // 第一次赋值项目分期
                if (this.form.projectStageCode) {
                  this.projectStageList.forEach(i => {
                    if (i.projectStageCode === this.form.projectStageCode) {
                      this.projectStageName = i.projectStageName
                      // 授权书 - 如果没有 attachUrl 就不初始化值了, 防止保存的时候 保存一个空的数据回去
                      if (i.attachUrl) {
                        this.form.authorizationFile = [{
                          attachName: i.attachName,
                          viewUrl: i.attachUrl,
                          attachUrl: i.attachPath,
                          fileTypeId: 'authorityPM',
                          businessType: 'CONTRACT_FORMATION',
                        }] || []
                      } else {
                        this.form.authorizationFile = []
                      }
                    }
                  })
                }
              }
            })
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { }, () => { this.isLoading = true }, () => { this.isLoading = false }
      );
    },
    // 采购商授权代表授权书模板
    getOrderConfiguration() {
      const params = {
        businessType: 'CONTRACT_FORMATION'
      };
      InterfaceService.getOrderConfiguration(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let uploadFileList = res.uploadFileList || []
          uploadFileList.forEach(i => {
            // if (i.fileTypeId === 'authorityPurchaser') {
            if (i.fileTypeId === 'authorityPM') {
              this.supplierTemplate = i
              this.supplierTemplate.name = i.templateFileName
              this.supplierTemplate.url = i.attachUrl
            } else if (i.fileTypeId === 'authorityConstructor') {
              this.contractCorpTemplate = i
              this.contractCorpTemplate.name = i.templateFileName
              this.contractCorpTemplate.url = i.attachUrl
            }
          });
        } else {
          this.$message.error(res.respMsg);
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 查询施工单位
    getStakeHolderCorp(keyword) {
      let params = {
        contractCorpType: 'construction',
        corpId: this.form.purchaserId
      };
      if (keyword) {
        params.corpName = keyword;
      }
      InterfaceService.getStakeHolderCorp(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          this.contractCorpList = res.corpInfos || []
        } else {
          this.$message.error(res.respMsg);
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 付款账户
    getBankList() {
      InterfaceService.getBankList(
        { corpId: this.form.purchaserId },
        data => {
          if (data.respData.respCode === "0000") {
            this.bankList = data.respData.bankList;
            if (this.bankList && this.bankList.length > 0 && !this.form.bankAcctId) {
              this.bankList.forEach(i => {
                if (i.bankAcctType === '0') {
                  this.form.bankAcctId = i.bankAcctId
                }
              })
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { }, () => { this.isLoading = true }, () => { this.isLoading = false }
      );
    },
    // 收货地址列表
    // getAddressList() {
    //   const params = {
    //     corpId: this.userInfo.corpId
    //   }
    //   InterfaceService.getReceiverAddressList(
    //     params,
    //     data => {
    //       //console.log(data)
    //       if (data.respCode === "0000") {
    //         this.addressList = data.respData.shippingAddress || [];
    //         if (!this.addressId) {
    //           this.addressList.forEach(i => {
    //             if (i.defaultFlg === '1') {
    //               this.addressId = i.addressId
    //             }
    //           })
    //         }
    //       }
    //     },
    //     data => { }, () => { this.isLoading = true }, () => { this.isLoading = false }
    //   );
    // },
    // 查询公司下属账户信息
    getQuerySubordinate(obj) {
      let param = {}
      if (obj && obj.companyId) {
        param = {
          corpId: obj.companyId
        }
      } else {
        param = {
          corpId: this.form && this.form.purchaserId || ''
        }

      }
      InterfaceService.getQuerySubordinate(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          if (obj && obj.companyId) {
            // alert('施工单位(企业名称)change')
            obj.acctList = data.respData.acctList || []
          } else {
            this.acctList = data.respData.acctList || []
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 处理下属单位只有一个时默认选中
    handleAcctList(list, roleId = [], name, obj) {
      const a = list.filter(i => i.roleIds && i.roleIds.some(j => roleId.includes(j.roleId)))
      if (a.length === 1) {
        if (typeof obj === 'object') {
          obj[name] = a[0].acctId
        } else {
          this[name] = a[0].acctId
        }
      }
      return a
    },
    // 设为默认地址
    // handleDefaultAddress(item) {
    //   const params = { ...item }
    //   params.defaultFlg = '1'
    //   InterfaceService.editReceiverAddressList(
    //     params,
    //     data => {
    //       //console.log(data)
    //       if (data && data.respData && data.respData.respCode === "0000") {
    //         this.$message.success('操作成功')
    //         this.getAddressList()
    //       }
    //     }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    // },
    confirm(operType) {
      if (operType === 'save') {
        // 施工单位保存时，信息必须全部填完
        if (this.orderInfo.constructionContent != '1') {
          const a = this.form.constructionCompany.filter(i => i.companyId && i.companyId !== '暂无' && (!i.handleAcctId || !i.contractSealer || !i.contractSigner))
          // console.log(a)
          if (a.length) {
            const corpName = this.contractCorpList.filter(i => i.corpId === a[0].companyId)[0].corpName
            return this.$message.error(`施工单位“${corpName}”的信息未填完！`)
          }
        }
        // 保存信息
        this.pushOrder(operType)
      } else {
        this.$refs['form'].validate((valid) => {
          if (valid) {
            // if (!this.addressId) return this.$message.error('请选择收货地址')
            // 提交OA审批
            // if (!this.orderInfo.externalSysList.length) {
            //   this.pushOrder('save', true)
            // } else {
            //   this.pushOrder(operType)
            // }
            this.pushOrder(operType)
          } else {
            this.$message.error('还有必填内容未填写，请检查填写信息！');
            return false
          }
        });
      }
    },
    pushOrder(operType, type = false) {
      // 采购商授权代表和施工单位授权代表数据处理
      let contractStakeHolders = []
      const corpIds = this.$store.state.userInfo.corpId || ''
      this.form.handleAcctId ? contractStakeHolders.push({ role: "21", acctId: this.form.handleAcctId, corpId: corpIds }) : contractStakeHolders.push({ role: "21", acctId: "", corpId: "" })
      this.form.contractPrincipal ? contractStakeHolders.push({ role: "23", acctId: this.form.contractPrincipal, corpId: corpIds }) : contractStakeHolders.push({ role: "23", acctId: "", corpId: "" })
      this.form.contractSealer ? contractStakeHolders.push({ role: "22", acctId: this.form.contractSealer, corpId: corpIds }) : contractStakeHolders.push({ role: "22", acctId: "", corpId: "" })
      // this.form.contractSigner ? contractStakeHolders.push({ role: "24", acctId: this.form.contractSigner, corpId: corpIds }) : contractStakeHolders.push({ role: "24", acctId: "", corpId: "" })
      this.form.materialClerk ? contractStakeHolders.push({ role: "28", acctId: this.form.materialClerk, corpId: corpIds }) : contractStakeHolders.push({ role: "28", acctId: "", corpId: "" })
      this.form.sealManager ? contractStakeHolders.push({ role: "29", acctId: this.form.sealManager, corpId: corpIds }) : contractStakeHolders.push({ role: "29", acctId: "", corpId: "" })
      let fileList = []
      if (this.orderInfo.constructionContent != '1') {
        this.form.constructionCompany.forEach(i => {
          if (i.companyId !== '暂无' && i.companyId) {
            !i.handleAcctId ? "" : contractStakeHolders.push({ role: "00", corpId: i.companyId, acctId: i.handleAcctId, })
            !i.contractSealer ? "" : contractStakeHolders.push({ role: "01", corpId: i.companyId, acctId: i.contractSealer, })
            !i.contractSigner ? "" : contractStakeHolders.push({ role: "02", corpId: i.companyId, acctId: i.contractSigner, })
            if (i.authorizationFile.length && i.handleAcctId !== '暂无') {
              i.authorizationFile[0].corpId = i.companyId
              fileList.push(i.authorizationFile[0])
            }
          } else {
            contractStakeHolders.push({ role: "00", corpId: "", acctId: "", exist: i.companyId === '暂无' ? '1' : '0' })
            contractStakeHolders.push({ role: "01", corpId: "", acctId: "", exist: i.companyId === '暂无' ? '1' : '0' })
            contractStakeHolders.push({ role: "02", corpId: "", acctId: "", exist: i.companyId === '暂无' ? '1' : '0' })
          }
        })
      }
      fileList = fileList.concat(this.form.authorizationFile, this.form.calculationFile, this.form.comparePriceFileList, this.form.otherFileList)
      // console.log(contractStakeHolders)
      // console.log(fileList)
      // console.log(this.form)
      // return
      // console.log(this.orderInfo.addRate, +(NumberUtil.divide(this.orderInfo.addRate, 100).toFixed(3)));
      // 判断采购商授权书是否为空
      // console.log(fileList, ' --fileList');
      if (operType !== 'save' && !fileList.some(s => (s.fileTypeId == 'authorityPM' && s.viewUrl))) {
        this.$message.error('采购商授权代表授权书不能为空，请至【公司管理】-【项目列表】查看项目及分期页面修改。')
        return
      }

      const params = {
        // addressId: this.addressId,
        orderNo: this.orderNo,
        building: this.form.building,
        addRate: this.orderInfo.busiType != 'ONEWAY_ORDER' ? +(NumberUtil.divide(+this.orderInfo.addRate, 100).toFixed(3)) : '',
        projectStageCode: this.form.projectStageCode,
        brokerCorpName: this.orderInfo.busiType != 'ONEWAY_ORDER' ? this.form.brokerCorpName : '',
        brokerCorpId: this.orderInfo.brokerCorpId,
        projectId: this.form.projectId,
        projectName: this.form.projectName,
        contractName: this.form.contractName,
        inPmtMethod: this.form.inPmtMethod || '',
        contractStakeHolders: contractStakeHolders,
        uploadFiles: fileList,
        bankAcctId: this.form.bankAcctId,
        constructionCostIndex: this.form.constructionCostIndex,
        amountCostIndex: this.form.amountCostIndex,
        targetCost: this.form.targetCost,
        groupLimit: this.form.groupLimit,
        dataIsIntact: operType == 'submit' ? true : false,
        operType: 'save',
        verifyCorpId: this.verifyCorpId || ''
      };
      // console.log(params);
      InterfaceService.pushOrder(
        params,
        data => {
          if (data.respData.respCode == "0000") {
            if (operType === 'submit') {
              this.showBox = false
              this.$emit('upDate')
              if (window.opener) {
                window.opener.location.reload();
              }
            } else {
              this.$message.success('保存成功')
              this.$emit('upDate', 'confirmContract')
              // if (type) {
              //   this.$refs.oaApprove.open()
              // }
              this.getOrderTemplate()
            }
          } else {
            if (data.respData.respMsg) {
              this.$message.error(data.respData.respMsg)
            } else {
              let errorMsgs = [];
              let errorList = data.respData.errorInfo && data.respData.errorInfo.errorList || [];
              let skuList = data.respData.errorInfo && data.respData.errorInfo.skuList || [];
              errorList.forEach(item => {
                errorMsgs.push('<p class="tl">' + item + '</p><br>')
              });
              skuList.forEach(sku => {
                errorMsgs.push('<p class="tl">' + sku.skuName + '(' + sku.skuId + ')：' + sku.errorMsg + '</p>')
              });
              if (errorMsgs.length) {
                this.$message.error(errorMsgs.join(" "), false)
              }
            }
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false });
    },
    // 下载合同
    handleDownloadContract() {
      const params = {
        orderNo: this.orderNo,
        bs: this.role === 'S' ? 'S' : "",
        documentVersion: "",
        fileFrom: "userUpload,systemCreate",
        documentTypeList: []
      };
      InterfaceService.getContractInfo(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          // console.log(res);
          let list = [];
          let documentInfos = res.documentInfos || [];
          let attachListB = [];
          let attachListS = [];
          let hasPdf = documentInfos.some(item => {
            return item.documentType === 'dt_10_contract_profession' || item.documentType === 'dt_00_contract_profession'
          });
          documentInfos.forEach(file => {
            if (hasPdf) {
              // if (file.documentType === 'dt_10_contract_profession' || file.documentType === 'dt_00_contract_profession' || file.documentType === 'otherFile') {
              if (['dt_10_contract_profession', 'dt_00_contract_profession', 'dt_00_contract_common', 'dt_10_contract_common', 'otherFile'].indexOf(file.documentType) != -1) {
                list.push(file)
              }
            } else {
              list.push(file)
            }
          });
          list.forEach(item => {
            if (item.bs === 'S') {
              let onOff = false;
              attachListS.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOff = true
                }
              });
              if (!onOff) {
                attachListS.push(item)
              }
            } else if (item.bs === 'B') {
              let onOff = false;
              attachListB.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOff = true
                }
              });
              if (!onOff) {
                attachListB.push(item)
              }
            } else {
              let onOffB = false;
              let onOffS = false;
              attachListB.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOffB = true
                }
              });
              attachListS.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOffS = true
                }
              });
              if (!onOffB) {
                attachListB.push(item)
              }
              if (!onOffS) {
                attachListS.push(item)
              }
            }
          });
          if (this.role === 'S') {
            this.handleBatchDownload(attachListS, [], hasPdf)
          } else {
            this.handleBatchDownload(attachListS, attachListB, hasPdf)
          }
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    handleBatchDownload(attachList1, attachList2, hasPdf) {
      let fileInfoBeans = [];
      if (attachList1.length) {
        if (!hasPdf) {
          attachList1.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: item.documentName,
              fileUrl: item.attachUrl,
            })
          })
        } else {
          attachList1.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: (item.documentType.indexOf('profession') != -1 ? '合同专业版/' : item.documentType.indexOf('common') != -1 ? '合同通用版/' : '') + item.documentName,
              fileUrl: item.attachUrl,
            })
          })
        }
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl;
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: (attachList2.length ? this.contractNameCount : this.role == 'S' ? this.contractNameCount : (this.contractNameCount.replace('采购合同', '供应合同'))) + ".zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
                if (attachList2.length) {
                  this.handleBatchDownload(attachList2, [], hasPdf)
                }
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    getOrderTemplate() {
      const params = {
        orderNo: this.orderNo
      };
      InterfaceService.getOrderTemplate(params, data => {
        // let res = data.respData;
        // if (res.respCode === "0000") {
        // } else {
        // }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false });
    },
    close() {
      formList.constructionCompany = [
        {
          companyId: '',
          handleAcctId: '',
          contractSealer: '',
          contractSigner: '',
          authorizationFile: [],
          calculationFile: [],
          acctList: [],
        }
      ]
      this.form = { ...formList }
      this.$refs['form'].resetFields()
      this.showBox = false
      this.isShowMore = false
    },
    // purchaserId = corpId, 如果入参有 purchaserId 则以purchaserId为corpId 查询
    open(orderInfo, type, purchaserId) {
      // console.log(orderInfo);
      this.orderInfo = Object.assign({}, orderInfo);
      if (!this.orderInfo.addRate) {
        this.orderInfo.addRate = 10
      } else {
        this.orderInfo.addRate = NumberUtil.accMul(this.orderInfo.addRate, 100)
      }
      // this.orderInfo.addRate = '1'
      this.showBox = true
      // --------- 回显数据 start ----------
      this.form.inPmtMethod = this.orderInfo.inPmtMethod || ''
      this.form.constructionCostIndex = this.orderInfo.constructionCostIndex || ''
      this.form.amountCostIndex = this.orderInfo.amountCostIndex || ''
      this.form.targetCost = this.orderInfo.targetCost || ''
      this.form.groupLimit = this.orderInfo.groupLimit || ''
      this.form.projectId = this.orderInfo.projectId || ''
      this.form.projectStageCode = this.orderInfo.projectStageCode || ''
      this.form.building = this.orderInfo.building || ''
      this.form.projectName = this.orderInfo.projectName || ''
      this.form.purchaserId = purchaserId
      // this.form.bankAcctId = this.orderInfo.bankAcctId || ''
      this.form.contractName = this.orderInfo.contractName || ''
      // 采购商授权代表
      this.form.authorizationFile = []
      const authorizationFile = this.orderInfo && this.orderInfo.documentInfoList && this.orderInfo.documentInfoList.filter(i => i.documentType === 'authorityPM') || [] //采购商授权代表授权书
      if (authorizationFile.length) {
        authorizationFile.forEach(i => {
          // 授权书 - 如果没有 attachUrl 就不初始化值了, 防止保存的时候 保存一个空的数据回去
          if (i.attachUrl) {
            this.form.authorizationFile.push({
              attachName: i.documentName,
              viewUrl: i.attachUrl,
              fileTypeId: i.documentType,
              businessType: 'CONTRACT_FORMATION',
              attachUrl: i.documentUrl
            }) || []
          }
        })
      }
      this.form.comparePriceFileList = []
      const comparePriceFileList = this.orderInfo && this.orderInfo.documentInfoList && this.orderInfo.documentInfoList.filter(i => i.documentType === 'comparePrice') || [] //比价清单
      if (comparePriceFileList.length) {
        comparePriceFileList.forEach(i => {
          this.form.comparePriceFileList.push({
            attachName: i.documentName,
            viewUrl: i.attachUrl,
            fileTypeId: i.documentType,
            businessType: 'CONTRACT_FORMATION',
            attachUrl: i.documentUrl
          })
        })
      }
      this.form.otherFileList = []
      const otherFileList = this.orderInfo && this.orderInfo.documentInfoList && this.orderInfo.documentInfoList.filter(i => i.documentType === 'purchaserOtherFile') || [] //其他附件
      if (otherFileList.length) {
        otherFileList.forEach(i => {
          this.form.otherFileList.push({
            attachName: i.documentName,
            viewUrl: i.attachUrl,
            fileTypeId: i.documentType,
            businessType: 'CONTRACT_FORMATION',
            attachUrl: i.documentUrl
          })
        })
      }
      this.form.calculationFile = []
      console.log(this.form.calculationFile)
      const calculationFile = this.orderInfo && this.orderInfo.documentInfoList && this.orderInfo.documentInfoList.filter(i => i.documentType === 'contractOaHtqdgcljss') || []//采购商授权代表授权书
      if (calculationFile.length) {
        this.form.calculationFile = []
        calculationFile.forEach(i => {
          this.form.calculationFile.push({
            attachName: i.documentName,
            viewUrl: i.attachUrl,
            fileTypeId: i.documentType,
            businessType: 'CONTRACT_FORMATION',
            attachUrl: i.documentUrl
          })
        })
      }
      this.form.handleAcctId = this.handleSupRole('21')
      this.form.contractPrincipal = this.handleSupRole('23')
      this.form.contractSealer = this.handleSupRole('22')
      // this.form.contractSigner = this.handleSupRole('24')
      this.form.materialClerk = this.handleSupRole('28')
      this.form.sealManager = this.handleSupRole('29')
      // 施工单位
      if (this.orderInfo.constructionContent != '1') {
        this.form.constructionCompany = []
        const authorizationFile = this.orderInfo && this.orderInfo.documentInfoList && this.orderInfo.documentInfoList.filter(i => i.documentType === 'authorityConstructor') || [] //施工单位授权代表授权书
        const a = this.orderInfo.contractStakeHolders.filter(i => i.role == '00' && i.corpId && i.acctId) //授权代表
        const b = this.orderInfo.contractStakeHolders.filter(i => i.role == '01' && i.corpId && i.acctId) //项目经理
        const c = this.orderInfo.contractStakeHolders.filter(i => i.role == '02' && i.corpId && i.acctId) //项目盖章人
        a.forEach(i => {
          let obj = {}
          obj.companyId = i.corpId
          obj.corpName = i.corpName
          obj.handleAcctId = i.acctId
          obj.authorizationFile = []
          obj.acctList = []
          b.forEach(j => {
            if (i.corpId === j.corpId) {
              obj.contractSealer = j.acctId
            }
          })
          c.forEach(j => {
            if (i.corpId === j.corpId) {
              obj.contractSigner = j.acctId
            }
          })
          authorizationFile.forEach(j => {
            if (i.corpId === j.corpId) {
              obj.authorizationFile.push({
                attachName: j.documentName,
                viewUrl: j.attachUrl,
                fileTypeId: j.documentType,
                businessType: 'CONTRACT_FORMATION',
                attachUrl: j.documentUrl
              })
            }
          })
          this.form.constructionCompany.push(obj)
        })
        if (!this.form.constructionCompany.length) {
          this.form.constructionCompany = formList.constructionCompany
          // 施工单位暂无回显
          const a = this.orderInfo.contractStakeHolders.filter(i => i.role == '00' && i.exist === '1') //授权代表
          if (a.length) {
            this.form.constructionCompany[0].companyId = '暂无'
          }
        } else {
          this.form.constructionCompany.forEach(i => {
            this.getQuerySubordinate(i)
          })
        }
      }


      // this.addressId = this.orderInfo.addressId || ''
      // --------- 回显数据 end ----------
      if (type !== 'confirmContract') {
        this.getProjectList()
        // console.log(this.form.constructionCompany)
        this.contractCorpList = []
        this.form.constructionCompany.forEach(i=>{
          this.contractCorpList.push({
            corpName: i.corpName,
            corpId: i.companyId,
          })
        })
        // this.getStakeHolderCorp()
        this.getOrderConfiguration()
        this.getBankList()
        // this.getAddressList()
        this.getQuerySubordinate()
      }
    },
    // 采购商授权代表角色处理
    handleSupRole(role) {
      const a = this.orderInfo.contractStakeHolders.filter(i => i.role == role && i.acctId)
      if (a.length) {
        return a[0].acctId
      } else {
        return ''
      }
    },
    // handlerClientHeight() {
    //   console.log(window.innerHeight)
    //   if (window.innerHeight < 700) {
    //     this.$refs.confirmContract.style.height = '90vh'
    //   }
    // }
  },
  // mounted() {
  //   this.handlerClientHeight()
  // },
}
</script>
<style lang="scss" scoped>
/deep/ .right_padding {
  .el-input__inner {
    padding-right: 30px;
  }
  .suffix {
    color: #444;
    margin-right: 4px;
  }
}
/deep/ .seatchW-width {
  position: relative;
  &.el-col-24 {
    width: inherit;
    width: initial;
  }
  .el-form-item__content {
    width: 400px;
  }
}
/deep/ .el-select {
  width: 100% !important;
}
/deep/ .account {
  .el-form-item__label {
    width: 80px !important;
  }
  .el-form-item__content {
    margin-left: 80px !important;
  }
}
/deep/ .label-two {
  .el-form-item__label {
    line-height: 17px !important;
  }
}
.order-info-title {
  margin-bottom: 15px !important;
}
.solid {
  width: 100%;
  border-top: 1px solid #eeeeee;
}
.dashed {
  width: 100%;
  border-top: 1px dashed #eee;
}
.box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .confirmContract {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    height: 80%;
    overflow-x: hidden;
    overflow-y: auto;
    .content {
      width: 1190px;
      margin: 0 auto 100px;
      font-size: 14px;
      line-height: 17px;
      .title {
        padding: 20px 0;
        border-bottom: 1px solid #eee;
        margin-bottom: 20px;
      }
      .box-gray {
        padding: 15px 10px;
        font-size: 14px;
        line-height: 20px;
        background: #dddddd;
      }
      form {
        > h1 {
          margin-bottom: 20px;
          font-size: 14px;
          font-weight: 600;
          line-height: 20px;
          > span {
            font-weight: normal;
            margin: 0 20px 0 6px;
          }
          > i {
            font-weight: normal;
          }
        }
      }
      .address {
        display: flex;
      }
      // .address {
      //   width: 100%;
      //   > li {
      //     margin-bottom: 14px;
      //     > div {
      //       display: flex;
      //     }
      //     .left {
      //       width: 140px;
      //       border: 1px solid #dddddd;
      //       height: 50px;
      //       font-size: 14px;
      //       line-height: 50px;
      //       text-align: center;
      //     }
      //     .right {
      //       width: calc(100% - 140px);
      //       height: 50px;
      //       padding: 0 130px 0 10px;
      //       position: relative;
      //       > p {
      //         font-size: 14px;
      //         line-height: 50px;
      //         > i {
      //           display: inline-block;
      //           width: 17px;
      //           height: 17px;
      //           background: url("../../../assets/images/icon/check.png")
      //             no-repeat;
      //           background-size: contain;
      //           margin-left: 2px;
      //           visibility: hidden;
      //         }
      //       }
      //       > span {
      //         position: absolute;
      //         right: 10px;
      //         top: 16px;
      //         display: none;
      //         &.active {
      //           right: 90px;
      //         }
      //       }
      //     }
      //     &.active,
      //     &:hover {
      //       .left {
      //         background: linear-gradient(122deg, #d7b064 0%, #ecce8b 100%);
      //         color: #fff;
      //         border: none;
      //       }
      //       .right {
      //         border: 1px dashed #444;
      //         background-color: #f0f8ff;
      //         > p {
      //           > i {
      //             visibility: visible;
      //           }
      //         }
      //         > span {
      //           display: block;
      //         }
      //       }
      //     }
      //   }
      // }
      .enclosure {
        margin-bottom: 22px;
        .upload {
          /deep/ .el-input,
          input {
            position: absolute;
            left: -9999px;
            width: 0px;
            height: 0px;
            overflow: hidden;
            opacity: 0;
          }
        }
        /deep/ .el-form-item {
          margin-bottom: 0 !important;
          label {
            width: auto !important;
            line-height: 20px;
            font-size: 14px;
          }
        }
        /deep/ .el-form-item__label {
          color: #444 !important;
          text-align: left;
          width: auto !important;
        }
        /deep/ .el-form-item__content {
          position: relative;
          margin-left: 0 !important;
        }
        /deep/ .el-form-item__error {
          position: absolute;
        }
        .pickPepoleCardUrl {
          /deep/ .el-form-item__error {
            position: absolute;
          }
        }
        .biddingAuthorizationUrl {
          /deep/ .el-form-item__error {
            position: absolute;
          }
        }
        a {
          position: absolute;
        }
        /deep/ .enclosure-content {
          font-size: 12px;
          margin-top: 34px;
          width: 1190px;
          border: 1px solid rgba(221, 221, 221, 1);
          padding: 0 10px;
          // line-height: 45px;
          line-height: 17px;
          padding: 14px 10px;
          > div {
            margin-top: 14px;
            &:first-child {
              margin-top: 0px !important;
            }
          }
          // span {
          //   margin-right: 12px;
          // }
        }
        .tip-text {
          margin-top: 26px;
          line-height: 17px;
        }
        .has-text {
          margin-top: 5px;
        }
      }
    }
  }
}
.division-info {
  position: relative;
  margin-top: 20px;
  span {
    color: #888;
    font-size: 14px;
  }
}
.enclosure-content-division {
  width: 1190px;
  background: #ffffff;
  border: 1px solid #dddddd;
  padding: 10px;
  line-height: 17px;
  font-size: 12px;
  margin-top: 6px;
  p {
    margin-bottom: 10px;
  }
  p:last-of-type {
    margin-bottom: 0;
  }
}

.aegalAuthorizedClient {
  position: relative;
  /deep/ .el-form-item__label {
    position: absolute;
    margin-top: -7px;
  }
  &::after {
    content: "(法人代表或授权委托人)";
    position: absolute;
    width: 160px;
    text-align: right;
    color: #888;
    white-space: pre;
    left: -8px;
    top: 16px;
    font-size: 12px;
  }
  &.projectSigner {
    &::after {
      content: "(收发货公司项目章的电子用印人)";
      left: -26px;
    }
  }
  &.contractSealer {
    &::after {
      content: "(合同章电子用印人)";
      left: -9px;
    }
  }
}
.el-row {
  overflow: initial;
}

.resize-none-container {
  .resize-none {
    /deep/ .el-textarea__inner {
      resize: none;
      overflow: auto;
    }
    /deep/ .el-input__count {
      height: 40px;
      line-height: 40px;
    }
  }
}
</style>