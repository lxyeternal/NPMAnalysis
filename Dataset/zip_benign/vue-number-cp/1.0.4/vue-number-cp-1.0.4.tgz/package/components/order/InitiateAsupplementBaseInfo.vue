<template>
  <div class="confirmInitiate-body-com">
    <div class="contract-group bb0" v-if="configOption.base">
      <p class="order-info-title">基本信息</p>
      <ul class="recipient-information base-info">
        <li>
          <span> 合同名称：</span> <span> 《{{configOption.baseInfo.contractName}}》</span>
        </li>
        <li>
          <span> 合同类别：</span> <span class="red"> {{configOption.baseInfo.orderCateCode}}</span>
        </li>
        <li>
          <span> 供应商：</span> <span> {{configOption.baseInfo.corpName}}</span>
        </li>
        <li>
          <span>增补次数：</span> <span> 第{{configOption.baseInfo.subOrderListCount}}笔 </span>
        </li>
      </ul>
    </div>
    <div class="contract-name" v-if="configOption.name"><span>合同名称: </span> {{configOption.nameInfo && configOption.nameInfo.mainContractName}} <i class="blue" @click="handleSeeDetails(configOption.nameInfo.mainOrderNo)"> 查看详情</i></div>
    <div class="contract-group" v-if="configOption.price">
      <p class="order-info-title">增补商品价款</p>
      <div class="introduction-center" v-if="configOption.priceInfo">
        <ul>
          <li>
            <span> 增补商品价款(税前)：</span> <span> {{configOption.priceInfo.pretaxPrice | formatMoney}} 元</span>
            <span v-if="configOption.priceInfo.computeAllFreightText"> (含税前运费: ￥{{ Math.abs(configOption.priceInfo.computeAllFreightText) | formatMoney}}) </span>
          </li>
          <li>
            <span> 税率：</span> <span> {{configOption.priceInfo.taxRate}} </span>
          </li>
          <li>
            <span> 增补商品价款(含税)：</span> <span class="red"> {{configOption.priceInfo.afterTaxPrice | formatMoney}} 元 </span>
          </li>
          <li>
            <span> 税额：</span> <span> {{configOption.priceInfo.prodTax | formatMoney}} 元</span>
          </li>
        </ul>
      </div>
    </div>
    <div class="contract-group bb0" v-if="configOption.address">
      <p class="order-info-title">收货地址</p>
      <ul class="recipient-information">
        <li>
          <span> 收货地址：</span> <span> {{configOption.addressInfo && configOption.addressInfo.consigneeAddr || ''}}</span>
        </li>
        <li>
          <span> 收货人：</span> <span> {{configOption.addressInfo && configOption.addressInfo.consigneeName}}&nbsp;{{configOption.addressInfo && configOption.addressInfo.consigneeMobile}}</span>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import { NumberUtil } from '@/utils/numberUtil'
export default {
  props: {
    configOption: {
      type: Object,
      default() {
        return {
          base: false,
          baseInfo: {},
          name: true,
          nameInfo: {},
          price: true,
          priceInfo: {},
          address: true,
          addressInfo: {},
        }
      }
    }
  },
  data() {
    return {
      isLoading: false,
      projectCateList: []
    };
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
    },
    handleSeeDetails(orderNo) {
      window.open(this.$router.resolve({
        path: '/orderDetail',
        query: {
          orderNo,
        }
      }).href, '_blank')
    },
  }
};
</script>

<style lang="scss" scoped>
.confirmInitiate-body-com {
  .mt20 {
    margin-top: 20px;
  }
  .bb0 {
    border-bottom: 0 !important;
  }
  .head-title {
    height: 50px;
    line-height: 50px;
    position: relative;
    border-bottom: 2px solid #ffd64e;
    background-color: #f5f5f5;
    color: #4f525a;
    span {
      position: absolute;
      padding: 0 24px;
      left: 0;
      border-bottom: 2px solid #444;
      font-size: 14px;
      font-weight: bold;
      height: 50px;
    }
  }
  .contract-name {
    font-size: 12px;
    color: #444;
    padding: 20px 0px;
    border-bottom: 1px solid #eee;
    span {
      color: #999;
    }
    i {
      font-style: normal;
      cursor: pointer;
    }
  }
  .contract-group {
    border-bottom: 1px solid #eee;
    .order-info-title {
      margin: 20px 0 10px;
      padding: 0 10px;
      font-size: 14px;
      border-left: 3px solid #000;
      line-height: 12px;
    }
    .introduction-center {
      background: #fef4f3;
      padding: 0 8px 12px;
      margin-bottom: 20px;
      ul {
        display: flex;
        flex-wrap: wrap;
        li {
          width: 50%;
          margin-top: 12px;
          font-weight: bold;
        }
      }
    }
    .recipient-information {
      &.base-info {
        li {
          span {
            &:first-child {
              color: #000;
            }
          }
        }
      }
      li {
        margin-top: 14px;
        span {
          &:first-child {
            color: #999;
          }
        }
      }
    }
  }
}
</style>
