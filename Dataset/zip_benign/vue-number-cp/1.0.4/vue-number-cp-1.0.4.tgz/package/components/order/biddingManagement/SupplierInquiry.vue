<template>
  <div class="supplierInquiry">
    <div class="list-home">
      <div class="list-content">
        <div class="panel-switch">
          <ul>
            <li class="hand" :class="{active: publishStatus=='ANNOUNCED'}" @click="publishStatus='ANNOUNCED';clear();">待回复</li>
            <li class="hand" :class="{active: publishStatus=='PUBLISH'}" @click="publishStatus='PUBLISH';clear();">已回复</li>
          </ul>
        </div>
        <div class="panel">
          <el-form class="form" size="small" label-width="80px">
            <el-row>
              <el-col :span="24">
                <el-form-item label="询标主题：">
                  <el-input v-model.trim="theme" placeholder="请输入关键词" maxlength="200" clearable></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row v-show="publishStatus=='ANNOUNCED'">
              <el-col :span="24">
                <el-form-item label="回复截止情况：" class="business">
                  <el-radio-group v-model="replyExpiredFlg" @change="search()">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'1'">未截止</el-radio>
                    <el-radio :label="'2'">已截止</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24" class="form-btns" align="center">
                <el-button class="btn" type="primary" size="small" @click="search()">搜索</el-button>
                <el-button class="btn" size="small" @click="clear()">清除</el-button>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <div class="list-box">
          <el-row class="button-panel" v-if="publishStatus=='ANNOUNCED'">
            <el-col :span="24">
              <el-checkbox v-model="checkboxAll" :disabled="!inquireList.length" style="margin: 0 10px" @change="checkboxChange">全选</el-checkbox>
              <el-button class="btn" :disabled="isDisabled || !inquireList.length" :class="{'isDisabled':isDisabled || !inquireList.length}" size="small" @click="batchSend">批量发送</el-button>
            </el-col>
          </el-row>
          <table>
            <thead>
              <tr>
                <td width="20px" v-if="publishStatus=='ANNOUNCED'"></td>
                <td width="68px">序号</td>
                <td width="800px">询标函主题</td>
                <td width="160px">{{publishStatus=='ANNOUNCED'?'回复截止时间':'回复时间'}}</td>
                <td width="110px">操作</td>
              </tr>
            </thead>
            <tbody v-for="(a,ind) in inquireList" :key="ind" class="tbody-row">
              <tr>
                <td v-if="publishStatus=='ANNOUNCED'">
                  <el-checkbox v-model="a.checkbox" @change="checkboxChangeOne" :disabled="a.buttonFlg != '1' || !isDeadline(a.deadLine)"></el-checkbox>
                </td>
                <td>
                  {{ind+1}}
                </td>
                <td>
                  {{a.theme}}
                </td>
                <td v-if="publishStatus=='ANNOUNCED'">
                  {{a.deadLine&&a.deadLine.split(' ')[0]}}
                </td>
                <td v-else>
                  {{a.responseTm&&a.responseTm.split(' ')[0]}}<br />
                  {{a.responseTm&&a.responseTm.split(' ')[1]}}
                </td>
                <td>
                  <p v-if="publishStatus=='ANNOUNCED' && a.buttonFlg == '0' && isDeadline(a.deadLine) && nodePlan=='INQUIRY_BID' && buyersNodePlan!='CONFIRM_BID'" class="hand blue" @click="goReplyInquiryLetter(a.supplierBidInquireNo,'1')">回复</p>
                  <p v-if="publishStatus=='ANNOUNCED' && a.buttonFlg == '1' && isDeadline(a.deadLine) && nodePlan=='INQUIRY_BID' && buyersNodePlan!='CONFIRM_BID'" class="hand blue" @click="goReplyInquiryLetter(a.supplierBidInquireNo,'2')">编辑</p>
                  <p v-if="publishStatus=='ANNOUNCED' && a.buttonFlg == '1' && isDeadline(a.deadLine) && nodePlan=='INQUIRY_BID' && buyersNodePlan!='CONFIRM_BID'" class="hand blue" @click="supplierSendReply([a.supplierBidInquireNo],'2','0');supplierBidInquireNo=a.supplierBidInquireNo">发送</p>
                  <p v-if="publishStatus=='PUBLISH'" class="hand blue" @click="goReplyInquiryLetter(a.supplierBidInquireNo,'3')">查看</p>
                </td>
              </tr>
            </tbody>
          </table>
          <!-- 空列表 -->
          <div class="accout-empty" v-if="!inquireList.length">
            <img src="@/assets/images/icon-no-product.png">
            <p>暂无回复问题！</p>
          </div>
          <!-- 分页 -->
          <div class="table-pagination" v-if="inquireList.length">
            <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
            </el-pagination>
          </div>
        </div>
      </div>
    </div>
    <!--  单次回复弹框 -->
    <el-dialog class="dialog dialog-drafts" :title="isProblem?'发送询标函':'发送回复询标函'" :append-to-body="true" :lock-scroll="true" :visible.sync="showBulletBox1" width="840px" center :close-on-click-modal="false">
      <div class="drafts-list tc">{{isProblem?'你有未回复的问题，请先去回复，若直接点击【确认发送】按钮即视作放弃回答相应问题。':'请检查该询标函问题均已回复，若无误，点击【确认发送】按钮即可。'}}</div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="supplierSendReply([supplierBidInquireNo],'2','1')">确认发送</div>
        <div class="clearBtn" @click="goReplyInquiryLetter(supplierBidInquireNo,'2')">编辑</div>
        <div class="clearBtn" @click="showBulletBox1=false">取消</div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import { viewFile } from '@/utils/orderUtil';

export default {
  components: {
    Loading,
  },
  data() {
    return {
      isLoading: false,
      checkboxAll: false,
      isDisabled: true, // 批量操作是否置灰
      publishStatus: 'ANNOUNCED', // 回复状态 //PUBLISH 已回复  ANNOUNCED 未回复
      theme: '',
      replyExpiredFlg: '',
      inquireList: [],

      isProblem: false,
      showBulletBox1: false,
      supplierBidInquireNo: '',//供应商询标函编号
      frequency: '', // 批量发送询标函的次数

      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码

      bidNo: '',//	招标编号	
    };
  },
  methods: {
    isDeadline(time) {
      // ie10不兼容2016-06-18,兼容2016/06/18
      let a = time.replace(/-/g, "/")
      let datetime = new Date()
      let year = datetime.getFullYear();
      let month = datetime.getMonth() + 1 < 10 ? "0" + (datetime.getMonth() + 1) : datetime.getMonth() + 1;
      let date = datetime.getDate() < 10 ? "0" + datetime.getDate() : datetime.getDate();
      let b = year + '/' + month + '/' + date
      // let a = new Date(time).getTime()
      // b = new Date(b).getTime()
      console.log(a, b)
      if (a >= b) {
        return true
      } else {
        return false
      }
    },
    search() {
      this.pageIndex = 1
      this.supplierInquiry()
    },
    clear() {
      this.pageIndex = 1;
      this.theme = ''
      this.replyExpiredFlg = ''
      this.supplierInquiry()
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.supplierInquiry()
    },
    // 去回复页面
    goReplyInquiryLetter(supplierBidInquireNo, type) {
      let url = ''
      if (type == '3') {
        url = 'viewReplyInquiryLetter'
      } else {
        url = "/replyInquiryLetter"
      }
      window.open(this.$router.resolve({
        path: url,
        query: {
          'supplierBidInquireNo': supplierBidInquireNo,
          'isPage': type,
          'isSupplyPicture': this.isSupplyPicture,
          'bidNo': this.bidNo,
          'obj': encodeURIComponent(JSON.stringify(
            {
              bidNo: this.bidNo,
              submitBidNo: this.submitBidNo,
              type: this.$route.query.type || '',
              tab: this.$route.query.tab || '',
            }
          ))
        }
      }).href, '_blank')
    },
    // 采购商问题收集列表on
    supplierInquiry() {
      let param = {
        submitBidNo: this.submitBidNo, //	招标编号	
        publishStatus: this.publishStatus,
        theme: this.theme,
        replyExpiredFlg: this.replyExpiredFlg,
        pageIndex: this.pageIndex
      }
      InterfaceService.supplierInquiry(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.inquireList = data.respData.inquireList || []
          this.inquireList.forEach(i => {
            this.$set(i, 'checkbox', false)
          });

          this.total = data.respData.totalCount
          this.pageSize = data.respData.pageSize

          this.checkboxAll = false
          this.isDisabled = true
          window.scrollTo(0, 0)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },

    // 全选
    checkboxChange() {
      this.inquireList.forEach(i => {
        if (i.buttonFlg == '1' && this.isDeadline(i.deadLine)) {
          this.$set(i, 'checkbox', this.checkboxAll)
        }
      });
      let a = this.inquireList.some(i => i.checkbox === true)
      if (a) {
        this.checkboxAll = true
      } else {
        this.checkboxAll = false
      }
      this.isDisabled = !this.checkboxAll
    },
    // 单选
    checkboxChangeOne() {
      const a = this.inquireList.filter(i => i.checkbox == true)
      if (!a.length) {
        this.isDisabled = true
        this.checkboxAll = false
      } else {
        this.isDisabled = false
        if (a.length != this.inquireList.length) {
          this.checkboxAll = false
        } else {
          this.checkboxAll = true
        }
      }
    },
    // 批量发送
    batchSend() {
      const a = this.inquireList.filter(i => i.checkbox == true)
      if (!a.length) {
        this.$message('请勾选')
        return
      }
      let list = []
      a.forEach(i => {
        list.push(i.supplierBidInquireNo)
      });
      this.frequency = a.length
      this.supplierSendReply(list, '1', '0')
    },
    // 供应商发送回复函
    supplierSendReply(supplierBidInquireNos, type, isChecked) {
      let param = {
        supplierBidInquireNos: supplierBidInquireNos,
        isChecked: isChecked // 是否忽略未回复的询标问题 1:忽略   0:不忽略
      }
      InterfaceService.supplierSendReply(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {

          let noReplyCnt = data.respData.noReplyCnt || 0
          let failFlg = data.respData.failFlg
          if (noReplyCnt > 0 && failFlg == '1') {
            this.showBulletBox1 = false
            if (type == '1') {
              this.$message('勾选的' + this.frequency + '份询标函中有' + noReplyCnt + '份询标函内附件已上传,问题未回复,请去编辑询标函。')
            } else {
              this.$confirm(
                '勾选的' + this.frequency + '份询标函中有' + noReplyCnt + '份询标函内附件已上传,问题未回复,请点击【编辑】按钮去编辑询标函。',
                '批量发送回复询标函',
                {
                  cancelButtonClass: "btn-custom-cancel",
                  confirmButtonClass: "btn-custom-confirm",
                  center: true,
                  dangerouslyUseHTMLString: true,
                  type: 'warning',
                  confirmButtonText: "编辑",
                  cancelButtonText: '取消',
                }).then(() => {
                  this.goReplyInquiryLetter(this.supplierBidInquireNo, '2')
                }).catch(() => {
                });
            }
            return
          }
          if (noReplyCnt > 0 && failFlg == '0') {
            this.showBulletBox1 = false
            if (type == '1') { //批量
              this.$confirm(
                '勾选的' + this.frequency + '份询标函中有' + noReplyCnt + '份询标函内问题未回复，请检查并完善内容，若直接点击【确认发送】按钮即视作放弃回答相应问题。',
                '批量发送回复询标函',
                {
                  cancelButtonClass: "btn-custom-cancel",
                  confirmButtonClass: "btn-custom-confirm",
                  center: true,
                  dangerouslyUseHTMLString: true,
                  type: 'warning',
                  confirmButtonText: "确认发送",
                  cancelButtonText: '取消',
                }).then(() => {
                  this.supplierSendReply(supplierBidInquireNos, '1', '1')
                }).catch(() => {
                });
            } else {
              // 二次询问
              this.isProblem = true
              this.showBulletBox1 = true
            }
            return
          }
          if (isChecked == '0') {
            if (type == '1') {
              this.$confirm(
                '请确认勾选的' + this.frequency + '份询标函内容均已回复，若无误，点击【发送】按钮即可。',
                '批量发送回复询标函',
                {
                  cancelButtonClass: "btn-custom-cancel",
                  confirmButtonClass: "btn-custom-confirm",
                  center: true,
                  dangerouslyUseHTMLString: true,
                  type: 'warning',
                  confirmButtonText: "确认发送",
                  cancelButtonText: '取消',
                }).then(() => {
                  this.supplierSendReply(supplierBidInquireNos, '1', '1')
                }).catch(() => {
                });
            } else {
              this.isProblem = false
              this.showBulletBox1 = true
            }

          } else {
            this.showBulletBox1 = false
            this.publishStatus = 'PUBLISH'
            this.$message.success('发送成功')
            this.supplierInquiry()
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    init() {
      this.publishStatus = this.$route.query.publishStatus || 'ANNOUNCED'
      if (!!this.$getRootLocalStorage('publishStatus')) {
        this.publishStatus = this.$getRootLocalStorage('publishStatus')
        this.$removeRootLocalStorage('publishStatus')
      }
      this.submitBidNo = this.$route.query.submitBidNo || ''
      this.bidNo = this.$route.query.bidNo || ''
      this.supplierInquiry()
    },
  },
  mounted() {
    this.init()
  },
  props: ['nodePlan', 'buyersNodePlan', 'isSupplyPicture'],
};
</script>

<style lang="scss" scoped>
/deep/ .el-select {
  width: 100% !important;
}

/deep/ .business {
  .el-form-item__label {
    width: 110px !important;
  }
  .el-form-item__content {
    margin-left: 110px !important;
  }
}
/deep/ .el-row .el-col span {
  color: inherit;
}
.el-row label {
  width: auto;
}
.supplierInquiry {
  padding-bottom: 60px;
  .list-home {
    width: 1190px;
    margin: 0 auto;
    .box_steps {
      padding: 20px 0 30px;
      box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
    }
    .list-content {
      margin: 10px 0;
      // tab栏
      .panel-switch {
        width: 100%;
        height: 40px;
        background-color: #f5f5f5;
        padding-right: 10px;
        margin-bottom: 6px;
        display: flex;
        justify-content: space-between;
        > ul {
          height: 100%;
          display: flex;
          li {
            padding: 0 17px;
            font-size: 14px;
            font-weight: 600;
            line-height: 20px;
            color: #888;
            position: relative;
            margin-right: 6px;
            line-height: 40px;
            &.active {
              color: #444;
            }
            &.active::before {
              content: "";
              width: 50%;
              height: 3px;
              background: rgba(201, 159, 79, 1);
              position: absolute;
              left: 25%;
              bottom: 4px;
            }
          }
        }
      }
      // 搜索面板
      .panel {
        background: rgba(249, 249, 249, 1);
        padding: 20px 10px 20px 0px;
        .el-button + .el-button {
          margin-left: 18px;
        }
      }
      // 列表
      .list-box {
        margin-top: 10px;
        table {
          margin-top: 10px;
          table-layout: fixed;
          width: 100%;
          line-height: 23px;
          font-size: 12px;
          td {
            padding: 16px 10px;
            vertical-align: middle;
            word-break: break-all;
            &:last-child {
              text-align: right;
            }
          }

          thead {
            font-size: 14px;
            text-align: left;
            white-space: nowrap;
            border-bottom: 1px solid #eee;
            background: rgba(249, 249, 249, 1);
            color: rgba(136, 136, 136, 1);
            tr {
              td {
                padding: 13px 10px;
                &:last-child {
                  text-align: right;
                }
              }
            }
          }
          .tbody-row {
            &:hover {
              background: #f0f8ff;
            }
          }
          tbody {
            text-align: left;
            tr {
              border-bottom: 1px solid #eee;
            }
            .border-none {
              border-bottom: none;
            }
          }
        }
      }
    }
  }
}
.el-select {
  width: 100%;
}
.btn {
  width: 80px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  padding: 0;
}

// 空数据
.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}

.searchbox {
  text-align: center;
  margin-top: 20px;
  display: flex;
  justify-content: center;
  .searchBtn {
    width: 120px;
    height: 34px;
    line-height: 34px;
    background: linear-gradient(
      122deg,
      rgba(215, 176, 100, 1) 0%,
      rgba(236, 206, 139, 1) 100%
    );
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(255, 255, 255, 1);
    display: inline-block;
    cursor: pointer;
  }
  .clearBtn {
    width: 120px;
    margin-left: 20px;
    height: 34px;
    line-height: 32px;
    border: 1px solid rgba(201, 159, 79, 1);
    font-size: 12px;
    font-family: PingFang SC;
    color: rgba(201, 159, 79, 1);
    display: inline-block;
    cursor: pointer;
  }
}
</style>
