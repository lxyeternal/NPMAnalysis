<template>
  <div class="page">
    <!--<p>{{nodePlan}}</p>-->
    <div class="tips">
      <!-- 祝贺您已中标，请下载中标文件，完善其内容，并上传加盖公司公章的中标扫描文件，扫描件以PDF格式上传。 -->
      祝贺您已中标，请电子签章中标文件后再提交。
    </div>
    <div class="bidding-info">
      中标函
    </div>
    <div style="padding-bottom: 30px;border-bottom: 1px solid #eee;">
      <span>《{{bidTitle}}集中采购中标函》<span class="f12 blue hand" style="margin-left: 10px" @click="viewBidLetter()">查看中标函</span><span class="f12 blue hand" style="margin-left: 10px" @click="handleOpenWinningDetail">查看中标公示</span></span>
    </div>
    <div class="bidding-info">
      价格信息
    </div>
    <div style="padding-bottom: 30px;border-bottom: 1px solid #eee;">
      <label class="grey">价格有效期：</label>
      <span>{{enterBidInfo.priceEffectiveStartDate}} ~ {{enterBidInfo.priceEffectiveEndDate}}</span>
    </div>
    <div class="bidding-info" style="margin-bottom: 15px;">中标文件</div>
    <div style="padding-bottom: 20px;border-bottom: 1px solid #eee;">
      <el-row class="bid-file" v-if="confirmBidTemplateList.length">
        <el-col v-for="(a,index) in confirmBidTemplateList" :key="index+'confirmBidTemplate'" :span="12" style="margin-bottom: 10px">
          <label class="grey">中标文件{{index+1}}：</label>
          <span>
            《{{a.attachName}}》
            <span :class="a.supplierSignStatus === '1' ? 'green' : 'red'">{{a.supplierSignStatus === '1' ?'（已签章）': '（未签章）'}}</span>
            <span class="hand blue" style="margin-left: 6px" @click="handleView(a.attachUrl)">查看</span>
            <span class="hand blue" style="margin-left: 6px" @click="handleDownload(a.attachName, a.attachUrl)">下载文件</span>
          </span>
        </el-col>
      </el-row>
    </div>

    <template v-if="enterBidInfo && enterBidInfo.contactUrl">
      <div class="bidding-info">
        采购经理通讯录
      </div>
      <div style="padding-bottom: 30px;border-bottom: 1px solid #eee;">
        <span>{{enterBidInfo.contactFileName}}</span>
        <span class="f12 blue hand" style="margin-left: 10px" @click="handleView(enterBidInfo.contactUrl)">查看</span>
        <span class="f12 blue hand" style="margin-left: 10px" @click="handleDownload(enterBidInfo.contactFileName, enterBidInfo.contactUrl)">下载</span>
      </div>
    </template>

    <div class="bidding-info" style="margin-bottom: 15px;">附件</div>
    <div class="f14 upload">
      其他附件
      <template v-if="nodePlan === 'AWARDED' || nodePlan === 'INCOMING'">
        <input :id="'otherFiles'" type="file" @change="handleUpload($event,'40')">
        <label class="hand blue f12 pl10" :for="'otherFiles'">上传</label>
      </template>
    </div>
    <div class="enclosure-content" v-if="otherFilesList.length">
      <div v-for="(item,index) in otherFilesList" :key="index">
        <b>{{item.attachName}}</b>
        <span class="hand blue" @click="handleView(item.attachUrl)">预览</span>
        <span class="hand blue" @click="handleDownload(item.attachName,item.attachUrl)">下载</span>
        <span class="hand blue" @click="handleDel('40',item,index)" v-if="nodePlan === 'AWARDED' || nodePlan === 'INCOMING'">删除</span>
      </div>
    </div>
    <div class="grey enclosure-content" v-else>
      未上传附件！
    </div>
    <!-- <div style="margin-top: 60px;margin-bottom: 188px;text-align: center" v-if="nodePlan === 'AWARDED' || nodePlan === 'INCOMING'">
      <el-button type="primary" style="width: 260px;height: 50px;" @click="handleSubmit" :disabled="!cooperationFileAttachUrl || !contractFileAttachUrl">提交</el-button>
    </div> -->
    <FixBottom class="bottom" v-if="!computedIsSigna || enterBidInfo.uploadConfirmattachFlag != 1">
      <div class="tc">
        <el-button type="primary" @click="handleSubmit" :disabled="computedIsSubmit" v-if=" this.enterBidInfo.uploadConfirmattachFlag != 1">确认提交</el-button>
        <el-button type="primary" v-if="!computedIsSigna" @click="showBullet=true">电子签章中标文件</el-button>
      </div>
    </FixBottom>
    <!-- 电子签章中标文件 -->
    <el-dialog class="dialog dialog-drafts" title="确认签章文件" :append-to-body="true" :lock-scroll="true" :visible.sync="showBullet" width="840px" center :close-on-click-modal="false" @close="isContract=false">
      <div class="drafts-list">
        <el-form class="form" size="small">
          <p class="f12 tc">请确认勾选需要签章的中标附件，点击【下一步】即可。</p>
          <div class="content">
            <el-row class="tl">
              <el-col class="tl" v-if="isSigna('58')">
                <el-checkbox :value="true" disabled><span class="f14" style="color: #444">《战略框架协议》</span></el-checkbox>
              </el-col>
              <el-col class="tl" v-if="isSigna('60')">
                <el-checkbox :value="true" disabled><span class="f14" style="color: #444">《廉洁合作协议书》</span></el-checkbox>
              </el-col>
              <el-col class="tl" v-if="isSigna('59')">
                <el-checkbox v-model="isContract"><span class="f14" style="color: #444">《采购合同通用条款》<span class="grey">（不供货的厂家，可不用签章该文件）</span></span></el-checkbox>
              </el-col>
            </el-row>
          </div>
        </el-form>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <el-button class="normal-btn" size="small" type="primary" :disabled="computedhandleSign" @click="handleSign()">下一步</el-button>
        <el-button class="normal-btn" size="small" @click="showBullet=false">取消</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
    <!-- 查看中标函或感谢函 -->
    <ViewBidLetter ref="viewBidLetter"></ViewBidLetter>
  </div>
</template>

<script>
import { viewFile } from '@/utils/orderUtil';
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import ViewBidLetter from "@/components/tender/dialog/ViewBidLetter";
import FixBottom from "@/components/base/FixBottom";

export default {
  name: "SupplierWinningBid",
  props: ["bidName", "nodePlan", 'ibBidCategoryInfos'],
  computed: {
    computedIsSubmit() {
      let result = !(this.handleConfirmBidTemplate('58') && this.handleConfirmBidTemplate('60'))
      return result
    },
    computedIsSigna() {
      const result = this.handleConfirmBidTemplate('58') && this.handleConfirmBidTemplate('60') && this.handleConfirmBidTemplate('59')
      return result
    },
    computedhandleSign() {
      let result = true
      const a = this.handleConfirmBidTemplate('58')
      const b = this.handleConfirmBidTemplate('60')
      const c = this.handleConfirmBidTemplate('59')
      if ((!a || !b) || ((a && b) && !c && this.isContract)) {
        result = false
      }
      return result
    },
  },
  data() {
    return {
      isLoading: false,
      bidNo: "",
      submitBidNo: "",

      cooperationFileAttachUrl: "",
      cooperationFilePath: "",
      cooperationFileOssFileId: "",
      contractFileName: "",
      contractFileAttachUrl: "",
      contractFilePath: "",
      contractFileOssFileId: "",
      otherFilesList: [],
      confirmBidTemplate: [],
      confirmBidTemplateList: [],
      enterBidInfo: {},
      delList: [],
      submitAttachs: [],
      showBullet: false,
      isContract: false,
      bidTitle: '',
      enterBidNo: '',
    }
  },
  components: {
    Loading, ViewBidLetter, FixBottom
  },
  methods: {
    handleOpenWinningDetail() {
      window.open(this.$router.resolve({
        path: "/bidBulletinDetail",
        query: {
          bidNo: this.bidNo,
          enterBidNo: this.enterBidNo,
          type: '1',
        },
      }).href, '_blank')
    },
    viewBidLetter() {
      let info = {
        supplierCorpName: this.$store.state.userInfo.corpName,
        ibBidCategoryInfos: this.ibBidCategoryInfos,
        year: this.enterBidInfo.bidStartYear + '~' + this.enterBidInfo.bidEndYear + '年度',
        publishTime: this.enterBidInfo.publishTime || '',
        corpId: this.enterBidInfo.corpId,
        remark: this.enterBidInfo.remark
      }
      this.$refs.viewBidLetter.open(info)
    },
    confirmBidTemplateFilter() {
      let list = []
      let attachTypeList = ['42', '43', '57'] //word
      let attachTypePDFList = ['58', '59', '60'] //PDF
      if (!this.confirmBidTemplate.length) return []
      attachTypePDFList.forEach((item, index) => {
        if (this.handleConfirmBidTemplate(item)) {
          list.push(this.confirmBidTemplate.find(i => i.attachType === item))
        } else {
          list.push(this.confirmBidTemplate.find(i => i.attachType === attachTypeList[index]))
        }
      })
      console.log(list)
      return list
    },
    handleConfirmBidTemplate(attachType) {
      console.log(this.confirmBidTemplate, '-confirmBidTemplate');

      return this.confirmBidTemplate.some(i => i.attachType === attachType && i.supplierSignStatus === '1')
    },
    isSigna(attachType) {
      return !this.confirmBidTemplateList.some(i => i.attachType === attachType && i.supplierSignStatus === '1')
    },
    handleSign() {
      const list = this.confirmBidTemplate.filter(i => i.attachType === '58' || i.attachType === '59' || i.attachType === '60')
      if (list.length !== 3) {
        this.generateSignaBidFile()
      } else {
        this.goBidSignPreview()
      }
    },
    goBidSignPreview() {
      this.$router.push({
        path: "/bidSignPreview",
        query: {
          isContract: String(this.isContract),
          bidNo: this.bidNo,
          submitBidNo: this.submitBidNo,
          bidName: this.bidName,
          enterBidNo: this.enterBidNo,
          submitBidStatus: this.$route.query.submitBidStatus || '',
          type: this.$route.query.type || '',
          tab: '4',
          publishStatus: this.$route.query.publishStatus || '',
        },
      })
    },
    // 生成待签章中标附件
    generateSignaBidFile() {
      let params = {};
      let confirmBidFileList = ['42', '57']
      if (this.isContract) {
        confirmBidFileList.push('43')
      }
      params = {
        bidNo: this.bidNo,
        submitBidNo: this.submitBidNo,
        confirmBidFileList: confirmBidFileList,
      };
      InterfaceService.generateSignaBidFile(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            this.goBidSignPreview()
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { }, () => { this.isLoading = true; }, () => { this.isLoading = false; }
      );
    },
    handleSubmit() {
      this.$confirm(
        '<p class="tl">请确认未漏签需要签章的中标附件（《战略合作协议》、《廉洁合作协议书》、《采购合同通用条款》），点击【确认提交】即可。</p>',
        '提交中标文件',
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确认提交",
          cancelButtonText: '取消',
        }).then(() => {
          this.submitWinningBidFies('1')
        }).catch(() => {
        });
    },
    submitWinningBidFies(handleType) {
      let enterBidAttachInfos = [];
      this.otherFilesList.forEach(item => {
        if (!item.ossFileId) {
          enterBidAttachInfos.push({
            attachType: "40",
            attachPath: item.attachPath,
            attachName: item.attachName,
          })
        }
      });
      enterBidAttachInfos = enterBidAttachInfos.concat(this.delList);
      const params = {
        enterBidAttachInfos,
        bidNo: this.bidNo,
        submitBidNo: this.submitBidNo,
        handleType: handleType,
        enterBidNo: this.enterBidNo,
      };
      console.log(params);
      InterfaceService.submitWinningBidFies(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            this.$message.success(handleType === '0' ? '上传成功' : "提交成功！");
            this.delList = [];
            this.getSupplierWinningBidDetail()
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    handleView(url) {
      viewFile(url)
    },
    handleDownload(name, url) {
      let attach = [];
      attach.push({
        url: url,
        name: name
      });
      this.$download(attach).then(res => {
        this.$message.success("已下载");
      }).catch(res => {
        this.$message.error("下载失败");
      })
    },
    handleDel(type, item, index) {
      if (type === "40") {
        if (item.ossFileId) {
          this.delList.push({ ossFileId: item.ossFileId })
        }
        this.otherFilesList.splice(index, 1)
      }
    },
    handleUpload(e, type) {
      const file = e.target.files[0];
      if (file) {
        this.uploadContractToOss(type, file).then(res => {
          let param = {
            ossFile: [{
              fileType: type, filePath: res.url
            }],
            appName: "PROD"
          };
          InterfaceService.ossSignatureUrl(param, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              let list = data.respData.ossFile || [];
              if (type === "40") {
                this.otherFilesList.push({
                  attachName: file.name,
                  attachPath: res.url,
                  attachUrl: list[0].url,
                })
                this.submitWinningBidFies('0')
              }
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        })
        e.value = "";
      }
    },
    uploadContractToOss(type, file) {
      return new Promise((resolve, reject) => {
        InterfaceService.getOssSignatureDisposable(file.name,{
          type: type,
          appName: "PROD",
        }, (data) => {
          let signature = data;
          this.uploadHander(0, file, new Date().getTime() + '/', signature, (pos, file, dirType, signature) => {
            let u = signature.dir + dirType + file.name;
            resolve({ url: u });
          }, () => { this.isLoading = true; }, () => { this.isLoading = false; })
        }, (data) => {
        },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          });
      })

    },
    uploadHander(pos, file, dirType, signature, callBack, loadingStartCb, loadingEndCb) {
      //去后端拿签名
      InterfaceService.uploadToOss(signature, file, dirType, pos, callBack, '', '', loadingStartCb, loadingEndCb)
    },
    getSupplierWinningBidDetail() {
      InterfaceService.getSupplierWinningBidDetail(
        {
          bidNo: this.bidNo,
          submitBidNo: this.submitBidNo,
          enterBidNo: this.enterBidNo
        },
        data => {
          if (data.respData.respCode === "0000") {
            let res = data.respData || {};
            this.confirmBidTemplate = res.confirmBidTemplate || [];
            this.confirmBidTemplateList = this.confirmBidTemplateFilter()
            this.enterBidInfo = res.bidEnterAttachBean || [];
            this.submitAttachs = res.submitAttachs || [];
            this.otherFilesList = [];
            this.submitAttachs.forEach(item => {
              if (item.attachType === "40") {
                this.otherFilesList.push({
                  attachName: item.attachName,
                  attachUrl: item.attachUrl,
                  ossFileId: item.ossFileId,
                })
              }
            })

            // 获取中标函名称
            setTimeout(() => {
              let category;
              if (this.ibBidCategoryInfos && this.ibBidCategoryInfos.length) {
                if (this.ibBidCategoryInfos.length == 1) {
                  category = this.ibBidCategoryInfos[0].categoryLevelTwoName
                } else {
                  let a = []
                  this.ibBidCategoryInfos.forEach(i => {
                    a.push(i.categoryLevelThreeName)
                  });
                  a = [...new Set(a)]
                  category = a.join('、')
                }
              }
              // const winBidcorpInfo = this.$winBidcorpInfo().find(i => i.corpId === this.enterBidInfo.corpId) || {}
              const year = this.enterBidInfo.bidStartYear + '~' + this.enterBidInfo.bidEndYear + '年度'
              // this.bidTitle = winBidcorpInfo.corpNameBrief + year + category
              this.bidTitle = '绿地建材集团' + year + category
            }, 300)
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => {
          this.$message.error(data.respData.respMsg);
        },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    init() {
      this.getSupplierWinningBidDetail()
    }
  },
  mounted() {
    this.bidNo = this.$route.query.bidNo || "";
    this.submitBidNo = this.$route.query.submitBidNo || "";
    this.enterBidNo = this.$route.query.enterBidNo || "";
    this.init()
  }
}
</script>

<style scoped lang="scss">
.dialog-drafts {
  .content {
    margin: 22px 0 0 225px;
    .el-col {
      margin-top: 9px;
    }
  }
}
.page {
  padding-bottom: 60px;
}
.tips {
  width: 100%;
  height: 30px;
  line-height: 30px;
  margin-top: -10px;
  padding-left: 10px;
  background: rgba(255, 252, 240, 1);
  border: 1px solid rgba(250, 226, 165, 1);
}
.bidding-info {
  margin: 20px 0 10px;
  padding: 0 10px 0 4px;
  font-size: 14px !important;
  border-left: 3px solid #444;
  line-height: 12px;
  font-weight: bold;
  color: #444;
}
.upload {
  /deep/ .el-input,
  input {
    position: absolute;
    left: -9999px;
    width: 0px;
    height: 0px;
    overflow: hidden;
    opacity: 0;
  }
  .pl6 {
    padding-left: 6px;
  }
  .pl10 {
    padding-left: 10px;
  }
}
.enclosure-content {
  font-size: 12px;
  width: 1190px;
  border: 1px solid #ddd;
  padding: 13px 10px;
  line-height: 17px;
  margin-top: 10px;
  margin-bottom: 20px;
  div {
    margin-bottom: 10px;
  }
  div:last-child {
    margin-bottom: 0;
  }
  b {
    margin-right: 6px;
  }
  span {
    margin-right: 10px;
  }
}
.required {
  &::before {
    content: "*";
    color: #f56c6c;
  }
}
.bid-file {
  > .el-col {
    &:nth-child(2n) {
      padding-left: 120px;
    }
  }
}
</style>