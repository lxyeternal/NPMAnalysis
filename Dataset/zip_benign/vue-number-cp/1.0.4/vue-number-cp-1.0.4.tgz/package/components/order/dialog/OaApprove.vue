<template>
  <div>
    <!-- 提交招标文件审批 -->
    <el-dialog custom-class="dialog-box" :title="'提交合同审批'" :append-to-body="true" :lock-scroll="true" :visible.sync="showBulletBox1" width="840px" center :close-on-click-modal="false" @close="close()">
      <div class="drafts-list tl">
        <el-form class="form" size="small" label-width="100px" :model="formDialog" :rules="rulesDialog" ref="formBulletBox1">
          <p class="f12 tc">{{content}}</p>
          <el-row>
            <el-col :span="24">
              <el-form-item :label="label+'：'" prop="approveId">
                <el-input :placeholder="'请输入' + label" v-model="formDialog.approveId" clearable maxlength="32"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <div class="uploadFileList">
            <div class="title-info tl">
              <p>{{fileLabel}}</p>
              <DownloadAndUpload :hasDownloadFlg='false' :fromId="'OaApprove'" :uploadType="fileType" :appName="appName" @outputValue="outputValue"></DownloadAndUpload>
            </div>
            <div class="fileList">
              <p class="noData" v-if="!formDialog.files.length">未上传附件！</p>
              <p v-for="(item,index) in formDialog.files" :key="index+'formDialog'">{{item.attachName}}<DownloadAndView :format="false" :viewName="'预览'" :downloadName="'下载'" :paddingLeft="'6px'" :attachUrl="item.attachUrl" :attachName="item.attachName"></DownloadAndView>
                <!-- <span class="hand blue" @click="handleDel(index)">删除</span> -->
              </p>
            </div>
          </div>
        </el-form>
      </div>
      <div slot="footer" class="searchbox" style="margin-top: 0px">
        <div class="searchBtn" @click="handleSubmit()">确认提交</div>
        <div class="clearBtn" @click="showBulletBox1=false;close()">取消</div>
      </div>
      <Loading :is-loading="isLoading"></Loading>
    </el-dialog>
  </div>
</template>
<script>
import DownloadAndView from '@/components/order/DownloadAndView'
import DownloadAndUpload from "@/components/base/DownloadAndUpload";
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
export default {
  components: {
    DownloadAndView, DownloadAndUpload, Loading
  },
  props: {
    orderNo: {
      type: String,
      default: ''
    },
    content: {
      type: String,
      default: ''
    },
    label: {
      type: String,
      default: ''
    },
    fileLabel: {
      type: String,
      default: ''
    },
    fileType: {
      type: String,
      default: ''
    },
    appName: {
      type: String,
      default: 'PROD'
    }
  },
  data() {
    let formDialog = {
      approveId: '',
      files: [],
    }
    return {
      isLoading: false,
      showBulletBox1: false,
      delList: [],
      formDialog: { ...formDialog },
      rulesDialog: {
        approveId: [
          { required: true, message: '必填', trigger: 'blur' }
        ],
      },
    }
  },
  methods: {
    outputValue(data) {
      let obj = {
        fileUrl: data.attachPath,
        attachName: data.attachName,
        attachUrl: data.attachUrl,
        attachType: this.fileType,
      }
      if (this.formDialog.files.length) {
        this.formDialog.files.splice(0, 1)
      }
      this.formDialog.files.push(obj)
    },
    // handleDel(index) {
    //   if (this.formDialog.files[index].ossFileId) {
    //     this.delList.push(this.formDialog.files[index])
    //   }
    //   this.formDialog.files.splice(index, 1)
    //   this.$message.success('已删除')
    // },
    handleSubmit() {
      this.$refs['formBulletBox1'].validate((valid) => {
        if (valid) {
          this.supplierOaApprove()
        } else {
          console.log('error submit!!');
          return false
        }
      });
    },
    supplierOaApprove() {
      let approveAcctName = this.$store.state.userInfo.acctName || ''
      let approveAttachInfos = []

      this.formDialog.files.forEach(i => {
        approveAttachInfos.push({
          attachPath: i.fileUrl,
          attachName: i.attachName,
          attachType: i.attachType,
        })
      })
      const params = {
        approveId: this.formDialog.approveId,
        orderNo: this.orderNo,
        approveName: '',
        approveAcctName: approveAcctName,
        approveType: '1',
        approveAttachInfos: approveAttachInfos,
      };
      InterfaceService.supplierOaApprove(
        params,
        data => {
          if (data.respData.respCode == "0000") {
            this.$message.success('提交成功')
            this.$emit('upDate', 'submit')
            this.showBulletBox1 = false
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { }, () => { this.isLoading = true }, () => { this.isLoading = false }
      );
    },
    open() {
      this.showBulletBox1 = true
    },
    close() {
      this.formDialog.files = []
      this.$refs['formBulletBox1'].resetFields();
    },
  },
}
</script>
<style lang="scss" scoped>
// 对话框
/deep/ .dialog-box {
  .el-dialog__body {
    padding-bottom: 0 !important;
  }
  .el-dialog__footer {
    padding: 20px;
  }
  .el-form-item--small.el-form-item {
    margin-bottom: 30px !important;
  }
  .drafts-list {
    .f12.tc {
      margin-bottom: 18px;
    }
  }
  .uploadFileList {
    margin: 0;
    > .title-info {
      font-size: 14px;
      line-height: 20px;
      color: rgba(68, 68, 68, 1);
      > p {
        display: inline-block;
        & + p {
          font-size: 12px;
          color: #888;
          line-height: 17px;
          display: block;
          margin-top: 6px;
        }
      }
      > span {
        font-size: 12px;
        margin-right: 10px;
        & + p {
          font-size: 12px;
          color: #888;
          line-height: 17px;
          display: block;
          margin-top: 6px;
        }
      }
    }
    .fileList {
      width: 100%;
      border: 1px solid rgba(221, 221, 221, 1);
      padding: 0 10px 14px 10px;
      margin: 4px 0 0px;
      > p {
        margin-top: 14px;
        font-size: 12px;
        line-height: 17px;
        color: rgba(68, 68, 68, 1);
        &.noData {
          color: #bbb;
        }
        > span {
          margin-right: 10px;
          &:first-child {
            margin-left: 6px;
          }
        }
      }
    }
  }
  .searchbox {
    text-align: center;
    margin-top: 20px;
    display: flex;
    justify-content: center;
    .searchBtn {
      width: 120px;
      height: 34px;
      line-height: 34px;
      background: linear-gradient(
        122deg,
        rgba(215, 176, 100, 1) 0%,
        rgba(236, 206, 139, 1) 100%
      );
      font-size: 12px;
      font-family: PingFang SC;
      color: rgba(255, 255, 255, 1);
      display: inline-block;
      cursor: pointer;
    }
    .clearBtn {
      width: 120px;
      margin-left: 20px;
      height: 34px;
      line-height: 32px;
      border: 1px solid rgba(201, 159, 79, 1);
      font-size: 12px;
      font-family: PingFang SC;
      color: rgba(201, 159, 79, 1);
      display: inline-block;
      cursor: pointer;
    }
  }
}
</style>