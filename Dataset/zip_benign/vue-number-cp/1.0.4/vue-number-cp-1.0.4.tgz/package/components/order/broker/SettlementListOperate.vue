<template>
    <div>
        <el-button type="primary" v-if="tab == 1" @click="handleOpenDetail(item)">审批</el-button>
        <el-button v-if="tab == 1 && settlementRole && (!item.status || item.status == 'canceled' || item.status == 'rejected')" @click="handleClose(item)">关闭</el-button>
        <el-button v-if="tab == 3 && settlementRole && item.status == 'processing'" @click="handleCancel(item)">撤回</el-button>
        <div v-if="tab == 4 || tab == 3"><span  class="blue hand" @click="handleOpenDetail(item)">查看详情</span></div>
        <div v-if="item.executionId"><span class="blue hand" @click="handleBatchDownload(item)">审批资料下载</span></div>
        <!--关闭审批-->
        <el-dialog class="dialog" title="关闭原因" :append-to-body="true" :lock-scroll="true" :visible.sync="closeApproavlDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;closeReason = ''">
            <div class="line-top"></div>
            <div class="f14" style="text-align: left;margin-bottom: 10px;">关闭后，系统会将关闭原因反馈给合同创建人。</div>
            <div class="f14" style="text-align: left">请填写关闭原因：</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="closeReason" placeholder="请填写关闭原因,300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button :disabled="!closeReason" type="primary" size="small" style="width: 100px" @click="handleCloseConfirm(item)">提交关闭</el-button>
                <el-button size="small" style="width: 100px" @click="closeApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>
<script>
    import accountMixin from "@/mixins/account";
    import { InterfaceService } from "@/services/api";
    import Loading from "@/components/base/Loading";

    export default {
        mixins: [accountMixin],
        name: "SettlementListOperate",
        props:["item","tab"],
        data() {
            return {
                entryNum:0,
                closeReason:"",
                closeApproavlDialogVisible:false,
                isLoading:false,
            }
        },
        components: {
            Loading,
        },
        computed: {
            // 是否显示批注
            isShowAnnotation() {
                return (item) => {
                    let mapState = false, state = false;
                    this.$store.state.userInfo.roleIds.map(mapItem => {
                        if(mapItem.roleId == item.fwRole) {
                            mapState = true
                        }
                    })
                    if (this.tab == 1 && mapState && item.fwStatus == '3') {
                        state = true
                    }
                    return state;
                }

            }
        },
        methods:{
            handleCancel(item) {
                this.$confirm(
                    "确认要撤回合同审批？撤回后的合同，在【待处理】中查看。",
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认撤回",
                        cancelButtonText: '取消',
                    }).then(() => {
                    this.handleCanceledConfirm(item)
                }).catch(() => {
                });
            },
            // 关闭流程弹窗
            handleClose(){
                this.closeApproavlDialogVisible = true;
            },
            handleEntry(ev){
                this.entryNum = ev.length
            },
            //  确认关闭
            handleCloseConfirm(item){
                let params = {
                        executionId : item.executionId,
                        procDefKey: item.closeProcDefKey,
                        comment: this.closeReason,
                    };
                InterfaceService.closeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("关闭成功");
                            this.closeApproavlDialogVisible = false;
                            this.$emit("refresh",true);
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            //  确认撤回
            handleCanceledConfirm(item){
                const params = {
                    executionId : item.executionId
                };
                InterfaceService.revokeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("撤回成功");
                            this.$emit("refresh",true);
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            // 查看详情
            handleOpenDetail(item) {
                let executionId = item.executionId,
                    orderNo = item.orderNo,
                    procDefKey = item.procDefKey;

                const { href } = this.$router.resolve({
                    path: "/settlementApprovalDetail",
                    query: {
                        executionId,
                        orderNo,
                        procDefKey,
                    },
                });
                window.open(href, '_blank');
            },
            //资料下载
            handleBatchDownload(item) {
                if (item.executionId) {
                    const params = {
                        executionId: item.executionId,
                        procDefKey:item.procDefKey
                    };
                    InterfaceService.approvalDataDownload(
                        params,
                        data => {
                            if (data.respData.respCode === "0000") {
                                let packingUrl = data.respData.attachUrl || "";
                                if (!packingUrl){
                                    this.$message.error("暂无资料！");
                                    return
                                }
                                window.open(packingUrl, "_blank");
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        },
                        data => {},
                        () => {
                            this.isLoading = true;
                        },
                        () => {
                            this.isLoading = false;
                        }
                    )
                }
            },
            handleCloseApproval(bool) {
                if (bool) {
                    this.$emit("refresh",true)
                }
            },
        },
        mounted() {
        }
    }
</script>

<style  lang="scss" scoped>
    /deep/.textareaContainer {
    .el-textarea__inner {
        min-height: 140px !important;
    }
    }
</style>