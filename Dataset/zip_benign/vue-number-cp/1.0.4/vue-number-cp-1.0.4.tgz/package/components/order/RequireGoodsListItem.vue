<template>
  <div>
    <div class="list-content" :ref="'thead'">
      <table class="table-default">
        <thead>
        <tr>
          <td width="368px">商品名称/型号</td>
          <td width="240px" class="tr"><span class="required">要货总量</span></td>
          <td width="240px" class="tr">已供货数量</td>
          <td width="242px" class="tr">实际验收数量</td>
          <td width="100px" class="tr"></td>
        </tr>
        </thead>
        <tbody v-for="(item,ind) in goodsList" :key="ind" class="tbody-row" v-if="goodsList.length" style="border-bottom: 1px solid #eee;">
        <tr style="border-bottom: none">
          <td>
            <div class="thumbnail fl" :style="{background:item.attUrl || item.picUrl ? 'url('+(item.attUrl || item.picUrl)+')' : '#eee'}"></div>
            <div :ref="'goodsHeight' + ind" class="fr" style="margin-left: 6px;width: 290px;">
              <p :title="item.skuName" class="goods-name hover-underline hand" @click="handleGoproduct(item)">{{item.skuName}}</p>
              <p style="margin-top: 10px;">型号：{{item.model}}</p>
              <!--<p class="fixed" v-if="item.type == '1'">固定组价商品</p>-->
              <p class="new-goods" v-if="item.isNewCom == '1'">新组价商品
                <el-popover popper-class="dark-popover" trigger="hover" placement="right">
                  <div style="color: #fff;width: 185px;">
                    新组价商品是指，代理商创建合同时，新组的商品。
                  </div>
                  <i slot="reference"><em class="triangle-topright"></em></i>
                </el-popover>
              </p>
              <p class="tag" v-if="item.isCombination=='1' && item.isNewCom !== '1'">组价商品</p>
              <p class="tag bg-lightSteelBlue" v-if="item.surchargeDetailList && item.surchargeDetailList.length">含附加项</p>
            </div>
          </td>
          <td class="tr"><span class="C99F4F">{{computedReq(item,'requireCount') | formatMoney}}{{item.goodsUnit}}</span></td>
          <td class="tr"><span class="C99F4F">{{computedReq(item,'deliveryCount') | formatMoney}}{{item.goodsUnit}}</span></td>
          <td class="tr">
            <template v-if="item.details.filter(i=>{return String(i.totalreceivdCount)}).length">
              <span class="C99F4F">{{computedReq(item,'totalreceivdCount') | formatMoney}}{{item.goodsUnit}}</span>
            </template>
            <template v-else>
              -
            </template>
          </td>
          <td></td>
        </tr>
        <tr>
          <td colspan="5" style="padding: 0!important;">
            <table class="deliver-table">
              <tbody v-for="(det,_ind) in item.details">
              <tr v-if="det.location">
                <td v-if="_ind === 0" width="80px" class="bold" style="color: #C99F4F;padding-left: 5px!important;">使用标段：</td>
                <td v-else width="80px"></td>
                <td width="288px" style="border-top:  1px dashed #eee;"><span class="bold">{{det.label}}：</span>{{det.location}}</td>
                <td class="tr" style="border-top:  1px dashed #eee;">{{det.requireCount | formatMoney}}{{item.goodsUnit}}</td>
                <td class="tr" style="border-top:  1px dashed #eee;">{{det.deliveryCount | formatMoney}}{{item.goodsUnit}}</td>
                <td class="tr" style="border-top:  1px dashed #eee;" v-if="String(det.totalreceivdCount)">{{det.totalreceivdCount | formatMoney}}{{item.goodsUnit}}</td>
                <td class="tr" style="border-top:  1px dashed #eee;" v-else>-</td>
                <td width="100px"></td>
              </tr>
              <tr v-if="det.remark">
                <td width="80px"></td>
                <td class="tl" colspan="5"><span class="bold">要货备注：</span>{{det.remark}}</td>
              </tr>
              <tr v-if="det.checkDescription">
                <td width="80px"></td>
                <td class="tl" colspan="5"><span class="bold">验收情况：</span>{{det.checkDescription}}</td>
              </tr>
              </tbody>
            </table>
          </td>
        </tr>
        <tr class="material-description" v-if="item.surchargeDetailList && item.surchargeDetailList.length"  style="border-bottom: none;">
          <!--<td colspan="2"></td>-->
          <td colspan="8" class="additional-items">
            <span class="desc-title">附加项说明：</span>
            <p v-for="(add,index) in item.surchargeDetailList":style="{'margin-bottom' : index < item.surchargeDetailList.length - 1 ? '10px' : '0'}">
              附加项{{index + 1}}：{{add.surchangeName}}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;X{{add.surchangeUnitCnt}}{{add.surchangeUnit}} &nbsp;&nbsp;&nbsp;&nbsp;<span style="color: #9452ff;">￥{{comupSurchangeUnitPrice(add.surchangeUnitPrice,add.surchangeUnitCnt) | formatMoney}}</span>
            </p>
          </td>
          <td></td>
        </tr>
        <tr class="material-description" v-if="item.itemDescription" style="border-bottom: none;">
          <!--<td colspan="2"></td>-->
          <td colspan="8" class="additional-items">
            <span class="desc-title">物料描述：</span>
            <p>{{item.itemDescription}}</p>
          </td>
          <td></td>
        </tr>
        <tr class="material-description" v-if="item.details && item.details.some(i=>{return i.attachList.filter(fil=>{return fil.attachType ==='0'}).length})"  style="border-bottom: none;" >
          <!--<td colspan="2"></td>-->
          <td colspan="8" class="additional-items" style="padding-bottom: 4px!important;">
            <span class="desc-title">要货附件：</span>
            <p v-for="(file,i) in item.details" class="file-content">
              <template v-if="file.attachList.filter(fil=>{return fil.attachType ==='0'}).length">
                {{file.label}}：
                <span v-for="(f,_f) in file.attachList.filter(fil=>{return fil.attachType ==='0'})">{{f.attachName}} <em class="blue-pointer" style="padding-left: 6px;" @click="handleDownload(f.attachName,f.attachUrl)">下载</em></span>
              </template>
            </p>
            <span class="desc-title blue-pointer" style="right: 10px;top: 14px;font-weight: normal" @click="handleBatchDownload(item,'0')">批量下载</span>
          </td>
          <td></td>
        </tr>
        <tr class="material-description" v-if="item.details && item.details.some(i=>{return i.attachList.filter(fil=>{return fil.attachType ==='2'}).length})"  style="border-bottom: none;" >
          <!--<td colspan="2"></td>-->
          <td colspan="8" class="additional-items" style="padding-bottom: 4px!important;">
            <span class="desc-title">验收附件：</span>
            <p v-for="(file,i) in item.details" class="file-content">
              <template v-if="file.attachList.filter(fil=>{return fil.attachType ==='2'}).length">
                {{file.label}}：
                <span v-for="(f,_f) in file.attachList.filter(fil=>{return fil.attachType ==='2'})">{{f.attachName}} <em class="blue-pointer" style="padding-left: 6px;" @click="handleDownload(f.attachName,f.attachUrl)">下载</em></span>
              </template>
            </p>
            <span class="desc-title blue-pointer" style="right: 10px;top: 14px;font-weight: normal" @click="handleBatchDownload(item,'2')">批量下载</span>
          </td>
          <td></td>
        </tr>
        </tbody>
      </table>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
  import accountMixin from "@/mixins/account";
  import { NumberUtil } from '@/utils/numberUtil';
  import { InterfaceService } from '@/services/api'
  import Loading from '@/components/base/Loading'
  import TableThead from "@/components/base/TableThead";

  export default {
    mixins: [accountMixin],
    props: ["orderInfo","showAddrInfo","goodsItem",'updateFlg','updateHeight'],
    components:{
      Loading,
      TableThead,
    },
    data() {
      return {
        goodsList:[],
        isLoading:false,
        hasDeliverFlg:false,
        pageSize:20,
        total:0,
        pageIndex:1,
        theadHeigth:0,
      };
    },
    computed:{
      comupSurchangeUnitPrice() {
        return function (price,num) {
          return Number(NumberUtil.accMul(price,+num))
        }
      },
      computedReq() {
        return function (item,type) {
          let num = '';
          item.details.forEach(det=>{
            num = Number(NumberUtil.numAdd(num,+det[type]))
          });
          return num
        };
      }
    },
    watch: {
      updateHeight(newVal) {
        if (newVal) {
          this.$nextTick(()=>{
            console.log(this.$refs.thead.offsetTop,this.$refs.thead.offsetHeight);
            if (this.$refs.thead) {
              this.theadHeigth = this.$refs.thead.offsetTop
            }
          })
        }
      },
      updateFlg(newVal) {
        if (newVal){
          this.getOrderRequireGoodsList();
        }
      },
      goodsItem: {
        handler(val) {
          this.goodsItem = val || "";
          if (Object.keys(this.goodsItem).length) {
            this.goodsList = [];
            this.goodsList.push(this.goodsItem)
          }
        },
        immediate: true,
        deep: true
      }
    },
    methods: {
      handleBatchDownload(item,type) {
        let fileInfoBeans = []
        item.details.forEach(det=>{
          det.attachList.forEach(a=>{
            if (a.attachType === type) {
              fileInfoBeans.push({
                archivePath:`${det.label}/` + a.attachName,
                fileUrl: a.attachUrl
              })
            }
          })
        })
        this.packageDownload(fileInfoBeans, `${item.skuName || '打包下载附件'}${type === '0' ? '要货单附件' : '验收单附件'}.zip`)
      },
      packageDownload(fileInfoBeans, fileName) {
        if (!(fileInfoBeans && fileInfoBeans.length)) return
        let params = {
          fileInfoBeans: fileInfoBeans,
          protocol: "https",
        };
        InterfaceService.packageDownload(
          params,
          data => {          let res = data.respData || {};
            if (data && data.respData && res.respCode === "0000") {
              const files = [
                { name: fileName, url: res.externalFileUrl }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              })
              this.dialogVisible = false;
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => {
            this.$message.error(data.respData.respMsg)
          }, () => {
            this.isLoading = true
          }, () => {
            this.isLoading = false
          })
      },
      handleGoproduct(item) {
        window.open(this.$router.resolve({
          path: "/productDetails",
          query: {
            spuId: item.spuId,
            corpId: item.corpId,
            skuId: item.skuId
          }
        }).href, '_blank')
      },
      handleDownload(name,url) {
        this.$download([{
          name: name || '',
          url: url || ''
        }]).then(result => {
          this.$message.success('已下载')
        }).catch(err => {
          this.$message.error('下载失败')
        })
      },
      getOrderRequireGoodsList() {
        InterfaceService.getOrderRequireGoodsList(
          {
            requireNo : this.orderInfo.requireNo,
            orderDetailIds: [],
            pageIndex: this.pageIndex,
          },
          data => {
            if (data.respData.respCode == '0000') {
              this.goodsList = [];
              let attachList = data.respData.attachList || [];
              JSON.parse(JSON.stringify(data.respData.requireList || [])).forEach(item=>{
                let onOff= false;
                this.goodsList.forEach(g=>{
                  if (+g.orderDetailId == +item.orderDetailId) {
                    onOff = true
                  }
                });
                if (!onOff) {
                  this.goodsList.push(item)
                }
              })
              this.goodsList.forEach(g=>{
                this.$set(g,'details',[])
                JSON.parse(JSON.stringify(data.respData.requireList || [])).forEach(item=>{
                  if (+g.orderDetailId == +item.orderDetailId) {
                    g.details.push({
                      requireCount:item.requireCount,
                      deliveryCount:item.deliveryCount,
                      goodsUnit : item.goodsUnit,
                      skuId : item.skuId,
                      orderDetailId : item.orderDetailId,
                      location:item.location,
                      attachList: [],
                      label: "",
                      remark:item.remark,
                      checkDescription:item.checkDescription,
                      operFlg:"Update",
                      id:item.id,
                      model:item.model,
                      fromId : ''+Math.random(),
                    })
                  }
                })
              });
              this.goodsList.forEach((item,ind)=>{
                attachList.forEach(att=>{
                  item.details.forEach((_item,_ind)=>{
                    _item.label = '标段' + (_ind + 1)
                    if (att.requireDetailId === _item.id) {
                      _item.attachList.push({
                        attachUrl : att.attachUrl,
                        attachName : att.attachName,
                        viewUrl : att.attachUrl,
                        requireDetailId : att.requireDetailId,
                        attachId :att.attachId,
                        attachType : '0',
                      })
                    }
                  })
                });
              });
              this.hasDeliverFlg = this.orderInfo.requireStatus >= '07' && this.orderInfo.requireStatus <= '18'
              console.log(this.goodsList);
              this.pageSize = data.respData.pageSize;
              this.total = data.respData.totalCount;
              this.$emit('goodsLength',this.total);
              // this.$nextTick(()=>{
              //   this.goodsList.forEach((item,index)=>{
              //     console.log(this.$refs['goodsHeight' + index][0].offsetHeight);
              //     this.$set(item,'firstTdHeight',this.$refs['goodsHeight' + index][0].offsetHeight + 28)
              //   })
              // })
              //其他附件
              let list = [];
              attachList.forEach(item=>{
                if (item.attachType === '4') {
                  list.push(item)
                }
              })
              this.$emit('otherFiles',list)
            } else {
              this.$message.error(data.respData.respMsg);
            }
          },
          data => {
          },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          }
        );
      },
    },
    mounted() {
      if (Object.keys(this.goodsItem).length) {
        this.goodsList = [];
        this.goodsList.push(this.goodsItem)
      } else {
        this.getOrderRequireGoodsList()
      }
      this.$nextTick(()=>{
        console.log(this.$refs.thead.offsetTop,this.$refs.thead.offsetHeight);
        if (this.$refs.thead) {
          this.theadHeigth = this.$refs.thead.offsetTop
        }
      })
      console.log(this.theadHeigth);
    }
  };
</script>

<style lang="scss" scoped>
  .address-content{
    margin-top: -10px;
    margin-bottom: 20px;
    background: #FFE9EB;
    border: 1px solid #DB7575;
    padding: 10px 10px 0;
    /deep/ .el-col{
      margin-bottom: 10px;
    }
    label{
      color: #888;
    }
  }
  .table-default{
    margin-top: 0;
    td{
      padding: 14px 5px !important;
    }
    table{
      td{
        padding: 14px 5px !important;
      }
    }
  }
  .list-content {
    width: 1190px;
    margin: 0 auto 20px;
    table {
      table-layout: fixed;
      width: 100%;
      line-height: 17px;
      font-size: 12px;
      td {
        table{
          td{
            vertical-align: middle !important;
          }
        }
        padding: 16px 10px 10px;
        vertical-align: middle !important;
        word-break: break-all;
        position: relative;
        .error-msg{
          position: absolute;
          right: 10px;
          margin-top: 6px;
        }
        .add-flg{
          position: absolute;
          left: 10px;
          margin-top: 6px;
        }
        .thumbnail{
          width: 60px;
          height: 60px;
          background: #eee;
        }
        .goods-name {
          width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
        }
        .fixed,.new-goods{
          position: relative;
          overflow: hidden;
          width: 100px;
          margin-top: 6px;
          height: 20px;
          line-height: 20px;
          background: #6598D3;
          text-align: center;
          font-size: 14px;
          color: #fff;
          border-radius: 2px;
        }
        .new-goods {
          background: #FF7D1D;
          .triangle-topright {
            width: 28px;
            height: 70px;
            position: absolute;
            background: #313131;
            top: -54px;
            right: -50px;
            -webkit-transform: rotate(45deg);
            transform: rotate(45deg);
          }
        }
        i{
          position: absolute;
          right: 16px;
          top: 50%;
          margin-top: -9px;
        }
        > p {
          line-height: 17px;
          & + p {
            margin-top: 4px;
          }
        }
      }
      .pt38{
        padding-top: 38px!important;
      }
      thead {
        font-size: 14px;
        text-align: left;
        white-space: nowrap;
        background: #f9f9f9;
        color: #888;
        border-bottom: 1px solid #eee;
      }
      .tbody-row {
        &:hover {
          background: #f0f8ff;
        }
      }
      tbody {
        text-align: left;
        /*.notice-td{*/
        /*background: #FFE9EB;*/
        /*padding: 6px 10px;*/
        /*}*/
        tr {
          border-bottom: 1px solid #eee;
        }
        .border-none {
          border-bottom: none;
        }
        .material-description{
          td{
            /deep/ .el-input{
              input{
                height: 34px;
              }
            }
          }
        }
      }
    }
    .deliver-table {
      tr{
        border: none!important;
        td{
          padding: 5px!important;
        }
      }
    }
  }
  .additional-items{
    border-top: 1px dashed #eee;
    font-size: 12px;
    .desc-title{
      font-weight: bold;
      position: absolute;
      color: #C99F4F;
    }
    div{
      padding-left: 72px;
    }
    p{
      padding-left: 72px;
    }
  }
  .file-content{
    padding-right: 100px;
    span{
      display: inline-block;
      padding-right: 40px;
    }
  }
  .table-pagination{
    margin: 0 0 35px;
    /deep/ .el-input {
      width: 50px;
    }
  }
  .bid-section {
    margin-left: 50px;
    em {
      margin-left: -48px;
    }
  }
  .C99F4F{
    color: #C99F4F;
  }
</style>
