<template>
  <div class="reques-information-container">
    <dl :class="{mt0: isView}" v-for="(item,idx) in billInfoList.filter(f=>!f.hide)" :key="idx">
      <dt v-if="!isView"><span><i class="red" v-if="item.require">*</i>{{item.name}}</span>
        <UpfileComponent ref="upfileRef" :btnName="'上传'" :immediateClearList="true" :immediateSubmit="true" :showMsg="false" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :dirName="dirNameComputed" :type="'12'" :id="'id'" @outputList="outputUpfileList($event, item)" />
      </dt>
      <dd v-if="item && item.list && item.list.length">
        <p v-for="(cItem, cIdx) in item.list || []" :key="cIdx">
          <font>
            {{cItem.deliveryName || cItem.requireName || cItem.statementName || cItem.receiptFileName || cItem.receiptFileName }}
            <span class="blue" v-if="cItem.attachUrl" @click="handlePreview(cItem)">预览</span>
            <span class="blue" v-if="cItem.attachUrl" @click="handleDownload(cItem)">下载</span>
            <span class="blue" v-if="!cItem.receiptNo && !isView" @click="handleDel(item.list, cIdx)">删除</span>
          </font>
          <font class="accName">
            <span>{{cItem.acctName || ''}} {{cItem.acctName &&  cItem.acctName != '系统生成' ? '上传' : ''}} &emsp; {{cItem.creTm || ''}}</span>
          </font>
        </p>
      </dd>
      <dd v-else-if="!isView">
        <p class="txt-center">暂无附件</p>
      </dd>
    </dl>
  </div>
</template>
<script>
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
export default {
  components: { UpfileComponent },
  props: ['dirNameComputed', 'billInfoList', 'isView'],
  mounted() {
  },
  methods: {
    outputUpfileList(ev, item) {
      this.$emit('outputList', ev, item)
    },
    handlePreview(item) {

      let encodeUrl = encodeURIComponent(item.attachUrl);
      const officeOpenTypeList = [".docx", ".dotx", ".doc", ".xlsx", ".xlsb", ".xlsm", ".xls", ".pptx", ".ppsx", ".ppt", ".pps", ".potx", ".ppsm"];
      let officeOpen = false;
      let userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
      let isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; //判断是否IE<11浏览器
      let isEdge = userAgent.indexOf("Edge") > -1 && !isIE; //判断是否IE的Edge浏览器
      let isIE11 = userAgent.indexOf('Trident') > -1 && userAgent.indexOf("rv:11.0") > -1;
      let IE = false;
      if (isIE || isEdge || isIE11) {
        IE = true
      } else {
        IE = false  //不是ie浏览器
      }
      officeOpenTypeList.some(item => {
        if (encodeUrl.indexOf(item) != -1) {
          return officeOpen = true
        }
      });

      if (officeOpen && !IE) {
        window.open("https://view.officeapps.live.com/op/view.aspx?src=" + encodeUrl, "_blank");
      } else {
        // 加KEY 解决 预览后 下载 跨域报错 bug
        this.$openWindow(`${item.attachUrl}&key=preview`)
      }
    },

    handleDownload(item) {
      const url = item.attachUrl,
        suffix = url.slice(url.lastIndexOf('.'), url.lastIndexOf('?'))
      this.$download([{
        url,
        name: `${item.deliveryName || item.requireName || item.statementName || item.receiptFileName}`
      }]).then(() => {
        this.$message.success("已下载");
      });
    },
    handleDel(itemList, index) {
      this.$emit('outputDelItem', itemList, index)
    },
  }

}
</script>
<style lang="scss" scoped>
.reques-information-container {
  dl {
    margin-top: 20px;
    &.mt0 {
      margin-top: 0;
    }
    dt {
      display: flex;

      span:not(.blue) {
        font-weight: bold;
        margin-right: 4px;
      }
      .blue {
        cursor: pointer;
      }
    }
    dd {
      margin-top: 12px;
      border: 1px solid #eee;
      padding: 6px 12px 12px;
      p {
        margin-top: 8px;
        display: flex;
        justify-content: space-between;
        transition: all .3s linear;
        font {
          &.accName {
            color: #777;
            float: right;
          }
        }
        .blue {
          margin-left: 4px;
          cursor: pointer;
        }
      }
    }
  }
  .txt-center {
    text-align: center;
    color: #888;
  }
}
</style>
