<template>
    <div>
        <!-- 合同选择 -->
        <el-dialog class="dialog" :title="title" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false">
            <div class="tc">
                <el-form :model="form" label-width="80px" size="small">
                    <el-row>
                        <el-col :span="12">
                            <el-form-item label="合同名称">
                                <el-input v-model="form.contractName"></el-input>
                            </el-form-item>
                        </el-col>
                        <el-col :span="12">
                            <el-form-item label="采购商">
                                <el-input v-model="form.purchaserName"></el-input>
                            </el-form-item>
                        </el-col>
                        <!-- <el-col :span="6">
                            <el-form-item label="合同编号">
                                <el-input v-model="form.orderNo"></el-input>
                            </el-form-item>
                        </el-col> -->
                    </el-row>
                    <el-row>
                        <el-col class="tc">
                            <el-button size="small" type="primary" @click="handleSearch">搜索</el-button>
                            <el-button size="small" @click="handleClear">清除</el-button>
                        </el-col>
                    </el-row>
                </el-form>
                <br>

                <div class="no-data" v-if="list&&!list.length">
                    没有搜索到相关合同
                </div>
                <table class="table">
                    <tr v-for="(row,index) in list" :key="index">
                        <td width="50" class="tr">
                            <el-radio v-model="selectRow" :label="index" @change="handleSelectRow(index)"> </el-radio>
                        </td>
                        <td>合同名称：《{{row.contractName}}》</td>
                    </tr>
                </table>
                <div class="table-pagination" v-if="list.length">
                    <el-pagination @current-change="handleCurrentChange" :current-page="form.pageIndex" :page-size="form.pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
                    </el-pagination>
                </div>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" @click="handleConfirm">确认</el-button>
                <el-button size="small" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

const form = {
    contractName: "",
    purchaserName: "",
    orderNo: "",
    pageIndex: 1,
    pageSize: 10
};

export default {
    components: {
        Loading
    },
    props: {
        paymentType:{
          type: String
        },
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            title: "请选择合同",
            form: Object.assign({}, form),
            list: [],
            total: 0,
            selectRow: null
        };
    },
    methods: {
        open(data) {
            if (data.title) {
                this.title = data.title;
            }
            this.init();
        },
        handleSearch() {
            this.getList();
        },
        handleClear() {
            const size = this.form.pageSize;
            this.form = Object.assign({}, form);
            this.form.pageSize = size;
        },
        handleCurrentChange(page) {
            this.form.pageIndex = page;
            this.getList();
            window.scrollTo(0,0)
        },
        handleSelectRow(i) {
            this.selectRow = i;
        },
        handleConfirm() {
            if (this.selectRow !== null) {
                this.dialogVisible = false;
                this.$emit("close", this.list[this.selectRow]);
            } else {
                this.$message.error("请至少选择一个合同");
            }
        },
        getList() {
            const params = {};
            for (let i in this.form) {
                if (this.form[i]) {
                    params[i] = this.form[i];
                }
            }
            params.paymentType = this.paymentType
            InterfaceService.getPaymentOrderList(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.selectRow = null;
                        this.list = data.respData.contractList || [];
                        this.total = +data.respData.totalCount;
                        this.form.pageSize = +data.respData.pageSize;
                    } else {
                        this.$message.error(data.respData.respMsg);
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        init() {
            this.list = [];
            this.form = Object.assign({}, form);
            this.getList();
            this.dialogVisible = true;
        }
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-radio__label {
    display: none;
}

.dialog {
    line-height: 25px;
}

.dialog-footer {
    /deep/ .el-button {
        width: 100px;
    }
}

.table {
    width: 100%;
    text-align: left;

    tr {
        border-bottom: 1px solid #ffffff;
        background: #f5f5f5;
    }

    td {
        padding: 10px 5px;
    }
}

.no-data {
    padding: 20px;
    text-align: center;
    background: #f5f5f5;
}
</style>
