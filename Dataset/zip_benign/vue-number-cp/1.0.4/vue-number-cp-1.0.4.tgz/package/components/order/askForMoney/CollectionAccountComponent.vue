<template>
  <div class="component-container">
    <el-row :gutter="20" class="dialog" v-if="isDialog">
      <el-col :span="12" :title="bankAccountInfo.bankAcctName || bankAccountInfo.acctName"><span class="title">开户名称：</span>{{bankAccountInfo.bankAcctName || bankAccountInfo.acctName}}</el-col>
      <el-col :span="12" :title="bankAccountInfo.name || bankAccountInfo.contact"><span class="title">联系人：</span>{{bankAccountInfo.name || bankAccountInfo.contact}}</el-col>
      <el-col :span="12" :title="bankAccountInfo.bankName"><span class="title">开户银行：</span>{{bankAccountInfo.bankName}}</el-col>
      <el-col :span="12" :title="bankAccountInfo.mobile | formatString"><span class="title">联系方式：</span>{{bankAccountInfo.mobile | formatString}}</el-col>
      <el-col :span="12" :title="bankAccountInfo.bankAcctNo | formatString('bank')"><span class="title">银行账号：</span><span class="red">{{bankAccountInfo.bankAcctNo | formatString('bank')}}</span></el-col>
    </el-row>
    <el-row :gutter="10" v-else>
      <el-col :span="8">
        <span class="title">开户名称：</span>
        <span :title="bankAccountInfo.bankAcctName || bankAccountInfo.acctName">{{bankAccountInfo.bankAcctName || bankAccountInfo.acctName}}</span>
      </el-col>
      <el-col :span="8">
        <span class="title">开户行行号：</span>
        <span :title="bankAccountInfo.bankNo || bankAccountInfo.bankCode | formatString('bank')">{{bankAccountInfo.bankNo || bankAccountInfo.bankCode | formatString('bank')}}</span>
      </el-col>
      <el-col :span="8">
        <span class="title">联系人：</span>
        <span :title="bankAccountInfo.name || bankAccountInfo.contact">{{bankAccountInfo.name || bankAccountInfo.contact}}</span>
      </el-col>

      <el-col :span="8">
        <span class="title">开户银行：</span>
        <span :title="bankAccountInfo.bankName">{{bankAccountInfo.bankName}}</span>
      </el-col>
      <el-col :span="8">
        <span class="title black">银行账号：</span>
        <span class="red" :title="bankAccountInfo.bankAcctNo | formatString('bank')">{{bankAccountInfo.bankAcctNo | formatString('bank')}}</span>
      </el-col>
      <el-col :span="8">
        <span class="title">联系方式：</span>
        <span :title="bankAccountInfo.mobile | formatString">{{bankAccountInfo.mobile | formatString}}</span>
      </el-col>

      <el-col :span="8">
        <span class="title">开户行地址：</span>
        <span :title="bankAddress(bankAccountInfo)">{{bankAddress(bankAccountInfo)}}</span>
      </el-col>
      <el-col :span="8">
        <span class="title">纳税人识别号：</span>
        <span :title="bankAccountInfo.taxPayerId | formatString('bank')">{{bankAccountInfo.taxPayerId | formatString('bank')}}</span>
      </el-col>
    </el-row>
  </div>
</template>
<script>
export default {
  props: ['bankAccountInfo', 'isDialog'],
  computed: {
    bankAddress() {
      return item => {
        return `${item.bankAddr || ''}`
      }
    }
  },
  filters: {
    // 过滤 字符串显示 state: 默认 电话格式, bank: 银行卡格式
    formatString: (val, state) => {
      state = state || 'tel'
      val = val || ''

      let newVal = ''
      if (state === 'tel') {
        // 如果检测到 有 -  说明是座机 不做分割
        if (val.includes('-')) {
          newVal = val
        } else {
          newVal = `${val.slice(0, 3)} ${val.slice(3, 7)} ${val.slice(7, val.length)}`
        }
        newVal = val.length <= 3 ? val : newVal
      } else {
        const len = Math.floor(val.length / 4)

        for (let i = 0; i < len; i++) {
          newVal += `${val.slice(4 * i, 4 * (i + 1))} `
          if (i + 1 >= len) newVal += val.slice(4 * (i + 1), val.length)
        }

        newVal = val.length <= 4 ? val : newVal
      }

      return newVal
    }
  },
}
</script>
<style lang="scss" scoped>
.component-container {
  .title {
    color: #888;
    &.black {
      color: #000;
    }
    span:not(.black) {
      overflow: hidden;
      width: 310px;
      display: inline-block;
      height: 11px;
      white-space: pre;
      text-overflow: ellipsis;
    }
  }
  [class*="el-col-"] {
    margin-top: 12px;
    overflow: hidden;
    white-space: pre;
    text-overflow: ellipsis;
  }
}
</style>
