<template>
    <div>
        <!-- 确认发货 -->
        <el-dialog class="dialog" :title="!isEdit?'确认发货':'填写物流'" @close="handleClosedExpress" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="700px" center :close-on-click-modal="false">
            <div class="deliver-dialog tl">
                <el-form class="nowrap" :model="deliverForm" :rules="deliverRules">
                    <el-form-item label="运送方式：" prop="shippingMethod">
                        <el-radio-group v-model="deliverForm.shippingMethod">
                            <el-radio label="0">供应商自行配送</el-radio>
                            <el-radio label="1">物流配送</el-radio>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item label="物流公司：" v-if="deliverForm.shippingMethod=='1'">
                        <el-select v-model="deliverForm.expressCompany" placeholder="请选择" clearable>
                            <el-option v-for="(item,index) in expressCompanyList" :key="index" :label="item.expressName" :value="item.expressCode"></el-option>
                        </el-select>

                        <div class="form-response-item">
                            <label>运单号码：</label>
                            <el-input v-model="deliverForm.trackingNo" placeholder="请填写运单号码" :maxlength="20"></el-input>
                        </div>
                    </el-form-item>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">{{!isEdit? '确定已发货':'确定修改'}}</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

const deliverForm = {
    shippingMethod: "1",
    expressCompany: null,
    trackingNo: ""
};
export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            requireNo: "",
            isEdit: false,
            deliverForm: Object.assign({}, deliverForm),
            deliverRules: {
                shippingMethod: [{ required: true, message: "请选择运送方式" }]
            },
            expressCompanyList: []
        };
    },
    methods: {
        open(data, isEdit) {
            this.requireNo = data.requireNo;
            this.isEdit = isEdit;
            this.deliverForm = Object.assign({}, deliverForm);

            if (isEdit) {
                this.deliverForm.shippingMethod = data.shippingMethod || "1";
                this.deliverForm.expressCompany = data.expressCompany;
                this.deliverForm.trackingNo = data.trackingNo;
            }

            if (!this.expressCompanyList.length) {
                this.getExpressList();
            }

            this.dialogVisible = true;
        },
        handleConfirm() {
            this.deliverOrder();
        },
        // 关闭物流信息
        handleClosedExpress() {
            this.$emit("close", false);
        },
        // 获取快递列表
        getExpressList() {
            InterfaceService.getExpressList(data => {
                const arr = data.expressList;
                this.expressCompanyList = arr || [];
            });
        },
        deliverOrder() {
            let params = {
                requireNo: this.requireNo
            };
            params = Object.assign(params, this.deliverForm);
            if (params.shippingMethod == "0") {
                delete params.expressCompany;
                delete params.trackingNo;
            }
            // 发货
            if (!this.isEdit) {
                InterfaceService.deliverOrder(
                    params,
                    data => {
                        console.log(data);
                        if (data.respCode === "0000") {
                            this.dialogVisible = false;
                            this.$emit("close", true);
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            } else {
                // 修改物流信息
                InterfaceService.editLogistics(
                    params,
                    data => {
                        console.log(data);
                        if (data.respCode === "0000") {
                            this.dialogVisible = false;
                            this.$emit("close", true);
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            }
        }
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-input {
    width: 180px;
}
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}

.form-response-item {
    display: inline-block;
    margin-left: 10px;
    vertical-align: bottom;
    label {
        display: inline-block;
        vertical-align: middle;
        width: 79px;
    }
}

@media (max-width: 1300px) {
    .form-response-item {
        width: 100%;
        margin-top: 10px;
        margin-left: 0;
    }
}
</style>
