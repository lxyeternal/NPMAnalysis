<template>
  <transition name="el-zoom-in-bottom">
    <div v-if="(dialogVisible || sessionShowFlg == '1') && fromIndex">
      <div class="box" v-show="showBox">
        <div class="addMockList">
          <div class="content">
            <div class="title tc">最近的清单草稿</div>
            <div class="center">
              <div class="product-table">
                <!-- 列表 -->
                <table>
                  <thead>
                    <tr>
                      <td width="48px">序号</td>
                      <td>草稿名称</td>
                      <td width="200px">创建时间</td>
                      <td width="48px" class="tr">操作</td>
                    </tr>
                  </thead>
                  <tbody v-for="(item,index) in draftsList" :key="index" class="tbody-row">
                    <tr>
                      <td width="48px">
                        {{index + 1}}
                      </td>
                      <td>
                        <div class="name">
                          <p class="ellipsisOne" :title="item.draftName">{{item.draftName}}</p>
                          <i class="tag" v-if="item.busiType === 'ONEWAY_ORDER'">单向合同</i>
                        </div>
                      </td>
                      <td width="200px">{{item.draftCreatTime}}</td>
                      <td width="48px" class="tr">
                        <p><span class="blue-pointer" @click="handleOpenDraft(item)">打开</span></p>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
              <!-- 空列表 -->
              <div class="accout-empty" v-if="!draftsList.length&&!isLoading">
                <img src="@/assets/images/icon-no-product.png">
                <p>没有最近的清单草稿，请<em class="blue-pointer" @click="handleCreateNew">创建新合同</em></p>
              </div>
            </div>
          </div>
          <!-- 按钮 -->
          <div class="foot">
            <el-button type="primary" @click="handleCreateNew">创建新合同</el-button>
            <el-button @click="handleGoDraftsList">去草稿箱</el-button>
            <el-button @click="showBox = false">取消</el-button>
          </div>
        </div>
      </div>
      <el-dialog class="dialog" title="完善信息" :append-to-body="true" :lock-scroll="true" :visible.sync="msgDialogVisible" width="840px" center :close-on-click-modal="false" @close="close">
        <div style="margin-bottom: 10px;">您的企业资料尚未完善，请联系管理员完成以下信息的认证后再去创建合同:</div>
        <div class="contract-list">
          <p>
            1.公司地址 &gt;&gt;
            <span v-if="corpAddrIsComplete == 1">已完成<i class="el-icon-check"></i></span>
            <span v-else class="blue-pointer" @click="handleGo('/vendorCenter/companyMessage','addr')">去完善<i class="el-icon-edit red"></i></span>
          </p>
          <p>
            2.开票信息 &gt;&gt;
            <span v-if="corpFinIsComplete == 1">已完成<i class="el-icon-check"></i></span>
            <span v-else class="blue-pointer" @click="handleGo('/vendorCenter/billingInformationEditing','fin')">去完善<i class="el-icon-edit red"></i></span>
          </p>
          <p>
            1.银行信息 &gt;&gt;
            <span v-if="corpBankIsComplete == 1">已完成<i class="el-icon-check"></i></span>
            <span v-else class="blue-pointer" @click="handleGo('/vendorCenter/enterpriseCertification')">去完善<i class="el-icon-edit red"></i></span>
          </p>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button v-if="corpAddrIsComplete != '1' || corpFinIsComplete != '1' || corpBankIsComplete != '1'" type="primary" class="normal-btn" @click="close">知道了</el-button>
          <el-button v-else type="primary" class="normal-btn" @click="create">创建合同</el-button>
        </div>
      </el-dialog>
      <!-- 选择合同类型 -->
      <el-dialog class="dialog" title="请选择合同类型" :append-to-body="true" :lock-scroll="true" :visible.sync="radioVisible" width="840px" center :close-on-click-modal="false" @close="busiType = '0'">
        <div class="tc">
          <span class="f12 grey"><span class="red">*</span>合同类型：</span>
          <el-radio-group v-model="busiType">
            <el-radio :label="'0'">与绿地建材集团签订合同(双向合同)</el-radio>
            <el-radio :label="'ONEWAY_ORDER'">与绿地房地产项目公司签订合同(单向合同)</el-radio>
          </el-radio-group>
        </div>
        <div slot="footer" class="dialog-footer">
          <el-button type="primary" class="normal-btn" @click="handleCreateNew('nextStep')">下一步</el-button>
          <el-button class="normal-btn" @click="radioVisible=false">取消</el-button>
        </div>
      </el-dialog>
      <Loading :is-loading="isLoading" v-if="showBox"></Loading>
    </div>
  </transition>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
export default {
  props: ['fromIndex'],
  data() {
    return {
      isLoading: false,
      showBox: false,
      msgDialogVisible: false,
      sessionShowFlg: "0",
      dialogVisible: false,
      corpAddrIsComplete: false,
      corpFinIsComplete: false,
      corpBankIsComplete: false,
      draftsList: [],

      radioVisible: false,
      busiType: '0',//ORDER(双向),ONEWAY_ORDER（单项）
      openPath: ''
    }
  },
  components: {
    Loading
  },
  methods: {
    handleGo(path, type) {
      let query = {};
      if (type == 'addr') {
        query = {
          type: 'addr'
        }
      } else if (type == 'fin') {
        query = {
          resultPath: '/vendorCenter/companyMessage'
        }
      }
      if (['purchaserCenter'].includes(this.openPath)) {
        this.$router.push({
          path: path,
          query: query
        });
        this.close()
        return
      }
      const routeData = this.$router.resolve({
        path: path,
        query: query
      });
      window.open(routeData.href, "_blank");
    },
    close() {
      this.msgDialogVisible = false;
      this.dialogVisible = false;
      this.$setRootScope('sessionShowFlg', '0')
    },
    handleOpenDraft(item) {
      if (item.saveStep !== '2') {
        this.$router.push({
          path: '/draftOfCreateOrder',
          query: {
            draftsId: item.id,
            draftName: item.draftName,
            busiType: item.busiType
          }
        })
      } else {
        this.$router.push({
          path: '/confirmOrder',
          query: {
            draftsId: item.id,
            orderNo: item.orderNo || "",
            busiType: item.busiType
          }
        })
      }

    },
    handleCreateNew(type = '') {
      if (type === 'nextStep') {
        this.$router.push({
          path: '/draftOfCreateOrder',
          query: {
            busiType: this.busiType,
          }
        })
      } else {
        this.radioVisible = true
      }
    },
    handleGoDraftsList() {
      this.$router.push('/vendorCenter/orderDraftsList')
    },
    create() {
      this.$setRootScope('sessionShowFlg', '0');
      this.getDraftsList();
    },
    open(path) {
      this.dialogVisible = true;
      this.openPath = path
      this.getDraftsList()
    },
    getDraftsList() {
      let param = {
        fromTime: this.fromTime,
        toTime: this.toTime,
        pageIndex: 1,
      };
      InterfaceService.getDraftsList(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          let res = data.respData || {}
          // this.draftsList = res.draftBoxInfos || []
          // this.showBox = true
          // let companyComplete =  res.corpAddrIsComplete === '1' && res.corpFinIsComplete === '1';
          // let bankComplete = res.corpBankIsComplete === '1';
          // res.corpAddrIsComplete = '0';
          // res.corpFinIsComplete = '0';
          // res.corpBankIsComplete = '0';
          this.corpAddrIsComplete = res.corpAddrIsComplete;
          this.corpBankIsComplete = res.corpBankIsComplete;
          this.corpFinIsComplete = res.corpFinIsComplete;
          if (res.corpAddrIsComplete === '1' && res.corpBankIsComplete === '1' && res.corpFinIsComplete === '1') {
            this.draftsList = res.draftBoxInfos || [];
            this.msgDialogVisible = false;
            this.showBox = true
          } else {
            this.msgDialogVisible = true;
            this.$setRootScope('sessionShowFlg', '1')
            // let str = '';
            // let list = [];
            // if (res.corpAddrIsComplete !== '1') {
            //   list.push('公司地址')
            // }
            // if (res.corpBankIsComplete !== '1') {
            //   list.push('银行信息')
            // }
            // if (res.corpFinIsComplete !== '1') {
            //   list.push('开票信息')
            // }
            // if (!companyComplete && !bankComplete) {
            //   str = "【管理中心】-【本公司信息】、【企业实名认证】"
            // }else if (companyComplete && !bankComplete) {
            //   str = "【企业实名认证】"
            // }else if (!companyComplete && bankComplete) {
            //   str = "【管理中心】-【本公司信息】"
            // }
            // this.$alert(
            //   `<span class="f12">您还未完善企业信息，请联系管理员至<span class="blue">${str}</span>将${list.join("、")}完善。若不完善则影响合同创建。</span>`,
            //   {
            //     confirmButtonClass: "btn-alert",
            //     confirmButtonText: "知道了",
            //     dangerouslyUseHTMLString: true,
            //     center: true,
            //     callback: action => {
            //     }
            //   }
            // );
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  },

  mounted() {
    this.sessionShowFlg = this.$getRootScope('sessionShowFlg') || '0';
    this.msgDialogVisible = this.sessionShowFlg === '1'
    if (this.sessionShowFlg == '1') {
      this.getDraftsList()
    }
  }
}
</script>
<style lang="scss" scoped>
.box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .addMockList {
    max-height: 80%;
    overflow: auto;
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    .content {
      width: 1190px;
      margin: 0 auto;
      font-size: 14px;
      line-height: 17px;
      .title {
        padding: 20px 0;
        border-bottom: 1px solid #eee;
        margin-bottom: 20px;
      }

      table,
      thead,
      tbody {
        display: block;
      }

      thead,
      tbody tr {
        display: table;
        width: 100%;
        table-layout: fixed;
      }
      table {
        margin-top: 2px;
        table-layout: fixed;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        td {
          padding: 14px 10px;
          vertical-align: middle;
          word-break: break-all;
          &:last-child {
            text-align: right;
          }
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          border-bottom: 1px solid #eee;
          background: rgba(249, 249, 249, 1);
          color: rgba(136, 136, 136, 1);
          tr {
            td {
              padding: 15px 10px;
              &:last-child {
                text-align: right;
              }
            }
          }
        }
        .tbody-row {
          &:hover {
            background: #f0f8ff;
          }
        }
        tbody {
          text-align: left;
          &.tbody-active {
            height: 40vh;
            overflow-y: auto;
          }
          tr {
            border-bottom: 1px solid #eee;
            td {
              .name {
                display: flex;
                > p {
                  max-width: 750px;
                  line-height: 20px;
                  margin-right: 5px;
                }
              }
              .tag {
                width: 70px;
                height: 20px;
                background: #8b95ac;
                line-height: 20px;
                font-size: 14px;
                color: #fff;
                text-align: center;
                border-radius: 2px;
                display: inline-block;
              }
            }
          }
          .border-none {
            border-bottom: none;
          }
        }
      }
    }
    .foot {
      width: 100%;
      margin-top: 40px;
      height: 57px;
      background: rgba(49, 49, 49, 0.9);
      line-height: 57px;
      text-align: center;
      .el-button {
        width: 120px;
        height: 34px;
        line-height: 34px;
        padding: 0;
        font-size: 12px;
      }
      .el-button--primary {
        color: #fff;
        border: none;
        background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
      }
    }
  }
}
.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
.accout-empty {
  padding: 15vh;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
.product-table {
  overflow-y: auto;
}
.el-icon-check {
  color: #1cb963;
}
.dialog {
  line-height: 17px;
}
</style>