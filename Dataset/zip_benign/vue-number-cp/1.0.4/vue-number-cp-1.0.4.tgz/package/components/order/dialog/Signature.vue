<template>
  <div>
    <!-- 审批签署 -->
    <el-dialog class="dialog" title="请确认签章方式" :append-to-body="true" :lock-scroll="true" :visible.sync="signDialogVisible" width="840px" center :close-on-click-modal="false">
      <div :class="{'tc':!signList || signList.length < 6}">
        <p class="tc">您待签署：{{roleList.join('、')}}</p>
        <!-- .filter(f=> f.type==1 || f.sealData) -->
        <div class="preview-sign preview-seal" v-for="(item,index) in signList" :key="index" v-if="checkSignVisible(item)">
          <div class="float-tip" v-if="!item.sealData&&item.type==2">请添加企业{{signType==="order"?'合同':'项目'}}章</div>
          <div class="float-tip" v-if="item.type==1&&showAddPersonalTip">请添加个人名章</div>

          <div class="preview-seal-content" :class="{'active':item.active}" @click="handleSelectSign(item,index)">
            <span v-if="item.sealData&&item.type==2" class="preview-seal-text">公章</span>
            <span v-if="item.sealData&&(item.type==1||item.type==0)" class="preview-seal-text">私章</span>
            <template v-if="item.sealData">
              <img :class="{gray:  ['0', '3'].includes(item.expireFlg)}" :title="item.expireFlg == '0' ? '已过期' : item.expireFlg == '3' ? '授权开始日期未到' : ''" v-if="item.type==0" :src="item.sealData">
              <img :class="{gray:  ['0', '3'].includes(item.expireFlg)}" :title="item.expireFlg == '0' ? '已过期' : item.expireFlg == '3' ? '授权开始日期未到' : ''" v-else :src="item.sealData? ('data:image/jpeg;base64,'+item.sealData):''">
            </template>
            <i class="el-icon-plus" v-if="!item.sealData"></i>
          </div>
          <label>{{(item.sealData? '':'添加')+item.label}}</label>
        </div>
        <!-- 如果没有授权印章 才添加授权印章 ,  contractCorpType 施工 监理 方 不显示 此案例-->

        <!-- <div class="preview-sign preview-seal" v-if="signType=='order' && canAddAuthorize && !isAuthorizationSeal('authorize').length"> -->
        <div class="preview-sign preview-seal" v-if="signInfo.personalEventCnt != 0 && !isAuthorizationSeal('authorize').length && !['construction', 'supervisory'].includes(contractCorpType)">
          <!-- <div class="float-tip">请添加被授权的个人名章</div> -->
          <div class="preview-seal-content" @click="handleSelectSign">
            <i class="el-icon-plus"></i>
          </div>
          <label>添加被授权的个人名章</label>
        </div>
        <!-- 如果没有法人印章 才添加法人印章 -->
        <!-- <div class="preview-sign preview-seal" v-if="signType=='order' && !isAuthorizationSeal('legal').length"> -->
        <div class="preview-sign preview-seal" v-if="signInfo.personalEventCnt != 0 && !isAuthorizationSeal('legal').length && !['construction', 'supervisory'].includes(contractCorpType) && signType === 'order'">
          <!-- <div class="float-tip">请添加法人代表章</div> -->
          <div class="preview-seal-content" @click="handleSelectSign">
            <i class="el-icon-plus"></i>
          </div>
          <label>添加法人代表章</label>
        </div>
        <div class="preview-sign preview-seal" v-if="canRedrawSign">
          <div class="preview-seal-content" @click="handleSelectSign({type:0})">
            <i class="el-icon-edit"></i>
          </div>
          <label>重绘签名</label>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" @click="handleConfirm" :disabled="!canNextSign">{{smsValid? '签署':'下一步'}}</el-button>
        <el-button class="normal-btn" @click="signDialogVisible = false">拒签</el-button>
      </div>
    </el-dialog>

    <!-- 确认签署 -->
    <el-dialog class="dialog" title="确认签署" :append-to-body="true" :lock-scroll="true" :visible.sync="confirmDialogVisible" width="840px" center :close-on-click-modal="false">
      <div class="tc" style="margin-bottom: -10px;">
        <p style="margin:6px 0 26px">输入图形验证码，点击获取手机验证码，系统会向您尾号为 {{mobileLastFour}} 手机号，发送验证码，输入验证码，确认本次签署。</p>
        <div class="pic-code">
          <ValidateCode @received="handleChangeValidCode" :update="updatePicCode"></ValidateCode>
        </div>
        <div class="pic-code" style="height: 18px;">
          <el-input type="tel" v-model="smsCode" placeholder="请输入手机验证码" style="position: absolute;left: 0;width: 285px;"></el-input>
          <el-button class="normal-btn tel" type="primary" @click="handleSendSMSCode" :disabled="!!smsTimer">{{smsTimerText}}</el-button>
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" @click="handleSign">签署</el-button>
        <el-button class="normal-btn" @click="confirmDialogVisible = false">拒签</el-button>
        <p class="mt40">为了保障您的账户交易安全，基于监管关于身份要素验证的相关要求，综合考虑用户使用习惯，我们可能采取不同的验证措施识别您的身份。</p>
        <p>例如，您的账户在大家采平台签章时，需要输入有效的手机验证码。</p>
      </div>
    </el-dialog>

    <!-- 添加企业印章 -->
    <el-dialog class="dialog" :title="'添加企业'+ (signType=='order'? '合同专用章':'项目印章')" :append-to-body="true" :lock-scroll="true" :visible.sync="addCompanyDialogVisible" width="900px" center :close-on-click-modal="false">
      <div>
        <p>印章样式只能设置一次，请认直填写!若有疑问请联系平台客服(客服电话：{{$platformContact()['hotLine']}})</p>
        <p>若印章样式没有符合你的要求，可通过邮件将印章图片发给平台，平台将帮您上传印章。
          <a class="link" @click="handleSendEmail">去发邮件</a>
          <a class="link send-email" @click="handleCopyEmail" :data-clipboard-text="$platformContact()['email']">复制Email地址</a>
        </p>
      </div>
      <div>
        <el-row>
          <el-col :span="19">
            <el-form :model="sealForm" label-width="150px">
              <el-form-item label="企业名称：" prop="mainText" required>
                <el-input v-model="sealForm.mainText" placeholder="请输入企业名称" disabled></el-input>
              </el-form-item>
              <el-form-item label="印章横向内容：" prop="hText">
                <el-input v-model="sealForm.hText" placeholder="限8个字符" :maxlength="8" :disabled="!canPreview" @input="handleChangeSealText"></el-input>
              </el-form-item>
              <el-form-item label="印章下弦文内容：" prop="qText">
                <el-input v-model="sealForm.qText" placeholder="限20个字符" :maxlength="20" :disabled="!canPreview" @input="handleChangeSealText"></el-input>
              </el-form-item>
              <!-- <el-form-item class="tc">
                                              <el-button :disabled="!canPreview" @click="handleCompanyPreview" class="normal-btn">生成预览</el-button>
                                          </el-form-item> -->
            </el-form>
          </el-col>
          <el-col :span="5">
            <div class="preview-seal preview-company" v-for="(item,index) in companySealList" :key="index">
              <div class="preview-seal-content" :class="{'active':item.active}" @click="handleChooseSeal(companySealList,item,index)">
                <img :src="item.sealData? ('data:image/jpeg;base64,'+item.sealData):''">
              </div>
              <label>印章预览</label>
            </div>
          </el-col>
        </el-row>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button v-if="!canCreat" type="primary" class="normal-btn" :disabled="!canPreview" @click="handleCompanyPreview">预览印章</el-button>
        <el-button v-if="canCreat" type="primary" class="normal-btn" @click="handleCompanyConfirm">确认生成印章</el-button>
        <el-button class="normal-btn" @click="handlePreStep('addCompanyDialogVisible')">上一步</el-button>
      </div>
    </el-dialog>

    <!-- 添加个人印章 -->
    <el-dialog class="dialog" title="添加个人印章" :append-to-body="true" :lock-scroll="true" :visible.sync="addPersonDialogVisible" width="840px" center :close-on-click-modal="false">
      <div>
        <el-row :gutter="160" class="tc">
          <el-col :span="4" v-for="(item,index) in personSealList" :key="index">
            <div class="preview-seal">
              <div class="preview-seal-content" :class="{'active':item.active}" @click="handleChooseSeal(personSealList,item,index)">
                <img :src="item.sealData? ('data:image/jpeg;base64,'+item.sealData):''">
              </div>
              <label>印章样式{{index+1}}</label>
            </div>
          </el-col>
        </el-row>
        <p>若印章样式没有符合你的要求，可通过邮件将印章图片发给平台，平台将帮您上传印章。
          <a class="link" @click="handleSendEmail">去发邮件</a>
          <a class="link send-email" @click="handleCopyEmail" :data-clipboard-text="$platformContact()['email']">复制Email地址</a>
        </p>

      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" @click="handlePersonConfirm">确认生成印章</el-button>
        <el-button class="normal-btn" @click="handlePreStep('addPersonDialogVisible')">上一步</el-button>
      </div>
    </el-dialog>

    <!-- 手绘签署 -->
    <el-dialog class="dialog" title="手绘签署" :append-to-body="true" :lock-scroll="true" :visible.sync="addHandDialogVisible" width="840px" center :close-on-click-modal="false">
      <div>
        <HandPaint ref="signature"></HandPaint>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" @click="handleHandConfirm">确定</el-button>
        <el-button class="normal-btn" @click="handlePreStep('addHandDialogVisible')">上一步</el-button>
      </div>
    </el-dialog>

    <!-- 实名认证 -->
    <Authentication ref="authentication" @close="handleCloseAuth"></Authentication>

    <!-- 添加授权印章 -->
    <AddAuthorize ref="authorize" @close="handleCloseAuthorize"></AddAuthorize>
    <Loading :is-loading="isLoading">
      <div v-if="showSignTip" slot="tip">
        <p style="margin-bottom: 10px;">本合同需盖章位置较多，需要点时间，请耐心等待！</p>
        <el-progress slot="tip" :text-inside="true" :stroke-width="26" :percentage="percentage"></el-progress>
      </div>
    </Loading>

  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import HandPaint from "@/components/base/HandPaint";
import ValidateCode from "@/components/base/ValidateCode.vue";
import Authentication from "@/components/auth/dialog/Authentication";
import AddAuthorize from "@/components/auth/dialog/AddAuthorize";
import { InterfaceService } from "@/services/api";
import ClipBoard from "clipboard";

const signList = [
  { label: "企业印章", type: 2, sealData: "", active: false, sealKind: 'corp,project' },
  { label: "个人名章", type: 1, sealData: "", active: false, sealKind: 'personal' }
];

const sealForm = {
  mainText: "",
  hText: "",
  qText: ""
};

const emailMap = {
  "@163.com": "http://mail.163.com",
  "@qq.com": "http://mail.qq.com",
  "@sina.com": "http://mail.sina.com.cn/",
  "@sina.cn": "http://mail.sina.com.cn/"
};

export default {
  props: ['propCorpId', 'propAcctId', 'mainText',],
  mixins: [accountMixin],
  components: {
    Loading,
    HandPaint,
    ValidateCode,
    Authentication,
    AddAuthorize
  },
  data() {
    return {
      isLoading: false,
      signDialogVisible: false,
      confirmDialogVisible: false,
      addCompanyDialogVisible: false,
      addPersonDialogVisible: false,
      addHandDialogVisible: false,
      signInfo: {},
      eventList: [],
      orderList: [],
      totalOrders: [],
      // signList: this.$clone(signList),
      signList: [],
      sealForm: Object.assign({}, sealForm),
      companySealList: [],
      personSealList: [],
      canPreview: true,
      canCreat: true,
      smsCode: "",
      smsTimer: 0,
      percentage: 0,
      prePicCode: "",
      picCode: "",
      updatePicCode: 0,
      totalEventNum: 0,
      signType: "",
      roleList: [],
      canAddAuthorize: false,
      signUserinfo: {},
      showSignTip: false,
      showBrokerBatchErrMgs: true,
      signFailNum: 0,
      totalsignNum: 0,
      preview: '',
      selfEsignId: null,
      currentAcctId: "",
      orderInfo: {},
    };
  },
  computed: {

    contractCorpType() {
      return this.$store.state.userInfo.contractCorpType || null
    },

    // 是否管理员
    isAdmin() {
      let adminRoles = ['1000', '2000', '3000', '4000', '5000', '9000'],
        roleIds = [];
      let corpId = ''
      let res = this.$store.state.userInfo;
      let bs = res.bs && res.bs.toUpperCase()
      if (bs === 'B') {
        corpId = this.propCorpId || this.$store.state.userInfo.corpId
      } else {
        corpId = this.$store.state.userInfo.corpId
      }
      this.$store.state.userInfo = this.$store.state.userInfo || {}
      const corpRoleList = this.$store.state.userInfo.corpRoleList || []
      corpRoleList.forEach(f => {
        if (f.corpId == corpId) {
          roleIds = roleIds.concat(f.roleList || [])
        }
      })

      console.log(roleIds, '---管理员');

      return roleIds.some(fItem => adminRoles.includes(fItem.roleId)) || this.isDivisionEdit

    },


    // 事业部 - 只有 2000 权限 则 哪条数据满足 对应的 corpId 才能编辑哪条
    isDivisionEdit() {
      return this.mixinsRoleIdsAdmin(this.orderInfo.purchaserId || '')
    },

    // 返回当前用户 持有的 权限
    mixinsRoleIdsAdmin() {
      return (corpId, code = '2000') => {
        const ids = this.roleListFilter(corpId) || []
        // 是否为管理员2000
        return ids.some(s => s.roleId == code)
      }
    },


    // 是否有 对应 印章
    isAuthorizationSeal() {
      return sealKind => {
        return this.signList.filter(f => f.sealKind === sealKind) || []
      }
    },

    /**
     * 判断 roleIds是否包含 传入 roleId
     */
    computedIsRoleId() {
      return id => {
        this.$store.state.userInfo = this.$store.state.userInfo || {}
        const roleId = typeof id === 'string' ? id : id.toString(),
          corpRoleList = this.$store.state.userInfo.corpRoleList || [],
          roleIds = corpRoleList.find(f => (f.corpId == this.propCorpId || f.corpId == this.$store.state.userInfo.corpId)).roleList || []

        return roleIds.filter(fItem => fItem.roleId === roleId).length
      }
    },
    email() {
      return (
        this.$store.state.userInfo && this.$store.state.userInfo.email
      );
    },
    mobile() {
      return (
        this.$store.state.userInfo &&
        this.$store.state.userInfo.mobileNo
      );
    },
    mobileLastFour() {
      return this.mobile.slice(-4);
    },
    showAddPersonalTip() {
      let bool = false;
      // 是否有个人或授权
      if (this.showPersonal) {
        bool = !this.signList.some(item => {
          return item.type == 1 && item.sealData;
        });
      }
      return bool;
    },
    showCompany() {
      return this.signInfo.corpEventCnt > 0;
    },
    showPersonal() {
      return this.signInfo.personalEventCnt > 0;
    },
    canNextSign() {
      // let companyBool = false;
      // let personalBool = false;
      //
      // // 是否有企业章
      // if (this.showCompany) {
      //   // this.signList.forEach(item => {
      //   //   if (item.type == 2 && !item.sealData) {
      //   //     companyBool = false;
      //   //   }
      //   // });
      //   companyBool = this.signList.some(item => {
      //     return item.type == 2 && item.sealData;
      //   });
      // }
      // // 是否有个人或授权
      // if (this.showPersonal) {
      //   personalBool = this.signList.some(item => {
      //     return item.type == 1 && item.sealData;
      //   });
      // }
      // return companyBool || personalBool;
      return this.signList.some(item => {
        return item.active;
      });
    },
    brokerRole() {
      return this.$store.state.userInfo &&
        this.$store.state.userInfo.contractCorpType === "broker"
    },
    canRedrawSign() {
      let bool = false;
      this.signList.forEach(item => {
        if (item.type == 0 && item.sealData) {
          bool = true;
        }
      });
      return bool;
    },
    smsValid() {
      return this.$store.state.isSignSMSValid;
    },
    smsTimerText() {
      let str = "";
      if (this.smsTimer <= 0) {
        str = "获取手机验证码";
      } else {
        str = this.smsTimer + "s后获取";
      }
      return str;
    }
  },
  methods: {
    open(events, signType, preview, orderInfo) {
      this.updatePicCode++
      this.eventList = events;
      console.log(this.eventList, 'signType', signType, orderInfo);
      console.log(this.propCorpId, this.propAcctId, this.mainText, '签章信息');

      this.orderInfo = orderInfo || {}
      this.signType = signType;
      if (preview) this.preview = preview;
      this.init();
    },
    checkSignVisible(item) {
      let visible = false;
      if (this.showCompany && item.type == 2) {
        visible = true;
      } else if (this.showPersonal && item.type == 1) {
        visible = true;
      } else if (this.showPersonal && item.type == 0) {
        visible = true;
      }
      return visible;
    },
    // 发送邮件
    handleSendEmail() {
      let valid = false;
      let email = this.email.split("@")[1];
      email = "@" + email;
      Object.keys(emailMap).forEach(key => {
        let reg = new RegExp(key, "i");
        if (reg.test(email)) {
          valid = true;
          window.open(emailMap[key]);
        }
      });

      if (!valid) {
        this.$message.info(
          "未匹配到相应邮件网站，请打开邮件客户端发送邮件"
        );
      }
    },
    // 复制email
    handleCopyEmail() {
      const clipboard = new ClipBoard(".send-email");
      clipboard.on("success", e => {
        this.$message.success("已复制");
        clipboard.destroy();
      });
      clipboard.on("error", e => {
        this.$message.error("该浏览器不支持复制");
        clipboard.destroy();
      });
    },
    // 企业印章预览
    handleCompanyPreview() {
      this.searchSeal();
    },

    go(path, type) {
      const { href } = this.$router.resolve({
        path,
        query: {
          sealType: type,
          hasSelected: "1",
          propCorpId: this.propCorpId,
          propAcctId: this.propAcctId,
          mainText: this.mainText,
        }
      });
      window.open(href, '_blank');
    },

    // 选择签署方式
    handleSelectSign(item, index) {
      if (!item.sealData || ['0', '3'].includes(item.expireFlg)) {
        let res = this.$store.state.userInfo;
        let bs = res.bs && res.bs.toUpperCase()
        let path = ''
        if (bs == 'B') {
          path = '/purchaserCenter/dvSealManagementList'
        } else if (bs == 'S') {
          path = '/vendorCenter/sealList'
        }

        if (item.type == 1) {
          // 个人
          this.signDialogVisible = false;
          this.go(path)
        } else {
          // 判断是否有权限添加印章
          // 如果有去添加印章页面 ,  如果没有 则不作操作
          if (this.isAdmin) {
            this.signDialogVisible = false;
            this.go(path)
          } else {
            if (item.expireFlg == '0') {
              this.$message.error('该印章已过期, 请联系管理员补交授权书！')
              return
            }
            if (item.expireFlg == '3') {
              this.$message.error('该印章授权开始日期未到,使用请联系管理员补交授权书！')
              return
            }
            this.$message.error('管理员尚未创建印章，或者您没有该印章的授权，请联系管理员！')
          }
        }
      } else {
        if (item.expireFlg == '0') {
          return
        }
        if (item.expireFlg == '3') {
          this.$message.error('该印章授权开始日期未到,使用请补交授权书!')
          return
        }
        if (item.type == 1) {
          let signItem = {}
          this.signList.forEach(_item => {
            if (_item.type == 1) {
              _item.active = false;
            }
            if (_item.sealKind.includes(item.sealKind)) {
              this.$set(_item, 'active', true)
            }
          });
        } else {
          this.signList.forEach(_item => {
            if (_item.type == 2) {
              _item.active = false;
            }
          });
          this.$set(item, 'active', true)
        }
      }

    },
    handleConfirm() {
      let valid = false;
      this.signList.forEach(item => {
        if (item.active) {
          valid = true;
        }
      });
      if (valid) {
        if (this.smsValid) {
          this.signFile();
        } else {
          this.signDialogVisible = false;
          this.confirmDialogVisible = true;
        }
      } else {
        this.$message.error("请选择签章");
      }
    },
    // 签署
    handleSign() {
      if (this.smsCode) {
        this.signFile();
      } else {
        this.$message.error("请输入验证码");
      }
    },
    // 认证完成
    handleCloseAuth(bool) {
      if (bool) {
        this.getSealListByEvent();
        this.signDialogVisible = true;
      }
    },
    // 企业签章确认
    handleCompanyConfirm() {
      let data =
        this.companySealList[0] && this.companySealList[0].sealData;
      this.chooseSeal(2, data);
      this.addCompanyDialogVisible = false;
      this.signDialogVisible = true;
    },
    // 个人签章确认
    handlePersonConfirm() {
      let data,
        valid = false;
      this.personSealList.forEach(item => {
        if (item.active) {
          valid = true;
          data = item.sealData;
        }
      });
      if (!valid) {
        this.$message.error("请选择个人印章");
        return;
      }
      this.chooseSeal(1, data);
      this.addPersonDialogVisible = false;
      this.signDialogVisible = true;
    },
    // 手绘签名确认
    handleHandConfirm() {
      const data = this.$refs["signature"].getData();
      this.chooseSeal(0, data);
      this.addHandDialogVisible = false;
      this.signDialogVisible = true;
    },
    // 上一步
    handlePreStep(dialog) {
      this[dialog] = false;
      this.signDialogVisible = true;
    },
    // 选择签章
    handleChooseSeal(list, item, index) {
      list.forEach((item, i) => {
        item.active = i == index;
        this.$set(list, i, item);
      });
    },
    // 发送验证码
    handleSendSMSCode() {
      if (!this.picCode) {
        this.$message.error("图形验证码不正确");
        return;
      }
      if (!this.smsTimer) {
        this.sendSMSCode();
      }
    },
    // 图形验证码值
    handleChangeValidCode(code) {
      this.picCode = code;
    },
    // 修改企业印章内容
    handleChangeSealText() {
      this.canCreat = false;
    },
    // 添加授权印章
    handleAddAuthorize() {
      this.signDialogVisible = false;
      this.$refs["authorize"].open();
    },
    // 添加授权印章完成
    handleCloseAuthorize(esignId) {
      this.signDialogVisible = true;
      if (esignId) {
        const options = {
          esignId: esignId,
          acctType: 1,
          processFlg: 1
        };
        this.setSeal(options, true);
      }
    },
    // 选择签章
    chooseSeal(type, data) {
      if (type == 1 || type == 2) {
        const options = {
          acctType: type,
          processFlg: 1
        };

        if (type == 1) {
          options.esignId = this.signUserinfo.esignId;
          options.sealData = data;
        } else if (type == 2) {
          options.sealParamFront = this.signType == "order" ? 1 : 2;
          options.sealType = 1;
          options.mainText = this.sealForm.mainText;
          options.hText = this.sealForm.hText;
          options.qText = this.sealForm.qText;
        }
        this.setSeal(options, true);

        this.signList.forEach((item, index) => {
          if (type == item.type) {
            item.sealData = data;
            item.active = true;
          }
          this.$set(this.signList, index, item);
        });
      } else {
        this.signList.forEach((item, index) => {
          if (type == item.type) {
            item.sealData = data;
            item.active = true;
          } else {
            item.active = false;
          }
          this.$set(this.signList, index, item);
        });
      }
    },
    // 企业印章预览
    searchSeal() {
      const options = {
        acctType: 2,
        sealParamFront: this.signType == "order" ? 1 : 2,
        processFlg: 0,
        mainText: this.sealForm.mainText,
        hText: this.sealForm.hText,
        qText: this.sealForm.qText
      };
      this.setSeal(options);
    },
    // 按事件获取签章列表
    getSealListByEvent() {
      const events = this.filterEventId();
      const params = {
        eventIdList: events
      };
      InterfaceService.getSealListByEvent(
        params,
        data => {
          if (data.respCode === "0000") {
            const result = data.respData;
            this.signInfo = result;
            this.companySealList = result.corpSealDataList || [];
            this.personSealList = result.personalSealDataList || [];

            this.signList = [];

            // 默认选中授权印章或个人印章
            const ownerSign = [];
            const authSign = [];

            this.personSealList.forEach((item, index) => {
              item.type = 1;
              this.$set(item, 'active', false)
              if (item.sealKind == 'personal') {
                item.label = "个人名章";
                ownerSign.push(item);
              } else if (['legal'].includes(item.sealKind) && this.signType === 'order') {
                item.label = "法人代表章";
                authSign.push(item);
              } else if (['authorize'].includes(item.sealKind)) {
                item.label = "被授权的个人名章";
                authSign.push(item);
              }
            });
            // const signList = [
            //   { label: "企业印章", type: 2, sealData: "", active: false, sealKind: 'corp,project' },
            //   { label: "个人名章", type: 1, sealData: "", active: false, sealKind: 'personal' }
            // ];
            if (this.companySealList.length) {
              let firstActive = false
              this.companySealList.forEach((item, index) => {
                if (item.expireFlg != '0' && item.expireFlg != '3' && !firstActive) {
                  firstActive = true
                  this.$set(item, 'active', true);
                } else {
                  this.$set(item, 'active', false);
                }
                this.signList.push({
                  label: item.sealName,
                  active: item.active,
                  sealId: item.sealId,
                  type: 2,
                  sealData: item.sealData,
                  sealKind: item.sealKind,
                  expireFlg: item.expireFlg,
                })
              });
            } else {
              if (this.showCompany) {
                this.signList.push({ label: "企业印章", type: 2, sealData: "", active: false, sealKind: 'corp,project' })
              }
            }
            if (ownerSign[0]) {
              this.signList.push({
                label: "个人名章",
                type: 1,
                sealData: ownerSign[0].sealData,
                sealId: ownerSign[0].sealId,
                active: true,
                sealKind: ownerSign[0].sealKind
              })
            } else {
              if (this.showPersonal) {
                this.signList.push({ label: "个人名章", type: 1, sealData: "", active: false, sealKind: 'personal' })
              }
            }
            // if (authSign.length) {
            //   authSign[0].active = true;
            // } else if (ownerSign.length) {
            //   ownerSign[0].active = true;
            // }

            // this.signList.forEach((item, index) => {
            //   if (item.type == 1) {
            //     if (ownerSign[0]) {
            //       item = ownerSign[0];
            //       this.$set(item, 'active', false)
            //     }
            //   } else if (item.type == 2) {
            //     if (this.companySealList[0]) {
            //       item = this.companySealList[0];
            //       item.type = 2;
            //       this.$set(item, 'active', true)
            //       item.label = "企业印章";
            //     }
            //   }
            //   this.$set(this.signList, index, item);
            // });

            this.signList = this.signList.concat(authSign);

            // 设置一个除了项目章之外 的 默认选中章
            this.signList.some(s => {
              if (!'corp,project'.includes(s.sealKind) && s.sealData) {
                this.$set(s, 'active', true)
                return true
              }
            })
            console.log(this.signList, '------init');

            // 个人签章
            if (this.showPersonal) {
              this.getAccountInfo();
            } else {
              this.signDialogVisible = true;
            }
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    // 预览/创建签章
    setSeal(opt, refresh) {
    },
    // 获取账户信息
    getAccountInfo() {
      const params = {
        acctId: this.currentAcctId
      };
      InterfaceService.accountInfo(
        params,
        data => {
          if (data.respCode === "0000") {
            const result = data.respData;
            this.signUserinfo = result;
            this.selfEsignId = result.esignId;
            this.signDialogVisible = true;
            // 未开设电子账户逻辑 注释
            // if (result.ecAcctIdFlg == 0) {
            //   this.signDialogVisible = false;
            //   this.$refs["authentication"].open(result);
            // } else if (result.ecAcctIdFlg == 1) {
            //   this.signDialogVisible = true;
            // }
          } else {
            this.$message.error(data.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    // 签署
    signFile(preSign) {
      let sealList = [];
      console.log(this.signList, '---signList');

      this.signList.forEach((item, index) => {
        if (item.active) {
          sealList.push({
            sealDataType: item.type == 0 ? 1 : item.type,
            sealId: item.sealId,
            sealKind: item.sealKind || ''
          })
        }
      });
      this.totalEventNum = this.eventList && this.eventList.length || 0
      this.percentage = 0;
      this.signFailNum = 0;
      this.totalsignNum = 0;
      this.orderList = [];
      this.totalOrders = [];
      this.showBrokerBatchErrMgs = true;
      if (this.brokerRole && !this.preview) {
        const events = this.filterEventId();
        events.forEach(item => {
          this.signFilePost(sealList, item);
        })
      } else {
        this.signFilePost(sealList);
      }
    },
    signFilePost(sealList, ev) {
      let params = {};
      if (this.brokerRole && !this.preview) {
        params = {
          eventIdList: [ev],
          sealDataList: sealList,
        };
      } else {
        const events = this.filterEventId();
        params = {
          eventIdList: events,
          sealDataList: sealList,
        };
      }
      if (!this.smsValid) {
        params.mobile = this.mobile;
        params.identifyCode = this.smsCode;
      }
      if (this.brokerRole && !this.preview) {
        this.showSignTip = true;
        this.isLoading = true;
      }
      console.log(params);
      InterfaceService.signFile(
        params,
        data => {
          const res = data.respData;
          if (res.respCode === "0000") {
            this.signDialogVisible = false;
            this.confirmDialogVisible = false;
            let valid = true;
            const respList = res.respList || [];
            let failMsg = "";
            if (!this.brokerRole) {
              respList.forEach(item => {
                const signList = item.signList || [];
                signList.forEach(_item => {
                  if (_item.signMsg !== 'success') {
                    valid = false;
                    // msgList.push(_item.signMsg);
                    failMsg = `签署失败，失败原因：<br>${_item.signMsg}`
                  }
                })
              });
              // 签章成功
              if (valid) {
                this.$emit("close", true);
                this.$store.dispatch("setSignSMSValid", true);
              } else { // 签章失败
                // const msg = msgList.join('<br/>');
                this.$alert(failMsg, {
                  dangerouslyUseHTMLString: true,
                  customClass: "alert-box",
                  center: true,
                  confirmButtonText: "知道了",
                  callback: action => {
                    this.$emit("close", false, respList);
                  }
                });
              }
            } else {            //博置角色签章
              // let orderList = [];
              // let totalOrders = []
              respList.forEach(item => {
                const signList = item.signList || [];
                signList.forEach(_item => {
                  let onOff = true;
                  this.totalOrders.forEach(ev => {
                    if (item.orderNo == ev) {
                      onOff = false
                    }
                  });
                  if (onOff) {
                    this.totalOrders.push(item.orderNo)
                  }
                  // totalOrders.push(item.orderNo);
                  if (_item.signMsg !== 'success') {
                    let onOff = true;
                    this.orderList.forEach(ev => {
                      if (item.orderNo == ev) {
                        onOff = false
                      }
                    });
                    if (onOff) {
                      this.orderList.push(item.orderNo)
                    }
                    failMsg = _item.signMsg
                  }
                })
              });
              // let signFailListNo = orderList.filter(function(element,index,self){
              //     return self.indexOf(element) === index;
              // });
              // let totalOrdersNo = totalOrders.filter(function(element,index,self){
              //     return self.indexOf(element) === index;
              // });
              // this.signFailNum += signFailListNo.length;
              // this.totalsignNum += totalOrdersNo.length;
              this.signFailNum = this.orderList.length;
              this.totalsignNum = this.totalOrders.length;
              //博置进入预览页面签章时失败弹窗，成功返回并进入签章成功页面
              if (this.preview) {
                if (this.signFailNum == 0) {
                  this.$emit("close", true);
                  this.$store.dispatch("setSignSMSValid", true);
                } else {
                  // const msg = msgList.join('<br/>');
                  // this.$alert(msg, '签署失败', {
                  this.$alert(failMsg, {
                    dangerouslyUseHTMLString: true,
                    customClass: "alert-box",
                    center: true,
                    confirmButtonText: "知道了",
                    callback: action => { }
                  });
                }
              }
            }

          } else {
            if ((this.brokerRole && this.preview) || !this.brokerRole || this.showBrokerBatchErrMgs) {
              this.$message.error(res.respMsg);
              this.showBrokerBatchErrMgs = false
            }
          }
          //博置批量签章时只返回成功失败条数
          if (this.totalsignNum) {
            if (this.brokerRole && !this.preview) {
              this.percentage += Number((100 / this.totalEventNum).toFixed(2));
              if (this.percentage > 99) {
                console.log(this.signFailNum, this.totalsignNum);
                if (this.signFailNum < this.totalsignNum) {
                  this.$store.dispatch("setSignSMSValid", true);
                }
                this.$emit("close", true, this.signFailNum);
                this.showSignTip = false;
                this.isLoading = false;
              }
            }
          } else {
            this.showSignTip = false;
            this.isLoading = false;
          }

        },
        data => {
          this.showSignTip = false;
          this.isLoading = false;
        },
        () => {
          if (!this.brokerRole || (this.brokerRole && this.preview)) {
            this.isLoading = true
          }
        },
        () => {
          if (!this.brokerRole || (this.brokerRole && this.preview)) {
            this.isLoading = false
          }
        }
      );
    },
    // 发送验证码
    sendSMSCode() {
      const params = {
        sendType: "SMS",
        target: this.mobile,
        origTxCode: "050040",
        validateCode: this.picCode,
        sessionValidateCode: this.prePicCode
      };
      InterfaceService.getPhoneCode(
        params,
        data => {
          const res = data.respData;

          if (res.respCode === "0000") {
            this.prePicCode = this.picCode;

            this.$message({
              showClose: true,
              message: '验证码已发送',
              type: 'success'
            });

            this.startSMSCodeTime();
          } else {
            this.updatePicCode++;
            this.$message.error(res.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    startSMSCodeTime() {
      this.smsTimer = 60;
      if (this._timer) clearInterval(this._timer);
      this._timer = setInterval(() => {
        if (!this.smsTimer) {
          this.updatePicCode++;
          clearInterval(this._timer);
        } else {
          this.smsTimer--;
        }
      }, 1000);
    },
    filterEventId() {
      const events = [];
      this.eventList.forEach(ev => {
        events.push(ev.eventId);
      });
      return events;
    },
    init() {
      this.canCreat = true;
      // this.signList = this.$clone(signList);
      this.sealForm = Object.assign({}, sealForm);
      this.sealForm.mainText =
        this.$store.state.userInfo &&
        this.$store.state.userInfo.corpName;
      this.smsCode = "";
      this.$store.dispatch("getSignSMSValid");

      this.roleList = [];
      const authList = ["24", "32", "40"]; // 合同签字人角色可以添加授权
      if (this.userinfo.accountList.length) {
        this.eventList.forEach(event => {
          event.processList && event.processList.forEach(proc => {
            this.userinfo.accountList.forEach(acc => {
              if (acc.acctId === proc.acctId) {
                this.currentAcctId = acc.acctId
              }
            })
          })
        });
      } else {
        this.currentAcctId = this.acctId
      }
      this.eventList.forEach(ev => {
        if (ev.processList) {
          ev.processList.forEach(process => {
            if (process.processFlg == 0 && process.acctId == this.currentAcctId && this.roleList.indexOf(process.roleName) === -1) {
              this.roleList.push(process.roleName);
            }

            if (process.processFlg == 0 && process.acctId == this.currentAcctId && authList.indexOf(process.role) !== -1) {
              this.canAddAuthorize = true;
            }
          });
        }
      });
      this.getSealListByEvent();

    }
  },
  destroyed() {
    clearInterval(this._timer);
  }
};
</script>

<style lang="scss" scoped>
p {
  /*margin: 10px 0;*/
}

.link {
  text-decoration: underline;
  cursor: pointer;
  color: #0082ff;
  &:hover {
    color: #0082ff;
  }
  &:active {
    color: #4c9cdd;
  }
}

.preview-seal {
  position: relative;
  display: inline-block;
  vertical-align: middle;
  margin: 10px 0 -5px;
  width: 120px;
  text-align: center;

  img {
    max-width: 100%;
    max-height: 100%;
    vertical-align: middle;
  }

  label {
    display: inline-block;
    margin: 10px 0;
    color: #888888;
  }

  i {
    font-size: 30px;
    color: #ccc;
  }

  .preview-seal-content {
    position: relative;
    width: 100px;
    height: 100px;
    line-height: 96px;
    margin: 0 auto;
    border: 1px solid #ccc;
    cursor: pointer;
    overflow: hidden;

    &.active {
      border-color: #9452ff;

      &:before,
      &:after {
        display: block;
      }
    }

    &:before {
      display: none;
      content: "";
      position: absolute;
      right: -10px;
      bottom: 0;
      width: 0;
      height: 0;
      border-bottom: 30px solid #9452ff;
      border-left: 30px solid transparent;
    }

    &:after {
      display: none;
      content: "";
      position: absolute;
      right: 0px;
      bottom: 5px;
      width: 10px;
      height: 5px;
      margin: auto;
      border-left: 2px solid #fff;
      border-bottom: 2px solid #fff;
      -webkit-transform: rotatex(-60deg);
      transform: rotatez(-60deg);
      -webkit-transform-origin: center;
      transform-origin: center;
    }

    .preview-seal-text {
      position: absolute;
      top: 3px;
      left: -40px;
      display: block;
      width: 100px;
      line-height: 20px;
      font-size: 12px;
      background: #eee;
      color: #fff;
      transform: rotatez(-45deg);
    }

    &.active .preview-seal-text {
      background: #9452ff;
    }
  }
}

.preview-sign {
  .preview-seal-content {
    border: 1px dashed #eee;

    &.active {
      border-style: solid;
    }
  }
}

.preview-company {
  margin: 0 10px;
  .preview-seal-content {
    width: 150px;
    height: 150px;
    line-height: 146px;
  }
}

.pic-code {
  width: 400px;
  margin: auto;
  margin-bottom: 20px;
  position: relative;
}

.sms-btn {
  width: 150px;
}

.float-tip {
  position: absolute;
  top: -18px;
  z-index: 1;
  display: inline-block;
  left: 50%;
  padding: 5px 10px;
  border-radius: 5px;
  white-space: nowrap;
  color: #ffffff;
  background: #9452ff;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.3);
  animation: float-tip-animate ease 1s 0s infinite alternate;
  &:before {
    position: absolute;
    bottom: -5px;
    left: 50%;
    transform: translate(-50%);
    content: "";
    border-top: 10px solid #9452ff;
    border-left: 8px solid transparent;
    border-right: 8px solid transparent;
  }
}
.mt40 {
  margin-top: 40px;
}
@keyframes float-tip-animate {
  from {
    transform: translatex(-50%) translateY(-2px);
  }
  to {
    transform: translatex(-50%) translateY(2px);
  }
}
/deep/ .el-input__inner {
  height: 34px;
  line-height: 34px;
}
.tel {
  position: absolute;
  right: 0;
  padding: 8px 10px !important;
}
.dialog-footer {
  p {
    line-height: 17px;
  }
}
.gray {
  -webkit-filter: grayscale(100%);
  -moz-filter: grayscale(100%);
  -ms-filter: grayscale(100%);
  -o-filter: grayscale(100%);

  filter: grayscale(100%);

  filter: gray;
}
</style>

