<template>
  <div class="quic-purchase-checkbox-list">
    <ul>
      <li v-for="(rItem, rIdx) of data" :key="rIdx">
        <span :title="rItem.title">{{rItem.title}}</span>
        <!--  rItem.isExpand  -->
        <div :class="['center', { off: rItem.isExpand}]">
          <div ref="checkboxGroupRef">
            <el-checkbox-group v-model="rItem.checkList" v-for="(item, idx) of rItem.checkBoxList" :key="idx" @change="handleCheckBoxChange">
              <el-checkbox :label="item.title" :title="item.title"></el-checkbox>
            </el-checkbox-group>
          </div>
        </div>
        <div :class="['shrink', { off: rItem.isExpand  }]" @click="rItem.isExpand = !rItem.isExpand" v-if="rItem.checkBoxList && rItem.checkBoxList.length > 4">
          {{rItem.isExpand ? '展开' : '收起' }}
          <i class="el-icon-arrow-down" v-if="rItem.isExpand"></i>
          <i class="el-icon-arrow-up" v-else></i>
        </div>
      </li>
    </ul>
  </div>
</template>
<script>
export default {
  props: ['data'],
  watch: {
    data: {
      handler(newName, oldName) {
        this.data.map(m => {
          m.isExpand === undefined && this.$set(m, 'isExpand', true)
        })
      },
      immediate: true
    }
  },
  mounted() {
  },
  computed: {
    showShrink() {
      return idx => {
        return this.$refs.checkboxGroupRef && this.$refs.checkboxGroupRef[idx] && this.$refs.checkboxGroupRef[idx].offsetHeight > 50
      }
    },
  },
  methods: {
    handleCheckBoxChange() {
      this.$emit('outputCheckbox')
    },
  },
}
</script>
<style lang="scss" scoped>
.quic-purchase-checkbox-list {
  // max-height: 353px;
  // overflow-x: auto;
  ul {
    overflow: hidden;
    li {
      display: flex;
      border-top: 1px solid #cacaca;
      position: relative;
      &:last-child {
        border-bottom: 1px solid #cacaca;
      }
      & > span {
        background: #eaeaea;
        width: 108px;
        padding: 12px;
        padding-right: 12px;
        font-weight: bold;
        margin-right: 22px;
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
        display: block;
        line-height: 20px;
      }
      .center {
        padding: 12px;
        padding-top: 0;
        width: 620px;
        background: #fff;
        height: auto;
        transition: all 0.3s linear;
        & > div {
          text-align: left;
          width: 100%;
          & > div {
            display: inline-block;
          }
        }
        &.off {
          height: 43px;
        }
        /deep/ .el-checkbox-group {
          margin-top: 12px;
          width: 25%;
          &:first-child {
            margin-left: 0;
          }
          .el-checkbox__input {
            margin-top: -11px;
          }
          .el-checkbox__label {
            color: #383838;
            padding-right: 70px;
            color: #383838;
            text-overflow: ellipsis;
            white-space: pre;
            overflow: hidden;
            width: 200px;
          }
          .el-checkbox__inner {
            z-index: 0;
          }
          .is-checked {
            .el-checkbox__label {
              color: #ffd64e;
            }
          }
        }
      }
    }
  }
  .shrink {
    position: absolute;
    right: 10px;
    top: 1px;
    margin-top: 9px;
    border: 1px solid #333;
    font-size: 12px;
    font-weight: bold;
    height: 24px;
    line-height: 23px;
    width: 70px;
    display: flex;
    cursor: pointer;
    justify-content: center;
    align-items: center;
    user-select: none;
    i {
      margin-left: 4px;
      margin-top: -1px;
      color: #000;
      font-weight: bold;
    }
  }
}
</style>

