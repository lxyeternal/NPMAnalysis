<template>
  <div>
    <div class="order-status">
      <div class="status-info">
        <div class="status-info-content">
          <div>
            <p>
              <label>当前状态：</label>
              <span class="big">{{orderInfo.orderStatusDisp}}</span>
              <span v-if="(orderInfo.orderStatus == 'contractTerminating'
                                        || orderInfo.orderStatus == 'contractTerminated') && contractSignStatus()" @click="handleViweRelieveContract" class="relieve blue">
                查看解除协议
              </span>
              <span v-if="role=='S'&&orderInfo.orderStatus=='11'&&showHandleLink">您有要货单待处理&nbsp;&nbsp;
                <a @click="handleJumpRequire">快去处理
                  <i class="el-icon-arrow-right"></i>
                </a>
              </span>
            </p>
            <p v-if="orderInfo.orderStatus=='02'">
              <label>取消原因：</label>
              <span>{{orderInfo.orderOperMsg}}</span>
            </p>
            <p v-if="orderInfo.orderStatus=='04'">
              <label>拒绝原因：</label>
              <span>{{orderInfo.orderOperMsg}}</span>
            </p>
          </div>
        </div>
        <div class="status-info-content">
          <template v-if="role=='S'">
            <template v-if="orderInfo.orderStatus=='01'">
              <el-button type="primary" size="small" @click="handleConfirmOrderDialog">确认合同</el-button>
              <el-button size="small" @click="handleRejectOrderDialog">拒绝合同</el-button>
            </template>
            <template v-if="showCancelGoodsBtn.length && orderInfo.orderStatusDisp != '合同解除中'">
              <el-button size="small" type="primary" @click="handleConfirmSupplement">确认增补</el-button>
            </template>
          </template>

          <template v-if="role=='B'&&!specialPurChaseRole">
            <template v-if="showCancelGoodsBtn.length && orderInfo.orderStatusDisp != '合同解除中'">
              <el-button size="small" @click="handleCancelRefuseDialog">取消增补商品</el-button>
            </template>
            <template v-if="orderInfo.priceType=='Negotiated'">
              <template v-if="orderInfo.orderStatus=='01' || orderInfo.orderStatus=='04' || orderInfo.orderStatus=='14'">
                <el-button size="small" @click="handleModifyPrice">修改协议价</el-button>
              </template>
            </template>
            <template v-if="orderInfo.orderStatus=='01'">
              <el-button size="small" @click="handleCancelOrderDialog">取消选型</el-button>
            </template>
            <!-- BUG #6278 合同列表：合同尚未签章时，合同列表不应该显示“我要货”操作 -->
            <!-- <template v-if="allowRequire()">
              <el-button type="primary" size="small" @click="handleRequire()">我要货</el-button>
            </template> -->
          </template>
          <el-button v-if="allowSignContract('0') || allowSignContract('goodsList')" size="small" @click="handleContractPreview('contract')" :disabled="!signFlag">合同签章</el-button>
          <el-button v-if="allowSignContract('contractTerminateSign')" size="mini" @click="handleContractPreview('relieve')">合同解除签章</el-button>
        </div>
      </div>
    </div>
    <!-- 取消增补 -->
    <RefuseToAddDialog v-if="refuseToAddDialogVisible" :isRefuse="role=='S'" :selectedList="selectedList" :refuseDialogOptions="refuseDialogOptions" @outputSelected="outputRefuseSelected" :refuseToAddDialogVisible.sync="refuseToAddDialogVisible"></RefuseToAddDialog>

    <!-- 确认合同 -->
    <OrderConfirm ref="orderConfirm" @close="handleCloseOrderConfirm"></OrderConfirm>
    <!-- 拒绝合同 -->
    <RejectOrder ref="rejectOrder" @close="handleCloseRejectOrder"></RejectOrder>
    <!-- 取消合同 -->
    <CancelOrder ref="cancelOrder" @close="handleCloseCancelOrder"></CancelOrder>
    <!-- 合同预览 -->
    <ContractPreview ref="contractPreview" @close="handleClosePreview"></ContractPreview>
    <!-- 合同签章 -->
    <Signature ref="signature" @close="handleCloseSignature"></Signature>
  </div>
</template>

<script>
// import $ from "jquery";
import accountMixin from '@/mixins/account';
import OrderConfirm from "@/components/order/dialog/orderOperate/OrderConfirm";
import RejectOrder from "@/components/order/dialog/orderOperate/RejectOrder";
import CancelOrder from "@/components/order/dialog/orderOperate/CancelOrder";
import ContractPreview from "@/components/order/dialog/ContractPreview";
import Signature from "@/components/order/dialog/Signature";
import { InterfaceService } from "@/services/api";
import { filterEventByAcct, viewFile } from '@/utils/orderUtil';
import RefuseToAddDialog from '@/components/order/RefuseToAddDialog'

export default {
  mixins: [accountMixin],
  components: {
    OrderConfirm,
    RejectOrder,
    CancelOrder,
    ContractPreview,
    Signature,
    RefuseToAddDialog
  },
  props: ["orderNo", "orderInfo", "showHandleLink", "signFlag"],
  data() {
    return {
      attach: {},
      refuseToAddDialogVisible: false, // 取消增补
      selectedList: [],
      refuseDialogOptions: [],
    };
  },
  computed: {
    showCancelGoodsBtn() {
      let itemList = []
      if (!(this.orderInfo && this.orderInfo.relContractInfo)) return itemList
      try {
        itemList = this.orderInfo.relContractInfo.relContractList.filter(f => f.mainSubFlg === 'sub' && f.orderStatus === '01')
      } catch (error) {
        console.log('tryCatch - showCancelGoodsBtn: ', error)
      }

      return itemList
    }
  },
  watch: {
  },
  methods: {
    init() {
      this.refuseDialogOptions = [
        "不想要了",
        "订单下多了",
        "订单重复了",
        "其他"
      ]
    },
    handleConfirmSupplement() {
      const item = this.showCancelGoodsBtn
      let unconfirmedOrderNos = []
      item.forEach(f => unconfirmedOrderNos.push(f.orderNo))
      this.$router.push({
        path: '/supplierConfirmInitiateASupplement',
        query: {
          unconfirmedOrderNos: encodeURIComponent(unconfirmedOrderNos.toString())
        }
      })
    },
    // 取消增补
    handleCancelRefuseDialog() {
      this.selectedList = this.showCancelGoodsBtn
      this.selectedList.map(m => {
        m.value = m.orderCnt
        m.label = `第${m.value}笔清单`
      })

      this.refuseToAddDialogVisible = true
    },


    /**
     * 取消理由 返回
     */
    outputRefuseSelected(msg, selected) {

      this.rejectionListReasons = msg
      this.refuseToAddDialogVisible = false
      let itemList = []
      selected.map && selected.map(m => {
        this.selectedList.some(s => (s.value === m && itemList.push(s.orderNo)))
      })
      this.cancelOrder(itemList)
    },

    /**
     * 供应商拒绝订单
     */
    cancelOrder(itemList) {
      let orders = []

      itemList.map(m => {
        orders.push({
          orderNo: m,
          cancelReason: this.rejectionListReasons,
        })
      })

      const params = {
        orders
      }

      InterfaceService.cancelOrder(params, data => {
        if (data.respCode === "0000") {
          if (data.respData.respCode === "0000") {
            const result = data.respData.confirmRst || []
            this.handleResultFun(result, '取消')
          } else {
            this.$message.error(data.respData.respMsg);
          }
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },

    /**
     * 处理结果返回
     */
    handleResultFun(result, notcieFont) {
      this.$emit("refresh")
      // 如果有失败消息 用 alert 提示
      if (result.some(s => s.result == 0)) {
        let html = ''
        result.map(m => {
          html += `<p style="color: ${m.result == 0 ? 'red' : 'green'}"><span>${m.orderName || '暂无项目名称'}：</span> <span>${m.confirmMsg || '处理失败'}</span></p>`
        })
        this.$alert(html, `${notcieFont}订单提示信息`, {
          dangerouslyUseHTMLString: true
        });
      } else {
        this.$message.success('处理成功')
      }
    },


    // 确认合同弹窗
    handleConfirmOrderDialog() {
      const orders = [];
      orders.push(this.orderInfo);
      this.$refs["orderConfirm"].open(orders);
    },
    // 确认合同完成
    handleCloseOrderConfirm(bool) {
      if (bool) {
        this.$emit("refresh");
      }
    },
    // 查看解除协议
    handleViweRelieveContract() {
      let params = {};
      let documentTypeList = [];
      let bs = "";
      let hasbroker = this.orderInfo.brokerCorpId && this.orderInfo.brokerCorpId.length > 0;
      if (this.role == "B") {
        documentTypeList = ["purchaserContractTerminate", "purchaserContractTerminate_pdf"];
        hasbroker ? bs = "B" : bs = "S";
      } else if (this.role == "S") {
        documentTypeList = ["supplierContractTerminate", "supplierContractTerminate_pdf"];
        bs = "S"
      }
      params = {
        orderNo: this.orderNo,
        documentTypeList: documentTypeList,
        bs: bs
      };
      InterfaceService.getContractInfo(
        params,
        data => {
          if (data.respData.respCode === "0000") {
            let attachList = data.respData.documentInfos || [];
            let onOff = false;
            let url = ""
            attachList.forEach(item => {
              if (item.documentType == "purchaserContractTerminate_pdf" || "supplierContractTerminate_pdf") {
                onOff = true;
                url = item.attachUrl
              }
            });
            if (!onOff) {
              attachList.forEach(item => {
                if (item.documentType == "purchaserContractTerminate" || "supplierContractTerminate") {
                  url = item.attachUrl
                }
              })
            }
            if (url) {
              viewFile(url)
            }
          } else {
            this.$message.error(data.respData.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    // 拒绝合同弹窗
    handleRejectOrderDialog() {
      const order = {
        orderNo: this.orderNo
      };
      this.$refs["rejectOrder"].open(order, this.orderInfo.priceType);
    },
    // 拒绝合同完成
    handleCloseRejectOrder(bool) {
      if (bool) {
        this.$emit("refresh");
      }
    },
    // 取消合同弹窗
    handleCancelOrderDialog() {
      const order = {
        orderNo: this.orderNo
      };
      this.$refs["cancelOrder"].open(order);
    },
    // 取消合同完成
    handleCloseCancelOrder(bool) {
      if (bool) {
        this.$emit("refresh");
      }
    },
    // 要货
    handleRequire() {
      this.$router.push({
        path: "/launchGoods",
        query: { orderNo: this.orderNo }
      });
    },
    // 修改协议价
    handleModifyPrice() {
      this.$router.push({
        path: "/modifyPrice",
        query: { orderNo: this.orderNo }
      });
    },
    // 跳转要货单信息
    handleJumpRequire() {
      let topNum = $(".require-order-info").offset().top;
      $("html ,body").animate({ scrollTop: topNum }, 300);
    },
    // 合同预览
    handleContractPreview(orderType) {
      // this.$refs["contractPreview"].open(this.orderInfo);
      console.log(orderType);
      this.$router.push({
        path: "/contractSign",
        query: {
          orderNo: this.orderInfo.orderNo,
          orderType: orderType
        }
      });
    },
    handleClosePreview(attach) {
      if (attach) {
        this.handleSignContract(attach);
      }
    },
    // 合同签章
    handleSignContract(attach) {
      const events = [];
      events.push(attach);
      this.attach = attach;
      this.$refs["signature"].open(events, 'order');
    },
    // 合同签章完成
    handleCloseSignature(bool) {
      if (bool) {
        this.$router.push({
          path: "/signOrderSuccess",
          query: {
            attachUrl: this.attach.attachUrl
          }
        });
        // this.$emit("refresh");
      }
    },
    contractSignStatus() {
      let allow = true;
      if (this.orderInfo.eventList && this.orderInfo.eventList.length > 0) {
        this.orderInfo.eventList.forEach(item => {
          if (item.eventType == 0 && item.eventStatus != "2") {
            allow = false;
          }
        })
      } else {
        allow = false
      }
      return allow
    },
    // 是否允许要货
    allowRequire() {
      let allow = false;
      const order = this.orderInfo;
      // allow =
      //     order.requireLeftTotal > 0 &&
      //     (order.orderStatus == "03" || order.orderStatus == "11");
      allow = order.orderStatus == "03" || order.orderStatus == "11";
      allow = allow && !this.brokerRole;

      if (allow && order.eventList) {
        allow = false;
        order.eventList.forEach(ev => {
          // 外部采购合同签署后可以要货
          if (
            ev.eventType == 0 &&
            ev.eventStatus == 2 &&
            ev.documentType == "00"
          ) {
            allow = true;
          }
        });
      }
      return allow;
    },
    // 是否允许签署合同
    allowSignContract(type) {
      let allow = false;
      if (this.orderInfo && this.orderInfo.eventList) {
        let acctIdList = [];
        if (this.userinfo.accountList.length) {
          this.userinfo.accountList.forEach(item => {
            acctIdList.push(item.acctId)
          });
        } else {
          acctIdList.push(this.acctId)
        }
        const list = filterEventByAcct(
          this.orderInfo.eventList,
          type,
          acctIdList
        );
        list.forEach(item => {
          if (
            item.eventType == type &&
            (item.eventStatus == 0 || item.eventStatus == 1)
          ) {
            if (item.processList) {
              item.processList.forEach(process => {
                if (process.processFlg == 0) {
                  allow = true;
                }
              });
            }
          }
        });
      }
      if ((this.orderInfo.orderStatus == 'contractTerminating' || this.orderInfo.orderStatus == 'contractTerminated') && type == "0") {
        allow = false;
      }
      return allow;
    }
  },
  mounted() {
    this.init()
  }
};
</script>
<style lang="scss" scoped>
.order-status {
  height: 120px;
  margin: 20px 0;
  padding: 40px 20px 40px 80px;
  border: 1px solid #fddd74;
  background: url("../../assets/images/order-detail-bg.jpg") no-repeat;
  background-size: 100% 100%;
}

.status-info {
  display: flex;
  justify-content: space-between;
  height: 100%;
  line-height: 25px;
}

.status-info-content {
  display: flex;
  justify-content: center;
  align-content: center;
  font-size: 14px;
  label {
    color: #888888;
  }

  a {
    color: #0082ff;
  }

  button {
    align-self: center;
  }
  & > div {
    display: inline-block;
    align-self: center;
  }

  .big {
    font-size: 18px;
    color: #333;
  }
  .relieve {
    margin-left: 10px;
    cursor: pointer;
  }
}
</style>


