<template>
    <div>
        <!-- 提交签收单 -->
        <el-dialog class="dialog" title="提交签收单" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false">
            <div class="content" v-if="!isFull">
                <p>提交后将通知相关授权代表来签章验收。现在本批次要货单还有未实收货品，如何处理剩余未验收的货品？</p>
                <!-- <p>
                    <el-checkbox v-model="checked1" @change="handleSelect1"></el-checkbox>&nbsp;继续补货&nbsp;(供应商继续将为该批次剩余货品供货)</p>
                <p>
                    <el-checkbox v-model="checked2" @change="handleSelect2"></el-checkbox>&nbsp;直接退货&nbsp;(本批次剩余货品不再继续供货)</p> -->
            </div>
            <div class="content tc" v-if="isFull">
                <p>提交后将通知相关授权代表来签章验收。<br>请确认已全部验收本批次要货单。</p>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确认并提交</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">待供方补货</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            order: {},
            isFull: true,
            checked1: true,
            checked2: false
        };
    },
    methods: {
        open(data, isFull) {
            this.order = data;
            this.isFull = isFull;
            this.checked1 = true;
            this.checked2 = false;
            this.dialogVisible = true;
        },
        handleSelect1() {
            this.checked1 = true;
            this.checked2 = false;
        },
        handleSelect2() {
            this.checked1 = false;
            this.checked2 = true;
        },
        handleConfirm() {
            this.saveSignRecipt();
        },
        confirmRecipt() {
            const params = {
                deliveryNo: this.order.deliveryNo,
                // isNeedReplenishment: !this.isFull && this.checked1 ? "1" : "0"
                isNeedReplenishment: "0"
            };
            InterfaceService.signReciptConfirm(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.dialogVisible = false;
                        this.$message.success('提交成功')
                        this.$emit("close", true);
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        // 保存验收单
        saveSignRecipt() {
            const list = [];
            this.order.deliveryList.forEach(item => {
                list.push({
                    skuId: item.skuId,
                    receiveCount: item.receiveCnt,
                    requireDetailId: item.requireDetailId,
                    checkDescription: item.checkDescription
                });
            });
            console.log(list);
            const params = {
                deliveryNo: this.order.deliveryNo,
                deliveryList: list
            };
            InterfaceService.saveSignRecipt(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.confirmRecipt();
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
.content {
    margin: auto;
    text-align: center;
}
</style>
