<template>
  <div class="component-container">
    <div class="dialog-money" v-if="isAskForReasons()">
      <span>预付比例：{{prepaymentRatioValue}}%</span>
      <span class="bold">预付金额：<font class="red">{{prepaymentAmountValue}}元</font></span>
    </div>
    <div class="dialog-money" v-else-if="isAskForReasons('preProgress')">
      <span :title="formatShippingNoticeSelected">
        <font class="w134">发货通知单：</font>
        <font>
          <p v-for="(item, idx) in formatShippingNoticeSelected.split('、')" :key="idx">
            {{item && item.slice(0, item.lastIndexOf('.')) || ''}}
          </p>
        </font>
      </span>
      <span class="bold">预付金额：<font class="red">{{preProgressAmt}}元</font></span>
    </div>
    <div class="dialog-money" :class="{'three-columns': !twoColumns}" v-else-if="isAskForReasons('progress')">
      <template v-if="isDetaill">
        <!-- 供应商显示 -->
        <template v-if="showRole === 'S'">
          <span>
            <font>
              本期产值
              <el-tooltip effect="dark" placement="top">
                <div slot="content">
                  <p>{{isProfessionalSubcontracting ? '本期产值=进度审核报表中审核的【本期产值合计】' : '本期产值=应付对账单中【本次对账金额】' }}</p>
                </div>
                <i class="el-icon-question tooltip-name"></i>
              </el-tooltip>
              ：
            </font>
            <font>{{progressInfo.outputValue | formatMoney}}元</font>
          </span>
          <span>
            <font>累计应付金额
              <el-tooltip effect="dark" placement="top">
                <div slot="content">
                  <p>累计应付=【合同金额】*【预付款比例】+【累计产值】*（【按要求进场付货款比例】-【预付款付合同比例】）</p>
                </div>
                <i class="el-icon-question tooltip-name"></i>
              </el-tooltip>
              ：</font>
            <font>{{progressInfo.totalPayablesAmt | formatMoney}}元</font>
          </span>
          <span>
            <font>本次应付金额
              <el-tooltip effect="dark" placement="top">
                <div slot="content">
                  <p>本次应付=本期【累计应付】-往期【累计应付】</p>
                </div>
                <i class="el-icon-question tooltip-name"></i>
              </el-tooltip>
              ：</font>
            <font class="red">{{progressInfo.payablesAmt | formatMoney}}元</font>
          </span>
          <span>
            <font>累计完成产值
              <el-tooltip effect="dark" placement="top">
                <div slot="content">
                  <p>{{isProfessionalSubcontracting ?'累计产值=同一合同往期【本期产值合计】之和+【本期产值合计】' : '累计产值=应付对账单中【累计对账款金额】'}}</p>
                </div>
                <i class="el-icon-question tooltip-name"></i>
              </el-tooltip>
              ：</font>
            <font class="red">{{progressInfo.totalOutputValue | formatMoney}}元</font>
          </span>
          <span>
            <font>累计已付金额
              <el-tooltip effect="dark" placement="top">
                <div slot="content">
                  <p>累计已付=同一合同往期【本次申请金额】之和</p>
                </div>
                <i class="el-icon-question tooltip-name"></i>
              </el-tooltip>
              ：</font>
            <font>{{progressInfo.totalPaidAmt | formatMoney}}元</font>
          </span>
        </template>
        <!-- 采购商显示 -->
        <template v-if="showRole === 'B'">
          <span>
            <font>本期产值：</font>
            <font>{{progressInfo.outputValue | formatMoney}}元</font>
          </span>
          <span>
            <font>累计应付金额：</font>
            <font>{{progressInfo.totalPayablesAmt | formatMoney}}元</font>
          </span>
          <span>
            <font>扣款金额：</font>
            <font>{{progressInfo.chargeBackAmt | formatMoney}}元</font>
          </span>
          <span>
            <font>累计完成产值：</font>
            <font>{{progressInfo.totalOutputValue | formatMoney}}元</font>
          </span>
          <span>
            <font>累计已付金额：</font>
            <font>{{progressInfo.totalPaidAmt | formatMoney}}元</font>
          </span>
          <span>
            <font>本次应付金额：</font>
            <font class="red">{{progressInfo.payablesAmt | formatMoney}}元</font>
          </span>
        </template>
      </template>
      <template v-else>
        <span>
          <font>本期产值：</font>
          <font>{{progressInfo.outputValue | formatMoney}}元</font>
        </span>
        <span>
          <font>本次应付金额：</font>
          <font class="red">{{progressInfo.payablesAmt | formatMoney}}元</font>
        </span>
        <span>
          <font>累计完成产值：</font>
          <font>{{progressInfo.totalOutputValue | formatMoney}}元</font>
        </span>
        <span>
          <font>累计应付金额：</font>
          <font>{{progressInfo.totalPayablesAmt | formatMoney}}元</font>
        </span>
        <span>
          <font>累计已付金额：</font>
          <font>{{progressInfo.totalPaidAmt | formatMoney}}元</font>
        </span>
      </template>
    </div>
  </div>
</template>
<script>
export default {
  // isDetaill 详情显示, showRole: 详情显示区分 , twoColumns: 两行显示
  props: ['progressInfo', 'baseInfo', 'inPaymentType', 'prepaymentAmountValue', 'prepaymentRatioValue', 'formatShippingNoticeSelected', 'preProgressAmt', 'isDetaill', 'showRole', 'twoColumns'],
  computed: {
    // 地址
    bankAddress() {
      return item => {
        return `${item.provCodeDisp || ''} ${item.districtCodeDisp || ''} ${item.addr || ''}`
      }
    },
    // 是否预付款
    isAskForReasons() {
      return paymentType => this.baseInfo && this.baseInfo.paymentType === (paymentType || 'advance')
    },
    // 是否为专业分包
    isProfessionalSubcontracting() {
      return this.baseInfo && ['01', '03'].includes(this.baseInfo.orderCateCode)
    }
  },
  filters: {
    // 过滤 字符串显示 state: 默认 电话格式, bank: 银行卡格式
    formatString: (val, state) => {
      state = state || 'tel'
      val = val || ''

      let newVal = ''
      if (state === 'tel') {
        newVal = `${val.slice(0, 3)} ${val.slice(3, 7)} ${val.slice(7, val.length)}`
      } else {
        const len = Math.floor(val.length / 4)

        for (let i = 0; i < len; i++) {
          newVal += `${val.slice(4 * i, 4 * (i + 1))} `
          if (i + 1 >= len) newVal += val.slice(4 * (i + 1), val.length)
        }
      }

      return newVal
    }
  },
  mounted() {
  }
}
</script>
<style lang="scss" scoped>
.component-container {
  .dialog-money {
    padding: 0 22px 12px;
    background: #fef4f3;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    overflow: hidden;
    &.three-columns {
      justify-content: flex-start;
      span {
        width: 32%;
      }
    }
    span {
      margin-top: 12px;
      width: 48%;
      float: left;
    }
    span:first-child {
      text-overflow: ellipsis;
      display: inline-block;
      display: flex;
      line-height: 15px;
      font.w134 {
        white-space: pre;
      }
    }
  }
}
/deep/ [class*=" el-icon-"] {
  color: #aaa;
}
</style>
