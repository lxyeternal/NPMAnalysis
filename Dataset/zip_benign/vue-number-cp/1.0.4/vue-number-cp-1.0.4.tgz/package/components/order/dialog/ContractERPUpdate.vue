<template>
    <div>
        <!-- 修改合同ERP -->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false">
            <div class="tc">
                <el-form ref="form" :model="form" :rules="rules" label-width="180px">
                    <el-form-item label="明源ERP合同编号：" prop="externalCode">
                        <el-input v-model="form.externalCode" placeholder="请输入合同编号" :maxlength="256"></el-input>
                    </el-form-item>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">保存</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

const form = {
    sysCode: "",
    externalCode: ""
};

export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            orderNo: "",
            form: Object.assign({}, form),
            rules: {
                externalCode: [
                    {
                        required: true,
                        message: "请输入合同编号",
                        trigger: "blur"
                    }
                ]
            }
        };
    },
    methods: {
        open(data) {
            this.orderNo = data.orderNo;
            this.form.sysCode = data.sysCode;
            this.form.externalCode = data.externalCode;
            this.dialogVisible = true;
        },
        handleConfirm() {
            this.$refs["form"].validate(valid => {
                if (valid) {
                    this.submit();
                }
            });
        },
        submit() {
            const params = {
                orderNo: this.orderNo,
                sysCode: this.form.sysCode,
                externalCode: this.form.externalCode
            };
            InterfaceService.updateContractERP(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.dialogVisible = false;
                        this.$message.success("合同ERP更新成功");
                        this.$emit("close", true);
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;
}
</style>

