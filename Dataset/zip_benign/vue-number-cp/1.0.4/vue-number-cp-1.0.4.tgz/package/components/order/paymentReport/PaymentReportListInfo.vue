<template>
    <div class="content">
        <h3>请款计划
            <el-button class="fr" type="primary" size="small" style="width:120px" @click="handleOpenGen" icon="el-icon-circle-plus-outline">新增请款计划</el-button>
        </h3>
        <br>

        <el-row>
            <el-col :span="6">
                <h2>{{order.toDoCnt||0}}</h2>
                <p class="grey">待处理</p>
            </el-col>
            <el-col :span="6" class="divide">
                <h2>{{order.processingCnt||0}}</h2>
                <p class="grey">进行中</p>
            </el-col>
            <el-col :span="6" class="divide">
                <h2>{{order.rejectCnt||0}}</h2>
                <p class="grey">已驳回</p>
            </el-col>
        </el-row>

        <AddPaymentReport ref="addPaymentReport"></AddPaymentReport>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import AddPaymentReport from "@/components/order/paymentReport/AddPaymentReportDialog";
export default {
    mixins: [accountMixin],
    components: {
        AddPaymentReport
    },
    props: ["type", "order"],
    data() {
        return {
            todoCount: 3,
            doingCount: 4
        };
    },
    methods: {
        handleOpenGen() {
            this.$refs["addPaymentReport"].open();
        }
    }
};
</script>

<style lang="scss" scoped>
h3 {
    font-weight: bold;
    font-size: 18px;
}

h2 {
    font-weight: bold;
    font-size: 35px;
    line-height: 35px;
}

.content {
    margin-bottom: 20px;
    padding: 10px 26px;
    line-height: 25px;
    background: #f5f5f5;
}

.divide {
    margin-right: 20px;
}
</style>
