<template>
    <div>
        <div class="top">
            <span>
                <label>总数量:</label><em v-if="approvalInfo.goodsUnit">{{approvalInfo.totalBuyCount}}{{approvalInfo.goodsUnit}}</em>
            </span>
            <span>
                <label>总合价(不含税):</label>{{approvalInfo.outContractFee | formatMoney}}元
            </span>
            <span>
                <label>总增值税合价:</label>{{approvalInfo.outContractTax | formatMoney}}元
            </span>
            <span>
                <label>总合价(含税):</label>{{approvalInfo.outContractFeeWithTax | formatMoney}}元
            </span>
            <!--<span class="blue pointer fr" @click="getContractInfo">-->
                <!--下载货品清单-->
            <!--</span>-->
        </div>
        <div class="table">
            <table>
                <thead>
                <tr>
                    <td width="60">序号</td>
                    <td class="tl" width="260">货品名称/型号</td>
                    <td>数量</td>
                    <td>单位</td>
                    <td>单价（元）</td>
                    <td>税率</td>
                    <td>合价（元）</td>
                    <td>品牌</td>
                    <!--<td v-if="item.description">说明</td>-->
                </tr>
                </thead>
                <tbody v-for="(item,index) in orderList" :key="index">
                    <tr>
                        <td>{{computeIndex(index)}}</td>
                        <td class="tl" style="position: relative">
                            <div style="width: 200px;">
                                {{item.skuName}}
                                <div class="imgs" v-if="item.picUrl">
                                    <img class="null-img" src="../../../assets/images/invoice/null_img.png">
                                    <img class="main-img" :src="item.picUrl">
                                </div>
                            </div>
                            <p class="grey" v-if="item.model">型号：{{item.model}}</p>
                        </td>
                        <td>{{parseFloat(item.buyCount)}}</td>
                        <td>{{item.goodsUnit}}</td>
                        <td>
                            <p class="grey">(不含税)&nbsp;{{item.price |formatMoney}}</p>
                            <p class="grey">(增值税)&nbsp;{{item.unitTaxAmt |formatMoney}}</p>
                            <p>(含<em style="padding-left: 1em">税)&nbsp;{{item.unitAmtWithTax |formatMoney}}</em></p>
                        </td>
                        <td>{{item.taxRate|percent}}</td>
                        <td>
                            <p class="grey">(不含税)&nbsp;{{item.totalAmt |formatMoney}}</p>
                            <p class="grey">(增值税)&nbsp;{{item.totalTaxAmt |formatMoney}}</p>
                            <p>(含<em style="padding-left: 1em">税)&nbsp;{{item.totalAmtWithTax |formatMoney}}</em></p>
                        </td>
                        <td>{{item.brandNameCn}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="table-pagination" v-if="orderList.length">
            <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
            </el-pagination>
        </div>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    import { InterfaceService } from "@/services/api";
    import download from "@/utils/download";
    import Loading from "@/components/base/Loading";

    export default {
        name: "brokerGoodsList",
        components: {
            Loading
        },
        // props:["approvalInfo"],
        data(){
            return{
                approvalInfo:{},
                orderList:[],
                pageIndex:1,
                pageSize:10,
                total:0,
                attachUrl:"",
                documentName:"",
                contractType:"",
                executionId:"",
                orderNo:"",
                isLoading: false,
            }
        },
        watch:{
        },
        filters: {
            percent(val) {
                return (val * 100)+ "%";
            }
        },
        methods:{
            // 计算货物清单序号
            computeIndex(index) {
                let num = 0;
                num += (this.pageIndex-1) * this.pageSize + index + 1;
                return num;
            },
            handleCurrentChange(page) {
                this.pageIndex = page;
                this.getApprovalDetail();
                window.scrollTo(0,0)
            },
            //获取货品清单
            getContractInfo() {
                const params = {
                    orderNo: this.orderNo,
                    bs: "S",
                };
                InterfaceService.getContractInfo(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            let list = data.respData.documentInfos || [];
                            let onOff = false;
                            list.forEach((item) => {
                                if (item.documentType == "goodsList") {
                                    this.attachUrl = item.attachUrl;
                                    this.documentName = item.documentName;
                                    onOff = true
                                }
                            });
                            if (!onOff){
                                list.forEach((item) => {
                                    // 甲供——材料采购类取sDocumentType为1的清单
                                    if (this.contractType == "0") {
                                        if (item.documentType == "04" && item.sDocumentType == "1" ) {
                                            this.attachUrl = item.attachUrl;
                                            this.documentName = item.documentName;
                                        }
                                    // // 专业分包——施工类取sDocumentType为4的清单
                                    }else if (this.contractType == "1") {
                                        if (item.documentType == "04" && item.sDocumentType == "4") {
                                            this.attachUrl = item.attachUrl;
                                            this.documentName = item.documentName;
                                        }
                                    }
                                });
                            }
                            const files = [
                                { name: this.documentName, url: this.attachUrl }
                            ];
                            this.$download(files, () => {this.isLoading = true}, () => {this.isLoading = false}).then(() => {
                                this.$message.success("已下载");
                            });
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {
                    },
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleDownload(name,url){
                const x = new XMLHttpRequest();
                x.open("GET",url, true);
                x.responseType = "blob";
                x.onload = e => {
                    download(
                        x.response,
                        name+".xlsx",
                        x.response.type
                    );
                };
                x.send();
            },
            getApprovalDetail() {
                const params = {
                    executionId: this.executionId || '',
                    procDefKey:'CONTRACT_APPROVE_WF',
                    orderNo:this.orderNo,
                    pageIndex: this.pageIndex
                };
                InterfaceService.getApprovalDetail(
                    params,
                    data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            this.approvalInfo = data.respData || {};
                            console.log(this.approvalInfo);
                            this.orderList = this.approvalInfo.orderList;
                            this.attachUrl = this.approvalInfo.attachUrl;
                            this.contractType = this.approvalInfo.contractType;
                            this.contractName = this.approvalInfo.contractName;
                            this.pageSize = this.approvalInfo.pageSize;
                            this.total = this.approvalInfo.totalCount;
                        } else {
                            this.$message.error(res.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            init(){
                this.executionId = this.$route.query.executionId;
                this.orderNo = this.$route.query.orderNo;
                this.getApprovalDetail();
            }
        },
        mounted(){
            this.init()
        }
    }
</script>

<style scoped lang="scss">
    .top{
        display: flex;
        justify-content: space-between;
        justify-items: center;
        font-size: 14px;
        margin-bottom: 16px;
        span{
            float: left;
            margin-left: 40px;
        }
        &:nth-of-type(1) span{
            margin-left: 0;
        }
    }
    .pointer{
        cursor: pointer;
    }
    .table {
        /deep/ .el-button {
            font-size: 12px;
        }

        width: 100%;
        line-height: 23px;
        font-size: 12px;
        table {
            width: 100%;
        }
        td {
            padding: 14px 10px;
            vertical-align: middle;
            word-break: break-word;
        }

        thead {
            text-align: left;
            white-space: nowrap;
            font-size: 14px;
            color: #909399;
            background: #f5f5f5;
        }

        tbody {
            text-align: left;

            &:hover {
                background: #e8f3fd;
            }

            td {
                border-bottom: 1px solid #ebeef5;
            }

            .divide {
                border-left: 1px solid #ebeef5;
            }
        }
    }
    .table-pagination {
        margin: 50px 0 80px;
        text-align: center;
        color: #888888;
    }
    .imgs{
        position: absolute;
        width: 20px;
        height: 20px;
        right: 30px;
        top: 30px;
        .null-img{
            width: 20px;
            height: 20px;
        }
        &:hover {
            .main-img{
                display: block;
            }
        }
        .main-img{
            position: absolute;
            display: none;
            width: 260px;
            height: 260px;
        }
    }

</style>