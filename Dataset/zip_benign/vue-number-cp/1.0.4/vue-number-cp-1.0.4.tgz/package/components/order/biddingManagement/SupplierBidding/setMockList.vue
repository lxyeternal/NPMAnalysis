<template>
  <div class="setMockList">
    <div class="page">
      <div class="order-info-title">设置模拟清单</div>
      <!-- 设置模拟清单 -->
      <div class="box2">
        <div class="panel">
          <el-form class="form" size="small" label-width="140px" type="flex" justify="space-between">
            <el-row>
              <el-col :span="24">
                <el-form-item label="添加模拟商品情况：" class="business">
                  <el-radio-group v-model="completeStatus" @change="getSupMockList">
                    <el-radio :label="'0'">全部</el-radio>
                    <el-radio :label="'1'">未添加</el-radio>
                    <el-radio :label="'2'">已添加</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <div class="title_tab">
          <div v-show="isShowScroll" class="tabs__nav-prev" @click="scroll('left')"><i class="el-icon-caret-left"></i></div>
          <div class="tabs__nav" :class="{'isShowScroll':isShowScroll}" ref="tabs__nav">
            <ul ref="tabList">
              <li class="hand" v-for="(a,index) in mockList" :key="index+'li'" @click="mockNo=a.mockNo;samplePicFlg=a.samplePicFlg;getSupMockList()" :class="{active: mockNo==a.mockNo}">
                套餐：{{a.mockName}}
              </li>
            </ul>
          </div>
          <div v-show="isShowScroll" class="tabs__nav-next" @click="scroll('right')"><i class="el-icon-caret-right"></i></div>
        </div>
        <div class="total-price">总价(不含税)：<span>{{totalPrice | formatTwoDigits}}</span>元</div>
        <TableThead :TopDistance="660">
          <tr slot="tr">
            <td width="50px">序号</td>
            <td width="206px">商品名称</td>
            <td width="98px" v-if="samplePicFlg=='1'">示例图片</td>
            <td width="48px">技术<br>标准</td>
            <td>参数</td>
            <td width="58px">投标<br>品牌</td>
            <td width="74px">投标型号</td>
            <td width="100px" class="tr">数量(单位)</td>
            <td width="100px">单价(不含税)(元)</td>
            <td width="100px">总价(不含税)(元)</td>
            <td width="100px" class="tr">操作</td>
          </tr>
        </TableThead>
        <table class="table">
          <thead>
            <tr>
              <td width="50px">序号</td>
              <td width="206px">商品名称</td>
              <td width="98px" v-if="samplePicFlg=='1'">示例图片</td>
              <td width="48px">技术<br>标准</td>
              <td>参数</td>
              <td width="58px">投标<br>品牌</td>
              <td width="74px">投标型号</td>
              <td width="100px" class="tr">数量(单位)</td>
              <td width="100px">单价(不含税)(元)</td>
              <td width="100px">总价(不含税)(元)</td>
              <td width="100px" class="tr">操作</td>
            </tr>
          </thead>
          <tbody class="tbody-row" v-for="(b,index) in mockProdList" :key="index+'mockProdList'">
            <tr>
              <td rowspan="2">{{index+1}}</td>
              <td rowspan="2" class="textarea_box">{{b.bidProdName}}</td>
              <td rowspan="2" v-if="samplePicFlg=='1'">
                <!-- 图片上传 -->
                <div class="info-master-img" :class="{active:!b.ossPath}">
                  <img :src="b.ossPath" alt="">
                </div>
              </td>
              <td>要求</td>
              <td>{{b.requireParams}}</td>
              <td rowspan="2" class="purple">{{b.brandCn}}</td>
              <td rowspan="2" class="purple">{{b.model?b.model:'-'}}</td>
              <td rowspan="2" class="textarea_box tr">{{(b.prodCnt || '') | formatTwoDigits}}{{(b.prodUnit || '')}}</td>
              <td rowspan="2" class="tr purple">{{(b.unitPrice || '') | formatTwoDigits}}</td>
              <td rowspan="2" class="tr purple">{{ b.unitPriceAll | formatTwoDigits}}</td>
              <td rowspan="2" class="tr">
                <p class="hand blue" v-if="b.skuId" style="margin-bottom: 4px;" @click="$refs.addMockList.open([{supplierBidMockId:b.supplierBidMockId,submitBidNo: submitBidNo,mockNo:b.mockNo,skuId:b.skuId,bidProdNo:b.bidProdNo,operateType:'DELETE'}],mockNo,'',submitBidNo,supplierParams)">替换</p>
                <p class="hand blue" v-if="b.skuId" style="margin-bottom: 4px;" @click="saveSupMockList([{supplierBidMockId:b.supplierBidMockId,submitBidNo: submitBidNo,mockNo:b.mockNo,skuId:b.skuId,bidProdNo:b.bidProdNo,operateType:'DELETE'}])">清空</p>
                <p class=" hand blue"  @click="handleGoproduct(b)" v-if="b.skuId">商品详情</p>
                <p class="hand blue" v-else style="margin-bottom: 4px;white-space: nowrap;" @click="$refs.addMockList.open([],mockNo,b.bidProdNo,submitBidNo,supplierParams)">添加模拟商品</p>
              </td>
            </tr>
            <tr>
              <td>实际</td>
              <td class="purple">{{b.supplierParams}}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <!-- 底部按钮 -->
      <FixBottom class="bottom">
        <div class="tc">
          <el-button type="primary" @click="step('under')">下一步</el-button>
          <el-button @click="step('on')">上一步</el-button>
        </div>
      </FixBottom>
    </div>
    <!-- 新增模拟商品 -->
    <AddMockList ref="addMockList" @updateData="getSupMockList" :mockList="mockList"></AddMockList>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import { viewFile } from '@/utils/orderUtil';
import FixBottom from "@/components/base/FixBottom";
import AddMockList from "@/components/order/biddingManagement/dialog/addMockList";
import TableThead from "@/components/base/TableThead";
export default {
  components: {
    Loading,
    FixBottom,
    AddMockList,
    TableThead
  },
  props: ['mockList', 'submitBidNo', 'bidNo'],
  data() {
    return {
      isLoading: false,

      isShowScroll: false,
      mockNo: '',//当前模拟清单编号
      mockProdList: [],
      completeStatus: '0',
      samplePicFlg: '',// 列表是否显示示例图
      totalPrice: '',//总价(不含税)
      supplierParams: '',//属性
    }
  },
  watch: {
    mockList() {
      this.isScroll()
    }
  },
  mounted() {
    this.mockNo = this.mockList[0].mockNo
    this.samplePicFlg = this.mockList[0].samplePicFlg
    this.getSupMockList()
  },
  methods: {
    handleGoproduct(item) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: item.spuId,
          skuId: item.skuId,
          corpId: item.supplierCorpId
        }
      }).href, '_blank')
    },
    // 上一步,下一步
    step(type) {
      let a = this.mockProdList.some(i => { return !i.skuId })
      if (a && type == 'under') {
        this.$confirm(
          "模拟清单有未添加的商品，请检查，若点击【确认】，未添加的商品，视作自动放弃。",
          "你有未添加的商品",
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            confirmButtonText: "确定",
            cancelButtonText: '取消',
          }).then(() => {
            this.$emit('UpdateStep', ['setMockList', type])
          }).catch(() => {

          });
      } else {
        this.$emit('UpdateStep', ['setMockList', type])
      }
    },
    // 判断套餐是否出现滚动条
    isScroll() {
      this.$nextTick(() => {
        this.$refs.tabList.offsetWidth > 1190 ? this.isShowScroll = true : this.isShowScroll = false
      })
    },
    scroll(type) {
      type == 'left' ? this.$refs.tabs__nav.scrollTo(this.$refs.tabs__nav.scrollLeft - 1190, 0) : this.$refs.tabs__nav.scrollTo(this.$refs.tabs__nav.scrollLeft + 1190, 0)
    },
    // 供应商查看模拟清单
    getSupMockList() {
      let param = {
        mockNo: this.mockNo,
        submitBidNo: this.submitBidNo,
        completeStatus: this.completeStatus,
      }
      InterfaceService.getSupMockList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.mockProdList = data.respData.mockProdList || []
          if (this.mockProdList.length) { this.supplierParams = this.mockProdList[0].supplierParams || '' }
          this.totalPrice = 0
          this.mockProdList.forEach(i => {
            let unitPriceAll = ''
            if (!i.prodCnt || !i.unitPrice) {
              unitPriceAll = ''
            } else {
              unitPriceAll = String(Number(i.unitPrice) * Number(i.prodCnt))
            }
            this.$set(i, 'unitPriceAll', unitPriceAll)
            if (unitPriceAll) {
              this.totalPrice += Number(unitPriceAll)
            }
          })
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 采购商保存模拟清单
    saveSupMockList(list) {
      this.$confirm(
        "是否确认清空该条商品全部内容？清空后，不能撤回。",
        "清空商品",
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确认清空",
          cancelButtonText: '取消',
        }).then(() => {
          let param = {
            supplierMockList: list,
          }
          InterfaceService.saveSupMockList(param, data => {
            this.isLoading = false;
            if (data && data.respData && data.respData.respCode === "0000") {
              this.$message.success('清空成功')
              this.getSupMockList()
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        }).catch(() => {
        });
    },
  },
}
</script>
<style lang="scss" scoped>
/deep/ .el-row label {
  width: inherit;
  width: initial;
}
/deep/ .el-input {
  width: 100%;
}
/deep/ .textarea_box {
  .el-textarea__inner {
    padding: 10px;
    resize: none;
  }
}
/deep/ .business.el-form-item--small.el-form-item {
  margin-bottom: 9px;
}
.purple {
  color: #9452ff;
}
.setMockList {
  width: 100%;
  .page {
    position: relative;
    .box2 {
      .panel {
        background: rgba(249, 249, 249, 1);
        padding: 9px 0px 0px 0px;
        margin: 20px 0;
      }
      .title_tab {
        width: 100%;
        display: flex;
        overflow: hidden;
        .tabs__nav-prev,
        .tabs__nav-next {
          width: 16px;
          height: 25px;
          margin: 1px 0;
          cursor: pointer;
          background: linear-gradient(
            180deg,
            rgba(215, 176, 100, 1) 0%,
            rgba(236, 206, 139, 1) 100%
          );
          text-align: center;
          line-height: 25px;
          > i {
            color: #fff;
          }
        }
        .tabs__nav {
          width: 100%;
          overflow-x: auto;
          overflow-y: hidden;
          > ul {
            white-space: nowrap;
            display: inline-block;
            > li {
              min-width: 80px;
              height: 26px;
              line-height: 26px;
              color: #c99f4f;
              font-size: 12px;
              text-align: center;
              padding: 0 18px;
              border: 1px solid #c99f4f;
              border-radius: 4px 4px 0px 0px;
              position: relative;
              display: inline-block;
              &:hover,
              &.active {
                background: linear-gradient(
                  123deg,
                  rgba(215, 176, 100, 1) 0%,
                  rgba(236, 206, 139, 1) 100%
                );
                border: none;
                color: #fff;
              }
              .title_tab,
              > i {
                position: absolute;
                right: 2px;
                top: 4px;
              }
            }
          }
          &.isShowScroll {
            width: calc(100% - 40px);
            margin: 0 4px -10px;
          }
        }
      }
      .total-price {
        width: 100%;
        height: 30px;
        line-height: 30px;
        text-align: right;
        background-color: #f9f9f9;
        border: 1px solid #eee;
        color: #888;
        padding-right: 20px;
        > span {
          color: #444;
        }
      }
      .table {
        table-layout: fixed;
        width: 100%;
        font-size: 12px;
        td {
          padding: 10px 10px;
          vertical-align: middle;
          word-break: break-all;
          line-height: 17px;

          // 图片上传
          .info-master-img {
            width: 80px;
            height: 80px;
            position: relative;
            overflow: hidden;
            &.active {
              background-color: #eeeeee;
            }
            > img {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              pointer-events: none;
              height: auto;
            }
          }
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          // border-bottom: 1px solid #eee;
          background: #f9f9f9;
          color: rgba(136, 136, 136, 1);
          tr {
            border-left: 1px solid #eee;
            td {
              padding: 5px 10px;
              border-right: 1px solid #eee;
            }
          }
        }

        tbody {
          text-align: left;
          tr {
            border-left: 1px solid #eee;
            border-bottom: 1px solid #eee;
            td {
              border-right: 1px solid #eee;
            }
            // &:hover {
            //   background: #f0f8ff;
            // }
          }
        }
      }
    }
  }
}
</style>