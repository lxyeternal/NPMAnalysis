<template>
    <div style="position: relative;margin-top: 30px;">
        <PanelTitle :tabs="tabs" class="panel-title">
        </PanelTitle>
        <span v-if="executionId" class="blue hand download"  @click="handleBatchDownload()">打包下载</span>
        <div class="data-content" ref="content">
            <div v-if="approvalList == 0" class="f14">
                请先上传审批附件
            </div>
            <table ref="table" v-else>
                <tbody class="head">
                    <tr>
                        <th width="80%">审批资料</th>
                        <th width="20%" style="text-align: right" v-if="startButton">操作</th>
                    </tr>
                </tbody>
                <tbody>
                    <tr v-for="(item,index) in approvalList" :key="index" class="tbody-row">
                        <td width="80%">
                            <span class="blue pointer" @click="handleView(item.attachUrl)">{{item.attachName}}</span>
                        </td>
                        <td width="20%" style="text-align: right">
                            <span class="blue pointer" @click="handleDel(item)" v-if="startButton">删除</span>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <template v-if="startButton">
            <div class="upload">
                <input id="paymentFile'" name="paymentFile" type="file" multiple  @change="handlePaymentUpload($event)">
                <label for="paymentFile'"><i class="el-icon-plus"></i>上传附件</label>
            </div>
            <!--<el-input style="margin: 10px 0;" type="textarea" v-model="comment" placeholder="请填写审批意见,300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>-->
            <!--<div class="count">-->
                <!--<span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300-->
            <!--</div>-->
        </template>
        <FixBottom v-if="fixedBottomActive && startButton">
            <div class="fix-bottom">
                <el-button type="primary" v-if="applyFlg == '2'"  style="width: 120px" @click="handleConfirm">审批</el-button>
                <el-button type="primary" v-if="applyFlg != '2'"  style="width: 120px" @click="handleEditPaymentInfo('showAll')">完善资料</el-button>
                <el-button  style="width: 120px" @click="closeApproavlDialogVisible = true">关闭流程</el-button>
                <el-button  style="width: 120px" @click="handleCloseWindow()">返回列表</el-button>
            </div>
        </FixBottom>
        <FixBottom v-if="fixedBottomActive && canceledButton">
            <div class="fix-bottom">
                <el-button  style="width: 120px" @click="cancleApproavlDialogVisible = true">撤回</el-button>
                <el-button  style="width: 120px" @click="handleCloseWindow()">返回列表</el-button>
            </div>
        </FixBottom>
        <!--关闭审批-->
        <el-dialog class="dialog" title="关闭流程原因" :append-to-body="true" :lock-scroll="true" :visible.sync="closeApproavlDialogVisible" width="840px" center :close-on-click-modal="false" @close="closeEntryNum = 0;closeReason = ''">
            <div class="line-top"></div>
            <!--<div class="f14" style="text-align: left;margin-bottom: 10px;">关闭后，系统会将关闭原因反馈给合同创建人。</div>-->
            <div class="f14" style="text-align: left">关闭流程后，将无法恢复本请款审批信息，确认关闭吗?</div>
            <div class="f14" style="text-align: left">请填写关闭流程原因：</div>
            <el-input style="margin: 20px 0;" type="textarea"  class="textareaContainer"  v-model="closeReason" placeholder="请填写关闭流程原因,300字以内" clearable :maxlength="300" @input="handleCloseEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':closeEntryNum >= 300}"> {{closeEntryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button :disabled="!closeReason" type="primary" size="small" style="width: 100px" @click="handleCloseConfirm">提交关闭</el-button>
                <el-button size="small" style="width: 100px" @click="closeApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--确认撤回审批-->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="cancleApproavlDialogVisible" width="840px" center :close-on-click-modal="false" :show-close="false">
            <div class="f14 form-btns" style="margin-bottom: 10px">确认要撤回合同审批？撤回后的合同，在【待处理】中查看。</div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleCanceledConfirm()">确定撤回</el-button>
                <el-button size="small" style="width: 100px" @click="cancleApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <BrokerPaymentApproval ref="brokerPaymentApproval" @refresh="refresh" @goBack="goBack"></BrokerPaymentApproval>
        <ImprovePaymentInfo ref="improvePaymentInfo" @close="improveRefresh"></ImprovePaymentInfo>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>
<script>
    import Loading from "@/components/base/Loading";
    import { InterfaceService } from "@/services/api";
    import { viewFile } from '@/utils/orderUtil';
    import PanelTitle from "@/components/base/PanelTitle";
    import FixBottom from "@/components/base/FixBottom";
    import BrokerPaymentApproval from "@/components/order/broker/dialog/BrokerPaymentApproval";
    import ImprovePaymentInfo from "@/components/order/broker/dialog/ImprovePaymentInfo";
    export default {
        components: {
            Loading,
            PanelTitle,
            FixBottom,
            BrokerPaymentApproval,
            ImprovePaymentInfo,
        },
        props: ["approvalInfo","procDefKey","executionId","status"],
        data() {
            return {
                tabs:[
                    { label: "审批资料", index: 1, active: true }
                ],
                isLoading: false,
                fixedBottomActive:false,
                closeApproavlDialogVisible:false,
                cancleApproavlDialogVisible:false,
                startButton:false,
                approvalButton:false,
                canceledButton:false,
                contractApproveInfos: {},
                order:{},
                purchaserId:"",
                orderNo:"",
                title:"",
                closeReason:"",
                entryNum:0,
                closeEntryNum:0,
                comment:"",
                applyFlg:"",
                approvalList:[],
                pmtBusiInfo:{},
            };
        },
        filters: {
            percent(val) {
                return (val * 100)+ "%";
            }
        },
        watch: {
            approvalInfo(newVal) {
                this.init(newVal)
            },
        },
        methods: {
            init(data) {
                console.log(data);
                this.order = data;
                this.approvalList = data.execAttachList;
                this.applyFlg = this.approvalInfo.applyFlg || "";
                this.$nextTick(function () {
                    window.addEventListener('scroll', this.onScroll)
                });
                this.getOperateStatus();
            },
            handleCloseWindow(){
                window.opener=null;
                window.close();
            },
            handleView(url) {
                if (url) {
                  viewFile(url)
                }
            },
            handleConfirm(){
                const data ={
                    executionId : this.executionId,
                    procDefKey : this.procDefKey
                };
                this.$refs["brokerPaymentApproval"].open(data);
            },
            handleDel(item){
                this.$confirm(
                    "删除后将无法恢复文件，确认删除吗?",
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认",
                        cancelButtonText: '取消',
                    }).then(() => {
                        this.confirmDel(item);
                    }).catch(() => {
                        this.$message({
                            type: 'info',
                            message: '已取消删除'
                        });
                    });
            },
            confirmDel(item) {
                let flowAttachIdList = [];
                flowAttachIdList.push(item.flowAttachId);
                const params = {
                    flowAttachIdList: flowAttachIdList
                };
                InterfaceService.approvalDataDel(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message({
                                type: 'success',
                                message: '删除成功!',
                            });
                            this.$emit("refresh","init")
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            goBack(id,key){
                if (id && key) {
                    this.handleEditPaymentInfo("showAll");
                }
            },
            refresh(bool){
                if (bool) {
                    this.$emit("refresh")
                }
            },
            improveRefresh(bool,data){
                if (bool) {
                    if (data){
                        this.handleConfirm()
                    }
                    this.$emit("refresh")

                }
            },
            getOperateStatus(){
                this.startButton = false;
                this.approvalButton = false;
                this.canceledButton = false;
                let status = this.status;
                if (status == "start") {
                    this.startButton = true;
                }else if (status == "approve"){
                    this.approvalButton = true;
                }else if (status == "cancel") {
                    this.canceledButton = true
                }
            },
            handleEditPaymentInfo(type){
                this.$refs["improvePaymentInfo"].open(type,this.executionId,this.procDefKey );
            },

            handleBatchDownload() {
                let DownloadExecutionId = this.executionId;
                if (!DownloadExecutionId) {
                    return
                }else {
                    const params = {
                        executionId: DownloadExecutionId,
                        procDefKey:this.procDefKey
                    };
                    InterfaceService.approvalDataDownload(
                        params,
                        data => {
                            if (data.respData.respCode === "0000") {
                                // window.opener.location.reload();
                                let packingUrl = data.respData.attachUrl || "";
                                if (!packingUrl){
                                    return
                                }
                                window.open(packingUrl, "_blank");
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        },
                        data => {},
                        () => {
                            this.isLoading = true;
                        },
                        () => {
                            this.isLoading = false;
                        }
                    )
                }
            },
            handlePaymentUpload(e){
                const files = e.target.files;
                let upLoadList = [];
                for (let i in files) {
                    if (files[i].size) {
                        upLoadList.push({
                            attachName: files[i].name,
                            file: files[i]
                        });
                    }
                }
                e.value = "";
                this.getPaymentReceiptList(upLoadList).then(res => {
                    let attachList = res;
                    delete attachList[0].file
                    this.approvalDataAdd(attachList);
                });
                this.resetInputValue();
            },
            /**
             * 重置input value  防止 同一个文件连续提交 不触发 onchange事件
             */
            resetInputValue() {
                let isIE10 = false,
                    uploadInputs = document.getElementsByName('paymentFile') || []
                isIE10 = window.navigator.userAgent.indexOf('MSIE') >= 1;
                for (let i = 0, len = uploadInputs.length; i < len; i++) {
                    const element = uploadInputs[i];

                    if (isIE10) {
                        let form = document.createElement('form'),
                            beforInput = element.nextSibling,
                            parentInput = element.parentNode

                        form.appendChild(element)
                        form.reset()
                        parentInput.insertBefore(element, beforInput)
                    } else {
                        element.value = ''
                    }

                }
            },
            onScroll(){
                let scrolled = document.documentElement.scrollTop || document.body.scrollTop;
                this.fixedBottomActive = scrolled >= 400;
            },
            getPaymentReceiptList(upLoadList) {
                return new Promise((resolve, reject) => {
                    let arr = upLoadList;
                    this.uploadReciptToOss(arr).then(res => {
                        arr.forEach((item, index) => {
                            res.forEach(oss => {
                                if (index == oss.index) {
                                    item.attachUrl = oss.url;
                                }
                            });
                        });
                        resolve(arr);
                    });
                });
            },
            //  确认撤回
            handleCanceledConfirm(){
                const params = {
                    executionId : this.executionId,
                    procDefKey : this.procDefKey
                };
                InterfaceService.revokeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("撤回成功");
                            this.$emit("refresh");
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
                this.cancleApproavlDialogVisible = false;

            },
            handleCloseConfirm(){
                let params = {
                    executionId : this.executionId,
                    procDefKey: this.procDefKey,
                    comment: this.closeReason,
                };
                InterfaceService.closeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("关闭流程成功");
                            this.closeApproavlDialogVisible = false;
                            this.closeReason = "";
                            this.$emit("close");
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleEntry(ev){
                this.entryNum = ev.length
            },
            handleCloseEntry(ev){
                this.closeEntryNum = ev.length
            },
            fillZero(val) {
                return val <= 9 ? "0" + val : val;
            },
            uploadReciptToOss(arr) {
                return new Promise((resolve, reject) => {
                    //去后端拿签名
                    InterfaceService.getOssSignature(
                        { type: "1" },
                        data => {
                            const promiseList = [];
                            arr.forEach((item, index) => {
                                const now = new Date();
                                const date = {
                                    y: now.getFullYear(),
                                    m: this.fillZero(now.getMonth() + 1),
                                    d: this.fillZero(now.getDate()),
                                    h: this.fillZero(now.getHours()),
                                    i: this.fillZero(now.getMinutes()),
                                    s: this.fillZero(now.getSeconds())
                                };
                                let dateStr = `${date.y}${date.m}${date.d}${
                                    date.h
                                    }${date.i}${date.s}`;
                                let dirName = `${
                                    this.orderNo
                                    }/approveFiles/${dateStr}/`;
                                const promise = new Promise(_resolve => {
                                    this.uploadHander(
                                        data,
                                        index,
                                        item.file,
                                        dirName,
                                        (pos, file, dir, signature) => {
                                            let u = signature.dir + dir + file.name;
                                            _resolve({ index: index, url: u });
                                        }
                                    );
                                });
                                promiseList.push(promise);
                            });
                            Promise.all(promiseList).then(values => {
                                resolve(values);
                            });
                        },
                        data => {}
                    );
                });
            },
            uploadHander(data, pos, file, dirName, callBack) {
                InterfaceService.uploadToOss(data, file, dirName, pos, callBack);
            },
            approvalDataAdd(attachList){
                const params = {
                    executionId: this.executionId ,
                    attachList:attachList,
                };
                InterfaceService.approvalDataAdd(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$emit("refresh","init")
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            viewNewDate(){
                let height = this.$refs.table.offsetHeight;
                if (height > 300) {
                    this.$refs.content.scrollTop = this.$refs.table.scrollHeight;
                }
            }
        },
        destroyed(){
            window.removeEventListener('scroll', this.onScroll)
        }
    };
</script>

<style lang="scss" scoped>
    .info {
        color: #888888;
    }
    .dialog {
        line-height: 25px;
    }
    .error-info {
        color: #f56c6c;
        font-size: 12px;
        line-height: 1;
        padding-top: 4px;
        position: absolute;
        top: 100%;
        left: 0;
    }
    .order-info-title {
        margin: 5px -10px;
        margin-bottom: 10px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
        text-align: left;
    }
    .data-content{
        position: relative;
        max-height: 330px;
        overflow-y: auto;
        table {
            table-layout: fixed;
            width: 100%;
            line-height: 23px;
            font-size: 12px;
            display: table;
            background: #f5f8f9;

            td,th {
                padding: 6px 10px;
                vertical-align: middle;
                word-break: break-word;
                text-align: left;
            }
            .head {
                font-size: 14px;
                text-align: left;
                white-space: nowrap;
                color: #909399;
                background: #f5f5f5;
                border-bottom: 1px solid #fff;
            }
            .tbody-row:hover {
                background: #e8f3fd;
            }
            tbody {
                text-align: center;
                display: block;
                width: 100%;
                tr {
                    display: table;
                    width: 100%;
                    table-layout: fixed;
                }
                td {
                    border-bottom: 1px solid #ebeef5;
                }
            }
        }

    }
    .pointer {
        cursor: pointer;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }

        .active {
            color: #ffd64e;
        }
    }
    .tax{
        width: 100%;
        vertical-align:baseline;
        margin-bottom: 20px;
        td{
            width: 33%;
            padding: 4px 10px;
            background: #f5f5f5;
            vertical-align:middle;
            text-align: left;
        }
    }
    .upload {
        width: 100%;
        height: 40px;
        line-height: 40px;
        background: #f5f5f5;
        border-top: 2px solid #fff;
        margin: 0 auto 20px;
        text-align: center;
        input {
            position: absolute;
            left: -9999px;
            width: 0px;
            height: 0px;
            overflow: hidden;
            opacity: 0;
        }

        label {
            cursor: pointer;
            color: #0082ff;
        }
    }
    /deep/ .el-dialog__body{
        padding-bottom: 0;
    }
    /deep/ .el-dialog__footer{
        padding-top: 0;
    }
    /deep/ .el-button{
        width: 100px;
    }
    .dialog-footer {
        margin: 20px auto 0;
    }
    .count{
        float: right;
        width: 100%;
        text-align: right;
        margin-bottom: 20px;
        span.red{
            color: #f00;
        }
    }
    .fix-bottom{
        width: 100%;
        margin: 0 auto;
        text-align: center;
    }
    .download{
        position: absolute;
        right: 10px;
        top: 12px;
    }
    /deep/.textareaContainer {
        .el-textarea__inner {
            min-height: 140px !important;
        }
    }
</style>
