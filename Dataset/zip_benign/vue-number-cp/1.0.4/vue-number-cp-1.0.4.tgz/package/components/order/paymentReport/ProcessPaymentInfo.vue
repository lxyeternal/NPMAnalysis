<template>
    <div>
        <table class="table">
            <colgroup>
                <col width="200">
                <col>
            </colgroup>
            <tr v-if="type==='progress'" v-for="(item,key) in billInfo" :key="key">
                <td>{{key|billFilter}}</td>
                <td>
                    <div class="bill-item" v-for="(row,index) in item" :key="index">
                        {{row.deliveryName || row.requireName || row.statementName || row.fileName}}
                        <span class="fr">
                            <a v-if="!row.file" class="pointer" @click="handlePreview(row)">预览</a>
                            <a class="pointer" @click="handleDel(item, index)">删除</a>
                        </span>
                    </div>
                    <div class="bill-upload">
                        <input :id="key+'-file'" type="file" @change="handleUpload($event,item)">
                        <label :for="key+'-file'">上传</label>
                    </div>
                </td>
            </tr>
            <tr>
                <td>收款银行账号</td>
                <td>
                    <div>
                        <el-form label-width="150px" size="mini" label-position="left">
                            <el-form-item label="开户名称：">
                                <span>{{bankInfo.bankAcctName}}</span>
                            </el-form-item>
                            <el-form-item label="开户银行：">
                                <span>{{bankInfo.bankName}}</span>
                            </el-form-item>
                            <el-form-item label="银行账号：">
                                <span>{{bankInfo.bankAcctNo}}</span>
                            </el-form-item>
                            <el-form-item label="纳税人识别号：">
                                <span>{{bankInfo.taxPayerId}}</span>
                            </el-form-item>
                            <el-form-item label="开户行地址：">
                                <span>{{bankInfo.provCodeDisp}}{{bankInfo.cityCodeDisp}}{{bankInfo.districtCodeDisp}}{{bankInfo.addr}}</span>
                            </el-form-item>
                            <el-form-item label="开户行行号：">
                                <span>{{bankInfo.bankNo}}</span>
                            </el-form-item>
                            <el-form-item label="联系人：">
                                <span>{{bankInfo.name}}</span>
                            </el-form-item>
                            <el-form-item label="联系方式：">
                                <span>{{bankInfo.mobile}}</span>
                            </el-form-item>
                        </el-form>
                    </div>
                </td>
            </tr>
            <tr>
                <td>请款报告</td>
                <td>
                    <slot name="form"></slot>
                </td>
            </tr>
        </table>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
export default {
    components: {
        Loading
    },
    props: ["info", "type"],
    data() {
        return {
            isLoading: false,
            orderNo: "",
            billInfo: {
                requireList: [],
                deliveryList: [],
                statementList: []
            },
            bankInfo: {}
        };
    },
    watch: {
        info: {
            handler(val) {
                this.billInfo = Object.assign(this.billInfo, val);
                console.log( this.billInfo ,'- this.billInfo ');

            },
            deep: true
        }
    },
    filters: {
        billFilter(key) {
            const map = {
                deliveryList: "工地验收单",
                requireList: "发货通知单",
                statementList: "应付对账单"
            };
            return map[key] || key;
        }
    },
    methods: {
        handlePreview(item) {
            window.open(item.attachUrl || item.file.value, "_blank");
        },
        handleDel(item, index) {
            item.splice(index, 1);
        },
        handleUpload(e, item) {
            const file = e.target.files[0];
            if (file) {
                const fileType = file.name.split(".")[1];
                const reg = /(png|jpg|jpeg|xls|xlsx|pdf)/i;
                if (!reg.test(fileType)) {
                    this.$message.error("请上传图片、PDF、EXCEL格式文件");
                    return;
                }
                item.push({
                    fileName: file.name,
                    file: file
                });
                e.value = "";
            }
        },
        getBankList() {
            InterfaceService.getBankList(
                {},
                data => {
                    if (data.respData.respCode === "0000") {
                        const list = data.respData.bankList;
                        if (list && list.length > 0) {
                            this.bankInfo = list[0];
                        }
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        checkRecipt() {
            let msg;
            if (!this.billInfo.requireList.length) {
                msg = "发货通知单";
            } else if (!this.billInfo.deliveryList.length) {
                msg = "工地验收单";
            } else if (!this.billInfo.statementList.length) {
                msg = "应付对账单";
            }

            if (msg) {
                msg = `请上传${msg}，并确认请款周期`;
                this.$message.error(msg);
                return false;
            }

            return true;
        },
        // 获取可提交的数据
        getReceiptList() {
            return new Promise((resolve, reject) => {
                let arr = this.converData(this.billInfo);
                this.uploadReciptToOss(arr).then(res => {
                    arr.forEach((item, index) => {
                        if (!item.receiptNo) {
                            res.forEach(oss => {
                                if (index == oss.index) {
                                    item.receiptFileUrl = oss.url;
                                    delete item.receiptFile;
                                    delete item.receiptNo;
                                }
                            });
                        }
                    });
                    resolve(arr);
                });
            });
        },
        // 转换数据结构
        converData(data) {
            let arr = [];
            const map = {
                deliveryList: "delivery",
                requireList: "require",
                statementList: "statement"
            };
            for (let key in data) {
                let receiptType = map[key];
                let list = data[key];
                if (list && list.length) {
                    list.forEach(item => {
                        const obj = {};
                        obj.receiptType = receiptType;
                        obj.receiptNo =
                            item.requireNo ||
                            item.deliveryNo ||
                            item.statementNo;
                        obj.receiptFileName =
                            item.requireName ||
                            item.deliveryName ||
                            item.statementName ||
                            item.fileName.split(".")[0];
                        obj.receiptFile = item.file;
                        arr.push(obj);
                    });
                }
            }
            return arr;
        },
        fillZero(val) {
            return val <= 9 ? "0" + val : val;
        },
        // 文件上传到oss
        uploadReciptToOss(arr) {
            return new Promise((resolve, reject) => {
                //去后端拿签名
                InterfaceService.getOssSignature(
                    { type: "1" },
                    data => {
                        const promiseList = [];
                        arr.forEach((item, index) => {
                            if (item.receiptNo) return;
                            const now = new Date();
                            const date = {
                                y: now.getFullYear(),
                                m: this.fillZero(now.getMonth() + 1),
                                d: this.fillZero(now.getDate()),
                                h: this.fillZero(now.getHours()),
                                i: this.fillZero(now.getMinutes()),
                                s: this.fillZero(now.getSeconds())
                            };
                            let dateStr = `${date.y}${date.m}${date.d}${
                                date.h
                            }${date.i}${date.s}`;
                            let dirName = `${
                                this.orderNo
                            }/paymentApply/${dateStr}/`;

                            const promise = new Promise(_resolve => {
                                this.uploadHander(
                                    data,
                                    index,
                                    item.receiptFile,
                                    dirName,
                                    (pos, file, dir, signature) => {
                                        let u = signature.dir + dir + file.name;
                                        _resolve({ index: index, url: u });
                                    }
                                );
                            });
                            promiseList.push(promise);
                        });
                        Promise.all(promiseList).then(values => {
                            resolve(values);
                        });
                    },
                    data => {}
                );
            });
        },
        uploadHander(data, pos, file, dirName, callBack) {
            InterfaceService.uploadToOss(data, file, dirName, pos, callBack);
        }
    },
    mounted() {
        this.orderNo = this.$route.query.orderNo;
        this.getBankList();
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-form-item__label {
    font-size: 12px;
}

/deep/ .el-form-item--mini.el-form-item {
    margin-bottom: 0;
}

.pointer {
    margin-right: 5px;
    color: #0082ff;
}

.table {
    width: 100%;
    td {
        padding: 15px;
        border: 1px solid #cedeec;
    }

    td:first-child {
        font-weight: bold;
        background: #f0f8ff;
    }
}

.bill-item {
    margin-bottom: 10px;
}

.bill-upload {
    input {
        position: absolute;
        left: -9999px;
        width: 0px;
        height: 0px;
        overflow: hidden;
        opacity: 0;
    }

    label {
        cursor: pointer;
        color: #0082ff;
    }
}
</style>
