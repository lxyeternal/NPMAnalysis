<template>
  <div class="productList">
    <div class="content">
      <template v-if="!fromLaunchGoods">
        <!-- <div class="top-box" style="border-bottom: 1px dashed #eee;">
          <p>实际距离：<span>{{''}}</span></p>
          <p>发货地址：<span>{{''}}</span></p>
        </div> -->
        <div class="top-box" style="padding-bottom: 30px;border-bottom: 1px solid #eee;">
          <p>收货地址：<span>{{dataInfo.consigneeAddr ? dataInfo.consigneeAddr : '待供应商填写'}}</span></p>
          <p>收货人：<span>{{dataInfo.consigneeName ? dataInfo.consigneeName : '待供应商填写'}} {{dataInfo.consigneeMobile ? dataInfo.consigneeMobile : ''}}</span></p>
        </div>
        <div class="order-info-title" style="margin-bottom: 10px !important;">附加费用单价说明</div>
        <div class="top-box" style="border-bottom: 1px solid #eee;">
          <p>附加费用单价说明：<span>{{otherMoneyDesc || '无'}}</span></p>
        </div>

        <div class="order-info-title" style="margin-bottom: 10px !important;">商品清单</div>
      </template>
      <div style="padding-left: 10px; margin-bottom: 10px" v-else>
        <el-checkbox v-model="allChecked" @change="handleAllSelectTableRow" :disabled="!(dataInfo.contractProdBeans && dataInfo.contractProdBeans.filter(i=>{return !i.disabled}).length)">全选</el-checkbox>
      </div>
      <TableThead :TopDistance="supplierType === '0' ? 500 : 580">
        <tr slot="tr">
          <td width="40px" v-if="fromLaunchGoods">
            &nbsp;
          </td>
          <td width="54px" v-if="fromLaunchGoods">序号</td>
          <td width="270px">商品名称/型号</td>
          <td v-if="fromLaunchGoods" width="826px" class="tl">参数</td>
          <template v-else>
            <td width="270px" class="tr">综合单价(不含税)(元)</td>
            <td width="150px" class="tr">总数量</td>
            <td width="120px" class="tr">税率</td>
            <!-- <td width="150px" class="tr">附加费用单价(元)</td>
            <td width="150px" class="tr">运费(元)</td> -->
            <td width="200px" class="tr">小计(不含税)(元)</td>
          </template>
        </tr>
      </TableThead>
      <table class="table-default">
        <thead>
          <tr>
            <td width="40px" v-if="fromLaunchGoods">
              &nbsp;
            </td>
            <td width="54px" v-if="fromLaunchGoods">序号</td>
            <td width="270px">商品名称/型号</td>
            <td v-if="fromLaunchGoods" width="826px" class="tl">参数</td>
            <template v-else>
              <td width="270px" class="tr">综合单价(不含税)(元)</td>
              <td width="150px" class="tr">总数量</td>
              <td width="120px" class="tr">税率</td>
              <!-- <td width="150px" class="tr">附加费用单价(元)</td>
              <td width="150px" class="tr">运费(元)</td> -->
              <td width="200px" class="tr">小计(不含税)(元)</td>
            </template>
          </tr>
        </thead>
        <tbody v-for="(a,ind) in dataInfo.contractProdBeans" :key="ind">
          <tr>
            <td v-if="fromLaunchGoods">
              <el-checkbox :disabled="a.disabled" v-model="a.checked" @change="handleSelectTableRow(a,ind)"></el-checkbox>
            </td>
            <td width="34px" v-if="fromLaunchGoods">{{ind + 1 + ((pageIndex - 1) * pageSize)}}</td>
            <td>
              <img v-if="a.newSku === '0'" class="new_ico" src="@/assets/images/icon/new_ico.png" alt="">
              <div class="skuName">
                <div class="attachImg" :class="{'active':!a.attachUrl}">
                  <img v-if="a.attachUrl" :src="a.attachUrl" alt="">
                </div>
                <div class="model">
                  <p class="f12 ellipsisTwo">
                    <!-- <span v-if="dataInfo.enterFrom == '0'">{{a.categoryName}} </span> -->
                    <span :class="{hoverUnderline: !isEsImp, hand: !isEsImp}" :title="a.skuName" @click="!isEsImp && handleGoproduct(a)">{{a.skuName}}</span>
                  </p>
                  <p class="f12" style="margin: 10px 0">型号：{{a.model?a.model:'-'}}</p>

                  <p style="margin-top: 10px" v-if="a.specifications && a.specifications.length < 18">规格：{{a.specifications}}</p>
                  <el-popover popper-class="dark-popover" trigger="hover" placement="top" v-else-if="a.specifications && a.specifications.length >= 18">
                    <div style="color: #fff;width: 500px">
                      规格：{{a.specifications}}
                    </div>
                    <p style="margin-top: 10px" slot="reference" v-if="$isIE()">规格：{{a.specifications.slice(0,18) + "..."}}</p>
                    <p style="margin-top: 10px" slot="reference" v-else class="ellipsisTwo">规格：{{a.specifications}}</p>
                  </el-popover>

                  <p v-if="a.isCombination == '1' && a.isNewCom != '1'" class="tag">组价商品</p>
                  <el-popover popper-class="dark-popover" trigger="hover" placement="right">
                    <div style="color: #fff;width: 185px;">
                      新组价商品是指，代理商创建合同时，新组的商品。
                    </div>
                    <p v-if="a.isNewCom == '1'" slot="reference" class="tag triangle-arrow orange">新组价商品</p>
                  </el-popover>
                  <p class="tag bg-lightSteelBlue" v-if="a.surchangeLength && a.surchangeLength != '0'">含附加项</p>
                </div>
              </div>
            </td>
            <td v-if="fromLaunchGoods" class="tl" width="770px">{{a.attrInfoDisp || '-'}}</td>
            <template v-else>
              <!-- <td class="tr">
                <p>{{divisionContract ? a.inPrice : a.outPrice | formatMoney}}</p>
                <span class="grey f12" v-if="a.tdOrderSurchargeDetailList && a.tdOrderSurchargeDetailList.length">(含附加项费)</span>
              </td> -->

              <td class="tr">
                <p>{{comprehensivePreTaxUnitPrice(a) | formatMoney}}</p>
                <p class="gary"><span>(单价：{{divisionContract ? a.inPrice : a.outPrice | formatMoney}})</span></p>
                <p class="gary">
                  <span>
                    (运费单价：{{freightCalculationComputead(a) | formatMoney}})
                  </span>
                </p>
                <p class="red"><span>(附加费用单价：{{divisionContract ? a.inOtherFee : a.outOtherFee | formatMoney}})</span></p>
                <p class="gary" v-if="isEsImp"><span>(其他费用{{divisionContract ? a.extendInOtherFee : a.extendOutOtherFee | formatMoney}})</span></p>
              </td>

              <td class="tr">{{a.buyCount + (a.goodsUnit || '')}}</td>
              <td class="tr">{{(+a.taxRate)*100+'%'}}</td>
              <!-- <td class="tr">{{divisionContract ? a.inOtherFee : a.outOtherFee | formatMoney}}</td>
              <td class="tr">
                <span v-if="a.freightAmt">{{a.freightAmt | formatMoney}}</span>
                <span v-else>0</span>
              </td> -->
              <td class="tr">
                <p v-if="!(a.skuBelongTo && a.skuBelongTo.length)">{{divisionContract ? a.inTotalAmt : a.outTotalAmt | formatMoney}}</p>

                <template v-else>
                  <SupTable :divisionContract="divisionContract" :dataList="a.skuBelongTo" :text="divisionContract ? a.inTotalAmt : a.outTotalAmt" :index="ind"></SupTable>
                  <p class="f12 grey" style="margin-top: 0px">(含补充数量费用)</p>
                </template>
              </td>
            </template>
          </tr>
          <tr v-if="a.isCombination !== '1' && a.tdOrderSurchargeDetailList && a.tdOrderSurchargeDetailList.length">
            <td colspan="5" style="padding: 0px">
              <div class="additional-items tl" :style="{'margin-left' : fromLaunchGoods ? '0' : '76px'}">
                <div class="clearfloat">
                  <div class="fl f12 yellow bold" style="font-weight: 600;">附加项说明：</div>
                  <div class="fl" style="width: calc(100% - 90px);">
                    <p class="f12 tl" v-for="(add,index) in a.tdOrderSurchargeDetailList" :key="index+'bidSurchangeBeanList'">附加项{{index+1}}：{{add.surchangeName}}&nbsp;&nbsp;&nbsp;&nbsp;X{{add.surchangeUnitCnt + add.surchangeUnit}}<span class="purple">&nbsp;&nbsp;&nbsp;¥ {{divisionContract ? add.inSurchangeUnitPrice : add.outSurchangeUnitPrice | formatMoney}}</span></p>
                  </div>
                </div>
              </div>
            </td>
          </tr>
          <tr v-if="a.floorNo">
            <td colspan="5" style="padding: 0px">
              <div class="additional-items tl" :style="{'margin-left' : fromLaunchGoods ? '0' : '76px'}">
                <div class="clearfloat">
                  <div class="fl f12 yellow bold">楼号：</div>
                  <div class="fl" style="width: calc(100% - 90px);">
                    <p class="f12">{{a.floorNo}}</p>
                  </div>
                </div>
              </div>
            </td>
          </tr>
          <tr v-if="a.itemDescription">
            <td colspan="5" style="padding: 0px">
              <div class="additional-items tl" :style="{'margin-left' : fromLaunchGoods ? '0' : '76px'}">
                <div class="clearfloat">
                  <div class="fl f12 yellow bold">物料描述：</div>
                  <div class="fl" style="width: calc(100% - 90px);">
                    <p class="f12">{{a.itemDescription}}</p>
                  </div>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <!-- 空列表 -->
      <div class="accout-empty" v-if="!dataInfo.contractProdBeans.length&&!isLoading">
        <img src="@/assets/images/icon-no-product.png">
        <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
      </div>
      <div class="table-pagination" v-if="dataInfo.contractProdBeans.length">
        <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
        </el-pagination>
      </div>

      <div class="foot-box" v-if="!fromLaunchGoods">
        <p>合同价款(不含税)：<span>{{(divisionContract ? dataInfo.inContractFee : dataInfo.outContractFee) | formatMoney}}元</span></p>
        <!--<p>（含税前运费：{{(divisionContract ? dataInfo.inLogisticsFee : dataInfo.outLogisticsAmount) | formatMoney}}元）</p>-->
        <p>税率：<span>{{dataInfo.taxRate}}</span></p>
        <p>税额：<span>{{(divisionContract ? dataInfo.inContractTax : dataInfo.outContractTax) | formatMoney}}元</span></p>
        <p>合同价款(含税)：<span class="red">{{(divisionContract ? dataInfo.inContractFeeWithTax : dataInfo.outContractFeeWithTax) | formatMoney}}元</span></p>
      </div>
    </div>
    <FixBottom v-if="fromLaunchGoods">
      <!-- <div class="fl" style="line-height: 36px;margin-right: 30px;">
        <el-checkbox style="color: #fff" v-model="allChecked" @change="handleAllSelectTableRow" :disabled="!(dataInfo.contractProdBeans && dataInfo.contractProdBeans.filter(i=>{return !i.disabled}).length)">全选</el-checkbox>
      </div> -->
      <div class="fl" style="color: #fff;line-height: 36px;">
        已选{{storageGoodsList.filter(i=>{return i.checked}).length}}款
      </div>
      <div class="fr">
        <el-button style="width: 120px;" @click="handleAdd('0')">上一步</el-button>
        <el-button type="primary" style="width: 120px;" :disabled="!storageGoodsList.filter(i=>{return i.checked}).length" @click="handleAdd('1')">添加</el-button>
      </div>
    </FixBottom>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import TableThead from "@/components/base/TableThead";
import { NumberUtil } from '@/utils/numberUtil';
import FixBottom from "@/components/base/FixBottom";
import SupTable from "@/components/order/supplementaryContract/SupTable";

export default {
  components: {
    Loading,
    TableThead,
    FixBottom,
    SupTable
  },
  data() {
    return {
      isLoading: false,
      allChecked: false,

      dataInfo: {
        contractProdBeans: []
      },
      storageGoodsList: [],
      supplierType: '0',//供应商性质（"0":厂家;"1":代理商;"2":经销商;"3":施工;"4":监理）

      total: 0, //分页 总页数
      pageSize: 50, //分页 每页的长度
      pageIndex: 1, //当前页码
    };
  },
  watch: {
    keywords(newVal) {
      this.pageIndex = 1;
      this.getContractProductList(newVal)
    }
  },
  computed: {
    // 是否为ES 导入
    isEsImp() {
      return this.dataInfo && this.dataInfo.enterFrom == '2'
    },
    freightCalculationComputead() {
      return item => this.divisionContract ? +item.inFreightPrice : +item.outFreightPrice
    },
    comprehensivePreTaxUnitPrice() {
      return item => {
        let result = 0
        result = NumberUtil.numAdd(this.divisionContract ? +item.inPrice : +item.outPrice, this.freightCalculationComputead(item)) || 0

        result = NumberUtil.numAdd(result, this.divisionContract ? +item.inOtherFee : +item.outOtherFee)
        return result || 0
      }
    },
  },
  props: ['orderNo', "addRate", "divisionContract", "fromLaunchGoods", 'disabledGoodsList', 'keywords', 'otherMoneyDesc'],
  methods: {
    handleAdd(type) {
      if (type == '0') {
        this.$emit('checkedList', [], type)
      } else {
        let list = this.storageGoodsList.filter(item => { return item.checked }).concat(this.disabledGoodsList);
        this.$emit('checkedList', list, type)
      }

    },
    handleAllSelectTableRow(bool) {
      // let arr = [];
      // arr = [].concat(this.dataInfo.contractProdBeans.filter(i=>{return !i.disabled}));
      // arr.forEach(item => {
      //   item.checked = bool;
      // });
      // this.dataInfo.contractProdBeans = arr;
      this.dataInfo.contractProdBeans.filter(i => { return !i.disabled }).forEach(item => {
        item.checked = bool
      })
      this.recordChecked();
      this.checkBatch();
    },
    // 选中行
    handleSelectTableRow(item, index) {
      this.$set(this.dataInfo.contractProdBeans, index, item);
      this.recordChecked();
      this.checkBatch();
      this.checkAllSelect();
    },
    // 是否可批量
    checkBatch() {
      this.hasChecked = this.dataInfo.contractProdBeans.filter(i => { return !i.disabled }).some(item => {
        return item.checked;
      });
    },
    // 是否全选
    checkAllSelect() {
      this.allChecked = this.dataInfo.contractProdBeans.filter(i => { return !i.disabled }).every(item => {
        return item.checked;
      });
      if (!this.dataInfo.contractProdBeans.filter(i => { return !i.disabled }).length) {
        this.allChecked = false
      }
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      window.scrollTo(0, 0)
      this.getContractProductList(this.keywords)
    },
    handleGoproduct(item) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: item.spuId,
          skuId: item.skuId,
          corpId: item.corpId
        }
      }).href, '_blank')
    },
    // 小计
    subtotal(skuPrice, skuCount, type) {
      let num
      if (skuPrice && skuCount) {
        num = NumberUtil.accMul(Number(skuPrice), Number(skuCount))
        if (type) num = NumberUtil.formatMoney(num)
      } else {
        num = '-'
      }
      return num
    },
    // 查询合同货品清单
    getContractProductList(keywords) {
      let param = {
        orderNo: this.orderNo,
        pageIndex: this.pageIndex,
        keywords: keywords || '',
        selectPorder: '2'
      };
      // if (!this.fromLaunchGoods) {
      //   param.selectPorder = '2'
      // }
      InterfaceService.getContractProductList(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.dataInfo = data.respData || {};
          this.dataInfo.contractProdBeans = data.respData.contractProdBeans || [];
          this.dataInfo.contractProdBeans.forEach(i => {
            this.$set(i, 'checked', false)
          });
          this.storageGoodsList.forEach(item => {
            this.dataInfo.contractProdBeans.forEach(_item => {
              if (+item.orderDetailId === +_item.orderDetailId) {
                _item.checked = item.checked
              }
            });
          });
          if (this.disabledGoodsList) {
            this.disabledGoodsList.forEach(item => {
              this.dataInfo.contractProdBeans.forEach(_item => {
                if (+item.orderDetailId === +_item.orderDetailId) {
                  _item.disabled = true
                }
              });
            });
          }
          this.checkAllSelect();
          this.checkBatch();
          this.total = data.respData.totalCount
          console.log(data.respData.totalCount);
          this.pageSize = data.respData.pageSize
          this.pageIndex = data.respData.pageIndex
          console.log(this.dataInfo, '-this.dataInfo');

        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    recordChecked() {
      this.dataInfo.contractProdBeans.forEach(item => {
        let onOff = false;
        this.storageGoodsList.forEach(_item => {
          if (+item.orderDetailId === +_item.orderDetailId) {
            onOff = true;
            _item.checked = item.checked
          }
        })
        if (!onOff) {
          this.storageGoodsList.push(item)
        }
      })
      this.disabledGoodsList.forEach(item => {
        this.dataInfo.contractProdBeans.forEach(_item => {
          if (+item.orderDetailId === +_item.orderDetailId) {
            _item.disabled = true
          }
        });
      });
      console.log(this.storageGoodsList);
    },
  },
  mounted() {
    console.log(this.disabledGoodsList);
    this.supplierType = this.$store.state.userInfo.supplyType || ''
    this.getContractProductList()
  },
};
</script>

<style lang="scss" scoped>
.productList {
  width: 100%;
  padding-bottom: 100px;
  .content {
    .top-box {
      width: 100%;
      padding: 0px 0 20px;
      margin-bottom: 20px;
      > p {
        font-size: 12px;
        line-height: 17px;
        margin-bottom: 10px;
        color: #888;
        > span {
          color: #444;
        }
        &:last-child {
          margin-bottom: 0;
        }
      }
    }
    .table-default {
      margin-top: 0px;
      thead {
        tr {
          td {
            font-size: 14px;
            line-height: 20px;
          }
        }
      }
      tbody {
        border-bottom: 1px solid #eee !important;
        tr {
          border-bottom: none !important;
        }
      }
      td {
        font-size: 12px;
        position: relative;
        .new_ico {
          position: absolute;
          left: 0;
          top: 0;
          width: 39px;
          height: 39px;
          z-index: 1;
        }
        .skuName {
          display: flex;
          .attachImg {
            width: 60px;
            height: 60px;
            min-width: 60px;
            position: relative;
            overflow: hidden;
            &.active {
              background-color: #eee;
            }
            > img {
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              pointer-events: none;
              height: auto;
            }
          }
          .model {
            margin-left: 6px;
          }
        }
      }
    }
    .foot-box {
      width: 100%;
      padding: 20px 20px;
      background: #f9f9f9;
      > p {
        font-size: 12px;
        line-height: 17px;
        margin-bottom: 4px;
        color: #888;
        text-align: right;
        span {
          color: #444;
          font-size: 14px;
          &.red {
            font-weight: 600;
          }
        }
        > :last-child {
          margin-bottom: 0;
        }
      }
    }
  }
}
.gary {
  color: #999;
}
.additional-items {
  border-top: 1px dashed #eee;
  padding: 14px 0;
  width: 1114px;
  // > div {
  //   > div {
  //     > p {
  //       margin-bottom: 6px;
  //       &:last-child {
  //         margin-bottom: 0px;
  //       }
  //     }
  //   }
  // }
}
</style>
