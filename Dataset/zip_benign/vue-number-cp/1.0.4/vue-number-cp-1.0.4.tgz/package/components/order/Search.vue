<template>
  <div class="search-wrap" @mouseenter="show" @mouseleave="expression">
    <div class="search-content">
      <el-form ref="form" >
        <div class="search-name">
          <el-form-item :label="firSearch" prop="goodsName">
            <el-input v-model="goodsName" placeholder=""></el-input>
          </el-form-item>
        </div>
        <div class="search-specifications">
          <el-form-item :label="secSearch" prop="specifications">
            <el-input v-model="specifications" placeholder=""></el-input>
          </el-form-item>
        </div>
        <div class="search-state">
          <el-form-item :label="thrSearch" prop="state" v-if="options.length != 0">
            <el-select v-model="state" placeholder="" >
                <el-option :label="item.label" :value="item.value" v-for="item,index in options" :key="index"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item :label="thrSearch" prop="company" v-else>
            <el-input v-model="company" placeholder=""></el-input>
          </el-form-item>
        </div>
        <div class="search-clear">
          <span @click="reset">重置</span>
        </div>
        <div class="search-todo">
          <span @click="goResult">查询</span>
        </div>
      </el-form>
    </div>
  </div>
</template>

<script>
// import $ from 'jquery'
export default {
  props:{
      firSearch:{
        type: String
      },
      secSearch:{
        type: String
      },
      thrSearch:{
        type: String
      },
      options:{
        type: Array
      }
  },
  data () {
    return {
      goodsName:'',
      specifications:'',
      state:'00',
      company:''
    }
  },
  methods:{
    expression(){
      if( !$('.el-select-dropdown').is(":visible") ){
        $('.search-wrap').css({
          opacity: '0'
        });
      }
    },
    show(){
      $('.search-wrap').css({
        opacity: '1'
      });
    },
    goResult(){
      //console.log( $('.checkorder-search').offset().top )
      //console.log($('.'+this.position).offset().top )
      //let elTop = $('.'+this.position).offset().top
      //$('html ,body').animate({scrollTop: elTop}, 300);
      let data = {};
      data.goodsName = this.goodsName;
      data.specifications = this.specifications;
      data.state = this.state;
      data.company = this.company;
        console.log(data);
        this.$emit('getSearchOptions',data);
    },
    reset(){
      this.goodsName = '';
      this.specifications = '';
      this.state = '00';
      this.company = '';
      this.$emit('resetSearch','');
    }
  }
}
</script>

<style scoped>
.search-wrap{position: fixed;bottom: 0;left: 0;width: 100%;height: 74px;background: #72757b;opacity: 0;transition: 0.5s all;}
/* .search-wrap:hover{opacity: 1} */
.search-content{width: 1190px;height: 74px;margin: 0 auto;line-height: 74px;}
.search-name,.search-specifications,.search-state{float: left;height: 100%;line-height: 74px;width: 284px;}
.search-state{margin-left: 84px;}
.search-specifications{margin-left: 88px;width: 288px;}
.search-content /deep/ .el-form-item__label{line-height: 74px;color: white;font-size: 12px;}
.search-content /deep/ .el-form-item__content{display: inline-block;}
.search-content /deep/ .el-input__inner{width: 210px;}
.search-content .search-state /deep/ .el-input__inner{width: 235px;}
.search-clear,.search-todo{float: right;}
.search-todo{margin-right: 10px;}
.search-clear span,.search-todo span{display: inline-block;width: 59px;height: 34px;background: white;text-align: center;line-height: 34px;border: 1px solid #4f525a;cursor: pointer;}
.search-todo span{background: #ffd64e;border: none;width: 57px;height: 32px;}

</style>
