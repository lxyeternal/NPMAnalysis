<template>
    <div>
        <!-- 确认要货单 -->
        <el-dialog class="dialog" title="确认要货单" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="850px" center :close-on-click-modal="false">
            <div>
                确认您已收到采购商《{{order.contractName}}》第{{order.requireBatchNo}}批次要货通知，并巳查看要货单详情及要货数量，接下此单并确认于 <span class="red">{{order.requireTimeFrom|datetime}} ~ {{order.requireTimeTo|datetime}}</span> 能送达指定地点。
                <br>
                <span class="info">若有疑问请联系采购商沟通相关事宜。</span>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确认</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            order: {}
        };
    },
    methods: {
        open(data) {
            this.order = data;
            this.dialogVisible = true;
        },
        handleConfirm() {
            this.confirmRequire();
        },
        confirmRequire() {
            const params = {
                requireNo: this.order.requireNo
            };
            InterfaceService.requireOrderConfirm(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        this.dialogVisible = false;
                        this.$emit('close',true);
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
</style>
