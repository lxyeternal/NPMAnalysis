<template>
  <!-- 下架商品库 -->
  <div class="OffShelfWarehouse">
    <div class="inner-container">
      <PanelTitle title="下架商品库"></PanelTitle>
      <div class="batch-operation grey">
        商品模式：
        <el-radio-group v-model="tagId" @change="pageIndex = 1;getAddShelfPro()">
          <el-radio :label="''">全部</el-radio>
          <el-radio :label="'BASE_PROD'">基础商品</el-radio>
          <el-radio :label="'COM_PROD'">组价商品</el-radio>
        </el-radio-group>
      </div>
      <el-checkbox style="margin:0 0 10px 10px;" v-model="allChecked" @change="handleAllSelectTableRow" :disabled="!goodsList.length || goodsList.every(i=> i.disabled)">全选(已选{{storageGoodsList.filter(i=>{return i.checked}).length}}款)</el-checkbox>
      <div class="list-content">
        <TableThead :TopDistance="310">
          <tr slot="tr">
            <td width="34px">
              &nbsp;
            </td>
            <td width="330px">商品名称/型号</td>
            <td class="tr" width="140px">单价(不含税)(元)</td>
            <td width="95px">商品模式</td>
            <td width="480px">参数</td>
            <td width="100px" class="tr">操作</td>
          </tr>
        </TableThead>
        <table>
          <thead>
            <tr>
              <td width="34px">
                &nbsp;
              </td>
              <td width="330px">商品名称/型号</td>
              <td class="tr" width="140px">单价(不含税)(元)</td>
              <td width="95px">商品模式</td>
              <td width="480px">参数</td>
              <td width="100px" class="tr">操作</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in goodsList" :key="ind" class="tbody-row">
            <tr>
              <td>
                <el-checkbox :disabled="item.disabled" v-model="item.checked" @change="handleSelectTableRow(item,ind)"></el-checkbox>
              </td>
              <td>
                <div class="thumbnail fl" :style="{background:item.spuAttachUrl ? 'url('+item.spuAttachUrl+')' : '#eee'}"></div>
                <div class="fr" style="width: 220px;margin-left: 6px;">
                  <p :title="item.spuName" class="f12 ellipsisTwo blue-pointer" @click="handleGoproduct(item)">{{item.spuName}}</p>
                  <p style="margin-top: 10px;">型号：{{item.spuModel || '-'}}</p>
                  <p class="new-goods" v-if="item.isNewProdflag == '1' && item.tagId == 'COM_PROD'">新组价商品
                    <el-popover popper-class="dark-popover" trigger="hover" placement="right">
                      <div style="color: #fff;width: 185px;">
                        新组价商品是指，代理商创建合同时，新组的商品。
                      </div>
                      <i slot="reference"><em class="triangle-topright"></em></i>
                    </el-popover>
                  </p>
                  <p class="tag" v-if="item.isNewProdflag != '1' && item.tagId == 'COM_PROD'">组价商品</p>
                  <p class="tag bg-lightSteelBlue" v-if="item.isSurFlag == '1'">含附加项</p>
                </div>
              </td>
              <td class="tr">{{item.spuPrice | formatMoney}}</td>
              <td>{{item.spuTagModel}}</td>
              <td>
                <p v-if="item.spuParams">{{item.spuParams}}</p>
                <p v-else>规格：{{item.specifications || '-'}}</p>
              </td>
              <td>
                <p v-if="item.approveStatus === '0' && item.approveType === '3'" class="tr blue"><span class="hand" @click="handleCreateGroupGoods(item,'img')">{{item.tagId == 'BASE_PROD' ? '编辑商品':'编辑组价'}}</span></p>
                <p v-else class="tr blue"><span class="hand" @click="handleCreateGroupGoods(item)">{{item.tagId == 'BASE_PROD' ? '编辑商品':'编辑组价'}}</span></p>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="tc empty" v-if="!goodsList.length && !isLoading">
          <p class="grey">暂无可添加商品！</p>
        </div>
        <div class="table-pagination" v-if="goodsList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <FixBottom>
      <div class="fl" style="color: #fff;line-height: 36px;margin-right: 20px">
        <el-checkbox class="checkbox" v-model="allChecked" @change="handleAllSelectTableRow" :disabled="!goodsList.length || goodsList.every(i=> i.disabled)">全选(已选{{storageGoodsList.filter(i=>{return i.checked}).length}}款)</el-checkbox>
      </div>
      <div class="fr">
        <el-button style="width: 120px;" @click="handleStep">上一步</el-button>
        <el-button type="primary" style="width: 120px;" :disabled="!storageGoodsList.filter(i=>{return i.checked}).length" @click="handleAdd">添加</el-button>
      </div>
    </FixBottom>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import FixBottom from "@/components/base/FixBottom";
import PanelTitle from "@/components/base/PanelTitle";
import Loading from "@/components/base/Loading";
import { NumberUtil } from '@/utils/numberUtil';
import TableThead from "@/components/base/TableThead";

export default {
  name: "AddGoodsList",
  components: {
    FixBottom,
    PanelTitle,
    Loading,
    TableThead,
  },
  // props: ['list'],
  // watch: {
  //   list(val) {
  //     this.storageGoodsList = this.$clone(val) || []
  //     this.storageGoodsList.forEach(i => this.$set(i, 'checked', false))
  //     console.log(this.storageGoodsList)
  //     this.getAddShelfPro()
  //   }
  // },
  data() {
    return {
      isLoading: false,
      pageSize: 10,
      pageIndex: 1,
      total: 0,

      tagId: "",
      allChecked: false,
      goodsList: [],
      storageGoodsList: [],
      skuNameOrModel: "",


    }
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo
    },
  },
  methods: {
    searchName(keyword) {
      this.skuNameOrModel = keyword;
      this.pageIndex = 1;
      this.getAddShelfPro()
    },
    handleAdd(save) {
      const list = this.$clone(this.storageGoodsList)
      let upDateList = list.filter(i => i.checked && !i.disabled)
      upDateList.forEach(i => this.$delete(i, 'disabled'))
      this.$emit('upDate', upDateList)
    },
    handleGoproduct(item) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: item.spuId,
          skuId: item.skuId,
          corpId: item.corpId
        }
      }).href, '_blank')
    },
    handleCreateGroupGoods(item, type = '') {
      this.$emit('goCreate', item, 'handleCreateGroupGoods', type)
      // if (item.tagId == 'BASE_PROD') {//基础商品
      //   this.$router.push({
      //     path: "/createProductInfo",
      //     query: {
      //       pageType: '2',
      //       pageStep: this.$parent.pageStep,
      //       isEdit: '1',
      //       spuId: item.spuId,
      //       supplierId: item.corpId,
      //       applyId: this.$parent.applyId,
      //       skuId: item.skuId
      //     }
      //   })
      // } else {
      //   this.$router.push({
      //     path: "/createGroupGoods",
      //     query: {
      //       pageType: '2',
      //       pageStep: this.$parent.pageStep,
      //       isEdit: '1',
      //       spuId: item.spuId,
      //       supplierId: item.corpId,
      //       applyId: this.$parent.applyId,
      //       skuId: item.skuId
      //     }
      //   })
      // }
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      window.scrollTo(0, 0)
      this.getAddShelfPro()
    },
    //全选
    handleAllSelectTableRow(bool) {
      // this.goodsList.forEach(i => this.$set(i, 'checked', bool))
      const list = this.goodsList.filter(i => !i.disabled)
      list.forEach(i => {
        this.$set(i, 'checked', bool)
      })
      this.recordChecked()
      this.checkAllSelect()
    },
    // 选中行
    handleSelectTableRow(item, index) {
      this.$set(this.goodsList, index, item);
      this.recordChecked();
      this.checkAllSelect()
    },
    recordChecked() {
      const list = this.goodsList.filter(i => !i.disabled)
      list.forEach(item => {
        let onOff = false;
        this.storageGoodsList.forEach(_item => {
          if (item.skuId === _item.skuId) {
            onOff = true;
            _item.checked = item.checked
          }
        })
        if (!onOff) {
          this.storageGoodsList.push(item)
        }
      })
    },
    // 是否全选
    checkAllSelect() {
      const list = this.goodsList.filter(i => !i.disabled)
      this.allChecked = list.every(item => {
        return item.checked;
      });
      if (!list.length) {
        this.allChecked = false
      }
    },
    // 上一步
    handleStep() {
      this.$emit('upDateStep', '0')
    },
    // 添加上架商品查询接口
    getAddShelfPro() {
      // return
      let param = {
        supplierType: this.userInfo.supplyType,
        tagId: this.tagId,//商品模式
        pageIndex: this.pageIndex,
        skuNameOrModel: this.skuNameOrModel || '',
      }
      InterfaceService.getAddShelfPro(param, data => {
        this.isLoading = false;
        // if (data && data.respData && data.respData.respCode === "0000") {
        if (data && data.respData) {
          this.goodsList = data.respData.commodityShelfBeanList || []
          this.goodsList.forEach(i => {
            this.$set(i, 'disabled', false)
            this.$set(i, 'checked', false)
            this.storageGoodsList.forEach(item => {
              if (i.skuId === item.skuId) {
                if (item.checked) {
                  this.$set(i, 'checked', true)
                }
                if (item.disabled) {
                  this.$set(i, 'disabled', true)
                }
              }
            })
          });
          this.checkAllSelect()
          this.total = data.respData.totalCount
          this.pageSize = data.respData.pageSize
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },

    init(val) {
      this.storageGoodsList = this.$clone(val) || []
      this.storageGoodsList.forEach(i => this.$set(i, 'checked', false))
      this.storageGoodsList.forEach(i => this.$set(i, 'disabled', true))
      this.getAddShelfPro()
    }
  },
  // mounted() {
  //   this.init();
  // }
}
</script>

<style scoped lang="scss">
.inner-container {
  .box_type {
    width: 100%;
    //   height: 42px;
    background: rgba(255, 252, 240, 1);
    border: 1px solid rgba(250, 226, 165, 1);
    font-size: 12px;
    line-height: 17px;
    color: #444444;
    padding: 6px 10px;
    margin: -10px 0 10px;
  }
  .batch-operation {
    height: 50px;
    line-height: 50px;
    background: #f9f9f9;
    padding-left: 10px;
    margin-top: -10px;
    margin-bottom: 10px;
  }
  .list-content {
    width: 1190px;
    margin: 0 auto;
    table {
      table-layout: fixed;
      width: 100%;
      line-height: 17px;
      font-size: 12px;
      td {
        padding: 14px 20px;
        vertical-align: middle;
        word-break: break-all;
        position: relative;
        .thumbnail {
          width: 60px;
          height: 60px;
          background: #eee;
        }
        .goods-name {
          width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
        }
        .fixed,
        .new-goods {
          position: relative;
          overflow: hidden;
          width: 100px;
          margin-top: 6px;
          height: 20px;
          line-height: 20px;
          background: #6598d3;
          text-align: center;
          font-size: 14px;
          color: #fff;
          border-radius: 2px;
        }
        .new-goods {
          background: #ff7d1d;
          .triangle-topright {
            width: 28px;
            height: 70px;
            position: absolute;
            background: #313131;
            top: -54px;
            right: -50px;
            -webkit-transform: rotate(45deg);
            transform: rotate(45deg);
          }
        }
        i {
          position: absolute;
          right: 16px;
          top: 50%;
          margin-top: -9px;
        }
        > p {
          line-height: 17px;
          & + p {
            margin-top: 4px;
          }
        }
      }
      thead {
        font-size: 14px;
        text-align: left;
        white-space: nowrap;
        background: #f9f9f9;
        color: #888;
        border-bottom: 1px solid #eee;
      }
      .tbody-row {
        &:hover {
          background: #f0f8ff;
        }
      }
      tbody {
        text-align: left;
        tr {
          border-bottom: 1px solid #eee;
        }
        .border-none {
          border-bottom: none;
        }
      }
    }
  }
}
.empty {
  margin-top: 20px;
  margin-bottom: 400px;
  p {
    margin-bottom: 23px;
  }
}
.tag {
  width: 90px;
  height: 20px;
  background: #6598d3;
  line-height: 20px;
  font-size: 14px;
  color: #fff;
  text-align: center;
  border-radius: 2px;
}
.white {
  width: 80px;
  background: #a6b2cc;
}
</style>