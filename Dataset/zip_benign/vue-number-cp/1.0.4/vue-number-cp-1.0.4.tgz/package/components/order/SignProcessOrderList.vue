<template>
  <div class="tl process-content">
    <div>
      <div class="box">
        <div class="tl inline"><span class="yellow">{{title}}&nbsp;&nbsp;|&nbsp;&nbsp;</span>采购方
          <span v-for="(item,index) in pList" :key="index">
            <i :class="filterNameColor(item)">
              {{showTipText(item)}}
            </i>
          </span>
        </div>
        <div class="tl inline" v-if="sList.length">供应方
          <span v-for="(item,index) in sList" :key="index">
            <i :class="filterNameColor(item)">
              {{showTipText(item)}}
            </i>
          </span>
        </div>
        <div class="tl inline">材料公司
          <span v-for="(item,index) in vList" :key="index">
            <i :class="filterNameColor(item)">
              {{showTipText(item)}}
            </i>
          </span>
        </div>
      </div>

    </div>
  </div>
</template>

<script>
import { getSealRoles } from "@/utils/orderUtil";
import accountMixin from "@/mixins/account";
export default {
  mixins: [accountMixin],
  data() {
    return {
      show: false,
      title: '',
      pList: [], // 采购方
      vList: [{
        type: 0,
        processFlg: "0",
      }, {
        type: 1,
        processFlg: "0",
      }], // 供应方 - 当sList 有值时 变为 总部
      sList: [], // 供应方 -> 角色为B时 documentType为00  role为3开头
      // 审批进度
      approvalList: [], // 审批进度 list
      orderType: '',//contract: 签署合同， relieve 终止合同
    };
  },
  // type: settle - 结算单
  props: ["order", "brokerCorpId", "isSupplementary", "type"],
  watch: {
    order() {
      this.init();
    }
  },
  computed: {

  },
  methods: {
    showTipText(item) {
      if (item.type == 0) {
        return item.processFlg == 1 ? "合同已盖章" : "合同待盖章";
      }
    },
    filterIconName(item) {
      let icon = "";
      if (item.type == 0) {
        icon = item.processFlg == 1 ? "icon-seal-yes" : "icon-seal-no";
      }
      return {
        [icon]: true
      };
    },
    filterNameColor(item) {
      return item.processFlg == 1 ? "green" : "red";
    },
    filterContractType(item) {
      const seals = getSealRoles();
      if (seals.indexOf(item.role) !== -1) {
        item.type = 0;
      } else {
        item.type = 1;
      }
      return item;
    },
    closedOrder(item) {
      let str = "";
      let reason = "";
      if (item.sysCode !== "ERP") {
        const executionList = this.order && this.order.executionList || [];
        executionList.forEach(ex => {
          if (ex.procDefKey == "CONTRACT_APPROVE_WF" && ex.executionStatus === "closed") {
            reason = ex.comment || ""
          }
        });
        if (reason) {
          str = "<br/>关闭原因：<br/>" + reason.replace(/\n/g, '<br/>');
        }
      }
      return str
    },
    filterExternalSys(item) {
      let str = "";
      let reason = "";
      if (item.sysCode !== "ERP") {
        const executionList = this.order && this.order.executionList || [];
        executionList.forEach(ex => {
          if (ex.procDefKey == "CONTRACT_APPROVE_WF" && ex.executionStatus === "closed") {
            reason = ex.comment || ""
          }
        });
        if (reason) {
          str = "<br/>关闭原因：<br/>" + reason.replace(/\n/g, '<br/>');
        }
      }
      return str;
    },

    init() {
      this.show = false;
      this.pList = [];
      this.vList = [{
        type: 0,
        processFlg: "0",
      }, {
        type: 1,
        processFlg: "0",
      }];
      this.sList = [];
      let brokerList = [];
      let bAllProcessList = [];
      let sAllProcessList = [];
      let bProcessList = [];
      let processList = [];
      let sProcessList = []; // brokerCorpId有值 角色为B时 documentType为00  (role为3开头) 显示 - 总部
      this.orderType = this.order.orderStatus === '05' ? 'contract' : 'relieve'
      if (this.orderType === 'contract') {
        if (this.isSupplementary) {
          this.title = '补充合同签署进度'
        } else {
          this.title = '合同签署进度'
        }
      } else if (this.orderType === 'relieve') {
        this.title = '终止合同签署进度'
      }

      if (this.order.settleStatus == '4') {
        this.title = '结算单签署进度'
      }
      const events = this.order.eventList || [];
      // 有: 采购&总部documentType=10, 供应商00. 无: 采购&总部documentType=00
      let broker = this.order.brokerCorpId || this.brokerCorpId || "";
      if (this.isSupplementary) {
        broker = true
      }
      if (this.order && this.order.eventList) {
        if (!broker) {
          events.forEach(ev => {
            // eventType 事件类型（0:合同签署）,  documentType 文档类型
            if ((ev.eventType == 0 && (ev.documentType == "dt_10_contract_profession") || (ev.documentType == "dt_10_contract_common")) ||
              (ev.eventType == 'replenishSign' && ev.documentType == "externalReplenishAgreement")) {
              //  eventStatus 事件状态（0:初始化; 1:处理中; 2已完成）
              if (ev.eventStatus == 2) {
                this.show = false;
              } else {
                this.show = true;
                bProcessList = JSON.parse(JSON.stringify(ev.processList || []));
                ev.processList.forEach(pro => {
                  bAllProcessList.push(pro)
                })
              }
            }
          });
        } else {
          events.forEach(ev => {
            if (this.orderType === 'contract') {
              if (this.isSupplementary) {
                if (ev.eventType == 'replenishSign' && ev.documentType == "internalReplenishAgreement") {
                  bProcessList = JSON.parse(JSON.stringify(ev.processList || []));
                  ev.processList.forEach(pro => {
                    bAllProcessList.push(pro)
                  })
                }
                if (ev.eventType == 'replenishSign' && ev.documentType == "externalReplenishAgreement") {
                  sProcessList = JSON.parse(JSON.stringify(ev.processList || []));
                  ev.processList.forEach(pro => {
                    sAllProcessList.push(pro)
                  })
                }
              } else {
                if (((ev.eventType == 0 && (ev.documentType == "dt_00_contract_profession") || (ev.documentType == "dt_00_contract_common")) || (ev.eventType == 'replenishSign' && ev.documentType == "internalReplenishAgreement"))) {
                  bProcessList = JSON.parse(JSON.stringify(ev.processList || []));
                  ev.processList.forEach(pro => {
                    bAllProcessList.push(pro)
                  })
                }
                //  brokerCorpId有值 角色为B时 documentType为00  (role为3开头)
                if (((ev.eventType == 0 && (ev.documentType == "dt_10_contract_profession") || (ev.documentType == "dt_10_contract_common")) || (ev.eventType == 'replenishSign' && ev.documentType == "externalReplenishAgreement"))) {
                  sProcessList = JSON.parse(JSON.stringify(ev.processList || []));
                  ev.processList.forEach(pro => {
                    sAllProcessList.push(pro)
                  })
                }
              }
            }
            if (this.orderType === 'relieve') {
              if (ev.eventType == 'contractTerminateSign' && ev.documentType == "purchaserContractTerminate_pdf") {
                bProcessList = JSON.parse(JSON.stringify(ev.processList || []));
                ev.processList.forEach(pro => {
                  bAllProcessList.push(pro)
                })
              }
              if (ev.eventType == 'contractTerminateSign' && ev.documentType == "supplierContractTerminate_pdf") {
                sProcessList = JSON.parse(JSON.stringify(ev.processList || []));
                ev.processList.forEach(pro => {
                  sAllProcessList.push(pro)
                })
              }
            }

            // 结算单
            if (this.order.settleStatus == '4') {
              if (ev.eventType == '5' && ev.documentType == "settle_purchaser_File") {
                bProcessList = JSON.parse(JSON.stringify(ev.processList || []));
                ev.processList.forEach(pro => {
                  bAllProcessList.push(pro)
                })
              }
              if (ev.eventType == '5' && ev.documentType == "settle_supplier_File") {
                sProcessList = JSON.parse(JSON.stringify(ev.processList || []));
                ev.processList.forEach(pro => {
                  sAllProcessList.push(pro)
                })
              }
            }

            // 结算单 单独判断
            if (this.type == 'settle') {
              if (['settle_purchaser_File', 'settle_supplier_File'].includes(ev.documentType)) {
                ev.processList.forEach(pro => {
                  processList.push(pro)
                })
              }
            } else {
              ev.processList.forEach(pro => {
                processList.push(pro)
              })
            }
          });
        }
      }
      bProcessList.forEach(b => {
        b.processFlg = bAllProcessList.filter(i => { return b.role == i.role }).every(i => { return i.processFlg === '1' }) ? '1' : '0'
      });
      sProcessList.forEach(s => {
        s.processFlg = sAllProcessList.filter(i => { return s.role == i.role }).every(i => { return i.processFlg === '1' }) ? '1' : '0'
      });
      // 查找s供应商
      sProcessList.forEach(process => {
        process = this.filterContractType(process);
        // 解决 process.role[0] 报错问题
        if (!process.role) return
        // brokerCorpId有值
        if (broker) {
          if (process.role[0] == 3) {
            //s筛选供应商
            this.sList.push(process)
          }
        }
      });
      bProcessList.forEach(process => {
        process = this.filterContractType(process);
        // 解决 process.role[0] 报错问题
        if (!process.role) return
        // brokerCorpId有值
        if (broker) {
          if (process.role[0] == 2) {
            this.pList.push(process);
          }
        }
      })
      processList.forEach(process => {
        process = this.filterContractType(process);
        // 解决 process.role[0] 报错问题
        if (!process.role) return
        // brokerCorpId无值
        if (!broker) {
          // 筛选采购商
          if (process.role[0] == 4 || process.role[0] == 2) {
            this.pList.push(process);
          } else if (process.role[0] == 3) {
            // 筛选供应商
            brokerList.push(process);
          }
        } else {
          if (process.role[0] == 4) {
            // 筛选供应商
            brokerList.push(process);
          }
        }
      });
      let sealList = [];
      let personalList = [];
      brokerList.forEach(item => {
        if (item.type == 0) {
          sealList.push(item)
        }
      });
      this.vList.forEach(v => {
        try {
          if (v.type == 0) {
            v.processFlg = sealList && sealList.length && sealList.every(s => { return s.processFlg == '1' }) ? "1" : "0"
          } else if (v.type == 1) {
            v.processFlg = personalList && personalList.length && personalList.every(p => { return p.processFlg == '1' }) ? "1" : "0"
          }
        } catch (error) {
          console.log(error);
        }
      })
      this.pList.sort((a, b) => {
        return b.type - a.type;
      });
      this.vList.sort((a, b) => {
        return b.type - a.type;
      })
      // }
      this.sList.sort((a, b) => {
        return b.type - a.type;
      })
      // 角色为采购商的时候 才执行 审批进度逻辑
      this.role == "B" && this.getExternalSysListInfo()
    },
    /**
     * 审批进度设置
     */
    getExternalSysListInfo() {
      this.approvalList = []
      const externalSysList = this.order && this.order.externalSysList || [];
      const executionList = this.order && this.order.executionList || [];
      // 判断approveStatus 审批状态是否全部为1 ,  true: 不显示 审批进度, false: 显示
      const isApproval = externalSysList.every(item => item.approveStatus == '1')

      // 如果不用显示 审批进度 不执行下面逻辑
      if (isApproval) return

      externalSysList.forEach(item => {
        this.approvalList.push(item || [])
      });
      // 显示OA进度，当前的操作人
      this.approvalList.forEach(_item => {
        executionList.forEach(ex => {
          if (_item.sysCode == "OA" && ex.procDefKey == "CONTRACT_APPROVE_WF") {
            if (ex.executorRole == "1002") {
              _item.role = "招采部审批"
            } else if (ex.executorRole == "1003") {
              _item.role = "工程部审批"
            } else if (ex.executorRole == "1004") {
              _item.role = "财务部审批"
            } else if (ex.executorRole == "1001") {
              _item.role = "副总经理审批"
            }
          }
        })
      })
      console.log(this.approvalList, '-approvalList');
    }
  },
  mounted() {
    this.init();
  }
};
</script>

<style lang="scss" scoped>
.process-content {
  color: #888888;
  & > div {
    padding: 5px;
  }
}
.inline {
  display: inline-block;
  // min-width: 150px;
  margin-right: 20px;
  padding: 0 10px;
  i {
    width: 20px;
    height: 20px;
    margin-left: 5px;
    vertical-align: middle;
  }
}
.inline:first-child {
  // border-right: 2px solid #c99f4f;
  margin-right: 0px;
}
.box {
  display: flex;
  justify-content: space-between;
}
/deep/ .icon-check-yes,
.icon-check-no,
.icon-seal-yes,
.icon-seal-no,
.icon-clock-no,
.icon-clock-yes {
  margin-right: 0;
}
.orange {
  color: #ffae11;
}
</style>
