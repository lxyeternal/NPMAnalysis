<template>
    <div>
        <!-- 下载合同模板 -->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="templateDialogVisible" width="800px" center :close-on-click-modal="false">
            <PanelTitle title="合同模板" bg-color="#fff" text-align="left"></PanelTitle>
            <div class="tc">
                <div class="img-container" v-if="groupCompanyCode == 'GREENLANDHK'">
                    <img v-if="order.contractType == '1'" src="@/assets/images/productFile/downloadTempBg2.jpg">
                    <img v-else src="@/assets/images/productFile/downloadTempBg1.jpg">
                </div>
                <el-checkbox-group v-model="checkTempList">
                    <el-checkbox label="1" v-if="isMiddleman && showSupplyContract">&nbsp; {{groupCompanyCode == 'GREENLANDHK' ? '绿地香港' : ''}}货物供应合同(上海博置与项目公司)模板</el-checkbox>
                    <el-checkbox label="2">&nbsp;{{ unMiddlemanText }}</el-checkbox>
                </el-checkbox-group>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleDownloadTemp">下载</el-button>
                <el-button size="small" style="width: 100px" @click="templateDialogVisible = false" v-if="back">返回</el-button>
                <el-button size="small" style="width: 100px" @click="templateDialogVisible = false" v-else>取消</el-button>
            </div>
        </el-dialog>

        <!-- 下载合同 -->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="downDialogVisible" width="800px" center :close-on-click-modal="false">
            <div class="tl">
                <PanelTitle :tabs="tabs" @select="handleSelectTab" bg-color="#fff"></PanelTitle>
                <div class="attach-table">
                    <table>
                        <tr v-for="(row,index) in attachList" :key="index" v-if="checkContractType(row)">
                            <td width="50" v-if="!hideBtn">
                                <el-checkbox v-model="row.checked" @change="handleSelectRow(row,index)"></el-checkbox>
                            </td>
                            <td :class="{blue: hideBtn}" @click="handleSeeContract(row)">{{row.documentName}}</td>
                            <td><span v-if="groupCompanyCode==1 && contractType==1 && row.addRate">本货物供应合同加价费率为{{row.addRate * 100}}%</span></td>
                        </tr>
                    </table>
                    <el-checkbox v-if="!hideBtn" v-model="allCheck" @change="handleAllCheck"></el-checkbox>&nbsp;&nbsp;<span v-if="!hideBtn" >全选</span>
                </div>
            </div>
            <div slot="footer" class="dialog-footer"  v-if="hideBtn">
                <el-button size="small" style="width: 100px" @click="downDialogVisible = false">关闭</el-button>
            </div>
            <div slot="footer" class="dialog-footer" v-else>
                <el-button type="primary" size="small" style="width: 100px" @click="handleDownload">下载</el-button>
                <el-button size="small" style="width: 100px" @click="handleAllDownload">打包下载</el-button>
                <el-button size="small" style="width: 100px" @click="downDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
const tabs = [
    { label: "货物供应合同", type: "1", active: true },
    { label: "货物采购合同", type: "0", active: false }
];

const tabsOuter = [{ label: "货物采购合同", type: "0", active: true }];

import accountMixin from '@/mixins/account';
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import { InterfaceService } from "@/services/api";
import download from "@/utils/download";
import { viewFile } from '@/utils/orderUtil';
export default {
    mixins:[accountMixin],
    components: {
        Loading,
        PanelTitle
    },
    props:['back', 'downloadOrder'],
    computed: {
        // 是否中间商 true 是, false 否
        isMiddleman() {
            return (this.downloadOrder && this.downloadOrder.brokerCorpId && this.downloadOrder.brokerCorpId.length) || false
        },
        unMiddlemanText() {
            return this.isMiddleman ? this.groupCompanyCode == 'GREENLANDHK' ? '绿地香港货物采购合同(上海博置与供应商)模板' : '货物采购合同(上海博置与供应商)模板' :  this.groupCompanyCode == 'GREENLANDHK' ?  '绿地香港货物采购合同(城市公司与供应商)模板' : '货物采购合同(城市公司与供应商)模板'
        } ,
    },
    data() {
        return {
            isLoading: false,
            templateDialogVisible: false,
            downDialogVisible: false,
            showSupplyContract: false,
            order: {},
            tabs: JSON.parse(JSON.stringify(tabs)),
            isInner: true,
            isOuter: false,
            contractType: 0,
            allCheck: false,
            showAllContract: false,
            attachList: [],
            checkTempList: [],
            hideBtn: false // 是否隐藏按钮
        };
    },
    methods: {
        open(data, type, opt) {
            this.order = data;
            if (type === "template") {
                this.checkTempList = this.isMiddleman ? ['1', '2'] : ['2'] ;
                this.templateDialogVisible = true;
                this.showSupplyContract = this.role === "B";
            } else if (type === "download") {
                this.initDownload();
                this.downDialogVisible = true;
            }

            if (opt === 'hideBtn') {
                this.hideBtn = true
            }
        },
        handleSelectTab(tab) {
            if (this.contractType == tab.type) return;
            this.contractType = tab.type;
            this.checkAllSelect();
            if (this.showAllContract) {
                return;
            } else {
                this.showAllContract = true;
                this.getContractInfo();
            }
        },
        handleSelectRow(row, index) {
            this.$set(this.attachList, index, row);
            this.checkAllSelect();
        },

        /**
         * 查看合同
         */
        handleSeeContract(item) {
            if (!this.hideBtn) return;
            if (item.attachUrl) {
              viewFile(item.attachUrl)
            }

        },
        // 是否全选
        checkAllSelect() {
            let num = 0;
            this.allCheck = this.attachList.every(item => {
                const bool = this.checkContractType(item);
                if (bool) {
                    num++;
                }
                return !bool || item.checked;
            });

            this.allCheck = num > 0 && this.allCheck;
        },
        handleAllCheck() {
            this.attachList.forEach((item, index) => {
                const bool = this.checkContractType(item);
                if (bool) {
                    item.checked = this.allCheck;
                }

                this.$set(this.attachList, index, item);
            });
        },
        handleDownloadTemp() {
            // 只选择一份合同模板时下载选择的合同模板
            if (this.checkTempList.length) {
                console.log(this.checkTempList);
                this.downloadTemp(this.checkTempList[0], this.checkTempList[1]);
                this.templateDialogVisible = false;
                this.$message.success("已下载");
            } else {
                this.$message.info("请选择下载模板");
            }
        },
        handleAllDownload(){
            let params = {};
            let documentType = "";
            this.role == "B" ? documentType = "2" : documentType = "0";
            params = {
                orderNo : this.order.orderNo,
                documentType: documentType
            };
            InterfaceService.contractPackingDownload(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        let packingUrl = "";
                        packingUrl = data.respData.externalFileUrl;
                        if (packingUrl == null){
                            this.$message.error("暂无打包内容")
                            return
                        }
                        this.packingDownload(this.order.contractName,packingUrl)
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        packingDownload(name,packingUrl){
            const x = new XMLHttpRequest();
            x.open("GET",packingUrl, true);
            x.responseType = "blob";
            x.onload = e => {
                download(
                    x.response,
                    name+".zip",
                    x.response.type
                );
            };
            x.send();
            this.downDialogVisible = false;
            this.$message.success("已下载");
        },
        handleDownload() {
            const attachs = [];
            this.attachList.forEach((item, index) => {
                const bool = this.checkContractType(item);
                if (bool && item.checked) {
                    attachs.push(item);
                }
                item.url = item.attachUrl;
                item.name = item.documentName.split("?")[0]
            });
            if (attachs.length) {
                this.$download(attachs).then(res=>{
                    this.downDialogVisible = false;
                    this.$message.success("已下载");
                })
            } else {
                this.$message.info("请选择需要下载的文件");
            }
        },
        checkContractType(row) {
            let bool = false;
            let relievePdf = false;
            this.attachList.forEach(item=>{
                if (item.documentType ===  "purchaserContractTerminate_pdf" || item.documentType === "supplierContractTerminate_pdf" ){
                    relievePdf = true
                }
            });
            if (relievePdf) {
                // 内部合同
                if (
                    this.contractType == 1 &&
                    ((row.bs === "B" || row.bs === "BS") && row.documentType !== "purchaserContractTerminate")
                ) {
                    bool = true;
                } else if (
                    // 外部合同
                    this.contractType == 0 &&
                    ((row.bs === "S" || row.bs === "BS") && row.documentType !== "supplierContractTerminate")
                    // (row.documentType === "00" || row.documentType === "04" || row.documentType === "06"  || row.documentType === "supplierContractTerminate_pdf")
                ) {
                    bool = true;
                }
            }else {
                if (
                    this.contractType == 1 &&
                    (row.bs === "B" || row.bs === "BS")
                ) {
                    bool = true;
                } else if (
                    // 外部合同
                    this.contractType == 0 &&
                    (row.bs === "S" || row.bs === "BS")
                ) {
                    bool = true;
                }
            }
            return bool;
        },
        getContractInfo() {
            const params = {
                // contractNo: this.order.contractNo,
                orderNo: this.order.orderNo,
                bs: this.contractType == "0" ? "S" : "B"
            };
            InterfaceService.getContractInfo(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        let list =  data.respData.documentInfos || [];
                        list.forEach(item=>{
                            let onOff = false;
                            this.attachList.forEach(_item=>{
                                if (_item.documentId == item.documentId) {
                                    onOff = true
                                }
                            });
                            if (!onOff) {
                                this.attachList.push(item)
                            }
                        });
                        // this.attachList = this.attachList.concat(
                        //     data.respData.documentInfos || []
                        // );
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        downloadTemp(type,num) {
            // const params = {
            //     contractNo: this.order.contractNo,
            //     contractType: type
            // };
            let params = {};
            if (this.role === "B") {
                params = {
                    orderNo: this.order.orderNo,
                    bs: type == "1" ? "B" : "S"
                };
            }else if (this.role === "S") {
                params = {
                    orderNo: this.order.orderNo,
                    bs: "S"
                };
            }
            console.log(params);
            InterfaceService.orderCotractDownload(
                params,
                data => {
                    //在返回成功的情况下再去下载第二份合同模板
                    if (num == "2" && this.role === "B") {
                        this.downloadTemp("S")
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        initDownload() {
            this.allCheck = false;
            this.showAllContract = false;
            if (this.role == "B") {
                this.contractType = 1;
                this.tabs = this.isMiddleman ? this.$clone(tabs) : this.$clone(tabsOuter)
                this.contractType = this.tabs[0].type;
            } else if (this.role == "S") {
                this.contractType = 0;
                this.tabs = this.$clone(tabsOuter);
                this.showAllContract = true;
            }
            this.attachList = [];

            this.getContractInfo();
        }
    }
};
</script>

<style lang="scss" scoped>
.img-container {
    border-bottom: 1px solid #eaeaea;
    margin-bottom: 15px;
    img {
        width: 100%;
    }
}
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;

    /deep/ .el-dialog__header {
        padding: 0;

        &:before {
            display: none;
        }
    }
}

.attach-table {
    padding: 0 20px;

    table {
        width: 100%;
        margin-bottom: 20px;
        border-bottom: 1px solid #eeee;
        .blue {
            color: #58bcff;
            cursor: pointer;
        }
    }
}
</style>
