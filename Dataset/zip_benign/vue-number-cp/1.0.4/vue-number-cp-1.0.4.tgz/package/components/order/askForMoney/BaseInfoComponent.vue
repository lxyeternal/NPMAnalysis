<template>
  <div class="component-container">
    <ul v-if="isDialog">
      <li>请款合同：《{{baseInfo.contractName}}》</li>
      <li>请款事由：<span class="red">{{baseInfo.askForReasonsValue}}</span></li>
      <li>采购商：{{baseInfo.purchaserName}}</li>
    </ul>
    <template v-else>
      <el-row :gutter="10">
        <el-col class="lh20 title" :span="1.5">合同编号：</el-col>
        <el-col class="lh20" :span="5">{{baseInfo.orderNo}}</el-col>
        <el-col class="lh20 title" :span="1.5">请款编号：</el-col>
        <el-col class="lh20" :span="5">{{baseInfo.paymentNo}}</el-col>
        <el-col class="lh20 title" :span="1.5">合同名称：</el-col>
        <el-col :span="9" class="lh20"><span>《{{baseInfo.contractName}}》</span><span  v-if="!(baseInfo.other && baseInfo.other.myTaskId === 'supervisory_confirm') && !notViewContractDetails" class="blue" @click="handleOrderDetail(baseInfo)">查看合同详情</span></el-col>
      </el-row>
      <el-row :gutter="10">
        <el-col class="title" :span="1.5">付款事由：</el-col>
        <el-col :span="5">{{baseInfo.askForReasonsValue}}</el-col>
        <el-col class="title" :span="1.5">&emsp;采购商：</el-col>
        <el-col :span="5">{{baseInfo.purchaserName}}</el-col>
        <el-col class="title" :span="1.5" v-if="baseInfo.datePickerValueStart">请款周期：</el-col>
        <el-col :span='4' v-if="baseInfo.datePickerValueStart">{{`${baseInfo.datePickerValueStart} ~ ${baseInfo.datePickerValueEnd}`}}</el-col>
      </el-row>
    </template>
  </div>
</template>
<script>
import accountMixin from "@/mixins/account"
export default {
  props: ['baseInfo', 'isDialog', 'cycleTime'],
  mixins: [accountMixin],
  mounted(){
  },
  methods: {
    /**
     * 查看合同详情
     */
    handleOrderDetail(order) {
      // 取消增补 功能需要
      window.open(this.$router.resolve({
        path: "/orderDetail",
        query: {
          orderNo: order.orderNo,
        }
      }).href, '_blank')
    },
  }
}
</script>
<style lang="scss" scoped>
.component-container {
  margin: 12px 0;
  .lh20 {
    line-height: 20px;
  }
  & > ul {
    li {
      margin-top: 8px;
    }
  }
  .el-row {
    margin-top: 12px;
  }
  .title {
    color: #888;
    &.black {
      color: #000;
    }
  }
  .blue {
    cursor: pointer;
  }
  &.row-flex-item-align-center {
    .el-row {
      display: flex;
      align-items: center;
      flex-wrap: wrap;
      [class*="el-col-"] {
        margin-top: 8px;
      }
      /deep/ .el-icon-percentage {
        &::before {
          content: "%";
          color: #000;
        }
      }
      /deep/ .el-icon-yuan {
        &::before {
          content: "元";
          color: #000;
        }
      }
    }
  }
  .account-tips {
    text-align: center;
    p {
      text-align: left;
      margin-bottom: 20px;
    }
  }
  .account-center {
    .account-specific-information {
      margin-top: 22px;
      border-top: 1px dashed #ccc;
      [class*="el-col-"] {
        margin-top: 12px;
      }
    }
  }
}
</style>
