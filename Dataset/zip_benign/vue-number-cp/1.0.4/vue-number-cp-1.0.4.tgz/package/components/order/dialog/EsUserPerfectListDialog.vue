<template>
  <transition name="el-zoom-in-bottom">
    <el-dialog class="dialog EsUserPerfectListDialog" title="完善信息" :append-to-body="true" :lock-scroll="true" :visible.sync="msgDialogVisible" width="840px" center :close-on-click-modal="false" @close="close">
      <div style="margin-bottom: 10px;">欢迎入驻大家采平台，请按照以下指引去完善您的公司信息，谢谢！</div>
      <div class="contract-list">
        <p>
          1.银行信息 &gt;&gt;
          <span v-if="vendorMessageInfo.corpBankIsComplete == 1">已完成<i class="el-icon-check"></i></span>
          <span v-else class="blue-pointer" @click="handleGo('/vendorCenter/enterpriseCertification')">去完善<i class="el-icon-edit red"></i></span>
        </p>

        <p>
          2.创建印章 &gt;&gt;
          <span v-if="isCorpSign">已完成<i class="el-icon-check"></i></span>
          <span v-else class="blue-pointer" @click="handleGo('/vendorCenter/sealList','addr')">去完善<i class="el-icon-edit red"></i></span>
        </p>
        <p>

          <p>
            3.企业地址 &gt;&gt;
            <span v-if="vendorMessageInfo.corpAddrIsComplete == 1">已完成<i class="el-icon-check"></i></span>
            <span v-else class="blue-pointer" @click="handleGo('/vendorCenter/companyMessage','addr')">去完善<i class="el-icon-edit red"></i></span>
          </p>
          <p>
            4.开票信息 &gt;&gt;
            <span v-if="vendorMessageInfo && vendorMessageInfo.acCorpFinInfoBean && vendorMessageInfo.acCorpFinInfoBean.invoiceType">已完成<i class="el-icon-check"></i></span>
            <span v-else class="blue-pointer" @click="handleGo('/vendorCenter/billingInformationEditing','fin')">去完善<i class="el-icon-edit red"></i></span>
          </p>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" @click="close">知道了</el-button>
      </div>
    </el-dialog>

    <Loading :is-loading="isLoading"></Loading>
    </div>
  </transition>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
export default {
  props: [],
  data() {
    return {
      isLoading: false,
      msgDialogVisible: false,
      sessionShowEsUserPerfectListDialog: "0",
      vendorMessageInfo: {},
      isCorpSign: false, // 是否需要完善印章
    }
  },
  components: {
    Loading
  },
  methods: {
    handleGo(path, type) {
      let query = {};
      if (type == 'addr') {
        query = {
          type: 'addr'
        }
      } else if (type == 'fin') {
        query = {
          resultPath: '/vendorCenter/companyMessage'
        }
      }
      const routeData = this.$router.resolve({
        path: path,
        query: query
      });
      window.open(routeData.href, "_blank");
    },
    close() {
      this.msgDialogVisible = false;
      this.$setRootScope('sessionShowEsUserPerfectListDialog', '0')
    },
    async open() {
      this.sessionShowEsUserPerfectListDialog = this.$getRootScope('sessionShowEsUserPerfectListDialog') || '0';
      if (this.sessionShowEsUserPerfectListDialog == '0') return
      const result = await this.getSealList()
      this.getVendorMessage(result)
    },

    /**
    * 获取印章列表参数
    */
    getSealList() {
      return new Promise(resolve => {
        let params = {
          sealDataType: 3
        };
        InterfaceService.getSealList(params, data => {
          if (data.respCode === '0000') {
            if (data.respData.respCode == '0000') {
              let result = data.respData.sealDataList || [];
              resolve(result)
            } else {
              this.$message.error(data.respData.respMsg);
              resolve(false)
            }
          } else {
            this.$message.error(data.respMsg);
            resolve(false)
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },

    getVendorMessage(result) {
      let param = {
        pageIndex: 1,
      };
      InterfaceService.getVendorMessage(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          // 1."银行信息" => 040002接口的 corpBankIsComplete 字段
          // 2."创建印章" => 040033接口 sealDataList 对象中存在" sealKind=corp "的记录
          // 3."企业地址" => 040002接口的 corpAddrIsComplete 字段
          // 4."开票信息"=> 040002接口 acCorpFinInfoBean 对象的 invoiceType 字段
          let res = data.respData || {}
          this.vendorMessageInfo = res

          // 公司印章
          this.isCorpSign = result && result.some(s => s.sealKind === 'corp')
          if (res.corpAddrIsComplete === '1' && res.corpBankIsComplete === '1' && res.acCorpFinInfoBean && res.acCorpFinInfoBean.invoiceType && this.isCorpSign) {
            this.msgDialogVisible = false;
          } else {
            this.msgDialogVisible = true;
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  },

  mounted() {
    this.open()
  }
}
</script>
<style lang="scss" scoped>
.EsUserPerfectListDialog {
  .contract-list {
    p {
      margin-top: 8px;
    }
  }
}
.box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .addMockList {
    max-height: 80%;
    overflow: auto;
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    .content {
      width: 1190px;
      margin: 0 auto;
      font-size: 14px;
      line-height: 17px;
      .title {
        padding: 20px 0;
        border-bottom: 1px solid #eee;
        margin-bottom: 20px;
      }

      table,
      thead,
      tbody {
        display: block;
      }

      thead,
      tbody tr {
        display: table;
        width: 100%;
        table-layout: fixed;
      }
      table {
        margin-top: 2px;
        table-layout: fixed;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        td {
          padding: 14px 10px;
          vertical-align: middle;
          word-break: break-all;
          &:last-child {
            text-align: right;
          }
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          border-bottom: 1px solid #eee;
          background: rgba(249, 249, 249, 1);
          color: rgba(136, 136, 136, 1);
          tr {
            td {
              padding: 15px 10px;
              &:last-child {
                text-align: right;
              }
            }
          }
        }
        .tbody-row {
          &:hover {
            background: #f0f8ff;
          }
        }
        tbody {
          text-align: left;
          &.tbody-active {
            height: 40vh;
            overflow-y: auto;
          }
          tr {
            border-bottom: 1px solid #eee;
            td {
              .name {
                display: flex;
                > p {
                  max-width: 750px;
                  line-height: 20px;
                  margin-right: 5px;
                }
              }
              .tag {
                width: 70px;
                height: 20px;
                background: #8b95ac;
                line-height: 20px;
                font-size: 14px;
                color: #fff;
                text-align: center;
                border-radius: 2px;
                display: inline-block;
              }
            }
          }
          .border-none {
            border-bottom: none;
          }
        }
      }
    }
    .foot {
      width: 100%;
      margin-top: 40px;
      height: 57px;
      background: rgba(49, 49, 49, 0.9);
      line-height: 57px;
      text-align: center;
      .el-button {
        width: 120px;
        height: 34px;
        line-height: 34px;
        padding: 0;
        font-size: 12px;
      }
      .el-button--primary {
        color: #fff;
        border: none;
        background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
      }
    }
  }
}
.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
.accout-empty {
  padding: 15vh;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
.product-table {
  overflow-y: auto;
}
.el-icon-check {
  color: #1cb963;
}
.dialog {
  line-height: 17px;
}
</style>