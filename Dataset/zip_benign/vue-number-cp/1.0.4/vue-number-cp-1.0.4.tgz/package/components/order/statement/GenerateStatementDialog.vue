<template>
    <div>
        <!-- 生成对账单 -->
        <el-dialog class="dialog" title="生成对账单" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="700px" center :close-on-click-modal="false">
            <div>
                <el-form ref="form" :model="form" :rules="rules" label-width="120px">
                    <el-form-item label="合同名称" prop="orderNo">
                        <el-select v-model="form.orderNo" placeholder="请选择合同名称" clearable style="width: 97%;">
                            <el-option v-for="order in orderList" :key="order.orderNo" :label="order.contractName" :value="order.orderNo"></el-option>
                        </el-select>
                    </el-form-item>
                    <el-row>
                        <el-col :span="11">
                            <el-form-item label="开始时间" prop="startDt">
                                <el-date-picker type="date" placeholder="请选择开始日期" value-format="yyyy-MM-dd" v-model="form.startDt" @change="handleChangeStartDt"></el-date-picker>
                            </el-form-item>
                        </el-col>
                        <el-col :span="11">
                            <el-form-item label="结束时间" prop="endDt">
                                <el-date-picker type="date" placeholder="请选择结束日期" value-format="yyyy-MM-dd" v-model="form.endDt" :picker-options="dateOption"></el-date-picker>
                            </el-form-item>
                        </el-col>
                    </el-row>

                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleGen">生成</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

const form = {
    orderNo: "",
    startDt: "",
    endDt: ""
};
export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            dateOption: {},
            orderList: [],
            form: Object.assign({}, form),
            rules: {
                orderNo: [
                    { required: true, message: "请选择合同", trigger: "change" }
                ],
                startDt: [
                    {
                        required: true,
                        message: "请选择开始时间",
                        trigger: "change"
                    }
                ],
                endDt: [
                    {
                        required: true,
                        message: "请选择结束时间",
                        trigger: "change"
                    }
                ]
            }
        };
    },
    methods: {
        open() {
            this.init();
            this.dialogVisible = true;
            this.$nextTick(() => {
                this.$refs["form"].resetFields();
            });
        },
        handleChangeStartDt(val) {
            this.dateOption = {
                disabledDate: now => {
                    return now.getTime() < +new Date(val.replace(/-/g, "/"));
                }
            };
        },
        handleGen() {
            this.$refs["form"].validate(valid => {
                if (valid) {
                    this.genStatement();
                }
            });
        },
        getOrderList() {
            const params = {
                orderStatus: ["11"],
                sort: "0_0_0",
                // enterFrom: 1
                // searchType: "0"
            };
            InterfaceService.getOrderList(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.orderList = data.respData.orders || [];
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        // 生成对账单
        genStatement() {
            const params = {
                startDt: this.form.startDt,
                endDt: this.form.endDt,
                // orderNos: [this.form.orderNo]
            };
            InterfaceService.generateStatement(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.$message.success("对账单生成成功");
                        this.dialogVisible = false;
                        this.$emit("close", true);
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        init() {
            this.form = Object.assign({}, form);
            this.getOrderList();
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;
}
</style>
