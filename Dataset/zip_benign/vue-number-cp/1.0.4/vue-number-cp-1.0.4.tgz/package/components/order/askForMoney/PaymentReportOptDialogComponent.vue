<template>
  <div class="component-container">
    <el-dialog class="dialog" :title="title" :append-to-body="true" :lock-scroll="true" :before-close="handleDialogCancel" :visible.sync="visible" width="900px" center :close-on-click-modal="false">
      <div class="confirm-payment-container">
        <!-- 非供应商确认 -->
        <div class="center" v-if="!isSupplierConfirm">
          <el-row :gutter="10">

            <!-- 鉴证 -->
            <template v-if="order.other && ['supervisory_confirm', 'engineer_pm_confirm'].includes(order.other.myTaskId)">
              <el-col :span="24">
                <span>
                  <i class="red">*</i>
                  鉴证意见
                </span>
                <el-input type="textarea" v-model="paymentCheckInfo.description" :rows="4" placeholder="请输入..." maxlength="200" show-word-limit />
              </el-col>
              <el-col :span="24" v-if="isProfessionalSubcontracting && order.paymentType === 'progress'" class="unFlex">
                <div class="flex">
                  <span>
                    <i class="red">*</i>
                    工程进度
                  </span>
                  <el-input type="textarea" v-model="outputValueCheckInfo.description" :rows="4" placeholder="请审核实际签认合同进度及工程量..." maxlength="200" show-word-limit />
                </div>
                <p class="red pNotice" v-if="order.other && ['supervisory_confirm'].includes(order.other.myTaskId)">※注意：明确审核后的进度及工作量。工程监理盖章。</p>
              </el-col>
            </template>

            <!-- 审核 输入框模式-->
            <template v-if="order.other && ['contract_op_confirm'].includes(order.other.myTaskId)">

              <!-- 合同预付款 -->
              <template v-if="order.paymentType === 'advance'">
                <el-col :span="24">
                  <ul class="input-row">
                    <li>
                      <!--<span class="title">
                        <i class="red">*</i>
                        预付比例
                      </span>
                      <div class="ipt-container" suffix-icon="el-icon-percentage">
                        <input size="small" v-input-custom-reg="{reg:'^[1-9]\\d?(\\.\\d{0,2})?$|^100$|^\\s*$'}" placeholder="请输入预付比例" v-model="paymentCheckInfo.advancePercent" />
                      </div> -->

                      预付比例 <span class="red">{{advancePercentComputed}}%</span>，
                      预付金额 <span class="red">{{order.advanceInfo && order.advanceInfo.advanceAmt | formatMoney}}</span>元。
                    </li>
                    <li>
                      <!--  <span class="title">
                     <i class="red">*</i>
                        预付金额
                      </span>
                      <div class="ipt-container" suffix-icon="el-icon-yuan">
                        <input size="small" :disabled="true" placeholder="系统根据输入比例自动算出预付金额" :value="prepaymentAmountValue" />
                      </div> -->
                    </li>
                  </ul>
                </el-col>
              </template>

              <!-- 材料进场预付款 -->
              <template v-if="order.paymentType === 'preProgress'">
                <el-col :span="24">
                  <ul class="input-row">
                    <li style="width: 100%">
                      <span class="title">
                        <!-- <i class="red">*</i> -->
                        预付金额
                      </span>
                      <!-- <div class="ipt-container" suffix-icon="el-icon-yuan">
                        <input size="small" v-input-custom-reg="{reg:'^\\d{1,9}(\\.\\d{0,2})?$|^\\s*$'}" placeholder="请输入预付金额" v-model="paymentCheckInfo.payablesAmt" />
                      </div> -->

                      <span class="red">{{order.preProgressInfo && order.preProgressInfo.preProgressAmt | formatMoney}}</span>元。
                    </li>
                  </ul>
                </el-col>
              </template>

              <!-- 进度款 -->
              <template v-if="order.paymentType === 'progress'">
                <el-col :span="24" class="column">
                  <ul class="input-row">
                    <li>
                      <span class="title"><i class="red">*</i>本期核定产值</span>
                      <div class="ipt-container" suffix-icon="el-icon-yuan">
                        <input size="small" v-input-custom-reg="{reg:'^[-]?(\\d{1,9}(\\.\\d{0,2})?)?$|^\\s*$'}" placeholder="请输入本期核定产值" v-model="paymentCheckInfo.outputValueCheck" /> </div>
                    </li>
                    <li>
                      <span class="title"><i class="red">*</i>累计核定产值</span>
                      <div class="ipt-container" suffix-icon="el-icon-yuan">
                        <input size="small" v-input-custom-reg="{reg:'^[-]?(\\d{1,9}(\\.\\d{0,2})?)?$|^\\s*$'}" placeholder="请输入累计核定产值" v-model="paymentCheckInfo.totalOutputValueCheck" /> </div>
                    </li>
                  </ul>
                  <p class="ipt-notice">根据合同约定，现已达成节点。</p>
                  <ul class="input-row">
                    <li>
                      <span class="title"><i class="red">*</i>累计应付金额</span>
                      <div class="ipt-container" suffix-icon="el-icon-yuan">
                        <input size="small" v-input-custom-reg="{reg:'^[-]?(\\d{1,9}(\\.\\d{0,2})?)?$|^\\s*$'}" placeholder="请输入累计应付金额" v-model="paymentCheckInfo.totalPayablesAmt" /> </div>
                    </li>
                    <li>
                      <span class="title"><i class="red">*</i>累计已付金额</span>
                      <div class="ipt-container" suffix-icon="el-icon-yuan">
                        <input size="small" v-input-custom-reg="{reg:'^[-]?(\\d{1,9}(\\.\\d{0,2})?)?$|^\\s*$'}" placeholder="请输入累计已付金额" v-model="paymentCheckInfo.totalPaidAmt" /> </div>
                    </li>
                  </ul>
                  <ul class="input-row">
                    <li>
                      <span class="title">扣款金额</span>
                      <div class="ipt-container" suffix-icon="el-icon-yuan">
                        <input size="small" v-input-custom-reg="{reg:'^[-]?(\\d{1,9}(\\.\\d{0,2})?)?$|^\\s*$'}" placeholder="请输入扣款金额" v-model="paymentCheckInfo.chargeBackAmt" /> </div>
                    </li>
                    <li>
                      <span class="title"><i class="red">*</i>本次申请金额</span>
                      <div class="ipt-container" suffix-icon="el-icon-yuan">
                        <input size="small" v-input-custom-reg="{reg:'^[-]?(\\d{1,9}(\\.\\d{0,2})?)?$|^\\s*$'}" placeholder="请输入本次申请金额" v-model="paymentCheckInfo.payablesAmt" /> </div>
                    </li>
                  </ul>
                </el-col>
              </template>
            </template>

            <!-- 审核 - 成本总监 -->
            <template v-if="order.other && ['contract_director_confirm'].includes(order.other.myTaskId)">
              <el-col v-if="['advance', 'preProgress'].includes(order.other.paymentType)">
                <p>
                  <template v-if="['advance'].includes(order.other.paymentType)">预付比例 <span class="red">{{numberUtilComputed('accMul', paymentCheckerItemComputed('advancePercent'), 100)}}%</span>，</template>
                  预付金额 <span class="red">{{paymentCheckerItemComputed('payablesAmt') | formatMoney}}</span>元。
                </p>
              </el-col>
              <el-col :span="24" v-else class="column">
                <p class="contract-director-confirm-p">
                  本期核定产值 <span class="red">{{paymentCheckerItemComputed('outputValue') | formatMoney}}</span>元，
                  累计核定产值 <span class="red">{{paymentCheckerItemComputed('totalOutputValue') | formatMoney}}</span>元，
                  根据合同约定，
                  现已达到节点，
                  累计应付金额 <span class="red">{{paymentCheckerItemComputed('totalPayablesAmt') | formatMoney}}</span>元，
                  累计已付金额 <span class="red">{{paymentCheckerItemComputed('totalPaidAmt') | formatMoney}}</span>元，
                  扣款金额 <span class="red">{{paymentCheckerItemComputed('chargeBackAmt') | formatMoney}}</span>元，
                  <b> 本次申请金额 <span class="red">{{paymentCheckerItemComputed('payablesAmt') | formatMoney}}</span>元。</b>
                </p>
                <template v-if="['01', '03'].includes(this.order.orderCateCode)">
                  <div class="contract-director-confirm-div-first">
                    <span class="wAuto">业主合约部产值审核意见：</span>
                    <span>{{paymentCheckerItemComputed('description')}}</span>
                  </div>
                  <div class="contract-director-confirm-div-last">
                    <p v-for="(item, idx) in receiptsListComputed" :key="idx">{{item.receiptFileName || ''}}<span class="blue hand" @click="handlePreview(item)">预览</span><span class="blue hand" @click="handleDownload(item)">下载</span></p>
                  </div>
                </template>
              </el-col>
            </template>

            <!-- 进度款 - 专业分包 -->
            <!--finance_director_confirm  审核 - 合约经办人 财务经理/财务总监  -->
            <el-col :span="24" class="column" :class="{'border-top-dashed': !(order.other && ['finance_director_confirm', 'general_manager_confirm'].includes(order.other.myTaskId)) && isProfessionalSubcontracting && isFileRequire}" v-if="isShowReviewOpinion">
              <!-- 财务经理/财务总监 时 不显示 标题 -->
              <div class="head-title" v-if="isFileRequire"><i class="red">*</i>业主合约部产值审核意见</div>
              <el-col :span="24" :class="['mt0']">
                <span>
                  <!-- 如果 合约经办人审核 判断是否为专业分包 是才显示 -->
                  <!--  v-if="['contract_op_confirm'].includes(order.other.myTaskId) ? isProfessionalSubcontracting : true" -->
                  <i class="red" v-if="!['contract_op_confirm', 'contract_director_confirm'].includes(order.other.myTaskId)">*</i>
                  审核意见
                </span>
                <el-input type="textarea" v-model="paymentCheckInfo.description" :rows="4" placeholder="请输入..." maxlength="200" show-word-limit />
              </el-col>
              <p class="audit-opinion-notice red" v-if="!['finance_director_confirm', 'general_manager_confirm'].includes(order.other.myTaskId) && isProfessionalSubcontracting">※注意：明确审核后产值。</p>
            </el-col>

            <!-- 附件 -->
            <el-col :span="24" class="border-top-dashed column">
              <div class="head-title" v-if="isFileRequire">上传《第三方咨询单位付款估值建议》</div>
              <div class="file-center">
                <span>
                  <i class="red" v-if="isFileRequire">*</i>
                  上传附件
                </span>
                <div class="upfile-div" :class="{isFileRequire: isFileRequire}">
                  <label>
                    <p>
                      <span v-if="!upfileNames.length" class="notice">上传《第三方咨询单位付款估值建议》</span>
                      <span v-else :title="upfileNames">{{upfileNames}}</span>
                    </p>
                    <UpfileComponent ref="upfileRef" multiple :btnName="'上传'" :immediateClearList="true" :immediateSubmit="true" :showMsg="false" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :dirName="dirNameComputed" :type="'12'" :id="'id'" @outputList="outputUpfileList($event)" />
                  </label>
                </div>
              </div>
            </el-col>
            <el-col :span="24" class="unFlex" v-if="upfileList && upfileList.length">
              <ul class="upfile-table head">
                <li>已上传的附件</li>
                <li>上传时间</li>
                <li class="txt-right">操作</li>
              </ul>
              <div class="upfile-table-body">
                <ul class="upfile-table" v-for="(item, idx) in upfileList" :key="idx">
                  <li>{{item.receiptFileName}}</li>
                  <li>{{item.creTm}}</li>
                  <li class="txt-right">
                    <template v-if="item.attachUrl">
                      <span class="blue hand" @click="handlePreview(item)">预览</span>
                      <span class="blue hand" @click="handleDownload(item)">下载</span>
                    </template>
                    <span class="blue hand" @click="handleDelUpfileClick(idx, item)">删除</span>
                  </li>
                </ul>
              </div>
            </el-col>
            <el-col :span="24" class="gray">
              <label>
                <el-checkbox v-model="responsibilityChecked"></el-checkbox>
                <b>勾选后，视作您已同意并授权平台电子签章，待请款签证审核流程全部结束后，平台统一电子签章。</b>
              </label>
            </el-col>
          </el-row>
        </div>
        <!-- 供应商确认 -->
        <div class="center" v-else>
          <p v-if="!this.order.close">请确认请款信息无误，点击【确认】后，将进入下个流程。</p>
          <div v-else>
            <el-row>
              <el-col :span="24" class="column">
                <el-col :span="24" :class="['mt0']">
                  <span>
                    <i class="red">*</i>
                    关闭意见
                  </span>
                  <el-input type="textarea" v-model="paymentCheckInfo.description" :rows="4" placeholder="请输入..." maxlength="200" show-word-limit />
                </el-col>
              </el-col>
            </el-row>
          </div>
        </div>
        <div class="btn-center">
          <el-button size="small" type="primary" style="width: 120px" :disabled="!responsibilityChecked && !isSupplierConfirm" @click="handleDialogConfirm">确认{{isSupplierConfirm?'':'并提交'}}</el-button>
          <el-button size="small" style="width: 120px" @click="handleDialogCancel">取消</el-button>
        </div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>

import Loading from "@/components/base/Loading";
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import { InterfaceService } from "@/services/api";
import { NumberUtil } from '@/utils/numberUtil'
export default {
  components: {
    UpfileComponent, // 上传
    Loading
  },
  props: ['visible', 'order'],
  data() {
    return {
      assuranceOpinion: '',
      title: '',
      responsibilityChecked: false, // 是否勾选
      upfileList: [], // 上传文件 list
      upfileListDel: [], // 删除 的 退回 附件
      isLoading: false,
      professionalSubcontracting: '', // 工程进度

      paymentCheckInfo: {  //Object	请款报告核定结果
        outputValueCheck: '', //String	本期核定产值
        totalOutputValueCheck: '', //String	累计核定产值
        totalPayablesAmt: '', //String	累计应付金额
        totalPaidAmt: '', //String	累计已付金额
        chargeBackAmt: '', //String	扣款金额（非必填）
        payablesAmt: '', //String	本次请款金额 (预付金额)
        advancePercent: '', // 预付比例
        description: '', //String	审核意见
      },
      outputValueCheckInfo: {	//Object	产值报表核定结果 桂城街道
        description: ''	//String	审核意见
      },
    }
  },
  computed: {
    // 精确计算
    numberUtilComputed() {
      return (key, val1, val2) => {
        return NumberUtil[key](val1, val2)
      }
    },
    // 是否显示审核意见
    isShowReviewOpinion() {
      return (this.order.other && ['finance_director_confirm', 'contract_director_confirm', 'general_manager_confirm', 'contract_op_confirm'].includes(this.order.other.myTaskId))
    },
    // 预付比例
    advancePercentComputed() {
      return NumberUtil.accMul(this.order.advanceInfo && this.order.advanceInfo.advancePercent, 100) || 0
    },

    // 业主合约部产值审核意见 附件
    receiptsListComputed() {
      return this.order && this.order.receiptsList && this.order.receiptsList.filter(f => f.receiptType === 'assessment_Recommendations') || []
    },

    // 供应商确认
    isSupplierConfirm() {
      return this.order.other && ['supplier_confirm'].includes(this.order.other.myTaskId) || this.order.close
    },
    // 核定金额并审核
    paymentCheckerItemComputed() {
      return key => {
        return this.order && this.order.other && this.order.other.paymentCheckerItem && this.order.other.paymentCheckerItem[key] || ''
      }
    },

    // 第三方 附件 是否 必须上传
    isFileRequire() {
      // 进度款 且 是 专业分包 且 合约经办人 显示 必传
      return this.order && this.order.paymentType === 'progress' && ['01', '03'].includes(this.order.orderCateCode) && ['contract_op_confirm'].includes(this.order.other.myTaskId)
    },
    // 预付金额：
    prepaymentAmountValue() {
      const value = this.$options.filters['formatMoney'](this.order && this.order.outContractFeeWithTax * this.paymentCheckInfo.advancePercent / 100)
      this.paymentCheckInfo.payablesAmt = (value == '0.00' || !value) ? '' : value
      return this.paymentCheckInfo.payablesAmt
    },
    // 上传路径标识
    dirNameComputed() {
      return this.order && `${this.order && this.order.other && this.order.other.executionId}/${new Date().getTime()}/` || ''
    },
    // 是否专业分包
    isProfessionalSubcontracting() {
      return this.order && ['01', '03'].includes(this.order.orderCateCode)
    },
    // 多文件上传 名称
    upfileNames() {
      let names = ''
      this.upfileList && this.upfileList.map(m => names += `${m.receiptFileName}、`)
      return names.slice(0, -1)
    },
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      // this.order.paymentType = 'progress'
      // this.order.orderCateCode = '01'
      if (this.order && this.order.other && this.order.other && this.order.other.oneselfReceiptsList && this.order.other.oneselfReceiptsList.length) {
        this.upfileList = this.order.other.oneselfReceiptsList
      }
      this.initTitle()
    },

    handlePreview(item) {
      let encodeUrl = encodeURIComponent(item.attachUrl);
      const officeOpenTypeList = [".docx", ".dotx", ".doc", ".xlsx", ".xlsb", ".xlsm", ".xls", ".pptx", ".ppsx", ".ppt", ".pps", ".potx", ".ppsm"];
      let officeOpen = false;
      let userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
      let isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; //判断是否IE<11浏览器
      let isEdge = userAgent.indexOf("Edge") > -1 && !isIE; //判断是否IE的Edge浏览器
      let isIE11 = userAgent.indexOf('Trident') > -1 && userAgent.indexOf("rv:11.0") > -1;
      let IE = false;
      if (isIE || isEdge || isIE11) {
        IE = true
      } else {
        IE = false  //不是ie浏览器
      }
      officeOpenTypeList.some(item => {
        if (encodeUrl.indexOf(item) != -1) {
          return officeOpen = true
        }
      });

      if (officeOpen && !IE) {
        window.open("https://view.officeapps.live.com/op/view.aspx?src=" + encodeUrl, "_blank");
      } else {
        // 加KEY 解决 预览后 下载 跨域报错 bug
        this.$openWindow(`${item.attachUrl}&key=preview`)
      }
    },

    handleDownload(item) {
      this.$download([{
        name: item.receiptFileName,
        url: item.attachUrl
      }])
    },

    initTitle() {
      let title = '鉴证意见'
      if (['contract_op_confirm'].includes(this.order.other.myTaskId)) {
        if (['01', '03'].includes(this.order.orderCateCode)) {
          title = '核定金额并审核意见'
        } else {
          title = '核定金额'
        }
      }

      if (['contract_director_confirm'].includes(this.order.other.myTaskId)) {
        title = '核定金额并审核'
      }

      if (['finance_director_confirm', 'general_manager_confirm'].includes(this.order.other.myTaskId)) {
        title = '审核意见'
      }

      if (['supplier_confirm'].includes(this.order.other.myTaskId)) {
        title = '确认信息'
      }

      if (this.order.close) {
        title = '关闭请款申请'
      }

      this.title = title
    },
    handleDelUpfileClick(idx, item) {
      this.upfileList.splice(idx, 1)
      // 如果有 ID 说明是 退回的 附件,  需要提交后台删除
      if (item && item.id) {
        item.operFlg = 'Del'
        item.receiptId = item.id
        this.saveMoneyApplication(item)
      }
    },

    /**
    * 删除 附件
    */
    async saveMoneyApplication(item) {
      if (!item || !this.order) return
      const params = {
        orderNo: this.order.orderNo,
        paymentNo: this.order.paymentNo,
        paymentOperFlg: 'Upd',
        paymentType: this.order.paymentType,
        receiptsList: [item]
      }
      if (!params) return
      InterfaceService.saveMoneyApplication(params, async data => {
        if (data.respData.respCode === "0000") {
          this.$message.success('删除成功')
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },


    handleDialogConfirm() {
      if (!this.verificationRequire()) return
      if (this.order.close) {
        this.handleCloseConfirm()
        return
      }
      this.submitPaymentDetail()
    },
    outputUpfileList(ev) {
      const addZero = (num, len = 2) => (`0${num}`).slice(-len),
        formaetDate = date => `${date.getFullYear()}-${addZero(date.getMonth() + 1)}-${addZero(date.getDate())} ${addZero(date.getHours())}:${addZero(date.getMinutes())} `

      this.upfileList = this.upfileList.concat(ev)
      this.upfileList.map(m => {
        !m.creTm && (m.creTm = formaetDate(new Date()))
        m.name && (m.receiptFileName = m.name)
      })
    },
    handleDialogCancel() {
      this.$emit('update:visible', false)
    },


    /**
     * 数据验证
     */
    verificationRequire() {
      // start: 流程初始化
      // supplier_apply: 供应商发起请款
      // supervisory_confirm: 施工监理鉴证
      // engineer_pm_confirm: 工程部项目经理鉴证
      // contract_op_confirm: 合约经办人审核
      // contract_director_confirm: 成本总监审核
      // finance_director_confirm: 财务经理/总监审核
      // general_manager_confirm: 项目总/城市总审核
      // supplier_confirm: 供应商确认请款单
      // end: 流程结束
      let start = true

      if (this.order && this.order.other) {
        // 鉴证
        if (['supervisory_confirm', 'engineer_pm_confirm'].includes(this.order.other.myTaskId)) {
          if (!this.paymentCheckInfo.description) {
            this.$message.error('请输入鉴证意见')
            start = false
          }

          // 专业分包
          if (start && ['01', '03'].includes(this.order.other.orderCateCode) && this.order.paymentType === 'progress') {
            if (!this.outputValueCheckInfo.description) {
              this.$message.error('请输入工程进度')
              start = false
            }
          }
        }




        // 核定/审核
        if (this.order && this.order.other && ['contract_op_confirm'].includes(this.order.other.myTaskId)) {

          // 合同预付款
          if (this.order.paymentType === 'advance') {
            if (!this.paymentCheckInfo.advancePercent) {
              this.paymentCheckInfo.advancePercent = NumberUtil.accMul(this.order.advanceInfo && this.order.advanceInfo.advancePercent, 100)
              this.paymentCheckInfo.payablesAmt = this.order.advanceInfo.advanceAmt
              // this.$message.error('请输入预付比例')
              // start = false
            }
          }

          // 材料进场预付款
          if (this.order.paymentType === 'preProgress') {
            if (!this.paymentCheckInfo.payablesAmt) {
              this.paymentCheckInfo.payablesAmt = this.order.preProgressInfo.preProgressAmt
              // this.$message.error('请输入预付金额')
              // start = false
            }
          }

          // 进度款
          if (this.order.paymentType === 'progress') {
            if (!this.paymentCheckInfo.outputValueCheck) {
              this.$message.error('请输入本期核定产值')
              start = false
            }
            if (start && !this.paymentCheckInfo.totalOutputValueCheck) {
              this.$message.error('请输入累计核定产值')
              start = false
            }
            if (start && !this.paymentCheckInfo.totalPayablesAmt) {
              this.$message.error('请输入累计应付金额')
              start = false
            }
            if (start && !this.paymentCheckInfo.totalPaidAmt) {
              this.$message.error('请输入累计已付金额')
              start = false
            }
            if (start && !this.paymentCheckInfo.payablesAmt) {
              this.$message.error('请输入本次请款金额')
              start = false
            }
          }
          // 如果是进度款且专业分包
          if (this.isFileRequire) {
            if (start && !this.paymentCheckInfo.description) {
              this.$message.error('请输入审核意见')
              start = false
            }
            if (start && !(this.upfileList && this.upfileList.length)) {
              this.$message.error('请上传附件')
              start = false
            }
          }
        }

        //财务经理
        // 财务总监
        // 财务经理
        // 财务总监
        if (['finance_director_confirm', 'general_manager_confirm'].includes(this.order.other.myTaskId)) {
          if (start && !this.paymentCheckInfo.description) {
            this.$message.error('请输入审核意见')
            start = false
          }
        }

        if (this.order.close) {
          if (start && !this.paymentCheckInfo.description) {
            this.$message.error('请输入关闭意见')
            start = false
          }
        }

      } else {
        start = false
      }
      return start
    },

    /**
     * 提交
     */
    submitPaymentDetail() {
      const paymentCheckInfo = this.$clone(this.paymentCheckInfo)
      // 预付比例 百分比 转换
      paymentCheckInfo.advancePercent && (paymentCheckInfo.advancePercent = (paymentCheckInfo.advancePercent / 100).toFixed(4))
      // 去掉金额里面的 , 号
      paymentCheckInfo.payablesAmt && (paymentCheckInfo.payablesAmt = paymentCheckInfo.payablesAmt.replace(/\,/g, ''))
      const params = {
        executionId: this.order && this.order.other && this.order.other.executionId,
        isAgree: 'Y',
        receiptsList: this.formatUpfileLis(), // List<Object>	单据列表
        paymentCheckInfo: paymentCheckInfo || {},
        outputValueCheckInfo: this.outputValueCheckInfo || {},
      }

      InterfaceService.submitPaymentDetail(params, data => {
        if (data.respData.respCode === "0000") {
          this.$message.success('审核成功')
          this.$emit('refresh', true)
          this.$emit('update:visible', false)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

    /**
     * 关闭请款申请
     */
    handleCloseConfirm() {
      const paymentCheckInfo = this.$clone(this.paymentCheckInfo),
        params = {
          executionId: this.order && this.order.other && this.order.other.executionId,
          comment: paymentCheckInfo.description || '',
        }

      InterfaceService.closeApprovalProcess(params, data => {
        if (data.respData.respCode === "0000") {
          this.$message.success("关闭成功")
          this.$emit('refresh', true)
          this.$emit('update:visible', false)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

    /**
     * 格式化上传文件
     */
    formatUpfileLis() {
      let arr = []
      // 进度款 合约经办人 专业分包
      const state = this.order && this.order.paymentType === 'progress' && ['contract_op_confirm'].includes(this.order.other.myTaskId) && ['01', '03'].includes(this.order.orderCateCode)
      this.upfileList.forEach(f => {
        // 如果 有ID 说明 是退回的 附件  不再进行上传
        !f.id && arr.push({
          receiptType: state ? 'assessment_Recommendations' : 'others', // assessment_Recommendations 专业分包	String	附件类型（others:其他请款单据）
          attachName: f.receiptFileName, //	String	单据名称
          attachUrl: f.url, //	String	单据地址
        })
      })
      return arr
    }
  }
}
</script>
<style lang="scss" scoped>
.confirm-payment-container {
  .component-container {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
  }
  .flex {
    display: flex;
  }
  .el-row {
    .el-col {
      display: flex;
      margin-top: 22px;
      text-align: left;
      &.unFlex {
        display: inherit;
      }
      &.column {
        flex-direction: column;
      }
      & > span {
        margin-right: 12px;
        width: 70px;
        text-align: right;
        padding-top: 12px;
      }
      .flex {
        & > span {
          margin-right: 12px;
          width: 70px;
          text-align: right;
          padding-top: 12px;
        }
        p {
          margin-top: 12px;
          margin-left: 76px;
        }
      }
      &.gray {
        background: #f1f1f1;
        padding: 8px 22px;
      }
      .upfile-div {
        display: flex;
        width: 100%;
        padding-top: 12px;
        &.isFileRequire {
          padding-top: 0;
          width: 790px;
          p {
            display: flex;
          }
          /deep/ .upfile-container {
            width: 17%;
            background: #ffd64e;
            display: flex;
            .center {
              display: flex;
              width: 100%;
              height: 100%;
              label {
                color: #000 !important;
                width: 100%;
                height: 100%;
                display: flex;
                align-items: center;
                justify-content: center;
              }
            }
          }
        }
        & > label {
          display: flex;
          width: 100%;
          p {
            border: 1px solid #eaeaea;
            height: 40px;
            width: 660px;
            display: flex;
            align-items: center;
            padding: 0 12px;
            display: none;
            .notice {
              color: #999;
            }
            span {
              height: 12px;
              overflow: hidden;
            }
          }
        }
      }
    }
    .upfile-table-body {
      max-height: 192px;
      overflow-y: auto;
    }
    .upfile-table {
      display: flex;
      width: 100%;
      margin-top: 2px;
      &.head {
        color: #666;
      }
      li {
        padding: 12px;
        text-align: left;
        &.txt-right {
          text-align: right;
        }
        background: #ddd;
        &:nth-child(1) {
          width: 50%;
        }
        &:nth-child(2) {
          width: 30%;
        }
        &:nth-child(3) {
          width: 20%;
        }
      }
    }
  }
  .btn-center {
    margin-top: 30px;
    text-align: center;
  }
}
.border-top-dashed {
  border-top: 1px dashed #ddd;
}
.pNotice {
  margin-left: 75px;
  margin-top: 14px;
}
.input-row {
  display: flex;
  width: 100%;
  margin-bottom: 12px;
  overflow: hidden;
  text-align: left;
  li {
    float: left;
    width: 50%;
    display: flex;
    $titleWidth: 100px;
    align-items: center;
    overflow: hidden;
    .title {
      width: $titleWidth;
      text-align: right;
      padding-right: 6px;
      float: left;
    }
    .ipt-container {
      width: calc(100% - #{$titleWidth});
      position: relative;
      input {
        height: 32px;
        line-height: 32px;
        &:disabled {
          background: #eee;
        }
      }
    }
  }
}
.head-title {
  border-left: 4px solid #333;
  padding-left: 8px;
  margin: 12px;
  font-weight: bold;
  text-align: left;
}
.file-center {
  display: flex;
  $titleWidth: 64px;
  & > span {
    width: $titleWidth;
    margin-top: 13px;
    float: left;
  }
  .upfile-div {
    width: calc(100% - #{$titleWidth});
  }
}
.audit-opinion-notice {
  margin: 8px 20px;
  text-align: left;
}
.ipt-notice {
  margin: 20px 18px 14px;
  text-align: left;
}
[suffix-icon="el-icon-percentage"] {
  position: relative;
  input {
    padding-right: 30px;
  }
  &::after {
    content: "%";
    position: absolute;
    right: 10px;
    top: 10px;
    font-size: 14px;
  }
}
[suffix-icon="el-icon-yuan"] {
  position: relative;
  input {
    padding-right: 30px;
  }
  &::after {
    content: "元";
    position: absolute;
    right: 10px;
    top: 10px;
    font-size: 14px;
  }
}
.contract-director-confirm-p {
  font-size: 14px;
  line-height: 22px;
  b {
    font-weight: bold;
  }
}
.contract-director-confirm-div-first {
  margin: 12px 0;
  display: flex;
  span {
    text-align: left;
    &:first-child {
      width: 340px;
    }
    &.wAuto {
      width: auto;
    }
  }
}
.contract-director-confirm-div-last {
  span {
    margin-left: 10px;
  }
  p {
    margin-top: 8px;
  }
}
.mt0 {
  margin-top: 0 !important;
}
.el-textarea {
  width: 790px;
}
</style>
