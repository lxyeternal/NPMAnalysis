<template>
    <div>
        <!-- 签署合同 -->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false">
            <PanelTitle :tabs="tabs" @select="handleSelectTab" bg-color="#fff"></PanelTitle>
            <div class="tc">
                <iframe :src="attach.attachUrl" frameborder="0" width="100%" height="600px">
                    您的浏览器不支持PDF预览
                </iframe>
            </div>
            <p>附件：
                <a class="attach-item blue" v-for="(attach,index) in attachList" :key="index" @click="handleDownload(attach)">{{attach.documentName}}</a>
            </p>
            <div slot="footer" class="dialog-footer">
                <el-button v-if="checkEventRole(contractType)=='unfinish'" type="primary" size="small" style="width: 100px" @click="handleConfirm">确认并签署</el-button>
                <el-button v-if="checkEventRole(contractType)=='finish'" size="small" style="width: 100px" disabled>已签章</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from '@/mixins/account';
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import download from "@/utils/download";
import { InterfaceService } from "@/services/api";
import { filterEventByAcct } from '@/utils/orderUtil';

const tabs = [
    { label: "货物供应合同", type: "10", active: true },
    { label: "货物采购合同", type: "00", active: false }
];
export default {
    mixins:[accountMixin],
    components: {
        Loading,
        PanelTitle
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            order: {},
            contractType: "",
            attach: {},
            attachList: [],
            tabs: JSON.parse(JSON.stringify(tabs))
        };
    },
    methods: {
        open(data) {
            this.order = data;
            this.attach = {};
            this.attachList = [];
            this.init();
            this.dialogVisible = true;
        },
        handleConfirm() {
            let attach = {};
            const events = this.order.eventList || [];
            events.forEach(ev => {
                if (ev.eventType == 0 && this.contractType == ev.documentType) {
                    attach = ev;
                }
            });

            this.dialogVisible = false;
            this.$emit("close", attach);
        },
        handleSelectTab(tab) {
            this.contractType = tab.type;
            this.getContractInfo(tab.type);
        },
        handleDownload(item) {
            const x = new XMLHttpRequest();
            x.open("GET", item.attachUrl, true);
            x.responseType = "blob";
            x.onload = e => {
                download(
                    x.response,
                    item.documentName.split("?")[0],
                    x.response.type
                );
            };
            x.send();
        },
        selectContract(type, list) {
            this.attachList = [];
            const events = list;
            events.forEach(ev => {
                if (type == "10") {
                    // 内部合同
                    if (ev.documentType == "10") {
                        this.attach = ev;
                    } else if (ev.documentType == "14") {
                        this.attachList.push(ev);
                    }
                } else if (type == "00") {
                    // 外部合同
                    if (ev.documentType == "00") {
                        this.attach = ev;
                    } else if (ev.documentType == "04") {
                        this.attachList.push(ev);
                    }
                }
            });
        },
        // 检查角色事件
        checkEventRole(type) {
            let status = '';
            if (this.order && this.order.eventList) {
                let acctIdList = [];
                if (this.userinfo.accountList.length) {
                    this.userinfo.accountList.forEach(item=>{
                        acctIdList.push(item.acctId)
                    });
                }else {
                    acctIdList.push(this.acctId)
                }
                const events =  filterEventByAcct(this.order.eventList, 0, acctIdList);
                events.forEach(ev => {
                    if (ev.eventType == 0 && ev.documentType == type) {
                        if (ev.processList && ev.processList.length) {
                            status = status || "finish";
                            ev.processList.forEach(process => {
                                if (process.processFlg == 0) {
                                    status = "unfinish";
                                }
                            });
                        }
                    }
                });
            }
            return status;
        },
        getContractInfo(type) {
            let bs;
            if (type == "10") {
                bs = "B";
            } else if (type == "00") {
                bs = "S";
            }
            const params = {
                orderNo: this.order.orderNo,
                bs: bs
            };
            InterfaceService.getContractInfo(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        const list = data.respData.documentInfos || [];
                        this.selectContract(type, list);
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        init() {
            let hasInner, hasOuter;
            const events = this.order.eventList || [];
            events.forEach(ev => {
                if (
                    ev.eventType == 0 &&
                    (ev.eventStatus == 0 || ev.eventStatus == 1)
                ) {
                    if (ev.documentType == "10") {
                        hasInner = true;
                    } else if (ev.documentType == "00") {
                        hasOuter = true;
                    }
                }
            });

            if (this.role == "B") {
                if (hasInner && hasOuter) {
                    this.tabs = this.$clone(tabs);
                    this.contractType = "10";
                } else if (hasInner) {
                    this.tabs = [
                        { label: "货物供应合同", type: "10", active: true }
                    ];
                    this.contractType = "10";
                } else if (hasOuter) {
                    this.tabs = [
                        { label: "货物采购合同", type: "00", active: true }
                    ];
                    this.contractType = "00";
                }
            } else if (this.role == "S") {
                if (hasOuter) {
                    this.tabs = [
                        { label: "货物采购合同", type: "00", active: true }
                    ];
                    this.contractType = "00";
                }
            }
            this.getContractInfo(this.contractType);
        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;

    /deep/ .el-dialog__header {
        padding: 0;

        &:before {
            display: none;
        }
    }
}

.attach-item {
    margin-right: 10px;
}
</style>
