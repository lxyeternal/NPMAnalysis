<template>
  <div class="companyBank">
    <div class="list-content">
      <div class="box_steps">
        <Steps :tenderList="tenderList" :active="step" :space="340"></Steps>
      </div>
      <!-- 确认企业基础信息 -->
      <div class="basic-info" v-if="step === 0">
        <el-form class="form" size="small" label-width="126px" :model="form" :rules="rules" ref="formBulletBox1">
          <ul class="company">
            <li>
              <div class="left">
                <span>企业名称：</span>
                <div class="company-showtext">{{infoData.corpName}}</div>
              </div>
              <div class="left">
                <span>统一社会信用代码：</span>
                <div class="company-showtext">{{infoData.busiLicense}}</div>
              </div>
            </li>
            <li>
              <div class="left">
                <el-form-item label="法人姓名：" prop="legalRepresent" class="legalCertNo">
                  <el-input type="text" placeholder="请输入法人姓名" v-model="form.legalRepresent" clearable maxlength="6"></el-input>
                </el-form-item>
              </div>
              <div class="left">
                <el-form-item label="法人身份证号：" prop="legalCertNo" class="legalCertNo">
                  <el-input type="text" placeholder="请输入身份证号" v-model="form.legalCertNo" clearable maxlength="18"></el-input>
                </el-form-item>
              </div>
            </li>
          </ul>
        </el-form>
        <div class="searchbox">
          <el-button type="primary" class="normal-btn" @click="handleStep">下一步</el-button>
        </div>
      </div>

      <!-- 填写银行账号 -->
      <BankAccount style="margin-top: 40px" v-if="step === 1" :propCorpId="propCorpId" :propAcctId="propAcctId" :acctName="infoData.corpName" :bankInfos="bankInfos" @updateStep="updateStep"></BankAccount>

      <!-- 校验接受金额 -->
      <div class="checkMoney" v-if="step === 2">
        <div class="box_type">
          <p>1.打款请求已发送，到账信息依据接收银行处理时效，请关注银行卡余额的变动； </p>
          <p>2.如果2～3个工作日还未收到打款信息，点击<span class="hand blue" @click="again">重新打款</span>；</p>
          <p>3.请从以下填写的银行账户查询收到的金额，并填入下方输入框内：</p>
          <div class="annex" style="margin-top: 20px">
            <div class="left grey">户&nbsp;&nbsp;&nbsp;&nbsp;名：</div>
            <div class="right">{{infoData.corpName}}</div>
          </div>
          <div class="annex">
            <div class="left grey">银行账号：</div>
            <div class="right">{{bankInfo.bankAcctNo | formatCardNum}}</div>
          </div>
          <div class="annex">
            <div class="left grey">银行名称：</div>
            <div class="right">{{bankInfo.bankName}}</div>
          </div>
          <div class="annex">
            <div class="left grey">支行名称：</div>
            <div class="right">{{bankInfo.subBranch}}</div>
          </div>
        </div>
        <el-form style="margin-top: 40px" class="form" size="small" label-width="90px" :model="form1" :rules="rules1" ref="formBulletBox2">
          <el-row>
            <el-col :span="24">
              <el-form-item label="接收金额：" prop="amount" class="amount">
                <el-input placeholder="请输入银行卡内收到的准确金额" v-model="form1.amount" maxlength="18" @input="form1.amount=form1.amount.replace(/[^\d.]/g,'')">
                  <div slot="suffix" class="suffix">元</div>
                </el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
        <div class="searchbox">
          <el-button :disabled="!form1.amount" :class="{'isDisabled-primary':!form1.amount}" type="primary" class="normal-btn" @click="handleCheck">提交核验</el-button>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import { viewFile } from '@/utils/orderUtil';
import Steps from "@/components/base/steps";
import BankAccount from "@/components/order/enterpriseCertification/BankAccount";
export default {
  components: {
    Loading, PanelTitle, viewFile, Steps, BankAccount
  },
  // propCorpId 如果外部 传入 corpId 则用 外部corpId 入参
  props: ['info', 'bankInfo', 'propCorpId', 'propAcctId'],
  watch: {
    bankInfo: {
      handler(val) {
        // console.log('bankInfos-----')
        // console.log(val)
        this.bankInfos = Object.assign({}, val)
      },
      immediate: true,
    },
    info: {
      handler(val) {
        // console.log('parent---')
        // console.log(val)
        this.infoData = this.$clone(val)
        this.form.legalCertNo = this.infoData.legalCertNo
      },
      immediate: true,
    },
    step(val) {
      if (val === 2) {
        this.form1.amount = ''
      }
    }
  },
  data() {
    let validataCertNo = (rule, value, callback) => {
      let certNoReg = this.$commonExpression('certNo');
      if (!value) {
        callback(new Error('请输入身份证号'));
      } else {
        if (!certNoReg.test(this.form.legalCertNo) && this.form.legalCertNo) {
          callback(new Error('身份证号格式不正确'));
        }
        callback();
      }
    };
    return {
      isLoading: false,

      infoData: {},
      bankInfos: {},
      step: 0,//0:确认企业基础信息 1:填写银行账号 2:校验接受金额
      tenderList: [
        {
          foot_info: "① 确认企业基础信息",
        },
        {
          foot_info: "② 填写银行账号",
        },
        {
          foot_info: "③ 校验接受金额",
        }
      ],
      acCorpInfoBean: {},
      form: {
        legalCertNo: '',
        legalRepresent: ''
      },
      rules: {
        legalCertNo: [
          { required: true, validator: validataCertNo, trigger: 'blur' }
        ],
        legalRepresent: [
          { required: true, message: '请输入法人姓名', trigger: 'blur' }
        ],
      },
      form1: {
        amount: '',
      },
      rules1: {
        amount: [
          { required: true, message: "必填", trigger: 'blur' },
        ],
      },
    };
  },
  methods: {
    updateStep(step) {
      this.$emit('upDate')
      this.step = step
    },
    handleStep() {
      this.$refs['formBulletBox1'].validate((valid) => {
        if (valid) {
          this.initiateCorporateCer()
        } else {
          this.$message.error('还有必填内容未填写，请检查填写信息！');
          return false
        }
      });
    },
    // 发起企业核身认证
    initiateCorporateCer(bankInfo) {
      let param = {}
      if (bankInfo) {
        this.form.legalRepresent = bankInfo.legalRepresent
        param = {
          corpId: this.propCorpId || this.$store.state.userInfo.corpId,
          corpName: bankInfo.corpName,
          busiLicense: bankInfo.orgCode,
          legalRepresent: this.form.legalRepresent,
          legalCertNo: bankInfo.legalCertNo,
          bankAcctType: bankInfo.bankAcctType,
        };
      } else {
        param = {
          corpId: this.propCorpId || this.$store.state.userInfo.corpId,
          corpName: this.infoData.corpName,
          busiLicense: this.infoData.busiLicense,
          legalRepresent: this.form.legalRepresent,
          legalCertNo: this.form.legalCertNo,
          bankAcctType: this.bankInfo.bankAcctType,
        };
      }
      console.log(param, 'param');
      InterfaceService.initiateCorporateCer(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          if (data.respData.status === '1') {
            this.$message.success('操作成功')
            this.$emit('upDate')
            this.step = 1
          } else {
            this.$message.error(data.respData.message)
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 重新打款
    again() {
      // this.bankInfos.provCode = ''
      // this.bankInfos.cityCode = ''
      // this.bankInfos.districtCode = ''
      this.initiateCorporateCer(this.bankInfo)
    },
    handleCheck() {
      this.$refs['formBulletBox2'].validate((valid) => {
        if (valid) {
          this.checkMarkMoney()
        } else {
          this.$message.error('还有必填内容未填写，请检查填写信息！');
          return false
        }
      });
    },
    // 验证接收金额
    checkMarkMoney() {
      const params = {
        bankAcctId: this.bankInfo.bankAcctId,
        amount: this.form1.amount,
        acctId: this.propAcctId || undefined, // 事业部列表传入
      }
      InterfaceService.checkMarkMoney(params, (data) => {
        const result = data.respData;
        if (result.respCode == '0000') {
          if (data.respData.status === '1') {
            this.$message.success('接收金额核验成功')
            this.$emit('upDate', true)
          } else {
            this.$message.error(data.respData.message)
          }
        } else {
          this.$message.error(result.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 查询未入库体检对象供应商
    doGetProviderRiskDetail() {
      const params = {
        name: this.info.corpName,
        type: "baseInfo"
      }
      InterfaceService.doGetProviderRiskDetail(params, (data) => {
        const result = data.respData;
        if (result.respCode == '0000') {
          const obj = result.evaluationInfo || {}
          this.infoData.busiLicense = obj.orgNumber || this.infoData.busiLicense
          this.infoData.legalRepresent = obj.legalPerson || this.infoData.legalRepresent
          this.form.legalRepresent = obj.legalPerson || this.infoData.legalRepresent
        } else {
          this.$message.error(result.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  },
  // mounted() {
  //   this.init()
  // },
};
</script>

<style lang="scss" scoped>
/deep/ .busiLicense {
  width: 100%;
  .el-form-item__content {
    width: calc(100% - 126px) !important;
  }
}
/deep/ .amount {
  .el-input__inner {
    padding-right: 30px;
  }
}
.suffix {
  color: #444;
  margin-right: 4px;
}
.searchbox {
  text-align: center;
  margin-top: 22px;
}
.companyBank {
  margin: 0 auto;
  padding-bottom: 60px;
  .list-content {
    .box_steps {
      padding: 20px 0 30px;
      box-shadow: 0px 0px 8px rgba(147, 147, 147, 0.16);
    }
    .basic-info {
      .company {
        width: 100%;
        padding: 40px 0 0px;
        > li {
          width: 100%;
          display: flex;
          margin-bottom: 10px;
          &:last-child {
            margin-bottom: 0px;
          }
          .left {
            flex: 1;
            line-height: 20px;
            font-size: 14px;
            color: #444444;
            display: flex;
            > span {
              color: #888888;
              display: inline-block;
              vertical-align: top;
              white-space: nowrap;
              width: 126px;
              text-align: right;
            }
            > div {
              display: inline-block;
            }
            .company-showtext {
              display: inline-block;
            }
          }
        }
      }
    }
    .checkMoney {
      margin-top: 40px;
      .box_type {
        width: 100%;
        //   height: 42px;
        background: rgba(255, 252, 240, 1);
        border: 1px solid rgba(250, 226, 165, 1);
        font-size: 12px;
        line-height: 17px;
        color: #444444;
        padding: 14px 10px;
        > p {
          margin-bottom: 10px;
          font-size: 14px;
          line-height: 20px;
        }
        > .annex {
          display: flex;
          margin-top: 10px;
          > .right {
            > p {
              margin-bottom: 10px;
              &:last-child {
                margin-bottom: 0;
              }
              > span {
                margin-left: 2px;
                margin-right: 10px;
              }
            }
          }
        }
      }
    }
  }
}
.legal-represent-container {
  display: flex;
  align-items: center;
  /deep/ .el-input__inner {
    height: 32px;
    line-height: 32;
  }
}
</style>
