<template>
    <div class="operate">
        <p v-if="allowSign()">
            <el-button type="primary" size="mini" @click="handleViewDetail">核对请款报告</el-button>
        </p>
        <p>
            <a v-if="status==2" @click="handleDownload">下载{{statementText}}</a>
        </p>
        <p>
            <a @click="handleViewDetail">查看请款计划资料</a>
        </p>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import { filterEventByAcct, allowByEvent } from "@/utils/orderUtil";
export default {
    mixins: [accountMixin],
    components: {
        Loading
    },
    props: ["type", "order", "status"],
    data() {
        return {
            isLoading: false
        };
    },
    computed: {
        eventType() {
            return this.type === "pay" ? 3 : 4;
        },
        statementText() {
            return this.type === "pay" ? "应付对账单" : "应收对账单";
        }
    },
    methods: {
        handleViewDetail() {
            this.$router.push({
                path: "/paymentReportDetail",
                query: {
                    type: this.type,
                    statementNo: this.order.statementNo
                }
            });
        },
        handleDownload() {
            let attachUrl = "";
            if (this.order && this.order.eventList) {
                this.order.eventList.forEach(item => {
                    if (item.eventType == this.eventType) {
                        attachUrl = item.attachUrl;
                    }
                });
            }

            if (!attachUrl) return this.$message.error("无下载地址");
            let name = attachUrl.split("?")[0];
            name = name.split("/").pop();
            const files = [{ name: decodeURIComponent(name), url: attachUrl }];
            this.$download(files).then(() => {
                this.$message.success("已下载");
            });
        },
        // 对账单待签章
        allowSign() {
            const eventType = this.eventType;
            let allow = false;
            if (this.order && this.order.eventList) {
                let acctIdList = [];
                if (this.userinfo.accountList.length) {
                    this.userinfo.accountList.forEach(item=>{
                        acctIdList.push(item.acctId)
                    });
                }else {
                    acctIdList.push(this.acctId)
                }
                const list = filterEventByAcct(
                    this.order.eventList,
                    eventType,
                    acctIdList
                );
                allow = allowByEvent(list, eventType);
            }
            return allow;
        }
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-button {
    margin-bottom: 5px;
}

.operate {
    a {
        display: block;
        white-space: nowrap;
        padding: 5px 5px 0 5px;
        line-height: 18px;
        color: #0082ff;
    }
}
</style>
