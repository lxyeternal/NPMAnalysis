<template>
    <div>
        <!-- <div class="order-status" v-if="showStatus"> -->
        <div class="order-status">
            <div class="status-info">
                <div class="status-info-content">
                    <div>
                        <div>
                            <label>当前状态：</label>
                            <span class="big">{{approvalStatusDisp}}</span>
                        </div>
                        <div v-if="lastFailTm">
                            <label>{{operationType}}：</label>
                            <span class="big">{{lastFailTm}}</span>
                        </div>
                        <div class="operation" :class="{'right55': !showCirculationOpinion}" v-if="startButton">
                            <el-button v-if="type != 'payment'" type="primary" @click="handleApprovalConfirm()">审批</el-button>
                            <template v-if="type == 'payment'">
                                <el-button v-if="applyFlg == '2'" type="primary" @click="handleApprovalConfirm()">审批</el-button>
                                <el-button v-if="applyFlg != '2'" type="primary" @click="handleEditPaymentInfo('showAll')">完善资料</el-button>
                            </template>
                            <el-button @click="closeApproavlDialogVisible = true">{{type === 'payment' ? "关闭流程" : "关闭"}}</el-button>
                         </div>
                            <div class="operation" :class="{'right55': !showCirculationOpinion}" v-if="approvalButton">
                            <el-button type="primary" @click="batchApproavlDialogVisible = true">同意</el-button>
                            <el-button @click="rejectedDialogVisible = true">退回</el-button>
                        </div>
                        <div class="operation" :class="{'right55': !showCirculationOpinion}" v-if="canceledButton">
                            <el-button @click="cancleApproavlDialogVisible = true">撤回</el-button>
                        </div>
                        <!-- <div class="confirm" v-if="showCirculationOpinion">
                            <el-button size="small" style="width: 100px" @click="handleOpenCirculationOpinion()">查看流转意见</el-button>
                            <CirculationOpinion ref="circulationOpinion" ></CirculationOpinion>
                        </div> -->


                        <!-- <div class="confirm" v-if="showCirculationOpinion">
                            <el-button size="small" style="width: 100px" @click="handleOpenCirculationOpinion()">查看流转意见</el-button>
                            <CirculationOpinion ref="circulationOpinion" ></CirculationOpinion>
                        </div> -->
                        <div class="forward-container" v-if="canFwRoleList.length && !fwStatus || type == 'payment'">
                            <i @mouseout="showForward()" @mouseover="showForward(true)"></i>
                            <ul v-if="isShowForward" @mouseout="showForward()" @mouseover="showForward(true)">
                                <li class="save" @click="handleClickForward(1)" v-if="type != 'payment'"><i></i>转发</li>
                                <li class="printing" @click="handleClickForward(2)" v-if="type == 'payment'"><i></i>打印</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- 流转意见 -->
        <!--  v-if="showCirculationOpinion" -->
        <div :class="['circulation-opinion-container', {openOption: isOpenOptionCirculation}]" v-if="execFlowList.length">
            <i class="option-circulation" v-if="isOpenOptionCirculation" @click="handleClickOptionCirculation">
                {{isOpenOptionCirculation ? '收起': '展开'}}
            </i>
            <div class="center">
                <div class="head-title">流转意见</div>
                <ul :class="{'isOpenOptionCirculation': !isOpenOptionCirculation,'one':computedExecFlowList && computedExecFlowList.length == 1}">
                    <li  v-for="(item,index) in computedExecFlowList" :key="index" :class="{'isAgree': computedCirculationState(item).isAgree}">
                        <dl>
                            <dt>{{item.acctName}}</dt>
                            <dd class="color888888">{{item.roleName}}</dd>
                        </dl>
                        <dl>
                            <dt>{{computedCirculationState(item).state}}</dt>
                            <!--  -->
                            <dd class="color888888">{{item.finishTm}}</dd>
                        </dl>
                        <dl v-if="item.comment">
                            <dt>{{computedCirculationState(item).reason}}:</dt>
                            <dd :title="item.comment" v-html="item.comment.replace(/\n/g, '<br/>')"></dd>
                        </dl>
                    </li>
                </ul>
                <div class="center-option-circulation" :style="{marginTop: isOpenOptionCirculation?'16px':''}">
                    <i class="option-circulation" @click="handleClickOptionCirculation">
                        {{isOpenOptionCirculation? '收起': '展开'}}
                    </i>
                </div>
            </div>
        </div>
        <!-- 确认审批 -->
        <el-dialog class="dialog padding10Dialog" :title="comfirmTitle" :append-to-body="true" :lock-scroll="true" :visible.sync="batchApproavlDialogVisible" width="840px" center :close-on-click-modal="false" :show-close="false"   @close="entryNum = 0;comment = ''">
            <div class="f14 form-btns" v-if="type != 'payment'" >确认通过此合同审批吗？</div>
            <div class="f14 form-btns" v-if="type == 'payment'">确认通过此合同请款审批吗？</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="comment" placeholder="请填写审批意见，300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm('Y')">同意</el-button>
                <el-button size="small" style="width: 100px" @click="batchApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--审批退回-->
        <el-dialog class="dialog padding10Dialog" title="退回原因" :append-to-body="true" :lock-scroll="true" :visible.sync="rejectedDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;rejectedReason = ''">
            <div class="f14 form-btns" style="text-align: left">请填写退回的原因</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="rejectedReason" placeholder="请填写退回的原因，300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button v-if="!managerApproval || type === 'payment'" type="primary" :disabled="!rejectedReason" size="small" style="width: 100px" @click="handleConfirm('N')">退回</el-button>
                <el-button v-if="managerApproval && type !== 'payment'" type="primary" :disabled="!rejectedReason" size="small" @click="handleConfirm('N')">退回到招采合约</el-button>
                <el-button v-if="managerApproval && type !== 'payment'" type="primary" :disabled="!rejectedReason" size="small" @click="handleCloseConfirm('manager')">退回到城市公司</el-button>
                <el-button size="small" style="width: 100px" @click="rejectedDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--关闭审批-->
        <el-dialog class="dialog padding10Dialog" :title="type === 'payment' ? '关闭流程' : '关闭'" :append-to-body="true" :lock-scroll="true" :visible.sync="closeApproavlDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;closeReason = ''">
            <div class="f14 form-btns" style="text-align: left;margin-bottom: 10px;">{{type === 'payment' ? '关闭流程后，将无法恢复本请款审批信息，确认关闭吗?' : '关闭后，系统会将关闭原因反馈给合同创建人。'}}</div>
            <div class="f14" style="text-align: left">请填写{{type === 'payment' ? '关闭流程' : '关闭'}}原因：</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="closeReason" :placeholder="type === 'payment' ? '请填写关闭流程原因,300字以内' : '请填写关闭原因,300字以内'" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button :disabled="!closeReason" type="primary" size="small" style="width: 100px" @click="handleCloseConfirm()">提交关闭</el-button>
                <el-button size="small" style="width: 100px" @click="closeApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--确认撤回审批-->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="cancleApproavlDialogVisible" width="500px" center :close-on-click-modal="false" :show-close="false" >
            <div class="f14 form-btns" style="margin-bottom: 10px">确认要撤回合同审批？撤回后的合同，在【待处理】中查看。</div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleCanceledConfirm()">确定撤回</el-button>
                <el-button size="small" style="width: 100px" @click="cancleApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!-- 弹窗 -->
    <el-dialog class="dialog dialog-drafts" :title="cpContractName" :append-to-body="true" :lock-scroll="true" :visible.sync="isShwoForwardDialogVisible" width="50%" center :close-on-click-modal="false">
      <div class="forward-dialog-container">
          <div class="head">
            <span>转发接收人</span>
            <!-- remote 是否远程, collapse-tags 显示tag标签 -->
            <el-select v-model="forwardSelectValue" reserve-keyword multiple filterable placeholder="请选择">
                <el-option v-for="item in roleList.filter(item=>canFwRoleList.includes(item.roleId))" :key="item.value" :label="item.label" :value="item.value" />
            </el-select>
          </div>
          <div class="body">
              <el-input type="textarea" class="textareaContainer" placeholder="请输入内容" v-model="forwardContenr" maxlength="300" />
              <span>{{forwardContenr.length}} / 300</span>
          </div>
          <div class="foot">
               <el-button type="primary" size="small" style="width: 100px" @click="handleClickSubmitForward">提交</el-button>
                <el-button size="small" style="width: 100px" @click="isShwoForwardDialogVisible = false">取消</el-button>
          </div>
      </div>
    </el-dialog>
        <!--发起单个审批-->
        <BrokerApproval v-if="type != 'payment'" ref="brokerApproval" @close="refresh"></BrokerApproval>
        <BrokerPaymentApproval v-if="type == 'payment'" ref="brokerPaymentApproval" @goBack = "goBack" @refresh="refresh"></BrokerPaymentApproval>
        <ImprovePaymentInfo ref="improvePaymentInfo" @close="refresh"></ImprovePaymentInfo>
    </div>
</template>

<script>
    import accountMixin from '@/mixins/account';
    import { InterfaceService } from "@/services/api";
    import BrokerApproval from "@/components/order/broker/BrokerApproval";
    import BrokerPaymentApproval from "@/components/order/broker/dialog/BrokerPaymentApproval";
    import CirculationOpinion from "@/components/order/broker/CirculationOpinion";
    import ImprovePaymentInfo from "@/components/order/broker/dialog/ImprovePaymentInfo";
    export default {
        mixins:[accountMixin],
        components: {
            BrokerApproval,
            CirculationOpinion,
            BrokerPaymentApproval,
            ImprovePaymentInfo
        },
        props: ["type","executionId", "approvalInfo", "canFwRoleList", "fwStatus","managerApproval"],
        data() {
            return {
                value: '',
                attach: {},
                approvalStatusDisp:"",
                handleCloseName:"",
                closeExecutionId:"",
                rejectedReason:"",
                closeReason:"",
                newExecutionId:"",
                comment:"",
                closeApproavlDialogVisible:false,
                batchApproavlDialogVisible:false,
                rejectedDialogVisible:false,
                cancleApproavlDialogVisible:false,
                acctName:"",
                comfirmTitle:"",
                lastFailTm:"",
                operationType:"",
                approvalButton:false,
                startButton:false,
                canceledButton:false,
                showCirculationOpinion:false,
                showStatus:false,
                approveFlowList:[],
                entryNum:0,
                execFlowList:[],
                isShowForward: false, // 是否显示 转发和打印
                showForwardTimer: null,
                isShwoForwardDialogVisible: false, // 是否显示转发弹窗
                forwardContenr: '', // 转发内容
                forwardSelectValue: [], // 已选转发人
                isOpenOptionCirculation: false, // 展开流转意见
                roleList: [], // 转发接收人
                procDefKey: '', // 合同状态 CONTRACT_APPROVE_WF": 审批 (审批流程), "CONTRACT_TERMINATE_WF": 合同终止()
            };
        },
        computed: {
            cpContractName() {
                return `《${this.approvalInfo.contractName}》${this.procDefKey === 'CONTRACT_APPROVE_WF' ? '审批流程' : ''}`
            },
            computedCirculationState() {
                return (item) => {
                    // item.isAgree === "Y" ? "审批意见" : "退回原因"
                    let result = {};
                    if (item.taskId === 'canceled') {
                        result.state = '审批撤回';
                        result.reason = '审批意见'
                    } else if (item.taskId === 'closed') {
                        result.state = '审批关闭';
                        result.reason = '关闭原因'
                    }else {
                        if (item.fwStatus == '1' || item.fwStatus == '2' ) {
                        result.state = item.fwStatus == '1' ? `转发${item.fwRoleName || ''}` : '批注'
                        result.reason =  item.fwStatus == '1' ? `转发内容` : '批注内容'
                        } else {
                            result.state = item.isAgree === "Y" ? "审批通过" : "审批退回"
                            result.reason = item.isAgree === "Y" ? "审批意见" : "退回原因"
                            result.isAgree = item.isAgree === "N"
                        }
                    }
                    return result
                }
            },
            computedExecFlowList() {
                return this.execFlowList.filter((item, idx) => {
                    /**
                     * 收缩情况下 只显示两条
                     */
                    if (!this.isOpenOptionCirculation) {
                        return idx <= 1
                    } else {
                        return true
                    }
                })
            }
        },
        watch: {
            approvalInfo(newVal) {
                this.init();
            }
        },
        methods: {
             handleClose(done) {
                this.$confirm('确认关闭？')
                .then(_ => {
                    done();
                })
                .catch(_ => {});
            },
            // 确认合同弹窗
            handleApprovalConfirm(){
                if (this.type == "payment") {
                     const data ={
                         executionId : this.executionId,
                         procDefKey : this.procDefKey
                     };
                     this.$refs["brokerPaymentApproval"].open(data);
                 }else {
                    this.$refs["brokerApproval"].open(this.executionId);
                 }
            },
            handleOpenCirculationOpinion(){
                console.log(this.execFlowList, 'this.execFlowList');

                this.$refs["circulationOpinion"].open(this.execFlowList);
            },
            handleConfirm(type){
                let executionList = [];
                let comment ;
                this.comment ? comment = this.comment : comment = "同意";
                if (type == 'Y'){
                    executionList.push({
                        executionId: this.executionId,
                        isAgree: "Y",
                        comment:comment,
                        procDefKey: this.procDefKey,
                    })
                }else if (type == 'N') {
                    executionList.push({
                        executionId: this.executionId,
                        isAgree: "N",
                        comment:this.rejectedReason,
                        procDefKey: this.procDefKey,
                    })
                }
                const params = {
                    executionList: executionList
                };
                InterfaceService.batchApprovalProcess(
                    params,
                    data => {
                        if (data.respCode === "0000") {
                            console.log(data);
                            if (data.respData.respList) {
                                this.approvalResult = data.respData.respList;
                                this.approvalResult.forEach(item=>{
                                    if (item.approveCode == "0000"){
                                        type == 'Y' ? this.$message.success("审批成功") : this.$message.success("退回操作完成");
                                        this.batchApproavlDialogVisible = false;
                                        this.rejectedDialogVisible = false;
                                        this.$emit("refresh")
                                    } else {
                                        this.$message.error(item.approveMsg);
                                    }
                                });
                            }else {
                                this.$message.error(data.respData.respMsg);
                            }
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleCloseConfirm(manager){
                let params = {};
                if (this.executionId) {
                    params = {
                        executionId : this.executionId,
                        procDefKey: this.procDefKey,
                        comment: manager ? this.rejectedReason : this.closeReason,
                    };
                }
                InterfaceService.closeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            if (!this.managerApproval) {
                                this.$message.success(this.type == "payment" ? "流程关闭成功" : "关闭成功");
                                this.closeApproavlDialogVisible = false;
                            } else {
                                this.$message.success("退回操作完成");
                                this.rejectedDialogVisible = false;
                            }
                            this.$emit("refresh")
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleEntry(ev){
                this.entryNum = ev.length
            },
            handleCanceledConfirm(){
                const params = {
                    executionId : this.newExecutionId || this.executionId
                };
                InterfaceService.revokeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("撤回成功");
                            this.cancleApproavlDialogVisible = false;
                            if (this.newExecutionId) {
                                this.$emit("refresh",this.newExecutionId)
                            }else {
                                this.$emit("refresh")
                            }
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            refresh(bool,data){
                if (bool) {
                    if (data) {
                        this.$refs["brokerPaymentApproval"].open(data);
                    }
                    this.$emit("refresh")
                }
            },
            goBack(id,key){
                if (id && key) {
                    this.handleEditPaymentInfo("showAll");
                }
            },
            // 根据operateStatus传值判断 显示的按钮
            getOperateStatus(){
                this.startButton = false;
                this.approvalButton = false;
                this.canceledButton = false;
                let status = this.approvalInfo.operateStatus;
                if (status == "start") {
                    this.startButton = true;
                }else if (status == "approve"){
                    this.approvalButton = true;
                }else if (status == "cancel") {
                    this.canceledButton = true
                }
            },
            init(){
                this.executionId = this.$props.executionId;
                this.procDefKey = this.$route.query.procDefKey;
                this.approvalInfo = this.$props.approvalInfo;
                this.applyFlg = this.$props.approvalInfo.applyFlg
                this.approveFlowList = this.approvalInfo.approveFlowList || [];
                this.execFlowList = this.approvalInfo.execFlowList || [];
                let operation = this.execFlowList && this.execFlowList[0];
                this.showStatus = this.approveFlowList && this.approveFlowList.length > 0;
                if (this.execFlowList && this.execFlowList.length == 0) {
                    this.approveFlowList.forEach(item=>{
                        if (item.isCurrentNode == "1") {
                            this.approvalStatusDisp = item.flowName;
                        }
                    });
                    this.showCirculationOpinion = false;
                }else if (this.execFlowList && this.execFlowList.length > 0) {
                    this.showCirculationOpinion = true;
                    this.approveFlowList.forEach(item=>{
                        if (item.isCurrentNode == "1" && item.step == "1"){
                            this.lastFailTm = this.execFlowList[0].finishTm;
                            if (operation.isAgree == "N" && operation.taskId == "operation_confirm") {
                                this.approvalStatusDisp = "工程部退回";
                                this.operationType = "退回时间";
                            }else if (operation.isAgree == "N" && operation.taskId == "finance_confirm") {
                                this.approvalStatusDisp = "财务部退回";
                                this.operationType = "退回时间";
                            }else if (operation.isAgree == "N" && operation.taskId == "vgm_confirm") {
                                this.approvalStatusDisp = "副总经理退回";
                                this.operationType = "退回时间";
                            } else if (operation.isAgree == "N" && operation.taskId == "contract_confirm") {
                                this.approvalStatusDisp = "招采部退回";
                                this.operationType = "退回时间";
                            } else if (operation.taskId == "canceled") {
                                if (this.type == "payment") {
                                    this.approvalStatusDisp = "工程部已撤回审批";
                                }else {
                                    this.approvalStatusDisp = "招采合约部已撤回审批";
                                }
                                this.operationType = "撤回时间";
                            } else if (operation.taskId == "contract_apply" || operation.taskId == "closed") {
                                this.approvalStatusDisp = "招采合约部审批";
                                this.lastFailTm = "";
                            }
                        } else if (item.isCurrentNode == "1" && item.step != "1") {
                            this.approvalStatusDisp = item.flowName;
                            this.lastFailTm = "";
                        }
                    });
                }
                this.type == "payment" ? this.comfirmTitle = "请款审批" : this.comfirmTitle = "合同审批"
                this.getRoleList();
                this.getOperateStatus()
            },

            /**
             * 是否展示 转发 和 打印
             * @param state true: 是, fasle: 否
             */
            showForward(state = false) {
                if (state) {
                    clearTimeout(this.showForwardTimer)
                }
                this.showForwardTimer = setTimeout(e => this.isShowForward = state, 50)
            },

            /**
             * 转发 和 打印 点击
             * @param state 1: 转发, 2: 打印
             */
            handleClickForward(state) {
                this.forwardSelectValue = [];
                this.forwardContenr = '';
                switch(state) {
                    case 1:
                        this.isShwoForwardDialogVisible = true
                        break
                    case 2:
                        console.log(123)
                        this.$emit('dandleClickPrint')
                        break
                }
            },

            /**
             * 提交转发
             */
            handleClickSubmitForward() {
                // 代码review改进
                if (!(this.forwardSelectValue && this.forwardSelectValue.length)) {
                    this.$message.error('接收人不能为空')
                    return
                }
                // 代码review改进
                if (!(this.forwardContenr && this.forwardContenr.length)) {
                    this.$message.error('转发内容不能为空')
                    return
                }
                this.processForwarding();
            },

            /**
             * 发送流程转发
             */
            processForwarding() {
                const param = [{
                    executionId: this.executionId,
                    comment: this.forwardContenr,
                    fwRoleList: this.formatForwardSelectValue()
                }]

                console.log(param, '提交接收人');
                InterfaceService.processForwarding({executionList: param}, (data) => {
                    console.log(data, '---data');

                if (data.respCode === "0000") {
                    if (data.respData && data.respData.respCode == "0000"){
                        this.$message.success(data.respData.respMsg);
                        this.isShwoForwardDialogVisible = false;
                        this.$emit("refresh")
                    }else {
                        this.$message.error(data.respData.respMsg);
                    }
                } else {
                    this.$message.error(data.respData.respMsg);
                }
                }, data => {}, () => {
                    this.isLoading = true;
                }, () => {
                    this.isLoading = false;
                });
            },

            /**
             * 格式化提交接收人入参
             */
            formatForwardSelectValue() {
                let roleId = []
                this.forwardSelectValue.forEach(value => {
                    for (let i = 0, len = this.roleList; i < len.length; i++) {
                        const role = this.roleList[i]

                        if (role.value === value) {
                            roleId.push(role.roleId)
                        }
                    }
                })

                return [...new Set(roleId)]
                // .map(item => {
                //     return {fwRole: item}
                // })
            },

            /**
             * 展开收缩 - 流转意见
             */
            handleClickOptionCirculation() {
                this.isOpenOptionCirculation = ! this.isOpenOptionCirculation
            },
            /**
             * 请款完善资料
             */
            handleEditPaymentInfo(type){
                this.$refs["improvePaymentInfo"].open(type,this.executionId,this.procDefKey );
            },
            /**
             * 查询公司下属角色信息 - 转发接收人
             */
            getRoleList() {
                InterfaceService.getRoleManageList({}, (data) => {
                    if (data.respCode === "0000") {
                        if (data.respData && data.respData.respCode == "0000"){
                            this.roleList = [];
                            const _dataList = data.respData.menuList || []
                            let valueIdx = 0

                            if (!(_dataList instanceof Array)) true
                            _dataList.forEach(item => {
                                const { roleId, roleName, acctList }  = item
                                if (!(acctList instanceof Array)) true
                                acctList.forEach (acctItem => {
                                    const { acctId, custName } = acctItem
                                    this.roleList.push({
                                        roleId,
                                        label: `${roleName} - ${custName}`,
                                        acctId,
                                        value: valueIdx
                                    })
                                    valueIdx++
                                })
                            })
                            console.log(this.roleList, '转发接收人')
                        }else {
                            this.$message.error(data.respData.respMsg);
                        }
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                }, data => {}, () => {
                    this.isLoading = true;
                }, () => {
                    this.isLoading = false;
                });
            }
        },
        mounted() {
        }
    };
</script>
<style lang="scss" scoped>
    .order-status {
        position: relative;
        height: 120px;
        margin: 0 0 20px;
        padding: 40px 20px 40px 80px;
        border: 1px solid #fddd74;
        background: url("../../../assets/images/order-detail-bg.jpg") no-repeat;
        background-size: 100% 100%;
    }
    .status-null {
        height: 30px;
    }
    .status-info {
        display: flex;
        justify-content: space-between;
        height: 100%;
        line-height: 25px;
    }

    .status-info-content {
        display: flex;
        justify-content: center;
        align-content: center;
        font-size: 14px;
        em{
            color: #444;
        }
        label {
            color: #888888;
        }

        a {
            color: #0082ff;
        }

        button {
            align-self: center;
        }
        & > div {
            display: inline-block;
            align-self: center;
        }

        .big {
            font-size: 18px;
            color: #333;
        }
        .confirm{
            position: absolute;
            right: 20px;
            bottom: 35px;
        }
        .operation{
            position: absolute;
            right: 60px;
            bottom: 35px;
        }
        .right20{
            right: 20px;
        }
        .right55{
            right: 55px;
        }
        .rejected-title{
            top: 34px;
            color: #bbb;
            display: inline-block;
            position: absolute;
            height: 70px;
            width: 900px;
            overflow-y: auto;
            word-wrap:break-word
        }
        // 转发
        .forward-container {
            position: absolute;
            right: 20px;
            top: 60px;
            &>i {
                background: url(../../../assets/images/forward-icon.png) no-repeat;
                cursor: pointer;
                display: block;
                width: 24px;
                height: 17px;
                padding-bottom: 32px;
            }
            ul {
                background: #fff;
                box-shadow: 0px 0px 12px #cacaca;
                border-radius: 2px;
                position: absolute;
                z-index: 1;
                margin-left: -72px;
                margin-top: 5px;
                padding-bottom: 22px;
                transition: all 3s linear;
                &::before {
                    content: '';
                    border-style: solid;
                    border-width: 10px;
                    border-color: transparent transparent #fff #fff;
                    box-shadow: -4px 7px 6px #eaeaea;
                    position: absolute;
                    transform: rotate(-223deg);
                    margin-top: -7px;
                    margin-left: 73px;
                }
                li {
                    display: flex;
                    align-items: center;
                    font-weight: bold;
                    cursor: pointer;
                    width: 130px;
                    padding: 22px 34px 0;
                    &.printing {
                        i {
                            background: url(../../../assets/images/printing-icon.png) no-repeat;
                        }
                    }
                    &.save {
                        i {
                            background: url(../../../assets/images/save-icon.png) no-repeat;
                        }
                    }

                    i {
                        background: url(../../../assets/images/printing-icon.png) no-repeat;
                        display: inline-block;
                        width: 15px;
                        height: 15px;
                        margin-right: 8px;
                    }
                }
            }
        }
    }
    /deep/ .el-button{
        height: 32px;
        width: 100px;
        padding: 0;
        span{
            text-align: center;
        }
    }
    /deep/ .el-dialog__header:before {
        height: 0;
    }
    .line-top{
        width: 95%;
        height: 1px;
        background: #eee;
        position: absolute;
        top:65px;
    }
    .form-btns {
        text-align: center;
    }
    .count{
        float: right;
        width: 100%;
        text-align: right;
        margin-bottom: 20px;
        span.red{
            color: #f00;
        }
    }
    .forward-dialog-container {
        padding-bottom: 30px;
        ::-webkit-scrollbar {
            width: 1px !important;
        }
        ::-webkit-scrollbar-button {
            height: 0;
        }
        /deep/ .el-select__tags {
            max-height: 85px;
            overflow: auto;
        }
        .head {
            display: flex;
            align-items: center;
            span {
                width: 10%;
            }
            /deep/ .el-select {
                width: 80%;
            }
            /deep/ input:focus {
                border: 0 !important;
            }
        }
        .body {
            margin-top: 22px;
            position: relative;
            /deep/ .el-textarea .el-textarea__inner {
                resize: none;
                width: 100%;
                height: 140px !important;
            }
            span {
                position: absolute;
                right: 9px;
                bottom: 6px;
            }
        }
        .foot {
            display: flex;
            justify-content: center;
            margin-top: 32px;
        }
    }

    // 流转意见
    .circulation-opinion-container {
        border: 1px solid #fddd74;
        padding: 20px;
        position: relative;
        margin-bottom: 22px;
        &.openOption {
            .option-circulation {
                &::after {
                    border-color: #0082ff #0082ff transparent transparent;
                    transform: rotate(-45deg);
                }
            }
        }
        .option-circulation {
            position: absolute;
            right: 16px;
            top: 21px;
            color: #0082ff;
            font-size: 12px;
            cursor: pointer;
            &::after {
                content: '';
                border-width: 3px;
                border-style: solid;
                display: inline-block;
                margin-left: 2px;
                border-color: #0082ff #0082ff transparent transparent;
                transform: rotate(135deg) translate(-3px, 1px);
            }
        }
        .center {
            display: flex;
            flex-direction: column;
            cursor: context-menu;
            .head-title {
                color: #444;
                font-size: 14px;
            }
            .center-option-circulation {
                width: 100%;
                height: 22px;
                position: relative;
                border-top: 1px solid #eeeeee;
                i {
                    left: 50%;
                    top: 17px;
                }
            }
            ul {
                margin-top: 12px;
                display: flex;
                flex-direction: column;
                min-height: 100px;
                &.isOpenOptionCirculation {
                    overflow: hidden;
                    height: 200px;
                    dd {
                        height: 40px;
                        display: -webkit-box;
                        -webkit-box-orient: vertical;
                        -webkit-line-clamp: 2;
                        overflow: hidden;
                    }
                }
                &.one{
                    height: auto;
                }
                li {
                    padding: 20px 40px;
                    border-top: 1px solid #eeeeee;
                    display: flex;
                    position: relative;
                    &:last-child {
                        padding-bottom: 0;
                    }
                    &.isAgree {
                        dl {
                            &:nth-child(2), &:nth-child(3) {
                                dt {
                                    color: #e9171d;
                                }
                            }
                        }
                    }
                    dl {
                        color: #444;
                        font-size: 14px;
                        width: 20%;
                        &:nth-child(2) {
                            width: 20%;
                        }
                        &:nth-child(3) {
                            width: 60%;
                        }
                        .color888888 {
                            color: #888;
                            font-size: 12px;
                        }
                        .colore9171d {
                            color:  #e9171d;
                        }
                        dt {
                            margin-bottom: 6px;
                            font-weight: bold;
                        }
                        dd {
                            line-height: 22px;
                            word-wrap: break-word;
                        }
                    }
                    .option-circulation {
                        left: 50%;
                        top: 16px;
                    }
                }
            }
        }
    }
    /deep/.textareaContainer {
       .el-textarea__inner {
           min-height: 140px !important;
       }
    }
    /deep/.padding10Dialog {
        .form-btns {
            padding: 16px 0;
            border-top: 1px solid #eee;
        }
        .el-dialog__header {
            padding-top: 22px !important;
        }
        .el-textarea {
            margin: 10px 0 !important;
        }
    }
</style>


