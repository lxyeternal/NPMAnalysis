<template>
    <div>
        <!-- 取消合同 -->
        <el-dialog class="dialog" title="填写选择取消选型原因" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="50%" center :close-on-click-modal="false">
            <div>
                <el-form :model="cancelForm" label-width="100px">
                    <el-form-item label="取消原因" prop="label">
                        <el-select v-model="cancelForm.label" placeholder="请选择取消选型原因" style="width:100%;">
                            <el-option v-for="(option,index) in cancelReasonList" :key="index" :label="option" :value="option"></el-option>
                        </el-select>
                        <i class="error-info" v-if="showError&&!cancelForm.label">请选择取消选型原因</i>
                    </el-form-item>

                    <el-form-item prop="reason" v-if="cancelForm.label=='其他'">
                        <el-input type="textarea" v-model="cancelForm.reason" rows="8" placeholder="请输入..."></el-input>
                        <i class="error-info" v-if="showError&&!cancelForm.reason">请输入取消选型原因</i>
                    </el-form-item>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 120px" @click="handleConfirm">确定并取消选型</el-button>
                <el-button size="small" style="width: 120px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
const cancelForm = {
    label: "",
    reason: ""
};

const cancelReasonList = [
    "无理由取消选型",
    "合同信息填写错误，重新选型",
    "要货计划有变动，取消选型",
    "其他"
];

export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            order: {},
            orderNo: "",
            showError: false,
            cancelForm: Object.assign({}, cancelForm),
            cancelReasonList: [].concat(cancelReasonList)
        };
    },
    methods: {
        open(data) {
            this.order = data;
            this.orderNo = data.orderNo;
            this.showError = false;
            this.dialogVisible = true;
        },
        handleConfirm() {
            if (!this.cancelForm.label) {
                this.showError = true;
                return;
            } else if (
                this.cancelForm.label == "其他" &&
                !this.cancelForm.reason
            ) {
                this.showError = true;
                return;
            }
            this.cancelOrder();
        },
        cancelOrder() {
            let reason = this.cancelForm.label;
            if (reason == "其他") {
                reason = this.cancelForm.reason;
            }
            const orders = {
                orderNo: this.orderNo,
                cancelReason: reason
            };
            const params = {
                orders: [orders]
            };
            InterfaceService.cancelOrder(
                params,
                data => {
                    console.log(data);
                    if (data.respCode === "0000") {
                        this.dialogVisible = false;
                        if (
                            data.respData.confirmRst &&
                            data.respData.confirmRst[0].result == "1"
                        ) {
                            this.$emit("close",true);
                        } else {
                            data.respData.confirmRst &&
                                this.$message.error(
                                    data.respData.confirmRst[0].confirmMsg
                                );
                        }
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
.error-info {
    color: #f56c6c;
    font-size: 12px;
    line-height: 1;
    padding-top: 4px;
    position: absolute;
    top: 100%;
    left: 0;
}
</style>
