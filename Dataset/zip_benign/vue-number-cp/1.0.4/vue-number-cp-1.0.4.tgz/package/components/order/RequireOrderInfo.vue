<template>
  <div>
    <div class="order-info">
      <template v-if="!showOtherFile || showTotal">
        <el-row>
          <el-col :span="12">
            <p>
              <label>合同编号：</label>
              <template v-if="role == 'B'">{{orderInfo.clOrderNo}}/{{orderInfo.sybOrderNo}}</template>
              <template v-else>
                {{orderInfo.clOrderNo}}
              </template>
            </p>
          </el-col>
          <el-col :span="12">
            <p>
              <label>合同名称：</label>
              《{{orderInfo.contractName}}》
              <span class="blue-pointer" @click="handleGoOrderDetail">查看合同详情</span>
            </p>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <p>
              <label>要货单号：</label>{{orderInfo.requireNo}}
            </p>
          </el-col>
          <el-col :span="12">
            <p>
              <label>创建日期：</label>{{orderInfo.tradeTime}}
            </p>
          </el-col>
        </el-row>
        <el-row class="row-border" style="margin-top: 0;">
          <el-col :span="12">
            <p>
              <label>批次：</label>第{{orderInfo.requireBatchNo}}批次
            </p>
          </el-col>
          <el-col :span="12">
            <p>
              <label>要求到货日期：</label><span class="red">{{orderInfo.requireTimeFrom}}~{{orderInfo.requireTimeTo && orderInfo.requireTimeTo.substring(11,orderInfo.requireTimeTo.length)}}</span>
            </p>
          </el-col>
        </el-row>
        <template v-for="(corp,ind) in corpList">
          <div class="order-info-title" :key="ind + 'k1'">
            {{corp.title}}
            <span class="blue hand fs12" v-if="corp.role == '0' && (( userinfo.corpIdList.includes(orderDetailInfo.supplierId) && orderDetailInfo.constructionContent == '1') || (userinfo.corpIdList.includes(orderDetailInfo.purchaserId) && orderDetailInfo.constructionContent == '0'))" @click="handleEditStakeHolder('material',corp)">变更人员</span>
          </div>
          <el-row class="row-border" :key="ind + 'k2'">
            <el-col :span="12" v-for="(item,index) in computedRoleList(corp.role)" :key="index">
              <label>{{item.roleName}}:</label>
              <template v-if="item.acctName">
                {{item.acctName}}
                <template v-if="item.mobile">(Tel:<em>{{item.mobile | formatPhoneNumber('3 4 4')}}</em>)</template>
                <DownloadAndView v-if="item.attachInfo" :attachUrl="item.attachInfo.attachUrl" :attachName="item.attachInfo.documentName"></DownloadAndView>
              </template>
              <template v-else>
                暂无
              </template>
            </el-col>
          </el-row>
        </template>
      </template>
      <template v-if="showLogisticsInfo">
        <div class="order-info-title">物流信息</div>
        <div>
          <el-row class="row-border" style="margin-top: 0;">
            <el-col :span="24">
              <p>
                <label>运送方式：</label> {{orderInfo.shippingMethod == '1' ? '第三方物流公司配送' : '供应商自行配送'}}
              </p>
            </el-col>
            <template v-if="orderInfo.shippingMethod=='1'">
              <el-col :span="12">
                <p>
                  <label>物流单号：</label>{{orderInfo.trackingNo}}
                </p>
              </el-col>
              <el-col :span="12">
                <p>
                  <label>物流公司：</label>{{orderInfo.expressName}}
                </p>
              </el-col>
            </template>
          </el-row>
        </div>
      </template>
      <template v-if="showOtherFile || showTotal">
        <PanelTitle v-if="fromDeliverGoods" title="附件"></PanelTitle>
        <div v-else class="order-info-title">附件</div>
        <div class="order-info-center">
          <p class="file-title" v-if="!(orderInfo.attachList && orderInfo.attachList.filter(i=> ['4', '3'].includes(i.attachType)).length)">暂无</p>
          <div class="other-container" v-if="orderInfo.attachList && orderInfo.attachList.filter(i=> ['4'].includes(i.attachType)).length">
            <p class="file-title">要货 - 其他附件<span class="blue-pointer" @click="handleBatchDownload('4')">下载</span></p>
            <div class="file-content">
              <p v-for="(file,ind) in orderInfo.attachList.filter(i=> i.attachType == '4')" :key="ind" :style="{'margin-bottom': ind === orderInfo.attachList.filter(i=> i.attachType == '4').length - 1 ? '0' : '10px'} ">
                {{file.attachName}}
                <DownloadAndView downloadName="下载" viewName="预览" :attachName="file.attachName" :attachUrl="file.attachUrl"></DownloadAndView>
              </p>
            </div>
          </div>
          <div class="other-container" v-if="orderInfo.attachList && orderInfo.attachList.filter(i=> ['3'].includes(i.attachType)).length">
            <p class="file-title">验收 - 其他附件<span class="blue-pointer" @click="handleBatchDownload('3')">下载</span></p>
            <div class="file-content">
              <p v-for="(file,ind) in orderInfo.attachList.filter(i=> i.attachType == '3')" :key="ind" :style="{'margin-bottom': ind === orderInfo.attachList.filter(i=> i.attachType == '3').length - 1 ? '0' : '10px'} ">
                {{file.attachName}}
                <DownloadAndView downloadName="下载" viewName="预览" :attachName="file.attachName" :attachUrl="file.attachUrl"></DownloadAndView>
              </p>
            </div>
          </div>
        </div>

      </template>
    </div>
    <UpdateStakeHolder ref="updateStakeHolder" @close="handleCloseUpdateStakeHolder"></UpdateStakeHolder>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import download from "@/utils/download";
import DownloadAndView from '@/components/order/DownloadAndView'
import PanelTitle from "@/components/base/PanelTitle";
import { InterfaceService } from '@/services/api'
import Loading from '@/components/base/Loading'
import UpdateStakeHolder from "@/components/order/dialog/UpdateStakeHolder";

export default {
  mixins: [accountMixin],
  // showLogisticsInfo 是否展示物流信息
  props: ["orderInfo", "showOtherFile", "fromDeliverGoods", 'showTotal', 'showLogisticsInfo'],
  components: {
    DownloadAndView,
    PanelTitle,
    Loading,
    UpdateStakeHolder,
  },
  data() {
    return {
      isLoading: false,
      roleList: [],
      documentInfoList: [],
      constructionStakeHolders: [], // 变更人员
      orderDetailInfo: {},
      corpList: [{
        title: '项目公司信息',
        role: '2'
      }, {
        title: '供应方信息',
        role: '3'
      }, {
        title: '施工单位',
        role: '0'
      },],
    };
  },
  computed: {
    // 采购商 - 事业部
    divisionContract() {
      return this.role == 'B'
    },
    computedRoleList() {
      return function (role) {
        return this.roleList.filter(item => {
          return item.role[0] === role
        })
      }
    }
  },
  watch: {
    orderInfo: {
      handler(val) {
        if (val) {
          if (!this.showOtherFile) {
            this.getOrderDetail()
          }
        }
      },
      deep: true
    }
  },
  methods: {
    handleCloseUpdateStakeHolder(bool) {
      if (bool) {
        this.$emit("refresh");
        this.getOrderDetail()
      }
    },
    handleEditStakeHolder(type,obj) {
      console.log(obj)
      let editRole = '';
      let fileTypeId = '';
      if (type == 'secondParty') {
        editRole = this.divisionContract ? '4' : '3'
        fileTypeId = 'authoritySupplier'
      } else if (type == 'firstParty') {
        editRole = this.divisionContract ? '2' : (this.orderDetailInfo.busiType === 'ONEWAY_ORDER' ? '2' : '4')
        fileTypeId = 'authorityPM'
      } else {
        editRole = '0'
        fileTypeId = 'authorityConstructor'
      }
      let roleList = [];
      if (editRole !== '0') {
        this.orderDetailInfo.contractStakeHolders && this.orderDetailInfo.contractStakeHolders.forEach(item => {
          if (item.role[0] === editRole && item.role[0] !== '0') {
            roleList.push(item)
          }
        });
      } else {
        //施工单位顺序根据constructionStakeHolders里面的数组进行排列，防止位置错乱
        this.constructionStakeHolders.forEach(item => {
          item.forEach(i => {
            roleList.push(i)
          })
        })
      }
      roleList.forEach(item => {
        if (item.role[0] == '2' && !item.corpId) {
          item.corpId = this.orderDetailInfo.purchaserId
        }
        if (item.role == '00') {
          if (this.orderDetailInfo.constructionContent == '1') {
            this.documentInfoList.forEach(_item => {
              if (_item.documentType === fileTypeId) {
                item.uploadFile = {
                  attachName: _item.documentName,
                  viewUrl: _item.attachUrl,
                  businessType: "CONTRACT_FORMATION",
                  fileTypeId: _item.documentType,
                  corpId: _item.corpId || "",
                  attachUrl: _item.documentUrl,
                  corpName: _item.documentUrl,
                }
              }
            });
          } else {
            this.documentInfoList.forEach(_item => {
              if (_item.documentType === fileTypeId && item.corpId === _item.corpId) {
                item.uploadFile = {
                  attachName: _item.documentName,
                  viewUrl: _item.attachUrl,
                  businessType: "CONTRACT_FORMATION",
                  fileTypeId: _item.documentType,
                  corpId: _item.corpId || "",
                  attachUrl: _item.documentUrl,
                }
              }
            });
          }
        } else if (item.role == '30' || item.role == '21') {
          this.documentInfoList.forEach(_item => {
            console.log(_item.documentType, fileTypeId);
            if (_item.documentType === fileTypeId) {
              console.log(item);
              item.uploadFile = {
                attachName: _item.documentName,
                viewUrl: _item.attachUrl,
                businessType: "CONTRACT_FORMATION",
                fileTypeId: _item.documentType,
                corpId: _item.corpId || "",
                attachUrl: _item.documentUrl,
              }
            }
          });
        }
      });
      console.log(roleList, '--- 传入');
      console.log(editRole, 'editRole 传入');
      // secondParty 乙方 不传 purchaserId
      this.$refs["updateStakeHolder"].open(roleList, editRole, fileTypeId, this.orderDetailInfo.orderStatus, type == 'secondParty' ? '' : type == 'material' ? this.orderDetailInfo.supplierId : this.orderDetailInfo.purchaserId, this.orderDetailInfo);
    },
    handleBatchDownload(attachType) {
      let fileInfoBeans = []
      this.orderInfo.attachList.filter(i => { return i.attachType == attachType }).forEach(item => {
        fileInfoBeans.push({
          archivePath: item.attachName,
          fileUrl: item.attachUrl,
        })
      });
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            const files = [
              { name: `${this.orderInfo.contractName}${attachType == '3' ? '验收' : '要货'}附件.zip`, url: url }
            ];
            this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
              this.$message.success("已下载");
            });
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    handleGoOrderDetail() {
      window.open(this.$router.resolve({
        path: '/orderDetail',
        query: {
          orderNo: this.orderInfo.orderNo
        }
      }).href, '_blank')
    },
    // 过滤角色
    filterRole(list = []) {
      const roles = ["00", "10", "21", "30"];
      return list.filter(item => {
        return roles.indexOf(item.role) !== -1;
      });
    },
    operateText(type) {
      let oper = "";
      if (this.orderInfo.requireOperFlow) {
        this.orderInfo.requireOperFlow.forEach(flow => {
          if (flow.operType == type) {
            oper = flow.operAcctName;
          }
        });
      }
      return oper;
    },
    handleDownload(url, name) {
      const x = new XMLHttpRequest();
      x.open("GET", url, true);
      x.responseType = "blob";
      x.onload = e => {
        download(x.response, `${name}.pdf`, x.response.type);
      };
      x.send();
    },
    getOrderDetail() {
      const params = {
        orderNo: this.orderInfo.orderNo,
      };
      InterfaceService.getOrderDetail(
        params,
        data => {
          let res = data.respData;
          this.orderDetailInfo = res
          if (res.respCode === "0000") {
            this.documentInfoList = data.respData.documentInfoList || [];
            this.roleList = []
            let contractStakeHolders = this.orderInfo.contractStakeHolders || [];
            this.roleList.unshift({
              roleName: '采购商名称',
              acctName: this.orderInfo.purchaserName,
              role: '2',
            }, {
                roleName: '施工单位',
                acctName: contractStakeHolders.find(i => { return i.role == '00' }) && contractStakeHolders.find(i => { return i.role == '00' }).corpName,
                role: '0',
              }, {
                roleName: '供应商名称',
                acctName: this.orderInfo.supplierName,
                role: '3',
              }, {
                roleName: '要货人',
                acctName: this.orderInfo.requireAcctName,
                mobile: this.orderInfo.requireAcctMobile,
                role: '200',
              }, {
                roleName: '发货人',
                acctName: this.orderInfo.deliverAcctName,
                mobile: this.orderInfo.deliverAcctMobile,
                role: '300',
              });
            let tempRoleList = ['28', '21', '29', '30', '33', '00', '01', '02']
            tempRoleList.forEach(role => {
              contractStakeHolders.forEach(item => {
                if (item.role === role) {
                  this.roleList.push({
                    roleName: item.roleName,
                    acctName: item.acctName,
                    role: item.role,
                    mobile: item.mobile,
                    corpId: item.corpId,
                  })
                }
              })
            })
            this.roleList.forEach(role => {
              if (role.role === '21') {
                role.attachInfo = this.documentInfoList.find(item => {
                  return item.documentType === 'authorityPM'
                })
              } else if (role.role === '30') {
                role.attachInfo = this.documentInfoList.find(item => {
                  return item.documentType === 'authoritySupplier'
                })
              } else if (role.role === '00') {
                role.attachInfo = this.documentInfoList.find(item => {
                  return item.documentType === 'authorityConstructor' && item.corpId === role.corpId
                })
              }
            })
            this.initConstructionStakeHolders()
          } else {
            this.$message.error(res.respMsg);
          }
        },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    initConstructionStakeHolders() {
      this.constructionStakeHolders = [];
      this.orderDetailInfo.contractStakeHolders && this.orderDetailInfo.contractStakeHolders.forEach((item, index) => {
        if (item.role[0] == '0') {
          if (item.role === '00') {
            this.constructionStakeHolders.push([item])
          }
        }
      });
      this.orderDetailInfo.contractStakeHolders && this.orderDetailInfo.contractStakeHolders.forEach((item, index) => {
        for (let i = 0; i < this.constructionStakeHolders.length; i++) {
          let ind = 0;
          let onOff = false
          this.constructionStakeHolders[i].forEach(con => {
            con.ind = i;
            if (con.corpId === item.corpId && item.role !== '00') {
              ind = i;
              onOff = true
            }
          });
          if (onOff) {
            item.ind = ind;
            this.constructionStakeHolders[ind].push(item)
          }
        }
      });
      this.constructionStakeHolders.forEach(item => {
        item = item.sort(this.compare)
      });

      console.log(this.constructionStakeHolders, '-constructionStakeHolders');

    },
  },
  mounted() {
    if (!this.showOtherFile) {
      this.getOrderDetail()
    }
  }
};
</script>

<style lang="scss" scoped>
.order-info {
  margin-bottom: 20px;
  line-height: 17px;
  font-size: 12px;
  /deep/ .el-col {
    margin-bottom: 10px;
  }
  p {
    word-break: break-word;
    white-space: normal;
    & > span {
      display: inline-block;
    }
  }

  label {
    white-space: nowrap;
    color: #888888;
  }
}

.order-info-title {
  margin: 5px -10px;
  margin-bottom: 20px;
  padding: 0 10px;
  font-size: 14px;
  border-left: 3px solid #000;
  line-height: 12px;
}

.receive-list {
  padding: 0 10px;
  p {
    line-height: 25px;
  }
}

.line {
  border-top: 1px solid #f5f5f5;
  margin-top: 20px;
  padding-bottom: 20px;
}
.row-border {
  margin-top: -10px;
  padding-bottom: 10px;
  border-bottom: 1px solid #eee;
}
.file-title {
  margin-top: -10px;
  margin-bottom: 6px;
  font-size: 14px;
  span {
    font-size: 12px;
    padding-left: 6px;
  }
}
.file-content {
  width: 1190px;
  line-height: 17px;
  border: 1px solid #dddddd;
  padding: 14px 10px;
  margin-bottom: 50px;
}
.required {
  &::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
.order-info-center {
  margin-top: 26px;
}
.fs12 {
  font-size: 12px;
}
</style>
