<template>
  <div>
    <el-dialog class="dialog" :title="`${subOrderNo ? '退回补充' : '拒绝'}合同${subOrderNo ? '原因' : ''}`" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="840px" center :close-on-click-modal="false" @close="close">
      <div>
        <el-form ref="rejectForm" :model="rejectForm" label-width="90px">
          <el-form-item :label="`${subOrderNo ? '退回' : '拒绝'}原因：`" prop="refuseReason" :rules="{required: true,message:`请填写${subOrderNo ? '退回' : '拒绝'}原因`}">
            <el-input type="textarea" class="resize-none" v-model="rejectForm.refuseReason" rows="4" maxlength="200" show-word-limit placeholder="请输入..."></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" class="normal-btn" :disabled="!rejectForm.refuseReason.trim()" @click="handleRejcet">{{subOrderNo ? '确认退回' : '拒绝'}}</el-button>
        <el-button class="normal-btn" @click="dialogVisible = false">取消</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

const rejectForm = {
  refuseReason: ""
};

export default {
  components: {
    Loading
  },
  data() {
    return {
      isLoading: false,
      dialogVisible: false,
      order: {},
      orderNo: '',
      rejectForm: Object.assign({}, rejectForm),

      subOrderNo: '',
    };
  },
  methods: {
    close() {
      this.rejectForm.refuseReason = '';
      this.$refs['rejectForm'].resetFields()
    },
    open(order, subOrderNo = '') {
      this.subOrderNo = subOrderNo

      this.order = order;
      this.orderNo = order.orderNo;
      this.rejectForm = Object.assign({}, rejectForm);
      this.dialogVisible = true;
    },
    handleRejcet() {
      this.$confirm(
        `确认${this.subOrderNo ? '退回' : '拒绝'}该${this.subOrderNo ? '补充' : ''}合同吗？确认请点击【确认${this.subOrderNo ? '退回' : '拒绝'}】`,
        `${this.subOrderNo ? '退回' : '拒绝'}${this.subOrderNo ? '补充' : ''}合同`,
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: `确认${this.subOrderNo ? '退回' : '拒绝'}`,
          cancelButtonText: '取消',
        }).then(() => {
          let params = {
            orderNo: this.subOrderNo || this.orderNo,
            refuseReason: this.rejectForm.refuseReason,
          };
          InterfaceService.cancelOrder(
            params,
            data => {
              let res = data.respData || {};
              if (data && data.respData && res.respCode === "0000") {
                this.dialogVisible = false;
                this.$message.success(`${this.subOrderNo ? '补充' : ''}合同已${this.subOrderNo ? '退回' : '拒绝'}！`);
                this.$emit("close", true)
              } else {
                this.$message.error(data.respData.respMsg)
              }
            }, data => {
              this.$message.error(data.respData.respMsg)
            }, () => {
              this.isLoading = true
            }, () => {
              this.isLoading = false
            })
        }).catch(() => {
        });
    },
  }
};
</script>

<style lang="scss" scoped>
.info {
  color: #888888;
}
.dialog {
  /deep/ .el-form-item {
    margin-bottom: 0;
  }
  /deep/ .el-form-item__label {
    padding-right: 6px !important;
    line-height: 17px;
  }
  /deep/ .el-dialog__footer {
    padding-top: 0 !important;
  }
}
.error-info {
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
  position: absolute;
  top: 100%;
  left: 0;
}
</style>
