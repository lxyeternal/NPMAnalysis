<template>
    <div class="content order-info">
        <!-- 待签署 -->
        <div class="unsign-info" v-if="filterUnsign().length">
            您待签署： {{filterUnsign().join('、')}}
        </div>

        <!-- 发货通知单签署情况 -->
        <div v-if="type=='1'">
            <el-row :gutter="10">
                <el-col :span="12" v-for="(item,index) in filterRole(roleList,'2')" :key="index+'0'">
                    <p class="role-title">{{item.label}}</p>
                    <div>
                        <el-row :gutter="2">
                            <el-col :span="12" v-for="(role,i) in item.children" :key="i">
                                <div class="role-content">
                                    <p>{{role.role|stakeHolderSign}}：
                                        <template v-if="role.acctId">
                                            <span :class="{'green': filterGreen(role)}">
                                                <i :class="filterIconName(role)"></i>{{showStatusText(role)}}</span>
                                        </template>
                                        <template v-if="!role.acctId">无</template>
                                    </p>
                                    <p v-if="role.acctId" class="person-info">{{role.custName}}
                                        <span v-if="filterShowMobile(role)">(Tel:{{role.mobile}})</span>
                                    </p>
                                </div>
                            </el-col>
                        </el-row>
                    </div>
                </el-col>
                <el-col :span="12" v-for="(item,index) in filterRole(roleList,'3')" :key="index+'1'">
                    <p class="role-title">{{item.label}}</p>
                    <div>
                        <el-row :gutter="2">
                            <el-col :span="12" v-for="(role,i) in item.children" :key="i">
                                <div class="role-content">
                                    <p>{{role.role|stakeHolderSign}}：
                                        <template v-if="role.acctId">
                                            <span :class="{'green': filterGreen(role)}">
                                                <i :class="filterIconName(role)"></i>{{showStatusText(role)}}</span>
                                        </template>
                                        <template v-if="!role.acctId">无</template>
                                    </p>
                                    <p v-if="role.acctId" class="person-info">{{role.custName}}
                                        <span v-if="filterShowMobile(role)">(Tel:{{role.mobile}})</span>
                                    </p>
                                </div>
                            </el-col>
                        </el-row>
                    </div>
                </el-col>
            </el-row>
        </div>
        <!-- 验收单签署情况 -->
        <div v-if="type=='2'">
            <el-row :gutter="20">
                <el-col :span="6" v-for="(item,index) in filterRole(roleList)" :key="index">
                    <el-row>
                        <p class="role-title">{{item.label}}</p>
                        <el-col :span="24" class="role-content" v-for="(role,_index) in item.children" :key="_index">
                            <p>{{role.role|stakeHolderSign}}：
                                <template v-if="role.acctId">
                                    <span :class="{'green': filterGreen(role)}">
                                        <i :class="filterIconName(role)"></i>{{showStatusText(role)}}</span>
                                </template>
                                <template v-if="!role.acctId">无</template>
                            </p>
                            <p v-if="role.acctId" class="person-info">{{role.custName}}
                                <span v-if="filterShowMobile(role)">(Tel:{{role.mobile}})</span>
                            </p>
                        </el-col>
                    </el-row>
                </el-col>
            </el-row>
        </div>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import {getSealRoles} from "@/utils/orderUtil";
const deliveryList = [
    {
        role: "2",
        label: "项目公司",
        children: [{ role: "21" }, { role: "25" }]
    },
    {
        role: "3",
        label: "供应方",
        children: [{ role: "30" }, { role: "33" }]
    }
];

const receiveList = [
    {
        role: "0",
        label: "要料施工单位",
        children: [{ role: "01" }, { role: "02" }]
    },
    {
        role: "1",
        label: "监理单位",
        children: [{ role: "10" }, { role: "11" }]
    },
    {
        role: "2",
        label: "项目公司",
        children: [{ role: "21" }, { role: "25" }]
    },
    {
        role: "3",
        label: "供应方",
        children: [{ role: "30" }, { role: "33" }]
    }
];

export default {
    mixins: [accountMixin],
    props: ["type", "order", "processList"],
    data() {
        return {
            roleList: []
        };
    },
    watch: {
        order() {
            this.init();
        },
        processList() {
            this.init();
        }
    },
    methods: {
        filterRole(list, role) {
            if (!role) return list;
            return list.filter(item => {
                return item.role == role;
            });
        },
        filterShowMobile(role) {
            const seals = getSealRoles();
            if (role.mobile && seals.indexOf(role.role) == -1) {
                return true;
            }
            return false;
        },
        showStatusText(item) {
            if (item.type == 0) {
                return item.processFlg == 1 ? "已盖章" : "待盖章";
            } else if (item.type == 1) {
                return item.processFlg == 1 ? "已签字" : "待签字";
            }
        },
        filterGreen(item) {
            let bool = false;
            if (item.type == 0) {
                bool = item.processFlg == 1;
            } else if (item.type == 1) {
                bool = item.processFlg == 1;
            }
            return bool;
        },
        filterIconName(item) {
            let icon = "";
            if (item.type == 0) {
                icon = item.processFlg == 1 ? "icon-seal-yes" : "";
            } else if (item.type == 1) {
                icon = item.processFlg == 1 ? "icon-check-yes" : "";
            }
            return {
                [icon]: true
            };
        },
        filterContractType(item) {
            const seals = getSealRoles();
            if (seals.indexOf(item.role) !== -1) {
                item.type = 0;
            } else {
                item.type = 1;
            }
            return item;
        },
        // 过滤待签署人
        filterUnsign() {
            const arr = [];
            const events = this.order.eventList || [];
            events.forEach(ev => {
                if (ev.eventType == this.type) {
                    const process = ev.processList || [];
                    process.forEach(item => {
                        if (
                             this.mxAcctIdList.includes(item.acctId) &&
                            item.processFlg == "0"
                        ) {
                            arr.push(item.roleName);
                        }
                    });
                }
            });
            return arr;
        },
        init() {
            if (this.type == "1") {
                this.roleList = this.$clone(deliveryList);
            } else if (this.type == "2") {
                this.roleList = this.$clone(receiveList);
            }

            let processList = [];
            if (this.processList) {
                processList = this.processList;
            } else if (this.order && this.order.eventList) {
                const events = this.order.eventList;
                events.forEach(ev => {
                    if (ev.eventType == this.type) {
                        processList = ev.processList || [];
                    }
                });
            }

            processList.forEach(process => {
                process = this.filterContractType(process);
            });

            this.roleList.forEach(item => {
                const children = [];
                item.children.forEach(_item => {
                    processList.forEach(process => {
                        if (_item.role === process.role) {
                            // children.push(process);
                            _item = Object.assign(_item,process)
                        }
                    });
                });
                // item.children = children;
            });
        }
    },
    mounted() {
        this.init();
    }
};
</script>

<style lang="scss" scoped>
.order-info {
    padding-top: 0;
    /deep/ .el-col {
        padding: 0;
    }
}

.content {
    margin: 20px 0;

    .role-content {
        min-height: 80px;
        margin-bottom: 2px;
        padding: 10px;
        background-color: #f5f5f5;

        .person-info {
            color: #888888;
        }

        i {
            margin-right: 3px;
            margin-bottom: 3px;
            vertical-align: middle;
            background-size: 100% 100%;
        }
    }
}

.role-title {
    font-weight: bold;
    padding: 0 10px;
    border-bottom: 1px solid #ececec;
    background-color: #f5f5f5;
}

.unsign-info {
    margin-bottom: 10px;
    padding: 0 5px 10px;
    border-bottom: 1px solid #ececec;
}
</style>
