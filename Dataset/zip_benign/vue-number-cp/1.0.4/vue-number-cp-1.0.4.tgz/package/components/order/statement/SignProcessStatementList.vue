<template>
    <div class="tl process-content" v-if="show">
        <div class="tc inline">对账单签署进度</div>
        <div class="tl inline" v-if="type==='pay'">供应方
            <el-tooltip v-for="(item,index) in vList" :key="index" effect="dark" :content="showTipText(item)" placement="top" :enterable="false">
                <i :class="filterIconName(item)"></i>
            </el-tooltip>
        </div>
        <div class="tl inline" v-if="type==='receive'">材料公司
            <el-tooltip v-for="(item,index) in mList" :key="index" effect="dark" :content="showTipText(item)" placement="top" :enterable="false">
                <i :class="filterIconName(item)"></i>
            </el-tooltip>
        </div>
        <div class="tl inline">采购方
            <el-tooltip v-for="(item,index) in pList" :key="index" effect="dark" :content="showTipText(item)" placement="top" :enterable="false">
                <i :class="filterIconName(item)"></i>
            </el-tooltip>
        </div>
    </div>
</template>

<script>
import { getSealRoles } from "@/utils/orderUtil";
export default {
    data() {
        return {
            show: false,
            pList: [], // 采购商
            vList: [], // 供应商
            mList: [] // 材料公司
        };
    },
    props: ["type", "order"],
    watch: {
        order() {
            this.init();
        }
    },
    methods: {
        showTipText(item) {
            // 盖章
            if (item.type == 0) {
                return item.roleName + (item.processFlg == 1 ? "已盖章" : "待盖章");
            } else if (item.type == 1) {
                // 签字
                return item.roleName + (item.processFlg == 1 ? "已签字" : "待签字");
            }
        },
        filterIconName(item) {
            let icon = "";
            if (item.type == 0) {
                icon = item.processFlg == 1 ? "icon-seal-yes" : "icon-seal-no";
            } else if (item.type == 1) {
                icon =
                    item.processFlg == 1 ? "icon-check-yes" : "icon-check-no";
            }
            return {
                [icon]: true
            };
        },
        // 区分盖章和签字角色
        filterContractType(item) {
            const seals = getSealRoles();
            if (seals.indexOf(item.role) !== -1) {
                item.type = 0;
            } else {
                item.type = 1;
            }
            return item;
        },
        init() {
            this.show = false;
            this.pList = [];
            this.vList = [];
            this.mList = [];
            let processList = [];
            let eventType = this.type === "pay" ? 3 : 4;
            if (this.order && this.order.eventList) {
                const events = this.order.eventList;
                events.forEach(ev => {
                    if (ev.eventType == eventType) {
                        // if (ev.eventStatus == 2) {
                        //     this.show = false;
                        // } else {
                            this.show = true;
                            processList = ev.processList || [];
                        // }
                    }
                });
            }
            processList.forEach(process => {
                process = this.filterContractType(process);
                // 筛选采购商
                if (process.role[0] == 2) {
                    this.pList.push(process);
                } else if (process.role[0] == 3) {
                    // 筛选供应商
                    this.vList.push(process);
                } else if (process.role[0] == 4) {
                    // 材料公司
                    this.mList.push(process);
                }
            });

            this.pList.sort((a, b) => {
                return b.role - a.role;
            });
            this.vList.sort((a, b) => {
                return b.role - a.role;
            });
            this.mList.sort((a, b) => {
                return b.role - a.role;
            });
        }
    },
    mounted() {
        this.init();
    }
};
</script>

<style lang="scss" scoped>
.process-content {
    padding: 5px;
    color: #888888;
}
.inline {
    display: inline-block;
    min-width: 150px;
    margin-right: 20px;
    padding: 0 10px;
    i {
        width: 20px;
        height: 20px;
        margin-left: 5px;
        vertical-align: middle;
    }
}
.inline:first-child {
    border-right: 2px solid #ffffff;
}
</style>
