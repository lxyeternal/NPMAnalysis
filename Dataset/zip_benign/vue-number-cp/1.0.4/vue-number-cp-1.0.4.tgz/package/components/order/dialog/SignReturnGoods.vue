<template>
    <div>
        <!-- 签收退货 -->
        <el-dialog class="dialog" title="签收退货" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="50%" center :close-on-click-modal="false">
            <div class="tc">请确认，您已收到退回货物，并签收</div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确定已签收</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            order: {},
            requireNo: ''
        };
    },
    methods: {
        open(data) {
            this.order = data;
            this.requireNo = data.requireNo;
            this.dialogVisible = true;
        },
        handleConfirm() {
            this.signReturnOrder();
        },
        signReturnOrder() {
            const params = {
                requireNo: this.requireNo
            };
            InterfaceService.signReturnOrder(
                params,
                data => {
                    console.log(data);
                    if (data.respCode === "0000") {
                        this.dialogVisible = false;
                        this.$emit('close',true);
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
</style>
