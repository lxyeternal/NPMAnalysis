<template>
    <!-- 对账单签署情况 -->
    <div class="content">
        <el-row class="role-row" :gutter="20" v-for="(item,index) in filterRole(roleList)" :key="index">
            <el-col>
                <p class="role-title" :class="{'vendor':item.role=='3','material':item.role=='4','purchase':item.role=='2'}">{{item.label}}</p>
            </el-col>
            <el-col :span="6" v-for="(role,_index) in item.children" :key="_index">
                <div class="role-content" :class="{'divide': _index!==item.children.length-1}">
                    <p>{{role.role|stakeHolderSign}}：
                        <template v-if="role.acctId">
                            <span :class="{'green': filterGreen(role)}">
                                <i :class="filterIconName(role)"></i>{{showStatusText(role)}}</span>
                        </template>
                        <template v-if="!role.acctId">无</template>
                    </p>
                    <p v-if="role.acctId" class="person-info">{{role.custName}}
                        <span v-if="filterShowMobile(role)">(Tel:{{role.mobile}})</span>
                    </p>
                </div>
            </el-col>
            <el-col>
                <hr>
            </el-col>
        </el-row>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import { getSealRoles } from "@/utils/orderUtil";
const payRoleList = [
    {
        role: "3",
        label: "供应商",
        children: [{ role: "30" }, { role: "33" }]
    },
    {
        role: "2",
        label: "城市公司",
        children: [
            { role: "21" },
            { role: "26" },
            { role: "27" },
            { role: "25" }
        ]
    }
];

const receiveList = [
    {
        role: "4",
        label: "材料公司",
        children: [{ role: "43" }, { role: "44" }]
    },
    {
        role: "2",
        label: "城市公司",
        children: [
            { role: "21" },
            { role: "26" },
            { role: "27" },
            { role: "25" }
        ]
    }
];

export default {
    mixins: [accountMixin],
    props: ["type", "statementInfo"],
    data() {
        return {
            eventType: 3,
            roleList: []
        };
    },
    watch: {
        statementInfo() {
            this.init();
        },
        processList() {
            this.init();
        }
    },
    methods: {
        filterRole(list, role) {
            if (!role) return list;

            return list.filter(item => {
                return item.role == role;
            });
        },
        filterShowMobile(role) {
            const seals = getSealRoles();
            if (role.mobile && seals.indexOf(role.role) == -1) {
                return true;
            }
            return false;
        },
        showStatusText(item) {
            if (item.type == 0) {
                return item.processFlg == 1 ? "已盖章" : "待盖章";
            } else if (item.type == 1) {
                return item.processFlg == 1 ? "已签字" : "待签字";
            }
        },
        filterGreen(item) {
            let bool = false;
            if (item.type == 0) {
                bool = item.processFlg == 1;
            } else if (item.type == 1) {
                bool = item.processFlg == 1;
            }
            return bool;
        },
        filterIconName(item) {
            let icon = "";
            if (item.type == 0) {
                icon = item.processFlg == 1 ? "icon-seal-yes" : "";
            } else if (item.type == 1) {
                icon = item.processFlg == 1 ? "icon-check-yes" : "";
            }
            return {
                [icon]: true
            };
        },
        filterContractType(item) {
            const seals = getSealRoles();
            if (seals.indexOf(item.role) !== -1) {
                item.type = 0;
            } else {
                item.type = 1;
            }
            return item;
        },
        // 过滤待签署人
        filterUnsign() {
            const arr = [];
            const events = this.statementInfo.eventList || [];
            events.forEach(ev => {
                if (ev.eventType == this.eventType) {
                    const process = ev.processList || [];
                    process.forEach(item => {
                        if (
                            this.mxAcctIdList.includes(item.acctId) &&
                            item.processFlg == "0"
                        ) {
                            arr.push(item.roleName);
                        }
                    });
                }
            });
            return arr;
        },
        init() {
            if (this.type === "pay") {
                this.eventType = 3;
                this.roleList = this.$clone(payRoleList);
            } else if (this.type === "receive") {
                this.eventType = 4;
                this.roleList = this.$clone(receiveList);
            }

            let processList = [];
            if (this.processList) {
                processList = this.processList;
            } else if (this.statementInfo && this.statementInfo.eventList) {
                const events = this.statementInfo.eventList;
                events.forEach(ev => {
                    if (ev.eventType == this.eventType) {
                        processList = ev.processList || [];
                    }
                });
            }

            processList.forEach(process => {
                process = this.filterContractType(process);
            });

            this.roleList.forEach(item => {
                const children = [];
                item.children.forEach(_item => {
                    processList.forEach(process => {
                        if (_item.role === process.role) {
                            _item = Object.assign(_item, process);
                        }
                    });
                });
            });
            console.log(this.roleList);
        }
    },
    mounted() {
        this.init();
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-col {
    padding: 0;
}

.content {
    margin: 20px 0;

    hr {
        border: none;
        border-bottom: 1px solid #ececec;
    }

    .role-content {
        min-height: 70px;
        margin-bottom: 2px;
        margin: 10px;
        margin-right: 0;
        line-height: 28px;
        // background-color: #f5f5f5;

        &.divide {
            border-right: 1px solid #ececec;
        }

        .person-info {
            color: #888888;
        }

        i {
            margin-right: 3px;
            margin-bottom: 3px;
            vertical-align: middle;
            background-size: 100% 100%;
        }
    }
}

.role-title {
    margin-top: 10px;
    padding: 15px;

    &.vendor {
        background: #a7d7af;
    }

    &.material {
        background: #ffc1b0;
    }

    &.purchase {
        background: #b7bdea;
    }
}
</style>
