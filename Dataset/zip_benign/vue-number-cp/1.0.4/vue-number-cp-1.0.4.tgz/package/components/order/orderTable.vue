<template>
  <div class="order-table-container">
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
      <thead>
        <tr>
          <!-- 表头 -->
          <th v-for="item in columnDefs" :key="item.field" :style="Object.assign({ width: item.w || '' , height: item.h || '', textAlign: item.align}, item.style)">
            <span>{{item.headerName}}</span>
          </th>
          <!-- 是否有传入操作按钮 -->
          <th :style="Object.assign({ width: operation.w || '' , height: operation.h || '', textAlign: operation.align}, operation.style)" v-if="Object.keys(operation).length">
            <span class="btn">{{operation.name || '操作'}}</span>
          </th>
        </tr>
      </thead>
      <tbody v-if="rowData && rowData.length">

        <tr v-for="(rItem, rIdx) in rowData" :key="rIdx">

          <td v-for="cItem in columnDefs" :key="cItem.field"
            :title="typeof cItem.filter === 'function' ? cItem.filter(rItem, rIdx) : rItem[cItem.field||0] | noDataPlaceholder"
            :style="Object.assign({ width: cItem.w || '' , height: cItem.h || '',
            textAlign: cItem.align}, cItem.style)">

            <!-- 是否进行 转换 html 过滤 -->
            <span v-if="!cItem.filterCellHtml">
              <!-- filter 进行字段过滤  -->
              {{(typeof cItem.filter === 'function' ? cItem.filter(rItem, rIdx) : rItem[cItem.field||0]) | noDataPlaceholder}}
            </span>

            <div v-else :title="cItem.filterCellHtml(rItem, rIdx).replace(/<[^>]*>/g, ' ')" v-html="cItem.filterCellHtml(rItem, rIdx)"></div>

          </td>
          <!-- 是否有传入操作按钮 -->
          <td :style="Object.assign({ width: operation.w || '' , height: operation.h || '', textAlign: operation.align}, operation.style)"
              :class="{disabled: typeof operation.disabled == 'function' ? operation.disabled(rItem, rIdx) : operation.disabled }"
              v-if="Object.keys(operation).length || (typeof operation.enable == 'function' ? operation.enable(rItem, rIdx) : operation.enable)">

            <!-- 点击按钮 返回当前数据下标和数据 -->
            <span v-for="(btnItem, btnIdx) in operation.btnList.filter(item => typeof item.rowBtnCellFilter === 'function' ? item.rowBtnCellFilter(rItem, rIdx) : true )" :key="btnIdx"
              :style="btnItem.rowBtnCellStyle && btnItem.rowBtnCellStyle(rItem, rIdx)||{}"
              @click="!(typeof btnItem.disabled == 'function' ? btnItem.disabled(rItem, rIdx) : btnItem.disabled) && !operation.disabled && btnItem.btnFn(rItem, rIdx)"
              :title="typeof btnItem.disabledNotice == 'function' ? btnItem.disabledNotice(rItem, rIdx) : btnItem.disabledNotice"
              :class="['btn', {
                  disabled:  typeof btnItem.disabled == 'function' ? btnItem.disabled(rItem, rIdx) : btnItem.disabled,
                  squareBtn: btnItem.isBtn,
                  primaryBgColor: btnItem.type === 'primary',
                  defaultBgColor: btnItem.type === 'default'}]">

                <p :style="btnItem.style">{{typeof btnItem.btnName === 'function' ? btnItem.btnName(rItem, rIdx) : btnItem.btnName  || ''}}</p>

            </span>

          </td>
        </tr>
      </tbody>
    </table>
    <div class="un-data-notice" v-if="rowData && !rowData.length">
      <img src="@/assets/images/icon-no-product.png">
      <p>{{unDataNotice}}</p>
    </div>
  </div>
</template>
<script>
export default {
  props: {
    // 列定义
    columnDefs: {
      type: Array,
      default() {
        return [{
          //   headerName: <string> 显示列名
          //   field: <string> 显示数据字段名
          //   filter: <function> 入参rItem&rIdx 过滤显示数据, 如数据 1: 男, 2: 女
          //   filterCellHtml: <function> 入参rItem&rIdx 过滤显示html, 自定义传入显示html内容
          //   w: <string> 宽
          //   h: <string> 高
          //   style: <object> 自定义样式 如: {width: '100px', height: '100px'}
        }]
      }
    },
    // 显示数据
    rowData: {
      type: Array,
      default() { return [] }
    },
    //  操作
    operation: {
      type: Object,
      default() {
        return {
          //  operation: <object>
          //  enable: <boolean || function> 入参rItem&rIdx 是否显示
          //  disabled: <boolean || function> 入参rItem&rIdx 是否可操作
          //  w: <string> 宽
          //  align: <string> 对齐方式
          //  rowBtnCellStyle: <function> 入参item&idx, 按钮 行样式
          //  rowBtnCellFilter: <function> 入参item&idx, 数据过滤
          //  btnList: <array>
          //      btnName: <string || function> 按钮名称
          //      btnFn: <function> callback 入参rItem&rIdx 返回当前行数据
          //      isBtn: <boolean> 是否为按钮  true 是  false 不是按钮(文字显示)
          //      type: <string> 按钮主题色  背景 <黄色 primary | 灰色default>
          //      style: <object> 按钮 自定义样式 如: {width: '100px', height: '100px'}
        }
      }
    },
    // 无数据提示信息
    unDataNotice: {
      type: String,
      default: '没有查询到相关数据！'
    }
  },
}
</script>
<style lang="scss" scoped>
%thTdBaseStyle {
  background: #f5f5f5;
  padding-left: 0;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  padding-left: 30px;
  font-size: 14px;
  text-align: left;
  border-bottom: 1px solid #eee;
  vertical-align: middle;
  font-family: "Helvetica Neue", Helvetica, Arial, "Hiragino Sans GB",
    "Hiragino Sans GB W3", "Microsoft YaHei UI", "Microsoft YaHei",
    "WenQuanYi Micro Hei", sans-serif;
  &:first-child {
    padding-left: 6px;
  }
}
.order-table-container {
  border: 0;
  .disabled {
    color: #888 !important;
    cursor: no-drop !important;
  }
  table {
    table-layout: fixed;
    thead {
      tr {
        th {
          @extend %thTdBaseStyle;
          height: 54px;
          line-height: 54px;
          background-color: #f5f5f5;
          color: #888;
          span {
            &.btn {
              padding: 5px;
            }
          }
        }
      }
    }
    tbody {
      tr {
        &:hover {
          td {
            background: #e8f3fd;
          }
        }
        td {
          @extend %thTdBaseStyle;
          transition: all 0.3s linear;
          background-color: #fff;
          color: #444;
          overflow: hidden;
          line-height: 24px;
          font-size: 12px;
          padding-top: 10px;
          padding-bottom: 10px;
          & > span {
            display: block;
            white-space: normal;
            word-break: break-all;
            line-height: 20px;
          }
          .btn {
            display: inline-block;
            white-space: nowrap;
            padding: 5px;
            line-height: 18px;
            color: #0082ff;
            font-size: 12px;
            text-align: right;
            cursor: pointer;
            outline: none;
            user-select: none;
            display: block;
            &.squareBtn {
              display: flex;
              justify-content: flex-end;
              p {
                color: #000;
                padding: 6px 12px;
                font-size: 12px;
                transition: all .3s linear;
                border: 1px solid transparent;
                text-align: center;
              }
              &.primaryBgColor {
                p {
                  background-color: #ffd64e;
                  border-color: #ffd64e;
                  &:hover {
                    background-color: #ecc43c;
                  }
                }
              }
              &.defaultBgColor {
                p {
                  border-color:#000;
                  background-color: #fff;
                  &:hover {
                    background-color: #eaeaea;
                  }
                }
              }
              &.disabled {
                p {
                  border-color: #eaeaea !important;
                  background-color: #eaeaea !important;
                  color: #888 !important;
                }
              }
            }
          }
        }
      }
    }
  }
  .un-data-notice {
    padding: 150px;
    text-align: center;
    line-height: 50px;
    color: #909399;
    p {
      font-size: 14px;
    }
  }
}
</style>


