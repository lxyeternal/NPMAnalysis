<template>
    <div>
        <!-- 供应商发起供货通知 -->
        <el-dialog class="dialog" title="供应商发起供货通知" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="840px" center :close-on-click-modal="false">
            <div>
                《{{order.contractName}}》第{{order.requireBatchNo}}批次要货单，供应商已备货完毕，准备发货，预计到货时间<span class="red">{{order.requireTimeFrom && order.requireTimeFrom.substring(0,19)}} ~ {{order.requireTimeTo && order.requireTimeTo.substring(11,order.requireTimeTo.length)}}</span>将货物送到指定地点。请确认是否发货？
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确认发货</el-button>
                <el-button size="small" style="width: 100px" @click="handleShowDelay">延缓发货</el-button>
            </div>
        </el-dialog>

        <!-- 延缓发货 -->
        <el-dialog class="dialog" title="延缓发货" :append-to-body="true" :lock-scroll="true" :visible.sync="delayDialogVisible" width="840px" center :close-on-click-modal="false">
            <div class="12">
                <i class="red">*</i>设置延缓到货时间：
                <el-date-picker v-model="date" type="date" :picker-options="dateOption" value-format="yyyy-MM-dd" placeholder="选择日期">
                </el-date-picker>
                <el-time-select v-model="time1" @change="handleChangeTime1" default-value="12:00" :picker-options="{
                      start: '00:00',
                      step: '01:00',
                      end: '23:00'
                    }" placeholder="选择时间">
                </el-time-select>
                <span>~</span>
                <el-time-select v-model="time2" default-value="12:00" :picker-options="{
                      start: '00:00',
                      step: '01:00',
                      end: '23:00',
                      minTime: time1
                    }" placeholder="选择时间">
                </el-time-select>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleDelay">确认延缓</el-button>
                <el-button size="small" style="width: 100px" @click="delayDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            delayDialogVisible: false,
            isDelay: '',
            order: {},
            dateOption: {},
            date: "",
            time1: "",
            time2: ""
        };
    },
    methods: {
        open(data, isDelay) {
            this.order = data;
            this.isDelay = isDelay;
            this.date = "";
            this.time1 = "";
            this.time2 = "";

            if (isDelay) {
                this.dateOption = {
                    disabledDate: now => {
                        return (
                            now.getTime() <
                            new Date(this.order.requireTimeTo.replace(/-/g,'/').slice(0, -2))
                        );
                    }
                };
                this.delayDialogVisible = true;
            } else {
                this.dialogVisible = true;
            }
        },
        handleConfirm() {
            this.sendOrder();
        },
        handleChangeTime1(val) {
            if (val > this.time2) {
                this.time2 = "";
            }
        },
        handleDelay() {
            if (!this.date || !this.time1 || !this.time2) {
                this.$message.error("请选择延期时间");
                return;
            }
            this.sendOrder();
        },
        handleShowDelay() {
          this.dateOption = {
            disabledDate: now => {
              return (
                now.getTime() <
                new Date(this.order.requireTimeTo.replace(/-/g,'/').slice(0, -2))
              );
            }
          };
            this.isDelay = 'isDelay'
            this.dialogVisible = false;
            this.delayDialogVisible = true;
        },
        sendOrder() {
          this.$confirm(
            "请再次确认是否" + (this.isDelay ?  '延缓发货':"发货"),
            this.isDelay ?  '延缓发货':"确认发货",
            {
              dangerouslyUseHTMLString: true,
              cancelButtonClass: "btn-custom-cancel",
              confirmButtonClass: "btn-custom-confirm",
              center: true,
              confirmButtonText: "确认",
              cancelButtonText: '取消',
            }).then(() => {
            const params = {
              requireNo: this.order.requireNo,
              isDelivery: this.isDelay ? "N" : "Y"
            };

            if (this.isDelay) {
              params.requireTimeFrom = this.date + " " + this.time1 + ":00";
              params.requireTimeTo = this.date + " " + this.time2 + ":00";
            }

            InterfaceService.sendOrderConfirm(
              params,
              data => {
                console.log(data);
                if (data.respCode === "0000") {
                  this.dialogVisible = false;
                  this.delayDialogVisible = false;
                  this.$emit("close", true);
                } else {
                  this.$message.error(data.respMsg);
                }
              },
              data => {},
              () => {
                this.isLoading = true;
              },
              () => {
                this.isLoading = false;
              }
            );
          }).catch(() => {
          })

        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
    /deep/ .el-input__inner{
        height: 32px;
        line-height: 32px;
    }
    /deep/ .el-input__icon{
        line-height: 35px;
    }
</style>
