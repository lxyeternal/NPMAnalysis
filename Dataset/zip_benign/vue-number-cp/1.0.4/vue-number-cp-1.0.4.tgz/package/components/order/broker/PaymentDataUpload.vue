<template>
    <div style="position: relative">
        <div class="data-content" ref="content">
            <table ref="table">
                <tbody class="head">
                    <tr>
                        <th width="80%"><em class="red">*</em>审批资料</th>
                        <th width="20%" style="text-align: right">操作</th>
                    </tr>
                </tbody>
                <div v-if="approvalList.length == 0 && waitApprovalList.length == 0 " class="f14 tl">
                    请先上传审批附件
                </div>
                <tbody>
                    <tr v-for="(item,index) in approvalList" :key="index" class="tbody-row">
                        <td width="80%">
                            <span class="blue pointer" @click="handleView(item.attachUrl)">{{item.attachName}}</span>
                        </td>
                        <td width="20%" style="text-align: right">
                            <span class="blue pointer" @click="handleDel(item,index)">删除</span>
                        </td>
                    </tr>
                    <tr v-for="(item,index) in waitApprovalList" :key="'wait'+index" class="tbody-row">
                        <td width="80%">
                            <span>{{item.attachName}}</span>
                        </td>
                        <td width="20%" style="text-align: right">
                            <span class="blue pointer" @click="handleDelWaitData(item,index)">删除</span>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <template>
            <div class="upload">
                <input id="paymentFile'" type="file" multiple  @change="handlePaymentUpload($event)">
                <label for="paymentFile'"><i class="el-icon-plus"></i>上传附件</label>
            </div>
        </template>
    </div>
</template>
<script>
    import Loading from "@/components/base/Loading";
    import { InterfaceService } from "@/services/api";
    import { viewFile } from '@/utils/orderUtil';
    import PanelTitle from "@/components/base/PanelTitle";
    import FixBottom from "@/components/base/FixBottom";
    import BrokerPaymentApproval from "@/components/order/broker/dialog/BrokerPaymentApproval";
    import ImprovePaymentInfo from "@/components/order/broker/dialog/ImprovePaymentInfo";
    export default {
        components: {
            Loading,
            PanelTitle,
            FixBottom,
            BrokerPaymentApproval,
            ImprovePaymentInfo,
        },
        props: ["orderNo","execAttachList","executionId","status","clearFiles"],
        data() {
            return {
                isLoading: false,
                fixedBottomActive:false,
                closeApproavlDialogVisible:false,
                cancleApproavlDialogVisible:false,
                startButton:false,
                approvalButton:false,
                canceledButton:false,
                contractApproveInfos: {},
                order:{},
                purchaserId:"",
                title:"",
                closeReason:"",
                entryNum:0,
                closeEntryNum:0,
                comment:"",
                approvalList:[],
                waitApprovalList:[],
                pmtBusiInfo:{},
            };
        },
        filters: {
            percent(val) {
                return (val * 100)+ "%";
            }
        },
        watch: {
            execAttachList(newVal) {
                this.init(newVal)
            },
            clearFiles(newVal) {
                console.log(newVal);
                if (newVal) {
                    this.waitApprovalList = []
                }
            },
            // executionId(newVal) {
            //     this.getApprovalDetail(newVal)
            // },
        },
        methods: {
            init(data) {
                console.log(data,"data");
                this.approvalList = data;
                this.$nextTick(function () {
                    window.addEventListener('scroll', this.onScroll)
                });
            },
            handleView(url) {
                if (url) {
                  viewFile(url)
                }
            },
            handleDel(item,index){
                this.$confirm(
                    "删除后将无法恢复文件，确认删除吗?",
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认",
                        cancelButtonText: '取消',
                    }).then(() => {
                        this.comfirmDel(item,index)
                    }).catch(() => {
                        this.$message({
                            type: 'info',
                            message: '已取消删除'
                        });
                    });
            },
            handleDelWaitData(item,index){
                this.$confirm(
                    "删除后将无法恢复文件，确认删除吗?",
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认",
                        cancelButtonText: '取消',
                    }).then(() => {
                    this.waitApprovalList.splice(index,1);
                    this.$emit("uplode",this.waitApprovalList);
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            comfirmDel(item,index) {
                let flowAttachIdList = [];
                flowAttachIdList.push(item.flowAttachId);
                const params = {
                    flowAttachIdList: flowAttachIdList
                };
                InterfaceService.approvalDataDel(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message({
                                type: 'success',
                                message: '删除成功!',
                            });
                            this.approvalList.splice(index,1);
                            // this.$emit("uplode",this.approvalList);
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handlePaymentUpload(e){
                const files = e.target.files;
                let upLoadList = [];
                for (let i in files) {
                    if (files[i].size) {
                        upLoadList.push({
                            attachName: files[i].name,
                            file: files[i]
                        });
                    }
                }
                e.value = "";
                this.getPaymentReceiptList(upLoadList).then(res => {
                    this.waitApprovalList = this.waitApprovalList.concat(res);
                    this.$emit("uplode",this.waitApprovalList);
                    console.log(this.waitApprovalList);
                    // this.approvalDataAdd(attachList);
                });
            },
            onScroll(){
                let scrolled = document.documentElement.scrollTop || document.body.scrollTop;
                this.fixedBottomActive = scrolled >= 400;
            },
            getPaymentReceiptList(upLoadList) {
                return new Promise((resolve, reject) => {
                    let arr = upLoadList;
                    this.uploadReciptToOss(arr).then(res => {
                        arr.forEach((item, index) => {
                            res.forEach(oss => {
                                if (index == oss.index) {
                                    item.attachUrl = oss.url;
                                }
                            });
                        });
                        resolve(arr);
                    });
                });
            },
            fillZero(val) {
                return val <= 9 ? "0" + val : val;
            },
            uploadReciptToOss(arr) {
                return new Promise((resolve, reject) => {
                    //去后端拿签名
                    InterfaceService.getOssSignature(
                        { type: "1" },
                        data => {
                            console.log(this.orderNo || this.executionId);
                            const promiseList = [];
                            arr.forEach((item, index) => {
                                const now = new Date();
                                const date = {
                                    y: now.getFullYear(),
                                    m: this.fillZero(now.getMonth() + 1),
                                    d: this.fillZero(now.getDate()),
                                    h: this.fillZero(now.getHours()),
                                    i: this.fillZero(now.getMinutes()),
                                    s: this.fillZero(now.getSeconds())
                                };
                                let dateStr = `${date.y}${date.m}${date.d}${
                                    date.h
                                    }${date.i}${date.s}`;
                                let dirName = `${
                                    this.orderNo || this.executionId
                                    }/approveFiles/${dateStr}/`;
                                const promise = new Promise(_resolve => {
                                    this.uploadHander(
                                        data,
                                        index,
                                        item.file,
                                        dirName,
                                        (pos, file, dir, signature) => {
                                            let u = signature.dir + dir + file.name;
                                            _resolve({ index: index, url: u });
                                        }
                                    );
                                });
                                promiseList.push(promise);
                            });
                            Promise.all(promiseList).then(values => {
                                resolve(values);
                            });
                        },
                        data => {}
                    );
                });
            },
            uploadHander(data, pos, file, dirName, callBack) {
                InterfaceService.uploadToOss(data, file, dirName, pos, callBack);
            },
            approvalDataAdd(attachList){
                const params = {
                    executionId: this.executionId ,
                    attachList:attachList,
                };
                console.log(params);
                InterfaceService.approvalDataAdd(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$emit("refresh")
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
        },
        destroyed(){
            window.removeEventListener('scroll', this.onScroll)
        }
    };
</script>

<style lang="scss" scoped>
    .info {
        color: #888888;
    }
    .dialog {
        line-height: 25px;
    }
    .error-info {
        color: #f56c6c;
        font-size: 12px;
        line-height: 1;
        padding-top: 4px;
        position: absolute;
        top: 100%;
        left: 0;
    }
    .order-info-title {
        margin: 5px -10px;
        margin-bottom: 10px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
        text-align: left;
    }
    .data-content{
        position: relative;
        max-height: 330px;
        overflow-y: auto;
        table {
            table-layout: fixed;
            width: 100%;
            line-height: 23px;
            font-size: 12px;
            display: table;
            background: #f5f8f9;

            td,th {
                padding: 6px 10px;
                vertical-align: middle;
                word-break: break-word;
                text-align: left;
            }
            .head {
                font-size: 14px;
                text-align: left;
                white-space: nowrap;
                color: #909399;
                background: #f5f5f5;
                border-bottom: 1px solid #fff;
            }
            .tbody-row:hover {
                background: #e8f3fd;
            }
            tbody {
                text-align: center;
                display: block;
                width: 100%;
                tr {
                    display: table;
                    width: 100%;
                    table-layout: fixed;
                }
                td {
                    border-bottom: 1px solid #ebeef5;
                }
            }
        }

    }
    .pointer {
        cursor: pointer;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }

        .active {
            color: #ffd64e;
        }
    }
    .tax{
        width: 100%;
        vertical-align:baseline;
        margin-bottom: 20px;
        td{
            width: 33%;
            padding: 4px 10px;
            background: #f5f5f5;
            vertical-align:middle;
            text-align: left;
        }
    }
    .upload {
        width: 100%;
        height: 40px;
        line-height: 40px;
        background: #f5f5f5;
        border-top: 2px solid #fff;
        margin: 0 auto 20px;
        text-align: center;
        input {
            position: absolute;
            left: -9999px;
            width: 0px;
            height: 0px;
            overflow: hidden;
            opacity: 0;
        }

        label {
            cursor: pointer;
            color: #0082ff;
        }
    }
    /deep/ .el-dialog__body{
        padding-bottom: 0;
    }
    /deep/ .el-dialog__footer{
        padding-top: 0;
    }
    /deep/ .el-button{
        width: 100px;
    }
    .dialog-footer {
        margin: 20px auto 0;
    }
    .count{
        float: right;
        width: 100%;
        text-align: right;
        margin-bottom: 20px;
        span.red{
            color: #f00;
        }
    }
    .fix-bottom{
        width: 100%;
        margin: 0 auto;
        text-align: center;
    }
    .download{
        position: absolute;
        right: 10px;
        top: 12px;
    }
</style>
