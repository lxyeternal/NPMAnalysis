<template>
    <div class="borkerApprovalPrint">
        <div class="head">
            <img src="../../../assets/images/logo.png" alt=""/>
            <div class="title">
                <div class="top">
                    <p>上海博置对外付款审批</p>
                    <span>External Payment Approval</span>
                </div>
                <div class="bottom">
                    编号(ERP编号): {{approvalInfo.erpBusiCode}}
                </div>
            </div>
            <div class="body">
                <table width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            请款主题
                        </td>
                        <td w20 colspan="3">
                            {{approvalInfo.applyTheme}}
                        </td>
                    </tr>
                </table>
                <table class="mt0" width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            申请人
                        </td>
                        <td w8>
                            {{approvalInfo.signAcctName}}
                        </td>
                        <td w4 class="title">
                            部门
                        </td>
                        <td w8>
                            博置-工程部
                        </td>
                    </tr>
                </table>
                <table width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            合同名称
                        </td>
                        <td w20 colspan="3">
                            《{{approvalInfo.contractName}}》
                        </td>
                    </tr>
                    <tr>
                        <td w4 class="title">
                            合同编号
                        </td>
                        <td w20 colspan="3">
                            {{approvalInfo.orderNo}}
                        </td>
                    </tr>
                </table>
                <table class="mt0" width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            城市公司
                        </td>
                        <td w8>
                            {{approvalInfo.cityCompany}}
                        </td>
                        <td w4 class="title">
                            项目名称
                        </td>
                        <td w8>
                            {{approvalInfo.projectName}}
                        </td>
                    </tr>

                    <tr>
                        <td w4 class="title">
                            合同价款(不含税)
                        </td>
                        <td w8>
                            <p>{{approvalInfo.outContractFee | formatMoney}}元</p>
                            <p>{{capitalization(approvalInfo.outContractFee)}}</p>
                        </td>
                        <td w4 class="title">
                            税率
                        </td>
                        <td w8>
                            {{approvalInfo.orderTaxRateRange}}
                        </td>
                    </tr>
                    <tr>
                        <td w4 class="title">
                            合同价款(税后)
                        </td>
                        <td w8>
                            <p>{{approvalInfo.outContractFeeWithTax | formatMoney}}元</p>
                            <p>{{capitalization(approvalInfo.outContractFeeWithTax)}}</p>
                        </td>
                        <td w4 class="title">
                            税额
                        </td>
                        <td w8>
                            <p>{{approvalInfo.outContractTax | formatMoney}}元</p>
                            <p>{{capitalization(approvalInfo.outContractTax)}}</p>
                        </td>
                    </tr>
                </table>
                <table width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            开户名称
                        </td>
                        <td w8>
                            {{corpFinInfo.acctName}}
                        </td>
                        <td w4 class="title">
                            供应商开户银行
                        </td>
                        <td w8>
                            {{corpFinInfo.bankName}}
                        </td>
                    </tr>
                    <tr>
                        <td w4 class="title">
                            供应商开户行地址
                        </td>
                        <td w8>
                            {{corpFinInfo.bankAddr}}
                        </td>
                        <td w4 class="title">
                            供应商开户行行号
                        </td>
                        <td w8>
                            {{corpFinInfo.bankCode | formatCardNum}}
                        </td>
                    </tr>
                    <tr>
                        <td w4 class="title">
                            供应商银行账号
                        </td>
                        <td w8>
                            {{corpFinInfo.bankAcct | formatCardNum}}
                        </td>
                        <td w4 class="title">
                            供应商纳税人识别号
                        </td>
                        <td w8>
                            {{corpFinInfo.taxPayId}}
                        </td>
                    </tr>
                    <tr>
                        <td w4 class="title">
                            供应商联系人
                        </td>
                        <td w8>
                            {{corpFinInfo.contact}}
                        </td>
                        <td w4 class="title">
                            供应商联系方式
                        </td>
                        <td w8>
                            {{corpFinInfo.phoneNo | formatPhoneNumber("3 4 4")}}
                        </td>
                    </tr>
                </table>

                <table width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            付款单位
                        </td>
                        <td w20 colspan="3">
                            {{corpFinInfo.pmtCorpName}}
                        </td>
                    </tr>
                </table>
                <table class="mt0" width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            付款事由
                        </td>
                        <td w8>
                            {{approvalInfo.paymentType}}
                        </td>
                        <td w4 class="title">
                            合同结算金额
                        </td>
                        <td w8 v-if="pmtBusiInfo.orderAuditAmt">
                            <p>{{pmtBusiInfo.orderAuditAmt | formatMoney}}元</p>
                            <p>{{capitalization(pmtBusiInfo.orderAuditAmt)}}</p>
                        </td>
                        <td w8 v-else>
                            <p>--元</p>
                        </td>
                    </tr>
                    <tr v-if="approvalInfo.pmtMethod || approvalInfo.paymentDescribe">
                        <td w4 class="title">付款条款</td>
                        <td w20 colspan="3">
                            <p v-html="approvalInfo.pmtMethod || approvalInfo.paymentDescribe"></p>
                        </td>
                    </tr>
                </table>
                <table class="mt0" width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td w4 class="title">
                            本期产值
                        </td>
                        <td w8>
                            <p>{{pmtBusiInfo.thisOutputValue | formatMoney}}元</p>
                            <p>{{capitalization(pmtBusiInfo.thisOutputValue)}}</p>
                        </td>
                        <td w4 class="title">
                            累计完成产值
                        </td>
                        <td w8>
                            <p>{{pmtBusiInfo.totalOutputValue | formatMoney}}元</p>
                            <p>{{capitalization(pmtBusiInfo.totalOutputValue)}}</p>
                        </td>
                    </tr>
                    <tr>
                        <td w4 class="title">
                            累计已付
                        </td>
                        <td w8>
                            <p>{{pmtBusiInfo.totalPaidAmt | formatMoney}}元</p>
                            <p>{{capitalization(pmtBusiInfo.totalPaidAmt)}}</p>
                        </td>
                        <td w4 class="title">
                            累计应付
                        </td>
                        <td w8>
                            <p>{{pmtBusiInfo.totalPayablesAmt | formatMoney}}元</p>
                            <p>{{capitalization(pmtBusiInfo.totalPayablesAmt)}}</p>
                        </td>
                    </tr>
                    <tr>
                        <td w4 class="title">
                            累计应付未付款
                        </td>
                        <td w8>
                            <p>{{pmtBusiInfo.totalPayableAmt | formatMoney}}元</p>
                            <p>{{capitalization(pmtBusiInfo.totalPayableAmt)}}</p>
                        </td>
                        <td w4 class="title bold">
                            本次申请金额
                        </td>
                        <td w8>
                            <p>{{pmtBusiInfo.payablesAmtApply | formatMoney}}元</p>
                            <p>{{capitalization(pmtBusiInfo.payablesAmtApply)}}</p>
                        </td>
                    </tr>
                </table>
                <!--<table width="100%" border="0" cellpadding="0" cellspacing="1" v-if="pmtBusiInfo.thisReceiptAmt || pmtBusiInfo.totalReceiptAmt">-->
                    <!--<tr>-->
                        <!--<template v-if="pmtBusiInfo.thisReceiptAmt && !pmtBusiInfo.totalReceiptAmt">-->
                            <!--<td w4 class="title">-->
                                <!--本次发票金额-->
                            <!--</td>-->
                            <!--<td w20>-->
                                <!--<p>{{pmtBusiInfo.thisReceiptAmt | formatMoney}}元</p>-->
                                <!--<p>{{capitalization(pmtBusiInfo.thisReceiptAmt)}}</p>-->
                            <!--</td>-->
                        <!--</template>-->
                        <!--<template v-if="!pmtBusiInfo.thisReceiptAmt && pmtBusiInfo.totalReceiptAmt">-->
                            <!--<td w4 class="title">-->
                                <!--累计发票金额-->
                            <!--</td>-->
                            <!--<td w20 >-->
                                <!--<p>{{pmtBusiInfo.totalReceiptAmt | formatMoney}}元</p>-->
                                <!--<p>{{capitalization(pmtBusiInfo.totalReceiptAmt)}}</p>-->
                            <!--</td>-->
                        <!--</template>-->
                        <!--<template v-if="pmtBusiInfo.thisReceiptAmt && pmtBusiInfo.totalReceiptAmt">-->
                            <!--<td w4 class="title">-->
                                <!--本次发票金额-->
                            <!--</td>-->
                            <!--<td w8>-->
                                <!--<p>{{pmtBusiInfo.thisReceiptAmt | formatMoney}}元</p>-->
                                <!--<p>{{capitalization(pmtBusiInfo.thisReceiptAmt)}}</p>-->
                            <!--</td>-->
                            <!--<td w4 class="title">-->
                                <!--累计发票金额-->
                            <!--</td>-->
                            <!--<td w8>-->
                                <!--<p>{{pmtBusiInfo.totalReceiptAmt | formatMoney}}元</p>-->
                                <!--<p>{{capitalization(pmtBusiInfo.totalReceiptAmt)}}</p>-->
                            <!--</td>-->
                        <!--</template>-->
                    <!--</tr>-->
                <!--</table>-->
                <table width="100%" border="0" cellpadding="0" cellspacing="1">
                    <tr>
                        <td  w4 class="title">
                            附件
                        </td>
                        <td w20 colspan="3">
                            <p style="margin-bottom: 10px;" v-for="(item,index) in approvalInfo.execAttachList" :key="index">{{item.attachName}}</p>
                        </td>
                    </tr>
                </table>

                <ul>
                    <li><span>流转意见</span></li>
                    <!--<li>-->
                        <!--<dl>-->
                            <!--<dt>刘晓莉</dt>-->
                            <!--<dd class="color888">财务部</dd>-->
                        <!--</dl>-->
                        <!--<dl>-->
                            <!--<dt>审批通过</dt>-->
                            <!--<dd class="color888">2019-04-21 13:00:09</dd>-->
                        <!--</dl>-->
                        <!--<dl>-->
                            <!--<dt>审批意见：</dt>-->
                            <!--<dd>-->
                                <!--XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX-->
                            <!--</dd>-->
                        <!--</dl>-->
                    <!--</li>-->
                    <li  v-for="(item,index) in approvalInfo.execFlowList" :key="index" :class="{'isAgree': computedCirculationState(item).isAgree}">
                        <dl>
                            <dt>{{item.acctName}}</dt>
                            <dd class="color888888">{{item.roleName}}</dd>
                        </dl>
                        <dl>
                            <dt>{{computedCirculationState(item).state}}</dt>
                            <!--  -->
                            <dd class="color888888">{{item.finishTm}}</dd>
                        </dl>
                        <dl v-if="item.comment">
                            <dt>{{computedCirculationState(item).reason}}:</dt>
                            <dd :title="item.comment" v-html="item.comment.replace(/\n/g, '<br/>')"></dd>
                        </dl>
                    </li>
                </ul>
            </div>

            <div class="foot">
                编号(ERP编号): {{approvalInfo.erpBusiCode}}
            </div>
        </div>
    </div>
</template>

<script>
    import { capitalizationAmount } from '@/utils/moneyUtil';
    export default {
        props: ["approvalInfo","paymentInfo","pmtBusiInfo","corpFinInfo"],
        data() {
            return {
                data: []
            };
        },
        computed:{
            computedCirculationState() {
                return (item) => {
                    // item.isAgree === "Y" ? "审批意见" : "退回原因"
                    let result = {};
                    if (item.taskId === 'canceled') {
                        result.state = '撤回审批'
                        result.reason = '审批意见'
                    } else {
                        if (item.fwStatus == '1' || item.fwStatus == '2' ) {
                            result.state = item.fwStatus == '1' ? `转发${item.fwRoleName || ''}` : '批注'
                            result.reason =  item.fwStatus == '1' ? `转发内容` : '批注内容'
                        } else {
                            result.state = item.isAgree === "Y" ? "审批通过" : "审批退回"
                            result.reason = item.isAgree === "Y" ? "审批意见" : "退回原因"
                            result.isAgree = item.isAgree === "N"
                        }
                    }
                    return result
                }
            },

            capitalization(){
                return (item) =>{
                    let fuhao = "";
                    let text = item + "";
                    if (text.indexOf("-") > -1) {
                        item = text.replace("-", "");
                        fuhao = "负"
                    }
                    let money1 = new Number(item);
                    let monee = Math.round(money1 * 100).toString(10);
                    let leng = monee.length;
                    let monval = "";
                    for (let i = 0; i < leng; i++) {
                        monval = monval + capitalizationAmount.to_upper(monee.charAt(i)) + capitalizationAmount.to_mon(leng - i - 1)
                    }
                    return fuhao + capitalizationAmount.repace_acc(monval)
                }
            }
        },
        methods:{
        },
        mounted(){
            console.log(this.paymentInfo);
        }
    }
</script>

<style scoped lang="scss">
    .PageNext {
        page-break-before: always;
    }

    .borkerApprovalPrint {
        font-size: 10pt;
        min-height: 9.7cm;
        width: 28.4cm;
        margin-top: 42px;
        .head {
            text-align: center;
            position: relative;
            img {
                position: absolute;
                width: 135px;
                height: 58px;
                left: 10px;
            }
            .title {
                color: #000;
                .top {
                    p {
                        font-size: 16pt;
                        margin-bottom: 8px;
                    }
                    span {
                        font-size: 13pt;
                    }
                }
                .bottom {
                    margin-top: 22px;
                    text-align: right;
                }
            }
            .body {
                $borderStyle: 1px solid #bbb;
                margin-top: 14px;
                box-sizing: border-box;
                color: #000;
                table {
                    border-top: $borderStyle;
                    margin-top: 24px;
                    table-layout:fixed;
                    [h0] {
                        height: 0 !important;
                        overflow: hidden;
                        td {
                            height: 0;
                            padding: 0;
                            border: 0;
                        }
                    }
                    .ofa{
                        overflow: visible;
                        white-space:nowrap;
                    }
                    .bln{
                        border-left: none;
                    }
                    td {
                        padding: 5px;
                        border-left: $borderStyle;
                        border-bottom: $borderStyle;
                        font-size: 10pt;
                        text-align: left;
                        vertical-align: middle;
                        &.bold {
                            font-weight: bold;
                        }
                        &[w3] {
                            width: calc(1000px / 24 * 3);
                        }
                        &[w4] {
                            width: calc(1000px / 24 * 4);
                        }
                        &[w6] {
                            width: calc(1000px / 24 * 6);
                        }
                        &[w8] {
                            width: calc(1000px / 24 * 8);
                        }

                        &[w14] {
                            width: calc(1000px / 24 * 14);
                        }
                        &[w20] {
                            width: calc(1000px / 24 * 20);
                        }
                        &[colspan="3"] {
                            p {
                                word-wrap: break-word;
                                width: 849px;
                            }
                        }
                        &.w173 {
                            width: 173px;
                        }
                        &:last-child {
                            border-right: $borderStyle;
                        }
                        &.title {
                            background: #e7f3fc;
                        }
                        p {
                            &:last-child {
                                margin-top: 4px;
                            }
                        }
                        pre {
                            line-height: 20px;
                            white-space: pre-line;
                        }
                    }
                }
                ul {
                    margin-top: 22px;
                    border: $borderStyle;
                    padding: 20px;
                    display: table;
                    width: 100%;
                    li {
                        text-align: left;
                        font-size: 10pt;
                        color: #000;
                        display: table-row;
                        width: 100%;
                        & > span {
                            display: block;
                        }
                        &:first-child {
                            font-size: 12pt;
                            span {
                                margin-bottom: 11px;
                            }
                        }
                        dl {
                            padding: 12px 0;
                            display: table-cell;
                            border-top: $borderStyle;
                            width: 20%;
                            &:nth-child(2) {
                                width: 20%;
                            }
                            &:nth-child(3) {
                                width: 60%;
                            }
                            dt {
                                margin-bottom: 4px;
                            }
                            dd {
                                line-height: 18px;
                                word-break: break-all;
                            }
                        }
                        .color888 {
                            color: #888;
                        }
                    }
                }
                .mt0{
                    margin-top: 0;
                    border-top: 0;
                }
            }
        }
        .foot {
            text-align: right;
            margin-top: 22px;
        }
    }
</style>