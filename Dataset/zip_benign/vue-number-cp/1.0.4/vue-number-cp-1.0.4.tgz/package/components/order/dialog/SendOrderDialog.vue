<template>
    <div>
        <!-- 确认发货 -->
        <el-dialog class="dialog" title="确认发货" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="600px" center :close-on-click-modal="false">
            <div class="tc">
                <p>确认发货信息并通知采购商已发货？</p>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">发货</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false
        };
    },
    methods: {
        open(data) {
            this.dialogVisible = true;
        },
        handleConfirm() {
            this.$emit("close", true);
        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
</style>
