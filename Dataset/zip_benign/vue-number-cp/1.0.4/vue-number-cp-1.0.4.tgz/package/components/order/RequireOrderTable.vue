<template>
  <div>
    <div class="table">
      <!-- 列表 -->
      <table>
        <thead>
        <tr>
          <td v-if="position!='detail'" width="292">合同编号/合同名称</td>
          <!--<td v-if="position!='detail'" width="150">合同名称</td>-->
          <td width="160">要货单号</td>
          <td width="120">批次</td>
          <!--<td width="100" class="pointer" @click="handleSort(0)">批次-->
            <!--<i class="el-icon-d-caret" v-if="sortList[0]==0"></i>-->
            <!--<i class="el-icon-caret-top active" v-if="sortList[0]==1"></i>-->
            <!--<i class="el-icon-caret-bottom active" v-if="sortList[0]==2"></i>-->
          <!--</td>-->
          <td width="172" v-if="position!='detail'">
            <span v-if="role=='S'">
              <template v-if="isAgent">
                采购商
              </template>
              <template v-else>
                采购商/代理商
              </template>
            </span>
            <span v-if="role=='B'">供应商</span>
          </td>
          <!--<td class="pointer" @click="handleSort(1)">创建时间-->
            <!--<i class="el-icon-d-caret" v-if="sortList[1]==0"></i>-->
            <!--<i class="el-icon-caret-top active" v-if="sortList[1]==1"></i>-->
            <!--<i class="el-icon-caret-bottom active" v-if="sortList[1]==2"></i>-->
          <!--</td>-->
          <td width="96">创建时间</td>
          <td width="68">状态</td>
          <td width="112" class="tr">操作</td>
        </tr>
        </thead>

        <template v-if="data.length">
          <tbody v-for="(row,index) in data" :key="index" class="tbody-row">
          <tr :class="{'border-none':position!='detail'}" class="tl">
            <td v-if="position!='detail'">
              <p class="order-no">
                <template v-if="role === 'B'">{{row.clOrderNo}}/{{row.sybOrderNo}}</template>
                <template v-else>
                  {{row.clOrderNo}}
                </template>
              </p>
              <p class="order-no">{{row.contractName}}</p>
            </td>
            <td>
              <div class="order-no">{{row.requireNo}}</div>
            </td>
            <td>第{{row.requireBatchNo}}批次</td>
            <td v-if="position!='detail'">
              <span v-if="role=='S'">
                <template v-if="isAgent">
                  {{row.purchaserName}}
                </template>
                <template v-else>
                  <p class="order-no">采购商：{{row.purchaserName}}</p>
                  <p class="order-no">
                    <template v-if="row.corpId === userinfo.corpId">
                      厂家直销
                    </template>
                    <template v-else>
                      代理商：
                    {{row.supplierName}}
                    </template>
                  </p>
                </template>
              </span>
              <span v-if="role=='B'">{{row.supplierName}}</span>
            </td>
            <td>{{row.tradeTime|datetime}}</td>
            <td>
              <span v-if="role=='S'">{{row.sRequireStatusDisp}}</span>
              <span v-if="role=='B'">{{row.bRequireStatusDisp}}</span>
            </td>
            <td class="tr">
              <RequireListOperate :tab="tab" :order="row" @refresh="refreshData"></RequireListOperate>
            </td>
          </tr>
          <tr class="sign-content" v-if="position!='detail'">
            <td colspan="100">
              <SignProcessRequireList :order="row"></SignProcessRequireList>
            </td>
          </tr>
          <!--<tr v-if="row.requireStatus=='21' || row.requireStatus=='23' || row.requireStatus=='24' || row.requireStatus=='15'" class="error-msg">-->
          <tr v-if="['23','24','21','25'].includes(row.requireStatus) && row.comment" class="error-msg">
            <td :colspan="7" :class="{'fold':!row.foldFlag}">
              <span class="bold fl">{{row.requireStatus === '21' || row.requireStatus === '25'? '撤回' : '退回'}}{{row.requireStatus === '25'? '验收单' : '要货单'}}原因：</span>
              <span class="fl">{{row.comment}}</span>
              <span class="fr blue-pointer" @click="row.foldFlag = !row.foldFlag" >{{row.foldFlag ? '展开':'收起'}}
                <i v-if="row.foldFlag" class="el-icon-caret-bottom"></i>
                <i v-else class="el-icon-caret-top"></i>
              </span>
              <div class="fl" v-if="!row.foldFlag" style="margin-top: 10px;"><em class="grey">{{row.requireStatus === '21' || row.requireStatus === '25'? '撤回' : '退回'}}时间：</em>{{row.endTime}}</div>
              <div style="clear: both"></div>
            </td>
          </tr>
          <tr v-if="['06'].includes(row.requireStatus)" class="error-msg">
            <td :colspan="7">
              <span class="bold fl">要求延缓到货日期：</span>
              <span class="fl">{{row.comment}}</span>
              <div style="clear: both"></div>
            </td>
          </tr>
          </tbody>
        </template>
      </table>
    </div>

    <div class="table-pagination" v-if="showPagination&&data.length">
      <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize"
                     :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
      </el-pagination>
    </div>
  </div>
</template>

<script>
  import accountMixin from '@/mixins/account';
  import RequireListOperate from '@/components/order/RequireListOperate';
  import SignProcessRequireList from "@/components/order/SignProcessRequireList";
  import {InterfaceService} from "@/services/api";

  export default {
    mixins: [accountMixin],
    components: {
      RequireListOperate,
      SignProcessRequireList
    },
    props: ["tab","data", "pageIndex", "pageSize", "total", "showPagination", 'position'],
    data() {
      return {
        sortList: [0, 2, 0],
        isLoading: false
      };
    },
    methods: {
      // 分页
      handleCurrentChange(page) {
        this.$emit("currentChange", page);
        window.scrollTo(0, 0)
      },
      // 排序
      handleSort(index) {
        let arr = [].concat(this.sortList);
        this.sortList.forEach((item, i) => {
          if (index == i) {
            if (item == 0) {
              arr[i] = 2;
            } else if (item == 2) {
              arr[i] = 1;
            } else {
              arr[i] = 0;
            }
          } else {
            arr[i] = 0;
          }
        });
        this.sortList = arr;
        this.$emit("sortChange", this.sortList);
      },
      refreshData() {
        this.$emit("refresh");
      }
    },
    mounted() {
    }
  };
</script>

<style lang="scss" scoped>
  .pointer {
    cursor: pointer;
    &:hover {
      color: #0082ff;
    }
    &:active {
      color: #4c9cdd;
    }

    .active {
      color: #ffd64e;
    }
  }

  .table {
    /deep/ .el-button {
      font-size: 12px;
    }

    width: 100%;
    line-height: 23px;
    font-size: 12px;
    table {
      table-layout: fixed;
      width: 100%;
    }
    td {
      padding: 14px 10px;
      vertical-align: middle;
      word-break: break-word;
    }

    thead {
      text-align: left;
      white-space: nowrap;
      font-size: 14px;
      color: #888;
      background: #f9f9f9;
    }

    tbody {
      text-align: center;

      tr:hover {
        background: #e8f3fd;
      }

    }
    .tbody-row {
      &:hover {
        background: #e8f3fd;
        .sign-content {
          background: #f0f8ff;
        }
      }
      .sign-content {
        display: table-row;
        background: #f9f9f9;
        &:hover {
          display: table-row;
        }
        td {
          padding: 0;
          border-top: none;
        }
      }
    }

    tbody {
      text-align: center;
      /*tr:hover + tr.sign-content {*/
      /*display: table-row;*/
      /*}*/

      tr {
        border-bottom: 1px solid #ebeef5;
      }
      .border-none {
        border-bottom: none;
      }
    }
  }

  .table-pagination {
    margin: 50px 0 80px;
    text-align: center;
    color: #888888;
  }

  .order-no {
    height: 100%;
    // max-width: 180px;
    word-wrap: break-word;
    overflow: hidden;
  }

  .deliver-dialog {
    margin: 0 30px;
    text-align: left;
    /deep/ .el-input {
      width: 180px;
    }
  }

  .form-response-item {
    display: inline-block;
    margin-left: 10px;
    vertical-align: bottom;
    label {
      display: inline-block;
      vertical-align: middle;
      width: 79px;
    }
  }

  @media (max-width: 1300px) {
    .form-response-item {
      width: 100%;
      margin-top: 10px;
      margin-left: 0;
    }
  }
  .error-msg{
    line-height: 30px;
    td{
      padding: 0 10px;
      background: #FFE9EB;
      border: 1px solid #DB7575;
      height: 30px;
      span{
        &:nth-of-type(2) {
          width: 815px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          text-align: left;
        }
        &:last-child{
          width: 40px;
        }
      }
    }
    .fold{
      line-height: 17px;
      padding: 6px 10px;
      height: auto;
      span{
        &:nth-of-type(2) {
          width: 815px;
          /*overflow: hidden;*/
          text-overflow: ellipsis;
          white-space: normal;
        }
      }
    }
  }
</style>
