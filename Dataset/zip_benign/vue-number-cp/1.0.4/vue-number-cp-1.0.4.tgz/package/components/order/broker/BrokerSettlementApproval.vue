<template>
    <div>
        <!-- 取消合同 -->
        <el-dialog class="dialog" :title="title" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="60%" center :close-on-click-modal="false" @close="handleClear">
            <div>
                <template v-if="!justView">
                    <div class="order-info-title">合同名称：《{{approvalInfo.contractName}}》</div>
                    <div class="order-info-title">合同价款</div>
                    <table class="tax">
                        <tr>
                            <td>合同价款（不含税）：{{approvalInfo.outContractFee | formatMoney}}元</td>
                            <td>税率：{{approvalInfo.orderTaxRateRange}}</td>
                            <!--<td rowspan="2" align="center" class="add-tax">加价费率：<em class="red" style="font-size: 22px;">{{approvalInfo.addRate|percent}}</em></td>-->
                        </tr>
                        <tr>
                            <td class="bold">合同价款（含税）：<em class="red">{{approvalInfo.outContractFeeWithTax | formatMoney}}元</em></td>
                            <td>税额：{{approvalInfo.outContractTax | formatMoney}}元</td>
                        </tr>
                    </table>
                </template>
                <div class="order-info-title">
                    审批资料
                    <span class=" blue" v-if="justView" style="cursor: pointer;margin-left: 20px;" @click="handleBatchDownload()">下载</span>
                </div>
                <div class="data-content" ref="content">
                    <div v-if="approvalList == 0" class="f14 tl">
                        请先上传审批附件
                    </div>
                    <table ref="table" v-else>
                        <tbody class="head">
                            <tr>
                                <th width="80%">附件名称</th>
                                <th width="20%" style="text-align: right" v-if="!justView">操作</th>
                            </tr>
                        </tbody>
                        <tbody>
                            <tr v-for="(item,index) in approvalList" :key="index" class="tbody-row">
                                <td width="80%">
                                    <span class="blue pointer" @click="handleView(item.attachUrl)">{{item.attachName}}</span>
                                </td>
                                <td width="20%" style="text-align: right" v-if="!justView">
                                    <span class="blue pointer" @click="handleDel(item)" v-if="item.attachType !== 'differenceReport'">删除</span>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <template v-if="!justView">
                <div class="upload">
                    <input id="file'" name="file" type="file" @change="handleUpload($event)">
                    <label for="file'"><i class="el-icon-plus"></i>上传附件</label>
                </div>
                <el-input style="margin: 10px 0;" type="textarea" v-model="comment" placeholder="请填写审批意见,300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
                <div class="count">
                    <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
                </div>
            </template>
            <div slot="footer" class="dialog-footer" v-if="!justView">
                <el-button :disabled="approvalList == 0" type="primary" size="small" style="width: 120px" @click="handleComfirm">同意</el-button>
                <el-button size="small" style="width: 120px" @click="handleClear()">取消</el-button>
            </div>
            <div slot="footer" class="dialog-footer" v-if="justView" style="margin-top: 20px">
                <el-button size="small" style="width: 120px" @click="handleClear()">关闭</el-button>
            </div>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    import Loading from "@/components/base/Loading";
    import { InterfaceService } from "@/services/api";
    import { viewFile } from '@/utils/orderUtil';

    export default {
        components: {
            Loading
        },
        data() {
            return {
                isLoading: false,
                dialogVisible: false,
                contractApproveInfos: {},
                order:{},
                executionId:"",
                purchaserId:"",
                orderNo:"",
                title:"",
                entryNum:0,
                comment:"",
                justView:false,
                approvalList:[],
                approvalInfo:{},
            };
        },
        filters: {
            percent(val) {
                return (val * 100)+ "%";
            }
        },
        methods: {
            open(executionId,type) {
                this.executionId = executionId;
                if (type == "justView") {
                    this.justView = true;
                    this.title = "审批资料查看"
                } else {
                    this.justView = false;
                    this.title = "确认审批"
                }
                this.getApprovalDetail();
                this.dialogVisible = true;
                console.log(this);
            },
            handleView(url) {
                if (url) {
                    viewFile(url)
                }
            },
            handleComfirm(){
                const params = {
                    procDefKey:'CONTRACT_APPROVE_WF',
                    executionId:this.executionId,
                    comment : this.comment
                };
                InterfaceService.startApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("审批操作成功！");
                            this.$emit("close", true);
                            this.dialogVisible = false
                        } else if (data.respData.respCode === "TRANS0362") {
                            let str = data.respData.respMsg;
                            str = str.replace(/;/g, "<br>");
                            this.$alert(
                                str,
                                '错误信息',
                                {
                                    customClass: "alert-box",
                                    dangerouslyUseHTMLString: true,
                                    confirmButtonText: "知道了",
                                    callback: action => {}
                                }
                            );
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleClear(){
                this.dialogVisible = false;
                this.comment = "";
                this.entryNum = 0
            },
            handleDel(item){
                this.$confirm(
                    "删除后将无法恢复文件，确认删除吗?",
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认",
                        cancelButtonText: '取消',
                    }).then(() => {
                        this.comfirmDel(item);
                    }).catch(() => {
                        this.$message({
                            type: 'info',
                            message: '已取消删除'
                        });
                    });
            },
            comfirmDel(item) {
                let flowAttachIdList = [];
                flowAttachIdList.push(item.flowAttachId);
                const params = {
                    flowAttachIdList: flowAttachIdList
                };
                InterfaceService.approvalDataDel(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message({
                                type: 'success',
                                message: '删除成功!',
                            });
                            this.getApprovalDetail();
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleEntry(ev){
                this.entryNum = ev.length
            },
            handleBatchDownload() {
                if (this.executionId) {
                    const params = {
                        executionId: this.executionId,
                        procDefKey:'CONTRACT_APPROVE_WF'
                    };
                    InterfaceService.approvalDataDownload(
                        params,
                        data => {
                            if (data.respData.respCode === "0000") {
                                // window.opener.location.reload();
                                let packingUrl = data.respData.attachUrl || "";
                                if (!packingUrl){
                                    return
                                }
                                window.open(packingUrl, "_blank");
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        },
                        data => {},
                        () => {
                            this.isLoading = true;
                        },
                        () => {
                            this.isLoading = false;
                        }
                    )
                }
            },
            handleUpload(e){
                const file = e.target.files[0];
                let upLoadList = [];
                if (file) {
                    // const fileType = file.name.split(".")[1];
                    // const reg = /(png|jpg|jpeg|xls|xlsx|pdf)/i;
                    // if (!reg.test(fileType)) {
                    //     this.$message.error("请上传图片、PDF、EXCEL格式文件");
                    //     return;
                    // }
                    upLoadList.push({
                        attachName: file.name,
                        file: file
                    });
                    this.resetInputValue()
                    this.getReceiptList(upLoadList).then(res => {
                        let attachList = res;
                        delete attachList[0].file
                        this.approvalDataAdd(attachList);
                    });
                }
            },
            /**
             * 重置input value  防止 同一个文件连续提交 不触发 onchange事件
             */
            resetInputValue() {
                let isIE10 = false,
                    uploadInputs = document.getElementsByName('file') || []
                if (window.navigator.userAgent.indexOf('MSIE') >= 1) { // 判断ie10以及以下
                    isIE10 = true
                } else {
                    isIE10 = false
                }
                for (let i = 0, len = uploadInputs.length; i < len; i++) {
                    const element = uploadInputs[i];

                    if (isIE10) {
                        let form = document.createElement('form'),
                            beforInput = element.nextSibling,
                            parentInput = element.parentNode

                        form.appendChild(element)
                        form.reset()
                        parentInput.insertBefore(element, beforInput)
                    } else {
                        element.value = ''
                    }

                }
            },
            getReceiptList(upLoadList) {
                return new Promise((resolve, reject) => {
                    let arr = upLoadList;
                    this.uploadReciptToOss(arr).then(res => {
                        arr.forEach((item, index) => {
                            console.log(res);
                            res.forEach(oss => {
                                if (index == oss.index) {
                                    item.attachUrl = oss.url;
                                }
                            });
                        });
                        resolve(arr);
                    });
                });
            },
            fillZero(val) {
                return val <= 9 ? "0" + val : val;
            },
            uploadReciptToOss(arr) {
                return new Promise((resolve, reject) => {
                    //去后端拿签名
                    InterfaceService.getOssSignature(
                        { type: "1" },
                        data => {
                            const promiseList = [];
                            arr.forEach((item, index) => {
                                const now = new Date();
                                const date = {
                                    y: now.getFullYear(),
                                    m: this.fillZero(now.getMonth() + 1),
                                    d: this.fillZero(now.getDate()),
                                    h: this.fillZero(now.getHours()),
                                    i: this.fillZero(now.getMinutes()),
                                    s: this.fillZero(now.getSeconds())
                                };
                                let dateStr = `${date.y}${date.m}${date.d}${
                                    date.h
                                    }${date.i}${date.s}`;
                                let dirName = `${
                                    this.orderNo
                                    }/approveFiles/${dateStr}/`;
                                const promise = new Promise(_resolve => {
                                    this.uploadHander(
                                        data,
                                        index,
                                        item.file,
                                        dirName,
                                        (pos, file, dir, signature) => {
                                            let u = signature.dir + dir + file.name;
                                            _resolve({ index: index, url: u });
                                        }
                                    );
                                });
                                promiseList.push(promise);
                            });
                            Promise.all(promiseList).then(values => {
                                resolve(values);
                            });
                        },
                        data => {},
                        () => {
                            this.isLoading = true;
                        },
                        () => {
                            this.isLoading = false;
                        }
                    );
                });
            },
            uploadHander(data, pos, file, dirName, callBack) {
                InterfaceService.uploadToOss(data, file, dirName, pos, callBack);
            },
            approvalDataAdd(attachList){
                const params = {
                    executionId: this.executionId ,
                    attachList:attachList,
                };
                InterfaceService.approvalDataAdd(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.getApprovalDetail(scroll);   // 传入scroll判断是否滚动到底部
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            viewNewDate(){
                let height = this.$refs.table.offsetHeight;
                if (height > 300) {
                    this.$refs.content.scrollTop = this.$refs.table.scrollHeight;
                }
            },
            getApprovalDetail(scroll){
                const params = {
                    executionId: this.executionId ,
                    procDefKey:'CONTRACT_APPROVE_WF',
                    pageIndex:1
                };
                InterfaceService.getApprovalDetail(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.approvalInfo = data.respData;
                            this.approvalList = this.approvalInfo.execAttachList || [];
                            this.purchaserId = this.approvalInfo.purchaserId;
                            this.orderNo = this.approvalInfo.orderNo;
                            // 如果是添加附件后调用审批详情，则判断是否超过content高度，如果超过，则滚动到content底部，显示最新添加的附件。
                            if (scroll) {
                                setTimeout(()=>{
                                    this.viewNewDate()
                                },500);
                            }
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            }
        }
    };
</script>

<style lang="scss" scoped>
    .info {
        color: #888888;
    }
    .dialog {
        line-height: 25px;
    }
    .error-info {
        color: #f56c6c;
        font-size: 12px;
        line-height: 1;
        padding-top: 4px;
        position: absolute;
        top: 100%;
        left: 0;
    }
    .order-info-title {
        margin: 5px -10px;
        margin-bottom: 20px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
        text-align: left;
    }
    .data-content{
        max-height: 300px;
        overflow-y: auto;
        table {
            table-layout: fixed;
            width: 100%;
            line-height: 23px;
            font-size: 12px;
            display: table;
            background: #f5f8f9;

            td,th {
                padding: 6px 10px;
                vertical-align: middle;
                word-break: break-word;
                text-align: left;
            }
            .head {
                font-size: 14px;
                text-align: left;
                white-space: nowrap;
                color: #909399;
                background: #f5f5f5;
                border-bottom: 1px solid #fff;
            }
            .tbody-row:hover {
                background: #e8f3fd;
            }
            tbody {
                text-align: center;
                display: block;
                width: 100%;
                tr {
                    display: table;
                    width: 100%;
                    table-layout: fixed;
                }
                td {
                    border-bottom: 1px solid #ebeef5;
                }
            }
        }

    }
    .pointer {
        cursor: pointer;
        &:hover {
            color: #0082ff;
        }
        &:active {
            color: #4c9cdd;
        }

        .active {
            color: #ffd64e;
        }
    }
    .tax{
        width: 100%;
        vertical-align:baseline;
        margin-bottom: 20px;
        td{
            width: 40%;
            padding: 4px 10px;
            background: #fef4f3;
            vertical-align:middle;
            text-align: left;
        }
        .add-tax {
            width: 20%;
            border-left: 4px solid #fff;
            font-size: 14px;
            font-weight: bold;

        }
    }
    .upload {
        width: 100%;
        height: 40px;
        line-height: 40px;
        margin: 0 auto 20px;
        text-align: center;
        background: #f5f5f5;
        border-top: 2px solid #fff;
        input {
            position: absolute;
            left: -9999px;
            width: 0px;
            height: 0px;
            overflow: hidden;
            opacity: 0;
        }

        label {
            cursor: pointer;
            color: #0082ff;
        }
    }
    /deep/ .el-dialog__body{
        padding-bottom: 0;
    }
    /deep/ .el-dialog__footer{
        padding-top: 0;
    }
    /deep/ .el-button{
        width: 100px;
    }
    .count{
        float: right;
        width: 100%;
        text-align: right;
        margin-bottom: 20px;
        span.red{
            color: #f00;
        }
    }

</style>
