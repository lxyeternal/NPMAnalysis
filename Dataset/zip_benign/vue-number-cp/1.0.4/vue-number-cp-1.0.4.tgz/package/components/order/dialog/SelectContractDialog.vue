<template>
  <div v-if="selectContractForGoodsDialog">
    <el-dialog title="选择要货合同" :append-to-body="true" :lock-scroll="true" :visible.sync="selectContractForGoodsDialog" width="840px" center :close-on-click-modal="false">
      <div class="red tl">说明：能要货的合同为履行中未结算合同！</div>
      <ul class="drafts-list refuse-to-add">
        <li>
          <span class="title"><i class="required"></i>供应商：</span>
          <el-select popper-class="selectContractDialogSelectContainer" v-model="supplierSelectedValue" filterable placeholder="请输入选择供应商" @change="handleSupplierSelectedValueChange" :filter-method="handleGetSupplierValue">
            <el-option v-for="item in selectedList.filter(i=>{return i.checked})" :key="item.supplierName" :label="item.supplierName" :title="item.supplierName" :value="item.supplierName">
              <span>{{item.supplierName}}</span>
            </el-option>
          </el-select>
        </li>
        <li>
          <span class="title"><i class="required"></i>履行中的合同：</span>
          <el-select popper-class="selectContractDialogSelectContainer" v-model="contractSelectedObj.orderNo" filterable placeholder="请输入选择合同名称或输入合同编号搜索" @change="handleContractSelectedValueChange" :filter-method="handleGetNameValue">
            <el-option v-for="option in internalRefuseDialogOptions.filter(f => f.contractName && f.supplierName === supplierSelectedValue && f.checked)" :key="option.orderNo" :label="option.contractName" :title="option.contractName" :value="option.orderNo">
              <!--<span>{{ option.contractName }}</span>-->
            </el-option>
          </el-select>
        </li>
      </ul>

      <div slot="footer" class="dialog-footer">
        <el-button :disabled="!contractSelectedObj.orderNo" type="primary" class="normal-btn" @click="handleSelectContractConfirm">确认并提交</el-button>
        <el-button class="normal-btn" @click="selectContractForGoodsDialog = false">取消</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>

</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";

export default {
  name: "SelectContractDialog",
  components: {
    Loading
  },
  data() {
    return {
      selectContractForGoodsDialog: false,
      isLoading: false,
      contractSelectedValue: "",
      supplierSelectedValue: "",
      contractSelectedObj: {},
      internalRefuseDialogOptions: [],
      dataList: [],
      selectedList: [],
    }
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo || {}
    }
  },
  methods: {
    handleGetSupplierValue(val) {
      val = val.replace(/\s+/g, "")

      if (val) {
        this.selectedList.forEach(item => {
          item.checked = !!~item.supplierName.indexOf(val) || !!~item.supplierName.toUpperCase().indexOf(val.toUpperCase())
        })
      } else {
        this.selectedList.forEach(item => {
          item.checked = true
        })
      }
    },
    handleGetNameValue(val) {
      val = val.replace(/\s*/g, "");
      if (val) {
        this.internalRefuseDialogOptions.filter(f => f.contractName && f.supplierName === this.supplierSelectedValue).forEach(item => {
          item.checked = !!(item.contractName && !!~item.contractName.indexOf(val)) || !!(item.clOrderNo && !!~item.clOrderNo.indexOf(val) || !!(item.sybOrderNo && !!~item.sybOrderNo.indexOf(val)))
          console.log(item, item.checked);
        })
      } else {
        this.internalRefuseDialogOptions.filter(f => f.contractName && f.supplierName === this.supplierSelectedValue).forEach(item => {
          item.checked = true
        })
      }
      console.log(val);
    },
    // 我要货点击
    async open() {
      !(this.selectedList && this.selectedList.length) && await this.remoteSearchOrder()
      this.selectedList.forEach(item => {
        item.checked = true
      });
      this.supplierSelectedValue = ''
      this.contractSelectedObj = {}
      this.selectContractForGoodsDialog = true
    },
    // 合同名称 select
    handleContractSelectedValueChange(ev) {
      console.log(ev);
      this.internalRefuseDialogOptions.filter(f => f.contractName && f.supplierName === this.supplierSelectedValue).forEach(item => {
        item.checked = true
      })
      this.contractSelectedObj = this.internalRefuseDialogOptions.filter(f => f.orderNo === ev)[0];
      this.internalRefuseDialogOptions = this.$clone(this.dataList);
      this.internalRefuseDialogOptions.forEach(item => {
        this.$set(item, 'checked', true)
      })
      console.log(this.internalRefuseDialogOptions);
      console.log(this.contractSelectedObj);
    },
    handleSupplierSelectedValueChange(ev) {
      this.contractSelectedValue = '';
      this.contractSelectedObj = {}
      this.internalRefuseDialogOptions.forEach(f => f.checked = true)
    },
    // 查询供应商
    remoteSearchOrder() {
      return new Promise(resolve => {
        InterfaceService.searchSimpleOrderListLimit({
          searchKey: '',
          usage: "requireGoods"
        }, data => {
          if (data.respData.respCode == '0000') {
            this.dataList = data.respData.contractList || []

            this.selectedList = []
            this.dataList.forEach(f => {
              let onOff = false;
              this.selectedList.forEach(s => {
                if (s.supplierName === f.supplierName) {
                  onOff = true
                }
              })
              if (!onOff) {
                this.selectedList.push({
                  supplierName: f.supplierName,
                  checked: true,
                })
              }
            });
            // this.selectedList = [...new Set(this.selectedList)]
            this.internalRefuseDialogOptions = this.$clone(this.dataList);
            this.internalRefuseDialogOptions.forEach(item => {
              this.$set(item, 'checked', true)
            })
            resolve(data.respData.contractList || [])
          } else {
            this.$message.error(data.respData.respMsg);
          }
        }, data => {
        }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },
    // 我要货 确认
    handleSelectContractConfirm() {
      console.log(this.contractSelectedObj, '-contractSelectedObj');
      console.log(this.userInfo, '-this.userInfo');

      if (!(this.userInfo.acctIdList && this.userInfo.acctIdList.includes(this.contractSelectedObj.acctId))) {
        this.$message.error("您不是当前合同的项目部材料员，无法发起要货！");
        return
      }
      // const { href } = this.$router.resolve({
      //   path: "/launchGoods",
      //   query: {
      //     orderNo: this.contractSelectedObj.orderNo
      //   },
      // });
      // window.open(href, '_blank');
      this.$router.push({
        path: "/launchGoods",
        query: { orderNo: this.contractSelectedObj.orderNo }
      })
      // this.$router.push({
      //   path: "/LaunchGoodsNew",
      //   query: { orderNo: this.contractSelectedObj.orderNo }
      // })
      this.selectContractForGoodsDialog = false;
    },
  }
}
</script>

<style scoped lang="scss">
.refuse-to-add {
  li {
    font-size: 14px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 22px;
    span {
      &.title {
        color: #999;
        width: 15%;
        text-align: right;
      }
      &.disabled {
        border: 1px solid #ddd;
        background: #eaeaea;
        width: 86%;
        padding: 10px 12px;
      }
    }
    /deep/ .el-input__inner {
      height: 34px;
    }
    /deep/ input.el-select__input:focus {
      border: none !important;
    }
    /deep/ .el-select {
      width: 86%;
    }
    /deep/ .el-textarea {
      textarea {
        width: 86%;
        float: right;
      }
    }
  }
}
.required {
  &::before {
    content: "*";
    color: #f56c6c;
    margin-right: 4px;
  }
}
</style>
<style lang="scss">
.selectContractDialogSelectContainer {
  max-width: 680px;
}
</style>
