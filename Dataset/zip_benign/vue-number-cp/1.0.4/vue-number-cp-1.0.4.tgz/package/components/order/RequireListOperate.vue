<template>
  <div class="operate" :class="{isFixBottom: isFixBottom}" v-if="!isFixBottom || showOperateComputed">
    <template v-if="isConfirmSignature">
      <el-button :type="fromPage ? 'primary' : 'text'" :class="{'el-button--default':fromPage}" v-if="computedCurrentSign" @click="checkEventRole(1)=='unfinish' ? handleRequireDetail('1') : handleCreateRecipt(1)">{{checkEventRole(1)=='unfinish' ? '确认并签章' : '签署验收单'}}</el-button>
      <el-button v-if="!computedCurrentSign && !fromPage" :type="fromPage ? 'primary' : 'text'" :class="{'el-button--default':fromPage}" @click="handleRequireDetail('')">查看详情</el-button>
    </template>
    <template v-if="role=='B'&&!specialPurChaseRole && (userinfo.acctIdList && userinfo.acctIdList.includes(order.requireCreator))">
      <template v-if="order.requireStatus=='01' || order.requireStatus=='02'">
        <el-button :type="fromPage ? '' : 'text'" :class="{'el-button--default':fromPage}" @click="handleCancelRequireOrder('21')">撤回要货单</el-button>
      </template>
      <template v-if="tab == 1">
        <el-button :type="fromPage ? 'primary' : 'text'" :class="{'el-button--default':fromPage}" v-if="order.requireStatus=='19' || order.requireStatus=='21' || order.requireStatus=='23' || order.requireStatus=='24'" @click="handleEdit">编辑</el-button>
        <el-button :type="fromPage ? '' : 'text'" :class="{'el-button--default':fromPage}" v-if="order.requireStatus=='19'" @click="handleDelRequireOrder">删除</el-button>
        <el-button :type="fromPage ? '' : 'text'" :class="{'el-button--default':fromPage}" v-if="order.requireStatus=='21' || order.requireStatus=='23' || order.requireStatus=='24'" @click="handleCancelRequireOrder('22')">关闭要货</el-button>
      </template>
      <el-button :type="fromPage ? 'primary' : 'text'" :class="{'el-button--default':fromPage}" v-if="order.requireStatus=='04'" @click="handleSendOrderNoticeConfirmDialog()">确认发货通知</el-button>
      <el-button :type="fromPage ? '' : 'text'" :class="{'el-button--default':fromPage}" v-if="order.requireStatus=='04'" @click="handleSendOrderNoticeConfirmDialog('delay')">延缓发货</el-button>

      <el-button :type="fromPage ? 'primary' : 'text'" :class="{'el-button--default':fromPage}" v-if="order.requireStatus=='07'" @click="handleCreateRecipt(0)">创建验收单</el-button>
      <el-button :type="fromPage ? 'primary' : 'text'" :class="{'el-button--default':fromPage}" v-if="order.requireStatus=='25'" @click="handleCreateRecipt(0,'edit')">编辑验收单</el-button>
      <el-button :type="fromPage ? 'primary' : 'text'" :class="{'el-button--default':fromPage}" v-if="order.requireStatus=='15'" @click="handleCreateRecipt(0,'edit')">继续验收</el-button>
      <el-button :type="fromPage ? '' : 'text'" :class="{'el-button--default':fromPage}" v-if="order.requireStatus=='16' || order.requireStatus=='17'" @click="handleWithdrawDeliver">撤回验收单</el-button>
    </template>
    <template v-if="role=='S'&&!specialPurChaseRole && (order.corpId == userinfo.corpId || order.supplierId == userinfo.corpId)&&supplierMaterialman">
      <el-button :type="fromPage ? 'primary' : 'text'" :class="{'el-button--default':fromPage}" v-if="order.requireStatus=='03'||order.requireStatus=='06'" @click="handleSendOrderNoticeDialog">发货通知</el-button>
      <el-button :type="fromPage ? 'primary' : 'text'" :class="{'el-button--default':fromPage}" v-if="order.requireStatus=='05'" @click="handleDeliverDialog">发货</el-button>
    </template>
    <template v-if="isReview">
      <el-button v-if="!fromPage" :type="fromPage ? 'primary' : 'text'" :class="{'el-button--default':fromPage}" @click="handleRequireDetail('')">查看详情</el-button>
    </template>
    <!-- 手动提交要货单 -->
    <SubmitRequire ref="submitRequire" @close="handleCloseSubmitRequire"></SubmitRequire>

    <!-- 确认发货通知 -->
    <SendOrderNoticeConfirm ref="sendOrderNoticeConfirm" @close="handleCloseSendOrderNoticeConfirm"></SendOrderNoticeConfirm>

    <!-- 确认要货单 -->
    <RequireOrderConfirm ref="requireOrderConfirm" @close="handleCloseRequireOrderConfirm"></RequireOrderConfirm>

    <!-- 发货通知 -->
    <SendOrderNotice ref="sendOrderNotice" @close="handleCloseSendOrderNotice"></SendOrderNotice>

    <!-- 签收退货 -->
    <SignReturnGoods ref="signReturnGoods" @close="handleCloseSignReturnGoods"></SignReturnGoods>

    <!-- 收货 -->
    <TakeGoodsConfirm ref="takeGoodsConfirm" @close="handleCloseTakeGoodsConfirm"></TakeGoodsConfirm>

    <!-- 退货 -->
    <ReturnGoods ref="returnGoods" @close="handleCloseReturnGoods"></ReturnGoods>

    <!-- 批量签署验收单 -->
    <SignBatchRecipt ref="signBatchRecipt" @close="handleCloseSignBatchRecipt"></SignBatchRecipt>

    <!-- 物流信息 -->
    <logistics ref="logistics"></logistics>
    <RejectDialog ref="RejectDialog" rejectBtn="确认撤回" dialogTitle="撤回原因" rejectContent="请确认撤回该要货单，并填写撤回原因，点击【确认撤回】按钮。" @refuseReason="getRefuseReason"></RejectDialog>
    <RejectDialog ref="withdrawDialog" rejectBtn="确认撤回" dialogTitle="撤回原因" rejectContent="请确认撤回该验收单，并填写撤回原因，点击【确认撤回】按钮。" @refuseReason="getWithdrawReason"></RejectDialog>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Logistics from "@/components/order/Logistics";
import SignReturnGoods from "@/components/order/dialog/SignReturnGoods";
import TakeGoodsConfirm from "@/components/order/dialog/TakeGoodsConfirm";
import ReturnGoods from "@/components/order/dialog/ReturnGoods";
import SendOrderNoticeConfirm from "@/components/order/dialog/SendOrderNoticeConfirm";
import RequireOrderConfirm from "@/components/order/dialog/RequireOrderConfirm";
import SendOrderNotice from "@/components/order/dialog/SendOrderNotice";
import SubmitRequire from "@/components/order/dialog/SubmitRequire";
import SignBatchRecipt from "@/components/order/dialog/SignBatchRecipt";
import { InterfaceService } from "@/services/api"
import { filterEventByAcct } from '@/utils/orderUtil';
import RejectDialog from "@/components/base/dialog/RejectDialog";

export default {
  mixins: [accountMixin],
  components: {
    Logistics,
    SignReturnGoods,
    TakeGoodsConfirm,
    ReturnGoods,
    SendOrderNoticeConfirm,
    RequireOrderConfirm,
    SendOrderNotice,
    SubmitRequire,
    RejectDialog,
    SignBatchRecipt
  },
  props: ["order", "tab", "fromPage", "isFixBottom"],
  computed: {
    supplierMaterialman() {
      return this.userinfo.roleIds && this.userinfo.roleIds.some(i => {
        return i.roleId === '3011' || i.roleId === '3011'
      })
    },
    isConfirmSignature() {
      return this.order.requireStatus !== '19' && this.order.requireStatus !== '21' && this.order.requireStatus !== '23' && this.order.requireStatus !== '24' && (this.checkEventRole(1) == 'unfinish' || this.checkEventRole(2) == 'unfinish')
    },
    isReview() {
      console.log(this.order.requireStatus, '-this.order.requireStatus');
      const result =
        (!['19', '21', '23', '24', '25'].includes(this.order.requireStatus) && !(this.checkEventRole(1) == 'unfinish' || this.checkEventRole(2) == 'unfinish')) ||
        // 创建者，撤回的要货单，重新编辑提交，未签署情况下，这里列表应该是编辑/关闭/ --- 查看详情
        (['21', '23', '24'].includes(this.order.requireStatus) && this.role == 'B' && !this.specialPurChaseRole && this.userinfo.acctIdList.includes(this.order.requireCreator)) || (this.role == 'S' && ['21', '25'].includes(this.order.requireStatus))

      return result
    },
    showOperateComputed() {
      console.log('底部悬浮');
      const result =
        (this.isConfirmSignature &&
          (this.computedCurrentSign || (!this.computedCurrentSign && !this.fromPage))) ||
        (this.role == 'B' && !this.specialPurChaseRole && this.userinfo.acctIdList.includes(this.order.requireCreator)) ||
        (this.role == 'S' && !this.specialPurChaseRole && (this.userinfo.corpIdList.includes(this.order.corpId) || this.userinfo.corpIdList.includes(this.order.supplierId)))

      return result
    },
    // 是否 可继续验收
    isEditAcceptanceComputed() {
      return order => {
        let state = false
        if (this.userinfo.acctIdList.includes(order.requireCreator)) {
          order.eventList.some(s => {
            // 有 documentType = 02  且 processList 里 processFlg 全部为 0 的时候 才能编辑
            if (s.documentType == '02') {
              state = s.processList && s.processList.every(e => e.processFlg == '0')
            }
          })
          if (order.requireStatus == '15') {
            state = true
          }
        }

        return state
      }
    },
    computedCurrentSign() {
      let bool = false;
      let processList = [];
      if (this.order.requireStatus === '16') {
        let currentInfo = {};
        if (this.order && this.order.eventList && this.order.eventList.length) {
          let firstSignFlg = false;
          this.order.eventList.forEach(item => {
            if (item.eventType == 2) {
              item.processList.forEach(pro => {
                if (pro.role === '28' && pro.processFlg == '0') {
                  firstSignFlg = true;
                  currentInfo = pro
                }
                if (pro.processFlg == '0' && this.userinfo.acctIdList.includes(pro.acctId)) {
                  bool = true
                }
              })
            }
          })
          if (firstSignFlg) {
            return this.userinfo.acctIdList.includes(currentInfo.acctId)
          } else {
            return bool
          }
        }
      } else {
        let currentInfo = {};
        if (this.order && this.order.eventList && this.order.eventList.length) {
          this.order.eventList.forEach(item => {
            if (item.eventType == 1) {
              item.processList.forEach(pro => {
                if (pro.role === '28') {
                  pro.ind = 0
                } else if (pro.role === '21') {
                  pro.ind = 1
                } else if (pro.role === '29') {
                  pro.ind = 2
                } else if (pro.role === '30') {
                  pro.ind = 3
                } else if (pro.role === '33') {
                  pro.ind = 4
                }
                processList.push(pro)
              })
            }
          })
        }
        processList = processList.sort(this.compare)
        currentInfo = processList.find(pro => {
          return pro.processFlg == '0'
        }) || {};
        console.log(currentInfo);
        if (this.userinfo.acctIdList.includes(currentInfo.acctId)) {
          bool = true
        }
      }
      return bool
    }
  },
  methods: {
    compare(obj1, obj2) {
      let val1 = obj1.ind;
      let val2 = obj2.ind;
      if (val1 < val2) {
        return -1;
      } else if (val1 > val2) {
        return 1;
      } else {
        return 0;
      }
    },
    // 查看要货单详情
    handleRequireDetail(type) {
      if (type) {
        this.$router.push({
          path: "/requireOrderDetail",
          query: {
            requireNo: this.order.requireNo,
            orderNo: this.order.orderNo,
            corpId: this.order.corpId
          }
        });
      } else {
        const { href } = this.$router.resolve({
          path: "/requireOrderDetail",
          query: {
            requireNo: this.order.requireNo,
            orderNo: this.order.orderNo,
            corpId: this.order.corpId
          },
        });
        window.open(href, '_blank');
      }
      // this.$router.push({
      //     path: "/requireOrderDetail",
      //     query: {
      //         requireNo: this.order.requireNo,
      //         corpId: this.order.corpId
      //     }
      // });
    },
    // 手工提交要货单
    handleSubmitRequireDialog() {
      this.$refs["submitRequire"].open(this.order);
    },
    // 提交要货单完成
    handleCloseSubmitRequire(bool) {
      if (bool) {
        this.refreshData();
      }
    },
    // 确认发货通知
    handleSendOrderNoticeConfirmDialog(type) {
      this.$refs["sendOrderNoticeConfirm"].open(
        this.order,
        type == "delay"
      );
    },
    // 确认发货通知完成
    handleCloseSendOrderNoticeConfirm(bool) {
      if (bool) {
        this.$message.success('操作成功！')
        this.refreshData();
      }
    },
    // 确认要货单
    handleRequireOrderConfirm() {
      this.$refs["requireOrderConfirm"].open(this.order);
    },
    // 确认要货单完成
    handleCloseRequireOrderConfirm(bool) {
      if (bool) {
        this.$emit("refresh");
      }
    },
    handleDelRequireOrder() {
      this.$confirm(
        '是否确认删除该笔要货单？删除后将无法恢复。',
        '删除要货',
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: "确认删除",
          cancelButtonText: '取消',
        }).then(() => {
          let param = {
            requireNo: this.order.requireNo,
            orderNo: this.order.orderNo,
            requireOperFlg: 'Del',
          };
          InterfaceService.saveReuireOrderList(param, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              this.$message.success('删除成功！');
              this.$emit("refresh");
            } else {
              this.$message.error(data.respData.respMsg)
            }
          }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        }).catch(() => {

        });
    },
    handleCancelRequireOrder(type) {
      if (type == '21') {
        this.$refs.RejectDialog.open();
      } else {
        let str = "是否确认关闭《" + this.order.contractName + "》第" + this.order.requireBatchNo + "批次要货单？关闭后不再恢复，关闭后的要货单信息至<span class='blue'>【交易管理】-【材料管理】-【材料进场】-【已结束】</span>列表查看。"
        this.$confirm(
          str,
          '关闭要货',
          {
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: type == '21' ? true : false,
            dangerouslyUseHTMLString: true,
            confirmButtonText: "确认关闭",
            cancelButtonText: '取消',
          }).then(() => {
            this.confirmCancel(type, '关闭')
          }).catch(() => {

          });
      }
    },
    getWithdrawReason(reason) {
      let param = {
        deliveryNo: this.order.lastDeliveryNo,
        reason: reason,
      };
      InterfaceService.withdrawDeliver(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('撤回成功！');
          this.$emit("refresh");
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    getRefuseReason(refuseReason) {
      this.confirmCancel('21', '撤回', refuseReason)
    },
    confirmCancel(type, str, refuseReason) {
      let param = {
        requireNo: this.order.requireNo,
        operType: type,
        reason: refuseReason,
      };
      InterfaceService.cancelOrRejectRequire(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success(str + '成功！');
          this.$emit("refresh", type === '22' ? 'close' : '');
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 发货通知
    handleSendOrderNoticeDialog() {
      this.$refs["sendOrderNotice"].open(this.order);
    },
    // 发货通知完成
    handleCloseSendOrderNotice(bool) {
      if (bool) {
        this.$emit("refresh");
      }
    },
    // 发货弹窗
    handleDeliverDialog() {
      // if (this.fromPage) {
      //   this.$router.push({
      //     path: "/deliverGoods",
      //     query: {
      //       requireNo: this.order.requireNo,
      //       deliveryNo: this.order.lastDeliveryNo,
      //     },
      //   });
      // } else {
      //   const { href } = this.$router.resolve({
      //     path: "/deliverGoods",
      //     query: {
      //       requireNo: this.order.requireNo,
      //       deliveryNo: this.order.lastDeliveryNo,
      //     },
      //   });
      //   window.open(href, '_blank');
      // }

      this.$router.push({
        path: "/deliverGoods",
        query: {
          requireNo: this.order.requireNo,
          deliveryNo: this.order.lastDeliveryNo,
        },
      });
    },
    // 签收退货弹窗
    handleSignReturnDialog() {
      this.$refs["signReturnGoods"].open(this.order);
    },
    // 签收退货完成
    handleCloseSignReturnGoods(bool) {
      if (bool) {
        this.refreshData();
      }
    },
    // 收货弹窗
    handleHarvestDialog() {
      this.$refs["takeGoodsConfirm"].open(this.order);
    },
    // 收货完成
    handleCloseTakeGoodsConfirm(bool) {
      if (bool) {
        this.refreshData();
      }
    },
    // 退货弹窗
    handleReturnDialog() {
      this.$refs["returnGoods"].open(this.order);
    },
    // 退货完成
    handleCloseReturnGoods(bool) {
      if (bool) {
        this.$message.info("退货原因已提交，并已通知对方");
        this.refreshData();
      }
    },
    //撤回验收单
    handleWithdrawDeliver() {
      this.$refs.withdrawDialog.open();
    },
    // 创建验收单
    handleCreateRecipt(isElectronicSignature, type) {
      // if (this.fromPage) {
      //   this.$router.push({
      //     path: "/CheckGoods",
      //     query: {
      //       deliveryNo: this.order.lastDeliveryNo,
      //       requireNo: this.order.requireNo,
      //       isElectronicSignature,
      //       type,
      //     },
      //   })
      // } else {
      //   const { href } = this.$router.resolve({
      //     path: "/CheckGoods",
      //     query: {
      //       deliveryNo: this.order.lastDeliveryNo,
      //       requireNo: this.order.requireNo,
      //       isElectronicSignature,
      //       type,
      //     },
      //   });
      //   window.open(href, '_blank');
      // }

      this.$router.push({
          path: "/CheckGoods",
          query: {
            deliveryNo: this.order.lastDeliveryNo,
            requireNo: this.order.requireNo,
            isElectronicSignature,
            type,
          }
      });
    },
    // 编辑
    handleEdit() {
      // if (this.fromPage) {
      //   this.$router.push({
      //     path: "/LaunchGoods",
      //     query: {
      //       orderNo: this.order.orderNo,
      //       requireNo: this.order.requireNo,
      //       requireBatchNo: this.order.requireBatchNo,
      //     },
      //   });
      // } else {
      //   const { href } = this.$router.resolve({
      //     path: "/LaunchGoods",
      //     query: {
      //       orderNo: this.order.orderNo,
      //       requireNo: this.order.requireNo,
      //       requireBatchNo: this.order.requireBatchNo,
      //     },
      //   });
      //   window.open(href, '_blank');
      // }

      this.$router.push({
          path: "/LaunchGoods",
          query: {
              orderNo: this.order.orderNo,
              requireNo: this.order.requireNo,
              requireBatchNo: this.order.requireBatchNo,
          }
      });
    },
    // 查看物流
    handleLogistics() {
      this.$refs["logistics"].$emit("init", {
        expressCompany: this.order.expressCompany,
        trackingNo: this.order.trackingNo
      });
    },
    // 批量确认签章完成
    handleCloseSignBatchRecipt(bool) {
      if (bool) {
        this.$emit("refresh");
      }
    },
    refreshData() {
      this.$emit("refresh");
    },
    // 检查角色事件
    checkEventRole(type) {
      let status = null;
      if (this.order && this.order.eventList) {
        let acctIdList = [];
        if (this.userinfo.accountList.length) {
          this.userinfo.accountList.forEach(item => {
            acctIdList.push(item.acctId)
          });
        } else {
          acctIdList.push(this.acctId)
        }
        const events = filterEventByAcct(this.order.eventList, type, acctIdList);
        events.forEach(ev => {
          if (ev.eventType == type) {
            if (ev.processList && ev.processList.length) {
              status = status || "finish";
              ev.processList.forEach(process => {
                if (process.processFlg == 0) {
                  status = "unfinish";
                }
              });
            }
          }
        });
      }
      return status;
    }
  },
  mounted() {
  }
};
</script>

<style lang="scss" scoped>
/deep/ .a {
  margin-bottom: 5px;
}
.operate {
  a {
    margin-bottom: 5px;
    display: block;
    white-space: nowrap;
    line-height: 18px;
    color: #0082FF;
    &:last-of-type {
      margin-bottom: 0;
    }
  }
}
.el-button--default {
  width: 120px;
}
/deep/ .el-button--text {
  padding: 0;
  margin-left: 0;
  width: 100%;
  text-align: right;
  color: #0082FF !important;
  &:hover {
    color: #0082FF;
  }
}
.isFixBottom {
  position: fixed;
  bottom: 0;
  left: 0;
  z-index: 2000;
  width: 100%;
  padding: 11px 40px;
  background: rgba(49, 49, 49, 0.9);
  text-align: center;
}
</style>
