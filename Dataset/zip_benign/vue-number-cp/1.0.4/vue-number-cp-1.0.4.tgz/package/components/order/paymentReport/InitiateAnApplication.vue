<template>
  <div>
    <!-- 生成对账单 -->
    <el-dialog class="dialog" title="创建请款申请" :append-to-body="true" :before-close="beforeClose" :lock-scroll="true" :visible.sync="initiateAnApplicationDialogVisible" width="900px" center :close-on-click-modal="false">
      <div>
        <div class="card-content">
          <el-row :gutter="10">
            <el-col :span="3" :class="'title'">
              <i class="red">*</i><span>请款合同</span>
            </el-col>
            <el-col :span="21">
              <el-select clearable :size="'small'" :popper-class="'initiateAnapplicataionSelect'" @visible-change="contractListVisibleChange" v-model="selectedContractValue" filterable :placeholder="contractSelectPlaceholder" @change="handleContractChange" :filter-method="filterContractMethod" @focus="handleContractFocus" @blur="handleContractBlur">
                <el-option v-for="item in contractList" :key="item.value" :label="item.label" :value="item.value">
                  <span style="float: left">{{item.orderNo}}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{item.label}}</span>
                </el-option>
                <p class="page-container">
                  <el-pagination @current-change="handlePageCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="pageTotal" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>" />
                </p>
              </el-select>
            </el-col>
            <el-col :span="3" :class="'title'">
              <i class="red">*</i><span>请款事由</span>
            </el-col>
            <el-col :span="7">
              <el-select clearable :size="'small'" v-model="askForReasonsValue" placeholder="请选择请款事由" @change="askForReasonsChange">
                <el-option v-for="item in askForReasonsList" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-col>
            <el-col :span="7" v-if="askForReasonsValue == '1'">
              <el-select clearable :size="'small'" v-model="prepaymentsValue" placeholder="请选择预付款">
                <el-option v-for="item in prepaymentsList.filter(f=> isHadAdvance ? f.value != '1' : true)" :key="item.value" :label="item.label" :value="item.value">
                </el-option>
              </el-select>
            </el-col>
          </el-row>
          <el-row v-if="askForReasonsValue == '2'">
            <el-col :span="3" class="title">
              <i class="red">*</i><span>请款周期</span>
            </el-col>
            <el-col :span="7">
              <el-date-picker size="small" :picker-options="pickerOptionsStart" v-model="datePickerValueStart" type="date" placeholder="选择日期" @change="handleDatepickerChange">
              </el-date-picker>
            </el-col>
            <el-col :span="2" class="title">
              <span>&nbsp;&nbsp;开始~&nbsp;&nbsp;</span>
            </el-col>
            <el-col :span="7">
              <el-date-picker size="small" :picker-options="pickerOptionsEnd" v-model="datePickerValueEnd" type="date" placeholder="选择日期" @change="handleDatepickerChange">
              </el-date-picker>
            </el-col>
            <el-col :span="2" class="title">
              <span>&nbsp;&nbsp;结束&nbsp;&nbsp;</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="24" style="margin-top: 24px; text-align: center">
              <el-button style="width: 120px" size="small" type="primary" @click="handeleNextClick">下一步</el-button>
              <el-button style="width: 120px" size="small" @click="beforeClose">取消</el-button>
            </el-col>
          </el-row>
        </div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>

import Loading from "@/components/base/Loading"
import { InterfaceService } from "@/services/api"
import { mapActions, mapState } from 'vuex'

export default {
  components: { Loading },
  props: {
    initiateAnApplicationDialogVisible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      contractList: [], // 请款合同
      selectedContractValue: '', // 请款合同选择
      askForReasonsList: [], // 请款事由
      askForReasonsValue: '',
      prepaymentsList: [], // 预付款
      prepaymentsValue: '',
      isLoading: false,
      datePickerValueStart: '', // 开始时间
      datePickerValueEnd: '', // 开始时间
      searchTimer: null, // 搜索定时器
      isHadAdvance: false, // 是否出现过合同预付款
      pickerOptionsStart: {},
      pickerOptionsEnd: {},
      pageIndex: 1,
      pageSize: 5,
      pageTotal: 10,
      contractSelectPlaceholder: '请搜索选择合同'
    };
  },
  mounted() {
    this.init()
  },
  methods: {
    ...mapActions(['setInitiateAnapplicationBaseInfoAct']),
    async init() {
      await this.getApprovalId()
      this.askForReasonsList = [
        { value: '1', label: '预付款' },
        { value: '2', label: '进度款' }
      ]
      this.prepaymentsList = [
        { value: '1', label: '合同预付款' },
        { value: '2', label: '进场材料预付款' }
      ]
    },

    /**
     * 分页器改变
     */
    handlePageCurrentChange(page) {
      this.pageIndex = page;
      this.selectedContractValue = ''

      this.contractSelectPlaceholder = this.searchVal || '请搜索选择合同'
      this.getPaymentOrderList()
    },

    blur() {

    },

    /**
     * 时间选择
     */
    handleDatepickerChange() {
      const __this = this
      this.pickerOptionsStart = {
        disabledDate(time) {
          return !__this.datePickerValueEnd ? false : time.getTime() > new Date(__this.datePickerValueEnd)
        },
      }
      this.pickerOptionsEnd = {
        disabledDate(time) {
          return !__this.datePickerValueStart ? false : time.getTime() < new Date(__this.datePickerValueStart)
        },
      }

    },

    /**
     * 下一步 点击
     */
    handeleNextClick() {
      if (!this.selectedContractValue) {
        this.$message.error('请选择请款合同')
        return
      }
      if (!this.askForReasonsValue) {
        this.$message.error('请选择请款事由')
        return
      }
      if (this.askForReasonsValue === '1' && !this.prepaymentsValue) {
        this.$message.error('请选择预付款')
        return
      }
      if (this.askForReasonsValue === '2' && !this.datePickerValueStart) {
        this.$message.error('请选择开始时间')
        return
      }
      if (this.askForReasonsValue === '2' && !this.datePickerValueEnd) {
        this.$message.error('请选择结束时间')
        return
      }

      const filterList = this.contractList.filter(f => f.orderNo === this.selectedContractValue),
        // 通过 val 获取 中文label
        selectValueFun = (list, val) => list.filter(f => f.value == val)[0] || {},
        queryItem = {
          // askForReasonsValue: selectValueFun(this.askForReasonsList, this.askForReasonsValue).label,
          // 如果是 预付款  需要 区分 是 合同预付款 还是 材料进场预付款
          askForReasonsValue: selectValueFun(this.askForReasonsList, this.askForReasonsValue).label === '预付款' ? selectValueFun(this.prepaymentsList, this.prepaymentsValue).label : selectValueFun(this.askForReasonsList, this.askForReasonsValue).label,
          prepaymentsValue: selectValueFun(this.prepaymentsList, this.prepaymentsValue).label,
          datePickerValueStart: this.formatDateTime(this.datePickerValueStart),
          datePickerValueEnd: this.formatDateTime(this.datePickerValueEnd),
          // paymentType	String	Y	请款事由（advance：合同预付款；preProgress：材料进场预付款；progress：进度款）
          paymentType: this.askForReasonsValue === '2' ? 'progress' : this.prepaymentsValue === '1' ? 'advance' : 'preProgress',
          paymentNo: this.executionId,
          isSessionStorage: true
        }

      let item = {}

      item = filterList && filterList[0] || {}

      this.setInitiateAnapplicationBaseInfoAct(Object.assign(queryItem, item))
      this.beforeClose()
      window.open(this.$router.resolve({
        path: '/InitiateAPayment'
      }).href, '_blank')
    },

    /**
     * 格式化时间
     */
    formatDateTime(date) {
      if (!date) return
      return `${date.getFullYear()}-${date.getMonth() + 1}-${date.getDate()}`
    },

    /**
     * 请搜索选择合同
     */
    filterContractMethod(val) {
      clearTimeout(this.searchTimer)
      this.searchTimer = setTimeout(() => {
        this.pageIndex = 1
        this.searchVal = val
        this.getPaymentOrderList()
      }, 500);
    },

    /**
     * 下拉输入框 获得焦点
     */
    handleContractFocus(val) {
      this.searchVal = ''
      this.pageIndex = 1
    },

    /**
     * 下拉输入框 失去焦点
     */
    handleContractBlur() {
    },

    /**
     * 合同选中
     */
    handleContractChange() {
      this.isHadAdvance = false
      const filterList = this.contractList.filter(f => f.orderNo === this.selectedContractValue)
      let item = {}

      item = filterList && filterList[0] || {}
      if (item.pmtApplyList && item.pmtApplyList.length) {
        // 如果历史记录 有合同预付款 , 则 不能选中合同预付款选项
        this.isHadAdvance = item.pmtApplyList.some(s => (s.paymentType === 'advance' && s.status !== 'closed'))
      }
      this.prepaymentsValue = ''
    },

    /**
     * 下拉框收缩时
     */
    contractListVisibleChange(ev) {
      this.contractSelectPlaceholder = '请搜索选择合同'
      ev && this.getPaymentOrderList()
    },

    /**
     * 关闭
     */
    beforeClose() {
      this.$emit('update:initiateAnApplicationDialogVisible', false)
    },

    /**
     * 请款事由改变
     */
    askForReasonsChange() {
      console.log(this.askForReasonsValue)
      this.prepaymentsValue = ''
      this.datePickerValueStart = ''
      this.datePickerValueEnd = ''
    },

    /**
     * 获取合同
     */
    getPaymentOrderList() {
      const params = {
        searchKey: this.searchVal || '',  // 合同名称
        pageIndex: this.pageIndex,
      }
      InterfaceService.getPaymentOrderList(params, data => {
        if (data.respData && data.respData.respCode === "0000") {
          this.contractList = data.respData.contractList || []
          this.contractList.map(m => {
            m.value = m.orderNo
            m.label = m.contractName
          })

          // this.pageIndex = Number(data.respData.pageIndex) || 1
          this.pageTotal = Number(data.respData.totalCount) || 1

        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        // this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

    /**
     * 获取合同编号
     */
    getApprovalId() {
      return new Promise(resolve => {
        InterfaceService.getApprovalId(
          {
            // EXE 流程ID采番
            // PMT 请款单编号采番
            type: 'PMT'
          },
          data => {
            if (data.respData.respCode === "0000") {
              console.log(data);
              this.executionId = data.respData.busiNo || "";
              // this.cityCompanyList = data.respData.resultList || []
              resolve(data.respData.busiNo)
            } else {
              this.$message.error(data.respData.respMsg);
            }
          },
          data => { },
          () => {
            this.isLoading = true;
          },
          () => {
            this.isLoading = false;
          });
      })
    },
  }
};
</script>

<style lang="scss" scoped>
.card-content {
  .title {
    font-size: 14px;
    color: #888;
  }
}
/deep/ .el-select {
  width: 100%;
  .el-select__input {
    border: 0px !important;
  }
}
/deep/ .el-row {
  align-items: center;
  display: flex;
  flex-wrap: wrap;
  [class*="el-col-"] {
    margin-top: 12px;
    padding-right: 0 !important;
  }
  .el-date-editor.el-input {
    width: 100% !important;
  }
}
.page-container {
  text-align: center;
  border-top: 1px solid #ddd;
  margin-top: 2px;
  padding-top: 7px;
}
</style>

<style lang="scss">
.initiateAnapplicataionSelect {
  .el-scrollbar__wrap {
    max-height: 410px !important;
  }
}
</style>


