<template>
  <div v-if="format">
    <span v-if="viewName" class="blue-pointer" @click="handleView(attachUrl)" style="padding-left: 6px">{{viewName}}</span>
    <span class="blue-pointer" @click="handleDownload(attachUrl,attachName)" :style="{'padding-left' : paddingLeft}">{{downloadName}}</span>
  </div>
  <div v-else>
    <span class="blue-pointer" @click="handleView(attachUrl)" :style="{'padding-left' : paddingLeft}">{{viewName}}</span>
    <span class="blue-pointer" @click="handleDownload(attachUrl,attachName)" style="padding-left: 10px">{{downloadName}}</span>
  </div>
</template>

<script>
import { viewFile } from '@/utils/orderUtil';

export default {
  name: "DownloadAndView",
  props: {
    format: {
      default: true
    },
    downloadName: {
      default: "下载授权书"
    },
    viewName: {
      default: "查看授权书"
    },
    paddingLeft: {
      default: "6px"
    },
    attachUrl: {
      default: ""
    },
    attachName: {
      default: ""
    },
    // 图片隐藏选择按钮
    hideRotate: {
      default: false
    }
  },
  methods: {
    handleView(url) {
      viewFile(url, this.hideRotate)
    },
    handleDownload(url, name) {
      let attach = [];
      attach.push({
        url: url,
        name: name
      });
      this.$download(attach).then(res => {
        this.$message.success("已下载");
      }).catch(res => {
        this.$message.error("下载失败");
      })
    },
  }
}
</script>

<style scoped>
div {
  display: inline-block;
}
</style>