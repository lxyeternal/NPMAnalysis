<template>
    <div>
        <!-- 退货 -->
        <el-dialog class="dialog" title="填写退货原因" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="50%" center :close-on-click-modal="false">
            <div>
                <p style="line-height:20px">请与供应商沟通后，直接拒绝签收全部货品，填写退货原因并提交；若已签收货，请联系物流，将本次要货单中所有货品，全部发出后，再填写退货原因并提交。</p>
                <br>
                <el-form :model="returnForm" label-width="70px" label-position="left">
                    <el-form-item label="退货原因" prop="reason">
                        <el-input type="textarea" v-model="returnForm.reason" rows="8" placeholder="请输入退货原因..."></el-input>
                        <i class="error-info" v-if="showError&&!returnForm.reason">请输入退货原因</i>
                    </el-form-item>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确定退货</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
const returnForm = {
    reason: ""
};
export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            order: {},
            requireNo: "",
            returnForm: Object.assign({}, returnForm),
            showError: false
        };
    },
    methods: {
        open(data) {
            this.order = data;
            this.requireNo = data.requireNo;
            this.returnForm = Object.assign({}, returnForm);
            this.dialogVisible = true;
        },
        handleConfirm() {
            if (!this.returnForm.reason) {
                this.showError = true;
                return;
            }
            this.returnOrder();
        },
        returnOrder() {
            const params = {
                requireNo: this.requireNo,
                returnReason: this.returnForm.reason
            };
            InterfaceService.returnOrder(
                params,
                data => {
                    console.log(data);
                    if (data.respCode === "0000") {
                        this.dialogVisible = false;
                        this.$emit("close", true);
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
.error-info {
    color: #f56c6c;
    font-size: 12px;
    line-height: 1;
    padding-top: 4px;
    position: absolute;
    top: 100%;
    left: 0;
}
</style>
