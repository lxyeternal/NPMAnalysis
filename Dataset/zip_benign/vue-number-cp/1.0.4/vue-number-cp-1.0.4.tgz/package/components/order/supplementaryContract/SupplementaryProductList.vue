<template>
  <div class="supplementaryProductList">
    <p v-if="showTest"><label>补充合同测试调用接口：</label><span class="blue-pointer" @click="testCode">050079</span></p>
    <TableThead :TopDistance="660" Height="60">
      <tr slot="tr">
        <td width="55px">序号</td>
        <td width="300px">补充合同编号/补充合同名称</td>
        <td width="100px">创建时间</td>
        <td width="150px" class="tr">补充合同价款<br>(不含税)(元)</td>
        <td width="70px" class="tr">税率</td>
        <td width="145px" class="tr">税额(元)</td>
        <td width="150px" class="tr">补充合同价款<br>(含税)(元)</td>
        <td width="90px">状态</td>
        <td width="130px">操作</td>
      </tr>
    </TableThead>
    <table class="table-default">
      <thead>
        <tr>
          <td width="55px">序号</td>
          <td width="300px">补充合同编号/补充合同名称</td>
          <td width="100px">创建时间</td>
          <td width="150px" class="tr">补充合同价款<br>(不含税)(元)</td>
          <td width="70px" class="tr">税率</td>
          <td width="145px" class="tr">税额(元)</td>
          <td width="150px" class="tr">补充合同价款<br>(含税)(元)</td>
          <td width="90px">状态</td>
          <td width="130px">操作</td>
        </tr>
      </thead>
      <tbody v-for="(item,ind) in replenishContractInfo.relContractList" :key="ind+'relContractList'">
        <tr :class="{'mask': item.orderStatus == '02', 'border-none': showSignProcess(item)}">
          <td>
            {{ind + 1}}
          </td>
          <td>
            <p>
              <template v-if="brokerRole">{{item.clOrderNo}}/{{item.sybOrderNo}}</template>
              <template v-else-if="divisionContract">
                {{item.sybOrderNo}}
              </template>
              <template v-else>
                {{item.clOrderNo}}
              </template>
            </p>
            <p v-if="item.contractName" class="tl">《{{item.contractName}}》</p>
          </td>
          <td>
            <template v-if="item.orderTm">
              <p>{{item.orderTm.substring(0, 10)}}</p>
              <p>{{item.orderTm.substring(11, item.orderTm.length)}}</p>
            </template>
          </td>
          <td class="tr">
            <p v-if="divisionContract">{{item.inContractFee | formatMoney}}</p>
            <p v-else>{{item.outContractFee| formatMoney}}</p>
          </td>
          <td class="tr">
            {{(+item.taxRate)*100+'%'}}
          </td>
          <td class="tr">
            <p v-if="divisionContract">{{item.inContractTax | formatMoney}}</p>
            <p v-else>{{item.outContractTax| formatMoney}}</p>
          </td>
          <td class="tr">
            <p v-if="divisionContract">{{item.inContractFeeWithTax | formatMoney}}</p>
            <p v-else>{{item.outContractFeeWithTax | formatMoney}}</p>
          </td>
          <td>{{item.orderStatusDisp}}</td>
          <td class="operat">
            <!-- 供应商 -->
            <template v-if="role == 'S'">
              <!--厂家-->
              <template v-if="userInfo.supplyType == '0'">
                <template v-if="orderInfo.supplierId === userInfo.corpId">
                  <p v-if="item.orderStatus == '01'">
                    <a @click="handleOperation('1',item.orderNo)">编辑补充合同</a>
                    <a @click="handleOperation('2', item.orderNo)">删除补充合同</a>
                  </p>
                  <p v-if="['04', '06'].includes(item.orderStatus)">
                    <a @click="handleOperation('1',item.orderNo)">编辑补充合同</a>
                    <a @click="handleOperation('4', item.orderNo)">关闭补充合同</a>
                  </p>

                  <p v-if="['05'].includes(item.orderStatus) && approveStatus(item) === '3' && isSignature(item)">
                    <a @click="handleSign(item, 'contract')">电子签章补充合同</a>
                  </p>
                  <p v-if="item.orderStatus == '03'">
                    <a @click="handleOperation('3', item.orderNo)">撤回补充合同</a>
                  </p>
                  <!-------------------------------- 解除与终止合同 ------------------------------------>
                  <!-- <p v-if="item.orderStatus == '05' && approveStatus(item) === '3'">
                    <a @click="handleOrderRescind(item, '1', true, true)">补充合同解除</a>
                  </p>
                  <p v-if="item.orderStatus == '11' && approveStatus(item) === '3'">
                    <a @click="handleOrderRescind(item, '1', false, true)">终止补充合同</a>
                  </p>
                  <p v-if="item.orderStatus === 'contractTerminating' && (approveStatus(item) === '3' || ['15', '16'].includes(item.terminatingStatus))">
                    <a v-if="approveStatusTermination(item) === '3'" @click="handleSign(item, 'relieve')">电子签章</a>

                    <a v-if="['15', '16'].includes(item.terminatingStatus)" @click="handleOrderRescind(item, '1', item.terminateType == 'relieve' ? true : false, true)">
                      继续{{item.terminateType == 'relieve' ? '解除补充合同' : '终止补充合同'}}
                    </a>
                    <a v-if="['15', '16'].includes(item.terminatingStatus)" @click="withdrawContract(item, '1')">{{item.terminateType == 'relieve' ? '关闭解除补充合同' : '关闭终止补充合同'}}</a>
                  </p>
                  <p v-if="isSupplierWithdraw(item)">
                    <a @click="withdrawContract(item, '0')">{{item.terminateType == 'relieve' ? '撤回解除补充合同' : '撤回终止补充合同'}}</a>
                  </p> -->
                </template>
                <!-------------------------------- 解除与终止合同 ------------------------------------>
                <!-- <p v-if="item.orderStatus === 'contractTerminating'">
                  <template v-if="item.terminatingStatus === '08'">
                    <a v-if="item.terminateType == 'relieve'" @click="handleOrderRescind(item, '2', true, true)">确认解除合同</a>
                    <a v-if="item.terminateType == 'relieve'" @click="handleOrderRescind(item, '3', true, true)">退回解除合同</a>
                    <a v-if="item.terminateType == 'terminate'" @click="handleOrderRescind(item, '2', false, true)">确认终止合同</a>
                    <a v-if="item.terminateType == 'terminate'" @click="handleOrderRescind(item, '3', false, true)">退回终止合同</a>
                  </template>
                </p> -->

                <p v-if="item.orderStatus == '07'">
                  <a @click="subOrderNo = item.orderNo;$refs.submitSupplementaryContract.open(item, '2')">审核通过</a>
                  <a @click="handleOperation('6', item.orderNo)">退回</a>
                </p>
              </template>
              <!-- 代理商 -->
              <template v-else>
                <p v-if="item.orderStatus == '01'">
                  <a @click="handleOperation('1',item.orderNo)">编辑补充合同</a>
                  <a @click="handleOperation('2', item.orderNo)">删除补充合同</a>
                </p>
                <p v-if="['04', '06'].includes(item.orderStatus)">
                  <a @click="handleOperation('1',item.orderNo)">编辑补充合同</a>
                  <a @click="handleOperation('4', item.orderNo)">关闭补充合同</a>
                </p>
                <p v-if="item.orderStatus == '07'">
                  <a @click="handleOperation('3', item.orderNo)">撤回补充合同</a>
                </p>
                <p v-if="['05'].includes(item.orderStatus) && approveStatus(item) === '3' && isSignature(item)">
                  <a @click="handleSign(item, 'contract')">电子签章补充合同</a>
                </p>

                <!-------------------------------- 解除与终止合同 ------------------------------------>
                <!-- <p v-if="item.orderStatus == '05' && approveStatus(item) === '3'">
                  <a @click="handleOrderRescind(item, '1', true, true)">补充合同解除</a>
                </p>
                <p v-if="item.orderStatus == '11' && approveStatus(item) === '3'">
                  <a @click="handleOrderRescind(item, '1', false, true)">终止补充合同</a>
                </p>
                <p v-if="item.orderStatus === 'contractTerminating' && (approveStatus(item) === '3' || ['08', '15', '16'].includes(item.terminatingStatus))">
                  <a v-if="approveStatusTermination(item) === '3'" @click="handleSign(item, 'relieve')">电子签章</a>
                  <a v-if="item.terminatingStatus === '08'" @click="withdrawContract(item, '0')">{{item.terminateType == 'relieve' ? '撤回解除补充合同' : '撤回终止补充合同'}}</a>

                  <a v-if="['15', '16'].includes(item.terminatingStatus)" @click="handleOrderRescind(item, '1', item.terminateType == 'relieve' ? true : false, true)">
                    继续{{item.terminateType == 'relieve' ? '解除补充合同' : '终止补充合同'}}
                  </a>
                  <a v-if="['15', '16'].includes(item.terminatingStatus)" @click="withdrawContract(item, '1')">{{item.terminateType == 'relieve' ? '关闭解除补充合同' : '关闭终止补充合同'}}</a>
                </p> -->
              </template>
              <p v-if="item.orderStatus != '01' || item.orderStatus != '02'"><a @click="handleDownloadContract(item)">下载补充协议</a></p>
            </template>
            <!-- 采购商 -->
            <template v-else>
              <!-- 采购商 -->
              <template v-if="!brokerRole">
                <p v-if="['03'].includes(item.orderStatus)">
                  <a @click="handleOAapproval(item)">提交OA审核</a>
                  <a @click="handleOperation('7', item.orderNo)">退回</a>
                </p>
                <p v-if="['05'].includes(item.orderStatus) && (approveStatus(item) === '4' || approveStatus(item) === '2')">
                  <a @click="handleOAapproval(item)">重新提交审核</a>
                  <a @click="handleOperation('7', item.orderNo)">退回</a>
                </p>
                <p v-if="['05'].includes(item.orderStatus) && approveStatus(item) === '3' && isSignature(item)">
                  <a @click="handleSign(item, 'contract')">电子签章补充合同</a>
                </p>
                <!-------------------------------- 解除与终止合同 ------------------------------------>
                <!-- <p v-if="item.orderStatus === 'contractTerminating' && approveStatusTermination(item) === '3'">
                  <a @click="handleSign(order, 'relieve')">电子签章</a>
                </p> -->
                <!-- 解除与终止合同 -->
                <!-- <p v-if="item.orderStatus === 'contractTerminating' && item.terminatingStatus === '09'">
                  <a v-if="item.terminateType == 'relieve' && (!approveStatusTermination(item) || ['2', '4'].includes(approveStatusTermination(item)))" @click="handleOrderRescind(item, '2', true, true)">发起OA解除合同审批</a>
                  <a v-if="item.terminateType == 'relieve' && (!approveStatusTermination(item) || ['2', '4'].includes(approveStatusTermination(item)))" @click="handleOrderRescind(item,'3', true, true)">退回解除合同</a>
                  <template v-if="item.terminateType == 'terminate'">
                    <span class="grey" v-if="['0','1'].includes(approveStatusTermination(item))">发起OA终止合同审批</span>
                    <template v-else-if="approveStatusTermination(item) !== '3' && (!approveStatusTermination(item) || ['2', '4'].includes(approveStatusTermination(item)))">
                      <a @click="handleOrderRescind(item, '2', false, true)">发起OA终止合同审批</a>
                      <a @click="handleOrderRescind(item, '3', false, true)">退回终止合同</a>
                    </template>
                  </template>
                </p> -->
              </template>
              <!-- 材料公司 -->
              <template v-else>
                <p v-if="['05'].includes(item.orderStatus) && approveStatus(item) === '3' && isSignature(item)">
                  <a @click="handleSign(item, 'contract')">电子签章补充合同</a>
                </p>
                <!-- 终止合同协议电子签章 -->
                <!-- <p v-if="item.orderStatus === 'contractTerminating' && approveStatusTermination(item) === '3'">
                  <a @click="handleSign(order, 'relieve')">电子签章</a>
                </p> -->
              </template>
              <p v-if="item.orderStatus != '01' || item.orderStatus != '02'"><a @click="handleDownloadContract(item)">下载补充协议</a></p>
            </template>
          </td>
        </tr>
        <tr class="sign-content" v-if="showSignProcess(item)">
          <td colspan="9">
            <SignProcessOrderList :order="item" :isSupplementary="true"></SignProcessOrderList>
          </td>
        </tr>
      </tbody>
      <!-- 累计 -->
      <tbody>
        <tr class="total">
          <td colspan="2" style="padding: 0px">
            <div class="total-text">补充合同总价款</div>
          </td>
          <td></td>
          <td>{{(divisionContract ? replenishContractInfo.relInContractFee : replenishContractInfo.relOutContractFee) | formatMoney}}</td>
          <td colspan="2"></td>
          <td>{{(divisionContract ? replenishContractInfo.relInContractFeeWithTax : replenishContractInfo.relOutContractFeeWithTax) | formatMoney}}</td>
          <td colspan="2"></td>
        </tr>
      </tbody>
    </table>
    <SubmitSupplementaryContract ref="submitSupplementaryContract" @confirmSubmit="pushOrder" :orderInfo="orderInfo" :tab="+tab"></SubmitSupplementaryContract>

    <OrderRescind ref="orderRescind" @close="handleOperation"></OrderRescind>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import TableThead from "@/components/base/TableThead";
import SubsistTable from "@/components/paymentRequest/SubsistTable";
import SubmitSupplementaryContract from "@/components/order/supplementaryContract/SubmitSupplementaryContract";
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import SignProcessOrderList from "@/components/order/SignProcessOrderList";
import OrderRescind from "@/components/order/dialog/orderOperate/OrderRescind";
// import { NumberUtil } from '@/utils/numberUtil';
// import { MoneyUtil } from '@/utils/moneyUtil';

export default {
  name: "detailsTable",
  components: {
    TableThead, SubsistTable, SubmitSupplementaryContract, Loading, SignProcessOrderList, OrderRescind
  },
  props: ['replenishContractInfo', 'divisionContract', 'orderInfo', 'tab'],
  data() {
    return {
      isLoading: false,

      subOrderNo: '',
      //   relContractList: [],
      showTest: false, // 是否显示 测试调用接口
    }
  },
  computed: {
    isSignature() {
      return item => {
        let result = false
        if (item.eventList) {
          let obj = item.eventList.find(i => i.bs === this.role) || {}
          if (obj.eventStatus !== '2' && obj.processList) {
            result = obj.processList.some(i => this.userInfo.acctIdList.includes(i.acctId) && i.processFlg == '0')
          }
        }
        return result
      }
    },
    brokerRole() {
      return this.$store.state.userInfo &&
        this.$store.state.userInfo.contractCorpType === "broker"
    },
    role() {
      return this.$store.state.userInfo
        ? this.$store.state.userInfo.bs
        : 0;
    },
    userInfo() {
      return this.$store.state.userInfo;
    },
  },
  mounted() {
    this.showTest = this.$route.query.showTest
  },
  methods: {
    handleOperation(type = '', orderNo = '') {
      console.log(type, orderNo)
      this.$emit('handleOperation', [type, orderNo])
    },
    // 合同解除与终止
    handleOrderRescind(item, type, isRescind, isSupplementary = false) {
      this.$refs["orderRescind"].open(item, type, isRescind, isSupplementary)
    },
    testCode() {
      // 补充合同
      let obj = {}
      if (this.replenishContractInfo.relContractList && this.replenishContractInfo.relContractList.length) {
        obj = this.replenishContractInfo.relContractList[0]
      }
      InterfaceService.testCode(
        { orderNo: obj.orderNo },
        data => {
          let res = data.respData;
          if (res.respCode === "0000") {
            this.$parent.getOrderDetail()
          } else {
            this.$message.error(data.respMsg);
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },

    showSignProcess(item) {
      return item.orderStatus === '05' && item.eventList && item.eventList.length
    },
    approveStatus(item) {
      let status = ''
      let oaApprovalInfo = item.externalSysList && item.externalSysList.find(i => { return i.sysCode === 'OA' }) || {};
      status = oaApprovalInfo.approveStatus
      console.log(status);
      return status
    },
    approveStatusTermination(item) {
      let status = ''
      let oaApprovalInfo = item.externalSysList && item.externalSysList.find(i => { return i.operType === 'TERMINATED' }) || {};
      status = oaApprovalInfo.approveStatus || ''
      console.log(status);
      return status
    },
    isSupplierWithdraw(item) {
      let result = false
      let list = item.externalSysList && item.externalSysList.filter(i => { return i.operType === 'TERMINATED' });
      if (item.orderStatus === 'contractTerminating' && item.terminatingStatus === '09' && !list.length) {
        result = true
      }
      console.log(result)
      return result
    },
    //电子签章
    handleSign(item = {}, orderType) {
      if (this.brokerRole) {
        window.open(this.$router.resolve({
          path: "/brokerSignPreview",
          query: {
            orderNo: this.orderInfo.orderNo,
            tab: this.tab,
            orderType: orderType,
            subOrderNo: item.orderNo
          }
        }).href, '_blank');
      } else {
        window.open(this.$router.resolve({
          path: "/contractSign",
          query: {
            orderNo: this.orderInfo.orderNo,
            orderType: orderType,
            subOrderNo: item.orderNo
          }
        }).href, '_blank')
      }
    },
    // 撤回解除或终止合同
    withdrawContract(item = {}, operateType = '') {
      this.$confirm(
        `确认要${item.terminateType == 'relieve' ? `${operateType === '0' ? '撤回' : '关闭'}解除补充合同` : `${operateType === '0' ? '撤回' : '关闭'}终止补充合同`}吗？`,
        `确认${operateType === '0' ? '撤回' : '关闭'}`,
        {
          cancelButtonClass: "btn-custom-cancel",
          confirmButtonClass: "btn-custom-confirm",
          center: true,
          dangerouslyUseHTMLString: true,
          confirmButtonText: `确认${operateType === '0' ? '撤回' : '关闭'}`,
          cancelButtonText: '取消',
        }).then(() => {
          let params = {
            orderNo: item.orderNo,
            operateType: operateType, //0撤回；1关闭
          };
          InterfaceService.withdrawContract(
            params,
            data => {
              let res = data.respData || {};
              if (data && data.respData && res.respCode === "0000") {
                this.$message.success('操作成功')
                this.handleOperation();
              } else {
                this.$message.error(data.respData.respMsg)
              }
            }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
        }).catch(() => {
        });
    },
    handleOAapproval(item) {
      this.subOrderNo = item.orderNo
      this.$refs.submitSupplementaryContract.open(item, '3')
    },
    pushOrder() {
      const params = {
        orderNo: this.subOrderNo,
        operType: 'submit',
      };
      InterfaceService.pushOrder(
        params,
        data => {
          if (data.respData.respCode == "0000") {
            this.$message.success('提交成功')
            this.handleOperation('8')
            window.opener && window.opener.location.reload();
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false });
    },
    // 下载
    handleDownloadContract(obj) {
      const params = {
        orderNo: obj.orderNo,
        bs: this.role == 'B' ? '' : 'S',
        documentVersion: "",
        fileFrom: "userUpload,systemCreate",
        documentTypeList: []
      };
      InterfaceService.getContractInfo(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let attachList = [];
          let list = res.documentInfos || [];
          let hasPdf = list.some(item => {
            return item.documentType === 'externalReplenishAgreement' || item.documentType === 'internalReplenishAgreement'
          });
          list.forEach(item => {
            if (hasPdf) {
              if (['externalReplenishAgreement', 'internalReplenishAgreement', 'otherFile'].indexOf(item.documentType) != -1) {
                let onOff = false;
                attachList.forEach(_item => {
                  if (item.documentId == _item.documentId) {
                    onOff = true
                  }
                });
                if (!onOff) {
                  attachList.push(item)
                }
              }
            } else {
              let onOff = false;
              attachList.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOff = true
                }
              });
              if (!onOff) {
                attachList.push(item)
              }
            }
          });
          this.handleBatchDownload(attachList, hasPdf, obj)
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    handleBatchDownload(attachList, hasPdf, obj) {
      let fileInfoBeans = []
      if (attachList.length) {
        if (!hasPdf) {
          attachList.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: item.documentName,
              fileUrl: item.attachUrl,
            })
          })
        } else {
          attachList.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: item.documentName,
              fileUrl: item.attachUrl,
            })
          })
        }
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                // { name: (this.divisionContract ? (obj.contractName.replace('采购合同', '供应合同')) : (obj.contractName)) + ".zip", url: data }
                { name: obj.contractName + ".zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
  },
}
</script>

<style scoped lang="scss">
.mask {
  background: #ddd;
  opacity: 0.7;
  // pointer-events: none;
  &:hover {
    background: #ddd;
    opacity: 0.7;
    // pointer-events: none;
  }
}
.supplementaryProductList {
  margin-bottom: 30px;
  .table-default {
    thead {
      tr {
        td {
          font-size: 14px;
          line-height: 20px;
        }
      }
    }
    tr {
      td {
        padding-left: 10px;
        padding-right: 10px;
        font-size: 12px;
        line-height: 17px;
      }
    }
    .box_type {
      background: #ffe9eb;
      border: 1px solid #db7575;
      color: #863838;
      margin-bottom: 0px;
    }
    tbody {
      .sign-content {
        display: table-row;
        background: #f9f9f9;
        &:hover {
          background: #f0f8ff;
        }
        td {
          padding: 0;
          border-top: none;
        }
      }
    }
    .total {
      background: #ebf1ff;
      > td {
        padding-top: 7px;
        padding-bottom: 6px;
        font-weight: 600;
        font-size: 12px;
        line-height: 17px;
        text-align: right;
        .total-text {
          // width: 151px;
          height: 30px;
          background-color: #e3ecff;
          padding-left: 10px;
          text-align: left;
          line-height: 30px;
        }
      }
    }
    .operat {
      > p {
        > a {
          display: block;
          color: #0082ff;
          font-size: 12px;
          line-height: 17px;
          margin-bottom: 4px;
          &:last-child {
            margin-bottom: 0px;
          }
        }
      }
    }
  }
}
</style>