<template>
    <div class="content">
        <template v-if="brokerRole">
            <h3>{{statementText}}管理</h3>
        </template>
        <template v-else>
            <h3>对账单每月26日更新</h3>
            <p>请在
                <span class="red">本月30日</span>之前完成签章，逾期待处理对账单将进入下一结账周期</p>

            <el-button v-if="type==='pay'&&role==='B'" class="fr" type="primary" style="width:120px" @click="handleOpenGen">生成对账单</el-button>
        </template>

        <el-row>
            <el-col :span="6">
                <h2>{{order.toDoCnt||0}}</h2>
                <p class="grey">待处理</p>
            </el-col>
            <el-col :span="6" class="divide">
                <h2>{{order.processingCnt||0}}</h2>
                <p class="grey">进行中</p>
            </el-col>
        </el-row>

        <GenerateStatement ref="genStatement" @close="handleCloseGen"></GenerateStatement>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import GenerateStatement from "@/components/order/statement/GenerateStatementDialog";
export default {
    mixins: [accountMixin],
    components: {
        GenerateStatement
    },
    props: ["type", "order"],
    data() {
        return {
            todoCount: 3,
            doingCount: 4
        };
    },
    computed: {
        statementText() {
            return this.type === "pay" ? "应付对账单" : "应收对账单";
        }
    },
    methods: {
        handleOpenGen() {
            this.$refs["genStatement"].open();
        },
        handleCloseGen(success) {
            if (success) {
                this.$emit("refresh");
            }
        }
    }
};
</script>

<style lang="scss" scoped>
h3 {
    font-weight: bold;
    font-size: 18px;
}

h2 {
    font-weight: bold;
    font-size: 35px;
    line-height: 35px;
}

.content {
    margin-bottom: 20px;
    padding: 10px 26px;
    line-height: 25px;
    background: #f5f5f5;
}

.divide {
    margin-right: 20px;
    // border-right: 1px solid #cccccc;
}
</style>
