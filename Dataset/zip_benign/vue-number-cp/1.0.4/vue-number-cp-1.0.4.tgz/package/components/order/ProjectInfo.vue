<template>
    <div>
        <div class="panel-title">
            <span>填写项目合同信息</span>
        </div>
        <div>
            <el-form ref="form" :model="form" :rules="rules">
                <!-- <el-form-item label="项目工程地区：" prop="projectProvCode" label-width="120px">
                    <Distpicker :address="defaultAddressCode" @receive="getAddressCode"></Distpicker>
                </el-form-item> -->
                <el-row :gutter="150">
                    <el-col :span="8">
                        <p class="form-item-label">
                            <i class="red">*&nbsp;</i>事业部名称：</p>
                        <el-form-item class="form-item" :required="true">
                            <el-input type="text" v-model="form.buName" placeholder="请输入事业部名称" disabled></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <p class="form-item-label">
                            <i class="red">*&nbsp;</i>项目名称：</p>
                        <el-form-item prop="projectId" class="form-item">
                            <el-select v-model="form.projectId" @change="handleChangeProjectName" clearable>
                                <el-option v-for="(pro,index) in projectNameList" :key="index" :label="pro.projectName" :value="pro.projectId"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <p class="form-item-label">
                            <i class="red">*&nbsp;</i>所在城市名称：</p>
                        <el-form-item class="form-item" :required="true">
                            <el-input type="text" v-model="form.subordinateCityName" placeholder="--" disabled></el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <p class="form-item-label">地块(如有)：</p>
                        <el-form-item prop="block" class="form-item">
                            <el-input type="text" v-model="form.block" placeholder="请输入地块名" @input="handleChangeName" @blur="checkFileName" :maxlength="200">
                                <i slot="suffix">地块</i>
                            </el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <p class="form-item-label">项目期数(如有)：</p>
                        <el-form-item prop="projectTerm" class="form-item">
                            <el-input v-model="form.projectTerm" placeholder="请输入数字，例如3" @input="handleChangeName" >
                                <i slot="suffix">期</i>
                            </el-input>
                        </el-form-item>
                    </el-col>
                    <!-- <el-col :span="8">
                        <p class="form-item-label">
                            <i class="red">*&nbsp;</i>工程名称：</p>
                        <el-form-item prop="engineeringName" class="form-item">
                            <el-autocomplete :maxlength="400" popper-class="my-autocomplete" v-model="form.engineeringName" :fetch-suggestions="queryEngineeringSearch" placeholder="请输入合同工程名称，例如：门窗安装入户工程" @input="handleChangeName" @select="handleEngineeringSelect">
                                <i class="el-icon-edit el-input__icon" slot="suffix">
                                </i>
                                <template slot-scope="{ item }">
                                    <div class="name">{{ item }}</div>
                                </template>
                            </el-autocomplete>
                        </el-form-item>
                    </el-col> -->
                    <el-col :span="8">
                        <p class="form-item-label">标段/楼栋(如有)：</p>
                        <el-form-item prop="building" class="form-item">
                            <el-input type="text" v-model="form.building" placeholder="请输入标段/楼栋" @input="handleChangeName()" @blur="checkFileName" :maxlength="200">
                            </el-input>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <p class="form-item-label">
                            <i class="red">*&nbsp;</i>类别：</p>
                        <el-form-item prop="orderCateCode" class="form-item">
                            <el-select v-model="form.orderCateCode" @change="handleChangeCate" placeholder="请选择类别" clearable>
                                <el-option v-for="(item,index) in projectCateList" :key="index" :label="item.name" :value="item.code"></el-option>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <el-col :span="8">
                        <p class="form-item-label">
                            <i class="red">*&nbsp;</i>专业名称：</p>
                            <!-- @mouseout="selectMouseout"  -->
                            <div class="majorSelectListContainer" @mouseover="selectMouseover" v-if="computedMajorSelectList.length" v-show="showSelectList">
                                <el-form-item prop="majoRselectedValue" class="form-item">
                                    <el-checkbox-group v-model="form.majoRselectedValue" @change="handleChangeName" >
                                        <el-checkbox v-for="item in computedMajorSelectList" :key="item" :label="item"></el-checkbox>
                                    </el-checkbox-group>
                                </el-form-item>
                            </div>
                        <el-form-item prop="majorCode" class="form-item">
                            <!--   @mouseout.native="selectMouseout" -->
                            <el-select clearable filterable default-first-option no-data-text="请选择类别"
                                no-match-text="请修改匹配关键词"
                                v-model="form.majorCode"
                                @mouseover.native="selectMouseover"
                                @change="handleChangeMajor(form.majorCode, 1)" placeholder="请选择专业名称">
                                <template v-if="projectMajorList.length&&form.orderCateCode==='01'">
                                    <el-option v-for="(item,index) in projectMajorList[0].list" :key="index" :label="item.name" :value="item.code"></el-option>
                                </template>
                                <template v-if="projectMajorList.length&&(form.orderCateCode==='02')">
                                    <el-option v-for="(item,index) in projectMajorList[1].list" :key="index" :label="item.name" :value="item.code"></el-option>
                                </template>
                                <template v-if="projectMajorList.length&&(form.orderCateCode==='03')">
                                    <el-option v-for="(item,index) in projectMajorList[2].list" :key="index" :label="item.name" :value="item.code"></el-option>
                                </template>
                            </el-select>
                        </el-form-item>
                    </el-col>
                    <!-- <el-col :span="8">
                        <p class="form-item-label">补充：</p>
                        <el-form-item prop="additionInfo" class="form-item">
                            <el-input v-model="form.additionInfo" placeholder="请输入合同补充名称，例如：补充协议一" @input="handleChangeName" :maxlength="200"></el-input>
                        </el-form-item>
                    </el-col> -->
                    <el-col :span="8" v-if="groupCompanyCode == 'GREENLANDHK' && brokerCorpTag && form.majorCode !== 'C63' ">
                        <p class="form-item-label">
                            <i class="red">*&nbsp;</i>货物供应合同加价费率：</p>
                        <el-form-item prop="addRate" class="form-item" :rules="{ required: true, message: '请输入加价费率', trigger: 'blur' }">
                            <el-input type="number" v-model="form.addRate" v-input-number placeholder="请输入加价费率" disabled>
                                <template slot="append">%</template>
                            </el-input>
                        </el-form-item>
                    </el-col>
                </el-row>
                <!-- <hr> -->
                <!-- <el-form-item label="预览合同名称：" prop="contractName" label-width="100px" class="form-item-large">
                    <el-input v-model="form.contractName" placeholder="例如：《五里桥项目3期门窗安装入户工程补充协议一》" :maxlength="400"></el-input>
                </el-form-item> -->

                <div class="project-name">
                    <label>预览合同名称：</label>
                    <span v-if="form.contractName">{{form.contractName}}</span>
                    <span v-else class="grey">例如：《五里桥项目3期门窗安装入户工程补充协议一》</span>
                </div>
                <p class="project-name-tip">※合同命名规则：事业部名称+所在城市名称+项目名称+地块(如有)+分期+标段/楼栋(如有)+专业名称+类别</p>
            </el-form>
        </div>
    </div>
</template>

<script>
import Distpicker from "@/components/base/Distpicker";
import { InterfaceService } from "@/services/api";
const form = {
    buName: "",
    subordinateCityName: "",
    projectProvCode: "",
    projectCityCode: "",
    projectDistrictCode: "",
    projectId: "",
    projectTerm: "",
    engineeringName: "",
    additionInfo: "",
    contractName: "",
    addRate: 10,
    block: "",
    blockName: "",
    building: "",
    majorCode: "",
    majorName: "",
    orderCateCode: "",
    orderCateName: "",
    orderCateFullName:"",
    majoRselectedValue: []
};
export default {
    components: {
        Distpicker
    },
    props: {
        form: {
            type: Object,
            default: function() {
                return Object.assign({}, form);
            }
        }
    },
    data() {
        const majoRselectedValueChange = (rule, value, callback) => {
            if (!this.form.majoRselectedValue.length) {
                callback(new Error('请勾选专业名称'));
            } else {
                callback();
            }
        }
        return {
            //form: Object.assign({}, form),
            rules: {
                projectProvCode: [
                    {
                        required: true,
                        message: "请选择工程地区",
                        trigger: "change"
                    }
                ],
                projectId: [
                    {
                        required: true,
                        message: "请填写项目名称",
                        trigger: "change"
                    }
                ],
                projectTerm: [
                    { pattern: /^[\u4e00-\u9fa5a-zA-Z0-9\-]{0,10}$/, message: '请输入数字、"-"或中英文, 且不超过10个字符' , trigger: "blur"},
                ],
                majorCode: [
                    {
                        required: true,
                        message: "请选择专业名称",
                        trigger: "change"
                    }
                ],
                orderCateCode: [
                    {
                        required: true,
                        message: "请选择类别",
                        trigger: "change"
                    }
                ],
                majoRselectedValue: [
                    { validator: majoRselectedValueChange, trigger: 'change' }
                ]
                // engineeringName: [
                //     {
                //         required: true,
                //         message: "请填写工程名称",
                //         trigger: ["blur", "change"]
                //     }
                // ]
            },
            engineeringNameList: [],
            projectNameList: [],
            defaultAddressCode: {
                provCode: "",
                cityCode: "",
                blockCode: ""
            },
            projectMajorList: [],
            projectCateList: [],
            projectMajor: {},
            showSelectList: false,
            selectTimer: null, // 显示多选定时器
        };
    },
    watch: {
        form(newVal, oldVal) {
            newVal.majoRselectedValue = newVal.majoRselectedValue || []

            if (newVal) {
                this.form = newVal;
                console.log(newVal);
                this.defaultAddressCode = {
                    provCode: this.form.projectProvCode,
                    cityCode: this.form.projectCityCode,
                    blockCode: this.form.projectDistrictCode
                };
                this.form.addRate = this.form.addRate || 10;
            }
            // this.projectMajor.name = this.form.majorName;

            this.handleChangeMajor(this.form.majorCode);
           // console.log('---this.form', this.form);
        },
        projectCate(newVal = {}, oldVal = {}) {
            if (newVal.code !== oldVal.code) {
                // 供应合同类型清空专业
                if(!newVal.code ||
                    (newVal.code==='01' && (oldVal.code==='02' || oldVal.code==='03')) ||
                    ((newVal.code==='02' || newVal.code==='03') && oldVal.code==='01')
                ){
                    this.form.majorCode = "";
                }
                // 判断类别是否为空
                let test = Object.keys(newVal);
                if (test.length == 0) {
                    newVal.code = "04"
                }
                if (newVal.code) {
                    this.$emit("changeContractType", newVal.code);
                }
                //console.log(newVal, '----newVal');
            }
        }
    },
    computed: {
        /**
         * 通过 code  查找 names
         */
        computedMajorSelectList() {
           // console.log(this.form.majorCode, 'majorCode')
            let valueList = []
            this.projectMajorList.forEach(item => {
                item && item.list.forEach(listItem => {
                    if(listItem.code === this.form.majorCode) {
                      //  console.log(listItem, 'selectValue');

                        valueList = listItem.selectValue && listItem.selectValue.split('、') || []
                    }
                })
            })
            return valueList
        },
        project() {
            const projects = this.projectNameList.filter(item => {
                return item.projectId == this.form.projectId;
            });
            return projects[0] ? projects[0] : {};
        },
        projectCate() {
            const items = this.projectCateList.filter(item => {
                return item.code == this.form.orderCateCode;
            });
         //   console.log('----------类别：', items);

            return items[0] ? items[0] : {};
        },
        projectMajorSelectList() {
            let list = [];
            const majorList = this.projectMajorList;
           // console.log(this.form.orderCateCode);
            if (majorList && majorList.length) {
                if (this.form.orderCateCode === "01") {
                    list = majorList[0].list;
                } else if (this.form.orderCateCode === "02") {
                    list = majorList[1].list;
                } else {
                    list = majorList[2].list;
                }
            }
            return list;
        },
        groupCompanyCode() {
            return (
                this.$store.state.userInfo &&
                this.$store.state.userInfo.groupCompanyCode
            );
        },
        brokerCorpTag() {
            return (
                this.$store.state.userInfo &&
                this.$store.state.userInfo.brokerList.length > 0
            );
        },
        userInfo() {
            return this.$store.state.userInfo || {};
        },
    },
    methods: {
        // 选择合同
        handleChangeProjectName() {
            const data = this.project;
            // 选中对应地址
            this.form.projectProvCode = data.projectProvCode;
            this.form.projectCityCode = data.projectCityCode;
            this.form.projectDistrictCode = data.projectDistrictCode;

            // this.form.buName = data.buName;
            // 特别行政区时取省名
            let cityName = data.projectCityName === '市辖区'? data.projectProvName : data.projectCityName;
            this.form.subordinateCityName = (
                cityName || ""
            ).replace("市", "");

            this.defaultAddressCode = {
                provCode: data.projectProvCode,
                cityCode: data.projectCityCode,
                blockCode: data.projectDistrictCode
            };
            this.handleChangeName();
        },
         // 切换专业名称
        handleChangeMajor(code, state) {
            if (state === 1) {
                this.form.majoRselectedValue = []
                this.$emit("outResetPayMentRadio");
            }
            console.log(this.form.majorCode);
            this.showSelectList = true
            if (code == "" || code == undefined) {
                this.projectMajor = {}
            } else {
                for (let i=0, len= this.projectMajorSelectList.length; i<len; i++) {
                    if (this.projectMajorSelectList[i].code == code) {
                        this.projectMajor = this.projectMajorSelectList[i]
                        break
                    }
                }
            }

            //console.log('--projectMajor-切换专业名称',code, this.projectMajor);
            this.$emit("outProjectMajorCode", this.projectMajor || {});
            // console.log(this.projectMajor.code);
            this.handleChangeName();
        },
        // 切换类别
        handleChangeCate(code) {
            // 切换类别时 重置专业名称
            this.projectMajor = {};
            this.form.majorCode = '';

            this.handleChangeName();
        },
        // 合同名称
        checkFileName(){
            let reg = new RegExp('^[^\\\\\\/:*?\\"<>|]+$');
            if (!reg.test(this.form.block) && this.form.block != "") {
                this.form.block = "";
                this.$message.error("地块名称不能包含下列字符：\\ / ：* ？\" < > |");
                this.handleChangeName()
            }
            if (!reg.test(this.form.building) && this.form.building != "") {
                this.form.building = "";
                this.$message.error("标段/楼栋名称不能包含下列字符：\\ / ：* ？\" < > |");
                this.handleChangeName()
            }
        },
        selectMouseout() {
            this.selectTimer = setTimeout( time => {
                this.showSelectList = false
            }, 300)
        },
        selectMouseover() {
            this.showSelectList = true
            clearTimeout(this.selectTimer)
        },
        handleChangeName() {
            let str = "";
            this.form.blockName = this.form.block
                ? this.form.block + "地块"
                : "";
            let projectName = "";
            // 当项目名称包含城市名称时，城市名称不显示在合同名称中，避免重复
            if (this.project.projectName && this.project.projectName.indexOf(this.form.subordinateCityName) != -1) {
                projectName = ""
            } else {
                projectName = this.form.subordinateCityName;
            }
            const obj = {
                0: this.form.buName,
                // 1: this.form.subordinateCityName,
                1: projectName,
                2: this.project.projectName,
                3: this.form.blockName,
                4: this.form.projectTerm ? this.form.projectTerm + "期" : "",
                5: this.form.building,
                6: this.getProjectMajorName(),
                7: this.projectCate.orderName
            };

            for (let i in obj) {
                str += obj[i] || "";
            }
            this.form.getProjectMajorName = this.getProjectMajorName()
            this.form.contractName = str.slice(0, 400);
        },
        getProjectMajorName() {
            let name = ''
            // 如果有多选值
            if (this.projectMajor && this.projectMajor.selectValue && this.projectMajor.selectValue.length) {
              name = this.projectMajor.selectValue.split('、').filter(fItem => {
                    if (!this.form.majoRselectedValue || typeof(this.form.majoRselectedValue) !== 'object') {
                        this.form.majoRselectedValue = []
                    }
                  return this.form.majoRselectedValue.includes(fItem)
              }).toString().replace(/,/g, '、')
              if (this.projectMajor.unit && this.projectMajor.unit.length) {
                 name.length && (name += this.projectMajor.unit)
              }
            } else {
                name = this.projectMajor.name
            }

            //console.log(name)
            return name
        },
        getAddressCode(data) {
            this.form.projectProvCode = data.provinceCode;
            this.form.projectCityCode = data.cityCode;
            this.form.projectDistrictCode = data.blockCode;
        },
        getForm() {
            if (this.groupCompanyCode != 'GREENLANDHK' || !this.brokerCorpTag) {
                this.form.addRate = null;
            }

            if (this.projectMajor && this.projectMajor.name) {
                this.form.majorName = this.projectMajor.name;
            }

            if (this.projectCate) {
                this.form.orderCateName = this.projectCate.orderName;
                this.form.orderCateFullName = this.projectCate.name
            }
            return this.$refs["form"];
        },
        queryProjectSearch(queryString, cb) {
            var projectList = this.projectNameList;
            // 调用 callback 返回建议列表的数据
            cb(projectList);
        },
        handleSelect(item) {
            this.form.projectName = item;
            this.handleChangeName();
        },
        queryEngineeringSearch(queryString, cb) {
            var engineeringList = this.engineeringNameList;
            // 调用 callback 返回建议列表的数据
            cb(engineeringList);
        },
        handleEngineeringSelect(item) {
            this.form.engineeringName = item;
            this.handleChangeName();
        },
        getContractById() {
            //获取合同信息BY公司id
            InterfaceService.getContractByCorpId(
                { corpId: this.userInfo.corpId },
                data => {
                    if (data.respData.respCode == "0000") {
                        let record = data.respData.contractList;
                        let engineeringNameList = [];
                        //   let projectNameList = []
                        record.forEach((item, index) => {
                            if (item.engineeringName) {
                                engineeringNameList.push(item.engineeringName);
                            }
                            // if(item.projectName){
                            //   projectNameList.push(item.projectName)
                            // }
                        });

                        this.engineeringNameList = Array.from(
                            new Set(engineeringNameList)
                        );
                        //   this.projectNameList = Array.from(new Set(projectNameList));
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        // 获取采购商项目信息
        getProjectInfo() {
            const params = {
                corpId: this.userInfo.corpId
            };
            InterfaceService.getProjectInfo(
                params,
                data => {
                    if (data.respData.respCode == "0000") {
                        let list = data.respData.projectList || [];
                        this.projectNameList = list;
                        // BUG #5175 批量采购，填写项目信息，如果项目只有1个就不要让人家选了，直接显示在框框中
                        if (this.projectNameList.length === 1) {
                           const projectId = this.projectNameList[0] && this.projectNameList[0].projectId || ''
                           this.$set(this.form, 'projectId', projectId)
                           this.handleChangeProjectName()
                        }

                        this.form.buName = data.respData.buName;
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        getProjectMajor() {
           return new Promise((resolve)=>{
                InterfaceService.getProjectMajor(data => {
                    if (typeof data === "string") {
                        this.projectMajorList = eval("(" + data + ")");
                    } else if (typeof data === "object") {
                        this.projectMajorList = data;
                    }
                   // console.log('---获取专业名称：', this.projectMajorList);
                    resolve(this.projectMajorList)
                });
           })
        },
        getProjectCate() {
            return new Promise((resolve)=>{
                InterfaceService.getProjectCate(data => {
                    if (typeof data === "string") {
                        this.projectCateList = eval("(" + data + ")");
                    } else if (typeof data === "object") {
                        this.projectCateList = data;
                    }
                   // console.log('---获取合同类别：', this.projectCateList);
                    resolve(this.projectCateList)
                });
            });
        }
    },
    async mounted() {
        this.getContractById();
        await this.getProjectCate();
        await this.getProjectMajor();
        // 下拉数据返回后 调用反显数据方法
        this.handleChangeMajor(this.form.majorCode);
        this.handleChangeName();
        this.defaultAddressCode = {
            provCode: this.form.projectProvCode,
            cityCode: this.form.projectCityCode,
            blockCode: this.form.projectDistrictCode
        };
        // BUG #5166 GROUP_COMPANY_CODE 和 GROUP_COMPANY_NAME 显示问题
        this.getProjectInfo();
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-col {
    height: 102px;
}

/deep/ .el-input-group__append {
    background-color: #ffffff;
}

hr {
    margin-bottom: 16px;
    border: none;
    border-bottom: 1px dashed #ccc;
}
.panel-title {
    height: 50px;
    background-color: #f5f5f5;
    color: #4f525a;
    font-size: 16px;
    line-height: 50px;
    border-bottom: 2px solid #ffd64e;
    margin-bottom: 20px;
    font-weight: 700;
}
.panel-title span {
    position: relative;
    padding: 0 26px;
    display: inline-block;
    vertical-align: top;
    font-size: 14px;
}
.panel-title span:before {
    position: absolute;
    content: "";
    width: 100%;
    height: 2px;
    background-color: #444;
    left: 0;
    bottom: 0;
}

.form-item {
    /deep/ .el-input {
        width: 270px;
    }
}

.form-item-label {
    margin-bottom: 0px;
    font-size: 14px;
    line-height: 40px;
}
.el-row {
    overflow: inherit;
    .el-col {
        position: relative;
        .majorSelectListContainer {
            border: 1px solid #eaeaea;
            position: absolute;
            left: 356px;
            display: flex;
            padding: 0 12px 12px;
            background: #fff;
            box-shadow: 0 5px 5px rgba(0,0,0,.1);
            z-index: 2;
            min-width: 108px;
            &::before {
                content: '';
                position: absolute;
                width: 12px;
                height: 12px;
                background: #fff;
                margin-left: -20px;
                margin-top: 12px;
                transform: rotate(45deg);
                border: 1px solid #eaeaea;
                border-color: transparent transparent #eaeaea  #eaeaea;
                box-shadow: 0 5px 5px rgba(0,0,0,.1);
            }
            /deep/ .el-checkbox-group {
                display: flex;
                flex-direction: column;
                .el-checkbox + .el-checkbox {
                    margin-left: 0
                }
                .el-checkbox {
                    margin-top: 12px;
                }
            }
        }
    }
}

.form-item-large {
    /deep/ .el-input {
        width: 800px;
        input {
            border-top: none;
            border-left: none;
            border-right: none;
            border: none;
            text-overflow: ellipsis;
        }
    }
}

.project-name {
    padding: 20px;
    font-size: 15px;
    background: #dddddd;
}

.project-name-tip {
    margin: 20px 0;
}
</style>

