<template>
  <div>
    <!-- 发起终止结算单 -->
    <el-dialog class="aettle-accounts-dialog relieve-dialog" title="发起终止结算单" :append-to-body="true" :lock-scroll="true" :visible.sync="aettleAccountsTerminationDialog" width="850px" center :close-on-click-modal="false">
      <div class="f12">
        <p class="txt-left mb10">确认已和采购商达成一致，同意解除合同结算单，并下载查阅过合同结算单解除协议，点击【确认并发起】。就视作同意以下合同协议内容。</p>
        <dl>
          <dt>材料合同：</dt>
          <dd>《XXXXXXXXXXXXX合同结算单解除协议（一）》</dd>
        </dl>
        <div class="download-dialog-container">
          <span class="hand blue">下载合同结算单解除用印版</span>
          <span class="hand blue">查看合同解除结算单用印版</span>
          <span class="hand blue">下载附件</span>
        </div>
      </div>
      <div class="sign-result txt-center">
        <el-button class="normal-btn" type="primary" @click="handleClickConfirmRelieve('1')" style="width: 120px;">确认并发起</el-button>
        <el-button class="normal-btn" @click="aettleAccountsTerminationDialog = false" style="width: 120px;">下载解除协议</el-button>
        <el-button class="normal-btn" @click="aettleAccountsTerminationDialog = false" style="width: 120px;">关闭</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import { viewFile } from '@/utils/orderUtil';

const rescindForm = {
  refuseReason: ""
};

export default {
  components: {
    Loading
  },
  data() {
    return {
      isLoading: false,
      aettleAccountsTerminationDialog: false,
    };
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo || {};
    },
  },
  methods: {
    // 文件下载
    handleDownTemp(name, url) {
      this.$download([{
        name: name,
        url: url
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 在线预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    handleClickConfirmRelieve() {

    },
  }
};
</script>

<style lang="scss" scoped>
.info {
  color: #888888;
}
.dialog {
  /deep/ .el-form-item {
    margin-bottom: 0;
  }
  /deep/ .el-form-item__label {
    padding-right: 6px !important;
    line-height: 17px;
  }
  /deep/ .el-dialog__footer {
    padding-top: 0 !important;
  }
}
.error-info {
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
  position: absolute;
  top: 100%;
  left: 0;
}
</style>
