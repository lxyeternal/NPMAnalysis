<template>
  <div>
    <FixBottom>
      <div class="tc">
        <el-button style="width: 120px;" type="primary" @click="handleApply">审核通过</el-button>
        <el-button style="width: 120px;" @click="handleReject">退回</el-button>
        <!--<el-button style="width: 120px;" @click="handlePrev">上一款商品</el-button>-->
        <!--<el-button style="width: 120px;" @click="handleNext">下一款商品</el-button>-->
      </div>
    </FixBottom>
    <RejectDialog ref="RejectDialog" @refuseReason="getRefuseReason"></RejectDialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
  import FixBottom from "@/components/base/FixBottom";
  import RejectDialog from "@/components/base/dialog/RejectDialog";
  import Loading from "@/components/base/Loading";
  import { InterfaceService } from "@/services/api";

  export default {
    props:['spuId','skuId','baseInfoForm','approveType','isAngent'],
    name: "BrokerGoodsAudit",
    components:{
      Loading,
      FixBottom,
      RejectDialog,
    },
    data() {
      return {
        isLoading:false,
      }
    },
    methods:{
      getRefuseReason(refuseReason) {
        this.handleOperation('3',refuseReason)
      },
      handleOperation(type,refuseReason) {
        let param = {
          approveProductInfos:[{
            spuId:this.spuId,
            skuId:this.skuId,
            approveStatus:'1',
            approveType:this.approveType,
            isAngent:this.isAngent,
          }],
          approveStatus: type,
          approveMsg: refuseReason,//商品名/型号
          approver: this.$store.state.userInfo && this.$store.state.userInfo.acctId || '',
        };
        InterfaceService.auditGoods(param, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            this.$message.success('操作成功！');
            this.$emit('close',true)
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
      },
      handleNext(){

      },
      handlePrev(){

      },
      handleReject(){
        this.$refs.RejectDialog.open()
      },
      handleApply(){
        this.$confirm(
          "请确认"+this.baseInfoForm.spuName+(this.baseInfoForm.spuModel ? ("，型号："+this.baseInfoForm.spuModel) : '')+"符合要求，点击【确认通过】按钮，该商品直接上架。",
          "确认商品审核通过",
          {
            dangerouslyUseHTMLString: true,
            cancelButtonClass: "btn-custom-cancel",
            confirmButtonClass: "btn-custom-confirm",
            center: true,
            confirmButtonText: "确认通过",
            cancelButtonText: '取消',
          }).then(() => {
            this.handleOperation('2','')
        }).catch(() => {
        });
      },
    }
  }
</script>

<style scoped>

</style>