<template>
  <div>
    <transition name="el-zoom-in-bottom">
      <div class="batchSetUseProject" v-show="showBox">
        <div class="confirmContract" ref="confirmContract">
          <div class="content">
            <div class="title tc">批量设置限定使用项目</div>
            <div class="center">
              <p class="f12">请确认为已勾选{{list.length}}款商品批量设置限定使用项目。</p>
              <MultipleSelectorAll ref="multipleSelectorAllCfm" style="margin-top: 20px" @getData="getSupplierData" :isSearch="true" :dataList="projectList" :width="1190" :paddingHight="8" :labelWidth="110" :pageSize="pageSize" :totalCount="projectList.length" :label="'限定使用项目'" :placeholder="'请输入项目名称搜索'"></MultipleSelectorAll>
            </div>
          </div>
          <FixBottom class="bottom">
            <!-- 未设置过模拟清单 -->
            <div class="tc">
              <el-button :disabled="!projectInfos.length" type="primary" @click="confirm">确认</el-button>
              <el-button @click="close">取消</el-button>
            </div>
          </FixBottom>
        </div>
        <Loading :is-loading="isLoading"></Loading>
      </div>
    </transition>
  </div>
</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import FixBottom from "@/components/base/FixBottom";
import MultipleSelectorAll from "@/components/base/MultipleSelectorAll";
export default {
  components: {
    FixBottom, Loading, MultipleSelectorAll
  },
  data() {
    return {
      isLoading: false,

      list: [],
      pageSize: 5,
      showBox: false,
      projectInfos: [],// 限定使用项目
    }
  },
  props: ['projectList'],
  watch: {
    // 锁定父元素html的滚动
    showBox(val) {
      if (val) {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'hidden', 'important')
      } else {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'scroll', 'important')
      }
    },
  },
  methods: {
    getSupplierData(val) {
      this.projectInfos = []
      if (val.length) {
        val.forEach(i => this.projectInfos.push({
          projectId: i.projectId,
          projectName: i.projectName,
          projectStageId: i.projectStageId,
          projectStageName: i.projectStageName,
          groupCompanyCode: i.groupCompanyCode,
          groupCompanyName: i.groupCompanyName,
        }))
      }
      console.log(this.projectInfos)
    },
    confirm() {
      this.batchSetProject()
    },
    batchSetProject() {
      let productInfos = []
      this.list.forEach(i => {
        productInfos.push({
          spuId: i.spuId,
          skuId: i.skuId,
          corpId: i.corpId || i.supplierId,
          approveType: i.approveType,
          approveStatus: i.approveStatus
        })
      })
      let param = {
        productInfos: productInfos,
        isUsedAll: this.projectInfos.length === this.projectList.length ? '1' : '0' //是否是全部项目 （1-是，0-否）
      }
      if (this.projectInfos.length !== this.projectList.length) {
        param.projectInfos = this.projectInfos
      }
      InterfaceService.batchSetProject(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('设置成功');
          this.close()
          this.$emit('upDate')
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    close() {
      this.projectInfos = []
      this.$refs.multipleSelectorAllCfm.clear()
      this.showBox = false
    },
    open(list = []) {
      console.log(list)
      this.list = this.$clone(list)
      this.showBox = true
    }
  },
}
</script>
<style lang="scss" scoped>
.batchSetUseProject {
  .el-col {
    width: inherit;
  }
}
.batchSetUseProject {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .confirmContract {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    height: 80%;
    overflow-x: hidden;
    overflow-y: auto;
    max-height: 610px;
    .content {
      width: 1190px;
      margin: 0 auto 100px;
      font-size: 14px;
      line-height: 17px;
      height: 500px;
      .title {
        padding: 20px 0;
        border-bottom: 1px solid #eee;
        margin-bottom: 20px;
      }
    }
  }
}
</style>