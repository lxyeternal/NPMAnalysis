<template>
  <div>
    <!-- 草稿箱列表 -->
    <el-dialog class="dialog dialog-drafts" title="" :append-to-body="true" :lock-scroll="true" :visible.sync="draftsDialogVisible" width="840px" center :close-on-click-modal="true" v-show="showDialog" @close="cancelDraftsDialog">
      <PanelTitle class="panel-title" :tabs="tabs" :textAlign="'left'" :bgColor="'#fff'" @select="handleChangeTab"></PanelTitle>
      <div v-if="tab == 1" class="table">
        <!--<div class="drafts-list">-->
          <!--<ul>-->
            <!--<li class="drafts-li title">-->
              <!--<div class="drafts-name">草稿名称</div>-->
              <!--<div class="drafts-date">创建时间</div>-->
              <!--<div class="drafts-btn"></div>-->
            <!--</li>-->
            <!--<li class="drafts-li" v-for="(item,index) in draftsList.filter((f, idx)=> idx < 5)" :key="index">-->
              <!--<div class="drafts-name">{{item.draftName}}</div>-->
              <!--<div class="drafts-date">{{item.draftCreatTime}}</div>-->
              <!--<div class="drafts-btn">-->
                <!--<el-button type="primary" size="small" style="width: 100px" @click="openDrafts(item.id)">-->
                  <!--打开-->
                <!--</el-button>-->
              <!--</div>-->
            <!--</li>-->

          <!--</ul>-->
        <!--</div>-->
        <div v-if="draftsList.length">
          <table class="drafts-list">
            <thead>
            <tr class="drafts-li title tc">
              <td class="drafts-name">草稿名称</td>
              <td class="drafts-date">创建时间</td>
              <td class="drafts-btn"></td>
            </tr>
            </thead>
            <tbody>
            <tr class="drafts-li" v-for="(item,index) in draftsList.filter((f, idx)=> idx < 5)" :key="index">
              <td class="drafts-name tl">
                {{item.draftName}}
                <p>
                  <span>
                    <span class="nailsupply" v-if="item.busiTypeDisc">{{item.busiTypeDisc}}</span>
                  </span>
                </p>
              </td>
              <td class="drafts-date tl">{{item.draftCreatTime}}</td>
              <td class="drafts-btn">
                <el-button type="primary" size="small" style="width: 100px" @click="openDrafts(item.id, item)">
                  打开
                </el-button>
              </td>
            </tr>
            </tbody>
          </table>
          <div class="tr more-drafts">
            <span class="blue hand" @click="goDraftsList()">更多清单草稿</span>
          </div>
        </div>
        <div v-else style="overflow-y: hidden">
          暂无清单草稿
        </div>
      </div>
      <div v-if="tab === 2 " class="table">
        <table class="drafts-list" v-if="selectionList.length">
          <thead>
            <tr class="drafts-li tc title">
              <td class="selection-name">选型清单</td>
              <td class="selection-other">供应商名称</td>
              <td class="selection-other">选型项目</td>
              <td class="selection-time">更新时间</td>
              <td class="selection-btn"></td>
            </tr>
          </thead>
          <tbody>
          <tr class="drafts-li tl" v-for="(item,index) in selectionList" :key="index">
            <td class="selection-name"><span class="blue hand" @click="handleSeeFile(item)">{{item.attachName}}</span></td>
            <td class="selection-other">{{item.corpName}}</td>
            <td class="selection-other">{{item.selectionName}}</td>
            <td class="selection-time">{{item.uptTm && item.uptTm.substring(0,item.uptTm.length-3)}}</td>
            <td class="selection-btn">
              <el-button type="primary" size="small" style="width: 100px" @click="openSelectionDia(item)">
                导入
              </el-button>
            </td>
          </tr>
          </tbody>
        </table>
        <div v-else style="overflow-y: hidden">
          暂无可快速采购的选型清单
        </div>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 100px" @click="cancelDraftsDialog(1)">去采购
        </el-button>
        <el-button size="small" style="width: 100px" @click="cancelDraftsDialog">取消</el-button>
      </div>
    </el-dialog>
    <SelectionQuickBuy ref="SelectionQuickBuy" @goBack="goBack"></SelectionQuickBuy>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { InterfaceService } from '@/services/api'
import Loading from '@/components/base/Loading'
import PanelTitle from "@/components/base/PanelTitle";
import { viewFile } from '@/utils/orderUtil';
import SelectionQuickBuy from "@/components/onlineModelSelection/dialog/SelectionQuickBuy";
import accountMixin from "@/mixins/account";

export default {
    mixins:[accountMixin],
    props: ['value'],
  components: {
    Loading,
      SelectionQuickBuy,
      PanelTitle
  },
  data() {
    return {
      isLoading: false,
        showDialog: this.value || false,
      draftsList: [], // 草稿箱列表数据
      selectionList: [], // 选型清单数据
      draftsDialogVisible: this.value || false,
      tabs: [
          { label: "最近的清单草稿", index: 1, active: true },
      ],
        tab :1
    }
  },
  mounted() {
      if (this.groupCompanyCode === 'GREENLANDHK') {
          this.tabs= [
              { label: "最近的清单草稿", index: 1, active: true },
              { label: "选型清单", index: 2 },
          ]
      }else {
          this.tabs= [
              { label: "最近的清单草稿", index: 1, active: true },
          ]
      }
    this.getDraftsList()
  },
  methods: {
    /**
     * 取消
     */
    cancelDraftsDialog(state) {
      this.$emit('input', false)
      if (state === 1) {
        this.$emit('showSelectSupplier', true)
      }
    },
      goBack(bool){
        this.showDialog = bool
      },
      // 修改tab
      handleChangeTab(tab) {
          this.tab = tab.index;
      },

    /**
     * 更多草稿
     */
    goDraftsList() {
      this.$router.push('/purchaserCenter/orderDraftsList')
    },

    /**
     * 获取草稿箱数据
     */
    getDraftsList() {
      return new Promise(resolve => {
        if (this.$route && this.$route.query && this.$route.query.state) {
          resolve(false)
          return
        }
        InterfaceService.getDraftsList({}, data => {
          if (data.respData.respCode == '0000') {
            this.draftsList = data.respData.draftBoxInfos;
              this.draftsList.forEach(item => {
                  if (item.busiType === "SUB_ORDER") {
                      item.busiTypeDisc = "增补商品"
                  }else {
                      item.busiTypeDisc = ""
                  }
              });
            // 如果清单中没有数据 则直接创建清单
              if (this.groupCompanyCode !== 'GREENLANDHK') {
                  !this.draftsList.length && this.cancelDraftsDialog(1)
              }else {
                  this.getMargeList();
              }
          } else {
            this.$message.error(data.respData.respMsg);
          }
          resolve(data.respData)
        }, data => {

        }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        }
        );
      })
    },
      //获取汇总版选型清单
      getMargeList() {
          return new Promise(resolve => {
              if (this.$route && this.$route.query && this.$route.query.state) {
                  resolve(false);
                  return
              }
              InterfaceService.selectionMargeList({}, data => {
                  let res = data.respData
                      if (res.respCode == '0000') {
                          this.selectionList = [];
                          let list = res.selectionList || [];
                          list.forEach(item=>{
                              if (item.listType === "MERGE_LIST") {
                                  this.selectionList.push(item)
                              }
                          });
                          if (this.selectionList.length) {
                              this.selectionList = this.selectionList.sort(this.compare);
                          }
                          !this.draftsList.length && !this.selectionList.length && this.cancelDraftsDialog(1)
                      } else {
                          this.$message.error(data.respData.respMsg);
                      }
                      resolve(res)
                  }, data => {

                  }, () => {
                      this.isLoading = true;
                  }, () => {
                      this.isLoading = false;
                  }
              );
          })
      },
      compare (obj1, obj2) {
          let val1 = obj1.uptTm;
          let val2 = obj2.uptTm;
          if (val1 > val2) {
              return -1;
          } else if (val1 < val2) {
              return 1;
          } else {
              return 0;
          }
      },
      openSelectionDia(item) {
          const params = {
              selectionNo : item.selectionNo,
              supplierId : item.corpId,
          };
          InterfaceService.selectionFileDownload(
              params,
              data => {
                  let res = data.respData|| {};
                  if (data && data.respData && res.respCode === "0000") {
                      let selectionInfo = res && res.supplierDetailList[0].selectionAttachList[0];
                      item = Object.assign(item,selectionInfo);
                      this.$refs["SelectionQuickBuy"].open(item,"quickBox");
                      this.showDialog = false
                  } else {
                      this.$message.error(data.respData.respMsg)
                  }
              }, data => {
                  this.$message.error(data.respData.respMsg)
              },
              () => {
                  this.isLoading = true
              }, (

              ) => {
                  this.isLoading = false
              }
          )
      },
      handleSeeFile(item) {
          if (item.attachUrl) {
              viewFile(item.attachUrl)
          }
      },
    /**
     * 草稿清单 -》打开草稿
     */
    openDrafts(id, item) {
      this.$setRootScope('forbidBack', 'true')
      this.$setRootScope('newest', true)
      this.$router.push({
        path: "/transfer",
        query: {
          query: JSON.stringify({ draftsId: id }), // newest 拉去最新货单数据
          path: item.busiType === 'ORDER' ? '/quickPurchase' : '/initiateASupplement',
        }
      });
    },
  },
}
</script>
<style lang="scss" scoped>
// 草稿箱
.dialog-drafts {
  /deep/ .el-dialog__header {
    &:before {
      height: 0;
    }
    position: absolute;
    width: 80px;
    z-index: 9999;
    right: 0;
  }
  .drafts-list{
    width: 100%;
    td{
      padding: 10px;
    }
  }
  .drafts-li {
    border-bottom: 1px solid #fff;
    background-color: #eeeeee;
    font-size: 14px;
    color: #444;
    div{
      display: inline-block;
      white-space: nowrap;
      text-overflow: ellipsis;
      padding: 0 20px;
    }

    /*&:first-child {*/
      /*height: 34px;*/
      /*line-height: 34px;*/
      /*background-color: #fff;*/
      /*font-size: 14px;*/
      /*color: #888;*/
    /*}*/
    .drafts-name {
      width: 40%;
    }
    .drafts-name,
    .drafts-date,
    .drafts-btn {

    }
    .drafts-btn {
      width: 36%;
      text-align: right;
    }
    .selection-name {
      width: 30%;
    }
    .selection-other {
      width: 17.5%;
    }
    .selection-time {
      width: 11.5%;
    }
    .selection-btn {
      width: 14.5%;
    }
  }
  .title{
    padding: 0 20px;
    background: #fff;
  }
  .more-drafts {
    height: 54px;
    line-height: 54px;
  }
  .table{
    margin-top: -15px;
    max-height: 400px;
    overflow-y: auto;
    table{
      line-height: 23px;
      td {
        vertical-align: middle;
        word-break: break-word;
      }
    }
  }
}
.nailsupply {
  font-size: 12px;
  max-width: 100%;
  min-height: 14px;
  padding: 0 6px;
  line-height: 14px;
  border: 1px solid #04c93c;
  border-radius: 7px;
  color: #04c93c;
  margin-right: 6px;
}
</style>

