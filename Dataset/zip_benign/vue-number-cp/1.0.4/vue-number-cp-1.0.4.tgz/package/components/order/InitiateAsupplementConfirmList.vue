<template>
  <div class="confirmInitiate-body-com">
    <table v-if="dataList.filter(f=> f.priceModel != 'floatingPrice').length">
      <thead>
        <tr :style="{background: headBgColor}">
          <td width="80">序号</td>
          <td width="130">型号</td>
          <td width="200" class="tl">品牌/商品名称</td>
          <td width="100">补充采购量</td>
          <td width="140" class="alignRight">税前单价(元)</td>
          <td width="140" class="alignRight">
            暂定税率
            <el-tooltip effect="dark" placement="top">
              <div slot="content">
                税率为暂定税, 以实际开票税率为准。
              </div>
              <i class="el-icon-question tooltip-name"></i>
            </el-tooltip>
          </td>
          <td width="140" class="alignRight">税前运费(元)</td>
          <td width="140" class="alignRight">税前总价(元)</td>
        </tr>
      </thead>
      <tbody v-if="showHeadInfo">
        <tr class="bean-head">
          <td colspan="8" height="20">
            <div class="left">
              <span>供应商：{{corpInfo.corpName}}</span>
              <span class="blue" @click="downloadQuickSelectionList">下载货品清单</span>
            </div>
            <div class="right">
              <span>税前总价(元)：{{preTax || 0 | formatMoney}}</span>
              <span class="telescopic" :class="{off: !isExpandTable}" @click="handleExpandChange">{{isExpandTable ? '收起' : '展开'}}</span>
            </div>
          </td>
        </tr>
      </tbody>
      <tbody v-show="isExpandTable">
        <tr :style="{background: bodyBgColor}" v-for="(item, idx) in dataList.filter(f=> f.priceModel != 'floatingPrice')" :key="idx">
          <td>
            <div class="new-flag" v-if="item.newFlag">NEW</div> {{idx + 1}}
          </td>
          <td>{{item.model}}</td>
          <td>
            <p>{{ item.brandName }}</p>
            <p>{{ item.skuName }}</p>
          </td>
          <td :class="{red: Number(item.buyCount) < 0}">{{item.buyCount}} {{item.goodsUnit}}</td>
          <td class="alignRight" :class="{red: item.price <= 0}">{{ item.price >= '0' ? '+':''}}{{item.price | formatMoney}} </td>
          <td class="alignRight">{{numberUtilAccMul(item.taxRate, 100)}}%</td>
          <td class="alignRight">{{item.outLogisticsAmount | formatMoney}}</td>
          <td class="alignRight" :class="{red: item.outTotalAmt <= 0}">{{ item.outTotalAmt >= '0' ? '+':''}}{{item.outTotalAmt | formatMoney}}</td>
        </tr>
      </tbody>
    </table>

    <table v-if="dataList.filter(f=> f.priceModel == 'floatingPrice').length">
      <thead>
        <tr :style="{background: headBgColor}">
          <td width="80">
            序号
          </td>
          <td width="130">型号</td>
          <td width="150" class="tl">品牌/商品名称</td>
          <td width="100">补充采购量</td>
          <td width="100" class="alignRight">税前模拟基价(元)</td>
          <td width="100" class="alignRight">税前浮动价(元)</td>
          <td width="100" class="alignRight">税前综合单价(元)</td>
          <td width="140" class="alignRight">
            暂定税率
            <el-tooltip effect="dark" placement="top">
              <div slot="content">
                税率为暂定税, 以实际开票税率为准。
              </div>
              <i class="el-icon-question tooltip-name"></i>
            </el-tooltip>
          </td>
          <td width="120" class="alignRight">税前运费(元)</td>
          <td width="120" class="alignRight">税前总价(元)</td>
        </tr>
      </thead>
      <tbody v-if="showHeadInfo && !dataList.some(s=> s.priceModel != 'floatingPrice')">
        <tr class="bean-head">
          <td colspan="11" height="20">
            <div class="left">
              <span>供应商：{{corpInfo.corpName}}</span>
              <span class="blue" @click="downloadQuickSelectionList">下载货品清单</span>
            </div>
            <div class="right">
              <span>税前总价(元)：{{preTax || 0 | formatMoney}}</span>
              <span class="telescopic" :class="{off: !isExpandTable}" @click="handleExpandChange">{{isExpandTable ? '收起' : '展开'}}</span>
            </div>
          </td>
        </tr>
      </tbody>
      <tbody v-show="isExpandTable">
        <tr :style="{background: bodyBgColor}" v-for="(item, idx) in dataList.filter(f=> f.priceModel == 'floatingPrice')" :key="idx">
          <td>
            <div class="new-flag" v-if="item.orderCnt || item.newFlag">NEW</div> {{idx + 1}}
          </td>
          <td>{{item.model}}</td>
          <td>
            <p>{{ item.brandName }}</p>
            <p>{{ item.skuName }}</p>
          </td>
          <td :class="{red: Number(item.buyCount) < 0}">{{item.buyCount}} {{item.goodsUnit}}</td>
          <td class="alignRight">
            <div v-if="item.basicPrice">{{item.basicPrice | formatMoney}}</div>
            <div v-else>{{item.price | formatMoney}} </div>
          </td>
          <td class="alignRight">
            {{Number(item.floatRange) | formatMoney}}
            <span class="priceContrast" v-if="!item.lowerShelf && item.floatPriceContrast" :title="item.floatPriceContrast">
              {{item.floatPriceContrast}}
            </span>
          </td>
          <td class="priceContainer">
            <div class="alignRight">
              <p>
                <span :class="{red: Number(item.basicPrice || item.price ||0) + Number(item.floatRange || 0) <= 0}">
                  {{ Number(item.basicPrice || item.price ||0) + Number(item.floatRange || 0) >= '0' ? '+':''}}
                  {{Number(item.basicPrice || item.price ||0) + Number(item.floatRange || 0) | formatMoney}}
                </span>
                <b class="red-num-tip red" v-show="Number(item.basicPrice || item.price || 0) + Number(item.floatRange || 0) <= '0'">综合单价不能为0或者负数</b>
                <el-tooltip effect="dark" placement="top">
                  <div slot="content">
                    <p class="tooltipPriceTarget">{{item.priceTarget}}</p>
                    <p>综合单价：模拟基价+浮动价</p>
                  </div>
                  <i class="el-icon-question tooltip-name"></i>
                </el-tooltip>
              </p>
            </div>
          </td>
          <td class="alignRight"><span :class="{'red':+item.taxRate !== 0.13}">{{item.taxRate | formatPercentage}}</span></td>
          <td class="alignRight">{{item.outLogisticsAmount | formatMoney}}</td>
          <td class="alignRight" :class="{red: item.outTotalAmt <= 0}">{{ item.outTotalAmt >= '0' ? '+':''}}{{item.outTotalAmt | formatMoney}}</td>
        </tr>
      </tbody>
    </table>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import { NumberUtil } from '@/utils/numberUtil';
import Loading from '@/components/base/Loading'
import { InterfaceService } from "@/services/api";
export default {
  components: { Loading },
  props: {
    // 是否显示头部 - 收缩栏
    showHeadInfo: {
      type: Boolean,
      default: true
    },
    // 头部 背景色
    headBgColor: {
      type: String,
      default: '#fff'
    },
    // 主体 背景色
    bodyBgColor: {
      type: String,
      default: '#f5f5f5'
    },
    // 显示数据
    dataList: {
      type: Array,
      default() { [] }
    },
    // 供应商信息
    corpInfo: {
      type: Object,
      default() { [] }
    },
    preTax: {
      type: [String, Number],
      default: ''
    }
  },
  data() {
    return {
      isLoading: false,
      isExpandTable: true, // 是否展开
    };
  },
  computed: {
    numberUtilAccMul() {
      return (arg1, arg2, fun = 'accMul') => {
        return NumberUtil[fun](Number(arg1), Number(arg2))
      }
    },
  },
  mounted() {
    console.log(this.dataList, 'InitiateAsupplementConfirmListDataList');
  },
  methods: {
    handleExpandChange() {
      this.isExpandTable = !this.isExpandTable
    },

    /**
     * 下载选型清单
     */
    async downloadQuickSelectionList() {
      this.isLoading = true;
      InterfaceService.downloadQuickSelectionList({ draftBoxId: this.corpInfo.draftBoxId }, data => {
        if (data.respData.respCode == '0000') {
          this.$download([{
            name: data.respData.attachName || '',
            url: data.respData.attachUrl || ''
          }]).then(() => {
            this.$message.success("已下载");
          })
        } else {
          this.$message.error(data.respData.respMsg);
        }
      }, data => {
      }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
  }
};
</script>

<style lang="scss" scoped>
.confirmInitiate-body-com {
  .mt20 {
    margin-top: 20px;
  }
  .bb0 {
    border-bottom: 0 !important;
  }
  .head-title {
    height: 50px;
    line-height: 50px;
    position: relative;
    border-bottom: 2px solid #ffd64e;
    background-color: #f5f5f5;
    color: #4f525a;
    span {
      position: absolute;
      padding: 0 24px;
      left: 0;
      border-bottom: 2px solid #444;
      font-size: 14px;
      font-weight: bold;
      height: 50px;
    }
  }
  .contract-name {
    font-size: 12px;
    color: #444;
    padding: 20px 0px;
    border-bottom: 1px solid #eee;
    span {
      color: #999;
    }
    i {
      font-style: normal;
      cursor: pointer;
    }
  }
  .contract-group {
    border-bottom: 1px solid #eee;
    .order-info-title {
      margin: 20px 0 10px;
      padding: 0 10px;
      font-size: 14px;
      border-left: 3px solid #000;
      line-height: 12px;
    }
    .introduction-center {
      background: #fef4f3;
      padding: 0 8px 12px;
      margin-bottom: 20px;
      ul {
        display: flex;
        flex-wrap: wrap;
        li {
          width: 50%;
          margin-top: 12px;
          font-weight: bold;
        }
      }
    }
    .recipient-information {
      li {
        margin-top: 14px;
        span {
          &:first-child {
            color: #999;
          }
        }
      }
    }
  }

  table {
    width: 100%;
    line-height: 23px;
    font-size: 12px;
    background-color: #fff;
    thead {
      td {
        padding: 2px 2px 6px;
      }
    }
    tbody {
      .bean-head {
        background: #eee;
        margin-bottom: 0;
      }
      td {
        &:first-child {
          overflow: hidden;
          .new-flag {
            position: absolute;
            color: #fff;
            background: #e00;
            width: 100px;
            font-weight: bold;
            text-align: center;
            transform: rotate(-45deg) scale(0.8);
            left: -39px;
            top: 0px;
            font-size: 12px;
          }
        }
      }
    }
    td {
      padding: 18px 10px;
      vertical-align: middle;
      word-break: break-word;
      text-align: left;

      .left-button {
        float: right;
        margin-left: 10px;
      }
      &.alignRight {
        text-align: right;
        p {
          text-align: right;
        }
      }
    }

    thead {
      font-size: 14px;
      text-align: center;
      white-space: nowrap;
      color: #909399;
      background: #fff;
    }

    tbody {
      text-align: center;
      margin-bottom: 10px;

      tr {
        background-color: #f5f5f5;
        position: relative;
        &.bean-head {
          td {
            padding: 6px 12px;
            .left {
              float: left;
            }
            .right {
              float: right;
              color: #888;
            }
            .blue {
              cursor: pointer;
              text-decoration: underline;
              margin-left: 4px;
            }
            .telescopic {
              position: relative;
              cursor: pointer;
              margin-left: 22px;
              padding-right: 8px;
              &::after {
                content: "";
                border-width: 3px;
                border-style: solid;
                border-color: #888 #888 transparent transparent;
                position: absolute;
                margin-top: 9px;
                margin-left: 4px;
                transform: rotate(-45deg);
                transition: all 0.3s linear;
              }
              &.off {
                &::after {
                  transform: rotate(135deg);
                  margin-top: 6px;
                }
              }
            }
          }
        }
        &.delete-tips {
          background: #ffe9eb;

          td {
            padding: 10px;

            &:hover {
              background: #ffe9eb !important;
            }
          }
        }

        &.template-alert {
          td {
            &:before {
              content: "";
              width: 100%;
              height: 18px;
              position: absolute;
              background: #ffdfe0;
              color: red;
              bottom: 0;
              left: 0;
              line-height: 18px;
              z-index: 10;
            }

            &:nth-child(4):before {
              content: "！该产品无法配送到";
              text-align: right;
            }
            &:nth-child(5):before {
              content: "您选择的地址";
              text-align: left;
            }
          }
        }

        &.error-td {
          background: #ffdfe0;
        }
      }

      tr:last-child {
        border-bottom: 1px solid #fff;
      }

      tr:hover {
        background: #e8f3fd !important;
      }

      td {
        border-bottom: 1px solid #fff;
        position: relative;
        &.account {
          input {
            width: 80%;
          }
        }

        .red-num-tip {
          position: absolute;
          bottom: 0;
          left: 0;
          width: 100%;
          height: 18px;
          line-height: 18px;
          z-index: 9;
          white-space: pre;
        }
      }
    }
  }
}


.alignRight {
  text-align: right;
  p {
    text-align: right;
  }
}
</style>
