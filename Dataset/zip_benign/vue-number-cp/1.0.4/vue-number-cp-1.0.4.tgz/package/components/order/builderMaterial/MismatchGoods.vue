<template>
    <div class="content">
        <PanelTitle :title="title"></PanelTitle>
        <div class="table">
            <table>
                <thead>
                    <tr>
                        <td width="100">申请单序号</td>
                        <td>材料类目</td>
                        <td>货品名称</td>
                        <td>使用标段</td>
                        <td>型号</td>
                        <td>物料描述</td>
                        <td>本次申请数量</td>
                        <td width="150"></td>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="(row,index) in list" :key="index" :class="{'offline':type==='offline'}">
                        <td>{{row.no}}</td>
                        <td>{{row.categoryFullName}}</td>
                        <td>{{row.materialName}}</td>
                        <td>{{row.location}}</td>
                        <td>{{row.model}}</td>
                        <td>{{row.description}}</td>
                        <td>{{row.applyCount}}{{row.unit}}</td>
                        <td class="operate">
                            <template v-if="type==='todo'">
                                <a @click="handleManualMatch(row)">手动匹配</a>
                                <a @click="handleMove(row, index, 'offline')">线下要货</a>
                            </template>
                            <template v-else>
                                <a @click="handleMove(row, index, 'todo')">移至待匹配</a>
                            </template>

                        </td>
                    </tr>
                </tbody>
            </table>
            <p v-if="type==='todo'" class="tip">注：待匹配的货品，将不列入发起要货清单中。</p>
            <p v-if="type==='offline'" class="tip">注：匹配失败区域的货品，将不列入发起要货清单中，可下载供线下发起的《发货通知单》，线下向供应商发起要货。</p>
        </div>
        <!-- 手动匹配 -->
        <ManualMatchDialog ref="manualMatch" @close="handleCloseManual"></ManualMatchDialog>
    </div>
</template>

<script>
import PanelTitle from "@/components/base/PanelTitle";
import ManualMatchDialog from "@/components/order/builderMaterial/ManualMatchDialog";
export default {
    components: {
        PanelTitle,
        ManualMatchDialog
    },
    props: ["type", "list"],
    data() {
        return {};
    },
    computed: {
        title() {
            return this.type == "todo" ? "待匹配货品区" : "线下要货区";
        }
    },
    methods: {
        handleManualMatch(row, index) {
            const data = row;
            data.index = index;
            this.$refs["manualMatch"].open(data);
        },
        handleCloseManual(data) {
            if (data) {
                const material = {
                    position: "match",
                    index: data.index
                };
                delete data.index;
                material.data = data;
                this.$emit("move", material);
            }
        },
        // 移至
        handleMove(row, index, position) {
            const material = {
                position: position,
                index: index,
                data: row
            };
            this.$emit("move", material);
        }
    },
    mounted() {}
};
</script>

<style lang="scss" scoped>
.tip {
    line-height: 40px;
}

.content {
    margin-bottom: 30px;
}
.table {
    margin-bottom: 2px;
    　 /deep/ .el-button {
        font-size: 12px;
    }

    width: 100%;
    line-height: 23px;
    font-size: 12px;
    table {
        width: 100%;
    }
    td {
        padding: 14px 10px;
        vertical-align: middle;
        word-break: break-word;
    }

    thead {
        text-align: center;
        white-space: nowrap;
        font-size: 14px;
        color: #909399;
    }

    tbody {
        text-align: center;

        tr:hover {
            background: #e8f3fd;
        }

        td {
            border-bottom: 1px solid #ffffff;
            background: #f5f5f5;
        }
    }

    tr.offline td {
        background: #cccccc;
    }
}

.operate {
    a {
        display: inline-block;
        margin-right: 10px;
        white-space: nowrap;
        color: #0082ff;
    }

    a:last-child {
        margin-right: 0;
    }
}
</style>
