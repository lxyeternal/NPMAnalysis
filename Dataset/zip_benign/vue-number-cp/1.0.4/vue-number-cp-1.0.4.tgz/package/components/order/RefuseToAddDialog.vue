<template>
  <div>
    <!-- 拒绝增补清单 -->
    <el-dialog :title="isRefuse?'填写选择拒绝增补商品原因':'填写取消增补商品原因'" :append-to-body="true" :lock-scroll="true" @close="handleCancel" :visible="refuseToAddDialogVisible" width="770px" center :close-on-click-modal="false">
      <ul class="drafts-list refuse-to-add">
        <li>
          <span class="title">{{isRefuse ? '已选填补清单' : (selectedList && selectedList.length) ? '选择取消清单' : '已选取消清单'}}</span>
          <span class="disabled" v-if="!(selectedList && selectedList.length)">{{selectedValue}}</span>
          <el-select v-else multiple v-model="selectedListValue" placeholder="请选择" @change="handleSelectedListChange">
            <el-option v-for="item in selectedList" :key="item.value" :label="item.label" :value="item.value">
              <span style="float: left">{{ item.label }}</span>
              <span class="option-right" style="float: right" @click.stop="handlePreview(item)">预览</span>
            </el-option>
          </el-select>
        </li>
        <li>
          <span class="title">{{isRefuse ? '拒绝' : '取消'}}原因</span>
          <el-select v-model="refuseDialogValue" placeholder="请选择" @change="handleRefuseChange">
            <el-option v-for="(option, idx) in internalRefuseDialogOptions" :key="idx" :label="option" :value="option"> </el-option>
          </el-select>
        </li>
        <li v-if="refuseDialogValue == '其他'">
          <el-input type="textarea" :rows="6" placeholder="请输入..." v-model="messageTextarea" />
        </li>
      </ul>

      <div slot="footer" class="dialog-footer">
        <el-button type="primary" size="small" style="width: 100px" @click="handleConfirmAndSubmit">确认并提交</el-button>
        <el-button size="small" style="width: 100px" @click="handleCancel">取消</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import { viewFile } from '@/utils/orderUtil';

export default {
  props: ['isRefuse', 'refuseToAddDialogVisible', 'refuseDialogOptions', 'selectedValue', 'selectedList'],
  data() {
    return {
      messageTextarea: '',
      refuseDialogValue: '',
      selectedListValue: '',
      internalRefuseDialogOptions: [],
    };
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {

      if (!(this.refuseDialogOptions && this.refuseDialogOptions.length)) {
        this.internalRefuseDialogOptions = [
          "生产周期太紧，短期无法安排合同生产",
          "原料不足，来不及生产",
          "成本上涨，此单做不了",
          "此款已停产，不能接合同",
          "其他"
        ]
      } else {
        this.internalRefuseDialogOptions = this.refuseDialogOptions
      }

      // 默认显示第一条
      if (this.selectedList && this.selectedList.length === 1) {
        this.selectedListValue = [this.selectedList[0].value]
        console.log(this.selectedListValue, 'selectedListValue');

      }

    },

    /**
     * 确认并提交
     */
    handleConfirmAndSubmit() {
      if (this.selectedList && this.selectedList.length && !this.selectedListValue.length) {
        this.$message.error(`请选择取消清单`)
        return
      }

      if (!this.refuseDialogValue) {
        this.$message.error(`请选择${this.isRefuse ? '拒绝' : '取消'}原因`)
        return
      }

      if (this.refuseDialogValue == '其他' && !this.messageTextarea) {
        this.$message.error(`请填写${this.isRefuse ? '拒绝' : '取消'}原因`)
        return
      }

      this.$emit('outputSelected', this.refuseDialogValue == '其他' ? this.messageTextarea : this.refuseDialogValue, this.selectedListValue || '')
    },

    /**
     * 取消
     */
    handleCancel() {
      this.$emit('update:refuseToAddDialogVisible', false);
    },

    /**
     * 拒绝原因 选择 改变
     */
    handleRefuseChange() {
      this.messageTextarea = ''
    },


    /**
     * 选择 清单
     */
    handleSelectedListChange() {
    },

    /**
     * 预览
     */
    handlePreview(item) {
      if (item.attachUrl) {
        viewFile(item.attachUrl)
      }
    },
  }
};
</script>

<style lang="scss" scoped>
.refuse-to-add {
  li {
    font-size: 14px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 22px;
    span {
      &.title {
        color: #999;
        width: 13%;
        text-align: right;
      }
      &.disabled {
        border: 1px solid #ddd;
        background: #eaeaea;
        width: 86%;
        padding: 10px 12px;
      }
    }

    /deep/ .el-select {
      width: 86%;
    }
    /deep/ .el-textarea {
      textarea {
        width: 86%;
        float: right;
      }
    }
  }
}
/deep/.option-right {
  color: #0082ff;
  z-index: 1;
  position: absolute;
  right: 8px;
}
</style>
