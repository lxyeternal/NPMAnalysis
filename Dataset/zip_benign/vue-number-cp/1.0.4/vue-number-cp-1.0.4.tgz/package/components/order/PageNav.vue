<template>
  <div class="pageNav">
    <ul>
      <li :class="{'active':choosed == index}" v-for="item,index in navigation" @click="jump(index)">
        <span></span>
        {{item.name}}
      </li>
    </ul>
    <div class="vertical"></div>
  </div>
</template>

<script>
// import $ from 'jquery'
export default {
  props:{
    navigation:{
      type: Array
    },
    change:{
      type: Number
    }
  },
  watch:{
    change(){
      this.arrTop = []
      this.navigation.forEach((item,index)=>{
        this.arrTop.push($('.'+item.position).offset().top)
      })
    }
  },
  data () {
    return {
      choosed:'0',
      arrTop:[]
    }
  },
  methods:{
    jump(ind){
      //this.choosed = index;
      let topNum = 0;
      this.navigation.forEach((item,index)=>{
        if( ind == index ){
          topNum = $('.'+item.position).offset().top
        }
      })
      /*if( ind == this.navigation.length-1 ){
        this.choosed = ind
      }*/
      $('html ,body').animate({scrollTop: topNum}, 300);
    },
    pageScroll(){
      let documentTop = document.documentElement.scrollTop;
      let documentHeight = document.documentElement.scrollHeight;
      let documentClientHeight = document.documentElement.clientHeight;

      this.arrTop.forEach( (item,index)=>{
        if( documentTop > (item-100) ){
          this.choosed = index;
        }
      } )
      if( documentTop < this.arrTop[0] ){
        this.choosed = 0
      }
      if( (documentTop+documentClientHeight) == documentHeight){
        this.choosed = this.navigation.length-1
      }
    }
  },
  mounted(){
    window.addEventListener('scroll', this.pageScroll)
    this.$el.querySelector('.vertical').style.height= (this.navigation.length * 34 - 30) + 'px';
    let self = this;
     // console.log(this.navigation);
      setTimeout(function(){
        self.navigation.forEach((item,index)=>{
          try {
            self.arrTop.push($('.'+item.position).offset().top)
          } catch (error) { }
        })
      },400)
  },
  //离开当前页面后执行
  destroyed: ()=> {
      window.removeEventListener('scroll', this.pageScroll)
  }
}
</script>

<style scoped>
.pageNav{position: fixed;top: 36%;right: 20px;width: 134px;}
.pageNav ul{width: 100%;font-size: 14px;color: #888888;background: rgba(255,255,255,0.5);padding: 8px 0 8px 10px;box-shadow: 0 0 5px #c3c3c3;}
.pageNav ul li{width: 100%;height: 34px;line-height: 34px;padding-left: 24px;position: relative;cursor: pointer;}
.pageNav ul li span{position: absolute;width: 9px;height: 9px;border-radius: 50%;background: white;border: 1px solid #888888;top: 12px;left: 10px;z-index: 2;}
.pageNav ul li:hover{color: #fbd452;}
.pageNav ul li:hover span{border:1px solid #fbd452;}
.pageNav ul li.active{background: url('../../assets/images/page_nav_bg.png') no-repeat;background-size: 100%; background-position: left center;color:#fbd452; }
.pageNav ul li.active span{border:1px solid #fbd452;background: #4f525a;}
.pageNav .vertical{position: absolute;width: 15px;border-right: 1px dashed #bbbbbb;top: 23px;left: 10px;z-index: 0;}
</style>
