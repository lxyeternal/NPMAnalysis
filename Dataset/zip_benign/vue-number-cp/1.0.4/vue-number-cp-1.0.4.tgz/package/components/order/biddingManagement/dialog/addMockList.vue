<template>
  <transition name="el-zoom-in-bottom">
    <div class="box" v-show="showBox">
      <div class="addMockList">
        <div class="content">
          <div class="title tc" v-if="mockNo && pageType === '0'">{{mockList.filter(i=>i.mockNo==mockNo)[0].mockName}}</div>
          <div class="title tc" v-if="pageType === '1'">添加商品</div>
          <div class="center">
            <el-form class="form" size="small" label-width="76px" @submit.native.prevent>
              <el-row>
                <el-col :span="24">
                  <el-form-item label="商品名称：">
                    <el-input v-model.trim="skuName" @keyup.enter.native="seach" @blur="seach" placeholder="请输入商品名称关键词或型号搜索，输入的关键词越多，搜到的概率越大" clearable @clear="seach"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
            <p v-if="ispro" class="f12 red" style="margin-bottom: 10px">只有已经上架的战略中标商品才会出现在本页面；非中标商品，请先申请上架，待审核通过后才能被查询出来。</p>
            <div>
              <table>
                <thead>
                  <tr>
                    <td width="40px"></td>
                    <td width="50px">序号</td>
                    <td :width="pageType === '0' ? '240px' : '320px'">商品名称/型号</td>
                    <td v-if="pageType === '1'" width="125px" class="tr">单价(不含税)(元)</td>
                    <td width="80px" v-if="pageType === '0'">品牌</td>
                    <td :width="pageType === '0' ? '70px' : '130px'" :style="{'padding-left' : pageType === '0' ? '10px' : '50px'}">单位</td>
                    <td>参数</td>
                    <td v-if="pageType === '0'" width="125px" class="tr">单价(不含税)(元)</td>
                    <td width="80px" style="padding-right: 20px" class="tr">操作</td>
                  </tr>
                </thead>
                <tbody :class="{'tbody-active':bidProdList.length}">
                  <tr v-for="(a,ind) in bidProdList" :key="ind" class="tbody-row">
                    <td width="40px">
                      <el-checkbox v-model="a.checkBox" :disabled="a.disable" @change="checkBoxOne(a)"></el-checkbox>
                    </td>
                    <td width="50px">
                      {{(ind+1)+pageSize*(pageIndex-1)}}
                    </td>
                    <td width="240px" v-if="pageType === '0'">
                      <span class="ellipsisTwo" :title="a.skuName">{{a.skuName}}</span>
                      <span>型号：{{a.model?a.model:'-'}}</span>
                      <div class="tag" v-if="a.combinationProdFlag=='1'">组价商品</div>
                    </td>
                    <td width="320px" v-else>
                      <div class="skuName">
                        <div class="attachImg" :class="{'active':!a.attUrl}">
                          <img v-if="a.attUrl" :src="a.attUrl" alt="">
                        </div>
                        <div class="model">
                          <p class="f12 ellipsisTwo" v-if="a.isExtraFee === '1'" :title="a.skuName">{{a.skuName}}</p>
                          <p v-else class="f12 ellipsisTwo hover-underline hand" :title="a.skuName" @click="handleGoproduct(a)">{{a.skuName}}</p>
                          <p class="f12" style="margin: 9px 0 6px">型号：{{a.model ? a.model : '-'}}</p>
                          <div class="tag inline-block" v-if="a.combinationProdFlag=='1'">组价商品</div>
                          <div class="tag inline-block bg-lightSteelBlue" v-if="pageType === '1' && a.combinationProdFlag !=='1' && a.bidSurchangeBeanList && a.bidSurchangeBeanList.length">含附加项</div>
                          <div class="tag inline-block" style="background: #FF7D1D;" v-if="pageType === '1' && a.approveStatus !== '2'">已下架</div>
                        </div>
                      </div>
                    </td>
                    <td width="125px" class="tr" v-if="pageType === '1'">
                      <p v-if="a.isExtraFee === '1'">{{NumberUtil.accMul(Number(a.unitPrice),100) + '%'}}</p>
                      <p v-else>{{(a.unitPrice || '0') | formatMoney}}</p>
                    </td>
                    <td width="80px" v-if="pageType === '0'">{{a.brandName}}</td>
                    <td :width="pageType === '0' ? '70px' : '130px'" :style="{'padding-left' : pageType === '0' ? '10px' : '50px'}">{{a.isExtraFee === '1' ? '-' : a.prodUnit}}</td>
                    <td :title="a.params"><span>{{a.isExtraFee === '1' ? '-' : (a.params || '-')}}</span></td>
                    <td width="125px" class="tr" v-if="pageType === '0'">{{a.priceA | formatMoney}}</td>
                    <td width="80px" class="tr">
                      <p v-if="a.isExtraFee === '1'" style="padding-right: 10px;">-</p>
                      <p v-else @click="handleGoproduct(a)" class="hand blue">商品详情</p>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <!-- 空列表 -->
            <div class="accout-empty" v-if="!bidProdList.length&&!isLoading">
              <img src="@/assets/images/icon-no-product.png">
              <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
            </div>
            <!-- 分页 -->
            <div class="table-pagination" v-if="bidProdList.length">
              <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
              </el-pagination>
            </div>
          </div>
        </div>
        <!-- 按钮 -->
        <div class="foot">
          <el-button type="primary" :disabled="bidProdList.every(i=>!i.checkBox) && !this.checkList.length" :class="{'isDisabled-primary':bidProdList.every(i=>!i.checkBox) && !this.checkList.length}" @click="addMockList">添加</el-button>
          <el-button @click="showBox = false">取消</el-button>
        </div>
      </div>
    </div>
  </transition>

</template>
<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import { NumberUtil } from '@/utils/numberUtil';
export default {
  props: ['mockList'],
  data() {
    return {
      isLoading: false,
      total: 0, //分页 总页数
      pageSize: 5, //分页 每页的长度
      pageIndex: 1, //当前页码

      NumberUtil: NumberUtil,
      pageType: '0',//0:招标管理 1:合同管理
      submitBidNo: '',
      showBox: false,
      bidProdList: [],
      checkList: [],
      skuName: '',
      bidNo: '',
      mockNo: '',
      bidProdNo: '',
      delList: [],
      ashList: [],
      supplierType: '',
      supplierId: '',
      delList: [],
      supplierParams: '',
      ispro: false,
    }
  },
  computed: {
    isDirectSales() {
      return this.supplierType == '0' || this.supplierType == '3'
    },
  },
  watch: {
    // 锁定父元素html的滚动
    showBox(val) {
      if (val) {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'hidden', 'important')
      } else {
        document.getElementsByTagName('html')[0].style.setProperty('overflow-y', 'scroll', 'important')
      }
    }
  },
  methods: {
    handleGoproduct(item) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: item.spuId,
          skuId: item.skuId,
          corpId: item.supplierCorpId
        }
      }).href, '_blank')
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.pageType === '0' ? this.getSupProMockList() : this.getSupplierProductList()
    },
    seach() {
      this.pageIndex = 1;
      this.pageType === '0' ? this.getSupProMockList() : this.getSupplierProductList()
    },
    // 单选
    checkBoxOne(a) {
      if (this.pageType === '0') {
        this.bidProdList.forEach(i => {
          if (i.spuId != a.spuId) {
            this.$set(i, 'checkBox', false)
          }
        })
      } else {
        if (a.checkBox) {
          this.checkList.push(a)
        } else {
          this.checkList.splice(this.checkList.findIndex(item => item.spuId === a.spuId), 1)
        }
      }
    },
    // 获取清单商品列表(招标)
    getSupProMockList() {
      // console.log('getSupProMockList')
      let param = {
        bidNo: this.bidNo,
        bidProdNo: this.bidProdNo ? this.bidProdNo : this.delList[0].bidProdNo,
        submitBidNo: this.submitBidNo,
        skuName: this.skuName || '',
        prodListType: '3',
        pageIndex: this.pageIndex,
      }
      InterfaceService.getSupProMockList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.bidProdList = data.respData.bidProdList || []
          this.bidProdList.forEach(i => {
            this.$set(i, 'checkBox', false)
            this.$set(i, 'disable', false)
            this.checkList.forEach(j => {
              if (i.spuId == j.spuId) {
                this.$set(i, 'checkBox', true)
              }
            });
          });
          this.total = data.respData.totalCount
          this.pageSize = data.respData.pageSize
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })

    },
    // 获取清单商品列表(合同)
    getSupplierProductList() {
      let url = ''
      let param = {
        skuNameOrModel: this.skuName || '',
        supplierId: this.isDirectSales ? this.$store.state.userInfo.corpId : this.supplierId,
        isCommodityWarehouse: '1',
        pageIndex: this.pageIndex,
        pageType: '0',
      }
      if (this.isDirectSales) {
        param.isCommodityWarehouse = '1'
        url = 'getSupplierProductList'
      } else {
        param.pageType = '1'
        url = 'getAuthorizeProductList'
      }
      if (this.ispro) {
        param.isCommodityWarehouse = '1'
        // param.pageType = '1'
        param.pageType = '0'//上架商品
      }

      InterfaceService[url](param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.bidProdList = data.respData.awredSpuBeans || []
          const skuId = this.$route.query.skuId //商品skuId（编辑时必传）
          this.bidProdList.forEach(i => {
            this.$set(i, 'checkBox', false)
            this.$set(i, 'disable', false)
            this.ashList.forEach(j => {
              if (j.skuId == i.skuId && j.isExtraFee === '1') {
                this.$set(i, 'disable', true)
              }
            })
            this.checkList.forEach(j => {
              if (i.spuId == j.spuId) {
                this.$set(i, 'checkBox', true)
              }
            });
            if (skuId && skuId == i.skuId) {
              this.$set(i, 'disable', true)
            }
            i.combinationProdFlag = i.isCombination
            i.prodUnit = i.goodsUnit
            i.params = i.prodAttars
          });
          console.log(this.bidProdList)
          this.total = data.respData.totalCount
          this.pageSize = data.respData.pageSize
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    // 供应商新增模拟清单
    addMockList() {
      if (this.pageType === '1') {
        this.$message.success('添加成功')
        this.$emit('updateData', this.checkList)
        this.showBox = false
        return
      }
      let supplierMockList = []
      this.bidProdList.forEach((i, index) => {
        if (i.checkBox) {
          supplierMockList.push({
            submitBidNo: this.submitBidNo,
            mockNo: this.mockNo,
            bidProdNo: i.bidProdNo,
            skuId: i.skuId,
            operateType: i.operateType = 'ADD' //ADD:新增；UPDATE:编辑；DELETE:删除
          })
        }
      });
      if (this.supplierParams) {
        const a = this.bidProdList.filter(i => i.checkBox)[0]
        const list = this.supplierParams.split('；')
        let seriesName = ''
        list.forEach(i => {
          if (i.indexOf('系列名称') !== -1) {
            seriesName = i.split('：')[1]
          }
        });
        // console.log(a)
        // console.log(list)
        // console.log(seriesName)
        if (seriesName && a.params.indexOf(seriesName) === -1) {
          this.$confirm(
            "您勾选的商品与清单中其他商品的系列名称不同,是否确定添加?",
            "添加",
            {
              cancelButtonClass: "btn-custom-cancel",
              confirmButtonClass: "btn-custom-confirm",
              center: true,
              dangerouslyUseHTMLString: true,
              confirmButtonText: "确定",
              cancelButtonText: '取消',
            }).then(() => {
              this.saveSupMockList(supplierMockList)
            }).catch(() => { });
        } else {
          this.saveSupMockList(supplierMockList)
        }
      } else {
        this.saveSupMockList(supplierMockList)
      }
    },
    // 供应商新增模拟清单
    saveSupMockList(supplierMockList) {
      supplierMockList = supplierMockList.concat(this.delList)
      console.log(supplierMockList)
      let param = {
        supplierMockList: supplierMockList,
      }
      InterfaceService.saveSupMockList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.$message.success('添加成功')
          this.$emit('updateData')
          this.showBox = false
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    open(delList, mockNo, bidProdNo, submitBidNo, supplierParams) {
      this.bidNo = this.$route.query.bidNo || ''
      this.submitBidNo = submitBidNo || ''
      this.mockNo = mockNo || ''
      this.bidProdNo = bidProdNo || ''
      this.delList = delList || []
      this.skuName = ''
      this.pageIndex = 1
      this.bidProdList = []
      this.checkList = []
      this.getSupProMockList()
      this.showBox = true
      this.supplierParams = supplierParams || ''
      this.pageType = '0'
    },
    // 商品管理创建组价
    handleOpen(ashList, supplierType, supplierId, ispro = false) {
      this.skuName = ''
      this.pageIndex = 1
      this.ashList = ashList || []
      this.checkList = []
      this.pageType = '1'
      this.supplierType = supplierType
      this.supplierId = supplierId || ''
      this.ispro = ispro
      this.getSupplierProductList()
      this.showBox = true
    }
  },
  // mounted() {
  //   this.open()
  // },
}
</script>
<style lang="scss" scoped>
.box {
  position: fixed;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  overflow: auto;
  margin: 0;
  background: rgba(0, 0, 0, 0.5);
  z-index: 2001;
  .addMockList {
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #fff;
    .content {
      width: 1190px;
      margin: 0 auto;
      font-size: 14px;
      line-height: 17px;
      .title {
        padding: 20px 0;
        border-bottom: 1px solid #eee;
        margin-bottom: 20px;
      }

      table,
      thead,
      tbody {
        display: block;
      }

      thead,
      tbody tr {
        display: table;
        width: 100%;
        table-layout: fixed;
      }
      table {
        margin-top: 2px;
        table-layout: fixed;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        td {
          padding: 14px 10px;
          vertical-align: middle;
          word-break: break-all;
          &:last-child {
            text-align: right;
          }
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          border-bottom: 1px solid #eee;
          background: rgba(249, 249, 249, 1);
          color: rgba(136, 136, 136, 1);
          tr {
            td {
              padding: 15px 10px;
              &:last-child {
                text-align: right;
              }
            }
          }
        }
        .tbody-row {
          &:hover {
            background: #f0f8ff;
          }
        }
        tbody {
          text-align: left;
          &.tbody-active {
            height: 40vh;
            overflow-y: auto;
          }
          tr {
            border-bottom: 1px solid #eee;
            td {
              .tag {
                width: 90px;
                height: 20px;
                background: #6598d3;
                line-height: 20px;
                font-size: 14px;
                color: #fff;
                text-align: center;
                border-radius: 2px;
                margin-right: 4px;
              }
              .skuName {
                display: flex;
                .attachImg {
                  width: 60px;
                  height: 60px;
                  min-width: 60px;
                  position: relative;
                  overflow: hidden;
                  &.active {
                    background-color: #eee;
                  }
                  > img {
                    position: absolute;
                    top: 0;
                    left: 0;
                    width: 100%;
                    pointer-events: none;
                    height: auto;
                  }
                }
                .model {
                  margin-left: 6px;
                }
              }
            }
          }
          .border-none {
            border-bottom: none;
          }
        }
      }
    }
    .foot {
      width: 100%;
      margin-top: 40px;
      height: 57px;
      background: rgba(49, 49, 49, 0.9);
      line-height: 57px;
      text-align: center;
      .el-button {
        width: 120px;
        height: 34px;
        line-height: 34px;
        padding: 0;
        font-size: 12px;
      }
      .el-button--primary {
        color: #fff;
        border: none;
        background: linear-gradient(120deg, #d7b064 0%, #ecce8b 100%);
      }
    }
  }
}
.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
.accout-empty {
  padding: 15vh;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
</style>