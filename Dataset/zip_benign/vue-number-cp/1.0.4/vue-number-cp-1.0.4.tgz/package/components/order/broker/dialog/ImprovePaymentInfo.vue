<template>
    <div>
        <!-- 新增/修改收款银行账户信息 -->
        <el-dialog class="dialog" :title="title" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false" :top="'3vh'">
            <div>
                <template v-if="(type =='tax' || type == 'showAll') && canEditOrderAmount=='0'">
                    <div class="order-info-title">合同价款</div>
                    <el-form ref="taxForm" :model="taxForm" :rules="taxRules" label-width="120px" size="small">
                        <el-row>
                            <el-col :span="11">
                                <el-form-item label="合同价款(含税)" prop="outContractFeeWithTax">
                                    <el-input @input="handleInput($event,'outContractFeeWithTax')" v-model.trim="taxForm.outContractFeeWithTax" type="text" placeholder="请输入数字" maxlength="15"></el-input>
                                    <span>元</span>
                                </el-form-item>
                            </el-col>
                        </el-row>
                    </el-form>
                </template>
                <template v-if="type =='payment' || type == 'showAll'">
                    <div class="order-info-title">请款明细</div>
                    <el-form ref="paymentForm" :model="paymentForm" :rules="paymentRules" label-width="120px" size="small">
                        <el-row>
                            <el-col :span="11">
                                <el-form-item label="本期产值" prop="thisOutputValue">
                                    <el-input @input="handleComputed($event,'thisOutputValue')" v-model.trim="paymentForm.thisOutputValue" type="text" placeholder="请输入数字" maxlength="15"></el-input>
                                    <span>元</span>
                                </el-form-item>
                            </el-col>
                            <el-col :span="11" :offset="2">
                                <el-form-item label="累计完成产值" prop="totalOutputValue" >
                                    <el-input @input="handleComputed($event,'totalOutputValue')" v-model.trim="paymentForm.totalOutputValue" type="text" placeholder="请输入数字" maxlength="15"></el-input>
                                    <span>元</span>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="11">
                                <el-form-item label="累计应付" prop="totalPayablesAmt" >
                                    <el-input @input="handleComputed($event,'totalPayablesAmt')" v-model.trim="paymentForm.totalPayablesAmt" type="text" placeholder="请输入数字" maxlength="15"></el-input>
                                    <span>元</span>
                                </el-form-item>
                            </el-col>
                            <el-col :span="11" :offset="2">
                                <el-form-item label="累计已付" prop="totalPaidAmt" >
                                    <el-input @input="handleComputed($event,'totalPaidAmt')" v-model.trim="paymentForm.totalPaidAmt" type="text" placeholder="请输入数字" maxlength="15"></el-input>
                                    <span>元</span>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="11">
                                <el-form-item label="本次申请金额" prop="payablesAmtApply" >
                                    <el-input @input="handleComputed($event,'payablesAmtApply')" v-model.trim="paymentForm.payablesAmtApply" type="text" placeholder="请输入数字" maxlength="15"></el-input>
                                    <span>元</span>
                                </el-form-item>
                            </el-col>
                            <el-col :span="11" :offset="2">
                                <el-form-item label="累计应付未付款" prop="totalPayableAmt">
                                    <el-input disabled v-model.trim="paymentForm.totalPayableAmt" type="text" maxlength="15"></el-input>
                                    <span>元</span>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="11">
                                <el-form-item label="合同结算金额" prop="orderAuditAmt" :required="paymentType === '结算款'">
                                    <el-input v-model.trim="paymentForm.orderAuditAmt" type="text" placeholder="--" maxlength="128"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                    </el-form>
                </template>
                <template v-if="type == 'account' || type == 'showAll'">
                    <div class="order-info-title">账户信息</div>
                    <el-form ref="form" :model="form" :rules="rules" label-width="120px" size="small">
                        <div class="f14 bold tl" style="margin-bottom: 14px;">供应商账户信息</div>
                        <el-row>
                            <el-col :span="11">
                                <el-form-item label="供应商开户名称" prop="acctName" >
                                    <el-input v-model.trim="form.acctName" type="text" placeholder="请输入供应商开户名称" maxlength="128"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="11" :offset="2">
                                <el-form-item label="开户银行" prop="bankName" >
                                    <el-input v-model.trim="form.bankName" type="text" placeholder="请输入开户银行" maxlength="128"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="11">
                                <el-form-item label="银行账号" prop="bankAcct" >
                                    <el-input v-model.trim="form.bankAcct" @input="handleFormat($event,'bankAcct')" @blur="formatCard('bankAcct',$event)" type="text" placeholder="请输入银行账号" maxlength="30"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="24">
                                <el-form-item label="开户行地址" prop="bankAddr">
                                    <el-input v-model.trim="form.bankAddr" type="text" placeholder="请输入地址" maxlength="128"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="11">
                                <el-form-item label="开户行行号" prop="bankCode">
                                    <el-input v-model.trim="form.bankCode" @input="handleFormat($event,'bankCode')" @blur="formatCard('bankCode',$event)"  type="text" placeholder="请输入开户行行号" maxlength="15"></el-input>
                                </el-form-item>
                            </el-col>
                            <el-col :span="11" :offset="2">
                                <el-form-item label="纳税人识别号" prop="taxPayId">
                                    <el-input v-model.trim="form.taxPayId" @input="handleFormat($event,'taxPayId')" @blur="formatCard('taxPayId',$event)" type="text" placeholder="请输入纳税人识别号" maxlength="38"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                        <el-row>
                            <el-col :span="11">
                                <el-form-item label="联系人" prop="contact" >
                                    <el-input v-model.trim="form.contact" type="text" placeholder="请输入联系人" maxlength="32"></el-input>
                                </el-form-item>
                            </el-col><el-col :span="11" :offset="2">
                            <el-form-item label="联系电话" prop="phoneNo" >
                                <el-input v-model.triam="form.phoneNo" type="text" placeholder="请输入联系电话" maxlength="30"></el-input>
                            </el-form-item>
                        </el-col>
                        </el-row>
                        <div class="f14 bold tl" style="margin-bottom: 14px;">付款方账户信息</div>
                        <el-row>
                            <el-col :span="24">
                                <el-form-item label="付款单位" prop="pmtCorpName">
                                    <el-input v-model.trim="form.pmtCorpName" type="text" placeholder="请输入付款单位" maxlength="128"></el-input>
                                </el-form-item>
                            </el-col>
                        </el-row>
                    </el-form>
                </template>
                <!--<template v-if="(type =='invoice' || type == 'showAll')">-->
                    <!--<div class="order-info-title">开票情况</div>-->
                    <!--<el-form ref="invoiceForm" :model="invoiceForm" :rules="invoiceRules" label-width="120px" size="small">-->
                        <!--<el-row>-->
                            <!--<el-col :span="11">-->
                                <!--<el-form-item label="本次发票金额" prop="thisReceiptAmt">-->
                                    <!--<el-input v-model.trim="invoiceForm.thisReceiptAmt" type="text" placeholder="请输入数字" maxlength="15"></el-input>-->
                                    <!--<span>元</span>-->
                                <!--</el-form-item>-->
                            <!--</el-col>-->
                            <!--<el-col :span="11" :offset="2">-->
                                <!--<el-form-item label="累计发票金额" prop="totalReceiptAmt">-->
                                    <!--<el-input v-model.trim="invoiceForm.totalReceiptAmt" type="text" placeholder="请输入数字" maxlength="15"></el-input>-->
                                    <!--<span>元</span>-->
                                <!--</el-form-item>-->
                            <!--</el-col>-->
                        <!--</el-row>-->
                    <!--</el-form>-->
                <!--</template>-->
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 150px" @click="handleConfirm('Y')">确认</el-button>
                <el-button size="small" style="width: 150px" @click="handleConfirm('D')">保存草稿</el-button>
                <el-button size="small" style="width: 150px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    import Loading from "@/components/base/Loading";
    import { InterfaceService } from "@/services/api";
    import {calculationUtil} from '@/utils/calculationUtil';
    import { MoneyUtil } from '@/utils/moneyUtil';
    import accountMixin from "@/mixins/account";

    const form = {
        acctName: "",
        bankName: "",
        bankAcct: "",
        taxPayId: "",
        bankAddr: "",
        bankCode: "",
        contact: "",
        phoneNo: "",
        pmtCorpName: ""
    };
    const paymentForm = {
        orderAuditAmt: "",
        payablesAmtApply: "",
        totalPayablesAmt: "",
        totalOutputValue: "",
        totalPaidAmt: "",
        thisOutputValue: "",
        totalPayableAmt: "",
    };
    const taxForm = {
        outContractFeeWithTax: "",
    };
    const invoiceForm = {
        thisReceiptAmt: "",
        totalReceiptAmt: "",
    };
    export default {
        mixins: [accountMixin],
        components: {
            Loading,
        },
        data() {

            const validateMoney = (rule, value, callback) => {
                const reg = new RegExp(/^[+]{0,1}(\d+)$|^[+]{0,1}(\d+\.\d+)$/);
                if ((value&&!reg.test(value) ||
                    (!value && (((this.paymentType === "结算款" && rule.fullField !== "thisOutputValue"))
                        ||this.paymentType !== "结算款" && rule.fullField !== "thisOutputValue" && rule.fullField !== "orderAuditAmt")))) {
                    return callback(new Error("金额填写有误，请确认后重新输入"));
                } else {
                    callback();
                }
            };
            const validateInvoiceMoney = (rule, value, callback) => {
                const reg = new RegExp(/^[+]{0,1}(\d+)$|^[+]{0,1}(\d+\.\d+)$/);
                if (value && (!reg.test(value) || +value <= 0) ) {
                    return callback(new Error("金额填写有误，请确认后重新输入"));
                } else {
                    callback();
                }
            };
            const validatetotalPaidAmt = (rule, value, callback) => {
                const reg = new RegExp(/^[+]{0,1}(\d+)$|^[+]{0,1}(\d+\.\d+)$/);
                if (!reg.test(value)) {
                    return callback(new Error("金额填写有误，请确认后重新输入"));
                } else {
                    callback();
                }
            };
            const validateTotalPayableAmt = (rule, value, callback) => {
                if (+value < 0 && this.paymentType === "结算款") {
                    return callback(new Error("累计应付未付款计算有误，请重新计算"));
                } else {
                    callback();
                }
            };
            const validateBankAcctNo = (rule, value, callback) => {
                value = value && value.replace(/\s+/g, "");
                const reg = new RegExp(/^[0-9_-]{0,30}$/);
                if (!value || !reg.test(value)) {
                    return callback(new Error("银行账号格式错误，必须为数字"));
                } else {
                    callback();
                }
            };
            const validateTaxPayer = (rule, value, callback) => {
                value = value && value.replace(/\s+/g, "");
                const reg = new RegExp(/^[0-9a-zA-Z]{15,20}$/);
                if (value && !reg.test(value)) {
                    return callback(new Error("识别号格式错误，15到20位字母或数字"));
                } else {
                    callback();
                }
            };
            const validateMobile = (rule, value, callback) => {
                const reg = new RegExp(/^[1][0-9][0-9]{9}$/);                    // 手机
                const reg1 = new RegExp(/^((0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/); // 座机
                if (!reg.test(value) && !reg1.test(value)) {
                    return callback(new Error("联系电话格式错误，请填写手机号或座机"));
                } else {
                    callback();
                }
            };
            const validateBankCode = (rule, value, callback) => {
                value = value && value.replace(/\s+/g, "");
                const reg = new RegExp(/^[0-9]{12}$/);
                if (value && !reg.test(value)) {
                    return callback(new Error("银行行号有误，请填写12位数字"));
                } else {
                    callback();
                }
            };
            const validateSupplierInfo = (rule, value, callback) => {
                if (!value) {
                    return callback(new Error("信息填写有误，请输入内容"));
                } else {
                    callback();
                }
            };
            return {
                isLoading: false,
                dialogVisible: false,
                type: "",
                title: "",
                orderNo: "",
                executionId: "",
                procDefKey: "",
                paymentType: "",
                canEditOrderAmount: "",
                form: Object.assign({}, form),
                paymentForm: Object.assign({}, paymentForm),
                taxForm: Object.assign({}, taxForm),
                invoiceForm: Object.assign({}, invoiceForm),
                rules: {
                    acctName: [
                        {
                            required:true,
                            message: "请输入供应商开户名称",
                            trigger: 'blur'
                        },
                        { validator: validateSupplierInfo, trigger: 'blur' }
                    ],
                    bankName: [
                        {
                            required:true,
                            message: "请输入开户银行",
                            trigger: 'blur'
                        },
                        { validator: validateSupplierInfo, trigger: 'blur' }
                    ],
                    bankAcct: [
                        {
                            required:true,
                            message: "请输入银行账号",
                            trigger: 'blur'
                        },
                        { validator: validateBankAcctNo, trigger: 'blur' }
                    ],
                    taxPayId: [
                        {
                            message: "请输入纳税人识别号",
                            trigger: 'blur'
                        },
                        { validator: validateTaxPayer, trigger: 'blur' }
                    ],
                    bankAddr: [
                        {
                            message: "请填写地址",
                            trigger: 'blur'
                        },
                        // { validator: validateSupplierInfo, trigger: 'blur' }
                    ],
                    bankCode: [
                        {
                            message: "请输入开户行行号",
                            trigger: 'blur'
                        },
                        { validator: validateBankCode, trigger: 'blur' }
                    ],
                    contact: [
                        {   required:true,
                            message: "请输入联系人",
                            trigger: 'blur' },
                        { validator: validateSupplierInfo, trigger: 'blur' }
                    ],
                    phoneNo: [
                        {
                            required:true,
                            message: "请输入联系电话",
                            trigger: 'blur'
                        },
                        { validator: validateMobile, trigger: 'blur' }
                    ]
                },
                paymentRules: {
                    orderAuditAmt: [
                        {
                            message: "请输入合同结算金额",
                            trigger: 'blur'
                        },
                        { validator: validateMoney, trigger: 'blur' }
                    ],
                    payablesAmtApply: [
                        {
                            message: "请输入本次申请金额",
                            trigger: 'blur'
                        },
                        { validator: validateMoney, trigger: 'blur' }
                    ],
                    totalPayablesAmt: [
                        {
                            required:true,
                            message: "请输入累计应付款",
                            trigger: 'blur'
                        },
                        { validator: validateMoney, trigger: 'blur' }
                    ],
                    totalOutputValue: [
                        {
                            required:true,
                            message: "请输入累计完成产值",
                            trigger: 'blur'
                        },
                        { validator: validateMoney, trigger: 'blur' }
                    ],
                    totalPaidAmt: [
                        {
                            required:true,
                            message: "请输入累计已付款",
                            trigger: 'blur'
                        },
                        { validator: validatetotalPaidAmt, trigger: 'blur' }
                    ],
                    thisOutputValue: [
                        {
                            required:true,
                            message: "请输入本期产值",
                            trigger: 'blur'
                        },
                        { validator: validateMoney, trigger: 'blur' }
                    ],
                    totalPayableAmt: [
                        { validator: validateTotalPayableAmt, trigger: 'blur' }
                    ],
                },
                taxRules: {
                    outContractFeeWithTax: [
                        {
                            message: "请输入合同价款(含税)金额",
                            trigger: 'blur'
                        },
                        { validator: validateMoney, trigger: 'blur' }
                    ],
                },
                invoiceRules: {
                    thisReceiptAmt: [
                        {
                            message: "",
                            trigger: 'blur'
                        },
                        { validator: validateInvoiceMoney, trigger: 'blur' }
                    ],
                    totalReceiptAmt: [
                        {
                            message: "",
                            trigger: 'blur'
                        },
                        { validator: validateInvoiceMoney, trigger: 'blur' }
                    ],
                }
            };
        },
        methods: {
            open(type,executionId,procDefKey) {
                this.type = type;
                this.executionId = executionId;
                this.procDefKey = procDefKey;

                if (this.type == "showAll" || this.type == "payment") {
                    this.title = "请完善请款信息";
                    this.$nextTick(() => {
                        this.$refs["paymentForm"].clearValidate();
                    });
                    if (this.type == "showAll") {
                        this.$nextTick(() => {
                            this.$refs["form"].clearValidate();
                            if (this.$refs["taxForm"]) {
                                this.$refs["taxForm"].clearValidate();
                            }
                        });
                    }
                } else if (this.type == "account") {
                    this.title = "供应商账户信息";
                    this.$nextTick(() => {
                        this.$refs["form"].clearValidate();
                    });
                } else if (this.type == "tax") {
                    this.title = "请填写合同价款信息";
                    this.$nextTick(() => {
                        if ( this.$refs["taxForm"]) {
                            this.$refs["taxForm"].clearValidate();
                        }
                    });
                }
                this.getApprovalDetail();
                this.dialogVisible = true;
            },
            handleInput(ev,num){
                this.taxForm[num] = ev.replace(/,/g,'');
            },
            handleFormat(e,type){
                // if(!isNaN(e.replace(/[ ]/g,""))){
                //     this.form[type] =e.replace(/\s/g,'').replace(/(\d{4})(?=\d)/g,"$1 ");//四位数字一组，以空格分割
                // }else{
                //     if(e.keyCode==8){//当输入非法字符时，禁止除退格键以外的按键输入
                //         return true;
                //     }else{
                //         return false
                //     }
                // }
            },
            formatCard(type,ev){
                this.form[type] = this.form[type] && this.form[type].replace(/\s+/g, "").replace(/(.{4})/g, "$1 ")
                if (ev && ev.target.value == "") {
                    this.form[type] = null
                }
            },
            //计算累计应付未付款
            handleComputed(ev,num){
                if (ev) {
                    this.paymentForm[num] = ev.replace(/,/g,'');
                    this.paymentForm.totalPayableAmt =
                        calculationUtil.sub(
                            calculationUtil.sub(this.paymentForm.totalPayablesAmt || 0,this.paymentForm.totalPaidAmt || 0), this.paymentForm.payablesAmtApply || 0
                        );
                    this.paymentForm.totalPayableAmt =MoneyUtil.moneyFixed(this.paymentForm.totalPayableAmt,2)
                }
            },

            handleConfirm(type) {
                if (type == "Y") {
                    if (this.type == "account") {
                        this.$refs["form"].validate(valid => {
                            if (valid) {
                                this.editPaymentInfo("improve");
                            }
                        });
                    } else if (this.type == "payment") {
                        this.$refs["paymentForm"].validate(valid => {
                            if (valid) {
                                this.editPaymentInfo("improve");
                            }
                        });
                    } else if (this.type == "tax") {
                        this.$refs["taxForm"].validate(valid => {
                            if (valid) {
                                this.editPaymentInfo("improve");
                            }
                        });
                    }else if (this.type == "invoice"){
                        this.$refs["invoiceForm"].validate(valid => {
                            if (valid) {
                                this.editPaymentInfo("improve");
                            }
                        });
                    } else {
                        this.$refs["paymentForm"].validate(valid => {
                            this.$refs["form"].validate(_valid => {
                                if (this.$refs["taxForm"]) {
                                    this.$refs["taxForm"].validate(__valid => {
                                        if (valid && _valid && __valid) {
                                            this.editPaymentInfo("improve","approval");
                                        }
                                    })
                                } else {
                                    if (valid && _valid) {
                                        this.editPaymentInfo("improve","approval");
                                    }
                                }
                            })
                        });
                    }
                }else if (type == "D") {
                    if (this.paymentType  === "结算款") {
                        if (this.paymentForm.totalPayableAmt < 0) {
                            this.$message.error("请款事由为结算款时，累计应付未付款不能为负数！")
                        }else {
                            this.editPaymentInfo("draft");
                        }
                    }else {
                        this.editPaymentInfo("draft");
                    }
                }

            },
            arrangeParams(type){
                Object.keys(this[type]).map(key => {
                    if (this[type][key] == "") {
                        this[type][key] = null
                    }
                });
            },
            editPaymentInfo(submitType,approval) {
                this.form.bankCode= this.form.bankCode && this.form.bankCode.replace(/\s+/g, "");
                this.form.bankAcct= this.form.bankAcct && this.form.bankAcct.replace(/\s+/g, "");
                this.form.taxPayId= this.form.taxPayId && this.form.taxPayId.replace(/\s+/g, "");
                let params = {};
                if (this.type == "account") {
                    // this.arrangeParams("form");
                    params = {
                        executionId : this.executionId,
                        corpFinInfo : this.form,
                        orderNo : this.orderNo
                    };
                } else if (this.type == "payment") {
                    this.arrangeParams("paymentForm");
                    params = {
                        executionId : this.executionId,
                        pmtBusiInfo : this.paymentForm,
                        orderNo : this.orderNo
                    };
                } else if (this.type == "tax") {
                    params = {
                        executionId : this.executionId,
                        outContractFeeWithTax : this.taxForm.outContractFeeWithTax || null,
                        orderNo : this.orderNo
                    };
                } else if (this.type == "invoice"){
                    this.arrangeParams("invoiceForm");
                    params = {
                        executionId : this.executionId,
                        pmtReceiptInfo : this.invoiceForm,
                        orderNo : this.orderNo
                    };
                } else {
                    this.arrangeParams("paymentForm");
                    this.arrangeParams("invoiceForm");
                    // this.arrangeParams("form");
                    params = {
                        executionId : this.executionId,
                        pmtBusiInfo : this.paymentForm,
                        pmtReceiptInfo : this.invoiceForm,
                        corpFinInfo : this.form,
                        outContractFeeWithTax : this.taxForm.outContractFeeWithTax || null,
                        orderNo : this.orderNo
                    };
                }
                if (submitType === "draft") {
                    params.isDraft = "1"
                }
                console.log(params);
                InterfaceService.approvalPaymentInfo(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.dialogVisible = false;
                            this.$message.success(submitType === "improve" ? "资料完善成功" : "保存草稿成功");
                            if (approval) {
                                const data = {
                                    procDefKey: this.procDefKey,
                                    executionId: this.executionId,
                                };
                                this.$emit("close",true,data);
                            } else {
                                this.$emit("close",true)
                            }

                        } else {
                            this.$message.error(data.respData.respMsg);
                            this.form.bankCode= this.form.bankCode && this.form.bankCode.replace(/(.{4})/g, "$1 ")
                            this.form.bankAcct= this.form.bankAcct && this.form.bankAcct.replace(/(.{4})/g, "$1 ")
                            this.form.taxPayId= this.form.taxPayId && this.form.taxPayId.replace(/(.{4})/g, "$1 ")
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            getContractAccountInfo(orderNo){
                InterfaceService.getContractAccountInfo(
                    {
                        orderNo :orderNo
                    },
                    data => {
                        if (data.respData.respCode === "0000") {
                            if (data.respData.corpFinInfo) {
                                this.form = Object.assign({}, data.respData.corpFinInfo);
                            }
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            getApprovalDetail() {
                let execution = this.executionId || '';
                let params = {};
                params = {
                    executionId: execution,
                    procDefKey:this.procDefKey,
                    pageIndex: 1
                };
                InterfaceService.getApprovalDetail(
                    params,
                    data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            let orderNo = data.respData.orderNo || "";
                            this.paymentType = res.paymentType;
                            this.form = Object.assign({},form, data.respData.corpFinInfo);
                            if (data.respData.corpFinInfo.pmtCorpName === null) {
                                this.form.pmtCorpName = this.userinfo.corpName
                            }else {
                                this.form.pmtCorpName = data.respData.corpFinInfo.pmtCorpName
                            }
                            if (this.type == "showAll" || this.type == "account") {
                                let noData = true;
                                for(let key in this.form){
                                    if(this.form[key]) {
                                        noData = false
                                    }
                                }
                                if (noData) {
                                    this.getContractAccountInfo(orderNo);

                                }
                            }
                            this.formatCard('bankAcct');
                            this.formatCard('bankCode');
                            this.formatCard('taxPayId');
                            this.paymentForm = Object.assign({},paymentForm, data.respData.pmtBusiInfo);
                            this.invoiceForm.thisReceiptAmt = this.paymentForm.thisReceiptAmt || "";
                            this.invoiceForm.totalReceiptAmt = this.paymentForm.totalReceiptAmt || "";
                            this.taxForm.outContractFeeWithTax = data.respData.outContractFeeWithTax || "";
                            this.orderNo = data.respData.orderNo || "";
                            this.canEditOrderAmount = data.respData.canEditOrderAmount || "";
                        } else {
                            this.$message.error(res.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
        }
    };
</script>

<style lang="scss" scoped>
    .dialog {
        line-height: 25px;
    }
    .order-info-title {
        margin: 5px 0 20px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;
        text-align: left;
    }
    /deep/ .el-form-item {
        span{
            position: absolute;
            right: 10px;
            top: 0;
        }
    }
    .select-year{
        width: 340px;
    }
    .form-item {
        position: relative;
        display: inline-block;
        line-height: 32px;
        /deep/ .el-date-editor {
            input.el-input__inner {
                padding: 0 15px;
            }
            .el-input__prefix {
                display: none;
            }
        }
    }
</style>
