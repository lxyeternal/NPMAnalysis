<template>
  <div class="prequalifica">
    <div class="list-home">
      <div class="list-content">
        <div class="order-info-title">{{prodListType=='1'?'完善商品图-基础款':'完善商品图-组价商品'}}</div>
        <div class="panel">
          <el-form class="form" size="small" label-width="90px" type="flex" justify="space-between">
            <el-row>
              <el-col :span="8">
                <el-form-item label="商品名称：" class="samll_label">
                  <el-input v-model.trim="skuName" placeholder="输入供应商名称" maxlength="64" clearable></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="型号：">
                  <el-input v-model.trim="model" placeholder="请输入" maxlength="64" clearable>
                  </el-input>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="品牌：">
                  <el-select v-model="brandId" filterable placeholder="请输入或选择" clearable>
                    <el-option label="全部" value=""></el-option>
                    <el-option v-for="item in brandList" :key="item.value" :label="item.nameCn" :value="item.brandId">
                    </el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="8" v-if="prodListType=='2'">
                <el-form-item label="售卖属性：">
                  <el-radio-group v-model="prodAttr" @change="search()">
                    <el-radio :label="''">全部</el-radio>
                    <el-radio :label="'材料类'">材料类</el-radio>
                    <el-radio :label="'加工费'">加工费</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="图片上传情况：" class="business">
                  <el-radio-group v-model="hasSpuPic" @change="search()">
                    <el-radio :label="'0'">全部</el-radio>
                    <el-radio :label="'1'">未上传</el-radio>
                    <el-radio :label="'2'">已上传</el-radio>
                  </el-radio-group>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="24" class="form-btns" align="center">
                <el-button class="btn" type="primary" size="small" @click="search()">搜索</el-button>
                <el-button class="btn" size="small" @click="clear()">清除</el-button>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <el-row class="button-panel">
          <el-col :span="12">
            <el-checkbox v-model="checkboxAll" :disabled="!bidProdList.length" style="margin: 0 10px" @change="checkboxChange">全选</el-checkbox>
            <el-button class="btn w140" size="small" :class="{'isDisabled':!bidProdList.length || !bidProdList.some(i=>i.checkBox)}" :disabled="!bidProdList.length || !bidProdList.some(i=>i.checkBox)" @click="batchUpload">批量上传同一组图片</el-button>
          </el-col>
        </el-row>
        <TableThead :TopDistance="660">
          <tr slot="tr">
            <td width="40px"></td>
            <td width="50px">序号</td>
            <td width="320px">商品名称/型号</td>
            <td width="80px">品牌</td>
            <td width="70px">单位</td>
            <td>属性</td>
            <td width="125px" class="tr">单价(不含税)(元)</td>
            <td width="90px">操作</td>
          </tr>
        </TableThead>
        <table>
          <thead>
            <tr>
              <td width="40px"></td>
              <td width="50px">序号</td>
              <td width="320px">商品名称/型号</td>
              <td width="80px">品牌</td>
              <td width="70px">单位</td>
              <td>属性</td>
              <td width="125px" class="tr">单价(不含税)(元)</td>
              <td width="90px">操作</td>
            </tr>
          </thead>
          <tbody v-for="(a,ind) in bidProdList" :key="ind" class="tbody-row">
            <tr>
              <td>
                <el-checkbox v-model="a.checkBox"></el-checkbox>
              </td>
              <td>
                {{ind+1}}
              </td>
              <td>
                <div class="skuName">
                  <div class="attachImg" :class="{'active':!a.attachUrl}">
                    <img v-if="a.attachUrl" :src="a.attachUrl" alt="">
                  </div>
                  <div class="model">
                    <span class="ellipsisTwo" :title="a.skuName">{{a.skuName}}</span>
                    <span>型号：{{a.model?a.model:'-'}}</span>
                  </div>
                </div>
              </td>
              <td>{{a.brandName}}</td>
              <td>{{a.prodUnit}}</td>
              <td :title="a.params"><span>{{a.params || '-'}}</span></td>
              <td class="tr">
                {{a.priceA | formatTwoDigits}}
              </td>
              <td>
                <p class="hand blue" v-if="!a.spuAttachList" @click="$refs.uploadProImg.open([a],prodListType)">上传商品图</p>
                <p class="hand blue" v-else @click="$refs.uploadProImg.open([a],prodListType)">替换商品图</p>
                <p class="hand blue" @click="handleProductDetails(a)">商品详情</p>
              </td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!bidProdList.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
        </div>
        <div class="table-pagination" v-if="bidProdList.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <!-- 底部按钮 -->
    <FixBottom class="bottom">
      <div class="tc">
        <el-button type="primary" @click="step('under')">下一步</el-button>
        <el-button @click="step('on')">上一步</el-button>
      </div>
    </FixBottom>
    <!-- 上传图片 -->
    <UploadProImg ref="uploadProImg" @updateData="getSupProMockList"></UploadProImg>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import FixBottom from "@/components/base/FixBottom";
import UploadProImg from "@/components/order/biddingManagement/dialog/uploadProImg";
import TableThead from "@/components/base/TableThead";
export default {
  components: {
    Loading,
    FixBottom,
    UploadProImg,
    TableThead
  },
  data() {
    return {
      isLoading: false,

      total: 0, //分页 总页数
      pageSize: 3, //分页 每页的长度
      pageIndex: 1, //当前页码

      prodListType: '1',//1:完善商品图-基础款,2:完善商品图-组价商品
      brandList: [],
      brandListIndex: 1,

      checkboxAll: false, // 全选
      skuName: '',
      model: '',
      brandId: '',
      prodAttr: '',
      hasSpuPic: '0',
      bidProdList: [],
    };
  },
  props: ['submitBidNo', 'bidNo'],
  methods: {
    handleProductDetails(item) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: item.spuId,
          skuId: item.skuId,
          corpId: item.supplierCorpId
        }
      }).href, '_blank')
    },
    step(type) {//on;under
      if (this.prodListType == '1') {
        if (type == 'on') {
          this.$emit('UpdateStep', ['perfectProImg', 'on'])
        } else {
          this.underCheck(this.prodListType, '1')
        }
      } else {
        if (type == 'on') {
          this.prodListType = '1'
          this.search()
        } else {
          // 校验
          this.underCheck(this.prodListType, '2')
        }
      }
    },
    // 下一步校验
    underCheck(prodListType, type) {
      // 校验
      let a = []
      this.bidProdList.forEach(i => {
        if (i.pictureIsFlag == '1') {
          let b = (i.spuAttachList || []).filter(j => j.type == '1')
          let c = (i.spuAttachList || []).filter(j => j.type == '2')
          if ((!b.length || !c.length) && prodListType == '1') {
            a.push(i)
          }
          if (!b.length && prodListType == '2') {
            a.push(i)
          }
        }
      })
      if (a.length) {
        this.$message.error('【' + a[0].skuName + '】未上传商品图')
        return
      } else {
        this.supplierBiddingDetail(type)
      }
    },
    // 全选
    checkboxChange() {
      this.bidProdList.forEach(i => {
        this.$set(i, 'checkBox', this.checkboxAll)
      });
    },
    // 批量上传图片
    batchUpload() {
      let list = this.bidProdList.filter(i => i.checkBox)
      this.$refs.uploadProImg.open(list, this.prodListType)
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      window.scrollTo(0, 0)
      this.getSupProMockList()
    },
    // 完善商品图列表
    getSupProMockList(type = '') {
      let param = {
        // bidProdNo: ,
        prodListType: this.prodListType, // 商品列表类型（1:基础；2:组价）
        skuName: this.skuName,
        bidNo: this.bidNo,
        submitBidNo: this.submitBidNo,
        model: this.model,
        brandId: this.brandId,
        prodAttr: this.prodAttr,
        hasSpuPic: this.hasSpuPic,
        pageIndex: this.pageIndex,
        isNeedUploadPic: '1',
      }
      InterfaceService.getSupProMockList(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.bidProdList = data.respData.bidProdList || []
          // console.log(this.prodListType, this.bidProdList.length)
          // 报价清单没有组价商品时，组价商品页面不显示
          if (this.prodListType == '2' && !this.bidProdList.length) {
            if (type) {
              this.prodListType = 1
              this.getSupProMockList()
            } else {
              this.$emit('UpdateStep', ['perfectProImg', 'under'])
              return
            }
          }
          if (this.brandListIndex === 1) {
            this.brandList = data.respData.brandList || []
            this.brandListIndex++
          }
          this.bidProdList.forEach(i => {
            this.$set(i, 'checkBox', false)
            if (i.spuAttachList) {
              let a = i.spuAttachList.filter(j => j.type == '1' && j.attachUrl)
              if (a.length) {
                this.$set(i, 'attachUrl', a[0].attachUrl)
              } else {
                this.$set(i, 'attachUrl', '')
              }
            } else {
              this.$set(i, 'attachUrl', '')
            }
          });
          this.checkboxAll = false;
          this.total = data.respData.totalCount
          this.pageSize = data.respData.pageSize
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })

    },
    // 投标详情详情
    supplierBiddingDetail(type) {
      let param = {
        submitBidNo: this.submitBidNo, //	投标编号				
        prodType: type == '1' ? '0' : '1', //	产品类型（ 0-基础， 1-组价 不传或传其他值-其他）	
      }
      InterfaceService.supplierBiddingDetail(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          const spuAttachListStatus = data.respData.spuAttachFlg || ''
          if (spuAttachListStatus == '1') {
            if (type === '1') {
              this.prodListType = '2'
              this.search()
            } else {
              this.$emit('UpdateStep', ['perfectProImg', 'under'])
            }
          } else {
            this.$message.error('您还有商品未上传图片，请去上传')
          }
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    search() {
      this.pageIndex = 1
      this.getSupProMockList()
    },
    clear() {
      this.skuName = ''
      this.model = ''
      this.brandId = ''
      this.prodAttr = ''
      this.hasSpuPic = '0'
      this.pageIndex = 1
      this.getSupProMockList()
    },
    init(type) {
      this.getSupProMockList(type)
    },
  },
  // mounted() {
  //   this.init()
  // },
};
</script>

<style lang="scss" scoped>
/deep/ .el-row label {
  width: inherit;
  width: initial;
}
/deep/ .el-input {
  width: 100%;
}

// /deep/ .el-select {
//   width: 100% !important;
// }
// /deep/ .el-form-item__label {
//   padding: 0 !important;
//   color: #888 !important;
// }

/deep/ .business {
  .el-form-item__label {
    width: 118px !important;
  }
}

.w140 {
  width: 140px !important;
}
.prequalifica {
  // padding-bottom: 60px;
  .list-home {
    width: 1190px;
    margin: 0 auto;
    .list-content {
      .panel {
        background: rgba(249, 249, 249, 1);
        padding: 20px 10px 20px 0px;
        margin: 20px 0;
      }
      // .button-panel {
      //   .el-button + .el-button {
      //     margin-left: 8px;
      //   }
      // }
      table {
        margin-top: 10px;
        table-layout: fixed;
        width: 100%;
        line-height: 23px;
        font-size: 12px;
        td {
          padding: 16px 10px;
          vertical-align: middle;
          word-break: break-all;
          &:last-child {
            text-align: right;
          }
          .skuName {
            display: flex;
            .attachImg {
              width: 80px;
              height: 80px;
              min-width: 80px;
              position: relative;
              overflow: hidden;
              &.active {
                background-color: #eee;
              }
              > img {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                pointer-events: none;
                height: auto;
              }
            }
            .model {
              margin-left: 6px;
            }
          }
        }

        thead {
          font-size: 14px;
          text-align: left;
          white-space: nowrap;
          border-bottom: 1px solid #eee;
          background: rgba(249, 249, 249, 1);
          color: rgba(136, 136, 136, 1);
          tr {
            td {
              padding: 13px 10px;
              &:last-child {
                text-align: right;
              }
            }
          }
        }
        .tbody-row {
          &:hover {
            background: #f0f8ff;
          }
        }
        tbody {
          text-align: left;
          tr {
            border-bottom: 1px solid #eee;
          }
          .border-none {
            border-bottom: none;
          }
        }
      }
    }
  }
}
.el-button + .el-button {
  margin-left: 20px;
}
.el-select {
  width: 100%;
}
/deep/ .el-row .el-col span {
  color: inherit;
}
.el-row {
  margin-bottom: 0px;
}
/deep/ .btn {
  width: 80px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  padding: 0;
}

.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
</style>
