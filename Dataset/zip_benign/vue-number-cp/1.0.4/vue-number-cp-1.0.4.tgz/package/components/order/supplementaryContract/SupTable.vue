<template>
  <el-popover popper-class="subsistTable-popover" trigger="click" placement="bottom" @show="handleShow">
    <div>
      <table class="table-default" :style="{'width': width +'px'}">
        <thead>
          <tr>
            <td width="155px">补充合同</td>
            <td width="155px" class="tr" :class="{'pad-left20': isScroll}">增补数量</td>
            <td width="160px" :class="{'pad-left20': isScroll}">增补金额(不含税)(元)</td>
          </tr>
        </thead>
        <tbody :style="{'width': width +'px'}" ref="tbody">
          <tr v-for="(item,ind) in dataList" :key="ind">
            <td width="155px">
              补充协议（{{$conversionNumber(item.orderCnt)}}）
            </td>
            <td width="155px" class="tr">
              {{item.buyCount | formatTwoDigits}}{{item.goodsUnit || ''}}
            </td>
            <td width="160px">
              {{(divisionContract ? item.inTotalAmt : item.outTotalAmt)  | formatMoney}}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <p slot="reference" class="hand"><span>{{text | formatMoney}}</span><i class="el-icon-caret-bottom blue"></i></p>
  </el-popover>
</template>
<script>
export default {
  props: {
    text: {
      type: String,
      default: ''
    },
    dataList: {
      type: Array,
      default: []
    },
    width: {
      type: Number,
      default: 470
    },
    divisionContract: {
      type: Boolean,
      default: false
    },
  },
  computed: {
    userInfo() {
      return this.$store.state.userInfo;
    },
  },
  data() {
    return {
      today: '',
      isScroll: false
    }
  },
  mounted() { },
  methods: {
    handleShow() {
      this.$nextTick(i => {
        let scrollHeight = this.$refs.tbody.scrollHeight
        if (scrollHeight > 270) {
          this.isScroll = true
        }
      })
    },
  }
}
</script>
<style lang="scss">
.subsistTable-popover {
  padding: 5px 10px 10px;
  .table-default {
    padding: 10px 4px;
    margin-top: 0px;
    thead {
      border: none;
      tr {
        td {
          font-size: 12px;
          line-height: 17px;
          padding: 7px 10px 6px;
          &.pad-left20 {
            padding-right: 20px;
          }
        }
      }
    }
    tbody {
      max-height: 270px;
      overflow-y: auto;
      display: block;
      tr {
        border-bottom: 1px dashed #eee;
        td {
          font-size: 12px;
          line-height: 17px;
          padding: 10px 10px;
        }
      }
    }
  }
}
</style>