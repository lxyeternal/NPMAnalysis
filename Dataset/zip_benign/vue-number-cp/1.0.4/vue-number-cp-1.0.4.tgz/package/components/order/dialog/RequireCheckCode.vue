<template>
    <div>
        <!-- 要货授权码 -->
        <el-dialog class="dialog" title="授权码" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false">
            <div>
                <p class="tip">
                    要货数量已超过合同签订的数量，请联系平台客服（
                    <span class="red">客服电话：{{$platformContact()['hotLine']}}</span>）获取授权码（授权码10分钟内有效），才能创建超过合同数量的要货单。
                </p>
                <el-form ref="form" :model="form" :rules="rules" label-width="100px">
                    <el-form-item label="授权码" prop="code">
                        <el-input v-model="form.code" type="text" maxlength="10" placeholder="请输入平台客服给与的授权码"></el-input>
                    </el-form-item>
                </el-form>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 150px" @click="handleConfirm">确定并创建要货单</el-button>
                <el-button size="small" style="width: 150px" @click="dialogVisible = false">取消创建</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
        return {
            dialogVisible: false,
            form: {
                code: ""
            },
            rules: {
                code: [
                    {
                        required: true,
                        message: "请输入授权码",
                        trigger: "blur"
                    }
                ]
            }
        };
    },
    methods: {
        open() {
            this.form.code = "";
            this.dialogVisible = true;
            this.$nextTick(() => {
                this.$refs["form"].clearValidate();
            });
        },
        handleConfirm() {
            this.$refs["form"].validate(valid => {
                if (valid) {
                    this.dialogVisible = false;
                    this.$emit("close", this.form.code);
                }
            });
        }
    }
};
</script>

<style lang="scss" scoped>
.tip {
    margin-bottom: 10px;
    padding: 0 40px;
    font-size: 14px;
    line-height: 25px;
}
</style>

