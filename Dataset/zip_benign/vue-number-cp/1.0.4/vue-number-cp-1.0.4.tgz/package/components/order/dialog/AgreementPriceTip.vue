<template>
    <div>
        <!-- 协议价提示 -->
        <el-dialog class="dialog" title="协议价说明" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="840px" center :close-on-click-modal="false">
            <div class="tl" style="padding:0 60px;">
                原则上您需要购买的商品价格已经是战略价，若根据实际情况，需要购买的商品价格低于战略价时，请联系平台客服（客服电话：{{$platformContact()['hotLine']}}）获取授权码（授权码10分钟内有效），在提交合同时，填写授权码即可。
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确定</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible= false">取消</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
        return {
            dialogVisible: false
        };
    },
    methods: {
        open() {
            this.dialogVisible = true;
        },
        handleConfirm() {
            this.dialogVisible = false;
            this.$emit("close", true);
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;

    /deep/ .el-dialog__header {
        padding: 20px;

        /*&:before {*/
            /*display: none;*/
        /*}*/
    }

    a {
        text-decoration: underline;
        color: #0082ff;
    }
}
</style>
