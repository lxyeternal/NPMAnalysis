<template>
    <div class="order-info" v-if="show">
        <el-row>
            <el-col>
                <div class="order-info-title">合同签署进度</div>
            </el-col>
        </el-row>
        <el-row :gutter="5">
            <!-- 供应方 -->
            <el-col :span="6" v-for="(item,index) in vList" :key="'s_'+index">
                <div class="order-sign">
                    供应方-{{showLabelText(item)}}：
                    <span :class="{'green': filterGreen(item)}">
                        <i :class="filterIconName(item)"></i>{{showLabelStatusText(item)}}</span>
                </div>
            </el-col>
            <!-- 采购方 -->
            <el-col :span="6" v-for="(item,index) in pList" :key="'b_'+index">
                <div class="order-sign">
                    采购方-{{showLabelText(item)}}：
                    <span :class="{'green': filterGreen(item)}">
                        <i :class="filterIconName(item)"></i>{{showLabelStatusText(item)}}</span>
                </div>
            </el-col>
        </el-row>
    </div>
</template>

<script>
    import accountMixin from "@/mixins/account";
    export default {
    mixins: [accountMixin],
    data() {
        return {
            show: false,
            pList: [],
            vList: []
        };
    },
    props: ["order"],
    watch: {
        order() {
            this.init();
        }
    },
    methods: {
        showLabelText(item) {
            if (item.type == 0) {
                return "合同盖章";
            } else if (item.type == 1) {
                return "合同签字";
            }
        },
        showLabelStatusText(item) {
            if (item.type == 0) {
                return item.processFlg == 1 ? "已盖章" : "待盖章";
            } else if (item.type == 1) {
                return item.processFlg == 1 ? "已签字" : "待签字";
            }
        },
        filterGreen(item) {
            let bool = false;
            if (item.type == 0) {
                bool = item.processFlg == 1;
            } else if (item.type == 1) {
                bool = item.processFlg == 1;
            }
            return bool;
        },
        filterIconName(item) {
            let icon = "";
            if (item.type == 0) {
                icon = item.processFlg == 1 ? "icon-seal-yes" : "";
            } else if (item.type == 1) {
                icon = item.processFlg == 1 ? "icon-check-yes" : "";
            }
            return {
                [icon]: true
            };
        },
        filterContractType(item) {
            const seals = ["02", "11", "22", "25", "31", "33", "41"];
            if (seals.indexOf(item.role) !== -1) {
                item.type = 0;
            } else {
                item.type = 1;
            }
            return item;
        },
        init() {
            this.pList = [];
            this.vList = [];
            let processList = [];
            const events = this.order.eventList || [];
            const broker = this.order.brokerCorpId || "";
            if (this.order && this.order.eventList) {
                if (!broker) {
                    events.forEach(ev => {
                        if (ev.eventType == 0 && ev.documentType == "00") {
                            if (ev.eventStatus == 2) {
                                this.show = false;
                            } else {
                                this.show = true;
                                processList = ev.processList || [];
                            }
                        }
                    });
                } else {
                    events.forEach(ev => {
                        if (ev.eventType == 0 && ev.documentType == "00" && this.role == "S") {
                            if (ev.eventStatus == 2) {
                                this.show = false;
                            } else {
                                this.show = true;
                                processList = ev.processList || [];
                            }
                        } else if (ev.eventType == 0 && ev.documentType == "10" && this.role == "B") {
                            if (ev.eventStatus == 2) {
                                this.show = false;
                            } else {
                                this.show = true;
                                processList = ev.processList || [];
                            }
                        }
                    });
                }
            }
            processList.forEach(process => {
                process = this.filterContractType(process);
				// 解决 process.role[0] 报错问题
                if (!process.role) return
                if (!broker) {
                    // 筛选采购商
                    if (process.role[0] == 4 || process.role[0] == 2) {
                        this.pList.push(process);
                    } else if (process.role[0] == 3) {
                        // 筛选供应商
                        this.vList.push(process);
                    }
                } else {
                    if (this.role == "B") {
                        // 筛选采购商
                        if (process.role[0] == 2) {
                            this.pList.push(process);
                        } else if (process.role[0] == 4) {
                            // 筛选供应商
                            this.vList.push(process);
                        }
                    } else if (this.role == "S") {
                        // 筛选采购商
                        if (process.role[0] == 2 || process.role[0] == 4) {
                            this.pList.push(process);
                        } else if (process.role[0] == 3) {
                            // 筛选供应商
                            this.vList.push(process);
                        }
                    }
                }

            });
            this.pList.sort((a,b)=>{
                return b.role - a.role;
            })
            this.vList.sort((a,b)=>{
                return b.role - a.role;
            })

        }
    },
    mounted() {
        this.init();
    }
};
</script>

<style lang="scss" scoped>
.order-info {
    margin: 20px 0;
    padding: 20px 0 0;
    border-top: 1px solid #f5f5f5;
    border-bottom: 1px solid #f5f5f5;
    line-height: 25px;
    font-size: 12px;

    /deep/ .el-col {
        padding: 0 10px;
    }

    p {
        width: 100%;
        display: flex;
        padding-right: 10px;
        word-break: break-word;
        white-space: normal;

        & > span {
            display: inline-block;
            flex: 1 1 0%;
        }
    }

    label {
        white-space: nowrap;
        color: #888888;
    }

    a {
        white-space: nowrap;
        color: #0082ff;
    }
}

.order-info-title {
    margin: 5px -10px;
    margin-bottom: 20px;
    padding: 0 10px;
    font-size: 14px;
    border-left: 3px solid #000;
    line-height: 12px;
}

.order-sign {
    padding: 8px 15px;
    background-color: #f5f5f5;

    i {
        margin-right: 3px;
        margin-bottom: 3px;
        background-size: 100%;
        vertical-align: middle;
    }
}
</style>
