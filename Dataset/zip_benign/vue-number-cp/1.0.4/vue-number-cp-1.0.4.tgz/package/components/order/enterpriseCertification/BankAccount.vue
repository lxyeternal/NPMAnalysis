<template>
  <div class="BankAccount">
    <div class="container">
      <div class="bank-content">
        <el-form ref="form" :model="bankInfo" :rules="bankInfoRules" label-width="110px" size="small">
          <el-row>
            <el-col :span="24">
              <el-form-item label="查询银行信息：" prop="searchBankCnapsCode">
                <el-select v-model="bankInfo.searchBankCnapsCode" filterable remote placeholder="请输入关键词" :remote-method="getBrankInfoList" @change="searchBrankChangeItem">
                  <el-option v-for="(item, idx) in bankInfoList" :key="idx" :label="item.bankName" :value="item.cnapsCode">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="开户银行：">
                <el-input v-model.trim="bankInfo.bankName" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="开户支行：">
                <el-input v-model.trim="bankInfo.subBranch" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="银行联行号：">
                <el-input v-model.trim="bankInfo.cnapsCode" :disabled="true"></el-input>
              </el-form-item>
            </el-col>

            <el-col :span="12">
              <el-form-item label="户名：">
                <el-input v-model.trim="acctName" :disabled="true"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="银行卡号：" prop="bankAcctNo">
                <el-input v-model.trim="bankInfo.bankAcctNo" @focus="handleFocus('bankAcctNo',$event)" placeholder="请输入银行卡号" maxlength="30"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-form-item label="开户行地址：" prop="districtCode">
              <Distpicker :address="bankInfo" @receive="getAddressCode"></Distpicker>
            </el-form-item>
          </el-row>
          <el-row>
            <el-form-item label="" prop="bankAddr">
              <el-input v-model.trim="bankInfo.bankAddr" type="text" placeholder="请输入开户行详细地址" maxlength="200"></el-input>
            </el-form-item>
          </el-row>
          <el-row>
            <el-col :span="12">
              <el-form-item label="联系人：" prop="contact">
                <el-input v-model.trim="bankInfo.contact" type="text" placeholder="请输入联系人" maxlength="30"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="12">
              <el-form-item label="联系方式：" prop="mobile">
                <el-input v-model="bankInfo.mobile" type="text" placeholder="请输入联系方式" maxlength="11"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div slot="footer" class="footer">
        <el-button type="primary" class="normal-btn" @click="handleConfirm">发起打款</el-button>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import Distpicker from "@/components/base/Distpicker";

const validatebankAcctNo = (rule, value, callback) => {
  value = value && value.replace(/\s+/g, "");
  const reg = new RegExp(/^[0-9]{0,30}$/);
  if (!value || !reg.test(value)) {
    return callback(new Error("银行卡号格式错误，必须为数字"));
  } else {
    callback();
  }
};
const validateMobile = (rule, value, callback) => {
  const reg = new RegExp(/^[1][0-9][0-9]{9}$/);                    // 手机
  if (!reg.test(value)) {
    return callback(new Error("联系方式格式错误，请填写手机号"));
  } else {
    callback();
  }
};
const bankInfo = {
  searchBankCnapsCode: "",
  subBranch: "",
  bankName: "",
  province: "",
  city: "",
  cnapsCode: "",
  bankAcctNo: "",
  provCode: "",
  cityCode: "",
  districtCode: "",
  blockCode: "",
  bankAddr: "",
  contact: "",
  mobile: "",
};
export default {
  components: {
    Loading,
    Distpicker,
  },
  computed: {

  },
  props: ['acctName', 'bankInfos', 'propCorpId', 'propAcctId'],
  watch: {
    bankInfos: {
      handler(val) {
        const obj = this.$clone(val)
        Object.assign(this.bankInfo, obj)
        this.bankInfo.searchBankCnapsCode = val.cnapsCode
        this.bankInfo.blockCode = val.districtCode
        this.getBrankInfoList(this.bankInfo.subBranch)
        // console.log(this.bankInfo)
      },
      immediate: true
    }
  },
  data() {
    return {
      isLoading: false,
      bankInfoList: [],
      bankInfo: Object.assign({}, bankInfo),
      bankInfoRules: {
        subBranch: [
          { required: true, message: "必填", trigger: ['blur'] },
        ],
        bankName: [
          { required: true, message: "必填", trigger: ['blur'] },
        ],
        cnapsCode: [
          { required: true, message: "必填", trigger: ['blur'] },
        ],
        bankAcctNo: [
          { required: true, message: "必填", trigger: ['blur'] },
          { validator: validatebankAcctNo, trigger: ['blur'] }
        ],
        bankAddr: [
          { required: true, message: "必填", trigger: ['blur'] },
        ],
        districtCode: [
          { required: true, message: "必填", trigger: 'change' }
        ],
        contact: [
          { required: true, message: "必填", trigger: ['blur'] },
        ],
        mobile: [
          { required: true, message: "必填", trigger: ['blur'] },
          { validator: validateMobile, trigger: ['blur'] }
        ]
      },
    };
  },
  methods: {
    handleFocus(type, ev) {
      this.bankInfo[type] = this.bankInfo[type] && this.bankInfo[type].replace(/\s+/g, "")
    },
    // 查询银行信息Change
    searchBrankChangeItem(val) {
      // console.log(val)
      const item = this.bankInfoList.filter(f => f.cnapsCode === this.bankInfo.searchBankCnapsCode)[0] || {}
      this.bankInfo.cnapsCode = item.cnapsCode
      this.bankInfo.bankName = item.bank
      this.bankInfo.subBranch = item.bankName
      // this.bankInfo.province = item.province
      // this.bankInfo.city = item.city
      // Object.assign(this.form, item)
    },
    // 查询银行信息
    getBrankInfoList(value) {
      if (value === null) return
      const keyWord = value.replace(/\s+/g, "")
      const params = {
        organizationAuthNo: this.bankInfos.organizationAuthNo,
        keyWord: keyWord
      }
      InterfaceService.getBrankInfoList(
        params,
        data => {
          const result = data.respData;
          if (result.respCode == '0000') {
            this.bankInfoList = result.bankInfoList || []
          }
        }, data => { }, () => { this.isLoading = true; }, () => { this.isLoading = false; })
    },
    handleConfirm() {
      this.$refs["form"].validate(valid => {
        if (valid) {
          if (!this.bankInfo.searchBankCnapsCode) {
            return this.$message.error('请查询银行信息！')
          }
          this.initiateCorporateMark()
        }
      });
    },
    getAddressCode(res, nameList = {}) {
      console.log(res)
      console.log(nameList)
      this.$set(this.bankInfo, "provCode", res.provinceCode);
      this.$set(this.bankInfo, "cityCode", res.cityCode);
      this.$set(this.bankInfo, "districtCode", res.blockCode);
      this.$set(this.bankInfo, "province", nameList.provinceName);
      this.$set(this.bankInfo, "city", nameList.cityName);
    },
    // 发起打款
    initiateCorporateMark() {
      const params = {
        bankAcctId: this.bankInfo.bankAcctId,//	Y	银行账户编号
        bankName: this.bankInfo.bankName,//	Y	银行名称
        provCode: this.bankInfo.provCode,//	Y	省代码
        province: this.bankInfo.province,//	Y	所在省份名称
        cityCode: this.bankInfo.cityCode,//	Y	市代码
        city: this.bankInfo.city,//	Y	所在城市名称
        districtCode: this.bankInfo.districtCode,//	Y	区代码
        bankAddr: this.bankInfo.bankAddr,//	Y	详细地址
        subBranch: this.bankInfo.subBranch,//	Y	支行名称全称
        bankAcctNo: this.bankInfo.bankAcctNo,//	Y	银行卡号
        cnapsCode: this.bankInfo.cnapsCode,//	Y	联行号可通过查询打款银行信息获取，或第三方数据库获取
        acctName: this.acctName,//	Y	户名
        contact: this.bankInfo.contact,//	Y	联系人名称
        mobile: this.bankInfo.mobile,//	Y	联系人电话
        acctId: this.propAcctId || undefined, // 事业部列表传入
      }
      InterfaceService.initiateCorporateMark(
        params,
        data => {
          const result = data.respData;
          if (result.respCode == '0000') {
            if (result.status === '1') {
              this.$message.success('打款成功')
              this.$emit('updateStep', 2)
            } else {
              this.$message.error(result.message)
            }
          } else {
            this.$message.error(result.respMsg)
          }
        }, data => { }, () => { this.isLoading = true; }, () => { this.isLoading = false; })
    },
    init() {

    }
  },
  mounted() {
    this.init();
  }
};
</script>

<style lang="scss" scoped>
/deep/ .el-form-item__label {
  font-size: 12px;
}
/deep/ .el-select {
  width: 100%;
}
/deep/ .el-form-item--mini.el-form-item {
  margin-bottom: 0;
}
.BankAccount {
  .container {
    padding: 0 15px 20px;
    .footer {
      text-align: center;
      margin-top: 22px;
    }
    .default-flg {
      text-align: left;
      height: 25px;
      line-height: 25px;
      padding-left: 10px;
      background-color: #eeeeee;
      span {
        margin-left: 6px;
      }
    }
  }
}
</style>
