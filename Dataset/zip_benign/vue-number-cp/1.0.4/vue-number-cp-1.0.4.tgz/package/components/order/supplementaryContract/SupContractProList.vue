<template>
  <div class="productList">
    <div class="content">
      <TableThead :TopDistance="supplierType === '0' ? 500 : 580" Height="60">
        <tr slot="tr">
          <td width="70px">序号</td>
          <td width="270px">商品名称/型号</td>
          <td width="150px" class="tr"><i class="red">*</i>补充采购量</td>
          <td width="150px" class="tr">附加费用单价<br>(不含税)(元)</td>
          <td width="120px" class="tr">税率</td>
          <td width="270px" class="tr">综合单价<br>(不含税)(元)</td>
          <td width="145px" class="tr">小计<br>(不含税)(元)</td>
        </tr>
      </TableThead>
      <table class="table-default">
        <thead>
          <tr>
            <td width="70px">序号</td>
            <td width="270px">商品名称/型号</td>
            <td width="150px" class="tr"><i class="red">*</i>补充采购量</td>
            <td width="150px" class="tr">附加费用单价<br>(不含税)(元)</td>
            <td width="120px" class="tr">税率</td>
            <td width="270px" class="tr">综合单价<br>(不含税)(元)</td>
            <td width="145px" class="tr">小计<br>(不含税)(元)</td>
          </tr>
        </thead>
        <tbody v-for="(a,ind) in dataInfo.contractProdBeans" :key="ind">
          <tr>
            <td>
              <img v-if="a.newSku === '0'" class="new_ico" src="@/assets/images/icon/new_ico.png" alt="">
              {{ind + 1 + ((pageIndex - 1) * pageSize)}}
            </td>
            <td>
              <div class="skuName">
                <div class="attachImg" :class="{'active':!a.attachUrl}">
                  <img v-if="a.attachUrl" :src="a.attachUrl" alt="">
                </div>
                <div class="model">
                  <p class="f12 ellipsisTwo hover-underline hand" :title="a.skuName" @click="handleGoproduct(a)">{{a.skuName}}</p>
                  <p class="f12" style="margin: 10px 0">型号：{{a.model?a.model:'-'}}</p>

                  <p style="margin-top: 10px" v-if="a.specifications && a.specifications.length < 18">规格：{{a.specifications}}</p>
                  <el-popover popper-class="dark-popover" trigger="hover" placement="top" v-else-if="a.specifications && a.specifications.length >= 18">
                    <div style="color: #fff;width: 500px">
                      规格：{{a.specifications}}
                    </div>
                    <p style="margin-top: 10px" slot="reference" v-if="$isIE()">规格：{{a.specifications.slice(0,18) + "..."}}</p>
                    <p style="margin-top: 10px" slot="reference" v-else class="ellipsisTwo">规格：{{a.specifications}}</p>
                  </el-popover>
                  <p v-if="a.isCombination == '1' && a.isNewCom != '1'" class="tag">组价商品</p>
                  <el-popover popper-class="dark-popover" trigger="hover" placement="right">
                    <div style="color: #fff;width: 185px;">
                      新组价商品是指，代理商创建合同时，新组的商品。
                    </div>
                    <p v-if="a.isNewCom == '1'" slot="reference" class="tag triangle-arrow orange">新组价商品</p>
                  </el-popover>
                  <p class="tag bg-lightSteelBlue" v-if="a.surchangeLength && a.surchangeLength != '0'">含附加项</p>
                </div>
              </div>
            </td>
            <td class="tr">{{a.buyCount + (a.goodsUnit || '')}}</td>
            <td class="tr">{{a.outOtherFee | formatMoney}}</td>
            <td class="tr">{{(+a.taxRate)*100+'%'}}</td>
            <td class="tr">
              <p>{{comprehensivePreTaxUnitPrice(a) | formatMoney}}</p>
              <p class="gary"><span>(单价：{{a.outPrice | formatMoney}})</span></p>
              <p class="gary">
                <span>
                  (运费单价：{{a.outFreightPrice | formatMoney}})
                </span>
              </p>
              <p class="gary"><span>(附加费用单价：{{a.outOtherFee | formatMoney}})</span></p>
            </td>
            <td class="tr">{{a.outTotalAmt | formatMoney}}</td>
          </tr>
          <tr v-if="a.isCombination !== '1' && a.tdOrderSurchargeDetailList && a.tdOrderSurchargeDetailList.filter(i=>i.checkBox).length">
            <td colspan="7" style="padding: 0px">
              <div class="additional-items tl" style="margin-left:76px">
                <div class="clearfloat">
                  <div class="fl f12 yellow bold" style="font-weight: 600;">附加项说明：</div>
                  <div class="fl" style="width: calc(100% - 90px);">
                    <p class="f12 tl" v-for="(add,index) in a.tdOrderSurchargeDetailList.filter(i=>i.checkBox)" :key="index+'tdOrderSurchargeDetailList'">附加项{{index+1}}：{{add.surchangeName}}&nbsp;&nbsp;&nbsp;&nbsp;X{{add.surchangeUnitCnt + add.surchangeUnit}}<span class="purple">&nbsp;&nbsp;&nbsp;¥ {{add.outSurchangeUnitPrice | formatMoney}}</span></p>
                  </div>
                </div>
              </div>
            </td>
          </tr>
          <tr v-if="a.floorNo">
            <td colspan="7" style="padding: 0px">
              <div class="additional-items tl" style="margin-left:76px">
                <div class="clearfloat">
                  <div class="fl f12 yellow bold">楼号：</div>
                  <div class="fl" style="width: calc(100% - 90px);">
                    <p class="f12">{{a.floorNo}}</p>
                  </div>
                </div>
              </div>
            </td>
          </tr>
          <tr v-if="a.itemDescription">
            <td colspan="7" style="padding: 0px">
              <div class="additional-items tl" style="margin-left:76px">
                <div class="clearfloat">
                  <div class="fl f12 yellow bold">物料描述：</div>
                  <div class="fl" style="width: calc(100% - 90px);">
                    <p class="f12">{{a.itemDescription}}</p>
                  </div>
                </div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
      <!-- 空列表 -->
      <div class="accout-empty" v-if="!dataInfo.contractProdBeans.length&&!isLoading">
        <img src="@/assets/images/icon-no-product.png">
        <p>没有搜索到相关记录，请重新修改搜索条件搜索！</p>
      </div>
      <div class="table-pagination" v-if="dataInfo.contractProdBeans.length" style="margin-bottom: 35px">
        <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
        </el-pagination>
      </div>
      <div class="foot-box">
        <p>合同价款(不含税)：<span>{{(dataInfo.outContractFee) | formatMoney}}元</span></p>
        <p>（含运费：{{(dataInfo.outLogisticsAmount) | formatMoney}}元）</p>
        <p>税率：<span>{{dataInfo.taxRate}}</span></p>
        <p>税额：<span>{{(dataInfo.outContractTax) | formatMoney}}元</span></p>
        <p>合同价款(含税)：<span class="red">{{(dataInfo.outContractFeeWithTax) | formatMoney}}元</span></p>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import TableThead from "@/components/base/TableThead";
import { NumberUtil } from '@/utils/numberUtil';
import FixBottom from "@/components/base/FixBottom";

export default {
  components: {
    Loading,
    TableThead,
    FixBottom,
  },
  data() {
    return {
      isLoading: false,
      allChecked: false,

      dataInfo: {
        contractProdBeans: []
      },
      supplierType: '0',//供应商性质（"0":厂家;"1":代理商;"2":经销商;"3":施工;"4":监理）
      orderNo: '',
      total: 0, //分页 总页数
      pageSize: 50, //分页 每页的长度
      pageIndex: 1, //当前页码
    };
  },
  computed: {
    freightCalculationComputead() {
      return item => +item.outFreightPrice
    },
    comprehensivePreTaxUnitPrice() {
      return item => {
        let result = 0
        result = NumberUtil.numAdd(+item.outPrice, +item.outFreightPrice) || 0

        result = NumberUtil.numAdd(result, +item.outOtherFee)
        return result || 0
      }
    },
  },
  methods: {
    init(orderNo) {
      this.orderNo = orderNo
      this.supplierType = this.$store.state.userInfo.supplyType || ''
      this.getContractProductList()
    },
    // 分页
    handleCurrentChange(page) {
      this.pageIndex = page;
      window.scrollTo(0, 0)
      this.getContractProductList()
    },
    handleGoproduct(item) {
      window.open(this.$router.resolve({
        path: "/productDetails",
        query: {
          spuId: item.spuId,
          skuId: item.skuId,
          corpId: item.corpId
        }
      }).href, '_blank')
    },
    // 小计
    subtotal(skuPrice, skuCount, type) {
      let num
      if (skuPrice && skuCount) {
        num = NumberUtil.accMul(Number(skuPrice), Number(skuCount))
        if (type) num = NumberUtil.formatMoney(num)
      } else {
        num = '-'
      }
      return num
    },
    // 查询合同货品清单
    getContractProductList() {
      let param = {
        orderNo: this.orderNo,
        pageIndex: this.pageIndex,
      };
      InterfaceService.getContractProductList(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.dataInfo = data.respData || {}
          this.dataInfo.contractProdBeans = data.respData.contractProdBeans || []

          this.dataInfo.contractProdBeans.forEach(i => {
            (i.tdOrderSurchargeDetailList || []).forEach(item => {
              if (item.surchangeUnitCnt && item.surchangeUnitCnt != '0') {
                this.$set(item, 'checkBox', true)
              } else {
                this.$set(item, 'checkBox', false)
              }
            })
          })

          this.total = data.respData.totalCount
          this.pageSize = data.respData.pageSize
          this.pageIndex = data.respData.pageIndex
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
  },
};
</script>

<style lang="scss" scoped>
.productList {
  width: 100%;
  padding-bottom: 100px;
  .content {
    .new_ico {
      position: absolute;
      left: 0;
      top: 0;
      width: 39px;
      height: 39px;
    }
    .table-default {
      thead {
        tr {
          td {
            font-size: 12px;
            line-height: 20px;
          }
        }
      }
      tbody {
        border-bottom: 1px solid #eee !important;
        tr {
          border-bottom: none !important;
          td {
            position: relative;
            font-size: 12px;
            .skuName {
              display: flex;
              .attachImg {
                width: 60px;
                height: 60px;
                min-width: 60px;
                position: relative;
                overflow: hidden;
                &.active {
                  background-color: #eee;
                }
                > img {
                  position: absolute;
                  top: 0;
                  left: 0;
                  width: 100%;
                  pointer-events: none;
                  height: auto;
                }
              }
              .model {
                margin-left: 6px;
              }
            }
          }
        }
      }
    }
    .foot-box {
      width: 100%;
      padding: 20px 20px;
      background: #f9f9f9;
      > p {
        font-size: 12px;
        line-height: 17px;
        margin-bottom: 4px;
        color: #888;
        text-align: right;
        span {
          color: #444;
          font-size: 14px;
          &.red {
            font-weight: 600;
          }
        }
        > :last-child {
          margin-bottom: 0;
        }
      }
    }
  }
}
.gary {
  color: #999;
}
.additional-items {
  border-top: 1px dashed #eee;
  padding: 14px 0;
  width: 1114px;
  // > div {
  //   > div {
  //     > p {
  //       margin-bottom: 6px;
  //       &:last-child {
  //         margin-bottom: 0px;
  //       }
  //     }
  //   }
  // }
}
</style>
