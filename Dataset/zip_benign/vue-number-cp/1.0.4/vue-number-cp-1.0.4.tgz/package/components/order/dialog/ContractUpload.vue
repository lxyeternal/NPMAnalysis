<template>
    <div v-if="dialogVisible">
        <!-- 上传合同 -->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="870px" center :close-on-click-modal="false">
            <div class="tl">
                <PanelTitle :tabs="tabs" @select="handleSelectTab" bg-color="#fff"></PanelTitle>
                <div v-if="form.documentType=='10'" class="tip">

                    上传文件大小不要压缩。 根据提示上传对应的货物供应合同文本及审批附件，请<span class="red">严格按照要求上传，切勿传错</span>。然后点击“确认并上传”即可。
                    <br>
                    <section v-if="!ifProfessionalSubcontracting">
                    1、合同文本上传入口：请根据平台提供的<a class="down-upload"  @click="loadContract()">合同模板</a>基础上更改合同条款，标准合同包含<span class="red">货物供应合同全套</span>（包含主合同及附件清单、技术要求、发货通知单、货物验收单、授权书、廉洁协议、应收应付对账单等）。
                    <br>
                    <span class="red">尤其注意！</span>请将涉及电子签章的主合同及相关附件合并成一个PDF文档后再上传，授权书线下签章不变。若上传的文件名称不规范，系统自动规范命名。
                    <br>
                    2、审批附件入口：上传审批需要的文件，可上传多份。此栏系统不支持命名规范，请自主规范命名。
                    </section>

                    <section v-else>
                    1、合同文本上传入口：请根据平台提供的<a class="down-upload"  @click="loadContract()">合同模板</a>基础上更改合同条款，标准合同包含<span class="red">专业分包合同全套</span>（包含主合同、合同条件及发货通知单、货物验收单、退货单、货物清单、授权书、廉洁协议、应收应付对账单、月度进度审核产值报告等）。
                    <br>
                    <span class="red">尤其注意！</span>请将涉及电子签章的<span class="red">主合同、合同条件及相关附件合并成一个PDF</span>文档后再上传，授权书线下签章不变。若上传的文件名称不规范，系统自动规范命名。
                    <br>
                    2、审批附件入口：上传除去合同外，审批需要的额外文件，可上传多份。此栏系统不支持命名规范，请自主规范命名。
                    </section>

                </div>

                <div v-if="form.documentType=='00'" class="tip">
                    上传文件大小不要压缩。 根据提示上传对应的货物采购合同文本及审批附件，请<span class="red">严格按照要求上传，切勿传错</span>。然后点击“确认并上传”即可。
                    <br>
                    <section v-if="!ifProfessionalSubcontracting">
                    1、合同文本上传入口：请根据平台提供的<a class="down-upload"  @click="loadContract()">合同模板</a>基础上更改合同条款，标准合同包含<span class="red">货物采购合同全套</span>（包含主合同及附件清单、技术要求、发货通知单、货物验收单、授权书、廉洁协议、应收应付对账单等）。
                    <br>
                    <span class="red">尤其注意！</span>请将涉及电子签章的主合同及相关附件合并成一个PDF文档后再上传，授权书线下签章不变。若上传的文件名称不规范，系统自动规范命名。
                    <br>
                    2、审批附件入口：上传审批需要的文件，可上传多份。此栏系统不支持命名规范，请自主规范命名。
                    </section>
                    <section v-else>
                    1、合同文本上传入口：请根据平台提供的<a class="down-upload"  @click="loadContract()">合同模板</a>基础上更改合同条款，标准合同包含<span class="red">专业分包合同全套</span>（包含主合同、合同条件及发货通知单、货物验收单、退货单、货物清单、授权书、廉洁协议、应收应付对账单、月度进度审核产值报告等）。
                    <br>
                    <span class="red">尤其注意！</span>请将涉及电子签章的<span class="red">主合同、合同条件及相关附件合并成一个PDF</span>文档后再上传，授权书线下签章不变。若上传的文件名称不规范，系统自动规范命名。
                    <br>
                    2、审批附件入口：上传除去合同外，审批需要的额外文件，可上传多份。此栏系统不支持命名规范，请自主规范命名。
                    </section>
                </div>

                <br>
                <el-form v-show="showForm" ref="contractForm" :model="form" label-width="118px">
                    <el-form-item label="合同文本" class="contract-content">
                        <el-col :span="18">
                            <div class="contract-list">
                                {{contractName}}
                            </div>
                        </el-col>
                        <input v-if="showFile" id="contract-list" ref="contract-list" type="file" @change="handleUploadContract" />
                        <!--<label for="contract-list" :class="{'disable' : (form.documentType == '00' && !canUploadSContract) || (form.documentType == '10' && !canUploadBContract)}">选择文件</label>-->
                        <label v-if="(form.documentType == '00' && !canUploadSContract) || (form.documentType == '10' && !canUploadBContract)" class="file-label disable">选择文件</label>
                        <label class="file-label" v-if="(form.documentType == '00' && canUploadSContract) || (form.documentType == '10' && canUploadBContract)" for="contract-list">选择文件</label>
                        <!--<a @click="showRecord('contact')">上传记录</a>-->
                        <el-col :span="24" v-if="form.documentType == '10'">
                            <el-checkbox v-model="form.isSignedB" true-label="0" false-label="1"></el-checkbox> 合同待签章
                            <el-checkbox v-model="form.isSignedB" true-label="1" false-label="0"></el-checkbox> 合同已签章
                            <span v-if="form.isSignedB == '1'" class="red">（您勾选了合同已签章，已签章合同将不再合制平台上进行电子签章）</span>
                        </el-col>
                        <el-col :span="24" v-else>
                            <el-checkbox v-model="form.isSignedS" true-label="0" false-label="1"></el-checkbox> 合同待签章
                            <el-checkbox v-model="form.isSignedS" true-label="1" false-label="0"></el-checkbox> 合同已签章
                            <span v-if="form.isSignedS == '1'" class="red">（您勾选了合同已签章，已签章合同将不再合制平台上进行电子签章）</span>
                        </el-col>
                    </el-form-item>
                    <!-- <el-form-item>
                        <el-checkbox v-model="checked1" :disabled="isHistory" @change="handleChangeSign1"></el-checkbox>&nbsp;合同待签章
                        <el-checkbox v-model="checked2" @change="handleChangeSign2"></el-checkbox>&nbsp;合同已签章
                    </el-form-item> -->
                    <!-- <el-form-item label="附件2：技术要求" class="contract-content" label-width="118px" >
                        <el-col :span="18">
                            <div class="contract-list">
                                {{enclosureTwoPlaceholder}}
                            </div>
                        </el-col>
                        <input v-if="showFile" id="enclosure-two" ref="enclosure-two" type="file" @change="handleUploadEncTwo" />
                        <label for="enclosure-two">选择文件</label>
                        <a @click="showRecord('enclosureTwo')">上传记录</a>
                    </el-form-item>
                    <el-form-item class="contract-content" label-width="118px" >
                        <template slot="label">
                            <p class="label-title">附件5-1：授权书</p>
                            <p class="label-sub-title">(城市公司项目经理)</p>
                        </template>
                        <el-col :span="18">
                            <div class="contract-list">
                                {{enclosureFivePlaceholder}}
                            </div>
                        </el-col>
                        <input v-if="showFile" id="enclosure-five" ref="enclosure-five" type="file" @change="handleUploadEncFive($event,1)" />
                        <label for="enclosure-five">选择文件</label>
                        <a @click="showRecord('enclosureFive')">上传记录</a>
                    </el-form-item>
                    <el-form-item class="contract-content" label-width="118px" >
                        <template slot="label">
                            <p class="label-title">附件5-2：授权书</p>
                            <p class="label-sub-title">(供应方)</p>
                        </template>
                        <el-col :span="18">
                            <div class="contract-list">
                                {{enclosureFiveTwoPlaceholder}}
                            </div>
                        </el-col>
                        <input v-if="showFile" id="enclosure-five-two" ref="enclosure-five-two" type="file" @change="handleUploadEncFive($event,2)" />
                        <label for="enclosure-five-two">选择文件</label>
                        <a @click="showRecord('enclosureFiveTwo')">上传记录</a>
                    </el-form-item>
                    <el-form-item class="contract-content" label-width="118px" >
                        <template slot="label">
                            <p class="label-title">附件5-3：授权书</p>
                            <p class="label-sub-title">(施工单位)</p>
                        </template>
                        <el-col :span="18">
                            <div class="contract-list">
                                {{enclosureFiveThreePlaceholder}}
                            </div>
                        </el-col>
                        <input v-if="showFile" id="enclosure-five-three" ref="enclosure-five-three" type="file" @change="handleUploadEncFive($event,3)" />
                        <label for="enclosure-five-three">选择文件</label>
                        <a @click="showRecord('enclosureFiveThree')">上传记录</a>
                    </el-form-item> -->
                    <el-form-item label="审批附件" class="contract-content">
                        <el-col :span="18">
                            <div class="contract-list">
                                {{attachApprovalPlaceholder}}
                                <el-tag size="mini" closable v-for="(item,index) in attachList" :key="index" v-if="item.type=='attachApproval'" @close="handleDelAttach(index)">{{item.name}}</el-tag>
                            </div>
                        </el-col>
                        <input v-if="showFile" id="contract-approval" multiple="multiple" ref="contract-approval" type="file" @change="handleUploadAttachApproval" />
                        <label class="file-label" for="contract-approval">选择文件</label>
                        <!--<a @click="showRecord('attachApproval')">上传记录</a>-->
                    </el-form-item>
                    <!-- <el-form-item label="附件" class="contract-content">
                        <el-col :span="18">
                            <div class="contract-list">
                                {{attachPlaceholder}}
                                <el-tag size="mini" closable v-for="(item,index) in attachList" :key="index" v-if="item.type=='attach'" @close="handleDelAttach(index)">{{item.name}}</el-tag>
                            </div>
                        </el-col>
                        <input v-if="showFile" id="contract-attach" multiple="multiple" ref="contract-attach" type="file" @change="handleUploadAttach" />
                        <label for="contract-attach">选择文件</label>
                        <a @click="showRecord('contactOld')">上传记录</a>
                    </el-form-item> -->
                </el-form>
            </div>
            <div class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="goToConfirm">确认并上传</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
            <template v-if="upLoadRecordList.length !=0">
                <div class="upload-record-title">
                    <!--<span>货物供应合同及审批附件</span>-->
                    <span>{{form.documentType == '10' ? "货物供应合同及审批附件" : "货物采购合同及审批附件"}}</span>
                    <span>上传时间</span>
                </div>
                <div class="record-wrap">
                    <ul>
                        <li v-for="(item,ind) in upLoadRecordList" :key="ind">
                            <span><i class="blue hand" @click="handleView(item.attachUrl)">{{item.documentName}}</i></span>
                            <span>{{item.fileUploadTime}}</span>
                        </li>
                    </ul>
                </div>
            </template>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>

        <!-- 确认上传文件名称格式 -->
        <el-dialog class="confirm-dialog" title="确认上传文件名称" :append-to-body="true" :lock-scroll="true" :visible.sync="confirmVisible" width="50%" center :close-on-click-modal="false">
            <p class="title-tip">由于你上传的文件名，不符合规范，系统将自动更改成规范命名，请确认上传的文件对应的文件名称：</p>
            <p class="confirm-title" v-for="(text,index) in arrContactName" :key="index">
                <span class="title-bg"></span>
                {{text.name}}
            </p>
            <p class="title-tip" v-if="duplicateFiles.length > 0">此外，您上传的《{{duplicateFiles.join("》、《")}}》已存在，是否要覆盖？</p>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 120px" @click="handleChange">确认更改并上传</el-button>
                <el-button size="small" style="width: 120px" @click="cancelSubmit">取消</el-button>
            </div>
        </el-dialog>
        <el-dialog class="confirm-dialog" title="确认上传重复文件" :append-to-body="true" :lock-scroll="true" :visible.sync="duplicateFilesVisible" width="50%" center :close-on-click-modal="false">
            <p class="title-tip">您上传的《{{duplicateFiles.join("》、《")}}》已存在，是否要覆盖？</p>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 120px" @click="handleConfirm">确认</el-button>
                <el-button size="small" style="width: 120px" @click="cancelSubmit">取消</el-button>
            </div>
        </el-dialog>
        <!-- 确认上传文件名称格式 -->
        <!--<el-dialog class="confirm-dialog" :title="recordUpName" :append-to-body="true" :lock-scroll="true" :visible.sync="uploadRecordVisible" width="50%" center :close-on-click-modal="false">-->
            <!--<div class="upload-record-title">-->
                <!--<span>文件名称</span><span>上传时间</span>-->
            <!--</div>-->
            <!--<div class="record-wrap">-->
                <!--<ul v-if="upLoadRecordList.length !=0">-->
                    <!--<li v-for="(item,ind) in upLoadRecordList" :key="ind">-->
                        <!--<span>{{item.documentName}}</span>-->
                        <!--<span>{{item.createDt}}</span>-->
                    <!--</li>-->
                <!--</ul>-->
                <!--<p v-else>暂无上传记录</p>-->
            <!--</div>-->
            <!--<div class="upload-foot">-->
                <!--<el-button size="small" style="width: 120px" @click="uploadRecordVisible = false">关闭</el-button>-->
            <!--</div>-->
        <!--</el-dialog>-->
        <!-- 下载合同 -->
        <ContractDownload ref="contractDownload" :downloadOrder="order" :back="'返回'"></ContractDownload>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import PanelTitle from "@/components/base/PanelTitle";
import { InterfaceService } from "@/services/api";
import ContractDownload from "@/components/order/dialog/ContractDownload";
import { viewFile } from '@/utils/orderUtil';

const form = {
    documentType: "10",
    isSignedS:"0",
    isSignedB:"0",
};

const tabs = [
    { label: "货物供应合同", type: "10", active: true },
    { label: "货物采购合同", type: "00", active: false }
];

export default {
    components: {
        Loading,
        PanelTitle,
        ContractDownload
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            tabs: JSON.parse(JSON.stringify(tabs)),
            checked1: true,
            checked2: false,
            form: Object.assign({}, form),
            attachList: [],
            order: {},
            showFile: true,
            showForm: true,
            confirmVisible:false,
            arrContactName:[],
            uploadRecordVisible:false,
            duplicateFilesVisible:false,
            canUploadSContract:true,
            canUploadBContract:true,
            recordUpName:'',
            changeNameArr:[],
            allApprovalFile:[],
            upLoadRecordList:[],
            duplicateFiles:[],
            temporaryStorageAttachList:[]
        };
    },

    computed: {
        // 是否中间商 true 是, false 否
        isMiddleman() {
            return (this.uploadOrder && this.uploadOrder.brokerCorpId && this.uploadOrder.brokerCorpId.length) || false
        },
        contractName() {
            let name = "请选择PDF文件";
            this.attachList.forEach(item => {
                if (item.type == "contract") {
                    name = item.name;
                }
            });
            return name;
        },
        attachPlaceholder() {
            let name = "请选择Word、Excel或PDF格式文件，可同时上传多份";
            if (this.form.documentType == "10") {
                name = "请选择明源ERP审批流扫描文件，可同时上传多份";
            } else if (this.form.documentType == "00") {
                name = "请选择审批流文件，可同时上传多份";
            }
            this.attachList.forEach(item => {
                if (item.type == "attach") {
                    name = "";
                }
            });
            return name;
        },
        //暂时先封印起来，改完再改回来的事情发生还少吗.....
        // enclosureTwoPlaceholder() {
        //     let name = "请选择本合同附件《附件2：技术要求》 格式为PDF";
        //     this.attachList.forEach(item => {
        //         if (item.type == "enclosureTwo") {
        //             name = item.name;
        //         }
        //     });
        //     return name;
        // },
        // enclosureFivePlaceholder() {
        //     let name = "请选择《附件5-1授权委托书格式(城市公司项目经理)》格式为jpg/png/PDF";
        //     this.attachList.forEach(item => {
        //         if (item.type == "enclosureFive") {
        //             name = item.name;
        //         }
        //     });
        //     return name;
        // },
        // enclosureFiveTwoPlaceholder(){
        //     let name = "请选择《附件5-2授权委托书格式(供应方)》格式为jpg/png/PDF";
        //     this.attachList.forEach(item => {
        //         if (item.type == "enclosureFiveTwo") {
        //             name = item.name;
        //         }
        //     });
        //     return name;
        // },
        // enclosureFiveThreePlaceholder(){
        //     let name = "请选择《附件5-3授权委托书格式(施工单位)》格式为jpg/png/PDF";
        //     this.attachList.forEach(item => {
        //         if (item.type == "enclosureFiveThree") {
        //             name = item.name;
        //         }
        //     });
        //     return name;
        // },
        isHistory() {
            return this.order && this.order.enterFrom == 0;
        },
        attachApprovalPlaceholder(){
            let name = ''
            if( this.form.documentType == '00' ){
                name = "请上传审批所需文件，请自主规范命名，可选择多份";
            }else{
                name = "请上传ERP审批所需文件，请自主规范命名，可选择多份";
            }
            this.attachList.forEach(item => {
                if (item.type == "attachApproval") {
                    name = "";
                }
            });
            return name;
        },
        ifProfessionalSubcontracting(){
            return this.order && this.order.contractName && this.order.contractName.includes('专业分包')
        }
    },
    methods: {
        open(data) {
            this.order = data;
            this.attachList = [];
            this.temporaryStorageAttachList = [];
            this.form = Object.assign({}, form);
            this.checked1 = true;
            this.checked2 = false;
            if (this.isHistory) {
                this.checked1 = false;
                this.checked2 = true;
            }

            // 判断是否有中间商
            let itemTabs = this.$clone(tabs)
            // 如果是中间商 只保留 <货物采购合同>
            itemTabs = this.isMiddleman ? itemTabs : itemTabs.splice(1,1) ;
            itemTabs[0].active = true;
            this.tabs = itemTabs;
            this.form.documentType = itemTabs[0].type
            this.dialogVisible = true;
            this.showForm = true;
            this.showFile = false;
            this.$nextTick(() => {
                this.$refs["contractForm"].resetFields();
                this.showFile = true;
            });
            this.canUploadSContract = true;
            this.canUploadBContract = true;
            this.init();
            this.getContractInfo()
        },
        loadContract(){
            console.log(this.order);
            this.$refs["contractDownload"].open(this.order, "template");
        },
        handleView(url) {
            if (url) {
              viewFile(url)
            }
        },
        handleSelectTab(tab) {
            let onOff = true; //是不是点击了相同的tab
            if( this.form.documentType != tab.type ){
                onOff = false;
            }
            this.form.documentType = tab.type;
            this.checked1 = true;
            this.checked2 = false;
            if (this.isHistory) {
                this.checked1 = false;
                this.checked2 = true;
            }
            let arr = [] //用来获取之前tab上上传的数据
            if( !onOff ){
                if( this.temporaryStorageAttachList.length != 0 ){
                    arr = [...this.temporaryStorageAttachList]
                    this.temporaryStorageAttachList = [];
                }
                this.temporaryStorageAttachList = [...this.attachList]
                this.attachList = [];
                let ifCurrent = false;
                arr.forEach((item)=>{
                    if( ( tab.type == '00' && (item.documentType == '00' || item.documentType == '06') ) || ( tab.type == '10' && (item.documentType == '10' || item.documentType == '16') ) ){
                        ifCurrent = true
                    }
                })
                if(ifCurrent){
                    this.attachList = [...arr]
                }
            }

            this.showFile = false;
            this.$nextTick(() => {
                this.$refs["contractForm"].resetFields();
                this.showFile = true;
            });

            this.showForm = false;
            setTimeout(() => {
                this.showForm = true;
            }, 200);
            this.getContractInfo();
        },
        handleChangeSign1() {
            this.checked1 = true;
            this.checked2 = false;
        },
        handleChangeSign2() {
            this.checked1 = false;
            this.checked2 = true;
        },
        handleUploadContract(e) {
            const file = e.target.files[0];
            if (!file) {
                return;
            }
            if (!file.type.match("pdf")) {
                this.$message.error("请上传PDF文件");
                return;
            }
            if (file.size > 52428800) {
                this.$message.error("您上传文件过大，请选择小于50MB的文件上传");
                this.$refs["contract-list"].value = null;
                return;
            }
            let hasContract = false;
            this.attachList.forEach(item => {
                if (item.type == "contract") {
                    item.file = file;
                    item.name = file.name;
                    item.documentType = this.form.documentType
                    hasContract = true;
                }
            });
            if (!hasContract) {
                this.attachList.push({
                    type: "contract",
                    file: file,
                    name: file.name,
                    documentType: this.form.documentType
                });
            }
            this.$refs["contract-list"].value = null
        },
        handleUploadAttach(e) {
            const files = e.target.files;
            if (!files || !files.length) {
                return;
            }

            Array.prototype.forEach.call(files, file => {
                this.attachList.push({
                    type: "attach",
                    file: file,
                    name: file.name
                });
            });
            e.value = "";
        },
        handleUploadAttachApproval(e) {

            const files = e.target.files;
            console.log(files);
            if (!files || !files.length) {
                return;
            }
            let overSizeList = [];
            let type = '';
            if( this.form.documentType == '00' ){
                type = '06'
            }else{
                type = '16'
            }
            Array.prototype.forEach.call(files, file => {
                if (file.size <= 52428800) {
                    this.attachList.push({
                        type: "attachApproval",
                        file: file,
                        name: file.name,
                        documentType:type
                    });
                }else {
                    overSizeList.push(file.name);
                }
            });
            if (overSizeList.length > 0) {
                this.$message.error("您上传的文件"+overSizeList.join("、")+"过大，请选择小于50MB的文件上传");
            }
            e.value = "";
            this.$refs["contract-approval"].value = null
        },
        handleUploadEncTwo(e) { //选择附件2
            const file = e.target.files[0];
            if (!file) {
                return;
            }
            if (!file.type.match("pdf")) {
                this.$message.error("请上传PDF文件");
                return;
            }
            let hasContract = false;
            this.attachList.forEach(item => {
                if (item.type == "enclosureTwo") {
                    item.file = file;
                    item.name = file.name;
                    hasContract = true;
                }
            });
            if (!hasContract) {
                this.attachList.push({
                    type: "enclosureTwo",
                    file: file,
                    name: file.name
                });
            }
        },
        handleUploadEncFive(e,num) { //选择附件5
            const file = e.target.files[0];
            if (!file) {
                return;
            }
            if (!file.type.match("pdf") && !file.type.match("jpg") && !file.type.match("jpeg") && !file.type.match("png")) {
                this.$message.error("请上传jpg/png/PDF文件");
                return;
            }
            let hasContract = false;
            this.attachList.forEach(item => {
                if (item.type == "enclosureFive" && num == 1) {
                    item.file = file;
                    item.name = file.name;
                    hasContract = true;
                }
                if (item.type == "enclosureFiveTwo" && num == 2) {
                    item.file = file;
                    item.name = file.name;
                    hasContract = true;
                }
                if (item.type == "enclosureFiveThree" && num == 3) {
                    item.file = file;
                    item.name = file.name;
                    hasContract = true;
                }
            });
            if (!hasContract) {
                if( num == 1 ){
                    this.attachList.push({
                        type: "enclosureFive",
                        file: file,
                        name: file.name
                    });
                }else if( num == 2 ){
                    this.attachList.push({
                        type: "enclosureFiveTwo",
                        file: file,
                        name: file.name
                    });
                }else{
                    this.attachList.push({
                        type: "enclosureFiveThree",
                        file: file,
                        name: file.name
                    });
                }
            }
        },
        // 删除附件
        handleDelAttach(index) {
            this.attachList.splice(index, 1);
        },
        goToConfirm(){
            let reg = /\.\w+$/;
            let regLeft = /《/;
            let regRight = /》/;
            this.arrContactName = [] //显示
            this.changeNameArr = [] //临时存改变名字
            this.duplicateFiles = [] //审批重复文件
            let contractName = this.order.contractName;
            // let type = this.form.documentType
            let onOff = true;
            let SupplyAndInstallation = true;
            if( contractName && contractName.match('专业分包') ){
                onOff = false
            }
            if( contractName && contractName.match('供应及安装') ){
                SupplyAndInstallation = false
            }
            let arr = [] //存附件5的内容
            const allAttachList = [].concat(this.attachList, this.temporaryStorageAttachList);
            // this.attachList = this.attachList.concat(this.temporaryStorageAttachList)
            // this.attachList.forEach((item)=>{
            allAttachList.forEach((item)=>{
                let fileName = item.name.replace(reg,'').replace(regLeft,'').replace(regRight,'');
                let fileExt = item.name.replace(/.+\./,"");
                let str = this.order.contractName;
                let type = item.documentType;
                if( item.type == 'contract' ){
                    if( !onOff ){
                        if( str != fileName ){
                            this.arrContactName.push({
                                name:'合同文本：'+ fileName +'，上传后系统自动命名成《'+str+'》'
                            })
                            this.changeNameArr.push({
                                type:'contract',
                                name:`《${str}》.${fileExt}`,
                                documentType: type
                            })
                        }
                    }else{
                        if( type == '10' ){
                            if( !SupplyAndInstallation ){
                                let SupplyAndInstallationStr = str.replace('供应及安装合同','供应及安装供应合同')
                                if( SupplyAndInstallationStr != fileName ){
                                    this.arrContactName.push({
                                        name:'合同文本：'+fileName+'，上传后系统自动命名成《'+SupplyAndInstallationStr+'》'
                                    })
                                    this.changeNameArr.push({
                                        type:'contract',
                                        name: `《${SupplyAndInstallationStr}》.${fileExt}`,
                                        documentType: type
                                    })
                                }
                            }else{
                                str = str && str.replace('供应合同','货物供应合同')
                                if( str != fileName ){
                                    this.arrContactName.push({
                                        name:'合同文本：'+fileName+'，上传后系统自动命名成《'+str+'》'
                                    })
                                    this.changeNameArr.push({
                                        type:'contract',
                                        name: `《${str}》.${fileExt}`,
                                        documentType: type
                                    })
                                }
                            }
                        }else{
                            if( !SupplyAndInstallation ){
                                let SupplyAndInstallationStr = str && str.replace('供应及安装合同','供应及安装采购合同')
                                if( SupplyAndInstallationStr != fileName ){
                                    this.arrContactName.push({
                                        name:'合同文本：'+fileName+'，上传后系统自动命名成《'+SupplyAndInstallationStr+'》'
                                    })
                                    this.changeNameArr.push({
                                        type:'contract',
                                        name:  `《${SupplyAndInstallationStr}》.${fileExt}`,
                                        documentType: type
                                    })
                                }
                            }else{
                                str = str && str.replace('供应合同','货物采购合同')
                                if( str != fileName ){
                                    str = str && str.replace('供应合同','采购合同')
                                    this.arrContactName.push({
                                        name:'合同文本：'+fileName+'，上传后系统自动命名成《'+str+'》'
                                    })
                                    this.changeNameArr.push({
                                        type:'contract',
                                        name: `《${str}》.${fileExt}`,
                                        documentType: type
                                    })
                                }
                            }
                        }
                    }
                }
                if( item.type == 'enclosureTwo' ){
                    if( fileName != '附件2：技术要求' ){
                        this.arrContactName.push({
                            name:'附件2：技术要求：'+fileName+'，上传后系统自动命名成《附件2 技术要求》'
                        })
                        this.changeNameArr.push({
                            type:'enclosureTwo',
                            name: '附件2：技术要求' + '.' + fileExt
                        })
                    }
                }
                if( item.type == 'enclosureFive' ){
                    if( fileName != '附件5-1：委托授权书格式(城市公司项目经理)' ){
                        this.arrContactName.push({
                            name:'附件5-1：授权书(城市公司项目经理)：'+fileName+'，上传后系统自动命名成《附件5-1委托授权书格式(城市公司项目经理)》'
                        })
                        this.changeNameArr.push({
                            type:'enclosureFive',
                            name: '附件5-1：委托授权书格式(城市公司项目经理)' + '.' + fileExt
                        })
                    }
                }
                if( item.type == 'enclosureFiveTwo' ){
                    if( fileName != '附件5-2：委托授权书格式(供应方)' ){
                        this.arrContactName.push({
                            name:'附件5-2：授权书(供应方)：'+fileName+'，上传后系统自动命名成《附件5-2委托授权书格式(供应方)》'
                        })
                        this.changeNameArr.push({
                            type:'enclosureFiveTwo',
                            name: '附件5-2：委托授权书格式(供应方)' + '.' + fileExt
                        })
                    }
                }
                if( item.type == 'enclosureFiveThree' ){
                    if( fileName != '附件5-3：委托授权书格式(施工单位)' ){
                        this.arrContactName.push({
                            name:'附件5-3：授权书(施工单位)：'+fileName+'，上传后系统自动命名成《附件5-3委托授权书格式(施工单位)》'
                        })
                        this.changeNameArr.push({
                            type:'enclosureFiveThree',
                            name: '附件5-3：委托授权书格式(施工单位)' + '.' + fileExt
                        })
                    }
                }
                if( item.type == 'attachApproval' ){
                    // this.allApprovalFile.forEach(_item=>{
                    this.upLoadRecordList.forEach(_item=>{
                        if ((type == "16" || type == "06") && (item.documentType == "06" || item.documentType == "16")) {
                            if (item.name == _item.documentName) {
                                this.duplicateFiles.push(_item.documentName)
                            }
                        }
                    })
                    // if( fileName != '附件5-3：委托授权书格式(施工单位)' ){
                    //     this.arrContactName.push({
                    //         name:'附件5-3：授权书(施工单位)：'+fileName+'，上传后系统自动命名成《附件5-3委托授权书格式(施工单位)》'
                    //     })
                    //     this.changeNameArr.push({
                    //         type:'enclosureFiveThree',
                    //         name: '附件5-3：委托授权书格式(施工单位)' + '.' + fileExt
                    //     })
                    // }
                }
            });
            if(this.changeNameArr.length != 0){
                this.confirmVisible = true;
            }else if (this.changeNameArr.length == 0 && this.duplicateFiles.length != 0){
                this.duplicateFilesVisible = true
            }else {
                this.concatAttach();
                this.handleConfirm()
            }
        },
        // showRecord(str){
        //     let documentType = this.form.documentType + ''
        //     let sDocumentType = ''
        //     switch(str){
        //         case 'contact':
        //             if( this.form.documentType == '10' ){
        //                 this.recordUpName = '货物供应合同上传记录'
        //             }else{
        //                 this.recordUpName = '货物采购合同上传记录'
        //             }
        //         break;
        //         case 'enclosureTwo':
        //            this.recordUpName = '附件2：技术要求上传记录'
        //            sDocumentType = '2'
        //         break;
        //         case 'enclosureFive':
        //            this.recordUpName = '附件5-1：授权书(城市公司项目经理)合同上传记录'
        //            sDocumentType = '5-1'
        //         break;
        //         case 'enclosureFiveTwo':
        //            this.recordUpName = '附件5-2：授权书(供应方)合同上传记录'
        //            sDocumentType = '5-2'
        //         break;
        //         case 'enclosureFiveThree':
        //            this.recordUpName = '附件5-3：授权书(施工单位)合同上传记录'
        //            sDocumentType = '5-3'
        //         break;
        //         case 'attachApproval':
        //            this.recordUpName = '审批附件'
        //         break;
        //     }
        //
        //     if( str == 'enclosureTwo' ||
        //         str == 'enclosureFive' ||
        //         str == 'enclosureFiveTwo' ||
        //         str == 'enclosureFiveThree' ){
        //         if( documentType == '00' ){
        //             documentType = '04'
        //         }
        //         if( documentType == '10' ){
        //             documentType = '14'
        //         }
        //     }
        //     if (str == 'attachApproval') {
        //         if( documentType == '00' ){
        //             documentType = '06'
        //         }
        //         if( documentType == '10' ){
        //             documentType = '16'
        //         }
        //     }
        //     let params = {
        //         orderNo:this.order.orderNo,
        //         documentType:documentType,
        //         sDocumentType:sDocumentType
        //     };
        //
        //     InterfaceService.uploadContractRecord(
        //         params,
        //         data => {
        //             if (data.respData.respCode === "0000") {
        //                 this.upLoadRecordList = data.respData.documentInfoList
        //                 this.upLoadRecordList.forEach((item)=>{
        //                     item.createDt  = item.createDt.substring(0,16)
        //                 })
        //                 // this.uploadRecordVisible = true;
        //             } else {
        //                 this.$message.error(data.respData.respMsg);
        //             }
        //         },
        //         data => {},
        //         () => {
        //             this.isLoading = true;
        //         },
        //         () => {
        //             this.isLoading = false;
        //         }
        //     );
        //
        // },
        getContractInfo() {
            this.upLoadRecordList = [];
            let documentType = this.form.documentType + '';
            const params = {
                orderNo: this.order.orderNo,
                bs: documentType == "00" ? "S" : "B",
                // fileFrom:"userUpload"
            };
            InterfaceService.getContractInfo(
                params,
                data => {
                    let documentInfos = data.respData.documentInfos || [];
                    if (data.respData.respCode === "0000") {
                        // console.log(data);
                        documentInfos.forEach(item=>{
                            if (documentType == "00" ){
                                if (item.documentType == "00" || item.documentType == "06") {
                                    this.upLoadRecordList.push(item)
                                    // let onOff = false;
                                    // this.allApprovalFile.forEach(_item=>{
                                    //     if (_item.documentId == item.documentId) {
                                    //         onOff = true;
                                    //     }
                                    // });
                                    // if (!onOff) {
                                    //     this.allApprovalFile.push(item)
                                    // }
                                }
                            }else {
                                if (item.documentType == "10" || item.documentType == "16") {
                                    this.upLoadRecordList.push(item)
                                    // let onOff = false;
                                    // this.allApprovalFile.forEach(_item=>{
                                    //     if (_item.documentId == item.documentId) {
                                    //         onOff = true;
                                    //     }
                                    // });
                                    // if (!onOff) {
                                    //     this.allApprovalFile.push(item)
                                    // }
                                }
                            }
                        });
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {
                },
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        handleChange(){
            this.concatAttach();
            this.attachList.forEach((item)=>{
                this.changeNameArr.forEach((val)=>{
                    if( val.type == item.type ){
                        if (val.documentType) {
                            if (item.documentType === val.documentType) {
                                item.name = val.name
                            }
                        } else {
                            item.name = val.name;
                        }
                    }
                })
            });
            this.handleConfirm()
        },
        handleConfirm() {
            // 去掉上传合同限制
            // let valid = false;
            let valid = true;
            // this.attachList.forEach(item => {
            //     if (item.type == "contract") {
            //         valid = true;
            //     }
            // });
            if (!this.attachList.length) {
                this.$message.error("请上传文件");
                return;
            }

            if (valid) {
                this.isLoading = true;
                this.uploadContractToOss().then(res => {
                    this.isLoading = false;
                    this.attachList.forEach((item, index) => {
                        res.forEach(oss => {
                            if (index == oss.index) {
                                item.url = oss.url;
                            }
                        });
                    });
                    this.uploadContract();
                });
            } else {
                this.$message.error("请上传合同");
            }
        },
        concatAttach(){
            this.attachList = this.attachList.concat(this.temporaryStorageAttachList);
        },
        uploadHander(data, pos, file, dirName, callBack,customName) {
            InterfaceService.uploadToOss(data, file, dirName, pos, callBack,customName);
        },
        // 文件上传到oss
        uploadContractToOss() {
            return new Promise((resolve, reject) => {
                //去后端拿签名
                InterfaceService.getOssSignature(
                    { type: "1" },
                    data => {
                        console.log(data);
                        const promiseList = [];
                        this.attachList.forEach((item, index) => {
                            let now = new Date().getTime()+index;
                            let dirName;
                            if (this.form.documentType == "10") {
                                dirName = this.order.orderNo + "/internalFiles/" + now + "/";
                                if( item.documentType == '06' || item.documentType == '00' ){
                                    dirName = this.order.orderNo + "/externalFiles/" + now + "/";
                                }
                            } else if (this.form.documentType == "00") {
                                dirName = this.order.orderNo + "/externalFiles/" + now + "/";
                                if( item.documentType == '10' || item.documentType == '16' ){
                                    dirName = this.order.orderNo + "/internalFiles/" + now + "/";
                                }
                            }
                            const promise = new Promise(_resolve => {
                                this.uploadHander(
                                    data,
                                    index,
                                    item.file,
                                    dirName,
                                    (pos, file, dir, signature) => {
                                        let u = signature.dir + dir + item.name;
                                        _resolve({ index: index, url: u });
                                    },
                                    item.name
                                )
                            });
                            promiseList.push(promise);
                        });
                        // 上传所有图片后回调
                        Promise.all(promiseList).then(values => {
                            resolve(values);
                        });
                    },
                    data => {}
                );
            });
        },
        uploadContract() {
            const documentInfos = [];
            let documentType = null;
            let sDocumentType = '';
            console.log(this.attachList);
            this.attachList.forEach(item => {
                if( !item.documentType ){
                    if (item.type == "attach" || item.type == 'enclosureTwo' || item.type == 'enclosureFive' || item.type == 'enclosureFiveTwo' || item.type == 'enclosureFiveThree') {
                        if (this.form.documentType == "00") {
                            documentType = "04";
                        } else if (this.form.documentType == "10") {
                            documentType = "14";
                        }
                    }else if (item.type == "attachApproval") {
                        if (this.form.documentType == "00") {
                            documentType = "06";
                        } else if (this.form.documentType == "10") {
                            documentType = "16";
                        }
                    }else {
                        documentType = this.form.documentType;
                    }
                    if( item.type == 'enclosureTwo' ){
                        sDocumentType = '2'
                    }else if( item.type == 'enclosureFive' ){
                        sDocumentType = '5-1'
                    }else if( item.type == 'enclosureFiveTwo' ){
                        sDocumentType = '5-2'
                    }else if( item.type == 'enclosureFiveThree' ){
                        sDocumentType = '5-3'
                    }else if (item.type == "attachApproval") {
                        sDocumentType = ''
                    }
                }else{
                    documentType = item.documentType
                }
                let doc = {
                    documentName: item.name,
                    documentType: documentType,
                    sDocumentType: sDocumentType,
                    attachUrl: item.url
                };
                documentInfos.push(doc);
                documentInfos.forEach(_item=>{
                    if (_item.documentType[0] == "0") {
                        _item.isSigned= this.form.isSignedS;
                        _item.bs = "S"
                    }
                    if (_item.documentType[0] == "1") {
                        _item.isSigned= this.form.isSignedB;
                        _item.bs = "B"
                    }
                })
            });
            const params = {
                orderNo: this.order.orderNo,
                documentInfos: documentInfos
            };
            console.log(params);
            InterfaceService.uploadContract(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.$message.success("上传合同成功");
                        // this.dialogVisible = false;
                        this.confirmVisible = false;
                        this.duplicateFilesVisible = false;
                        this.uploadRecordVisible = false;
                        this.attachList = [];
                        this.temporaryStorageAttachList=[]
                        this.getContractInfo();
                        if (this.form.isSignedS == "1") {
                            this.canUploadSContract = false
                        }
                        if (this.form.isSignedB == "1") {
                            this.canUploadBContract = false
                        }
                        this.$emit("close", true);
                    } else {
                        this.attachList = this.attachList.filter((item)=>{
                            if( (this.form.documentType == '10' && (item.documentType == '10' || item.documentType == '16')) || (this.form.documentType == '00' && (item.documentType == '00' || item.documentType == '06')) ){
                                return true
                            }
                        })
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        cancelSubmit(){
            this.confirmVisible = false;
            this.duplicateFilesVisible = false
        },
        init() {
            const order = this.order;
            if (order.eventList) {
                order.eventList.forEach(item => {
                    // 签章中不能上传合同
                    if (item.eventType == 0 && (item.eventStatus == 1 || item.eventStatus == 2)) {
                        if (item.documentType == "00") {
                            // 只显示内部合同上传
                            // this.tabs = [
                            //     {
                            //         label: "货物供应合同",
                            //         type: "10",
                            //         active: true
                            //     }
                            // ];
                            this.canUploadSContract = false;
                            // this.handleSelectTab(this.tabs[0]);
                        } else if (item.documentType == "10") {
                            this.canUploadBContract = false;
                            // 只显示外部合同上传,
                            // this.tabs = [
                            //     {
                            //         label: "货物采购合同",
                            //         type: "00",
                            //         active: true
                            //     }
                            // ];
                            // this.handleSelectTab(this.tabs[0]);
                        }
                    }
                });
            }
        }
    },
    props:['uploadOrder'],
};
</script>

<style lang="scss" scoped>
.el-tag + .el-tag {
    margin-left: 10px;
}

.info {
    color: #888888;
}
.dialog {
    line-height: 25px;

    /deep/ .el-dialog__header {
        padding: 0;

        &:before {
            display: none;
        }
    }
}

.contract-content {
    position: relative;
    input[type="file"] {
        position: absolute;
        width: 0;
        height: 0;
        overflow: hidden;
        opacity: 0;
    }

    .file-label {
        width: 98px;
        display: inline-block;
        padding: 12px 20px;
        line-height: 1;
        white-space: nowrap;
        cursor: pointer;
        font-size: 14px;
        border: 1px solid #ffd64e;
        background: #ffd64e;
        margin-left: 10px;
    }
    .disable{
        /*padding: 12px 14px;*/
        border: 1px solid #dddddd;
        background: #dddddd;
        cursor: not-allowed;
        color: #afaeae;
    }
    /deep/ .el-checkbox {
        padding: 0;
        margin-left: 0;
        border: none;
        background: none;
    }
    /deep/ .el-col-24 label:nth-of-type(2){
            margin-left: 10px;
    }
    .label-title{
        width: 100%;
        line-height: 18px;
    }

    .label-sub-title{
        width: 100%;
        line-height: 16px;
        font-size: 12px;
    }

    .contract-list {
        min-height: 38px;
        padding: 0 10px;
        border: 1px solid #dcdfe6;
        line-height: 38px;
        color: #888888;
    }

    a{
       margin-left: 10px;
       color: #0082ff;
    }
}

.tip {
    font-size: 12px;
    line-height: 20px;

    .down-upload{
        color:#0082ff;
        text-decoration: underline;
    }
}

.title{
  position: relative;
  height: 12px;
  line-height: 12px;
  padding-left: 10px;
  text-align: left;

  .title-bg{
    width: 3px;
    height: 12px;
    position: absolute;
    background: #4f525a;
    top: 0;
    left: 0;
  }
}
.confirm-dialog{
    line-height: 25px;

    .title-tip{
        padding-bottom: 10px;
    }

    .confirm-title{
        position: relative;
        line-height: 20px;
        padding-left: 10px;
        text-align: left;

        .title-bg{
            width: 3px;
            height: 12px;
            position: absolute;
            background: #4f525a;
            top: 4px;
            left: 0;
        }
    }
    .upload-foot{
        width: 100%;
        text-align: center;
        margin-bottom: 10px;
    }
}
.upload-record-title{
    width: 100%;
    border-top: 1px solid #eeeeee;
    height: 34px;
    line-height: 34px;
    background: #f5f5f5;
    padding-left: 10px;

    span{
        float: left;
        height: 34px;
        line-height: 34px;
        color: #888888;
        text-align:left;
        border-bottom: 1px solid #fff;
    }
    span:first-child{
        width: 79%;
    }
}
.record-wrap{
    width: 100%;
    height: 234px;
    overflow-y: scroll;
    background: #f5f5f5;
    border-bottom: 1px solid #eee;
    margin-bottom: 20px;
    ul{
        padding-left: 10px;

        li{
            height: 52px;
            line-height: 52px;
            border-bottom: 1px solid #eeeeee;

            span:first-child{
                display: inline-block;
                width: 80%;
            }
            span{
                text-align: left;
            }
        }
    }

    p{
        padding-left: 10px;
        line-height: 30px;
    }
}
    /deep/ .dialog-footer{
        text-align: center;
        margin-bottom: 20px;
    }
</style>
