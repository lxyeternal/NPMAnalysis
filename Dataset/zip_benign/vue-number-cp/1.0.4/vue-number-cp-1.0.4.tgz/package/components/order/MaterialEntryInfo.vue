<template>
    <div>
        <PanelTitle title="项目合同人员信息"></PanelTitle>
        <div>
            <el-form ref="form" :model="form" :rules="rules">
                <!-- <el-form-item label="选择签署合同类型:" :rules="[{ required: true, message: '请选择合同类型', trigger: 'change' }]">
                            <el-radio-group v-model="form.contractType" @change="handleChangeContractType">
                                <el-radio label="0">采购合同</el-radio>
                                <el-radio label="1">专业分包合同</el-radio>
                            </el-radio-group>
                        </el-form-item> -->
                <!-- <hr> -->
                <!-- 'hidden':majorCode === 'C01' && part.role == '4' 专业名称是钢筋（C01）不显示 "技术标准" -->
                <el-row :class="{'special-title': part.role == '4','hidden':majorCode === 'C01' && part.role == '4'}" :gutter="150" v-for="(part,partIndex) in partList" :key="partIndex">
                    <el-col :span="24">
                        <p class="order-info-title">
                            {{part.label}}
                            <span v-if="part.role == '0' && contractType == 2" class="blue pointer" @click="handleAddConstruction">
                                +增加要料施工单位
                            </span>
                        </p>
                    </el-col>
                    <el-col :span="item.displaySort ? 24 : 8" v-for="(item,index) in filterRole(roleList,part.role)" :key="index">
                        <div>
                            <!-- 技术要求隐藏标题 -->
                            <p class="form-item-label" v-if="item.label">
                                <span v-if="(item.required && (item.role && item.role.length > 1)) || item.role == '03'" class="red">*&nbsp;</span>{{item.label}}
                                <el-tooltip v-if="item.tooltip" effect="dark" placement="top-start">
                                    <div slot="content" style="width: 200px">{{item.tooltip}}</div>
                                    <i class="el-icon-question tooltip-name"></i>
                                </el-tooltip>
                                ：
                                <span class="fr blue pointer" v-if="controlDel(roleList) && item.role == '0'" @click="handleDelConstruction(item.ind)">
                                    删除该单位
                                </span>
                            </p>
                            <!-- 企业 -->
                            <el-form-item v-if="item.role === part.role && item.label">
                                <el-select v-model="item.corpId" :placeholder="'请搜索或选择'+ item.label" clearable filterable remote :remote-method="handleFilterCorp" @change="handleChangeCorp(item,index,item.ind)" @visible-change="handleVisibleChage($event,item)" :disabled="part.role == '0'&& (contractType == '01'||contractType == '03')">
                                    <!-- 指定供应商为施工单位 -->
                                    <!--<el-option v-if="part.role == '0'" :label="'供应商：'+vendorCorp.corpName" :value="vendorCorp.corpId"></el-option>-->
                                    <el-option label="无" value="无">
                                    </el-option>
                                    <el-option v-show="option.show" v-for="option in filterCorpList(item.role,item.corpList)" :key="option.corpId" :label="option.corpName" :value="option.corpId">
                                    </el-option>
                                </el-select>
                            </el-form-item>
                            <!-- 角色 -->
                            <el-form-item v-if="item.role !== part.role && item.label" :error="showErrorMsg(item)">
                                <!-- 特殊处理 带上传 -->
                                <div v-if="item.displaySort" class="need-upload-container">
                                    <el-row>
                                        <!-- 如果role != 4 说明不是技术要求 -->
                                        <el-col :span="8" v-if="part.role != '4'" class="need-upload-select">
                                            <!-- 300 供应商 不显示下拉选择 -->
                                            <el-select v-if="item.roleId != '300'" v-model="item.acctId" :placeholder="'请选择'+ item.label" clearable :no-data-text="noDataText(item.label,item.role)" @change="handleChangeRole(item)">
                                                <el-option class="role-option" v-for="option in filterCurrentRole(item,item.acctList)" :key="option.acctId" :label="option.acctName" :value="option.acctId">
                                                    <span v-html="option.acctName" style="line-height: 30px" @click="handlegoUsersManage(option)">{{option.acctName}}{{option.desc}}</span>
                                                    <span v-if="option.mobile">(Tel:{{option.mobile}})</span>
                                                    <p v-if="filterRoleName(option.roleIds)" :title="filterRoleName(option.roleIds)">
                                                        {{filterRoleName(option.roleIds)}}</p>
                                                </el-option>
                                            </el-select>
                                            <el-input v-else :value="corpName" :disabled="true"></el-input>
                                        </el-col>
                                        <el-col :span="part.role == '4' ? 24 : 16">
                                            <ul :class="['neet-upload-upfile', {'disabled': item.upfileResultList && item.upfileResultList.length}]">
                                                <li>
                                                    <p class="input-file-p">
                                                        <span v-if="!item.fileName" class="gray">
                                                            请上传: {{item.getFileItem&&item.getFileItem.fileTypeName||''}} ,
                                                            格式为{{item.getFileItem&&item.getFileItem.uploadFileSuffix}}
                                                        </span>
                                                        <span v-else>{{item.fileName || ''}}</span>
                                                    </p>
                                                </li>
                                                <li>
                                                    <!-- :disabled="item.upfileResultList && item.upfileResultList.length != 0" -->
                                                    <UpfileComponent ref="upfileRef"
                                                                     :immediateClearList="true"
                                                                     :immediateSubmit="false"
                                                                     :fileSize="52428800"
                                                                     :fileSizeMsg="'上传文件不能超过50M, 请重新选择'"
                                                                     :btnName="'选择文件'"
                                                                     :dirName="`${new Date().getTime()}/`"
                                                                     :type="'5'"
                                                                     :fileTypes="item.getFileItem && item.getFileItem.uploadFileSuffix || ''"
                                                                     :id="(item.displaySort + (item.ind || 9999)).toString()"
                                                                     @outputList="outputUpfileList($event, item)"></UpfileComponent>
                                                </li>
                                                <li>
                                                    <!--  :disabled="!item.getFileItem || item.upfileResultList && item.upfileResultList.length===0"  -->
                                                    <el-button type="primary" @click.native="submitUpfile(index, item)">
                                                        上传
                                                    </el-button>
                                                    <el-button :disabled="!(item.getFileItem&&item.getFileItem.attachUrl)" @click="handleDoloadTemp(item)"> {{part.role === '4' ? '下载技术要求资料' : '下载授权书模板'}}
                                                    </el-button>
                                                </li>
                                            </ul>
                                        </el-col>
                                    </el-row>
                                    <el-row v-if="item.upfileResultList && item.upfileResultList[0] && item.upfileResultList[0].url">
                                        <el-col :span="24" class="neet-upload-col">
                                            <div class="neet-upload-body">
                                                <div class="title">
                                                    <el-col :span="20" align="left" clas>
                                                        {{part.role === '4' ? '已上传的技术要求资料' : '已上传的授权书'}}
                                                    </el-col>
                                                    <el-col :span="4" align="right">
                                                        操作
                                                    </el-col>
                                                </div>
                                                <ul>
                                                    <li v-for="(uItem, idx) in item.upfileResultList" :key="idx">
                                                        <el-col :span="20" align="left">
                                                            {{uItem.name || ''}}
                                                        </el-col>
                                                        <el-col :span="4" align="right">
                                                            <a class="blue" @click="handleDelUpfile(item, idx)">删除</a>
                                                        </el-col>
                                                    </li>
                                                </ul>
                                            </div>
                                        </el-col>
                                    </el-row>
                                </div>
                                <el-select v-else v-model="item.acctId" :placeholder="'请选择'+ item.label" clearable :no-data-text="noDataText(item.label,item.role)" @change="handleChangeRole(item)">
                                    <el-option class="role-option" v-for="option in filterCurrentRole(item,item.acctList)" :key="option.acctId" :label="option.acctName" :value="option.acctId">
                                        <span v-html="option.acctName" style="line-height: 30px" @click="handlegoUsersManage(option)">{{option.acctName}}{{option.desc}}</span>
                                        <span v-if="option.mobile">(Tel:{{option.mobile}})</span>
                                        <p v-if="filterRoleName(option.roleIds)" :title="filterRoleName(option.roleIds)">
                                            {{filterRoleName(option.roleIds)}}</p>
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </div>
                    </el-col>
                </el-row>
            </el-form>
        </div>
    </div>
</template>
<script>
    import accountMixin from "@/mixins/account";
    import PanelTitle from "@/components/base/PanelTitle";
    import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
    import { InterfaceService } from "@/services/api";

    const partList = [
            { role: "2", label: "项目公司" },
            { role: "3", label: "供应商" },
            { role: "0", label: "要料施工单位" },
            { role: "1", label: "监理单位" },
            { role: "4", label: "技术要求" },
        ],
        roleList = [{
            role: "21",
            roleId: "601",
            label: "收货方授权代表(城市公司项目经理)",
            required: true,
            corpId: "",
            acctId: "",
            corpList: [],
            acctList: [],
            defaultChoose: "",
            displaySort: "10"
        },
            {
                role: "20",
                roleId: "600",
                label: "项目部材料(设备)工程师",
                required: true,
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
                defaultChoose: ""
            },
            {
                role: "25",
                roleId: "602",
                label: "工程部收发货印章管理员",
                required: true,
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
                defaultChoose: ""
            },
            {
                role: "26",
                roleId: "605",
                label: "项目部合约经办人",
                required: true,
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
                defaultChoose: ""
            },
            {
                role: "27",
                roleId: "609",
                label: "项目部合约总监",
                required: true,
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
                defaultChoose: ""
            },
            // {
            //     role: "24",
            //     roleId: "603",
            //     label: "合同签字人",
            //     required: true,
            //     corpId: "",
            //     acctId: "",
            //     corpList: [],
            //     acctList: [],
            //     defaultChoose: ""
            // },
            {
                role: "22",
                roleId: "604",
                label: "合同盖章人",
                required: true,
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
                defaultChoose: ""
            },
            {
                role: "0", // 施工单位企业
                roleId: "0",
                // ind:"0",
                label: "企业",
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
            },
            {
                role: "01",
                roleId: "641",
                // ind:"0",
                label: "施工单位项目经理",
                required: true,
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
                defaultChoose: ""
            },
            {
                role: "02",
                roleId: "642",
                // ind:"0",
                label: "项目盖章人",
                required: true,
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
                defaultChoose: ""
            },
            {
                role: "00",
                roleId: "640",
                // ind:"0",
                label: "授权代表(指定收货人)",
                required: true,
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
                tooltip: "即该项目的发货通知和收货代表。在该项目材料设备发货通知和验收过程中签署《发货通知单》和《供应方发货及工地收货验收单》,均有效。",
                defaultChoose: "",
                displaySort: "30"
            },
            {
                role: "1", // 监理单位企业
                roleId: "1",
                label: "企业",
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
            },
            {
                role: "11",
                roleId: "661",
                label: "项目盖章人",
                required: true,
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
                defaultChoose: ""

            },
            {
                role: "10",
                roleId: "660",
                label: "授权代表",
                required: true,
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
                tooltip: "即该项目施工监理单位的收货验收代表。在该项目材料设备发货通知和验收过程中,签署《供应方发货及工地收货验收单》,均有效。",
                defaultChoose: "",
                displaySort: "40"
            },
            {
                role: "30", // 供应商 企业
                roleId: "300",
                // ind:"0",
                label: "企业",
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
                displaySort: "20"
            },
            {
                role: "40", // 技术要求
                roleId: "400",
                // ind:"0",
                label: "技术要求",
                corpId: "",
                acctId: "",
                corpList: [],
                acctList: [],
                displaySort: "50"
            }
        ],

        form = {
            contractType: "0"
        };

    export default {
        mixins: [accountMixin],
        components: {
            PanelTitle,
            UpfileComponent
        },
        props: {
            initData: {
                default: null
            },
            contractType: {
                default: "0"
            },
            projectMajorCode: {
                default: ""
            },
            corpName: {
                default: ""
            }
        },
        watch: {
            initData(val) {
                val = val || {}
                let sortItem = []
                this.vendorCorp = val.vendorCorp || this.vendorCorp;
                if (val.roleList && val.roleList.length) {
                    // 补充字段和按roleList 排序
                    val.roleList.map(s => {
                        roleList.some(m => {
                            let state = false
                            // 匹配, 补充缺失字段 displaySort, fileTypeId
                            if (m.role === s.role) {
                                s.displaySort = m.displaySort
                                s.fileTypeId = m.fileTypeId
                                sortItem.push(s)
                                state = true
                            }
                            return state
                        })
                    });
                    roleList.map(s => {
                        const result = val.roleList.some(m => {
                            let state = false
                            // 匹配, 补充缺失字段 displaySort, fileTypeId
                            if (m.role === s.role) {
                                state = true
                            }
                            return state
                        });
                        // 未匹配 直接赋值
                        if (!result) {
                            sortItem.push(s)
                        }
                    });
                    val.roleList.some(s => {
                        let state = false
                        // 03 特殊字段
                        if (s.role === '03') {
                            sortItem.push(s)
                            state = true
                        }
                        return state
                    })

                    // 排序

                    this.roleList = [...sortItem]
                    this.formatRoleList()
                }
                this.form = Object.assign(this.form, val.form);
                this.roleList.forEach(item => {
                    if (item.role === "0" && item.corpId && item.corpId !== "无") {
                        this.getSubRole(item.corpId, "0","init");
                    }
                    if (item.role === "1" && item.corpId && item.corpId !== "无") {
                        this.getSubRole(item.corpId, "1","init");
                    }
                    if (item.roleId == "606") {
                        item.roleId = "609"
                    }
                    if (item.role.length > 1 && !item.hide) {
                        item.required = true
                    } else if (item.role.length > 1) {
                        item.required = false
                    }
                    if (item.corpId != "无") {
                        item.hide = false
                    } else {
                        item.required = false;
                        item.hide = item.role.length > 1;
                        item.corpList = []
                    }
                });
                console.log(this.roleList);
                // this.setSelfCorp();
                this.setSelfCorp();
                this.getSubRole(this.userinfo.corpId, "2");
                this.getInitCrop();
            },
            contractType(val) {
                if (val) {
                    this.form.contractType = val == '01' ? '1' : '0';
                    this.handleChangeContractType();
                }
            },
            projectMajorCode(val) {
                if (val) {
                    this.majorCode = val;
                    this.handleChangeContractType();

                }
            }
        },
        data() {
            return {
                isLoading: false,
                form: Object.assign({}, form),
                rules: {},
                showError: false,
                roleList: JSON.parse(JSON.stringify(roleList)),
                vendorCorp: {},
                partList: partList,
                remoteTypeRole: null,
                remoteKeyword: '',
                remoteOnOff: false,
                remoteList: [],
                majorCode: '',
                getFirstCrop: true,
                remoteTypeInd: "",
                ind: 0,
                needUploadRoles: ['21', '00', '10', '30', '40'], // 需要上传的role
                upfileResultList: [], // 上传组件返回
                getFileList: [], // 查询交易文件上传配置接口  返回list
                unRequiredRoleId: ['300', '400'] // 无需验证的RoleId
            };
        },
        mounted() {
            this.init()
        },
        methods: {
            handleDoloadTemp(item) {
                const downItem = item.getFileItem || {}
                this.$download([{
                    name: downItem.templateFileName || '',
                    url: downItem.attachUrl || ''
                }]).then(result => {
                    this.$message.success('已下载')
                }).catch(err => {
                    this.$message.error('下载失败')
                })
            },
            handleDelUpfile(item, fIdx) {

                this.$set(item, 'fileName', '')
                item.upfileResultList.splice(fIdx, 1)
            },

            // 格式化 附件配置数据
            formatRoleList() {
                // 通过 需要上传的role 找到 对应数组
                this.roleList.forEach(s => {
                    let state = false
                    this.getFileList.map(m => {
                        if (s.displaySort === m.displaySort) {
                            s.fileTypeId = m.fileTypeId
                            this.$set(s, 'upfileResultList', s.upfileResultList || []);
                            this.$set(s, 'getFileItem', m);
                            state = true
                        }
                        return state
                    })
                    // 如果没找到则 赋值为空
                    if (!state) {
                        this.$set(s, 'getFileItem', {});
                    }
                })

            },

            // 上传附件
            submitUpfile(idx, item) {
                this.$refs.upfileRef.some(s => {
                    let state = false
                    if (s.id === (item.displaySort + (item.ind || 9999)).toString()) {
                        s.handleConfim(item.upfileItem || [])
                        item.upfileItem = []

                        this.$set(item, 'fileName', '')
                        state = true
                    }
                    return state
                })
            },
            // 文件上传反馈
            outputUpfileList(ev, item) {
                ev = [...ev] || []
                const name = ev[0] && ev[0].name && ev[0].name.slice(0, ev[0].name.lastIndexOf('.')) || '',
                    uploadFileNameRule = item.getFileItem && item.getFileItem.uploadFileNameRule || '',
                    getFileItem = item.getFileItem && item.getFileItem || {}

                // 文件名校验规则 包含/全等/不验证
                if (getFileItem.uploadFileNameRuleType === 'like') {
                    if (!name.includes(uploadFileNameRule)) {
                        this.$message.error(`请上传文件名包含 ${getFileItem.fileTypeName || ''} 的文件`)
                        return
                    }
                } else if (getFileItem.uploadFileNameRuleType === 'same') {
                    if (name !== uploadFileNameRule) {
                        this.$message.error(`请上传文件名为 ${getFileItem.fileTypeName || ''} 的文件`)
                        return
                    }
                }


                if (!(ev && ev[0] && ev[0].url)) {
                    this.$set(item, 'fileName', ev[0] && ev[0].name || '')
                    // 如果返回  没有数据 直接添加
                    if (!(item.upfileResultList && item.upfileResultList.length)) {
                        this.$set(item, 'upfileResultList', ev)
                    }
                    // 上传文件临时存储空间
                    this.$set(item, 'upfileItem', ev)
                } else {
                    this.$set(item, 'upfileResultList', ev)
                }
                console.log(ev, item, '----ev')
            },
            filterCorpList(role,list) {
                if (role == "0") {
                    if (!this.remoteOnOff) {
                        list.forEach(_item => {
                            let state = true;
                            this.roleList.forEach(__item=>{
                                if (_item.corpId === __item.corpId) {
                                    state = false
                                }
                            });

                            _item.show = state;
                        });
                    }else {
                        list.forEach(_item => {
                            let state = false;
                            this.remoteList.forEach(__item=>{
                                if (__item.corpId === _item.corpId) {
                                    state = true
                                }
                            })
                             _item.show = state
                        });
                    }
                }else {
                    list.forEach(_item => {
                        _item.show = true;
                    });
                }
                // console.log(outList);
                return list
            },
            filterRole(list, role) {
                return list.filter(item => {
                    return item.role[0] == role && !item.hide;
                });
            },
            // 下属人员的roleId有相应的角色时才显示，否则不予显示，例如授权代表一栏下属人员有此角色则显示，否则提示去用户管理添加
            filterCurrentRole(role, acctList) {
                let arr = [];
                acctList.forEach(item => {
                    if (item.roleIds) {
                        item.roleIds.forEach(__item => {
                            // console.log(__item);
                            if (__item.roleId == role.roleId) {
                                arr.push(item)
                            }
                        })
                    }
                });
                let onOff = false;
                arr.forEach(item => {
                    if (item.acctId == role.acctId) {
                        onOff = true
                    }
                });
                if (!onOff) {
                    role.acctId = ""
                }
                if (arr.length == 0 && role.role[0] == "2") {
                    role.acctId = "";
                    arr.push({
                        acctName: `<p style="color: #aaa">暂无${role.label}&nbsp;&nbsp;请设置<em style="cursor: pointer;color: #3a8ee6" @click="go()">权限管理</em>添加</p>`
                    })
                }
                return arr
            },
            go() {
                console.log(1);
            },
            filterRoleName(list) {
                const arr = [];
                if (list && list.length) {
                    list.forEach(item => {
                        if (item.roleName) {
                            arr.push(item.roleName);
                        }
                    });
                }

                return arr.join(",");
            },
            noDataText(label, role) {
                let str = "";
                if (role[0] == "0") {
                    str = `暂无${label},请联系施工方管理员`
                } else if (role[0] == "1") {
                    str = `暂无${label},请联系监理单位管理员`
                }
                return str
            },
            handleDelConstruction(ind) {
                this.roleList.forEach((item, index) => {
                    if (item.role == "0") {
                        if (item.ind == ind) {
                            this.roleList.splice(index, 4);
                        }
                    }
                });
            },
            handleAddConstruction() {
                let indArr = []
                this.roleList.forEach(item=>{
                    if (item.role == "0" && item.ind != undefined && !isNaN(item.ind)) {
                        indArr.push(item.ind)
                    }
                });
                this.ind = indArr.length > 0 ? +indArr.sort(function(a,b){return b-a;})[0] : 0;
                this.ind++;
                this.roleList.unshift({
                        role: "0", // 施工单位企业
                        roleId: "0",
                        ind: this.ind.toString(),
                        label: "企业",
                        corpId: "",
                        acctId: "",
                        corpList: [],
                        acctList: [],
                    },

                    {
                        role: "01",
                        roleId: "641",
                        ind: this.ind.toString(),
                        label: "施工单位项目经理",
                        required: true,
                        corpId: "",
                        acctId: "",
                        corpList: [],
                        acctList: [],
                        defaultChoose: ""
                    }, {
                        role: "02",
                        roleId: "642",
                        ind: this.ind.toString(),
                        label: "项目盖章人",
                        required: true,
                        corpId: "",
                        acctId: "",
                        corpList: [],
                        acctList: [],
                        defaultChoose: ""
                    }, {
                        role: "00",
                        roleId: "640",
                        ind: this.ind.toString(),
                        label: "授权代表(指定收货人)",
                        required: true,
                        corpId: "",
                        acctId: "",
                        corpList: [],
                        acctList: [],
                        tooltip: "即该项目的发货通知和收货代表。在该项目材料设备发货通知和验收过程中签署《发货通知单》和《供应方发货及工地收货验收单》,均有效。",
                        defaultChoose: "",
                        displaySort: "30"
                    },
                )
                this.formatRoleList()
            },
            handleVisibleChage($event, item) {
                if (!$event) return;
                this.remoteTypeRole = item.role;
                this.remoteTypeInd = item.ind;
                this.remoteKeyword = item.corpName;
                item.corpList.log
                if (item.role[0] == 0) {
                    this.getCorpList("construction", "", this.remoteTypeRole);
                } else if (item.role[0] == 1) {
                    this.getCorpList("supervisory", "",this.remoteTypeRole); //不输入关键字或清除之前的关键字时，只显示关联的监理单位列表。
                }
            },
            // 远程搜索施工、监理企业
            handleFilterCorp(keyword) {
                this.remoteKeyword = keyword;
                this.remoteOnOff = keyword !== "";
                if (this.remoteTypeRole[0] == 0) {
                    this.getCorpList("construction", keyword, this.remoteTypeRole);
                } else if (this.remoteTypeRole[0] == 1) {
                    this.getCorpList("supervisory", keyword, this.remoteTypeRole);
                }
            },
            // 切换企业
            handleChangeCorp(item, index, ind) {
                if (item.corpId == "") {
                    item.corpList = []
                }
                let corpIdList = [];
                this.roleList.forEach(_item => {
                    if (_item.role[0] == item.role[0] && _item.ind == ind) {
                        _item.corpId = item.corpId;
                        // _item.defaultChoose = null;
                        if (item.corpId == "") {
                            _item.acctList = []
                            _item.acctId = "";
                            _item.corpId = "";
                            _item.corpName = "";
                            _item.corpList = [];
                            _item.required = true
                        }
                        if (_item.role.length == 1 && item.corpList) {
                            item.corpList.forEach(corp => {
                                if (_item.corpId == corp.corpId) {
                                    _item.corpName = corp.corpName;
                                }
                            })
                        }
                        if (item.corpList.length == 0 && _item.corpId === this.vendorCorp.corpId) {
                            item.corpList = [{
                                corpId: this.vendorCorp.corpId,
                                corpName: this.vendorCorp.corpName
                            }];
                        }
                        _item.hide = _item.corpId == this.vendorCorp.corpId && _item.role.length > 1 && this.contractType != "02";
                        //选择无时，如果存在两个及以上的施工单位，则直接删除该施工单位，如果只有一条，则只隐藏干系人
                        if (item.corpId == "无" && _item.role.length > 1) {
                            if (item.role[0] === "0") {
                                if (this.controlDel(this.roleList)) {
                                    this.handleDelConstruction(ind)
                                } else {
                                    _item.hide = true;
                                    _item.required = false
                                }
                            } else if (item.role[0] === "1") {
                                _item.hide = true;
                                _item.required = false
                            }
                        } else if (item.corpId != "无" && _item.role.length > 1) {
                            _item.hide = false;
                            _item.required = true
                        }
                    }
                    if (_item.role == "0" && _item.corpId != "无") {
                        corpIdList.push(_item.corpId)
                    }
                });
                let repeatList = corpIdList.sort();
                for (let i = 0; i < corpIdList.length; i++) {
                    if (repeatList[i] == repeatList[i + 1] && repeatList[i] != "") {
                        this.$message.error("已存在该施工单位，请重新选择");
                        item.corpId = "";
                        return
                    }
                    if (repeatList[i] == this.vendorCorp.corpId && this.contractType == "02" &&
                        (this.majorCode != 'C63' && this.majorCode != 'C64' && this.majorCode != 'C65' && this.majorCode != 'C66' )) {
                        this.$message.error("该合同类型下无法选择供应商为施工方，请重新选择");
                        this.roleList.forEach(_item=>{
                            if (_item.corpId == this.vendorCorp.corpId) {
                                _item.corpId = "";
                                _item.acctList = [];
                            }
                        });
                        return
                    }
                }
                // if (item.corpId)
                if (item.corpId && item.corpId !== "无") {
                    this.getSubRole(item.corpId, item.role, ind);
                }
            },
            // 切换合同类型
            handleChangeContractType() {
                if (this.contractType != '02' && this.contractType != '04') {
                    let onOff = false;
                    this.roleList.forEach(item => {
                        if (item.role == "03") {
                            onOff = true
                        }
                    });
                    if (!onOff) {
                        this.roleList.push({
                            role: "03",
                            roleId: "300",
                            label: "企业",
                            corpId: "",
                            acctId: "",
                            corpList: [],
                            acctList: [],
                            displaySort: "30"
                        });
                    }
                    this.formatRoleList()

                } else {
                    let onOff = false
                    this.roleList.forEach((item, index) => {
                        if (item.role == "03") {
                            this.roleList.splice(index, 1);
                        }
                        if (item.role == '0') {
                            onOff = true
                        }
                    });
                    if (!onOff) {
                        this.handleAddConstruction()
                    }
                }
                this.roleList.forEach(item => {
                    if (item.role[0] == "0" && (this.contractType != '02' && this.contractType != '04')) {
                        // item.defaultChoose = "";
                        item.acctList = [];
                        // item.hide = this.form.contractType == 1 && item.role.length > 1;
                        // item.hide = (this.contractType == '01' || this.contractType == '03') && item.role.length > 1;
                        item.hide = item.role != "03";
                        // if (this.form.contractType == 1) {
                        item.corpList = [{
                            corpId: this.vendorCorp.corpId,
                            corpName: this.vendorCorp.corpName
                        }];
                        item.corpId = this.vendorCorp.corpId;
                        item.corpName = this.vendorCorp.corpName;
                    } else if (item.role[0] == "0" && (this.contractType == '02' || this.contractType == '04')) {
                        item.hide = false
                        if (item.corpId == "无") {
                            item.corpList = [];
                            item.corpName = "";
                            // item.defaultChoose = "";
                            item.acctId = "";
                            if (item.role.length > 1) {
                                item.hide = true;
                                item.required = false
                            }
                        } else if (item.corpId == this.vendorCorp.corpId) {
                            item.corpList = [];
                            item.acctList = [];
                            item.corpName = "";
                            // item.defaultChoose = "";
                            item.acctId = "";
                            item.corpId = "";
                        }
                    }
                });
                if (this.contractType != '02' && this.contractType != '04') {
                    this.roleList = this.roleList.filter((item) => {
                        return item.ind == undefined
                    });
                    this.roleList.forEach(item => {
                        if (item.role[0] == "0") {
                            item.required = false;
                        }
                    })
                } else {
                    this.roleList.forEach(item => {
                        if (item.role[0] == "0" && !item.hide) {
                            item.required = true;
                        }
                    })
                }
            },
            // 切换角色
            handleChangeRole(item) {
                // item.acctId = item.defaultChoose;
                // if (!item.acctId) {
                //     item.defaultChoose = ""
                // }
            },
            handlegoUsersManage(option) {
                if (option.acctName.indexOf("暂无") != -1) {
                    this.$router.push('/purchaserCenter/usersManage')
                }
            },
            controlDel(list) {
                let onOff = true;
                let num = 0;
                list.forEach(role => {
                    if (role.role == "0") {
                        num++
                    }
                });
                if (num <= 1) {
                    onOff = false
                } else {
                    onOff = true
                }
                return onOff
            },
            showErrorMsg(item) {
                if (!this.showError) return "";
                // 排除技术要求
                let msg;


                if (item.role.length != 1 && !item.acctId && item.required && !this.unRequiredRoleId.includes(item.roleId)) {
                    msg = "请选择" + item.label;
                }
                return msg;
            },
            showDialog(msg) {
                this.$alert(msg, {
                    dangerouslyUseHTMLString: true,
                    customClass: "alert-box",
                    center: true,
                    confirmButtonText: "知道了",
                    callback: action => {}
                });
            },
            // 设置本公司corp信息
            setSelfCorp() {
                const corp = {
                    corpId: this.userinfo.corpId,
                    corpName: this.userinfo.corpName
                };
                this.roleList.forEach(item => {
                    if (item.role[0] == 2) {
                        item.corpId = corp.corpId;
                        item.corpList = [corp];
                    }
                });
            },
            // 查询施工或监理公司信息
            getCorpList(type, corp, role) {
                const params = {
                    contractCorpType: type,
                };
                if (corp) {
                    params.corpName = corp;
                }
                InterfaceService.getStakeHolderCorp(
                    params,
                    data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            const corps = this.$clone(data.respData.corpInfos);
                            if (type === "construction") {
                                this.remoteList = corps
                                let list = [];
                                this.roleList.forEach(item=>{
                                    if (item.role == "0") {
                                        item.corpList.forEach(_item=>{
                                            let onOff = false;
                                            list.forEach(__item=>{
                                                if (__item.corpId && __item.corpId === _item.corpId) {
                                                    onOff = true
                                                }
                                            });
                                            if (!onOff) {
                                                list.push({
                                                    corpId: _item.corpId,
                                                    corpName: _item.corpName,
                                                })
                                            }
                                        })
                                    }
                                });
                                this.roleList.forEach(item => {
                                    if (item.role[0] == role[0]) {
                                        item.corpList = list;
                                        corps.forEach(_item=>{
                                            let onOff = false;
                                            item.corpList.forEach(__item=>{
                                                if (_item.corpId === __item.corpId) {
                                                    onOff = true
                                                }
                                            });
                                            if (!onOff) {
                                                item.corpList.push(_item)
                                            }
                                        });
                                    }
                                });

                            }else {
                                this.roleList.forEach(item => {
                                    if (item.role[0] == role[0]) {
                                        item.corpList = corps;
                                    }
                                });
                            }
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            // 查询项目部下属信息
            getSubRole(corpId, role, ind) {
                const params = {
                    corpId: corpId
                };
                InterfaceService.getQuerySubordinate(
                    params,
                    data => {
                        let res = data.respData;
                        let arr = [];
                        if (res.respCode === "0000") {
                            // 正常状态的用户（acctStatus == "0"）才可以作为干系人参与合同
                            let roles = [];
                            res.acctList && res.acctList.forEach(i=>{
                                if (i.acctStatus == "0") {
                                    roles.push(i)
                                }
                            });
                            roles = this.$clone(roles);
                            if (ind === "init" && (role === "0" || role === "1")) {
                                this.roleList.forEach(item => {
                                    if (item.role[0] == role[0] && item.corpId == corpId) {
                                        item.acctList = roles;
                                    }
                                });
                                return
                            }
                            this.roleList.forEach(item => {
                                if (item.role[0] == role[0] && item.ind == ind) {
                                    if (item.role.length > 1 && (item.role[0] == "0" || item.role[0] == "1")) {
                                        item.acctId = "";
                                    }
                                    item.acctList = roles;
                                    if (!item.acctId) {
                                        item.acctList.forEach(_item => {
                                            if (_item.roleIds) {
                                                _item.roleIds.forEach(_role => {
                                                    if (_role.roleId == item.roleId) {
                                                        arr.push({
                                                            "id": _role.roleId,
                                                            "acctName": _item.acctName,
                                                            "acctId": _item.acctId
                                                        })
                                                    }
                                                })
                                            }
                                        });
                                        let arr1 = [];
                                        arr.forEach(item => {
                                            arr1.push(item.id);
                                        });
                                        const filterNonUnique = arr => arr.filter(i => arr.indexOf(i) === arr.lastIndexOf(i));
                                        arr.forEach(item => {
                                            filterNonUnique(arr1).forEach(_item => {
                                                if (item.id == _item) {
                                                    this.roleList.forEach(__item => {
                                                        //当草稿存入数据时acctId不为空，不自动填充，以草稿为准
                                                        // if (__item.roleId == item.id && __item.defaultChoose == '' && __item.ind == ind){
                                                        if (__item.roleId == item.id && __item.ind == ind) {
                                                            // __item.defaultChoose = item.acctName
                                                            __item.acctId = item.acctId
                                                        }
                                                    })
                                                }
                                            })
                                        });
                                    }
                                }
                            });
                        } else {
                            this.$message.error(data.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },

            // 查询交易文件上传配置接口
            getOrderConfiguration() {
                return new Promise((resolve, reject) => {
                    const params = {
                        businessType: 'CONTRACT_FORMATION'
                    };

                    InterfaceService.getOrderConfiguration(params, data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            this.getFileList = res.uploadFileList || []
                            this.getFileList.map((m, idx) => m.idx = idx)
                            resolve(this.getFileList)
                        } else {
                            reject([])
                            this.$message.error(data.respMsg);
                        }
                    }, data => {}, () => {
                        this.isLoading = true;
                    }, () => {
                        this.isLoading = false;
                    })
                })
            },

            // 检验表单
            checkForm() {
                let valid = true;
                this.roleList.forEach(item => {
                    // if (item.role[0] == "2" && !item.defaultChoose) {
                    // if (item.role[0] == "2" && !item.acctId) {
                    if (item.role.length != 1 && !item.acctId && item.required && !this.unRequiredRoleId.includes(item.roleId)) {
                        //console.log(item);
                        valid = false;
                    }
                });

                if (!valid) {
                    this.$message.error("请填写材料进场信息");
                }
                this.showError = true;
                return valid;
            },
            // 获取信息
            getForm() {
                const arr = [];
                //  console.log(this.roleList);
                this.roleList.forEach(item => {
                    if (item.role.length > 1 && item.corpId && item.corpId != "无") {
                        if (item.corpId == this.vendorCorp.corpId && item.role != "03") {
                            if (this.contractType ==  "02") {
                                arr.push({
                                    role: item.role,
                                    corpId: item.corpId,
                                    acctId: item.acctId
                                });
                            }else if (this.contractType == "01" || this.contractType == "03"){
                                arr.push({
                                    role: item.role,
                                    corpId: item.corpId,
                                });
                            }
                        } else if (item.acctId) {
                            arr.push({
                                role: item.role,
                                corpId: item.corpId,
                                acctId: item.acctId
                            });
                        }
                    }
                });
                return arr;
            },
            getInitRoleList() {
                return this.$clone(roleList);
            },
            // 获取合同信息
            getContractData() {
                return {
                    contractType: this.form.contractType
                };
            },
            getDraftForm() {
                return this.roleList;
            },
            getInitCrop() {
                this.roleList.forEach(item => {
                    // if (item.acctList) {
                    //     item.acctList.forEach(_item=>{
                    //         if (item.defaultChoose == _item.acctId){
                    //             item.acctId = _item.acctId
                    //         }
                    //     })
                    // }else {
                    //     item.defaultChoose = ""
                    // }
                    if (item.role[0] != "0") {
                        // if (item.corpList && item.corpList.length == 1){
                        //     item.corpId = item.corpList[0].corpId
                        // }
                    } else {
                        if (this.contractType == '01' || this.contractType == '03') {
                            item.corpId = this.vendorCorp.corpId
                        } else {
                            if (item.role == "0" && item.corpName) {
                                item.corpList = [];
                                item.corpList.push({
                                    corpId: item.corpId,
                                    corpName: item.corpName,
                                });
                            }
                        }
                    }
                });
            },
            async init() {
                await this.getOrderConfiguration()
                this.formatRoleList()
            },

        },
    };
</script>
<style lang="scss" scoped>
    /deep/ .el-select {
        width: 100%;
    }

    hr {
        margin-bottom: 16px;
        border: none;
        border-bottom: 1px dashed #ccc;
    }

    .form-item-label {
        margin-bottom: 0px;
        font-size: 14px;
        line-height: 40px;
    }

    .tooltip-name {
        color: #ccc;

        &:hover {
            color: #444444;
        }
    }

    .order-info-title {
        margin: 5px 0;
        margin-bottom: 20px;
        padding: 0 10px;
        font-size: 14px;
        border-left: 3px solid #000;
        line-height: 12px;

        span {
            padding-left: 10px;
        }
    }

    .role-option {
        height: auto;

        p {
            /*height: 30px;*/
            max-width: 300px;
            line-height: 20px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
    }

    .pointer {
        cursor: pointer;
    }

    [class*="el-col-"] {
        display: inline-block;
        float: none;
    }

    .need-upload-container {
        .el-col-8.need-upload-select {
            width: 295px;
        }

        .el-col-16 {
            $labelWidth: 299px;
            width: calc(100% - #{$labelWidth});
        }

        .el-col {
            box-sizing: border-box;
            float: left;
        }

        .neet-upload-upfile {
            box-sizing: border-box;
            padding-left: 12px;
            display: flex;
            border-top: 1px solid transparent;

            &.disabled {
                /deep/ .center .blue {
                    // background: #dddddd !important;
                    // color: #a9a9a9 !important;
                }
            }

            &>li {
                width: 53%;

                &:nth-child(1) {
                    .input-file-p {
                        border: 1px solid #dcdfe6;
                        box-sizing: border-box;
                        padding: 0 12px;
                        color: #606266;
                        display: block;
                        display: flex;
                        flex-wrap: wrap;
                        min-height: 40px;

                        span {
                            height: 38px;
                        }

                        &>.gray {
                            color: #c0c4cc;
                            font-size: 12px;
                            outline: none;
                            height: 38px;
                        }

                        .el-tag {
                            margin: 4px;
                            height: 30px;
                        }
                    }
                }

                &:nth-child(2) {
                    width: 15%;
                }

                &:nth-child(3) {
                    width: 33%;
                }

                .el-button--default {
                    height: 38px;
                    margin-left: 4px;
                }
            }

            .el-button--primary {
                width: 119px;
                margin-right: 12px;
            }

            /deep/ .upfile-container {
                .center {
                    label {
                        width: 90%;
                        background-color: #ffd64e;
                        color: #000000 !important;
                        text-align: center;
                    }
                }
            }
        }

        .neet-upload-col {
            background: #f5f5f5;
            margin-top: 18px;
        }

        .neet-upload-body {
            width: 98%;
            margin: auto;
            font-weight: bold;
            font-size: 12px;

            ul {
                position: relative;

                &::before {
                    content: '';
                    height: 2px;
                    width: 103%;
                    background: #fff;
                    position: absolute;
                    left: -14px;
                    z-index: 0;
                    top: 34px;
                }
            }

            li {
                height: 36px;
                line-height: 36px;
            }

            .title {
                color: #888;
                font-weight: normal;
            }

            a {
                font-weight: normal;
            }
        }
    }

    /deep/ .el-row.special-title {
        &.hidden{
            display: none;
        }
        .order-info-title {
            height: 50px;
            background-color: #f5f5f5;
            color: #4f525a;
            font-size: 16px;
            line-height: 50px;
            border-bottom: 2px solid #ffd64e;
            margin-bottom: 10px;
            font-weight: 700;
            border-left: 0;
            position: relative;
            padding-left: 22px;

            &::before {
                content: "";
                height: 2px;
                width: 116px;
                position: absolute;
                background-color: #444;
                bottom: -2px;
                left: -1px;
            }
        }

        .neet-upload-upfile {
            &>li {
                width: 64%;

                /deep/ .upfile-container .center label {
                    width: 119px;
                }

                &:nth-child(2) {
                    width: 11%;
                }

                &:nth-child(3) {
                    width: 25%;
                }
            }
        }
    }
</style>