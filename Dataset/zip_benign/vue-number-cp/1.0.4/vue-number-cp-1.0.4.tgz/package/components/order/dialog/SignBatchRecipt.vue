<template>
    <div>
        <!-- 批量签署签收单 -->
        <el-dialog class="dialog" title="待签署签收单" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false">
            <div class="tl">
                <table class="table">
                    <tr v-for="(row,index) in signList" :key="index">
                        <td width="50">
                            <el-checkbox v-model="row.checked" @change="handleSelectRow(row,index)"></el-checkbox>
                        </td>
                        <td>《{{row.documentName}}》</td>
                        <td width="150">
                            <el-button type="primary" size="small" @click="handleSign(row)">签署验收单</el-button>
                        </td>
                    </tr>
                </table>
                <p class="batch-bottom">
                    <el-checkbox v-model="allCheck" @change="handleAllCheck"></el-checkbox>&nbsp;全选
                    <el-button size="small" @click="handleBatchSign">批量签署</el-button>
                </p>
            </div>
        </el-dialog>

        <!-- 签章 -->
        <SignatureDialog ref="signatureDialog" @close="handleCloseSignature"></SignatureDialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from '@/mixins/account';
import Loading from "@/components/base/Loading";
import SignatureDialog from "@/components/order/dialog/Signature";
import { InterfaceService } from "@/services/api";
import { filterEventByAcct } from '@/utils/orderUtil';

export default {
    mixins:[accountMixin],
    components: {
        Loading,
        SignatureDialog
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            allCheck: false,
            signList: []
        };
    },
    methods: {
        open(data) {
            this.signList = data ? this.$clone(data) : [];
            this.allCheck = false;
            this.init();
            this.dialogVisible = true;
        },
        handleSelectRow(item, index) {
            this.$set(this.signList, index, item);
            this.checkAllSelect();
        },
        // 是否全选
        checkAllSelect() {
            this.allCheck = this.signList.every(item => {
                return item.checked;
            });
        },
        handleAllCheck() {
            this.signList.forEach((item, index) => {
                item.checked = this.allCheck;
                this.$set(this.signList, index, item);
            });
        },
        handleSign(row) {
            this.handleClose(false);

            // 去除当前交割单号
            const list = [];
            this.signList.forEach(item => {
                if (item.deliveryNo != row.deliveryNo) {
                    list.push(item);
                }
            });

            this.$router.push({
                path: "/checkGoods",
                query: {
                    deliveryNo: row.deliveryNo,
                    deliveryList: JSON.stringify(list || [])
                }
            });
        },
        handleBatchSign() {
            let valid = false;
            this.signList.forEach((item, index) => {
                if (item.checked) {
                    valid = true;
                }
            });

            if (valid) {
                this.dialogVisible = false;
                this.handleSignDialog();
            } else {
                this.$message.info("请选择签收单");
            }
        },
        // 签章
        handleSignDialog() {
            const events = [];
            this.signList.forEach(item => {
                if (
                    item.checked &&
                    item.eventType == 2 &&
                    (item.eventStatus == 0 || item.eventStatus == 1)
                ) {
                    events.push(item);
                }
            });
            this.$refs["signatureDialog"].open(events);
        },
        // 签章完成
        handleCloseSignature(bool) {
            this.handleClose(true);
        },
        handleClose(bool) {
            this.dialogVisible = false;
            this.$emit("close", bool);
        },
        init() {
            const events = [];
            let acctIdList = [];
            if (this.userinfo.accountList.length) {
                this.userinfo.accountList.forEach(item=>{
                    acctIdList.push(item.acctId)
                });
            }else {
                acctIdList.push(this.acctId)
            }
            this.signList = filterEventByAcct(this.signList, 2, acctIdList);
            this.signList.forEach(ev => {
                let valid = false;
                if (ev.eventType == 2) {
                    const pros = ev.processList || [];
                    pros.forEach(process => {
                        if (process.processFlg == 0) {
                            valid = true;
                        }
                    });
                }
                if (valid) {
                    ev.checked = false;
                    events.push(ev);
                }
            });
            this.signList = events;
        }
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-button {
    width: 100px;
}

.info {
    color: #888888;
}

.dialog {
    line-height: 25px;
}

.table {
    width: 100%;
    margin-bottom: 10px;

    td {
        padding: 10px;
        border-bottom: 1px solid #ffffff;
        background: #f5f5f5;
    }
}

.batch-bottom {
    padding: 10px;
    margin-bottom: 20px;
}
</style>
