<template>
    <div class="order-info">
        <div class="order-info-title">材料进场人员信息

            <a class="link fr" @click="handleOpenAll">
                <span v-if="!allOpen">全部展开
                    <i class="el-icon-caret-bottom"></i>
                </span>
                <span v-if="allOpen">全部收起
                    <i class="el-icon-caret-top"></i>
                </span>
            </a>
        </div>

        <div class="list-row" style="margin-bottom: 10px;" v-for="(item,index) in deliveryList" :key="index">
            <p class="header">{{item.documentName}}
                <a :href="item.attachUrl" target="_blank">预览</a>
                <a @click="handleDownload(item)">下载</a>
                <a class="fr blue" @click="handleOpenItem(deliveryList,item,index)">
                    <span v-if="!item.open">展开
                        <i class="el-icon-caret-bottom"></i>
                    </span>
                    <span v-if="item.open">收起
                        <i class="el-icon-caret-top"></i>
                    </span>
                </a>
            </p>
            <div v-show="item.open">
                <SignProcessRequire class="sign-process" type="1" :order="order" :processList="item.processList"></SignProcessRequire>
            </div>
        </div>
        <div class="list-row" v-for="(item,index) in receiveList" :key="index">
            <p class="header">{{item.documentName}}
                <a :href="item.attachUrl" target="_blank">预览</a>
                <a @click="handleDownload(item)">下载</a>
                <a class="fr blue" @click="handleOpenItem(receiveList,item,index)">
                    <span v-if="!item.open">展开
                        <i class="el-icon-caret-bottom"></i>
                    </span>
                    <span v-if="item.open">收起
                        <i class="el-icon-caret-top"></i>
                    </span>
                </a>
            </p>
            <div v-show="item.open">
                <SignProcessRequire class="sign-process" type="2" :order="order" :processList="item.processList"></SignProcessRequire>
            </div>
        </div>
    </div>
</template>

<script>
import SignProcessRequire from "@/components/order/SignProcessRequire";
import download from "@/utils/download";

export default {
    components: {
        SignProcessRequire
    },
    data() {
        return {
            allOpen: false,
            deliveryList: [],
            receiveList: []
        };
    },
    props: ["order"],
    watch: {
        order() {
            this.init();
        }
    },
    methods: {
        handleOpenAll() {
            this.allOpen = !this.allOpen;
            this.deliveryList.forEach((item, index) => {
                item.open = this.allOpen;
                this.$set(this.deliveryList, index, item);
            });

            this.receiveList.forEach(item => {
                item.open = this.allOpen;
            });
        },
        handleOpenItem(list, item, index) {
            item.open = !item.open;
            let deliveryOpen = this.deliveryList.every(item=>{
                return item.open
            });
            let receiveOpen = this.receiveList.every(item=>{
                return item.open
            });
            this.allOpen = deliveryOpen && receiveOpen;
            this.$set(list, index, item);
        },
        handleDownload(item) {
            const x = new XMLHttpRequest();
            x.open("GET", item.attachUrl, true);
            x.responseType = "blob";
            x.onload = e => {
                download(
                    x.response,
                    item.documentName.split("?")[0],
                    x.response.type
                );
            };
            x.send();
            this.$message.success("已下载");
        },
        init() {
            if (this.order && this.order.eventList) {
                this.deliveryList = [];
                this.receiveList = [];
                this.order.eventList.forEach(item => {
                    if (item.eventType == 1) {
                        this.deliveryList.push(item);
                    } else if (item.eventType == 2) {
                        this.receiveList.push(item);
                    }
                });
            }
        }
    },
    mounted() {
        this.init();
    }
};
</script>

<style lang="scss" scoped>
.sign-process.content {
    margin: 0;
}

.sign-process.order-info {
    border: none;
}

.order-info {
    margin: 20px 0;
    padding: 20px 0;
    border-top: 1px solid #f5f5f5;
    border-bottom: 1px solid #f5f5f5;
    line-height: 25px;
    font-size: 12px;

    a {
        margin-left: 20px;
        white-space: nowrap;
        color: #0082ff;
    }
}

.order-info-title {
    margin: 5px 0;
    margin-bottom: 20px;
    padding: 0 10px;
    font-size: 14px;
    border-left: 3px solid #000;
    line-height: 12px;
}

.list-row {
    border: 1px solid #ececec;

    .header {
        padding: 15px;
    }
}
</style>
