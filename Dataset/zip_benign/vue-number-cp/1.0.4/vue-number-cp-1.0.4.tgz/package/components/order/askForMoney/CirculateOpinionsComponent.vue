<template>
  <div class="component-container">
    <!-- 流转意见 -->
    <!--  v-if="showCirculationOpinion" -->
    <div :class="['circulation-opinion-container', {openOption: isOpenOptionCirculation}]" v-if="execFlowList.length">
      <i class="option-circulation" v-if="isOpenOptionCirculation" @click="isOpenOptionCirculation = !isOpenOptionCirculation">
        {{isOpenOptionCirculation ? '收起': '展开'}}
      </i>
      <div class="center">
        <div class="head-title">流转意见</div>
        <ul :class="{'isOpenOptionCirculation': !isOpenOptionCirculation,'one':computedExecFlowList && computedExecFlowList.length == 1}">
          <li v-for="(item,index) in computedExecFlowList" :key="index" :class="{'isAgree': computedCirculationState(item).isAgree}">
            <dl>
              <dt>{{item.acctName}}</dt>
              <dd class="color888888">{{item.roleName}}</dd>
            </dl>
            <dl>
              <dt>{{computedCirculationState(item).state}}</dt>
              <!--  -->
              <dd class="color888888">{{item.finishTm}}</dd>
            </dl>
            <dl v-if="item.comment">
              <dt>{{computedCirculationState(item).reason}}:</dt>
              <dd v-html="item.comment.replace(/\n/g, '<br/>')"></dd>
            </dl>
          </li>
        </ul>
        <div class="center-option-circulation" :style="{marginTop: isOpenOptionCirculation?'16px':''}">
          <i class="option-circulation" @click="isOpenOptionCirculation = !isOpenOptionCirculation">
            {{isOpenOptionCirculation? '收起': '展开'}}
          </i>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props: ['execFlowList'],
  data() {
    return {
      isOpenOptionCirculation: false
    }
  },
  computed: {
    computedCirculationState() {
      return (item) => {
        // item.isAgree === "Y" ? "审批意见" : "退回原因"
        let result = {};
        if (item.taskId === 'canceled') {
          result.state = '审批撤回';
          result.reason = '审批意见'
        } else if (item.taskId === 'closed') {
          result.state = '请款关闭';
          result.reason = '关闭原因'
          // 发情申请
        } else if (item.taskId === 'supplier_apply') {
          result.state = '发起申请';
          result.reason = '审批意见'
          // 完成确认
        } else if (item.taskId === 'supplier_confirm') {
          result.state = '完成确认';
          result.reason = '审批意见'
        } else {
          if (item.fwStatus == '1' || item.fwStatus == '2') {
            result.state = item.fwStatus == '1' ? `转发${item.fwRoleName || ''}` : '批注'
            result.reason = item.fwStatus == '1' ? `转发内容` : '批注内容'
          } else {
            result.state = item.isAgree === "Y" ? "审批通过" : "审批退回"
            result.reason = item.isAgree === "Y" ? "审批意见" : "退回原因"
            result.isAgree = item.isAgree === "N"
          }
        }
        return result
      }
    },
    computedExecFlowList() {
      return this.execFlowList.filter((item, idx) => {
        /**
         * 收缩情况下 只显示两条
         */
        if (!this.isOpenOptionCirculation) {
          return idx <= 1
        } else {
          return true
        }
      })
    }
  },
  mounted() {
  },
  methods: {

  }
}
</script>
<style lang="scss" scoped>
.component-container {
  // 流转意见
  .circulation-opinion-container {
    border: 1px solid #fddd74;
    padding: 20px;
    position: relative;
    margin-bottom: 22px;
    &.openOption {
      .option-circulation {
        &::after {
          border-color: #0082ff #0082ff transparent transparent;
          transform: rotate(-45deg);
        }
      }
    }
    .option-circulation {
      position: absolute;
      right: 16px;
      top: 21px;
      color: #0082ff;
      font-size: 12px;
      cursor: pointer;
      &::after {
        content: "";
        border-width: 3px;
        border-style: solid;
        display: inline-block;
        margin-left: 2px;
        border-color: #0082ff #0082ff transparent transparent;
        transform: rotate(135deg) translate(-3px, 1px);
      }
    }
    .center {
      display: flex;
      flex-direction: column;
      cursor: context-menu;
      .head-title {
        color: #444;
        font-size: 14px;
      }
      .center-option-circulation {
        width: 100%;
        height: 22px;
        position: relative;
        border-top: 1px solid #eeeeee;
        i {
          left: 50%;
          top: 17px;
        }
      }
      ul {
        margin-top: 12px;
        display: flex;
        flex-direction: column;
        min-height: 100px;
        &.isOpenOptionCirculation {
          overflow: hidden;
          height: 200px;
          dd {
            height: 40px;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            overflow: hidden;
          }
        }
        &.one {
          height: auto;
        }
        li {
          padding: 20px 40px;
          border-top: 1px solid #eeeeee;
          display: flex;
          position: relative;
          &:last-child {
            padding-bottom: 0;
          }
          &.isAgree {
            dl {
              &:nth-child(2),
              &:nth-child(3) {
                dt {
                  color: #e9171d;
                }
              }
            }
          }
          dl {
            color: #444;
            font-size: 14px;
            width: 20%;
            &:nth-child(2) {
              width: 20%;
            }
            &:nth-child(3) {
              width: 60%;
            }
            .color888888 {
              color: #888;
              font-size: 12px;
            }
            .colore9171d {
              color: #e9171d;
            }
            dt {
              margin-bottom: 6px;
              font-weight: bold;
            }
            dd {
              line-height: 22px;
              word-wrap: break-word;
            }
          }
          .option-circulation {
            left: 50%;
            top: 16px;
          }
        }
      }
    }
  }
}
</style>
