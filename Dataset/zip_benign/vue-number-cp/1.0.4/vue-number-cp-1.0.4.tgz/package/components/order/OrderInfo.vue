<template>
  <div>
    <!-- <PanelTitle title="合同信息" class="order-data-message"></PanelTitle> -->
    <div class="order-info">
      <el-row>
        <el-col :span="12">
          <p>
            <!--<label>合同编号：</label>{{orderInfo.orderNo}}-->
            <label>合同编号：</label>{{divisionContract ? orderInfo.sybOrderNo : orderInfo.clOrderNo}}
          </p>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <p>
            <label>合同名称：</label>
            <span>
              <span v-if="orderInfo.contractName">
                {{ divisionContract ? ('《'+ orderInfo.contractName.replace('采购合同','供应合同') + '》') : ('《'+ orderInfo.contractName + '》')}}
              </span>
              <span v-if="orderInfo.busiType != 'ONEWAY_ORDER'" class='blue-pointer' @click="handleDownloadContract">下载合同</span>
              <DownloadAndView v-if="!divisionContract && supplierFile.attachUrl" downloadName="下载合同终止用印版" viewName="" :attachUrl="supplierFile.attachUrl" :attachName="supplierFile.documentName"></DownloadAndView>
              <DownloadAndView v-if="divisionContract && purchaserFile.attachUrl" downloadName="下载合同终止用印版" viewName="" :attachUrl="purchaserFile.attachUrl" :attachName="purchaserFile.documentName"></DownloadAndView>
            </span>
          </p>
        </el-col>
      </el-row>
      <!--<el-row>-->
      <!--<el-col :span="12">-->
      <!--<p>-->
      <!--<label>供应商名称(代理商)：</label>{{orderInfo.supplierName}}-->
      <!--</p>-->
      <!--</el-col>-->
      <!--<el-col :span="12">-->
      <!--<p>-->
      <!--<label>采购商名称：</label>{{orderInfo.purchaserName}}-->
      <!--</p>-->
      <!--</el-col>-->
      <!--</el-row>-->
      <el-row>
        <el-col :span="12">
          <p>
            <label>合同创建时间：</label>{{orderInfo.orderTime}}
          </p>
        </el-col>
        <el-col :span="12" v-if="orderInfo.busiType != 'ONEWAY_ORDER'">
          <p>
            <label>下单人：</label>{{orderInfo.orderAcctName}}
          </p>
        </el-col>
        <el-col :span="12" v-else>
          <p>
            <label>签约品牌：</label>{{orderInfo.signedBrand}}
          </p>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12" v-if="showTest">
          <p>
            <label>测试调用接口：</label><span class="blue-pointer" @click="testCode">050079</span>
          </p>
        </el-col>
        <el-col :span="12" v-if="orderInfo.busiType != 'ONEWAY_ORDER'">
          <p>
            <label>签约品牌：</label>{{orderInfo.signedBrand}}
          </p>
        </el-col>
      </el-row>
      <el-row v-if="orderInfo.externalSysList && orderInfo.externalSysList.length">
        <el-col :span="12" v-if="orderInfo.externalSysList[0].approveStatusDesc">
          <p>
            <label>OA审批结果：</label><span>{{orderInfo.externalSysList[0].approveStatusDesc}}</span>
          </p>
        </el-col>

      </el-row>
      <el-row v-if="orderInfo.externalSysList && orderInfo.externalSysList[0].externalApprovalComments">
        <el-col :span="24">
          <p>
            <label>OA审批意见：</label>
            <p v-html="orderInfo.externalSysList[0].externalApprovalComments.replace(/\n/g, '<br/>')"></p>
          </p>
        </el-col>
      </el-row>
      <div class="line"></div>
      <!-- 合同价款 -->
      <el-row>
        <el-col :span="24">
          <div class="order-info-title">合同价款</div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <div class="introduction-center" v-if="orderInfo.busiType == 'ONEWAY_ORDER' || !(orderInfo.replenishContractInfo && orderInfo.replenishContractInfo.relContractList && orderInfo.replenishContractInfo.relContractList.length && orderInfo.replenishInContractFee)">
            <ul class="has-rate" v-if="divisionContract">
              <li>
                <span class="grey"> 合同价款(不含税)：</span> <span> {{orderInfo.inContractFee |formatMoney}} 元 </span>
              </li>
              <li>
                <span class="grey"> 税率：</span> <span> {{orderInfo.orderTaxRateRange}} </span>
              </li>
              <li>
                <span class="grey"></span>
              </li>
              <li>
                <span class="grey"> 合同价款(含税)：</span> <span class="bold red"> {{orderInfo.inContractFeeWithTax|formatMoney}} 元 </span>
              </li>
              <li>
                <span class="grey"> 税额：</span> <span> {{orderInfo.inContractTax |formatMoney}} 元 </span>
              </li>
              <li>
                <span class="grey"> 加价率：</span>
                <span class="f16 bold td-lt" v-if="originalAddRate && (originalAddRate != computeAddRate)"> {{originalAddRate}}% </span>
                <span class="f16 red bold"> {{computeAddRate}}% </span>
              </li>
            </ul>
            <ul v-else>
              <li>
                <span class="grey"> 合同价款(不含税)：</span> <span> {{Number(orderInfo.outContractFee)|formatMoney}} 元 </span>
              </li>
              <li>
                <span class="grey"> 税率：</span> <span> {{orderInfo.orderTaxRateRange}} </span>
              </li>
              <li>
                <span class="grey"> 合同价款(含税)：</span> <span class="bold red"> {{Number(orderInfo.outContractFeeWithTax)|formatMoney}} 元 </span>
              </li>
              <li>
                <span class="grey"> 税额：</span> <span> {{Number(orderInfo.outContractTax) |formatMoney}} 元 </span>
              </li>
            </ul>
          </div>
          <div class="introduction-center" v-else>
            <ul v-if="divisionContract">
              <li>
                <span class="grey"> 合同价款(不含税)：</span> <span> {{Number(orderInfo.allInContractFee) | formatMoney}}元(主合同价款{{Number(orderInfo.inContractFee) | formatMoney}}元+补充合同价款{{Number(orderInfo.replenishInContractFee) | formatMoney}}元)</span>
              </li>
              <li>
                <span class="grey"> 税率：</span> <span> {{orderInfo.orderTaxRateRange}} </span>
              </li>
              <!-- <li style="width: 16%">
                <span class="grey"></span>
              </li> -->
              <li>
                <span class="grey"> 合同价款(含税)：</span> <span class="bold red"> {{Number(orderInfo.allInContractFeeWithTax) | formatMoney}}元(主合同价款{{Number(orderInfo.inContractFeeWithTax) | formatMoney}}元+补充合同价款{{Number(orderInfo.replenishInContractFeeWithTax) | formatMoney}}元)</span>
              </li>
              <li>
                <span class="grey"> 税额：</span> <span> {{Number(orderInfo.allInContractTax) | formatMoney}}元(主合同价款{{Number(orderInfo.inContractTax) | formatMoney}}元+补充合同价款{{Number(orderInfo.replenishInContractTax) | formatMoney}}元)</span>
              </li>
              <li>
                <span class="grey"> 加价率：</span>
                <span class="f16 bold td-lt" v-if="originalAddRate && (originalAddRate != computeAddRate)"> {{originalAddRate}}% </span>
                <span class="f16 red bold"> {{computeAddRate}}% </span>
              </li>
            </ul>
            <ul v-else>
              <li>
                <span class="grey"> 合同价款(不含税)：</span> <span> {{Number(orderInfo.allOutContractFee) | formatMoney}}元(主合同价款{{Number(orderInfo.outContractFee) | formatMoney}}元+补充合同价款{{Number(orderInfo.replenishOutContractFee) | formatMoney}}元) </span>
              </li>
              <li>
                <span class="grey"> 税率：</span> <span> {{orderInfo.orderTaxRateRange}} </span>
              </li>
              <li>
                <span class="grey"> 合同价款(含税)：</span> <span class="bold red"> {{Number(orderInfo.allOutContractFeeWithTax) | formatMoney}}元(主合同价款{{Number(orderInfo.outContractFeeWithTax) | formatMoney}}元+补充合同价款{{Number(orderInfo.replenishOutContractFeeWithTax) | formatMoney}}元)</span>
              </li>
              <li>
                <span class="grey"> 税额：</span> <span> {{Number(orderInfo.allOutContractTax) | formatMoney}}元(主合同价款{{Number(orderInfo.outContractTax) | formatMoney}}元+补充合同价款{{Number(orderInfo.replenishOutContractTax) | formatMoney}}元) </span>
              </li>
            </ul>
          </div>
        </el-col>
      </el-row>
      <div class="line" style="margin-top: 10px"></div>
      <!-- 事业部合同数据录入 -->
      <el-row v-if="divisionContract">
        <el-col :span="24">
          <div class="order-info-title">事业部合同数据录入</div>
        </el-col>
      </el-row>
      <el-row v-if="divisionContract">
        <el-col :span="24">
          <el-row>
            <el-col :span="12">
              <label>合同金额建面成本指标：</label>
              <span>{{orderInfo.constructionCostIndex || '暂无'}}</span>
            </el-col>
            <el-col :span="12">
              <label>合同金额实物量成本指标：</label>
              <span>{{orderInfo.amountCostIndex || '暂无'}}</span>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="12">
              <label>目标成本该项核算*90%：</label>
              <span>{{orderInfo.targetCost ? orderInfo.targetCost + ' 元' : '暂无'}}</span>
            </el-col>
            <el-col :span="12">
              <label>集团限额或目标成本限额要求：</label>
              <span>{{orderInfo.groupLimit || '暂无'}}</span>
            </el-col>
          </el-row>
        </el-col>
      </el-row>
      <el-row class="engineeringCalculationSheetRow" v-if="divisionContract && documentInfoList.filter(i=>i.documentType === 'contractOaHtqdgcljss').length">
        <el-col :span="24">
          <span class="f14">合同清单工程计算书</span>
          <div class="enclosure-content">
            <p v-for="(file,ind) in documentInfoList.filter(i=>i.documentType === 'contractOaHtqdgcljss')" :key="ind">
              {{file.documentName}}
              <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="file.attachUrl" :attachName="file.documentName"></DownloadAndView>
            </p>
          </div>
        </el-col>
      </el-row>
      <div class="line" v-if="divisionContract"></div>
      <el-row>
        <el-col :span="24">
          <div class="order-info-title">
            甲方信息
            <span style="margin-left: 6px;font-size: 12px" class="blue-pointer" v-if="(divisionContract || orderInfo.busiType === 'ONEWAY_ORDER') && userinfo.corpIdList.includes(orderInfo.purchaserId) && orderInfo.orderStatus != '02'" @click="handleEditStakeHolder('firstParty')">变更人员</span>
          </div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <label>采购商名称：</label>
          <span v-if="orderInfo.busiType != 'ONEWAY_ORDER'">{{divisionContract ? orderInfo.purchaserName : orderInfo.brokerCorpName}}</span>
          <span v-else>{{orderInfo.purchaserName}}</span>
        </el-col>
        <el-col :span="12">
          <label>采购商授权代表(城市公司项目经理) ：</label>{{stakeHoldersRole('21','showMobile')}}
          <DownloadAndView v-if="computedAttachUrl('authorityPM','url') && stakeHoldersRole('21','showMobile') != '暂无'" :attachUrl="computedAttachUrl('authorityPM','url')" :attachName="computedAttachUrl('authorityPM')"></DownloadAndView>
          <p class="red" v-if="bs == 'B'">如需变更项目经理，请至【公司管理】-【项目列表】查看项目及分期页面修改。</p>
        </el-col>
      </el-row>
      <el-row>
        <!-- <el-col :span="12">
          <label>甲方合同签字人(法人代表或授权委托人) ：</label>
          <span>{{divisionContract ? stakeHoldersRole('24') : stakeHoldersRole('40')}}</span>
        </el-col> -->
        <el-col :span="12">
          <label>甲方合同盖章人(合同章电子用印人) ：</label>
          <span v-if="orderInfo.busiType != 'ONEWAY_ORDER'">{{divisionContract ? stakeHoldersRole('22') : stakeHoldersRole('41')}}</span>
          <span v-else>{{stakeHoldersRole('22')}}</span>
        </el-col>
      </el-row>
      <el-row v-if="divisionContract || orderInfo.busiType === 'ONEWAY_ORDER'">
        <el-col :span="12">
          <label>项目部材料员 ：</label>
          <span>{{stakeHoldersRole('28','showMobile')}}</span>
        </el-col>
        <el-col :span="12">
          <label>收发货印章管理员(收发货公司项目章的电子用印人) ：</label>
          <span>{{stakeHoldersRole('29','showMobile')}}</span>
        </el-col>
      </el-row>
      <div class="line"></div>
      <el-row>
        <el-col :span="24">
          <div class="order-info-title">
            乙方信息

            <span style="margin-left: 6px;font-size: 12px" class="blue-pointer" v-if="!divisionContract &&  userinfo.corpIdList.includes(orderInfo.supplierId) && orderInfo.orderStatus != '02'" @click="handleEditStakeHolder('secondParty')">变更人员</span>
          </div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <label>供应商名称：</label>
          <span>{{divisionContract ? orderInfo.brokerCorpName : orderInfo.supplierName}}</span>
        </el-col>
        <el-col :span="12" v-if="!divisionContract">
          <label>供应商授权代表(代理商)：</label>{{stakeHoldersRole('30','showMobile')}}
          <DownloadAndView :attachUrl="computedAttachUrl('authoritySupplier','url')" :attachName="computedAttachUrl('authoritySupplier')"></DownloadAndView>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12" v-if="!divisionContract && computedAttachUrl('supplierAuthority')">
          <label>厂家授权书：</label>
          <span>{{computedAttachUrl('supplierAuthority')}}</span>
          <DownloadAndView :attachUrl="computedAttachUrl('supplierAuthority','url')" :attachName="computedAttachUrl('supplierAuthority')"></DownloadAndView>
        </el-col>
        <!-- <el-col :span="12">
          <label>乙方合同签字人(法人代表或授权委托人) ：</label>
          <span>{{divisionContract ? stakeHoldersRole('40') : stakeHoldersRole('32')}}</span>
        </el-col> -->
        <el-col :span="12">
          <label>乙方合同盖章人 (合同章电子用印人)：</label>
          <span>{{divisionContract ? stakeHoldersRole('41') : stakeHoldersRole('31')}}</span>
        </el-col>
        <el-col :span="12" v-if="!divisionContract">
          <label>乙方项目盖章人 (收发货公司项目章的电子用印人)：</label>
          <span>{{divisionContract ? stakeHoldersRole('33') : stakeHoldersRole('33')}}</span>
        </el-col>
      </el-row>
      <!--<div class="line"></div>-->
      <!--&lt;!&ndash; 材料进场人员 &ndash;&gt;-->
      <!--<OrderStakeHolder :order="orderInfo" @refresh="handleRefresh"></OrderStakeHolder>-->
      <div class="line"></div>
      <el-row>
        <el-col :span="24">
          <div class="order-info-title">
            要料施工单位

            <span style="margin-left: 6px;font-size: 12px" class="blue-pointer" v-if="(( userinfo.corpIdList.includes(orderInfo.supplierId) && orderInfo.constructionContent == '1') || (userinfo.corpIdList.includes(orderInfo.purchaserId) && orderInfo.constructionContent == '0'))  && orderInfo.orderStatus != '02'" @click="handleEditStakeHolder('material')">变更人员</span>
          </div>
        </el-col>
      </el-row>
      <template v-for="(item,index) in constructionStakeHolders">
        <el-row>
          <el-col :span="12">
            <label>施工单位 ：</label>
            <span>{{(item[0] && item[0].corpName) || "暂无"}}</span>
          </el-col>
          <el-col :span="12">
            <label>施工方授权代表(指定收货人) ：</label>{{stakeHoldersRole('00','showMobile',item)}}
            <DownloadAndView v-if="item[0] && item[0].corpName" :attachUrl="computedAttachUrl('authorityConstructor','url',item[index])" :attachName="computedAttachUrl('authorityConstructor','',item[index])"></DownloadAndView>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <label>项目经理 ：</label>
            <span>{{stakeHoldersRole('01','showMobile',item)}}</span>
          </el-col>
          <el-col :span="12">
            <label>项目盖章人 ：</label>
            <span>{{stakeHoldersRole('02','showMobile',item)}}</span>
          </el-col>
        </el-row>
      </template>
      <div class="line"></div>
      <!-- 付款方式 -->
      <el-row>
        <el-col :span="24">
          <div class="order-info-title">付款方式</div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <div v-if="pmtMethodCp.length" v-html="pmtMethodCp.replace(/\n/mg, `<br class='block'/>`)"></div>
          <div v-else class="undata-notice">暂无</div>
        </el-col>
      </el-row>
      <div class="line"></div>

      <!-- 相关信息 -->
      <template v-if="orderInfo.majorCode === 'C63'">
        <el-row>
          <el-col :span="24">
            <div class="order-info-title">相关信息</div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <p class="f12" style="margin-bottom: 10px;">本合同第一批电梯送货日期为：{{orderInfo.firstDeliveryYear}}年{{orderInfo.firstDeliveryMonth}}月</p>
            <p class="f12">买方未在合同约定的交货日期提取本合同产品的，卖方可免费保管{{orderInfo.elevatorFreeDay ? orderInfo.elevatorFreeDay : ''}}天，自第{{orderInfo.elevatorFreeDay ? +orderInfo.elevatorFreeDay+1 : ''}}天起，买方按如下价格向卖方支付仓储费：电梯每台{{orderInfo.elevatorFreeOverfee | formatMoney}}元/天，该仓储费在合同结算内一并计算。在买方支付仓储费之后，产品质量保证期顺延。</p>
          </el-col>
        </el-row>
        <div class="line"></div>
      </template>

      <!-- 其他条款 -->
      <template v-if="orderInfo.additionInfo">
        <el-row>
          <el-col :span="24">
            <div class="order-info-title">其他条款</div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <!--<div v-html="orderInfo.pmtMethod"></div>-->
            <div v-html="orderInfo.additionInfo && orderInfo.additionInfo.replace(/\n/g, '<br/>')"></div>
          </el-col>
        </el-row>
        <div class="line"></div>
      </template>

      <div class="template-category-contract">
        <templateHtmlComponent :html="tmeplateHtml" :tpCategoryObj="tpCategoryObj"></templateHtmlComponent>
      </div>

      <el-row>
        <el-col :span="24">
          <div class="order-info-title">收付款账户信息</div>
        </el-col>
      </el-row>
      <div class="bold f14" style="margin-bottom: 10px ;">
        <div class="bold">甲方账户信息</div>
      </div>
      <el-row>
        <el-col :span="12">
          <label>开户名称：</label><span>{{firstPartyBankInfo.acctName || '信息待采购商填写'}}</span>
        </el-col>
        <el-col :span="12">
          <label>开户银行：</label><span>{{firstPartyBankInfo.bankName || '信息待采购商填写'}}</span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <label>开户行地址：</label><span>{{firstPartyBankInfo.provCodeDisp + firstPartyBankInfo.cityCodeDisp +firstPartyBankInfo.districtCodeDisp + firstPartyBankInfo.bankAddr || '信息待采购商填写'}}</span>
        </el-col>
        <el-col :span="12">
          <label>开户行行号：</label>
          <span>
            <template v-if="firstPartyBankInfo.bankCode">
              {{firstPartyBankInfo.bankCode | formatCardNum }}
            </template>
            <template v-else>
              信息待采购商填写
            </template>
          </span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <label>银行账号：</label>
          <span>
            <template v-if="firstPartyBankInfo.bankAcctNo">
              {{firstPartyBankInfo.bankAcctNo | formatCardNum }}
            </template>
            <template v-else>
              信息待采购商填写
            </template>
          </span>
        </el-col>
        <el-col :span="12">
          <label>纳税人识别号：</label>
          <span>
            <template v-if="firstPartyBankInfo.taxPayerId">
              {{firstPartyBankInfo.taxPayerId | formatCardNum }}
            </template>
            <template v-else>
              信息待采购商填写
            </template>
          </span>
        </el-col>
      </el-row>
      <el-row style="padding-bottom:30px;border-bottom: 1px dashed #f5f5f5;">
        <el-col :span="12">
          <label>联系人：</label><span>{{firstPartyBankInfo.contact || '信息待采购商填写'}}</span>
        </el-col>
        <el-col :span="12">
          <label>联系方式：</label>
          <span>
            <template v-if="firstPartyBankInfo.mobile">
              {{firstPartyBankInfo.mobile | formatPhoneNumber("3 4 4") }}
            </template>
            <template v-else>
              信息待采购商填写
            </template>
          </span>
        </el-col>
      </el-row>
      <div class="bold f14" style="margin: 20px 0 10px;">
        <div class="bold">乙方账户信息</div>
      </div>
      <el-row>
        <el-col :span="12">
          <label>开户名称：</label>{{secondPartyBankInfo.acctName || '-'}}
        </el-col>
        <el-col :span="12">
          <label>开户银行：</label>{{secondPartyBankInfo.bankName || '-'}}
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <label>开户行地址：</label>{{secondPartyBankInfo.provCodeDisp || '-'}}{{secondPartyBankInfo.cityCodeDisp || '-'}}{{secondPartyBankInfo.districtCodeDisp || '-'}}{{secondPartyBankInfo.bankAddr || '-'}}
        </el-col>
        <el-col :span="12">
          <label>开户行行号：</label>
          <span>
            <template v-if="secondPartyBankInfo.bankCode">
              {{secondPartyBankInfo.bankCode | formatCardNum }}
            </template>
            <template v-else>
              -
            </template>
          </span>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="12">
          <label>银行账号：</label>
          <span>
            <template v-if="secondPartyBankInfo.bankAcctNo">
              {{secondPartyBankInfo.bankAcctNo | formatCardNum }}
            </template>
            <template v-else>
              -
            </template>
          </span>
        </el-col>
        <el-col :span="12">
          <label>纳税人识别号：</label>
          <span>
            <template v-if="secondPartyBankInfo.taxPayerId">
              {{secondPartyBankInfo.taxPayerId | formatCardNum }}
            </template>
            <template v-else>
              -
            </template>
          </span>
        </el-col>
      </el-row>
      <el-row style="padding-bottom:30px;border-bottom: 1px solid #f5f5f5;">
        <el-col :span="12">
          <label>联系人：</label>{{secondPartyBankInfo.contact || '-'}}
        </el-col>
        <el-col :span="12">
          <label>联系方式：</label>
          <span>
            <template v-if="secondPartyBankInfo.mobile">
              {{secondPartyBankInfo.mobile | formatPhoneNumber("3 4 4") }}
            </template>
            <template v-else>
              -
            </template>
          </span>
        </el-col>
      </el-row>
      <!-- ERP更新 -->
      <!-- 附件 -->
      <template v-if="orderInfo.busiType != 'ONEWAY_ORDER'">
        <el-row>
          <el-col :span="24">
            <div class="order-info-title">附件</div>
          </el-col>
        </el-row>
      </template>
      <el-row v-else>
        <el-col :span="24">
          <div class="order-info-title">供应商附件</div>
        </el-col>
      </el-row>
      <el-row v-if="orderInfo.busiType === 'ONEWAY_ORDER'">
        <el-col :span="24">
          <span class="f14">合同附件</span>
          <span v-if="documentInfoList.filter(i=>i.documentType === 'contractFile').length" class="f12 blue hand" style="margin-left: 6px" @click="handleDownloadOtherFile('contractFile')">下载</span>
          <div class="enclosure-content" style="margin-bottom: 30px;" v-if="documentInfoList.filter(i=>i.documentType === 'contractFile').length">
            <p v-for="(file,ind) in documentInfoList.filter(i=>i.documentType === 'contractFile')" :key="ind">
              {{file.documentName}}
              <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="file.attachUrl" :attachName="file.documentName"></DownloadAndView>
            </p>
          </div>
          <div class="enclosure-content" v-else style="margin-bottom: 30px;color: #bbb;">
            暂无合同附件！
          </div>
        </el-col>
        <el-col :span="24">
          <span class="f14">组价附件</span>
          <span v-if="documentInfoList.filter(i=>i.documentType === 'combinationFile').length" class="f12 blue hand" style="margin-left: 6px" @click="handleDownloadOtherFile('combinationFile')">下载</span>
          <div class="enclosure-content" style="margin-bottom: 30px;" v-if="documentInfoList.filter(i=>i.documentType === 'combinationFile').length">
            <p v-for="(file,ind) in documentInfoList.filter(i=>i.documentType === 'combinationFile')" :key="ind">
              {{file.documentName}}
              <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="file.attachUrl" :attachName="file.documentName"></DownloadAndView>
            </p>
          </div>
          <div class="enclosure-content" v-else style="margin-bottom: 30px;color: #bbb;">
            暂无组价附件！
          </div>
        </el-col>
      </el-row>
      <el-row>
        <el-col :span="24">
          <span class="f14">附件5：技术要求或图纸</span>
          <div class="enclosure-content" style="margin-bottom: 30px;" v-if="documentInfoList.filter(i=>i.documentType === 'technicalStandard').length">
            <p v-for="(file,ind) in documentInfoList.filter(i=>i.documentType === 'technicalStandard')" :key="ind">
              {{file.documentName}}
              <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="file.attachUrl" :attachName="file.documentName"></DownloadAndView>
            </p>
          </div>
          <div class="enclosure-content" v-else style="margin-bottom: 30px;color: #bbb;">
            暂无技术要求或图纸！
          </div>
        </el-col>
        <el-col :span="24" v-if="orderInfo.majorCode === 'C63'">
          <span class="f14">产品规格表(卖方提供并确认)</span>
          <div class="enclosure-content" style="margin-bottom: 30px;" v-if="documentInfoList.filter(i=>i.documentType === 'productSpecificationFile').length">
            <p v-for="(file,ind) in documentInfoList.filter(i=>i.documentType === 'productSpecificationFile')" :key="ind">
              {{file.documentName}}
              <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="file.attachUrl" :attachName="file.documentName"></DownloadAndView>
            </p>
          </div>
          <div class="enclosure-content" v-else style="margin-bottom: 30px;color: #bbb;">
            暂无产品规格表！
          </div>
        </el-col>
        <el-col :span="24">
          <span class="f14">其他附件</span>
          <span v-if="documentInfoList.filter(i=>i.documentType === 'otherFile').length" class="f12 blue hand" style="margin-left: 6px" @click="handleDownloadOtherFile('otherFile')">下载</span>
          <div class="enclosure-content" v-if="documentInfoList.filter(i=>i.documentType === 'otherFile').length">
            <p v-for="(file,ind) in documentInfoList.filter(i=>i.documentType === 'otherFile')" :key="ind">
              {{file.documentName}}
              <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="file.attachUrl" :attachName="file.documentName"></DownloadAndView>
            </p>
          </div>
          <div class="enclosure-content" v-else style="margin-bottom: 30px;color: #bbb;">
            暂无其他附件！
          </div>
        </el-col>
      </el-row>

      <template v-if="bs == 'B' && orderInfo.busiType === 'ONEWAY_ORDER'">
        <el-row style="border-top: 1px solid #eee;">
          <el-col :span="24">
            <div class="order-info-title">事业部合同数据录入</div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <el-row>
              <el-col :span="12">
                <label>合同金额建面成本指标：</label>
                <span>{{orderInfo.constructionCostIndex || '暂无'}}</span>
              </el-col>
              <el-col :span="12">
                <label>合同金额实物量成本指标：</label>
                <span>{{orderInfo.amountCostIndex || '暂无'}}</span>
              </el-col>
            </el-row>
            <el-row>
              <el-col :span="12">
                <label>目标成本该项核算*90%：</label>
                <span>{{orderInfo.targetCost ? orderInfo.targetCost + ' 元' : '暂无'}}</span>
              </el-col>
              <el-col :span="12">
                <label>集团限额或目标成本限额要求：</label>
                <span>{{orderInfo.groupLimit || '暂无'}}</span>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
        <el-row style="margin-top: 20px;">
          <el-col :span="24">
            <span class="f14">合同清单工程计算书</span>
            <div class="enclosure-content" style="margin-bottom: 30px;" v-if="documentInfoList.filter(i=>i.documentType === 'contractOaHtqdgcljss').length">
              <p v-for="(file,ind) in documentInfoList.filter(i=>i.documentType === 'contractOaHtqdgcljss')" :key="ind">
                {{file.documentName}}
                <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="file.attachUrl" :attachName="file.documentName"></DownloadAndView>
              </p>
            </div>
            <div class="enclosure-content" v-else style="margin-bottom: 30px;color: #bbb;">
              暂无合同清单工程计算书！
            </div>
          </el-col>
        </el-row>
        <el-row style="border-top: 1px solid #eee;">
          <el-col :span="24">
            <div class="order-info-title">采购商附件</div>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="24">
            <span class="f14">比价清单</span>
            <span v-if="documentInfoList.filter(i=> ['comparePrice'].includes(i.documentType)).length" class="f12 blue hand" style="margin-left: 6px" @click="handleDownloadOtherFile('comparePrice')">下载</span>
            <div class="enclosure-content" style="margin-bottom: 30px;" v-if="documentInfoList.filter(i=> ['comparePrice'].includes(i.documentType)).length">
              <p v-for="(file,ind) in documentInfoList.filter(i=>i.documentType === 'comparePrice')" :key="ind">
                {{file.documentName}}
                <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="file.attachUrl" :attachName="file.documentName"></DownloadAndView>
              </p>
            </div>
            <div class="enclosure-content" v-else style="margin-bottom: 30px;color: #bbb;">
              暂无比价清单！
            </div>
          </el-col>
          <el-col :span="24" v-if="documentInfoList.filter(i=> ['purchaserOtherFile'].includes(i.documentType)).length">
            <span class="f14">其他附件</span>
            <span v-if="documentInfoList.filter(i=> ['purchaserOtherFile'].includes(i.documentType)).length" class="f12 blue hand" style="margin-left: 6px" @click="handleDownloadOtherFile('purchaserOtherFile')">下载</span>
            <div class="enclosure-content" style="margin-bottom: 30px;" v-if="documentInfoList.filter(i=> ['purchaserOtherFile'].includes(i.documentType)).length">
              <p v-for="(file,ind) in documentInfoList.filter(i=>i.documentType === 'purchaserOtherFile')" :key="ind">
                {{file.documentName}}
                <DownloadAndView downloadName="下载" viewName="预览" :attachUrl="file.attachUrl" :attachName="file.documentName"></DownloadAndView>
              </p>
            </div>
            <div class="enclosure-content" v-else style="margin-bottom: 30px;color: #bbb;">
              暂无其他附件！
            </div>
          </el-col>
        </el-row>
      </template>
    </div>
    <Loading :is-loading="isLoading"></Loading>
    <UpdateStakeHolder ref="updateStakeHolder" @close="handleCloseUpdateStakeHolder"></UpdateStakeHolder>
  </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import PanelTitle from "@/components/base/PanelTitle";
import ContractOperate from "@/components/order/ContractOperate";
import SignProcessContract from "@/components/order/SignProcessOrderDetail";
import OrderStakeHolder from "@/components/order/OrderStakeHolder";
import { InterfaceService } from "@/services/api";
import { viewFile } from '@/utils/orderUtil';
import DownloadAndView from '@/components/order/DownloadAndView'
import { NumberUtil } from '@/utils/numberUtil';
import UpdateStakeHolder from "@/components/order/dialog/UpdateStakeHolder";
import Loading from "@/components/base/Loading";
import Vue from 'vue'

export default {
  mixins: [accountMixin],
  components: {
    PanelTitle,
    ContractOperate,
    SignProcessContract,
    OrderStakeHolder,
    DownloadAndView,
    UpdateStakeHolder,
    Loading,
    templateHtmlComponent: {
      props: {
        html: String,
        tpCategoryObj: {
          type: Object,
          default() { return {} }
        }
      },
      render(h) {
        Vue.prototype.$tpCategoryObj = this.tpCategoryObj || {}
        const com = Vue.extend({
          template: `<div>${this.html}</div>`
        })
        return h(com, {})
      },
    }
  },
  props: {
    orderInfo: {
      type: Object,
      default: () => ({}),
      required: false
    },
    bankAcctInfoList: {
      type: Array,
      default: () => ([]),
      required: false
    },
    orderNo: {
      type: String,
      default: "",
      required: false
    },
    tab: {
      type: Number,
      default: "",
      required: false
    },
  },
  data() {
    return {
      roleList: [],
      isLoading: false,
      documentInfoList: [],
      // *合同清单工程计算书
      documentInfoList: [],
      constructionStakeHolders: [],
      closeReason: "",
      showTest: false, // 是否显示 测试调用接口
      specialCategoryIds: [], // 非标合同编号 合集
      tpCategoryObj: {}, // 非标合同字段
      tmeplateHtml: '', // 非标合同模板
    };
  },
  filters: {
    percent(val) {
      return (val * 100) + "%";
    }
  },
  computed: {
    supplierFile() {
      let obj = {}
      if (this.orderInfo.documentInfoList && this.orderInfo.documentInfoList.find(i => { return i.documentType === 'supplierContractTerminate_pdf' })) {
        obj = this.orderInfo.documentInfoList.find(i => { return i.documentType === 'supplierContractTerminate_pdf' })
      }
      return obj
    },
    purchaserFile() {
      let obj = {}
      if (this.orderInfo.documentInfoList && this.orderInfo.documentInfoList.find(i => { return i.documentType === 'purchaserContractTerminate_pdf' })) {
        obj = this.orderInfo.documentInfoList.find(i => { return i.documentType === 'purchaserContractTerminate_pdf' })
      }
      return obj
    },
    pmtMethodCp() {
      const pmtMethod = (this.divisionContract ? this.orderInfo.inPmtMethod : this.orderInfo.pmtMethod) || ''
      return pmtMethod.replace(/</mg, `&lt;`).replace(/>/mg, `&gt;`)
    },
    originalAddRate() {
      const result = NumberUtil.accMul(this.orderInfo && +this.orderInfo.originalAddRate || 0, 100) || 0
      return result
    },
    computeAddRate() {
      return NumberUtil.accMul(this.orderInfo && +this.orderInfo.addRate || 0, 100) || 0
    },
    // 采购商 - 事业部
    divisionContract() {
      return this.bs == 'B' && this.tab == '1'
    },
    firstPartyBankInfo() {
      let info = {};
      this.bankAcctInfoList.forEach(item => {
        if (!this.divisionContract && this.orderInfo.busiType != 'ONEWAY_ORDER') {
          if (item.acctBankType == '3') {
            info = item
          }
        } else {
          if (item.acctBankType == '2') {
            info = item
          }
        }
      })
      return info
    },
    secondPartyBankInfo() {
      let info = {};
      this.bankAcctInfoList.forEach(item => {
        if (!this.divisionContract) {
          if (item.acctBankType == "1") {
            info = item
          }
        } else {
          if (item.acctBankType == '3') {
            info = item
          }
        }
      })
      return info
    },
    stakeHoldersRole() {
      return function (role, showMobile, item) {
        let str = '';
        let list = [];
        if (role[0] == '0') {
          list = item
          console.log(list);
        } else {
          list = this.orderInfo.contractStakeHolders || [];
        }
        list.forEach(item => {
          if (item.role === role) {
            if (item.acctName) {
              str = item.acctName + (showMobile ? "(Tel:" + this.formatPhoneNumber(item.mobile, '3 4 4') + ")" : "");
            }
          }
        });
        return str || '暂无'
      }
    },
    computedOrderUrl() {
      return function (isUrl) {
        let str = '';
        let type = this.divisionContract ? 'contractProfession' : 'contractCommon';
        this.documentInfoList.forEach(item => {
          if (item.documentType === type) {
            if (isUrl) {
              str = item.attachUrl
            } else {
              str = item.documentName
            }
          }
        });
        return str
      }
    },
    computedAttachUrl() {
      return function (type, isUrl, i) {
        let str = '';
        this.documentInfoList.forEach(item => {
          if (item.documentType == 'authorityConstructor' && i) {
          }
          if (!i || (i && i.corpId === item.corpId)) {
            if (item.documentType === type) {
              if (isUrl) {
                str = item.attachUrl
              } else {
                str = item.documentName
              }
            }
          }
        });
        return str
      }
    },
    isHistory() {
      return this.orderInfo && this.orderInfo.enterFrom == 0;
    },
    bs() {
      return (
        this.$store.state.userInfo.bs
      );
    },
    relContractInfo() {
      return this.orderInfo && this.orderInfo.relContractInfo || {}
    }
  },
  watch: {
    orderInfo: {
      deep: true,
      handler(newVal, oldVal) {
        this.init()
      }
    },
  },
  methods: {

    /**
     * 查询配置信息 - 获取非标合同 ID
     */
    getPaymentMethod() {
      return new Promise((resolve, reject) => {
        let params = {
          appName: 'TRANS',
          // groupId: 'GREENLANDHK_PMT_METHOD',
          groupIds: ['GREENLANDHK_PMT_METHOD', 'CREATE_ORDER_SELECTD_CATEGORY'],
          acctId: this.userinfo.acctId
        };
        InterfaceService.getPaymentMethod(params, data => {
          if (data && data.respData && data.respData.respCode === "0000") {

            const configEntityListMap = data.respData.configEntityListMap || {},
              selectList = configEntityListMap.CREATE_ORDER_SELECTD_CATEGORY || []

            this.specialCategoryIds = selectList.find(f => f.code == 'NOT_STANDARD_CATEGORY').value.split(',') || []
            console.log(this.specialCategoryIds, 'specialCategoryIds');

            resolve(data.respData.configEntityListMap);
          } else {
            this.$message.error(data.respData && data.respData.respMsg);
            reject(data.respData && data.respData.respMsg || '')
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })

    },

    // 获取非标合同模板
    getSpecialContractInit(categoryId) {
      categoryId = categoryId || this.orderInfo.majorCode || ''
      let params = {
        corpId: this.orderInfo.supplierId || this.this.userinfo.corpId,
        operType: categoryId == '57' ? '0' : '1',
        categoryId,
      };
      InterfaceService.liftWarehousingInfo(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            const htmlContent = res.htmlContent || ''
            this.tmeplateHtml = htmlContent.replace(/v-model/g, 'disabled v-model')
            console.log(this.tmeplateHtml);
            this.tpCategoryObj = this.orderInfo.sysDoorsWindows || {}
          } else {
            this.$message.error(data.respData && data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData && data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },

    testCode() {
      InterfaceService.testCode(
        { orderNo: this.orderNo },
        data => {
          let res = data.respData;
          if (res.respCode === "0000") {
          } else {
            this.$message.error(data.respMsg);
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    handleDownloadContract() {
      const params = {
        orderNo: this.orderNo,
        bs: this.divisionContract ? 'B' : 'S',
        documentVersion: "",
        fileFrom: "userUpload,systemCreate",
        documentTypeList: []
      };
      InterfaceService.getContractInfo(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          let attachList = [];
          let list = res.documentInfos || [];
          if (res.subDocumentInfos) {
            list = list.concat(res.subDocumentInfos)
          }
          let hasPdf = list.some(item => {
            return item.documentType === 'dt_10_contract_profession' || item.documentType === 'dt_00_contract_profession'
          });
          list.forEach(item => {
            if (hasPdf) {
              // if (item.documentType === 'dt_10_contract_profession' || item.documentType === 'dt_00_contract_profession' || item.documentType === 'otherFile') {
              if (['dt_10_contract_profession',
                'dt_00_contract_profession',
                'dt_00_contract_common',
                'dt_10_contract_common',
                'otherFile',
                'purchaserContractTerminate_pdf',
                'supplierContractTerminate_pdf',
                'internalReplenishAgreement',
                'externalReplenishAgreement',
                "settle_purchaser_File",
                "settle_supplier_File",
              ].indexOf(item.documentType) != -1 || (['contractTerminated'].includes(this.orderInfo.orderStatus) && ['purchaserContractTerminate_pdf', 'supplierContractTerminate_pdf'].indexOf(item.documentType) != -1)) {
                let onOff = false;
                attachList.forEach(_item => {
                  if (item.documentId == _item.documentId) {
                    onOff = true
                  }
                });
                if (!onOff) {
                  attachList.push(item)
                }
              }
            } else {
              let onOff = false;
              attachList.forEach(_item => {
                if (item.documentId == _item.documentId) {
                  onOff = true
                }
              });
              if (!onOff) {
                attachList.push(item)
              }
            }
          });
          this.handleBatchDownload(attachList, hasPdf)
        } else {
          this.$message.error(data.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },
    handleDownloadOtherFile(type) {
      let fileInfoBeans = []
      let attachList = this.documentInfoList.filter(i => i.documentType === type)
      if (attachList.length) {
        attachList.forEach((item, index) => {
          fileInfoBeans.push({
            archivePath: item.documentName,
            fileUrl: item.attachUrl,
          })
        })
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            InterfaceService.packageDownloadAsyn(url, data => {
              const obj = {
                contractFile: '合同附件.zip',
                combinationFile: '组价附件.zip',
                technicalStandard: '合同清单工程计算书.zip',
                otherFile: '供应商其他附件.zip',
                comparePrice: '比价清单.zip',
                purchaserOtherFile: '采购商其他附件.zip',
              }
              const files = [
                { name: this.orderInfo.contractName + obj[type], url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    handleBatchDownload(attachList, hasPdf) {
      let fileInfoBeans = []
      if (attachList.length) {
        if (!hasPdf) {
          attachList.forEach((item, index) => {
            fileInfoBeans.push({
              archivePath: item.documentName,
              fileUrl: item.attachUrl,
            })
          })
        } else {
          attachList.forEach((item, index) => {
            if (item.documentType.indexOf('profession') != -1) {
              fileInfoBeans.push({
                archivePath: '合同专业版/' + item.documentName,
                fileUrl: item.attachUrl,
              })
            }
            if (item.documentType.indexOf('common') != -1) {
              fileInfoBeans.push({
                archivePath: '合同通用版/' + item.documentName,
                fileUrl: item.attachUrl,
              })
            }
            if (item.documentType.indexOf("settle") != -1) {
              fileInfoBeans.push({
                archivePath: "合同结算/" + item.documentName,
                fileUrl: item.attachUrl,
              });
            }
            if (['purchaserContractTerminate_pdf', 'supplierContractTerminate_pdf'].includes(item.documentType)) {
              fileInfoBeans.push({
                archivePath: '合同终止协议/' + item.documentName,
                fileUrl: item.attachUrl,
              })
            }
            if (['internalReplenishAgreement', 'externalReplenishAgreement'].includes(item.documentType)) {
              fileInfoBeans.push({
                archivePath: '合同补充协议/' + item.documentName,
                fileUrl: item.attachUrl,
              })
            }
          })
        }
      }
      let params = {
        fileInfoBeans: fileInfoBeans,
        protocol: "https",
        isAsyn: true
      };
      InterfaceService.packageDownload(
        params,
        data => {
          let res = data.respData || {};
          if (data && data.respData && res.respCode === "0000") {
            let url = res.externalFileUrl
            // const files = [
            //   { name: (this.divisionContract ? (this.orderInfo.contractName.replace('采购合同','供应合同')) : (this.orderInfo.contractName))+ ".zip", url: url }
            // ];
            // this.$download(files).then(() => {
            //   this.$message.success("已下载");
            // });
            InterfaceService.packageDownloadAsyn(url, data => {
              const files = [
                { name: (this.divisionContract ? (this.orderInfo.contractName.replace('采购合同', '供应合同')) : (this.orderInfo.contractName)) + ".zip", url: data }
              ];
              this.$download(files, () => { this.isLoading = true }, () => { this.isLoading = false }).then(() => {
                this.$message.success("已下载");
              });
            }, () => { this.$message.error(data.respData.respMsg) }, () => { this.isLoading = true }, () => { this.isLoading = false })
          } else {
            this.$message.error(data.respData.respMsg)
          }
        }, data => {
          this.$message.error(data.respData.respMsg)
        }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
    },
    handleEditStakeHolder(type) {
      let editRole = '';
      let fileTypeId = '';
      if (type == 'secondParty') {
        editRole = this.divisionContract ? '4' : '3'
        fileTypeId = 'authoritySupplier'
      } else if (type == 'firstParty') {
        editRole = this.divisionContract ? '2' : (this.orderInfo.busiType === 'ONEWAY_ORDER' ? '2' : '4')
        fileTypeId = 'authorityPM'
      } else {
        editRole = '0'
        fileTypeId = 'authorityConstructor'
      }
      let roleList = [];
      if (editRole !== '0') {
        this.orderInfo.contractStakeHolders && this.orderInfo.contractStakeHolders.forEach(item => {
          if (item.role[0] === editRole && item.role[0] !== '0') {
            roleList.push(item)
          }
        });
      } else {
        //施工单位顺序根据constructionStakeHolders里面的数组进行排列，防止位置错乱
        this.constructionStakeHolders.forEach(item => {
          item.forEach(i => {
            roleList.push(i)
          })
        })
      }
      roleList.forEach(item => {
        if (item.role[0] == '2' && !item.corpId) {
          item.corpId = this.orderInfo.purchaserId
        }
        if (item.role == '00') {
          if (this.orderInfo.constructionContent == '1') {
            this.documentInfoList.forEach(_item => {
              if (_item.documentType === fileTypeId) {
                item.uploadFile = {
                  attachName: _item.documentName,
                  viewUrl: _item.attachUrl,
                  businessType: "CONTRACT_FORMATION",
                  fileTypeId: _item.documentType,
                  corpId: _item.corpId || "",
                  attachUrl: _item.documentUrl,
                  corpName: _item.documentUrl,
                }
              }
            });
          } else {
            this.documentInfoList.forEach(_item => {
              if (_item.documentType === fileTypeId && item.corpId === _item.corpId) {
                item.uploadFile = {
                  attachName: _item.documentName,
                  viewUrl: _item.attachUrl,
                  businessType: "CONTRACT_FORMATION",
                  fileTypeId: _item.documentType,
                  corpId: _item.corpId || "",
                  attachUrl: _item.documentUrl,
                }
              }
            });
          }
        } else if (item.role == '30' || item.role == '21') {
          this.documentInfoList.forEach(_item => {
            console.log(_item.documentType, fileTypeId);
            if (_item.documentType === fileTypeId) {
              console.log(item);
              item.uploadFile = {
                attachName: _item.documentName,
                viewUrl: _item.attachUrl,
                businessType: "CONTRACT_FORMATION",
                fileTypeId: _item.documentType,
                corpId: _item.corpId || "",
                attachUrl: _item.documentUrl,
              }
            }
          });
        }
      });
      console.log(roleList, '--- 传入');
      // secondParty 乙方 不传 purchaserId
      this.$refs["updateStakeHolder"].open(roleList, editRole, fileTypeId, this.orderInfo.orderStatus, type == 'secondParty' ? '' : type == 'material' ? this.orderInfo.supplierId : this.orderInfo.purchaserId, this.orderInfo);
    },
    handleCloseUpdateStakeHolder(bool) {
      if (bool) {
        this.$emit("refresh");
      }
    },
    formatPhoneNumber(val, str) {
      let renum = ""; //函数返回对象
      if (val) {
        if (val.length == 11 && val.indexOf("-") == -1) {
          let arr = [3, 4, 4];
          let i, m = 0, n;
          if (str.indexOf('-') > -1) {
            arr = str.split("-");
            for (i = 0; i < arr.length; i++) {
              n = m + Number(arr[i]);
              renum += val.substring(m, n);
              if (i < arr.length - 1) renum += "-";
              m = n;
            }
          } else {
            arr = str.split(" ");
            for (i = 0; i < arr.length; i++) {
              n = m + Number(arr[i]);
              renum += val.substring(m, n);
              if (i < arr.length - 1) renum += " ";
              m = n;
            }
          }
        } else {
          renum = val
        }
      }
      return renum
    },
    handleDownload(item) {
      const suffix = item.attachUrl.slice(item.attachUrl.slice(0, item.attachUrl.indexOf('?')).lastIndexOf('.') + 1, item.attachUrl.indexOf('?')) || '',
        param = [{
          url: item.attachUrl || '',
          name: `${item.attachName || '下载文件.suffix'}`
        }]
      console.log(suffix, 'suffix', param);

      this.$download(param, () => { this.isLoading = true }, () => { this.isLoading = false }).then(res => {
        this.$message.success("已下载");
      })
    },
    handleSeeFile(item) {
      if (item.attachUrl) {
        viewFile(item.attachUrl)
      }

    },
    filterExternalSys(item) {
      let str = "";
      if (item.externalCode) {
        if (item.sysCode == "ERP") {
          let status = item.approveStatus == 1 ? "审批完成" : "审批中";
          str = "(" + item.sysCode + status + ")";
        } else {
          if (item.approveStatus == 1) {
            str = "(审批完成)"
          } else {
            str = "(总部 -" + item.comment + ")";
          }
        }
      }
      return str;
    },
    handleRefresh() {
      this.$emit("refresh");
    },
    handleCloseERP(bool) {
      if (bool) {
        this.$emit("refresh");
      }
    },
    // 检查未签署角色
    checkUnsignRole() {
      this.roleList = [];
      if (this.orderInfo.eventList) {
        // this.orderInfo.orderTime = this.orderInfo.orderTime.substring(0, 10);
        this.orderInfo.eventList.forEach(ev => {
          if (ev.documentType == "00" && ev.processList) {
            ev.processList.forEach(process => {
              if (
                process.processFlg == 0 &&
                this.mxAcctIdList.includes(process.acctId) &&
                this.roleList.indexOf(process.roleName) === -1
              ) {
                this.roleList.push(process.roleName);
              }
            });
          }
        });
      }
    },
    filterERP(list = []) {
      let resList = list;
      // if (this.userTag == 1) {
      const res = list.filter(item => {
        return item.sysCode === "ERP";
      });

      // if (!res.length) {
      //     resList.unshift({
      //         sysCode: "ERP"
      //     });
      // }
      // }

      return resList;
    },
    //查看合同
    loadContract(contractNo) {
      InterfaceService.orderCotractDownload(
        { contractNo: contractNo },
        data => { },
        data => { },
        () => {
          this.isLoading = true;
        },
        () => {
          this.isLoading = false;
        }
      );
    },
    async init() {
      this.checkUnsignRole();
      await this.getPaymentMethod()
      // 如果是非标合同
      if (this.specialCategoryIds.includes(this.orderInfo.majorCode)) {
        this.getSpecialContractInit()
      }
      const executionList = this.orderInfo && this.orderInfo.executionList || [];
      this.showTest = this.$route.query.showTest
      this.closeReason = "";
      this.documentInfoList = this.orderInfo && this.orderInfo.documentInfoList || [];
      console.log(this.documentInfoList);
      this.constructionStakeHolders = [];
      this.orderInfo.contractStakeHolders && this.orderInfo.contractStakeHolders.forEach((item, index) => {
        if (item.role[0] == '0') {
          if (item.role === '00') {
            this.constructionStakeHolders.push([item])
          }
        }
      });
      this.orderInfo.contractStakeHolders && this.orderInfo.contractStakeHolders.forEach((item, index) => {
        for (let i = 0; i < this.constructionStakeHolders.length; i++) {
          let ind = 0;
          let onOff = false
          this.constructionStakeHolders[i].forEach(con => {
            con.ind = i;
            if (con.corpId === item.corpId && item.role !== '00') {
              ind = i;
              onOff = true
            }
          });
          if (onOff) {
            item.ind = ind;
            this.constructionStakeHolders[ind].push(item)
          }
        }
      });
      this.constructionStakeHolders.forEach(item => {
        item = item.sort(this.compare)
      });
      console.log(this.constructionStakeHolders);
      executionList.forEach(ex => {
        if (ex.procDefKey == "CONTRACT_APPROVE_WF" && ex.executionStatus === "closed") {
          this.closeReason = ex.comment || ""
        }
      });
    },
    compare(obj1, obj2) {
      var val1 = obj1.role;
      var val2 = obj2.role;
      if (val1 < val2) {
        return -1;
      } else if (val1 > val2) {
        return 1;
      } else {
        return 0;
      }
    },
  },
  mounted() {
    this.init()
  },
};
</script>

<style lang="scss" scoped>
.order-info {
  margin-bottom: 20px;
  line-height: 25px;
  font-size: 12px;

  /deep/ .el-col {
    /*padding: 0 10px;*/
  }

  p {
    width: 100%;
    display: flex;
    padding-right: 10px;
    word-break: break-word;
    white-space: normal;

    & > span {
      display: inline-block;
      flex: 1 1 0%;
    }
  }

  label {
    white-space: nowrap;
    color: #888888;
  }

  a {
    white-space: nowrap;
    color: #0082ff;
  }

  i {
    font-style: normal;
  }
}
.enclosure-content {
  width: 1190px;
  background: #ffffff;
  border: 1px solid #dddddd;
  padding: 10px;
  line-height: 17px;
  font-size: 12px;
  margin-top: 6px;
  p {
    margin-bottom: 10px;
  }
  p:last-of-type {
    margin-bottom: 0;
  }
}
.order-info-title {
  margin: 5px 0 14px;
  padding: 0 10px;
  font-size: 14px;
  border-left: 3px solid #000;
  line-height: 12px;
}

.nailsupply {
  padding: 0 6px;
  text-align: center;
  display: inline-block;
  max-width: 100%;
  min-height: 14px;
  line-height: 14px;
  border: 1px solid #ffa300;
  border-radius: 7px;
  color: #ffa300;
  margin-right: 6px;
}
/deep/ .el-dropdown-menu__item {
  min-height: 14px;
  line-height: 14px;
  border: 1px solid #ffa300;
  border-radius: 7px;
  color: #ffa300;
  cursor: default;
  margin-top: 5px;
  &:hover {
    color: #ffa300;
    background: #fff;
  }
  &:first-child {
    margin-top: 0;
  }
}
.line {
  margin: 30px 0 0 0;
  height: 1px !important;
  width: 100%;
  background: #f5f5f5;
}

.introduction-center {
  background: #fef4f3;
  padding: 8px;
  margin-bottom: 20px;
  position: relative;
  ul {
    display: flex;
    flex-wrap: wrap;
    li {
      width: 50%;
      &.bold {
        font-weight: bold;
      }
    }
  }
  .has-rate {
    li {
      width: 33%;
    }
  }
  // .has-rate-supplementary {
  //   li {
  //     width: 42%;
  //   }
  // }
}

table {
  width: 100%;
  line-height: 23px;
  font-size: 12px;
  background-color: #fff;
  border: 1px solid #ddd;
  border-bottom: 0;
  margin-bottom: 30px;
  thead {
    tr {
      background: #eee;
      border-bottom: 1px solid #ddd;
      td {
        padding: 2px;
        text-align: center;
        color: #999;
      }
    }
  }
  tbody {
    tr {
      border-bottom: 1px solid #ddd;
      transition: all 0.3s linear;
      &:hover {
        background: #f4f7ff;
      }
      &.tr-last-summary {
        background: #e2e9fd;
        font-weight: bold;
        td {
          padding: 2px 8px;
          &:first-child {
            background: #d5e1fd;
          }
        }
      }
      td {
        text-align: left;
        padding: 8px;
        &.txtRight {
          text-align: right;
        }

        &.txtRight {
          text-align: right;
        }
        .blue {
          margin-left: 14px;
          cursor: pointer;
        }
      }
    }
  }
}
.engineeringCalculationSheetRow {
  margin-top: 22px;
}
/deep/ br {
  display: inline;
  line-height: 11px;
  content: "";
  &.block {
    display: block;
  }
}
.td-lt {
  text-decoration: line-through;
}
.template-category-contract {
  max-height: 300px;
  overflow: auto;
  margin-bottom: 20px;
  margin-top: -20px;
  /deep/ p {
    margin-top: 10px;
    a {
      color: #0082ff;
    }
  }
  /deep/ .el-checkbox {
    width: 100px;
  }
  /deep/ .el-input {
    display: inline-block;
    width: 100px;
    .el-input__inner {
      border: 0;
      border-bottom: 1px solid #888;
      height: 20px;
      line-height: 20px;
      &[disabled] {
        user-select: none;
      }
      &:hover,
      &:focus {
        border: 0;
        border-bottom: 1px solid #888;
      }
    }
  }
}
</style>
