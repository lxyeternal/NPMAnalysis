<template>
  <div class="userList">
    <PanelTitle :title="'用户列表'"></PanelTitle>
    <Breadcrumb :breadcrumbList="breadcrumb" @refresh="handleGoBack()"></Breadcrumb>
    <div class="list-home">
      <div class="list-content">
        <table>
          <thead>
            <tr>
              <td width="6%">序号</td>
              <td width="12%">姓名</td>
              <td width="12%">手机号</td>
              <td width="20%">邮箱</td>
              <td width="40%">角色</td>
              <td width="10%">状态</td>
            </tr>
          </thead>
          <tbody v-for="(item,ind) in approveLst" :key="ind" class="tbody-row">
            <tr>
              <td>
                {{ind+1}}
              </td>
              <td>
                {{item.acctName}}
              </td>
              <td>
                {{item.mobile}}
              </td>
              <td>
                <span>{{item.email}}</span>
              </td>
              <td>
                <i v-for="(a,index) in item.roleIds" :key="index">{{a.roleName+(item.roleIds.length !=index+1?',':'')}}</i>
              </td>
              <td>{{item.acctStatusDisp}}</td>
            </tr>
          </tbody>
        </table>
        <!-- 空列表 -->
        <div class="accout-empty" v-if="!approveLst.length&&!isLoading">
          <img src="@/assets/images/icon-no-product.png">
          <p>暂无数据！</p>
        </div>
        <div class="table-pagination" v-if="approveLst.length">
          <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
          </el-pagination>
        </div>
      </div>
    </div>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import PanelTitle from "@/components/base/PanelTitle";
import { InterfaceService } from "@/services/api";
import Loading from "@/components/base/Loading";
import Breadcrumb from "@/components/base/Breadcrumb";

export default {
  components: {
    Loading,
    PanelTitle,
    Breadcrumb
  },
  data() {
    return {
      isLoading: false,

      total: 0, //分页 总页数
      pageSize: 10, //分页 每页的长度
      pageIndex: 1, //当前页码
      approveLst: [],
      breadcrumb: [],
      corpId: '', // 公司Id
    };
  },
  methods: {
    handleCurrentChange(page) {
      this.pageIndex = page;
      this.getUserList()
      window.scrollTo(0, 0)
    },
    handleGoBack() {
      this.$router.go(-1);
    },

    // 用户列表列表
    getUserList() {
      this.isLoading = true;
      let param = {
        corpId: this.corpId,
        pageIndex: this.pageIndex,
        pageSize: this.pageSize,
      }
      InterfaceService.getQuerySubordinate(param, data => {
        this.isLoading = false;
        if (data && data.respData && data.respData.respCode === "0000") {
          this.approveLst = data.respData.acctList
          this.total = Number(data.respData.totalCount)
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },
    init() {
      this.corpId = this.$route.query.corpId || ''
      const breadcrumb = JSON.parse(this.$getRootScope('breadcrumb') || '[]')
      this.breadcrumb = (breadcrumb && breadcrumb.length) ? breadcrumb : [
        { name: '账户管理中心', path: '/purchaserCenter/accountInfo' },
        { name: this.$route.query.bs == 'S' ? '供应商列表' : '采购商列表', goBack: true },
        { name: '用户列表' },
      ]
      this.getUserList()
    },
  },
  mounted() {
    this.init()
  },
  destroyed() {
    this.$removeRootScope('breadcrumb')
  }
};
</script>

<style lang="scss" scoped>
.userList {
  margin: 0 auto;
  padding-bottom: 82px;

  .list-content {
    table {
      margin-top: 20px;
      table-layout: fixed;
      width: 100%;
      line-height: 23px;
      font-size: 12px;
      td {
        padding: 13px 20px;
        vertical-align: middle;
        word-break: break-all;
        &:first-child {
          padding-left: 10px;
        }
        &:last-child {
          padding-right: 10px;
          text-align: right;
        }
      }

      thead {
        font-size: 14px;
        text-align: left;
        white-space: nowrap;
        border-bottom: 1px solid #eee;
        color: #888;
        background: #f9f9f9;
        tr {
          td {
            &:first-child {
              padding-left: 10px;
            }
            &:last-child {
              padding-right: 10px;
              text-align: right;
            }
          }
        }
      }
      .tbody-row {
        &:hover {
          background: #f0f8ff;
        }
      }
      tbody {
        text-align: left;
        tr {
          border-bottom: 1px solid #eee;
        }
        td {
          span {
            color: #0082ff;
            // cursor: pointer;
            text-decoration: underline;
          }
        }
        .border-none {
          border-bottom: none;
        }
      }
    }
  }
}
.table-pagination {
  margin: 24px 0 0;
  text-align: center;
  color: #888888;
}
.btn {
  width: 80px;
  height: 26px;
  line-height: 26px;
  font-size: 12px;
  padding: 0;
}
.el-button + .el-button {
  margin-left: 18px;
}
.accout-empty {
  padding: 150px;
  text-align: center;
  line-height: 50px;
  color: #909399;
}
/deep/ .panel-title {
  margin-bottom: 0 !important;
}
</style>
