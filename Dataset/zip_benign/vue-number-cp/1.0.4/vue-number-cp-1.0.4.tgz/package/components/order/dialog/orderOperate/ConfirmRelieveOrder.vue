<template>
    <div>
        <!-- 拒绝合同 -->
        <el-dialog class="dialog" :title=title :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="870px" center :close-on-click-modal="false">
            <div style="text-align: center" v-if="contractSignStatus != '1' && user == 'S'">
                是否确认已和采购商达成一致？点击【确认】按钮，视作终止磋商合同。
            </div>
            <div v-if="contractSignStatus != '1' && user == 'broker' && !justShow" style="text-align: center">
                是否确认已和供应商、城市公司达成一致？点击【确认，终止磋商】按钮，视作终止磋商合同。
            </div>
            <template v-if="user == 'broker' && contractSignStatus != '1'">
                <div class="relieve-title" v-if="!originalContract">
                    合同模板
                    <span class="pointer" @click="downloadContract">下载</span>
                </div>
                <div class="relieve-title" v-if="originalContract">
                    原合同
                    <span class="pointer" @click="handleDownload('original')">下载</span>
                </div>
                <p style="text-align: left" v-for="item in attachList" v-if="item.documentType == '00' || item.documentType == '10'">
                    <span>{{item.documentName}}</span>
                    <em class="pointer" @click="handleView(item)">点击预览</em>
                </p>
            </template>
            <div class="tl" v-if="contractSignStatus == '1'">
                <div class="tip" v-if="user == 'S'">
                    确认已和采购商达成一致，同意解除合同。<span class="red">点击【确认】按钮，就视作同意以下所有合同内容</span>。
                </div>
                <div class="tip" v-if="user == 'broker' && !justShow">
                    确认已和供应商、城市公司达成一致，同意解除合同。<span class="red">点击【确认】按钮，就视作同意以下所有合同内容</span>。
                </div>
                <template v-if="user == 'broker'">
                    <div class="relieve-title" v-if="originalContract">
                        原合同
                        <span class="pointer" @click="handleDownload('original')">下载</span>
                    </div>
                    <p v-for="item in attachList" v-if="item.documentType == '00' || item.documentType == '10'">
                        <span>{{item.documentName}}</span>
                        <em class="pointer" @click="handleView(item)">点击预览</em>
                    </p>
                </template>
                <div class="relieve-title" v-if="relieveContract">
                    合同解除协议
                    <span class="pointer" @click="handleDownload('relieve')">下载</span>
                </div>
                <p v-for="item in attachList" v-if="item.documentType == 'supplierContractTerminate'">
                    <span>{{item.documentName}}</span>
                    <em class="pointer" @click="handleView(item)">点击预览</em>
                </p>
                <p v-for="item in attachList" v-if="user == 'broker' && item.documentType == 'purchaserContractTerminate'">
                    <span>{{item.documentName}}</span>
                    <em class="pointer" @click="handleView(item)">点击预览</em>
                </p>
                <div class="relieve-title" v-if="relieveEnclosureContract">
                    解除协议凭证附件
                    <span class="pointer" @click="handleDownload('enclosure')">下载</span>
                </div>
                <p v-for="item in attachList" v-if="item.documentType == 'contractTerminateAttach'">
                    <span>{{item.documentName}}</span>
                    <em class="pointer" @click="handleView(item)">点击预览</em>
                </p>
            </div>
            <template v-if="user == 'S'">
                <div slot="footer" class="dialog-footer">
                    <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm('Y')">确认</el-button>
                    <el-button size="small" style="width: 100px" @click="dialogVisible = false;rejectDialogVisible = true">拒绝</el-button>
                    <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
                </div>
            </template>
            <template v-if="user == 'broker'">
                <div slot="footer" class="dialog-footer" v-if="!justShow">
                    <el-button type="primary" v-if="contractSignStatus == '1'" size="small" style="width: 100px" @click="handleConfirm('Y')">确认</el-button>
                    <el-button type="primary" v-else size="small" style="width: 120px" @click="handleConfirm('Y')">确认，终止磋商</el-button>
                    <el-button size="small" style="width: 100px" @click="handleClose()">取消</el-button>
                </div>
                <div slot="footer" class="dialog-footer"  v-else>
                    <el-button size="small" style="width: 100px" @click="handleClose()">取消</el-button>
                </div>
            </template>

        </el-dialog>
        <el-dialog class="dialog" :title="refuseTitle" :append-to-body="true" :lock-scroll="true" :visible.sync="rejectDialogVisible" width="870px" center :close-on-click-modal="false">
            <div>
                <el-input type="textarea" v-model="reason" rows="8" placeholder="请输入拒绝合同解除的原因..." maxlength="500" @input="handleEntry($event)"></el-input>
                <i class="count">
                    <span :class="{'red':entryNum >= 500}"> {{entryNum}}</span>/ 500
                </i>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" :disabled="!reason" style="width: 100px" @click="handleConfirm('N')">提交</el-button>
                <el-button size="small" style="width: 100px" @click="rejectDialogVisible = false;dialogVisible = true">取消</el-button>
            </div>
        </el-dialog>
        <ContractDownload ref="contractDownload" :downloadOrder="order"></ContractDownload>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import ContractDownload from "@/components/order/dialog/ContractDownload";

export default {
    components: {
        Loading,
        ContractDownload
},
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            rejectDialogVisible: false,
            order: {},
            orderNo: '',
            user: '',
            orderStatus: "",
            title: "",
            refuseTitle: "",
            executionId: "",
            contractSignStatus: "0",
            broker: false,
            showError: false,
            reason:"",
            justShow:"",
            entryNum:0,
            showRelieveData: false,
            originalContract:false,
            relieveContract:false,
            relieveEnclosureContract:false,
            hasBroker:false
        };
    },
    methods: {
        open(data,user,type) {
            this.order = data;
            // 博置查看资料
            this.justShow = type == "look";
            this.orderNo = data.orderNo;
            this.user = user;
            if (user == "broker") {
                this.broker = true;
                // 下载模板时判断是博置参与
                this.order.brokerCorpId = "1";
                this.executionId = data.executionId;
                this.contractSignStatus = data.contractSignStatus;
                this.hasBroker = true
            } else {
                this.executionId = data.executionList.length > 0 && data.executionList[0].executionId || "";
                let list = this.order.executionList || [];
                if (list && list.length > 0) {
                    list.forEach(item=>{
                        if (( item.procDefKey== "CONTRACT_TERMINATE_BROKER_WF" || item.procDefKey == "CONTRACT_TERMINATE_WF")
                            && item.executionStatus == "processing") {
                            this.executionId = item.executionId
                        }
                    })
                };
                if (this.order.brokerCorpId && this.order.brokerCorpId.length > 0) {
                    this.hasBroker = true;
                }
                let showRelieveData = true;
                if (this.order.eventList && this.order.eventList.length > 0) {
                    this.order.eventList.forEach(item=>{
                        if (item.eventStatus != "2") {
                            showRelieveData = false;
                        }
                    })
                }else {
                    showRelieveData = false
                }
                showRelieveData ? this.contractSignStatus = "1" : this.contractSignStatus = "0";
            }
            if (!this.justShow) {
                if (this.contractSignStatus == "1") {
                    this.title = "确认合同解除";
                    this.refuseTitle = "拒绝合同解除";
                } else {
                    this.title = "终止磋商合同";
                    this.refuseTitle = "拒绝终止磋商合同";
                }
            } else {
                this.title = "查看资料"
            }
            this.orderStatus = data.orderStatus;
            this.showError = false;
            this.reason = "";
            this.dialogVisible = true;
            if (this.contractSignStatus == "1" || this.user == 'broker') {
                this.getRelieveData()
            }
        },
        handleEntry(ev){
            this.entryNum = ev.length
        },
        handleConfirm(type) {
            if (!this.reason && type == "N") {
                this.showError = true;
                return;
            }
            this.relieveOrder(type);
        },
        handleView(item){
            let encodeUrl = encodeURIComponent(item.attachUrl);
            const officeOpenTypeList = [".docx",".dotx",".doc",".xlsx",".xlsb",".xlsm",".xls",".pptx",".ppsx",".ppt",".pps",".potx",".ppsm"];
            let officeOpen = false;
            let userAgent = navigator.userAgent; //取得浏览器的userAgent字符串
            let isIE = userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; //判断是否IE<11浏览器
            let isEdge = userAgent.indexOf("Edge") > -1 && !isIE; //判断是否IE的Edge浏览器
            let isIE11 = userAgent.indexOf('Trident') > -1 && userAgent.indexOf("rv:11.0") > -1;
            let IE = false;
            if(isIE || isEdge || isIE11) {
                IE = true
            }else{
                IE = false  //不是ie浏览器
            }
            officeOpenTypeList.some(item=>{
                if (encodeUrl.indexOf(item) != -1) {
                    return officeOpen = true
                }
            });
            if (officeOpen && !IE) {
                window.open("https://view.officeapps.live.com/op/view.aspx?src="+encodeUrl, "_blank");
            }else {
                window.open(item.attachUrl, "_blank");
            }
        },
        handleDownload(type){
            this.attachList.forEach(item=>{
                if (type == "original") {
                    if (item.documentType == "00" || item.documentType == "10" ) {
                        this.dataDownload(item.attachUrl)
                    }
                }else if (type == "relieve") {
                    if (item.documentType == "purchaserContractTerminate" || item.documentType == "supplierContractTerminate" ) {
                        this.dataDownload(item.attachUrl)
                    }
                }else if (item.documentType == "contractTerminateAttach") {
                    this.dataDownload(item.attachUrl)
                }
            })
        },
        handleClose(){
            this.dialogVisible = false;
            this.attachList = [];
            this.originalContract = false;
        },
        dataDownload(url){
            let attachUrl = url;
            if (!attachUrl) return this.$message.error("无下载地址");
            let name = attachUrl.split("?")[0];
            name = name.split("/").pop();
            const files = [{ name: decodeURIComponent(name), url: attachUrl }];
            this.$download(files).then(() => {
                this.$message.success("已下载");
            });
        },
        relieveOrder(type) {
            let params = {}
            if (type == "Y") {
                params = {
                    executionId: this.executionId,
                    isAgree:type,
                    comment:"同意"
                };
            }else if (type == "N") {
                params = {
                    executionId: this.executionId,
                    isAgree:type,
                    comment:this.reason
                };
            }
            console.log(params);
            InterfaceService.ComfirmRelieveOrder(
                params,
                data => {
                    if (data.respCode === "0000") {
                        if (data.respData.respCode === "0000") {
                            this.dialogVisible = false;
                            this.rejectDialogVisible = false;
                            this.$message.success("操作成功");
                            this.$emit("close", true);
                        }else {
                            this.$message.error(data.respData.respMsg);
                        }
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        getRelieveData(){
            let params = {};
            this.attachList = [];
            if (this.hasBroker) {
                params = {
                    orderNo: this.order.orderNo,
                    documentTypeList:["purchaserContractTerminate","supplierContractTerminate","contractTerminateAttach","00","10"]
                };
            } else {
                params = {
                    orderNo: this.order.orderNo,
                    documentTypeList:["supplierContractTerminate","contractTerminateAttach"]
                };
            }
            InterfaceService.getContractInfo(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.attachList = data.respData.documentInfos || [];
                        this.attachList.forEach(item=>{
                            if (item.documentType == "10" || item.documentType == "00") {
                                this.originalContract = true
                            }else if (item.documentType == "purchaserContractTerminate" || item.documentType == "supplierContractTerminate") {
                                this.relieveContract = true
                            }else if (item.documentType == "contractTerminateAttach") {
                                this.relieveEnclosureContract = true
                            }
                        })
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        downloadContract() {
            console.log(this.order);
            this.$refs["contractDownload"].open(this.order, "template");
        }
    }
};
</script>

<style lang="scss" scoped>
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
.error-info {
    color: #f56c6c;
    font-size: 12px;
    line-height: 1;
    padding-top: 4px;
    float: left;
    text-align: left;
    margin-bottom: 20px;
}
.relieve-title{
    text-align: left;
    margin: 20px 0 10px;
    padding: 0 10px;
    font-size: 14px;
    border-left: 3px solid #000;
    line-height: 12px;
}
.pointer{
    margin-left: 5px;
    cursor: pointer;
    color: #0082ff;
}
.count{
    float: right;
    text-align: right;
    margin-bottom: 20px;
    span.red{
        color: #f00;
    }
}
</style>
