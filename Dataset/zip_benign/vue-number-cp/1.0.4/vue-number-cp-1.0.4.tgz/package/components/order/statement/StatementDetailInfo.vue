<template>
    <div>
        <div class="statement-info">
            <el-row>
                <el-col :span="8">
                    <p>
                        <label>合同名称：</label>
                        <span>
                            <span v-if="statementInfo.contractName">《{{statementInfo.contractName}}》</span>
                        </span>
                    </p>
                    <p>
                        <label>合同编号：</label>{{statementInfo.orderNo}}
                    </p>
                </el-col>
                <el-col :span="8">
                    <p>
                        <label>供应商：</label>{{statementInfo.supplierName}}
                    </p>
                    <p>
                        <label>采购商：</label>{{statementInfo.purchaserName}}
                    </p>
                    <p>
                        <label>{{statementText}}号：</label>{{statementInfo.statementNo}}
                    </p>
                </el-col>
                <el-col :span="8">
                    <p>
                        <label>入账周期：</label>{{statementInfo.startDt}} ~ {{statementInfo.endDt}}
                    </p>
                    <p>
                        <label>生成时间：</label>{{statementInfo.creTm|datetime}}
                    </p>
                </el-col>
            </el-row>
        </div>
    </div>
</template>

<script>
export default {
    props: ["type", "statementInfo"],
    computed: {
        statementText() {
            return this.type === "pay" ? "应付对账单" : "应收对账单";
        }
    }
};
</script>

<style lang="scss" scoped>
.statement-info {
    margin-bottom: 20px;
    line-height: 25px;
    font-size: 12px;

    /deep/ .el-col {
        padding: 0 10px;
    }

    p {
        width: 100%;
        display: flex;
        padding-right: 10px;
        word-break: break-word;
        white-space: normal;

        & > span {
            display: inline-block;
            flex: 1 1 0%;
        }
    }

    label {
        white-space: nowrap;
        color: #888888;
    }

    a {
        white-space: nowrap;
        color: #0082ff;
    }

    i {
        font-style: normal;
    }
}
</style>
