<template>
    <span class="contract" v-if="order&&order.orderStatus >= '01'">
        <a class="blue hand" v-if="order&&allowDownloadTemp()" @click="loadContract()">下载模板</a>
        <!--<a class="blue hand" v-if="order&&allowUploadContract()" @click="uploadContract()">上传合同文本</a>-->
        <!--<a class="blue hand" v-if="order&&allowDownloadContract()" @click="downloadContract()">下载合同文本</a>-->
        <!--<a class="blue hand" v-if="order&&allowDownloadContract()" @click="downloadContract()">上传/下载资料</a>-->
        <a class="blue hand" v-if="order" @click="downloadContract()">{{role === "B"?"上传/下载资料":"下载资料"}}</a>

        <!-- 上传合同 -->
        <ContractUpload ref="contractUpload" :order="order" :uploadOrder="order" @close="handleCloseContractUpload"></ContractUpload>
        <!-- 下载合同 -->
        <ContractDownload ref="contractDownload" :downloadOrder="order"></ContractDownload>
        <AttachmentManage ref="attachmentManage" @close="handleCloseContractUpload"></AttachmentManage>
    </span>
</template>

<script>
import accountMixin from '@/mixins/account';
import ContractUpload from "@/components/order/dialog/ContractUpload";
import ContractDownload from "@/components/order/dialog/ContractDownload";
import AttachmentManage from '@/components/order/dialog/AttachmentManage'
export default {
    mixins:[accountMixin],
    components: {
        ContractUpload,
        ContractDownload,
        AttachmentManage,
    },
    props: ["order"],
    computed: {
        isSignature() {
            return this.order && this.order.eventList && this.order.eventList.some(f => f.eventType == '0' && f.eventStatus != '0')
        }
    },
    methods: {
        isMiddleman() {
            return (this.order && this.order.brokerCorpId && this.order.brokerCorpId.length) || false
        },
        // 是否允许下载合同模板
        allowDownloadTemp() {
            // 后台导入合同无法下载模板
            if (this.order && this.order.enterFrom == 0) return;
            const order = this.order;
            let allow = false;
            if (this.role == "B" && (order.contractNo || order.orderNo)) {
                allow = true;
                if (order.eventList && order.orderStatus >= "03") {
                    order.eventList && order.eventList.forEach(item => {
                        if (item.eventType == 0) {
                            allow = false;
                        }
                    });
                }
            }

            // 角色为供应商时, 显示下载模板逻辑 和 下载合同逻辑一致
            if (this.role == "S") {
                order.eventList && order.eventList.forEach(item => {
                    if (item.eventType == 0 && (item.documentType === "00" || item.documentType === "04")) {
                        allow = true;
                    }
                });
            }

            return allow;
        },

        // 是否允许下载合同
        allowDownloadContract() {
            const order = this.order;
            let allow = false;
            if (order.eventList) {
                order.eventList && order.eventList.forEach(item => {
                    if (this.role == "B" && item.eventType == 0) {
                        allow = true;
                    } else if (this.role == "S" &&  item.eventType == 0 && (item.documentType === "00" || item.documentType === "04")) {
                        allow = true;
                    }
                });
            }

            return allow;
        },
        // 是否允许上传合同
        allowUploadContract() {
            const order = this.order;
            let allow = false;
            let contractNum = 0;
            if (this.role == "B" && !this.specialPurChaseRole && order.orderStatus >= "03" && order.orderStatus!=='04' &&order.orderStatus!=='14' && (order.contractNo || order.orderNo)) {
                allow = true;
                // if (order.eventList) {
                //     order.eventList && order.eventList.forEach(item => {
                //         if (item.eventType == 0 && (item.eventStatus == 1 || item.eventStatus == 2)) {
                //             if (
                //                 item.documentType == "00" ||
                //                 item.documentType == "10"
                //             ) {
                //                 contractNum++;
                //             }
                //         }
                //     });
                // }
            }
            // if (contractNum == 2 && this.isMiddleman) {
            //     allow = false;
            // }
            // if (contractNum == 1 && !this.isMiddleman) {
            //     allow = false;
            // }
            return allow;
        },
        //下载合同模板
        loadContract() {
            if (this.groupCompanyCode === 'GREENLANDHK' && this.order.orderStatus < "03") {
                this.$confirm(
                    `<p class="tl">因供应商还未确认合同，您下载的合同模板中乙方信息将缺失。该合同模板为采供双方磋商使用的初稿，为避免总部审批时因合同存在问题被驳回，建议您待供应商确认后，再下载合同模板。</p>`,
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        dangerouslyUseHTMLString: true,
                        type: 'warning',
                        confirmButtonText: "继续下载",
                        cancelButtonText: '取消',
                    }).then(() => {
                    this.$refs["contractDownload"].open(this.order, "template");
                }).catch(() => {
                });
            }else {
                this.$refs["contractDownload"].open(this.order, "template");
            }
        },
        // 上传合同
        uploadContract() {
            this.$refs["contractUpload"].open(this.order);
        },
        handleCloseContractUpload(bool) {
            if (bool) {
                this.$emit("refresh");
            }
        },
        // 下载合同
        downloadContract() {
            // this.$refs["contractDownload"].open(this.order, "download");
            this.$refs["attachmentManage"].open(this.order);
        }
    }
};
</script>

<style lang="scss" scoped>
.contract {
    display: inline-block;
    margin-left: 10px;
}

.hand + .hand {
    margin-left: 10px;
}
</style>
