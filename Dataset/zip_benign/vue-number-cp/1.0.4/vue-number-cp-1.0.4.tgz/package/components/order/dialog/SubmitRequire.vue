<template>
    <div>
        <!-- 提交要货单 -->
        <el-dialog class="dialog" title="提交要货单" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="50%" center :close-on-click-modal="false">
            <div class="tc">确认直接提交要货单，通知供应商备货？</div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确定提交</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            requireNo: '',
        };
    },
    methods: {
        open(data) {
            this.requireNo = data.requireNo;
            this.dialogVisible = true;
        },
        handleConfirm() {
            this.submit();
        },
        submit() {
            const params = {
                requireNo: this.requireNo
            };
            InterfaceService.submitRequireOrder(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.dialogVisible = false;
                        this.$emit("close", true);
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;
}
</style>

