<template>
  <div class="opinions-content" :class="{'reject-content':!isOA}">
    <div class="top">
      <div class="fl f14 bold">{{isOA ? yellowText : redText}}</div>
      <div class="fr blue hand f12" @click="foldFlag = !foldFlag">
        {{foldFlag ? '展开':'收起'}}
        <i v-if="foldFlag" class="el-icon-caret-bottom"></i>
        <i v-else class="el-icon-caret-top"></i>
      </div>
      <div style="clear: both;"></div>
    </div>
    <div v-if="isOA" class="middle-cont">
      <div class="middle" v-for="item in computedList">
        <div style="margin-bottom: 10px;">
          <span>{{item.name}}</span>
          <span v-html="item.comment && item.comment.replace(/\n/g, '<br/>')"></span>
          <div style="clear: both;"></div>
        </div>
        <div class="grey">
          <span>{{item.department}}</span>
          <span>{{item.time}}</span>
          <div style="clear: both;"></div>
        </div>
      </div>
    </div>
    <div v-else class="middle-cont">
      <div class="middle" v-for="item in computedList">
        <div style="margin-bottom: 10px;">
          <span>{{item.name}}</span>
          <span v-if="['15', '16'].includes(item.operType)">{{terminateType == 'relieve' ? '解除合同退回原因：' : '终止合同退回原因：'}}</span>
          <span v-else-if="item.textDescription">{{item.textDescription}}</span>
          <span v-else>退回原因：</span>
          <div style="clear: both;"></div>
        </div>
        <div class="grey">
          <span>{{item.time}}</span>
          <span style="color: #444;" v-html="item.comment && item.comment.replace(/\n/g, '<br/>')"></span>
          <div style="clear: both;"></div>
        </div>
      </div>
    </div>
    <div class="bottom">
      <span class="blue hand f12" @click="foldFlag = !foldFlag">
        {{foldFlag ? '展开':'收起'}}
        <i v-if="foldFlag" class="el-icon-caret-bottom"></i>
        <i v-else class="el-icon-caret-top"></i>
      </span>
    </div>
  </div>
</template>

<script>
export default {
  // props:["isOA","execFlowList"],
  props: {
    isOA: {
      type: Boolean,
      default: false,
    },
    execFlowList: {
      type: Array,
      default: () => []
    },
    yellowText: {
      type: String,
      default: '采购商确认合同流转意见',
    },
    redText: {
      type: String,
      default: '退回意见',
    },
    terminateType: {
      type: String,
      default: '',
    },
  },
  name: "OATransferOpinions",
  data() {
    return {
      foldFlag: true
    };
  },
  computed: {
    computedList() {
      return this.execFlowList.filter((item, idx) => {
        if (this.foldFlag) {
          return idx < 1
        } else {
          return true
        }
      })
    }
  },
  methods: {
    handleFold() {

    }
  }
}
</script>

<style scoped lang="scss">
.opinions-content {
  padding: 10px;
  width: 1190px;
  line-height: 17px;
  background: #fffcf0;
  border: 1px solid #fae2a5;
  margin-bottom: 10px;
  .middle-cont {
    min-height: 78px;
    max-height: 400px;
    overflow-y: auto;
  }
  .top {
    height: 30px;
    border-bottom: 1px solid #eee;
  }
  .middle {
    font-size: 12px;
    padding: 10px 0;
    min-height: 71px;
    border-bottom: 1px solid #eee;
    div {
      span {
        float: left;
        word-break: break-all;
        &:first-child {
          width: 17%;
        }
        &:last-of-type {
          width: 83%;
        }
      }
    }
  }
  .bottom {
    padding-top: 10px;
    height: 27px;
    text-align: center;
  }
}
.reject-content {
  background: #fffcfc;
  border: 1px solid #db7575;
}
</style>