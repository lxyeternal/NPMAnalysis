<template>
  <div>
    <!-- 发起解除结算单 -->
    <el-dialog class="aettle-accounts-dialog relieve-dialog" :title="titleCp" :append-to-body="true" :lock-scroll="true" :visible.sync="aettleAccountsRelieveDialog" width="850px" center :close-on-click-modal="false">
      <div class="f12">
        <p class="txt-center mb10" v-if="settleType == 'start'">确认已和采购商达成一致，同意并解除结算单，点击【确认并发起】按钮，待相关方确认后，合同结算单解除。</p>
        <p class="txt-center mb10" v-if="settleType == 'close'">确认关闭结算单，点击【确认关闭】按钮，合同结算单关闭。</p>
      </div>
      <div class="sign-result txt-center">
        <el-button class="normal-btn" type="primary" @click="handleClickConfirmRelieve('0')" style="width: 120px;">{{confirmBtnNameCP}}</el-button>
        <el-button class="normal-btn" @click="aettleAccountsRelieveDialog = false" style="width: 120px;">关闭</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
import { viewFile } from '@/utils/orderUtil';

const rescindForm = {
  refuseReason: ""
};

export default {
  components: {
    Loading
  },
  data() {
    return {
      isLoading: false,
      aettleAccountsRelieveDialog: false,
      order: {},
      settleType: ''
    };
  },
  computed: {
    titleCp() {
      return this.settleType == 'start' ? '发起解除结算单' : this.settleType == 'close' ? '确认关闭结算单' : ''
    },
    confirmBtnNameCP() {
      return this.settleType == 'start' ? '确认并发起' :  this.settleType == 'close' ? '确认关闭' : ''
    },
    userInfo() {
      return this.$store.state.userInfo || {};
    },
  },
  methods: {
    /**
     * type: start-发起解除, relieve: 供应商解除, close: 供应商关闭
     */
    open(order, type) {
      this.order = order || {}
      this.settleType = type || 'start'
      this.aettleAccountsRelieveDialog = true
    },
    // 文件下载
    handleDownTemp(name, url) {
      this.$download([{
        name: name,
        url: url
      }]).then(result => {
        this.$message.success('已下载')
      }).catch(err => {
        this.$message.error('下载失败')
      })
    },
    // 在线预览
    handleView(url) {
      if (url) {
        viewFile(url)
      }
    },
    handleClickConfirmRelieve(handleType) {
      this.relivevTerminationStatementSingle(handleType)
    },

    /**
     * 解除/终止结算单
     */
    relivevTerminationStatementSingle(handleType) {
      return new Promise(resolve => {
        let params = {
          settleNo: this.order.settleNo || '', //	String	Y	结算单编号
          handleType,  //操作类型（0-解除，1-终止）
        };
        InterfaceService.relivevTerminationStatementSingle(
          params,
          data => {
            let res = data && data.respData || {};
            if (res.respCode === "0000") {
              this.aettleAccountsRelieveDialog = false
              this.$message.success(`${handleType === '0' ? '发起解除' : '终止'}成功!`)
              this.$emit('close')
            } else {
              this.$message.error(res.respMsg)
            }
            resolve(true)
          }, data => {
            this.$message.error(data.respMsg)
          }, () => {
            this.isLoading = true
          }, () => {
            this.isLoading = false
          })

      })
    },
  }
};
</script>

<style lang="scss" scoped>
.info {
  color: #888888;
}
.dialog {
  /deep/ .el-form-item {
    margin-bottom: 0;
  }
  /deep/ .el-form-item__label {
    padding-right: 6px !important;
    line-height: 17px;
  }
  /deep/ .el-dialog__footer {
    padding-top: 0 !important;
  }
}
.error-info {
  color: #f56c6c;
  font-size: 12px;
  line-height: 1;
  padding-top: 4px;
  position: absolute;
  top: 100%;
  left: 0;
}
</style>
