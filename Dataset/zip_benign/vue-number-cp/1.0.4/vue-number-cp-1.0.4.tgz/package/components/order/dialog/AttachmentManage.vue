<template>
    <div v-if="dialogVisible">

        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="870px" center :close-on-click-modal="false" @close="handleRefresh">
            <div class="tl">
                <PanelTitle :tabs="tabs" @select="handleSelectTab" bg-color="#fff"></PanelTitle>
                <div class="attach-wrapper">
                    <!-- 下载 -->
                    <div class="download-wrapper" v-if="attatchType == '00'">
                        <div class="attach-panel-title">
                            <span class="hand attach-panel" :class="{'active':dTab.active}"
                                  v-for="(dTab,index) in downLoadTabs" :key="'d_t_'+index"
                                  @click="hanleTitleType('downLoadType','downLoadTabs',dTab.type,index)">{{dTab.label}}</span>
                        </div>
                        <div class="down-load-content clearfloat">
                            <el-row :gutter="20">
                                <!-- 供应方 -->
                                <el-col :span="downLoadType === '00' ? 24 : 12" v-if="role != 'S' && (isMiddleman || downLoadType == '00' || brokerRole)">
                                    <div class="supplier-attach-box">
                                        <div class="s-title">{{downLoadType == "00" ? "审批资料":"货物供应合同"}}</div>
                                        <div class="s-body">
                                            <ul>
                                                <li v-for="(contract,index) in attachBList" :key="'s_'+index">
                                                    <el-checkbox v-model="contract.checked" @change="handleSelectRow(attachBList,contract,index,'B')"></el-checkbox>
                                                    <span class="blue hand" @click="handleSeeFile(contract)">{{contract.documentName}}</span>
                                                </li>
                                                <li v-if="!(attachBList && attachBList.length)">暂无资料</li>
                                            </ul>
                                        </div>
                                        <div v-if="attachBList && attachBList.length" style="padding-left:10px;margin-top:10px;">
                                            <el-checkbox v-model="allCheckB" @change="handleAllCheck('B')">全选</el-checkbox>
                                        </div>
                                    </div>
                                </el-col>
                                <!-- 采购方 -->
                                <el-col :span="role == 'B' && (isMiddleman || brokerRole) ? 12 : 24" v-if="downLoadType !== '00'">
                                    <div class="buyer-attach-box">
                                        <div class="s-title" v-if="role == 'B'">货物采购合同</div>
                                        <div class="s-body">
                                            <ul>
                                                <li v-for="(contract,index) in attachSList" :key="'b_'+index">
                                                    <el-checkbox v-model="contract.checked" @change="handleSelectRow(attachSList,contract,index,'S')"></el-checkbox>
                                                    <span class="blue hand" @click="handleSeeFile(contract)">{{contract.documentName}}</span>

                                                </li>
                                                <li v-if="!(attachSList && attachSList.length)">暂无资料</li>
                                            </ul>
                                        </div>
                                        <div v-if="attachSList && attachSList.length" style="padding-left:10px;margin-top:10px;">
                                            <el-checkbox v-model="allCheckS" @change="handleAllCheck('S')">全选</el-checkbox>
                                        </div>
                                    </div>
                                </el-col>
                            </el-row>
                        </div>
                    </div>
                    <!-- 上传 -->
                    <div class="upload-wrapper" v-if="attatchType == '10' && role == 'B'">
                        <div class="attach-panel-title">
                            <span class="hand attach-panel" :class="{'active':dTab.active}"
                                  v-for="(dTab,index) in upLoadTabs" :key="'s_t_'+index"
                                  @click="hanleTitleType('upLoadType','upLoadTabs',dTab.type,index)">{{dTab.label}}</span>
                        </div>
                        <div class="up-load-content">
                            <div class="up-load-warrant" v-if="upLoadType == file.type" v-for="(file,index) in upLoadList" :key="index">
                                <div class="up-load-contract-describe" v-html="file.describe"  v-if="compuSignedFlag" @click="downloadTemp($event)">
                                </div>
                                <div class="up-load-contract-form"  v-if="compuSignedFlag">
                                    <el-form label="" label-width="128px">
                                        <el-form-item :label="item.fileTypeName" class="contract-content" :class="{lh40:file.type == '01' || file.type == '01' || file.type == '03'}" v-for="(item,ind) in file.uploadFileList" :key="ind">
                                            <el-col :span="item.attachUrl? 20 : 24">
                                                <ul class="neet-upload-upfile" :class="{isie:isIE11}">
                                                    <li>
                                                        <p class="input-file-p">
                                                            <span v-if="!item.fileName" class="gray">
                                                              请上传: {{item&&item.fileTypeName||''}} ,
                                                              格式为{{item&&item.uploadFileSuffix}}
                                                            </span>
                                                            <span v-else>{{item.fileName || ''}}</span>
                                                        </p>
                                                    </li>
                                                    <li>
                                                        <UpfileComponent
                                                                ref="upfileRef"
                                                                :immediateClearList="true"
                                                                :immediateSubmit="true"
                                                                :showMsg="false"
                                                                :fileSize="52428800"
                                                                :fileSizeMsg="'上传文件不能超过50M, 请重新选择'"
                                                                :btnName="'选择文件'"
                                                                :disabled="erpApproval() || canSignContract()"
                                                                :dirName="selectDirName(item)"
                                                                :type="'1'"
                                                                :fileTypes="item && item.uploadFileSuffix || ''"
                                                                :id="item.displaySort"
                                                                :fileNameList="selectFileNameList(item)"
                                                                @outputList="outputUpfileList($event, item)">
                                                        </UpfileComponent>
                                                    </li>
                                                </ul>
                                            </el-col>
                                            <el-col :span="4" v-if="item.attachUrl">
                                                <el-button size="small" style="width: 100px;height:40px;margin-left:20px;" @click="handleDownTemp(item)">下载模板</el-button>
                                            </el-col>
                                        </el-form-item>
                                    </el-form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="dialog-footer">
                <!-- 下载button -->
                <div v-if="attatchType == '00'">
                    <el-button type="primary" size="small" style="width: 100px" @click.native="handleDownload()">下载</el-button>
                    <!--<el-button size="small" style="width: 100px" @click="handleAllDownload">全部打包下载</el-button>-->
                    <el-button size="small" style="width: 100px" @click="handleRefresh">取消</el-button>
                </div>
                <div v-if="attatchType == '10' && upLoadType == '00'" style="margin-top:10px;text-align: left" >
                    <el-checkbox v-model="checkSignCtract" @click="checkSignCtract = !checkSignCtract">我要上传已签章合同</el-checkbox>
                </div>
                <!-- 上传button -->
                <div v-if="compuSignedFlag">
                    <el-button :disabled="!filterFileList()" type="primary" size="small" style="width: 100px" @click.native="submitUpfile()">上传</el-button>
                    <el-button size="small" style="width: 100px" @click="handleRefresh">取消</el-button>
                </div>
            </div>
            <div class="uploaded-finished-list" v-if="compuSignedFlag">
                <div class="upload-record-title">
                    <span>已上传的文本
                        <!--<em style="padding-left: 20px;" class="hand blue" @click="handleOpenRecord()">查看上传记录</em>-->
                    </span>
                    <span>上传时间</span>
                    <span class="tr" v-show="upLoadType !== '00' && !erpApproval()">操作</span>
                </div>
                <div class="record-wrap">
                    <ul>
                        <li v-for="(item,index) in upLoadFileList" :key="index">
                            <span>
                                <em class="hand blue" @click="handleSeeFile(item)">{{item.documentName}}</em>
                            </span>
                            <span>{{item.fileUploadTime}}</span>
                            <span class="buttons tr" v-show="upLoadType !== '00' && !erpApproval()">
                                <i class="blue hand" @click="handleDel(item)">删除</i>
                            </span>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="close-btn hand" @click="handleRefresh"><i class="el-icon-close"></i></div>
        </el-dialog>
        <!--上传记录-->
        <el-dialog class="confirm-dialog" title="查看上传记录" :append-to-body="true" :lock-scroll="true"
                   :visible.sync="uploadRecordVisible" width="50%" center :close-on-click-modal="false">
            <div class="upload-record-title">
                <span>文件名称</span><span>上传时间</span>
            </div>
            <div class="record-wrap">
                <ul v-if="upLoadRecordList.length !=0">
                    <li v-for="(item,ind) in upLoadRecordList" :key="ind">
                        <span>{{item.documentName}}</span>
                        <span>{{item.createDt}}</span>
                    </li>
                </ul>
                <p v-else>暂无上传记录</p>
            </div>
            <div class="upload-foot">
                <el-button size="small" style="width: 120px" @click="uploadRecordVisible = false">关闭</el-button>
            </div>
        </el-dialog>
        <el-dialog class="confirm-dialog" title="上传错误信息" :append-to-body="true" :lock-scroll="true" :visible.sync="failMessageVisible" width="70%" center :close-on-click-modal="false">
            <el-col :span="failMessageSList.length ? 12 : 24" v-if="failMessageBList.length">
                <div class="supplier-attach-box tl">
                    <div class="s-title tl">供应合同审批文件错误信息</div>
                    <div class="s-body">
                        <ul>
                            <li v-for="(item,ind) in failMessageBList" :key="'b_'+ind">
                                {{ind + 1}}、{{item}}
                            </li>
                        </ul>
                    </div>
                </div>
            </el-col>
            <el-col :span="failMessageBList.length ? 12 : 24" v-if="failMessageSList.length">
                <div class="buyer-attach-box tl">
                    <div class="s-title tl">采购合同审批文件错误信息</div>
                    <div class="s-body">
                        <ul>
                            <li v-for="(item,ind) in failMessageSList" :key="'s_'+ind">
                                {{ind + 1}}、{{item}}
                            </li>
                        </ul>
                    </div>
                </div>
            </el-col>
            <div class="clear"></div>
            <div class="dialog-footer">
                <el-button size="small" style="width: 120px" @click="failMessageVisible = false">知道了</el-button>
            </div>
        </el-dialog>
        <ContractDownload ref="contractDownload" :downloadOrder="order" :back="'返回'"></ContractDownload>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    import Loading from "@/components/base/Loading";
    import PanelTitle from "@/components/base/PanelTitle";
    import { InterfaceService } from "@/services/api";
    import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
    import ContractDownload from "@/components/order/dialog/ContractDownload";
    import accountMixin from "@/mixins/account";
    import { viewFile } from '@/utils/orderUtil';
    const tabs = [
        { label: "上传资料", type: "10", active: true },
        { label: "下载资料", type: "00", active: false }
    ];

    const downLoadTabs = [
        { label: "合同审批版", type: "00", active: true },
        { label: "合同用印版", type: "01", active: false },
        { label: "其他附件", type: "02", active: false },
    ]

    const downLoadTabsS = [
        { label: "货物采购合同", type: "01", active: true },
        { label: "其他附件", type: "02", active: false },
    ]
    const upLoadTabs = [
        { label: "上传合同文本", type: "00", active: true },
        { label: "上传技术标准", type: "01", active: false },
        { label: "上传授权书", type: "02", active: false }
    ];
    const upLoadList = [
        {
            describe:`<p>上传文件大小不要压缩。根据提示上传对应合同文本及审批附件，请<span class="red">严格按要求上传，切勿传错</span>。然后点击“上传”即可。</p>
                  <p>请先<span class="blue hand" @click="handleDownTemp()">下载合同模板</span>，在合同模板的基础上更改合同条款，确认无误后，再上传。上传后的文件，请在【下载】-【合同用印版】中查看。</p>`,
            type : "00",
            uploadFileList:[{
                businessType: "CONTRACT_MANGEMENT",
                fileTypeId: "contractB",
                displaySort: "B",
                bs:"B",
                fileTypeName: "货物供应合同文本",
                uploadFileNameRule: "",
                uploadFileSuffix: "pdf",
                uploadNecessary: "1",
            },{
                businessType: "CONTRACT_MANGEMENT",
                fileTypeId: "contractS",
                displaySort: "S",
                bs:"S",
                fileTypeName: "货物采购合同文本",
                uploadFileNameRule: "",
                uploadFileSuffix: "pdf",
                uploadNecessary: "1",
            }]
        },
        {
            describe:`<p>请上传符合本合同货品属性的技术要求文本，上传文件时，文件大小不要压缩，并将文件命名成：《附件2：技术要求》。然后点击【上传】按钮即可。上传后的文件，请在【下载合同模板】中查看。</p>`,
            type : "01",
            uploadFileList:[]
        },
        {
            describe:` <p>1、<span class="red">请提供线下已用完印的扫描授权书文件</span>。若不清楚授权书的要求和形式，请先下载模板，根据模板的提示填写对应内容，并实物盖章。</p>
                    <p>2、<span class="red">文件名规范</span>：a、城市公司项目经理授权书规范名称：《附件5-1：授权委托书(城市公司项目经理)》；</p>
                    <p><span style="visibility: hidden;">2、文件名规范：</span>b、供应方授权书规范名称：《附件5-2：授权委托书(供应方）》；施工单位的授权书规范名称：《附件5-3：授权委托书(施工单位）》；</p>
                    <p><span style="visibility: hidden;">2、文件名规范：b、</span>监理单位的授权书规范名称：《附件5-4：授权委托书(监理单位）》。</p>
                    <p>3、确认文件信息无误，点击【上传】按钮即可，上传文件大小不要压缩。上传后的文件，请在【下载合同模板】中查看。</p>`,
            type : "02",
            uploadFileList:[]
        },
        {
            describe:` <p>1、<span class="blue hand" @click="handleDownTemp()">待审批全套合同文件</span>指的是在平台提供的<span class="blue hand" @click="handleDownTemp()">标准合同模板</span>基础上进行修改并确认无误，<em class="red">可以提交ERP及材料公司进行审批</em>的全套合同文件，审批通过之后，将直接在该版本上进行用印。</p>
                    <p>2、上传待审批全套合同文件时，<em class="red">请勿更改</em>合同模板预设的文件名称和文本格式，并将文件打成压缩包，格式为<em class="red">.zip</em>或<em class="red">.rar</em></p>
                    <p>3、上传成功之后，系统会自动为您生成"<em class="red">待签合同与标准合同偏离清单</em>"文件，您可以直接确认差异内容，如有疑问，请联系平台客服：400-009-0506(工作日9:00-18:00)</p>
                    <p>4、当合同在ERP系统中发起审批之后，为确保两个系统中文件内容的一致性，平台将关闭"待审批合同文件"的上传路径，合同文件内容以ERP系统中的审批附件为准。</p>`,
            type : "03",
            uploadFileList:[]
        },
    ];
    const form = {
        documentType: "10",
        isSignedS:"0",
        isSignedB:"0",
    };
    export default {
        mixins: [accountMixin],
        components: {
            Loading,
            PanelTitle,
            UpfileComponent,
            ContractDownload,
        },
        data() {
            return {
                isLoading: false,
                dialogVisible: false,
                tabs:JSON.parse(JSON.stringify(tabs)),
                downLoadTabs:JSON.parse(JSON.stringify(downLoadTabs)),
                upLoadTabs:JSON.parse(JSON.stringify(upLoadTabs)),
                attatchType:"10",//弹层标题
                downLoadType:"00",//合同审批版:00、合同用印版:01
                upLoadType:"02",//上传合同文本:00、上传技术标准:01,上传授权书:02
                checkSignCtract:false,
                uploadRecordVisible:false,
                failMessageVisible:false,
                allCheckB:false,
                allCheckS:false,
                whetherClose:false,
                form: Object.assign({}, form),
                fileList: [],
                order: {},
                upLoadList: JSON.parse(JSON.stringify(upLoadList)),
                upLoadFileList: [],
                attachBList: [],
                attachSList: [],
                upLoadRecordList: [],
                attachList: [],
                arrContactName:[],
                failMessageBList:[],
                failMessageSList:[],
            };
        },

        computed: {
            compuSignedFlag(){
                return this.attatchType == '10' && ((this.upLoadType == '00' && (this.checkSignCtract || this.whetherClose)) || this.upLoadType != '00')
            },
            isMiddleman() {
                return (this.order && this.order.brokerCorpId && this.order.brokerCorpId.length) || false
            },
            isIE11() {
                let userAgent = navigator.userAgent;
                return userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1; // ie11<11
            },

        },
        methods: {
            open(order){
                this.order = order;
                this.whetherClose = this.order.whetherClose === "2";
                this.upLoadList[0].uploadFileList.forEach(item=>{
                    if (item.upfileResultList) {
                        item.upfileResultList = [];
                        item.fileName = ""
                    }
                });
                if (!this.isMiddleman){
                    this.upLoadList = JSON.parse(JSON.stringify(upLoadList))
                    this.upLoadList[0].uploadFileList.shift();
                }
                if (this.role == "B") {
                    if (!this.brokerRole) {
                        this.attatchType = "10";
                        this.tabs = JSON.parse(JSON.stringify(tabs));
                        this.getOrderConfiguration();
                        this.hanleTitleType('upLoadType','upLoadTabs',"02",2)
                    }else {
                        this.downLoadTabs = JSON.parse(JSON.stringify(downLoadTabs));
                        this.downLoadTabs.pop()
                        this.tabs = [
                            { label: "下载资料", type: "00", active: true}
                        ];
                        this.attatchType = "00";
                        this.hanleTitleType('downLoadType','downLoadTabs',"00",0)
                    }
                }else {
                    this.downLoadTabs = JSON.parse(JSON.stringify(downLoadTabsS))
                    this.tabs = [
                        { label: "下载资料", type: "00", active: true}
                    ];
                    this.attatchType = "00";
                    this.hanleTitleType('downLoadType','downLoadTabs',"01",0)
                }
                this.dialogVisible = true;
            },
            handleSeeFile(item) {
                if (item.attachUrl) {
                  viewFile(item.attachUrl)
                }
            },
            filterFileList(){
                let bool = false;
                this.upLoadList.forEach(item=>{
                    item.uploadFileList.forEach(_item=>{
                        if (_item.upfileResultList && _item.upfileResultList.length > 0) {
                            bool = true
                        }
                    })
                });
                return bool
            },
            // 判断erp审批是否通过，通过则disabled待审核附件上传按钮
            erpApproval(){
                let bool = false;
                this.order.externalSysList && this.order.externalSysList.forEach(item=>{
                    if ((this.upLoadType == '03' && item.sysCode === 'ERP' && item.approveStatus === "1" && item.codeStatus === "1")
                    ) {
                        bool = true
                    }
                });
                return bool
            },
            // 供应商确认合同后才可以上传合同
            canSignContract(){
                let bool = false;
                if (this.order.orderStatus < '03' && this.upLoadType == "00") {
                    bool = true;
                }
                return bool
            },
            //弹层切换：上传、下载
            handleSelectTab(tab) {
                this.attatchType = tab.type;
                if (tab.type == "00") {
                    this.hanleTitleType('downLoadType','downLoadTabs',"00",0)
                }else {
                    this.hanleTitleType('upLoadType','upLoadTabs',"02",2)
                }
                this.getAttacheInit(tab.type);
            },
            downloadTemp(e){
                if (e.target.className == "blue hand") {
                    this.$refs["contractDownload"].open(this.order, "template");
                }
            },
            //下载切换： 合同审批版、合同用印版
            //上传切换： 上传合同文本、上传技术标准、上传授权书
            hanleTitleType(titleType,tabListName,targetType,index){
                this[titleType] = targetType
                this[tabListName].forEach((item, i) => {
                    item.active = index == i;
                    this.$set(this[tabListName], i, item);
                });
                this.attachBList = []
                this.attachSList = []
                let documentTypeList = [];
                if (titleType == "upLoadType") {
                    if (targetType == "00") {
                        documentTypeList = ["00","10"]
                    }else if (targetType == "01") {
                        documentTypeList = ["technicalStandard"]
                    }else if (targetType == "02") {
                        documentTypeList = ["authorityPM","authoritySupplier","authorityConstructor","authoritySupervisor"]
                    }else if (targetType == "03") {
                        documentTypeList = ["condenseFile","differenceReport"]
                    }
                    this.getContractInfo(documentTypeList,"upload");
                }else {
                    if (targetType == "02") {
                        if (this.role === "S") {
                            documentTypeList = ["06"]
                        }else {
                            documentTypeList = ["06","16"]
                        }
                    }
                    this.getContractInfo(documentTypeList);
                }
            },
            handleAllCheck(type) {
                if (type == "B") {
                    this.attachBList.forEach((item,index)=>{
                        item.checked = this.allCheckB;
                        this.$set(this.attachBList, index, item);
                    })
                }else if (type == "S") {
                    this.attachSList.forEach((item,index)=>{
                        item.checked = this.allCheckS;
                        this.$set(this.attachSList, index, item);
                    })
                }
            },
            handleSelectRow(list,row, index,type) {
                // this.$set(list, index, row);
                this.checkAllSelect(list,type);
            },
            // 是否全选
            checkAllSelect(list,type) {
                if (type == "B") {
                    let num = 0;
                    this.allCheckB = list.every(item => {
                        num++;
                        return item.checked;
                    });
                    this.allCheckB = num > 0 && this.allCheckB;
                }else {
                    let num = 0;
                    this.allCheckS = list.every(item => {
                        num++;
                        return item.checked;
                    });
                    this.allCheckS = num > 0 && this.allCheckS;
                }

            },
            selectDirName(item){
                let dirName = ""
                let now = new Date().getTime();
                if (item.bs == 'BS') {
                    dirName = `${this.order.orderNo}/publicFiles/${now}/`
                }else if (item.bs == "B") {
                    dirName = `${this.order.orderNo}/internalFiles/${now}/`
                }else if (item.bs == "S") {
                    dirName = `${this.order.orderNo}/externalFiles/${now}/`
                }
                return dirName
            },
            handleOpenRecord(){
                let params = {
                    orderNo:this.order.orderNo,
                };

                InterfaceService.uploadContractRecord(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleDownTemp(item){
                if (item && item.fileTypeId !== "contractB" && item.fileTypeId !== "contractS") {
                    this.$download([{
                        name: item.templateFileName || '',
                        url: item.attachUrl || ''
                    }]).then(result => {
                        this.$message.success('已下载')
                    }).catch(err => {
                        this.$message.error('下载失败')
                    })
                }else {
                    this.$refs["contractDownload"].open(this.order, "template");
                }
            },
            handleDownload(){
                let downloadList = []
                this.attachBList.forEach(item=>{
                    if (item.checked) {
                        downloadList.push(item)
                    }
                });
                this.attachSList.forEach(item=>{
                    let onOff = false;
                    downloadList.forEach(_item=>{
                        if (_item.documentId == item.documentId) {
                            onOff = true
                        }
                    });
                    if (!onOff && item.checked) {
                        downloadList.push(item)
                    }
                });
                const attachs = [];
                downloadList.forEach((item) => {
                    attachs.push(item);
                    item.url = item.attachUrl;
                    item.name = item.documentName.split("?")[0]
                });
                if (attachs.length) {
                    this.$download(attachs).then(res=>{
                        this.$message.success("已下载");
                    })
                } else {
                    this.$message.info("请选择需要下载的文件");
                }
            },
            handleRefresh(){
                this.downLoadType = "00"
                this.dialogVisible = false
                this.$emit("close", true);
            },
            handleDel(item){
                this.$confirm(
                    "删除后将无法恢复文件，确认删除吗?",
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认",
                        cancelButtonText: '取消',
                    }).then(() => {
                    this.confirmDel(item);
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            selectFileNameList(item){
                let arr = [];
                this.arrContactName.forEach(i=>{
                    if (i.type == item.fileTypeId || i.type == item.fileTypeId + item.bs  ) {
                        arr.push(i)
                    }
                });
                return arr
            },
            confirmDel(item){
                let documentIdList = [];
                documentIdList.push(item.documentId)
                let params = {
                    orderNo: this.order.orderNo,
                    documentIdList: documentIdList
                };
                InterfaceService.deleteContractFiles(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("删除成功！")
                            this.upLoadTabs.forEach((item,ind)=>{
                                if(item.active == true){
                                    this.hanleTitleType('upLoadType','upLoadTabs',item.type,ind)
                                }
                            })
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {
                    },
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            // 上传附件
            submitUpfile() {
                let uploadFiles = []
                this.upLoadList.forEach(item=>{
                    item.uploadFileList.forEach(file=>{
                        if (file.upfileResultList && file.upfileResultList.length > 0) {
                            uploadFiles.push({
                                businessType:"CONTRACT_MANAGEMENT",
                                bs:file.bs,
                                fileTypeId:file.fileTypeId,
                                attachName:file.upfileResultList[0].name,
                                attachUrl:file.upfileResultList[0].url,
                            });
                            uploadFiles.forEach(f=>{
                                if (f.fileTypeId == "contractB" || f.fileTypeId == "contractS") {
                                    f.isSigned = this.checkSignCtract ? "1" : "0"
                                }
                            })
                        }
                    })
                });
                this.doSubmit(uploadFiles)
            },
            doSubmit(uploadFiles){
                let params = {
                    orderNo : this.order.orderNo,
                    uploadFiles : uploadFiles
                };
                InterfaceService.uploadContractFiles(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("上传成功！");
                            this.upLoadList.forEach(item=>{
                                item.uploadFileList.forEach(item=>{
                                    if (item.fileName) {
                                        item.fileName = ""
                                    }
                                    if (item.upfileResultList) {
                                        item.upfileResultList = []
                                    }
                                })
                            });
                            this.upLoadTabs.forEach((item,ind)=>{
                                if(item.active == true){
                                    this.hanleTitleType('upLoadType','upLoadTabs',item.type,ind)
                                }
                            })
                        } else if (data.respData.respCode === "TRANS0352") {
                            this.failMessageBList = data.respData.bfailMessageList || [];
                            this.failMessageSList = data.respData.sfailMessageList || [];
                            if (this.failMessageBList.length > 0 || this.failMessageSList.length > 0) {
                                this.failMessageVisible = true;
                            }
                        }else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {
                    },
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            // activeList(list){
            //     let arr = [];
            //     list.forEach(item=>{
            //         if (this.downLoadType == "00" && item.documentVersion == "approve") {
            //             arr.push(item)
            //         } else if (this.downLoadType == "01" && item.documentVersion == "sign") {
            //             arr.push(item)
            //         }
            //     });
            //
            //     return arr
            // },
            outputUpfileList(ev, item) {
                ev = [...ev] || [];
                const name = ev[0] && ev[0].name && ev[0].name.slice(0, ev[0].name.lastIndexOf('.')) || '',
                    uploadFileNameRule = item && item.uploadFileNameRule || '',
                    getFileItem = item || {}

                // if (ev[0] && ev[0].name !== (item && item.uploadFileNameRule) && item.uploadFileNameRule) {
                //     this.$message.error(`请上传文件名为 ${item && item.fileTypeName || ''} 的文件`)
                //     return
                // }
                // 文件名校验规则 包含/全等/不验证
                if (getFileItem.uploadFileNameRuleType === 'like')  {
                    if (!name.includes(uploadFileNameRule)) {
                        this.$message.error(`请上传文件名包含 ${getFileItem.uploadFileNameRule || ''} 的文件`)
                        return
                    }
                } else if (getFileItem.uploadFileNameRuleType === 'same') {
                    if (name !== uploadFileNameRule) {
                        this.$message.error(`请上传文件名为 ${getFileItem.uploadFileNameRule || ''} 的文件`)
                        return
                    }
                }

                this.$set(item, 'upfileResultList', ev);
                this.$set(item, 'fileName', ev[0] && ev[0].name)
            },
            //初始化附件配置列表
            getAttacheInit(type){

            },
            getOrderConfiguration() {
                return new Promise((resolve, reject) => {
                    this.upLoadTabs = JSON.parse(JSON.stringify(upLoadTabs));
                    const params = {
                        businessType: 'CONTRACT_MANGEMENT'
                    };
                    InterfaceService.getOrderConfiguration(params, data => {
                        let res = data.respData;
                        if (res.respCode === "0000") {
                            let fileList = res.uploadFileList || [];
                            // this.fileList = res.uploadFileList || [];
                            this.upLoadList.forEach(file=>{
                                if (file.type !== "00") {
                                    file.uploadFileList = []
                                }
                            });
                            let onOff = false;
                            fileList.forEach(item=>{
                                this.upLoadList.forEach(file=>{
                                    if (file.type === "02") {
                                        if (item.displaySort === "10" ||
                                            item.displaySort === "20" ||
                                            item.displaySort === "30" ||
                                            item.displaySort === "40") {
                                            file.uploadFileList.push(item)
                                        }
                                    }else if (file.type == "01") {
                                        if (item.displaySort === "50") {
                                            file.uploadFileList.push(item)
                                        }
                                    }else if (file.type == "03") {
                                        if (item.displaySort === "60" || item.displaySort === "70") {
                                            onOff = true;
                                            if (this.isMiddleman) {
                                                file.uploadFileList.push(item);
                                            }else {
                                                if (item.bs == "S") {
                                                    file.uploadFileList.push(item);
                                                }
                                            }
                                        }
                                    }
                                })
                            });
                            onOff && this.upLoadTabs.push({ label: "上传待审批附件", type: "03", active: false });
                            // this.fileList.map((m, idx) => m.idx = idx)
                            resolve(this.upLoadList)
                            this.formatContractName();
                        } else {
                            reject([])
                            this.$message.error(data.respMsg);
                        }
                    }, data => {
                    }, () => {
                        this.isLoading = true;
                    }, () => {
                        this.isLoading = false;
                    })
                })
            },
            formatContractName(){
                this.arrContactName = []
                let contractName = this.order.contractName;
                // let type = this.form.documentType
                let onOff = true;
                let SupplyAndInstallation = true;
                if( contractName && contractName.match('专业分包') ){
                    onOff = false
                }
                if( contractName && contractName.match('供应及安装') ){
                    SupplyAndInstallation = false
                }
                this.upLoadList.forEach(_item=>{
                    _item.uploadFileList.forEach((item)=> {
                        let str = this.order.contractName;
                        let type = item.fileTypeId;
                        if (type == "contractB" || type == "contractS"){
                            if (!onOff) {
                                this.arrContactName.push({
                                    str:str,
                                    type
                                });
                            } else {
                                if (type == 'contractB') {
                                    if (!SupplyAndInstallation) {
                                        let SupplyAndInstallationStr = str.replace('供应及安装合同', '供应及安装供应合同')
                                        this.arrContactName.push({
                                            str:SupplyAndInstallationStr,
                                            type
                                        })
                                    } else {
                                        str = str && str.replace('供应合同', '货物供应合同')
                                        this.arrContactName.push({
                                            str:str,
                                            type
                                        })
                                    }
                                } else {
                                    if (!SupplyAndInstallation) {
                                        let SupplyAndInstallationStr = str && str.replace('供应及安装合同', '供应及安装采购合同')
                                        this.arrContactName.push({
                                            str:SupplyAndInstallationStr,
                                            type
                                        })
                                    } else {
                                        str = str && str.replace('供应合同', '货物采购合同')
                                        this.arrContactName.push({
                                            str:str,
                                            type
                                        })
                                    }
                                }
                            }
                        }
                        if (type == "condenseFile") {
                            let bs = item.bs;
                            if (!onOff) {
                                if (bs === "B") {
                                    // this.arrContactName.push({
                                    //     str:str + "（上海博置与项目公司）",
                                    //     type:type+bs
                                    // });
                                    item.uploadFileNameRule = str + "（上海博置与项目公司）"
                                }else {
                                    // this.arrContactName.push({
                                    //     str:str + "（上海博置与供应商）",
                                    //     type:type+bs
                                    // });
                                    item.uploadFileNameRule = str + "（上海博置与供应商）"
                                }
                            } else {
                                if (bs == 'B') {
                                    if (!SupplyAndInstallation) {
                                        let SupplyAndInstallationStr = str.replace('供应及安装合同', '供应及安装货物供应合同')
                                        // this.arrContactName.push({
                                        //     str:SupplyAndInstallationStr,
                                        //     type:type+bs
                                        // });
                                        item.uploadFileNameRule = SupplyAndInstallationStr
                                    } else {
                                        str = str && str.replace('供应合同', '货物供应合同')
                                        // this.arrContactName.push({
                                        //     str:str,
                                        //     type:type+bs
                                        // });
                                        item.uploadFileNameRule = str
                                    }
                                } else {
                                    if (!SupplyAndInstallation) {
                                        let SupplyAndInstallationStr = str && str.replace('供应及安装合同', '供应及安装货物采购合同')
                                        // this.arrContactName.push({
                                        //     str:SupplyAndInstallationStr,
                                        //     type:type+bs
                                        // })
                                        item.uploadFileNameRule = SupplyAndInstallationStr;
                                    } else {
                                        str = str && str.replace('供应合同', '货物采购合同');
                                        // this.arrContactName.push({
                                        //     str:str,
                                        //     type:type+bs
                                        // })
                                        item.uploadFileNameRule = str;
                                    }
                                }
                            }
                        }
                    })
                });
                // 判断名称校验后加不加书名号,zip包不加《》
                this.arrContactName.forEach(item=>{
                    item.hasMarks = item.type == "contractB" || item.type == "contractB"
                })
            },
            getContractInfo(documentTypeList,type) {
                this.upLoadFileList = [];
                let attachBList = [];
                let attachSList = [];
                let documentVersion = "";
                this.tabs.forEach(item=>{
                    if(item.type == "00" && item.active){
                        documentVersion = this.downLoadType == "00" ? "approve" : this.downLoadType == "01" ? "sign" : ""
                    }
                });
                let fileFrom = documentTypeList && documentTypeList.some(item=>{return item == "00" || item == "10"}) ? "userUpload" : "";
                const params = {
                    orderNo: this.order.orderNo,
                    bs: this.role==='S'?'S':'',
                    documentTypeList:documentTypeList ? documentTypeList : [],
                    documentVersion:documentVersion,
                    fileFrom:fileFrom
                };
                InterfaceService.getContractInfo(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            if (documentTypeList && type) {
                                this.upLoadFileList = data.respData.documentInfos || [];
                            } else {
                                let list =  data.respData.documentInfos || [];
                                let attachList = []
                                list.forEach(item=>{
                                    let onOff = false;
                                    attachList.forEach(_item=>{
                                        if (_item.documentId == item.documentId) {
                                            onOff = true
                                        }
                                    });
                                    if (!onOff) {
                                        attachList.push(item)
                                    }
                                });
                                attachList.forEach(item=>{
                                    item.checked = false;
                                    if (this.downLoadType == "00") {
                                        attachBList.push(item)
                                    }else {
                                        if (item.bs == "B") {
                                            attachBList.push(item)
                                        }else if (item.bs == "S") {
                                            attachSList.push(item)
                                        }else if (item.bs == "BS") {
                                            attachBList.push(item)
                                            attachSList.push(item)
                                        }
                                    }
                                });
                                this.attachBList = JSON.parse(JSON.stringify(attachBList));
                                this.attachSList = JSON.parse(JSON.stringify(attachSList));
                                this.checkAllSelect(this.attachBList,"B")
                                this.checkAllSelect(this.attachSList,"S")
                            }
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {
                    },
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
        },
        props:[],
    };
</script>

<style lang="scss" scoped>
    .close-btn{
        width: 50px;
        height: 50px;
        position: absolute;
        top: 0;
        right: 0;
        text-align: center;
        line-height: 50px;
        .el-icon-close{
            font-size: 22px;
        }
    }
    .upload-record-title{
        width: 100%;
        border-top: 1px solid #eeeeee;
        margin-top: 20px;
        height: 34px;
        line-height: 34px;
        background: #f5f5f5;
        padding-left: 10px;

        span{
            display: inline-block;
            float: left;
            height: 34px;
            line-height: 34px;
            color: #888888;

            border-bottom: 1px solid #fff;
            text-align: left;
        }
        span:first-child{
            width: 70.5%;
        }
        span:nth-of-type(2){
            width: 23%;
        }
        span:last-child{
            /*width: 10.7%;*/
            text-align: left;
        }
    }
    .record-wrap{
        width: 100%;
        max-height: 110px;
        overflow-y: scroll;
        background: #f5f5f5;
        border-bottom: 1px solid #eee;
        margin-bottom: 20px;
        ul{
            padding-left: 10px;

            li{
                min-height: 32px;
                line-height: 32px;
                border-bottom: 1px solid #eeeeee;
                span:first-child{
                    width: 71%;
                }
                span:nth-of-type(2){
                    width: 15.6%;
                }
                // span:last-child{
                //     /*width: 5%;*/
                //     text-align: right;
                // }
                span{
                    display: inline-block;
                    float: left;
                    text-align: left;
                }
                .buttons{
                    width: 11.4%;
                    display: inline-block;
                    text-align: right;
                }
            }
        }

        p{
            padding-left: 10px;
            line-height: 30px;
        }
    }
    .panel-title{
        margin-bottom: 4px !important;
    }

    .attach-wrapper{
        /deep/ .el-checkbox__inner{
            border-radius: 0;
            background-color:#eee;
            border:1px solid #cacaca;
        }

        /deep/ .el-checkbox__input.is-checked .el-checkbox__inner{
            background-color: #ffd64e;
            border-color:#ffd64e;
        }

        /deep/ .el-checkbox__input.is-checked + .el-checkbox__label{
            color:#444 !important;
        }
        .attach-panel-title{
            height: 38px;
            width: 100%;
            background: #eee;
            overflow: hidden;
            margin-bottom: 10px;
            .attach-panel{
                font-size:14px;
                color: #888;
                font-weight: 500;
                line-height: 38px;
                height:38px;
                padding:0 20px;
                background: #eee;
                float: left;
                &.active{
                    color:#fff;
                    font-weight: 700;
                    background: #4f525a;
                }
            }
        }

    }
    .s-title{
        font-size: 14px;
        color:#444;
        margin:10px 0;
        border-left: 3px solid #4f525a;
        line-height: 1.2;
        padding-left: 6px;
    }
    .s-body{
        height:224px;
        background: #eee;
        overflow-y: scroll;
        padding:4px 10px;
        li{
            width: 100%;

            font-size: 14px;
            color:#444;
            min-height: 28px;
            padding:7px 0 ;
            line-height: 1.2;
        }

    }
    .upload-wrapper{
        .up-load-contract-describe{
            padding-top:10px;
            line-height: 20px;
            font-size: 12px;
            color:#444;
        }
        .up-load-contract-form{
            padding-top: 20px;
            position: relative;
            input[type="file"] {
                position: absolute;
                width: 0;
                height: 0;
                overflow: hidden;
                opacity: 0;
            }

            .file-label {
                width: 98px;
                display: inline-block;
                padding: 12px 20px;
                line-height: 1;
                white-space: nowrap;
                cursor: pointer;
                font-size: 14px;
                border: 1px solid #ffd64e;
                background: #ffd64e;
                margin-left: 10px;
            }
            .disable{
                /*padding: 12px 14px;*/
                border: 1px solid #dddddd;
                background: #dddddd;
                cursor: not-allowed;
                color: #afaeae;
            }
            /deep/ .el-checkbox {
                padding: 0;
                margin-left: 0;
                border: none;
                background: none;
            }
            /deep/ .el-col-24 label:nth-of-type(2){
                margin-left: 10px;
            }
            .label-title{
                width: 100%;
                line-height: 18px;
            }

            .label-sub-title{
                width: 100%;
                line-height: 16px;
                font-size: 12px;
            }

            .contract-list {
                min-height: 38px;
                padding: 0 10px;
                border: 1px solid #dcdfe6;
                line-height: 38px;
                color: #888888;
                font-size: 12px;
            }

            a{
                margin-left: 10px;
                color: #0082ff;
            }
        }

    }
    /deep/ .el-form-item__label{
        font-size: 12px!important;
    }
    .up-load-warrant{

        /deep/ .el-form-item__label{
            line-height: 1.2;
            font-size: 12px;
        }
    }
    .el-tag + .el-tag {
        margin-left: 10px;
    }

    .dialog {
        line-height: 25px;

        /deep/ .el-dialog__header {
            padding: 0;

            &:before {
                display: none;
            }
        }
    }
    .neet-upload-upfile {
        box-sizing: border-box;
        padding-left: 12px;
        display: flex;
        border-top: 1px solid transparent;

        &.disabled {
            /deep/ .center .blue {
                // background: #dddddd !important;
                // color: #a9a9a9 !important;
            }
        }

        &>li {
            width: 85%;

            &:nth-child(1) {
                .input-file-p {
                    border: 1px solid #dcdfe6;
                    box-sizing: border-box;
                    padding: 0 12px;
                    color: #606266;
                    display: block;
                    display: flex;
                    flex-wrap: wrap;
                    min-height: 40px;

                    span {
                        height: 38px;
                        overflow: hidden;
                        text-overflow:ellipsis;
                        white-space: nowrap;
                    }

                    &>.gray {
                        color: #c0c4cc;
                        font-size: 12px;
                        outline: none;
                        height: 38px;
                    }

                    .el-tag {
                        margin: 4px;
                        height: 30px;
                    }
                }
            }

            &:nth-child(2) {
                width: 15%;
            }

            &:nth-child(3) {
                width: 33%;
            }

            .el-button--default {
                height: 40px;
                margin-left: 4px;
            }
        }

        .el-button--primary {
            width: 119px;
            margin-right: 12px;
        }

        /deep/ .upfile-container {
            .center {
                label {
                    width: 100%;
                    background-color: #ffd64e;
                    color: #000000 !important;
                    text-align: center;
                    height: 40px;
                }
            }
        }
    }

    .lh40{
        height: 40px;
        line-height: 40px;
    }
    .lh12{
        line-height: 1.2;
    }
    .lh40{
        /deep/ .el-form-item__label{
            height: 40px;
            line-height:40px;
        }
    }
    .isie{
        /deep/ .upfile-container {
            .center {
                label {
                    height: 42px;
                }
            }
        }
    }
    /deep/ .dialog-footer{
        text-align: center;
        margin-bottom: 20px;
        margin-top:20px;
    }
    .clear{
        clear: both;
    }
</style>
