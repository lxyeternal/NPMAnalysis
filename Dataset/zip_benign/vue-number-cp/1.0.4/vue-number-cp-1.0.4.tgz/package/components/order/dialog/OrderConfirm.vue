<template>
    <div>
        <!-- 确认合同 -->
        <el-dialog class="dialog" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="850px" center :close-on-click-modal="false">
            <div slot="title" class="el-dialog__title">{{isBatch? '批量确认合同':'确认合同'}}</div>
            <div class="tl">您已确认合同内容、并履行货品供应服务。且备货周期为
                <el-input class="term-input" type="number" v-model="term" placeholder="请输入备货时长"  @keyup.native="validateTerm($event)"></el-input>日历天
                <span class="info">(即供应商收到发货通知单之日起至供应商将货物送达采购商指定地点的时间周期)。</span>

                <el-form class="form" label-width="160px">
                    <el-row>
                        <el-col :span="12" v-for="(item,index) in filterLength(roleList,0,4)" :key="index">
                            <el-form-item :label="item.label+':'" :error="showErrorMsg(item)" :rules="[{required: true, message: '', trigger: 'change'}]">
                                <el-select v-model="item.defaultChoose" :placeholder="'请选择'+item.label" @change="getAcctId(item)">
                                    <el-option class="role-option" v-for="option in filterCurrentRole(item,item.acctList)" :key="option.acctId" :label="option.acctName" :value="option.acctId">
                                        <span style="line-height: 30px" v-html="option.acctName" @click="handlegoUsersManage(option)">{{option.acctName}}</span>
                                        <span v-if="option.mobile">(Tel:{{option.mobile}})</span>
                                        <p v-if="filterRoleName(option.roleIds)" :title="filterRoleName(option.roleIds)">{{filterRoleName(option.roleIds)}}</p>
                                    </el-option>
                                </el-select>
                            </el-form-item>
                        </el-col>
                    </el-row>

                    <div v-if="roleList.length>4">
                        <hr>
                        <p class="tip">※本合同为货物供应合同，请添加施工人员（施工单位人员可与供应商人员信息一致），才能为采购商提供供货及安装服务。</p>
                        <el-row>
                            <el-col :span="12" v-for="(item,index) in filterLength(roleList,4)" :key="index">
                                <el-form-item :label="item.label+':'" :error="showErrorMsg(item)" :rules="[{required: true, message: '', trigger: 'change'}]">
                                    <el-select v-model="item.defaultChoose" :placeholder="'请选择'+item.label"  @change="getAcctId(item)">
                                        <el-option class="role-option" v-for="(option,index) in filterCurrentRole(item,item.acctList)" :key="option.acctId" :label="option.acctName" :value="option.acctId">
                                            <span style="line-height: 30px" v-html="option.acctName" @click="handlegoUsersManage(option)">{{option.acctName}}</span>
                                            <span v-if="option.mobile">(Tel:{{option.mobile}})</span>
                                            <p v-if="filterRoleName(option.roleIds)" :title="filterRoleName(option.roleIds)">{{filterRoleName(option.roleIds)}}</p>
                                        </el-option>
                                    </el-select>
                                </el-form-item>
                            </el-col>
                        </el-row>
                    </div>

                </el-form>

            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">{{isBatch? '批量确认':'确认'}}</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";

const vendorList = [
//     1.供应商
// ·供应商授权代表=>620角色
// ·合同签字人=>621
// ·合同盖章人=>622
// 2.施工单位(如果有的话)
// ·授权代表(指定收货人)=>640角色
// ·项目经理=>641角色
// ·项目盖章人=>642角色
    {
        role: "30",
        label: "供应商授权代表",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"620"
    },
    {
        role: "33",
        label: "项目盖章人",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"623",
    },
    // {
    //     role: "32",
    //     label: "合同签字人",
    //     acctId: "",
    //     acctList: [],
    //     defaultChoose:"",
    //     roleId:"621"
    // },
    {
        role: "31",
        label: "合同盖章人",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"622"
    }
];

const impleList = [
    {
        role: "00",
        label: "施工单位授权代表",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"640"
    },
    {
        role: "01",
        label: "施工单位项目经理",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"641"
    },
    {
        role: "02",
        label: "施工单位项目盖章人",
        acctId: "",
        acctList: [],
        defaultChoose:"",
        roleId:"642"
    }
];

export default {
    mixins: [accountMixin],
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            isBatch: false,
            orders: [],
            term: "",
            acctList: [],
            roleList: this.$clone(vendorList),
            showError: false
        };
    },
    methods: {
        open(orders, isBatch) {
            this.isBatch = isBatch;
            this.orders = orders || [];
            this.term = "";
            this.roleList = this.$clone(vendorList);
            this.dialogVisible = true;
            this.init();
            this.getSubRole();
        },
        filterLength(list, start, end) {
            return this.roleList.slice(start, end);
        },
        filterCurrentRole(role,acctList){
            let arr = [];
            acctList.forEach(item =>{
                if (item.roleIds) {
                    item.roleIds.forEach(__item=>{
                        // console.log(__item);
                        if (__item.roleId == role.roleId) {
                            arr.push(item)
                        }
                    })
                }
            });
            if (arr.length == 0) {
                arr.push({
                    acctName:`<p style="color: #aaa">暂无${role.label}&nbsp;&nbsp;请设置<em style="cursor: pointer;color: #3a8ee6" @click="go()">权限管理</em>添加</p>`
                })
            }
            return arr
        },
        filterRoleName(list) {
            const arr = [];
            if (list && list.length) {
                list.forEach(item => {
                    if (item.roleName) {
                        arr.push(item.roleName);
                    }
                });
            }

            return arr.join(",");
        },
        showErrorMsg(item) {
            if (!this.showError) return "";
            let msg;
            if (!item.defaultChoose) {
                msg = "请选择" + item.label;
            }
            return msg;
        },
        handlegoUsersManage(option){
            if (option.acctName.indexOf("暂无") != -1){
                this.$router.push('/vendorCenter/usersManage')
            }
        },
        handleConfirm() {
            if (!this.term) {
                this.$message.error("请输入备货时长");
                return;
            }
            let valid = true;
            this.roleList.forEach(item => {

                if (!item.defaultChoose) {
                    valid = false;
                }
            });

            if (!valid) {
                this.showError = true;
            } else {
                this.confirmOrder();
            }
        },
        validateTerm(ev){
            let val = ev.target.value;
            this.term = val.substring(0, 4);
        },
        // 查询项目部下属信息
        getSubRole() {
            const params = {};
            InterfaceService.getQuerySubordinate(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        // this.acctList = data.respData.acctList || [];
                        let arr = [];
                        this.roleList.forEach(item => {
                            item.acctList = data.respData.acctList
                            item.acctList.forEach(_item=>{
                                if (_item.roleIds){
                                    _item.roleIds.forEach(role=>{
                                        if (role.roleId == item.roleId){
                                            arr.push({
                                                "id":role.roleId,
                                                "acctName":_item.acctName,
                                                "acctId":_item.acctId
                                            })
                                        }
                                    })
                                }
                            })
                        });
                        //下属员工有且仅有一个与label对应的角色时，默认选中
                        let arr1 = [];
                        arr.forEach(item=>{
                            arr1.push(item.id);
                        });
                        const filterNonUnique = arr => arr.filter(i => arr.indexOf(i) === arr.lastIndexOf(i))
                        arr.forEach(item=>{
                            filterNonUnique(arr1).forEach(_item=>{
                                if (item.id == _item) {
                                    this.roleList.forEach(__item=>{
                                        if (__item.roleId == item.id){
                                            __item.defaultChoose = item.acctName
                                            __item.acctId = item.acctId
                                        }
                                    })
                                }
                            })
                        });
                        this.roleList.forEach(item=>{
                            if (!item.defaultChoose){
                                item.defaultChoose = "";
                            }
                            if (item.acctList) {
                                item.acctList.forEach(_item=>{
                                    if (item.defaultChoose == _item.acctId){
                                        item.acctId = _item.acctId
                                    }
                                })
                            }else {
                                item.defaultChoose = ""
                            }
                        });
                        console.log(this.roleList);
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        getAcctId(item){
            item.acctId = item.defaultChoose
            if (!item.acctId) {
                item.defaultChoose = ""
            }
        },
        confirmOrder() {
            const stakeHolder = [];

            this.roleList.forEach(item => {
                if (item.defaultChoose) {
                    stakeHolder.push({
                        role: item.role,
                        corpId: this.userinfo.corpId,
                        acctId: item.acctId
                    });
                }
            });
            console.log(stakeHolder);

            const orders = [];
            this.orders.forEach(item => {
                orders.push(item.orderNo);
            });

            const params = {
                orders: orders,
                prepareCycle: this.term,
                contractStakeHolders: stakeHolder
            };
            InterfaceService.confirmOrder(
                params,
                data => {
                    console.log(data);
                    if (data.respCode === "0000") {
                        if (data.respData.respCode === "0000") {
                            this.dialogVisible = false;
                            this.$emit("close", true);
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    } else {
                        this.$message.error(data.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        },
        init() {
            let vendorImple = false; // 供应商为施工方
            if (this.orders) {
                this.orders.forEach(item => {
                    if(vendorImple) return;
                    let vendorCorpId = "";
                    // 查找供应商
                    // item.contractStakeHolders.forEach(_item => {
                    //     if (!vendorCorpId && _item.role[0] == "3") {
                    //         vendorCorpId = _item.corpId;
                    //     }
                    // });

                    for (let i = 0, len = item.contractStakeHolders.length; i < len; i++) {
                        const contractStakeHolders = item.contractStakeHolders[i],
                            role = contractStakeHolders && contractStakeHolders.role && contractStakeHolders.role [0] || '';
                        if (role == "3") {
                            vendorCorpId = contractStakeHolders.corpId;
                            break;
                        }
                    }

                    if (vendorCorpId) {
                        // item.contractStakeHolders.forEach(_item => {
                        //     if (_item.role[0] == "0" && _item.corpId == vendorCorpId) {
                        //         vendorImple = true;
                        //     }
                        // });
                    for (let i = 0, len = item.contractStakeHolders.length; i < len; i++) {
                        const contractStakeHolders = item.contractStakeHolders[i],
                            role = contractStakeHolders && contractStakeHolders.role && contractStakeHolders.role [0] || '';
                            if (role == "0" && vendorCorpId == contractStakeHolders.corpId) {
                                vendorImple = true;
                                break;
                            }
                        }
                    }
                });
            }

            if (vendorImple) {
                this.roleList = this.roleList.concat(this.$clone(impleList));
            }
        },

    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-select {
    width: 100%;
}

hr {
    border: 1px dashed #ececec;
}

.tip {
    margin-top: 20px;
    margin-bottom: 10px;
}

.term-input.el-input {
    width: 200px;
}
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;

    a {
        text-decoration: underline;
        color: #0082ff;
    }

    a.bold {
        font-weight: bold;
        text-decoration: none;
        color: #444444;
        cursor: default;
    }
}

.form {
    margin-top: 20px;
}

.role-option {
    height: auto;
    p {
        height: 30px;
        max-width: 210px;
        line-height: 20px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }
}
[class*="el-col-"]{
    display: inline-block;
    float: none;
}
</style>
