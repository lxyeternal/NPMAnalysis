<template>
  <div class="component-container">
    <div class="head-container" :class="{'flex-direction-column': !isDetaillPage}">
      <!-- 供应商 -->
      <template>

        <!-- 初始化 -->
        <template v-if="order.status === 'init'">
          <el-button type="primary" style="width: 73px" size="mini" @click="handleOptBtnClickConfirm('edit')">编辑</el-button>
          <a class="blue hand" @click="handleOptBtnClickConfirm('del')">删除</a>
        </template>

        <!-- 结束 -->
        <template v-else-if="order.status === 'down'">
          <el-button type="primary" style="width: 73px" size="mini">确认信息</el-button>
        </template>

        <!-- 关闭 -->
        <template v-else-if="order.status === 'rejected'">
          <el-button type="primary" style="width: 73px" size="mini" @click="handleOptBtnClickConfirm()">关闭请款</el-button>
        </template>

        <!-- 施工监理/工程部项目经理 -->
        <!-- 不再 init 状态显示 且 如果是 供应商的话 只在供应商确认时 才能显示 -->
        <template v-if="isShowBtnContainer">
          <el-button type="primary" v-if="queryStatus !== 'rejected'" :style="{width: isDetaillPage?'120px':'72px'}" size="mini" @click="handleOptBtnClickConfirm()">{{confirmBtnName}}</el-button>
          <!-- 不是在 鉴证2且供应商确认8 都可以退回 -->
          <el-button size="small" style="width: 120px" v-if="isShowReturnBtn" @click="handleOptBtnClickReturn()">退回</el-button>
          <el-button size="small" style="width: 120px" v-if="this.order.other.myTaskId === 'supplier_confirm' && isDetaillPage ||(queryStatus === 'rejected' && this.order.other.myTaskId)" @click="handleOptBtnClickConfirm('close')">关闭请款申请</el-button>
        </template>
      </template>
    </div>

    <!-- 底部悬浮 -->
    <div class="foot-float" v-if="isDetaillPage">
      <div class="inner-container">
        <div class="right">
          <template v-if="isShowBtnContainer">
            <el-button type="primary" v-if="queryStatus !== 'rejected'" size="small" style="width: 120px" @click="handleOptBtnClickConfirm()">{{confirmBtnName}}</el-button>
            <el-button size="small" style="width: 120px" v-if="isShowReturnBtn" @click="handleOptBtnClickReturn()">退回</el-button>
            <el-button size="small" style="width: 120px" v-if="this.order.other.myTaskId === 'supplier_confirm' && isDetaillPage || (queryStatus === 'rejected' && this.order.other.myTaskId)" @click="handleOptBtnClickConfirm('close')">关闭请款申请</el-button>
          </template>
          <el-button size="small" style="width: 120px" @click="handleDownloadAllFile">下载所有附件</el-button>
        </div>
      </div>
    </div>

    <PaymentReportOptDialogComponent v-if="showOptDialogComponent" :visible.sync="showOptDialogComponent" :order="order" @refresh="refresh"></PaymentReportOptDialogComponent>

    <AskForMoneyGoBackComponent v-if="goBackVisible" :visible.sync="goBackVisible" :order="order" @refresh="refresh"></AskForMoneyGoBackComponent>

    <!-- 删除 -->
    <el-dialog class="dialog" :title="'删除提示'" :append-to-body="true" :lock-scroll="true" :visible.sync="showDelDialog" width="600px" center :close-on-click-modal="false">
      <div class="confirm-payment-container">
        <div class="center">
          您确认删除该请款记录吗？
        </div>
        <div class="btn-center">
          <el-button size="small" type="primary" style="width: 120px" @click="handleDelDialogConfirm">确认</el-button>
          <el-button size="small" style="width: 120px" @click="handleDelDialogCancel">取消</el-button>
        </div>
      </div>
    </el-dialog>

    <!-- 添加个人印章 -->
    <el-dialog class="dialog" :title="'添加个人印章确认信息'" :append-to-body="true" :lock-scroll="true" :visible.sync="isShowAddPersonalSealDialog" width="600px" center :close-on-click-modal="false">
      <div class="confirm-payment-container">
        <div class="center AddPersonalSeal">
          <ul>
            <li>
              <span>企业名称：</span>
              <span>{{userInfo.corpName}}</span>
            </li>
          </ul>
          <ul>
            <li>
              <span>姓名：</span>
              <span>{{userInfo.acctName}}</span>
            </li>
            <li>
              <span>身份证号：</span>
              <span>{{certNo}}</span>
            </li>
          </ul>
        </div>
        <div class="btn-center">
          <el-button size="small" type="primary" style="width: 120px" @click="handleAddPersonalSealDialogConfirm">确认并提交</el-button>
          <el-button size="small" style="width: 120px" @click="isShowAddPersonalSealDialog = false">取消</el-button>
        </div>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>
</template>
<script>
import accountMixin from "@/mixins/account";
import PaymentReportOptDialogComponent from "@/components/order/askForMoney/PaymentReportOptDialogComponent";
import AskForMoneyGoBackComponent from "@/components/order/askForMoney/AskForMoneyGoBackComponent";
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
export default {
  mixins: [accountMixin],
  components: {
    Loading,
    PaymentReportOptDialogComponent, // 操作 - 弹窗
    AskForMoneyGoBackComponent, // 退回弹窗
  },
  props: ['order', 'tab'],
  data() {
    return {
      isLoading: false,
      showOptDialogComponent: false,  // 操作 - 弹窗
      flowStateList: [], // 流程对应状态的 按钮名称
      goBackVisible: false, // 退回
      showDelDialog: false, // 删除
      delContractName: '', // 删除合同名称
      queryStatus: '', // 项目状态
      isShowAddPersonalSealDialog: false, // 添加个人印章
      personalSeal: [], // 个人印章信息
      certNo: '', // 身份证号
    }
  },
  computed: {
    // 是否在详情页
    isDetaillPage() {
      const path = this.$route.path || ''
      // 只在详情页 才显示返回
      return path.includes('paymentPlanDetail')
    },

    // 是否显示退回btn (除施工监理和供应商确认状态都可以退回)
    isShowReturnBtn() {
      return this.order && this.order.other && this.order.other.paymentReturnBeans && this.order.other.paymentReturnBeans.length
    },

    // 是否显示按钮 - 鉴证/审核/确认信息/退回
    isShowBtnContainer() {
      if (!(this.order && this.order.other)) return
      let state = false

      // 不是初始化  且 有 taskId
      if (this.order.status !== 'init' && this.order.other.myTaskId != '') {
        // 如果当前角色是供应商  则只能在 状态为 供应商确认时显示 确认信息 按钮
        if (this.role === 'S' && ['supplier_confirm'].includes(this.order.other.myTaskId)) {
          state = true
        }

        // 施工监理 - 鉴证
        if (this.role === 'S' && this.supervisory) {
          state = true
        }

        // 采购商 - 审核
        if (this.role === 'B' && !['supplier_confirm'].includes(this.order.other.myTaskId)) {
          state = true
        }
      }

      // 如果是在列表 页 的按钮  不是待处理的 都不显示
      if (!this.isDetaillPage && this.tab != 0) {
        state = false
      }

      // 供应商 关闭
      if (this.queryStatus === 'rejected') {
        state = true
      }

      return state
    },

    // 查询当前项目进度
    queryProcessCurrent() {
      let itemList = this.order && this.order.other && this.order.other.flowList || []
      return itemList.filter(f => f.isCurrentNode == '1')[0] || {}
    },

    // 根据 当前项目进度 查找 显示 对应 按钮名称
    confirmBtnName() {
      let btnName = ''
      try {
        const item = this.flowStateList.filter(f => f.steps && f.steps.includes(this.order.other.myTaskId))[0] || {}
        btnName = item.btnName || ''
      } catch (error) { console.log(error) }

      return btnName
    },

    acctId() {
      return this.$store.state.userInfo && this.$store.state.userInfo.acctId || ''
    },
    userInfo() {
      return this.$store.state.userInfo
    },
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.queryStatus = this.$route.query.queryStatus
      // 如果是 退回到了 供应商  则退回意见显示
      this.queryStatus === 'rejected' && (this.$set(this.order, 'cloase', true))
      this.initFlowStateList()
    },

    /**
     * 初始化 按钮名称 数据
     */
    initFlowStateList() {
      this.flowStateList = [
        {
          steps: ['supervisory_confirm', 'engineer_pm_confirm'],
          btnName: '鉴证'
        },
        {
          steps: ['contract_op_confirm', 'contract_director_confirm', 'finance_director_confirm', 'general_manager_confirm'],
          btnName: '审核'
        },
        {
          steps: ['supplier_confirm'],
          btnName: '确认信息'
        },
      ]
    },

    /**
     * 下载所有附件
     */
    handleDownloadAllFile() {
      this.paymentDetailDownloadAll()
    },

    /**
     * 打包下载
     */
    paymentDetailDownloadAll() {
      return new Promise(resolve => {
        let params = { //给予后端的入参
          paymentNo: this.order.paymentNo
        }
        InterfaceService.paymentDetailDownloadAll(params, data => {
          if (data.respData.respCode === '0000') {
            this.$download([{
              name: data.respData && data.respData.fileName || '全部资料',
              url: data.respData && data.respData.fileUrl
            }])
          }
        }, data => { }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },

    /**
     * 详情
     */
    handleViewDetail() {
      try {
        window.open(this.$router.resolve({
          path: "/paymentPlanDetail",
          query: {
            executionId: this.order.other.executionId,
            paymentNo: this.order.paymentNo,
            queryStatus: this.order.status || ''
          }
        }).href, '_blank')
      } catch (error) { console.log(error) }
    },

    handleAddPersonalSealDialogConfirm() {
      this.certify()
      this.isShowAddPersonalSealDialog = false
    },

    handleDelDialogConfirm() {
      this.saveMoneyApplication(this.order)
      this.showDelDialog = false
    },

    handleDelDialogCancel() {
      this.showDelDialog = false
    },

    /**
     * 按钮 确认 点击
     */
    async handleOptBtnClickConfirm(state) {
      switch (state) {
        // 删除
        case 'del':
          this.delContractName = ''
          this.delContractName = this.order && this.order.contractName
          this.showDelDialog = true
          break
        // 编辑
        case 'edit':
          this.$removeRootScope('initiateAnapplicationBaseInfo')
          window.open(
            this.$router.resolve({
              path: "/InitiateAPayment",
              query: {
                paymentNo: this.order && this.order.paymentNo || '',
                state: 'edit'
              }
            }).href, '_blank')
          break
        default:
          // 非详情页的 确认信息按钮 点击跳转详情页
          if (!this.isDetaillPage) {
            this.handleViewDetail()
            return
          }

          // 点击 是否为 关闭请款
          this.$set(this.order, 'close', state === 'close')

          // 如果不是关闭 则判断 是否有 个人签章 有则 继续往下 无则添加
          if (state !== 'close') {
            await this.getSealList()
            // 如果个人印章没有 则 需要添加个人印章
            if (!(this.personalSeal && this.personalSeal.length)) {
              await this.getAccountInfo()
              this.isShowAddPersonalSealDialog = true
              return
            }
          }

          this.showOptDialogComponent = true
          break
      }
    },

    /**
     * 获取身份证号
     */
    getAccountInfo() {
      return new Promise(resolve => {
        const params = {
          acctId: this.acctId
        };
        InterfaceService.accountInfo(params, data => {
          if (data.respCode === "0000") {
            this.certNo = data.respData.certNo || ''
            resolve(this.certNo)
          } else {
            this.$message.error(data.respMsg)
          }
        }, data => { }, () => {
          this.isLoading = true
        }, () => {
          this.isLoading = false
        })
      })
    },

    /**
     * 获取个人印章列表参数
     */
    getSealList(type) {
      return new Promise(resolve => {
        let params = {
          sealDataType: 1
        };
        InterfaceService.getSealList(params, data => {
          if (data.respCode === '0000') {
            if (data.respData.respCode == '0000') {
              let result = data.respData.sealDataList || [];
              this.personalSeal = []
              if (result.length > 0) {
                result.forEach(item => {
                  if (item.isOwner == '1') {
                    this.personalSeal.push(item)
                  }
                })
              }
              resolve(true)
            } else {
              this.$message.error(data.respData.respMsg);
              resolve(false)
            }
          } else {
            this.$message.error(data.respMsg);
            resolve(false)
          }
        }, data => { }, () => {
          this.isLoading = true;
        }, () => {
          this.isLoading = false;
        })
      })
    },

    /**
     * 实名认证
     */
    certify() {
      const params = {
        acctType: '1',
        name: this.userInfo.corpName,
        certType: '01',
        certNo: this.certNo,
      }
      InterfaceService.certifyAccount(params, data => {
        let res = data.respData;
        if (res.respCode === "0000") {
          this.setSeal(data.respData.esignId || '')
        } else {
          this.$message.error(res && res.respMsg);
        }
      }, data => { }, () => {
        this.isLoading = true;
      }, () => {
        this.isLoading = false;
      })
    },

    /**
     * 实名认证后 - 创建个人签章
     */
    setSeal(esignId) {
      const params = {
        esignId: esignId,
        acctType: '1',
        processFlg: '1'
      };
      InterfaceService.setSeal(params, data => {
        if (data.respCode === '0000') {
          if (data.respData.respCode == '0000') {
            this.$message.success('添加成功')
          } else {
            this.$message.error(data.respData.respMsg)
          }
        } else {
          this.$message.error(data.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },

    /**
     * 点击 退回
     */
    handleOptBtnClickReturn() {
      this.goBackVisible = true
    },

    /**
     * 删除
     */
    async saveMoneyApplication(item) {
      if (!item) return
      const params = {
        orderNo: item.orderNo,
        paymentNo: item.paymentNo,
        paymentOperFlg: 'Del',
        paymentType: item.paymentType,
      }
      if (!params) return
      InterfaceService.saveMoneyApplication(params, async data => {
        if (data.respData.respCode === "0000") {
          this.$message.success('删除成功')
          this.refresh()
        } else {
          this.$message.error(data.respData.respMsg)
        }
      }, data => { }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      })
    },


    refresh() {
      if (window.opener) {
        window.opener.location.reload();
      }
      this.$emit('refresh', true)
    }
  }
}
</script>
<style lang="scss" scoped>
.component-container {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  .head-container {
    display: flex;
    justify-content: flex-end;
    &.flex-direction-column {
      flex-direction: column;
      align-items: flex-end;
    }
  }
  .foot-float {
    position: fixed;
    height: 60px;
    width: 100%;
    background-color: #72757b;
    bottom: 0;
    left: 0;
    z-index: 2000;
    display: flex;
    align-items: center;
    .inner-container {
      display: flex;
      justify-content: flex-end;
      align-items: center;
      .right {
        display: flex;
        justify-content: flex-end;
      }
    }
  }
}
.btn-center {
  margin: 12px;
  text-align: center;
}
/deep/ .el-button--mini {
  padding: 7px 9px;
}

.AddPersonalSeal {
  padding: 12px 12px 22px;
  ul {
    margin-top: 12px;
    width: 100%;
    overflow: hidden;
    li {
      width: 50%;
      float: left;
      overflow: hidden;
      span {
        display: block;
        float: left;
        &:first-child {
          width: 90px;
          text-align: right;
          font-weight: bold;
          margin-right: 6px;
        }
      }
    }
  }
}
</style>
