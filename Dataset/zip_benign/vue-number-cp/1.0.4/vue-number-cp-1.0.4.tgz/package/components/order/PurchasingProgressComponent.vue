<template>
  <div class="purchasingProgressComponent">
    <div class="require-content" :class="{fold: progress.stretchFlag}" v-if="progress.attachName">
      <div class="require-title" v-if="progress.attachName">
        <span class="bold f14">
          {{progress.attachName}}
          <!--  :fileTypes="uploadFileSuffix" -->
          <UpfileComponent v-if="progress.isShowOpr == '1' || (progress.isShowOpr != '1' && progress.fileFrom == 'esUpload')" ref="upfileRef" :immediateClearList="true" :fileSize="52428800" :fileSizeMsg="'上传文件不能超过50M, 请重新选择'" :btnName="'上传'" :dirName="`${new Date().getTime()}/`" :type="'67'" :appName="'TRD'" :id="'123'" @outputList="handleUpFileResult($event, progress)"></UpfileComponent>
          <DownloadAndView v-if="progress.isShowOpr != '1'" :attachName="`${progress.attachName}.pdf`" :attachUrl="progress.attachUrl" downloadName="下载" viewName="查看"></DownloadAndView>
        </span>
        <div class="fr blue hand f12 stretch" @click="handleClick">
          {{progress.stretchFlag ? '展开':'收起'}}
          <i v-if="progress.stretchFlag" class="el-icon-caret-bottom"></i>
          <i v-else class="el-icon-caret-top"></i>
        </div>
      </div>
      <template v-if="!progress.stretchFlag">
        <div class="stake-holder-content" :style="{marginBottom:  progress.speedOfProgressList.length -1 == speedIdx ? '0px': '10px'}" v-for="(speedItem, speedIdx) in progress.speedOfProgressList" :key="speedIdx">
          <p style="margin-bottom: 4px; font-size: 14px">{{speedItem.title}}</p>
          <el-row :gutter="10" v-if="speedItem.dataList && speedItem.dataList.length">
            <el-col :span="12/speedItem.dataList.length*2" v-for="(item,index) in speedItem.dataList" :key="index">
              <div style="min-height: 111px">
                <p style="margin-bottom: 16px;">{{item.roleName}}&nbsp;{{item.sealType !== '1' ? '盖章' : '签字'}}：
                  <span :class="{green : item.processFlg == '1',red:item.processFlg == '0'}">
                    {{item.processFlg == '1' ? item.sealType !== '1' ? '已盖章' : '已签字' : item.sealType !== '1' ? '待盖章' : '待签字' }}
                  </span>
                </p>
                <p style="margin-bottom: 10px;" class="grey">{{item.custName}}<em v-if="item.mobile">(Tel:<em>{{item.mobile
                      | formatPhoneNumber("3 4 4")}}</em>)</em></p>
                <p class="grey" v-show="item.uptTm && item.processFlg == '1'">签署日期：
                  <template v-if="item.uptTm && item.processFlg == '1'">{{item.uptTm}}</template>
                </p>
              </div>
            </el-col>
          </el-row>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import DownloadAndView from '@/components/order/DownloadAndView'
import UpfileComponent from "@/components/order/biddingManagement/upfileComponent";
import { InterfaceService } from "@/services/api";

export default {
  components: {
    DownloadAndView,
    UpfileComponent,
  },
  props: ["progress"],
  data() {
    return {
    }
  },
  computed: {

  },
  methods: {
    handleUpFileResult(e, progress) {
      const { file, name, targetValue, url } = e[0]
      // this.authorizationInfo = {
      //   file: file,
      //   attachName: name,
      //   creTm: DateUtil.dateToString(),
      //   targetValue,
      //   attachUrl: url,
      // };
      // this.form.attachUrl = this.authorizationInfo.attachUrl || "";
      this.uploadRequireGoddsFIle(progress && progress.documentId || '', url)
    },

    uploadRequireGoddsFIle(documentId, attachPath) {
      let param = {
        documentId,
        attachPath,
      }
      InterfaceService.uploadRequireGoddsFIle(param, data => {
        if (data && data.respData && data.respData.respCode === "0000") {
          this.refurbish()
        } else {
          this.$message.error(data.respData && data.respData.respMsg || '')
        }
      }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
    },

    handleClick() {
      this.progress.stretchFlag = !this.progress.stretchFlag;
      this.$emit('clickFlg')
    },
    refurbish() {
      this.$emit('refurbish', true)
    }
  }
};
</script>

<style lang="scss" scoped>
.purchasingProgressComponent {
  .require-content {
    border: 1px solid #ddd;
    padding: 0 10px 10px;
    margin-bottom: 10px;

    /deep/ .upfile-container {
      display: inline-block;
      line-height: 10px;
      padding-top: 0px;
      font-size: 14px;
      width: 40px;
    }

    &.fold {
      height: 50px;
      line-height: 50px;
      .require-title {
        border-bottom: 0;
      }
    }
    .require-title {
      height: 50px;
      line-height: 50px;
      border-bottom: 1px solid #eee;
      margin-bottom: 20px;
      .stretch {
        margin-top: 18px;
      }
    }

    .stake-holder-content {
      /deep/ .el-col {
        div {
          background: #f5f5f5;
          padding: 20px 10px;
        }
      }
    }
  }
}
</style>
