<template>
    <div class="content">
        <PanelTitle title="匹配货品区"></PanelTitle>
        <div>
            <div class="table">
                <table>
                    <thead>
                        <tr>
                            <td width="50"></td>
                            <td width="100">申请单序号</td>
                            <td width="260">品牌/物料名称</td>
                            <td>本次要货量</td>
                            <td>标段</td>
                            <td>合同名称</td>
                            <td width="150"></td>
                        </tr>
                    </thead>
                    <tbody v-for="(row,index) in list" :key="index">
                        <tr :class="{'offline': +row.requireLeft<=0 }">
                            <td>
                                <el-checkbox v-model="row.checked" @change="handleSelectRow(row,index)"></el-checkbox>
                            </td>
                            <td>{{row.no}}</td>
                            <td>
                                <div class="material-name">
                                    <div class="left">
                                        <img :src="row.picUrl" v-error-img>
                                    </div>
                                    <div class="right">
                                        <p>{{ row.materialName }}</p>
                                        <p>规格：{{row.model}}</p>
                                    </div>
                                </div>
                            </td>
                            <td>
                                {{row.applyCount}}{{row.unit}}
                                <p class="red" v-if="+row.requireLeft<=0">数量超过合同剩余可要货量{{row.requireLeft}}{{row.unit}}</p>
                            </td>
                            <td>{{row.location}}</td>
                            <td>{{row.contractName}}</td>
                            <td class="operate">
                                <div v-if="row.requireLeft>0">
                                    <!-- <a>确定</a>
                                    <a>编辑</a> -->
                                    <a @click="handleMove(row,index,'todo')">移至待匹配</a>
                                </div>
                                <div v-else>
                                    <a v-if="+row.requireLeft<=0" @click="handleMove(row,index,'offline')">线下要货</a>
                                </div>
                            </td>
                        </tr>
                        <tr v-if="+row.requireLeft>0&&+row.requireLeft<+row.applyCount" class="row-error">
                            <td colspan="7" class="tc red">
                                本次申请要货{{row.applyCount}}{{row.unit}}，只能发起合同剩余可要货量{{row.requireLeft}}{{row.unit}}。
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <p class="batch-ope">
                <el-checkbox v-model="allCheck" @change="handleAllCheck"></el-checkbox>&nbsp;全选
                <!-- <el-button size="small" type="primary" @click="handleBatchConfirm">批量确定</el-button> -->
                <el-button size="small" @click="handleBatchOffline">线下要货</el-button>
            </p>
        </div>
    </div>
</template>

<script>
import PanelTitle from "@/components/base/PanelTitle";
export default {
    components: {
        PanelTitle
    },
    props: ["list"],
    data() {
        return {
            allCheck: false
        };
    },
    methods: {
        handleSelectRow(item, index) {
            this.$set(this.list, index, item);
            this.checkAllSelect();
        },
        // 是否全选
        checkAllSelect() {
            this.allCheck = this.list.every(item => {
                return item.checked;
            });
        },
        handleAllCheck() {
            this.list.forEach((item, index) => {
                item.checked = this.allCheck;
                this.$set(this.list, index, item);
            });
        },
        handleBatchConfirm() {},
        handleBatchOffline() {
            if (!this.list.length) {
                this.$message.error("无匹配货品");
                return;
            }

            let valid = false;
            this.list.forEach((item, index) => {
                if (item.checked) {
                    valid = true;
                    const material = Object.assign({}, item);
                    delete material.checked;
                    this.handleMove(material, index, "offline");
                }
            });
            this.allCheck = false;

            if (!valid) {
                this.$message.error("请至少选择一个货品");
            }
        },
        // 移至
        handleMove(row, index, position) {
            const material = {
                position: position,
                index: index,
                data: row
            };
            this.$emit("move", material);
        }
    },
    mounted() {}
};
</script>

<style lang="scss" scoped>
.content {
    margin-bottom: 30px;
}

.batch-ope {
    margin-top: 10px;
}

.table {
    margin-bottom: 2px;
    　 /deep/ .el-button {
        font-size: 12px;
    }

    width: 100%;
    line-height: 23px;
    font-size: 12px;
    table {
        width: 100%;
    }
    td {
        padding: 14px 10px;
        vertical-align: middle;
        word-break: break-word;
    }

    thead {
        text-align: center;
        white-space: nowrap;
        font-size: 14px;
        color: #909399;
    }

    tbody {
        text-align: center;

        tr:hover {
            background: #e8f3fd;
        }

        td {
            border-bottom: 1px solid #ffffff;
            background: #f5f5f5;
        }
    }

    tr.offline td {
        background: #cccccc;
    }

    tr.row-error td {
        padding: 5px 10px;
        background: #ffe8e8;
    }
}

.material-name {
    display: inline-flex;
    width: 100%;
    vertical-align: top;
    line-height: 20px;

    img {
        width: 75px;
        height: 75px;
    }

    a:hover {
        text-decoration: underline;
        color: #0082ff;
    }

    .left {
        margin-right: 10px;
    }

    .right {
        text-align: left;

        p:first-child {
            margin-bottom: 10px;
        }
        p:last-child {
            word-break: break-all;
            max-height: 40px;
            overflow: hidden;
            color: #969799;
        }
    }
}

.operate {
    a {
        display: inline-block;
        margin-right: 10px;
        white-space: nowrap;
        color: #0082ff;
    }

    a:last-child {
        margin-right: 0;
    }
}
</style>
