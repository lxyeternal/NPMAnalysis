<template>
    <div>
        <div class="info-item">
            <p>合同名称</p>
            <p></p>
        </div>
        <div class="info-item">
            <p>合同金额(含税)</p>
            <p></p>
        </div>
        <div class="info-item">
            <p>付款事由</p>
            <p></p>
        </div>
        <div class="info-item">
            <p>付款条款</p>
            <p></p>
        </div>
        <div class="info-item">
            <p>完成产值</p>
            <p></p>
        </div>
        <div class="info-item">
            <p>累计应付</p>
            <p></p>
        </div>
        <div class="info-item">
            <p>累计请款(不含本期)</p>
            <p></p>
        </div>
        <div class="info-item">
            <p>累计已付</p>
            <p></p>
        </div>
        <div class="info-item">
            <p>本次申请金额</p>
            <p></p>
        </div>
    </div>
</template>

<script>
export default {
    props: ["info"]
};
</script>

<style lang="scss" scoped>
.info-item {
    p {
        margin: 0;
        padding: 10px;
    }

    p:first-child {
        background: #f5f5f5;
    }
}

.bold {
    font-weight: bold;
}
</style>
