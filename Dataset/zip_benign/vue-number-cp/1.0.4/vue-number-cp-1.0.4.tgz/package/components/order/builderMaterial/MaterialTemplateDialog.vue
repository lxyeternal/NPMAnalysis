<template>
    <div>
        <!-- 下载最新清单模版提示 -->
        <el-dialog class="dialog" :class="{'no-header':type==='warning'}" :title="type==='error'?'上传失败':''" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="600px" center :close-on-click-modal="false">
            <div class="tl content">
                <p v-for="(row,index) in list" :key="index">{{row.msg}}</p>
                <p v-if="type==='error'">请重新审查核对清单内容后，再上传。</p>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button v-if="showDownload" type="primary" size="small" style="width: 150px" @click="handleConfirm('download')">下载要料清单模版</el-button>

                <el-button v-if="type==='warning'" size="small" style="width: 150px" @click="handleConfirm('upload')">确定上传</el-button>
                <el-button v-if="type==='error'" size="small" style="width: 150px" @click="dialogVisible = false">知道了</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            type: "",
            list: []
        };
    },
    computed: {
        showDownload() {
            let bool = false;
            if (this.type === "error") {
                this.list.forEach(item => {
                    if (item.msgCode === "TRANS0124") {
                        bool = true;
                    }
                });
            } else if (this.type === "warning") {
                this.list.forEach(item => {
                    if (item.msgCode === "TRANS0126") {
                        bool = true;
                    }
                });
            }
            return bool;
        }
    },
    methods: {
        open(type, data = []) {
            this.type = type;
            this.list = data;
            this.dialogVisible = true;
        },
        handleConfirm(type) {
            this.dialogVisible = false;
            this.$emit("close", type);
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;
}

.dialog.no-header {
    /deep/ .el-dialog__header {
        &:before {
            display: none;
        }
    }
}

.content {
    max-height: 500px;
    font-size: 14px;
    overflow: auto;
}
</style>


