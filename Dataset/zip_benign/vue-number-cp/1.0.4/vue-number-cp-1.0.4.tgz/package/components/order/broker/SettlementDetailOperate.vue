<template>
    <div>
        <template v-if="topApproval">
            <div class="order-status">
                <div class="status-info">
                    <div class="status-info-content">
                        <div>
                            <div>
                                <label>当前状态：</label>
                                <span class="big">{{approvalStatusDisp}}</span>
                            </div>
                            <div v-if="lastFailTm">
                                <label>{{operationType}}：</label>
                                <span class="big">{{lastFailTm}}</span>
                            </div>
                            <div class="operation" :class="{'right55': !showCirculationOpinion}" v-if="startButton">
                                <el-button type="primary" @click="handleSettlementApproval('applyWf')">审批</el-button>
                                <el-button @click="handleSettlementApproval('update')">保存草稿</el-button>
                                <el-button @click="closeApproavlDialogVisible = true">关闭</el-button>
                            </div>
                            <div class="operation" :class="{'right55': !showCirculationOpinion}" v-if="approvalButton">
                                <el-button type="primary" @click="batchApproavlDialogVisible = true">同意</el-button>
                                <el-button @click="rejectedDialogVisible = true">退回</el-button>
                            </div>
                            <div class="operation" :class="{'right55': !showCirculationOpinion}" v-if="canceledButton">
                                <el-button @click="handleCancel">撤回</el-button>
                            </div>
                            <div class="forward-container">
                                <i @mouseout="showForward()" @mouseover="showForward(true)"></i>
                                <ul v-if="isShowForward" @mouseout="showForward()" @mouseover="showForward(true)">
                                    <li class="printing" @click="handleClickForward(2)"><i></i>打印</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- 流转意见 -->
            <!--  v-if="showCirculationOpinion" -->
            <div :class="['circulation-opinion-container', {openOption: isOpenOptionCirculation}]" v-if="execFlowList.length">
                <i class="option-circulation" v-if="isOpenOptionCirculation" @click="handleClickOptionCirculation">
                    {{isOpenOptionCirculation ? '收起': '展开'}}
                </i>
                <div class="center">
                    <div class="head-title">流转意见</div>
                    <ul :class="{'isOpenOptionCirculation': !isOpenOptionCirculation,'one':computedExecFlowList && computedExecFlowList.length == 1}">
                        <li  v-for="(item,index) in computedExecFlowList" :key="index" :class="{'isAgree': computedCirculationState(item).isAgree}">
                            <dl>
                                <dt>{{item.acctName}}</dt>
                                <dd class="color888888">{{item.roleName}}</dd>
                            </dl>
                            <dl>
                                <dt>{{computedCirculationState(item).state}}</dt>
                                <!--  -->
                                <dd class="color888888">{{item.finishTm}}</dd>
                            </dl>
                            <dl v-if="item.comment">
                                <dt>{{computedCirculationState(item).reason}}:</dt>
                                <dd :title="item.comment" v-html="item.comment.replace(/\n/g, '<br/>')"></dd>
                            </dl>
                        </li>
                    </ul>
                    <div class="center-option-circulation" :style="{marginTop: isOpenOptionCirculation?'16px':''}">
                        <i class="option-circulation" @click="handleClickOptionCirculation">
                            {{isOpenOptionCirculation? '收起': '展开'}}
                        </i>
                    </div>
                </div>
            </div>
        </template>
        <template v-else>
            <div style="position: relative;margin-top: 30px;">
                <PanelTitle :tabs="tabs" class="panel-title"></PanelTitle>
                <span v-if="executionId" class="blue hand download"  @click="handleBatchDownload()">打包下载</span>
                <div class="data-content" ref="content">
                    <div v-if="execAttachList == 0" class="f14">
                        请先上传审批附件
                    </div>
                    <table ref="table" v-else>
                        <tbody class="head">
                        <tr>
                            <th width="80%">审批资料</th>
                            <th width="20%" style="text-align: right" v-if="startButton">操作</th>
                        </tr>
                        </tbody>
                        <tbody>
                        <tr v-for="(item,index) in execAttachList" :key="index" class="tbody-row">
                            <td width="80%">
                                <span class="blue hand" @click="handleView(item.attachUrl)">{{item.attachName}}</span>
                            </td>
                            <td width="20%" style="text-align: right">
                                <span class="blue hand" @click="handleDel(item)" v-if="startButton">删除</span>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <template v-if="startButton">
                <div class="upload">
                    <input id="paymentFile'" name="paymentFile" type="file" multiple  @change="handlePaymentUpload($event)">
                    <label for="paymentFile'"><i class="el-icon-plus"></i>上传附件</label>
                </div>
                <!--<el-input style="margin: 10px 0;" type="textarea" v-model="comment" placeholder="请填写审批意见,300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>-->
                <!--<div class="count">-->
                <!--<span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300-->
                <!--</div>-->
            </template>
            <FixBottom v-if="fixedBottomActive">
                <div class="fix-bottom" v-if="">
                    <template v-if="startButton">
                        <el-button type="primary" style="width: 120px" @click="handleSettlementApproval('applyWf')">审批</el-button>
                        <el-button style="width: 120px" @click="handleSettlementApproval('update')">保存草稿</el-button>
                        <el-button  style="width: 120px" @click="closeApproavlDialogVisible = true">关闭</el-button>
                    </template>
                    <template v-if="canceledButton">
                        <el-button  style="width: 120px" @click="handleCancel">撤回</el-button>
                    </template>
                    <template v-if="approvalButton">
                        <el-button type="primary" style="width: 120px;" @click="batchApproavlDialogVisible=true">同意</el-button>
                        <el-button style="width: 120px;" @click="rejectedDialogVisible=true">退回</el-button>
                    </template>
                    <el-button  style="width: 120px" @click="handleCloseWindow()">返回列表</el-button>
                </div>
            </FixBottom>
        </template>
        <!-- <div class="order-status" v-if="showStatus"> -->

        <!-- 确认审批 -->
        <el-dialog class="dialog padding10Dialog" :title="'结算审批'" :append-to-body="true" :lock-scroll="true" :visible.sync="batchApproavlDialogVisible" width="840px" center :close-on-click-modal="false" :show-close="false"   @close="entryNum = 0;comment = ''">
            <div class="f14 form-btns">确认通过此结算审批吗？</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="comment" placeholder="请填写审批意见，300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm('Y')">同意</el-button>
                <el-button size="small" style="width: 100px" @click="batchApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--审批退回-->
        <el-dialog class="dialog padding10Dialog" title="退回原因" :append-to-body="true" :lock-scroll="true" :visible.sync="rejectedDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;rejectedReason = ''">
            <div class="f14 form-btns" style="text-align: left">请填写退回的原因</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="rejectedReason" placeholder="请填写退回的原因，300字以内" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" :disabled="!rejectedReason" size="small" style="width: 100px" @click="handleConfirm('N')">退回</el-button>
                <el-button size="small" style="width: 100px" @click="rejectedDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <!--关闭审批-->
        <el-dialog class="dialog padding10Dialog" :title="'关闭'" :append-to-body="true" :lock-scroll="true" :visible.sync="closeApproavlDialogVisible" width="840px" center :close-on-click-modal="false" @close="entryNum = 0;closeReason = ''">
            <div class="f14 form-btns" style="text-align: left;margin-bottom: 10px;">关闭后，将无法恢复本结算审批信息，确认关闭吗?</div>
            <div class="f14" style="text-align: left">请填写关闭原因：</div>
            <el-input style="margin: 20px 0;" type="textarea" class="textareaContainer" v-model="closeReason" :placeholder="'请填写关闭原因,300字以内'" clearable :maxlength="300" @input="handleEntry($event)"></el-input>
            <div class="count">
                <span :class="{'red':entryNum >= 300}"> {{entryNum}}</span>/ 300
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button :disabled="!closeReason" type="primary" size="small" style="width: 100px" @click="handleCloseConfirm()">提交关闭</el-button>
                <el-button size="small" style="width: 100px" @click="closeApproavlDialogVisible = false">取消</el-button>
            </div>
        </el-dialog>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
    import accountMixin from '@/mixins/account';
    import { InterfaceService } from "@/services/api";
    import PanelTitle from "@/components/base/PanelTitle";
    import FixBottom from "@/components/base/FixBottom";
    import Loading from "@/components/base/Loading";
    import { viewFile } from '@/utils/orderUtil';

    export default {
        mixins:[accountMixin],
        components: {
            PanelTitle,
            FixBottom,
            Loading,
        },
        props: ["errorRules","type","executionId", "settleInfo","topApproval"],
        data() {
            return {
                value: '',
                tabs:[
                    { label: "审批资料", index: 1, active: true }
                ],
                attach: {},
                approvalStatusDisp:"",
                rejectedReason:"",
                closeReason:"",
                comment:"",
                closeApproavlDialogVisible:false,
                batchApproavlDialogVisible:false,
                rejectedDialogVisible:false,
                isLoading:false,
                acctName:"",
                lastFailTm:"",
                operationType:"",
                approvalButton:false,
                fixedBottomActive:false,
                startButton:false,
                canceledButton:false,
                showCirculationOpinion:false,
                isOpenOptionCirculation:false,
                showStatus:false,
                approveFlowList:[],
                entryNum:0,
                execFlowList:[],
                execAttachList:[],
                isShowForward: false, // 是否显示 转发和打印
                showForwardTimer: null,
                procDefKey: '', // 合同状态 CONTRACT_APPROVE_WF": 审批 (审批流程), "CONTRACT_TERMINATE_WF": 合同终止()
            };
        },
        computed: {
            computedCirculationState() {
                return (item) => {
                    // item.isAgree === "Y" ? "审批意见" : "退回原因"
                    let result = {};
                    if (item.taskId === 'canceled') {
                        result.state = '审批撤回';
                        result.reason = '审批意见'
                    } else if (item.taskId === 'closed') {
                        result.state = '审批关闭';
                        result.reason = '关闭原因'
                    }else {
                        if (item.fwStatus == '1' || item.fwStatus == '2' ) {
                        result.state = item.fwStatus == '1' ? `转发${item.fwRoleName || ''}` : '批注'
                        result.reason =  item.fwStatus == '1' ? `转发内容` : '批注内容'
                        } else {
                            result.state = item.isAgree === "Y" ? "审批通过" : "审批退回"
                            result.reason = item.isAgree === "Y" ? "审批意见" : "退回原因"
                            result.isAgree = item.isAgree === "N"
                        }
                    }
                    return result
                }
            },
            computedExecFlowList() {
                return this.execFlowList.filter((item, idx) => {
                    /**
                     * 收缩情况下 只显示两条
                     */
                    if (!this.isOpenOptionCirculation) {
                        return idx <= 1
                    } else {
                        return true
                    }
                })
            }
        },
        watch: {
            settleInfo: {
                handler(newValue) {
                    this.init()
                },
                deep: true
            },
        },
        methods: {
             handleClose(done) {
                this.$confirm('确认关闭？')
                .then(_ => {
                    done();
                })
                .catch(_ => {});
            },
            //关闭窗口
            handleCloseWindow(){
                window.opener=null;
                window.close();
            },
            handleSettlementApproval(type) {
                console.log(this.errorRules);
                // if (this.settleInfo.outSettleInfoStatus === 'init') {
                 //     if (!this.settleInfo.erpContractAmount) {
                 //         this.$message.error("请填写合同金额（含税）！");
                 //         return
                 //     }
                 //     if (!this.settleInfo.erpSettleAmount) {
                 //         this.$message.error("请填写最终结算金额！");
                 //         return
                 //     }
                 // }else {
                 //     if (!this.settleInfo.outContractAmount) {
                 //         this.$message.error("请填写合同金额（含税）！");
                 //         return
                 //     }
                 //     if (!this.settleInfo.outSettleAmount) {
                 //         this.$message.error("请填写最终结算金额！");
                 //         return
                 //     }
                 // }
                let canSubmit = true;
                for (let i in this.errorRules) {
                    if (this.errorRules[i]) {
                        canSubmit = false
                    }
                }
                if (!canSubmit) {
                    this.$message.error("金额填写有误，请重新输入！");
                    return
                }
                 if (!this.execAttachList || !this.execAttachList.length) {
                     this.$message.error("请上传审批附件！");
                     return
                 }
                 this.submitSettlementInfo(type);
            },
            submitSettlementInfo(type) {
                 let params = {};
                 let date = new Date();
                 if (this.settleInfo.outContractAmount && !isNaN(this.settleInfo.outContractAmount)) {
                     params.outContractAmount = this.settleInfo.outContractAmount
                 }else {
                     params.outContractAmount = this.settleInfo.erpContractAmount
                 }
                if (this.settleInfo.outSettleAmount && !isNaN(this.settleInfo.outContractAmount)) {
                    params.outSettleAmount = this.settleInfo.outSettleAmount
                }else {
                    params.outSettleAmount = this.settleInfo.erpSettleAmount
                }
                if (this.settleInfo.outSettleRemark && this.settleInfo.outSettleRemark != 'null') {
                    params.outSettleRemark = this.settleInfo.outSettleRemark
                }else {
                    params.outSettleRemark = this.settleInfo.erpSettleRemark
                }
                 params.settleNo = this.settleInfo.settleNo;
                 params.outSettleDt =  this.dateFormat("YYYY-mm-dd", date);
                 params.processFlg = type;
                InterfaceService.submitSettlementInfo(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            if (type === "applyWf") {
                                this.batchApproavlDialogVisible = true
                            }else {
                                this.$emit("refresh");
                                this.$message.success("保存成功！")
                            }
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            dateFormat(fmt, date) {
                let ret;
                let opt = {
                    "Y+": date.getFullYear().toString(),        // 年
                    "m+": (date.getMonth() + 1).toString(),     // 月
                    "d+": date.getDate().toString(),            // 日
                    "H+": date.getHours().toString(),           // 时
                    "M+": date.getMinutes().toString(),         // 分
                    "S+": date.getSeconds().toString()          // 秒
                };
                for (let k in opt) {
                    ret = new RegExp("(" + k + ")").exec(fmt);
                    if (ret) {
                        fmt = fmt.replace(ret[1], (ret[1].length == 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, "0")))
                    };
                };
                return fmt;
            },
            handleDel(item){
                this.$confirm(
                    "删除后将无法恢复文件，确认删除吗?",
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认",
                        cancelButtonText: '取消',
                    }).then(() => {
                    this.confirmDel(item);
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            confirmDel(item) {
                let flowAttachIdList = [];
                flowAttachIdList.push(item.flowAttachId);
                const params = {
                    flowAttachIdList: flowAttachIdList
                };
                InterfaceService.approvalDataDel(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message({
                                type: 'success',
                                message: '删除成功!',
                            });
                            this.$emit("refresh","uploadFile")
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleConfirm(type){
                 if (!this.startButton) {
                     let executionList = [];
                     let comment ;
                     this.comment ? comment = this.comment : comment = "同意";
                     if (type == 'Y'){
                         executionList.push({
                             executionId: this.executionId,
                             isAgree: "Y",
                             comment:comment,
                             procDefKey: this.procDefKey,
                         })
                     }else if (type == 'N') {
                         executionList.push({
                             executionId: this.executionId,
                             isAgree: "N",
                             comment:this.rejectedReason,
                             procDefKey: this.procDefKey,
                         })
                     }
                     const params = {
                         executionList: executionList
                     };
                     InterfaceService.batchApprovalProcess(
                         params,
                         data => {
                             if (data.respCode === "0000") {
                                 console.log(data);
                                 if (data.respData.respList) {
                                     this.approvalResult = data.respData.respList;
                                     this.approvalResult.forEach(item=>{
                                         if (item.approveCode == "0000"){
                                             type == 'Y' ? this.$message.success("审批成功") : this.$message.success("退回操作完成");
                                             this.batchApproavlDialogVisible = false;
                                             this.rejectedDialogVisible = false;
                                             this.$emit("refresh")
                                         } else {
                                             this.$message.error(item.approveMsg);
                                         }
                                     });
                                 }else {
                                     this.$message.error(data.respData.respMsg);
                                 }
                             } else {
                                 this.$message.error(data.respData.respMsg);
                             }
                         },
                         data => {},
                         () => {
                             this.isLoading = true;
                         },
                         () => {
                             this.isLoading = false;
                         }
                     );
                 }else {
                     const params = {
                         procDefKey:this.procDefKey,
                         executionId:this.executionId,
                         comment:this.comment,
                     }
                     InterfaceService.startApprovalProcess(
                         params,
                         data => {
                             if (data.respData.respCode === "0000") {
                                 this.batchApproavlDialogVisible = false
                                 this.$message.success("审批操作成功！");
                                 this.$emit("refresh");
                             } else {
                                 this.$message.error(data.respData.respMsg);
                             }
                         },
                         data => {},
                         () => {
                             this.isLoading = true;
                         },
                         () => {
                             this.isLoading = false;
                         }
                     );
                 }
            },
            handleCloseConfirm(){
                let params = {};
                if (this.executionId) {
                    params = {
                        executionId : this.executionId,
                        procDefKey: this.procDefKey,
                        comment: this.closeReason,
                    };
                }
                InterfaceService.closeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("关闭成功");
                            this.closeApproavlDialogVisible = false;
                            this.$emit("refresh")
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handlePaymentUpload(e){
                const files = e.target.files;
                let upLoadList = [];
                for (let i in files) {
                    if (files[i].size) {
                        upLoadList.push({
                            attachName: files[i].name,
                            file: files[i]
                        });
                    }
                }
                e.value = "";
                this.getPaymentReceiptList(upLoadList).then(res => {
                    let attachList = res;
                    delete attachList[0].file
                    this.approvalDataAdd(attachList);
                });
                this.resetInputValue();
            },
            /**
             * 重置input value  防止 同一个文件连续提交 不触发 onchange事件
             */
            resetInputValue() {
                let isIE10 = false,
                    uploadInputs = document.getElementsByName('paymentFile') || []
                isIE10 = window.navigator.userAgent.indexOf('MSIE') >= 1;
                for (let i = 0, len = uploadInputs.length; i < len; i++) {
                    const element = uploadInputs[i];

                    if (isIE10) {
                        let form = document.createElement('form'),
                            beforInput = element.nextSibling,
                            parentInput = element.parentNode

                        form.appendChild(element)
                        form.reset()
                        parentInput.insertBefore(element, beforInput)
                    } else {
                        element.value = ''
                    }

                }
            },
            getPaymentReceiptList(upLoadList) {
                return new Promise((resolve, reject) => {
                    let arr = upLoadList;
                    this.uploadReciptToOss(arr).then(res => {
                        arr.forEach((item, index) => {
                            res.forEach(oss => {
                                if (index == oss.index) {
                                    item.attachUrl = oss.url;
                                }
                            });
                        });
                        resolve(arr);
                    });
                });
            },
            fillZero(val) {
                return val <= 9 ? "0" + val : val;
            },
            uploadReciptToOss(arr) {
                return new Promise((resolve, reject) => {
                    //去后端拿签名
                    InterfaceService.getOssSignature(
                        { type: "1" },
                        data => {
                            const promiseList = [];
                            arr.forEach((item, index) => {
                                const now = new Date();
                                const date = {
                                    y: now.getFullYear(),
                                    m: this.fillZero(now.getMonth() + 1),
                                    d: this.fillZero(now.getDate()),
                                    h: this.fillZero(now.getHours()),
                                    i: this.fillZero(now.getMinutes()),
                                    s: this.fillZero(now.getSeconds())
                                };
                                let dateStr = `${date.y}${date.m}${date.d}${
                                    date.h
                                    }${date.i}${date.s}`;
                                let dirName = `${
                                    this.orderNo
                                    }/approveFiles/${dateStr}/`;
                                const promise = new Promise(_resolve => {
                                    this.uploadHander(
                                        data,
                                        index,
                                        item.file,
                                        dirName,
                                        (pos, file, dir, signature) => {
                                            let u = signature.dir + dir + file.name;
                                            _resolve({ index: index, url: u });
                                        }
                                    );
                                });
                                promiseList.push(promise);
                            });
                            Promise.all(promiseList).then(values => {
                                resolve(values);
                            });
                        },
                        data => {}
                    );
                });
            },
            uploadHander(data, pos, file, dirName, callBack) {
                InterfaceService.uploadToOss(data, file, dirName, pos, callBack);
            },
            approvalDataAdd(attachList){
                const params = {
                    executionId: this.executionId ,
                    attachList:attachList,
                };
                InterfaceService.approvalDataAdd(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$emit("refresh","uploadFile")
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleEntry(ev){
                this.entryNum = ev.length
            },
            handleCancel() {
                this.$confirm(
                    "确认要撤回合同审批？撤回后的合同，在【待处理】中查看。",
                    {
                        cancelButtonClass: "btn-custom-cancel",
                        confirmButtonClass: "btn-custom-confirm",
                        center: true,
                        type: 'warning',
                        confirmButtonText: "确认撤回",
                        cancelButtonText: '取消',
                    }).then(() => {
                        this.handleCanceledConfirm()
                }).catch(() => {
                });
            },
            handleCanceledConfirm(){
                const params = {
                    executionId : this.executionId
                };
                InterfaceService.revokeApprovalProcess(
                    params,
                    data => {
                        if (data.respData.respCode === "0000") {
                            this.$message.success("撤回成功");
                            this.$emit("refresh")
                        } else {
                            this.$message.error(data.respData.respMsg);
                        }
                    },
                    data => {},
                    () => {
                        this.isLoading = true;
                    },
                    () => {
                        this.isLoading = false;
                    }
                );
            },
            handleView(url) {
                if (url) {
                  viewFile(url)
                }
            },
            handleBatchDownload() {
                if (this.executionId) {
                    const params = {
                        executionId: this.executionId,
                        procDefKey:this.procDefKey
                    };
                    InterfaceService.approvalDataDownload(
                        params,
                        data => {
                            if (data.respData.respCode === "0000") {
                                // window.opener.location.reload();
                                let packingUrl = data.respData.attachUrl || "";
                                if (!packingUrl){
                                    this.$message.error("暂无资料！");
                                    return
                                }
                                window.open(packingUrl, "_blank");
                            } else {
                                this.$message.error(data.respData.respMsg);
                            }
                        },
                        data => {},
                        () => {
                            this.isLoading = true;
                        },
                        () => {
                            this.isLoading = false;
                        }
                    )
                }
            },
            // 根据operateStatus传值判断 显示的按钮
            getOperateStatus(){
                this.startButton = false;
                this.approvalButton = false;
                this.canceledButton = false;
                let status = this.settleInfo.operateStatus;
                if (status == "start") {
                    this.startButton = true;
                }else if (status == "approve"){
                    this.approvalButton = true;
                }else if (status == "cancel") {
                    this.canceledButton = true
                }
            },
            onScroll(){
                let scrolled = document.documentElement.scrollTop || document.body.scrollTop;
                this.fixedBottomActive = scrolled >= 300;
            },
            init(){
                this.executionId = this.$props.executionId;
                this.procDefKey = 'SETTLE_APPROVE_WF';
                this.settleInfo = this.$props.settleInfo;
                this.applyFlg = this.$props.settleInfo.applyFlg
                this.approveFlowList = this.settleInfo.approveFlowList || [];
                this.execAttachList = this.settleInfo.execAttachList || [];
                this.execFlowList = this.settleInfo.execFlowList || [];
                let operation = this.execFlowList && this.execFlowList[0];
                this.showStatus = this.approveFlowList && this.approveFlowList.length > 0;
                if (this.execFlowList && this.execFlowList.length == 0) {
                    this.approveFlowList.forEach(item=>{
                        if (item.isCurrentNode == "1") {
                            this.approvalStatusDisp = item.flowName;
                        }
                    });
                    this.showCirculationOpinion = false;
                }else if (this.execFlowList && this.execFlowList.length > 0) {
                    this.showCirculationOpinion = true;
                    this.approveFlowList.forEach(item=>{
                        if (item.isCurrentNode == "1" && item.step == "1"){
                            this.lastFailTm = this.execFlowList[0].finishTm;
                            if (operation.isAgree == "N" && operation.taskId == "operation_confirm") {
                                this.approvalStatusDisp = "工程部退回";
                                this.operationType = "退回时间";
                            }else if (operation.isAgree == "N" && operation.taskId == "finance_confirm") {
                                this.approvalStatusDisp = "财务部退回";
                                this.operationType = "退回时间";
                            }else if (operation.isAgree == "N" && operation.taskId == "vgm_confirm") {
                                this.approvalStatusDisp = "副总经理退回";
                                this.operationType = "退回时间";
                            } else if (operation.isAgree == "N" && operation.taskId == "contract_confirm") {
                                this.approvalStatusDisp = "招采部负责人退回";
                                this.operationType = "退回时间";
                            } else if (operation.taskId == "canceled") {
                                this.approvalStatusDisp = "招采合约部结算负责人已撤回审批";
                                this.operationType = "撤回时间";
                            } else if (operation.taskId == "contract_apply" || operation.taskId == "closed") {
                                this.approvalStatusDisp = "招采合约部结算负责人审批";
                                this.lastFailTm = "";
                            }
                        } else if (item.isCurrentNode == "1" && item.step != "1") {
                            this.approvalStatusDisp = item.flowName;
                            this.lastFailTm = "";
                        }
                    });
                }
                this.$nextTick(function () {
                    window.addEventListener('scroll', this.onScroll)
                });
                this.getOperateStatus()
            },
            /**
             * 展开收缩 - 流转意见
             */
            handleClickOptionCirculation() {
                this.isOpenOptionCirculation = ! this.isOpenOptionCirculation
            },
            /**
             * 是否展示 转发 和 打印
             * @param state true: 是, fasle: 否
             */
            showForward(state = false) {
                if (state) {
                    clearTimeout(this.showForwardTimer)
                }
                this.showForwardTimer = setTimeout(e => this.isShowForward = state, 50)
            },

            /**
             * 转发 和 打印 点击
             * @param state 1: 转发, 2: 打印
             */
            handleClickForward(state) {
                this.forwardSelectValue = [];
                this.forwardContenr = '';
                switch(state) {
                    case 1:
                        break
                    case 2:
                        console.log(123)
                        this.$emit('handleClickPrint')
                        break
                }
            },

        },
        mounted() {
            // this.init()
        },
        destroyed(){
            window.removeEventListener('scroll', this.onScroll)
        }
    };
</script>
<style lang="scss" scoped>
    .order-status {
        position: relative;
        height: 120px;
        margin: 0 0 20px;
        padding: 40px 20px 40px 80px;
        border: 1px solid #fddd74;
        background: url("../../../assets/images/order-detail-bg.jpg") no-repeat;
        background-size: 100% 100%;
    }
    .status-null {
        height: 30px;
    }
    .status-info {
        display: flex;
        justify-content: space-between;
        height: 100%;
        line-height: 25px;
    }

    .status-info-content {
        display: flex;
        justify-content: center;
        align-content: center;
        font-size: 14px;
        em{
            color: #444;
        }
        label {
            color: #888888;
        }

        a {
            color: #0082ff;
        }

        button {
            align-self: center;
        }
        & > div {
            display: inline-block;
            align-self: center;
        }

        .big {
            font-size: 18px;
            color: #333;
        }
        .confirm{
            position: absolute;
            right: 20px;
            bottom: 35px;
        }
        .operation{
            position: absolute;
            right: 60px;
            bottom: 35px;
        }
        .right20{
            right: 20px;
        }
        .right55{
            right: 55px;
        }
        .rejected-title{
            top: 34px;
            color: #bbb;
            display: inline-block;
            position: absolute;
            height: 70px;
            width: 900px;
            overflow-y: auto;
            word-wrap:break-word
        }
        // 转发
        .forward-container {
            position: absolute;
            right: 20px;
            top: 60px;
            &>i {
                background: url(../../../assets/images/forward-icon.png) no-repeat;
                cursor: pointer;
                display: block;
                width: 24px;
                height: 17px;
                padding-bottom: 32px;
            }
            ul {
                background: #fff;
                box-shadow: 0px 0px 12px #cacaca;
                border-radius: 2px;
                position: absolute;
                z-index: 1;
                margin-left: -72px;
                margin-top: 5px;
                padding-bottom: 22px;
                transition: all 3s linear;
                &::before {
                    content: '';
                    border-style: solid;
                    border-width: 10px;
                    border-color: transparent transparent #fff #fff;
                    box-shadow: -4px 7px 6px #eaeaea;
                    position: absolute;
                    transform: rotate(-223deg);
                    margin-top: -7px;
                    margin-left: 73px;
                }
                li {
                    display: flex;
                    align-items: center;
                    font-weight: bold;
                    cursor: pointer;
                    width: 130px;
                    padding: 22px 34px 0;
                    &.printing {
                        i {
                            background: url(../../../assets/images/printing-icon.png) no-repeat;
                        }
                    }
                    &.save {
                        i {
                            background: url(../../../assets/images/save-icon.png) no-repeat;
                        }
                    }

                    i {
                        background: url(../../../assets/images/printing-icon.png) no-repeat;
                        display: inline-block;
                        width: 15px;
                        height: 15px;
                        margin-right: 8px;
                    }
                }
            }
        }
    }
    /deep/ .el-button{
        height: 32px;
        width: 100px;
        padding: 0;
        span{
            text-align: center;
        }
    }
    /deep/ .el-dialog__header:before {
        height: 0;
    }
    .line-top{
        width: 95%;
        height: 1px;
        background: #eee;
        position: absolute;
        top:65px;
    }
    .form-btns {
        text-align: center;
    }
    .count{
        float: right;
        width: 100%;
        text-align: right;
        margin-bottom: 20px;
        span.red{
            color: #f00;
        }
    }
    .forward-dialog-container {
        padding-bottom: 30px;
        ::-webkit-scrollbar {
            width: 1px !important;
        }
        ::-webkit-scrollbar-button {
            height: 0;
        }
        /deep/ .el-select__tags {
            max-height: 85px;
            overflow: auto;
        }
        .head {
            display: flex;
            align-items: center;
            span {
                width: 10%;
            }
            /deep/ .el-select {
                width: 80%;
            }
            /deep/ input:focus {
                border: 0 !important;
            }
        }
        .body {
            margin-top: 22px;
            position: relative;
            /deep/ .el-textarea .el-textarea__inner {
                resize: none;
                width: 100%;
                height: 140px !important;
            }
            span {
                position: absolute;
                right: 9px;
                bottom: 6px;
            }
        }
        .foot {
            display: flex;
            justify-content: center;
            margin-top: 32px;
        }
    }

    // 流转意见
    .circulation-opinion-container {
        border: 1px solid #fddd74;
        padding: 20px;
        position: relative;
        margin-bottom: 22px;
        &.openOption {
            .option-circulation {
                &::after {
                    border-color: #0082ff #0082ff transparent transparent;
                    transform: rotate(-45deg);
                }
            }
        }
        .option-circulation {
            position: absolute;
            right: 16px;
            top: 21px;
            color: #0082ff;
            font-size: 12px;
            cursor: pointer;
            &::after {
                content: '';
                border-width: 3px;
                border-style: solid;
                display: inline-block;
                margin-left: 2px;
                border-color: #0082ff #0082ff transparent transparent;
                transform: rotate(135deg) translate(-3px, 1px);
            }
        }
        .center {
            display: flex;
            flex-direction: column;
            cursor: context-menu;
            .head-title {
                color: #444;
                font-size: 14px;
            }
            .center-option-circulation {
                width: 100%;
                height: 22px;
                position: relative;
                border-top: 1px solid #eeeeee;
                i {
                    left: 50%;
                    top: 17px;
                }
            }
            ul {
                margin-top: 12px;
                display: flex;
                flex-direction: column;
                min-height: 100px;
                &.isOpenOptionCirculation {
                    overflow: hidden;
                    height: 200px;
                    dd {
                        height: 40px;
                        display: -webkit-box;
                        -webkit-box-orient: vertical;
                        -webkit-line-clamp: 2;
                        overflow: hidden;
                    }
                }
                &.one{
                    height: auto;
                }
                li {
                    padding: 20px 40px;
                    border-top: 1px solid #eeeeee;
                    display: flex;
                    position: relative;
                    &:last-child {
                        padding-bottom: 0;
                    }
                    &.isAgree {
                        dl {
                            &:nth-child(2), &:nth-child(3) {
                                dt {
                                    color: #e9171d;
                                }
                            }
                        }
                    }
                    dl {
                        color: #444;
                        font-size: 14px;
                        width: 20%;
                        &:nth-child(2) {
                            width: 20%;
                        }
                        &:nth-child(3) {
                            width: 60%;
                        }
                        .color888888 {
                            color: #888;
                            font-size: 12px;
                        }
                        .colore9171d {
                            color:  #e9171d;
                        }
                        dt {
                            margin-bottom: 6px;
                            font-weight: bold;
                        }
                        dd {
                            line-height: 22px;
                            word-wrap: break-word;
                        }
                    }
                    .option-circulation {
                        left: 50%;
                        top: 16px;
                    }
                }
            }
        }
    }
    /deep/.textareaContainer {
       .el-textarea__inner {
           min-height: 140px !important;
       }
    }
    /deep/.padding10Dialog {
        .form-btns {
            padding: 16px 0;
            border-top: 1px solid #eee;
        }
        .el-dialog__header {
            padding-top: 22px !important;
        }
        .el-textarea {
            margin: 10px 0 !important;
        }
    }
    .info {
        color: #888888;
    }
    .dialog {
        line-height: 25px;
    }
    .data-content{
        position: relative;
        max-height: 330px;
        overflow-y: auto;
        table {
            table-layout: fixed;
            width: 100%;
            line-height: 23px;
            font-size: 12px;
            display: table;
            background: #f5f8f9;

            td,th {
                padding: 6px 10px;
                vertical-align: middle;
                word-break: break-word;
                text-align: left;
            }
            .head {
                font-size: 14px;
                text-align: left;
                white-space: nowrap;
                color: #909399;
                background: #f5f5f5;
                border-bottom: 1px solid #fff;
            }
            .tbody-row:hover {
                background: #e8f3fd;
            }
            tbody {
                text-align: center;
                display: block;
                width: 100%;
                tr {
                    display: table;
                    width: 100%;
                    table-layout: fixed;
                }
                td {
                    border-bottom: 1px solid #ebeef5;
                }
            }
        }

    }
    .upload {
        width: 100%;
        height: 40px;
        line-height: 40px;
        background: #f5f5f5;
        border-top: 2px solid #fff;
        margin: 0 auto 20px;
        text-align: center;
        input {
            position: absolute;
            left: -9999px;
            width: 0px;
            height: 0px;
            overflow: hidden;
            opacity: 0;
        }

        label {
            cursor: pointer;
            color: #0082ff;
        }
    }
    /deep/ .el-dialog__body{
        padding-bottom: 0;
    }
    /deep/ .el-dialog__footer{
        padding-top: 0;
    }
    /deep/ .el-button{
        width: 100px;
    }
    .dialog-footer {
        margin: 20px auto 0;
    }
    .fix-bottom{
        width: 100%;
        margin: 0 auto;
        text-align: center;
    }
    .download{
        position: absolute;
        right: 10px;
        top: 19px;
    }
    // 流转意见
    .circulation-opinion-container {
        border: 1px solid #fddd74;
        padding: 20px;
        position: relative;
        margin-bottom: 22px;
        &.openOption {
            .option-circulation {
                &::after {
                    border-color: #0082ff #0082ff transparent transparent;
                    transform: rotate(-45deg);
                }
            }
        }
        .option-circulation {
            position: absolute;
            right: 16px;
            top: 21px;
            color: #0082ff;
            font-size: 12px;
            cursor: pointer;
            &::after {
                content: '';
                border-width: 3px;
                border-style: solid;
                display: inline-block;
                margin-left: 2px;
                border-color: #0082ff #0082ff transparent transparent;
                transform: rotate(135deg) translate(-3px, 1px);
            }
        }
        .center {
            display: flex;
            flex-direction: column;
            cursor: context-menu;
            .head-title {
                color: #444;
                font-size: 14px;
            }
            .center-option-circulation {
                width: 100%;
                height: 22px;
                position: relative;
                border-top: 1px solid #eeeeee;
                i {
                    left: 50%;
                    top: 17px;
                }
            }
            ul {
                margin-top: 12px;
                display: flex;
                flex-direction: column;
                min-height: 100px;
                &.isOpenOptionCirculation {
                    overflow: hidden;
                    height: 200px;
                    dd {
                        height: 40px;
                        display: -webkit-box;
                        -webkit-box-orient: vertical;
                        -webkit-line-clamp: 2;
                        overflow: hidden;
                    }
                }
                &.one{
                    height: auto;
                }
                li {
                    padding: 20px 40px;
                    border-top: 1px solid #eeeeee;
                    display: flex;
                    position: relative;
                    &:last-child {
                        padding-bottom: 0;
                    }
                    &.isAgree {
                        dl {
                            &:nth-child(2), &:nth-child(3) {
                                dt {
                                    color: #e9171d;
                                }
                            }
                        }
                    }
                    dl {
                        color: #444;
                        font-size: 14px;
                        width: 20%;
                        &:nth-child(2) {
                            width: 20%;
                        }
                        &:nth-child(3) {
                            width: 60%;
                        }
                        .color888888 {
                            color: #888;
                            font-size: 12px;
                        }
                        .colore9171d {
                            color:  #e9171d;
                        }
                        dt {
                            margin-bottom: 6px;
                            font-weight: bold;
                        }
                        dd {
                            line-height: 22px;
                            word-wrap: break-word;
                        }
                    }
                    .option-circulation {
                        left: 50%;
                        top: 16px;
                    }
                }
            }
        }
    }
</style>


