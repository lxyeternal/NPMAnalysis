<template>
    <div class="process-conent" v-if="list.length">
        <el-steps :active="processActive" align-center :class="{'dark-steps':abnormalContract}">
            <el-step v-for="(item,index) in list" :key="index" :class="{'big':isBigNode(item)}">
                <div slot="description" class="process-desc">
                    <p>{{item.flowName}}</p>
                    <p class="grey" v-if="isApproval && item.finishTime">{{item.finishTime}}</p>
                </div>
            </el-step>
        </el-steps>
    </div>
</template>

<script>
export default {
    props: ["orderStatus", "processList","isApproval"],
    data() {
        return {
            list: []
        };
    },
    computed: {
        processActive() {
            let index = 0;
            if (this.abnormalContract) return 0;
            this.list.forEach((item, i) => {
                if (item.isCurrentNode == "1") {
                    index = i;
                }
            });
            return index + 1;
        },
        abnormalContract() {
            return (
                this.orderStatus === "02" ||
                this.orderStatus === "04" ||
                this.orderStatus === "14"
            );
        }
    },
    watch: {
        processList() {
            this.init();
        }
    },
    methods: {
        isBigNode(item) {
            return (
                item.isCurrentNode == "1" &&
                this.processActive !== this.list.length
            );
        },
        init() {
            this.list = this.$clone(this.processList);
            this.list.sort((a, b) => {
                return a.step - b.step;
            });
        }
    },
    mounted() {
        this.init();
        console.log(this.isApproval);
    }
};
</script>

<style lang="scss" scoped>
$unfinish-color: #dddddd;
$finish-color: #ffd64e;
$empha-color: #f87a31;
$dark-color: #000;

// ie兼容
.el-step {
    width: 50%;
}

.el-step:last-child {
    max-width: none !important;
}

/deep/ .el-step__line {
    background-color: $unfinish-color;
}

/deep/ .el-step__head.is-process,
/deep/ .el-step__head.is-wait {
    border-color: $unfinish-color;
    color: #ffffff;

    .el-step__icon.is-text {
        background-color: $unfinish-color;
    }
}

/deep/ .el-step__head.is-finish {
    border-color: $finish-color;
    color: #ffffff;

    .el-step__icon.is-text {
        background-color: $finish-color;
    }
}

.big {
    /deep/ .el-step__head.is-finish {
        border-color: $empha-color;
        .el-step__icon.is-text {
            background-color: $empha-color;
            transform: scale(1.3);
        }
    }
}

.dark-steps {
    /deep/ .el-step__head.is-process,
    /deep/ .el-step__head.is-wait,
    /deep/ .el-step__head.is-finish {
        border-color: $dark-color;
        color: #ffffff;

        .el-step__icon.is-text {
            background-color: $dark-color;
        }
    }
}

.process-conent {
    padding: 40px 20px;
}

.process-desc {
    margin-top: 20px;
    font-size: 14px;
    color: #444444;
}
</style>
