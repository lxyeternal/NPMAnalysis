<template>
    <div>
        <!-- 取消合同 -->
        <el-dialog class="dialog" title="温馨提示" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="800px" center :close-on-click-modal="false">
            <div>
                <p>申报信息修改功能尚未正式开放，若信息有争议需要修改，或需要添加备注信息，请在与供应商达成一致后，联系客服，为您修改。</p>
                <p>客服电话：{{$platformContact()['hotLine']}} {{$platformContact()['hotLineTime']}}</p>
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="dialogVisible = false">确认</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
export default {
    data() {
        return {
            dialogVisible: false
        };
    },
    methods: {
        open(data) {
            this.dialogVisible = true;
        }
    }
};
</script>

<style lang="scss" scoped>
.dialog {
    line-height: 25px;
}
</style>
