<template>
    <div>
        <!-- 发货通知 -->
        <el-dialog class="dialog" title="发送发货通知" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="830px" center :close-on-click-modal="false">
            <div>
                通知采购商："已备货完毕，准备发货，到货时间预计于
                <!--<el-input :value="order.requireTimeFrom|datetime" disabled></el-input>~-->
                <!--<el-input :value="order.requireTimeTo|datetime" disabled></el-input>-->
                <span class="red">{{order.requireTimeFrom}}</span>~<span class="red">{{order.requireTimeTo && order.requireTimeTo.substring(11,order.requireTimeTo.length)}}</span>
                将货物送到指定地点。请确认是否发货？"
            </div>
            <div slot="footer" class="dialog-footer">
                <el-button type="primary" size="small" style="width: 100px" @click="handleConfirm">确认发送</el-button>
                <el-button size="small" style="width: 100px" @click="dialogVisible = false">取消</el-button>
            </div>
        </el-dialog>

        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import Loading from "@/components/base/Loading";
import { InterfaceService } from "@/services/api";
export default {
    components: {
        Loading
    },
    data() {
        return {
            isLoading: false,
            dialogVisible: false,
            order: {},
        };
    },
    methods: {
        open(data) {
            this.order = data;
            this.dialogVisible = true;
        },
        handleConfirm() {
            this.sendOrder();
        },
        sendOrder() {
            const params = {
                requireNo: this.order.requireNo
            };
            InterfaceService.requireOrderSendNotice(
                params,
                data => {
                    let res = data.respData;
                    if (res.respCode === "0000") {
                        this.dialogVisible = false;
                        this.$message.success('发送成功！')
                        this.$emit("close", true);
                    }
                },
                data => {
                    this.$message.error(data.respData && data.respData.respMsg);
                },
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-input{
    width: 180px;
}
.info {
    color: #888888;
}
.dialog {
    line-height: 25px;
}
</style>
