<template>
  <div v-if="dialogVisible">
    <el-dialog class="dialog" title="提问" :append-to-body="true" :lock-scroll="true" :visible.sync="dialogVisible" width="840px" center :close-on-click-modal="false" @close="handleClose">
      <div class="tip">若想所提问题能得到有效答复，<span class="red">请将问题逐条编辑并发布提问</span>。</div>
      <el-form class="questionForm" ref="questionForm" :model="questionForm" :rules="rules"  label-width="100px" size="small" >
        <el-form-item label="主题：" prop="qaTheme">
          <el-input type="text" clearable v-model="questionForm.qaTheme"  placeholder="请输入主题，限60字" maxlength="60"></el-input>
        </el-form-item>
        <el-form-item label="问题分类：" prop="qaClassify" style="text-align: left">
          <el-select placeholder="请选择" v-model="questionForm.qaClassify">
            <el-option v-for="(item,index) in QAClassifyList.filter(i=>{return i.code != 'NOTICE'})" :key="index" :value="item.code" :label="item.value"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="描述内容：" prop="qaTheme" >
          <el-input class="resize-none" type="textarea" v-model="questionForm.qaDescription" :rows="4" placeholder="请输入..." maxlength="200" show-word-limit></el-input>
        </el-form-item>
        <el-form-item ref="enclosureForm" label-width="0" class="upload tl" >
          <b class="f14" style="color: #444;margin-right: 6px;">该问题的补充说明附件</b>
          <input :id="'others'" type="file" @change="handleUpload($event)">
          <label style="position:absolute;top: 7px;" class="hand blue f12" :for="'others'">上传</label>
          <div class="enclosure-content" style="margin-top: 0;" v-if="questionForm.qaAttachInfoList.filter(i=>{return !i.del}).length">
            <div v-for="(item,index) in questionForm.qaAttachInfoList.filter(i=>{return !i.del})">
              <span>{{item.attachName}}</span>
              <span class="hand blue" @click="handleView(item.url)">预览</span>
              <span class="hand blue" @click="handleDownload(item.url,item.attachName)">下载</span>
              <span class="hand blue" @click="handleDel(item)">删除</span>
            </div>
          </div>
          <div v-else class="grey enclosure-content">
            未上传附件！
          </div>
        </el-form-item>
      </el-form>
      <div class="tc btn-content">
        <el-button type="primary" class="normal-btn" @click="handleSubmit(1)">确认发布</el-button>
        <el-button class="normal-btn" @click="handleSubmit(0)">保存</el-button>
        <el-button class="normal-btn" @click="handleClose">取消</el-button>
      </div>
    </el-dialog>
    <Loading :is-loading="isLoading"></Loading>
  </div>

</template>

<script>
  import Loading from "@/components/base/Loading";
  import { InterfaceService } from "@/services/api";
  import { viewFile } from '@/utils/orderUtil';

  const form = {
    bidNo:"",
    bidQaNo:"",
    qaTheme:"",
    qaClassify:"",
    qaDescription:"",
    qaAttachInfoList:[],
  };
  export default {
    name: "putQuestion",
    components:{
      Loading,
    },
    data() {
      return {
        dialogVisible:false,
        isLoading:false,
        type:"",
        QAClassifyList:[],
        questionForm:JSON.parse(JSON.stringify (form)),
        rules:{
          qaClassify:[{
            required : true,
            message: "必填",
            trigger: "change"
          }],
          qaTheme:[{
            required : true,
            message: "必填",
            trigger: "blur"
          }],
          qaDescription:[{
            required : true,
            message: "必填",
            trigger: "blur"
          }],
        },
      }
    },
    methods:{
      handleView(url) {
        viewFile(url)
      },
      handleDownload(url,name) {
        let attach = [];
        attach.push({
          url :url,
          name : name
        });
        this.$download(attach).then(res=>{
          this.$message.success("已下载");
        }).catch(res=>{
          this.$message.error("下载失败");
        })
      },
      handleUpload(e) {
        const file = e.target.files[0];
        if (file) {
          // if (file.size > 20971520) {
          //   this.$message.error("单个附件大小不超过20MB");
          //   return;
          // }
          this.uploadContractToOss('11',file).then(res => {
            let param = {
              ossFile: [{
                fileType: "11", filePath: res.url
              }],
              appName: "PROD"
            };
            InterfaceService.ossSignatureUrl(param, data => {
              if (data && data.respData && data.respData.respCode === "0000") {
                let list =  data.respData.ossFile || [];
                console.log(list);
                if (list.length) {
                  this.questionForm.qaAttachInfoList.push({
                    attachName:file.name,
                    attachPath:res.url,
                    url:list[0].url,
                    del : false
                  })
                }
                this.$refs['enclosureForm'] && this.$refs['enclosureForm'].clearValidate()
              } else {
                this.$message.error(data.respData.respMsg)
              }
            }, data => { }, () => { this.isLoading = true }, () => { this.isLoading = false })
          })
          e.value = "";
        }
      },
      uploadContractToOss(type,file) {
        return new Promise((resolve, reject) => {
          InterfaceService.getOssSignatureDisposable(file.name,{
              type:type,
              appName:"PROD",
            }, (data) => {
              let signature = data;
              this.uploadHander(0, file, new Date().getTime() + '/',signature, (pos, file, dirType, signature) => {
                let u = signature.dir + dirType+ file.name;
                resolve({url: u });
                //图片上传到oss之后 提交注册信息
                // setTimeout(() => {
                //   this.isReject ? this.isRejectSubmigCompelet() : this.submitCompelet()
                // }, 800)
              },() => { this.isLoading = true; }, () => { this.isLoading = false; })
            }, (data) => {
            },
            () => {
              this.isLoading = true;
            },
            () => {
              this.isLoading = false;
            });
        })

      },
      uploadHander(pos, file, dirType, signature, callBack, loadingStartCb, loadingEndCb) {
        //去后端拿签名
        InterfaceService.uploadToOss(signature, file, dirType, pos, callBack, '', '', loadingStartCb, loadingEndCb)
      },
      handleClose() {
        this.dialogVisible = false
        this.questionForm = JSON.parse(JSON.stringify (form));
      },
      handleDel(item){
        this.$set(item,'del',true);
        this.$forceUpdate()
        console.log(item);
      },
      handleSubmit(operationType){
        this.$refs.questionForm.validate((valid) => {
          if (valid) {
            if (operationType == 1) {
              this.$confirm(
                "确认已完善提问信息及附件，并提问吗？",
                "确认提问",
                {
                  cancelButtonClass: "btn-custom-cancel",
                  confirmButtonClass: "btn-custom-confirm",
                  center:true,
                  confirmButtonText: "确认",
                  cancelButtonText: '取消',
                }).then(() => {
                  this.submit(operationType)
              }).catch(() => {
              });
            }else {
              this.submit(operationType)
            }
          }
        })
      },
      submit(operationType) {
        // let params = Object.assign({},this.questionForm);
        let params = JSON.parse(JSON.stringify (this.questionForm));
        params.handleType = operationType;
        params.qaAttachInfoList = [];
        if (this.questionForm.qaAttachInfoList.length) {
          this.questionForm.qaAttachInfoList.forEach(item=>{
            if (item.ossFileId) {
              if (item.del) {
                params.qaAttachInfoList.push({
                  ossFileId: item.ossFileId
                })
              }
            } else {
              if (!item.del) {
                params.qaAttachInfoList.push(item)
              }
            }
            delete item.url
          })
        }
        InterfaceService[this.type == "edit" ? 'getSupplierQustionEdit':'supplierCreateQuestion'](params, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              if (this.type !='edit') {
                this.$message.success(operationType == 1 ? "提问成功！" : "保存成功！");
                this.handleClose();
                this.$emit('refresh',operationType)
              } else {
                if (operationType == 1) {
                  this.supplierQustionOperation(operationType);
                }else {
                  this.handleClose();
                  this.$emit('refresh',operationType)
                  this.$message.success("保存成功！");
                }
              }
            } else {
              this.$message.error(data.respData.respMsg)
            }
          },
          data => { },
          () => { this.isLoading = true },
          () => { this.isLoading = false })
      },
      supplierQustionOperation(operationType){
        let bidQaNos = [];
        bidQaNos.push(this.questionForm.bidQaNo)
        let params = {
          bidQaNos,
          handleType:"1"
        };
        InterfaceService.supplierQustionOperation(params, data => {
            if (data && data.respData && data.respData.respCode === "0000") {
              this.$message.success("提问成功！")
              this.handleClose();
              this.$emit('refresh',operationType)
            } else {
              this.$message.error(data.respData.respMsg)
            }
          },
          data => { },
          () => { this.isLoading = true },
          () => { this.isLoading = false })
      },
      getSupplierQustionDetail(){
        InterfaceService.getSupplierQustionDetail({
          bidQaNo:this.questionForm.bidQaNo
        }, data => {
          if (data && data.respData && data.respData.respCode === "0000") {
            let res = data.respData || {};
            this.questionForm.qaTheme = res.qaTheme || "";
            this.questionForm.qaClassify = res.qaClassify || "";
            this.questionForm.qaDescription = res.qaDescription || "";
            this.questionForm.qaAttachInfoList = res.qaAttachInfoList || [];
            if (this.questionForm.qaAttachInfoList.length) {
              this.questionForm.qaAttachInfoList.forEach(item=>{
                item.url = item.attachUrl;
                item.del = false;
              })
            }
          } else {
            this.$message.error(data.respData.respMsg)
          }
        },
        data => { },
        () => { this.isLoading = true },
        () => { this.isLoading = false })
      },
      open(type,bidNo,bidQaNo,QAClassifyList) {
        this.dialogVisible = true;
        this.QAClassifyList = QAClassifyList || []
        this.questionForm.bidNo = bidNo || "";
        this.questionForm.bidQaNo = bidQaNo || "";
        this.type = type || "";
        if (this.type == "edit" && this.questionForm.bidQaNo) {
          this.getSupplierQustionDetail();
        }
      }
    }
  }
</script>

<style scoped lang="scss">
  .resize-none{
    /deep/ .el-textarea__inner{
      resize: none;
      overflow: auto;
    }
  }
  .questionForm{
    font-size: 12px;
    color: #888;
  }
  .enclosure-content{
    margin-top: 0;
    font-size: 12px;
    width:100%;
    border:1px solid rgba(221,221,221,1);
    padding: 8px 10px;
    line-height: 25px;
    span{
      margin-right: 12px;
    }
  }
  .btn-content{
    margin-top: 20px;
    margin-bottom: 10px;
  }
  .upload{
    /deep/ .el-input,input {
      position: absolute;
      left: -9999px;
      width: 0px;
      height: 0px;
      overflow: hidden;
      opacity: 0;
    }
  }
  /deep/ .el-form-item__content{
    text-align: left;
  }
  .tip{
    width: 100%;
    text-align: center;
    margin-bottom: 14px;
  }
</style>