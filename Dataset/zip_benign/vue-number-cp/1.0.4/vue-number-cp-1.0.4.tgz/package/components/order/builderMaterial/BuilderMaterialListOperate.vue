<template>
    <div class="operate">
        <p v-if="allowRequire()">
            <el-button type="primary" size="mini" @click="handleLaunchGoods">发起要货</el-button>
        </p>
        <p>
            <a @click="handleViewDetail">查看施工要料单详情</a>
        </p>
        <p>
            <a @click="handleDownload">下载要料单</a>
        </p>
        <p v-if="material.applyStatus==='APPLY'">
            <a @click="handleDelete">删除</a>
        </p>
        <!-- 删除提示 -->
        <MaterialDelDialog ref="delMaterial" @close="handleCloseDel"></MaterialDelDialog>
        <Loading :is-loading="isLoading"></Loading>
    </div>
</template>

<script>
import accountMixin from "@/mixins/account";
import Loading from "@/components/base/Loading";
import MaterialDelDialog from "@/components/order/builderMaterial/MaterialDeleteDialog";
import { InterfaceService } from "@/services/api";
export default {
    mixins: [accountMixin],
    components: {
        Loading,
        MaterialDelDialog
    },
    props: ["material"],
    data() {
        return {
            isLoading: false
        };
    },
    methods: {
        handleLaunchGoods() {
            this.$router.push({
                path: "/builderMaterialConfirm",
                query: {
                    applyNo: this.material.applyNo
                }
            });
        },
        handleViewDetail() {
            this.$router.push({
                path: "/builderMaterialDetail",
                query: {
                    applyNo: this.material.applyNo
                }
            });
        },
        handleDelete() {
            this.$refs["delMaterial"].open();
        },
        handleCloseDel(bool) {
            if (bool) {
                this.delMaterial();
            }
        },
        handleDownload() {
            if (!this.material.attachUrl) return;
            let name = this.material.attachUrl.split("?")[0];
            name = name.split("/").pop();
            const files = [
                { name: decodeURIComponent(name), url: this.material.attachUrl }
            ];
            this.$download(files).then(() => {
                this.$message.success("已下载");
            });
        },
        // 是否允许要货
        allowRequire() {
            return !this.brokerRole && this.material.applyStatus!=='TOTAL_SUBMIT';
        },
        delMaterial() {
            const params = {
                applyList: [
                    {
                        applyNo: this.material.applyNo,
                        applyStatus: "DELETE"
                    }
                ]
            };
            InterfaceService.updateBuilderMaterial(
                params,
                data => {
                    if (data.respData.respCode === "0000") {
                        this.$emit("refresh");
                    } else {
                        this.$message.error(data.respData.respMsg);
                    }
                },
                data => {},
                () => {
                    this.isLoading = true;
                },
                () => {
                    this.isLoading = false;
                }
            );
        }
    }
};
</script>

<style lang="scss" scoped>
/deep/ .el-button {
    margin-bottom: 5px;
}

.operate {
    a {
        display: block;
        white-space: nowrap;
        padding: 5px 5px 0 5px;
        line-height: 18px;
        color: #0082ff;
    }
}
</style>
