<template>
  <div class="quickbuy-add require-list">
    <div class="table" :class="{fixedSearchActive: fixedSearchActive,'mb80':isConfirm}">
      <div class="fixedSearchActiveBg" v-if="fixedSearchActive && !isView"></div>
      <table>
        <thead :class="{isViewTitle : isView}">
          <tr>
            <td width="50" v-if="!isView"></td>
            <td width="260">商品名/规格</td>
            <td width="124">剩余可要货数量</td>
            <!--<td width="56" v-if="isConfirm">&nbsp;</td>-->
            <td width="114" v-if="isConfirm">填写要货数量</td>
            <td width="170" v-if="!isConfirm">填写要货数量</td>
            <!--<td width="56" v-if="isConfirm">&nbsp;</td>-->
            <!--<td>单位</td>-->
            <td width="265">使用标段或部位</td>
            <td width="265">备注</td>
            <td width="50" v-if="!isView">操作</td>
          </tr>
        </thead>
        <!--<tbody v-show="showP" class="no-quickbuy-add-list">没有找到已选定的商品</tbody>-->
        <tbody>
          <tr v-for="(item,index) in orderList" :key="index" :class="{'choosed':item.choosed,'disable':item.requireLeft==0}">
            <td width="50" v-if="!isView">
              <el-checkbox v-model="item.checked" @change="handleSelectRow(item,index)"></el-checkbox>
            </td>
            <td width="260">
              <div class="order-name">
                <div class="left">
                  <img :src="item.attachpicUrl" v-error-img v-if="!isView">
                  <span v-else>{{index + 1}}</span>
                </div>
                <div class="right">
                  <p class="go-blue" @click="goProduct(item.spuId,index)">{{ item.skuName }}</p>
                  <p>型号：{{item.model}}</p>
                </div>
              </div>
            </td>
            <!--<td width="124" class="tr">{{compRequireLeftNum(item)}}{{item.goodsUnit}}</td>-->
            <td width="124" class="tr">{{item.requireLeft}}{{item.goodsUnit}}</td>
            <!--<td width="56" v-if="isConfirm">&nbsp;</td>-->
            <td width="114" :class="{'require-goods-num':!isConfirm}" class="tl">
              <div :class="{'tr' : !req.edit}" style="padding: 7px 0 ;" class="mb10" v-for="(req,ind) in item.requireList" :key="ind" v-if="req.operFlg != 'Del'">
                <template v-if="req.edit">
                  <!--<span class="cut" :class="{'grey':req.num == 0}" @click.stop="cut(index)">-</span>-->
                  <input type="number" class="tr" v-input-number @blur="handleBlur($event,req)" @keyup="ctrlNum(index,req.requireCount)" v-model="req.requireCount" name="" maxlength="14"><em style="padding-left: 4px;">{{item.goodsUnit|| ''}}</em>
                  <!-- <span class="add" :class="{'grey':item.num == item.requireLeft}" @click.stop="add(index)">+</span> -->
                  <!--<span class="add" @click.stop="add(index)">+</span>-->
                </template>
                <span v-else>{{req.requireCount || 0}}{{item.goodsUnit|| ''}}</span>
                <!--<p v-if="+req.requireCount>+item.requireLeft" class="red tip">超出合同签订数量</p>-->
              </div>
              <!--<p v-if="compRequireLeftNum(item) < 0" class="red tip td-add">超出合同签订数量</p>-->
              <!-- <span class="cut" :class="{'grey':item.num == 0}" @click.stop="cut(index)">-</span><input type="text" v-input-number @keyup="ctrlNum(index,item.num)" v-model="item.num" name="" :disabled="item.requireLeft == 0" maxlength="8"> -->

            </td>
            <!--<td width="56" v-if="isConfirm">&nbsp;</td>-->
            <!--<td>{{item.goodsUnit|| ''}}</td>-->
            <td width="265" class="tl">
              <div class="mb10" :class = "{padding7:isConfirm}" v-for="(req,ind) in item.requireList" :key="ind" v-if="req.operFlg != 'Del'">
                <template v-if="req.edit">
                  <el-input type="textarea" @input="handleInput" :maxlength="20" placeholder="请输入标段，限20字" v-model="req.location"></el-input>
                </template>
                <p v-else class="tl">
                  {{req.location || "无"}}
                </p>
              </div>
              <!--<p v-if="item.requireList.some(req=>{return req.edit})" class="td-add"><span class="hand blue" @click="handleAdd(item,index)">+增加标段</span></p>-->
              <p class="td-add" v-if="!isView" :class="{'bottom12':compBntStyle(item)}"><span class="hand blue" @click="handleAdd(item,index)">+增加标段</span></p>
            </td>
            <td width="265" class="tl">
              <div class="mb10" :class = "{padding7:isConfirm}"  v-for="(req,ind) in item.requireList" :key="ind" v-if="req.operFlg != 'Del'">
                <template v-if="req.edit">
                  <el-input type="textarea" @input="handleInput" :maxlength="20" placeholder="请输入备注，限20字" v-model="req.remark"></el-input>
                </template>
                <p v-else class="tl">
                  {{req.remark || "无"}}
                </p>
              </div>
            </td>
            <td width="60" class="td-operation blue" v-if="!isView">
              <div class="mb10" style="height: 54px;line-height: 54px;" v-for="(req,ind) in item.requireList" :key="ind" v-if="req.operFlg != 'Del'">
                <!--<span @click="handleEdit(req,ind,item,index)">{{req.edit ? "确认" : "编辑"}}</span>-->
                <!--<span @click="handleDel(req,ind,item,index)">{{req.edit ? "取消" : "删除"}}</span>-->
                <span v-if="showDelBtn(item)" @click="handleDel(req,ind,item,index)">删除</span>
                <!--<span>上传附件</span>-->
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div class="table-pagination" v-if="orderList.length && pageIndex">
      <el-pagination @current-change="handleCurrentChange" :current-page="pageIndex" :page-size="pageSize" :total="total" layout="prev, pager, next, total, jumper" prev-text="<<上一页" next-text="下一页>>">
      </el-pagination>
    </div>
    <FixBottom>
      <!--<FixBottom>-->
      <div class="fix-bottom">
        <div class="fl check" :class="{'w560':isConfirm}">
          <el-checkbox v-if="!isView" v-model="allCheck" @change="handleAllCheck"></el-checkbox>&nbsp;<span v-if="!isView">当页全选</span>
          <!--<span>{{isView && '已选' || ''}}{{isView ? (orderList&&orderList.length || 0) : 'N'}}款</span>-->
          <span>已选{{isView ? (orderList&&orderList.length || 0) : compTotalChecked()}}款</span>
          <el-input v-if="!isView" v-model="locationText" :maxlength="20" placeholder="勾选货品，在此输入需要批量标注的标段内容，限20个字"></el-input>
          <el-button v-if="!isView" type="primary" @click="handleBatchLocation">批量标段</el-button>
        </div>
        <div class="fr btn tr" :class="{'w560':!isConfirm}">
          <el-button class="bottom-btn" @click="saveReuireOrderList(null)">保存</el-button>
          <el-button type="primary"  class="bottom-btn" @click="handleGoNext">{{isConfirm ? '上一步' : '下一步'}}</el-button>
          <el-button v-if="isConfirm" type="primary" class="bottom-btn" @click="handleConfirmClick">创建要货单</el-button>
        </div>
      </div>
    </FixBottom>
    <Loading :is-loading="isLoading"></Loading>

    <slot name="leave"></slot>
  </div>
</template>

<script>
import { InterfaceService } from '@/services/api'
import Loading from '@/components/base/Loading'
import FixBottom from "@/components/base/FixBottom";
import { MoneyUtil } from '@/utils/moneyUtil';

export default {
  props: {
    fixedSearchActive: {
      type: Boolean,
      default: false
    },
    orderList: {
      type: Array
    },
    allOrderList:{
        type: Array
    },
    orderInfo: {
      type: Object
    },
      initRequireNo: {
          type: String
      },
    pageIndex: {
      type: Number
    },
    pageSize: {
      type: Number
    },
    total: {
      type: Number
    },
    // 查看模式
    isView: {
      type: Boolean,
      default: false
    },
    // 是否 带提交
    isConfirm: {
      type: Boolean,
      default: false
    },
      requireSaveType: {
          type: String,
          default: "entry"
      },
      otherSaveInfo:{
          type: Object
      }
  },
  components: {
    Loading,
    FixBottom,

  },
  data() {
    return {
      locationText: "",
      allCheck: false,
      isLoading: false,
      storeRequireCount :"",
      storeLocation : "",
      storeRemark : "",
      requireNo : "",
    };
  },
  computed: {
    showP() {
      let ifShow = true;
      this.orderList.forEach((item, ind) => {
        if (item.show) {
          ifShow = false;
        }
      });
      return ifShow;
    }
  },
    watch:{
        initRequireNo: {
            handler(val) {
                this.requireNo = val || "";
                console.log(this.requireNo);
            },
            immediate: true
        }
    },
  methods: {
      compBntStyle(item) {
          let num = 0;
          item.requireList.forEach(req=>{
              if (req.operFlg != "Del") {
                  num++
              }
          });
          return num === 1
      },
      showDelBtn(item) {
          let num = 0;
          item.requireList.forEach(req=>{
              if (req.operFlg != "Del") {
                  num ++
              }
          });
          return num > 1
      },
    handleInput() {
      this.$forceUpdate()
    },
    handleCurrentChange(page) {
      this.allCheck = false;
      this.$emit("currentChange", page);
      // window.scrollTo(0,0)
    },
    handleGoNext() {
        if (!this.isConfirm) {
            this.saveReuireOrderList(null,"goNext")
        }else {
            this.$emit('outputNext')
        }
    },
    handleAdd(item, index) {
      item.requireList.push({
        id: "",
        operFlg: "",
        skuId: item.skuId,
        requireCount: "",
        location: "",
        remark: "",
        edit: true,
      });
      this.$set(this.orderList, index, item)
      console.log(item);
    },
    handleEdit(req, ind, item, index) {
      req.edit = !req.edit;
        this.storeRequireCount =req.requireCount || "";
        this.storeLocation = req.location || "";
        this.storeRemark = req.remark || "";
        if (!req.edit) {
            if (!req.requireCount) {
                this.$message.error("请填写要货数量")
                req.edit = !req.edit;
            }else {
                this.saveReuireOrderList(req);
            }
      }
      this.$set(item.requireList, ind, req);
      this.$set(this.orderList, index, item)
    },
      compRequireLeftNum(item){
          let num = 0
          // if (this.isConfirm) {
              item.requireList.forEach(req=>{
                  if (req.operFlg != "Del") {
                      num += +req.requireCount
                  }
              })
          // }else {
          //     initNum = +item.initCount
          // }
          return this.isConfirm ? Number(item.requireLeft) :  (Number(item.requireLeft) + Number(item.initCount) -num) < 0 ? 0 : (Number(item.requireLeft) + Number(item.initCount) -num)
      },
      compTotalChecked() {
          let num = 0
          this.orderList.forEach(item=>{
              if (item.checked) {
                  num ++
              }
          })
          return num
      },
    handleDel(req, ind, item, index) {
        req.operFlg = "Del";
        req.requireCount = "";
        req.location = "";
        req.remark = "";
          // if (item.requireList.length > 1) {
          //     item.requireList.splice(ind, 1);
          // } else {
          //     item.requireList.forEach(_item => {
          //         _item.id = "";
          //         _item.operFlg = "Del";
          //         _item.requireCount = "";
          //         _item.location = "";
          //         _item.remark = "";
          //     })
          // }
      // this.$set(item.requireList, ind, req);
      this.$set(this.orderList, index, item)
    },
    handleConfirmClick() {
      this.$emit('outputConfirm')
    },
      //记录已选择的订单
      recordOrder() {
          this.orderList.forEach(_item => {
              let onOff = false;
              this.allOrderList.forEach(item => {
                  if (item.skuId == _item.skuId) {
                      item.requireCount = _item.requireCount;
                      item.location = _item.location;
                      item.remark = _item.remark;
                      item.requireList = _item.requireList;
                      onOff = true
                  }
              });
              if (!onOff) {
                  this.allOrderList.push(_item)
              }
          });
      },
    saveReuireOrderList(req,goNext) {
        let requireList = []
        this.recordOrder()
        // if (goNext && !this.isConfirm) {
        //     let num = 0;
        //     this.allOrderList.forEach(item=>{
        //         item.requireList.forEach(req=>{
        //             num += req.requireCount
        //         });
        //     })
        //     if (num <= 0) {
        //         this.$message.error("请选择要货商品！");
        //         return
        //     }
        // }
        console.log(this.allOrderList);
        this.allOrderList.forEach(f => {
          f.requireList.map(m => {
              if (m.requireCount == 0&&m.id) {
                  m.operFlg = "Del";
                  m.requireCount = ""
              }
              if (m.requireCount > 0 || (m.operFlg == "Del"&&m.id)) {
                  const {
                      applyNo,
                      id,
                      skuId,
                      requireCount,
                      location,
                      remark
                  } = m

                  requireList.push({
                      applyNo,
                      id,
                      operFlg: id ? m.operFlg || 'Update' : 'Add',
                      skuId,
                      requireCount,
                      location,
                      remark
                  })
              }
          })
        })

      let params = {
        orderNo: this.orderInfo.orderNo,
        requireNo: this.requireNo || "",
        requireOperFlg: this.requireNo ? "Update" : "Add",
        requireList:this.isConfirm?[]:requireList,
        requireSaveType:this.requireSaveType,
      };
      if (this.isConfirm) {
          params = Object.assign(params,this.otherSaveInfo)
      }
        InterfaceService.saveReuireOrderList(params, (data) => {
        if (data.respData.respCode == '0000') {
            this.requireNo = data.respData.requireNo || ""
            if (window.opener) {
                window.opener.location.reload();
            }
            if (goNext) {
                this.$emit("getSkuId",[],this.requireNo,"goNext")
                // this.checkRequireOrderNumber()
            }else {
                let skuIdList = [];
                requireList.forEach(item=>{
                    skuIdList.push(item.skuId)
                })
                this.$emit("getSkuId",skuIdList,this.requireNo)
                this.$message.success("保存成功")
            }
        } else {
            if (req) {
                req.edit = !req.edit
            }
            this.$message.error(data.respData.respMsg);
        }
      }, (data) => {
      }, () => {
        this.isLoading = true
      }, () => {
        this.isLoading = false
      });
    },
      checkRequireOrderNumber() {
          let params = {
              requireNo : this.requireNo,
              state : "01",
          };
          InterfaceService.getOrderRequireGoodsList(
              params,
              data => {
                  if (data.respData.respCode == '0000') {
                      let requireList = data.respData.requireList || [];
                      if (!requireList.length) {
                          this.$message.error("请先选择要货商品！")
                      }else {
                          this.$emit('outputNext',this.requireNo)
                      }
                  } else {
                      this.$message.error(data.respData.respMsg);
                  }
              },
              data => {
              },
              () => {
                  this.isLoading = true;
              },
              () => {
                  this.isLoading = false;
              }
          );
      },
    handleBatchLocation() {
      const arr = this.orderList;
      let hasOne = false;
      arr.forEach((item, index) => {
        if (item.checked) {
          hasOne = true;
          item.requireList && item.requireList.forEach(f => {
            this.$set(f, 'location', this.locationText)
          })
        }
      });
      if (!hasOne) {
        this.$message.info('请选择商品');
      }
    },
    handleSelectRow(item, index) {
      this.$set(this.orderList, index, item);
      this.checkAllSelect();
    },
    // 是否全选
    checkAllSelect() {
      this.allCheck = this.orderList.every(item => {
        return item.checked;
      });
    },
    handleAllCheck() {
      this.orderList.forEach((item, index) => {
        item.checked = this.allCheck;
        this.$set(this.orderList, index, item);
      });
    },
      handleBlur(ev,req) {
          if (+ev.target.value < 0) {
              this.$message.error("要货数量不能为负数,请重新填写");
              req.requireCount = 0
          }
      },
    ctrlNum(index, num) {
      this.$emit("ctrlNum", index, num);
    },
    goProduct(spuId, index) {
      let self = this;
      let product = self.orderList[index];
      self.$setRootScope("launchGoods", JSON.stringify(product));
      this.$router.push({
        path: "/productDetail",
        query: {
          id: spuId
        }
      });
    }
  }
};
</script>

<style lang="scss" scoped>
.quickbuy-add .must-icon {
  position: absolute;
  top: -2px;
  left: -27px;
}

.quickbuy-add-title {
  height: 50px;
  background-color: #f5f5f5;
  color: #4f525a;
  font-size: 16px;
  line-height: 50px;
  border-bottom: 2px solid #ffd64e;
  margin-bottom: 20px;
  font-weight: 700;
}

.quickbuy-add-title span {
  position: relative;
  padding: 0 26px;
  display: inline-block;
  height: 50px;
  line-height: 50px;
  font-size: 14px;
}

.quickbuy-add-title span:before {
  position: absolute;
  content: "";
  width: 100%;
  height: 2px;
  background-color: #444;
  left: 0;
  bottom: 0;
}

.quickbuy-add {
  margin-top: 35px;
}

.remarks {
  background-color: #f5f5f5;
  padding: 18px 20px;
}

.remarks {
  color: #888;
  font-size: 14px;
}

.remarks input {
  width: 56%;
  height: 36px;
  border: 1px solid #ddd;
  background-color: #fff;
  text-indent: 12px;
  margin-left: 18px;
  margin-right: 18px;
}

.no-quickbuy-add-list {
  text-align: center;
  line-height: 50px;
  height: 50px;
  font-size: 14px;
  color: #444444;
}

.require-goods-title-wrap {
  width: 100%;
  line-height: 44px;
  height: 44px;
}

.require-goods-title {
  float: left;
  height: 44px;
  text-align: center;
  font-size: 14px;
  color: #888888;
}

.require-goods-title.select {
  width: 50px;
}

.require-goods-title.name {
  width: 263px;
}

.require-goods-title.price {
  width: 130px;
}

.require-goods-title.choose {
  width: 184px;
}

.require-goods-title.num {
  width: 180px;
}

.require-goods-title.location {
  width: 180px;
}

.require-goods-title.total {
  width: 200px;
}

.require-goods-warp {
  width: 100%;
  background: #f5f5f5;
}

.require-goods-warp li {
  width: 100%;
  height: 100px;
  line-height: 100px;
  margin-bottom: 1px;
}

.require-goods-warp li.choosed {
  background: #fde9a8;
}

.require-goods-warp li.disable {
  background: #e5e5e5;
}

.require-goods-warp li:hover {
  background: #e8f3fd;
}

.require-goods-name {
  float: left;
  width: 263px;
  padding: 19px 0 0 19px;
  height: 100px;
}

.require-goods-name img {
  width: 60px;
  height: 60px;
  float: left;
}

.require-goods-name .require-goods-right {
  float: left;
  margin-left: 10px;
  font-size: 12px;
  color: #444444;
  width: 172px;
  height: 100%;
}

.require-goods-name .require-goods-right p {
  width: 100%;
  line-height: 18px;
}

.require-goods-name .require-goods-right span {
  display: block;
  width: 100%;
  line-height: 16px;
  color: #888888;
  margin-top: 10px;
}

.require-goods-select,
.require-goods-price,
.require-goods-choose,
.require-goods-location,
.require-goods-total {
  text-align: center;
  height: 100px;
  line-height: 100px;
  float: left;
  width: 130px;
  color: #444444;
}

.require-goods-select {
  width: 50px;
}

.require-goods-choose {
  width: 184px;
}

.require-goods-num {
  position: relative;
  width: 180px;
}

.require-goods-location {
  width: 180px;
}

.require-goods-location /deep/ .el-input input {
  height: 33px;
  line-height: 33px;
}

.require-goods-total {
  width: 200px;
}

.cut,
.add {
  display: inline-block;
  width: 28px;
  height: 33px;
  background: white;
  text-align: center;
  line-height: 33px;
  border: 1px solid #dddddd;
  cursor: pointer;
  vertical-align: middle;
  user-select: none;
}

.cut.grey,
.add.grey {
  cursor: not-allowed;
  background: #eeeeee;
}

.add {
  margin-left: -3px;
}

.require-goods-num input {
  width: 100px;
  padding-right: 4px;
  /*border-top: 1px solid #dddddd;*/
  /*border-bottom: 1px solid #dddddd;*/
  /*height: 33px;*/
  /*line-height: 33px;*/
  text-align: center;
  /*border-right: none;*/
  /*border-left: none;*/
  vertical-align: middle;
}

.require-goods-num input:focus {
  /*border-right: none;*/
  /*border-left: none;*/
}

.require-goods-num input::-ms-clear {
  display: none;
}

.require-goods-num .tip {
  position: absolute;
  width: 100%;
  left: 0;
  bottom: 10px;
}

.go-blue:hover {
  color: #0082ff;
  text-decoration: underline;
  cursor: pointer;
}

.table {
  margin-bottom: 2px;
  　 /deep/ .el-button {
    font-size: 12px;
  }

  width: 100%;
  line-height: 23px;
  font-size: 12px;
  &.fixedSearchActive {
    %fixedSearch-active-public {
      animation: showFixed 0.3s 1;
      @keyframes showFixed {
        0% {
          top: -50px;
        }
        50% {
          top: 0px;
        }
        100% {
          top: 58px;
        }
      }
    }
    .fixedSearchActiveBg {
      position: fixed;
      top: 58px;
      left: 0;
      background: #535864;
      width: 100%;
      z-index: 2;
      height: 30px;
      @extend %fixedSearch-active-public;
    }
    .isViewTitle{
      top: 0;
    }
    thead {
      position: fixed;
      top: 58px;
      height: 30px;
      background: #535864;
      width: 1190px;
      margin: auto;
      color: #fff;
      left: 50%;
      transform: translateX(-50%);
      z-index: 2;
      @extend %fixedSearch-active-public;
      td{
        height: 30px;
        line-height: 5px;
      }
    }
  }
  table {
    width: 100%;
  }
  td {
    padding: 14px 10px;
    vertical-align: middle;
    word-break: break-word;
    position: relative;
    .td-add {
      position: absolute;
      bottom: 0;
      text-align: left;
    }
    .bottom12 {
      bottom: 12px;
    }
  }

  thead {
    text-align: center;
    white-space: nowrap;
    font-size: 14px;
    color: #909399;
  }

  tbody {
    text-align: center;

    tr:hover {
      background: #e8f3fd;
    }

    td {
      border-bottom: 1px solid #ffffff;
      background: #f5f5f5;
    }
  }
  .td-operation {
    span {
      margin-right: 8px;
      cursor: pointer;
    }
  }
}

.order-name {
  display: inline-flex;
  width: 100%;
  vertical-align: top;
  line-height: 20px;

  img {
    width: 75px;
    height: 75px;
  }

  .left {
    margin-right: 10px;
  }

  .right {
    text-align: left;

    p {
      max-width: 180px;
      word-break: break-all;
      max-height: 40px;
      overflow: hidden;
    }

    p:first-child {
      margin-bottom: 10px;
    }
    p:last-child {
      word-break: break-all;
      max-height: 40px;
      overflow: hidden;
      color: #969799;
    }
  }
}
.mb80{
  margin-bottom: 80px;
}
.table-pagination {
  margin: 20px 0 20px;
  text-align: center;
  color: #888888;
}

.all-opt {
  margin-bottom: 20px;
  padding: 10px 20px;

  /deep/ .el-input {
    margin-left: 20px;
    width: 400px;
  }
}
.mb10 {
  margin-bottom: 10px;
}
.fix-bottom {
  .check {
    width: 590px;
    text-align: left;
    height: 40px;
    line-height: 40px;
    span {
      color: #fff;
      margin-right: 6px;
    }
    .el-input {
      width: 340px;
    }
  }
  .btn {
    width: 630px;
    margin-top: 4px;
    .bottom-btn{
      width: 200px;
      line-height: 8px;
      height: 32px;
    }
  }
  .w560{
    width: 560px;
  }

}
  /deep/ .el-textarea__inner{
    padding-right: 15px;
    resize: none;
  }
.padding7{
  padding: 7px 0;
}
</style>
