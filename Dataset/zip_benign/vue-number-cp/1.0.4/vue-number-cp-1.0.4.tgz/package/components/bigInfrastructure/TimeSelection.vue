<template>
  <div class="f14 time-select">
    <div class="fl" style="font-size: 12px">
      统计时间:{{searchFromTm}}
      <template v-if="searchEndTm">~</template>
      {{searchEndTm}}
    </div>
    <div class="fr specifications-choose tr">
      <ul>
        <li class="width-auto" :class="{'disabled': (timeSelected == 'year' && !maxYear ) || timeSelected == 'sevenDays' || timeSelected == 'thirtyDays' || !canEdit}" @click="changeTimeBtn('next')"><i class="el-icon-caret-right"></i></li>
        <li style="margin: 0 2px 0 6px;" class="width-auto" :class="{'disabled':  (timeSelected == 'year' && !minYear ) || timeSelected == 'sevenDays' || timeSelected == 'thirtyDays'}" @click="changeTimeBtn('prev')"><i class="el-icon-caret-left"></i></li>
        <li :class="{'active':timeSelected === 'year'}" style="border-right: 1px solid #ddd;">
          <el-select v-model="yearSelect" placeholder="请选择年" @change="changeTimeSelection('year')">
            <el-option v-for="item in yearOptions" :key="item" :label="item" :value="item">
            </el-option>
          </el-select>
        </li>
        <li :class="{'active':timeSelected === 'month'}" @click="selectedTm('month')">
          月
          <el-date-picker @change="changeTimeSelection('month',$event)" ref="month" type="month" :picker-options="dateOption" v-model="selectedTime"></el-date-picker>
        </li>
        <li :class="{'active':timeSelected === 'week'}" @click="selectedTm('week')">
          周
          <el-date-picker @change="changeTimeSelection('week',$event)" ref="week" type="week" :picker-options="dateOption" v-model="selectedTime"></el-date-picker>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>

export default {
  name: "timeSelection",
  props: ["selTime", "realTime", "timeSel"],
  watch: {
    realTime: {
      handler: function (nVal) {
        this.initYearOptions()
        this.init();
        if (nVal) {
          this.selectedTime = new Date(this.selTime);
          this.timeSelected = this.timeSel;
          console.log(this.selTime);
          this.changeTimeSelection(this.timeSelected)
        }
      },
      immediate: true
    }
  },
  computed: {
    // 判断年是否可以点击 向前
    maxYear() {
      return this.yearSelect < new Date().getFullYear()
    },
    // 判断年是否可以点击 向后
    minYear() {
      return this.yearSelect > new Date().getFullYear() - this.disYear + 1
    },
  },
  data() {
    return {
      timeSelected: "year",
      searchFromTm: "",
      searchEndTm: "",
      selectedTime: "",
      canEdit: true,
      dateOption: {
        firstDayOfWeek: 1,
        disabledDate(time) {
          return time.getTime() >= Date.now();
        }
      },
      disYear: 50, // 显示历史年份限制
      yearOptions: [], // 年份数组
      yearSelect: '', // 年
    }
  },

  methods: {
    changeTimeSelection(type, ev) {
      if (ev != "Invalid Date") {
        console.log(type, ev);
        let nowTime = new Date();
        this.timeSelected = type;
        if (type === "year") {
          this.searchFromTm = new Date(`${this.yearSelect}-01-01`).Format("yyyy-MM-dd")
          // 判断选中年份是否为当前年份, 如果是, 结束时间 为当前时间
          if (this.yearSelect == nowTime.getFullYear()) {
            this.searchEndTm = new Date(nowTime).Format("yyyy-MM-dd")
          } else {
            // 设置一年的最后一天时间
            this.searchEndTm = new Date(`${this.yearSelect}-12-31`).Format("yyyy-MM-dd")
          }

          this.selectedTime = new Date(this.searchFromTm)
        } else if (type === "sevenDays") {
          this.searchEndTm = new Date(nowTime - 24 * 60 * 60 * 1000).Format("yyyy-MM-dd");
          this.searchFromTm = new Date(nowTime - 168 * 60 * 60 * 1000).Format("yyyy-MM-dd")
          this.selectedTime = ""
        } else if (type === "thirtyDays") {
          this.searchEndTm = new Date(nowTime - 24 * 60 * 60 * 1000).Format("yyyy-MM-dd");
          this.searchFromTm = new Date(nowTime - 720 * 60 * 60 * 1000).Format("yyyy-MM-dd")
          this.selectedTime = ""
        } else if (type === "day") {
          if (this.selectedTime.getDate() <= nowTime.getDate()) {
            this.searchEndTm = this.searchFromTm = this.selectedTime.Format("yyyy-MM-dd");
            this.canEdit = this.selectedTime.getDate() != nowTime.getDate()
          } else {
            this.canEdit = false
          }
        } else if (type === "week") {
          this.searchFromTm = new Date(this.selectedTime - 24 * 60 * 60 * 1000).Format("yyyy-MM-dd");
          if (new Date(+this.selectedTime + 144 * 60 * 60 * 1000) >= nowTime) {
            this.searchEndTm = nowTime.Format("yyyy-MM-dd");
            this.canEdit = false
          } else {
            this.searchEndTm = new Date(+this.selectedTime + 120 * 60 * 60 * 1000).Format("yyyy-MM-dd");
            this.canEdit = true
          }
        } else if (type === "month") {
          let curDate = this.selectedTime;
          let curMonth = curDate.getMonth();
          this.searchFromTm = new Date(curDate.setDate(1)).Format("yyyy-MM-dd");
          if (curDate.getFullYear() === nowTime.getFullYear()) {
            if (curDate.getMonth() < nowTime.getMonth()) {
              curDate.setMonth(curMonth + 1);
              this.searchEndTm = new Date(curDate.setDate(0)).Format("yyyy-MM-dd")
              this.canEdit = true
            } else {
              // this.searchEndTm = new Date(nowTime.setDate(0)).Format("yyyy-MM-dd")
              this.searchEndTm = nowTime.Format("yyyy-MM-dd");
              this.canEdit = false
            }
          } else {
            curDate.setMonth(curMonth + 1);
            this.searchEndTm = new Date(curDate.setDate(0)).Format("yyyy-MM-dd")
            this.canEdit = true
          }
        }
        // 如果 点击 不是年 需要 设置 年的 时间
        if (type !== "year") {
          this.yearSelect = this.selectedTime && this.selectedTime.getFullYear()
        }
        this.$emit("getSelectedTime", this.searchFromTm, this.searchEndTm, this.timeSelected, this.selectedTime)
      }
    },
    changeTimeBtn(type) {
      if (type === "prev") {
        if (this.timeSelected === "day") {
          this.selectedTime = new Date(this.selectedTime - 24 * 60 * 60 * 1000);
          this.changeTimeSelection("day");
        } else if (this.timeSelected === "week") {
          this.selectedTime = new Date(this.selectedTime - 168 * 60 * 60 * 1000);
          this.changeTimeSelection("week");
        } else if (this.timeSelected === "month") {
          this.selectedTime = new Date(this.selectedTime - 31 * 24 * 60 * 60 * 1000);
          this.changeTimeSelection("month");
        } else if (this.timeSelected === "year") {
          if (this.minYear) {
            this.yearSelect--
            this.changeTimeSelection("year");
          }
        }
      } else if (type === "next") {
        if (this.canEdit) {
          if (this.timeSelected === "day") {
            this.selectedTime = new Date(+this.selectedTime + 24 * 60 * 60 * 1000);
            this.changeTimeSelection("day");
          } else if (this.timeSelected === "week") {
            this.selectedTime = new Date(+this.selectedTime + 168 * 60 * 60 * 1000);
            this.changeTimeSelection("week");
          } else if (this.timeSelected === "month") {
            this.selectedTime = new Date(+this.selectedTime + 24 * 60 * 60 * 1000);
            this.changeTimeSelection("month");
          } else if (this.timeSelected === "year") {
            if (this.maxYear) {
              this.yearSelect++
              this.changeTimeSelection("year");
            }
          }
        }
      }
    },
    selectedTm(type) {
      this.$refs[type].focus();
    },
    initYearOptions() {
      const year = new Date().getFullYear() || 0

      this.yearSelect = year
      this.yearOptions = []
      for (let i = year; i > year - this.disYear; i--) {
        this.yearOptions.push(i)
      }
    },
    init() {
      Date.prototype.Format = function (fmt) { //author: meizz
        let o = {
          "M+": this.getMonth() + 1, //月份
          "d+": this.getDate(), //日
          "h+": this.getHours(), //小时
          "m+": this.getMinutes(), //分
          "s+": this.getSeconds(), //秒
          "q+": Math.floor((this.getMonth() + 3) / 3), //季度
          "S": this.getMilliseconds() //毫秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (let k in o)
          if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
      };
    }
  },
}
</script>

<style lang="scss" scoped>
.time-select {
  height: 40px;
  line-height: 30px;
  margin: 0px;
}
.specifications-choose {
  overflow: hidden;
}
.specifications-choose ul {
  width: 636px;
  overflow: hidden;
}
.specifications-choose ul li {
  float: right;
  width: 82px;
  text-align: center;
  line-height: 24px;
  height: 26px;
  border: 1px solid #dddddd;
  color: #444;
  position: relative;
  cursor: pointer;
  border-right: none;
  &.width-auto {
    width: 16px !important;
    height: 26px;
    border-right: 1px solid #ddd;
    i {
      color: #c99f4f;
    }
  }
  &.disabled {
    cursor: not-allowed !important;
    i {
      color: #bbb;
    }
  }
  /deep/ .el-select {
    height: 24px;
    .el-input--suffix {
      display: flex;
      align-items: center;
    }
  }

  /deep/ .el-input--suffix .el-input__inner {
    height: 24px;
    line-height: 24px;
    border: 0;
    width: 79px;
  }
  /deep/ .el-select .el-input .el-select__caret {
    margin-top: 8px;
    &.is-reverse {
      margin-top: -9px;
    }
  }
  &.active {
    /deep/ .el-input--suffix .el-input__inner {
      background: linear-gradient(119deg, #d7b064 0%, #ecce8b 100%);
      color: #fff;
    }
    /deep/ .el-select .el-input .el-select__caret {
      color: #fff;
      margin-top: 8px;
      &.is-reverse {
        margin-top: -9px;
      }
    }
  }
}
.specifications-choose ul li.active {
  background: linear-gradient(119deg, #d7b064 0%, #ecce8b 100%);
  color: #fff;
}
.el-date-editor {
  width: 0;
  height: 0;
  overflow: hidden;
}
</style>