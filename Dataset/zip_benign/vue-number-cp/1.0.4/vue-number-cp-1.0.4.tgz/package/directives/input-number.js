const findEl = (el) => {
    return el.tagName === 'INPUT' ? el : el.querySelector('input');
}

const trigger = (el, type) => {
    const e = document.createEvent('HTMLEvents')
    e.initEvent(type, true, true)
    el.dispatchEvent(e)
}

const formatValue = (el, precision = 6) => {
    if (!el.value) return;
    if (el.value.includes('。')) {
        el.value = el.value.replace('。', '.')
    }

    if (el.value == '00' || el.value == '-00' || el.value == '+00') {
        el.value = 0;
    }
    const reg = new RegExp(`^[\\+\\-]?\\d{1,9}(\\.\\d{0,${precision}})?$`);
    if (!el.value.match(reg)) {
        el.value = el.t_value || null;
    } else {
        el.t_value = el.value;
    }
}

const inputNumber = {
    bind: function (ele, binding, vnode) {
        const precision = binding.value && binding.value.precision;
        let el = findEl(ele);
        el.handler = function () {
            formatValue(el, precision);
        }
        el.trigger = function () {
            trigger(el, 'input')
        }
        el.addEventListener('input', el.handler)
        el.addEventListener('keyup', el.trigger)
        el.addEventListener('keydown', el.trigger)
    },
    unbind: function (ele) {
        let el = findEl(ele);
        el.removeEventListener('input', el.handler)
        el.removeEventListener('keyup', el.trigger)
        el.removeEventListener('keydown', el.trigger)
    },
    componentUpdated: function (ele, binding) {
        const precision = binding.value && binding.value.precision;
        let el = findEl(ele);
        formatValue(el, precision);
    }
}

export default inputNumber;