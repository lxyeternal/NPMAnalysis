const numberControl = {
  bind: function (el) {
    // console.log(el);
  },
  inserted: function (el,binding) {
    console.log(binding.value);
    let negative = binding && binding.value && binding.value.negative || false; // 是否可输入负数
    let decimal = binding && binding.value && binding.value.decimal || 2;       // 小数位数
    let maxLength = binding && binding.value && binding.value.maxLength || 100; // 最大正数长度
    el.addEventListener('input', (e) => {
      if (negative) {
        // 负数
        e.target.value  = e.target.value.replace(/[^\d.-]/g, ""); //清除"数字"、"-"和"."以外的字符
      } else {
        e.target.value  = e.target.value.replace(/[^\d.]/g, ""); //清除"数字"和"."以外的字符
      }
      e.target.value = e.target.value.replace(/^\./g, ""); //验证第一个字符是数字
      e.target.value = e.target.value.replace(/\.{2,}/g, "."); //只保留第一个, 清除多余的
      e.target.value = e.target.value.replace(/-{2,}/g,""); //只保留第一个, 清除多余的
      if (e.target.value.length > 1 && e.target.value[e.target.value.length - 1] == '-') {
        e.target.value = e.target.value.substring(0, e.target.value.length - 1)
      }
      if (e.target.value.indexOf('.') != -1) {
        e.target.value = e.target.value.substring(0, e.target.value.indexOf('.') + decimal + 1)
      }
      //最大可输入长度
      if (e.target.value.indexOf('.') != -1) {
        console.log(e.target.value.indexOf('.'));
        if (e.target.value.length > maxLength + decimal + 1) {
          e.target.value = e.target.value.substring(0, maxLength + decimal + 1)
        }
      }else{
        if (e.target.value.length > maxLength) {
          e.target.value = e.target.value.substring(0, maxLength)
        }
      }
    })
  }
}

export default numberControl;