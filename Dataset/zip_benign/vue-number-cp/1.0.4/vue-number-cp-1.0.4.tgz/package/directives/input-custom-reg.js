import { log } from "util";

const findEl = (el) => {
    return el.tagName === 'INPUT' ? el : el.querySelector('input');
}

const trigger = (el, type) => {
    const e = document.createEvent('HTMLEvents')
    e.initEvent(type, true, true)
    el.dispatchEvent(e)
}

const formatValue = (el, precision = 6, binding) => {

    if (!el.value) return;
    if (el.value.includes('。')) {
        // 值 中文句号  转换 和去前后空格
        el.value = el.value.replace('。', '.').trim()
    }

    // 值未00时转换成0
    if (el.value == '00' || el.value == '-00' || el.value == '+00') {
        el.value = 0;
    }

    let regString = null
    // 如果不需要设置 正则验证 则 reg 赋值为 null

    if (binding.value && binding.value.reg === null) {
        regString = '.?'
    } else {
        regString = (binding.value && binding.value.reg) ? binding.value.reg : '^[-+]?(\\d{1,9}(\\.\\d{0,6})?)?$';
    }
    const reg = new RegExp(regString);
    let elVal = el.value
    // 是否有精度处理
    binding.value && binding.value.accuracy && el.value != '-' && Number(el.value).toFixed && (elVal = Number(el.value).toFixed(binding.value.accuracy))

    if (!elVal.match(reg)) {
        el.value = binding.value && binding.value.accuracy ? el.t_value.toFixed(binding.value.accuracy) : el.t_value || null;
    } else {
        el.t_value = binding.value && binding.value.accuracy ? el.value.toFixed(binding.value.accuracy) : el.value;
    }
}

const inputNumber = {
    bind: function (ele, binding) {
        const precision = binding.value && binding.value.precision;
        let el = findEl(ele);
        el.handler = function () {
            formatValue(el, precision, binding);
        }
        el.trigger = function () {
            trigger(el, 'input')
        }
        el.addEventListener('input', el.handler)
        el.addEventListener('keyup', el.trigger)
        el.addEventListener('keydown', el.trigger)
    },
    unbind: function (ele) {
        let el = findEl(ele);
        el.removeEventListener('input', el.handler)
        el.removeEventListener('keyup', el.trigger)
        el.removeEventListener('keydown', el.trigger)
    },
    componentUpdated: function (ele, binding) {
        const precision = binding.value && binding.value.precision;
        let el = findEl(ele);
        formatValue(el, precision, binding);
    }
}

export default inputNumber;