import inputNumber from './input-number';
import inputPwd from './input-pwd';
import errorImg from './error-image';
import inputCustomReg from './input-custom-reg';
import numberControl from './number-control';

export default {
    install(Vue, options) {
        Vue.directive('inputNumber', inputNumber);
        Vue.directive('inputPwd', inputPwd);
        Vue.directive('errorImg', errorImg);
        Vue.directive('inputCustomReg', inputCustomReg);
        Vue.directive('numberControl', numberControl);
    }
}