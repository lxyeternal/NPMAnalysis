const src = '/static/images/no-img.png';

const errorImg = {
    inserted: function (el) {
        if (!el.src || el.src === (location.origin + '/')) {
            el.src = src;
        }
    },
    componentUpdated: function (el) {
        if (!el.src) {
            el.src = src;
        }
    }
}

export default errorImg;