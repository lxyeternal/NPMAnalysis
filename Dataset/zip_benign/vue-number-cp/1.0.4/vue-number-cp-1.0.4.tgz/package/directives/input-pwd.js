const inputPwd = {
    inserted:function(el){
        el.addEventListener('keyup',(e)=>{
            let val = e.target.value;
            console.log(val)
            val  = val.replace(/[^\u4e00-\u9fa5\w]/g,'')
            console.log(val)
            if(val.length >=18){
            	val =  val.substr(0,18)
            }
        })
    }
}

export default inputPwd;