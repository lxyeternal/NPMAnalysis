export default {
    common: {
        hello: 'Hi，欢迎来到大家采~'
    },
    product: {

    },
    order: {

    }
}