export default {
    common: {
        hello: 'Hi，welcome to collaboration~'
    },
    product: {

    },
    order: {

    }
}