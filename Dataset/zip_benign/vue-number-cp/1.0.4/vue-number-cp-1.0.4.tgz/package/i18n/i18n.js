import Vue from 'vue'
import VueI18n from 'vue-i18n'
import locale from 'element-ui/lib/locale';
import zhCN from './lang/zh-CN'
import en from './lang/en'
import enLocale from 'element-ui/lib/locale/lang/en'
import zhCNLocale from 'element-ui/lib/locale/lang/zh-CN'

Vue.use(VueI18n)

const messages = {
  en: Object.assign(en, enLocale),
  zhCN: Object.assign(zhCN, zhCNLocale)
}

const i18n = new VueI18n({
  locale: 'zhCN',
  messages 
})

//实现element插件的多语言切换
locale.i18n((key, value) => i18n.t(key, value)) 

export default i18n

/**
 * example
 * 
 * 使用
 * <span>{{$t('common.hello')}}</span>
 * 
 * 切换语言
 * this.$i18n.locale = 'en'
 */
