

module.exports = document.documentElement;