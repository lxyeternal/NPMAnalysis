
```bash
npm i ss-line-chart@0.0.5 --save
```
## Framework Integration
https://stenciljs.com/docs/overview

## Setting Prop Using JS (Won't work with HTML) 

https://medium.com/@gilfink/using-complex-objects-arrays-as-props-in-stencil-components-f2d54b093e85

document.querySelector('line-chart').data = [{'x': '0.5', 'y': '3'}, {'x': '2', 'y': '4'}];

