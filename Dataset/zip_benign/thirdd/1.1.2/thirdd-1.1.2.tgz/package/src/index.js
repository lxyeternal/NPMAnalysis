import ModelFbx from './model-fbx.vue';

const components = [
  ModelFbx,
];

/* eslint-disable no-shadow */
const install = (Vue) => {
  components.forEach((component) => {
    Vue.component(component.name, component);
  });
};

if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue);
}

export default {
  install,
  ModelFbx,
};

export {
  install,
  ModelFbx,
};
