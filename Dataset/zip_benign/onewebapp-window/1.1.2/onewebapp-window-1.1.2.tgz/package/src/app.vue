<template>
  <div
    class="box"
    ref="box"
    :style="{
      height: eventInfo.height + 'px',
      width: eventInfo.width + 'px',
      top: eventInfo.top + 'px',
      left: eventInfo.left + 'px',
    }"
    v-if="visible"
    @mousedown.stop="clickItem"
  >
    <div
      class="top"
      :class="{ top_cur: isZoom }"
      @mousedown.stop="mouseDown($event, 'top')"
      @mouseup.stop="clearEvent"
    ></div>
    <div
      class="left"
      :class="{ left_cur: isZoom }"
      @mousedown.stop="mouseDown($event, 'left')"
      @mouseup.stop="clearEvent"
    ></div>
    <div
      class="right"
      :class="{ right_cur: isZoom }"
      @mousedown.stop="mouseDown($event, 'right')"
      @mouseup.stop="clearEvent"
    ></div>
    <div
      class="bottom"
      :class="{ bottom_cur: isZoom }"
      @mousedown.stop="mouseDown($event, 'bottom')"
      @mouseup.stop="clearEvent"
    ></div>
    <div
      class="top_left"
      :class="{ top_left_cur: isZoom }"
      @mousedown.stop="mouseDown($event, 'top_left')"
      @mouseup.stop="clearEvent"
    ></div>
    <div
      class="bottom_left"
      :class="{ bottom_left_cur: isZoom }"
      @mousedown.stop="mouseDown($event, 'bottom_left')"
      @mouseup.stop="clearEvent"
    ></div>
    <div
      class="top_right"
      :class="{ top_right_cur: isZoom }"
      @mousedown.stop="mouseDown($event, 'top_right')"
      @mouseup.stop="clearEvent"
    ></div>
    <div
      class="bottom_right"
      :class="{ bottom_right_cur: isZoom }"
      @mousedown.stop="mouseDown($event, 'bottom_right')"
      @mouseup.stop="clearEvent"
    ></div>

    <div
      class="box-title"
      ref="boxtitle"
      @mousedown.stop="dragDiv($event)"
      @mouseup.stop="clearEvent($event)"
    >
      <span>{{ title }}</span>
      <div class="box-title-btn">
        <span class="iconfont" @click="closeFun">x</span>
      </div>
    </div>
    <div class="box-main">
      <slot></slot>
    </div>
  </div>
</template>
<script>
export default {
  name: "window",
  data() {
    return {
      lastY: "",
      lastX: "",
      moveY: "",
      moveX: "",
      //窗口默认大小
      eventInfo: {
        width: this.width,
        height: this.height,
        top: this.top,
        left: this.top,
      },
      //当前点击的位置
      translate: "",
      //判断鼠标是否点击
      clickFlag: false,
      //元素是否移动
      moveFlag: true,
    };
  },
  props: {
    visible: {
      default: false,
      type: Boolean,
    },
    title: {
      default: "窗口",
      type: String,
    },
    isZoom: {
      default: true,
      type: Boolean,
    },
    isRun: {
      default: true,
      type: Boolean,
    },
    width: {
      type: [Number, String],
      default: window.innerWidth - window.innerWidth * 0.6,
    },
    height: {
      type: [Number, String],
      default: window.innerHeight - window.innerHeight * 0.4,
    },
    top: {
      type: [Number, String],
      default: 0,
    },
    left: {
      type: [Number, String],
      default: 0,
    },
  },
  mounted() {
    // this.$emit('open')
  },
  watch: {
    visible(newVal, oldVal) {
        if (newVal) {
          this.$emit('open')
        }
    },
  },
  methods: {
    mouseMove(e) {
      this.clickItem();
      switch (this.translate) {
        case "top":
          this.topChange(e);
          break;
        case "bottom":
          this.bottomChange(e);
          break;
        case "left":
          this.leftChange(e);
          break;
        case "right":
          this.rightChange(e);
          break;
        case "top_left":
          this.topChange(e);
          this.leftChange(e);
          break;
        case "bottom_left":
          this.bottomChange(e);
          this.leftChange(e);
          break;
        case "top_right":
          this.topChange(e);
          this.rightChange(e);
          break;
        case "bottom_right":
          this.bottomChange(e);
          this.rightChange(e);
          break;
        default:
          console.log("啦啦啦，我是卖报的小专家");
          break;
      }
      this.lastY = e.screenY;
      this.lastX = e.screenX;
    },
    topChange(e) {
      this.eventInfo.height =
        -(e.screenY - this.lastY) + this.$refs.box.clientHeight;
      this.eventInfo.top = e.clientY;
    },
    leftChange(e) {
      this.eventInfo.left = e.clientX;
      this.eventInfo.width =
        -(e.screenX - this.lastX) + this.$refs.box.clientWidth;
    },
    bottomChange(e) {
      this.eventInfo.height =
        e.screenY - this.lastY + this.$refs.box.clientHeight;
    },
    rightChange(e) {
      this.eventInfo.width =
        e.screenX - this.lastX + this.$refs.box.clientWidth;
    },
    mouseDown(e, translate) {
      if (!this.isZoom) {
        return false;
      }
      this.lastY = e.screenY;
      this.lastX = e.screenX;
      this.translate = translate;

      document.onmousemove = this.mouseMove;
    },
    //移动
    dragDiv(el) {
      if (!this.isRun) {
        return false;
      }
      this.clickItem();
      const box = this.$refs.box;
      const _this = this;
      box.startX = el.clientX - box.offsetLeft;
      box.startY = el.clientY - box.offsetTop;
      this.moveFlag = true;
      document.onmousemove = (e) => {
        if (_this.moveFlag) {
          _this.eventInfo.left = e.clientX - box.startX;
          _this.eventInfo.top = e.clientY - box.startY;
        }
      };
    },
    clearEvent() {
      document.onmousemove = null;
      document.onmouseup = null;
    },
    // 关闭
    closeFun() {
      this.$emit('update:visible', false)
      this.$emit("closeFun", true);
    },
    //鼠标按下回调
    clickItem() {
      this.$emit("clickItem", true);
    },
  },
};
</script>
<style scoped>
.box {
  position: absolute;
  min-height: 100px;
  min-width: 150px;
  box-shadow: 0 2px 12px 0 rgb(0 0 0 / 10%);
  /* transition: top 0.1s; */
}
.top,
.left,
.right,
.bottom {
  position: absolute;
}
.top,
.bottom {
  left: 0;
  right: 0;
  margin-left: auto;
  margin-right: auto;
}
.left,
.right {
  top: 0;
  bottom: 0;
  margin-top: auto;
  margin-bottom: auto;
}
.top {
  width: calc(100% - 4px);
  height: 2px;
  top: 0;
  left: 0;
}
.top_cur {
  cursor: n-resize;
}
.bottom {
  width: calc(100% - 4px);
  height: 2px;
  bottom: 0;
  left: 0;
}
.bottom_cur {
  cursor: s-resize;
}
.left {
  width: 2px;
  height: calc(100% - 4px);
  top: 0;
  left: 0;
}
.left_cur {
  cursor: w-resize;
}
.right {
  width: 2px;
  height: calc(100% - 4px);
  bottom: 0;
  right: 0;
}
.right_cur {
  cursor: e-resize;
}
.top_left,
.top_right,
.bottom_left,
.bottom_right {
  width: 6px;
  height: 6px;
  position: absolute;
}

.top_left {
  top: 0;
  left: 0;
}
.top_left_cur {
  cursor: nw-resize;
}
.top_right {
  top: 0;
  right: 0;
}
.top_right_cur {
  cursor: ne-resize;
}
.bottom_left {
  bottom: 0;
  left: 0;
}
.bottom_left_cur {
  cursor: sw-resize;
}
.bottom_right {
  bottom: 0;
  right: 0;
}
.bottom_right_cur {
  cursor: se-resize;
}
.top,
.bottom,
.left,
.right,
.top_left,
.top_right,
.bottom_left,
.bottom_right {
  z-index: 2;
}
.box-title {
  width: 100%;
  height: 30px;
  position: absolute;
  top: 2px;
  left: 0;
  right: 0;
  margin-left: auto;
  margin-right: auto;
  background: #fff;
  border-bottom: 0.5px solid rgba(124, 124, 124, 0.5);
  box-sizing: border-box;
  line-height: 30px;
  padding-left: 10px;
  box-sizing: border-box;
}
.box-title > span {
  display: block;
  width: 70%;
  float: left;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 14px;
  color: #000;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.box-title > .box-title-btn {
  /* width: 100px; */
  float: right;
  height: 100%;
  display: flex;
  justify-content: space-around;
}
.box-main {
  width: 100%;
  height: calc(100% - 31px);
  position: absolute;
  left: 0;
  right: 0;
  top: 33px;
  bottom: 0;
  margin: auto;
  background: #fff;
  padding: 7px;
  box-sizing: border-box;
}
.iconfont {
  cursor: pointer;
  font-size: 18px;
  color: rgb(124, 124, 124);
  width: 30px;
  height: 100%;
  text-align: center;
  line-height: 30px;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
.iconfont:hover {
  background: rgba(255, 0, 0, 0.7);
  color: #fff;
}
</style>
