// 引入组件
import app from './app.vue';
// 组件需要添加name属性，代表注册的组件名称，也可以修改成其他的
app.install = Vue => Vue.component(app.name, app); //注册组件

export default app;