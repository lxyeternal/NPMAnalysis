import { Component, EventEmitter, Input, Output, TemplateRef, Inject, LOCALE_ID } from '@angular/core';
import { CalendarService } from './calendar.service';
var IEvent = (function () {
    function IEvent(vCalEvent) {
        this.createTime = null;
        this.updateTime = null;
        this.allDay = false;
        this.startTime = null;
        this.endTime = null;
        this.title = null;
        this.ids = null;
        if (IEvent.isValid(vCalEvent)) {
            this.createTime = new Date(vCalEvent.createTime.getTime());
            this.updateTime = new Date(vCalEvent.updateTime.getTime());
            this.allDay = vCalEvent.allDay;
            this.startTime = new Date(vCalEvent.startTime.getTime());
            this.endTime = new Date(vCalEvent.endTime.getTime());
            this.title = vCalEvent.title;
            this.ids = vCalEvent.ids;
        }
    }
    IEvent.isValid = function (pstCalEvent) {
        return (null !== pstCalEvent && 'object' === typeof pstCalEvent) &&
            pstCalEvent.createTime instanceof Date &&
            pstCalEvent.updateTime instanceof Date &&
            'boolean' === typeof pstCalEvent.allDay &&
            pstCalEvent.startTime instanceof Date &&
            pstCalEvent.endTime instanceof Date &&
            'string' === typeof pstCalEvent.title;
    };
    return IEvent;
}());
export { IEvent };
export var Step;
(function (Step) {
    Step[Step["QuarterHour"] = 15] = "QuarterHour";
    Step[Step["HalfHour"] = 30] = "HalfHour";
    Step[Step["Hour"] = 60] = "Hour";
})(Step || (Step = {}));
var CalendarComponent = (function () {
    function CalendarComponent(m_oCalendarService, m_sAppLocale) {
        this.m_oCalendarService = m_oCalendarService;
        this.m_sAppLocale = m_sAppLocale;
        this.eventSource = [];
        this.calendarMode = 'month';
        this.formatDay = 'd';
        this.formatDayHeader = 'EEE';
        this.formatDayTitle = 'MMMM dd, yyyy';
        this.formatWeekTitle = 'MMMM yyyy, \'Week\' w';
        this.formatMonthTitle = 'MMMM yyyy';
        this.formatWeekViewDayHeader = 'EEE d';
        this.formatHourColumn = 'ha';
        this.showEventDetail = true;
        this.startingDayMonth = 0;
        this.startingDayWeek = 0;
        this.allDayLabel = 'all day';
        this.noEventsLabel = 'No Events';
        this.queryMode = 'local';
        this.step = Step.Hour;
        this.timeInterval = 60;
        this.autoSelect = true;
        this.dir = "";
        this.scrollToHour = 0;
        this.preserveScrollPosition = false;
        this.lockSwipeToPrev = false;
        this.lockSwipes = false;
        this.locale = "";
        this.startHour = 0;
        this.endHour = 24;
        this.spaceBetween = 0;
        this.onCurrentDateChanged = new EventEmitter();
        this.onRangeChanged = new EventEmitter();
        this.onEventSelected = new EventEmitter();
        this.onTimeSelected = new EventEmitter();
        this.onTitleChanged = new EventEmitter();
        this.hourParts = 1;
        this.hourSegments = 1;
        this.locale = m_sAppLocale;
    }
    Object.defineProperty(CalendarComponent.prototype, "currentDate", {
        get: function () {
            return this._currentDate;
        },
        set: function (val) {
            if (!val) {
                val = new Date();
            }
            this._currentDate = val;
            this.m_oCalendarService.setCurrentDate(val, true);
            this.onCurrentDateChanged.emit(this._currentDate);
        },
        enumerable: true,
        configurable: true
    });
    CalendarComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.autoSelect) {
            if ('false' === this.autoSelect.toString()) {
                this.autoSelect = false;
            }
            else {
                this.autoSelect = true;
            }
        }
        this.hourSegments = 60 / this.timeInterval;
        this.hourParts = 60 / this.step;
        if (this.hourParts <= this.hourSegments) {
            this.hourParts = 1;
        }
        else {
            this.hourParts = this.hourParts / this.hourSegments;
        }
        this.startHour = parseInt(this.startHour.toString());
        this.endHour = parseInt(this.endHour.toString());
        this.m_oCalendarService.queryMode = this.queryMode;
        this.currentDateChangedFromChildrenSubscription = this.m_oCalendarService.currentDateChangedFromChildren$.subscribe(function (currentDate) {
            _this._currentDate = currentDate;
            _this.onCurrentDateChanged.emit(currentDate);
        });
    };
    CalendarComponent.prototype.ngOnDestroy = function () {
        if (this.currentDateChangedFromChildrenSubscription) {
            this.currentDateChangedFromChildrenSubscription.unsubscribe();
            this.currentDateChangedFromChildrenSubscription = null;
        }
    };
    CalendarComponent.prototype.rangeChanged = function (range) {
        this.onRangeChanged.emit(range);
    };
    CalendarComponent.prototype.eventSelected = function (event) {
        this.onEventSelected.emit(event);
    };
    CalendarComponent.prototype.timeSelected = function (timeSelected) {
        this.onTimeSelected.emit(timeSelected);
    };
    CalendarComponent.prototype.titleChanged = function (title) {
        this.onTitleChanged.emit(title);
    };
    CalendarComponent.prototype.loadEvents = function () {
        this.m_oCalendarService.loadEvents();
    };
    CalendarComponent.decorators = [
        { type: Component, args: [{
                    selector: 'calendar',
                    template: "\n\t\t<ng-template #monthviewDefaultDisplayEventTemplate let-view=\"view\" let-row=\"row\" let-col=\"col\">\n\t\t\t<div class=\"calendar-date-box\">\n\t\t\t\t<div class=\"calendar-date-name\">{{ view.dates[row * 7 + col].label }}</div>\n\t\t\t\t<div class=\"calendar-date-event-info\">{{ view.dates[row * 7 + col].events.length }}</div>\n\t\t\t</div>\n\t\t</ng-template>\n\t\t<ng-template #monthviewDefaultEventDetailTemplate let-showEventDetail=\"showEventDetail\"\n\t\t\t     let-selectedDate=\"selectedDate\" let-noEventsLabel=\"noEventsLabel\">\n\t\t\t<ion-list class=\"event-detail-container\" has-bouncing=\"false\" *ngIf=\"showEventDetail\"\n\t\t\t\t  overflow-scroll=\"false\">\n\t\t\t\t<ion-item *ngFor=\"let event of selectedDate?.events\" (click)=\"eventSelected(event)\">\n                        <span *ngIf=\"!event.allDay\"\n\t\t\t      class=\"monthview-eventdetail-timecolumn\">{{event.startTime|date: 'HH:mm'}}\n\t\t\t\t-\n\t\t\t\t{{event.endTime|date: 'HH:mm'}}\n                        </span>\n\t\t\t\t\t<span *ngIf=\"event.allDay\"\n\t\t\t\t\t      class=\"monthview-eventdetail-timecolumn\">{{allDayLabel}}</span>\n\t\t\t\t\t<span class=\"event-detail\">  |  {{event.title}}</span>\n\t\t\t\t</ion-item>\n\t\t\t\t<ion-item *ngIf=\"selectedDate?.events.length==0\">\n\t\t\t\t\t<div class=\"no-events-label\">{{noEventsLabel}}</div>\n\t\t\t\t</ion-item>\n\t\t\t</ion-list>\n\t\t</ng-template>\n\t\t<ng-template #defaultWeekviewHeaderTemplate let-viewDate=\"viewDate\">\n\t\t\t{{ viewDate.dayHeader }}\n\t\t</ng-template>\n\t\t<ng-template #defaultAllDayEventTemplate let-displayEvent=\"displayEvent\">\n\t\t\t<div class=\"calendar-event-inner\">{{displayEvent.event.title}}</div>\n\t\t</ng-template>\n\t\t<ng-template #defaultNormalEventTemplate let-displayEvent=\"displayEvent\">\n\t\t\t<div class=\"calendar-event-inner\">{{displayEvent.event.title}}</div>\n\t\t</ng-template>\n\t\t<ng-template #defaultWeekViewAllDayEventSectionTemplate let-day=\"day\" let-eventTemplate=\"eventTemplate\">\n\t\t\t<div [ngClass]=\"{'calendar-event-wrap': day.events}\" *ngIf=\"day.events\"\n\t\t\t     [ngStyle]=\"{height: 25*day.events.length+'px'}\">\n\t\t\t\t<div *ngFor=\"let displayEvent of day.events\" class=\"calendar-event\" tappable\n\t\t\t\t     (click)=\"eventSelected(displayEvent.event)\"\n\t\t\t\t     [ngStyle]=\"{top: 25*displayEvent.position+'px', width: 100*(displayEvent.endIndex-displayEvent.startIndex)+'%', height: '25px'}\">\n\t\t\t\t\t<ng-template [ngTemplateOutlet]=\"eventTemplate\"\n\t\t\t\t\t\t     [ngTemplateOutletContext]=\"{displayEvent:displayEvent}\">\n\t\t\t\t\t</ng-template>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</ng-template>\n\t\t<ng-template #defaultDayViewAllDayEventSectionTemplate let-allDayEvents=\"allDayEvents\"\n\t\t\t     let-eventTemplate=\"eventTemplate\">\n\t\t\t<div *ngFor=\"let displayEvent of allDayEvents; let eventIndex=index\"\n\t\t\t     class=\"calendar-event\" tappable\n\t\t\t     (click)=\"eventSelected(displayEvent.event)\"\n\t\t\t     [ngStyle]=\"{top: 25*eventIndex+'px',width: '100%',height:'25px'}\">\n\t\t\t\t<ng-template [ngTemplateOutlet]=\"eventTemplate\"\n\t\t\t\t\t     [ngTemplateOutletContext]=\"{displayEvent:displayEvent}\">\n\t\t\t\t</ng-template>\n\t\t\t</div>\n\t\t</ng-template>\n\t\t<ng-template #defaultNormalEventSectionTemplate let-tm=\"tm\" let-hourParts=\"hourParts\"\n\t\t\t     let-eventTemplate=\"eventTemplate\">\n\t\t\t<div [ngClass]=\"{'calendar-event-wrap': tm.events}\" *ngIf=\"tm.events\">\n\t\t\t\t<div *ngFor=\"let displayEvent of tm.events\" class=\"calendar-event\" tappable\n\t\t\t\t     (click)=\"eventSelected(displayEvent.event)\"\n\t\t\t\t     [ngStyle]=\"{top: (37*displayEvent.startOffset/hourParts)+'px',left: 100/displayEvent.overlapNumber*displayEvent.position+'%', width: 100/displayEvent.overlapNumber+'%', height: 37*(displayEvent.endIndex -displayEvent.startIndex - (displayEvent.endOffset + displayEvent.startOffset)/hourParts)+'px'}\">\n\t\t\t\t\t<ng-template [ngTemplateOutlet]=\"eventTemplate\"\n\t\t\t\t\t\t     [ngTemplateOutletContext]=\"{displayEvent:displayEvent}\">\n\t\t\t\t\t</ng-template>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</ng-template>\n\n\t\t<div [ngSwitch]=\"calendarMode\" class=\"{{calendarMode}}view-container\">\n\t\t\t<monthview *ngSwitchCase=\"'month'\"\n\t\t\t\t   [formatDay]=\"formatDay\"\n\t\t\t\t   [formatDayHeader]=\"formatDayHeader\"\n\t\t\t\t   [formatMonthTitle]=\"formatMonthTitle\"\n\t\t\t\t   [startingDayMonth]=\"startingDayMonth\"\n\t\t\t\t   [showEventDetail]=\"showEventDetail\"\n\t\t\t\t   [noEventsLabel]=\"noEventsLabel\"\n\t\t\t\t   [autoSelect]=\"autoSelect\"\n\t\t\t\t   [eventSource]=\"eventSource\"\n\t\t\t\t   [markDisabled]=\"markDisabled\"\n\t\t\t\t   [monthviewDisplayEventTemplate]=\"monthviewDisplayEventTemplate||monthviewDefaultDisplayEventTemplate\"\n\t\t\t\t   [monthviewInactiveDisplayEventTemplate]=\"monthviewInactiveDisplayEventTemplate||monthviewDefaultDisplayEventTemplate\"\n\t\t\t\t   [monthviewEventDetailTemplate]=\"monthviewEventDetailTemplate||monthviewDefaultEventDetailTemplate\"\n\t\t\t\t   [locale]=\"locale\"\n\t\t\t\t   [dateFormatter]=\"dateFormatter\"\n\t\t\t\t   [dir]=\"dir\"\n\t\t\t\t   [lockSwipeToPrev]=\"lockSwipeToPrev\"\n\t\t\t\t   [lockSwipes]=\"lockSwipes\"\n\t\t\t\t   [spaceBetween]=\"spaceBetween\"\n\t\t\t\t   (onRangeChanged)=\"rangeChanged($event)\"\n\t\t\t\t   (onEventSelected)=\"eventSelected($event)\"\n\t\t\t\t   (onTimeSelected)=\"timeSelected($event)\"\n\t\t\t\t   (onTitleChanged)=\"titleChanged($event)\">\n\t\t\t</monthview>\n\t\t\t<weekview *ngSwitchCase=\"'week'\"\n\t\t\t\t  [formatWeekTitle]=\"formatWeekTitle\"\n\t\t\t\t  [formatWeekViewDayHeader]=\"formatWeekViewDayHeader\"\n\t\t\t\t  [formatHourColumn]=\"formatHourColumn\"\n\t\t\t\t  [startingDayWeek]=\"startingDayWeek\"\n\t\t\t\t  [allDayLabel]=\"allDayLabel\"\n\t\t\t\t  [hourParts]=\"hourParts\"\n\t\t\t\t  [autoSelect]=\"autoSelect\"\n\t\t\t\t  [hourSegments]=\"hourSegments\"\n\t\t\t\t  [eventSource]=\"eventSource\"\n\t\t\t\t  [markDisabled]=\"markDisabled\"\n\t\t\t\t  [weekviewHeaderTemplate]=\"weekviewHeaderTemplate||defaultWeekviewHeaderTemplate\"\n\t\t\t\t  [weekviewAllDayEventTemplate]=\"weekviewAllDayEventTemplate||defaultAllDayEventTemplate\"\n\t\t\t\t  [weekviewNormalEventTemplate]=\"weekviewNormalEventTemplate||defaultNormalEventTemplate\"\n\t\t\t\t  [weekviewAllDayEventSectionTemplate]=\"weekviewAllDayEventSectionTemplate||defaultWeekViewAllDayEventSectionTemplate\"\n\t\t\t\t  [weekviewNormalEventSectionTemplate]=\"weekviewNormalEventSectionTemplate||defaultNormalEventSectionTemplate\"\n\t\t\t\t  [locale]=\"locale\"\n\t\t\t\t  [dateFormatter]=\"dateFormatter\"\n\t\t\t\t  [dir]=\"dir\"\n\t\t\t\t  [scrollToHour]=\"scrollToHour\"\n\t\t\t\t  [preserveScrollPosition]=\"preserveScrollPosition\"\n\t\t\t\t  [lockSwipeToPrev]=\"lockSwipeToPrev\"\n\t\t\t\t  [lockSwipes]=\"lockSwipes\"\n\t\t\t\t  [startHour]=\"startHour\"\n\t\t\t\t  [endHour]=\"endHour\"\n\t\t\t\t  [spaceBetween]=\"spaceBetween\"\n\t\t\t\t  (onRangeChanged)=\"rangeChanged($event)\"\n\t\t\t\t  (onEventSelected)=\"eventSelected($event)\"\n\t\t\t\t  (onTimeSelected)=\"timeSelected($event)\"\n\t\t\t\t  (onTitleChanged)=\"titleChanged($event)\">\n\t\t\t</weekview>\n\t\t\t<dayview *ngSwitchCase=\"'day'\"\n\t\t\t\t [formatDayTitle]=\"formatDayTitle\"\n\t\t\t\t [formatHourColumn]=\"formatHourColumn\"\n\t\t\t\t [allDayLabel]=\"allDayLabel\"\n\t\t\t\t [hourParts]=\"hourParts\"\n\t\t\t\t [hourSegments]=\"hourSegments\"\n\t\t\t\t [eventSource]=\"eventSource\"\n\t\t\t\t [markDisabled]=\"markDisabled\"\n\t\t\t\t [dayviewAllDayEventTemplate]=\"dayviewAllDayEventTemplate||defaultAllDayEventTemplate\"\n\t\t\t\t [dayviewNormalEventTemplate]=\"dayviewNormalEventTemplate||defaultNormalEventTemplate\"\n\t\t\t\t [dayviewAllDayEventSectionTemplate]=\"dayviewAllDayEventSectionTemplate||defaultDayViewAllDayEventSectionTemplate\"\n\t\t\t\t [dayviewNormalEventSectionTemplate]=\"dayviewNormalEventSectionTemplate||defaultNormalEventSectionTemplate\"\n\t\t\t\t [locale]=\"locale\"\n\t\t\t\t [dateFormatter]=\"dateFormatter\"\n\t\t\t\t [dir]=\"dir\"\n\t\t\t\t [scrollToHour]=\"scrollToHour\"\n\t\t\t\t [preserveScrollPosition]=\"preserveScrollPosition\"\n\t\t\t\t [lockSwipeToPrev]=\"lockSwipeToPrev\"\n\t\t\t\t [lockSwipes]=\"lockSwipes\"\n\t\t\t\t [startHour]=\"startHour\"\n\t\t\t\t [endHour]=\"endHour\"\n\t\t\t\t [spaceBetween]=\"spaceBetween\"\n\t\t\t\t (onRangeChanged)=\"rangeChanged($event)\"\n\t\t\t\t (onEventSelected)=\"eventSelected($event)\"\n\t\t\t\t (onTimeSelected)=\"timeSelected($event)\"\n\t\t\t\t (onTitleChanged)=\"titleChanged($event)\">\n\t\t\t</dayview>\n\t\t</div>\n\t",
                    styles: ["\n\t\t:host > div {\n\t\t\theight: 100%;\n\t\t}\n\n\t\t.event-detail-container {\n\t\t\tborder-top: 2px darkgrey solid;\n\t\t}\n\n\t\t.no-events-label {\n\t\t\tfont-weight: bold;\n\t\t\tcolor: darkgrey;\n\t\t\ttext-align: center;\n\t\t}\n\n\t\t.event-detail {\n\t\t\tcursor: pointer;\n\t\t\twhite-space: nowrap;\n\t\t\ttext-overflow: ellipsis;\n\t\t}\n\n\t\t.monthview-eventdetail-timecolumn {\n\t\t\twidth: 110px;\n\t\t\toverflow: hidden;\n\t\t}\n\n\t\t.calendar-event-inner {\n\t\t\toverflow: hidden;\n\t\t\tbackground-color: #3a87ad;\n\t\t\tcolor: white;\n\t\t\theight: 100%;\n\t\t\twidth: 100%;\n\t\t\tpadding: 2px;\n\t\t\tline-height: 15px;\n\t\t}\n\n\t\t@media (max-width: 750px) {\n\t\t\t.calendar-event-inner {\n\t\t\t\tfont-size: 12px;\n\t\t\t}\n\t\t}\n\t"],
                    providers: [CalendarService]
                },] },
    ];
    CalendarComponent.ctorParameters = function () { return [
        { type: CalendarService, },
        { type: undefined, decorators: [{ type: Inject, args: [LOCALE_ID,] },] },
    ]; };
    CalendarComponent.propDecorators = {
        "currentDate": [{ type: Input },],
        "eventSource": [{ type: Input },],
        "calendarMode": [{ type: Input },],
        "formatDay": [{ type: Input },],
        "formatDayHeader": [{ type: Input },],
        "formatDayTitle": [{ type: Input },],
        "formatWeekTitle": [{ type: Input },],
        "formatMonthTitle": [{ type: Input },],
        "formatWeekViewDayHeader": [{ type: Input },],
        "formatHourColumn": [{ type: Input },],
        "showEventDetail": [{ type: Input },],
        "startingDayMonth": [{ type: Input },],
        "startingDayWeek": [{ type: Input },],
        "allDayLabel": [{ type: Input },],
        "noEventsLabel": [{ type: Input },],
        "queryMode": [{ type: Input },],
        "step": [{ type: Input },],
        "timeInterval": [{ type: Input },],
        "autoSelect": [{ type: Input },],
        "markDisabled": [{ type: Input },],
        "monthviewDisplayEventTemplate": [{ type: Input },],
        "monthviewInactiveDisplayEventTemplate": [{ type: Input },],
        "monthviewEventDetailTemplate": [{ type: Input },],
        "weekviewHeaderTemplate": [{ type: Input },],
        "weekviewAllDayEventTemplate": [{ type: Input },],
        "weekviewNormalEventTemplate": [{ type: Input },],
        "dayviewAllDayEventTemplate": [{ type: Input },],
        "dayviewNormalEventTemplate": [{ type: Input },],
        "weekviewAllDayEventSectionTemplate": [{ type: Input },],
        "weekviewNormalEventSectionTemplate": [{ type: Input },],
        "dayviewAllDayEventSectionTemplate": [{ type: Input },],
        "dayviewNormalEventSectionTemplate": [{ type: Input },],
        "dateFormatter": [{ type: Input },],
        "dir": [{ type: Input },],
        "scrollToHour": [{ type: Input },],
        "preserveScrollPosition": [{ type: Input },],
        "lockSwipeToPrev": [{ type: Input },],
        "lockSwipes": [{ type: Input },],
        "locale": [{ type: Input },],
        "startHour": [{ type: Input },],
        "endHour": [{ type: Input },],
        "spaceBetween": [{ type: Input },],
        "onCurrentDateChanged": [{ type: Output },],
        "onRangeChanged": [{ type: Output },],
        "onEventSelected": [{ type: Output },],
        "onTimeSelected": [{ type: Output },],
        "onTitleChanged": [{ type: Output },],
    };
    return CalendarComponent;
}());
export { CalendarComponent };
//# sourceMappingURL=calendar.js.map