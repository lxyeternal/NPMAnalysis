import { Component, Input, Output, EventEmitter, ViewChild, TemplateRef } from '@angular/core';
import { DatePipe } from '@angular/common';
import { Slides } from 'ionic-angular';
import { CalendarService } from './calendar.service';
var MonthViewComponent = (function () {
    function MonthViewComponent(calendarService) {
        this.calendarService = calendarService;
        this.autoSelect = true;
        this.dir = "";
        this.onRangeChanged = new EventEmitter();
        this.onEventSelected = new EventEmitter();
        this.onTimeSelected = new EventEmitter(true);
        this.onTitleChanged = new EventEmitter(true);
        this.views = [];
        this.currentViewIndex = 0;
        this.mode = 'month';
        this.direction = 0;
        this.moveOnSelected = false;
        this.inited = false;
        this.callbackOnInit = true;
    }
    MonthViewComponent.prototype.ngOnInit = function () {
        var _this = this;
        if (this.dateFormatter && this.dateFormatter.formatMonthViewDay) {
            this.formatDayLabel = this.dateFormatter.formatMonthViewDay;
        }
        else {
            var dayLabelDatePipe_1 = new DatePipe('en-US');
            this.formatDayLabel = function (date) {
                return dayLabelDatePipe_1.transform(date, this.formatDay);
            };
        }
        if (this.dateFormatter && this.dateFormatter.formatMonthViewDayHeader) {
            this.formatDayHeaderLabel = this.dateFormatter.formatMonthViewDayHeader;
        }
        else {
            var datePipe_1 = new DatePipe(this.locale);
            this.formatDayHeaderLabel = function (date) {
                return datePipe_1.transform(date, this.formatDayHeader);
            };
        }
        if (this.dateFormatter && this.dateFormatter.formatMonthViewTitle) {
            this.formatTitle = this.dateFormatter.formatMonthViewTitle;
        }
        else {
            var datePipe_2 = new DatePipe(this.locale);
            this.formatTitle = function (date) {
                return datePipe_2.transform(date, this.formatMonthTitle);
            };
        }
        this.slider.enableKeyboardControl(false);
        if (this.lockSwipeToPrev) {
            this.slider.lockSwipeToPrev(true);
        }
        if (this.lockSwipes) {
            this.slider.lockSwipes(true);
        }
        this.refreshView();
        this.inited = true;
        this.currentDateChangedFromParentSubscription = this.calendarService.currentDateChangedFromParent$.subscribe(function (currentDate) {
            _this.refreshView();
        });
        this.eventSourceChangedSubscription = this.calendarService.eventSourceChanged$.subscribe(function () {
            _this.onDataLoaded();
        });
    };
    MonthViewComponent.prototype.ngOnDestroy = function () {
        if (this.currentDateChangedFromParentSubscription) {
            this.currentDateChangedFromParentSubscription.unsubscribe();
            this.currentDateChangedFromParentSubscription = null;
        }
        if (this.eventSourceChangedSubscription) {
            this.eventSourceChangedSubscription.unsubscribe();
            this.eventSourceChangedSubscription = null;
        }
    };
    MonthViewComponent.prototype.ngOnChanges = function (changes) {
        if (!this.inited)
            return;
        var eventSourceChange = changes['eventSource'];
        if (eventSourceChange && eventSourceChange.currentValue) {
            this.onDataLoaded();
        }
        var lockSwipeToPrev = changes['lockSwipeToPrev'];
        if (lockSwipeToPrev) {
            this.slider.lockSwipeToPrev(lockSwipeToPrev.currentValue);
        }
        var lockSwipes = changes['lockSwipes'];
        if (lockSwipes) {
            this.slider.lockSwipes(lockSwipes.currentValue);
        }
    };
    MonthViewComponent.prototype.ngAfterViewInit = function () {
        var _this = this;
        setTimeout(function () {
            if (_this.slider) {
                _this.slider.enableKeyboardControl(false);
            }
        }, 300);
        var title = this.getTitle();
        this.onTitleChanged.emit(title);
    };
    MonthViewComponent.prototype.onSlideChanged = function () {
        if (this.callbackOnInit) {
            this.callbackOnInit = false;
            return;
        }
        var currentSlideIndex = this.slider.getActiveIndex();
        var direction = 0;
        var currentViewIndex = this.currentViewIndex;
        currentSlideIndex = (currentSlideIndex + 2) % 3;
        if (currentSlideIndex - currentViewIndex === 1) {
            direction = 1;
        }
        else if (currentSlideIndex === 0 && currentViewIndex === 2) {
            direction = 1;
            this.slider.slideTo(1, 0, false);
        }
        else if (currentViewIndex - currentSlideIndex === 1) {
            direction = -1;
        }
        else if (currentSlideIndex === 2 && currentViewIndex === 0) {
            direction = -1;
            this.slider.slideTo(3, 0, false);
        }
        this.currentViewIndex = currentSlideIndex;
        this.move(direction);
    };
    MonthViewComponent.prototype.move = function (direction) {
        if (direction === 0)
            return;
        this.direction = direction;
        if (!this.moveOnSelected) {
            var adjacentDate = this.calendarService.getAdjacentCalendarDate(this.mode, direction);
            this.calendarService.setCurrentDate(adjacentDate);
        }
        this.refreshView();
        this.direction = 0;
        this.moveOnSelected = false;
    };
    MonthViewComponent.prototype.createDateObject = function (date) {
        var disabled = false;
        if (this.markDisabled) {
            disabled = this.markDisabled(date);
        }
        return {
            date: date,
            events: [],
            label: this.formatDayLabel(date),
            secondary: false,
            disabled: disabled
        };
    };
    MonthViewComponent.getDates = function (startDate, n) {
        var dates = new Array(n);
        var current = new Date(startDate.getTime());
        var i = 0;
        current.setHours(12);
        while (i < n) {
            dates[i++] = new Date(current.getTime());
            current.setDate(current.getDate() + 1);
        }
        return dates;
    };
    MonthViewComponent.prototype.getViewData = function (startTime) {
        var startDate = startTime;
        var date = startDate.getDate();
        var month = (startDate.getMonth() + (date !== 1 ? 1 : 0)) % 12;
        var dates = MonthViewComponent.getDates(startDate, 42);
        var days = [];
        for (var i = 0; i < 42; i++) {
            var dateObject = this.createDateObject(dates[i]);
            dateObject.secondary = dates[i].getMonth() !== month;
            days[i] = dateObject;
        }
        var dayHeaders = [];
        for (var i = 0; i < 7; i++) {
            dayHeaders.push(this.formatDayHeaderLabel(days[i].date));
        }
        return {
            dates: days,
            dayHeaders: dayHeaders
        };
    };
    MonthViewComponent.prototype.getHighlightClass = function (date) {
        var className = '';
        if (date.hasEvent) {
            if (date.secondary) {
                className = 'monthview-secondary-with-event';
            }
            else {
                className = 'monthview-primary-with-event';
            }
        }
        if (date.selected) {
            if (className) {
                className += ' ';
            }
            className += 'monthview-selected';
        }
        if (date.current) {
            if (className) {
                className += ' ';
            }
            className += 'monthview-current';
        }
        if (date.secondary) {
            if (className) {
                className += ' ';
            }
            className += 'text-muted';
        }
        if (date.disabled) {
            if (className) {
                className += ' ';
            }
            className += 'monthview-disabled';
        }
        return className;
    };
    MonthViewComponent.prototype.getRange = function (currentDate) {
        var year = currentDate.getFullYear();
        var month = currentDate.getMonth();
        var firstDayOfMonth = new Date(year, month, 1);
        var difference = this.startingDayMonth - firstDayOfMonth.getDay();
        var numDisplayedFromPreviousMonth = (difference > 0) ? 7 - difference : -difference;
        var startDate = new Date(firstDayOfMonth.getTime());
        if (numDisplayedFromPreviousMonth > 0) {
            startDate.setDate(-numDisplayedFromPreviousMonth + 1);
        }
        var endDate = new Date(startDate.getTime());
        endDate.setDate(endDate.getDate() + 42);
        return {
            startTime: startDate,
            endTime: endDate
        };
    };
    MonthViewComponent.prototype.onDataLoaded = function () {
        var range = this.range;
        var eventSource = this.eventSource;
        var len = eventSource ? eventSource.length : 0;
        var startTime = range.startTime;
        var endTime = range.endTime;
        var utcStartTime = new Date(Date.UTC(startTime.getFullYear(), startTime.getMonth(), startTime.getDate()));
        var utcEndTime = new Date(Date.UTC(endTime.getFullYear(), endTime.getMonth(), endTime.getDate()));
        var currentViewIndex = this.currentViewIndex;
        var dates = this.views[currentViewIndex].dates;
        var oneDay = 86400000;
        var eps = 0.0006;
        for (var r = 0; r < 42; r += 1) {
            if (dates[r].hasEvent) {
                dates[r].hasEvent = false;
                dates[r].events = [];
            }
        }
        for (var i = 0; i < len; i += 1) {
            var event_1 = eventSource[i];
            var eventStartTime = new Date(event_1.startTime.getTime());
            var eventEndTime = new Date(event_1.endTime.getTime());
            var st = void 0;
            var et = void 0;
            if (event_1.allDay) {
                if (eventEndTime <= utcStartTime || eventStartTime >= utcEndTime) {
                    continue;
                }
                else {
                    st = utcStartTime;
                    et = utcEndTime;
                }
            }
            else {
                if (eventEndTime <= startTime || eventStartTime >= endTime) {
                    continue;
                }
                else {
                    st = startTime;
                    et = endTime;
                }
            }
            var timeDiff = void 0;
            var timeDifferenceStart = void 0;
            if (eventStartTime <= st) {
                timeDifferenceStart = 0;
            }
            else {
                timeDiff = eventStartTime.getTime() - st.getTime();
                if (!event_1.allDay) {
                    timeDiff = timeDiff - (eventStartTime.getTimezoneOffset() - st.getTimezoneOffset()) * 60000;
                }
                timeDifferenceStart = timeDiff / oneDay;
            }
            var timeDifferenceEnd = void 0;
            if (eventEndTime >= et) {
                timeDiff = et.getTime() - st.getTime();
                if (!event_1.allDay) {
                    timeDiff = timeDiff - (et.getTimezoneOffset() - st.getTimezoneOffset()) * 60000;
                }
                timeDifferenceEnd = timeDiff / oneDay;
            }
            else {
                timeDiff = eventEndTime.getTime() - st.getTime();
                if (!event_1.allDay) {
                    timeDiff = timeDiff - (eventEndTime.getTimezoneOffset() - st.getTimezoneOffset()) * 60000;
                }
                timeDifferenceEnd = timeDiff / oneDay;
            }
            var index = Math.floor(timeDifferenceStart);
            while (index < timeDifferenceEnd - eps) {
                dates[index].hasEvent = true;
                var eventSet = dates[index].events;
                if (eventSet) {
                    eventSet.push(event_1);
                }
                else {
                    eventSet = [];
                    eventSet.push(event_1);
                    dates[index].events = eventSet;
                }
                index += 1;
            }
        }
        for (var r = 0; r < 42; r += 1) {
            if (dates[r].hasEvent) {
                dates[r].events.sort(this.compareEvent);
            }
        }
        if (this.autoSelect) {
            var findSelected = false;
            for (var r = 0; r < 42; r += 1) {
                if (dates[r].selected) {
                    this.selectedDate = dates[r];
                    findSelected = true;
                    break;
                }
            }
            if (findSelected) {
                this.onTimeSelected.emit({
                    selectedTime: this.selectedDate.date,
                    events: this.selectedDate.events,
                    disabled: this.selectedDate.disabled
                });
            }
        }
    };
    ;
    MonthViewComponent.prototype.refreshView = function () {
        this.range = this.getRange(this.calendarService.currentDate);
        if (this.inited) {
            var title = this.getTitle();
            this.onTitleChanged.emit(title);
        }
        this.calendarService.populateAdjacentViews(this);
        this.updateCurrentView(this.range.startTime, this.views[this.currentViewIndex]);
        this.calendarService.rangeChanged(this);
    };
    MonthViewComponent.prototype.getTitle = function () {
        var currentViewStartDate = this.range.startTime;
        var date = currentViewStartDate.getDate();
        var month = (currentViewStartDate.getMonth() + (date !== 1 ? 1 : 0)) % 12;
        var year = currentViewStartDate.getFullYear() + (date !== 1 && month === 0 ? 1 : 0);
        var headerDate = new Date(year, month, 1, 12, 0, 0, 0);
        return this.formatTitle(headerDate);
    };
    MonthViewComponent.prototype.compareEvent = function (event1, event2) {
        if (event1.allDay) {
            return 1;
        }
        else if (event2.allDay) {
            return -1;
        }
        else {
            return (event1.startTime.getTime() - event2.startTime.getTime());
        }
    };
    MonthViewComponent.prototype.select = function (viewDate) {
        if (!this.views)
            return;
        var selectedDate = viewDate.date;
        var events = viewDate.events;
        if (!viewDate.disabled) {
            var dates = this.views[this.currentViewIndex].dates;
            var currentCalendarDate = this.calendarService.currentDate;
            var currentMonth = currentCalendarDate.getMonth();
            var currentYear = currentCalendarDate.getFullYear();
            var selectedMonth = selectedDate.getMonth();
            var selectedYear = selectedDate.getFullYear();
            var direction = 0;
            if (currentYear === selectedYear) {
                if (currentMonth !== selectedMonth) {
                    direction = currentMonth < selectedMonth ? 1 : -1;
                }
            }
            else {
                direction = currentYear < selectedYear ? 1 : -1;
            }
            this.calendarService.setCurrentDate(selectedDate);
            if (direction === 0) {
                var currentViewStartDate = this.range.startTime;
                var oneDay = 86400000;
                var selectedDayDifference = Math.floor((selectedDate.getTime() - currentViewStartDate.getTime() - (selectedDate.getTimezoneOffset() - currentViewStartDate.getTimezoneOffset()) * 60000) / oneDay);
                for (var r = 0; r < 42; r += 1) {
                    dates[r].selected = false;
                }
                if (selectedDayDifference >= 0 && selectedDayDifference < 42) {
                    dates[selectedDayDifference].selected = true;
                    this.selectedDate = dates[selectedDayDifference];
                }
            }
            else {
                this.moveOnSelected = true;
                this.slideView(direction);
            }
        }
        this.onTimeSelected.emit({
            selectedTime: selectedDate,
            events: events,
            disabled: viewDate.disabled
        });
    };
    MonthViewComponent.prototype.slideView = function (direction) {
        if (direction === 1) {
            this.slider.slideNext();
        }
        else if (direction === -1) {
            this.slider.slidePrev();
        }
    };
    MonthViewComponent.prototype.updateCurrentView = function (currentViewStartDate, view) {
        var currentCalendarDate = this.calendarService.currentDate;
        var today = new Date();
        var oneDay = 86400000;
        var selectedDayDifference = Math.floor((currentCalendarDate.getTime() - currentViewStartDate.getTime() - (currentCalendarDate.getTimezoneOffset() - currentViewStartDate.getTimezoneOffset()) * 60000) / oneDay);
        var currentDayDifference = Math.floor((today.getTime() - currentViewStartDate.getTime() - (today.getTimezoneOffset() - currentViewStartDate.getTimezoneOffset()) * 60000) / oneDay);
        for (var r = 0; r < 42; r += 1) {
            view.dates[r].selected = false;
        }
        if (selectedDayDifference >= 0 && selectedDayDifference < 42 && !view.dates[selectedDayDifference].disabled && (this.autoSelect || this.moveOnSelected)) {
            view.dates[selectedDayDifference].selected = true;
            this.selectedDate = view.dates[selectedDayDifference];
        }
        else {
            this.selectedDate =
                {
                    date: null,
                    events: [],
                    label: null,
                    secondary: null,
                    disabled: false
                };
        }
        if (currentDayDifference >= 0 && currentDayDifference < 42) {
            view.dates[currentDayDifference].current = true;
        }
    };
    MonthViewComponent.prototype.eventSelected = function (event) {
        this.onEventSelected.emit(event);
    };
    MonthViewComponent.decorators = [
        { type: Component, args: [{
                    selector: 'monthview',
                    template: "\n\t\t<div>\n\t\t\t<ion-slides #monthSlider [loop]=\"true\" [dir]=\"dir\" [spaceBetween]=\"spaceBetween\"\n\t\t\t\t    (ionSlideDidChange)=\"onSlideChanged()\">\n\t\t\t\t<ion-slide>\n\t\t\t\t\t<table *ngIf=\"0===currentViewIndex\"\n\t\t\t\t\t       class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[0].dayHeaders\">\n\t\t\t\t\t\t\t\t<small>{{dayHeader}}</small>\n\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t<tr *ngFor=\"let row of [0,1,2,3,4,5]\">\n\t\t\t\t\t\t\t<td *ngFor=\"let col of [0,1,2,3,4,5,6]\" tappable\n\t\t\t\t\t\t\t    (click)=\"select(views[0].dates[row*7+col])\"\n\t\t\t\t\t\t\t    [ngClass]=\"getHighlightClass(views[0].dates[row*7+col])\">\n\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{view: views[0], row: row, col: col}\">\n\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t\t<table *ngIf=\"0!==currentViewIndex\"\n\t\t\t\t\t       class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t<tr class=\"text-center\">\n\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[0].dayHeaders\">\n\t\t\t\t\t\t\t\t<small>{{dayHeader}}</small>\n\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t<tr *ngFor=\"let row of [0,1,2,3,4,5]\">\n\t\t\t\t\t\t\t<td *ngFor=\"let col of [0,1,2,3,4,5,6]\">\n\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewInactiveDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{view: views[0], row: row, col: col}\">\n\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t</ion-slide>\n\t\t\t\t<ion-slide>\n\t\t\t\t\t<table *ngIf=\"1===currentViewIndex\"\n\t\t\t\t\t       class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[1].dayHeaders\">\n\t\t\t\t\t\t\t\t<small>{{dayHeader}}</small>\n\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t<tr *ngFor=\"let row of [0,1,2,3,4,5]\">\n\t\t\t\t\t\t\t<td *ngFor=\"let col of [0,1,2,3,4,5,6]\" tappable\n\t\t\t\t\t\t\t    (click)=\"select(views[1].dates[row*7+col])\"\n\t\t\t\t\t\t\t    [ngClass]=\"getHighlightClass(views[1].dates[row*7+col])\">\n\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{view: views[1], row: row, col: col}\">\n\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t\t<table *ngIf=\"1!==currentViewIndex\"\n\t\t\t\t\t       class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t<tr class=\"text-center\">\n\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[1].dayHeaders\">\n\t\t\t\t\t\t\t\t<small>{{dayHeader}}</small>\n\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t<tr *ngFor=\"let row of [0,1,2,3,4,5]\">\n\t\t\t\t\t\t\t<td *ngFor=\"let col of [0,1,2,3,4,5,6]\">\n\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewInactiveDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{view: views[1], row: row, col: col}\">\n\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t</ion-slide>\n\t\t\t\t<ion-slide>\n\t\t\t\t\t<table *ngIf=\"2===currentViewIndex\"\n\t\t\t\t\t       class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[2].dayHeaders\">\n\t\t\t\t\t\t\t\t<small>{{dayHeader}}</small>\n\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t<tr *ngFor=\"let row of [0,1,2,3,4,5]\">\n\t\t\t\t\t\t\t<td *ngFor=\"let col of [0,1,2,3,4,5,6]\" tappable\n\t\t\t\t\t\t\t    (click)=\"select(views[2].dates[row*7+col])\"\n\t\t\t\t\t\t\t    [ngClass]=\"getHighlightClass(views[2].dates[row*7+col])\">\n\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{view: views[2], row: row, col: col}\">\n\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t\t<table *ngIf=\"2!==currentViewIndex\"\n\t\t\t\t\t       class=\"table table-bordered table-fixed monthview-datetable\">\n\t\t\t\t\t\t<thead>\n\t\t\t\t\t\t<tr class=\"text-center\">\n\t\t\t\t\t\t\t<th *ngFor=\"let dayHeader of views[2].dayHeaders\">\n\t\t\t\t\t\t\t\t<small>{{dayHeader}}</small>\n\t\t\t\t\t\t\t</th>\n\t\t\t\t\t\t</tr>\n\t\t\t\t\t\t</thead>\n\t\t\t\t\t\t<tbody>\n\t\t\t\t\t\t<tr *ngFor=\"let row of [0,1,2,3,4,5]\">\n\t\t\t\t\t\t\t<td *ngFor=\"let col of [0,1,2,3,4,5,6]\">\n\t\t\t\t\t\t\t\t<ng-template\n\t\t\t\t\t\t\t\t\t[ngTemplateOutlet]=\"monthviewInactiveDisplayEventTemplate\"\n\t\t\t\t\t\t\t\t\t[ngTemplateOutletContext]=\"{view: views[2], row: row, col: col}\">\n\t\t\t\t\t\t\t\t</ng-template>\n\t\t\t\t\t\t\t</td>\n\t\t\t\t\t\t<tr>\n\t\t\t\t\t\t</tbody>\n\t\t\t\t\t</table>\n\t\t\t\t</ion-slide>\n\t\t\t</ion-slides>\n\t\t\t<ng-template [ngTemplateOutlet]=\"monthviewEventDetailTemplate\"\n\t\t\t\t     [ngTemplateOutletContext]=\"{showEventDetail:showEventDetail, selectedDate: selectedDate, noEventsLabel: noEventsLabel}\">\n\t\t\t</ng-template>\n\t\t</div>\n\t",
                    styles: ["\n\t\t.text-muted {\n\t\t\tcolor: #999;\n\t\t}\n\n\t\t.table-fixed {\n\t\t\ttable-layout: fixed;\n\t\t}\n\n\t\t.table {\n\t\t\twidth: 100%;\n\t\t\tmax-width: 100%;\n\t\t\tbackground-color: transparent;\n\t\t}\n\n\t\t.table > thead > tr > th, .table > tbody > tr > th, .table > tfoot > tr > th, .table > thead > tr > td,\n\t\t.table > tbody > tr > td, .table > tfoot > tr > td {\n\t\t\tpadding: 8px;\n\t\t\tline-height: 20px;\n\t\t\tvertical-align: top;\n\t\t}\n\n\t\t.table > thead > tr > th {\n\t\t\tvertical-align: bottom;\n\t\t\tborder-bottom: 2px solid #ddd;\n\t\t}\n\n\t\t.table > thead:first-child > tr:first-child > th, .table > thead:first-child > tr:first-child > td {\n\t\t\tborder-top: 0\n\t\t}\n\n\t\t.table > tbody + tbody {\n\t\t\tborder-top: 2px solid #ddd;\n\t\t}\n\n\t\t.table-bordered {\n\t\t\t/*border: 1px solid #ddd;*/\n\t\t}\n\n\t\t.table-bordered > thead > tr > th, .table-bordered > tbody > tr > th, .table-bordered > tfoot > tr > th,\n\t\t.table-bordered > thead > tr > td, .table-bordered > tbody > tr > td, .table-bordered > tfoot > tr > td {\n\t\t\tborder: 1px solid #ddd;\n\t\t}\n\n\t\t.table-bordered > thead > tr > th, .table-bordered > thead > tr > td {\n\t\t\tborder-bottom-width: 2px;\n\t\t}\n\n\t\t.table-striped > tbody > tr:nth-child(odd) > td, .table-striped > tbody > tr:nth-child(odd) > th {\n\t\t\tbackground-color: #f9f9f9\n\t\t}\n\n\t\t.monthview-primary-with-event {\n\t\t\t/*background-color: #3a87ad;*/\n\t\t\tcolor: white;\n\t\t}\n\n\t\t.monthview-current {\n\t\t\t/*background-color: #f0f0f0;*/\n\t\t}\n\n\t\t.monthview-selected {\n\t\t\t/*background-color: #009900;*/\n\t\t\tcolor: white;\n\t\t}\n\n\t\t.monthview-datetable td.monthview-disabled {\n\t\t\tcolor: lightgrey;\n\t\t\tcursor: default;\n\t\t}\n\n\t\t.monthview-datetable th {\n\t\t\ttext-align: center;\n\t\t}\n\n\t\t.monthview-datetable td {\n\t\t\tcursor: pointer;\n\t\t\ttext-align: center;\n\t\t}\n\n\t\t.monthview-secondary-with-event {\n\t\t\t/*background-color: #d9edf7;*/\n\t\t}\n\n\t\t::-webkit-scrollbar,\n\t\t*::-webkit-scrollbar {\n\t\t\tdisplay: none;\n\t\t}\n\t"]
                },] },
    ];
    MonthViewComponent.ctorParameters = function () { return [
        { type: CalendarService, },
    ]; };
    MonthViewComponent.propDecorators = {
        "slider": [{ type: ViewChild, args: ['monthSlider',] },],
        "monthviewDisplayEventTemplate": [{ type: Input },],
        "monthviewInactiveDisplayEventTemplate": [{ type: Input },],
        "monthviewEventDetailTemplate": [{ type: Input },],
        "formatDay": [{ type: Input },],
        "formatDayHeader": [{ type: Input },],
        "formatMonthTitle": [{ type: Input },],
        "eventSource": [{ type: Input },],
        "startingDayMonth": [{ type: Input },],
        "showEventDetail": [{ type: Input },],
        "noEventsLabel": [{ type: Input },],
        "autoSelect": [{ type: Input },],
        "markDisabled": [{ type: Input },],
        "locale": [{ type: Input },],
        "dateFormatter": [{ type: Input },],
        "dir": [{ type: Input },],
        "lockSwipeToPrev": [{ type: Input },],
        "lockSwipes": [{ type: Input },],
        "spaceBetween": [{ type: Input },],
        "onRangeChanged": [{ type: Output },],
        "onEventSelected": [{ type: Output },],
        "onTimeSelected": [{ type: Output },],
        "onTitleChanged": [{ type: Output },],
    };
    return MonthViewComponent;
}());
export { MonthViewComponent };
//# sourceMappingURL=monthview.js.map