// This is a node module used by test_sn_core.js to test the _$construct function

( function () {
  _$construct( 'exports', { location: [0,0], global_props: "/etc/whatever.json" }, module );
  module.exports.prototype._$init = function () {
    console.log( 'This is the test node module\'s _$init function' );
  };
  module.exports.prototype.moveTo = function( new_location ) {
    this.location = new_location;
  };
} ) ();