// Copyright (c) 2013 Smithee, Spelvin, Agnew & Plinge, All Rights Reserved
//

// This code is intended to both test the sn-core functionality as well as provide a set of examples of how it can be used. But
// it's not really a good example of why some people prefer "functional programming."

// Before you can use sn-core, you have to require it. Note that we don't assign the module to a variable, which is common in
// node applications. This is because we duck-punch directly into Object, Array and Function prototypes.
             require( './sn-core.js' );
var assert = require( 'assert' );

// _$punch() : This function duck-punches the function it's called against into a specified object with a given name. So if
// we define the following function and punch it into Object.prototype, we should be able to call it against any object.

function _concatenate_keys() {
  var rv = "";
  for( var i in this ) {
    rv += i;
  }
  return rv;
}

_concatenate_keys._$punch( Object.prototype, '_$catkeys' );

var fixture_1 = {
  "one": undefined,
  "two": null,
  "three": true,
  "four": false,
  "five": 801,
  "six": -901.25,
  "seven": "eight",
  "eight": [ 0, 1, 2 ],
  "nine": { "one": "two", "three": "four" }
};

var catted_keys = fixture_1._$catkeys();
assert.equal( catted_keys, "onetwothreefourfivesixseveneightnine" );
console.log( "Concatenated keys of a test object and got this:" );
console.log( catted_keys );

// You can also call _$punch() on anonymous functions like this:

( function() {
  var rv = {};
  this._$each( function( a ) {
    rv[ a ] = rv[ a ]?rv[ a ] + 1:1;
  } );
  return rv;
} )._$punch( String.prototype, '_$freq' );

// This function calculates a frequency graph of the letters in a string. Note you don't have to begin your function names with
// '_$'. We just do it so it's easier to see which functions are from this package.

console.log( "I duck-punched an anonymous function into String.prototype._$freq and this is what i got" );
console.log( "now is the winter of our discontent"._$freq() );

// The _$punch() function uses the Object.defineProperty() function to insert functions into objects. If we didn't do that, it
// would be possible that function names like '_$each' and '_$map' would show up as enumerable properties of each object you
// create. This next bit of code tests to make sure we didn't do that.

var areFunctionNamesEnumerable = false;

for( var i in fixture_1 ) {
  if( String( i ).substr(0,2) == '_$' ) {
    areFunctionNamesEnumerable = true;
    break;
  }
}

assert.equal( areFunctionNamesEnumerable, false );
console.log( "Okay. Looks like functions we added to Object.prototype aren't enumerable. This is good." );

var fixture_2 = [ 2, 3, 5, 7, 11, 13, 17 ];

for( var i in fixture_2 ) {
  if( String( i ).substr(0,2) == '_$' ) {
    areFunctionNamesEnumerable = true;
    break;
  }
}

assert.equal( areFunctionNamesEnumerable, false );
console.log( "Okay. Looks like functions we added to Array.prototype aren't enumerable. This is good." );

// _$each() : iterate through each element in an Object, Array or String calling a programmer provided function on each element.

// You might actually be familiar with this kind of function. jQuery, prototype.js and underscore.js provide similar capabilities.
// _$each works with regular objects, arrays and strings. Here's an example:

console.log( "printing out some prime numbers" );

fixture_2._$each( function( e, i ) {
  console.log( "prime number " + ( i + 1 ) + " is " + e );
  assert( e, fixture_2[ i ] );
} );

// You don't have to accept both the e & i parameters.
var count_even = 0;
fixture_2._$each( function( e ) {
  if( e % 2 == 0 ) {
    count_even++;
  }
} );
assert.equal( count_even, 1 );

// By default, this is the object you called the _$each against.
[ "testing" ]._$each( function( ) {
  assert.equal( "object", typeof this );
  assert.equal( 1, this.length );
  assert.equal( "testing", this[ 0 ] );
} );

// You can use the bind() function to bind this to a different object. In this example, we bind this to [4, 5, 6] and call a function on [1, 2, 3]
var result = 0;
[ 1, 2, 3 ]._$each( function ( e, i ) {
  result += e * this[ i ];
}.bind( [4, 5, 6] ) );
assert.equal( 32, result );

// _$each also works on regular objects (associtive arrays). remember the catted_keys example above? here's how we do it with the _$each function:
var catted_keys = ""
fixture_1._$each( function( e, i ) {
  assert.equal( this[ i ], e );
  catted_keys += i;
} );

assert.equal( catted_keys, "onetwothreefourfivesixseveneightnine" );

// And we can call _$each on a string.

var length = 0;
"for great justice"._$each( function( e ) {
  length++;
} );
assert.equal( length, "for great justice".length );

// And calls to _$each (and most other object iterating functions) return a reference to the object you called it against, so you can chain calls:

console.log( "printing out some of the fibbonacci sequence" );
var fibbonacci = [0, 1, 1, 2, 3, 5, 8, 13];
var fib_squared = [0, 1, 1, 4, 9, 25, 64, 169];
fibbonacci.
  _$each( function( e, i ) {
    console.log( "F" + i + " is " + e );
    assert.equal( e, fibbonacci[ i ] );
  } ).
  _$each( function( e, i ) {
    var e_squared = e * e;
    console.log( "F" + i + " squared is " + e_squared );
    assert.equal( e_squared, fib_squared[ i ] );
  } );

// and if you return TRUE from the function passed to _$each, it will break out of the loop. be careful
// doing this on an Object cause we can't guarantee the order in which elements are evaluated.
var count = 0;
( { one: true, two: 12, three: 'string' } )._$each( function( ) { count++; return true; } );
assert.equal( 1, count );

count = 0;
[ undefined, true, 12, 'string' ]._$each( function( e ) { count++; return 'number' == typeof e; } );
assert.equal( 3, count );

count = 0;
"01245"._$each( function( e ) { count++; return '4' == e; } );
assert.equal( 4, count );

// The _$map function can be called on an Object, Array or String. It takes a function that is called on each element of the receiver.
// The return values of the function are collected into a new collection and returned.

result = fixture_1._$map( function( e ) {
  return typeof e;
} );

assert.equal( result.one, "undefined" );
assert.equal( result.two, "object" );
assert.equal( result.three, "boolean" );
assert.equal( result.four, "boolean" );
assert.equal( result.five, "number" );
assert.equal( result.six, "number" );
assert.equal( result.seven, "string" );
assert.equal( result.eight, "object" );
assert.equal( result.nine, "object" );

// And map functions can be chained as well, so you could do something like this:
result = fixture_2.
  _$map( function( e ) { return e * e; } ).
  _$map( function( e ) { return e + 1; } );

assert.equal( result[0], 5 );
assert.equal( result[1], 10 );
assert.equal( result[2], 26 );
assert.equal( result[3], 50 );
assert.equal( result[4], 122 );
assert.equal( result[5], 170 );
assert.equal( result[6], 290 );

// But doing something like this is probably more interesting. You can apply a sequence of functions to each element
// in an array relatively easily:

result = fibbonacci.
  _$map( Math.sqrt ).
  _$map( Math.ceil );

// This is the equivalent of doing the following, but with much less code:

var result = [];
for( var i = 0, il = fibbonacci.length; i < il; i++ ) {
  result.push( Math.sqrt( fibbonacci[ i ] ) );
}
for( var i = 0, il = result.length; i < il; i++ ) {
  result[ i ] = Math.ceil( result[ i ] );
}

// And for fun, we can use the _$map function to create a ROT13 (Caesar Cipher) function:
function ROT13( input ) {
  return input.
    _$map( function( e ) {
      var a = e.toUpperCase().charCodeAt(0) - 65;
      return String.fromCharCode( ((a<0||a>25)?a:(a+13)%26)+65 );
  } );
}

assert.equal( "GUVF VF N GRFG 123", ROT13( "this is a test 123" ) );

// The _$fold function is used to extract a scalar from a collection. Pass it a function that returns a scalar given the
// previous invocation's scalar, the current element and the index.

result = fibbonacci.
  _$fold( function( base, e, i ) {
    return base + e;
  } );
assert.equal( result, 33 );

// Except you don't really have to return a scalar. In fact, you can do all sorts of interesting things:

function _calc( base, e ) {
  switch( e ) {
  case '0':
  case '1':
  case '2':
  case '3':
  case '4':
  case '5':
  case '6':
  case '7':
  case '8':
  case '9':
    base[0] *= 10;
    base[0] += Number(e);
    break;
  case '+':
    base[0] += base[1].pop();
    break;
  case '-':
    base[0] -= base[1].pop();
    break;
  case '*':
    base[0] *= base[1].pop();
    break;
  case '/':
    base[0] /= base[1].pop();
    break;
  case '\n':
    base[1].push( base[0] );
    base[0] = 0;
    break;
  }

  return base;
}

result = [ '9', '0', '1', '\n', '2', '5', '+' ]._$fold( _calc, [ 0, [] ] );
assert.equal( 926, result[0] );

// And you can call _$fold on strings:

result = "This is a test"._$fold( function( base, e ) {
  if( e.charCodeAt(0) < 96 ) {
    return base + "*";
  }
  return base + e.toUpperCase();
}, "" );

assert.equal( "*HIS*IS*A*TEST", result );

// Here's another great usage of the fold function:
function array_equals( source, dest ) {
  return source._$fold( function (base, e, i) {
    return base && ( e == dest[ i ] );
  }, true );
}

// JavaScript's reverse() function does a "reverse in place." i.e. - it modifies the source array. The
// sn-core _$reverse() method makes a shallow copy of the source before reversing.

result = fibbonacci._$reverse();
assert.equal( array_equals( [ 13, 8, 5, 3, 2, 1, 1, 0 ], result ), true );

// The _$negate function allows you to create a function that negates another function. For example:

var fixture_3 = [ 1, 2, 0, 3, 1 ];

function is_equal_to_one( value ) {
  return value == 1;
}

var not_equal_to_one = is_equal_to_one._$negate();

var not_ones = fixture_3._$map( not_equal_to_one );

assert.equal( typeof not_ones, "object" );
assert.equal( not_ones.length, 5 );
assert.equal( not_ones[0], false );
assert.equal( not_ones[1], true );
assert.equal( not_ones[2], true );
assert.equal( not_ones[3], true );
assert.equal( not_ones[4], false );

// The _$any, _$all and _$none functions will tell you if any, all or none of the members of an object return true when passed as
// parameters to a user-provided function. In this example, we check to make sure that the is_equal_to_one() function returns true
// for at least one member of fixture_3:

assert.equal( fixture_3._$any( is_equal_to_one ), true );

// This shows how to test that all elements in fixture_3 are less than 10:

assert.equal( fixture_3._$all( function ( e ) { return e < 10; } ), true );

// And this example shows that none of the elements in fixture_2 are equal to 1.

assert.equal( fixture_2._$none( is_equal_to_one ), true );

//_$pluck is a nice tool to create an array of objects 'plucked' from a collection of objects

var pluck_from_here = [
  { status: 200, body: "Yay! Successful!" },
  { status: 201, body: "Yay! New Object Created!" },
  { status: 404, body: "Badness! Resource Not Found!" }
];

result = pluck_from_here._$pluck( 'status' );
assert.equal( 200, result[0] );
assert.equal( 201, result[1] );
assert.equal( 404, result[2] );
assert.equal( 3, result.length );

console.log( result );

var or_pluck_from_here = {
  "http://example.org/whatever": {
    status: 200,
    response: { success: true, message: "this is just a test, but a successful test" }
  },
  "http://example.org/whoknows": {
    status: 200,
    response: { success: false, message: "this is an app level failure." }
  },
  "http://example.org/idontknow": {
    status: 404
  }
};

result = or_pluck_from_here._$pluck( 'status' );
assert.equal( 3, result.length );

console.log( result );


// JavaScript has an existing function for returning a list of keys in an associative array. But it's implemented
// as a 'static' method on the Object object. sn-core's _$keys function is a property of Object so you can do
// something like this:

console.log( fixture_1._$keys() );

// instead of:

console.log( Object.keys( fixture_1 ) );

// there's no real difference except in how it's called.

// the _$merge function does a recursive merge of two objects.
var dest = [1, 2, 3];
var source = [ undefined, 7 ];
dest._$merge( source );
assert.equal( dest[0], 1 );
assert.equal( dest[1], 7 );
assert.equal( dest[2], 3 );

dest = { a: { b: 1, c: 2 } };
source = { a: { c: "test", d: 4 } };
dest._$merge( source );
assert.equal( dest.a.b, 1 );
assert.equal( dest.a.c, "test" );
assert.equal( dest.a.d, 4 );

// the _$shallow function makes a shallow copy of properties from one object into another. Note that it overwrites values in
// the destination if they're present in the source.

dest = { a: 1, b: 99 };
source = { b: 2, c: 3, d: 4 };

dest._$shallow( source );

assert.equal( dest.a, 1 );
assert.equal( dest.b, 2 );
assert.equal( dest.c, 3 );
assert.equal( dest.d, 4 );

// The _$shallow function is useful in situations like this, where you might want a constructor that creates instances with
// both options and defaults.

function SampleObject( options ) {
  var defaults = {
    path: "/etc/whatever.json",
    count: 10
  };
  this._$shallow( defaults )._$shallow( options?options:{} );
}

var a = new SampleObject();
assert.equal( a.path, "/etc/whatever.json" );
assert.equal( a.count, 10 );
assert.equal( a.other, undefined );

var b = new SampleObject({});
assert.equal( b.path, "/etc/whatever.json" );
assert.equal( b.count, 10 );
assert.equal( b.other, undefined );

var c = new SampleObject({other: 12});
assert.equal( c.path, "/etc/whatever.json" );
assert.equal( c.count, 10 );
assert.equal( c.other, 12 );

var d = new SampleObject({other: 12, path: "./here.json"});
assert.equal( d.path, "./here.json" );
assert.equal( d.count, 10 );
assert.equal( d.other, 12 );

// This is a pattern used frequently enough, I added the _$construct function to make it slightly less verbose

_$construct( 'OtherSample', { log: "/var/log/whatever.csv" } );

a = new OtherSample();
assert.equal( a.log, "/var/log/whatever.csv");

b = new OtherSample({});
assert.equal( b.log, "/var/log/whatever.csv");

c = new OtherSample({count: 21});
assert.equal( c.log, "/var/log/whatever.csv");
assert.equal( c.count, 21 );

d = new OtherSample({count: 21, log: "/var/log/blargh.log"});
assert.equal( d.log, "/var/log/blargh.log");
assert.equal( d.count, 21 );

// And if you define a function _$init for the newly constructed class, it will be called as part of the constructor:

OtherSample.prototype._$init = function () {
  console.log( "calling the OtherSample() init function" );
  this.count = 99;
};

var e = new OtherSample({count: 21, log: "/var/log/blargh.log"});
assert.equal( e.log, "/var/log/blargh.log");
assert.equal( e.count, 99 );

// And you can use the _$construct function in node modules. look at the test_node_module.js file for an example.
if( require ) {
  var foo = require( './test_node_module' );
  var bar = new foo();

  assert.equal( bar.global_props, '/etc/whatever.json' );

  var baz = new foo( { global_props: './dingo.json' } );
  assert.equal( baz.global_props, './dingo.json' );
}

// Partial application allows you to create a new function from an old function with some parameters still applied.

function _add_two_numbers( x, y ) { return x + y; }
var _add_four = _add_two_numbers._$partial( 4 );

assert.equal( _add_four( 7 ), 11 );

// The _$compose function creates a function that calls one function on the output of a second function:

function _multiply_by_three( x ) { return 3 * x; }
var _add_then_multiply = _multiply_by_three._$compose( _add_four );

assert.equal( _add_then_multiply( 7 ), 33 ); // ( 7 + 4 ) * 3 == 33

// The _$flip function reverses the order of parameters. This can be useful when combined with partial application.

function _divide_some_numbers ( x, y ) { return x / y; }
_invert_some_numbers = _divide_some_numbers._$flip();

assert.equal( _divide_some_numbers( 2, 5 ), .4 );
assert.equal( _invert_some_numbers( 2, 5 ), 2.5 );

var items = [];

function _log_this( param, value ) {
  console.log( "logging: " + ((param)?param.toString():"undefined") );
  items.push( value );
}

_log_this( "line 1", 33 );
_log_this._$nextTick( "line 3", 77 );
_log_this( "line 2", 44 );

// But wait, we've not called _log_this for a third time yet:
assert.equal( items.length, 2 );
assert.equal( items[0], 33 );
assert.equal( items[1], 44 );

( function () {
  // this _should_ be called after third parameter has been pushed onto the items stack
  assert.equal( items.length, 3 );
  assert.equal( items[2], 77 );
} )._$nextTick();

// Test counter

fixture_3 = [ 5, 4, 3, 2, 1 ];
var total = 0;
var _cfunc = fixture_3.length._$counter( function () { assert.equal( total, 15 ); } );
fixture_3._$each( function ( e ) { total += e; _cfunc() } );

// Test capture

( function() {
  JSON.parse( '{ "test": "whatever" }' );
  assert( true, "If we make it to this line, we didn't get an error." );
  console.log( "correctly avoided calling _error_handler when _$capture clause didn't raise an exception" );
} )._$capture( function () {
  assert( false, "If we make it to this line, then the _error_handler is being incorrectly called" );
} )._$nextTick();

( function() {
  // note: the JSON below doesn't have double quotes around the test key.
  JSON.parse( '{ test: "whatever" }' );
  assert( false, "If we make it to this line, we didn't catch the exception." );
} )._$capture( function ( err ) {
  assert( true, "If we make it to this line, then the _error_handler correctly caught the exception" );
  assert.equal( err.name, 'SyntaxError', "was expecting a syntax error" );
  console.log( "correctly called _error_handler when _$capture _clause generated a SyntaxError" );
} )._$nextTick();
