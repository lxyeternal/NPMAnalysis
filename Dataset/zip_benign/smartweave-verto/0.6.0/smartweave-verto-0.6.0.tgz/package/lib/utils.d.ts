import Transaction from 'arweave/node/lib/transaction';
import Arweave from 'arweave';
import { GQLEdgeInterface } from './interfaces/gqlResult';
interface UnformattedTag {
    name: string;
    value: string;
}
export declare function getTag(tx: Transaction, name: string): any;
/**
 * Unpacks string tags from a Tx and puts in a KV map
 * Tags that appear multiple times will be converted to an
 * array of string values, ordered as they appear in the tx.
 *
 * @param tx
 */
export declare function unpackTags(tx: Transaction): Record<string, string | string[]>;
export declare function formatTags(tags: UnformattedTag[]): Record<string, string | string[]>;
export declare function arrayToHex(arr: Uint8Array): string;
export declare function log(arweave?: Arweave, ...str: string[]): void;
export declare function normalizeContractSource(contractSrc: string): string;
/**
 * Function that evaluates the `settings` key of the state and return a valid Map.
 * @param state
 * @returns {Map} settings as a map
 */
export declare function evalSettings(state: any): Map<string, any>;
/**
 * Checks if edge has multiple tags with the name 'Contract', which means multiple interactions.
 * @param gqlResult
 * @returns {boolean}
 */
export declare function hasMultipleinteractions(gqlResult: GQLEdgeInterface): boolean;
export {};
