import Arweave from 'arweave';
import Transaction from 'arweave/node/lib/transaction';
import { JWKInterface } from 'arweave/node/lib/wallet';
/**
 * Simulates the creation of a new contract from a contract, so that the cost for the creation can be checked
 * Returns the transaction describing the creation simulation.
 *
 * @param arweave       an Arweave client instance
 * @param wallet        a wallet private or public key
 * @param initState     the contract initial state, as a JSON string.
 * @param contractSrc optional the contract source as string.
 */
export declare function simulateCreateContractFromSource(arweave: Arweave, wallet: JWKInterface | 'use_wallet', initState: string, contractSrc: string, reward?: string): Promise<Transaction>;
/**
 * Simulate the creation of a contract from an existing contract source tx, with an initial state.
 * Returns the contract id.
 *
 * @param arweave   an Arweave client instance
 * @param wallet    a wallet private or public key
 * @param srcTxId   the contract source Tx id.
 * @param state     the initial state, as a JSON string.
 * @param tags          an array of tags with name/value as objects.
 * @param target        if needed to send AR to an address, this is the target.
 * @param winstonQty    amount of winston to send to the target, if needed.
 */
export declare function simulateCreateContractFromTx(arweave: Arweave, wallet: JWKInterface | 'use_wallet', srcTxId: string, state: string, tags?: {
    name: string;
    value: string;
}[], target?: string, winstonQty?: string, reward?: string): Promise<Transaction>;
/**
 * Create a new contract from a contract source file and an initial state.
 * Returns the contract id.
 *
 * @param arweave       an Arweave client instance
 * @param wallet        a wallet private or public key
 * @param contractSrc   the contract source as string.
 * @param initState     the contract initial state, as a JSON string.
 */
export declare function createContract(arweave: Arweave, wallet: JWKInterface | 'use_wallet', contractSrc: string, initState: string, reward?: string): Promise<string>;
/**
 * Create a new contract from an existing contract source tx, with an initial state.
 * Returns the contract id.
 *
 * @param arweave   an Arweave client instance
 * @param wallet    a wallet private or public key
 * @param srcTxId   the contract source Tx id.
 * @param state     the initial state, as a JSON string.
 * @param tags          an array of tags with name/value as objects.
 * @param target        if needed to send AR to an address, this is the target.
 * @param winstonQty    amount of winston to send to the target, if needed.
 */
export declare function createContractFromTx(arweave: Arweave, wallet: JWKInterface | 'use_wallet', srcTxId: string, state: string, tags?: {
    name: string;
    value: string;
}[], target?: string, winstonQty?: string, reward?: string): Promise<string>;
