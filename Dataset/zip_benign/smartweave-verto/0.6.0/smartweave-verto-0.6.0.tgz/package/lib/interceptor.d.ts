export declare type InterceptorFn = (contractId: string, state: any, interactionNumber: number, height: number) => Promise<void> | void;
export declare type InterceptorObj = {
    interceptor: InterceptorFn;
    contractId: string;
};
export declare class Interceptors {
    static interceptors: InterceptorObj[];
    static setContractInterceptor(contractId: string, interceptor: InterceptorFn): number;
    static setGlobalInterceptor(interceptor: InterceptorFn): number;
    static callInterceptors(contractId: string, state: any, interactionNumber: number, height: number): Promise<void[]>;
}
