import Arweave from 'arweave';
import { ContractHandler } from './contract-step';
import { SmartWeaveGlobal } from './smartweave-global';
/**
 * Loads the contract source, initial state and other parameters
 *
 * @param arweave     an Arweave client instance
 * @param contractID  the Transaction Id of the contract
 */
export declare function loadContract(arweave: Arweave, contractID: string, contractSrcTXID?: string): Promise<{
    id: string;
    contractSrcTXID: string;
    contractSrc: string;
    initState: string;
    minFee: any;
    contractTX: import("arweave/node/lib/transaction").default;
    handler: ContractHandler;
    swGlobal: SmartWeaveGlobal;
}>;
/**
 * Translates a contract source code into a Js function that can be called, and sets
 * up two globals, SmartWeave and the ContractError exception.
 *
 * At the moment this uses the Function() constructor (basically the same as eval),
 * But the design is geared toward switching to Realms or something like
 * https://github.com/justjake/quickjs-emscripten. (probably the latter)
 *
 * In the current implemention, using Function(), the 'globals' are actually
 * just lexically scoped vars, unique to each instance of a contract.
 *
 * @param contractSrc the javascript source for the contract. Must declare a handle() function
 */
export declare function createContractExecutionEnvironment(arweave: Arweave, contractSrc: string, contractId: string, contractOwner: string): {
    handler: ContractHandler;
    swGlobal: SmartWeaveGlobal;
};
