# makehaus-lib

MakeHaus library required by `Glue` and `node-red-contrib-makehaus`.

## Notes
- For StreamDeck Support you must have `@fortawesome/fontawesome-pro` installed. It is not listed as a peer dependency / optional dependency as it is a paid package and the installation still would fail if it was listed as such and could not be found.
- A note about colors:
    - Colors for RGB LED Buttons are processed as hsl. All methods and properties take that formatted as a single 32-bit unsigned integer which can be computed as follows:
        - Bytes 0-1: 16-bit Hue (0-65535)
        - Byte 2: 8-bit Saturation (0-255)
        - Byte 3: 8-bit Lightness (0-255)
    - You can use the `hsl(hue, saturation, lightness)` method to convert a color to this format
        - `hue`: 0 - 360
        - `saturation`: 0 - 1
        - `lightness`: 0 - 1
        - To get the vivid, purest color, use a `saturation` of `1` and a `lightness` of `0.5` (defaults)
    - There are also lots of colors predefined in the `COLORS` constant.
