# Changelog

## 2.0.1 (2023-08-04)
- fix: missing `COLORS` and `hsl`

## 2.0.0 (2023-08-04)
- feat: published new major version