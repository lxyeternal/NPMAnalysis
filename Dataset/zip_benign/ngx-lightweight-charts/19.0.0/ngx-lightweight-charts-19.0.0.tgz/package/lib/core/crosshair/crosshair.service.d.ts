import { TVChart } from "../tv-chart";
export declare class CrosshairService<HorzScaleItem> {
    #private;
    readonly crosshairPosition$: import("rxjs").Observable<{
        [key: string]: any;
        [key: number]: any;
    } | null>;
    constructor();
    register(charts: TVChart<any, HorzScaleItem>[], clearExisting?: boolean): void;
    deregister(chart: TVChart<any, HorzScaleItem>): void;
    destroy(): void;
}
