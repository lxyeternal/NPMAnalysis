import { Observable } from "rxjs";
import { IChartApiBase, MouseEventParams, Time } from "lightweight-charts";
import { ChartSubscriptions } from "./chart.types";
export declare class ChartStreams<HorzScaleItem = Time> implements ChartSubscriptions<HorzScaleItem> {
    #private;
    readonly crossHairMove$: Observable<MouseEventParams<HorzScaleItem>>;
    readonly click$: Observable<MouseEventParams<HorzScaleItem>>;
    readonly dblClick$: Observable<MouseEventParams<HorzScaleItem>>;
    constructor(chart: IChartApiBase<HorzScaleItem>);
    destroy(): void;
}
