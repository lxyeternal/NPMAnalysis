import { Observable } from "rxjs";
export type MultiStreamOutput<T> = {
    source: Observable<T>;
    data: T;
};
export declare class MultiStream<T> {
    #private;
    readonly stream$: Observable<MultiStreamOutput<T> | undefined>;
    get currentValue(): T | undefined;
    updateObservables(streams: Observable<T>[]): void;
    destroy(): void;
}
export declare function isMultiStreamOutput<T>(arg: MultiStreamOutput<T> | undefined): arg is MultiStreamOutput<T>;
export declare function isOutputWithData<T>(update: MultiStreamOutput<T> | undefined): update is MultiStreamOutput<NonNullable<T>>;
