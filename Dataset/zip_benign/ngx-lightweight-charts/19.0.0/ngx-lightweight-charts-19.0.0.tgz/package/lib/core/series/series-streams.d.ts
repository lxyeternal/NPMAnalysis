import { Observable } from "rxjs";
import { DataChangedScope, ISeriesApi, SeriesType, Time } from "lightweight-charts";
import { SeriesSubscriptions } from "./series.types";
export declare class SeriesStreams<T extends SeriesType, HorzScaleItem = Time> implements SeriesSubscriptions {
    #private;
    readonly dataChange$: Observable<DataChangedScope>;
    constructor(series: ISeriesApi<T, HorzScaleItem>);
    destroy(): void;
}
