import { TimescaleSubscriptions } from "./timescale.types";
import { ITimeScaleApi, LogicalRange, Range, Time } from "lightweight-charts";
import { Observable } from "rxjs";
export declare class TimescaleStreams<HorzScaleItem = Time> implements TimescaleSubscriptions<HorzScaleItem> {
    #private;
    readonly visibleTimeRangeChange$: Observable<Range<HorzScaleItem> | null>;
    readonly visibleLogicalRangeChange$: Observable<LogicalRange | null>;
    readonly sizeChange$: Observable<number>;
    constructor(timescale: ITimeScaleApi<HorzScaleItem>);
    destroy(): void;
}
