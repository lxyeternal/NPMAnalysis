import { LogicalRange, MouseEventParams, Point, Range } from "lightweight-charts";
import { Observable } from "rxjs";
export type Syncable = {
    setVisibleLogicalRange(range: Range<number>): void;
    getVisibleLogicalRange(): LogicalRange | null | undefined;
    readonly visibleLogicalRangeChange$: Observable<LogicalRange | null>;
};
export type SyncableWithCrosshair<HorzScaleItem> = Syncable & {
    setCrossHairPositionByPoint(point: Point, time?: HorzScaleItem): void;
    clearCrosshairPosition(): void;
    readonly crossHairMove$: Observable<MouseEventParams<HorzScaleItem>>;
};
export declare function isSyncableWithCrosshair<HorzScaleItem>(arg: Syncable): arg is SyncableWithCrosshair<HorzScaleItem>;
export declare class SyncService<HorzScaleItem> {
    #private;
    readonly visibleLogicalRange$: Observable<LogicalRange>;
    readonly crosshairPosition$: Observable<MouseEventParams<HorzScaleItem>>;
    constructor();
    register(arg: Syncable[], clearExisting?: boolean): void;
    deregister(arg: Syncable): void;
    destroy(): void;
}
