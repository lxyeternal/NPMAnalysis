import { ChartOptions, DeepPartial, IChartApiBase, IHorzScaleBehavior, Time } from "lightweight-charts";
import { ChartSubscriptions } from "./chart.types";
import { TimescaleSubscriptions } from "../timescale";
export type ChartFactoryReturnType<HorzScaleItem = Time> = {
    chart: IChartApiBase<HorzScaleItem>;
    chartSubscriptions: ChartSubscriptions<HorzScaleItem>;
    timescaleSubscriptions: TimescaleSubscriptions<HorzScaleItem>;
};
type getOptionsType<T, HorzScaleItem> = [T] extends [never] ? ChartOptions : T extends IHorzScaleBehavior<HorzScaleItem> ? ReturnType<T['options']> : never;
type getScaleBehaviorType<T, HorzScaleItem> = T extends IHorzScaleBehavior<HorzScaleItem> ? T : never;
export declare class ChartFactory {
    create<HorzScaleItem = Time, THorzScaleBehavior extends IHorzScaleBehavior<HorzScaleItem> = never>(container: string | HTMLElement, options?: DeepPartial<getOptionsType<THorzScaleBehavior, HorzScaleItem>>, horzScaleBehavior?: getScaleBehaviorType<THorzScaleBehavior, HorzScaleItem>): ChartFactoryReturnType<HorzScaleItem>;
}
export {};
