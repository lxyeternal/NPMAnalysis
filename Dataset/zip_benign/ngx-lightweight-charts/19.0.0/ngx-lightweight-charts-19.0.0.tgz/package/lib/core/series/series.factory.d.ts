import { CustomData, IChartApiBase, ICustomSeriesPaneView, ISeriesApi, SeriesPartialOptionsMap, SeriesType } from "lightweight-charts";
import { SeriesSubscriptions } from "./series.types";
export type SeriesFactoryReturnType<T extends SeriesType, HorzScaleItem> = {
    series?: ISeriesApi<T, HorzScaleItem>;
    seriesSubscriptions?: SeriesSubscriptions;
};
export type RequiresCustomData<T extends SeriesType, HorzScaleItem> = T extends 'Custom' ? CustomData<HorzScaleItem> : never;
export type RequiresCustomSeriesView<T extends SeriesType, HorzScaleItem> = T extends 'Custom' ? [customSeriesView: ICustomSeriesPaneView<HorzScaleItem>] : [];
export declare class SeriesFactory {
    #private;
    create<T extends SeriesType, HorzScaleItem>(type: T, chart: IChartApiBase<HorzScaleItem>, seriesOptions: SeriesPartialOptionsMap[T], ...customSeriesView: RequiresCustomSeriesView<T, HorzScaleItem>): SeriesFactoryReturnType<T, HorzScaleItem>;
}
