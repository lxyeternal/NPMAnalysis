import { TVChart } from "../tv-chart";
import { SeriesType } from "lightweight-charts";
export declare function filterChartsByIds<T extends SeriesType, HorxItemScale>(ids: string | string[]): (chart: TVChart<T, HorxItemScale>) => boolean;
