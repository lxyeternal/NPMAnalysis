import { Observable } from "rxjs";
export type HandlerCallbackFn<T> = (arg: T) => void;
export type SubHandlerFn<T> = (handler: HandlerCallbackFn<T>) => void;
export declare class SubscriptionStreamHandler<Param> {
    #private;
    readonly stream$: Observable<Param>;
    constructor(subscribeFn: SubHandlerFn<Param>, unsubscribeFn: SubHandlerFn<Param>);
    destroy(): void;
}
