import { SeriesType } from "lightweight-charts";
import { TVChart } from "../../core";
import * as i0 from "@angular/core";
export declare class TVChartCollectorDirective<T extends SeriesType, HorzScaleItem> {
    #private;
    ids: import("@angular/core").InputSignal<string | string[]>;
    readonly childCharts: import("@angular/core").Signal<readonly TVChart<T, HorzScaleItem>[]>;
    readonly charts: import("@angular/core").Signal<TVChart<T, HorzScaleItem>[] | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TVChartCollectorDirective<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TVChartCollectorDirective<any, any>, "[tvChartCollector]", never, { "ids": { "alias": "tvChartCollector"; "required": false; "isSignal": true; }; }, {}, ["childCharts"], never, true, never>;
}
