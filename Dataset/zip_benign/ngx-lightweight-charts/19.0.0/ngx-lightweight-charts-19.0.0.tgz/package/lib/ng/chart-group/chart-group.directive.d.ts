import { DeepPartial, SeriesType } from "lightweight-charts";
import * as i0 from "@angular/core";
export declare class TVChartGroupDirective<T extends SeriesType, HorzItemScale> {
    #private;
    ids: import("@angular/core").InputSignal<string | string[]>;
    groupOptions: import("@angular/core").InputSignal<DeepPartial<import("lightweight-charts").TimeChartOptions> | undefined>;
    showAllTimeScales: import("@angular/core").InputSignal<boolean>;
    minimumWidth: import("@angular/core").InputSignal<number>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<TVChartGroupDirective<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TVChartGroupDirective<any, any>, "[tvChartGroup]", never, { "ids": { "alias": "tvChartGroup"; "required": false; "isSignal": true; }; "groupOptions": { "alias": "groupOptions"; "required": false; "isSignal": true; }; "showAllTimeScales": { "alias": "showAllTimeScales"; "required": false; "isSignal": true; }; "minimumWidth": { "alias": "minimumWidth"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
