import { CandlestickData, HistogramData } from "lightweight-charts";
import { TVChartInputsDirective } from "../chart-inputs.directive";
import { TVChart } from "../../../core";
import * as i0 from "@angular/core";
import * as i1 from "../chart-inputs.directive";
import * as i2 from "../charts-outputs.directive";
export declare class TVCandleStickChartComponent<HorzScaleItem> {
    #private;
    seriesOptions: import("@angular/core").InputSignal<import("lightweight-charts").DeepPartial<import("lightweight-charts").CandlestickStyleOptions & import("lightweight-charts").SeriesOptionsCommon>>;
    volumeOptions: import("@angular/core").InputSignal<import("lightweight-charts").DeepPartial<import("lightweight-charts").HistogramStyleOptions & import("lightweight-charts").SeriesOptionsCommon>>;
    data: import("@angular/core").InputSignal<CandlestickData<HorzScaleItem>[] | undefined>;
    volume: import("@angular/core").InputSignal<HistogramData<HorzScaleItem>[] | undefined>;
    chart: import("@angular/core").Signal<TVChart<"Candlestick", HorzScaleItem> | undefined>;
    readonly inputs: TVChartInputsDirective<HorzScaleItem>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<TVCandleStickChartComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TVCandleStickChartComponent<any>, "tv-candlestick-chart", never, { "seriesOptions": { "alias": "seriesOptions"; "required": false; "isSignal": true; }; "volumeOptions": { "alias": "volumeOptions"; "required": false; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; "volume": { "alias": "volume"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.TVChartInputsDirective; inputs: { "id": "id"; "options": "options"; "markers": "markers"; }; outputs: {}; }, { directive: typeof i2.TVChartOutputsDirective; inputs: {}; outputs: { "initialised": "initialised"; "chartClick": "chartClick"; "chartDBLClick": "chartDBLClick"; "crosshairMoved": "crosshairMoved"; "visibleLogicalRangeChanged": "visibleLogicalRangeChanged"; "visibleTimeRangeChanged": "visibleTimeRangeChanged"; "sizeChanged": "sizeChanged"; "dataChanged": "dataChanged"; }; }]>;
}
