import { SeriesType } from "lightweight-charts";
import * as i0 from "@angular/core";
export type ChartBorderStyles = {
    borderColor?: string;
    borderVisible?: boolean;
};
export declare class TVChartBorderDirective<T extends SeriesType, HorzItemScale> {
    #private;
    borderStyles: import("@angular/core").InputSignal<ChartBorderStyles>;
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<TVChartBorderDirective<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TVChartBorderDirective<any, any>, "[tvChartBorder]", never, { "borderStyles": { "alias": "tvChartBorder"; "required": true; "isSignal": true; }; }, {}, never, never, true, never>;
}
