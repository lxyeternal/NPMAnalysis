import { DeepPartial, SeriesMarker } from "lightweight-charts";
import * as i0 from "@angular/core";
export declare class TVChartInputsDirective<HorzScaleItem> {
    id: import("@angular/core").InputSignal<string | undefined>;
    options: import("@angular/core").InputSignal<DeepPartial<import("lightweight-charts").TimeChartOptions> | undefined>;
    markers: import("@angular/core").InputSignal<SeriesMarker<HorzScaleItem>[] | undefined>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TVChartInputsDirective<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TVChartInputsDirective<any>, "[tvChartInputs]", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "markers": { "alias": "markers"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}
export declare const tvChartInputsDirectiveHostDef: {
    directive: typeof TVChartInputsDirective;
    inputs: string[];
};
