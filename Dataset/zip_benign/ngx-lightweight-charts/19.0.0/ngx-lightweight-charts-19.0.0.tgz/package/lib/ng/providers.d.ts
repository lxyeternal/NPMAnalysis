import { EnvironmentProviders } from "@angular/core";
export declare function getTVChartDefaultProviders(): EnvironmentProviders;
