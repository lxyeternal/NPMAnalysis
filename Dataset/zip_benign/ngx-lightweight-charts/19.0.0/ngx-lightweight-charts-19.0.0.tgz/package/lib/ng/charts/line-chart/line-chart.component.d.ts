import { LineData, Time } from "lightweight-charts";
import { TVChartInputsDirective } from "../chart-inputs.directive";
import * as i0 from "@angular/core";
import * as i1 from "../chart-inputs.directive";
import * as i2 from "../charts-outputs.directive";
export declare class TVLineChartDirective {
    seriesOptions: import("@angular/core").InputSignal<import("lightweight-charts").DeepPartial<import("lightweight-charts").LineStyleOptions & import("lightweight-charts").SeriesOptionsCommon>>;
    data: import("@angular/core").InputSignal<LineData<Time>[] | undefined>;
    readonly inputs: TVChartInputsDirective<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TVLineChartDirective, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TVLineChartDirective, "tv-line-chart", never, { "seriesOptions": { "alias": "seriesOptions"; "required": false; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.TVChartInputsDirective; inputs: { "id": "id"; "options": "options"; "markers": "markers"; }; outputs: {}; }, { directive: typeof i2.TVChartOutputsDirective; inputs: {}; outputs: { "initialised": "initialised"; "chartClick": "chartClick"; "chartDBLClick": "chartDBLClick"; "crosshairMoved": "crosshairMoved"; "visibleLogicalRangeChanged": "visibleLogicalRangeChanged"; "visibleTimeRangeChanged": "visibleTimeRangeChanged"; "sizeChanged": "sizeChanged"; "dataChanged": "dataChanged"; }; }]>;
}
