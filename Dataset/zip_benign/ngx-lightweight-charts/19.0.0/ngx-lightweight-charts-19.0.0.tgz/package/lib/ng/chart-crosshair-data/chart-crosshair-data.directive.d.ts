import { OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
export declare class TVChartCrosshairDataDirective implements OnDestroy {
    #private;
    ids: import("@angular/core").InputSignal<string | string[]>;
    data: import("@angular/core").OutputRef<{
        [key: string]: any;
        [key: number]: any;
    } | null>;
    constructor();
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TVChartCrosshairDataDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TVChartCrosshairDataDirective, "[tvChartCrosshairData]", never, { "ids": { "alias": "tvChartCrosshairDataIds"; "required": false; "isSignal": true; }; }, { "data": "tvChartCrosshairData"; }, never, never, true, never>;
}
