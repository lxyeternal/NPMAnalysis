import { Provider } from "@angular/core";
import { SeriesType } from "lightweight-charts";
import { TVChart } from "../../core";
export declare const tvChartProvider: Provider;
export declare const tvChartProviderWithExistenceCheck: Provider;
export declare function tvChartProviderFactory<T extends SeriesType>(): TVChart<T>;
