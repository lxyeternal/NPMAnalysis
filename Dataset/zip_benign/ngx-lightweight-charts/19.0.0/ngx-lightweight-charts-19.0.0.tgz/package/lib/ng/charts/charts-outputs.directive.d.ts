import { SeriesType } from "lightweight-charts";
import { TVChart } from "../../core";
import * as i0 from "@angular/core";
export declare class TVChartOutputsDirective<T extends SeriesType, HorzScaleItem> {
    #private;
    readonly initialised: import("@angular/core").OutputRef<TVChart<T, HorzScaleItem> | undefined>;
    readonly chartClick: import("@angular/core").OutputRef<import("lightweight-charts").MouseEventParams<HorzScaleItem>>;
    readonly chartDBLClick: import("@angular/core").OutputRef<import("lightweight-charts").MouseEventParams<HorzScaleItem>>;
    readonly crosshairMoved: import("@angular/core").OutputRef<import("lightweight-charts").MouseEventParams<HorzScaleItem>>;
    readonly visibleTimeRangeChanged: import("@angular/core").OutputRef<import("lightweight-charts").Range<HorzScaleItem> | null>;
    readonly visibleLogicalRangeChanged: import("@angular/core").OutputRef<import("lightweight-charts").LogicalRange | null>;
    readonly sizeChanged: import("@angular/core").OutputRef<number>;
    readonly dataChanged: import("@angular/core").OutputRef<import("lightweight-charts").DataChangedScope>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TVChartOutputsDirective<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TVChartOutputsDirective<any, any>, "[tvChartOutputs]", never, {}, { "initialised": "initialised"; "chartClick": "chartClick"; "chartDBLClick": "chartDBLClick"; "crosshairMoved": "crosshairMoved"; "visibleTimeRangeChanged": "visibleTimeRangeChanged"; "visibleLogicalRangeChanged": "visibleLogicalRangeChanged"; "sizeChanged": "sizeChanged"; "dataChanged": "dataChanged"; }, never, never, true, never>;
}
export declare const tvChartOutputsDirectiveHostDef: {
    directive: typeof TVChartOutputsDirective;
    outputs: string[];
};
