import { OnInit, OnDestroy } from '@angular/core';
import { ChartOptions, DeepPartial, ICustomSeriesPaneView, SeriesDataItemTypeMap, SeriesPartialOptionsMap, SeriesType } from "lightweight-charts";
import * as i0 from "@angular/core";
import * as i1 from "./chart-inputs.directive";
import * as i2 from "./charts-outputs.directive";
export declare const DEFAULT_CHART_OPTIONS: DeepPartial<ChartOptions>;
export declare const DEFAULT_DARK_CHART_OPTIONS: DeepPartial<ChartOptions>;
export declare class TVChartDirective<T extends SeriesType, HorzScaleItem> implements OnInit, OnDestroy {
    #private;
    type: import("@angular/core").InputSignal<T>;
    seriesOptions: import("@angular/core").InputSignal<SeriesPartialOptionsMap[T] | undefined>;
    data: import("@angular/core").InputSignal<SeriesDataItemTypeMap<HorzScaleItem>[T][] | undefined>;
    customSeriesView: import("@angular/core").InputSignal<ICustomSeriesPaneView<HorzScaleItem, import("lightweight-charts").CustomData<HorzScaleItem>, import("lightweight-charts").CustomSeriesOptions> | undefined>;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TVChartDirective<any, any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TVChartDirective<any, any>, "[tvChart]", never, { "type": { "alias": "tvChart"; "required": true; "isSignal": true; }; "seriesOptions": { "alias": "seriesOptions"; "required": false; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; "customSeriesView": { "alias": "customSeriesView"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.TVChartInputsDirective; inputs: { "id": "id"; "options": "options"; "markers": "markers"; }; outputs: {}; }, { directive: typeof i2.TVChartOutputsDirective; inputs: {}; outputs: { "initialised": "initialised"; "chartClick": "chartClick"; "chartDBLClick": "chartDBLClick"; "crosshairMoved": "crosshairMoved"; "visibleLogicalRangeChanged": "visibleLogicalRangeChanged"; "visibleTimeRangeChanged": "visibleTimeRangeChanged"; "sizeChanged": "sizeChanged"; "dataChanged": "dataChanged"; }; }]>;
}
