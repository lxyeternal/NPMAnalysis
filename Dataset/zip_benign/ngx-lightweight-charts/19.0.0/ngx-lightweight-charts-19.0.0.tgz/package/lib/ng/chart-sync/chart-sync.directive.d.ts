import { OnDestroy } from '@angular/core';
import * as i0 from "@angular/core";
export declare class TVChartSyncDirective implements OnDestroy {
    #private;
    ids: import("@angular/core").InputSignal<string | string[]>;
    visibleLogicalRange: import("@angular/core").OutputRef<import("lightweight-charts").LogicalRange>;
    crosshairPosition: import("@angular/core").OutputRef<import("lightweight-charts").MouseEventParams<any>>;
    constructor();
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TVChartSyncDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<TVChartSyncDirective, "[tvChartSync]", never, { "ids": { "alias": "tvChartSync"; "required": false; "isSignal": true; }; }, { "visibleLogicalRange": "visibleLogicalRange"; "crosshairPosition": "crosshairPosition"; }, never, never, true, never>;
}
