import { BarData, Time } from "lightweight-charts";
import { TVChartInputsDirective } from "../chart-inputs.directive";
import * as i0 from "@angular/core";
import * as i1 from "../chart-inputs.directive";
import * as i2 from "../charts-outputs.directive";
export declare class TVBarChartDirective {
    seriesOptions: import("@angular/core").InputSignal<import("lightweight-charts").DeepPartial<import("lightweight-charts").BarStyleOptions & import("lightweight-charts").SeriesOptionsCommon>>;
    data: import("@angular/core").InputSignal<BarData<Time>[] | undefined>;
    readonly inputs: TVChartInputsDirective<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TVBarChartDirective, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TVBarChartDirective, "tv-bar-chart", never, { "seriesOptions": { "alias": "seriesOptions"; "required": false; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; }, {}, never, never, true, [{ directive: typeof i1.TVChartInputsDirective; inputs: { "id": "id"; "options": "options"; "markers": "markers"; }; outputs: {}; }, { directive: typeof i2.TVChartOutputsDirective; inputs: {}; outputs: { "initialised": "initialised"; "chartClick": "chartClick"; "chartDBLClick": "chartDBLClick"; "crosshairMoved": "crosshairMoved"; "visibleLogicalRangeChanged": "visibleLogicalRangeChanged"; "visibleTimeRangeChanged": "visibleTimeRangeChanged"; "sizeChanged": "sizeChanged"; "dataChanged": "dataChanged"; }; }]>;
}
