/**
 * CalcJs
 * @name calcjs.js
 * @author Yuhei Aihara <yu.e.yu.4119@gmail.com>
 * @license MIT License
 */
(function (factory) {
    if (typeof module === "object" && typeof module.exports === "object") {
        var v = factory(require, exports);
        if (v !== undefined) module.exports = v;
    }
    else if (typeof define === "function" && define.amd) {
        define(["require", "exports"], factory);
    }
    else if (typeof window === "object"){
        var v = factory();
        if (v !== undefined) window.calcjs = v;
    }
})(function (require, exports) {
    "use strict";
    var VERSION = "1.0.0";
    var calcDigit = function (list) {
        var result = 0;
        for (var _i = 0, list_1 = list; _i < list_1.length; _i++) {
            var num = list_1[_i];
            var str = num.toExponential();
            var match = str.match(/^\d(?:\.(\d+))?e([\+\-])(\d+)$/);
            var ret = match && match[1] && match[1].length || 0;
            if (match && match[2] === "+") {
                ret -= Number(match[3]);
            }
            else if (match) {
                ret += Number(match[3]);
            }
            if (result < ret) {
                result = ret;
            }
        }
        return Math.pow(10, result);
    };
    var toUpperDigit = function (num, digit) {
        return Math.round(num * digit);
    };
    var Chain = /** @class */ (function () {
        function Chain(num) {
            this.operators = [];
            this.nums = [num];
        }
        Chain.prototype.add = function (num) {
            this.operators.push("add");
            this.nums.push(num);
            return this;
        };
        Chain.prototype.sub = function (num) {
            this.operators.push("sub");
            this.nums.push(num);
            return this;
        };
        Chain.prototype.multi = function (num) {
            this.operators.push("multi");
            this.nums.push(num);
            return this;
        };
        Chain.prototype.div = function (num) {
            this.operators.push("div");
            this.nums.push(num);
            return this;
        };
        Chain.prototype.end = function () {
            var digit = calcDigit(this.nums);
            var indexMulti = this.operators.indexOf("multi");
            var indexDiv = this.operators.indexOf("div");
            while (indexMulti >= 0 || indexDiv >= 0) {
                var nextIndex = void 0;
                var ret = void 0;
                if (indexMulti >= 0 && (indexDiv < 0 || indexMulti < indexDiv)) {
                    nextIndex = indexMulti + 1;
                    ret = toUpperDigit(this.nums[indexMulti], digit) *
                        toUpperDigit(this.nums[nextIndex], digit) /
                        (digit * digit);
                    this.nums.splice(indexMulti, 2, ret);
                    this.operators.splice(indexMulti, 1);
                }
                else if (indexDiv >= 0) {
                    nextIndex = indexDiv + 1;
                    ret = this.nums[indexDiv] / this.nums[nextIndex];
                    this.nums.splice(indexDiv, 2, ret);
                    this.operators.splice(indexDiv, 1);
                }
                indexMulti = this.operators.indexOf("multi");
                indexDiv = this.operators.indexOf("div");
                digit = calcDigit(this.nums);
            }
            digit = calcDigit(this.nums);
            var result = this.nums[0];
            for (var i = 0; i < this.operators.length; i++) {
                if (this.operators[i] === "add") {
                    result = (toUpperDigit(result, digit) + toUpperDigit(this.nums[i + 1], digit)) / digit;
                }
                else {
                    result = (toUpperDigit(result, digit) - toUpperDigit(this.nums[i + 1], digit)) / digit;
                }
            }
            this.nums = [];
            this.operators = [];
            return result;
        };
        return Chain;
    }());
    var CalcJs = /** @class */ (function () {
        function CalcJs() {
            this.VERSION = VERSION;
        }
        CalcJs.prototype.add = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            var digit = calcDigit(args);
            var result = toUpperDigit(args[0], digit) || 0;
            for (var i = 1; i < args.length; i++) {
                result += toUpperDigit(args[i], digit);
            }
            return result / digit;
        };
        CalcJs.prototype.sub = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            var digit = calcDigit(args);
            var result = toUpperDigit(args[0], digit) || 0;
            for (var i = 1; i < args.length; i++) {
                result -= toUpperDigit(args[i], digit);
            }
            return result / digit;
        };
        CalcJs.prototype.multi = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            var digit = calcDigit(args);
            var result = toUpperDigit(args[0], digit) || 0;
            for (var i = 1; i < args.length; i++) {
                result *= toUpperDigit(args[i], digit);
            }
            return result / Math.pow(digit, args.length);
        };
        CalcJs.prototype.div = function () {
            var args = [];
            for (var _i = 0; _i < arguments.length; _i++) {
                args[_i] = arguments[_i];
            }
            var result = args[0] || 0;
            for (var i = 1; i < args.length; i++) {
                result /= args[i];
            }
            return result;
        };
        CalcJs.prototype.begin = function (num) {
            return new Chain(num);
        };
        return CalcJs;
    }());
    return new CalcJs();
});
