import { Formatter, Path, SitemapPathOptions } from "./types";
export declare function generateSitemaps(paths: Array<Path>, base: string, publicPath: string, filename: string, skipgzip: boolean, globalPathOptions: SitemapPathOptions, formatter?: Formatter): Promise<Array<string>>;
//# sourceMappingURL=generators.d.ts.map