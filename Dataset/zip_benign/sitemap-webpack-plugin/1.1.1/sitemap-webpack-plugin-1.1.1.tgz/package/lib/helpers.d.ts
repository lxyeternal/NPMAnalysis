/// <reference types="node" />
import { SitemapStream, SitemapIndexStream, EnumChangefreq } from "sitemap";
import { sources, Compilation } from "webpack";
import { Path, SitemapPathOptions } from "./types";
declare const RawSource: typeof sources.RawSource;
export { RawSource };
declare type Gzip = (text: string) => Promise<Buffer>;
export declare const gzip: Gzip;
export declare function assertValidChangefreq(changefreq: string): asserts changefreq is EnumChangefreq;
export declare function compilationPublicPath(compilation: Compilation): string;
export declare function compilationEmitAsset(compilation: Compilation, file: string, source: sources.Source): void;
export declare function pathAttributes(path: Path, globalOptions: SitemapPathOptions): Record<string, unknown>;
export declare function sitemapFilename(filename: string, extension: string, index: number): string;
export declare function sitemapStreamToString(stream: SitemapIndexStream | SitemapStream, formatter?: (code: string) => string): Promise<string>;
//# sourceMappingURL=helpers.d.ts.map