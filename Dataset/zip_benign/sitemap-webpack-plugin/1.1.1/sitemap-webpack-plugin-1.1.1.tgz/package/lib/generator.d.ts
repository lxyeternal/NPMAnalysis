import { Formatter, Path, SitemapPathOptions } from "./types";
declare type GenerateSitemapArgs = {
    paths: Array<Path>;
    base: string;
    globalPathOptions: SitemapPathOptions;
    formatter?: Formatter;
};
declare type GenerateSitemapsArgs = GenerateSitemapArgs & {
    publicPath: string;
    filename: string;
    skipgzip: boolean;
};
export declare function generate({ paths, base, publicPath, filename, skipgzip, globalPathOptions, formatter }: GenerateSitemapsArgs): Promise<Array<string>>;
export {};
//# sourceMappingURL=generator.d.ts.map