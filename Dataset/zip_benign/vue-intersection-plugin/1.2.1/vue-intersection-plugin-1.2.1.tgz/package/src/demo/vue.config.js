module.exports = {
    baseUrl: './'
}