import { Criteria, INotificationQueueEntity, INotificationQueueRepo, PK } from '@node-notifications/core';
import { NotificationBaseRepo } from './notification.base.repo';
export declare class NotificationQueueRepo<Id extends PK = PK, Entity extends INotificationQueueEntity<Id> = INotificationQueueEntity<Id>> extends NotificationBaseRepo<Entity, Id> implements INotificationQueueRepo<Id> {
    addToQueue(data: Partial<Entity>): Promise<Entity>;
    updateQueue(id: Id, data: Partial<Entity>): Promise<Entity>;
    deleteFromQueue(criteria: Criteria<Id>): Promise<number>;
    findForProcessing(transport: string, limit?: number): Promise<Entity[]>;
}
