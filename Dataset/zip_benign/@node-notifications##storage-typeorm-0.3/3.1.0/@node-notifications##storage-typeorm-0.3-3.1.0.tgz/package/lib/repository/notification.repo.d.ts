import { Criteria, INotificationHistoryEntity, INotificationHistoryRepo, INotificationQueueEntity, INotificationQueueRepo, PK } from '@node-notifications/core';
import { FindOptionsWhere } from 'typeorm';
import { NotificationBaseRepo } from './notification.base.repo';
export type INotificationEntity<Id extends PK = PK, UserId extends PK = PK> = INotificationHistoryEntity<Id, UserId> & INotificationQueueEntity<Id>;
export declare class NotificationRepo<Id extends PK = PK, UserId extends PK = PK, Entity extends INotificationEntity<Id, UserId> = INotificationEntity<Id, UserId>> extends NotificationBaseRepo<Entity, Id, UserId> implements INotificationHistoryRepo<Id, UserId>, INotificationQueueRepo<Id> {
    createHistory(data: Partial<Entity>): Promise<Entity>;
    updateHistory(id: Id, data: Partial<Entity>): Promise<Entity>;
    markAsRead(criteria: Criteria<Id> | FindOptionsWhere<Entity>): Promise<number>;
    addToQueue(data: Partial<Entity>): Promise<Entity>;
    updateQueue(id: Id, data: Partial<Entity>): Promise<Entity>;
    deleteFromQueue(criteria: Criteria<Id>): Promise<number>;
    findForProcessing(transport: string, limit?: number): Promise<Entity[]>;
}
