import { Criteria, IEntity, INotificationQueueEntity, PK } from '@node-notifications/core';
import { FindOptionsWhere, Repository } from 'typeorm';
export declare abstract class NotificationBaseRepo<Entity extends IEntity<Id>, Id extends PK = PK, UserId extends PK = PK> extends Repository<Entity> {
    constructor(parent: Repository<Entity>);
    protected createEntity(data: Partial<Entity>): Promise<Entity>;
    protected updateEntity(id: Id, data: Partial<Entity>): Promise<Entity>;
    protected deleteEntity(criteria: Criteria<Id> | FindOptionsWhere<INotificationQueueEntity<Id>>): Promise<number>;
    protected findForProcessing(transport: string, limit?: number): Promise<Entity[]>;
    protected markAsRead(criteria: Criteria<Id> | FindOptionsWhere<Entity>): Promise<number>;
}
