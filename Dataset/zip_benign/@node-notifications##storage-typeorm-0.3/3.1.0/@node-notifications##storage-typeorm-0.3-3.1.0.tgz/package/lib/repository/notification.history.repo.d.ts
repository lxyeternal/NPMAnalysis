import { Criteria, INotificationHistoryEntity, INotificationHistoryRepo, PK } from '@node-notifications/core';
import { FindOptionsWhere } from 'typeorm';
import { NotificationBaseRepo } from './notification.base.repo';
export declare class NotificationHistoryRepo<Id extends PK = PK, UserId extends PK = PK, Entity extends INotificationHistoryEntity<Id, UserId> = INotificationHistoryEntity<Id, UserId>> extends NotificationBaseRepo<Entity, Id, UserId> implements INotificationHistoryRepo<Id, UserId> {
    createHistory(data: Partial<Entity>): Promise<Entity>;
    updateHistory(id: Id, data: Partial<Entity>): Promise<Entity>;
    markAsRead(criteria: Criteria<Id> | FindOptionsWhere<Entity>): Promise<number>;
}
