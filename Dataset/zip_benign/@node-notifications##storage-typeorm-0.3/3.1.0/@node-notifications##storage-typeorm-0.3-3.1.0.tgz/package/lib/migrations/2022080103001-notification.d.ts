import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class Notification2022080103001 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
