import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class HistoryQueue2022080103001 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
