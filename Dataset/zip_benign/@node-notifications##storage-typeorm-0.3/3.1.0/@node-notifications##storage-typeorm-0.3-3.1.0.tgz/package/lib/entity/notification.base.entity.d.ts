import { INotificationHistoryEntity, INotificationUser, IObject, NotificationStatusEnum, PK } from '@node-notifications/core';
export declare abstract class NotificationBaseEntity<Id extends PK = PK, UserId extends PK = PK> implements INotificationHistoryEntity<Id, UserId> {
    id: Id;
    status: NotificationStatusEnum;
    recipientId: UserId;
    recipientType?: string;
    senderId?: UserId;
    senderType?: string;
    transport: string;
    transportData: IObject;
    transportResponse: IObject | null;
    sentAttempts: number;
    sentAt: Date | null;
    createdAt: Date;
    get recipient(): INotificationUser<UserId>;
    set recipient(recipient: INotificationUser<UserId>);
    get sender(): INotificationUser<UserId> | undefined;
    set sender(sender: INotificationUser<UserId> | undefined);
}
