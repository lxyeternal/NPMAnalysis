import { PK } from '@node-notifications/core';
import { NotificationQueueEntity } from './notification.queue.entity';
export declare class NotificationEntity<Id extends PK = PK, UserId extends PK = PK> extends NotificationQueueEntity<Id, UserId> {
}
