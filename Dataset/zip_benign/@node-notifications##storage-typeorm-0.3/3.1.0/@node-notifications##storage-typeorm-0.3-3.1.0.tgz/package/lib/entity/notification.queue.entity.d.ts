import { PK } from '@node-notifications/core';
import { NotificationHistoryEntity } from './notification.history.entity';
export declare class NotificationQueueEntity<Id extends PK = PK, UserId extends PK = PK> extends NotificationHistoryEntity<Id, UserId> {
    nextSend: Date | null;
    inProcess: boolean;
}
