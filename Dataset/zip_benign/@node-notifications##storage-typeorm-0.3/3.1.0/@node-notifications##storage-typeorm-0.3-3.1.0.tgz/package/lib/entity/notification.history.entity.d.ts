import { PK } from '@node-notifications/core';
import { NotificationBaseEntity } from './notification.base.entity';
export declare class NotificationHistoryEntity<Id extends PK = PK, UserId extends PK = PK> extends NotificationBaseEntity<Id, UserId> {
}
