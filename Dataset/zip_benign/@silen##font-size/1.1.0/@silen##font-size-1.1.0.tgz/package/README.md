# font-size

```
npm i @silen/font-size
```

or

```
yarn add @silen/font-size
```

# Usage

```js
import setFontSize from '@silen/font-size';

setFontSize();
setFontSize({ rate: 0.5 });
setFontSize({ rate: 1 });
setFontSize({ rate: 1.5 });
setFontSize({ rate: 12 });
setFontSize({ rate: null, once: false });
setFontSize({ rate: null, once: true });
setFontSize({ rate: 1.5, once: true });
setFontSize({ once: true });
setFontSize({ fullwidth: 4096 });
```

or

```
<script src="./node_modules/@silen/font-size/dist/index.min.js"></script>
<script>
window.setFontSize();
</script>
```
