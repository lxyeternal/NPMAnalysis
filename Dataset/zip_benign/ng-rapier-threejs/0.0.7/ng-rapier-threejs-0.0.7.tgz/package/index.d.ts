/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="ng-rapier-threejs" />
export * from './public-api';
