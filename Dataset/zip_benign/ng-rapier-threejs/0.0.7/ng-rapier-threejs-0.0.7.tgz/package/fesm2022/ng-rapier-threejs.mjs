import * as i0 from '@angular/core';
import { Injectable } from '@angular/core';
import RAPIER, { ActiveEvents, ColliderDesc, RigidBodyDesc } from '@dimforge/rapier3d-compat';
import * as THREE from 'three';
import { ACESFilmicToneMapping, WebGLRenderer, Vector3, Vector2, Euler, Quaternion, Object3D, Matrix4, Raycaster } from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OBJLoader } from 'three/addons/loaders/OBJLoader.js';
import { RGBELoader } from 'three/addons/loaders/RGBELoader.js';
import { Lensflare, LensflareElement } from 'three/addons/objects/Lensflare.js';

class ColliderProps {
    /**
     * THREE.Object3D 를 입력받아 shape구성에 필요한 args 및 offset를 가져돈다.
     * @param args = {object3d, collider}
     */
    create(params) {
        const object = params.object3d; //  | THREE.Group
        let _translation = new THREE.Vector3();
        let _rotation = new THREE.Quaternion();
        let _scale = new THREE.Vector3(1, 1, 1);
        let _args = [];
        let _offset = new THREE.Vector3();
        params.collider = params.collider || {};
        params.body = params.body || {};
        if (!params.collider.args && object) { // 별도의 args가 없는 경우 형태를 자동으로 계산한다.
            object.updateWorldMatrix(true, true);
            new THREE.Matrix4()
                .copy(object.matrixWorld)
                .decompose(_translation, _rotation, _scale);
            object.traverse((mesh) => {
                if (mesh.type === 'Mesh') {
                    const { args, offset } = this.getColliderArgsFromGeometry(mesh, params.collider.shape);
                    _args.push(...args);
                    _offset = offset;
                }
            });
        }
        params.collider.args = params.collider.args || _args;
        params.collider.offset = params.collider.offset || _offset;
        params.collider.shape = params.collider.shape || 'cuboid';
        params.collider.scale = params.collider.scale || _scale;
        params.collider.rotation = params.collider.rotation || new THREE.Quaternion();
        params.collider.translation = params.collider.translation || new THREE.Vector3();
        params.body.rotation = params.body.rotation || _rotation;
        params.body.translation = params.body.translation || _translation;
    }
    ;
    getColliderArgsFromGeometry(mesh, shape) {
        switch (shape) {
            case 'ball':
                mesh.geometry.computeBoundingSphere();
                const { boundingSphere } = mesh.geometry;
                const radius = boundingSphere.radius;
                return {
                    args: [radius],
                    offset: boundingSphere.center
                };
            case 'trimesh':
                // case 'cylinder':
                const clonedGeometry = mesh.geometry.index
                    ? mesh.geometry.clone()
                    : this.mergeVertices(mesh.geometry);
                return {
                    args: [
                        clonedGeometry.attributes.position.array,
                        clonedGeometry.index?.array
                    ],
                    offset: new THREE.Vector3()
                };
            case 'hull':
            case 'convexHull':
                const g = mesh.geometry.clone();
                return {
                    args: [g.attributes.position.array],
                    offset: new THREE.Vector3()
                };
            default: //  'cuboid', 'cylinder', cones
                mesh.geometry.computeBoundingBox();
                const { boundingBox } = mesh.geometry;
                const size = boundingBox.getSize(new THREE.Vector3());
                return {
                    args: [size.x / 2, size.y / 2, size.z / 2],
                    offset: boundingBox.getCenter(new THREE.Vector3())
                };
        }
    }
    ;
    /**
     * @param {BufferGeometry} geometry
     * @param {number} tolerance
     * @return {BufferGeometry>}
     */
    mergeVertices(geometry, tolerance = 1e-4) {
        tolerance = Math.max(tolerance, Number.EPSILON);
        const hashToIndex = {};
        const indices = geometry.getIndex();
        const positions = geometry.getAttribute('position');
        const vertexCount = indices ? indices.count : positions.count;
        // next value for triangle indices
        let nextIndex = 0;
        // attributes and new attribute arrays
        const attributeNames = Object.keys(geometry.attributes);
        const attrArrays = {};
        const morphAttrsArrays = {};
        const newIndices = [];
        const getters = ['getX', 'getY', 'getZ', 'getW'];
        // initialize the arrays
        for (let i = 0, l = attributeNames.length; i < l; i++) {
            const name = attributeNames[i];
            attrArrays[name] = [];
            const morphAttr = geometry.morphAttributes[name];
            if (morphAttr) {
                morphAttrsArrays[name] = new Array(morphAttr.length).fill(0).map(() => []);
            }
        }
        // convert the error tolerance to an amount of decimal places to truncate to
        const decimalShift = Math.log10(1 / tolerance);
        const shiftMultiplier = Math.pow(10, decimalShift);
        for (let i = 0; i < vertexCount; i++) {
            const index = indices ? indices.getX(i) : i;
            // Generate a hash for the vertex attributes at the current index 'i'
            let hash = '';
            for (let j = 0, l = attributeNames.length; j < l; j++) {
                const name = attributeNames[j];
                const attribute = geometry.getAttribute(name);
                const itemSize = attribute.itemSize;
                for (let k = 0; k < itemSize; k++) {
                    // double tilde truncates the decimal value
                    // @ts-ignore no
                    hash += `${~~(attribute[getters[k]](index) * shiftMultiplier)},`;
                }
            }
            // Add another reference to the vertex if it's already
            // used by another index
            if (hash in hashToIndex) {
                newIndices.push(hashToIndex[hash]);
            }
            else {
                // copy data to the new index in the attribute arrays
                for (let j = 0, l = attributeNames.length; j < l; j++) {
                    const name = attributeNames[j];
                    const attribute = geometry.getAttribute(name);
                    const morphAttr = geometry.morphAttributes[name];
                    const itemSize = attribute.itemSize;
                    const newarray = attrArrays[name];
                    const newMorphArrays = morphAttrsArrays[name];
                    for (let k = 0; k < itemSize; k++) {
                        const getterFunc = getters[k];
                        // @ts-ignore
                        newarray.push(attribute[getterFunc](index));
                        if (morphAttr) {
                            for (let m = 0, ml = morphAttr.length; m < ml; m++) {
                                // @ts-ignore
                                newMorphArrays[m].push(morphAttr[m][getterFunc](index));
                            }
                        }
                    }
                }
                hashToIndex[hash] = nextIndex;
                newIndices.push(nextIndex);
                nextIndex++;
            }
        }
        // Generate typed arrays from new attribute arrays and update
        // the attributeBuffers
        const result = geometry.clone();
        for (let i = 0, l = attributeNames.length; i < l; i++) {
            const name = attributeNames[i];
            const oldAttribute = geometry.getAttribute(name);
            //@ts-expect-error  something to do with functions and constructors and new
            const buffer = new oldAttribute.array.constructor(attrArrays[name]);
            const attribute = new THREE.BufferAttribute(buffer, oldAttribute.itemSize, oldAttribute.normalized);
            result.setAttribute(name, attribute);
            // Update the attribute arrays
            if (name in morphAttrsArrays) {
                for (let j = 0; j < morphAttrsArrays[name].length; j++) {
                    const oldMorphAttribute = geometry.morphAttributes[name][j];
                    //@ts-expect-error something to do with functions and constructors and new
                    const buffer = new oldMorphAttribute.array.constructor(morphAttrsArrays[name][j]);
                    const morphAttribute = new THREE.BufferAttribute(buffer, oldMorphAttribute.itemSize, oldMorphAttribute.normalized);
                    result.morphAttributes[name][j] = morphAttribute;
                }
            }
        }
        result.setIndex(newIndices);
        return result;
    }
}

const interactionGroups = (memberships, filters) => (bitmask(memberships) << 16) +
    (filters !== undefined ? bitmask(filters) : 0b1111_1111_1111_1111);
const bitmask = (groups) => [groups].flat().reduce((acc, layer) => acc | (1 << layer), 0);

const ColliderOptions = {
    activeCollisionTypes: (collider, value) => {
        collider.setActiveCollisionTypes(value);
    },
    activeEvents: (collider, value) => {
        // collider.setActiveEvents(ActiveEvents[value as keyof ActiveEvents]);
        // collider.setActiveEvents((ActiveEvents as { [key: string]: any })[value as keyof ActiveEvents]);
        collider.setActiveEvents(ActiveEvents[value]);
    },
    activeHooks: (collider, value) => {
        collider.setActiveHooks(value);
    },
    collisionGroups: (collider, value) => {
        const group = interactionGroups(value[0], value[1]);
        collider.setCollisionGroups(group);
    },
    contactForceEventThreshold: (collider, value) => {
        collider.setContactForceEventThreshold(value);
    },
    contactSkin: (collider, value) => {
        collider.setContactSkin(value);
    },
    density: (collider, value) => {
        collider.setDensity(value);
    },
    enabled: (collider, value) => {
        collider.setEnabled(value);
    },
    friction: (collider, value) => {
        collider.setFriction(value);
    },
    frictionCombineRule: (collider, value) => {
        collider.setFrictionCombineRule(value);
    },
    mass: (collider, value) => {
        collider.setMass(value);
    },
    // massProperties: (collider:ColliderDesc, value: number) => {
    //   collider.setMassProperties(mass: number, centerOfMass: Vector, principalAngularInertia: Vector, angularInertiaLocalFrame: Rotatio);
    // },
    restitution: (collider, value) => {
        collider.setRestitution(value);
    },
    restitutionCombineRule: (collider, value) => {
        collider.setRestitutionCombineRule(value);
    },
    rotation: (collider, value) => {
        collider.setRotation(value);
    },
    sensor: (collider, value) => {
        collider.setSensor(value);
    },
    solverGroups: (collider, value) => {
        collider.setSolverGroups(value);
    },
    translation: (collider, value) => {
        if (Array.isArray(value)) {
            collider.setTranslation(value[0], value[1], value[2]);
        }
        else {
            collider.setTranslation(value.x, value.y, value.z);
        }
    }
};
class RapierColliderDesc {
    constructor() { }
    extractPropsFromOptions() {
    }
    createShapeFromOptions(options) {
        const shape = options.shape;
        const scale = options.scale;
        // const scaledArgs: number | number[] | Float32Array<ArrayBufferLike>[] | Uint32Array<ArrayBufferLike>[] | Vector[] = this.scaleColliderArgs(shape!, options.args, scale);
        const scaledArgs = this.scaleColliderArgs(shape, options.args, scale);
        let desc;
        switch (shape) {
            case 'heightfield': // Heightfield uses a vector
                desc = ColliderDesc[shape](scaledArgs[0], scaledArgs[1], scaledArgs[2], scaledArgs[3], scaledArgs[4]);
                break;
            case 'trimesh':
            case 'convexMesh':
                desc = ColliderDesc[shape](scaledArgs[0], scaledArgs[1]);
                break;
            case 'convexHull':
                desc = ColliderDesc[shape](scaledArgs[0]);
                break;
            case 'polyline':
                desc = ColliderDesc[shape](scaledArgs[0], scaledArgs[1]);
                break;
            case 'roundConvexHull':
                desc = ColliderDesc[shape](scaledArgs[0], scaledArgs[1]);
                break;
            case 'roundConvexMesh':
                desc = ColliderDesc[shape](scaledArgs[0], scaledArgs[1], scaledArgs[2]);
                break;
            case 'ball':
                desc = ColliderDesc[shape](scaledArgs[0]);
                // desc = ColliderDesc[shape](scaledArgs[0]);
                // desc = ColliderDesc[shape](...scaledArgs);
                break;
            case 'capsule':
            case 'cylinder':
            case 'cone':
                desc = ColliderDesc[shape](scaledArgs[0], scaledArgs[1]);
                break;
            case 'roundCuboid':
                desc = ColliderDesc[shape](scaledArgs[0], scaledArgs[1], scaledArgs[2], scaledArgs[3]);
                break;
            default: // cuboid, roundCylinder, roundCone
                desc = ColliderDesc[shape](scaledArgs[0], scaledArgs[1], scaledArgs[2]);
                // desc = ColliderDesc[shape!](0.5, 0.5, 0.5);
                break;
        }
        return this.setColliderDescFromOption(desc, options);
    }
    ;
    setColliderDescFromOption(desc, options) {
        Object.keys(options).forEach((key) => {
            if (key in ColliderOptions) {
                ColliderOptions[key](desc, options[key]);
            }
        });
        return desc;
    }
    scaleColliderArgs(shape, args, scale) {
        const newArgs = args.slice();
        switch (shape) {
            case 'heightfield': // Heightfield uses a vector
                const s = newArgs[3];
                s.x *= scale.x;
                s.x *= scale.y;
                s.x *= scale.z;
                return newArgs;
            case 'trimesh':
            case 'convexHull':
                newArgs[0] = this.scaleVertices(newArgs[0], scale);
                return newArgs;
            default:
                const scaleArray = [scale.x, scale.y, scale.z, scale.x, scale.x];
                return newArgs.map((arg, index) => scaleArray[index] * arg);
        }
    }
    ;
    scaleVertices(vertices, scale) {
        const scaledVerts = Array.from(vertices);
        for (let i = 0; i < vertices.length / 3; i++) {
            scaledVerts[i * 3] *= scale.x;
            scaledVerts[i * 3 + 1] *= scale.y;
            scaledVerts[i * 3 + 2] *= scale.z;
        }
        return scaledVerts;
    }
    ;
}

const rigidBodyTypeMap = {
    fixed: 1,
    dynamic: 0,
    kinematicPositionBased: 2,
    kinematicPosition: 2,
    kinematicVelocityBased: 3,
    kinematicVelocity: 3
};
// const RigidBodyOptions: TrigidBodyProps = {
// const RigidBodyOptions: any = {
const RigidBodyOptions = {
    additionalMass: (rigidbody, value) => {
        rigidbody.setAdditionalMass(value);
    },
    additionalSolverIterations: (rigidbody, value) => {
        rigidbody.setAdditionalSolverIterations(value);
    },
    angularDamping: (rigidbody, value) => {
        rigidbody.setAngularDamping(value);
    },
    angvel: (rigidbody, value) => {
        rigidbody.setAngvel(value);
    },
    canSleep: (rigidbody, value) => {
        rigidbody.setCanSleep(value);
    },
    ccdEnabled: (rigidbody, value) => {
        rigidbody.setCcdEnabled(value);
    },
    dominanceGroup: (rigidbody, value) => {
        rigidbody.setDominanceGroup(value);
    },
    enabled: (rigidbody, value) => {
        rigidbody.setEnabled(value);
    },
    enabledRotations: (rigidbody, value) => {
        rigidbody.enabledRotations(value[0], value[1], value[2]);
    },
    gravityScale: (rigidbody, value) => {
        rigidbody.setGravityScale(value);
    },
    linearDamping: (rigidbody, value) => {
        rigidbody.setLinearDamping(value);
    },
    linvel: (rigidbody, value) => {
        rigidbody.setLinvel(value.x, value.y, value.z);
    },
    rotation: (rigidbody, value) => {
        if (Array.isArray(value)) {
            rigidbody.setRotation(new THREE.Quaternion().setFromEuler(new THREE.Euler(...value)));
        }
        else {
            rigidbody.setRotation(value);
        }
    },
    sleeping: (rigidbody, value) => {
        rigidbody.setSleeping(value);
    },
    softCcdPrediction: (rigidbody, value) => {
        rigidbody.setSoftCcdPrediction(value);
    },
    translation: (rigidbody, value) => {
        if (Array.isArray(value)) {
            rigidbody.setTranslation(value[0], value[1], value[2]);
        }
        else {
            rigidbody.setTranslation(value.x, value.y, value.z);
        }
    },
    userData: (rigidbody, value) => {
        rigidbody.setUserData(value);
    },
};
``;
class RapierRigidBodyDesc {
    constructor() { }
    createRigidBodyFromOptions(options) {
        const type = this.rigidBodyTypeFromString(options?.type || 'fixed');
        const desc = new RigidBodyDesc(type);
        return this.setRigidBodyDescFromOption(desc, options);
    }
    ;
    rigidBodyTypeFromString(type) {
        return rigidBodyTypeMap[type];
    }
    setRigidBodyDescFromOption(desc, options) {
        Object.keys(options).forEach((key) => {
            if (key in RigidBodyOptions) {
                RigidBodyOptions[key](desc, options[key]);
            }
        });
        return desc;
    }
}

class Body {
    rapier;
    object3d; // Mesh;
    rigidBody;
    collider;
    useFrame;
    // private eventQueue: RAPIER.EventQueue;
    onCollisionEnter;
    constructor(rapier) {
        this.rapier = rapier;
    }
    /**
     *
     * @param args = {object3d, collider}
     */
    async create(params, callback) {
        this.object3d = params.object3d;
        const colliderProps = new ColliderProps();
        // 전달한 params에 추가적인 매개변수를 붙혀서 가져온다.
        colliderProps.create(params);
        const rapierRigidBodyDesc = new RapierRigidBodyDesc();
        const rigidBodyDesc = rapierRigidBodyDesc.createRigidBodyFromOptions(params.body);
        if (!this.rapier.world) {
            console.error('rapier world not defined');
        }
        this.rigidBody = this.rapier.world.createRigidBody(rigidBodyDesc);
        if (params.collider) {
            const rapierColliderDesc = new RapierColliderDesc();
            const colliderDesc = rapierColliderDesc.createShapeFromOptions(params.collider);
            this.collider = this.rapier.world.createCollider(colliderDesc, this.rigidBody);
            if (params.collider.onCollisionEnter) {
                this.onCollisionEnter = params.collider.onCollisionEnter;
                this.collider.setActiveEvents(RAPIER.ActiveEvents.COLLISION_EVENTS);
            }
            this.rapier.dynamicBodies.push(this);
        }
        if (callback) {
            callback(this);
        }
        // return this;
    }
    remove() {
        this.rapier.world.removeCollider(this.collider, true);
    }
    update(clock) {
        if (this.object3d) {
            this.object3d.position.copy(this.rigidBody.translation());
            this.object3d.quaternion.copy(this.rigidBody.rotation());
        }
        if (typeof this.onCollisionEnter === 'function') {
            // this.eventQueue.drainCollisionEvents((handle1, handle2, started) => {
            this.rapier.eventQueue.drainCollisionEvents((handle1, handle2, started) => {
                if (started) {
                    this.onCollisionEnter(handle1, handle2);
                    // this.rapier.world.narrowPhase.contactPair(handle1, handle2, (manifold, flipped) => {
                    //   const contactFid1 = manifold.contactFid1;
                    //   const contactFid2 = manifold.contactFid2;
                    //   this.onCollisionEnter();
                    // });
                }
            });
        }
        if (this.useFrame) {
            this.useFrame(clock);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.6", ngImport: i0, type: Body, deps: [{ token: Rapier }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.1.6", ngImport: i0, type: Body });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.6", ngImport: i0, type: Body, decorators: [{
            type: Injectable
        }], ctorParameters: () => [{ type: Rapier }] });

class RapierDebugRenderer {
    mesh;
    world;
    enabled = true;
    constructor(scene, world) {
        this.world = world;
        this.mesh = new THREE.LineSegments(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ color: 0xffffff, vertexColors: true, linewidth: 5 }));
        this.mesh.frustumCulled = false;
        scene.add(this.mesh);
    }
    update() {
        // if(this.world) {
        if (this.enabled) {
            const { vertices, colors } = this.world.debugRender();
            this.mesh.geometry.setAttribute('position', new THREE.BufferAttribute(vertices, 3));
            this.mesh.geometry.setAttribute('color', new THREE.BufferAttribute(colors, 4));
            this.mesh.visible = true;
        }
        else {
            this.mesh.visible = false;
        }
        // }
    }
}

// import {RigidBody} from './RigidBody';
class Rapier {
    world;
    // public rigidBody: RigidBody;
    threeJsWorld;
    // public dynamicBodies: [THREE.Object3D, RAPIER.RigidBody][] = [];
    dynamicBodies = [];
    eventQueue;
    rapierDebugRenderer;
    /**
     *
     * @param args
     */
    constructor() {
        RAPIER.init(); // This line is only needed if using the compat version
    }
    /*
    public async initRapier(x: number = 0.0, y: number = -9.81, z: number = 0.0):Promise<Rapier> { // Promise<Rapier>
  
    
      this.removeAll();
      
      if(!this.world) {
        const gravity = new RAPIER.Vector3(x, y, z);
        this.world = new RAPIER.World(gravity);
    
        this.threeJsWorld.updates.push((clock:any)=>{this.update(clock)});
      }
  
      this.eventQueue = new RAPIER.EventQueue(true);
     
      return this;
    } */
    async init(gravity = [0.0, -9.81, 0.0]) {
        this.removeAll();
        this.world = new RAPIER.World(new RAPIER.Vector3(gravity[0], gravity[1], gravity[2]));
        this.threeJsWorld.updates.push((clock) => { this.update(clock); });
        this.eventQueue = new RAPIER.EventQueue(true);
        return this;
    }
    enableRapierDebugRenderer() {
        this.rapierDebugRenderer = new RapierDebugRenderer(this.threeJsWorld.scene, this.world);
        return this;
    }
    update(clock) {
        this.world.timestep = Math.min(clock.delta, 0.1);
        // this.world.step();
        this.world.step(this.eventQueue);
        for (let i = 0, n = this.dynamicBodies.length; i < n; i++) {
            this.dynamicBodies[i].update(clock);
        }
        if (this.rapierDebugRenderer && this.rapierDebugRenderer.enabled) {
            this.rapierDebugRenderer.update();
        }
    }
    removeAll() {
        for (let i = 0, n = this.dynamicBodies.length; i < n; i++) {
            this.dynamicBodies[i].remove();
        }
        this.dynamicBodies = [];
    }
    /**
     *
     * @param props
     * @returns
     */
    async createBody(props) {
        const bodyObj = new Body(this);
        await bodyObj.create(props);
        return bodyObj;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.6", ngImport: i0, type: Rapier, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.1.6", ngImport: i0, type: Rapier, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.6", ngImport: i0, type: Rapier, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

const LightOptions = {
    // Maximum angle of light dispersion from its direction whose upper bound is Math.PI/2.
    angle: (light, value) => {
        light.angle = value;
    },
    castShadow: (light, value) => {
        light.castShadow = value;
    },
    // Hexadecimal color of the light. Default 0xffffff (white).
    //  | THREE.SpotLight | THREE.AmbientLight | THREE.DirectionalLight
    color: (light, value) => {
        light.color = new THREE.Color().setHex(value);
        // light.color = value;
    },
    // Maximum range of the light. Default is 0 (no limit). Expects a Float.
    distance: (light, value) => {
        light.distance = value;
    },
    // Numeric value of the light's strength/intensity. Expects a Float. Default 1.
    intensity: (light, value) => {
        light.intensity = value;
    },
    // Percent of the SpotLight cone that is attenuated due to penumbra. Takes values between zero and 1. Expects a Float. Default 0.
    penumbra: (light, value) => {
        light.penumbra = value;
    },
    position: (light, value) => {
        light.position.set(value[0], value[1], value[2]);
        // light.position.set(...value);
    },
};
const LightShadowOptions = {
    blurSamples: (light, value) => {
        light.shadow.blurSamples = value;
    },
    radius: (light, value) => {
        light.shadow.radius = value;
    },
};
class Light {
    lightProps;
    light;
    helper;
    constructor(lightProps) {
        this.lightProps = lightProps;
        this.create();
        if (lightProps.helper) {
            this.createHelpers();
        }
    }
    create() {
        switch (this.lightProps.type) {
            case 'ambient':
                this.light = new THREE.AmbientLight();
                break;
            case 'hemisphere':
                this.light = new THREE.HemisphereLight();
                break;
            case 'directional':
                this.light = new THREE.DirectionalLight();
                break;
            case 'point':
                this.light = new THREE.PointLight();
                break;
            case 'spot':
                this.light = new THREE.SpotLight();
                break;
        }
        this.setProperty();
    }
    setProperty() {
        Object.keys(this.lightProps).forEach((key) => {
            if (key == 'shadow') {
                Object.keys(this.lightProps[key]).forEach((k) => {
                    if (k in LightShadowOptions) {
                        LightShadowOptions[k](this.light, this.lightProps[key][k]);
                    }
                });
            }
            else {
                if (key in LightOptions) {
                    LightOptions[key](this.light, this.lightProps[key]);
                }
            }
        });
    }
    get() {
        return this.light;
    }
    /**
     * helper 는 별도로 분리 예정
     */
    createHelpers() {
        switch (this.lightProps.type) {
            // case 'ambient':
            //   this.helper = new THREE.AmbientLightHelper(this.light, 0.1);
            //   break;
            case 'hemisphere':
                this.helper = new THREE.HemisphereLightHelper(this.light, 0.1);
                break;
            case 'directional':
                this.helper = new THREE.DirectionalLightHelper(this.light, 0.1);
                break;
            case 'point':
                this.helper = new THREE.PointLightHelper(this.light, 0.1);
                break;
            case 'spot':
                this.helper = new THREE.SpotLightHelper(this.light, 0.1);
                break;
        }
    }
}

class Geometry {
    constructor() {
    }
    create(params) {
        // let geometry: THREE.BoxGeometry | THREE.SphereGeometry | THREE.CylinderGeometry | THREE.IcosahedronGeometry;
        switch (params.type) {
            case 'sphere':
                return new THREE.SphereGeometry(...params.args);
            case 'cylinder':
                return new THREE.CylinderGeometry(...params.args);
            case 'icosahedron':
                return new THREE.IcosahedronGeometry(...params.args);
            case 'torusknot':
                return new THREE.TorusKnotGeometry(...params.args);
            default: // box
                return new THREE.BoxGeometry(...params.args);
        }
    }
}

class Material {
    constructor() {
    }
    async createMaterial(args) {
        const map = await this.loadmap(args);
        // const map = await new THREE.TextureLoader().load( args.url );//this.loadmap(args);
        // const map = null;
        const params = {};
        params.flatShading = args.flatShading || false;
        params.color = args.color || null;
        params.map = map || null;
        switch (args.type) {
            case 'standard':
                return new THREE.MeshStandardMaterial(params);
            case 'normal':
                return new THREE.MeshNormalMaterial(params);
            case 'phong':
                return new THREE.MeshPhongMaterial(params);
        }
        return null;
    }
    async loadmap(args) {
        if (args.textureUrl) {
            return this.TextureLoader(args.textureUrl);
        }
        else if (args.objUrl) {
        }
        return null;
    }
    async TextureLoader(url) {
        return await new THREE.TextureLoader().load(url);
    }
}

// import {GLTFLoader, GLTF} from 'three/examples/jsm/loaders/GLTFLoader.js';
class LoaderGLTF {
    object;
    loader(url) {
        return new Promise((resolve, reject) => {
            const loader = new GLTFLoader();
            loader.load(url, (glb) => {
                this.object = glb;
                resolve(true);
            }, (xhr) => {
                // console.log( ( xhr.loaded / xhr.total * 100 ) + '% loaded' );
            }, (error) => {
                // console.log( 'An error happened' );
            });
        });
    }
    /**
      *
      * @param args
      * @param geometry {type: sphereGeometry}
      * @param material
      */
    /**
     * onegroup onemesh
     * @returns
     */
    getObject() {
        return this.object.scene.children[0];
    }
    getObjectByName(name) {
        return this.object.scene.getObjectByName(name);
    }
}

class LoaderObj {
    /**
     *
     * @param args
     * @param geometry {type: sphereGeometry}
     * @param material
     */
    async create(url) {
        const body = await this.loader(url);
        const mesh = body.children[0];
        // if(args.scale) this.mesh.scale.set(1, 1, 1);
        return mesh;
    }
    loader(url, name) {
        return new Promise((resolve, reject) => {
            const loader = new OBJLoader();
            loader.load(url, (obj) => {
                resolve(obj);
            }, (xhr) => {
                // console.log( ( xhr.loaded / xhr.total * 100 ) + '% loaded' );
            }, (error) => {
                // console.log( 'An error happened' );
            });
        });
    }
}

const mapping = {
    UVMapping: 300,
    CubeReflectionMapping: 301,
    CubeRefractionMapping: 302,
    CubeUVReflectionMapping: 306,
    EquirectangularReflectionMapping: 303,
    EquirectangularRefractionMapping: 304
};
const TextureOptions = {
    format: (texture, value) => {
        texture.format = value;
    },
    type: (texture, value) => {
        texture.type = value;
    },
    mapping: (texture, value) => {
        texture.mapping = mapping[value];
    },
    wrapS: (texture, value) => {
        texture.wrapS = value;
    },
    wrapT: (texture, value) => {
        texture.wrapT = value;
    },
    magFilter: (texture, value) => {
        texture.magFilter = value;
    },
    minFilter: (texture, value) => {
        texture.minFilter = value;
    },
    anisotropy: (texture, value) => {
        texture.anisotropy = value;
    },
    colorSpace: (texture, value) => {
        texture.colorSpace = value;
    }
};
class LoaderRGBE {
    texture;
    loader(url, props) {
        return new Promise((resolve, reject) => {
            const loader = new RGBELoader();
            loader.load(url, (texture) => {
                Object.keys(props).forEach((key) => {
                    if (key in TextureOptions) {
                        TextureOptions[key](texture, props[key]);
                    }
                });
                this.texture = texture;
                resolve(texture);
            }, (xhr) => {
                // console.log( ( xhr.loaded / xhr.total * 100 ) + '% loaded' );
            }, (error) => {
                // console.log( 'An error happened' );
            });
        });
    }
}

const MeshOptions = {
    position: (mesh, value) => {
        if (Array.isArray(value)) {
            mesh.position.set(value[0], value[1], value[2]);
        }
        else {
            mesh.position.set(value.x, value.y, value.z);
        }
    },
    scale: (mesh, value) => {
        if (Array.isArray(value)) {
            mesh.scale.set(value[0], value[1], value[2]);
        }
        else {
            mesh.scale.set(value.x, value.y, value.z);
        }
    },
    rotation: (mesh, value) => {
        if (Array.isArray(value)) {
            mesh.rotation.set(value[0], value[1], value[2]);
        }
        else {
            mesh.rotation.set(value.x, value.y, value.z);
        }
    },
    castShadow: (mesh, value) => {
        mesh.castShadow = value;
    },
    receiveShadow: (mesh, value) => {
        mesh.receiveShadow = value;
    }
};
class Mesh {
    mesh;
    // public geometry!: IGeometry;
    // public material!: THREE.Material;
    constructor() { }
    /**
     *
     * @param args
     * @param geometry {type: sphereGeometry}
     * @param material
     */
    async create(args) {
        const geometry = this.createGeometry(args.geometry);
        // const materialObj = new Material();
        const material = await new Material().createMaterial(args.material);
        this.mesh = this.createMesh(geometry, material, args.mesh || {});
        return this.mesh;
    }
    async loadObj(args) {
        const loader = new LoaderObj();
        const obj = await loader.create(args.mesh.url);
        this.mesh = obj.getObjectByName(args.mesh.name) || obj;
        const material = new Material();
        // this.material = await material.createMaterial(args.material);
        this.mesh.material = await material.createMaterial(args.material);
        this.mesh.name = args.mesh.name || null;
        args.mesh.scale ? this.mesh.scale.set(args.mesh.scale.x, args.mesh.scale.y, args.mesh.scale.z) : null;
        this.mesh.castShadow = args.mesh.castShadow || false;
        this.mesh.receiveShadow = args.mesh.receiveShadow || false;
        args.mesh.position ? this.mesh.position.set(args.mesh.position.x, args.mesh.position.y, args.mesh.position.z) : null;
        return this.mesh;
    }
    async loadGLTF(args, callback) {
        // const loader = new LoaderGLTF();
        const gltf = new LoaderGLTF();
        await gltf.loader(args.url);
        callback(gltf);
        return this;
    }
    async loadRGBE(args, callback) {
        // const loader = new LoaderGLTF();
        const gltf = new LoaderRGBE();
        return this;
        // this.mesh.name = args.name || null;
        // args.scale? this.mesh.scale.set(args.scale.x, args.scale.y, args.scale.z): null;
        // this.mesh.castShadow = args.castShadow || false;
        // this.mesh.receiveShadow = args.receiveShadow || false;
        // args.position ? this.mesh.position.set(args.position.x, args.position.y, args.position.z) : null;
        // return this.mesh;
    }
    createGeometry(params) {
        params.args = params.args || [];
        return new Geometry().create(params);
    }
    createMesh(geometry, material, args) {
        const mesh = new THREE.Mesh(geometry, material);
        Object.keys(args).forEach((key) => {
            if (key in MeshOptions) {
                MeshOptions[key](mesh, args[key]);
            }
        });
        return mesh;
    }
}

/*
export const WebGLRendererParametersOptions =  [
  'canvas',
  'context', // Default is null
  'alpha', // default is false.
  'premultipliedAlpha', // default is true.
  'antialias', // default is false.
  'stencil', //  default is false.
  'preserveDrawingBuffer',  //default is false.
  'powerPreference',
  'depth',  // default is true.
  'failIfMajorPerformanceCaveat',  // default is true.
  'precision',
  'logarithmicDepthBuffer', // default is true.
  'reverseDepthBuffer',// default is true.
];

*/
const RendererOptions = {
    pixelRatio: (renderer, value) => {
        renderer.setPixelRatio(value);
    },
    shadowMap: (renderer, value) => {
        Object.keys(value).forEach((key) => {
            renderer.shadowMap[key] = value[key];
        });
    },
    size: (renderer, value) => {
        renderer.setSize(value[0], value[1]);
    },
    toneMapping: (renderer, value) => {
        switch (value) {
            case 'ACESFilmic':
                renderer.toneMapping = ACESFilmicToneMapping;
                break;
        }
    }
};
// class childOfWebGLRendererParameters {
//   id = "";
//   title = "";
//   isDeleted = false;
// }
class Renderer {
    renderer;
    constructor() { }
    // public WebGLRenderer(rendererProps: WebGLRendererParameters) {
    WebGLRenderer(rendererProps) {
        const parameters = {};
        // Object.keys(rendererProps).forEach((key: any) =>{
        //   if(WebGLRendererParametersOptions.indexOf(key) !== -1) {
        //     parameters[key] = rendererProps[key];
        //   }
        // });
        Object.keys(rendererProps).forEach((key) => {
            parameters[key] = rendererProps[key];
        });
        this.renderer = new WebGLRenderer(parameters);
        return this;
    }
    ;
    setProperty(rendererProps) {
        Object.keys(rendererProps).forEach((key) => {
            if (key in RendererOptions) {
                RendererOptions[key](this.renderer, rendererProps[key]);
            }
        });
        return this;
    }
}

class World {
    container;
    scene = new THREE.Scene();
    clock = new THREE.Clock();
    updates = [];
    controls;
    helpers;
    renderer; // = new THREE.WebGLRenderer( { antialias: true, alpha: true } );
    camera;
    screen = { width: 0, height: 0 };
    rapier;
    constructor(rapier) {
        this.rapier = rapier;
    }
    setContainer(container) {
        this.container = container;
        return this;
    }
    enableControls(controlProps) {
        this.controls = new OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping = controlProps?.damping || false; // an animation loop is required when either damping or auto-rotation are enabled
        this.controls.target.z = controlProps?.target.x || 0;
        this.controls.target.y = controlProps?.target.y || 0;
        this.controls.target.z = controlProps?.target.z || 0;
        return this;
    }
    /**
     *
     * @param helperProps
     * @deprecated
     */
    enableHelpers(helperProps) {
        this.setGridHelper(helperProps);
    }
    setGridHelper(helperProps) {
        helperProps.args = helperProps.args || [1000, 40, 0x303030, 0x303030];
        this.helpers = new THREE.GridHelper(...helperProps.args);
        // this.helpers = new THREE.GridHelper( 1000, 40, 0x303030, 0x303030 );
        this.helpers.position.x = helperProps.position?.x || 0;
        this.helpers.position.y = helperProps.position?.y || 0;
        this.helpers.position.z = helperProps.position?.z || 0;
        this.scene.add(this.helpers);
        return this;
    }
    /**
     * Set screen width and height, default is window.innerWidth, window.innerHeight
     * @param screenProps
     * @returns World
     */
    setScreen(screenProps) {
        let { width, height } = screenProps || { width: window.innerWidth, height: window.innerHeight };
        width = width || window.innerWidth;
        height = height || window.innerHeight;
        this.screen = { width, height };
        return this;
    }
    /**
     *
     * @param rendererProps { antialias, alpha }
     * @param params {pixelRatio, size:[],toneMapping, shadowMap }
     * @returns
     */
    // public setRenderer(rendererProps: RendererProps, property?: any) {
    setRenderer(rendererProps, property) {
        // this.renderer = new THREE.WebGLRenderer( rendererProps ).setProperty();
        property = property || {};
        property.size = property.size || [this.screen.width, this.screen.height];
        property.pixelRatio = property.pixelRatio || window.devicePixelRatio;
        const renderer = new Renderer().WebGLRenderer(rendererProps).setProperty(property);
        this.renderer = renderer.renderer;
        // this.renderer.setPixelRatio( window.devicePixelRatio );
        // this.renderer.setSize( this.screen.width, this.screen.height );
        this.container.appendChild(this.renderer.domElement);
        return this;
    }
    setCamera(cameraProps) {
        let { fov, aspect, near, far } = cameraProps;
        fov = fov || 25; // 현재값 : 25
        aspect = aspect || window.innerWidth / window.innerHeight;
        near = near || 0.1;
        far = far || 200; // 200
        this.camera = new THREE.PerspectiveCamera(fov, aspect, near, far);
        cameraProps.position ? this.camera.position.set(cameraProps.position[0], cameraProps.position[1], cameraProps.position[2]) : this.camera.position.set(0, 0, 0);
        // this.camera.position.set( 0, 0, 100 ); // 0, 0, 200
        return this;
    }
    onResize() {
        this.setScreen();
        this.renderer.setSize(this.screen.width, this.screen.height);
        this.camera.aspect = this.screen.width / this.screen.height;
        this.camera.updateProjectionMatrix();
    }
    /**
     *
     * @param lightProps
     * - type: 'spot',
     * - intensity: Math.PI * 10,
     * - angle: Math.PI / 1.8,
     * - penumbra: 0.5,
     * - castShadow: true,
     * -shadow: {blurSamples: 10, radius: 5}
     * @returns
     */
    // public setLights(lightProps: any) {  
    //   const light = new Light(lightProps);
    //   this.scene.add(light.light);
    //   return this;
    // }
    setLight(lightProp, callback) {
        const light = new Light(lightProp);
        this.scene.add(light.light);
        if (lightProp.helper) {
            this.scene.add(light.helper);
        }
        if (callback) {
            callback(light);
        }
        return this;
    }
    setLights(lightProps) {
        const holder = new THREE.Object3D;
        lightProps.forEach((lightProp) => {
            const light = new Light(lightProp);
            holder.add(light.light);
            if (lightProp.helper) {
                this.scene.add(light.helper);
            }
        });
        this.scene.add(holder);
        return this;
    }
    clear() {
        this.scene.clear();
        return this;
    }
    render() {
        const clock = { delta: this.clock.getDelta(), elapsedTime: this.clock.getElapsedTime() };
        if (this.controls) {
            this.controls.update();
        }
        this.updates.forEach((fnc) => {
            fnc(clock);
        });
        this.renderer.render(this.scene, this.camera);
    }
    update = () => {
        this.render();
        requestAnimationFrame(this.update); // request next update
    };
    enableRapier(callback) {
        // this.rapier = new Rapier(this);
        this.rapier.threeJsWorld = this;
        callback(this.rapier);
        return this;
    }
    /**
   *
   * @param props
   * @param callback
   * @returns
   * @deprecated  use addObject
   */
    async addMesh(props) {
        const mesh = await new Mesh().create(props);
        this.scene.add(mesh);
        return mesh;
    }
    /**
     * create threejs mesh and rapier body same time
     * @param props
     * @param callback
     * @returns
     */
    async addObject(props, callback) {
        const mesh = await new Mesh().create({ geometry: props.geometry, material: props.material, mesh: props.mesh });
        this.scene.add(mesh);
        let body;
        if (props.rapier) {
            props.rapier.object3d = mesh;
            body = await this.rapier.createBody(props.rapier);
            if (callback) {
                callback(mesh, body);
            }
        }
        else {
            if (callback) {
                callback(mesh);
            }
        }
        return this;
    }
    async addObjectFromObjFile(props, callback) {
        const mesh = await new Mesh().loadObj(props);
        this.scene.add(mesh);
        let body;
        if (props.rapier) {
            props.rapier.object3d = mesh;
            body = await this.rapier.createBody(props.rapier);
        }
        this.scene.add(mesh);
        if (callback) {
            callback(mesh, body);
        }
        return this;
    }
    /**
     *
     * @param props {url, [{name, props},..]}
     */
    /*
    public async addObjectFromGLTF(props: any, callback?:(mesh?:THREE.Mesh | THREE.Object3D<THREE.Object3DEventMap>, body?:Body)=>void) {
      await new Mesh().loadGLTF(props, async (gltf) => {
        const mesh = <THREE.Mesh>gltf.getObjectByName('Cylinder');
        if(mesh) {
          mesh.traverse((m) => {
            m.receiveShadow = true
          });
        }
  
        this.scene.add(mesh);
        let body;
        if(props.rapier) {
          props.rapier.object3d = mesh;
          body = await this.rapier.createBody(props.rapier);
        }
  
        if(callback) {
          callback(mesh, body);
        }
      });
    }
  */
    // public async addObjectFromGLTF(props: any, callback?:(mesh:THREE.Mesh | THREE.Object3D<THREE.Object3DEventMap>, body?:Body)=>void) {
    // public async addObjectFromGLTF(props: any, callback?:(obj:Itest[]) =>void) {
    async addObjectFromGLTF(props, callback) {
        const obj = [];
        const MeshClass = new Mesh();
        await MeshClass.loadGLTF(props, async (gltf) => {
            for (let i = 0; i < props.props.length; i++) {
                const prop = props.props[i];
                let mesh;
                if (prop.name) {
                    mesh = gltf.getObjectByName(prop.name);
                }
                else {
                    mesh = gltf.getObject();
                }
                if (mesh) {
                    mesh.traverse((m) => {
                        if (prop.receiveShadow) {
                            m.receiveShadow = true;
                        }
                    });
                }
                this.scene.add(mesh);
                let body = undefined;
                if (prop.rapier) {
                    prop.rapier.object3d = mesh;
                    body = await this.rapier.createBody(prop.rapier);
                }
                obj.push({ mesh, body });
            }
            if (callback) {
                callback(obj);
            }
        });
    }
    /**
     * crete only rapier body
     * @param props
     * @param callback
     * @returns
     */
    async addRapierBody(props, callback) {
        const body = await this.rapier.createBody(props);
        if (callback) {
            callback(body);
        }
        return this;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.6", ngImport: i0, type: World, deps: [{ token: Rapier }], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.1.6", ngImport: i0, type: World, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.6", ngImport: i0, type: World, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: Rapier }] });

class EventListener {
    keyMap = {};
    bindMouse = {
        keydown: {},
        keyup: {},
        mousemove: {},
        wheel: {}
    };
    onMouseMove = []; // {document: fn}
    onMouseWheel = [];
    windowResize = [];
    activeMouseMove(renderer) {
        document.addEventListener('click', () => {
            renderer.domElement.requestPointerLock();
        });
    }
    activeWindowResize() {
        window.addEventListener('resize', () => {
            this.windowResize.forEach(fn => {
                fn.bind(this)();
            });
        });
    }
    // public activeMouseWhee(renderer: WebGLRenderer) {
    //   document.addEventListener('click', () => {
    //     renderer.domElement.requestPointerLock()
    //   })
    // }
    activeClickEvent(renderer) {
        document.addEventListener('click', () => {
            renderer.domElement.requestPointerLock();
        });
    }
    activePointerlockchange(renderer) {
        this.bindMouse.keydown = this.onDocumentKey.bind(this);
        this.bindMouse.keyup = this.onDocumentKey.bind(this);
        this.bindMouse.mousemove = this.onDocumentMouseMove.bind(this);
        this.bindMouse.wheel = this.onDocumentMouseWheel.bind(this);
        document.addEventListener('pointerlockchange', () => {
            if (document.pointerLockElement === renderer.domElement) {
                document.addEventListener('keydown', this.bindMouse.keydown);
                document.addEventListener('keyup', this.bindMouse.keyup);
                renderer.domElement.addEventListener('mousemove', this.bindMouse.mousemove);
                renderer.domElement.addEventListener('wheel', this.bindMouse.wheel);
            }
            else {
                document.removeEventListener('keydown', this.bindMouse.keydown);
                document.removeEventListener('keyup', this.bindMouse.keyup);
                renderer.domElement.removeEventListener('mousemove', this.bindMouse.mousemove);
                renderer.domElement.removeEventListener('wheel', this.bindMouse.wheel);
            }
        });
    }
    onDocumentKey(e) {
        this.keyMap[e.code] = e.type === 'keydown';
    }
    onDocumentMouseMove(e) {
        this.onMouseMove.forEach(fn => {
            fn.renderer.bind(this)(e);
        });
    }
    onDocumentMouseWheel(e) {
        this.onMouseWheel.forEach(fn => {
            fn.renderer.bind(this)(e);
        });
    }
    /**
     *
     * @param fn {document | renderer: fn}
     */
    addMouseMoveEvent(fn) {
        this.onMouseMove.push(fn);
    }
    /**
     *
     * @param fn {document | renderer: fn}
     */
    addMouseWeelEvent(fn) {
        this.onMouseWheel.push(fn);
    }
    addWindowResize(fn) {
        this.windowResize.push(fn);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "19.1.6", ngImport: i0, type: EventListener, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "19.1.6", ngImport: i0, type: EventListener, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "19.1.6", ngImport: i0, type: EventListener, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

// import {GLTFLoader, GLTF} from 'three/examples/jsm/loaders/GLTFLoader.js';
class LensFlare {
    lensflare;
    constructor() {
        this.lensflare = new Lensflare();
    }
    addElement(params) {
        this.lensflare.addElement(new LensflareElement(params.texture, params.size, params.distance, params.color));
        return this;
    }
    get() {
        return this.lensflare;
    }
}

const _vector3 = new Vector3();
const _vector2 = new Vector2();
const _euler = new Euler();
const _quaternion = new Quaternion();
const _object3d = new Object3D();
const _matrix4 = new Matrix4();
const _raycaster = new Raycaster();

// import { Euler, Matrix4, Object3D, Quaternion, Vector3 } from "three";
// export const _quaternion = new Quaternion();
// export const _euler = new Euler();
// export const _vector3 = new Vector3();
// export const _object3d = new Object3D();
// export const _matrix4 = new Matrix4();
// export const _position = new Vector3();
// export const _rotation = new Quaternion();
// export const _scale = new Vector3();
// export {ColliderProps} from './rapier/ColliderProps';
// export {RapierColliderDesc} from './rapier/RapierColliderDesc';
// export {RapierRigidBodyDesc} from './rapier/RapierRigidBodyDesc';
// 아래부터 실제 프로그램에서 사용할 예정

/**
 * Generated bundle index. Do not edit.
 */

export { Body, EventListener, LensFlare, Light, LoaderGLTF, LoaderObj, LoaderRGBE, Mesh, Rapier, World, _euler, _matrix4, _object3d, _quaternion, _raycaster, _vector2, _vector3 };
//# sourceMappingURL=ng-rapier-threejs.mjs.map
