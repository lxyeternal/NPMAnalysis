import * as THREE from "three";
export type IGeometry = THREE.BoxGeometry | THREE.SphereGeometry | THREE.CylinderGeometry | THREE.IcosahedronGeometry | THREE.TorusKnotGeometry;
export declare class Geometry {
    constructor();
    create(params: any): IGeometry;
}
