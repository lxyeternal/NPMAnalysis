import * as THREE from "three";
export declare class Material {
    constructor();
    createMaterial(args: any): Promise<THREE.MeshStandardMaterial | THREE.MeshNormalMaterial | THREE.MeshPhongMaterial | null>;
    private loadmap;
    private TextureLoader;
}
