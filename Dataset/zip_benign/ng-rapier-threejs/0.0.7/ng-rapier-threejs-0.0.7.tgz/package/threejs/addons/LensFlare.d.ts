import * as THREE from "three";
import { Lensflare } from 'three/addons/objects/Lensflare.js';
type TLensflareElement = {
    texture: THREE.Texture;
    size?: number;
    distance?: number;
    color?: THREE.Color;
};
export declare class LensFlare {
    lensflare: Lensflare;
    constructor();
    addElement(params: TLensflareElement): this;
    get(): Lensflare;
}
export {};
