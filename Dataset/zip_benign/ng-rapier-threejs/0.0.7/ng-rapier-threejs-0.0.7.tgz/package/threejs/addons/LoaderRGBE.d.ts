import { DataTexture } from "three";
export declare class LoaderRGBE {
    texture: DataTexture;
    loader(url: string, props?: any): Promise<DataTexture>;
}
