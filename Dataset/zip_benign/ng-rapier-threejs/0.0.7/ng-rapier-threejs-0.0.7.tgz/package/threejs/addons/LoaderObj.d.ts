import * as THREE from "three";
export declare class LoaderObj {
    /**
     *
     * @param args
     * @param geometry {type: sphereGeometry}
     * @param material
     */
    create(url: string): Promise<THREE.Object3D<THREE.Object3DEventMap>>;
    private loader;
}
