import * as THREE from "three";
export declare class LoaderGLTF {
    private object;
    loader(url: string): Promise<boolean>;
    /**
      *
      * @param args
      * @param geometry {type: sphereGeometry}
      * @param material
      */
    /**
     * onegroup onemesh
     * @returns
     */
    getObject(): THREE.Object3D;
    getObjectByName(name: string): THREE.Object3D | undefined;
}
