import * as THREE from 'three';
import { Light } from './lib/Light';
import { Tmesh, Tobj } from './Mesh';
import { Rapier } from '../rapier/Rapier';
import { Tcollider, Body } from '../rapier/Body';
import * as i0 from "@angular/core";
interface CameraProps {
    fov?: number;
    aspect?: number;
    near?: number;
    far?: number;
    position?: number[];
}
interface ScreenProps {
    width?: number;
    height?: number;
}
export interface ClockProps {
    delta: number;
    elapsedTime: number;
}
export interface Itest {
    mesh: THREE.Mesh | THREE.Object3D<THREE.Object3DEventMap>;
    body: Body;
}
export declare class World {
    private container;
    scene: THREE.Scene;
    private clock;
    updates: any[];
    private controls;
    private helpers;
    renderer: THREE.WebGLRenderer;
    camera: THREE.PerspectiveCamera;
    private screen;
    rapier: Rapier;
    constructor(rapier: Rapier);
    setContainer(container: HTMLElement): this;
    enableControls(controlProps?: any): this;
    /**
     *
     * @param helperProps
     * @deprecated
     */
    enableHelpers(helperProps?: any): void;
    setGridHelper(helperProps?: any): this;
    /**
     * Set screen width and height, default is window.innerWidth, window.innerHeight
     * @param screenProps
     * @returns World
     */
    setScreen(screenProps?: ScreenProps): World;
    /**
     *
     * @param rendererProps { antialias, alpha }
     * @param params {pixelRatio, size:[],toneMapping, shadowMap }
     * @returns
     */
    setRenderer(rendererProps: any, property?: any): this;
    setCamera(cameraProps: CameraProps): this;
    onResize(): void;
    /**
     *
     * @param lightProps
     * - type: 'spot',
     * - intensity: Math.PI * 10,
     * - angle: Math.PI / 1.8,
     * - penumbra: 0.5,
     * - castShadow: true,
     * -shadow: {blurSamples: 10, radius: 5}
     * @returns
     */
    setLight(lightProp: any, callback?: (light: Light) => void): this;
    setLights(lightProps: any[]): this;
    clear(): this;
    render(): void;
    update: () => void;
    enableRapier(callback: (rapier: Rapier) => void): this;
    /**
   *
   * @param props
   * @param callback
   * @returns
   * @deprecated  use addObject
   */
    addMesh(props: Tmesh): Promise<THREE.Mesh<THREE.BufferGeometry<THREE.NormalBufferAttributes>, THREE.Material | THREE.Material[], THREE.Object3DEventMap>>;
    /**
     * create threejs mesh and rapier body same time
     * @param props
     * @param callback
     * @returns
     */
    addObject(props: Tmesh, callback?: (mesh?: THREE.Mesh, body?: Body) => void): Promise<this>;
    addObjectFromObjFile(props: Tobj, callback?: (mesh?: THREE.Mesh | THREE.Object3D<THREE.Object3DEventMap>, body?: Body) => void): Promise<this>;
    /**
     *
     * @param props {url, [{name, props},..]}
     */
    addObjectFromGLTF(props: any, callback?: (obj: {
        mesh: THREE.Mesh | THREE.Object3D<THREE.Object3DEventMap>;
        body?: Body;
    }[]) => void): Promise<void>;
    /**
     * crete only rapier body
     * @param props
     * @param callback
     * @returns
     */
    addRapierBody(props: Tcollider, callback?: (body: Body) => void): Promise<this>;
    static ɵfac: i0.ɵɵFactoryDeclaration<World, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<World>;
}
export {};
