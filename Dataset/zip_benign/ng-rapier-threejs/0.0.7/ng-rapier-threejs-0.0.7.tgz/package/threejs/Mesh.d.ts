import * as THREE from "three";
import { LoaderGLTF } from './addons/LoaderGLTF';
export type Tmesh = {
    geometry: any;
    material: any;
    mesh: any;
    rapier?: any;
};
export type Tobj = {
    material: any;
    mesh: any;
    rapier?: any;
};
export declare class Mesh {
    mesh: THREE.Object3D | THREE.Mesh;
    constructor();
    /**
     *
     * @param args
     * @param geometry {type: sphereGeometry}
     * @param material
     */
    create(args: Tmesh): Promise<THREE.Mesh>;
    loadObj(args: Tobj): Promise<THREE.Object3D<THREE.Object3DEventMap>>;
    loadGLTF(args: any, callback: (gltf: LoaderGLTF) => void): Promise<this>;
    loadRGBE(args: any, callback: (gltf: LoaderGLTF) => void): Promise<this>;
    private createGeometry;
    private createMesh;
}
