import * as THREE from "three";
export declare const LightOptions: any;
export declare const LightShadowOptions: any;
export declare class Light {
    private lightProps;
    light: THREE.HemisphereLight | THREE.AmbientLight | THREE.DirectionalLight | THREE.PointLight | THREE.SpotLight;
    helper: THREE.HemisphereLightHelper | THREE.DirectionalLightHelper | THREE.PointLightHelper | THREE.SpotLightHelper;
    constructor(lightProps: any);
    private create;
    private setProperty;
    get(): THREE.HemisphereLight | THREE.AmbientLight | THREE.DirectionalLight | THREE.PointLight | THREE.SpotLight;
    /**
     * helper 는 별도로 분리 예정
     */
    private createHelpers;
}
