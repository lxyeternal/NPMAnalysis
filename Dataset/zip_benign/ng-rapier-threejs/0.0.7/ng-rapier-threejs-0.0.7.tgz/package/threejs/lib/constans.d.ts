import { Vector3, Euler, Quaternion, Object3D, Matrix4, Vector2, Raycaster } from "three";
export declare const _vector3: Vector3;
export declare const _vector2: Vector2;
export declare const _euler: Euler;
export declare const _quaternion: Quaternion;
export declare const _object3d: Object3D;
export declare const _matrix4: Matrix4;
export declare const _raycaster: Raycaster;
