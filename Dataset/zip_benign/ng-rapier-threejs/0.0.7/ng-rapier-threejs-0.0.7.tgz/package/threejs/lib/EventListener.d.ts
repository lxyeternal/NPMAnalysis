import { WebGLRenderer } from "three";
import * as i0 from "@angular/core";
export declare class EventListener {
    keyMap: {
        [key: string]: boolean;
    };
    private bindMouse;
    onMouseMove: any[];
    onMouseWheel: any[];
    windowResize: any[];
    activeMouseMove(renderer: WebGLRenderer): void;
    activeWindowResize(): void;
    activeClickEvent(renderer: WebGLRenderer): void;
    activePointerlockchange(renderer: WebGLRenderer): void;
    private onDocumentKey;
    private onDocumentMouseMove;
    private onDocumentMouseWheel;
    /**
     *
     * @param fn {document | renderer: fn}
     */
    addMouseMoveEvent(fn: any): void;
    /**
     *
     * @param fn {document | renderer: fn}
     */
    addMouseWeelEvent(fn: any): void;
    addWindowResize(fn: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EventListener, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<EventListener>;
}
