import { WebGLRenderer } from "three";
export interface RendererProps {
    antialias?: boolean;
    alpha?: boolean;
}
export interface ShadowMapProps {
    autoUpdate: boolean;
    enabled: boolean;
    needsUpdate: boolean;
}
export declare const RendererOptions: any;
export declare class Renderer {
    renderer: WebGLRenderer;
    constructor();
    WebGLRenderer(rendererProps: any): this;
    setProperty(rendererProps: any): this;
}
