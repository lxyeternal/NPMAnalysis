import RAPIER from '@dimforge/rapier3d-compat';
import { World as ThreeJsWorld } from '../threejs/World';
import { Body } from './Body';
import { RapierDebugRenderer } from './RapierDebugRenderer';
import * as i0 from "@angular/core";
export declare class Rapier {
    world: RAPIER.World;
    threeJsWorld: ThreeJsWorld;
    dynamicBodies: Body[];
    eventQueue: RAPIER.EventQueue;
    rapierDebugRenderer: RapierDebugRenderer;
    /**
     *
     * @param args
     */
    constructor();
    init(gravity?: number[]): Promise<this>;
    enableRapierDebugRenderer(): this;
    private update;
    private removeAll;
    /**
     *
     * @param props
     * @returns
     */
    createBody(props: any): Promise<Body>;
    static ɵfac: i0.ɵɵFactoryDeclaration<Rapier, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Rapier>;
}
