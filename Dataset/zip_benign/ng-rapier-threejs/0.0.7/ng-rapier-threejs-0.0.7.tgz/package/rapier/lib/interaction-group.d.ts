import { InteractionGroups } from "@dimforge/rapier3d-compat";
export declare const interactionGroups: (memberships: number | number[], filters?: number | number[]) => InteractionGroups;
