import * as THREE from "three";
import { RigidBodyDesc } from "@dimforge/rapier3d-compat";
export type RigidBodyTypeString = "fixed" | "dynamic" | "kinematicPositionBased" | "kinematicPosition" | "kinematicVelocityBased" | "kinematicVelocity";
export type TrigidBodyProps = {
    additionalMass?: number;
    additionalSolverIterations?: number;
    angularDamping?: number;
    angvel?: THREE.Vector3;
    canSleep?: boolean;
    ccdEnabled?: boolean;
    dominanceGroup?: number;
    enabled?: boolean;
    enabledRotations?: boolean[];
    gravityScale?: number;
    linearDamping?: number;
    linvel?: THREE.Vector3;
    rotation?: THREE.Quaternion;
    sleeping?: boolean;
    softCcdPrediction?: number;
    translation?: THREE.Vector3 | number[];
    userData?: any;
    type?: string;
};
export declare class RapierRigidBodyDesc {
    constructor();
    createRigidBodyFromOptions(options: any): RigidBodyDesc | null;
    private rigidBodyTypeFromString;
    private setRigidBodyDescFromOption;
}
