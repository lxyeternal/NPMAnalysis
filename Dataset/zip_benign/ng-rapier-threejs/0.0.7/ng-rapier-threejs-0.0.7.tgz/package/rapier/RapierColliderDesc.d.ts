import * as THREE from "three";
import { ColliderDesc } from "@dimforge/rapier3d-compat";
export type ColliderShape = "cuboid" | "trimesh" | "ball" | "capsule" | "convexHull" | "heightfield" | "polyline" | "roundCuboid" | "cylinder" | "roundCylinder" | "cone" | "roundCone" | "convexMesh" | "roundConvexHull" | "roundConvexMesh";
export type TcolliderProps = {
    activeCollisionTypes?: number;
    activeEvents?: string;
    activeHooks?: number;
    collisionGroups?: number[] | [number | [], number[]];
    contactForceEventThreshold?: number;
    contactSkin?: number;
    density?: number;
    enabled?: boolean;
    friction?: number;
    frictionCombineRule?: any;
    mass?: number;
    restitution?: number;
    restitutionCombineRule?: number;
    rotation?: THREE.Quaternion;
    sensor?: boolean;
    solverGroups?: number;
    translation?: number[] | THREE.Vector3;
    args?: number[];
    shape?: string;
    onCollisionEnter?: any;
};
export type scaledArgs = {};
export declare class RapierColliderDesc {
    constructor();
    extractPropsFromOptions(): void;
    createShapeFromOptions(options: any): ColliderDesc | null;
    private setColliderDescFromOption;
    private scaleColliderArgs;
    private scaleVertices;
}
