import * as THREE from "three";
import RAPIER from '@dimforge/rapier3d-compat';
import { Rapier } from './Rapier';
import { TcolliderProps } from './RapierColliderDesc';
import { TrigidBodyProps } from './RapierRigidBodyDesc';
import { ClockProps } from '../public-api';
import * as i0 from "@angular/core";
export type Tcollider = {
    body: TrigidBodyProps;
    collider: TcolliderProps;
    object3d?: any;
};
export declare class Body {
    private rapier;
    object3d: THREE.Object3D;
    rigidBody: RAPIER.RigidBody;
    collider: RAPIER.Collider;
    useFrame: {
        (argument: any): void;
    };
    private onCollisionEnter;
    constructor(rapier: Rapier);
    /**
     *
     * @param args = {object3d, collider}
     */
    create(params: Tcollider, callback?: (body?: Body) => void): Promise<void>;
    remove(): void;
    update(clock: ClockProps): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<Body, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<Body>;
}
