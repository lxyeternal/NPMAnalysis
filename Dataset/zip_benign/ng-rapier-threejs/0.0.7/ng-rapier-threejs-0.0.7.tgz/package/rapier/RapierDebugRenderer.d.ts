import * as THREE from "three";
import RAPIER from '@dimforge/rapier3d-compat';
export declare class RapierDebugRenderer {
    mesh: THREE.LineSegments<THREE.BufferGeometry<THREE.NormalBufferAttributes>, THREE.LineBasicMaterial, THREE.Object3DEventMap>;
    world: RAPIER.World;
    enabled: boolean;
    constructor(scene: THREE.Scene, world: RAPIER.World);
    update(): void;
}
