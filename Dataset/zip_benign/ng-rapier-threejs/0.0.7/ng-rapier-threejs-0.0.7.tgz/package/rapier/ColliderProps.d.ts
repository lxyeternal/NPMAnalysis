import * as THREE from 'three';
export type TobjectProps = {
    position: THREE.Vector3;
    rotation: THREE.Quaternion;
    scale: THREE.Vector3;
    shape: string;
    args: any[];
    offset: THREE.Vector3;
};
export declare class ColliderProps {
    /**
     * THREE.Object3D 를 입력받아 shape구성에 필요한 args 및 offset를 가져돈다.
     * @param args = {object3d, collider}
     */
    create(params: any): void;
    private getColliderArgsFromGeometry;
    /**
     * @param {BufferGeometry} geometry
     * @param {number} tolerance
     * @return {BufferGeometry>}
     */
    private mergeVertices;
}
