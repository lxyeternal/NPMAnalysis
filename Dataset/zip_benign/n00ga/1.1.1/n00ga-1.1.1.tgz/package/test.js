const { N00GA } = require('./index');

const n = N00GA('/dev/tty.usbserial-0001');

n.initialise().then(() => {
  n.send('foo');
});
