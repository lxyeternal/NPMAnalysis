declare module 'mapbox-gl' {
    type Projection = undefined | 'globe' | 'equalEarth' | 'albers' | 'mercator' | 'lambertConformalConic' | 'winkelTripel' | 'naturalEarth' | 'equirectangular';
    interface ProjectionSpecification {
        name: Projection;
        center: [number, number];
        parallels: [number, number];
    }
    interface Map {
        setProjection: (projection?: Projection | ProjectionSpecification) => void;
    }
}
export {};
//# sourceMappingURL=MapboxMap.d.ts.map