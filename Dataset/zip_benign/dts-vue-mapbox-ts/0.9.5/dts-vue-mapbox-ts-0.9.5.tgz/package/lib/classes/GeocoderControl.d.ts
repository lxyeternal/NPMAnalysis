import { Result, Results } from '@mapbox/mapbox-gl-geocoder';
import { ComponentInternalInstance } from 'vue';
import { FeatureCollection, GeoJsonProperties, Geometry } from 'geojson';
export declare type FilterFunction = (r: Result) => boolean;
export declare type ExternalGeocoderFunction = ((searchInput: string, features: FeatureCollection<Geometry, GeoJsonProperties>) => Promise<FeatureCollection<Geometry, GeoJsonProperties>>);
export declare type RenderFunction = ((feature: Result) => string);
export declare type GetItemValueFunction = RenderFunction;
export declare type LocalGeocoderFunction = ((query: string) => Result[]);
export interface GeocoderComponentInstanceAdditions {
    proxy: {
        showOriginalGeocoder: boolean;
        geocoderState: {
            result: Result;
            results: Results;
            error: null | string;
            loading: null | string;
        };
    };
}
export declare type GeocoderComponentInstance = GeocoderComponentInstanceAdditions & ComponentInternalInstance;
//# sourceMappingURL=GeocoderControl.d.ts.map