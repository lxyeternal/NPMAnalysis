import { portal } from "./portal";
export {
  portal
};
//# sourceMappingURL=index.js.map
