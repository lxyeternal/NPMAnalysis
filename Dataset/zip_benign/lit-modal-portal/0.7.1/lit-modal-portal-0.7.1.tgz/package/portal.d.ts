import { AsyncDirective } from 'lit/async-directive.js';
export type TargetOrSelector = Node | string;
export interface PortalOptions {
    placeholder?: unknown;
}
export declare class PortalDirective extends AsyncDirective {
    private containerId;
    private container;
    private target;
    render(content: unknown | Promise<unknown>, targetOrSelector: TargetOrSelector | Promise<TargetOrSelector>, options?: PortalOptions): symbol;
    protected disconnected(): void;
    protected reconnected(): void;
}
export declare const portal: (content: unknown, targetOrSelector: TargetOrSelector | Promise<TargetOrSelector>, options?: PortalOptions) => import("lit-html/directive").DirectiveResult<typeof PortalDirective>;
//# sourceMappingURL=portal.d.ts.map