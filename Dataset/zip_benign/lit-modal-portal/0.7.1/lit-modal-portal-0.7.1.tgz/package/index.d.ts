import { portal } from './portal';
export { portal };
//# sourceMappingURL=index.d.ts.map