# Reste à faire

## Fix

- Gérer proprement les problématiques d'encodage

## Features

- Gérer la reprise sur erreur

## Technical Debt
