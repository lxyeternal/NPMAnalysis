export const cfgItem = [
  {
    label: 'x',
    name: 'x',
    value: 0,
    placeholder: '例如：10',
    type: [],
  },
  {
    label: 'y',
    name: 'y',
    value: 0,
    placeholder: '例如：10',
    type: [],
  },
  {
    label: 'clazz',
    name: 'clazz',
    value: '',
    placeholder: '例如：cz-title',
    type: [],
  },
  {
    label: '请求参数',
    name: 'params',
    value: '',
    placeholder: '例如：{id: 2}',
    type: [],
  },
  {
    label: '请求方式',
    name: 'method',
    value: 'get',
    placeholder: '例如：get',
    type: [{
      id: 'get',
      name: 'get'
    }, {
      id: 'post',
      name: 'post'
    }, {
      id: 'put',
      name: 'put'
    }, {
      id: 'delete',
      name: 'delete'
    }]
  },
  {
    label: '请求地址',
    name: 'url',
    value: '',
    placeholder: '例如：',
    type: [],
  },
  {
    label: '数据',
    name: 'data',
    value: [0.7, 0.72],
    placeholder: '例如：[0.6, 0.7]',
    type: [],
  },
  {
    label: '宽度',
    name: 'width',
    value: '400px',
    placeholder: '例如：400px',
    type: [],
  },
  {
    label: '高度',
    name: 'height',
    value: '200px',
    placeholder: '例如：200px',
    type: [],
  },
  {
    label: '图元波浪颜色',
    name: 'colors',
    value: ['#fdc16c', ['#3af8d3', '#0f4d7c']],
    placeholder: "例如：['#fdc16c', ['#3af8d3', '#0f4d7c']]",
    type: [],
  },
  {
    label: '波浪振幅',
    name: 'amplitude',
    value: '5%',
    placeholder: '例如：5%',
    type: [],
  },
  {
    label: '图表背景图',
    name: 'chartbg',
    value: './images/yzkl/pie-bg1.png',
    placeholder: '例如：./images/yzkl/pie-bg1.png',
    type: [],
  },
  {
    label: '图表背景色',
    name: 'backgroundStyle',
    value: 'rgba(10, 66, 117, 1)',
    placeholder: '例如：rgba(10, 66, 117, 1)',
    type: ['color'],
  },
  {
    label: '轮廓线颜色',
    name: 'outlineColor',
    value: 'rgba(15, 129, 228, 0.7)',
    placeholder: '例如：rgba(15, 129, 228, 0.7)',
    type: ['color'],
  },
  {
    label: '轮廓线宽',
    name: 'outlineDistance',
    value: 2,
    placeholder: '例如：2',
    type: [],
  },
  {
    label: '边框线宽',
    name: 'borderWidth',
    value: 10,
    placeholder: '默认：10',
    type: [],
  },
  {
    label: '显示文字',
    name: 'textStr',
    value: '100',
    placeholder: '100',
    type: [],
  },
  {
    label: '文字颜色',
    name: 'textStrColor',
    value: '#fff',
    placeholder: '#fff',
    type: ['color'],
  },
  {
    label: '文字大小',
    name: 'textStrSize',
    value: '20px',
    placeholder: '20px',
    type: [],
  },
  {
    label: 'options',
    name: 'options',
    value: {},
    placeholder: '例如：{}',
    type: [],
  },
];

export default {
  x: 0,
  y: 0,
  clazz: '',
  params: {},
  url: '',
  method: 'get',
  data: [0.7, 0.72],

  width: '400px',
  height: '200px',
  colors: ['#fdc16c', ['#3af8d3', '#0f4d7c']],
  amplitude: '5%',
  chartbg: './images/yzkl/pie-bg1.png',
  backgroundStyle: 'rgba(10, 66, 117, 1)',
  outlineColor: 'rgba(15, 129, 228, 0.7)',
  outlineDistance: 2,
  borderWidth: 10,

  textStr: '100',
  textStrColor: '#fff',
  textStrSize: '20px',
  options: {},
};