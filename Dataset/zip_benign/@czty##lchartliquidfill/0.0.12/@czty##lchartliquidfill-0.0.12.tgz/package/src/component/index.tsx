import * as echarts from 'echarts/lib/echarts'
import 'echarts-liquidfill';
import React, { FC, useEffect, useState } from 'react'
import  { merge } from 'lodash-es'
import './index.scss'
import configers from '../../configer'

const isArray = (o) => {
  return Object.prototype.toString.call(o) === '[object Array]';
}

const noDataOption = {
  text: '暂无数据',
  color: 'rgba(255, 255, 255, 0)',
  textColor: '#8a8e91',
  maskColor: 'rgba(255, 255, 255, 0)'
}

const loadingDataOption = {
  text: '正在加载中...',
  color: 'rgba(255, 255, 255, 0)',
  textColor: '#8a8e91',
  maskColor: 'rgba(255, 255, 255, 0)'
}
const defaultColors = [
  '#37a2da', '#54bcf2', '#32c5e9', '#40d2c9', '#67eba8', '#9fe6b8', '#c4e69f', '#e6ed70', '#ffdb5c', '#fdc16c',
  '#ff9f7f', '#f87c7c', '#fb7293', '#ed4e86', '#f27fd8', '#f6a8ff', '#f1cdfb', '#d1a6ef', '#bc82e5', '#8378ea',
  '#6977fc', '#869af0', '#abb9f4', '#abc6f4', '#749ee5', '#448fdc', '#2b8ef4', '#2bb4f4', '#8ed8ff', '#b7cad4'
]

const graphicImgUrl = './images/sft/pie-bg1.png';
// mode是模式， false代表接口模式，true代表外部填写静态值的模式, mode=false 
const LchartLiquidfill: FC = ({ draggable = true, configer = configers }) => {
  const {
    data,

    textStr,
    textStrColor,
    textStrSize,

    width,
    height,
    colors,
    amplitude,

    chartbg,
    backgroundStyle,
    outlineColor,
    outlineDistance,
    borderWidth,

    options,
  } = configer;
  const colorsA = []
  colors.forEach((itemC) => {
    if (isArray(itemC)) {
      colorsA.push({
        type: 'linear',
        x: 0,
        y: 0,
        x2: 0,
        y2: 1,
        colorStops: [
          {
            offset: 0,
            color: itemC[0], // 0% 处的颜色
          },
          {
            offset: 1,
            color: itemC[1], // 100% 处的颜色
          },
        ],
        global: false, // 缺省为 false
      });
    } else {
      colorsA.push(itemC);
    }
  });
  const chartData = {
    graphic: {
      elements: [
        {
          type: 'image',
          z: 10,
          style: {
            image: chartbg !== '' ? graphicImgUrl : '',
            width: Number(height.slice(0, -2)),
            height: Number(height.slice(0, -2)),
          },
          left: 'center',
          top: 'center',
        },
      ],
    },
    series: [
      {
        name: 'liquidFill',
        type: 'liquidFill',
        data: data, // 数据项的值，介于0-1之间 传入多个数据值来展示多个数值或制造多个波浪的效果
        // color: colors, // ['#294D99', '#156ACF', '#1598ED', '#45BDFF'],
        color: colorsA,
        center: ['50%', '50%'], // 图的位置，第一个值为横坐标，第二个值为纵坐标；可设置为百分比如"50%"或者像素值如"100px"
        radius: '85%', // 图的半径，可设置为百分比如"50%"或者像素值如"100px"
        amplitude: amplitude === '' ? '8%' : amplitude, // 振幅 像素或百分比。如果是百分比，则相对于直径。0表示静止
        waveLength: '80%', // 波长 可设置为百分比如"50%"或者像素值如"100px"
        phase: 'auto', // 波浪的相位 一般是auto
        period: 'auto', // 向前移动一个波长所需的毫秒数
        direction: 'right', // 波浪滚动的方向
        shape: 'circle', // 波浪形状，可被设置为'circle', 'rect', 'roundRect', 'triangle', 'diamond', 'pin', 'arrow' 或者 svg路径

        waveAnimation: true, // 是否开启波浪动画
        animationEasing: 'linear', // 当波浪从底部开始上升时，初始动画的简化方法。
        animationEasingUpdate: 'linear', // 其他动画的简化方法，例如，当数据值改变及波位改变时。
        animationDuration: 1000, // 动画持续时间，单位为毫秒
        animationDurationUpdate: 1000, // 数据更新动画持续时间

        outline: {
          // 轮廓设置
          show: true,
          borderDistance: outlineDistance !== '' ? outlineDistance : 2,
          itemStyle: {
            color: outlineColor,
            borderColor: backgroundStyle, // '#0E74CD',
            borderWidth,
            shadowBlur: 0,
            // shadowColor: 'rgba(0, 0, 0, 0.25)',
          },
        },
        backgroundStyle: {
          color: backgroundStyle,
        },

        itemStyle: {
          // opacity: 0.7,
          shadowBlur: 0,
          // shadowColor: 'rgba(0, 0, 0, 0.4)',
        },

        label: {
          show: false,
          color: '#294D99',
          insideColor: '#fff',
          fontSize: 50,
          fontWeight: 'bold',

          align: 'center',
          baseline: 'middle',
          position: 'inside',
        },
      },
    ],
  };
  const [myChart, setChart] = useState(null);
  const [od, setOd] = useState(chartData);
  // const [colorList] = useState(colorsArr);
  const [dots] = useState(Math.floor(Math.random() * 10000));
  const handleDrag = (e) => {
    /*
     * 这里还可以传输一个字段，来标明是什么类型的组件
     * 比如button是需要传string的prop, echarts是传数组对象类的prop
     * 不同的类型，左侧的属性编辑栏里编辑的项不同
     */
    const data = JSON.stringify({
      type: 'other',
      id: 'LchartLiquidfill',
      relate: 'in',
    });
    e.dataTransfer.setData('Text', data);
  };

  const updateData = () => {
    const item = merge(chartData, options);
    if (data?.length) {
      item.series[0].data = data;
    } else {
      item.series[0].data = [];
    }
    setOd({ ...item });
  };
  useEffect(() => {
    const chartDom = document.querySelector(`.dccp-charts-${dots}`);
    setChart(echarts.init(chartDom));
    window.onresize = function () {
      myChart?.resize();
    };
    return () => {
      myChart?.dispose();
      setChart(null);
    }
  }, []);

  useEffect(() => {
    updateData();
    // 对于第二个参数是对象的问题，可以是string化，也可以是md5化
  }, [JSON.stringify(configer)]);

  useEffect(() => {
    try {
      myChart?.setOption(od, true);
    } catch (e) {
      console.log(e);
    }
    if (od.series[0].data.length) {
      myChart?.hideLoading();
    } else {
      myChart?.showLoading(noDataOption);
    }
  }, [JSON.stringify(od), myChart]);
  
  const handleResize = () => {
    myChart?.resize()
  }
  useEffect(()=>{
    if(myChart) {
      window.addEventListener('resize', handleResize);
    }
    return () => {
      window.removeEventListener('resize', handleResize)
    }
  }, [myChart])

  return (
    <div className='cz-lchartbar-c'>
      <div
        draggable={draggable}
        onDragStart={(e) => {
          handleDrag(e);
        }}
        style={{ width, height }}
        className={`dragor dccp-charts dccp-charts-${dots}`}
      ></div>
      <div
        className='text_box'
        style={{ color: textStrColor, fontSize: textStrSize }}
      >
        {chartData.series[0].data?.length ? textStr : ''}
      </div>
    </div>
  );
};

export default LchartLiquidfill;