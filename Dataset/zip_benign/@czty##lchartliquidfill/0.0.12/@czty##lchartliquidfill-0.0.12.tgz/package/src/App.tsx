import React, { FC } from 'react'
import 'antd/dist/antd.css'
// 文件夹命名得全小写的
import LchartLiquidfill from '@/component';

const App: FC = () => {
  return (
    <div className='app'>
      <LchartLiquidfill />
    </div>
  );
}

export default App