水球图

水球图多用来展示多个数值或制造多个波浪的效果

|参数|说明|
|:----|:----|
| clazz  | 自定义类名 |
| url  | 外部请求url |
| method  | 外部请求url的方式 |
| params  | 外部参数 |
| width  | 图表的宽 例如：400px |
| height  | 图表的高 例如：200px |
| data  | 数据，数组格式，数组的每个元素值范围是[0-1] ，例如：[0.5, 0.7]或[{name: '名1', value: 0.5}, {name: '名2', value: 0.7}]  |
| color  | 数据，表示数据中每个数据图元的颜色，支持单色和渐变(仅两种颜色，从上至下) 例如：['#fdc16c', ['#3af8d3', '#0f4d7c']]  |
| amplitude  | 波浪的振幅 像素或百分比。如果是百分比，则相对于直径。0表示静止 |
| chartbg  | 图表的背景图，可以为空 为空就不显示背景 例如：./images/yzkl/pie-bg1.png |
| backgroundStyle  | 图表的背景颜色 例如：rgba(10, 66, 117, 1) 或 #fdc16c |
| outlineColor  | 图表的轮廓线颜色 例如：rgba(10, 66, 117, 1) 或 #fdc16c |
| outlineDistance  | 图表的轮廓线宽度 例如：2 |
| borderWidth  | 图表的外边框宽度 例如：10 |
| textStr  | 图表上层显示的文字 例如：100 |
| textStrSize  | 图表上层显示的文字的大小 例如：100 |
| textStrColor  | 图表上层显示的文字的颜色 例如：#ffffff |
| options  | 图表的配置数据 请参考[水球图](https://github.com/ecomfe/echarts-liquidfill) 、[Echarts配置项](https://echarts.apache.org/zh/option.html#title)|
