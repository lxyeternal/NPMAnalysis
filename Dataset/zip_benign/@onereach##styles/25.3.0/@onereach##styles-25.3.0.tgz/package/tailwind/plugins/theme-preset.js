const plugin = require('tailwindcss/plugin');
const { variants } = require('./core');

const values = {
  'primary': 'primary',
  'primary-dark': 'primary..-dark',

  // 'secondary': 'secondary',
  // 'secondary-dark': 'secondary..-dark',

  // 'tertiary': 'tertiary',
  // 'tertiary-dark': 'tertiary..-dark',

  'success': 'success',
  'success-dark': 'success..-dark',

  'warning': 'warning',
  'warning-dark': 'warning..-dark',

  'error': 'error',
  'error-dark': 'error..-dark',
};

module.exports = {
  values,

  plugin: plugin(({ matchComponents, theme }) => {
    matchComponents({
      'theme-preset-1': (value) => {
        const [token, suffix = ''] = value.split('..');

        return {
          color: theme(`textColor.on-${token}` + suffix),
          backgroundColor: theme(`backgroundColor.${token}` + suffix),

          borderStyle: 'none',
          outlineStyle: 'none',

          [variants['mobile']]: {
            [variants['active']]: {
              backgroundColor: theme(`backgroundColor.${token}-hover` + suffix),
            },
          },

          [variants['desktop']]: {
            [variants['hover']]: {
              backgroundColor: theme(`backgroundColor.${token}-hover` + suffix),
            },

            [variants['focus-visible']]: {
              backgroundColor: theme(`backgroundColor.${token}-hover` + suffix),
            },

            [variants['active']]: {
              backgroundColor: theme(`backgroundColor.${token}` + suffix),
            },
          },

          [variants['disabled']]: {
            color: `${theme('textColor.on-disabled' + suffix)} !important`,
            backgroundColor: `${theme('backgroundColor.disabled' + suffix)} !important`,
          },

          transitionProperty: 'color, background-color, border-color, outline-color',
          transitionDuration: theme('transitionDuration.short'),
          transitionTimingFunction: theme('transitionTimingFunction.standard'),
        };
      },

      'theme-preset-2': (value) => {
        const [token, suffix = ''] = value.split('..');

        return {
          color: theme(`textColor.${token}` + suffix),
          backgroundColor: theme(`backgroundColor.${token}-opacity-0-08` + suffix),

          borderStyle: 'none',
          outlineStyle: 'none',

          [variants['mobile']]: {
            [variants['active']]: {
              backgroundColor: theme(`backgroundColor.${token}-opacity-0-12` + suffix),
            },
          },

          [variants['desktop']]: {
            [variants['hover']]: {
              backgroundColor: theme(`backgroundColor.${token}-opacity-0-12` + suffix),
            },

            [variants['focus-visible']]: {
              backgroundColor: theme(`backgroundColor.${token}-opacity-0-12` + suffix),
            },

            [variants['active']]: {
              backgroundColor: theme(`backgroundColor.${token}-opacity-0-16` + suffix),
            },
          },

          [variants['disabled']]: {
            color: `${theme('textColor.on-disabled' + suffix)} !important`,
            backgroundColor: `${theme('backgroundColor.disabled' + suffix)} !important`,
          },

          transitionProperty: 'color, background-color, border-color, outline-color',
          transitionDuration: theme('transitionDuration.short'),
          transitionTimingFunction: theme('transitionTimingFunction.standard'),
        };
      },

      'theme-preset-3': (value) => {
        const [token, suffix = ''] = value.split('..');

        return {
          color: theme(`textColor.${token}` + suffix),
          backgroundColor: 'transparent',

          borderStyle: 'none',
          outlineStyle: 'none',

          [variants['mobile']]: {
            [variants['active']]: {
              backgroundColor: theme(`backgroundColor.${token}-opacity-0-08` + suffix),
            },
          },

          [variants['desktop']]: {
            [variants['hover']]: {
              backgroundColor: theme(`backgroundColor.${token}-opacity-0-08` + suffix),
            },

            [variants['focus-visible']]: {
              backgroundColor: theme(`backgroundColor.${token}-opacity-0-08` + suffix),
            },

            [variants['active']]: {
              backgroundColor: theme(`backgroundColor.${token}-opacity-0-16` + suffix),
            },
          },

          [variants['disabled']]: {
            color: `${theme('textColor.on-disabled' + suffix)} !important`,
            backgroundColor: 'transparent !important',
          },

          transitionProperty: 'color, background-color, border-color, outline-color',
          transitionDuration: theme('transitionDuration.short'),
          transitionTimingFunction: theme('transitionTimingFunction.standard'),
        };
      },

      'theme-preset-4': (value) => {
        const [token, suffix = ''] = value.split('..');

        return {
          color: theme(`textColor.${token}` + suffix),
          backgroundColor: 'transparent',

          borderStyle: 'none',
          outlineStyle: 'none',

          [variants['mobile']]: {
            [variants['active']]: {
              color: theme(`textColor.${token}-hover` + suffix),
            },
          },

          [variants['desktop']]: {
            [variants['hover']]: {
              color: theme(`textColor.${token}-hover` + suffix),
            },

            [variants['focus-visible']]: {
              color: theme(`textColor.${token}-hover` + suffix),
            },

            [variants['active']]: {
              color: theme(`textColor.${token}` + suffix),
            },
          },

          [variants['disabled']]: {
            color: `${theme('textColor.on-disabled' + suffix)} !important`,
            backgroundColor: 'transparent !important',
          },

          transitionProperty: 'color, background-color, border-color, outline-color',
          transitionDuration: theme('transitionDuration.short'),
          transitionTimingFunction: theme('transitionTimingFunction.standard'),
        };
      },
    }, { values });
  }),
};
