const plugin = require('tailwindcss/plugin');
const { variants } = require('./core');

module.exports = {
  plugin: plugin(({ addComponents }) => {
    addComponents({
      '.interactivity-default': {
        pointerEvents: 'auto',
        userSelect: 'none',
        cursor: 'default',
      },

      '.interactivity-click': {
        pointerEvents: 'auto',
        userSelect: 'none',
        cursor: 'pointer',

        [variants['disabled']]: {
          pointerEvents: 'none !important',
          userSelect: 'none !important',
          cursor: 'default !important',
        },
      },

      '.interactivity-select': {
        pointerEvents: 'auto',
        userSelect: 'text',
        cursor: 'text',

        [variants['disabled']]: {
          pointerEvents: 'none !important',
          userSelect: 'none !important',
          cursor: 'default !important',
        },
      },

      '.interactivity-resize-row': {
        pointerEvents: 'auto',
        userSelect: 'none',
        cursor: 'row-resize',

        [variants['disabled']]: {
          pointerEvents: 'none !important',
          userSelect: 'none !important',
          cursor: 'default !important',
        },
      },

      '.interactivity-resize-column': {
        pointerEvents: 'auto',
        userSelect: 'none',
        cursor: 'col-resize',

        [variants['disabled']]: {
          pointerEvents: 'none !important',
          userSelect: 'none !important',
          cursor: 'default !important',
        },
      },

      '.interactivity-drag': {
        pointerEvents: 'auto',
        userSelect: 'none',
        cursor: 'grab',

        [variants['active']]: {
          cursor: 'grabbing',
        },

        [variants['disabled']]: {
          pointerEvents: 'none !important',
          userSelect: 'none !important',
          cursor: 'default !important',
        },
      },

      '.interactivity-none': {
        pointerEvents: 'none',
        userSelect: 'none',
        cursor: 'default',
      },
    });
  }),
};
