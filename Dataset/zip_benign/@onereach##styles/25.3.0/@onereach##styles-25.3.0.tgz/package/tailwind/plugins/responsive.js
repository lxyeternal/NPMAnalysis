const plugin = require('tailwindcss/plugin');
const screens = require('../../screens.json');


module.exports = {
  plugin: plugin(({ addVariant }) => {
    const minScreenValue = Math.min(...Object.values(screens).map(width => parseInt(width)));

    Object.entries(screens).forEach(([breakpoint, width]) => {
      addVariant(breakpoint, [
        `@media (min-width: ${width})`,
        `[force-screen~="${breakpoint}"] &`,
        `&[force-screen~="${breakpoint}"]`,
      ]);
    });

    // Custom variant for extra small screens
    addVariant('xs', [
      `@media (max-width: ${minScreenValue - 1}px)`,
      '[force-screen~="xs"] &',
      '&[force-screen~="xs"]',
    ]);
  }),
};
