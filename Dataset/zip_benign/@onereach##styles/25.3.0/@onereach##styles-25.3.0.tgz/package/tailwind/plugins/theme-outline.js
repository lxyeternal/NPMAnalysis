const plugin = require('tailwindcss/plugin');
const { variants } = require('./core');

const values = {
  'primary': 'primary-opacity-0-16',
  'primary-dark': 'primary-opacity-0-16..-dark',

  // 'secondary': 'secondary-opacity-0-16',
  // 'secondary-dark': 'secondary-opacity-0-16..-dark',

  // 'tertiary': 'tertiary-opacity-0-16',
  // 'tertiary-dark': 'tertiary-opacity-0-16..-dark',

  'success': 'success-opacity-0-16',
  'success-dark': 'success-opacity-0-16..-dark',

  'warning': 'warning-opacity-0-16',
  'warning-dark': 'warning-opacity-0-16..-dark',

  'error': 'error-opacity-0-16',
  'error-dark': 'error-opacity-0-16..-dark',

  'transparent': 'transparent',
  'transparent-dark': 'transparent..-dark',

  'current': 'current',
  'current-dark': 'current..-dark',

  'inherit': 'inherit',
  'inherit-dark': 'inherit..-dark',
};

module.exports = {
  values,

  plugin: plugin(({ matchComponents, theme }) => {
    matchComponents({
      'theme-outline': (value) => {
        const [token, suffix = ''] = value.split('..');

        return {
          outlineStyle: 'solid',
          outlineColor: theme(`outlineColor.${token}` + suffix, token),

          [variants['disabled']]: ['transparent'].includes(token) ? null : {
            outlineColor: `${theme('outlineColor.transparent' + suffix)} !important`,
          },

          transitionProperty: 'color, background-color, border-color, outline-color',
          transitionDuration: theme('transitionDuration.short'),
          transitionTimingFunction: theme('transitionTimingFunction.standard'),
        };
      },
    }, { values });
  }),
};
