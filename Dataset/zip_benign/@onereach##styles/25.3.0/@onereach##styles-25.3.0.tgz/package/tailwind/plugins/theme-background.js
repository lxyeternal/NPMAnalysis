const plugin = require('tailwindcss/plugin');
const { variants } = require('./core');

const values = {
  'base': 'white',
  'base-dark': 'black',

  'default': 'background',
  'default-dark': 'background..-dark',

  'overlay': 'overlay',
  'overlay-dark': 'overlay..-dark',

  'primary': 'primary',
  'primary-dark': 'primary..-dark',

  'secondary': 'secondary',
  'secondary-dark': 'secondary..-dark',

  'tertiary': 'tertiary',
  'tertiary-dark': 'tertiary..-dark',

  'success': 'success',
  'success-dark': 'success..-dark',

  'warning': 'warning',
  'warning-dark': 'warning..-dark',

  'error': 'error',
  'error-dark': 'error..-dark',

  'primary-hover': 'primary-hover',
  'primary-hover-dark': 'primary-hover..-dark',

  // 'secondary-hover': 'secondary-hover',
  // 'secondary-hover-dark': 'secondary-hover..-dark',

  // 'tertiary-hover': 'tertiary-hover',
  // 'tertiary-hover-dark': 'tertiary-hover..-dark',

  'success-hover': 'success-hover',
  'success-hover-dark': 'success-hover..-dark',

  'warning-hover': 'warning-hover',
  'warning-hover-dark': 'warning-hover..-dark',

  'error-hover': 'error-hover',
  'error-hover-dark': 'error-hover..-dark',

  'primary-translucent-1': 'primary-opacity-0-08',
  'primary-translucent-1-dark': 'primary-opacity-0-08..-dark',

  // 'secondary-translucent-1': 'secondary-opacity-0-08',
  // 'secondary-translucent-1-dark': 'secondary-opacity-0-08..-dark',

  // 'tertiary-translucent-1': 'tertiary-opacity-0-08',
  // 'tertiary-translucent-1-dark': 'tertiary-opacity-0-08..-dark',

  'success-translucent-1': 'success-opacity-0-08',
  'success-translucent-1-dark': 'success-opacity-0-08..-dark',

  'warning-translucent-1': 'warning-opacity-0-08',
  'warning-translucent-1-dark': 'warning-opacity-0-08..-dark',

  'error-translucent-1': 'error-opacity-0-08',
  'error-translucent-1-dark': 'error-opacity-0-08..-dark',

  'primary-translucent-2': 'primary-opacity-0-12',
  'primary-translucent-2-dark': 'primary-opacity-0-12..-dark',

  // 'secondary-translucent-2': 'secondary-opacity-0-12',
  // 'secondary-translucent-2-dark': 'secondary-opacity-0-12..-dark',

  // 'tertiary-translucent-2': 'tertiary-opacity-0-12',
  // 'tertiary-translucent-2-dark': 'tertiary-opacity-0-12..-dark',

  'success-translucent-2': 'success-opacity-0-12',
  'success-translucent-2-dark': 'success-opacity-0-12..-dark',

  'warning-translucent-2': 'warning-opacity-0-12',
  'warning-translucent-2-dark': 'warning-opacity-0-12..-dark',

  'error-translucent-2': 'error-opacity-0-12',
  'error-translucent-2-dark': 'error-opacity-0-12..-dark',

  'primary-translucent-3': 'primary-opacity-0-16',
  'primary-translucent-3-dark': 'primary-opacity-0-16..-dark',

  // 'secondary-translucent-3': 'secondary-opacity-0-16',
  // 'secondary-translucent-3-dark': 'secondary-opacity-0-16..-dark',

  // 'tertiary-translucent-3': 'tertiary-opacity-0-16',
  // 'tertiary-translucent-3-dark': 'tertiary-opacity-0-16..-dark',

  'success-translucent-3': 'success-opacity-0-16',
  'success-translucent-3-dark': 'success-opacity-0-16..-dark',

  'warning-translucent-3': 'warning-opacity-0-16',
  'warning-translucent-3-dark': 'warning-opacity-0-16..-dark',

  'error-translucent-3': 'error-opacity-0-16',
  'error-translucent-3-dark': 'error-opacity-0-16..-dark',

  'primary-container': 'primary-container',
  'primary-container-dark': 'primary-container..-dark',

  'secondary-container': 'secondary-container',
  'secondary-container-dark': 'secondary-container..-dark',

  'tertiary-container': 'tertiary-container',
  'tertiary-container-dark': 'tertiary-container..-dark',

  'success-container': 'success-container',
  'success-container-dark': 'success-container..-dark',

  'warning-container': 'warning-container',
  'warning-container-dark': 'warning-container..-dark',

  'error-container': 'error-container',
  'error-container-dark': 'error-container..-dark',

  'surface': 'surface',
  'surface-dark': 'surface..-dark',

  'surface-1': 'surface-1',
  'surface-1-dark': 'surface-1..-dark',

  'surface-2': 'surface-2',
  'surface-2-dark': 'surface-2..-dark',

  'surface-3': 'surface-3',
  'surface-3-dark': 'surface-3..-dark',

  'surface-4': 'surface-4',
  'surface-4-dark': 'surface-4..-dark',

  'surface-5': 'surface-5',
  'surface-5-dark': 'surface-5..-dark',

  'surface-variant': 'surface-variant',
  'surface-variant-dark': 'surface-variant..-dark',

  'surface-variant-1': 'surface-variant-1',
  'surface-variant-1-dark': 'surface-variant-1..-dark',

  'surface-inverse': 'inverse-surface',
  'surface-inverse-dark': 'inverse-surface..-dark',

  'outline': 'outline',
  'outline-dark': 'outline..-dark',

  'outline-variant': 'outline-variant',
  'outline-variant-dark': 'outline-variant..-dark',

  'outline-translucent-1': 'outline-opacity-0-08',
  'outline-translucent-1-dark': 'outline-opacity-0-08..-dark',

  'outline-translucent-2': 'outline-opacity-0-12',
  'outline-translucent-2-dark': 'outline-opacity-0-12..-dark',

  'outline-translucent-3': 'outline-opacity-0-16',
  'outline-translucent-3-dark': 'outline-opacity-0-16..-dark',

  'outline-translucent-4': 'outline-opacity-0-32',
  'outline-translucent-4-dark': 'outline-opacity-0-32..-dark',

  'outline-translucent-5': 'outline-opacity-0-48',
  'outline-translucent-5-dark': 'outline-opacity-0-48..-dark',

  'outline-translucent-6': 'outline-opacity-0-64',
  'outline-translucent-6-dark': 'outline-opacity-0-64..-dark',

  'outline-translucent-7': 'outline-opacity-0-80',
  'outline-translucent-7-dark': 'outline-opacity-0-80..-dark',

  'outline-translucent-8': 'outline-opacity-0-96',
  'outline-translucent-8-dark': 'outline-opacity-0-96..-dark',

  'disabled': 'disabled',
  'disabled-dark': 'disabled..-dark',

  'transparent': 'transparent',
  'transparent-dark': 'transparent..-dark',

  'current': 'current',
  'current-dark': 'current..-dark',

  'inherit': 'inherit',
  'inherit-dark': 'inherit..-dark',
};

module.exports = {
  values,

  plugin: plugin(({ matchComponents, theme }) => {
    matchComponents({
      'theme-background': (value) => {
        const [token, suffix = ''] = value.split('..');

        return {
          backgroundColor: theme(`backgroundColor.${token}` + suffix, token),

          [variants['disabled']]: ['white', 'black', 'transparent'].includes(token) ? null : {
            backgroundColor: `${theme('backgroundColor.disabled' + suffix)} !important`,
          },

          transitionProperty: 'color, background-color, border-color, outline-color',
          transitionDuration: theme('transitionDuration.short'),
          transitionTimingFunction: theme('transitionTimingFunction.standard'),
        };
      },
    }, { values });
  }),
};
