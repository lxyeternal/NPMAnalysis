const plugin = require('tailwindcss/plugin');

const variants = {
  'mobile': '@media (hover: none)',
  'desktop': '@media (hover: hover)',

  'draggable': ['&:is([draggable]:not([draggable="false"]))', '&[force-state~="draggable"]'],

  'checked': ['&:is([checked]:not([checked="false"]), :checked)', '&[force-state~="checked"]'],
  'selected': ['&:is([selected]:not([selected="false"]), :checked)', '&[force-state~="selected"]'],
  'activated': ['&:is([activated]:not([activated="false"]))', '&[force-state~="activated"]'],

  'enabled': ['&:is(:not([disabled]), [disabled="false"])', '&[force-state~="enabled"]'],
  'disabled': ['&:is([disabled]:not([disabled="false"]))', '&[force-state~="disabled"]'],

  'optional': ['&:is(:not([required]), [required="false"])', '&[force-state~="optional"]'],
  'required': ['&:is([required]:not([required="false"]))', '&[force-state~="required"]'],

  'read-write': ['&:is(:not([readonly]), [readonly="false"])', '&[force-state~="read-write"]'],
  'read-only': ['&:is([readonly]:not([readonly="false"]))', '&[force-state~="read-only"]'],

  'valid': ['&:is(:not([invalid]), [invalid="false"])', '&[force-state~="valid"]'],
  'invalid': ['&:is([invalid]:not([invalid="false"]))', '&[force-state~="invalid"]'],

  // Sub-components
  'children': process.env.OREST_SCOPED_STYLES === 'true'
    ? ['& > :deep(*)']
    : ['& > *'],

  get 'hover'() {
    return this['enabled'].flatMap((selector) => [
      `${selector}:not(.interactivity-none):not([force-state]):hover`,
      `${selector}:not(.interactivity-none)[force-state~="hover"]`,
    ]);
  },

  get 'focus'() {
    return this['enabled'].flatMap((selector) => [
      `${selector}:not(.interactivity-none):not([force-state]):focus`,
      `${selector}:not(.interactivity-none)[force-state~="focus"]`,
    ]);
  },

  get 'focus-within'() {
    return this['enabled'].flatMap((selector) => [
      `${selector}:not(.interactivity-none):not([force-state]):focus-within`,
      `${selector}:not(.interactivity-none)[force-state~="focus-within"]`,
    ]);
  },

  get 'focus-visible'() {
    return this['enabled'].flatMap((selector) => [
      `${selector}:not(.interactivity-none):not([force-state]):focus-visible`,
      `${selector}:not(.interactivity-none)[force-state~="focus-visible"]`,
    ]);
  },

  get 'active'() {
    return this['enabled'].flatMap((selector) => [
      `${selector}:not(.interactivity-none):not([force-state]):active`,
      `${selector}:not(.interactivity-none)[force-state~="active"]`,
    ]);
  },
};

module.exports = {
  variants,

  plugin: plugin(({ addVariant, addUtilities }) => {
    Object.entries(variants).forEach(([modifier, selectors]) => {
      addVariant(modifier, selectors);
    });

    // TODO: Remove when migration complete
    addUtilities({
      '.visually-hidden': {
        width: 0,
        height: 0,
        visibility: 'hidden',
      },
    });
  }),
};
