const plugin = require('tailwindcss/plugin');

const values = {
  'outlined': '"opsz" 24, "wght" 400, "FILL" 0, "GRAD" 0',
  'outlined-bold': '"opsz" 24, "wght" 700, "FILL" 0, "GRAD" 0',

  'filled': '"opsz" 24, "wght" 400, "FILL" 1, "GRAD" 0',
  'filled-bold': '"opsz" 24, "wght" 700, "FILL" 1, "GRAD" 0',

  'inherit': 'inherit',
};

module.exports = {
  plugin: plugin(({ matchComponents, addComponents }) => {
    matchComponents({
      'iconography': (value) => ({
        fontFamily: '"Material Symbols Outlined"',
        fontVariationSettings: value,
      }),
    }, { values });

    addComponents({
      '.iconography-onereach': {
        fontFamily: '"OneReach Icons"',
      },
    });
  }),
};
