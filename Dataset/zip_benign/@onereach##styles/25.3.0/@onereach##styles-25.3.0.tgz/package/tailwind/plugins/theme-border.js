const plugin = require('tailwindcss/plugin');
const { variants } = require('./core');

const values = {
  'primary': 'primary',
  'primary-dark': 'primary..-dark',

  'secondary': 'secondary',
  'secondary-dark': 'secondary..-dark',

  'tertiary': 'tertiary',
  'tertiary-dark': 'tertiary..-dark',

  'success': 'success',
  'success-dark': 'success..-dark',

  'warning': 'warning',
  'warning-dark': 'warning..-dark',

  'error': 'error',
  'error-dark': 'error..-dark',

  'outline': 'outline',
  'outline-dark': 'outline..-dark',

  'outline-variant': 'outline-variant',
  'outline-variant-dark': 'outline-variant..-dark',

  'disabled': 'disabled',
  'disabled-dark': 'disabled..-dark',

  'transparent': 'transparent',
  'transparent-dark': 'transparent..-dark',

  'current': 'current',
  'current-dark': 'current..-dark',

  'inherit': 'inherit',
  'inherit-dark': 'inherit..-dark',
};

module.exports = {
  values,

  plugin: plugin(({ matchComponents, theme }) => {
    matchComponents({
      'theme-border': (value) => {
        const [token, suffix = ''] = value.split('..');

        return {
          borderStyle: 'solid',
          borderColor: theme(`borderColor.${token}` + suffix, token),

          [variants['disabled']]: ['transparent'].includes(token) ? null : {
            borderColor: `${theme('borderColor.disabled' + suffix)} !important`,
          },

          transitionProperty: 'color, background-color, border-color, outline-color',
          transitionDuration: theme('transitionDuration.short'),
          transitionTimingFunction: theme('transitionTimingFunction.standard'),
        };
      },
    }, { values });
  }),
};
