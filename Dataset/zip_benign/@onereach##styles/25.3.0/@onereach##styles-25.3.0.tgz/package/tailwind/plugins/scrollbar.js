const plugin = require('tailwindcss/plugin');

module.exports = {
  plugin: plugin(({ addComponents }) => {
    addComponents({
      '.scrollbar-hidden': {
        // Webkit
        '&::-webkit-scrollbar': {
          width: 0,
          height: 0,
        },

        // Gecko
        scrollbarWidth: 'none',
      },
    });
  }),
};
