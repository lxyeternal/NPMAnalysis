module.exports = {
  parseSpacingTokens(designTokens) {
    return Object.values(designTokens)
      .reduce((preset, { name, value }) => ({
        ...preset,
        ...name === 'none'
          ? { '0': value }
          : {
            [name]: value,
            [`${name}*`]: `${Number(value.match(/^(\d+)px$/)[1]) - 1}px`,
          },
      }), {});
  },

  parseColorTokens(designTokens, colorGroups) {
    const isBackground = (name) => /\b(?:container|background|surface)\b/.test(name) && !isText(name);
    const isText = (name) => /\b(?:on)\b/.test(name);
    const isShadow = (name) => /\b(?:shadow)\b/.test(name);

    const defineColorGroup = (name) => {
      switch (true) {
        case isBackground(name):
          return 'background';

        case isText(name):
          return 'text';

        case isShadow(name):
          return null;

        default:
          return 'generic';
      }
    };

    return Object.values(designTokens)
      .map((token) => {
        const { name, theme } = token.name.match(/^(?:(?<theme>light|dark)-)?(?<name>.+)$/).groups;

        return {
          name,
          theme,
          group: defineColorGroup(name),
          color: token.value.replace(/rgba\((\d+),(\d+),(\d+),([\d.]+)\)/, 'rgba($1 $2 $3 / $4)'),
        };
      })
      .filter(({ group }) => colorGroups.includes(group))
      .reduce((preset, { name, theme, color }) => ({
        ...preset,
        [!theme || theme === 'light' ? name : `${name}-${theme}`]: color,
      }), {});
  },

  parseBorderRadiusTokens(designTokens) {
    return Object.values(designTokens)
      .map((token) => ({
        name: token.name,
        borderRadius: token.value,
      }))
      .reduce((preset, { name, borderRadius }) => ({
        ...preset,
        [name]: borderRadius,
      }), {});
  },

  parseBorderWidthTokens(designTokens) {
    return Object.values(designTokens)
      .map((token) => {
        const borderWidth = token.value.split(' ')[0];

        return {
          name: borderWidth.slice(0, -2),
          borderWidth,
        };
      })
      .reduce((preset, { name, borderWidth }) => ({
        ...preset,
        [name]: borderWidth,
      }), {});
  },

  parseBoxShadowTokens(designTokens) {
    return Object.values(designTokens)
      .map((token) => {
        const { name, theme } = token.name.match(/^(?:(?<theme>light|dark)-)?(?<name>.+)$/).groups;

        return {
          name,
          theme,
          boxShadow: token.value
            .replace(/\b0px\b/g, '0')
            .replace(/rgba\((\d+),(\d+),(\d+),([\d.]+)\)/g, 'rgba($1 $2 $3 / $4)'),
        };
      })
      .reduce((preset, { name, theme, boxShadow }) => ({
        ...preset,
        [!theme || theme === 'light' ? name : `${name}-${theme}`]: boxShadow,
      }), {});
  },

  parseFontFamilyTokens(designTokens) {
    return Object.values(designTokens)
      .reduce((preset, { name, fontFamily }) => ({
        ...preset,
        [name]: fontFamily,
      }), {});
  },

  parseFontSizeTokens(designTokens) {
    return Object.values(designTokens)
      .reduce((preset, { name, fontSize, lineHeight }) => ({
        ...preset,
        [name]: [fontSize, { lineHeight }],
      }), {});
  },

  parseFontWeightTokens(designTokens) {
    return Object.values(designTokens)
      .reduce((preset, { name, fontWeight }) => ({
        ...preset,
        [name]: fontWeight,
      }), {});
  },

  parseColorTokensNames(designTokens, colorGroups) {
    const prefix = 'or-c';
    const isBackground = (name) => /\b(?:container|background|surface)\b/.test(name) && !isText(name);
    const isText = (name) => /\b(?:on)\b/.test(name);
    const isShadow = (name) => /\b(?:shadow)\b/.test(name);

    const defineColorGroup = (name) => {
      switch (true) {
        case isBackground(name):
          return 'background';

        case isText(name):
          return 'text';

        case isShadow(name):
          return null;

        default:
          return 'generic';
      }
    };

    const colorVars = Object.values(designTokens)
      .map((token) => {
        const { name, theme } = token.name.match(/^(?:(?<theme>light|dark)-)?(?<name>.+)$/).groups;

        return {
          // name: `${name}${theme ? `-${theme}` : ''}`, we skip 'light' postfix now
          name: `${name}${theme && theme !== 'light' ? `-${theme}` : ''}`,
          group: defineColorGroup(name),
          color: `var(--${prefix}-${name}${theme ? `-${theme}` : ''})`,
        };
      })
      .filter(({ group }) => colorGroups.includes(group));

    const colorMap = colorVars.reduce((preset, { name, color }) => {
      preset[name] = color;
      return preset;
    }, {});

    // Add default colors
    // Object.keys(colorMap).forEach((color) => {
    //   const colorParts = color.split('-');
    //   if (colorParts.length > 1) {
    //     const defaultColor = colorParts.slice(0, -1).join('-');
    //     if (!colorMap[defaultColor]) {
    //       colorMap[defaultColor] = `var(--${prefix}-${defaultColor})`;
    //     }
    //   }
    // });

    return colorMap;
  },
};
