module.exports = {
  // this file used as default config file and can be overridden on app side by creating tailwind.config.js file in
  // the app root, this file is a problem as we need to modify in to allow tailwind usage in ui libraries
  // TODO: Refactor this to allow to add new libs without modifying and performance loose
  content: [
    './src/**/*.{vue,js,mjs,ts,jsx,tsx}',
    './node_modules/@onereach/service-navigation/dist/auto/**/*.{vue,js,mjs,ts,jsx,tsx}',
    './node_modules/@onereach/auth-ui-module/dist/auto/**/*.{vue,js,mjs,ts,jsx,tsx}',
    './node_modules/@onereach/ui-components/dist/esm/**/*.{vue,js,mjs,ts,jsx,tsx}',
  ],
  presets: [
    require('@onereach/styles/tailwind.config.preset.js'),
  ],
};
