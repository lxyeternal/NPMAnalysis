import VueGaplessScroll from "./gapless-scroll/index.vue";

const components = [VueGaplessScroll];

const install = (Vue) => {
  components.forEach((v) => {
    Vue.component(v.name, v);
  });
};

if (typeof window !== "undefined" && window.Vue) {
  install(window.Vue);
}

export default { install, VueGaplessScroll };
