import VueGaplessScroll from "./index.vue";

VueGaplessScroll.install = (Vue) => {
  Vue.component(VueGaplessScroll.name, VueGaplessScroll);
};

export default VueGaplessScroll;
