import { MinUIComponent } from "./components";

export type GaplessScrollOptions = {
  // 0:无缝滚动(用于无点击事件) 1: 触底滚动(到达最后一个会返回顶部，用于点击事件滚动)
  scrollType: number;
  // 滚动方向 up:向上滚动 down:向下 left:向左 right:向右
  direction: "up" | "down" | "left" | "right";
  // 滚动速度 数字越大越快
  speed: number;
  // 符合滚动条件后是否自动滚动
  autoPlay: boolean;
  // 鼠标悬停是否停止滚动
  hoverStop: boolean;
  // 单次滚动(轮播)距离(仅在interval不为0生效)
  step: number;
  // 轮播停留间隔 0为自动滚动
  interval: number;
  // 带间隔的轮播(interval不为0)是否显示(左右/上下)控制器
  controls: boolean;
  // 自定义控制器时，两边控制器宽(左右滚动时)或高(上下滚动时)总和
  // 即为外层容器width/height需补充的padding
  controlsPadding: number[];
  // 单次轮播动画时间(仅在点击(左右/上下)控制器时生效,0无动画)
  animateTime: number;
  // 无内容时显示的图src
  emptyImg: string;
  // 无内容时显示的文字
  emptyText: string;
  // 无数据时图片显示大小
  emptyWidth: string;
  //  解决水平无缝时margin间隔问题
  marginBias: number;
};

export declare class VueGaplessScroll extends MinUIComponent {
  // 外容器宽度
  width: number;
  // 外容器高度
  height: number;
  // 数据
  list: any[];
  options: Partial<GaplessScrollOptions>;
}
