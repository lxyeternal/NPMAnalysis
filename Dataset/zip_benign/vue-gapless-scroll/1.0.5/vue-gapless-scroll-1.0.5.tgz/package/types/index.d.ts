export * from "./min-ui";

import * as VueGaplessScroll from "./min-ui";
export default VueGaplessScroll;
