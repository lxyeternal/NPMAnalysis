import Vue from "vue";
export declare class MinUIComponent extends Vue {
  static install(vue: typeof Vue): void;
}
