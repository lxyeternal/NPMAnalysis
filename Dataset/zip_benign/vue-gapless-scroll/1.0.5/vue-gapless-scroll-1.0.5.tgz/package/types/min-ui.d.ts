// import Vue, { PluginObject } from "vue";

import { VueGaplessScroll } from "./vue-gapless-scroll";

export class GaplessScroll extends VueGaplessScroll {}
