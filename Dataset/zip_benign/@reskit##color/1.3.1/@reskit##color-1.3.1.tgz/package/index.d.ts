import type { Color } from "./src/entities/color";
import { getImageInUint8Array } from "./src/extract";
declare function extractColor(text: string): string[];
declare function extractImageColor(url: string | File, n?: number, scaleDown?: boolean): Promise<Color[]>;
declare function extractImageColorInRust(url: string | File, n?: number, scaleDown?: boolean): Promise<Color[]>;
export { extractColor, extractImageColor, extractImageColorInRust, getImageInUint8Array };
