import { Color } from "./entities/color";
declare function getImageInUint8Array(url: string, scaleDown?: boolean): Promise<Uint8Array>;
declare function extractColorFromImage(imageData: Uint8Array, maxNum: number): Promise<Color[]>;
export { getImageInUint8Array, extractColorFromImage };
