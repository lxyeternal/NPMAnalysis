import { Color } from "./color";
declare class ColorGroup {
    main: Color;
    num: number;
    setMainColor(color: Color): void;
    getDistance(c: Color): number;
    addColor(color: Color): void;
}
export { ColorGroup };
