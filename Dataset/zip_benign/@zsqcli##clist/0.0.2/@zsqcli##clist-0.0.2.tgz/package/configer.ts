export const cfgItem = [{
  label: 'x',
  name: 'x',
  value: 0,
  placeholder: '例如：10',
  type: []
}, {
  label: 'y',
  name: 'y',
  value: 0,
  placeholder: '例如：10',
  type: []
}, {
  label: 'clazz',
  name: 'clazz',
  value: '',
  placeholder: '例如：cz-title',
  type: []
}, {
  label: '请求参数',
  name: 'params',
  value: '',
  placeholder: '例如：{id: 2}',
  type: []
}, {
  label: '请求方式',
  name: 'method',
  value: 'get',
  placeholder: '例如：get',
  type: [{
    id: 'get',
    name: 'get'
  }, {
    id: 'post',
    name: 'post'
  }, {
    id: 'put',
    name: 'put'
  }, {
    id: 'delete',
    name: 'delete'
  }]
}, {
  label: '请求地址',
  name: 'url',
  value: '',
  placeholder: '例如：',
  type: []
}, {
  label: '数据',
  name: 'data',
  value: [['2021-02-01', '测试内容', '100', '普通类型'],
  ['2021-02-01', '测试内容', '100', '特殊类型']],
  placeholder: '例如：[]',
  type: []
}, {
  label: '宽度',
  name: 'width',
  value: '400px',
  placeholder: '例如：400px',
  type: []
}, {
  label: '高度',
  name: 'height',
  value: '202px',
  placeholder: '例如：704px',
  type: []
}, {
  label: '列标题',
  name: 'title',
  value: [
    { createTime: '时间', show: true },
    { content: '内容', show: true },
    { score: '分数', show: false },
    { type: '类型', show: true }
  ],
  placeholder: `例如：[
    { createTime: '时间', show: true },
    { content: '内容', show: true },
    { score: '分数', show: false },
    { type: '类型', show: true }
  ]`,
  type: []
}, {
  label: '列宽',
  name: 'columnWidth',
  value: ['34%', '40%', '', '26%'],
  placeholder: `例如：['34%', '40%', '', '26%']`,
  type: []
}, {
  label: '标题字号',
  name: 'headerFontSize',
  value: '14px',
  placeholder: '例如：14px',
  type: []
}, {
  label: '标题颜色',
  name: 'headerFontColor',
  value: 'rgb(137, 171, 205)',
  placeholder: '例如：rgb(137, 171, 205)',
  type: []
}, {
  label: '标题行高',
  name: 'headerHeight',
  value: '40px',
  placeholder: '例如：40px',
  type: []
}, {
  label: '背景Url',
  name: 'headerBGUrl',
  value: './images/sft/listbg1.png',
  placeholder: '例如：./images/sft/listbg1.png',
  type: []
}, {
  label: '背景颜色',
  name: 'headerBGColor',
  value: '',
  placeholder: '例如：#eee',
  type: ['color']
}, {
  label: '内容字号',
  name: 'bodyFontSize',
  value: '14px',
  placeholder: '例如：14px',
  type: []
}, {
  label: '内容颜色',
  name: 'bodyFontColor',
  value: '#888',
  placeholder: '例如：#888',
  type: ['color']
}, {
  label: '内容行高',
  name: 'bodyRowHeight',
  value: '40px',
  placeholder: '例如：40px',
  type: []
}, {
  label: '行背景色',
  name: 'rowBGColor',
  value: 'rgba(0, 0, 0, 0.3)/none',
  placeholder: '例如：rgba(0, 0, 0, 0.3)/none',
  type: []
}, {
  label: '开启滚动',
  name: 'isScroll',
  value: '是',
  placeholder: '例如：是',
  type: [{
    id: '是',
    name: '是'
  }, {
    id: '否',
    name: '否'
  }]
}, {
  label: '显示标题',
  name: 'showHeader',
  value: '是',
  placeholder: '例如：是',
  type: [{
    id: '是',
    name: '是'
  }, {
    id: '否',
    name: '否'
  }]
}, {
  label: '提示框背景色',
  name: 'tooltipColor',
  value: 'rgb(16, 32, 50)',
  placeholder: '例如：rgb(16, 32, 50)',
  type: ['color']
}]

export default {
  x: 0,
  y: 0,
  clazz: '',
  params: {},
  url: '',
  method: 'get',
  data: [['2021-02-01', '测试内容', '100', '普通类型'],
  ['2021-02-01', '测试内容', '100', '特殊类型']],

  width: '400px',
  height: '200px',
  title: [
    { createTime: '时间', show: true },
    { content: '内容', show: true },
    { score: '分数', show: false },
    { type: '类型', show: true }
  ],
  columnWidth: ['34%', '40%', '', '26%'],
  headerFontSize: '14px',
  headerFontColor: 'rgb(137, 171, 205)',
  headerHeight: '40px',
  headerBGUrl: './images/sft/listbg1.png',
  headerBGColor: '',

  bodyFontSize: '14px',
  bodyFontColor: '#888',
  bodyRowHeight: '40px',
  rowBGColor: 'rgba(0, 0, 0, 0.3)/none',
  isScroll: '是',
  showHeader: '是',
  tooltipColor: 'rgb(16, 32, 50)'
}