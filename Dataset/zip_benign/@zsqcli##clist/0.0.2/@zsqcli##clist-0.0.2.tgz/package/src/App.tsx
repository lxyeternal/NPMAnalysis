import React, { FC } from 'react'
import 'antd/dist/antd.css'
import CList from '@/component'


const App: FC = () => {
  return (
    <div className="app">
      <CList /> 
    </div>
  )
}

export default App