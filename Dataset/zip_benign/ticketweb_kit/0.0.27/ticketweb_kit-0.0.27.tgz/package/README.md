# ticketweb_kit

ticket 公共组件库

## Version

### TODO

1. 增加网络请求模块

### 0.27 fix: 进度组件标题过长导致样式错乱

### 0.26 user 组件只读模式从 user.fullname 中获取值

### 0.23 支持接口拉取语言配置文件

### 0.13

1. fix sn 格式

### 0.7

1. 本地配置多语言文件

### 0.6

1. 支持 user 组件
2. form 支持传入 columns 字段和 data 数据，用于解析特定格式的表单字段

### 0.4

1. 支持多语言
2. form 表单去掉 columns 参数
