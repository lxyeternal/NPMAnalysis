// This file contains utility functions for various tasks within the package.

// export function formatDate(date) {
//     return new Intl.DateTimeFormat('en-US').format(date);
// }

// export function capitalizeFirstLetter(string) {
//     return string.charAt(0).toUpperCase() + string.slice(1);
// }

// export function deepClone(obj) {
//     return JSON.parse(JSON.stringify(obj));
// }