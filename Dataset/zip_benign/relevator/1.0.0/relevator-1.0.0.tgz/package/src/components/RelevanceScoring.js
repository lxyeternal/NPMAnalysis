export default class Relevator {
  constructor(config) {
    this.validateConfig(config);
    this.config = config;
  }

  validateConfig(config) {
    if (!config.weights || !config.normalizers) {
      throw new Error('Config must include weights and normalizers');
    }

    if (Object.keys(config.weights).length === 0) {
      throw new Error('Weights object cannot be empty');
    }

    if (Object.keys(config.normalizers).length === 0) {
      throw new Error('Normalizers object cannot be empty');
    }

    // Validate that weights sum to 1
    const weightSum = Object.values(config.weights).reduce((sum, weight) => sum + weight, 0);
    if (Math.abs(weightSum - 1) > 0.0001) { // Allow for floating point imprecision
      throw new Error('Weights must sum to 1');
    }
  }

  calculateScore(content) {
    let totalScore = 0;

    // Process each metric
    Object.entries(content).forEach(([metric, value]) => {
      // Skip if no weight defined
      if (!this.config.weights[metric]) return;

      // Get normalized value
      let normalizedValue = this.normalizeMetric(metric, value);

      // Apply custom calculator if exists
      if (this.config.customCalculators && this.config.customCalculators[metric]) {
        normalizedValue = this.config.customCalculators[metric](value, normalizedValue);
      }

      // Add weighted score
      totalScore += normalizedValue * this.config.weights[metric];
    });

    return totalScore;
  }

  // Calculate normalized score for a single metric
  normalizeMetric(metricName, value) {
    const normalizer = this.config.normalizers[metricName];
    if (!normalizer) return value;

    if (typeof normalizer === 'function') {
      return normalizer(value);
    }

    // Default normalization strategies
    switch (normalizer.type) {
      case 'linear':
        return Math.min(1, value / normalizer.max);
      
      case 'logarithmic':
        return Math.min(1, 
          Math.log(value + 1) / Math.log(normalizer.max + 1)
        );
      
      case 'boolean':
        return value ? 1 : 0;
      
      case 'bellCurve':
        return Math.min(1, Math.exp(
          -Math.pow(value - normalizer.ideal, 2) / 
          (2 * Math.pow(normalizer.max / 3, 2))
        ));
      
      case 'plateau':
        if (value <= normalizer.ideal) {
          return value / normalizer.ideal;
        }
        // Exponential decay after ideal
        return Math.exp(-(value - normalizer.ideal) / (normalizer.max - normalizer.ideal));
      
      default:
        return value;
    }
  }
}