/// <reference types="node" />
interface CaptchaOptions {
    imageOptions?: {
        width: number;
        height: number;
        puzzleSize?: number;
        padding?: number;
    };
    image?: Buffer;
    distort?: boolean;
    rotate?: boolean;
    fill?: string;
    stroke?: string;
    strokeWidth?: string;
    opacity?: string;
}
declare const createCaptcha: (options?: CaptchaOptions) => Promise<{
    data: {
        background: Buffer;
        slider: Buffer;
    };
    solution: number;
}>;
export default createCaptcha;
