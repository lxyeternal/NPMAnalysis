declare const createRandomInteger: (min?: number, max?: number) => number;
declare const backgroundSvg: (width: number, height: number, { gridWidth, gridHeight, scheme, seeds, }?: {
    gridWidth?: number | undefined;
    gridHeight?: number | undefined;
    scheme?: string[] | undefined;
    seeds?: number[] | undefined;
}) => string;
declare const puzzlePieceSvg: ({ distort, rotate, fill, stroke, seed, opacity, strokeWidth, }?: {
    distort?: boolean | undefined;
    rotate?: boolean | undefined;
    fill?: string | undefined;
    stroke?: string | undefined;
    seed?: number | undefined;
    opacity?: string | undefined;
    strokeWidth?: string | undefined;
}) => string;
export { puzzlePieceSvg, backgroundSvg, createRandomInteger };
