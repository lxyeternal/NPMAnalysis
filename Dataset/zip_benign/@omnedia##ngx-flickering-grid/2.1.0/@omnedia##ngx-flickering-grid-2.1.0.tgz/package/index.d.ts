/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@omnedia/ngx-flickering-grid" />
export * from './public-api';
