import * as i1 from '@angular/common';
import { isPlatformBrowser, CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { PLATFORM_ID, Component, Inject, ViewChild, Input } from '@angular/core';

class NgxFlickeringGridComponent {
    platformId;
    background;
    canvas;
    styleClass;
    squareSize = 4;
    gridGap = 6;
    flickerChance = 0.3;
    color = "#6B7280";
    maxOpacity = 0.3;
    intersectionObserver;
    ctx;
    cols = 0;
    rows = 0;
    squares;
    lastAnimationTime = 0;
    animationFrameId;
    memoizedColor = "rgba(0, 0, 0,";
    isInView = false;
    animating = false;
    constructor(platformId) {
        this.platformId = platformId;
    }
    ngAfterViewInit() {
        this.initCanvas();
        if (isPlatformBrowser(this.platformId)) {
            this.intersectionObserver = new IntersectionObserver(([entry]) => {
                this.renderContents(entry.isIntersecting);
            });
            this.intersectionObserver.observe(this.canvas.nativeElement);
        }
    }
    ngOnDestroy() {
        window.removeEventListener("resize", () => this.setCanvasSize());
        if (this.intersectionObserver) {
            this.intersectionObserver.disconnect();
        }
        if (this.animationFrameId) {
            cancelAnimationFrame(this.animationFrameId);
        }
    }
    renderContents(isIntersecting) {
        if (isIntersecting && !this.isInView) {
            this.isInView = true;
            if (!this.animating) {
                this.animationFrameId = requestAnimationFrame((time) => this.animateCanvas(time));
            }
        }
        else if (!isIntersecting) {
            this.isInView = false;
        }
    }
    initCanvas() {
        this.setCanvasSize();
        this.setMemoizedColor();
        window.addEventListener("resize", () => this.setCanvasSize());
        if (!this.animating) {
            this.animationFrameId = requestAnimationFrame((time) => this.animateCanvas(time));
        }
    }
    setMemoizedColor() {
        if (typeof window === "undefined") {
            this.memoizedColor = `rgba(0, 0, 0,`;
            return;
        }
        const canvas = document.createElement("canvas");
        canvas.width = canvas.height = 1;
        const ctx = canvas.getContext("2d", {
            willReadFrequently: true,
        });
        if (!ctx) {
            this.memoizedColor = `rgba(0, 0, 0,`;
            return;
        }
        ctx.fillStyle = this.color;
        ctx.fillRect(0, 0, 1, 1);
        const [r, g, b] = ctx.getImageData(0, 0, 1, 1).data;
        this.memoizedColor = `rgba(${r}, ${g}, ${b},`;
        return;
    }
    animateCanvas(time) {
        if (!this.isInView) {
            this.animating = false;
            return;
        }
        this.animating = true;
        const deltaTime = (time - this.lastAnimationTime) / 1000;
        this.lastAnimationTime = time;
        this.updateSquares(deltaTime);
        this.drawGrid();
        this.animationFrameId = requestAnimationFrame((time) => this.animateCanvas(time));
    }
    setCanvasSize() {
        this.canvas.nativeElement.width =
            this.background.nativeElement.getBoundingClientRect().width;
        this.canvas.nativeElement.height =
            this.background.nativeElement.getBoundingClientRect().height;
        this.setupCanvas();
        this.ctx = this.canvas.nativeElement.getContext("2d", {
            willReadFrequently: true,
        });
    }
    setupCanvas() {
        this.cols = Math.ceil(this.canvas.nativeElement.width / (this.squareSize + this.gridGap));
        this.rows = Math.ceil(this.canvas.nativeElement.height / (this.squareSize + this.gridGap));
        this.squares = new Float32Array(this.cols * this.rows);
        for (let i = 0; i < this.squares.length; i++) {
            this.squares[i] = Math.random() * this.maxOpacity;
        }
    }
    updateSquares(deltaTime) {
        if (!this.squares) {
            return;
        }
        for (let i = 0; i < this.squares.length; i++) {
            if (Math.random() < this.flickerChance * deltaTime) {
                this.squares[i] = Math.random() * this.maxOpacity;
            }
        }
    }
    drawGrid() {
        if (!this.squares) {
            return;
        }
        this.ctx.clearRect(0, 0, this.canvas.nativeElement.width, this.canvas.nativeElement.height);
        this.ctx.fillStyle = "transparent";
        this.ctx.fillRect(0, 0, this.canvas.nativeElement.width, this.canvas.nativeElement.height);
        const [r, g, b] = this.ctx.getImageData(0, 0, 1, 1).data;
        for (let i = 0; i < this.cols; i++) {
            for (let j = 0; j < this.rows; j++) {
                const opacity = this.squares[i * this.rows + j];
                this.ctx.fillStyle = `${this.memoizedColor}${opacity})`;
                this.ctx.fillRect(i * (this.squareSize + this.gridGap), j * (this.squareSize + this.gridGap), this.squareSize, this.squareSize);
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.0", ngImport: i0, type: NgxFlickeringGridComponent, deps: [{ token: PLATFORM_ID }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.0", type: NgxFlickeringGridComponent, isStandalone: true, selector: "om-flickering-grid", inputs: { styleClass: "styleClass", squareSize: "squareSize", gridGap: "gridGap", flickerChance: "flickerChance", color: "color", maxOpacity: "maxOpacity" }, viewQueries: [{ propertyName: "background", first: true, predicate: ["OmFlickeringGridBackground"], descendants: true }, { propertyName: "canvas", first: true, predicate: ["OmFlickeringGridCanvas"], descendants: true }], ngImport: i0, template: "<div class=\"om-flickering-grid\" [ngClass]=\"styleClass\">\r\n    <div class=\"om-flickering-grid-background\" #OmFlickeringGridBackground>\r\n        <canvas class=\"om-flickering-grid-canvas\" width=\"100\" height=\"100\" #OmFlickeringGridCanvas></canvas>\r\n    </div>\r\n    <div class=\"om-flickering-grid-content\">\r\n        <ng-content></ng-content>\r\n    </div>\r\n</div>", styles: [".om-flickering-grid{position:relative;width:100%;height:100%}.om-flickering-grid .om-flickering-grid-background{position:absolute;width:100%;height:100%;pointer-events:none;overflow:hidden}.om-flickering-grid .om-flickering-grid-background canvas{pointer-events:none;z-index:0;position:absolute;inset:0}.om-flickering-grid .om-flickering-grid-content{position:relative;z-index:1;width:100%;height:100%}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.0", ngImport: i0, type: NgxFlickeringGridComponent, decorators: [{
            type: Component,
            args: [{ selector: "om-flickering-grid", standalone: true, imports: [CommonModule], template: "<div class=\"om-flickering-grid\" [ngClass]=\"styleClass\">\r\n    <div class=\"om-flickering-grid-background\" #OmFlickeringGridBackground>\r\n        <canvas class=\"om-flickering-grid-canvas\" width=\"100\" height=\"100\" #OmFlickeringGridCanvas></canvas>\r\n    </div>\r\n    <div class=\"om-flickering-grid-content\">\r\n        <ng-content></ng-content>\r\n    </div>\r\n</div>", styles: [".om-flickering-grid{position:relative;width:100%;height:100%}.om-flickering-grid .om-flickering-grid-background{position:absolute;width:100%;height:100%;pointer-events:none;overflow:hidden}.om-flickering-grid .om-flickering-grid-background canvas{pointer-events:none;z-index:0;position:absolute;inset:0}.om-flickering-grid .om-flickering-grid-content{position:relative;z-index:1;width:100%;height:100%}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Inject,
                    args: [PLATFORM_ID]
                }] }], propDecorators: { background: [{
                type: ViewChild,
                args: ["OmFlickeringGridBackground"]
            }], canvas: [{
                type: ViewChild,
                args: ["OmFlickeringGridCanvas"]
            }], styleClass: [{
                type: Input,
                args: ["styleClass"]
            }], squareSize: [{
                type: Input,
                args: ["squareSize"]
            }], gridGap: [{
                type: Input,
                args: ["gridGap"]
            }], flickerChance: [{
                type: Input,
                args: ["flickerChance"]
            }], color: [{
                type: Input,
                args: ["color"]
            }], maxOpacity: [{
                type: Input,
                args: ["maxOpacity"]
            }] } });

/*
 * Public API Surface of ngx-flickering-grid
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxFlickeringGridComponent };
//# sourceMappingURL=omnedia-ngx-flickering-grid.mjs.map
