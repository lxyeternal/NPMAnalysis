export * from './lib/ngx-flickering-grid.component';
