/* tslint:disable */
/* eslint-disable */
/**
* @param {string} code 
* @returns {string} 
*/
export function run(code: string): string;
