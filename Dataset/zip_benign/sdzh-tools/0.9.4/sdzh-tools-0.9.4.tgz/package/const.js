"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.REG = {
    // 邮箱
    email: /[\w!#$%&'*+/=?^_`{|}~-]+(?:\.[\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[\w](?:[\w-]*[\w])?/,
    zh: /[\u4e00-\u9fa5]/,
    // 只允许中英文和空格
    zh_en: /^[\u4E00-\u9FA5A-Za-z0-9\s]*$/g
};
