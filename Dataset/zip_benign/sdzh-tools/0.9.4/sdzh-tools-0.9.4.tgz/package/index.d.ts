import { AxiosRequestConfig, CancelTokenSource } from 'axios';
import JSZip from 'jszip';
import PreviewFile from './component/previewFile/previewFile';
import PreviewImage from './component/previewImage/previewImage';
import PreviewVideo from './component/previewVideo/previewVideo';
import ChangeSchoolModal from './component/changeSchoolModal/changeSchoolModal';
import CreateSchoolModal from './component/createSchoolModal/createSchoolModal';
export { PreviewFile, PreviewImage, PreviewVideo, ChangeSchoolModal, CreateSchoolModal };
export declare function decodeText(payload: any): ({
    name: string;
    text: any;
    src?: undefined;
} | {
    name: string;
    src: string;
    text?: undefined;
})[];
export declare const emojiUrl = "https://imgcache.qq.com/open/qcloud/tim/assets/emoji/";
export declare const emojiMap: {
    [key: string]: string;
};
export declare const emojiName: string[];
export declare const CHANGE_TITLE_ICON: (name: string, icon: string) => void;
export declare const VALIDATE_TEXT_LENGTH: (v: string) => number;
export declare const DES: (option: {
    key: string;
    message: string;
    type?: "decrypt" | "encrypt" | undefined;
}) => string;
export declare const RETURN_CHAPTER_INDEX: (length: number) => string;
/**
 * 阿里云存储
 */
interface OSSOption {
    oss: any;
    name: string;
    file: File;
    config?: any;
    progress?: Function;
}
declare global {
    interface Window {
        OSS: any;
    }
}
export declare const OSS: any;
export declare const UPLOAD_TO_OSS: (option: OSSOption) => Promise<unknown>;
/**
 * 请求方法封装
 */
export declare const AXIOS: import("axios").AxiosInstance;
interface HttpResponse {
    code: number;
    data: any;
    msg: string;
}
interface HttpRequest {
    method: 'get' | 'post';
    url: string;
    data?: any;
    config?: AxiosRequestConfig;
    cancel?: (token: CancelTokenSource) => void;
    success?: (value?: HttpResponse) => {};
    fail?: (value?: HttpResponse) => {};
}
export declare const HEADERS: {
    Authorization: string;
};
export declare const HTTP_REQUEST: (option: HttpRequest) => Promise<any>;
/**
 * cookie操作
 */
export declare const COOKIE: {
    getCookie: (name: string) => string | null;
    setCookie: (name: string, value: string, time: number) => void;
    delCookie: (name: string) => void;
};
/**
 * 获取链接里参数
 * @param {string} 参数名
 */
export declare const GET_QUERY_STRING: (name: string) => string;
/**
 * GET_RANDOM 获取随机数
 * @param {number} 返回随机数长度
 */
export declare const GET_RANDOM: (length?: number) => string;
/**
 * 判断数组或对象是否为空
 * @param option
 */
export declare const IS_EMPTY: (option: any) => boolean;
/**
 * 替换浏览器参数
 */
export declare const REPLACE_PARAML: (key: string, value: string, isDelete?: Boolean | undefined) => void;
interface parseRes {
    fileArr: Array<any>;
    pathArr: Array<any> | string;
    level: number;
    size: number;
}
export declare const PARSE_DIRS_FILES: (e: any) => Promise<parseRes>;
interface downloadDir {
    dirFileStructure: {
        id: number;
        file_name: string;
        file_type: string;
        file_memory: number;
        file_path: string | null;
        path_name: "/新建文件夹(1)22224/";
        file_dir: string;
        level: number;
        isdir: number;
    };
    children: Array<downloadDir>;
}
/**
 * 递归遍历需要压缩的数据结构树
 * @param jszip jszip实例
 * @param arr 需要遍历的数组数据
 * @param oss1 bucket sdzhofficialwebsite
 * @param oss2 bucket imotunkt
 */
export declare const PARSE_DIR_TREE: (jszip: JSZip, arr: downloadDir[], oss1: any, oss2: any) => JSZip;
export declare const FORMAT: (date: Date, fmt: string) => string;
declare type MemoryTypeStr = 'TB' | 'GB' | 'MB' | 'KB' | 'B';
export declare const MEMORY_WITH_UNIT: (memory: number, type: MemoryTypeStr) => string;
export declare const MEMORY_WITHOUT_UNIT: (fileSize: string) => number;
