import CryptoJS from 'crypto-js';
import axios, { AxiosRequestConfig, AxiosResponse, CancelTokenSource } from 'axios';
import qs from 'qs';
import JSZip from 'jszip'
import PreviewFile from './component/previewFile/previewFile';
import PreviewImage from './component/previewImage/previewImage';
import PreviewVideo from './component/previewVideo/previewVideo';
import ChangeSchoolModal from './component/changeSchoolModal/changeSchoolModal';
import CreateSchoolModal from './component/createSchoolModal/createSchoolModal';
export { PreviewFile, PreviewImage, PreviewVideo, ChangeSchoolModal, CreateSchoolModal }
export function decodeText(payload: any) {
  let renderDom = []
  // 文本消息
  let temp = payload.text
  let left = -1
  let right = -1
  while (temp !== '') {
    left = temp.indexOf('[')
    right = temp.indexOf(']')
    switch (left) {
      case 0:
        if (right === -1) {
          renderDom.push({
            name: 'text',
            text: temp
          })
          temp = ''
        } else {
          let _emoji = temp.slice(0, right + 1)
          if (emojiMap[_emoji]) {
            renderDom.push({
              name: 'img',
              src: emojiUrl + emojiMap[_emoji]
            })
            temp = temp.substring(right + 1)
          } else {
            renderDom.push({
              name: 'text',
              text: '['
            })
            temp = temp.slice(1)
          }
        }
        break
      case -1:
        renderDom.push({
          name: 'text',
          text: temp
        })
        temp = ''
        break
      default:
        renderDom.push({
          name: 'text',
          text: temp.slice(0, left)
        })
        temp = temp.substring(left)
        break
    }
  }
  return renderDom
}
export const emojiUrl = 'https://imgcache.qq.com/open/qcloud/tim/assets/emoji/'
export const emojiMap: { [key: string]: string } = {
  '[NO]': 'emoji_0@2x.png',
  '[OK]': 'emoji_1@2x.png',
  '[下雨]': 'emoji_2@2x.png',
  '[么么哒]': 'emoji_3@2x.png',
  '[乒乓]': 'emoji_4@2x.png',
  '[便便]': 'emoji_5@2x.png',
  '[信封]': 'emoji_6@2x.png',
  '[偷笑]': 'emoji_7@2x.png',
  '[傲慢]': 'emoji_8@2x.png',
  '[再见]': 'emoji_9@2x.png',
  '[冷汗]': 'emoji_10@2x.png',
  '[凋谢]': 'emoji_11@2x.png',
  '[刀]': 'emoji_12@2x.png',
  '[删除]': 'emoji_13@2x.png',
  '[勾引]': 'emoji_14@2x.png',
  '[发呆]': 'emoji_15@2x.png',
  '[发抖]': 'emoji_16@2x.png',
  '[可怜]': 'emoji_17@2x.png',
  '[可爱]': 'emoji_18@2x.png',
  '[右哼哼]': 'emoji_19@2x.png',
  '[右太极]': 'emoji_20@2x.png',
  '[右车头]': 'emoji_21@2x.png',
  '[吐]': 'emoji_22@2x.png',
  '[吓]': 'emoji_23@2x.png',
  '[咒骂]': 'emoji_24@2x.png',
  '[咖啡]': 'emoji_25@2x.png',
  '[啤酒]': 'emoji_26@2x.png',
  '[嘘]': 'emoji_27@2x.png',
  '[回头]': 'emoji_28@2x.png',
  '[困]': 'emoji_29@2x.png',
  '[坏笑]': 'emoji_30@2x.png',
  '[多云]': 'emoji_31@2x.png',
  '[大兵]': 'emoji_32@2x.png',
  '[大哭]': 'emoji_33@2x.png',
  '[太阳]': 'emoji_34@2x.png',
  '[奋斗]': 'emoji_35@2x.png',
  '[奶瓶]': 'emoji_36@2x.png',
  '[委屈]': 'emoji_37@2x.png',
  '[害羞]': 'emoji_38@2x.png',
  '[尴尬]': 'emoji_39@2x.png',
  '[左哼哼]': 'emoji_40@2x.png',
  '[左太极]': 'emoji_41@2x.png',
  '[左车头]': 'emoji_42@2x.png',
  '[差劲]': 'emoji_43@2x.png',
  '[弱]': 'emoji_44@2x.png',
  '[强]': 'emoji_45@2x.png',
  '[彩带]': 'emoji_46@2x.png',
  '[彩球]': 'emoji_47@2x.png',
  '[得意]': 'emoji_48@2x.png',
  '[微笑]': 'emoji_49@2x.png',
  '[心碎了]': 'emoji_50@2x.png',
  '[快哭了]': 'emoji_51@2x.png',
  '[怄火]': 'emoji_52@2x.png',
  '[怒]': 'emoji_53@2x.png',
  '[惊恐]': 'emoji_54@2x.png',
  '[惊讶]': 'emoji_55@2x.png',
  '[憨笑]': 'emoji_56@2x.png',
  '[手枪]': 'emoji_57@2x.png',
  '[打哈欠]': 'emoji_58@2x.png',
  '[抓狂]': 'emoji_59@2x.png',
  '[折磨]': 'emoji_60@2x.png',
  '[抠鼻]': 'emoji_61@2x.png',
  '[抱抱]': 'emoji_62@2x.png',
  '[抱拳]': 'emoji_63@2x.png',
  '[拳头]': 'emoji_64@2x.png',
  '[挥手]': 'emoji_65@2x.png',
  '[握手]': 'emoji_66@2x.png',
  '[撇嘴]': 'emoji_67@2x.png',
  '[擦汗]': 'emoji_68@2x.png',
  '[敲打]': 'emoji_69@2x.png',
  '[晕]': 'emoji_70@2x.png',
  '[月亮]': 'emoji_71@2x.png',
  '[棒棒糖]': 'emoji_72@2x.png',
  '[汽车]': 'emoji_73@2x.png',
  '[沙发]': 'emoji_74@2x.png',
  '[流汗]': 'emoji_75@2x.png',
  '[流泪]': 'emoji_76@2x.png',
  '[激动]': 'emoji_77@2x.png',
  '[灯泡]': 'emoji_78@2x.png',
  '[炸弹]': 'emoji_79@2x.png',
  '[熊猫]': 'emoji_80@2x.png',
  '[爆筋]': 'emoji_81@2x.png',
  '[爱你]': 'emoji_82@2x.png',
  '[爱心]': 'emoji_83@2x.png',
  '[爱情]': 'emoji_84@2x.png',
  '[猪头]': 'emoji_85@2x.png',
  '[猫咪]': 'emoji_86@2x.png',
  '[献吻]': 'emoji_87@2x.png',
  '[玫瑰]': 'emoji_88@2x.png',
  '[瓢虫]': 'emoji_89@2x.png',
  '[疑问]': 'emoji_90@2x.png',
  '[白眼]': 'emoji_91@2x.png',
  '[皮球]': 'emoji_92@2x.png',
  '[睡觉]': 'emoji_93@2x.png',
  '[磕头]': 'emoji_94@2x.png',
  '[示爱]': 'emoji_95@2x.png',
  '[礼品袋]': 'emoji_96@2x.png',
  '[礼物]': 'emoji_97@2x.png',
  '[篮球]': 'emoji_98@2x.png',
  '[米饭]': 'emoji_99@2x.png',
  '[糗大了]': 'emoji_100@2x.png',
  '[红双喜]': 'emoji_101@2x.png',
  '[红灯笼]': 'emoji_102@2x.png',
  '[纸巾]': 'emoji_103@2x.png',
  '[胜利]': 'emoji_104@2x.png',
  '[色]': 'emoji_105@2x.png',
  '[药]': 'emoji_106@2x.png',
  '[菜刀]': 'emoji_107@2x.png',
  '[蛋糕]': 'emoji_108@2x.png',
  '[蜡烛]': 'emoji_109@2x.png',
  '[街舞]': 'emoji_110@2x.png',
  '[衰]': 'emoji_111@2x.png',
  '[西瓜]': 'emoji_112@2x.png',
  '[调皮]': 'emoji_113@2x.png',
  '[象棋]': 'emoji_114@2x.png',
  '[跳绳]': 'emoji_115@2x.png',
  '[跳跳]': 'emoji_116@2x.png',
  '[车厢]': 'emoji_117@2x.png',
  '[转圈]': 'emoji_118@2x.png',
  '[鄙视]': 'emoji_119@2x.png',
  '[酷]': 'emoji_120@2x.png',
  '[钞票]': 'emoji_121@2x.png',
  '[钻戒]': 'emoji_122@2x.png',
  '[闪电]': 'emoji_123@2x.png',
  '[闭嘴]': 'emoji_124@2x.png',
  '[闹钟]': 'emoji_125@2x.png',
  '[阴险]': 'emoji_126@2x.png',
  '[难过]': 'emoji_127@2x.png',
  '[雨伞]': 'emoji_128@2x.png',
  '[青蛙]': 'emoji_129@2x.png',
  '[面条]': 'emoji_130@2x.png',
  '[鞭炮]': 'emoji_131@2x.png',
  '[风车]': 'emoji_132@2x.png',
  '[飞吻]': 'emoji_133@2x.png',
  '[飞机]': 'emoji_134@2x.png',
  '[饥饿]': 'emoji_135@2x.png',
  '[香蕉]': 'emoji_136@2x.png',
  '[骷髅]': 'emoji_137@2x.png',
  '[麦克风]': 'emoji_138@2x.png',
  '[麻将]': 'emoji_139@2x.png',
  '[鼓掌]': 'emoji_140@2x.png',
  '[龇牙]': 'emoji_141@2x.png'
}
export const emojiName = [
  '[龇牙]',
  '[调皮]',
  '[流汗]',
  '[偷笑]',
  '[再见]',
  '[敲打]',
  '[擦汗]',
  '[猪头]',
  '[玫瑰]',
  '[流泪]',
  '[大哭]',
  '[嘘]',
  '[酷]',
  '[抓狂]',
  '[委屈]',
  '[便便]',
  '[炸弹]',
  '[菜刀]',
  '[可爱]',
  '[色]',
  '[害羞]',
  '[得意]',
  '[吐]',
  '[微笑]',
  '[怒]',
  '[尴尬]',
  '[惊恐]',
  '[冷汗]',
  '[爱心]',
  '[示爱]',
  '[白眼]',
  '[傲慢]',
  '[难过]',
  '[惊讶]',
  '[疑问]',
  '[困]',
  '[么么哒]',
  '[憨笑]',
  '[爱情]',
  '[衰]',
  '[撇嘴]',
  '[阴险]',
  '[奋斗]',
  '[发呆]',
  '[右哼哼]',
  '[抱抱]',
  '[坏笑]',
  '[飞吻]',
  '[鄙视]',
  '[晕]',
  '[大兵]',
  '[可怜]',
  '[强]',
  '[弱]',
  '[握手]',
  '[胜利]',
  '[抱拳]',
  '[凋谢]',
  '[米饭]',
  '[蛋糕]',
  '[西瓜]',
  '[啤酒]',
  '[瓢虫]',
  '[勾引]',
  '[OK]',
  '[爱你]',
  '[咖啡]',
  '[月亮]',
  '[刀]',
  '[发抖]',
  '[差劲]',
  '[拳头]',
  '[心碎了]',
  '[太阳]',
  '[礼物]',
  '[皮球]',
  '[骷髅]',
  '[挥手]',
  '[闪电]',
  '[饥饿]',
  '[咒骂]',
  '[折磨]',
  '[抠鼻]',
  '[鼓掌]',
  '[糗大了]',
  '[左哼哼]',
  '[打哈欠]',
  '[快哭了]',
  '[吓]',
  '[篮球]',
  '[乒乓]',
  '[NO]',
  '[跳跳]',
  '[怄火]',
  '[转圈]',
  '[磕头]',
  '[回头]',
  '[跳绳]',
  '[激动]',
  '[街舞]',
  '[献吻]',
  '[左太极]',
  '[右太极]',
  '[闭嘴]',
  '[猫咪]',
  '[红双喜]',
  '[鞭炮]',
  '[红灯笼]',
  '[麻将]',
  '[麦克风]',
  '[礼品袋]',
  '[信封]',
  '[象棋]',
  '[彩带]',
  '[蜡烛]',
  '[爆筋]',
  '[棒棒糖]',
  '[奶瓶]',
  '[面条]',
  '[香蕉]',
  '[飞机]',
  '[左车头]',
  '[车厢]',
  '[右车头]',
  '[多云]',
  '[下雨]',
  '[钞票]',
  '[熊猫]',
  '[灯泡]',
  '[风车]',
  '[闹钟]',
  '[雨伞]',
  '[彩球]',
  '[钻戒]',
  '[沙发]',
  '[纸巾]',
  '[手枪]',
  '[青蛙]'
]

export const CHANGE_TITLE_ICON = (name: string, icon: string) => {
  document.title = name;
  let link: HTMLLinkElement = document.querySelector("link[rel*='icon']") || document.createElement('link');
  link['type'] = 'image/x-icon';
  link['rel'] = 'shortcut icon';
  link['href'] = icon;
  document.getElementsByTagName('head')[0].appendChild(link);
}

export const VALIDATE_TEXT_LENGTH = (v: string): number => {
  //中文、中文标点、全角字符按1长度，英文、英文符号、数字按0.5长度计算
  let r = /([\u4e00-\u9fa5]|[\u3000-\u303F]|[\uFF00-\uFF60])/g;
  let m = v.match(r);
  let l = 0;
  if (m) {
    return (l = m.length + (v.length - m.length) * 0.5);
  } else {
    return (l = v.length * 0.5);
  }
}

export const DES = (option: { key: string, message: string, type?: 'encrypt' | 'decrypt' | undefined }) => {
  if (!option.type || (option.type && option.type === 'encrypt')) {
    //加密
    return CryptoJS.DES.encrypt(option.message, CryptoJS.enc.Utf8.parse(option.key), {
      mode: CryptoJS.mode.ECB,
      padding: CryptoJS.pad.Pkcs7
    }).toString();
  } else {
    return CryptoJS.DES.decrypt(option.message, CryptoJS.enc.Utf8.parse(option.key), {
      mode: CryptoJS.mode.ECB,
      padding: CryptoJS.pad.Pkcs7
    }).toString(CryptoJS.enc.Utf8)
  }
}


/**
 * 返回章节索引的大写
 * @param length  章节数组长度
 */
const uppercaseNumber = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '百'];
export const RETURN_CHAPTER_INDEX = (length: number) => {
  length++
  let a = '';
  if (length < 10) {
    a = uppercaseNumber[length]
  } else if (length < 100) {
    a = uppercaseNumber[+length.toString()[0]] + uppercaseNumber[10] + (uppercaseNumber[+length.toString()[1]] === '零' ? '' : uppercaseNumber[+length.toString()[1]])
  }
  return a
}

/**
 * 转换存储空间大小单位
 * @param memory 为单位
 * @param type 单位
 */
const CHANGE_MEMORY = (memory: any, type: string): any => {
  type = type.toUpperCase();
  let data = Number(memory);
  const unit: string[] = ['TB', 'GB', 'MB', 'KB', 'B'];
  const index = unit.indexOf(type);
  if (!index || index === 4) {
    return data.toFixed(2) + type
  } else {
    if (data < 1024) return data.toFixed(2) + type;
    else return CHANGE_MEMORY(data / 1024, unit[index - 1])
  }
}




/**
 * 阿里云存储
 */
interface OSSOption {
  oss: any;
  name: string;
  file: File;
  config?: any;
  progress?: Function;
}
declare global {
  interface Window {
    OSS: any;
  }
}
export const OSS: any = (option: {
  region: string,
  accessKeyId: string,
  accessKeySecret: string,
  bucket: string
}) => {
  if (window.OSS) {
    return new window['OSS'](option)
  } else {
    return new (require('ali-oss'))(option)
  }
}

export const UPLOAD_TO_OSS = (option: OSSOption) => {
  return new Promise((resolve, reject) => {
    option.oss.multipartUpload(option.name, option.file, option.config || {
      parallel: 2,
      partSize: 1024 * 1024 * 5,
      progress: (percent: number) => {
        typeof option.progress === 'function' && option.progress(percent)
      },
      headers: {
        'Content-Disposition': 'attachment; filename=' + encodeURI(option.file.name)
      }
    }).then((res: any) => {
      resolve(res.res.requestUrls[0].replace(/\?upload\S+/, ''))
    }).catch((err: any) => {
      reject(err)
    })
  })
}

/**
 * 请求方法封装
 */
export const AXIOS = axios.create({
  baseURL: window.location.origin,
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
  }
})

interface HttpResponse { code: number, data: any, msg: string }
interface HttpRequest {
  method: 'get' | 'post',
  url: string,
  data?: any,
  config?: AxiosRequestConfig,
  cancel?: (token: CancelTokenSource) => void,
  success?: (value?: HttpResponse) => {}
  fail?: (value?: HttpResponse) => {}
}
export const HEADERS = {
  Authorization: ''
}
export const HTTP_REQUEST = (option: HttpRequest) => {
  const cancelToken = axios.CancelToken.source();
  if (option.cancel) {
    option.cancel(cancelToken)
  }
  if (option.method === 'get') {
    if (option.data instanceof Object) {
      option.url += '?' + qs.stringify(option.data);
    }
    return new Promise((resolve: (value?: any) => void, reject: (value?: any) => void): void => {
      AXIOS.get(option.url, { ...option.config, headers: { Authorization: HEADERS.Authorization, ...(option.config || {}).headers }, cancelToken: cancelToken.token })
        .then((res: AxiosResponse<HttpResponse>) => {
          let data = res.data;
          option.success && option.success(data)
          resolve(data);
        }, (err: any) => {
          option.fail && option.fail(err)
          reject(err)
        });
    })
  } else {
    let data = option.data instanceof Object ? qs.stringify(option.data) : option.data;
    return new Promise((resolve: (value?: any) => void, reject: (value?: any) => void): void => {
      AXIOS.post(option.url, data, { ...option.config, headers: { Authorization: HEADERS.Authorization, ...(option.config || {}).headers }, cancelToken: cancelToken.token })
        .then((res: AxiosResponse<HttpResponse>) => {
          let data = res.data;
          option.success && option.success(data)
          resolve(data);
        }, (err: any) => {
          option.fail && option.fail(err)
          reject(err);
        })
    })
  }
}

/**
 * cookie操作
 */
export const COOKIE = {
  getCookie: function (name: string) {
    const arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"))
    if (arr) {
      return unescape(arr[2]);
    }
    else { return null; }
  },
  setCookie: function (name: string, value: string, time: number) {
    var exp = new Date();
    COOKIE.delCookie('t')
    exp.setTime(exp.getTime() + time * 24 * 60 * 60 * 1000);
    let domainArr = window.location.hostname.match(/(\.[a-z]*){2}$/gi) || ''
    document.cookie = name + "=" + escape(value) + ";path=/;expires=" + exp.toUTCString() + ';domain=' + (domainArr ? domainArr[0] : '.imotun.com')
  },
  delCookie: function (name: string) {
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval = COOKIE.getCookie(name);
    if (cval != null) {
      let domainArr = window.location.hostname.match(/(\.[a-z]*){2}$/gi) || ''
      document.cookie = name + "=" + cval + ";path=/;expires=" + exp.toUTCString() + ';domain=' + (domainArr ? domainArr[0] : '.imotun.com');
    }
  }
}

/**
 * 获取链接里参数
 * @param {string} 参数名
 */
export const GET_QUERY_STRING = (name: string) => {
  const reg = new RegExp('(^|&)' + name + '=([^&]*|$)', 'i');
  const r = window.location.search.substr(1).match(reg);
  if (r != null) {
    return unescape(r[2]);
  }
  return '';
}

/**
 * GET_RANDOM 获取随机数
 * @param {number} 返回随机数长度
 */
export const GET_RANDOM = (length = 10) => {
  let s = ''
  const b = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
  for (let i = 0; i < length; i++) {
    s += b[Math.floor(Math.random() * b.length)]
  }
  return s
}

/**
 * 判断数组或对象是否为空
 * @param option 
 */
export const IS_EMPTY = (option: any) => {
  switch (Object.prototype.toString.call(option).slice(8, -1)) {
    case 'Array':
      if (option.length > 0) {
        return false;
      } else {
        return true;
      }
    case 'Object':
      if (Object.keys(option).length > 0) {
        return false;
      } else {
        return true;
      }
    default: return true
  }
}

/**
 * 替换浏览器参数
 */
export const REPLACE_PARAML = (key: string, value: string, isDelete?: Boolean) => {
  let re = new RegExp('(^|&)' + key + '=([^&]*|$)', 'gi'); // /(\?|&)lessonid=([^&]*|$)/i
  let reg = new RegExp('\\?&|&&|([?&]$)')
  let search = window.location.search.substring(1);
  let newVal = isDelete ? '' : '&' + key + '=' + escape(value)
  if (search && re.test(search)) {
    // url存在并且含有key
    search = search.replace(re, newVal)
  } else {
    search += newVal
  }
  let nUrl = window.location.href.split('?')[0] + '?' + search;
  nUrl = nUrl.replace(reg, function () {
    if (arguments) {
      switch (arguments[0]) {
        case '&':
        case '?':
          return ''
        case '&&':
          return '&'
        case '?&':
          return '?'
        default:
          return ''
      }
    }
    return ''
  })
  window.history.replaceState(null, "", nUrl)
}

interface parseRes {
  fileArr: Array<any>,
  pathArr: Array<any> | string,
  level: number,
  size: number
}
export const PARSE_DIRS_FILES = (e: any): Promise<parseRes> => {
  return new Promise((resolve, reject) => {
    // 判断拖拽进来是否有内容
    const files = e.files;
    if (files.length === 0) {
      return;
    }
    const items = e.items;
    let path = GET_QUERY_STRING('path') || '/';
    let level = 0;
    let size = 0;
    let fileArr: any = [];
    let pathArr = new Set();
    let DirAndFileCount = 0;
    let DirCount = 0;
    let parseDirs = (dirEntry: any, parentPath: any) => {
      if (parentPath = parentPath || '', dirEntry.isFile) {
        dirEntry.file((res: any) => {
          res.directoryPath = parentPath;
          fileArr.push(res);
          size += res.size
          if (DirAndFileCount - DirCount + 1 === fileArr.length) {
            level += path.split('/').length - 1;
            resolve({ fileArr, pathArr: Array.from(pathArr), level, size });
          }
        })
      } else if (dirEntry.isDirectory) {
        const dirReader = dirEntry.createReader();
        dirReader.readEntries((res: any) => {
          DirAndFileCount += res.length;
          DirCount++;
          res.map((item: any) => {
            if (item.isDirectory) {
              pathArr.add(item.fullPath + '/');
              level = Math.max(level, item.fullPath.split('/').length - 1)
            }
            parseDirs(item, parentPath + dirEntry.name + '/')
          })
        })
      }
    };
    for (let i = 0; i < files.length; i++) {
      if (items && items[i]) {
        let dirEntry = items[i].webkitGetAsEntry();
        if (!dirEntry.isFile && dirEntry.isDirectory) {
          level = 1;
          pathArr.add(dirEntry.fullPath + '/')
          parseDirs(dirEntry, path);
        } else if (dirEntry.isFile) {
          dirEntry.file((res: any) => {
            res.directoryPath = path;
            fileArr.push(res);
            size = res.size
            if (files.length === fileArr.length) {
              level = path.split('/').length - 1
              resolve({ fileArr, pathArr: '', level, size });
            }
          })
        }
      }
    }
  })
}
interface downloadDir {
  dirFileStructure: {
    id: number
    file_name: string, // "新建文件夹(1)22224"
    file_type: string, // "dir"
    file_memory: number, //0
    file_path: string | null //""
    path_name: "/新建文件夹(1)22224/"
    file_dir: string;
    level: number;
    isdir: number;
  },
  children: Array<downloadDir>
}

/**
 * 递归遍历需要压缩的数据结构树
 * @param jszip jszip实例
 * @param arr 需要遍历的数组数据
 * @param oss1 bucket sdzhofficialwebsite
 * @param oss2 bucket imotunkt
 */
export const PARSE_DIR_TREE = (jszip: JSZip, arr: Array<downloadDir>, oss1: any, oss2: any) => {
  if (arr instanceof Array) {
    const MAP_TREE = (arr: Array<any>) => {
      arr.map(item => {
        let info = item.dirFileStructure;
        if (info.isdir) {
          jszip.folder(info.file_dir.replace(/^\/|\/$/g, ''))
        } else {
          let path = info.file_path.replace(/^http.*oss-cn-shenzhen.aliyuncs.com\//, '').replace(/^\//, '');
          jszip.file(info.path_name ? info.path_name.substr(1) : info.file_name, HTTP_REQUEST({
            method: 'get',
            url: /sdzhofficialwebsite/.test(info.file_path) ? oss1.signatureUrl(decodeURI(path)) : oss2.signatureUrl(decodeURI(path)),
            config: {
              responseType: 'arraybuffer'
            }
          }), { binary: true })
        }
        item.children.length && MAP_TREE(item.children)
      })
    }

    MAP_TREE(arr);
  }
  return jszip
}

export const FORMAT = (date: Date, fmt: string) => {
  // date 为 Date对象， fmt 为 YMd HH:mm:ss格式
  date = date || new Date();
  fmt = fmt || 'YYYY-MM-dd HH:mm:ss';
  const o: {
    [key: string]: any
  } = {
    "M+": date.getMonth() + 1, //月份 
    "d+": date.getDate(), //日 
    "H+": date.getHours(), //小时 
    "m+": date.getMinutes(), //分 
    "s+": date.getSeconds(), //秒 
    "q+": Math.floor((date.getMonth() + 3) / 3), //季度 
    "S": date.getMilliseconds(), //毫秒 
    "w": ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][date.getDay()], // 星期中的第几，
  };
  if (/(Y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
  }
  for (let k in o) {
    if (new RegExp("(" + k + ")").test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
    }
  }
  return fmt;
}

type MemoryTypeStr = 'TB' | 'GB' | 'MB' | 'KB' | 'B'
export const MEMORY_WITH_UNIT = (memory: number, type: MemoryTypeStr): string => {
  let data = Number(memory);
  const unit: Array<MemoryTypeStr> = ['TB', 'GB', 'MB', 'KB', 'B'];
  const index = unit.indexOf(type);
  if (!index) {
    return data.toFixed(2) + type
  } else {
    if (data < 1024) return data.toFixed(2) + type;
    else return MEMORY_WITH_UNIT(data / 1024, unit[index - 1])
  }
}

export const MEMORY_WITHOUT_UNIT = (fileSize: string): number => {
  // if (/kb/i.test(fileSize)) {

  // } else 
  if (/mb/i.test(fileSize)) {
    return parseFloat(fileSize) * 1024;
  } else if (/gb/i.test(fileSize)) {
    return parseFloat(fileSize) * 1024 * 1024;
  }
  return parseFloat(fileSize);
};

