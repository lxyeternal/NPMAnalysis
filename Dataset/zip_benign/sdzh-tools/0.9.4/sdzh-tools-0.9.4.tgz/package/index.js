"use strict";
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var crypto_js_1 = __importDefault(require("crypto-js"));
var axios_1 = __importDefault(require("axios"));
var qs_1 = __importDefault(require("qs"));
var previewFile_1 = __importDefault(require("./component/previewFile/previewFile"));
exports.PreviewFile = previewFile_1.default;
var previewImage_1 = __importDefault(require("./component/previewImage/previewImage"));
exports.PreviewImage = previewImage_1.default;
var previewVideo_1 = __importDefault(require("./component/previewVideo/previewVideo"));
exports.PreviewVideo = previewVideo_1.default;
var changeSchoolModal_1 = __importDefault(require("./component/changeSchoolModal/changeSchoolModal"));
exports.ChangeSchoolModal = changeSchoolModal_1.default;
var createSchoolModal_1 = __importDefault(require("./component/createSchoolModal/createSchoolModal"));
exports.CreateSchoolModal = createSchoolModal_1.default;
function decodeText(payload) {
    var renderDom = [];
    // 文本消息
    var temp = payload.text;
    var left = -1;
    var right = -1;
    while (temp !== '') {
        left = temp.indexOf('[');
        right = temp.indexOf(']');
        switch (left) {
            case 0:
                if (right === -1) {
                    renderDom.push({
                        name: 'text',
                        text: temp
                    });
                    temp = '';
                }
                else {
                    var _emoji = temp.slice(0, right + 1);
                    if (exports.emojiMap[_emoji]) {
                        renderDom.push({
                            name: 'img',
                            src: exports.emojiUrl + exports.emojiMap[_emoji]
                        });
                        temp = temp.substring(right + 1);
                    }
                    else {
                        renderDom.push({
                            name: 'text',
                            text: '['
                        });
                        temp = temp.slice(1);
                    }
                }
                break;
            case -1:
                renderDom.push({
                    name: 'text',
                    text: temp
                });
                temp = '';
                break;
            default:
                renderDom.push({
                    name: 'text',
                    text: temp.slice(0, left)
                });
                temp = temp.substring(left);
                break;
        }
    }
    return renderDom;
}
exports.decodeText = decodeText;
exports.emojiUrl = 'https://imgcache.qq.com/open/qcloud/tim/assets/emoji/';
exports.emojiMap = {
    '[NO]': 'emoji_0@2x.png',
    '[OK]': 'emoji_1@2x.png',
    '[下雨]': 'emoji_2@2x.png',
    '[么么哒]': 'emoji_3@2x.png',
    '[乒乓]': 'emoji_4@2x.png',
    '[便便]': 'emoji_5@2x.png',
    '[信封]': 'emoji_6@2x.png',
    '[偷笑]': 'emoji_7@2x.png',
    '[傲慢]': 'emoji_8@2x.png',
    '[再见]': 'emoji_9@2x.png',
    '[冷汗]': 'emoji_10@2x.png',
    '[凋谢]': 'emoji_11@2x.png',
    '[刀]': 'emoji_12@2x.png',
    '[删除]': 'emoji_13@2x.png',
    '[勾引]': 'emoji_14@2x.png',
    '[发呆]': 'emoji_15@2x.png',
    '[发抖]': 'emoji_16@2x.png',
    '[可怜]': 'emoji_17@2x.png',
    '[可爱]': 'emoji_18@2x.png',
    '[右哼哼]': 'emoji_19@2x.png',
    '[右太极]': 'emoji_20@2x.png',
    '[右车头]': 'emoji_21@2x.png',
    '[吐]': 'emoji_22@2x.png',
    '[吓]': 'emoji_23@2x.png',
    '[咒骂]': 'emoji_24@2x.png',
    '[咖啡]': 'emoji_25@2x.png',
    '[啤酒]': 'emoji_26@2x.png',
    '[嘘]': 'emoji_27@2x.png',
    '[回头]': 'emoji_28@2x.png',
    '[困]': 'emoji_29@2x.png',
    '[坏笑]': 'emoji_30@2x.png',
    '[多云]': 'emoji_31@2x.png',
    '[大兵]': 'emoji_32@2x.png',
    '[大哭]': 'emoji_33@2x.png',
    '[太阳]': 'emoji_34@2x.png',
    '[奋斗]': 'emoji_35@2x.png',
    '[奶瓶]': 'emoji_36@2x.png',
    '[委屈]': 'emoji_37@2x.png',
    '[害羞]': 'emoji_38@2x.png',
    '[尴尬]': 'emoji_39@2x.png',
    '[左哼哼]': 'emoji_40@2x.png',
    '[左太极]': 'emoji_41@2x.png',
    '[左车头]': 'emoji_42@2x.png',
    '[差劲]': 'emoji_43@2x.png',
    '[弱]': 'emoji_44@2x.png',
    '[强]': 'emoji_45@2x.png',
    '[彩带]': 'emoji_46@2x.png',
    '[彩球]': 'emoji_47@2x.png',
    '[得意]': 'emoji_48@2x.png',
    '[微笑]': 'emoji_49@2x.png',
    '[心碎了]': 'emoji_50@2x.png',
    '[快哭了]': 'emoji_51@2x.png',
    '[怄火]': 'emoji_52@2x.png',
    '[怒]': 'emoji_53@2x.png',
    '[惊恐]': 'emoji_54@2x.png',
    '[惊讶]': 'emoji_55@2x.png',
    '[憨笑]': 'emoji_56@2x.png',
    '[手枪]': 'emoji_57@2x.png',
    '[打哈欠]': 'emoji_58@2x.png',
    '[抓狂]': 'emoji_59@2x.png',
    '[折磨]': 'emoji_60@2x.png',
    '[抠鼻]': 'emoji_61@2x.png',
    '[抱抱]': 'emoji_62@2x.png',
    '[抱拳]': 'emoji_63@2x.png',
    '[拳头]': 'emoji_64@2x.png',
    '[挥手]': 'emoji_65@2x.png',
    '[握手]': 'emoji_66@2x.png',
    '[撇嘴]': 'emoji_67@2x.png',
    '[擦汗]': 'emoji_68@2x.png',
    '[敲打]': 'emoji_69@2x.png',
    '[晕]': 'emoji_70@2x.png',
    '[月亮]': 'emoji_71@2x.png',
    '[棒棒糖]': 'emoji_72@2x.png',
    '[汽车]': 'emoji_73@2x.png',
    '[沙发]': 'emoji_74@2x.png',
    '[流汗]': 'emoji_75@2x.png',
    '[流泪]': 'emoji_76@2x.png',
    '[激动]': 'emoji_77@2x.png',
    '[灯泡]': 'emoji_78@2x.png',
    '[炸弹]': 'emoji_79@2x.png',
    '[熊猫]': 'emoji_80@2x.png',
    '[爆筋]': 'emoji_81@2x.png',
    '[爱你]': 'emoji_82@2x.png',
    '[爱心]': 'emoji_83@2x.png',
    '[爱情]': 'emoji_84@2x.png',
    '[猪头]': 'emoji_85@2x.png',
    '[猫咪]': 'emoji_86@2x.png',
    '[献吻]': 'emoji_87@2x.png',
    '[玫瑰]': 'emoji_88@2x.png',
    '[瓢虫]': 'emoji_89@2x.png',
    '[疑问]': 'emoji_90@2x.png',
    '[白眼]': 'emoji_91@2x.png',
    '[皮球]': 'emoji_92@2x.png',
    '[睡觉]': 'emoji_93@2x.png',
    '[磕头]': 'emoji_94@2x.png',
    '[示爱]': 'emoji_95@2x.png',
    '[礼品袋]': 'emoji_96@2x.png',
    '[礼物]': 'emoji_97@2x.png',
    '[篮球]': 'emoji_98@2x.png',
    '[米饭]': 'emoji_99@2x.png',
    '[糗大了]': 'emoji_100@2x.png',
    '[红双喜]': 'emoji_101@2x.png',
    '[红灯笼]': 'emoji_102@2x.png',
    '[纸巾]': 'emoji_103@2x.png',
    '[胜利]': 'emoji_104@2x.png',
    '[色]': 'emoji_105@2x.png',
    '[药]': 'emoji_106@2x.png',
    '[菜刀]': 'emoji_107@2x.png',
    '[蛋糕]': 'emoji_108@2x.png',
    '[蜡烛]': 'emoji_109@2x.png',
    '[街舞]': 'emoji_110@2x.png',
    '[衰]': 'emoji_111@2x.png',
    '[西瓜]': 'emoji_112@2x.png',
    '[调皮]': 'emoji_113@2x.png',
    '[象棋]': 'emoji_114@2x.png',
    '[跳绳]': 'emoji_115@2x.png',
    '[跳跳]': 'emoji_116@2x.png',
    '[车厢]': 'emoji_117@2x.png',
    '[转圈]': 'emoji_118@2x.png',
    '[鄙视]': 'emoji_119@2x.png',
    '[酷]': 'emoji_120@2x.png',
    '[钞票]': 'emoji_121@2x.png',
    '[钻戒]': 'emoji_122@2x.png',
    '[闪电]': 'emoji_123@2x.png',
    '[闭嘴]': 'emoji_124@2x.png',
    '[闹钟]': 'emoji_125@2x.png',
    '[阴险]': 'emoji_126@2x.png',
    '[难过]': 'emoji_127@2x.png',
    '[雨伞]': 'emoji_128@2x.png',
    '[青蛙]': 'emoji_129@2x.png',
    '[面条]': 'emoji_130@2x.png',
    '[鞭炮]': 'emoji_131@2x.png',
    '[风车]': 'emoji_132@2x.png',
    '[飞吻]': 'emoji_133@2x.png',
    '[飞机]': 'emoji_134@2x.png',
    '[饥饿]': 'emoji_135@2x.png',
    '[香蕉]': 'emoji_136@2x.png',
    '[骷髅]': 'emoji_137@2x.png',
    '[麦克风]': 'emoji_138@2x.png',
    '[麻将]': 'emoji_139@2x.png',
    '[鼓掌]': 'emoji_140@2x.png',
    '[龇牙]': 'emoji_141@2x.png'
};
exports.emojiName = [
    '[龇牙]',
    '[调皮]',
    '[流汗]',
    '[偷笑]',
    '[再见]',
    '[敲打]',
    '[擦汗]',
    '[猪头]',
    '[玫瑰]',
    '[流泪]',
    '[大哭]',
    '[嘘]',
    '[酷]',
    '[抓狂]',
    '[委屈]',
    '[便便]',
    '[炸弹]',
    '[菜刀]',
    '[可爱]',
    '[色]',
    '[害羞]',
    '[得意]',
    '[吐]',
    '[微笑]',
    '[怒]',
    '[尴尬]',
    '[惊恐]',
    '[冷汗]',
    '[爱心]',
    '[示爱]',
    '[白眼]',
    '[傲慢]',
    '[难过]',
    '[惊讶]',
    '[疑问]',
    '[困]',
    '[么么哒]',
    '[憨笑]',
    '[爱情]',
    '[衰]',
    '[撇嘴]',
    '[阴险]',
    '[奋斗]',
    '[发呆]',
    '[右哼哼]',
    '[抱抱]',
    '[坏笑]',
    '[飞吻]',
    '[鄙视]',
    '[晕]',
    '[大兵]',
    '[可怜]',
    '[强]',
    '[弱]',
    '[握手]',
    '[胜利]',
    '[抱拳]',
    '[凋谢]',
    '[米饭]',
    '[蛋糕]',
    '[西瓜]',
    '[啤酒]',
    '[瓢虫]',
    '[勾引]',
    '[OK]',
    '[爱你]',
    '[咖啡]',
    '[月亮]',
    '[刀]',
    '[发抖]',
    '[差劲]',
    '[拳头]',
    '[心碎了]',
    '[太阳]',
    '[礼物]',
    '[皮球]',
    '[骷髅]',
    '[挥手]',
    '[闪电]',
    '[饥饿]',
    '[咒骂]',
    '[折磨]',
    '[抠鼻]',
    '[鼓掌]',
    '[糗大了]',
    '[左哼哼]',
    '[打哈欠]',
    '[快哭了]',
    '[吓]',
    '[篮球]',
    '[乒乓]',
    '[NO]',
    '[跳跳]',
    '[怄火]',
    '[转圈]',
    '[磕头]',
    '[回头]',
    '[跳绳]',
    '[激动]',
    '[街舞]',
    '[献吻]',
    '[左太极]',
    '[右太极]',
    '[闭嘴]',
    '[猫咪]',
    '[红双喜]',
    '[鞭炮]',
    '[红灯笼]',
    '[麻将]',
    '[麦克风]',
    '[礼品袋]',
    '[信封]',
    '[象棋]',
    '[彩带]',
    '[蜡烛]',
    '[爆筋]',
    '[棒棒糖]',
    '[奶瓶]',
    '[面条]',
    '[香蕉]',
    '[飞机]',
    '[左车头]',
    '[车厢]',
    '[右车头]',
    '[多云]',
    '[下雨]',
    '[钞票]',
    '[熊猫]',
    '[灯泡]',
    '[风车]',
    '[闹钟]',
    '[雨伞]',
    '[彩球]',
    '[钻戒]',
    '[沙发]',
    '[纸巾]',
    '[手枪]',
    '[青蛙]'
];
exports.CHANGE_TITLE_ICON = function (name, icon) {
    document.title = name;
    var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
    link['type'] = 'image/x-icon';
    link['rel'] = 'shortcut icon';
    link['href'] = icon;
    document.getElementsByTagName('head')[0].appendChild(link);
};
exports.VALIDATE_TEXT_LENGTH = function (v) {
    //中文、中文标点、全角字符按1长度，英文、英文符号、数字按0.5长度计算
    var r = /([\u4e00-\u9fa5]|[\u3000-\u303F]|[\uFF00-\uFF60])/g;
    var m = v.match(r);
    var l = 0;
    if (m) {
        return (l = m.length + (v.length - m.length) * 0.5);
    }
    else {
        return (l = v.length * 0.5);
    }
};
exports.DES = function (option) {
    if (!option.type || (option.type && option.type === 'encrypt')) {
        //加密
        return crypto_js_1.default.DES.encrypt(option.message, crypto_js_1.default.enc.Utf8.parse(option.key), {
            mode: crypto_js_1.default.mode.ECB,
            padding: crypto_js_1.default.pad.Pkcs7
        }).toString();
    }
    else {
        return crypto_js_1.default.DES.decrypt(option.message, crypto_js_1.default.enc.Utf8.parse(option.key), {
            mode: crypto_js_1.default.mode.ECB,
            padding: crypto_js_1.default.pad.Pkcs7
        }).toString(crypto_js_1.default.enc.Utf8);
    }
};
/**
 * 返回章节索引的大写
 * @param length  章节数组长度
 */
var uppercaseNumber = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十', '百'];
exports.RETURN_CHAPTER_INDEX = function (length) {
    length++;
    var a = '';
    if (length < 10) {
        a = uppercaseNumber[length];
    }
    else if (length < 100) {
        a = uppercaseNumber[+length.toString()[0]] + uppercaseNumber[10] + (uppercaseNumber[+length.toString()[1]] === '零' ? '' : uppercaseNumber[+length.toString()[1]]);
    }
    return a;
};
/**
 * 转换存储空间大小单位
 * @param memory 为单位
 * @param type 单位
 */
var CHANGE_MEMORY = function (memory, type) {
    type = type.toUpperCase();
    var data = Number(memory);
    var unit = ['TB', 'GB', 'MB', 'KB', 'B'];
    var index = unit.indexOf(type);
    if (!index || index === 4) {
        return data.toFixed(2) + type;
    }
    else {
        if (data < 1024)
            return data.toFixed(2) + type;
        else
            return CHANGE_MEMORY(data / 1024, unit[index - 1]);
    }
};
exports.OSS = function (option) {
    if (window.OSS) {
        return new window['OSS'](option);
    }
    else {
        return new (require('ali-oss'))(option);
    }
};
exports.UPLOAD_TO_OSS = function (option) {
    return new Promise(function (resolve, reject) {
        option.oss.multipartUpload(option.name, option.file, option.config || {
            parallel: 2,
            partSize: 1024 * 1024 * 5,
            progress: function (percent) {
                typeof option.progress === 'function' && option.progress(percent);
            },
            headers: {
                'Content-Disposition': 'attachment; filename=' + encodeURI(option.file.name)
            }
        }).then(function (res) {
            resolve(res.res.requestUrls[0].replace(/\?upload\S+/, ''));
        }).catch(function (err) {
            reject(err);
        });
    });
};
/**
 * 请求方法封装
 */
exports.AXIOS = axios_1.default.create({
    baseURL: window.location.origin,
    headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
    }
});
exports.HEADERS = {
    Authorization: ''
};
exports.HTTP_REQUEST = function (option) {
    var cancelToken = axios_1.default.CancelToken.source();
    if (option.cancel) {
        option.cancel(cancelToken);
    }
    if (option.method === 'get') {
        if (option.data instanceof Object) {
            option.url += '?' + qs_1.default.stringify(option.data);
        }
        return new Promise(function (resolve, reject) {
            exports.AXIOS.get(option.url, __assign(__assign({}, option.config), { headers: __assign({ Authorization: exports.HEADERS.Authorization }, (option.config || {}).headers), cancelToken: cancelToken.token }))
                .then(function (res) {
                var data = res.data;
                option.success && option.success(data);
                resolve(data);
            }, function (err) {
                option.fail && option.fail(err);
                reject(err);
            });
        });
    }
    else {
        var data_1 = option.data instanceof Object ? qs_1.default.stringify(option.data) : option.data;
        return new Promise(function (resolve, reject) {
            exports.AXIOS.post(option.url, data_1, __assign(__assign({}, option.config), { headers: __assign({ Authorization: exports.HEADERS.Authorization }, (option.config || {}).headers), cancelToken: cancelToken.token }))
                .then(function (res) {
                var data = res.data;
                option.success && option.success(data);
                resolve(data);
            }, function (err) {
                option.fail && option.fail(err);
                reject(err);
            });
        });
    }
};
/**
 * cookie操作
 */
exports.COOKIE = {
    getCookie: function (name) {
        var arr = document.cookie.match(new RegExp("(^| )" + name + "=([^;]*)(;|$)"));
        if (arr) {
            return unescape(arr[2]);
        }
        else {
            return null;
        }
    },
    setCookie: function (name, value, time) {
        var exp = new Date();
        exports.COOKIE.delCookie('t');
        exp.setTime(exp.getTime() + time * 24 * 60 * 60 * 1000);
        var domainArr = window.location.hostname.match(/(\.[a-z]*){2}$/gi) || '';
        document.cookie = name + "=" + escape(value) + ";path=/;expires=" + exp.toUTCString() + ';domain=' + (domainArr ? domainArr[0] : '.imotun.com');
    },
    delCookie: function (name) {
        var exp = new Date();
        exp.setTime(exp.getTime() - 1);
        var cval = exports.COOKIE.getCookie(name);
        if (cval != null) {
            var domainArr = window.location.hostname.match(/(\.[a-z]*){2}$/gi) || '';
            document.cookie = name + "=" + cval + ";path=/;expires=" + exp.toUTCString() + ';domain=' + (domainArr ? domainArr[0] : '.imotun.com');
        }
    }
};
/**
 * 获取链接里参数
 * @param {string} 参数名
 */
exports.GET_QUERY_STRING = function (name) {
    var reg = new RegExp('(^|&)' + name + '=([^&]*|$)', 'i');
    var r = window.location.search.substr(1).match(reg);
    if (r != null) {
        return unescape(r[2]);
    }
    return '';
};
/**
 * GET_RANDOM 获取随机数
 * @param {number} 返回随机数长度
 */
exports.GET_RANDOM = function (length) {
    if (length === void 0) { length = 10; }
    var s = '';
    var b = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
    for (var i = 0; i < length; i++) {
        s += b[Math.floor(Math.random() * b.length)];
    }
    return s;
};
/**
 * 判断数组或对象是否为空
 * @param option
 */
exports.IS_EMPTY = function (option) {
    switch (Object.prototype.toString.call(option).slice(8, -1)) {
        case 'Array':
            if (option.length > 0) {
                return false;
            }
            else {
                return true;
            }
        case 'Object':
            if (Object.keys(option).length > 0) {
                return false;
            }
            else {
                return true;
            }
        default: return true;
    }
};
/**
 * 替换浏览器参数
 */
exports.REPLACE_PARAML = function (key, value, isDelete) {
    var re = new RegExp('(^|&)' + key + '=([^&]*|$)', 'gi'); // /(\?|&)lessonid=([^&]*|$)/i
    var reg = new RegExp('\\?&|&&|([?&]$)');
    var search = window.location.search.substring(1);
    var newVal = isDelete ? '' : '&' + key + '=' + escape(value);
    if (search && re.test(search)) {
        // url存在并且含有key
        search = search.replace(re, newVal);
    }
    else {
        search += newVal;
    }
    var nUrl = window.location.href.split('?')[0] + '?' + search;
    nUrl = nUrl.replace(reg, function () {
        if (arguments) {
            switch (arguments[0]) {
                case '&':
                case '?':
                    return '';
                case '&&':
                    return '&';
                case '?&':
                    return '?';
                default:
                    return '';
            }
        }
        return '';
    });
    window.history.replaceState(null, "", nUrl);
};
exports.PARSE_DIRS_FILES = function (e) {
    return new Promise(function (resolve, reject) {
        // 判断拖拽进来是否有内容
        var files = e.files;
        if (files.length === 0) {
            return;
        }
        var items = e.items;
        var path = exports.GET_QUERY_STRING('path') || '/';
        var level = 0;
        var size = 0;
        var fileArr = [];
        var pathArr = new Set();
        var DirAndFileCount = 0;
        var DirCount = 0;
        var parseDirs = function (dirEntry, parentPath) {
            if (parentPath = parentPath || '', dirEntry.isFile) {
                dirEntry.file(function (res) {
                    res.directoryPath = parentPath;
                    fileArr.push(res);
                    size += res.size;
                    if (DirAndFileCount - DirCount + 1 === fileArr.length) {
                        level += path.split('/').length - 1;
                        resolve({ fileArr: fileArr, pathArr: Array.from(pathArr), level: level, size: size });
                    }
                });
            }
            else if (dirEntry.isDirectory) {
                var dirReader = dirEntry.createReader();
                dirReader.readEntries(function (res) {
                    DirAndFileCount += res.length;
                    DirCount++;
                    res.map(function (item) {
                        if (item.isDirectory) {
                            pathArr.add(item.fullPath + '/');
                            level = Math.max(level, item.fullPath.split('/').length - 1);
                        }
                        parseDirs(item, parentPath + dirEntry.name + '/');
                    });
                });
            }
        };
        for (var i = 0; i < files.length; i++) {
            if (items && items[i]) {
                var dirEntry = items[i].webkitGetAsEntry();
                if (!dirEntry.isFile && dirEntry.isDirectory) {
                    level = 1;
                    pathArr.add(dirEntry.fullPath + '/');
                    parseDirs(dirEntry, path);
                }
                else if (dirEntry.isFile) {
                    dirEntry.file(function (res) {
                        res.directoryPath = path;
                        fileArr.push(res);
                        size = res.size;
                        if (files.length === fileArr.length) {
                            level = path.split('/').length - 1;
                            resolve({ fileArr: fileArr, pathArr: '', level: level, size: size });
                        }
                    });
                }
            }
        }
    });
};
/**
 * 递归遍历需要压缩的数据结构树
 * @param jszip jszip实例
 * @param arr 需要遍历的数组数据
 * @param oss1 bucket sdzhofficialwebsite
 * @param oss2 bucket imotunkt
 */
exports.PARSE_DIR_TREE = function (jszip, arr, oss1, oss2) {
    if (arr instanceof Array) {
        var MAP_TREE_1 = function (arr) {
            arr.map(function (item) {
                var info = item.dirFileStructure;
                if (info.isdir) {
                    jszip.folder(info.file_dir.replace(/^\/|\/$/g, ''));
                }
                else {
                    var path = info.file_path.replace(/^http.*oss-cn-shenzhen.aliyuncs.com\//, '').replace(/^\//, '');
                    jszip.file(info.path_name ? info.path_name.substr(1) : info.file_name, exports.HTTP_REQUEST({
                        method: 'get',
                        url: /sdzhofficialwebsite/.test(info.file_path) ? oss1.signatureUrl(decodeURI(path)) : oss2.signatureUrl(decodeURI(path)),
                        config: {
                            responseType: 'arraybuffer'
                        }
                    }), { binary: true });
                }
                item.children.length && MAP_TREE_1(item.children);
            });
        };
        MAP_TREE_1(arr);
    }
    return jszip;
};
exports.FORMAT = function (date, fmt) {
    // date 为 Date对象， fmt 为 YMd HH:mm:ss格式
    date = date || new Date();
    fmt = fmt || 'YYYY-MM-dd HH:mm:ss';
    var o = {
        "M+": date.getMonth() + 1,
        "d+": date.getDate(),
        "H+": date.getHours(),
        "m+": date.getMinutes(),
        "s+": date.getSeconds(),
        "q+": Math.floor((date.getMonth() + 3) / 3),
        "S": date.getMilliseconds(),
        "w": ['周日', '周一', '周二', '周三', '周四', '周五', '周六'][date.getDay()],
    };
    if (/(Y+)/.test(fmt)) {
        fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(fmt)) {
            fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        }
    }
    return fmt;
};
exports.MEMORY_WITH_UNIT = function (memory, type) {
    var data = Number(memory);
    var unit = ['TB', 'GB', 'MB', 'KB', 'B'];
    var index = unit.indexOf(type);
    if (!index) {
        return data.toFixed(2) + type;
    }
    else {
        if (data < 1024)
            return data.toFixed(2) + type;
        else
            return exports.MEMORY_WITH_UNIT(data / 1024, unit[index - 1]);
    }
};
exports.MEMORY_WITHOUT_UNIT = function (fileSize) {
    // if (/kb/i.test(fileSize)) {
    // } else 
    if (/mb/i.test(fileSize)) {
        return parseFloat(fileSize) * 1024;
    }
    else if (/gb/i.test(fileSize)) {
        return parseFloat(fileSize) * 1024 * 1024;
    }
    return parseFloat(fileSize);
};
