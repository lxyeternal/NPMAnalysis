export declare const REG: {
    email: RegExp;
    zh: RegExp;
    zh_en: RegExp;
};
