# 项目中使用到的工具函数

## react组件
    import {PreviewFile, PreviewImage, PreviewVideo} from 'sdzh-tools'

## VALIDATE_TEXT_LENGTH
    返回文本长度，中文为1，英文为0.5

### DES 对称加密与解密
    DES(option: {
      key: string, 
      message: string, 
      type?: 'encrypt' | 'decrypt' | undefined
    }) => string
    key: 加密信息的密钥
    message: 需要加密的信息
    type: 加密或解密，默认值是encrypt
    该方法返回加密或解密结果

### 上传文件到阿里云的对象存储OSS
    const OSS: any = (option: {
      region: string,
      accessKeyId: string,
      accessKeySecret: string,
      bucket: string
    }) => OSSInstance
    该方法返回oss实例


    UPLOAD_TO_OSS({
      name: string, // oss存储路径，
      file: string, // File文件
      config: Object // oss其它配置
      progress: (percent: number) => void  // 上传进度函数
    })

### 发送网络请求
    HTTP_REQUEST = ({
      method: 'get' | 'post',
      url: string,
      data?: any,
      config?: AxiosRequestConfig,
      success?: (value?: HttpResponse) => {}
      fail?: (value?: HttpResponse) => {}
    }) => Promise


### COOKIE操作函数
    COOKIE.getCookie(key: string) 
    COOKIE.setCookie(key: string, value: string, time: number)
    COOKIE.delCookie(key: string)


### 获取浏览器链接的参数
    GET_QUERY_STRING(name) => string
    name 参数的key


### 获取随机字符串
    GET_RANDOM(length =  10) => string
    length 返回的字符串长度，默认为10

### 判断数组或对象是否为空
    IS_EMPTY(Object) => boolean

### 替换浏览器参数
    REPLACE_PARAML(key: string, value: string)
    key 参数名
    value 参数值

### 遍历拖拽文件夹，并返回文件列表
    PARSE_DIRS_FILES(dataTransfer: DataTransfer) => Array<File>

### 需要下载的文件夹数据 并返回jszip实例
    // oss1 bucket sdzhofficialwebsite
    // oss2 bucket imotunkt
    PARSE_DIR_TREE(jszip: JSZip,arr: Array<downloadDir>, oss1: any, oss2: any) => jszip

### 格式化时间
    // Y:年 M:月 d:日 H:时 m:分 s:秒 q:季度 w: 周几
    FORMAT(Date, format) => string 

### 内存转换成带单位的值
    // 数字转换成最大单位的内存单位
    MEMORY_WITH_UNIT(memory: number, unit: string)


### 内存转换成不带单位的kb值
    // 带单位内存转换成kb为单位的数字
    MEMORY_WITHOUT_UNIT(memory: string) 

