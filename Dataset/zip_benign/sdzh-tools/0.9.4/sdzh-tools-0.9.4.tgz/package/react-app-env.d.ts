/// <reference types="node" />
/// <reference types="react" />


declare namespace NodeJS {
  interface ProcessEnv {
    readonly NODE_ENV: 'development' | 'production' | 'test';
    readonly PUBLIC_URL: string;
  }
}

interface Window {
  Tucao: any;
  __REDUX_DEVTOOLS_EXTENSION_COMPOSE__: any;
  particlesJS: any;
  ActiveXObject: any;
  qt: any;
  QRCode: any;
}

interface Document{
  webkitIsFullScreen: boolean;
  mozFullScreen: boolean;
}

declare module '*.bmp' {
  const src: string;
  export default src;
}

declare module '*.gif' {
  const src: string;
  export default src;
}

declare module '*.jpg' {
  const src: string;
  export default src;
}

declare module '*.jpeg' {
  const src: string;
  export default src;
}

declare module '*.png' {
  const src: string;
  export default src;
}

declare module '*.webp' {
    const src: string;
    export default src;
}

declare module '*.svg' {
  import * as React from 'react';

  export const ReactComponent: React.FunctionComponent<React.SVGProps<SVGSVGElement>>;

  const src: string;
  export default src;
}

declare module '*.module.css' {
  const classes: { readonly [key: string]: string };
  export default classes;
}

declare module '*.module.scss' {
  const classes: { readonly [key: string]: string };
  export default classes;
}

declare module '*.module.sass' {
  const classes: { readonly [key: string]: string };
  export default classes;
}


declare module 'tim-js-sdk' {
  const classes: any;
  export default classes;
}
declare module 'cos-js-sdk-v5' {
  const classes: any;
  export default classes;
}

declare module 'emojify.js' {
  const classes: any;
  export default classes;
}