import TIM from 'tim-js-sdk';
import COS from 'cos-js-sdk-v5';

interface SDZH_TIMProps {
  SDKAppID: number;
  logLevel: number;
  onSdkIsReady?: (e: any) => void;
  onError: (e: any) => void;
  onMessageReceived?: (e: any) => void;
  onMessageRevoked?: (e: any) => void;
  onConversationListUpdate?: (e: any) => void;
  onGroupListUpdate?: (e: any) => void;
  onGroupSystemNoticeReceived?: (e: any) => void;
  onKickOut?: (e: any) => void;
  onNetStateChange?: (e: any) => void;
  onProfileUpdate?: (e: any) => void;
  onBlacklistUpdate?: (e: any) => void;
}

interface TIM {
  login: (...arg: any) => Promise<any>;
  logout: (...arg: any) => Promise<any>;

  joinGroup: (...arg: any) => Promise<any>;
  quitGroup: (...arg: any) => Promise<any>;

  createTextMessage: (...arg: any) => Promise<any>;
  sendMessage: (...arg: any) => Promise<any>;

  getMessageList: (...arg: any) => Promise<any>;
  updateMyProfile: (...arg: any) => Promise<any>;

  getGroupProfile: (...arg: any) => Promise<any>;
  getGroupMemberList: (...arg: any) => Promise<void>;

  getGroupList: (...arg: any) => Promise<void>;

  createGroup: (...arg: any) => Promise<void>;
}

export const TIM_TYPES = TIM.TYPES;
export const TIM_EVENT = TIM.EVENT

export const SDZH_TIM = (options: SDZH_TIMProps): TIM => {
  const tim = TIM.create({
    SDKAppID: options.SDKAppID
  }); // SDK 实例通常用 tim 表示
  const defaultCallback = () => {}
  // 设置 SDK 日志输出级别，详细分级请参见 setLogLevel 接口的说明
  tim.setLogLevel(0); // 普通级别，日志量较多，接入时建议使用
  // tim.setLogLevel(1); // release级别，SDK 输出关键信息，生产环境时建议使用
  // 将腾讯云对象存储服务 SDK （以下简称 COS SDK）注册为插件，IM SDK 发送文件、图片等消息时，需要用到腾讯云的 COS 服务
  // HTML5 环境，注册 COS SDK
  tim.registerPlugin({ 'cos-js-sdk': COS });
  //登录成功后会触发 SDK_READY 事件，该事件触发后，可正常使用 SDK 接口
  tim.on(TIM_EVENT.SDK_READY, options.onSdkIsReady || defaultCallback);
  //SDK NOT READT
  tim.on(TIM_EVENT.SDK_NOT_READY, options.onSdkIsReady || defaultCallback);
  //SDK内部出错
  tim.on(TIM_EVENT.ERROR, options.onError || defaultCallback);
  //收到新消息
  tim.on(TIM_EVENT.MESSAGE_RECEIVED, options.onMessageReceived || defaultCallback);
  //收到消息被撤回
  tim.on(TIM_EVENT.MESSAGE_REVOKED, options.onMessageRevoked || defaultCallback);
  //会话列表更新
  tim.on(TIM_EVENT.CONVERSATION_LIST_UPDATED, options.onConversationListUpdate || defaultCallback || defaultCallback);
  //群组列表更新
  tim.on(TIM_EVENT.GROUP_LIST_UPDATED, options.onGroupListUpdate || defaultCallback || defaultCallback);
  //收到新的群系统通知
  tim.on(TIM_EVENT.GROUP_SYSTEM_NOTICE_RECEIVED, options.onGroupSystemNoticeReceived || defaultCallback || defaultCallback);
  //收到自己或好友资料变更通知
  tim.on(TIM_EVENT.PROFILE_UPDATED, options.onProfileUpdate || defaultCallback);
  //收到黑名单列表更新通知
  tim.on(TIM_EVENT.BLACKLIST_UPDATED, options.onBlacklistUpdate || defaultCallback);
  //下线通知
  tim.on(TIM_EVENT.KICKED_OUT, options.onKickOut || defaultCallback);
  //网络状态变化
  tim.on(TIM_EVENT.NET_STATE_CHANGE, options.onNetStateChange || defaultCallback);

  return tim;
}