"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var tim_js_sdk_1 = __importDefault(require("tim-js-sdk"));
var cos_js_sdk_v5_1 = __importDefault(require("cos-js-sdk-v5"));
exports.TIM_TYPES = tim_js_sdk_1.default.TYPES;
exports.TIM_EVENT = tim_js_sdk_1.default.EVENT;
exports.SDZH_TIM = function (options) {
    var tim = tim_js_sdk_1.default.create({
        SDKAppID: options.SDKAppID
    }); // SDK 实例通常用 tim 表示
    var defaultCallback = function () { };
    // 设置 SDK 日志输出级别，详细分级请参见 setLogLevel 接口的说明
    tim.setLogLevel(0); // 普通级别，日志量较多，接入时建议使用
    // tim.setLogLevel(1); // release级别，SDK 输出关键信息，生产环境时建议使用
    // 将腾讯云对象存储服务 SDK （以下简称 COS SDK）注册为插件，IM SDK 发送文件、图片等消息时，需要用到腾讯云的 COS 服务
    // HTML5 环境，注册 COS SDK
    tim.registerPlugin({ 'cos-js-sdk': cos_js_sdk_v5_1.default });
    //登录成功后会触发 SDK_READY 事件，该事件触发后，可正常使用 SDK 接口
    tim.on(exports.TIM_EVENT.SDK_READY, options.onSdkIsReady || defaultCallback);
    //SDK NOT READT
    tim.on(exports.TIM_EVENT.SDK_NOT_READY, options.onSdkIsReady || defaultCallback);
    //SDK内部出错
    tim.on(exports.TIM_EVENT.ERROR, options.onError || defaultCallback);
    //收到新消息
    tim.on(exports.TIM_EVENT.MESSAGE_RECEIVED, options.onMessageReceived || defaultCallback);
    //收到消息被撤回
    tim.on(exports.TIM_EVENT.MESSAGE_REVOKED, options.onMessageRevoked || defaultCallback);
    //会话列表更新
    tim.on(exports.TIM_EVENT.CONVERSATION_LIST_UPDATED, options.onConversationListUpdate || defaultCallback || defaultCallback);
    //群组列表更新
    tim.on(exports.TIM_EVENT.GROUP_LIST_UPDATED, options.onGroupListUpdate || defaultCallback || defaultCallback);
    //收到新的群系统通知
    tim.on(exports.TIM_EVENT.GROUP_SYSTEM_NOTICE_RECEIVED, options.onGroupSystemNoticeReceived || defaultCallback || defaultCallback);
    //收到自己或好友资料变更通知
    tim.on(exports.TIM_EVENT.PROFILE_UPDATED, options.onProfileUpdate || defaultCallback);
    //收到黑名单列表更新通知
    tim.on(exports.TIM_EVENT.BLACKLIST_UPDATED, options.onBlacklistUpdate || defaultCallback);
    //下线通知
    tim.on(exports.TIM_EVENT.KICKED_OUT, options.onKickOut || defaultCallback);
    //网络状态变化
    tim.on(exports.TIM_EVENT.NET_STATE_CHANGE, options.onNetStateChange || defaultCallback);
    return tim;
};
