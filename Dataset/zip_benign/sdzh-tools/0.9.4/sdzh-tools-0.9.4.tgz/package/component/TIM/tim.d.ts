import TIM from 'tim-js-sdk';
interface SDZH_TIMProps {
    SDKAppID: number;
    logLevel: number;
    onSdkIsReady?: (e: any) => void;
    onError: (e: any) => void;
    onMessageReceived?: (e: any) => void;
    onMessageRevoked?: (e: any) => void;
    onConversationListUpdate?: (e: any) => void;
    onGroupListUpdate?: (e: any) => void;
    onGroupSystemNoticeReceived?: (e: any) => void;
    onKickOut?: (e: any) => void;
    onNetStateChange?: (e: any) => void;
    onProfileUpdate?: (e: any) => void;
    onBlacklistUpdate?: (e: any) => void;
}
interface TIM {
    login: (...arg: any) => Promise<any>;
    logout: (...arg: any) => Promise<any>;
    joinGroup: (...arg: any) => Promise<any>;
    quitGroup: (...arg: any) => Promise<any>;
    createTextMessage: (...arg: any) => Promise<any>;
    sendMessage: (...arg: any) => Promise<any>;
    getMessageList: (...arg: any) => Promise<any>;
    updateMyProfile: (...arg: any) => Promise<any>;
    getGroupProfile: (...arg: any) => Promise<any>;
    getGroupMemberList: (...arg: any) => Promise<void>;
    getGroupList: (...arg: any) => Promise<void>;
    createGroup: (...arg: any) => Promise<void>;
}
export declare const TIM_TYPES: any;
export declare const TIM_EVENT: any;
export declare const SDZH_TIM: (options: SDZH_TIMProps) => TIM;
export {};
