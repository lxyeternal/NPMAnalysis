import React from 'react';
import './createSchoolModal.less';
import 'antd/es/form/style';
import { FormComponentProps } from 'antd/lib/form/Form';
interface formPorps extends FormComponentProps {
    visible: boolean;
    onCancel: any;
    isAudit: any;
    onSubmit: (values: any) => void;
}
declare const _default: React.MemoExoticComponent<import("antd/lib/form/interface").ConnectedComponentClass<({ form, visible, onCancel, isAudit, onSubmit }: formPorps) => JSX.Element, Pick<formPorps, "visible" | "onSubmit" | "onCancel" | "isAudit" | "wrappedComponentRef">>>;
export default _default;
