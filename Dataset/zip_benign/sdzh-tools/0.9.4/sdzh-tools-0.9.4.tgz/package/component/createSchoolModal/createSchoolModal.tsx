import React from 'react';
import Modal from 'antd/es/modal';
import Input from 'antd/es/input'
import Button from 'antd/es/button'
import './createSchoolModal.less'
import 'antd/es/form/style'
import Form, { FormComponentProps } from 'antd/lib/form/Form';
interface formPorps extends FormComponentProps {
  visible: boolean;
  onCancel: any;
  isAudit: any;
  onSubmit: (values: any) => void;
}
// forwardRef<FormComponentProps, formPorps>(({ form, visible, onCancel }: formPorps, _ref)
const CreateSchoolForm =(({ form, visible, onCancel, isAudit, onSubmit }: formPorps) => {
  // useImperativeHandle(_ref, () => ({
  //   form
  // }))
  console.log('创建学校')
  const handleSubmit = (e: any) => {
    e.preventDefault();
    form.validateFields((err: any, values: any) => {
      if (!err) {
        //todo  创建学校
        onSubmit(values)
      }
    });
  }
  return (
    <Modal
      title={null}
      footer={null}
      centered
      visible={visible}
      wrapClassName='create-school-modal'
      width={460}
      onCancel={(e: any) => {onCancel(false)}}
    >
      <div className='create-school-modal-content'>
        <p>创建学校</p>
        <div>{isAudit ? '正在系统审核中，审核结果将在1-2个工作日内通知到您，请耐心等候吧' : '请填写贵校基本信息，系统将会在1-2个工作日内完成审核并通知到您。'}</div>
        <Form className="create-school-form" onSubmit={handleSubmit}>
          <Form.Item>
            {
              form.getFieldDecorator('schoolName', {
                rules: [
                  {
                    required: true,
                    message: '请输入学校名称，最多30字',
                  }
                ],
                initialValue: isAudit ? isAudit.group_name : ''
              })(<Input maxLength={30} placeholder="请填写学校名称" disabled={isAudit ? true : false}></Input>)
            }
          </Form.Item>
          <Form.Item>
            {
              form.getFieldDecorator('schoolDomain', {
                rules: [
                  {
                    validator: (rule: any, value: any, callback: Function) => {
                      if (value && !/^[A-Za-z.]*/.test(value)) {
                        callback('请填写有效的学校网站域名')
                      } else {
                        callback()
                      }
                    },
                  },
                ],
                initialValue: isAudit ? isAudit.domain : ''
              })(<Input maxLength={40} placeholder="请填写学校网站域名，如：baidu.com" disabled={isAudit ? true : false}></Input>)
            }
          </Form.Item>
          <Form.Item>
            {isAudit? <Button block disabled size="large">正在审核</Button>:<Button type="primary" block htmlType="submit" size="large">提交申请</Button>}
          </Form.Item>
        </Form>
      </div>
    </Modal>
  )
})
const CreateSchoolModal = Form.create<formPorps>()(CreateSchoolForm);
export default React.memo(CreateSchoolModal, (prevProps, nextProps) => {
  if(prevProps.visible !== nextProps.visible || prevProps.isAudit !== nextProps.isAudit) return false
  return true
})