"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var react_1 = __importDefault(require("react"));
var modal_1 = __importDefault(require("antd/es/modal"));
var input_1 = __importDefault(require("antd/es/input"));
var button_1 = __importDefault(require("antd/es/button"));
require("./createSchoolModal.less");
require("antd/es/form/style");
var Form_1 = __importDefault(require("antd/lib/form/Form"));
// forwardRef<FormComponentProps, formPorps>(({ form, visible, onCancel }: formPorps, _ref)
var CreateSchoolForm = (function (_a) {
    var form = _a.form, visible = _a.visible, onCancel = _a.onCancel, isAudit = _a.isAudit, onSubmit = _a.onSubmit;
    // useImperativeHandle(_ref, () => ({
    //   form
    // }))
    console.log('创建学校');
    var handleSubmit = function (e) {
        e.preventDefault();
        form.validateFields(function (err, values) {
            if (!err) {
                //todo  创建学校
                onSubmit(values);
            }
        });
    };
    return (react_1.default.createElement(modal_1.default, { title: null, footer: null, centered: true, visible: visible, wrapClassName: 'create-school-modal', width: 460, onCancel: function (e) { onCancel(false); } },
        react_1.default.createElement("div", { className: 'create-school-modal-content' },
            react_1.default.createElement("p", null, "\u521B\u5EFA\u5B66\u6821"),
            react_1.default.createElement("div", null, isAudit ? '正在系统审核中，审核结果将在1-2个工作日内通知到您，请耐心等候吧' : '请填写贵校基本信息，系统将会在1-2个工作日内完成审核并通知到您。'),
            react_1.default.createElement(Form_1.default, { className: "create-school-form", onSubmit: handleSubmit },
                react_1.default.createElement(Form_1.default.Item, null, form.getFieldDecorator('schoolName', {
                    rules: [
                        {
                            required: true,
                            message: '请输入学校名称，最多30字',
                        }
                    ],
                    initialValue: isAudit ? isAudit.group_name : ''
                })(react_1.default.createElement(input_1.default, { maxLength: 30, placeholder: "\u8BF7\u586B\u5199\u5B66\u6821\u540D\u79F0", disabled: isAudit ? true : false }))),
                react_1.default.createElement(Form_1.default.Item, null, form.getFieldDecorator('schoolDomain', {
                    rules: [
                        {
                            validator: function (rule, value, callback) {
                                if (value && !/^[A-Za-z.]*/.test(value)) {
                                    callback('请填写有效的学校网站域名');
                                }
                                else {
                                    callback();
                                }
                            },
                        },
                    ],
                    initialValue: isAudit ? isAudit.domain : ''
                })(react_1.default.createElement(input_1.default, { maxLength: 40, placeholder: "\u8BF7\u586B\u5199\u5B66\u6821\u7F51\u7AD9\u57DF\u540D\uFF0C\u5982\uFF1Abaidu.com", disabled: isAudit ? true : false }))),
                react_1.default.createElement(Form_1.default.Item, null, isAudit ? react_1.default.createElement(button_1.default, { block: true, disabled: true, size: "large" }, "\u6B63\u5728\u5BA1\u6838") : react_1.default.createElement(button_1.default, { type: "primary", block: true, htmlType: "submit", size: "large" }, "\u63D0\u4EA4\u7533\u8BF7"))))));
});
var CreateSchoolModal = Form_1.default.create()(CreateSchoolForm);
exports.default = react_1.default.memo(CreateSchoolModal, function (prevProps, nextProps) {
    if (prevProps.visible !== nextProps.visible || prevProps.isAudit !== nextProps.isAudit)
        return false;
    return true;
});
