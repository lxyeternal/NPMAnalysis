import { Component, CSSProperties } from 'react';
import './previewVideo.less';
interface PreviewVideoProps {
    onClose: (() => void) | undefined;
    src: string;
    poster: string;
    videoStyle?: CSSProperties | undefined;
}
declare class PreviewVideo extends Component<PreviewVideoProps> {
    constructor(props: PreviewVideoProps);
    render(): JSX.Element;
}
export default PreviewVideo;
