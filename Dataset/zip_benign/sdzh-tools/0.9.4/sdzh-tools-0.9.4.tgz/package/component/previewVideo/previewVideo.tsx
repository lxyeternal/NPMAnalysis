import React, { Component, CSSProperties } from 'react';
import './previewVideo.less'

interface PreviewVideoProps {
  onClose: (() => void) | undefined;
  src: string;
  poster: string;
  videoStyle?: CSSProperties | undefined;
  
}
class PreviewVideo extends Component<PreviewVideoProps> {
  constructor(props: PreviewVideoProps) {
    super(props);
    this.state = {}
  }

  render() {
    const {onClose, src, poster, videoStyle} = this.props;
    return <div className="play-video" onClick={onClose}>
    <video style={videoStyle} src={src} controls autoPlay poster={poster} onClick={(e) => e.stopPropagation()}></video>
  </div>
  }
}

export default PreviewVideo