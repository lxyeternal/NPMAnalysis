"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
var react_1 = __importStar(require("react"));
require("./previewVideo.less");
var PreviewVideo = /** @class */ (function (_super) {
    __extends(PreviewVideo, _super);
    function PreviewVideo(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {};
        return _this;
    }
    PreviewVideo.prototype.render = function () {
        var _a = this.props, onClose = _a.onClose, src = _a.src, poster = _a.poster, videoStyle = _a.videoStyle;
        return react_1.default.createElement("div", { className: "play-video", onClick: onClose },
            react_1.default.createElement("video", { style: videoStyle, src: src, controls: true, autoPlay: true, poster: poster, onClick: function (e) { return e.stopPropagation(); } }));
    };
    return PreviewVideo;
}(react_1.Component));
exports.default = PreviewVideo;
