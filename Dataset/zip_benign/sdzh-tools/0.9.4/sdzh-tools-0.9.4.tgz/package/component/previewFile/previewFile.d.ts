import { Component } from 'react';
import './previewFile.less';
interface PreviewFileProps {
    fileInfo: any;
    isEmbedded?: boolean;
    src: string;
    onClosePreviewFile: Function;
}
interface PreviewFileState {
    previewMeta: any;
    previewIndex: any;
    isFullScreen: boolean;
    isExcel: boolean;
}
export default class PreviewFile extends Component<PreviewFileProps, PreviewFileState> {
    private clickPrevPage;
    private clickNextPage;
    private sendMessage;
    constructor(props: PreviewFileProps);
    componentDidMount: () => void;
    close: () => void;
    exitFullScreen: () => void;
    fullScreen: () => void;
    prevPage: () => void;
    nextPage: () => void;
    render(): JSX.Element;
}
export {};
