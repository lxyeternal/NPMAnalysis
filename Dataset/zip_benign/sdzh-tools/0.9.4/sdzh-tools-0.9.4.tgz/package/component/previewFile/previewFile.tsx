import React, { Component } from 'react';
// import { Button } from 'antd';
import Icon  from 'antd/es/icon'
import Button  from 'antd/es/button'
import './previewFile.less';
interface Window {
  Tucao: any;
  __REDUX_DEVTOOLS_EXTENSION_COMPOSE__: any;
  particlesJS: any;
  ActiveXObject: any;
  qt: any;
  QRCode: any;
}

interface Document {
  webkitIsFullScreen: boolean;
  mozFullScreen: boolean;
}
interface PreviewFileProps {
  fileInfo: any,
  isEmbedded?: boolean,
  src: string,
  onClosePreviewFile: Function
}

interface PreviewFileState {
  previewMeta: any;
  previewIndex: any;
  isFullScreen: boolean;
  isExcel: boolean;
}

const exitIcon = (props: React.SVGProps<SVGSVGElement>) => {
  return <svg viewBox="0 0 1024 1024" version="1.1" {...props}><path d="M717.1584 363.6736c0-9.216 3.5328-18.432 10.5984-25.3952a35.8912 35.8912 0 0 1 50.944 0l146.2784 146.3808a35.8912 35.8912 0 0 1 0 50.8928l-146.2784 146.432a35.8912 35.8912 0 0 1-61.44-25.5488 35.84 35.84 0 0 1 10.496-25.4976l84.9408-84.8896h-449.024a35.9936 35.9936 0 1 1 0-71.9872h449.024L727.7056 389.12a36.1984 36.1984 0 0 1-10.5472-25.4976zM565.76 891.0848a35.84 35.84 0 1 1 0 71.68H163.84a76.8 76.8 0 0 1-76.8-76.8V143.36a76.8 76.8 0 0 1 76.8-76.8h401.8688a35.84 35.84 0 0 1 0 71.68H163.84a5.12 5.12 0 0 0-5.12 5.12v742.6048a5.12 5.12 0 0 0 5.12 5.12h401.8688z"></path></svg>
}

const FULL_SCREEN = (el?: any) => {
  el = document.documentElement;
  let rfs = el.requestFullScreen || el.webkitRequestFullScreen || el.mozRequestFullScreen || el.msRequestFullScreen,
    wscript;

  if (typeof rfs != "undefined" && rfs) {
    rfs.call(el);
    return;
  }

  if (typeof window['ActiveXObject'] != "undefined") {
    wscript = new window['ActiveXObject']("WScript.Shell");
    if (wscript) {
      wscript.SendKeys("{F11}");
    }
  }
}

const EXIT_FULL_SCREEN = () => {
  let el: any = document;
  let cfs = el.cancelFullScreen || el.webkitCancelFullScreen || el.mozCancelFullScreen || el.exitFullScreen;
  let wscript;
  if (typeof cfs != "undefined" && cfs) {
    cfs.call(el);
    return;
  }
  if (typeof window['ActiveXObject'] != "undefined") {
    wscript = new window['ActiveXObject']("WScript.Shell");
    if (wscript != null) {
      wscript.SendKeys("{F11}");
    }
  }
}
export default class PreviewFile extends Component<PreviewFileProps, PreviewFileState> {
  private clickPrevPage: any;
  private clickNextPage: any;
  private sendMessage: (...arg: any[]) => void;
  constructor(props: PreviewFileProps) {
    super(props)
    this.state = {
      previewMeta: {},
      previewIndex: 0,
      isFullScreen: false,
      isExcel: ['xls', 'xlsx'].includes(props.fileInfo.file_type),
    };
    /** 
     * 阿里云文件预览通信
     */
    const json2str = (obj: any) => {
      return JSON.stringify(obj, function (key, val) {
        if (typeof val === 'function') {
          val = val.toString();
        }
        return val;
      });
    }

    this.sendMessage = function (action: any, data: any) {
      const iframe: HTMLIFrameElement = (document.getElementById('preview-iframe') as HTMLIFrameElement);
      iframe?.contentWindow?.postMessage(json2str({ action: action, data: data }), '*');
    };

    window.onmessage = (e: MessageEvent) => {
      if (e.origin !== 'https://preview.imm.aliyun.com' || typeof (e.data) !== 'string') return;
      var res = JSON.parse(e.data);
      switch (res.action) {
        case 'preview.meta':
          this.setState({
            previewMeta: res.data
          })
          break;
        case 'page.readPage':
          this.setState({
            previewIndex: res.data.pageIndex
          })
          break;
        case 'preview.ready':
          this.sendMessage('setConfig', {
            powerpointCustomStyle: function (isMobile: boolean) {
              if (!isMobile) {
                return {
                  // 隐藏翻页按钮
                  paginationDisplay: false,
                  // 隐藏全屏按钮
                  fullScreenButtonDisplay: false,
                  // 预览容器上边距
                  containerMarginTop: 30,
                  // 预览容器下边距
                  containerMarginBottom: 30,
                  // 容器背景色
                  // containerBackground: '#000000'
                };
              } else {
                return {};
              }
            }
          })
          break;
        default:
          break;
      }
    }
  }

  componentDidMount = () => {
    window.onresize = () => {
      const isFullScreen = document.fullscreen || document.webkitIsFullScreen || document.mozFullScreen;
      this.setState({ isFullScreen })
    }
  }
  public close = () => {
    this.props.onClosePreviewFile(false)
  }

  public exitFullScreen = () => {
    EXIT_FULL_SCREEN();
  }

  public fullScreen = () => {
    FULL_SCREEN();
  }

  public prevPage = () => {
    if (this.clickPrevPage) return;
    this.clickPrevPage = setTimeout(() => {
      this.clickPrevPage = null;
      this.sendMessage('logic.prevPage')
    }, 0)
  }

  public nextPage = () => {
    if (this.clickNextPage) return;
    this.clickNextPage = setTimeout(() => {
      this.clickNextPage = null;
      this.sendMessage('logic.nextPage')
    }, 0)
  }

  render() {
    const { fileInfo } = this.props;
    const { previewIndex, previewMeta, isExcel } = this.state;
    return (
      <div className="previewFile" onKeyPress={() => { }}>
        <React.Fragment>
          {!this.state.isFullScreen && <div className="title">
            <img src={this.props.fileInfo.src} alt=""></img>
            <span>{this.props.fileInfo.file_name}</span>
          </div>}
          <div className="options-btn">
            {!isExcel && <div className="custom-preview" style={{ textAlign: 'center' }} id={isExcel ? '111' : '000'}>
              <Icon className="page-btn" onClick={this.prevPage} type="left" style={{ color: previewIndex === 0 ? '#ACACAC' : '#517Eff' }} />
              <span className="page-show">{(previewIndex + 1) + " / " + previewMeta.pc}</span>
              <Icon className="page-btn" onClick={this.nextPage} type="right" style={{ color: (previewIndex + 1 === previewMeta.pc ? '#ACACAC' : '#517Eff') }} />
            </div>}
            <div style={{ position: 'absolute', top: 14, right: 60, }}>
              <a href={fileInfo.file_path}><Button type="primary"><img src="~~/images/downloadPreview.png" alt="" /><span>&nbsp;下载</span></Button></a>
              {!this.state.isFullScreen && <Button type="primary" className="fullScreen" style={{ margin: '0 10px' }} onClick={this.fullScreen}>
                <Icon type="fullscreen" />全屏
              </Button>}
              {this.state.isFullScreen && <Button type="primary" style={{ margin: '0 10px' }} onClick={this.exitFullScreen}>
                <Icon type="fullscreen-exit" />
                退出全屏</Button>}
              <Button type="primary" onClick={this.close} className="exitEmbeddedPreview"><Icon component={exitIcon} /><span>&nbsp;退出预览</span></Button>
            </div>
          </div>
          <iframe id="preview-iframe" title="预览iframe" src={this.props.src} frameBorder="0" style={{ height: this.state.isFullScreen ? '100%' : 'calc(100% - 115px)' }} />
        </React.Fragment>
      </div>
    )
  }
}
