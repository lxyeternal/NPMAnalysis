"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var react_1 = __importStar(require("react"));
// import { Button } from 'antd';
var icon_1 = __importDefault(require("antd/es/icon"));
var button_1 = __importDefault(require("antd/es/button"));
require("./previewFile.less");
var exitIcon = function (props) {
    return react_1.default.createElement("svg", __assign({ viewBox: "0 0 1024 1024", version: "1.1" }, props),
        react_1.default.createElement("path", { d: "M717.1584 363.6736c0-9.216 3.5328-18.432 10.5984-25.3952a35.8912 35.8912 0 0 1 50.944 0l146.2784 146.3808a35.8912 35.8912 0 0 1 0 50.8928l-146.2784 146.432a35.8912 35.8912 0 0 1-61.44-25.5488 35.84 35.84 0 0 1 10.496-25.4976l84.9408-84.8896h-449.024a35.9936 35.9936 0 1 1 0-71.9872h449.024L727.7056 389.12a36.1984 36.1984 0 0 1-10.5472-25.4976zM565.76 891.0848a35.84 35.84 0 1 1 0 71.68H163.84a76.8 76.8 0 0 1-76.8-76.8V143.36a76.8 76.8 0 0 1 76.8-76.8h401.8688a35.84 35.84 0 0 1 0 71.68H163.84a5.12 5.12 0 0 0-5.12 5.12v742.6048a5.12 5.12 0 0 0 5.12 5.12h401.8688z" }));
};
var FULL_SCREEN = function (el) {
    el = document.documentElement;
    var rfs = el.requestFullScreen || el.webkitRequestFullScreen || el.mozRequestFullScreen || el.msRequestFullScreen, wscript;
    if (typeof rfs != "undefined" && rfs) {
        rfs.call(el);
        return;
    }
    if (typeof window['ActiveXObject'] != "undefined") {
        wscript = new window['ActiveXObject']("WScript.Shell");
        if (wscript) {
            wscript.SendKeys("{F11}");
        }
    }
};
var EXIT_FULL_SCREEN = function () {
    var el = document;
    var cfs = el.cancelFullScreen || el.webkitCancelFullScreen || el.mozCancelFullScreen || el.exitFullScreen;
    var wscript;
    if (typeof cfs != "undefined" && cfs) {
        cfs.call(el);
        return;
    }
    if (typeof window['ActiveXObject'] != "undefined") {
        wscript = new window['ActiveXObject']("WScript.Shell");
        if (wscript != null) {
            wscript.SendKeys("{F11}");
        }
    }
};
var PreviewFile = /** @class */ (function (_super) {
    __extends(PreviewFile, _super);
    function PreviewFile(props) {
        var _this = _super.call(this, props) || this;
        _this.componentDidMount = function () {
            window.onresize = function () {
                var isFullScreen = document.fullscreen || document.webkitIsFullScreen || document.mozFullScreen;
                _this.setState({ isFullScreen: isFullScreen });
            };
        };
        _this.close = function () {
            _this.props.onClosePreviewFile(false);
        };
        _this.exitFullScreen = function () {
            EXIT_FULL_SCREEN();
        };
        _this.fullScreen = function () {
            FULL_SCREEN();
        };
        _this.prevPage = function () {
            if (_this.clickPrevPage)
                return;
            _this.clickPrevPage = setTimeout(function () {
                _this.clickPrevPage = null;
                _this.sendMessage('logic.prevPage');
            }, 0);
        };
        _this.nextPage = function () {
            if (_this.clickNextPage)
                return;
            _this.clickNextPage = setTimeout(function () {
                _this.clickNextPage = null;
                _this.sendMessage('logic.nextPage');
            }, 0);
        };
        _this.state = {
            previewMeta: {},
            previewIndex: 0,
            isFullScreen: false,
            isExcel: ['xls', 'xlsx'].includes(props.fileInfo.file_type),
        };
        /**
         * 阿里云文件预览通信
         */
        var json2str = function (obj) {
            return JSON.stringify(obj, function (key, val) {
                if (typeof val === 'function') {
                    val = val.toString();
                }
                return val;
            });
        };
        _this.sendMessage = function (action, data) {
            var _a;
            var iframe = document.getElementById('preview-iframe');
            (_a = iframe === null || iframe === void 0 ? void 0 : iframe.contentWindow) === null || _a === void 0 ? void 0 : _a.postMessage(json2str({ action: action, data: data }), '*');
        };
        window.onmessage = function (e) {
            if (e.origin !== 'https://preview.imm.aliyun.com' || typeof (e.data) !== 'string')
                return;
            var res = JSON.parse(e.data);
            switch (res.action) {
                case 'preview.meta':
                    _this.setState({
                        previewMeta: res.data
                    });
                    break;
                case 'page.readPage':
                    _this.setState({
                        previewIndex: res.data.pageIndex
                    });
                    break;
                case 'preview.ready':
                    _this.sendMessage('setConfig', {
                        powerpointCustomStyle: function (isMobile) {
                            if (!isMobile) {
                                return {
                                    // 隐藏翻页按钮
                                    paginationDisplay: false,
                                    // 隐藏全屏按钮
                                    fullScreenButtonDisplay: false,
                                    // 预览容器上边距
                                    containerMarginTop: 30,
                                    // 预览容器下边距
                                    containerMarginBottom: 30,
                                };
                            }
                            else {
                                return {};
                            }
                        }
                    });
                    break;
                default:
                    break;
            }
        };
        return _this;
    }
    PreviewFile.prototype.render = function () {
        var fileInfo = this.props.fileInfo;
        var _a = this.state, previewIndex = _a.previewIndex, previewMeta = _a.previewMeta, isExcel = _a.isExcel;
        return (react_1.default.createElement("div", { className: "previewFile", onKeyPress: function () { } },
            react_1.default.createElement(react_1.default.Fragment, null,
                !this.state.isFullScreen && react_1.default.createElement("div", { className: "title" },
                    react_1.default.createElement("img", { src: this.props.fileInfo.src, alt: "" }),
                    react_1.default.createElement("span", null, this.props.fileInfo.file_name)),
                react_1.default.createElement("div", { className: "options-btn" },
                    !isExcel && react_1.default.createElement("div", { className: "custom-preview", style: { textAlign: 'center' }, id: isExcel ? '111' : '000' },
                        react_1.default.createElement(icon_1.default, { className: "page-btn", onClick: this.prevPage, type: "left", style: { color: previewIndex === 0 ? '#ACACAC' : '#517Eff' } }),
                        react_1.default.createElement("span", { className: "page-show" }, (previewIndex + 1) + " / " + previewMeta.pc),
                        react_1.default.createElement(icon_1.default, { className: "page-btn", onClick: this.nextPage, type: "right", style: { color: (previewIndex + 1 === previewMeta.pc ? '#ACACAC' : '#517Eff') } })),
                    react_1.default.createElement("div", { style: { position: 'absolute', top: 14, right: 60, } },
                        react_1.default.createElement("a", { href: fileInfo.file_path },
                            react_1.default.createElement(button_1.default, { type: "primary" },
                                react_1.default.createElement("img", { src: "~~/images/downloadPreview.png", alt: "" }),
                                react_1.default.createElement("span", null, "\u00A0\u4E0B\u8F7D"))),
                        !this.state.isFullScreen && react_1.default.createElement(button_1.default, { type: "primary", className: "fullScreen", style: { margin: '0 10px' }, onClick: this.fullScreen },
                            react_1.default.createElement(icon_1.default, { type: "fullscreen" }),
                            "\u5168\u5C4F"),
                        this.state.isFullScreen && react_1.default.createElement(button_1.default, { type: "primary", style: { margin: '0 10px' }, onClick: this.exitFullScreen },
                            react_1.default.createElement(icon_1.default, { type: "fullscreen-exit" }),
                            "\u9000\u51FA\u5168\u5C4F"),
                        react_1.default.createElement(button_1.default, { type: "primary", onClick: this.close, className: "exitEmbeddedPreview" },
                            react_1.default.createElement(icon_1.default, { component: exitIcon }),
                            react_1.default.createElement("span", null, "\u00A0\u9000\u51FA\u9884\u89C8")))),
                react_1.default.createElement("iframe", { id: "preview-iframe", title: "\u9884\u89C8iframe", src: this.props.src, frameBorder: "0", style: { height: this.state.isFullScreen ? '100%' : 'calc(100% - 115px)' } }))));
    };
    return PreviewFile;
}(react_1.Component));
exports.default = PreviewFile;
