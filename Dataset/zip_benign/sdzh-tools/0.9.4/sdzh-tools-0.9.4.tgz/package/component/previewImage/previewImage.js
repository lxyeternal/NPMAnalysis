"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    result["default"] = mod;
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var react_1 = __importStar(require("react"));
var carousel_1 = __importDefault(require("antd/es/carousel"));
var icon_1 = __importDefault(require("antd/es/icon"));
var button_1 = __importDefault(require("antd/es/button"));
require("antd/es/carousel/style");
require("antd/es/icon/style");
require("./previewImage.less");
var react_dom_1 = __importDefault(require("react-dom"));
var hammerjs_1 = __importDefault(require("hammerjs"));
var RotateSvg = function () { return (react_1.default.createElement("svg", { version: "1.1", viewBox: "0 0 1024 1024", height: "22", width: "24" },
    react_1.default.createElement("path", { d: "M1464.3 279.7", "p-id": "2913", fill: "#ffffff" }),
    react_1.default.createElement("path", { d: "M512 960c-60.5 0-119.1-11.9-174.4-35.2-53.4-22.6-101.3-54.9-142.4-96s-73.4-89-96-142.4C75.9 631.1 64 572.5 64 512s11.9-119.1 35.2-174.4c22.6-53.4 54.9-101.3 96-142.4s89-73.4 142.4-96C392.9 75.9 451.5 64 512 64s119.1 11.9 174.4 35.2c53.4 22.6 101.3 54.9 142.4 96s73.4 89 96 142.4C948.1 392.9 960 451.5 960 512c0 19.1-15.5 34.6-34.6 34.6s-34.6-15.5-34.6-34.6c0-51.2-10-100.8-29.8-147.4-19.1-45.1-46.4-85.6-81.2-120.4C745 209.4 704.5 182 659.4 163c-46.7-19.7-96.3-29.8-147.4-29.8-51.2 0-100.8 10-147.4 29.8-45.1 19.1-85.6 46.4-120.4 81.2S182 319.5 163 364.6c-19.7 46.7-29.8 96.3-29.8 147.4 0 51.2 10 100.8 29.8 147.4 19.1 45.1 46.4 85.6 81.2 120.4C279 814.6 319.5 842 364.6 861c46.7 19.7 96.3 29.8 147.4 29.8 64.6 0 128.4-16.5 184.4-47.8 54.4-30.4 100.9-74.1 134.6-126.6 10.3-16.1 31.7-20.8 47.8-10.4 16.1 10.3 20.8 31.7 10.4 47.8-39.8 62-94.8 113.7-159.1 149.6-66.2 37-141.7 56.6-218.1 56.6z", "p-id": "2914", fill: "#ffffff" }),
    react_1.default.createElement("path", { d: "M924 552c-19.8 0-36-16.2-36-36V228c0-19.8 16.2-36 36-36s36 16.2 36 36v288c0 19.8-16.2 36-36 36zM275.4 575.5c9.5-2.5 19.1 2.9 22.3 12.2 3.5 10.2 9.9 17.7 19.1 22.6 7.1 3.9 15.1 5.8 24 5.8 16.6 0 30.8-6.9 42.5-20.8 11.7-13.8 20-32.7 24.9-75.1-7.7 12.2-17.3 20.8-28.7 25.8-11.4 5-23.7 7.4-36.8 7.4-26.7 0-47.7-8.3-63.3-24.9-15.5-16.6-23.3-37.9-23.3-64.1 0-25.1 7.7-47.1 23-66.2 15.3-19 37.9-28.6 67.8-28.6 40.3 0 68.1 18.1 83.4 54.4 8.5 19.9 12.7 44.9 12.7 74.9 0 33.8-5.1 63.8-15.3 89.9-16.9 43.5-45.5 65.2-85.8 65.2-27 0-47.6-7.1-61.6-21.2-10-10.1-16.4-22-19.3-35.8-2-9.6 4-19.1 13.5-21.6l0.9 0.1z m103-74.4c9.4-7.5 14.1-20.6 14.1-39.3 0-16.8-4.2-29.3-12.7-37.5S360.6 412 347.5 412c-14 0-25.2 4.7-33.4 14.1-8.2 9.4-12.4 22-12.4 37.7 0 14.9 3.6 26.7 10.9 35.5 7.2 8.8 18.8 13.1 34.6 13.1 11.4 0 21.8-3.8 31.2-11.3zM646.6 414.4c12.4 22.8 18.5 54 18.5 93.7 0 37.6-5.6 68.7-16.8 93.3-16.2 35.3-42.8 52.9-79.6 52.9-33.2 0-57.9-14.4-74.2-43.3-13.5-24.1-20.3-56.4-20.3-97 0-31.4 4.1-58.4 12.2-80.9 15.2-42 42.7-63 82.5-63 35.9 0 61.8 14.8 77.7 44.3z m-40.2 173.3c9.4-13.9 14-39.9 14-78 0-27.4-3.4-50-10.1-67.7-6.8-17.7-19.9-26.6-39.4-26.6-17.9 0-31 8.4-39.3 25.2-8.3 16.8-12.4 41.6-12.4 74.3 0 24.6 2.6 44.4 7.9 59.4 8.1 22.8 22 34.3 41.6 34.3 15.7 0 28.3-7 37.7-20.9zM803.3 387.2c11.2 11.3 16.8 25 16.8 41.2 0 16.7-5.8 30.7-17.5 41.8C791 481.4 777.4 487 762 487c-17.1 0-31.2-5.8-42.1-17.4-10.9-11.6-16.4-25.1-16.4-40.6 0-16.5 5.8-30.4 17.3-41.7 11.5-11.3 25.3-17 41.2-17 16.3 0 30.1 5.7 41.3 16.9zM739.5 451c6.2 6.2 13.7 9.3 22.5 9.3 8.4 0 15.8-3.1 22.1-9.3 6.3-6.2 9.4-13.7 9.4-22.6 0-8.5-3.1-15.9-9.3-22.1-6.2-6.2-13.6-9.3-22.2-9.3s-16.1 3.1-22.4 9.3c-6.3 6.2-9.4 13.7-9.4 22.6-0.1 8.4 3 15.8 9.3 22.1z", "p-id": "2915", fill: "#ffffff" }))); };
var PreviewImage = /** @class */ (function (_super) {
    __extends(PreviewImage, _super);
    function PreviewImage(props) {
        var _this = _super.call(this, props) || this;
        _this.state = {
            scale: 1,
            rotate: 0
        };
        _this.tMatrix = [1, 0, 0, 1, 0, 0]; //x缩放，无，无，y缩放，x平移，y平移
        _this.initialScal = {
            nowScale: 1,
            lastScale: 1,
            lastTranslate: {
                x: 0,
                y: 0
            },
            pointCenter: {
                x: 0,
                y: 0
            },
            lastCenter: {
                x: 0,
                y: 0
            }
        };
        _this.scale = 1;
        _this.rotate = 0;
        //public center = this.initialScal.lastCenter
        //public pointXY = (x: number,y: number) => {return {x,y}}
        _this.componentDidMount = function () {
            if (_this.slider) {
                _this.slider.onclick = function () {
                    _this.closeCarouel();
                };
            }
            if (_this.pinch) {
                _this.hammertime = new hammerjs_1.default(_this.pinch, { touchAction: 'pan-x pan-y' });
                _this.hammertime.get('pinch').set({ enable: true });
                //this.center = this.initialScal.lastCenter = this.pointXY(this.pinch.offsetWidth/2, this.pinch.offsetHeight/2)
                var preScale_1 = 0;
                //双指开始前
                _this.hammertime.on('pinchstart', function (e) {
                    console.log('双指开始前', e);
                    preScale_1 = _this.scale;
                    //this.initialScal.lastTranslate = this.pointXY(this.tMatrix[4], this.tMatrix[5]) //获取元素的偏移值
                    // this.setState({
                    //   scale: this.tMatrix[0] || 1
                    // })
                    //this.initialScal.pointCenter = this.pointXY(e.center.x, e.center.y)
                });
                //双指移动
                _this.hammertime.on('pinchmove', function (e) {
                    console.log('双指移动', e);
                    //this.initialScal.nowScale = this.state.scale * e.scale;
                    var scale = preScale_1 * e.scale;
                    if (scale < 0.3 || scale > 3)
                        return;
                    _this.scale = scale;
                    // window.requestAnimationFrame(() => {
                    setTimeout(function () {
                        _this.pinch.children[0].style.transform = "scale(" + _this.scale + ") rotate(" + _this.rotate + "deg)";
                    }, 15);
                    // console.log(this.pinch)
                    // })
                    // setTimeout(() => { this.setState({ scale: preScale * e.scale }) }, 1000 / 60)
                });
            }
        };
        _this.componentWillUnmount = function () {
            var _a;
            (_a = _this.hammertime) === null || _a === void 0 ? void 0 : _a.remove('pinch');
        };
        _this.closeCarouel = function () {
            _this.props.onCloseCarouel(false);
        };
        _this.next = function () {
            _this.slider.next();
        };
        _this.prev = function () {
            _this.slider.prev();
        };
        /**
         * roatate旋转
         */
        _this.roatate = function () {
            var rotate = _this.rotate + 90;
            _this.rotate = rotate === 360 ? 0 : rotate;
            _this.pinch && (_this.pinch.children[0].style.transform = "scale(" + _this.scale + ") rotate(" + _this.rotate + "deg)");
            // this.setState({
            //   rotate: rotate > 360 ? 0 : rotate
            // })
        };
        _this.state = {
            scale: 1,
            rotate: 0
        };
        return _this;
    }
    PreviewImage.prototype.render = function () {
        var _this = this;
        return (react_1.default.createElement("div", { className: "previewImage" }, this.props.isEmbedded ? react_1.default.createElement("div", { className: "embedded-wrap" },
            react_1.default.createElement("div", { className: "embedded-img", ref: function (el) { _this.pinch = el; } },
                react_1.default.createElement("img", { src: this.props.carouelList, alt: "" })),
            react_1.default.createElement("div", { className: "embedded-foot" },
                react_1.default.createElement(button_1.default, { onClick: this.roatate, ghost: true },
                    react_1.default.createElement(icon_1.default, { component: RotateSvg }),
                    "\u65CB\u8F6C"),
                react_1.default.createElement(button_1.default, { type: "primary", onClick: function () { _this.props.onCloseCarouel(false); } }, "\u9000\u51FA\u9884\u89C8"))) : react_1.default.createElement(react_1.default.Fragment, null,
            react_1.default.createElement(carousel_1.default, { ref: function (el) {
                    console.log(el);
                    _this.slider = el;
                    react_dom_1.default.findDOMNode(el) !== null ? react_dom_1.default.findDOMNode(el).onclick = function () {
                        _this.closeCarouel();
                    } : console.log(el);
                }, dots: false, className: "preview-carousel", initialSlide: this.props.carouelIndex, arrows: true }, this.props.carouelList && this.props.carouelList.map(function (item, index) {
                return (react_1.default.createElement("div", { onClick: _this.closeCarouel, key: index, className: "item-img", style: { position: 'relative' } },
                    react_1.default.createElement("img", { src: item, alt: "\u9884\u89C8\u7684\u56FE" })));
            })),
            react_1.default.createElement(icon_1.default, { type: "left-circle", theme: "filled", className: "left-circle", onClick: this.prev }),
            react_1.default.createElement(icon_1.default, { type: "right-circle", theme: "filled", className: "right-circle", onClick: this.next }))));
    };
    return PreviewImage;
}(react_1.Component));
exports.default = PreviewImage;
