import { Component } from 'react';
import 'antd/es/carousel/style';
import 'antd/es/icon/style';
import './previewImage.less';
interface IPROP {
    carouelList: any;
    onCloseCarouel: Function;
    carouelIndex?: number;
    isEmbedded?: boolean;
}
export default class PreviewImage extends Component<IPROP, {}> {
    constructor(props: IPROP);
    readonly state: {
        scale: number;
        rotate: number;
    };
    slider: any;
    pinch: any;
    hammertime: any;
    tMatrix: number[];
    initialScal: {
        nowScale: number;
        lastScale: number;
        lastTranslate: {
            x: number;
            y: number;
        };
        pointCenter: {
            x: number;
            y: number;
        };
        lastCenter: {
            x: number;
            y: number;
        };
    };
    scale: number;
    rotate: number;
    componentDidMount: () => void;
    componentWillUnmount: () => void;
    closeCarouel: () => void;
    next: () => void;
    prev: () => void;
    /**
     * roatate旋转
     */
    roatate: () => void;
    render(): JSX.Element;
}
export {};
