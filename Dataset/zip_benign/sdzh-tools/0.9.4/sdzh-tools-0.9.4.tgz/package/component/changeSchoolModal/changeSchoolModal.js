"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
var react_1 = __importDefault(require("react"));
var modal_1 = __importDefault(require("antd/es/modal"));
require("antd/es/form/style");
require("./changeSchoolModal.less");
var tooltip_1 = __importDefault(require("antd/es/tooltip"));
require("antd/es/tooltip/style");
var icon_1 = __importDefault(require("antd/es/icon"));
var __1 = require("../..");
var AddSvg = function () { return (react_1.default.createElement("svg", { version: "1.1", viewBox: "0 0 58 58", height: "58", width: "58" },
    react_1.default.createElement("g", { id: "\u9875\u9762-1", stroke: "none", strokeWidth: "1", fill: "none", fillRule: "evenodd" },
        react_1.default.createElement("g", { id: "\u5207\u6362\u5B66\u6821", transform: "translate(-1103.000000, -453.000000)", fill: "#517EFF", fillRule: "nonzero" },
            react_1.default.createElement("g", { id: "\u5206\u7EC4-9", transform: "translate(636.000000, 316.000000)" },
                react_1.default.createElement("g", { id: "\u5206\u7EC4-10" },
                    react_1.default.createElement("path", { d: "M492,162 L492,141 C492,138.790861 493.790861,137 496,137 C498.209139,137 500,138.790861 500,141 L500,162 L521,162 C523.209139,162 525,163.790861 525,166 C525,168.209139 523.209139,170 521,170 L500,170 L500,191 C500,193.209139 498.209139,195 496,195 C493.790861,195 492,193.209139 492,191 L492,170 L471,170 C468.790861,170 467,168.209139 467,166 C467,163.790861 468.790861,162 471,162 L492,162 Z", id: "\u5408\u5E76\u5F62\u72B6", fill: "#517EFF" }))))))); };
var checkMark = function () { return (react_1.default.createElement("svg", { version: "1.1", xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 512 512" },
    react_1.default.createElement("g", { id: "icomoon-ignore", fill: "#ffffff" }),
    react_1.default.createElement("path", { d: "M432 64l-240 240-112-112-80 80 192 192 320-320z", fill: "#ffffff" }))); };
var ChangeSchoolModal = (function (_a) {
    var visible = _a.visible, onCancel = _a.onCancel, schoolList = _a.schoolList, createSchool = _a.createSchool;
    return (react_1.default.createElement(modal_1.default, { title: null, footer: null, centered: true, visible: visible, closable: false, wrapClassName: 'change-school-modal', width: 'unset', onCancel: function (e) { onCancel(false); } },
        react_1.default.createElement("div", { className: 'change-school-modal-content' },
            react_1.default.createElement("p", null,
                "\u5207\u6362\u5B66\u6821",
                react_1.default.createElement(tooltip_1.default, { title: "\u652F\u6301\u52A0\u5165\u6216\u521B\u5EFA\u591A\u4E2A\u5B66\u6821\u7684\u64CD\u4F5C\uFF0C\u5355\u51FB\u5207\u6362\u5B66\u6821", overlayClassName: "tool-question" },
                    react_1.default.createElement(icon_1.default, { type: "question-circle" }))),
            react_1.default.createElement("div", { className: "school-list" },
                schoolList && schoolList.map(function (item) {
                    return (react_1.default.createElement("div", { className: "school-item " + (item.domain === window.location.host && 'current-school'), key: item.id },
                        react_1.default.createElement("a", { key: item.school_id, className: "router-link", href: "http://" + item.domain + "/profile?token=" + __1.HEADERS.Authorization },
                            react_1.default.createElement("p", null, item.school_name),
                            react_1.default.createElement("div", null,
                                react_1.default.createElement("img", { src: item.icon || 'http://imotunkt.oss-cn-shenzhen.aliyuncs.com/imotun/schoolLogoMgt/%E6%9C%AA%E6%A0%87%E9%A2%98-1%20%E4%B8%8A%E5%8D%8811.47.47.png' }),
                                react_1.default.createElement("img", { src: item.word_icon || 'http://imotunkt.oss-cn-shenzhen.aliyuncs.com/imotun/schoolLogoMgt/%E6%9C%AA%E6%A0%87%E9%A2%98-1.png' }))),
                        item.domain === window.location.host && react_1.default.createElement(react_1.default.Fragment, null,
                            react_1.default.createElement("div", { className: "school-check" }),
                            react_1.default.createElement(icon_1.default, { className: "school-check-mark", component: checkMark }))));
                }),
                react_1.default.createElement("div", { className: 'create-school', onClick: function () { createSchool(true); onCancel(false); } },
                    react_1.default.createElement(icon_1.default, { component: AddSvg }),
                    react_1.default.createElement("p", null, "\u521B\u5EFA\u5B66\u6821"))))));
});
exports.default = react_1.default.memo(ChangeSchoolModal, function (prevProps, nextProps) {
    if (prevProps.visible !== nextProps.visible || prevProps.schoolList !== nextProps.schoolList)
        return false;
    return true;
});
