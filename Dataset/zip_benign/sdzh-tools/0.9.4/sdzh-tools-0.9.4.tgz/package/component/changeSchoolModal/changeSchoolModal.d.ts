import React from 'react';
import 'antd/es/form/style';
import './changeSchoolModal.less';
import 'antd/es/tooltip/style';
interface formPorps {
    visible: boolean | undefined;
    onCancel?: any;
    schoolList: any;
    createSchool: any;
}
declare const _default: React.MemoExoticComponent<({ visible, onCancel, schoolList, createSchool }: formPorps) => JSX.Element>;
export default _default;
