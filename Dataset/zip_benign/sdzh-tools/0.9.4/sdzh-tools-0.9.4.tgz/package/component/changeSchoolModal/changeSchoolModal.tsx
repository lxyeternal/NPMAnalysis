import React from 'react';
import Modal from 'antd/es/modal';
import 'antd/es/form/style'
import './changeSchoolModal.less'
import Tooltip from 'antd/es/tooltip'
import 'antd/es/tooltip/style'
import Icon  from 'antd/es/icon';
import { HEADERS } from '../..';
interface formPorps {
  visible: boolean | undefined;
  onCancel?: any;
  schoolList: any;
  createSchool: any;
}
const AddSvg = () => (
  <svg version="1.1" viewBox="0 0 58 58" height="58" width="58">
    <g id="页面-1" stroke="none" strokeWidth="1" fill="none" fillRule="evenodd">
      <g id="切换学校" transform="translate(-1103.000000, -453.000000)" fill="#517EFF" fillRule="nonzero">
        <g id="分组-9" transform="translate(636.000000, 316.000000)">
          <g id="分组-10">
            <path d="M492,162 L492,141 C492,138.790861 493.790861,137 496,137 C498.209139,137 500,138.790861 500,141 L500,162 L521,162 C523.209139,162 525,163.790861 525,166 C525,168.209139 523.209139,170 521,170 L500,170 L500,191 C500,193.209139 498.209139,195 496,195 C493.790861,195 492,193.209139 492,191 L492,170 L471,170 C468.790861,170 467,168.209139 467,166 C467,163.790861 468.790861,162 471,162 L492,162 Z" id="合并形状" fill="#517EFF"></path>
          </g>
        </g>
      </g>
    </g>
  </svg>
)

const checkMark = () => (
  <svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 512 512">
    <g id="icomoon-ignore" fill="#ffffff">
    </g>
    <path d="M432 64l-240 240-112-112-80 80 192 192 320-320z" fill="#ffffff"></path>
  </svg>
)

const ChangeSchoolModal = (({ visible, onCancel, schoolList, createSchool }: formPorps) => {
  return (
    <Modal
      title={null}
      footer={null}
      centered
      visible={visible}
      closable={false}
      wrapClassName='change-school-modal'
      width={'unset'}
      onCancel={(e: any) => { onCancel(false) }}
    >
      <div className='change-school-modal-content'>
        <p>切换学校<Tooltip title="支持加入或创建多个学校的操作，单击切换学校" overlayClassName="tool-question"><Icon type="question-circle" /></Tooltip></p>
        <div className="school-list">
          {
            schoolList && schoolList.map((item: any) => {
              return (
                <div className={`school-item ${item.domain === window.location.host && 'current-school'}`} key={item.id}>
                  <a
                    key={item.school_id}
                    className="router-link"
                    href={`http://${item.domain}/profile?token=${HEADERS.Authorization}`}
                  >
                    <p>{item.school_name}</p>
                    <div>
                      <img src={item.icon || 'http://imotunkt.oss-cn-shenzhen.aliyuncs.com/imotun/schoolLogoMgt/%E6%9C%AA%E6%A0%87%E9%A2%98-1%20%E4%B8%8A%E5%8D%8811.47.47.png'}></img>
                      <img src={item.word_icon || 'http://imotunkt.oss-cn-shenzhen.aliyuncs.com/imotun/schoolLogoMgt/%E6%9C%AA%E6%A0%87%E9%A2%98-1.png'}></img>
                    </div>
                  </a>
                  {
                    item.domain === window.location.host && <>
                      <div className="school-check"></div>
                      <Icon className="school-check-mark" component={checkMark}></Icon>
                    </>
                  }
                </div>
              )
            })
          }
          <div className='create-school' onClick={() => { createSchool(true); onCancel(false) }}>
            <Icon component={AddSvg}></Icon>
            <p>创建学校</p>
          </div>
        </div>
      </div>
    </Modal>
  )
})

export default React.memo(ChangeSchoolModal, (prevProps: formPorps, nextProps: formPorps) => {
  if (prevProps.visible !== nextProps.visible || prevProps.schoolList !== nextProps.schoolList) return false
  return true
});