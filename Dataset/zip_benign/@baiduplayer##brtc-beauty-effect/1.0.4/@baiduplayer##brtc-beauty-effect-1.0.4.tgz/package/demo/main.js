window.onload = ()=>{
  let video = document.getElementById("beautyVideo");
  let beautyEffect = null;
  let localStream = null;
  let newStream = null
  start();
  async function start(){
     beautyEffect = new BRTCBeautyEffect();
     localStream = await getLcalStream();
     if(localStream){
      newStream = await beautyEffect.getBeautyStream(localStream)
       video.srcObject = newStream;
       video.play();
       start_brtc_with_stream(newStream);
     }
   }
   function getLcalStream(){
      return new Promise((resolve)=>{
        navigator.mediaDevices.getUserMedia({
          video: {
            width : {max: 1280,min:1280},
            height : {min:720,max:720},
          },
          audio: false,
        })
        .then(async(stream) => {
           resolve(stream)
       });
      });
   }
   // 设置美颜特效
   let beautyEffectArray = [
     "Lightening",
     "Smoothness",
     "Sharpness",
     "Redness",
     "Contrast",
   ];
   beautyEffectArray.forEach((val) => {
     let documentVal = document.getElementById(val + "Beauty");
     documentVal.onchange = () => {
       let param = {
         [val.toLocaleLowerCase()]: documentVal.value,
       }
       beautyEffect.setOptions(param);
     };
   });
 document.getElementById("start").onclick = () => {
  destroy();
  start();
 }
// 开启
 document.getElementById("enableBeauty").onclick = () => {
   beautyEffect.enable();
 };
 // 关闭
 document.getElementById("disableBeauty").onclick = () => {
   beautyEffect.disable();
 };
 document.getElementById("getoptions").onclick = () => {
   console.log(beautyEffect.getOptions(),'getoptions');
 };
 // 销毁 
 document.getElementById("destroy").onclick = () => {
   destroy()
 }
 function destroy(){  
  if(newStream && newStream.getTracks){
    newStream.getTracks().forEach(track => {
      track.stop();
    })
  }
   beautyEffect && beautyEffect.destroy && beautyEffect.destroy();
   beautyEffect = null;
   localStream = null;
   stopBrtc();
 }

function GetRequest() {
  var url = window.location.search;
  var theRequest = new Object();
    if (url.indexOf("?") != -1) {
      var str = url.substr(1);
      var strs = str.split("&");
      for(var i = 0; i < strs.length; i ++) {
          theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
      }
    }
  return theRequest;
}
var gRequest = GetRequest();

gRequest['brtcserver'] = gRequest['brtcserver'] || gRequest['s'];
gRequest['appid'] = gRequest['appid'] || gRequest['a'];
gRequest['roomname'] = gRequest['roomname'] || gRequest['r'];
gRequest['display'] = gRequest['display'] || gRequest['d'];

if (!gRequest['appid'] || !gRequest['roomname']) {
  console.log('warning: for BRTC, URL should: https://xxx?a=get_appid_from_baidu&r=roomname');
}

function start_brtc_with_stream(s) {
  if (!gRequest['appid'] || !gRequest['roomname']) {
    // need appid and roomname for BRTC.
    return;
  }

  window.BRTC_Start({
    server: gRequest["brtcserver"] || 'wss://rtc.exp.bcelive.com/janus',
    appid: gRequest["appid"],
    token: "notoken",
    roomname: gRequest["roomname"],
    userid: "100" + Math.floor(Math.random() * 1000000).toString(),
    displayname: gRequest["display"] || 'Beauty-effect',
    localvideoviewid: "herevideo",
    usingvideo: true,
    usingaudio: true,
    stream: s,
    aspublisher: true,
    autosubscribe: false,
    autoresubscribing: false,
    userevent: true,
    userevent_joinedroom: function (id, display, attribute) {
      console.log('userevent_joinedroom id: ' + id
        + ', display: ' + display + ', attribute:' + attribute);
    },
    userevent_leavingroom: function (id, display) {
      console.log('userevent_leavingroom id: ' + id + ', display: ' + display);
    },
    remotevideocoming: function(id,display,attribute) {
        console.log('remotevideocoming, feedid:'+ id + ':' + display + ':' + attribute);
        var v_id = 'room1v' + id;
        if (!document.getElementById(v_id)) {
          var divEle = document.createElement("div");
          divEle.id = v_id;
          divEle.style = 'width: 320px;height: 180px;display: inline-block;';
          document.body.appendChild(divEle);
        }

        window.BRTC_SubscribeStreaming(v_id, id);
    },
    remotevideoleaving: function(id) {
      console.log("remotevideoleaving, feedid:"+ id);
      document.getElementById('room1v' + id)?.remove();
    },
    remotevideounpublished: function(id) {
      console.log("remotevideounpublished, feedid:"+ id);
    },
    remotevideoloading: function(idx) {
      console.log("remotevideoloading, index:"+ idx);
    },
    remotevideoon: function(idx) {
      console.log("remotevideoon, index:"+ idx);
    },
    remotevideooff: function(idx) {
      console.log("remotevideooff, index:"+ idx);
    },
  });
}
function stopBrtc() {
  window.BRTC_Stop();
}
}