module.export = {
  presets: ['@babel/env'],
  plugins: ['@babel/plugin-syntax-class-properties'],
};
