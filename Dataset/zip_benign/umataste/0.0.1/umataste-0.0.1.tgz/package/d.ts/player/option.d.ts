import BufferingStrategy from "../buffering/buffering-strategy";
import Decoder from "../decoder/decoder";
import Source from "../source/source";
export declare type PlayerOption = {
    source: Source;
    decoder: Decoder;
    buffering: BufferingStrategy;
    baseTimeSyncType: 'vide' | 'soun';
};
//# sourceMappingURL=option.d.ts.map