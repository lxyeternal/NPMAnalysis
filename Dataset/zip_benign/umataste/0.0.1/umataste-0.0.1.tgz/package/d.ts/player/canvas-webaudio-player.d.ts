import { Events } from '../event/events';
import { PlayerOption } from './option';
export default class MSEPlayer {
    private emitter;
    private source;
    private decoder;
    private buffering;
    private canvas;
    private audio;
    private audioSourceQueue;
    private audioStalled;
    private initData;
    private baseTime;
    private baseTimeSyncType;
    private readonly onInitSegmentRecievedHandler;
    private readonly onFragmentRecievedHandler;
    private readonly onAudioBufferSouceEndHandler;
    private readonly onVideoFrameDecodedHandler;
    private readonly onAudioFrameDecodedHandler;
    constructor(option?: PlayerOption);
    load(url: string): Promise<boolean>;
    attachCanvas(canvas: HTMLCanvasElement): void;
    attachAudioContext(AudioContext: AudioContext): void;
    private onInitSegmentRecieved;
    private onFragmentRecieved;
    private abort;
    private clean;
    private unload;
    stop(): void;
    on<T extends keyof Events>(type: T, handler: ((payload: Events[T]) => void)): void;
    off<T extends keyof Events>(type: T, handler: ((payload: Events[T]) => void)): void;
    private pushVideoFrame;
    private pushAudioFrame;
    private onAudioBufferSouceEnd;
    private onVideoFrameDecoded;
    private onAudioFrameDecoded;
}
//# sourceMappingURL=canvas-webaudio-player.d.ts.map