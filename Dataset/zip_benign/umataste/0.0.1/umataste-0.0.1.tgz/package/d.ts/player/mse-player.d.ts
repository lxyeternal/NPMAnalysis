import { Events } from '../event/events';
import { PlayerOption } from './option';
export default class MSEPlayer {
    private emitter;
    private source;
    private media;
    private mediaSource;
    private mediaSourceUrl;
    private sourceBufferQueue;
    private initData;
    private baseTime;
    private readonly onInitSegmentRecievedHandler;
    private readonly onFragmentRecievedHandler;
    constructor(option?: PlayerOption);
    load(url: string): Promise<boolean>;
    attachMedia(media: HTMLMediaElement): void;
    private onInitSegmentRecieved;
    private onFragmentRecieved;
    private abort;
    private clean;
    private unload;
    stop(): void;
    on<T extends keyof Events>(type: T, handler: ((payload: Events[T]) => void)): void;
    off<T extends keyof Events>(type: T, handler: ((payload: Events[T]) => void)): void;
}
//# sourceMappingURL=mse-player.d.ts.map