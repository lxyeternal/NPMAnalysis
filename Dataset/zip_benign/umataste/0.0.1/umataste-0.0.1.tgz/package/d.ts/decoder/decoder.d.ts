import { InitData } from "../demux/init/index";
import EventEmitter from "../event/eventemitter";
export default abstract class Decoder {
    abstract setEmitter(emitter: EventEmitter): void;
    abstract initVideoDecoder(init: InitData): Promise<void>;
    abstract initAudioDecoder(init: InitData): Promise<void>;
}
//# sourceMappingURL=decoder.d.ts.map