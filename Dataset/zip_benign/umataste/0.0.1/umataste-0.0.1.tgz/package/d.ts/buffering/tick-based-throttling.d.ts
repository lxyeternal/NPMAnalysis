import BufferingStrategy from "./buffering-strategy";
import EventEmitter from "../event/eventemitter";
declare type TickBasedThrottlingOptions = {
    emitFirstFrameOnly?: boolean;
    audioBasedLipsync?: boolean;
    tickHz?: number;
};
export default class TickBasedThrottling extends BufferingStrategy {
    private emitter;
    private options;
    private ticker;
    private readonly onH264ParsedHandler;
    private readonly onAACParsedHandler;
    private readonly onTickerTickHandler;
    private h264Queue;
    private soundBufferingTime;
    private soundStalledTime;
    private startTimestamp;
    private lastTimestamp;
    static isSupported(): boolean;
    constructor(options?: TickBasedThrottlingOptions);
    setEmitter(emitter: EventEmitter): void;
    start(): void;
    abort(): void;
    destroy(): void;
    private onH264Parsed;
    private onAACParsed;
    private onTickerTick;
    private onTick;
}
export {};
//# sourceMappingURL=tick-based-throttling.d.ts.map