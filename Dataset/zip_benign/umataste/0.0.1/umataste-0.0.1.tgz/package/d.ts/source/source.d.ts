import EventEmitter from '../event/eventemitter';
export default abstract class Source {
    abstract setEmitter(emitter: EventEmitter): void;
    abstract abort(): void;
    abstract load(url: string): Promise<boolean>;
}
//# sourceMappingURL=source.d.ts.map