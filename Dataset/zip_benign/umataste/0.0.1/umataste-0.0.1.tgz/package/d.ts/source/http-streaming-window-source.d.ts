import EventEmitter from '../event/eventemitter';
import Source from "./source";
export default class HTTPStreamingWindowSource extends Source {
    private fetchReader;
    private abortController;
    private emitter;
    private boxQueue;
    private init;
    private sidx;
    private moof;
    constructor();
    static isSupported(): boolean;
    setEmitter(emitter: EventEmitter): void;
    abort(): void;
    load(url: string): Promise<boolean>;
    private pump;
}
//# sourceMappingURL=http-streaming-window-source.d.ts.map