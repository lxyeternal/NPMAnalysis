import EventEmitter from '../event/eventemitter';
import Source from "./source";
export default class HTTPStreamingWindowSource extends Source {
    private socket;
    private abortController;
    private emitter;
    private readonly onErrorHandler;
    private readonly onMessageHandler;
    private boxQueue;
    private init;
    private sidx;
    private moof;
    constructor();
    static isSupported(): boolean;
    setEmitter(emitter: EventEmitter): void;
    abort(): void;
    load(url: string): Promise<boolean>;
    private onError;
    private onMessage;
}
//# sourceMappingURL=websocket-streaming-window-source.d.ts.map