/// <reference types="dom-webcodecs" />
export declare const EventTypes: {
    readonly INIT_SEGMENT_RECIEVED: "INIT_SEGMENT_RECIEVED";
    readonly FRAGMENT_RECIEVED: "FRAGMENT_RECIEVED";
    readonly H264_PARSED: "H264_PARSED";
    readonly AAC_PARSED: "AAC_PARSED";
    readonly H264_EMITTED: "H264_EMITTED";
    readonly AAC_EMITTED: "AAC_EMITTED";
    readonly VIDEO_FRAME_DECODED: "VIDEO_FRAME_DECODED";
    readonly AUDIO_FRAME_DECODED: "AUDIO_FRAME_DECODED";
    readonly VIDEO_DECODE_ERROR: "VIDEO_DECODE_ERROR";
    readonly AUDIO_DECODE_ERROR: "AUDIO_DECODE_ERROR";
};
export declare type INIT_SEGMENT_RECIEVED_PAYLOAD = {
    event: typeof EventTypes.INIT_SEGMENT_RECIEVED;
    adaptation_id: number;
    init: ArrayBuffer;
};
export declare type FRAGMENT_RECIEVED_PAYLOAD = {
    event: typeof EventTypes.FRAGMENT_RECIEVED;
    adaptation_id: number;
    sidx: ArrayBuffer[];
    fragment: ArrayBuffer;
};
export declare type H264_PARSED_PAYLOAD = {
    event: typeof EventTypes.H264_PARSED;
    timestamp: number;
    isIDR: boolean;
    payload: ArrayBuffer;
};
export declare type AAC_PARSED_PAYLOAD = {
    event: typeof EventTypes.AAC_PARSED;
    timestamp: number;
    duration: number;
    payload: ArrayBuffer;
};
export declare type H264_EMITTED_PAYLOAD = {
    event: typeof EventTypes.H264_EMITTED;
    timestamp: number;
    isIDR: boolean;
    payload: ArrayBuffer;
};
export declare type AAC_EMITTED_PAYLOAD = {
    event: typeof EventTypes.AAC_EMITTED;
    timestamp: number;
    duration: number;
    payload: ArrayBuffer;
};
export declare type VIDEO_FRAME_DECODED_PAYLOAD = {
    event: typeof EventTypes.VIDEO_FRAME_DECODED;
    frame: VideoFrame;
};
export declare type AUDIO_FRAME_DECODED_PAYLOAD = {
    event: typeof EventTypes.AUDIO_FRAME_DECODED;
    frame: AudioData;
};
export declare type VIDEO_DECODE_ERROR_PAYLOAD = {
    event: typeof EventTypes.VIDEO_DECODE_ERROR;
    error: unknown;
};
export declare type AUDIO_DECODE_ERROR_PAYLOAD = {
    event: typeof EventTypes.AUDIO_DECODE_ERROR;
    error: unknown;
};
export declare type Events = {
    [EventTypes.INIT_SEGMENT_RECIEVED]: INIT_SEGMENT_RECIEVED_PAYLOAD;
    [EventTypes.FRAGMENT_RECIEVED]: FRAGMENT_RECIEVED_PAYLOAD;
    [EventTypes.H264_PARSED]: H264_PARSED_PAYLOAD;
    [EventTypes.AAC_PARSED]: AAC_PARSED_PAYLOAD;
    [EventTypes.H264_EMITTED]: H264_EMITTED_PAYLOAD;
    [EventTypes.AAC_EMITTED]: AAC_EMITTED_PAYLOAD;
    [EventTypes.VIDEO_FRAME_DECODED]: VIDEO_FRAME_DECODED_PAYLOAD;
    [EventTypes.AUDIO_FRAME_DECODED]: AUDIO_FRAME_DECODED_PAYLOAD;
    [EventTypes.VIDEO_DECODE_ERROR]: VIDEO_DECODE_ERROR_PAYLOAD;
    [EventTypes.AUDIO_DECODE_ERROR]: AUDIO_DECODE_ERROR_PAYLOAD;
};
//# sourceMappingURL=events.d.ts.map