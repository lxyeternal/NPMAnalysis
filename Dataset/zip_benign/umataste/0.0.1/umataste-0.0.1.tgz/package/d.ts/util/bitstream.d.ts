export declare class BitStream {
    private bits;
    private data;
    private offset;
    constructor(data: ArrayBuffer);
    empty(): boolean;
    bitLength(): number;
    private fill;
    private peek;
    skipBits(length: number): void;
    readBits(length: number): number;
    readBool(): boolean;
}
//# sourceMappingURL=bitstream.d.ts.map