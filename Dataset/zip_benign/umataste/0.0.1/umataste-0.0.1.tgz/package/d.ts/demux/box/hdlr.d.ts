import { Box } from "./box";
export declare type Hdlr = {
    version: number;
    flags: number;
    handler_type: string;
    name: string;
};
export declare const parseHdlr: (arraybuffer: ArrayBuffer, hdlr: Box) => Hdlr;
//# sourceMappingURL=hdlr.d.ts.map