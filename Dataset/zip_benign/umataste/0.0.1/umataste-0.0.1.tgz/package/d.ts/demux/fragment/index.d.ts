import { InitData } from "../init/index";
export declare const getFragmentData: (arraybuffer: ArrayBuffer, initData: InitData[]) => {
    base_media_decode_time: number;
    sample_duration: number;
    duration: number;
    track: InitData;
    data_offset: number | undefined;
}[][];
export declare const getBaseTime: (arraybuffer: ArrayBuffer, initData: InitData[]) => {
    base_media_decode_time: number;
    track_id: number;
}[];
export declare const adjustBaseTime: (arraybuffer: ArrayBuffer, initData: InitData[], baseTime: number) => void;
//# sourceMappingURL=index.d.ts.map