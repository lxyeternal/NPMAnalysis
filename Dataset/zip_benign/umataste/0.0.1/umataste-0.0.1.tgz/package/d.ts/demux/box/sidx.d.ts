import { Box } from "./box";
declare type Entry = {
    reference_type: number;
    referenced_size: number;
    sub_segment_duration: number;
    starts_with_SAP: number;
    SAP_type: number;
    SAP_delta_time: number;
};
export declare type Sidx = {
    version: number;
    flags: number;
    reference_id: number;
    timescale: number;
    earliest_presentation_time: number;
    first_offset: number;
    entries: Entry[];
};
export declare const parseSidx: (arraybuffer: ArrayBuffer, sidx: Box) => Sidx;
export {};
//# sourceMappingURL=sidx.d.ts.map