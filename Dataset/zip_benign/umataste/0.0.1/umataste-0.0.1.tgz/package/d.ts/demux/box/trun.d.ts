import { Box } from "./box";
declare type Entry = {
    sample_duration?: number;
    sample_size?: number;
    sample_flags?: number;
    sample_composition_time_offset?: number;
};
export declare type Trun = {
    version: number;
    flags: number;
    sample_count: number;
    data_offset?: number;
    first_sample_flag?: number;
    entries: Entry[];
};
export declare const parseTrun: (arraybuffer: ArrayBuffer, trun: Box) => Trun;
export {};
//# sourceMappingURL=trun.d.ts.map