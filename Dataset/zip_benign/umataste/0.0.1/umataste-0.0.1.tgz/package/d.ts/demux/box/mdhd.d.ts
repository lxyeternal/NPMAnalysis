import { Box } from "./box";
export declare type Mdhd = {
    version: number;
    flags: number;
    timescale: number;
};
export declare const parseMdhd: (arraybuffer: ArrayBuffer, mdhd: Box) => Mdhd;
//# sourceMappingURL=mdhd.d.ts.map