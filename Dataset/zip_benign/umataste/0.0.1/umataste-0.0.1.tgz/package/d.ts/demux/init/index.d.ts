import { Codec } from "../box/stsd";
export declare type InitData = {
    track_id: number;
    timescale: number;
    duration: number;
    handler_type: string;
    name: string;
    codec: Codec;
};
export declare const parseInitData: (arraybuffer: ArrayBuffer) => InitData[];
//# sourceMappingURL=index.d.ts.map