export default class Queue {
    private queue;
    private chunks;
    private total;
    private concat;
    push(chunk: Uint8Array): void;
    pop(): Uint8Array | undefined;
    isEmpty(): boolean;
    clear(): void;
}
//# sourceMappingURL=queue.d.ts.map