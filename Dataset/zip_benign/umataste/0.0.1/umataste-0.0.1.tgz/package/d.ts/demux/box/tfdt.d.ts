import { Box } from "./box";
export declare type Tfdt = {
    version: number;
    flags: number;
    base_media_decode_time: number;
};
export declare const parseTfdt: (arraybuffer: ArrayBuffer, tfdt: Box) => Tfdt;
//# sourceMappingURL=tfdt.d.ts.map