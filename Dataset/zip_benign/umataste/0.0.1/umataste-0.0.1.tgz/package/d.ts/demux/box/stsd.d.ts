import { Box } from "./box";
export declare type AVCCodec = {
    name: 'avc1';
    identifier: string;
    description: ArrayBuffer;
    avcC: {
        configuration_version: number;
        avc_profile_indication: number;
        profile_compatibility: number;
        avc_level_indication: number;
        nalu_length_size: number;
    };
};
export declare type MP4ACodec = {
    name: 'mp4a';
    identifier: string;
    description: ArrayBuffer;
    sampling_frequency: number;
    mp4a: {
        object_type: number;
        sampling_frequency: number;
    };
};
export declare type Codec = AVCCodec | MP4ACodec | {
    name: string;
    identifier: string;
    description: ArrayBuffer;
};
export declare type Stsd = {
    version: number;
    flags: number;
    codec: Codec;
};
export declare const parseStsd: (arraybuffer: ArrayBuffer, stsd: Box) => Stsd;
//# sourceMappingURL=stsd.d.ts.map