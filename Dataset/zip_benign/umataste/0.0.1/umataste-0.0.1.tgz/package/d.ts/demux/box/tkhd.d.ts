import { Box } from "./box";
export declare type Tkhd = {
    version: number;
    flags: number;
    track_id: number;
    duration: number;
};
export declare const parseTkhd: (arraybuffer: ArrayBuffer, tkhd: Box) => Tkhd;
//# sourceMappingURL=tkhd.d.ts.map