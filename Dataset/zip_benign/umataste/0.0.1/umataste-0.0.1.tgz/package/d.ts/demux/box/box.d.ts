export declare type Box = {
    begin: number;
    end: number;
    size: number;
    type: string;
};
export declare const parseBox: (arraybuffer: ArrayBuffer, begin?: number, end?: number | undefined) => Box;
export declare const findBox: (type: string | string[] | null, arraybuffer: ArrayBuffer, begin?: number, end?: number | undefined) => Box[];
//# sourceMappingURL=box.d.ts.map