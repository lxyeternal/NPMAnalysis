import { Box } from "./box";
export declare type Tfhd = {
    version: number;
    flags: number;
    track_id: number;
    default_sample_duration?: number;
};
export declare const parseTfhd: (arraybuffer: ArrayBuffer, tfhd: Box) => Tfhd;
//# sourceMappingURL=tfhd.d.ts.map