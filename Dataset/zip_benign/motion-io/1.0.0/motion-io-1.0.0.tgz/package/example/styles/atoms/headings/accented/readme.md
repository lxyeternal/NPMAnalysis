`.accented` is this
