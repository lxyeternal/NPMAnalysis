module.exports = {
    "status": "deprecated"
}
