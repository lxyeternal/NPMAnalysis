/**
     * Typecast a value to a String, using an empty string value for null or
     * undefined.
     */
    function toString(val){
        return val == null ? '' : val.toString();
    }

    var toString_1 = toString;

/**
     * "Convert" value into an 32-bit integer.
     * Works like `Math.floor` if val > 0 and `Math.ceil` if val < 0.
     * IMPORTANT: val will wrap at 2^31 and -2^31.
     * Perf tests: http://jsperf.com/vs-vs-parseint-bitwise-operators/7
     */
    function toInt(val){
        // we do not use lang/toNumber because of perf and also because it
        // doesn't break the functionality
        return ~~val;
    }

    var toInt_1 = toInt;

/**
     * Repeat string n times
     */
     function repeat(str, n){
         var result = '';
         str = toString_1(str);
         n = toInt_1(n);
        if (n < 1) {
            return '';
        }
        while (n > 0) {
            if (n % 2) {
                result += str;
            }
            n = Math.floor(n / 2);
            str += str;
        }
        return result;
     }

     var repeat_1 = repeat;

/**
     * Pad string with `char` if its' length is smaller than `minLen`
     */
    function lpad(str, minLen, ch) {
        str = toString_1(str);
        ch = ch || ' ';

        return (str.length < minLen) ?
            repeat_1(ch, minLen - str.length) + str : str;
    }

    var lpad_1 = lpad;

/*!
 * hex-color-regex <https://github.com/regexps/hex-color-regex>
 *
 * Copyright (c) 2015 Charlike Mike Reagent <@tunnckoCore> (http://www.tunnckocore.tk)
 * Released under the MIT license.
 */

var hexColorRegex = function hexColorRegex (opts) {
  opts = opts && typeof opts === 'object' ? opts : {};

  return opts.strict ? /^#([a-f0-9]{6}|[a-f0-9]{3})\b$/i : /#([a-f0-9]{6}|[a-f0-9]{3})\b/gi
};

var isHexcolor = function isHexcolor (hex) {
  return hexColorRegex({strict: true}).test(hex)
};

/**
 * @param  {string} originalColor
 *
 * @returns {string}
 */

function normalizeColor(originalColor) {
  var color = originalColor.replace(/^#/, '');

  if (color.length === 3) {
    return color[0] + color[0] + color[1] + color[1] + color[2] + color[2];
  }

  return color;
}
/**
 * @param  {number} decimalValue
 *
 * @returns {string}
 */


function decimalToHex(decimalValue) {
  return decimalValue.toString(16);
}
/**
 * @param  {string} hexValue
 *
 * @returns {number}
 */


function hexToDecimal(hexValue) {
  return parseInt(hexValue, 16);
}
/**
 * @param  {string} originalBaseColor
 * @param  {string} originalColorToAdjust
 * @param  {number} weight
 *
 * @returns {string}
 */


function mix(originalBaseColor, originalColorToAdjust) {
  var weight = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  var color = [];

  if (!isHexcolor(originalBaseColor) || !isHexcolor(originalColorToAdjust)) {
    throw new TypeError('Expected color to be a valid hex color.');
  }

  var baseColor = normalizeColor(originalBaseColor);
  var colorToAdjust = normalizeColor(originalColorToAdjust);
  var colorCharacters = colorToAdjust.length - 1;

  for (var i = 0; i <= colorCharacters; i += 2) {
    var baseColorDecimal = hexToDecimal(baseColor.slice(i, i + 2));
    var colorToAdjustDecimal = hexToDecimal(colorToAdjust.slice(i, i + 2));
    var value = lpad_1(decimalToHex(Math.round(colorToAdjustDecimal + (baseColorDecimal - colorToAdjustDecimal) * (weight * 100 / 100))), 2, '0');
    color.push(value);
  }

  var hexColor = color.join('');
  return "#".concat(hexColor);
}

function tint(color, percent) {
  return mix('#fff', color, percent);
}

function shade(color, percent) {
  return mix('#000', color, percent);
}

export { shade, tint };
//# sourceMappingURL=index.esm.js.map
