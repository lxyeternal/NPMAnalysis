# exframe-metrics

Utility functions for instrumenting metrics.

## Install

```bash
npm install exframe-metrics
```

## Usage

### instrument

`instrument` function takes a function as input, adds duration histogram and count metrics to it, executes it, and returns a `Promise` that is fulfilled with result of the function.

```javascript
const myFunction = () => 'banana';

const result = await instrument(myFunction);

console.log(result);
// > banana

console.log(await prometheusClient.register.metrics());
// # HELP function_myFunction_duration_seconds Length of time, in seconds, the function took to complete
// # TYPE function_myFunction_duration_seconds histogram
// function_myFunction_duration_seconds_bucket{le="0.005"} 1
// function_myFunction_duration_seconds_bucket{le="0.01"} 1
// function_myFunction_duration_seconds_bucket{le="0.025"} 1
// function_myFunction_duration_seconds_bucket{le="0.05"} 1
// function_myFunction_duration_seconds_bucket{le="0.1"} 1
// function_myFunction_duration_seconds_bucket{le="0.25"} 1
// function_myFunction_duration_seconds_bucket{le="0.5"} 1
// function_myFunction_duration_seconds_bucket{le="1"} 1
// function_myFunction_duration_seconds_bucket{le="2.5"} 1
// function_myFunction_duration_seconds_bucket{le="5"} 1
// function_myFunction_duration_seconds_bucket{le="10"} 1
// function_myFunction_duration_seconds_bucket{le="+Inf"} 1
// function_myFunction_duration_seconds_sum 0.000182651
// function_myFunction_duration_seconds_count 1

// # HELP function_myFunction_calls_total Total number of times the function was called
// # TYPE function_myFunction_calls_total counter
// function_myFunction_calls_total 1
```

### lazyInstrument

`lazyInstrument` function has a similar outcome as `instrument` except that it does not execute the input function directly and instead returns a different async function, instrumented with metrics, that can be called later. Useful for generating middleware functions.

```javascript
const myFunction = () => 'banana';

const myDeferredFunction = await lazyInstrument(myFunction);

const result = await myDeferredFunction();

console.log(result);
// > banana
```

## API

### instrument(fn, options?)

Returns a `Promise` that is either fulfilled with the input function's result, or rejected with an error if the function throws.

#### fn

Type: `function`

Function to be instrumented. Default metrics added are:

- duration: Histogram metric that measures the total time the function took to execute. The default name of this metric is `"function_<function_name>_duration_seconds"`
- count: Counter metric that measures the total number of calls to the function with the same name (or `metricName` if provided). The default name of this metrics is: `"function_<function_name>_calls_total"`

#### options

Type: `object`

##### metricName

Type: `String`

Overrides the `fn` name to use for the base part of the metric names. *Note: This property is required if an anonymous function is provided*

##### metricPrefix

Type: `String`

String to prepend to an auto-generated metric name. Ignored if `metricName` is provided
