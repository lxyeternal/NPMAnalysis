'use strict';

const { instrument, lazyInstrument } = require('./lib/instrument');

module.exports = {
  instrument,
  lazyInstrument
};
