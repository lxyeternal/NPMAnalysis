# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [2.7.16](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.15...@molgenis-ui/components-library@2.7.16) (2021-11-25)


### Bug Fixes

* multifilter now correctly emit selected values when searching and has return objects enabled ([99e1b34](https://github.com/molgenis/molgenis-frontend/commit/99e1b34f48b28cf085a703632c756ac852bdc47b))





## [2.7.15](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.14...@molgenis-ui/components-library@2.7.15) (2021-11-02)


### Bug Fixes

* finding no results now gives empty list. Change cursor to help for warning badge ([302cf6a](https://github.com/molgenis/molgenis-frontend/commit/302cf6a999b09a72b2cf74599252ad386d23402b))





## [2.7.14](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.13...@molgenis-ui/components-library@2.7.14) (2021-08-20)


### Bug Fixes

* deduplication on query ([937b2c2](https://github.com/molgenis/molgenis-frontend/commit/937b2c235d060f4dfc7f80554182bcc9f00ae395))
* everything that wcould go wrong and has gone wrong, has been fixed ([7da549b](https://github.com/molgenis/molgenis-frontend/commit/7da549b554a9b73afb637c869505349942c0b8ea))
* unittestt to test as intended and linting ([813e225](https://github.com/molgenis/molgenis-frontend/commit/813e22519397a0a6d1a1c035c0c480d26c35accf))





## [2.7.13](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.12...@molgenis-ui/components-library@2.7.13) (2021-08-19)


### Bug Fixes

* this.options is async, needs await ([85d6e98](https://github.com/molgenis/molgenis-frontend/commit/85d6e98185377702f6a36d90dba9997b1946d5db))





## [2.7.12](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.11...@molgenis-ui/components-library@2.7.12) (2021-08-19)


### Bug Fixes

* list was not assigned again, so changes did not persist ([744cd3e](https://github.com/molgenis/molgenis-frontend/commit/744cd3e02fe9186990bd7d4d5be82cd93cc3e111))





## [2.7.11](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.10...@molgenis-ui/components-library@2.7.11) (2021-08-19)


### Bug Fixes

* newValues not a vue data property ([4d2f1ac](https://github.com/molgenis/molgenis-frontend/commit/4d2f1acf575170d60f712fd86ff42d7be8f8c984))





## [2.7.10](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.9...@molgenis-ui/components-library@2.7.10) (2021-08-19)


### Bug Fixes

* added null check for selections ([d6dce87](https://github.com/molgenis/molgenis-frontend/commit/d6dce87058512277b36a22261318da799595484f))
* can't sort by selection if there is no selection ([298e60c](https://github.com/molgenis/molgenis-frontend/commit/298e60ce541a3069e9e5170510ff19eef84b85ab))
* newValues was empty array, which was always truthy and led to error on join ([8961caa](https://github.com/molgenis/molgenis-frontend/commit/8961caa9c7e7cd95cfa44c643b838172b4c5d735))
* returning a deduplicated array ([737ca8d](https://github.com/molgenis/molgenis-frontend/commit/737ca8d13903b27cb8020bacf44880c07e5c19fa))





## [2.7.9](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.8...@molgenis-ui/components-library@2.7.9) (2021-08-17)


### Bug Fixes

* selection outside initial range not visible on mounted ([#682](https://github.com/molgenis/molgenis-frontend/issues/682)) ([b5d5502](https://github.com/molgenis/molgenis-frontend/commit/b5d550220e36acff487162bb6265ea6f59f7e10a))





## [2.7.8](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.7...@molgenis-ui/components-library@2.7.8) (2021-06-29)


### Bug Fixes

* **components-library:** controlled Pagination ([dc2d5f5](https://github.com/molgenis/molgenis-frontend/commit/dc2d5f59cb24aa8826d714984b0e63c65b6c4194))





## [2.7.7](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.6...@molgenis-ui/components-library@2.7.7) (2021-06-25)


### Bug Fixes

* **components-library:** need name for import to work ([ec3cadb](https://github.com/molgenis/molgenis-frontend/commit/ec3cadbd4593e76c296779a7c10747f8829e5e42))





## [2.7.6](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.5...@molgenis-ui/components-library@2.7.6) (2021-06-25)

**Note:** Version bump only for package @molgenis-ui/components-library





## [2.7.5](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.4...@molgenis-ui/components-library@2.7.5) (2021-06-25)


### Bug Fixes

* **components-library:** abstracted satisfy-all and changed its styling ([b1e3109](https://github.com/molgenis/molgenis-frontend/commit/b1e31090fe673143b987805cc9aa9ccd6c1414f3))
* **components-library:** don't use @ shortcut ([bff1c8a](https://github.com/molgenis/molgenis-frontend/commit/bff1c8a03d678a4b8b197426c1968f49ec3588fb))





## [2.7.4](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.3...@molgenis-ui/components-library@2.7.4) (2021-06-18)


### Bug Fixes

* **components-library:** add i18n functionality ([f2e27d5](https://github.com/molgenis/molgenis-frontend/commit/f2e27d5e0248f7d9fbf73536b815b46b27c14d7b))





## [2.7.3](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.2...@molgenis-ui/components-library@2.7.3) (2021-06-18)


### Bug Fixes

* **components-library:** converted html input checkbox to vue bootstrap checkbox ([43a069f](https://github.com/molgenis/molgenis-frontend/commit/43a069fe977f3b92405b98d2c36982bb8b2c35f0))





## [2.7.2](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.1...@molgenis-ui/components-library@2.7.2) (2021-06-15)


### Bug Fixes

* forgot to add the component ([4b72bcc](https://github.com/molgenis/molgenis-frontend/commit/4b72bcc3f3c351f0e0ab70eadd198fad162e6cfc))





## [2.7.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.7.0...@molgenis-ui/components-library@2.7.1) (2021-06-15)


### Bug Fixes

* expose table and apitable component ([854e862](https://github.com/molgenis/molgenis-frontend/commit/854e86289002404171f5cdf5d9804639c81ee6f9))





# [2.7.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.6.0...@molgenis-ui/components-library@2.7.0) (2021-06-11)


### Bug Fixes

* updated naming ([c2444bc](https://github.com/molgenis/molgenis-frontend/commit/c2444bc398eb8d9f622089433aaebd930c81d479))


### Features

* table component ([89c3bb0](https://github.com/molgenis/molgenis-frontend/commit/89c3bb017ca84452bebb505f912195841d9d2865))
* working table component ([218ce6d](https://github.com/molgenis/molgenis-frontend/commit/218ce6d0cb9a0c9ef4604d9fc13674b3fe99f606))





# [2.6.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.5.1...@molgenis-ui/components-library@2.6.0) (2021-06-10)


### Features

* **components-library:** Add satisfyAll checkbox for Multifilter and CheckboxFilter ([372c680](https://github.com/molgenis/molgenis-frontend/commit/372c6807cf8e0967f234ed686f6c1118d255dc6d))





## [2.5.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.5.0...@molgenis-ui/components-library@2.5.1) (2021-06-08)


### Bug Fixes

* fixed route-router naming error by not needing it in de components library ([4f5c3e0](https://github.com/molgenis/molgenis-frontend/commit/4f5c3e028f46c6e92569425f9d56b47402b0a138))
* make buttons a slot ([202ccca](https://github.com/molgenis/molgenis-frontend/commit/202cccaa86e0ac0f783403db1872c4f883a56e8e))





# [2.5.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.4.5...@molgenis-ui/components-library@2.5.0) (2021-05-26)


### Features

* add table row and header components ([95ce975](https://github.com/molgenis/molgenis-frontend/commit/95ce975ca95e4e4c1453906f5c1c75c4f32961d7))





## [2.4.5](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.4.4...@molgenis-ui/components-library@2.4.5) (2021-04-08)

**Note:** Version bump only for package @molgenis-ui/components-library





## [2.4.4](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.4.3...@molgenis-ui/components-library@2.4.4) (2021-03-25)


### Bug Fixes

* **components-library:** match the styles of different toasts ([#582](https://github.com/molgenis/molgenis-frontend/issues/582)) ([c4bc486](https://github.com/molgenis/molgenis-frontend/commit/c4bc486e10df2054812b4e10e47edc9b9b0933b4))





## [2.4.3](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.4.2...@molgenis-ui/components-library@2.4.3) (2021-03-22)


### Bug Fixes

* **components-library:** added container-fluid instead of container class to toast, to prevent the button going off-screen ([685fbde](https://github.com/molgenis/molgenis-frontend/commit/685fbde3f98c9d399a7b73e8328e69ec72b98cd1))





## [2.4.2](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.4.1...@molgenis-ui/components-library@2.4.2) (2021-03-19)

**Note:** Version bump only for package @molgenis-ui/components-library





## [2.4.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.4.0...@molgenis-ui/components-library@2.4.1) (2021-03-18)

**Note:** Version bump only for package @molgenis-ui/components-library





# [2.4.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.3.0...@molgenis-ui/components-library@2.4.0) (2021-03-09)


### Bug Fixes

* select / deselect all now works ([f446788](https://github.com/molgenis/molgenis-frontend/commit/f446788facab67fc531a28a2fdb0cf2fde3245d1))


### Features

* now you can add an array of values to the checkbox filter and it will only show those options ([5e7bf06](https://github.com/molgenis/molgenis-frontend/commit/5e7bf06346f7410ce8da6f8de95d9a8359fd1b71))





# [2.3.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.2.0...@molgenis-ui/components-library@2.3.0) (2021-03-03)


### Features

* **components-library:** Dynamic filter container labels ([#553](https://github.com/molgenis/molgenis-frontend/issues/553)) ([6cd4933](https://github.com/molgenis/molgenis-frontend/commit/6cd4933af69abe3dd7ff4bca5d5d45ede1fc2d78))





# [2.2.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.1.1...@molgenis-ui/components-library@2.2.0) (2021-02-25)


### Features

* **components-library:** Add multifilter cutoff as a variable, so you can easily test warning and removing magic number ([#549](https://github.com/molgenis/molgenis-frontend/issues/549)) ([86872ac](https://github.com/molgenis/molgenis-frontend/commit/86872acea10367274c8d794e715d2bf2feeac9db))





## [2.1.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.1.0...@molgenis-ui/components-library@2.1.1) (2021-02-25)


### Bug Fixes

* **data-explorer:** use dropdown to change filters; updated styling ([#539](https://github.com/molgenis/molgenis-frontend/issues/539)) ([6fdd30a](https://github.com/molgenis/molgenis-frontend/commit/6fdd30afbb08e8fe3bcb846ac069c5c02e53c927))
* **data-explorer, components-library, navigator:** fix master build ([b8c2e19](https://github.com/molgenis/molgenis-frontend/commit/b8c2e19ff04b1b859a4e41de28d7e852770ec883))





# [2.1.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.0.3...@molgenis-ui/components-library@2.1.0) (2021-02-15)


### Features

* changed icon to be more informative ([d0d610f](https://github.com/molgenis/molgenis-frontend/commit/d0d610f))





## [2.0.3](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.0.2...@molgenis-ui/components-library@2.0.3) (2021-02-02)


### Bug Fixes

* add view to router & parse page/size to int from router ([ebb1fd1](https://github.com/molgenis/molgenis-frontend/commit/ebb1fd1))





## [2.0.2](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.0.1...@molgenis-ui/components-library@2.0.2) (2021-02-01)


### Bug Fixes

* **components-library:** emit updated model on size change ([#514](https://github.com/molgenis/molgenis-frontend/issues/514)) ([184527d](https://github.com/molgenis/molgenis-frontend/commit/184527d))





## [2.0.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@2.0.0...@molgenis-ui/components-library@2.0.1) (2021-02-01)


### Bug Fixes

* **components-library, data-explorer:** fix routing issues due to wrong fetch order ([a14c1fe](https://github.com/molgenis/molgenis-frontend/commit/a14c1fe))





# [2.0.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.6.4...@molgenis-ui/components-library@2.0.0) (2021-01-27)


### Features

* **components-library:** remove router from Pagination component ([#509](https://github.com/molgenis/molgenis-frontend/issues/509)) ([1cd4559](https://github.com/molgenis/molgenis-frontend/commit/1cd4559))


### BREAKING CHANGES

* **components-library:** Requires consumers to implement Vue-router navigation





## [1.6.4](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.6.3...@molgenis-ui/components-library@1.6.4) (2021-01-22)


### Bug Fixes

* **components-library:** Fix 507 hard color in component ([#508](https://github.com/molgenis/molgenis-frontend/issues/508)) ([c72f651](https://github.com/molgenis/molgenis-frontend/commit/c72f651)), closes [#507](https://github.com/molgenis/molgenis-frontend/issues/507)





## [1.6.3](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.6.2...@molgenis-ui/components-library@1.6.3) (2021-01-08)


### Bug Fixes

* **components-library:** fix pagination issues + lint code ([#482](https://github.com/molgenis/molgenis-frontend/issues/482)) ([36e0057](https://github.com/molgenis/molgenis-frontend/commit/36e0057))





## [1.6.2](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.6.1...@molgenis-ui/components-library@1.6.2) (2021-01-06)


### Bug Fixes

* **components-library:** bump release ([#475](https://github.com/molgenis/molgenis-frontend/issues/475)) ([fa0b426](https://github.com/molgenis/molgenis-frontend/commit/fa0b426))





## [1.6.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.6.0...@molgenis-ui/components-library@1.6.1) (2021-01-06)


### Bug Fixes

* **components-library:** update i18n pagination ([0d29220](https://github.com/molgenis/molgenis-frontend/commit/0d29220))





# [1.6.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.5.2...@molgenis-ui/components-library@1.6.0) (2021-01-04)


### Features

* **components-library:** add pagination component ([4744fbd](https://github.com/molgenis/molgenis-frontend/commit/4744fbd))





## [1.5.2](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.5.1...@molgenis-ui/components-library@1.5.2) (2020-12-17)


### Bug Fixes

* **components-library:** remove undefined, empty arrays, empty strings, etz from the selected filters ([8b4886c](https://github.com/molgenis/molgenis-frontend/commit/8b4886c))





## [1.5.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.5.0...@molgenis-ui/components-library@1.5.1) (2020-12-04)


### Bug Fixes

* **components-library:** removed negative margins when active filters are empty ([c5a2c9c](https://github.com/molgenis/molgenis-frontend/commit/c5a2c9c))





# [1.5.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.4.3...@molgenis-ui/components-library@1.5.0) (2020-12-03)


### Features

* **components-library:** added new appendToBody property to datetime filter ([31c9bd7](https://github.com/molgenis/molgenis-frontend/commit/31c9bd7))





## [1.4.3](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.4.2...@molgenis-ui/components-library@1.4.3) (2020-12-03)


### Bug Fixes

* **components-library:** fix button margin with negative margins ([e7ad3ba](https://github.com/molgenis/molgenis-frontend/commit/e7ad3ba))





## [1.4.2](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.4.1...@molgenis-ui/components-library@1.4.2) (2020-11-30)

**Note:** Version bump only for package @molgenis-ui/components-library





## [1.4.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.4.0...@molgenis-ui/components-library@1.4.1) (2020-11-23)


### Bug Fixes

* query & sorting ([4304be4](https://github.com/molgenis/molgenis-frontend/commit/4304be4))
* **components-library:** Searching inside multifilter no longer clears checkboxes. Newly found options are appended on top. ([df567d4](https://github.com/molgenis/molgenis-frontend/commit/df567d4))





# [1.4.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.3.3...@molgenis-ui/components-library@1.4.0) (2020-11-20)


### Features

* add Toaster component ([#439](https://github.com/molgenis/molgenis-frontend/issues/439)) ([5e8252c](https://github.com/molgenis/molgenis-frontend/commit/5e8252c))





## [1.3.3](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.3.2...@molgenis-ui/components-library@1.3.3) (2020-11-17)


### Bug Fixes

* **components-library:** Object assign is really required for correct responsiveness of v-model of checkbox group ([52e6b63](https://github.com/molgenis/molgenis-frontend/commit/52e6b63))





## [1.3.2](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.3.1...@molgenis-ui/components-library@1.3.2) (2020-11-17)


### Bug Fixes

* typo ([1786880](https://github.com/molgenis/molgenis-frontend/commit/1786880))
* **components-library:** added reactiveness from changes made by active filter ([9d68a02](https://github.com/molgenis/molgenis-frontend/commit/9d68a02))
* **components-library:** deduplicate options when fetching based on initial value ([dd5f950](https://github.com/molgenis/molgenis-frontend/commit/dd5f950))
* **components-library:** small bug in reactiveness ([6a089dd](https://github.com/molgenis/molgenis-frontend/commit/6a089dd))





## [1.3.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.3.0...@molgenis-ui/components-library@1.3.1) (2020-11-16)

**Note:** Version bump only for package @molgenis-ui/components-library





# [1.3.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.2.0...@molgenis-ui/components-library@1.3.0) (2020-11-16)


### Features

* first steps to make returning objects from multi-filter possible ([daa0331](https://github.com/molgenis/molgenis-frontend/commit/daa0331))
* multifilter can now return an recieve objects. Also fixed a bug where the initial value was not shown correctly on creation ([d2261c0](https://github.com/molgenis/molgenis-frontend/commit/d2261c0))





# [1.2.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.1.3...@molgenis-ui/components-library@1.2.0) (2020-11-10)


### Features

* **components-library:** option to return text and value in checkbox filter instead of only value(id) ([1bf8ac1](https://github.com/molgenis/molgenis-frontend/commit/1bf8ac1))





## [1.1.3](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.1.2...@molgenis-ui/components-library@1.1.3) (2020-11-06)


### Bug Fixes

* **components-library:** fixed infinite loop sometimes occurring ([#429](https://github.com/molgenis/molgenis-frontend/issues/429)) ([56dd873](https://github.com/molgenis/molgenis-frontend/commit/56dd873))





## [1.1.2](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.1.1...@molgenis-ui/components-library@1.1.2) (2020-11-06)


### Bug Fixes

* **components-library:** removed computed in favour of v-model ([8372665](https://github.com/molgenis/molgenis-frontend/commit/8372665))





## [1.1.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.1.0...@molgenis-ui/components-library@1.1.1) (2020-11-06)

**Note:** Version bump only for package @molgenis-ui/components-library





# [1.1.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.0.1...@molgenis-ui/components-library@1.1.0) (2020-11-03)


### Features

* **components-library:** add custom css class for header ([09240cd](https://github.com/molgenis/molgenis-frontend/commit/09240cd))





## [1.0.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@1.0.0...@molgenis-ui/components-library@1.0.1) (2020-10-22)


### Bug Fixes

* **components-library:** add babel to rollup build ([#411](https://github.com/molgenis/molgenis-frontend/issues/411)) ([16a7ddf](https://github.com/molgenis/molgenis-frontend/commit/16a7ddf))
* **components-library:** distinguish vue-cli babel preset from rollup preset ([#413](https://github.com/molgenis/molgenis-frontend/issues/413)) ([994d51f](https://github.com/molgenis/molgenis-frontend/commit/994d51f))





# [1.0.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.10.0...@molgenis-ui/components-library@1.0.0) (2020-10-21)


### chore

* make vue-bootstrap an external dependency ([#409](https://github.com/molgenis/molgenis-frontend/issues/409)) ([02c7e2d](https://github.com/molgenis/molgenis-frontend/commit/02c7e2d)), closes [#7576](https://github.com/molgenis/molgenis-frontend/issues/7576)


### Features

* **components-library:** [#7576](https://github.com/molgenis/molgenis-frontend/issues/7576) components-library as library ([931b16b](https://github.com/molgenis/molgenis-frontend/commit/931b16b))


### BREAKING CHANGES

* **components-library:** Third-party dependencies need to be included separately; see README.md
* Third-party dependencies need to be included separately; see README.md





# [0.10.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.9.1...@molgenis-ui/components-library@0.10.0) (2020-10-09)


### Features

* **components-library:** add RangeFilter to styleguidist ([#387](https://github.com/molgenis/molgenis-frontend/issues/387)) ([650ac74](https://github.com/molgenis/molgenis-frontend/commit/650ac74))





## [0.9.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.9.0...@molgenis-ui/components-library@0.9.1) (2020-10-09)

**Note:** Version bump only for package @molgenis-ui/components-library





# [0.9.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.8.0...@molgenis-ui/components-library@0.9.0) (2020-10-07)


### Features

* **components-library:** [#7576](https://github.com/molgenis/molgenis-frontend/issues/7576) add MultiFilter to styleguidist ([#388](https://github.com/molgenis/molgenis-frontend/issues/388)) ([bc3c9b1](https://github.com/molgenis/molgenis-frontend/commit/bc3c9b1))





# [0.8.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.7.0...@molgenis-ui/components-library@0.8.0) (2020-10-07)


### Features

* **components-library:** Add active filters component ([#393](https://github.com/molgenis/molgenis-frontend/issues/393)) ([cfcc51d](https://github.com/molgenis/molgenis-frontend/commit/cfcc51d))





# [0.7.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.6.0...@molgenis-ui/components-library@0.7.0) (2020-10-07)


### Features

* **components-library:** add filter card component ([#391](https://github.com/molgenis/molgenis-frontend/issues/391)) ([9a598cf](https://github.com/molgenis/molgenis-frontend/commit/9a598cf))





# [0.6.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.5.0...@molgenis-ui/components-library@0.6.0) (2020-09-30)


### Features

* **components-library:** [#7576](https://github.com/molgenis/molgenis-frontend/issues/7576) add DateTimeFilter to styleguidist ([#390](https://github.com/molgenis/molgenis-frontend/issues/390)) ([814173c](https://github.com/molgenis/molgenis-frontend/commit/814173c))





# [0.5.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.4.0...@molgenis-ui/components-library@0.5.0) (2020-09-25)


### Features

* **components-library:** Add Number filter component ([#386](https://github.com/molgenis/molgenis-frontend/issues/386)) ([9459d17](https://github.com/molgenis/molgenis-frontend/commit/9459d17))





# [0.4.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.3.1...@molgenis-ui/components-library@0.4.0) (2020-09-25)


### Features

* **components-library:** Add string-filter component ([#385](https://github.com/molgenis/molgenis-frontend/issues/385)) ([210793b](https://github.com/molgenis/molgenis-frontend/commit/210793b))





## [0.3.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.3.0...@molgenis-ui/components-library@0.3.1) (2020-09-24)


### Bug Fixes

* **components-library:** change use if i-tag to span-tag, removes sonar warning ([#384](https://github.com/molgenis/molgenis-frontend/issues/384)) ([007cae4](https://github.com/molgenis/molgenis-frontend/commit/007cae4))





# [0.3.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.2.2...@molgenis-ui/components-library@0.3.0) (2020-09-24)


### Features

* **components-library:** added passthrough classes so you can style the toast ([#382](https://github.com/molgenis/molgenis-frontend/issues/382)) ([08e9bde](https://github.com/molgenis/molgenis-frontend/commit/08e9bde))
* **components-library:** Allow object data in cartselectiontoast ([c7136d0](https://github.com/molgenis/molgenis-frontend/commit/c7136d0))





## [0.2.2](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.2.1...@molgenis-ui/components-library@0.2.2) (2020-09-22)


### Bug Fixes

* **components-lib:** Fix linting in jsx template for vs code, needs v-bind: instead of : ([f4a5a3f](https://github.com/molgenis/molgenis-frontend/commit/f4a5a3f))





## [0.2.1](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.2.0...@molgenis-ui/components-library@0.2.1) (2020-09-21)


### Bug Fixes

* **components-library:** now exposes correctly ([a9c9914](https://github.com/molgenis/molgenis-frontend/commit/a9c9914))





# [0.2.0](https://github.com/molgenis/molgenis-frontend/compare/@molgenis-ui/components-library@0.1.1...@molgenis-ui/components-library@0.2.0) (2020-09-18)


### Bug Fixes

* cleanup code and unit tests ([76bdc1c](https://github.com/molgenis/molgenis-frontend/commit/76bdc1c))
* **components-library:** fix lib build ([6eb2fb4](https://github.com/molgenis/molgenis-frontend/commit/6eb2fb4))
* **components-library:** fix single quotes. (linter does not work?) ([4cf5850](https://github.com/molgenis/molgenis-frontend/commit/4cf5850))
* add basic functionality ([03ec0f2](https://github.com/molgenis/molgenis-frontend/commit/03ec0f2))


### Features

* add cartSelectionToast component ([91a79e8](https://github.com/molgenis/molgenis-frontend/commit/91a79e8))
* complete all CartSelectionToast properties ([7084a85](https://github.com/molgenis/molgenis-frontend/commit/7084a85))
* complete all CartSelectionToast properties ([8565af9](https://github.com/molgenis/molgenis-frontend/commit/8565af9))





## 0.1.1 (2020-09-08)

**Note:** Version bump only for package @molgenis-ui/components-library
