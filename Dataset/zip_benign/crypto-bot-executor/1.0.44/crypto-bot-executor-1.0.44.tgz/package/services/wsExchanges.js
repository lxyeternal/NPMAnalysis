const WebsocketClient = require('ftx-api').WebsocketClient
const { Exchange } = require('./services/exchanges')
const { getKey } = require('../utils/utils')

class WebsocketExchange {
  constructor(name) {
    this.name = name
  }
  
  init = async (exchange, symbol, size, side) => {
    try {
      const params = {
        key: await getKey(this.name, 'KEY'),
        secret: await getKey(this.name, 'SECRET'),
        subAccountName: await getKey(this.name, 'SUBACC'),
      }

      // Prepare a ws connection (connection init is automatic once ws client is instanced)
      const ws = new WebsocketClient(params)
      this.exchange = new Exchange(exchange)

      // append event listeners
      ws.on('response', (msg) => {
        console.log('response: ', msg)
      })
      ws.on('update', (msg) => {
        console.log(msg)
        if (msg.type === 'update') {
          // update:  {
          //   channel: 'fills',
          //   type: 'update',
          //   data: {
          //     id: 4492241438,
          //     market: 'ETH-PERP',
          //     future: 'ETH-PERP',
          //     baseCurrency: null,
          //     quoteCurrency: null,
          //     type: 'order',
          //     side: 'buy',
          //     price: 4227.4,
          //     size: 0.01,
          //     orderId: 90537350996,
          //     time: '2021-10-26T01:53:02.804696+00:00',
          //     tradeId: 2229585232,
          //     feeRate: 0.000679,
          //     fee: 0.028704046,
          //     feeCurrency: 'USD',
          //     liquidity: 'taker'
          //   }
          // }
          console.log(`${side} ${size} ${symbol} on ${exchange}`)
          this.exchange.placeOrder(symbol, 'buy', 'market', size)
        }
      })
      // ws.on('error', msg => console.log('err: ', msg));

      // Subscribe to public & private topics. Any of the following are valid:
      ws.subscribe('fills')
    } catch (e) {
      console.error('err: ', e.body)
    }
  }
}

module.exports = {
  WebsocketExchange,
}
