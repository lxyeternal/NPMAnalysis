const TelegramBot = require('node-telegram-bot-api')
const bot = new TelegramBot(process.env.TOKEN, { polling: false })

const sendMessage = async (channel, message) => {
  await bot.sendMessage(channel, message, {
    parse_mode: 'markdown',
  })
}

module.exports = {
  sendMessage,
}
