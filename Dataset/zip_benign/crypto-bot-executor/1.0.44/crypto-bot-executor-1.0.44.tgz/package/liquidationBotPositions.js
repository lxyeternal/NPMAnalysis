require('dotenv').config({ path: '~/.env/crypto-bot.env' })
const fetch = require('node-fetch')
const { Contract, Wallet, BigNumber, constants, providers } = require('ethers')
const metadata = require('./resources/perpetual/optimism.json')

const player = require('play-sound')((opts = {}))

const VaultArtifact = require('@perp/curie-contract/artifacts/contracts/Vault.sol/Vault.json')

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

const play = () => {
  player.play(`${__dirname}/resources/sounds/start.mp3`, function (err) {
    if (err) throw err
  })
}

const fetchAccounts = async () => {
  const createQueryFunc = (batchSize, lastID) => `
  {
    positions(first: ${batchSize}, where: {positionSize_gt: "0", id_gt: "${lastID}"}) {
      trader
    }
  }`
  const extractDataFunc = (data) => {
    return data.data.positions
  }
  return (
    await queryAndExtractSubgraphAll(createQueryFunc, extractDataFunc)
  ).map((accountData) => accountData.trader)
}

const queryAndExtractSubgraphAll = async (createQueryFunc, extractDataFunc) => {
  let results = []
  // batchSize should between 0 ~ 1000
  const batchSize = 1000
  let lastID = ''
  while (true) {
    const query = createQueryFunc(batchSize, lastID)
    const data = await querySubgraph(query)
    if (data.errors) {
      break
    }
    const batch = extractDataFunc(data)
    if (batch.length === 0) {
      break
    }
    results = [...results, ...batch]
    lastID = results[results.length - 1].id
  }
  return results
}

const querySubgraph = async (query) => {
  const resp = await fetch(
    'https://api.thegraph.com/subgraphs/name/perpetual-protocol/perpetual-v2-optimism',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({ query }),
    }
  )
  const data = await resp.json()
  if (data.errors) {
    console.error({
      event: 'GraphQueryError',
      params: {
        err: new Error('GraphQueryError'),
        errors: data.errors,
      },
    })
  }
  return data
}

const start = async () => {
  // const metadata = await fetch(urlProd).then((res) => res.json())
  const vaultAddr = metadata.contracts.Vault.address
  const mainNet = 'https://mainnet.optimism.io'
  const layer2Provider = new providers.JsonRpcProvider(mainNet)

  const vault = new Contract(vaultAddr, VaultArtifact.abi, layer2Provider)

  const accounts = await fetchAccounts()

  // console.log(accounts)

  const sliceIntoChunks = (arr, chunkSize) => {
    const res = []
    for (let i = 0; i < arr.length; i += chunkSize) {
      const chunk = arr.slice(i, i + chunkSize)
      res.push(chunk)
    }
    return res
  }

  const chunks = sliceIntoChunks(accounts, 100)

  for (let i = 0; i < chunks.length; i++) {
    try {
      const liquidations = chunks[i].map(async (p) => {
        const temp = await vault.isLiquidatable(p)
        // console.log(p, temp)
        return [p, temp]
      })
      let liqs = await Promise.all(liquidations)

      if (!liqs.every((p) => p[1] === false)) {
        console.log(liqs.filter((k) => k[1] == true))
        process.exit()
      }
    } catch (error) {
      continue
    }
  }
}

const run = async () => {
  try {
    await start()
  } catch (err) {
    console.log(err)
  }
}

run()
