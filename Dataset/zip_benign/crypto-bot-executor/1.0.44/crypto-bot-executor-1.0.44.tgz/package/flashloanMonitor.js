const { Contract, providers, utils } = require('ethers')
const rpcURL =
  'https://eth-mainnet.g.alchemy.com/v2/cW5bppEvg-quPiwKxlEXmSy5Xm5iTGe8'
const provider = new providers.JsonRpcProvider(rpcURL)
require('crypto-bot-libs/utils/utils')
const db = require('crypto-bot-libs/services/db')
const moment = require('moment')

const AAVE_LENDING_POOL_ABI = [
  {
    anonymous: false,
    inputs: [
      {
        indexed: true,
        internalType: 'address',
        name: 'target',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'initiator',
        type: 'address',
      },
      {
        indexed: true,
        internalType: 'address',
        name: 'asset',
        type: 'address',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'amount',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint256',
        name: 'premium',
        type: 'uint256',
      },
      {
        indexed: false,
        internalType: 'uint16',
        name: 'referralCode',
        type: 'uint16',
      },
    ],
    name: 'FlashLoan',
    type: 'event',
  },
]

const main = async () => {
  // const AAVE_LENDING_POOL_ADDRESS = '0x794a61358D6845594F94dc1DB02A252b5b4814aD'
  const AAVE_LENDING_POOL_ADDRESS = '0x7d2768dE32b0b80b7a3454c06BdAc94A69DDc7A9'

  const aaveLendingPool = new Contract(
    AAVE_LENDING_POOL_ADDRESS,
    AAVE_LENDING_POOL_ABI,
    provider
  )

  const logs = await provider
    .getLogs({
      fromBlock: 15205000,
      toBlock: 15305000,
      address: AAVE_LENDING_POOL_ADDRESS,
      asset: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
      topics: [
        utils.keccak256(
          utils.toUtf8Bytes(Object.keys(aaveLendingPool.interface.events)[0])
        ),
      ],
    })
    .catch((err) => console.error(err))

  // console.log(logs)

  const inserts = logs.map((p) => {
    return [
      moment.utc().toISOString(),
      'Mainnet',
      'AAVE',
      p.blockNumber,
      'wETH',
      parseFloat(
        utils.defaultAbiCoder.decode(['uint256'], p.data).toString() / 10 ** 18
      ),
    ]
  })

  await db.insertFlashLoansBulk(inserts)
}

main()
