require('dotenv').config({ path: '~/.env/crypto-bot.env' })
const marginManagement = require('./marginManagement')
const balances = require('./cli/balances')
const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

const switchRoute = {}

exports.handler = async (event, context) => {
  // console.log(event)
  // const payload1 = {
  //   env: 'PRODUCTION',
  //   exchangeA: 'PERPETUAL',
  //   exchangeB: 'FTX',
  //   asset: 'ETH',
  //   amountUsd: 100,
  //   trigger: 5,
  //   dryrun: true,
  // }
  // const margin = marginManagement.marginManagement(payload1)

  const balancePayload1 = {
    env: 'PRODUCTION',
    exchange: 'FTX',
    asset: 'USD',
    dryrun: false,
  }
  const balance1 = balances.getBalances(balancePayload1)

  const balancePayload2 = {
    env: 'PRODUCTION',
    exchange: 'PERPETUAL',
    asset: 'USD',
    dryrun: false,
  }
  const balance2 = balances.getBalances(balancePayload2)

  const balancePayload3 = {
    env: 'STAGING',
    exchange: 'FTX',
    asset: 'USD',
    dryrun: false,
  }
  const balance3 = balances.getBalances(balancePayload3)


  const balancePayload4 = {
    env: 'STAGING',
    exchange: 'PERPETUAL',
    asset: 'USD',
    dryrun: false,
  }
  const balance4 = await balances.getBalances(balancePayload4)

  await Promise.all([balance1, balance2, balance3, balance4])
  // const func = switchRoute[event.route]
  // const resp = await func(event.payload)

  // return resp
}

const test = async () => {
  // await openPosition()
}

// if (process.env.NODE_ENV === 'dev') test()
if (process.env.NODE_ENV === 'dev') this.handler()
