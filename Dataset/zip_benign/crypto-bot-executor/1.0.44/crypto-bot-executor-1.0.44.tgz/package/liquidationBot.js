require('dotenv').config({ path: '~/.env/crypto-bot.env' })
const fetch = require('node-fetch')
const { Contract, Wallet, BigNumber, constants, providers } = require('ethers')
const metadata = require('./resources/perpetual/optimism.json')

const VaultArtifact = require('@perp/curie-contract/artifacts/contracts/Vault.sol/Vault.json')

const urlProd = 'https://metadata.perp.exchange/v2/optimism.json'

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

const fetchAccounts = async (type) => {
  const createQueryFunc = (batchSize, lastID) => `
  {
      ${type}(first: ${batchSize}, where: {id_gt: "${lastID}"}) {
          id
      }
  }`
  const extractDataFunc = (data) => {
    return data.data[type]
  }
  return (
    await queryAndExtractSubgraphAll(createQueryFunc, extractDataFunc)
  ).map((accountData) => accountData.id)
}

const queryAndExtractSubgraphAll = async (createQueryFunc, extractDataFunc) => {
  let results = []
  // batchSize should between 0 ~ 1000
  const batchSize = 1000
  let lastID = ''
  while (true) {
    const query = createQueryFunc(batchSize, lastID)
    const data = await querySubgraph(query)
    if (data.errors) {
      break
    }
    const batch = extractDataFunc(data)
    if (batch.length === 0) {
      break
    }
    results = [...results, ...batch]
    lastID = results[results.length - 1].id
  }
  return results
}

const querySubgraph = async (query) => {
  const resp = await fetch(
    'https://api.thegraph.com/subgraphs/name/perpetual-protocol/perpetual-v2-optimism',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
      },
      body: JSON.stringify({ query }),
    }
  )
  const data = await resp.json()
  if (data.errors) {
    console.error({
      event: 'GraphQueryError',
      params: {
        err: new Error('GraphQueryError'),
        errors: data.errors,
      },
    })
  }
  return data
}

const start = async () => {
  // const metadata = await fetch(urlProd).then((res) => res.json())
  const vaultAddr = metadata.contracts.Vault.address
  const mainNet =
    'https://mainnet.optimism.io'
  const layer2Provider = new providers.JsonRpcProvider(mainNet)
  const layer2Wallet = new Wallet(process.env.PERPETUAL_STAGING_SECRET).connect(
    layer2Provider
  )
  const vault = new Contract(vaultAddr, VaultArtifact.abi, layer2Provider)

  const traders = await fetchAccounts('traders')
  const makers = await fetchAccounts('makers')
  const result = Array.from(new Set(traders.concat(makers)))

  // const liquidations = result.map(p => {
  //   return [p, await vault.isLiquidatable('0x01b2e7c7768d2a58eb721fd32c6718ba3f053a15')]
  // }).filter(k => k[1] === true)

  const sliceIntoChunks = (arr, chunkSize) => {
    const res = []
    for (let i = 0; i < arr.length; i += chunkSize) {
      const chunk = arr.slice(i, i + chunkSize)
      res.push(chunk)
    }
    return res
  }

  const chunks = sliceIntoChunks(result, 100)

  for (let i = 0; i < chunks.length; i++) {
    try {
      const liquidations = chunks[i].map(async (p) => {
        const temp = await vault.isLiquidatable(p)
        console.log(p, temp)
        if (temp) process.exit()
      })
      await Promise.all(liquidations)
      await delay(1000)
      console.log(i)
    } catch (error) {
      continue
    }
  }
}

const run = async () => {
  await start()
}

run()
