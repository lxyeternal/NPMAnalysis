require('dotenv').config({ path: '~/.env/crypto-bot.env' })
const { Contract, Wallet, BigNumber, constants, providers } = require('ethers')
const { parseUnits, formatEther, formatUnits } = require('ethers/lib/utils')
const fetch = require('node-fetch')
const { Pool } = require('@uniswap/v3-sdk')
const { Token } = require('@uniswap/sdk-core')
const JSBI = require('jsbi')
const { Exchange } = require('crypto-bot-libs/services/exchanges')
const metadata = require('crypto-bot-libs/resources/perpetual/optimism.json')

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

const DEFAULT_DECIMALS = 18

let clearingHouse, exchange, vault, accountBalance, layer2Provider

const poolAbi =
  require('@uniswap/v3-core/artifacts/contracts/interfaces/IUniswapV3Pool.sol/IUniswapV3Pool.json').abi

const deposit = async () => {
  const options = {
    gasLimit: 3_000_000,
  }

  // Need allowance first
  const tx = await vault.deposit(usdcAddr, parseUnits('90'), options)
  const result = await tx.wait()
  console.log(result)
}

/**
 * isBaseToQuote false for longing
 * isExactInput true for shorting
 * @param {*} total
 * @returns
 */
const openPosition = async (asset, side, total) => {
  try {
    const ADDR = metadata.contracts[`v${asset}`].address

    const block = await layer2Provider.getBlock()
    let baseToQuote, exactInput

    if (side === 'buy') {
      ;(baseToQuote = false), (exactInput = false)
    } else {
      ;(baseToQuote = true), (exactInput = true)
    }

    const params = {
      baseToken: ADDR,
      isBaseToQuote: baseToQuote, // false for longing
      isExactInput: exactInput,
      amount: parseUnits(total.toString()),
      oppositeAmountBound: 0, // 0 for no amount limit
      sqrtPriceLimitX96: 0, // 0 for no price limit
      deadline: block.timestamp + 900, // 15 minutes for example
      referralCode:
        '0x000000000000000000000000000000000000000000007475747369616e647265', // Buffer.from('tutsiandre').toString('hex')
    }

    const result = await clearingHouse.openPosition(params)
    return result
  } catch (error) {
    console.log(error)
    throw error
  }
}

const getPositions = async (trader) => {
  // const value = await clearingHouse.getAccountValue(process.env.PUBLIC_KEY)
  // console.log('Total Value', formatEther(value))
  const value = await vault.getAccountValue(trader)
  console.log('Total Value', formatUnits(value, 6))
  const free = await vault.getFreeCollateral(trader)
  console.log('Free Collateral', formatUnits(free, 6))
  const pendingPayments = await exchange.getAllPendingFundingPayment(trader)
  console.log('Pending Payments', formatEther(pendingPayments))
}

const getTakerPosition = async (vAddr) => {
  const ADDR = vAddr || metadata.contracts.vETH.address
  const result = await accountBalance.getTakerPositionSize(
    process.env.PUBLIC_KEY,
    ADDR
  )
  console.log(formatEther(result))
}

const getTotalPositionValue = async () => {
  const result = await accountBalance.getTotalAbsPositionValue(
    process.env.PUBLIC_KEY
  )
  console.log(formatEther(result))
}

const getOracleLastPrice = async (oracleAddr) => {
  try {
    const aggregatorV3InterfaceABI = [
      {
        inputs: [],
        name: 'decimals',
        outputs: [{ internalType: 'uint8', name: '', type: 'uint8' }],
        stateMutability: 'view',
        type: 'function',
      },
      {
        inputs: [
          {
            internalType: 'uint256',
            name: 'interval',
            type: 'uint256',
          },
        ],
        name: 'getPrice',
        outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
        stateMutability: 'view',
        type: 'function',
      },
    ]
    const addr = oracleAddr || '0xa36faf16f31c12285467b1973ee8fa144ed4d846'
    const priceFeed = new Contract(
      addr,
      aggregatorV3InterfaceABI,
      layer2Provider
    )
    const result = await priceFeed.getPrice(0)
    return parseFloat(formatUnits(result, 8))
  } catch (error) {
    console.log(error)
    throw error
  }
}

const getMarkPrice = async (poolAddr) => {
  try {
    const poolAddress = poolAddr || '0x36B18618c4131D8564A714fb6b4D2B1EdADc0042' // vETH
    const poolContract = new Contract(poolAddress, poolAbi, layer2Provider)

    const [liquidity, slot] = await Promise.all([
      poolContract.liquidity(),
      poolContract.slot0(),
    ])

    const state = {
      liquidity,
      sqrtPriceX96: slot[0],
      tick: slot[1],
      observationIndex: slot[2],
      observationCardinality: slot[3],
      observationCardinalityNext: slot[4],
      feeProtocol: slot[5],
      unlocked: slot[6],
    }

    const sqrtPriceX96 = state.sqrtPriceX96
    const price =
      (sqrtPriceX96 ** 2 * 1e18) / 1e18 / JSBI.BigInt(2) ** JSBI.BigInt(192)

    return price
  } catch (error) {
    console.log(error)
    throw error
  }
}

const setup = async () => {
  const ClearingHouseArtifact = require('@perp/curie-contract/artifacts/contracts/ClearingHouse.sol/ClearingHouse.json')
  const ExchangeArtifact = require('@perp/curie-contract/artifacts/contracts/Exchange.sol/Exchange.json')
  const VaultArtifact = require('@perp/curie-contract/artifacts/contracts/Vault.sol/Vault.json')
  const AccountBalanceArtifact = require('@perp/curie-contract/artifacts/contracts/AccountBalance.sol/AccountBalance.json')

  // const urlStag = 'https://metadata.perp.exchange/v2/optimism-kovan.json'
  const urlProd = 'https://metadata.perp.exchange/v2/optimism.json'

  // metadata = await fetch(urlProd).then((res) => res.json())

  const clearingHouseAddr = metadata.contracts.ClearingHouse.address
  const exchangeAddr = metadata.contracts.Exchange.address
  const vaultAddr = metadata.contracts.Vault.address
  const accountBalanceAddr = metadata.contracts.AccountBalance.address
  const usdcAddr = metadata.externalContracts.USDC

  const mainNet = 'http://127.0.0.1:7545'
  // const mainNet = 'https://mainnet.optimism.io'
  // const testNet = 'https://kovan.optimism.io'
  layer2Provider = new providers.JsonRpcProvider(mainNet)
  // const layer2Wallet = new Wallet(process.env.PRIVATE_KEY).connect(
  //   layer2Provider
  // )

  const layer2Wallet = layer2Provider.getSigner('0x811886a1d8aa7e06bc057dabd87102911a584350')

  clearingHouse = new Contract(
    clearingHouseAddr,
    ClearingHouseArtifact.abi,
    layer2Wallet
  )


  clearingHouse = new Contract(
    clearingHouseAddr,
    ClearingHouseArtifact.abi,
    layer2Provider
  )


  exchange = new Contract(exchangeAddr, ExchangeArtifact.abi, layer2Wallet)

  vault = new Contract(vaultAddr, VaultArtifact.abi, layer2Wallet)

  accountBalance = new Contract(
    accountBalanceAddr,
    AccountBalanceArtifact.abi,
    layer2Wallet
  )

  accountBalance = new Contract(
    accountBalanceAddr,
    AccountBalanceArtifact.abi,
    layer2Provider
  )
}

const test = async () => {
  const trader = '0x811886a1d8aa7e06bc057dabd87102911a584350'
  await setup()
  await getPositions(trader)
  // await getOracleLastPrice()
  // await openPosition()
  // await getPositions()

  const asset = 'ETH'

  // let position = await getPositions(trader)
  // console.log(position)

  const dex = await openPosition(asset, 'buy', 1)

  await getPositions(trader)
  const liquidatable = await vault.isLiquidatable(trader)
  console.log(liquidatable)

}

if (process.env.NODE_ENV === 'dev') test()
