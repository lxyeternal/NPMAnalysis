require('dotenv').config({ path: '~/.env/crypto-bot.env' })
const { Contract } = require('ethers')
const { parseUnits, formatEther, formatUnits } = require('ethers/lib/utils')
const { Pool } = require('@uniswap/v3-sdk')
const { Token } = require('@uniswap/sdk-core')
const JSBI = require('jsbi')

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

const DEFAULT_DECIMALS = 18

let clearingHouse, exchange, vault, accountBalance, layer2Provider

const poolAbi =
  require('@uniswap/v3-core/artifacts/contracts/interfaces/IUniswapV3Pool.sol/IUniswapV3Pool.json').abi

const deposit = async () => {
  const options = {
    gasLimit: 3_000_000,
  }

  // Need allowance first
  const tx = await vault.deposit(usdcAddr, parseUnits('90'), options)
  const result = await tx.wait()
  console.log(result)
}


const getOracleLastPrice = async (oracleAddr) => {
  try {
    const aggregatorV3InterfaceABI = [
      {
        inputs: [],
        name: 'decimals',
        outputs: [{ internalType: 'uint8', name: '', type: 'uint8' }],
        stateMutability: 'view',
        type: 'function',
      },
      {
        inputs: [
          {
            internalType: 'uint256',
            name: 'interval',
            type: 'uint256',
          },
        ],
        name: 'getPrice',
        outputs: [{ internalType: 'uint256', name: '', type: 'uint256' }],
        stateMutability: 'view',
        type: 'function',
      },
    ]
    const addr = oracleAddr || '0xa36faf16f31c12285467b1973ee8fa144ed4d846'
    const priceFeed = new Contract(
      addr,
      aggregatorV3InterfaceABI,
      layer2Provider
    )
    const result = await priceFeed.getPrice(0)
    return parseFloat(formatUnits(result, 8))
  } catch (error) {
    console.log(error)
    throw error
  }
}

const uniswapTest = async (poolAddr) => {
  const poolAddress = poolAddr || '0x36B18618c4131D8564A714fb6b4D2B1EdADc0042' // vETH
  const poolContract = new Contract(poolAddress, poolAbi, layer2Provider)

  const [factory, token0, token1, fee, tickSpacing, maxLiquidityPerTick] =
    await Promise.all([
      poolContract.factory(),
      poolContract.token0(),
      poolContract.token1(),
      poolContract.fee(),
      poolContract.tickSpacing(),
      poolContract.maxLiquidityPerTick(),
    ])

  const immutables = {
    factory,
    token0,
    token1,
    fee,
    tickSpacing,
    maxLiquidityPerTick,
  }

  const [liquidity, slot] = await Promise.all([
    poolContract.liquidity(),
    poolContract.slot0(),
  ])

  const state = {
    liquidity,
    sqrtPriceX96: slot[0],
    tick: slot[1],
    observationIndex: slot[2],
    observationCardinality: slot[3],
    observationCardinalityNext: slot[4],
    feeProtocol: slot[5],
    unlocked: slot[6],
  }

  const TokenA = new Token(10, immutables.token0, 18, 'USDC', 'USD Coin')

  const TokenB = new Token(10, immutables.token1, 18, 'vETH', 'vEther')

  const poolExample = new Pool(
    TokenA,
    TokenB,
    immutables.fee,
    state.sqrtPriceX96.toString(),
    state.liquidity.toString(),
    state.tick
  )

  let sqrtPriceX96 = state.sqrtPriceX96
  let number_1 =
    (sqrtPriceX96 ** 2 * 1e18) / 1e18 / JSBI.BigInt(2) ** JSBI.BigInt(192)

  const token0Price = poolExample.token0Price
  const token1Price = poolExample.token1Price

  console.log(
    poolExample,
    token0Price.numerator.toString(),
    token1Price.numerator.toString()
  )
  console.log(immutables.token0, immutables.token1)
  console.log(number_1)
}
