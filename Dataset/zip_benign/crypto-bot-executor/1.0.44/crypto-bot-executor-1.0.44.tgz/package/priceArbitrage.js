const { Exchange } = require('crypto-bot-libs/services/exchanges')

const ENV = process.argv[2]
const EXCHANGEA = process.argv[3]
const EXCHANGEB = process.argv[4]
const ASSET = process.argv[5]
const AMOUNT = parseFloat(process.argv[6])
const TRIGGER_LONG = parseFloat(process.argv[7])
const TRIGGER_SHORT = parseFloat(process.argv[8])
const POSITION = parseInt(process.argv[9])
const VERBOSE = process.argv[10] === '1'

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

/**
 * node priceArbitrage.js STAGING FTX PERPETUAL ETH 0.5 0.3 0 1 1
 */
const run = async () => {
  const ftx = new Exchange(EXCHANGEA, ENV)
  await ftx.init()

  const perp = new Exchange(EXCHANGEB, ENV)
  await perp.init()

  const dryRun = false
  let position = POSITION
  let finalAmount = AMOUNT / 2

  while (true) {
    if (position !== 0) {
      finalAmount = AMOUNT
    }
    try {
      const ftxPrice = ftx.getMarket(`${ASSET}-PERP`)
      const perpPrice = perp.getMarket(`v${ASSET}`)

      const [p1, p2] = await Promise.all([ftxPrice, perpPrice])

      const spread = (p2.last / p1.last - 1) * 100
      if (VERBOSE) {
        console.log(
          new Date(),
          p1.last.toFixed(6),
          p2.last.toFixed(6),
          spread.toFixed(3)
        )
      }

      if (spread < TRIGGER_SHORT && position >= 0) {
        console.log(
          new Date(),
          `Triggered open position, buy ${EXCHANGEB} sell ${EXCHANGEA}`,
          p1.last.toFixed(6),
          p2.last.toFixed(6),
          spread.toFixed(3)
        )
        if (!dryRun) {
          const dex = perp.placeOrder(
            `v${ASSET}`,
            'buy',
            'market',
            finalAmount,
            p2.last
          )
          const cex = ftx.placeOrder(
            `${ASSET}-PERP`,
            'sell',
            'market',
            finalAmount,
            p1.last
          )
          await Promise.all([dex, cex])
        }
        position = -1
      } else if (spread > TRIGGER_LONG && position <= 0) {
        console.log(
          new Date(),
          `Triggered open position, sell ${EXCHANGEB} buy ${EXCHANGEA}`,
          p1.last.toFixed(6),
          p2.last.toFixed(6),
          spread.toFixed(3)
        )
        if (!dryRun) {
          const dex = perp.placeOrder(
            `v${ASSET}`,
            'sell',
            'market',
            finalAmount,
            p2.last
          )
          const cex = ftx.placeOrder(
            `${ASSET}-PERP`,
            'buy',
            'market',
            finalAmount,
            p1.last
          )
          await Promise.all([dex, cex])
        }
        position = 1
      }

      await delay(1500)
    } catch (error) {
      console.log(error)
      process.exit()
    }
  }
}

console.log(
  ENV,
  EXCHANGEA,
  EXCHANGEB,
  ASSET,
  AMOUNT,
  TRIGGER_LONG,
  TRIGGER_SHORT,
  POSITION,
  VERBOSE
)

const main = async () => {
  await run()
}

main()
