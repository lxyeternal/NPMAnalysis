const { Exchange } = require('./services/exchanges')
const { WebsocketExchange } = require('./services/wsExchanges')
const perpv2 = require('@perp')

const main = async () => {}
let start = false

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

/**
 * Open a position in two exchanges, exchange A will be called by normal api, exchange B will be called by websocket running on exchange A
 * @param  {[type]} arg1 [description]
 * @param  {[type]} arg2 [description]
 * @return {[type]}      [description]
 */
const openPosition = async (
  exchangeA,
  exchangeB,
  symbolA,
  symbolB,
  size=1,
  minimumSpread=0.05
) => {
  start = true
  const exchange = new Exchange(exchangeA)
  const wsExchange = new WebsocketExchange(exchangeA)

  await exchange.init()
  await wsExchange.init(exchangeB, symbolB, size, 'sell')

  while (start) {
    const result = await Promise.all([
      exchange.getMarket(symbolA),
      exchange.getMarket(symbolB)
    ])
    console.log(`Spread ${Math.abs(1 - (result[0].ask / result[1].bid))*100}`)
    if (Math.abs(1 - (result[0].ask / result[1].bid))*100 < minimumSpread) {
      // TODO: Place order
      console.log('Open position')
      await exchange.placeOrder(symbolA, 'buy', 'market', 1)
      break
    }
  }
  console.log('Finished1')
}

const openPositionDesc = async () => {
  
}

const test = async () => {
  let result = openPosition('FTX', 'BINANCE', 'UNI-PERP', 'UNIUSDT', 5)
  // await delay(5000)
  // start = false
  // console.log('Finished2')
}

if (process.env.NODE_ENV === 'dev') test()
