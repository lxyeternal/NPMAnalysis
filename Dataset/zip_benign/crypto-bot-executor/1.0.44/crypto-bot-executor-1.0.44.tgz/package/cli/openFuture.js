#!/usr/bin/env node
const { Exchange } = require('crypto-bot-libs/services/exchanges')

const ENV = process.argv[2] || 'PRODUCTION'
const EXCHANGE = process.argv[3] || 'BINANCE'
const SIDE = process.argv[4] || 'buy'
const SYMBOL = process.argv[5] || 'ETHUSD_230630'
const AMOUNT = parseFloat(process.argv[6]) || 1
/**
 * node openFuture.js PRODUCTION FTX buy ETH 0.1
 */
const openPosition = async () => {
  const exch = new Exchange(EXCHANGE, ENV)
  await exch.init()

  try {
    await exch.placeOrder(SYMBOL, SIDE, 'market', AMOUNT, 0)
  } catch (error) {
    console.log(error)
  }

  process.exit()
}

console.log(ENV, EXCHANGE, SIDE, SYMBOL, AMOUNT)
openPosition()
