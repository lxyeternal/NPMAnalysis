#!/usr/bin/env node
const { Exchange } = require('crypto-bot-libs/services/exchanges')
const player = require('play-sound')((opts = {}))

const bot = require('../services/message')
const channel = -690779964

const ENV = process.argv[2]
const EXCHANGEA = process.argv[3]
const EXCHANGEB = process.argv[4]
const ASSET = process.argv[5]
const AMOUNT = parseFloat(process.argv[6])
let TOTAL = parseFloat(process.argv[7])
const TRIGGER = parseFloat(process.argv[8])
const DRYRUN = process.argv[9] === '1'
const VERBOSE = process.argv[10] === '1'

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

const playBegin = () => {
  player.play(`${__dirname}/../resources/sounds/start.mp3`, function (err) {
    if (err) throw err
  })
}

const playEnd = () => {
  player.play(`${__dirname}/../resources/sounds/finish.mp3`, function (err) {
    if (err) throw err
  })
}

/**
 * node crossArb.js STAGING FTX PERPETUAL ETH 0.5 2 0.3 1 1
 */
const openPosition = async () => {
  const exch1 = new Exchange(EXCHANGEA, ENV)
  await exch1.init()

  const exch2 = new Exchange(EXCHANGEB, ENV)
  await exch2.init()
  let current, last

  while (true) {
    try {
      current = new Date()
      const symbol1 = exch1.getSymbol(ASSET)
      const symbol2 = exch2.getSymbol(ASSET)

      const exch1Price = exch1.getMarket(symbol1)
      const exch2Price = exch2.getMarket(symbol2)

      let [p1, p2] = [null, null]

      try {
        ;[p1, p2] = await Promise.all([exch1Price, exch2Price])
      } catch (error) {
        console.log(error)
        continue
      }

      const spread = (p2.bid / p1.ask - 1) * 100
      last = new Date()
      if (VERBOSE) {
        console.log(
          last,
          exch1.name,
          exch2.name,
          ASSET,
          p1.ask.toFixed(6),
          p2.bid.toFixed(6),
          spread.toFixed(3),
          last - current
        )
      }

      if (spread > TRIGGER && last - current <= 10 * 1000) {
        console.log('Triggered open position')
        if (!DRYRUN) {
          playBegin()
          const order1 = exch2.placeOrder(
            symbol2,
            'sell',
            'market',
            AMOUNT,
            p2.bid
          )
          const order2 = exch1.placeOrder(
            symbol1,
            'buy',
            'market',
            AMOUNT,
            p1.ask
          )
          await Promise.all([order1, order2])
          playEnd()
          const message = `❗ Cross Arb *${exch1.name}* *${exch2.name}* ASSET: *${ASSET}* SPREAD: ${spread} TRIGGER: *${TRIGGER}* AMOUNT: *${AMOUNT}* - P1: *${p1.ask}* P2 *${p2.bid}*`
          await bot.sendMessage(channel, message)
        }

        TOTAL -= AMOUNT
        console.log('MISSING ', TOTAL)
      }

      if (TOTAL <= 0) {
        console.log('Finish ', TOTAL)
        break
      }
      await delay(1500)
    } catch (error) {
      console.log(error)
      break
    }
  }
  await delay(60 * 1000)
  process.exit()
}

console.log(
  ENV,
  EXCHANGEA,
  EXCHANGEB,
  ASSET,
  AMOUNT,
  TOTAL,
  TRIGGER,
  DRYRUN,
  VERBOSE
)
openPosition()
