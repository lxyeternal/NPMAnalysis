#!/usr/bin/env node
const utils = require('crypto-bot-libs/utils/utils')
const db = require('crypto-bot-libs/services/db')
const bot = require('../services/message')

const moment = require('moment')

const MESSAGE = parseInt(process.argv[2]) == 1 || false

/**
 * node report.js  0
 */
const paymentReport = async () => {
  try {
    const channel = await utils.getTelegramChannel('REPORT')
    const payments = await db.query(
      'select account, exchange, asset, sum(payment) from crypto.payments p where date(p."date") = current_date group by account, exchange, asset'
    )

    const total = await db.query(
      'select sum(payment) from crypto.payments p where date(p."date") = current_date'
    )

    console.log(JSON.parse(payments).rows)

    const paymentMessages = JSON.parse(payments).rows.map(async (p) => {
      const message = `❗ Payments ${p.exchange} ACC: ${p.account} ASSET: ${
        p.asset
      } PAYMENT: ${parseFloat(p.sum).toFixed(2)}`
      if (MESSAGE) {
        await bot.sendMessage(channel, message)
      }
    })
    await Promise.all(paymentMessages)

    const totalMessage = JSON.parse(total).rows.map(async (p) => {
      const message = `❗ TOTAL ${parseFloat(p.sum).toFixed(2)}`
      if (MESSAGE) {
        await bot.sendMessage(channel, message)
      }
    })
    await Promise.all(totalMessage)
  } catch (error) {
    console.log(error)
  }

  process.exit()
}

paymentReport()
