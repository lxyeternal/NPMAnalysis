#!/usr/bin/env node
const utils = require('crypto-bot-libs/utils/utils')
const { Exchange } = require('crypto-bot-libs/services/exchanges')
const db = require('crypto-bot-libs/services/db')

const moment = require('moment')

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

const EXCHANGE = process.argv[2] || 'ALL'
const TYPE = process.argv[3] || 'HISTORICAL' // LASTHOUR
const FROM = parseInt(process.argv[4]) || 15
const TO = parseInt(process.argv[5]) || -1


const getFundings = async (payload) => {
  const exchange = payload.exchange
  const symbol = payload.symbol
  const start = payload.start
  const end = payload.end
  const period = payload.period || 24
  const save = payload.save || false
  const limit = payload.limit

  const fundingsByPeriod = await getFundingsByPeriod(
    exchange,
    symbol,
    start,
    end,
    period,
    limit
  )

  const asset = new Exchange(exchange).getAsset(symbol)

  const fundingsBulk = fundingsByPeriod.map((r) => [
    r.time,
    exchange,
    asset,
    r.symbol,
    r.type,
    r.rate,
  ])

  if (fundingsBulk.length === 0) {
    // console.log('Erro')
    return fundingsByPeriod
  }

  if (save) {
    await db.insertFundingBulk(fundingsBulk)
  }
  return fundingsByPeriod
}

const getFundingsByExchange = async (payload) => {
  const exchange = payload.exchange
  const start = payload.start
  const end = payload.end
  const limit = payload.limit
  const instruments = await new Exchange(exchange).getFutureInstruments()

  const lambdas = instruments.map((p) => {
    const payload = {
      exchange,
      symbol: p.name,
      start,
      end,
      limit,
      period: 24,
      save: true,
    }

    return getFundings(payload)
  })

  await Promise.all(lambdas)
  return { instruments: instruments.length, inserts: lambdas.length }
}

const getHistoricalFundings = async (period = 24) => {
  let exchanges = null
  if (EXCHANGE === 'ALL') exchanges = await utils.getExchanges()
  else exchanges = [EXCHANGE]

  const results = exchanges.map(async (p) => {
    console.log(p)

    const payload = {
      route: 'fundingsByExchange',
      payload: {
        exchange: p,
        start: 0,
        end: 0,
      },
    }

    for (let day = FROM; day >= TO; day--) {
      let tempDate = moment()
        .add(-1 * day, 'DAYS')
        .format('YYYYMMDD')
      let start = moment.utc(tempDate).unix() - 1
      let end = start + period * 3600

      console.log(start, end)
      console.log(new Date(start * 1000), new Date(end * 1000))

      payload.payload.start = start
      payload.payload.end = end

      const results = await getFundingsByExchange(payload.payload)
      console.log(results)
      await delay(3 * 1000)
    }
  })
  await Promise.all(results)
}

const getFundingsLastHour = async (utcDate) => {
  let exchanges = null
  if (EXCHANGE === 'ALL') exchanges = await utils.getExchanges()
  else exchanges = [EXCHANGE]

  const tasks = exchanges.map((exchange) => {
    let utc = null

    utc = new Date()

    if (utcDate) utc = new Date(utcDate * 1000)

    let start =
      Date.UTC(
        utc.getUTCFullYear(),
        utc.getUTCMonth(),
        utc.getUTCDate(),
        utc.getUTCHours()
      ) /
        1000 -
      1
    let end = start + 1 * 3600 - 1

    console.log(
      exchange,
      new Date(start * 1000).toUTCString(),
      new Date(end * 1000).toUTCString()
    )
    const payload = {
      route: 'fundingsByExchange',
      payload: {
        exchange: exchange,
        start: start,
        end: end,
        limit: 1,
      },
    }
    return getFundingsByExchange(payload.payload)
  })
  await Promise.all(tasks)
}

/**
 *
 * @param {string} exchange Exchange name {FTX|BINANCE|DYDX}
 * @param {string} symbol Future symbol {BTC-PERP, BTCUSDT}
 * @param {int} start Start date unix time
 * @param {int} end End date unix time
 * @param {int} period Period in hours
 * @param {int} limit Limit per call
 * @returns
 */
const getFundingsByPeriod = async (
  exchange,
  symbol,
  start,
  end,
  period = 24,
  limit
) => {
  const client = new Exchange(exchange)
  const iteractions = Math.ceil((end - start) / (period * 3600))
  let fundings = []

  for (let i = 1; i <= iteractions; i++) {
    let startCalc = start + (i - 1) * period * 3600
    let endCalc = start + i * period * 3600 - 5 * 60
    if (i === iteractions) endCalc = end - 5 * 60

    fundings.push(
      ...(await client.getFundingRates(symbol, startCalc, endCalc, limit))
    )
  }
  return fundings
}

const main = async () => {
  if (TYPE === 'HISTORICAL') await getHistoricalFundings()
  else if (TYPE === 'LASTHOUR') await getFundingsLastHour()
  else console.log('type must be HISTORICAL or LASTHOUR')

  process.exit()
}

main()
