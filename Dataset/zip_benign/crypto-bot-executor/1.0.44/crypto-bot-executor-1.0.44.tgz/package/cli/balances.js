#!/usr/bin/env node
const { Exchange } = require('crypto-bot-libs/services/exchanges')
const db = require('crypto-bot-libs/services/db')
const bot = require('../services/message')

const moment = require('moment')
const channel = -690779964

const ENV = process.argv[2] || 'STAGING'
const EXCHANGE = process.argv[3] || 'FTX'
const ASSET = process.argv[4] || 'ETH'
const MESSAGE = parseInt(process.argv[5]) == 1 || false
const DB = parseInt(process.argv[6]) == 1 || false

/**
 * node balances.js STAGING FTX USD 0
 */
const getBalances = async () => {
  const exch = new Exchange(EXCHANGE, ENV)
  await exch.init()

  try {
    const balance = await exch.getBalance(ASSET)

    const message = `❗ Balances ${
      exch.name
    } ACC: ${ENV} ASSET: ${ASSET} BALANCE: ${balance.total.toFixed(2)}`
    if (MESSAGE) {
      await bot.sendMessage(channel, message)
    }
    console.log(message)
    if (DB) {
      await db.insertBalance(
        new moment.utc(),
        ASSET,
        balance.total,
        balance.total,
        ENV,
        EXCHANGE
      )
    }
  } catch (error) {
    console.log(error)
  }

  process.exit()
}

getBalances()
