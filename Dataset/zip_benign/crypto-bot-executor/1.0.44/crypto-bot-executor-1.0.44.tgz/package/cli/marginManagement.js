#!/usr/bin/env node
const { Exchange } = require('crypto-bot-libs/services/exchanges')
const utils = require('crypto-bot-libs/utils/utils')
const player = require('play-sound')((opts = {}))

const bot = require('../services/message')

const playBegin = () => {
  player.play(`${__dirname}/../resources/sounds/start.mp3`, function (err) {
    if (err) throw err
  })
}

const playEnd = () => {
  player.play(`${__dirname}/../resources/sounds/finish.mp3`, function (err) {
    if (err) throw err
  })
}

const ENV = process.argv[2] || 'PRODUCTION'
const EXCHANGEA = process.argv[3] || 'FTX'
const EXCHANGEB = process.argv[4] || 'PERPETUAL'
const ASSET = process.argv[5] || 'ETH'
const AMOUNT_USD = parseFloat(process.argv[6]) || 3000
const TRIGGER = parseFloat(process.argv[7]) || 6
const DRYRUN = process.argv[8] === '1' || false
const VERBOSE = process.argv[9] === '1' || false

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

/**
 * Exchange A always being LONG
 * Exchange B always being SHORT
 * node marginManagement.js STAGING FTX PERPETUAL ETH 2000 6 1 1
 */
const marginManagement = async () => {
  const channel = await utils.getTelegramChannel('MARGIN')
  const exch1 = new Exchange(EXCHANGEA, ENV)
  await exch1.init()

  const exch2 = new Exchange(EXCHANGEB, ENV)
  await exch2.init()

  try {
    const symbol1 = exch1.getSymbol(ASSET)
    const symbol2 = exch2.getSymbol(ASSET)
    const exch1Leverage = exch1.getLeverage(symbol1)
    const exch2Levarege = exch2.getLeverage(symbol2)
    const exch1Position = exch1.getPosition(symbol1)
    const exch2Position = exch2.getPosition(symbol2)
    const exch1Market = exch1.getMarket(symbol1)
    const exch2Market = exch2.getMarket(symbol2)

    const [l1, l2, price1, price2, pos1, pos2] = await Promise.all([
      exch1Leverage,
      exch2Levarege,
      exch1Market,
      exch2Market,
      exch1Position,
      exch2Position,
    ])
    const amount = parseFloat((AMOUNT_USD / price1.last).toFixed(4))

    let messageBefore = `❗ Margin Management *Attempt* *${
      exch1.name
    }* POS: *${pos1.toFixed(3)}* LEV: *${l1.toFixed(3)}* - *${
      exch2.name
    }* POS: *${pos2.toFixed(3)}* LEV: *${l2.toFixed(
      3
    )}* - TRIGGER: *${TRIGGER}*  AMOUNT *${amount}*`
    await bot.sendMessage(channel, messageBefore, {
      parse_mode: 'markdown',
    })

    if (l1 > TRIGGER || l2 > TRIGGER) {
      console.log('Placing order')
      if (!DRYRUN) {
        playBegin()
        const order1 = exch1.placeOrder(
          symbol1,
          'buy',
          'market',
          amount,
          price1.last
        )
        const order2 = exch2.placeOrder(
          symbol2,
          'sell',
          'market',
          amount,
          price2.last
        )
        await Promise.all([order1, order2])
        playEnd()
        const message = `❗ Margin Management *Execution* *${
          exch1.name
        }* POS: *${pos1.toFixed(3)}* LEV: *${l1.toFixed(3)}* - *${
          exch2.name
        }* POS: *${pos2.toFixed(3)}* LEV: *${l2.toFixed(
          3
        )}* - TRIGGER: *${TRIGGER}*  AMOUNT *${amount}*`
        await bot.sendMessage(channel, message)
      }
    }
  } catch (error) {
    console.log(error)
  }
  process.exit()
}

marginManagement()
