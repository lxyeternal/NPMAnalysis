#!/usr/bin/env node
const ccxt = require('ccxt')
const { getKey } = require('crypto-bot-libs/utils/utils')

const ENV = process.argv[2] || 'PRODUCTION'
const EXCHANGE = process.argv[3] || 'BINANCE'
const SYMBOL1 = process.argv[4] || 'ETHUSD_230630'
const SYMBOL2 = process.argv[5] || 'ETHUSD_230331'
const AMOUNT = parseFloat(process.argv[6]) || 1
let TOTAL = parseFloat(process.argv[7]) || 1
const TRIGGER = parseFloat(process.argv[8]) || -1
const DRYRUN = process.argv[9] === '1' || false
const VERBOSE = process.argv[10] === '1' || false

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

/**
 * Simple Arbitrage Between Spot and USDT Future
 * node simpleArb.js PRODUCTION BINANCE ETH/BUSD ETH/USDT:USDT 0.1 0.1 0.3 0 1
 */
async function main() {
  let current, last
  const keys = await getKey(EXCHANGE, ENV)
  // Set your Binance API keys
  const binance = new ccxt.binance({
    apiKey: keys['KEY'],
    secret: keys['SECRET'],
  })

  // Markets
  // const markets = await binance.loadMarkets(true)
  
  while (true) {
    current = new Date()
    // Fetch the last price for ETHUSD_230331 and ETHUSD_230630
    const [p1, p2] = await Promise.all([
      binance.fetchOrderBook(SYMBOL1),
      binance.fetchOrderBook(SYMBOL2),
    ])

    // Calculate the difference between the last prices
    const spread = (p2.bids[0][0] / p1.asks[0][0] - 1) * 100

    last = new Date()
    console.log(
      last.toISOString(),
      EXCHANGE,
      SYMBOL1,
      p1.asks[0][0],
      SYMBOL2,
      p2.bids[0][0],
      spread.toFixed(3),
      last - current
    )

    if (spread > TRIGGER && last - current <= 10 * 1000) {
      console.log('Triggered open position')
      if (!DRYRUN) {
        try {
          // Place market order to buy ETHUSD_230331
          const order1 = binance.createOrder(SYMBOL1, 'market', 'buy', AMOUNT)
          const order2 = binance.createOrder(
            SYMBOL2,
            'market',
            'sell',
            AMOUNT
          )

          await Promise.all([order1, order2])
          console.log('Market order to buy ETHUSD_230331 placed successfully.')
          console.log('Market order to sell ETHUSD_230630 placed successfully.')
        } catch (error) {
          console.error(error.message)
        }
      }
      TOTAL -= AMOUNT
      console.log('TOTAL ', TOTAL)
    }
    if (TOTAL <= 0) {
      console.log('Finish ', TOTAL)
      break
    }
    await delay(2000)
  }
}

console.log(
  ENV,
  EXCHANGE,
  SYMBOL1,
  SYMBOL2,
  AMOUNT,
  TOTAL,
  TRIGGER,
  DRYRUN,
  VERBOSE
)
main()
