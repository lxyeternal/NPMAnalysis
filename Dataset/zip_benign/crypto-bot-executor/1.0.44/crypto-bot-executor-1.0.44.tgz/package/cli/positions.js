#!/usr/bin/env node
const { Exchange } = require('crypto-bot-libs/services/exchanges')
const db = require('crypto-bot-libs/services/db')

const ENV = process.argv[2] || 'PRODUCTION'
const EXCHANGE = process.argv[3] || 'FTX'

/**
 * positions - Get current positions
 */
const positions = async () => {
  try {
    const client = new Exchange(EXCHANGE, ENV)
    await client.init()

    const positions = await client.getPositions()

    const positionsBulk = positions.map((r) => [
      // date, exchange, asset, symbol, account, total, side, notional
      new Date(),
      r.exchange,
      r.asset,
      r.symbol,
      r.account,
      r.total,
      r.side,
      r.notional,
    ])

    if (positionsBulk.length === 0) {
      // console.log('Erro')
      return []
    }

    await db.insertPositionsBulk(positionsBulk)
  } catch (error) {
    console.log(error)
  }

  console.log('Positions succesfully retrieved')
  process.exit()
}

positions()
