#!/usr/bin/env node
const { getKey } = require('crypto-bot-libs/utils/utils')
const db = require('crypto-bot-libs/services/db')

const Binance = require('node-binance-api')

const moment = require('moment')

const EXCHANGE = process.argv[2] || 'BINANCE'
const PERPETUO_EXCHANGE = process.argv[3] || 'BINANCE'
// const PERPETUO_EXCHANGE = process.argv[2] || 'BINANCE-USDT'

// Settlement price: The settlement price used for delivery of contracts will be calculated as the average of the price index every second over the last hour (between 7.00 and 08.00 UTC) before delivery, i.e. total 3600 price index.
// Settlement time 8:00AM UTC
// Futures
// USDT - ETHUSDT
// USDT Delivery ETHUSDT_220930
// BUSD - ETHBUSD
// Futures not USDT or BUSD
// COIN Perpetual ETHUSD_PERP
// Delivery ETHUSD_221230

const mainBinance = async (perpetuoExchange) => {
  try {
    const keys = await getKey('BINANCE', 'PRODUCTION')

    let client = new Binance().options({
      APIKEY: keys.KEY,
      APISECRET: keys.SECRET,
    })

    const prices = await client.deliveryPrices()
    const deliveries = Object.keys(prices).filter((p) => !p.includes('PERP'))

    const assets = deliveries.map((p) => p.split('_')[0].replace('USD', ''))

    const queryResult = await db.query(
      `select asset, (sum(total)/15)*100 total from crypto.fundings_by_exchange where exchange = '${perpetuoExchange}' and date >= now()  - interval '15 day' and asset = ANY ($1) group by asset`,
      [assets]
    )

    const fundings = JSON.parse(queryResult).rows
    console.log(fundings)

    const merged = deliveries.map((delivery) => {
      const asset = delivery.split('_')[0].replace('USD', '')
      const perpetuo = `${asset}USD_PERP`
      const last = parseFloat(prices[delivery])
      const index = parseFloat(prices[perpetuo])
      const basis = (last / index - 1) * 100
      const expiry = moment(`20${delivery.split('_')[1]}T080000Z`).toISOString()
      const dateDiff =
        (moment(`20${delivery.split('_')[1]}`) - moment.now()) /
        1000 /
        (3600 * 24)

      console.log(asset)
      const funding = parseFloat(
        fundings.filter((p) => p.asset === asset)[0] == undefined
          ? 0
          : fundings.filter((p) => p.asset === asset)[0]['total']
      )

      const expectedFunding = dateDiff * funding

      const apyBasis = (Math.abs(basis) * 365) / dateDiff
      const apyFunding = (Math.abs(expectedFunding) * 365) / dateDiff
      let diff = 0

      if (basis * expectedFunding < 0) {
        diff = apyBasis + apyFunding
      } else {
        diff =
          apyBasis - apyFunding > apyFunding - apyBasis
            ? apyFunding - apyBasis
            : apyBasis - apyFunding
      }

      return [
        moment.utc().toISOString(),
        'BINANCE-COIN',
        PERPETUO_EXCHANGE,
        asset,
        delivery,
        perpetuo,
        last,
        index,
        basis,
        funding,
        expiry,
        dateDiff,
        expectedFunding,
        apyBasis,
        apyFunding,
        diff,
      ]
    })
    console.log(merged)

    await db.insertDeliveriesApyBulk(merged)
  } catch (error) {
    console.log(error)
  }
}


if (EXCHANGE === 'BINANCE') mainBinance(PERPETUO_EXCHANGE)
