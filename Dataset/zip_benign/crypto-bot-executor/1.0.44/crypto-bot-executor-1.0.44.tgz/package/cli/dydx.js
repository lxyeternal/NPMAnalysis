#!/usr/bin/env node
const {
  DydxClient,
  Asset,
  Market,
  OrderSide,
  OrderType,
  TimeInForce,
  PositionStatus,
} = require('@dydxprotocol/v3-client')
const Web3 = require('web3')

const HTTP_HOST = 'https://api.dydx.exchange'

const ccxt = require('ccxt')
const { getKey } = require('crypto-bot-libs/utils/utils')
const player = require('play-sound')((opts = {}))

let client1,
  client2 = null

const web3 = new Web3()

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms))


const playBegin = () => {
  player.play(`${__dirname}/../resources/sounds/start.mp3`, function (err) {
    if (err) throw err
  })
}

const playEnd = () => {
  player.play(`${__dirname}/../resources/sounds/finish.mp3`, function (err) {
    if (err) throw err
  })
}

const ENV = process.argv[2] || 'PRODUCTION'
const EXCHANGE1 = process.argv[3] || 'BINANCE'
const EXCHANGE2 = process.argv[4] || 'DYDX'
const SYMBOL1 = process.argv[5] || 'SOLUSDT'
const SYMBOL2 = process.argv[6] || 'SOL_USD'
const AMOUNT = parseFloat(process.argv[7]) || 1
let TOTAL = parseFloat(process.argv[8]) || 1
const TRIGGER = parseFloat(process.argv[9]) || 0.24
const DRYRUN = process.argv[10] === '1' || false
const VERBOSE = process.argv[11] === '1' || true

const init = async () => {
  const keys1 = await getKey(EXCHANGE1, ENV)
  const keys2 = await getKey(EXCHANGE2, ENV)

  switch (EXCHANGE1) {
    case 'BINANCE':
      client1 = new ccxt.binanceusdm({
        apiKey: keys1['KEY'],
        secret: keys1['SECRET'],
      })
      client1.name = 'BINANCE'
      break
    case 'DYDX': {
      web3.eth.accounts.wallet.add(keys1['SECRET'])
      client1 = new DydxClient(HTTP_HOST, { web3 })
      client1.ethWallet = keys1['KEY']
      const apiCreds = await client1.onboarding.recoverDefaultApiCredentials(
        client1.ethWallet
      )

      const starkKeys = await client1.onboarding.deriveStarkKey(
        client1.ethWallet
      )

      client1.apiKeyCredentials = apiCreds
      client1.starkPrivateKey = starkKeys.privateKey
      client1.name = 'DYDX'
      break
    }
  }

  switch (EXCHANGE2) {
    case 'BINANCE':
      client2 = new ccxt.binanceusdm({
        apiKey: keys2['KEY'],
        secret: keys2['SECRET'],
      })
      client2.name = 'BINANCE'
      break
    case 'DYDX': {
      web3.eth.accounts.wallet.add(keys2['SECRET'])
      client2 = new DydxClient(HTTP_HOST, { web3 })
      client2.ethWallet = keys2['KEY']
      const apiCreds = await client2.onboarding.recoverDefaultApiCredentials(
        client2.ethWallet
      )

      const starkKeys = await client2.onboarding.deriveStarkKey(
        client2.ethWallet
      )

      client2.apiKeyCredentials = apiCreds
      client2.starkPrivateKey = starkKeys.privateKey
      client2.name = 'DYDX'
      break
    }
  }
}

const positions = async (market) => {
  const positions = await client1.private.getPositions({
    market,
    status: PositionStatus.OPEN,
  })

  console.log(positions)
}

const placeOrder = async (client, symbol, side, price, amount) => {
  let placedOrder
  switch (client.name) {
    case 'BINANCE':
      placedOrder = await client.createOrder(symbol, 'market', side, amount)
      break
    case 'DYDX': {
      const account = await client.private.getAccount(client.ethWallet)

      const order = {
        market: Market[symbol],
        side: OrderSide[side.toUpperCase()],
        type: OrderType.MARKET,
        postOnly: false,
        size: amount.toString(),
        price: price.toFixed(2),
        limitFee: '0.015',
        timeInForce: TimeInForce.FOK,
        expiration: '2023-12-21T21:30:20.200Z',
      }

      placedOrder = await client.private.createOrder(
        order,
        account.account.positionId
      )
      break
    }
  }

  return placedOrder
}

const getOrderBook = async (client, symbol) => {
  let orderBook = null
  switch (client.name) {
    case 'BINANCE':
      orderBook = client.fetchOrderBook(symbol)
      break
    case 'DYDX': {
      orderBook = client.public.getOrderBook(Market[symbol])
      break
    }
  }
  return orderBook
}

const main = async () => {
  let current, last
  await init()
  // await positions(Market.ETH_USD)
  // await placeOrder(order)

  while (true) {
    current = new Date()

    const [orderBook1, orderBook2] = await Promise.all([
      getOrderBook(client1, SYMBOL1),
      getOrderBook(client2, SYMBOL2),
    ])

    let p1, p2

    if (client1.name === 'BINANCE') {
      p1 = orderBook1.asks[0][0]
      p2 = parseFloat(orderBook2.bids[0].price)
    } else if (client1.name === 'DYDX') {
      p1 = parseFloat(orderBook1.asks[0].price)
      p2 = orderBook2.bids[0][0]
    }
    const spread = (p2 / p1 - 1) * 100

    last = new Date()
    console.log(
      last.toISOString(),
      EXCHANGE1,
      SYMBOL1,
      p1,
      EXCHANGE2,
      SYMBOL2,
      p2,
      spread.toFixed(3),
      last - current
    )
    if (spread > TRIGGER && last - current <= 1 * 1000) {
      console.log('Triggered')
      if (!DRYRUN) {
        playBegin()
        const [order1, order2] = await Promise.all([placeOrder(client1, SYMBOL1, 'buy', p1*1.1, AMOUNT), placeOrder(client2, SYMBOL2, 'sell', p2*0.9, AMOUNT)])
        // console.log(order1, order2)
        const message = `❗ Open Position *${client1.name}* *${client2.name}* SYMBOL1: *${SYMBOL1}* SYMBOL2: *${SYMBOL2}* SPREAD: ${spread} TRIGGER: *${TRIGGER}* AMOUNT: *${AMOUNT}* - P1: *${p1}* P2 *${p2}*`
        console.log(message)
        playEnd()
      }
      TOTAL -= AMOUNT
      console.log('TOTAL ', TOTAL)
    }
    if (TOTAL <= 0) {
      console.log('Finish ', TOTAL)
      break
    }
    await delay(2000)
  }
}

console.log(
  ENV,
  EXCHANGE1,
  EXCHANGE2,
  SYMBOL1,
  SYMBOL2,
  AMOUNT,
  TOTAL,
  TRIGGER,
  DRYRUN,
  VERBOSE
)
main()
