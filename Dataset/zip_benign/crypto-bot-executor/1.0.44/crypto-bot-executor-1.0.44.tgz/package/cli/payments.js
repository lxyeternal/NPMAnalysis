#!/usr/bin/env node
const { Exchange } = require('crypto-bot-libs/services/exchanges')
const db = require('crypto-bot-libs/services/db')

let DAYS_BEFORE = parseFloat(process.argv[2]) || 1.5

const getPayments = async (exchange, symbol, start, end, account) => {
  try {
    console.log(
      exchange,
      symbol,
      new Date(start * 1000),
      new Date(end * 1000),
      account
    )
    const client = new Exchange(exchange, account)
    await client.init()

    const payments = await client.getFundingPayments(symbol, start, end)

    return payments
  } catch (er) {
    console.log(er)
  }
}

const getPaymentsByPeriod = async (
  exchange,
  symbol,
  start,
  end,
  account,
  period = 24
) => {
  const iteractions = Math.ceil((end - start) / (period * 3600))
  let payments = []

  for (let i = 1; i <= iteractions; i++) {
    let startCalc = start + (i - 1) * period * 3600
    let endCalc = start + i * period * 3600
    if (i === iteractions) endCalc = end

    payments.push(
      ...(await getPayments(exchange, symbol, startCalc, endCalc, account))
    )
  }
  return payments
}

const getPaymentsByExchange = async (payload) => {
  const { exchange, assets, start, end, account } = { ...payload }

  const period = payload.period || 24
  const save = payload.save || true

  const exchangeInstance = new Exchange(exchange, account)

  const lambdas = assets.map(async (asset) => {
    const symbol = exchangeInstance.getSymbol(asset)

    const paymentsByPeriod = await getPaymentsByPeriod(
      exchange,
      symbol,
      start,
      end,
      account,
      period
    )

    const paymentsBulk = paymentsByPeriod.map((r) => [
      r.time,
      exchange,
      asset,
      r.symbol,
      account,
      r.rate,
      r.payment,
    ])

    if (paymentsBulk.length === 0) {
      // console.log('Erro')
      return paymentsByPeriod
    }

    if (save) {
      await db.insertPaymentsBulk(paymentsBulk)
    }
  })
  await Promise.all(lambdas)
  return { instruments: assets.length, inserts: lambdas.length }
}

/**
 * run - Get payments last day
 */
const run = async () => {
  const payload = {}
  let positions = null
  try {
    positions = JSON.parse(
      await db.query(
        `select exchange, account, jsonb_agg(asset) as assets from crypto.positions where open is true 
        group by exchange, account`
      )
    ).rows
  } catch (error) {
    console.log(error)
  }

  console.log(positions)

  const utc = new Date()

  const start =
    Date.UTC(
      utc.getUTCFullYear(),
      utc.getUTCMonth(),
      utc.getUTCDate(),
      utc.getUTCHours()
    ) /
      1000 -
    DAYS_BEFORE * 24 * 3600
  const end = start + DAYS_BEFORE * 24 * 3600 + 1

  const tasks = positions.map(async (p) => {
    console.log(
      p.exchange,
      new Date(start * 1000).toUTCString(),
      new Date(end * 1000).toUTCString(),
      p.assets,
      p.account
    )

    payload.start = start
    payload.end = end

    const payloadExchange = {
      exchange: p.exchange,
      assets: p.assets,
      account: p.account,
      start,
      end,
    }

    await getPaymentsByExchange(payloadExchange)
  })

  await Promise.all(tasks)

  console.log('Payments succesfully retrieved')
  process.exit()
}

run()
