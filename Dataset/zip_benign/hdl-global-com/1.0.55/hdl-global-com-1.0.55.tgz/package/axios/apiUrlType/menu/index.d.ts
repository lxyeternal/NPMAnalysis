import { GlobalResDataType } from '../globalType';
type menuListType = {
    alias: string;
    category: string;
    clientId: null;
    icon: string;
    key: number;
    menuId: number;
    name: string;
    orderNum: number;
    params: null | string;
    parentId: number;
    parentKey: number;
    perms: null | string;
    sn: string;
    type: number;
    url: string;
    childs: null | menuListType[];
};
type getMenuData = {
    getMenuData: {
        paramsType: {
            username: string;
        };
        resDataType: GlobalResDataType<menuListType[]>;
    };
};
export type menuModuleType = getMenuData;
export {};
