import { GlobalResDataType } from '../globalType';
type login = {
    login: {
        paramsType: {
            username: string;
            password: string;
            encryptFlag: boolean;
            loginType: string;
            deviceId: string;
            validCode: string;
            captchaType: string;
        };
        resDataType: GlobalResDataType<{
            access_token: string;
            refresh_token: null;
            token_type: string;
            scope: string;
            companyCode: string;
            userId: number;
            deptId: number;
            username: string;
            othername: string;
        }>;
    };
};
type logout = {
    logout: {
        paramsType: any;
        resDataType: GlobalResDataType<string>;
    };
};
export type loginModuleType = login & logout;
export {};
