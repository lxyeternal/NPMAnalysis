import { GlobalResDataType } from '../globalType';
type downFile = {
    downFile: {
        paramsType: {
            id: string | number;
            uuid: string | number;
        };
        resDataType: any;
    };
};
type fileUpload = {
    fileUpload: {
        paramsType: {
            file: any;
        };
        resDataType: GlobalResDataType<any>;
    };
};
export type downFileModuleType = downFile & fileUpload;
export {};
