type wsNotify = {
    wsNotify: {
        paramsType: any;
        resDataType: any;
    };
};
type baseSocket = {
    baseSocket: {
        paramsType: any;
        resDataType: any;
    };
};
export type wsModuleType = wsNotify & baseSocket;
export {};
