import { GlobalResDataType, PaginationType } from '../globalType';
type getNoticeUnreadCount = {
    getNoticeUnreadCount: {
        paramsType: any;
        resDataType: GlobalResDataType<{
            total: number;
            type: string;
            itemList: {
                type: string;
                count: number;
            }[];
        }>;
    };
};
type Param = {
    businessKey: string;
    targetType: string;
    processType: string;
    targetId: string;
    processCategory: string;
};
type notice = {
    id: number;
    notifyId: number;
    title: string;
    content: string;
    status: string;
    immortal: string;
    deadline?: any;
    createBy: number;
    createByName: string;
    createTime: string;
    type: string;
    level: string;
    publishTime: string;
    publishBy: number;
    publishByName: string;
    state: string;
    readTime?: any;
    params: Param | null;
};
type noticeListPage = {
    noticeListPage: {
        paramsType: {
            page: number;
            limit: number;
            types: string[];
        };
        resDataType: GlobalResDataType<PaginationType<notice>>;
    };
};
type noticeList = {
    noticeList: {
        paramsType: {
            types: string[];
        };
        resDataType: GlobalResDataType;
    };
};
type noticeRead = {
    noticeRead: {
        paramsType: {
            id: number;
        };
        resDataType: GlobalResDataType<notice[]>;
    };
};
type noticeReadAll = {
    noticeReadAll: {
        paramsType: {
            type: string;
        };
        resDataType: GlobalResDataType;
    };
};
export type noticeModuleType = getNoticeUnreadCount & noticeListPage & noticeList & noticeRead & noticeReadAll;
export {};
