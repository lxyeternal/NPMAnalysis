export type GlobalResDataType<T = any> = {
    resTimestamp: string;
    resCode: string;
    resMsg: string;
    source: null;
    resData: T;
};
export type PaginationType<T = any> = {
    pageNum: number;
    pageSize: number;
    size: number;
    startRow: number;
    endRow: number;
    total: number;
    pages: number;
    list: T[];
    prePage: number;
    nextPage: number;
    isFirstPage: boolean;
    isLastPage: boolean;
    hasPreviousPage: boolean;
    hasNextPage: boolean;
    navigatePages: number;
    navigatepageNums: number[];
    navigateFirstPage: number;
    navigateLastPage: number;
    lastPage: number;
    firstPage: number;
};
export type getPublicKey = {
    getPublicKey: {
        paramsType: any;
        resDataType: GlobalResDataType<string>;
    };
};
export type getDictChild = {
    getDictChild: {
        paramsType: {
            code: string;
        };
        resDataType: GlobalResDataType<{
            id: number;
            detailCode: string;
            detailName: string;
            dictCode: string;
            detailDescn: string;
            value: null;
            param: null;
            companyCode: string;
        }[]>;
    };
};
type GlobalModuleType = getPublicKey & getDictChild;
export default GlobalModuleType;
