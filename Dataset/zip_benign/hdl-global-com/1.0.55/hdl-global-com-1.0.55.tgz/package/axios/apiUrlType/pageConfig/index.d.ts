import { GlobalResDataType } from '../globalType';
type ConfigType = {
    id: number;
    type: string;
    spcId: string;
    code: string;
    label: string;
    dataSource: {
        [K: string]: any;
    };
    prop: {
        [K: string]: any;
    };
    remark: string;
    createTime: string;
    creatorId: number;
    updateTime: string;
    updaterId: number;
    companyCode: string;
};
export type getPageAuth = {
    getPageAuth: {
        paramsType: {
            menuSn: string;
            status: number;
        };
        resDataType: GlobalResDataType<{
            id: number;
            guid: string;
            menuSn: string;
            code: string;
            name: string;
            remark: string;
            status: string;
            createTime: string;
            creatorId: number;
            creatorName?: any;
            updateTime: string;
            updaterId: number;
            updaterName?: any;
            formConfigList?: ConfigType[];
            filterConfigList?: ConfigType[];
            listConfigList?: ConfigType[];
        }[]>;
    };
};
export type pageConfigModuleType = getPageAuth;
export {};
