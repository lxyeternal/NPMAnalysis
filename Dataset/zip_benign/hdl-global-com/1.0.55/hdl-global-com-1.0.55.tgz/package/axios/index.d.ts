import { AxiosRequestConfig, Method } from 'axios';
import { AxiosResponseType } from './type';
export * from './apiUrlType/globalType';
export interface NewAxiosRequestConfig<T extends string, K = any> extends AxiosRequestConfig<K> {
    url: T;
    method?: Method;
    noFormat?: boolean;
    paramsType?: 'data' | 'params';
    aloneFunc?: (...args: any[]) => any;
    orderUrl?: boolean;
}
type ParamsPushNull<T extends Record<string, any>> = {
    [K in keyof T]: T[K] | null;
};
/**
 * @description axios请求封装
 * @param {NewAxiosRequestConfig<ApiUrlKeyType, AxiosResponseType[ApiUrlKeyType]>} obj
 */
export declare const useAxios: <T extends string, K extends { [x in T]: {
    paramsType: any;
    resDataType: any;
}; }>(urlList: Record<T, string>) => <A extends T>(obj: NewAxiosRequestConfig<A, Partial<ParamsPushNull<K[A]["paramsType"]>>>) => Promise<K[A]["resDataType"]>;
export declare const axios: <A extends "getPublicKey" | "getDictChild" | "login" | "logout" | "fileUpload" | "downFile" | "getMenuData" | "getPageAuth" | "getNoticeUnreadCount" | "noticeListPage" | "noticeList" | "noticeRead" | "noticeReadAll" | "wsNotify" | "baseSocket">(obj: NewAxiosRequestConfig<A, Partial<ParamsPushNull<AxiosResponseType[A]["paramsType"]>>>) => Promise<AxiosResponseType[A]["resDataType"]>;
export type useAxiosType = ReturnType<typeof useAxios>;
