import { default as apiUrlList } from './apiUrl';
import { GetArrItemType } from '../utils/type';
import { default as GlobalModuleType } from './apiUrlType/globalType';
import { loginModuleType } from './apiUrlType/login';
import { downFileModuleType } from './apiUrlType/file';
import { menuModuleType } from './apiUrlType/menu';
import { pageConfigModuleType } from './apiUrlType/pageConfig';
import { noticeModuleType } from './apiUrlType/notice';
import { wsModuleType } from './apiUrlType/ws';
export type ApiUrlKeyType = keyof typeof apiUrlList;
export type AxiosResponseType = GlobalModuleType & loginModuleType & downFileModuleType & menuModuleType & pageConfigModuleType & noticeModuleType & wsModuleType;
export type AxiosResultType = {
    [K in ApiUrlKeyType]: AxiosResponseType[K]['resDataType']['resData'];
};
export type AxiosListResultType = {
    [K in ApiUrlKeyType]: AxiosResultType[K] extends {
        list: infer I;
    } ? GetArrItemType<I> : AxiosResultType[K];
};
export type AxiosResultItemType = {
    [K in ApiUrlKeyType]: AxiosResultType[K] extends (infer I)[] ? I : AxiosResultType[K];
};
