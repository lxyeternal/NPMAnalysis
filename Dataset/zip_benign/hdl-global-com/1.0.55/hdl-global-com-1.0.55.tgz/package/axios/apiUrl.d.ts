declare const apiUrlList: {
    getPublicKey: string;
    getDictChild: string;
    login: string;
    logout: string;
    fileUpload: string;
    downFile: string;
    getMenuData: string;
    getPageAuth: string;
    getNoticeUnreadCount: string;
    noticeListPage: string;
    noticeList: string;
    noticeRead: string;
    noticeReadAll: string;
    wsNotify: string;
    baseSocket: string;
};
export default apiUrlList;
