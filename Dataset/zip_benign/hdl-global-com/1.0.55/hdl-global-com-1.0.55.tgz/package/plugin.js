import y from "fs";
import M from "path";
import u from "child_process";
import N from "readline";
import A from "ssh2";
import R from "ssh2-sftp-client";
import q from "inquirer";
const w = N.createInterface({
  // 创建读取工作流
  input: process.stdin,
  output: process.stdout
}), S = ["hdl-global-com"], j = "http://registry.npmmirror.com", x = {
  npm: {
    address: "http://registry.npmmirror.com",
    // npm源地址
    install: "pnpm add"
    // 安装命令
  },
  yarn: {
    address: "https://registry.yarnpkg.com",
    // yarn源地址
    install: "yarn add"
    // 安装命令
  }
};
let k = !1;
const B = M.resolve(process.cwd(), "yarn.lock"), v = y.existsSync(B) ? "yarn" : "npm";
let f = 0, d = null;
const a = (e, n) => {
  k && u.execSync(
    `npm config set registry=${x[v].address}`
  ), f += 1, d = n || d, f === S.length && (w.close(), console.log(`开始${e === "build" ? "编译" : "启动"}项目...`), d && y.writeFileSync("./package.json", JSON.stringify(d, null, 2)), f = 0, d = null);
}, D = async (e) => {
  const n = JSON.parse(
    y.readFileSync("package.json", "utf-8")
  );
  u.execSync("npm config get registry", {
    encoding: "utf-8"
  }).indexOf(j) === -1 && (console.log("正在为你切换至私有库下载源，请等待..."), k = !0, u.execSync(`npm config set registry ${j}`));
  for (let r = 0; r < S.length; r++) {
    const o = S[r], g = `npm view ${o} version`, s = u.execSync(g, { encoding: "utf-8" }), b = n.dependencies[o];
    if (!b) {
      a(e);
      continue;
    }
    const c = s.substring(0, s.length - 1), O = c.indexOf("alpha") !== -1 || c.indexOf("beta") !== -1, P = b.endsWith(c);
    if (e === "build")
      if (!O && !P) {
        const i = await new Promise((h) => {
          w.question(
            `依赖包${o}存在新版，新版版本号：${c}，是否更新？（y/n）`,
            ($) => {
              h($);
            }
          );
        });
        i === "y" || i === "Y" || i === "是" ? (console.log(`请手动更新依赖包：${x[v].install} ${o}@${c}`), f = 0, d = null, k = !1, process.exit()) : (console.log("你已跳过此次更新"), a(e));
      } else
        a(e);
    else if (P)
      a(e);
    else {
      const i = await new Promise((h) => {
        w.question(
          `依赖包${o}存在新版，新版版本号：${c}，是否更新？（y/n）`,
          ($) => {
            h($);
          }
        );
      });
      i === "y" || i === "Y" || i === "是" ? (console.log("开始更新依赖包..."), u.execSync(
        `${x[v].install} ${o}@${c}`
      ), console.log(`依赖包${o}已更新到最新版本`), n.dependencies[o] = c, a(e, n)) : (console.log("你已跳过此次更新"), a(e));
    }
  }
}, K = () => ({
  name: "hdl-listen-plugin",
  // 插件名称
  async configResolved(e) {
    if (e.command === "serve") {
      await D("serve");
      return;
    }
    await D("build");
  }
}), H = q.createPromptModule(), m = new R(), l = new A.Client(), J = JSON.parse(y.readFileSync("package.json", "utf-8")), F = [
  // 服务器信息
  {
    name: "微前端开发环境",
    info: {
      // 服务器信息
      host: "183.6.105.119",
      port: 2152,
      username: "root",
      password: "superMcs%2024"
    },
    pageAddress: `/home/micro/${J.name}/web/dist`
    // 文件地址
  }
], p = (e) => e < 9 ? `0${e}` : e, I = () => {
  const e = /* @__PURE__ */ new Date(), n = e.getFullYear(), t = p(e.getMonth() + 1), r = p(e.getDate()), o = p(e.getHours()), g = p(e.getMinutes()), s = p(e.getSeconds());
  return `${n}-${t}-${r} ${o}:${g}:${s}`;
}, L = async () => {
  const e = await H({
    type: "list",
    name: "server",
    message: "请选择部署服务器",
    choices: F.map((t) => t.name)
  }), n = F.find((t) => t.name === e.server);
  if (n) {
    await m.connect(n.info);
    try {
      await m.rename(n.pageAddress, `${n.pageAddress}.${I()}`);
    } catch {
      console.log("服务器上的文件夹不存在，跳过重命名操作");
    }
    await m.uploadDir("dist", n.pageAddress), m.end(), l.on("ready", () => {
      l.exec(`cd /home/micro;docker restart ${J.name}`, (t, r) => {
        if (t) {
          console.error("执行命令时出错:", t);
          return;
        }
        console.log("正在重启docker，请稍后...");
        let o = "", g = "";
        r.on("data", (s) => {
          o += s.toString();
        }), r.stderr.on("data", (s) => {
          g += s.toString();
        }), r.on("close", (s) => {
          console.log("部署完成"), console.log("退出码:", s), l.end();
        });
      });
    }), l.on("error", (t) => {
      console.error("SSH连接出错:", t);
    }), l.on("end", () => {
      console.log("SSH连接已关闭");
    }), l.connect(n.info);
  }
}, Q = () => ({
  name: "hdl-project-build",
  apply: "build",
  // 只在生产环境下执行
  async writeBundle() {
    await new Promise((e) => {
      setTimeout(() => {
        e(!0);
      }, 1e3);
    }), await L();
  }
});
export {
  K as hdlListenModule,
  Q as hdlProjectBuild
};
