import { Method, ResponseType } from 'axios';
import { GetArrItemType } from './type';
export { useRegisterRoute, useSetRouteView } from './registerRoute';
/**
 * @description: 生成uuid
 */
export declare const useUUID: (len?: number) => string;
interface DebounceParams {
    delay?: number;
    isImmediate?: boolean;
}
/**
 * @description: 防抖
 */
export declare const useDebounce: <T extends any[], R>(fn: (...args: T) => R, params?: DebounceParams) => (...args: T) => void;
/**
 * @description 等待函数
 */
export declare const useSleep: (time?: number) => Promise<void>;
/**
 * @description: 格式化日期
 * @param {Date | string | number} date 日期
 * @param {string} formatType yyyy:年份 MM:月份 dd:日 HH:小时(24小时制) hh:小时(12小时制) mm:分 ss:秒
 */
export declare const useFormatDate: (date: Date | string | number, formatType?: string) => string;
/**
 * @description 获取筛选框中动态添加的参数
 * @param {object} defaultParams 原有的默认参数
 * @returns {object}
 */
export declare const useGetSearchParams: <T>(defaultParams: T) => T;
/**
 * @description 分页hooks函数
 */
export declare const usePagination: <T extends {
    [x: string]: {
        resDataType: any;
        paramsType: any;
    };
}, K extends { [x in keyof T]: any; }>(pageAxios: any) => <G extends { [Key in keyof { [B in keyof T]: T[B]["resDataType"]["resData"] extends {
    list: infer I;
} ? I : never; }]: { [B in keyof T]: T[B]["resDataType"]["resData"] extends {
    list: infer I;
} ? I : never; }[Key] extends never ? never : Key; }[keyof T]>(obj: { [K_1 in G]: {
    url: G;
    data?: Partial<T[K_1]["paramsType"]> | undefined;
    method?: Method;
    isPopup?: boolean;
    immediate?: boolean;
}; }[G]) => {
    total: globalThis.Ref<number, number>;
    pageSize: globalThis.Ref<number, number>;
    currentPage: globalThis.Ref<number, number>;
    tableData: globalThis.Ref<K[G]["list"], K[G]["list"]>;
    rowData: [GetArrItemType<K[G]["list"]> | null] extends [globalThis.Ref<any, any>] ? import('@vue/shared').IfAny<globalThis.Ref<any, any> & GetArrItemType<K[G]["list"]>, globalThis.Ref<globalThis.Ref<any, any> & GetArrItemType<K[G]["list"]>, globalThis.Ref<any, any> & GetArrItemType<K[G]["list"]>>, globalThis.Ref<any, any> & GetArrItemType<K[G]["list"]>> : globalThis.Ref<import('vue').UnwrapRef<GetArrItemType<K[G]["list"]>> | null, GetArrItemType<K[G]["list"]> | import('vue').UnwrapRef<GetArrItemType<K[G]["list"]>> | null>;
    getTableData: (axiosParams?: Partial<T[G]["paramsType"]> | boolean, isReset?: boolean) => Promise<void>;
    resetTable: () => void;
    updateTableUrl: (newUrl: { [Key in keyof { [B in keyof T]: T[B]["resDataType"]["resData"] extends {
        list: infer I;
    } ? I : never; }]: { [B in keyof T]: T[B]["resDataType"]["resData"] extends {
        list: infer I;
    } ? I : never; }[Key] extends never ? never : Key; }[keyof T]) => void;
};
/**
 * @description: 获取字典子项
 */
export declare const useGetDictChild: (code: string, params?: {
    [x: string]: any;
}) => Promise<{
    id: number;
    detailCode: string;
    detailName: string;
    dictCode: string;
    detailDescn: string;
    value: null;
    param: null;
    companyCode: string;
}[]>;
type EventName = 'logout' | 'micro';
/**
 * @description 事件总线 监听退出登录、返回微前端首页
 */
export declare const useEventBus: () => {
    emit<T extends any[]>(e: EventName, ...args: T): void;
    on<T extends any[]>(e: EventName, callback: (...args: T) => void): void;
    off(e: EventName): void;
};
/**
 * @description 用于合并对象 常用于编辑时的数据回显
 */
export declare const useAssign: <T extends Record<string, any>, K extends Record<keyof T, any>>(obj: T, assignObj: K) => {} & T;
/**
 * @description 下载文件
 */
export declare const useDownFile: (downParams: {
    id?: string | number;
    uuid?: string | number;
}, responseType?: ResponseType) => Promise<string>;
type Callback = (args: {
    width: number;
    height: number;
    contentWidth: number;
    contentHeight: number;
}) => void;
/**
 * @description 监听DOM的尺寸变化
 */
export declare const useDomResize: (el: Element, callback: Callback, flag?: boolean) => void;
/**
 * @description 监听DOM的结构变化
 */
export declare const useMutationObserver: (refEl: Ref<HTMLElement | null>, callback: MutationCallback) => void;
export declare const pageSnData: globalThis.Ref<{
    [K: string]: {
        id: number;
        guid: string;
        menuSn: string;
        code: string;
        name: string;
        remark: string;
        status: string;
        createTime: string;
        creatorId: number;
        creatorName?: any;
        updateTime: string;
        updaterId: number;
        updaterName?: any;
        formConfigList?: {
            id: number;
            type: string;
            spcId: string;
            code: string;
            label: string;
            dataSource: {
                [K: string]: any;
            };
            prop: {
                [K: string]: any;
            };
            remark: string;
            createTime: string;
            creatorId: number;
            updateTime: string;
            updaterId: number;
            companyCode: string;
        }[];
        filterConfigList?: {
            id: number;
            type: string;
            spcId: string;
            code: string;
            label: string;
            dataSource: {
                [K: string]: any;
            };
            prop: {
                [K: string]: any;
            };
            remark: string;
            createTime: string;
            creatorId: number;
            updateTime: string;
            updaterId: number;
            companyCode: string;
        }[];
        listConfigList?: {
            id: number;
            type: string;
            spcId: string;
            code: string;
            label: string;
            dataSource: {
                [K: string]: any;
            };
            prop: {
                [K: string]: any;
            };
            remark: string;
            createTime: string;
            creatorId: number;
            updateTime: string;
            updaterId: number;
            companyCode: string;
        }[];
    }[];
}, {
    [K: string]: {
        id: number;
        guid: string;
        menuSn: string;
        code: string;
        name: string;
        remark: string;
        status: string;
        createTime: string;
        creatorId: number;
        creatorName?: any;
        updateTime: string;
        updaterId: number;
        updaterName?: any;
        formConfigList?: {
            id: number;
            type: string;
            spcId: string;
            code: string;
            label: string;
            dataSource: {
                [K: string]: any;
            };
            prop: {
                [K: string]: any;
            };
            remark: string;
            createTime: string;
            creatorId: number;
            updateTime: string;
            updaterId: number;
            companyCode: string;
        }[];
        filterConfigList?: {
            id: number;
            type: string;
            spcId: string;
            code: string;
            label: string;
            dataSource: {
                [K: string]: any;
            };
            prop: {
                [K: string]: any;
            };
            remark: string;
            createTime: string;
            creatorId: number;
            updateTime: string;
            updaterId: number;
            companyCode: string;
        }[];
        listConfigList?: {
            id: number;
            type: string;
            spcId: string;
            code: string;
            label: string;
            dataSource: {
                [K: string]: any;
            };
            prop: {
                [K: string]: any;
            };
            remark: string;
            createTime: string;
            creatorId: number;
            updateTime: string;
            updaterId: number;
            companyCode: string;
        }[];
    }[];
}>;
/**
 * @description 获取页面权限 主要是筛选框、表格列与表单
 */
export declare const useGetPageAuth: () => Promise<{
    id: number;
    guid: string;
    menuSn: string;
    code: string;
    name: string;
    remark: string;
    status: string;
    createTime: string;
    creatorId: number;
    creatorName?: any;
    updateTime: string;
    updaterId: number;
    updaterName?: any;
    formConfigList?: {
        id: number;
        type: string;
        spcId: string;
        code: string;
        label: string;
        dataSource: {
            [K: string]: any;
        };
        prop: {
            [K: string]: any;
        };
        remark: string;
        createTime: string;
        creatorId: number;
        updateTime: string;
        updaterId: number;
        companyCode: string;
    }[];
    filterConfigList?: {
        id: number;
        type: string;
        spcId: string;
        code: string;
        label: string;
        dataSource: {
            [K: string]: any;
        };
        prop: {
            [K: string]: any;
        };
        remark: string;
        createTime: string;
        creatorId: number;
        updateTime: string;
        updaterId: number;
        companyCode: string;
    }[];
    listConfigList?: {
        id: number;
        type: string;
        spcId: string;
        code: string;
        label: string;
        dataSource: {
            [K: string]: any;
        };
        prop: {
            [K: string]: any;
        };
        remark: string;
        createTime: string;
        creatorId: number;
        updateTime: string;
        updaterId: number;
        companyCode: string;
    }[];
}[]>;
/**
 * @description: blob文件下载
 */
export declare const useBlobDownload: (blob: Blob, fileName: string) => void;
/**
 * @description: 文档下载处理
 */
export declare const useFileOperate: (res: any, fileName: string, fileType: string) => void;
/**
 * @description: 引入在线字体图标
 */
export declare const useLinkIconScript: () => Promise<void>;
/**
 * @description 主要用于大屏，表格自动滚动功能
 * @param elemStr string 滚动的元素标识
 * @param options.speed number 速度，大于等于0，默认为0.7
 * @param options.direction 'upper' | 'down' 方向，默认为upper
 * @returns
 */
export declare const useTableRoll: (elemStr: string, options?: {
    speed?: number;
    direction?: "upper" | "down";
}) => () => void;
