import { Router } from 'vue-router';
import { AxiosResultType } from '../axios/type';
export declare const useSetRouteView: (pageInfo: Record<string, any>, name: string, ignore?: string[]) => void;
/**
 * @description 自动根据系统文件夹结构注册路由
 */
export declare const useRegisterRoute: (router: Router, menuData: AxiosResultType["getMenuData"]) => Promise<void>;
