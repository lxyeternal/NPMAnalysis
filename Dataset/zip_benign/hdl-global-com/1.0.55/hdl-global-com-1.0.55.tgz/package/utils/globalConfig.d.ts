import { ConfigType } from './type';
import { UploadRawFile } from 'element-plus';
/**
 * @description 设置默认的缓存key
 */
export declare const useHdlLocalStorageKeyConfig: () => {
    HDL_MENU: globalThis.Ref<string, string>;
    HDL_MENU_SN: globalThis.Ref<string, string>;
    HDL_TOKEN: globalThis.Ref<string, string>;
    HDL_USER: globalThis.Ref<string, string>;
    HDL_USER_NAME: globalThis.Ref<string, string>;
    HDL_PWD: globalThis.Ref<string, string>;
    HDL_TYPE: globalThis.Ref<string, string>;
    useSetConfig: (config: ConfigType["localStorageKey"]) => void;
};
declare const hdlStorageKeyConfig: {
    HDL_MENU: globalThis.Ref<string, string>;
    HDL_MENU_SN: globalThis.Ref<string, string>;
    HDL_TOKEN: globalThis.Ref<string, string>;
    HDL_USER: globalThis.Ref<string, string>;
    HDL_USER_NAME: globalThis.Ref<string, string>;
    HDL_PWD: globalThis.Ref<string, string>;
    HDL_TYPE: globalThis.Ref<string, string>;
    useSetConfig: (config: ConfigType["localStorageKey"]) => void;
};
/**
 * @description 登录组件的默认配置信息保存
 */
export declare const useHdlLoginConfig: () => {
    loginSuccessRoute: globalThis.Ref<string, string>;
    useSetConfig: (loginConfig?: ConfigType["hdlLogin"]) => void;
    refreshRouteName: globalThis.Ref<string, string>;
    loginRoute: globalThis.Ref<string, string>;
    qkMenuType: globalThis.Ref<string, string>;
};
declare const hdlLoginConfig: {
    loginSuccessRoute: globalThis.Ref<string, string>;
    useSetConfig: (loginConfig?: ConfigType["hdlLogin"]) => void;
    refreshRouteName: globalThis.Ref<string, string>;
    loginRoute: globalThis.Ref<string, string>;
    qkMenuType: globalThis.Ref<string, string>;
};
declare const hdlTableConfig: {
    useSetConfig: (config?: ConfigType["hdlTable"]) => void;
    pageSize: globalThis.Ref<number, number>;
    popupPageSize: globalThis.Ref<number, number>;
    pageSizes: globalThis.Ref<number[], number[]>;
    popupPageSizes: globalThis.Ref<number[], number[]>;
};
declare const hdlMenusConfig: {
    width: globalThis.Ref<number, number>;
    collapseWidth: globalThis.Ref<number, number>;
    useSetConfig: (config?: ConfigType["hdlMenus"]) => void;
};
declare const hdlSearchConfig: {
    width: globalThis.Ref<number, number>;
    useSetConfig: (config?: ConfigType["hdlSearch"]) => void;
};
declare const hdlFormConfig: {
    useSetConfig: (config?: ConfigType["hdlForm"]) => void;
    labelWidth: globalThis.Ref<string, string>;
};
declare const hdlTreeConfig: {
    useSetConfig: (config?: ConfigType["hdlTree"]) => void;
    width: globalThis.Ref<number, number>;
    mixWidth: globalThis.Ref<number, number>;
    maxWidth: globalThis.Ref<number, number>;
};
declare const hdlDialogConfig: {
    useSetConfig: (config?: ConfigType["hdlDialog"]) => void;
    dialogAttr: {
        closeOnClickModal: boolean;
        closeOnPressEscape: boolean;
        appendTo: string;
        draggable: boolean;
    };
};
declare const hdlElUploadConfig: {
    readonly disabled?: boolean | undefined;
    readonly name?: string | undefined;
    readonly multiple?: boolean | undefined;
    readonly beforeUpload?: ((rawFile: UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>) | undefined;
    readonly onRemove?: ((uploadFile: import('element-plus').UploadFile, uploadFiles: import('element-plus').UploadFiles) => void) | undefined;
    readonly onChange?: ((uploadFile: import('element-plus').UploadFile, uploadFiles: import('element-plus').UploadFiles) => void) | undefined;
    readonly onPreview?: ((uploadFile: import('element-plus').UploadFile) => void) | undefined;
    readonly onSuccess?: ((response: any, uploadFile: import('element-plus').UploadFile, uploadFiles: import('element-plus').UploadFiles) => void) | undefined;
    readonly onProgress?: ((evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus').UploadFile, uploadFiles: import('element-plus').UploadFiles) => void) | undefined;
    readonly onError?: ((error: Error, uploadFile: import('element-plus').UploadFile, uploadFiles: import('element-plus').UploadFiles) => void) | undefined;
    readonly onExceed?: ((files: File[], uploadFiles: import('element-plus').UploadUserFile[]) => void) | undefined;
    readonly action?: string | undefined;
    readonly method?: string | undefined;
    readonly data?: import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | ((rawFile: UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>) | {
        then: <TResult1 = import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>, TResult2 = never>(onfulfilled?: ((value: import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>) => TResult1 | PromiseLike<TResult1>) | null | undefined, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | null | undefined) => Promise<TResult1 | TResult2>;
        catch: <TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | null | undefined) => Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | TResult>;
        finally: (onfinally?: (() => void) | null | undefined) => Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>>;
        readonly [Symbol.toStringTag]: string;
    } | undefined;
    readonly drag?: boolean | undefined;
    readonly withCredentials?: boolean | undefined;
    readonly showFileList?: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
    readonly accept?: string | undefined;
    readonly fileList?: {
        size?: number | undefined;
        raw?: {
            uid: number;
            readonly lastModified: number;
            readonly name: string;
            readonly webkitRelativePath: string;
            readonly size: number;
            readonly type: string;
            arrayBuffer: () => Promise<ArrayBuffer>;
            bytes: () => Promise<Uint8Array>;
            slice: (start?: number, end?: number, contentType?: string) => Blob;
            stream: () => ReadableStream<Uint8Array>;
            text: () => Promise<string>;
        } | undefined;
        name: string;
        percentage?: number | undefined;
        response?: unknown;
        url?: string | undefined;
        status?: import('element-plus').UploadStatus | undefined;
        uid?: number | undefined;
    }[] | undefined;
    readonly autoUpload?: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown> | undefined;
    readonly listType?: import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "text" | "picture" | "picture-card", unknown> | undefined;
    readonly httpRequest?: import('element-plus').UploadRequestHandler | undefined;
    readonly beforeRemove?: ((uploadFile: import('element-plus').UploadFile, uploadFiles: import('element-plus').UploadFiles) => import('element-plus/es/utils/typescript.mjs').Awaitable<boolean>) | undefined;
    readonly crossorigin?: import('element-plus/es/utils/index.mjs').EpPropMergeType<(new (...args: any[]) => "" | "anonymous" | "use-credentials") | (() => "" | "anonymous" | "use-credentials") | ((new (...args: any[]) => "" | "anonymous" | "use-credentials") | (() => "" | "anonymous" | "use-credentials"))[], unknown, unknown> | undefined;
    readonly headers?: Record<string, any> | {
        append: (name: string, value: string) => void;
        delete: (name: string) => void;
        get: (name: string) => string | null;
        getSetCookie: () => string[];
        has: (name: string) => boolean;
        set: (name: string, value: string) => void;
        forEach: (callbackfn: (value: string, key: string, parent: Headers) => void, thisArg?: any) => void;
        entries: () => HeadersIterator<[string, string]>;
        keys: () => HeadersIterator<string>;
        values: () => HeadersIterator<string>;
        [Symbol.iterator]: () => HeadersIterator<[string, string]>;
    } | undefined;
    readonly limit?: number | undefined;
};
export declare const hdlWsConfig: {
    reconnectInter: globalThis.Ref<number[], number[]>;
    useSetConfig: (config?: ConfigType["hdlWs"]) => void;
};
export { hdlLoginConfig, hdlTableConfig, hdlStorageKeyConfig, hdlMenusConfig, hdlSearchConfig, hdlFormConfig, hdlTreeConfig, hdlDialogConfig, hdlElUploadConfig };
declare const _default: (configType?: ConfigType) => void;
export default _default;
