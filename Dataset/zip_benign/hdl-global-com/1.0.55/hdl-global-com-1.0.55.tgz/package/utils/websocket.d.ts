export declare const useWs: <T extends string>(urlList: Record<T, string>) => {
    useInitWs: <K extends keyof typeof urlList>(params: {
        url: K;
        data?: string;
        wsFlag?: string;
    }, isReconnect?: boolean) => void;
    useWsOpen: (uuid: string, callback: () => void) => () => void;
    useWsMsg: (uuid: string, callback: <V = any>(value: V) => void) => () => void;
    useWsClose: (uuid: string, callback: (ev: CloseEvent) => void) => () => void;
    useWsError: (uuid: string, callback: (ev: Event) => void) => () => void;
    useWsSend: (uuid: string, data: any, operate?: {
        interval: number;
        isHeartbeat: boolean;
    }) => void;
    useCloseWs: (uuid: string, closeWs?: boolean) => void;
    useGetWs: (uuid: string) => WebSocket;
};
export declare const useInitWs: <K extends "getPublicKey" | "getDictChild" | "login" | "logout" | "fileUpload" | "downFile" | "getMenuData" | "getPageAuth" | "getNoticeUnreadCount" | "noticeListPage" | "noticeList" | "noticeRead" | "noticeReadAll" | "wsNotify" | "baseSocket">(params: {
    url: K;
    data?: string;
    wsFlag?: string;
}, isReconnect?: boolean) => void, useWsClose: (uuid: string, callback: (ev: CloseEvent) => void) => () => void, useWsError: (uuid: string, callback: (ev: Event) => void) => () => void, useWsMsg: (uuid: string, callback: <V = any>(value: V) => void) => () => void, useWsOpen: (uuid: string, callback: () => void) => () => void, useWsSend: (uuid: string, data: any, operate?: {
    interval: number;
    isHeartbeat: boolean;
} | undefined) => void, useCloseWs: (uuid: string, closeWs?: boolean) => void, useGetWs: (uuid: string) => WebSocket;
