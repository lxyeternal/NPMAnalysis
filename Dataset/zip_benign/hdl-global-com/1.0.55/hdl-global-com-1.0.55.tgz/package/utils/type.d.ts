import { TableColumnCtx, InputProps, SelectContext, cascaderProps, DatePickerProps, InputNumberProps, SelectV2Context, TimePickerDefaultProps, CascaderNode, CascaderValue, UploadProps, ElTooltipProps } from 'element-plus';
import { TimeSelectProps } from 'element-plus/es/components/time-select/src/time-select';
import { TreeComponentProps } from 'element-plus/es/components/tree/src/tree.type';
import { DefineComponent, ExtractPropTypes } from 'vue';
import { AxiosResultType } from '../axios/type';
/**
 * @description 一些常用的ts工具函数
 */
export type GetArrItemType<T> = T extends (infer I)[] ? I : T;
export type DictChildType = GetArrItemType<AxiosResultType['getDictChild']>;
/**
 * @description 表格组件的类型导出
 */
type OtherTableColumn<T> = {
    prop: T extends Record<string, any> ? keyof T : string;
    type: 'default' | 'selection' | 'index' | 'expand' | 'move';
    slot: boolean;
    show: any;
    auth: string;
    onlyAuth: boolean;
};
export type TableColumn<T = any> = Partial<TableColumnCtx<T> & OtherTableColumn<T>>[];
export type TableColumnSlotType<T = any> = TableColumn<T>;
export type TableRowType<T> = (T extends Array<infer I> ? I : T) | null;
export type TableEmitsType = 'info' | 'update' | 'del';
export type TableRefFuncType = {
    clearSelection: () => void;
    getSelectionRows: <T>() => TableRowType<T>[];
    toggleRowSelection: <T>(row: TableRowType<T>, selected: boolean) => void;
    toggleAllSelection: () => void;
    toggleRowExpansion: <T>(row: TableRowType<T>, expanded: boolean) => void;
    setCurrentRow: <T>(row: TableRowType<T>) => void;
    clearSort: () => void;
    doLayout: () => void;
    clearFilter: (columnKey?: string[]) => void;
    sort: (prop: string, order: string) => void;
    scrollTo: (options: number | ScrollToOptions, yCoord?: number | undefined) => void;
    setScrollLeft: (left?: number | undefined) => void;
    setScrollTop: (top?: number | undefined) => void;
};
/**
 * @description 筛选区域的类型导出
 */
type SearchFilterDefaultType = {
    id: string;
    auth?: string;
    onlyAuth?: boolean;
    model: any;
    show?: any;
};
type SearchFilter = {
    'el-input': SearchFilterDefaultType & {
        comName: 'el-input';
        props?: Partial<InputProps>;
        emits?: Partial<{
            blur: (event: FocusEvent) => void;
            focus: (event: FocusEvent) => void;
            change: (value: string | number) => void;
            input: (value: string | number) => void;
            clear: () => void;
        }>;
    };
    'el-select': SearchFilterDefaultType & {
        comName: 'el-select';
        children: {
            comName: 'el-option';
            data: any;
            props?: Partial<{
                value: string | number | boolean | object;
                label: string | number;
                disabled: boolean;
            }>;
        };
        props?: Partial<SelectContext['props']>;
        emits?: Partial<{
            change: (value: any) => void;
            visibleChange: (visible: boolean) => void;
            removeTag: (tagValue: any) => void;
            clear: () => void;
            blur: (event: FocusEvent) => void;
            focus: (event: FocusEvent) => void;
        }>;
    };
    'el-cascader': SearchFilterDefaultType & {
        comName: 'el-cascader';
        props?: Partial<ExtractPropTypes<typeof cascaderProps> & {
            options: any;
        }>;
        emits?: Partial<{
            change: (value: CascaderValue) => void;
            expandChange: (value: CascaderValue) => void;
            blur: (event: FocusEvent) => void;
            focus: (event: FocusEvent) => void;
            visibleChange: (value: boolean) => void;
            removeTag: (value: CascaderNode['valueByOption']) => void;
        }>;
    };
    'el-date-picker': SearchFilterDefaultType & {
        comName: 'el-date-picker';
        props?: Partial<DatePickerProps>;
        emits?: Partial<{
            change: (value: any) => void;
            blur: (e: FocusEvent) => void;
            focus: (e: FocusEvent) => void;
            calendarChange: (val: [Date, null | Date]) => void;
            panelChange: (date: Date | [Date, Date], mode: 'month' | 'year', view?: string) => void;
            visibleChange: (visibility: boolean) => void;
        }>;
    };
    'el-input-number': SearchFilterDefaultType & {
        comName: 'el-input-number';
        props?: Partial<InputNumberProps>;
        emits?: Partial<{
            change: (currentValue: number | undefined, oldValue: number | undefined) => void;
            blur: (event: FocusEvent) => void;
            focus: (event: FocusEvent) => void;
        }>;
    };
    'el-select-v2': SearchFilterDefaultType & {
        comName: 'el-select-v2';
        props?: Partial<SelectV2Context['props']>;
        emits?: Partial<{
            change: (val: any) => void;
            visibleChange: (visible: boolean) => void;
            removeTag: (tagValue: any) => void;
            clear: () => void;
            blur: (event: FocusEvent) => void;
            focus: (event: FocusEvent) => void;
        }>;
    };
    'el-time-picker': SearchFilterDefaultType & {
        comName: 'el-time-picker';
        props?: Partial<TimePickerDefaultProps>;
        emits?: Partial<{
            change: (val: number | string | Date | [number, number] | [string, string] | [Date, Date]) => void;
            blur: (e: FocusEvent) => void;
            focus: (e: FocusEvent) => void;
            visibleChange: (visibility: boolean) => void;
        }>;
    };
    'el-time-select': SearchFilterDefaultType & {
        comName: 'el-time-select';
        props?: Partial<TimeSelectProps>;
        emits?: Partial<{
            change: (value: string) => void;
            blur: (e: FocusEvent) => void;
            focus: (e: FocusEvent) => void;
        }>;
    };
    'el-tree-select': SearchFilterDefaultType & {
        comName: 'el-tree-select';
        props?: Partial<SelectContext['props'] & TreeComponentProps>;
        emits?: Partial<{
            nodeClick: ((...args: any[]) => any);
            nodeContextmenu: ((...args: any[]) => any);
            checkChange: ((...args: any[]) => any);
            check: ((...args: any[]) => any);
            currentChange: ((...args: any[]) => any);
            nodeExpand: ((...args: any[]) => any);
            nodeCollapse: ((...args: any[]) => any);
            nodeDragStart: ((...args: any[]) => any);
            nodeDragEnter: ((...args: any[]) => any);
            nodeDragLeave: ((...args: any[]) => any);
            nodeDragOver: ((...args: any[]) => any);
            nodeDragEnd: ((...args: any[]) => any);
            nodeDrop: ((...args: any[]) => any);
            change: (value: any) => void;
            visibleChange: (visible: boolean) => void;
            removeTag: (tagValue: any) => void;
            clear: () => void;
            blur: (event: FocusEvent) => void;
            focus: (event: FocusEvent) => void;
        }>;
    };
};
export type SearchType = SearchFilter[keyof SearchFilter];
/**
 * @description 按钮组件类型导出
 */
type ClassType = 'primary' | 'success' | 'info' | 'warning' | 'danger';
type ButtonTypeDefault = {
    default: {
        type?: 'default';
        name: string;
        icon?: DefineComponent;
        auth: string;
        func: (...args: any[]) => any;
        class?: ClassType;
        show?: any;
        loading?: any;
        developShow?: boolean;
    };
    children: {
        type: 'select';
        name: string;
        class?: ClassType;
        children: {
            name: string;
            icon?: DefineComponent;
            auth: string;
            func: (...args: any[]) => any;
            show?: any;
            loading?: any;
            developShow?: boolean;
        }[];
    };
    upload: {
        type: 'upload';
        props: Partial<UploadProps>;
        name: string;
        auth: string;
        class?: ClassType;
        show?: any;
        loading?: any;
        developShow?: boolean;
        icon?: DefineComponent;
    };
    tooltip: {
        type: 'tooltip';
        name: string;
        auth: string;
        class?: ClassType;
        show?: any;
        loading?: any;
        developShow?: boolean;
        icon?: DefineComponent;
        props: Partial<ElTooltipProps>;
        func: (...args: any[]) => any;
    };
};
export type ButtonType = ButtonTypeDefault[keyof ButtonTypeDefault];
/**
 * @description 公共的配置类型导出
 */
export type ConfigType = Partial<{
    localStorageKey: Partial<{
        HDL_TOKEN: string;
        HDL_USER: string;
        HDL_MENU: string;
        HDL_MENU_SN: string;
        HDL_USER_NAME: string;
        HDL_PWD: string;
        HDL_TYPE: string;
    }>;
    hdlLogin: Partial<{
        loginSuccessRoute: string;
        loginRoute: string;
        refreshRouteName: string;
        qkMenuType: string;
    }>;
    hdlTable: Partial<{
        authVal: number;
        onlyShowVal: boolean;
        pageSizes: number[];
        pageSize: number;
        popupPageSizes: number[];
        popupPageSize: number;
    }>;
    hdlMenus: Partial<{
        width: number;
        collapseWidth: number;
    }>;
    hdlSearch: Partial<{
        width: number;
    }>;
    hdlForm: Partial<{
        labelWidth: string;
    }>;
    hdlTree: Partial<{
        width: number;
        minWidth: number;
        maxWidth: number;
    }>;
    hdlWs: Partial<{
        reconnectInter: number[];
    }>;
    hdlDialog: Partial<{
        appendTo: string;
    }>;
}>;
export {};
