import hdlLogin from './components/hdlLogin/hdlLogin.vue';
import hdlNoPage from './components/hdlNoPage/hdlNoPage.vue';
import hdlMsgLogin from './components/hdlMsgLogin/hdlMsgLogin.vue';
import hdlHeader from './components/hdlHeader/hdlHeader.vue';
import hdlMenus from './components/hdlMenus/hdlMenus.vue';
import hdlSearch from './components/hdlSearch/hdlSearch.vue';
import hdlBtn from './components/hdlBtn/hdlBtn.vue';
import hdlCron from './components/hdlCron/hdlCron.vue';
import hdlTable from './components/hdlTable/hdlTable.vue';
import hdlForm from './components/hdlForm/hdlForm.vue';
import hdlTree from './components/hdlTree/hdlTree.vue';
import hdlFileImport from './components/hdlFileImport/hdlFileImport.vue';
import hdlJsonForm from './components/hdlJsonForm/hdlJsonForm.vue';

// GlobalComponents for Volar
declare module 'vue' {
  export interface GlobalComponents {
    hdlLogin: typeof hdlLogin;
    hdlNoPage: typeof hdlNoPage;
    hdlMsgLogin: typeof hdlMsgLogin;
    hdlHeader: typeof hdlHeader;
    hdlMenus: typeof hdlMenus;
    hdlSearch: typeof hdlSearch;
    hdlBtn: typeof hdlBtn;
    hdlCron: typeof hdlCron;
    hdlTable: typeof hdlTable;
    hdlForm: typeof hdlForm;
    hdlTree: typeof hdlTree;
    hdlFileImport: typeof hdlFileImport;
    hdlJsonForm: typeof hdlJsonForm;
  }
}

export {};
