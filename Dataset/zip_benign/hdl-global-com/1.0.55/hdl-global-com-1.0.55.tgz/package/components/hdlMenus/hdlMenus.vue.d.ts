declare const _default: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    userName: {
        type: StringConstructor;
        required: true;
    };
    systemSn: {
        type: StringConstructor;
        required: true;
    };
    collapse: {
        type: BooleanConstructor;
        required: true;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
    getSystemName: (name: string) => any;
}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    userName: {
        type: StringConstructor;
        required: true;
    };
    systemSn: {
        type: StringConstructor;
        required: true;
    };
    collapse: {
        type: BooleanConstructor;
        required: true;
    };
}>> & Readonly<{
    onGetSystemName?: ((name: string) => any) | undefined;
}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>;
export default _default;
