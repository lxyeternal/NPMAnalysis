type menuListType = {
    alias: string;
    category: string;
    clientId: null;
    icon: string;
    key: number;
    menuId: number;
    name: string;
    orderNum: number;
    params: null | string;
    parentId: number;
    parentKey: number;
    perms: null | string;
    sn: string;
    type: number;
    url: string;
    childs: null | menuListType[];
};
declare const _default: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    flag: {
        type: StringConstructor;
        default: string;
    };
    menuInfo: {
        type: PropType<menuListType>;
        default: () => {};
    };
    collapse: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    flag: {
        type: StringConstructor;
        default: string;
    };
    menuInfo: {
        type: PropType<menuListType>;
        default: () => {};
    };
    collapse: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{}>, {
    flag: string;
    collapse: boolean;
    menuInfo: menuListType;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>;
export default _default;
