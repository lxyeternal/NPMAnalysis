export type FormDataType = {
    [key: string]: {
        type: string;
        field: string;
        value: string;
        expand: boolean;
        child: FormDataType;
    };
};
export declare const useJsonToForm: (data: any) => FormDataType;
/**
 * @description 还原成简化版的JSON数据格式
 * @param {*} data
 * @returns
 */
export declare const useConvertJsonData: (data: any) => any;
export declare const uuid: string, tempJsonValue: globalThis.Ref<FormDataType, FormDataType>, setJsonValue: (data: FormDataType, flag?: boolean) => void, resetValue: () => void;
