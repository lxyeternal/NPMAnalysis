import { default as ace } from 'ace-builds';
declare const _default: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    modelValue: {
        type: BooleanConstructor;
        default: boolean;
    };
    title: {
        type: StringConstructor;
        default: string;
    };
    json: {
        type: (StringConstructor | ObjectConstructor)[];
        default: () => {};
    };
    options: {
        type: ObjectConstructor;
        default: () => {};
    };
    readonly: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
    "update:model-value": (val: boolean) => any;
    confirm: () => any;
    "update:json": (val: any) => any;
}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    modelValue: {
        type: BooleanConstructor;
        default: boolean;
    };
    title: {
        type: StringConstructor;
        default: string;
    };
    json: {
        type: (StringConstructor | ObjectConstructor)[];
        default: () => {};
    };
    options: {
        type: ObjectConstructor;
        default: () => {};
    };
    readonly: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    "onUpdate:model-value"?: ((val: boolean) => any) | undefined;
    onConfirm?: (() => any) | undefined;
    "onUpdate:json"?: ((val: any) => any) | undefined;
}>, {
    modelValue: boolean;
    readonly: boolean;
    options: Record<string, any>;
    title: string;
    json: string | Record<string, any>;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    vAceEditorRef: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<globalThis.ExtractPropTypes<{
        value: {
            type: StringConstructor;
            required: true;
        };
        lang: {
            type: StringConstructor;
            default: string;
        };
        theme: {
            type: StringConstructor;
            default: string;
        };
        options: ObjectConstructor;
        placeholder: StringConstructor;
        readonly: BooleanConstructor;
        wrap: BooleanConstructor;
        printMargin: {
            type: (BooleanConstructor | NumberConstructor)[];
            default: boolean;
        };
        minLines: NumberConstructor;
        maxLines: NumberConstructor;
    }>> & {
        [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
    }, unknown, unknown, {}, {
        focus(this: import('vue3-ace-editor/types').VAceEditorInstance): void;
        blur(this: import('vue3-ace-editor/types').VAceEditorInstance): void;
        selectAll(this: import('vue3-ace-editor/types').VAceEditorInstance): void;
        getAceInstance(this: import('vue3-ace-editor/types').VAceEditorInstance): ace.Ace.Editor;
    }, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, string[], import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, {
        lang: string;
        theme: string;
        readonly: boolean;
        wrap: boolean;
        printMargin: number | boolean;
    }, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {}, any, import('vue').ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<globalThis.ExtractPropTypes<{
        value: {
            type: StringConstructor;
            required: true;
        };
        lang: {
            type: StringConstructor;
            default: string;
        };
        theme: {
            type: StringConstructor;
            default: string;
        };
        options: ObjectConstructor;
        placeholder: StringConstructor;
        readonly: BooleanConstructor;
        wrap: BooleanConstructor;
        printMargin: {
            type: (BooleanConstructor | NumberConstructor)[];
            default: boolean;
        };
        minLines: NumberConstructor;
        maxLines: NumberConstructor;
    }>> & {
        [x: `on${Capitalize<string>}`]: ((...args: any[]) => any) | undefined;
    }, {}, {}, {}, {
        focus(this: import('vue3-ace-editor/types').VAceEditorInstance): void;
        blur(this: import('vue3-ace-editor/types').VAceEditorInstance): void;
        selectAll(this: import('vue3-ace-editor/types').VAceEditorInstance): void;
        getAceInstance(this: import('vue3-ace-editor/types').VAceEditorInstance): ace.Ace.Editor;
    }, {
        lang: string;
        theme: string;
        readonly: boolean;
        wrap: boolean;
        printMargin: number | boolean;
    }> | null;
}, any>;
export default _default;
