declare const _default: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    modelValue: {
        type: ObjectConstructor;
        default: () => {};
    };
    indent: {
        type: NumberConstructor;
        default: number;
    };
    fieldDisabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    jsonId: {
        type: StringConstructor;
        default: string;
    };
    readonly: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    modelValue: {
        type: ObjectConstructor;
        default: () => {};
    };
    indent: {
        type: NumberConstructor;
        default: number;
    };
    fieldDisabled: {
        type: BooleanConstructor;
        default: boolean;
    };
    jsonId: {
        type: StringConstructor;
        default: string;
    };
    readonly: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{}>, {
    modelValue: Record<string, any>;
    readonly: boolean;
    indent: number;
    fieldDisabled: boolean;
    jsonId: string;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
export default _default;
