import { UploadFile, UploadFiles, UploadUserFile, UploadRawFile } from 'element-plus';
declare const _default: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    modelValue: {
        type: BooleanConstructor;
        required: true;
    };
    url: {
        type: StringConstructor;
        required: true;
    };
    limit: {
        type: NumberConstructor;
        default: undefined;
    };
    maxSize: {
        type: NumberConstructor;
        default: number;
    };
    headersParams: {
        type: ObjectConstructor;
        default: () => {};
    };
    data: {
        type: ObjectConstructor;
        default: () => {};
    };
    accept: {
        type: StringConstructor;
        default: string;
    };
    fileTypeStr: {
        type: StringConstructor;
        default: string;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
    "update:model-value": (val: boolean) => any;
    refresh: () => any;
}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    modelValue: {
        type: BooleanConstructor;
        required: true;
    };
    url: {
        type: StringConstructor;
        required: true;
    };
    limit: {
        type: NumberConstructor;
        default: undefined;
    };
    maxSize: {
        type: NumberConstructor;
        default: number;
    };
    headersParams: {
        type: ObjectConstructor;
        default: () => {};
    };
    data: {
        type: ObjectConstructor;
        default: () => {};
    };
    accept: {
        type: StringConstructor;
        default: string;
    };
    fileTypeStr: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    "onUpdate:model-value"?: ((val: boolean) => any) | undefined;
    onRefresh?: (() => any) | undefined;
}>, {
    data: Record<string, any>;
    accept: string;
    limit: number;
    maxSize: number;
    headersParams: Record<string, any>;
    fileTypeStr: string;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    uploadRef: ({
        $: import('vue').ComponentInternalInstance;
        $data: {};
        $props: Partial<{
            readonly data: import('element-plus/es/utils/index.mjs').EpPropMergeType<(new (...args: any[]) => import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | (() => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | ((new (...args: any[]) => import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | (() => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)))[], unknown, unknown>;
            readonly disabled: boolean;
            readonly drag: boolean;
            readonly multiple: boolean;
            readonly name: string;
            readonly onChange: (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onError: (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onProgress: (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly action: string;
            readonly withCredentials: boolean;
            readonly method: string;
            readonly showFileList: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly accept: string;
            readonly fileList: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[];
            readonly autoUpload: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly listType: import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "picture" | "text" | "picture-card", unknown>;
            readonly httpRequest: import('element-plus').UploadRequestHandler;
            readonly beforeUpload: (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>;
            readonly onRemove: (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onPreview: (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void;
            readonly onSuccess: (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onExceed: (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void;
        }> & Omit<{
            readonly disabled: boolean;
            readonly name: string;
            readonly multiple: boolean;
            readonly beforeUpload: (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>;
            readonly onRemove: (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onChange: (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onPreview: (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void;
            readonly onSuccess: (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onProgress: (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onError: (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onExceed: (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void;
            readonly action: string;
            readonly method: string;
            readonly data: import('element-plus/es/utils/index.mjs').EpPropMergeType<(new (...args: any[]) => import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | (() => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | ((new (...args: any[]) => import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | (() => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)))[], unknown, unknown>;
            readonly drag: boolean;
            readonly withCredentials: boolean;
            readonly showFileList: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly accept: string;
            readonly fileList: UploadUserFile[];
            readonly autoUpload: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly listType: import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "text" | "picture" | "picture-card", unknown>;
            readonly httpRequest: import('element-plus').UploadRequestHandler;
            readonly beforeRemove?: ((uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => import('element-plus/es/utils/typescript.mjs').Awaitable<boolean>) | undefined;
            readonly crossorigin?: import('element-plus/es/utils/index.mjs').EpPropMergeType<(new (...args: any[]) => "" | "anonymous" | "use-credentials") | (() => "" | "anonymous" | "use-credentials") | ((new (...args: any[]) => "" | "anonymous" | "use-credentials") | (() => "" | "anonymous" | "use-credentials"))[], unknown, unknown> | undefined;
            readonly headers?: import('element-plus/es/utils/index.mjs').EpPropMergeType<(new (...args: any[]) => Record<string, any> | Headers) | (() => Record<string, any> | Headers) | ((new (...args: any[]) => Record<string, any> | Headers) | (() => Record<string, any> | Headers))[], unknown, unknown> | undefined;
            readonly limit?: number | undefined;
        } & import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, "disabled" | "name" | "multiple" | "beforeUpload" | "onRemove" | "onChange" | "onPreview" | "onSuccess" | "onProgress" | "onError" | "onExceed" | "action" | "method" | "data" | "drag" | "withCredentials" | "showFileList" | "accept" | "fileList" | "autoUpload" | "listType" | "httpRequest">;
        $attrs: {
            [x: string]: unknown;
        };
        $refs: {
            [x: string]: unknown;
        };
        $slots: Readonly<{
            [name: string]: import('vue').Slot<any> | undefined;
        }>;
        $root: ComponentPublicInstance | null;
        $parent: ComponentPublicInstance | null;
        $host: Element | null;
        $emit: (event: string, ...args: any[]) => void;
        $el: any;
        $options: import('vue').ComponentOptionsBase<Readonly<globalThis.ExtractPropTypes<{
            readonly beforeUpload: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>) | (() => (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>) | {
                (): (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>;
                new (): any;
                readonly prototype: any;
            } | ((new (...args: any[]) => (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>) | (() => (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>) | {
                (): (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>;
                new (): any;
                readonly prototype: any;
            })[], unknown, unknown, () => void, boolean>;
            readonly beforeRemove: {
                readonly type: import('vue').PropType<(uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => import('element-plus/es/utils/typescript.mjs').Awaitable<boolean>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly onRemove: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
                (): (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
                new (): any;
                readonly prototype: any;
            } | ((new (...args: any[]) => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
                (): (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
                new (): any;
                readonly prototype: any;
            })[], unknown, unknown, () => void, boolean>;
            readonly onChange: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
                (): (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
                new (): any;
                readonly prototype: any;
            } | ((new (...args: any[]) => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
                (): (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
                new (): any;
                readonly prototype: any;
            })[], unknown, unknown, () => void, boolean>;
            readonly onPreview: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void) | (() => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void) | {
                (): (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void;
                new (): any;
                readonly prototype: any;
            } | ((new (...args: any[]) => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void) | (() => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void) | {
                (): (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void;
                new (): any;
                readonly prototype: any;
            })[], unknown, unknown, () => void, boolean>;
            readonly onSuccess: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
                (): (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
                new (): any;
                readonly prototype: any;
            } | ((new (...args: any[]) => (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
                (): (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
                new (): any;
                readonly prototype: any;
            })[], unknown, unknown, () => void, boolean>;
            readonly onProgress: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
                (): (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
                new (): any;
                readonly prototype: any;
            } | ((new (...args: any[]) => (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
                (): (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
                new (): any;
                readonly prototype: any;
            })[], unknown, unknown, () => void, boolean>;
            readonly onError: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
                (): (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
                new (): any;
                readonly prototype: any;
            } | ((new (...args: any[]) => (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
                (): (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
                new (): any;
                readonly prototype: any;
            })[], unknown, unknown, () => void, boolean>;
            readonly onExceed: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void) | (() => (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void) | {
                (): (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void;
                new (): any;
                readonly prototype: any;
            } | ((new (...args: any[]) => (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void) | (() => (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void) | {
                (): (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void;
                new (): any;
                readonly prototype: any;
            })[], unknown, unknown, () => void, boolean>;
            readonly crossorigin: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/index.mjs').EpPropMergeType<(new (...args: any[]) => "" | "anonymous" | "use-credentials") | (() => "" | "anonymous" | "use-credentials") | ((new (...args: any[]) => "" | "anonymous" | "use-credentials") | (() => "" | "anonymous" | "use-credentials"))[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly action: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "#", boolean>;
            readonly headers: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/index.mjs').EpPropMergeType<(new (...args: any[]) => Record<string, any> | Headers) | (() => Record<string, any> | Headers) | ((new (...args: any[]) => Record<string, any> | Headers) | (() => Record<string, any> | Headers))[], unknown, unknown>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            readonly method: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "post", boolean>;
            readonly data: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | (() => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | ((new (...args: any[]) => import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | (() => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)))[], unknown, unknown, () => import('element-plus/es/utils/typescript.mjs').Mutable<{}>, boolean>;
            readonly multiple: BooleanConstructor;
            readonly name: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "file", boolean>;
            readonly drag: BooleanConstructor;
            readonly withCredentials: BooleanConstructor;
            readonly showFileList: import('element-plus/es/utils/index.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly accept: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
            readonly fileList: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) | (() => import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) | ((new (...args: any[]) => import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) | (() => import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]))[], unknown, unknown, () => [], boolean>;
            readonly autoUpload: import('element-plus/es/utils/index.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
            readonly listType: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, "picture" | "text" | "picture-card", unknown, "text", boolean>;
            readonly httpRequest: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').UploadRequestHandler) | (() => import('element-plus').UploadRequestHandler) | {
                (): import('element-plus').UploadRequestHandler;
                new (): any;
                readonly prototype: any;
            } | ((new (...args: any[]) => import('element-plus').UploadRequestHandler) | (() => import('element-plus').UploadRequestHandler) | {
                (): import('element-plus').UploadRequestHandler;
                new (): any;
                readonly prototype: any;
            })[], unknown, unknown, import('element-plus').UploadRequestHandler, boolean>;
            readonly disabled: BooleanConstructor;
            readonly limit: NumberConstructor;
        }>>, {
            abort: (file: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void;
            submit: () => void;
            clearFiles: (states?: import('element-plus').UploadStatus[]) => void;
            handleStart: (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => void;
            handleRemove: (file: import('element-plus/es/components/upload/src/upload.mjs').UploadFile | import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile, rawFile?: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => void;
        }, unknown, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, Record<string, any>, string, {
            readonly data: import('element-plus/es/utils/index.mjs').EpPropMergeType<(new (...args: any[]) => import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | (() => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | ((new (...args: any[]) => import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | (() => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)))[], unknown, unknown>;
            readonly disabled: boolean;
            readonly drag: boolean;
            readonly multiple: boolean;
            readonly name: string;
            readonly onChange: (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onError: (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onProgress: (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly action: string;
            readonly withCredentials: boolean;
            readonly method: string;
            readonly showFileList: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly accept: string;
            readonly fileList: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[];
            readonly autoUpload: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
            readonly listType: import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "picture" | "text" | "picture-card", unknown>;
            readonly httpRequest: import('element-plus').UploadRequestHandler;
            readonly beforeUpload: (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>;
            readonly onRemove: (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onPreview: (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void;
            readonly onSuccess: (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            readonly onExceed: (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void;
        }, {}, string, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, import('vue').ComponentProvideOptions> & {
            beforeCreate?: (() => void) | (() => void)[];
            created?: (() => void) | (() => void)[];
            beforeMount?: (() => void) | (() => void)[];
            mounted?: (() => void) | (() => void)[];
            beforeUpdate?: (() => void) | (() => void)[];
            updated?: (() => void) | (() => void)[];
            activated?: (() => void) | (() => void)[];
            deactivated?: (() => void) | (() => void)[];
            beforeDestroy?: (() => void) | (() => void)[];
            beforeUnmount?: (() => void) | (() => void)[];
            destroyed?: (() => void) | (() => void)[];
            unmounted?: (() => void) | (() => void)[];
            renderTracked?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            renderTriggered?: ((e: import('vue').DebuggerEvent) => void) | ((e: import('vue').DebuggerEvent) => void)[];
            errorCaptured?: ((err: unknown, instance: ComponentPublicInstance | null, info: string) => boolean | void) | ((err: unknown, instance: ComponentPublicInstance | null, info: string) => boolean | void)[];
        };
        $forceUpdate: () => void;
        $nextTick: typeof import('vue').nextTick;
        $watch<T extends string | ((...args: any) => any)>(source: T, cb: T extends (...args: any) => infer R ? (...args: [R, R, import('@vue/reactivity').OnCleanup]) => any : (...args: [any, any, import('@vue/reactivity').OnCleanup]) => any, options?: import('vue').WatchOptions): import('vue').WatchStopHandle;
    } & Readonly<{
        readonly data: import('element-plus/es/utils/index.mjs').EpPropMergeType<(new (...args: any[]) => import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | (() => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | ((new (...args: any[]) => import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | (() => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)))[], unknown, unknown>;
        readonly disabled: boolean;
        readonly drag: boolean;
        readonly multiple: boolean;
        readonly name: string;
        readonly onChange: (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
        readonly onError: (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
        readonly onProgress: (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
        readonly action: string;
        readonly withCredentials: boolean;
        readonly method: string;
        readonly showFileList: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly accept: string;
        readonly fileList: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[];
        readonly autoUpload: import('element-plus/es/utils/index.mjs').EpPropMergeType<BooleanConstructor, unknown, unknown>;
        readonly listType: import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "picture" | "text" | "picture-card", unknown>;
        readonly httpRequest: import('element-plus').UploadRequestHandler;
        readonly beforeUpload: (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>;
        readonly onRemove: (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
        readonly onPreview: (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void;
        readonly onSuccess: (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
        readonly onExceed: (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void;
    }> & Omit<Readonly<globalThis.ExtractPropTypes<{
        readonly beforeUpload: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>) | (() => (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>) | {
            (): (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>;
            new (): any;
            readonly prototype: any;
        } | ((new (...args: any[]) => (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>) | (() => (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>) | {
            (): (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<void | undefined | null | boolean | File | Blob>;
            new (): any;
            readonly prototype: any;
        })[], unknown, unknown, () => void, boolean>;
        readonly beforeRemove: {
            readonly type: import('vue').PropType<(uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => import('element-plus/es/utils/typescript.mjs').Awaitable<boolean>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly onRemove: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
            (): (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            new (): any;
            readonly prototype: any;
        } | ((new (...args: any[]) => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
            (): (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            new (): any;
            readonly prototype: any;
        })[], unknown, unknown, () => void, boolean>;
        readonly onChange: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
            (): (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            new (): any;
            readonly prototype: any;
        } | ((new (...args: any[]) => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
            (): (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            new (): any;
            readonly prototype: any;
        })[], unknown, unknown, () => void, boolean>;
        readonly onPreview: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void) | (() => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void) | {
            (): (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void;
            new (): any;
            readonly prototype: any;
        } | ((new (...args: any[]) => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void) | (() => (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void) | {
            (): (uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void;
            new (): any;
            readonly prototype: any;
        })[], unknown, unknown, () => void, boolean>;
        readonly onSuccess: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
            (): (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            new (): any;
            readonly prototype: any;
        } | ((new (...args: any[]) => (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
            (): (response: any, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            new (): any;
            readonly prototype: any;
        })[], unknown, unknown, () => void, boolean>;
        readonly onProgress: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
            (): (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            new (): any;
            readonly prototype: any;
        } | ((new (...args: any[]) => (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
            (): (evt: import('element-plus').UploadProgressEvent, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            new (): any;
            readonly prototype: any;
        })[], unknown, unknown, () => void, boolean>;
        readonly onError: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
            (): (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            new (): any;
            readonly prototype: any;
        } | ((new (...args: any[]) => (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | (() => (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void) | {
            (): (error: Error, uploadFile: import('element-plus/es/components/upload/src/upload.mjs').UploadFile, uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadFiles) => void;
            new (): any;
            readonly prototype: any;
        })[], unknown, unknown, () => void, boolean>;
        readonly onExceed: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void) | (() => (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void) | {
            (): (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void;
            new (): any;
            readonly prototype: any;
        } | ((new (...args: any[]) => (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void) | (() => (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void) | {
            (): (files: File[], uploadFiles: import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) => void;
            new (): any;
            readonly prototype: any;
        })[], unknown, unknown, () => void, boolean>;
        readonly crossorigin: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/index.mjs').EpPropMergeType<(new (...args: any[]) => "" | "anonymous" | "use-credentials") | (() => "" | "anonymous" | "use-credentials") | ((new (...args: any[]) => "" | "anonymous" | "use-credentials") | (() => "" | "anonymous" | "use-credentials"))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly action: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "#", boolean>;
        readonly headers: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/index.mjs').EpPropMergeType<(new (...args: any[]) => Record<string, any> | Headers) | (() => Record<string, any> | Headers) | ((new (...args: any[]) => Record<string, any> | Headers) | (() => Record<string, any> | Headers))[], unknown, unknown>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        readonly method: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "post", boolean>;
        readonly data: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | (() => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | ((new (...args: any[]) => import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>> | Promise<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)) | (() => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus/es/utils/typescript.mjs').Mutable<Record<string, any>>> | ((rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => import('element-plus/es/utils/typescript.mjs').Awaitable<import('element-plus').UploadData>)))[], unknown, unknown, () => import('element-plus/es/utils/typescript.mjs').Mutable<{}>, boolean>;
        readonly multiple: BooleanConstructor;
        readonly name: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "file", boolean>;
        readonly drag: BooleanConstructor;
        readonly withCredentials: BooleanConstructor;
        readonly showFileList: import('element-plus/es/utils/index.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly accept: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, unknown, unknown, "", boolean>;
        readonly fileList: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) | (() => import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) | ((new (...args: any[]) => import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]) | (() => import('element-plus/es/components/upload/src/upload.mjs').UploadUserFile[]))[], unknown, unknown, () => [], boolean>;
        readonly autoUpload: import('element-plus/es/utils/index.mjs').EpPropFinalized<BooleanConstructor, unknown, unknown, true, boolean>;
        readonly listType: import('element-plus/es/utils/index.mjs').EpPropFinalized<StringConstructor, "picture" | "text" | "picture-card", unknown, "text", boolean>;
        readonly httpRequest: import('element-plus/es/utils/index.mjs').EpPropFinalized<(new (...args: any[]) => import('element-plus').UploadRequestHandler) | (() => import('element-plus').UploadRequestHandler) | {
            (): import('element-plus').UploadRequestHandler;
            new (): any;
            readonly prototype: any;
        } | ((new (...args: any[]) => import('element-plus').UploadRequestHandler) | (() => import('element-plus').UploadRequestHandler) | {
            (): import('element-plus').UploadRequestHandler;
            new (): any;
            readonly prototype: any;
        })[], unknown, unknown, import('element-plus').UploadRequestHandler, boolean>;
        readonly disabled: BooleanConstructor;
        readonly limit: NumberConstructor;
    }>>, "disabled" | "name" | "multiple" | "beforeUpload" | "onRemove" | "onChange" | "onPreview" | "onSuccess" | "onProgress" | "onError" | "onExceed" | "action" | "method" | "data" | "drag" | "withCredentials" | "showFileList" | "accept" | "fileList" | "autoUpload" | "listType" | "httpRequest" | "abort" | "submit" | "clearFiles" | "handleStart" | "handleRemove"> & import('vue').ShallowUnwrapRef<{
        abort: (file: import('element-plus/es/components/upload/src/upload.mjs').UploadFile) => void;
        submit: () => void;
        clearFiles: (states?: import('element-plus').UploadStatus[]) => void;
        handleStart: (rawFile: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => void;
        handleRemove: (file: import('element-plus/es/components/upload/src/upload.mjs').UploadFile | import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile, rawFile?: import('element-plus/es/components/upload/src/upload.mjs').UploadRawFile) => void;
    }> & {} & import('vue').ComponentCustomProperties & {} & {
        $slots: {
            file?(_: {
                file: import('element-plus/es/components/upload/src/upload.mjs').UploadFile;
                index: number;
            }): any;
            file?(_: {
                file: import('element-plus/es/components/upload/src/upload.mjs').UploadFile;
                index: number;
            }): any;
            trigger?(_: {}): any;
            trigger?(_: {}): any;
            default?(_: {}): any;
            default?(_: {}): any;
            default?(_: {}): any;
            tip?(_: {}): any;
        };
    }) | null;
}, any>;
export default _default;
