export type CrontabValueObj = {
    second: string;
    min: string;
    hour: string;
    day: string;
    month: string;
    week: string;
    year: string;
};
export type CrontabValue = keyof CrontabValueObj;
export type RefsType = {
    cronsecond: any;
    cronmin: any;
    cronhour: any;
    cronday: any;
    cronmonth: any;
    cronweek: any;
    cronyear: any;
};
