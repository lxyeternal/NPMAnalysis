import { PropType } from 'vue';
import { CrontabValueObj, CrontabValue } from './type';
declare const _default: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    tabVal: {
        type: StringConstructor;
        default: string;
    };
    modelValue: {
        type: StringConstructor;
        default: string;
    };
    hideComponent: {
        type: PropType<CrontabValue[]>;
        default: () => never[];
    };
    readonly: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
    fill: (val: string) => any;
    "update:modelValue": (val: string) => any;
    hide: () => any;
    "update:tabVal": (val: string) => any;
}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    tabVal: {
        type: StringConstructor;
        default: string;
    };
    modelValue: {
        type: StringConstructor;
        default: string;
    };
    hideComponent: {
        type: PropType<CrontabValue[]>;
        default: () => never[];
    };
    readonly: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    onFill?: ((val: string) => any) | undefined;
    "onUpdate:modelValue"?: ((val: string) => any) | undefined;
    onHide?: (() => any) | undefined;
    "onUpdate:tabVal"?: ((val: string) => any) | undefined;
}>, {
    modelValue: string;
    readonly: boolean;
    tabVal: string;
    hideComponent: (keyof CrontabValueObj)[];
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
export default _default;
