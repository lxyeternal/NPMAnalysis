import { PropType } from 'vue';
import { CrontabValueObj } from './type';
declare const _default: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    readonly: {
        type: BooleanConstructor;
        default: boolean;
    };
    check: {
        type: FunctionConstructor;
        required: true;
    };
    cron: {
        type: PropType<CrontabValueObj>;
        default: () => {};
    };
}>, {
    changeCycle01: (val: number) => void;
    changeCycle02: (val: number) => void;
    changeAverage01: (val: number) => void;
    changeAverage02: (val: number) => void;
    changeCheckboxList: (val: string[]) => void;
    changeWorkday: (val: number) => void;
    changeRadioValue: (val: number) => void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
    update: (key: string, value: string, type?: string | undefined) => any;
}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    readonly: {
        type: BooleanConstructor;
        default: boolean;
    };
    check: {
        type: FunctionConstructor;
        required: true;
    };
    cron: {
        type: PropType<CrontabValueObj>;
        default: () => {};
    };
}>> & Readonly<{
    onUpdate?: ((key: string, value: string, type?: string | undefined) => any) | undefined;
}>, {
    readonly: boolean;
    cron: CrontabValueObj;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>;
export default _default;
