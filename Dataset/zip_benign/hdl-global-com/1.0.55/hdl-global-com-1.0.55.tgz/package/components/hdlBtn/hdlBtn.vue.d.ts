import { PropType } from 'vue';
import { ButtonType } from '../../utils/type';
declare const _default: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    modelValue: {
        type: PropType<ButtonType[]>;
        required: true;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    modelValue: {
        type: PropType<ButtonType[]>;
        required: true;
    };
}>> & Readonly<{}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    hdlBtn: HTMLDivElement;
}, HTMLDivElement>;
export default _default;
