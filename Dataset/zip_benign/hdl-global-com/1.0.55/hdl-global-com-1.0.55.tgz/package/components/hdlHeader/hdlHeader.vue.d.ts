declare function __VLS_template(): {
    attrs: Partial<{}>;
    slots: {
        left?(_: {}): any;
        center?(_: {}): any;
    };
    refs: {};
    rootEl: HTMLDivElement;
};
type __VLS_TemplateResult = ReturnType<typeof __VLS_template>;
declare const __VLS_component: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    showCollapse: {
        type: BooleanConstructor;
        default: boolean;
    };
    collapse: {
        type: BooleanConstructor;
        default: boolean;
    };
    collapseWidth: {
        type: NumberConstructor;
        default: number;
    };
    width: {
        type: NumberConstructor;
        default: number;
    };
    avatar: {
        type: StringConstructor;
        required: true;
    };
    userName: {
        type: StringConstructor;
        default: string;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
    getMenuStatus: (width: number) => any;
    "update:collapse": (type: boolean) => any;
}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    showCollapse: {
        type: BooleanConstructor;
        default: boolean;
    };
    collapse: {
        type: BooleanConstructor;
        default: boolean;
    };
    collapseWidth: {
        type: NumberConstructor;
        default: number;
    };
    width: {
        type: NumberConstructor;
        default: number;
    };
    avatar: {
        type: StringConstructor;
        required: true;
    };
    userName: {
        type: StringConstructor;
        default: string;
    };
}>> & Readonly<{
    onGetMenuStatus?: ((width: number) => any) | undefined;
    "onUpdate:collapse"?: ((type: boolean) => any) | undefined;
}>, {
    width: number;
    collapseWidth: number;
    showCollapse: boolean;
    collapse: boolean;
    userName: string;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
declare const _default: __VLS_WithTemplateSlots<typeof __VLS_component, __VLS_TemplateResult["slots"]>;
export default _default;
type __VLS_WithTemplateSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
