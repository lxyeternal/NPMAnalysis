declare const _default: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    detailCode: {
        type: StringConstructor;
        default: string;
    };
    currentCode: {
        type: StringConstructor;
        default: string;
    };
    isNeedRefresh: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    detailCode: {
        type: StringConstructor;
        default: string;
    };
    currentCode: {
        type: StringConstructor;
        default: string;
    };
    isNeedRefresh: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{}>, {
    detailCode: string;
    currentCode: string;
    isNeedRefresh: boolean;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, HTMLDivElement>;
export default _default;
