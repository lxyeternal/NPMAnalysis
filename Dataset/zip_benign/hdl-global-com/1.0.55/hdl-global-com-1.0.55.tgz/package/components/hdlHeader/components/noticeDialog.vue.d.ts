import { DictChildType } from '../../../utils/type.ts';
type newDictChildType = DictChildType & Record<string, any>;
declare const _default: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    modelValue: {
        type: BooleanConstructor;
        default: boolean;
    };
    noticeType: {
        type: StringConstructor;
        default: string;
    };
    noticeTypeList: {
        type: PropType<newDictChildType[]>;
        default: () => never[];
    };
    isNeedRefresh: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
    "update:model-value": (type: boolean) => any;
    refreshCount: () => any;
    getData: () => any;
}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    modelValue: {
        type: BooleanConstructor;
        default: boolean;
    };
    noticeType: {
        type: StringConstructor;
        default: string;
    };
    noticeTypeList: {
        type: PropType<newDictChildType[]>;
        default: () => never[];
    };
    isNeedRefresh: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    "onUpdate:model-value"?: ((type: boolean) => any) | undefined;
    onRefreshCount?: (() => any) | undefined;
    onGetData?: (() => any) | undefined;
}>, {
    modelValue: boolean;
    isNeedRefresh: boolean;
    noticeType: string;
    noticeTypeList: newDictChildType[];
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>;
export default _default;
