import { PropType } from 'vue';
import { TableColumn } from '../../utils/type';
declare function __VLS_template(): {
    attrs: Partial<{}>;
    slots: Partial<Record<string, (_: {
        colData: any;
    }) => any>> & {
        expand?(_: {}): any;
        pagination?(_: {
            size: "small";
            pageSizes: number[];
            layout: string;
            background: boolean;
            pagerCount: number;
        }): any;
    };
    refs: {
        hdlTableRef: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<globalThis.ExtractPropTypes<{
            data: {
                type: import('vue').PropType<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow[]>;
                default: () => never[];
            };
            size: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            width: (NumberConstructor | StringConstructor)[];
            height: (NumberConstructor | StringConstructor)[];
            maxHeight: (NumberConstructor | StringConstructor)[];
            fit: {
                type: BooleanConstructor;
                default: boolean;
            };
            stripe: BooleanConstructor;
            border: BooleanConstructor;
            rowKey: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["rowKey"]>;
            showHeader: {
                type: BooleanConstructor;
                default: boolean;
            };
            showSummary: BooleanConstructor;
            sumText: StringConstructor;
            summaryMethod: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["summaryMethod"]>;
            rowClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["rowClassName"]>;
            rowStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["rowStyle"]>;
            cellClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["cellClassName"]>;
            cellStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["cellStyle"]>;
            headerRowClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerRowClassName"]>;
            headerRowStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerRowStyle"]>;
            headerCellClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerCellClassName"]>;
            headerCellStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerCellStyle"]>;
            highlightCurrentRow: BooleanConstructor;
            currentRowKey: (NumberConstructor | StringConstructor)[];
            emptyText: StringConstructor;
            expandRowKeys: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["expandRowKeys"]>;
            defaultExpandAll: BooleanConstructor;
            defaultSort: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["defaultSort"]>;
            tooltipEffect: StringConstructor;
            tooltipOptions: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["tooltipOptions"]>;
            spanMethod: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["spanMethod"]>;
            selectOnIndeterminate: {
                type: BooleanConstructor;
                default: boolean;
            };
            indent: {
                type: NumberConstructor;
                default: number;
            };
            treeProps: {
                type: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["treeProps"]>;
                default: () => {
                    hasChildren: string;
                    children: string;
                    checkStrictly: boolean;
                };
            };
            lazy: BooleanConstructor;
            load: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["load"]>;
            style: {
                type: import('vue').PropType<import('vue').CSSProperties>;
                default: () => {};
            };
            className: {
                type: StringConstructor;
                default: string;
            };
            tableLayout: {
                type: import('vue').PropType<"fixed" | "auto">;
                default: string;
            };
            scrollbarAlwaysOn: BooleanConstructor;
            flexible: BooleanConstructor;
            showOverflowTooltip: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["showOverflowTooltip"]>;
            appendFilterPanelTo: StringConstructor;
            scrollbarTabindex: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            allowDragLastColumn: {
                type: BooleanConstructor;
                default: boolean;
            };
        }>> & {
            onScroll?: ((...args: any[]) => any) | undefined;
            onSelect?: ((...args: any[]) => any) | undefined;
            "onExpand-change"?: ((...args: any[]) => any) | undefined;
            "onCurrent-change"?: ((...args: any[]) => any) | undefined;
            "onSelect-all"?: ((...args: any[]) => any) | undefined;
            "onSelection-change"?: ((...args: any[]) => any) | undefined;
            "onCell-mouse-enter"?: ((...args: any[]) => any) | undefined;
            "onCell-mouse-leave"?: ((...args: any[]) => any) | undefined;
            "onCell-contextmenu"?: ((...args: any[]) => any) | undefined;
            "onCell-click"?: ((...args: any[]) => any) | undefined;
            "onCell-dblclick"?: ((...args: any[]) => any) | undefined;
            "onRow-click"?: ((...args: any[]) => any) | undefined;
            "onRow-contextmenu"?: ((...args: any[]) => any) | undefined;
            "onRow-dblclick"?: ((...args: any[]) => any) | undefined;
            "onHeader-click"?: ((...args: any[]) => any) | undefined;
            "onHeader-contextmenu"?: ((...args: any[]) => any) | undefined;
            "onSort-change"?: ((...args: any[]) => any) | undefined;
            "onFilter-change"?: ((...args: any[]) => any) | undefined;
            "onHeader-dragend"?: ((...args: any[]) => any) | undefined;
        }, {
            ns: {
                namespace: import('vue').ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string) => string;
                m: (modifier?: string) => string;
                be: (blockSuffix?: string, element?: string) => string;
                em: (element?: string, modifier?: string) => string;
                bm: (blockSuffix?: string, modifier?: string) => string;
                bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                is: {
                    (name: string, state: boolean | undefined): string;
                    (name: string): string;
                };
                cssVar: (object: Record<string, string>) => Record<string, string>;
                cssVarName: (name: string) => string;
                cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                cssVarBlockName: (name: string) => string;
            };
            layout: import('element-plus/es/components/table/src/table-layout.mjs').default<any>;
            store: any;
            columns: import('vue').ComputedRef<import('element-plus').TableColumnCtx<unknown>>;
            handleHeaderFooterMousewheel: (event: any, data: any) => void;
            handleMouseLeave: () => void;
            tableId: string;
            tableSize: import('vue').ComputedRef<"" | "small" | "default" | "large">;
            isHidden: import('vue').Ref<boolean>;
            isEmpty: import('vue').ComputedRef<boolean>;
            renderExpanded: import('vue').Ref<null>;
            resizeProxyVisible: import('vue').Ref<boolean>;
            resizeState: import('vue').Ref<{
                width: null | number;
                height: null | number;
                headerHeight: null | number;
            }>;
            isGroup: import('vue').Ref<boolean>;
            bodyWidth: import('vue').ComputedRef<string>;
            tableBodyStyles: import('vue').ComputedRef<{
                width: string;
            }>;
            emptyBlockStyle: import('vue').ComputedRef<{
                width: string;
                height: string;
            } | null>;
            debouncedUpdateLayout: import('lodash').DebouncedFunc<() => void>;
            handleFixedMousewheel: (event: any, data: any) => void;
            setCurrentRow: (row: any) => void;
            getSelectionRows: () => any;
            toggleRowSelection: (row: any, selected?: boolean, ignoreSelectable?: boolean) => void;
            clearSelection: () => void;
            clearFilter: (columnKeys?: string[]) => void;
            toggleAllSelection: () => void;
            toggleRowExpansion: (row: any, expanded?: boolean) => void;
            clearSort: () => void;
            doLayout: () => void;
            sort: (prop: string, order: string) => void;
            updateKeyChildren: (key: string, data: any[]) => void;
            t: import('element-plus').Translator;
            setDragVisible: (visible: boolean) => void;
            context: import('element-plus').Table<any>;
            computedSumText: import('vue').ComputedRef<string>;
            computedEmptyText: import('vue').ComputedRef<string>;
            tableLayout: import('vue').ComputedRef<("fixed" | "auto") | undefined>;
            scrollbarViewStyle: {
                display: string;
                verticalAlign: string;
            };
            scrollbarStyle: import('vue').ComputedRef<{
                height: string;
                maxHeight?: undefined;
            } | {
                maxHeight: string;
                height?: undefined;
            } | {
                height?: undefined;
                maxHeight?: undefined;
            }>;
            scrollBarRef: import('vue').Ref<any>;
            scrollTo: (options: ScrollToOptions | number, yCoord?: number) => void;
            setScrollLeft: (left?: number) => void;
            setScrollTop: (top?: number) => void;
            allowDragLastColumn: boolean;
        }, unknown, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, ("select" | "scroll" | "select-all" | "expand-change" | "current-change" | "selection-change" | "cell-mouse-enter" | "cell-mouse-leave" | "cell-contextmenu" | "cell-click" | "cell-dblclick" | "row-click" | "row-contextmenu" | "row-dblclick" | "header-click" | "header-contextmenu" | "sort-change" | "filter-change" | "header-dragend")[], import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, {
            data: any[];
            style: import('vue').CSSProperties;
            tableLayout: "fixed" | "auto";
            border: boolean;
            className: string;
            fit: boolean;
            lazy: boolean;
            scrollbarAlwaysOn: boolean;
            allowDragLastColumn: boolean;
            stripe: boolean;
            treeProps: import('element-plus/es/components/table/src/table/defaults.mjs').TreeProps | undefined;
            showHeader: boolean;
            showSummary: boolean;
            highlightCurrentRow: boolean;
            defaultExpandAll: boolean;
            selectOnIndeterminate: boolean;
            indent: number;
            flexible: boolean;
            scrollbarTabindex: string | number;
        }, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {}, any, import('vue').ComponentProvideOptions, {
            P: {};
            B: {};
            D: {};
            C: {};
            M: {};
            Defaults: {};
        }, Readonly<globalThis.ExtractPropTypes<{
            data: {
                type: import('vue').PropType<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow[]>;
                default: () => never[];
            };
            size: {
                readonly type: import('vue').PropType<import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
                readonly required: false;
                readonly validator: ((val: unknown) => boolean) | undefined;
                __epPropKey: true;
            };
            width: (NumberConstructor | StringConstructor)[];
            height: (NumberConstructor | StringConstructor)[];
            maxHeight: (NumberConstructor | StringConstructor)[];
            fit: {
                type: BooleanConstructor;
                default: boolean;
            };
            stripe: BooleanConstructor;
            border: BooleanConstructor;
            rowKey: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["rowKey"]>;
            showHeader: {
                type: BooleanConstructor;
                default: boolean;
            };
            showSummary: BooleanConstructor;
            sumText: StringConstructor;
            summaryMethod: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["summaryMethod"]>;
            rowClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["rowClassName"]>;
            rowStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["rowStyle"]>;
            cellClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["cellClassName"]>;
            cellStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["cellStyle"]>;
            headerRowClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerRowClassName"]>;
            headerRowStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerRowStyle"]>;
            headerCellClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerCellClassName"]>;
            headerCellStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerCellStyle"]>;
            highlightCurrentRow: BooleanConstructor;
            currentRowKey: (NumberConstructor | StringConstructor)[];
            emptyText: StringConstructor;
            expandRowKeys: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["expandRowKeys"]>;
            defaultExpandAll: BooleanConstructor;
            defaultSort: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["defaultSort"]>;
            tooltipEffect: StringConstructor;
            tooltipOptions: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["tooltipOptions"]>;
            spanMethod: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["spanMethod"]>;
            selectOnIndeterminate: {
                type: BooleanConstructor;
                default: boolean;
            };
            indent: {
                type: NumberConstructor;
                default: number;
            };
            treeProps: {
                type: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["treeProps"]>;
                default: () => {
                    hasChildren: string;
                    children: string;
                    checkStrictly: boolean;
                };
            };
            lazy: BooleanConstructor;
            load: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["load"]>;
            style: {
                type: import('vue').PropType<import('vue').CSSProperties>;
                default: () => {};
            };
            className: {
                type: StringConstructor;
                default: string;
            };
            tableLayout: {
                type: import('vue').PropType<"fixed" | "auto">;
                default: string;
            };
            scrollbarAlwaysOn: BooleanConstructor;
            flexible: BooleanConstructor;
            showOverflowTooltip: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["showOverflowTooltip"]>;
            appendFilterPanelTo: StringConstructor;
            scrollbarTabindex: {
                type: (NumberConstructor | StringConstructor)[];
                default: undefined;
            };
            allowDragLastColumn: {
                type: BooleanConstructor;
                default: boolean;
            };
        }>> & {
            onScroll?: ((...args: any[]) => any) | undefined;
            onSelect?: ((...args: any[]) => any) | undefined;
            "onExpand-change"?: ((...args: any[]) => any) | undefined;
            "onCurrent-change"?: ((...args: any[]) => any) | undefined;
            "onSelect-all"?: ((...args: any[]) => any) | undefined;
            "onSelection-change"?: ((...args: any[]) => any) | undefined;
            "onCell-mouse-enter"?: ((...args: any[]) => any) | undefined;
            "onCell-mouse-leave"?: ((...args: any[]) => any) | undefined;
            "onCell-contextmenu"?: ((...args: any[]) => any) | undefined;
            "onCell-click"?: ((...args: any[]) => any) | undefined;
            "onCell-dblclick"?: ((...args: any[]) => any) | undefined;
            "onRow-click"?: ((...args: any[]) => any) | undefined;
            "onRow-contextmenu"?: ((...args: any[]) => any) | undefined;
            "onRow-dblclick"?: ((...args: any[]) => any) | undefined;
            "onHeader-click"?: ((...args: any[]) => any) | undefined;
            "onHeader-contextmenu"?: ((...args: any[]) => any) | undefined;
            "onSort-change"?: ((...args: any[]) => any) | undefined;
            "onFilter-change"?: ((...args: any[]) => any) | undefined;
            "onHeader-dragend"?: ((...args: any[]) => any) | undefined;
        }, {
            ns: {
                namespace: import('vue').ComputedRef<string>;
                b: (blockSuffix?: string) => string;
                e: (element?: string) => string;
                m: (modifier?: string) => string;
                be: (blockSuffix?: string, element?: string) => string;
                em: (element?: string, modifier?: string) => string;
                bm: (blockSuffix?: string, modifier?: string) => string;
                bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
                is: {
                    (name: string, state: boolean | undefined): string;
                    (name: string): string;
                };
                cssVar: (object: Record<string, string>) => Record<string, string>;
                cssVarName: (name: string) => string;
                cssVarBlock: (object: Record<string, string>) => Record<string, string>;
                cssVarBlockName: (name: string) => string;
            };
            layout: import('element-plus/es/components/table/src/table-layout.mjs').default<any>;
            store: any;
            columns: import('vue').ComputedRef<import('element-plus').TableColumnCtx<unknown>>;
            handleHeaderFooterMousewheel: (event: any, data: any) => void;
            handleMouseLeave: () => void;
            tableId: string;
            tableSize: import('vue').ComputedRef<"" | "small" | "default" | "large">;
            isHidden: import('vue').Ref<boolean>;
            isEmpty: import('vue').ComputedRef<boolean>;
            renderExpanded: import('vue').Ref<null>;
            resizeProxyVisible: import('vue').Ref<boolean>;
            resizeState: import('vue').Ref<{
                width: null | number;
                height: null | number;
                headerHeight: null | number;
            }>;
            isGroup: import('vue').Ref<boolean>;
            bodyWidth: import('vue').ComputedRef<string>;
            tableBodyStyles: import('vue').ComputedRef<{
                width: string;
            }>;
            emptyBlockStyle: import('vue').ComputedRef<{
                width: string;
                height: string;
            } | null>;
            debouncedUpdateLayout: import('lodash').DebouncedFunc<() => void>;
            handleFixedMousewheel: (event: any, data: any) => void;
            setCurrentRow: (row: any) => void;
            getSelectionRows: () => any;
            toggleRowSelection: (row: any, selected?: boolean, ignoreSelectable?: boolean) => void;
            clearSelection: () => void;
            clearFilter: (columnKeys?: string[]) => void;
            toggleAllSelection: () => void;
            toggleRowExpansion: (row: any, expanded?: boolean) => void;
            clearSort: () => void;
            doLayout: () => void;
            sort: (prop: string, order: string) => void;
            updateKeyChildren: (key: string, data: any[]) => void;
            t: import('element-plus').Translator;
            setDragVisible: (visible: boolean) => void;
            context: import('element-plus').Table<any>;
            computedSumText: import('vue').ComputedRef<string>;
            computedEmptyText: import('vue').ComputedRef<string>;
            tableLayout: import('vue').ComputedRef<("fixed" | "auto") | undefined>;
            scrollbarViewStyle: {
                display: string;
                verticalAlign: string;
            };
            scrollbarStyle: import('vue').ComputedRef<{
                height: string;
                maxHeight?: undefined;
            } | {
                maxHeight: string;
                height?: undefined;
            } | {
                height?: undefined;
                maxHeight?: undefined;
            }>;
            scrollBarRef: import('vue').Ref<any>;
            scrollTo: (options: ScrollToOptions | number, yCoord?: number) => void;
            setScrollLeft: (left?: number) => void;
            setScrollTop: (top?: number) => void;
            allowDragLastColumn: boolean;
        }, {}, {}, {}, {
            data: any[];
            style: import('vue').CSSProperties;
            tableLayout: "fixed" | "auto";
            border: boolean;
            className: string;
            fit: boolean;
            lazy: boolean;
            scrollbarAlwaysOn: boolean;
            allowDragLastColumn: boolean;
            stripe: boolean;
            treeProps: import('element-plus/es/components/table/src/table/defaults.mjs').TreeProps | undefined;
            showHeader: boolean;
            showSummary: boolean;
            highlightCurrentRow: boolean;
            defaultExpandAll: boolean;
            selectOnIndeterminate: boolean;
            indent: number;
            flexible: boolean;
            scrollbarTabindex: string | number;
        }> | null;
    };
    rootEl: any;
};
type __VLS_TemplateResult = ReturnType<typeof __VLS_template>;
declare const __VLS_component: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    isPopup: {
        type: BooleanConstructor;
        default: boolean;
    };
    auth: {
        type: StringConstructor;
        default: string;
    };
    columns: {
        type: PropType<TableColumn>;
        required: true;
    };
    data: {
        type: PropType<any[]>;
        required: true;
    };
}>, {
    clearSelection: () => void;
    getSelectionRows: <T>() => import('../..').TableRowType<T>[];
    toggleRowSelection: <T>(row: import('../..').TableRowType<T>, selected: boolean) => void;
    toggleAllSelection: () => void;
    toggleRowExpansion: <T>(row: import('../..').TableRowType<T>, expanded: boolean) => void;
    setCurrentRow: <T>(row: import('../..').TableRowType<T>) => void;
    clearSort: () => void;
    doLayout: () => void;
    clearFilter: (columnKey?: string[]) => void;
    sort: (prop: string, order: string) => void;
    scrollTo: (options: number | ScrollToOptions, yCoord?: number | undefined) => void;
    setScrollLeft: (left?: number | undefined) => void;
    setScrollTop: (top?: number | undefined) => void;
}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
    rowSort: (params: any) => any;
}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    isPopup: {
        type: BooleanConstructor;
        default: boolean;
    };
    auth: {
        type: StringConstructor;
        default: string;
    };
    columns: {
        type: PropType<TableColumn>;
        required: true;
    };
    data: {
        type: PropType<any[]>;
        required: true;
    };
}>> & Readonly<{
    onRowSort?: ((params: any) => any) | undefined;
}>, {
    auth: string;
    isPopup: boolean;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    hdlTableRef: import('vue').CreateComponentPublicInstanceWithMixins<Readonly<globalThis.ExtractPropTypes<{
        data: {
            type: import('vue').PropType<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow[]>;
            default: () => never[];
        };
        size: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        width: (NumberConstructor | StringConstructor)[];
        height: (NumberConstructor | StringConstructor)[];
        maxHeight: (NumberConstructor | StringConstructor)[];
        fit: {
            type: BooleanConstructor;
            default: boolean;
        };
        stripe: BooleanConstructor;
        border: BooleanConstructor;
        rowKey: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["rowKey"]>;
        showHeader: {
            type: BooleanConstructor;
            default: boolean;
        };
        showSummary: BooleanConstructor;
        sumText: StringConstructor;
        summaryMethod: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["summaryMethod"]>;
        rowClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["rowClassName"]>;
        rowStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["rowStyle"]>;
        cellClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["cellClassName"]>;
        cellStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["cellStyle"]>;
        headerRowClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerRowClassName"]>;
        headerRowStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerRowStyle"]>;
        headerCellClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerCellClassName"]>;
        headerCellStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerCellStyle"]>;
        highlightCurrentRow: BooleanConstructor;
        currentRowKey: (NumberConstructor | StringConstructor)[];
        emptyText: StringConstructor;
        expandRowKeys: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["expandRowKeys"]>;
        defaultExpandAll: BooleanConstructor;
        defaultSort: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["defaultSort"]>;
        tooltipEffect: StringConstructor;
        tooltipOptions: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["tooltipOptions"]>;
        spanMethod: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["spanMethod"]>;
        selectOnIndeterminate: {
            type: BooleanConstructor;
            default: boolean;
        };
        indent: {
            type: NumberConstructor;
            default: number;
        };
        treeProps: {
            type: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["treeProps"]>;
            default: () => {
                hasChildren: string;
                children: string;
                checkStrictly: boolean;
            };
        };
        lazy: BooleanConstructor;
        load: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["load"]>;
        style: {
            type: import('vue').PropType<import('vue').CSSProperties>;
            default: () => {};
        };
        className: {
            type: StringConstructor;
            default: string;
        };
        tableLayout: {
            type: import('vue').PropType<"fixed" | "auto">;
            default: string;
        };
        scrollbarAlwaysOn: BooleanConstructor;
        flexible: BooleanConstructor;
        showOverflowTooltip: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["showOverflowTooltip"]>;
        appendFilterPanelTo: StringConstructor;
        scrollbarTabindex: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        allowDragLastColumn: {
            type: BooleanConstructor;
            default: boolean;
        };
    }>> & {
        onScroll?: ((...args: any[]) => any) | undefined;
        onSelect?: ((...args: any[]) => any) | undefined;
        "onExpand-change"?: ((...args: any[]) => any) | undefined;
        "onCurrent-change"?: ((...args: any[]) => any) | undefined;
        "onSelect-all"?: ((...args: any[]) => any) | undefined;
        "onSelection-change"?: ((...args: any[]) => any) | undefined;
        "onCell-mouse-enter"?: ((...args: any[]) => any) | undefined;
        "onCell-mouse-leave"?: ((...args: any[]) => any) | undefined;
        "onCell-contextmenu"?: ((...args: any[]) => any) | undefined;
        "onCell-click"?: ((...args: any[]) => any) | undefined;
        "onCell-dblclick"?: ((...args: any[]) => any) | undefined;
        "onRow-click"?: ((...args: any[]) => any) | undefined;
        "onRow-contextmenu"?: ((...args: any[]) => any) | undefined;
        "onRow-dblclick"?: ((...args: any[]) => any) | undefined;
        "onHeader-click"?: ((...args: any[]) => any) | undefined;
        "onHeader-contextmenu"?: ((...args: any[]) => any) | undefined;
        "onSort-change"?: ((...args: any[]) => any) | undefined;
        "onFilter-change"?: ((...args: any[]) => any) | undefined;
        "onHeader-dragend"?: ((...args: any[]) => any) | undefined;
    }, {
        ns: {
            namespace: import('vue').ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        layout: import('element-plus/es/components/table/src/table-layout.mjs').default<any>;
        store: any;
        columns: import('vue').ComputedRef<import('element-plus').TableColumnCtx<unknown>>;
        handleHeaderFooterMousewheel: (event: any, data: any) => void;
        handleMouseLeave: () => void;
        tableId: string;
        tableSize: import('vue').ComputedRef<"" | "small" | "default" | "large">;
        isHidden: import('vue').Ref<boolean>;
        isEmpty: import('vue').ComputedRef<boolean>;
        renderExpanded: import('vue').Ref<null>;
        resizeProxyVisible: import('vue').Ref<boolean>;
        resizeState: import('vue').Ref<{
            width: null | number;
            height: null | number;
            headerHeight: null | number;
        }>;
        isGroup: import('vue').Ref<boolean>;
        bodyWidth: import('vue').ComputedRef<string>;
        tableBodyStyles: import('vue').ComputedRef<{
            width: string;
        }>;
        emptyBlockStyle: import('vue').ComputedRef<{
            width: string;
            height: string;
        } | null>;
        debouncedUpdateLayout: import('lodash').DebouncedFunc<() => void>;
        handleFixedMousewheel: (event: any, data: any) => void;
        setCurrentRow: (row: any) => void;
        getSelectionRows: () => any;
        toggleRowSelection: (row: any, selected?: boolean, ignoreSelectable?: boolean) => void;
        clearSelection: () => void;
        clearFilter: (columnKeys?: string[]) => void;
        toggleAllSelection: () => void;
        toggleRowExpansion: (row: any, expanded?: boolean) => void;
        clearSort: () => void;
        doLayout: () => void;
        sort: (prop: string, order: string) => void;
        updateKeyChildren: (key: string, data: any[]) => void;
        t: import('element-plus').Translator;
        setDragVisible: (visible: boolean) => void;
        context: import('element-plus').Table<any>;
        computedSumText: import('vue').ComputedRef<string>;
        computedEmptyText: import('vue').ComputedRef<string>;
        tableLayout: import('vue').ComputedRef<("fixed" | "auto") | undefined>;
        scrollbarViewStyle: {
            display: string;
            verticalAlign: string;
        };
        scrollbarStyle: import('vue').ComputedRef<{
            height: string;
            maxHeight?: undefined;
        } | {
            maxHeight: string;
            height?: undefined;
        } | {
            height?: undefined;
            maxHeight?: undefined;
        }>;
        scrollBarRef: import('vue').Ref<any>;
        scrollTo: (options: ScrollToOptions | number, yCoord?: number) => void;
        setScrollLeft: (left?: number) => void;
        setScrollTop: (top?: number) => void;
        allowDragLastColumn: boolean;
    }, unknown, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, ("select" | "scroll" | "select-all" | "expand-change" | "current-change" | "selection-change" | "cell-mouse-enter" | "cell-mouse-leave" | "cell-contextmenu" | "cell-click" | "cell-dblclick" | "row-click" | "row-contextmenu" | "row-dblclick" | "header-click" | "header-contextmenu" | "sort-change" | "filter-change" | "header-dragend")[], import('vue').VNodeProps & import('vue').AllowedComponentProps & import('vue').ComponentCustomProps, {
        data: any[];
        style: import('vue').CSSProperties;
        tableLayout: "fixed" | "auto";
        border: boolean;
        className: string;
        fit: boolean;
        lazy: boolean;
        scrollbarAlwaysOn: boolean;
        allowDragLastColumn: boolean;
        stripe: boolean;
        treeProps: import('element-plus/es/components/table/src/table/defaults.mjs').TreeProps | undefined;
        showHeader: boolean;
        showSummary: boolean;
        highlightCurrentRow: boolean;
        defaultExpandAll: boolean;
        selectOnIndeterminate: boolean;
        indent: number;
        flexible: boolean;
        scrollbarTabindex: string | number;
    }, true, {}, {}, import('vue').GlobalComponents, import('vue').GlobalDirectives, string, {}, any, import('vue').ComponentProvideOptions, {
        P: {};
        B: {};
        D: {};
        C: {};
        M: {};
        Defaults: {};
    }, Readonly<globalThis.ExtractPropTypes<{
        data: {
            type: import('vue').PropType<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow[]>;
            default: () => never[];
        };
        size: {
            readonly type: import('vue').PropType<import('element-plus/es/utils/index.mjs').EpPropMergeType<StringConstructor, "" | "small" | "default" | "large", never>>;
            readonly required: false;
            readonly validator: ((val: unknown) => boolean) | undefined;
            __epPropKey: true;
        };
        width: (NumberConstructor | StringConstructor)[];
        height: (NumberConstructor | StringConstructor)[];
        maxHeight: (NumberConstructor | StringConstructor)[];
        fit: {
            type: BooleanConstructor;
            default: boolean;
        };
        stripe: BooleanConstructor;
        border: BooleanConstructor;
        rowKey: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["rowKey"]>;
        showHeader: {
            type: BooleanConstructor;
            default: boolean;
        };
        showSummary: BooleanConstructor;
        sumText: StringConstructor;
        summaryMethod: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["summaryMethod"]>;
        rowClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["rowClassName"]>;
        rowStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["rowStyle"]>;
        cellClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["cellClassName"]>;
        cellStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["cellStyle"]>;
        headerRowClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerRowClassName"]>;
        headerRowStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerRowStyle"]>;
        headerCellClassName: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerCellClassName"]>;
        headerCellStyle: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["headerCellStyle"]>;
        highlightCurrentRow: BooleanConstructor;
        currentRowKey: (NumberConstructor | StringConstructor)[];
        emptyText: StringConstructor;
        expandRowKeys: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["expandRowKeys"]>;
        defaultExpandAll: BooleanConstructor;
        defaultSort: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["defaultSort"]>;
        tooltipEffect: StringConstructor;
        tooltipOptions: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["tooltipOptions"]>;
        spanMethod: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["spanMethod"]>;
        selectOnIndeterminate: {
            type: BooleanConstructor;
            default: boolean;
        };
        indent: {
            type: NumberConstructor;
            default: number;
        };
        treeProps: {
            type: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["treeProps"]>;
            default: () => {
                hasChildren: string;
                children: string;
                checkStrictly: boolean;
            };
        };
        lazy: BooleanConstructor;
        load: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["load"]>;
        style: {
            type: import('vue').PropType<import('vue').CSSProperties>;
            default: () => {};
        };
        className: {
            type: StringConstructor;
            default: string;
        };
        tableLayout: {
            type: import('vue').PropType<"fixed" | "auto">;
            default: string;
        };
        scrollbarAlwaysOn: BooleanConstructor;
        flexible: BooleanConstructor;
        showOverflowTooltip: import('vue').PropType<import('element-plus').TableProps<import('element-plus/es/components/table/src/table/defaults.mjs').DefaultRow>["showOverflowTooltip"]>;
        appendFilterPanelTo: StringConstructor;
        scrollbarTabindex: {
            type: (NumberConstructor | StringConstructor)[];
            default: undefined;
        };
        allowDragLastColumn: {
            type: BooleanConstructor;
            default: boolean;
        };
    }>> & {
        onScroll?: ((...args: any[]) => any) | undefined;
        onSelect?: ((...args: any[]) => any) | undefined;
        "onExpand-change"?: ((...args: any[]) => any) | undefined;
        "onCurrent-change"?: ((...args: any[]) => any) | undefined;
        "onSelect-all"?: ((...args: any[]) => any) | undefined;
        "onSelection-change"?: ((...args: any[]) => any) | undefined;
        "onCell-mouse-enter"?: ((...args: any[]) => any) | undefined;
        "onCell-mouse-leave"?: ((...args: any[]) => any) | undefined;
        "onCell-contextmenu"?: ((...args: any[]) => any) | undefined;
        "onCell-click"?: ((...args: any[]) => any) | undefined;
        "onCell-dblclick"?: ((...args: any[]) => any) | undefined;
        "onRow-click"?: ((...args: any[]) => any) | undefined;
        "onRow-contextmenu"?: ((...args: any[]) => any) | undefined;
        "onRow-dblclick"?: ((...args: any[]) => any) | undefined;
        "onHeader-click"?: ((...args: any[]) => any) | undefined;
        "onHeader-contextmenu"?: ((...args: any[]) => any) | undefined;
        "onSort-change"?: ((...args: any[]) => any) | undefined;
        "onFilter-change"?: ((...args: any[]) => any) | undefined;
        "onHeader-dragend"?: ((...args: any[]) => any) | undefined;
    }, {
        ns: {
            namespace: import('vue').ComputedRef<string>;
            b: (blockSuffix?: string) => string;
            e: (element?: string) => string;
            m: (modifier?: string) => string;
            be: (blockSuffix?: string, element?: string) => string;
            em: (element?: string, modifier?: string) => string;
            bm: (blockSuffix?: string, modifier?: string) => string;
            bem: (blockSuffix?: string, element?: string, modifier?: string) => string;
            is: {
                (name: string, state: boolean | undefined): string;
                (name: string): string;
            };
            cssVar: (object: Record<string, string>) => Record<string, string>;
            cssVarName: (name: string) => string;
            cssVarBlock: (object: Record<string, string>) => Record<string, string>;
            cssVarBlockName: (name: string) => string;
        };
        layout: import('element-plus/es/components/table/src/table-layout.mjs').default<any>;
        store: any;
        columns: import('vue').ComputedRef<import('element-plus').TableColumnCtx<unknown>>;
        handleHeaderFooterMousewheel: (event: any, data: any) => void;
        handleMouseLeave: () => void;
        tableId: string;
        tableSize: import('vue').ComputedRef<"" | "small" | "default" | "large">;
        isHidden: import('vue').Ref<boolean>;
        isEmpty: import('vue').ComputedRef<boolean>;
        renderExpanded: import('vue').Ref<null>;
        resizeProxyVisible: import('vue').Ref<boolean>;
        resizeState: import('vue').Ref<{
            width: null | number;
            height: null | number;
            headerHeight: null | number;
        }>;
        isGroup: import('vue').Ref<boolean>;
        bodyWidth: import('vue').ComputedRef<string>;
        tableBodyStyles: import('vue').ComputedRef<{
            width: string;
        }>;
        emptyBlockStyle: import('vue').ComputedRef<{
            width: string;
            height: string;
        } | null>;
        debouncedUpdateLayout: import('lodash').DebouncedFunc<() => void>;
        handleFixedMousewheel: (event: any, data: any) => void;
        setCurrentRow: (row: any) => void;
        getSelectionRows: () => any;
        toggleRowSelection: (row: any, selected?: boolean, ignoreSelectable?: boolean) => void;
        clearSelection: () => void;
        clearFilter: (columnKeys?: string[]) => void;
        toggleAllSelection: () => void;
        toggleRowExpansion: (row: any, expanded?: boolean) => void;
        clearSort: () => void;
        doLayout: () => void;
        sort: (prop: string, order: string) => void;
        updateKeyChildren: (key: string, data: any[]) => void;
        t: import('element-plus').Translator;
        setDragVisible: (visible: boolean) => void;
        context: import('element-plus').Table<any>;
        computedSumText: import('vue').ComputedRef<string>;
        computedEmptyText: import('vue').ComputedRef<string>;
        tableLayout: import('vue').ComputedRef<("fixed" | "auto") | undefined>;
        scrollbarViewStyle: {
            display: string;
            verticalAlign: string;
        };
        scrollbarStyle: import('vue').ComputedRef<{
            height: string;
            maxHeight?: undefined;
        } | {
            maxHeight: string;
            height?: undefined;
        } | {
            height?: undefined;
            maxHeight?: undefined;
        }>;
        scrollBarRef: import('vue').Ref<any>;
        scrollTo: (options: ScrollToOptions | number, yCoord?: number) => void;
        setScrollLeft: (left?: number) => void;
        setScrollTop: (top?: number) => void;
        allowDragLastColumn: boolean;
    }, {}, {}, {}, {
        data: any[];
        style: import('vue').CSSProperties;
        tableLayout: "fixed" | "auto";
        border: boolean;
        className: string;
        fit: boolean;
        lazy: boolean;
        scrollbarAlwaysOn: boolean;
        allowDragLastColumn: boolean;
        stripe: boolean;
        treeProps: import('element-plus/es/components/table/src/table/defaults.mjs').TreeProps | undefined;
        showHeader: boolean;
        showSummary: boolean;
        highlightCurrentRow: boolean;
        defaultExpandAll: boolean;
        selectOnIndeterminate: boolean;
        indent: number;
        flexible: boolean;
        scrollbarTabindex: string | number;
    }> | null;
}, any>;
declare const _default: __VLS_WithTemplateSlots<typeof __VLS_component, __VLS_TemplateResult["slots"]>;
export default _default;
type __VLS_WithTemplateSlots<T, S> = T & {
    new (): {
        $slots: S;
    };
};
