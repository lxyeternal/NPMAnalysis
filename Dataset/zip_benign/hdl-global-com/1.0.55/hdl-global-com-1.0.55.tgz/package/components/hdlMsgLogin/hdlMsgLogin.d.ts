declare const _default: (callback: () => void) => void;
export default _default;
