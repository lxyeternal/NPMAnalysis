import { PropType } from 'vue';
import { SearchType } from '../../utils/type';
declare const _default: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    auth: {
        type: StringConstructor;
        default: string;
    };
    modelValue: {
        type: PropType<SearchType[]>;
        required: true;
    };
    hideBtn: {
        type: BooleanConstructor;
        default: boolean;
    };
    refreshToSearch: {
        type: BooleanConstructor;
        default: boolean;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
    "update:modelValue": (val: SearchType[]) => any;
    search: () => any;
    refresh: () => any;
}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    auth: {
        type: StringConstructor;
        default: string;
    };
    modelValue: {
        type: PropType<SearchType[]>;
        required: true;
    };
    hideBtn: {
        type: BooleanConstructor;
        default: boolean;
    };
    refreshToSearch: {
        type: BooleanConstructor;
        default: boolean;
    };
}>> & Readonly<{
    "onUpdate:modelValue"?: ((val: SearchType[]) => any) | undefined;
    onSearch?: (() => any) | undefined;
    onRefresh?: (() => any) | undefined;
}>, {
    auth: string;
    hideBtn: boolean;
    refreshToSearch: boolean;
}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {
    hdlSearchRef: HTMLDivElement;
}, any>;
export default _default;
