declare const _default: (src: string, isImg?: boolean) => void;
export default _default;
