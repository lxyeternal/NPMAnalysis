declare const _default: import('vue').DefineComponent<globalThis.ExtractPropTypes<{
    modelValue: {
        type: BooleanConstructor;
        required: true;
    };
    src: {
        type: StringConstructor;
        required: true;
    };
    isImg: {
        type: BooleanConstructor;
        required: true;
    };
}>, {}, {}, {}, {}, import('vue').ComponentOptionsMixin, import('vue').ComponentOptionsMixin, {} & {
    "update:model-value": (val: boolean) => any;
}, string, import('vue').PublicProps, Readonly<globalThis.ExtractPropTypes<{
    modelValue: {
        type: BooleanConstructor;
        required: true;
    };
    src: {
        type: StringConstructor;
        required: true;
    };
    isImg: {
        type: BooleanConstructor;
        required: true;
    };
}>> & Readonly<{
    "onUpdate:model-value"?: ((val: boolean) => any) | undefined;
}>, {}, {}, {}, {}, string, import('vue').ComponentProvideOptions, true, {}, any>;
export default _default;
