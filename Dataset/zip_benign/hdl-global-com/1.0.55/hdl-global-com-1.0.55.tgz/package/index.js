import { ElDialog as _g, ElMessage as Ae, genFileId as qg } from "element-plus";
import { defineComponent as q, openBlock as y, createBlock as U, unref as v, mergeProps as ae, withCtx as n, createElementBlock as N, createApp as $g, reactive as Ie, ref as W, shallowRef as cg, watch as M, onUnmounted as eg, onMounted as pe, onBeforeUnmount as Hg, nextTick as Xg, useTemplateRef as he, resolveComponent as S, createElementVNode as x, createVNode as t, createTextVNode as k, Fragment as T, renderList as $, toDisplayString as P, h as Zg, normalizeProps as Kg, guardReactiveProps as Sg, isRef as fe, Teleport as eI, withDirectives as We, vShow as Rg, resolveDynamicComponent as xe, createCommentVNode as E, renderSlot as we, normalizeClass as Xe, computed as _, resolveDirective as ng, normalizeStyle as me, toHandlers as pg, useSlots as gI, useAttrs as II, inject as lI, provide as CI } from "vue";
import wg from "axios";
import yg from "qs";
import { Avatar as dg, Lock as AI, LoadingOne as aI, MenuFoldOne as oI, MenuUnfoldOne as tI, FullScreen as Gg, OffScreen as vg, Remind as nI, Extend as dI, Power as sI, Search as fg, Refresh as uI, Filter as cI, AddThree as Ne, Down as iI, Drag as Wg, FolderUpload as mI, DeleteOne as bI } from "@icon-park/vue-next";
import rI from "jsencrypt";
import { useRouter as Yg, useRoute as ZI } from "vue-router";
import Je from "screenfull";
import pI from "sortablejs";
import { VAceEditor as yI } from "vue3-ace-editor";
import Cg from "ace-builds";
const gg = {
  getPublicKey: "/micro_com_api/uaa/uaa/getPublicKey",
  // 获取公钥
  getDictChild: "/micro_com_api/base/sys/dict/findDictDetailListByCode",
  // 获取参数字典
  login: "/micro_com_api/uaa/uaa/loginUser",
  // 登录系统
  logout: "/micro_com_api/uaa/uaa/logout",
  // 微服务退出接口
  fileUpload: "/micro_com_api/base/fileImprot/fileUpload",
  // 文件上传
  downFile: "/micro_com_api/base/fileImprot/fileDownload",
  // 文件下载
  getMenuData: "/micro_com_api/base/sys/menu/nav",
  // 获取菜单数据
  getPageAuth: "/micro_com_api/base/sys/page-config/detail/list",
  // 获取页面权限
  getNoticeUnreadCount: "/micro_com_api/notify/v2/user-notify/count/unread",
  // 获取未读消息数量
  noticeListPage: "/micro_com_api/notify/v2/user-notify/list-page",
  // 工单、任务、报警列表
  noticeList: "/micro_com_api/notify/v2/user-notify/list",
  // 公告、系统列表
  noticeRead: "/micro_com_api/notify/v2/user-notify/read",
  // 标记已读
  noticeReadAll: "/micro_com_api/notify/v2/user-notify/read/all",
  // 标记全部已读
  wsNotify: "/wsNotify/notify/ws",
  // ws通知地址
  baseSocket: "/wsNotify/base/ws"
  // 用户登录记录及状态的ws
}, GI = ["src"], vI = ["src"], WI = /* @__PURE__ */ q({
  __name: "hdlImgPreview",
  props: {
    modelValue: {
      // 弹窗状态
      type: Boolean,
      required: !0
    },
    src: {
      // 待预览的资源地址
      type: String,
      required: !0
    },
    isImg: {
      // 是否是图片，有可能是视频
      type: Boolean,
      required: !0
    }
  },
  emits: ["update:model-value"],
  setup(e, { emit: a }) {
    const l = e, I = a, A = () => {
      l.modelValue && I("update:model-value", !l.modelValue);
    };
    return (g, d) => (y(), U(v(_g), ae({ class: "small-dialog" }, v(Ye).dialogAttr, {
      closeOnClickModal: "",
      closeOnPressEscape: "",
      "model-value": e.modelValue,
      "onUpdate:modelValue": A
    }), {
      default: n(() => [
        e.isImg ? (y(), N("img", {
          key: 0,
          src: e.src,
          class: "full-box"
        }, null, 8, GI)) : (y(), N("video", {
          key: 1,
          src: e.src,
          controls: "",
          class: "full-box"
        }, null, 8, vI))
      ]),
      _: 1
    }, 16, ["model-value"]));
  }
}), hI = (e, a = !0) => {
  const l = document.createDocumentFragment();
  $g(WI, {
    modelValue: !0,
    src: e,
    isImg: a
  }).mount(l), document.body.appendChild(l);
}, VI = () => {
  const e = W("HDL_TOKEN"), a = W("HDL_USER"), l = W("HDL_MENU_SN"), I = W("HDL_MENU"), A = W("HDL_USER_NAME"), g = W("HDL_PWD"), d = W("HDL_TYPE");
  return {
    HDL_MENU: I,
    HDL_MENU_SN: l,
    HDL_TOKEN: e,
    HDL_USER: a,
    HDL_USER_NAME: A,
    HDL_PWD: g,
    HDL_TYPE: d,
    useSetConfig: (Z) => {
      I.value = (Z == null ? void 0 : Z.HDL_MENU) || I.value, l.value = (Z == null ? void 0 : Z.HDL_MENU_SN) || l.value, a.value = (Z == null ? void 0 : Z.HDL_USER) || a.value, e.value = (Z == null ? void 0 : Z.HDL_TOKEN) || e.value, A.value = (Z == null ? void 0 : Z.HDL_USER_NAME) || A.value, g.value = (Z == null ? void 0 : Z.HDL_PWD) || g.value, d.value = (Z == null ? void 0 : Z.HDL_TYPE) || d.value;
    }
  };
}, Ce = VI(), BI = () => {
  const e = W("/main"), a = W("/login"), l = W("refreshRoute"), I = W("3");
  return {
    loginSuccessRoute: e,
    useSetConfig: (g) => {
      e.value = (g == null ? void 0 : g.loginSuccessRoute) || e.value, a.value = (g == null ? void 0 : g.loginRoute) || a.value, l.value = (g == null ? void 0 : g.refreshRouteName) || l.value, I.value = (g == null ? void 0 : g.qkMenuType) || I.value;
    },
    refreshRouteName: l,
    loginRoute: a,
    qkMenuType: I
  };
}, He = BI(), HI = () => {
  const e = W(20), a = W(5), l = W([10, 20, 50]), I = W([5, 10, 20]), A = (d) => {
    d != null && d.pageSizes && (l.value = d.pageSizes), d != null && d.popupPageSizes && (I.value = d.popupPageSizes), d != null && d.pageSize && (e.value = d.pageSize), d != null && d.popupPageSize && (a.value = d.popupPageSize);
  };
  return {
    useSetConfig: (d) => {
      A(d);
    },
    pageSize: e,
    popupPageSize: a,
    pageSizes: l,
    popupPageSizes: I
  };
}, Be = HI(), XI = () => {
  const e = W(240), a = W(80);
  return {
    width: e,
    collapseWidth: a,
    useSetConfig: (I) => {
      e.value = (I == null ? void 0 : I.width) || e.value, a.value = (I == null ? void 0 : I.collapseWidth) || a.value;
    }
  };
}, hg = XI(), KI = () => {
  const e = W(192);
  return {
    width: e,
    useSetConfig: (l) => {
      e.value = (l == null ? void 0 : l.width) || e.value;
    }
  };
}, kg = KI(), SI = () => {
  const e = W("80px");
  return {
    useSetConfig: (l) => {
      e.value = (l == null ? void 0 : l.labelWidth) || e.value;
    },
    labelWidth: e
  };
}, Jg = SI(), RI = () => {
  const e = W(260), a = W(200), l = W(320);
  return {
    useSetConfig: (A) => {
      e.value = (A == null ? void 0 : A.width) || e.value, a.value = (A == null ? void 0 : A.minWidth) || a.value, l.value = (A == null ? void 0 : A.maxWidth) || l.value;
    },
    width: e,
    mixWidth: a,
    maxWidth: l
  };
}, Re = RI(), wI = () => {
  const e = Ie({
    closeOnClickModal: !1,
    // 是否可以通过点击 modal 关闭 Dialog
    closeOnPressEscape: !1,
    // 是否可以通过按下 ESC 关闭 Dialog
    appendTo: "body",
    // 弹窗添加到哪个位置
    draggable: !0
    // 为 Dialog 启用可拖拽功能
  });
  return {
    useSetConfig: (l) => {
      e.appendTo = (l == null ? void 0 : l.appendTo) || e.appendTo;
    },
    dialogAttr: e
  };
}, Ye = wI(), rA = Ie({
  // 这个没有组件，纯粹是想统一一下配置项，上传组件
  headers: {
    Authorization: "Bearer " + localStorage.getItem(Ce.HDL_TOKEN.value)
  },
  action: gg.fileUpload,
  accept: "image/png, image/jpg, image/jpeg, image/gif",
  listType: "picture-card",
  beforeUpload(e) {
    if (e.size && e.size > 10485760)
      return Ae.warning("文件大小不能超过10M"), !1;
  },
  onExceed() {
    Ae.warning("超出上传限制，请先删除后再上传");
  },
  onPreview(e) {
    var l;
    const a = ((l = e.raw) == null ? void 0 : l.type.indexOf("image")) !== -1;
    hI(e.url, a);
  }
}), fI = () => {
  const e = W([1e3, 3e3, 1e4, 3e4, 6e4]);
  return {
    reconnectInter: e,
    useSetConfig: (l) => {
      l != null && l.reconnectInter && (e.value = l.reconnectInter);
    }
  };
}, Ng = fI(), YI = (e) => {
  He.useSetConfig(e == null ? void 0 : e.hdlLogin), Be.useSetConfig(e == null ? void 0 : e.hdlTable), Ce.useSetConfig(e == null ? void 0 : e.localStorageKey), kg.useSetConfig(e == null ? void 0 : e.hdlSearch), Jg.useSetConfig(e == null ? void 0 : e.hdlForm), Re.useSetConfig(e == null ? void 0 : e.hdlTree), Ng.useSetConfig(e == null ? void 0 : e.hdlWs), Ye.useSetConfig(e == null ? void 0 : e.hdlDialog);
}, ig = wg.create(), kI = [200, 201], JI = "0000", Le = /* @__PURE__ */ new Map(), NI = (e) => {
  var I;
  const a = (I = e == null ? void 0 : e.response) == null ? void 0 : I.status;
  if (!a) {
    console.log("请求已取消，无任何返回。");
    return;
  }
  const l = parseInt((a / 100).toString());
  if (a === 404)
    throw Ae({
      message: `${a}：接口不存在`,
      type: "error",
      grouping: !0
      // 是否将相同的提示信息合并为一条
    }), Error("接口不存在");
  switch (l) {
    case 4:
      a === 401 ? jg().emit("logout") : Ae({
        message: `${a}：${e.data.resMsg}`,
        type: "error",
        grouping: !0
        // 是否将相同的提示信息合并为一条
      });
      break;
    case 5:
      Ae({
        message: `${a}：服务端内部出错 状态异常 请联系管理员`,
        type: "error",
        grouping: !0
        // 是否将相同的提示信息合并为一条
      });
      break;
  }
}, xg = (e) => {
  const { url: a, method: l, params: I, data: A } = e;
  return [a, l, yg.stringify(I), yg.stringify(A)].join("&");
}, xI = (e) => {
  const a = xg(e);
  Le.has(a) || (e.cancelToken = new wg.CancelToken((l) => {
    Le.set(a, l);
  }));
}, Lg = (e) => {
  const a = xg(e);
  Le.has(a) && (Le.get(a)("已取消请求"), Le.delete(a));
};
ig.interceptors.request.use((e) => {
  const a = localStorage.getItem(Ce.HDL_TOKEN.value);
  return a && (e.headers.Authorization = `Bearer ${a}`), Lg(e), xI(e), e;
}, (e) => Promise.reject(e));
ig.interceptors.response.use((e) => (Lg(e.config), kI.includes(e.status) ? e.data.resCode && e.data.resCode !== JI ? Promise.reject(e) : Promise.resolve(e) : Promise.reject(e)), (e) => (NI(e), Promise.reject(e)));
const LI = ["get", "delete", "GET", "DELETE"], FI = (e) => (a) => {
  let l = "data";
  return (LI.includes(a.method || "") || !a.method) && (l = "params"), a.paramsType && (l = a.paramsType), new Promise((I) => {
    ig({
      url: a.orderUrl ? a.url : `${e[a.url]}${a.params || ""}`,
      method: a.method || "get",
      responseType: a.responseType || "json",
      [l]: a.data || {}
    }).then((A) => {
      a.noFormat ? I(A) : I(A.data);
    }).catch((A) => {
      if (a.aloneFunc && typeof a.aloneFunc == "function" && a.aloneFunc(A), A.code !== "ERR_CANCELED") {
        if (A.code === "ERR_BAD_REQUEST") {
          Ae({
            message: "登录过期，请重新登录",
            type: "warning",
            grouping: !0
            // 是否将相同的提示信息合并为一条
          });
          return;
        }
        throw Ae({
          message: A.data.resMsg,
          type: "error",
          grouping: !0
          // 是否将相同的提示信息合并为一条
        }), Error(A);
      }
    });
  });
}, ie = FI(gg), Fg = cg([]), sg = W([]), Ug = W(""), ZA = (e, a, l = ["components"]) => {
  Ug.value = a;
  for (const I in e) {
    if (l.some((d) => I.includes(d)))
      continue;
    const A = I.split("/"), g = A[A.length - 1].split(".vue")[0];
    Fg.value.push({
      name: g,
      view: e[I]
    });
  }
}, zg = (e) => {
  var l;
  const a = [];
  for (let I = 0; I < e.length; I++)
    e[I].type === 1 ? a.push(e[I]) : e[I].childs && ((l = e[I].childs) != null && l.length) && a.push(...zg(e[I].childs));
  return a;
}, UI = (e, a) => {
  const l = zg(a);
  for (let I = 0; I < l.length; I++) {
    const A = l[I].url, g = Fg.value.find((d) => d.name === A);
    g && (e.hasRoute(A) || (e.addRoute(Ug.value, {
      name: A,
      path: `/${A}`,
      component: g.view
    }), sg.value.push(A)));
  }
}, Vg = (e) => {
  sg.value.forEach((a) => {
    e.hasRoute(a) && e.removeRoute(a);
  }), sg.value = [];
}, zI = async (e, a) => {
  const l = localStorage.getItem(Ce.HDL_TOKEN.value), I = He.loginRoute.value;
  Vg(e), UI(e, a), await e.isReady(), e.beforeEach((A, g, d) => {
    if (A.path === I)
      return Vg(e), d();
    if (!l)
      return d({ path: I });
    if (!a.length)
      return d({ path: "/404" });
    if (A.name === He.refreshRouteName.value)
      return d({ path: A.path, replace: !0 });
    d();
  });
}, ce = (e = 6) => {
  let a = Math.random().toString(36).slice(2, 2 + e);
  return a.length < e && (a += ce(e - a.length)), a;
}, Ze = (e, a = { delay: 400, isImmediate: !0 }) => {
  const { delay: l = 250, isImmediate: I = !0 } = a;
  let A = null, g = !0;
  return (...d) => {
    A && clearTimeout(A), I && g && (e(...d), g = !1), A = window.setTimeout(() => {
      g = !0, I || e(...d);
    }, l);
  };
}, pA = async (e = 0) => new Promise((a) => {
  setTimeout(() => {
    a();
  }, e);
}), yA = (e, a = "YYYY-MM-DD") => {
  const l = new Date(e), I = {
    yyyy: l.getFullYear(),
    // 年份
    YYYY: l.getFullYear(),
    // 年份
    MM: l.getMonth() + 1,
    // 月份
    dd: l.getDate(),
    // 日
    DD: l.getDate(),
    // 日
    HH: l.getHours(),
    // 小时(24小时制)
    hh: l.getHours() % 12 === 0 ? 12 : l.getHours() % 12,
    // 小时(12小时制)
    mm: l.getMinutes(),
    // 分
    ss: l.getSeconds()
    // 秒
  };
  let A = a;
  for (const g in I)
    A = A.replace(
      g,
      I[g] < 10 ? "0" + I[g] : I[g] + ""
    );
  return A;
}, jI = (e) => {
  const a = {};
  for (const l in e)
    e[l] !== void 0 && e[l] !== "" && (a[l] = e[l]);
  return a;
}, DI = (e) => (a) => {
  const l = W(0), I = W(a.isPopup ? Be.popupPageSize.value : Be.pageSize.value), A = W(1), g = W(!0), d = Object.prototype.hasOwnProperty.call(a, "immediate") ? a.immediate : !0, c = W([]), Z = W(null), G = W({}), K = W(a.url), b = (o) => {
    g.value = !1, A.value = 1, I.value = a.isPopup ? Be.popupPageSize.value : Be.pageSize.value, o && setTimeout(() => {
      g.value = !0;
    }, 100);
  }, s = async (o, H) => {
    var i;
    typeof o == "boolean" ? b(!0) : o !== void 0 && (G.value = o), H && b(!0);
    const h = await e({
      url: K.value,
      data: jI({
        limit: I.value,
        page: A.value,
        ...a.data || {},
        ...G.value || {}
      }),
      method: a.method || "get"
    });
    Z.value = null, c.value = ((i = h.resData) == null ? void 0 : i.list) || [], l.value = h.resData.total, h.resData.pages && A.value > h.resData.pages && (A.value = h.resData.pages);
  }, R = () => {
    b(), l.value = 0, c.value = [];
  }, u = (o) => {
    K.value = o;
  };
  return d && s(), M([I, A], () => {
    if (!g.value) {
      g.value = !0;
      return;
    }
    s();
  }), {
    total: l,
    pageSize: I,
    currentPage: A,
    tableData: c,
    rowData: Z,
    getTableData: s,
    resetTable: R,
    updateTableUrl: u
  };
}, ug = async (e, a) => {
  const l = W([]), I = await ie({
    url: "getDictChild",
    data: {
      code: e,
      ...a || {}
    }
  });
  return l.value = I.resData, l.value;
}, Te = {}, jg = () => ({
  emit(e, ...a) {
    Te[e] && Te[e](...a);
  },
  on(e, a) {
    Te[e] = a;
  },
  off(e) {
    delete Te[e];
  }
}), GA = (e, a) => {
  const l = Object.assign({}, e);
  for (const I in e)
    l[I] = a[I];
  return l;
}, OI = async (e, a = "blob") => {
  const { uuid: l, id: I } = e, A = await ie({
    url: "downFile",
    data: {
      uuid: l,
      id: I
    },
    noFormat: !0,
    responseType: a
  }), g = new Blob([A.data], {
    type: "application/octet-stream"
  });
  return window.URL.createObjectURL(g);
}, Me = /* @__PURE__ */ new WeakMap(), Dg = (e, a, l = !1) => {
  const I = new ResizeObserver(Ze((d) => {
    for (const c of d) {
      const Z = Me.get(c.target);
      if (Z) {
        if (!Z.flag) {
          Me.set(c.target, {
            flag: !0,
            callback: Z.callback
          });
          continue;
        }
        Z.callback && typeof Z.callback == "function" && Z.callback({
          width: c.borderBoxSize[0].inlineSize,
          height: c.borderBoxSize[0].blockSize,
          contentWidth: c.contentBoxSize[0].inlineSize,
          contentHeight: c.contentBoxSize[0].blockSize
        });
      }
    }
  }, {
    isImmediate: !1,
    delay: 100
  })), A = () => {
    Me.set(e, {
      flag: l,
      callback: a
    }), I.observe(e);
  }, g = () => {
    I.unobserve(e), Me.delete(e);
  };
  A(), eg(() => {
    g();
  });
}, Og = (e, a) => {
  const l = cg(null);
  pe(() => {
    if (!e.value) {
      console.warn("DOM元素不存在");
      return;
    }
    l.value = new MutationObserver(Ze(a, {
      isImmediate: !1,
      delay: 100
    })), l.value.observe(e.value, {
      childList: !0,
      // 观察目标子节点的变化
      subtree: !0,
      // 观察后代节点
      attributes: !1
      // 观察属性的变化
    });
  }), eg(() => {
    var I;
    (I = l.value) == null || I.disconnect();
  });
}, _e = W({});
let Ag = !1, ag = [];
const mg = async () => {
  const e = localStorage.getItem(Ce.HDL_MENU_SN.value);
  return new Promise((a, l) => {
    if (Object.prototype.hasOwnProperty.call(_e.value, e)) {
      a(_e.value[e]);
      return;
    }
    if (Ag) {
      ag.push({ resolve: a, reject: l });
      return;
    }
    Ag = !0, ie({
      url: "getPageAuth",
      data: {
        menuSn: e,
        status: 1
      }
    }).then((I) => {
      _e.value = {
        [e]: I.resData
      }, a(I.resData), Ag = !1, ag.map((A) => {
        A.resolve(I.resData);
      }), ag = [];
    });
  });
}, TI = (e, a) => {
  const l = window.URL.createObjectURL(e), I = document.createElement("a");
  I.style.display = "none", I.href = l, I.setAttribute("download", decodeURI(a)), document.body.appendChild(I), I.click(), document.body.removeChild(I);
}, vA = (e, a, l) => {
  const I = e.headers["content-disposition"].split(";");
  let A = "", g = "";
  for (let c = 0; c < I.length; c++)
    if (I[c].indexOf("filename=") !== -1) {
      const Z = I[c].replace("filename=", ""), G = Z.split(".");
      g = "." + G[G.length - 1], A = Z.replace(g, "");
      break;
    }
  a && (A = a), l && (g = l);
  const d = new Blob([e.data], {
    type: "application/octet-stream"
  });
  TI(d, A + g);
}, MI = async () => {
  const e = "iconScriptId";
  if (document.getElementById(e))
    return;
  const l = await ug("iconfont_address");
  if (!(l && l.length))
    return;
  const I = document.createElement("script");
  I.setAttribute("id", e), I.setAttribute("type", "text/javascript"), I.setAttribute("src", l[0].detailDescn), document.head.appendChild(I);
}, WA = (e, a) => {
  let l = 0, I = null, A = null;
  const g = (a == null ? void 0 : a.direction) || "upper", d = () => {
    const b = document.createDocumentFragment();
    for (let s = 0; s < I.children.length; s++) {
      const R = I.children[s].cloneNode(!0);
      b.appendChild(R);
    }
    I == null || I.appendChild(b);
  }, c = () => {
    l = l - ((a == null ? void 0 : a.speed) ?? 0.7) * (g === "down" ? -1 : 1);
    const b = I.offsetHeight;
    Math.abs(l) >= b / 2 && g === "upper" ? l = 0 : l >= 0 && g === "down" && (l = -b / 2), I.style.transform = `translateY(${l}px)`, A = requestAnimationFrame(c);
  }, Z = () => {
    A && cancelAnimationFrame(A);
  }, G = () => {
    requestAnimationFrame(c);
  }, K = () => {
    I = document.querySelector(e), Xg(() => {
      var R;
      const b = I.offsetHeight;
      (((R = I.parentElement) == null ? void 0 : R.offsetHeight) || 0) >= b || (d(), c(), I.addEventListener("mouseenter", Z), I.addEventListener("mouseleave", G));
    });
  };
  return Hg(() => {
    A && cancelAnimationFrame(A), I && I.removeEventListener("mouseenter", Z), I && I.removeEventListener("mouseleave", G);
  }), K;
}, og = /* @__PURE__ */ new WeakMap(), QI = {
  mounted(e) {
    const a = e.previousElementSibling, l = e.nextElementSibling;
    !a || !l || (e.onmousedown = (I) => {
      const A = I.clientX - a.offsetWidth;
      return document.onmousemove = (g) => {
        let d = g.clientX - A;
        d >= Re.maxWidth.value && (d = Re.maxWidth.value), d <= Re.mixWidth.value && (d = Re.mixWidth.value), a.style.width = d + "px", l.style.width = `calc(100% - ${d + e.offsetWidth}px)`;
      }, document.onmouseup = () => {
        document.onmousemove = null, document.onmouseup = null;
      }, !1;
    });
  },
  unmounted(e) {
    e.onmousedown = null;
  }
}, PI = {
  mounted(e, a) {
    const l = a.arg, I = a.value;
    if (Object.prototype.hasOwnProperty.call(l, "developShow") && l.developShow)
      return;
    const A = JSON.parse(localStorage.getItem(Ce.HDL_MENU.value) || "[]"), g = localStorage.getItem(Ce.HDL_MENU_SN.value);
    if (!A.length) {
      e.parentElement.remove(), I && typeof I == "function" && I();
      return;
    }
    const d = A.find((G) => G.sn === g && G.perms !== null && G.perms !== "");
    if (!d) {
      e.parentElement.remove(), I && typeof I == "function" && I();
      return;
    }
    const c = d.perms;
    (c.startsWith("{") ? JSON.parse(c) : {})[l.auth] !== 1 && (e.parentElement.remove(), I && typeof I == "function" && I()), e.parentElement.setAttribute("auth", l.auth);
  }
}, EI = {
  updated(e, a) {
    const l = a.value;
    if (!(l != null && l.length) || og.has(e))
      return;
    og.set(e, !0);
    const I = a.arg.split("-"), A = I[0], g = I[1], d = I[2];
    if (!A || !g)
      return;
    const c = l.find((Z) => Z.code === g);
    if (c) {
      if (!c.prop.auth) {
        e.parentElement.remove();
        return;
      }
      if (d !== "undefined" && !c.prop.onlyAuth) {
        e.parentElement.remove();
        return;
      }
      e.parentElement.setAttribute("auth", g);
    }
  },
  unmounted(e) {
    og.delete(e);
  }
}, _I = {
  mounted(e, a) {
    var K, b;
    const l = a.value[0], I = a.value[1], A = a.value[2], g = a.arg;
    if (!l || !I)
      return;
    const d = ((b = (K = _e.value[l]) == null ? void 0 : K.find((s) => s.code === l)) == null ? void 0 : b.formConfigList) ?? [];
    if (!d.length)
      return;
    const c = d.find((s) => s.code === I), Z = c == null ? void 0 : c.prop, G = A && !(Z != null && Z.onlyAuth);
    if (!Z || !Z.auth || G) {
      e.remove();
      return;
    }
    g && typeof g == "function" && g(Z);
  }
}, Qe = /* @__PURE__ */ new WeakMap(), qI = {
  mounted(e, a) {
    const l = a.value;
    let I = !0;
    const A = new ResizeObserver(Ze((g) => {
      if (I) {
        I = !1;
        return;
      }
      for (const d of g)
        l && typeof l == "function" && l(d.contentRect.width, d.contentRect.height);
    }, {
      isImmediate: !1,
      delay: 100
    }));
    A.observe(e), Qe.has(e) || Qe.set(e, A);
  },
  unmounted(e) {
    var a;
    (a = Qe.get(e)) == null || a.unobserve(e), Qe.delete(e);
  }
}, $I = {
  install(e) {
    e.directive("treeDrag", QI), e.directive("btnAuth", PI), e.directive("searchAuth", EI), e.directive("formAuth", _I), e.directive("resize", qI);
  }
}, el = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGwAAABYCAYAAAAQjRJ2AAAAAXNSR0IArs4c6QAAIABJREFUeF7tfQdUVNf29zm3TIcB6V2EiGLvJRpNbGhU7AWNsTcisfdu7CJ2jTWxG41GrFiINZZYUbHTFEE6DNNu/dYe5/rd8PQlecH/0ve8y1nDzJx7yv6d3fe5YvTx+qAogD+o2X6cLPoI2Ae2CT4C9hGwD4wCH9h0P3LYR8A+MAp8YNP9yGEfAfvAKPCBTfcjh30E7O9RQBRF26bBGIt/787/zdbvhMPsIEDftv6LENKTxgJ/IS/fgTSbdchqRaTFIvIqHeaVZDGh1RtIF5d8XqWyahEyIIRYhJAAL4wxvH+87BQodcBEUaQQQkrD9ast8JmLTfHdyxWIB/fL4LRUjWgxa7CVpQgTAIkpkRAxVhNWXqs0ERpHi+jiaWKDy2Wi8sHZVGitR6h+7WR1QNBphJDRDt7/PBeWGmCiKBJFp460Fn/a3ZiKO1adSMsNoDDyoBFyEoHMxKuhMIEQooB1ECLge1a0fXglGQVRRITAIVEQkcgiJcqzlg9IoGrXTeYaN08ivmh2WxcQ9BvchTHm/xfZ7h8DBuIP9I8oiqr0rm3GOe079rkSIRcKYxdBFJ0xQkoRNBR6zRw2ZfV6YCWBREpABEGIiMTQFCEsYJETES4WERIxL4jYzBHIyCLBItav8Qh92e4R06Hz0TKhVeMRQtz/ktj8R4Dl308ui4Z17ktEjn/s2KX7HowxJ4oiaXryoA2fmFiRePHcWcx87kpkZupRRqaOzM/XihaTKFgZBWksVon5+RRRbCUQC1BhgkRYQWBMi6KoFLGgRSpMIwUmCBpj0GqiiQftJiJEmBgk5rA1gxPE7n3PiT2/Oufo53cLIcT/t4P3twED0YfQK3YpOnu2B2rarDtuUPO+46XfJ0ncJhdVMgPEJhFBONrf4W+RffSoGpvx3JXISPcVk545obSH7jgxwYtPfOhL55qdSYQcRAI5UyJyRA4kEikCi4hD2ECIiOVZDmEzS6IiJqzpTRw18Shq2XKvE8b5/63i8i8BZic6VVBQ4IN3bupGPX3qJCxdW11YsfCsfsT4aOul881UDT+LKw0iiaJIA5DWnJwg4UliJf7m9WrE8cNVyPj4T0gjciZFpMc6rEI0JkSRwBjxCBUjxHOiyCOUbq0QcI/9duSVMkNHxrwyUP+7XIY/BcwOljb/py3DycgRY7U5RmeMcJYFobv40pnNmgZN9pQGUP+uD5iDNSsrkIk70h1/v6I+dfFWqJLA/thBpBEmkYgwwgRGIsOK2Ih5BuFsxkWTxU6bdMw5avJ0ENXveo7/V/3/W8BA/JmQydPUIXy148FTLWgw1+tVSiOixu0U2naM0ev1eaU1UcmBljhC9hnmqEQIKRBCgWaEgpijsa2JWZP76G7fo7ESIZ4gECkSSCR4EYPEBhuzCIFxmmP0cnzCz1v0s1PfQWsRQtYPXce9FTAAq9BqLSs2rr/N4fdbNRkX7W1mzeqD+m5fLwSR9a4iE3LgZJtBmif4eB4mhGoUzpow2mnWos9UYFe6vvITeDNCJMcipKOQSAgi5pAoFgqcBaM8S70qKdTOg+MdAgMvfsigvREwAOvlzUvdVZ83G+JQaAmwjBx8zRSzrr8bxhCFKPXrLSDJx5HPE/7WMQWGpszimeOJ+UsbAGiEEqHicn6I12qRw7VHCOtEhGkS/D8RsSxwnGBERAYzftgeduGqGZ4YgzP+wVyACWy0fwEMiFewYfU0asg3Q2gRmy0XDi/Qf9pmy7uKNPwFsCTrUiIuzBk4TYcQqlDw+H4YGdFpuO7aA2fBQYVze3cTlawVa3fsR5SFQ8jRHiED4IycwDNEvtnNMYNfsXKrvkfv5eDHva+GCYBkyMgoL06fsMjyLD3X/fjpQTbAJCsQTO6CoQMWU+s3N8G1KmUKR09+5+juff5db8M/Ae1NUkCKU6oQQlUYhDyMS2ZNVI2bVVeFRFTUuz1iqtcV1adOEJrjFxBGAsLOBOIJEpFgThaIAk+gXGv1CneFmbNu0O26HcMIPVMi9AJ8OftLimGCC/POVMAbXCBlUXa2n3jo587kjh8bEPGXa/EIE+Shn9Zr23WdCSEKmkHoE2PsvnBq9MgRiqfpBnbGhJ90MxfM+L+S9f8BYHKfDkBzQgj5GZIe1Rd7dJyq/T3RSfTzxoWRA0Ws1QgOO3aRxOXbiIQoig5iLwJCZiQIRoLgERKZYE+R69LlLlGvyW2yVp3L2M8vU41QjgUhRCJUTCOUjRDKwhhb38Xmhfhrfn6+NxW7bySxa2db4uyZIMICMR/M8DWD4vDpc1FqZ+9U26KLRLGCpXXTNU4nztcjBMFq/mlrtEO3PnPfxcRK9vkPgJKLR8kZB4fcy4KQr3VN9AJV5Nj6SoyxqUNL0dJ7UKpoLXDVrFqhU/12F9kyOUoCIY2IREaw+XHATlZMikhLiFxZD55WOrMiKXC8UmPhmjU7rR4z4XuVzgkMllJxEexrJ/IPxw7COzZ9Sh460khp5P1ohAhbmgIRVuPsMSedpi3qgjFmXi+4YNuWOHWf/s2EQK/L5mMnJ5YJqXThXYL1H+istxkfEpe9TuMghIDb1KDbivKzfPFXXeaqjlwIoAiEDGNHiNzA4clUYeE2avncKGp7rBNtD2liNYWQBiPEcAiZMEKiAP9e5+ggMJ3f6csE3c+xEQqEHv0noEkRnwyEVLojR3pyh39qQh49XEWVlldZQVCkKMA+IBCDhOdM3y7x7JT5UWWCgw0lrXGcO3XsRerQId7x1oMw2JDvAqy/CJKca940jZKWovTZFuKShb3gXgeEkIsVoU+KDx/orBz4VR/tSyMCYIpill5m+0fuogkmT7Vu3ff80rkaIikHQ3jF1hFkERwQEgkFwhA7IQiECjhk8nDk2AfPe6r0ujvAk2qEQGKa7fqOLkCIcno1DymXZ9N9KDERGXJe9uYTbvsTV867o1On69EvC53UiPQXRJ7EmESCyAusisxlIjrdEafOW6QPDD79tmwE6DDyXVmAMoNGbunJCf/v8ltvMzbe1ldJK9Lj1RdcgIXHvpb5UwYqv1vYWGUlEI8Rts6fzLMT5qyhEUrHmZnF/Oa1M+gzJ53xlRsQmcQ0RE9sghIhrEZINCPR2qY5y9Ste42wmJSEd0ASrlfrkqVuwyfskD7VdVcuYMrZ65GIhByhmCniTUYjbci28LmFJmzCyUoEe0KAgIzNo4d/PCIsrK/6Lt936Fl6+JhVam/vtD9jmD8NTf1ZB//u9xLRijcRWgKsJHD/Dix5P2/qU7oXdBq84HLjEapkLczxYr+bPla9Ym0QxRAEA5mcvt2escvWRiu1TsUcicxEcXEZ4eSh+ujCudrC7d8DqCs3VIpiW3JIxIQgioItlSfymOB4UTRZy6hTlGaOUpjZlyLCSQQh3EUCSkEIQRSoEL3KoBtERORyBGIJQSi2+LvkiC3CsnCHjoe1bTsv+ztZhncGWAkxKBdfJQn+Ni57GyeWFI1Sf6+zCPJsgB0w+A0sSU8rQj5sZqaa+H5JV2LD+vbcCwMlgo/t78azjRpm0nOWrqbLBdwjEUkxiCdML7P8yMR7/mT6MxchM02vzCpwFzIztUTOSwJnpjHikzROIMRchMR0xPD3EYHuYIUiU1ASBk7nZNSRegvS6SzGepUX4krVC/maNW861P/sOBgSb8pu/BmDvBPA3sJZ4OzCeKBdbTloKU0jz2fKvpPP/W0cKJ+/1J/8OxD3cIFvBd+DQQLz0CKEyjEIubPXrvrjg3vL47i4QOvju+VwzPqd+r4Dt6FXPhnc74YQcgSwBYQCLAiVEQREC4TgRiJUJCKiSGMqzhPTMwo4gTWSSk2hSBDFopY2KTROBqRWF9u5DOpT/nGJQ6kC9gauggmCPgcC4QUHfhxdRutYOLhlx2h7pEKDXilvUBYApJT2LwmsXD9JiwaAJOcW3uGzLTUj2Q/2mySzH9oAAAAYjANzAuOE4hBytweXrRRCYHhl2sUZ3AP9wTzd8y/+Wo1r9MUaBwobCWelVSBolTUoyKTcvGOGKiT0LvhqdkME/DXbekrbl30XgMmJYq/gQML9tKddQweELWvaNOzMr1NWTrTLeKApyHiYB0TjJR8HCAqE0qNXBJS4p+QOtXHO46wsLzeFIs/JyQnAB0DgktrCZzYxLakmTVHqT7z9b4LLJeNy6APmDNynTs7MrPPkZbp/i2q1ILoP38OcoA9XiKqYVi+uh/ftDqKMZg9Bq2NFo0Fgxs087Ni1+zGE0DP7ZnhlIb6DXFypASbLLEtiCAgAJq5t4gaToXetCYMisYJjb83fuVitUFxCCL0EZ9cOChAb2sPONy2L3Tn5aMKVeiemLv/avmuhG+gbuAjSLXAxDMO4lYvsvmVaz/67h3zR7kc714AYAiCA2ACOR9/ls2bSCpLYMGxqpP17qR/YDDAuvBxHb475/venD6qfn/t9I/QqwgHzB/0HGwrGDeJfcSbESxD9KkcA4vOBffNJUuKDAAwIGvgiJ8dh64VjXQQkMqTA0c8KC30KivI97r1MLZNTlKv7unGbqxV9/J9nFBSJTkoHi7teW6SilWZHB2eLi1pbQCGs7bV65thLSYmBw5t1Puqsc+QLTMWiwHGiwAsqDvEiJ/CUgDFtMOY7nn2cGFTO1Su9a+2mFzEmTJgQrUhUsu5lnPgyGk0mxwj0lP3rB3/iGVC0ut+YaEEUuTyTQW9lilUYusSI1SjVWdUCyytHbl4y6cyDWxVvLdrSFSE6R2bAwEYC0GCTQ3GJ+Grv2LgPwAZJAACDbwYbxSauS0NvyZV5qXCYjLtgt2qyDfnVvpj5zZwnL9PLcjxPOem0YrCnfwbDWNQGlmGSHt7xFhRKWqF3NXPGPMwXGTQIYxIrVGaRphksItrX28fi5ORS9ODRDT82v0hJUJQFauBsso5AAtRXAQGVHu6mKgEVH2S+SPVOT01yFjRaApmNAhZ4TLBIFBQiJ5oY2j+0ShEmFeyzzJdahU6HLWYDjziOQzxvRqKoQxRprVa+Uo6DQqt9lJ3u/eknlRNr+gWnQgMVrcaQISUhqKUgCGdSl+2qcypS0LRgYI242GgRVUqFoMCkqXHVGvFeetcEWRagVAthSxsw4DCwqICwbsWMuYLBbHbRqxwIjZK+PuunDQNn/7y+/dKvxx7t/mnYCTVN6DPzC6gzj2+Wf/rieWCBsZjmBV7ASCCuPb3/Sb6xkPRydi+oGhCcw7GclaYoXhRFjhN55KDWIJEV6EvJ93wycrLLODs55yyKGLo/xKOcITH9saqYMTklv8xy0Kp0FgWlUO69dKxhntlAzOja/7LJxBDFFtZIIJGjFYpChrE6XX9yN+T3lIeBhYzZVU2Q1kepSWqVSkkQpAKZWFakKcTRogKLtMAyrFUlWESKpynOQ6dNCwkIyuMsVrHQyuiX9Ina3Dy05lmEEDjBYHT8Y8vwXXGYZKX5IoSe25U4yAwIXNZACN3edPrAN6O2rWyXsnTP4jJl3EBJw28gUqQoOFhjLIvYKi1mjlh7NvFG4OlJqyK/qFH3sN1SA7EDbaXKK2LDyYPjhy4e/c1XHfsc/mHYjBEIobJ23VhgXyjoUpfRP6yccfXJPd8L363rZ7/fFuGxizOpP/2YzYtnxBzY3nh8xOCtC3pGbjSbzU55ZjPS0LSNu3UqVXGByVSh6ZzBE0mSNF34btMYR1oNjrLkNoCzDBcUANmMp9IE7R9zWAljA4gAC4OJSuazNIZm9anY/iM3L45Iidk3zcfD46hs50gBXMmq9G67YMLmuIQLIbcXbOsc6l/ucgnLTzLVqV2/nRzWa/bQ8d/2HPFzzNcjp9vNccnykwwVNH3nuoVxCVcqXFmwpafMgoT5gs6BjWNzrodtWrhgfdzBz+4v39O3vJffI8mHklmfcI9v2/mjNuQVFwm/zd00BCH01A4+zAvWLcUU4b1Uuaw0AYOJwkvauRLx/exOKLPvYny3MTtW9L29aPs0J53udzuhJJEBc4EdDxH3ct2WT1229+LJWrcW7+xbLSAICPdYZgBIegEfv/nbkNZT+s2a9FXUD/N6RoJ/B24CcKE0D+jXZdHh7SNjf/u16oV5m3rYxwWrVAIW3sGgoL/dtmzJxrh99R4v+6W/t6vrHZnTLfl30G/54evnzruS/MTl+vwtfRBCYJyAZfo6hixLhL6XHAbgSNwF7zaOSc7IqJ6Um16+0FDkoCRo9DDzmee11AdBLSvVve+g1WSQJG3W6rSFjrRKcFBqkF6jLnZ38SiiEfKK3DA/cs3PP362dVL0oq+afLnLxgks8kK0zdcBYoMl5nzpwa0un47tNWlSxPB9cyMidyOEoIgUxBKIJCCyzTmOjt059sD186EXZq0daf8NLDu7xWfbaABYzpiNMYtiju1olRizd3gF/8Cr9rbwm+TbwX0+zWcP22RkWdOlORsn21WAi10Ug9iW+n2V2ipFa7G0OEwKtEJ/AJhXQurDstVG91mI87IDRK2Ch5AprVap1GX0bFFmthYJfDEiCUwIlCBQBI0UNEHSlOCqczZ+Glw5Kd9crH+Smebu4uBsbhhUOVkgCCQKvNnMWCmTxUIWWs0KnmPoYpbRZBdmq/1cfAqCPXwKjRYDxfCYJwnIPpoFB40jX++TKikX7l2r/Tj7hWJ218HHgty904N8fO9RiALOAABAdwJ3ePdfMWfolvj99Sf3HLpjVucBv1AUxRrMZp4gBC1CFKlVKlOevHwR0m7xuCkWjuW3DJywz9fJtZAVBCutorICnD1f0jQNPplUalCq/lhpAyZFx2Hxqp+vnulyI+lB+aTsdE8TY3VQUQpCpVCqzFYzwXOiQUFSmFbRooNKQ6pIJadSK1mLxcrtunyqWqHB4Brs6VUkYkz5OLjmigQ25hoLFGarFSloJatQKHgecSg7O8dHo1VxVobhk56lepG8QPK2Ig5RwByPsNVMoiKj6FIhxOrk5sUUFxcV1/SvmKnXOGfRCiQqFRRtsphEhUKpunrvTvCLwnyHsl5uL5OyctyclKpcD+cy2QLDkxwSaJIkRRpjS4ahUEVRpEZDU9zznGy10WrFSoo2G17muEz6esjeuT0jVyKEcmVx01Lzx0oTMLlIlAd2bbrBrt/gHUI8INKS7KID7oMX7EQQHyCemIWHflg2ceOSzn1b9YjfMnwq1EICJ4Byhz6gHYg69dl7N9p0XjZpDBbFgu96R+1uVrHaixc5ORxPIJRblE/mFhc6cwyn33s5vunvqQ/9Tk1eMaZB+crXEjOelU3NSPe/+/xxhRf5uf6ZRXluGpWKyMzP1d1NeeRqsDCCQGKVIHKCwAsUJ/C0lWURTRAsFpDF28U131mnYY0MT9O0wkhTpDmnIB+Nbtvj3KiwnptlUY/3ViRKhJdieSASpOApiHEAkZu0Y/XcDvW/uFEvqOLPb4jSA2jQj/J60sN+n04bOKl2uUr34qetiFQoFDa/RpZZhsiDc1pWRr3Pvxs+Ld9YZDk9de2SGoHlwZgBkx50mbQB3H6+HN+7S8z0r+4s/GFo5bLBV+yAQ39QLgebyBYSm/vTpmFT965t/dOohUsaVKiSajSb3MyCQFisVqWIBBELyOji6MTO/3lL5y3H91Qb0qnPsXX9xi3hOM6boiiYP2xEGB8Mn/dah0lBX1u8RlYqJk3axnWVR/U6urDPiF++rFF/jcwFkMx6yWDRXbif0KvDknGTi3mLGPvtomUta9SLtYMgGRzgoDsfvnahc59Vs/s66lR556etW+Tn4Q1RBkgeAsEkzlYcun6xa/uFowdfn781qmZQyEV7YBnaSJF1aOu4+czxXnP3r+tyf8lPXykUCig2hXAT/Ab+HKwFrEG33eeO9ew5N2rg1CGTts/p1P8Hez/QF7gIUhxTkhrvrUgE7oLFSY6olF6R0if09l+PjKziF/y0WnDIL3axAe1BbIKIA8DgbyLm0O5Rk/es6aFSqiwNgysnzOk2eK+ZsxgLCvL1KdnZ+oQXKWWTX6b63c9MC1aQSpVCSRo+C6zyyKOMRyZFkwa9UlckIpbRaTS0ltaxuy/F1Yq7c7VOzwYt40e06fI7lGAazGaGEEUh0N2zwN2xTJ5CodAuPrKz26qjuxtfXbhtgodOD1wNKRO56wHWqfe5e9c7NxkX0W/RkGlbx4X3BsDAn4OXpA6keOJ7LRIlP8y5GCFLYV5WUDFj8TWZrC4kQRTcfPKg8sKjOzohLKChzcP3t63e+L6VYxwpiqKz87LdLifd93z4Is0jOSfL5WlGapBKpbRgimJysl86FvOM2VXvYuYsFpT+8L4nokWMVGrs7hfE+OldCngkmh+kp/hYDEU0JkleFKDuSRSRSIqItRLuXl7GQG//vEfPUssWW81Ip1AVMQJPYIEw+zg7Z2m1ao7nSWWRqdAVU3Sxt86R8XDxLHB1dEj107vme+jdiv3KeJjcnHQGH2d3fuXxn5vM3bX8szn9xx2e2vHro0arhTebzJSDxuGhUqkElwLEopQuKjVfrLSNDgAMkoEFt5Of1B21dVl3JUW7qEiKZjiuOC3npWeRaPFlGYbMKMzjPbVOL1mGLcNjrGU5ljYzZqGcj2+Bo9bRZDabXK0CQ3E8Klg3YOy2+uWrXGA45KKk6YKd5461Ts565qui1OLpxGuV84pznUwMS7Icx/m6uuZzgigwHEOQFGk7Xo04gWA4XqkiSSbLbC7DWxglSRPZEKUhSdFQbLU6cgyv4hErBrj4GB20ajEx+bGfJTeXFDHPY4bnkaveiEkli8wWk2BlNM5eXnSQV7m8gqJ8qtBUbLZYrYyh0ODU8/PWF3aO+g58MxCNUsjtvQYMRAKINTYjN9eXomnWQaFgVSrVS6vV6ldtTMTeCuWCC7d8My0yJSPNz2CyOPKiSKoopdnHw73YX+/+EMTqxlMHhwzeMP/rIG+/p6cnLpvm7+Fzxm4gQE4KxCgYC2LstfMdOsdM+NZT75KyasD4LeG1Gv+aX1ysZgSrFnOY5GgOezu4v4g5vGvYmA0LekV16LtrQqevT2QX5akEHhVhgdDxWMAujg7Gh8+S/UZvX/tVWn66vmbZ4MzqZUOf0QTJYkyQey+drEoTKuu0Lv1Ohvj65q47urfdwRvnAz2d3QoaVaj21M/NK8dJqy2s6hP85LOK1UDfysNT7yVg8miHFNAF+S2FnGy/Vx3b61Cgu5f54Pglfe05JCmOJ6/J0J64ebn3l0vGjfP39EmKn7RsZoCrJ0QdwOAAwOAdAHM8m3iz4xfjvho1rtewHQsiIqECCcSRXHLYDJr9F05Hdp4zZND2qSujezVuvd/eD/hK0J8t6XgzKbF+k+nfzK4YGJh6dsrqKSqVCiImtvKG1OzMSoIo8oHuXrZA75rju3tELp/es0uLztf2jp6/xL6JwPWASAwYJrY44vsc6ZACshKxJAtJSpfbfLDQMT13uzuVKTozbXV4iXifvFbD7WzCjT7NF4wYFezl9+TUpFWTfVxdwVwHoIB7JUK4XHpwo/2no776btnoWUuiWnQBy1OqEZGDptr32+mhXeeOiDwwfd3QDvU+g2d/SJlxaQO4/3jmSFi/OUMnzB4xY+fUDgOhRADGkgwJyfKFDaZac2jP4MjlEyP6dx54YtOwKUvt/iNsuowSBypKjbtsIS55ruU/+btE8rJkf/LknfrpixfV6k7us6y8X0DmpTmbOsqCuRIXAmiwaPcTty4PbLt4bFSQl/eT05NWTfZ2cb9uf8AKcK9kdTpfe3Sne51ve0xaOnzqylHteq63726pKAeWBH/rd1863SPiu5Hfxs37/psW1RqCeJUsWUkKaC89eVC74aj2KxcNm7J1XJuvgWukTSe5HdLmU6w/fmDAkIUj+o3rOy520dffgmMPwIORIZn1Utv3FjBpUfKNIE0aftPG3bjSqfXcyGl1qta6e2XG9xA1l2o+5EDDPa5Hrl4Y0H7Z+LGhXgGPT05bOc7TyfWGnRjQViKk9mbao3Y1h3eds3jQ+O1jw3utk1lnkogF/0mMv3ujabNREfOOLf5hWFj1+lBPIrkgUpEPcffpg+pVh4TtnD582p6ZnQZMtXOYdBBBGtcWBIi7fTE8bOiX01ZM37hpROsuq+wiURLv0ka1rf99zYfJAZMzqxS9UP0Qf6R/v8UTxrf9osXvh8bFdJNVGJXcwfoDl3/9ulP0hAn+Xj6PLs5YN87XxQPKyABgqbztlY/HoCDcu97ub1p1O7NywBjY6eA0Qzt5ekVjNps1QzcsihrapvvhBsEVIL8GIhraSOcJiCtP7zWsP6bPsv3TVq/tWKs+HLaXTpxK85OAIIusVv/J21cPiAzr9EtFn7KQhoE2ID5Lrv29BEwSL/KFSYSVEprozN0brT//pse6jm3bX9w/dkmvtxSSwoJVd1IfNa46rNOymtXq3Lw+f8sw+24HMOQcBn8rt587+qWTzpltW7PB8RKFqlJKRKq2gs+g46QgtZTjsuXFClCB+kVKbv3QskH37SkTSVpIY0qSAHQbvKBf6A8u6RCELQQnK5F7fwAr8dQ2KcUiTVgiltyYEAf8MH+pRq0xruz+LYgcqY1cJIKoslmUN1LuV/Zz809x02qlsrXXekFWRConpjzoLAelJOElLpDrTinuKC9mlUsNaR0SyPJojnxe8na2WOp7IxLfAJjN8srIyAhkWdYKuSSr1UpQFEVZeN5Vr9EQxqIi10xTPuuhc0lkWZJUKAQTy7IUQcCZa4xZkiRJllVTFOUQ6OmZYTVymkxjnlaNcQFDEFalUsnDxagZjiwmoW+SeHWR8MCrkqXegiC8NnxsA8Bjr/7/hQVB4JVKJdQ3KkmSpAVB4CiKgkHgAWQG6NjJCcoSbcaLBDB8lrIT8J0UhpJ06x+OHL3PgFFpaWmhtWvXXms0GrU6na4IjjNhElsIROkYzqrVk6psKAU0cBZMkwpeQDwSeYGwUZ0kMUEQtJVjBCT4ydf/AAANgUlEQVSKKsxjkaBJUaGkTaRIwMEonhQxQ9AUjyB0DpEnXsBWnqNpBUXQBFRdv87wIpHAAhZEkaZpxPO87Sw3xvAEHdvjl6QXJQiChWVZW909nJFTKBQYNgVBEPCy7QPIhQmCIJIk+fpv+EEURUH6DqL1mZmZZMuWLe9s2bJlzntXql3CpJd2HXXmzJkGHMdxCgU86wvTNELFHKbcMSZzSFJQYo6zIJqGNC4Pmp9lWQSLBcyAIwiCsDAMA+e7WEEQGEJBKChEqQXbqWSC5zDmSDvnsCxr4xiSJAEAW1SdJEmjANksjB2hO1EUgVsswPFAYcACkHs1FEEAh7MCqxERaUEip0eYMiKO03Mcl8uyrBPDMFBIA+OQHMfRAC6MC2wpCIJeEAToywpzLygoEIKCgrIiIiJAn0KU/v2pSywhEuWiRj5Jec38v4isN/h+JU38kp9LWmF/EHGyfJmkz+RzkUfdS7ofks6D/iQ9JtfH8vbSmPAur+WXlwXYxGdpikP5BN5Atz//qgRgbyIkTBrqJZTJycleOTk5SgcHh2wfHx+Dg4MDmMzyBKd8PlA5JemBNxkIJceSt7FZjjCu2WxWqNVqKeclJRQl0OAeyXBQ3LhxI+T69esVQAQ2bNgwoWLFihDTLLnBJKBsR5aSkpLK5Obmejk7O7PBwcFwyh/CYpKbYDtI8d4A9m9OV762okwmk1vMiphO36/5vsfzZ8+8RHutoqurq6FHj277xs+YuMnP1Q/yTa937MmTJ5tOmTwx0lGvN+cWFGI1qUAKtRJ5eXllNWrU6Hbkl5HbUVmbkpf7YxJg5Llz5+qvXL2yQ/yvZz7Pz87R6RwccNOmTS8NHTp0T5s2beDAPfhKEhA2I2ns2LFToqOju8oSqsLMmTNXz5gxAxxxyVK0WaMGg8Fp1apVHdesWdPl+fPnQfaBWX9///Thw4f/PGHChA0Sh5Y2WP+Iw94C2GuRk5qaWr5Vq1YrHz58WEGtVjPh4eHxQUFBKVlZWV4HDx6sl5WVVcbFxSX/6NGjPevWrQtpddu1ZcuWDv3791+GMTK7urplsyyrKioq0oCeAM7x8PAoOnz4cIfatWtL1bYScPS33347ecWKFVAniCpWDLlXqVLl9LS0Z55Xr14NxRirO3XqdGbfvn2D7NwLXMJt2bKlU//+/Rc3bNjw5tatW7/Jzs7Wde/efXFaWlq5ffv2jercuTPEHYHjrUlJSRXatGmz5OHDhyEODg6FnTt3POvl5ZOZlpZW5tixY9Xz8vJ8Ro8e/X10dPSK0jbn5SLkz2XfG1q8ATB5K0WNGjWO3rp1K7RVq1Zn9u/fP0qj0UgnQWwlA/369Vvxww8/dK1Tp875q1evQpjK5mAfOHCgdadOnVaNGvXt6qVLl0E8z+aTPX361GnlypWjly9f3p2mafzo0aP6ZcuWhfS9becPGzZs4bp16yJq1Khxafv27aNCQ0PTpQmlpKQ4DBo0aOOpU6catGzZ8lJcXByMB2LTGhERsWbXrl2tzp8/36JRo0ZQ5COeOXOmbnx8fOXBgwfv8PX1hfEZk8nkWqlSpV2pqakBgwcP3rJu3br5MlPfFs1p167dIjBuYmNjIR9Wqv7XuwLMRrwlS5Z8PX78+O8aNWp07dy5c11kokbuRKNRo0YtCA8PP9m0aVPYxaDrTAcOHGjWqVOnTdOnT100a9Yc2KmS8WDjiAkTJkxZvHjxoO7dux/btWsXnPVCR44cady2bdsfQ0JCEs+fP9/Fzc1N0iNy4wA1a9bsx/j4+Kbz58+fP3HiRBB3qsGDBy/duHHj59u3b58WERGxVwaCZITYDI9hw4bNX7duXfdBgwZtW79+/Uy7WJWcdkla4cTExJDQ0NDEdyEOS1skSkocNW7ceO/Fixfr/PLLLwPbt29/qgSDSjoBOE0qb5OsLTY2NjYsPDx8zbRp0+bNnj0biAoXtAMLjEhJSQmuXLnyCZqmudTU1NqOjo5FPXv2XLl79+6WO3fuHNmzZ084OCHV9cuHpk+cOFEvLCxsW/Xq1e/fuHGjHXBnXFzcF2FhYQsxxprZs2cvmTp1KtRngI6U5knk5eUp/f39461Wq8P169cbV61a9TVny0Jl0lg2Ef3BAJaXl6f55JNPrkK84vbt2/W8vLykNLk8lCOPM4LvBPE42/nkQ4cOVQ8PD/9p4sTxK+bNWwC18iXDTUTr1q13xMXF1U1MvNmiQoVqycHBwYeysrL8EhISapUtWxbGk4eUpCCwLeVSpUqVw3fv3v3kwYMHjUNCQmwHxqOjo3uPGzdujCiKejBu5s2bt6Rv374HpbHj4+NrNWvWbEOTJp/eOHPmgk1HlrzeFUD/Ms5/pMDsN73J8Hj8+HH5kJCQuEqVKj25c+dOC1n/Nm6KiopasHLlyl4BAQEvNBpNIcdxmqpVKz3ct+/AcFvKPza2bnh4+LZx48asWbRoyYIS87OBHhERsW7Xrl0tr1271qJWrVpJbm5up/V6PX7y5EkTmUgruTTbJmnVqtWWEydONLx9+3bbqlWrPpHa379/32/BggXDtm7dCnk6XceOHWNB9wJoR48e/axt27YrwsPb7Ttw4OCU1/qklM9+/RUs5E7nX2n/hzZvAIxIS0vzr1ChwjEPD4+c5OTk5vYcliR+AbBlGzZsaF+pUqUkk8lE3r9/v1Lt2jUf//779WYgioBzwsLCdo4cGbUmJmY5pEvklw2w8PDwHbGxsQ0SEhJaVKlS5Un58uUPJycn+zx69Kh5YGCg3E14Pa4kuipXrnwwMTGxQlJSUuOyZcuC3yQvTUM3b96s2aFDh+VpaWlB0dHRc0aPHr3h9OnT9Zo3b77+888/vxQfHz/wXRkUfwWA0gJMIoyNi6pVq3YwISGh8tmzZ/t99tln8LxFeSIT2tqKdPbu3duyW7duG3v3jojdtm1HFBD18OHD9du3b7995MiodUuXLpsnWwTMlcjPz9dUq1btyLNnz/weP378RXBwcMqAAQO+27x5c4cVK1bMHzFiBDxjQ1rXHzIFx48fr9WmTZvdDRs2vH3hwgXJMpWcd8m3Q4cPH27Trl271W3atDlz5MiRgQaDwdHb2zuO4zjh1q1b4SEhIXCY/g96Sv7Ii3cpHksTMKCtzbIaO3bspOjo6EE9evSI27Vr1zey4zfws0REKiIiYtWuXbvaLl++fF5UVBQoe+bEiRPVW7VqtX/kyJGbYmJiwBqTJyLF6OjofuPGjZvVvHnzCydOnIiADq9duxZQp06d4zRNC3fu3PkiJCQE6iqkTWR7z8nJ0TRo0GDPkydPquzYsWNiRETEnosXz9Ru3PiL7YsXL54zZswYANp2gXgMDQ0917hx4xvnzp3rDgbPoEGDZmzcuLHzgAED9m/cuNFmJUKcsKSU2b17d+smTZr86u3t/U4etPaPALNR3/7fSckJlJ2drQkICLhnNpt1w4cP37h69eoZJQ7vKSMjI6PXrFnTs0qVKg8TEhIaS8CcOnWqcosWLX4ZOXLklpiYmO9kRge9dOnSLmPGjJkNAPz2228dGjRoAJleG/fOnTt3+LRp00ZqNJriFStWTO/fv/9JKfR17NixRkOHDp2VlpYWOHLkyO9jYmLgeZBEbGxs8/Dw8E1+fn7P796929rR0RGKP/HUqVOHzJ07d8qoUaOWLF269HsA7Pnz50TVqlV/LSgocB4yZMjWtWvXgriW//8v5OTJk4cvWLCgR0ZGRgtPT8938kzhfwzYG0CzYXf27NmmrVu33gyp+YAAv6xu3brt9/HxS3v+PM17796fmqWmPq8UEOCXcuHCbx18fX2BI2ycFBcX93lYWNiPHh6uz8qVC8ozm61scXGxLjk5OZDneaxUKi179uwZHx4efqSESU2tXr265zfffAOGAk1RlNnT07OwsLDQ1WAwgI/HzJw5c+2MGTOgskpatzBmzKhFS5cu6+rsrDe0ahV2JTHxnkdCwt0qISGf3H7w4BGUMUgH/4SEhIQabdq0WZqenu7u6ur6olevXscCAwNfpqenu+3Zsyfs2bNn7qGhobfv3r3b712JxVIBrARor53VlJQUv1mzpk3cuXNPGMOw0tlf0sFBWzh06NB9UVEj5/n6+oIZbnOKgZDnzp2r2rdvnzUUReXm5ub5KJUKpFJpnnt5eeU3bdr0TlRU1I8eHh7gB8nNfSl+iZKSkny3b9/eGfp58SJd7+TkbGjcuPGTvn37bq1YsSLUysv1m+3gxo8/bu46f/7Cfg8fPqrg6lomp0uXLkemT58Z4+XlBXWLtoMMskC3csqUKcPXrFnzZUFBATyHyuYu6HS69BEjRhydN2/eOvkTRP+KIfF32pQaYNKgbwpZZWRkqNLT08sZjUY3jUZzv06dOlCgCb6XPFLwB51TMnP8hs9vWufb1iOP0Je87w/REPuPb3V8pedLwtwvXbpUyWq1Kt3d3ZNCQ0MLSjv39XcW+HdA/5e2f/MJpH95LEnMvOmxdW8b86+KJun+v9r+L0+6lBuWOofJ51eSiP+O4KW8rv/a7t4pYG8D733fxe8z2v9ngL3PRPiQ5vYRsA8JrdI4DPGBrfeDn+5HDvvAIPwI2EfAPjAKfGDT/chhHwH7wCjwgU33/wHUDIqGN/wocAAAAABJRU5ErkJggg==", gl = { class: "login full-box" }, Il = { class: "login-form" }, ll = { class: "login-title" }, Cl = { class: "logo" }, Al = ["src"], al = /* @__PURE__ */ q({
  __name: "hdlLogin",
  setup(e) {
    const a = Yg(), l = Ie({
      user: "",
      //登录账号
      pass: ""
      //登录密码
    }), I = W(!1), A = he("formRef"), g = W(""), d = Ie({
      // 表单校验规则
      user: [{
        required: !0,
        message: "请输入登录账号",
        trigger: "blur"
      }],
      pass: [{
        required: !0,
        message: "请输入登录密码",
        trigger: "blur"
      }]
    }), c = new rI();
    localStorage.clear(), (async () => {
      const b = await ie({
        url: "getPublicKey"
      });
      g.value = b.resData;
    })();
    const G = async () => {
      var b;
      if (!I.value)
        try {
          await ((b = A.value) == null ? void 0 : b.validate()), c.setPublicKey(g.value), I.value = !0;
          const s = await ie({
            url: "login",
            method: "post",
            data: {
              encryptFlag: !0,
              loginType: "",
              deviceId: ce(8),
              username: c.encrypt(l.user),
              password: c.encrypt(l.pass),
              validCode: ""
            },
            aloneFunc: () => {
              I.value = !1;
            }
          });
          I.value = !1, localStorage.setItem(Ce.HDL_TOKEN.value, s.resData.access_token), localStorage.setItem(Ce.HDL_USER_NAME.value, l.user), localStorage.setItem(Ce.HDL_PWD.value, l.pass), a.push(He.loginSuccessRoute.value);
        } catch {
          console.warn("请完善表单信息");
        }
    }, K = (b) => {
      b.key === "Enter" && G();
    };
    return window.addEventListener("keydown", K), Hg(() => {
      window.removeEventListener("keydown", K);
    }), (b, s) => {
      const R = S("el-icon"), u = S("el-input"), o = S("el-form-item"), H = S("el-button"), h = S("el-form");
      return y(), N("div", gl, [
        x("div", Il, [
          x("div", ll, [
            x("div", Cl, [
              x("img", {
                src: v(el),
                class: "logo-img"
              }, null, 8, Al),
              s[2] || (s[2] = x("span", { class: "logo-title" }, "智慧监控平台", -1))
            ]),
            s[3] || (s[3] = x("span", { class: "login-subtitle" }, " 致力于打造最好的智慧监控平台 ", -1))
          ]),
          t(h, {
            ref: "formRef",
            model: v(l),
            rules: v(d)
          }, {
            default: n(() => [
              t(o, { prop: "user" }, {
                default: n(() => [
                  t(u, {
                    modelValue: v(l).user,
                    "onUpdate:modelValue": s[0] || (s[0] = (i) => v(l).user = i),
                    placeholder: "请输入登录账号",
                    clearable: ""
                  }, {
                    prefix: n(() => [
                      t(R, null, {
                        default: n(() => [
                          t(v(dg))
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["modelValue"])
                ]),
                _: 1
              }),
              t(o, { prop: "pass" }, {
                default: n(() => [
                  t(u, {
                    modelValue: v(l).pass,
                    "onUpdate:modelValue": s[1] || (s[1] = (i) => v(l).pass = i),
                    "show-password": "",
                    type: "password",
                    placeholder: "请输入登录密码",
                    clearable: ""
                  }, {
                    prefix: n(() => [
                      t(R, null, {
                        default: n(() => [
                          t(v(AI))
                        ]),
                        _: 1
                      })
                    ]),
                    _: 1
                  }, 8, ["modelValue"])
                ]),
                _: 1
              }),
              t(H, {
                type: "primary",
                class: "full-width",
                onClick: G
              }, {
                default: n(() => s[4] || (s[4] = [
                  k("登录")
                ])),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["model", "rules"])
        ])
      ]);
    };
  }
}), ol = { class: "full-box hdlNoPage" }, tl = { class: "loading-main" }, nl = /* @__PURE__ */ q({
  __name: "hdlNoPage",
  setup(e) {
    return (a, l) => (y(), N("div", ol, [
      x("div", tl, [
        t(v(aI)),
        l[0] || (l[0] = x("span", { class: "loading-text" }, "正在加载", -1))
      ])
    ]));
  }
}), dl = { class: "listCom" }, sl = { class: "listHeader" }, ul = { class: "listContent" }, cl = ["innerHTML"], il = { class: "date" }, Bg = /* @__PURE__ */ q({
  __name: "listCom",
  props: {
    detailCode: {
      type: String,
      default: ""
    },
    currentCode: {
      type: String,
      default: ""
    },
    isNeedRefresh: {
      type: Boolean,
      default: !1
    }
  },
  emits: ["refreshCount"],
  setup(e, { emit: a }) {
    const l = e, I = a, A = W([]), g = async () => {
      const Z = await ie({
        url: "noticeList",
        method: "post",
        data: {
          types: [l.detailCode]
        }
      });
      A.value = Z.resData;
    }, d = (Z) => {
      Z.state !== "1" && (ie({
        url: "noticeRead",
        params: `/${Z.notifyId}`
      }), Ae.success("已设为已读"), g(), I("refreshCount"));
    }, c = () => {
      ie({
        url: "noticeReadAll",
        data: {
          type: l.detailCode
        }
      }), Ae.success("已全部设为已读"), g(), I("refreshCount");
    };
    return M(() => l.currentCode, () => {
      l.currentCode === l.detailCode && g();
    }, {
      immediate: !0
    }), M(() => l.isNeedRefresh, () => {
      l.isNeedRefresh && g();
    }, {
      immediate: !0
    }), (Z, G) => {
      const K = S("el-button"), b = S("el-scrollbar");
      return y(), N("div", dl, [
        x("div", null, [
          t(K, {
            type: "primary",
            round: "",
            onClick: c
          }, {
            default: n(() => G[0] || (G[0] = [
              k("全部已读")
            ])),
            _: 1
          })
        ]),
        t(b, { class: "listPanel" }, {
          default: n(() => [
            (y(!0), N(T, null, $(v(A), (s, R) => (y(), N("div", {
              class: "listBox",
              key: R
            }, [
              x("div", sl, [
                x("span", null, P(s.title), 1),
                t(K, {
                  type: "primary",
                  link: "",
                  onClick: (u) => d(s)
                }, {
                  default: n(() => [
                    k(P(s.state === "0" ? "设为已读" : "已读"), 1)
                  ]),
                  _: 2
                }, 1032, ["onClick"])
              ]),
              G[1] || (G[1] = x("div", { class: "hdl-line" }, null, -1)),
              x("div", ul, [
                x("div", {
                  innerHTML: s.content
                }, null, 8, cl),
                x("div", il, " 发布日期：" + P(s.publishTime), 1)
              ])
            ]))), 128))
          ]),
          _: 1
        })
      ]);
    };
  }
}), ml = { class: "full-box" }, bl = { class: "singleLine" }, rl = { class: "ellipsis" }, Zl = { class: "messageDatail" }, pl = { class: "messageDatail" }, yl = ["innerHTML"], Gl = { class: "messageDatail" }, tg = /* @__PURE__ */ q({
  __name: "tableCom",
  props: {
    detailCode: {
      type: String,
      default: ""
    },
    currentCode: {
      type: String,
      default: ""
    },
    isNeedRefresh: {
      type: Boolean,
      default: !1
    }
  },
  setup(e) {
    const a = e, l = W([{
      prop: "state",
      label: "状态",
      formatter: (u) => u.state === "0" ? Zg("span", { style: { color: "#f56c6c" } }, "未读") : Zg("span", { style: { color: "#E6A23C" } }, "已读"),
      width: 80
    }, {
      prop: "title",
      label: "标题",
      width: 250
    }, {
      prop: "content",
      label: "消息内容",
      slot: !0
    }, {
      prop: "createTime",
      label: "创建时间",
      width: 150
    }]), I = W(null), A = W(!1), { tableData: g, rowData: d, total: c, pageSize: Z, currentPage: G, getTableData: K } = DI(ie)({
      url: "noticeListPage",
      method: "post",
      data: {
        types: [a.detailCode]
      },
      immediate: !1
    }), b = (u) => {
      d.value = u;
    }, s = () => {
      K({ types: [a.detailCode] }, !0);
    }, R = (u) => {
      I.value = u, A.value = !0;
    };
    return M(() => a.currentCode, () => {
      a.currentCode === a.detailCode && s();
    }, {
      immediate: !0
    }), M(() => a.isNeedRefresh, () => {
      a.isNeedRefresh && s();
    }, {
      immediate: !0
    }), (u, o) => {
      const H = S("el-button"), h = S("el-table-column"), i = S("el-pagination"), V = S("hdl-table"), X = S("el-dialog");
      return y(), N("div", ml, [
        t(V, {
          data: v(g),
          columns: v(l),
          onRowClick: b
        }, {
          content: n(({ colData: L }) => [
            t(h, Kg(Sg(L)), {
              default: n(({ row: J }) => [
                x("div", bl, [
                  x("div", rl, P(J.content), 1),
                  t(H, {
                    type: "primary",
                    text: "",
                    onClick: (f) => R(J)
                  }, {
                    default: n(() => o[3] || (o[3] = [
                      k("查看消息")
                    ])),
                    _: 2
                  }, 1032, ["onClick"])
                ])
              ]),
              _: 2
            }, 1040)
          ]),
          pagination: n((L) => [
            t(i, ae(L, {
              "page-size": v(Z),
              "onUpdate:pageSize": o[0] || (o[0] = (J) => fe(Z) ? Z.value = J : null),
              "current-page": v(G),
              "onUpdate:currentPage": o[1] || (o[1] = (J) => fe(G) ? G.value = J : null),
              total: v(c)
            }), null, 16, ["page-size", "current-page", "total"])
          ]),
          _: 1
        }, 8, ["data", "columns"]),
        (y(), U(eI, { to: ".listComDialog" }, [
          t(X, ae({ "model-value": v(A) }, v(Ye).dialogAttr, {
            title: "消息详情",
            class: "small-dialog",
            onClosed: o[2] || (o[2] = (L) => A.value = !1)
          }), {
            default: n(() => [
              x("div", Zl, [
                o[4] || (o[4] = x("div", { class: "title" }, "消息标题：", -1)),
                x("div", null, P(v(I).title), 1)
              ]),
              x("div", pl, [
                o[5] || (o[5] = x("div", { class: "title" }, "消息内容：", -1)),
                x("div", {
                  innerHTML: v(I).content
                }, null, 8, yl)
              ]),
              x("div", Gl, [
                o[6] || (o[6] = x("div", { class: "title" }, "创建时间：", -1)),
                x("div", null, P(v(I).createTime), 1)
              ])
            ]),
            _: 1
          }, 16, ["model-value"])
        ]))
      ]);
    };
  }
}), Tg = (e, a) => {
  const l = e.__vccOpts || e;
  for (const [I, A] of a)
    l[I] = A;
  return l;
}, vl = {};
function Wl(e, a) {
  return y(), N("div", null, "chat");
}
const hl = /* @__PURE__ */ Tg(vl, [["render", Wl]]), Vl = { class: "noticeDialog" }, Bl = { class: "label" }, Hl = ["href"], Xl = { class: "label-text" }, Kl = /* @__PURE__ */ q({
  __name: "noticeDialog",
  props: {
    modelValue: {
      type: Boolean,
      default: !1
    },
    noticeType: {
      type: String,
      default: ""
    },
    noticeTypeList: {
      type: Array,
      default: () => []
    },
    isNeedRefresh: {
      type: Boolean,
      default: !1
    }
  },
  emits: ["update:model-value", "getData", "refreshCount"],
  setup(e, { emit: a }) {
    const l = e, I = a, A = W(""), g = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Map(), c = () => {
      l.modelValue && I("update:model-value", !l.modelValue);
    }, Z = async () => {
      var b;
      A.value = l.noticeType ? l.noticeType : (b = l.noticeTypeList[0]) == null ? void 0 : b.detailCode, l.noticeTypeList.forEach((s) => {
        switch (s.detailCode) {
          case "anno":
            g.set(s.detailCode, Bg), d.set(s.detailCode, "warning");
            break;
          case "wo":
            g.set(s.detailCode, tg), d.set(s.detailCode, "primary");
            break;
          case "task":
            g.set(s.detailCode, tg), d.set(s.detailCode, "success");
            break;
          case "alarm":
            g.set(s.detailCode, tg), d.set(s.detailCode, "success");
            break;
          case "im":
            g.set(s.detailCode, hl), d.set(s.detailCode, "danger");
            break;
          case "sys":
            g.set(s.detailCode, Bg), d.set(s.detailCode, "success");
            break;
        }
      });
    }, G = (b) => {
      A.value = b;
    }, K = () => {
      I("refreshCount");
    };
    return (b, s) => {
      const R = S("el-icon"), u = S("el-tag"), o = S("el-tab-pane"), H = S("el-tabs"), h = S("el-dialog");
      return y(), N(T, null, [
        t(h, ae({ "model-value": e.modelValue }, v(Ye).dialogAttr, {
          class: "large-dialog",
          title: "消息",
          "onUpdate:modelValue": c,
          onOpened: Z
        }), {
          default: n(() => [
            x("div", Vl, [
              t(H, {
                modelValue: v(A),
                "onUpdate:modelValue": s[0] || (s[0] = (i) => fe(A) ? A.value = i : null),
                "tab-position": "left",
                class: "notice-tabs",
                onTabChange: G
              }, {
                default: n(() => [
                  (y(!0), N(T, null, $(e.noticeTypeList, (i) => (y(), U(o, {
                    key: i.detailCode,
                    name: i.detailCode
                  }, {
                    label: n(() => [
                      x("div", Bl, [
                        t(R, null, {
                          default: n(() => [
                            (y(), N("svg", null, [
                              x("use", {
                                href: `#${i.icon}`
                              }, null, 8, Hl)
                            ]))
                          ]),
                          _: 2
                        }, 1024),
                        x("span", Xl, P(i.detailName), 1),
                        t(u, {
                          type: v(d).get(i.detailCode),
                          size: "small"
                        }, {
                          default: n(() => [
                            k(P(i.count), 1)
                          ]),
                          _: 2
                        }, 1032, ["type"]),
                        We(x("div", null, P(e.noticeTypeList), 513), [
                          [Rg, !1]
                        ])
                      ])
                    ]),
                    default: n(() => [
                      (y(), U(xe(v(g).get(i.detailCode)), {
                        "current-code": v(A),
                        "detail-code": i.detailCode,
                        "is-need-refresh": e.isNeedRefresh,
                        onRefreshCount: K
                      }, null, 40, ["current-code", "detail-code", "is-need-refresh"]))
                    ]),
                    _: 2
                  }, 1032, ["name"]))), 128))
                ]),
                _: 1
              }, 8, ["modelValue"])
            ])
          ]),
          _: 1
        }, 16, ["model-value"]),
        s[1] || (s[1] = x("div", { class: "listComDialog" }, null, -1))
      ], 64);
    };
  }
}), Sl = { class: "layout-header" }, Rl = { class: "header-left" }, wl = { class: "header-center" }, fl = { class: "header-right" }, Yl = { class: "layout-item" }, kl = { class: "fullScreen" }, Jl = { class: "notice" }, Nl = { class: "dropdown-item-icon" }, xl = ["href"], Ll = { class: "dropdown-item-txt" }, Fl = { class: "user" }, Ul = { class: "user-icon" }, zl = ["src"], jl = { class: "user-name" }, Dl = { class: "dropdown-item-icon" }, Ol = { class: "dropdown-item-icon" }, Tl = { class: "dropdown-item-icon" }, Ml = { class: "dropdown-item-icon" }, Pe = "wsNotify", Ee = "baseSocket", Ql = /* @__PURE__ */ q({
  __name: "hdlHeader",
  props: {
    showCollapse: {
      // 是否展示菜单（折叠图标）
      type: Boolean,
      default: !0
    },
    collapse: {
      // 是否将菜单折叠
      type: Boolean,
      default: !0
    },
    collapseWidth: {
      // 菜单折叠后的宽度
      type: Number,
      default: hg.collapseWidth.value
    },
    width: {
      // 菜单展开后的宽度
      type: Number,
      default: hg.width.value
    },
    avatar: {
      // 用户头像唯一标识
      type: String,
      required: !0
    },
    userName: {
      // 当前登录的用户名
      type: String,
      default: "默认用户"
    }
  },
  emits: ["getMenuStatus", "update:collapse"],
  setup(e, { emit: a }) {
    const { useInitWs: l, useWsMsg: I, useWsOpen: A, useWsSend: g, useCloseWs: d } = Mg(gg), c = e, Z = a, G = W(""), K = W(!1), b = W(!1), s = W(""), R = W([]), u = W([]), o = W(!1), H = W(!0), h = W(!1), i = async () => {
      G.value = await OI({
        uuid: c.avatar
      });
    };
    M(() => c.avatar, (r) => {
      r && i();
    });
    const V = () => {
      Z("update:collapse", !c.collapse), Xg(() => {
        Z("getMenuStatus", c[c.collapse ? "collapseWidth" : "width"]);
      });
    }, X = async () => {
      await ie({
        url: "logout",
        method: "delete"
      }), Ae.success("退出成功"), jg().emit("logout");
    }, L = async () => {
      const r = await ug("showNotice");
      H.value = !(r.length > 0 && r[0].detailCode === "false");
    }, J = async () => {
      R.value = await ug("notice_list");
    }, f = async () => {
      const r = await ie({
        url: "getNoticeUnreadCount"
      }), j = r.resData.itemList;
      K.value = r.resData.total > 0, u.value = R.value.map((D) => {
        var z;
        return {
          count: ((z = j.find((te) => te.type === D.detailCode)) == null ? void 0 : z.count) || 0,
          ...D,
          ...JSON.parse(D.detailDescn)
        };
      }).sort((D, B) => D.order - B.order);
    }, O = (r) => {
      b.value = !0, s.value = r;
    }, m = (r) => {
      switch (r) {
        case "user":
          Ae.warning("敬请期待...");
          break;
        case "logout":
          X();
          break;
        case "fullScreen":
          Je.toggle();
          break;
        case "extend":
          Je.toggle(document.getElementById("layout-content"));
          break;
      }
    }, C = () => {
      Je.toggle();
    }, p = W(!1), F = () => {
      l({
        url: "wsNotify",
        data: `?access_token=${localStorage.getItem("HDL_TOKEN")}&deviceId=${ce(8)}`
      }), A(Pe, () => {
        g(Pe, {
          type: "ping"
        }, {
          interval: 30 * 1e3,
          // 30秒心跳时间
          isHeartbeat: !0
        });
      }), I(Pe, (r) => {
        p.value = !1, r.type !== "pong" && (o.value && f(), b.value && (p.value = !0)), r.type === "enabled-receive-config" && (o.value = !0);
      });
    }, w = () => {
      l({
        url: "baseSocket",
        wsFlag: Ee,
        data: `?access_token=${localStorage.getItem("HDL_TOKEN")}`
      }), A(Ee, () => {
        g(Ee, {
          type: "ping"
        });
      });
    };
    return pe(async () => {
      Z("getMenuStatus", c[c.collapse ? "collapseWidth" : "width"]), await L(), H.value && (await J(), await f(), F(), w()), Je.on("change", function() {
        h.value = Je.isFullscreen;
      });
    }), eg(() => {
      d(Pe), d(Ee);
    }), (r, j) => {
      const D = S("el-badge"), B = S("el-icon"), z = S("el-dropdown-item"), te = S("el-dropdown-menu"), oe = S("el-dropdown");
      return y(), N("div", Sl, [
        x("div", Rl, [
          e.showCollapse ? (y(), N("div", {
            key: 0,
            class: "layout-icon",
            onClick: V
          }, [
            (y(), U(xe(e.collapse ? v(tI) : v(oI))))
          ])) : E("", !0),
          we(r.$slots, "left")
        ]),
        x("div", wl, [
          we(r.$slots, "center")
        ]),
        x("div", fl, [
          x("div", Yl, [
            x("div", kl, [
              v(h) ? (y(), U(v(vg), {
                key: 1,
                class: "icon",
                onClick: C
              })) : (y(), U(v(Gg), {
                key: 0,
                class: "icon",
                onClick: C
              }))
            ]),
            v(H) ? (y(), U(oe, {
              key: 0,
              onCommand: O
            }, {
              dropdown: n(() => [
                t(te, null, {
                  default: n(() => [
                    (y(!0), N(T, null, $(v(u), (Y, ee) => (y(), U(z, {
                      class: "dropdown-item",
                      key: ee,
                      command: Y.detailCode
                    }, {
                      default: n(() => [
                        x("div", Nl, [
                          t(B, null, {
                            default: n(() => [
                              (y(), N("svg", null, [
                                x("use", {
                                  href: `#${Y.icon}`
                                }, null, 8, xl)
                              ]))
                            ]),
                            _: 2
                          }, 1024)
                        ]),
                        x("span", Ll, P(Y.detailName) + P(Y.count > 0 ? `(${Y.count})` : ""), 1)
                      ]),
                      _: 2
                    }, 1032, ["command"]))), 128))
                  ]),
                  _: 1
                })
              ]),
              default: n(() => [
                x("div", Jl, [
                  t(D, {
                    isDot: v(K),
                    class: "item"
                  }, {
                    default: n(() => [
                      t(v(nI), { class: "icon" })
                    ]),
                    _: 1
                  }, 8, ["isDot"])
                ])
              ]),
              _: 1
            })) : E("", !0),
            t(oe, { onCommand: m }, {
              dropdown: n(() => [
                t(te, null, {
                  default: n(() => [
                    t(z, {
                      class: "dropdown-item",
                      command: "user"
                    }, {
                      default: n(() => [
                        x("div", Dl, [
                          t(v(dg), { class: "icon" })
                        ]),
                        j[1] || (j[1] = x("span", { class: "dropdown-item-txt" }, "个人中心", -1))
                      ]),
                      _: 1
                    }),
                    t(z, {
                      class: "dropdown-item",
                      command: "fullScreen"
                    }, {
                      default: n(() => [
                        x("div", Ol, [
                          v(h) ? (y(), U(v(vg), {
                            key: 1,
                            class: "icon"
                          })) : (y(), U(v(Gg), {
                            key: 0,
                            class: "icon"
                          }))
                        ]),
                        j[2] || (j[2] = x("span", { class: "dropdown-item-txt" }, "界面全屏", -1))
                      ]),
                      _: 1
                    }),
                    t(z, {
                      class: "dropdown-item",
                      command: "extend"
                    }, {
                      default: n(() => [
                        x("div", Tl, [
                          t(v(dI), { class: "icon" })
                        ]),
                        j[3] || (j[3] = x("span", { class: "dropdown-item-txt" }, "内容全屏", -1))
                      ]),
                      _: 1
                    }),
                    t(z, {
                      class: "dropdown-item",
                      command: "logout"
                    }, {
                      default: n(() => [
                        x("div", Ml, [
                          t(v(sI), { class: "icon" })
                        ]),
                        j[4] || (j[4] = x("span", { class: "dropdown-item-txt" }, "退出登录", -1))
                      ]),
                      _: 1
                    })
                  ]),
                  _: 1
                })
              ]),
              default: n(() => [
                x("div", Fl, [
                  x("div", Ul, [
                    v(G) ? (y(), N("img", {
                      key: 1,
                      src: v(G),
                      class: "user-img"
                    }, null, 8, zl)) : (y(), U(v(dg), {
                      key: 0,
                      class: "font-icon"
                    }))
                  ]),
                  x("div", jl, P(e.userName), 1)
                ])
              ]),
              _: 1
            })
          ])
        ]),
        t(Kl, {
          modelValue: v(b),
          "onUpdate:modelValue": j[0] || (j[0] = (Y) => fe(b) ? b.value = Y : null),
          "notice-type": v(s),
          "notice-type-list": v(u),
          "is-need-refresh": v(p),
          onRefreshCount: f
        }, null, 8, ["modelValue", "notice-type", "notice-type-list", "is-need-refresh"])
      ]);
    };
  }
}), Pl = { class: "iconpark-icon" }, El = ["href"], _l = {
  key: 0,
  class: "collapse-title"
}, ql = { key: 1 }, $l = { class: "iconpark-icon" }, eC = ["href"], gC = {
  key: 0,
  class: "collapse-title"
}, IC = /* @__PURE__ */ q({
  __name: "hdlSubMenus",
  props: {
    flag: {
      // 切割符
      type: String,
      default: "hdl-HDL"
    },
    menuInfo: {
      // 菜单数据
      type: Object,
      default: () => ({})
    },
    collapse: {
      // 菜单折叠状态
      type: Boolean,
      default: !0
    }
  },
  setup(e) {
    return (a, l) => {
      const I = S("el-icon"), A = S("hdl-sub-menus", !0), g = S("el-menu-item"), d = S("el-sub-menu");
      return y(), U(d, {
        index: `${e.menuInfo.url}${e.flag}${e.menuInfo.sn}`
      }, {
        title: n(() => [
          x("div", {
            class: Xe(e.collapse ? "menu-collapse" : "")
          }, [
            t(I, null, {
              default: n(() => [
                (y(), N("svg", Pl, [
                  x("use", {
                    href: `#${e.menuInfo.icon}`
                  }, null, 8, El)
                ]))
              ]),
              _: 1
            }),
            e.collapse ? (y(), N("span", _l, P(e.menuInfo.alias), 1)) : (y(), N("span", ql, P(e.menuInfo.name), 1))
          ], 2)
        ]),
        default: n(() => [
          (y(!0), N(T, null, $(e.menuInfo.childs, (c) => (y(), N(T, {
            key: c.menuId
          }, [
            c.childs && c.childs.length ? (y(), U(A, {
              key: 0,
              flag: e.flag,
              "menu-info": c,
              collapse: e.collapse
            }, null, 8, ["flag", "menu-info", "collapse"])) : (y(), U(g, {
              key: 1,
              index: `${c.url}${e.flag}${c.sn}`
            }, {
              title: n(() => [
                e.collapse ? E("", !0) : (y(), N(T, { key: 0 }, [
                  k(P(c.name), 1)
                ], 64))
              ]),
              default: n(() => [
                x("div", {
                  class: Xe(e.collapse ? "menu-collapse" : "")
                }, [
                  t(I, null, {
                    default: n(() => [
                      (y(), N("svg", $l, [
                        x("use", {
                          href: `#${c.icon}`
                        }, null, 8, eC)
                      ]))
                    ]),
                    _: 2
                  }, 1024),
                  e.collapse ? (y(), N("span", gC, P(c.alias), 1)) : E("", !0)
                ], 2)
              ]),
              _: 2
            }, 1032, ["index"]))
          ], 64))), 128))
        ]),
        _: 1
      }, 8, ["index"]);
    };
  }
}), lC = { class: "iconpark-icon" }, CC = ["href"], AC = {
  key: 0,
  class: "collapse-title"
}, ve = "hdl-HDL", aC = /* @__PURE__ */ q({
  __name: "hdlMenus",
  props: {
    userName: {
      // 当前登录的用户名
      type: String,
      required: !0
    },
    systemSn: {
      // 你需要获取的系统菜单类型，因为后端返回了所有系统的菜单，所以需要这个去过滤我想要的系统的菜单
      type: String,
      required: !0
    },
    collapse: {
      // 菜单折叠状态
      type: Boolean,
      required: !0
    }
  },
  emits: ["getSystemName"],
  setup(e, { emit: a }) {
    const l = Yg(), I = ZI(), A = e, g = a, d = W([]), c = W(""), Z = (b) => {
      const s = `/${b.split(ve)[0]}`;
      I.path !== s && (localStorage.setItem(Ce.HDL_MENU_SN.value, b.split(ve)[1]), l.push({ path: s }));
    }, G = (b, s) => {
      var u;
      let R = "";
      for (let o = 0; o < b.length; o++) {
        if (b[o].url === s) {
          R = b[o].sn;
          break;
        }
        if (b[o].childs && ((u = b[o].childs) != null && u.length) && (R = G(b[o].childs || [], s), R))
          return R;
      }
      return R;
    }, K = async () => {
      const s = (await ie({
        url: "getMenuData",
        data: {
          username: A.userName
        }
      })).resData.filter((h) => h.category === He.qkMenuType.value && h.sn === A.systemSn);
      if (!s.length)
        return;
      d.value = s[0].childs || [];
      const R = G(s[0].childs || [], s[0].url), u = localStorage.getItem(Ce.HDL_MENU_SN.value);
      localStorage.setItem(Ce.HDL_MENU_SN.value, R || "");
      const o = localStorage.getItem(Ce.HDL_TYPE.value) === "3";
      localStorage.removeItem(Ce.HDL_TYPE.value);
      const H = JSON.parse(localStorage.getItem(Ce.HDL_MENU.value) || "[]");
      if (u) {
        const h = H.find((i) => i.sn === u && i.category === He.qkMenuType.value);
        c.value = `${h == null ? void 0 : h.url}${ve}${u}`, localStorage.setItem(Ce.HDL_MENU_SN.value, u || "");
      } else
        c.value = `${s[0].url}${ve}${R}`;
      if (o) {
        const h = H.find((i) => i.url === I.path.substring(1) && i.type !== 0 && i.category === He.qkMenuType.value);
        c.value = `${h == null ? void 0 : h.url}${ve}${h.sn}`, localStorage.setItem(Ce.HDL_MENU_SN.value, h.sn || "");
      }
      g("getSystemName", s[0].name), zI(l, d.value), Z(c.value), l.push({ path: `/${c.value.split(ve)[0]}`, query: o ? { type: "3" } : {} });
    };
    return M(() => A.userName, (b) => {
      b && (K(), MI());
    }), (b, s) => {
      const R = S("el-icon"), u = S("el-menu-item"), o = S("el-menu"), H = S("el-scrollbar");
      return y(), U(H, { class: "hdl-menus" }, {
        default: n(() => [
          t(o, {
            collapse: e.collapse,
            "default-active": v(c),
            onSelect: Z
          }, {
            default: n(() => [
              (y(!0), N(T, null, $(v(d), (h) => (y(), N(T, {
                key: h.menuId
              }, [
                h.childs && h.childs.length ? (y(), U(IC, {
                  key: 0,
                  flag: ve,
                  "menu-info": h,
                  collapse: e.collapse
                }, null, 8, ["menu-info", "collapse"])) : (y(), U(u, {
                  key: 1,
                  index: `${h.url}${ve}${h.sn}`
                }, {
                  title: n(() => [
                    k(P(h.name), 1)
                  ]),
                  default: n(() => [
                    x("div", {
                      class: Xe(e.collapse ? "menu-collapse" : "")
                    }, [
                      t(R, null, {
                        default: n(() => [
                          (y(), N("svg", lC, [
                            x("use", {
                              href: `#${h.icon}`
                            }, null, 8, CC)
                          ]))
                        ]),
                        _: 2
                      }, 1024),
                      e.collapse ? (y(), N("span", AC, P(h.alias), 1)) : E("", !0)
                    ], 2)
                  ]),
                  _: 2
                }, 1032, ["index"]))
              ], 64))), 128))
            ]),
            _: 1
          }, 8, ["collapse", "default-active"])
        ]),
        _: 1
      });
    };
  }
}), oC = {
  key: 0,
  class: "hdl-search",
  ref: "hdlSearchRef"
}, tC = { class: "hdl-search-main" }, nC = {
  key: 0,
  class: "hdl-form-btn"
}, dC = /* @__PURE__ */ q({
  __name: "hdlSearch",
  props: {
    auth: {
      // 筛选区域父级权限标识
      type: String,
      default: ""
    },
    modelValue: {
      // 筛选区域父级数据
      type: Array,
      required: !0
    },
    hideBtn: {
      // 是否隐藏掉重置按钮、搜索按钮等
      type: Boolean,
      default: !1
    },
    refreshToSearch: {
      // 点击重置后，是否自动执行search回调
      type: Boolean,
      default: !0
    }
  },
  emits: ["search", "refresh", "update:modelValue"],
  setup(e, { emit: a }) {
    const l = e, I = a, A = he("hdlSearchRef"), g = Ie({
      // 默认的属性配置
      clearable: !0
      // 是否可清空
    }), d = Ie({
      // 默认子组件属性配置
      label: "label",
      value: "value"
    }), c = l.modelValue.map((V) => V.model), Z = Ie({
      // 筛选框的样式
      paddingBottom: "0px"
    }), G = W(42), K = W([]), b = _(() => (V) => Object.prototype.hasOwnProperty.call(V, "show") ? V.show : !0), s = _(() => (V) => {
      const X = V.auth || "";
      return `${l.auth}-${X}-${V.onlyAuth}`;
    });
    (async () => {
      var X;
      const V = await mg();
      K.value = ((X = V.find((L) => L.code === l.auth)) == null ? void 0 : X.filterConfigList) ?? [];
    })();
    const u = _(() => (V) => {
      var f, O;
      if (!((f = K.value) != null && f.length))
        return {};
      const X = (O = K.value) == null ? void 0 : O.findIndex((m) => m.code === V);
      if (X === -1)
        return {};
      const L = K.value[X].prop, J = {};
      for (const m in L)
        ["auth", "onlyAuth"].includes(m) || (J[m] = L[m]);
      return J;
    }), o = () => {
      const V = l.modelValue;
      c.forEach((X, L) => {
        V[L].model = X;
      }), I("update:modelValue", V);
    }, H = Ze(() => {
      I("search");
    }), h = Ze(() => {
      o(), I("refresh"), l.refreshToSearch && I("search");
    }), i = Ze(() => {
      Ae.warning("敬请期待");
    });
    return Og(A, () => {
      var X, L;
      const V = (X = A.value) == null ? void 0 : X.querySelectorAll(".hdl-form-item");
      V != null && V.length || (L = A.value) == null || L.remove();
    }), pe(() => {
      Dg(A.value, (V) => {
        V.height === G.value ? (Z.paddingBottom = "0px", A.value.style.paddingBottom = "5px") : (Z.paddingBottom = "5px", A.value.style.paddingBottom = "0px");
      }, !0);
    }), (V, X) => {
      const L = S("el-button"), J = ng("search-auth");
      return e.modelValue.length ? (y(), N("div", oC, [
        x("div", tC, [
          (y(!0), N(T, null, $(e.modelValue, (f) => We((y(), N("div", {
            class: "hdl-form-item",
            key: f.id,
            style: me(v(Z))
          }, [
            f.comName === "el-select" ? (y(), N(T, { key: 0 }, [
              v(b)(f) ? We((y(), U(xe(f.comName), ae({
                key: 0,
                ref_for: !0
              }, { ...v(g), ...f.props || {}, ...v(u)(f.auth) }, pg(f.emits || {}), {
                modelValue: f.model,
                "onUpdate:modelValue": (O) => f.model = O,
                style: { width: v(kg).width.value + "px" }
              }), {
                default: n(() => [
                  (y(!0), N(T, null, $(f.children.data, (O) => {
                    var m, C, p;
                    return y(), U(xe(f.children.comName), ae({
                      key: O[((m = f.children.props) == null ? void 0 : m.value) ?? v(d).value],
                      ref_for: !0
                    }, { ...f.children.props || {}, label: O[((C = f.children.props) == null ? void 0 : C.label) ?? v(d).label], value: O[((p = f.children.props) == null ? void 0 : p.value) ?? v(d).value] }), null, 16);
                  }), 128))
                ]),
                _: 2
              }, 1040, ["modelValue", "onUpdate:modelValue", "style"])), [
                [J, v(K), v(s)(f)]
              ]) : E("", !0)
            ], 64)) : (y(), N(T, { key: 1 }, [
              v(b)(f) ? (y(), U(xe(f.comName), ae({
                key: 0,
                ref_for: !0
              }, { ...v(g), ...f.props || {}, ...v(u)(f.auth) }, pg(f.emits || {}), {
                modelValue: f.model,
                "onUpdate:modelValue": (O) => f.model = O,
                class: "full-width"
              }), null, 16, ["modelValue", "onUpdate:modelValue"])) : E("", !0)
            ], 64))
          ], 4)), [
            [J, v(K), v(s)(f)]
          ])), 128))
        ]),
        e.hideBtn ? E("", !0) : (y(), N("div", nC, [
          t(L, {
            type: "primary",
            icon: v(fg),
            circle: "",
            onClick: v(H)
          }, null, 8, ["icon", "onClick"]),
          t(L, {
            type: "warning",
            icon: v(uI),
            circle: "",
            onClick: v(h)
          }, null, 8, ["icon", "onClick"]),
          t(L, {
            type: "info",
            icon: v(cI),
            circle: "",
            onClick: v(i)
          }, null, 8, ["icon", "onClick"])
        ]))
      ], 512)) : E("", !0);
    };
  }
}), sC = {
  class: "hdl-btn",
  ref: "hdlBtn"
}, uC = { key: 0 }, cC = /* @__PURE__ */ q({
  __name: "hdlBtn",
  props: {
    modelValue: {
      type: Array,
      required: !0
    }
  },
  setup(e) {
    const a = e, l = ["primary", "success", "info", "warning", "danger"];
    let I = 0;
    const A = {}, g = W(42), d = Ie({
      // 筛选框的默认宽度
      paddingBottom: "0px"
    }), c = (s, R) => {
      const u = R;
      if (A[u])
        return A[u];
      if (!s) {
        I = I >= l.length ? 0 : I;
        const H = I === 0 ? "primary" : l[I];
        return I++, A[u] = H, H;
      }
      const o = l.findIndex((H) => H === s);
      return I = o === -1 ? I : o, A[u] = s || "primary", s || "primary";
    }, Z = (s) => {
      const R = s.split("_"), u = R[0], o = Number(R[1]), H = a.modelValue.findIndex((h) => h.name === u);
      H !== -1 && a.modelValue[H].children[o].func();
    }, G = he("hdlBtn"), K = Ze(() => {
      var R, u;
      const s = (R = G.value) == null ? void 0 : R.children;
      s != null && s.length || (u = G.value) == null || u.remove();
    }, {
      isImmediate: !1,
      delay: 0
    }), b = () => {
      if (!G.value)
        return;
      if (!G.value.children.length) {
        G.value.style.display = "none";
        return;
      }
      G.value.style.display = "flex";
      const s = G.value.querySelectorAll(".btn-dropdown");
      if (s.length)
        for (let R = 0; R < s.length; R++) {
          const u = s[R], o = u.querySelectorAll(".btn-dropdown-menu");
          if (!o.length) {
            u.parentElement.remove();
            continue;
          }
          for (let H = 0; H < o.length; H++)
            o[H].children.length || u.parentElement.remove();
        }
    };
    return Og(G, () => {
      var R, u, o;
      if (!((u = (R = G.value) == null ? void 0 : R.children) == null ? void 0 : u.length)) {
        (o = G.value) == null || o.remove();
        return;
      }
      b();
    }), pe(async () => {
      Dg(G.value, (s) => {
        s.height === g.value ? (d.paddingBottom = "0px", G.value.style.paddingBottom = "5px") : (d.paddingBottom = "5px", G.value.style.paddingBottom = "0px");
      }, !0), b();
    }), (s, R) => {
      const u = S("el-icon"), o = S("el-button"), H = S("el-dropdown-item"), h = S("el-dropdown-menu"), i = S("el-dropdown"), V = S("el-upload"), X = S("el-tooltip"), L = ng("btnAuth"), J = ng("btn-auth");
      return y(), N("div", sC, [
        (y(!0), N(T, null, $(e.modelValue, (f) => (y(), N(T, {
          key: f.name
        }, [
          f.type === "select" ? (y(), N("div", {
            key: 0,
            class: "btn-item",
            style: me(v(d))
          }, [
            t(i, {
              placement: "bottom-start",
              teleported: !1,
              onCommand: Z,
              class: "btn-dropdown"
            }, {
              dropdown: n(() => [
                t(h, { class: "btn-dropdown-menu" }, {
                  default: n(() => [
                    (y(!0), N(T, null, $(f.children, (O, m) => (y(), N(T, {
                      key: O.auth
                    }, [
                      !Object.prototype.hasOwnProperty.call(O, "show") || O.show ? We((y(), N("div", uC, [
                        t(H, {
                          command: f.name + "_" + m,
                          disabled: O.loading,
                          icon: O.icon || v(Ne)
                        }, {
                          default: n(() => [
                            k(P(O.name), 1)
                          ]),
                          _: 2
                        }, 1032, ["command", "disabled", "icon"])
                      ])), [
                        [L, v(K), O]
                      ]) : E("", !0)
                    ], 64))), 128))
                  ]),
                  _: 2
                }, 1024)
              ]),
              default: n(() => [
                t(o, {
                  type: c(f.class, f.name)
                }, {
                  default: n(() => [
                    k(P(f.name) + " ", 1),
                    t(u, { class: "el-icon--right" }, {
                      default: n(() => [
                        t(v(iI))
                      ]),
                      _: 1
                    })
                  ]),
                  _: 2
                }, 1032, ["type"])
              ]),
              _: 2
            }, 1024)
          ], 4)) : f.type === "upload" ? (y(), N(T, { key: 1 }, [
            !Object.prototype.hasOwnProperty.call(f, "show") || f.show ? (y(), N("div", {
              key: 0,
              class: "btn-item",
              style: me(v(d))
            }, [
              t(V, ae({ ref_for: !0 }, f.props || {}, {
                "show-file-list": !1,
                class: "hdl-upload"
              }), {
                default: n(() => [
                  We((y(), U(o, {
                    type: c(f.class, f.name),
                    icon: f.icon || v(Ne)
                  }, {
                    default: n(() => [
                      k(P(f.name), 1)
                    ]),
                    _: 2
                  }, 1032, ["type", "icon"])), [
                    [L, v(K), f]
                  ])
                ]),
                _: 2
              }, 1040)
            ], 4)) : E("", !0)
          ], 64)) : f.type === "tooltip" ? (y(), N(T, { key: 2 }, [
            !Object.prototype.hasOwnProperty.call(f, "show") || f.show ? (y(), N("div", {
              key: 0,
              class: "btn-item",
              style: me(v(d))
            }, [
              t(X, ae({ ref_for: !0 }, f.props || {}), {
                default: n(() => [
                  We((y(), U(o, {
                    type: c(f.class, f.name),
                    loading: f.loading,
                    onClick: f.func,
                    icon: f.icon || v(Ne)
                  }, {
                    default: n(() => [
                      k(P(f.name), 1)
                    ]),
                    _: 2
                  }, 1032, ["type", "loading", "onClick", "icon"])), [
                    [L, v(K), f]
                  ])
                ]),
                _: 2
              }, 1040)
            ], 4)) : E("", !0)
          ], 64)) : (y(), N(T, { key: 3 }, [
            !Object.prototype.hasOwnProperty.call(f, "show") || f.show ? (y(), N("div", {
              key: 0,
              class: "btn-item",
              style: me(v(d))
            }, [
              We((y(), U(o, {
                type: c(f.class, f.name),
                icon: f.icon || v(Ne),
                loading: f.loading,
                onClick: f.func
              }, {
                default: n(() => [
                  k(P(f.name), 1)
                ]),
                _: 2
              }, 1032, ["type", "icon", "loading", "onClick"])), [
                [J, v(K), f]
              ])
            ], 4)) : E("", !0)
          ], 64))
        ], 64))), 128))
      ], 512);
    };
  }
}), iC = /* @__PURE__ */ q({
  __name: "second",
  props: {
    readonly: {
      type: Boolean,
      default: !1
    },
    check: {
      type: Function,
      required: !0
    }
  },
  emits: ["update"],
  setup(e, { expose: a, emit: l }) {
    const I = e, A = l, g = W(1), d = W(0), c = W(1), Z = W(0), G = W(1), K = W(["0"]), b = I.check, s = _(() => {
      const m = b(d.value, 0, 58), C = b(
        c.value,
        m ? m + 1 : 1,
        59
      );
      return m + "-" + C;
    }), R = _(() => {
      const m = b(Z.value, 0, 58), C = b(G.value, 1, 59 - m || 0);
      return m + "/" + C;
    }), u = _(() => {
      let m = K.value.join();
      return m == "" ? "*" : m;
    }), o = () => {
      switch (g.value) {
        case 1:
          A("update", "second", "*", "second");
          break;
        case 2:
          A("update", "second", s.value);
          break;
        case 3:
          A("update", "second", R.value);
          break;
        case 4:
          A("update", "second", u.value);
          break;
      }
    }, H = () => {
      g.value === 2 && A("update", "second", s.value);
    }, h = () => {
      g.value === 3 && A("update", "second", R.value);
    }, i = () => {
      g.value === 4 && A("update", "second", u.value);
    };
    return M(g, o), M(s, H), M(R, h), M(u, i), a({
      changeCycle01: (m) => {
        d.value = m;
      },
      changeCycle02: (m) => {
        c.value = m;
      },
      changeAverage01: (m) => {
        Z.value = m;
      },
      changeAverage02: (m) => {
        G.value = m;
      },
      changeCheckboxList: (m) => {
        K.value = m;
      },
      changeRadioValue: (m) => {
        g.value = m;
      }
    }), (m, C) => {
      const p = S("el-radio"), F = S("el-form-item"), w = S("el-input-number"), r = S("el-option"), j = S("el-select"), D = S("el-form");
      return y(), U(D, { "label-width": "auto" }, {
        default: n(() => [
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[0] || (C[0] = (B) => g.value = B),
                label: 1,
                disabled: e.readonly
              }, {
                default: n(() => C[9] || (C[9] = [
                  k(" 秒，允许的通配符[, - * /] ")
                ])),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[3] || (C[3] = (B) => g.value = B),
                label: 2,
                disabled: e.readonly
              }, {
                default: n(() => [
                  C[10] || (C[10] = k(" 周期从 ")),
                  t(w, {
                    modelValue: d.value,
                    "onUpdate:modelValue": C[1] || (C[1] = (B) => d.value = B),
                    min: 0,
                    max: 58,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "disabled"]),
                  C[11] || (C[11] = k(" - ")),
                  t(w, {
                    modelValue: c.value,
                    "onUpdate:modelValue": C[2] || (C[2] = (B) => c.value = B),
                    min: d.value ? d.value * 1 + 1 : 1,
                    max: 59,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "min", "disabled"]),
                  C[12] || (C[12] = k(" 秒 "))
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[6] || (C[6] = (B) => g.value = B),
                label: 3,
                disabled: e.readonly
              }, {
                default: n(() => [
                  C[13] || (C[13] = k(" 从 ")),
                  t(w, {
                    modelValue: Z.value,
                    "onUpdate:modelValue": C[4] || (C[4] = (B) => Z.value = B),
                    min: 0,
                    max: 58,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "disabled"]),
                  C[14] || (C[14] = k(" 秒开始，每 ")),
                  t(w, {
                    modelValue: G.value,
                    "onUpdate:modelValue": C[5] || (C[5] = (B) => G.value = B),
                    min: 1,
                    max: 59 - Z.value || 0,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "max", "disabled"]),
                  C[15] || (C[15] = k(" 秒执行一次 "))
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[8] || (C[8] = (B) => g.value = B),
                label: 4,
                disabled: e.readonly
              }, {
                default: n(() => [
                  C[16] || (C[16] = k(" 指定 ")),
                  t(j, {
                    clearable: "",
                    modelValue: K.value,
                    "onUpdate:modelValue": C[7] || (C[7] = (B) => K.value = B),
                    placeholder: "可多选",
                    multiple: "",
                    style: { width: "192px" },
                    disabled: e.readonly
                  }, {
                    default: n(() => [
                      (y(), N(T, null, $(60, (B) => t(r, {
                        key: B,
                        value: String(B - 1)
                      }, {
                        default: n(() => [
                          k(P(B - 1), 1)
                        ]),
                        _: 2
                      }, 1032, ["value"])), 64))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "disabled"])
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
}), mC = /* @__PURE__ */ q({
  __name: "min",
  props: {
    readonly: {
      type: Boolean,
      default: !1
    },
    check: {
      type: Function,
      required: !0
    }
  },
  emits: ["update"],
  setup(e, { expose: a, emit: l }) {
    const I = e, A = l, g = W(1), d = W(0), c = W(1), Z = W(0), G = W(1), K = W(["0"]), b = I.check, s = _(() => {
      const m = b(d.value, 0, 58), C = b(
        c.value,
        m ? m + 1 : 1,
        59
      );
      return m + "-" + C;
    }), R = _(() => {
      const m = b(Z.value, 0, 58), C = b(G.value, 1, 59 - m || 0);
      return m + "/" + C;
    }), u = _(() => {
      let m = K.value.join();
      return m == "" ? "*" : m;
    }), o = () => {
      switch (g.value) {
        case 1:
          A("update", "min", "*", "min");
          break;
        case 2:
          A("update", "min", s.value, "min");
          break;
        case 3:
          A("update", "min", R.value, "min");
          break;
        case 4:
          A("update", "min", u.value, "min");
          break;
      }
    }, H = () => {
      g.value === 2 && A("update", "min", s.value, "min");
    }, h = () => {
      g.value === 3 && A("update", "min", R.value, "min");
    }, i = () => {
      g.value === 4 && A("update", "min", u.value, "min");
    };
    return M(g, o), M(s, H), M(R, h), M(u, i), a({
      changeCycle01: (m) => {
        d.value = m;
      },
      changeCycle02: (m) => {
        c.value = m;
      },
      changeAverage01: (m) => {
        Z.value = m;
      },
      changeAverage02: (m) => {
        G.value = m;
      },
      changeCheckboxList: (m) => {
        K.value = m;
      },
      changeRadioValue: (m) => {
        g.value = m;
      }
    }), (m, C) => {
      const p = S("el-radio"), F = S("el-form-item"), w = S("el-input-number"), r = S("el-option"), j = S("el-select"), D = S("el-form");
      return y(), U(D, { "label-width": "auto" }, {
        default: n(() => [
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[0] || (C[0] = (B) => g.value = B),
                label: 1,
                disabled: e.readonly
              }, {
                default: n(() => C[9] || (C[9] = [
                  k(" 分钟，允许的通配符[, - * /] ")
                ])),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[3] || (C[3] = (B) => g.value = B),
                label: 2,
                disabled: e.readonly
              }, {
                default: n(() => [
                  C[10] || (C[10] = k(" 周期从 ")),
                  t(w, {
                    modelValue: d.value,
                    "onUpdate:modelValue": C[1] || (C[1] = (B) => d.value = B),
                    min: 0,
                    max: 58,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "disabled"]),
                  C[11] || (C[11] = k(" - ")),
                  t(w, {
                    modelValue: c.value,
                    "onUpdate:modelValue": C[2] || (C[2] = (B) => c.value = B),
                    min: d.value ? d.value * 1 + 1 : 1,
                    max: 59,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "min", "disabled"]),
                  C[12] || (C[12] = k(" 分钟 "))
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[6] || (C[6] = (B) => g.value = B),
                label: 3,
                disabled: e.readonly
              }, {
                default: n(() => [
                  C[13] || (C[13] = k(" 从 ")),
                  t(w, {
                    modelValue: Z.value,
                    "onUpdate:modelValue": C[4] || (C[4] = (B) => Z.value = B),
                    min: 0,
                    max: 58,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "disabled"]),
                  C[14] || (C[14] = k(" 分钟开始，每 ")),
                  t(w, {
                    modelValue: G.value,
                    "onUpdate:modelValue": C[5] || (C[5] = (B) => G.value = B),
                    min: 1,
                    max: 59 - Z.value || 0,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "max", "disabled"]),
                  C[15] || (C[15] = k(" 分钟执行一次 "))
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[8] || (C[8] = (B) => g.value = B),
                label: 4,
                disabled: e.readonly
              }, {
                default: n(() => [
                  C[16] || (C[16] = k(" 指定 ")),
                  t(j, {
                    clearable: "",
                    modelValue: K.value,
                    "onUpdate:modelValue": C[7] || (C[7] = (B) => K.value = B),
                    placeholder: "可多选",
                    multiple: "",
                    style: { width: "192px" },
                    disabled: e.readonly
                  }, {
                    default: n(() => [
                      (y(), N(T, null, $(60, (B) => t(r, {
                        key: B,
                        value: String(B - 1)
                      }, {
                        default: n(() => [
                          k(P(B - 1), 1)
                        ]),
                        _: 2
                      }, 1032, ["value"])), 64))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "disabled"])
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
}), bC = /* @__PURE__ */ q({
  __name: "hour",
  props: {
    readonly: {
      type: Boolean,
      default: !1
    },
    check: {
      type: Function,
      required: !0
    }
  },
  emits: ["update"],
  setup(e, { expose: a, emit: l }) {
    const I = e, A = l, g = W(1), d = W(0), c = W(1), Z = W(0), G = W(1), K = W(["0"]), b = I.check, s = _(() => {
      const m = b(d.value, 0, 22), C = b(
        c.value,
        m ? m + 1 : 1,
        23
      );
      return m + "-" + C;
    }), R = _(() => {
      const m = b(Z.value, 0, 22), C = b(G.value, 1, 23 - m || 0);
      return m + "/" + C;
    }), u = _(() => {
      let m = K.value.join();
      return console.log(m), m == "" ? "*" : m;
    }), o = () => {
      switch (g.value) {
        case 1:
          A("update", "hour", "*");
          break;
        case 2:
          A("update", "hour", s.value);
          break;
        case 3:
          A("update", "hour", R.value);
          break;
        case 4:
          A("update", "hour", u.value);
          break;
      }
    }, H = () => {
      g.value === 2 && A("update", "hour", s.value);
    }, h = () => {
      g.value === 3 && A("update", "hour", R.value);
    }, i = () => {
      g.value === 4 && A("update", "hour", u.value);
    };
    return M(g, o), M(s, H), M(R, h), M(u, i), a({
      changeCycle01: (m) => {
        d.value = m;
      },
      changeCycle02: (m) => {
        c.value = m;
      },
      changeAverage01: (m) => {
        Z.value = m;
      },
      changeAverage02: (m) => {
        G.value = m;
      },
      changeCheckboxList: (m) => {
        K.value = m;
      },
      changeRadioValue: (m) => {
        g.value = m;
      }
    }), (m, C) => {
      const p = S("el-radio"), F = S("el-form-item"), w = S("el-input-number"), r = S("el-option"), j = S("el-select"), D = S("el-form");
      return y(), U(D, { "label-width": "auto" }, {
        default: n(() => [
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[0] || (C[0] = (B) => g.value = B),
                label: 1,
                disabled: e.readonly
              }, {
                default: n(() => C[9] || (C[9] = [
                  k(" 小时，允许的通配符[, - * /] ")
                ])),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[3] || (C[3] = (B) => g.value = B),
                label: 2,
                disabled: e.readonly
              }, {
                default: n(() => [
                  C[10] || (C[10] = k(" 周期从 ")),
                  t(w, {
                    modelValue: d.value,
                    "onUpdate:modelValue": C[1] || (C[1] = (B) => d.value = B),
                    min: 0,
                    max: 22,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "disabled"]),
                  C[11] || (C[11] = k(" - ")),
                  t(w, {
                    modelValue: c.value,
                    "onUpdate:modelValue": C[2] || (C[2] = (B) => c.value = B),
                    min: d.value ? d.value * 1 + 1 : 1,
                    max: 23,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "min", "disabled"]),
                  C[12] || (C[12] = k(" 小时 "))
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[6] || (C[6] = (B) => g.value = B),
                label: 3,
                disabled: e.readonly
              }, {
                default: n(() => [
                  C[13] || (C[13] = k(" 从 ")),
                  t(w, {
                    modelValue: Z.value,
                    "onUpdate:modelValue": C[4] || (C[4] = (B) => Z.value = B),
                    min: 0,
                    max: 22,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "disabled"]),
                  C[14] || (C[14] = k(" 小时开始，每 ")),
                  t(w, {
                    modelValue: G.value,
                    "onUpdate:modelValue": C[5] || (C[5] = (B) => G.value = B),
                    min: 1,
                    max: 23 - Z.value || 0,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "max", "disabled"]),
                  C[15] || (C[15] = k(" 小时执行一次 "))
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[8] || (C[8] = (B) => g.value = B),
                label: 4,
                disabled: e.readonly
              }, {
                default: n(() => [
                  C[16] || (C[16] = k(" 指定 ")),
                  t(j, {
                    clearable: "",
                    modelValue: K.value,
                    "onUpdate:modelValue": C[7] || (C[7] = (B) => K.value = B),
                    placeholder: "可多选",
                    multiple: "",
                    style: { width: "192px" },
                    disabled: e.readonly
                  }, {
                    default: n(() => [
                      (y(), N(T, null, $(24, (B) => t(r, {
                        key: B,
                        value: String(B - 1)
                      }, {
                        default: n(() => [
                          k(P(B - 1), 1)
                        ]),
                        _: 2
                      }, 1032, ["value"])), 64))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "disabled"])
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
}), rC = /* @__PURE__ */ q({
  __name: "day",
  props: {
    readonly: {
      type: Boolean,
      default: !1
    },
    check: {
      type: Function,
      required: !0
    },
    cron: {
      type: Object,
      default: () => ({})
    }
  },
  emits: ["update"],
  setup(e, { expose: a, emit: l }) {
    const I = e, A = l, g = W(1), d = W(1), c = W(1), Z = W(2), G = W(1), K = W(1), b = W(["1"]), s = I.check, R = _(() => {
      const w = s(c.value, 1, 30), r = s(
        Z.value,
        w ? w + 1 : 2,
        31,
        31
      );
      return w + "-" + r;
    }), u = _(() => {
      const w = s(G.value, 1, 30), r = s(K.value, 1, 31 - w || 0);
      return w + "/" + r;
    }), o = _(() => {
      let w = b.value.join();
      return w == "" ? "*" : w;
    }), H = _(() => s(d.value, 1, 31)), h = () => {
      switch (g.value !== 2 && I.cron.week !== "?" && A("update", "week", "?", "day"), g.value === 2 && I.cron.week === "?" && A("update", "week", "*", "day"), g.value) {
        case 1:
          A("update", "day", "*");
          break;
        case 2:
          A("update", "day", "?");
          break;
        case 3:
          A("update", "day", R.value);
          break;
        case 4:
          A("update", "day", u.value);
          break;
        case 5:
          A("update", "day", d.value + "W");
          break;
        case 6:
          A("update", "day", "L");
          break;
        case 7:
          A("update", "day", o.value);
          break;
      }
    }, i = () => {
      g.value === 3 && A("update", "day", R.value);
    }, V = () => {
      g.value === 4 && A("update", "day", u.value);
    }, X = () => {
      g.value === 5 && A("update", "day", H.value + "W");
    }, L = () => {
      g.value === 7 && A("update", "day", o.value);
    };
    return M(g, h), M(R, i), M(u, V), M(H, X), M(o, L), a({
      changeCycle01: (w) => {
        c.value = w;
      },
      changeCycle02: (w) => {
        Z.value = w;
      },
      changeAverage01: (w) => {
        G.value = w;
      },
      changeAverage02: (w) => {
        K.value = w;
      },
      changeCheckboxList: (w) => {
        b.value = w;
      },
      changeWorkday: (w) => {
        d.value = w;
      },
      changeRadioValue: (w) => {
        g.value = w;
      }
    }), (w, r) => {
      const j = S("el-radio"), D = S("el-form-item"), B = S("el-input-number"), z = S("el-option"), te = S("el-select"), oe = S("el-form");
      return y(), U(oe, { "label-width": "auto" }, {
        default: n(() => [
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[0] || (r[0] = (Y) => g.value = Y),
                label: 1,
                disabled: e.readonly
              }, {
                default: n(() => r[13] || (r[13] = [
                  k(" 日，允许的通配符[, - * ? / L W] ")
                ])),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[1] || (r[1] = (Y) => g.value = Y),
                label: 2,
                disabled: e.readonly
              }, {
                default: n(() => r[14] || (r[14] = [
                  k(" 不指定 ")
                ])),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[4] || (r[4] = (Y) => g.value = Y),
                label: 3,
                disabled: e.readonly
              }, {
                default: n(() => [
                  r[15] || (r[15] = k(" 周期从 ")),
                  t(B, {
                    modelValue: c.value,
                    "onUpdate:modelValue": r[2] || (r[2] = (Y) => c.value = Y),
                    min: 1,
                    max: 30,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "disabled"]),
                  r[16] || (r[16] = k(" - ")),
                  t(B, {
                    modelValue: Z.value,
                    "onUpdate:modelValue": r[3] || (r[3] = (Y) => Z.value = Y),
                    min: c.value ? c.value * 1 + 1 : 2,
                    max: 31,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "min", "disabled"]),
                  r[17] || (r[17] = k(" 日 "))
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[7] || (r[7] = (Y) => g.value = Y),
                label: 4,
                disabled: e.readonly
              }, {
                default: n(() => [
                  r[18] || (r[18] = k(" 从 ")),
                  t(B, {
                    modelValue: G.value,
                    "onUpdate:modelValue": r[5] || (r[5] = (Y) => G.value = Y),
                    min: 1,
                    max: 30,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "disabled"]),
                  r[19] || (r[19] = k(" 号开始，每 ")),
                  t(B, {
                    modelValue: K.value,
                    "onUpdate:modelValue": r[6] || (r[6] = (Y) => K.value = Y),
                    min: 1,
                    max: 31 - G.value || 1,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "max", "disabled"]),
                  r[20] || (r[20] = k(" 日执行一次 "))
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[9] || (r[9] = (Y) => g.value = Y),
                label: 5,
                disabled: e.readonly
              }, {
                default: n(() => [
                  r[21] || (r[21] = k(" 每月 ")),
                  t(B, {
                    modelValue: d.value,
                    "onUpdate:modelValue": r[8] || (r[8] = (Y) => d.value = Y),
                    min: 1,
                    max: 31,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "disabled"]),
                  r[22] || (r[22] = k(" 号最近的那个工作日 "))
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[10] || (r[10] = (Y) => g.value = Y),
                label: 6,
                disabled: e.readonly
              }, {
                default: n(() => r[23] || (r[23] = [
                  k(" 本月最后一天 ")
                ])),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[12] || (r[12] = (Y) => g.value = Y),
                label: 7,
                disabled: e.readonly
              }, {
                default: n(() => [
                  r[24] || (r[24] = k(" 指定 ")),
                  t(te, {
                    clearable: "",
                    modelValue: b.value,
                    "onUpdate:modelValue": r[11] || (r[11] = (Y) => b.value = Y),
                    placeholder: "可多选",
                    multiple: "",
                    style: { width: "192px" },
                    disabled: e.readonly
                  }, {
                    default: n(() => [
                      (y(), N(T, null, $(31, (Y) => t(z, {
                        key: Y,
                        value: String(Y)
                      }, {
                        default: n(() => [
                          k(P(Y), 1)
                        ]),
                        _: 2
                      }, 1032, ["value"])), 64))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "disabled"])
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
}), ZC = /* @__PURE__ */ q({
  __name: "month",
  props: {
    readonly: {
      type: Boolean,
      default: !1
    },
    check: {
      type: Function,
      required: !0
    }
  },
  emits: ["update"],
  setup(e, { expose: a, emit: l }) {
    const I = e, A = l, g = W(1), d = W(0), c = W(1), Z = W(0), G = W(1), K = W(["0"]), b = I.check, s = () => {
      switch (g.value) {
        case 1:
          A("update", "month", "*");
          break;
        case 2:
          A("update", "month", R.value);
          break;
        case 3:
          A("update", "month", u.value);
          break;
        case 4:
          A("update", "month", o.value);
          break;
      }
    }, R = _(() => {
      const m = b(d.value, 1, 11), C = b(
        c.value,
        m ? m + 1 : 2,
        12
      );
      return m + "-" + C;
    }), u = _(() => {
      const m = b(Z.value, 1, 11), C = b(G.value, 1, 12 - m || 0);
      return m + "/" + C;
    }), o = _(() => {
      let m = K.value.join();
      return m == "" ? "*" : m;
    }), H = () => {
      g.value === 2 && A("update", "month", R.value);
    }, h = () => {
      g.value === 3 && A("update", "month", u.value);
    }, i = () => {
      g.value == 4 && A("update", "month", o.value);
    };
    return M(g, s), M(R, H), M(u, h), M(o, i), a({
      changeCycle01: (m) => {
        d.value = m;
      },
      changeCycle02: (m) => {
        c.value = m;
      },
      changeAverage01: (m) => {
        Z.value = m;
      },
      changeAverage02: (m) => {
        G.value = m;
      },
      changeCheckboxList: (m) => {
        K.value = m;
      },
      changeRadioValue: (m) => {
        g.value = m;
      }
    }), (m, C) => {
      const p = S("el-radio"), F = S("el-form-item"), w = S("el-input-number"), r = S("el-option"), j = S("el-select"), D = S("el-form");
      return y(), U(D, { "label-width": "auto" }, {
        default: n(() => [
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[0] || (C[0] = (B) => g.value = B),
                label: 1,
                disabled: e.readonly
              }, {
                default: n(() => C[9] || (C[9] = [
                  k(" 月，允许的通配符[, - * /] ")
                ])),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[3] || (C[3] = (B) => g.value = B),
                label: 2,
                disabled: e.readonly
              }, {
                default: n(() => [
                  C[10] || (C[10] = k(" 周期从 ")),
                  t(w, {
                    modelValue: d.value,
                    "onUpdate:modelValue": C[1] || (C[1] = (B) => d.value = B),
                    min: 1,
                    max: 11,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "disabled"]),
                  C[11] || (C[11] = k(" - ")),
                  t(w, {
                    modelValue: c.value,
                    "onUpdate:modelValue": C[2] || (C[2] = (B) => c.value = B),
                    min: d.value ? d.value * 1 + 1 : 2,
                    max: 12,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "min", "disabled"]),
                  C[12] || (C[12] = k(" 月 "))
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[6] || (C[6] = (B) => g.value = B),
                label: 3,
                disabled: e.readonly
              }, {
                default: n(() => [
                  C[13] || (C[13] = k(" 从 ")),
                  t(w, {
                    modelValue: Z.value,
                    "onUpdate:modelValue": C[4] || (C[4] = (B) => Z.value = B),
                    min: 1,
                    max: 11,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "disabled"]),
                  C[14] || (C[14] = k(" 月开始，每 ")),
                  t(w, {
                    modelValue: G.value,
                    "onUpdate:modelValue": C[5] || (C[5] = (B) => G.value = B),
                    min: 1,
                    max: 12 - Z.value || 0,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "max", "disabled"]),
                  C[15] || (C[15] = k(" 月执行一次 "))
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(F, null, {
            default: n(() => [
              t(p, {
                modelValue: g.value,
                "onUpdate:modelValue": C[8] || (C[8] = (B) => g.value = B),
                label: 4,
                disabled: e.readonly
              }, {
                default: n(() => [
                  C[16] || (C[16] = k(" 指定 ")),
                  t(j, {
                    clearable: "",
                    modelValue: K.value,
                    "onUpdate:modelValue": C[7] || (C[7] = (B) => K.value = B),
                    placeholder: "可多选",
                    multiple: "",
                    style: { width: "192px" },
                    disabled: e.readonly
                  }, {
                    default: n(() => [
                      (y(), N(T, null, $(12, (B) => t(r, {
                        key: B,
                        value: String(B)
                      }, {
                        default: n(() => [
                          k(P(B), 1)
                        ]),
                        _: 2
                      }, 1032, ["value"])), 64))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "disabled"])
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
}), pC = /* @__PURE__ */ q({
  __name: "week",
  props: {
    readonly: {
      type: Boolean,
      default: !1
    },
    check: {
      type: Function,
      required: !0
    },
    cron: {
      type: Object,
      default: () => ({})
    }
  },
  emits: ["update"],
  setup(e, { expose: a, emit: l }) {
    const I = e, A = l, g = W(2), d = W(2), c = W(2), Z = W(3), G = W(1), K = W(2), b = W(["0"]), s = W([
      {
        key: 2,
        value: "星期一"
      },
      {
        key: 3,
        value: "星期二"
      },
      {
        key: 4,
        value: "星期三"
      },
      {
        key: 5,
        value: "星期四"
      },
      {
        key: 6,
        value: "星期五"
      },
      {
        key: 7,
        value: "星期六"
      },
      {
        key: 1,
        value: "星期日"
      }
    ]), R = I.check, u = _(() => (c.value = R(c.value, 1, 7), Z.value = R(Z.value, 1, 7), c.value + "-" + Z.value)), o = _(() => (G.value = R(G.value, 1, 4), K.value = R(K.value, 1, 7), G.value + "#" + K.value)), H = _(() => (d.value = R(d.value, 1, 7), d.value)), h = _(() => {
      let w = b.value.join();
      return w == "" ? "*" : w;
    }), i = () => {
      switch (g.value !== 2 && I.cron.day !== "?" && A("update", "day", "?", "week"), g.value === 2 && I.cron.day === "?" && A("update", "day", "*", "week"), g.value) {
        case 1:
          A("update", "week", "*");
          break;
        case 2:
          A("update", "week", "?");
          break;
        case 3:
          A("update", "week", u.value);
          break;
        case 4:
          A("update", "week", o.value);
          break;
        case 5:
          A("update", "week", H.value + "L");
          break;
        case 6:
          A("update", "week", h.value);
          break;
      }
    }, V = () => {
      g.value === 3 && A("update", "week", u.value);
    }, X = () => {
      g.value === 4 && A("update", "week", o.value);
    }, L = () => {
      g.value === 5 && A("update", "week", d.value + "L");
    }, J = () => {
      g.value === 6 && A("update", "week", h.value);
    };
    return M(g, i), M(u, V), M(o, X), M(H, L), M(h, J), a({
      changeCycle01: (w) => {
        c.value = w;
      },
      changeCycle02: (w) => {
        Z.value = w;
      },
      changeAverage01: (w) => {
        G.value = w;
      },
      changeAverage02: (w) => {
        K.value = w;
      },
      changeCheckboxList: (w) => {
        b.value = w;
      },
      changeRadioValue: (w) => {
        g.value = w;
      },
      weekdayChange: L
    }), (w, r) => {
      const j = S("el-radio"), D = S("el-form-item"), B = S("el-option"), z = S("el-select"), te = S("el-input-number"), oe = S("el-form");
      return y(), U(oe, { "label-width": "auto" }, {
        default: n(() => [
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[0] || (r[0] = (Y) => g.value = Y),
                label: 1,
                disabled: e.readonly
              }, {
                default: n(() => r[12] || (r[12] = [
                  k(" 周，允许的通配符[, - * ? / L #] ")
                ])),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[1] || (r[1] = (Y) => g.value = Y),
                label: 2,
                disabled: e.readonly
              }, {
                default: n(() => r[13] || (r[13] = [
                  k(" 不指定 ")
                ])),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[4] || (r[4] = (Y) => g.value = Y),
                label: 3,
                disabled: e.readonly
              }, {
                default: n(() => [
                  r[14] || (r[14] = k(" 周期从星期 ")),
                  t(z, {
                    clearable: "",
                    modelValue: c.value,
                    "onUpdate:modelValue": r[2] || (r[2] = (Y) => c.value = Y),
                    disabled: e.readonly
                  }, {
                    default: n(() => [
                      (y(!0), N(T, null, $(s.value, (Y, ee) => (y(), U(B, {
                        key: ee,
                        label: Y.value,
                        value: Y.key,
                        disabled: Y.key === 1
                      }, {
                        default: n(() => [
                          k(P(Y.value), 1)
                        ]),
                        _: 2
                      }, 1032, ["label", "value", "disabled"]))), 128))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "disabled"]),
                  r[15] || (r[15] = k(" - ")),
                  t(z, {
                    clearable: "",
                    modelValue: Z.value,
                    "onUpdate:modelValue": r[3] || (r[3] = (Y) => Z.value = Y),
                    disabled: e.readonly
                  }, {
                    default: n(() => [
                      (y(!0), N(T, null, $(s.value, (Y, ee) => (y(), U(B, {
                        key: ee,
                        label: Y.value,
                        value: Y.key,
                        disabled: Y.key < c.value && Y.key !== 1
                      }, {
                        default: n(() => [
                          k(P(Y.value), 1)
                        ]),
                        _: 2
                      }, 1032, ["label", "value", "disabled"]))), 128))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "disabled"])
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[7] || (r[7] = (Y) => g.value = Y),
                label: 4
              }, {
                default: n(() => [
                  r[16] || (r[16] = k(" 第 ")),
                  t(te, {
                    modelValue: G.value,
                    "onUpdate:modelValue": r[5] || (r[5] = (Y) => G.value = Y),
                    min: 1,
                    max: 4,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "disabled"]),
                  r[17] || (r[17] = k(" 周的星期 ")),
                  t(z, {
                    clearable: "",
                    modelValue: K.value,
                    "onUpdate:modelValue": r[6] || (r[6] = (Y) => K.value = Y),
                    disabled: e.readonly
                  }, {
                    default: n(() => [
                      (y(!0), N(T, null, $(s.value, (Y, ee) => (y(), U(B, {
                        key: ee,
                        label: Y.value,
                        value: Y.key
                      }, {
                        default: n(() => [
                          k(P(Y.value), 1)
                        ]),
                        _: 2
                      }, 1032, ["label", "value"]))), 128))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "disabled"])
                ]),
                _: 1
              }, 8, ["modelValue"])
            ]),
            _: 1
          }),
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[9] || (r[9] = (Y) => g.value = Y),
                label: 5,
                disabled: e.readonly
              }, {
                default: n(() => [
                  r[18] || (r[18] = k(" 本月最后一个星期 ")),
                  t(z, {
                    clearable: "",
                    modelValue: d.value,
                    "onUpdate:modelValue": r[8] || (r[8] = (Y) => d.value = Y),
                    disabled: e.readonly
                  }, {
                    default: n(() => [
                      (y(!0), N(T, null, $(s.value, (Y, ee) => (y(), U(B, {
                        key: ee,
                        label: Y.value,
                        value: Y.key
                      }, {
                        default: n(() => [
                          k(P(Y.value), 1)
                        ]),
                        _: 2
                      }, 1032, ["label", "value"]))), 128))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "disabled"])
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(D, null, {
            default: n(() => [
              t(j, {
                modelValue: g.value,
                "onUpdate:modelValue": r[11] || (r[11] = (Y) => g.value = Y),
                label: 6,
                disabled: e.readonly
              }, {
                default: n(() => [
                  r[19] || (r[19] = k(" 指定 ")),
                  t(z, {
                    clearable: "",
                    modelValue: b.value,
                    "onUpdate:modelValue": r[10] || (r[10] = (Y) => b.value = Y),
                    placeholder: "可多选",
                    multiple: "",
                    style: { width: "192px" },
                    disabled: e.readonly
                  }, {
                    default: n(() => [
                      (y(!0), N(T, null, $(s.value, (Y, ee) => (y(), U(B, {
                        key: ee,
                        label: Y.value,
                        value: String(Y.key)
                      }, {
                        default: n(() => [
                          k(P(Y.value), 1)
                        ]),
                        _: 2
                      }, 1032, ["label", "value"]))), 128))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "disabled"])
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
}), yC = /* @__PURE__ */ q({
  __name: "year",
  props: {
    readonly: {
      type: Boolean,
      default: !1
    },
    check: {
      type: Function,
      required: !0
    }
  },
  emits: ["update"],
  setup(e, { expose: a, emit: l }) {
    const I = e, A = l, g = W(0), d = W(1), c = W((/* @__PURE__ */ new Date()).getFullYear()), Z = W(0), G = W(0), K = W(1), b = W([]), s = I.check, R = _(() => {
      const C = s(c.value, g.value, 2098), p = s(
        Z.value,
        C ? C + 1 : g.value + 1,
        2099
      );
      return C + "-" + p;
    }), u = _(() => {
      const C = s(G.value, g.value, 2098), p = s(
        K.value,
        1,
        2099 - C || g.value
      );
      return C + "/" + p;
    }), o = _(() => b.value.join()), H = () => {
      switch (d.value) {
        case 1:
          A("update", "year", "");
          break;
        case 2:
          A("update", "year", "*");
          break;
        case 3:
          A("update", "year", R.value);
          break;
        case 4:
          A("update", "year", u.value);
          break;
        case 5:
          A("update", "year", o.value);
          break;
      }
    }, h = () => {
      d.value === 3 && A("update", "year", R.value);
    }, i = () => {
      d.value === 4 && A("update", "year", u.value);
    }, V = () => {
      d.value === 5 && A("update", "year", o.value);
    };
    return M(d, H), M(R, h), M(u, i), M(o, V), pe(() => {
      g.value = Number((/* @__PURE__ */ new Date()).getFullYear()), c.value = g.value, G.value = g.value, b.value = [String(g.value)];
    }), a({
      changeCycle01: (C) => {
        c.value = C;
      },
      changeCycle02: (C) => {
        Z.value = C;
      },
      changeAverage01: (C) => {
        G.value = C;
      },
      changeAverage02: (C) => {
        K.value = C;
      },
      changeCheckboxList: (C) => {
        b.value = C;
      },
      changeRadioValue: (C) => {
        d.value = C;
      }
    }), (C, p) => {
      const F = S("el-radio"), w = S("el-form-item"), r = S("el-input-number"), j = S("el-option"), D = S("el-select"), B = S("el-form");
      return y(), U(B, { "label-width": "auto" }, {
        default: n(() => [
          t(w, null, {
            default: n(() => [
              t(F, {
                label: 1,
                modelValue: d.value,
                "onUpdate:modelValue": p[0] || (p[0] = (z) => d.value = z),
                disabled: e.readonly
              }, {
                default: n(() => p[10] || (p[10] = [
                  k(" 不填，允许的通配符[, - * /] ")
                ])),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(w, null, {
            default: n(() => [
              t(F, {
                label: 2,
                modelValue: d.value,
                "onUpdate:modelValue": p[1] || (p[1] = (z) => d.value = z),
                disabled: e.readonly
              }, {
                default: n(() => p[11] || (p[11] = [
                  k(" 每年 ")
                ])),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(w, null, {
            default: n(() => [
              t(F, {
                label: 3,
                modelValue: d.value,
                "onUpdate:modelValue": p[4] || (p[4] = (z) => d.value = z),
                disabled: e.readonly
              }, {
                default: n(() => [
                  p[12] || (p[12] = k(" 周期从 ")),
                  t(r, {
                    modelValue: c.value,
                    "onUpdate:modelValue": p[2] || (p[2] = (z) => c.value = z),
                    min: g.value,
                    max: 2098,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "min", "disabled"]),
                  p[13] || (p[13] = k(" - ")),
                  t(r, {
                    modelValue: Z.value,
                    "onUpdate:modelValue": p[3] || (p[3] = (z) => Z.value = z),
                    min: c.value ? c.value * 1 + 1 : g.value + 1,
                    max: 2099,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "min", "disabled"])
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(w, null, {
            default: n(() => [
              t(F, {
                label: 4,
                modelValue: d.value,
                "onUpdate:modelValue": p[7] || (p[7] = (z) => d.value = z),
                disabled: e.readonly
              }, {
                default: n(() => [
                  p[14] || (p[14] = k(" 从 ")),
                  t(r, {
                    modelValue: G.value,
                    "onUpdate:modelValue": p[5] || (p[5] = (z) => G.value = z),
                    min: g.value,
                    max: 2098,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "min", "disabled"]),
                  p[15] || (p[15] = k(" 年开始，每 ")),
                  t(r, {
                    modelValue: K.value,
                    "onUpdate:modelValue": p[6] || (p[6] = (z) => K.value = z),
                    min: 1,
                    max: 2099 - G.value || g.value,
                    disabled: e.readonly
                  }, null, 8, ["modelValue", "max", "disabled"]),
                  p[16] || (p[16] = k(" 年执行一次 "))
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          }),
          t(w, null, {
            default: n(() => [
              t(F, {
                label: 5,
                modelValue: d.value,
                "onUpdate:modelValue": p[9] || (p[9] = (z) => d.value = z),
                disabled: e.readonly
              }, {
                default: n(() => [
                  p[17] || (p[17] = k(" 指定 ")),
                  t(D, {
                    clearable: "",
                    modelValue: b.value,
                    "onUpdate:modelValue": p[8] || (p[8] = (z) => b.value = z),
                    placeholder: "可多选",
                    multiple: "",
                    style: { width: "192px" },
                    disabled: e.readonly
                  }, {
                    default: n(() => [
                      (y(), N(T, null, $(9, (z) => t(j, {
                        key: z,
                        value: String(z - 1 + g.value),
                        label: z - 1 + g.value
                      }, null, 8, ["value", "label"])), 64))
                    ]),
                    _: 1
                  }, 8, ["modelValue", "disabled"])
                ]),
                _: 1
              }, 8, ["modelValue", "disabled"])
            ]),
            _: 1
          })
        ]),
        _: 1
      });
    };
  }
}), GC = { class: "popup-result" }, vC = { class: "start-date" }, WC = { key: 1 }, hC = /* @__PURE__ */ q({
  __name: "result",
  props: {
    ex: {
      type: String,
      required: !0
    }
  },
  setup(e) {
    const a = W(""), l = W(""), I = W([]), A = W([]), g = W(!0), d = W(!0), c = W(/* @__PURE__ */ new Date()), Z = e, G = () => {
      d.value = !d.value;
    }, K = (C, p) => {
      if (p <= C[0] || p > C[C.length - 1])
        return 0;
      for (let F = 0; F < C.length - 1; F++)
        if (p > C[F] && p <= C[F + 1])
          return F + 1;
    }, b = (C, p) => {
      let F = [];
      for (let w = C; w <= p; w++)
        F.push(w);
      return F;
    }, s = (C) => {
      let p = [], F = C.split(",");
      for (let w = 0; w < F.length; w++)
        p[w] = Number(F[w]);
      return p.sort(L), p;
    }, R = (C, p) => {
      I.value[5] = b(p, p + 100), C !== void 0 && (C.indexOf("-") >= 0 ? I.value[5] = J(C, p + 100, !1) : C.indexOf("/") >= 0 ? I.value[5] = X(C, p + 100) : C !== "*" && (I.value[5] = s(C)));
    }, u = (C) => {
      I.value[4] = b(1, 12), C.indexOf("-") >= 0 ? I.value[4] = J(C, 12, !1) : C.indexOf("/") >= 0 ? I.value[4] = X(C, 12) : C !== "*" && (I.value[4] = s(C));
    }, o = (C) => {
      if (a.value == "" && l.value == "")
        if (C.indexOf("-") >= 0)
          a.value = "weekDay", l.value = J(C, 7, !1);
        else if (C.indexOf("#") >= 0) {
          a.value = "assWeek";
          let p = C.match(/[0-9]{1}/g);
          l.value = [Number(p[1]), Number(p[0])], I.value[3] = [1], l.value[1] == 7 && (l.value[1] = 0);
        } else C.indexOf("L") >= 0 ? (a.value = "lastWeek", l.value = Number(C.match(/[0-9]{1,2}/g)[0]), I.value[3] = [31], l.value == 7 && (l.value = 0)) : C !== "*" && C !== "?" && (a.value = "weekDay", l.value = s(C));
    }, H = (C) => {
      I.value[3] = b(1, 31), a.value = "", l.value = "", C.indexOf("-") >= 0 ? (I.value[3] = J(C, 31, !1), l.value = "null") : C.indexOf("/") >= 0 ? (I.value[3] = X(C, 31), l.value = "null") : C.indexOf("W") >= 0 ? (a.value = "workDay", l.value = Number(C.match(/[0-9]{1,2}/g)[0]), I.value[3] = [l.value]) : C.indexOf("L") >= 0 ? (a.value = "lastDay", l.value = "null", I.value[3] = [31]) : C !== "*" && C !== "?" ? (I.value[3] = s(C), l.value = "null") : C == "*" && (l.value = "null");
    }, h = (C) => {
      I.value[2] = b(0, 23), C.indexOf("-") >= 0 ? I.value[2] = J(C, 24, !0) : C.indexOf("/") >= 0 ? I.value[2] = X(C, 23) : C !== "*" && (I.value[2] = s(C));
    }, i = (C) => {
      I.value[1] = b(0, 59), C.indexOf("-") >= 0 ? I.value[1] = J(C, 60, !0) : C.indexOf("/") >= 0 ? I.value[1] = X(C, 59) : C !== "*" && (I.value[1] = s(C));
    }, V = (C) => {
      I.value[0] = b(0, 59), C.indexOf("-") >= 0 ? I.value[0] = J(C, 60, !0) : C.indexOf("/") >= 0 ? I.value[0] = X(C, 59) : C !== "*" && (I.value[0] = s(C));
    }, X = (C, p) => {
      let F = [], w = C.split("/"), r = Number(w[0]), j = Number(w[1]);
      for (; r <= p; )
        F.push(r), r += j;
      return F;
    }, L = (C, p) => p - C > 0 ? -1 : 1, J = (C, p, F) => {
      let w = [], r = C.split("-"), j = Number(r[0]), D = Number(r[1]);
      j > D && (D += p);
      for (let B = j; B <= D; B++) {
        let z = 0;
        F == !1 && B % p == 0 && (z = p), w.push(Math.round(B % p + z));
      }
      return w.sort(L), w;
    }, f = (C, p) => {
      let F = typeof C == "number" ? new Date(C) : C, w = F.getFullYear(), r = F.getMonth() + 1, j = F.getDate(), D = F.getHours(), B = F.getMinutes(), z = F.getSeconds(), te = F.getDay();
      if (p == null)
        return w + "-" + (r < 10 ? "0" + r : r) + "-" + (j < 10 ? "0" + j : j) + " " + (D < 10 ? "0" + D : D) + ":" + (B < 10 ? "0" + B : B) + ":" + (z < 10 ? "0" + z : z);
      if (p == "week")
        return te + 1;
    }, O = (C) => {
      let p = new Date(C), F = f(p);
      return C === F;
    }, m = () => {
      g.value = !1;
      let C = Z.ex.split(" "), p = 0, F = [], w = new Date(c.value), r = w.getFullYear(), j = w.getMonth() + 1, D = w.getDate(), B = w.getHours(), z = w.getMinutes(), te = w.getSeconds();
      V(C[0]), i(C[1]), h(C[2]), H(C[3]), u(C[4]), o(C[5]), R(C[6], r);
      let oe = I.value[0], Y = I.value[1], ee = I.value[2], ue = I.value[3], de = I.value[4], Fe = I.value[5], Ig = K(oe, te), Ue = K(Y, z), ze = K(ee, B), je = K(ue, D), De = K(de, j), rg = K(Fe, r);
      const Oe = function() {
        Ig = 0, te = oe[Ig];
      }, ke = function() {
        Ue = 0, z = Y[Ue], Oe();
      }, Ke = function() {
        ze = 0, B = ee[ze], ke();
      }, be = function() {
        je = 0, D = ue[je], Ke();
      }, ye = function() {
        De = 0, j = de[De], be();
      };
      r !== Fe[rg] && ye(), j !== de[De] && be(), D !== ue[je] && Ke(), B !== ee[ze] && ke(), z !== Y[Ue] && Oe();
      e: for (let lg = rg; lg < Fe.length; lg++) {
        let se = Fe[lg];
        if (j > de[de.length - 1]) {
          ye();
          continue;
        }
        g: for (let re = De; re < de.length; re++) {
          let le = de[re];
          if (le = le < 10 ? "0" + le : le, D > ue[ue.length - 1]) {
            if (be(), re == de.length - 1) {
              ye();
              continue e;
            }
            continue;
          }
          I: for (let Ge = je; Ge < ue.length; Ge++) {
            let Q = ue[Ge], ne = Q < 10 ? "0" + Q : Q;
            if (B > ee[ee.length - 1]) {
              if (Ke(), Ge == ue.length - 1) {
                if (be(), re == de.length - 1) {
                  ye();
                  continue e;
                }
                continue g;
              }
              continue;
            }
            if (O(se + "-" + le + "-" + ne + " 00:00:00") !== !0 && a.value !== "workDay" && a.value !== "lastWeek" && a.value !== "lastDay") {
              be();
              continue g;
            }
            if (a.value == "lastDay") {
              if (O(se + "-" + le + "-" + ne + " 00:00:00") !== !0)
                for (; Q > 0 && O(se + "-" + le + "-" + ne + " 00:00:00") !== !0; )
                  Q--, ne = Q < 10 ? "0" + Q : Q;
            } else if (a.value == "workDay") {
              if (O(se + "-" + le + "-" + ne + " 00:00:00") !== !0)
                for (; Q > 0 && O(se + "-" + le + "-" + ne + " 00:00:00") !== !0; )
                  Q--, ne = Q < 10 ? "0" + Q : Q;
              let ge = f(
                /* @__PURE__ */ new Date(se + "-" + le + "-" + ne + " 00:00:00"),
                "week"
              );
              ge == 1 ? (Q++, ne = Q < 10 ? "0" + Q : Q, O(se + "-" + le + "-" + ne + " 00:00:00") !== !0 && (Q -= 3)) : ge == 7 && (l.value !== 1 ? Q-- : Q += 2);
            } else if (a.value == "weekDay") {
              let ge = f(
                /* @__PURE__ */ new Date(se + "-" + le + "-" + Q + " 00:00:00"),
                "week"
              );
              if (l.value.indexOf(ge) < 0) {
                if (Ge == ue.length - 1) {
                  if (be(), re == de.length - 1) {
                    ye();
                    continue e;
                  }
                  continue g;
                }
                continue;
              }
            } else if (a.value == "assWeek") {
              let ge = f(
                /* @__PURE__ */ new Date(se + "-" + le + "-" + Q + " 00:00:00"),
                "week"
              );
              l.value[1] >= ge ? Q = (l.value[0] - 1) * 7 + l.value[1] - ge + 1 : Q = l.value[0] * 7 + l.value[1] - ge + 1;
            } else if (a.value == "lastWeek") {
              if (O(se + "-" + le + "-" + ne + " 00:00:00") !== !0)
                for (; Q > 0 && O(se + "-" + le + "-" + ne + " 00:00:00") !== !0; )
                  Q--, ne = Q < 10 ? "0" + Q : Q;
              let ge = f(
                /* @__PURE__ */ new Date(se + "-" + le + "-" + ne + " 00:00:00"),
                "week"
              );
              l.value < ge ? Q -= ge - l.value : l.value > ge && (Q -= 7 - (l.value - ge));
            }
            Q = Q < 10 ? "0" + Q : Q;
            l: for (let ge = ze; ge < ee.length; ge++) {
              let Qg = ee[ge] < 10 ? "0" + ee[ge] : ee[ge];
              if (z > Y[Y.length - 1]) {
                if (ke(), ge == ee.length - 1) {
                  if (Ke(), Ge == ue.length - 1) {
                    if (be(), re == de.length - 1) {
                      ye();
                      continue e;
                    }
                    continue g;
                  }
                  continue I;
                }
                continue;
              }
              C: for (let Ve = Ue; Ve < Y.length; Ve++) {
                let Pg = Y[Ve] < 10 ? "0" + Y[Ve] : Y[Ve];
                if (te > oe[oe.length - 1]) {
                  if (Oe(), Ve == Y.length - 1) {
                    if (ke(), ge == ee.length - 1) {
                      if (Ke(), Ge == ue.length - 1) {
                        if (be(), re == de.length - 1) {
                          ye();
                          continue e;
                        }
                        continue g;
                      }
                      continue I;
                    }
                    continue l;
                  }
                  continue;
                }
                for (let Se = Ig; Se <= oe.length - 1; Se++) {
                  let Eg = oe[Se] < 10 ? "0" + oe[Se] : oe[Se];
                  if (le !== "00" && Q !== "00" && (F.push(
                    se + "-" + le + "-" + Q + " " + Qg + ":" + Pg + ":" + Eg
                  ), p++), p == 5) break e;
                  if (Se == oe.length - 1) {
                    if (Oe(), Ve == Y.length - 1) {
                      if (ke(), ge == ee.length - 1) {
                        if (Ke(), Ge == ue.length - 1) {
                          if (be(), re == de.length - 1) {
                            ye();
                            continue e;
                          }
                          continue g;
                        }
                        continue I;
                      }
                      continue l;
                    }
                    continue C;
                  }
                }
              }
            }
          }
        }
      }
      F.length == 0 ? A.value = ["没有达到条件的结果！"] : (A.value = F, F.length !== 5 && A.value.push(
        "最近100年内只有上面" + F.length + "条结果！"
      )), g.value = !0;
    };
    return M(() => Z.ex, m), pe(() => {
      m();
    }), (C, p) => {
      const F = S("el-date-picker");
      return y(), N("div", GC, [
        x("p", {
          class: "title",
          onClick: G
        }, [
          p[1] || (p[1] = k(" 最近5次运行时间")),
          x("i", {
            class: Xe(d.value ? "el-icon-arrow-down" : "el-icon-arrow-right")
          }, null, 2)
        ]),
        x("div", vC, [
          p[2] || (p[2] = x("span", { class: "label" }, "初次运行时间", -1)),
          t(F, {
            type: "datetime",
            modelValue: c.value,
            "onUpdate:modelValue": p[0] || (p[0] = (w) => c.value = w),
            placeholder: "请选择初次运行时间",
            onChange: m
          }, null, 8, ["modelValue"])
        ]),
        x("ul", {
          class: "popup-result-scroll",
          style: me({ height: d.value ? "120px" : "0px" })
        }, [
          g.value ? (y(!0), N(T, { key: 0 }, $(A.value, (w) => (y(), N("li", { key: w }, P(w), 1))), 128)) : (y(), N("li", WC, "计算结果中..."))
        ], 4)
      ]);
    };
  }
}), VC = /* @__PURE__ */ Tg(hC, [["__scopeId", "data-v-f5855d83"]]), BC = { class: "hdl-cron" }, HC = { class: "popup-main" }, XC = /* @__PURE__ */ q({
  __name: "hdlCron",
  props: {
    tabVal: {
      // 当前选中的tab
      type: String,
      default: "hour"
    },
    modelValue: {
      // 表达式默认值
      type: String,
      default: "0 0 0/1 * * ?"
    },
    hideComponent: {
      // 需要隐藏的选项卡
      type: Array,
      default: () => []
    },
    readonly: {
      // 是否是只读模式
      type: Boolean,
      default: !1
    }
  },
  emits: ["update:tabVal", "hide", "fill", "update:modelValue"],
  setup(e, { emit: a }) {
    const l = e, I = a;
    W(["秒", "分钟", "小时", "日", "月", "周", "年"]);
    const A = Ie({
      second: "*",
      min: "*",
      hour: "*",
      day: "*",
      month: "*",
      week: "?",
      year: ""
    }), g = {
      cronsecond: W(null),
      cronmin: W(null),
      cronhour: W(null),
      cronday: W(null),
      cronmonth: W(null),
      cronweek: W(null),
      cronyear: W(null)
    }, d = _(() => A.second + " " + A.min + " " + A.hour + " " + A.day + " " + A.month + " " + A.week + (A.year == "" ? "" : " " + A.year)), c = (u) => !(l.hideComponent && l.hideComponent.includes(u)), Z = (u, o) => {
      let H = ["second", "min", "hour", "month"], h = "cron" + u, i;
      if (g[h].value) {
        if (H.includes(u))
          if (o === "*")
            i = 1;
          else if (o.indexOf("-") > -1) {
            let V = o.split("-");
            isNaN(Number(V[0])) ? g[h].value.changeCycle01(0) : g[h].value.changeCycle01(Number(V[0])), g[h].value.changeCycle02(Number(V[1])), i = 2;
          } else if (o.indexOf("/") > -1) {
            let V = o.split("/");
            isNaN(Number(V[0])) ? g[h].value.changeAverage01(0) : g[h].value.changeAverage01(Number(V[0])), g[h].value.changeAverage02(Number(V[1])), i = 3;
          } else
            i = 4, g[h].value.changeCheckboxList(o.split(","));
        else if (u == "day")
          if (o === "*")
            i = 1;
          else if (o == "?")
            i = 2;
          else if (o.indexOf("-") > -1) {
            let V = o.split("-");
            isNaN(Number(V[0])) ? g[h].value.changeCycle01(0) : g[h].value.changeCycle01(Number(V[0])), g[h].value.changeCycle02(Number(V[1])), i = 3;
          } else if (o.indexOf("/") > -1) {
            let V = o.split("/");
            isNaN(Number(V[0])) ? g[h].value.changeAverage01(0) : g[h].value.changeAverage01(Number(V[0])), g[h].value.changeAverage02(Number(V[1])), i = 4;
          } else if (o.indexOf("W") > -1) {
            let V = o.split("W");
            isNaN(Number(V[0])) ? g[h].value.changeWorkday(0) : g[h].value.changeWorkday(Number(V[0])), i = 5;
          } else o === "L" ? i = 6 : (g[h].value.changeCheckboxList(o.split(",")), i = 7);
        else if (u == "week")
          if (o === "*")
            i = 1;
          else if (o == "?")
            i = 2;
          else if (o.indexOf("-") > -1) {
            let V = o.split("-");
            isNaN(Number(V[0])) ? g[h].value.changeCycle01(0) : g[h].value.changeCycle01(Number(V[0])), g[h].value.changeCycle02(Number(V[1])), i = 3;
          } else if (o.indexOf("#") > -1) {
            let V = o.split("#");
            isNaN(Number(V[0])) ? g[h].value.changeAverage01(1) : g[h].value.changeAverage01(Number(V[0])), g[h].value.changeAverage02(Number(V[1])), i = 4;
          } else if (o.indexOf("L") > -1) {
            let V = o.split("L");
            isNaN(Number(V[0])) ? g[h].value.weekdayChange(1) : g[h].value.weekdayChange(Number(V[0])), i = 5;
          } else
            g[h].value.changeCheckboxList(o.split(",")), i = 6;
        else u == "year" && (o == "" ? i = 1 : o == "*" ? i = 2 : o.indexOf("-") > -1 ? i = 3 : o.indexOf("/") > -1 ? i = 4 : (g[h].value.changeCheckboxList(o.split(",")), i = 5));
        g[h].value.changeRadioValue(i);
      }
    }, G = () => {
      Object.assign(A, {
        second: "*",
        min: "*",
        hour: "*",
        day: "*",
        month: "*",
        week: "?",
        year: ""
      });
      for (let u in A) {
        const o = u;
        Z(o, A[o]);
      }
    }, K = () => {
      if (l.modelValue) {
        let u = l.modelValue.split(" ");
        if (u.length >= 6) {
          Object.assign(A, {
            second: u[0],
            min: u[1],
            hour: u[2],
            day: u[3],
            month: u[4],
            week: u[5],
            year: u[6] ? u[6] : ""
          });
          for (let o in A) {
            const H = o;
            A[H] && Z(H, A[H]);
          }
        }
      } else
        G();
    }, b = (u) => {
      I("update:tabVal", u);
    }, s = (u, o, H) => {
      A[u] = o, H && H !== u && Z(u, o);
    }, R = (u, o, H) => (u = Math.floor(u), u < o ? u = o : u > H && (u = H), u);
    return M(d, (u) => {
      I("update:modelValue", u);
    }), M(() => l.modelValue, (u) => {
      u && K();
    }), pe(() => {
      l.modelValue || I("update:modelValue", "0 0 0/1 * * ?"), K();
    }), (u, o) => {
      const H = S("el-tab-pane"), h = S("el-tabs");
      return S("el-button"), y(), N("div", BC, [
        t(h, {
          type: "border-card",
          "model-value": e.tabVal,
          onTabClick: b
        }, {
          default: n(() => [
            c("second") ? (y(), U(H, {
              key: 0,
              label: "秒",
              name: "second"
            }, {
              default: n(() => [
                t(iC, {
                  onUpdate: s,
                  check: R,
                  cron: A,
                  ref: g.cronsecond,
                  readonly: e.readonly
                }, null, 8, ["cron", "readonly"])
              ]),
              _: 1
            })) : E("", !0),
            c("min") ? (y(), U(H, {
              key: 1,
              label: "分钟",
              name: "min"
            }, {
              default: n(() => [
                t(mC, {
                  onUpdate: s,
                  check: R,
                  cron: A,
                  ref: g.cronmin,
                  readonly: e.readonly
                }, null, 8, ["cron", "readonly"])
              ]),
              _: 1
            })) : E("", !0),
            c("hour") ? (y(), U(H, {
              key: 2,
              label: "小时",
              name: "hour"
            }, {
              default: n(() => [
                t(bC, {
                  onUpdate: s,
                  check: R,
                  cron: A,
                  ref: g.cronhour,
                  readonly: e.readonly
                }, null, 8, ["cron", "readonly"])
              ]),
              _: 1
            })) : E("", !0),
            c("day") ? (y(), U(H, {
              key: 3,
              label: "日",
              name: "day"
            }, {
              default: n(() => [
                t(rC, {
                  onUpdate: s,
                  check: R,
                  cron: A,
                  ref: g.cronday,
                  readonly: e.readonly
                }, null, 8, ["cron", "readonly"])
              ]),
              _: 1
            })) : E("", !0),
            c("month") ? (y(), U(H, {
              key: 4,
              label: "月",
              name: "month"
            }, {
              default: n(() => [
                t(ZC, {
                  onUpdate: s,
                  check: R,
                  cron: A,
                  ref: g.cronmonth,
                  readonly: e.readonly
                }, null, 8, ["cron", "readonly"])
              ]),
              _: 1
            })) : E("", !0),
            c("week") ? (y(), U(H, {
              key: 5,
              label: "周",
              name: "week"
            }, {
              default: n(() => [
                t(pC, {
                  ref: g.cronweek,
                  check: R,
                  cron: A,
                  readonly: e.readonly,
                  onUpdate: s
                }, null, 8, ["cron", "readonly"])
              ]),
              _: 1
            })) : E("", !0),
            c("year") ? (y(), U(H, {
              key: 6,
              label: "年",
              name: "year"
            }, {
              default: n(() => [
                t(yC, {
                  onUpdate: s,
                  check: R,
                  cron: A,
                  ref: g.cronyear,
                  readonly: e.readonly
                }, null, 8, ["cron", "readonly"])
              ]),
              _: 1
            })) : E("", !0)
          ]),
          _: 1
        }, 8, ["model-value"]),
        x("div", HC, [
          E("", !0),
          t(VC, { ex: d.value }, null, 8, ["ex"]),
          E("", !0)
        ])
      ]);
    };
  }
}), KC = {
  key: 0,
  class: "pageSize"
}, SC = /* @__PURE__ */ q({
  inheritAttrs: !1,
  __name: "hdlTable",
  props: {
    isPopup: {
      // 是否是弹窗中的表格
      type: Boolean,
      default: !1
    },
    auth: {
      // 需要对列进行权限控制时 此参数必填
      type: String,
      default: ""
    },
    columns: {
      // 表格列配置
      type: Array,
      required: !0
    },
    data: {
      // 表格数据源
      type: Array,
      required: !0
    }
  },
  emits: ["rowSort"],
  setup(e, { expose: a, emit: l }) {
    const I = e, A = l, g = gI(), d = Ie({
      // 表格默认配置
      elementLoadingText: "正在加载中...",
      // 表格加载时的提示文字
      elementLoadingSpinner: "el-icon-loading",
      // 表格加载时的icon
      highlightCurrentRow: !0,
      // 高亮显示行
      emptyText: "暂无数据",
      // 没有数据时的提示文字
      height: g.pagination ? "calc(100% - 29px)" : "100%",
      // 表格高度
      border: !0,
      size: "small"
    }), c = Ie({
      // 表格列默认配置
      align: "center",
      // 对齐方式
      showOverflowTooltip: !0
      // 文字超出显示省略号
    }), Z = Ie({
      // 默认的分页属性
      size: "small",
      // 小型分页
      pageSizes: I.isPopup ? Be.popupPageSizes.value : Be.pageSizes.value,
      // 分页页数 根据是否是弹窗中的来区分
      layout: "total, sizes, prev, pager, next, jumper",
      // 分页布局
      background: !0,
      // 是否为分页增加背景色
      pagerCount: 5
      // 分页按钮数量
    }), G = he("hdlTableRef"), K = Ie({}), b = _(() => I.isPopup ? g.pagination ? "hdl-table-popup" : "hdl-table-popup-no-page" : ""), s = cg(null), R = W([]), u = Ie({}), o = () => {
      const V = G.value.$el.querySelector(".el-table__body tbody");
      s.value = new pI(V, {
        group: "move-col",
        handle: ".move-col",
        // 只有是类名为move-col的才能拖
        onEnd(X) {
          const L = X.newIndex, J = X.oldIndex;
          if (L === J)
            return;
          const f = I.data[J], O = I.data[L], m = [], C = J > L ? "up" : "down", p = C === "up" ? L : J, F = C === "up" ? J : L;
          for (let w = p; w <= F; w++)
            m.push(I.data[w]);
          m[C === "up" ? "unshift" : "push"](...m.splice(J - p, 1)), A("rowSort", {
            dragCol: f,
            targetCol: O,
            oldIndex: J,
            newIndex: L,
            effectData: m
          });
        }
      });
    };
    (async () => {
      var V;
      const i = await mg();
      R.value = ((V = i.find((X) => X.code === I.auth)) == null ? void 0 : V.listConfigList) ?? [];
    })();
    const h = _(() => (i) => {
      var L;
      const V = (L = R.value) == null ? void 0 : L.find((J) => J.code === i.auth);
      if (!V)
        return !0;
      const X = V.prop;
      if (!X.auth || i.onlyAuth && !X.onlyAuth)
        return !1;
      u[i.auth] = {};
      for (const J in X)
        ["auth", "onlyAuth"].includes(J) || (u[i.auth][J] = X[J]);
      return !0;
    });
    return pe(() => {
      K.clearSelection = G.value.clearSelection, K.getSelectionRows = G.value.getSelectionRows, K.toggleRowSelection = G.value.toggleRowSelection, K.toggleAllSelection = G.value.toggleAllSelection, K.toggleRowExpansion = G.value.toggleRowExpansion, K.setCurrentRow = G.value.setCurrentRow, K.clearSort = G.value.clearSort, K.clearFilter = G.value.clearFilter, K.doLayout = G.value.doLayout, K.sort = G.value.sort, K.scrollTo = G.value.scrollTo, K.setScrollLeft = G.value.setScrollLeft, K.setScrollTop = G.value.setScrollTop, o();
    }), eg(() => {
      var i;
      (i = s.value) == null || i.destroy();
    }), a(K), (i, V) => {
      const X = S("el-table-column"), L = S("el-table");
      return y(), N("div", {
        class: Xe(["hdl-table full-box", v(b)])
      }, [
        t(L, ae({ ref: "hdlTableRef" }, { ...v(d), ...i.$attrs }, { data: e.data }), {
          default: n(() => [
            i.$slots.expand ? we(i.$slots, "expand", { key: 0 }) : E("", !0),
            (y(!0), N(T, null, $(e.columns, (J) => (y(), N(T, {
              key: J.prop
            }, [
              !Object.prototype.hasOwnProperty.call(J, "show") || J.show ? (y(), N(T, { key: 0 }, [
                J.slot ? (y(), N(T, { key: 0 }, [
                  v(h)(J) ? we(i.$slots, J.prop, {
                    key: 0,
                    colData: { ...v(c), ...J, ...J.auth ? v(u)[J.auth] : {} }
                  }) : E("", !0)
                ], 64)) : (y(), N(T, { key: 1 }, [
                  J.type === "move" ? (y(), U(X, ae({
                    key: 0,
                    ref_for: !0
                  }, { ...v(c), width: 40, showOverflowTooltip: !1 }, { "class-name": "move-col" }), {
                    header: n(() => [
                      t(v(Wg))
                    ]),
                    default: n(() => [
                      t(v(Wg))
                    ]),
                    _: 1
                  }, 16)) : v(h)(J) ? (y(), U(X, ae({
                    key: 1,
                    ref_for: !0
                  }, { ...v(c), ...J, ...J.auth ? v(u)[J.auth] : {} }), null, 16)) : E("", !0)
                ], 64))
              ], 64)) : E("", !0)
            ], 64))), 128))
          ]),
          _: 3
        }, 16, ["data"]),
        i.$slots.pagination ? (y(), N("div", KC, [
          we(i.$slots, "pagination", Kg(Sg(v(Z))))
        ])) : E("", !0)
      ], 2);
    };
  }
}), RC = {
  key: 0,
  class: "hdl-form"
}, wC = /* @__PURE__ */ q({
  __name: "hdlForm",
  props: {
    model: {
      // 绑定的表单数据源
      type: Object,
      required: !0
    },
    rules: {
      // 验证规则
      type: Object
    },
    inline: {
      // 是否行内表单模式
      type: Boolean,
      default: !1
    },
    labelPosition: {
      // 表单域标签的位置， 当设置为 left 或 right 时，则也需要设置 label-width 属性
      type: String,
      default: "right"
    },
    labelWidth: {
      // 标签的长度，例如 '50px'。 作为 Form 直接子元素的 form-item 会继承该值。 可以使用 auto。
      type: String,
      default: Jg.labelWidth.value
    },
    labelSuffix: {
      // 表单域标签的后缀
      type: String,
      default: ""
    },
    hideRequiredAsterisk: {
      // 是否隐藏必填字段标签旁边的红色星号。
      type: Boolean,
      default: !1
    },
    requireAsteriskPosition: {
      // 星号的位置。
      type: String,
      default: "left"
    },
    showMessage: {
      // 是否显示校验错误信息
      type: Boolean,
      default: !0
    },
    inlineMessage: {
      // 是否以行内形式展示校验信息
      type: Boolean,
      default: !1
    },
    statusIcon: {
      // 是否在输入框中显示校验结果反馈图标
      type: Boolean,
      default: !1
    },
    validateOnRuleChange: {
      // 是否在 rules 属性改变后立即触发一次验证
      type: Boolean,
      default: !0
    },
    size: {
      // 用于控制该表单内组件的尺寸
      type: String,
      default: "default"
    },
    disabled: {
      // 是否禁用该表单内的所有组件。 如果设置为 true, 它将覆盖内部组件的 disabled 属性
      type: Boolean,
      default: !1
    },
    scrollToError: {
      // 当校验失败时，滚动到第一个错误表单项	
      type: Boolean,
      default: !1
    },
    scrollIntoViewOptions: {
      // 当校验有失败结果时，滚动到第一个失败的表单项目 可通过 scrollIntoView 配置
      type: Object
    }
  },
  emits: ["validate"],
  setup(e, { expose: a, emit: l }) {
    const I = e, A = l, g = he("elFormRef"), d = W(!1);
    (async () => {
      await mg(), d.value = !0;
    })();
    const Z = (u, o, H) => {
      A("validate", u, o, H);
    };
    return a({
      validate: (u) => {
        if (u && typeof u == "function")
          g.value.validate(u);
        else
          return g.value.validate();
      },
      validateField: (u, o) => g.value.validateField(u, o),
      resetFields: (u) => g.value.resetFields(u),
      scrollToField: (u) => {
        g.value.scrollToField(u);
      },
      clearValidate: (u) => {
        g.value.clearValidate(u);
      }
    }), (u, o) => {
      const H = S("el-form");
      return v(d) ? (y(), N("div", RC, [
        t(H, ae({ ref: "elFormRef" }, I, { onValidate: Z }), {
          default: n(() => [
            we(u.$slots, "default")
          ]),
          _: 3
        }, 16)
      ])) : E("", !0);
    };
  }
}), fC = {
  key: 0,
  class: "hdl-filter"
}, YC = /* @__PURE__ */ q({
  inheritAttrs: !1,
  __name: "hdlTree",
  props: {
    showFilter: {
      // 是否显示筛选框
      type: Boolean,
      default: !0
    },
    inputProps: {
      // 筛选框的配置属性
      type: Object,
      default: () => ({})
    },
    treeWidth: {
      // 树宽度
      type: String,
      default: ""
    },
    nodeKey: {
      // 树节点唯一标识
      type: String,
      required: !0
    }
  },
  emits: ["currentChange", "check"],
  setup(e, { expose: a, emit: l }) {
    const I = e, A = l, g = II(), d = Ie({
      // 树默认字段修改
      highlightCurrent: !0,
      props: {
        label: "name",
        children: "childs"
      }
    }), c = Ie({
      // 设置初始的树宽度
      width: I.treeWidth || `${Re.width.value}px`
    }), Z = W(""), G = Ie({
      // 筛选框默认配置项
      placeholder: "请输入搜索值",
      clearable: !0
    }), K = Ie({
      // 树高度
      height: `calc(100% - ${I.showFilter ? 44 : 0}px)`
    }), b = he("hdlTreeRef"), s = Ie({}), R = (V, X) => {
      var J;
      if (!V)
        return !0;
      const L = ((J = g.props) == null ? void 0 : J.label) ?? d.props.label;
      return X[L].includes(V);
    }, u = Ze(() => {
      b.value.filter(Z.value);
    }, {
      isImmediate: !1
    }), o = (V, X) => {
      A("currentChange", V, X);
    }, H = (V, X) => {
      var J;
      b.value.setChecked(V[I.nodeKey], X, !0);
      const L = ((J = g == null ? void 0 : g.props) == null ? void 0 : J.children) ?? d.props.children;
      if (V[L] && V[L].length)
        for (let f = 0; f < V[L].length; f++)
          H(V[L][f], X);
    }, h = (V) => {
      const X = b.value.getNode(V);
      X.parent.key && (b.value.setChecked(X.parent, !0, !0), h(X.parent));
    }, i = (V, X) => {
      var f;
      const L = X.checkedKeys.indexOf(V[I.nodeKey]), J = ((f = g == null ? void 0 : g.props) == null ? void 0 : f.children) ?? d.props.children;
      if (L !== -1) {
        h(V), H(V, !0);
        return;
      }
      V[J] && V[J].length && H(V, !1), A("check", V, X);
    };
    return pe(() => {
      s.filter = b.value.filter, s.updateKeyChildren = b.value.updateKeyChildren, s.getCheckedNodes = b.value.getCheckedNodes, s.setCheckedNodes = b.value.setCheckedNodes, s.getCheckedKeys = b.value.getCheckedKeys, s.setCheckedKeys = b.value.setCheckedKeys, s.setChecked = b.value.setChecked, s.getHalfCheckedNodes = b.value.getHalfCheckedNodes, s.getHalfCheckedKeys = b.value.getHalfCheckedKeys, s.getCurrentKey = b.value.getCurrentKey, s.getCurrentNode = b.value.getCurrentNode, s.setCurrentKey = b.value.setCurrentKey, s.setCurrentNode = b.value.setCurrentNode, s.getNode = b.value.getNode, s.remove = b.value.remove, s.append = b.value.append, s.insertBefore = b.value.insertBefore, s.insertAfter = b.value.insertAfter;
    }), a(s), (V, X) => {
      const L = S("el-input"), J = S("el-tree"), f = S("el-scrollbar");
      return y(), N("div", {
        class: "hdl-tree",
        style: me(v(c))
      }, [
        e.showFilter ? (y(), N("div", fC, [
          t(L, ae({ ...v(G), ...e.inputProps }, {
            modelValue: v(Z),
            "onUpdate:modelValue": X[0] || (X[0] = (O) => fe(Z) ? Z.value = O : null),
            "prefix-icon": v(fg),
            onInput: v(u)
          }), null, 16, ["modelValue", "prefix-icon", "onInput"])
        ])) : E("", !0),
        t(f, {
          class: "hdl-tree-main",
          style: me(v(K))
        }, {
          default: n(() => [
            t(J, ae({ ref: "hdlTreeRef" }, { ...v(d), ...v(g) }, {
              "node-key": e.nodeKey,
              "filter-node-method": R,
              onCurrentChange: o,
              onCheck: i
            }), null, 16, ["node-key"])
          ]),
          _: 1
        }, 8, ["style"])
      ], 4);
    };
  }
}), kC = { class: "dialog-content" }, JC = { class: "el-upload__tip" }, NC = /* @__PURE__ */ q({
  __name: "hdlFileImport",
  props: {
    modelValue: {
      // 弹窗状态
      type: Boolean,
      required: !0
    },
    url: {
      // 上传地址
      type: String,
      required: !0
    },
    limit: {
      // 上传文件个数限制
      type: Number,
      default: void 0
    },
    maxSize: {
      // 上传文件大小限制
      type: Number,
      default: 10
    },
    headersParams: {
      // 上传文件头部参数
      type: Object,
      default: () => ({})
    },
    data: {
      // 上传文件额外参数
      type: Object,
      default: () => ({})
    },
    accept: {
      // 上传文件类型
      type: String,
      default: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
    },
    fileTypeStr: {
      // 上传文件类型描述
      type: String,
      default: ".xls/.xlsx"
    }
  },
  emits: ["update:model-value", "refresh"],
  setup(e, { emit: a }) {
    const l = e, I = a, A = W([]), g = he("uploadRef"), d = W({
      Authorization: "Bearer " + window.localStorage.getItem("HDL_TOKEN"),
      ...l.headersParams
    }), c = () => {
      l.modelValue && I("update:model-value", !l.modelValue);
    }, Z = () => {
      var u;
      (u = g.value) == null || u.submit();
    }, G = () => {
      A.value = [];
    }, K = (u) => {
      g.value.clearFiles();
      const o = u[0];
      o.uid = qg(), g.value.handleStart(o);
    }, b = (u) => {
      const o = l.maxSize * 1024 * 1024;
      if (u.size && u.size > o)
        return Ae.warning("文件大小不能超过10M！"), !1;
    }, s = (u, o) => {
      A.value = o;
    }, R = (u, o) => {
      A.value = o, u.response && ([0, "0", "0000"].includes(u.response.resCode) ? (Ae.success("上传成功"), c(), I("refresh")) : (Ae.error(u.response.errorMessage), A.value = []));
    };
    return (u, o) => {
      const H = S("el-icon"), h = S("el-upload"), i = S("el-button"), V = S("el-dialog");
      return y(), U(V, ae({ "model-value": e.modelValue }, v(Ye).dialogAttr, {
        class: "small-dialog",
        title: "文件上传",
        "onUpdate:modelValue": c,
        onClose: G
      }), {
        footer: n(() => [
          t(i, {
            type: "info",
            onClick: c
          }, {
            default: n(() => o[1] || (o[1] = [
              k("取消")
            ])),
            _: 1
          }),
          t(i, {
            type: "primary",
            onClick: Z
          }, {
            default: n(() => o[2] || (o[2] = [
              k("上传")
            ])),
            _: 1
          })
        ]),
        default: n(() => [
          x("div", kC, [
            t(h, {
              ref: "uploadRef",
              drag: "",
              action: e.url,
              accept: e.accept,
              headers: v(d),
              data: e.data,
              "auto-upload": !1,
              limit: e.limit,
              "file-list": v(A),
              "on-exceed": K,
              "before-upload": b,
              "on-remove": s,
              "on-change": R
            }, {
              tip: n(() => [
                x("div", JC, " 仅支持 " + P(e.fileTypeStr) + " 格式文件 ", 1)
              ]),
              default: n(() => [
                t(H, { class: "el-icon--upload" }, {
                  default: n(() => [
                    t(v(mI))
                  ]),
                  _: 1
                }),
                o[0] || (o[0] = x("div", { class: "el-upload__text" }, [
                  k(" 拖拽文件到这里或 "),
                  x("em", null, "点击上传")
                ], -1))
              ]),
              _: 1
            }, 8, ["action", "accept", "headers", "data", "limit", "file-list"])
          ])
        ]),
        _: 1
      }, 16, ["model-value"]);
    };
  }
}), xC = "data:text/javascript;base64,YWNlLmRlZmluZSgiYWNlL21vZGUvanNvbl9oaWdobGlnaHRfcnVsZXMiLFsicmVxdWlyZSIsImV4cG9ydHMiLCJtb2R1bGUiLCJhY2UvbGliL29vcCIsImFjZS9tb2RlL3RleHRfaGlnaGxpZ2h0X3J1bGVzIl0sIGZ1bmN0aW9uKHJlcXVpcmUsIGV4cG9ydHMsIG1vZHVsZSl7InVzZSBzdHJpY3QiOwp2YXIgb29wID0gcmVxdWlyZSgiLi4vbGliL29vcCIpOwp2YXIgVGV4dEhpZ2hsaWdodFJ1bGVzID0gcmVxdWlyZSgiLi90ZXh0X2hpZ2hsaWdodF9ydWxlcyIpLlRleHRIaWdobGlnaHRSdWxlczsKdmFyIEpzb25IaWdobGlnaHRSdWxlcyA9IGZ1bmN0aW9uICgpIHsKICAgIHRoaXMuJHJ1bGVzID0gewogICAgICAgICJzdGFydCI6IFsKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgdG9rZW46ICJ2YXJpYWJsZSIsIC8vIHNpbmdsZSBsaW5lCiAgICAgICAgICAgICAgICByZWdleDogJ1siXSg/Oig/OlxcXFwuKXwoPzpbXiJcXFxcXSkpKj9bIl1cXHMqKD89OiknCiAgICAgICAgICAgIH0sIHsKICAgICAgICAgICAgICAgIHRva2VuOiAic3RyaW5nIiwgLy8gc2luZ2xlIGxpbmUKICAgICAgICAgICAgICAgIHJlZ2V4OiAnIicsCiAgICAgICAgICAgICAgICBuZXh0OiAic3RyaW5nIgogICAgICAgICAgICB9LCB7CiAgICAgICAgICAgICAgICB0b2tlbjogImNvbnN0YW50Lm51bWVyaWMiLCAvLyBoZXgKICAgICAgICAgICAgICAgIHJlZ2V4OiAiMFt4WF1bMC05YS1mQS1GXStcXGIiCiAgICAgICAgICAgIH0sIHsKICAgICAgICAgICAgICAgIHRva2VuOiAiY29uc3RhbnQubnVtZXJpYyIsIC8vIGZsb2F0CiAgICAgICAgICAgICAgICByZWdleDogIlsrLV0/XFxkKyg/Oig/OlxcLlxcZCopPyg/OltlRV1bKy1dP1xcZCspPyk/XFxiIgogICAgICAgICAgICB9LCB7CiAgICAgICAgICAgICAgICB0b2tlbjogImNvbnN0YW50Lmxhbmd1YWdlLmJvb2xlYW4iLAogICAgICAgICAgICAgICAgcmVnZXg6ICIoPzp0cnVlfGZhbHNlKVxcYiIKICAgICAgICAgICAgfSwgewogICAgICAgICAgICAgICAgdG9rZW46ICJ0ZXh0IiwgLy8gc2luZ2xlIHF1b3RlZCBzdHJpbmdzIGFyZSBub3QgYWxsb3dlZAogICAgICAgICAgICAgICAgcmVnZXg6ICJbJ10oPzooPzpcXFxcLil8KD86W14nXFxcXF0pKSo/WyddIgogICAgICAgICAgICB9LCB7CiAgICAgICAgICAgICAgICB0b2tlbjogImNvbW1lbnQiLCAvLyBjb21tZW50cyBhcmUgbm90IGFsbG93ZWQsIGJ1dCB3aG8gY2FyZXM/CiAgICAgICAgICAgICAgICByZWdleDogIlxcL1xcLy4qJCIKICAgICAgICAgICAgfSwgewogICAgICAgICAgICAgICAgdG9rZW46ICJjb21tZW50LnN0YXJ0IiwgLy8gY29tbWVudHMgYXJlIG5vdCBhbGxvd2VkLCBidXQgd2hvIGNhcmVzPwogICAgICAgICAgICAgICAgcmVnZXg6ICJcXC9cXCoiLAogICAgICAgICAgICAgICAgbmV4dDogImNvbW1lbnQiCiAgICAgICAgICAgIH0sIHsKICAgICAgICAgICAgICAgIHRva2VuOiAicGFyZW4ubHBhcmVuIiwKICAgICAgICAgICAgICAgIHJlZ2V4OiAiW1soe10iCiAgICAgICAgICAgIH0sIHsKICAgICAgICAgICAgICAgIHRva2VuOiAicGFyZW4ucnBhcmVuIiwKICAgICAgICAgICAgICAgIHJlZ2V4OiAiW1xcXSl9XSIKICAgICAgICAgICAgfSwgewogICAgICAgICAgICAgICAgdG9rZW46ICJwdW5jdHVhdGlvbi5vcGVyYXRvciIsCiAgICAgICAgICAgICAgICByZWdleDogL1ssXS8KICAgICAgICAgICAgfSwgewogICAgICAgICAgICAgICAgdG9rZW46ICJ0ZXh0IiwKICAgICAgICAgICAgICAgIHJlZ2V4OiAiXFxzKyIKICAgICAgICAgICAgfQogICAgICAgIF0sCiAgICAgICAgInN0cmluZyI6IFsKICAgICAgICAgICAgewogICAgICAgICAgICAgICAgdG9rZW46ICJjb25zdGFudC5sYW5ndWFnZS5lc2NhcGUiLAogICAgICAgICAgICAgICAgcmVnZXg6IC9cXCg/OnhbMC05YS1mQS1GXXsyfXx1WzAtOWEtZkEtRl17NH18WyJcXFwvYmZucnRdKS8KICAgICAgICAgICAgfSwgewogICAgICAgICAgICAgICAgdG9rZW46ICJzdHJpbmciLAogICAgICAgICAgICAgICAgcmVnZXg6ICcifCQnLAogICAgICAgICAgICAgICAgbmV4dDogInN0YXJ0IgogICAgICAgICAgICB9LCB7CiAgICAgICAgICAgICAgICBkZWZhdWx0VG9rZW46ICJzdHJpbmciCiAgICAgICAgICAgIH0KICAgICAgICBdLAogICAgICAgICJjb21tZW50IjogWwogICAgICAgICAgICB7CiAgICAgICAgICAgICAgICB0b2tlbjogImNvbW1lbnQuZW5kIiwgLy8gY29tbWVudHMgYXJlIG5vdCBhbGxvd2VkLCBidXQgd2hvIGNhcmVzPwogICAgICAgICAgICAgICAgcmVnZXg6ICJcXCpcXC8iLAogICAgICAgICAgICAgICAgbmV4dDogInN0YXJ0IgogICAgICAgICAgICB9LCB7CiAgICAgICAgICAgICAgICBkZWZhdWx0VG9rZW46ICJjb21tZW50IgogICAgICAgICAgICB9CiAgICAgICAgXQogICAgfTsKfTsKb29wLmluaGVyaXRzKEpzb25IaWdobGlnaHRSdWxlcywgVGV4dEhpZ2hsaWdodFJ1bGVzKTsKZXhwb3J0cy5Kc29uSGlnaGxpZ2h0UnVsZXMgPSBKc29uSGlnaGxpZ2h0UnVsZXM7Cgp9KTsKCmFjZS5kZWZpbmUoImFjZS9tb2RlL21hdGNoaW5nX2JyYWNlX291dGRlbnQiLFsicmVxdWlyZSIsImV4cG9ydHMiLCJtb2R1bGUiLCJhY2UvcmFuZ2UiXSwgZnVuY3Rpb24ocmVxdWlyZSwgZXhwb3J0cywgbW9kdWxlKXsidXNlIHN0cmljdCI7CnZhciBSYW5nZSA9IHJlcXVpcmUoIi4uL3JhbmdlIikuUmFuZ2U7CnZhciBNYXRjaGluZ0JyYWNlT3V0ZGVudCA9IGZ1bmN0aW9uICgpIHsgfTsKKGZ1bmN0aW9uICgpIHsKICAgIHRoaXMuY2hlY2tPdXRkZW50ID0gZnVuY3Rpb24gKGxpbmUsIGlucHV0KSB7CiAgICAgICAgaWYgKCEvXlxzKyQvLnRlc3QobGluZSkpCiAgICAgICAgICAgIHJldHVybiBmYWxzZTsKICAgICAgICByZXR1cm4gL15ccypcfS8udGVzdChpbnB1dCk7CiAgICB9OwogICAgdGhpcy5hdXRvT3V0ZGVudCA9IGZ1bmN0aW9uIChkb2MsIHJvdykgewogICAgICAgIHZhciBsaW5lID0gZG9jLmdldExpbmUocm93KTsKICAgICAgICB2YXIgbWF0Y2ggPSBsaW5lLm1hdGNoKC9eKFxzKlx9KS8pOwogICAgICAgIGlmICghbWF0Y2gpCiAgICAgICAgICAgIHJldHVybiAwOwogICAgICAgIHZhciBjb2x1bW4gPSBtYXRjaFsxXS5sZW5ndGg7CiAgICAgICAgdmFyIG9wZW5CcmFjZVBvcyA9IGRvYy5maW5kTWF0Y2hpbmdCcmFja2V0KHsgcm93OiByb3csIGNvbHVtbjogY29sdW1uIH0pOwogICAgICAgIGlmICghb3BlbkJyYWNlUG9zIHx8IG9wZW5CcmFjZVBvcy5yb3cgPT0gcm93KQogICAgICAgICAgICByZXR1cm4gMDsKICAgICAgICB2YXIgaW5kZW50ID0gdGhpcy4kZ2V0SW5kZW50KGRvYy5nZXRMaW5lKG9wZW5CcmFjZVBvcy5yb3cpKTsKICAgICAgICBkb2MucmVwbGFjZShuZXcgUmFuZ2Uocm93LCAwLCByb3csIGNvbHVtbiAtIDEpLCBpbmRlbnQpOwogICAgfTsKICAgIHRoaXMuJGdldEluZGVudCA9IGZ1bmN0aW9uIChsaW5lKSB7CiAgICAgICAgcmV0dXJuIGxpbmUubWF0Y2goL15ccyovKVswXTsKICAgIH07Cn0pLmNhbGwoTWF0Y2hpbmdCcmFjZU91dGRlbnQucHJvdG90eXBlKTsKZXhwb3J0cy5NYXRjaGluZ0JyYWNlT3V0ZGVudCA9IE1hdGNoaW5nQnJhY2VPdXRkZW50OwoKfSk7CgphY2UuZGVmaW5lKCJhY2UvbW9kZS9mb2xkaW5nL2NzdHlsZSIsWyJyZXF1aXJlIiwiZXhwb3J0cyIsIm1vZHVsZSIsImFjZS9saWIvb29wIiwiYWNlL3JhbmdlIiwiYWNlL21vZGUvZm9sZGluZy9mb2xkX21vZGUiXSwgZnVuY3Rpb24ocmVxdWlyZSwgZXhwb3J0cywgbW9kdWxlKXsidXNlIHN0cmljdCI7CnZhciBvb3AgPSByZXF1aXJlKCIuLi8uLi9saWIvb29wIik7CnZhciBSYW5nZSA9IHJlcXVpcmUoIi4uLy4uL3JhbmdlIikuUmFuZ2U7CnZhciBCYXNlRm9sZE1vZGUgPSByZXF1aXJlKCIuL2ZvbGRfbW9kZSIpLkZvbGRNb2RlOwp2YXIgRm9sZE1vZGUgPSBleHBvcnRzLkZvbGRNb2RlID0gZnVuY3Rpb24gKGNvbW1lbnRSZWdleCkgewogICAgaWYgKGNvbW1lbnRSZWdleCkgewogICAgICAgIHRoaXMuZm9sZGluZ1N0YXJ0TWFya2VyID0gbmV3IFJlZ0V4cCh0aGlzLmZvbGRpbmdTdGFydE1hcmtlci5zb3VyY2UucmVwbGFjZSgvXHxbXnxdKj8kLywgInwiICsgY29tbWVudFJlZ2V4LnN0YXJ0KSk7CiAgICAgICAgdGhpcy5mb2xkaW5nU3RvcE1hcmtlciA9IG5ldyBSZWdFeHAodGhpcy5mb2xkaW5nU3RvcE1hcmtlci5zb3VyY2UucmVwbGFjZSgvXHxbXnxdKj8kLywgInwiICsgY29tbWVudFJlZ2V4LmVuZCkpOwogICAgfQp9Owpvb3AuaW5oZXJpdHMoRm9sZE1vZGUsIEJhc2VGb2xkTW9kZSk7CihmdW5jdGlvbiAoKSB7CiAgICB0aGlzLmZvbGRpbmdTdGFydE1hcmtlciA9IC8oW1x7XFtcKF0pW15cfVxdXCldKiR8XlxzKihcL1wqKS87CiAgICB0aGlzLmZvbGRpbmdTdG9wTWFya2VyID0gL15bXlxbXHtcKF0qKFtcfVxdXCldKXxeW1xzXCpdKihcKlwvKS87CiAgICB0aGlzLnNpbmdsZUxpbmVCbG9ja0NvbW1lbnRSZSA9IC9eXHMqKFwvXCopLipcKlwvXHMqJC87CiAgICB0aGlzLnRyaXBsZVN0YXJCbG9ja0NvbW1lbnRSZSA9IC9eXHMqKFwvXCpcKlwqKS4qXCpcL1xzKiQvOwogICAgdGhpcy5zdGFydFJlZ2lvblJlID0gL15ccyooXC9cKnxcL1wvKSM/cmVnaW9uXGIvOwogICAgdGhpcy5fZ2V0Rm9sZFdpZGdldEJhc2UgPSB0aGlzLmdldEZvbGRXaWRnZXQ7CiAgICB0aGlzLmdldEZvbGRXaWRnZXQgPSBmdW5jdGlvbiAoc2Vzc2lvbiwgZm9sZFN0eWxlLCByb3cpIHsKICAgICAgICB2YXIgbGluZSA9IHNlc3Npb24uZ2V0TGluZShyb3cpOwogICAgICAgIGlmICh0aGlzLnNpbmdsZUxpbmVCbG9ja0NvbW1lbnRSZS50ZXN0KGxpbmUpKSB7CiAgICAgICAgICAgIGlmICghdGhpcy5zdGFydFJlZ2lvblJlLnRlc3QobGluZSkgJiYgIXRoaXMudHJpcGxlU3RhckJsb2NrQ29tbWVudFJlLnRlc3QobGluZSkpCiAgICAgICAgICAgICAgICByZXR1cm4gIiI7CiAgICAgICAgfQogICAgICAgIHZhciBmdyA9IHRoaXMuX2dldEZvbGRXaWRnZXRCYXNlKHNlc3Npb24sIGZvbGRTdHlsZSwgcm93KTsKICAgICAgICBpZiAoIWZ3ICYmIHRoaXMuc3RhcnRSZWdpb25SZS50ZXN0KGxpbmUpKQogICAgICAgICAgICByZXR1cm4gInN0YXJ0IjsgLy8gbGluZUNvbW1lbnRSZWdpb25TdGFydAogICAgICAgIHJldHVybiBmdzsKICAgIH07CiAgICB0aGlzLmdldEZvbGRXaWRnZXRSYW5nZSA9IGZ1bmN0aW9uIChzZXNzaW9uLCBmb2xkU3R5bGUsIHJvdywgZm9yY2VNdWx0aWxpbmUpIHsKICAgICAgICB2YXIgbGluZSA9IHNlc3Npb24uZ2V0TGluZShyb3cpOwogICAgICAgIGlmICh0aGlzLnN0YXJ0UmVnaW9uUmUudGVzdChsaW5lKSkKICAgICAgICAgICAgcmV0dXJuIHRoaXMuZ2V0Q29tbWVudFJlZ2lvbkJsb2NrKHNlc3Npb24sIGxpbmUsIHJvdyk7CiAgICAgICAgdmFyIG1hdGNoID0gbGluZS5tYXRjaCh0aGlzLmZvbGRpbmdTdGFydE1hcmtlcik7CiAgICAgICAgaWYgKG1hdGNoKSB7CiAgICAgICAgICAgIHZhciBpID0gbWF0Y2guaW5kZXg7CiAgICAgICAgICAgIGlmIChtYXRjaFsxXSkKICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLm9wZW5pbmdCcmFja2V0QmxvY2soc2Vzc2lvbiwgbWF0Y2hbMV0sIHJvdywgaSk7CiAgICAgICAgICAgIHZhciByYW5nZSA9IHNlc3Npb24uZ2V0Q29tbWVudEZvbGRSYW5nZShyb3csIGkgKyBtYXRjaFswXS5sZW5ndGgsIDEpOwogICAgICAgICAgICBpZiAocmFuZ2UgJiYgIXJhbmdlLmlzTXVsdGlMaW5lKCkpIHsKICAgICAgICAgICAgICAgIGlmIChmb3JjZU11bHRpbGluZSkgewogICAgICAgICAgICAgICAgICAgIHJhbmdlID0gdGhpcy5nZXRTZWN0aW9uUmFuZ2Uoc2Vzc2lvbiwgcm93KTsKICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgICAgIGVsc2UgaWYgKGZvbGRTdHlsZSAhPSAiYWxsIikKICAgICAgICAgICAgICAgICAgICByYW5nZSA9IG51bGw7CiAgICAgICAgICAgIH0KICAgICAgICAgICAgcmV0dXJuIHJhbmdlOwogICAgICAgIH0KICAgICAgICBpZiAoZm9sZFN0eWxlID09PSAibWFya2JlZ2luIikKICAgICAgICAgICAgcmV0dXJuOwogICAgICAgIHZhciBtYXRjaCA9IGxpbmUubWF0Y2godGhpcy5mb2xkaW5nU3RvcE1hcmtlcik7CiAgICAgICAgaWYgKG1hdGNoKSB7CiAgICAgICAgICAgIHZhciBpID0gbWF0Y2guaW5kZXggKyBtYXRjaFswXS5sZW5ndGg7CiAgICAgICAgICAgIGlmIChtYXRjaFsxXSkKICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmNsb3NpbmdCcmFja2V0QmxvY2soc2Vzc2lvbiwgbWF0Y2hbMV0sIHJvdywgaSk7CiAgICAgICAgICAgIHJldHVybiBzZXNzaW9uLmdldENvbW1lbnRGb2xkUmFuZ2Uocm93LCBpLCAtMSk7CiAgICAgICAgfQogICAgfTsKICAgIHRoaXMuZ2V0U2VjdGlvblJhbmdlID0gZnVuY3Rpb24gKHNlc3Npb24sIHJvdykgewogICAgICAgIHZhciBsaW5lID0gc2Vzc2lvbi5nZXRMaW5lKHJvdyk7CiAgICAgICAgdmFyIHN0YXJ0SW5kZW50ID0gbGluZS5zZWFyY2goL1xTLyk7CiAgICAgICAgdmFyIHN0YXJ0Um93ID0gcm93OwogICAgICAgIHZhciBzdGFydENvbHVtbiA9IGxpbmUubGVuZ3RoOwogICAgICAgIHJvdyA9IHJvdyArIDE7CiAgICAgICAgdmFyIGVuZFJvdyA9IHJvdzsKICAgICAgICB2YXIgbWF4Um93ID0gc2Vzc2lvbi5nZXRMZW5ndGgoKTsKICAgICAgICB3aGlsZSAoKytyb3cgPCBtYXhSb3cpIHsKICAgICAgICAgICAgbGluZSA9IHNlc3Npb24uZ2V0TGluZShyb3cpOwogICAgICAgICAgICB2YXIgaW5kZW50ID0gbGluZS5zZWFyY2goL1xTLyk7CiAgICAgICAgICAgIGlmIChpbmRlbnQgPT09IC0xKQogICAgICAgICAgICAgICAgY29udGludWU7CiAgICAgICAgICAgIGlmIChzdGFydEluZGVudCA+IGluZGVudCkKICAgICAgICAgICAgICAgIGJyZWFrOwogICAgICAgICAgICB2YXIgc3ViUmFuZ2UgPSB0aGlzLmdldEZvbGRXaWRnZXRSYW5nZShzZXNzaW9uLCAiYWxsIiwgcm93KTsKICAgICAgICAgICAgaWYgKHN1YlJhbmdlKSB7CiAgICAgICAgICAgICAgICBpZiAoc3ViUmFuZ2Uuc3RhcnQucm93IDw9IHN0YXJ0Um93KSB7CiAgICAgICAgICAgICAgICAgICAgYnJlYWs7CiAgICAgICAgICAgICAgICB9CiAgICAgICAgICAgICAgICBlbHNlIGlmIChzdWJSYW5nZS5pc011bHRpTGluZSgpKSB7CiAgICAgICAgICAgICAgICAgICAgcm93ID0gc3ViUmFuZ2UuZW5kLnJvdzsKICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgICAgIGVsc2UgaWYgKHN0YXJ0SW5kZW50ID09IGluZGVudCkgewogICAgICAgICAgICAgICAgICAgIGJyZWFrOwogICAgICAgICAgICAgICAgfQogICAgICAgICAgICB9CiAgICAgICAgICAgIGVuZFJvdyA9IHJvdzsKICAgICAgICB9CiAgICAgICAgcmV0dXJuIG5ldyBSYW5nZShzdGFydFJvdywgc3RhcnRDb2x1bW4sIGVuZFJvdywgc2Vzc2lvbi5nZXRMaW5lKGVuZFJvdykubGVuZ3RoKTsKICAgIH07CiAgICB0aGlzLmdldENvbW1lbnRSZWdpb25CbG9jayA9IGZ1bmN0aW9uIChzZXNzaW9uLCBsaW5lLCByb3cpIHsKICAgICAgICB2YXIgc3RhcnRDb2x1bW4gPSBsaW5lLnNlYXJjaCgvXHMqJC8pOwogICAgICAgIHZhciBtYXhSb3cgPSBzZXNzaW9uLmdldExlbmd0aCgpOwogICAgICAgIHZhciBzdGFydFJvdyA9IHJvdzsKICAgICAgICB2YXIgcmUgPSAvXlxzKig/OlwvXCp8XC9cL3wtLSkjPyhlbmQpP3JlZ2lvblxiLzsKICAgICAgICB2YXIgZGVwdGggPSAxOwogICAgICAgIHdoaWxlICgrK3JvdyA8IG1heFJvdykgewogICAgICAgICAgICBsaW5lID0gc2Vzc2lvbi5nZXRMaW5lKHJvdyk7CiAgICAgICAgICAgIHZhciBtID0gcmUuZXhlYyhsaW5lKTsKICAgICAgICAgICAgaWYgKCFtKQogICAgICAgICAgICAgICAgY29udGludWU7CiAgICAgICAgICAgIGlmIChtWzFdKQogICAgICAgICAgICAgICAgZGVwdGgtLTsKICAgICAgICAgICAgZWxzZQogICAgICAgICAgICAgICAgZGVwdGgrKzsKICAgICAgICAgICAgaWYgKCFkZXB0aCkKICAgICAgICAgICAgICAgIGJyZWFrOwogICAgICAgIH0KICAgICAgICB2YXIgZW5kUm93ID0gcm93OwogICAgICAgIGlmIChlbmRSb3cgPiBzdGFydFJvdykgewogICAgICAgICAgICByZXR1cm4gbmV3IFJhbmdlKHN0YXJ0Um93LCBzdGFydENvbHVtbiwgZW5kUm93LCBsaW5lLmxlbmd0aCk7CiAgICAgICAgfQogICAgfTsKfSkuY2FsbChGb2xkTW9kZS5wcm90b3R5cGUpOwoKfSk7CgphY2UuZGVmaW5lKCJhY2UvbW9kZS9qc29uIixbInJlcXVpcmUiLCJleHBvcnRzIiwibW9kdWxlIiwiYWNlL2xpYi9vb3AiLCJhY2UvbW9kZS90ZXh0IiwiYWNlL21vZGUvanNvbl9oaWdobGlnaHRfcnVsZXMiLCJhY2UvbW9kZS9tYXRjaGluZ19icmFjZV9vdXRkZW50IiwiYWNlL21vZGUvZm9sZGluZy9jc3R5bGUiLCJhY2Uvd29ya2VyL3dvcmtlcl9jbGllbnQiXSwgZnVuY3Rpb24ocmVxdWlyZSwgZXhwb3J0cywgbW9kdWxlKXsidXNlIHN0cmljdCI7CnZhciBvb3AgPSByZXF1aXJlKCIuLi9saWIvb29wIik7CnZhciBUZXh0TW9kZSA9IHJlcXVpcmUoIi4vdGV4dCIpLk1vZGU7CnZhciBIaWdobGlnaHRSdWxlcyA9IHJlcXVpcmUoIi4vanNvbl9oaWdobGlnaHRfcnVsZXMiKS5Kc29uSGlnaGxpZ2h0UnVsZXM7CnZhciBNYXRjaGluZ0JyYWNlT3V0ZGVudCA9IHJlcXVpcmUoIi4vbWF0Y2hpbmdfYnJhY2Vfb3V0ZGVudCIpLk1hdGNoaW5nQnJhY2VPdXRkZW50Owp2YXIgQ1N0eWxlRm9sZE1vZGUgPSByZXF1aXJlKCIuL2ZvbGRpbmcvY3N0eWxlIikuRm9sZE1vZGU7CnZhciBXb3JrZXJDbGllbnQgPSByZXF1aXJlKCIuLi93b3JrZXIvd29ya2VyX2NsaWVudCIpLldvcmtlckNsaWVudDsKdmFyIE1vZGUgPSBmdW5jdGlvbiAoKSB7CiAgICB0aGlzLkhpZ2hsaWdodFJ1bGVzID0gSGlnaGxpZ2h0UnVsZXM7CiAgICB0aGlzLiRvdXRkZW50ID0gbmV3IE1hdGNoaW5nQnJhY2VPdXRkZW50KCk7CiAgICB0aGlzLiRiZWhhdmlvdXIgPSB0aGlzLiRkZWZhdWx0QmVoYXZpb3VyOwogICAgdGhpcy5mb2xkaW5nUnVsZXMgPSBuZXcgQ1N0eWxlRm9sZE1vZGUoKTsKfTsKb29wLmluaGVyaXRzKE1vZGUsIFRleHRNb2RlKTsKKGZ1bmN0aW9uICgpIHsKICAgIHRoaXMubGluZUNvbW1lbnRTdGFydCA9ICIvLyI7CiAgICB0aGlzLmJsb2NrQ29tbWVudCA9IHsgc3RhcnQ6ICIvKiIsIGVuZDogIiovIiB9OwogICAgdGhpcy5nZXROZXh0TGluZUluZGVudCA9IGZ1bmN0aW9uIChzdGF0ZSwgbGluZSwgdGFiKSB7CiAgICAgICAgdmFyIGluZGVudCA9IHRoaXMuJGdldEluZGVudChsaW5lKTsKICAgICAgICBpZiAoc3RhdGUgPT0gInN0YXJ0IikgewogICAgICAgICAgICB2YXIgbWF0Y2ggPSBsaW5lLm1hdGNoKC9eLipbXHtcKFxbXVxzKiQvKTsKICAgICAgICAgICAgaWYgKG1hdGNoKSB7CiAgICAgICAgICAgICAgICBpbmRlbnQgKz0gdGFiOwogICAgICAgICAgICB9CiAgICAgICAgfQogICAgICAgIHJldHVybiBpbmRlbnQ7CiAgICB9OwogICAgdGhpcy5jaGVja091dGRlbnQgPSBmdW5jdGlvbiAoc3RhdGUsIGxpbmUsIGlucHV0KSB7CiAgICAgICAgcmV0dXJuIHRoaXMuJG91dGRlbnQuY2hlY2tPdXRkZW50KGxpbmUsIGlucHV0KTsKICAgIH07CiAgICB0aGlzLmF1dG9PdXRkZW50ID0gZnVuY3Rpb24gKHN0YXRlLCBkb2MsIHJvdykgewogICAgICAgIHRoaXMuJG91dGRlbnQuYXV0b091dGRlbnQoZG9jLCByb3cpOwogICAgfTsKICAgIHRoaXMuY3JlYXRlV29ya2VyID0gZnVuY3Rpb24gKHNlc3Npb24pIHsKICAgICAgICB2YXIgd29ya2VyID0gbmV3IFdvcmtlckNsaWVudChbImFjZSJdLCAiYWNlL21vZGUvanNvbl93b3JrZXIiLCAiSnNvbldvcmtlciIpOwogICAgICAgIHdvcmtlci5hdHRhY2hUb0RvY3VtZW50KHNlc3Npb24uZ2V0RG9jdW1lbnQoKSk7CiAgICAgICAgd29ya2VyLm9uKCJhbm5vdGF0ZSIsIGZ1bmN0aW9uIChlKSB7CiAgICAgICAgICAgIHNlc3Npb24uc2V0QW5ub3RhdGlvbnMoZS5kYXRhKTsKICAgICAgICB9KTsKICAgICAgICB3b3JrZXIub24oInRlcm1pbmF0ZSIsIGZ1bmN0aW9uICgpIHsKICAgICAgICAgICAgc2Vzc2lvbi5jbGVhckFubm90YXRpb25zKCk7CiAgICAgICAgfSk7CiAgICAgICAgcmV0dXJuIHdvcmtlcjsKICAgIH07CiAgICB0aGlzLiRpZCA9ICJhY2UvbW9kZS9qc29uIjsKfSkuY2FsbChNb2RlLnByb3RvdHlwZSk7CmV4cG9ydHMuTW9kZSA9IE1vZGU7Cgp9KTsgICAgICAgICAgICAgICAgKGZ1bmN0aW9uKCkgewogICAgICAgICAgICAgICAgICAgIGFjZS5yZXF1aXJlKFsiYWNlL21vZGUvanNvbiJdLCBmdW5jdGlvbihtKSB7CiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgbW9kdWxlID09ICJvYmplY3QiICYmIHR5cGVvZiBleHBvcnRzID09ICJvYmplY3QiICYmIG1vZHVsZSkgewogICAgICAgICAgICAgICAgICAgICAgICAgICAgbW9kdWxlLmV4cG9ydHMgPSBtOwogICAgICAgICAgICAgICAgICAgICAgICB9CiAgICAgICAgICAgICAgICAgICAgfSk7CiAgICAgICAgICAgICAgICB9KSgpOwogICAgICAgICAgICA=", LC = "data:text/javascript;base64,YWNlLmRlZmluZSgiYWNlL3RoZW1lL2Nocm9tZS1jc3MiLFsicmVxdWlyZSIsImV4cG9ydHMiLCJtb2R1bGUiXSwgZnVuY3Rpb24ocmVxdWlyZSwgZXhwb3J0cywgbW9kdWxlKXttb2R1bGUuZXhwb3J0cyA9ICIuYWNlLWNocm9tZSAuYWNlX2d1dHRlciB7XG4gIGJhY2tncm91bmQ6ICNlYmViZWI7XG4gIGNvbG9yOiAjMzMzO1xuICBvdmVyZmxvdyA6IGhpZGRlbjtcbn1cblxuLmFjZS1jaHJvbWUgLmFjZV9wcmludC1tYXJnaW4ge1xuICB3aWR0aDogMXB4O1xuICBiYWNrZ3JvdW5kOiAjZThlOGU4O1xufVxuXG4uYWNlLWNocm9tZSB7XG4gIGJhY2tncm91bmQtY29sb3I6ICNGRkZGRkY7XG4gIGNvbG9yOiBibGFjaztcbn1cblxuLmFjZS1jaHJvbWUgLmFjZV9jdXJzb3Ige1xuICBjb2xvcjogYmxhY2s7XG59XG5cbi5hY2UtY2hyb21lIC5hY2VfaW52aXNpYmxlIHtcbiAgY29sb3I6IHJnYigxOTEsIDE5MSwgMTkxKTtcbn1cblxuLmFjZS1jaHJvbWUgLmFjZV9jb25zdGFudC5hY2VfYnVpbGRpbiB7XG4gIGNvbG9yOiByZ2IoODgsIDcyLCAyNDYpO1xufVxuXG4uYWNlLWNocm9tZSAuYWNlX2NvbnN0YW50LmFjZV9sYW5ndWFnZSB7XG4gIGNvbG9yOiByZ2IoODgsIDkyLCAyNDYpO1xufVxuXG4uYWNlLWNocm9tZSAuYWNlX2NvbnN0YW50LmFjZV9saWJyYXJ5IHtcbiAgY29sb3I6IHJnYig2LCAxNTAsIDE0KTtcbn1cblxuLmFjZS1jaHJvbWUgLmFjZV9pbnZhbGlkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE1MywgMCwgMCk7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cblxuLmFjZS1jaHJvbWUgLmFjZV9mb2xkIHtcbn1cblxuLmFjZS1jaHJvbWUgLmFjZV9zdXBwb3J0LmFjZV9mdW5jdGlvbiB7XG4gIGNvbG9yOiByZ2IoNjAsIDc2LCAxMTQpO1xufVxuXG4uYWNlLWNocm9tZSAuYWNlX3N1cHBvcnQuYWNlX2NvbnN0YW50IHtcbiAgY29sb3I6IHJnYig2LCAxNTAsIDE0KTtcbn1cblxuLmFjZS1jaHJvbWUgLmFjZV9zdXBwb3J0LmFjZV90eXBlLFxuLmFjZS1jaHJvbWUgLmFjZV9zdXBwb3J0LmFjZV9jbGFzc1xuLmFjZS1jaHJvbWUgLmFjZV9zdXBwb3J0LmFjZV9vdGhlciB7XG4gIGNvbG9yOiByZ2IoMTA5LCAxMjEsIDIyMik7XG59XG5cbi5hY2UtY2hyb21lIC5hY2VfdmFyaWFibGUuYWNlX3BhcmFtZXRlciB7XG4gIGZvbnQtc3R5bGU6aXRhbGljO1xuICBjb2xvcjojRkQ5NzFGO1xufVxuLmFjZS1jaHJvbWUgLmFjZV9rZXl3b3JkLmFjZV9vcGVyYXRvciB7XG4gIGNvbG9yOiByZ2IoMTA0LCAxMTgsIDEzNSk7XG59XG5cbi5hY2UtY2hyb21lIC5hY2VfY29tbWVudCB7XG4gIGNvbG9yOiAjMjM2ZTI0O1xufVxuXG4uYWNlLWNocm9tZSAuYWNlX2NvbW1lbnQuYWNlX2RvYyB7XG4gIGNvbG9yOiAjMjM2ZTI0O1xufVxuXG4uYWNlLWNocm9tZSAuYWNlX2NvbW1lbnQuYWNlX2RvYy5hY2VfdGFnIHtcbiAgY29sb3I6ICMyMzZlMjQ7XG59XG5cbi5hY2UtY2hyb21lIC5hY2VfY29uc3RhbnQuYWNlX251bWVyaWMge1xuICBjb2xvcjogcmdiKDAsIDAsIDIwNSk7XG59XG5cbi5hY2UtY2hyb21lIC5hY2VfdmFyaWFibGUge1xuICBjb2xvcjogcmdiKDQ5LCAxMzIsIDE0OSk7XG59XG5cbi5hY2UtY2hyb21lIC5hY2VfeG1sLXBlIHtcbiAgY29sb3I6IHJnYigxMDQsIDEwNCwgOTEpO1xufVxuXG4uYWNlLWNocm9tZSAuYWNlX2VudGl0eS5hY2VfbmFtZS5hY2VfZnVuY3Rpb24ge1xuICBjb2xvcjogIzAwMDBBMjtcbn1cblxuXG4uYWNlLWNocm9tZSAuYWNlX2hlYWRpbmcge1xuICBjb2xvcjogcmdiKDEyLCA3LCAyNTUpO1xufVxuXG4uYWNlLWNocm9tZSAuYWNlX2xpc3Qge1xuICBjb2xvcjpyZ2IoMTg1LCA2LCAxNDQpO1xufVxuXG4uYWNlLWNocm9tZSAuYWNlX21hcmtlci1sYXllciAuYWNlX3NlbGVjdGlvbiB7XG4gIGJhY2tncm91bmQ6IHJnYigxODEsIDIxMywgMjU1KTtcbn1cblxuLmFjZS1jaHJvbWUgLmFjZV9tYXJrZXItbGF5ZXIgLmFjZV9zdGVwIHtcbiAgYmFja2dyb3VuZDogcmdiKDI1MiwgMjU1LCAwKTtcbn1cblxuLmFjZS1jaHJvbWUgLmFjZV9tYXJrZXItbGF5ZXIgLmFjZV9zdGFjayB7XG4gIGJhY2tncm91bmQ6IHJnYigxNjQsIDIyOSwgMTAxKTtcbn1cblxuLmFjZS1jaHJvbWUgLmFjZV9tYXJrZXItbGF5ZXIgLmFjZV9icmFja2V0IHtcbiAgbWFyZ2luOiAtMXB4IDAgMCAtMXB4O1xuICBib3JkZXI6IDFweCBzb2xpZCByZ2IoMTkyLCAxOTIsIDE5Mik7XG59XG5cbi5hY2UtY2hyb21lIC5hY2VfbWFya2VyLWxheWVyIC5hY2VfYWN0aXZlLWxpbmUge1xuICBiYWNrZ3JvdW5kOiByZ2JhKDAsIDAsIDAsIDAuMDcpO1xufVxuXG4uYWNlLWNocm9tZSAuYWNlX2d1dHRlci1hY3RpdmUtbGluZSB7XG4gICAgYmFja2dyb3VuZC1jb2xvciA6ICNkY2RjZGM7XG59XG5cbi5hY2UtY2hyb21lIC5hY2VfbWFya2VyLWxheWVyIC5hY2Vfc2VsZWN0ZWQtd29yZCB7XG4gIGJhY2tncm91bmQ6IHJnYigyNTAsIDI1MCwgMjU1KTtcbiAgYm9yZGVyOiAxcHggc29saWQgcmdiKDIwMCwgMjAwLCAyNTApO1xufVxuXG4uYWNlLWNocm9tZSAuYWNlX3N0b3JhZ2UsXG4uYWNlLWNocm9tZSAuYWNlX2tleXdvcmQsXG4uYWNlLWNocm9tZSAuYWNlX21ldGEuYWNlX3RhZyB7XG4gIGNvbG9yOiByZ2IoMTQ3LCAxNSwgMTI4KTtcbn1cblxuLmFjZS1jaHJvbWUgLmFjZV9zdHJpbmcuYWNlX3JlZ2V4IHtcbiAgY29sb3I6IHJnYigyNTUsIDAsIDApXG59XG5cbi5hY2UtY2hyb21lIC5hY2Vfc3RyaW5nIHtcbiAgY29sb3I6ICMxQTFBQTY7XG59XG5cbi5hY2UtY2hyb21lIC5hY2VfZW50aXR5LmFjZV9vdGhlci5hY2VfYXR0cmlidXRlLW5hbWUge1xuICBjb2xvcjogIzk5NDQwOTtcbn1cblxuLmFjZS1jaHJvbWUgLmFjZV9pbmRlbnQtZ3VpZGUge1xuICBiYWNrZ3JvdW5kOiB1cmwoXCJkYXRhOmltYWdlL3BuZztiYXNlNjQsaVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUFFQUFBQUNDQVlBQUFDWmdiWW5BQUFBRTBsRVFWUUltV1A0Ly8vL2Y0YkxseS8vQndBbVZnZDEvdzExL2dBQUFBQkpSVTVFcmtKZ2dnPT1cIikgcmlnaHQgcmVwZWF0LXk7XG59XG4gIFxuLmFjZS1jaHJvbWUgLmFjZV9pbmRlbnQtZ3VpZGUtYWN0aXZlIHtcbiAgYmFja2dyb3VuZDogdXJsKFwiZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFBRUFBQUFDQ0FZQUFBQ1pnYlluQUFBQUNYQklXWE1BQUFzVEFBQUxFd0VBbXB3WUFBQUFJR05JVWswQUFIb2xBQUNBZ3dBQStmOEFBSURwQUFCMU1BQUE2bUFBQURxWUFBQVhiNUpmeFVZQUFBQVpTVVJCVkhqYVl2ai8vLzkvaGl2S3l2OEJBQUFBLy84REFDTHFCaGJ2aysvZUFBQUFBRWxGVGtTdVFtQ0NcIikgcmlnaHQgcmVwZWF0LXk7XG59XG4iOwoKfSk7CgphY2UuZGVmaW5lKCJhY2UvdGhlbWUvY2hyb21lIixbInJlcXVpcmUiLCJleHBvcnRzIiwibW9kdWxlIiwiYWNlL3RoZW1lL2Nocm9tZS1jc3MiLCJhY2UvbGliL2RvbSJdLCBmdW5jdGlvbihyZXF1aXJlLCBleHBvcnRzLCBtb2R1bGUpe2V4cG9ydHMuaXNEYXJrID0gZmFsc2U7CmV4cG9ydHMuY3NzQ2xhc3MgPSAiYWNlLWNocm9tZSI7CmV4cG9ydHMuY3NzVGV4dCA9IHJlcXVpcmUoIi4vY2hyb21lLWNzcyIpOwp2YXIgZG9tID0gcmVxdWlyZSgiLi4vbGliL2RvbSIpOwpkb20uaW1wb3J0Q3NzU3RyaW5nKGV4cG9ydHMuY3NzVGV4dCwgZXhwb3J0cy5jc3NDbGFzcywgZmFsc2UpOwoKfSk7ICAgICAgICAgICAgICAgIChmdW5jdGlvbigpIHsKICAgICAgICAgICAgICAgICAgICBhY2UucmVxdWlyZShbImFjZS90aGVtZS9jaHJvbWUiXSwgZnVuY3Rpb24obSkgewogICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIG1vZHVsZSA9PSAib2JqZWN0IiAmJiB0eXBlb2YgZXhwb3J0cyA9PSAib2JqZWN0IiAmJiBtb2R1bGUpIHsKICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vZHVsZS5leHBvcnRzID0gbTsKICAgICAgICAgICAgICAgICAgICAgICAgfQogICAgICAgICAgICAgICAgICAgIH0pOwogICAgICAgICAgICAgICAgfSkoKTsKICAgICAgICAgICAg", FC = "data:text/javascript;base64,Im5vIHVzZSBzdHJpY3QiOwohKGZ1bmN0aW9uKHdpbmRvdykgewppZiAodHlwZW9mIHdpbmRvdy53aW5kb3cgIT0gInVuZGVmaW5lZCIgJiYgd2luZG93LmRvY3VtZW50KQogICAgcmV0dXJuOwppZiAod2luZG93LnJlcXVpcmUgJiYgd2luZG93LmRlZmluZSkKICAgIHJldHVybjsKCmlmICghd2luZG93LmNvbnNvbGUpIHsKICAgIHdpbmRvdy5jb25zb2xlID0gZnVuY3Rpb24oKSB7CiAgICAgICAgdmFyIG1zZ3MgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMsIDApOwogICAgICAgIHBvc3RNZXNzYWdlKHt0eXBlOiAibG9nIiwgZGF0YTogbXNnc30pOwogICAgfTsKICAgIHdpbmRvdy5jb25zb2xlLmVycm9yID0KICAgIHdpbmRvdy5jb25zb2xlLndhcm4gPSAKICAgIHdpbmRvdy5jb25zb2xlLmxvZyA9CiAgICB3aW5kb3cuY29uc29sZS50cmFjZSA9IHdpbmRvdy5jb25zb2xlOwp9CndpbmRvdy53aW5kb3cgPSB3aW5kb3c7CndpbmRvdy5hY2UgPSB3aW5kb3c7Cgp3aW5kb3cub25lcnJvciA9IGZ1bmN0aW9uKG1lc3NhZ2UsIGZpbGUsIGxpbmUsIGNvbCwgZXJyKSB7CiAgICBwb3N0TWVzc2FnZSh7dHlwZTogImVycm9yIiwgZGF0YTogewogICAgICAgIG1lc3NhZ2U6IG1lc3NhZ2UsCiAgICAgICAgZGF0YTogZXJyICYmIGVyci5kYXRhLAogICAgICAgIGZpbGU6IGZpbGUsCiAgICAgICAgbGluZTogbGluZSwgCiAgICAgICAgY29sOiBjb2wsCiAgICAgICAgc3RhY2s6IGVyciAmJiBlcnIuc3RhY2sKICAgIH19KTsKfTsKCndpbmRvdy5ub3JtYWxpemVNb2R1bGUgPSBmdW5jdGlvbihwYXJlbnRJZCwgbW9kdWxlTmFtZSkgewogICAgLy8gbm9ybWFsaXplIHBsdWdpbiByZXF1aXJlcwogICAgaWYgKG1vZHVsZU5hbWUuaW5kZXhPZigiISIpICE9PSAtMSkgewogICAgICAgIHZhciBjaHVua3MgPSBtb2R1bGVOYW1lLnNwbGl0KCIhIik7CiAgICAgICAgcmV0dXJuIHdpbmRvdy5ub3JtYWxpemVNb2R1bGUocGFyZW50SWQsIGNodW5rc1swXSkgKyAiISIgKyB3aW5kb3cubm9ybWFsaXplTW9kdWxlKHBhcmVudElkLCBjaHVua3NbMV0pOwogICAgfQogICAgLy8gbm9ybWFsaXplIHJlbGF0aXZlIHJlcXVpcmVzCiAgICBpZiAobW9kdWxlTmFtZS5jaGFyQXQoMCkgPT0gIi4iKSB7CiAgICAgICAgdmFyIGJhc2UgPSBwYXJlbnRJZC5zcGxpdCgiLyIpLnNsaWNlKDAsIC0xKS5qb2luKCIvIik7CiAgICAgICAgbW9kdWxlTmFtZSA9IChiYXNlID8gYmFzZSArICIvIiA6ICIiKSArIG1vZHVsZU5hbWU7CiAgICAgICAgCiAgICAgICAgd2hpbGUgKG1vZHVsZU5hbWUuaW5kZXhPZigiLiIpICE9PSAtMSAmJiBwcmV2aW91cyAhPSBtb2R1bGVOYW1lKSB7CiAgICAgICAgICAgIHZhciBwcmV2aW91cyA9IG1vZHVsZU5hbWU7CiAgICAgICAgICAgIG1vZHVsZU5hbWUgPSBtb2R1bGVOYW1lLnJlcGxhY2UoL15cLlwvLywgIiIpLnJlcGxhY2UoL1wvXC5cLy8sICIvIikucmVwbGFjZSgvW15cL10rXC9cLlwuXC8vLCAiIik7CiAgICAgICAgfQogICAgfQogICAgCiAgICByZXR1cm4gbW9kdWxlTmFtZTsKfTsKCndpbmRvdy5yZXF1aXJlID0gZnVuY3Rpb24gcmVxdWlyZShwYXJlbnRJZCwgaWQpIHsKICAgIGlmICghaWQpIHsKICAgICAgICBpZCA9IHBhcmVudElkOwogICAgICAgIHBhcmVudElkID0gbnVsbDsKICAgIH0KICAgIGlmICghaWQuY2hhckF0KQogICAgICAgIHRocm93IG5ldyBFcnJvcigid29ya2VyLmpzIHJlcXVpcmUoKSBhY2NlcHRzIG9ubHkgKHBhcmVudElkLCBpZCkgYXMgYXJndW1lbnRzIik7CgogICAgaWQgPSB3aW5kb3cubm9ybWFsaXplTW9kdWxlKHBhcmVudElkLCBpZCk7CgogICAgdmFyIG1vZHVsZSA9IHdpbmRvdy5yZXF1aXJlLm1vZHVsZXNbaWRdOwogICAgaWYgKG1vZHVsZSkgewogICAgICAgIGlmICghbW9kdWxlLmluaXRpYWxpemVkKSB7CiAgICAgICAgICAgIG1vZHVsZS5pbml0aWFsaXplZCA9IHRydWU7CiAgICAgICAgICAgIG1vZHVsZS5leHBvcnRzID0gbW9kdWxlLmZhY3RvcnkoKS5leHBvcnRzOwogICAgICAgIH0KICAgICAgICByZXR1cm4gbW9kdWxlLmV4cG9ydHM7CiAgICB9CiAgIAogICAgaWYgKCF3aW5kb3cucmVxdWlyZS50bG5zKQogICAgICAgIHJldHVybiBjb25zb2xlLmxvZygidW5hYmxlIHRvIGxvYWQgIiArIGlkKTsKICAgIAogICAgdmFyIHBhdGggPSByZXNvbHZlTW9kdWxlSWQoaWQsIHdpbmRvdy5yZXF1aXJlLnRsbnMpOwogICAgaWYgKHBhdGguc2xpY2UoLTMpICE9ICIuanMiKSBwYXRoICs9ICIuanMiOwogICAgCiAgICB3aW5kb3cucmVxdWlyZS5pZCA9IGlkOwogICAgd2luZG93LnJlcXVpcmUubW9kdWxlc1tpZF0gPSB7fTsgLy8gcHJldmVudCBpbmZpbml0ZSBsb29wIG9uIGJyb2tlbiBtb2R1bGVzCiAgICBpbXBvcnRTY3JpcHRzKHBhdGgpOwogICAgcmV0dXJuIHdpbmRvdy5yZXF1aXJlKHBhcmVudElkLCBpZCk7Cn07CmZ1bmN0aW9uIHJlc29sdmVNb2R1bGVJZChpZCwgcGF0aHMpIHsKICAgIHZhciB0ZXN0UGF0aCA9IGlkLCB0YWlsID0gIiI7CiAgICB3aGlsZSAodGVzdFBhdGgpIHsKICAgICAgICB2YXIgYWxpYXMgPSBwYXRoc1t0ZXN0UGF0aF07CiAgICAgICAgaWYgKHR5cGVvZiBhbGlhcyA9PSAic3RyaW5nIikgewogICAgICAgICAgICByZXR1cm4gYWxpYXMgKyB0YWlsOwogICAgICAgIH0gZWxzZSBpZiAoYWxpYXMpIHsKICAgICAgICAgICAgcmV0dXJuICBhbGlhcy5sb2NhdGlvbi5yZXBsYWNlKC9cLyokLywgIi8iKSArICh0YWlsIHx8IGFsaWFzLm1haW4gfHwgYWxpYXMubmFtZSk7CiAgICAgICAgfSBlbHNlIGlmIChhbGlhcyA9PT0gZmFsc2UpIHsKICAgICAgICAgICAgcmV0dXJuICIiOwogICAgICAgIH0KICAgICAgICB2YXIgaSA9IHRlc3RQYXRoLmxhc3RJbmRleE9mKCIvIik7CiAgICAgICAgaWYgKGkgPT09IC0xKSBicmVhazsKICAgICAgICB0YWlsID0gdGVzdFBhdGguc3Vic3RyKGkpICsgdGFpbDsKICAgICAgICB0ZXN0UGF0aCA9IHRlc3RQYXRoLnNsaWNlKDAsIGkpOwogICAgfQogICAgcmV0dXJuIGlkOwp9CndpbmRvdy5yZXF1aXJlLm1vZHVsZXMgPSB7fTsKd2luZG93LnJlcXVpcmUudGxucyA9IHt9OwoKd2luZG93LmRlZmluZSA9IGZ1bmN0aW9uKGlkLCBkZXBzLCBmYWN0b3J5KSB7CiAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA9PSAyKSB7CiAgICAgICAgZmFjdG9yeSA9IGRlcHM7CiAgICAgICAgaWYgKHR5cGVvZiBpZCAhPSAic3RyaW5nIikgewogICAgICAgICAgICBkZXBzID0gaWQ7CiAgICAgICAgICAgIGlkID0gd2luZG93LnJlcXVpcmUuaWQ7CiAgICAgICAgfQogICAgfSBlbHNlIGlmIChhcmd1bWVudHMubGVuZ3RoID09IDEpIHsKICAgICAgICBmYWN0b3J5ID0gaWQ7CiAgICAgICAgZGVwcyA9IFtdOwogICAgICAgIGlkID0gd2luZG93LnJlcXVpcmUuaWQ7CiAgICB9CiAgICAKICAgIGlmICh0eXBlb2YgZmFjdG9yeSAhPSAiZnVuY3Rpb24iKSB7CiAgICAgICAgd2luZG93LnJlcXVpcmUubW9kdWxlc1tpZF0gPSB7CiAgICAgICAgICAgIGV4cG9ydHM6IGZhY3RvcnksCiAgICAgICAgICAgIGluaXRpYWxpemVkOiB0cnVlCiAgICAgICAgfTsKICAgICAgICByZXR1cm47CiAgICB9CgogICAgaWYgKCFkZXBzLmxlbmd0aCkKICAgICAgICAvLyBJZiB0aGVyZSBpcyBubyBkZXBlbmRlbmNpZXMsIHdlIGluamVjdCAicmVxdWlyZSIsICJleHBvcnRzIiBhbmQKICAgICAgICAvLyAibW9kdWxlIiBhcyBkZXBlbmRlbmNpZXMsIHRvIHByb3ZpZGUgQ29tbW9uSlMgY29tcGF0aWJpbGl0eS4KICAgICAgICBkZXBzID0gWyJyZXF1aXJlIiwgImV4cG9ydHMiLCAibW9kdWxlIl07CgogICAgdmFyIHJlcSA9IGZ1bmN0aW9uKGNoaWxkSWQpIHsKICAgICAgICByZXR1cm4gd2luZG93LnJlcXVpcmUoaWQsIGNoaWxkSWQpOwogICAgfTsKCiAgICB3aW5kb3cucmVxdWlyZS5tb2R1bGVzW2lkXSA9IHsKICAgICAgICBleHBvcnRzOiB7fSwKICAgICAgICBmYWN0b3J5OiBmdW5jdGlvbigpIHsKICAgICAgICAgICAgdmFyIG1vZHVsZSA9IHRoaXM7CiAgICAgICAgICAgIHZhciByZXR1cm5FeHBvcnRzID0gZmFjdG9yeS5hcHBseSh0aGlzLCBkZXBzLnNsaWNlKDAsIGZhY3RvcnkubGVuZ3RoKS5tYXAoZnVuY3Rpb24oZGVwKSB7CiAgICAgICAgICAgICAgICBzd2l0Y2ggKGRlcCkgewogICAgICAgICAgICAgICAgICAgIC8vIEJlY2F1c2UgInJlcXVpcmUiLCAiZXhwb3J0cyIgYW5kICJtb2R1bGUiIGFyZW4ndCBhY3R1YWwKICAgICAgICAgICAgICAgICAgICAvLyBkZXBlbmRlbmNpZXMsIHdlIG11c3QgaGFuZGxlIHRoZW0gc2VwZXJhdGVseS4KICAgICAgICAgICAgICAgICAgICBjYXNlICJyZXF1aXJlIjogcmV0dXJuIHJlcTsKICAgICAgICAgICAgICAgICAgICBjYXNlICJleHBvcnRzIjogcmV0dXJuIG1vZHVsZS5leHBvcnRzOwogICAgICAgICAgICAgICAgICAgIGNhc2UgIm1vZHVsZSI6ICByZXR1cm4gbW9kdWxlOwogICAgICAgICAgICAgICAgICAgIC8vIEJ1dCBmb3IgYWxsIG90aGVyIGRlcGVuZGVuY2llcywgd2UgY2FuIGp1c3QgZ28gYWhlYWQgYW5kCiAgICAgICAgICAgICAgICAgICAgLy8gcmVxdWlyZSB0aGVtLgogICAgICAgICAgICAgICAgICAgIGRlZmF1bHQ6ICAgICAgICByZXR1cm4gcmVxKGRlcCk7CiAgICAgICAgICAgICAgICB9CiAgICAgICAgICAgIH0pKTsKICAgICAgICAgICAgaWYgKHJldHVybkV4cG9ydHMpCiAgICAgICAgICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IHJldHVybkV4cG9ydHM7CiAgICAgICAgICAgIHJldHVybiBtb2R1bGU7CiAgICAgICAgfQogICAgfTsKfTsKd2luZG93LmRlZmluZS5hbWQgPSB7fTsKd2luZG93LnJlcXVpcmUudGxucyA9IHt9Owp3aW5kb3cuaW5pdEJhc2VVcmxzICA9IGZ1bmN0aW9uIGluaXRCYXNlVXJscyh0b3BMZXZlbE5hbWVzcGFjZXMpIHsKICAgIGZvciAodmFyIGkgaW4gdG9wTGV2ZWxOYW1lc3BhY2VzKQogICAgICAgIHRoaXMucmVxdWlyZS50bG5zW2ldID0gdG9wTGV2ZWxOYW1lc3BhY2VzW2ldOwp9OwoKd2luZG93LmluaXRTZW5kZXIgPSBmdW5jdGlvbiBpbml0U2VuZGVyKCkgewoKICAgIHZhciBFdmVudEVtaXR0ZXIgPSB3aW5kb3cucmVxdWlyZSgiYWNlL2xpYi9ldmVudF9lbWl0dGVyIikuRXZlbnRFbWl0dGVyOwogICAgdmFyIG9vcCA9IHdpbmRvdy5yZXF1aXJlKCJhY2UvbGliL29vcCIpOwogICAgCiAgICB2YXIgU2VuZGVyID0gZnVuY3Rpb24oKSB7fTsKICAgIAogICAgKGZ1bmN0aW9uKCkgewogICAgICAgIAogICAgICAgIG9vcC5pbXBsZW1lbnQodGhpcywgRXZlbnRFbWl0dGVyKTsKICAgICAgICAgICAgICAgIAogICAgICAgIHRoaXMuY2FsbGJhY2sgPSBmdW5jdGlvbihkYXRhLCBjYWxsYmFja0lkKSB7CiAgICAgICAgICAgIHBvc3RNZXNzYWdlKHsKICAgICAgICAgICAgICAgIHR5cGU6ICJjYWxsIiwKICAgICAgICAgICAgICAgIGlkOiBjYWxsYmFja0lkLAogICAgICAgICAgICAgICAgZGF0YTogZGF0YQogICAgICAgICAgICB9KTsKICAgICAgICB9OwogICAgCiAgICAgICAgdGhpcy5lbWl0ID0gZnVuY3Rpb24obmFtZSwgZGF0YSkgewogICAgICAgICAgICBwb3N0TWVzc2FnZSh7CiAgICAgICAgICAgICAgICB0eXBlOiAiZXZlbnQiLAogICAgICAgICAgICAgICAgbmFtZTogbmFtZSwKICAgICAgICAgICAgICAgIGRhdGE6IGRhdGEKICAgICAgICAgICAgfSk7CiAgICAgICAgfTsKICAgICAgICAKICAgIH0pLmNhbGwoU2VuZGVyLnByb3RvdHlwZSk7CiAgICAKICAgIHJldHVybiBuZXcgU2VuZGVyKCk7Cn07Cgp2YXIgbWFpbiA9IHdpbmRvdy5tYWluID0gbnVsbDsKdmFyIHNlbmRlciA9IHdpbmRvdy5zZW5kZXIgPSBudWxsOwoKd2luZG93Lm9ubWVzc2FnZSA9IGZ1bmN0aW9uKGUpIHsKICAgIHZhciBtc2cgPSBlLmRhdGE7CiAgICBpZiAobXNnLmV2ZW50ICYmIHNlbmRlcikgewogICAgICAgIHNlbmRlci5fc2lnbmFsKG1zZy5ldmVudCwgbXNnLmRhdGEpOwogICAgfQogICAgZWxzZSBpZiAobXNnLmNvbW1hbmQpIHsKICAgICAgICBpZiAobWFpblttc2cuY29tbWFuZF0pCiAgICAgICAgICAgIG1haW5bbXNnLmNvbW1hbmRdLmFwcGx5KG1haW4sIG1zZy5hcmdzKTsKICAgICAgICBlbHNlIGlmICh3aW5kb3dbbXNnLmNvbW1hbmRdKQogICAgICAgICAgICB3aW5kb3dbbXNnLmNvbW1hbmRdLmFwcGx5KHdpbmRvdywgbXNnLmFyZ3MpOwogICAgICAgIGVsc2UKICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCJVbmtub3duIGNvbW1hbmQ6IiArIG1zZy5jb21tYW5kKTsKICAgIH0KICAgIGVsc2UgaWYgKG1zZy5pbml0KSB7CiAgICAgICAgd2luZG93LmluaXRCYXNlVXJscyhtc2cudGxucyk7CiAgICAgICAgc2VuZGVyID0gd2luZG93LnNlbmRlciA9IHdpbmRvdy5pbml0U2VuZGVyKCk7CiAgICAgICAgdmFyIGNsYXp6ID0gdGhpcy5yZXF1aXJlKG1zZy5tb2R1bGUpW21zZy5jbGFzc25hbWVdOwogICAgICAgIG1haW4gPSB3aW5kb3cubWFpbiA9IG5ldyBjbGF6eihzZW5kZXIpOwogICAgfQp9Owp9KSh0aGlzKTsKCmFjZS5kZWZpbmUoImFjZS9saWIvb29wIixbXSwgZnVuY3Rpb24ocmVxdWlyZSwgZXhwb3J0cywgbW9kdWxlKXsidXNlIHN0cmljdCI7CmV4cG9ydHMuaW5oZXJpdHMgPSBmdW5jdGlvbiAoY3Rvciwgc3VwZXJDdG9yKSB7CiAgICBjdG9yLnN1cGVyXyA9IHN1cGVyQ3RvcjsKICAgIGN0b3IucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShzdXBlckN0b3IucHJvdG90eXBlLCB7CiAgICAgICAgY29uc3RydWN0b3I6IHsKICAgICAgICAgICAgdmFsdWU6IGN0b3IsCiAgICAgICAgICAgIGVudW1lcmFibGU6IGZhbHNlLAogICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSwKICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlCiAgICAgICAgfQogICAgfSk7Cn07CmV4cG9ydHMubWl4aW4gPSBmdW5jdGlvbiAob2JqLCBtaXhpbikgewogICAgZm9yICh2YXIga2V5IGluIG1peGluKSB7CiAgICAgICAgb2JqW2tleV0gPSBtaXhpbltrZXldOwogICAgfQogICAgcmV0dXJuIG9iajsKfTsKZXhwb3J0cy5pbXBsZW1lbnQgPSBmdW5jdGlvbiAocHJvdG8sIG1peGluKSB7CiAgICBleHBvcnRzLm1peGluKHByb3RvLCBtaXhpbik7Cn07Cgp9KTsKCmFjZS5kZWZpbmUoImFjZS9hcHBseV9kZWx0YSIsW10sIGZ1bmN0aW9uKHJlcXVpcmUsIGV4cG9ydHMsIG1vZHVsZSl7InVzZSBzdHJpY3QiOwpmdW5jdGlvbiB0aHJvd0RlbHRhRXJyb3IoZGVsdGEsIGVycm9yVGV4dCkgewogICAgY29uc29sZS5sb2coIkludmFsaWQgRGVsdGE6IiwgZGVsdGEpOwogICAgdGhyb3cgIkludmFsaWQgRGVsdGE6ICIgKyBlcnJvclRleHQ7Cn0KZnVuY3Rpb24gcG9zaXRpb25JbkRvY3VtZW50KGRvY0xpbmVzLCBwb3NpdGlvbikgewogICAgcmV0dXJuIHBvc2l0aW9uLnJvdyA+PSAwICYmIHBvc2l0aW9uLnJvdyA8IGRvY0xpbmVzLmxlbmd0aCAmJgogICAgICAgIHBvc2l0aW9uLmNvbHVtbiA+PSAwICYmIHBvc2l0aW9uLmNvbHVtbiA8PSBkb2NMaW5lc1twb3NpdGlvbi5yb3ddLmxlbmd0aDsKfQpmdW5jdGlvbiB2YWxpZGF0ZURlbHRhKGRvY0xpbmVzLCBkZWx0YSkgewogICAgaWYgKGRlbHRhLmFjdGlvbiAhPSAiaW5zZXJ0IiAmJiBkZWx0YS5hY3Rpb24gIT0gInJlbW92ZSIpCiAgICAgICAgdGhyb3dEZWx0YUVycm9yKGRlbHRhLCAiZGVsdGEuYWN0aW9uIG11c3QgYmUgJ2luc2VydCcgb3IgJ3JlbW92ZSciKTsKICAgIGlmICghKGRlbHRhLmxpbmVzIGluc3RhbmNlb2YgQXJyYXkpKQogICAgICAgIHRocm93RGVsdGFFcnJvcihkZWx0YSwgImRlbHRhLmxpbmVzIG11c3QgYmUgYW4gQXJyYXkiKTsKICAgIGlmICghZGVsdGEuc3RhcnQgfHwgIWRlbHRhLmVuZCkKICAgICAgICB0aHJvd0RlbHRhRXJyb3IoZGVsdGEsICJkZWx0YS5zdGFydC9lbmQgbXVzdCBiZSBhbiBwcmVzZW50Iik7CiAgICB2YXIgc3RhcnQgPSBkZWx0YS5zdGFydDsKICAgIGlmICghcG9zaXRpb25JbkRvY3VtZW50KGRvY0xpbmVzLCBkZWx0YS5zdGFydCkpCiAgICAgICAgdGhyb3dEZWx0YUVycm9yKGRlbHRhLCAiZGVsdGEuc3RhcnQgbXVzdCBiZSBjb250YWluZWQgaW4gZG9jdW1lbnQiKTsKICAgIHZhciBlbmQgPSBkZWx0YS5lbmQ7CiAgICBpZiAoZGVsdGEuYWN0aW9uID09ICJyZW1vdmUiICYmICFwb3NpdGlvbkluRG9jdW1lbnQoZG9jTGluZXMsIGVuZCkpCiAgICAgICAgdGhyb3dEZWx0YUVycm9yKGRlbHRhLCAiZGVsdGEuZW5kIG11c3QgY29udGFpbmVkIGluIGRvY3VtZW50IGZvciAncmVtb3ZlJyBhY3Rpb25zIik7CiAgICB2YXIgbnVtUmFuZ2VSb3dzID0gZW5kLnJvdyAtIHN0YXJ0LnJvdzsKICAgIHZhciBudW1SYW5nZUxhc3RMaW5lQ2hhcnMgPSAoZW5kLmNvbHVtbiAtIChudW1SYW5nZVJvd3MgPT0gMCA/IHN0YXJ0LmNvbHVtbiA6IDApKTsKICAgIGlmIChudW1SYW5nZVJvd3MgIT0gZGVsdGEubGluZXMubGVuZ3RoIC0gMSB8fCBkZWx0YS5saW5lc1tudW1SYW5nZVJvd3NdLmxlbmd0aCAhPSBudW1SYW5nZUxhc3RMaW5lQ2hhcnMpCiAgICAgICAgdGhyb3dEZWx0YUVycm9yKGRlbHRhLCAiZGVsdGEucmFuZ2UgbXVzdCBtYXRjaCBkZWx0YSBsaW5lcyIpOwp9CmV4cG9ydHMuYXBwbHlEZWx0YSA9IGZ1bmN0aW9uIChkb2NMaW5lcywgZGVsdGEsIGRvTm90VmFsaWRhdGUpIHsKICAgIHZhciByb3cgPSBkZWx0YS5zdGFydC5yb3c7CiAgICB2YXIgc3RhcnRDb2x1bW4gPSBkZWx0YS5zdGFydC5jb2x1bW47CiAgICB2YXIgbGluZSA9IGRvY0xpbmVzW3Jvd10gfHwgIiI7CiAgICBzd2l0Y2ggKGRlbHRhLmFjdGlvbikgewogICAgICAgIGNhc2UgImluc2VydCI6CiAgICAgICAgICAgIHZhciBsaW5lcyA9IGRlbHRhLmxpbmVzOwogICAgICAgICAgICBpZiAobGluZXMubGVuZ3RoID09PSAxKSB7CiAgICAgICAgICAgICAgICBkb2NMaW5lc1tyb3ddID0gbGluZS5zdWJzdHJpbmcoMCwgc3RhcnRDb2x1bW4pICsgZGVsdGEubGluZXNbMF0gKyBsaW5lLnN1YnN0cmluZyhzdGFydENvbHVtbik7CiAgICAgICAgICAgIH0KICAgICAgICAgICAgZWxzZSB7CiAgICAgICAgICAgICAgICB2YXIgYXJncyA9IFtyb3csIDFdLmNvbmNhdChkZWx0YS5saW5lcyk7CiAgICAgICAgICAgICAgICBkb2NMaW5lcy5zcGxpY2UuYXBwbHkoZG9jTGluZXMsIGFyZ3MpOwogICAgICAgICAgICAgICAgZG9jTGluZXNbcm93XSA9IGxpbmUuc3Vic3RyaW5nKDAsIHN0YXJ0Q29sdW1uKSArIGRvY0xpbmVzW3Jvd107CiAgICAgICAgICAgICAgICBkb2NMaW5lc1tyb3cgKyBkZWx0YS5saW5lcy5sZW5ndGggLSAxXSArPSBsaW5lLnN1YnN0cmluZyhzdGFydENvbHVtbik7CiAgICAgICAgICAgIH0KICAgICAgICAgICAgYnJlYWs7CiAgICAgICAgY2FzZSAicmVtb3ZlIjoKICAgICAgICAgICAgdmFyIGVuZENvbHVtbiA9IGRlbHRhLmVuZC5jb2x1bW47CiAgICAgICAgICAgIHZhciBlbmRSb3cgPSBkZWx0YS5lbmQucm93OwogICAgICAgICAgICBpZiAocm93ID09PSBlbmRSb3cpIHsKICAgICAgICAgICAgICAgIGRvY0xpbmVzW3Jvd10gPSBsaW5lLnN1YnN0cmluZygwLCBzdGFydENvbHVtbikgKyBsaW5lLnN1YnN0cmluZyhlbmRDb2x1bW4pOwogICAgICAgICAgICB9CiAgICAgICAgICAgIGVsc2UgewogICAgICAgICAgICAgICAgZG9jTGluZXMuc3BsaWNlKHJvdywgZW5kUm93IC0gcm93ICsgMSwgbGluZS5zdWJzdHJpbmcoMCwgc3RhcnRDb2x1bW4pICsgZG9jTGluZXNbZW5kUm93XS5zdWJzdHJpbmcoZW5kQ29sdW1uKSk7CiAgICAgICAgICAgIH0KICAgICAgICAgICAgYnJlYWs7CiAgICB9Cn07Cgp9KTsKCmFjZS5kZWZpbmUoImFjZS9saWIvZXZlbnRfZW1pdHRlciIsW10sIGZ1bmN0aW9uKHJlcXVpcmUsIGV4cG9ydHMsIG1vZHVsZSl7InVzZSBzdHJpY3QiOwp2YXIgRXZlbnRFbWl0dGVyID0ge307CnZhciBzdG9wUHJvcGFnYXRpb24gPSBmdW5jdGlvbiAoKSB7IHRoaXMucHJvcGFnYXRpb25TdG9wcGVkID0gdHJ1ZTsgfTsKdmFyIHByZXZlbnREZWZhdWx0ID0gZnVuY3Rpb24gKCkgeyB0aGlzLmRlZmF1bHRQcmV2ZW50ZWQgPSB0cnVlOyB9OwpFdmVudEVtaXR0ZXIuX2VtaXQgPQogICAgRXZlbnRFbWl0dGVyLl9kaXNwYXRjaEV2ZW50ID0gZnVuY3Rpb24gKGV2ZW50TmFtZSwgZSkgewogICAgICAgIHRoaXMuX2V2ZW50UmVnaXN0cnkgfHwgKHRoaXMuX2V2ZW50UmVnaXN0cnkgPSB7fSk7CiAgICAgICAgdGhpcy5fZGVmYXVsdEhhbmRsZXJzIHx8ICh0aGlzLl9kZWZhdWx0SGFuZGxlcnMgPSB7fSk7CiAgICAgICAgdmFyIGxpc3RlbmVycyA9IHRoaXMuX2V2ZW50UmVnaXN0cnlbZXZlbnROYW1lXSB8fCBbXTsKICAgICAgICB2YXIgZGVmYXVsdEhhbmRsZXIgPSB0aGlzLl9kZWZhdWx0SGFuZGxlcnNbZXZlbnROYW1lXTsKICAgICAgICBpZiAoIWxpc3RlbmVycy5sZW5ndGggJiYgIWRlZmF1bHRIYW5kbGVyKQogICAgICAgICAgICByZXR1cm47CiAgICAgICAgaWYgKHR5cGVvZiBlICE9ICJvYmplY3QiIHx8ICFlKQogICAgICAgICAgICBlID0ge307CiAgICAgICAgaWYgKCFlLnR5cGUpCiAgICAgICAgICAgIGUudHlwZSA9IGV2ZW50TmFtZTsKICAgICAgICBpZiAoIWUuc3RvcFByb3BhZ2F0aW9uKQogICAgICAgICAgICBlLnN0b3BQcm9wYWdhdGlvbiA9IHN0b3BQcm9wYWdhdGlvbjsKICAgICAgICBpZiAoIWUucHJldmVudERlZmF1bHQpCiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQgPSBwcmV2ZW50RGVmYXVsdDsKICAgICAgICBsaXN0ZW5lcnMgPSBsaXN0ZW5lcnMuc2xpY2UoKTsKICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxpc3RlbmVycy5sZW5ndGg7IGkrKykgewogICAgICAgICAgICBsaXN0ZW5lcnNbaV0oZSwgdGhpcyk7CiAgICAgICAgICAgIGlmIChlLnByb3BhZ2F0aW9uU3RvcHBlZCkKICAgICAgICAgICAgICAgIGJyZWFrOwogICAgICAgIH0KICAgICAgICBpZiAoZGVmYXVsdEhhbmRsZXIgJiYgIWUuZGVmYXVsdFByZXZlbnRlZCkKICAgICAgICAgICAgcmV0dXJuIGRlZmF1bHRIYW5kbGVyKGUsIHRoaXMpOwogICAgfTsKRXZlbnRFbWl0dGVyLl9zaWduYWwgPSBmdW5jdGlvbiAoZXZlbnROYW1lLCBlKSB7CiAgICB2YXIgbGlzdGVuZXJzID0gKHRoaXMuX2V2ZW50UmVnaXN0cnkgfHwge30pW2V2ZW50TmFtZV07CiAgICBpZiAoIWxpc3RlbmVycykKICAgICAgICByZXR1cm47CiAgICBsaXN0ZW5lcnMgPSBsaXN0ZW5lcnMuc2xpY2UoKTsKICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGlzdGVuZXJzLmxlbmd0aDsgaSsrKQogICAgICAgIGxpc3RlbmVyc1tpXShlLCB0aGlzKTsKfTsKRXZlbnRFbWl0dGVyLm9uY2UgPSBmdW5jdGlvbiAoZXZlbnROYW1lLCBjYWxsYmFjaykgewogICAgdmFyIF9zZWxmID0gdGhpczsKICAgIHRoaXMub24oZXZlbnROYW1lLCBmdW5jdGlvbiBuZXdDYWxsYmFjaygpIHsKICAgICAgICBfc2VsZi5vZmYoZXZlbnROYW1lLCBuZXdDYWxsYmFjayk7CiAgICAgICAgY2FsbGJhY2suYXBwbHkobnVsbCwgYXJndW1lbnRzKTsKICAgIH0pOwogICAgaWYgKCFjYWxsYmFjaykgewogICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbiAocmVzb2x2ZSkgewogICAgICAgICAgICBjYWxsYmFjayA9IHJlc29sdmU7CiAgICAgICAgfSk7CiAgICB9Cn07CkV2ZW50RW1pdHRlci5zZXREZWZhdWx0SGFuZGxlciA9IGZ1bmN0aW9uIChldmVudE5hbWUsIGNhbGxiYWNrKSB7CiAgICB2YXIgaGFuZGxlcnMgPSB0aGlzLl9kZWZhdWx0SGFuZGxlcnM7CiAgICBpZiAoIWhhbmRsZXJzKQogICAgICAgIGhhbmRsZXJzID0gdGhpcy5fZGVmYXVsdEhhbmRsZXJzID0geyBfZGlzYWJsZWRfOiB7fSB9OwogICAgaWYgKGhhbmRsZXJzW2V2ZW50TmFtZV0pIHsKICAgICAgICB2YXIgb2xkID0gaGFuZGxlcnNbZXZlbnROYW1lXTsKICAgICAgICB2YXIgZGlzYWJsZWQgPSBoYW5kbGVycy5fZGlzYWJsZWRfW2V2ZW50TmFtZV07CiAgICAgICAgaWYgKCFkaXNhYmxlZCkKICAgICAgICAgICAgaGFuZGxlcnMuX2Rpc2FibGVkX1tldmVudE5hbWVdID0gZGlzYWJsZWQgPSBbXTsKICAgICAgICBkaXNhYmxlZC5wdXNoKG9sZCk7CiAgICAgICAgdmFyIGkgPSBkaXNhYmxlZC5pbmRleE9mKGNhbGxiYWNrKTsKICAgICAgICBpZiAoaSAhPSAtMSkKICAgICAgICAgICAgZGlzYWJsZWQuc3BsaWNlKGksIDEpOwogICAgfQogICAgaGFuZGxlcnNbZXZlbnROYW1lXSA9IGNhbGxiYWNrOwp9OwpFdmVudEVtaXR0ZXIucmVtb3ZlRGVmYXVsdEhhbmRsZXIgPSBmdW5jdGlvbiAoZXZlbnROYW1lLCBjYWxsYmFjaykgewogICAgdmFyIGhhbmRsZXJzID0gdGhpcy5fZGVmYXVsdEhhbmRsZXJzOwogICAgaWYgKCFoYW5kbGVycykKICAgICAgICByZXR1cm47CiAgICB2YXIgZGlzYWJsZWQgPSBoYW5kbGVycy5fZGlzYWJsZWRfW2V2ZW50TmFtZV07CiAgICBpZiAoaGFuZGxlcnNbZXZlbnROYW1lXSA9PSBjYWxsYmFjaykgewogICAgICAgIGlmIChkaXNhYmxlZCkKICAgICAgICAgICAgdGhpcy5zZXREZWZhdWx0SGFuZGxlcihldmVudE5hbWUsIGRpc2FibGVkLnBvcCgpKTsKICAgIH0KICAgIGVsc2UgaWYgKGRpc2FibGVkKSB7CiAgICAgICAgdmFyIGkgPSBkaXNhYmxlZC5pbmRleE9mKGNhbGxiYWNrKTsKICAgICAgICBpZiAoaSAhPSAtMSkKICAgICAgICAgICAgZGlzYWJsZWQuc3BsaWNlKGksIDEpOwogICAgfQp9OwpFdmVudEVtaXR0ZXIub24gPQogICAgRXZlbnRFbWl0dGVyLmFkZEV2ZW50TGlzdGVuZXIgPSBmdW5jdGlvbiAoZXZlbnROYW1lLCBjYWxsYmFjaywgY2FwdHVyaW5nKSB7CiAgICAgICAgdGhpcy5fZXZlbnRSZWdpc3RyeSA9IHRoaXMuX2V2ZW50UmVnaXN0cnkgfHwge307CiAgICAgICAgdmFyIGxpc3RlbmVycyA9IHRoaXMuX2V2ZW50UmVnaXN0cnlbZXZlbnROYW1lXTsKICAgICAgICBpZiAoIWxpc3RlbmVycykKICAgICAgICAgICAgbGlzdGVuZXJzID0gdGhpcy5fZXZlbnRSZWdpc3RyeVtldmVudE5hbWVdID0gW107CiAgICAgICAgaWYgKGxpc3RlbmVycy5pbmRleE9mKGNhbGxiYWNrKSA9PSAtMSkKICAgICAgICAgICAgbGlzdGVuZXJzW2NhcHR1cmluZyA/ICJ1bnNoaWZ0IiA6ICJwdXNoIl0oY2FsbGJhY2spOwogICAgICAgIHJldHVybiBjYWxsYmFjazsKICAgIH07CkV2ZW50RW1pdHRlci5vZmYgPQogICAgRXZlbnRFbWl0dGVyLnJlbW92ZUxpc3RlbmVyID0KICAgICAgICBFdmVudEVtaXR0ZXIucmVtb3ZlRXZlbnRMaXN0ZW5lciA9IGZ1bmN0aW9uIChldmVudE5hbWUsIGNhbGxiYWNrKSB7CiAgICAgICAgICAgIHRoaXMuX2V2ZW50UmVnaXN0cnkgPSB0aGlzLl9ldmVudFJlZ2lzdHJ5IHx8IHt9OwogICAgICAgICAgICB2YXIgbGlzdGVuZXJzID0gdGhpcy5fZXZlbnRSZWdpc3RyeVtldmVudE5hbWVdOwogICAgICAgICAgICBpZiAoIWxpc3RlbmVycykKICAgICAgICAgICAgICAgIHJldHVybjsKICAgICAgICAgICAgdmFyIGluZGV4ID0gbGlzdGVuZXJzLmluZGV4T2YoY2FsbGJhY2spOwogICAgICAgICAgICBpZiAoaW5kZXggIT09IC0xKQogICAgICAgICAgICAgICAgbGlzdGVuZXJzLnNwbGljZShpbmRleCwgMSk7CiAgICAgICAgfTsKRXZlbnRFbWl0dGVyLnJlbW92ZUFsbExpc3RlbmVycyA9IGZ1bmN0aW9uIChldmVudE5hbWUpIHsKICAgIGlmICghZXZlbnROYW1lKQogICAgICAgIHRoaXMuX2V2ZW50UmVnaXN0cnkgPSB0aGlzLl9kZWZhdWx0SGFuZGxlcnMgPSB1bmRlZmluZWQ7CiAgICBpZiAodGhpcy5fZXZlbnRSZWdpc3RyeSkKICAgICAgICB0aGlzLl9ldmVudFJlZ2lzdHJ5W2V2ZW50TmFtZV0gPSB1bmRlZmluZWQ7CiAgICBpZiAodGhpcy5fZGVmYXVsdEhhbmRsZXJzKQogICAgICAgIHRoaXMuX2RlZmF1bHRIYW5kbGVyc1tldmVudE5hbWVdID0gdW5kZWZpbmVkOwp9OwpleHBvcnRzLkV2ZW50RW1pdHRlciA9IEV2ZW50RW1pdHRlcjsKCn0pOwoKYWNlLmRlZmluZSgiYWNlL3JhbmdlIixbXSwgZnVuY3Rpb24ocmVxdWlyZSwgZXhwb3J0cywgbW9kdWxlKXsidXNlIHN0cmljdCI7CnZhciBSYW5nZSA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHsKICAgIGZ1bmN0aW9uIFJhbmdlKHN0YXJ0Um93LCBzdGFydENvbHVtbiwgZW5kUm93LCBlbmRDb2x1bW4pIHsKICAgICAgICB0aGlzLnN0YXJ0ID0gewogICAgICAgICAgICByb3c6IHN0YXJ0Um93LAogICAgICAgICAgICBjb2x1bW46IHN0YXJ0Q29sdW1uCiAgICAgICAgfTsKICAgICAgICB0aGlzLmVuZCA9IHsKICAgICAgICAgICAgcm93OiBlbmRSb3csCiAgICAgICAgICAgIGNvbHVtbjogZW5kQ29sdW1uCiAgICAgICAgfTsKICAgIH0KICAgIFJhbmdlLnByb3RvdHlwZS5pc0VxdWFsID0gZnVuY3Rpb24gKHJhbmdlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuc3RhcnQucm93ID09PSByYW5nZS5zdGFydC5yb3cgJiYKICAgICAgICAgICAgdGhpcy5lbmQucm93ID09PSByYW5nZS5lbmQucm93ICYmCiAgICAgICAgICAgIHRoaXMuc3RhcnQuY29sdW1uID09PSByYW5nZS5zdGFydC5jb2x1bW4gJiYKICAgICAgICAgICAgdGhpcy5lbmQuY29sdW1uID09PSByYW5nZS5lbmQuY29sdW1uOwogICAgfTsKICAgIFJhbmdlLnByb3RvdHlwZS50b1N0cmluZyA9IGZ1bmN0aW9uICgpIHsKICAgICAgICByZXR1cm4gKCJSYW5nZTogWyIgKyB0aGlzLnN0YXJ0LnJvdyArICIvIiArIHRoaXMuc3RhcnQuY29sdW1uICsKICAgICAgICAgICAgIl0gLT4gWyIgKyB0aGlzLmVuZC5yb3cgKyAiLyIgKyB0aGlzLmVuZC5jb2x1bW4gKyAiXSIpOwogICAgfTsKICAgIFJhbmdlLnByb3RvdHlwZS5jb250YWlucyA9IGZ1bmN0aW9uIChyb3csIGNvbHVtbikgewogICAgICAgIHJldHVybiB0aGlzLmNvbXBhcmUocm93LCBjb2x1bW4pID09IDA7CiAgICB9OwogICAgUmFuZ2UucHJvdG90eXBlLmNvbXBhcmVSYW5nZSA9IGZ1bmN0aW9uIChyYW5nZSkgewogICAgICAgIHZhciBjbXAsIGVuZCA9IHJhbmdlLmVuZCwgc3RhcnQgPSByYW5nZS5zdGFydDsKICAgICAgICBjbXAgPSB0aGlzLmNvbXBhcmUoZW5kLnJvdywgZW5kLmNvbHVtbik7CiAgICAgICAgaWYgKGNtcCA9PSAxKSB7CiAgICAgICAgICAgIGNtcCA9IHRoaXMuY29tcGFyZShzdGFydC5yb3csIHN0YXJ0LmNvbHVtbik7CiAgICAgICAgICAgIGlmIChjbXAgPT0gMSkgewogICAgICAgICAgICAgICAgcmV0dXJuIDI7CiAgICAgICAgICAgIH0KICAgICAgICAgICAgZWxzZSBpZiAoY21wID09IDApIHsKICAgICAgICAgICAgICAgIHJldHVybiAxOwogICAgICAgICAgICB9CiAgICAgICAgICAgIGVsc2UgewogICAgICAgICAgICAgICAgcmV0dXJuIDA7CiAgICAgICAgICAgIH0KICAgICAgICB9CiAgICAgICAgZWxzZSBpZiAoY21wID09IC0xKSB7CiAgICAgICAgICAgIHJldHVybiAtMjsKICAgICAgICB9CiAgICAgICAgZWxzZSB7CiAgICAgICAgICAgIGNtcCA9IHRoaXMuY29tcGFyZShzdGFydC5yb3csIHN0YXJ0LmNvbHVtbik7CiAgICAgICAgICAgIGlmIChjbXAgPT0gLTEpIHsKICAgICAgICAgICAgICAgIHJldHVybiAtMTsKICAgICAgICAgICAgfQogICAgICAgICAgICBlbHNlIGlmIChjbXAgPT0gMSkgewogICAgICAgICAgICAgICAgcmV0dXJuIDQyOwogICAgICAgICAgICB9CiAgICAgICAgICAgIGVsc2UgewogICAgICAgICAgICAgICAgcmV0dXJuIDA7CiAgICAgICAgICAgIH0KICAgICAgICB9CiAgICB9OwogICAgUmFuZ2UucHJvdG90eXBlLmNvbXBhcmVQb2ludCA9IGZ1bmN0aW9uIChwKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuY29tcGFyZShwLnJvdywgcC5jb2x1bW4pOwogICAgfTsKICAgIFJhbmdlLnByb3RvdHlwZS5jb250YWluc1JhbmdlID0gZnVuY3Rpb24gKHJhbmdlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuY29tcGFyZVBvaW50KHJhbmdlLnN0YXJ0KSA9PSAwICYmIHRoaXMuY29tcGFyZVBvaW50KHJhbmdlLmVuZCkgPT0gMDsKICAgIH07CiAgICBSYW5nZS5wcm90b3R5cGUuaW50ZXJzZWN0cyA9IGZ1bmN0aW9uIChyYW5nZSkgewogICAgICAgIHZhciBjbXAgPSB0aGlzLmNvbXBhcmVSYW5nZShyYW5nZSk7CiAgICAgICAgcmV0dXJuIChjbXAgPT0gLTEgfHwgY21wID09IDAgfHwgY21wID09IDEpOwogICAgfTsKICAgIFJhbmdlLnByb3RvdHlwZS5pc0VuZCA9IGZ1bmN0aW9uIChyb3csIGNvbHVtbikgewogICAgICAgIHJldHVybiB0aGlzLmVuZC5yb3cgPT0gcm93ICYmIHRoaXMuZW5kLmNvbHVtbiA9PSBjb2x1bW47CiAgICB9OwogICAgUmFuZ2UucHJvdG90eXBlLmlzU3RhcnQgPSBmdW5jdGlvbiAocm93LCBjb2x1bW4pIHsKICAgICAgICByZXR1cm4gdGhpcy5zdGFydC5yb3cgPT0gcm93ICYmIHRoaXMuc3RhcnQuY29sdW1uID09IGNvbHVtbjsKICAgIH07CiAgICBSYW5nZS5wcm90b3R5cGUuc2V0U3RhcnQgPSBmdW5jdGlvbiAocm93LCBjb2x1bW4pIHsKICAgICAgICBpZiAodHlwZW9mIHJvdyA9PSAib2JqZWN0IikgewogICAgICAgICAgICB0aGlzLnN0YXJ0LmNvbHVtbiA9IHJvdy5jb2x1bW47CiAgICAgICAgICAgIHRoaXMuc3RhcnQucm93ID0gcm93LnJvdzsKICAgICAgICB9CiAgICAgICAgZWxzZSB7CiAgICAgICAgICAgIHRoaXMuc3RhcnQucm93ID0gcm93OwogICAgICAgICAgICB0aGlzLnN0YXJ0LmNvbHVtbiA9IGNvbHVtbjsKICAgICAgICB9CiAgICB9OwogICAgUmFuZ2UucHJvdG90eXBlLnNldEVuZCA9IGZ1bmN0aW9uIChyb3csIGNvbHVtbikgewogICAgICAgIGlmICh0eXBlb2Ygcm93ID09ICJvYmplY3QiKSB7CiAgICAgICAgICAgIHRoaXMuZW5kLmNvbHVtbiA9IHJvdy5jb2x1bW47CiAgICAgICAgICAgIHRoaXMuZW5kLnJvdyA9IHJvdy5yb3c7CiAgICAgICAgfQogICAgICAgIGVsc2UgewogICAgICAgICAgICB0aGlzLmVuZC5yb3cgPSByb3c7CiAgICAgICAgICAgIHRoaXMuZW5kLmNvbHVtbiA9IGNvbHVtbjsKICAgICAgICB9CiAgICB9OwogICAgUmFuZ2UucHJvdG90eXBlLmluc2lkZSA9IGZ1bmN0aW9uIChyb3csIGNvbHVtbikgewogICAgICAgIGlmICh0aGlzLmNvbXBhcmUocm93LCBjb2x1bW4pID09IDApIHsKICAgICAgICAgICAgaWYgKHRoaXMuaXNFbmQocm93LCBjb2x1bW4pIHx8IHRoaXMuaXNTdGFydChyb3csIGNvbHVtbikpIHsKICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTsKICAgICAgICAgICAgfQogICAgICAgICAgICBlbHNlIHsKICAgICAgICAgICAgICAgIHJldHVybiB0cnVlOwogICAgICAgICAgICB9CiAgICAgICAgfQogICAgICAgIHJldHVybiBmYWxzZTsKICAgIH07CiAgICBSYW5nZS5wcm90b3R5cGUuaW5zaWRlU3RhcnQgPSBmdW5jdGlvbiAocm93LCBjb2x1bW4pIHsKICAgICAgICBpZiAodGhpcy5jb21wYXJlKHJvdywgY29sdW1uKSA9PSAwKSB7CiAgICAgICAgICAgIGlmICh0aGlzLmlzRW5kKHJvdywgY29sdW1uKSkgewogICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgICAgICAgICB9CiAgICAgICAgICAgIGVsc2UgewogICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7CiAgICAgICAgICAgIH0KICAgICAgICB9CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfTsKICAgIFJhbmdlLnByb3RvdHlwZS5pbnNpZGVFbmQgPSBmdW5jdGlvbiAocm93LCBjb2x1bW4pIHsKICAgICAgICBpZiAodGhpcy5jb21wYXJlKHJvdywgY29sdW1uKSA9PSAwKSB7CiAgICAgICAgICAgIGlmICh0aGlzLmlzU3RhcnQocm93LCBjb2x1bW4pKSB7CiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7CiAgICAgICAgICAgIH0KICAgICAgICAgICAgZWxzZSB7CiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTsKICAgICAgICAgICAgfQogICAgICAgIH0KICAgICAgICByZXR1cm4gZmFsc2U7CiAgICB9OwogICAgUmFuZ2UucHJvdG90eXBlLmNvbXBhcmUgPSBmdW5jdGlvbiAocm93LCBjb2x1bW4pIHsKICAgICAgICBpZiAoIXRoaXMuaXNNdWx0aUxpbmUoKSkgewogICAgICAgICAgICBpZiAocm93ID09PSB0aGlzLnN0YXJ0LnJvdykgewogICAgICAgICAgICAgICAgcmV0dXJuIGNvbHVtbiA8IHRoaXMuc3RhcnQuY29sdW1uID8gLTEgOiAoY29sdW1uID4gdGhpcy5lbmQuY29sdW1uID8gMSA6IDApOwogICAgICAgICAgICB9CiAgICAgICAgfQogICAgICAgIGlmIChyb3cgPCB0aGlzLnN0YXJ0LnJvdykKICAgICAgICAgICAgcmV0dXJuIC0xOwogICAgICAgIGlmIChyb3cgPiB0aGlzLmVuZC5yb3cpCiAgICAgICAgICAgIHJldHVybiAxOwogICAgICAgIGlmICh0aGlzLnN0YXJ0LnJvdyA9PT0gcm93KQogICAgICAgICAgICByZXR1cm4gY29sdW1uID49IHRoaXMuc3RhcnQuY29sdW1uID8gMCA6IC0xOwogICAgICAgIGlmICh0aGlzLmVuZC5yb3cgPT09IHJvdykKICAgICAgICAgICAgcmV0dXJuIGNvbHVtbiA8PSB0aGlzLmVuZC5jb2x1bW4gPyAwIDogMTsKICAgICAgICByZXR1cm4gMDsKICAgIH07CiAgICBSYW5nZS5wcm90b3R5cGUuY29tcGFyZVN0YXJ0ID0gZnVuY3Rpb24gKHJvdywgY29sdW1uKSB7CiAgICAgICAgaWYgKHRoaXMuc3RhcnQucm93ID09IHJvdyAmJiB0aGlzLnN0YXJ0LmNvbHVtbiA9PSBjb2x1bW4pIHsKICAgICAgICAgICAgcmV0dXJuIC0xOwogICAgICAgIH0KICAgICAgICBlbHNlIHsKICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29tcGFyZShyb3csIGNvbHVtbik7CiAgICAgICAgfQogICAgfTsKICAgIFJhbmdlLnByb3RvdHlwZS5jb21wYXJlRW5kID0gZnVuY3Rpb24gKHJvdywgY29sdW1uKSB7CiAgICAgICAgaWYgKHRoaXMuZW5kLnJvdyA9PSByb3cgJiYgdGhpcy5lbmQuY29sdW1uID09IGNvbHVtbikgewogICAgICAgICAgICByZXR1cm4gMTsKICAgICAgICB9CiAgICAgICAgZWxzZSB7CiAgICAgICAgICAgIHJldHVybiB0aGlzLmNvbXBhcmUocm93LCBjb2x1bW4pOwogICAgICAgIH0KICAgIH07CiAgICBSYW5nZS5wcm90b3R5cGUuY29tcGFyZUluc2lkZSA9IGZ1bmN0aW9uIChyb3csIGNvbHVtbikgewogICAgICAgIGlmICh0aGlzLmVuZC5yb3cgPT0gcm93ICYmIHRoaXMuZW5kLmNvbHVtbiA9PSBjb2x1bW4pIHsKICAgICAgICAgICAgcmV0dXJuIDE7CiAgICAgICAgfQogICAgICAgIGVsc2UgaWYgKHRoaXMuc3RhcnQucm93ID09IHJvdyAmJiB0aGlzLnN0YXJ0LmNvbHVtbiA9PSBjb2x1bW4pIHsKICAgICAgICAgICAgcmV0dXJuIC0xOwogICAgICAgIH0KICAgICAgICBlbHNlIHsKICAgICAgICAgICAgcmV0dXJuIHRoaXMuY29tcGFyZShyb3csIGNvbHVtbik7CiAgICAgICAgfQogICAgfTsKICAgIFJhbmdlLnByb3RvdHlwZS5jbGlwUm93cyA9IGZ1bmN0aW9uIChmaXJzdFJvdywgbGFzdFJvdykgewogICAgICAgIGlmICh0aGlzLmVuZC5yb3cgPiBsYXN0Um93KQogICAgICAgICAgICB2YXIgZW5kID0geyByb3c6IGxhc3RSb3cgKyAxLCBjb2x1bW46IDAgfTsKICAgICAgICBlbHNlIGlmICh0aGlzLmVuZC5yb3cgPCBmaXJzdFJvdykKICAgICAgICAgICAgdmFyIGVuZCA9IHsgcm93OiBmaXJzdFJvdywgY29sdW1uOiAwIH07CiAgICAgICAgaWYgKHRoaXMuc3RhcnQucm93ID4gbGFzdFJvdykKICAgICAgICAgICAgdmFyIHN0YXJ0ID0geyByb3c6IGxhc3RSb3cgKyAxLCBjb2x1bW46IDAgfTsKICAgICAgICBlbHNlIGlmICh0aGlzLnN0YXJ0LnJvdyA8IGZpcnN0Um93KQogICAgICAgICAgICB2YXIgc3RhcnQgPSB7IHJvdzogZmlyc3RSb3csIGNvbHVtbjogMCB9OwogICAgICAgIHJldHVybiBSYW5nZS5mcm9tUG9pbnRzKHN0YXJ0IHx8IHRoaXMuc3RhcnQsIGVuZCB8fCB0aGlzLmVuZCk7CiAgICB9OwogICAgUmFuZ2UucHJvdG90eXBlLmV4dGVuZCA9IGZ1bmN0aW9uIChyb3csIGNvbHVtbikgewogICAgICAgIHZhciBjbXAgPSB0aGlzLmNvbXBhcmUocm93LCBjb2x1bW4pOwogICAgICAgIGlmIChjbXAgPT0gMCkKICAgICAgICAgICAgcmV0dXJuIHRoaXM7CiAgICAgICAgZWxzZSBpZiAoY21wID09IC0xKQogICAgICAgICAgICB2YXIgc3RhcnQgPSB7IHJvdzogcm93LCBjb2x1bW46IGNvbHVtbiB9OwogICAgICAgIGVsc2UKICAgICAgICAgICAgdmFyIGVuZCA9IHsgcm93OiByb3csIGNvbHVtbjogY29sdW1uIH07CiAgICAgICAgcmV0dXJuIFJhbmdlLmZyb21Qb2ludHMoc3RhcnQgfHwgdGhpcy5zdGFydCwgZW5kIHx8IHRoaXMuZW5kKTsKICAgIH07CiAgICBSYW5nZS5wcm90b3R5cGUuaXNFbXB0eSA9IGZ1bmN0aW9uICgpIHsKICAgICAgICByZXR1cm4gKHRoaXMuc3RhcnQucm93ID09PSB0aGlzLmVuZC5yb3cgJiYgdGhpcy5zdGFydC5jb2x1bW4gPT09IHRoaXMuZW5kLmNvbHVtbik7CiAgICB9OwogICAgUmFuZ2UucHJvdG90eXBlLmlzTXVsdGlMaW5lID0gZnVuY3Rpb24gKCkgewogICAgICAgIHJldHVybiAodGhpcy5zdGFydC5yb3cgIT09IHRoaXMuZW5kLnJvdyk7CiAgICB9OwogICAgUmFuZ2UucHJvdG90eXBlLmNsb25lID0gZnVuY3Rpb24gKCkgewogICAgICAgIHJldHVybiBSYW5nZS5mcm9tUG9pbnRzKHRoaXMuc3RhcnQsIHRoaXMuZW5kKTsKICAgIH07CiAgICBSYW5nZS5wcm90b3R5cGUuY29sbGFwc2VSb3dzID0gZnVuY3Rpb24gKCkgewogICAgICAgIGlmICh0aGlzLmVuZC5jb2x1bW4gPT0gMCkKICAgICAgICAgICAgcmV0dXJuIG5ldyBSYW5nZSh0aGlzLnN0YXJ0LnJvdywgMCwgTWF0aC5tYXgodGhpcy5zdGFydC5yb3csIHRoaXMuZW5kLnJvdyAtIDEpLCAwKTsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHJldHVybiBuZXcgUmFuZ2UodGhpcy5zdGFydC5yb3csIDAsIHRoaXMuZW5kLnJvdywgMCk7CiAgICB9OwogICAgUmFuZ2UucHJvdG90eXBlLnRvU2NyZWVuUmFuZ2UgPSBmdW5jdGlvbiAoc2Vzc2lvbikgewogICAgICAgIHZhciBzY3JlZW5Qb3NTdGFydCA9IHNlc3Npb24uZG9jdW1lbnRUb1NjcmVlblBvc2l0aW9uKHRoaXMuc3RhcnQpOwogICAgICAgIHZhciBzY3JlZW5Qb3NFbmQgPSBzZXNzaW9uLmRvY3VtZW50VG9TY3JlZW5Qb3NpdGlvbih0aGlzLmVuZCk7CiAgICAgICAgcmV0dXJuIG5ldyBSYW5nZShzY3JlZW5Qb3NTdGFydC5yb3csIHNjcmVlblBvc1N0YXJ0LmNvbHVtbiwgc2NyZWVuUG9zRW5kLnJvdywgc2NyZWVuUG9zRW5kLmNvbHVtbik7CiAgICB9OwogICAgUmFuZ2UucHJvdG90eXBlLm1vdmVCeSA9IGZ1bmN0aW9uIChyb3csIGNvbHVtbikgewogICAgICAgIHRoaXMuc3RhcnQucm93ICs9IHJvdzsKICAgICAgICB0aGlzLnN0YXJ0LmNvbHVtbiArPSBjb2x1bW47CiAgICAgICAgdGhpcy5lbmQucm93ICs9IHJvdzsKICAgICAgICB0aGlzLmVuZC5jb2x1bW4gKz0gY29sdW1uOwogICAgfTsKICAgIHJldHVybiBSYW5nZTsKfSgpKTsKUmFuZ2UuZnJvbVBvaW50cyA9IGZ1bmN0aW9uIChzdGFydCwgZW5kKSB7CiAgICByZXR1cm4gbmV3IFJhbmdlKHN0YXJ0LnJvdywgc3RhcnQuY29sdW1uLCBlbmQucm93LCBlbmQuY29sdW1uKTsKfTsKUmFuZ2UuY29tcGFyZVBvaW50cyA9IGZ1bmN0aW9uIChwMSwgcDIpIHsKICAgIHJldHVybiBwMS5yb3cgLSBwMi5yb3cgfHwgcDEuY29sdW1uIC0gcDIuY29sdW1uOwp9OwpleHBvcnRzLlJhbmdlID0gUmFuZ2U7Cgp9KTsKCmFjZS5kZWZpbmUoImFjZS9hbmNob3IiLFtdLCBmdW5jdGlvbihyZXF1aXJlLCBleHBvcnRzLCBtb2R1bGUpeyJ1c2Ugc3RyaWN0IjsKdmFyIG9vcCA9IHJlcXVpcmUoIi4vbGliL29vcCIpOwp2YXIgRXZlbnRFbWl0dGVyID0gcmVxdWlyZSgiLi9saWIvZXZlbnRfZW1pdHRlciIpLkV2ZW50RW1pdHRlcjsKdmFyIEFuY2hvciA9IC8qKiBAY2xhc3MgKi8gKGZ1bmN0aW9uICgpIHsKICAgIGZ1bmN0aW9uIEFuY2hvcihkb2MsIHJvdywgY29sdW1uKSB7CiAgICAgICAgdGhpcy4kb25DaGFuZ2UgPSB0aGlzLm9uQ2hhbmdlLmJpbmQodGhpcyk7CiAgICAgICAgdGhpcy5hdHRhY2goZG9jKTsKICAgICAgICBpZiAodHlwZW9mIHJvdyAhPSAibnVtYmVyIikKICAgICAgICAgICAgdGhpcy5zZXRQb3NpdGlvbihyb3cucm93LCByb3cuY29sdW1uKTsKICAgICAgICBlbHNlCiAgICAgICAgICAgIHRoaXMuc2V0UG9zaXRpb24ocm93LCBjb2x1bW4pOwogICAgfQogICAgQW5jaG9yLnByb3RvdHlwZS5nZXRQb3NpdGlvbiA9IGZ1bmN0aW9uICgpIHsKICAgICAgICByZXR1cm4gdGhpcy4kY2xpcFBvc2l0aW9uVG9Eb2N1bWVudCh0aGlzLnJvdywgdGhpcy5jb2x1bW4pOwogICAgfTsKICAgIEFuY2hvci5wcm90b3R5cGUuZ2V0RG9jdW1lbnQgPSBmdW5jdGlvbiAoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuZG9jdW1lbnQ7CiAgICB9OwogICAgQW5jaG9yLnByb3RvdHlwZS5vbkNoYW5nZSA9IGZ1bmN0aW9uIChkZWx0YSkgewogICAgICAgIGlmIChkZWx0YS5zdGFydC5yb3cgPT0gZGVsdGEuZW5kLnJvdyAmJiBkZWx0YS5zdGFydC5yb3cgIT0gdGhpcy5yb3cpCiAgICAgICAgICAgIHJldHVybjsKICAgICAgICBpZiAoZGVsdGEuc3RhcnQucm93ID4gdGhpcy5yb3cpCiAgICAgICAgICAgIHJldHVybjsKICAgICAgICB2YXIgcG9pbnQgPSAkZ2V0VHJhbnNmb3JtZWRQb2ludChkZWx0YSwgeyByb3c6IHRoaXMucm93LCBjb2x1bW46IHRoaXMuY29sdW1uIH0sIHRoaXMuJGluc2VydFJpZ2h0KTsKICAgICAgICB0aGlzLnNldFBvc2l0aW9uKHBvaW50LnJvdywgcG9pbnQuY29sdW1uLCB0cnVlKTsKICAgIH07CiAgICBBbmNob3IucHJvdG90eXBlLnNldFBvc2l0aW9uID0gZnVuY3Rpb24gKHJvdywgY29sdW1uLCBub0NsaXApIHsKICAgICAgICB2YXIgcG9zOwogICAgICAgIGlmIChub0NsaXApIHsKICAgICAgICAgICAgcG9zID0gewogICAgICAgICAgICAgICAgcm93OiByb3csCiAgICAgICAgICAgICAgICBjb2x1bW46IGNvbHVtbgogICAgICAgICAgICB9OwogICAgICAgIH0KICAgICAgICBlbHNlIHsKICAgICAgICAgICAgcG9zID0gdGhpcy4kY2xpcFBvc2l0aW9uVG9Eb2N1bWVudChyb3csIGNvbHVtbik7CiAgICAgICAgfQogICAgICAgIGlmICh0aGlzLnJvdyA9PSBwb3Mucm93ICYmIHRoaXMuY29sdW1uID09IHBvcy5jb2x1bW4pCiAgICAgICAgICAgIHJldHVybjsKICAgICAgICB2YXIgb2xkID0gewogICAgICAgICAgICByb3c6IHRoaXMucm93LAogICAgICAgICAgICBjb2x1bW46IHRoaXMuY29sdW1uCiAgICAgICAgfTsKICAgICAgICB0aGlzLnJvdyA9IHBvcy5yb3c7CiAgICAgICAgdGhpcy5jb2x1bW4gPSBwb3MuY29sdW1uOwogICAgICAgIHRoaXMuX3NpZ25hbCgiY2hhbmdlIiwgewogICAgICAgICAgICBvbGQ6IG9sZCwKICAgICAgICAgICAgdmFsdWU6IHBvcwogICAgICAgIH0pOwogICAgfTsKICAgIEFuY2hvci5wcm90b3R5cGUuZGV0YWNoID0gZnVuY3Rpb24gKCkgewogICAgICAgIHRoaXMuZG9jdW1lbnQub2ZmKCJjaGFuZ2UiLCB0aGlzLiRvbkNoYW5nZSk7CiAgICB9OwogICAgQW5jaG9yLnByb3RvdHlwZS5hdHRhY2ggPSBmdW5jdGlvbiAoZG9jKSB7CiAgICAgICAgdGhpcy5kb2N1bWVudCA9IGRvYyB8fCB0aGlzLmRvY3VtZW50OwogICAgICAgIHRoaXMuZG9jdW1lbnQub24oImNoYW5nZSIsIHRoaXMuJG9uQ2hhbmdlKTsKICAgIH07CiAgICBBbmNob3IucHJvdG90eXBlLiRjbGlwUG9zaXRpb25Ub0RvY3VtZW50ID0gZnVuY3Rpb24gKHJvdywgY29sdW1uKSB7CiAgICAgICAgdmFyIHBvcyA9IHt9OwogICAgICAgIGlmIChyb3cgPj0gdGhpcy5kb2N1bWVudC5nZXRMZW5ndGgoKSkgewogICAgICAgICAgICBwb3Mucm93ID0gTWF0aC5tYXgoMCwgdGhpcy5kb2N1bWVudC5nZXRMZW5ndGgoKSAtIDEpOwogICAgICAgICAgICBwb3MuY29sdW1uID0gdGhpcy5kb2N1bWVudC5nZXRMaW5lKHBvcy5yb3cpLmxlbmd0aDsKICAgICAgICB9CiAgICAgICAgZWxzZSBpZiAocm93IDwgMCkgewogICAgICAgICAgICBwb3Mucm93ID0gMDsKICAgICAgICAgICAgcG9zLmNvbHVtbiA9IDA7CiAgICAgICAgfQogICAgICAgIGVsc2UgewogICAgICAgICAgICBwb3Mucm93ID0gcm93OwogICAgICAgICAgICBwb3MuY29sdW1uID0gTWF0aC5taW4odGhpcy5kb2N1bWVudC5nZXRMaW5lKHBvcy5yb3cpLmxlbmd0aCwgTWF0aC5tYXgoMCwgY29sdW1uKSk7CiAgICAgICAgfQogICAgICAgIGlmIChjb2x1bW4gPCAwKQogICAgICAgICAgICBwb3MuY29sdW1uID0gMDsKICAgICAgICByZXR1cm4gcG9zOwogICAgfTsKICAgIHJldHVybiBBbmNob3I7Cn0oKSk7CkFuY2hvci5wcm90b3R5cGUuJGluc2VydFJpZ2h0ID0gZmFsc2U7Cm9vcC5pbXBsZW1lbnQoQW5jaG9yLnByb3RvdHlwZSwgRXZlbnRFbWl0dGVyKTsKZnVuY3Rpb24gJHBvaW50c0luT3JkZXIocG9pbnQxLCBwb2ludDIsIGVxdWFsUG9pbnRzSW5PcmRlcikgewogICAgdmFyIGJDb2xJc0FmdGVyID0gZXF1YWxQb2ludHNJbk9yZGVyID8gcG9pbnQxLmNvbHVtbiA8PSBwb2ludDIuY29sdW1uIDogcG9pbnQxLmNvbHVtbiA8IHBvaW50Mi5jb2x1bW47CiAgICByZXR1cm4gKHBvaW50MS5yb3cgPCBwb2ludDIucm93KSB8fCAocG9pbnQxLnJvdyA9PSBwb2ludDIucm93ICYmIGJDb2xJc0FmdGVyKTsKfQpmdW5jdGlvbiAkZ2V0VHJhbnNmb3JtZWRQb2ludChkZWx0YSwgcG9pbnQsIG1vdmVJZkVxdWFsKSB7CiAgICB2YXIgZGVsdGFJc0luc2VydCA9IGRlbHRhLmFjdGlvbiA9PSAiaW5zZXJ0IjsKICAgIHZhciBkZWx0YVJvd1NoaWZ0ID0gKGRlbHRhSXNJbnNlcnQgPyAxIDogLTEpICogKGRlbHRhLmVuZC5yb3cgLSBkZWx0YS5zdGFydC5yb3cpOwogICAgdmFyIGRlbHRhQ29sU2hpZnQgPSAoZGVsdGFJc0luc2VydCA/IDEgOiAtMSkgKiAoZGVsdGEuZW5kLmNvbHVtbiAtIGRlbHRhLnN0YXJ0LmNvbHVtbik7CiAgICB2YXIgZGVsdGFTdGFydCA9IGRlbHRhLnN0YXJ0OwogICAgdmFyIGRlbHRhRW5kID0gZGVsdGFJc0luc2VydCA/IGRlbHRhU3RhcnQgOiBkZWx0YS5lbmQ7IC8vIENvbGxhcHNlIGluc2VydCByYW5nZS4KICAgIGlmICgkcG9pbnRzSW5PcmRlcihwb2ludCwgZGVsdGFTdGFydCwgbW92ZUlmRXF1YWwpKSB7CiAgICAgICAgcmV0dXJuIHsKICAgICAgICAgICAgcm93OiBwb2ludC5yb3csCiAgICAgICAgICAgIGNvbHVtbjogcG9pbnQuY29sdW1uCiAgICAgICAgfTsKICAgIH0KICAgIGlmICgkcG9pbnRzSW5PcmRlcihkZWx0YUVuZCwgcG9pbnQsICFtb3ZlSWZFcXVhbCkpIHsKICAgICAgICByZXR1cm4gewogICAgICAgICAgICByb3c6IHBvaW50LnJvdyArIGRlbHRhUm93U2hpZnQsCiAgICAgICAgICAgIGNvbHVtbjogcG9pbnQuY29sdW1uICsgKHBvaW50LnJvdyA9PSBkZWx0YUVuZC5yb3cgPyBkZWx0YUNvbFNoaWZ0IDogMCkKICAgICAgICB9OwogICAgfQogICAgcmV0dXJuIHsKICAgICAgICByb3c6IGRlbHRhU3RhcnQucm93LAogICAgICAgIGNvbHVtbjogZGVsdGFTdGFydC5jb2x1bW4KICAgIH07Cn0KZXhwb3J0cy5BbmNob3IgPSBBbmNob3I7Cgp9KTsKCmFjZS5kZWZpbmUoImFjZS9kb2N1bWVudCIsW10sIGZ1bmN0aW9uKHJlcXVpcmUsIGV4cG9ydHMsIG1vZHVsZSl7InVzZSBzdHJpY3QiOwp2YXIgb29wID0gcmVxdWlyZSgiLi9saWIvb29wIik7CnZhciBhcHBseURlbHRhID0gcmVxdWlyZSgiLi9hcHBseV9kZWx0YSIpLmFwcGx5RGVsdGE7CnZhciBFdmVudEVtaXR0ZXIgPSByZXF1aXJlKCIuL2xpYi9ldmVudF9lbWl0dGVyIikuRXZlbnRFbWl0dGVyOwp2YXIgUmFuZ2UgPSByZXF1aXJlKCIuL3JhbmdlIikuUmFuZ2U7CnZhciBBbmNob3IgPSByZXF1aXJlKCIuL2FuY2hvciIpLkFuY2hvcjsKdmFyIERvY3VtZW50ID0gLyoqIEBjbGFzcyAqLyAoZnVuY3Rpb24gKCkgewogICAgZnVuY3Rpb24gRG9jdW1lbnQodGV4dE9yTGluZXMpIHsKICAgICAgICB0aGlzLiRsaW5lcyA9IFsiIl07CiAgICAgICAgaWYgKHRleHRPckxpbmVzLmxlbmd0aCA9PT0gMCkgewogICAgICAgICAgICB0aGlzLiRsaW5lcyA9IFsiIl07CiAgICAgICAgfQogICAgICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodGV4dE9yTGluZXMpKSB7CiAgICAgICAgICAgIHRoaXMuaW5zZXJ0TWVyZ2VkTGluZXMoeyByb3c6IDAsIGNvbHVtbjogMCB9LCB0ZXh0T3JMaW5lcyk7CiAgICAgICAgfQogICAgICAgIGVsc2UgewogICAgICAgICAgICB0aGlzLmluc2VydCh7IHJvdzogMCwgY29sdW1uOiAwIH0sIHRleHRPckxpbmVzKTsKICAgICAgICB9CiAgICB9CiAgICBEb2N1bWVudC5wcm90b3R5cGUuc2V0VmFsdWUgPSBmdW5jdGlvbiAodGV4dCkgewogICAgICAgIHZhciBsZW4gPSB0aGlzLmdldExlbmd0aCgpIC0gMTsKICAgICAgICB0aGlzLnJlbW92ZShuZXcgUmFuZ2UoMCwgMCwgbGVuLCB0aGlzLmdldExpbmUobGVuKS5sZW5ndGgpKTsKICAgICAgICB0aGlzLmluc2VydCh7IHJvdzogMCwgY29sdW1uOiAwIH0sIHRleHQgfHwgIiIpOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5nZXRWYWx1ZSA9IGZ1bmN0aW9uICgpIHsKICAgICAgICByZXR1cm4gdGhpcy5nZXRBbGxMaW5lcygpLmpvaW4odGhpcy5nZXROZXdMaW5lQ2hhcmFjdGVyKCkpOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5jcmVhdGVBbmNob3IgPSBmdW5jdGlvbiAocm93LCBjb2x1bW4pIHsKICAgICAgICByZXR1cm4gbmV3IEFuY2hvcih0aGlzLCByb3csIGNvbHVtbik7CiAgICB9OwogICAgRG9jdW1lbnQucHJvdG90eXBlLiRkZXRlY3ROZXdMaW5lID0gZnVuY3Rpb24gKHRleHQpIHsKICAgICAgICB2YXIgbWF0Y2ggPSB0ZXh0Lm1hdGNoKC9eLio/KFxyXG58XHJ8XG4pL20pOwogICAgICAgIHRoaXMuJGF1dG9OZXdMaW5lID0gbWF0Y2ggPyBtYXRjaFsxXSA6ICJcbiI7CiAgICAgICAgdGhpcy5fc2lnbmFsKCJjaGFuZ2VOZXdMaW5lTW9kZSIpOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5nZXROZXdMaW5lQ2hhcmFjdGVyID0gZnVuY3Rpb24gKCkgewogICAgICAgIHN3aXRjaCAodGhpcy4kbmV3TGluZU1vZGUpIHsKICAgICAgICAgICAgY2FzZSAid2luZG93cyI6CiAgICAgICAgICAgICAgICByZXR1cm4gIlxyXG4iOwogICAgICAgICAgICBjYXNlICJ1bml4IjoKICAgICAgICAgICAgICAgIHJldHVybiAiXG4iOwogICAgICAgICAgICBkZWZhdWx0OgogICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMuJGF1dG9OZXdMaW5lIHx8ICJcbiI7CiAgICAgICAgfQogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5zZXROZXdMaW5lTW9kZSA9IGZ1bmN0aW9uIChuZXdMaW5lTW9kZSkgewogICAgICAgIGlmICh0aGlzLiRuZXdMaW5lTW9kZSA9PT0gbmV3TGluZU1vZGUpCiAgICAgICAgICAgIHJldHVybjsKICAgICAgICB0aGlzLiRuZXdMaW5lTW9kZSA9IG5ld0xpbmVNb2RlOwogICAgICAgIHRoaXMuX3NpZ25hbCgiY2hhbmdlTmV3TGluZU1vZGUiKTsKICAgIH07CiAgICBEb2N1bWVudC5wcm90b3R5cGUuZ2V0TmV3TGluZU1vZGUgPSBmdW5jdGlvbiAoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuJG5ld0xpbmVNb2RlOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5pc05ld0xpbmUgPSBmdW5jdGlvbiAodGV4dCkgewogICAgICAgIHJldHVybiAodGV4dCA9PSAiXHJcbiIgfHwgdGV4dCA9PSAiXHIiIHx8IHRleHQgPT0gIlxuIik7CiAgICB9OwogICAgRG9jdW1lbnQucHJvdG90eXBlLmdldExpbmUgPSBmdW5jdGlvbiAocm93KSB7CiAgICAgICAgcmV0dXJuIHRoaXMuJGxpbmVzW3Jvd10gfHwgIiI7CiAgICB9OwogICAgRG9jdW1lbnQucHJvdG90eXBlLmdldExpbmVzID0gZnVuY3Rpb24gKGZpcnN0Um93LCBsYXN0Um93KSB7CiAgICAgICAgcmV0dXJuIHRoaXMuJGxpbmVzLnNsaWNlKGZpcnN0Um93LCBsYXN0Um93ICsgMSk7CiAgICB9OwogICAgRG9jdW1lbnQucHJvdG90eXBlLmdldEFsbExpbmVzID0gZnVuY3Rpb24gKCkgewogICAgICAgIHJldHVybiB0aGlzLmdldExpbmVzKDAsIHRoaXMuZ2V0TGVuZ3RoKCkpOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5nZXRMZW5ndGggPSBmdW5jdGlvbiAoKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuJGxpbmVzLmxlbmd0aDsKICAgIH07CiAgICBEb2N1bWVudC5wcm90b3R5cGUuZ2V0VGV4dFJhbmdlID0gZnVuY3Rpb24gKHJhbmdlKSB7CiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0TGluZXNGb3JSYW5nZShyYW5nZSkuam9pbih0aGlzLmdldE5ld0xpbmVDaGFyYWN0ZXIoKSk7CiAgICB9OwogICAgRG9jdW1lbnQucHJvdG90eXBlLmdldExpbmVzRm9yUmFuZ2UgPSBmdW5jdGlvbiAocmFuZ2UpIHsKICAgICAgICB2YXIgbGluZXM7CiAgICAgICAgaWYgKHJhbmdlLnN0YXJ0LnJvdyA9PT0gcmFuZ2UuZW5kLnJvdykgewogICAgICAgICAgICBsaW5lcyA9IFt0aGlzLmdldExpbmUocmFuZ2Uuc3RhcnQucm93KS5zdWJzdHJpbmcocmFuZ2Uuc3RhcnQuY29sdW1uLCByYW5nZS5lbmQuY29sdW1uKV07CiAgICAgICAgfQogICAgICAgIGVsc2UgewogICAgICAgICAgICBsaW5lcyA9IHRoaXMuZ2V0TGluZXMocmFuZ2Uuc3RhcnQucm93LCByYW5nZS5lbmQucm93KTsKICAgICAgICAgICAgbGluZXNbMF0gPSAobGluZXNbMF0gfHwgIiIpLnN1YnN0cmluZyhyYW5nZS5zdGFydC5jb2x1bW4pOwogICAgICAgICAgICB2YXIgbCA9IGxpbmVzLmxlbmd0aCAtIDE7CiAgICAgICAgICAgIGlmIChyYW5nZS5lbmQucm93IC0gcmFuZ2Uuc3RhcnQucm93ID09IGwpCiAgICAgICAgICAgICAgICBsaW5lc1tsXSA9IGxpbmVzW2xdLnN1YnN0cmluZygwLCByYW5nZS5lbmQuY29sdW1uKTsKICAgICAgICB9CiAgICAgICAgcmV0dXJuIGxpbmVzOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5pbnNlcnRMaW5lcyA9IGZ1bmN0aW9uIChyb3csIGxpbmVzKSB7CiAgICAgICAgY29uc29sZS53YXJuKCJVc2Ugb2YgZG9jdW1lbnQuaW5zZXJ0TGluZXMgaXMgZGVwcmVjYXRlZC4gVXNlIHRoZSBpbnNlcnRGdWxsTGluZXMgbWV0aG9kIGluc3RlYWQuIik7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5zZXJ0RnVsbExpbmVzKHJvdywgbGluZXMpOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5yZW1vdmVMaW5lcyA9IGZ1bmN0aW9uIChmaXJzdFJvdywgbGFzdFJvdykgewogICAgICAgIGNvbnNvbGUud2FybigiVXNlIG9mIGRvY3VtZW50LnJlbW92ZUxpbmVzIGlzIGRlcHJlY2F0ZWQuIFVzZSB0aGUgcmVtb3ZlRnVsbExpbmVzIG1ldGhvZCBpbnN0ZWFkLiIpOwogICAgICAgIHJldHVybiB0aGlzLnJlbW92ZUZ1bGxMaW5lcyhmaXJzdFJvdywgbGFzdFJvdyk7CiAgICB9OwogICAgRG9jdW1lbnQucHJvdG90eXBlLmluc2VydE5ld0xpbmUgPSBmdW5jdGlvbiAocG9zaXRpb24pIHsKICAgICAgICBjb25zb2xlLndhcm4oIlVzZSBvZiBkb2N1bWVudC5pbnNlcnROZXdMaW5lIGlzIGRlcHJlY2F0ZWQuIFVzZSBpbnNlcnRNZXJnZWRMaW5lcyhwb3NpdGlvbiwgWycnLCAnJ10pIGluc3RlYWQuIik7CiAgICAgICAgcmV0dXJuIHRoaXMuaW5zZXJ0TWVyZ2VkTGluZXMocG9zaXRpb24sIFsiIiwgIiJdKTsKICAgIH07CiAgICBEb2N1bWVudC5wcm90b3R5cGUuaW5zZXJ0ID0gZnVuY3Rpb24gKHBvc2l0aW9uLCB0ZXh0KSB7CiAgICAgICAgaWYgKHRoaXMuZ2V0TGVuZ3RoKCkgPD0gMSkKICAgICAgICAgICAgdGhpcy4kZGV0ZWN0TmV3TGluZSh0ZXh0KTsKICAgICAgICByZXR1cm4gdGhpcy5pbnNlcnRNZXJnZWRMaW5lcyhwb3NpdGlvbiwgdGhpcy4kc3BsaXQodGV4dCkpOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5pbnNlcnRJbkxpbmUgPSBmdW5jdGlvbiAocG9zaXRpb24sIHRleHQpIHsKICAgICAgICB2YXIgc3RhcnQgPSB0aGlzLmNsaXBwZWRQb3MocG9zaXRpb24ucm93LCBwb3NpdGlvbi5jb2x1bW4pOwogICAgICAgIHZhciBlbmQgPSB0aGlzLnBvcyhwb3NpdGlvbi5yb3csIHBvc2l0aW9uLmNvbHVtbiArIHRleHQubGVuZ3RoKTsKICAgICAgICB0aGlzLmFwcGx5RGVsdGEoewogICAgICAgICAgICBzdGFydDogc3RhcnQsCiAgICAgICAgICAgIGVuZDogZW5kLAogICAgICAgICAgICBhY3Rpb246ICJpbnNlcnQiLAogICAgICAgICAgICBsaW5lczogW3RleHRdCiAgICAgICAgfSwgdHJ1ZSk7CiAgICAgICAgcmV0dXJuIHRoaXMuY2xvbmVQb3MoZW5kKTsKICAgIH07CiAgICBEb2N1bWVudC5wcm90b3R5cGUuY2xpcHBlZFBvcyA9IGZ1bmN0aW9uIChyb3csIGNvbHVtbikgewogICAgICAgIHZhciBsZW5ndGggPSB0aGlzLmdldExlbmd0aCgpOwogICAgICAgIGlmIChyb3cgPT09IHVuZGVmaW5lZCkgewogICAgICAgICAgICByb3cgPSBsZW5ndGg7CiAgICAgICAgfQogICAgICAgIGVsc2UgaWYgKHJvdyA8IDApIHsKICAgICAgICAgICAgcm93ID0gMDsKICAgICAgICB9CiAgICAgICAgZWxzZSBpZiAocm93ID49IGxlbmd0aCkgewogICAgICAgICAgICByb3cgPSBsZW5ndGggLSAxOwogICAgICAgICAgICBjb2x1bW4gPSB1bmRlZmluZWQ7CiAgICAgICAgfQogICAgICAgIHZhciBsaW5lID0gdGhpcy5nZXRMaW5lKHJvdyk7CiAgICAgICAgaWYgKGNvbHVtbiA9PSB1bmRlZmluZWQpCiAgICAgICAgICAgIGNvbHVtbiA9IGxpbmUubGVuZ3RoOwogICAgICAgIGNvbHVtbiA9IE1hdGgubWluKE1hdGgubWF4KGNvbHVtbiwgMCksIGxpbmUubGVuZ3RoKTsKICAgICAgICByZXR1cm4geyByb3c6IHJvdywgY29sdW1uOiBjb2x1bW4gfTsKICAgIH07CiAgICBEb2N1bWVudC5wcm90b3R5cGUuY2xvbmVQb3MgPSBmdW5jdGlvbiAocG9zKSB7CiAgICAgICAgcmV0dXJuIHsgcm93OiBwb3Mucm93LCBjb2x1bW46IHBvcy5jb2x1bW4gfTsKICAgIH07CiAgICBEb2N1bWVudC5wcm90b3R5cGUucG9zID0gZnVuY3Rpb24gKHJvdywgY29sdW1uKSB7CiAgICAgICAgcmV0dXJuIHsgcm93OiByb3csIGNvbHVtbjogY29sdW1uIH07CiAgICB9OwogICAgRG9jdW1lbnQucHJvdG90eXBlLiRjbGlwUG9zaXRpb24gPSBmdW5jdGlvbiAocG9zaXRpb24pIHsKICAgICAgICB2YXIgbGVuZ3RoID0gdGhpcy5nZXRMZW5ndGgoKTsKICAgICAgICBpZiAocG9zaXRpb24ucm93ID49IGxlbmd0aCkgewogICAgICAgICAgICBwb3NpdGlvbi5yb3cgPSBNYXRoLm1heCgwLCBsZW5ndGggLSAxKTsKICAgICAgICAgICAgcG9zaXRpb24uY29sdW1uID0gdGhpcy5nZXRMaW5lKGxlbmd0aCAtIDEpLmxlbmd0aDsKICAgICAgICB9CiAgICAgICAgZWxzZSB7CiAgICAgICAgICAgIHBvc2l0aW9uLnJvdyA9IE1hdGgubWF4KDAsIHBvc2l0aW9uLnJvdyk7CiAgICAgICAgICAgIHBvc2l0aW9uLmNvbHVtbiA9IE1hdGgubWluKE1hdGgubWF4KHBvc2l0aW9uLmNvbHVtbiwgMCksIHRoaXMuZ2V0TGluZShwb3NpdGlvbi5yb3cpLmxlbmd0aCk7CiAgICAgICAgfQogICAgICAgIHJldHVybiBwb3NpdGlvbjsKICAgIH07CiAgICBEb2N1bWVudC5wcm90b3R5cGUuaW5zZXJ0RnVsbExpbmVzID0gZnVuY3Rpb24gKHJvdywgbGluZXMpIHsKICAgICAgICByb3cgPSBNYXRoLm1pbihNYXRoLm1heChyb3csIDApLCB0aGlzLmdldExlbmd0aCgpKTsKICAgICAgICB2YXIgY29sdW1uID0gMDsKICAgICAgICBpZiAocm93IDwgdGhpcy5nZXRMZW5ndGgoKSkgewogICAgICAgICAgICBsaW5lcyA9IGxpbmVzLmNvbmNhdChbIiJdKTsKICAgICAgICAgICAgY29sdW1uID0gMDsKICAgICAgICB9CiAgICAgICAgZWxzZSB7CiAgICAgICAgICAgIGxpbmVzID0gWyIiXS5jb25jYXQobGluZXMpOwogICAgICAgICAgICByb3ctLTsKICAgICAgICAgICAgY29sdW1uID0gdGhpcy4kbGluZXNbcm93XS5sZW5ndGg7CiAgICAgICAgfQogICAgICAgIHRoaXMuaW5zZXJ0TWVyZ2VkTGluZXMoeyByb3c6IHJvdywgY29sdW1uOiBjb2x1bW4gfSwgbGluZXMpOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5pbnNlcnRNZXJnZWRMaW5lcyA9IGZ1bmN0aW9uIChwb3NpdGlvbiwgbGluZXMpIHsKICAgICAgICB2YXIgc3RhcnQgPSB0aGlzLmNsaXBwZWRQb3MocG9zaXRpb24ucm93LCBwb3NpdGlvbi5jb2x1bW4pOwogICAgICAgIHZhciBlbmQgPSB7CiAgICAgICAgICAgIHJvdzogc3RhcnQucm93ICsgbGluZXMubGVuZ3RoIC0gMSwKICAgICAgICAgICAgY29sdW1uOiAobGluZXMubGVuZ3RoID09IDEgPyBzdGFydC5jb2x1bW4gOiAwKSArIGxpbmVzW2xpbmVzLmxlbmd0aCAtIDFdLmxlbmd0aAogICAgICAgIH07CiAgICAgICAgdGhpcy5hcHBseURlbHRhKHsKICAgICAgICAgICAgc3RhcnQ6IHN0YXJ0LAogICAgICAgICAgICBlbmQ6IGVuZCwKICAgICAgICAgICAgYWN0aW9uOiAiaW5zZXJ0IiwKICAgICAgICAgICAgbGluZXM6IGxpbmVzCiAgICAgICAgfSk7CiAgICAgICAgcmV0dXJuIHRoaXMuY2xvbmVQb3MoZW5kKTsKICAgIH07CiAgICBEb2N1bWVudC5wcm90b3R5cGUucmVtb3ZlID0gZnVuY3Rpb24gKHJhbmdlKSB7CiAgICAgICAgdmFyIHN0YXJ0ID0gdGhpcy5jbGlwcGVkUG9zKHJhbmdlLnN0YXJ0LnJvdywgcmFuZ2Uuc3RhcnQuY29sdW1uKTsKICAgICAgICB2YXIgZW5kID0gdGhpcy5jbGlwcGVkUG9zKHJhbmdlLmVuZC5yb3csIHJhbmdlLmVuZC5jb2x1bW4pOwogICAgICAgIHRoaXMuYXBwbHlEZWx0YSh7CiAgICAgICAgICAgIHN0YXJ0OiBzdGFydCwKICAgICAgICAgICAgZW5kOiBlbmQsCiAgICAgICAgICAgIGFjdGlvbjogInJlbW92ZSIsCiAgICAgICAgICAgIGxpbmVzOiB0aGlzLmdldExpbmVzRm9yUmFuZ2UoeyBzdGFydDogc3RhcnQsIGVuZDogZW5kIH0pCiAgICAgICAgfSk7CiAgICAgICAgcmV0dXJuIHRoaXMuY2xvbmVQb3Moc3RhcnQpOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5yZW1vdmVJbkxpbmUgPSBmdW5jdGlvbiAocm93LCBzdGFydENvbHVtbiwgZW5kQ29sdW1uKSB7CiAgICAgICAgdmFyIHN0YXJ0ID0gdGhpcy5jbGlwcGVkUG9zKHJvdywgc3RhcnRDb2x1bW4pOwogICAgICAgIHZhciBlbmQgPSB0aGlzLmNsaXBwZWRQb3Mocm93LCBlbmRDb2x1bW4pOwogICAgICAgIHRoaXMuYXBwbHlEZWx0YSh7CiAgICAgICAgICAgIHN0YXJ0OiBzdGFydCwKICAgICAgICAgICAgZW5kOiBlbmQsCiAgICAgICAgICAgIGFjdGlvbjogInJlbW92ZSIsCiAgICAgICAgICAgIGxpbmVzOiB0aGlzLmdldExpbmVzRm9yUmFuZ2UoeyBzdGFydDogc3RhcnQsIGVuZDogZW5kIH0pCiAgICAgICAgfSwgdHJ1ZSk7CiAgICAgICAgcmV0dXJuIHRoaXMuY2xvbmVQb3Moc3RhcnQpOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5yZW1vdmVGdWxsTGluZXMgPSBmdW5jdGlvbiAoZmlyc3RSb3csIGxhc3RSb3cpIHsKICAgICAgICBmaXJzdFJvdyA9IE1hdGgubWluKE1hdGgubWF4KDAsIGZpcnN0Um93KSwgdGhpcy5nZXRMZW5ndGgoKSAtIDEpOwogICAgICAgIGxhc3RSb3cgPSBNYXRoLm1pbihNYXRoLm1heCgwLCBsYXN0Um93KSwgdGhpcy5nZXRMZW5ndGgoKSAtIDEpOwogICAgICAgIHZhciBkZWxldGVGaXJzdE5ld0xpbmUgPSBsYXN0Um93ID09IHRoaXMuZ2V0TGVuZ3RoKCkgLSAxICYmIGZpcnN0Um93ID4gMDsKICAgICAgICB2YXIgZGVsZXRlTGFzdE5ld0xpbmUgPSBsYXN0Um93IDwgdGhpcy5nZXRMZW5ndGgoKSAtIDE7CiAgICAgICAgdmFyIHN0YXJ0Um93ID0gKGRlbGV0ZUZpcnN0TmV3TGluZSA/IGZpcnN0Um93IC0gMSA6IGZpcnN0Um93KTsKICAgICAgICB2YXIgc3RhcnRDb2wgPSAoZGVsZXRlRmlyc3ROZXdMaW5lID8gdGhpcy5nZXRMaW5lKHN0YXJ0Um93KS5sZW5ndGggOiAwKTsKICAgICAgICB2YXIgZW5kUm93ID0gKGRlbGV0ZUxhc3ROZXdMaW5lID8gbGFzdFJvdyArIDEgOiBsYXN0Um93KTsKICAgICAgICB2YXIgZW5kQ29sID0gKGRlbGV0ZUxhc3ROZXdMaW5lID8gMCA6IHRoaXMuZ2V0TGluZShlbmRSb3cpLmxlbmd0aCk7CiAgICAgICAgdmFyIHJhbmdlID0gbmV3IFJhbmdlKHN0YXJ0Um93LCBzdGFydENvbCwgZW5kUm93LCBlbmRDb2wpOwogICAgICAgIHZhciBkZWxldGVkTGluZXMgPSB0aGlzLiRsaW5lcy5zbGljZShmaXJzdFJvdywgbGFzdFJvdyArIDEpOwogICAgICAgIHRoaXMuYXBwbHlEZWx0YSh7CiAgICAgICAgICAgIHN0YXJ0OiByYW5nZS5zdGFydCwKICAgICAgICAgICAgZW5kOiByYW5nZS5lbmQsCiAgICAgICAgICAgIGFjdGlvbjogInJlbW92ZSIsCiAgICAgICAgICAgIGxpbmVzOiB0aGlzLmdldExpbmVzRm9yUmFuZ2UocmFuZ2UpCiAgICAgICAgfSk7CiAgICAgICAgcmV0dXJuIGRlbGV0ZWRMaW5lczsKICAgIH07CiAgICBEb2N1bWVudC5wcm90b3R5cGUucmVtb3ZlTmV3TGluZSA9IGZ1bmN0aW9uIChyb3cpIHsKICAgICAgICBpZiAocm93IDwgdGhpcy5nZXRMZW5ndGgoKSAtIDEgJiYgcm93ID49IDApIHsKICAgICAgICAgICAgdGhpcy5hcHBseURlbHRhKHsKICAgICAgICAgICAgICAgIHN0YXJ0OiB0aGlzLnBvcyhyb3csIHRoaXMuZ2V0TGluZShyb3cpLmxlbmd0aCksCiAgICAgICAgICAgICAgICBlbmQ6IHRoaXMucG9zKHJvdyArIDEsIDApLAogICAgICAgICAgICAgICAgYWN0aW9uOiAicmVtb3ZlIiwKICAgICAgICAgICAgICAgIGxpbmVzOiBbIiIsICIiXQogICAgICAgICAgICB9KTsKICAgICAgICB9CiAgICB9OwogICAgRG9jdW1lbnQucHJvdG90eXBlLnJlcGxhY2UgPSBmdW5jdGlvbiAocmFuZ2UsIHRleHQpIHsKICAgICAgICBpZiAoIShyYW5nZSBpbnN0YW5jZW9mIFJhbmdlKSkKICAgICAgICAgICAgcmFuZ2UgPSBSYW5nZS5mcm9tUG9pbnRzKHJhbmdlLnN0YXJ0LCByYW5nZS5lbmQpOwogICAgICAgIGlmICh0ZXh0Lmxlbmd0aCA9PT0gMCAmJiByYW5nZS5pc0VtcHR5KCkpCiAgICAgICAgICAgIHJldHVybiByYW5nZS5zdGFydDsKICAgICAgICBpZiAodGV4dCA9PSB0aGlzLmdldFRleHRSYW5nZShyYW5nZSkpCiAgICAgICAgICAgIHJldHVybiByYW5nZS5lbmQ7CiAgICAgICAgdGhpcy5yZW1vdmUocmFuZ2UpOwogICAgICAgIHZhciBlbmQ7CiAgICAgICAgaWYgKHRleHQpIHsKICAgICAgICAgICAgZW5kID0gdGhpcy5pbnNlcnQocmFuZ2Uuc3RhcnQsIHRleHQpOwogICAgICAgIH0KICAgICAgICBlbHNlIHsKICAgICAgICAgICAgZW5kID0gcmFuZ2Uuc3RhcnQ7CiAgICAgICAgfQogICAgICAgIHJldHVybiBlbmQ7CiAgICB9OwogICAgRG9jdW1lbnQucHJvdG90eXBlLmFwcGx5RGVsdGFzID0gZnVuY3Rpb24gKGRlbHRhcykgewogICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgZGVsdGFzLmxlbmd0aDsgaSsrKSB7CiAgICAgICAgICAgIHRoaXMuYXBwbHlEZWx0YShkZWx0YXNbaV0pOwogICAgICAgIH0KICAgIH07CiAgICBEb2N1bWVudC5wcm90b3R5cGUucmV2ZXJ0RGVsdGFzID0gZnVuY3Rpb24gKGRlbHRhcykgewogICAgICAgIGZvciAodmFyIGkgPSBkZWx0YXMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHsKICAgICAgICAgICAgdGhpcy5yZXZlcnREZWx0YShkZWx0YXNbaV0pOwogICAgICAgIH0KICAgIH07CiAgICBEb2N1bWVudC5wcm90b3R5cGUuYXBwbHlEZWx0YSA9IGZ1bmN0aW9uIChkZWx0YSwgZG9Ob3RWYWxpZGF0ZSkgewogICAgICAgIHZhciBpc0luc2VydCA9IGRlbHRhLmFjdGlvbiA9PSAiaW5zZXJ0IjsKICAgICAgICBpZiAoaXNJbnNlcnQgPyBkZWx0YS5saW5lcy5sZW5ndGggPD0gMSAmJiAhZGVsdGEubGluZXNbMF0KICAgICAgICAgICAgOiAhUmFuZ2UuY29tcGFyZVBvaW50cyhkZWx0YS5zdGFydCwgZGVsdGEuZW5kKSkgewogICAgICAgICAgICByZXR1cm47CiAgICAgICAgfQogICAgICAgIGlmIChpc0luc2VydCAmJiBkZWx0YS5saW5lcy5sZW5ndGggPiAyMDAwMCkgewogICAgICAgICAgICB0aGlzLiRzcGxpdEFuZGFwcGx5TGFyZ2VEZWx0YShkZWx0YSwgMjAwMDApOwogICAgICAgIH0KICAgICAgICBlbHNlIHsKICAgICAgICAgICAgYXBwbHlEZWx0YSh0aGlzLiRsaW5lcywgZGVsdGEsIGRvTm90VmFsaWRhdGUpOwogICAgICAgICAgICB0aGlzLl9zaWduYWwoImNoYW5nZSIsIGRlbHRhKTsKICAgICAgICB9CiAgICB9OwogICAgRG9jdW1lbnQucHJvdG90eXBlLiRzYWZlQXBwbHlEZWx0YSA9IGZ1bmN0aW9uIChkZWx0YSkgewogICAgICAgIHZhciBkb2NMZW5ndGggPSB0aGlzLiRsaW5lcy5sZW5ndGg7CiAgICAgICAgaWYgKGRlbHRhLmFjdGlvbiA9PSAicmVtb3ZlIiAmJiBkZWx0YS5zdGFydC5yb3cgPCBkb2NMZW5ndGggJiYgZGVsdGEuZW5kLnJvdyA8IGRvY0xlbmd0aAogICAgICAgICAgICB8fCBkZWx0YS5hY3Rpb24gPT0gImluc2VydCIgJiYgZGVsdGEuc3RhcnQucm93IDw9IGRvY0xlbmd0aCkgewogICAgICAgICAgICB0aGlzLmFwcGx5RGVsdGEoZGVsdGEpOwogICAgICAgIH0KICAgIH07CiAgICBEb2N1bWVudC5wcm90b3R5cGUuJHNwbGl0QW5kYXBwbHlMYXJnZURlbHRhID0gZnVuY3Rpb24gKGRlbHRhLCBNQVgpIHsKICAgICAgICB2YXIgbGluZXMgPSBkZWx0YS5saW5lczsKICAgICAgICB2YXIgbCA9IGxpbmVzLmxlbmd0aCAtIE1BWCArIDE7CiAgICAgICAgdmFyIHJvdyA9IGRlbHRhLnN0YXJ0LnJvdzsKICAgICAgICB2YXIgY29sdW1uID0gZGVsdGEuc3RhcnQuY29sdW1uOwogICAgICAgIGZvciAodmFyIGZyb20gPSAwLCB0byA9IDA7IGZyb20gPCBsOyBmcm9tID0gdG8pIHsKICAgICAgICAgICAgdG8gKz0gTUFYIC0gMTsKICAgICAgICAgICAgdmFyIGNodW5rID0gbGluZXMuc2xpY2UoZnJvbSwgdG8pOwogICAgICAgICAgICBjaHVuay5wdXNoKCIiKTsKICAgICAgICAgICAgdGhpcy5hcHBseURlbHRhKHsKICAgICAgICAgICAgICAgIHN0YXJ0OiB0aGlzLnBvcyhyb3cgKyBmcm9tLCBjb2x1bW4pLAogICAgICAgICAgICAgICAgZW5kOiB0aGlzLnBvcyhyb3cgKyB0bywgY29sdW1uID0gMCksCiAgICAgICAgICAgICAgICBhY3Rpb246IGRlbHRhLmFjdGlvbiwKICAgICAgICAgICAgICAgIGxpbmVzOiBjaHVuawogICAgICAgICAgICB9LCB0cnVlKTsKICAgICAgICB9CiAgICAgICAgZGVsdGEubGluZXMgPSBsaW5lcy5zbGljZShmcm9tKTsKICAgICAgICBkZWx0YS5zdGFydC5yb3cgPSByb3cgKyBmcm9tOwogICAgICAgIGRlbHRhLnN0YXJ0LmNvbHVtbiA9IGNvbHVtbjsKICAgICAgICB0aGlzLmFwcGx5RGVsdGEoZGVsdGEsIHRydWUpOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS5yZXZlcnREZWx0YSA9IGZ1bmN0aW9uIChkZWx0YSkgewogICAgICAgIHRoaXMuJHNhZmVBcHBseURlbHRhKHsKICAgICAgICAgICAgc3RhcnQ6IHRoaXMuY2xvbmVQb3MoZGVsdGEuc3RhcnQpLAogICAgICAgICAgICBlbmQ6IHRoaXMuY2xvbmVQb3MoZGVsdGEuZW5kKSwKICAgICAgICAgICAgYWN0aW9uOiAoZGVsdGEuYWN0aW9uID09ICJpbnNlcnQiID8gInJlbW92ZSIgOiAiaW5zZXJ0IiksCiAgICAgICAgICAgIGxpbmVzOiBkZWx0YS5saW5lcy5zbGljZSgpCiAgICAgICAgfSk7CiAgICB9OwogICAgRG9jdW1lbnQucHJvdG90eXBlLmluZGV4VG9Qb3NpdGlvbiA9IGZ1bmN0aW9uIChpbmRleCwgc3RhcnRSb3cpIHsKICAgICAgICB2YXIgbGluZXMgPSB0aGlzLiRsaW5lcyB8fCB0aGlzLmdldEFsbExpbmVzKCk7CiAgICAgICAgdmFyIG5ld2xpbmVMZW5ndGggPSB0aGlzLmdldE5ld0xpbmVDaGFyYWN0ZXIoKS5sZW5ndGg7CiAgICAgICAgZm9yICh2YXIgaSA9IHN0YXJ0Um93IHx8IDAsIGwgPSBsaW5lcy5sZW5ndGg7IGkgPCBsOyBpKyspIHsKICAgICAgICAgICAgaW5kZXggLT0gbGluZXNbaV0ubGVuZ3RoICsgbmV3bGluZUxlbmd0aDsKICAgICAgICAgICAgaWYgKGluZGV4IDwgMCkKICAgICAgICAgICAgICAgIHJldHVybiB7IHJvdzogaSwgY29sdW1uOiBpbmRleCArIGxpbmVzW2ldLmxlbmd0aCArIG5ld2xpbmVMZW5ndGggfTsKICAgICAgICB9CiAgICAgICAgcmV0dXJuIHsgcm93OiBsIC0gMSwgY29sdW1uOiBpbmRleCArIGxpbmVzW2wgLSAxXS5sZW5ndGggKyBuZXdsaW5lTGVuZ3RoIH07CiAgICB9OwogICAgRG9jdW1lbnQucHJvdG90eXBlLnBvc2l0aW9uVG9JbmRleCA9IGZ1bmN0aW9uIChwb3MsIHN0YXJ0Um93KSB7CiAgICAgICAgdmFyIGxpbmVzID0gdGhpcy4kbGluZXMgfHwgdGhpcy5nZXRBbGxMaW5lcygpOwogICAgICAgIHZhciBuZXdsaW5lTGVuZ3RoID0gdGhpcy5nZXROZXdMaW5lQ2hhcmFjdGVyKCkubGVuZ3RoOwogICAgICAgIHZhciBpbmRleCA9IDA7CiAgICAgICAgdmFyIHJvdyA9IE1hdGgubWluKHBvcy5yb3csIGxpbmVzLmxlbmd0aCk7CiAgICAgICAgZm9yICh2YXIgaSA9IHN0YXJ0Um93IHx8IDA7IGkgPCByb3c7ICsraSkKICAgICAgICAgICAgaW5kZXggKz0gbGluZXNbaV0ubGVuZ3RoICsgbmV3bGluZUxlbmd0aDsKICAgICAgICByZXR1cm4gaW5kZXggKyBwb3MuY29sdW1uOwogICAgfTsKICAgIERvY3VtZW50LnByb3RvdHlwZS4kc3BsaXQgPSBmdW5jdGlvbiAodGV4dCkgewogICAgICAgIHJldHVybiB0ZXh0LnNwbGl0KC9cclxufFxyfFxuLyk7CiAgICB9OwogICAgcmV0dXJuIERvY3VtZW50Owp9KCkpOwpEb2N1bWVudC5wcm90b3R5cGUuJGF1dG9OZXdMaW5lID0gIiI7CkRvY3VtZW50LnByb3RvdHlwZS4kbmV3TGluZU1vZGUgPSAiYXV0byI7Cm9vcC5pbXBsZW1lbnQoRG9jdW1lbnQucHJvdG90eXBlLCBFdmVudEVtaXR0ZXIpOwpleHBvcnRzLkRvY3VtZW50ID0gRG9jdW1lbnQ7Cgp9KTsKCmFjZS5kZWZpbmUoImFjZS9saWIvZGVlcF9jb3B5IixbXSwgZnVuY3Rpb24ocmVxdWlyZSwgZXhwb3J0cywgbW9kdWxlKXtleHBvcnRzLmRlZXBDb3B5ID0gZnVuY3Rpb24gZGVlcENvcHkob2JqKSB7CiAgICBpZiAodHlwZW9mIG9iaiAhPT0gIm9iamVjdCIgfHwgIW9iaikKICAgICAgICByZXR1cm4gb2JqOwogICAgdmFyIGNvcHk7CiAgICBpZiAoQXJyYXkuaXNBcnJheShvYmopKSB7CiAgICAgICAgY29weSA9IFtdOwogICAgICAgIGZvciAodmFyIGtleSA9IDA7IGtleSA8IG9iai5sZW5ndGg7IGtleSsrKSB7CiAgICAgICAgICAgIGNvcHlba2V5XSA9IGRlZXBDb3B5KG9ialtrZXldKTsKICAgICAgICB9CiAgICAgICAgcmV0dXJuIGNvcHk7CiAgICB9CiAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9iaikgIT09ICJbb2JqZWN0IE9iamVjdF0iKQogICAgICAgIHJldHVybiBvYmo7CiAgICBjb3B5ID0ge307CiAgICBmb3IgKHZhciBrZXkgaW4gb2JqKQogICAgICAgIGNvcHlba2V5XSA9IGRlZXBDb3B5KG9ialtrZXldKTsKICAgIHJldHVybiBjb3B5Owp9OwoKfSk7CgphY2UuZGVmaW5lKCJhY2UvbGliL2xhbmciLFtdLCBmdW5jdGlvbihyZXF1aXJlLCBleHBvcnRzLCBtb2R1bGUpeyJ1c2Ugc3RyaWN0IjsKZXhwb3J0cy5sYXN0ID0gZnVuY3Rpb24gKGEpIHsKICAgIHJldHVybiBhW2EubGVuZ3RoIC0gMV07Cn07CmV4cG9ydHMuc3RyaW5nUmV2ZXJzZSA9IGZ1bmN0aW9uIChzdHJpbmcpIHsKICAgIHJldHVybiBzdHJpbmcuc3BsaXQoIiIpLnJldmVyc2UoKS5qb2luKCIiKTsKfTsKZXhwb3J0cy5zdHJpbmdSZXBlYXQgPSBmdW5jdGlvbiAoc3RyaW5nLCBjb3VudCkgewogICAgdmFyIHJlc3VsdCA9ICcnOwogICAgd2hpbGUgKGNvdW50ID4gMCkgewogICAgICAgIGlmIChjb3VudCAmIDEpCiAgICAgICAgICAgIHJlc3VsdCArPSBzdHJpbmc7CiAgICAgICAgaWYgKGNvdW50ID4+PSAxKQogICAgICAgICAgICBzdHJpbmcgKz0gc3RyaW5nOwogICAgfQogICAgcmV0dXJuIHJlc3VsdDsKfTsKdmFyIHRyaW1CZWdpblJlZ2V4cCA9IC9eXHNccyovOwp2YXIgdHJpbUVuZFJlZ2V4cCA9IC9cc1xzKiQvOwpleHBvcnRzLnN0cmluZ1RyaW1MZWZ0ID0gZnVuY3Rpb24gKHN0cmluZykgewogICAgcmV0dXJuIHN0cmluZy5yZXBsYWNlKHRyaW1CZWdpblJlZ2V4cCwgJycpOwp9OwpleHBvcnRzLnN0cmluZ1RyaW1SaWdodCA9IGZ1bmN0aW9uIChzdHJpbmcpIHsKICAgIHJldHVybiBzdHJpbmcucmVwbGFjZSh0cmltRW5kUmVnZXhwLCAnJyk7Cn07CmV4cG9ydHMuY29weU9iamVjdCA9IGZ1bmN0aW9uIChvYmopIHsKICAgIHZhciBjb3B5ID0ge307CiAgICBmb3IgKHZhciBrZXkgaW4gb2JqKSB7CiAgICAgICAgY29weVtrZXldID0gb2JqW2tleV07CiAgICB9CiAgICByZXR1cm4gY29weTsKfTsKZXhwb3J0cy5jb3B5QXJyYXkgPSBmdW5jdGlvbiAoYXJyYXkpIHsKICAgIHZhciBjb3B5ID0gW107CiAgICBmb3IgKHZhciBpID0gMCwgbCA9IGFycmF5Lmxlbmd0aDsgaSA8IGw7IGkrKykgewogICAgICAgIGlmIChhcnJheVtpXSAmJiB0eXBlb2YgYXJyYXlbaV0gPT0gIm9iamVjdCIpCiAgICAgICAgICAgIGNvcHlbaV0gPSB0aGlzLmNvcHlPYmplY3QoYXJyYXlbaV0pOwogICAgICAgIGVsc2UKICAgICAgICAgICAgY29weVtpXSA9IGFycmF5W2ldOwogICAgfQogICAgcmV0dXJuIGNvcHk7Cn07CmV4cG9ydHMuZGVlcENvcHkgPSByZXF1aXJlKCIuL2RlZXBfY29weSIpLmRlZXBDb3B5OwpleHBvcnRzLmFycmF5VG9NYXAgPSBmdW5jdGlvbiAoYXJyKSB7CiAgICB2YXIgbWFwID0ge307CiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGFyci5sZW5ndGg7IGkrKykgewogICAgICAgIG1hcFthcnJbaV1dID0gMTsKICAgIH0KICAgIHJldHVybiBtYXA7Cn07CmV4cG9ydHMuY3JlYXRlTWFwID0gZnVuY3Rpb24gKHByb3BzKSB7CiAgICB2YXIgbWFwID0gT2JqZWN0LmNyZWF0ZShudWxsKTsKICAgIGZvciAodmFyIGkgaW4gcHJvcHMpIHsKICAgICAgICBtYXBbaV0gPSBwcm9wc1tpXTsKICAgIH0KICAgIHJldHVybiBtYXA7Cn07CmV4cG9ydHMuYXJyYXlSZW1vdmUgPSBmdW5jdGlvbiAoYXJyYXksIHZhbHVlKSB7CiAgICBmb3IgKHZhciBpID0gMDsgaSA8PSBhcnJheS5sZW5ndGg7IGkrKykgewogICAgICAgIGlmICh2YWx1ZSA9PT0gYXJyYXlbaV0pIHsKICAgICAgICAgICAgYXJyYXkuc3BsaWNlKGksIDEpOwogICAgICAgIH0KICAgIH0KfTsKZXhwb3J0cy5lc2NhcGVSZWdFeHAgPSBmdW5jdGlvbiAoc3RyKSB7CiAgICByZXR1cm4gc3RyLnJlcGxhY2UoLyhbLiorP14ke30oKXxbXF1cL1xcXSkvZywgJ1xcJDEnKTsKfTsKZXhwb3J0cy5lc2NhcGVIVE1MID0gZnVuY3Rpb24gKHN0cikgewogICAgcmV0dXJuICgiIiArIHN0cikucmVwbGFjZSgvJi9nLCAiJiMzODsiKS5yZXBsYWNlKC8iL2csICImIzM0OyIpLnJlcGxhY2UoLycvZywgIiYjMzk7IikucmVwbGFjZSgvPC9nLCAiJiM2MDsiKTsKfTsKZXhwb3J0cy5nZXRNYXRjaE9mZnNldHMgPSBmdW5jdGlvbiAoc3RyaW5nLCByZWdFeHApIHsKICAgIHZhciBtYXRjaGVzID0gW107CiAgICBzdHJpbmcucmVwbGFjZShyZWdFeHAsIGZ1bmN0aW9uIChzdHIpIHsKICAgICAgICBtYXRjaGVzLnB1c2goewogICAgICAgICAgICBvZmZzZXQ6IGFyZ3VtZW50c1thcmd1bWVudHMubGVuZ3RoIC0gMl0sCiAgICAgICAgICAgIGxlbmd0aDogc3RyLmxlbmd0aAogICAgICAgIH0pOwogICAgfSk7CiAgICByZXR1cm4gbWF0Y2hlczsKfTsKZXhwb3J0cy5kZWZlcnJlZENhbGwgPSBmdW5jdGlvbiAoZmNuKSB7CiAgICB2YXIgdGltZXIgPSBudWxsOwogICAgdmFyIGNhbGxiYWNrID0gZnVuY3Rpb24gKCkgewogICAgICAgIHRpbWVyID0gbnVsbDsKICAgICAgICBmY24oKTsKICAgIH07CiAgICB2YXIgZGVmZXJyZWQgPSBmdW5jdGlvbiAodGltZW91dCkgewogICAgICAgIGRlZmVycmVkLmNhbmNlbCgpOwogICAgICAgIHRpbWVyID0gc2V0VGltZW91dChjYWxsYmFjaywgdGltZW91dCB8fCAwKTsKICAgICAgICByZXR1cm4gZGVmZXJyZWQ7CiAgICB9OwogICAgZGVmZXJyZWQuc2NoZWR1bGUgPSBkZWZlcnJlZDsKICAgIGRlZmVycmVkLmNhbGwgPSBmdW5jdGlvbiAoKSB7CiAgICAgICAgdGhpcy5jYW5jZWwoKTsKICAgICAgICBmY24oKTsKICAgICAgICByZXR1cm4gZGVmZXJyZWQ7CiAgICB9OwogICAgZGVmZXJyZWQuY2FuY2VsID0gZnVuY3Rpb24gKCkgewogICAgICAgIGNsZWFyVGltZW91dCh0aW1lcik7CiAgICAgICAgdGltZXIgPSBudWxsOwogICAgICAgIHJldHVybiBkZWZlcnJlZDsKICAgIH07CiAgICBkZWZlcnJlZC5pc1BlbmRpbmcgPSBmdW5jdGlvbiAoKSB7CiAgICAgICAgcmV0dXJuIHRpbWVyOwogICAgfTsKICAgIHJldHVybiBkZWZlcnJlZDsKfTsKZXhwb3J0cy5kZWxheWVkQ2FsbCA9IGZ1bmN0aW9uIChmY24sIGRlZmF1bHRUaW1lb3V0KSB7CiAgICB2YXIgdGltZXIgPSBudWxsOwogICAgdmFyIGNhbGxiYWNrID0gZnVuY3Rpb24gKCkgewogICAgICAgIHRpbWVyID0gbnVsbDsKICAgICAgICBmY24oKTsKICAgIH07CiAgICB2YXIgX3NlbGYgPSBmdW5jdGlvbiAodGltZW91dCkgewogICAgICAgIGlmICh0aW1lciA9PSBudWxsKQogICAgICAgICAgICB0aW1lciA9IHNldFRpbWVvdXQoY2FsbGJhY2ssIHRpbWVvdXQgfHwgZGVmYXVsdFRpbWVvdXQpOwogICAgfTsKICAgIF9zZWxmLmRlbGF5ID0gZnVuY3Rpb24gKHRpbWVvdXQpIHsKICAgICAgICB0aW1lciAmJiBjbGVhclRpbWVvdXQodGltZXIpOwogICAgICAgIHRpbWVyID0gc2V0VGltZW91dChjYWxsYmFjaywgdGltZW91dCB8fCBkZWZhdWx0VGltZW91dCk7CiAgICB9OwogICAgX3NlbGYuc2NoZWR1bGUgPSBfc2VsZjsKICAgIF9zZWxmLmNhbGwgPSBmdW5jdGlvbiAoKSB7CiAgICAgICAgdGhpcy5jYW5jZWwoKTsKICAgICAgICBmY24oKTsKICAgIH07CiAgICBfc2VsZi5jYW5jZWwgPSBmdW5jdGlvbiAoKSB7CiAgICAgICAgdGltZXIgJiYgY2xlYXJUaW1lb3V0KHRpbWVyKTsKICAgICAgICB0aW1lciA9IG51bGw7CiAgICB9OwogICAgX3NlbGYuaXNQZW5kaW5nID0gZnVuY3Rpb24gKCkgewogICAgICAgIHJldHVybiB0aW1lcjsKICAgIH07CiAgICByZXR1cm4gX3NlbGY7Cn07CmV4cG9ydHMuc3VwcG9ydHNMb29rYmVoaW5kID0gZnVuY3Rpb24gKCkgewogICAgdHJ5IHsKICAgICAgICBuZXcgUmVnRXhwKCcoPzw9LiknKTsKICAgIH0KICAgIGNhdGNoIChlKSB7CiAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgfQogICAgcmV0dXJuIHRydWU7Cn07CmV4cG9ydHMuc2tpcEVtcHR5TWF0Y2ggPSBmdW5jdGlvbiAobGluZSwgbGFzdCwgc3VwcG9ydHNVbmljb2RlRmxhZykgewogICAgcmV0dXJuIHN1cHBvcnRzVW5pY29kZUZsYWcgJiYgbGluZS5jb2RlUG9pbnRBdChsYXN0KSA+IDB4ZmZmZiA/IDIgOiAxOwp9OwoKfSk7CgphY2UuZGVmaW5lKCJhY2Uvd29ya2VyL21pcnJvciIsW10sIGZ1bmN0aW9uKHJlcXVpcmUsIGV4cG9ydHMsIG1vZHVsZSkgewoidXNlIHN0cmljdCI7Cgp2YXIgRG9jdW1lbnQgPSByZXF1aXJlKCIuLi9kb2N1bWVudCIpLkRvY3VtZW50Owp2YXIgbGFuZyA9IHJlcXVpcmUoIi4uL2xpYi9sYW5nIik7CiAgICAKdmFyIE1pcnJvciA9IGV4cG9ydHMuTWlycm9yID0gZnVuY3Rpb24oc2VuZGVyKSB7CiAgICB0aGlzLnNlbmRlciA9IHNlbmRlcjsKICAgIHZhciBkb2MgPSB0aGlzLmRvYyA9IG5ldyBEb2N1bWVudCgiIik7CiAgICAKICAgIHZhciBkZWZlcnJlZFVwZGF0ZSA9IHRoaXMuZGVmZXJyZWRVcGRhdGUgPSBsYW5nLmRlbGF5ZWRDYWxsKHRoaXMub25VcGRhdGUuYmluZCh0aGlzKSk7CiAgICAKICAgIHZhciBfc2VsZiA9IHRoaXM7CiAgICBzZW5kZXIub24oImNoYW5nZSIsIGZ1bmN0aW9uKGUpIHsKICAgICAgICB2YXIgZGF0YSA9IGUuZGF0YTsKICAgICAgICBpZiAoZGF0YVswXS5zdGFydCkgewogICAgICAgICAgICBkb2MuYXBwbHlEZWx0YXMoZGF0YSk7CiAgICAgICAgfSBlbHNlIHsKICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBkYXRhLmxlbmd0aDsgaSArPSAyKSB7CiAgICAgICAgICAgICAgICB2YXIgZCwgZXJyOyAKICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGRhdGFbaSsxXSkpIHsKICAgICAgICAgICAgICAgICAgICBkID0ge2FjdGlvbjogImluc2VydCIsIHN0YXJ0OiBkYXRhW2ldLCBsaW5lczogZGF0YVtpKzFdfTsKICAgICAgICAgICAgICAgIH0gZWxzZSB7CiAgICAgICAgICAgICAgICAgICAgZCA9IHthY3Rpb246ICJyZW1vdmUiLCBzdGFydDogZGF0YVtpXSwgZW5kOiBkYXRhW2krMV19OwogICAgICAgICAgICAgICAgfQogICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICBpZiAoKGQuYWN0aW9uID09ICJpbnNlcnQiID8gZC5zdGFydCA6IGQuZW5kKS5yb3cgPj0gZG9jLiRsaW5lcy5sZW5ndGgpIHsKICAgICAgICAgICAgICAgICAgICBlcnIgPSBuZXcgRXJyb3IoIkludmFsaWQgZGVsdGEiKTsKICAgICAgICAgICAgICAgICAgICBlcnIuZGF0YSA9IHsKICAgICAgICAgICAgICAgICAgICAgICAgcGF0aDogX3NlbGYuJHBhdGgsCiAgICAgICAgICAgICAgICAgICAgICAgIGxpbmVzTGVuZ3RoOiBkb2MuJGxpbmVzLmxlbmd0aCwKICAgICAgICAgICAgICAgICAgICAgICAgc3RhcnQ6IGQuc3RhcnQsCiAgICAgICAgICAgICAgICAgICAgICAgIGVuZDogZC5lbmQKICAgICAgICAgICAgICAgICAgICB9OwogICAgICAgICAgICAgICAgICAgIHRocm93IGVycjsKICAgICAgICAgICAgICAgIH0KCiAgICAgICAgICAgICAgICBkb2MuYXBwbHlEZWx0YShkLCB0cnVlKTsKICAgICAgICAgICAgfQogICAgICAgIH0KICAgICAgICBpZiAoX3NlbGYuJHRpbWVvdXQpCiAgICAgICAgICAgIHJldHVybiBkZWZlcnJlZFVwZGF0ZS5zY2hlZHVsZShfc2VsZi4kdGltZW91dCk7CiAgICAgICAgX3NlbGYub25VcGRhdGUoKTsKICAgIH0pOwp9OwoKKGZ1bmN0aW9uKCkgewogICAgCiAgICB0aGlzLiR0aW1lb3V0ID0gNTAwOwogICAgCiAgICB0aGlzLnNldFRpbWVvdXQgPSBmdW5jdGlvbih0aW1lb3V0KSB7CiAgICAgICAgdGhpcy4kdGltZW91dCA9IHRpbWVvdXQ7CiAgICB9OwogICAgCiAgICB0aGlzLnNldFZhbHVlID0gZnVuY3Rpb24odmFsdWUpIHsKICAgICAgICB0aGlzLmRvYy5zZXRWYWx1ZSh2YWx1ZSk7CiAgICAgICAgdGhpcy5kZWZlcnJlZFVwZGF0ZS5zY2hlZHVsZSh0aGlzLiR0aW1lb3V0KTsKICAgIH07CiAgICAKICAgIHRoaXMuZ2V0VmFsdWUgPSBmdW5jdGlvbihjYWxsYmFja0lkKSB7CiAgICAgICAgdGhpcy5zZW5kZXIuY2FsbGJhY2sodGhpcy5kb2MuZ2V0VmFsdWUoKSwgY2FsbGJhY2tJZCk7CiAgICB9OwogICAgCiAgICB0aGlzLm9uVXBkYXRlID0gZnVuY3Rpb24oKSB7CiAgICB9OwogICAgCiAgICB0aGlzLmlzUGVuZGluZyA9IGZ1bmN0aW9uKCkgewogICAgICAgIHJldHVybiB0aGlzLmRlZmVycmVkVXBkYXRlLmlzUGVuZGluZygpOwogICAgfTsKICAgIAp9KS5jYWxsKE1pcnJvci5wcm90b3R5cGUpOwoKfSk7CgphY2UuZGVmaW5lKCJhY2UvbW9kZS9qc29uL2pzb25fcGFyc2UiLFtdLCBmdW5jdGlvbihyZXF1aXJlLCBleHBvcnRzLCBtb2R1bGUpIHsKInVzZSBzdHJpY3QiOwoKICAgIHZhciBhdCwgICAgIC8vIFRoZSBpbmRleCBvZiB0aGUgY3VycmVudCBjaGFyYWN0ZXIKICAgICAgICBjaCwgICAgIC8vIFRoZSBjdXJyZW50IGNoYXJhY3RlcgogICAgICAgIGVzY2FwZWUgPSB7CiAgICAgICAgICAgICciJzogICciJywKICAgICAgICAgICAgJ1xcJzogJ1xcJywKICAgICAgICAgICAgJy8nOiAgJy8nLAogICAgICAgICAgICBiOiAgICAnXGInLAogICAgICAgICAgICBmOiAgICAnXGYnLAogICAgICAgICAgICBuOiAgICAnXG4nLAogICAgICAgICAgICByOiAgICAnXHInLAogICAgICAgICAgICB0OiAgICAnXHQnCiAgICAgICAgfSwKICAgICAgICB0ZXh0LAoKICAgICAgICBlcnJvciA9IGZ1bmN0aW9uIChtKSB7CgogICAgICAgICAgICB0aHJvdyB7CiAgICAgICAgICAgICAgICBuYW1lOiAgICAnU3ludGF4RXJyb3InLAogICAgICAgICAgICAgICAgbWVzc2FnZTogbSwKICAgICAgICAgICAgICAgIGF0OiAgICAgIGF0LAogICAgICAgICAgICAgICAgdGV4dDogICAgdGV4dAogICAgICAgICAgICB9OwogICAgICAgIH0sCgogICAgICAgIG5leHQgPSBmdW5jdGlvbiAoYykgewoKICAgICAgICAgICAgaWYgKGMgJiYgYyAhPT0gY2gpIHsKICAgICAgICAgICAgICAgIGVycm9yKCJFeHBlY3RlZCAnIiArIGMgKyAiJyBpbnN0ZWFkIG9mICciICsgY2ggKyAiJyIpOwogICAgICAgICAgICB9CgogICAgICAgICAgICBjaCA9IHRleHQuY2hhckF0KGF0KTsKICAgICAgICAgICAgYXQgKz0gMTsKICAgICAgICAgICAgcmV0dXJuIGNoOwogICAgICAgIH0sCgogICAgICAgIG51bWJlciA9IGZ1bmN0aW9uICgpIHsKCiAgICAgICAgICAgIHZhciBudW1iZXIsCiAgICAgICAgICAgICAgICBzdHJpbmcgPSAnJzsKCiAgICAgICAgICAgIGlmIChjaCA9PT0gJy0nKSB7CiAgICAgICAgICAgICAgICBzdHJpbmcgPSAnLSc7CiAgICAgICAgICAgICAgICBuZXh0KCctJyk7CiAgICAgICAgICAgIH0KICAgICAgICAgICAgd2hpbGUgKGNoID49ICcwJyAmJiBjaCA8PSAnOScpIHsKICAgICAgICAgICAgICAgIHN0cmluZyArPSBjaDsKICAgICAgICAgICAgICAgIG5leHQoKTsKICAgICAgICAgICAgfQogICAgICAgICAgICBpZiAoY2ggPT09ICcuJykgewogICAgICAgICAgICAgICAgc3RyaW5nICs9ICcuJzsKICAgICAgICAgICAgICAgIHdoaWxlIChuZXh0KCkgJiYgY2ggPj0gJzAnICYmIGNoIDw9ICc5JykgewogICAgICAgICAgICAgICAgICAgIHN0cmluZyArPSBjaDsKICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgfQogICAgICAgICAgICBpZiAoY2ggPT09ICdlJyB8fCBjaCA9PT0gJ0UnKSB7CiAgICAgICAgICAgICAgICBzdHJpbmcgKz0gY2g7CiAgICAgICAgICAgICAgICBuZXh0KCk7CiAgICAgICAgICAgICAgICBpZiAoY2ggPT09ICctJyB8fCBjaCA9PT0gJysnKSB7CiAgICAgICAgICAgICAgICAgICAgc3RyaW5nICs9IGNoOwogICAgICAgICAgICAgICAgICAgIG5leHQoKTsKICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgICAgIHdoaWxlIChjaCA+PSAnMCcgJiYgY2ggPD0gJzknKSB7CiAgICAgICAgICAgICAgICAgICAgc3RyaW5nICs9IGNoOwogICAgICAgICAgICAgICAgICAgIG5leHQoKTsKICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgfQogICAgICAgICAgICBudW1iZXIgPSArc3RyaW5nOwogICAgICAgICAgICBpZiAoaXNOYU4obnVtYmVyKSkgewogICAgICAgICAgICAgICAgZXJyb3IoIkJhZCBudW1iZXIiKTsKICAgICAgICAgICAgfSBlbHNlIHsKICAgICAgICAgICAgICAgIHJldHVybiBudW1iZXI7CiAgICAgICAgICAgIH0KICAgICAgICB9LAoKICAgICAgICBzdHJpbmcgPSBmdW5jdGlvbiAoKSB7CgogICAgICAgICAgICB2YXIgaGV4LAogICAgICAgICAgICAgICAgaSwKICAgICAgICAgICAgICAgIHN0cmluZyA9ICcnLAogICAgICAgICAgICAgICAgdWZmZmY7CgogICAgICAgICAgICBpZiAoY2ggPT09ICciJykgewogICAgICAgICAgICAgICAgd2hpbGUgKG5leHQoKSkgewogICAgICAgICAgICAgICAgICAgIGlmIChjaCA9PT0gJyInKSB7CiAgICAgICAgICAgICAgICAgICAgICAgIG5leHQoKTsKICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHN0cmluZzsKICAgICAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKGNoID09PSAnXFwnKSB7CiAgICAgICAgICAgICAgICAgICAgICAgIG5leHQoKTsKICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGNoID09PSAndScpIHsKICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVmZmZmID0gMDsKICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCA0OyBpICs9IDEpIHsKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZXggPSBwYXJzZUludChuZXh0KCksIDE2KTsKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWlzRmluaXRlKGhleCkpIHsKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7CiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfQogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVmZmZmID0gdWZmZmYgKiAxNiArIGhleDsKICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZyArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKHVmZmZmKTsKICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlb2YgZXNjYXBlZVtjaF0gPT09ICdzdHJpbmcnKSB7CiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJpbmcgKz0gZXNjYXBlZVtjaF07CiAgICAgICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7CiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhazsKICAgICAgICAgICAgICAgICAgICAgICAgfQogICAgICAgICAgICAgICAgICAgIH0gZWxzZSBpZiAoY2ggPT0gIlxuIiB8fCBjaCA9PSAiXHIiKSB7CiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrOwogICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7CiAgICAgICAgICAgICAgICAgICAgICAgIHN0cmluZyArPSBjaDsKICAgICAgICAgICAgICAgICAgICB9CiAgICAgICAgICAgICAgICB9CiAgICAgICAgICAgIH0KICAgICAgICAgICAgZXJyb3IoIkJhZCBzdHJpbmciKTsKICAgICAgICB9LAoKICAgICAgICB3aGl0ZSA9IGZ1bmN0aW9uICgpIHsKCiAgICAgICAgICAgIHdoaWxlIChjaCAmJiBjaCA8PSAnICcpIHsKICAgICAgICAgICAgICAgIG5leHQoKTsKICAgICAgICAgICAgfQogICAgICAgIH0sCgogICAgICAgIHdvcmQgPSBmdW5jdGlvbiAoKSB7CgogICAgICAgICAgICBzd2l0Y2ggKGNoKSB7CiAgICAgICAgICAgIGNhc2UgJ3QnOgogICAgICAgICAgICAgICAgbmV4dCgndCcpOwogICAgICAgICAgICAgICAgbmV4dCgncicpOwogICAgICAgICAgICAgICAgbmV4dCgndScpOwogICAgICAgICAgICAgICAgbmV4dCgnZScpOwogICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7CiAgICAgICAgICAgIGNhc2UgJ2YnOgogICAgICAgICAgICAgICAgbmV4dCgnZicpOwogICAgICAgICAgICAgICAgbmV4dCgnYScpOwogICAgICAgICAgICAgICAgbmV4dCgnbCcpOwogICAgICAgICAgICAgICAgbmV4dCgncycpOwogICAgICAgICAgICAgICAgbmV4dCgnZScpOwogICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlOwogICAgICAgICAgICBjYXNlICduJzoKICAgICAgICAgICAgICAgIG5leHQoJ24nKTsKICAgICAgICAgICAgICAgIG5leHQoJ3UnKTsKICAgICAgICAgICAgICAgIG5leHQoJ2wnKTsKICAgICAgICAgICAgICAgIG5leHQoJ2wnKTsKICAgICAgICAgICAgICAgIHJldHVybiBudWxsOwogICAgICAgICAgICB9CiAgICAgICAgICAgIGVycm9yKCJVbmV4cGVjdGVkICciICsgY2ggKyAiJyIpOwogICAgICAgIH0sCgogICAgICAgIHZhbHVlLCAgLy8gUGxhY2UgaG9sZGVyIGZvciB0aGUgdmFsdWUgZnVuY3Rpb24uCgogICAgICAgIGFycmF5ID0gZnVuY3Rpb24gKCkgewoKICAgICAgICAgICAgdmFyIGFycmF5ID0gW107CgogICAgICAgICAgICBpZiAoY2ggPT09ICdbJykgewogICAgICAgICAgICAgICAgbmV4dCgnWycpOwogICAgICAgICAgICAgICAgd2hpdGUoKTsKICAgICAgICAgICAgICAgIGlmIChjaCA9PT0gJ10nKSB7CiAgICAgICAgICAgICAgICAgICAgbmV4dCgnXScpOwogICAgICAgICAgICAgICAgICAgIHJldHVybiBhcnJheTsgICAvLyBlbXB0eSBhcnJheQogICAgICAgICAgICAgICAgfQogICAgICAgICAgICAgICAgd2hpbGUgKGNoKSB7CiAgICAgICAgICAgICAgICAgICAgYXJyYXkucHVzaCh2YWx1ZSgpKTsKICAgICAgICAgICAgICAgICAgICB3aGl0ZSgpOwogICAgICAgICAgICAgICAgICAgIGlmIChjaCA9PT0gJ10nKSB7CiAgICAgICAgICAgICAgICAgICAgICAgIG5leHQoJ10nKTsKICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFycmF5OwogICAgICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgICAgICAgICBuZXh0KCcsJyk7CiAgICAgICAgICAgICAgICAgICAgd2hpdGUoKTsKICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgfQogICAgICAgICAgICBlcnJvcigiQmFkIGFycmF5Iik7CiAgICAgICAgfSwKCiAgICAgICAgb2JqZWN0ID0gZnVuY3Rpb24gKCkgewoKICAgICAgICAgICAgdmFyIGtleSwKICAgICAgICAgICAgICAgIG9iamVjdCA9IHt9OwoKICAgICAgICAgICAgaWYgKGNoID09PSAneycpIHsKICAgICAgICAgICAgICAgIG5leHQoJ3snKTsKICAgICAgICAgICAgICAgIHdoaXRlKCk7CiAgICAgICAgICAgICAgICBpZiAoY2ggPT09ICd9JykgewogICAgICAgICAgICAgICAgICAgIG5leHQoJ30nKTsKICAgICAgICAgICAgICAgICAgICByZXR1cm4gb2JqZWN0OyAgIC8vIGVtcHR5IG9iamVjdAogICAgICAgICAgICAgICAgfQogICAgICAgICAgICAgICAgd2hpbGUgKGNoKSB7CiAgICAgICAgICAgICAgICAgICAga2V5ID0gc3RyaW5nKCk7CiAgICAgICAgICAgICAgICAgICAgd2hpdGUoKTsKICAgICAgICAgICAgICAgICAgICBuZXh0KCc6Jyk7CiAgICAgICAgICAgICAgICAgICAgaWYgKE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwga2V5KSkgewogICAgICAgICAgICAgICAgICAgICAgICBlcnJvcignRHVwbGljYXRlIGtleSAiJyArIGtleSArICciJyk7CiAgICAgICAgICAgICAgICAgICAgfQogICAgICAgICAgICAgICAgICAgIG9iamVjdFtrZXldID0gdmFsdWUoKTsKICAgICAgICAgICAgICAgICAgICB3aGl0ZSgpOwogICAgICAgICAgICAgICAgICAgIGlmIChjaCA9PT0gJ30nKSB7CiAgICAgICAgICAgICAgICAgICAgICAgIG5leHQoJ30nKTsKICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG9iamVjdDsKICAgICAgICAgICAgICAgICAgICB9CiAgICAgICAgICAgICAgICAgICAgbmV4dCgnLCcpOwogICAgICAgICAgICAgICAgICAgIHdoaXRlKCk7CiAgICAgICAgICAgICAgICB9CiAgICAgICAgICAgIH0KICAgICAgICAgICAgZXJyb3IoIkJhZCBvYmplY3QiKTsKICAgICAgICB9OwoKICAgIHZhbHVlID0gZnVuY3Rpb24gKCkgewoKICAgICAgICB3aGl0ZSgpOwogICAgICAgIHN3aXRjaCAoY2gpIHsKICAgICAgICBjYXNlICd7JzoKICAgICAgICAgICAgcmV0dXJuIG9iamVjdCgpOwogICAgICAgIGNhc2UgJ1snOgogICAgICAgICAgICByZXR1cm4gYXJyYXkoKTsKICAgICAgICBjYXNlICciJzoKICAgICAgICAgICAgcmV0dXJuIHN0cmluZygpOwogICAgICAgIGNhc2UgJy0nOgogICAgICAgICAgICByZXR1cm4gbnVtYmVyKCk7CiAgICAgICAgZGVmYXVsdDoKICAgICAgICAgICAgcmV0dXJuIGNoID49ICcwJyAmJiBjaCA8PSAnOScgPyBudW1iZXIoKSA6IHdvcmQoKTsKICAgICAgICB9CiAgICB9OwoKICAgIHJldHVybiBmdW5jdGlvbiAoc291cmNlLCByZXZpdmVyKSB7CiAgICAgICAgdmFyIHJlc3VsdDsKCiAgICAgICAgdGV4dCA9IHNvdXJjZTsKICAgICAgICBhdCA9IDA7CiAgICAgICAgY2ggPSAnICc7CiAgICAgICAgcmVzdWx0ID0gdmFsdWUoKTsKICAgICAgICB3aGl0ZSgpOwogICAgICAgIGlmIChjaCkgewogICAgICAgICAgICBlcnJvcigiU3ludGF4IGVycm9yIik7CiAgICAgICAgfQoKICAgICAgICByZXR1cm4gdHlwZW9mIHJldml2ZXIgPT09ICdmdW5jdGlvbicgPyBmdW5jdGlvbiB3YWxrKGhvbGRlciwga2V5KSB7CiAgICAgICAgICAgIHZhciBrLCB2LCB2YWx1ZSA9IGhvbGRlcltrZXldOwogICAgICAgICAgICBpZiAodmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JykgewogICAgICAgICAgICAgICAgZm9yIChrIGluIHZhbHVlKSB7CiAgICAgICAgICAgICAgICAgICAgaWYgKE9iamVjdC5oYXNPd25Qcm9wZXJ0eS5jYWxsKHZhbHVlLCBrKSkgewogICAgICAgICAgICAgICAgICAgICAgICB2ID0gd2Fsayh2YWx1ZSwgayk7CiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2ICE9PSB1bmRlZmluZWQpIHsKICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlW2tdID0gdjsKICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHsKICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRlbGV0ZSB2YWx1ZVtrXTsKICAgICAgICAgICAgICAgICAgICAgICAgfQogICAgICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgICAgIH0KICAgICAgICAgICAgfQogICAgICAgICAgICByZXR1cm4gcmV2aXZlci5jYWxsKGhvbGRlciwga2V5LCB2YWx1ZSk7CiAgICAgICAgfSh7Jyc6IHJlc3VsdH0sICcnKSA6IHJlc3VsdDsKICAgIH07Cn0pOwoKYWNlLmRlZmluZSgiYWNlL21vZGUvanNvbl93b3JrZXIiLFtdLCBmdW5jdGlvbihyZXF1aXJlLCBleHBvcnRzLCBtb2R1bGUpIHsKInVzZSBzdHJpY3QiOwoKdmFyIG9vcCA9IHJlcXVpcmUoIi4uL2xpYi9vb3AiKTsKdmFyIE1pcnJvciA9IHJlcXVpcmUoIi4uL3dvcmtlci9taXJyb3IiKS5NaXJyb3I7CnZhciBwYXJzZSA9IHJlcXVpcmUoIi4vanNvbi9qc29uX3BhcnNlIik7Cgp2YXIgSnNvbldvcmtlciA9IGV4cG9ydHMuSnNvbldvcmtlciA9IGZ1bmN0aW9uKHNlbmRlcikgewogICAgTWlycm9yLmNhbGwodGhpcywgc2VuZGVyKTsKICAgIHRoaXMuc2V0VGltZW91dCgyMDApOwp9OwoKb29wLmluaGVyaXRzKEpzb25Xb3JrZXIsIE1pcnJvcik7CgooZnVuY3Rpb24oKSB7CgogICAgdGhpcy5vblVwZGF0ZSA9IGZ1bmN0aW9uKCkgewogICAgICAgIHZhciB2YWx1ZSA9IHRoaXMuZG9jLmdldFZhbHVlKCk7CiAgICAgICAgdmFyIGVycm9ycyA9IFtdOwogICAgICAgIHRyeSB7CiAgICAgICAgICAgIGlmICh2YWx1ZSkKICAgICAgICAgICAgICAgIHBhcnNlKHZhbHVlKTsKICAgICAgICB9IGNhdGNoIChlKSB7CiAgICAgICAgICAgIHZhciBwb3MgPSB0aGlzLmRvYy5pbmRleFRvUG9zaXRpb24oZS5hdC0xKTsKICAgICAgICAgICAgZXJyb3JzLnB1c2goewogICAgICAgICAgICAgICAgcm93OiBwb3Mucm93LAogICAgICAgICAgICAgICAgY29sdW1uOiBwb3MuY29sdW1uLAogICAgICAgICAgICAgICAgdGV4dDogZS5tZXNzYWdlLAogICAgICAgICAgICAgICAgdHlwZTogImVycm9yIgogICAgICAgICAgICB9KTsKICAgICAgICB9CiAgICAgICAgdGhpcy5zZW5kZXIuZW1pdCgiYW5ub3RhdGUiLCBlcnJvcnMpOwogICAgfTsKCn0pLmNhbGwoSnNvbldvcmtlci5wcm90b3R5cGUpOwoKfSk7Cg==", UC = (e) => {
  const a = {};
  for (let l = 0; l < e.length; l++) {
    const I = Array.isArray(e[l]), A = !I && typeof e[l] == "object", g = `hdl-${ce(8)}`;
    a[g] = {
      type: I ? "array" : typeof e[l],
      value: A || I ? "" : e[l],
      expand: !1,
      field: "",
      child: {}
    }, A && (a[g].child = bg(e[l]));
  }
  return a;
}, bg = (e) => {
  const a = {};
  for (const l in e) {
    const I = Array.isArray(e[l]), A = `hdl-${ce(8)}`, g = !I && typeof e[l] == "object";
    a[A] = {
      type: I ? "array" : typeof e[l],
      value: g || I ? "" : e[l],
      expand: !1,
      field: l,
      child: {}
    }, g && (a[A].child = bg(e[l])), I && (a[A].child = UC(e[l]));
  }
  return a;
}, zC = (e) => {
  const a = [];
  for (const l in e) {
    const I = e[l].value;
    e[l].type === "object" ? a.push($e(e[l].child)) : a.push(I);
  }
  return a;
}, $e = (e) => {
  let a = {};
  for (const l in e) {
    const I = e[l];
    if (I.field === "root") {
      a = {
        ...$e(I.child)
      };
      break;
    }
    I.child && Object.keys(I.child).length > 0 ? I.type === "array" ? a[I.field] = zC(I.child) : a[I.field] = $e(I.child) : I.type === "object" ? a[I.field] = {} : I.type === "array" ? a[I.field] = [] : a[I.field] = I.value;
  }
  return a;
}, jC = () => {
  const e = ce(8), a = {
    [`hdl-${e}`]: {
      type: "object",
      field: "root",
      value: "",
      expand: !1,
      child: {}
    }
  }, l = W({
    ...a
  });
  return {
    uuid: e,
    tempJsonValue: l,
    setJsonValue: (g, d = !0) => {
      d ? l.value = g : l.value[`hdl-${e}`].child = g;
    },
    resetValue: () => {
      l.value = {
        ...a
      };
    }
  };
}, { uuid: DC, tempJsonValue: qe, setJsonValue: OC, resetValue: TC } = jC(), MC = ["id"], QC = { class: "form-item" }, PC = ["onClick"], EC = { class: "field" }, _C = { class: "field-type" }, qC = { class: "field-value" }, $C = {
  key: 0,
  class: "field-icon"
}, eA = ["onClick"], gA = { class: "add-icon" }, IA = /* @__PURE__ */ q({
  name: "JsonForm",
  __name: "jsonForm",
  props: {
    modelValue: {
      // 表单数据
      type: Object,
      default: () => ({})
    },
    indent: {
      // 缩进，用于控制json的层级
      type: Number,
      default: 0
    },
    fieldDisabled: {
      // 字段是否禁用
      type: Boolean,
      default: !1
    },
    jsonId: {
      // id
      type: String,
      default: ""
    },
    readonly: {
      // 是否只读
      type: Boolean,
      default: !1
    }
  },
  setup(e) {
    const a = W([
      // 字段类型数据
      { value: "string", label: "字符串" },
      { value: "number", label: "数字" },
      { value: "boolean", label: "布尔" },
      { value: "array", label: "数组" },
      { value: "object", label: "对象" }
    ]), l = lI("vAceEditorElem"), I = _(() => (o) => o === "root"), A = _(() => (o) => ["boolean"].includes(o)), g = _(() => (o) => I.value(o.field) || o.type === "object" || o.type === "array"), d = (o, H) => {
      o.expand = !o.expand;
      const h = document.getElementById(H);
      h.style.height = o.expand ? "0" : "auto";
    }, c = () => {
      if (l && l.value) {
        const o = l.value.getAceInstance();
        o.setValue(JSON.stringify($e(qe.value), null, 2)), o.clearSelection();
      }
    }, Z = () => {
      c();
    }, G = (o) => {
      const H = o.value;
      o.value = "", Object.prototype.hasOwnProperty.call(o, "child") && delete o.child, (o.type === "object" || o.type === "array") && (o.child = {}), o.type === "number" && (o.value = isNaN(Number(H)) ? 0 : Number(H)), o.type === "boolean" && (o.value = !0), c();
    }, K = (o, H) => {
      const h = H.type === "number" ? Number(o) : o;
      H.value = h, c();
    }, b = (o, H) => {
      for (const h in o) {
        if (h === H) {
          delete o[h];
          break;
        }
        o[h].child && b(o[h].child, H);
      }
    }, s = (o) => {
      b(qe.value, o), c();
    }, R = (o, H) => {
      for (const h in o) {
        if (h === H) {
          const i = `hdl-${ce(8)}`;
          o[i] = {
            expand: !1,
            field: i,
            type: "string",
            value: ""
          };
          break;
        }
        o[h].child && R(o[h].child, H);
      }
    }, u = (o, H, h) => {
      if (o === "brother") {
        if (H.field === "root") {
          Ae.warning("无法添加兄弟节点");
          return;
        }
        R(qe.value, h), c();
        return;
      }
      if (H.type !== "array" && H.type !== "object") {
        Ae.warning("无法添加子节点");
        return;
      }
      Object.prototype.hasOwnProperty.call(H, "child") || (H.child = {});
      const i = `hdl-${ce(8)}`;
      H.child[i] = {
        expand: !1,
        field: i,
        type: "string",
        value: ""
      }, c();
    };
    return (o, H) => {
      const h = S("el-icon"), i = S("el-input"), V = S("el-option"), X = S("el-select"), L = S("el-dropdown-item"), J = S("el-dropdown-menu"), f = S("el-dropdown"), O = S("json-form", !0);
      return y(), N("div", {
        class: Xe(["json-form", e.indent === 0 ? "json-form-first" : ""]),
        id: e.jsonId,
        style: me({ paddingLeft: e.indent * 5 + "px" })
      }, [
        (y(!0), N(T, null, $(e.modelValue, (m, C) => (y(), N(T, { key: C }, [
          x("div", QC, [
            x("div", {
              class: "fold",
              onClick: (p) => d(m, C)
            }, [
              We(t(h, {
                class: Xe(["fold-icon", m.expand ? "fold-icon-right" : ""])
              }, {
                default: n(() => H[0] || (H[0] = [
                  x("svg", null, [
                    x("use", { href: "#triangle" })
                  ], -1)
                ])),
                _: 2
              }, 1032, ["class"]), [
                [Rg, m.type === "object" || m.type === "array"]
              ])
            ], 8, PC),
            x("div", EC, [
              t(i, {
                size: "small",
                placeholder: "请输入字段名",
                modelValue: m.field,
                "onUpdate:modelValue": (p) => m.field = p,
                disabled: v(I)(m.field) || e.fieldDisabled,
                readonly: e.readonly,
                onChange: Z
              }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "readonly"])
            ]),
            x("div", _C, [
              v(I)(m.field) ? (y(), U(X, {
                key: 0,
                modelValue: "object",
                size: "small",
                placeholder: "请选择字段类型",
                disabled: ""
              }, {
                default: n(() => [
                  (y(!0), N(T, null, $(v(a), (p) => (y(), U(V, {
                    key: p.value,
                    value: p.value,
                    label: p.label
                  }, null, 8, ["value", "label"]))), 128))
                ]),
                _: 2
              }, 1024)) : (y(), U(X, {
                key: 1,
                modelValue: m.type,
                "onUpdate:modelValue": (p) => m.type = p,
                size: "small",
                placeholder: "请选择字段类型",
                disabled: e.readonly,
                onChange: (p) => G(m)
              }, {
                default: n(() => [
                  (y(!0), N(T, null, $(v(a), (p) => (y(), U(V, {
                    key: p.value,
                    value: p.value,
                    label: p.label
                  }, null, 8, ["value", "label"]))), 128))
                ]),
                _: 2
              }, 1032, ["modelValue", "onUpdate:modelValue", "disabled", "onChange"]))
            ]),
            x("div", qC, [
              v(A)(m.type) ? (y(), U(X, {
                key: 0,
                size: "small",
                modelValue: m.value,
                "onUpdate:modelValue": (p) => m.value = p,
                placeholder: "请选择字段默认值",
                disabled: v(g)(m) || e.readonly,
                onChange: (p) => K(p, m)
              }, {
                default: n(() => [
                  t(V, {
                    value: !0,
                    label: "true"
                  }),
                  t(V, {
                    value: !1,
                    label: "false"
                  })
                ]),
                _: 2
              }, 1032, ["modelValue", "onUpdate:modelValue", "disabled", "onChange"])) : (y(), U(i, {
                key: 1,
                size: "small",
                modelValue: m.value,
                "onUpdate:modelValue": (p) => m.value = p,
                placeholder: "请输入字段默认值",
                disabled: v(g)(m),
                readonly: e.readonly,
                onChange: (p) => K(p, m)
              }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled", "readonly", "onChange"]))
            ]),
            e.readonly ? E("", !0) : (y(), N("div", $C, [
              m.field !== "root" ? (y(), N("div", {
                key: 0,
                class: "close-icon icon",
                onClick: (p) => s(C)
              }, [
                t(v(bI))
              ], 8, eA)) : E("", !0),
              t(f, {
                class: "icon",
                style: me({ paddingLeft: v(I)(m.field) ? "10px" : "5px" }),
                onCommand: (p) => u(p, m, C)
              }, {
                dropdown: n(() => [
                  t(J, null, {
                    default: n(() => [
                      t(L, { command: "child" }, {
                        default: n(() => H[1] || (H[1] = [
                          k("添加子节点")
                        ])),
                        _: 1
                      }),
                      t(L, { command: "brother" }, {
                        default: n(() => H[2] || (H[2] = [
                          k("添加兄弟节点")
                        ])),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                default: n(() => [
                  x("div", gA, [
                    t(v(Ne))
                  ])
                ]),
                _: 2
              }, 1032, ["style", "onCommand"])
            ]))
          ]),
          m.type === "object" ? (y(), U(O, {
            key: 0,
            modelValue: m.child,
            indent: e.indent + 1,
            jsonId: C,
            readonly: e.readonly
          }, null, 8, ["modelValue", "indent", "jsonId", "readonly"])) : E("", !0),
          m.type === "array" ? (y(), U(O, {
            key: 1,
            modelValue: m.child,
            indent: e.indent + 1,
            fieldDisabled: "",
            jsonId: C,
            readonly: e.readonly
          }, null, 8, ["modelValue", "indent", "jsonId", "readonly"])) : E("", !0)
        ], 64))), 128))
      ], 14, MC);
    };
  }
}), lA = { class: "hdl-json-form hdl-popup-height" }, CA = { class: "json-main" }, AA = /* @__PURE__ */ q({
  __name: "hdlJsonForm",
  props: {
    modelValue: {
      // 弹窗状态
      type: Boolean,
      default: !1
    },
    title: {
      // 弹窗标题
      type: String,
      default: "扩展JSON编辑器"
    },
    json: {
      // json数据
      type: [Object, String],
      default: () => ({})
    },
    options: {
      // 代码编辑器配置
      type: Object,
      default: () => ({})
    },
    readonly: {
      // 是否只读
      type: Boolean,
      default: !1
    }
  },
  emits: ["update:model-value", "update:json", "confirm"],
  setup(e, { emit: a }) {
    Cg.config.setModuleUrl("ace/mode/json", xC), Cg.config.setModuleUrl("ace/theme/chrome", LC), Cg.config.setModuleUrl("ace/mode/json_worker", FC);
    const l = e, I = a, A = W("{}"), g = W(!0), d = _(() => ({
      useWorker: !0,
      // 检测代码错误
      enableSnippets: !0,
      // 启用代码提示及补全
      enableLiveAutocompletion: !0,
      // 智能补全
      enableBasicAutocompletion: !0,
      // 自动补全
      tabSize: 2,
      wrap: !0,
      // 自动换行
      ...l.options,
      readOnly: l.readonly
    })), c = he("vAceEditorRef"), Z = () => {
      l.modelValue && I("update:model-value", !l.modelValue);
    };
    CI("vAceEditorElem", c);
    const G = () => {
      c.value.getAceInstance().on("change", Ze(() => {
        try {
          OC(bg(JSON.parse(A.value)), !1);
        } catch {
        }
      }, {
        isImmediate: !1
      }));
    }, K = () => {
      try {
        typeof l.json != "string" ? (A.value = JSON.stringify(l.json, null, 2), g.value = !0) : (A.value = JSON.stringify(JSON.parse(l.json), null, 2), g.value = !1);
      } catch {
        Ae.error("JSON数据格式错误");
      }
      G();
    }, b = () => {
      A.value = "{}", g.value = !0, TC();
    }, s = () => {
      typeof l.json == "string" ? I("update:json", A.value) : I("update:json", JSON.parse(A.value)), Z(), I("confirm");
    };
    return (R, u) => {
      const o = S("el-scrollbar"), H = S("el-button"), h = S("el-dialog");
      return y(), U(h, ae({ "model-value": e.modelValue }, v(Ye).dialogAttr, {
        class: "large-dialog",
        title: e.title,
        "onUpdate:modelValue": Z,
        onClose: b,
        onOpened: K
      }), {
        footer: n(() => [
          t(H, {
            type: "info",
            onClick: Z
          }, {
            default: n(() => u[1] || (u[1] = [
              k("取消")
            ])),
            _: 1
          }),
          t(H, {
            type: "primary",
            onClick: s
          }, {
            default: n(() => u[2] || (u[2] = [
              k("保存")
            ])),
            _: 1
          })
        ]),
        default: n(() => [
          x("div", lA, [
            x("div", CA, [
              t(v(yI), {
                ref: "vAceEditorRef",
                value: v(A),
                "onUpdate:value": u[0] || (u[0] = (i) => fe(A) ? A.value = i : null),
                class: "full-height",
                lang: "json",
                wrap: "",
                options: v(d)
              }, null, 8, ["value", "options"])
            ]),
            t(o, { class: "form-main" }, {
              default: n(() => [
                t(IA, {
                  "model-value": v(qe),
                  "json-id": `hdl-${v(DC)}`,
                  readonly: e.readonly
                }, null, 8, ["model-value", "json-id", "readonly"])
              ]),
              _: 1
            })
          ])
        ]),
        _: 1
      }, 16, ["model-value", "title"]);
    };
  }
}), Mg = (e) => {
  let a = "ws://";
  location.protocol.indexOf("https") !== -1 && (a = "wss://");
  const l = {
    value: Ng.reconnectInter.value,
    // 重连时间间隔
    index: 0,
    // 当前处于第几次重连
    time: null
    // 重连定时器
  }, I = Ie({}), A = {}, g = {}, d = (i, V) => {
    const X = ce();
    return g[i] || (g[i] = []), g[i].push({
      id: X,
      callback: V
    }), () => {
      g[i] = g[i].filter((L) => L.id !== X);
    };
  }, c = {}, Z = (i, V) => {
    const X = ce();
    return c[i] || (c[i] = []), c[i].push({
      id: X,
      callback: V
    }), () => {
      c[i] = c[i].filter((L) => L.id !== X);
    };
  }, G = {}, K = (i, V) => {
    const X = ce();
    return G[i] || (G[i] = []), G[i].push({
      id: X,
      callback: V
    }), () => {
      G[i] = G[i].filter((L) => L.id !== X);
    };
  }, b = {}, s = (i, V) => {
    const X = ce();
    return b[i] || (b[i] = []), b[i].push({
      id: X,
      callback: V
    }), () => {
      b[i] = b[i].filter((L) => L.id !== X);
    };
  }, R = {}, u = (i, V, X) => {
    I[i] && (I[i].send(JSON.stringify(V)), X && X.isHeartbeat && (R[i] = setInterval(() => {
      I[i].send(JSON.stringify(V));
    }, X.interval)));
  }, o = (i, V = !0) => {
    V && I[i] && I[i].close();
  }, H = (i) => I[i], h = (i, V) => {
    const X = i.wsFlag || i.url;
    if (Object.prototype.hasOwnProperty.call(I, X) && !V) {
      console.warn("websocket对应的唯一标识已存在，请更换唯一标识");
      return;
    }
    const L = `${e[i.url]}${i.data || ""}`;
    I[X] = new WebSocket(a + location.host + L), A[X] = JSON.parse(JSON.stringify(l)), I[X].onopen = () => {
      Object.prototype.hasOwnProperty.call(g, X) && g[X].forEach((J) => {
        J.callback();
      });
    }, I[X].onmessage = (J) => {
      Object.prototype.hasOwnProperty.call(c, X) && c[X].forEach((f) => {
        f.callback(JSON.parse(J.data));
      });
    }, I[X].onerror = (J) => {
      Object.prototype.hasOwnProperty.call(A, X) && b[X].forEach((f) => {
        f.callback(J);
      }), A[X].index < A[X].value.length && (A[X].time = setTimeout(() => {
        A[X].index++, h(i, !0);
      }, A[X].value[A[X].index]));
    }, I[X].onclose = (J) => {
      Object.prototype.hasOwnProperty.call(G, X) && G[X].forEach((f) => {
        f.callback(J);
      }), clearInterval(R[X]), delete I[X], delete g[X], delete c[X], delete G[X], delete R[X];
    };
  };
  return {
    useInitWs: h,
    useWsOpen: d,
    useWsMsg: Z,
    useWsClose: K,
    useWsError: s,
    useWsSend: u,
    useCloseWs: o,
    useGetWs: H
  };
};
Mg(gg);
const hA = {
  install(e, a) {
    e.component("hdlLogin", al), e.component("hdlNoPage", nl), e.component("hdlHeader", Ql), e.component("hdlMenus", aC), e.component("hdlSearch", dC), e.component("hdlBtn", cC), e.component("hdlCron", XC), e.component("hdlTable", SC), e.component("hdlForm", wC), e.component("hdlTree", YC), e.component("hdlFileImport", NC), e.component("hdlJsonForm", AA), YI(a), e.use($I);
  }
};
export {
  ie as axios,
  hA as default,
  cC as hdlBtn,
  XC as hdlCron,
  Ye as hdlDialogConfig,
  rA as hdlElUploadConfig,
  NC as hdlFileImport,
  wC as hdlForm,
  Jg as hdlFormConfig,
  Ql as hdlHeader,
  AA as hdlJsonForm,
  al as hdlLogin,
  He as hdlLoginConfig,
  aC as hdlMenus,
  hg as hdlMenusConfig,
  nl as hdlNoPage,
  dC as hdlSearch,
  kg as hdlSearchConfig,
  Ce as hdlStorageKeyConfig,
  SC as hdlTable,
  Be as hdlTableConfig,
  YC as hdlTree,
  Re as hdlTreeConfig,
  Ng as hdlWsConfig,
  _e as pageSnData,
  GA as useAssign,
  FI as useAxios,
  TI as useBlobDownload,
  Ze as useDebounce,
  Dg as useDomResize,
  OI as useDownFile,
  jg as useEventBus,
  vA as useFileOperate,
  yA as useFormatDate,
  ug as useGetDictChild,
  mg as useGetPageAuth,
  jI as useGetSearchParams,
  VI as useHdlLocalStorageKeyConfig,
  BI as useHdlLoginConfig,
  hI as useImgPreview,
  MI as useLinkIconScript,
  Og as useMutationObserver,
  DI as usePagination,
  zI as useRegisterRoute,
  ZA as useSetRouteView,
  pA as useSleep,
  WA as useTableRoll,
  ce as useUUID,
  Mg as useWs
};
