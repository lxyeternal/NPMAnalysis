import { Plugin } from 'vite';
export declare const hdlListenModule: () => Plugin;
