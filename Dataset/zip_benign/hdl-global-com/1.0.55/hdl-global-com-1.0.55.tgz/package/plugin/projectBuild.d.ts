export declare const hdlProjectBuild: () => {
    name: string;
    apply: string;
    writeBundle(): Promise<void>;
};
