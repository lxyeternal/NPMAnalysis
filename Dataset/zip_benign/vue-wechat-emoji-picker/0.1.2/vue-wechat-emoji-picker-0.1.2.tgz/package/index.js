import { defineComponent as S, ref as p, openBlock as I, createElementBlock as x, createElementVNode as _, normalizeStyle as k, pushScopeId as E, popScopeId as C } from "vue";
const M = (n) => (E("data-v-6f35c610"), n = n(), C(), n), B = ["src"], P = /* @__PURE__ */ M(() => /* @__PURE__ */ _("div", { id: "emoji-preview" }, null, -1)), z = 62, X = /* @__PURE__ */ S({
  __name: "index",
  props: {
    scale: {
      type: Number,
      default: 0.5
    }
  },
  emits: ["onSelect"],
  setup(n, { emit: m }) {
    const s = n, d = m, r = z * s.scale, j = (e) => new Promise((t, i) => {
      const o = new Image();
      o.onload = () => {
        t({
          width: o.width,
          height: o.height
        });
      }, o.onerror = i, o.src = e;
    }), a = p({ width: 0, height: 0 }), g = (e, t) => {
      const i = [
        ["[微笑]", "[撇嘴]", "[色]", "[发呆]", "[得意]", "[流泪]", "[害羞]", "[闭嘴]", "[睡]", "[大哭]", "[尴尬]"],
        ["[发怒]", "[调皮]", "[呲牙]", "[惊讶]", "[难过]", "[酷]", "[冷汗]", "[抓狂]", "[吐]", "[偷笑]", "[愉快]"],
        ["[白眼]", "[傲慢]", "[饥饿]", "[困]", "[惊恐]", "[流汗]", "[憨笑]", "[悠闲]", "[奋斗]", "[咒骂]", "[疑问]"],
        ["[嘘]", "[晕]", "[疯了]", "[衰]", "[骷髅]", "[敲打]", "[再见]", "[擦汗]", "[抠鼻]", "[鼓掌]", "[糗大了]"],
        ["[坏笑]", "[左哼哼]", "[右哼哼]", "[哈欠]", "[鄙视]", "[委屈]", "[快哭了]", "[阴险]", "[亲亲]", "[吓]", "[可怜]"],
        ["[菜刀]", "[西瓜]", "[啤酒]", "[篮球]", "[乒乓]", "[咖啡]", "[饭]", "[猪头]", "[玫瑰]", "[凋谢]", "[嘴唇]"],
        ["[爱心]", "[心碎]", "[蛋糕]", "[闪电]", "[炸弹]", "[刀]", "[足球]", "[瓢虫]", "[便便]", "[月亮]", "[太阳]"],
        ["[礼物]", "[拥抱]", "[强]", "[弱]", "[握手]", "[胜利]", "[抱拳]", "[勾引]", "[拳头]", "[差劲]", "[爱你]"],
        ["[NO]", "[OK]", "[爱情]", "[飞吻]", "[跳跳]", "[发抖]", "[怄火]", "[转圈]", "[磕头]", "[回头]", "[跳绳]"],
        ["[投降]", "[Hooray]", "[Meditate]", "[Smooch]", "[TaiChi L]", "[TaiChi R]"]
      ], o = Math.floor(e / r), c = Math.floor(t / r);
      return o < 0 || c < 0 || o >= i[0].length || c >= i.length ? "无效的坐标" : i[c][o];
    }, h = p(null), y = (e) => {
      const t = h.value.getBoundingClientRect(), i = e.clientX - t.left, o = e.clientY - t.top;
      d("onSelect", g(i, o));
    };
    let f;
    const w = (e) => {
      const t = h.value.getBoundingClientRect(), i = e.clientX - t.left, o = e.clientY - t.top, c = g(i, o);
      if (f === c)
        return;
      f = c;
      const l = document.getElementById("emoji-preview");
      if (l) {
        if (!c) {
          l.style.display = "none";
          return;
        }
        l.innerHTML = c, l.style.display = "block", l.style.left = `${e.clientX + 10}px`, l.style.top = `${e.clientY + 10}px`;
      }
    }, u = p("");
    return (async () => {
      const { default: e } = await import("./wechat-emoticons-o5oNCHa0.js");
      u.value = e;
      const t = await j(u.value);
      a.value.width = t.width * s.scale, a.value.height = t.height * s.scale;
    })(), (e, t) => (I(), x("div", null, [
      _("img", {
        ref_key: "emojiIcons",
        ref: h,
        src: u.value,
        onMousemove: w,
        onClick: y,
        style: k(`width: ${a.value.width}px; height: ${a.value.height}px`)
      }, null, 44, B),
      P
    ]));
  }
}), Y = (n, m) => {
  const s = n.__vccOpts || n;
  for (const [d, r] of m)
    s[d] = r;
  return s;
}, v = /* @__PURE__ */ Y(X, [["__scopeId", "data-v-6f35c610"]]);
v.install = (n) => (n.component("WechatEmojiPicker", v), n);
export {
  v as default
};
