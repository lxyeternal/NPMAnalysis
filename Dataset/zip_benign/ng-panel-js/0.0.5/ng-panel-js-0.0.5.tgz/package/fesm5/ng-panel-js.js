import 'hammerjs';
import { __decorate, __param, __extends } from 'tslib';
import { InjectionToken, Inject, ɵɵdefineInjectable, ɵɵinject, Injectable, HostListener, Component, ElementRef, Injector, NgModule } from '@angular/core';
import { BehaviorSubject, Subject, Observable } from 'rxjs';
import { createCustomElement } from '@angular/elements';
import { HammerGestureConfig, HammerModule, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';

var LIB_CONFIG = new InjectionToken('LIB_CONFIG');

var PanelJsService = /** @class */ (function () {
    function PanelJsService(config) {
        this.config = config;
        this.scrollLockSubject = new BehaviorSubject(false);
        this.currentScrollLock$ = this.scrollLockSubject.asObservable();
        this.events$ = new Subject();
    }
    PanelJsService.prototype.animateStage0 = function () { };
    PanelJsService.prototype.animateStage1 = function () { };
    PanelJsService.prototype.animateAnchorStage = function () { };
    PanelJsService.prototype.toggle = function () {
        this.events$.next('toggle');
    };
    PanelJsService.prototype.getScrollLock = function () { return this.currentScrollLock$; };
    PanelJsService.prototype.setScrollLock = function (newValue) { this.scrollLockSubject.next(newValue); };
    PanelJsService.prototype.getSwipeEvents = function () {
        return Observable.create(function (observer) { return observer.next(); });
    };
    PanelJsService.prototype.getConfig = function () {
        return this.config;
    };
    PanelJsService.prototype.getEvents = function () {
        return this.events$;
    };
    PanelJsService.ctorParameters = function () { return [
        { type: undefined, decorators: [{ type: Inject, args: [LIB_CONFIG,] }] }
    ]; };
    PanelJsService.ɵprov = ɵɵdefineInjectable({ factory: function PanelJsService_Factory() { return new PanelJsService(ɵɵinject(LIB_CONFIG)); }, token: PanelJsService, providedIn: "root" });
    PanelJsService = __decorate([
        Injectable({
            providedIn: 'root'
        }),
        __param(0, Inject(LIB_CONFIG))
    ], PanelJsService);
    return PanelJsService;
}());

var PanelJsComponent = /** @class */ (function () {
    function PanelJsComponent(panelService) {
        this.panelService = panelService;
        this.transitionSpeed = '0s';
        // Used to fix iOS propogation bug
        this.colour = "purple";
        this.colourSubject = new BehaviorSubject("red");
        var config = panelService.getConfig();
        this.stage0 = window.innerHeight * (1 - config.stage0);
        this.stage1 = window.innerHeight * (1 - config.stage1);
        this.persistentMode = config.persistent;
        if (this.persistentMode) {
            this.animateStage0();
            this.panelOpen = true;
        }
        else {
            this.animateClose();
            this.panelOpen = false;
        }
        this.stageBoundary = this.stage0 / 2;
    }
    PanelJsComponent.prototype.panstart = function (event) {
        // event.preventDefault();
        this.transitionSpeed = '0s';
        this.startPos = event.deltaY - this.pos;
    };
    PanelJsComponent.prototype.panmove = function (event) {
        var touchPos = event.deltaY - this.startPos;
        // Prevent panel from going out of boundaries
        console.log(event);
        if (this.persistentMode) {
            if (touchPos > this.stage1 && touchPos < this.stage0) {
                this.pos = touchPos;
            }
        }
        else {
            if (touchPos > this.stage1) {
                this.pos = touchPos;
            }
        }
    };
    PanelJsComponent.prototype.panend = function (event) {
        this.transitionSpeed = '0.3s';
        var speed = Math.abs(event.velocity);
        console.log(event);
        // Swipe down
        if (event.offsetDirection === 16) {
            if (this.currentStage === 1) {
                if (speed > 0.5 || this.pos > this.stageBoundary) {
                    this.animateStage0();
                }
                else {
                    this.animateStage1();
                }
            }
            else if (this.currentStage === 0 && !this.persistentMode) {
                this.toggle();
            }
        }
        // Swipe up
        else if (event.offsetDirection === 8) {
            if (this.currentStage === 0) {
                if (speed > 0.5 || this.pos < this.stageBoundary) {
                    this.animateStage1();
                }
                else {
                    this.animateStage0();
                }
            }
        }
    };
    PanelJsComponent.prototype.animateStage1 = function () {
        this.panelService.setScrollLock(true);
        this.pos = this.stage1;
        this.currentStage = 1;
        this.colourSubject.next('green');
    };
    PanelJsComponent.prototype.animateStage0 = function () {
        this.panelService.setScrollLock(false);
        this.pos = this.stage0;
        this.currentStage = 0;
        this.colourSubject.next('blue');
    };
    PanelJsComponent.prototype.animateClose = function () {
        this.panelService.setScrollLock(false);
        this.pos = window.innerHeight;
        this.currentStage = -1;
        this.colourSubject.next('yellow');
    };
    PanelJsComponent.prototype.toggle = function () {
        this.transitionSpeed = '0.3s';
        if (!this.persistentMode) {
            if (this.panelOpen) {
                this.animateClose();
            }
            else {
                this.animateStage0();
            }
            this.panelOpen = !this.panelOpen;
        }
    };
    PanelJsComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.panelService.getEvents().subscribe(function (event) {
            switch (event) {
                case 'toggle':
                    _this.toggle();
                    break;
                default:
                    break;
            }
        });
        console.log(this.panelService.getConfig());
        this.colourSubject.asObservable().subscribe(function (color) {
            if (_this.colour === color) {
                _this.colour = "purple";
            }
            else {
                _this.colour = color;
            }
        });
    };
    PanelJsComponent.ctorParameters = function () { return [
        { type: PanelJsService }
    ]; };
    __decorate([
        HostListener('panstart', ['$event'])
    ], PanelJsComponent.prototype, "panstart", null);
    __decorate([
        HostListener('panmove', ['$event'])
    ], PanelJsComponent.prototype, "panmove", null);
    __decorate([
        HostListener('panend', ['$event'])
    ], PanelJsComponent.prototype, "panend", null);
    PanelJsComponent = __decorate([
        Component({
            selector: 'panel-js',
            template: '<ng-content></ng-content>',
            host: {
                "[style.transform]": "'translate3d(0, '+pos+'px, 0)'",
                "[style.transition]": "transitionSpeed",
                "[style.backgroundColor]": "colour",
                "[style.display]": "'block'",
                "[style.willChange]": "'transform'"
            },
            styles: [":host{position:absolute;bottom:0;left:0;padding:0;margin:0;width:100%;height:100%;will-change:transform;z-index:1000;background:red;border-radius:25%}ng-content>*{width:100%!important;height:100%!important}"]
        })
    ], PanelJsComponent);
    return PanelJsComponent;
}());

var PanelJsScrollComponent = /** @class */ (function () {
    function PanelJsScrollComponent(panelService, elementRef) {
        this.panelService = panelService;
        this.elementRef = elementRef;
    }
    PanelJsScrollComponent.prototype.onScroll = function (event) {
        console.log('scroll');
        // event.stopPropagation();
    };
    PanelJsScrollComponent.prototype.ngOnInit = function () {
        var _this = this;
        console.log("panel scroll init");
        // const scrollEvent$: Observable<Event> = fromEvent(this.elementRef.nativeElement, 'scroll');
        // this.panelService.setScrollListener(scrollEvent$);
        this.panelService.getScrollLock().subscribe(function (lock) {
            if (lock) {
                _this.overflow = "scroll";
            }
            else {
                _this.overflow = "hidden";
            }
            //this.overflow = "scroll";
        });
    };
    PanelJsScrollComponent.ctorParameters = function () { return [
        { type: PanelJsService },
        { type: ElementRef }
    ]; };
    __decorate([
        HostListener('pan', ['$event'])
    ], PanelJsScrollComponent.prototype, "onScroll", null);
    PanelJsScrollComponent = __decorate([
        Component({
            selector: 'panel-js-scroll',
            template: '<ng-content></ng-content>',
            host: {
                "[style.overflowY]": "overflow",
                "[style.display]": "'block'",
            },
            styles: [""]
        })
    ], PanelJsScrollComponent);
    return PanelJsScrollComponent;
}());

var PanelHammerConfig = /** @class */ (function (_super) {
    __extends(PanelHammerConfig, _super);
    function PanelHammerConfig() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.overrides = {
            'pan': { threshold: 0 }
        };
        return _this;
    }
    PanelHammerConfig = __decorate([
        Injectable()
    ], PanelHammerConfig);
    return PanelHammerConfig;
}(HammerGestureConfig));
var PanelJsModule = /** @class */ (function () {
    function PanelJsModule(injector) {
        this.injector = injector;
    }
    PanelJsModule_1 = PanelJsModule;
    PanelJsModule.prototype.ngDoBootstrap = function () {
        var panel = createCustomElement(PanelJsComponent, { injector: this.injector });
        var panelScroll = createCustomElement(PanelJsScrollComponent, { injector: this.injector });
        customElements.define('panel-js', panel);
        customElements.define('panel-js-scroll', panelScroll);
    };
    PanelJsModule.forRoot = function (config) {
        return ({
            ngModule: PanelJsModule_1,
            providers: [
                {
                    provide: LIB_CONFIG,
                    useValue: config
                }
            ]
        });
    };
    var PanelJsModule_1;
    PanelJsModule.ctorParameters = function () { return [
        { type: Injector }
    ]; };
    PanelJsModule = PanelJsModule_1 = __decorate([
        NgModule({
            declarations: [PanelJsComponent, PanelJsScrollComponent],
            imports: [HammerModule],
            entryComponents: [PanelJsComponent, PanelJsScrollComponent],
            exports: [PanelJsComponent, PanelJsScrollComponent],
            providers: [{
                    provide: HAMMER_GESTURE_CONFIG,
                    useClass: PanelHammerConfig
                }]
        })
    ], PanelJsModule);
    return PanelJsModule;
}());

/*
 * Public API Surface of panel-js
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LIB_CONFIG, PanelHammerConfig, PanelJsComponent, PanelJsModule, PanelJsScrollComponent, PanelJsService };
//# sourceMappingURL=ng-panel-js.js.map
