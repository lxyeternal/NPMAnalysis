(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('hammerjs'), require('@angular/core'), require('rxjs'), require('@angular/elements'), require('@angular/platform-browser')) :
    typeof define === 'function' && define.amd ? define('ng-panel-js', ['exports', 'hammerjs', '@angular/core', 'rxjs', '@angular/elements', '@angular/platform-browser'], factory) :
    (global = global || self, factory(global['ng-panel-js'] = {}, null, global.ng.core, global.rxjs, global.ng.elements, global.ng.platformBrowser));
}(this, (function (exports, hammerjs, core, rxjs, elements, platformBrowser) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0

    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.

    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */
    /* global Reflect, Promise */

    var extendStatics = function(d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };

    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var __assign = function() {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };

    function __rest(s, e) {
        var t = {};
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
            t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }

    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); }
    }

    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }

    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    }

    function __exportStar(m, exports) {
        for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }

    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m) return m.call(o);
        if (o && typeof o.length === "number") return {
            next: function () {
                if (o && i >= o.length) o = void 0;
                return { value: o && o[i++], done: !o };
            }
        };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }

    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m) return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
        }
        catch (error) { e = { error: error }; }
        finally {
            try {
                if (r && !r.done && (m = i["return"])) m.call(i);
            }
            finally { if (e) throw e.error; }
        }
        return ar;
    }

    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }

    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++) s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    };

    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n]) i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try { step(g[n](v)); } catch (e) { settle(q[0][3], e); } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]); }
    }

    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }

    function __asyncValues(o) {
        if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function(v) { resolve({ value: v, done: d }); }, reject); }
    }

    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) { Object.defineProperty(cooked, "raw", { value: raw }); } else { cooked.raw = raw; }
        return cooked;
    };

    function __importStar(mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k in mod) if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
        result.default = mod;
        return result;
    }

    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }

    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }

    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    var LIB_CONFIG = new core.InjectionToken('LIB_CONFIG');

    var PanelJsService = /** @class */ (function () {
        function PanelJsService(config) {
            this.config = config;
            this.scrollLockSubject = new rxjs.BehaviorSubject(false);
            this.currentScrollLock$ = this.scrollLockSubject.asObservable();
            this.events$ = new rxjs.Subject();
        }
        PanelJsService.prototype.animateStage0 = function () { };
        PanelJsService.prototype.animateStage1 = function () { };
        PanelJsService.prototype.animateAnchorStage = function () { };
        PanelJsService.prototype.toggle = function () {
            this.events$.next('toggle');
        };
        PanelJsService.prototype.getScrollLock = function () { return this.currentScrollLock$; };
        PanelJsService.prototype.setScrollLock = function (newValue) { this.scrollLockSubject.next(newValue); };
        PanelJsService.prototype.getSwipeEvents = function () {
            return rxjs.Observable.create(function (observer) { return observer.next(); });
        };
        PanelJsService.prototype.getConfig = function () {
            return this.config;
        };
        PanelJsService.prototype.getEvents = function () {
            return this.events$;
        };
        PanelJsService.ctorParameters = function () { return [
            { type: undefined, decorators: [{ type: core.Inject, args: [LIB_CONFIG,] }] }
        ]; };
        PanelJsService.ɵprov = core["ɵɵdefineInjectable"]({ factory: function PanelJsService_Factory() { return new PanelJsService(core["ɵɵinject"](LIB_CONFIG)); }, token: PanelJsService, providedIn: "root" });
        PanelJsService = __decorate([
            core.Injectable({
                providedIn: 'root'
            }),
            __param(0, core.Inject(LIB_CONFIG))
        ], PanelJsService);
        return PanelJsService;
    }());

    var PanelJsComponent = /** @class */ (function () {
        function PanelJsComponent(panelService) {
            this.panelService = panelService;
            this.transitionSpeed = '0s';
            // Used to fix iOS propogation bug
            this.colour = "purple";
            this.colourSubject = new rxjs.BehaviorSubject("red");
            var config = panelService.getConfig();
            this.stage0 = window.innerHeight * (1 - config.stage0);
            this.stage1 = window.innerHeight * (1 - config.stage1);
            this.persistentMode = config.persistent;
            if (this.persistentMode) {
                this.animateStage0();
                this.panelOpen = true;
            }
            else {
                this.animateClose();
                this.panelOpen = false;
            }
            this.stageBoundary = this.stage0 / 2;
        }
        PanelJsComponent.prototype.panstart = function (event) {
            // event.preventDefault();
            this.transitionSpeed = '0s';
            this.startPos = event.deltaY - this.pos;
        };
        PanelJsComponent.prototype.panmove = function (event) {
            var touchPos = event.deltaY - this.startPos;
            // Prevent panel from going out of boundaries
            console.log(event);
            if (this.persistentMode) {
                if (touchPos > this.stage1 && touchPos < this.stage0) {
                    this.pos = touchPos;
                }
            }
            else {
                if (touchPos > this.stage1) {
                    this.pos = touchPos;
                }
            }
        };
        PanelJsComponent.prototype.panend = function (event) {
            this.transitionSpeed = '0.3s';
            var speed = Math.abs(event.velocity);
            console.log(event);
            // Swipe down
            if (event.offsetDirection === 16) {
                if (this.currentStage === 1) {
                    if (speed > 0.5 || this.pos > this.stageBoundary) {
                        this.animateStage0();
                    }
                    else {
                        this.animateStage1();
                    }
                }
                else if (this.currentStage === 0 && !this.persistentMode) {
                    this.toggle();
                }
            }
            // Swipe up
            else if (event.offsetDirection === 8) {
                if (this.currentStage === 0) {
                    if (speed > 0.5 || this.pos < this.stageBoundary) {
                        this.animateStage1();
                    }
                    else {
                        this.animateStage0();
                    }
                }
            }
        };
        PanelJsComponent.prototype.animateStage1 = function () {
            this.panelService.setScrollLock(true);
            this.pos = this.stage1;
            this.currentStage = 1;
            this.colourSubject.next('green');
        };
        PanelJsComponent.prototype.animateStage0 = function () {
            this.panelService.setScrollLock(false);
            this.pos = this.stage0;
            this.currentStage = 0;
            this.colourSubject.next('blue');
        };
        PanelJsComponent.prototype.animateClose = function () {
            this.panelService.setScrollLock(false);
            this.pos = window.innerHeight;
            this.currentStage = -1;
            this.colourSubject.next('yellow');
        };
        PanelJsComponent.prototype.toggle = function () {
            this.transitionSpeed = '0.3s';
            if (!this.persistentMode) {
                if (this.panelOpen) {
                    this.animateClose();
                }
                else {
                    this.animateStage0();
                }
                this.panelOpen = !this.panelOpen;
            }
        };
        PanelJsComponent.prototype.ngOnInit = function () {
            var _this = this;
            this.panelService.getEvents().subscribe(function (event) {
                switch (event) {
                    case 'toggle':
                        _this.toggle();
                        break;
                    default:
                        break;
                }
            });
            console.log(this.panelService.getConfig());
            this.colourSubject.asObservable().subscribe(function (color) {
                if (_this.colour === color) {
                    _this.colour = "purple";
                }
                else {
                    _this.colour = color;
                }
            });
        };
        PanelJsComponent.ctorParameters = function () { return [
            { type: PanelJsService }
        ]; };
        __decorate([
            core.HostListener('panstart', ['$event'])
        ], PanelJsComponent.prototype, "panstart", null);
        __decorate([
            core.HostListener('panmove', ['$event'])
        ], PanelJsComponent.prototype, "panmove", null);
        __decorate([
            core.HostListener('panend', ['$event'])
        ], PanelJsComponent.prototype, "panend", null);
        PanelJsComponent = __decorate([
            core.Component({
                selector: 'panel-js',
                template: '<ng-content></ng-content>',
                host: {
                    "[style.transform]": "'translate3d(0, '+pos+'px, 0)'",
                    "[style.transition]": "transitionSpeed",
                    "[style.backgroundColor]": "colour",
                    "[style.display]": "'block'",
                    "[style.willChange]": "'transform'"
                },
                styles: [":host{position:absolute;bottom:0;left:0;padding:0;margin:0;width:100%;height:100%;will-change:transform;z-index:1000;background:red;border-radius:25%}ng-content>*{width:100%!important;height:100%!important}"]
            })
        ], PanelJsComponent);
        return PanelJsComponent;
    }());

    var PanelJsScrollComponent = /** @class */ (function () {
        function PanelJsScrollComponent(panelService, elementRef) {
            this.panelService = panelService;
            this.elementRef = elementRef;
        }
        PanelJsScrollComponent.prototype.onScroll = function (event) {
            console.log('scroll');
            // event.stopPropagation();
        };
        PanelJsScrollComponent.prototype.ngOnInit = function () {
            var _this = this;
            console.log("panel scroll init");
            // const scrollEvent$: Observable<Event> = fromEvent(this.elementRef.nativeElement, 'scroll');
            // this.panelService.setScrollListener(scrollEvent$);
            this.panelService.getScrollLock().subscribe(function (lock) {
                if (lock) {
                    _this.overflow = "scroll";
                }
                else {
                    _this.overflow = "hidden";
                }
                //this.overflow = "scroll";
            });
        };
        PanelJsScrollComponent.ctorParameters = function () { return [
            { type: PanelJsService },
            { type: core.ElementRef }
        ]; };
        __decorate([
            core.HostListener('pan', ['$event'])
        ], PanelJsScrollComponent.prototype, "onScroll", null);
        PanelJsScrollComponent = __decorate([
            core.Component({
                selector: 'panel-js-scroll',
                template: '<ng-content></ng-content>',
                host: {
                    "[style.overflowY]": "overflow",
                    "[style.display]": "'block'",
                },
                styles: [""]
            })
        ], PanelJsScrollComponent);
        return PanelJsScrollComponent;
    }());

    var PanelHammerConfig = /** @class */ (function (_super) {
        __extends(PanelHammerConfig, _super);
        function PanelHammerConfig() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.overrides = {
                'pan': { threshold: 0 }
            };
            return _this;
        }
        PanelHammerConfig = __decorate([
            core.Injectable()
        ], PanelHammerConfig);
        return PanelHammerConfig;
    }(platformBrowser.HammerGestureConfig));
    var PanelJsModule = /** @class */ (function () {
        function PanelJsModule(injector) {
            this.injector = injector;
        }
        PanelJsModule_1 = PanelJsModule;
        PanelJsModule.prototype.ngDoBootstrap = function () {
            var panel = elements.createCustomElement(PanelJsComponent, { injector: this.injector });
            var panelScroll = elements.createCustomElement(PanelJsScrollComponent, { injector: this.injector });
            customElements.define('panel-js', panel);
            customElements.define('panel-js-scroll', panelScroll);
        };
        PanelJsModule.forRoot = function (config) {
            return ({
                ngModule: PanelJsModule_1,
                providers: [
                    {
                        provide: LIB_CONFIG,
                        useValue: config
                    }
                ]
            });
        };
        var PanelJsModule_1;
        PanelJsModule.ctorParameters = function () { return [
            { type: core.Injector }
        ]; };
        PanelJsModule = PanelJsModule_1 = __decorate([
            core.NgModule({
                declarations: [PanelJsComponent, PanelJsScrollComponent],
                imports: [platformBrowser.HammerModule],
                entryComponents: [PanelJsComponent, PanelJsScrollComponent],
                exports: [PanelJsComponent, PanelJsScrollComponent],
                providers: [{
                        provide: platformBrowser.HAMMER_GESTURE_CONFIG,
                        useClass: PanelHammerConfig
                    }]
            })
        ], PanelJsModule);
        return PanelJsModule;
    }());

    exports.LIB_CONFIG = LIB_CONFIG;
    exports.PanelHammerConfig = PanelHammerConfig;
    exports.PanelJsComponent = PanelJsComponent;
    exports.PanelJsModule = PanelJsModule;
    exports.PanelJsScrollComponent = PanelJsScrollComponent;
    exports.PanelJsService = PanelJsService;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=ng-panel-js.umd.js.map
