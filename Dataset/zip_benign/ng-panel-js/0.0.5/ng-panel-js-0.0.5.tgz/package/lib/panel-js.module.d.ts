import { Injector, ModuleWithProviders } from '@angular/core';
import { HammerGestureConfig } from '@angular/platform-browser';
import { PanelJSConfig } from './config';
export declare class PanelHammerConfig extends HammerGestureConfig {
    overrides: any;
}
export declare class PanelJsModule {
    private injector;
    constructor(injector: Injector);
    ngDoBootstrap(): void;
    static forRoot(config: PanelJSConfig): ModuleWithProviders;
}
