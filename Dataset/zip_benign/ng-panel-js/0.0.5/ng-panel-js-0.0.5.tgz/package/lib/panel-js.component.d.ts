/// <reference types="hammerjs" />
import { OnInit } from '@angular/core';
import { PanelJsService } from './panel-js.service';
export declare class PanelJsComponent implements OnInit {
    private panelService;
    private startPos;
    private stage0;
    private stage1;
    private stageBoundary;
    private currentStage;
    private persistentMode;
    private panelOpen;
    pos: number;
    transitionSpeed: string;
    colour: string;
    private colourSubject;
    constructor(panelService: PanelJsService);
    panstart(event: HammerInput): void;
    panmove(event: HammerInput): void;
    panend(event: HammerInput): void;
    animateStage1(): void;
    animateStage0(): void;
    animateClose(): void;
    toggle(): void;
    ngOnInit(): void;
}
