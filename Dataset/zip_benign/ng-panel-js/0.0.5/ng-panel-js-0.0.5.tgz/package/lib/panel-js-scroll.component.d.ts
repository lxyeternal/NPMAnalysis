import { OnInit, ElementRef } from '@angular/core';
import { PanelJsService } from './panel-js.service';
export declare class PanelJsScrollComponent implements OnInit {
    private panelService;
    private elementRef;
    overflow: string;
    constructor(panelService: PanelJsService, elementRef: ElementRef);
    onScroll(event: Event): void;
    ngOnInit(): void;
}
