import { Observable } from 'rxjs';
import { PanelJSConfig } from './config';
export declare class PanelJsService {
    private config;
    constructor(config: PanelJSConfig);
    private scrollLockSubject;
    private currentScrollLock$;
    private events$;
    animateStage0(): void;
    animateStage1(): void;
    animateAnchorStage(): void;
    toggle(): void;
    getScrollLock(): Observable<boolean>;
    setScrollLock(newValue: boolean): void;
    getSwipeEvents(): Observable<any>;
    getConfig(): PanelJSConfig;
    getEvents(): Observable<string>;
}
