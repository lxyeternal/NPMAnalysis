import { InjectionToken } from '@angular/core';
export interface PanelJSConfig {
    persistent?: boolean;
    stage0?: number;
    stage1?: number;
}
export declare const LIB_CONFIG: InjectionToken<PanelJSConfig>;
