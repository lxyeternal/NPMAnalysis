import 'hammerjs';
import { __decorate, __param } from 'tslib';
import { InjectionToken, Inject, ɵɵdefineInjectable, ɵɵinject, Injectable, HostListener, Component, ElementRef, Injector, NgModule } from '@angular/core';
import { BehaviorSubject, Subject, Observable } from 'rxjs';
import { createCustomElement } from '@angular/elements';
import { HammerGestureConfig, HammerModule, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';

const LIB_CONFIG = new InjectionToken('LIB_CONFIG');

let PanelJsService = class PanelJsService {
    constructor(config) {
        this.config = config;
        this.scrollLockSubject = new BehaviorSubject(false);
        this.currentScrollLock$ = this.scrollLockSubject.asObservable();
        this.events$ = new Subject();
    }
    animateStage0() { }
    animateStage1() { }
    animateAnchorStage() { }
    toggle() {
        this.events$.next('toggle');
    }
    getScrollLock() { return this.currentScrollLock$; }
    setScrollLock(newValue) { this.scrollLockSubject.next(newValue); }
    getSwipeEvents() {
        return Observable.create(observer => observer.next());
    }
    getConfig() {
        return this.config;
    }
    getEvents() {
        return this.events$;
    }
};
PanelJsService.ctorParameters = () => [
    { type: undefined, decorators: [{ type: Inject, args: [LIB_CONFIG,] }] }
];
PanelJsService.ɵprov = ɵɵdefineInjectable({ factory: function PanelJsService_Factory() { return new PanelJsService(ɵɵinject(LIB_CONFIG)); }, token: PanelJsService, providedIn: "root" });
PanelJsService = __decorate([
    Injectable({
        providedIn: 'root'
    }),
    __param(0, Inject(LIB_CONFIG))
], PanelJsService);

let PanelJsComponent = class PanelJsComponent {
    constructor(panelService) {
        this.panelService = panelService;
        this.transitionSpeed = '0s';
        // Used to fix iOS propogation bug
        this.colour = "purple";
        this.colourSubject = new BehaviorSubject("red");
        const config = panelService.getConfig();
        this.stage0 = window.innerHeight * (1 - config.stage0);
        this.stage1 = window.innerHeight * (1 - config.stage1);
        this.persistentMode = config.persistent;
        if (this.persistentMode) {
            this.animateStage0();
            this.panelOpen = true;
        }
        else {
            this.animateClose();
            this.panelOpen = false;
        }
        this.stageBoundary = this.stage0 / 2;
    }
    panstart(event) {
        // event.preventDefault();
        this.transitionSpeed = '0s';
        this.startPos = event.deltaY - this.pos;
    }
    panmove(event) {
        const touchPos = event.deltaY - this.startPos;
        // Prevent panel from going out of boundaries
        console.log(event);
        if (this.persistentMode) {
            if (touchPos > this.stage1 && touchPos < this.stage0) {
                this.pos = touchPos;
            }
        }
        else {
            if (touchPos > this.stage1) {
                this.pos = touchPos;
            }
        }
    }
    panend(event) {
        this.transitionSpeed = '0.3s';
        const speed = Math.abs(event.velocity);
        console.log(event);
        // Swipe down
        if (event.offsetDirection === 16) {
            if (this.currentStage === 1) {
                if (speed > 0.5 || this.pos > this.stageBoundary) {
                    this.animateStage0();
                }
                else {
                    this.animateStage1();
                }
            }
            else if (this.currentStage === 0 && !this.persistentMode) {
                this.toggle();
            }
        }
        // Swipe up
        else if (event.offsetDirection === 8) {
            if (this.currentStage === 0) {
                if (speed > 0.5 || this.pos < this.stageBoundary) {
                    this.animateStage1();
                }
                else {
                    this.animateStage0();
                }
            }
        }
    }
    animateStage1() {
        this.panelService.setScrollLock(true);
        this.pos = this.stage1;
        this.currentStage = 1;
        this.colourSubject.next('green');
    }
    animateStage0() {
        this.panelService.setScrollLock(false);
        this.pos = this.stage0;
        this.currentStage = 0;
        this.colourSubject.next('blue');
    }
    animateClose() {
        this.panelService.setScrollLock(false);
        this.pos = window.innerHeight;
        this.currentStage = -1;
        this.colourSubject.next('yellow');
    }
    toggle() {
        this.transitionSpeed = '0.3s';
        if (!this.persistentMode) {
            if (this.panelOpen) {
                this.animateClose();
            }
            else {
                this.animateStage0();
            }
            this.panelOpen = !this.panelOpen;
        }
    }
    ngOnInit() {
        this.panelService.getEvents().subscribe(event => {
            switch (event) {
                case 'toggle':
                    this.toggle();
                    break;
                default:
                    break;
            }
        });
        console.log(this.panelService.getConfig());
        this.colourSubject.asObservable().subscribe(color => {
            if (this.colour === color) {
                this.colour = "purple";
            }
            else {
                this.colour = color;
            }
        });
    }
};
PanelJsComponent.ctorParameters = () => [
    { type: PanelJsService }
];
__decorate([
    HostListener('panstart', ['$event'])
], PanelJsComponent.prototype, "panstart", null);
__decorate([
    HostListener('panmove', ['$event'])
], PanelJsComponent.prototype, "panmove", null);
__decorate([
    HostListener('panend', ['$event'])
], PanelJsComponent.prototype, "panend", null);
PanelJsComponent = __decorate([
    Component({
        selector: 'panel-js',
        template: '<ng-content></ng-content>',
        host: {
            "[style.transform]": "'translate3d(0, '+pos+'px, 0)'",
            "[style.transition]": "transitionSpeed",
            "[style.backgroundColor]": "colour",
            "[style.display]": "'block'",
            "[style.willChange]": "'transform'"
        },
        styles: [":host{position:absolute;bottom:0;left:0;padding:0;margin:0;width:100%;height:100%;will-change:transform;z-index:1000;background:red;border-radius:25%}ng-content>*{width:100%!important;height:100%!important}"]
    })
], PanelJsComponent);

let PanelJsScrollComponent = class PanelJsScrollComponent {
    constructor(panelService, elementRef) {
        this.panelService = panelService;
        this.elementRef = elementRef;
    }
    onScroll(event) {
        console.log('scroll');
        // event.stopPropagation();
    }
    ngOnInit() {
        console.log("panel scroll init");
        // const scrollEvent$: Observable<Event> = fromEvent(this.elementRef.nativeElement, 'scroll');
        // this.panelService.setScrollListener(scrollEvent$);
        this.panelService.getScrollLock().subscribe(lock => {
            if (lock) {
                this.overflow = "scroll";
            }
            else {
                this.overflow = "hidden";
            }
            //this.overflow = "scroll";
        });
    }
};
PanelJsScrollComponent.ctorParameters = () => [
    { type: PanelJsService },
    { type: ElementRef }
];
__decorate([
    HostListener('pan', ['$event'])
], PanelJsScrollComponent.prototype, "onScroll", null);
PanelJsScrollComponent = __decorate([
    Component({
        selector: 'panel-js-scroll',
        template: '<ng-content></ng-content>',
        host: {
            "[style.overflowY]": "overflow",
            "[style.display]": "'block'",
        },
        styles: [""]
    })
], PanelJsScrollComponent);

var PanelJsModule_1;
let PanelHammerConfig = class PanelHammerConfig extends HammerGestureConfig {
    constructor() {
        super(...arguments);
        this.overrides = {
            'pan': { threshold: 0 }
        };
    }
};
PanelHammerConfig = __decorate([
    Injectable()
], PanelHammerConfig);
let PanelJsModule = PanelJsModule_1 = class PanelJsModule {
    constructor(injector) {
        this.injector = injector;
    }
    ngDoBootstrap() {
        const panel = createCustomElement(PanelJsComponent, { injector: this.injector });
        const panelScroll = createCustomElement(PanelJsScrollComponent, { injector: this.injector });
        customElements.define('panel-js', panel);
        customElements.define('panel-js-scroll', panelScroll);
    }
    static forRoot(config) {
        return ({
            ngModule: PanelJsModule_1,
            providers: [
                {
                    provide: LIB_CONFIG,
                    useValue: config
                }
            ]
        });
    }
};
PanelJsModule.ctorParameters = () => [
    { type: Injector }
];
PanelJsModule = PanelJsModule_1 = __decorate([
    NgModule({
        declarations: [PanelJsComponent, PanelJsScrollComponent],
        imports: [HammerModule],
        entryComponents: [PanelJsComponent, PanelJsScrollComponent],
        exports: [PanelJsComponent, PanelJsScrollComponent],
        providers: [{
                provide: HAMMER_GESTURE_CONFIG,
                useClass: PanelHammerConfig
            }]
    })
], PanelJsModule);

/*
 * Public API Surface of panel-js
 */

/**
 * Generated bundle index. Do not edit.
 */

export { LIB_CONFIG, PanelHammerConfig, PanelJsComponent, PanelJsModule, PanelJsScrollComponent, PanelJsService };
//# sourceMappingURL=ng-panel-js.js.map
