import { Plot } from "../Plot";
import { Point } from "../../Point";
import { Rectangle } from "../../Rectangle";

export const drawBarChart = function (this: Plot, ctx: CanvasRenderingContext2D, plotData: Point[], vp: Rectangle) {

    let stepWidth = vp.width;
    if (plotData.length>=2) { stepWidth = (plotData[1].x-plotData[0].x) }
    stepWidth = stepWidth - this._options.mainSize;

    for (let i = 0; i < plotData.length; i++) {
        ctx.beginPath();
        ctx.lineTo(plotData[i].x - stepWidth*0.5, vp.zeroY);
        ctx.lineTo(plotData[i].x - stepWidth*0.5, plotData[i].y);
        ctx.lineTo(plotData[i].x + stepWidth*0.5, plotData[i].y);
        ctx.lineTo(plotData[i].x + stepWidth*0.5, vp.zeroY);
        ctx.closePath();
        ctx.fill();
        ctx.beginPath();
        ctx.lineTo(plotData[i].x - stepWidth*0.5, plotData[i].y);
        ctx.lineTo(plotData[i].x + stepWidth*0.5, plotData[i].y);
        ctx.closePath();
        ctx.stroke();
    }

    // ctx.globalAlpha = this._options.opacity;
    
    //ctx.stroke();
}