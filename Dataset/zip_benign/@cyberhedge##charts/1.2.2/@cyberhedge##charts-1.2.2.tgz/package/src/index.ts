// browserify ./src/index.ts -p [ tsify --noImplicitAny ] > chart-bundle.js

export {Chart} from './classes/Chart';
export {Ticks} from './classes/ticks/Ticks';
export {Legend} from './classes/Legend';
export {Point} from './classes/Point';
export {Rectangle} from './classes/Rectangle';
export {Label} from './classes/Label';

import {Chart} from './classes/Chart';
import {Ticks} from './classes/ticks/Ticks';
import {Legend} from './classes/Legend';
import {Point} from './classes/Point';
import {Rectangle} from './classes/Rectangle';
import {Label} from './classes/Label';

//@ts-ignore
window['Chart'] = Chart;
//@ts-ignore
window['Ticks'] = Ticks;
//@ts-ignore
window['Point'] = Point;
//@ts-ignore
window['Legend'] = Legend;
//@ts-ignore
window['Rectangle'] = Rectangle;
//@ts-ignore
window['Label'] = Label;
