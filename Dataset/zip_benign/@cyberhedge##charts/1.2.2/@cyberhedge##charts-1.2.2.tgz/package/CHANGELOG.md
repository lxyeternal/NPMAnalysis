# Changelog

## [1.1.1]
### Added
- Plot type **text**: added auto fit rotation
- Plot type **text**: `setTextLineOptions` method - enables setting cursor line paddings, length and rotation angle

### Fixed
- Improved `chartCreate` performancy by reducing initial calculations.   
- Fixed label fontsize mediaquery option. Runs when reload.  

## [1.1.0] - 2021-01-12
### Added
- Plot: `setLineWidthMediaQueries` method - enables setting lineWidth depending on mediaQuery  

## [1.0.0]
### Changed
- Start following [SemVer](https://semver.org) properly.