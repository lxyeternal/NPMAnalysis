const _ = require('lodash');

function updateArray(array) {
    return _.sortedUniq(array);
}

module.exports = { updateArray };
