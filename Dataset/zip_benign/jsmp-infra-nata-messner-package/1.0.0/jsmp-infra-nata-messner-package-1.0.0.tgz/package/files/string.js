const _ = require('lodash');

function updateString(string) {
    return _.kebabCase(string);
}

module.exports = { updateString };
