const { updateArray }= require ('./files/array');
const { updateString } = require ('./files/string');

const sortedArray = [1, 1, 2, 3, 3, 3, 5, 8, 8];
let result = updateArray(sortedArray);

console.log(result);

let param = '__We__ARE__WaLkInG';
let result2 = updateString(param);

console.log(result2);
