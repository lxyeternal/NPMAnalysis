const assert = require('assert');
const { updateArray }= require ('../files/array');

const sortedArray = [1, 1, 2, 3, 3, 3, 5, 8, 8];
let result = updateArray(sortedArray);
console.log(result);

assert.ok(result);
assert.deepEqual(sortedArray, [1, 1, 2, 3, 3, 3, 5, 8, 8]);
assert.notDeepEqual(sortedArray, result);
