const assert = require('assert');
const { updateString } = require ('../files/string');

let str = '__We__ARE__WaLkInG';
let str2 = 'we-are-wa-lk-in-g';

let result2 = updateString(str);
console.log(result2);

assert( 'we-are-wa-lk-in-g' === result2 );
assert.equal(result2, str2);
assert.notEqual(str, str2);
