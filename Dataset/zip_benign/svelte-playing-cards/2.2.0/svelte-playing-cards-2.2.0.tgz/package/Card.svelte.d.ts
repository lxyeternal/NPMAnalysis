import { SvelteComponentTyped } from "svelte";
/**typescript type - all the 4 suits */
export declare type Suit = 'SPADES' | 'DIAMONDS' | 'HEARTS' | 'CLUBS';
/**typescript type - all the values a card can take except JOKER*/
export declare type ValueWithoutJoker = '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'JACK' | 'QUEEN' | 'KING' | 'ACE';
/**typescript type - all the values a card can take including JOKER*/
export declare type Value = ValueWithoutJoker | 'JOKER';
/**typescript type - all 54 value-of-suit a card can take*/
export declare type CardType = `${ValueWithoutJoker}-of-${Suit}` | 'BLACK-JOKER' | 'RED-JOKER';
import type { SvelteComponent } from 'svelte';
declare const __propDef: {
    props: {
        [x: string]: any;
        width?: string;
        height?: string;
        topPosition?: string;
        leftPosition?: string;
        position?: string;
        showBackSide?: boolean;
        card: CardType;
        customBack?: typeof SvelteComponent;
        customBackProps?: Record<string, unknown>;
        customFront?: typeof SvelteComponent;
        customFrontProps?: Record<string, unknown>;
        enableDrag?: boolean;
        shouldRotate?: boolean;
        onClick?: svelte.JSX.MouseEventHandler<HTMLDivElement>;
        onDblClick?: svelte.JSX.MouseEventHandler<HTMLDivElement>;
        getCard?: () => CardType;
        flip?: (allowTransition?: boolean, axis?: 'X' | 'Y', increment?: number, ms?: number) => Promise<void>;
        remove?: () => void;
        transitionToTarget?: (targetX: number, targetY: number, options?: {
            duration?: number;
            easing?: (x: any) => any;
            delay?: number;
        }) => Promise<SvelteAllProps>;
        showFront?: (allowTransition?: boolean, axis?: 'X' | 'Y', increment?: number, ms?: number) => Promise<void>;
        showBack?: (allowTransition?: boolean, axis?: 'X' | 'Y', increment?: number, ms?: number) => Promise<void>;
        drop?: (options?: {
            enableDrag: boolean;
            position: string;
            height: string;
            width: string;
            topPos: string;
            leftPos: string;
        }) => svelte.JSX.MouseEventHandler<HTMLElement>;
        getPosition?: () => [string, string];
        setPosition?: (pos: {
            top: string;
            left: string;
        }) => void;
        getSuppliedProps?: () => SvelteAllProps;
        shufflingTransition?: (axis?: 'X' | 'Y', offset?: number, increment?: number, ms?: number) => Promise<void>;
    };
    events: {
        [evt: string]: CustomEvent<any>;
    };
    slots: {};
};
export declare type CardProps = typeof __propDef.props;
export declare type CardEvents = typeof __propDef.events;
export declare type CardSlots = typeof __propDef.slots;
/**
 * Component to render a card
 * Import component by
 * ```svelte
 * import Card from "svelte-playing-cards"
 * ```
 * and use it in your code
 * ```svelte
 * <Card card="10-of-CLUBS" />
 * ```
 */
export default class Card extends SvelteComponentTyped<CardProps, CardEvents, CardSlots> {
    get getCard(): () => CardType;
    get flip(): (allowTransition?: boolean, axis?: "X" | "Y", increment?: number, ms?: number) => Promise<void>;
    get remove(): () => void;
    get transitionToTarget(): (targetX: number, targetY: number, options?: {
        duration?: number;
        easing?: (x: any) => any;
        delay?: number;
    }) => Promise<SvelteAllProps>;
    get showFront(): (allowTransition?: boolean, axis?: "X" | "Y", increment?: number, ms?: number) => Promise<void>;
    get showBack(): (allowTransition?: boolean, axis?: "X" | "Y", increment?: number, ms?: number) => Promise<void>;
    get drop(): (options?: {
        enableDrag: boolean;
        position: string;
        height: string;
        width: string;
        topPos: string;
        leftPos: string;
    }) => svelte.JSX.MouseEventHandler<HTMLElement>;
    get getPosition(): () => [string, string];
    get setPosition(): (pos: {
        top: string;
        left: string;
    }) => void;
    get getSuppliedProps(): () => SvelteAllProps;
    get shufflingTransition(): (axis?: "X" | "Y", offset?: number, increment?: number, ms?: number) => Promise<void>;
}
export {};
