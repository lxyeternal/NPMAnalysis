import { SvelteComponentTyped } from "svelte";
/**
 * generates deck of card
 * @param param0.withBlackJoker include black joker
 * @param param0.withRedJoker include red joker
 * @param param0.shouldShuffle shuffle the deck
 */
export declare const generateFullDeckFun: ({ withBlackJoker, withRedJoker, shouldShuffle }?: {
    withBlackJoker?: boolean;
    withRedJoker?: boolean;
    shouldShuffle?: boolean;
}) => CardType[];
/**
 * shuffle the deck.
 *
 * @param deck - deck of cards to shuffle
 */
export declare const shuffleFun: (deck: CardType[]) => void;
import type { SvelteComponent } from 'svelte';
import type { CardType } from './Card.svelte';
import Card from './Card.svelte';
declare const __propDef: {
    props: {
        /**
             * list of cards to render (pushes all 52 cards without jokers if nothing or empty array is supplied).
             * without shuffling the last value in deck is rendered on top
             */ deck?: CardType[];
        /**shuffle the supplied deck*/ shouldShuffle?: boolean;
        /**width of single card @default 200px*/ cardWidth?: string;
        /**height of single card @default 250px*/ cardHeight?: string;
        /**list of cards which should have custom front along with custom component and its props*/ cardCustomFronts?: [CardType, typeof SvelteComponent, Record<string, unknown>][];
        /**custom component for back of cards*/ cardCustomBackComp?: typeof SvelteComponent;
        /**props for custom back component*/ cardCustomBackCompProps?: Record<string, unknown>;
        /**distance from top @default 0px*/ topPosition?: string;
        /**distance from left @default 0px*/ leftPosition?: string;
        /**offset from leftPosition (helps in giving 3d look to deck) @default 0.5*/ leftPositionOffset?: number;
        /**offset from topPosition (helps in giving 3d look to deck) @default 0.1*/ topPositionOffset?: number;
        /**list of cards showing front*/ frontShowingCards?: CardType[];
        /**
             * on:click handler (default to drawTopCard)
             * @param event onClick event
             */ onClick?: svelte.JSX.MouseEventHandler<HTMLElement>;
        /**
             * on:dblclick handler (default to shuffle)
             * @param event onDblClick event
             */ onDblClick?: svelte.JSX.MouseEventHandler<HTMLElement>;
        /**
             * Makes the deck ready to call methods upon. Only need to call this method if you want to call any method
             * immediately on component initilization i.e. without waiting for any event to occur.
             *
             * @param waitTime time to wait before ready. @default 10ms
             * @example
             * ```js
             * //...
             * let deckComp;
             * let cardProps;
             * //...
             *
             * const execMethod = async()=>{
             * 	await deckComp.gettingReady();
             * 	// use any method on deckComp
             * }
             * $: if(deckComp){
             * 	    execMethod()
             * 	  }
             * ```
             */ gettingReady?: (waitTime?: number) => Promise<void>;
        /** get the deck
             * @returns deck
             */ getDeck?: () => CardType[];
        /**
             * get top card
             * @param targetX x-coordinate of target to transition to
             * (to avoid transition either provide null or nothing)
             * @param targetY y-coordinate of target to transition to
             * (to avoid transition either provide null or nothing)
             * @param options  options to control transition
             * @param options.duration milliseconds to complete transition
             * @param options.easing easing function
             * @param options.delay milliseconds after which transition starts
             * @param removeFromDom remove card from dom (if true index 1 of return array will be useless)
             * supplying targetX and targetY automatically removes old instance of card
             *
             * @returns promise that resolves to [card face (value-of-suit), the card component, props passed to card component] or null if deck is empty
             * @example
             * ```js
             * //...
             * let deckComp
             * let cardProps;
             * //...
             * ```
             * ```svelte
             * <Deck bind:this={deckComp}/>
             * <div on:click={async(e)=>{
             *  const { x, y } = e.currentTarget.getBoundingClientRect();
             *  const cards = await deckComp.drawTopCard(x,y)
             *  cardProps = cards[2]
             * }}>
             * {#if cardProps}
             *	<svelte:component this={Card} {...cardProps} />
             *	{/if}
             * </div>
             * ```
             */ drawTopCard?: (targetX?: number, targetY?: number, options?: {
            duration?: number;
            easing?: (x: any) => any;
            delay?: number;
        }, removeFromDom?: boolean) => Promise<[CardType, Card, SvelteAllProps] | null>;
        /**
             * get top n cards
             *
             * @param numOfCards number of cards to draw
             * @param targetX x-coordinate of target to transition to
             * (to avoid transition either provide null or nothing)
             * @param targetY y-coordinate of target to transition to
             * (to avoid transition either provide null or nothing)
             * @param options  options to control transition
             * @param options.duration milliseconds to complete transition
             * @param options.easing easing function
             * @param options.delay milliseconds after which transition starts
             *
             * @returns promise that resolves to [list of  card face (value-of-suit), list of card components,list of props passed to card components]
             * or null if deck is empty
             * @example
             * ```js
             * //...
             * let deckComp
             * let cardsProps = [];
             * //...
             * ```
             * ```svelte
             * <Deck bind:this={deckComp}/>
             * <div on:click={async(e)=>{
             *  const { x, y } = e.currentTarget.getBoundingClientRect();
             *  const cards = await deckComp.drawCards(5,x,y)
             *  cardsProps = cardsProps.concat(cards[2])
             * }}>
             * {#each cardsProps as cardProps }
             *  <svelte:component this={Card} {...cardProps} />
             * {/each}
             * </div>
             * ```
             */ drawCards?: (numOfCards: number, targetX?: number, targetY?: number, options?: {
            duration?: number;
            easing?: (x: any) => any;
            delay?: number;
        }) => Promise<[CardType[], Card[], SvelteAllProps[]] | null>;
        /**
             * shuffle the deck.
             *
             * if transition is allowed then time for one cycle = ((2 * offset) / increment) * ms
             * total time for transition = cycles * time for one cycle
             *
             * @param allowTransition allow shuffling transition
             * @param axis axis of shuffling
             * @param offset how far card goes before coming back
             * @param increment increment per ms milliseconds
             * @param ms  number of milliseconds to next point in transition
             * @param cycles total cycles
             */ shuffleWithTransition?: (allowTransition?: boolean, axis?: 'X' | 'Y', offset?: number, increment?: number, ms?: number, cycles?: number) => Promise<void>;
        /**
             * show front of a card
             * @param indexOfCard index of card in deck
             */ showCardFront?: (indexOfCard: number) => Promise<void>;
        /**
             * show back of a card
             * @param indexOfCard index of card in deck
             */ hideCardFront?: (indexOfCard: number) => Promise<void>;
        /**
             * flip a card
             * @param indexOfCard index of card in deck
             */ flipCard?: (indexOfCard: number) => Promise<void>;
        /**show front of top card*/ showTopCardFront?: () => Promise<void>;
        /**show back of top card*/ hideTopCardFront?: () => Promise<void>;
        /**flip top card*/ flipTopCard?: () => Promise<void>;
        /**
             * function to call on on:drop event of element where card could be drag and drop to
             * @param cardToDrop the card component to drop
             * @param options  options to change card after drop
             *
             * @returns a function which accepts drag event
             *
             * @example
             * ```svelte
             * <div on:drop={deckComp.drop(card)}  on:dragenter={(e) => e.preventDefault()}
             * on:dragover={(e) => e.preventDefault()}></div>
             * ```
             * where deckComp is instance of Deck. Notice you have to call the function as
             * it returns another function which accepts the event
             *
             */ drop?: (cardToDrop: Card, options?: {
            enableDrag: boolean;
            position: string;
            height: string;
            width: string;
            topPos: string;
            leftPos: string;
        }) => svelte.JSX.MouseEventHandler<HTMLElement>;
    };
    events: {
        [evt: string]: CustomEvent<any>;
    };
    slots: {};
};
export declare type DeckProps = typeof __propDef.props;
export declare type DeckEvents = typeof __propDef.events;
export declare type DeckSlots = typeof __propDef.slots;
/**
 * A component to generate deck of cards
 * Import component by
 * ```svelte
 * import Deck from "svelte-playing-cards"
 * ```
 * and use it in your code
 * ```svelte
 * <Deck />
 * ```
 * by default it renders all 52 cards (without jokers)
 * To specify cards pass it in as a list to deck prop
 *
 * ```svelte
 * <Deck deck={["10-of-CLUBS","QUEEN-of-HEARTS","BLACK-JOKER"]} />
 * ```
 */
export default class Deck extends SvelteComponentTyped<DeckProps, DeckEvents, DeckSlots> {
    get gettingReady(): (waitTime?: number) => Promise<void>;
    get getDeck(): () => CardType[];
    get drawTopCard(): (targetX?: number, targetY?: number, options?: {
        duration?: number;
        easing?: (x: any) => any;
        delay?: number;
    }, removeFromDom?: boolean) => Promise<[CardType, Card, SvelteAllProps]>;
    get drawCards(): (numOfCards: number, targetX?: number, targetY?: number, options?: {
        duration?: number;
        easing?: (x: any) => any;
        delay?: number;
    }) => Promise<[CardType[], Card[], SvelteAllProps[]]>;
    get shuffleWithTransition(): (allowTransition?: boolean, axis?: "X" | "Y", offset?: number, increment?: number, ms?: number, cycles?: number) => Promise<void>;
    get showCardFront(): (indexOfCard: number) => Promise<void>;
    get hideCardFront(): (indexOfCard: number) => Promise<void>;
    get flipCard(): (indexOfCard: number) => Promise<void>;
    get showTopCardFront(): () => Promise<void>;
    get hideTopCardFront(): () => Promise<void>;
    get flipTopCard(): () => Promise<void>;
    get drop(): (cardToDrop: Card, options?: {
        enableDrag: boolean;
        position: string;
        height: string;
        width: string;
        topPos: string;
        leftPos: string;
    }) => svelte.JSX.MouseEventHandler<HTMLElement>;
}
export {};
