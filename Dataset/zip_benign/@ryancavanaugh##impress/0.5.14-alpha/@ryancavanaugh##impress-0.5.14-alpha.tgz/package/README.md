# Installation
> `npm install --save-dev @ryancavanaugh/impress`

# Summary
This package contains type definitions for Impress.js 0.5.

The project URL or description is https://github.com/bartaz/impress.js

# Credits

These definitions were written by Boris Yankov <https://github.com/borisyankov/>.

# Details
Typings were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped in the impress directory.

Additional Details
 * Last updated: Tue, 17 May 2016 00:18:19 GMT
 * Typings kind: Global
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: impress
