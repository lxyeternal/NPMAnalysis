# Simple customizable rating component

## Download
`npm install @simuratli/rating`

## Tutiorial
After download package import it like:

`import { Rating } from '@simuratli/rating'`


Simple usage of Rating component like that:

`<Rating rate={2} precision={0.5} />`

Rating component with custom svg:

`<Rating
        filledIcon={FilledHearth}
        emptyIcon={Hearth}
        rate={2}
        precision={0.5}
/>`


- rate: number(show current rate)
- precision: number(must be smaller or equal than 1, It used for we want to dvide 1 icon how many parts)
    


[Example website](https://codesandbox.io/s/simuratli-rating-u7v5wv?file=/src/App.js)


