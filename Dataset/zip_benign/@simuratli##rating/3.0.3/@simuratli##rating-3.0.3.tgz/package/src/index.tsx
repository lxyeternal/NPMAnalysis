import React, { useState, useRef } from 'react';

const FilledStar = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="#FFD983" stroke="black" strokeLinecap="round" strokeLinejoin="round"/>
</svg>

const Star = () => <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" stroke="black" strokeLinecap="round" strokeLinejoin="round"/>
</svg>


export const Rating = ({
  precision = 1,
  rate=2.5,
  emptyIcon = Star,
  filledIcon = FilledStar,
}) => {
  const [activeStar, setActiveStar] = useState(rate);
  const [arrayForStars] = useState([0,1,2,3,4]);
  const [hoverActiveStar, setHoverActiveStar] = useState(-1);
  const [isHovered, setIsHovered] = useState(false);
  const ratingContainerRef = useRef<HTMLDivElement | null>(null);

  const calculateRating = (e:React.MouseEvent) => {
    const position = ratingContainerRef?.current?.getBoundingClientRect();
    if(!position) return -1
    let percent = (e.clientX - position.left) / position.width;
    const numberInStars = percent * 5;
    const nearestNumber = Math.round((numberInStars + precision / 2) / precision) * precision;

    return Number(nearestNumber.toFixed(precision.toString().split('.')[1]?.length || 0));
  };

  const handleClick = (e:React.MouseEvent) => {
    setIsHovered(false);
    setActiveStar(calculateRating(e));
  };

  const handleMouseMove = (e:React.MouseEvent) => {
    setIsHovered(true);
    setHoverActiveStar(calculateRating(e));
  };

  

  const handleMouseLeave = () => {
    setHoverActiveStar(-1); // Reset to default state
    setIsHovered(false);
  };
  const EmptyIcon = emptyIcon;
  const FilledIcon = filledIcon;



  return (
    <div
      style={{
        display: 'inline-flex',
        position: 'relative',
        cursor: 'pointer',
        textAlign: 'left',
      }}
      onClick={handleClick}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      ref={ratingContainerRef}
    >
      {arrayForStars.map((index) => {
        const activeState = isHovered ? hoverActiveStar : activeStar;

        const showEmptyIcon = activeState === -1 || activeState < index + 1;

        const isActiveRating = activeState !== 1;
        const isRatingWithPrecision = activeState % 1 !== 0;
        const isRatingEqualToIndex = Math.ceil(activeState) === index + 1;
        const showRatingWithPrecision =
          isActiveRating && isRatingWithPrecision && isRatingEqualToIndex;

        return (
          <div
            style={{
              cursor: 'pointer',
              position:"relative"
            }}
            key={index}
          >
            <div
              style={{
                width: showRatingWithPrecision ? `${(activeState % 1) * 100}%` : '0%',
                overflow: 'hidden',
                position: 'absolute'
              }}
            >
              <FilledIcon/>
            </div>
            <div
              style={{
                color: showEmptyIcon ? 'gray' : 'inherit'
              }}
            >
              {showEmptyIcon ? <EmptyIcon /> : <FilledIcon/>}
            </div>
          </div>
        );
      })}
    </div>
  );
};
