[![Build Status](https://travis-ci.org/orfeo-lang/orfeo.svg?branch=master)](https://travis-ci.org/orfeo-lang/orfeo)
[![Coverage Status](https://coveralls.io/repos/github/orfeo-lang/orfeo/badge.svg?branch=master)](https://coveralls.io/github/orfeo-lang/orfeo?branch=master)
[![JavaScript Style Guide](https://img.shields.io/badge/code_style-standard-brightgreen.svg)](https://standardjs.com)

```
    (𝄚𝄚𝄚𝄚)                 (𝄚𝄚𝄚)
  (𝄚𝄚)    (𝄚𝄚)           (𝄚)
(𝄚𝄚)        (𝄚𝄚)(𝄚) (𝄚𝄚𝄚)(𝄚)(𝄚)(𝄚) (𝄚𝄚)       (𝄚𝄚𝄚)
(𝄚𝄚)        (𝄚𝄚) (𝄚𝄚)     (𝄚𝄚)    (𝄚)  (𝄚𝄚) (𝄚𝄚)   (𝄚𝄚)
(𝄚𝄚)        (𝄚𝄚) (𝄚𝄚)     (𝄚𝄚)  (𝄚𝄚𝄚𝄚) (𝄚) (𝄚𝄚)     (𝄚𝄚)
  (𝄚𝄚)     (𝄚𝄚)  (𝄚𝄚)     (𝄚𝄚)  (𝄚)          (𝄚𝄚)   (𝄚𝄚)
    (𝄚𝄚𝄚𝄚)     (𝄚𝄚𝄚)     (𝄚𝄚)    (𝄚𝄚𝄚𝄚)        (𝄚𝄚𝄚)
```

# Orfeo

The reference compiler for the Orfeo programming language.

It compiles an Orfeo program to the Timeline file format.

http://orfeo.org

## Installation

`npm install @orfeo/orfeo`

## Usage

```js
const compile = require('@orfeo/orfeo')
const program = '(a b c d)'
const timelineFile = compile(program)
// timelineFile ->
0 a
0.25 b
0.5 c
0.75 d
1
```

## Tests

Command                        | Description
------------------------------ | ------------
`npm test` or `npm run test`   | unit tests + coverage + standardx linting
`npm run cover`                | unit tests + coverage
`npm run standardx`            | standardx linting
`npm run units_with_standardx` | unit tests + standardx linting
`npm run units`                | unit tests
`npm run units_v`              | unit tests : verbose
`npm run unit_lexer`           | unit tests - lexer
`npm run unit_lexer_v`         | unit tests - lexer : verbose
`npm run unit_number`          | unit tests - number
`npm run unit_number_v`        | unit tests - number : verbose
`npm run unit_parser`          | unit tests - parser
`npm run unit_parser_v`        | unit tests - parser : verbose
`npm run unit_sanitizer`       | unit tests - sanitizer
`npm run unit_sanitizer_v`     | unit tests - sanitizer : verbose
`npm run unit_utilities`       | unit tests - utilities
`npm run unit_utilities_v`     | unit tests - utilities : verbose
`npm run unit_validators`      | unit tests - validators
`npm run unit_validators_v`    | unit tests - validators : verbose

## Copyright

Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque

## License

MIT
