/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

exports.capitalizeFirstLetter =
  str => str.charAt(0).toUpperCase() + str.slice(1)

exports.doesStringifiedNumHaveLeadingZero =
  strNum =>
    strNum.length > 1 &&
    strNum.charAt(0) === '0' &&
    strNum.charAt(1) !== '.'

exports.throwError = (
  status, msg = null, lineNum = null, linePos = null
) => {
  const location = lineNum !== null && linePos !== null
    ? 'At ' + lineNum + ':' + linePos
    : ''
  const error = msg !== null
    ? status + '\n' + msg
    : status
  throw new Error(location + '\n' + error)
}

exports.findIndexOfNthOccurrenceOfTokenType = (
  tokens, nthOccurrence, type, depth = null
) => {
  let count = 0
  let index = null
  for (let i = 0, len = tokens.length; i < len; i++) {
    if (
      tokens[i].type === type &&
      (depth === null || tokens[i].depth === depth)
    ) {
      count++
      if (count === nthOccurrence) {
        index = i
        break
      }
    }
  }
  return index
}

module.exports = exports
