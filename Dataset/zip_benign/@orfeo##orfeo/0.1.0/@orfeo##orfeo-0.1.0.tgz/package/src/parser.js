/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

const {
  doesStringifiedNumHaveLeadingZero,
  throwError,
  findIndexOfNthOccurrenceOfTokenType,
} = require('../src/utilities')
const { is } = require('../src/validators')
let deepestDepth

function renderDurationTokens (tokens) {
  tokens.forEach(token => {
    if (token.type === 'DURATION') {
      if (is(token.value, 'DURATION_NUMBER')) {
        const strNum = token.value.substr(1)
        if (doesStringifiedNumHaveLeadingZero(strNum)) {
          throwError(
            'Illegal Leading Zero: ' + token.value,
            'A duration number cannot have a leading zero.',
            token.lineNum,
            token.linePos
          )
        }
        const number = parseFloat(strNum)
        if (number < 0) {
          throwError(
            'Illegal Negative Number: ' + token.value,
            'A duration number cannot be negative.',
            token.lineNum,
            token.linePos
          )
        }
        token.value = number
      } else if (is(token.value, 'DURATION_TIMESIGNATURE')) {
        const parts = token.value.substr(1).split('/')
        let nominator = parts[0]
        let denominator = parts[1]
        if (doesStringifiedNumHaveLeadingZero(nominator)) {
          throwError(
            'Illegal Leading Zero: ' + token.value,
            'A duration timesignature nominator cannot have a leading zero.',
            token.lineNum,
            token.linePos
          )
        }
        if (doesStringifiedNumHaveLeadingZero(denominator)) {
          throwError(
            'Illegal Leading Zero: ' + token.value,
            'A duration timesignature denominator cannot have a leading zero.',
            token.lineNum,
            token.linePos
          )
        }
        nominator = parseFloat(nominator)
        denominator = parseFloat(denominator)
        if (nominator < 0) {
          throwError(
            'Illegal Negative Number: ' + token.value,
            'A duration timesignature nominator cannot be negative.',
            token.lineNum,
            token.linePos
          )
        }
        if (denominator < 0) {
          throwError(
            'Illegal Negative Number: ' + token.value,
            'A duration timesignature denominator cannot be negative.',
            token.lineNum,
            token.linePos
          )
        }
        if (denominator === 0) {
          throwError(
            'Illegal Divide By Zero: ' + token.value,
            'A duration timesignature denominator cannot be equal to zero.',
            token.lineNum,
            token.linePos
          )
        }
        token.value = (4 / denominator) * nominator
      }
    }
  })
}

function setDurationPropOnTupletExprOpenTokens (tokens) {
  tokens.forEach((token, i) => {
    if (token.type === 'TUPLET_EXPR_OPEN') {
      const nextToken = tokens[i + 1]
      if (nextToken.type === 'DURATION') {
        if (is(nextToken.value, 'DURATION_EQUALS')) {
          token.duration = 'EQUALS'
        } else {
          token.duration = nextToken.value
        }
      } else { // default
        token.duration = 1
      }
    }
  })
}

const calcFlaggedDuration = (duration, numFlags) =>
  duration / Math.pow(2, numFlags)

const calcDottedDuration = (duration, numDots) =>
  (2 * duration) - (duration / Math.pow(2, numDots))

function setDurationPropOnDatumTokens (tokens) {
  tokens.forEach((token, i) => {
    if (token.type === 'DATUM') {
      token.duration = 1
      const prevToken = tokens[i - 1]
      const nextToken = tokens[i + 1]
      if (prevToken.type === 'RHYTHM_FLAGS') {
        const numDatumFlags = prevToken.value.length
        token.duration = calcFlaggedDuration(
          token.duration, numDatumFlags
        )
      }
      if (nextToken.type === 'RHYTHM_DOTS') {
        const numDatumDots = nextToken.value.length
        token.duration = calcDottedDuration(
          token.duration, numDatumDots
        )
      }
    }
  })
}

function setDeepestDepth (tokens) {
  deepestDepth = 0
  tokens.forEach(token => {
    if (token.depth > deepestDepth) {
      deepestDepth = token.depth
    }
  })
}

// Sets and calculates duration related props for TUPLET_EXPR_OPEN.
// 1. Sets sumOfChildDurations.
// 2. Does RHYTHM_FLAGS and RHYTHM_DOTS calculations for duration.
function setDurationRelatedPropsOnTupletExprOpenTokens (tokens) {
  let areSummingChildDurations = false
  let sumOfChildDurations
  let indexOfParent
  let numExprFlags
  for (let i = deepestDepth; i >= 0; i--) {
    tokens.forEach((token, j) => {
      if (
        areSummingChildDurations &&
        (
          (token.type === 'DATUM' && token.depth === i) ||
          (token.type === 'TUPLET_EXPR_OPEN' && token.depth === i + 1)
        )
      ) {
        sumOfChildDurations += token.duration
      } else if (token.depth === i) {
        if (token.type === 'TUPLET_EXPR_OPEN') {
          areSummingChildDurations = true
          sumOfChildDurations = 0
          indexOfParent = j
          numExprFlags =
            (
              j > 0 &&
              tokens[j - 1].type === 'RHYTHM_FLAGS'
            )
              ? tokens[j - 1].value.length
              : 0
        } else if (token.type === 'TUPLET_EXPR_CLOSE') {
          areSummingChildDurations = false
          const k = indexOfParent
          tokens[k].sumOfChildDurations = sumOfChildDurations
          if (tokens[k].duration === 'EQUALS') {
            tokens[k].duration = sumOfChildDurations
          }
          const numExprDots =
            (
              j < tokens.length - 1 &&
              tokens[j + 1].type === 'RHYTHM_DOTS'
            )
              ? tokens[j + 1].value.length
              : 0
          tokens[k].duration = calcFlaggedDuration(
            tokens[k].duration, numExprFlags
          )
          tokens[k].duration = calcDottedDuration(
            tokens[k].duration, numExprDots
          )
        }
      }
    })
  }
}

function setinZeroDurationExprPropOnTupletExprOpenTokens (tokens) {
  let depthOfZeroDurationExpr = -1
  tokens.forEach(token => {
    if (token.type === 'TUPLET_EXPR_OPEN') {
      if (
        token.duration === 0 &&
        depthOfZeroDurationExpr === -1
      ) {
        depthOfZeroDurationExpr = token.depth
      }
      token.inZeroDurationExpr = depthOfZeroDurationExpr !== -1
    } else if (
      token.type === 'TUPLET_EXPR_CLOSE' &&
      token.depth === depthOfZeroDurationExpr
    ) {
      depthOfZeroDurationExpr = -1
    }
  })
}

function setTimePropOnDatumTokens (tokens) {
  for (let i = 1; i <= deepestDepth; i++) {
    let sumOfPreviouslySetDatumTokens
    let indexOfParent
    tokens.forEach((token, j) => {
      if (token.depth === i) {
        if (token.type === 'TUPLET_EXPR_OPEN') {
          sumOfPreviouslySetDatumTokens = 0
          indexOfParent = j
          if (
            token.type === 'TUPLET_EXPR_OPEN' &&
            token.depth === 1
          ) {
            token.time = 0
            token.unitDuration = token.duration / token.sumOfChildDurations
          }
        } else if (token.type === 'DATUM') {
          if (tokens[indexOfParent].inZeroDurationExpr === false) {
            token.time = tokens[indexOfParent].time +
              (sumOfPreviouslySetDatumTokens * tokens[indexOfParent].unitDuration)
          }
          sumOfPreviouslySetDatumTokens += token.duration
        }
      } else if (
        token.type === 'TUPLET_EXPR_OPEN' &&
        token.depth === i + 1
      ) {
        token.time = tokens[indexOfParent].time +
          (sumOfPreviouslySetDatumTokens * tokens[indexOfParent].unitDuration)
        token.unitDuration = tokens[indexOfParent].unitDuration *
          (token.duration / token.sumOfChildDurations)
        sumOfPreviouslySetDatumTokens += token.duration
      }
    })
  }
}

function setEventsTail (tokens, events) {
  const i = findIndexOfNthOccurrenceOfTokenType(
    tokens, 1, 'TUPLET_EXPR_OPEN'
  )
  events.push({ time: tokens[i].duration })
}

function renderEvents (tokens) {
  const events = []
  tokens.forEach(token => {
    if (
      token.type === 'DATUM' &&
      Object.prototype.hasOwnProperty.call(token, 'time')
    ) {
      events.push({
        time: token.time,
        datum: token.value,
      })
    }
  })
  if (events.length > 0) {
    setEventsTail(tokens, events)
  }
  return events
}

function translateEventsToTimepointFileFormat (events) {
  let file = ''
  events.forEach(e => {
    file += e.time
    if (
      Object.prototype.hasOwnProperty.call(e, 'datum') &&
      e.datum.length > 0
    ) {
      // Add double quotes when e.datum is padded with whitespaces
      // to keep these whitespaces as an integral part of the datum.
      // I.e "  datum  "
      if (e.datum.trim().length < e.datum.length) {
        e.datum = '"' + e.datum + '"'
      }
      file += ' ' + e.datum
    }
    file += '\n'
  })
  return file
}

function parse (tokens) {
  renderDurationTokens(tokens)
  setDurationPropOnTupletExprOpenTokens(tokens)
  setDurationPropOnDatumTokens(tokens)
  setDeepestDepth(tokens)
  setDurationRelatedPropsOnTupletExprOpenTokens(tokens)
  setinZeroDurationExprPropOnTupletExprOpenTokens(tokens)
  setTimePropOnDatumTokens(tokens)
  return translateEventsToTimepointFileFormat(renderEvents(tokens))
}

module.exports = tokens => parse(tokens)
