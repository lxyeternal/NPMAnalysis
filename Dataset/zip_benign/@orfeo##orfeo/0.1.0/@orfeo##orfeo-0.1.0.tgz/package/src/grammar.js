/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

const number = '-?(\\.[0-9]+|[0-9]+\\.?[0-9]*)'

module.exports = {
  regex: {
    TUPLET_EXPR_OPEN:       /\(/,
    TUPLET_EXPR_CLOSE:      /\)/,
    DURATION:               /:[=0-9/.-]*/,
    DURATION_EQUALS:        /:=/,
    DURATION_NUMBER:        new RegExp(':' + number),
    DURATION_TIMESIGNATURE: new RegExp(':' + number + '/' + number),
    // DATUM_LOOSE is used in src/lexer.js/captureDatumAndRhythmDots()
    // to capture either a DATUM or RHYTHM_DOTS since periods can be
    // used in both these tokens.
    DATUM_LOOSE:            /[._a-zA-Z0-9/[\]♮♭♯-]+/,
    DATUM:                  /(\.*[_a-zA-Z0-9/[\]♮♭♯-]+)+/,
    STRING_DELIM:           /"/,
    RHYTHM_FLAGS:           /\^+/,
    RHYTHM_DOTS:            /\.+/,
    NUMBER:                 new RegExp(number),
    NONWHITESPACE:          /\S*/,
    NEWLINE:                /\r?\n/,
  },
  unallowedFollowers: {
    TUPLET_EXPR_OPEN: [
      'RHYTHM_DOTS',
    ],
    TUPLET_EXPR_CLOSE: [
      'DURATION',
    ],
    DURATION: [
      'DURATION',
      'RHYTHM_DOTS',
    ],
    DATUM: [
      'DURATION',
    ],
    RHYTHM_FLAGS: [
      'TUPLET_EXPR_CLOSE',
      'DURATION',
      'RHYTHM_FLAGS',
      'RHYTHM_DOTS',
    ],
    RHYTHM_DOTS: [
      'DURATION',
      'RHYTHM_DOTS',
    ],
  },
  whitespace: {
    requiredBeforeFollowers: {
      TUPLET_EXPR_CLOSE: [
        'TUPLET_EXPR_OPEN',
        'DATUM',
        'RHYTHM_FLAGS',
      ],
      DURATION: [
        'TUPLET_EXPR_OPEN',
        'DATUM',
        'RHYTHM_FLAGS',
      ],
      DATUM: [
        'TUPLET_EXPR_OPEN',
        'DATUM',
        'RHYTHM_FLAGS',
      ],
      RHYTHM_DOTS: [
        'TUPLET_EXPR_OPEN',
        'DATUM',
        'RHYTHM_FLAGS',
      ],
    },
    unallowedBeforeFollowers: {
      TUPLET_EXPR_CLOSE: [
        'RHYTHM_DOTS',
      ],
      DATUM: [
        'RHYTHM_DOTS',
      ],
      RHYTHM_FLAGS: [
        'TUPLET_EXPR_OPEN',
        'DATUM',
      ],
    },
  },
  phrased: {
    TUPLET_EXPR_OPEN:  'a tuplet expression opening parenthesis',
    TUPLET_EXPR_CLOSE: 'a tuplet expression closing parenthesis',
    DURATION:          'a duration',
    DATUM:             'a datum',
    RHYTHM_FLAGS:      'rhythm flags',
    RHYTHM_DOTS:       'rhythm dots',
  },
}
