/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

const grammar = require('../src/grammar')

const isString = val => typeof val === 'string'

const doesEntireStringMatchRegex = (str, regex) => {
  if (!isString(str)) return false
  regex = new RegExp(regex, 'g')
  const matches = str.match(regex)
  return matches === null
    ? false
    : matches.includes(str)
}

// Checks if a string is of a given Orfeo type.
const is = (str, type) =>
  doesEntireStringMatchRegex(str, grammar.regex[type])

exports.isString = isString
exports.doesEntireStringMatchRegex = doesEntireStringMatchRegex
exports.is = is
module.exports = exports
