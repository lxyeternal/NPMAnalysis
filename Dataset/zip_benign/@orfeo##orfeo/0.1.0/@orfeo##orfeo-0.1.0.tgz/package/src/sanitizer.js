/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

const grammar = require('../src/grammar')
const {
  capitalizeFirstLetter,
  throwError,
  findIndexOfNthOccurrenceOfTokenType,
} = require('../src/utilities')
const { is } = require('../src/validators')

function assignDepthsToTokens (tokens) {
  let depth = 0
  tokens.forEach((token, i) => {
    if (token.type === 'TUPLET_EXPR_OPEN') {
      depth++
      token.depth = depth
    } else if (token.type === 'TUPLET_EXPR_CLOSE') {
      token.depth = depth
      depth--
    } else {
      token.depth = depth
    }
  })
}

function checkForAMissingTopLevelTupletExpr (tokens) {
  if (
    tokens.length > 0 &&
    !(
      tokens[0].type === 'TUPLET_EXPR_OPEN' ||
      (
        tokens.length > 1 &&
        tokens[0].type === 'RHYTHM_FLAGS' &&
        tokens[1].type === 'TUPLET_EXPR_OPEN'
      )
    )
  ) {
    throwError(
      'Missing Top Level Tuplet Expression!',
      'Non empty files must contain a top level tuplet expression.'
    )
  }
}

function checkForMoreThanOneTopLevelTupletExpr (tokens) {
  const index = findIndexOfNthOccurrenceOfTokenType(
    tokens, 2, 'TUPLET_EXPR_OPEN', 1
  )
  if (index !== null) {
    throwError(
      'Unexpected Token: (',
      'There can only be one top level tuplet expression.',
      tokens[index].lineNum,
      tokens[index].linePos
    )
  }
}

function checkForAnUneccessaryTupletExprClose (tokens) {
  tokens.forEach(token => {
    if (
      token.type === 'TUPLET_EXPR_CLOSE' &&
      token.depth === 0
    ) {
      throwError(
        'Unexpected Token: )',
        'There is no opened tuplet expression that needs to be closed.',
        token.lineNum,
        token.linePos
      )
    }
  })
}

function checkForAnUnclosedTupletExpr (tokens) {
  if (tokens.length === 0) return
  let depthAtFileEnd = tokens[tokens.length - 1].depth
  // Remove -1 to depthAtFileEnd if the last token is a TUPLET_EXPR_CLOSE
  // since lowering depth only manifests in the following token.
  if (tokens[tokens.length - 1].type === 'TUPLET_EXPR_CLOSE') {
    depthAtFileEnd -= 1
  }
  if (depthAtFileEnd > 0) {
    for (let i = tokens.length - 1; i >= 0; i--) {
      const token = tokens[i]
      if (
        token.type === 'TUPLET_EXPR_OPEN' &&
        token.depth === depthAtFileEnd
      ) {
        throwError(
          'Unexpected End Of File!',
          'The tuplet expression opened at ' +
            token.lineNum + ':' + token.linePos + ' was not closed.'
        )
      }
    }
  }
}

function validateTupletExprParentheses (tokens) {
  checkForAMissingTopLevelTupletExpr(tokens)
  checkForMoreThanOneTopLevelTupletExpr(tokens)
  checkForAnUneccessaryTupletExprClose(tokens)
  checkForAnUnclosedTupletExpr(tokens)
}

function validateDurations (tokens) {
  tokens.forEach(token => {
    if (
      token.type === 'DURATION' &&
      !(
        is(token.value, 'DURATION_EQUALS') ||
        is(token.value, 'DURATION_NUMBER') ||
        is(token.value, 'DURATION_TIMESIGNATURE')
      )
    ) {
      if (token.value.length === 1) {
        throwError(
          'Empty Duration!',
          'You must write a legal duration after the <:> sign.' + '\n' +
            'It must be an equals sign, a number, or a time signature.',
          token.lineNum,
          token.linePos
        )
      } else {
        throwError(
          'Malformed Duration: ' + token.value,
          'A duration must be an equals sign, a number, or a time signature.',
          token.lineNum,
          token.linePos
        )
      }
    }
  })
}

function renameStringToDatum (tokens) {
  tokens.forEach(token => {
    if (token.type === 'STRING') {
      token.type = 'DATUM'
    }
  })
}

function validateTokenOrder (tokens) {
  for (let i = 0, len = tokens.length - 1; i < len; i++) {
    const token = tokens[i]
    const followingToken = tokens[i + 1]
    if (grammar.unallowedFollowers[token.type].includes(followingToken.type)) {
      throwError(
        'Unexpected Token: ' + followingToken.value,
        capitalizeFirstLetter(grammar.phrased[followingToken.type]) +
          ' cannot follow ' + grammar.phrased[token.type] + '.',
        followingToken.lineNum,
        followingToken.linePos
      )
    }
  }
}

function checkForRequiredWhitespaces (
  token, followingToken, linePosAfterFirstToken
) {
  if (
    Object.prototype.hasOwnProperty.call(
      grammar.whitespace.requiredBeforeFollowers, token.type
    ) &&
    grammar.whitespace.requiredBeforeFollowers[token.type]
      .includes(followingToken.type) &&
    token.lineNum === followingToken.lineNum &&
    linePosAfterFirstToken === followingToken.linePos
  ) {
    throwError(
      'Missing Whitespace!',
      'A space is required between ' + grammar.phrased[token.type] +
        ' and ' + grammar.phrased[followingToken.type] + '.',
      followingToken.lineNum,
      followingToken.linePos
    )
  }
}

function checkForUnallowedWhitespaces (
  token, followingToken, linePosAfterFirstToken
) {
  if (
    Object.prototype.hasOwnProperty.call(
      grammar.whitespace.unallowedBeforeFollowers, token.type
    ) &&
    grammar.whitespace.unallowedBeforeFollowers[token.type]
      .includes(followingToken.type) &&
    (
      token.lineNum !== followingToken.lineNum ||
      linePosAfterFirstToken < followingToken.linePos
    )
  ) {
    throwError(
      'Illegal Whitespace!',
      'A space is unallowed between ' + grammar.phrased[token.type] +
        ' and ' + grammar.phrased[followingToken.type] + '.',
      token.lineNum,
      linePosAfterFirstToken
    )
  }
}

function validateWhitespaces (tokens) {
  for (let i = 0, len = tokens.length - 1; i < len; i++) {
    const token = tokens[i]
    const followingToken = tokens[i + 1]
    const linePosAfterFirstToken = token.linePos + token.rawLength
    checkForRequiredWhitespaces(token, followingToken, linePosAfterFirstToken)
    checkForUnallowedWhitespaces(token, followingToken, linePosAfterFirstToken)
  }
}

function sanitize (tokens) {
  assignDepthsToTokens(tokens)
  validateTupletExprParentheses(tokens)
  validateDurations(tokens)
  renameStringToDatum(tokens)
  validateTokenOrder(tokens)
  validateWhitespaces(tokens)
  return tokens
}

module.exports = tokens => sanitize(tokens)
