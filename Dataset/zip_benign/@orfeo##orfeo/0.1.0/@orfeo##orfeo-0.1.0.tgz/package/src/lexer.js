/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

const grammar = require('../src/grammar')
const { throwError } = require('../src/utilities')
const { doesEntireStringMatchRegex, is } = require('../src/validators')

let tokens, lines, line, lineNum, linePos, EOF

// -----------------------------------------------------------------------------
// File Scanning
// -----------------------------------------------------------------------------
// Peeks at a number of chars from the current position.
// If "end of line" is reached, false is returned.
function peek (num) {
  return linePos + num - 1 <= line.length
    ? line.substr(linePos - 1, num)
    : false
}

function moveToNextLine () {
  linePos = 1
  lineNum++
  if (lineNum <= lines.length) {
    line = lines[lineNum - 1]
  } else {
    EOF = true
  }
}

function moveToNextChar () {
  if (linePos < line.length) {
    linePos++
  } else {
    moveToNextLine()
  }
}

function move (num) {
  for (num; num > 0; num--) {
    moveToNextChar()
  }
}

// -----------------------------------------------------------------------------
// Utilities
// -----------------------------------------------------------------------------
function createToken (
  type, value, lineNum, linePos, rawLength = value.length
) {
  tokens.push({
    type: type,
    value: value,
    lineNum: lineNum,
    linePos: linePos,
    // Raw length in code.
    // E.g. The double quoted string "abc" has a rawLength of 5.
    // Used for whitespace validation.
    rawLength: rawLength,
  })
}

// -----------------------------------------------------------------------------
// Capturers
// -----------------------------------------------------------------------------
function captureChar (char, type) {
  createToken(type, char, lineNum, linePos)
  move(1)
}

function captureSequence (str, type) {
  const lineNumAtStart = lineNum
  const linePosAtStart = linePos
  let done = false
  move(str.length)
  // The following line is disabled for eslint because lineNum
  // is modified in the move function instead of the loop.
  while (!done && lineNum === lineNumAtStart) { // eslint-disable-line
    const peek1 = peek(1)
    if (is(str + peek1, type)) {
      str += peek1
      move(1)
    } else {
      done = true
    }
  }
  createToken(type, str, lineNumAtStart, linePosAtStart)
}

function captureString (delimiter) {
  const lineNumAtStart = lineNum
  const linePosAtStart = linePos
  let str = ''
  let done = false
  move(1)
  do {
    const peek1 = peek(1)
    if (peek1 === false || lineNum !== lineNumAtStart) {
      throwError(
        'Unexpected End Of Line!',
        'The string started at ' +
          lineNumAtStart + ':' + linePosAtStart + ' was not terminated.',
        lineNumAtStart,
        linePosAtStart + str.length + 1
      )
    }
    if (doesEntireStringMatchRegex(peek1, new RegExp(delimiter))) {
      done = true
    } else {
      str += peek1
    }
    move(1)
  } while (!done)
  createToken('STRING', str, lineNumAtStart, linePosAtStart, str.length + 2)
}

function getRhythmDotsFromDatum (datum) {
  let rhythmDots = ''
  for (let len = datum.length; len > 0; len--) {
    if (is(datum.substr(0, len), 'DATUM')) {
      break
    } else {
      rhythmDots += '.'
    }
  }
  return rhythmDots
}

function captureDatumAndRhythmDots (str) {
  captureSequence(str, 'DATUM_LOOSE')
  const token = tokens[tokens.length - 1]
  if (is(token.value, 'RHYTHM_DOTS')) {
    token.type = 'RHYTHM_DOTS'
  } else {
    token.type = 'DATUM'
    const rhythmDots = getRhythmDotsFromDatum(token.value)
    if (rhythmDots.length > 0) {
      // Calculate the new DATUM length and value.
      const newDatumLength = token.value.length - rhythmDots.length
      const newDatumValue = token.value.substring(0, newDatumLength)
      // Create the RHYTHM_DOTS token.
      createToken(
        'RHYTHM_DOTS',
        rhythmDots,
        token.lineNum,
        token.linePos + newDatumLength
      )
      // Save the new DATUM value and rawLength.
      token.value = newDatumValue
      token.rawLength = newDatumLength
    }
  }
}

// -----------------------------------------------------------------------------
// Lexing
// -----------------------------------------------------------------------------
function lex (file) {
  tokens = []
  lines = file.split(grammar.regex.NEWLINE)
  line = lines[0]
  lineNum = 1
  linePos = 1
  EOF = false
  do {
    const peek1 = peek(1)
    if (peek1 === false) moveToNextLine()
    else if (is(peek1, 'TUPLET_EXPR_OPEN'))  captureChar(peek1, 'TUPLET_EXPR_OPEN')
    else if (is(peek1, 'TUPLET_EXPR_CLOSE')) captureChar(peek1, 'TUPLET_EXPR_CLOSE')
    else if (is(peek1, 'DURATION'))          captureSequence(peek1, 'DURATION')
    else if (is(peek1, 'DATUM_LOOSE'))       captureDatumAndRhythmDots(peek1)
    else if (is(peek1, 'STRING_DELIM'))      captureString(peek1)
    else if (is(peek1, 'RHYTHM_FLAGS'))      captureSequence(peek1, 'RHYTHM_FLAGS')
    else if (is(peek1, 'NONWHITESPACE')) {
      throwError('Unknown Token: ' + peek1, null, lineNum, linePos)
    } else {
      move(1)
    }
  } while (!EOF)
  return tokens
}

module.exports = file => lex(file)
