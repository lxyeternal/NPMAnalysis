/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

const lex = require('./src/lexer')
const sanitize = require('./src/sanitizer')
const parse = require('./src/parser')

module.exports = file => parse(sanitize(lex(file)))
