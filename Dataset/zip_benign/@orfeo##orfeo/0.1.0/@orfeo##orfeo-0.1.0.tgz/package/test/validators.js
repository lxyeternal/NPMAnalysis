/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

const { expect } = require('chai')
const grammar = require('../src/grammar')
const {
  isString,
  doesEntireStringMatchRegex,
  is,
} = require('../src/validators')

describe('#validators', () => {
  describe('isString()', () => {
    it('TRUE  for strings', () => {
      testIsString(['', 'str', '10'], true)
    })

    it('FALSE for non-strings', () => {
      testIsString([undefined, null, true, 10, [], {}, Math], false)
    })
  })

  describe('doesEntireStringMatchRegex()', () => {
    it('FALSE for non-strings', () => {
      testDoesEntireStringMatchRegex(
        [[undefined], [null], [true], [10], [[]], [{}], [Math]], false
      )
    })

    it('TRUE  if entire string matches regex', () => {
      const values = [
        ['(',      'TUPLET_EXPR_OPEN'],
        [')',      'TUPLET_EXPR_CLOSE'],
        [':4/4',   'DURATION'],
        ['datum',  'DATUM'],
        ['^^^',    'RHYTHM_FLAGS'],
        ['...',    'RHYTHM_DOTS'],
        ['-00.01', 'NUMBER'],
      ]
      testDoesEntireStringMatchRegex(values, true)
    })

    it('FALSE if entire string does not match regex', () => {
      const values = [
        ['!(',      'TUPLET_EXPR_OPEN'],
        ['!)',      'TUPLET_EXPR_CLOSE'],
        ['!:4/4',   'DURATION'],
        ['!datum',  'DATUM'],
        ['!^^^',    'RHYTHM_FLAGS'],
        ['!...',    'RHYTHM_DOTS'],
        ['!-00.01', 'NUMBER'],
      ]
      testDoesEntireStringMatchRegex(values, false)
    })
  })

  describe('is()', () => {
    it('TRUE  if string is of a given Orfeo type', () => {
      const values = [
        ['(',      'TUPLET_EXPR_OPEN'],
        [')',      'TUPLET_EXPR_CLOSE'],
        [':4/4',   'DURATION'],
        ['datum',  'DATUM'],
        ['^^^',    'RHYTHM_FLAGS'],
        ['...',    'RHYTHM_DOTS'],
        ['-00.01', 'NUMBER'],
      ]
      testIs(values, true)
    })

    it('FALSE if string is not of a given Orfeo type', () => {
      const values = [
        ['!(',      'TUPLET_EXPR_OPEN'],
        ['!)',      'TUPLET_EXPR_CLOSE'],
        ['!:4/4',   'DURATION'],
        ['!datum',  'DATUM'],
        ['!^^^',    'RHYTHM_FLAGS'],
        ['!...',    'RHYTHM_DOTS'],
        ['!-00.01', 'NUMBER'],
      ]
      testIs(values, false)
    })
  })
})

function testIsString (values, expected) {
  values.forEach(v => {
    const result = isString(v)
    expect(result).to.equal(expected)
  })
}

function testDoesEntireStringMatchRegex (values, expected) {
  values.forEach(v => {
    const result = doesEntireStringMatchRegex(v[0], grammar.regex[v[1]])
    expect(result).to.equal(expected)
  })
}

function testIs (values, expected) {
  values.forEach(v => {
    const result = is(v[0], v[1])
    expect(result).to.equal(expected)
  })
}
