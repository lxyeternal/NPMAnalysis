/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

const { expect } = require('chai')
const lexer = require('../src/lexer')
const f = v => () => lexer(v)

describe('#lexer', () => {
  describe('TUPLET_EXPR_OPEN', () => {
    it('capture a tuplet expression opening parenthesis', function () {
      const file = '('
      testEachToken(file, this)
    })
  })

  describe('TUPLET_EXPR_CLOSE', () => {
    it('capture a tuplet expression closing parenthesis', function () {
      const file = ')'
      testEachToken(file, this)
    })
  })

  describe('DURATION', () => {
    it('capture various durations', function () {
      const file = ': := :1 :1.1 :-1.1 :1/1 :1.1/1.1 :-1.1/-1.1'
      testEachToken(file, this)
    })
  })

  describe('DATUM', () => {
    it('capture all legal beginning characters', function () {
      const file = `
        a b c d e f g h i j k l m n o p q r s t u v w x y z
        A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
        0 1 2 3 4 5 6 7 8 9
        .a _ / [ ] ♮ ♭ ♯ -
      `
      testEachToken(file, this)
    })

    it('capture all legal characters', function () {
      const file = `
        abcdefghijklmnopqrstuvwxyz
        ABCDEFGHIJKLMNOPQRSTUVWXYZ
        0123456789
        ._/[]♮♭♯-
      `
      testEachToken(file, this)
    })

    it('capture various character combinations', function () {
      const file = 'ab -ab .ab _ab ABC A_B_C A.B.C A-B-C A/B[0] C♮♭♯ 0 -0 -0.0'
      testEachToken(file, this)
    })

    it('separate datum from rhythm dots', () => {
      const file = 'datum...'
      const result = lexer(file)
      const expected = [
        { type: 'DATUM',       value: 'datum', lineNum: 1, linePos: 1, rawLength: 5 },
        { type: 'RHYTHM_DOTS', value: '...',   lineNum: 1, linePos: 6, rawLength: 3 },
      ]
      expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
    })
  })

  describe('STRING', () => {
    it('capture various strings', function () {
      const file = '"abc" "ABC" "123" "!@#"'
      testEachToken(file, this)
    })

    it('capture an empty string', function () {
      const file = '""'
      testEachToken(file, this)
    })

    it('ERR if string is not terminated', () => {
      const file = ' "abc'
      expect(f(file)).to.throw(
        'At 1:6' + '\n' +
        'Unexpected End Of Line!' + '\n' +
        'The string started at 1:2 was not terminated.'
      )
    })

    it('ERR if string is terminated on the next line', () => {
      const file = ` "abc
                   "`
      expect(f(file)).to.throw(
        'At 1:6' + '\n' +
        'Unexpected End Of Line!' + '\n' +
        'The string started at 1:2 was not terminated.'
      )
    })
  })

  describe('RHYTHM_FLAGS', () => {
    it('capture one', function () {
      const file = '^'
      testEachToken(file, this)
    })

    it('capture many', function () {
      const file = '^^^'
      testEachToken(file, this)
    })
  })

  describe('RHYTHM_DOTS', () => {
    it('capture one', function () {
      const file = '.'
      testEachToken(file, this)
    })

    it('capture many', function () {
      const file = '...'
      testEachToken(file, this)
    })
  })

  describe('unknown token', () => {
    it('ERR with $', () => {
      const file = '$'
      expect(f(file)).to.throw('At 1:1\nUnknown Token: $')
    })
  })

  describe('line jumps', () => {
    it('should work with line jumps', () => {
      const file = `(
1 2
  3


4

  5
6
)`
      const result = lexer(file)
      const expected = [
        { type: 'TUPLET_EXPR_OPEN',  value: '(', lineNum: 1,  linePos: 1, rawLength: 1 },
        { type: 'DATUM',             value: '1', lineNum: 2,  linePos: 1, rawLength: 1 },
        { type: 'DATUM',             value: '2', lineNum: 2,  linePos: 3, rawLength: 1 },
        { type: 'DATUM',             value: '3', lineNum: 3,  linePos: 3, rawLength: 1 },
        { type: 'DATUM',             value: '4', lineNum: 6,  linePos: 1, rawLength: 1 },
        { type: 'DATUM',             value: '5', lineNum: 8,  linePos: 3, rawLength: 1 },
        { type: 'DATUM',             value: '6', lineNum: 9,  linePos: 1, rawLength: 1 },
        { type: 'TUPLET_EXPR_CLOSE', value: ')', lineNum: 10, linePos: 1, rawLength: 1 },
      ]
      expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
    })
  })

  describe('potpourri', () => {
    it('should work with all tokens', () => {
      const file = '^^(:= (:4 a abc (:4/4 1 123) ^.-9. ^^^ ... "str"))..'
      const result = lexer(file)
      const expected = [
        { type: 'RHYTHM_FLAGS',      value: '^^',   lineNum: 1, linePos: 1,  rawLength: 2 },
        { type: 'TUPLET_EXPR_OPEN',  value: '(',    lineNum: 1, linePos: 3,  rawLength: 1 },
        { type: 'DURATION',          value: ':=',   lineNum: 1, linePos: 4,  rawLength: 2 },
        { type: 'TUPLET_EXPR_OPEN',  value: '(',    lineNum: 1, linePos: 7,  rawLength: 1 },
        { type: 'DURATION',          value: ':4',   lineNum: 1, linePos: 8,  rawLength: 2 },
        { type: 'DATUM',             value: 'a',    lineNum: 1, linePos: 11, rawLength: 1 },
        { type: 'DATUM',             value: 'abc',  lineNum: 1, linePos: 13, rawLength: 3 },
        { type: 'TUPLET_EXPR_OPEN',  value: '(',    lineNum: 1, linePos: 17, rawLength: 1 },
        { type: 'DURATION',          value: ':4/4', lineNum: 1, linePos: 18, rawLength: 4 },
        { type: 'DATUM',             value: '1',    lineNum: 1, linePos: 23, rawLength: 1 },
        { type: 'DATUM',             value: '123',  lineNum: 1, linePos: 25, rawLength: 3 },
        { type: 'TUPLET_EXPR_CLOSE', value: ')',    lineNum: 1, linePos: 28, rawLength: 1 },
        { type: 'RHYTHM_FLAGS',      value: '^',    lineNum: 1, linePos: 30, rawLength: 1 },
        { type: 'DATUM',             value: '.-9',  lineNum: 1, linePos: 31, rawLength: 3 },
        { type: 'RHYTHM_DOTS',       value: '.',    lineNum: 1, linePos: 34, rawLength: 1 },
        { type: 'RHYTHM_FLAGS',      value: '^^^',  lineNum: 1, linePos: 36, rawLength: 3 },
        { type: 'RHYTHM_DOTS',       value: '...',  lineNum: 1, linePos: 40, rawLength: 3 },
        { type: 'STRING',            value: 'str',  lineNum: 1, linePos: 44, rawLength: 5 },
        { type: 'TUPLET_EXPR_CLOSE', value: ')',    lineNum: 1, linePos: 49, rawLength: 1 },
        { type: 'TUPLET_EXPR_CLOSE', value: ')',    lineNum: 1, linePos: 50, rawLength: 1 },
        { type: 'RHYTHM_DOTS',       value: '..',   lineNum: 1, linePos: 51, rawLength: 2 },
      ]
      expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
    })
  })
})

function testEachToken (file, that) {
  const tokenType = that.test.parent.title
  const tokens = file.trim().split(/\s+/)
  tokens.forEach(token => {
    const result = lexer(token)
    const expected = [
      {
        type: tokenType,
        value: tokenType !== 'STRING'
          ? token
          : token.substr(1, token.length - 2),
        lineNum: 1,
        linePos: 1,
        rawLength: token.length,
      },
    ]
    expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
  })
}
