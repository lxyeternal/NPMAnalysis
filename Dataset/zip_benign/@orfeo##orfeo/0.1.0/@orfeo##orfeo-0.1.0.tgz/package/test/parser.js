/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

const { expect } = require('chai')
const compile = require('../index')
const f = v => () => compile(v)

describe('#parser', () => {
  describe('errors', () => {
    describe('duration', () => {
      it('ERR duration number has a leading zero', () => {
        const file = '(:01)'
        expect(f(file)).to.throw(
          'At 1:2' + '\n' +
          'Illegal Leading Zero: :01' + '\n' +
          'A duration number cannot have a leading zero.'
        )
      })

      it('ERR duration number is negative', () => {
        const file = '(:-1)'
        expect(f(file)).to.throw(
          'At 1:2' + '\n' +
          'Illegal Negative Number: :-1' + '\n' +
          'A duration number cannot be negative.'
        )
      })

      it('ERR duration timesignature nominator has a leading zero', () => {
        const file = '(:04/4)'
        expect(f(file)).to.throw(
          'At 1:2' + '\n' +
          'Illegal Leading Zero: :04/4' + '\n' +
          'A duration timesignature nominator cannot have a leading zero.'
        )
      })

      it('ERR duration timesignature denominator has a leading zero', () => {
        const file = '(:4/04)'
        expect(f(file)).to.throw(
          'At 1:2' + '\n' +
          'Illegal Leading Zero: :4/04' + '\n' +
          'A duration timesignature denominator cannot have a leading zero.'
        )
      })

      it('ERR duration timesignature nominator is negative', () => {
        const file = '(:-1/1)'
        expect(f(file)).to.throw(
          'At 1:2' + '\n' +
          'Illegal Negative Number: :-1/1' + '\n' +
          'A duration timesignature nominator cannot be negative.'
        )
      })

      it('ERR duration timesignature denominator is negative', () => {
        const file = '(:1/-1)'
        expect(f(file)).to.throw(
          'At 1:2' + '\n' +
          'Illegal Negative Number: :1/-1' + '\n' +
          'A duration timesignature denominator cannot be negative.'
        )
      })

      it('ERR duration timesignature denominator is equal to zero', () => {
        const file = '(:1/0)'
        expect(f(file)).to.throw(
          'At 1:2' + '\n' +
          'Illegal Divide By Zero: :1/0' + '\n' +
          'A duration timesignature denominator cannot be equal to zero.'
        )
      })
    })
  })

  describe('rendering', () => {
    describe('to timeline file format', () => {
      describe('empty Orfeo program', () => {
        it('empty file', () => {
          const file = ''
          const result = compile(file)
          const expected = ''
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('empty top tuplet expr', () => {
          const file = '()'
          const result = compile(file)
          const expected = ''
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('tuplet expr duration = 0', () => {
          const file = '(:0)'
          const result = compile(file)
          const expected = ''
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('tuplet expr duration = 0 with datum', () => {
          const file = '(:0 a b c d)'
          const result = compile(file)
          const expected = ''
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('tuplet expr duration = 0 with nested tuplet expr', () => {
          const file = '(:0 (a b c d))'
          const result = compile(file)
          const expected = ''
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('tuplet expr duration = 1 with nested tuplet expr duration = 0', () => {
          const file = '(:1 (:0 a b c d))'
          const result = compile(file)
          const expected = ''
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })
      })

      describe('tuplet expressions', () => {
        it('plain', () => {
          const file = '(a b c d)'
          const result = compile(file)
          const expected =
`0 a
0.25 b
0.5 c
0.75 d
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('depth of 2 at the beginning', () => {
          const file = '((a b) c d e)'
          const result = compile(file)
          const expected =
`0 a
0.125 b
0.25 c
0.5 d
0.75 e
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('depth of 2 in the middle', () => {
          const file = '(a (b c) d e)'
          const result = compile(file)
          const expected =
`0 a
0.25 b
0.375 c
0.5 d
0.75 e
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('depth of 2 at the end', () => {
          const file = '(a b c (d e))'
          const result = compile(file)
          const expected =
`0 a
0.25 b
0.5 c
0.75 d
0.875 e
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('adjacent tuplet expr', () => {
          const file = '((a b c d) (e f g h))'
          const result = compile(file)
          const expected =
`0 a
0.125 b
0.25 c
0.375 d
0.5 e
0.625 f
0.75 g
0.875 h
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('multiple depths', () => {
          const file = '(a b (c (d e)) f)'
          const result = compile(file)
          const expected =
`0 a
0.25 b
0.5 c
0.625 d
0.6875 e
0.75 f
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })
      })

      describe('datum', () => {
        it('whitespace padded datum strings', () => {
          const file = '(" a " "  b " "  c" "d  ")'
          const result = compile(file)
          const expected =
`0 " a "
0.25 "  b "
0.5 "  c"
0.75 "d  "
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })
      })

      describe('duration', () => {
        it('one equals duration', () => {
          const file = '(:= a b c d)'
          const result = compile(file)
          const expected =
`0 a
1 b
2 c
3 d
4
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('nested equals duration', () => {
          const file = '(:= a (:= b (:= c d)) e)'
          const result = compile(file)
          const expected =
`0 a
1 b
2 c
3 d
4 e
5
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('nested equals and number durations', () => {
          const file = '(:= a (:4 b (:= c d)) e (:2.5 f (:= g h (:= i))))'
          const result = compile(file)
          const expected =
`0 a
1 b
2.333333333333333 c
3.666666666666666 d
5 e
6 f
6.625 g
7.25 h
7.875 i
8.5
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('one integer number duration', () => {
          const file = '(:2 a b c d)'
          const result = compile(file)
          const expected =
`0 a
0.5 b
1 c
1.5 d
2
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('many integer number durations', () => {
          const file = '((:1 a) (:2 b) (:3 c) (:4 d))'
          const result = compile(file)
          const expected =
`0 a
0.1 b
0.30000000000000004 c
0.6000000000000001 d
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('one float number duration', () => {
          const file = '(:90.5 a b c d)'
          const result = compile(file)
          const expected =
`0 a
22.625 b
45.25 c
67.875 d
90.5
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('many float number durations', () => {
          const file = '((:1 a) (:.9 b) (:.8 c) (:.7 d))'
          const result = compile(file)
          const expected =
`0 a
0.2941176470588235 b
0.5588235294117646 c
0.7941176470588235 d
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('one integer timesignature duration', () => {
          const file = '(:4/4 a b c d)'
          const result = compile(file)
          const expected =
`0 a
1 b
2 c
3 d
4
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('many integer timesignature durations', () => {
          const file = '(:= (:4/4 a) (:5/8 b) (:1/1 c) (:4/6 d))'
          const result = compile(file)
          const expected =
`0 a
4 b
6.5 c
10.5 d
13.166666666666666
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('one float timesignature duration', () => {
          const file = '(:4.1/4.5 a b c d)'
          const result = compile(file)
          const expected =
`0 a
0.911111111111111 b
1.822222222222222 c
2.733333333333333 d
3.644444444444444
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('many float timesignature durations', () => {
          const file = '(:= (:4.5/4.1 a) (:5.5/8.1 b) (:1.5/1.1 c) (:4.5/6.1 d))'
          const result = compile(file)
          const expected =
`0 a
4.390243902439025 b
7.106293285155074 c
12.560838739700529 d
15.511658411831677
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('integer number duration at depth 2', () => {
          const file = '(a (:2 b c d) e)'
          const result = compile(file)
          const expected =
`0 a
0.25 b
0.41666666666666663 c
0.5833333333333333 d
0.75 e
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('duration = 10 without datum', () => {
          const file = '(a (:10) b c)'
          const result = compile(file)
          const expected =
`0 a
0.8461538461538463 b
0.9230769230769231 c
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('children of duration = 0', () => {
          const file = '(a (:0) b (:0) c (:0) d)'
          const result = compile(file)
          const expected =
`0 a
0.25 b
0.5 c
0.75 d
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('children of duration = 0 with datum', () => {
          const file = '(a (:0 erased) b (:0 erased erased) c (:0 erased) d)'
          const result = compile(file)
          const expected =
`0 a
0.25 b
0.5 c
0.75 d
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('children of duration = 0 with children datum', () => {
          const file = '(a (:0 (erased)) b (:0 (erased erased)) c (:0 (erased)) d)'
          const result = compile(file)
          const expected =
`0 a
0.25 b
0.5 c
0.75 d
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })
      })

      describe('rhythm flags and dots', () => {
        it('flags on datum', () => {
          const file = '(a ^b ^^c ^^^d)'
          const result = compile(file)
          const expected =
`0 a
0.5333333333333333 b
0.8 c
0.9333333333333333 d
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('dots on datum', () => {
          const file = '(a b. c.. d...)'
          const result = compile(file)
          const expected =
`0 a
0.16326530612244897 b
0.4081632653061224 c
0.6938775510204082 d
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('flags and dots on datum', () => {
          const file = '(a... ^b.. ^^c. ^^^d)'
          const result = compile(file)
          const expected =
`0 a
0.576923076923077 b
0.8461538461538463 c
0.9615384615384616 d
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('flags on tuplet expr', () => {
          const file = '^(a b c ^^(d e) )'
          const result = compile(file)
          const expected =
`0 a
0.15384615384615385 b
0.3076923076923077 c
0.46153846153846156 d
0.4807692307692308 e
0.5
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('dots on tuplet expr', () => {
          const file = '(a b c (d e). )..'
          const result = compile(file)
          const expected =
`0 a
0.3888888888888889 b
0.7777777777777778 c
1.1666666666666667 d
1.4583333333333335 e
1.75
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('flags and dots on tuplet expr', () => {
          const file = '^(a b c ^^(d e). )..'
          const result = compile(file)
          const expected =
`0 a
0.25925925925925924 b
0.5185185185185185 c
0.7777777777777777 d
0.8263888888888888 e
0.875
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('flags and dots on datum in tuplet expr with duration', () => {
          const file = '(:2.5 a b. ^c. d..)'
          const result = compile(file)
          const expected =
`0 a
0.5 b
1.25 c
1.625 d
2.5
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('flags and dots on a tuplet expr with a duration', () => {
          const file = '^^(:2.5 a b c d).'
          const result = compile(file)
          const expected =
`0 a
0.234375 b
0.46875 c
0.703125 d
0.9375
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })

        it('potpourri of dots and flags', () => {
          const file = '^(:3.5 ^^(:2.5 a b. ^c ^^d..).. ).'
          const result = compile(file)
          const expected =
`0 a
0.7636363636363636 b
1.909090909090909 c
2.2909090909090906 d
2.625
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })
      })

      describe('general', () => {
        it('potpourri of everything', () => {
          const file = '("cat" (:2.5 _A♭B♯ a♮ "dog" ^(:3 ^^_0.9 _a..). "hen & fly" (_ (:= _ (:4/4 _)))) b)'
          const result = compile(file)
          const expected =
`0 cat
0.2222222222222222 _A♭B♯
0.29885057471264365 a♮
0.3754789272030651 dog
0.4521072796934866 _0.9
0.4736590038314176 _a
0.6245210727969348 hen & fly
0.7011494252873562 _
0.7139208173690932 _
0.7266922094508301 _
0.7777777777777777 b
1
`
          expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
        })
      })
    })
  })
})
