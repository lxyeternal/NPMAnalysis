/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

const { expect } = require('chai')
const {
  capitalizeFirstLetter,
  doesStringifiedNumHaveLeadingZero,
  throwError,
  findIndexOfNthOccurrenceOfTokenType,
} = require('../src/utilities')

describe('#utilities', () => {
  describe('capitalizeFirstLetter()', () => {
    it('capitalize the first letter', () => {
      const word = 'orfeo'
      const result = capitalizeFirstLetter(word)
      const expected = 'Orfeo'
      expect(result).to.equal(expected)
    })
  })

  describe('doesStringifiedNumHaveLeadingZero()', () => {
    it('FALSE when there is no leading zero', () => {
      const strNum = '1'
      const result = doesStringifiedNumHaveLeadingZero(strNum)
      const expected = false
      expect(result).to.equal(expected)
    })

    it('TRUE  when there is one leading zero', () => {
      const strNum = '01.0'
      const result = doesStringifiedNumHaveLeadingZero(strNum)
      const expected = true
      expect(result).to.equal(expected)
    })

    it('TRUE  when there are many leading zeros', () => {
      const strNum = '0001.0'
      const result = doesStringifiedNumHaveLeadingZero(strNum)
      const expected = true
      expect(result).to.equal(expected)
    })
  })

  describe('throwError()', () => {
    const f = (status, msg, lineNum, linePos) => () =>
      throwError(status, msg, lineNum, linePos)

    it('ERR with all parameters', () => {
      const status = 'status'
      const msg = 'message'
      const lineNum = 1
      const linePos = 2
      expect(f(status, msg, lineNum, linePos)).to.throw(
        'At 1:2' + '\n' +
        'status' + '\n' +
        'message'
      )
    })

    it('ERR without lineNum nor linePos', () => {
      const status = 'status'
      const msg = 'message'
      expect(f(status, msg)).to.throw(
        'status' + '\n' +
        'message'
      )
    })

    it('ERR without msg, lineNum nor linePos', () => {
      const status = 'status'
      expect(f(status)).to.throw(
        'status'
      )
    })

    it('ERR with msg === null', () => {
      const status = 'status'
      const msg = null
      const lineNum = 1
      const linePos = 2
      expect(f(status, msg, lineNum, linePos)).to.throw(
        'At 1:2' + '\n' +
        'status'
      )
    })
  })

  describe('findIndexOfNthOccurrenceOfTokenType()', () => {
    it('NULL when none is found', () => {
      const tokens = [
        { type: 'a' },
        { type: 'b' },
        { type: 'c' },
      ]
      const nthOccurrence = 1
      const type = 'none'
      const result = findIndexOfNthOccurrenceOfTokenType(
        tokens, nthOccurrence, type
      )
      const expected = null
      expect(result).to.equal(expected)
    })

    it('find index of the first occurrence', () => {
      const tokens = [
        { type: 'a' },
        { type: 'b' },
        { type: 'c' },
      ]
      const nthOccurrence = 1
      const type = 'b'
      const result = findIndexOfNthOccurrenceOfTokenType(
        tokens, nthOccurrence, type
      )
      const expected = 1
      expect(result).to.equal(expected)
    })

    it('find index of the second occurrence', () => {
      const tokens = [
        { type: 'a' },
        { type: 'b' },
        { type: 'a' },
      ]
      const nthOccurrence = 2
      const type = 'a'
      const result = findIndexOfNthOccurrenceOfTokenType(
        tokens, nthOccurrence, type
      )
      const expected = 2
      expect(result).to.equal(expected)
    })

    it('should work with the depth option', () => {
      const tokens = [
        { type: 'a', depth: 0 },
        { type: 'a', depth: 1 },
        { type: 'a', depth: 1 },
      ]
      const nthOccurrence = 2
      const type = 'a'
      const depth = 1
      const result = findIndexOfNthOccurrenceOfTokenType(
        tokens, nthOccurrence, type, depth
      )
      const expected = 2
      expect(result).to.equal(expected)
    })
  })
})
