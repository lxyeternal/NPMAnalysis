/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

const { expect } = require('chai')
const { is } = require('../src/validators')

describe('#number', () => {
  describe('capture integers', () => {
    it('single char positive integers', () => {
      const file = '0 1 2 3 4 5 6 7 8 9'
      testEachNumber(file)
    })

    it('single char negative integers', () => {
      const file = '-0 -1 -2 -3 -4 -5 -6 -7 -8 -9'
      testEachNumber(file)
    })

    it('multi char positive integers', () => {
      const file = '012 345 6789'
      testEachNumber(file)
    })

    it('multi char negative integers', () => {
      const file = '-012 -345 -6789'
      testEachNumber(file)
    })
  })

  describe('capture floats', () => {
    it('single char positive floats starting with .', () => {
      const file = '.0 .1 .2 .3 .4 .5 .6 .7 .8 .9'
      testEachNumber(file)
    })

    it('single char negative floats starting with -.', () => {
      const file = '-.0 -.1 -.2 -.3 -.4 -.5 -.6 -.7 -.8 -.9'
      testEachNumber(file)
    })

    it('single char positive floats starting with 0.', () => {
      const file = '0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9'
      testEachNumber(file)
    })

    it('single char negative floats starting with -0.', () => {
      const file = '-0.0 -0.1 -0.2 -0.3 -0.4 -0.5 -0.6 -0.7 -0.8 -0.9'
      testEachNumber(file)
    })

    it('multi char positive floats starting with .', () => {
      const file = '.012 .345 .6789'
      testEachNumber(file)
    })

    it('multi char negative floats starting with -.', () => {
      const file = '-.012 -.345 -.6789'
      testEachNumber(file)
    })

    it('multi char positive floats starting with 0.', () => {
      const file = '0.012 0.345 0.6789'
      testEachNumber(file)
    })

    it('multi char negative floats starting with -0.', () => {
      const file = '-0.012 -0.345 -0.6789'
      testEachNumber(file)
    })

    it('multi char positive floats starting with 012.', () => {
      const file = '012.012 345.345 6789.6789'
      testEachNumber(file)
    })

    it('multi char negative floats starting with -012.', () => {
      const file = '-012.012 -345.345 -6789.6789'
      testEachNumber(file)
    })
  })

  describe('capture zeros', () => {
    it('leading zeros', () => {
      const file = '001 -001 .001 -.001 0.001 -0.001'
      testEachNumber(file)
    })

    it('trailing zeros', () => {
      const file = '100 -100 .100 -.100 0.100 -0.100'
      testEachNumber(file)
    })

    it('only zeros', () => {
      const file = '000 -000 .000 -.000 000.000 -000.000'
      testEachNumber(file)
    })
  })
})

function testEachNumber (numbers) {
  numbers.split(' ').forEach(number => {
    const result = is(number, 'NUMBER')
    const expected = true
    expect(result).to.equal(expected)
  })
}
