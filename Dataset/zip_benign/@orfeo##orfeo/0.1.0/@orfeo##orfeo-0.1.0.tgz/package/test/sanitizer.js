/* -----------------------------------------------------------------------------
  Copyright (c) 2019-2020, Pierre-Emmanuel Lévesque
  License: MIT
----------------------------------------------------------------------------- */
'use strict'

const { expect } = require('chai')
const grammar = require('../src/grammar')
const lexer = require('../src/lexer')
const sanitizer = require('../src/sanitizer')
const { capitalizeFirstLetter } = require('../src/utilities')
const sanitize = file => sanitizer(lexer(file))
const f = v => () => sanitize(v)

describe('#sanitizer', () => {
  describe('assignDepthsToTokens()', () => {
    it('add a depth property to each token', () => {
      const file = '^^(a (b c))..'
      const result = sanitize(file)
      const expected = [
        { type: 'RHYTHM_FLAGS',      value: '^^', lineNum: 1, linePos: 1,  rawLength: 2, depth: 0 },
        { type: 'TUPLET_EXPR_OPEN',  value: '(',  lineNum: 1, linePos: 3,  rawLength: 1, depth: 1 },
        { type: 'DATUM',             value: 'a',  lineNum: 1, linePos: 4,  rawLength: 1, depth: 1 },
        { type: 'TUPLET_EXPR_OPEN',  value: '(',  lineNum: 1, linePos: 6,  rawLength: 1, depth: 2 },
        { type: 'DATUM',             value: 'b',  lineNum: 1, linePos: 7,  rawLength: 1, depth: 2 },
        { type: 'DATUM',             value: 'c',  lineNum: 1, linePos: 9,  rawLength: 1, depth: 2 },
        { type: 'TUPLET_EXPR_CLOSE', value: ')',  lineNum: 1, linePos: 10, rawLength: 1, depth: 2 },
        { type: 'TUPLET_EXPR_CLOSE', value: ')',  lineNum: 1, linePos: 11, rawLength: 1, depth: 1 },
        { type: 'RHYTHM_DOTS',       value: '..', lineNum: 1, linePos: 12, rawLength: 2, depth: 0 },
      ]
      expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
    })
  })

  describe('validateTupletExprParentheses()', () => {
    describe('checkForAMissingTopLevelTupletExpr()', () => {
      it('ERR missing top level tuplet expression', () => {
        const file = 'datum'
        expect(f(file)).to.throw(
          'Missing Top Level Tuplet Expression!' + '\n' +
          'Non empty files must contain a top level tuplet expression.'
        )
      })
    })

    describe('checkForMoreThanOneTopLevelTupletExpr()', () => {
      it('ERR more than one top level tuplet expression', () => {
        const file = '() ()'
        expect(f(file)).to.throw(
          'At 1:4' + '\n' +
          'Unexpected Token: (' + '\n' +
          'There can only be one top level tuplet expression.'
        )
      })
    })

    describe('checkForAnUneccessaryTupletExprClose()', () => {
      it('ERR uneccessary tuplet expression closing parenthesis', () => {
        const file = '(()))'
        expect(f(file)).to.throw(
          'At 1:5' + '\n' +
          'Unexpected Token: )' + '\n' +
          'There is no opened tuplet expression that needs to be closed.'
        )
      })
    })

    describe('checkForAnUnclosedTupletExpr()', () => {
      it('ERR unclosed tuplet expression', () => {
        const file = '('
        expect(f(file)).to.throw(
          'Unexpected End Of File!' + '\n' +
          'The tuplet expression opened at 1:1 was not closed.'
        )
      })

      it('ERR many unclosed tuplet expressions', () => {
        const file = '((('
        expect(f(file)).to.throw(
          'Unexpected End Of File!' + '\n' +
          'The tuplet expression opened at 1:3 was not closed.'
        )
      })

      it('ERR the right unclosed tuplet expression', () => {
        const file = '((()'
        expect(f(file)).to.throw(
          'Unexpected End Of File!' + '\n' +
          'The tuplet expression opened at 1:2 was not closed.'
        )
      })
    })
  })

  describe('validateDurations()', () => {
    it('ERR an empty duration', () => {
      const file = '(:)'
      expect(f(file)).to.throw(
        'At 1:2' + '\n' +
        'Empty Duration!' + '\n' +
        'You must write a legal duration after the <:> sign.' + '\n' +
        'It must be an equals sign, a number, or a time signature.'
      )
    })

    it('ERR empty duration followed by another token', () => {
      const file = '(:datum)'
      expect(f(file)).to.throw(
        'At 1:2' + '\n' +
        'Empty Duration!' + '\n' +
        'You must write a legal duration after the <:> sign.' + '\n' +
        'It must be an equals sign, a number, or a time signature.'
      )
    })

    it('ERR malformed duration', () => {
      const file = '(:9=.)'
      expect(f(file)).to.throw(
        'At 1:2' + '\n' +
        'Malformed Duration: :9=.' + '\n' +
        'A duration must be an equals sign, a number, or a time signature.'
      )
    })
  })

  describe('renameStringToDatum()', () => {
    it('rename string to datum', () => {
      const file = '("abc" datum "def")'
      const result = sanitize(file)
      const expected = [
        { type: 'TUPLET_EXPR_OPEN',  value: '(',     lineNum: 1, linePos: 1,  rawLength: 1, depth: 1 },
        { type: 'DATUM',             value: 'abc',   lineNum: 1, linePos: 2,  rawLength: 5, depth: 1 },
        { type: 'DATUM',             value: 'datum', lineNum: 1, linePos: 8,  rawLength: 5, depth: 1 },
        { type: 'DATUM',             value: 'def',   lineNum: 1, linePos: 14, rawLength: 5, depth: 1 },
        { type: 'TUPLET_EXPR_CLOSE', value: ')',     lineNum: 1, linePos: 19, rawLength: 1, depth: 1 },
      ]
      expect(JSON.stringify(result)).to.equal(JSON.stringify(expected))
    })
  })

  describe('validateTokenOrder()', () => {
    describe('TUPLET_EXPR_OPEN', () => {
      it('ERR RHYTHM_DOTS', () => {
        const file = '(...)'
        throwTokenOrderErr(file, 2, '...', 'TUPLET_EXPR_OPEN', 'RHYTHM_DOTS')
      })
    })

    describe('TUPLET_EXPR_CLOSE', () => {
      it('ERR DURATION', () => {
        const file = '(() :4/4)'
        throwTokenOrderErr(file, 5, ':4/4', 'TUPLET_EXPR_CLOSE', 'DURATION')
      })
    })

    describe('DURATION', () => {
      it('ERR DURATION', () => {
        const file = '(:4/4 :2/2)'
        throwTokenOrderErr(file, 7, ':2/2', 'DURATION', 'DURATION')
      })

      it('ERR RHYTHM_DOTS', () => {
        const file = '(:4/4 ...)'
        throwTokenOrderErr(file, 7, '...', 'DURATION', 'RHYTHM_DOTS')
      })
    })

    describe('DATUM', () => {
      it('ERR DURATION', () => {
        const file = '(datum :4/4)'
        throwTokenOrderErr(file, 8, ':4/4', 'DATUM', 'DURATION')
      })
    })

    describe('RHYTHM_FLAGS', () => {
      it('ERR TUPLET_EXPR_CLOSE', () => {
        const file = '(^^^)'
        throwTokenOrderErr(file, 5, ')', 'RHYTHM_FLAGS', 'TUPLET_EXPR_CLOSE')
      })

      it('ERR DURATION', () => {
        const file = '(^^^ :4/4)'
        throwTokenOrderErr(file, 6, ':4/4', 'RHYTHM_FLAGS', 'DURATION')
      })

      it('ERR RHYTHM_FLAGS', () => {
        const file = '(^^^ ^^^)'
        throwTokenOrderErr(file, 6, '^^^', 'RHYTHM_FLAGS', 'RHYTHM_FLAGS')
      })

      it('ERR RHYTHM_DOTS', () => {
        const file = '(^^^ ...)'
        throwTokenOrderErr(file, 6, '...', 'RHYTHM_FLAGS', 'RHYTHM_DOTS')
      })
    })

    describe('RHYTHM_DOTS', () => {
      it('ERR DURATION', () => {
        const file = '(()... :4/4)'
        throwTokenOrderErr(file, 8, ':4/4', 'RHYTHM_DOTS', 'DURATION')
      })

      it('ERR RHYTHM_DOTS', () => {
        const file = '(()... ...)'
        throwTokenOrderErr(file, 8, '...', 'RHYTHM_DOTS', 'RHYTHM_DOTS')
      })
    })
  })

  describe('validateWhitespaces()', () => {
    describe('checkForRequiredWhitespaces()', () => {
      describe('TUPLET_EXPR_CLOSE', () => {
        it('ERR TUPLET_EXPR_OPEN', () => {
          const file = '(()())'
          throwMissingWhitespaceErr(file, 4, 'TUPLET_EXPR_CLOSE', 'TUPLET_EXPR_OPEN')
        })

        it('ERR DATUM', () => {
          const file = '(()datum)'
          throwMissingWhitespaceErr(file, 4, 'TUPLET_EXPR_CLOSE', 'DATUM')
        })

        it('ERR RHYTHM_FLAGS', () => {
          const file = '(()^^^datum)'
          throwMissingWhitespaceErr(file, 4, 'TUPLET_EXPR_CLOSE', 'RHYTHM_FLAGS')
        })
      })

      describe('DURATION', () => {
        it('ERR TUPLET_EXPR_OPEN', () => {
          const file = '(:4())'
          throwMissingWhitespaceErr(file, 4, 'DURATION', 'TUPLET_EXPR_OPEN')
        })

        it('ERR DATUM', () => {
          const file = '(:4datum)'
          throwMissingWhitespaceErr(file, 4, 'DURATION', 'DATUM')
        })

        it('ERR RHYTHM_FLAGS', () => {
          const file = '(:4^^^datum)'
          throwMissingWhitespaceErr(file, 4, 'DURATION', 'RHYTHM_FLAGS')
        })
      })

      describe('DATUM', () => {
        it('ERR TUPLET_EXPR_OPEN', () => {
          const file = '(datum())'
          throwMissingWhitespaceErr(file, 7, 'DATUM', 'TUPLET_EXPR_OPEN')
        })

        it('ERR DATUM', () => {
          const file = '(datum"datum")'
          throwMissingWhitespaceErr(file, 7, 'DATUM', 'DATUM')
        })

        it('ERR RHYTHM_FLAGS', () => {
          const file = '(datum^^^datum)'
          throwMissingWhitespaceErr(file, 7, 'DATUM', 'RHYTHM_FLAGS')
        })
      })

      describe('RHYTHM_DOTS', () => {
        it('ERR TUPLET_EXPR_OPEN', () => {
          const file = '(datum...())'
          throwMissingWhitespaceErr(file, 10, 'RHYTHM_DOTS', 'TUPLET_EXPR_OPEN')
        })

        it('ERR DATUM', () => {
          const file = '(datum..."datum")'
          throwMissingWhitespaceErr(file, 10, 'RHYTHM_DOTS', 'DATUM')
        })

        it('ERR RHYTHM_FLAGS', () => {
          const file = '(datum...^^^datum)'
          throwMissingWhitespaceErr(file, 10, 'RHYTHM_DOTS', 'RHYTHM_FLAGS')
        })
      })
    })

    describe('checkForUnallowedWhitespaces()', () => {
      describe('TUPLET_EXPR_CLOSE', () => {
        it('ERR RHYTHM_DOTS', () => {
          const file = '(() ...)'
          throwIllegalWhitespaceErr(file, 4, 'TUPLET_EXPR_CLOSE', 'RHYTHM_DOTS')
        })
      })

      describe('DATUM', () => {
        it('ERR RHYTHM_DOTS', () => {
          const file = '(datum ...)'
          throwIllegalWhitespaceErr(file, 7, 'DATUM', 'RHYTHM_DOTS')
        })
      })

      describe('RHYTHM_FLAGS', () => {
        it('ERR TUPLET_EXPR_OPEN', () => {
          const file = '(^^^ ())'
          throwIllegalWhitespaceErr(file, 5, 'RHYTHM_FLAGS', 'TUPLET_EXPR_OPEN')
        })

        it('ERR DATUM', () => {
          const file = '(^^^ datum)'
          throwIllegalWhitespaceErr(file, 5, 'RHYTHM_FLAGS', 'DATUM')
        })
      })
    })
  })
})

function throwTokenOrderErr (
  file, linePos, unexpectedToken, TOKEN_TYPE_A, TOKEN_TYPE_B
) {
  expect(f(file)).to.throw(
    'At 1:' + linePos + '\n' +
    'Unexpected Token: ' + unexpectedToken + '\n' +
    capitalizeFirstLetter(grammar.phrased[TOKEN_TYPE_B]) +
      ' cannot follow ' +
      grammar.phrased[TOKEN_TYPE_A] + '.'
  )
}

function throwMissingWhitespaceErr (
  file, linePos, TOKEN_TYPE_A, TOKEN_TYPE_B
) {
  expect(f(file)).to.throw(
    'At 1:' + linePos + '\n' +
    'Missing Whitespace!' + '\n' +
    'A space is required between ' +
      grammar.phrased[TOKEN_TYPE_A] + ' and ' +
      grammar.phrased[TOKEN_TYPE_B] + '.'
  )
}

function throwIllegalWhitespaceErr (
  file, linePos, TOKEN_TYPE_A, TOKEN_TYPE_B
) {
  expect(f(file)).to.throw(
    'At 1:' + linePos + '\n' +
    'Illegal Whitespace!' + '\n' +
    'A space is unallowed between ' +
      grammar.phrased[TOKEN_TYPE_A] + ' and ' +
      grammar.phrased[TOKEN_TYPE_B] + '.'
  )
}
