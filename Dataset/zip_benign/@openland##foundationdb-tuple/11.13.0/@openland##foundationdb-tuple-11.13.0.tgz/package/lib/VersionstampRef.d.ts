/// <reference types="node" />
import { Versionstamp } from './Versionstamp';
export declare class VersionstampRef {
    readonly index: Buffer;
    private _resolved;
    constructor(index: Buffer);
    get resolved(): Versionstamp;
    resolve(vt: Buffer): void;
}
