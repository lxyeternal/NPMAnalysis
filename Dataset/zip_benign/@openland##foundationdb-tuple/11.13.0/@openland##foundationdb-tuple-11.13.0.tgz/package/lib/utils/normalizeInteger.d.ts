/**
 * This function is intended to detect if number is integer that
 * can be safely encoded as integer
 *
 * @param src sorce number
 */
export declare function normalizeInteger(src: number): number;
