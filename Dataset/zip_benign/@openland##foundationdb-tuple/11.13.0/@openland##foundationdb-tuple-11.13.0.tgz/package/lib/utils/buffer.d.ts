/// <reference types="node" />
export declare class BufferReader {
    readonly bufffer: Buffer;
    offset: number;
    constructor(src: Buffer);
    get completed(): boolean;
    peek(): number;
    readByte(): number;
    readBuffer(size: number): Buffer;
    expect(byte: number): void;
    skip(count: number): void;
}
export declare class BufferWriter {
    private _storage;
    private _used;
    constructor(capacity?: number);
    writeByte(val: number): void;
    writeString(val: string): void;
    writeBuffer(val: Buffer): void;
    build(): Buffer;
    private _need;
}
