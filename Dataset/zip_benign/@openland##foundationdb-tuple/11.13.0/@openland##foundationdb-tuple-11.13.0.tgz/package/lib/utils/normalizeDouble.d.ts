export declare function normalizeDouble(src: number): number;
