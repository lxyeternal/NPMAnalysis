/// <reference types="node" />
import { Float } from './Float';
import { Versionstamp } from './Versionstamp';
import { VersionstampRef } from './VersionstampRef';
export { Float };
export { Versionstamp };
export { VersionstampRef };
export declare type TupleItem = number | Float | boolean | string | Buffer | Versionstamp | null;
export declare type TupleItemExtended = TupleItem | VersionstampRef;
/**
 * Pack tuple to a Buffer
 * @param src array of TupleItems
 */
export declare function pack(src: TupleItem[]): Buffer;
/**
 * Unpack tuple from a Buffer
 * @param src source Buffer
 */
export declare function unpack(src: Buffer): TupleItem[];
/**
 * Equality of two tuples
 * @param a first tuple
 * @param b second tuple
 */
export declare function equals(a: TupleItem[], b: TupleItem[]): boolean;
/**
 * Pack with versionstamp ref
 * @param src source tuple
 */
export declare function packWithVersionstamp(src: TupleItemExtended[]): Buffer | {
    prefix: Buffer;
    suffix: Buffer;
};
