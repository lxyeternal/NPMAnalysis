/// <reference types="node" />
export declare class Versionstamp {
    readonly value: Buffer;
    constructor(value: Buffer);
}
