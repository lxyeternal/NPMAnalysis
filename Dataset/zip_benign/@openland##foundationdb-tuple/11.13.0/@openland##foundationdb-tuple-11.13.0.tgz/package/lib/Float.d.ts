/**
 * Wrapper object for float values
 */
export declare class Float {
    /**
     * Actual value of a float tuple
     */
    readonly value: number;
    constructor(value: number);
}
