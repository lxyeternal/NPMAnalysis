/// <reference types="node" />
import { Versionstamp } from './Versionstamp';
import { Float } from './Float';
import { BufferWriter, BufferReader } from './utils/buffer';
export interface TupleCodec<T> {
    is(code: number): boolean;
    pack(src: T, writer: BufferWriter): void;
    unpack(reader: BufferReader): T;
}
export declare const NullCodec: TupleCodec<null>;
export declare const BooleanCodec: TupleCodec<boolean>;
export declare const ByteStringCodec: TupleCodec<Buffer>;
export declare const TextStringCodec: TupleCodec<string>;
export declare const VersionstampCodec: TupleCodec<Versionstamp>;
export declare const IntegerCodec: TupleCodec<number>;
export declare const DoubleCodec: TupleCodec<Float>;
