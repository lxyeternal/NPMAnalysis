/* global test, expect, beforeEach */
import { kea, resetContext, getContext } from 'kea'
import { sagaPlugin } from '../index'
import { put } from 'redux-saga/effects'

beforeEach(() => {
  resetContext({
    plugins: [sagaPlugin()],
  })
})

test('can have a kea with only a saga', () => {
  let sagaRan = false

  const sagaLogic = kea({
    start: function* () {
      sagaRan = true
    },
  })

  expect(sagaLogic._isKea).toBe(true)
  expect(getContext().plugins.activated.map((p) => p.name)).toEqual(['core', 'saga'])

  expect(sagaRan).toBe(false)

  sagaLogic.mount()

  expect(sagaRan).toBe(true)
})

test('can access defined actions', () => {
  let sagaRan = false

  const sagaLogic = kea({
    actions: () => ({
      doSomething: (input) => ({ input }),
    }),
    reducers: ({ actions }) => ({
      something: [false, {}],
    }),
    start: function* () {
      expect(this.path).toBeDefined()
      expect(this.actions).toBeDefined()
      expect(this.get).toBeDefined()
      expect(this.fetch).toBeDefined()
      expect(Object.keys(this.actions)).toEqual(['doSomething'])

      const { doSomething } = this.actionCreators
      expect(doSomething('input-text')).toEqual({ type: doSomething.toString(), payload: { input: 'input-text' } })

      sagaRan = true
    },
  })

  expect(sagaLogic._isKea).toBe(true)
  expect(getContext().plugins.activated.map((p) => p.name)).toEqual(['core', 'saga'])

  expect(sagaRan).toBe(false)

  sagaLogic.mount()

  expect(sagaRan).toBe(true)
})

test('can access values on reducer', () => {
  let sagaRan = false

  const sagaLogic = kea({
    actions: () => ({
      setString: (string) => ({ string }),
    }),
    reducers: ({ actions }) => ({
      ourString: [
        'nothing',
        {
          [actions.setString]: (state, payload) => payload.string,
        },
      ],
    }),
    start: function* () {
      const { setString } = this.actionCreators

      expect(this.get).toBeDefined()
      expect(this.fetch).toBeDefined()

      expect(yield this.get('ourString')).toBe('nothing')

      yield put(setString('something'))

      expect(yield this.get('ourString')).toBe('something')
      expect(yield this.fetch('ourString')).toEqual({ ourString: 'something' })

      sagaRan = true
    },
  })

  expect(sagaLogic._isKea).toBe(true)
  expect(getContext().plugins.activated.map((p) => p.name)).toEqual(['core', 'saga'])

  expect(sagaRan).toBe(false)

  sagaLogic.mount()

  expect(sagaLogic.workers).not.toBeDefined()

  expect(sagaRan).toBe(true)
})
