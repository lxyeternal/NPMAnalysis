import { Saga } from 'redux-saga';
import { Logic } from 'kea';
export declare function keaSaga(): any;
export declare function startSaga(index: number, saga: Saga, logic: Logic): boolean;
export declare function cancelSaga(index: number): boolean;
