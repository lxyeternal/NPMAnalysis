import { Logic, LogicBuilder } from 'kea';
import { Saga } from 'redux-saga';
export declare function saga<L extends Logic = Logic>(input: Saga): LogicBuilder<L>;
export declare function workers<L extends Logic = Logic>(input: Record<string, Saga>): LogicBuilder<L>;
export declare function takeEvery<L extends Logic = Logic>(input: Record<string, Saga | Saga[]> | ((logic: L) => Record<string, Saga | Saga[]>)): LogicBuilder<L>;
export declare function takeLatest<L extends Logic = Logic>(input: Record<string, Saga | Saga[]> | ((logic: L) => Record<string, Saga | Saga[]>)): LogicBuilder<L>;
export declare function cancelled<L extends Logic = Logic>(input: Saga): LogicBuilder<L>;
