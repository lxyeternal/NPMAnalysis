import { Plugin, VisitKeaPropertyArguments } from 'kea-typegen';
declare const _default: Plugin;
export default _default;
export declare function workers({ parsedLogic, node }: VisitKeaPropertyArguments): void;
