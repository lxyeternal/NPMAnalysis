import { KeaPlugin } from 'kea';
import { SagaPluginOptions } from './types';
export declare const sagaPlugin: ({ injectGetFetchIntoEveryLogic }?: SagaPluginOptions) => KeaPlugin;
