import { LogicWithSaga } from './types';
export declare function addGetAndFetch(logic: LogicWithSaga): void;
