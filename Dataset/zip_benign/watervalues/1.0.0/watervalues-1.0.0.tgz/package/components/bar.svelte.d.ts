import { SvelteComponentTyped } from "svelte";
import type { LeftOrRight, WaterMeasure, WaterMeasureId } from '../types';
declare const __propDef: {
    props: {
        /** The water measure id. */ measureId: WaterMeasureId | string;
        /**
           * Water measure object
           *
           * Can be omitted if measureId is set.
           */ measure?: WaterMeasure | undefined;
        /** The current water value to display. */ value?: number | undefined;
        /** Position of the label. */ labelPosition?: LeftOrRight | undefined;
        /** Show a marker on the bar that indicates the value. */ showMarker?: boolean | undefined;
        /** Color the marker according to the indication of the given value. */ colorMarker?: boolean | undefined;
    };
    events: {
        [evt: string]: CustomEvent<any>;
    };
    slots: {};
};
export declare type BarProps = typeof __propDef.props;
export declare type BarEvents = typeof __propDef.events;
export declare type BarSlots = typeof __propDef.slots;
export default class Bar extends SvelteComponentTyped<BarProps, BarEvents, BarSlots> {
}
export {};
