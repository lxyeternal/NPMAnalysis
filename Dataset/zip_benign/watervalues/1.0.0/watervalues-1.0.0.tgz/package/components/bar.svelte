<script>import { calculatePercentage, getIndicationFromValue } from '../calc';
import { generateCssGradient } from '../css';
import measures from '../measures';
import { colors, darkenIfMandatory } from '../color';
/** The water measure id. */
export let measureId;
/**
 * Water measure object
 *
 * Can be omitted if measureId is set.
 */
// @ts-ignore
export let measure = measureId && measures[measureId];
/** The current water value to display. */
export let value = undefined;
/** Position of the label. */
export let labelPosition = 'left';
/** Show a marker on the bar that indicates the value. */
export let showMarker = true;
/** Color the marker according to the indication of the given value. */
export let colorMarker = false;
$: if (!measureId && !measure)
    console.warn('Water value bar: at least one of `measureId` and `measure` must be set.');
$: labelColor = ((value || value === 0) && colorMarker
    ? darkenIfMandatory(colors[getIndicationFromValue(measure, value)])
    : undefined);
</script>

<div class="watervaluebar">
  {#if value}
    <div
      class="label {labelPosition}"
      style:color={labelColor}
    >{value}</div>
  {/if}

  <div
    class="bar"
    style:background={generateCssGradient(measures[measureId])}
  >
    {#if showMarker && value}
      <div
        class="marker"
        style:left="{calculatePercentage(measures[measureId], value)}%"
      ></div>
    {/if}
  </div>
</div>

<style src="./bar.scss">.watervaluebar {
  display: flex;
  width: 100%;
  gap: 5px;
}
.watervaluebar .label {
  line-height: 1;
  min-width: 2rem;
}
.watervaluebar .label.left {
  order: 1;
}
.watervaluebar .label.right {
  order: 3;
}
.watervaluebar .bar {
  order: 2;
  flex: 1 0;
  min-height: 1rem;
  overflow: hidden;
}
.watervaluebar .bar .marker {
  background-color: magenta;
  position: relative;
  transition: left 0.3s;
}
.watervaluebar .bar .marker::before {
  content: "";
  background-image: url('data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 257 223"%3E%3Cpath fill-rule="evenodd" d="M128.5 223 0 0h257Z"/%3E%3C/svg%3E');
  background-repeat: no-repeat;
  background-size: contain;
  width: 0.7rem;
  height: 0.7rem;
  position: absolute;
}</style>
