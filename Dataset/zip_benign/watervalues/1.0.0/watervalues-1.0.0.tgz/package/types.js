/** Color indication, from best to worst */
export var Indication;
(function (Indication) {
    Indication[Indication["Green"] = 0] = "Green";
    Indication[Indication["Yellow"] = 1] = "Yellow";
    Indication[Indication["Orange"] = 2] = "Orange";
    Indication[Indication["Red"] = 3] = "Red";
})(Indication || (Indication = {}));
;
;
