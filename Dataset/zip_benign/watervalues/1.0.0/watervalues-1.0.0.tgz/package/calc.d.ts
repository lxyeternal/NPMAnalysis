import type { Indication, WaterMeasure } from './types.js';
/**
 * Get the minimum and maximum from a {@link WaterMeasure}
 * @param measure Water measure to get the min and max values from
 * @returns Object with `min` and `max`
 *
 * @example
 * ```js
 * measureMinMax(values.gh);
 * //=> { min: 4, max: 15 }
 * ```
 */
export declare function measureMinMax(measure: WaterMeasure): {
    min: number;
    max: number;
};
/**
 * Convert a value to percentage
 * @param measure Water measure
 * @param value Water value (e.g. `7.4`)
 * @returns `val` in percentage format from 0 through 100
 *
 * @example
 * ```js
 * calculatePercentage(values.ph, 6.9);
 * //=> 41.66666666666669
 * ```
 */
export declare function calculatePercentage(measure: WaterMeasure, value: number): number;
/**
 * Get the {@link Indication} from a {@link WaterMeasure} and a value.
 * @param measure Water measure object
 * @param value Value to get indication for
 * @returns Indication
 */
export declare function getIndicationFromValue(measure: WaterMeasure, value: number): Indication;
