import { Indication } from './types.js';
/** {@link Indication}s with CSS color values */
export declare const colors: Record<Indication, string>;
export declare function darkenIfMandatory(color: string): string;
