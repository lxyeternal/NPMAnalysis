import { type WaterMeasure, type WaterMeasureId } from './types.js';
/** Water values */
declare const measures: Record<WaterMeasureId | string, WaterMeasure>;
export default measures;
