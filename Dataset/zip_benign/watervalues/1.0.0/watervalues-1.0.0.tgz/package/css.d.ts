import type { WaterMeasure } from './types.js';
/**
 * Build the CSS gradient code for the given water type
 * @param measure {@link WaterMeasure}
 * @returns CSS gradient code
 *
 * @example
 * ```js
 * generateCssGradient(values.no2);
 * //=> linear-gradient(90deg, green 0%, yellow 5%, red 10%, red 100%)
 * ```
 */
export declare function generateCssGradient(measure: WaterMeasure): string;
