export { calculatePercentage, getIndicationFromValue } from './calc.js';
export { colors, darkenIfMandatory } from './color.js';
export { generateCssGradient } from './css.js';
export { default as measures } from './measures.js';
export { Indication } from './types.js';
