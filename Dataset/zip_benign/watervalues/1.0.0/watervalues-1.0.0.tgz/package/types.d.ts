export declare type WaterMeasureId = 'no2' | 'no3' | 'gh' | 'kh' | 'ph' | 'chlorine';
export declare type LeftOrRight = 'left' | 'right';
/** Color indication, from best to worst */
export declare enum Indication {
    Green = 0,
    Yellow = 1,
    Orange = 2,
    Red = 3
}
/** A water value measure */
export interface WaterMeasure {
    /** Localised name of the water measure */
    name: {
        nl: string;
        en: string;
    };
    /** Range */
    range: {
        /** Water value */
        value: number;
        /** Indication */
        indication: Indication;
    }[];
}
