## weichiachang    ![openSource](https://badges.frapsoft.com/os/v1/open-source.svg?v=102)

<p align="center">
  <a target="_blank" href="https://github.com/WeiChiaChang/weichiachang">
    <img alt="weichiachang" src="https://i.imgur.com/v6acUuw.gif"  width="250">
  </a>
</p>
<p align=center>
  <a target="_blank" href="https://npmjs.org/package/tw-forex" title="NPM version"><img src="https://img.shields.io/npm/v/weichiachang.svg"></a>
  <a target="_blank" href="http://nodejs.org/download/" title="Node version"><img src="https://img.shields.io/badge/node.js-%3E=_7.0-green.svg"></a>
  <a target="_blank" href="https://opensource.org/licenses/MIT" title="License: MIT"><img src="https://img.shields.io/badge/License-MIT-blue.svg"></a>
  <a target="_blank" href="http://makeapullrequest.com" title="PRs Welcome"><img src="https://img.shields.io/badge/PRs-welcome-brightgreen.svg"></a>
</p>

> WeiChiaChang CLI

## Install
```shell
$ npm i weichiachang -g
```

<img src="overview.png" width="800">

## Built with

This project's a personal practice mostly <del>copied</del> from [sindresorhus/sindresorhus](https://github.com/sindresorhus/sindresorhus).

## 💉 Donate

<a href="https://www.buymeacoffee.com/dKPhu3g" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a>

## License
MIT © [WeiChiaChang](https://github.com/WeiChiaChang)


