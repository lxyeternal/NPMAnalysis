'use strict';
const path = require('path');
const {h, Text} = require('ink');
const SelectInput = require('ink-select-input');
const opn = require('opn');
const terminalImage = require('terminal-image');

const open = url => opn(url, {wait: false});

const handleSelect = item => {
	if (item.url) {
		open(item.url);
	}

	if (item.action) {
		item.action();
	}
};

const items = [
	{
		label: 'Website',
		url: 'https://weichiachang.github.io/'
	},
	{
		label: 'Twitter',
		url: 'https://twitter.com/ioh04019'
	},
	{
		label: 'GitHub',
		url: 'https://github.com/WeiChiaChang'
	},
	{
		label: 'Blog',
		url: 'https://weichiachang.github.io/blog/'
	},
	{
		label: 'Medium',
		url: 'https://medium.com/weekly-github-digest'
	},
	{
		label: 'Contact',
		url: 'https://www.linkedin.com/in/wesley-c-23ba00104/'
	},
	{
		label: 'Ask Me Anything',
		url: 'https://github.com/WeiChiaChang/ama'
	},
	{
		label: 'Donate my open source work',
		url: 'https://www.buymeacoffee.com/dKPhu3g'
	},
	{
		label: 'Goooooood Weeeeeed!',
		async action() {
			console.log(await terminalImage.file(path.join(__dirname, 'woow.png')));
			console.log(await terminalImage.file(path.join(__dirname, 'taiwan-kuma.gif')));
			console.log(await terminalImage.file(path.join(__dirname, 'close.gif')));
			console.log(await terminalImage.file(path.join(__dirname, 'fromZeroToNone.png')));
		}
	},
	// TODO: Add separator item here when https://github.com/vadimdemedes/ink-select-input/issues/4 is done
	{
		label: 'Quit',
		action() {
			process.exit(); // eslint-disable-line unicorn/no-process-exit
		}
	}
];

module.exports = () => (
	<div>
		<br/>
		<div>
			<Text>Based on the planet Earth.</Text>
		</div>
		<br/>
		<SelectInput items={items} onSelect={handleSelect}/>
	</div>
);
