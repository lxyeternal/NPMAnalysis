export default class RangeFinder {
    /**
     * Constructor
     *
     * @param {number} min
     * @param {number} max
     */
    constructor(min, max, ease = x => x) {
        this.min = min;
        this.max = max;
        this._ease = ease;
    }

    /**
     * Get percent
     *
     * @param {number} value
     * @returns {number}
     */
    percent(value) {
        return RangeFinder.percent(value, this.min, this.max);
    }

    /**
     * Get value
     *
     * @param {number} percent
     * @returns {number}
     */
    value(percent) {
        return RangeFinder.value(percent, this.min, this.max);
    }

    /**
     * Ease
     *
     * @param {number} percent
     * @returns {number}
     */
    ease(percent) {
        return RangeFinder.ease(percent, this._ease);
    }

    /**
     * Get percent
     *
     * @param {number} value
     * @param {number} min
     * @param {number} max
     * @returns {number}
     */
    static percent(value, min, max) {
        return (value - min) / (max - min);
    }

    /**
     * Get percent
     *
     * @param {number} percent
     * @param {number} min
     * @param {number} max
     * @returns {number}
     */
    static value(percent, min, max) {
        return ((max - min) * percent) + min;
    }

    /**
     * Ease
     *
     * @param {number} percent
     * @param {function} ease
     */
    static ease(percent, ease) {
        return ease(percent);
    }

    /**
     * Power in
     *
     * @param {number} pow
     * @returns {function(*=): number}
     */
    static powIn(pow) {
        return function(t) {
            return Math.pow(t,pow);
        };
    };

    /**
     * Power out
     *
     * @param {number} pow
     * @returns {function(*): *}
     */
    static powOut(pow) {
        return function(t) {
            return 1-Math.pow(1-t,pow);
        };
    };

    /**
     * Power in and out
     *
     * @param {number} pow
     * @returns {function(*=): *}
     */
    static powInOut(pow) {
        return function(t) {
            if ((t*=2)<1) return 0.5*Math.pow(t,pow);
            return 1-0.5*Math.abs(Math.pow(2-t,pow));
        };
    };
}