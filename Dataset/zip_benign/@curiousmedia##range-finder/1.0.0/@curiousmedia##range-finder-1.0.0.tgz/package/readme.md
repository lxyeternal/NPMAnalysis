# Range Finder
Calculate the percentage or value between a range of numbers. 

## Installation
```
npm install @curiousmedia/range-finder
```

## Basic usage

### Instance
```javascript
let rf = new RangeFinder(10, 20);

// Get percent
rf.percent(15); // 0.5

// Get value
rf.value(0.5); // 15
```

### Static
```javascript
RangeFinder.percent(15, 10, 20);
```

## Easing

### Robert Penner Equation
See [easing functions](https://www.npmjs.com/package/easing-functions) NPM library.
```javascript
let rf = new RangeFinder(10, 20, Easing.Quadratic.In);
rf.value(rf.ease(0.5)); // 12.5
rf.ease(rf.percent(15)); // 0.25
```

### Configurable easing
```javascript
let rf = new RangeFinder(10, 20, RangeFinder.powIn(3));
rf.value(rf.ease(0.5)); // 11.25
rf.ease(rf.percent(15)); // 0.25
```