import resolve from '@rollup/plugin-node-resolve';
import babel from '@rollup/plugin-babel';
import { uglify } from 'rollup-plugin-uglify';

export default [
    {
        input: 'src/range-finder.js',
        output: {
            name: 'RangeFinder',
            file: 'dist/range-finder.js',
            format: 'umd'
        },
        plugins: [
            resolve(),
            babel({
                presets: [['@babel/preset-env']],
                exclude: ['node_modules/**']
            }),
            uglify()
        ]
    },
    {
        input: 'src/range-finder.js',
        output: {
            file: 'dist/range-finder.esm.js',
            format: 'es'
        },
        external: []
    }
];