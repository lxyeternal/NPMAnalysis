export const Heading = () => {
  // TODO
}