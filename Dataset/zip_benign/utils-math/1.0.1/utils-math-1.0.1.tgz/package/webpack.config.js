module.exports = {
    devtool: '#sourcemap',
    entry: {
        index: './test/tests.es6.js'
    },
    output: {
        path: __dirname,
        filename: './test/tests.js'
    }
}
