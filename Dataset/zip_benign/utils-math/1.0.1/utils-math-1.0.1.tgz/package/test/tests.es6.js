import * as mathExt from '../index';
import { expect } from 'chai';

describe('浮点运算测试', () => {
    it('加法测试', () => {
        const ret = mathExt.add(0.1, 0.2);
        const ret2 = mathExt.add(0.1, 0.02);
        const ret3 = mathExt.add(41612.84, 221.8);
        expect(ret).to.be.equal(0.3);
        expect(ret2).to.be.equal(.12);
        expect(ret3).to.be.equal(41834.64);
    });

    it('减法测试', () => {
        const ret = mathExt.sub(0.3, 0.1);
        expect(ret).to.be.equal(0.2);
    });

    it('乘法测试', () => {
        const ret = mathExt.mul(1.01, 1.3);
        expect(ret).to.be.equal(1.313);
    });

    it('除法测试', () => {
        const ret = mathExt.div(0.69, 10);
        expect(ret).to.be.equal(0.069);
    })
});
