# math-ext

四则运算扩展，解决浮点运算精度问题

# 安装

```bash
$ yarn add utils-math
```

# 使用

```javascript
import * as mathExt from 'utils-math';

// 加
mathExt.add(0.1, 0.2) === 0.3

// 减
mathExt.sub(0.3, 0.1) === 0.2

// 乘
mathExt.mul(1.01, 1.3) === 1.313

// 除
mathExt.div(0.69, 10) === 0.069

```
