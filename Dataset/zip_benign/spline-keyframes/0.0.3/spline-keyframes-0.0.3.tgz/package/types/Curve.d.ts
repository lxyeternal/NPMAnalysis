import { Keyframe, KeyframeData } from './Keyframe';
import { Segment } from './Segment';
export declare type CurveOptions = {
    tension?: number;
    samples?: number;
};
export declare class Curve {
    tension: number;
    samples: number;
    frames: Keyframe[];
    segments: Segment[];
    points: Array<{
        time: number;
        value: number;
    }>;
    _dirty: boolean;
    constructor(frames: KeyframeData[], opts?: CurveOptions);
    at(time: number): number;
}
