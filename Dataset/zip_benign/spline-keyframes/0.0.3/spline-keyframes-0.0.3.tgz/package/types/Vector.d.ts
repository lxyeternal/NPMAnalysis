export declare class Vector {
    time: number;
    value: number;
    constructor(time: number, value: number);
    add(vector: Vector): Vector;
    magnitude(): number;
    scale(num: number): Vector;
    subtract(vector: Vector): Vector;
}
