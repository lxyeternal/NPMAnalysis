import { Keyframe } from './Keyframe';
import { Vector } from './Vector';
export declare class Segment {
    start: number;
    end: number;
    duration: number;
    p0: Vector;
    p1: Vector;
    p2: Vector;
    p3: Vector;
    p0_p1: Vector;
    p1_p2: Vector;
    p2_p3: Vector;
    magnitude: number;
    constructor(p0: Keyframe, p3: Keyframe);
    points(n: number, points: Array<{
        time: number;
        value: number;
    }>): void;
}
