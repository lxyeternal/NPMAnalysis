import { Curve } from './Curve';
import { Vector } from './Vector';
export declare type KeyframeData = {
    time: number;
    value: number;
    tension?: number;
};
export declare class Keyframe {
    curve: Curve;
    time: number;
    value: number;
    tension: number;
    previous: Keyframe;
    next: Keyframe;
    leftControlPoint: Vector;
    rightControlPoint: Vector;
    line: Vector;
    constructor(curve: Curve, data: KeyframeData);
    _link(previous: Keyframe, next: Keyframe): void;
    remove(): void;
}
