(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('d3'), require('@angular/core')) :
    typeof define === 'function' && define.amd ? define('ng6-o2-chart', ['exports', 'd3', '@angular/core'], factory) :
    (factory((global['ng6-o2-chart'] = {}),null,global.ng.core));
}(this, (function (exports,d3,core) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var /** @type {?} */ LINE_CHART_TYPE_NAME = 'line';
    var /** @type {?} */ BAR_CHART_TYPE_NAME = 'bar';
    var /** @type {?} */ PIE_CHART_TYPE_NAME = 'pie';
    var /** @type {?} */ SCATTER_PLOT_CHART_TYPE_NAME = 'scatterPlot';
    var /** @type {?} */ HISTOGRAM_CHART_TYPE_NAME = 'histogram';
    var /** @type {?} */ STACK_BAR_CHART_TYPE_NAME = 'stackBar';
    var /** @type {?} */ GEO_MAP_CHART_TYPE_NAME = 'geoMap';
    var /** @type {?} */ GEO_ORTHOGRAPHIC_CHART_TYPE_NAME = 'geoOrthographic';
    var /** @type {?} */ TREE_MAP_CHART_TYPE_NAME = 'treeMap';
    var /** @type {?} */ PACK_LAYOUT_CHART_TYPE_NAME = 'packLayout';
    var /** @type {?} */ CHOROPLETH_CHART_TYPE_NAME = 'choropleth';
    var /** @type {?} */ TREE_CHART_TYPE_NAME = 'tree';
    var /** @type {?} */ SANKEY_CHART_TYPE_NAME = 'sankey';
    var /** @type {?} */ FORCE_CHART_TYPE_NAME = 'force';

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var O2Common = (function () {
        function O2Common(svgContainer, configData, autoMaxX, autoMaxY, svgWidth, svgHeight) {
            this.svgContainer = svgContainer;
            this.configData = configData;
            this.autoMaxX = autoMaxX;
            this.autoMaxY = autoMaxY;
            this.svgWidth = svgWidth;
            this.svgHeight = svgHeight;
        }
        Object.defineProperty(O2Common.prototype, "axisClassName", {
            get: /**
             * @return {?}
             */ function () {
                return this.configData.className.axis;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "lineClassName", {
            get: /**
             * @return {?}
             */ function () {
                return this.configData.className.line;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXBorderLineClassName", {
            get: /**
             * @return {?}
             */ function () {
                return this.configData.className.axisXBorder;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "maxXValue", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _maxX = this.autoMaxX;
                if (!this.configData.maxValue.auto) {
                    _maxX = this.configData.maxValue.x;
                }
                return _maxX;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "maxYValue", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _maxY = this.autoMaxY;
                if (!this.configData.maxValue.auto) {
                    _maxY = this.configData.maxValue.y;
                }
                return _maxY;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphInitXPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _intX = this.configData.margin.left;
                if (this.configData.legend.display && this.configData.legend.position !== 'right') {
                    _intX = this.configData.margin.left
                        + this.configData.legend.totalWidth;
                }
                return _intX;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphInitYPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _intY = this.configData.margin.top
                    + this.configData.title.height;
                return _intY;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphYScale", {
            get: /**
             * @return {?}
             */ function () {
                return this.graphHeight / this.maxYValue;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphXScale", {
            get: /**
             * @return {?}
             */ function () {
                return this.graphWidth / this.maxXValue;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphWidth", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _margin = this.configData.margin.left
                    + this.configData.margin.right;
                if (this.configData.legend.display) {
                    _margin += this.configData.legend.totalWidth;
                }
                return this.svgWidth - _margin;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphHeight", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _h = this.svgHeight
                    - this.configData.title.height
                    - this.configData.margin.top
                    - this.configData.margin.bottom;
                return _h;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphCenterPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _xyArray = new Array();
                var /** @type {?} */ _x = this.configData.margin.left
                    + this.graphWidth / 2;
                var /** @type {?} */ _y = this.configData.margin.top
                    + this.configData.title.height
                    + this.graphHeight / 2;
                _xyArray.push(_x);
                _xyArray.push(_y);
                return _xyArray;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphCenterTranslatePos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.configData.margin.left
                    + this.graphWidth / 2;
                var /** @type {?} */ _y = this.configData.margin.top
                    + this.configData.title.height
                    + this.graphHeight / 2;
                return 'translate(' + String(_x) + ', ' + String(_y) + ')';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphInitTranslatePos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.graphInitXPos;
                var /** @type {?} */ _y = this.graphInitYPos;
                return 'translate(' + String(_x) + ', ' + String(_y) + ')';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXLabelInitXPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.configData.margin.left
                    + this.configData.axis.xLabel.leftMargin;
                return _x;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXLabelInitYPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _y = this.svgHeight
                    - this.configData.axis.xLabel.bottomMargin;
                return _y;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisTranslatePos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.configData.margin.left;
                var /** @type {?} */ _y = this.configData.margin.top
                    + this.configData.title.height;
                return 'translate(' + String(_x) + ', ' + String(_y) + ')';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXBorderLineWidth", {
            get: /**
             * @return {?}
             */ function () {
                return this.configData.axis.borderLineWidth;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisYBorderHeight", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _margin = this.configData.margin.top
                    + this.configData.margin.bottom
                    + this.configData.title.height;
                return this.svgHeight - _margin;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXBorderWidth", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _margin = this.configData.margin.left
                    + this.configData.margin.right;
                if (this.configData.legend.display) {
                    _margin += this.configData.legend.totalWidth;
                }
                return this.svgWidth - _margin;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisYOrient", {
            get: /**
             * @return {?}
             */ function () {
                return 'left';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXOrient", {
            get: /**
             * @return {?}
             */ function () {
                return 'bottom';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXBorderTranslatePos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ sYpos = String(this.svgHeight - this.configData.margin.bottom);
                return 'translate(' + this.configData.margin.left + ', ' + sYpos + ')';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "innerRadiusPercent", {
            get: /**
             * @return {?}
             */ function () {
                return this.configData.pie.innerRadius.percent;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "innerRadiusTitle", {
            get: /**
             * @return {?}
             */ function () {
                return this.configData.pie.innerRadius.title;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "innerRadiusTitleTranslatePos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.configData.margin.left
                    + this.graphWidth / 2;
                var /** @type {?} */ _y = this.configData.margin.top
                    + this.configData.title.height
                    + this.graphHeight / 2
                    + 5;
                return 'translate(' + String(_x) + ', ' + String(_y) + ')';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "legendInitXPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.configData.margin.left
                    + this.graphWidth
                    + this.configData.legend.initXPos;
                if (this.configData.legend.position !== 'right') {
                    _x = this.configData.margin.left
                        + this.configData.legend.initXPos;
                }
                return _x;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "legendInitYPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _y = this.configData.margin.top
                    + this.configData.title.height
                    + this.configData.legend.initYPos;
                return _y;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "gridYStep", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _maxY = Math.ceil(this.maxYValue / 100) * 10;
                var /** @type {?} */ _lineNum = 10;
                var /** @type {?} */ _step = Math.ceil(_maxY / _lineNum) * _lineNum;
                return _step;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "gridXStep", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _maxX = Math.ceil(this.maxXValue / 100) * 10;
                var /** @type {?} */ _lineNum = 10;
                var /** @type {?} */ _step = Math.ceil(_maxX / _lineNum) * _lineNum;
                return _step;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "titleInitXPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.configData.margin.left
                    + (this.graphWidth + this.configData.legend.totalWidth) / 2
                    + this.configData.title.leftMargin;
                return _x;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "titleInitYPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _y = this.configData.margin.top
                    + this.configData.title.height
                    - this.configData.title.bottomMargin;
                return _y;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "defaultColorFunc", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _color;
                if (this.configData.color.auto) {
                    if (this.configData.color.defaultColorNumber === '20') {
                        _color = d3.scaleOrdinal(d3.schemeCategory20);
                    }
                    else {
                        _color = d3.scaleOrdinal(d3.schemeCategory10);
                    }
                }
                return _color;
            },
            enumerable: true,
            configurable: true
        });
        return O2Common;
    }());
    var O2LegendData = (function () {
        function O2LegendData(title, color) {
            this.title = title;
            this.color = color;
        }
        return O2LegendData;
    }());
    var O2ScatterPlotData = (function () {
        function O2ScatterPlotData(x, y, r) {
            this.x = x;
            this.y = y;
            this.r = r;
        }
        return O2ScatterPlotData;
    }());
    var O2IdValueData = (function () {
        function O2IdValueData(id, value) {
            this.id = id;
            this.value = value;
        }
        return O2IdValueData;
    }());
    // export class O2KeyValueData {
    //     constructor(
    //        public key: string,
    // 	   public value: number
    //        ) { }
    // }
    // export class O2DateKVArrayData {
    //     constructor(
    //        public date: Date,
    // 	   public kvArray: Array<O2KeyValueData>
    //        ) { }
    // }
    // export class O2DateStKVArrayData {
    //     constructor(
    //        public dateSt: string,
    // 	   public kvArray: Array<O2KeyValueData>
    //        ) { }
    // }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Ng6O2ChartComponent = (function () {
        function Ng6O2ChartComponent(elementRef) {
            console.log('el:HTMLElement-------------------');
            var /** @type {?} */ el = elementRef.nativeElement;
            this.root = d3.select(el);
        }
        /**
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
            };
        /**
         * @param {?} changes
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
            function (changes) {
                var /** @type {?} */ svgWidth = parseInt(this.svgWidth, 10);
                var /** @type {?} */ svgHeight = parseInt(this.svgHeight, 10);
                var /** @type {?} */ dataSet = this.graphData;
                var /** @type {?} */ configData = this.configData;
                var /** @type {?} */ chartType = this.chartType;
                var /** @type {?} */ svgContainer = this.root.append('svg')
                    .attr('width', svgWidth)
                    .attr('height', svgHeight);
                console.log(chartType);
                switch (chartType) {
                    case LINE_CHART_TYPE_NAME:
                        this.buildLine(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case BAR_CHART_TYPE_NAME:
                        this.buildBar(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case PIE_CHART_TYPE_NAME:
                        this.buildPie(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case SCATTER_PLOT_CHART_TYPE_NAME:
                        this.buildScatterPlot(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case HISTOGRAM_CHART_TYPE_NAME:
                        this.buildHistogram(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case STACK_BAR_CHART_TYPE_NAME:
                        this.buildStackBar(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case GEO_MAP_CHART_TYPE_NAME:
                        this.buildGeoMap(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case GEO_ORTHOGRAPHIC_CHART_TYPE_NAME:
                        this.buildGeoOrthographic(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case TREE_CHART_TYPE_NAME:
                        this.buildTree(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case PACK_LAYOUT_CHART_TYPE_NAME:
                        this.buildPackLayout(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case CHOROPLETH_CHART_TYPE_NAME:
                        this.buildChoropleth(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case FORCE_CHART_TYPE_NAME:
                        this.buildForce(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case TREE_MAP_CHART_TYPE_NAME:
                        //  this.buildTreeMap(svgContainer,configData, dataSet,svgWidth,svgHeight );
                        break;
                    case SANKEY_CHART_TYPE_NAME:
                        //  this.buildSankey(svgContainer,configData, dataSet,svgWidth,svgHeight );
                        break;
                    default:
                        break;
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildHistogram = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in buildHistogram-------------------');
                var /** @type {?} */ dataSet = dataSetJson.data;
                var /** @type {?} */ _binNumber = dataSetJson.bins.length - 1;
                var /** @type {?} */ _maxY = 300; // dummy number
                var /** @type {?} */ _maxX = dataSetJson.range[1];
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _graphWidth = cdt.graphWidth;
                var /** @type {?} */ _graphHeight = cdt.graphHeight;
                var /** @type {?} */ _graphInitX = cdt.graphInitXPos;
                var /** @type {?} */ _graphInitY = cdt.graphInitYPos;
                var /** @type {?} */ _titleDisplay = configData.title.display;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                var /** @type {?} */ _gridYDisplay = configData.grid.y.display;
                var /** @type {?} */ _marginLeft = configData.margin.left;
                var /** @type {?} */ _marginTop = configData.margin.top;
                var /** @type {?} */ _className = configData.className.histogramBar;
                var /** @type {?} */ _dataSet = new Array();
                for (var /** @type {?} */ i in dataSet) {
                    if (dataSet.hasOwnProperty(i)) {
                        var /** @type {?} */ _num = dataSet[i] / _maxX;
                        _dataSet.push(_num);
                    }
                }
                var /** @type {?} */ formatCount = d3.format(',.0f');
                var /** @type {?} */ _histgramContainer = svgContainer
                    .append('g')
                    .attr('transform', 'translate(' + _graphInitX + ',' + _graphInitY + ')');
                var /** @type {?} */ _xScale = d3.scaleLinear()
                    .rangeRound([0, _graphWidth]);
                var /** @type {?} */ bins = d3.histogram()
                    .domain([0, 1])
                    .thresholds(_xScale.ticks(_binNumber))(_dataSet);
                var /** @type {?} */ _yScale = d3.scaleLinear()
                    .domain([0, d3.max(bins, function (d) {
                        return d.length;
                    })])
                    .range([_graphHeight, 0]);
                var /** @type {?} */ bar = _histgramContainer
                    .selectAll('.bar')
                    .data(bins)
                    .enter()
                    .append('g')
                    .attr('class', _className)
                    .attr('transform', function (d) {
                    return 'translate(' + _xScale(d.x0) + ',' + _yScale(d.length) + ')';
                });
                if (_animation) {
                    bar.append('rect')
                        .attr('x', 1)
                        .attr('width', _xScale(bins[0].x1) - _xScale(bins[0].x0) - 1)
                        .attr('height', 0)
                        .transition()
                        .duration(_animationDuration)
                        .attr('height', function (d) {
                        return _graphHeight - _yScale(d.length);
                    });
                }
                else {
                    bar.append('rect')
                        .attr('x', 1)
                        .attr('width', _xScale(bins[0].x1) - _xScale(bins[0].x0) - 1)
                        .attr('height', function (d) {
                        return _graphHeight - _yScale(d.length);
                    });
                }
                bar.append('text')
                    .attr('dy', '.75em')
                    .attr('y', 6)
                    .attr('x', (_xScale(bins[0].x1) - _xScale(bins[0].x0)) / 2)
                    .attr('text-anchor', 'middle')
                    .text(function (d) {
                    return formatCount(d.length);
                });
                // ---CALL buildTitle-----------------
                if (_titleDisplay) {
                    this.drawTitle(cdt);
                }
                // ------------------------------------
                // ---CALL buildAxis-----------------
                this.buildYAxis(cdt);
                this.buildXAxis(cdt);
                if (_gridYDisplay) {
                    this.drawYGrid(cdt);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildForce = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('In  buildFoce----------------');
                var /** @type {?} */ _maxX = 100;
                var /** @type {?} */ _maxY = 100;
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _color = cdt.defaultColorFunc;
                var /** @type {?} */ _graphHeight = cdt.graphHeight;
                var /** @type {?} */ _graphWidth = cdt.graphWidth;
                var /** @type {?} */ _marginLeft = configData.margin.left;
                var /** @type {?} */ _marginTop = configData.margin.top;
                var /** @type {?} */ simulation = d3.forceSimulation()
                    .force('link', d3.forceLink().id(function (d) {
                    return d.id;
                }))
                    .force('charge', d3.forceManyBody())
                    .force('center', d3.forceCenter(_graphWidth / 2, _graphHeight / 2));
                var /** @type {?} */ _forceContainer = svgContainer
                    .append('g')
                    .attr('transform', 'translate(' + _marginLeft + ',' + _marginTop + ')');
                var /** @type {?} */ link = _forceContainer.append('g')
                    .attr('class', 'force-links')
                    .selectAll('line')
                    .data(dataSetJson.links)
                    .enter()
                    .append('line')
                    .attr('stroke-width', function (d) {
                    return Math.sqrt(d.value);
                });
                var /** @type {?} */ node = _forceContainer.append('g')
                    .attr('class', 'nodes')
                    .selectAll('circle')
                    .data(dataSetJson.nodes)
                    .enter()
                    .append('circle')
                    .attr('r', 5)
                    .attr('fill', function (d) {
                    return _color(d.group);
                })
                    .call(d3.drag()
                    .on('start', dragstarted)
                    .on('drag', dragged)
                    .on('end', dragended));
                node.append('title')
                    .text(function (d) {
                    return d.id;
                });
                simulation
                    .nodes(dataSetJson.nodes)
                    .on('tick', ticked);
                var /** @type {?} */ _forceLink = simulation.force('link');
                _forceLink.links(dataSetJson.links);
                /**
                 * @return {?}
                 */
                function ticked() {
                    link
                        .attr('x1', function (d) {
                        return d.source.x;
                    })
                        .attr('y1', function (d) {
                        return d.source.y;
                    })
                        .attr('x2', function (d) {
                        return d.target.x;
                    })
                        .attr('y2', function (d) {
                        return d.target.y;
                    });
                    node
                        .attr('cx', function (d) {
                        return d.x;
                    })
                        .attr('cy', function (d) {
                        return d.y;
                    });
                }
                /**
                 * @param {?} d
                 * @return {?}
                 */
                function dragstarted(d) {
                    if (!d3.event.active) {
                        simulation.alphaTarget(0.3).restart();
                    }
                    d.fx = d.x;
                    d.fy = d.y;
                }
                /**
                 * @param {?} d
                 * @return {?}
                 */
                function dragged(d) {
                    d.fx = d3.event.x;
                    d.fy = d3.event.y;
                }
                /**
                 * @param {?} d
                 * @return {?}
                 */
                function dragended(d) {
                    if (!d3.event.active) {
                        simulation.alphaTarget(0);
                    }
                    d.fx = null;
                    d.fy = null;
                }
                //  ------------------------------------
                //  ---CALL buildLegend-----------------
                var /** @type {?} */ _legendDataSet = new Array();
                for (var /** @type {?} */ i in dataSetJson.groups) {
                    if (dataSetJson.groups.hasOwnProperty(i)) {
                        var /** @type {?} */ _id = dataSetJson.groups[i].id;
                        _legendDataSet.push(new O2LegendData(dataSetJson.groups[i].name, _color(_id)));
                    }
                }
                this.buildLegend(cdt, _legendDataSet);
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildChoropleth = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in buildChoropleth -------------------');
                var /** @type {?} */ _maxX = 100; // any value
                var /** @type {?} */ _maxY = 100; // any value
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _graphCenterPos = cdt.graphCenterPos;
                var /** @type {?} */ _titleDisplay = configData.title.display;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ _focusColor = configData.color.focusColor;
                var /** @type {?} */ _scale = dataSetJson.map.scale;
                var /** @type {?} */ _targetName = dataSetJson.map.targetName;
                var /** @type {?} */ _keyDataName = dataSetJson.map.keyDataName;
                var /** @type {?} */ _keyName = 'data.' + _keyDataName;
                var /** @type {?} */ _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
                var /** @type {?} */ _startColor = dataSetJson.map.startColor;
                var /** @type {?} */ _endColor = dataSetJson.map.endColor;
                var /** @type {?} */ _colorNum = dataSetJson.map.colorNumber;
                var /** @type {?} */ _center = dataSetJson.map.center;
                var /** @type {?} */ _targetPropertyName = dataSetJson.map.targetPropertyName;
                var /** @type {?} */ _targetProperty = 'd.' + _targetPropertyName;
                var /** @type {?} */ color = d3.interpolateHsl(_startColor, _endColor);
                var /** @type {?} */ _max = dataSetJson.data[0].value;
                var /** @type {?} */ _min = dataSetJson.data[0].value;
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        if (_max < dataSetJson.data[i].value) {
                            _max = dataSetJson.data[i].value;
                        }
                        if (_min > dataSetJson.data[i].value) {
                            _min = dataSetJson.data[i].value;
                        }
                    }
                }
                var /** @type {?} */ _range = _max - _min;
                var /** @type {?} */ _step = _range / (_colorNum - 1);
                var /** @type {?} */ _findColorById = function (id) {
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            if (id === dataSetJson.data[i].id) {
                                var /** @type {?} */ _value = dataSetJson.data[i].value;
                                var /** @type {?} */ _rate = Math.ceil((_value - _min) / _step);
                                return color(_rate / _max);
                            }
                        }
                    }
                };
                var /** @type {?} */ path = d3.geoPath()
                    .projection(d3.geoMercator()
                    .center(_center)
                    .scale(_scale)
                    .translate(_graphCenterPos));
                d3.json(_geoMapDataUrl, function (error, data) {
                    svgContainer.selectAll('path')
                        .data(eval(_keyName))
                        .enter()
                        .append('path')
                        .attr('d', path)
                        .style('fill', function (d, i) {
                        var /** @type {?} */ _cl = _findColorById(eval(_targetProperty));
                        return _cl;
                    });
                });
                // ------------------------------------
                // ---CALL buildTitle-----------------
                if (_titleDisplay) {
                    this.drawTitle(cdt);
                }
                //  ------------------------------------
                //  ---CALL buildLegend-----------------
                if (_legendDisplay) {
                    var /** @type {?} */ _legendDataSet = new Array();
                    for (var /** @type {?} */ i = 0; i < _colorNum; i++) {
                        var /** @type {?} */ _label = String(_min + (i * _step)) + ' --';
                        _legendDataSet.push(new O2LegendData(_label, color(i / _max)));
                    }
                    this.buildLegend(cdt, _legendDataSet);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildPackLayout = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in PackLayout------------------');
                var /** @type {?} */ _packlayoutClass = configData.className.packlayout;
                var /** @type {?} */ _packlayoutLabelClass = configData.className.packlayoutLabel;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                var /** @type {?} */ color = d3.scaleOrdinal(d3.schemeCategory10);
                //  const color = d3.scale.category10();
                var /** @type {?} */ bubble = d3.pack()
                    .size([svgWidth, svgHeight]);
                var /** @type {?} */ nodes0 = d3.hierarchy(dataSetJson);
                var /** @type {?} */ pack = svgContainer.selectAll('g')
                    .data(bubble(nodes0).descendants())
                    .enter()
                    .append('g')
                    .attr('transform', function (d, i) {
                    return 'translate(' + d.x + ',' + d.y + ')';
                });
                var /** @type {?} */ _circle = pack.append('circle');
                if (_animation) {
                    _circle.attr('r', 0)
                        .transition()
                        .duration(function (d, i) {
                        return d.depth * _animationDuration + 500;
                    })
                        .attr('r', function (d) {
                        return d.r;
                    })
                        .style('fill', function (d, i) {
                        return color(i);
                    });
                }
                else {
                    _circle.attr('r', function (d) {
                        return d.r;
                    })
                        .style('fill', function (d, i) {
                        return color(i);
                    });
                }
                var /** @type {?} */ _text = pack.append('text')
                    .attr('class', _packlayoutLabelClass)
                    .text(function (d, i) {
                    if (d.depth === 1) {
                        return d.data.name;
                    }
                    return null;
                });
                if (_animation) {
                    _text.style('opacity', 0)
                        .transition()
                        .duration(_animationDuration)
                        .style('opacity', 1.0);
                }
                else {
                    _text.style('opacity', 1.0);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildTree = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('In  buildTree----------------');
                var /** @type {?} */ _maxX = 0;
                var /** @type {?} */ _maxY = 0;
                _maxY = 100;
                _maxX = 100;
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _graphHeight = cdt.graphHeight;
                var /** @type {?} */ _graphWidth = cdt.graphWidth;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                var /** @type {?} */ _treemapClass = configData.className.treemap;
                var /** @type {?} */ _treemapLabelClass = configData.className.treemapLabel;
                var /** @type {?} */ _marginLeft = configData.margin.left;
                var /** @type {?} */ _marginTop = configData.margin.top;
                var /** @type {?} */ tree = d3.tree()
                    .size([_graphWidth, _graphHeight]);
                var /** @type {?} */ nodes0 = d3.hierarchy(dataSetJson);
                var /** @type {?} */ nodes = tree(nodes0);
                var /** @type {?} */ _treeContainer = svgContainer
                    .append('g')
                    .attr('transform', 'translate(' + _marginLeft + ',' + _marginTop + ')');
                var /** @type {?} */ link = _treeContainer
                    .selectAll('.link')
                    .data(nodes.descendants().slice(1))
                    .enter()
                    .append('path')
                    .attr('class', 'tree-node-link')
                    .attr('d', function (d) {
                    return 'M' + d.x + ',' + d.y
                        + 'C' + d.x + ',' + (d.y + d.parent.y) / 2
                        + ' ' + d.parent.x + ',' + (d.y + d.parent.y) / 2
                        + ' ' + d.parent.x + ',' + d.parent.y;
                });
                var /** @type {?} */ node = _treeContainer
                    .selectAll('.node')
                    .data(nodes.descendants())
                    .enter()
                    .append('g')
                    .attr('class', function (d) {
                    return 'tree-node' +
                        (d.children ? '-internal' : '-leaf');
                })
                    .attr('transform', function (d) {
                    return 'translate(' + d.x + ',' + d.y + ')';
                });
                node.append('circle')
                    .attr('r', 10);
                node.append('text')
                    .attr('dy', '.35em')
                    .attr('y', function (d) {
                    return d.children ? -20 : 20;
                })
                    .style('text-anchor', 'middle')
                    .text(function (d) {
                    return d.data.name;
                });
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildGeoOrthographic = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in buildGeoOrthographic -------------------');
                var /** @type {?} */ _maxX = 100; // any value
                var /** @type {?} */ _maxY = 100; // any value
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _graphCenterPos = cdt.graphCenterPos;
                var /** @type {?} */ _titleDisplay = configData.title.display;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ _focusColor = configData.color.focusColor;
                var /** @type {?} */ _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
                var /** @type {?} */ _scale = dataSetJson.map.scale;
                var /** @type {?} */ _targetName = dataSetJson.map.targetName;
                var /** @type {?} */ _targetProperty = 'd.' + dataSetJson.map.targetPropertyName;
                var /** @type {?} */ _keyDataName = dataSetJson.map.keyDataName;
                var /** @type {?} */ _keyName = 'data.' + _keyDataName;
                var /** @type {?} */ _clipAngle = dataSetJson.map.clipAngle;
                var /** @type {?} */ _rotateH = dataSetJson.map.rotate.horizontal;
                var /** @type {?} */ _rotateV = dataSetJson.map.rotate.vertical;
                var /** @type {?} */ _oceanColor = dataSetJson.map.oceanColor;
                var /** @type {?} */ _antarcticaColor = dataSetJson.map.antarcticaColor;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                var /** @type {?} */ _animationH = 0;
                var /** @type {?} */ _findColorByName = function (name) {
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            if (name === dataSetJson.data[i].name) {
                                var /** @type {?} */ _color = dataSetJson.data[i].color;
                                return _color;
                            }
                        }
                    }
                    return null;
                };
                var /** @type {?} */ targetPath = d3.geoOrthographic()
                    .translate(_graphCenterPos)
                    .clipAngle(_clipAngle)
                    .scale(_scale)
                    .rotate([_rotateH, _rotateV]);
                var /** @type {?} */ path = d3.geoPath()
                    .projection(targetPath);
                d3.json(_geoMapDataUrl, function (error, data) {
                    svgContainer.append('circle')
                        .attr('cx', _graphCenterPos[0])
                        .attr('cy', _graphCenterPos[1])
                        .attr('r', _scale)
                        .style('fill', _oceanColor);
                    var /** @type {?} */ earthPath = svgContainer.selectAll('path')
                        .data(eval(_keyName))
                        .enter()
                        .append('path')
                        .attr('d', path)
                        .style('fill', function (d, i) {
                        var /** @type {?} */ _targetArea = eval(_targetProperty);
                        if (_findColorByName(_targetArea) !== null) {
                            return _findColorByName(_targetArea);
                        }
                        return 'hsl(' + i + ',80%,60%)';
                    });
                    if (_animation) {
                        d3.timer(function () {
                            targetPath.rotate([_rotateH + _animationH, _rotateV]);
                            _animationH += 2;
                            earthPath.attr('d', path);
                        });
                    }
                });
                // ------------------------------------
                // ---CALL buildTitle-----------------
                if (_titleDisplay) {
                    this.drawTitle(cdt);
                }
                if (_legendDisplay) {
                    var /** @type {?} */ _legendDataSet = new Array();
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            var /** @type {?} */ _name = dataSetJson.data[i].name;
                            var /** @type {?} */ _color = dataSetJson.data[i].color;
                            if (_name === 'Antarctica') {
                                continue;
                            }
                            _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, dataSetJson.data[i].color));
                        }
                    }
                    this.buildLegend(cdt, _legendDataSet);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildGeoMap = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in buildGeoMap -------------------');
                var /** @type {?} */ _maxX = 100; // any value
                var /** @type {?} */ _maxY = 100; // any value
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _graphCenterPos = cdt.graphCenterPos;
                var /** @type {?} */ _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
                var /** @type {?} */ _scale = dataSetJson.map.scale;
                var /** @type {?} */ _keyDataName = dataSetJson.map.keyDataName;
                var /** @type {?} */ _keyName = 'data.' + _keyDataName;
                var /** @type {?} */ _targetProperty = 'd.' + dataSetJson.map.targetPropertyName;
                var /** @type {?} */ _antarcticaColor = dataSetJson.map.antarcticaColor;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ path = d3.geoPath()
                    .projection(d3.geoMercator()
                    .translate(_graphCenterPos)
                    .scale(_scale));
                var /** @type {?} */ _findColorByName = function (name) {
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            if (name === dataSetJson.data[i].name) {
                                var /** @type {?} */ _color = dataSetJson.data[i].color;
                                return _color;
                            }
                        }
                    }
                    return null;
                };
                d3.json(_geoMapDataUrl, function (error, data) {
                    svgContainer.selectAll('path')
                        .data(eval(_keyName))
                        .enter()
                        .append('path')
                        .attr('d', path)
                        .style('fill', function (d, i) {
                        var /** @type {?} */ _targetArea = eval(_targetProperty);
                        if (_findColorByName(_targetArea) !== null) {
                            return _findColorByName(_targetArea);
                        }
                        return 'hsl(' + i + ',80%,60%)';
                    });
                });
                //  ------------------------------------
                //  ---CALL buildLegend-----------------
                if (_legendDisplay) {
                    var /** @type {?} */ _legendDataSet = new Array();
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            var /** @type {?} */ _name = dataSetJson.data[i].name;
                            var /** @type {?} */ _color = dataSetJson.data[i].color;
                            if (_name === 'Antarctica') {
                                continue;
                            }
                            _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, dataSetJson.data[i].color));
                        }
                    }
                    this.buildLegend(cdt, _legendDataSet);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildStackBar = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in buildStackBar-------------------');
                var /** @type {?} */ _totalY = new Array();
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        _totalY.push(0);
                    }
                }
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        var /** @type {?} */ k = 0;
                        for (var /** @type {?} */ j in dataSetJson.data[i].value) {
                            if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                                _totalY[k++] += dataSetJson.data[i].value[j].y;
                            }
                        }
                    }
                }
                var /** @type {?} */ _maxX = 0;
                var /** @type {?} */ _maxY = 0;
                _maxY = d3.max(_totalY);
                _maxX = 100;
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _color = cdt.defaultColorFunc;
                var /** @type {?} */ _columnNum = dataSetJson.data.length;
                var /** @type {?} */ _barWidth = (cdt.graphWidth / _columnNum) - configData.margin.between;
                var /** @type {?} */ _columnWidth = (cdt.graphWidth / _columnNum);
                var /** @type {?} */ _initPosX = cdt.graphInitXPos;
                var /** @type {?} */ _graphHeight = cdt.graphHeight;
                var /** @type {?} */ _maxYValue = cdt.maxYValue;
                var /** @type {?} */ _opacity = configData.color.opacity;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ _gridYDisplay = configData.grid.y.display;
                var /** @type {?} */ _gridXDisplay = configData.grid.x.display;
                var /** @type {?} */ _labelDisplay = configData.label.display;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                //  Get Data Name
                var /** @type {?} */ _seriesDateName = dataSetJson.series[0];
                //  Get Keys
                var /** @type {?} */ _keyArray = new Array();
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        var /** @type {?} */ _key = dataSetJson.data[i].name;
                        var /** @type {?} */ _value = dataSetJson.data[i].value[0].y;
                        _keyArray.push(_key);
                    }
                }
                //  Get Date String
                var /** @type {?} */ _dateArray = new Array();
                for (var /** @type {?} */ i in dataSetJson.data[0].value) {
                    if (dataSetJson.data[0].value.hasOwnProperty(i)) {
                        var /** @type {?} */ _xValue = dataSetJson.data[0].value[i].x;
                        _dateArray.push(_xValue);
                    }
                }
                var /** @type {?} */ _hashArray = new Array();
                for (var /** @type {?} */ i in _dateArray) {
                    if (_dateArray.hasOwnProperty(i)) {
                        var /** @type {?} */ _hashNumber = {};
                        for (var /** @type {?} */ j in _keyArray) {
                            if (_keyArray.hasOwnProperty(j)) {
                                var /** @type {?} */ _key = _keyArray[j];
                                var /** @type {?} */ _value = dataSetJson.data[j].value[i].y;
                                _hashNumber[_key] = _value;
                            }
                        }
                        _hashArray.push(_hashNumber);
                    }
                }
                var /** @type {?} */ yScale = d3.scaleLinear()
                    .domain([0, _maxYValue])
                    .range([0, _graphHeight]);
                var /** @type {?} */ stack = d3.stack();
                var /** @type {?} */ _rect = svgContainer.selectAll('g')
                    .data(stack.keys(_keyArray)(_hashArray))
                    .enter()
                    .append('g')
                    .attr('fill', function (d, i) {
                    return _color(i);
                })
                    .attr('fill-opacity', _opacity)
                    .selectAll('rect')
                    .data(function (d, i) {
                    return d;
                })
                    .enter()
                    .append('rect');
                if (_animation) {
                    _rect.attr('x', function (d, i) {
                        return _initPosX + i * _columnWidth;
                    })
                        .attr('height', 0)
                        .attr('y', function (d, i) {
                        var /** @type {?} */ nm = 'd.data.' + _keyArray[i];
                        var /** @type {?} */ _yValue = eval(nm);
                        return svgHeight - configData.margin.bottom - yScale(d[1]);
                    })
                        .attr('width', _barWidth)
                        .transition()
                        .duration(_animationDuration)
                        .attr('height', function (d, i) {
                        return yScale(d[1] - d[0]);
                    });
                }
                else {
                    _rect.attr('x', function (d, i) {
                        return _initPosX + (i * _columnWidth);
                    })
                        .attr('y', function (d, i) {
                        var /** @type {?} */ nm = 'd.data.' + _keyArray[i];
                        var /** @type {?} */ _yValue = eval(nm);
                        return svgHeight - configData.margin.bottom - yScale(d[1]);
                    })
                        .attr('width', _barWidth)
                        .attr('height', function (d, i) {
                        return yScale(d[1] - d[0]);
                    });
                }
                // ------------------------------------
                // ---CALL buildTitle-----------------
                this.drawTitle(cdt);
                // ------------------------------------
                // ---CALL buildAxis-----------------
                this.buildYAxis(cdt);
                this.drawXBaseLine(cdt);
                //  ------------------------------------
                //  ---CALL drawXAxisLabel-----------------
                if (_labelDisplay) {
                    var /** @type {?} */ _labelArray = new Array();
                    for (var /** @type {?} */ i in dataSetJson.data[0].value) {
                        if (dataSetJson.data[0].value.hasOwnProperty(i)) {
                            _labelArray.push(dataSetJson.data[0].value[i].x);
                        }
                    }
                    this.drawXAxisLabel(cdt, _labelArray, STACK_BAR_CHART_TYPE_NAME);
                }
                //  ------------------------------------
                //  ---CALL buildLegend-----------------
                if (_legendDisplay) {
                    var /** @type {?} */ _legendDataSet = new Array();
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, _color(i)));
                        }
                    }
                    this.buildLegend(cdt, _legendDataSet);
                }
                if (_gridYDisplay) {
                    this.drawYGrid(cdt);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildScatterPlot = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('In  buildScatterPlot----------------');
                var /** @type {?} */ _dataSet = new Array();
                var /** @type {?} */ _maxX = 0;
                var /** @type {?} */ _maxY = 0;
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        for (var /** @type {?} */ j in dataSetJson.data[i].value) {
                            if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                                if (_maxX < dataSetJson.data[i].value[j].x) {
                                    _maxX = dataSetJson.data[i].value[j].x;
                                }
                                if (_maxY < dataSetJson.data[i].value[j].y) {
                                    _maxY = dataSetJson.data[i].value[j].y;
                                }
                                var /** @type {?} */ _scatterPlotData = new O2ScatterPlotData(dataSetJson.data[i].value[j].x, dataSetJson.data[i].value[j].y, dataSetJson.data[i].value[j].r);
                                _dataSet.push(_scatterPlotData);
                            }
                        }
                    }
                }
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _initPosX = cdt.graphInitXPos;
                var /** @type {?} */ _seriesNumber = dataSetJson.series.length;
                var /** @type {?} */ _color = cdt.defaultColorFunc;
                var /** @type {?} */ _opacity = configData.color.opacity;
                var /** @type {?} */ _gridYDisplay = configData.grid.y.display;
                var /** @type {?} */ _gridXDisplay = configData.grid.x.display;
                var /** @type {?} */ _titleDisplay = configData.title.display;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ _circle = svgContainer.selectAll('circle')
                    .data(_dataSet)
                    .enter()
                    .append('circle')
                    .attr('cx', function (d, i) {
                    return _initPosX + d.x;
                })
                    .attr('cy', function (d, i) {
                    return (svgHeight - configData.margin.bottom - d.y);
                })
                    .attr('r', function (d, i) {
                    return d.r;
                })
                    .style('fill', function (d, i) {
                    var /** @type {?} */ _colorNum = i % _seriesNumber;
                    return _color(_colorNum);
                })
                    .attr('fill-opacity', _opacity);
                // ---CALL buildTitle-----------------
                if (_titleDisplay) {
                    this.drawTitle(cdt);
                }
                // ------------------------------------
                // ---CALL buildLegend-----------------
                if (_legendDisplay) {
                    var /** @type {?} */ _legendDataSet = new Array();
                    for (var /** @type {?} */ i = 0; i < dataSetJson.series.length; i++) {
                        _legendDataSet.push(new O2LegendData(dataSetJson.series[i], _color(i)));
                    }
                    this.buildLegend(cdt, _legendDataSet);
                }
                // ------------------------------------
                // ---CALL buildAxis-----------------
                this.buildYAxis(cdt);
                this.buildXAxis(cdt);
                if (_gridYDisplay) {
                    this.drawYGrid(cdt);
                }
                if (_gridXDisplay) {
                    this.drawXGrid(cdt);
                }
            };
        /**
         * @param {?} o2Common
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.drawXGrid = /**
         * @param {?} o2Common
         * @return {?}
         */
            function (o2Common) {
                console.log('in buildXGrid-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                var /** @type {?} */ _stepX = cdt.gridXStep;
                var /** @type {?} */ _maxX = cdt.maxXValue;
                var /** @type {?} */ _graphYScale = cdt.graphYScale;
                var /** @type {?} */ _graphXScale = cdt.graphXScale;
                var /** @type {?} */ _graphWidth = cdt.graphWidth;
                var /** @type {?} */ _gridClassName = configData.className.grid;
                var /** @type {?} */ _axisXScale = d3.scaleLinear()
                    .domain([0, _maxX])
                    .range([0, _maxX * _graphXScale]);
                var /** @type {?} */ _rangeX = d3.range(_stepX * _graphXScale, _maxX * _graphXScale, _stepX * _graphXScale);
                svgContainer.append('g')
                    .selectAll('line.x')
                    .data(_rangeX)
                    .enter()
                    .append('line')
                    .attr('class', _gridClassName)
                    .attr('x1', function (d, i) {
                    var /** @type {?} */ _x1 = configData.margin.left + d;
                    return _x1;
                })
                    .attr('y1', cdt.svgHeight - configData.margin.bottom)
                    .attr('x2', function (d, i) {
                    var /** @type {?} */ _x2 = configData.margin.left + d;
                    return _x2;
                })
                    .attr('y2', configData.margin.top + configData.title.height);
            };
        /**
         * @param {?} o2Common
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildXAxis = /**
         * @param {?} o2Common
         * @return {?}
         */
            function (o2Common) {
                console.log('in buildXAxis-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                var /** @type {?} */ _maxX = cdt.maxXValue;
                var /** @type {?} */ _graphXScale = cdt.graphXScale;
                var /** @type {?} */ _axisXScale = d3.scaleLinear()
                    .domain([0, _maxX])
                    .range([0, _maxX * _graphXScale]);
                svgContainer.append('g')
                    .attr('class', cdt.axisClassName)
                    .attr('transform', cdt.axisXBorderTranslatePos)
                    .call(d3.axisBottom(_axisXScale));
                //  .scale()
                //  .orient(cdt.axisXOrient)
                //  );
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildPie = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('In  buildPie----------------');
                var /** @type {?} */ _maxX = 100;
                var /** @type {?} */ _maxY = 100;
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _color = cdt.defaultColorFunc;
                var /** @type {?} */ _graphHeight = cdt.graphHeight;
                var /** @type {?} */ _opacity = configData.color.opacity;
                var /** @type {?} */ _titleHeight = configData.title.height;
                var /** @type {?} */ _leftMargin = configData.margin.left;
                var /** @type {?} */ _topMargin = configData.margin.top;
                var /** @type {?} */ _bottomMargin = configData.margin.bottom;
                var /** @type {?} */ _betweenMargin = configData.margin.between;
                var /** @type {?} */ _innerRadiusPercent = cdt.innerRadiusPercent;
                var /** @type {?} */ _graphCenterTranslatePos = cdt.graphCenterTranslatePos;
                var /** @type {?} */ _pieClassName = configData.className.pie;
                var /** @type {?} */ _pieValueClassName = configData.className.pieNum;
                var /** @type {?} */ _pieInnerTitleClassName = configData.className.pieInnerTitle;
                var /** @type {?} */ _innerRadiusTitleTranslatePos = cdt.innerRadiusTitleTranslatePos;
                var /** @type {?} */ _innerRadiusTitle = cdt.innerRadiusTitle;
                var /** @type {?} */ _titleDisplay = configData.title.display;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ _labelDisplay = configData.label.display;
                var /** @type {?} */ _valueDisplay = configData.pie.value.display;
                var /** @type {?} */ _percentDisplay = configData.pie.percent.display;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                var /** @type {?} */ dataSet = new Array();
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        var /** @type {?} */ _num = dataSetJson.data[i].value;
                        dataSet.push(_num);
                    }
                }
                var /** @type {?} */ _sum = d3.sum(dataSet);
                var /** @type {?} */ pie = d3.pie();
                var /** @type {?} */ arc = d3.arc()
                    .innerRadius(_graphHeight * _innerRadiusPercent / 100)
                    .outerRadius(_graphHeight / 2);
                var /** @type {?} */ pieElements = svgContainer.selectAll('path')
                    .data(pie(dataSet))
                    .enter()
                    .append('g')
                    .attr('transform', _graphCenterTranslatePos);
                var /** @type {?} */ _makeCenterTitle = function () {
                    if (_valueDisplay && _percentDisplay) {
                        var /** @type {?} */ _st = _innerRadiusTitle + ':' + _sum + ' (100%)';
                        return _st;
                    }
                    if (_percentDisplay) {
                        return '100%';
                    }
                    if (_valueDisplay) {
                        return _innerRadiusTitle + ':' + _sum;
                    }
                };
                var /** @type {?} */ textElements = svgContainer.append('text')
                    .attr('class', _pieInnerTitleClassName)
                    .attr('transform', _innerRadiusTitleTranslatePos)
                    .text(_makeCenterTitle);
                var /** @type {?} */ _arc = pieElements.append('path')
                    .attr('class', _pieClassName)
                    .style('fill', function (d, i) {
                    return _color(i);
                })
                    .attr('fill-opacity', _opacity);
                //  For d3Version4 animation is not available now
                //  if (_animation) {
                //      _arc.transition()
                //      .duration(_animationDuration)
                //      .delay((d,i)=> {
                //          return i *1000;
                //      })
                //      .attrTween('d',(d: any,i: number) =>  {
                //          const _interpolate = d3.interpolateObject(
                //              { startAngle:d.startAngle,endAngle:d.startAngle }
                //              { startAngle:d.startAngle,endAngle:d.endAngle }
                //          )
                //          return (t) {
                //              return arc(_interpolate(t));
                //          }
                //      })
                //  }
                //  else{
                //      _arc.attr('d',arc);
                //  }
                _arc.attr('d', arc);
                pieElements.append('text')
                    .attr('class', _pieValueClassName)
                    .attr('transform', function (d, i) {
                    return 'translate(' + arc.centroid(d) + ')';
                })
                    .text(function (d, i) {
                    if (_valueDisplay && _percentDisplay) {
                        var /** @type {?} */ _percentSt = String(Math.ceil(d.value / _sum * 100));
                        var /** @type {?} */ _st = String(d.value) + ' (' + _percentSt + '%)';
                        return _st;
                    }
                    if (_percentDisplay) {
                        var /** @type {?} */ _percentSt = String(Math.ceil(d.value / _sum * 100));
                        var /** @type {?} */ _st = _percentSt + '%';
                        return _st;
                    }
                    if (_valueDisplay) {
                        return d.value;
                    }
                });
                // ---CALL buildTitle-----------------
                if (_titleDisplay) {
                    this.drawTitle(cdt);
                }
                // ------------------------------------
                // ---CALL buildLegend-----------------
                if (_legendDisplay) {
                    var /** @type {?} */ _legendDataSet = new Array();
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, _color(i)));
                        }
                    }
                    this.buildLegend(cdt, _legendDataSet);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildBar = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('In  buildBar----------------');
                var /** @type {?} */ _yDataSet = new Array();
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        for (var /** @type {?} */ j in dataSetJson.data[i].y) {
                            if (dataSetJson.data[i].y.hasOwnProperty(j)) {
                                var /** @type {?} */ _y = dataSetJson.data[i].y[j];
                                _yDataSet.push(_y);
                            }
                        }
                    }
                }
                var /** @type {?} */ _maxX = 0;
                var /** @type {?} */ _maxY = 0;
                _maxY = d3.max(_yDataSet);
                _maxX = 100;
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _barValueClass = configData.className.barValue;
                var /** @type {?} */ _color = cdt.defaultColorFunc;
                var /** @type {?} */ _seriesNum = dataSetJson.series.length;
                var /** @type {?} */ _columnNum = _yDataSet.length;
                var /** @type {?} */ _initPosY = cdt.graphInitYPos;
                var /** @type {?} */ _graphHeight = cdt.graphHeight;
                var /** @type {?} */ _graphWidth = cdt.graphWidth;
                var /** @type {?} */ _opacity = configData.color.opacity;
                var /** @type {?} */ _titleHeight = configData.title.height;
                var /** @type {?} */ _titleDisplay = configData.title.display;
                var /** @type {?} */ _leftMargin = configData.margin.left;
                var /** @type {?} */ _topMargin = configData.margin.top;
                var /** @type {?} */ _bottomMargin = configData.margin.bottom;
                var /** @type {?} */ _betweenMargin = configData.margin.between;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ _labelDisplay = configData.label.display;
                var /** @type {?} */ _gridYDisplay = configData.grid.y.display;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                var /** @type {?} */ _barWidth = (_graphWidth - (_betweenMargin * _columnNum / _seriesNum)) / _columnNum;
                var /** @type {?} */ _columnWidth = (_graphWidth / _columnNum);
                var /** @type {?} */ _graphYScale = cdt.graphYScale;
                var /** @type {?} */ yBarScale = d3.scaleLinear()
                    .domain([0, _maxY])
                    .range([_maxY * _graphYScale, 0]);
                var /** @type {?} */ _barPadding = _betweenMargin;
                var /** @type {?} */ grpGraph = svgContainer.selectAll('g')
                    .data(_yDataSet)
                    .enter()
                    .append('g')
                    .attr('transform', function (d, i) {
                    var /** @type {?} */ _padding = ((i % _seriesNum) === 0) ? _barPadding : 0;
                    return 'translate(' + (_padding + _columnWidth * i) + ')';
                })
                    .style('fill', function (d, i) {
                    var /** @type {?} */ _remnant = (i % _seriesNum);
                    return _color(_remnant);
                })
                    .attr('fill-opacity', _opacity);
                var /** @type {?} */ _rect = grpGraph.append('rect');
                if (_animation) {
                    _rect.attr('x', _leftMargin)
                        .attr('height', 0)
                        .attr('y', function (d) {
                        return _initPosY;
                    })
                        .attr('width', _barWidth - _barPadding)
                        .transition()
                        .duration(_animationDuration)
                        .attr('y', function (d) {
                        return yBarScale(d) + _initPosY;
                    })
                        .attr('height', function (d) {
                        return _graphHeight - yBarScale(d);
                    });
                }
                else {
                    _rect.attr('x', _leftMargin)
                        .attr('y', function (d) {
                        return yBarScale(d) + _initPosY;
                    })
                        .attr('width', _barWidth - _barPadding)
                        .attr('height', function (d) {
                        return _graphHeight - yBarScale(d);
                    });
                }
                var /** @type {?} */ textBarValue = grpGraph.append('text');
                textBarValue
                    .attr('class', _barValueClass)
                    .attr('x', _leftMargin)
                    .attr('y', function (d) {
                    return yBarScale(d) + _initPosY;
                })
                    .text(function (d) {
                    return d;
                });
                // ------------------------------------
                // ---CALL buildAxis-----------------
                this.buildYAxis(cdt);
                //  ------------------------------------
                //  ---CALL drawXAxisLabel-----------------
                if (_labelDisplay) {
                    var /** @type {?} */ _labelArray = new Array();
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            _labelArray.push(dataSetJson.data[i].x);
                        }
                    }
                    this.drawXAxisLabel(cdt, _labelArray, BAR_CHART_TYPE_NAME);
                }
                this.drawXBaseLine(cdt);
                //  ------------------------------------
                //  ---CALL buildLegend-----------------
                var /** @type {?} */ _legendDataSet = new Array();
                for (var /** @type {?} */ i in dataSetJson.series) {
                    if (dataSetJson.series.hasOwnProperty(i)) {
                        _legendDataSet.push(new O2LegendData(dataSetJson.series[i], _color(i)));
                    }
                }
                this.buildLegend(cdt, _legendDataSet);
                // ------------------------------------
                // ---CALL buildTitle-----------------
                if (_titleDisplay) {
                    this.drawTitle(cdt);
                }
                if (_gridYDisplay) {
                    this.drawYGrid(cdt);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildLine = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in buildTest-------------------');
                var /** @type {?} */ _groupMaxY = new Array();
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        var /** @type {?} */ _gMaxY = 0;
                        for (var /** @type {?} */ j in dataSetJson.data[i].value) {
                            if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                                if (_gMaxY < dataSetJson.data[i].value[j].y) {
                                    _gMaxY = dataSetJson.data[i].value[j].y;
                                }
                            }
                        }
                        _groupMaxY.push(_gMaxY);
                    }
                }
                var /** @type {?} */ _maxX = 0;
                var /** @type {?} */ _maxY = 0;
                _maxY = d3.max(_groupMaxY);
                _maxX = 100;
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _color = cdt.defaultColorFunc;
                var /** @type {?} */ _columnNum = dataSetJson.data[0].value.length;
                var /** @type {?} */ _columnWidth = cdt.graphWidth / _columnNum;
                console.log(_columnWidth);
                if (configData.grid.y.display) {
                    this.drawYGrid(cdt);
                }
                //  O2IdValueData
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        var /** @type {?} */ _lineArray = new Array();
                        for (var /** @type {?} */ j in dataSetJson.data[i].value) {
                            if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                                var /** @type {?} */ idValue = new O2IdValueData(parseInt(j, 10), dataSetJson.data[i].value[j].y);
                                _lineArray.push(idValue);
                            }
                        }
                        var /** @type {?} */ num = parseInt(i, 10);
                        this.drawSingleLine(cdt, _lineArray, num);
                    }
                }
                // ------------------------------------
                // ---CALL buildTitle-----------------
                this.drawTitle(cdt);
                // ------------------------------------
                // ---CALL buildAxis-----------------
                this.buildYAxis(cdt);
                this.drawXBaseLine(cdt);
                //  ------------------------------------
                //  ---CALL drawXAxisLabel-----------------
                var /** @type {?} */ _labelArray = new Array();
                for (var /** @type {?} */ i in dataSetJson.data[0].value) {
                    if (dataSetJson.data[0].value.hasOwnProperty(i)) {
                        _labelArray.push(dataSetJson.data[0].value[i].x);
                    }
                }
                this.drawXAxisLabel(cdt, _labelArray, LINE_CHART_TYPE_NAME);
                //  ------------------------------------
                //  ---CALL buildLegend-----------------
                var /** @type {?} */ _legendDataSet = new Array();
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, _color(i)));
                    }
                }
                this.buildLegend(cdt, _legendDataSet);
            };
        /**
         * @param {?} o2Common
         * @param {?} dataSet
         * @param {?} lineNum
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.drawSingleLine = /**
         * @param {?} o2Common
         * @param {?} dataSet
         * @param {?} lineNum
         * @return {?}
         */
            function (o2Common, dataSet, lineNum) {
                console.log('in drawSingleLine-------------------');
                console.log(dataSet);
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                var /** @type {?} */ _maxX = cdt.maxXValue;
                var /** @type {?} */ _initXPos = cdt.axisXLabelInitXPos;
                var /** @type {?} */ _initYPos = cdt.axisXLabelInitYPos;
                var /** @type {?} */ _columnNum = dataSet.length;
                var /** @type {?} */ _columnWidth = cdt.graphWidth / (_columnNum - 1);
                var /** @type {?} */ _color = d3.scaleOrdinal(d3.schemeCategory10);
                var /** @type {?} */ _lineClassName = configData.className.multiLinePrefix + String(lineNum);
                var /** @type {?} */ _leftMargin = configData.margin.left;
                var /** @type {?} */ _bottomMargin = configData.margin.bottom;
                var /** @type {?} */ _yScale = cdt.graphYScale;
                var /** @type {?} */ line = d3.line()
                    .curve(d3.curveLinear)
                    .x(function (d) {
                    return _leftMargin + d.id * _columnWidth;
                })
                    .y(function (d) {
                    return cdt.svgHeight - _bottomMargin - (d.value * _yScale);
                });
                svgContainer.append('path')
                    .attr('class', _lineClassName)
                    .attr('d', line(dataSet));
                //  .attr('transform', cdt.axisTranslatePos)
            };
        /**
         * @param {?} o2Common
         * @param {?} _legendDataSet
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildLegend = /**
         * @param {?} o2Common
         * @param {?} _legendDataSet
         * @return {?}
         */
            function (o2Common, _legendDataSet) {
                console.log('in buildLegend-------------------');
                //  maxValues are meaningless
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                //  const cdt = new O2Common(configData, 100, 100, svgWidth, svgHeight);
                var /** @type {?} */ legendRectSize = configData.legend.rectWidth;
                var /** @type {?} */ legendSpacing = 10;
                var /** @type {?} */ ySpacing = configData.legend.ySpacing;
                var /** @type {?} */ initPosX = cdt.legendInitXPos;
                var /** @type {?} */ initPosY = cdt.legendInitYPos;
                var /** @type {?} */ opacity = configData.color.opacity;
                var /** @type {?} */ grpLegend = svgContainer.append('g')
                    .selectAll('g')
                    .data(_legendDataSet)
                    .enter()
                    .append('g')
                    .attr('class', 'legend')
                    .attr('transform', function (d, i) {
                    var /** @type {?} */ height = legendRectSize + ySpacing;
                    var /** @type {?} */ x = initPosX;
                    var /** @type {?} */ y = i * height + initPosY;
                    return 'translate(' + x + ', ' + y + ')';
                });
                grpLegend.append('rect')
                    .attr('width', legendRectSize)
                    .attr('height', legendRectSize)
                    .style('fill', function (d) {
                    return d.color;
                })
                    .style('stroke', function (d) {
                    return d.color;
                })
                    .attr('fill-opacity', opacity);
                grpLegend.append('text')
                    .attr('x', legendRectSize + legendSpacing)
                    .attr('y', legendRectSize)
                    .text(function (d) {
                    return d.title;
                });
            };
        /**
         * @param {?} o2Common
         * @param {?} labelDataSet
         * @param {?} chartType
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.drawXAxisLabel = /**
         * @param {?} o2Common
         * @param {?} labelDataSet
         * @param {?} chartType
         * @return {?}
         */
            function (o2Common, labelDataSet, chartType) {
                console.log('in drawXAxisLabel-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                // const _maxX = cdt.maxXValue;
                var /** @type {?} */ _initXPos = cdt.axisXLabelInitXPos;
                var /** @type {?} */ _initYPos = cdt.axisXLabelInitYPos;
                var /** @type {?} */ _columnNum = labelDataSet.length;
                var /** @type {?} */ _columnWidth = cdt.graphWidth / _columnNum;
                if (chartType === LINE_CHART_TYPE_NAME) {
                    _columnWidth = cdt.graphWidth / (_columnNum - 1);
                }
                var /** @type {?} */ grpLabel = svgContainer.append('g')
                    .selectAll('g')
                    .data(labelDataSet)
                    .enter()
                    .append('g')
                    .attr('class', configData.axisXText)
                    .attr('transform', function (d, i) {
                    var /** @type {?} */ _x = _initXPos + _columnWidth * i;
                    var /** @type {?} */ _y = _initYPos;
                    return 'translate(' + _x + ', ' + _y + ')';
                });
                grpLabel.append('text')
                    .attr('class', configData.className.axisXText)
                    .text(function (d, i) {
                    return d;
                });
            };
        /**
         * @param {?} o2Common
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.drawXBaseLine = /**
         * @param {?} o2Common
         * @return {?}
         */
            function (o2Common) {
                console.log('in drawXBaseLine-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                svgContainer.append('rect')
                    .attr('class', cdt.axisXBorderLineClassName)
                    .attr('width', cdt.axisXBorderWidth)
                    .attr('height', cdt.axisXBorderLineWidth)
                    .attr('transform', cdt.axisXBorderTranslatePos);
            };
        /**
         * @param {?} o2Common
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.buildYAxis = /**
         * @param {?} o2Common
         * @return {?}
         */
            function (o2Common) {
                console.log('in buildYAxis-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                var /** @type {?} */ _maxY = cdt.maxYValue;
                var /** @type {?} */ _graphYScale = cdt.graphYScale;
                var /** @type {?} */ _axisYScale = d3.scaleLinear()
                    .domain([0, _maxY])
                    .range([_maxY * _graphYScale, 0]);
                svgContainer.append('g')
                    .attr('class', cdt.axisClassName)
                    .attr('transform', cdt.axisTranslatePos)
                    .call(d3.axisLeft(_axisYScale));
            };
        /**
         * @param {?} o2Common
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.drawTitle = /**
         * @param {?} o2Common
         * @return {?}
         */
            function (o2Common) {
                console.log('in drawTitle-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                var /** @type {?} */ _title = configData.title.name;
                var /** @type {?} */ _xPos = cdt.titleInitXPos;
                var /** @type {?} */ _yPos = cdt.titleInitYPos;
                var /** @type {?} */ _titleClassName = configData.title.className;
                svgContainer.append('text')
                    .attr('class', _titleClassName)
                    .attr('x', _xPos)
                    .attr('y', _yPos)
                    .text(_title);
            };
        /**
         * @param {?} o2Common
         * @return {?}
         */
        Ng6O2ChartComponent.prototype.drawYGrid = /**
         * @param {?} o2Common
         * @return {?}
         */
            function (o2Common) {
                console.log('in buildYGrid-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                var /** @type {?} */ _stepY = cdt.gridYStep;
                var /** @type {?} */ _maxY = cdt.maxYValue;
                var /** @type {?} */ _graphYScale = cdt.graphYScale;
                var /** @type {?} */ _gridClassName = configData.className.grid;
                var /** @type {?} */ _rangeY = d3.range(_stepY * _graphYScale, _maxY * _graphYScale, _stepY * _graphYScale);
                svgContainer.append('g')
                    .selectAll('line.y')
                    .data(_rangeY)
                    .enter()
                    .append('line')
                    .attr('class', _gridClassName)
                    .attr('x1', configData.margin.left)
                    .attr('y1', function (d, i) {
                    var /** @type {?} */ _y1 = cdt.svgHeight - configData.margin.bottom - d;
                    return _y1;
                })
                    .attr('x2', configData.margin.left + cdt.axisXBorderWidth)
                    .attr('y2', function (d, i) {
                    var /** @type {?} */ _y1 = cdt.svgHeight - configData.margin.bottom - d;
                    return _y1;
                });
            };
        Ng6O2ChartComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'lib-Ng6O2Chart',
                        template: "",
                        styles: []
                    },] },
        ];
        /** @nocollapse */
        Ng6O2ChartComponent.ctorParameters = function () {
            return [
                { type: core.ElementRef }
            ];
        };
        Ng6O2ChartComponent.propDecorators = {
            chartType: [{ type: core.Input }],
            svgWidth: [{ type: core.Input }],
            svgHeight: [{ type: core.Input }],
            graphData: [{ type: core.Input }],
            configData: [{ type: core.Input }]
        };
        return Ng6O2ChartComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Ng6O2ChartModule = (function () {
        function Ng6O2ChartModule() {
        }
        Ng6O2ChartModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [],
                        declarations: [Ng6O2ChartComponent],
                        exports: [Ng6O2ChartComponent]
                    },] },
        ];
        return Ng6O2ChartModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    exports.LINE_CHART_TYPE_NAME = LINE_CHART_TYPE_NAME;
    exports.BAR_CHART_TYPE_NAME = BAR_CHART_TYPE_NAME;
    exports.PIE_CHART_TYPE_NAME = PIE_CHART_TYPE_NAME;
    exports.SCATTER_PLOT_CHART_TYPE_NAME = SCATTER_PLOT_CHART_TYPE_NAME;
    exports.HISTOGRAM_CHART_TYPE_NAME = HISTOGRAM_CHART_TYPE_NAME;
    exports.STACK_BAR_CHART_TYPE_NAME = STACK_BAR_CHART_TYPE_NAME;
    exports.GEO_MAP_CHART_TYPE_NAME = GEO_MAP_CHART_TYPE_NAME;
    exports.GEO_ORTHOGRAPHIC_CHART_TYPE_NAME = GEO_ORTHOGRAPHIC_CHART_TYPE_NAME;
    exports.TREE_MAP_CHART_TYPE_NAME = TREE_MAP_CHART_TYPE_NAME;
    exports.PACK_LAYOUT_CHART_TYPE_NAME = PACK_LAYOUT_CHART_TYPE_NAME;
    exports.CHOROPLETH_CHART_TYPE_NAME = CHOROPLETH_CHART_TYPE_NAME;
    exports.TREE_CHART_TYPE_NAME = TREE_CHART_TYPE_NAME;
    exports.SANKEY_CHART_TYPE_NAME = SANKEY_CHART_TYPE_NAME;
    exports.FORCE_CHART_TYPE_NAME = FORCE_CHART_TYPE_NAME;
    exports.Ng6O2ChartComponent = Ng6O2ChartComponent;
    exports.Ng6O2ChartModule = Ng6O2ChartModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmc2LW8yLWNoYXJ0LnVtZC5qcy5tYXAiLCJzb3VyY2VzIjpbIm5nOi8vbmc2LW8yLWNoYXJ0L2xpYi9zaGFyZWQvY2hhcnQtY29uc3QudHMiLCJuZzovL25nNi1vMi1jaGFydC9saWIvc2hhcmVkL28yY29tbW9uLnRzIiwibmc6Ly9uZzYtbzItY2hhcnQvbGliL25nNi1vMi1jaGFydC5jb21wb25lbnQudHMiLCJuZzovL25nNi1vMi1jaGFydC9saWIvbmc2LW8yLWNoYXJ0Lm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJleHBvcnQgY29uc3QgTElORV9DSEFSVF9UWVBFX05BTUUgID0gJ2xpbmUnO1xyXG5leHBvcnQgY29uc3QgQkFSX0NIQVJUX1RZUEVfTkFNRSA9ICdiYXInO1xyXG5leHBvcnQgY29uc3QgUElFX0NIQVJUX1RZUEVfTkFNRSA9ICdwaWUnO1xyXG5leHBvcnQgY29uc3QgU0NBVFRFUl9QTE9UX0NIQVJUX1RZUEVfTkFNRSA9ICdzY2F0dGVyUGxvdCc7XHJcbmV4cG9ydCBjb25zdCBISVNUT0dSQU1fQ0hBUlRfVFlQRV9OQU1FID0gJ2hpc3RvZ3JhbSc7XHJcbmV4cG9ydCBjb25zdCBTVEFDS19CQVJfQ0hBUlRfVFlQRV9OQU1FID0gJ3N0YWNrQmFyJztcclxuZXhwb3J0IGNvbnN0IEdFT19NQVBfQ0hBUlRfVFlQRV9OQU1FID0gJ2dlb01hcCc7XHJcbmV4cG9ydCBjb25zdCBHRU9fT1JUSE9HUkFQSElDX0NIQVJUX1RZUEVfTkFNRSA9ICdnZW9PcnRob2dyYXBoaWMnO1xyXG5leHBvcnQgY29uc3QgVFJFRV9NQVBfQ0hBUlRfVFlQRV9OQU1FID0gJ3RyZWVNYXAnO1xyXG5leHBvcnQgY29uc3QgUEFDS19MQVlPVVRfQ0hBUlRfVFlQRV9OQU1FID0gJ3BhY2tMYXlvdXQnO1xyXG5leHBvcnQgY29uc3QgQ0hPUk9QTEVUSF9DSEFSVF9UWVBFX05BTUUgPSAnY2hvcm9wbGV0aCc7XHJcbmV4cG9ydCBjb25zdCBUUkVFX0NIQVJUX1RZUEVfTkFNRSA9ICd0cmVlJztcclxuZXhwb3J0IGNvbnN0IFNBTktFWV9DSEFSVF9UWVBFX05BTUUgPSAnc2Fua2V5JztcclxuZXhwb3J0IGNvbnN0IEZPUkNFX0NIQVJUX1RZUEVfTkFNRSA9ICdmb3JjZScgO1xyXG4iLCJpbXBvcnQgKiBhcyBkMyBmcm9tICdkMyc7XHJcblxyXG5cclxuXHJcbmV4cG9ydCBjbGFzcyBPMkNvbW1vbiB7XHJcblxyXG4gICAgY29uc3RydWN0b3IoXHJcbiAgICAgICAgcHVibGljIHN2Z0NvbnRhaW5lcjogYW55LFxyXG4gICAgICAgIHB1YmxpYyBjb25maWdEYXRhOiBhbnksXHJcbiAgICAgICAgcHVibGljIGF1dG9NYXhYOiBudW1iZXIsXHJcbiAgICAgICAgcHVibGljIGF1dG9NYXhZOiBudW1iZXIsXHJcbiAgICAgICAgcHVibGljIHN2Z1dpZHRoOiBudW1iZXIsXHJcbiAgICAgICAgcHVibGljIHN2Z0hlaWdodDogbnVtYmVyXHJcbiAgICApIHsgfVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tICBDTEFTUyBOQU1FICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxucHVibGljIGdldCBheGlzQ2xhc3NOYW1lKCk6IHN0cmluZyB7XHJcbiAgICByZXR1cm4gdGhpcy5jb25maWdEYXRhLmNsYXNzTmFtZS5heGlzO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGxpbmVDbGFzc05hbWUoKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ0RhdGEuY2xhc3NOYW1lLmxpbmU7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgYXhpc1hCb3JkZXJMaW5lQ2xhc3NOYW1lKCk6IHN0cmluZyB7XHJcbiAgICByZXR1cm4gdGhpcy5jb25maWdEYXRhLmNsYXNzTmFtZS5heGlzWEJvcmRlcjtcclxufVxyXG5cclxuXHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0gIE1BWCBWQUxVRSAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5wdWJsaWMgZ2V0IG1heFhWYWx1ZSgpOiBudW1iZXIge1xyXG4gICAgbGV0IF9tYXhYID0gdGhpcy5hdXRvTWF4WDtcclxuICAgIGlmICghdGhpcy5jb25maWdEYXRhLm1heFZhbHVlLmF1dG8pIHtcclxuICAgICAgICBfbWF4WCA9IHRoaXMuY29uZmlnRGF0YS5tYXhWYWx1ZS54O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIF9tYXhYO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IG1heFlWYWx1ZSgpOiBudW1iZXIge1xyXG4gICAgbGV0IF9tYXhZID0gdGhpcy5hdXRvTWF4WTtcclxuICAgIGlmICghdGhpcy5jb25maWdEYXRhLm1heFZhbHVlLmF1dG8pIHtcclxuICAgICAgICBfbWF4WSA9IHRoaXMuY29uZmlnRGF0YS5tYXhWYWx1ZS55O1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIF9tYXhZO1xyXG59XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0gIEdSQVBIIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5wdWJsaWMgZ2V0IGdyYXBoSW5pdFhQb3MoKTogbnVtYmVyIHtcclxuICAgIGxldCBfaW50WCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdDtcclxuICAgIGlmICh0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXkgJiYgdGhpcy5jb25maWdEYXRhLmxlZ2VuZC5wb3NpdGlvbiAhPT0gJ3JpZ2h0Jykge1xyXG4gICAgICAgIF9pbnRYID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLnRvdGFsV2lkdGg7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gX2ludFg7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JhcGhJbml0WVBvcygpOiBudW1iZXIge1xyXG4gICAgY29uc3QgX2ludFkgPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0O1xyXG4gICAgcmV0dXJuIF9pbnRZO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGdyYXBoWVNjYWxlKCk6IG51bWJlciB7XHJcbiAgICByZXR1cm4gdGhpcy5ncmFwaEhlaWdodCAvIHRoaXMubWF4WVZhbHVlO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGdyYXBoWFNjYWxlKCk6IG51bWJlciB7XHJcbiAgICByZXR1cm4gdGhpcy5ncmFwaFdpZHRoIC8gdGhpcy5tYXhYVmFsdWU7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JhcGhXaWR0aCgpOiBudW1iZXIge1xyXG4gICAgbGV0IF9tYXJnaW4gPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ucmlnaHQ7XHJcbiAgICBpZiAodGhpcy5jb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5KSB7XHJcbiAgICAgICAgX21hcmdpbiArPSB0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLnRvdGFsV2lkdGg7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHRoaXMuc3ZnV2lkdGggLSBfbWFyZ2luO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGdyYXBoSGVpZ2h0KCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfaCA9IHRoaXMuc3ZnSGVpZ2h0XHJcbiAgICAgICAgICAgICAgICAtIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHRcclxuICAgICAgICAgICAgICAgIC0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi50b3BcclxuICAgICAgICAgICAgICAgIC0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5ib3R0b207XHJcbiAgICByZXR1cm4gX2g7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JhcGhDZW50ZXJQb3MoKTogYW55IHtcclxuICAgIGNvbnN0IF94eUFycmF5OiBBcnJheTxudW1iZXI+ID0gbmV3IEFycmF5KCk7XHJcbiAgICBjb25zdCBfeCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICAgICAgKyB0aGlzLmdyYXBoV2lkdGggLyAyO1xyXG4gICAgY29uc3QgX3kgPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHRcclxuICAgICAgICAgICAgKyB0aGlzLmdyYXBoSGVpZ2h0IC8gMjtcclxuICAgIF94eUFycmF5LnB1c2goX3gpO1xyXG4gICAgX3h5QXJyYXkucHVzaChfeSk7XHJcbiAgICByZXR1cm4gX3h5QXJyYXk7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JhcGhDZW50ZXJUcmFuc2xhdGVQb3MoKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IF94ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICsgdGhpcy5ncmFwaFdpZHRoIC8gMjtcclxuICAgIGNvbnN0IF95ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi50b3BcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0XHJcbiAgICAgICAgICAgICsgdGhpcy5ncmFwaEhlaWdodCAvIDI7XHJcbiAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgU3RyaW5nKF94KSArICcsICcgKyBTdHJpbmcoX3kpICsgJyknO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGdyYXBoSW5pdFRyYW5zbGF0ZVBvcygpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgX3ggPSB0aGlzLmdyYXBoSW5pdFhQb3M7XHJcbiAgICBjb25zdCBfeSA9IHRoaXMuZ3JhcGhJbml0WVBvcztcclxuICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyBTdHJpbmcoX3gpICsgJywgJyArIFN0cmluZyhfeSkgKyAnKSc7XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLSAgQVhJUyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbnB1YmxpYyBnZXQgYXhpc1hMYWJlbEluaXRYUG9zKCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfeCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS5heGlzLnhMYWJlbC5sZWZ0TWFyZ2luO1xyXG4gICAgcmV0dXJuIF94O1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGF4aXNYTGFiZWxJbml0WVBvcygpOiBudW1iZXIge1xyXG4gICAgY29uc3QgX3kgPSB0aGlzLnN2Z0hlaWdodFxyXG4gICAgICAgICAgICAtIHRoaXMuY29uZmlnRGF0YS5heGlzLnhMYWJlbC5ib3R0b21NYXJnaW47XHJcbiAgICByZXR1cm4gX3k7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgYXhpc1RyYW5zbGF0ZVBvcygpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgX3ggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnQ7XHJcbiAgICBjb25zdCBfeSA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4udG9wXHJcbiAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLnRpdGxlLmhlaWdodDtcclxuICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyBTdHJpbmcoX3gpICsgJywgJyArIFN0cmluZyhfeSkgKyAnKSc7XHJcbn1cclxuXHJcblxyXG5wdWJsaWMgZ2V0IGF4aXNYQm9yZGVyTGluZVdpZHRoKCk6IG51bWJlciB7XHJcbiAgICByZXR1cm4gdGhpcy5jb25maWdEYXRhLmF4aXMuYm9yZGVyTGluZVdpZHRoO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGF4aXNZQm9yZGVySGVpZ2h0KCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfbWFyZ2luID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi50b3BcclxuICAgICAgICAgICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tXHJcbiAgICAgICAgICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0O1xyXG4gICAgcmV0dXJuIHRoaXMuc3ZnSGVpZ2h0IC0gX21hcmdpbjtcclxufVxyXG5cclxucHVibGljIGdldCBheGlzWEJvcmRlcldpZHRoKCk6IG51bWJlciB7XHJcbiAgICBsZXQgX21hcmdpbiA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLm1hcmdpbi5yaWdodDtcclxuICAgIGlmICh0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXkpIHtcclxuICAgICAgICBfbWFyZ2luICs9IHRoaXMuY29uZmlnRGF0YS5sZWdlbmQudG90YWxXaWR0aDtcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLnN2Z1dpZHRoIC0gX21hcmdpbjtcclxufVxyXG5cclxucHVibGljIGdldCBheGlzWU9yaWVudCgpOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuICdsZWZ0JztcclxufVxyXG5cclxucHVibGljIGdldCBheGlzWE9yaWVudCgpOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuICdib3R0b20nO1xyXG59XHJcbnB1YmxpYyBnZXQgYXhpc1hCb3JkZXJUcmFuc2xhdGVQb3MoKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IHNZcG9zID0gU3RyaW5nKHRoaXMuc3ZnSGVpZ2h0IC0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5ib3R0b20pO1xyXG4gICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdCArICcsICcgKyBzWXBvcyArICcpJztcclxufVxyXG5cclxuXHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0gIFJBRElVUyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbnB1YmxpYyBnZXQgaW5uZXJSYWRpdXNQZXJjZW50KCk6IG51bWJlciB7XHJcbiAgICByZXR1cm4gdGhpcy5jb25maWdEYXRhLnBpZS5pbm5lclJhZGl1cy5wZXJjZW50O1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGlubmVyUmFkaXVzVGl0bGUoKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ0RhdGEucGllLmlubmVyUmFkaXVzLnRpdGxlO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGlubmVyUmFkaXVzVGl0bGVUcmFuc2xhdGVQb3MoKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IF94ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICAgICArIHRoaXMuZ3JhcGhXaWR0aCAvIDI7XHJcbiAgICBjb25zdCBfeSA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4udG9wXHJcbiAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLnRpdGxlLmhlaWdodFxyXG4gICAgICAgICAgICArIHRoaXMuZ3JhcGhIZWlnaHQgLyAyXHJcbiAgICAgICAgICAgICsgNTtcclxuICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyBTdHJpbmcoX3gpICsgJywgJyArIFN0cmluZyhfeSkgKyAnKSc7XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLSAgTEVHRU5EICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxucHVibGljIGdldCBsZWdlbmRJbml0WFBvcygpOiBudW1iZXIge1xyXG4gICAgbGV0IF94ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICAgICArIHRoaXMuZ3JhcGhXaWR0aFxyXG4gICAgICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLmluaXRYUG9zIDtcclxuICAgIGlmICh0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLnBvc2l0aW9uICE9PSAncmlnaHQnKSB7XHJcbiAgICAgICAgX3ggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLmxlZ2VuZC5pbml0WFBvcyA7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gX3g7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgbGVnZW5kSW5pdFlQb3MoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF95ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi50b3BcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0XHJcbiAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLmxlZ2VuZC5pbml0WVBvcztcclxuICAgIHJldHVybiBfeTtcclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tICBHUklEICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxucHVibGljIGdldCBncmlkWVN0ZXAoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF9tYXhZID0gTWF0aC5jZWlsKHRoaXMubWF4WVZhbHVlIC8gMTAwKSAqIDEwO1xyXG4gICAgY29uc3QgX2xpbmVOdW0gPSAxMDtcclxuICAgIGNvbnN0IF9zdGVwID0gTWF0aC5jZWlsKF9tYXhZIC8gX2xpbmVOdW0pICogX2xpbmVOdW07XHJcbiAgICByZXR1cm4gX3N0ZXA7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JpZFhTdGVwKCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfbWF4WCA9IE1hdGguY2VpbCh0aGlzLm1heFhWYWx1ZSAvIDEwMCkgKiAxMDtcclxuICAgIGNvbnN0IF9saW5lTnVtID0gMTA7XHJcbiAgICBjb25zdCBfc3RlcCA9IE1hdGguY2VpbChfbWF4WCAvIF9saW5lTnVtKSAqIF9saW5lTnVtO1xyXG4gICAgcmV0dXJuIF9zdGVwO1xyXG59XHJcblxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tICBUSVRMRSAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbnB1YmxpYyBnZXQgdGl0bGVJbml0WFBvcygpOiBudW1iZXIge1xyXG4gICAgY29uc3QgX3ggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgKyAodGhpcy5ncmFwaFdpZHRoICsgdGhpcy5jb25maWdEYXRhLmxlZ2VuZC50b3RhbFdpZHRoKSAvIDJcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEudGl0bGUubGVmdE1hcmdpbjtcclxuICAgIHJldHVybiBfeDtcclxufVxyXG5cclxucHVibGljIGdldCB0aXRsZUluaXRZUG9zKCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfeSA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4udG9wXHJcbiAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLnRpdGxlLmhlaWdodFxyXG4gICAgICAgICAgICAtIHRoaXMuY29uZmlnRGF0YS50aXRsZS5ib3R0b21NYXJnaW47XHJcbiAgICByZXR1cm4gX3k7XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLSAgQ09MT1IgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5wdWJsaWMgZ2V0IGRlZmF1bHRDb2xvckZ1bmMoKTogYW55IHtcclxuICAgIGxldCBfY29sb3I6IGFueTtcclxuICAgIGlmICh0aGlzLmNvbmZpZ0RhdGEuY29sb3IuYXV0byApIHtcclxuICAgICAgICBpZiAodGhpcy5jb25maWdEYXRhLmNvbG9yLmRlZmF1bHRDb2xvck51bWJlciA9PT0gJzIwJykge1xyXG4gICAgICAgICAgICBfY29sb3IgPSBkMy5zY2FsZU9yZGluYWwoZDMuc2NoZW1lQ2F0ZWdvcnkyMCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgX2NvbG9yID0gZDMuc2NhbGVPcmRpbmFsKGQzLnNjaGVtZUNhdGVnb3J5MTApO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBfY29sb3I7XHJcbn1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE8yTGluZURhdGEge1xyXG5jb25zdHJ1Y3RvcihcclxuICAgIHB1YmxpYyBkYXRhOiBBcnJheTxudW1iZXI+LFxyXG4gICAgcHVibGljIGNvbG9yOiBzdHJpbmcsXHJcbiAgICBwdWJsaWMgZGFzaGVkQXJyYXk6IHN0cmluZyxcclxuICAgIHB1YmxpYyBpbnRlcnBvbGF0ZTogc3RyaW5nXHJcbiAgICApIHsgfVxyXG59XHJcblxyXG5cclxuZXhwb3J0IGNsYXNzIE8yTGVnZW5kRGF0YSB7XHJcbmNvbnN0cnVjdG9yKFxyXG4gICBwdWJsaWMgdGl0bGU6IHN0cmluZyxcclxuICAgIHB1YmxpYyBjb2xvcjogc3RyaW5nICkgeyB9XHJcblxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTzJTY2F0dGVyUGxvdERhdGEge1xyXG5jb25zdHJ1Y3RvcihcclxuICAgcHVibGljIHg6IG51bWJlcixcclxuICAgcHVibGljIHk6IG51bWJlcixcclxuICAgcHVibGljIHI6IG51bWJlciApIHsgfVxyXG5cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE8yU3RhY2tCYXJEYXRhIHtcclxuY29uc3RydWN0b3IoXHJcbiAgIHB1YmxpYyB4OiBzdHJpbmcsXHJcbiAgIHB1YmxpYyB5OiBudW1iZXJcclxuICAgKSB7IH1cclxuXHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBPMklkVmFsdWVEYXRhIHtcclxuY29uc3RydWN0b3IoXHJcbiAgIHB1YmxpYyBpZDogbnVtYmVyLFxyXG4gICAgcHVibGljIHZhbHVlOiBudW1iZXJcclxuICAgKSB7IH1cclxuXHJcbn1cclxuXHJcbi8vIGV4cG9ydCBjbGFzcyBPMktleVZhbHVlRGF0YSB7XHJcbi8vICAgICBjb25zdHJ1Y3RvcihcclxuLy8gICAgICAgIHB1YmxpYyBrZXk6IHN0cmluZyxcclxuLy8gXHQgICBwdWJsaWMgdmFsdWU6IG51bWJlclxyXG4vLyAgICAgICAgKSB7IH1cclxuLy8gfVxyXG4vLyBleHBvcnQgY2xhc3MgTzJEYXRlS1ZBcnJheURhdGEge1xyXG4vLyAgICAgY29uc3RydWN0b3IoXHJcbi8vICAgICAgICBwdWJsaWMgZGF0ZTogRGF0ZSxcclxuLy8gXHQgICBwdWJsaWMga3ZBcnJheTogQXJyYXk8TzJLZXlWYWx1ZURhdGE+XHJcbi8vICAgICAgICApIHsgfVxyXG4vLyB9XHJcbi8vIGV4cG9ydCBjbGFzcyBPMkRhdGVTdEtWQXJyYXlEYXRhIHtcclxuLy8gICAgIGNvbnN0cnVjdG9yKFxyXG4vLyAgICAgICAgcHVibGljIGRhdGVTdDogc3RyaW5nLFxyXG4vLyBcdCAgIHB1YmxpYyBrdkFycmF5OiBBcnJheTxPMktleVZhbHVlRGF0YT5cclxuLy8gICAgICAgICkgeyB9XHJcbi8vIH0iLCJpbXBvcnQge0NvbXBvbmVudCwgRGlyZWN0aXZlLCBJbnB1dCwgT25Jbml0LCBJbmplY3QsIEVsZW1lbnRSZWYgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7T3V0cHV0LCBPbkNoYW5nZXMsIFNpbXBsZUNoYW5nZX0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge08yQ29tbW9uLCBPMkxlZ2VuZERhdGEsIE8yU2NhdHRlclBsb3REYXRhLCBPMlN0YWNrQmFyRGF0YSwgTzJMaW5lRGF0YSwgTzJJZFZhbHVlRGF0YX0gZnJvbSAnLi9zaGFyZWQvbzJjb21tb24nO1xuXG5pbXBvcnQgKiBhcyBDaGFydENvbnN0IGZyb20gJy4vc2hhcmVkL2NoYXJ0LWNvbnN0JztcbmltcG9ydCAqIGFzIGQzIGZyb20gJ2QzJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnbGliLU5nNk8yQ2hhcnQnLFxuICB0ZW1wbGF0ZTogYGAsXG4gIHN0eWxlczogW11cbn0pXG5leHBvcnQgY2xhc3MgTmc2TzJDaGFydENvbXBvbmVudCBpbXBsZW1lbnRzICBPbkluaXQgLCBPbkNoYW5nZXMge1xuICBASW5wdXQoKSBjaGFydFR5cGU6IHN0cmluZztcbiAgQElucHV0KCkgc3ZnV2lkdGg6IHN0cmluZztcbiAgQElucHV0KCkgc3ZnSGVpZ2h0OiBzdHJpbmc7XG4gIEBJbnB1dCgpIGdyYXBoRGF0YTogQXJyYXk8bnVtYmVyPjtcbiAgQElucHV0KCkgY29uZmlnRGF0YTogYW55O1xuICByb290OiBhbnk7XG5cbiAgY29uc3RydWN0b3IoIGVsZW1lbnRSZWY6IEVsZW1lbnRSZWYgKSB7XG4gICAgY29uc29sZS5sb2coJ2VsOkhUTUxFbGVtZW50LS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuICAgIGNvbnN0IGVsOiBIVE1MRWxlbWVudCAgICA9IGVsZW1lbnRSZWYubmF0aXZlRWxlbWVudDtcbiAgICB0aGlzLnJvb3QgPSBkMy5zZWxlY3QoZWwpO1xufVxuXG5uZ09uSW5pdCgpIHtcbn1cblxubmdPbkNoYW5nZXMoY2hhbmdlczoge1twcm9wZXJ0eU5hbWU6IHN0cmluZ106IFNpbXBsZUNoYW5nZX0pIHtcbiAgY29uc3Qgc3ZnV2lkdGggPSBwYXJzZUludCh0aGlzLnN2Z1dpZHRoLCAxMCk7XG4gIGNvbnN0IHN2Z0hlaWdodCA9IHBhcnNlSW50KHRoaXMuc3ZnSGVpZ2h0LCAxMCk7XG4gIGNvbnN0IGRhdGFTZXQgPSB0aGlzLmdyYXBoRGF0YTtcbiAgY29uc3QgY29uZmlnRGF0YSA9IHRoaXMuY29uZmlnRGF0YTtcbiAgY29uc3QgY2hhcnRUeXBlID0gdGhpcy5jaGFydFR5cGU7XG4gIGNvbnN0IHN2Z0NvbnRhaW5lciA9IHRoaXMucm9vdC5hcHBlbmQoJ3N2ZycpXG4gICAgICAgICAgICAuYXR0cignd2lkdGgnLCBzdmdXaWR0aClcbiAgICAgICAgICAgIC5hdHRyKCdoZWlnaHQnLCBzdmdIZWlnaHQpO1xuXG4gIGNvbnNvbGUubG9nKGNoYXJ0VHlwZSk7XG4gIHN3aXRjaCAoY2hhcnRUeXBlKSB7XG4gICAgY2FzZSBDaGFydENvbnN0LkxJTkVfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZExpbmUoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5CQVJfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZEJhcihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5QSUVfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZFBpZShzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5TQ0FUVEVSX1BMT1RfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZFNjYXR0ZXJQbG90KHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LkhJU1RPR1JBTV9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkSGlzdG9ncmFtKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LlNUQUNLX0JBUl9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkU3RhY2tCYXIoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuR0VPX01BUF9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkR2VvTWFwKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LkdFT19PUlRIT0dSQVBISUNfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZEdlb09ydGhvZ3JhcGhpYyhzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5UUkVFX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRUcmVlKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LlBBQ0tfTEFZT1VUX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRQYWNrTGF5b3V0KHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LkNIT1JPUExFVEhfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZENob3JvcGxldGgoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuRk9SQ0VfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZEZvcmNlKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LlRSRUVfTUFQX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIC8vICB0aGlzLmJ1aWxkVHJlZU1hcChzdmdDb250YWluZXIsY29uZmlnRGF0YSwgZGF0YVNldCxzdmdXaWR0aCxzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5TQU5LRVlfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgLy8gIHRoaXMuYnVpbGRTYW5rZXkoc3ZnQ29udGFpbmVyLGNvbmZpZ0RhdGEsIGRhdGFTZXQsc3ZnV2lkdGgsc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBkZWZhdWx0OlxuICAgICAgYnJlYWs7XG4gIH1cbn1cblxuXG5cbnByaXZhdGUgYnVpbGRIaXN0b2dyYW0oc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRIaXN0b2dyYW0tLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgZGF0YVNldCA9IGRhdGFTZXRKc29uLmRhdGE7XG4gIGNvbnN0IF9iaW5OdW1iZXIgPSBkYXRhU2V0SnNvbi5iaW5zLmxlbmd0aCAtIDE7XG5cbiAgY29uc3QgX21heFkgPSAzMDA7IC8vIGR1bW15IG51bWJlclxuICBjb25zdCBfbWF4WCA9IGRhdGFTZXRKc29uLnJhbmdlWzFdO1xuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuICBjb25zdCBfZ3JhcGhXaWR0aCA9IGNkdC5ncmFwaFdpZHRoO1xuICBjb25zdCBfZ3JhcGhIZWlnaHQgPSBjZHQuZ3JhcGhIZWlnaHQ7XG4gIGNvbnN0IF9tYXhZVmFsdWUgPSBjZHQubWF4WVZhbHVlO1xuICBjb25zdCBfZ3JhcGhYU2NhbGUgPSBjZHQuZ3JhcGhYU2NhbGU7XG4gIGNvbnN0IF9ncmFwaEluaXRYID0gY2R0LmdyYXBoSW5pdFhQb3M7XG4gIGNvbnN0IF9ncmFwaEluaXRZID0gY2R0LmdyYXBoSW5pdFlQb3M7XG5cbiAgY29uc3QgX3RpdGxlRGlzcGxheSA9IGNvbmZpZ0RhdGEudGl0bGUuZGlzcGxheTtcbiAgY29uc3QgX2FuaW1hdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmVuYWJsZTtcbiAgY29uc3QgX2FuaW1hdGlvbkR1cmF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZHVyYXRpb247XG4gIGNvbnN0IF9ncmlkWURpc3BsYXkgPSBjb25maWdEYXRhLmdyaWQueS5kaXNwbGF5O1xuICBjb25zdCBfbWFyZ2luTGVmdCA9IGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQ7XG4gIGNvbnN0IF9tYXJnaW5Ub3AgPSBjb25maWdEYXRhLm1hcmdpbi50b3A7XG4gIGNvbnN0IF9jbGFzc05hbWUgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5oaXN0b2dyYW1CYXI7XG5cblxuICBjb25zdCBfZGF0YVNldDogQXJyYXk8bnVtYmVyPiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldCkge1xuICAgICAgaWYgKGRhdGFTZXQuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBjb25zdCBfbnVtID0gZGF0YVNldFtpXSAvIF9tYXhYO1xuICAgICAgICAgIF9kYXRhU2V0LnB1c2goX251bSk7XG4gICAgICB9XG4gIH1cblxuICBjb25zdCBmb3JtYXRDb3VudCA9IGQzLmZvcm1hdCgnLC4wZicpO1xuXG4gIGNvbnN0IF9oaXN0Z3JhbUNvbnRhaW5lciA9IHN2Z0NvbnRhaW5lclxuICAgICAgICAgICAgICAgICAgLmFwcGVuZCgnZycpXG4gICAgICAgICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgJ3RyYW5zbGF0ZSgnICsgX2dyYXBoSW5pdFggKyAnLCcgKyBfZ3JhcGhJbml0WSArICcpJyk7XG5cbiAgY29uc3QgX3hTY2FsZSA9IGQzLnNjYWxlTGluZWFyKClcbiAgICAgIC5yYW5nZVJvdW5kKFswLCBfZ3JhcGhXaWR0aF0pO1xuXG4gIGNvbnN0IGJpbnMgPSBkMy5oaXN0b2dyYW0oKVxuICAgICAgLmRvbWFpbihbMCwgMV0pXG4gICAgICAudGhyZXNob2xkcyhfeFNjYWxlLnRpY2tzKF9iaW5OdW1iZXIpKVxuICAgICAgKF9kYXRhU2V0KTtcblxuXG4gIGNvbnN0IF95U2NhbGUgPSBkMy5zY2FsZUxpbmVhcigpXG4gICAgICAuZG9tYWluKFswLCBkMy5tYXgoYmlucywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiBkLmxlbmd0aDtcbiAgICAgIH0pXSlcbiAgICAgIC5yYW5nZShbX2dyYXBoSGVpZ2h0LCAwXSk7XG5cbiAgY29uc3QgYmFyID0gX2hpc3RncmFtQ29udGFpbmVyXG4gICAgICAuc2VsZWN0QWxsKCcuYmFyJylcbiAgICAgIC5kYXRhKGJpbnMpXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgnZycpXG4gICAgICAuYXR0cignY2xhc3MnLCBfY2xhc3NOYW1lKVxuICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgX3hTY2FsZShkLngwKSArICcsJyArIF95U2NhbGUoZC5sZW5ndGgpICsgJyknO1xuICAgICAgfSk7XG5cbiAgaWYgKF9hbmltYXRpb24pIHtcbiAgICAgIGJhci5hcHBlbmQoJ3JlY3QnKVxuICAgICAgICAgIC5hdHRyKCd4JywgIDEpXG4gICAgICAgICAgLmF0dHIoJ3dpZHRoJywgX3hTY2FsZShiaW5zWzBdLngxKSAtIF94U2NhbGUoYmluc1swXS54MCkgLSAxKVxuICAgICAgICAgIC5hdHRyKCdoZWlnaHQnLCAwKVxuICAgICAgICAgIC50cmFuc2l0aW9uKClcbiAgICAgICAgICAuZHVyYXRpb24oX2FuaW1hdGlvbkR1cmF0aW9uKVxuICAgICAgICAgIC5hdHRyKCdoZWlnaHQnLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiBfZ3JhcGhIZWlnaHQgLSBfeVNjYWxlKGQubGVuZ3RoKTtcbiAgICAgICAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICAgIGJhci5hcHBlbmQoJ3JlY3QnKVxuICAgICAgICAgIC5hdHRyKCd4JywgMSlcbiAgICAgICAgICAuYXR0cignd2lkdGgnLCBfeFNjYWxlKGJpbnNbMF0ueDEpIC0gX3hTY2FsZShiaW5zWzBdLngwKSAtIDEpXG4gICAgICAgICAgLmF0dHIoJ2hlaWdodCcsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIF9ncmFwaEhlaWdodCAtIF95U2NhbGUoZC5sZW5ndGgpO1xuICAgICAgICAgIH0pO1xuICB9XG5cbiAgYmFyLmFwcGVuZCgndGV4dCcpXG4gICAgICAuYXR0cignZHknLCAnLjc1ZW0nKVxuICAgICAgLmF0dHIoJ3knLCA2KVxuICAgICAgLmF0dHIoJ3gnLCAoX3hTY2FsZShiaW5zWzBdLngxKSAtIF94U2NhbGUoYmluc1swXS54MCkpIC8gMilcbiAgICAgIC5hdHRyKCd0ZXh0LWFuY2hvcicsICdtaWRkbGUnKVxuICAgICAgLnRleHQoKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiBmb3JtYXRDb3VudChkLmxlbmd0aCk7XG4gICAgICB9KTtcblxuICAvLyAtLS1DQUxMIGJ1aWxkVGl0bGUtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX3RpdGxlRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3VGl0bGUoY2R0KTtcbiAgfVxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZEF4aXMtLS0tLS0tLS0tLS0tLS0tLVxuICB0aGlzLmJ1aWxkWUF4aXMoY2R0KTtcblxuICB0aGlzLmJ1aWxkWEF4aXMoY2R0KTtcblxuICAgaWYgKF9ncmlkWURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1lHcmlkKGNkdCk7XG4gIH1cbn1cblxuXG5cbnByaXZhdGUgYnVpbGRGb3JjZShzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdJbiAgYnVpbGRGb2NlLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IF9tYXhYID0gMTAwO1xuICBjb25zdCBfbWF4WSA9IDEwMDtcbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcblxuICBjb25zdCBfY29sb3IgPSBjZHQuZGVmYXVsdENvbG9yRnVuYztcbiAgY29uc3QgX2luaXRQb3NYID0gY2R0LmdyYXBoSW5pdFhQb3M7XG4gIGNvbnN0IF9pbml0UG9zWSA9IGNkdC5ncmFwaEluaXRZUG9zO1xuICBjb25zdCBfY2VudGVyUG9zID0gY2R0LmdyYXBoQ2VudGVyUG9zO1xuICBjb25zdCBfZ3JhcGhIZWlnaHQgPSBjZHQuZ3JhcGhIZWlnaHQ7XG4gIGNvbnN0IF9ncmFwaFdpZHRoID0gY2R0LmdyYXBoV2lkdGg7XG5cbiAgY29uc3QgX21hcmdpbkxlZnQgPSBjb25maWdEYXRhLm1hcmdpbi5sZWZ0O1xuICBjb25zdCBfbWFyZ2luVG9wID0gY29uZmlnRGF0YS5tYXJnaW4udG9wO1xuXG5cbiAgY29uc3Qgc2ltdWxhdGlvbiA9IGQzLmZvcmNlU2ltdWxhdGlvbigpXG4gICAgICAuZm9yY2UoJ2xpbmsnLCBkMy5mb3JjZUxpbmsoKS5pZCgoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGQuaWQ7XG4gICAgICB9KSlcbiAgICAgIC5mb3JjZSgnY2hhcmdlJywgZDMuZm9yY2VNYW55Qm9keSgpKVxuICAgICAgLmZvcmNlKCdjZW50ZXInLCBkMy5mb3JjZUNlbnRlcihfZ3JhcGhXaWR0aCAvIDIsIF9ncmFwaEhlaWdodCAvIDIpKTtcblxuXG4gIGNvbnN0IF9mb3JjZUNvbnRhaW5lciA9IHN2Z0NvbnRhaW5lclxuICAgIC5hcHBlbmQoJ2cnKVxuICAgIC5hdHRyKCd0cmFuc2Zvcm0nLFxuICAgICAgJ3RyYW5zbGF0ZSgnICsgX21hcmdpbkxlZnQgKyAnLCcgKyBfbWFyZ2luVG9wICsgJyknKTtcblxuICBjb25zdCBsaW5rID0gX2ZvcmNlQ29udGFpbmVyLmFwcGVuZCgnZycpXG4gICAgICAuYXR0cignY2xhc3MnLCAnZm9yY2UtbGlua3MnKVxuICAgICAgLnNlbGVjdEFsbCgnbGluZScpXG4gICAgICAuZGF0YShkYXRhU2V0SnNvbi5saW5rcylcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdsaW5lJylcbiAgICAgIC5hdHRyKCdzdHJva2Utd2lkdGgnLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIE1hdGguc3FydChkLnZhbHVlKTtcbiAgICAgIH0pO1xuXG4gIGNvbnN0IG5vZGUgPSBfZm9yY2VDb250YWluZXIuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCdjbGFzcycsICdub2RlcycpXG4gICAgICAuc2VsZWN0QWxsKCdjaXJjbGUnKVxuICAgICAgLmRhdGEoZGF0YVNldEpzb24ubm9kZXMpXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgnY2lyY2xlJylcbiAgICAgIC5hdHRyKCdyJywgNSlcbiAgICAgIC5hdHRyKCdmaWxsJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiBfY29sb3IoZC5ncm91cCk7XG4gICAgICB9KVxuICAgICAgLmNhbGwoZDMuZHJhZygpXG4gICAgICAgICAgLm9uKCdzdGFydCcsIGRyYWdzdGFydGVkKVxuICAgICAgICAgIC5vbignZHJhZycsIGRyYWdnZWQpXG4gICAgICAgICAgLm9uKCdlbmQnLCBkcmFnZW5kZWQpKTtcblxuICAgICAgbm9kZS5hcHBlbmQoJ3RpdGxlJylcbiAgICAgICAgICAudGV4dCgoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiBkLmlkO1xuICAgICAgICAgIH0pO1xuXG4gIHNpbXVsYXRpb25cbiAgICAgIC5ub2RlcyhkYXRhU2V0SnNvbi5ub2RlcylcbiAgICAgIC5vbigndGljaycsIHRpY2tlZCk7XG5cbiAgY29uc3QgX2ZvcmNlTGluazogYW55ID0gc2ltdWxhdGlvbi5mb3JjZSgnbGluaycpO1xuICBfZm9yY2VMaW5rLmxpbmtzKGRhdGFTZXRKc29uLmxpbmtzKTtcblxuICBmdW5jdGlvbiB0aWNrZWQoKSB7XG4gICAgICBsaW5rXG4gICAgICAgICAgLmF0dHIoJ3gxJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgIHJldHVybiBkLnNvdXJjZS54OyB9KVxuICAgICAgICAgIC5hdHRyKCd5MScsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgIHJldHVybiBkLnNvdXJjZS55OyB9KVxuICAgICAgICAgIC5hdHRyKCd4MicsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICByZXR1cm4gZC50YXJnZXQueDsgfSlcbiAgICAgICAgICAuYXR0cigneTInLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgcmV0dXJuIGQudGFyZ2V0Lnk7IH0pO1xuXG4gICAgICBub2RlXG4gICAgICAgICAgLmF0dHIoJ2N4JywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgIHJldHVybiBkLng7IH0pXG4gICAgICAgICAgLmF0dHIoJ2N5JywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgIHJldHVybiBkLnk7IH0pO1xuICB9XG5cbiAgZnVuY3Rpb24gZHJhZ3N0YXJ0ZWQoZDogYW55KSAge1xuICAgICAgaWYgKCFkMy5ldmVudC5hY3RpdmUpIHtcbiAgICAgICAgICBzaW11bGF0aW9uLmFscGhhVGFyZ2V0KDAuMykucmVzdGFydCgpO1xuICAgICAgfVxuICAgICAgZC5meCA9IGQueDtcbiAgICAgIGQuZnkgPSBkLnk7XG4gIH1cblxuICBmdW5jdGlvbiBkcmFnZ2VkKGQ6IGFueSkgIHtcbiAgICAgIGQuZnggPSBkMy5ldmVudC54O1xuICAgICAgZC5meSA9IGQzLmV2ZW50Lnk7XG4gIH1cblxuICBmdW5jdGlvbiBkcmFnZW5kZWQoZDogYW55KSAge1xuICAgICAgaWYgKCFkMy5ldmVudC5hY3RpdmUpIHtcbiAgICAgICAgICBzaW11bGF0aW9uLmFscGhhVGFyZ2V0KDApO1xuICAgICAgfVxuICAgICAgZC5meCA9IG51bGw7XG4gICAgICBkLmZ5ID0gbnVsbDtcbiAgfVxuXG4gIC8vICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gIC0tLUNBTEwgYnVpbGRMZWdlbmQtLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZ3JvdXBzKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZ3JvdXBzLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgY29uc3QgX2lkID0gZGF0YVNldEpzb24uZ3JvdXBzW2ldLmlkO1xuICAgICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShkYXRhU2V0SnNvbi5ncm91cHNbaV0ubmFtZSwgX2NvbG9yKF9pZCkpKTtcbiAgICAgIH1cbiAgfVxuICB0aGlzLmJ1aWxkTGVnZW5kKGNkdCwgX2xlZ2VuZERhdGFTZXQpO1xuXG5cblxufVxuXG5cbnByaXZhdGUgYnVpbGRDaG9yb3BsZXRoKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkQ2hvcm9wbGV0aCAtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgX21heFggPSAxMDA7IC8vIGFueSB2YWx1ZVxuICBjb25zdCBfbWF4WSA9IDEwMDsgLy8gYW55IHZhbHVlXG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG4gIGNvbnN0IF9ncmFwaENlbnRlclBvcyA9IGNkdC5ncmFwaENlbnRlclBvcztcbiAgY29uc3QgX2dyYXBoSW5pdFggPSBjZHQuZ3JhcGhJbml0WFBvcztcbiAgY29uc3QgX2dyYXBoSW5pdFkgPSBjZHQuZ3JhcGhJbml0WVBvcztcblxuXG4gIGNvbnN0IF90aXRsZURpc3BsYXkgPSBjb25maWdEYXRhLnRpdGxlLmRpc3BsYXk7XG4gIGNvbnN0IF9sZWdlbmREaXNwbGF5ID0gY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheTtcbiAgY29uc3QgX2ZvY3VzQ29sb3IgPSBjb25maWdEYXRhLmNvbG9yLmZvY3VzQ29sb3I7XG5cbiAgY29uc3QgX3NjYWxlID0gZGF0YVNldEpzb24ubWFwLnNjYWxlO1xuICBjb25zdCBfdGFyZ2V0TmFtZSA9IGRhdGFTZXRKc29uLm1hcC50YXJnZXROYW1lO1xuICBjb25zdCBfa2V5RGF0YU5hbWUgPSBkYXRhU2V0SnNvbi5tYXAua2V5RGF0YU5hbWU7XG4gIGNvbnN0IF9rZXlOYW1lID0gJ2RhdGEuJyArIF9rZXlEYXRhTmFtZTtcbiAgY29uc3QgX2dlb01hcERhdGFVcmwgPSBkYXRhU2V0SnNvbi5tYXAuYmFzZUdlb0RhdGFVcmw7XG4gIGNvbnN0IF9zdGFydENvbG9yID0gZGF0YVNldEpzb24ubWFwLnN0YXJ0Q29sb3I7XG4gIGNvbnN0IF9lbmRDb2xvciA9IGRhdGFTZXRKc29uLm1hcC5lbmRDb2xvcjtcbiAgY29uc3QgX2NvbG9yTnVtID0gZGF0YVNldEpzb24ubWFwLmNvbG9yTnVtYmVyO1xuICBjb25zdCBfY2VudGVyID0gZGF0YVNldEpzb24ubWFwLmNlbnRlcjtcbiAgY29uc3QgX3RhcmdldFByb3BlcnR5TmFtZSA9IGRhdGFTZXRKc29uLm1hcC50YXJnZXRQcm9wZXJ0eU5hbWU7XG4gIGNvbnN0IF90YXJnZXRQcm9wZXJ0eSA9ICdkLicgKyBfdGFyZ2V0UHJvcGVydHlOYW1lO1xuXG4gIGNvbnN0IGNvbG9yID0gZDMuaW50ZXJwb2xhdGVIc2woX3N0YXJ0Q29sb3IsIF9lbmRDb2xvcik7XG5cbiAgbGV0IF9tYXggPSBkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlO1xuICBsZXQgX21pbiA9IGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWU7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGlmIChfbWF4IDwgZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZSkge1xuICAgICAgICAgICAgICBfbWF4ID0gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKF9taW4gPiBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlKSB7XG4gICAgICAgICAgICAgIF9taW4gPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgfVxuICBjb25zdCBfcmFuZ2UgPSBfbWF4IC0gX21pbjtcbiAgY29uc3QgX3N0ZXAgPSBfcmFuZ2UgLyAoX2NvbG9yTnVtIC0gMSk7XG5cbiAgY29uc3QgX2ZpbmRDb2xvckJ5SWQgPSAoaWQ6IG51bWJlcik6IHN0cmluZyA9PiB7XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgIGlmIChpZCA9PT0gZGF0YVNldEpzb24uZGF0YVtpXS5pZCkge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX3ZhbHVlID0gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZTtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IF9yYXRlID0gTWF0aC5jZWlsKChfdmFsdWUgLSBfbWluKSAvIF9zdGVwKTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjb2xvcihfcmF0ZSAvIF9tYXgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgfVxuICB9O1xuXG4gIGNvbnN0IHBhdGggPSBkMy5nZW9QYXRoKClcbiAgICAgICAgICAgICAgLnByb2plY3Rpb24oXG4gICAgICAgICAgICAgICAgICBkMy5nZW9NZXJjYXRvcigpXG4gICAgICAgICAgICAgICAgICAuY2VudGVyKF9jZW50ZXIpXG4gICAgICAgICAgICAgICAgICAuc2NhbGUoX3NjYWxlKVxuICAgICAgICAgICAgICAgICAgLnRyYW5zbGF0ZShfZ3JhcGhDZW50ZXJQb3MpXG4gICAgICAgICAgICAgICk7XG5cbiAgZDMuanNvbihfZ2VvTWFwRGF0YVVybCwgKGVycm9yLCBkYXRhKSA9PiB7XG4gICAgICBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdwYXRoJylcbiAgICAgICAgICAgICAgLmRhdGEoZXZhbChfa2V5TmFtZSkpXG4gICAgICAgICAgICAgIC5lbnRlcigpXG4gICAgICAgICAgICAgIC5hcHBlbmQoJ3BhdGgnKVxuICAgICAgICAgICAgICAuYXR0cignZCcsIHBhdGgpXG4gICAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IF9jbCA9IF9maW5kQ29sb3JCeUlkKGV2YWwoX3RhcmdldFByb3BlcnR5KSk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gX2NsO1xuICAgICAgICAgICAgICB9KTtcbiAgfSk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfdGl0bGVEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdUaXRsZShjZHQpO1xuICB9XG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBidWlsZExlZ2VuZC0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfbGVnZW5kRGlzcGxheSkge1xuICAgICAgY29uc3QgX2xlZ2VuZERhdGFTZXQ6IEFycmF5PE8yTGVnZW5kRGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgX2NvbG9yTnVtOyBpKyspIHtcbiAgICAgICAgICBjb25zdCBfbGFiZWwgPSBTdHJpbmcoX21pbiArIChpICogX3N0ZXApKSArICAnIC0tJztcbiAgICAgICAgICBfbGVnZW5kRGF0YVNldC5wdXNoKG5ldyBPMkxlZ2VuZERhdGEoX2xhYmVsLCBjb2xvcihpIC8gX21heCkpKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG4gIH1cblxufVxuXG5wcml2YXRlIGJ1aWxkUGFja0xheW91dChzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBQYWNrTGF5b3V0LS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgX3BhY2tsYXlvdXRDbGFzcyA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLnBhY2tsYXlvdXQ7XG4gIGNvbnN0IF9wYWNrbGF5b3V0TGFiZWxDbGFzcyA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLnBhY2tsYXlvdXRMYWJlbDtcbiAgY29uc3QgX2FuaW1hdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmVuYWJsZTtcbiAgY29uc3QgX2FuaW1hdGlvbkR1cmF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZHVyYXRpb247XG4gIGNvbnN0IGNvbG9yID0gZDMuc2NhbGVPcmRpbmFsKGQzLnNjaGVtZUNhdGVnb3J5MTApO1xuICAvLyAgY29uc3QgY29sb3IgPSBkMy5zY2FsZS5jYXRlZ29yeTEwKCk7XG4gIGNvbnN0IGJ1YmJsZSA9IGQzLnBhY2soKVxuICAgICAgICAgICAgICAgICAgLnNpemUoW3N2Z1dpZHRoLCBzdmdIZWlnaHRdKTtcblxuICBjb25zdCBub2RlczAgPSBkMy5oaWVyYXJjaHkoZGF0YVNldEpzb24pO1xuXG4gIGNvbnN0IHBhY2sgPSAgc3ZnQ29udGFpbmVyLnNlbGVjdEFsbCgnZycpXG4gICAgICAgICAgICAgIC5kYXRhKGJ1YmJsZShub2RlczApLmRlc2NlbmRhbnRzKCkpXG4gICAgICAgICAgICAgIC5lbnRlcigpXG4gICAgICAgICAgICAgIC5hcHBlbmQoJ2cnKVxuICAgICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIGQueCArICcsJyArIGQueSArICcpJztcbiAgICAgICAgICAgICAgfSk7XG5cbiAgY29uc3QgX2NpcmNsZSA9IHBhY2suYXBwZW5kKCdjaXJjbGUnKTtcbiAgaWYgKF9hbmltYXRpb24pIHtcbiAgICAgIF9jaXJjbGUuYXR0cigncicsIDApXG4gICAgICAgICAgICAgIC50cmFuc2l0aW9uKClcbiAgICAgICAgICAgICAgLmR1cmF0aW9uKChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBkLmRlcHRoICogX2FuaW1hdGlvbkR1cmF0aW9uICArIDUwMDtcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLmF0dHIoJ3InLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gZC5yO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAoZDogYW55LCBpOiBhbnkpID0+ICB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gY29sb3IoaSk7XG4gICAgICAgICAgICAgIH0pO1xuICB9IGVsc2Uge1xuICAgICAgX2NpcmNsZS5hdHRyKCdyJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGQucjtcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IGFueSwgaTogYW55KSA9PiAge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbG9yKGkpO1xuICAgICAgICAgICAgICB9KTtcbiAgfVxuXG4gIGNvbnN0IF90ZXh0ID0gcGFjay5hcHBlbmQoJ3RleHQnKVxuICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCBfcGFja2xheW91dExhYmVsQ2xhc3MpXG4gICAgICAgICAgICAgIC50ZXh0KChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICAgICAgICAgIGlmIChkLmRlcHRoID09PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGQuZGF0YS5uYW1lO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgICAgICAgIH0pO1xuXG4gIGlmIChfYW5pbWF0aW9uKSB7XG4gICAgICBfdGV4dC5zdHlsZSgnb3BhY2l0eScsIDApXG4gICAgICAgICAgLnRyYW5zaXRpb24oKVxuICAgICAgICAgIC5kdXJhdGlvbihfYW5pbWF0aW9uRHVyYXRpb24pXG4gICAgICAgICAgLnN0eWxlKCdvcGFjaXR5JywgMS4wKTtcbiAgfSBlbHNlIHtcbiAgICAgIF90ZXh0LnN0eWxlKCdvcGFjaXR5JywgMS4wKTtcbiAgfVxuXG59XG5cbnByaXZhdGUgYnVpbGRUcmVlKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ0luICBidWlsZFRyZWUtLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgbGV0IF9tYXhYID0gMDtcbiAgbGV0IF9tYXhZID0gMDtcbiAgX21heFkgPSAxMDA7XG4gIF9tYXhYID0gMTAwO1xuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuXG4gIGNvbnN0IF9jb2xvciA9IGNkdC5kZWZhdWx0Q29sb3JGdW5jO1xuICBjb25zdCBfaW5pdFBvc1ggPSBjZHQuZ3JhcGhJbml0WFBvcztcbiAgY29uc3QgX2luaXRQb3NZID0gY2R0LmdyYXBoSW5pdFlQb3M7XG4gIGNvbnN0IF9ncmFwaEhlaWdodCA9IGNkdC5ncmFwaEhlaWdodDtcbiAgY29uc3QgX2dyYXBoV2lkdGggPSBjZHQuZ3JhcGhXaWR0aDtcblxuICBjb25zdCBfYW5pbWF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZW5hYmxlO1xuICBjb25zdCBfYW5pbWF0aW9uRHVyYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5kdXJhdGlvbjtcbiAgY29uc3QgX3RyZWVtYXBDbGFzcyA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLnRyZWVtYXA7XG4gIGNvbnN0IF90cmVlbWFwTGFiZWxDbGFzcyA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLnRyZWVtYXBMYWJlbDtcbiAgY29uc3QgX21hcmdpbkxlZnQgPSBjb25maWdEYXRhLm1hcmdpbi5sZWZ0O1xuICBjb25zdCBfbWFyZ2luVG9wID0gY29uZmlnRGF0YS5tYXJnaW4udG9wO1xuXG5cbiAgY29uc3QgdHJlZSA9IGQzLnRyZWUoKVxuICAgICAgICAgICAgICAgICAgLnNpemUoW19ncmFwaFdpZHRoLCBfZ3JhcGhIZWlnaHRdKTtcblxuICBjb25zdCBub2RlczAgPSBkMy5oaWVyYXJjaHkoZGF0YVNldEpzb24pO1xuXG4gIGNvbnN0IG5vZGVzID0gdHJlZShub2RlczApO1xuXG4gIGNvbnN0IF90cmVlQ29udGFpbmVyID0gc3ZnQ29udGFpbmVyXG4gICAgLmFwcGVuZCgnZycpXG4gICAgLmF0dHIoJ3RyYW5zZm9ybScsXG4gICAgICAndHJhbnNsYXRlKCcgKyBfbWFyZ2luTGVmdCArICcsJyArIF9tYXJnaW5Ub3AgKyAnKScpO1xuXG4gIGNvbnN0IGxpbmsgPSBfdHJlZUNvbnRhaW5lclxuICAgICAgLnNlbGVjdEFsbCgnLmxpbmsnKVxuICAgICAgLmRhdGEoIG5vZGVzLmRlc2NlbmRhbnRzKCkuc2xpY2UoMSkpXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgncGF0aCcpXG4gICAgICAuYXR0cignY2xhc3MnLCAndHJlZS1ub2RlLWxpbmsnKVxuICAgICAgLmF0dHIoJ2QnLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuICdNJyArIGQueCArICcsJyArIGQueVxuICAgICAgICAgICAgICArICdDJyArIGQueCArICcsJyArIChkLnkgKyBkLnBhcmVudC55KSAvIDJcbiAgICAgICAgICAgICAgKyAnICcgKyBkLnBhcmVudC54ICsgJywnICsgIChkLnkgKyBkLnBhcmVudC55KSAvIDJcbiAgICAgICAgICAgICAgKyAnICcgKyBkLnBhcmVudC54ICsgJywnICsgZC5wYXJlbnQueTtcbiAgICAgICAgICB9XG4gICAgICApO1xuXG4gIGNvbnN0IG5vZGUgPSBfdHJlZUNvbnRhaW5lclxuICAgICAgLnNlbGVjdEFsbCgnLm5vZGUnKVxuICAgICAgLmRhdGEobm9kZXMuZGVzY2VuZGFudHMoKSlcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCdjbGFzcycsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gJ3RyZWUtbm9kZScgK1xuICAgICAgICAgIChkLmNoaWxkcmVuID8gJy1pbnRlcm5hbCcgOiAnLWxlYWYnKTtcbiAgICAgIH0pXG4gICAgICAuYXR0cigndHJhbnNmb3JtJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyBkLnggKyAnLCcgKyBkLnkgKyAnKSc7XG4gICAgICB9KTtcblxuICBub2RlLmFwcGVuZCgnY2lyY2xlJylcbiAgICAgIC5hdHRyKCdyJywgMTApO1xuXG4gIG5vZGUuYXBwZW5kKCd0ZXh0JylcbiAgICAgIC5hdHRyKCdkeScsICcuMzVlbScpXG4gICAgICAuYXR0cigneScsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gZC5jaGlsZHJlbiA/IC0yMCA6IDIwO1xuICAgICAgfSlcbiAgICAgIC5zdHlsZSgndGV4dC1hbmNob3InLCAnbWlkZGxlJylcbiAgICAgIC50ZXh0KChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gZC5kYXRhLm5hbWU7XG4gICAgICB9KTtcblxuXG59XG5cblxuXG5wcml2YXRlIGJ1aWxkR2VvT3J0aG9ncmFwaGljKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkR2VvT3J0aG9ncmFwaGljIC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfbWF4WCA9IDEwMDsgLy8gYW55IHZhbHVlXG4gIGNvbnN0IF9tYXhZID0gMTAwOyAvLyBhbnkgdmFsdWVcbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcbiAgY29uc3QgX2dyYXBoQ2VudGVyUG9zID0gY2R0LmdyYXBoQ2VudGVyUG9zO1xuICBjb25zdCBfZ3JhcGhJbml0WCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfZ3JhcGhJbml0WSA9IGNkdC5ncmFwaEluaXRZUG9zO1xuXG4gIGNvbnN0IF90aXRsZURpc3BsYXkgPSBjb25maWdEYXRhLnRpdGxlLmRpc3BsYXk7XG4gIGNvbnN0IF9sZWdlbmREaXNwbGF5ID0gY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheTtcbiAgY29uc3QgX2ZvY3VzQ29sb3IgPSBjb25maWdEYXRhLmNvbG9yLmZvY3VzQ29sb3I7XG5cbiAgY29uc3QgX2dlb01hcERhdGFVcmwgPSBkYXRhU2V0SnNvbi5tYXAuYmFzZUdlb0RhdGFVcmw7XG4gIGNvbnN0IF9zY2FsZSA9IGRhdGFTZXRKc29uLm1hcC5zY2FsZTtcbiAgY29uc3QgX3RhcmdldE5hbWUgPSBkYXRhU2V0SnNvbi5tYXAudGFyZ2V0TmFtZTtcbiAgY29uc3QgX3RhcmdldFByb3BlcnR5ID0gJ2QuJyArIGRhdGFTZXRKc29uLm1hcC50YXJnZXRQcm9wZXJ0eU5hbWU7XG4gIGNvbnN0IF9rZXlEYXRhTmFtZSA9IGRhdGFTZXRKc29uLm1hcC5rZXlEYXRhTmFtZTtcbiAgY29uc3QgX2tleU5hbWUgPSAnZGF0YS4nICsgX2tleURhdGFOYW1lO1xuICBjb25zdCBfY2xpcEFuZ2xlID0gZGF0YVNldEpzb24ubWFwLmNsaXBBbmdsZTtcbiAgY29uc3QgX3JvdGF0ZUggICA9IGRhdGFTZXRKc29uLm1hcC5yb3RhdGUuaG9yaXpvbnRhbDtcbiAgY29uc3QgX3JvdGF0ZVYgICA9IGRhdGFTZXRKc29uLm1hcC5yb3RhdGUudmVydGljYWw7XG4gIGNvbnN0IF9vY2VhbkNvbG9yID0gZGF0YVNldEpzb24ubWFwLm9jZWFuQ29sb3I7XG4gIGNvbnN0IF9hbnRhcmN0aWNhQ29sb3IgPSBkYXRhU2V0SnNvbi5tYXAuYW50YXJjdGljYUNvbG9yO1xuICBjb25zdCBfYW5pbWF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZW5hYmxlO1xuICBjb25zdCBfYW5pbWF0aW9uRHVyYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5kdXJhdGlvbjtcbiAgbGV0IF9hbmltYXRpb25IID0gMDtcblxuICBjb25zdCBfZmluZENvbG9yQnlOYW1lID0gKG5hbWU6IHN0cmluZyk6IHN0cmluZyA9PiB7XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgIGlmIChuYW1lID09PSBkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWUpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IF9jb2xvciA9IGRhdGFTZXRKc29uLmRhdGFbaV0uY29sb3I7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gX2NvbG9yO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIG51bGw7XG4gIH07XG5cbiAgY29uc3QgdGFyZ2V0UGF0aCA9IGQzLmdlb09ydGhvZ3JhcGhpYygpXG4gICAgICAgICAgICAgIC50cmFuc2xhdGUoX2dyYXBoQ2VudGVyUG9zKVxuICAgICAgICAgICAgICAuY2xpcEFuZ2xlKF9jbGlwQW5nbGUpXG4gICAgICAgICAgICAgIC5zY2FsZShfc2NhbGUpXG4gICAgICAgICAgICAgIC5yb3RhdGUoW19yb3RhdGVILCBfcm90YXRlVl0pO1xuXG4gIGNvbnN0IHBhdGggPSBkMy5nZW9QYXRoKClcbiAgICAgICAgICAgICAgLnByb2plY3Rpb24oXG4gICAgICAgICAgICAgICAgICB0YXJnZXRQYXRoXG4gICAgICAgICAgICAgICk7XG5cbiAgZDMuanNvbihfZ2VvTWFwRGF0YVVybCwgKGVycm9yLCBkYXRhKSA9PiB7XG4gICAgICBzdmdDb250YWluZXIuYXBwZW5kKCdjaXJjbGUnKVxuICAgICAgICAgIC5hdHRyKCdjeCcsIF9ncmFwaENlbnRlclBvc1swXSlcbiAgICAgICAgICAuYXR0cignY3knLCBfZ3JhcGhDZW50ZXJQb3NbMV0pXG4gICAgICAgICAgLmF0dHIoJ3InLCBfc2NhbGUpXG4gICAgICAgICAgLnN0eWxlKCdmaWxsJywgX29jZWFuQ29sb3IpO1xuXG4gICAgICBjb25zdCBlYXJ0aFBhdGggPSBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdwYXRoJylcbiAgICAgICAgICAuZGF0YShldmFsKF9rZXlOYW1lKSlcbiAgICAgICAgICAuZW50ZXIoKVxuICAgICAgICAgIC5hcHBlbmQoJ3BhdGgnKVxuICAgICAgICAgIC5hdHRyKCdkJywgcGF0aClcbiAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgICAgIGNvbnN0IF90YXJnZXRBcmVhID0gZXZhbChfdGFyZ2V0UHJvcGVydHkpO1xuICAgICAgICAgICAgICBpZiAoX2ZpbmRDb2xvckJ5TmFtZShfdGFyZ2V0QXJlYSkgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBfZmluZENvbG9yQnlOYW1lKF90YXJnZXRBcmVhKTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIHJldHVybiAnaHNsKCcgKyBpICsgJyw4MCUsNjAlKSc7XG4gICAgICAgICAgfSk7XG4gICAgICBpZiAoX2FuaW1hdGlvbikge1xuICAgICAgICAgIGQzLnRpbWVyKCgpID0+IHtcbiAgICAgICAgICAgICAgdGFyZ2V0UGF0aC5yb3RhdGUoW19yb3RhdGVIICsgX2FuaW1hdGlvbkgsIF9yb3RhdGVWXSk7XG4gICAgICAgICAgICAgIF9hbmltYXRpb25IICs9IDI7XG4gICAgICAgICAgICAgIGVhcnRoUGF0aC5hdHRyKCdkJywgcGF0aCk7XG4gICAgICAgICAgfSk7XG4gICAgICB9XG4gIH0pO1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkVGl0bGUtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX3RpdGxlRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3VGl0bGUoY2R0KTtcbiAgfVxuXG4gIGlmIChfbGVnZW5kRGlzcGxheSkge1xuICAgICAgY29uc3QgX2xlZ2VuZERhdGFTZXQ6IEFycmF5PE8yTGVnZW5kRGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgY29uc3QgX25hbWUgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWU7XG4gICAgICAgICAgICAgIGNvbnN0IF9jb2xvciA9IGRhdGFTZXRKc29uLmRhdGFbaV0uY29sb3I7XG4gICAgICAgICAgICAgIGlmIChfbmFtZSA9PT0gJ0FudGFyY3RpY2EnKSB7XG4gICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBfbGVnZW5kRGF0YVNldC5wdXNoKG5ldyBPMkxlZ2VuZERhdGEoZGF0YVNldEpzb24uZGF0YVtpXS5uYW1lLCBkYXRhU2V0SnNvbi5kYXRhW2ldLmNvbG9yKSk7XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5idWlsZExlZ2VuZChjZHQsIF9sZWdlbmREYXRhU2V0KTtcbiAgfVxuXG5cbn1cblxuXG5cbnByaXZhdGUgYnVpbGRHZW9NYXAoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRHZW9NYXAgLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IF9tYXhYID0gMTAwOyAvLyBhbnkgdmFsdWVcbiAgY29uc3QgX21heFkgPSAxMDA7IC8vIGFueSB2YWx1ZVxuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuICBjb25zdCBfZ3JhcGhDZW50ZXJQb3MgPSBjZHQuZ3JhcGhDZW50ZXJQb3M7XG4gIGNvbnN0IF9nZW9NYXBEYXRhVXJsID0gIGRhdGFTZXRKc29uLm1hcC5iYXNlR2VvRGF0YVVybDtcbiAgY29uc3QgX3NjYWxlID0gZGF0YVNldEpzb24ubWFwLnNjYWxlO1xuICBjb25zdCBfa2V5RGF0YU5hbWUgPSBkYXRhU2V0SnNvbi5tYXAua2V5RGF0YU5hbWU7XG4gIGNvbnN0IF9rZXlOYW1lID0gJ2RhdGEuJyArIF9rZXlEYXRhTmFtZTtcbiAgY29uc3QgX3RhcmdldFByb3BlcnR5ID0gJ2QuJyArIGRhdGFTZXRKc29uLm1hcC50YXJnZXRQcm9wZXJ0eU5hbWU7XG4gIGNvbnN0IF9hbnRhcmN0aWNhQ29sb3IgPSBkYXRhU2V0SnNvbi5tYXAuYW50YXJjdGljYUNvbG9yO1xuICBjb25zdCBfbGVnZW5kRGlzcGxheSA9IGNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXk7XG5cbiAgY29uc3QgcGF0aCA9IGQzLmdlb1BhdGgoKVxuICAgICAgICAgICAgICAucHJvamVjdGlvbihcbiAgICAgICAgICAgICAgICAgIGQzLmdlb01lcmNhdG9yKClcbiAgICAgICAgICAgICAgICAgIC50cmFuc2xhdGUoX2dyYXBoQ2VudGVyUG9zKVxuICAgICAgICAgICAgICAgICAgLnNjYWxlKF9zY2FsZSlcbiAgICAgICAgICAgICAgKTtcblxuICBjb25zdCBfZmluZENvbG9yQnlOYW1lID0gKG5hbWU6IHN0cmluZyk6IHN0cmluZyA9PiB7XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgIGlmIChuYW1lID09PSBkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWUpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IF9jb2xvciA9IGRhdGFTZXRKc29uLmRhdGFbaV0uY29sb3I7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gX2NvbG9yO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmV0dXJuIG51bGw7XG4gIH07XG5cbiAgZDMuanNvbihfZ2VvTWFwRGF0YVVybCwgKGVycm9yLCBkYXRhKSA9PiB7XG4gICAgICBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdwYXRoJylcbiAgICAgICAgICAgICAgLmRhdGEoZXZhbChfa2V5TmFtZSkpXG4gICAgICAgICAgICAgIC5lbnRlcigpXG4gICAgICAgICAgICAgIC5hcHBlbmQoJ3BhdGgnKVxuICAgICAgICAgICAgICAuYXR0cignZCcsIHBhdGgpXG4gICAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IF90YXJnZXRBcmVhID0gZXZhbChfdGFyZ2V0UHJvcGVydHkpO1xuICAgICAgICAgICAgICAgICAgaWYgKF9maW5kQ29sb3JCeU5hbWUoX3RhcmdldEFyZWEpICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9maW5kQ29sb3JCeU5hbWUoX3RhcmdldEFyZWEpO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgcmV0dXJuICdoc2woJyArIGkgKyAnLDgwJSw2MCUpJztcbiAgICAgICAgICAgICAgfSk7XG4gICAgICB9KTtcblxuICAvLyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vICAtLS1DQUxMIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF9sZWdlbmREaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICAgICAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICBjb25zdCBfbmFtZSA9IGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZTtcbiAgICAgICAgICAgICAgY29uc3QgX2NvbG9yID0gZGF0YVNldEpzb24uZGF0YVtpXS5jb2xvcjtcbiAgICAgICAgICAgICAgaWYgKF9uYW1lID09PSAnQW50YXJjdGljYScpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWUsIGRhdGFTZXRKc29uLmRhdGFbaV0uY29sb3IpKTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLmJ1aWxkTGVnZW5kKGNkdCwgX2xlZ2VuZERhdGFTZXQpO1xuICB9XG5cbn1cblxuXG5cbnByaXZhdGUgYnVpbGRTdGFja0JhcihzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZFN0YWNrQmFyLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGludGVyZmFjZSBIYXNoU3RyaW5nIHtcbiAgICBbaW5kZXg6IHN0cmluZ106IHN0cmluZztcbiAgfVxuICBpbnRlcmZhY2UgSGFzaE51bWJlciB7XG4gICAgW2tleTogc3RyaW5nXTogbnVtYmVyO1xuICB9XG5cbiAgY29uc3QgX3RvdGFsWTogQXJyYXk8bnVtYmVyPiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgIF90b3RhbFkucHVzaCgwKTtcbiAgICAgIH1cbiAgfVxuXG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGxldCBrID0gMDtcbiAgICAgICAgICBmb3IgKGNvbnN0IGogaW4gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZSkge1xuICAgICAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZS5oYXNPd25Qcm9wZXJ0eShqKSkge1xuICAgICAgICAgICAgICAgICAgX3RvdGFsWVtrKytdICs9IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgIH1cbiAgfVxuICBsZXQgX21heFggPSAwO1xuICBsZXQgX21heFkgPSAwO1xuICBfbWF4WSA9IGQzLm1heChfdG90YWxZKTtcbiAgX21heFggPSAxMDA7XG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG5cbiAgY29uc3QgX2NvbG9yID0gY2R0LmRlZmF1bHRDb2xvckZ1bmM7XG4gIGNvbnN0IF9jb2x1bW5OdW0gPSAgZGF0YVNldEpzb24uZGF0YS5sZW5ndGg7XG4gIGNvbnN0IF9iYXJXaWR0aCA9IChjZHQuZ3JhcGhXaWR0aCAvIF9jb2x1bW5OdW0pIC0gY29uZmlnRGF0YS5tYXJnaW4uYmV0d2VlbjtcbiAgY29uc3QgX2NvbHVtbldpZHRoID0gKGNkdC5ncmFwaFdpZHRoIC8gX2NvbHVtbk51bSkgO1xuICBjb25zdCBfaW5pdFBvc1ggPSBjZHQuZ3JhcGhJbml0WFBvcztcbiAgY29uc3QgX2luaXRQb3NZID0gY2R0LmdyYXBoSW5pdFlQb3M7XG4gIGNvbnN0IF9ncmFwaEhlaWdodCA9IGNkdC5ncmFwaEhlaWdodDtcbiAgY29uc3QgX21heFlWYWx1ZSA9IGNkdC5tYXhZVmFsdWU7XG5cbiAgY29uc3QgX29wYWNpdHkgPSBjb25maWdEYXRhLmNvbG9yLm9wYWNpdHk7XG4gIGNvbnN0IF9sZWdlbmREaXNwbGF5ID0gY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheTtcbiAgY29uc3QgX2dyaWRZRGlzcGxheSA9IGNvbmZpZ0RhdGEuZ3JpZC55LmRpc3BsYXk7XG4gIGNvbnN0IF9ncmlkWERpc3BsYXkgPSBjb25maWdEYXRhLmdyaWQueC5kaXNwbGF5O1xuICBjb25zdCBfbGFiZWxEaXNwbGF5ID0gY29uZmlnRGF0YS5sYWJlbC5kaXNwbGF5O1xuICBjb25zdCBfYW5pbWF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZW5hYmxlO1xuICBjb25zdCBfYW5pbWF0aW9uRHVyYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5kdXJhdGlvbjtcblxuICAvLyAgR2V0IERhdGEgTmFtZVxuICBjb25zdCBfc2VyaWVzRGF0ZU5hbWUgPSBkYXRhU2V0SnNvbi5zZXJpZXNbMF07XG5cbiAgLy8gIEdldCBLZXlzXG4gIGNvbnN0IF9rZXlBcnJheTogQXJyYXk8c3RyaW5nPiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBjb25zdCBfa2V5ID0gZGF0YVNldEpzb24uZGF0YVtpXS5uYW1lO1xuICAgICAgICAgIGNvbnN0IF92YWx1ZSA9IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbMF0ueTtcbiAgICAgICAgICBfa2V5QXJyYXkucHVzaChfa2V5KTtcbiAgICAgIH1cbiAgfVxuXG4gIC8vICBHZXQgRGF0ZSBTdHJpbmdcbiAgY29uc3QgX2RhdGVBcnJheTogQXJyYXk8c3RyaW5nPiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWUuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBjb25zdCBfeFZhbHVlID0gZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZVtpXS54O1xuICAgICAgICAgIF9kYXRlQXJyYXkucHVzaChfeFZhbHVlKTtcbiAgICAgIH1cbiAgfVxuXG4gIGNvbnN0IF9oYXNoQXJyYXk6IEFycmF5PGFueT4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpIGluIF9kYXRlQXJyYXkpIHtcbiAgICAgIGlmIChfZGF0ZUFycmF5Lmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgY29uc3QgX2RhdGVTdCA9IF9kYXRlQXJyYXlbaV07XG4gICAgICAgICAgY29uc3QgX2hhc2hOdW1iZXI6IEhhc2hOdW1iZXIgPSB7IH07XG4gICAgICAgICAgZm9yIChjb25zdCBqIGluIF9rZXlBcnJheSkge1xuICAgICAgICAgICAgICBpZiAoX2tleUFycmF5Lmhhc093blByb3BlcnR5KGopKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBfa2V5ID0gX2tleUFycmF5W2pdO1xuICAgICAgICAgICAgICAgICAgY29uc3QgX3ZhbHVlID0gZGF0YVNldEpzb24uZGF0YVtqXS52YWx1ZVtpXS55O1xuICAgICAgICAgICAgICAgICAgX2hhc2hOdW1iZXJbX2tleV0gID0gX3ZhbHVlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIF9oYXNoQXJyYXkucHVzaChfaGFzaE51bWJlcik7XG4gICAgICB9XG4gIH1cblxuICBjb25zdCB5U2NhbGUgPSBkMy5zY2FsZUxpbmVhcigpXG4gICAgICAgICAgICAgICAgICAuZG9tYWluKFswLCBfbWF4WVZhbHVlXSlcbiAgICAgICAgICAgICAgICAgIC5yYW5nZShbMCwgX2dyYXBoSGVpZ2h0XSk7XG5cblxuICBjb25zdCBzdGFjayA9IGQzLnN0YWNrKCk7XG4gIGNvbnN0IF9yZWN0ID0gc3ZnQ29udGFpbmVyLnNlbGVjdEFsbCgnZycpXG4gICAgICAuZGF0YShzdGFjay5rZXlzKF9rZXlBcnJheSkoX2hhc2hBcnJheSkpXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgnZycpXG4gICAgICAuYXR0cignZmlsbCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgIHJldHVybiBfY29sb3IoaSk7XG4gICAgICB9IClcbiAgICAgIC5hdHRyKCdmaWxsLW9wYWNpdHknLCBfb3BhY2l0eSlcbiAgICAgIC5zZWxlY3RBbGwoJ3JlY3QnKVxuICAgICAgLmRhdGEoKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGQ7XG4gICAgICB9KVxuICAgICAgLmVudGVyKClcbiAgICAgIC5hcHBlbmQoJ3JlY3QnKTtcblxuXG5cbiAgaWYgKF9hbmltYXRpb24pIHtcbiAgICAgIF9yZWN0LmF0dHIoJ3gnLCAoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICByZXR1cm4gX2luaXRQb3NYw6PCgMKAICsgw6PCgMKAaSAqIF9jb2x1bW5XaWR0aDtcbiAgICAgIH0pXG4gICAgICAuYXR0cignaGVpZ2h0JywgIDApXG4gICAgICAuYXR0cigneScsIChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgIGNvbnN0IG5tID0gJ2QuZGF0YS4nICsgX2tleUFycmF5W2ldO1xuICAgICAgICAgIGNvbnN0IF95VmFsdWUgPSBldmFsKG5tKTtcbiAgICAgICAgICByZXR1cm4gc3ZnSGVpZ2h0IC0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tIC0geVNjYWxlKGRbMV0pO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCd3aWR0aCcsIF9iYXJXaWR0aClcbiAgICAgIC50cmFuc2l0aW9uKClcbiAgICAgIC5kdXJhdGlvbihfYW5pbWF0aW9uRHVyYXRpb24pXG4gICAgICAuYXR0cignaGVpZ2h0JywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHlTY2FsZShkWzFdIC0gZFswXSk7XG4gICAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICAgIF9yZWN0LmF0dHIoJ3gnLCAoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICByZXR1cm4gX2luaXRQb3NYICsgKGkgKiBfY29sdW1uV2lkdGgpO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCd5JywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgY29uc3Qgbm0gPSAnZC5kYXRhLicgKyBfa2V5QXJyYXlbaV07XG4gICAgICAgICAgY29uc3QgX3lWYWx1ZSA9IGV2YWwobm0pO1xuICAgICAgICAgIHJldHVybiBzdmdIZWlnaHQgLSBjb25maWdEYXRhLm1hcmdpbi5ib3R0b20gLSB5U2NhbGUoZFsxXSk7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ3dpZHRoJywgX2JhcldpZHRoKVxuICAgICAgLmF0dHIoJ2hlaWdodCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgIHJldHVybiB5U2NhbGUoZFsxXSAtIGRbMF0pO1xuICAgICAgfSk7XG4gIH1cblxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkVGl0bGUtLS0tLS0tLS0tLS0tLS0tLVxuICB0aGlzLmRyYXdUaXRsZShjZHQpO1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkQXhpcy0tLS0tLS0tLS0tLS0tLS0tXG4gIHRoaXMuYnVpbGRZQXhpcyhjZHQpO1xuXG4gIHRoaXMuZHJhd1hCYXNlTGluZShjZHQpO1xuXG4gIC8vICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gIC0tLUNBTEwgZHJhd1hBeGlzTGFiZWwtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX2xhYmVsRGlzcGxheSkge1xuICAgICAgY29uc3QgX2xhYmVsQXJyYXk6ICBBcnJheTxzdHJpbmc+ID0gbmV3IEFycmF5KCk7XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZSkge1xuICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgIF9sYWJlbEFycmF5LnB1c2goZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZVtpXS54KTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLmRyYXdYQXhpc0xhYmVsKGNkdCwgX2xhYmVsQXJyYXksIENoYXJ0Q29uc3QuU1RBQ0tfQkFSX0NIQVJUX1RZUEVfTkFNRSk7XG4gIH1cblxuXG4gIC8vICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gIC0tLUNBTEwgYnVpbGRMZWdlbmQtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX2xlZ2VuZERpc3BsYXkpIHtcbiAgICAgIGNvbnN0IF9sZWdlbmREYXRhU2V0OiBBcnJheTxPMkxlZ2VuZERhdGE+ID0gbmV3IEFycmF5KCk7XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWUsIF9jb2xvcihpKSkpO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG4gIH1cblxuICBpZiAoX2dyaWRZRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3WUdyaWQoY2R0KTtcbiAgfVxuXG59XG5cbnByaXZhdGUgYnVpbGRTY2F0dGVyUGxvdChzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdJbiAgYnVpbGRTY2F0dGVyUGxvdC0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfZGF0YVNldDogQXJyYXk8TzJTY2F0dGVyUGxvdERhdGE+ID0gbmV3IEFycmF5KCk7XG4gIGxldCBfbWF4WCA9IDA7XG4gIGxldCBfbWF4WSA9IDA7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGZvciAoY29uc3QgaiBpbiBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlKSB7XG4gICAgICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlLmhhc093blByb3BlcnR5KGopKSB7XG4gICAgICAgICAgICAgICAgICBpZiAoX21heFggPCBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLngpIHtcbiAgICAgICAgICAgICAgICAgICAgICBfbWF4WCA9IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueDtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGlmIChfbWF4WSA8IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueSkge1xuICAgICAgICAgICAgICAgICAgICAgIF9tYXhZID0gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS55O1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgY29uc3QgX3NjYXR0ZXJQbG90RGF0YSA9IG5ldyBPMlNjYXR0ZXJQbG90RGF0YShcbiAgICAgICAgICAgICAgICAgICAgICBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLngsXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS55LFxuICAgICAgICAgICAgICAgICAgICAgIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ucixcbiAgICAgICAgICAgICAgICAgICkgO1xuICAgICAgICAgICAgICAgICAgX2RhdGFTZXQucHVzaChfc2NhdHRlclBsb3REYXRhKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgIH1cbiAgfVxuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuXG4gIGNvbnN0IF9pbml0UG9zWCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfaW5pdFBvc1kgPSBjZHQuZ3JhcGhJbml0WVBvcztcblxuICBjb25zdCBfc2VyaWVzTnVtYmVyID0gZGF0YVNldEpzb24uc2VyaWVzLmxlbmd0aDtcbiAgY29uc3QgX2NvbG9yID0gY2R0LmRlZmF1bHRDb2xvckZ1bmM7XG4gIGNvbnN0IF9vcGFjaXR5ID0gY29uZmlnRGF0YS5jb2xvci5vcGFjaXR5O1xuICBjb25zdCBfZ3JpZFlEaXNwbGF5ID0gY29uZmlnRGF0YS5ncmlkLnkuZGlzcGxheTtcbiAgY29uc3QgX2dyaWRYRGlzcGxheSA9IGNvbmZpZ0RhdGEuZ3JpZC54LmRpc3BsYXk7XG4gIGNvbnN0IF90aXRsZURpc3BsYXkgPSBjb25maWdEYXRhLnRpdGxlLmRpc3BsYXk7XG4gIGNvbnN0IF9sZWdlbmREaXNwbGF5ID0gY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheTtcblxuICBjb25zdCBfY2lyY2xlID0gc3ZnQ29udGFpbmVyLnNlbGVjdEFsbCgnY2lyY2xlJylcbiAgICAgICAgICAuZGF0YShfZGF0YVNldClcbiAgICAgICAgICAuZW50ZXIoKVxuICAgICAgICAgIC5hcHBlbmQoJ2NpcmNsZScpXG4gICAgICAgICAgLmF0dHIoJ2N4JywgKGQ6IE8yU2NhdHRlclBsb3REYXRhLCBpOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gX2luaXRQb3NYICsgZC54O1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmF0dHIoJ2N5JywgKGQ6IE8yU2NhdHRlclBsb3REYXRhLCBpOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gKHN2Z0hlaWdodCAtIGNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbSAtIGQueSk7XG4gICAgICAgICAgfSlcbiAgICAgICAgICAuYXR0cigncicsIChkOiBPMlNjYXR0ZXJQbG90RGF0YSwgaTogYW55KTogbnVtYmVyID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIGQucjtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICAgICAgY29uc3QgX2NvbG9yTnVtID0gaSAlIF9zZXJpZXNOdW1iZXI7XG4gICAgICAgICAgICAgIHJldHVybiBfY29sb3IoX2NvbG9yTnVtKTtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5hdHRyKCdmaWxsLW9wYWNpdHknLCAgX29wYWNpdHkpO1xuXG5cbiAgLy8gLS0tQ0FMTCBidWlsZFRpdGxlLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF90aXRsZURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1RpdGxlKGNkdCk7XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZExlZ2VuZC0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfbGVnZW5kRGlzcGxheSkge1xuICAgICAgY29uc3QgX2xlZ2VuZERhdGFTZXQ6IEFycmF5PE8yTGVnZW5kRGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGF0YVNldEpzb24uc2VyaWVzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgX2xlZ2VuZERhdGFTZXQucHVzaChuZXcgTzJMZWdlbmREYXRhKGRhdGFTZXRKc29uLnNlcmllc1tpXSwgX2NvbG9yKGkpKSk7XG4gICAgICB9XG4gICAgICB0aGlzLmJ1aWxkTGVnZW5kKGNkdCwgX2xlZ2VuZERhdGFTZXQpO1xuICB9XG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkQXhpcy0tLS0tLS0tLS0tLS0tLS0tXG4gIHRoaXMuYnVpbGRZQXhpcyhjZHQpO1xuXG4gIHRoaXMuYnVpbGRYQXhpcyhjZHQpO1xuXG4gIGlmIChfZ3JpZFlEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdZR3JpZChjZHQpO1xuICB9XG4gIGlmIChfZ3JpZFhEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdYR3JpZChjZHQpO1xuICB9XG59XG5cblxuXG5wcml2YXRlIGRyYXdYR3JpZChvMkNvbW1vbjogYW55KTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkWEdyaWQtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgY2R0ID0gbzJDb21tb247XG4gIGNvbnN0IGNvbmZpZ0RhdGEgPSBjZHQuY29uZmlnRGF0YTtcbiAgY29uc3Qgc3ZnQ29udGFpbmVyID0gY2R0LnN2Z0NvbnRhaW5lcjtcblxuICBjb25zdCBfc3RlcFggPSAgY2R0LmdyaWRYU3RlcDtcblxuICBjb25zdCBfbWF4WCA9IGNkdC5tYXhYVmFsdWU7XG4gIGNvbnN0IF9ncmFwaFlTY2FsZSA9IGNkdC5ncmFwaFlTY2FsZTtcbiAgY29uc3QgX2dyYXBoWFNjYWxlID0gY2R0LmdyYXBoWFNjYWxlO1xuICBjb25zdCBfZ3JhcGhXaWR0aCA9IGNkdC5ncmFwaFdpZHRoO1xuICBjb25zdCBfZ3JpZENsYXNzTmFtZSA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLmdyaWQ7XG4gIGNvbnN0IF9heGlzWFNjYWxlID0gZDMuc2NhbGVMaW5lYXIoKVxuICAgICAgICAgICAgICAgICAgLmRvbWFpbihbMCwgX21heFhdKVxuICAgICAgICAgICAgICAgICAgLnJhbmdlKFswLCBfbWF4WCAqIF9ncmFwaFhTY2FsZV0pO1xuICBjb25zdCBfcmFuZ2VYID0gZDMucmFuZ2UoX3N0ZXBYICogX2dyYXBoWFNjYWxlLFxuICAgICAgICAgICAgICAgICAgX21heFggICogX2dyYXBoWFNjYWxlLFxuICAgICAgICAgICAgICAgICAgX3N0ZXBYICogX2dyYXBoWFNjYWxlKTtcblxuICBzdmdDb250YWluZXIuYXBwZW5kKCdnJylcbiAgICAgIC5zZWxlY3RBbGwoJ2xpbmUueCcpXG4gICAgICAuZGF0YShfcmFuZ2VYKVxuICAgICAgLmVudGVyKClcbiAgICAgIC5hcHBlbmQoJ2xpbmUnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgX2dyaWRDbGFzc05hbWUpXG4gICAgICAuYXR0cigneDEnLCAoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgY29uc3QgX3gxID0gY29uZmlnRGF0YS5tYXJnaW4ubGVmdCAgKyBkO1xuICAgICAgICAgIHJldHVybiBfeDE7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ3kxJywgY2R0LnN2Z0hlaWdodCAtIGNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbSlcbiAgICAgIC5hdHRyKCd4MicsIChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICBjb25zdCBfeDIgPSBjb25maWdEYXRhLm1hcmdpbi5sZWZ0ICArIGQ7XG4gICAgICAgICAgcmV0dXJuIF94MjtcbiAgICAgIH0pXG4gICAgICAuYXR0cigneTInLCBjb25maWdEYXRhLm1hcmdpbi50b3AgKyBjb25maWdEYXRhLnRpdGxlLmhlaWdodCk7XG59XG5cbnByaXZhdGUgYnVpbGRYQXhpcyhvMkNvbW1vbjogYW55KTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkWEF4aXMtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgY2R0ID0gbzJDb21tb247XG4gIGNvbnN0IGNvbmZpZ0RhdGEgPSBjZHQuY29uZmlnRGF0YTtcbiAgY29uc3Qgc3ZnQ29udGFpbmVyID0gY2R0LnN2Z0NvbnRhaW5lcjtcblxuICBjb25zdCBfbWF4WCA9IGNkdC5tYXhYVmFsdWU7XG4gIGNvbnN0IF9ncmFwaFhTY2FsZSA9IGNkdC5ncmFwaFhTY2FsZTtcblxuICBjb25zdCBfYXhpc1hTY2FsZSA9IGQzLnNjYWxlTGluZWFyKClcbiAgICAgICAgICAgICAgICAgIC5kb21haW4oWzAsIF9tYXhYXSlcbiAgICAgICAgICAgICAgICAgIC5yYW5nZShbMCwgX21heFggKiBfZ3JhcGhYU2NhbGVdKTtcblxuICBzdmdDb250YWluZXIuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCdjbGFzcycsIGNkdC5heGlzQ2xhc3NOYW1lKVxuICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIGNkdC5heGlzWEJvcmRlclRyYW5zbGF0ZVBvcylcbiAgICAgIC5jYWxsKFxuICAgICAgICAgICAgZDMuYXhpc0JvdHRvbShfYXhpc1hTY2FsZSlcbiAgICAgICk7XG4gICAgICAgICAgICAvLyAgLnNjYWxlKClcbiAgICAgICAgICAgIC8vICAub3JpZW50KGNkdC5heGlzWE9yaWVudClcbiAgICAgICAgICAgIC8vICApO1xufVxuXG5cblxucHJpdmF0ZSBidWlsZFBpZShzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdJbiAgYnVpbGRQaWUtLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgX21heFggPSAxMDA7XG4gIGNvbnN0IF9tYXhZID0gMTAwO1xuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuXG4gIGNvbnN0IF9jb2xvciA9IGNkdC5kZWZhdWx0Q29sb3JGdW5jO1xuICBjb25zdCBfaW5pdFBvc1ggPSBjZHQuZ3JhcGhJbml0WFBvcztcbiAgY29uc3QgX2luaXRQb3NZID0gY2R0LmdyYXBoSW5pdFlQb3M7XG4gIGNvbnN0IF9ncmFwaEhlaWdodCA9IGNkdC5ncmFwaEhlaWdodDtcbiAgY29uc3QgX2dyYXBoV2lkdGggPSBjZHQuZ3JhcGhXaWR0aDtcblxuICBjb25zdCBfb3BhY2l0eSA9IGNvbmZpZ0RhdGEuY29sb3Iub3BhY2l0eTtcbiAgY29uc3QgX3RpdGxlSGVpZ2h0ID0gY29uZmlnRGF0YS50aXRsZS5oZWlnaHQ7XG4gIGNvbnN0IF9sZWZ0TWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4ubGVmdDtcbiAgY29uc3QgX3RvcE1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLnRvcDtcbiAgY29uc3QgX2JvdHRvbU1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbTtcbiAgY29uc3QgX2JldHdlZW5NYXJnaW4gPSBjb25maWdEYXRhLm1hcmdpbi5iZXR3ZWVuO1xuICBjb25zdCBfaW5uZXJSYWRpdXNQZXJjZW50ID0gY2R0LmlubmVyUmFkaXVzUGVyY2VudDtcbiAgY29uc3QgX2dyYXBoQ2VudGVyVHJhbnNsYXRlUG9zID0gY2R0LmdyYXBoQ2VudGVyVHJhbnNsYXRlUG9zO1xuICBjb25zdCBfcGllQ2xhc3NOYW1lID0gY29uZmlnRGF0YS5jbGFzc05hbWUucGllO1xuICBjb25zdCBfcGllVmFsdWVDbGFzc05hbWUgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5waWVOdW07XG4gIGNvbnN0IF9waWVJbm5lclRpdGxlQ2xhc3NOYW1lID0gY29uZmlnRGF0YS5jbGFzc05hbWUucGllSW5uZXJUaXRsZTtcbiAgY29uc3QgX2lubmVyUmFkaXVzVGl0bGVUcmFuc2xhdGVQb3MgPSBjZHQuaW5uZXJSYWRpdXNUaXRsZVRyYW5zbGF0ZVBvcztcbiAgY29uc3QgX2lubmVyUmFkaXVzVGl0bGUgPSBjZHQuaW5uZXJSYWRpdXNUaXRsZTtcbiAgY29uc3QgX3RpdGxlRGlzcGxheSA9IGNvbmZpZ0RhdGEudGl0bGUuZGlzcGxheTtcbiAgY29uc3QgX2xlZ2VuZERpc3BsYXkgPSBjb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5O1xuICBjb25zdCBfbGFiZWxEaXNwbGF5ID0gY29uZmlnRGF0YS5sYWJlbC5kaXNwbGF5O1xuICBjb25zdCBfdmFsdWVEaXNwbGF5ID0gY29uZmlnRGF0YS5waWUudmFsdWUuZGlzcGxheTtcbiAgY29uc3QgX3BlcmNlbnREaXNwbGF5ID0gY29uZmlnRGF0YS5waWUucGVyY2VudC5kaXNwbGF5O1xuICBjb25zdCBfYW5pbWF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZW5hYmxlO1xuICBjb25zdCBfYW5pbWF0aW9uRHVyYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5kdXJhdGlvbjtcblxuICBjb25zdCB3aWR0aCA9IHN2Z1dpZHRoO1xuICBjb25zdCBoZWlnaHQgPSBzdmdIZWlnaHQ7XG5cbiAgY29uc3QgZGF0YVNldDogQXJyYXk8bnVtYmVyPiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgIGluICBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGNvbnN0IF9udW0gPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlO1xuICAgICAgICAgIGRhdGFTZXQucHVzaChfbnVtKTtcbiAgICAgIH1cbiAgfVxuXG4gIGNvbnN0IF9zdW0gPSBkMy5zdW0oZGF0YVNldCk7XG4gIGNvbnN0IHBpZSA9IGQzLnBpZSgpO1xuICBjb25zdCBhcmMgPSBkMy5hcmMoKVxuICAgICAgICAgICAgICAuaW5uZXJSYWRpdXMoX2dyYXBoSGVpZ2h0ICogX2lubmVyUmFkaXVzUGVyY2VudCAvIDEwMClcbiAgICAgICAgICAgICAgLm91dGVyUmFkaXVzKF9ncmFwaEhlaWdodCAvIDIpO1xuXG4gIGNvbnN0IHBpZUVsZW1lbnRzID0gc3ZnQ29udGFpbmVyLnNlbGVjdEFsbCgncGF0aCcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5kYXRhKHBpZShkYXRhU2V0KSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmVudGVyKClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmFwcGVuZCgnZycpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBfZ3JhcGhDZW50ZXJUcmFuc2xhdGVQb3MpO1xuXG5cbiAgY29uc3QgX21ha2VDZW50ZXJUaXRsZSA9ICgpOiBzdHJpbmcgPT4ge1xuICAgICAgICAgIGlmIChfdmFsdWVEaXNwbGF5ICYmIF9wZXJjZW50RGlzcGxheSkge1xuICAgICAgICAgICAgICBjb25zdCBfc3QgPSBfaW5uZXJSYWRpdXNUaXRsZSArICc6JyArIF9zdW0gKyAgJyAoMTAwJSknO1xuICAgICAgICAgICAgICByZXR1cm4gX3N0O1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoX3BlcmNlbnREaXNwbGF5KSB7XG4gICAgICAgICAgICAgIHJldHVybiAnMTAwJSc7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChfdmFsdWVEaXNwbGF5KSB7XG4gICAgICAgICAgICAgIHJldHVybiBfaW5uZXJSYWRpdXNUaXRsZSArICc6JyArIF9zdW07XG4gICAgICAgICAgfVxuICB9O1xuXG4gIGNvbnN0IHRleHRFbGVtZW50cyA9IHN2Z0NvbnRhaW5lci5hcHBlbmQoJ3RleHQnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCBfcGllSW5uZXJUaXRsZUNsYXNzTmFtZSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIF9pbm5lclJhZGl1c1RpdGxlVHJhbnNsYXRlUG9zIClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLnRleHQoX21ha2VDZW50ZXJUaXRsZSk7XG5cbiAgY29uc3QgX2FyYyA9IHBpZUVsZW1lbnRzLmFwcGVuZCgncGF0aCcpXG4gICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIF9waWVDbGFzc05hbWUpXG4gICAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBfY29sb3IoaSk7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC5hdHRyKCdmaWxsLW9wYWNpdHknLCBfb3BhY2l0eSk7XG5cbiAgLy8gIEZvciBkM1ZlcnNpb240IGFuaW1hdGlvbiBpcyBub3QgYXZhaWxhYmxlIG5vd1xuICAvLyAgaWYgKF9hbmltYXRpb24pIHtcbiAgLy8gICAgICBfYXJjLnRyYW5zaXRpb24oKVxuICAvLyAgICAgIC5kdXJhdGlvbihfYW5pbWF0aW9uRHVyYXRpb24pXG4gIC8vICAgICAgLmRlbGF5KChkLGkpPT4ge1xuICAvLyAgICAgICAgICByZXR1cm4gaSAqMTAwMDtcbiAgLy8gICAgICB9KVxuICAvLyAgICAgIC5hdHRyVHdlZW4oJ2QnLChkOiBhbnksaTogbnVtYmVyKSA9PiAge1xuICAvLyAgICAgICAgICBjb25zdCBfaW50ZXJwb2xhdGUgPSBkMy5pbnRlcnBvbGF0ZU9iamVjdChcbiAgLy8gICAgICAgICAgICAgIHsgc3RhcnRBbmdsZTpkLnN0YXJ0QW5nbGUsZW5kQW5nbGU6ZC5zdGFydEFuZ2xlIH1cbiAgLy8gICAgICAgICAgICAgIHsgc3RhcnRBbmdsZTpkLnN0YXJ0QW5nbGUsZW5kQW5nbGU6ZC5lbmRBbmdsZSB9XG4gIC8vICAgICAgICAgIClcbiAgLy8gICAgICAgICAgcmV0dXJuICh0KSB7XG4gIC8vICAgICAgICAgICAgICByZXR1cm4gYXJjKF9pbnRlcnBvbGF0ZSh0KSk7XG4gIC8vICAgICAgICAgIH1cbiAgLy8gICAgICB9KVxuICAvLyAgfVxuICAvLyAgZWxzZXtcbiAgLy8gICAgICBfYXJjLmF0dHIoJ2QnLGFyYyk7XG4gIC8vICB9XG4gIF9hcmMuYXR0cignZCcsIGFyYyk7XG5cbiAgcGllRWxlbWVudHMuYXBwZW5kKCd0ZXh0JylcbiAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgX3BpZVZhbHVlQ2xhc3NOYW1lKVxuICAgICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyBhcmMuY2VudHJvaWQoZCkgKyAnKSc7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC50ZXh0KChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgaWYgKF92YWx1ZURpc3BsYXkgJiYgX3BlcmNlbnREaXNwbGF5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgX3BlcmNlbnRTdCA9IFN0cmluZyhNYXRoLmNlaWwoZC52YWx1ZSAvIF9zdW0gICogMTAwKSk7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgX3N0ID0gU3RyaW5nKGQudmFsdWUpICsgJyAoJyArIF9wZXJjZW50U3QgKyAnJSknO1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfc3Q7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBpZiAoX3BlcmNlbnREaXNwbGF5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgX3BlcmNlbnRTdCA9IFN0cmluZyhNYXRoLmNlaWwoZC52YWx1ZSAvIF9zdW0gICogMTAwKSk7XG4gICAgICAgICAgICAgICAgICAgICAgY29uc3QgX3N0ID0gX3BlcmNlbnRTdCArICclJztcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3N0O1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgaWYgKF92YWx1ZURpc3BsYXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZC52YWx1ZTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSk7XG5cbiAgLy8gLS0tQ0FMTCBidWlsZFRpdGxlLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF90aXRsZURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1RpdGxlKGNkdCk7XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZExlZ2VuZC0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfbGVnZW5kRGlzcGxheSkge1xuICAgICAgY29uc3QgX2xlZ2VuZERhdGFTZXQ6IEFycmF5PE8yTGVnZW5kRGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgX2xlZ2VuZERhdGFTZXQucHVzaChuZXcgTzJMZWdlbmREYXRhKGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZSwgX2NvbG9yKGkpKSk7XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5idWlsZExlZ2VuZChjZHQsIF9sZWdlbmREYXRhU2V0KTtcbiAgfVxufVxuXG5cblxucHJpdmF0ZSBidWlsZEJhcihzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdJbiAgYnVpbGRCYXItLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgX3lEYXRhU2V0OiBBcnJheTxudW1iZXI+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGZvciAoY29uc3QgaiBpbiBkYXRhU2V0SnNvbi5kYXRhW2ldLnkpIHtcbiAgICAgICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbaV0ueS5oYXNPd25Qcm9wZXJ0eShqKSkge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX3kgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnlbal07XG4gICAgICAgICAgICAgICAgICBfeURhdGFTZXQucHVzaChfeSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gIH1cblxuICBsZXQgX21heFggPSAwO1xuICBsZXQgX21heFkgPSAwO1xuICBfbWF4WSA9IGQzLm1heChfeURhdGFTZXQpO1xuICBfbWF4WCA9IDEwMDtcbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcblxuICBjb25zdCBfYmFyVmFsdWVDbGFzcyA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLmJhclZhbHVlO1xuICBjb25zdCBfY29sb3IgPSBjZHQuZGVmYXVsdENvbG9yRnVuYztcbiAgY29uc3QgX3Nlcmllc051bSA9ICBkYXRhU2V0SnNvbi5zZXJpZXMubGVuZ3RoO1xuICBjb25zdCBfY29sdW1uTnVtID0gIF95RGF0YVNldC5sZW5ndGg7XG4gIGNvbnN0IF9pbml0UG9zWCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfaW5pdFBvc1kgPSBjZHQuZ3JhcGhJbml0WVBvcztcbiAgY29uc3QgX2dyYXBoSGVpZ2h0ID0gY2R0LmdyYXBoSGVpZ2h0O1xuICBjb25zdCBfZ3JhcGhXaWR0aCA9IGNkdC5ncmFwaFdpZHRoO1xuICBjb25zdCBfbWF4WVZhbHVlID0gY2R0Lm1heFlWYWx1ZTtcbiAgY29uc3QgX29wYWNpdHkgPSBjb25maWdEYXRhLmNvbG9yLm9wYWNpdHk7XG4gIGNvbnN0IF90aXRsZUhlaWdodCA9IGNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0O1xuICBjb25zdCBfdGl0bGVEaXNwbGF5ID0gY29uZmlnRGF0YS50aXRsZS5kaXNwbGF5O1xuICBjb25zdCBfbGVmdE1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQ7XG4gIGNvbnN0IF90b3BNYXJnaW4gPSBjb25maWdEYXRhLm1hcmdpbi50b3A7XG4gIGNvbnN0IF9ib3R0b21NYXJnaW4gPSBjb25maWdEYXRhLm1hcmdpbi5ib3R0b207XG4gIGNvbnN0IF9iZXR3ZWVuTWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4uYmV0d2VlbjtcbiAgY29uc3QgX2xlZ2VuZERpc3BsYXkgPSBjb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5O1xuICBjb25zdCBfbGFiZWxEaXNwbGF5ID0gY29uZmlnRGF0YS5sYWJlbC5kaXNwbGF5O1xuICBjb25zdCBfZ3JpZFlEaXNwbGF5ID0gY29uZmlnRGF0YS5ncmlkLnkuZGlzcGxheTtcbiAgY29uc3QgX2FuaW1hdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmVuYWJsZTtcbiAgY29uc3QgX2FuaW1hdGlvbkR1cmF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZHVyYXRpb247XG5cbiAgY29uc3QgX2JhcldpZHRoID0gKF9ncmFwaFdpZHRoIC0gKF9iZXR3ZWVuTWFyZ2luICogX2NvbHVtbk51bSAvIF9zZXJpZXNOdW0pKSAvICBfY29sdW1uTnVtO1xuICBjb25zdCBfY29sdW1uV2lkdGggPSAoX2dyYXBoV2lkdGggLyBfY29sdW1uTnVtKSA7XG5cbiAgY29uc3QgX2dyYXBoWVNjYWxlID0gY2R0LmdyYXBoWVNjYWxlO1xuXG4gIGNvbnN0IHlCYXJTY2FsZSA9IGQzLnNjYWxlTGluZWFyKClcbiAgICAgICAgICAgICAgICAgIC5kb21haW4oWzAsIF9tYXhZXSlcbiAgICAgICAgICAgICAgICAgIC5yYW5nZShbX21heFkgKiBfZ3JhcGhZU2NhbGUsIDBdKTtcblxuICBjb25zdCBfYmFyUGFkZGluZyA9IF9iZXR3ZWVuTWFyZ2luO1xuXG5cblxuXG4gIGNvbnN0IGdycEdyYXBoID0gc3ZnQ29udGFpbmVyLnNlbGVjdEFsbCgnZycpXG4gICAgICAuZGF0YShfeURhdGFTZXQpXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgnZycpXG4gICAgICAuYXR0cigndHJhbnNmb3JtJywgKGQ6IGFueSwgaTogbnVtYmVyKTogc3RyaW5nID0+IHtcbiAgICAgICAgICBjb25zdCBfcGFkZGluZyA9ICgoaSAlIF9zZXJpZXNOdW0pID09PSAwKSA/IF9iYXJQYWRkaW5nIDogMDtcbiAgICAgICAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgKF9wYWRkaW5nICsgX2NvbHVtbldpZHRoICogaSkgKyAnKSc7XG4gICAgICB9KVxuICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgIGNvbnN0IF9yZW1uYW50ID0gKGkgJSBfc2VyaWVzTnVtKTtcbiAgICAgICAgICByZXR1cm4gX2NvbG9yKF9yZW1uYW50KTtcbiAgICAgIH0pXG4gICAgICAuYXR0cignZmlsbC1vcGFjaXR5JywgX29wYWNpdHkpO1xuXG4gIGNvbnN0IF9yZWN0ID0gIGdycEdyYXBoLmFwcGVuZCgncmVjdCcpO1xuICBpZiAoX2FuaW1hdGlvbikge1xuICAgICAgX3JlY3QuYXR0cigneCcsIF9sZWZ0TWFyZ2luKVxuICAgICAgLmF0dHIoJ2hlaWdodCcsIDApXG4gICAgICAuYXR0cigneScsIChkOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICAgIHJldHVybiBfaW5pdFBvc1k7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ3dpZHRoJywgX2JhcldpZHRoIC0gX2JhclBhZGRpbmcpXG4gICAgICAudHJhbnNpdGlvbigpXG4gICAgICAuZHVyYXRpb24oX2FuaW1hdGlvbkR1cmF0aW9uKVxuICAgICAgLmF0dHIoJ3knLCAoZDogYW55KTogbnVtYmVyID0+IHtcbiAgICAgICAgICByZXR1cm4geUJhclNjYWxlKGQpICsgX2luaXRQb3NZO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCAoZDogYW55KTogbnVtYmVyID0+IHtcbiAgICAgICAgICByZXR1cm4gX2dyYXBoSGVpZ2h0IC0geUJhclNjYWxlKGQpIDtcbiAgICAgIH0pO1xuICB9IGVsc2Uge1xuICAgICAgX3JlY3QuYXR0cigneCcsIF9sZWZ0TWFyZ2luKVxuICAgICAgLmF0dHIoJ3knLCAoZDogYW55KTogbnVtYmVyID0+IHtcbiAgICAgICAgICByZXR1cm4geUJhclNjYWxlKGQpICsgX2luaXRQb3NZO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCd3aWR0aCcsIF9iYXJXaWR0aCAtIF9iYXJQYWRkaW5nKVxuICAgICAgLmF0dHIoJ2hlaWdodCcsIChkOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICAgIHJldHVybiBfZ3JhcGhIZWlnaHQgLSB5QmFyU2NhbGUoZCk7XG4gICAgICB9KTtcbiAgfVxuXG4gIGNvbnN0IHRleHRCYXJWYWx1ZSA9IGdycEdyYXBoLmFwcGVuZCgndGV4dCcpO1xuICB0ZXh0QmFyVmFsdWVcbiAgICAgIC5hdHRyKCdjbGFzcycsIF9iYXJWYWx1ZUNsYXNzKVxuICAgICAgLmF0dHIoJ3gnLCBfbGVmdE1hcmdpbilcbiAgICAgIC5hdHRyKCd5JywgKGQ6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgIHJldHVybiB5QmFyU2NhbGUoZCkgKyBfaW5pdFBvc1k7XG4gICAgICB9KVxuICAgICAgLnRleHQoKGQ6IGFueSk6IHN0cmluZyA9PiB7XG4gICAgICAgIHJldHVybiBkIDtcbiAgICAgIH0pO1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkQXhpcy0tLS0tLS0tLS0tLS0tLS0tXG4gIHRoaXMuYnVpbGRZQXhpcyhjZHQpO1xuXG4gIC8vICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gIC0tLUNBTEwgZHJhd1hBeGlzTGFiZWwtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX2xhYmVsRGlzcGxheSkge1xuICAgICAgY29uc3QgX2xhYmVsQXJyYXk6ICBBcnJheTxzdHJpbmc+ID0gbmV3IEFycmF5KCk7XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgIF9sYWJlbEFycmF5LnB1c2goZGF0YVNldEpzb24uZGF0YVtpXS54KTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLmRyYXdYQXhpc0xhYmVsKGNkdCwgX2xhYmVsQXJyYXksIENoYXJ0Q29uc3QuQkFSX0NIQVJUX1RZUEVfTkFNRSk7XG4gIH1cblxuICB0aGlzLmRyYXdYQmFzZUxpbmUoY2R0KTtcblxuICAvLyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vICAtLS1DQUxMIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3QgX2xlZ2VuZERhdGFTZXQ6IEFycmF5PE8yTGVnZW5kRGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLnNlcmllcykge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLnNlcmllcy5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICBfbGVnZW5kRGF0YVNldC5wdXNoKG5ldyBPMkxlZ2VuZERhdGEoZGF0YVNldEpzb24uc2VyaWVzW2ldLCBfY29sb3IoaSkpKTtcbiAgICAgIH1cbiAgfVxuICB0aGlzLmJ1aWxkTGVnZW5kKGNkdCwgX2xlZ2VuZERhdGFTZXQpO1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkVGl0bGUtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX3RpdGxlRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3VGl0bGUoY2R0KTtcbiAgfVxuXG4gIGlmIChfZ3JpZFlEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdZR3JpZChjZHQpO1xuICB9XG5cbn1cblxuXG5wcml2YXRlIGJ1aWxkTGluZShzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZFRlc3QtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgX2dyb3VwTWF4WTogQXJyYXk8bnVtYmVyPiA9IG5ldyBBcnJheSgpO1xuXG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGxldCBfZ01heFkgPSAwO1xuICAgICAgICAgIGZvciAoY29uc3QgaiBpbiBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlKSB7XG4gICAgICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlLmhhc093blByb3BlcnR5KGopKSB7XG4gICAgICAgICAgICAgICAgICBpZiAoX2dNYXhZIDwgZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS55KSB7XG4gICAgICAgICAgICAgICAgICAgICAgX2dNYXhZID0gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS55O1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIF9ncm91cE1heFkucHVzaChfZ01heFkpIDtcbiAgICAgIH1cbiAgfVxuICBsZXQgX21heFggPSAwO1xuICBsZXQgX21heFkgPSAwO1xuICBfbWF4WSA9IGQzLm1heChfZ3JvdXBNYXhZKTtcbiAgX21heFggPSAxMDA7XG5cbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcbiAgY29uc3QgX2NvbG9yID0gY2R0LmRlZmF1bHRDb2xvckZ1bmM7XG5cbiAgY29uc3QgX2NvbHVtbk51bSA9IGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWUubGVuZ3RoIDtcbiAgY29uc3QgX2NvbHVtbldpZHRoID0gY2R0LmdyYXBoV2lkdGggLyBfY29sdW1uTnVtO1xuXG4gIGNvbnNvbGUubG9nKF9jb2x1bW5XaWR0aCk7XG5cbiAgaWYgKGNvbmZpZ0RhdGEuZ3JpZC55LmRpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1lHcmlkKGNkdCk7XG4gIH1cblxuICAvLyAgTzJJZFZhbHVlRGF0YVxuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBjb25zdCBfbGluZUFycmF5OiBBcnJheTxPMklkVmFsdWVEYXRhPiA9IG5ldyBBcnJheSgpO1xuICAgICAgICAgIGZvciAoY29uc3QgaiBpbiBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlKSB7XG4gICAgICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlLmhhc093blByb3BlcnR5KGopKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBpZFZhbHVlID0gbmV3IE8ySWRWYWx1ZURhdGEocGFyc2VJbnQoaiwgMTApLCBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLnkpO1xuICAgICAgICAgICAgICAgICAgX2xpbmVBcnJheS5wdXNoKGlkVmFsdWUpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICAgIGNvbnN0IG51bSA9IHBhcnNlSW50KGksIDEwKTtcbiAgICAgICAgICB0aGlzLmRyYXdTaW5nbGVMaW5lKGNkdCwgX2xpbmVBcnJheSwgbnVtKTtcbiAgICAgIH1cbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkVGl0bGUtLS0tLS0tLS0tLS0tLS0tLVxuICB0aGlzLmRyYXdUaXRsZShjZHQpO1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkQXhpcy0tLS0tLS0tLS0tLS0tLS0tXG4gIHRoaXMuYnVpbGRZQXhpcyhjZHQpO1xuXG4gIHRoaXMuZHJhd1hCYXNlTGluZShjZHQpO1xuXG4gIC8vICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gIC0tLUNBTEwgZHJhd1hBeGlzTGFiZWwtLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCBfbGFiZWxBcnJheTogIEFycmF5PHN0cmluZz4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWUpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgX2xhYmVsQXJyYXkucHVzaChkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlW2ldLngpO1xuICAgICAgfVxuICB9XG4gIHRoaXMuZHJhd1hBeGlzTGFiZWwoY2R0LCBfbGFiZWxBcnJheSwgQ2hhcnRDb25zdC5MSU5FX0NIQVJUX1RZUEVfTkFNRSk7XG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBidWlsZExlZ2VuZC0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0IF9sZWdlbmREYXRhU2V0OiBBcnJheTxPMkxlZ2VuZERhdGE+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICBfbGVnZW5kRGF0YVNldC5wdXNoKG5ldyBPMkxlZ2VuZERhdGEoZGF0YVNldEpzb24uZGF0YVtpXS5uYW1lLCBfY29sb3IoaSkpKTtcbiAgICAgIH1cbiAgfVxuICB0aGlzLmJ1aWxkTGVnZW5kKGNkdCwgX2xlZ2VuZERhdGFTZXQpO1xuXG59XG5cblxuXG5cbnByaXZhdGUgZHJhd1NpbmdsZUxpbmUobzJDb21tb246IGFueSwgZGF0YVNldDogYW55LCBsaW5lTnVtOiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gZHJhd1NpbmdsZUxpbmUtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc29sZS5sb2coZGF0YVNldCk7XG4gIGNvbnN0IGNkdCA9IG8yQ29tbW9uO1xuICBjb25zdCBjb25maWdEYXRhID0gY2R0LmNvbmZpZ0RhdGE7XG4gIGNvbnN0IHN2Z0NvbnRhaW5lciA9IGNkdC5zdmdDb250YWluZXI7XG5cbiAgY29uc3QgX21heFggPSBjZHQubWF4WFZhbHVlO1xuICBjb25zdCBfaW5pdFhQb3MgPSBjZHQuYXhpc1hMYWJlbEluaXRYUG9zO1xuICBjb25zdCBfaW5pdFlQb3MgPSBjZHQuYXhpc1hMYWJlbEluaXRZUG9zO1xuICBjb25zdCBfY29sdW1uTnVtID0gZGF0YVNldC5sZW5ndGg7XG4gIGNvbnN0IF9jb2x1bW5XaWR0aCA9IGNkdC5ncmFwaFdpZHRoIC8gKF9jb2x1bW5OdW0gLSAxKTtcbiAgY29uc3QgX2NvbG9yID0gZDMuc2NhbGVPcmRpbmFsKGQzLnNjaGVtZUNhdGVnb3J5MTApO1xuXG4gIGNvbnN0IF9saW5lQ2xhc3NOYW1lID0gY29uZmlnRGF0YS5jbGFzc05hbWUubXVsdGlMaW5lUHJlZml4ICsgU3RyaW5nKGxpbmVOdW0pO1xuICBjb25zdCBfbGVmdE1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQ7XG4gIGNvbnN0IF9ib3R0b21NYXJnaW4gPSBjb25maWdEYXRhLm1hcmdpbi5ib3R0b207XG5cbiAgY29uc3QgX3lTY2FsZSA9IGNkdC5ncmFwaFlTY2FsZTtcblxuXG4gIGNvbnN0IGxpbmUgPSBkMy5saW5lKClcbiAgICAgIC5jdXJ2ZShkMy5jdXJ2ZUxpbmVhcilcbiAgICAgIC54KCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIF9sZWZ0TWFyZ2luICsgZC5pZCAqIF9jb2x1bW5XaWR0aDtcbiAgICAgIH0pXG4gICAgICAueSggKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiBjZHQuc3ZnSGVpZ2h0IC0gX2JvdHRvbU1hcmdpbiAtICggZC52YWx1ZSAqIF95U2NhbGUpIDtcbiAgICAgIH0pO1xuXG4gIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ3BhdGgnKVxuICAgICAgICAgIC5hdHRyKCdjbGFzcycsIF9saW5lQ2xhc3NOYW1lKVxuICAgICAgICAgIC5hdHRyKCdkJywgbGluZShkYXRhU2V0KSk7XG4gICAgICAgICAgLy8gIC5hdHRyKCd0cmFuc2Zvcm0nLCBjZHQuYXhpc1RyYW5zbGF0ZVBvcylcbn1cblxuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIC0tLUJ1aWxkIExlZ2VuZCAgLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5wcml2YXRlIGJ1aWxkTGVnZW5kKG8yQ29tbW9uOiBhbnksIF9sZWdlbmREYXRhU2V0OiBhbnkpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRMZWdlbmQtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgLy8gIG1heFZhbHVlcyBhcmUgbWVhbmluZ2xlc3NcbiAgY29uc3QgY2R0ID0gbzJDb21tb247XG4gIGNvbnN0IGNvbmZpZ0RhdGEgPSBjZHQuY29uZmlnRGF0YTtcbiAgY29uc3Qgc3ZnQ29udGFpbmVyID0gY2R0LnN2Z0NvbnRhaW5lcjtcbiAgLy8gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihjb25maWdEYXRhLCAxMDAsIDEwMCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG4gIGNvbnN0IGxlZ2VuZFJlY3RTaXplID0gY29uZmlnRGF0YS5sZWdlbmQucmVjdFdpZHRoO1xuICBjb25zdCBsZWdlbmRTcGFjaW5nID0gMTA7XG4gIGNvbnN0IHlTcGFjaW5nID0gY29uZmlnRGF0YS5sZWdlbmQueVNwYWNpbmc7XG4gIGNvbnN0IGluaXRQb3NYID0gY2R0LmxlZ2VuZEluaXRYUG9zO1xuICBjb25zdCBpbml0UG9zWSA9IGNkdC5sZWdlbmRJbml0WVBvcztcbiAgY29uc3Qgb3BhY2l0eSA9IGNvbmZpZ0RhdGEuY29sb3Iub3BhY2l0eTtcblxuICBjb25zdCBncnBMZWdlbmQgPSBzdmdDb250YWluZXIuYXBwZW5kKCdnJylcbiAgICAgICAgICAgICAgLnNlbGVjdEFsbCgnZycpXG4gICAgICAgICAgICAgIC5kYXRhKF9sZWdlbmREYXRhU2V0KVxuICAgICAgICAgICAgICAuZW50ZXIoKVxuICAgICAgICAgICAgICAuYXBwZW5kKCdnJylcbiAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgJ2xlZ2VuZCcpXG4gICAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZDogTzJMZWdlbmREYXRhLCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGhlaWdodCA9IGxlZ2VuZFJlY3RTaXplICsgeVNwYWNpbmc7XG4gICAgICAgICAgICAgICAgICBjb25zdCB4ID0gaW5pdFBvc1g7XG4gICAgICAgICAgICAgICAgICBjb25zdCB5ID0gaSAqIGhlaWdodCArIGluaXRQb3NZIDtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyB4ICsgJywgJyArIHkgKyAnKSc7XG4gICAgICAgICAgICAgIH0pO1xuXG4gIGdycExlZ2VuZC5hcHBlbmQoJ3JlY3QnKVxuICAgICAgLmF0dHIoJ3dpZHRoJywgbGVnZW5kUmVjdFNpemUpXG4gICAgICAuYXR0cignaGVpZ2h0JywgbGVnZW5kUmVjdFNpemUpXG4gICAgICAuc3R5bGUoJ2ZpbGwnLCAoZDogTzJMZWdlbmREYXRhKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGQuY29sb3I7XG4gICAgICB9KVxuICAgICAgLnN0eWxlKCdzdHJva2UnLCAoZDogTzJMZWdlbmREYXRhKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGQuY29sb3I7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ2ZpbGwtb3BhY2l0eScsIG9wYWNpdHkpO1xuXG4gIGdycExlZ2VuZC5hcHBlbmQoJ3RleHQnKVxuICAgICAgLmF0dHIoJ3gnLCBsZWdlbmRSZWN0U2l6ZSArIGxlZ2VuZFNwYWNpbmcpXG4gICAgICAuYXR0cigneScsIGxlZ2VuZFJlY3RTaXplKVxuICAgICAgLnRleHQoKGQ6IE8yTGVnZW5kRGF0YSkgPT4ge1xuICAgICAgICAgIHJldHVybiBkLnRpdGxlO1xuICAgICAgfSk7XG59XG5cblxucHJpdmF0ZSBkcmF3WEF4aXNMYWJlbChvMkNvbW1vbjogYW55LCBsYWJlbERhdGFTZXQ6IGFueSwgY2hhcnRUeXBlOiBzdHJpbmcpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gZHJhd1hBeGlzTGFiZWwtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgY2R0ID0gbzJDb21tb247XG4gIGNvbnN0IGNvbmZpZ0RhdGEgPSBjZHQuY29uZmlnRGF0YTtcbiAgY29uc3Qgc3ZnQ29udGFpbmVyID0gY2R0LnN2Z0NvbnRhaW5lcjtcblxuICAvLyBjb25zdCBfbWF4WCA9IGNkdC5tYXhYVmFsdWU7XG4gIGNvbnN0IF9pbml0WFBvcyA9IGNkdC5heGlzWExhYmVsSW5pdFhQb3M7XG4gIGNvbnN0IF9pbml0WVBvcyA9IGNkdC5heGlzWExhYmVsSW5pdFlQb3M7XG5cbiAgY29uc3QgX2NvbHVtbk51bSA9IGxhYmVsRGF0YVNldC5sZW5ndGg7XG4gIGxldCBfY29sdW1uV2lkdGggPSBjZHQuZ3JhcGhXaWR0aCAvIF9jb2x1bW5OdW07XG4gIGlmICggY2hhcnRUeXBlID09PSBDaGFydENvbnN0LkxJTkVfQ0hBUlRfVFlQRV9OQU1FKSB7XG4gICAgICBfY29sdW1uV2lkdGggPSBjZHQuZ3JhcGhXaWR0aCAvIChfY29sdW1uTnVtIC0gMSk7XG4gIH1cblxuICBjb25zdCBncnBMYWJlbCA9IHN2Z0NvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgICAgICAgICAuc2VsZWN0QWxsKCdnJylcbiAgICAgICAgICAgICAgLmRhdGEobGFiZWxEYXRhU2V0KVxuICAgICAgICAgICAgICAuZW50ZXIoKVxuICAgICAgICAgICAgICAuYXBwZW5kKCdnJylcbiAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgY29uZmlnRGF0YS5heGlzWFRleHQpXG4gICAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IF94ID0gX2luaXRYUG9zICsgX2NvbHVtbldpZHRoICogaTtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IF95ID0gX2luaXRZUG9zIDtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyBfeCArICcsICcgKyBfeSArICcpJztcbiAgICAgICAgICAgICAgfSk7XG5cbiAgZ3JwTGFiZWwuYXBwZW5kKCd0ZXh0JylcbiAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgY29uZmlnRGF0YS5jbGFzc05hbWUuYXhpc1hUZXh0KVxuICAgICAgICAgICAgICAudGV4dCgoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBkO1xuICAgICAgICAgICAgICB9KTtcblxuXG59XG5cblxucHJpdmF0ZSBkcmF3WEJhc2VMaW5lKG8yQ29tbW9uOiBhbnkpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gZHJhd1hCYXNlTGluZS0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3Qgc3ZnQ29udGFpbmVyID0gY2R0LnN2Z0NvbnRhaW5lcjtcblxuICBzdmdDb250YWluZXIuYXBwZW5kKCdyZWN0JylcbiAgICAgIC5hdHRyKCdjbGFzcycsIGNkdC5heGlzWEJvcmRlckxpbmVDbGFzc05hbWUpXG4gICAgICAuYXR0cignd2lkdGgnLCBjZHQuYXhpc1hCb3JkZXJXaWR0aClcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCBjZHQuYXhpc1hCb3JkZXJMaW5lV2lkdGgpXG4gICAgICAuYXR0cigndHJhbnNmb3JtJywgY2R0LmF4aXNYQm9yZGVyVHJhbnNsYXRlUG9zKTtcblxufVxuXG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gLS0tQnVpbGQgQXhpcyAgLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5wcml2YXRlIGJ1aWxkWUF4aXMobzJDb21tb246IGFueSk6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZFlBeGlzLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IGNkdCA9IG8yQ29tbW9uO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIGNvbnN0IF9tYXhZID0gY2R0Lm1heFlWYWx1ZTtcbiAgY29uc3QgX2dyYXBoWVNjYWxlID0gY2R0LmdyYXBoWVNjYWxlO1xuXG4gIGNvbnN0IF9heGlzWVNjYWxlID0gZDMuc2NhbGVMaW5lYXIoKVxuICAgICAgICAgICAgICAgICAgLmRvbWFpbihbMCwgX21heFldKVxuICAgICAgICAgICAgICAgICAgLnJhbmdlKFtfbWF4WSAqIF9ncmFwaFlTY2FsZSwgMF0pO1xuXG4gIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgY2R0LmF4aXNDbGFzc05hbWUpXG4gICAgICAuYXR0cigndHJhbnNmb3JtJywgY2R0LmF4aXNUcmFuc2xhdGVQb3MpXG4gICAgICAuY2FsbChcbiAgICAgICAgICAgIGQzLmF4aXNMZWZ0KF9heGlzWVNjYWxlKVxuICAgICAgICAgICAgKTtcblxufVxuXG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gLS0tIGRyYXdUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG5wcml2YXRlIGRyYXdUaXRsZShvMkNvbW1vbjogYW55KTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGRyYXdUaXRsZS0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3QgY29uZmlnRGF0YSA9IGNkdC5jb25maWdEYXRhO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIGNvbnN0IF90aXRsZSA9IGNvbmZpZ0RhdGEudGl0bGUubmFtZTtcbiAgY29uc3QgX3hQb3MgPSBjZHQudGl0bGVJbml0WFBvcztcbiAgY29uc3QgX3lQb3MgPSBjZHQudGl0bGVJbml0WVBvcztcbiAgY29uc3QgX3RpdGxlQ2xhc3NOYW1lID0gY29uZmlnRGF0YS50aXRsZS5jbGFzc05hbWU7XG5cbiAgc3ZnQ29udGFpbmVyLmFwcGVuZCgndGV4dCcpXG4gICAgICAuYXR0cignY2xhc3MnLCBfdGl0bGVDbGFzc05hbWUpXG4gICAgICAuYXR0cigneCcsIF94UG9zKVxuICAgICAgLmF0dHIoJ3knLCBfeVBvcylcbiAgICAgIC50ZXh0KF90aXRsZSk7XG59XG5cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS1kcmF3R3JpZCAgLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5wcml2YXRlIGRyYXdZR3JpZChvMkNvbW1vbjogYW55KTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkWUdyaWQtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgY2R0ID0gbzJDb21tb247XG4gIGNvbnN0IGNvbmZpZ0RhdGEgPSBjZHQuY29uZmlnRGF0YTtcbiAgY29uc3Qgc3ZnQ29udGFpbmVyID0gY2R0LnN2Z0NvbnRhaW5lcjtcblxuICBjb25zdCBfc3RlcFkgPSAgY2R0LmdyaWRZU3RlcDtcbiAgY29uc3QgX21heFkgPSBjZHQubWF4WVZhbHVlO1xuICBjb25zdCBfZ3JhcGhZU2NhbGUgPSBjZHQuZ3JhcGhZU2NhbGU7XG4gIGNvbnN0IF9ncmlkQ2xhc3NOYW1lID0gY29uZmlnRGF0YS5jbGFzc05hbWUuZ3JpZDtcbiAgY29uc3QgX3JhbmdlWSA9IGQzLnJhbmdlKF9zdGVwWSAqIF9ncmFwaFlTY2FsZSxcbiAgICAgICAgICAgICAgICAgIF9tYXhZICogX2dyYXBoWVNjYWxlLFxuICAgICAgICAgICAgICAgICAgX3N0ZXBZICogX2dyYXBoWVNjYWxlKTtcblxuICBzdmdDb250YWluZXIuYXBwZW5kKCdnJylcbiAgICAgIC5zZWxlY3RBbGwoJ2xpbmUueScpXG4gICAgICAuZGF0YShfcmFuZ2VZKVxuICAgICAgLmVudGVyKClcbiAgICAgIC5hcHBlbmQoJ2xpbmUnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgX2dyaWRDbGFzc05hbWUpXG4gICAgICAuYXR0cigneDEnLCBjb25maWdEYXRhLm1hcmdpbi5sZWZ0KVxuICAgICAgLmF0dHIoJ3kxJywgKCBkOiBhbnksIGk6IG51bWJlciApID0+ICB7XG4gICAgICAgICAgY29uc3QgX3kxID0gY2R0LnN2Z0hlaWdodCAtIGNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbSAtIGQ7XG4gICAgICAgICAgcmV0dXJuIF95MTtcbiAgICAgIH0pXG4gICAgICAuYXR0cigneDInLCBjb25maWdEYXRhLm1hcmdpbi5sZWZ0ICsgY2R0LmF4aXNYQm9yZGVyV2lkdGgpXG4gICAgICAuYXR0cigneTInLCAoIGQ6IGFueSwgaTogbnVtYmVyICkgPT4gIHtcbiAgICAgICAgICBjb25zdCBfeTEgPSBjZHQuc3ZnSGVpZ2h0IC0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tIC0gZDtcbiAgICAgICAgICByZXR1cm4gX3kxO1xuICAgICAgfSk7XG4gIH1cbn0iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmc2TzJDaGFydENvbXBvbmVudCB9IGZyb20gJy4vbmc2LW8yLWNoYXJ0LmNvbXBvbmVudCc7XG5cbkBOZ01vZHVsZSh7XG4gIGltcG9ydHM6IFtcbiAgXSxcbiAgZGVjbGFyYXRpb25zOiBbTmc2TzJDaGFydENvbXBvbmVudF0sXG4gIGV4cG9ydHM6IFtOZzZPMkNoYXJ0Q29tcG9uZW50XVxufSlcbmV4cG9ydCBjbGFzcyBOZzZPMkNoYXJ0TW9kdWxlIHsgfVxuIl0sIm5hbWVzIjpbImQzLnNjYWxlT3JkaW5hbCIsImQzLnNjaGVtZUNhdGVnb3J5MjAiLCJkMy5zY2hlbWVDYXRlZ29yeTEwIiwiZDMuc2VsZWN0IiwiQ2hhcnRDb25zdC5MSU5FX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuQkFSX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuUElFX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuU0NBVFRFUl9QTE9UX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuSElTVE9HUkFNX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuU1RBQ0tfQkFSX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuR0VPX01BUF9DSEFSVF9UWVBFX05BTUUiLCJDaGFydENvbnN0LkdFT19PUlRIT0dSQVBISUNfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5UUkVFX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuUEFDS19MQVlPVVRfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5DSE9ST1BMRVRIX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuRk9SQ0VfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5UUkVFX01BUF9DSEFSVF9UWVBFX05BTUUiLCJDaGFydENvbnN0LlNBTktFWV9DSEFSVF9UWVBFX05BTUUiLCJkMy5mb3JtYXQiLCJkMy5zY2FsZUxpbmVhciIsImQzLmhpc3RvZ3JhbSIsImQzLm1heCIsImQzLmZvcmNlU2ltdWxhdGlvbiIsImQzLmZvcmNlTGluayIsImQzLmZvcmNlTWFueUJvZHkiLCJkMy5mb3JjZUNlbnRlciIsImQzLmRyYWciLCJkMy5ldmVudCIsImQzLmludGVycG9sYXRlSHNsIiwiZDMuZ2VvUGF0aCIsImQzLmdlb01lcmNhdG9yIiwiZDMuanNvbiIsImQzLnBhY2siLCJkMy5oaWVyYXJjaHkiLCJkMy50cmVlIiwiZDMuZ2VvT3J0aG9ncmFwaGljIiwiZDMudGltZXIiLCJkMy5zdGFjayIsImQzLnJhbmdlIiwiZDMuYXhpc0JvdHRvbSIsImQzLnN1bSIsImQzLnBpZSIsImQzLmFyYyIsImQzLmxpbmUiLCJkMy5jdXJ2ZUxpbmVhciIsImQzLmF4aXNMZWZ0IiwiQ29tcG9uZW50IiwiRWxlbWVudFJlZiIsIklucHV0IiwiTmdNb2R1bGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQSx5QkFBYSxvQkFBb0IsR0FBSSxNQUFNLENBQUM7QUFDNUMseUJBQWEsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO0FBQ3pDLHlCQUFhLG1CQUFtQixHQUFHLEtBQUssQ0FBQztBQUN6Qyx5QkFBYSw0QkFBNEIsR0FBRyxhQUFhLENBQUM7QUFDMUQseUJBQWEseUJBQXlCLEdBQUcsV0FBVyxDQUFDO0FBQ3JELHlCQUFhLHlCQUF5QixHQUFHLFVBQVUsQ0FBQztBQUNwRCx5QkFBYSx1QkFBdUIsR0FBRyxRQUFRLENBQUM7QUFDaEQseUJBQWEsZ0NBQWdDLEdBQUcsaUJBQWlCLENBQUM7QUFDbEUseUJBQWEsd0JBQXdCLEdBQUcsU0FBUyxDQUFDO0FBQ2xELHlCQUFhLDJCQUEyQixHQUFHLFlBQVksQ0FBQztBQUN4RCx5QkFBYSwwQkFBMEIsR0FBRyxZQUFZLENBQUM7QUFDdkQseUJBQWEsb0JBQW9CLEdBQUcsTUFBTSxDQUFDO0FBQzNDLHlCQUFhLHNCQUFzQixHQUFHLFFBQVEsQ0FBQztBQUMvQyx5QkFBYSxxQkFBcUIsR0FBRyxPQUFPOzs7Ozs7QUNiNUMsSUFJQSxJQUFBO1FBRUksa0JBQ1csY0FDQSxZQUNBLFVBQ0EsVUFDQSxVQUNBO1lBTEEsaUJBQVksR0FBWixZQUFZO1lBQ1osZUFBVSxHQUFWLFVBQVU7WUFDVixhQUFRLEdBQVIsUUFBUTtZQUNSLGFBQVEsR0FBUixRQUFRO1lBQ1IsYUFBUSxHQUFSLFFBQVE7WUFDUixjQUFTLEdBQVQsU0FBUztTQUNmOzhCQUtFLG1DQUFhOzs7O2dCQUNwQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQzs7Ozs7OEJBRy9CLG1DQUFhOzs7O2dCQUNwQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQzs7Ozs7OEJBRy9CLDhDQUF3Qjs7OztnQkFDL0IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUM7Ozs7OzhCQVF0QywrQkFBUzs7OztnQkFDaEIscUJBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUU7b0JBQ2hDLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7aUJBQ3RDO2dCQUNELE9BQU8sS0FBSyxDQUFDOzs7Ozs4QkFHTiwrQkFBUzs7OztnQkFDaEIscUJBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBQzFCLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUU7b0JBQ2hDLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7aUJBQ3RDO2dCQUNELE9BQU8sS0FBSyxDQUFDOzs7Ozs4QkFNTixtQ0FBYTs7OztnQkFDcEIscUJBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDeEMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLE9BQU8sRUFBRTtvQkFDL0UsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUk7MEJBQ3JCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztpQkFDbkQ7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7Ozs7OzhCQUdOLG1DQUFhOzs7O2dCQUNwQixxQkFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztzQkFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO2dCQUMzQyxPQUFPLEtBQUssQ0FBQzs7Ozs7OEJBR04saUNBQVc7Ozs7Z0JBQ2xCLE9BQU8sSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDOzs7Ozs4QkFHbEMsaUNBQVc7Ozs7Z0JBQ2xCLE9BQU8sSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDOzs7Ozs4QkFHakMsZ0NBQVU7Ozs7Z0JBQ2pCLHFCQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO3NCQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7Z0JBQzVDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO29CQUNoQyxPQUFPLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO2lCQUNoRDtnQkFFRCxPQUFPLElBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDOzs7Ozs4QkFHeEIsaUNBQVc7Ozs7Z0JBQ2xCLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUztzQkFDWCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNO3NCQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHO3NCQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7Z0JBQzVDLE9BQU8sRUFBRSxDQUFDOzs7Ozs4QkFHSCxvQ0FBYzs7OztnQkFDckIscUJBQU0sUUFBUSxHQUFrQixJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUM1QyxxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtzQkFDeEIsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUM7Z0JBQ2xDLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHO3NCQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNO3NCQUM1QixJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztnQkFDL0IsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDbEIsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDbEIsT0FBTyxRQUFRLENBQUM7Ozs7OzhCQUdULDZDQUF1Qjs7OztnQkFDOUIscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUk7c0JBQzVCLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO2dCQUM5QixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztzQkFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtzQkFDNUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUM7Z0JBQy9CLE9BQU8sWUFBWSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQzs7Ozs7OEJBR3BELDJDQUFxQjs7OztnQkFDNUIscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7Z0JBQzlCLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO2dCQUM5QixPQUFPLFlBQVksR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUM7Ozs7OzhCQU1wRCx3Q0FBa0I7Ozs7Z0JBQ3pCLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO3NCQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO2dCQUNqRCxPQUFPLEVBQUUsQ0FBQzs7Ozs7OEJBR0gsd0NBQWtCOzs7O2dCQUN6QixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVM7c0JBQ2YsSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksQ0FBQztnQkFDbkQsT0FBTyxFQUFFLENBQUM7Ozs7OzhCQUdILHNDQUFnQjs7OztnQkFDdkIscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDdkMscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUc7c0JBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztnQkFDdkMsT0FBTyxZQUFZLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDOzs7Ozs4QkFJcEQsMENBQW9COzs7O2dCQUMzQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQzs7Ozs7OEJBR3JDLHVDQUFpQjs7OztnQkFDeEIscUJBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUc7c0JBQ3hCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU07c0JBQzdCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztnQkFDL0MsT0FBTyxJQUFJLENBQUMsU0FBUyxHQUFHLE9BQU8sQ0FBQzs7Ozs7OEJBR3pCLHNDQUFnQjs7OztnQkFDdkIscUJBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUk7c0JBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztnQkFDNUMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7b0JBQ2hDLE9BQU8sSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7aUJBQ2hEO2dCQUNELE9BQU8sSUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUM7Ozs7OzhCQUd4QixpQ0FBVzs7OztnQkFDbEIsT0FBTyxNQUFNLENBQUM7Ozs7OzhCQUdQLGlDQUFXOzs7O2dCQUNsQixPQUFPLFFBQVEsQ0FBQzs7Ozs7OEJBRVQsNkNBQXVCOzs7O2dCQUM5QixxQkFBTSxLQUFLLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3JFLE9BQU8sWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHLEdBQUcsQ0FBQzs7Ozs7OEJBUWhFLHdDQUFrQjs7OztnQkFDekIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDOzs7Ozs4QkFHeEMsc0NBQWdCOzs7O2dCQUN2QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7Ozs7OzhCQUd0QyxrREFBNEI7Ozs7Z0JBQ25DLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO3NCQUN4QixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztnQkFDbEMscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUc7c0JBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU07c0JBQzVCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQztzQkFDcEIsQ0FBQyxDQUFDO2dCQUNaLE9BQU8sWUFBWSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQzs7Ozs7OEJBTXBELG9DQUFjOzs7O2dCQUNyQixxQkFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtzQkFDdEIsSUFBSSxDQUFDLFVBQVU7c0JBQ2YsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFFO2dCQUMvQyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxPQUFPLEVBQUU7b0JBQzdDLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJOzBCQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUU7aUJBQzNDO2dCQUNELE9BQU8sRUFBRSxDQUFDOzs7Ozs4QkFHSCxvQ0FBYzs7OztnQkFDckIscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUc7c0JBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU07c0JBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztnQkFDMUMsT0FBTyxFQUFFLENBQUM7Ozs7OzhCQU1ILCtCQUFTOzs7O2dCQUNoQixxQkFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDbkQscUJBQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQztnQkFDcEIscUJBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxHQUFHLFFBQVEsQ0FBQztnQkFDckQsT0FBTyxLQUFLLENBQUM7Ozs7OzhCQUdOLCtCQUFTOzs7O2dCQUNoQixxQkFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDbkQscUJBQU0sUUFBUSxHQUFHLEVBQUUsQ0FBQztnQkFDcEIscUJBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxHQUFHLFFBQVEsQ0FBQztnQkFDckQsT0FBTyxLQUFLLENBQUM7Ozs7OzhCQU9OLG1DQUFhOzs7O2dCQUNwQixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtzQkFDNUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFVBQVUsSUFBSSxDQUFDO3NCQUN6RCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7Z0JBQzNDLE9BQU8sRUFBRSxDQUFDOzs7Ozs4QkFHSCxtQ0FBYTs7OztnQkFDcEIscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUc7c0JBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU07c0JBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQztnQkFDN0MsT0FBTyxFQUFFLENBQUM7Ozs7OzhCQU1ILHNDQUFnQjs7OztnQkFDdkIscUJBQUksTUFBVyxDQUFDO2dCQUNoQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUssRUFBRTtvQkFDN0IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsS0FBSyxJQUFJLEVBQUU7d0JBQ25ELE1BQU0sR0FBR0EsZUFBZSxDQUFDQyxtQkFBbUIsQ0FBQyxDQUFDO3FCQUNqRDt5QkFBTTt3QkFDSCxNQUFNLEdBQUdELGVBQWUsQ0FBQ0UsbUJBQW1CLENBQUMsQ0FBQztxQkFDakQ7aUJBQ0o7Z0JBQ0QsT0FBTyxNQUFNLENBQUM7Ozs7O3VCQTVRbEI7UUE4UUMsQ0FBQTtBQTFRRCxJQXNSQSxJQUFBO1FBQ0Esc0JBQ1UsT0FDQztZQURELFVBQUssR0FBTCxLQUFLO1lBQ0osVUFBSyxHQUFMLEtBQUs7U0FBYzsyQkE3UjlCO1FBK1JDLENBQUE7QUFMRCxJQU9BLElBQUE7UUFDQSwyQkFDVSxHQUNBLEdBQ0E7WUFGQSxNQUFDLEdBQUQsQ0FBQztZQUNELE1BQUMsR0FBRCxDQUFDO1lBQ0QsTUFBQyxHQUFELENBQUM7U0FBYztnQ0FyU3pCO1FBdVNDLENBQUE7QUFORCxJQWdCQSxJQUFBO1FBQ0EsdUJBQ1UsSUFDQztZQURELE9BQUUsR0FBRixFQUFFO1lBQ0QsVUFBSyxHQUFMLEtBQUs7U0FDUjs0QkFyVFI7UUF1VEMsQ0FBQTtBQU5EOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pUQTtRQW9CRSw2QkFBYSxVQUFzQjtZQUNqQyxPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxDQUFDLENBQUM7WUFDakQscUJBQU0sRUFBRSxHQUFtQixVQUFVLENBQUMsYUFBYSxDQUFDO1lBQ3BELElBQUksQ0FBQyxJQUFJLEdBQUdDLFNBQVMsQ0FBQyxFQUFFLENBQUMsQ0FBQztTQUM3Qjs7OztRQUVELHNDQUFROzs7WUFBUjthQUNDOzs7OztRQUVELHlDQUFXOzs7O1lBQVgsVUFBWSxPQUErQztnQkFDekQscUJBQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUM3QyxxQkFBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQy9DLHFCQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUMvQixxQkFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQkFDbkMscUJBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQ2pDLHFCQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7cUJBQ2pDLElBQUksQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDO3FCQUN2QixJQUFJLENBQUMsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUVyQyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUN2QixRQUFRLFNBQVM7b0JBQ2YsS0FBS0Msb0JBQStCO3dCQUNsQyxJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQzt3QkFDdkUsTUFBTTtvQkFDUixLQUFLQyxtQkFBOEI7d0JBQ2pDLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO3dCQUN2RSxNQUFNO29CQUNSLEtBQUtDLG1CQUE4Qjt3QkFDakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7d0JBQ3ZFLE1BQU07b0JBQ1IsS0FBS0MsNEJBQXVDO3dCQUMxQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO3dCQUMvRSxNQUFNO29CQUNSLEtBQUtDLHlCQUFvQzt3QkFDdkMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7d0JBQzdFLE1BQU07b0JBQ1IsS0FBS0MseUJBQW9DO3dCQUN2QyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQzt3QkFDNUUsTUFBTTtvQkFDUixLQUFLQyx1QkFBa0M7d0JBQ3JDLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO3dCQUMxRSxNQUFNO29CQUNSLEtBQUtDLGdDQUEyQzt3QkFDOUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQzt3QkFDbkYsTUFBTTtvQkFDUixLQUFLQyxvQkFBK0I7d0JBQ2xDLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO3dCQUN4RSxNQUFNO29CQUNSLEtBQUtDLDJCQUFzQzt3QkFDekMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7d0JBQzlFLE1BQU07b0JBQ1IsS0FBS0MsMEJBQXFDO3dCQUN4QyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQzt3QkFDOUUsTUFBTTtvQkFDUixLQUFLQyxxQkFBZ0M7d0JBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO3dCQUN6RSxNQUFNO29CQUNSLEtBQUtDLHdCQUFtQzs7d0JBRXRDLE1BQU07b0JBQ1IsS0FBS0Msc0JBQWlDOzt3QkFFcEMsTUFBTTtvQkFDUjt3QkFDRSxNQUFNO2lCQUNUO2FBQ0Y7Ozs7Ozs7OztRQUlPLDRDQUFjOzs7Ozs7OztzQkFBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7Z0JBRTlHLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0NBQXNDLENBQUMsQ0FBQztnQkFFcEQscUJBQU0sT0FBTyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUM7Z0JBQ2pDLHFCQUFNLFVBQVUsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7Z0JBRS9DLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBQ2xCLHFCQUFNLEtBQUssR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNuQyxxQkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDdEYscUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7Z0JBQ25DLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO2dCQUdyQyxxQkFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLGFBQWEsQ0FBQztnQkFDdEMscUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7Z0JBRXRDLHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFDL0MscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2dCQUMvQyxxQkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztnQkFDekQscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztnQkFDaEQscUJBQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUMzQyxxQkFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7Z0JBQ3pDLHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQztnQkFHckQscUJBQU0sUUFBUSxHQUFrQixJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUM1QyxLQUFLLHFCQUFNLENBQUMsSUFBSSxPQUFPLEVBQUU7b0JBQ3JCLElBQUksT0FBTyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDM0IscUJBQU0sSUFBSSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUM7d0JBQ2hDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3ZCO2lCQUNKO2dCQUVELHFCQUFNLFdBQVcsR0FBR0MsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUV0QyxxQkFBTSxrQkFBa0IsR0FBRyxZQUFZO3FCQUN0QixNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUNYLElBQUksQ0FBQyxXQUFXLEVBQUUsWUFBWSxHQUFHLFdBQVcsR0FBRyxHQUFHLEdBQUcsV0FBVyxHQUFHLEdBQUcsQ0FBQyxDQUFDO2dCQUV6RixxQkFBTSxPQUFPLEdBQUdDLGNBQWMsRUFBRTtxQkFDM0IsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUM7Z0JBRWxDLHFCQUFNLElBQUksR0FBR0MsWUFBWSxFQUFFO3FCQUN0QixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7cUJBQ2QsVUFBVSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FDckMsUUFBUSxDQUFDLENBQUM7Z0JBR2YscUJBQU0sT0FBTyxHQUFHRCxjQUFjLEVBQUU7cUJBQzNCLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRUUsTUFBTSxDQUFDLElBQUksRUFBRSxVQUFDLENBQU07d0JBQzVCLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsQ0FBQyxDQUFDLENBQUM7cUJBQ0gsS0FBSyxDQUFDLENBQUMsWUFBWSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRTlCLHFCQUFNLEdBQUcsR0FBRyxrQkFBa0I7cUJBQ3pCLFNBQVMsQ0FBQyxNQUFNLENBQUM7cUJBQ2pCLElBQUksQ0FBQyxJQUFJLENBQUM7cUJBQ1YsS0FBSyxFQUFFO3FCQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUM7cUJBQ1gsSUFBSSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUM7cUJBQ3pCLElBQUksQ0FBQyxXQUFXLEVBQUUsVUFBQyxDQUFNO29CQUN0QixPQUFPLFlBQVksR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQztpQkFDdkUsQ0FBQyxDQUFDO2dCQUVQLElBQUksVUFBVSxFQUFFO29CQUNaLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3lCQUNiLElBQUksQ0FBQyxHQUFHLEVBQUcsQ0FBQyxDQUFDO3lCQUNiLElBQUksQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQzt5QkFDNUQsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7eUJBQ2pCLFVBQVUsRUFBRTt5QkFDWixRQUFRLENBQUMsa0JBQWtCLENBQUM7eUJBQzVCLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBQyxDQUFNO3dCQUNuQixPQUFPLFlBQVksR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3FCQUMzQyxDQUFDLENBQUM7aUJBQ1Y7cUJBQU07b0JBQ0gsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7eUJBQ2IsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7eUJBQ1osSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO3lCQUM1RCxJQUFJLENBQUMsUUFBUSxFQUFFLFVBQUMsQ0FBTTt3QkFDbkIsT0FBTyxZQUFZLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztxQkFDM0MsQ0FBQyxDQUFDO2lCQUNWO2dCQUVELEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNiLElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDO3FCQUNuQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztxQkFDWixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDMUQsSUFBSSxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUM7cUJBQzdCLElBQUksQ0FBQyxVQUFDLENBQU07b0JBQ1QsT0FBTyxXQUFXLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2lCQUNoQyxDQUFDLENBQUM7O2dCQUdQLElBQUksYUFBYSxFQUFFO29CQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3ZCOzs7Z0JBR0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFcEIsSUFBSSxhQUFhLEVBQUU7b0JBQ2hCLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3ZCOzs7Ozs7Ozs7O1FBS0ssd0NBQVU7Ozs7Ozs7O3NCQUFDLFlBQWlCLEVBQUUsVUFBZSxFQUFFLFdBQWdCLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtnQkFFMUcsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO2dCQUU3QyxxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDO2dCQUNsQixxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDO2dCQUNsQixxQkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFFdEYscUJBQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztnQkFJcEMscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7Z0JBQ3JDLHFCQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUVuQyxxQkFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQzNDLHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztnQkFHekMscUJBQU0sVUFBVSxHQUFHQyxrQkFBa0IsRUFBRTtxQkFDbEMsS0FBSyxDQUFDLE1BQU0sRUFBRUMsWUFBWSxFQUFFLENBQUMsRUFBRSxDQUFDLFVBQUMsQ0FBTTtvQkFDcEMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDO2lCQUNmLENBQUMsQ0FBQztxQkFDRixLQUFLLENBQUMsUUFBUSxFQUFFQyxnQkFBZ0IsRUFBRSxDQUFDO3FCQUNuQyxLQUFLLENBQUMsUUFBUSxFQUFFQyxjQUFjLENBQUMsV0FBVyxHQUFHLENBQUMsRUFBRSxZQUFZLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFHeEUscUJBQU0sZUFBZSxHQUFHLFlBQVk7cUJBQ2pDLE1BQU0sQ0FBQyxHQUFHLENBQUM7cUJBQ1gsSUFBSSxDQUFDLFdBQVcsRUFDZixZQUFZLEdBQUcsV0FBVyxHQUFHLEdBQUcsR0FBRyxVQUFVLEdBQUcsR0FBRyxDQUFDLENBQUM7Z0JBRXpELHFCQUFNLElBQUksR0FBRyxlQUFlLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDbkMsSUFBSSxDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7cUJBQzVCLFNBQVMsQ0FBQyxNQUFNLENBQUM7cUJBQ2pCLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDO3FCQUN2QixLQUFLLEVBQUU7cUJBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDZCxJQUFJLENBQUMsY0FBYyxFQUFFLFVBQUMsQ0FBTTtvQkFDekIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztpQkFDN0IsQ0FBQyxDQUFDO2dCQUVQLHFCQUFNLElBQUksR0FBRyxlQUFlLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDbkMsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUM7cUJBQ3RCLFNBQVMsQ0FBQyxRQUFRLENBQUM7cUJBQ25CLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDO3FCQUN2QixLQUFLLEVBQUU7cUJBQ1AsTUFBTSxDQUFDLFFBQVEsQ0FBQztxQkFDaEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7cUJBQ1osSUFBSSxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQU07b0JBQ2pCLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztpQkFDMUIsQ0FBQztxQkFDRCxJQUFJLENBQUNDLE9BQU8sRUFBRTtxQkFDVixFQUFFLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQztxQkFDeEIsRUFBRSxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUM7cUJBQ25CLEVBQUUsQ0FBQyxLQUFLLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFFM0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7cUJBQ2YsSUFBSSxDQUFDLFVBQUMsQ0FBTTtvQkFDVCxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUM7aUJBQ2YsQ0FBQyxDQUFDO2dCQUVYLFVBQVU7cUJBQ0wsS0FBSyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7cUJBQ3hCLEVBQUUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7Z0JBRXhCLHFCQUFNLFVBQVUsR0FBUSxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUNqRCxVQUFVLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQzs7OztnQkFFcEM7b0JBQ0ksSUFBSTt5QkFDQyxJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBTTt3QkFDaEIsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztxQkFBRSxDQUFDO3lCQUN2QixJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBTTt3QkFDakIsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztxQkFBRSxDQUFDO3lCQUN0QixJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBTTt3QkFDaEIsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztxQkFBRSxDQUFDO3lCQUN2QixJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBTTt3QkFDaEIsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztxQkFBRSxDQUFDLENBQUM7b0JBRTdCLElBQUk7eUJBQ0MsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFDLENBQU07d0JBQ2hCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFBRSxDQUFDO3lCQUNoQixJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBTTt3QkFDaEIsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUFFLENBQUMsQ0FBQztpQkFDekI7Ozs7O2dCQUVELHFCQUFxQixDQUFNO29CQUN2QixJQUFJLENBQUNDLFFBQVEsQ0FBQyxNQUFNLEVBQUU7d0JBQ2xCLFVBQVUsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7cUJBQ3pDO29CQUNELENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztvQkFDWCxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ2Q7Ozs7O2dCQUVELGlCQUFpQixDQUFNO29CQUNuQixDQUFDLENBQUMsRUFBRSxHQUFHQSxRQUFRLENBQUMsQ0FBQyxDQUFDO29CQUNsQixDQUFDLENBQUMsRUFBRSxHQUFHQSxRQUFRLENBQUMsQ0FBQyxDQUFDO2lCQUNyQjs7Ozs7Z0JBRUQsbUJBQW1CLENBQU07b0JBQ3JCLElBQUksQ0FBQ0EsUUFBUSxDQUFDLE1BQU0sRUFBRTt3QkFDbEIsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDN0I7b0JBQ0QsQ0FBQyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUM7b0JBQ1osQ0FBQyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUM7aUJBQ2Y7OztnQkFJRCxxQkFBTSxjQUFjLEdBQXdCLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ3hELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxNQUFNLEVBQUU7b0JBQ2hDLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3RDLHFCQUFNLEdBQUcsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQzt3QkFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLFlBQVksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNsRjtpQkFDSjtnQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxjQUFjLENBQUMsQ0FBQzs7Ozs7Ozs7OztRQU9oQyw2Q0FBZTs7Ozs7Ozs7c0JBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO2dCQUUvRyxPQUFPLENBQUMsR0FBRyxDQUFDLHdDQUF3QyxDQUFDLENBQUM7Z0JBRXRELHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBQ2xCLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBQ2xCLHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUN0RixxQkFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLGNBQWMsQ0FBQztnQkFLM0MscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2dCQUMvQyxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Z0JBQ2pELHFCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztnQkFFaEQscUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO2dCQUNyQyxxQkFBTSxXQUFXLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7Z0JBQy9DLHFCQUFNLFlBQVksR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFDakQscUJBQU0sUUFBUSxHQUFHLE9BQU8sR0FBRyxZQUFZLENBQUM7Z0JBQ3hDLHFCQUFNLGNBQWMsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQztnQkFDdEQscUJBQU0sV0FBVyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUMvQyxxQkFBTSxTQUFTLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7Z0JBQzNDLHFCQUFNLFNBQVMsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFDOUMscUJBQU0sT0FBTyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO2dCQUN2QyxxQkFBTSxtQkFBbUIsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDO2dCQUMvRCxxQkFBTSxlQUFlLEdBQUcsSUFBSSxHQUFHLG1CQUFtQixDQUFDO2dCQUVuRCxxQkFBTSxLQUFLLEdBQUdDLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFFeEQscUJBQUksSUFBSSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dCQUNyQyxxQkFBSSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ3JDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7b0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3BDLElBQUksSUFBSSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFOzRCQUNsQyxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7eUJBQ3BDO3dCQUNELElBQUksSUFBSSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFOzRCQUNsQyxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7eUJBQ3BDO3FCQUNKO2lCQUNKO2dCQUNELHFCQUFNLE1BQU0sR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDO2dCQUMzQixxQkFBTSxLQUFLLEdBQUcsTUFBTSxJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFFdkMscUJBQU0sY0FBYyxHQUFHLFVBQUMsRUFBVTtvQkFDOUIsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTt3QkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTs0QkFDcEMsSUFBSSxFQUFFLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUU7Z0NBQy9CLHFCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQ0FDekMscUJBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxJQUFJLEtBQUssQ0FBQyxDQUFDO2dDQUNqRCxPQUFPLEtBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLENBQUM7NkJBQzlCO3lCQUNKO3FCQUNKO2lCQUNKLENBQUM7Z0JBRUYscUJBQU0sSUFBSSxHQUFHQyxVQUFVLEVBQUU7cUJBQ1osVUFBVSxDQUNQQyxjQUFjLEVBQUU7cUJBQ2YsTUFBTSxDQUFDLE9BQU8sQ0FBQztxQkFDZixLQUFLLENBQUMsTUFBTSxDQUFDO3FCQUNiLFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FDOUIsQ0FBQztnQkFFZEMsT0FBTyxDQUFDLGNBQWMsRUFBRSxVQUFDLEtBQUssRUFBRSxJQUFJO29CQUNoQyxZQUFZLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQzt5QkFDckIsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzt5QkFDcEIsS0FBSyxFQUFFO3lCQUNQLE1BQU0sQ0FBQyxNQUFNLENBQUM7eUJBQ2QsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUM7eUJBQ2YsS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO3dCQUM3QixxQkFBTSxHQUFHLEdBQUcsY0FBYyxDQUFDLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDO3dCQUNsRCxPQUFPLEdBQUcsQ0FBQztxQkFDZCxDQUFDLENBQUM7aUJBQ2QsQ0FBQyxDQUFDOzs7Z0JBSUgsSUFBSSxhQUFhLEVBQUU7b0JBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDdkI7OztnQkFJRCxJQUFJLGNBQWMsRUFBRTtvQkFDaEIscUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO29CQUN4RCxLQUFLLHFCQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFDaEMscUJBQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLEdBQUksS0FBSyxDQUFDO3dCQUNuRCxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDbEU7b0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7aUJBQ3pDOzs7Ozs7Ozs7O1FBSUssNkNBQWU7Ozs7Ozs7O3NCQUFDLFlBQWlCLEVBQUUsVUFBZSxFQUFFLFdBQWdCLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtnQkFFL0csT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO2dCQUUvQyxxQkFBTSxnQkFBZ0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQztnQkFDekQscUJBQU0scUJBQXFCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxlQUFlLENBQUM7Z0JBQ25FLHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztnQkFDL0MscUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7Z0JBQ3pELHFCQUFNLEtBQUssR0FBRy9CLGVBQWUsQ0FBQ0UsbUJBQW1CLENBQUMsQ0FBQzs7Z0JBRW5ELHFCQUFNLE1BQU0sR0FBRzhCLE9BQU8sRUFBRTtxQkFDUCxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQztnQkFFN0MscUJBQU0sTUFBTSxHQUFHQyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBRXpDLHFCQUFNLElBQUksR0FBSSxZQUFZLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztxQkFDNUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztxQkFDbEMsS0FBSyxFQUFFO3FCQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUM7cUJBQ1gsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO29CQUNqQyxPQUFPLFlBQVksR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztpQkFDL0MsQ0FBQyxDQUFDO2dCQUVmLHFCQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUN0QyxJQUFJLFVBQVUsRUFBRTtvQkFDWixPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7eUJBQ1gsVUFBVSxFQUFFO3lCQUNaLFFBQVEsQ0FBQyxVQUFDLENBQU0sRUFBRSxDQUFTO3dCQUN4QixPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsa0JBQWtCLEdBQUksR0FBRyxDQUFDO3FCQUM5QyxDQUFDO3lCQUNELElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxDQUFNO3dCQUNkLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDZCxDQUFDO3lCQUNELEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBTTt3QkFDMUIsT0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ25CLENBQUMsQ0FBQztpQkFDZDtxQkFBTTtvQkFDSCxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU07d0JBQ2IsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNkLENBQUM7eUJBQ0QsS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFNO3dCQUMxQixPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDbkIsQ0FBQyxDQUFDO2lCQUNkO2dCQUVELHFCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDcEIsSUFBSSxDQUFDLE9BQU8sRUFBRSxxQkFBcUIsQ0FBQztxQkFDcEMsSUFBSSxDQUFDLFVBQUMsQ0FBTSxFQUFFLENBQVM7b0JBQ3BCLElBQUksQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDLEVBQUU7d0JBQ2YsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztxQkFDdEI7b0JBQ0QsT0FBTyxJQUFJLENBQUM7aUJBQ2YsQ0FBQyxDQUFDO2dCQUVmLElBQUksVUFBVSxFQUFFO29CQUNaLEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQzt5QkFDcEIsVUFBVSxFQUFFO3lCQUNaLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQzt5QkFDNUIsS0FBSyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQztpQkFDOUI7cUJBQU07b0JBQ0gsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7aUJBQy9COzs7Ozs7Ozs7O1FBSUssdUNBQVM7Ozs7Ozs7O3NCQUFDLFlBQWlCLEVBQUUsVUFBZSxFQUFFLFdBQWdCLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtnQkFFekcsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO2dCQUU3QyxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUNkLHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7Z0JBQ2QsS0FBSyxHQUFHLEdBQUcsQ0FBQztnQkFDWixLQUFLLEdBQUcsR0FBRyxDQUFDO2dCQUNaLHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUt0RixxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFDckMscUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7Z0JBRW5DLHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztnQkFDL0MscUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7Z0JBQ3pELHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQztnQkFDbkQscUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUM7Z0JBQzdELHFCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDM0MscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2dCQUd6QyxxQkFBTSxJQUFJLEdBQUdDLE9BQU8sRUFBRTtxQkFDTCxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztnQkFFbkQscUJBQU0sTUFBTSxHQUFHRCxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUM7Z0JBRXpDLHFCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBRTNCLHFCQUFNLGNBQWMsR0FBRyxZQUFZO3FCQUNoQyxNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUNYLElBQUksQ0FBQyxXQUFXLEVBQ2YsWUFBWSxHQUFHLFdBQVcsR0FBRyxHQUFHLEdBQUcsVUFBVSxHQUFHLEdBQUcsQ0FBQyxDQUFDO2dCQUV6RCxxQkFBTSxJQUFJLEdBQUcsY0FBYztxQkFDdEIsU0FBUyxDQUFDLE9BQU8sQ0FBQztxQkFDbEIsSUFBSSxDQUFFLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ25DLEtBQUssRUFBRTtxQkFDUCxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNkLElBQUksQ0FBQyxPQUFPLEVBQUUsZ0JBQWdCLENBQUM7cUJBQy9CLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxDQUFNO29CQUNkLE9BQU8sR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDOzBCQUN0QixHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7MEJBQ3hDLEdBQUcsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7MEJBQ2hELEdBQUcsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7aUJBQ3pDLENBQ0osQ0FBQztnQkFFTixxQkFBTSxJQUFJLEdBQUcsY0FBYztxQkFDdEIsU0FBUyxDQUFDLE9BQU8sQ0FBQztxQkFDbEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQztxQkFDekIsS0FBSyxFQUFFO3FCQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUM7cUJBQ1gsSUFBSSxDQUFDLE9BQU8sRUFBRSxVQUFDLENBQU07b0JBQ2xCLE9BQU8sV0FBVzt5QkFDakIsQ0FBQyxDQUFDLFFBQVEsR0FBRyxXQUFXLEdBQUcsT0FBTyxDQUFDLENBQUM7aUJBQ3hDLENBQUM7cUJBQ0QsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFDLENBQU07b0JBQ3RCLE9BQU8sWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO2lCQUMvQyxDQUFDLENBQUM7Z0JBRVAsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7cUJBQ2hCLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBRW5CLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNkLElBQUksQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDO3FCQUNuQixJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTTtvQkFDZCxPQUFPLENBQUMsQ0FBQyxRQUFRLEdBQUcsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDO2lCQUNoQyxDQUFDO3FCQUNELEtBQUssQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDO3FCQUM5QixJQUFJLENBQUMsVUFBQyxDQUFNO29CQUNULE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7aUJBQ3RCLENBQUMsQ0FBQzs7Ozs7Ozs7OztRQU9ELGtEQUFvQjs7Ozs7Ozs7c0JBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO2dCQUVwSCxPQUFPLENBQUMsR0FBRyxDQUFDLDZDQUE2QyxDQUFDLENBQUM7Z0JBRTNELHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBQ2xCLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBQ2xCLHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUN0RixxQkFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLGNBQWMsQ0FBQztnQkFJM0MscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2dCQUMvQyxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Z0JBQ2pELHFCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztnQkFFaEQscUJBQU0sY0FBYyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO2dCQUN0RCxxQkFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7Z0JBQ3JDLHFCQUFNLFdBQVcsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztnQkFDL0MscUJBQU0sZUFBZSxHQUFHLElBQUksR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDO2dCQUNsRSxxQkFBTSxZQUFZLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUM7Z0JBQ2pELHFCQUFNLFFBQVEsR0FBRyxPQUFPLEdBQUcsWUFBWSxDQUFDO2dCQUN4QyxxQkFBTSxVQUFVLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUM7Z0JBQzdDLHFCQUFNLFFBQVEsR0FBSyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7Z0JBQ3JELHFCQUFNLFFBQVEsR0FBSyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQ25ELHFCQUFNLFdBQVcsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztnQkFDL0MscUJBQU0sZ0JBQWdCLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUM7Z0JBQ3pELHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztnQkFDL0MscUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7Z0JBQ3pELHFCQUFJLFdBQVcsR0FBRyxDQUFDLENBQUM7Z0JBRXBCLHFCQUFNLGdCQUFnQixHQUFHLFVBQUMsSUFBWTtvQkFDbEMsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTt3QkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTs0QkFDcEMsSUFBSSxJQUFJLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUU7Z0NBQ25DLHFCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQ0FDekMsT0FBTyxNQUFNLENBQUM7NkJBQ2pCO3lCQUNKO3FCQUNKO29CQUNELE9BQU8sSUFBSSxDQUFDO2lCQUNmLENBQUM7Z0JBRUYscUJBQU0sVUFBVSxHQUFHRSxrQkFBa0IsRUFBRTtxQkFDMUIsU0FBUyxDQUFDLGVBQWUsQ0FBQztxQkFDMUIsU0FBUyxDQUFDLFVBQVUsQ0FBQztxQkFDckIsS0FBSyxDQUFDLE1BQU0sQ0FBQztxQkFDYixNQUFNLENBQUMsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQztnQkFFMUMscUJBQU0sSUFBSSxHQUFHTixVQUFVLEVBQUU7cUJBQ1osVUFBVSxDQUNQLFVBQVUsQ0FDYixDQUFDO2dCQUVkRSxPQUFPLENBQUMsY0FBYyxFQUFFLFVBQUMsS0FBSyxFQUFFLElBQUk7b0JBQ2hDLFlBQVksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO3lCQUN4QixJQUFJLENBQUMsSUFBSSxFQUFFLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDOUIsSUFBSSxDQUFDLElBQUksRUFBRSxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQzlCLElBQUksQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDO3lCQUNqQixLQUFLLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDO29CQUVoQyxxQkFBTSxTQUFTLEdBQUcsWUFBWSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7eUJBQzNDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7eUJBQ3BCLEtBQUssRUFBRTt5QkFDUCxNQUFNLENBQUMsTUFBTSxDQUFDO3lCQUNkLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO3lCQUNmLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUzt3QkFDN0IscUJBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQzt3QkFDMUMsSUFBSSxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsS0FBSyxJQUFJLEVBQUU7NEJBQ3hDLE9BQU8sZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7eUJBQ3hDO3dCQUVELE9BQU8sTUFBTSxHQUFHLENBQUMsR0FBRyxXQUFXLENBQUM7cUJBQ25DLENBQUMsQ0FBQztvQkFDUCxJQUFJLFVBQVUsRUFBRTt3QkFDWkssUUFBUSxDQUFDOzRCQUNMLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxRQUFRLEdBQUcsV0FBVyxFQUFFLFFBQVEsQ0FBQyxDQUFDLENBQUM7NEJBQ3RELFdBQVcsSUFBSSxDQUFDLENBQUM7NEJBQ2pCLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDO3lCQUM3QixDQUFDLENBQUM7cUJBQ047aUJBQ0osQ0FBQyxDQUFDOzs7Z0JBSUgsSUFBSSxhQUFhLEVBQUU7b0JBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDdkI7Z0JBRUQsSUFBSSxjQUFjLEVBQUU7b0JBQ2hCLHFCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDeEQsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTt3QkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTs0QkFDcEMscUJBQU0sS0FBSyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDOzRCQUN2QyxxQkFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7NEJBQ3pDLElBQUksS0FBSyxLQUFLLFlBQVksRUFBRTtnQ0FDeEIsU0FBUzs2QkFDWjs0QkFDRCxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQzt5QkFDOUY7cUJBQ0o7b0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7aUJBQ3pDOzs7Ozs7Ozs7O1FBT0sseUNBQVc7Ozs7Ozs7O3NCQUFDLFlBQWlCLEVBQUUsVUFBZSxFQUFFLFdBQWdCLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtnQkFFM0csT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO2dCQUVsRCxxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDO2dCQUNsQixxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDO2dCQUNsQixxQkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDdEYscUJBQU0sZUFBZSxHQUFHLEdBQUcsQ0FBQyxjQUFjLENBQUM7Z0JBQzNDLHFCQUFNLGNBQWMsR0FBSSxXQUFXLENBQUMsR0FBRyxDQUFDLGNBQWMsQ0FBQztnQkFDdkQscUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO2dCQUNyQyxxQkFBTSxZQUFZLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUM7Z0JBQ2pELHFCQUFNLFFBQVEsR0FBRyxPQUFPLEdBQUcsWUFBWSxDQUFDO2dCQUN4QyxxQkFBTSxlQUFlLEdBQUcsSUFBSSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUM7Z0JBQ2xFLHFCQUFNLGdCQUFnQixHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDO2dCQUN6RCxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Z0JBRWpELHFCQUFNLElBQUksR0FBR1AsVUFBVSxFQUFFO3FCQUNaLFVBQVUsQ0FDUEMsY0FBYyxFQUFFO3FCQUNmLFNBQVMsQ0FBQyxlQUFlLENBQUM7cUJBQzFCLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FDakIsQ0FBQztnQkFFZCxxQkFBTSxnQkFBZ0IsR0FBRyxVQUFDLElBQVk7b0JBQ2xDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7d0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7NEJBQ3BDLElBQUksSUFBSSxLQUFLLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFO2dDQUNuQyxxQkFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0NBQ3pDLE9BQU8sTUFBTSxDQUFDOzZCQUNqQjt5QkFDSjtxQkFDSjtvQkFDRCxPQUFPLElBQUksQ0FBQztpQkFDZixDQUFDO2dCQUVGQyxPQUFPLENBQUMsY0FBYyxFQUFFLFVBQUMsS0FBSyxFQUFFLElBQUk7b0JBQ2hDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO3lCQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3lCQUNwQixLQUFLLEVBQUU7eUJBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQzt5QkFDZCxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQzt5QkFDZixLQUFLLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7d0JBQzdCLHFCQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7d0JBQzFDLElBQUksZ0JBQWdCLENBQUMsV0FBVyxDQUFDLEtBQUssSUFBSSxFQUFFOzRCQUN4QyxPQUFPLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDO3lCQUN4Qzt3QkFDRCxPQUFPLE1BQU0sR0FBRyxDQUFDLEdBQUcsV0FBVyxDQUFDO3FCQUNuQyxDQUFDLENBQUM7aUJBQ1YsQ0FBQyxDQUFDOzs7Z0JBSVAsSUFBSSxjQUFjLEVBQUU7b0JBQ2hCLHFCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDeEQsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTt3QkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTs0QkFDcEMscUJBQU0sS0FBSyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDOzRCQUN2QyxxQkFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7NEJBQ3pDLElBQUksS0FBSyxLQUFLLFlBQVksRUFBRTtnQ0FDeEIsU0FBUzs2QkFDWjs0QkFDRCxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQzt5QkFDOUY7cUJBQ0o7b0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7aUJBQ3pDOzs7Ozs7Ozs7O1FBTUssMkNBQWE7Ozs7Ozs7O3NCQUFDLFlBQWlCLEVBQUUsVUFBZSxFQUFFLFdBQWdCLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtnQkFFN0csT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO2dCQVNuRCxxQkFBTSxPQUFPLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQzNDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7b0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3JDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ2xCO2lCQUNKO2dCQUVELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7b0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3BDLHFCQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7d0JBQ1YsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7NEJBQ3ZDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dDQUM3QyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7NkJBQ2xEO3lCQUNKO3FCQUNKO2lCQUNKO2dCQUNELHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7Z0JBQ2QscUJBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQkFDZCxLQUFLLEdBQUdWLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDeEIsS0FBSyxHQUFHLEdBQUcsQ0FBQztnQkFDWixxQkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFFdEYscUJBQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDcEMscUJBQU0sVUFBVSxHQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO2dCQUM1QyxxQkFBTSxTQUFTLEdBQUcsQ0FBQyxHQUFHLENBQUMsVUFBVSxHQUFHLFVBQVUsSUFBSSxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFDNUUscUJBQU0sWUFBWSxJQUFJLEdBQUcsQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDLENBQUU7Z0JBQ3BELHFCQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsYUFBYSxDQUFDO2dCQUVwQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFDckMscUJBQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUM7Z0JBRWpDLHFCQUFNLFFBQVEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFDMUMscUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO2dCQUNqRCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUNoRCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUNoRCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQy9DLHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztnQkFDL0MscUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7O2dCQUd6RCxxQkFBTSxlQUFlLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Z0JBRzlDLHFCQUFNLFNBQVMsR0FBa0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDN0MsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtvQkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDcEMscUJBQU0sSUFBSSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO3dCQUN0QyxxQkFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM5QyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN4QjtpQkFDSjs7Z0JBR0QscUJBQU0sVUFBVSxHQUFrQixJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUM5QyxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtvQkFDdkMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQzdDLHFCQUFNLE9BQU8sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQy9DLFVBQVUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7cUJBQzVCO2lCQUNKO2dCQUVELHFCQUFNLFVBQVUsR0FBZSxJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUMzQyxLQUFLLHFCQUFNLENBQUMsSUFBSSxVQUFVLEVBQUU7b0JBQ3hCLElBQUksVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFFOUIscUJBQU0sV0FBVyxHQUFlLEVBQUcsQ0FBQzt3QkFDcEMsS0FBSyxxQkFBTSxDQUFDLElBQUksU0FBUyxFQUFFOzRCQUN2QixJQUFJLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0NBQzdCLHFCQUFNLElBQUksR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzFCLHFCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQzlDLFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBSSxNQUFNLENBQUM7NkJBQy9CO3lCQUNKO3dCQUNELFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7cUJBQ2hDO2lCQUNKO2dCQUVELHFCQUFNLE1BQU0sR0FBR0YsY0FBYyxFQUFFO3FCQUNkLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQztxQkFDdkIsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLFlBQVksQ0FBQyxDQUFDLENBQUM7Z0JBRzFDLHFCQUFNLEtBQUssR0FBR2tCLFFBQVEsRUFBRSxDQUFDO2dCQUN6QixxQkFBTSxLQUFLLEdBQUcsWUFBWSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7cUJBQ3BDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO3FCQUN2QyxLQUFLLEVBQUU7cUJBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDWCxJQUFJLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7b0JBQzVCLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNwQixDQUFFO3FCQUNGLElBQUksQ0FBQyxjQUFjLEVBQUUsUUFBUSxDQUFDO3FCQUM5QixTQUFTLENBQUMsTUFBTSxDQUFDO3FCQUNqQixJQUFJLENBQUMsVUFBQyxDQUFNLEVBQUUsQ0FBUztvQkFDcEIsT0FBTyxDQUFDLENBQUM7aUJBQ1osQ0FBQztxQkFDRCxLQUFLLEVBQUU7cUJBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUlwQixJQUFJLFVBQVUsRUFBRTtvQkFDWixLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO3dCQUM5QixPQUFPLFNBQVMsR0FBSyxDQUFDLEdBQUcsWUFBWSxDQUFDO3FCQUN6QyxDQUFDO3lCQUNELElBQUksQ0FBQyxRQUFRLEVBQUcsQ0FBQyxDQUFDO3lCQUNsQixJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7d0JBQ3pCLHFCQUFNLEVBQUUsR0FBRyxTQUFTLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUNwQyxxQkFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO3dCQUN6QixPQUFPLFNBQVMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQzlELENBQUM7eUJBQ0QsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUM7eUJBQ3hCLFVBQVUsRUFBRTt5QkFDWixRQUFRLENBQUMsa0JBQWtCLENBQUM7eUJBQzVCLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUzt3QkFDOUIsT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUM5QixDQUFDLENBQUM7aUJBQ047cUJBQU07b0JBQ0gsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUzt3QkFDOUIsT0FBTyxTQUFTLElBQUksQ0FBQyxHQUFHLFlBQVksQ0FBQyxDQUFDO3FCQUN6QyxDQUFDO3lCQUNELElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUzt3QkFDekIscUJBQU0sRUFBRSxHQUFHLFNBQVMsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3BDLHFCQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7d0JBQ3pCLE9BQU8sU0FBUyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDOUQsQ0FBQzt5QkFDRCxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQzt5QkFDeEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO3dCQUM5QixPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQzlCLENBQUMsQ0FBQztpQkFDTjs7O2dCQUtELElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7OztnQkFJcEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFckIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O2dCQUl4QixJQUFJLGFBQWEsRUFBRTtvQkFDZixxQkFBTSxXQUFXLEdBQW1CLElBQUksS0FBSyxFQUFFLENBQUM7b0JBQ2hELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO3dCQUN2QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTs0QkFDN0MsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDcEQ7cUJBQ0o7b0JBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFNUIseUJBQW9DLENBQUMsQ0FBQztpQkFDL0U7OztnQkFLRCxJQUFJLGNBQWMsRUFBRTtvQkFDaEIscUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO29CQUN4RCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO3dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUNwQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQzlFO3FCQUNKO29CQUNELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDO2lCQUN6QztnQkFFRCxJQUFJLGFBQWEsRUFBRTtvQkFDZixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUN2Qjs7Ozs7Ozs7OztRQUlLLDhDQUFnQjs7Ozs7Ozs7c0JBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO2dCQUVoSCxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUM7Z0JBRXBELHFCQUFNLFFBQVEsR0FBNkIsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDdkQscUJBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQkFDZCxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUNkLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7b0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3BDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFOzRCQUN2QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQ0FDN0MsSUFBSSxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO29DQUN4QyxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lDQUMxQztnQ0FDRCxJQUFJLEtBQUssR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0NBQ3hDLEtBQUssR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUNBQzFDO2dDQUNELHFCQUFNLGdCQUFnQixHQUFHLElBQUksaUJBQWlCLENBQzFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFDOUIsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUM5QixXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQ2pDLENBQUU7Z0NBQ0gsUUFBUSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDOzZCQUNuQzt5QkFDSjtxQkFDSjtpQkFDSjtnQkFDRCxxQkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFFdEYscUJBQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7Z0JBR3BDLHFCQUFNLGFBQWEsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQkFDaEQscUJBQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDcEMscUJBQU0sUUFBUSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2dCQUMxQyxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUNoRCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUNoRCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQy9DLHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFFakQscUJBQU0sT0FBTyxHQUFHLFlBQVksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO3FCQUN2QyxJQUFJLENBQUMsUUFBUSxDQUFDO3FCQUNkLEtBQUssRUFBRTtxQkFDUCxNQUFNLENBQUMsUUFBUSxDQUFDO3FCQUNoQixJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBb0IsRUFBRSxDQUFNO29CQUNyQyxPQUFPLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUMxQixDQUFDO3FCQUNELElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFvQixFQUFFLENBQU07b0JBQ3JDLFFBQVEsU0FBUyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUU7aUJBQ3ZELENBQUM7cUJBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQW9CLEVBQUUsQ0FBTTtvQkFDcEMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUNkLENBQUM7cUJBQ0QsS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO29CQUM3QixxQkFBTSxTQUFTLEdBQUcsQ0FBQyxHQUFHLGFBQWEsQ0FBQztvQkFDcEMsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7aUJBQzVCLENBQUM7cUJBQ0QsSUFBSSxDQUFDLGNBQWMsRUFBRyxRQUFRLENBQUMsQ0FBQzs7Z0JBSXpDLElBQUksYUFBYSxFQUFFO29CQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3ZCOzs7Z0JBSUQsSUFBSSxjQUFjLEVBQUU7b0JBQ2hCLHFCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDeEQsS0FBSyxxQkFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTt3QkFDaEQsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLFlBQVksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQzNFO29CQUNELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDO2lCQUN6Qzs7O2dCQUdELElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBRXJCLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBRXJCLElBQUksYUFBYSxFQUFFO29CQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3ZCO2dCQUNELElBQUksYUFBYSxFQUFFO29CQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3ZCOzs7Ozs7UUFLSyx1Q0FBUzs7OztzQkFBQyxRQUFhO2dCQUU3QixPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7Z0JBRWhELHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7Z0JBQ3JCLHFCQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUNsQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQztnQkFFdEMscUJBQU0sTUFBTSxHQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUM7Z0JBRTlCLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDO2dCQUM1QixxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFDckMscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7Z0JBQ3JDLHFCQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUNuQyxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7Z0JBQ2pELHFCQUFNLFdBQVcsR0FBR1UsY0FBYyxFQUFFO3FCQUNuQixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7cUJBQ2xCLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQztnQkFDbEQscUJBQU0sT0FBTyxHQUFHbUIsUUFBUSxDQUFDLE1BQU0sR0FBRyxZQUFZLEVBQzlCLEtBQUssR0FBSSxZQUFZLEVBQ3JCLE1BQU0sR0FBRyxZQUFZLENBQUMsQ0FBQztnQkFFdkMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7cUJBQ25CLFNBQVMsQ0FBQyxRQUFRLENBQUM7cUJBQ25CLElBQUksQ0FBQyxPQUFPLENBQUM7cUJBQ2IsS0FBSyxFQUFFO3FCQUNQLE1BQU0sQ0FBQyxNQUFNLENBQUM7cUJBQ2QsSUFBSSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUM7cUJBQzdCLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUztvQkFDMUIscUJBQU0sR0FBRyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxHQUFJLENBQUMsQ0FBQztvQkFDeEMsT0FBTyxHQUFHLENBQUM7aUJBQ2QsQ0FBQztxQkFDRCxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7cUJBQ3BELElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUztvQkFDMUIscUJBQU0sR0FBRyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxHQUFJLENBQUMsQ0FBQztvQkFDeEMsT0FBTyxHQUFHLENBQUM7aUJBQ2QsQ0FBQztxQkFDRCxJQUFJLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7Ozs7OztRQUczRCx3Q0FBVTs7OztzQkFBQyxRQUFhO2dCQUU5QixPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7Z0JBRWhELHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7Z0JBQ3JCLHFCQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUNsQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQztnQkFFdEMscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUM7Z0JBQzVCLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO2dCQUVyQyxxQkFBTSxXQUFXLEdBQUduQixjQUFjLEVBQUU7cUJBQ25CLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztxQkFDbEIsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDO2dCQUVsRCxZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDbkIsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsYUFBYSxDQUFDO3FCQUNoQyxJQUFJLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQztxQkFDOUMsSUFBSSxDQUNDb0IsYUFBYSxDQUFDLFdBQVcsQ0FBQyxDQUMvQixDQUFDOzs7Ozs7Ozs7Ozs7O1FBUUEsc0NBQVE7Ozs7Ozs7O3NCQUFDLFlBQWlCLEVBQUUsVUFBZSxFQUFFLFdBQWdCLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtnQkFFeEcsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO2dCQUU1QyxxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDO2dCQUNsQixxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDO2dCQUNsQixxQkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFFdEYscUJBQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztnQkFHcEMscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7Z0JBR3JDLHFCQUFNLFFBQVEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFDMUMscUJBQU0sWUFBWSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO2dCQUM3QyxxQkFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQzNDLHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztnQkFDekMscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2dCQUMvQyxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Z0JBQ2pELHFCQUFNLG1CQUFtQixHQUFHLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztnQkFDbkQscUJBQU0sd0JBQXdCLEdBQUcsR0FBRyxDQUFDLHVCQUF1QixDQUFDO2dCQUM3RCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7Z0JBQy9DLHFCQUFNLGtCQUFrQixHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2dCQUN2RCxxQkFBTSx1QkFBdUIsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQztnQkFDbkUscUJBQU0sNkJBQTZCLEdBQUcsR0FBRyxDQUFDLDRCQUE0QixDQUFDO2dCQUN2RSxxQkFBTSxpQkFBaUIsR0FBRyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7Z0JBQy9DLHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFDL0MscUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO2dCQUNqRCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQy9DLHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQ25ELHFCQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUM7Z0JBQ3ZELHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztnQkFDL0MscUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7Z0JBS3pELHFCQUFNLE9BQU8sR0FBa0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDM0MsS0FBSyxxQkFBTSxDQUFDLElBQU0sV0FBVyxDQUFDLElBQUksRUFBRTtvQkFDaEMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDcEMscUJBQU0sSUFBSSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO3dCQUN2QyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUN0QjtpQkFDSjtnQkFFRCxxQkFBTSxJQUFJLEdBQUdDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDN0IscUJBQU0sR0FBRyxHQUFHQyxNQUFNLEVBQUUsQ0FBQztnQkFDckIscUJBQU0sR0FBRyxHQUFHQyxNQUFNLEVBQUU7cUJBQ1AsV0FBVyxDQUFDLFlBQVksR0FBRyxtQkFBbUIsR0FBRyxHQUFHLENBQUM7cUJBQ3JELFdBQVcsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBRTNDLHFCQUFNLFdBQVcsR0FBRyxZQUFZLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztxQkFDekIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztxQkFDbEIsS0FBSyxFQUFFO3FCQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUM7cUJBQ1gsSUFBSSxDQUFDLFdBQVcsRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO2dCQUdyRSxxQkFBTSxnQkFBZ0IsR0FBRztvQkFDakIsSUFBSSxhQUFhLElBQUksZUFBZSxFQUFFO3dCQUNsQyxxQkFBTSxHQUFHLEdBQUcsaUJBQWlCLEdBQUcsR0FBRyxHQUFHLElBQUksR0FBSSxTQUFTLENBQUM7d0JBQ3hELE9BQU8sR0FBRyxDQUFDO3FCQUNkO29CQUNELElBQUksZUFBZSxFQUFFO3dCQUNqQixPQUFPLE1BQU0sQ0FBQztxQkFDakI7b0JBQ0QsSUFBSSxhQUFhLEVBQUU7d0JBQ2YsT0FBTyxpQkFBaUIsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDO3FCQUN6QztpQkFDUixDQUFDO2dCQUVGLHFCQUFNLFlBQVksR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDdkIsSUFBSSxDQUFDLE9BQU8sRUFBRSx1QkFBdUIsQ0FBQztxQkFDdEMsSUFBSSxDQUFDLFdBQVcsRUFBRSw2QkFBNkIsQ0FBRTtxQkFDakQsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7Z0JBRWhELHFCQUFNLElBQUksR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDMUIsSUFBSSxDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7cUJBQzVCLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUztvQkFDN0IsT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3BCLENBQUM7cUJBQ0QsSUFBSSxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2dCQXNCNUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7Z0JBRXBCLFdBQVcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNiLElBQUksQ0FBQyxPQUFPLEVBQUUsa0JBQWtCLENBQUM7cUJBQ2pDLElBQUksQ0FBQyxXQUFXLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUztvQkFDckMsT0FBTyxZQUFZLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7aUJBQzNDLENBQUM7cUJBQ0QsSUFBSSxDQUFDLFVBQUMsQ0FBTSxFQUFFLENBQVM7b0JBQ3BCLElBQUksYUFBYSxJQUFJLGVBQWUsRUFBRTt3QkFDbEMscUJBQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxHQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0JBQzVELHFCQUFNLEdBQUcsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxHQUFHLElBQUksR0FBRyxVQUFVLEdBQUcsSUFBSSxDQUFDO3dCQUN2RCxPQUFPLEdBQUcsQ0FBQztxQkFDZDtvQkFDRCxJQUFJLGVBQWUsRUFBRTt3QkFDakIscUJBQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxHQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUM7d0JBQzVELHFCQUFNLEdBQUcsR0FBRyxVQUFVLEdBQUcsR0FBRyxDQUFDO3dCQUM3QixPQUFPLEdBQUcsQ0FBQztxQkFDZDtvQkFDRCxJQUFJLGFBQWEsRUFBRTt3QkFDZixPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7cUJBQ2xCO2lCQUNKLENBQUMsQ0FBQzs7Z0JBR2YsSUFBSSxhQUFhLEVBQUU7b0JBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDdkI7OztnQkFJRCxJQUFJLGNBQWMsRUFBRTtvQkFDaEIscUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO29CQUN4RCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO3dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUNwQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQzlFO3FCQUNKO29CQUNELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDO2lCQUN6Qzs7Ozs7Ozs7OztRQUtLLHNDQUFROzs7Ozs7OztzQkFBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7Z0JBRXhHLE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsQ0FBQztnQkFFNUMscUJBQU0sU0FBUyxHQUFrQixJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUM3QyxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO29CQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUNwQyxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTs0QkFDbkMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0NBQ3pDLHFCQUFNLEVBQUUsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDcEMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQzs2QkFDdEI7eUJBQ0o7cUJBQ0o7aUJBQ0o7Z0JBRUQscUJBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQkFDZCxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUNkLEtBQUssR0FBR3JCLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztnQkFDMUIsS0FBSyxHQUFHLEdBQUcsQ0FBQztnQkFDWixxQkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFFdEYscUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO2dCQUNyRCxxQkFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLGdCQUFnQixDQUFDO2dCQUNwQyxxQkFBTSxVQUFVLEdBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7Z0JBQzlDLHFCQUFNLFVBQVUsR0FBSSxTQUFTLENBQUMsTUFBTSxDQUFDO2dCQUVyQyxxQkFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLGFBQWEsQ0FBQztnQkFDcEMscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7Z0JBQ3JDLHFCQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUVuQyxxQkFBTSxRQUFRLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQzFDLHFCQUFNLFlBQVksR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztnQkFDN0MscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2dCQUMvQyxxQkFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQzNDLHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztnQkFDekMscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2dCQUMvQyxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Z0JBQ2pELHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFDakQscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2dCQUMvQyxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUNoRCxxQkFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7Z0JBQy9DLHFCQUFNLGtCQUFrQixHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO2dCQUV6RCxxQkFBTSxTQUFTLEdBQUcsQ0FBQyxXQUFXLElBQUksY0FBYyxHQUFHLFVBQVUsR0FBRyxVQUFVLENBQUMsSUFBSyxVQUFVLENBQUM7Z0JBQzNGLHFCQUFNLFlBQVksSUFBSSxXQUFXLEdBQUcsVUFBVSxDQUFDLENBQUU7Z0JBRWpELHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO2dCQUVyQyxxQkFBTSxTQUFTLEdBQUdGLGNBQWMsRUFBRTtxQkFDakIsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUNsQixLQUFLLENBQUMsQ0FBQyxLQUFLLEdBQUcsWUFBWSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRWxELHFCQUFNLFdBQVcsR0FBRyxjQUFjLENBQUM7Z0JBS25DLHFCQUFNLFFBQVEsR0FBRyxZQUFZLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztxQkFDdkMsSUFBSSxDQUFDLFNBQVMsQ0FBQztxQkFDZixLQUFLLEVBQUU7cUJBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDWCxJQUFJLENBQUMsV0FBVyxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7b0JBQ2pDLHFCQUFNLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLFVBQVUsTUFBTSxDQUFDLElBQUksV0FBVyxHQUFHLENBQUMsQ0FBQztvQkFDNUQsT0FBTyxZQUFZLElBQUksUUFBUSxHQUFHLFlBQVksR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7aUJBQzdELENBQUM7cUJBQ0QsS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO29CQUM3QixxQkFBTSxRQUFRLElBQUksQ0FBQyxHQUFHLFVBQVUsQ0FBQyxDQUFDO29CQUNsQyxPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQztpQkFDM0IsQ0FBQztxQkFDRCxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsQ0FBQyxDQUFDO2dCQUVwQyxxQkFBTSxLQUFLLEdBQUksUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDdkMsSUFBSSxVQUFVLEVBQUU7b0JBQ1osS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDO3lCQUMzQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQzt5QkFDakIsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU07d0JBQ2QsT0FBTyxTQUFTLENBQUM7cUJBQ3BCLENBQUM7eUJBQ0QsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLEdBQUcsV0FBVyxDQUFDO3lCQUN0QyxVQUFVLEVBQUU7eUJBQ1osUUFBUSxDQUFDLGtCQUFrQixDQUFDO3lCQUM1QixJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTTt3QkFDZCxPQUFPLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUM7cUJBQ25DLENBQUM7eUJBQ0QsSUFBSSxDQUFDLFFBQVEsRUFBRSxVQUFDLENBQU07d0JBQ25CLE9BQU8sWUFBWSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBRTtxQkFDdkMsQ0FBQyxDQUFDO2lCQUNOO3FCQUFNO29CQUNILEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQzt5QkFDM0IsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU07d0JBQ2QsT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDO3FCQUNuQyxDQUFDO3lCQUNELElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxHQUFHLFdBQVcsQ0FBQzt5QkFDdEMsSUFBSSxDQUFDLFFBQVEsRUFBRSxVQUFDLENBQU07d0JBQ25CLE9BQU8sWUFBWSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDdEMsQ0FBQyxDQUFDO2lCQUNOO2dCQUVELHFCQUFNLFlBQVksR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUM3QyxZQUFZO3FCQUNQLElBQUksQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO3FCQUM3QixJQUFJLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQztxQkFDdEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU07b0JBQ2hCLE9BQU8sU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQztpQkFDakMsQ0FBQztxQkFDRCxJQUFJLENBQUMsVUFBQyxDQUFNO29CQUNYLE9BQU8sQ0FBQyxDQUFFO2lCQUNYLENBQUMsQ0FBQzs7O2dCQUlQLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7OztnQkFJckIsSUFBSSxhQUFhLEVBQUU7b0JBQ2YscUJBQU0sV0FBVyxHQUFtQixJQUFJLEtBQUssRUFBRSxDQUFDO29CQUNoRCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO3dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUNwQyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQzNDO3FCQUNKO29CQUNELElBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFdBQVcsRUFBRWQsbUJBQThCLENBQUMsQ0FBQztpQkFDekU7Z0JBRUQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O2dCQUl4QixxQkFBTSxjQUFjLEdBQXdCLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ3hELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxNQUFNLEVBQUU7b0JBQ2hDLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3hDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUN6RTtpQkFDSjtnQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxjQUFjLENBQUMsQ0FBQzs7O2dCQUl0QyxJQUFJLGFBQWEsRUFBRTtvQkFDZixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUN2QjtnQkFFRCxJQUFJLGFBQWEsRUFBRTtvQkFDZixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUN2Qjs7Ozs7Ozs7OztRQUtLLHVDQUFTOzs7Ozs7OztzQkFBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7Z0JBRXpHLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztnQkFFL0MscUJBQU0sVUFBVSxHQUFrQixJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUU5QyxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO29CQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUNwQyxxQkFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDO3dCQUNmLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFOzRCQUN2QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQ0FDN0MsSUFBSSxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO29DQUN6QyxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lDQUMzQzs2QkFDSjt5QkFDSjt3QkFDRCxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFFO3FCQUM1QjtpQkFDSjtnQkFDRCxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUNkLHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7Z0JBQ2QsS0FBSyxHQUFHZ0IsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO2dCQUMzQixLQUFLLEdBQUcsR0FBRyxDQUFDO2dCQUVaLHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUN0RixxQkFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLGdCQUFnQixDQUFDO2dCQUVwQyxxQkFBTSxVQUFVLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFFO2dCQUNyRCxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7Z0JBRWpELE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7Z0JBRTFCLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFO29CQUMzQixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUN2Qjs7Z0JBR0QsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtvQkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDcEMscUJBQU0sVUFBVSxHQUF5QixJQUFJLEtBQUssRUFBRSxDQUFDO3dCQUNyRCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTs0QkFDdkMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0NBQzdDLHFCQUFNLE9BQU8sR0FBRyxJQUFJLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNuRixVQUFVLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDOzZCQUM1Qjt5QkFDSjt3QkFDRCxxQkFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzt3QkFDNUIsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsVUFBVSxFQUFFLEdBQUcsQ0FBQyxDQUFDO3FCQUM3QztpQkFDSjs7O2dCQUlELElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7OztnQkFJcEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFckIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O2dCQUl4QixxQkFBTSxXQUFXLEdBQW1CLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ2hELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO29CQUN2QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDN0MsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDcEQ7aUJBQ0o7Z0JBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFakIsb0JBQStCLENBQUMsQ0FBQzs7O2dCQUl2RSxxQkFBTSxjQUFjLEdBQXdCLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ3hELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7b0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3RDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDNUU7aUJBQ0o7Z0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7Ozs7Ozs7O1FBT2hDLDRDQUFjOzs7Ozs7c0JBQUMsUUFBYSxFQUFFLE9BQVksRUFBRSxPQUFlO2dCQUVqRSxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUM7Z0JBRXBELE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ3JCLHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7Z0JBQ3JCLHFCQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUNsQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQztnQkFFdEMscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUM7Z0JBQzVCLHFCQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsa0JBQWtCLENBQUM7Z0JBQ3pDLHFCQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsa0JBQWtCLENBQUM7Z0JBQ3pDLHFCQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDO2dCQUNsQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFVBQVUsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQ3ZELHFCQUFNLE1BQU0sR0FBR0osZUFBZSxDQUFDRSxtQkFBbUIsQ0FBQyxDQUFDO2dCQUVwRCxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxlQUFlLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUM5RSxxQkFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQzNDLHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQkFFL0MscUJBQU0sT0FBTyxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7Z0JBR2hDLHFCQUFNLElBQUksR0FBR3lDLE9BQU8sRUFBRTtxQkFDakIsS0FBSyxDQUFDQyxjQUFjLENBQUM7cUJBQ3JCLENBQUMsQ0FBRSxVQUFDLENBQU07b0JBQ1AsT0FBTyxXQUFXLEdBQUcsQ0FBQyxDQUFDLEVBQUUsR0FBRyxZQUFZLENBQUM7aUJBQzVDLENBQUM7cUJBQ0QsQ0FBQyxDQUFFLFVBQUMsQ0FBTTtvQkFDUCxPQUFPLEdBQUcsQ0FBQyxTQUFTLEdBQUcsYUFBYSxJQUFLLENBQUMsQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFDLENBQUU7aUJBQ2hFLENBQUMsQ0FBQztnQkFFUCxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDbEIsSUFBSSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUM7cUJBQzdCLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7O1FBUTVCLHlDQUFXOzs7OztzQkFBQyxRQUFhLEVBQUUsY0FBbUI7Z0JBRXBELE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQzs7Z0JBR2pELHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7Z0JBQ3JCLHFCQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUNsQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQzs7Z0JBRXRDLHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQztnQkFDbkQscUJBQU0sYUFBYSxHQUFHLEVBQUUsQ0FBQztnQkFDekIscUJBQU0sUUFBUSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO2dCQUM1QyxxQkFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLGNBQWMsQ0FBQztnQkFDcEMscUJBQU0sUUFBUSxHQUFHLEdBQUcsQ0FBQyxjQUFjLENBQUM7Z0JBQ3BDLHFCQUFNLE9BQU8sR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFFekMscUJBQU0sU0FBUyxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUM3QixTQUFTLENBQUMsR0FBRyxDQUFDO3FCQUNkLElBQUksQ0FBQyxjQUFjLENBQUM7cUJBQ3BCLEtBQUssRUFBRTtxQkFDUCxNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUNYLElBQUksQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDO3FCQUN2QixJQUFJLENBQUMsV0FBVyxFQUFFLFVBQUMsQ0FBZSxFQUFFLENBQVM7b0JBQzFDLHFCQUFNLE1BQU0sR0FBRyxjQUFjLEdBQUcsUUFBUSxDQUFDO29CQUN6QyxxQkFBTSxDQUFDLEdBQUcsUUFBUSxDQUFDO29CQUNuQixxQkFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLE1BQU0sR0FBRyxRQUFRLENBQUU7b0JBQ2pDLE9BQU8sWUFBWSxHQUFHLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQztpQkFDNUMsQ0FBQyxDQUFDO2dCQUVmLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQztxQkFDN0IsSUFBSSxDQUFDLFFBQVEsRUFBRSxjQUFjLENBQUM7cUJBQzlCLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBQyxDQUFlO29CQUMzQixPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7aUJBQ2xCLENBQUM7cUJBQ0QsS0FBSyxDQUFDLFFBQVEsRUFBRSxVQUFDLENBQWU7b0JBQzdCLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQztpQkFDbEIsQ0FBQztxQkFDRCxJQUFJLENBQUMsY0FBYyxFQUFFLE9BQU8sQ0FBQyxDQUFDO2dCQUVuQyxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDbkIsSUFBSSxDQUFDLEdBQUcsRUFBRSxjQUFjLEdBQUcsYUFBYSxDQUFDO3FCQUN6QyxJQUFJLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQztxQkFDekIsSUFBSSxDQUFDLFVBQUMsQ0FBZTtvQkFDbEIsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDO2lCQUNsQixDQUFDLENBQUM7Ozs7Ozs7O1FBSUQsNENBQWM7Ozs7OztzQkFBQyxRQUFhLEVBQUUsWUFBaUIsRUFBRSxTQUFpQjtnQkFFeEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDO2dCQUVwRCxxQkFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDO2dCQUNyQixxQkFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztnQkFDbEMscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7O2dCQUd0QyxxQkFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLGtCQUFrQixDQUFDO2dCQUN6QyxxQkFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLGtCQUFrQixDQUFDO2dCQUV6QyxxQkFBTSxVQUFVLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQztnQkFDdkMscUJBQUksWUFBWSxHQUFHLEdBQUcsQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO2dCQUMvQyxJQUFLLFNBQVMsS0FBS3hDLG9CQUErQixFQUFFO29CQUNoRCxZQUFZLEdBQUcsR0FBRyxDQUFDLFVBQVUsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUM7aUJBQ3BEO2dCQUVELHFCQUFNLFFBQVEsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDNUIsU0FBUyxDQUFDLEdBQUcsQ0FBQztxQkFDZCxJQUFJLENBQUMsWUFBWSxDQUFDO3FCQUNsQixLQUFLLEVBQUU7cUJBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDWCxJQUFJLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxTQUFTLENBQUM7cUJBQ25DLElBQUksQ0FBQyxXQUFXLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUztvQkFDakMscUJBQU0sRUFBRSxHQUFHLFNBQVMsR0FBRyxZQUFZLEdBQUcsQ0FBQyxDQUFDO29CQUN4QyxxQkFBTSxFQUFFLEdBQUcsU0FBUyxDQUFFO29CQUN0QixPQUFPLFlBQVksR0FBRyxFQUFFLEdBQUcsSUFBSSxHQUFHLEVBQUUsR0FBRyxHQUFHLENBQUM7aUJBQzlDLENBQUMsQ0FBQztnQkFFZixRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDVixJQUFJLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDO3FCQUM3QyxJQUFJLENBQUMsVUFBQyxDQUFNLEVBQUUsQ0FBUztvQkFDcEIsT0FBTyxDQUFDLENBQUM7aUJBQ1osQ0FBQyxDQUFDOzs7Ozs7UUFNVCwyQ0FBYTs7OztzQkFBQyxRQUFhO2dCQUVqQyxPQUFPLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7Z0JBRW5ELHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7Z0JBQ3JCLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDO2dCQUV0QyxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDdEIsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsd0JBQXdCLENBQUM7cUJBQzNDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLGdCQUFnQixDQUFDO3FCQUNuQyxJQUFJLENBQUMsUUFBUSxFQUFFLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQztxQkFDeEMsSUFBSSxDQUFDLFdBQVcsRUFBRSxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQzs7Ozs7O1FBUTlDLHdDQUFVOzs7O3NCQUFDLFFBQWE7Z0JBRTlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLENBQUMsQ0FBQztnQkFFaEQscUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztnQkFDckIscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7Z0JBRXRDLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDO2dCQUM1QixxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFFckMscUJBQU0sV0FBVyxHQUFHZSxjQUFjLEVBQUU7cUJBQ25CLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztxQkFDbEIsS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHLFlBQVksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUVsRCxZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDbkIsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsYUFBYSxDQUFDO3FCQUNoQyxJQUFJLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztxQkFDdkMsSUFBSSxDQUNDMEIsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUN2QixDQUFDOzs7Ozs7UUFPTix1Q0FBUzs7OztzQkFBQyxRQUFhO2dCQUU3QixPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7Z0JBRS9DLHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7Z0JBQ3JCLHFCQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUNsQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQztnQkFFdEMscUJBQU0sTUFBTSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO2dCQUNyQyxxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLGFBQWEsQ0FBQztnQkFDaEMscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7Z0JBQ2hDLHFCQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztnQkFFbkQsWUFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7cUJBQ3RCLElBQUksQ0FBQyxPQUFPLEVBQUUsZUFBZSxDQUFDO3FCQUM5QixJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztxQkFDaEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUM7cUJBQ2hCLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQzs7Ozs7O1FBT1osdUNBQVM7Ozs7c0JBQUMsUUFBYTtnQkFFN0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO2dCQUVoRCxxQkFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDO2dCQUNyQixxQkFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztnQkFDbEMscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7Z0JBRXRDLHFCQUFNLE1BQU0sR0FBSSxHQUFHLENBQUMsU0FBUyxDQUFDO2dCQUM5QixxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQztnQkFDNUIscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7Z0JBQ3JDLHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztnQkFDakQscUJBQU0sT0FBTyxHQUFHUCxRQUFRLENBQUMsTUFBTSxHQUFHLFlBQVksRUFDOUIsS0FBSyxHQUFHLFlBQVksRUFDcEIsTUFBTSxHQUFHLFlBQVksQ0FBQyxDQUFDO2dCQUV2QyxZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDbkIsU0FBUyxDQUFDLFFBQVEsQ0FBQztxQkFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQztxQkFDYixLQUFLLEVBQUU7cUJBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDZCxJQUFJLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQztxQkFDN0IsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztxQkFDbEMsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFFLENBQU0sRUFBRSxDQUFTO29CQUMzQixxQkFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ3pELE9BQU8sR0FBRyxDQUFDO2lCQUNkLENBQUM7cUJBQ0QsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7cUJBQ3pELElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBRSxDQUFNLEVBQUUsQ0FBUztvQkFDM0IscUJBQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO29CQUN6RCxPQUFPLEdBQUcsQ0FBQztpQkFDZCxDQUFDLENBQUM7OztvQkFocURSUSxjQUFTLFNBQUM7d0JBQ1QsUUFBUSxFQUFFLGdCQUFnQjt3QkFDMUIsUUFBUSxFQUFFLEVBQUU7d0JBQ1osTUFBTSxFQUFFLEVBQUU7cUJBQ1g7Ozs7O3dCQVhvREMsZUFBVTs7OztnQ0FhNURDLFVBQUs7K0JBQ0xBLFVBQUs7Z0NBQ0xBLFVBQUs7Z0NBQ0xBLFVBQUs7aUNBQ0xBLFVBQUs7O2tDQWpCUjs7Ozs7OztBQ0FBOzs7O29CQUdDQyxhQUFRLFNBQUM7d0JBQ1IsT0FBTyxFQUFFLEVBQ1I7d0JBQ0QsWUFBWSxFQUFFLENBQUMsbUJBQW1CLENBQUM7d0JBQ25DLE9BQU8sRUFBRSxDQUFDLG1CQUFtQixDQUFDO3FCQUMvQjs7K0JBUkQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OyJ9