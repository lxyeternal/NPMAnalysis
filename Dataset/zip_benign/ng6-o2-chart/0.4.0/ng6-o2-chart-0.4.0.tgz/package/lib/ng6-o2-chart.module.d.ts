export declare class Ng6O2ChartModule {
}
