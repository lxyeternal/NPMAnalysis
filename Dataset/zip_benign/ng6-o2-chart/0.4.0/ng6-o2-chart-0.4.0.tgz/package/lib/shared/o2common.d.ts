export declare class O2Common {
    svgContainer: any;
    configData: any;
    autoMaxX: number;
    autoMaxY: number;
    svgWidth: number;
    svgHeight: number;
    constructor(svgContainer: any, configData: any, autoMaxX: number, autoMaxY: number, svgWidth: number, svgHeight: number);
    readonly axisClassName: string;
    readonly lineClassName: string;
    readonly axisXBorderLineClassName: string;
    readonly maxXValue: number;
    readonly maxYValue: number;
    readonly graphInitXPos: number;
    readonly graphInitYPos: number;
    readonly graphYScale: number;
    readonly graphXScale: number;
    readonly graphWidth: number;
    readonly graphHeight: number;
    readonly graphCenterPos: any;
    readonly graphCenterTranslatePos: string;
    readonly graphInitTranslatePos: string;
    readonly axisXLabelInitXPos: number;
    readonly axisXLabelInitYPos: number;
    readonly axisTranslatePos: string;
    readonly axisXBorderLineWidth: number;
    readonly axisYBorderHeight: number;
    readonly axisXBorderWidth: number;
    readonly axisYOrient: string;
    readonly axisXOrient: string;
    readonly axisXBorderTranslatePos: string;
    readonly innerRadiusPercent: number;
    readonly innerRadiusTitle: string;
    readonly innerRadiusTitleTranslatePos: string;
    readonly legendInitXPos: number;
    readonly legendInitYPos: number;
    readonly gridYStep: number;
    readonly gridXStep: number;
    readonly titleInitXPos: number;
    readonly titleInitYPos: number;
    readonly defaultColorFunc: any;
}
export declare class O2LineData {
    data: Array<number>;
    color: string;
    dashedArray: string;
    interpolate: string;
    constructor(data: Array<number>, color: string, dashedArray: string, interpolate: string);
}
export declare class O2LegendData {
    title: string;
    color: string;
    constructor(title: string, color: string);
}
export declare class O2ScatterPlotData {
    x: number;
    y: number;
    r: number;
    constructor(x: number, y: number, r: number);
}
export declare class O2StackBarData {
    x: string;
    y: number;
    constructor(x: string, y: number);
}
export declare class O2IdValueData {
    id: number;
    value: number;
    constructor(id: number, value: number);
}
