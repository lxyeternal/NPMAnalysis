import { select, format, scaleLinear, histogram, max, forceSimulation, forceLink, forceManyBody, forceCenter, drag, event, interpolateHsl, geoPath, geoMercator, json, scaleOrdinal, schemeCategory10, pack, hierarchy, tree, geoOrthographic, timer, stack, range, axisBottom, sum, pie, arc, line, curveLinear, axisLeft, schemeCategory20 } from 'd3';
import { Component, Input, ElementRef, NgModule } from '@angular/core';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
const /** @type {?} */ LINE_CHART_TYPE_NAME = 'line';
const /** @type {?} */ BAR_CHART_TYPE_NAME = 'bar';
const /** @type {?} */ PIE_CHART_TYPE_NAME = 'pie';
const /** @type {?} */ SCATTER_PLOT_CHART_TYPE_NAME = 'scatterPlot';
const /** @type {?} */ HISTOGRAM_CHART_TYPE_NAME = 'histogram';
const /** @type {?} */ STACK_BAR_CHART_TYPE_NAME = 'stackBar';
const /** @type {?} */ GEO_MAP_CHART_TYPE_NAME = 'geoMap';
const /** @type {?} */ GEO_ORTHOGRAPHIC_CHART_TYPE_NAME = 'geoOrthographic';
const /** @type {?} */ TREE_MAP_CHART_TYPE_NAME = 'treeMap';
const /** @type {?} */ PACK_LAYOUT_CHART_TYPE_NAME = 'packLayout';
const /** @type {?} */ CHOROPLETH_CHART_TYPE_NAME = 'choropleth';
const /** @type {?} */ TREE_CHART_TYPE_NAME = 'tree';
const /** @type {?} */ SANKEY_CHART_TYPE_NAME = 'sankey';
const /** @type {?} */ FORCE_CHART_TYPE_NAME = 'force';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class O2Common {
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} autoMaxX
     * @param {?} autoMaxY
     * @param {?} svgWidth
     * @param {?} svgHeight
     */
    constructor(svgContainer, configData, autoMaxX, autoMaxY, svgWidth, svgHeight) {
        this.svgContainer = svgContainer;
        this.configData = configData;
        this.autoMaxX = autoMaxX;
        this.autoMaxY = autoMaxY;
        this.svgWidth = svgWidth;
        this.svgHeight = svgHeight;
    }
    /**
     * @return {?}
     */
    get axisClassName() {
        return this.configData.className.axis;
    }
    /**
     * @return {?}
     */
    get lineClassName() {
        return this.configData.className.line;
    }
    /**
     * @return {?}
     */
    get axisXBorderLineClassName() {
        return this.configData.className.axisXBorder;
    }
    /**
     * @return {?}
     */
    get maxXValue() {
        let /** @type {?} */ _maxX = this.autoMaxX;
        if (!this.configData.maxValue.auto) {
            _maxX = this.configData.maxValue.x;
        }
        return _maxX;
    }
    /**
     * @return {?}
     */
    get maxYValue() {
        let /** @type {?} */ _maxY = this.autoMaxY;
        if (!this.configData.maxValue.auto) {
            _maxY = this.configData.maxValue.y;
        }
        return _maxY;
    }
    /**
     * @return {?}
     */
    get graphInitXPos() {
        let /** @type {?} */ _intX = this.configData.margin.left;
        if (this.configData.legend.display && this.configData.legend.position !== 'right') {
            _intX = this.configData.margin.left
                + this.configData.legend.totalWidth;
        }
        return _intX;
    }
    /**
     * @return {?}
     */
    get graphInitYPos() {
        const /** @type {?} */ _intY = this.configData.margin.top
            + this.configData.title.height;
        return _intY;
    }
    /**
     * @return {?}
     */
    get graphYScale() {
        return this.graphHeight / this.maxYValue;
    }
    /**
     * @return {?}
     */
    get graphXScale() {
        return this.graphWidth / this.maxXValue;
    }
    /**
     * @return {?}
     */
    get graphWidth() {
        let /** @type {?} */ _margin = this.configData.margin.left
            + this.configData.margin.right;
        if (this.configData.legend.display) {
            _margin += this.configData.legend.totalWidth;
        }
        return this.svgWidth - _margin;
    }
    /**
     * @return {?}
     */
    get graphHeight() {
        const /** @type {?} */ _h = this.svgHeight
            - this.configData.title.height
            - this.configData.margin.top
            - this.configData.margin.bottom;
        return _h;
    }
    /**
     * @return {?}
     */
    get graphCenterPos() {
        const /** @type {?} */ _xyArray = new Array();
        const /** @type {?} */ _x = this.configData.margin.left
            + this.graphWidth / 2;
        const /** @type {?} */ _y = this.configData.margin.top
            + this.configData.title.height
            + this.graphHeight / 2;
        _xyArray.push(_x);
        _xyArray.push(_y);
        return _xyArray;
    }
    /**
     * @return {?}
     */
    get graphCenterTranslatePos() {
        const /** @type {?} */ _x = this.configData.margin.left
            + this.graphWidth / 2;
        const /** @type {?} */ _y = this.configData.margin.top
            + this.configData.title.height
            + this.graphHeight / 2;
        return 'translate(' + String(_x) + ', ' + String(_y) + ')';
    }
    /**
     * @return {?}
     */
    get graphInitTranslatePos() {
        const /** @type {?} */ _x = this.graphInitXPos;
        const /** @type {?} */ _y = this.graphInitYPos;
        return 'translate(' + String(_x) + ', ' + String(_y) + ')';
    }
    /**
     * @return {?}
     */
    get axisXLabelInitXPos() {
        const /** @type {?} */ _x = this.configData.margin.left
            + this.configData.axis.xLabel.leftMargin;
        return _x;
    }
    /**
     * @return {?}
     */
    get axisXLabelInitYPos() {
        const /** @type {?} */ _y = this.svgHeight
            - this.configData.axis.xLabel.bottomMargin;
        return _y;
    }
    /**
     * @return {?}
     */
    get axisTranslatePos() {
        const /** @type {?} */ _x = this.configData.margin.left;
        const /** @type {?} */ _y = this.configData.margin.top
            + this.configData.title.height;
        return 'translate(' + String(_x) + ', ' + String(_y) + ')';
    }
    /**
     * @return {?}
     */
    get axisXBorderLineWidth() {
        return this.configData.axis.borderLineWidth;
    }
    /**
     * @return {?}
     */
    get axisYBorderHeight() {
        const /** @type {?} */ _margin = this.configData.margin.top
            + this.configData.margin.bottom
            + this.configData.title.height;
        return this.svgHeight - _margin;
    }
    /**
     * @return {?}
     */
    get axisXBorderWidth() {
        let /** @type {?} */ _margin = this.configData.margin.left
            + this.configData.margin.right;
        if (this.configData.legend.display) {
            _margin += this.configData.legend.totalWidth;
        }
        return this.svgWidth - _margin;
    }
    /**
     * @return {?}
     */
    get axisYOrient() {
        return 'left';
    }
    /**
     * @return {?}
     */
    get axisXOrient() {
        return 'bottom';
    }
    /**
     * @return {?}
     */
    get axisXBorderTranslatePos() {
        const /** @type {?} */ sYpos = String(this.svgHeight - this.configData.margin.bottom);
        return 'translate(' + this.configData.margin.left + ', ' + sYpos + ')';
    }
    /**
     * @return {?}
     */
    get innerRadiusPercent() {
        return this.configData.pie.innerRadius.percent;
    }
    /**
     * @return {?}
     */
    get innerRadiusTitle() {
        return this.configData.pie.innerRadius.title;
    }
    /**
     * @return {?}
     */
    get innerRadiusTitleTranslatePos() {
        const /** @type {?} */ _x = this.configData.margin.left
            + this.graphWidth / 2;
        const /** @type {?} */ _y = this.configData.margin.top
            + this.configData.title.height
            + this.graphHeight / 2
            + 5;
        return 'translate(' + String(_x) + ', ' + String(_y) + ')';
    }
    /**
     * @return {?}
     */
    get legendInitXPos() {
        let /** @type {?} */ _x = this.configData.margin.left
            + this.graphWidth
            + this.configData.legend.initXPos;
        if (this.configData.legend.position !== 'right') {
            _x = this.configData.margin.left
                + this.configData.legend.initXPos;
        }
        return _x;
    }
    /**
     * @return {?}
     */
    get legendInitYPos() {
        const /** @type {?} */ _y = this.configData.margin.top
            + this.configData.title.height
            + this.configData.legend.initYPos;
        return _y;
    }
    /**
     * @return {?}
     */
    get gridYStep() {
        const /** @type {?} */ _maxY = Math.ceil(this.maxYValue / 100) * 10;
        const /** @type {?} */ _lineNum = 10;
        const /** @type {?} */ _step = Math.ceil(_maxY / _lineNum) * _lineNum;
        return _step;
    }
    /**
     * @return {?}
     */
    get gridXStep() {
        const /** @type {?} */ _maxX = Math.ceil(this.maxXValue / 100) * 10;
        const /** @type {?} */ _lineNum = 10;
        const /** @type {?} */ _step = Math.ceil(_maxX / _lineNum) * _lineNum;
        return _step;
    }
    /**
     * @return {?}
     */
    get titleInitXPos() {
        const /** @type {?} */ _x = this.configData.margin.left
            + (this.graphWidth + this.configData.legend.totalWidth) / 2
            + this.configData.title.leftMargin;
        return _x;
    }
    /**
     * @return {?}
     */
    get titleInitYPos() {
        const /** @type {?} */ _y = this.configData.margin.top
            + this.configData.title.height
            - this.configData.title.bottomMargin;
        return _y;
    }
    /**
     * @return {?}
     */
    get defaultColorFunc() {
        let /** @type {?} */ _color;
        if (this.configData.color.auto) {
            if (this.configData.color.defaultColorNumber === '20') {
                _color = scaleOrdinal(schemeCategory20);
            }
            else {
                _color = scaleOrdinal(schemeCategory10);
            }
        }
        return _color;
    }
}
class O2LegendData {
    /**
     * @param {?} title
     * @param {?} color
     */
    constructor(title, color) {
        this.title = title;
        this.color = color;
    }
}
class O2ScatterPlotData {
    /**
     * @param {?} x
     * @param {?} y
     * @param {?} r
     */
    constructor(x, y, r) {
        this.x = x;
        this.y = y;
        this.r = r;
    }
}
class O2IdValueData {
    /**
     * @param {?} id
     * @param {?} value
     */
    constructor(id, value) {
        this.id = id;
        this.value = value;
    }
}
// export class O2KeyValueData {
//     constructor(
//        public key: string,
// 	   public value: number
//        ) { }
// }
// export class O2DateKVArrayData {
//     constructor(
//        public date: Date,
// 	   public kvArray: Array<O2KeyValueData>
//        ) { }
// }
// export class O2DateStKVArrayData {
//     constructor(
//        public dateSt: string,
// 	   public kvArray: Array<O2KeyValueData>
//        ) { }
// }

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class Ng6O2ChartComponent {
    /**
     * @param {?} elementRef
     */
    constructor(elementRef) {
        console.log('el:HTMLElement-------------------');
        const /** @type {?} */ el = elementRef.nativeElement;
        this.root = select(el);
    }
    /**
     * @return {?}
     */
    ngOnInit() {
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    ngOnChanges(changes) {
        const /** @type {?} */ svgWidth = parseInt(this.svgWidth, 10);
        const /** @type {?} */ svgHeight = parseInt(this.svgHeight, 10);
        const /** @type {?} */ dataSet = this.graphData;
        const /** @type {?} */ configData = this.configData;
        const /** @type {?} */ chartType = this.chartType;
        const /** @type {?} */ svgContainer = this.root.append('svg')
            .attr('width', svgWidth)
            .attr('height', svgHeight);
        console.log(chartType);
        switch (chartType) {
            case LINE_CHART_TYPE_NAME:
                this.buildLine(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case BAR_CHART_TYPE_NAME:
                this.buildBar(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case PIE_CHART_TYPE_NAME:
                this.buildPie(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case SCATTER_PLOT_CHART_TYPE_NAME:
                this.buildScatterPlot(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case HISTOGRAM_CHART_TYPE_NAME:
                this.buildHistogram(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case STACK_BAR_CHART_TYPE_NAME:
                this.buildStackBar(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case GEO_MAP_CHART_TYPE_NAME:
                this.buildGeoMap(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case GEO_ORTHOGRAPHIC_CHART_TYPE_NAME:
                this.buildGeoOrthographic(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case TREE_CHART_TYPE_NAME:
                this.buildTree(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case PACK_LAYOUT_CHART_TYPE_NAME:
                this.buildPackLayout(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case CHOROPLETH_CHART_TYPE_NAME:
                this.buildChoropleth(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case FORCE_CHART_TYPE_NAME:
                this.buildForce(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case TREE_MAP_CHART_TYPE_NAME:
                //  this.buildTreeMap(svgContainer,configData, dataSet,svgWidth,svgHeight );
                break;
            case SANKEY_CHART_TYPE_NAME:
                //  this.buildSankey(svgContainer,configData, dataSet,svgWidth,svgHeight );
                break;
            default:
                break;
        }
    }
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    buildHistogram(svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in buildHistogram-------------------');
        const /** @type {?} */ dataSet = dataSetJson.data;
        const /** @type {?} */ _binNumber = dataSetJson.bins.length - 1;
        const /** @type {?} */ _maxY = 300; // dummy number
        const /** @type {?} */ _maxX = dataSetJson.range[1];
        const /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        const /** @type {?} */ _graphWidth = cdt.graphWidth;
        const /** @type {?} */ _graphHeight = cdt.graphHeight;
        const /** @type {?} */ _graphInitX = cdt.graphInitXPos;
        const /** @type {?} */ _graphInitY = cdt.graphInitYPos;
        const /** @type {?} */ _titleDisplay = configData.title.display;
        const /** @type {?} */ _animation = configData.animation.enable;
        const /** @type {?} */ _animationDuration = configData.animation.duration;
        const /** @type {?} */ _gridYDisplay = configData.grid.y.display;
        const /** @type {?} */ _marginLeft = configData.margin.left;
        const /** @type {?} */ _marginTop = configData.margin.top;
        const /** @type {?} */ _className = configData.className.histogramBar;
        const /** @type {?} */ _dataSet = new Array();
        for (const /** @type {?} */ i in dataSet) {
            if (dataSet.hasOwnProperty(i)) {
                const /** @type {?} */ _num = dataSet[i] / _maxX;
                _dataSet.push(_num);
            }
        }
        const /** @type {?} */ formatCount = format(',.0f');
        const /** @type {?} */ _histgramContainer = svgContainer
            .append('g')
            .attr('transform', 'translate(' + _graphInitX + ',' + _graphInitY + ')');
        const /** @type {?} */ _xScale = scaleLinear()
            .rangeRound([0, _graphWidth]);
        const /** @type {?} */ bins = histogram()
            .domain([0, 1])
            .thresholds(_xScale.ticks(_binNumber))(_dataSet);
        const /** @type {?} */ _yScale = scaleLinear()
            .domain([0, max(bins, (d) => {
                return d.length;
            })])
            .range([_graphHeight, 0]);
        const /** @type {?} */ bar = _histgramContainer
            .selectAll('.bar')
            .data(bins)
            .enter()
            .append('g')
            .attr('class', _className)
            .attr('transform', (d) => {
            return 'translate(' + _xScale(d.x0) + ',' + _yScale(d.length) + ')';
        });
        if (_animation) {
            bar.append('rect')
                .attr('x', 1)
                .attr('width', _xScale(bins[0].x1) - _xScale(bins[0].x0) - 1)
                .attr('height', 0)
                .transition()
                .duration(_animationDuration)
                .attr('height', (d) => {
                return _graphHeight - _yScale(d.length);
            });
        }
        else {
            bar.append('rect')
                .attr('x', 1)
                .attr('width', _xScale(bins[0].x1) - _xScale(bins[0].x0) - 1)
                .attr('height', (d) => {
                return _graphHeight - _yScale(d.length);
            });
        }
        bar.append('text')
            .attr('dy', '.75em')
            .attr('y', 6)
            .attr('x', (_xScale(bins[0].x1) - _xScale(bins[0].x0)) / 2)
            .attr('text-anchor', 'middle')
            .text((d) => {
            return formatCount(d.length);
        });
        // ---CALL buildTitle-----------------
        if (_titleDisplay) {
            this.drawTitle(cdt);
        }
        // ------------------------------------
        // ---CALL buildAxis-----------------
        this.buildYAxis(cdt);
        this.buildXAxis(cdt);
        if (_gridYDisplay) {
            this.drawYGrid(cdt);
        }
    }
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    buildForce(svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('In  buildFoce----------------');
        const /** @type {?} */ _maxX = 100;
        const /** @type {?} */ _maxY = 100;
        const /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        const /** @type {?} */ _color = cdt.defaultColorFunc;
        const /** @type {?} */ _graphHeight = cdt.graphHeight;
        const /** @type {?} */ _graphWidth = cdt.graphWidth;
        const /** @type {?} */ _marginLeft = configData.margin.left;
        const /** @type {?} */ _marginTop = configData.margin.top;
        const /** @type {?} */ simulation = forceSimulation()
            .force('link', forceLink().id((d) => {
            return d.id;
        }))
            .force('charge', forceManyBody())
            .force('center', forceCenter(_graphWidth / 2, _graphHeight / 2));
        const /** @type {?} */ _forceContainer = svgContainer
            .append('g')
            .attr('transform', 'translate(' + _marginLeft + ',' + _marginTop + ')');
        const /** @type {?} */ link = _forceContainer.append('g')
            .attr('class', 'force-links')
            .selectAll('line')
            .data(dataSetJson.links)
            .enter()
            .append('line')
            .attr('stroke-width', (d) => {
            return Math.sqrt(d.value);
        });
        const /** @type {?} */ node = _forceContainer.append('g')
            .attr('class', 'nodes')
            .selectAll('circle')
            .data(dataSetJson.nodes)
            .enter()
            .append('circle')
            .attr('r', 5)
            .attr('fill', (d) => {
            return _color(d.group);
        })
            .call(drag()
            .on('start', dragstarted)
            .on('drag', dragged)
            .on('end', dragended));
        node.append('title')
            .text((d) => {
            return d.id;
        });
        simulation
            .nodes(dataSetJson.nodes)
            .on('tick', ticked);
        const /** @type {?} */ _forceLink = simulation.force('link');
        _forceLink.links(dataSetJson.links);
        /**
         * @return {?}
         */
        function ticked() {
            link
                .attr('x1', (d) => {
                return d.source.x;
            })
                .attr('y1', (d) => {
                return d.source.y;
            })
                .attr('x2', (d) => {
                return d.target.x;
            })
                .attr('y2', (d) => {
                return d.target.y;
            });
            node
                .attr('cx', (d) => {
                return d.x;
            })
                .attr('cy', (d) => {
                return d.y;
            });
        }
        /**
         * @param {?} d
         * @return {?}
         */
        function dragstarted(d) {
            if (!event.active) {
                simulation.alphaTarget(0.3).restart();
            }
            d.fx = d.x;
            d.fy = d.y;
        }
        /**
         * @param {?} d
         * @return {?}
         */
        function dragged(d) {
            d.fx = event.x;
            d.fy = event.y;
        }
        /**
         * @param {?} d
         * @return {?}
         */
        function dragended(d) {
            if (!event.active) {
                simulation.alphaTarget(0);
            }
            d.fx = null;
            d.fy = null;
        }
        //  ------------------------------------
        //  ---CALL buildLegend-----------------
        const /** @type {?} */ _legendDataSet = new Array();
        for (const /** @type {?} */ i in dataSetJson.groups) {
            if (dataSetJson.groups.hasOwnProperty(i)) {
                const /** @type {?} */ _id = dataSetJson.groups[i].id;
                _legendDataSet.push(new O2LegendData(dataSetJson.groups[i].name, _color(_id)));
            }
        }
        this.buildLegend(cdt, _legendDataSet);
    }
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    buildChoropleth(svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in buildChoropleth -------------------');
        const /** @type {?} */ _maxX = 100; // any value
        const /** @type {?} */ _maxY = 100; // any value
        const /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        const /** @type {?} */ _graphCenterPos = cdt.graphCenterPos;
        const /** @type {?} */ _titleDisplay = configData.title.display;
        const /** @type {?} */ _legendDisplay = configData.legend.display;
        const /** @type {?} */ _focusColor = configData.color.focusColor;
        const /** @type {?} */ _scale = dataSetJson.map.scale;
        const /** @type {?} */ _targetName = dataSetJson.map.targetName;
        const /** @type {?} */ _keyDataName = dataSetJson.map.keyDataName;
        const /** @type {?} */ _keyName = 'data.' + _keyDataName;
        const /** @type {?} */ _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
        const /** @type {?} */ _startColor = dataSetJson.map.startColor;
        const /** @type {?} */ _endColor = dataSetJson.map.endColor;
        const /** @type {?} */ _colorNum = dataSetJson.map.colorNumber;
        const /** @type {?} */ _center = dataSetJson.map.center;
        const /** @type {?} */ _targetPropertyName = dataSetJson.map.targetPropertyName;
        const /** @type {?} */ _targetProperty = 'd.' + _targetPropertyName;
        const /** @type {?} */ color = interpolateHsl(_startColor, _endColor);
        let /** @type {?} */ _max = dataSetJson.data[0].value;
        let /** @type {?} */ _min = dataSetJson.data[0].value;
        for (const /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                if (_max < dataSetJson.data[i].value) {
                    _max = dataSetJson.data[i].value;
                }
                if (_min > dataSetJson.data[i].value) {
                    _min = dataSetJson.data[i].value;
                }
            }
        }
        const /** @type {?} */ _range = _max - _min;
        const /** @type {?} */ _step = _range / (_colorNum - 1);
        const /** @type {?} */ _findColorById = (id) => {
            for (const /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    if (id === dataSetJson.data[i].id) {
                        const /** @type {?} */ _value = dataSetJson.data[i].value;
                        const /** @type {?} */ _rate = Math.ceil((_value - _min) / _step);
                        return color(_rate / _max);
                    }
                }
            }
        };
        const /** @type {?} */ path = geoPath()
            .projection(geoMercator()
            .center(_center)
            .scale(_scale)
            .translate(_graphCenterPos));
        json(_geoMapDataUrl, (error, data) => {
            svgContainer.selectAll('path')
                .data(eval(_keyName))
                .enter()
                .append('path')
                .attr('d', path)
                .style('fill', (d, i) => {
                const /** @type {?} */ _cl = _findColorById(eval(_targetProperty));
                return _cl;
            });
        });
        // ------------------------------------
        // ---CALL buildTitle-----------------
        if (_titleDisplay) {
            this.drawTitle(cdt);
        }
        //  ------------------------------------
        //  ---CALL buildLegend-----------------
        if (_legendDisplay) {
            const /** @type {?} */ _legendDataSet = new Array();
            for (let /** @type {?} */ i = 0; i < _colorNum; i++) {
                const /** @type {?} */ _label = String(_min + (i * _step)) + ' --';
                _legendDataSet.push(new O2LegendData(_label, color(i / _max)));
            }
            this.buildLegend(cdt, _legendDataSet);
        }
    }
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    buildPackLayout(svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in PackLayout------------------');
        const /** @type {?} */ _packlayoutClass = configData.className.packlayout;
        const /** @type {?} */ _packlayoutLabelClass = configData.className.packlayoutLabel;
        const /** @type {?} */ _animation = configData.animation.enable;
        const /** @type {?} */ _animationDuration = configData.animation.duration;
        const /** @type {?} */ color = scaleOrdinal(schemeCategory10);
        //  const color = d3.scale.category10();
        const /** @type {?} */ bubble = pack()
            .size([svgWidth, svgHeight]);
        const /** @type {?} */ nodes0 = hierarchy(dataSetJson);
        const /** @type {?} */ pack$$1 = svgContainer.selectAll('g')
            .data(bubble(nodes0).descendants())
            .enter()
            .append('g')
            .attr('transform', (d, i) => {
            return 'translate(' + d.x + ',' + d.y + ')';
        });
        const /** @type {?} */ _circle = pack$$1.append('circle');
        if (_animation) {
            _circle.attr('r', 0)
                .transition()
                .duration((d, i) => {
                return d.depth * _animationDuration + 500;
            })
                .attr('r', (d) => {
                return d.r;
            })
                .style('fill', (d, i) => {
                return color(i);
            });
        }
        else {
            _circle.attr('r', (d) => {
                return d.r;
            })
                .style('fill', (d, i) => {
                return color(i);
            });
        }
        const /** @type {?} */ _text = pack$$1.append('text')
            .attr('class', _packlayoutLabelClass)
            .text((d, i) => {
            if (d.depth === 1) {
                return d.data.name;
            }
            return null;
        });
        if (_animation) {
            _text.style('opacity', 0)
                .transition()
                .duration(_animationDuration)
                .style('opacity', 1.0);
        }
        else {
            _text.style('opacity', 1.0);
        }
    }
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    buildTree(svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('In  buildTree----------------');
        let /** @type {?} */ _maxX = 0;
        let /** @type {?} */ _maxY = 0;
        _maxY = 100;
        _maxX = 100;
        const /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        const /** @type {?} */ _graphHeight = cdt.graphHeight;
        const /** @type {?} */ _graphWidth = cdt.graphWidth;
        const /** @type {?} */ _animation = configData.animation.enable;
        const /** @type {?} */ _animationDuration = configData.animation.duration;
        const /** @type {?} */ _treemapClass = configData.className.treemap;
        const /** @type {?} */ _treemapLabelClass = configData.className.treemapLabel;
        const /** @type {?} */ _marginLeft = configData.margin.left;
        const /** @type {?} */ _marginTop = configData.margin.top;
        const /** @type {?} */ tree$$1 = tree()
            .size([_graphWidth, _graphHeight]);
        const /** @type {?} */ nodes0 = hierarchy(dataSetJson);
        const /** @type {?} */ nodes = tree$$1(nodes0);
        const /** @type {?} */ _treeContainer = svgContainer
            .append('g')
            .attr('transform', 'translate(' + _marginLeft + ',' + _marginTop + ')');
        const /** @type {?} */ link = _treeContainer
            .selectAll('.link')
            .data(nodes.descendants().slice(1))
            .enter()
            .append('path')
            .attr('class', 'tree-node-link')
            .attr('d', (d) => {
            return 'M' + d.x + ',' + d.y
                + 'C' + d.x + ',' + (d.y + d.parent.y) / 2
                + ' ' + d.parent.x + ',' + (d.y + d.parent.y) / 2
                + ' ' + d.parent.x + ',' + d.parent.y;
        });
        const /** @type {?} */ node = _treeContainer
            .selectAll('.node')
            .data(nodes.descendants())
            .enter()
            .append('g')
            .attr('class', (d) => {
            return 'tree-node' +
                (d.children ? '-internal' : '-leaf');
        })
            .attr('transform', (d) => {
            return 'translate(' + d.x + ',' + d.y + ')';
        });
        node.append('circle')
            .attr('r', 10);
        node.append('text')
            .attr('dy', '.35em')
            .attr('y', (d) => {
            return d.children ? -20 : 20;
        })
            .style('text-anchor', 'middle')
            .text((d) => {
            return d.data.name;
        });
    }
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    buildGeoOrthographic(svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in buildGeoOrthographic -------------------');
        const /** @type {?} */ _maxX = 100; // any value
        const /** @type {?} */ _maxY = 100; // any value
        const /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        const /** @type {?} */ _graphCenterPos = cdt.graphCenterPos;
        const /** @type {?} */ _titleDisplay = configData.title.display;
        const /** @type {?} */ _legendDisplay = configData.legend.display;
        const /** @type {?} */ _focusColor = configData.color.focusColor;
        const /** @type {?} */ _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
        const /** @type {?} */ _scale = dataSetJson.map.scale;
        const /** @type {?} */ _targetName = dataSetJson.map.targetName;
        const /** @type {?} */ _targetProperty = 'd.' + dataSetJson.map.targetPropertyName;
        const /** @type {?} */ _keyDataName = dataSetJson.map.keyDataName;
        const /** @type {?} */ _keyName = 'data.' + _keyDataName;
        const /** @type {?} */ _clipAngle = dataSetJson.map.clipAngle;
        const /** @type {?} */ _rotateH = dataSetJson.map.rotate.horizontal;
        const /** @type {?} */ _rotateV = dataSetJson.map.rotate.vertical;
        const /** @type {?} */ _oceanColor = dataSetJson.map.oceanColor;
        const /** @type {?} */ _antarcticaColor = dataSetJson.map.antarcticaColor;
        const /** @type {?} */ _animation = configData.animation.enable;
        const /** @type {?} */ _animationDuration = configData.animation.duration;
        let /** @type {?} */ _animationH = 0;
        const /** @type {?} */ _findColorByName = (name) => {
            for (const /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    if (name === dataSetJson.data[i].name) {
                        const /** @type {?} */ _color = dataSetJson.data[i].color;
                        return _color;
                    }
                }
            }
            return null;
        };
        const /** @type {?} */ targetPath = geoOrthographic()
            .translate(_graphCenterPos)
            .clipAngle(_clipAngle)
            .scale(_scale)
            .rotate([_rotateH, _rotateV]);
        const /** @type {?} */ path = geoPath()
            .projection(targetPath);
        json(_geoMapDataUrl, (error, data) => {
            svgContainer.append('circle')
                .attr('cx', _graphCenterPos[0])
                .attr('cy', _graphCenterPos[1])
                .attr('r', _scale)
                .style('fill', _oceanColor);
            const /** @type {?} */ earthPath = svgContainer.selectAll('path')
                .data(eval(_keyName))
                .enter()
                .append('path')
                .attr('d', path)
                .style('fill', (d, i) => {
                const /** @type {?} */ _targetArea = eval(_targetProperty);
                if (_findColorByName(_targetArea) !== null) {
                    return _findColorByName(_targetArea);
                }
                return 'hsl(' + i + ',80%,60%)';
            });
            if (_animation) {
                timer(() => {
                    targetPath.rotate([_rotateH + _animationH, _rotateV]);
                    _animationH += 2;
                    earthPath.attr('d', path);
                });
            }
        });
        // ------------------------------------
        // ---CALL buildTitle-----------------
        if (_titleDisplay) {
            this.drawTitle(cdt);
        }
        if (_legendDisplay) {
            const /** @type {?} */ _legendDataSet = new Array();
            for (const /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    const /** @type {?} */ _name = dataSetJson.data[i].name;
                    const /** @type {?} */ _color = dataSetJson.data[i].color;
                    if (_name === 'Antarctica') {
                        continue;
                    }
                    _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, dataSetJson.data[i].color));
                }
            }
            this.buildLegend(cdt, _legendDataSet);
        }
    }
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    buildGeoMap(svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in buildGeoMap -------------------');
        const /** @type {?} */ _maxX = 100; // any value
        const /** @type {?} */ _maxY = 100; // any value
        const /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        const /** @type {?} */ _graphCenterPos = cdt.graphCenterPos;
        const /** @type {?} */ _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
        const /** @type {?} */ _scale = dataSetJson.map.scale;
        const /** @type {?} */ _keyDataName = dataSetJson.map.keyDataName;
        const /** @type {?} */ _keyName = 'data.' + _keyDataName;
        const /** @type {?} */ _targetProperty = 'd.' + dataSetJson.map.targetPropertyName;
        const /** @type {?} */ _antarcticaColor = dataSetJson.map.antarcticaColor;
        const /** @type {?} */ _legendDisplay = configData.legend.display;
        const /** @type {?} */ path = geoPath()
            .projection(geoMercator()
            .translate(_graphCenterPos)
            .scale(_scale));
        const /** @type {?} */ _findColorByName = (name) => {
            for (const /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    if (name === dataSetJson.data[i].name) {
                        const /** @type {?} */ _color = dataSetJson.data[i].color;
                        return _color;
                    }
                }
            }
            return null;
        };
        json(_geoMapDataUrl, (error, data) => {
            svgContainer.selectAll('path')
                .data(eval(_keyName))
                .enter()
                .append('path')
                .attr('d', path)
                .style('fill', (d, i) => {
                const /** @type {?} */ _targetArea = eval(_targetProperty);
                if (_findColorByName(_targetArea) !== null) {
                    return _findColorByName(_targetArea);
                }
                return 'hsl(' + i + ',80%,60%)';
            });
        });
        //  ------------------------------------
        //  ---CALL buildLegend-----------------
        if (_legendDisplay) {
            const /** @type {?} */ _legendDataSet = new Array();
            for (const /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    const /** @type {?} */ _name = dataSetJson.data[i].name;
                    const /** @type {?} */ _color = dataSetJson.data[i].color;
                    if (_name === 'Antarctica') {
                        continue;
                    }
                    _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, dataSetJson.data[i].color));
                }
            }
            this.buildLegend(cdt, _legendDataSet);
        }
    }
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    buildStackBar(svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in buildStackBar-------------------');
        const /** @type {?} */ _totalY = new Array();
        for (const /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                _totalY.push(0);
            }
        }
        for (const /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                let /** @type {?} */ k = 0;
                for (const /** @type {?} */ j in dataSetJson.data[i].value) {
                    if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                        _totalY[k++] += dataSetJson.data[i].value[j].y;
                    }
                }
            }
        }
        let /** @type {?} */ _maxX = 0;
        let /** @type {?} */ _maxY = 0;
        _maxY = max(_totalY);
        _maxX = 100;
        const /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        const /** @type {?} */ _color = cdt.defaultColorFunc;
        const /** @type {?} */ _columnNum = dataSetJson.data.length;
        const /** @type {?} */ _barWidth = (cdt.graphWidth / _columnNum) - configData.margin.between;
        const /** @type {?} */ _columnWidth = (cdt.graphWidth / _columnNum);
        const /** @type {?} */ _initPosX = cdt.graphInitXPos;
        const /** @type {?} */ _graphHeight = cdt.graphHeight;
        const /** @type {?} */ _maxYValue = cdt.maxYValue;
        const /** @type {?} */ _opacity = configData.color.opacity;
        const /** @type {?} */ _legendDisplay = configData.legend.display;
        const /** @type {?} */ _gridYDisplay = configData.grid.y.display;
        const /** @type {?} */ _gridXDisplay = configData.grid.x.display;
        const /** @type {?} */ _labelDisplay = configData.label.display;
        const /** @type {?} */ _animation = configData.animation.enable;
        const /** @type {?} */ _animationDuration = configData.animation.duration;
        //  Get Data Name
        const /** @type {?} */ _seriesDateName = dataSetJson.series[0];
        //  Get Keys
        const /** @type {?} */ _keyArray = new Array();
        for (const /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                const /** @type {?} */ _key = dataSetJson.data[i].name;
                const /** @type {?} */ _value = dataSetJson.data[i].value[0].y;
                _keyArray.push(_key);
            }
        }
        //  Get Date String
        const /** @type {?} */ _dateArray = new Array();
        for (const /** @type {?} */ i in dataSetJson.data[0].value) {
            if (dataSetJson.data[0].value.hasOwnProperty(i)) {
                const /** @type {?} */ _xValue = dataSetJson.data[0].value[i].x;
                _dateArray.push(_xValue);
            }
        }
        const /** @type {?} */ _hashArray = new Array();
        for (const /** @type {?} */ i in _dateArray) {
            if (_dateArray.hasOwnProperty(i)) {
                const /** @type {?} */ _hashNumber = {};
                for (const /** @type {?} */ j in _keyArray) {
                    if (_keyArray.hasOwnProperty(j)) {
                        const /** @type {?} */ _key = _keyArray[j];
                        const /** @type {?} */ _value = dataSetJson.data[j].value[i].y;
                        _hashNumber[_key] = _value;
                    }
                }
                _hashArray.push(_hashNumber);
            }
        }
        const /** @type {?} */ yScale = scaleLinear()
            .domain([0, _maxYValue])
            .range([0, _graphHeight]);
        const /** @type {?} */ stack$$1 = stack();
        const /** @type {?} */ _rect = svgContainer.selectAll('g')
            .data(stack$$1.keys(_keyArray)(_hashArray))
            .enter()
            .append('g')
            .attr('fill', (d, i) => {
            return _color(i);
        })
            .attr('fill-opacity', _opacity)
            .selectAll('rect')
            .data((d, i) => {
            return d;
        })
            .enter()
            .append('rect');
        if (_animation) {
            _rect.attr('x', (d, i) => {
                return _initPosX + i * _columnWidth;
            })
                .attr('height', 0)
                .attr('y', (d, i) => {
                const /** @type {?} */ nm = 'd.data.' + _keyArray[i];
                const /** @type {?} */ _yValue = eval(nm);
                return svgHeight - configData.margin.bottom - yScale(d[1]);
            })
                .attr('width', _barWidth)
                .transition()
                .duration(_animationDuration)
                .attr('height', (d, i) => {
                return yScale(d[1] - d[0]);
            });
        }
        else {
            _rect.attr('x', (d, i) => {
                return _initPosX + (i * _columnWidth);
            })
                .attr('y', (d, i) => {
                const /** @type {?} */ nm = 'd.data.' + _keyArray[i];
                const /** @type {?} */ _yValue = eval(nm);
                return svgHeight - configData.margin.bottom - yScale(d[1]);
            })
                .attr('width', _barWidth)
                .attr('height', (d, i) => {
                return yScale(d[1] - d[0]);
            });
        }
        // ------------------------------------
        // ---CALL buildTitle-----------------
        this.drawTitle(cdt);
        // ------------------------------------
        // ---CALL buildAxis-----------------
        this.buildYAxis(cdt);
        this.drawXBaseLine(cdt);
        //  ------------------------------------
        //  ---CALL drawXAxisLabel-----------------
        if (_labelDisplay) {
            const /** @type {?} */ _labelArray = new Array();
            for (const /** @type {?} */ i in dataSetJson.data[0].value) {
                if (dataSetJson.data[0].value.hasOwnProperty(i)) {
                    _labelArray.push(dataSetJson.data[0].value[i].x);
                }
            }
            this.drawXAxisLabel(cdt, _labelArray, STACK_BAR_CHART_TYPE_NAME);
        }
        //  ------------------------------------
        //  ---CALL buildLegend-----------------
        if (_legendDisplay) {
            const /** @type {?} */ _legendDataSet = new Array();
            for (const /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, _color(i)));
                }
            }
            this.buildLegend(cdt, _legendDataSet);
        }
        if (_gridYDisplay) {
            this.drawYGrid(cdt);
        }
    }
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    buildScatterPlot(svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('In  buildScatterPlot----------------');
        const /** @type {?} */ _dataSet = new Array();
        let /** @type {?} */ _maxX = 0;
        let /** @type {?} */ _maxY = 0;
        for (const /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                for (const /** @type {?} */ j in dataSetJson.data[i].value) {
                    if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                        if (_maxX < dataSetJson.data[i].value[j].x) {
                            _maxX = dataSetJson.data[i].value[j].x;
                        }
                        if (_maxY < dataSetJson.data[i].value[j].y) {
                            _maxY = dataSetJson.data[i].value[j].y;
                        }
                        const /** @type {?} */ _scatterPlotData = new O2ScatterPlotData(dataSetJson.data[i].value[j].x, dataSetJson.data[i].value[j].y, dataSetJson.data[i].value[j].r);
                        _dataSet.push(_scatterPlotData);
                    }
                }
            }
        }
        const /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        const /** @type {?} */ _initPosX = cdt.graphInitXPos;
        const /** @type {?} */ _seriesNumber = dataSetJson.series.length;
        const /** @type {?} */ _color = cdt.defaultColorFunc;
        const /** @type {?} */ _opacity = configData.color.opacity;
        const /** @type {?} */ _gridYDisplay = configData.grid.y.display;
        const /** @type {?} */ _gridXDisplay = configData.grid.x.display;
        const /** @type {?} */ _titleDisplay = configData.title.display;
        const /** @type {?} */ _legendDisplay = configData.legend.display;
        const /** @type {?} */ _circle = svgContainer.selectAll('circle')
            .data(_dataSet)
            .enter()
            .append('circle')
            .attr('cx', (d, i) => {
            return _initPosX + d.x;
        })
            .attr('cy', (d, i) => {
            return (svgHeight - configData.margin.bottom - d.y);
        })
            .attr('r', (d, i) => {
            return d.r;
        })
            .style('fill', (d, i) => {
            const /** @type {?} */ _colorNum = i % _seriesNumber;
            return _color(_colorNum);
        })
            .attr('fill-opacity', _opacity);
        // ---CALL buildTitle-----------------
        if (_titleDisplay) {
            this.drawTitle(cdt);
        }
        // ------------------------------------
        // ---CALL buildLegend-----------------
        if (_legendDisplay) {
            const /** @type {?} */ _legendDataSet = new Array();
            for (let /** @type {?} */ i = 0; i < dataSetJson.series.length; i++) {
                _legendDataSet.push(new O2LegendData(dataSetJson.series[i], _color(i)));
            }
            this.buildLegend(cdt, _legendDataSet);
        }
        // ------------------------------------
        // ---CALL buildAxis-----------------
        this.buildYAxis(cdt);
        this.buildXAxis(cdt);
        if (_gridYDisplay) {
            this.drawYGrid(cdt);
        }
        if (_gridXDisplay) {
            this.drawXGrid(cdt);
        }
    }
    /**
     * @param {?} o2Common
     * @return {?}
     */
    drawXGrid(o2Common) {
        console.log('in buildXGrid-------------------');
        const /** @type {?} */ cdt = o2Common;
        const /** @type {?} */ configData = cdt.configData;
        const /** @type {?} */ svgContainer = cdt.svgContainer;
        const /** @type {?} */ _stepX = cdt.gridXStep;
        const /** @type {?} */ _maxX = cdt.maxXValue;
        const /** @type {?} */ _graphYScale = cdt.graphYScale;
        const /** @type {?} */ _graphXScale = cdt.graphXScale;
        const /** @type {?} */ _graphWidth = cdt.graphWidth;
        const /** @type {?} */ _gridClassName = configData.className.grid;
        const /** @type {?} */ _axisXScale = scaleLinear()
            .domain([0, _maxX])
            .range([0, _maxX * _graphXScale]);
        const /** @type {?} */ _rangeX = range(_stepX * _graphXScale, _maxX * _graphXScale, _stepX * _graphXScale);
        svgContainer.append('g')
            .selectAll('line.x')
            .data(_rangeX)
            .enter()
            .append('line')
            .attr('class', _gridClassName)
            .attr('x1', (d, i) => {
            const /** @type {?} */ _x1 = configData.margin.left + d;
            return _x1;
        })
            .attr('y1', cdt.svgHeight - configData.margin.bottom)
            .attr('x2', (d, i) => {
            const /** @type {?} */ _x2 = configData.margin.left + d;
            return _x2;
        })
            .attr('y2', configData.margin.top + configData.title.height);
    }
    /**
     * @param {?} o2Common
     * @return {?}
     */
    buildXAxis(o2Common) {
        console.log('in buildXAxis-------------------');
        const /** @type {?} */ cdt = o2Common;
        const /** @type {?} */ configData = cdt.configData;
        const /** @type {?} */ svgContainer = cdt.svgContainer;
        const /** @type {?} */ _maxX = cdt.maxXValue;
        const /** @type {?} */ _graphXScale = cdt.graphXScale;
        const /** @type {?} */ _axisXScale = scaleLinear()
            .domain([0, _maxX])
            .range([0, _maxX * _graphXScale]);
        svgContainer.append('g')
            .attr('class', cdt.axisClassName)
            .attr('transform', cdt.axisXBorderTranslatePos)
            .call(axisBottom(_axisXScale));
        //  .scale()
        //  .orient(cdt.axisXOrient)
        //  );
    }
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    buildPie(svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('In  buildPie----------------');
        const /** @type {?} */ _maxX = 100;
        const /** @type {?} */ _maxY = 100;
        const /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        const /** @type {?} */ _color = cdt.defaultColorFunc;
        const /** @type {?} */ _graphHeight = cdt.graphHeight;
        const /** @type {?} */ _opacity = configData.color.opacity;
        const /** @type {?} */ _titleHeight = configData.title.height;
        const /** @type {?} */ _leftMargin = configData.margin.left;
        const /** @type {?} */ _topMargin = configData.margin.top;
        const /** @type {?} */ _bottomMargin = configData.margin.bottom;
        const /** @type {?} */ _betweenMargin = configData.margin.between;
        const /** @type {?} */ _innerRadiusPercent = cdt.innerRadiusPercent;
        const /** @type {?} */ _graphCenterTranslatePos = cdt.graphCenterTranslatePos;
        const /** @type {?} */ _pieClassName = configData.className.pie;
        const /** @type {?} */ _pieValueClassName = configData.className.pieNum;
        const /** @type {?} */ _pieInnerTitleClassName = configData.className.pieInnerTitle;
        const /** @type {?} */ _innerRadiusTitleTranslatePos = cdt.innerRadiusTitleTranslatePos;
        const /** @type {?} */ _innerRadiusTitle = cdt.innerRadiusTitle;
        const /** @type {?} */ _titleDisplay = configData.title.display;
        const /** @type {?} */ _legendDisplay = configData.legend.display;
        const /** @type {?} */ _labelDisplay = configData.label.display;
        const /** @type {?} */ _valueDisplay = configData.pie.value.display;
        const /** @type {?} */ _percentDisplay = configData.pie.percent.display;
        const /** @type {?} */ _animation = configData.animation.enable;
        const /** @type {?} */ _animationDuration = configData.animation.duration;
        const /** @type {?} */ dataSet = new Array();
        for (const /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                const /** @type {?} */ _num = dataSetJson.data[i].value;
                dataSet.push(_num);
            }
        }
        const /** @type {?} */ _sum = sum(dataSet);
        const /** @type {?} */ pie$$1 = pie();
        const /** @type {?} */ arc$$1 = arc()
            .innerRadius(_graphHeight * _innerRadiusPercent / 100)
            .outerRadius(_graphHeight / 2);
        const /** @type {?} */ pieElements = svgContainer.selectAll('path')
            .data(pie$$1(dataSet))
            .enter()
            .append('g')
            .attr('transform', _graphCenterTranslatePos);
        const /** @type {?} */ _makeCenterTitle = () => {
            if (_valueDisplay && _percentDisplay) {
                const /** @type {?} */ _st = _innerRadiusTitle + ':' + _sum + ' (100%)';
                return _st;
            }
            if (_percentDisplay) {
                return '100%';
            }
            if (_valueDisplay) {
                return _innerRadiusTitle + ':' + _sum;
            }
        };
        const /** @type {?} */ textElements = svgContainer.append('text')
            .attr('class', _pieInnerTitleClassName)
            .attr('transform', _innerRadiusTitleTranslatePos)
            .text(_makeCenterTitle);
        const /** @type {?} */ _arc = pieElements.append('path')
            .attr('class', _pieClassName)
            .style('fill', (d, i) => {
            return _color(i);
        })
            .attr('fill-opacity', _opacity);
        //  For d3Version4 animation is not available now
        //  if (_animation) {
        //      _arc.transition()
        //      .duration(_animationDuration)
        //      .delay((d,i)=> {
        //          return i *1000;
        //      })
        //      .attrTween('d',(d: any,i: number) =>  {
        //          const _interpolate = d3.interpolateObject(
        //              { startAngle:d.startAngle,endAngle:d.startAngle }
        //              { startAngle:d.startAngle,endAngle:d.endAngle }
        //          )
        //          return (t) {
        //              return arc(_interpolate(t));
        //          }
        //      })
        //  }
        //  else{
        //      _arc.attr('d',arc);
        //  }
        _arc.attr('d', arc$$1);
        pieElements.append('text')
            .attr('class', _pieValueClassName)
            .attr('transform', (d, i) => {
            return 'translate(' + arc$$1.centroid(d) + ')';
        })
            .text((d, i) => {
            if (_valueDisplay && _percentDisplay) {
                const /** @type {?} */ _percentSt = String(Math.ceil(d.value / _sum * 100));
                const /** @type {?} */ _st = String(d.value) + ' (' + _percentSt + '%)';
                return _st;
            }
            if (_percentDisplay) {
                const /** @type {?} */ _percentSt = String(Math.ceil(d.value / _sum * 100));
                const /** @type {?} */ _st = _percentSt + '%';
                return _st;
            }
            if (_valueDisplay) {
                return d.value;
            }
        });
        // ---CALL buildTitle-----------------
        if (_titleDisplay) {
            this.drawTitle(cdt);
        }
        // ------------------------------------
        // ---CALL buildLegend-----------------
        if (_legendDisplay) {
            const /** @type {?} */ _legendDataSet = new Array();
            for (const /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, _color(i)));
                }
            }
            this.buildLegend(cdt, _legendDataSet);
        }
    }
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    buildBar(svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('In  buildBar----------------');
        const /** @type {?} */ _yDataSet = new Array();
        for (const /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                for (const /** @type {?} */ j in dataSetJson.data[i].y) {
                    if (dataSetJson.data[i].y.hasOwnProperty(j)) {
                        const /** @type {?} */ _y = dataSetJson.data[i].y[j];
                        _yDataSet.push(_y);
                    }
                }
            }
        }
        let /** @type {?} */ _maxX = 0;
        let /** @type {?} */ _maxY = 0;
        _maxY = max(_yDataSet);
        _maxX = 100;
        const /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        const /** @type {?} */ _barValueClass = configData.className.barValue;
        const /** @type {?} */ _color = cdt.defaultColorFunc;
        const /** @type {?} */ _seriesNum = dataSetJson.series.length;
        const /** @type {?} */ _columnNum = _yDataSet.length;
        const /** @type {?} */ _initPosY = cdt.graphInitYPos;
        const /** @type {?} */ _graphHeight = cdt.graphHeight;
        const /** @type {?} */ _graphWidth = cdt.graphWidth;
        const /** @type {?} */ _opacity = configData.color.opacity;
        const /** @type {?} */ _titleHeight = configData.title.height;
        const /** @type {?} */ _titleDisplay = configData.title.display;
        const /** @type {?} */ _leftMargin = configData.margin.left;
        const /** @type {?} */ _topMargin = configData.margin.top;
        const /** @type {?} */ _bottomMargin = configData.margin.bottom;
        const /** @type {?} */ _betweenMargin = configData.margin.between;
        const /** @type {?} */ _legendDisplay = configData.legend.display;
        const /** @type {?} */ _labelDisplay = configData.label.display;
        const /** @type {?} */ _gridYDisplay = configData.grid.y.display;
        const /** @type {?} */ _animation = configData.animation.enable;
        const /** @type {?} */ _animationDuration = configData.animation.duration;
        const /** @type {?} */ _barWidth = (_graphWidth - (_betweenMargin * _columnNum / _seriesNum)) / _columnNum;
        const /** @type {?} */ _columnWidth = (_graphWidth / _columnNum);
        const /** @type {?} */ _graphYScale = cdt.graphYScale;
        const /** @type {?} */ yBarScale = scaleLinear()
            .domain([0, _maxY])
            .range([_maxY * _graphYScale, 0]);
        const /** @type {?} */ _barPadding = _betweenMargin;
        const /** @type {?} */ grpGraph = svgContainer.selectAll('g')
            .data(_yDataSet)
            .enter()
            .append('g')
            .attr('transform', (d, i) => {
            const /** @type {?} */ _padding = ((i % _seriesNum) === 0) ? _barPadding : 0;
            return 'translate(' + (_padding + _columnWidth * i) + ')';
        })
            .style('fill', (d, i) => {
            const /** @type {?} */ _remnant = (i % _seriesNum);
            return _color(_remnant);
        })
            .attr('fill-opacity', _opacity);
        const /** @type {?} */ _rect = grpGraph.append('rect');
        if (_animation) {
            _rect.attr('x', _leftMargin)
                .attr('height', 0)
                .attr('y', (d) => {
                return _initPosY;
            })
                .attr('width', _barWidth - _barPadding)
                .transition()
                .duration(_animationDuration)
                .attr('y', (d) => {
                return yBarScale(d) + _initPosY;
            })
                .attr('height', (d) => {
                return _graphHeight - yBarScale(d);
            });
        }
        else {
            _rect.attr('x', _leftMargin)
                .attr('y', (d) => {
                return yBarScale(d) + _initPosY;
            })
                .attr('width', _barWidth - _barPadding)
                .attr('height', (d) => {
                return _graphHeight - yBarScale(d);
            });
        }
        const /** @type {?} */ textBarValue = grpGraph.append('text');
        textBarValue
            .attr('class', _barValueClass)
            .attr('x', _leftMargin)
            .attr('y', (d) => {
            return yBarScale(d) + _initPosY;
        })
            .text((d) => {
            return d;
        });
        // ------------------------------------
        // ---CALL buildAxis-----------------
        this.buildYAxis(cdt);
        //  ------------------------------------
        //  ---CALL drawXAxisLabel-----------------
        if (_labelDisplay) {
            const /** @type {?} */ _labelArray = new Array();
            for (const /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    _labelArray.push(dataSetJson.data[i].x);
                }
            }
            this.drawXAxisLabel(cdt, _labelArray, BAR_CHART_TYPE_NAME);
        }
        this.drawXBaseLine(cdt);
        //  ------------------------------------
        //  ---CALL buildLegend-----------------
        const /** @type {?} */ _legendDataSet = new Array();
        for (const /** @type {?} */ i in dataSetJson.series) {
            if (dataSetJson.series.hasOwnProperty(i)) {
                _legendDataSet.push(new O2LegendData(dataSetJson.series[i], _color(i)));
            }
        }
        this.buildLegend(cdt, _legendDataSet);
        // ------------------------------------
        // ---CALL buildTitle-----------------
        if (_titleDisplay) {
            this.drawTitle(cdt);
        }
        if (_gridYDisplay) {
            this.drawYGrid(cdt);
        }
    }
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    buildLine(svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in buildTest-------------------');
        const /** @type {?} */ _groupMaxY = new Array();
        for (const /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                let /** @type {?} */ _gMaxY = 0;
                for (const /** @type {?} */ j in dataSetJson.data[i].value) {
                    if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                        if (_gMaxY < dataSetJson.data[i].value[j].y) {
                            _gMaxY = dataSetJson.data[i].value[j].y;
                        }
                    }
                }
                _groupMaxY.push(_gMaxY);
            }
        }
        let /** @type {?} */ _maxX = 0;
        let /** @type {?} */ _maxY = 0;
        _maxY = max(_groupMaxY);
        _maxX = 100;
        const /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        const /** @type {?} */ _color = cdt.defaultColorFunc;
        const /** @type {?} */ _columnNum = dataSetJson.data[0].value.length;
        const /** @type {?} */ _columnWidth = cdt.graphWidth / _columnNum;
        console.log(_columnWidth);
        if (configData.grid.y.display) {
            this.drawYGrid(cdt);
        }
        //  O2IdValueData
        for (const /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                const /** @type {?} */ _lineArray = new Array();
                for (const /** @type {?} */ j in dataSetJson.data[i].value) {
                    if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                        const /** @type {?} */ idValue = new O2IdValueData(parseInt(j, 10), dataSetJson.data[i].value[j].y);
                        _lineArray.push(idValue);
                    }
                }
                const /** @type {?} */ num = parseInt(i, 10);
                this.drawSingleLine(cdt, _lineArray, num);
            }
        }
        // ------------------------------------
        // ---CALL buildTitle-----------------
        this.drawTitle(cdt);
        // ------------------------------------
        // ---CALL buildAxis-----------------
        this.buildYAxis(cdt);
        this.drawXBaseLine(cdt);
        //  ------------------------------------
        //  ---CALL drawXAxisLabel-----------------
        const /** @type {?} */ _labelArray = new Array();
        for (const /** @type {?} */ i in dataSetJson.data[0].value) {
            if (dataSetJson.data[0].value.hasOwnProperty(i)) {
                _labelArray.push(dataSetJson.data[0].value[i].x);
            }
        }
        this.drawXAxisLabel(cdt, _labelArray, LINE_CHART_TYPE_NAME);
        //  ------------------------------------
        //  ---CALL buildLegend-----------------
        const /** @type {?} */ _legendDataSet = new Array();
        for (const /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, _color(i)));
            }
        }
        this.buildLegend(cdt, _legendDataSet);
    }
    /**
     * @param {?} o2Common
     * @param {?} dataSet
     * @param {?} lineNum
     * @return {?}
     */
    drawSingleLine(o2Common, dataSet, lineNum) {
        console.log('in drawSingleLine-------------------');
        console.log(dataSet);
        const /** @type {?} */ cdt = o2Common;
        const /** @type {?} */ configData = cdt.configData;
        const /** @type {?} */ svgContainer = cdt.svgContainer;
        const /** @type {?} */ _maxX = cdt.maxXValue;
        const /** @type {?} */ _initXPos = cdt.axisXLabelInitXPos;
        const /** @type {?} */ _initYPos = cdt.axisXLabelInitYPos;
        const /** @type {?} */ _columnNum = dataSet.length;
        const /** @type {?} */ _columnWidth = cdt.graphWidth / (_columnNum - 1);
        const /** @type {?} */ _color = scaleOrdinal(schemeCategory10);
        const /** @type {?} */ _lineClassName = configData.className.multiLinePrefix + String(lineNum);
        const /** @type {?} */ _leftMargin = configData.margin.left;
        const /** @type {?} */ _bottomMargin = configData.margin.bottom;
        const /** @type {?} */ _yScale = cdt.graphYScale;
        const /** @type {?} */ line$$1 = line()
            .curve(curveLinear)
            .x((d) => {
            return _leftMargin + d.id * _columnWidth;
        })
            .y((d) => {
            return cdt.svgHeight - _bottomMargin - (d.value * _yScale);
        });
        svgContainer.append('path')
            .attr('class', _lineClassName)
            .attr('d', line$$1(dataSet));
        //  .attr('transform', cdt.axisTranslatePos)
    }
    /**
     * @param {?} o2Common
     * @param {?} _legendDataSet
     * @return {?}
     */
    buildLegend(o2Common, _legendDataSet) {
        console.log('in buildLegend-------------------');
        //  maxValues are meaningless
        const /** @type {?} */ cdt = o2Common;
        const /** @type {?} */ configData = cdt.configData;
        const /** @type {?} */ svgContainer = cdt.svgContainer;
        //  const cdt = new O2Common(configData, 100, 100, svgWidth, svgHeight);
        const /** @type {?} */ legendRectSize = configData.legend.rectWidth;
        const /** @type {?} */ legendSpacing = 10;
        const /** @type {?} */ ySpacing = configData.legend.ySpacing;
        const /** @type {?} */ initPosX = cdt.legendInitXPos;
        const /** @type {?} */ initPosY = cdt.legendInitYPos;
        const /** @type {?} */ opacity = configData.color.opacity;
        const /** @type {?} */ grpLegend = svgContainer.append('g')
            .selectAll('g')
            .data(_legendDataSet)
            .enter()
            .append('g')
            .attr('class', 'legend')
            .attr('transform', (d, i) => {
            const /** @type {?} */ height = legendRectSize + ySpacing;
            const /** @type {?} */ x = initPosX;
            const /** @type {?} */ y = i * height + initPosY;
            return 'translate(' + x + ', ' + y + ')';
        });
        grpLegend.append('rect')
            .attr('width', legendRectSize)
            .attr('height', legendRectSize)
            .style('fill', (d) => {
            return d.color;
        })
            .style('stroke', (d) => {
            return d.color;
        })
            .attr('fill-opacity', opacity);
        grpLegend.append('text')
            .attr('x', legendRectSize + legendSpacing)
            .attr('y', legendRectSize)
            .text((d) => {
            return d.title;
        });
    }
    /**
     * @param {?} o2Common
     * @param {?} labelDataSet
     * @param {?} chartType
     * @return {?}
     */
    drawXAxisLabel(o2Common, labelDataSet, chartType) {
        console.log('in drawXAxisLabel-------------------');
        const /** @type {?} */ cdt = o2Common;
        const /** @type {?} */ configData = cdt.configData;
        const /** @type {?} */ svgContainer = cdt.svgContainer;
        // const _maxX = cdt.maxXValue;
        const /** @type {?} */ _initXPos = cdt.axisXLabelInitXPos;
        const /** @type {?} */ _initYPos = cdt.axisXLabelInitYPos;
        const /** @type {?} */ _columnNum = labelDataSet.length;
        let /** @type {?} */ _columnWidth = cdt.graphWidth / _columnNum;
        if (chartType === LINE_CHART_TYPE_NAME) {
            _columnWidth = cdt.graphWidth / (_columnNum - 1);
        }
        const /** @type {?} */ grpLabel = svgContainer.append('g')
            .selectAll('g')
            .data(labelDataSet)
            .enter()
            .append('g')
            .attr('class', configData.axisXText)
            .attr('transform', (d, i) => {
            const /** @type {?} */ _x = _initXPos + _columnWidth * i;
            const /** @type {?} */ _y = _initYPos;
            return 'translate(' + _x + ', ' + _y + ')';
        });
        grpLabel.append('text')
            .attr('class', configData.className.axisXText)
            .text((d, i) => {
            return d;
        });
    }
    /**
     * @param {?} o2Common
     * @return {?}
     */
    drawXBaseLine(o2Common) {
        console.log('in drawXBaseLine-------------------');
        const /** @type {?} */ cdt = o2Common;
        const /** @type {?} */ svgContainer = cdt.svgContainer;
        svgContainer.append('rect')
            .attr('class', cdt.axisXBorderLineClassName)
            .attr('width', cdt.axisXBorderWidth)
            .attr('height', cdt.axisXBorderLineWidth)
            .attr('transform', cdt.axisXBorderTranslatePos);
    }
    /**
     * @param {?} o2Common
     * @return {?}
     */
    buildYAxis(o2Common) {
        console.log('in buildYAxis-------------------');
        const /** @type {?} */ cdt = o2Common;
        const /** @type {?} */ svgContainer = cdt.svgContainer;
        const /** @type {?} */ _maxY = cdt.maxYValue;
        const /** @type {?} */ _graphYScale = cdt.graphYScale;
        const /** @type {?} */ _axisYScale = scaleLinear()
            .domain([0, _maxY])
            .range([_maxY * _graphYScale, 0]);
        svgContainer.append('g')
            .attr('class', cdt.axisClassName)
            .attr('transform', cdt.axisTranslatePos)
            .call(axisLeft(_axisYScale));
    }
    /**
     * @param {?} o2Common
     * @return {?}
     */
    drawTitle(o2Common) {
        console.log('in drawTitle-------------------');
        const /** @type {?} */ cdt = o2Common;
        const /** @type {?} */ configData = cdt.configData;
        const /** @type {?} */ svgContainer = cdt.svgContainer;
        const /** @type {?} */ _title = configData.title.name;
        const /** @type {?} */ _xPos = cdt.titleInitXPos;
        const /** @type {?} */ _yPos = cdt.titleInitYPos;
        const /** @type {?} */ _titleClassName = configData.title.className;
        svgContainer.append('text')
            .attr('class', _titleClassName)
            .attr('x', _xPos)
            .attr('y', _yPos)
            .text(_title);
    }
    /**
     * @param {?} o2Common
     * @return {?}
     */
    drawYGrid(o2Common) {
        console.log('in buildYGrid-------------------');
        const /** @type {?} */ cdt = o2Common;
        const /** @type {?} */ configData = cdt.configData;
        const /** @type {?} */ svgContainer = cdt.svgContainer;
        const /** @type {?} */ _stepY = cdt.gridYStep;
        const /** @type {?} */ _maxY = cdt.maxYValue;
        const /** @type {?} */ _graphYScale = cdt.graphYScale;
        const /** @type {?} */ _gridClassName = configData.className.grid;
        const /** @type {?} */ _rangeY = range(_stepY * _graphYScale, _maxY * _graphYScale, _stepY * _graphYScale);
        svgContainer.append('g')
            .selectAll('line.y')
            .data(_rangeY)
            .enter()
            .append('line')
            .attr('class', _gridClassName)
            .attr('x1', configData.margin.left)
            .attr('y1', (d, i) => {
            const /** @type {?} */ _y1 = cdt.svgHeight - configData.margin.bottom - d;
            return _y1;
        })
            .attr('x2', configData.margin.left + cdt.axisXBorderWidth)
            .attr('y2', (d, i) => {
            const /** @type {?} */ _y1 = cdt.svgHeight - configData.margin.bottom - d;
            return _y1;
        });
    }
}
Ng6O2ChartComponent.decorators = [
    { type: Component, args: [{
                selector: 'lib-Ng6O2Chart',
                template: ``,
                styles: []
            },] },
];
/** @nocollapse */
Ng6O2ChartComponent.ctorParameters = () => [
    { type: ElementRef }
];
Ng6O2ChartComponent.propDecorators = {
    chartType: [{ type: Input }],
    svgWidth: [{ type: Input }],
    svgHeight: [{ type: Input }],
    graphData: [{ type: Input }],
    configData: [{ type: Input }]
};

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
class Ng6O2ChartModule {
}
Ng6O2ChartModule.decorators = [
    { type: NgModule, args: [{
                imports: [],
                declarations: [Ng6O2ChartComponent],
                exports: [Ng6O2ChartComponent]
            },] },
];

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

export { LINE_CHART_TYPE_NAME, BAR_CHART_TYPE_NAME, PIE_CHART_TYPE_NAME, SCATTER_PLOT_CHART_TYPE_NAME, HISTOGRAM_CHART_TYPE_NAME, STACK_BAR_CHART_TYPE_NAME, GEO_MAP_CHART_TYPE_NAME, GEO_ORTHOGRAPHIC_CHART_TYPE_NAME, TREE_MAP_CHART_TYPE_NAME, PACK_LAYOUT_CHART_TYPE_NAME, CHOROPLETH_CHART_TYPE_NAME, TREE_CHART_TYPE_NAME, SANKEY_CHART_TYPE_NAME, FORCE_CHART_TYPE_NAME, Ng6O2ChartComponent, Ng6O2ChartModule };

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmc2LW8yLWNoYXJ0LmpzLm1hcCIsInNvdXJjZXMiOlsibmc6Ly9uZzYtbzItY2hhcnQvbGliL3NoYXJlZC9jaGFydC1jb25zdC50cyIsIm5nOi8vbmc2LW8yLWNoYXJ0L2xpYi9zaGFyZWQvbzJjb21tb24udHMiLCJuZzovL25nNi1vMi1jaGFydC9saWIvbmc2LW8yLWNoYXJ0LmNvbXBvbmVudC50cyIsIm5nOi8vbmc2LW8yLWNoYXJ0L2xpYi9uZzYtbzItY2hhcnQubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBMSU5FX0NIQVJUX1RZUEVfTkFNRSAgPSAnbGluZSc7XHJcbmV4cG9ydCBjb25zdCBCQVJfQ0hBUlRfVFlQRV9OQU1FID0gJ2Jhcic7XHJcbmV4cG9ydCBjb25zdCBQSUVfQ0hBUlRfVFlQRV9OQU1FID0gJ3BpZSc7XHJcbmV4cG9ydCBjb25zdCBTQ0FUVEVSX1BMT1RfQ0hBUlRfVFlQRV9OQU1FID0gJ3NjYXR0ZXJQbG90JztcclxuZXhwb3J0IGNvbnN0IEhJU1RPR1JBTV9DSEFSVF9UWVBFX05BTUUgPSAnaGlzdG9ncmFtJztcclxuZXhwb3J0IGNvbnN0IFNUQUNLX0JBUl9DSEFSVF9UWVBFX05BTUUgPSAnc3RhY2tCYXInO1xyXG5leHBvcnQgY29uc3QgR0VPX01BUF9DSEFSVF9UWVBFX05BTUUgPSAnZ2VvTWFwJztcclxuZXhwb3J0IGNvbnN0IEdFT19PUlRIT0dSQVBISUNfQ0hBUlRfVFlQRV9OQU1FID0gJ2dlb09ydGhvZ3JhcGhpYyc7XHJcbmV4cG9ydCBjb25zdCBUUkVFX01BUF9DSEFSVF9UWVBFX05BTUUgPSAndHJlZU1hcCc7XHJcbmV4cG9ydCBjb25zdCBQQUNLX0xBWU9VVF9DSEFSVF9UWVBFX05BTUUgPSAncGFja0xheW91dCc7XHJcbmV4cG9ydCBjb25zdCBDSE9ST1BMRVRIX0NIQVJUX1RZUEVfTkFNRSA9ICdjaG9yb3BsZXRoJztcclxuZXhwb3J0IGNvbnN0IFRSRUVfQ0hBUlRfVFlQRV9OQU1FID0gJ3RyZWUnO1xyXG5leHBvcnQgY29uc3QgU0FOS0VZX0NIQVJUX1RZUEVfTkFNRSA9ICdzYW5rZXknO1xyXG5leHBvcnQgY29uc3QgRk9SQ0VfQ0hBUlRfVFlQRV9OQU1FID0gJ2ZvcmNlJyA7XHJcbiIsImltcG9ydCAqIGFzIGQzIGZyb20gJ2QzJztcclxuXHJcblxyXG5cclxuZXhwb3J0IGNsYXNzIE8yQ29tbW9uIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwdWJsaWMgc3ZnQ29udGFpbmVyOiBhbnksXHJcbiAgICAgICAgcHVibGljIGNvbmZpZ0RhdGE6IGFueSxcclxuICAgICAgICBwdWJsaWMgYXV0b01heFg6IG51bWJlcixcclxuICAgICAgICBwdWJsaWMgYXV0b01heFk6IG51bWJlcixcclxuICAgICAgICBwdWJsaWMgc3ZnV2lkdGg6IG51bWJlcixcclxuICAgICAgICBwdWJsaWMgc3ZnSGVpZ2h0OiBudW1iZXJcclxuICAgICkgeyB9XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0gIENMQVNTIE5BTUUgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5wdWJsaWMgZ2V0IGF4aXNDbGFzc05hbWUoKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ0RhdGEuY2xhc3NOYW1lLmF4aXM7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgbGluZUNsYXNzTmFtZSgpOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuIHRoaXMuY29uZmlnRGF0YS5jbGFzc05hbWUubGluZTtcclxufVxyXG5cclxucHVibGljIGdldCBheGlzWEJvcmRlckxpbmVDbGFzc05hbWUoKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ0RhdGEuY2xhc3NOYW1lLmF4aXNYQm9yZGVyO1xyXG59XHJcblxyXG5cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLSAgTUFYIFZBTFVFICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbnB1YmxpYyBnZXQgbWF4WFZhbHVlKCk6IG51bWJlciB7XHJcbiAgICBsZXQgX21heFggPSB0aGlzLmF1dG9NYXhYO1xyXG4gICAgaWYgKCF0aGlzLmNvbmZpZ0RhdGEubWF4VmFsdWUuYXV0bykge1xyXG4gICAgICAgIF9tYXhYID0gdGhpcy5jb25maWdEYXRhLm1heFZhbHVlLng7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gX21heFg7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgbWF4WVZhbHVlKCk6IG51bWJlciB7XHJcbiAgICBsZXQgX21heFkgPSB0aGlzLmF1dG9NYXhZO1xyXG4gICAgaWYgKCF0aGlzLmNvbmZpZ0RhdGEubWF4VmFsdWUuYXV0bykge1xyXG4gICAgICAgIF9tYXhZID0gdGhpcy5jb25maWdEYXRhLm1heFZhbHVlLnk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gX21heFk7XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLSAgR1JBUEggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbnB1YmxpYyBnZXQgZ3JhcGhJbml0WFBvcygpOiBudW1iZXIge1xyXG4gICAgbGV0IF9pbnRYID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0O1xyXG4gICAgaWYgKHRoaXMuY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheSAmJiB0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLnBvc2l0aW9uICE9PSAncmlnaHQnKSB7XHJcbiAgICAgICAgX2ludFggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS5sZWdlbmQudG90YWxXaWR0aDtcclxuICAgIH1cclxuICAgIHJldHVybiBfaW50WDtcclxufVxyXG5cclxucHVibGljIGdldCBncmFwaEluaXRZUG9zKCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfaW50WSA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4udG9wXHJcbiAgICAgICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHQ7XHJcbiAgICByZXR1cm4gX2ludFk7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JhcGhZU2NhbGUoKTogbnVtYmVyIHtcclxuICAgIHJldHVybiB0aGlzLmdyYXBoSGVpZ2h0IC8gdGhpcy5tYXhZVmFsdWU7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JhcGhYU2NhbGUoKTogbnVtYmVyIHtcclxuICAgIHJldHVybiB0aGlzLmdyYXBoV2lkdGggLyB0aGlzLm1heFhWYWx1ZTtcclxufVxyXG5cclxucHVibGljIGdldCBncmFwaFdpZHRoKCk6IG51bWJlciB7XHJcbiAgICBsZXQgX21hcmdpbiA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLm1hcmdpbi5yaWdodDtcclxuICAgIGlmICh0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXkpIHtcclxuICAgICAgICBfbWFyZ2luICs9IHRoaXMuY29uZmlnRGF0YS5sZWdlbmQudG90YWxXaWR0aDtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gdGhpcy5zdmdXaWR0aCAtIF9tYXJnaW47XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JhcGhIZWlnaHQoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF9oID0gdGhpcy5zdmdIZWlnaHRcclxuICAgICAgICAgICAgICAgIC0gdGhpcy5jb25maWdEYXRhLnRpdGxlLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgLSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICAgICAgLSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbTtcclxuICAgIHJldHVybiBfaDtcclxufVxyXG5cclxucHVibGljIGdldCBncmFwaENlbnRlclBvcygpOiBhbnkge1xyXG4gICAgY29uc3QgX3h5QXJyYXk6IEFycmF5PG51bWJlcj4gPSBuZXcgQXJyYXkoKTtcclxuICAgIGNvbnN0IF94ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICAgICArIHRoaXMuZ3JhcGhXaWR0aCAvIDI7XHJcbiAgICBjb25zdCBfeSA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4udG9wXHJcbiAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLnRpdGxlLmhlaWdodFxyXG4gICAgICAgICAgICArIHRoaXMuZ3JhcGhIZWlnaHQgLyAyO1xyXG4gICAgX3h5QXJyYXkucHVzaChfeCk7XHJcbiAgICBfeHlBcnJheS5wdXNoKF95KTtcclxuICAgIHJldHVybiBfeHlBcnJheTtcclxufVxyXG5cclxucHVibGljIGdldCBncmFwaENlbnRlclRyYW5zbGF0ZVBvcygpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgX3ggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgKyB0aGlzLmdyYXBoV2lkdGggLyAyO1xyXG4gICAgY29uc3QgX3kgPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHRcclxuICAgICAgICAgICAgKyB0aGlzLmdyYXBoSGVpZ2h0IC8gMjtcclxuICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyBTdHJpbmcoX3gpICsgJywgJyArIFN0cmluZyhfeSkgKyAnKSc7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JhcGhJbml0VHJhbnNsYXRlUG9zKCk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBfeCA9IHRoaXMuZ3JhcGhJbml0WFBvcztcclxuICAgIGNvbnN0IF95ID0gdGhpcy5ncmFwaEluaXRZUG9zO1xyXG4gICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIFN0cmluZyhfeCkgKyAnLCAnICsgU3RyaW5nKF95KSArICcpJztcclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tICBBWElTICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxucHVibGljIGdldCBheGlzWExhYmVsSW5pdFhQb3MoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF94ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLmF4aXMueExhYmVsLmxlZnRNYXJnaW47XHJcbiAgICByZXR1cm4gX3g7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgYXhpc1hMYWJlbEluaXRZUG9zKCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfeSA9IHRoaXMuc3ZnSGVpZ2h0XHJcbiAgICAgICAgICAgIC0gdGhpcy5jb25maWdEYXRhLmF4aXMueExhYmVsLmJvdHRvbU1hcmdpbjtcclxuICAgIHJldHVybiBfeTtcclxufVxyXG5cclxucHVibGljIGdldCBheGlzVHJhbnNsYXRlUG9zKCk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBfeCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdDtcclxuICAgIGNvbnN0IF95ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi50b3BcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0O1xyXG4gICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIFN0cmluZyhfeCkgKyAnLCAnICsgU3RyaW5nKF95KSArICcpJztcclxufVxyXG5cclxuXHJcbnB1YmxpYyBnZXQgYXhpc1hCb3JkZXJMaW5lV2lkdGgoKTogbnVtYmVyIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ0RhdGEuYXhpcy5ib3JkZXJMaW5lV2lkdGg7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgYXhpc1lCb3JkZXJIZWlnaHQoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF9tYXJnaW4gPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLm1hcmdpbi5ib3R0b21cclxuICAgICAgICAgICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHQ7XHJcbiAgICByZXR1cm4gdGhpcy5zdmdIZWlnaHQgLSBfbWFyZ2luO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGF4aXNYQm9yZGVyV2lkdGgoKTogbnVtYmVyIHtcclxuICAgIGxldCBfbWFyZ2luID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnJpZ2h0O1xyXG4gICAgaWYgKHRoaXMuY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheSkge1xyXG4gICAgICAgIF9tYXJnaW4gKz0gdGhpcy5jb25maWdEYXRhLmxlZ2VuZC50b3RhbFdpZHRoO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMuc3ZnV2lkdGggLSBfbWFyZ2luO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGF4aXNZT3JpZW50KCk6IHN0cmluZyB7XHJcbiAgICByZXR1cm4gJ2xlZnQnO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGF4aXNYT3JpZW50KCk6IHN0cmluZyB7XHJcbiAgICByZXR1cm4gJ2JvdHRvbSc7XHJcbn1cclxucHVibGljIGdldCBheGlzWEJvcmRlclRyYW5zbGF0ZVBvcygpOiBzdHJpbmcge1xyXG4gICAgY29uc3Qgc1lwb3MgPSBTdHJpbmcodGhpcy5zdmdIZWlnaHQgLSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbSk7XHJcbiAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0ICsgJywgJyArIHNZcG9zICsgJyknO1xyXG59XHJcblxyXG5cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLSAgUkFESVVTICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxucHVibGljIGdldCBpbm5lclJhZGl1c1BlcmNlbnQoKTogbnVtYmVyIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ0RhdGEucGllLmlubmVyUmFkaXVzLnBlcmNlbnQ7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgaW5uZXJSYWRpdXNUaXRsZSgpOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuIHRoaXMuY29uZmlnRGF0YS5waWUuaW5uZXJSYWRpdXMudGl0bGU7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgaW5uZXJSYWRpdXNUaXRsZVRyYW5zbGF0ZVBvcygpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgX3ggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgICAgICsgdGhpcy5ncmFwaFdpZHRoIC8gMjtcclxuICAgIGNvbnN0IF95ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi50b3BcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0XHJcbiAgICAgICAgICAgICsgdGhpcy5ncmFwaEhlaWdodCAvIDJcclxuICAgICAgICAgICAgKyA1O1xyXG4gICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIFN0cmluZyhfeCkgKyAnLCAnICsgU3RyaW5nKF95KSArICcpJztcclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tICBMRUdFTkQgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5wdWJsaWMgZ2V0IGxlZ2VuZEluaXRYUG9zKCk6IG51bWJlciB7XHJcbiAgICBsZXQgX3ggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgICAgICsgdGhpcy5ncmFwaFdpZHRoXHJcbiAgICAgICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS5sZWdlbmQuaW5pdFhQb3MgO1xyXG4gICAgaWYgKHRoaXMuY29uZmlnRGF0YS5sZWdlbmQucG9zaXRpb24gIT09ICdyaWdodCcpIHtcclxuICAgICAgICBfeCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLmluaXRYUG9zIDtcclxuICAgIH1cclxuICAgIHJldHVybiBfeDtcclxufVxyXG5cclxucHVibGljIGdldCBsZWdlbmRJbml0WVBvcygpOiBudW1iZXIge1xyXG4gICAgY29uc3QgX3kgPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHRcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLmluaXRZUG9zO1xyXG4gICAgcmV0dXJuIF95O1xyXG59XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0gIEdSSUQgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5wdWJsaWMgZ2V0IGdyaWRZU3RlcCgpOiBudW1iZXIge1xyXG4gICAgY29uc3QgX21heFkgPSBNYXRoLmNlaWwodGhpcy5tYXhZVmFsdWUgLyAxMDApICogMTA7XHJcbiAgICBjb25zdCBfbGluZU51bSA9IDEwO1xyXG4gICAgY29uc3QgX3N0ZXAgPSBNYXRoLmNlaWwoX21heFkgLyBfbGluZU51bSkgKiBfbGluZU51bTtcclxuICAgIHJldHVybiBfc3RlcDtcclxufVxyXG5cclxucHVibGljIGdldCBncmlkWFN0ZXAoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF9tYXhYID0gTWF0aC5jZWlsKHRoaXMubWF4WFZhbHVlIC8gMTAwKSAqIDEwO1xyXG4gICAgY29uc3QgX2xpbmVOdW0gPSAxMDtcclxuICAgIGNvbnN0IF9zdGVwID0gTWF0aC5jZWlsKF9tYXhYIC8gX2xpbmVOdW0pICogX2xpbmVOdW07XHJcbiAgICByZXR1cm4gX3N0ZXA7XHJcbn1cclxuXHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0gIFRJVExFICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxucHVibGljIGdldCB0aXRsZUluaXRYUG9zKCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfeCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICArICh0aGlzLmdyYXBoV2lkdGggKyB0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLnRvdGFsV2lkdGgpIC8gMlxyXG4gICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5sZWZ0TWFyZ2luO1xyXG4gICAgcmV0dXJuIF94O1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IHRpdGxlSW5pdFlQb3MoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF95ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi50b3BcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0XHJcbiAgICAgICAgICAgIC0gdGhpcy5jb25maWdEYXRhLnRpdGxlLmJvdHRvbU1hcmdpbjtcclxuICAgIHJldHVybiBfeTtcclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tICBDT0xPUiAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbnB1YmxpYyBnZXQgZGVmYXVsdENvbG9yRnVuYygpOiBhbnkge1xyXG4gICAgbGV0IF9jb2xvcjogYW55O1xyXG4gICAgaWYgKHRoaXMuY29uZmlnRGF0YS5jb2xvci5hdXRvICkge1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZ0RhdGEuY29sb3IuZGVmYXVsdENvbG9yTnVtYmVyID09PSAnMjAnKSB7XHJcbiAgICAgICAgICAgIF9jb2xvciA9IGQzLnNjYWxlT3JkaW5hbChkMy5zY2hlbWVDYXRlZ29yeTIwKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBfY29sb3IgPSBkMy5zY2FsZU9yZGluYWwoZDMuc2NoZW1lQ2F0ZWdvcnkxMCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIF9jb2xvcjtcclxufVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTzJMaW5lRGF0YSB7XHJcbmNvbnN0cnVjdG9yKFxyXG4gICAgcHVibGljIGRhdGE6IEFycmF5PG51bWJlcj4sXHJcbiAgICBwdWJsaWMgY29sb3I6IHN0cmluZyxcclxuICAgIHB1YmxpYyBkYXNoZWRBcnJheTogc3RyaW5nLFxyXG4gICAgcHVibGljIGludGVycG9sYXRlOiBzdHJpbmdcclxuICAgICkgeyB9XHJcbn1cclxuXHJcblxyXG5leHBvcnQgY2xhc3MgTzJMZWdlbmREYXRhIHtcclxuY29uc3RydWN0b3IoXHJcbiAgIHB1YmxpYyB0aXRsZTogc3RyaW5nLFxyXG4gICAgcHVibGljIGNvbG9yOiBzdHJpbmcgKSB7IH1cclxuXHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBPMlNjYXR0ZXJQbG90RGF0YSB7XHJcbmNvbnN0cnVjdG9yKFxyXG4gICBwdWJsaWMgeDogbnVtYmVyLFxyXG4gICBwdWJsaWMgeTogbnVtYmVyLFxyXG4gICBwdWJsaWMgcjogbnVtYmVyICkgeyB9XHJcblxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTzJTdGFja0JhckRhdGEge1xyXG5jb25zdHJ1Y3RvcihcclxuICAgcHVibGljIHg6IHN0cmluZyxcclxuICAgcHVibGljIHk6IG51bWJlclxyXG4gICApIHsgfVxyXG5cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE8ySWRWYWx1ZURhdGEge1xyXG5jb25zdHJ1Y3RvcihcclxuICAgcHVibGljIGlkOiBudW1iZXIsXHJcbiAgICBwdWJsaWMgdmFsdWU6IG51bWJlclxyXG4gICApIHsgfVxyXG5cclxufVxyXG5cclxuLy8gZXhwb3J0IGNsYXNzIE8yS2V5VmFsdWVEYXRhIHtcclxuLy8gICAgIGNvbnN0cnVjdG9yKFxyXG4vLyAgICAgICAgcHVibGljIGtleTogc3RyaW5nLFxyXG4vLyBcdCAgIHB1YmxpYyB2YWx1ZTogbnVtYmVyXHJcbi8vICAgICAgICApIHsgfVxyXG4vLyB9XHJcbi8vIGV4cG9ydCBjbGFzcyBPMkRhdGVLVkFycmF5RGF0YSB7XHJcbi8vICAgICBjb25zdHJ1Y3RvcihcclxuLy8gICAgICAgIHB1YmxpYyBkYXRlOiBEYXRlLFxyXG4vLyBcdCAgIHB1YmxpYyBrdkFycmF5OiBBcnJheTxPMktleVZhbHVlRGF0YT5cclxuLy8gICAgICAgICkgeyB9XHJcbi8vIH1cclxuLy8gZXhwb3J0IGNsYXNzIE8yRGF0ZVN0S1ZBcnJheURhdGEge1xyXG4vLyAgICAgY29uc3RydWN0b3IoXHJcbi8vICAgICAgICBwdWJsaWMgZGF0ZVN0OiBzdHJpbmcsXHJcbi8vIFx0ICAgcHVibGljIGt2QXJyYXk6IEFycmF5PE8yS2V5VmFsdWVEYXRhPlxyXG4vLyAgICAgICAgKSB7IH1cclxuLy8gfSIsImltcG9ydCB7Q29tcG9uZW50LCBEaXJlY3RpdmUsIElucHV0LCBPbkluaXQsIEluamVjdCwgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtPdXRwdXQsIE9uQ2hhbmdlcywgU2ltcGxlQ2hhbmdlfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7TzJDb21tb24sIE8yTGVnZW5kRGF0YSwgTzJTY2F0dGVyUGxvdERhdGEsIE8yU3RhY2tCYXJEYXRhLCBPMkxpbmVEYXRhLCBPMklkVmFsdWVEYXRhfSBmcm9tICcuL3NoYXJlZC9vMmNvbW1vbic7XG5cbmltcG9ydCAqIGFzIENoYXJ0Q29uc3QgZnJvbSAnLi9zaGFyZWQvY2hhcnQtY29uc3QnO1xuaW1wb3J0ICogYXMgZDMgZnJvbSAnZDMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdsaWItTmc2TzJDaGFydCcsXG4gIHRlbXBsYXRlOiBgYCxcbiAgc3R5bGVzOiBbXVxufSlcbmV4cG9ydCBjbGFzcyBOZzZPMkNoYXJ0Q29tcG9uZW50IGltcGxlbWVudHMgIE9uSW5pdCAsIE9uQ2hhbmdlcyB7XG4gIEBJbnB1dCgpIGNoYXJ0VHlwZTogc3RyaW5nO1xuICBASW5wdXQoKSBzdmdXaWR0aDogc3RyaW5nO1xuICBASW5wdXQoKSBzdmdIZWlnaHQ6IHN0cmluZztcbiAgQElucHV0KCkgZ3JhcGhEYXRhOiBBcnJheTxudW1iZXI+O1xuICBASW5wdXQoKSBjb25maWdEYXRhOiBhbnk7XG4gIHJvb3Q6IGFueTtcblxuICBjb25zdHJ1Y3RvciggZWxlbWVudFJlZjogRWxlbWVudFJlZiApIHtcbiAgICBjb25zb2xlLmxvZygnZWw6SFRNTEVsZW1lbnQtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG4gICAgY29uc3QgZWw6IEhUTUxFbGVtZW50ICAgID0gZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50O1xuICAgIHRoaXMucm9vdCA9IGQzLnNlbGVjdChlbCk7XG59XG5cbm5nT25Jbml0KCkge1xufVxuXG5uZ09uQ2hhbmdlcyhjaGFuZ2VzOiB7W3Byb3BlcnR5TmFtZTogc3RyaW5nXTogU2ltcGxlQ2hhbmdlfSkge1xuICBjb25zdCBzdmdXaWR0aCA9IHBhcnNlSW50KHRoaXMuc3ZnV2lkdGgsIDEwKTtcbiAgY29uc3Qgc3ZnSGVpZ2h0ID0gcGFyc2VJbnQodGhpcy5zdmdIZWlnaHQsIDEwKTtcbiAgY29uc3QgZGF0YVNldCA9IHRoaXMuZ3JhcGhEYXRhO1xuICBjb25zdCBjb25maWdEYXRhID0gdGhpcy5jb25maWdEYXRhO1xuICBjb25zdCBjaGFydFR5cGUgPSB0aGlzLmNoYXJ0VHlwZTtcbiAgY29uc3Qgc3ZnQ29udGFpbmVyID0gdGhpcy5yb290LmFwcGVuZCgnc3ZnJylcbiAgICAgICAgICAgIC5hdHRyKCd3aWR0aCcsIHN2Z1dpZHRoKVxuICAgICAgICAgICAgLmF0dHIoJ2hlaWdodCcsIHN2Z0hlaWdodCk7XG5cbiAgY29uc29sZS5sb2coY2hhcnRUeXBlKTtcbiAgc3dpdGNoIChjaGFydFR5cGUpIHtcbiAgICBjYXNlIENoYXJ0Q29uc3QuTElORV9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkTGluZShzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LkJBUl9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkQmFyKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LlBJRV9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkUGllKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LlNDQVRURVJfUExPVF9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkU2NhdHRlclBsb3Qoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuSElTVE9HUkFNX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRIaXN0b2dyYW0oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuU1RBQ0tfQkFSX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRTdGFja0JhcihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5HRU9fTUFQX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRHZW9NYXAoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuR0VPX09SVEhPR1JBUEhJQ19DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkR2VvT3J0aG9ncmFwaGljKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LlRSRUVfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZFRyZWUoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuUEFDS19MQVlPVVRfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZFBhY2tMYXlvdXQoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuQ0hPUk9QTEVUSF9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkQ2hvcm9wbGV0aChzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5GT1JDRV9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkRm9yY2Uoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuVFJFRV9NQVBfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgLy8gIHRoaXMuYnVpbGRUcmVlTWFwKHN2Z0NvbnRhaW5lcixjb25maWdEYXRhLCBkYXRhU2V0LHN2Z1dpZHRoLHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LlNBTktFWV9DSEFSVF9UWVBFX05BTUU6XG4gICAgICAvLyAgdGhpcy5idWlsZFNhbmtleShzdmdDb250YWluZXIsY29uZmlnRGF0YSwgZGF0YVNldCxzdmdXaWR0aCxzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGRlZmF1bHQ6XG4gICAgICBicmVhaztcbiAgfVxufVxuXG5cblxucHJpdmF0ZSBidWlsZEhpc3RvZ3JhbShzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZEhpc3RvZ3JhbS0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBkYXRhU2V0ID0gZGF0YVNldEpzb24uZGF0YTtcbiAgY29uc3QgX2Jpbk51bWJlciA9IGRhdGFTZXRKc29uLmJpbnMubGVuZ3RoIC0gMTtcblxuICBjb25zdCBfbWF4WSA9IDMwMDsgLy8gZHVtbXkgbnVtYmVyXG4gIGNvbnN0IF9tYXhYID0gZGF0YVNldEpzb24ucmFuZ2VbMV07XG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG4gIGNvbnN0IF9ncmFwaFdpZHRoID0gY2R0LmdyYXBoV2lkdGg7XG4gIGNvbnN0IF9ncmFwaEhlaWdodCA9IGNkdC5ncmFwaEhlaWdodDtcbiAgY29uc3QgX21heFlWYWx1ZSA9IGNkdC5tYXhZVmFsdWU7XG4gIGNvbnN0IF9ncmFwaFhTY2FsZSA9IGNkdC5ncmFwaFhTY2FsZTtcbiAgY29uc3QgX2dyYXBoSW5pdFggPSBjZHQuZ3JhcGhJbml0WFBvcztcbiAgY29uc3QgX2dyYXBoSW5pdFkgPSBjZHQuZ3JhcGhJbml0WVBvcztcblxuICBjb25zdCBfdGl0bGVEaXNwbGF5ID0gY29uZmlnRGF0YS50aXRsZS5kaXNwbGF5O1xuICBjb25zdCBfYW5pbWF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZW5hYmxlO1xuICBjb25zdCBfYW5pbWF0aW9uRHVyYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5kdXJhdGlvbjtcbiAgY29uc3QgX2dyaWRZRGlzcGxheSA9IGNvbmZpZ0RhdGEuZ3JpZC55LmRpc3BsYXk7XG4gIGNvbnN0IF9tYXJnaW5MZWZ0ID0gY29uZmlnRGF0YS5tYXJnaW4ubGVmdDtcbiAgY29uc3QgX21hcmdpblRvcCA9IGNvbmZpZ0RhdGEubWFyZ2luLnRvcDtcbiAgY29uc3QgX2NsYXNzTmFtZSA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLmhpc3RvZ3JhbUJhcjtcblxuXG4gIGNvbnN0IF9kYXRhU2V0OiBBcnJheTxudW1iZXI+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0KSB7XG4gICAgICBpZiAoZGF0YVNldC5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGNvbnN0IF9udW0gPSBkYXRhU2V0W2ldIC8gX21heFg7XG4gICAgICAgICAgX2RhdGFTZXQucHVzaChfbnVtKTtcbiAgICAgIH1cbiAgfVxuXG4gIGNvbnN0IGZvcm1hdENvdW50ID0gZDMuZm9ybWF0KCcsLjBmJyk7XG5cbiAgY29uc3QgX2hpc3RncmFtQ29udGFpbmVyID0gc3ZnQ29udGFpbmVyXG4gICAgICAgICAgICAgICAgICAuYXBwZW5kKCdnJylcbiAgICAgICAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAndHJhbnNsYXRlKCcgKyBfZ3JhcGhJbml0WCArICcsJyArIF9ncmFwaEluaXRZICsgJyknKTtcblxuICBjb25zdCBfeFNjYWxlID0gZDMuc2NhbGVMaW5lYXIoKVxuICAgICAgLnJhbmdlUm91bmQoWzAsIF9ncmFwaFdpZHRoXSk7XG5cbiAgY29uc3QgYmlucyA9IGQzLmhpc3RvZ3JhbSgpXG4gICAgICAuZG9tYWluKFswLCAxXSlcbiAgICAgIC50aHJlc2hvbGRzKF94U2NhbGUudGlja3MoX2Jpbk51bWJlcikpXG4gICAgICAoX2RhdGFTZXQpO1xuXG5cbiAgY29uc3QgX3lTY2FsZSA9IGQzLnNjYWxlTGluZWFyKClcbiAgICAgIC5kb21haW4oWzAsIGQzLm1heChiaW5zLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGQubGVuZ3RoO1xuICAgICAgfSldKVxuICAgICAgLnJhbmdlKFtfZ3JhcGhIZWlnaHQsIDBdKTtcblxuICBjb25zdCBiYXIgPSBfaGlzdGdyYW1Db250YWluZXJcbiAgICAgIC5zZWxlY3RBbGwoJy5iYXInKVxuICAgICAgLmRhdGEoYmlucylcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCdjbGFzcycsIF9jbGFzc05hbWUpXG4gICAgICAuYXR0cigndHJhbnNmb3JtJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyBfeFNjYWxlKGQueDApICsgJywnICsgX3lTY2FsZShkLmxlbmd0aCkgKyAnKSc7XG4gICAgICB9KTtcblxuICBpZiAoX2FuaW1hdGlvbikge1xuICAgICAgYmFyLmFwcGVuZCgncmVjdCcpXG4gICAgICAgICAgLmF0dHIoJ3gnLCAgMSlcbiAgICAgICAgICAuYXR0cignd2lkdGgnLCBfeFNjYWxlKGJpbnNbMF0ueDEpIC0gX3hTY2FsZShiaW5zWzBdLngwKSAtIDEpXG4gICAgICAgICAgLmF0dHIoJ2hlaWdodCcsIDApXG4gICAgICAgICAgLnRyYW5zaXRpb24oKVxuICAgICAgICAgIC5kdXJhdGlvbihfYW5pbWF0aW9uRHVyYXRpb24pXG4gICAgICAgICAgLmF0dHIoJ2hlaWdodCcsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIF9ncmFwaEhlaWdodCAtIF95U2NhbGUoZC5sZW5ndGgpO1xuICAgICAgICAgIH0pO1xuICB9IGVsc2Uge1xuICAgICAgYmFyLmFwcGVuZCgncmVjdCcpXG4gICAgICAgICAgLmF0dHIoJ3gnLCAxKVxuICAgICAgICAgIC5hdHRyKCd3aWR0aCcsIF94U2NhbGUoYmluc1swXS54MSkgLSBfeFNjYWxlKGJpbnNbMF0ueDApIC0gMSlcbiAgICAgICAgICAuYXR0cignaGVpZ2h0JywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gX2dyYXBoSGVpZ2h0IC0gX3lTY2FsZShkLmxlbmd0aCk7XG4gICAgICAgICAgfSk7XG4gIH1cblxuICBiYXIuYXBwZW5kKCd0ZXh0JylcbiAgICAgIC5hdHRyKCdkeScsICcuNzVlbScpXG4gICAgICAuYXR0cigneScsIDYpXG4gICAgICAuYXR0cigneCcsIChfeFNjYWxlKGJpbnNbMF0ueDEpIC0gX3hTY2FsZShiaW5zWzBdLngwKSkgLyAyKVxuICAgICAgLmF0dHIoJ3RleHQtYW5jaG9yJywgJ21pZGRsZScpXG4gICAgICAudGV4dCgoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGZvcm1hdENvdW50KGQubGVuZ3RoKTtcbiAgICAgIH0pO1xuXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfdGl0bGVEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdUaXRsZShjZHQpO1xuICB9XG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkQXhpcy0tLS0tLS0tLS0tLS0tLS0tXG4gIHRoaXMuYnVpbGRZQXhpcyhjZHQpO1xuXG4gIHRoaXMuYnVpbGRYQXhpcyhjZHQpO1xuXG4gICBpZiAoX2dyaWRZRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3WUdyaWQoY2R0KTtcbiAgfVxufVxuXG5cblxucHJpdmF0ZSBidWlsZEZvcmNlKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ0luICBidWlsZEZvY2UtLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgX21heFggPSAxMDA7XG4gIGNvbnN0IF9tYXhZID0gMTAwO1xuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuXG4gIGNvbnN0IF9jb2xvciA9IGNkdC5kZWZhdWx0Q29sb3JGdW5jO1xuICBjb25zdCBfaW5pdFBvc1ggPSBjZHQuZ3JhcGhJbml0WFBvcztcbiAgY29uc3QgX2luaXRQb3NZID0gY2R0LmdyYXBoSW5pdFlQb3M7XG4gIGNvbnN0IF9jZW50ZXJQb3MgPSBjZHQuZ3JhcGhDZW50ZXJQb3M7XG4gIGNvbnN0IF9ncmFwaEhlaWdodCA9IGNkdC5ncmFwaEhlaWdodDtcbiAgY29uc3QgX2dyYXBoV2lkdGggPSBjZHQuZ3JhcGhXaWR0aDtcblxuICBjb25zdCBfbWFyZ2luTGVmdCA9IGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQ7XG4gIGNvbnN0IF9tYXJnaW5Ub3AgPSBjb25maWdEYXRhLm1hcmdpbi50b3A7XG5cblxuICBjb25zdCBzaW11bGF0aW9uID0gZDMuZm9yY2VTaW11bGF0aW9uKClcbiAgICAgIC5mb3JjZSgnbGluaycsIGQzLmZvcmNlTGluaygpLmlkKChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gZC5pZDtcbiAgICAgIH0pKVxuICAgICAgLmZvcmNlKCdjaGFyZ2UnLCBkMy5mb3JjZU1hbnlCb2R5KCkpXG4gICAgICAuZm9yY2UoJ2NlbnRlcicsIGQzLmZvcmNlQ2VudGVyKF9ncmFwaFdpZHRoIC8gMiwgX2dyYXBoSGVpZ2h0IC8gMikpO1xuXG5cbiAgY29uc3QgX2ZvcmNlQ29udGFpbmVyID0gc3ZnQ29udGFpbmVyXG4gICAgLmFwcGVuZCgnZycpXG4gICAgLmF0dHIoJ3RyYW5zZm9ybScsXG4gICAgICAndHJhbnNsYXRlKCcgKyBfbWFyZ2luTGVmdCArICcsJyArIF9tYXJnaW5Ub3AgKyAnKScpO1xuXG4gIGNvbnN0IGxpbmsgPSBfZm9yY2VDb250YWluZXIuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCdjbGFzcycsICdmb3JjZS1saW5rcycpXG4gICAgICAuc2VsZWN0QWxsKCdsaW5lJylcbiAgICAgIC5kYXRhKGRhdGFTZXRKc29uLmxpbmtzKVxuICAgICAgLmVudGVyKClcbiAgICAgIC5hcHBlbmQoJ2xpbmUnKVxuICAgICAgLmF0dHIoJ3N0cm9rZS13aWR0aCcsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gTWF0aC5zcXJ0KGQudmFsdWUpO1xuICAgICAgfSk7XG5cbiAgY29uc3Qgbm9kZSA9IF9mb3JjZUNvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgJ25vZGVzJylcbiAgICAgIC5zZWxlY3RBbGwoJ2NpcmNsZScpXG4gICAgICAuZGF0YShkYXRhU2V0SnNvbi5ub2RlcylcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdjaXJjbGUnKVxuICAgICAgLmF0dHIoJ3InLCA1KVxuICAgICAgLmF0dHIoJ2ZpbGwnLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIF9jb2xvcihkLmdyb3VwKTtcbiAgICAgIH0pXG4gICAgICAuY2FsbChkMy5kcmFnKClcbiAgICAgICAgICAub24oJ3N0YXJ0JywgZHJhZ3N0YXJ0ZWQpXG4gICAgICAgICAgLm9uKCdkcmFnJywgZHJhZ2dlZClcbiAgICAgICAgICAub24oJ2VuZCcsIGRyYWdlbmRlZCkpO1xuXG4gICAgICBub2RlLmFwcGVuZCgndGl0bGUnKVxuICAgICAgICAgIC50ZXh0KChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIGQuaWQ7XG4gICAgICAgICAgfSk7XG5cbiAgc2ltdWxhdGlvblxuICAgICAgLm5vZGVzKGRhdGFTZXRKc29uLm5vZGVzKVxuICAgICAgLm9uKCd0aWNrJywgdGlja2VkKTtcblxuICBjb25zdCBfZm9yY2VMaW5rOiBhbnkgPSBzaW11bGF0aW9uLmZvcmNlKCdsaW5rJyk7XG4gIF9mb3JjZUxpbmsubGlua3MoZGF0YVNldEpzb24ubGlua3MpO1xuXG4gIGZ1bmN0aW9uIHRpY2tlZCgpIHtcbiAgICAgIGxpbmtcbiAgICAgICAgICAuYXR0cigneDEnLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgcmV0dXJuIGQuc291cmNlLng7IH0pXG4gICAgICAgICAgLmF0dHIoJ3kxJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIGQuc291cmNlLnk7IH0pXG4gICAgICAgICAgLmF0dHIoJ3gyJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgIHJldHVybiBkLnRhcmdldC54OyB9KVxuICAgICAgICAgIC5hdHRyKCd5MicsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICByZXR1cm4gZC50YXJnZXQueTsgfSk7XG5cbiAgICAgIG5vZGVcbiAgICAgICAgICAuYXR0cignY3gnLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgcmV0dXJuIGQueDsgfSlcbiAgICAgICAgICAuYXR0cignY3knLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgcmV0dXJuIGQueTsgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBkcmFnc3RhcnRlZChkOiBhbnkpICB7XG4gICAgICBpZiAoIWQzLmV2ZW50LmFjdGl2ZSkge1xuICAgICAgICAgIHNpbXVsYXRpb24uYWxwaGFUYXJnZXQoMC4zKS5yZXN0YXJ0KCk7XG4gICAgICB9XG4gICAgICBkLmZ4ID0gZC54O1xuICAgICAgZC5meSA9IGQueTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGRyYWdnZWQoZDogYW55KSAge1xuICAgICAgZC5meCA9IGQzLmV2ZW50Lng7XG4gICAgICBkLmZ5ID0gZDMuZXZlbnQueTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGRyYWdlbmRlZChkOiBhbnkpICB7XG4gICAgICBpZiAoIWQzLmV2ZW50LmFjdGl2ZSkge1xuICAgICAgICAgIHNpbXVsYXRpb24uYWxwaGFUYXJnZXQoMCk7XG4gICAgICB9XG4gICAgICBkLmZ4ID0gbnVsbDtcbiAgICAgIGQuZnkgPSBudWxsO1xuICB9XG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBidWlsZExlZ2VuZC0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0IF9sZWdlbmREYXRhU2V0OiBBcnJheTxPMkxlZ2VuZERhdGE+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5ncm91cHMpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5ncm91cHMuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBjb25zdCBfaWQgPSBkYXRhU2V0SnNvbi5ncm91cHNbaV0uaWQ7XG4gICAgICAgICAgX2xlZ2VuZERhdGFTZXQucHVzaChuZXcgTzJMZWdlbmREYXRhKGRhdGFTZXRKc29uLmdyb3Vwc1tpXS5uYW1lLCBfY29sb3IoX2lkKSkpO1xuICAgICAgfVxuICB9XG4gIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG5cblxuXG59XG5cblxucHJpdmF0ZSBidWlsZENob3JvcGxldGgoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRDaG9yb3BsZXRoIC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfbWF4WCA9IDEwMDsgLy8gYW55IHZhbHVlXG4gIGNvbnN0IF9tYXhZID0gMTAwOyAvLyBhbnkgdmFsdWVcbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcbiAgY29uc3QgX2dyYXBoQ2VudGVyUG9zID0gY2R0LmdyYXBoQ2VudGVyUG9zO1xuICBjb25zdCBfZ3JhcGhJbml0WCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfZ3JhcGhJbml0WSA9IGNkdC5ncmFwaEluaXRZUG9zO1xuXG5cbiAgY29uc3QgX3RpdGxlRGlzcGxheSA9IGNvbmZpZ0RhdGEudGl0bGUuZGlzcGxheTtcbiAgY29uc3QgX2xlZ2VuZERpc3BsYXkgPSBjb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5O1xuICBjb25zdCBfZm9jdXNDb2xvciA9IGNvbmZpZ0RhdGEuY29sb3IuZm9jdXNDb2xvcjtcblxuICBjb25zdCBfc2NhbGUgPSBkYXRhU2V0SnNvbi5tYXAuc2NhbGU7XG4gIGNvbnN0IF90YXJnZXROYW1lID0gZGF0YVNldEpzb24ubWFwLnRhcmdldE5hbWU7XG4gIGNvbnN0IF9rZXlEYXRhTmFtZSA9IGRhdGFTZXRKc29uLm1hcC5rZXlEYXRhTmFtZTtcbiAgY29uc3QgX2tleU5hbWUgPSAnZGF0YS4nICsgX2tleURhdGFOYW1lO1xuICBjb25zdCBfZ2VvTWFwRGF0YVVybCA9IGRhdGFTZXRKc29uLm1hcC5iYXNlR2VvRGF0YVVybDtcbiAgY29uc3QgX3N0YXJ0Q29sb3IgPSBkYXRhU2V0SnNvbi5tYXAuc3RhcnRDb2xvcjtcbiAgY29uc3QgX2VuZENvbG9yID0gZGF0YVNldEpzb24ubWFwLmVuZENvbG9yO1xuICBjb25zdCBfY29sb3JOdW0gPSBkYXRhU2V0SnNvbi5tYXAuY29sb3JOdW1iZXI7XG4gIGNvbnN0IF9jZW50ZXIgPSBkYXRhU2V0SnNvbi5tYXAuY2VudGVyO1xuICBjb25zdCBfdGFyZ2V0UHJvcGVydHlOYW1lID0gZGF0YVNldEpzb24ubWFwLnRhcmdldFByb3BlcnR5TmFtZTtcbiAgY29uc3QgX3RhcmdldFByb3BlcnR5ID0gJ2QuJyArIF90YXJnZXRQcm9wZXJ0eU5hbWU7XG5cbiAgY29uc3QgY29sb3IgPSBkMy5pbnRlcnBvbGF0ZUhzbChfc3RhcnRDb2xvciwgX2VuZENvbG9yKTtcblxuICBsZXQgX21heCA9IGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWU7XG4gIGxldCBfbWluID0gZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgaWYgKF9tYXggPCBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlKSB7XG4gICAgICAgICAgICAgIF9tYXggPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoX21pbiA+IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUpIHtcbiAgICAgICAgICAgICAgX21pbiA9IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWU7XG4gICAgICAgICAgfVxuICAgICAgfVxuICB9XG4gIGNvbnN0IF9yYW5nZSA9IF9tYXggLSBfbWluO1xuICBjb25zdCBfc3RlcCA9IF9yYW5nZSAvIChfY29sb3JOdW0gLSAxKTtcblxuICBjb25zdCBfZmluZENvbG9yQnlJZCA9IChpZDogbnVtYmVyKTogc3RyaW5nID0+IHtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgaWYgKGlkID09PSBkYXRhU2V0SnNvbi5kYXRhW2ldLmlkKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBfdmFsdWUgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgY29uc3QgX3JhdGUgPSBNYXRoLmNlaWwoKF92YWx1ZSAtIF9taW4pIC8gX3N0ZXApO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbG9yKF9yYXRlIC8gX21heCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gIH07XG5cbiAgY29uc3QgcGF0aCA9IGQzLmdlb1BhdGgoKVxuICAgICAgICAgICAgICAucHJvamVjdGlvbihcbiAgICAgICAgICAgICAgICAgIGQzLmdlb01lcmNhdG9yKClcbiAgICAgICAgICAgICAgICAgIC5jZW50ZXIoX2NlbnRlcilcbiAgICAgICAgICAgICAgICAgIC5zY2FsZShfc2NhbGUpXG4gICAgICAgICAgICAgICAgICAudHJhbnNsYXRlKF9ncmFwaENlbnRlclBvcylcbiAgICAgICAgICAgICAgKTtcblxuICBkMy5qc29uKF9nZW9NYXBEYXRhVXJsLCAoZXJyb3IsIGRhdGEpID0+IHtcbiAgICAgIHN2Z0NvbnRhaW5lci5zZWxlY3RBbGwoJ3BhdGgnKVxuICAgICAgICAgICAgICAuZGF0YShldmFsKF9rZXlOYW1lKSlcbiAgICAgICAgICAgICAgLmVudGVyKClcbiAgICAgICAgICAgICAgLmFwcGVuZCgncGF0aCcpXG4gICAgICAgICAgICAgIC5hdHRyKCdkJywgcGF0aClcbiAgICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX2NsID0gX2ZpbmRDb2xvckJ5SWQoZXZhbChfdGFyZ2V0UHJvcGVydHkpKTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBfY2w7XG4gICAgICAgICAgICAgIH0pO1xuICB9KTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZFRpdGxlLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF90aXRsZURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1RpdGxlKGNkdCk7XG4gIH1cblxuICAvLyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vICAtLS1DQUxMIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF9sZWdlbmREaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfY29sb3JOdW07IGkrKykge1xuICAgICAgICAgIGNvbnN0IF9sYWJlbCA9IFN0cmluZyhfbWluICsgKGkgKiBfc3RlcCkpICsgICcgLS0nO1xuICAgICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShfbGFiZWwsIGNvbG9yKGkgLyBfbWF4KSkpO1xuICAgICAgfVxuICAgICAgdGhpcy5idWlsZExlZ2VuZChjZHQsIF9sZWdlbmREYXRhU2V0KTtcbiAgfVxuXG59XG5cbnByaXZhdGUgYnVpbGRQYWNrTGF5b3V0KHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIFBhY2tMYXlvdXQtLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfcGFja2xheW91dENsYXNzID0gY29uZmlnRGF0YS5jbGFzc05hbWUucGFja2xheW91dDtcbiAgY29uc3QgX3BhY2tsYXlvdXRMYWJlbENsYXNzID0gY29uZmlnRGF0YS5jbGFzc05hbWUucGFja2xheW91dExhYmVsO1xuICBjb25zdCBfYW5pbWF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZW5hYmxlO1xuICBjb25zdCBfYW5pbWF0aW9uRHVyYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5kdXJhdGlvbjtcbiAgY29uc3QgY29sb3IgPSBkMy5zY2FsZU9yZGluYWwoZDMuc2NoZW1lQ2F0ZWdvcnkxMCk7XG4gIC8vICBjb25zdCBjb2xvciA9IGQzLnNjYWxlLmNhdGVnb3J5MTAoKTtcbiAgY29uc3QgYnViYmxlID0gZDMucGFjaygpXG4gICAgICAgICAgICAgICAgICAuc2l6ZShbc3ZnV2lkdGgsIHN2Z0hlaWdodF0pO1xuXG4gIGNvbnN0IG5vZGVzMCA9IGQzLmhpZXJhcmNoeShkYXRhU2V0SnNvbik7XG5cbiAgY29uc3QgcGFjayA9ICBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdnJylcbiAgICAgICAgICAgICAgLmRhdGEoYnViYmxlKG5vZGVzMCkuZGVzY2VuZGFudHMoKSlcbiAgICAgICAgICAgICAgLmVudGVyKClcbiAgICAgICAgICAgICAgLmFwcGVuZCgnZycpXG4gICAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgZC54ICsgJywnICsgZC55ICsgJyknO1xuICAgICAgICAgICAgICB9KTtcblxuICBjb25zdCBfY2lyY2xlID0gcGFjay5hcHBlbmQoJ2NpcmNsZScpO1xuICBpZiAoX2FuaW1hdGlvbikge1xuICAgICAgX2NpcmNsZS5hdHRyKCdyJywgMClcbiAgICAgICAgICAgICAgLnRyYW5zaXRpb24oKVxuICAgICAgICAgICAgICAuZHVyYXRpb24oKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGQuZGVwdGggKiBfYW5pbWF0aW9uRHVyYXRpb24gICsgNTAwO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAuYXR0cigncicsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBkLnI7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIChkOiBhbnksIGk6IGFueSkgPT4gIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjb2xvcihpKTtcbiAgICAgICAgICAgICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgICBfY2lyY2xlLmF0dHIoJ3InLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gZC5yO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAoZDogYW55LCBpOiBhbnkpID0+ICB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gY29sb3IoaSk7XG4gICAgICAgICAgICAgIH0pO1xuICB9XG5cbiAgY29uc3QgX3RleHQgPSBwYWNrLmFwcGVuZCgndGV4dCcpXG4gICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIF9wYWNrbGF5b3V0TGFiZWxDbGFzcylcbiAgICAgICAgICAgICAgLnRleHQoKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICAgICAgaWYgKGQuZGVwdGggPT09IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZC5kYXRhLm5hbWU7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICAgfSk7XG5cbiAgaWYgKF9hbmltYXRpb24pIHtcbiAgICAgIF90ZXh0LnN0eWxlKCdvcGFjaXR5JywgMClcbiAgICAgICAgICAudHJhbnNpdGlvbigpXG4gICAgICAgICAgLmR1cmF0aW9uKF9hbmltYXRpb25EdXJhdGlvbilcbiAgICAgICAgICAuc3R5bGUoJ29wYWNpdHknLCAxLjApO1xuICB9IGVsc2Uge1xuICAgICAgX3RleHQuc3R5bGUoJ29wYWNpdHknLCAxLjApO1xuICB9XG5cbn1cblxucHJpdmF0ZSBidWlsZFRyZWUoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnSW4gIGJ1aWxkVHJlZS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBsZXQgX21heFggPSAwO1xuICBsZXQgX21heFkgPSAwO1xuICBfbWF4WSA9IDEwMDtcbiAgX21heFggPSAxMDA7XG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG5cbiAgY29uc3QgX2NvbG9yID0gY2R0LmRlZmF1bHRDb2xvckZ1bmM7XG4gIGNvbnN0IF9pbml0UG9zWCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfaW5pdFBvc1kgPSBjZHQuZ3JhcGhJbml0WVBvcztcbiAgY29uc3QgX2dyYXBoSGVpZ2h0ID0gY2R0LmdyYXBoSGVpZ2h0O1xuICBjb25zdCBfZ3JhcGhXaWR0aCA9IGNkdC5ncmFwaFdpZHRoO1xuXG4gIGNvbnN0IF9hbmltYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5lbmFibGU7XG4gIGNvbnN0IF9hbmltYXRpb25EdXJhdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmR1cmF0aW9uO1xuICBjb25zdCBfdHJlZW1hcENsYXNzID0gY29uZmlnRGF0YS5jbGFzc05hbWUudHJlZW1hcDtcbiAgY29uc3QgX3RyZWVtYXBMYWJlbENsYXNzID0gY29uZmlnRGF0YS5jbGFzc05hbWUudHJlZW1hcExhYmVsO1xuICBjb25zdCBfbWFyZ2luTGVmdCA9IGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQ7XG4gIGNvbnN0IF9tYXJnaW5Ub3AgPSBjb25maWdEYXRhLm1hcmdpbi50b3A7XG5cblxuICBjb25zdCB0cmVlID0gZDMudHJlZSgpXG4gICAgICAgICAgICAgICAgICAuc2l6ZShbX2dyYXBoV2lkdGgsIF9ncmFwaEhlaWdodF0pO1xuXG4gIGNvbnN0IG5vZGVzMCA9IGQzLmhpZXJhcmNoeShkYXRhU2V0SnNvbik7XG5cbiAgY29uc3Qgbm9kZXMgPSB0cmVlKG5vZGVzMCk7XG5cbiAgY29uc3QgX3RyZWVDb250YWluZXIgPSBzdmdDb250YWluZXJcbiAgICAuYXBwZW5kKCdnJylcbiAgICAuYXR0cigndHJhbnNmb3JtJyxcbiAgICAgICd0cmFuc2xhdGUoJyArIF9tYXJnaW5MZWZ0ICsgJywnICsgX21hcmdpblRvcCArICcpJyk7XG5cbiAgY29uc3QgbGluayA9IF90cmVlQ29udGFpbmVyXG4gICAgICAuc2VsZWN0QWxsKCcubGluaycpXG4gICAgICAuZGF0YSggbm9kZXMuZGVzY2VuZGFudHMoKS5zbGljZSgxKSlcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdwYXRoJylcbiAgICAgIC5hdHRyKCdjbGFzcycsICd0cmVlLW5vZGUtbGluaycpXG4gICAgICAuYXR0cignZCcsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gJ00nICsgZC54ICsgJywnICsgZC55XG4gICAgICAgICAgICAgICsgJ0MnICsgZC54ICsgJywnICsgKGQueSArIGQucGFyZW50LnkpIC8gMlxuICAgICAgICAgICAgICArICcgJyArIGQucGFyZW50LnggKyAnLCcgKyAgKGQueSArIGQucGFyZW50LnkpIC8gMlxuICAgICAgICAgICAgICArICcgJyArIGQucGFyZW50LnggKyAnLCcgKyBkLnBhcmVudC55O1xuICAgICAgICAgIH1cbiAgICAgICk7XG5cbiAgY29uc3Qgbm9kZSA9IF90cmVlQ29udGFpbmVyXG4gICAgICAuc2VsZWN0QWxsKCcubm9kZScpXG4gICAgICAuZGF0YShub2Rlcy5kZXNjZW5kYW50cygpKVxuICAgICAgLmVudGVyKClcbiAgICAgIC5hcHBlbmQoJ2cnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiAndHJlZS1ub2RlJyArXG4gICAgICAgICAgKGQuY2hpbGRyZW4gPyAnLWludGVybmFsJyA6ICctbGVhZicpO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIGQueCArICcsJyArIGQueSArICcpJztcbiAgICAgIH0pO1xuXG4gIG5vZGUuYXBwZW5kKCdjaXJjbGUnKVxuICAgICAgLmF0dHIoJ3InLCAxMCk7XG5cbiAgbm9kZS5hcHBlbmQoJ3RleHQnKVxuICAgICAgLmF0dHIoJ2R5JywgJy4zNWVtJylcbiAgICAgIC5hdHRyKCd5JywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiBkLmNoaWxkcmVuID8gLTIwIDogMjA7XG4gICAgICB9KVxuICAgICAgLnN0eWxlKCd0ZXh0LWFuY2hvcicsICdtaWRkbGUnKVxuICAgICAgLnRleHQoKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiBkLmRhdGEubmFtZTtcbiAgICAgIH0pO1xuXG5cbn1cblxuXG5cbnByaXZhdGUgYnVpbGRHZW9PcnRob2dyYXBoaWMoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRHZW9PcnRob2dyYXBoaWMgLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IF9tYXhYID0gMTAwOyAvLyBhbnkgdmFsdWVcbiAgY29uc3QgX21heFkgPSAxMDA7IC8vIGFueSB2YWx1ZVxuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuICBjb25zdCBfZ3JhcGhDZW50ZXJQb3MgPSBjZHQuZ3JhcGhDZW50ZXJQb3M7XG4gIGNvbnN0IF9ncmFwaEluaXRYID0gY2R0LmdyYXBoSW5pdFhQb3M7XG4gIGNvbnN0IF9ncmFwaEluaXRZID0gY2R0LmdyYXBoSW5pdFlQb3M7XG5cbiAgY29uc3QgX3RpdGxlRGlzcGxheSA9IGNvbmZpZ0RhdGEudGl0bGUuZGlzcGxheTtcbiAgY29uc3QgX2xlZ2VuZERpc3BsYXkgPSBjb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5O1xuICBjb25zdCBfZm9jdXNDb2xvciA9IGNvbmZpZ0RhdGEuY29sb3IuZm9jdXNDb2xvcjtcblxuICBjb25zdCBfZ2VvTWFwRGF0YVVybCA9IGRhdGFTZXRKc29uLm1hcC5iYXNlR2VvRGF0YVVybDtcbiAgY29uc3QgX3NjYWxlID0gZGF0YVNldEpzb24ubWFwLnNjYWxlO1xuICBjb25zdCBfdGFyZ2V0TmFtZSA9IGRhdGFTZXRKc29uLm1hcC50YXJnZXROYW1lO1xuICBjb25zdCBfdGFyZ2V0UHJvcGVydHkgPSAnZC4nICsgZGF0YVNldEpzb24ubWFwLnRhcmdldFByb3BlcnR5TmFtZTtcbiAgY29uc3QgX2tleURhdGFOYW1lID0gZGF0YVNldEpzb24ubWFwLmtleURhdGFOYW1lO1xuICBjb25zdCBfa2V5TmFtZSA9ICdkYXRhLicgKyBfa2V5RGF0YU5hbWU7XG4gIGNvbnN0IF9jbGlwQW5nbGUgPSBkYXRhU2V0SnNvbi5tYXAuY2xpcEFuZ2xlO1xuICBjb25zdCBfcm90YXRlSCAgID0gZGF0YVNldEpzb24ubWFwLnJvdGF0ZS5ob3Jpem9udGFsO1xuICBjb25zdCBfcm90YXRlViAgID0gZGF0YVNldEpzb24ubWFwLnJvdGF0ZS52ZXJ0aWNhbDtcbiAgY29uc3QgX29jZWFuQ29sb3IgPSBkYXRhU2V0SnNvbi5tYXAub2NlYW5Db2xvcjtcbiAgY29uc3QgX2FudGFyY3RpY2FDb2xvciA9IGRhdGFTZXRKc29uLm1hcC5hbnRhcmN0aWNhQ29sb3I7XG4gIGNvbnN0IF9hbmltYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5lbmFibGU7XG4gIGNvbnN0IF9hbmltYXRpb25EdXJhdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmR1cmF0aW9uO1xuICBsZXQgX2FuaW1hdGlvbkggPSAwO1xuXG4gIGNvbnN0IF9maW5kQ29sb3JCeU5hbWUgPSAobmFtZTogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgaWYgKG5hbWUgPT09IGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZSkge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX2NvbG9yID0gZGF0YVNldEpzb24uZGF0YVtpXS5jb2xvcjtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBfY29sb3I7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgfTtcblxuICBjb25zdCB0YXJnZXRQYXRoID0gZDMuZ2VvT3J0aG9ncmFwaGljKClcbiAgICAgICAgICAgICAgLnRyYW5zbGF0ZShfZ3JhcGhDZW50ZXJQb3MpXG4gICAgICAgICAgICAgIC5jbGlwQW5nbGUoX2NsaXBBbmdsZSlcbiAgICAgICAgICAgICAgLnNjYWxlKF9zY2FsZSlcbiAgICAgICAgICAgICAgLnJvdGF0ZShbX3JvdGF0ZUgsIF9yb3RhdGVWXSk7XG5cbiAgY29uc3QgcGF0aCA9IGQzLmdlb1BhdGgoKVxuICAgICAgICAgICAgICAucHJvamVjdGlvbihcbiAgICAgICAgICAgICAgICAgIHRhcmdldFBhdGhcbiAgICAgICAgICAgICAgKTtcblxuICBkMy5qc29uKF9nZW9NYXBEYXRhVXJsLCAoZXJyb3IsIGRhdGEpID0+IHtcbiAgICAgIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ2NpcmNsZScpXG4gICAgICAgICAgLmF0dHIoJ2N4JywgX2dyYXBoQ2VudGVyUG9zWzBdKVxuICAgICAgICAgIC5hdHRyKCdjeScsIF9ncmFwaENlbnRlclBvc1sxXSlcbiAgICAgICAgICAuYXR0cigncicsIF9zY2FsZSlcbiAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCBfb2NlYW5Db2xvcik7XG5cbiAgICAgIGNvbnN0IGVhcnRoUGF0aCA9IHN2Z0NvbnRhaW5lci5zZWxlY3RBbGwoJ3BhdGgnKVxuICAgICAgICAgIC5kYXRhKGV2YWwoX2tleU5hbWUpKVxuICAgICAgICAgIC5lbnRlcigpXG4gICAgICAgICAgLmFwcGVuZCgncGF0aCcpXG4gICAgICAgICAgLmF0dHIoJ2QnLCBwYXRoKVxuICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICAgICAgY29uc3QgX3RhcmdldEFyZWEgPSBldmFsKF90YXJnZXRQcm9wZXJ0eSk7XG4gICAgICAgICAgICAgIGlmIChfZmluZENvbG9yQnlOYW1lKF90YXJnZXRBcmVhKSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIF9maW5kQ29sb3JCeU5hbWUoX3RhcmdldEFyZWEpO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgcmV0dXJuICdoc2woJyArIGkgKyAnLDgwJSw2MCUpJztcbiAgICAgICAgICB9KTtcbiAgICAgIGlmIChfYW5pbWF0aW9uKSB7XG4gICAgICAgICAgZDMudGltZXIoKCkgPT4ge1xuICAgICAgICAgICAgICB0YXJnZXRQYXRoLnJvdGF0ZShbX3JvdGF0ZUggKyBfYW5pbWF0aW9uSCwgX3JvdGF0ZVZdKTtcbiAgICAgICAgICAgICAgX2FuaW1hdGlvbkggKz0gMjtcbiAgICAgICAgICAgICAgZWFydGhQYXRoLmF0dHIoJ2QnLCBwYXRoKTtcbiAgICAgICAgICB9KTtcbiAgICAgIH1cbiAgfSk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfdGl0bGVEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdUaXRsZShjZHQpO1xuICB9XG5cbiAgaWYgKF9sZWdlbmREaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICAgICAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICBjb25zdCBfbmFtZSA9IGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZTtcbiAgICAgICAgICAgICAgY29uc3QgX2NvbG9yID0gZGF0YVNldEpzb24uZGF0YVtpXS5jb2xvcjtcbiAgICAgICAgICAgICAgaWYgKF9uYW1lID09PSAnQW50YXJjdGljYScpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWUsIGRhdGFTZXRKc29uLmRhdGFbaV0uY29sb3IpKTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLmJ1aWxkTGVnZW5kKGNkdCwgX2xlZ2VuZERhdGFTZXQpO1xuICB9XG5cblxufVxuXG5cblxucHJpdmF0ZSBidWlsZEdlb01hcChzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZEdlb01hcCAtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgX21heFggPSAxMDA7IC8vIGFueSB2YWx1ZVxuICBjb25zdCBfbWF4WSA9IDEwMDsgLy8gYW55IHZhbHVlXG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG4gIGNvbnN0IF9ncmFwaENlbnRlclBvcyA9IGNkdC5ncmFwaENlbnRlclBvcztcbiAgY29uc3QgX2dlb01hcERhdGFVcmwgPSAgZGF0YVNldEpzb24ubWFwLmJhc2VHZW9EYXRhVXJsO1xuICBjb25zdCBfc2NhbGUgPSBkYXRhU2V0SnNvbi5tYXAuc2NhbGU7XG4gIGNvbnN0IF9rZXlEYXRhTmFtZSA9IGRhdGFTZXRKc29uLm1hcC5rZXlEYXRhTmFtZTtcbiAgY29uc3QgX2tleU5hbWUgPSAnZGF0YS4nICsgX2tleURhdGFOYW1lO1xuICBjb25zdCBfdGFyZ2V0UHJvcGVydHkgPSAnZC4nICsgZGF0YVNldEpzb24ubWFwLnRhcmdldFByb3BlcnR5TmFtZTtcbiAgY29uc3QgX2FudGFyY3RpY2FDb2xvciA9IGRhdGFTZXRKc29uLm1hcC5hbnRhcmN0aWNhQ29sb3I7XG4gIGNvbnN0IF9sZWdlbmREaXNwbGF5ID0gY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheTtcblxuICBjb25zdCBwYXRoID0gZDMuZ2VvUGF0aCgpXG4gICAgICAgICAgICAgIC5wcm9qZWN0aW9uKFxuICAgICAgICAgICAgICAgICAgZDMuZ2VvTWVyY2F0b3IoKVxuICAgICAgICAgICAgICAgICAgLnRyYW5zbGF0ZShfZ3JhcGhDZW50ZXJQb3MpXG4gICAgICAgICAgICAgICAgICAuc2NhbGUoX3NjYWxlKVxuICAgICAgICAgICAgICApO1xuXG4gIGNvbnN0IF9maW5kQ29sb3JCeU5hbWUgPSAobmFtZTogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgaWYgKG5hbWUgPT09IGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZSkge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX2NvbG9yID0gZGF0YVNldEpzb24uZGF0YVtpXS5jb2xvcjtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBfY29sb3I7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgfTtcblxuICBkMy5qc29uKF9nZW9NYXBEYXRhVXJsLCAoZXJyb3IsIGRhdGEpID0+IHtcbiAgICAgIHN2Z0NvbnRhaW5lci5zZWxlY3RBbGwoJ3BhdGgnKVxuICAgICAgICAgICAgICAuZGF0YShldmFsKF9rZXlOYW1lKSlcbiAgICAgICAgICAgICAgLmVudGVyKClcbiAgICAgICAgICAgICAgLmFwcGVuZCgncGF0aCcpXG4gICAgICAgICAgICAgIC5hdHRyKCdkJywgcGF0aClcbiAgICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX3RhcmdldEFyZWEgPSBldmFsKF90YXJnZXRQcm9wZXJ0eSk7XG4gICAgICAgICAgICAgICAgICBpZiAoX2ZpbmRDb2xvckJ5TmFtZShfdGFyZ2V0QXJlYSkgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX2ZpbmRDb2xvckJ5TmFtZShfdGFyZ2V0QXJlYSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICByZXR1cm4gJ2hzbCgnICsgaSArICcsODAlLDYwJSknO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgIH0pO1xuXG4gIC8vICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gIC0tLUNBTEwgYnVpbGRMZWdlbmQtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX2xlZ2VuZERpc3BsYXkpIHtcbiAgICAgIGNvbnN0IF9sZWdlbmREYXRhU2V0OiBBcnJheTxPMkxlZ2VuZERhdGE+ID0gbmV3IEFycmF5KCk7XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgIGNvbnN0IF9uYW1lID0gZGF0YVNldEpzb24uZGF0YVtpXS5uYW1lO1xuICAgICAgICAgICAgICBjb25zdCBfY29sb3IgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLmNvbG9yO1xuICAgICAgICAgICAgICBpZiAoX25hbWUgPT09ICdBbnRhcmN0aWNhJykge1xuICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgX2xlZ2VuZERhdGFTZXQucHVzaChuZXcgTzJMZWdlbmREYXRhKGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZSwgZGF0YVNldEpzb24uZGF0YVtpXS5jb2xvcikpO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG4gIH1cblxufVxuXG5cblxucHJpdmF0ZSBidWlsZFN0YWNrQmFyKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkU3RhY2tCYXItLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgaW50ZXJmYWNlIEhhc2hTdHJpbmcge1xuICAgIFtpbmRleDogc3RyaW5nXTogc3RyaW5nO1xuICB9XG4gIGludGVyZmFjZSBIYXNoTnVtYmVyIHtcbiAgICBba2V5OiBzdHJpbmddOiBudW1iZXI7XG4gIH1cblxuICBjb25zdCBfdG90YWxZOiBBcnJheTxudW1iZXI+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgX3RvdGFsWS5wdXNoKDApO1xuICAgICAgfVxuICB9XG5cbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgbGV0IGsgPSAwO1xuICAgICAgICAgIGZvciAoY29uc3QgaiBpbiBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlKSB7XG4gICAgICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlLmhhc093blByb3BlcnR5KGopKSB7XG4gICAgICAgICAgICAgICAgICBfdG90YWxZW2srK10gKz0gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS55O1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgfVxuICB9XG4gIGxldCBfbWF4WCA9IDA7XG4gIGxldCBfbWF4WSA9IDA7XG4gIF9tYXhZID0gZDMubWF4KF90b3RhbFkpO1xuICBfbWF4WCA9IDEwMDtcbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcblxuICBjb25zdCBfY29sb3IgPSBjZHQuZGVmYXVsdENvbG9yRnVuYztcbiAgY29uc3QgX2NvbHVtbk51bSA9ICBkYXRhU2V0SnNvbi5kYXRhLmxlbmd0aDtcbiAgY29uc3QgX2JhcldpZHRoID0gKGNkdC5ncmFwaFdpZHRoIC8gX2NvbHVtbk51bSkgLSBjb25maWdEYXRhLm1hcmdpbi5iZXR3ZWVuO1xuICBjb25zdCBfY29sdW1uV2lkdGggPSAoY2R0LmdyYXBoV2lkdGggLyBfY29sdW1uTnVtKSA7XG4gIGNvbnN0IF9pbml0UG9zWCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfaW5pdFBvc1kgPSBjZHQuZ3JhcGhJbml0WVBvcztcbiAgY29uc3QgX2dyYXBoSGVpZ2h0ID0gY2R0LmdyYXBoSGVpZ2h0O1xuICBjb25zdCBfbWF4WVZhbHVlID0gY2R0Lm1heFlWYWx1ZTtcblxuICBjb25zdCBfb3BhY2l0eSA9IGNvbmZpZ0RhdGEuY29sb3Iub3BhY2l0eTtcbiAgY29uc3QgX2xlZ2VuZERpc3BsYXkgPSBjb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5O1xuICBjb25zdCBfZ3JpZFlEaXNwbGF5ID0gY29uZmlnRGF0YS5ncmlkLnkuZGlzcGxheTtcbiAgY29uc3QgX2dyaWRYRGlzcGxheSA9IGNvbmZpZ0RhdGEuZ3JpZC54LmRpc3BsYXk7XG4gIGNvbnN0IF9sYWJlbERpc3BsYXkgPSBjb25maWdEYXRhLmxhYmVsLmRpc3BsYXk7XG4gIGNvbnN0IF9hbmltYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5lbmFibGU7XG4gIGNvbnN0IF9hbmltYXRpb25EdXJhdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmR1cmF0aW9uO1xuXG4gIC8vICBHZXQgRGF0YSBOYW1lXG4gIGNvbnN0IF9zZXJpZXNEYXRlTmFtZSA9IGRhdGFTZXRKc29uLnNlcmllc1swXTtcblxuICAvLyAgR2V0IEtleXNcbiAgY29uc3QgX2tleUFycmF5OiBBcnJheTxzdHJpbmc+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGNvbnN0IF9rZXkgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWU7XG4gICAgICAgICAgY29uc3QgX3ZhbHVlID0gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVswXS55O1xuICAgICAgICAgIF9rZXlBcnJheS5wdXNoKF9rZXkpO1xuICAgICAgfVxuICB9XG5cbiAgLy8gIEdldCBEYXRlIFN0cmluZ1xuICBjb25zdCBfZGF0ZUFycmF5OiBBcnJheTxzdHJpbmc+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGNvbnN0IF94VmFsdWUgPSBkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlW2ldLng7XG4gICAgICAgICAgX2RhdGVBcnJheS5wdXNoKF94VmFsdWUpO1xuICAgICAgfVxuICB9XG5cbiAgY29uc3QgX2hhc2hBcnJheTogQXJyYXk8YW55PiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gX2RhdGVBcnJheSkge1xuICAgICAgaWYgKF9kYXRlQXJyYXkuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBjb25zdCBfZGF0ZVN0ID0gX2RhdGVBcnJheVtpXTtcbiAgICAgICAgICBjb25zdCBfaGFzaE51bWJlcjogSGFzaE51bWJlciA9IHsgfTtcbiAgICAgICAgICBmb3IgKGNvbnN0IGogaW4gX2tleUFycmF5KSB7XG4gICAgICAgICAgICAgIGlmIChfa2V5QXJyYXkuaGFzT3duUHJvcGVydHkoaikpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IF9rZXkgPSBfa2V5QXJyYXlbal07XG4gICAgICAgICAgICAgICAgICBjb25zdCBfdmFsdWUgPSBkYXRhU2V0SnNvbi5kYXRhW2pdLnZhbHVlW2ldLnk7XG4gICAgICAgICAgICAgICAgICBfaGFzaE51bWJlcltfa2V5XSAgPSBfdmFsdWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgX2hhc2hBcnJheS5wdXNoKF9oYXNoTnVtYmVyKTtcbiAgICAgIH1cbiAgfVxuXG4gIGNvbnN0IHlTY2FsZSA9IGQzLnNjYWxlTGluZWFyKClcbiAgICAgICAgICAgICAgICAgIC5kb21haW4oWzAsIF9tYXhZVmFsdWVdKVxuICAgICAgICAgICAgICAgICAgLnJhbmdlKFswLCBfZ3JhcGhIZWlnaHRdKTtcblxuXG4gIGNvbnN0IHN0YWNrID0gZDMuc3RhY2soKTtcbiAgY29uc3QgX3JlY3QgPSBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdnJylcbiAgICAgIC5kYXRhKHN0YWNrLmtleXMoX2tleUFycmF5KShfaGFzaEFycmF5KSlcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCdmaWxsJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIF9jb2xvcihpKTtcbiAgICAgIH0gKVxuICAgICAgLmF0dHIoJ2ZpbGwtb3BhY2l0eScsIF9vcGFjaXR5KVxuICAgICAgLnNlbGVjdEFsbCgncmVjdCcpXG4gICAgICAuZGF0YSgoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICByZXR1cm4gZDtcbiAgICAgIH0pXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgncmVjdCcpO1xuXG5cblxuICBpZiAoX2FuaW1hdGlvbikge1xuICAgICAgX3JlY3QuYXR0cigneCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgIHJldHVybiBfaW5pdFBvc1jDo8KAwoAgKyDDo8KAwoBpICogX2NvbHVtbldpZHRoO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCAgMClcbiAgICAgIC5hdHRyKCd5JywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgY29uc3Qgbm0gPSAnZC5kYXRhLicgKyBfa2V5QXJyYXlbaV07XG4gICAgICAgICAgY29uc3QgX3lWYWx1ZSA9IGV2YWwobm0pO1xuICAgICAgICAgIHJldHVybiBzdmdIZWlnaHQgLSBjb25maWdEYXRhLm1hcmdpbi5ib3R0b20gLSB5U2NhbGUoZFsxXSk7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ3dpZHRoJywgX2JhcldpZHRoKVxuICAgICAgLnRyYW5zaXRpb24oKVxuICAgICAgLmR1cmF0aW9uKF9hbmltYXRpb25EdXJhdGlvbilcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCAoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICByZXR1cm4geVNjYWxlKGRbMV0gLSBkWzBdKTtcbiAgICAgIH0pO1xuICB9IGVsc2Uge1xuICAgICAgX3JlY3QuYXR0cigneCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgIHJldHVybiBfaW5pdFBvc1ggKyAoaSAqIF9jb2x1bW5XaWR0aCk7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ3knLCAoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICBjb25zdCBubSA9ICdkLmRhdGEuJyArIF9rZXlBcnJheVtpXTtcbiAgICAgICAgICBjb25zdCBfeVZhbHVlID0gZXZhbChubSk7XG4gICAgICAgICAgcmV0dXJuIHN2Z0hlaWdodCAtIGNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbSAtIHlTY2FsZShkWzFdKTtcbiAgICAgIH0pXG4gICAgICAuYXR0cignd2lkdGgnLCBfYmFyV2lkdGgpXG4gICAgICAuYXR0cignaGVpZ2h0JywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHlTY2FsZShkWzFdIC0gZFswXSk7XG4gICAgICB9KTtcbiAgfVxuXG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIHRoaXMuZHJhd1RpdGxlKGNkdCk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRBeGlzLS0tLS0tLS0tLS0tLS0tLS1cbiAgdGhpcy5idWlsZFlBeGlzKGNkdCk7XG5cbiAgdGhpcy5kcmF3WEJhc2VMaW5lKGNkdCk7XG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBkcmF3WEF4aXNMYWJlbC0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfbGFiZWxEaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGFiZWxBcnJheTogIEFycmF5PHN0cmluZz4gPSBuZXcgQXJyYXkoKTtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWUuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgX2xhYmVsQXJyYXkucHVzaChkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlW2ldLngpO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuZHJhd1hBeGlzTGFiZWwoY2R0LCBfbGFiZWxBcnJheSwgQ2hhcnRDb25zdC5TVEFDS19CQVJfQ0hBUlRfVFlQRV9OQU1FKTtcbiAgfVxuXG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBidWlsZExlZ2VuZC0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfbGVnZW5kRGlzcGxheSkge1xuICAgICAgY29uc3QgX2xlZ2VuZERhdGFTZXQ6IEFycmF5PE8yTGVnZW5kRGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgX2xlZ2VuZERhdGFTZXQucHVzaChuZXcgTzJMZWdlbmREYXRhKGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZSwgX2NvbG9yKGkpKSk7XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5idWlsZExlZ2VuZChjZHQsIF9sZWdlbmREYXRhU2V0KTtcbiAgfVxuXG4gIGlmIChfZ3JpZFlEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdZR3JpZChjZHQpO1xuICB9XG5cbn1cblxucHJpdmF0ZSBidWlsZFNjYXR0ZXJQbG90KHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ0luICBidWlsZFNjYXR0ZXJQbG90LS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IF9kYXRhU2V0OiBBcnJheTxPMlNjYXR0ZXJQbG90RGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgbGV0IF9tYXhYID0gMDtcbiAgbGV0IF9tYXhZID0gMDtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgZm9yIChjb25zdCBqIGluIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUpIHtcbiAgICAgICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUuaGFzT3duUHJvcGVydHkoaikpIHtcbiAgICAgICAgICAgICAgICAgIGlmIChfbWF4WCA8IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueCkge1xuICAgICAgICAgICAgICAgICAgICAgIF9tYXhYID0gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS54O1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgaWYgKF9tYXhZIDwgZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS55KSB7XG4gICAgICAgICAgICAgICAgICAgICAgX21heFkgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLnk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBjb25zdCBfc2NhdHRlclBsb3REYXRhID0gbmV3IE8yU2NhdHRlclBsb3REYXRhKFxuICAgICAgICAgICAgICAgICAgICAgIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueCxcbiAgICAgICAgICAgICAgICAgICAgICBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLnksXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS5yLFxuICAgICAgICAgICAgICAgICAgKSA7XG4gICAgICAgICAgICAgICAgICBfZGF0YVNldC5wdXNoKF9zY2F0dGVyUGxvdERhdGEpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgfVxuICB9XG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG5cbiAgY29uc3QgX2luaXRQb3NYID0gY2R0LmdyYXBoSW5pdFhQb3M7XG4gIGNvbnN0IF9pbml0UG9zWSA9IGNkdC5ncmFwaEluaXRZUG9zO1xuXG4gIGNvbnN0IF9zZXJpZXNOdW1iZXIgPSBkYXRhU2V0SnNvbi5zZXJpZXMubGVuZ3RoO1xuICBjb25zdCBfY29sb3IgPSBjZHQuZGVmYXVsdENvbG9yRnVuYztcbiAgY29uc3QgX29wYWNpdHkgPSBjb25maWdEYXRhLmNvbG9yLm9wYWNpdHk7XG4gIGNvbnN0IF9ncmlkWURpc3BsYXkgPSBjb25maWdEYXRhLmdyaWQueS5kaXNwbGF5O1xuICBjb25zdCBfZ3JpZFhEaXNwbGF5ID0gY29uZmlnRGF0YS5ncmlkLnguZGlzcGxheTtcbiAgY29uc3QgX3RpdGxlRGlzcGxheSA9IGNvbmZpZ0RhdGEudGl0bGUuZGlzcGxheTtcbiAgY29uc3QgX2xlZ2VuZERpc3BsYXkgPSBjb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5O1xuXG4gIGNvbnN0IF9jaXJjbGUgPSBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdjaXJjbGUnKVxuICAgICAgICAgIC5kYXRhKF9kYXRhU2V0KVxuICAgICAgICAgIC5lbnRlcigpXG4gICAgICAgICAgLmFwcGVuZCgnY2lyY2xlJylcbiAgICAgICAgICAuYXR0cignY3gnLCAoZDogTzJTY2F0dGVyUGxvdERhdGEsIGk6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiBfaW5pdFBvc1ggKyBkLng7XG4gICAgICAgICAgfSlcbiAgICAgICAgICAuYXR0cignY3knLCAoZDogTzJTY2F0dGVyUGxvdERhdGEsIGk6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiAoc3ZnSGVpZ2h0IC0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tIC0gZC55KTtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5hdHRyKCdyJywgKGQ6IE8yU2NhdHRlclBsb3REYXRhLCBpOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gZC5yO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICBjb25zdCBfY29sb3JOdW0gPSBpICUgX3Nlcmllc051bWJlcjtcbiAgICAgICAgICAgICAgcmV0dXJuIF9jb2xvcihfY29sb3JOdW0pO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmF0dHIoJ2ZpbGwtb3BhY2l0eScsICBfb3BhY2l0eSk7XG5cblxuICAvLyAtLS1DQUxMIGJ1aWxkVGl0bGUtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX3RpdGxlRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3VGl0bGUoY2R0KTtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF9sZWdlbmREaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhU2V0SnNvbi5zZXJpZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBfbGVnZW5kRGF0YVNldC5wdXNoKG5ldyBPMkxlZ2VuZERhdGEoZGF0YVNldEpzb24uc2VyaWVzW2ldLCBfY29sb3IoaSkpKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG4gIH1cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRBeGlzLS0tLS0tLS0tLS0tLS0tLS1cbiAgdGhpcy5idWlsZFlBeGlzKGNkdCk7XG5cbiAgdGhpcy5idWlsZFhBeGlzKGNkdCk7XG5cbiAgaWYgKF9ncmlkWURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1lHcmlkKGNkdCk7XG4gIH1cbiAgaWYgKF9ncmlkWERpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1hHcmlkKGNkdCk7XG4gIH1cbn1cblxuXG5cbnByaXZhdGUgZHJhd1hHcmlkKG8yQ29tbW9uOiBhbnkpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRYR3JpZC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3QgY29uZmlnRGF0YSA9IGNkdC5jb25maWdEYXRhO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIGNvbnN0IF9zdGVwWCA9ICBjZHQuZ3JpZFhTdGVwO1xuXG4gIGNvbnN0IF9tYXhYID0gY2R0Lm1heFhWYWx1ZTtcbiAgY29uc3QgX2dyYXBoWVNjYWxlID0gY2R0LmdyYXBoWVNjYWxlO1xuICBjb25zdCBfZ3JhcGhYU2NhbGUgPSBjZHQuZ3JhcGhYU2NhbGU7XG4gIGNvbnN0IF9ncmFwaFdpZHRoID0gY2R0LmdyYXBoV2lkdGg7XG4gIGNvbnN0IF9ncmlkQ2xhc3NOYW1lID0gY29uZmlnRGF0YS5jbGFzc05hbWUuZ3JpZDtcbiAgY29uc3QgX2F4aXNYU2NhbGUgPSBkMy5zY2FsZUxpbmVhcigpXG4gICAgICAgICAgICAgICAgICAuZG9tYWluKFswLCBfbWF4WF0pXG4gICAgICAgICAgICAgICAgICAucmFuZ2UoWzAsIF9tYXhYICogX2dyYXBoWFNjYWxlXSk7XG4gIGNvbnN0IF9yYW5nZVggPSBkMy5yYW5nZShfc3RlcFggKiBfZ3JhcGhYU2NhbGUsXG4gICAgICAgICAgICAgICAgICBfbWF4WCAgKiBfZ3JhcGhYU2NhbGUsXG4gICAgICAgICAgICAgICAgICBfc3RlcFggKiBfZ3JhcGhYU2NhbGUpO1xuXG4gIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgLnNlbGVjdEFsbCgnbGluZS54JylcbiAgICAgIC5kYXRhKF9yYW5nZVgpXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgnbGluZScpXG4gICAgICAuYXR0cignY2xhc3MnLCBfZ3JpZENsYXNzTmFtZSlcbiAgICAgIC5hdHRyKCd4MScsIChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICBjb25zdCBfeDEgPSBjb25maWdEYXRhLm1hcmdpbi5sZWZ0ICArIGQ7XG4gICAgICAgICAgcmV0dXJuIF94MTtcbiAgICAgIH0pXG4gICAgICAuYXR0cigneTEnLCBjZHQuc3ZnSGVpZ2h0IC0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tKVxuICAgICAgLmF0dHIoJ3gyJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgIGNvbnN0IF94MiA9IGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQgICsgZDtcbiAgICAgICAgICByZXR1cm4gX3gyO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCd5MicsIGNvbmZpZ0RhdGEubWFyZ2luLnRvcCArIGNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0KTtcbn1cblxucHJpdmF0ZSBidWlsZFhBeGlzKG8yQ29tbW9uOiBhbnkpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRYQXhpcy0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3QgY29uZmlnRGF0YSA9IGNkdC5jb25maWdEYXRhO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIGNvbnN0IF9tYXhYID0gY2R0Lm1heFhWYWx1ZTtcbiAgY29uc3QgX2dyYXBoWFNjYWxlID0gY2R0LmdyYXBoWFNjYWxlO1xuXG4gIGNvbnN0IF9heGlzWFNjYWxlID0gZDMuc2NhbGVMaW5lYXIoKVxuICAgICAgICAgICAgICAgICAgLmRvbWFpbihbMCwgX21heFhdKVxuICAgICAgICAgICAgICAgICAgLnJhbmdlKFswLCBfbWF4WCAqIF9ncmFwaFhTY2FsZV0pO1xuXG4gIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgY2R0LmF4aXNDbGFzc05hbWUpXG4gICAgICAuYXR0cigndHJhbnNmb3JtJywgY2R0LmF4aXNYQm9yZGVyVHJhbnNsYXRlUG9zKVxuICAgICAgLmNhbGwoXG4gICAgICAgICAgICBkMy5heGlzQm90dG9tKF9heGlzWFNjYWxlKVxuICAgICAgKTtcbiAgICAgICAgICAgIC8vICAuc2NhbGUoKVxuICAgICAgICAgICAgLy8gIC5vcmllbnQoY2R0LmF4aXNYT3JpZW50KVxuICAgICAgICAgICAgLy8gICk7XG59XG5cblxuXG5wcml2YXRlIGJ1aWxkUGllKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ0luICBidWlsZFBpZS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfbWF4WCA9IDEwMDtcbiAgY29uc3QgX21heFkgPSAxMDA7XG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG5cbiAgY29uc3QgX2NvbG9yID0gY2R0LmRlZmF1bHRDb2xvckZ1bmM7XG4gIGNvbnN0IF9pbml0UG9zWCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfaW5pdFBvc1kgPSBjZHQuZ3JhcGhJbml0WVBvcztcbiAgY29uc3QgX2dyYXBoSGVpZ2h0ID0gY2R0LmdyYXBoSGVpZ2h0O1xuICBjb25zdCBfZ3JhcGhXaWR0aCA9IGNkdC5ncmFwaFdpZHRoO1xuXG4gIGNvbnN0IF9vcGFjaXR5ID0gY29uZmlnRGF0YS5jb2xvci5vcGFjaXR5O1xuICBjb25zdCBfdGl0bGVIZWlnaHQgPSBjb25maWdEYXRhLnRpdGxlLmhlaWdodDtcbiAgY29uc3QgX2xlZnRNYXJnaW4gPSBjb25maWdEYXRhLm1hcmdpbi5sZWZ0O1xuICBjb25zdCBfdG9wTWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4udG9wO1xuICBjb25zdCBfYm90dG9tTWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tO1xuICBjb25zdCBfYmV0d2Vlbk1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLmJldHdlZW47XG4gIGNvbnN0IF9pbm5lclJhZGl1c1BlcmNlbnQgPSBjZHQuaW5uZXJSYWRpdXNQZXJjZW50O1xuICBjb25zdCBfZ3JhcGhDZW50ZXJUcmFuc2xhdGVQb3MgPSBjZHQuZ3JhcGhDZW50ZXJUcmFuc2xhdGVQb3M7XG4gIGNvbnN0IF9waWVDbGFzc05hbWUgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5waWU7XG4gIGNvbnN0IF9waWVWYWx1ZUNsYXNzTmFtZSA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLnBpZU51bTtcbiAgY29uc3QgX3BpZUlubmVyVGl0bGVDbGFzc05hbWUgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5waWVJbm5lclRpdGxlO1xuICBjb25zdCBfaW5uZXJSYWRpdXNUaXRsZVRyYW5zbGF0ZVBvcyA9IGNkdC5pbm5lclJhZGl1c1RpdGxlVHJhbnNsYXRlUG9zO1xuICBjb25zdCBfaW5uZXJSYWRpdXNUaXRsZSA9IGNkdC5pbm5lclJhZGl1c1RpdGxlO1xuICBjb25zdCBfdGl0bGVEaXNwbGF5ID0gY29uZmlnRGF0YS50aXRsZS5kaXNwbGF5O1xuICBjb25zdCBfbGVnZW5kRGlzcGxheSA9IGNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXk7XG4gIGNvbnN0IF9sYWJlbERpc3BsYXkgPSBjb25maWdEYXRhLmxhYmVsLmRpc3BsYXk7XG4gIGNvbnN0IF92YWx1ZURpc3BsYXkgPSBjb25maWdEYXRhLnBpZS52YWx1ZS5kaXNwbGF5O1xuICBjb25zdCBfcGVyY2VudERpc3BsYXkgPSBjb25maWdEYXRhLnBpZS5wZXJjZW50LmRpc3BsYXk7XG4gIGNvbnN0IF9hbmltYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5lbmFibGU7XG4gIGNvbnN0IF9hbmltYXRpb25EdXJhdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmR1cmF0aW9uO1xuXG4gIGNvbnN0IHdpZHRoID0gc3ZnV2lkdGg7XG4gIGNvbnN0IGhlaWdodCA9IHN2Z0hlaWdodDtcblxuICBjb25zdCBkYXRhU2V0OiBBcnJheTxudW1iZXI+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSAgaW4gIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgY29uc3QgX251bSA9IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWU7XG4gICAgICAgICAgZGF0YVNldC5wdXNoKF9udW0pO1xuICAgICAgfVxuICB9XG5cbiAgY29uc3QgX3N1bSA9IGQzLnN1bShkYXRhU2V0KTtcbiAgY29uc3QgcGllID0gZDMucGllKCk7XG4gIGNvbnN0IGFyYyA9IGQzLmFyYygpXG4gICAgICAgICAgICAgIC5pbm5lclJhZGl1cyhfZ3JhcGhIZWlnaHQgKiBfaW5uZXJSYWRpdXNQZXJjZW50IC8gMTAwKVxuICAgICAgICAgICAgICAub3V0ZXJSYWRpdXMoX2dyYXBoSGVpZ2h0IC8gMik7XG5cbiAgY29uc3QgcGllRWxlbWVudHMgPSBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdwYXRoJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmRhdGEocGllKGRhdGFTZXQpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAuZW50ZXIoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAuYXBwZW5kKCdnJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIF9ncmFwaENlbnRlclRyYW5zbGF0ZVBvcyk7XG5cblxuICBjb25zdCBfbWFrZUNlbnRlclRpdGxlID0gKCk6IHN0cmluZyA9PiB7XG4gICAgICAgICAgaWYgKF92YWx1ZURpc3BsYXkgJiYgX3BlcmNlbnREaXNwbGF5KSB7XG4gICAgICAgICAgICAgIGNvbnN0IF9zdCA9IF9pbm5lclJhZGl1c1RpdGxlICsgJzonICsgX3N1bSArICAnICgxMDAlKSc7XG4gICAgICAgICAgICAgIHJldHVybiBfc3Q7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChfcGVyY2VudERpc3BsYXkpIHtcbiAgICAgICAgICAgICAgcmV0dXJuICcxMDAlJztcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKF92YWx1ZURpc3BsYXkpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIF9pbm5lclJhZGl1c1RpdGxlICsgJzonICsgX3N1bTtcbiAgICAgICAgICB9XG4gIH07XG5cbiAgY29uc3QgdGV4dEVsZW1lbnRzID0gc3ZnQ29udGFpbmVyLmFwcGVuZCgndGV4dCcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIF9waWVJbm5lclRpdGxlQ2xhc3NOYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgX2lubmVyUmFkaXVzVGl0bGVUcmFuc2xhdGVQb3MgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAudGV4dChfbWFrZUNlbnRlclRpdGxlKTtcblxuICBjb25zdCBfYXJjID0gcGllRWxlbWVudHMuYXBwZW5kKCdwYXRoJylcbiAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgX3BpZUNsYXNzTmFtZSlcbiAgICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIF9jb2xvcihpKTtcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLmF0dHIoJ2ZpbGwtb3BhY2l0eScsIF9vcGFjaXR5KTtcblxuICAvLyAgRm9yIGQzVmVyc2lvbjQgYW5pbWF0aW9uIGlzIG5vdCBhdmFpbGFibGUgbm93XG4gIC8vICBpZiAoX2FuaW1hdGlvbikge1xuICAvLyAgICAgIF9hcmMudHJhbnNpdGlvbigpXG4gIC8vICAgICAgLmR1cmF0aW9uKF9hbmltYXRpb25EdXJhdGlvbilcbiAgLy8gICAgICAuZGVsYXkoKGQsaSk9PiB7XG4gIC8vICAgICAgICAgIHJldHVybiBpICoxMDAwO1xuICAvLyAgICAgIH0pXG4gIC8vICAgICAgLmF0dHJUd2VlbignZCcsKGQ6IGFueSxpOiBudW1iZXIpID0+ICB7XG4gIC8vICAgICAgICAgIGNvbnN0IF9pbnRlcnBvbGF0ZSA9IGQzLmludGVycG9sYXRlT2JqZWN0KFxuICAvLyAgICAgICAgICAgICAgeyBzdGFydEFuZ2xlOmQuc3RhcnRBbmdsZSxlbmRBbmdsZTpkLnN0YXJ0QW5nbGUgfVxuICAvLyAgICAgICAgICAgICAgeyBzdGFydEFuZ2xlOmQuc3RhcnRBbmdsZSxlbmRBbmdsZTpkLmVuZEFuZ2xlIH1cbiAgLy8gICAgICAgICAgKVxuICAvLyAgICAgICAgICByZXR1cm4gKHQpIHtcbiAgLy8gICAgICAgICAgICAgIHJldHVybiBhcmMoX2ludGVycG9sYXRlKHQpKTtcbiAgLy8gICAgICAgICAgfVxuICAvLyAgICAgIH0pXG4gIC8vICB9XG4gIC8vICBlbHNle1xuICAvLyAgICAgIF9hcmMuYXR0cignZCcsYXJjKTtcbiAgLy8gIH1cbiAgX2FyYy5hdHRyKCdkJywgYXJjKTtcblxuICBwaWVFbGVtZW50cy5hcHBlbmQoJ3RleHQnKVxuICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCBfcGllVmFsdWVDbGFzc05hbWUpXG4gICAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIGFyYy5jZW50cm9pZChkKSArICcpJztcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLnRleHQoKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgICAgICAgICBpZiAoX3ZhbHVlRGlzcGxheSAmJiBfcGVyY2VudERpc3BsYXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBfcGVyY2VudFN0ID0gU3RyaW5nKE1hdGguY2VpbChkLnZhbHVlIC8gX3N1bSAgKiAxMDApKTtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBfc3QgPSBTdHJpbmcoZC52YWx1ZSkgKyAnICgnICsgX3BlcmNlbnRTdCArICclKSc7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9zdDtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGlmIChfcGVyY2VudERpc3BsYXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBfcGVyY2VudFN0ID0gU3RyaW5nKE1hdGguY2VpbChkLnZhbHVlIC8gX3N1bSAgKiAxMDApKTtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBfc3QgPSBfcGVyY2VudFN0ICsgJyUnO1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfc3Q7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBpZiAoX3ZhbHVlRGlzcGxheSkge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBkLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KTtcblxuICAvLyAtLS1DQUxMIGJ1aWxkVGl0bGUtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX3RpdGxlRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3VGl0bGUoY2R0KTtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF9sZWdlbmREaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICAgICAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICBfbGVnZW5kRGF0YVNldC5wdXNoKG5ldyBPMkxlZ2VuZERhdGEoZGF0YVNldEpzb24uZGF0YVtpXS5uYW1lLCBfY29sb3IoaSkpKTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLmJ1aWxkTGVnZW5kKGNkdCwgX2xlZ2VuZERhdGFTZXQpO1xuICB9XG59XG5cblxuXG5wcml2YXRlIGJ1aWxkQmFyKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ0luICBidWlsZEJhci0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfeURhdGFTZXQ6IEFycmF5PG51bWJlcj4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgZm9yIChjb25zdCBqIGluIGRhdGFTZXRKc29uLmRhdGFbaV0ueSkge1xuICAgICAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YVtpXS55Lmhhc093blByb3BlcnR5KGopKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBfeSA9IGRhdGFTZXRKc29uLmRhdGFbaV0ueVtqXTtcbiAgICAgICAgICAgICAgICAgIF95RGF0YVNldC5wdXNoKF95KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgIH1cbiAgfVxuXG4gIGxldCBfbWF4WCA9IDA7XG4gIGxldCBfbWF4WSA9IDA7XG4gIF9tYXhZID0gZDMubWF4KF95RGF0YVNldCk7XG4gIF9tYXhYID0gMTAwO1xuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuXG4gIGNvbnN0IF9iYXJWYWx1ZUNsYXNzID0gY29uZmlnRGF0YS5jbGFzc05hbWUuYmFyVmFsdWU7XG4gIGNvbnN0IF9jb2xvciA9IGNkdC5kZWZhdWx0Q29sb3JGdW5jO1xuICBjb25zdCBfc2VyaWVzTnVtID0gIGRhdGFTZXRKc29uLnNlcmllcy5sZW5ndGg7XG4gIGNvbnN0IF9jb2x1bW5OdW0gPSAgX3lEYXRhU2V0Lmxlbmd0aDtcbiAgY29uc3QgX2luaXRQb3NYID0gY2R0LmdyYXBoSW5pdFhQb3M7XG4gIGNvbnN0IF9pbml0UG9zWSA9IGNkdC5ncmFwaEluaXRZUG9zO1xuICBjb25zdCBfZ3JhcGhIZWlnaHQgPSBjZHQuZ3JhcGhIZWlnaHQ7XG4gIGNvbnN0IF9ncmFwaFdpZHRoID0gY2R0LmdyYXBoV2lkdGg7XG4gIGNvbnN0IF9tYXhZVmFsdWUgPSBjZHQubWF4WVZhbHVlO1xuICBjb25zdCBfb3BhY2l0eSA9IGNvbmZpZ0RhdGEuY29sb3Iub3BhY2l0eTtcbiAgY29uc3QgX3RpdGxlSGVpZ2h0ID0gY29uZmlnRGF0YS50aXRsZS5oZWlnaHQ7XG4gIGNvbnN0IF90aXRsZURpc3BsYXkgPSBjb25maWdEYXRhLnRpdGxlLmRpc3BsYXk7XG4gIGNvbnN0IF9sZWZ0TWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4ubGVmdDtcbiAgY29uc3QgX3RvcE1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLnRvcDtcbiAgY29uc3QgX2JvdHRvbU1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbTtcbiAgY29uc3QgX2JldHdlZW5NYXJnaW4gPSBjb25maWdEYXRhLm1hcmdpbi5iZXR3ZWVuO1xuICBjb25zdCBfbGVnZW5kRGlzcGxheSA9IGNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXk7XG4gIGNvbnN0IF9sYWJlbERpc3BsYXkgPSBjb25maWdEYXRhLmxhYmVsLmRpc3BsYXk7XG4gIGNvbnN0IF9ncmlkWURpc3BsYXkgPSBjb25maWdEYXRhLmdyaWQueS5kaXNwbGF5O1xuICBjb25zdCBfYW5pbWF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZW5hYmxlO1xuICBjb25zdCBfYW5pbWF0aW9uRHVyYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5kdXJhdGlvbjtcblxuICBjb25zdCBfYmFyV2lkdGggPSAoX2dyYXBoV2lkdGggLSAoX2JldHdlZW5NYXJnaW4gKiBfY29sdW1uTnVtIC8gX3Nlcmllc051bSkpIC8gIF9jb2x1bW5OdW07XG4gIGNvbnN0IF9jb2x1bW5XaWR0aCA9IChfZ3JhcGhXaWR0aCAvIF9jb2x1bW5OdW0pIDtcblxuICBjb25zdCBfZ3JhcGhZU2NhbGUgPSBjZHQuZ3JhcGhZU2NhbGU7XG5cbiAgY29uc3QgeUJhclNjYWxlID0gZDMuc2NhbGVMaW5lYXIoKVxuICAgICAgICAgICAgICAgICAgLmRvbWFpbihbMCwgX21heFldKVxuICAgICAgICAgICAgICAgICAgLnJhbmdlKFtfbWF4WSAqIF9ncmFwaFlTY2FsZSwgMF0pO1xuXG4gIGNvbnN0IF9iYXJQYWRkaW5nID0gX2JldHdlZW5NYXJnaW47XG5cblxuXG5cbiAgY29uc3QgZ3JwR3JhcGggPSBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdnJylcbiAgICAgIC5kYXRhKF95RGF0YVNldClcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZDogYW55LCBpOiBudW1iZXIpOiBzdHJpbmcgPT4ge1xuICAgICAgICAgIGNvbnN0IF9wYWRkaW5nID0gKChpICUgX3Nlcmllc051bSkgPT09IDApID8gX2JhclBhZGRpbmcgOiAwO1xuICAgICAgICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyAoX3BhZGRpbmcgKyBfY29sdW1uV2lkdGggKiBpKSArICcpJztcbiAgICAgIH0pXG4gICAgICAuc3R5bGUoJ2ZpbGwnLCAoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgY29uc3QgX3JlbW5hbnQgPSAoaSAlIF9zZXJpZXNOdW0pO1xuICAgICAgICAgIHJldHVybiBfY29sb3IoX3JlbW5hbnQpO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCdmaWxsLW9wYWNpdHknLCBfb3BhY2l0eSk7XG5cbiAgY29uc3QgX3JlY3QgPSAgZ3JwR3JhcGguYXBwZW5kKCdyZWN0Jyk7XG4gIGlmIChfYW5pbWF0aW9uKSB7XG4gICAgICBfcmVjdC5hdHRyKCd4JywgX2xlZnRNYXJnaW4pXG4gICAgICAuYXR0cignaGVpZ2h0JywgMClcbiAgICAgIC5hdHRyKCd5JywgKGQ6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgICAgcmV0dXJuIF9pbml0UG9zWTtcbiAgICAgIH0pXG4gICAgICAuYXR0cignd2lkdGgnLCBfYmFyV2lkdGggLSBfYmFyUGFkZGluZylcbiAgICAgIC50cmFuc2l0aW9uKClcbiAgICAgIC5kdXJhdGlvbihfYW5pbWF0aW9uRHVyYXRpb24pXG4gICAgICAuYXR0cigneScsIChkOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICAgIHJldHVybiB5QmFyU2NhbGUoZCkgKyBfaW5pdFBvc1k7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ2hlaWdodCcsIChkOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICAgIHJldHVybiBfZ3JhcGhIZWlnaHQgLSB5QmFyU2NhbGUoZCkgO1xuICAgICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgICBfcmVjdC5hdHRyKCd4JywgX2xlZnRNYXJnaW4pXG4gICAgICAuYXR0cigneScsIChkOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICAgIHJldHVybiB5QmFyU2NhbGUoZCkgKyBfaW5pdFBvc1k7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ3dpZHRoJywgX2JhcldpZHRoIC0gX2JhclBhZGRpbmcpXG4gICAgICAuYXR0cignaGVpZ2h0JywgKGQ6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgICAgcmV0dXJuIF9ncmFwaEhlaWdodCAtIHlCYXJTY2FsZShkKTtcbiAgICAgIH0pO1xuICB9XG5cbiAgY29uc3QgdGV4dEJhclZhbHVlID0gZ3JwR3JhcGguYXBwZW5kKCd0ZXh0Jyk7XG4gIHRleHRCYXJWYWx1ZVxuICAgICAgLmF0dHIoJ2NsYXNzJywgX2JhclZhbHVlQ2xhc3MpXG4gICAgICAuYXR0cigneCcsIF9sZWZ0TWFyZ2luKVxuICAgICAgLmF0dHIoJ3knLCAoZDogYW55KTogbnVtYmVyID0+IHtcbiAgICAgICAgcmV0dXJuIHlCYXJTY2FsZShkKSArIF9pbml0UG9zWTtcbiAgICAgIH0pXG4gICAgICAudGV4dCgoZDogYW55KTogc3RyaW5nID0+IHtcbiAgICAgICAgcmV0dXJuIGQgO1xuICAgICAgfSk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRBeGlzLS0tLS0tLS0tLS0tLS0tLS1cbiAgdGhpcy5idWlsZFlBeGlzKGNkdCk7XG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBkcmF3WEF4aXNMYWJlbC0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfbGFiZWxEaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGFiZWxBcnJheTogIEFycmF5PHN0cmluZz4gPSBuZXcgQXJyYXkoKTtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgX2xhYmVsQXJyYXkucHVzaChkYXRhU2V0SnNvbi5kYXRhW2ldLngpO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuZHJhd1hBeGlzTGFiZWwoY2R0LCBfbGFiZWxBcnJheSwgQ2hhcnRDb25zdC5CQVJfQ0hBUlRfVFlQRV9OQU1FKTtcbiAgfVxuXG4gIHRoaXMuZHJhd1hCYXNlTGluZShjZHQpO1xuXG4gIC8vICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gIC0tLUNBTEwgYnVpbGRMZWdlbmQtLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uc2VyaWVzKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uc2VyaWVzLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShkYXRhU2V0SnNvbi5zZXJpZXNbaV0sIF9jb2xvcihpKSkpO1xuICAgICAgfVxuICB9XG4gIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfdGl0bGVEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdUaXRsZShjZHQpO1xuICB9XG5cbiAgaWYgKF9ncmlkWURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1lHcmlkKGNkdCk7XG4gIH1cblxufVxuXG5cbnByaXZhdGUgYnVpbGRMaW5lKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkVGVzdC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfZ3JvdXBNYXhZOiBBcnJheTxudW1iZXI+ID0gbmV3IEFycmF5KCk7XG5cbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgbGV0IF9nTWF4WSA9IDA7XG4gICAgICAgICAgZm9yIChjb25zdCBqIGluIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUpIHtcbiAgICAgICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUuaGFzT3duUHJvcGVydHkoaikpIHtcbiAgICAgICAgICAgICAgICAgIGlmIChfZ01heFkgPCBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLnkpIHtcbiAgICAgICAgICAgICAgICAgICAgICBfZ01heFkgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLnk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgX2dyb3VwTWF4WS5wdXNoKF9nTWF4WSkgO1xuICAgICAgfVxuICB9XG4gIGxldCBfbWF4WCA9IDA7XG4gIGxldCBfbWF4WSA9IDA7XG4gIF9tYXhZID0gZDMubWF4KF9ncm91cE1heFkpO1xuICBfbWF4WCA9IDEwMDtcblxuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuICBjb25zdCBfY29sb3IgPSBjZHQuZGVmYXVsdENvbG9yRnVuYztcblxuICBjb25zdCBfY29sdW1uTnVtID0gZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZS5sZW5ndGggO1xuICBjb25zdCBfY29sdW1uV2lkdGggPSBjZHQuZ3JhcGhXaWR0aCAvIF9jb2x1bW5OdW07XG5cbiAgY29uc29sZS5sb2coX2NvbHVtbldpZHRoKTtcblxuICBpZiAoY29uZmlnRGF0YS5ncmlkLnkuZGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3WUdyaWQoY2R0KTtcbiAgfVxuXG4gIC8vICBPMklkVmFsdWVEYXRhXG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGNvbnN0IF9saW5lQXJyYXk6IEFycmF5PE8ySWRWYWx1ZURhdGE+ID0gbmV3IEFycmF5KCk7XG4gICAgICAgICAgZm9yIChjb25zdCBqIGluIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUpIHtcbiAgICAgICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUuaGFzT3duUHJvcGVydHkoaikpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlkVmFsdWUgPSBuZXcgTzJJZFZhbHVlRGF0YShwYXJzZUludChqLCAxMCksIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueSk7XG4gICAgICAgICAgICAgICAgICBfbGluZUFycmF5LnB1c2goaWRWYWx1ZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgbnVtID0gcGFyc2VJbnQoaSwgMTApO1xuICAgICAgICAgIHRoaXMuZHJhd1NpbmdsZUxpbmUoY2R0LCBfbGluZUFycmF5LCBudW0pO1xuICAgICAgfVxuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIHRoaXMuZHJhd1RpdGxlKGNkdCk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRBeGlzLS0tLS0tLS0tLS0tLS0tLS1cbiAgdGhpcy5idWlsZFlBeGlzKGNkdCk7XG5cbiAgdGhpcy5kcmF3WEJhc2VMaW5lKGNkdCk7XG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBkcmF3WEF4aXNMYWJlbC0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0IF9sYWJlbEFycmF5OiAgQXJyYXk8c3RyaW5nPiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWUuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBfbGFiZWxBcnJheS5wdXNoKGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWVbaV0ueCk7XG4gICAgICB9XG4gIH1cbiAgdGhpcy5kcmF3WEF4aXNMYWJlbChjZHQsIF9sYWJlbEFycmF5LCBDaGFydENvbnN0LkxJTkVfQ0hBUlRfVFlQRV9OQU1FKTtcblxuICAvLyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vICAtLS1DQUxMIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3QgX2xlZ2VuZERhdGFTZXQ6IEFycmF5PE8yTGVnZW5kRGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWUsIF9jb2xvcihpKSkpO1xuICAgICAgfVxuICB9XG4gIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG5cbn1cblxuXG5cblxucHJpdmF0ZSBkcmF3U2luZ2xlTGluZShvMkNvbW1vbjogYW55LCBkYXRhU2V0OiBhbnksIGxpbmVOdW06IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBkcmF3U2luZ2xlTGluZS0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zb2xlLmxvZyhkYXRhU2V0KTtcbiAgY29uc3QgY2R0ID0gbzJDb21tb247XG4gIGNvbnN0IGNvbmZpZ0RhdGEgPSBjZHQuY29uZmlnRGF0YTtcbiAgY29uc3Qgc3ZnQ29udGFpbmVyID0gY2R0LnN2Z0NvbnRhaW5lcjtcblxuICBjb25zdCBfbWF4WCA9IGNkdC5tYXhYVmFsdWU7XG4gIGNvbnN0IF9pbml0WFBvcyA9IGNkdC5heGlzWExhYmVsSW5pdFhQb3M7XG4gIGNvbnN0IF9pbml0WVBvcyA9IGNkdC5heGlzWExhYmVsSW5pdFlQb3M7XG4gIGNvbnN0IF9jb2x1bW5OdW0gPSBkYXRhU2V0Lmxlbmd0aDtcbiAgY29uc3QgX2NvbHVtbldpZHRoID0gY2R0LmdyYXBoV2lkdGggLyAoX2NvbHVtbk51bSAtIDEpO1xuICBjb25zdCBfY29sb3IgPSBkMy5zY2FsZU9yZGluYWwoZDMuc2NoZW1lQ2F0ZWdvcnkxMCk7XG5cbiAgY29uc3QgX2xpbmVDbGFzc05hbWUgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5tdWx0aUxpbmVQcmVmaXggKyBTdHJpbmcobGluZU51bSk7XG4gIGNvbnN0IF9sZWZ0TWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4ubGVmdDtcbiAgY29uc3QgX2JvdHRvbU1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbTtcblxuICBjb25zdCBfeVNjYWxlID0gY2R0LmdyYXBoWVNjYWxlO1xuXG5cbiAgY29uc3QgbGluZSA9IGQzLmxpbmUoKVxuICAgICAgLmN1cnZlKGQzLmN1cnZlTGluZWFyKVxuICAgICAgLngoIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gX2xlZnRNYXJnaW4gKyBkLmlkICogX2NvbHVtbldpZHRoO1xuICAgICAgfSlcbiAgICAgIC55KCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGNkdC5zdmdIZWlnaHQgLSBfYm90dG9tTWFyZ2luIC0gKCBkLnZhbHVlICogX3lTY2FsZSkgO1xuICAgICAgfSk7XG5cbiAgc3ZnQ29udGFpbmVyLmFwcGVuZCgncGF0aCcpXG4gICAgICAgICAgLmF0dHIoJ2NsYXNzJywgX2xpbmVDbGFzc05hbWUpXG4gICAgICAgICAgLmF0dHIoJ2QnLCBsaW5lKGRhdGFTZXQpKTtcbiAgICAgICAgICAvLyAgLmF0dHIoJ3RyYW5zZm9ybScsIGNkdC5heGlzVHJhbnNsYXRlUG9zKVxufVxuXG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gLS0tQnVpbGQgTGVnZW5kICAtLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbnByaXZhdGUgYnVpbGRMZWdlbmQobzJDb21tb246IGFueSwgX2xlZ2VuZERhdGFTZXQ6IGFueSk6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZExlZ2VuZC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICAvLyAgbWF4VmFsdWVzIGFyZSBtZWFuaW5nbGVzc1xuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3QgY29uZmlnRGF0YSA9IGNkdC5jb25maWdEYXRhO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuICAvLyAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKGNvbmZpZ0RhdGEsIDEwMCwgMTAwLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcbiAgY29uc3QgbGVnZW5kUmVjdFNpemUgPSBjb25maWdEYXRhLmxlZ2VuZC5yZWN0V2lkdGg7XG4gIGNvbnN0IGxlZ2VuZFNwYWNpbmcgPSAxMDtcbiAgY29uc3QgeVNwYWNpbmcgPSBjb25maWdEYXRhLmxlZ2VuZC55U3BhY2luZztcbiAgY29uc3QgaW5pdFBvc1ggPSBjZHQubGVnZW5kSW5pdFhQb3M7XG4gIGNvbnN0IGluaXRQb3NZID0gY2R0LmxlZ2VuZEluaXRZUG9zO1xuICBjb25zdCBvcGFjaXR5ID0gY29uZmlnRGF0YS5jb2xvci5vcGFjaXR5O1xuXG4gIGNvbnN0IGdycExlZ2VuZCA9IHN2Z0NvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgICAgICAgICAuc2VsZWN0QWxsKCdnJylcbiAgICAgICAgICAgICAgLmRhdGEoX2xlZ2VuZERhdGFTZXQpXG4gICAgICAgICAgICAgIC5lbnRlcigpXG4gICAgICAgICAgICAgIC5hcHBlbmQoJ2cnKVxuICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCAnbGVnZW5kJylcbiAgICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIChkOiBPMkxlZ2VuZERhdGEsIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgaGVpZ2h0ID0gbGVnZW5kUmVjdFNpemUgKyB5U3BhY2luZztcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHggPSBpbml0UG9zWDtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHkgPSBpICogaGVpZ2h0ICsgaW5pdFBvc1kgO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIHggKyAnLCAnICsgeSArICcpJztcbiAgICAgICAgICAgICAgfSk7XG5cbiAgZ3JwTGVnZW5kLmFwcGVuZCgncmVjdCcpXG4gICAgICAuYXR0cignd2lkdGgnLCBsZWdlbmRSZWN0U2l6ZSlcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCBsZWdlbmRSZWN0U2l6ZSlcbiAgICAgIC5zdHlsZSgnZmlsbCcsIChkOiBPMkxlZ2VuZERhdGEpID0+IHtcbiAgICAgICAgICByZXR1cm4gZC5jb2xvcjtcbiAgICAgIH0pXG4gICAgICAuc3R5bGUoJ3N0cm9rZScsIChkOiBPMkxlZ2VuZERhdGEpID0+IHtcbiAgICAgICAgICByZXR1cm4gZC5jb2xvcjtcbiAgICAgIH0pXG4gICAgICAuYXR0cignZmlsbC1vcGFjaXR5Jywgb3BhY2l0eSk7XG5cbiAgZ3JwTGVnZW5kLmFwcGVuZCgndGV4dCcpXG4gICAgICAuYXR0cigneCcsIGxlZ2VuZFJlY3RTaXplICsgbGVnZW5kU3BhY2luZylcbiAgICAgIC5hdHRyKCd5JywgbGVnZW5kUmVjdFNpemUpXG4gICAgICAudGV4dCgoZDogTzJMZWdlbmREYXRhKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGQudGl0bGU7XG4gICAgICB9KTtcbn1cblxuXG5wcml2YXRlIGRyYXdYQXhpc0xhYmVsKG8yQ29tbW9uOiBhbnksIGxhYmVsRGF0YVNldDogYW55LCBjaGFydFR5cGU6IHN0cmluZyk6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBkcmF3WEF4aXNMYWJlbC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3QgY29uZmlnRGF0YSA9IGNkdC5jb25maWdEYXRhO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIC8vIGNvbnN0IF9tYXhYID0gY2R0Lm1heFhWYWx1ZTtcbiAgY29uc3QgX2luaXRYUG9zID0gY2R0LmF4aXNYTGFiZWxJbml0WFBvcztcbiAgY29uc3QgX2luaXRZUG9zID0gY2R0LmF4aXNYTGFiZWxJbml0WVBvcztcblxuICBjb25zdCBfY29sdW1uTnVtID0gbGFiZWxEYXRhU2V0Lmxlbmd0aDtcbiAgbGV0IF9jb2x1bW5XaWR0aCA9IGNkdC5ncmFwaFdpZHRoIC8gX2NvbHVtbk51bTtcbiAgaWYgKCBjaGFydFR5cGUgPT09IENoYXJ0Q29uc3QuTElORV9DSEFSVF9UWVBFX05BTUUpIHtcbiAgICAgIF9jb2x1bW5XaWR0aCA9IGNkdC5ncmFwaFdpZHRoIC8gKF9jb2x1bW5OdW0gLSAxKTtcbiAgfVxuXG4gIGNvbnN0IGdycExhYmVsID0gc3ZnQ29udGFpbmVyLmFwcGVuZCgnZycpXG4gICAgICAgICAgICAgIC5zZWxlY3RBbGwoJ2cnKVxuICAgICAgICAgICAgICAuZGF0YShsYWJlbERhdGFTZXQpXG4gICAgICAgICAgICAgIC5lbnRlcigpXG4gICAgICAgICAgICAgIC5hcHBlbmQoJ2cnKVxuICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCBjb25maWdEYXRhLmF4aXNYVGV4dClcbiAgICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX3ggPSBfaW5pdFhQb3MgKyBfY29sdW1uV2lkdGggKiBpO1xuICAgICAgICAgICAgICAgICAgY29uc3QgX3kgPSBfaW5pdFlQb3MgO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIF94ICsgJywgJyArIF95ICsgJyknO1xuICAgICAgICAgICAgICB9KTtcblxuICBncnBMYWJlbC5hcHBlbmQoJ3RleHQnKVxuICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCBjb25maWdEYXRhLmNsYXNzTmFtZS5heGlzWFRleHQpXG4gICAgICAgICAgICAgIC50ZXh0KChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGQ7XG4gICAgICAgICAgICAgIH0pO1xuXG5cbn1cblxuXG5wcml2YXRlIGRyYXdYQmFzZUxpbmUobzJDb21tb246IGFueSk6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBkcmF3WEJhc2VMaW5lLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IGNkdCA9IG8yQ29tbW9uO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ3JlY3QnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgY2R0LmF4aXNYQm9yZGVyTGluZUNsYXNzTmFtZSlcbiAgICAgIC5hdHRyKCd3aWR0aCcsIGNkdC5heGlzWEJvcmRlcldpZHRoKVxuICAgICAgLmF0dHIoJ2hlaWdodCcsIGNkdC5heGlzWEJvcmRlckxpbmVXaWR0aClcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBjZHQuYXhpc1hCb3JkZXJUcmFuc2xhdGVQb3MpO1xuXG59XG5cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS1CdWlsZCBBeGlzICAtLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbnByaXZhdGUgYnVpbGRZQXhpcyhvMkNvbW1vbjogYW55KTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkWUF4aXMtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgY2R0ID0gbzJDb21tb247XG4gIGNvbnN0IHN2Z0NvbnRhaW5lciA9IGNkdC5zdmdDb250YWluZXI7XG5cbiAgY29uc3QgX21heFkgPSBjZHQubWF4WVZhbHVlO1xuICBjb25zdCBfZ3JhcGhZU2NhbGUgPSBjZHQuZ3JhcGhZU2NhbGU7XG5cbiAgY29uc3QgX2F4aXNZU2NhbGUgPSBkMy5zY2FsZUxpbmVhcigpXG4gICAgICAgICAgICAgICAgICAuZG9tYWluKFswLCBfbWF4WV0pXG4gICAgICAgICAgICAgICAgICAucmFuZ2UoW19tYXhZICogX2dyYXBoWVNjYWxlLCAwXSk7XG5cbiAgc3ZnQ29udGFpbmVyLmFwcGVuZCgnZycpXG4gICAgICAuYXR0cignY2xhc3MnLCBjZHQuYXhpc0NsYXNzTmFtZSlcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBjZHQuYXhpc1RyYW5zbGF0ZVBvcylcbiAgICAgIC5jYWxsKFxuICAgICAgICAgICAgZDMuYXhpc0xlZnQoX2F4aXNZU2NhbGUpXG4gICAgICAgICAgICApO1xuXG59XG5cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0gZHJhd1RpdGxlLS0tLS0tLS0tLS0tLS0tLS1cbnByaXZhdGUgZHJhd1RpdGxlKG8yQ29tbW9uOiBhbnkpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gZHJhd1RpdGxlLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IGNkdCA9IG8yQ29tbW9uO1xuICBjb25zdCBjb25maWdEYXRhID0gY2R0LmNvbmZpZ0RhdGE7XG4gIGNvbnN0IHN2Z0NvbnRhaW5lciA9IGNkdC5zdmdDb250YWluZXI7XG5cbiAgY29uc3QgX3RpdGxlID0gY29uZmlnRGF0YS50aXRsZS5uYW1lO1xuICBjb25zdCBfeFBvcyA9IGNkdC50aXRsZUluaXRYUG9zO1xuICBjb25zdCBfeVBvcyA9IGNkdC50aXRsZUluaXRZUG9zO1xuICBjb25zdCBfdGl0bGVDbGFzc05hbWUgPSBjb25maWdEYXRhLnRpdGxlLmNsYXNzTmFtZTtcblxuICBzdmdDb250YWluZXIuYXBwZW5kKCd0ZXh0JylcbiAgICAgIC5hdHRyKCdjbGFzcycsIF90aXRsZUNsYXNzTmFtZSlcbiAgICAgIC5hdHRyKCd4JywgX3hQb3MpXG4gICAgICAuYXR0cigneScsIF95UG9zKVxuICAgICAgLnRleHQoX3RpdGxlKTtcbn1cblxuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIC0tLWRyYXdHcmlkICAtLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbnByaXZhdGUgZHJhd1lHcmlkKG8yQ29tbW9uOiBhbnkpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRZR3JpZC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3QgY29uZmlnRGF0YSA9IGNkdC5jb25maWdEYXRhO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIGNvbnN0IF9zdGVwWSA9ICBjZHQuZ3JpZFlTdGVwO1xuICBjb25zdCBfbWF4WSA9IGNkdC5tYXhZVmFsdWU7XG4gIGNvbnN0IF9ncmFwaFlTY2FsZSA9IGNkdC5ncmFwaFlTY2FsZTtcbiAgY29uc3QgX2dyaWRDbGFzc05hbWUgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5ncmlkO1xuICBjb25zdCBfcmFuZ2VZID0gZDMucmFuZ2UoX3N0ZXBZICogX2dyYXBoWVNjYWxlLFxuICAgICAgICAgICAgICAgICAgX21heFkgKiBfZ3JhcGhZU2NhbGUsXG4gICAgICAgICAgICAgICAgICBfc3RlcFkgKiBfZ3JhcGhZU2NhbGUpO1xuXG4gIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgLnNlbGVjdEFsbCgnbGluZS55JylcbiAgICAgIC5kYXRhKF9yYW5nZVkpXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgnbGluZScpXG4gICAgICAuYXR0cignY2xhc3MnLCBfZ3JpZENsYXNzTmFtZSlcbiAgICAgIC5hdHRyKCd4MScsIGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQpXG4gICAgICAuYXR0cigneTEnLCAoIGQ6IGFueSwgaTogbnVtYmVyICkgPT4gIHtcbiAgICAgICAgICBjb25zdCBfeTEgPSBjZHQuc3ZnSGVpZ2h0IC0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tIC0gZDtcbiAgICAgICAgICByZXR1cm4gX3kxO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCd4MicsIGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQgKyBjZHQuYXhpc1hCb3JkZXJXaWR0aClcbiAgICAgIC5hdHRyKCd5MicsICggZDogYW55LCBpOiBudW1iZXIgKSA9PiAge1xuICAgICAgICAgIGNvbnN0IF95MSA9IGNkdC5zdmdIZWlnaHQgLSBjb25maWdEYXRhLm1hcmdpbi5ib3R0b20gLSBkO1xuICAgICAgICAgIHJldHVybiBfeTE7XG4gICAgICB9KTtcbiAgfVxufSIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOZzZPMkNoYXJ0Q29tcG9uZW50IH0gZnJvbSAnLi9uZzYtbzItY2hhcnQuY29tcG9uZW50JztcblxuQE5nTW9kdWxlKHtcbiAgaW1wb3J0czogW1xuICBdLFxuICBkZWNsYXJhdGlvbnM6IFtOZzZPMkNoYXJ0Q29tcG9uZW50XSxcbiAgZXhwb3J0czogW05nNk8yQ2hhcnRDb21wb25lbnRdXG59KVxuZXhwb3J0IGNsYXNzIE5nNk8yQ2hhcnRNb2R1bGUgeyB9XG4iXSwibmFtZXMiOlsiZDMuc2NhbGVPcmRpbmFsIiwiZDMuc2NoZW1lQ2F0ZWdvcnkyMCIsImQzLnNjaGVtZUNhdGVnb3J5MTAiLCJkMy5zZWxlY3QiLCJDaGFydENvbnN0LkxJTkVfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5CQVJfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5QSUVfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5TQ0FUVEVSX1BMT1RfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5ISVNUT0dSQU1fQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5TVEFDS19CQVJfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5HRU9fTUFQX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuR0VPX09SVEhPR1JBUEhJQ19DSEFSVF9UWVBFX05BTUUiLCJDaGFydENvbnN0LlRSRUVfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5QQUNLX0xBWU9VVF9DSEFSVF9UWVBFX05BTUUiLCJDaGFydENvbnN0LkNIT1JPUExFVEhfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5GT1JDRV9DSEFSVF9UWVBFX05BTUUiLCJDaGFydENvbnN0LlRSRUVfTUFQX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuU0FOS0VZX0NIQVJUX1RZUEVfTkFNRSIsImQzLmZvcm1hdCIsImQzLnNjYWxlTGluZWFyIiwiZDMuaGlzdG9ncmFtIiwiZDMubWF4IiwiZDMuZm9yY2VTaW11bGF0aW9uIiwiZDMuZm9yY2VMaW5rIiwiZDMuZm9yY2VNYW55Qm9keSIsImQzLmZvcmNlQ2VudGVyIiwiZDMuZHJhZyIsImQzLmV2ZW50IiwiZDMuaW50ZXJwb2xhdGVIc2wiLCJkMy5nZW9QYXRoIiwiZDMuZ2VvTWVyY2F0b3IiLCJkMy5qc29uIiwiZDMucGFjayIsImQzLmhpZXJhcmNoeSIsInBhY2siLCJ0cmVlIiwiZDMudHJlZSIsImQzLmdlb09ydGhvZ3JhcGhpYyIsImQzLnRpbWVyIiwic3RhY2siLCJkMy5zdGFjayIsImQzLnJhbmdlIiwiZDMuYXhpc0JvdHRvbSIsImQzLnN1bSIsInBpZSIsImQzLnBpZSIsImFyYyIsImQzLmFyYyIsImxpbmUiLCJkMy5saW5lIiwiZDMuY3VydmVMaW5lYXIiLCJkMy5heGlzTGVmdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBLHVCQUFhLG9CQUFvQixHQUFJLE1BQU0sQ0FBQztBQUM1Qyx1QkFBYSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7QUFDekMsdUJBQWEsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO0FBQ3pDLHVCQUFhLDRCQUE0QixHQUFHLGFBQWEsQ0FBQztBQUMxRCx1QkFBYSx5QkFBeUIsR0FBRyxXQUFXLENBQUM7QUFDckQsdUJBQWEseUJBQXlCLEdBQUcsVUFBVSxDQUFDO0FBQ3BELHVCQUFhLHVCQUF1QixHQUFHLFFBQVEsQ0FBQztBQUNoRCx1QkFBYSxnQ0FBZ0MsR0FBRyxpQkFBaUIsQ0FBQztBQUNsRSx1QkFBYSx3QkFBd0IsR0FBRyxTQUFTLENBQUM7QUFDbEQsdUJBQWEsMkJBQTJCLEdBQUcsWUFBWSxDQUFDO0FBQ3hELHVCQUFhLDBCQUEwQixHQUFHLFlBQVksQ0FBQztBQUN2RCx1QkFBYSxvQkFBb0IsR0FBRyxNQUFNLENBQUM7QUFDM0MsdUJBQWEsc0JBQXNCLEdBQUcsUUFBUSxDQUFDO0FBQy9DLHVCQUFhLHFCQUFxQixHQUFHLE9BQU87Ozs7OztBQ2I1Qzs7Ozs7Ozs7O0lBTUksWUFDVyxjQUNBLFlBQ0EsVUFDQSxVQUNBLFVBQ0E7UUFMQSxpQkFBWSxHQUFaLFlBQVk7UUFDWixlQUFVLEdBQVYsVUFBVTtRQUNWLGFBQVEsR0FBUixRQUFRO1FBQ1IsYUFBUSxHQUFSLFFBQVE7UUFDUixhQUFRLEdBQVIsUUFBUTtRQUNSLGNBQVMsR0FBVCxTQUFTO0tBQ2Y7Ozs7UUFLRSxhQUFhO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDOzs7OztRQUcvQixhQUFhO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDOzs7OztRQUcvQix3QkFBd0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUM7Ozs7O1FBUXRDLFNBQVM7UUFDaEIscUJBQUksS0FBSyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFDMUIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRTtZQUNoQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO1NBQ3RDO1FBQ0QsT0FBTyxLQUFLLENBQUM7Ozs7O1FBR04sU0FBUztRQUNoQixxQkFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFO1lBQ2hDLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7U0FDdEM7UUFDRCxPQUFPLEtBQUssQ0FBQzs7Ozs7UUFNTixhQUFhO1FBQ3BCLHFCQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7UUFDeEMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLE9BQU8sRUFBRTtZQUMvRSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtrQkFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO1NBQ25EO1FBQ0QsT0FBTyxLQUFLLENBQUM7Ozs7O1FBR04sYUFBYTtRQUNwQix1QkFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztjQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7UUFDM0MsT0FBTyxLQUFLLENBQUM7Ozs7O1FBR04sV0FBVztRQUNsQixPQUFPLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQzs7Ozs7UUFHbEMsV0FBVztRQUNsQixPQUFPLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQzs7Ozs7UUFHakMsVUFBVTtRQUNqQixxQkFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtjQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDNUMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7WUFDaEMsT0FBTyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztTQUNoRDtRQUVELE9BQU8sSUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUM7Ozs7O1FBR3hCLFdBQVc7UUFDbEIsdUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTO2NBQ1gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtjQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHO2NBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUM1QyxPQUFPLEVBQUUsQ0FBQzs7Ozs7UUFHSCxjQUFjO1FBQ3JCLHVCQUFNLFFBQVEsR0FBa0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUM1Qyx1QkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtjQUN4QixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztRQUNsQyx1QkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztjQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNO2NBQzVCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO1FBQy9CLFFBQVEsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7UUFDbEIsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNsQixPQUFPLFFBQVEsQ0FBQzs7Ozs7UUFHVCx1QkFBdUI7UUFDOUIsdUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUk7Y0FDNUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUM7UUFDOUIsdUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUc7Y0FDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtjQUM1QixJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztRQUMvQixPQUFPLFlBQVksR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUM7Ozs7O1FBR3BELHFCQUFxQjtRQUM1Qix1QkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUM5Qix1QkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztRQUM5QixPQUFPLFlBQVksR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUM7Ozs7O1FBTXBELGtCQUFrQjtRQUN6Qix1QkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtjQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO1FBQ2pELE9BQU8sRUFBRSxDQUFDOzs7OztRQUdILGtCQUFrQjtRQUN6Qix1QkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVM7Y0FDZixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO1FBQ25ELE9BQU8sRUFBRSxDQUFDOzs7OztRQUdILGdCQUFnQjtRQUN2Qix1QkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQ3ZDLHVCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHO2NBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUN2QyxPQUFPLFlBQVksR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUM7Ozs7O1FBSXBELG9CQUFvQjtRQUMzQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQzs7Ozs7UUFHckMsaUJBQWlCO1FBQ3hCLHVCQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHO2NBQ3hCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU07Y0FDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBQy9DLE9BQU8sSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUM7Ozs7O1FBR3pCLGdCQUFnQjtRQUN2QixxQkFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtjQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7UUFDNUMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7WUFDaEMsT0FBTyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztTQUNoRDtRQUNELE9BQU8sSUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUM7Ozs7O1FBR3hCLFdBQVc7UUFDbEIsT0FBTyxNQUFNLENBQUM7Ozs7O1FBR1AsV0FBVztRQUNsQixPQUFPLFFBQVEsQ0FBQzs7Ozs7UUFFVCx1QkFBdUI7UUFDOUIsdUJBQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3JFLE9BQU8sWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHLEdBQUcsQ0FBQzs7Ozs7UUFRaEUsa0JBQWtCO1FBQ3pCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQzs7Ozs7UUFHeEMsZ0JBQWdCO1FBQ3ZCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQzs7Ozs7UUFHdEMsNEJBQTRCO1FBQ25DLHVCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO2NBQ3hCLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO1FBQ2xDLHVCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHO2NBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU07Y0FDNUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDO2NBQ3BCLENBQUMsQ0FBQztRQUNaLE9BQU8sWUFBWSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQzs7Ozs7UUFNcEQsY0FBYztRQUNyQixxQkFBSSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtjQUN0QixJQUFJLENBQUMsVUFBVTtjQUNmLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBRTtRQUMvQyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxPQUFPLEVBQUU7WUFDN0MsRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUk7a0JBQ3pCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBRTtTQUMzQztRQUNELE9BQU8sRUFBRSxDQUFDOzs7OztRQUdILGNBQWM7UUFDckIsdUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUc7Y0FDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtjQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDMUMsT0FBTyxFQUFFLENBQUM7Ozs7O1FBTUgsU0FBUztRQUNoQix1QkFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNuRCx1QkFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLHVCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxRQUFRLENBQUM7UUFDckQsT0FBTyxLQUFLLENBQUM7Ozs7O1FBR04sU0FBUztRQUNoQix1QkFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUNuRCx1QkFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO1FBQ3BCLHVCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxRQUFRLENBQUM7UUFDckQsT0FBTyxLQUFLLENBQUM7Ozs7O1FBT04sYUFBYTtRQUNwQix1QkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtjQUM1QixDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBVSxJQUFJLENBQUM7Y0FDekQsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDO1FBQzNDLE9BQU8sRUFBRSxDQUFDOzs7OztRQUdILGFBQWE7UUFDcEIsdUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUc7Y0FDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtjQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUM7UUFDN0MsT0FBTyxFQUFFLENBQUM7Ozs7O1FBTUgsZ0JBQWdCO1FBQ3ZCLHFCQUFJLE1BQVcsQ0FBQztRQUNoQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUssRUFBRTtZQUM3QixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLGtCQUFrQixLQUFLLElBQUksRUFBRTtnQkFDbkQsTUFBTSxHQUFHQSxZQUFlLENBQUNDLGdCQUFtQixDQUFDLENBQUM7YUFDakQ7aUJBQU07Z0JBQ0gsTUFBTSxHQUFHRCxZQUFlLENBQUNFLGdCQUFtQixDQUFDLENBQUM7YUFDakQ7U0FDSjtRQUNELE9BQU8sTUFBTSxDQUFDOztDQUVqQjs7Ozs7O0lBYUQsWUFDVSxPQUNDO1FBREQsVUFBSyxHQUFMLEtBQUs7UUFDSixVQUFLLEdBQUwsS0FBSztLQUFjO0NBRTdCOzs7Ozs7O0lBR0QsWUFDVSxHQUNBLEdBQ0E7UUFGQSxNQUFDLEdBQUQsQ0FBQztRQUNELE1BQUMsR0FBRCxDQUFDO1FBQ0QsTUFBQyxHQUFELENBQUM7S0FBYztDQUV4Qjs7Ozs7O0lBV0QsWUFDVSxJQUNDO1FBREQsT0FBRSxHQUFGLEVBQUU7UUFDRCxVQUFLLEdBQUwsS0FBSztLQUNSO0NBRVA7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZURDs7OztJQW9CRSxZQUFhLFVBQXNCO1FBQ2pDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQztRQUNqRCx1QkFBTSxFQUFFLEdBQW1CLFVBQVUsQ0FBQyxhQUFhLENBQUM7UUFDcEQsSUFBSSxDQUFDLElBQUksR0FBR0MsTUFBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0tBQzdCOzs7O0lBRUQsUUFBUTtLQUNQOzs7OztJQUVELFdBQVcsQ0FBQyxPQUErQztRQUN6RCx1QkFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDN0MsdUJBQU0sU0FBUyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQy9DLHVCQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQy9CLHVCQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO1FBQ25DLHVCQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO1FBQ2pDLHVCQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7YUFDakMsSUFBSSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUM7YUFDdkIsSUFBSSxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUVyQyxPQUFPLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3ZCLFFBQVEsU0FBUztZQUNmLEtBQUtDLG9CQUErQjtnQkFDbEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQ3ZFLE1BQU07WUFDUixLQUFLQyxtQkFBOEI7Z0JBQ2pDLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO2dCQUN2RSxNQUFNO1lBQ1IsS0FBS0MsbUJBQThCO2dCQUNqQyxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQztnQkFDdkUsTUFBTTtZQUNSLEtBQUtDLDRCQUF1QztnQkFDMUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQztnQkFDL0UsTUFBTTtZQUNSLEtBQUtDLHlCQUFvQztnQkFDdkMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7Z0JBQzdFLE1BQU07WUFDUixLQUFLQyx5QkFBb0M7Z0JBQ3ZDLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO2dCQUM1RSxNQUFNO1lBQ1IsS0FBS0MsdUJBQWtDO2dCQUNyQyxJQUFJLENBQUMsV0FBVyxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQztnQkFDMUUsTUFBTTtZQUNSLEtBQUtDLGdDQUEyQztnQkFDOUMsSUFBSSxDQUFDLG9CQUFvQixDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQztnQkFDbkYsTUFBTTtZQUNSLEtBQUtDLG9CQUErQjtnQkFDbEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7Z0JBQ3hFLE1BQU07WUFDUixLQUFLQywyQkFBc0M7Z0JBQ3pDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO2dCQUM5RSxNQUFNO1lBQ1IsS0FBS0MsMEJBQXFDO2dCQUN4QyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQztnQkFDOUUsTUFBTTtZQUNSLEtBQUtDLHFCQUFnQztnQkFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7Z0JBQ3pFLE1BQU07WUFDUixLQUFLQyx3QkFBbUM7O2dCQUV0QyxNQUFNO1lBQ1IsS0FBS0Msc0JBQWlDOztnQkFFcEMsTUFBTTtZQUNSO2dCQUNFLE1BQU07U0FDVDtLQUNGOzs7Ozs7Ozs7SUFJTyxjQUFjLENBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBRTlHLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0NBQXNDLENBQUMsQ0FBQztRQUVwRCx1QkFBTSxPQUFPLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQztRQUNqQyx1QkFBTSxVQUFVLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBRS9DLHVCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDbEIsdUJBQU0sS0FBSyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkMsdUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDdEYsdUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7UUFDbkMsdUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7UUFHckMsdUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7UUFDdEMsdUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7UUFFdEMsdUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1FBQy9DLHVCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUMvQyx1QkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUN6RCx1QkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ2hELHVCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztRQUMzQyx1QkFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7UUFDekMsdUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDO1FBR3JELHVCQUFNLFFBQVEsR0FBa0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUM1QyxLQUFLLHVCQUFNLENBQUMsSUFBSSxPQUFPLEVBQUU7WUFDckIsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUMzQix1QkFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQztnQkFDaEMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN2QjtTQUNKO1FBRUQsdUJBQU0sV0FBVyxHQUFHQyxNQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFdEMsdUJBQU0sa0JBQWtCLEdBQUcsWUFBWTthQUN0QixNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ1gsSUFBSSxDQUFDLFdBQVcsRUFBRSxZQUFZLEdBQUcsV0FBVyxHQUFHLEdBQUcsR0FBRyxXQUFXLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFFekYsdUJBQU0sT0FBTyxHQUFHQyxXQUFjLEVBQUU7YUFDM0IsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUM7UUFFbEMsdUJBQU0sSUFBSSxHQUFHQyxTQUFZLEVBQUU7YUFDdEIsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ2QsVUFBVSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FDckMsUUFBUSxDQUFDLENBQUM7UUFHZix1QkFBTSxPQUFPLEdBQUdELFdBQWMsRUFBRTthQUMzQixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUVFLEdBQU0sQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFNO2dCQUM1QixPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUM7YUFDbkIsQ0FBQyxDQUFDLENBQUM7YUFDSCxLQUFLLENBQUMsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUU5Qix1QkFBTSxHQUFHLEdBQUcsa0JBQWtCO2FBQ3pCLFNBQVMsQ0FBQyxNQUFNLENBQUM7YUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQzthQUNWLEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDWCxJQUFJLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQzthQUN6QixJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBTTtZQUN0QixPQUFPLFlBQVksR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUN2RSxDQUFDLENBQUM7UUFFUCxJQUFJLFVBQVUsRUFBRTtZQUNaLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2lCQUNiLElBQUksQ0FBQyxHQUFHLEVBQUcsQ0FBQyxDQUFDO2lCQUNiLElBQUksQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDNUQsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7aUJBQ2pCLFVBQVUsRUFBRTtpQkFDWixRQUFRLENBQUMsa0JBQWtCLENBQUM7aUJBQzVCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFNO2dCQUNuQixPQUFPLFlBQVksR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQzNDLENBQUMsQ0FBQztTQUNWO2FBQU07WUFDSCxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztpQkFDYixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztpQkFDWixJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQzVELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFNO2dCQUNuQixPQUFPLFlBQVksR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQzNDLENBQUMsQ0FBQztTQUNWO1FBRUQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDYixJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQzthQUNuQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzthQUNaLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQzFELElBQUksQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDO2FBQzdCLElBQUksQ0FBQyxDQUFDLENBQU07WUFDVCxPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDaEMsQ0FBQyxDQUFDOztRQUdQLElBQUksYUFBYSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2Qjs7O1FBR0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUVyQixJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXBCLElBQUksYUFBYSxFQUFFO1lBQ2hCLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDdkI7Ozs7Ozs7Ozs7SUFLSyxVQUFVLENBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBRTFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0JBQStCLENBQUMsQ0FBQztRQUU3Qyx1QkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDO1FBQ2xCLHVCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDbEIsdUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFdEYsdUJBQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztRQUlwQyx1QkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUNyQyx1QkFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUVuQyx1QkFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7UUFDM0MsdUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1FBR3pDLHVCQUFNLFVBQVUsR0FBR0MsZUFBa0IsRUFBRTthQUNsQyxLQUFLLENBQUMsTUFBTSxFQUFFQyxTQUFZLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFNO1lBQ3BDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQztTQUNmLENBQUMsQ0FBQzthQUNGLEtBQUssQ0FBQyxRQUFRLEVBQUVDLGFBQWdCLEVBQUUsQ0FBQzthQUNuQyxLQUFLLENBQUMsUUFBUSxFQUFFQyxXQUFjLENBQUMsV0FBVyxHQUFHLENBQUMsRUFBRSxZQUFZLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUd4RSx1QkFBTSxlQUFlLEdBQUcsWUFBWTthQUNqQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ1gsSUFBSSxDQUFDLFdBQVcsRUFDZixZQUFZLEdBQUcsV0FBVyxHQUFHLEdBQUcsR0FBRyxVQUFVLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFFekQsdUJBQU0sSUFBSSxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ25DLElBQUksQ0FBQyxPQUFPLEVBQUUsYUFBYSxDQUFDO2FBQzVCLFNBQVMsQ0FBQyxNQUFNLENBQUM7YUFDakIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7YUFDdkIsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNkLElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQyxDQUFNO1lBQ3pCLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDN0IsQ0FBQyxDQUFDO1FBRVAsdUJBQU0sSUFBSSxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ25DLElBQUksQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO2FBQ3RCLFNBQVMsQ0FBQyxRQUFRLENBQUM7YUFDbkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7YUFDdkIsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLFFBQVEsQ0FBQzthQUNoQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzthQUNaLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFNO1lBQ2pCLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUMxQixDQUFDO2FBQ0QsSUFBSSxDQUFDQyxJQUFPLEVBQUU7YUFDVixFQUFFLENBQUMsT0FBTyxFQUFFLFdBQVcsQ0FBQzthQUN4QixFQUFFLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQzthQUNuQixFQUFFLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDLENBQUM7UUFFM0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7YUFDZixJQUFJLENBQUMsQ0FBQyxDQUFNO1lBQ1QsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDO1NBQ2YsQ0FBQyxDQUFDO1FBRVgsVUFBVTthQUNMLEtBQUssQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDO2FBQ3hCLEVBQUUsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFFeEIsdUJBQU0sVUFBVSxHQUFRLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDakQsVUFBVSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUM7Ozs7UUFFcEM7WUFDSSxJQUFJO2lCQUNDLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFNO2dCQUNoQixPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2FBQUUsQ0FBQztpQkFDdkIsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQU07Z0JBQ2pCLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7YUFBRSxDQUFDO2lCQUN0QixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBTTtnQkFDaEIsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQzthQUFFLENBQUM7aUJBQ3ZCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFNO2dCQUNoQixPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2FBQUUsQ0FBQyxDQUFDO1lBRTdCLElBQUk7aUJBQ0MsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQU07Z0JBQ2hCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUFFLENBQUM7aUJBQ2hCLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFNO2dCQUNoQixPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFBRSxDQUFDLENBQUM7U0FDekI7Ozs7O1FBRUQscUJBQXFCLENBQU07WUFDdkIsSUFBSSxDQUFDQyxLQUFRLENBQUMsTUFBTSxFQUFFO2dCQUNsQixVQUFVLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDO2FBQ3pDO1lBQ0QsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ1gsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ2Q7Ozs7O1FBRUQsaUJBQWlCLENBQU07WUFDbkIsQ0FBQyxDQUFDLEVBQUUsR0FBR0EsS0FBUSxDQUFDLENBQUMsQ0FBQztZQUNsQixDQUFDLENBQUMsRUFBRSxHQUFHQSxLQUFRLENBQUMsQ0FBQyxDQUFDO1NBQ3JCOzs7OztRQUVELG1CQUFtQixDQUFNO1lBQ3JCLElBQUksQ0FBQ0EsS0FBUSxDQUFDLE1BQU0sRUFBRTtnQkFDbEIsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM3QjtZQUNELENBQUMsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDO1lBQ1osQ0FBQyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUM7U0FDZjs7O1FBSUQsdUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO1FBQ3hELEtBQUssdUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxNQUFNLEVBQUU7WUFDaEMsSUFBSSxXQUFXLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDdEMsdUJBQU0sR0FBRyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDbEY7U0FDSjtRQUNELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDOzs7Ozs7Ozs7O0lBT2hDLGVBQWUsQ0FBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7UUFFL0csT0FBTyxDQUFDLEdBQUcsQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDO1FBRXRELHVCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDbEIsdUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUNsQix1QkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN0Rix1QkFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLGNBQWMsQ0FBQztRQUszQyx1QkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDL0MsdUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQ2pELHVCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztRQUVoRCx1QkFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7UUFDckMsdUJBQU0sV0FBVyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQy9DLHVCQUFNLFlBQVksR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUNqRCx1QkFBTSxRQUFRLEdBQUcsT0FBTyxHQUFHLFlBQVksQ0FBQztRQUN4Qyx1QkFBTSxjQUFjLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7UUFDdEQsdUJBQU0sV0FBVyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQy9DLHVCQUFNLFNBQVMsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztRQUMzQyx1QkFBTSxTQUFTLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUM7UUFDOUMsdUJBQU0sT0FBTyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDO1FBQ3ZDLHVCQUFNLG1CQUFtQixHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUM7UUFDL0QsdUJBQU0sZUFBZSxHQUFHLElBQUksR0FBRyxtQkFBbUIsQ0FBQztRQUVuRCx1QkFBTSxLQUFLLEdBQUdDLGNBQWlCLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRXhELHFCQUFJLElBQUksR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUNyQyxxQkFBSSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDckMsS0FBSyx1QkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtZQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNwQyxJQUFJLElBQUksR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtvQkFDbEMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2lCQUNwQztnQkFDRCxJQUFJLElBQUksR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtvQkFDbEMsSUFBSSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2lCQUNwQzthQUNKO1NBQ0o7UUFDRCx1QkFBTSxNQUFNLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztRQUMzQix1QkFBTSxLQUFLLEdBQUcsTUFBTSxJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUV2Qyx1QkFBTSxjQUFjLEdBQUcsQ0FBQyxFQUFVO1lBQzlCLEtBQUssdUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7Z0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQ3BDLElBQUksRUFBRSxLQUFLLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxFQUFFO3dCQUMvQix1QkFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7d0JBQ3pDLHVCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLElBQUksSUFBSSxLQUFLLENBQUMsQ0FBQzt3QkFDakQsT0FBTyxLQUFLLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxDQUFDO3FCQUM5QjtpQkFDSjthQUNKO1NBQ0osQ0FBQztRQUVGLHVCQUFNLElBQUksR0FBR0MsT0FBVSxFQUFFO2FBQ1osVUFBVSxDQUNQQyxXQUFjLEVBQUU7YUFDZixNQUFNLENBQUMsT0FBTyxDQUFDO2FBQ2YsS0FBSyxDQUFDLE1BQU0sQ0FBQzthQUNiLFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FDOUIsQ0FBQztRQUVkQyxJQUFPLENBQUMsY0FBYyxFQUFFLENBQUMsS0FBSyxFQUFFLElBQUk7WUFDaEMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7aUJBQ3JCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQ3BCLEtBQUssRUFBRTtpQkFDUCxNQUFNLENBQUMsTUFBTSxDQUFDO2lCQUNkLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO2lCQUNmLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFNLEVBQUUsQ0FBUztnQkFDN0IsdUJBQU0sR0FBRyxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQztnQkFDbEQsT0FBTyxHQUFHLENBQUM7YUFDZCxDQUFDLENBQUM7U0FDZCxDQUFDLENBQUM7OztRQUlILElBQUksYUFBYSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2Qjs7O1FBSUQsSUFBSSxjQUFjLEVBQUU7WUFDaEIsdUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ3hELEtBQUsscUJBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNoQyx1QkFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsR0FBSSxLQUFLLENBQUM7Z0JBQ25ELGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2xFO1lBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7U0FDekM7Ozs7Ozs7Ozs7SUFJSyxlQUFlLENBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBRS9HLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztRQUUvQyx1QkFBTSxnQkFBZ0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQztRQUN6RCx1QkFBTSxxQkFBcUIsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQztRQUNuRSx1QkFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7UUFDL0MsdUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7UUFDekQsdUJBQU0sS0FBSyxHQUFHL0IsWUFBZSxDQUFDRSxnQkFBbUIsQ0FBQyxDQUFDOztRQUVuRCx1QkFBTSxNQUFNLEdBQUc4QixJQUFPLEVBQUU7YUFDUCxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQztRQUU3Qyx1QkFBTSxNQUFNLEdBQUdDLFNBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUV6Qyx1QkFBTUMsT0FBSSxHQUFJLFlBQVksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO2FBQzVCLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDbEMsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNYLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFNLEVBQUUsQ0FBUztZQUNqQyxPQUFPLFlBQVksR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUMvQyxDQUFDLENBQUM7UUFFZix1QkFBTSxPQUFPLEdBQUdBLE9BQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdEMsSUFBSSxVQUFVLEVBQUU7WUFDWixPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7aUJBQ1gsVUFBVSxFQUFFO2lCQUNaLFFBQVEsQ0FBQyxDQUFDLENBQU0sRUFBRSxDQUFTO2dCQUN4QixPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsa0JBQWtCLEdBQUksR0FBRyxDQUFDO2FBQzlDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQU07Z0JBQ2QsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2QsQ0FBQztpQkFDRCxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBTSxFQUFFLENBQU07Z0JBQzFCLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ25CLENBQUMsQ0FBQztTQUNkO2FBQU07WUFDSCxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQU07Z0JBQ2IsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2QsQ0FBQztpQkFDRCxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBTSxFQUFFLENBQU07Z0JBQzFCLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ25CLENBQUMsQ0FBQztTQUNkO1FBRUQsdUJBQU0sS0FBSyxHQUFHQSxPQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNwQixJQUFJLENBQUMsT0FBTyxFQUFFLHFCQUFxQixDQUFDO2FBQ3BDLElBQUksQ0FBQyxDQUFDLENBQU0sRUFBRSxDQUFTO1lBQ3BCLElBQUksQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDLEVBQUU7Z0JBQ2YsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzthQUN0QjtZQUNELE9BQU8sSUFBSSxDQUFDO1NBQ2YsQ0FBQyxDQUFDO1FBRWYsSUFBSSxVQUFVLEVBQUU7WUFDWixLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUM7aUJBQ3BCLFVBQVUsRUFBRTtpQkFDWixRQUFRLENBQUMsa0JBQWtCLENBQUM7aUJBQzVCLEtBQUssQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FDOUI7YUFBTTtZQUNILEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQy9COzs7Ozs7Ozs7O0lBSUssU0FBUyxDQUFDLFlBQWlCLEVBQUUsVUFBZSxFQUFFLFdBQWdCLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtRQUV6RyxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixDQUFDLENBQUM7UUFFN0MscUJBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztRQUNkLHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDZCxLQUFLLEdBQUcsR0FBRyxDQUFDO1FBQ1osS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUNaLHVCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBS3RGLHVCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO1FBQ3JDLHVCQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBRW5DLHVCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUMvQyx1QkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUN6RCx1QkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7UUFDbkQsdUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxZQUFZLENBQUM7UUFDN0QsdUJBQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQzNDLHVCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztRQUd6Qyx1QkFBTUMsT0FBSSxHQUFHQyxJQUFPLEVBQUU7YUFDTCxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUVuRCx1QkFBTSxNQUFNLEdBQUdILFNBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUV6Qyx1QkFBTSxLQUFLLEdBQUdFLE9BQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUUzQix1QkFBTSxjQUFjLEdBQUcsWUFBWTthQUNoQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ1gsSUFBSSxDQUFDLFdBQVcsRUFDZixZQUFZLEdBQUcsV0FBVyxHQUFHLEdBQUcsR0FBRyxVQUFVLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFFekQsdUJBQU0sSUFBSSxHQUFHLGNBQWM7YUFDdEIsU0FBUyxDQUFDLE9BQU8sQ0FBQzthQUNsQixJQUFJLENBQUUsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNuQyxLQUFLLEVBQUU7YUFDUCxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ2QsSUFBSSxDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQzthQUMvQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBTTtZQUNkLE9BQU8sR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDO2tCQUN0QixHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7a0JBQ3hDLEdBQUcsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUM7a0JBQ2hELEdBQUcsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7U0FDekMsQ0FDSixDQUFDO1FBRU4sdUJBQU0sSUFBSSxHQUFHLGNBQWM7YUFDdEIsU0FBUyxDQUFDLE9BQU8sQ0FBQzthQUNsQixJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO2FBQ3pCLEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDWCxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBTTtZQUNsQixPQUFPLFdBQVc7aUJBQ2pCLENBQUMsQ0FBQyxRQUFRLEdBQUcsV0FBVyxHQUFHLE9BQU8sQ0FBQyxDQUFDO1NBQ3hDLENBQUM7YUFDRCxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBTTtZQUN0QixPQUFPLFlBQVksR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUMvQyxDQUFDLENBQUM7UUFFUCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQzthQUNoQixJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBRW5CLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ2QsSUFBSSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7YUFDbkIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQU07WUFDZCxPQUFPLENBQUMsQ0FBQyxRQUFRLEdBQUcsQ0FBQyxFQUFFLEdBQUcsRUFBRSxDQUFDO1NBQ2hDLENBQUM7YUFDRCxLQUFLLENBQUMsYUFBYSxFQUFFLFFBQVEsQ0FBQzthQUM5QixJQUFJLENBQUMsQ0FBQyxDQUFNO1lBQ1QsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztTQUN0QixDQUFDLENBQUM7Ozs7Ozs7Ozs7SUFPRCxvQkFBb0IsQ0FBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7UUFFcEgsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDO1FBRTNELHVCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDbEIsdUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUNsQix1QkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN0Rix1QkFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLGNBQWMsQ0FBQztRQUkzQyx1QkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDL0MsdUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQ2pELHVCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztRQUVoRCx1QkFBTSxjQUFjLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7UUFDdEQsdUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO1FBQ3JDLHVCQUFNLFdBQVcsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUMvQyx1QkFBTSxlQUFlLEdBQUcsSUFBSSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUM7UUFDbEUsdUJBQU0sWUFBWSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO1FBQ2pELHVCQUFNLFFBQVEsR0FBRyxPQUFPLEdBQUcsWUFBWSxDQUFDO1FBQ3hDLHVCQUFNLFVBQVUsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUM3Qyx1QkFBTSxRQUFRLEdBQUssV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO1FBQ3JELHVCQUFNLFFBQVEsR0FBSyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDbkQsdUJBQU0sV0FBVyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQy9DLHVCQUFNLGdCQUFnQixHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDO1FBQ3pELHVCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUMvQyx1QkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUN6RCxxQkFBSSxXQUFXLEdBQUcsQ0FBQyxDQUFDO1FBRXBCLHVCQUFNLGdCQUFnQixHQUFHLENBQUMsSUFBWTtZQUNsQyxLQUFLLHVCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO2dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNwQyxJQUFJLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRTt3QkFDbkMsdUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO3dCQUN6QyxPQUFPLE1BQU0sQ0FBQztxQkFDakI7aUJBQ0o7YUFDSjtZQUNELE9BQU8sSUFBSSxDQUFDO1NBQ2YsQ0FBQztRQUVGLHVCQUFNLFVBQVUsR0FBR0UsZUFBa0IsRUFBRTthQUMxQixTQUFTLENBQUMsZUFBZSxDQUFDO2FBQzFCLFNBQVMsQ0FBQyxVQUFVLENBQUM7YUFDckIsS0FBSyxDQUFDLE1BQU0sQ0FBQzthQUNiLE1BQU0sQ0FBQyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBRTFDLHVCQUFNLElBQUksR0FBR1IsT0FBVSxFQUFFO2FBQ1osVUFBVSxDQUNQLFVBQVUsQ0FDYixDQUFDO1FBRWRFLElBQU8sQ0FBQyxjQUFjLEVBQUUsQ0FBQyxLQUFLLEVBQUUsSUFBSTtZQUNoQyxZQUFZLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztpQkFDeEIsSUFBSSxDQUFDLElBQUksRUFBRSxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQzlCLElBQUksQ0FBQyxJQUFJLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUM5QixJQUFJLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQztpQkFDakIsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQztZQUVoQyx1QkFBTSxTQUFTLEdBQUcsWUFBWSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7aUJBQzNDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQ3BCLEtBQUssRUFBRTtpQkFDUCxNQUFNLENBQUMsTUFBTSxDQUFDO2lCQUNkLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO2lCQUNmLEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFNLEVBQUUsQ0FBUztnQkFDN0IsdUJBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFDMUMsSUFBSSxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsS0FBSyxJQUFJLEVBQUU7b0JBQ3hDLE9BQU8sZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3hDO2dCQUVELE9BQU8sTUFBTSxHQUFHLENBQUMsR0FBRyxXQUFXLENBQUM7YUFDbkMsQ0FBQyxDQUFDO1lBQ1AsSUFBSSxVQUFVLEVBQUU7Z0JBQ1pPLEtBQVEsQ0FBQztvQkFDTCxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxHQUFHLFdBQVcsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO29CQUN0RCxXQUFXLElBQUksQ0FBQyxDQUFDO29CQUNqQixTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDN0IsQ0FBQyxDQUFDO2FBQ047U0FDSixDQUFDLENBQUM7OztRQUlILElBQUksYUFBYSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2QjtRQUVELElBQUksY0FBYyxFQUFFO1lBQ2hCLHVCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUN4RCxLQUFLLHVCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO2dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNwQyx1QkFBTSxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7b0JBQ3ZDLHVCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztvQkFDekMsSUFBSSxLQUFLLEtBQUssWUFBWSxFQUFFO3dCQUN4QixTQUFTO3FCQUNaO29CQUNELGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2lCQUM5RjthQUNKO1lBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7U0FDekM7Ozs7Ozs7Ozs7SUFPSyxXQUFXLENBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBRTNHLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0NBQW9DLENBQUMsQ0FBQztRQUVsRCx1QkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDO1FBQ2xCLHVCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDbEIsdUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDdEYsdUJBQU0sZUFBZSxHQUFHLEdBQUcsQ0FBQyxjQUFjLENBQUM7UUFDM0MsdUJBQU0sY0FBYyxHQUFJLFdBQVcsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO1FBQ3ZELHVCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztRQUNyQyx1QkFBTSxZQUFZLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUM7UUFDakQsdUJBQU0sUUFBUSxHQUFHLE9BQU8sR0FBRyxZQUFZLENBQUM7UUFDeEMsdUJBQU0sZUFBZSxHQUFHLElBQUksR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDO1FBQ2xFLHVCQUFNLGdCQUFnQixHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDO1FBQ3pELHVCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUVqRCx1QkFBTSxJQUFJLEdBQUdULE9BQVUsRUFBRTthQUNaLFVBQVUsQ0FDUEMsV0FBYyxFQUFFO2FBQ2YsU0FBUyxDQUFDLGVBQWUsQ0FBQzthQUMxQixLQUFLLENBQUMsTUFBTSxDQUFDLENBQ2pCLENBQUM7UUFFZCx1QkFBTSxnQkFBZ0IsR0FBRyxDQUFDLElBQVk7WUFDbEMsS0FBSyx1QkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtnQkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDcEMsSUFBSSxJQUFJLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUU7d0JBQ25DLHVCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzt3QkFDekMsT0FBTyxNQUFNLENBQUM7cUJBQ2pCO2lCQUNKO2FBQ0o7WUFDRCxPQUFPLElBQUksQ0FBQztTQUNmLENBQUM7UUFFRkMsSUFBTyxDQUFDLGNBQWMsRUFBRSxDQUFDLEtBQUssRUFBRSxJQUFJO1lBQ2hDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2lCQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2lCQUNwQixLQUFLLEVBQUU7aUJBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQztpQkFDZCxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQztpQkFDZixLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBTSxFQUFFLENBQVM7Z0JBQzdCLHVCQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUM7Z0JBQzFDLElBQUksZ0JBQWdCLENBQUMsV0FBVyxDQUFDLEtBQUssSUFBSSxFQUFFO29CQUN4QyxPQUFPLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDO2lCQUN4QztnQkFDRCxPQUFPLE1BQU0sR0FBRyxDQUFDLEdBQUcsV0FBVyxDQUFDO2FBQ25DLENBQUMsQ0FBQztTQUNWLENBQUMsQ0FBQzs7O1FBSVAsSUFBSSxjQUFjLEVBQUU7WUFDaEIsdUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ3hELEtBQUssdUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7Z0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQ3BDLHVCQUFNLEtBQUssR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztvQkFDdkMsdUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO29CQUN6QyxJQUFJLEtBQUssS0FBSyxZQUFZLEVBQUU7d0JBQ3hCLFNBQVM7cUJBQ1o7b0JBQ0QsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLFlBQVksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7aUJBQzlGO2FBQ0o7WUFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxjQUFjLENBQUMsQ0FBQztTQUN6Qzs7Ozs7Ozs7OztJQU1LLGFBQWEsQ0FBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7UUFFN0csT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO1FBU25ELHVCQUFNLE9BQU8sR0FBa0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUMzQyxLQUFLLHVCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO1lBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3JDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDbEI7U0FDSjtRQUVELEtBQUssdUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7WUFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDcEMscUJBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDVixLQUFLLHVCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtvQkFDdkMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQzdDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDbEQ7aUJBQ0o7YUFDSjtTQUNKO1FBQ0QscUJBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztRQUNkLHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDZCxLQUFLLEdBQUdWLEdBQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUN4QixLQUFLLEdBQUcsR0FBRyxDQUFDO1FBQ1osdUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFdEYsdUJBQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztRQUNwQyx1QkFBTSxVQUFVLEdBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7UUFDNUMsdUJBQU0sU0FBUyxHQUFHLENBQUMsR0FBRyxDQUFDLFVBQVUsR0FBRyxVQUFVLElBQUksVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFDNUUsdUJBQU0sWUFBWSxJQUFJLEdBQUcsQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDLENBQUU7UUFDcEQsdUJBQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7UUFFcEMsdUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7UUFDckMsdUJBQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUM7UUFFakMsdUJBQU0sUUFBUSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1FBQzFDLHVCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUNqRCx1QkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ2hELHVCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7UUFDaEQsdUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1FBQy9DLHVCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUMvQyx1QkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQzs7UUFHekQsdUJBQU0sZUFBZSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7O1FBRzlDLHVCQUFNLFNBQVMsR0FBa0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUM3QyxLQUFLLHVCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO1lBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3BDLHVCQUFNLElBQUksR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztnQkFDdEMsdUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDOUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN4QjtTQUNKOztRQUdELHVCQUFNLFVBQVUsR0FBa0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUM5QyxLQUFLLHVCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtZQUN2QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDN0MsdUJBQU0sT0FBTyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDL0MsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQzthQUM1QjtTQUNKO1FBRUQsdUJBQU0sVUFBVSxHQUFlLElBQUksS0FBSyxFQUFFLENBQUM7UUFDM0MsS0FBSyx1QkFBTSxDQUFDLElBQUksVUFBVSxFQUFFO1lBQ3hCLElBQUksVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFFOUIsdUJBQU0sV0FBVyxHQUFlLEVBQUcsQ0FBQztnQkFDcEMsS0FBSyx1QkFBTSxDQUFDLElBQUksU0FBUyxFQUFFO29CQUN2QixJQUFJLFNBQVMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQzdCLHVCQUFNLElBQUksR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzFCLHVCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzlDLFdBQVcsQ0FBQyxJQUFJLENBQUMsR0FBSSxNQUFNLENBQUM7cUJBQy9CO2lCQUNKO2dCQUNELFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7YUFDaEM7U0FDSjtRQUVELHVCQUFNLE1BQU0sR0FBR0YsV0FBYyxFQUFFO2FBQ2QsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO2FBQ3ZCLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBRzFDLHVCQUFNb0IsUUFBSyxHQUFHQyxLQUFRLEVBQUUsQ0FBQztRQUN6Qix1QkFBTSxLQUFLLEdBQUcsWUFBWSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7YUFDcEMsSUFBSSxDQUFDRCxRQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO2FBQ3ZDLEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDWCxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBTSxFQUFFLENBQVM7WUFDNUIsT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDcEIsQ0FBRTthQUNGLElBQUksQ0FBQyxjQUFjLEVBQUUsUUFBUSxDQUFDO2FBQzlCLFNBQVMsQ0FBQyxNQUFNLENBQUM7YUFDakIsSUFBSSxDQUFDLENBQUMsQ0FBTSxFQUFFLENBQVM7WUFDcEIsT0FBTyxDQUFDLENBQUM7U0FDWixDQUFDO2FBQ0QsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBSXBCLElBQUksVUFBVSxFQUFFO1lBQ1osS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFNLEVBQUUsQ0FBUztnQkFDOUIsT0FBTyxTQUFTLEdBQUssQ0FBQyxHQUFHLFlBQVksQ0FBQzthQUN6QyxDQUFDO2lCQUNELElBQUksQ0FBQyxRQUFRLEVBQUcsQ0FBQyxDQUFDO2lCQUNsQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBTSxFQUFFLENBQVM7Z0JBQ3pCLHVCQUFNLEVBQUUsR0FBRyxTQUFTLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwQyx1QkFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUN6QixPQUFPLFNBQVMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDOUQsQ0FBQztpQkFDRCxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQztpQkFDeEIsVUFBVSxFQUFFO2lCQUNaLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQztpQkFDNUIsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQU0sRUFBRSxDQUFTO2dCQUM5QixPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDOUIsQ0FBQyxDQUFDO1NBQ047YUFBTTtZQUNILEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBTSxFQUFFLENBQVM7Z0JBQzlCLE9BQU8sU0FBUyxJQUFJLENBQUMsR0FBRyxZQUFZLENBQUMsQ0FBQzthQUN6QyxDQUFDO2lCQUNELElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFNLEVBQUUsQ0FBUztnQkFDekIsdUJBQU0sRUFBRSxHQUFHLFNBQVMsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BDLHVCQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7Z0JBQ3pCLE9BQU8sU0FBUyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM5RCxDQUFDO2lCQUNELElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDO2lCQUN4QixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBTSxFQUFFLENBQVM7Z0JBQzlCLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM5QixDQUFDLENBQUM7U0FDTjs7O1FBS0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O1FBSXBCLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFckIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O1FBSXhCLElBQUksYUFBYSxFQUFFO1lBQ2YsdUJBQU0sV0FBVyxHQUFtQixJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ2hELEtBQUssdUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO2dCQUN2QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDN0MsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDcEQ7YUFDSjtZQUNELElBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFdBQVcsRUFBRTlCLHlCQUFvQyxDQUFDLENBQUM7U0FDL0U7OztRQUtELElBQUksY0FBYyxFQUFFO1lBQ2hCLHVCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUN4RCxLQUFLLHVCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO2dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNwQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQzlFO2FBQ0o7WUFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxjQUFjLENBQUMsQ0FBQztTQUN6QztRQUVELElBQUksYUFBYSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2Qjs7Ozs7Ozs7OztJQUlLLGdCQUFnQixDQUFDLFlBQWlCLEVBQUUsVUFBZSxFQUFFLFdBQWdCLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtRQUVoSCxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUM7UUFFcEQsdUJBQU0sUUFBUSxHQUE2QixJQUFJLEtBQUssRUFBRSxDQUFDO1FBQ3ZELHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDZCxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsS0FBSyx1QkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtZQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNwQyxLQUFLLHVCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtvQkFDdkMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQzdDLElBQUksS0FBSyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTs0QkFDeEMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDMUM7d0JBQ0QsSUFBSSxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUN4QyxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUMxQzt3QkFDRCx1QkFBTSxnQkFBZ0IsR0FBRyxJQUFJLGlCQUFpQixDQUMxQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQzlCLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFDOUIsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUNqQyxDQUFFO3dCQUNILFFBQVEsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztxQkFDbkM7aUJBQ0o7YUFDSjtTQUNKO1FBQ0QsdUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFdEYsdUJBQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7UUFHcEMsdUJBQU0sYUFBYSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO1FBQ2hELHVCQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7UUFDcEMsdUJBQU0sUUFBUSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1FBQzFDLHVCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7UUFDaEQsdUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUNoRCx1QkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDL0MsdUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBRWpELHVCQUFNLE9BQU8sR0FBRyxZQUFZLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQzthQUN2QyxJQUFJLENBQUMsUUFBUSxDQUFDO2FBQ2QsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLFFBQVEsQ0FBQzthQUNoQixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBb0IsRUFBRSxDQUFNO1lBQ3JDLE9BQU8sU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDMUIsQ0FBQzthQUNELElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFvQixFQUFFLENBQU07WUFDckMsUUFBUSxTQUFTLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRTtTQUN2RCxDQUFDO2FBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQW9CLEVBQUUsQ0FBTTtZQUNwQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDZCxDQUFDO2FBQ0QsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQU0sRUFBRSxDQUFTO1lBQzdCLHVCQUFNLFNBQVMsR0FBRyxDQUFDLEdBQUcsYUFBYSxDQUFDO1lBQ3BDLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1NBQzVCLENBQUM7YUFDRCxJQUFJLENBQUMsY0FBYyxFQUFHLFFBQVEsQ0FBQyxDQUFDOztRQUl6QyxJQUFJLGFBQWEsRUFBRTtZQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDdkI7OztRQUlELElBQUksY0FBYyxFQUFFO1lBQ2hCLHVCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUN4RCxLQUFLLHFCQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNoRCxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUMzRTtZQUNELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1NBQ3pDOzs7UUFHRCxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXJCLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFckIsSUFBSSxhQUFhLEVBQUU7WUFDZixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3ZCO1FBQ0QsSUFBSSxhQUFhLEVBQUU7WUFDZixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3ZCOzs7Ozs7SUFLSyxTQUFTLENBQUMsUUFBYTtRQUU3QixPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7UUFFaEQsdUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztRQUNyQix1QkFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUNsQyx1QkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQztRQUV0Qyx1QkFBTSxNQUFNLEdBQUksR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUU5Qix1QkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUM1Qix1QkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUNyQyx1QkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUNyQyx1QkFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUNuQyx1QkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7UUFDakQsdUJBQU0sV0FBVyxHQUFHVSxXQUFjLEVBQUU7YUFDbkIsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQ2xCLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUNsRCx1QkFBTSxPQUFPLEdBQUdzQixLQUFRLENBQUMsTUFBTSxHQUFHLFlBQVksRUFDOUIsS0FBSyxHQUFJLFlBQVksRUFDckIsTUFBTSxHQUFHLFlBQVksQ0FBQyxDQUFDO1FBRXZDLFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ25CLFNBQVMsQ0FBQyxRQUFRLENBQUM7YUFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQzthQUNiLEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDZCxJQUFJLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQzthQUM3QixJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBTSxFQUFFLENBQVM7WUFDMUIsdUJBQU0sR0FBRyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxHQUFJLENBQUMsQ0FBQztZQUN4QyxPQUFPLEdBQUcsQ0FBQztTQUNkLENBQUM7YUFDRCxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDcEQsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDLENBQU0sRUFBRSxDQUFTO1lBQzFCLHVCQUFNLEdBQUcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksR0FBSSxDQUFDLENBQUM7WUFDeEMsT0FBTyxHQUFHLENBQUM7U0FDZCxDQUFDO2FBQ0QsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzs7Ozs7SUFHM0QsVUFBVSxDQUFDLFFBQWE7UUFFOUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO1FBRWhELHVCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7UUFDckIsdUJBQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7UUFDbEMsdUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7UUFFdEMsdUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUM7UUFDNUIsdUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7UUFFckMsdUJBQU0sV0FBVyxHQUFHdEIsV0FBYyxFQUFFO2FBQ25CLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUNsQixLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUM7UUFFbEQsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDbkIsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsYUFBYSxDQUFDO2FBQ2hDLElBQUksQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLHVCQUF1QixDQUFDO2FBQzlDLElBQUksQ0FDQ3VCLFVBQWEsQ0FBQyxXQUFXLENBQUMsQ0FDL0IsQ0FBQzs7Ozs7Ozs7Ozs7OztJQVFBLFFBQVEsQ0FBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7UUFFeEcsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1FBRTVDLHVCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDbEIsdUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUNsQix1QkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUV0Rix1QkFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLGdCQUFnQixDQUFDO1FBR3BDLHVCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO1FBR3JDLHVCQUFNLFFBQVEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUMxQyx1QkFBTSxZQUFZLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7UUFDN0MsdUJBQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQzNDLHVCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztRQUN6Qyx1QkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDL0MsdUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQ2pELHVCQUFNLG1CQUFtQixHQUFHLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztRQUNuRCx1QkFBTSx3QkFBd0IsR0FBRyxHQUFHLENBQUMsdUJBQXVCLENBQUM7UUFDN0QsdUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO1FBQy9DLHVCQUFNLGtCQUFrQixHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO1FBQ3ZELHVCQUFNLHVCQUF1QixHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDO1FBQ25FLHVCQUFNLDZCQUE2QixHQUFHLEdBQUcsQ0FBQyw0QkFBNEIsQ0FBQztRQUN2RSx1QkFBTSxpQkFBaUIsR0FBRyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7UUFDL0MsdUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1FBQy9DLHVCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUNqRCx1QkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDL0MsdUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUNuRCx1QkFBTSxlQUFlLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1FBQ3ZELHVCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUMvQyx1QkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUt6RCx1QkFBTSxPQUFPLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7UUFDM0MsS0FBSyx1QkFBTSxDQUFDLElBQU0sV0FBVyxDQUFDLElBQUksRUFBRTtZQUNoQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNwQyx1QkFBTSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ3ZDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDdEI7U0FDSjtRQUVELHVCQUFNLElBQUksR0FBR0MsR0FBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzdCLHVCQUFNQyxNQUFHLEdBQUdDLEdBQU0sRUFBRSxDQUFDO1FBQ3JCLHVCQUFNQyxNQUFHLEdBQUdDLEdBQU0sRUFBRTthQUNQLFdBQVcsQ0FBQyxZQUFZLEdBQUcsbUJBQW1CLEdBQUcsR0FBRyxDQUFDO2FBQ3JELFdBQVcsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFM0MsdUJBQU0sV0FBVyxHQUFHLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2FBQ3pCLElBQUksQ0FBQ0gsTUFBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ2xCLEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDWCxJQUFJLENBQUMsV0FBVyxFQUFFLHdCQUF3QixDQUFDLENBQUM7UUFHckUsdUJBQU0sZ0JBQWdCLEdBQUc7WUFDakIsSUFBSSxhQUFhLElBQUksZUFBZSxFQUFFO2dCQUNsQyx1QkFBTSxHQUFHLEdBQUcsaUJBQWlCLEdBQUcsR0FBRyxHQUFHLElBQUksR0FBSSxTQUFTLENBQUM7Z0JBQ3hELE9BQU8sR0FBRyxDQUFDO2FBQ2Q7WUFDRCxJQUFJLGVBQWUsRUFBRTtnQkFDakIsT0FBTyxNQUFNLENBQUM7YUFDakI7WUFDRCxJQUFJLGFBQWEsRUFBRTtnQkFDZixPQUFPLGlCQUFpQixHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7YUFDekM7U0FDUixDQUFDO1FBRUYsdUJBQU0sWUFBWSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ3ZCLElBQUksQ0FBQyxPQUFPLEVBQUUsdUJBQXVCLENBQUM7YUFDdEMsSUFBSSxDQUFDLFdBQVcsRUFBRSw2QkFBNkIsQ0FBRTthQUNqRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUVoRCx1QkFBTSxJQUFJLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDMUIsSUFBSSxDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7YUFDNUIsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQU0sRUFBRSxDQUFTO1lBQzdCLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3BCLENBQUM7YUFDRCxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7UUFzQjVDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFRSxNQUFHLENBQUMsQ0FBQztRQUVwQixXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNiLElBQUksQ0FBQyxPQUFPLEVBQUUsa0JBQWtCLENBQUM7YUFDakMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQU0sRUFBRSxDQUFTO1lBQ3JDLE9BQU8sWUFBWSxHQUFHQSxNQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUMzQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLENBQUMsQ0FBTSxFQUFFLENBQVM7WUFDcEIsSUFBSSxhQUFhLElBQUksZUFBZSxFQUFFO2dCQUNsQyx1QkFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLEdBQUksR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDNUQsdUJBQU0sR0FBRyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxHQUFHLFVBQVUsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZELE9BQU8sR0FBRyxDQUFDO2FBQ2Q7WUFDRCxJQUFJLGVBQWUsRUFBRTtnQkFDakIsdUJBQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxHQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQzVELHVCQUFNLEdBQUcsR0FBRyxVQUFVLEdBQUcsR0FBRyxDQUFDO2dCQUM3QixPQUFPLEdBQUcsQ0FBQzthQUNkO1lBQ0QsSUFBSSxhQUFhLEVBQUU7Z0JBQ2YsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDO2FBQ2xCO1NBQ0osQ0FBQyxDQUFDOztRQUdmLElBQUksYUFBYSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2Qjs7O1FBSUQsSUFBSSxjQUFjLEVBQUU7WUFDaEIsdUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ3hELEtBQUssdUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7Z0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQ3BDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDOUU7YUFDSjtZQUNELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1NBQ3pDOzs7Ozs7Ozs7O0lBS0ssUUFBUSxDQUFDLFlBQWlCLEVBQUUsVUFBZSxFQUFFLFdBQWdCLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtRQUV4RyxPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixDQUFDLENBQUM7UUFFNUMsdUJBQU0sU0FBUyxHQUFrQixJQUFJLEtBQUssRUFBRSxDQUFDO1FBQzdDLEtBQUssdUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7WUFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDcEMsS0FBSyx1QkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQ25DLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUN6Qyx1QkFBTSxFQUFFLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3BDLFNBQVMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7cUJBQ3RCO2lCQUNKO2FBQ0o7U0FDSjtRQUVELHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDZCxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsS0FBSyxHQUFHekIsR0FBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzFCLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDWix1QkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUV0Rix1QkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7UUFDckQsdUJBQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztRQUNwQyx1QkFBTSxVQUFVLEdBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDOUMsdUJBQU0sVUFBVSxHQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUM7UUFFckMsdUJBQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7UUFDcEMsdUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7UUFDckMsdUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7UUFFbkMsdUJBQU0sUUFBUSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1FBQzFDLHVCQUFNLFlBQVksR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztRQUM3Qyx1QkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDL0MsdUJBQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQzNDLHVCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztRQUN6Qyx1QkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDL0MsdUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQ2pELHVCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUNqRCx1QkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDL0MsdUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUNoRCx1QkFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7UUFDL0MsdUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7UUFFekQsdUJBQU0sU0FBUyxHQUFHLENBQUMsV0FBVyxJQUFJLGNBQWMsR0FBRyxVQUFVLEdBQUcsVUFBVSxDQUFDLElBQUssVUFBVSxDQUFDO1FBQzNGLHVCQUFNLFlBQVksSUFBSSxXQUFXLEdBQUcsVUFBVSxDQUFDLENBQUU7UUFFakQsdUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7UUFFckMsdUJBQU0sU0FBUyxHQUFHRixXQUFjLEVBQUU7YUFDakIsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQ2xCLEtBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVsRCx1QkFBTSxXQUFXLEdBQUcsY0FBYyxDQUFDO1FBS25DLHVCQUFNLFFBQVEsR0FBRyxZQUFZLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQzthQUN2QyxJQUFJLENBQUMsU0FBUyxDQUFDO2FBQ2YsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNYLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFNLEVBQUUsQ0FBUztZQUNqQyx1QkFBTSxRQUFRLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxVQUFVLE1BQU0sQ0FBQyxJQUFJLFdBQVcsR0FBRyxDQUFDLENBQUM7WUFDNUQsT0FBTyxZQUFZLElBQUksUUFBUSxHQUFHLFlBQVksR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7U0FDN0QsQ0FBQzthQUNELEtBQUssQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFNLEVBQUUsQ0FBUztZQUM3Qix1QkFBTSxRQUFRLElBQUksQ0FBQyxHQUFHLFVBQVUsQ0FBQyxDQUFDO1lBQ2xDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1NBQzNCLENBQUM7YUFDRCxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBRXBDLHVCQUFNLEtBQUssR0FBSSxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQ3ZDLElBQUksVUFBVSxFQUFFO1lBQ1osS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDO2lCQUMzQixJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQztpQkFDakIsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQU07Z0JBQ2QsT0FBTyxTQUFTLENBQUM7YUFDcEIsQ0FBQztpQkFDRCxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsR0FBRyxXQUFXLENBQUM7aUJBQ3RDLFVBQVUsRUFBRTtpQkFDWixRQUFRLENBQUMsa0JBQWtCLENBQUM7aUJBQzVCLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFNO2dCQUNkLE9BQU8sU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQzthQUNuQyxDQUFDO2lCQUNELElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFNO2dCQUNuQixPQUFPLFlBQVksR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUU7YUFDdkMsQ0FBQyxDQUFDO1NBQ047YUFBTTtZQUNILEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLFdBQVcsQ0FBQztpQkFDM0IsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQU07Z0JBQ2QsT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDO2FBQ25DLENBQUM7aUJBQ0QsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLEdBQUcsV0FBVyxDQUFDO2lCQUN0QyxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBTTtnQkFDbkIsT0FBTyxZQUFZLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3RDLENBQUMsQ0FBQztTQUNOO1FBRUQsdUJBQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDN0MsWUFBWTthQUNQLElBQUksQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO2FBQzdCLElBQUksQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDO2FBQ3RCLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFNO1lBQ2hCLE9BQU8sU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQztTQUNqQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLENBQUMsQ0FBTTtZQUNYLE9BQU8sQ0FBQyxDQUFFO1NBQ1gsQ0FBQyxDQUFDOzs7UUFJUCxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7UUFJckIsSUFBSSxhQUFhLEVBQUU7WUFDZix1QkFBTSxXQUFXLEdBQW1CLElBQUksS0FBSyxFQUFFLENBQUM7WUFDaEQsS0FBSyx1QkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtnQkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDcEMsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUMzQzthQUNKO1lBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFZCxtQkFBOEIsQ0FBQyxDQUFDO1NBQ3pFO1FBRUQsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O1FBSXhCLHVCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUN4RCxLQUFLLHVCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsTUFBTSxFQUFFO1lBQ2hDLElBQUksV0FBVyxDQUFDLE1BQU0sQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3hDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3pFO1NBQ0o7UUFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxjQUFjLENBQUMsQ0FBQzs7O1FBSXRDLElBQUksYUFBYSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2QjtRQUVELElBQUksYUFBYSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2Qjs7Ozs7Ozs7OztJQUtLLFNBQVMsQ0FBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7UUFFekcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1FBRS9DLHVCQUFNLFVBQVUsR0FBa0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUU5QyxLQUFLLHVCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO1lBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3BDLHFCQUFJLE1BQU0sR0FBRyxDQUFDLENBQUM7Z0JBQ2YsS0FBSyx1QkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7b0JBQ3ZDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUM3QyxJQUFJLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7NEJBQ3pDLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQzNDO3FCQUNKO2lCQUNKO2dCQUNELFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUU7YUFDNUI7U0FDSjtRQUNELHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDZCxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsS0FBSyxHQUFHZ0IsR0FBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzNCLEtBQUssR0FBRyxHQUFHLENBQUM7UUFFWix1QkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN0Rix1QkFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLGdCQUFnQixDQUFDO1FBRXBDLHVCQUFNLFVBQVUsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUU7UUFDckQsdUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxVQUFVLEdBQUcsVUFBVSxDQUFDO1FBRWpELE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUM7UUFFMUIsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUU7WUFDM0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2Qjs7UUFHRCxLQUFLLHVCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO1lBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3BDLHVCQUFNLFVBQVUsR0FBeUIsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDckQsS0FBSyx1QkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7b0JBQ3ZDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUM3Qyx1QkFBTSxPQUFPLEdBQUcsSUFBSSxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDbkYsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztxQkFDNUI7aUJBQ0o7Z0JBQ0QsdUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQzVCLElBQUksQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFVBQVUsRUFBRSxHQUFHLENBQUMsQ0FBQzthQUM3QztTQUNKOzs7UUFJRCxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7UUFJcEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUVyQixJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7UUFJeEIsdUJBQU0sV0FBVyxHQUFtQixJQUFJLEtBQUssRUFBRSxDQUFDO1FBQ2hELEtBQUssdUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO1lBQ3ZDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUM3QyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3BEO1NBQ0o7UUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUVqQixvQkFBK0IsQ0FBQyxDQUFDOzs7UUFJdkUsdUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO1FBQ3hELEtBQUssdUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7WUFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDdEMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLFlBQVksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzVFO1NBQ0o7UUFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxjQUFjLENBQUMsQ0FBQzs7Ozs7Ozs7SUFPaEMsY0FBYyxDQUFDLFFBQWEsRUFBRSxPQUFZLEVBQUUsT0FBZTtRQUVqRSxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUM7UUFFcEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNyQix1QkFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDO1FBQ3JCLHVCQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQ2xDLHVCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDO1FBRXRDLHVCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDO1FBQzVCLHVCQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsa0JBQWtCLENBQUM7UUFDekMsdUJBQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztRQUN6Qyx1QkFBTSxVQUFVLEdBQUcsT0FBTyxDQUFDLE1BQU0sQ0FBQztRQUNsQyx1QkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFVBQVUsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFDdkQsdUJBQU0sTUFBTSxHQUFHSixZQUFlLENBQUNFLGdCQUFtQixDQUFDLENBQUM7UUFFcEQsdUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsZUFBZSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUM5RSx1QkFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7UUFDM0MsdUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO1FBRS9DLHVCQUFNLE9BQU8sR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO1FBR2hDLHVCQUFNOEMsT0FBSSxHQUFHQyxJQUFPLEVBQUU7YUFDakIsS0FBSyxDQUFDQyxXQUFjLENBQUM7YUFDckIsQ0FBQyxDQUFFLENBQUMsQ0FBTTtZQUNQLE9BQU8sV0FBVyxHQUFHLENBQUMsQ0FBQyxFQUFFLEdBQUcsWUFBWSxDQUFDO1NBQzVDLENBQUM7YUFDRCxDQUFDLENBQUUsQ0FBQyxDQUFNO1lBQ1AsT0FBTyxHQUFHLENBQUMsU0FBUyxHQUFHLGFBQWEsSUFBSyxDQUFDLENBQUMsS0FBSyxHQUFHLE9BQU8sQ0FBQyxDQUFFO1NBQ2hFLENBQUMsQ0FBQztRQUVQLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ2xCLElBQUksQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO2FBQzdCLElBQUksQ0FBQyxHQUFHLEVBQUVGLE9BQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDOzs7Ozs7OztJQVE1QixXQUFXLENBQUMsUUFBYSxFQUFFLGNBQW1CO1FBRXBELE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQzs7UUFHakQsdUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztRQUNyQix1QkFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUNsQyx1QkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQzs7UUFFdEMsdUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDO1FBQ25ELHVCQUFNLGFBQWEsR0FBRyxFQUFFLENBQUM7UUFDekIsdUJBQU0sUUFBUSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQzVDLHVCQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsY0FBYyxDQUFDO1FBQ3BDLHVCQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsY0FBYyxDQUFDO1FBQ3BDLHVCQUFNLE9BQU8sR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUV6Qyx1QkFBTSxTQUFTLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDN0IsU0FBUyxDQUFDLEdBQUcsQ0FBQzthQUNkLElBQUksQ0FBQyxjQUFjLENBQUM7YUFDcEIsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNYLElBQUksQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDO2FBQ3ZCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFlLEVBQUUsQ0FBUztZQUMxQyx1QkFBTSxNQUFNLEdBQUcsY0FBYyxHQUFHLFFBQVEsQ0FBQztZQUN6Qyx1QkFBTSxDQUFDLEdBQUcsUUFBUSxDQUFDO1lBQ25CLHVCQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxHQUFHLFFBQVEsQ0FBRTtZQUNqQyxPQUFPLFlBQVksR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUM7U0FDNUMsQ0FBQyxDQUFDO1FBRWYsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDbkIsSUFBSSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUM7YUFDN0IsSUFBSSxDQUFDLFFBQVEsRUFBRSxjQUFjLENBQUM7YUFDOUIsS0FBSyxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQWU7WUFDM0IsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDO1NBQ2xCLENBQUM7YUFDRCxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBZTtZQUM3QixPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7U0FDbEIsQ0FBQzthQUNELElBQUksQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFbkMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDbkIsSUFBSSxDQUFDLEdBQUcsRUFBRSxjQUFjLEdBQUcsYUFBYSxDQUFDO2FBQ3pDLElBQUksQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDO2FBQ3pCLElBQUksQ0FBQyxDQUFDLENBQWU7WUFDbEIsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDO1NBQ2xCLENBQUMsQ0FBQzs7Ozs7Ozs7SUFJRCxjQUFjLENBQUMsUUFBYSxFQUFFLFlBQWlCLEVBQUUsU0FBaUI7UUFFeEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDO1FBRXBELHVCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7UUFDckIsdUJBQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7UUFDbEMsdUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7O1FBR3RDLHVCQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsa0JBQWtCLENBQUM7UUFDekMsdUJBQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztRQUV6Qyx1QkFBTSxVQUFVLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQztRQUN2QyxxQkFBSSxZQUFZLEdBQUcsR0FBRyxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7UUFDL0MsSUFBSyxTQUFTLEtBQUs1QyxvQkFBK0IsRUFBRTtZQUNoRCxZQUFZLEdBQUcsR0FBRyxDQUFDLFVBQVUsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDcEQ7UUFFRCx1QkFBTSxRQUFRLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDNUIsU0FBUyxDQUFDLEdBQUcsQ0FBQzthQUNkLElBQUksQ0FBQyxZQUFZLENBQUM7YUFDbEIsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNYLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLFNBQVMsQ0FBQzthQUNuQyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBTSxFQUFFLENBQVM7WUFDakMsdUJBQU0sRUFBRSxHQUFHLFNBQVMsR0FBRyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1lBQ3hDLHVCQUFNLEVBQUUsR0FBRyxTQUFTLENBQUU7WUFDdEIsT0FBTyxZQUFZLEdBQUcsRUFBRSxHQUFHLElBQUksR0FBRyxFQUFFLEdBQUcsR0FBRyxDQUFDO1NBQzlDLENBQUMsQ0FBQztRQUVmLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ1YsSUFBSSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQzthQUM3QyxJQUFJLENBQUMsQ0FBQyxDQUFNLEVBQUUsQ0FBUztZQUNwQixPQUFPLENBQUMsQ0FBQztTQUNaLENBQUMsQ0FBQzs7Ozs7O0lBTVQsYUFBYSxDQUFDLFFBQWE7UUFFakMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO1FBRW5ELHVCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7UUFDckIsdUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7UUFFdEMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDdEIsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsd0JBQXdCLENBQUM7YUFDM0MsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsZ0JBQWdCLENBQUM7YUFDbkMsSUFBSSxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUMsb0JBQW9CLENBQUM7YUFDeEMsSUFBSSxDQUFDLFdBQVcsRUFBRSxHQUFHLENBQUMsdUJBQXVCLENBQUMsQ0FBQzs7Ozs7O0lBUTlDLFVBQVUsQ0FBQyxRQUFhO1FBRTlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLENBQUMsQ0FBQztRQUVoRCx1QkFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDO1FBQ3JCLHVCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDO1FBRXRDLHVCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDO1FBQzVCLHVCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO1FBRXJDLHVCQUFNLFdBQVcsR0FBR2UsV0FBYyxFQUFFO2FBQ25CLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzthQUNsQixLQUFLLENBQUMsQ0FBQyxLQUFLLEdBQUcsWUFBWSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFbEQsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDbkIsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsYUFBYSxDQUFDO2FBQ2hDLElBQUksQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLGdCQUFnQixDQUFDO2FBQ3ZDLElBQUksQ0FDQ2dDLFFBQVcsQ0FBQyxXQUFXLENBQUMsQ0FDdkIsQ0FBQzs7Ozs7O0lBT04sU0FBUyxDQUFDLFFBQWE7UUFFN0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1FBRS9DLHVCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7UUFDckIsdUJBQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7UUFDbEMsdUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7UUFFdEMsdUJBQU0sTUFBTSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQ3JDLHVCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsYUFBYSxDQUFDO1FBQ2hDLHVCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsYUFBYSxDQUFDO1FBQ2hDLHVCQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztRQUVuRCxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUN0QixJQUFJLENBQUMsT0FBTyxFQUFFLGVBQWUsQ0FBQzthQUM5QixJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQzthQUNoQixJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQzthQUNoQixJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Ozs7OztJQU9aLFNBQVMsQ0FBQyxRQUFhO1FBRTdCLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLENBQUMsQ0FBQztRQUVoRCx1QkFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDO1FBQ3JCLHVCQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQ2xDLHVCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDO1FBRXRDLHVCQUFNLE1BQU0sR0FBSSxHQUFHLENBQUMsU0FBUyxDQUFDO1FBQzlCLHVCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDO1FBQzVCLHVCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO1FBQ3JDLHVCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztRQUNqRCx1QkFBTSxPQUFPLEdBQUdWLEtBQVEsQ0FBQyxNQUFNLEdBQUcsWUFBWSxFQUM5QixLQUFLLEdBQUcsWUFBWSxFQUNwQixNQUFNLEdBQUcsWUFBWSxDQUFDLENBQUM7UUFFdkMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDbkIsU0FBUyxDQUFDLFFBQVEsQ0FBQzthQUNuQixJQUFJLENBQUMsT0FBTyxDQUFDO2FBQ2IsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNkLElBQUksQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO2FBQzdCLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7YUFDbEMsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFFLENBQU0sRUFBRSxDQUFTO1lBQzNCLHVCQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUN6RCxPQUFPLEdBQUcsQ0FBQztTQUNkLENBQUM7YUFDRCxJQUFJLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQzthQUN6RCxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUUsQ0FBTSxFQUFFLENBQVM7WUFDM0IsdUJBQU0sR0FBRyxHQUFHLEdBQUcsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1lBQ3pELE9BQU8sR0FBRyxDQUFDO1NBQ2QsQ0FBQyxDQUFDOzs7O1lBaHFEUixTQUFTLFNBQUM7Z0JBQ1QsUUFBUSxFQUFFLGdCQUFnQjtnQkFDMUIsUUFBUSxFQUFFLEVBQUU7Z0JBQ1osTUFBTSxFQUFFLEVBQUU7YUFDWDs7OztZQVhvRCxVQUFVOzs7d0JBYTVELEtBQUs7dUJBQ0wsS0FBSzt3QkFDTCxLQUFLO3dCQUNMLEtBQUs7eUJBQ0wsS0FBSzs7Ozs7OztBQ2pCUjs7O1lBR0MsUUFBUSxTQUFDO2dCQUNSLE9BQU8sRUFBRSxFQUNSO2dCQUNELFlBQVksRUFBRSxDQUFDLG1CQUFtQixDQUFDO2dCQUNuQyxPQUFPLEVBQUUsQ0FBQyxtQkFBbUIsQ0FBQzthQUMvQjs7Ozs7Ozs7Ozs7Ozs7OyJ9