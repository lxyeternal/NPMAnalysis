import { select, format, scaleLinear, histogram, max, forceSimulation, forceLink, forceManyBody, forceCenter, drag, event, interpolateHsl, geoPath, geoMercator, json, scaleOrdinal, schemeCategory10, pack, hierarchy, tree, geoOrthographic, timer, stack, range, axisBottom, sum, pie, arc, line, curveLinear, axisLeft, schemeCategory20 } from 'd3';
import { Component, Input, ElementRef, NgModule } from '@angular/core';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var /** @type {?} */ LINE_CHART_TYPE_NAME = 'line';
var /** @type {?} */ BAR_CHART_TYPE_NAME = 'bar';
var /** @type {?} */ PIE_CHART_TYPE_NAME = 'pie';
var /** @type {?} */ SCATTER_PLOT_CHART_TYPE_NAME = 'scatterPlot';
var /** @type {?} */ HISTOGRAM_CHART_TYPE_NAME = 'histogram';
var /** @type {?} */ STACK_BAR_CHART_TYPE_NAME = 'stackBar';
var /** @type {?} */ GEO_MAP_CHART_TYPE_NAME = 'geoMap';
var /** @type {?} */ GEO_ORTHOGRAPHIC_CHART_TYPE_NAME = 'geoOrthographic';
var /** @type {?} */ TREE_MAP_CHART_TYPE_NAME = 'treeMap';
var /** @type {?} */ PACK_LAYOUT_CHART_TYPE_NAME = 'packLayout';
var /** @type {?} */ CHOROPLETH_CHART_TYPE_NAME = 'choropleth';
var /** @type {?} */ TREE_CHART_TYPE_NAME = 'tree';
var /** @type {?} */ SANKEY_CHART_TYPE_NAME = 'sankey';
var /** @type {?} */ FORCE_CHART_TYPE_NAME = 'force';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var O2Common = /** @class */ (function () {
    function O2Common(svgContainer, configData, autoMaxX, autoMaxY, svgWidth, svgHeight) {
        this.svgContainer = svgContainer;
        this.configData = configData;
        this.autoMaxX = autoMaxX;
        this.autoMaxY = autoMaxY;
        this.svgWidth = svgWidth;
        this.svgHeight = svgHeight;
    }
    Object.defineProperty(O2Common.prototype, "axisClassName", {
        get: /**
         * @return {?}
         */
        function () {
            return this.configData.className.axis;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "lineClassName", {
        get: /**
         * @return {?}
         */
        function () {
            return this.configData.className.line;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "axisXBorderLineClassName", {
        get: /**
         * @return {?}
         */
        function () {
            return this.configData.className.axisXBorder;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "maxXValue", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _maxX = this.autoMaxX;
            if (!this.configData.maxValue.auto) {
                _maxX = this.configData.maxValue.x;
            }
            return _maxX;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "maxYValue", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _maxY = this.autoMaxY;
            if (!this.configData.maxValue.auto) {
                _maxY = this.configData.maxValue.y;
            }
            return _maxY;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "graphInitXPos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _intX = this.configData.margin.left;
            if (this.configData.legend.display && this.configData.legend.position !== 'right') {
                _intX = this.configData.margin.left
                    + this.configData.legend.totalWidth;
            }
            return _intX;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "graphInitYPos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _intY = this.configData.margin.top
                + this.configData.title.height;
            return _intY;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "graphYScale", {
        get: /**
         * @return {?}
         */
        function () {
            return this.graphHeight / this.maxYValue;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "graphXScale", {
        get: /**
         * @return {?}
         */
        function () {
            return this.graphWidth / this.maxXValue;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "graphWidth", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _margin = this.configData.margin.left
                + this.configData.margin.right;
            if (this.configData.legend.display) {
                _margin += this.configData.legend.totalWidth;
            }
            return this.svgWidth - _margin;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "graphHeight", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _h = this.svgHeight
                - this.configData.title.height
                - this.configData.margin.top
                - this.configData.margin.bottom;
            return _h;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "graphCenterPos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _xyArray = new Array();
            var /** @type {?} */ _x = this.configData.margin.left
                + this.graphWidth / 2;
            var /** @type {?} */ _y = this.configData.margin.top
                + this.configData.title.height
                + this.graphHeight / 2;
            _xyArray.push(_x);
            _xyArray.push(_y);
            return _xyArray;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "graphCenterTranslatePos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _x = this.configData.margin.left
                + this.graphWidth / 2;
            var /** @type {?} */ _y = this.configData.margin.top
                + this.configData.title.height
                + this.graphHeight / 2;
            return 'translate(' + String(_x) + ', ' + String(_y) + ')';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "graphInitTranslatePos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _x = this.graphInitXPos;
            var /** @type {?} */ _y = this.graphInitYPos;
            return 'translate(' + String(_x) + ', ' + String(_y) + ')';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "axisXLabelInitXPos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _x = this.configData.margin.left
                + this.configData.axis.xLabel.leftMargin;
            return _x;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "axisXLabelInitYPos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _y = this.svgHeight
                - this.configData.axis.xLabel.bottomMargin;
            return _y;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "axisTranslatePos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _x = this.configData.margin.left;
            var /** @type {?} */ _y = this.configData.margin.top
                + this.configData.title.height;
            return 'translate(' + String(_x) + ', ' + String(_y) + ')';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "axisXBorderLineWidth", {
        get: /**
         * @return {?}
         */
        function () {
            return this.configData.axis.borderLineWidth;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "axisYBorderHeight", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _margin = this.configData.margin.top
                + this.configData.margin.bottom
                + this.configData.title.height;
            return this.svgHeight - _margin;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "axisXBorderWidth", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _margin = this.configData.margin.left
                + this.configData.margin.right;
            if (this.configData.legend.display) {
                _margin += this.configData.legend.totalWidth;
            }
            return this.svgWidth - _margin;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "axisYOrient", {
        get: /**
         * @return {?}
         */
        function () {
            return 'left';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "axisXOrient", {
        get: /**
         * @return {?}
         */
        function () {
            return 'bottom';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "axisXBorderTranslatePos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ sYpos = String(this.svgHeight - this.configData.margin.bottom);
            return 'translate(' + this.configData.margin.left + ', ' + sYpos + ')';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "innerRadiusPercent", {
        get: /**
         * @return {?}
         */
        function () {
            return this.configData.pie.innerRadius.percent;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "innerRadiusTitle", {
        get: /**
         * @return {?}
         */
        function () {
            return this.configData.pie.innerRadius.title;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "innerRadiusTitleTranslatePos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _x = this.configData.margin.left
                + this.graphWidth / 2;
            var /** @type {?} */ _y = this.configData.margin.top
                + this.configData.title.height
                + this.graphHeight / 2
                + 5;
            return 'translate(' + String(_x) + ', ' + String(_y) + ')';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "legendInitXPos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _x = this.configData.margin.left
                + this.graphWidth
                + this.configData.legend.initXPos;
            if (this.configData.legend.position !== 'right') {
                _x = this.configData.margin.left
                    + this.configData.legend.initXPos;
            }
            return _x;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "legendInitYPos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _y = this.configData.margin.top
                + this.configData.title.height
                + this.configData.legend.initYPos;
            return _y;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "gridYStep", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _maxY = Math.ceil(this.maxYValue / 100) * 10;
            var /** @type {?} */ _lineNum = 10;
            var /** @type {?} */ _step = Math.ceil(_maxY / _lineNum) * _lineNum;
            return _step;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "gridXStep", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _maxX = Math.ceil(this.maxXValue / 100) * 10;
            var /** @type {?} */ _lineNum = 10;
            var /** @type {?} */ _step = Math.ceil(_maxX / _lineNum) * _lineNum;
            return _step;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "titleInitXPos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _x = this.configData.margin.left
                + (this.graphWidth + this.configData.legend.totalWidth) / 2
                + this.configData.title.leftMargin;
            return _x;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "titleInitYPos", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _y = this.configData.margin.top
                + this.configData.title.height
                - this.configData.title.bottomMargin;
            return _y;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(O2Common.prototype, "defaultColorFunc", {
        get: /**
         * @return {?}
         */
        function () {
            var /** @type {?} */ _color;
            if (this.configData.color.auto) {
                if (this.configData.color.defaultColorNumber === '20') {
                    _color = scaleOrdinal(schemeCategory20);
                }
                else {
                    _color = scaleOrdinal(schemeCategory10);
                }
            }
            return _color;
        },
        enumerable: true,
        configurable: true
    });
    return O2Common;
}());
var O2LegendData = /** @class */ (function () {
    function O2LegendData(title, color) {
        this.title = title;
        this.color = color;
    }
    return O2LegendData;
}());
var O2ScatterPlotData = /** @class */ (function () {
    function O2ScatterPlotData(x, y, r) {
        this.x = x;
        this.y = y;
        this.r = r;
    }
    return O2ScatterPlotData;
}());
var O2IdValueData = /** @class */ (function () {
    function O2IdValueData(id, value) {
        this.id = id;
        this.value = value;
    }
    return O2IdValueData;
}());
// export class O2KeyValueData {
//     constructor(
//        public key: string,
// 	   public value: number
//        ) { }
// }
// export class O2DateKVArrayData {
//     constructor(
//        public date: Date,
// 	   public kvArray: Array<O2KeyValueData>
//        ) { }
// }
// export class O2DateStKVArrayData {
//     constructor(
//        public dateSt: string,
// 	   public kvArray: Array<O2KeyValueData>
//        ) { }
// }

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var Ng6O2ChartComponent = /** @class */ (function () {
    function Ng6O2ChartComponent(elementRef) {
        console.log('el:HTMLElement-------------------');
        var /** @type {?} */ el = elementRef.nativeElement;
        this.root = select(el);
    }
    /**
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
    };
    /**
     * @param {?} changes
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.ngOnChanges = /**
     * @param {?} changes
     * @return {?}
     */
    function (changes) {
        var /** @type {?} */ svgWidth = parseInt(this.svgWidth, 10);
        var /** @type {?} */ svgHeight = parseInt(this.svgHeight, 10);
        var /** @type {?} */ dataSet = this.graphData;
        var /** @type {?} */ configData = this.configData;
        var /** @type {?} */ chartType = this.chartType;
        var /** @type {?} */ svgContainer = this.root.append('svg')
            .attr('width', svgWidth)
            .attr('height', svgHeight);
        console.log(chartType);
        switch (chartType) {
            case LINE_CHART_TYPE_NAME:
                this.buildLine(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case BAR_CHART_TYPE_NAME:
                this.buildBar(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case PIE_CHART_TYPE_NAME:
                this.buildPie(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case SCATTER_PLOT_CHART_TYPE_NAME:
                this.buildScatterPlot(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case HISTOGRAM_CHART_TYPE_NAME:
                this.buildHistogram(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case STACK_BAR_CHART_TYPE_NAME:
                this.buildStackBar(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case GEO_MAP_CHART_TYPE_NAME:
                this.buildGeoMap(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case GEO_ORTHOGRAPHIC_CHART_TYPE_NAME:
                this.buildGeoOrthographic(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case TREE_CHART_TYPE_NAME:
                this.buildTree(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case PACK_LAYOUT_CHART_TYPE_NAME:
                this.buildPackLayout(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case CHOROPLETH_CHART_TYPE_NAME:
                this.buildChoropleth(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case FORCE_CHART_TYPE_NAME:
                this.buildForce(svgContainer, configData, dataSet, svgWidth, svgHeight);
                break;
            case TREE_MAP_CHART_TYPE_NAME:
                //  this.buildTreeMap(svgContainer,configData, dataSet,svgWidth,svgHeight );
                break;
            case SANKEY_CHART_TYPE_NAME:
                //  this.buildSankey(svgContainer,configData, dataSet,svgWidth,svgHeight );
                break;
            default:
                break;
        }
    };
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildHistogram = /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in buildHistogram-------------------');
        var /** @type {?} */ dataSet = dataSetJson.data;
        var /** @type {?} */ _binNumber = dataSetJson.bins.length - 1;
        var /** @type {?} */ _maxY = 300; // dummy number
        var /** @type {?} */ _maxX = dataSetJson.range[1];
        var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        var /** @type {?} */ _graphWidth = cdt.graphWidth;
        var /** @type {?} */ _graphHeight = cdt.graphHeight;
        var /** @type {?} */ _graphInitX = cdt.graphInitXPos;
        var /** @type {?} */ _graphInitY = cdt.graphInitYPos;
        var /** @type {?} */ _titleDisplay = configData.title.display;
        var /** @type {?} */ _animation = configData.animation.enable;
        var /** @type {?} */ _animationDuration = configData.animation.duration;
        var /** @type {?} */ _gridYDisplay = configData.grid.y.display;
        var /** @type {?} */ _marginLeft = configData.margin.left;
        var /** @type {?} */ _marginTop = configData.margin.top;
        var /** @type {?} */ _className = configData.className.histogramBar;
        var /** @type {?} */ _dataSet = new Array();
        for (var /** @type {?} */ i in dataSet) {
            if (dataSet.hasOwnProperty(i)) {
                var /** @type {?} */ _num = dataSet[i] / _maxX;
                _dataSet.push(_num);
            }
        }
        var /** @type {?} */ formatCount = format(',.0f');
        var /** @type {?} */ _histgramContainer = svgContainer
            .append('g')
            .attr('transform', 'translate(' + _graphInitX + ',' + _graphInitY + ')');
        var /** @type {?} */ _xScale = scaleLinear()
            .rangeRound([0, _graphWidth]);
        var /** @type {?} */ bins = histogram()
            .domain([0, 1])
            .thresholds(_xScale.ticks(_binNumber))(_dataSet);
        var /** @type {?} */ _yScale = scaleLinear()
            .domain([0, max(bins, function (d) {
                return d.length;
            })])
            .range([_graphHeight, 0]);
        var /** @type {?} */ bar = _histgramContainer
            .selectAll('.bar')
            .data(bins)
            .enter()
            .append('g')
            .attr('class', _className)
            .attr('transform', function (d) {
            return 'translate(' + _xScale(d.x0) + ',' + _yScale(d.length) + ')';
        });
        if (_animation) {
            bar.append('rect')
                .attr('x', 1)
                .attr('width', _xScale(bins[0].x1) - _xScale(bins[0].x0) - 1)
                .attr('height', 0)
                .transition()
                .duration(_animationDuration)
                .attr('height', function (d) {
                return _graphHeight - _yScale(d.length);
            });
        }
        else {
            bar.append('rect')
                .attr('x', 1)
                .attr('width', _xScale(bins[0].x1) - _xScale(bins[0].x0) - 1)
                .attr('height', function (d) {
                return _graphHeight - _yScale(d.length);
            });
        }
        bar.append('text')
            .attr('dy', '.75em')
            .attr('y', 6)
            .attr('x', (_xScale(bins[0].x1) - _xScale(bins[0].x0)) / 2)
            .attr('text-anchor', 'middle')
            .text(function (d) {
            return formatCount(d.length);
        });
        // ---CALL buildTitle-----------------
        if (_titleDisplay) {
            this.drawTitle(cdt);
        }
        // ------------------------------------
        // ---CALL buildAxis-----------------
        this.buildYAxis(cdt);
        this.buildXAxis(cdt);
        if (_gridYDisplay) {
            this.drawYGrid(cdt);
        }
    };
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildForce = /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('In  buildFoce----------------');
        var /** @type {?} */ _maxX = 100;
        var /** @type {?} */ _maxY = 100;
        var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        var /** @type {?} */ _color = cdt.defaultColorFunc;
        var /** @type {?} */ _graphHeight = cdt.graphHeight;
        var /** @type {?} */ _graphWidth = cdt.graphWidth;
        var /** @type {?} */ _marginLeft = configData.margin.left;
        var /** @type {?} */ _marginTop = configData.margin.top;
        var /** @type {?} */ simulation = forceSimulation()
            .force('link', forceLink().id(function (d) {
            return d.id;
        }))
            .force('charge', forceManyBody())
            .force('center', forceCenter(_graphWidth / 2, _graphHeight / 2));
        var /** @type {?} */ _forceContainer = svgContainer
            .append('g')
            .attr('transform', 'translate(' + _marginLeft + ',' + _marginTop + ')');
        var /** @type {?} */ link = _forceContainer.append('g')
            .attr('class', 'force-links')
            .selectAll('line')
            .data(dataSetJson.links)
            .enter()
            .append('line')
            .attr('stroke-width', function (d) {
            return Math.sqrt(d.value);
        });
        var /** @type {?} */ node = _forceContainer.append('g')
            .attr('class', 'nodes')
            .selectAll('circle')
            .data(dataSetJson.nodes)
            .enter()
            .append('circle')
            .attr('r', 5)
            .attr('fill', function (d) {
            return _color(d.group);
        })
            .call(drag()
            .on('start', dragstarted)
            .on('drag', dragged)
            .on('end', dragended));
        node.append('title')
            .text(function (d) {
            return d.id;
        });
        simulation
            .nodes(dataSetJson.nodes)
            .on('tick', ticked);
        var /** @type {?} */ _forceLink = simulation.force('link');
        _forceLink.links(dataSetJson.links);
        /**
         * @return {?}
         */
        function ticked() {
            link
                .attr('x1', function (d) {
                return d.source.x;
            })
                .attr('y1', function (d) {
                return d.source.y;
            })
                .attr('x2', function (d) {
                return d.target.x;
            })
                .attr('y2', function (d) {
                return d.target.y;
            });
            node
                .attr('cx', function (d) {
                return d.x;
            })
                .attr('cy', function (d) {
                return d.y;
            });
        }
        /**
         * @param {?} d
         * @return {?}
         */
        function dragstarted(d) {
            if (!event.active) {
                simulation.alphaTarget(0.3).restart();
            }
            d.fx = d.x;
            d.fy = d.y;
        }
        /**
         * @param {?} d
         * @return {?}
         */
        function dragged(d) {
            d.fx = event.x;
            d.fy = event.y;
        }
        /**
         * @param {?} d
         * @return {?}
         */
        function dragended(d) {
            if (!event.active) {
                simulation.alphaTarget(0);
            }
            d.fx = null;
            d.fy = null;
        }
        //  ------------------------------------
        //  ---CALL buildLegend-----------------
        var /** @type {?} */ _legendDataSet = new Array();
        for (var /** @type {?} */ i in dataSetJson.groups) {
            if (dataSetJson.groups.hasOwnProperty(i)) {
                var /** @type {?} */ _id = dataSetJson.groups[i].id;
                _legendDataSet.push(new O2LegendData(dataSetJson.groups[i].name, _color(_id)));
            }
        }
        this.buildLegend(cdt, _legendDataSet);
    };
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildChoropleth = /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in buildChoropleth -------------------');
        var /** @type {?} */ _maxX = 100; // any value
        var /** @type {?} */ _maxY = 100; // any value
        var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        var /** @type {?} */ _graphCenterPos = cdt.graphCenterPos;
        var /** @type {?} */ _titleDisplay = configData.title.display;
        var /** @type {?} */ _legendDisplay = configData.legend.display;
        var /** @type {?} */ _focusColor = configData.color.focusColor;
        var /** @type {?} */ _scale = dataSetJson.map.scale;
        var /** @type {?} */ _targetName = dataSetJson.map.targetName;
        var /** @type {?} */ _keyDataName = dataSetJson.map.keyDataName;
        var /** @type {?} */ _keyName = 'data.' + _keyDataName;
        var /** @type {?} */ _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
        var /** @type {?} */ _startColor = dataSetJson.map.startColor;
        var /** @type {?} */ _endColor = dataSetJson.map.endColor;
        var /** @type {?} */ _colorNum = dataSetJson.map.colorNumber;
        var /** @type {?} */ _center = dataSetJson.map.center;
        var /** @type {?} */ _targetPropertyName = dataSetJson.map.targetPropertyName;
        var /** @type {?} */ _targetProperty = 'd.' + _targetPropertyName;
        var /** @type {?} */ color = interpolateHsl(_startColor, _endColor);
        var /** @type {?} */ _max = dataSetJson.data[0].value;
        var /** @type {?} */ _min = dataSetJson.data[0].value;
        for (var /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                if (_max < dataSetJson.data[i].value) {
                    _max = dataSetJson.data[i].value;
                }
                if (_min > dataSetJson.data[i].value) {
                    _min = dataSetJson.data[i].value;
                }
            }
        }
        var /** @type {?} */ _range = _max - _min;
        var /** @type {?} */ _step = _range / (_colorNum - 1);
        var /** @type {?} */ _findColorById = function (id) {
            for (var /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    if (id === dataSetJson.data[i].id) {
                        var /** @type {?} */ _value = dataSetJson.data[i].value;
                        var /** @type {?} */ _rate = Math.ceil((_value - _min) / _step);
                        return color(_rate / _max);
                    }
                }
            }
        };
        var /** @type {?} */ path = geoPath()
            .projection(geoMercator()
            .center(_center)
            .scale(_scale)
            .translate(_graphCenterPos));
        json(_geoMapDataUrl, function (error, data) {
            svgContainer.selectAll('path')
                .data(eval(_keyName))
                .enter()
                .append('path')
                .attr('d', path)
                .style('fill', function (d, i) {
                var /** @type {?} */ _cl = _findColorById(eval(_targetProperty));
                return _cl;
            });
        });
        // ------------------------------------
        // ---CALL buildTitle-----------------
        if (_titleDisplay) {
            this.drawTitle(cdt);
        }
        //  ------------------------------------
        //  ---CALL buildLegend-----------------
        if (_legendDisplay) {
            var /** @type {?} */ _legendDataSet = new Array();
            for (var /** @type {?} */ i = 0; i < _colorNum; i++) {
                var /** @type {?} */ _label = String(_min + (i * _step)) + ' --';
                _legendDataSet.push(new O2LegendData(_label, color(i / _max)));
            }
            this.buildLegend(cdt, _legendDataSet);
        }
    };
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildPackLayout = /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in PackLayout------------------');
        var /** @type {?} */ _packlayoutClass = configData.className.packlayout;
        var /** @type {?} */ _packlayoutLabelClass = configData.className.packlayoutLabel;
        var /** @type {?} */ _animation = configData.animation.enable;
        var /** @type {?} */ _animationDuration = configData.animation.duration;
        var /** @type {?} */ color = scaleOrdinal(schemeCategory10);
        //  const color = d3.scale.category10();
        var /** @type {?} */ bubble = pack()
            .size([svgWidth, svgHeight]);
        var /** @type {?} */ nodes0 = hierarchy(dataSetJson);
        var /** @type {?} */ pack$$1 = svgContainer.selectAll('g')
            .data(bubble(nodes0).descendants())
            .enter()
            .append('g')
            .attr('transform', function (d, i) {
            return 'translate(' + d.x + ',' + d.y + ')';
        });
        var /** @type {?} */ _circle = pack$$1.append('circle');
        if (_animation) {
            _circle.attr('r', 0)
                .transition()
                .duration(function (d, i) {
                return d.depth * _animationDuration + 500;
            })
                .attr('r', function (d) {
                return d.r;
            })
                .style('fill', function (d, i) {
                return color(i);
            });
        }
        else {
            _circle.attr('r', function (d) {
                return d.r;
            })
                .style('fill', function (d, i) {
                return color(i);
            });
        }
        var /** @type {?} */ _text = pack$$1.append('text')
            .attr('class', _packlayoutLabelClass)
            .text(function (d, i) {
            if (d.depth === 1) {
                return d.data.name;
            }
            return null;
        });
        if (_animation) {
            _text.style('opacity', 0)
                .transition()
                .duration(_animationDuration)
                .style('opacity', 1.0);
        }
        else {
            _text.style('opacity', 1.0);
        }
    };
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildTree = /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('In  buildTree----------------');
        var /** @type {?} */ _maxX = 0;
        var /** @type {?} */ _maxY = 0;
        _maxY = 100;
        _maxX = 100;
        var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        var /** @type {?} */ _graphHeight = cdt.graphHeight;
        var /** @type {?} */ _graphWidth = cdt.graphWidth;
        var /** @type {?} */ _animation = configData.animation.enable;
        var /** @type {?} */ _animationDuration = configData.animation.duration;
        var /** @type {?} */ _treemapClass = configData.className.treemap;
        var /** @type {?} */ _treemapLabelClass = configData.className.treemapLabel;
        var /** @type {?} */ _marginLeft = configData.margin.left;
        var /** @type {?} */ _marginTop = configData.margin.top;
        var /** @type {?} */ tree$$1 = tree()
            .size([_graphWidth, _graphHeight]);
        var /** @type {?} */ nodes0 = hierarchy(dataSetJson);
        var /** @type {?} */ nodes = tree$$1(nodes0);
        var /** @type {?} */ _treeContainer = svgContainer
            .append('g')
            .attr('transform', 'translate(' + _marginLeft + ',' + _marginTop + ')');
        var /** @type {?} */ link = _treeContainer
            .selectAll('.link')
            .data(nodes.descendants().slice(1))
            .enter()
            .append('path')
            .attr('class', 'tree-node-link')
            .attr('d', function (d) {
            return 'M' + d.x + ',' + d.y
                + 'C' + d.x + ',' + (d.y + d.parent.y) / 2
                + ' ' + d.parent.x + ',' + (d.y + d.parent.y) / 2
                + ' ' + d.parent.x + ',' + d.parent.y;
        });
        var /** @type {?} */ node = _treeContainer
            .selectAll('.node')
            .data(nodes.descendants())
            .enter()
            .append('g')
            .attr('class', function (d) {
            return 'tree-node' +
                (d.children ? '-internal' : '-leaf');
        })
            .attr('transform', function (d) {
            return 'translate(' + d.x + ',' + d.y + ')';
        });
        node.append('circle')
            .attr('r', 10);
        node.append('text')
            .attr('dy', '.35em')
            .attr('y', function (d) {
            return d.children ? -20 : 20;
        })
            .style('text-anchor', 'middle')
            .text(function (d) {
            return d.data.name;
        });
    };
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildGeoOrthographic = /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in buildGeoOrthographic -------------------');
        var /** @type {?} */ _maxX = 100; // any value
        var /** @type {?} */ _maxY = 100; // any value
        var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        var /** @type {?} */ _graphCenterPos = cdt.graphCenterPos;
        var /** @type {?} */ _titleDisplay = configData.title.display;
        var /** @type {?} */ _legendDisplay = configData.legend.display;
        var /** @type {?} */ _focusColor = configData.color.focusColor;
        var /** @type {?} */ _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
        var /** @type {?} */ _scale = dataSetJson.map.scale;
        var /** @type {?} */ _targetName = dataSetJson.map.targetName;
        var /** @type {?} */ _targetProperty = 'd.' + dataSetJson.map.targetPropertyName;
        var /** @type {?} */ _keyDataName = dataSetJson.map.keyDataName;
        var /** @type {?} */ _keyName = 'data.' + _keyDataName;
        var /** @type {?} */ _clipAngle = dataSetJson.map.clipAngle;
        var /** @type {?} */ _rotateH = dataSetJson.map.rotate.horizontal;
        var /** @type {?} */ _rotateV = dataSetJson.map.rotate.vertical;
        var /** @type {?} */ _oceanColor = dataSetJson.map.oceanColor;
        var /** @type {?} */ _antarcticaColor = dataSetJson.map.antarcticaColor;
        var /** @type {?} */ _animation = configData.animation.enable;
        var /** @type {?} */ _animationDuration = configData.animation.duration;
        var /** @type {?} */ _animationH = 0;
        var /** @type {?} */ _findColorByName = function (name) {
            for (var /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    if (name === dataSetJson.data[i].name) {
                        var /** @type {?} */ _color = dataSetJson.data[i].color;
                        return _color;
                    }
                }
            }
            return null;
        };
        var /** @type {?} */ targetPath = geoOrthographic()
            .translate(_graphCenterPos)
            .clipAngle(_clipAngle)
            .scale(_scale)
            .rotate([_rotateH, _rotateV]);
        var /** @type {?} */ path = geoPath()
            .projection(targetPath);
        json(_geoMapDataUrl, function (error, data) {
            svgContainer.append('circle')
                .attr('cx', _graphCenterPos[0])
                .attr('cy', _graphCenterPos[1])
                .attr('r', _scale)
                .style('fill', _oceanColor);
            var /** @type {?} */ earthPath = svgContainer.selectAll('path')
                .data(eval(_keyName))
                .enter()
                .append('path')
                .attr('d', path)
                .style('fill', function (d, i) {
                var /** @type {?} */ _targetArea = eval(_targetProperty);
                if (_findColorByName(_targetArea) !== null) {
                    return _findColorByName(_targetArea);
                }
                return 'hsl(' + i + ',80%,60%)';
            });
            if (_animation) {
                timer(function () {
                    targetPath.rotate([_rotateH + _animationH, _rotateV]);
                    _animationH += 2;
                    earthPath.attr('d', path);
                });
            }
        });
        // ------------------------------------
        // ---CALL buildTitle-----------------
        if (_titleDisplay) {
            this.drawTitle(cdt);
        }
        if (_legendDisplay) {
            var /** @type {?} */ _legendDataSet = new Array();
            for (var /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    var /** @type {?} */ _name = dataSetJson.data[i].name;
                    var /** @type {?} */ _color = dataSetJson.data[i].color;
                    if (_name === 'Antarctica') {
                        continue;
                    }
                    _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, dataSetJson.data[i].color));
                }
            }
            this.buildLegend(cdt, _legendDataSet);
        }
    };
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildGeoMap = /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in buildGeoMap -------------------');
        var /** @type {?} */ _maxX = 100; // any value
        var /** @type {?} */ _maxY = 100; // any value
        var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        var /** @type {?} */ _graphCenterPos = cdt.graphCenterPos;
        var /** @type {?} */ _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
        var /** @type {?} */ _scale = dataSetJson.map.scale;
        var /** @type {?} */ _keyDataName = dataSetJson.map.keyDataName;
        var /** @type {?} */ _keyName = 'data.' + _keyDataName;
        var /** @type {?} */ _targetProperty = 'd.' + dataSetJson.map.targetPropertyName;
        var /** @type {?} */ _antarcticaColor = dataSetJson.map.antarcticaColor;
        var /** @type {?} */ _legendDisplay = configData.legend.display;
        var /** @type {?} */ path = geoPath()
            .projection(geoMercator()
            .translate(_graphCenterPos)
            .scale(_scale));
        var /** @type {?} */ _findColorByName = function (name) {
            for (var /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    if (name === dataSetJson.data[i].name) {
                        var /** @type {?} */ _color = dataSetJson.data[i].color;
                        return _color;
                    }
                }
            }
            return null;
        };
        json(_geoMapDataUrl, function (error, data) {
            svgContainer.selectAll('path')
                .data(eval(_keyName))
                .enter()
                .append('path')
                .attr('d', path)
                .style('fill', function (d, i) {
                var /** @type {?} */ _targetArea = eval(_targetProperty);
                if (_findColorByName(_targetArea) !== null) {
                    return _findColorByName(_targetArea);
                }
                return 'hsl(' + i + ',80%,60%)';
            });
        });
        //  ------------------------------------
        //  ---CALL buildLegend-----------------
        if (_legendDisplay) {
            var /** @type {?} */ _legendDataSet = new Array();
            for (var /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    var /** @type {?} */ _name = dataSetJson.data[i].name;
                    var /** @type {?} */ _color = dataSetJson.data[i].color;
                    if (_name === 'Antarctica') {
                        continue;
                    }
                    _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, dataSetJson.data[i].color));
                }
            }
            this.buildLegend(cdt, _legendDataSet);
        }
    };
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildStackBar = /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in buildStackBar-------------------');
        var /** @type {?} */ _totalY = new Array();
        for (var /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                _totalY.push(0);
            }
        }
        for (var /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                var /** @type {?} */ k = 0;
                for (var /** @type {?} */ j in dataSetJson.data[i].value) {
                    if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                        _totalY[k++] += dataSetJson.data[i].value[j].y;
                    }
                }
            }
        }
        var /** @type {?} */ _maxX = 0;
        var /** @type {?} */ _maxY = 0;
        _maxY = max(_totalY);
        _maxX = 100;
        var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        var /** @type {?} */ _color = cdt.defaultColorFunc;
        var /** @type {?} */ _columnNum = dataSetJson.data.length;
        var /** @type {?} */ _barWidth = (cdt.graphWidth / _columnNum) - configData.margin.between;
        var /** @type {?} */ _columnWidth = (cdt.graphWidth / _columnNum);
        var /** @type {?} */ _initPosX = cdt.graphInitXPos;
        var /** @type {?} */ _graphHeight = cdt.graphHeight;
        var /** @type {?} */ _maxYValue = cdt.maxYValue;
        var /** @type {?} */ _opacity = configData.color.opacity;
        var /** @type {?} */ _legendDisplay = configData.legend.display;
        var /** @type {?} */ _gridYDisplay = configData.grid.y.display;
        var /** @type {?} */ _gridXDisplay = configData.grid.x.display;
        var /** @type {?} */ _labelDisplay = configData.label.display;
        var /** @type {?} */ _animation = configData.animation.enable;
        var /** @type {?} */ _animationDuration = configData.animation.duration;
        //  Get Data Name
        var /** @type {?} */ _seriesDateName = dataSetJson.series[0];
        //  Get Keys
        var /** @type {?} */ _keyArray = new Array();
        for (var /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                var /** @type {?} */ _key = dataSetJson.data[i].name;
                var /** @type {?} */ _value = dataSetJson.data[i].value[0].y;
                _keyArray.push(_key);
            }
        }
        //  Get Date String
        var /** @type {?} */ _dateArray = new Array();
        for (var /** @type {?} */ i in dataSetJson.data[0].value) {
            if (dataSetJson.data[0].value.hasOwnProperty(i)) {
                var /** @type {?} */ _xValue = dataSetJson.data[0].value[i].x;
                _dateArray.push(_xValue);
            }
        }
        var /** @type {?} */ _hashArray = new Array();
        for (var /** @type {?} */ i in _dateArray) {
            if (_dateArray.hasOwnProperty(i)) {
                var /** @type {?} */ _hashNumber = {};
                for (var /** @type {?} */ j in _keyArray) {
                    if (_keyArray.hasOwnProperty(j)) {
                        var /** @type {?} */ _key = _keyArray[j];
                        var /** @type {?} */ _value = dataSetJson.data[j].value[i].y;
                        _hashNumber[_key] = _value;
                    }
                }
                _hashArray.push(_hashNumber);
            }
        }
        var /** @type {?} */ yScale = scaleLinear()
            .domain([0, _maxYValue])
            .range([0, _graphHeight]);
        var /** @type {?} */ stack$$1 = stack();
        var /** @type {?} */ _rect = svgContainer.selectAll('g')
            .data(stack$$1.keys(_keyArray)(_hashArray))
            .enter()
            .append('g')
            .attr('fill', function (d, i) {
            return _color(i);
        })
            .attr('fill-opacity', _opacity)
            .selectAll('rect')
            .data(function (d, i) {
            return d;
        })
            .enter()
            .append('rect');
        if (_animation) {
            _rect.attr('x', function (d, i) {
                return _initPosX + i * _columnWidth;
            })
                .attr('height', 0)
                .attr('y', function (d, i) {
                var /** @type {?} */ nm = 'd.data.' + _keyArray[i];
                var /** @type {?} */ _yValue = eval(nm);
                return svgHeight - configData.margin.bottom - yScale(d[1]);
            })
                .attr('width', _barWidth)
                .transition()
                .duration(_animationDuration)
                .attr('height', function (d, i) {
                return yScale(d[1] - d[0]);
            });
        }
        else {
            _rect.attr('x', function (d, i) {
                return _initPosX + (i * _columnWidth);
            })
                .attr('y', function (d, i) {
                var /** @type {?} */ nm = 'd.data.' + _keyArray[i];
                var /** @type {?} */ _yValue = eval(nm);
                return svgHeight - configData.margin.bottom - yScale(d[1]);
            })
                .attr('width', _barWidth)
                .attr('height', function (d, i) {
                return yScale(d[1] - d[0]);
            });
        }
        // ------------------------------------
        // ---CALL buildTitle-----------------
        this.drawTitle(cdt);
        // ------------------------------------
        // ---CALL buildAxis-----------------
        this.buildYAxis(cdt);
        this.drawXBaseLine(cdt);
        //  ------------------------------------
        //  ---CALL drawXAxisLabel-----------------
        if (_labelDisplay) {
            var /** @type {?} */ _labelArray = new Array();
            for (var /** @type {?} */ i in dataSetJson.data[0].value) {
                if (dataSetJson.data[0].value.hasOwnProperty(i)) {
                    _labelArray.push(dataSetJson.data[0].value[i].x);
                }
            }
            this.drawXAxisLabel(cdt, _labelArray, STACK_BAR_CHART_TYPE_NAME);
        }
        //  ------------------------------------
        //  ---CALL buildLegend-----------------
        if (_legendDisplay) {
            var /** @type {?} */ _legendDataSet = new Array();
            for (var /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, _color(i)));
                }
            }
            this.buildLegend(cdt, _legendDataSet);
        }
        if (_gridYDisplay) {
            this.drawYGrid(cdt);
        }
    };
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildScatterPlot = /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('In  buildScatterPlot----------------');
        var /** @type {?} */ _dataSet = new Array();
        var /** @type {?} */ _maxX = 0;
        var /** @type {?} */ _maxY = 0;
        for (var /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                for (var /** @type {?} */ j in dataSetJson.data[i].value) {
                    if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                        if (_maxX < dataSetJson.data[i].value[j].x) {
                            _maxX = dataSetJson.data[i].value[j].x;
                        }
                        if (_maxY < dataSetJson.data[i].value[j].y) {
                            _maxY = dataSetJson.data[i].value[j].y;
                        }
                        var /** @type {?} */ _scatterPlotData = new O2ScatterPlotData(dataSetJson.data[i].value[j].x, dataSetJson.data[i].value[j].y, dataSetJson.data[i].value[j].r);
                        _dataSet.push(_scatterPlotData);
                    }
                }
            }
        }
        var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        var /** @type {?} */ _initPosX = cdt.graphInitXPos;
        var /** @type {?} */ _seriesNumber = dataSetJson.series.length;
        var /** @type {?} */ _color = cdt.defaultColorFunc;
        var /** @type {?} */ _opacity = configData.color.opacity;
        var /** @type {?} */ _gridYDisplay = configData.grid.y.display;
        var /** @type {?} */ _gridXDisplay = configData.grid.x.display;
        var /** @type {?} */ _titleDisplay = configData.title.display;
        var /** @type {?} */ _legendDisplay = configData.legend.display;
        var /** @type {?} */ _circle = svgContainer.selectAll('circle')
            .data(_dataSet)
            .enter()
            .append('circle')
            .attr('cx', function (d, i) {
            return _initPosX + d.x;
        })
            .attr('cy', function (d, i) {
            return (svgHeight - configData.margin.bottom - d.y);
        })
            .attr('r', function (d, i) {
            return d.r;
        })
            .style('fill', function (d, i) {
            var /** @type {?} */ _colorNum = i % _seriesNumber;
            return _color(_colorNum);
        })
            .attr('fill-opacity', _opacity);
        // ---CALL buildTitle-----------------
        if (_titleDisplay) {
            this.drawTitle(cdt);
        }
        // ------------------------------------
        // ---CALL buildLegend-----------------
        if (_legendDisplay) {
            var /** @type {?} */ _legendDataSet = new Array();
            for (var /** @type {?} */ i = 0; i < dataSetJson.series.length; i++) {
                _legendDataSet.push(new O2LegendData(dataSetJson.series[i], _color(i)));
            }
            this.buildLegend(cdt, _legendDataSet);
        }
        // ------------------------------------
        // ---CALL buildAxis-----------------
        this.buildYAxis(cdt);
        this.buildXAxis(cdt);
        if (_gridYDisplay) {
            this.drawYGrid(cdt);
        }
        if (_gridXDisplay) {
            this.drawXGrid(cdt);
        }
    };
    /**
     * @param {?} o2Common
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.drawXGrid = /**
     * @param {?} o2Common
     * @return {?}
     */
    function (o2Common) {
        console.log('in buildXGrid-------------------');
        var /** @type {?} */ cdt = o2Common;
        var /** @type {?} */ configData = cdt.configData;
        var /** @type {?} */ svgContainer = cdt.svgContainer;
        var /** @type {?} */ _stepX = cdt.gridXStep;
        var /** @type {?} */ _maxX = cdt.maxXValue;
        var /** @type {?} */ _graphYScale = cdt.graphYScale;
        var /** @type {?} */ _graphXScale = cdt.graphXScale;
        var /** @type {?} */ _graphWidth = cdt.graphWidth;
        var /** @type {?} */ _gridClassName = configData.className.grid;
        var /** @type {?} */ _axisXScale = scaleLinear()
            .domain([0, _maxX])
            .range([0, _maxX * _graphXScale]);
        var /** @type {?} */ _rangeX = range(_stepX * _graphXScale, _maxX * _graphXScale, _stepX * _graphXScale);
        svgContainer.append('g')
            .selectAll('line.x')
            .data(_rangeX)
            .enter()
            .append('line')
            .attr('class', _gridClassName)
            .attr('x1', function (d, i) {
            var /** @type {?} */ _x1 = configData.margin.left + d;
            return _x1;
        })
            .attr('y1', cdt.svgHeight - configData.margin.bottom)
            .attr('x2', function (d, i) {
            var /** @type {?} */ _x2 = configData.margin.left + d;
            return _x2;
        })
            .attr('y2', configData.margin.top + configData.title.height);
    };
    /**
     * @param {?} o2Common
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildXAxis = /**
     * @param {?} o2Common
     * @return {?}
     */
    function (o2Common) {
        console.log('in buildXAxis-------------------');
        var /** @type {?} */ cdt = o2Common;
        var /** @type {?} */ configData = cdt.configData;
        var /** @type {?} */ svgContainer = cdt.svgContainer;
        var /** @type {?} */ _maxX = cdt.maxXValue;
        var /** @type {?} */ _graphXScale = cdt.graphXScale;
        var /** @type {?} */ _axisXScale = scaleLinear()
            .domain([0, _maxX])
            .range([0, _maxX * _graphXScale]);
        svgContainer.append('g')
            .attr('class', cdt.axisClassName)
            .attr('transform', cdt.axisXBorderTranslatePos)
            .call(axisBottom(_axisXScale));
        //  .scale()
        //  .orient(cdt.axisXOrient)
        //  );
    };
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildPie = /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('In  buildPie----------------');
        var /** @type {?} */ _maxX = 100;
        var /** @type {?} */ _maxY = 100;
        var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        var /** @type {?} */ _color = cdt.defaultColorFunc;
        var /** @type {?} */ _graphHeight = cdt.graphHeight;
        var /** @type {?} */ _opacity = configData.color.opacity;
        var /** @type {?} */ _titleHeight = configData.title.height;
        var /** @type {?} */ _leftMargin = configData.margin.left;
        var /** @type {?} */ _topMargin = configData.margin.top;
        var /** @type {?} */ _bottomMargin = configData.margin.bottom;
        var /** @type {?} */ _betweenMargin = configData.margin.between;
        var /** @type {?} */ _innerRadiusPercent = cdt.innerRadiusPercent;
        var /** @type {?} */ _graphCenterTranslatePos = cdt.graphCenterTranslatePos;
        var /** @type {?} */ _pieClassName = configData.className.pie;
        var /** @type {?} */ _pieValueClassName = configData.className.pieNum;
        var /** @type {?} */ _pieInnerTitleClassName = configData.className.pieInnerTitle;
        var /** @type {?} */ _innerRadiusTitleTranslatePos = cdt.innerRadiusTitleTranslatePos;
        var /** @type {?} */ _innerRadiusTitle = cdt.innerRadiusTitle;
        var /** @type {?} */ _titleDisplay = configData.title.display;
        var /** @type {?} */ _legendDisplay = configData.legend.display;
        var /** @type {?} */ _labelDisplay = configData.label.display;
        var /** @type {?} */ _valueDisplay = configData.pie.value.display;
        var /** @type {?} */ _percentDisplay = configData.pie.percent.display;
        var /** @type {?} */ _animation = configData.animation.enable;
        var /** @type {?} */ _animationDuration = configData.animation.duration;
        var /** @type {?} */ dataSet = new Array();
        for (var /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                var /** @type {?} */ _num = dataSetJson.data[i].value;
                dataSet.push(_num);
            }
        }
        var /** @type {?} */ _sum = sum(dataSet);
        var /** @type {?} */ pie$$1 = pie();
        var /** @type {?} */ arc$$1 = arc()
            .innerRadius(_graphHeight * _innerRadiusPercent / 100)
            .outerRadius(_graphHeight / 2);
        var /** @type {?} */ pieElements = svgContainer.selectAll('path')
            .data(pie$$1(dataSet))
            .enter()
            .append('g')
            .attr('transform', _graphCenterTranslatePos);
        var /** @type {?} */ _makeCenterTitle = function () {
            if (_valueDisplay && _percentDisplay) {
                var /** @type {?} */ _st = _innerRadiusTitle + ':' + _sum + ' (100%)';
                return _st;
            }
            if (_percentDisplay) {
                return '100%';
            }
            if (_valueDisplay) {
                return _innerRadiusTitle + ':' + _sum;
            }
        };
        var /** @type {?} */ textElements = svgContainer.append('text')
            .attr('class', _pieInnerTitleClassName)
            .attr('transform', _innerRadiusTitleTranslatePos)
            .text(_makeCenterTitle);
        var /** @type {?} */ _arc = pieElements.append('path')
            .attr('class', _pieClassName)
            .style('fill', function (d, i) {
            return _color(i);
        })
            .attr('fill-opacity', _opacity);
        //  For d3Version4 animation is not available now
        //  if (_animation) {
        //      _arc.transition()
        //      .duration(_animationDuration)
        //      .delay((d,i)=> {
        //          return i *1000;
        //      })
        //      .attrTween('d',(d: any,i: number) =>  {
        //          const _interpolate = d3.interpolateObject(
        //              { startAngle:d.startAngle,endAngle:d.startAngle }
        //              { startAngle:d.startAngle,endAngle:d.endAngle }
        //          )
        //          return (t) {
        //              return arc(_interpolate(t));
        //          }
        //      })
        //  }
        //  else{
        //      _arc.attr('d',arc);
        //  }
        _arc.attr('d', arc$$1);
        pieElements.append('text')
            .attr('class', _pieValueClassName)
            .attr('transform', function (d, i) {
            return 'translate(' + arc$$1.centroid(d) + ')';
        })
            .text(function (d, i) {
            if (_valueDisplay && _percentDisplay) {
                var /** @type {?} */ _percentSt = String(Math.ceil(d.value / _sum * 100));
                var /** @type {?} */ _st = String(d.value) + ' (' + _percentSt + '%)';
                return _st;
            }
            if (_percentDisplay) {
                var /** @type {?} */ _percentSt = String(Math.ceil(d.value / _sum * 100));
                var /** @type {?} */ _st = _percentSt + '%';
                return _st;
            }
            if (_valueDisplay) {
                return d.value;
            }
        });
        // ---CALL buildTitle-----------------
        if (_titleDisplay) {
            this.drawTitle(cdt);
        }
        // ------------------------------------
        // ---CALL buildLegend-----------------
        if (_legendDisplay) {
            var /** @type {?} */ _legendDataSet = new Array();
            for (var /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, _color(i)));
                }
            }
            this.buildLegend(cdt, _legendDataSet);
        }
    };
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildBar = /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('In  buildBar----------------');
        var /** @type {?} */ _yDataSet = new Array();
        for (var /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                for (var /** @type {?} */ j in dataSetJson.data[i].y) {
                    if (dataSetJson.data[i].y.hasOwnProperty(j)) {
                        var /** @type {?} */ _y = dataSetJson.data[i].y[j];
                        _yDataSet.push(_y);
                    }
                }
            }
        }
        var /** @type {?} */ _maxX = 0;
        var /** @type {?} */ _maxY = 0;
        _maxY = max(_yDataSet);
        _maxX = 100;
        var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        var /** @type {?} */ _barValueClass = configData.className.barValue;
        var /** @type {?} */ _color = cdt.defaultColorFunc;
        var /** @type {?} */ _seriesNum = dataSetJson.series.length;
        var /** @type {?} */ _columnNum = _yDataSet.length;
        var /** @type {?} */ _initPosY = cdt.graphInitYPos;
        var /** @type {?} */ _graphHeight = cdt.graphHeight;
        var /** @type {?} */ _graphWidth = cdt.graphWidth;
        var /** @type {?} */ _opacity = configData.color.opacity;
        var /** @type {?} */ _titleHeight = configData.title.height;
        var /** @type {?} */ _titleDisplay = configData.title.display;
        var /** @type {?} */ _leftMargin = configData.margin.left;
        var /** @type {?} */ _topMargin = configData.margin.top;
        var /** @type {?} */ _bottomMargin = configData.margin.bottom;
        var /** @type {?} */ _betweenMargin = configData.margin.between;
        var /** @type {?} */ _legendDisplay = configData.legend.display;
        var /** @type {?} */ _labelDisplay = configData.label.display;
        var /** @type {?} */ _gridYDisplay = configData.grid.y.display;
        var /** @type {?} */ _animation = configData.animation.enable;
        var /** @type {?} */ _animationDuration = configData.animation.duration;
        var /** @type {?} */ _barWidth = (_graphWidth - (_betweenMargin * _columnNum / _seriesNum)) / _columnNum;
        var /** @type {?} */ _columnWidth = (_graphWidth / _columnNum);
        var /** @type {?} */ _graphYScale = cdt.graphYScale;
        var /** @type {?} */ yBarScale = scaleLinear()
            .domain([0, _maxY])
            .range([_maxY * _graphYScale, 0]);
        var /** @type {?} */ _barPadding = _betweenMargin;
        var /** @type {?} */ grpGraph = svgContainer.selectAll('g')
            .data(_yDataSet)
            .enter()
            .append('g')
            .attr('transform', function (d, i) {
            var /** @type {?} */ _padding = ((i % _seriesNum) === 0) ? _barPadding : 0;
            return 'translate(' + (_padding + _columnWidth * i) + ')';
        })
            .style('fill', function (d, i) {
            var /** @type {?} */ _remnant = (i % _seriesNum);
            return _color(_remnant);
        })
            .attr('fill-opacity', _opacity);
        var /** @type {?} */ _rect = grpGraph.append('rect');
        if (_animation) {
            _rect.attr('x', _leftMargin)
                .attr('height', 0)
                .attr('y', function (d) {
                return _initPosY;
            })
                .attr('width', _barWidth - _barPadding)
                .transition()
                .duration(_animationDuration)
                .attr('y', function (d) {
                return yBarScale(d) + _initPosY;
            })
                .attr('height', function (d) {
                return _graphHeight - yBarScale(d);
            });
        }
        else {
            _rect.attr('x', _leftMargin)
                .attr('y', function (d) {
                return yBarScale(d) + _initPosY;
            })
                .attr('width', _barWidth - _barPadding)
                .attr('height', function (d) {
                return _graphHeight - yBarScale(d);
            });
        }
        var /** @type {?} */ textBarValue = grpGraph.append('text');
        textBarValue
            .attr('class', _barValueClass)
            .attr('x', _leftMargin)
            .attr('y', function (d) {
            return yBarScale(d) + _initPosY;
        })
            .text(function (d) {
            return d;
        });
        // ------------------------------------
        // ---CALL buildAxis-----------------
        this.buildYAxis(cdt);
        //  ------------------------------------
        //  ---CALL drawXAxisLabel-----------------
        if (_labelDisplay) {
            var /** @type {?} */ _labelArray = new Array();
            for (var /** @type {?} */ i in dataSetJson.data) {
                if (dataSetJson.data.hasOwnProperty(i)) {
                    _labelArray.push(dataSetJson.data[i].x);
                }
            }
            this.drawXAxisLabel(cdt, _labelArray, BAR_CHART_TYPE_NAME);
        }
        this.drawXBaseLine(cdt);
        //  ------------------------------------
        //  ---CALL buildLegend-----------------
        var /** @type {?} */ _legendDataSet = new Array();
        for (var /** @type {?} */ i in dataSetJson.series) {
            if (dataSetJson.series.hasOwnProperty(i)) {
                _legendDataSet.push(new O2LegendData(dataSetJson.series[i], _color(i)));
            }
        }
        this.buildLegend(cdt, _legendDataSet);
        // ------------------------------------
        // ---CALL buildTitle-----------------
        if (_titleDisplay) {
            this.drawTitle(cdt);
        }
        if (_gridYDisplay) {
            this.drawYGrid(cdt);
        }
    };
    /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildLine = /**
     * @param {?} svgContainer
     * @param {?} configData
     * @param {?} dataSetJson
     * @param {?} svgWidth
     * @param {?} svgHeight
     * @return {?}
     */
    function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
        console.log('in buildTest-------------------');
        var /** @type {?} */ _groupMaxY = new Array();
        for (var /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                var /** @type {?} */ _gMaxY = 0;
                for (var /** @type {?} */ j in dataSetJson.data[i].value) {
                    if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                        if (_gMaxY < dataSetJson.data[i].value[j].y) {
                            _gMaxY = dataSetJson.data[i].value[j].y;
                        }
                    }
                }
                _groupMaxY.push(_gMaxY);
            }
        }
        var /** @type {?} */ _maxX = 0;
        var /** @type {?} */ _maxY = 0;
        _maxY = max(_groupMaxY);
        _maxX = 100;
        var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
        var /** @type {?} */ _color = cdt.defaultColorFunc;
        var /** @type {?} */ _columnNum = dataSetJson.data[0].value.length;
        var /** @type {?} */ _columnWidth = cdt.graphWidth / _columnNum;
        console.log(_columnWidth);
        if (configData.grid.y.display) {
            this.drawYGrid(cdt);
        }
        //  O2IdValueData
        for (var /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                var /** @type {?} */ _lineArray = new Array();
                for (var /** @type {?} */ j in dataSetJson.data[i].value) {
                    if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                        var /** @type {?} */ idValue = new O2IdValueData(parseInt(j, 10), dataSetJson.data[i].value[j].y);
                        _lineArray.push(idValue);
                    }
                }
                var /** @type {?} */ num = parseInt(i, 10);
                this.drawSingleLine(cdt, _lineArray, num);
            }
        }
        // ------------------------------------
        // ---CALL buildTitle-----------------
        this.drawTitle(cdt);
        // ------------------------------------
        // ---CALL buildAxis-----------------
        this.buildYAxis(cdt);
        this.drawXBaseLine(cdt);
        //  ------------------------------------
        //  ---CALL drawXAxisLabel-----------------
        var /** @type {?} */ _labelArray = new Array();
        for (var /** @type {?} */ i in dataSetJson.data[0].value) {
            if (dataSetJson.data[0].value.hasOwnProperty(i)) {
                _labelArray.push(dataSetJson.data[0].value[i].x);
            }
        }
        this.drawXAxisLabel(cdt, _labelArray, LINE_CHART_TYPE_NAME);
        //  ------------------------------------
        //  ---CALL buildLegend-----------------
        var /** @type {?} */ _legendDataSet = new Array();
        for (var /** @type {?} */ i in dataSetJson.data) {
            if (dataSetJson.data.hasOwnProperty(i)) {
                _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, _color(i)));
            }
        }
        this.buildLegend(cdt, _legendDataSet);
    };
    /**
     * @param {?} o2Common
     * @param {?} dataSet
     * @param {?} lineNum
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.drawSingleLine = /**
     * @param {?} o2Common
     * @param {?} dataSet
     * @param {?} lineNum
     * @return {?}
     */
    function (o2Common, dataSet, lineNum) {
        console.log('in drawSingleLine-------------------');
        console.log(dataSet);
        var /** @type {?} */ cdt = o2Common;
        var /** @type {?} */ configData = cdt.configData;
        var /** @type {?} */ svgContainer = cdt.svgContainer;
        var /** @type {?} */ _maxX = cdt.maxXValue;
        var /** @type {?} */ _initXPos = cdt.axisXLabelInitXPos;
        var /** @type {?} */ _initYPos = cdt.axisXLabelInitYPos;
        var /** @type {?} */ _columnNum = dataSet.length;
        var /** @type {?} */ _columnWidth = cdt.graphWidth / (_columnNum - 1);
        var /** @type {?} */ _color = scaleOrdinal(schemeCategory10);
        var /** @type {?} */ _lineClassName = configData.className.multiLinePrefix + String(lineNum);
        var /** @type {?} */ _leftMargin = configData.margin.left;
        var /** @type {?} */ _bottomMargin = configData.margin.bottom;
        var /** @type {?} */ _yScale = cdt.graphYScale;
        var /** @type {?} */ line$$1 = line()
            .curve(curveLinear)
            .x(function (d) {
            return _leftMargin + d.id * _columnWidth;
        })
            .y(function (d) {
            return cdt.svgHeight - _bottomMargin - (d.value * _yScale);
        });
        svgContainer.append('path')
            .attr('class', _lineClassName)
            .attr('d', line$$1(dataSet));
        //  .attr('transform', cdt.axisTranslatePos)
    };
    /**
     * @param {?} o2Common
     * @param {?} _legendDataSet
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildLegend = /**
     * @param {?} o2Common
     * @param {?} _legendDataSet
     * @return {?}
     */
    function (o2Common, _legendDataSet) {
        console.log('in buildLegend-------------------');
        //  maxValues are meaningless
        var /** @type {?} */ cdt = o2Common;
        var /** @type {?} */ configData = cdt.configData;
        var /** @type {?} */ svgContainer = cdt.svgContainer;
        //  const cdt = new O2Common(configData, 100, 100, svgWidth, svgHeight);
        var /** @type {?} */ legendRectSize = configData.legend.rectWidth;
        var /** @type {?} */ legendSpacing = 10;
        var /** @type {?} */ ySpacing = configData.legend.ySpacing;
        var /** @type {?} */ initPosX = cdt.legendInitXPos;
        var /** @type {?} */ initPosY = cdt.legendInitYPos;
        var /** @type {?} */ opacity = configData.color.opacity;
        var /** @type {?} */ grpLegend = svgContainer.append('g')
            .selectAll('g')
            .data(_legendDataSet)
            .enter()
            .append('g')
            .attr('class', 'legend')
            .attr('transform', function (d, i) {
            var /** @type {?} */ height = legendRectSize + ySpacing;
            var /** @type {?} */ x = initPosX;
            var /** @type {?} */ y = i * height + initPosY;
            return 'translate(' + x + ', ' + y + ')';
        });
        grpLegend.append('rect')
            .attr('width', legendRectSize)
            .attr('height', legendRectSize)
            .style('fill', function (d) {
            return d.color;
        })
            .style('stroke', function (d) {
            return d.color;
        })
            .attr('fill-opacity', opacity);
        grpLegend.append('text')
            .attr('x', legendRectSize + legendSpacing)
            .attr('y', legendRectSize)
            .text(function (d) {
            return d.title;
        });
    };
    /**
     * @param {?} o2Common
     * @param {?} labelDataSet
     * @param {?} chartType
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.drawXAxisLabel = /**
     * @param {?} o2Common
     * @param {?} labelDataSet
     * @param {?} chartType
     * @return {?}
     */
    function (o2Common, labelDataSet, chartType) {
        console.log('in drawXAxisLabel-------------------');
        var /** @type {?} */ cdt = o2Common;
        var /** @type {?} */ configData = cdt.configData;
        var /** @type {?} */ svgContainer = cdt.svgContainer;
        // const _maxX = cdt.maxXValue;
        var /** @type {?} */ _initXPos = cdt.axisXLabelInitXPos;
        var /** @type {?} */ _initYPos = cdt.axisXLabelInitYPos;
        var /** @type {?} */ _columnNum = labelDataSet.length;
        var /** @type {?} */ _columnWidth = cdt.graphWidth / _columnNum;
        if (chartType === LINE_CHART_TYPE_NAME) {
            _columnWidth = cdt.graphWidth / (_columnNum - 1);
        }
        var /** @type {?} */ grpLabel = svgContainer.append('g')
            .selectAll('g')
            .data(labelDataSet)
            .enter()
            .append('g')
            .attr('class', configData.axisXText)
            .attr('transform', function (d, i) {
            var /** @type {?} */ _x = _initXPos + _columnWidth * i;
            var /** @type {?} */ _y = _initYPos;
            return 'translate(' + _x + ', ' + _y + ')';
        });
        grpLabel.append('text')
            .attr('class', configData.className.axisXText)
            .text(function (d, i) {
            return d;
        });
    };
    /**
     * @param {?} o2Common
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.drawXBaseLine = /**
     * @param {?} o2Common
     * @return {?}
     */
    function (o2Common) {
        console.log('in drawXBaseLine-------------------');
        var /** @type {?} */ cdt = o2Common;
        var /** @type {?} */ svgContainer = cdt.svgContainer;
        svgContainer.append('rect')
            .attr('class', cdt.axisXBorderLineClassName)
            .attr('width', cdt.axisXBorderWidth)
            .attr('height', cdt.axisXBorderLineWidth)
            .attr('transform', cdt.axisXBorderTranslatePos);
    };
    /**
     * @param {?} o2Common
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.buildYAxis = /**
     * @param {?} o2Common
     * @return {?}
     */
    function (o2Common) {
        console.log('in buildYAxis-------------------');
        var /** @type {?} */ cdt = o2Common;
        var /** @type {?} */ svgContainer = cdt.svgContainer;
        var /** @type {?} */ _maxY = cdt.maxYValue;
        var /** @type {?} */ _graphYScale = cdt.graphYScale;
        var /** @type {?} */ _axisYScale = scaleLinear()
            .domain([0, _maxY])
            .range([_maxY * _graphYScale, 0]);
        svgContainer.append('g')
            .attr('class', cdt.axisClassName)
            .attr('transform', cdt.axisTranslatePos)
            .call(axisLeft(_axisYScale));
    };
    /**
     * @param {?} o2Common
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.drawTitle = /**
     * @param {?} o2Common
     * @return {?}
     */
    function (o2Common) {
        console.log('in drawTitle-------------------');
        var /** @type {?} */ cdt = o2Common;
        var /** @type {?} */ configData = cdt.configData;
        var /** @type {?} */ svgContainer = cdt.svgContainer;
        var /** @type {?} */ _title = configData.title.name;
        var /** @type {?} */ _xPos = cdt.titleInitXPos;
        var /** @type {?} */ _yPos = cdt.titleInitYPos;
        var /** @type {?} */ _titleClassName = configData.title.className;
        svgContainer.append('text')
            .attr('class', _titleClassName)
            .attr('x', _xPos)
            .attr('y', _yPos)
            .text(_title);
    };
    /**
     * @param {?} o2Common
     * @return {?}
     */
    Ng6O2ChartComponent.prototype.drawYGrid = /**
     * @param {?} o2Common
     * @return {?}
     */
    function (o2Common) {
        console.log('in buildYGrid-------------------');
        var /** @type {?} */ cdt = o2Common;
        var /** @type {?} */ configData = cdt.configData;
        var /** @type {?} */ svgContainer = cdt.svgContainer;
        var /** @type {?} */ _stepY = cdt.gridYStep;
        var /** @type {?} */ _maxY = cdt.maxYValue;
        var /** @type {?} */ _graphYScale = cdt.graphYScale;
        var /** @type {?} */ _gridClassName = configData.className.grid;
        var /** @type {?} */ _rangeY = range(_stepY * _graphYScale, _maxY * _graphYScale, _stepY * _graphYScale);
        svgContainer.append('g')
            .selectAll('line.y')
            .data(_rangeY)
            .enter()
            .append('line')
            .attr('class', _gridClassName)
            .attr('x1', configData.margin.left)
            .attr('y1', function (d, i) {
            var /** @type {?} */ _y1 = cdt.svgHeight - configData.margin.bottom - d;
            return _y1;
        })
            .attr('x2', configData.margin.left + cdt.axisXBorderWidth)
            .attr('y2', function (d, i) {
            var /** @type {?} */ _y1 = cdt.svgHeight - configData.margin.bottom - d;
            return _y1;
        });
    };
    Ng6O2ChartComponent.decorators = [
        { type: Component, args: [{
                    selector: 'lib-Ng6O2Chart',
                    template: "",
                    styles: []
                },] },
    ];
    /** @nocollapse */
    Ng6O2ChartComponent.ctorParameters = function () { return [
        { type: ElementRef }
    ]; };
    Ng6O2ChartComponent.propDecorators = {
        chartType: [{ type: Input }],
        svgWidth: [{ type: Input }],
        svgHeight: [{ type: Input }],
        graphData: [{ type: Input }],
        configData: [{ type: Input }]
    };
    return Ng6O2ChartComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var Ng6O2ChartModule = /** @class */ (function () {
    function Ng6O2ChartModule() {
    }
    Ng6O2ChartModule.decorators = [
        { type: NgModule, args: [{
                    imports: [],
                    declarations: [Ng6O2ChartComponent],
                    exports: [Ng6O2ChartComponent]
                },] },
    ];
    return Ng6O2ChartModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

export { LINE_CHART_TYPE_NAME, BAR_CHART_TYPE_NAME, PIE_CHART_TYPE_NAME, SCATTER_PLOT_CHART_TYPE_NAME, HISTOGRAM_CHART_TYPE_NAME, STACK_BAR_CHART_TYPE_NAME, GEO_MAP_CHART_TYPE_NAME, GEO_ORTHOGRAPHIC_CHART_TYPE_NAME, TREE_MAP_CHART_TYPE_NAME, PACK_LAYOUT_CHART_TYPE_NAME, CHOROPLETH_CHART_TYPE_NAME, TREE_CHART_TYPE_NAME, SANKEY_CHART_TYPE_NAME, FORCE_CHART_TYPE_NAME, Ng6O2ChartComponent, Ng6O2ChartModule };

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmc2LW8yLWNoYXJ0LmpzLm1hcCIsInNvdXJjZXMiOlsibmc6Ly9uZzYtbzItY2hhcnQvbGliL3NoYXJlZC9jaGFydC1jb25zdC50cyIsIm5nOi8vbmc2LW8yLWNoYXJ0L2xpYi9zaGFyZWQvbzJjb21tb24udHMiLCJuZzovL25nNi1vMi1jaGFydC9saWIvbmc2LW8yLWNoYXJ0LmNvbXBvbmVudC50cyIsIm5nOi8vbmc2LW8yLWNoYXJ0L2xpYi9uZzYtbzItY2hhcnQubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBjb25zdCBMSU5FX0NIQVJUX1RZUEVfTkFNRSAgPSAnbGluZSc7XHJcbmV4cG9ydCBjb25zdCBCQVJfQ0hBUlRfVFlQRV9OQU1FID0gJ2Jhcic7XHJcbmV4cG9ydCBjb25zdCBQSUVfQ0hBUlRfVFlQRV9OQU1FID0gJ3BpZSc7XHJcbmV4cG9ydCBjb25zdCBTQ0FUVEVSX1BMT1RfQ0hBUlRfVFlQRV9OQU1FID0gJ3NjYXR0ZXJQbG90JztcclxuZXhwb3J0IGNvbnN0IEhJU1RPR1JBTV9DSEFSVF9UWVBFX05BTUUgPSAnaGlzdG9ncmFtJztcclxuZXhwb3J0IGNvbnN0IFNUQUNLX0JBUl9DSEFSVF9UWVBFX05BTUUgPSAnc3RhY2tCYXInO1xyXG5leHBvcnQgY29uc3QgR0VPX01BUF9DSEFSVF9UWVBFX05BTUUgPSAnZ2VvTWFwJztcclxuZXhwb3J0IGNvbnN0IEdFT19PUlRIT0dSQVBISUNfQ0hBUlRfVFlQRV9OQU1FID0gJ2dlb09ydGhvZ3JhcGhpYyc7XHJcbmV4cG9ydCBjb25zdCBUUkVFX01BUF9DSEFSVF9UWVBFX05BTUUgPSAndHJlZU1hcCc7XHJcbmV4cG9ydCBjb25zdCBQQUNLX0xBWU9VVF9DSEFSVF9UWVBFX05BTUUgPSAncGFja0xheW91dCc7XHJcbmV4cG9ydCBjb25zdCBDSE9ST1BMRVRIX0NIQVJUX1RZUEVfTkFNRSA9ICdjaG9yb3BsZXRoJztcclxuZXhwb3J0IGNvbnN0IFRSRUVfQ0hBUlRfVFlQRV9OQU1FID0gJ3RyZWUnO1xyXG5leHBvcnQgY29uc3QgU0FOS0VZX0NIQVJUX1RZUEVfTkFNRSA9ICdzYW5rZXknO1xyXG5leHBvcnQgY29uc3QgRk9SQ0VfQ0hBUlRfVFlQRV9OQU1FID0gJ2ZvcmNlJyA7XHJcbiIsImltcG9ydCAqIGFzIGQzIGZyb20gJ2QzJztcclxuXHJcblxyXG5cclxuZXhwb3J0IGNsYXNzIE8yQ29tbW9uIHtcclxuXHJcbiAgICBjb25zdHJ1Y3RvcihcclxuICAgICAgICBwdWJsaWMgc3ZnQ29udGFpbmVyOiBhbnksXHJcbiAgICAgICAgcHVibGljIGNvbmZpZ0RhdGE6IGFueSxcclxuICAgICAgICBwdWJsaWMgYXV0b01heFg6IG51bWJlcixcclxuICAgICAgICBwdWJsaWMgYXV0b01heFk6IG51bWJlcixcclxuICAgICAgICBwdWJsaWMgc3ZnV2lkdGg6IG51bWJlcixcclxuICAgICAgICBwdWJsaWMgc3ZnSGVpZ2h0OiBudW1iZXJcclxuICAgICkgeyB9XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0gIENMQVNTIE5BTUUgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5wdWJsaWMgZ2V0IGF4aXNDbGFzc05hbWUoKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ0RhdGEuY2xhc3NOYW1lLmF4aXM7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgbGluZUNsYXNzTmFtZSgpOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuIHRoaXMuY29uZmlnRGF0YS5jbGFzc05hbWUubGluZTtcclxufVxyXG5cclxucHVibGljIGdldCBheGlzWEJvcmRlckxpbmVDbGFzc05hbWUoKTogc3RyaW5nIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ0RhdGEuY2xhc3NOYW1lLmF4aXNYQm9yZGVyO1xyXG59XHJcblxyXG5cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLSAgTUFYIFZBTFVFICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbnB1YmxpYyBnZXQgbWF4WFZhbHVlKCk6IG51bWJlciB7XHJcbiAgICBsZXQgX21heFggPSB0aGlzLmF1dG9NYXhYO1xyXG4gICAgaWYgKCF0aGlzLmNvbmZpZ0RhdGEubWF4VmFsdWUuYXV0bykge1xyXG4gICAgICAgIF9tYXhYID0gdGhpcy5jb25maWdEYXRhLm1heFZhbHVlLng7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gX21heFg7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgbWF4WVZhbHVlKCk6IG51bWJlciB7XHJcbiAgICBsZXQgX21heFkgPSB0aGlzLmF1dG9NYXhZO1xyXG4gICAgaWYgKCF0aGlzLmNvbmZpZ0RhdGEubWF4VmFsdWUuYXV0bykge1xyXG4gICAgICAgIF9tYXhZID0gdGhpcy5jb25maWdEYXRhLm1heFZhbHVlLnk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gX21heFk7XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLSAgR1JBUEggLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbnB1YmxpYyBnZXQgZ3JhcGhJbml0WFBvcygpOiBudW1iZXIge1xyXG4gICAgbGV0IF9pbnRYID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0O1xyXG4gICAgaWYgKHRoaXMuY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheSAmJiB0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLnBvc2l0aW9uICE9PSAncmlnaHQnKSB7XHJcbiAgICAgICAgX2ludFggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS5sZWdlbmQudG90YWxXaWR0aDtcclxuICAgIH1cclxuICAgIHJldHVybiBfaW50WDtcclxufVxyXG5cclxucHVibGljIGdldCBncmFwaEluaXRZUG9zKCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfaW50WSA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4udG9wXHJcbiAgICAgICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHQ7XHJcbiAgICByZXR1cm4gX2ludFk7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JhcGhZU2NhbGUoKTogbnVtYmVyIHtcclxuICAgIHJldHVybiB0aGlzLmdyYXBoSGVpZ2h0IC8gdGhpcy5tYXhZVmFsdWU7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JhcGhYU2NhbGUoKTogbnVtYmVyIHtcclxuICAgIHJldHVybiB0aGlzLmdyYXBoV2lkdGggLyB0aGlzLm1heFhWYWx1ZTtcclxufVxyXG5cclxucHVibGljIGdldCBncmFwaFdpZHRoKCk6IG51bWJlciB7XHJcbiAgICBsZXQgX21hcmdpbiA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLm1hcmdpbi5yaWdodDtcclxuICAgIGlmICh0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXkpIHtcclxuICAgICAgICBfbWFyZ2luICs9IHRoaXMuY29uZmlnRGF0YS5sZWdlbmQudG90YWxXaWR0aDtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gdGhpcy5zdmdXaWR0aCAtIF9tYXJnaW47XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JhcGhIZWlnaHQoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF9oID0gdGhpcy5zdmdIZWlnaHRcclxuICAgICAgICAgICAgICAgIC0gdGhpcy5jb25maWdEYXRhLnRpdGxlLmhlaWdodFxyXG4gICAgICAgICAgICAgICAgLSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICAgICAgLSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbTtcclxuICAgIHJldHVybiBfaDtcclxufVxyXG5cclxucHVibGljIGdldCBncmFwaENlbnRlclBvcygpOiBhbnkge1xyXG4gICAgY29uc3QgX3h5QXJyYXk6IEFycmF5PG51bWJlcj4gPSBuZXcgQXJyYXkoKTtcclxuICAgIGNvbnN0IF94ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICAgICArIHRoaXMuZ3JhcGhXaWR0aCAvIDI7XHJcbiAgICBjb25zdCBfeSA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4udG9wXHJcbiAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLnRpdGxlLmhlaWdodFxyXG4gICAgICAgICAgICArIHRoaXMuZ3JhcGhIZWlnaHQgLyAyO1xyXG4gICAgX3h5QXJyYXkucHVzaChfeCk7XHJcbiAgICBfeHlBcnJheS5wdXNoKF95KTtcclxuICAgIHJldHVybiBfeHlBcnJheTtcclxufVxyXG5cclxucHVibGljIGdldCBncmFwaENlbnRlclRyYW5zbGF0ZVBvcygpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgX3ggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgKyB0aGlzLmdyYXBoV2lkdGggLyAyO1xyXG4gICAgY29uc3QgX3kgPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHRcclxuICAgICAgICAgICAgKyB0aGlzLmdyYXBoSGVpZ2h0IC8gMjtcclxuICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyBTdHJpbmcoX3gpICsgJywgJyArIFN0cmluZyhfeSkgKyAnKSc7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgZ3JhcGhJbml0VHJhbnNsYXRlUG9zKCk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBfeCA9IHRoaXMuZ3JhcGhJbml0WFBvcztcclxuICAgIGNvbnN0IF95ID0gdGhpcy5ncmFwaEluaXRZUG9zO1xyXG4gICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIFN0cmluZyhfeCkgKyAnLCAnICsgU3RyaW5nKF95KSArICcpJztcclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tICBBWElTICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxucHVibGljIGdldCBheGlzWExhYmVsSW5pdFhQb3MoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF94ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLmF4aXMueExhYmVsLmxlZnRNYXJnaW47XHJcbiAgICByZXR1cm4gX3g7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgYXhpc1hMYWJlbEluaXRZUG9zKCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfeSA9IHRoaXMuc3ZnSGVpZ2h0XHJcbiAgICAgICAgICAgIC0gdGhpcy5jb25maWdEYXRhLmF4aXMueExhYmVsLmJvdHRvbU1hcmdpbjtcclxuICAgIHJldHVybiBfeTtcclxufVxyXG5cclxucHVibGljIGdldCBheGlzVHJhbnNsYXRlUG9zKCk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBfeCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdDtcclxuICAgIGNvbnN0IF95ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi50b3BcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0O1xyXG4gICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIFN0cmluZyhfeCkgKyAnLCAnICsgU3RyaW5nKF95KSArICcpJztcclxufVxyXG5cclxuXHJcbnB1YmxpYyBnZXQgYXhpc1hCb3JkZXJMaW5lV2lkdGgoKTogbnVtYmVyIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ0RhdGEuYXhpcy5ib3JkZXJMaW5lV2lkdGg7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgYXhpc1lCb3JkZXJIZWlnaHQoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF9tYXJnaW4gPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLm1hcmdpbi5ib3R0b21cclxuICAgICAgICAgICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHQ7XHJcbiAgICByZXR1cm4gdGhpcy5zdmdIZWlnaHQgLSBfbWFyZ2luO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGF4aXNYQm9yZGVyV2lkdGgoKTogbnVtYmVyIHtcclxuICAgIGxldCBfbWFyZ2luID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnJpZ2h0O1xyXG4gICAgaWYgKHRoaXMuY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheSkge1xyXG4gICAgICAgIF9tYXJnaW4gKz0gdGhpcy5jb25maWdEYXRhLmxlZ2VuZC50b3RhbFdpZHRoO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMuc3ZnV2lkdGggLSBfbWFyZ2luO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGF4aXNZT3JpZW50KCk6IHN0cmluZyB7XHJcbiAgICByZXR1cm4gJ2xlZnQnO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGF4aXNYT3JpZW50KCk6IHN0cmluZyB7XHJcbiAgICByZXR1cm4gJ2JvdHRvbSc7XHJcbn1cclxucHVibGljIGdldCBheGlzWEJvcmRlclRyYW5zbGF0ZVBvcygpOiBzdHJpbmcge1xyXG4gICAgY29uc3Qgc1lwb3MgPSBTdHJpbmcodGhpcy5zdmdIZWlnaHQgLSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbSk7XHJcbiAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0ICsgJywgJyArIHNZcG9zICsgJyknO1xyXG59XHJcblxyXG5cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLSAgUkFESVVTICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxucHVibGljIGdldCBpbm5lclJhZGl1c1BlcmNlbnQoKTogbnVtYmVyIHtcclxuICAgIHJldHVybiB0aGlzLmNvbmZpZ0RhdGEucGllLmlubmVyUmFkaXVzLnBlcmNlbnQ7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgaW5uZXJSYWRpdXNUaXRsZSgpOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuIHRoaXMuY29uZmlnRGF0YS5waWUuaW5uZXJSYWRpdXMudGl0bGU7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgaW5uZXJSYWRpdXNUaXRsZVRyYW5zbGF0ZVBvcygpOiBzdHJpbmcge1xyXG4gICAgY29uc3QgX3ggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgICAgICsgdGhpcy5ncmFwaFdpZHRoIC8gMjtcclxuICAgIGNvbnN0IF95ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi50b3BcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0XHJcbiAgICAgICAgICAgICsgdGhpcy5ncmFwaEhlaWdodCAvIDJcclxuICAgICAgICAgICAgKyA1O1xyXG4gICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIFN0cmluZyhfeCkgKyAnLCAnICsgU3RyaW5nKF95KSArICcpJztcclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tICBMRUdFTkQgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5wdWJsaWMgZ2V0IGxlZ2VuZEluaXRYUG9zKCk6IG51bWJlciB7XHJcbiAgICBsZXQgX3ggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgICAgICsgdGhpcy5ncmFwaFdpZHRoXHJcbiAgICAgICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS5sZWdlbmQuaW5pdFhQb3MgO1xyXG4gICAgaWYgKHRoaXMuY29uZmlnRGF0YS5sZWdlbmQucG9zaXRpb24gIT09ICdyaWdodCcpIHtcclxuICAgICAgICBfeCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLmluaXRYUG9zIDtcclxuICAgIH1cclxuICAgIHJldHVybiBfeDtcclxufVxyXG5cclxucHVibGljIGdldCBsZWdlbmRJbml0WVBvcygpOiBudW1iZXIge1xyXG4gICAgY29uc3QgX3kgPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHRcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLmluaXRZUG9zO1xyXG4gICAgcmV0dXJuIF95O1xyXG59XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0gIEdSSUQgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5wdWJsaWMgZ2V0IGdyaWRZU3RlcCgpOiBudW1iZXIge1xyXG4gICAgY29uc3QgX21heFkgPSBNYXRoLmNlaWwodGhpcy5tYXhZVmFsdWUgLyAxMDApICogMTA7XHJcbiAgICBjb25zdCBfbGluZU51bSA9IDEwO1xyXG4gICAgY29uc3QgX3N0ZXAgPSBNYXRoLmNlaWwoX21heFkgLyBfbGluZU51bSkgKiBfbGluZU51bTtcclxuICAgIHJldHVybiBfc3RlcDtcclxufVxyXG5cclxucHVibGljIGdldCBncmlkWFN0ZXAoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF9tYXhYID0gTWF0aC5jZWlsKHRoaXMubWF4WFZhbHVlIC8gMTAwKSAqIDEwO1xyXG4gICAgY29uc3QgX2xpbmVOdW0gPSAxMDtcclxuICAgIGNvbnN0IF9zdGVwID0gTWF0aC5jZWlsKF9tYXhYIC8gX2xpbmVOdW0pICogX2xpbmVOdW07XHJcbiAgICByZXR1cm4gX3N0ZXA7XHJcbn1cclxuXHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0gIFRJVExFICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxucHVibGljIGdldCB0aXRsZUluaXRYUG9zKCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfeCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICArICh0aGlzLmdyYXBoV2lkdGggKyB0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLnRvdGFsV2lkdGgpIC8gMlxyXG4gICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5sZWZ0TWFyZ2luO1xyXG4gICAgcmV0dXJuIF94O1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IHRpdGxlSW5pdFlQb3MoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF95ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi50b3BcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0XHJcbiAgICAgICAgICAgIC0gdGhpcy5jb25maWdEYXRhLnRpdGxlLmJvdHRvbU1hcmdpbjtcclxuICAgIHJldHVybiBfeTtcclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tICBDT0xPUiAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbnB1YmxpYyBnZXQgZGVmYXVsdENvbG9yRnVuYygpOiBhbnkge1xyXG4gICAgbGV0IF9jb2xvcjogYW55O1xyXG4gICAgaWYgKHRoaXMuY29uZmlnRGF0YS5jb2xvci5hdXRvICkge1xyXG4gICAgICAgIGlmICh0aGlzLmNvbmZpZ0RhdGEuY29sb3IuZGVmYXVsdENvbG9yTnVtYmVyID09PSAnMjAnKSB7XHJcbiAgICAgICAgICAgIF9jb2xvciA9IGQzLnNjYWxlT3JkaW5hbChkMy5zY2hlbWVDYXRlZ29yeTIwKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBfY29sb3IgPSBkMy5zY2FsZU9yZGluYWwoZDMuc2NoZW1lQ2F0ZWdvcnkxMCk7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIF9jb2xvcjtcclxufVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTzJMaW5lRGF0YSB7XHJcbmNvbnN0cnVjdG9yKFxyXG4gICAgcHVibGljIGRhdGE6IEFycmF5PG51bWJlcj4sXHJcbiAgICBwdWJsaWMgY29sb3I6IHN0cmluZyxcclxuICAgIHB1YmxpYyBkYXNoZWRBcnJheTogc3RyaW5nLFxyXG4gICAgcHVibGljIGludGVycG9sYXRlOiBzdHJpbmdcclxuICAgICkgeyB9XHJcbn1cclxuXHJcblxyXG5leHBvcnQgY2xhc3MgTzJMZWdlbmREYXRhIHtcclxuY29uc3RydWN0b3IoXHJcbiAgIHB1YmxpYyB0aXRsZTogc3RyaW5nLFxyXG4gICAgcHVibGljIGNvbG9yOiBzdHJpbmcgKSB7IH1cclxuXHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBPMlNjYXR0ZXJQbG90RGF0YSB7XHJcbmNvbnN0cnVjdG9yKFxyXG4gICBwdWJsaWMgeDogbnVtYmVyLFxyXG4gICBwdWJsaWMgeTogbnVtYmVyLFxyXG4gICBwdWJsaWMgcjogbnVtYmVyICkgeyB9XHJcblxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTzJTdGFja0JhckRhdGEge1xyXG5jb25zdHJ1Y3RvcihcclxuICAgcHVibGljIHg6IHN0cmluZyxcclxuICAgcHVibGljIHk6IG51bWJlclxyXG4gICApIHsgfVxyXG5cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE8ySWRWYWx1ZURhdGEge1xyXG5jb25zdHJ1Y3RvcihcclxuICAgcHVibGljIGlkOiBudW1iZXIsXHJcbiAgICBwdWJsaWMgdmFsdWU6IG51bWJlclxyXG4gICApIHsgfVxyXG5cclxufVxyXG5cclxuLy8gZXhwb3J0IGNsYXNzIE8yS2V5VmFsdWVEYXRhIHtcclxuLy8gICAgIGNvbnN0cnVjdG9yKFxyXG4vLyAgICAgICAgcHVibGljIGtleTogc3RyaW5nLFxyXG4vLyBcdCAgIHB1YmxpYyB2YWx1ZTogbnVtYmVyXHJcbi8vICAgICAgICApIHsgfVxyXG4vLyB9XHJcbi8vIGV4cG9ydCBjbGFzcyBPMkRhdGVLVkFycmF5RGF0YSB7XHJcbi8vICAgICBjb25zdHJ1Y3RvcihcclxuLy8gICAgICAgIHB1YmxpYyBkYXRlOiBEYXRlLFxyXG4vLyBcdCAgIHB1YmxpYyBrdkFycmF5OiBBcnJheTxPMktleVZhbHVlRGF0YT5cclxuLy8gICAgICAgICkgeyB9XHJcbi8vIH1cclxuLy8gZXhwb3J0IGNsYXNzIE8yRGF0ZVN0S1ZBcnJheURhdGEge1xyXG4vLyAgICAgY29uc3RydWN0b3IoXHJcbi8vICAgICAgICBwdWJsaWMgZGF0ZVN0OiBzdHJpbmcsXHJcbi8vIFx0ICAgcHVibGljIGt2QXJyYXk6IEFycmF5PE8yS2V5VmFsdWVEYXRhPlxyXG4vLyAgICAgICAgKSB7IH1cclxuLy8gfSIsImltcG9ydCB7Q29tcG9uZW50LCBEaXJlY3RpdmUsIElucHV0LCBPbkluaXQsIEluamVjdCwgRWxlbWVudFJlZiB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtPdXRwdXQsIE9uQ2hhbmdlcywgU2ltcGxlQ2hhbmdlfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7TzJDb21tb24sIE8yTGVnZW5kRGF0YSwgTzJTY2F0dGVyUGxvdERhdGEsIE8yU3RhY2tCYXJEYXRhLCBPMkxpbmVEYXRhLCBPMklkVmFsdWVEYXRhfSBmcm9tICcuL3NoYXJlZC9vMmNvbW1vbic7XG5cbmltcG9ydCAqIGFzIENoYXJ0Q29uc3QgZnJvbSAnLi9zaGFyZWQvY2hhcnQtY29uc3QnO1xuaW1wb3J0ICogYXMgZDMgZnJvbSAnZDMnO1xuXG5AQ29tcG9uZW50KHtcbiAgc2VsZWN0b3I6ICdsaWItTmc2TzJDaGFydCcsXG4gIHRlbXBsYXRlOiBgYCxcbiAgc3R5bGVzOiBbXVxufSlcbmV4cG9ydCBjbGFzcyBOZzZPMkNoYXJ0Q29tcG9uZW50IGltcGxlbWVudHMgIE9uSW5pdCAsIE9uQ2hhbmdlcyB7XG4gIEBJbnB1dCgpIGNoYXJ0VHlwZTogc3RyaW5nO1xuICBASW5wdXQoKSBzdmdXaWR0aDogc3RyaW5nO1xuICBASW5wdXQoKSBzdmdIZWlnaHQ6IHN0cmluZztcbiAgQElucHV0KCkgZ3JhcGhEYXRhOiBBcnJheTxudW1iZXI+O1xuICBASW5wdXQoKSBjb25maWdEYXRhOiBhbnk7XG4gIHJvb3Q6IGFueTtcblxuICBjb25zdHJ1Y3RvciggZWxlbWVudFJlZjogRWxlbWVudFJlZiApIHtcbiAgICBjb25zb2xlLmxvZygnZWw6SFRNTEVsZW1lbnQtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG4gICAgY29uc3QgZWw6IEhUTUxFbGVtZW50ICAgID0gZWxlbWVudFJlZi5uYXRpdmVFbGVtZW50O1xuICAgIHRoaXMucm9vdCA9IGQzLnNlbGVjdChlbCk7XG59XG5cbm5nT25Jbml0KCkge1xufVxuXG5uZ09uQ2hhbmdlcyhjaGFuZ2VzOiB7W3Byb3BlcnR5TmFtZTogc3RyaW5nXTogU2ltcGxlQ2hhbmdlfSkge1xuICBjb25zdCBzdmdXaWR0aCA9IHBhcnNlSW50KHRoaXMuc3ZnV2lkdGgsIDEwKTtcbiAgY29uc3Qgc3ZnSGVpZ2h0ID0gcGFyc2VJbnQodGhpcy5zdmdIZWlnaHQsIDEwKTtcbiAgY29uc3QgZGF0YVNldCA9IHRoaXMuZ3JhcGhEYXRhO1xuICBjb25zdCBjb25maWdEYXRhID0gdGhpcy5jb25maWdEYXRhO1xuICBjb25zdCBjaGFydFR5cGUgPSB0aGlzLmNoYXJ0VHlwZTtcbiAgY29uc3Qgc3ZnQ29udGFpbmVyID0gdGhpcy5yb290LmFwcGVuZCgnc3ZnJylcbiAgICAgICAgICAgIC5hdHRyKCd3aWR0aCcsIHN2Z1dpZHRoKVxuICAgICAgICAgICAgLmF0dHIoJ2hlaWdodCcsIHN2Z0hlaWdodCk7XG5cbiAgY29uc29sZS5sb2coY2hhcnRUeXBlKTtcbiAgc3dpdGNoIChjaGFydFR5cGUpIHtcbiAgICBjYXNlIENoYXJ0Q29uc3QuTElORV9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkTGluZShzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LkJBUl9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkQmFyKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LlBJRV9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkUGllKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LlNDQVRURVJfUExPVF9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkU2NhdHRlclBsb3Qoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuSElTVE9HUkFNX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRIaXN0b2dyYW0oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuU1RBQ0tfQkFSX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRTdGFja0JhcihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5HRU9fTUFQX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRHZW9NYXAoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuR0VPX09SVEhPR1JBUEhJQ19DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkR2VvT3J0aG9ncmFwaGljKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LlRSRUVfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZFRyZWUoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuUEFDS19MQVlPVVRfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZFBhY2tMYXlvdXQoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuQ0hPUk9QTEVUSF9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkQ2hvcm9wbGV0aChzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5GT1JDRV9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkRm9yY2Uoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuVFJFRV9NQVBfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgLy8gIHRoaXMuYnVpbGRUcmVlTWFwKHN2Z0NvbnRhaW5lcixjb25maWdEYXRhLCBkYXRhU2V0LHN2Z1dpZHRoLHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LlNBTktFWV9DSEFSVF9UWVBFX05BTUU6XG4gICAgICAvLyAgdGhpcy5idWlsZFNhbmtleShzdmdDb250YWluZXIsY29uZmlnRGF0YSwgZGF0YVNldCxzdmdXaWR0aCxzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGRlZmF1bHQ6XG4gICAgICBicmVhaztcbiAgfVxufVxuXG5cblxucHJpdmF0ZSBidWlsZEhpc3RvZ3JhbShzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZEhpc3RvZ3JhbS0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBkYXRhU2V0ID0gZGF0YVNldEpzb24uZGF0YTtcbiAgY29uc3QgX2Jpbk51bWJlciA9IGRhdGFTZXRKc29uLmJpbnMubGVuZ3RoIC0gMTtcblxuICBjb25zdCBfbWF4WSA9IDMwMDsgLy8gZHVtbXkgbnVtYmVyXG4gIGNvbnN0IF9tYXhYID0gZGF0YVNldEpzb24ucmFuZ2VbMV07XG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG4gIGNvbnN0IF9ncmFwaFdpZHRoID0gY2R0LmdyYXBoV2lkdGg7XG4gIGNvbnN0IF9ncmFwaEhlaWdodCA9IGNkdC5ncmFwaEhlaWdodDtcbiAgY29uc3QgX21heFlWYWx1ZSA9IGNkdC5tYXhZVmFsdWU7XG4gIGNvbnN0IF9ncmFwaFhTY2FsZSA9IGNkdC5ncmFwaFhTY2FsZTtcbiAgY29uc3QgX2dyYXBoSW5pdFggPSBjZHQuZ3JhcGhJbml0WFBvcztcbiAgY29uc3QgX2dyYXBoSW5pdFkgPSBjZHQuZ3JhcGhJbml0WVBvcztcblxuICBjb25zdCBfdGl0bGVEaXNwbGF5ID0gY29uZmlnRGF0YS50aXRsZS5kaXNwbGF5O1xuICBjb25zdCBfYW5pbWF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZW5hYmxlO1xuICBjb25zdCBfYW5pbWF0aW9uRHVyYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5kdXJhdGlvbjtcbiAgY29uc3QgX2dyaWRZRGlzcGxheSA9IGNvbmZpZ0RhdGEuZ3JpZC55LmRpc3BsYXk7XG4gIGNvbnN0IF9tYXJnaW5MZWZ0ID0gY29uZmlnRGF0YS5tYXJnaW4ubGVmdDtcbiAgY29uc3QgX21hcmdpblRvcCA9IGNvbmZpZ0RhdGEubWFyZ2luLnRvcDtcbiAgY29uc3QgX2NsYXNzTmFtZSA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLmhpc3RvZ3JhbUJhcjtcblxuXG4gIGNvbnN0IF9kYXRhU2V0OiBBcnJheTxudW1iZXI+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0KSB7XG4gICAgICBpZiAoZGF0YVNldC5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGNvbnN0IF9udW0gPSBkYXRhU2V0W2ldIC8gX21heFg7XG4gICAgICAgICAgX2RhdGFTZXQucHVzaChfbnVtKTtcbiAgICAgIH1cbiAgfVxuXG4gIGNvbnN0IGZvcm1hdENvdW50ID0gZDMuZm9ybWF0KCcsLjBmJyk7XG5cbiAgY29uc3QgX2hpc3RncmFtQ29udGFpbmVyID0gc3ZnQ29udGFpbmVyXG4gICAgICAgICAgICAgICAgICAuYXBwZW5kKCdnJylcbiAgICAgICAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAndHJhbnNsYXRlKCcgKyBfZ3JhcGhJbml0WCArICcsJyArIF9ncmFwaEluaXRZICsgJyknKTtcblxuICBjb25zdCBfeFNjYWxlID0gZDMuc2NhbGVMaW5lYXIoKVxuICAgICAgLnJhbmdlUm91bmQoWzAsIF9ncmFwaFdpZHRoXSk7XG5cbiAgY29uc3QgYmlucyA9IGQzLmhpc3RvZ3JhbSgpXG4gICAgICAuZG9tYWluKFswLCAxXSlcbiAgICAgIC50aHJlc2hvbGRzKF94U2NhbGUudGlja3MoX2Jpbk51bWJlcikpXG4gICAgICAoX2RhdGFTZXQpO1xuXG5cbiAgY29uc3QgX3lTY2FsZSA9IGQzLnNjYWxlTGluZWFyKClcbiAgICAgIC5kb21haW4oWzAsIGQzLm1heChiaW5zLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGQubGVuZ3RoO1xuICAgICAgfSldKVxuICAgICAgLnJhbmdlKFtfZ3JhcGhIZWlnaHQsIDBdKTtcblxuICBjb25zdCBiYXIgPSBfaGlzdGdyYW1Db250YWluZXJcbiAgICAgIC5zZWxlY3RBbGwoJy5iYXInKVxuICAgICAgLmRhdGEoYmlucylcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCdjbGFzcycsIF9jbGFzc05hbWUpXG4gICAgICAuYXR0cigndHJhbnNmb3JtJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyBfeFNjYWxlKGQueDApICsgJywnICsgX3lTY2FsZShkLmxlbmd0aCkgKyAnKSc7XG4gICAgICB9KTtcblxuICBpZiAoX2FuaW1hdGlvbikge1xuICAgICAgYmFyLmFwcGVuZCgncmVjdCcpXG4gICAgICAgICAgLmF0dHIoJ3gnLCAgMSlcbiAgICAgICAgICAuYXR0cignd2lkdGgnLCBfeFNjYWxlKGJpbnNbMF0ueDEpIC0gX3hTY2FsZShiaW5zWzBdLngwKSAtIDEpXG4gICAgICAgICAgLmF0dHIoJ2hlaWdodCcsIDApXG4gICAgICAgICAgLnRyYW5zaXRpb24oKVxuICAgICAgICAgIC5kdXJhdGlvbihfYW5pbWF0aW9uRHVyYXRpb24pXG4gICAgICAgICAgLmF0dHIoJ2hlaWdodCcsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIF9ncmFwaEhlaWdodCAtIF95U2NhbGUoZC5sZW5ndGgpO1xuICAgICAgICAgIH0pO1xuICB9IGVsc2Uge1xuICAgICAgYmFyLmFwcGVuZCgncmVjdCcpXG4gICAgICAgICAgLmF0dHIoJ3gnLCAxKVxuICAgICAgICAgIC5hdHRyKCd3aWR0aCcsIF94U2NhbGUoYmluc1swXS54MSkgLSBfeFNjYWxlKGJpbnNbMF0ueDApIC0gMSlcbiAgICAgICAgICAuYXR0cignaGVpZ2h0JywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gX2dyYXBoSGVpZ2h0IC0gX3lTY2FsZShkLmxlbmd0aCk7XG4gICAgICAgICAgfSk7XG4gIH1cblxuICBiYXIuYXBwZW5kKCd0ZXh0JylcbiAgICAgIC5hdHRyKCdkeScsICcuNzVlbScpXG4gICAgICAuYXR0cigneScsIDYpXG4gICAgICAuYXR0cigneCcsIChfeFNjYWxlKGJpbnNbMF0ueDEpIC0gX3hTY2FsZShiaW5zWzBdLngwKSkgLyAyKVxuICAgICAgLmF0dHIoJ3RleHQtYW5jaG9yJywgJ21pZGRsZScpXG4gICAgICAudGV4dCgoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGZvcm1hdENvdW50KGQubGVuZ3RoKTtcbiAgICAgIH0pO1xuXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfdGl0bGVEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdUaXRsZShjZHQpO1xuICB9XG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkQXhpcy0tLS0tLS0tLS0tLS0tLS0tXG4gIHRoaXMuYnVpbGRZQXhpcyhjZHQpO1xuXG4gIHRoaXMuYnVpbGRYQXhpcyhjZHQpO1xuXG4gICBpZiAoX2dyaWRZRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3WUdyaWQoY2R0KTtcbiAgfVxufVxuXG5cblxucHJpdmF0ZSBidWlsZEZvcmNlKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ0luICBidWlsZEZvY2UtLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgX21heFggPSAxMDA7XG4gIGNvbnN0IF9tYXhZID0gMTAwO1xuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuXG4gIGNvbnN0IF9jb2xvciA9IGNkdC5kZWZhdWx0Q29sb3JGdW5jO1xuICBjb25zdCBfaW5pdFBvc1ggPSBjZHQuZ3JhcGhJbml0WFBvcztcbiAgY29uc3QgX2luaXRQb3NZID0gY2R0LmdyYXBoSW5pdFlQb3M7XG4gIGNvbnN0IF9jZW50ZXJQb3MgPSBjZHQuZ3JhcGhDZW50ZXJQb3M7XG4gIGNvbnN0IF9ncmFwaEhlaWdodCA9IGNkdC5ncmFwaEhlaWdodDtcbiAgY29uc3QgX2dyYXBoV2lkdGggPSBjZHQuZ3JhcGhXaWR0aDtcblxuICBjb25zdCBfbWFyZ2luTGVmdCA9IGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQ7XG4gIGNvbnN0IF9tYXJnaW5Ub3AgPSBjb25maWdEYXRhLm1hcmdpbi50b3A7XG5cblxuICBjb25zdCBzaW11bGF0aW9uID0gZDMuZm9yY2VTaW11bGF0aW9uKClcbiAgICAgIC5mb3JjZSgnbGluaycsIGQzLmZvcmNlTGluaygpLmlkKChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gZC5pZDtcbiAgICAgIH0pKVxuICAgICAgLmZvcmNlKCdjaGFyZ2UnLCBkMy5mb3JjZU1hbnlCb2R5KCkpXG4gICAgICAuZm9yY2UoJ2NlbnRlcicsIGQzLmZvcmNlQ2VudGVyKF9ncmFwaFdpZHRoIC8gMiwgX2dyYXBoSGVpZ2h0IC8gMikpO1xuXG5cbiAgY29uc3QgX2ZvcmNlQ29udGFpbmVyID0gc3ZnQ29udGFpbmVyXG4gICAgLmFwcGVuZCgnZycpXG4gICAgLmF0dHIoJ3RyYW5zZm9ybScsXG4gICAgICAndHJhbnNsYXRlKCcgKyBfbWFyZ2luTGVmdCArICcsJyArIF9tYXJnaW5Ub3AgKyAnKScpO1xuXG4gIGNvbnN0IGxpbmsgPSBfZm9yY2VDb250YWluZXIuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCdjbGFzcycsICdmb3JjZS1saW5rcycpXG4gICAgICAuc2VsZWN0QWxsKCdsaW5lJylcbiAgICAgIC5kYXRhKGRhdGFTZXRKc29uLmxpbmtzKVxuICAgICAgLmVudGVyKClcbiAgICAgIC5hcHBlbmQoJ2xpbmUnKVxuICAgICAgLmF0dHIoJ3N0cm9rZS13aWR0aCcsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gTWF0aC5zcXJ0KGQudmFsdWUpO1xuICAgICAgfSk7XG5cbiAgY29uc3Qgbm9kZSA9IF9mb3JjZUNvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgJ25vZGVzJylcbiAgICAgIC5zZWxlY3RBbGwoJ2NpcmNsZScpXG4gICAgICAuZGF0YShkYXRhU2V0SnNvbi5ub2RlcylcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdjaXJjbGUnKVxuICAgICAgLmF0dHIoJ3InLCA1KVxuICAgICAgLmF0dHIoJ2ZpbGwnLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIF9jb2xvcihkLmdyb3VwKTtcbiAgICAgIH0pXG4gICAgICAuY2FsbChkMy5kcmFnKClcbiAgICAgICAgICAub24oJ3N0YXJ0JywgZHJhZ3N0YXJ0ZWQpXG4gICAgICAgICAgLm9uKCdkcmFnJywgZHJhZ2dlZClcbiAgICAgICAgICAub24oJ2VuZCcsIGRyYWdlbmRlZCkpO1xuXG4gICAgICBub2RlLmFwcGVuZCgndGl0bGUnKVxuICAgICAgICAgIC50ZXh0KChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIGQuaWQ7XG4gICAgICAgICAgfSk7XG5cbiAgc2ltdWxhdGlvblxuICAgICAgLm5vZGVzKGRhdGFTZXRKc29uLm5vZGVzKVxuICAgICAgLm9uKCd0aWNrJywgdGlja2VkKTtcblxuICBjb25zdCBfZm9yY2VMaW5rOiBhbnkgPSBzaW11bGF0aW9uLmZvcmNlKCdsaW5rJyk7XG4gIF9mb3JjZUxpbmsubGlua3MoZGF0YVNldEpzb24ubGlua3MpO1xuXG4gIGZ1bmN0aW9uIHRpY2tlZCgpIHtcbiAgICAgIGxpbmtcbiAgICAgICAgICAuYXR0cigneDEnLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgcmV0dXJuIGQuc291cmNlLng7IH0pXG4gICAgICAgICAgLmF0dHIoJ3kxJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIGQuc291cmNlLnk7IH0pXG4gICAgICAgICAgLmF0dHIoJ3gyJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgIHJldHVybiBkLnRhcmdldC54OyB9KVxuICAgICAgICAgIC5hdHRyKCd5MicsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICByZXR1cm4gZC50YXJnZXQueTsgfSk7XG5cbiAgICAgIG5vZGVcbiAgICAgICAgICAuYXR0cignY3gnLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgcmV0dXJuIGQueDsgfSlcbiAgICAgICAgICAuYXR0cignY3knLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgcmV0dXJuIGQueTsgfSk7XG4gIH1cblxuICBmdW5jdGlvbiBkcmFnc3RhcnRlZChkOiBhbnkpICB7XG4gICAgICBpZiAoIWQzLmV2ZW50LmFjdGl2ZSkge1xuICAgICAgICAgIHNpbXVsYXRpb24uYWxwaGFUYXJnZXQoMC4zKS5yZXN0YXJ0KCk7XG4gICAgICB9XG4gICAgICBkLmZ4ID0gZC54O1xuICAgICAgZC5meSA9IGQueTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGRyYWdnZWQoZDogYW55KSAge1xuICAgICAgZC5meCA9IGQzLmV2ZW50Lng7XG4gICAgICBkLmZ5ID0gZDMuZXZlbnQueTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGRyYWdlbmRlZChkOiBhbnkpICB7XG4gICAgICBpZiAoIWQzLmV2ZW50LmFjdGl2ZSkge1xuICAgICAgICAgIHNpbXVsYXRpb24uYWxwaGFUYXJnZXQoMCk7XG4gICAgICB9XG4gICAgICBkLmZ4ID0gbnVsbDtcbiAgICAgIGQuZnkgPSBudWxsO1xuICB9XG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBidWlsZExlZ2VuZC0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0IF9sZWdlbmREYXRhU2V0OiBBcnJheTxPMkxlZ2VuZERhdGE+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5ncm91cHMpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5ncm91cHMuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBjb25zdCBfaWQgPSBkYXRhU2V0SnNvbi5ncm91cHNbaV0uaWQ7XG4gICAgICAgICAgX2xlZ2VuZERhdGFTZXQucHVzaChuZXcgTzJMZWdlbmREYXRhKGRhdGFTZXRKc29uLmdyb3Vwc1tpXS5uYW1lLCBfY29sb3IoX2lkKSkpO1xuICAgICAgfVxuICB9XG4gIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG5cblxuXG59XG5cblxucHJpdmF0ZSBidWlsZENob3JvcGxldGgoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRDaG9yb3BsZXRoIC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfbWF4WCA9IDEwMDsgLy8gYW55IHZhbHVlXG4gIGNvbnN0IF9tYXhZID0gMTAwOyAvLyBhbnkgdmFsdWVcbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcbiAgY29uc3QgX2dyYXBoQ2VudGVyUG9zID0gY2R0LmdyYXBoQ2VudGVyUG9zO1xuICBjb25zdCBfZ3JhcGhJbml0WCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfZ3JhcGhJbml0WSA9IGNkdC5ncmFwaEluaXRZUG9zO1xuXG5cbiAgY29uc3QgX3RpdGxlRGlzcGxheSA9IGNvbmZpZ0RhdGEudGl0bGUuZGlzcGxheTtcbiAgY29uc3QgX2xlZ2VuZERpc3BsYXkgPSBjb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5O1xuICBjb25zdCBfZm9jdXNDb2xvciA9IGNvbmZpZ0RhdGEuY29sb3IuZm9jdXNDb2xvcjtcblxuICBjb25zdCBfc2NhbGUgPSBkYXRhU2V0SnNvbi5tYXAuc2NhbGU7XG4gIGNvbnN0IF90YXJnZXROYW1lID0gZGF0YVNldEpzb24ubWFwLnRhcmdldE5hbWU7XG4gIGNvbnN0IF9rZXlEYXRhTmFtZSA9IGRhdGFTZXRKc29uLm1hcC5rZXlEYXRhTmFtZTtcbiAgY29uc3QgX2tleU5hbWUgPSAnZGF0YS4nICsgX2tleURhdGFOYW1lO1xuICBjb25zdCBfZ2VvTWFwRGF0YVVybCA9IGRhdGFTZXRKc29uLm1hcC5iYXNlR2VvRGF0YVVybDtcbiAgY29uc3QgX3N0YXJ0Q29sb3IgPSBkYXRhU2V0SnNvbi5tYXAuc3RhcnRDb2xvcjtcbiAgY29uc3QgX2VuZENvbG9yID0gZGF0YVNldEpzb24ubWFwLmVuZENvbG9yO1xuICBjb25zdCBfY29sb3JOdW0gPSBkYXRhU2V0SnNvbi5tYXAuY29sb3JOdW1iZXI7XG4gIGNvbnN0IF9jZW50ZXIgPSBkYXRhU2V0SnNvbi5tYXAuY2VudGVyO1xuICBjb25zdCBfdGFyZ2V0UHJvcGVydHlOYW1lID0gZGF0YVNldEpzb24ubWFwLnRhcmdldFByb3BlcnR5TmFtZTtcbiAgY29uc3QgX3RhcmdldFByb3BlcnR5ID0gJ2QuJyArIF90YXJnZXRQcm9wZXJ0eU5hbWU7XG5cbiAgY29uc3QgY29sb3IgPSBkMy5pbnRlcnBvbGF0ZUhzbChfc3RhcnRDb2xvciwgX2VuZENvbG9yKTtcblxuICBsZXQgX21heCA9IGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWU7XG4gIGxldCBfbWluID0gZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgaWYgKF9tYXggPCBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlKSB7XG4gICAgICAgICAgICAgIF9tYXggPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoX21pbiA+IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUpIHtcbiAgICAgICAgICAgICAgX21pbiA9IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWU7XG4gICAgICAgICAgfVxuICAgICAgfVxuICB9XG4gIGNvbnN0IF9yYW5nZSA9IF9tYXggLSBfbWluO1xuICBjb25zdCBfc3RlcCA9IF9yYW5nZSAvIChfY29sb3JOdW0gLSAxKTtcblxuICBjb25zdCBfZmluZENvbG9yQnlJZCA9IChpZDogbnVtYmVyKTogc3RyaW5nID0+IHtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgaWYgKGlkID09PSBkYXRhU2V0SnNvbi5kYXRhW2ldLmlkKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBfdmFsdWUgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgY29uc3QgX3JhdGUgPSBNYXRoLmNlaWwoKF92YWx1ZSAtIF9taW4pIC8gX3N0ZXApO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbG9yKF9yYXRlIC8gX21heCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gIH07XG5cbiAgY29uc3QgcGF0aCA9IGQzLmdlb1BhdGgoKVxuICAgICAgICAgICAgICAucHJvamVjdGlvbihcbiAgICAgICAgICAgICAgICAgIGQzLmdlb01lcmNhdG9yKClcbiAgICAgICAgICAgICAgICAgIC5jZW50ZXIoX2NlbnRlcilcbiAgICAgICAgICAgICAgICAgIC5zY2FsZShfc2NhbGUpXG4gICAgICAgICAgICAgICAgICAudHJhbnNsYXRlKF9ncmFwaENlbnRlclBvcylcbiAgICAgICAgICAgICAgKTtcblxuICBkMy5qc29uKF9nZW9NYXBEYXRhVXJsLCAoZXJyb3IsIGRhdGEpID0+IHtcbiAgICAgIHN2Z0NvbnRhaW5lci5zZWxlY3RBbGwoJ3BhdGgnKVxuICAgICAgICAgICAgICAuZGF0YShldmFsKF9rZXlOYW1lKSlcbiAgICAgICAgICAgICAgLmVudGVyKClcbiAgICAgICAgICAgICAgLmFwcGVuZCgncGF0aCcpXG4gICAgICAgICAgICAgIC5hdHRyKCdkJywgcGF0aClcbiAgICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX2NsID0gX2ZpbmRDb2xvckJ5SWQoZXZhbChfdGFyZ2V0UHJvcGVydHkpKTtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBfY2w7XG4gICAgICAgICAgICAgIH0pO1xuICB9KTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZFRpdGxlLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF90aXRsZURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1RpdGxlKGNkdCk7XG4gIH1cblxuICAvLyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vICAtLS1DQUxMIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF9sZWdlbmREaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBfY29sb3JOdW07IGkrKykge1xuICAgICAgICAgIGNvbnN0IF9sYWJlbCA9IFN0cmluZyhfbWluICsgKGkgKiBfc3RlcCkpICsgICcgLS0nO1xuICAgICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShfbGFiZWwsIGNvbG9yKGkgLyBfbWF4KSkpO1xuICAgICAgfVxuICAgICAgdGhpcy5idWlsZExlZ2VuZChjZHQsIF9sZWdlbmREYXRhU2V0KTtcbiAgfVxuXG59XG5cbnByaXZhdGUgYnVpbGRQYWNrTGF5b3V0KHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIFBhY2tMYXlvdXQtLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfcGFja2xheW91dENsYXNzID0gY29uZmlnRGF0YS5jbGFzc05hbWUucGFja2xheW91dDtcbiAgY29uc3QgX3BhY2tsYXlvdXRMYWJlbENsYXNzID0gY29uZmlnRGF0YS5jbGFzc05hbWUucGFja2xheW91dExhYmVsO1xuICBjb25zdCBfYW5pbWF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZW5hYmxlO1xuICBjb25zdCBfYW5pbWF0aW9uRHVyYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5kdXJhdGlvbjtcbiAgY29uc3QgY29sb3IgPSBkMy5zY2FsZU9yZGluYWwoZDMuc2NoZW1lQ2F0ZWdvcnkxMCk7XG4gIC8vICBjb25zdCBjb2xvciA9IGQzLnNjYWxlLmNhdGVnb3J5MTAoKTtcbiAgY29uc3QgYnViYmxlID0gZDMucGFjaygpXG4gICAgICAgICAgICAgICAgICAuc2l6ZShbc3ZnV2lkdGgsIHN2Z0hlaWdodF0pO1xuXG4gIGNvbnN0IG5vZGVzMCA9IGQzLmhpZXJhcmNoeShkYXRhU2V0SnNvbik7XG5cbiAgY29uc3QgcGFjayA9ICBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdnJylcbiAgICAgICAgICAgICAgLmRhdGEoYnViYmxlKG5vZGVzMCkuZGVzY2VuZGFudHMoKSlcbiAgICAgICAgICAgICAgLmVudGVyKClcbiAgICAgICAgICAgICAgLmFwcGVuZCgnZycpXG4gICAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgZC54ICsgJywnICsgZC55ICsgJyknO1xuICAgICAgICAgICAgICB9KTtcblxuICBjb25zdCBfY2lyY2xlID0gcGFjay5hcHBlbmQoJ2NpcmNsZScpO1xuICBpZiAoX2FuaW1hdGlvbikge1xuICAgICAgX2NpcmNsZS5hdHRyKCdyJywgMClcbiAgICAgICAgICAgICAgLnRyYW5zaXRpb24oKVxuICAgICAgICAgICAgICAuZHVyYXRpb24oKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGQuZGVwdGggKiBfYW5pbWF0aW9uRHVyYXRpb24gICsgNTAwO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAuYXR0cigncicsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBkLnI7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIChkOiBhbnksIGk6IGFueSkgPT4gIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjb2xvcihpKTtcbiAgICAgICAgICAgICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgICBfY2lyY2xlLmF0dHIoJ3InLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gZC5yO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAoZDogYW55LCBpOiBhbnkpID0+ICB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gY29sb3IoaSk7XG4gICAgICAgICAgICAgIH0pO1xuICB9XG5cbiAgY29uc3QgX3RleHQgPSBwYWNrLmFwcGVuZCgndGV4dCcpXG4gICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIF9wYWNrbGF5b3V0TGFiZWxDbGFzcylcbiAgICAgICAgICAgICAgLnRleHQoKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICAgICAgaWYgKGQuZGVwdGggPT09IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZC5kYXRhLm5hbWU7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICAgfSk7XG5cbiAgaWYgKF9hbmltYXRpb24pIHtcbiAgICAgIF90ZXh0LnN0eWxlKCdvcGFjaXR5JywgMClcbiAgICAgICAgICAudHJhbnNpdGlvbigpXG4gICAgICAgICAgLmR1cmF0aW9uKF9hbmltYXRpb25EdXJhdGlvbilcbiAgICAgICAgICAuc3R5bGUoJ29wYWNpdHknLCAxLjApO1xuICB9IGVsc2Uge1xuICAgICAgX3RleHQuc3R5bGUoJ29wYWNpdHknLCAxLjApO1xuICB9XG5cbn1cblxucHJpdmF0ZSBidWlsZFRyZWUoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnSW4gIGJ1aWxkVHJlZS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBsZXQgX21heFggPSAwO1xuICBsZXQgX21heFkgPSAwO1xuICBfbWF4WSA9IDEwMDtcbiAgX21heFggPSAxMDA7XG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG5cbiAgY29uc3QgX2NvbG9yID0gY2R0LmRlZmF1bHRDb2xvckZ1bmM7XG4gIGNvbnN0IF9pbml0UG9zWCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfaW5pdFBvc1kgPSBjZHQuZ3JhcGhJbml0WVBvcztcbiAgY29uc3QgX2dyYXBoSGVpZ2h0ID0gY2R0LmdyYXBoSGVpZ2h0O1xuICBjb25zdCBfZ3JhcGhXaWR0aCA9IGNkdC5ncmFwaFdpZHRoO1xuXG4gIGNvbnN0IF9hbmltYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5lbmFibGU7XG4gIGNvbnN0IF9hbmltYXRpb25EdXJhdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmR1cmF0aW9uO1xuICBjb25zdCBfdHJlZW1hcENsYXNzID0gY29uZmlnRGF0YS5jbGFzc05hbWUudHJlZW1hcDtcbiAgY29uc3QgX3RyZWVtYXBMYWJlbENsYXNzID0gY29uZmlnRGF0YS5jbGFzc05hbWUudHJlZW1hcExhYmVsO1xuICBjb25zdCBfbWFyZ2luTGVmdCA9IGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQ7XG4gIGNvbnN0IF9tYXJnaW5Ub3AgPSBjb25maWdEYXRhLm1hcmdpbi50b3A7XG5cblxuICBjb25zdCB0cmVlID0gZDMudHJlZSgpXG4gICAgICAgICAgICAgICAgICAuc2l6ZShbX2dyYXBoV2lkdGgsIF9ncmFwaEhlaWdodF0pO1xuXG4gIGNvbnN0IG5vZGVzMCA9IGQzLmhpZXJhcmNoeShkYXRhU2V0SnNvbik7XG5cbiAgY29uc3Qgbm9kZXMgPSB0cmVlKG5vZGVzMCk7XG5cbiAgY29uc3QgX3RyZWVDb250YWluZXIgPSBzdmdDb250YWluZXJcbiAgICAuYXBwZW5kKCdnJylcbiAgICAuYXR0cigndHJhbnNmb3JtJyxcbiAgICAgICd0cmFuc2xhdGUoJyArIF9tYXJnaW5MZWZ0ICsgJywnICsgX21hcmdpblRvcCArICcpJyk7XG5cbiAgY29uc3QgbGluayA9IF90cmVlQ29udGFpbmVyXG4gICAgICAuc2VsZWN0QWxsKCcubGluaycpXG4gICAgICAuZGF0YSggbm9kZXMuZGVzY2VuZGFudHMoKS5zbGljZSgxKSlcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdwYXRoJylcbiAgICAgIC5hdHRyKCdjbGFzcycsICd0cmVlLW5vZGUtbGluaycpXG4gICAgICAuYXR0cignZCcsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gJ00nICsgZC54ICsgJywnICsgZC55XG4gICAgICAgICAgICAgICsgJ0MnICsgZC54ICsgJywnICsgKGQueSArIGQucGFyZW50LnkpIC8gMlxuICAgICAgICAgICAgICArICcgJyArIGQucGFyZW50LnggKyAnLCcgKyAgKGQueSArIGQucGFyZW50LnkpIC8gMlxuICAgICAgICAgICAgICArICcgJyArIGQucGFyZW50LnggKyAnLCcgKyBkLnBhcmVudC55O1xuICAgICAgICAgIH1cbiAgICAgICk7XG5cbiAgY29uc3Qgbm9kZSA9IF90cmVlQ29udGFpbmVyXG4gICAgICAuc2VsZWN0QWxsKCcubm9kZScpXG4gICAgICAuZGF0YShub2Rlcy5kZXNjZW5kYW50cygpKVxuICAgICAgLmVudGVyKClcbiAgICAgIC5hcHBlbmQoJ2cnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiAndHJlZS1ub2RlJyArXG4gICAgICAgICAgKGQuY2hpbGRyZW4gPyAnLWludGVybmFsJyA6ICctbGVhZicpO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIGQueCArICcsJyArIGQueSArICcpJztcbiAgICAgIH0pO1xuXG4gIG5vZGUuYXBwZW5kKCdjaXJjbGUnKVxuICAgICAgLmF0dHIoJ3InLCAxMCk7XG5cbiAgbm9kZS5hcHBlbmQoJ3RleHQnKVxuICAgICAgLmF0dHIoJ2R5JywgJy4zNWVtJylcbiAgICAgIC5hdHRyKCd5JywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiBkLmNoaWxkcmVuID8gLTIwIDogMjA7XG4gICAgICB9KVxuICAgICAgLnN0eWxlKCd0ZXh0LWFuY2hvcicsICdtaWRkbGUnKVxuICAgICAgLnRleHQoKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiBkLmRhdGEubmFtZTtcbiAgICAgIH0pO1xuXG5cbn1cblxuXG5cbnByaXZhdGUgYnVpbGRHZW9PcnRob2dyYXBoaWMoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRHZW9PcnRob2dyYXBoaWMgLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IF9tYXhYID0gMTAwOyAvLyBhbnkgdmFsdWVcbiAgY29uc3QgX21heFkgPSAxMDA7IC8vIGFueSB2YWx1ZVxuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuICBjb25zdCBfZ3JhcGhDZW50ZXJQb3MgPSBjZHQuZ3JhcGhDZW50ZXJQb3M7XG4gIGNvbnN0IF9ncmFwaEluaXRYID0gY2R0LmdyYXBoSW5pdFhQb3M7XG4gIGNvbnN0IF9ncmFwaEluaXRZID0gY2R0LmdyYXBoSW5pdFlQb3M7XG5cbiAgY29uc3QgX3RpdGxlRGlzcGxheSA9IGNvbmZpZ0RhdGEudGl0bGUuZGlzcGxheTtcbiAgY29uc3QgX2xlZ2VuZERpc3BsYXkgPSBjb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5O1xuICBjb25zdCBfZm9jdXNDb2xvciA9IGNvbmZpZ0RhdGEuY29sb3IuZm9jdXNDb2xvcjtcblxuICBjb25zdCBfZ2VvTWFwRGF0YVVybCA9IGRhdGFTZXRKc29uLm1hcC5iYXNlR2VvRGF0YVVybDtcbiAgY29uc3QgX3NjYWxlID0gZGF0YVNldEpzb24ubWFwLnNjYWxlO1xuICBjb25zdCBfdGFyZ2V0TmFtZSA9IGRhdGFTZXRKc29uLm1hcC50YXJnZXROYW1lO1xuICBjb25zdCBfdGFyZ2V0UHJvcGVydHkgPSAnZC4nICsgZGF0YVNldEpzb24ubWFwLnRhcmdldFByb3BlcnR5TmFtZTtcbiAgY29uc3QgX2tleURhdGFOYW1lID0gZGF0YVNldEpzb24ubWFwLmtleURhdGFOYW1lO1xuICBjb25zdCBfa2V5TmFtZSA9ICdkYXRhLicgKyBfa2V5RGF0YU5hbWU7XG4gIGNvbnN0IF9jbGlwQW5nbGUgPSBkYXRhU2V0SnNvbi5tYXAuY2xpcEFuZ2xlO1xuICBjb25zdCBfcm90YXRlSCAgID0gZGF0YVNldEpzb24ubWFwLnJvdGF0ZS5ob3Jpem9udGFsO1xuICBjb25zdCBfcm90YXRlViAgID0gZGF0YVNldEpzb24ubWFwLnJvdGF0ZS52ZXJ0aWNhbDtcbiAgY29uc3QgX29jZWFuQ29sb3IgPSBkYXRhU2V0SnNvbi5tYXAub2NlYW5Db2xvcjtcbiAgY29uc3QgX2FudGFyY3RpY2FDb2xvciA9IGRhdGFTZXRKc29uLm1hcC5hbnRhcmN0aWNhQ29sb3I7XG4gIGNvbnN0IF9hbmltYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5lbmFibGU7XG4gIGNvbnN0IF9hbmltYXRpb25EdXJhdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmR1cmF0aW9uO1xuICBsZXQgX2FuaW1hdGlvbkggPSAwO1xuXG4gIGNvbnN0IF9maW5kQ29sb3JCeU5hbWUgPSAobmFtZTogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgaWYgKG5hbWUgPT09IGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZSkge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX2NvbG9yID0gZGF0YVNldEpzb24uZGF0YVtpXS5jb2xvcjtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBfY29sb3I7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgfTtcblxuICBjb25zdCB0YXJnZXRQYXRoID0gZDMuZ2VvT3J0aG9ncmFwaGljKClcbiAgICAgICAgICAgICAgLnRyYW5zbGF0ZShfZ3JhcGhDZW50ZXJQb3MpXG4gICAgICAgICAgICAgIC5jbGlwQW5nbGUoX2NsaXBBbmdsZSlcbiAgICAgICAgICAgICAgLnNjYWxlKF9zY2FsZSlcbiAgICAgICAgICAgICAgLnJvdGF0ZShbX3JvdGF0ZUgsIF9yb3RhdGVWXSk7XG5cbiAgY29uc3QgcGF0aCA9IGQzLmdlb1BhdGgoKVxuICAgICAgICAgICAgICAucHJvamVjdGlvbihcbiAgICAgICAgICAgICAgICAgIHRhcmdldFBhdGhcbiAgICAgICAgICAgICAgKTtcblxuICBkMy5qc29uKF9nZW9NYXBEYXRhVXJsLCAoZXJyb3IsIGRhdGEpID0+IHtcbiAgICAgIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ2NpcmNsZScpXG4gICAgICAgICAgLmF0dHIoJ2N4JywgX2dyYXBoQ2VudGVyUG9zWzBdKVxuICAgICAgICAgIC5hdHRyKCdjeScsIF9ncmFwaENlbnRlclBvc1sxXSlcbiAgICAgICAgICAuYXR0cigncicsIF9zY2FsZSlcbiAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCBfb2NlYW5Db2xvcik7XG5cbiAgICAgIGNvbnN0IGVhcnRoUGF0aCA9IHN2Z0NvbnRhaW5lci5zZWxlY3RBbGwoJ3BhdGgnKVxuICAgICAgICAgIC5kYXRhKGV2YWwoX2tleU5hbWUpKVxuICAgICAgICAgIC5lbnRlcigpXG4gICAgICAgICAgLmFwcGVuZCgncGF0aCcpXG4gICAgICAgICAgLmF0dHIoJ2QnLCBwYXRoKVxuICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICAgICAgY29uc3QgX3RhcmdldEFyZWEgPSBldmFsKF90YXJnZXRQcm9wZXJ0eSk7XG4gICAgICAgICAgICAgIGlmIChfZmluZENvbG9yQnlOYW1lKF90YXJnZXRBcmVhKSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIF9maW5kQ29sb3JCeU5hbWUoX3RhcmdldEFyZWEpO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgcmV0dXJuICdoc2woJyArIGkgKyAnLDgwJSw2MCUpJztcbiAgICAgICAgICB9KTtcbiAgICAgIGlmIChfYW5pbWF0aW9uKSB7XG4gICAgICAgICAgZDMudGltZXIoKCkgPT4ge1xuICAgICAgICAgICAgICB0YXJnZXRQYXRoLnJvdGF0ZShbX3JvdGF0ZUggKyBfYW5pbWF0aW9uSCwgX3JvdGF0ZVZdKTtcbiAgICAgICAgICAgICAgX2FuaW1hdGlvbkggKz0gMjtcbiAgICAgICAgICAgICAgZWFydGhQYXRoLmF0dHIoJ2QnLCBwYXRoKTtcbiAgICAgICAgICB9KTtcbiAgICAgIH1cbiAgfSk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfdGl0bGVEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdUaXRsZShjZHQpO1xuICB9XG5cbiAgaWYgKF9sZWdlbmREaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICAgICAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICBjb25zdCBfbmFtZSA9IGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZTtcbiAgICAgICAgICAgICAgY29uc3QgX2NvbG9yID0gZGF0YVNldEpzb24uZGF0YVtpXS5jb2xvcjtcbiAgICAgICAgICAgICAgaWYgKF9uYW1lID09PSAnQW50YXJjdGljYScpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWUsIGRhdGFTZXRKc29uLmRhdGFbaV0uY29sb3IpKTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLmJ1aWxkTGVnZW5kKGNkdCwgX2xlZ2VuZERhdGFTZXQpO1xuICB9XG5cblxufVxuXG5cblxucHJpdmF0ZSBidWlsZEdlb01hcChzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZEdlb01hcCAtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgX21heFggPSAxMDA7IC8vIGFueSB2YWx1ZVxuICBjb25zdCBfbWF4WSA9IDEwMDsgLy8gYW55IHZhbHVlXG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG4gIGNvbnN0IF9ncmFwaENlbnRlclBvcyA9IGNkdC5ncmFwaENlbnRlclBvcztcbiAgY29uc3QgX2dlb01hcERhdGFVcmwgPSAgZGF0YVNldEpzb24ubWFwLmJhc2VHZW9EYXRhVXJsO1xuICBjb25zdCBfc2NhbGUgPSBkYXRhU2V0SnNvbi5tYXAuc2NhbGU7XG4gIGNvbnN0IF9rZXlEYXRhTmFtZSA9IGRhdGFTZXRKc29uLm1hcC5rZXlEYXRhTmFtZTtcbiAgY29uc3QgX2tleU5hbWUgPSAnZGF0YS4nICsgX2tleURhdGFOYW1lO1xuICBjb25zdCBfdGFyZ2V0UHJvcGVydHkgPSAnZC4nICsgZGF0YVNldEpzb24ubWFwLnRhcmdldFByb3BlcnR5TmFtZTtcbiAgY29uc3QgX2FudGFyY3RpY2FDb2xvciA9IGRhdGFTZXRKc29uLm1hcC5hbnRhcmN0aWNhQ29sb3I7XG4gIGNvbnN0IF9sZWdlbmREaXNwbGF5ID0gY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheTtcblxuICBjb25zdCBwYXRoID0gZDMuZ2VvUGF0aCgpXG4gICAgICAgICAgICAgIC5wcm9qZWN0aW9uKFxuICAgICAgICAgICAgICAgICAgZDMuZ2VvTWVyY2F0b3IoKVxuICAgICAgICAgICAgICAgICAgLnRyYW5zbGF0ZShfZ3JhcGhDZW50ZXJQb3MpXG4gICAgICAgICAgICAgICAgICAuc2NhbGUoX3NjYWxlKVxuICAgICAgICAgICAgICApO1xuXG4gIGNvbnN0IF9maW5kQ29sb3JCeU5hbWUgPSAobmFtZTogc3RyaW5nKTogc3RyaW5nID0+IHtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgaWYgKG5hbWUgPT09IGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZSkge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX2NvbG9yID0gZGF0YVNldEpzb24uZGF0YVtpXS5jb2xvcjtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBfY29sb3I7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gbnVsbDtcbiAgfTtcblxuICBkMy5qc29uKF9nZW9NYXBEYXRhVXJsLCAoZXJyb3IsIGRhdGEpID0+IHtcbiAgICAgIHN2Z0NvbnRhaW5lci5zZWxlY3RBbGwoJ3BhdGgnKVxuICAgICAgICAgICAgICAuZGF0YShldmFsKF9rZXlOYW1lKSlcbiAgICAgICAgICAgICAgLmVudGVyKClcbiAgICAgICAgICAgICAgLmFwcGVuZCgncGF0aCcpXG4gICAgICAgICAgICAgIC5hdHRyKCdkJywgcGF0aClcbiAgICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX3RhcmdldEFyZWEgPSBldmFsKF90YXJnZXRQcm9wZXJ0eSk7XG4gICAgICAgICAgICAgICAgICBpZiAoX2ZpbmRDb2xvckJ5TmFtZShfdGFyZ2V0QXJlYSkgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX2ZpbmRDb2xvckJ5TmFtZShfdGFyZ2V0QXJlYSk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICByZXR1cm4gJ2hzbCgnICsgaSArICcsODAlLDYwJSknO1xuICAgICAgICAgICAgICB9KTtcbiAgICAgIH0pO1xuXG4gIC8vICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gIC0tLUNBTEwgYnVpbGRMZWdlbmQtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX2xlZ2VuZERpc3BsYXkpIHtcbiAgICAgIGNvbnN0IF9sZWdlbmREYXRhU2V0OiBBcnJheTxPMkxlZ2VuZERhdGE+ID0gbmV3IEFycmF5KCk7XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgIGNvbnN0IF9uYW1lID0gZGF0YVNldEpzb24uZGF0YVtpXS5uYW1lO1xuICAgICAgICAgICAgICBjb25zdCBfY29sb3IgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLmNvbG9yO1xuICAgICAgICAgICAgICBpZiAoX25hbWUgPT09ICdBbnRhcmN0aWNhJykge1xuICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgX2xlZ2VuZERhdGFTZXQucHVzaChuZXcgTzJMZWdlbmREYXRhKGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZSwgZGF0YVNldEpzb24uZGF0YVtpXS5jb2xvcikpO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG4gIH1cblxufVxuXG5cblxucHJpdmF0ZSBidWlsZFN0YWNrQmFyKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkU3RhY2tCYXItLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgaW50ZXJmYWNlIEhhc2hTdHJpbmcge1xuICAgIFtpbmRleDogc3RyaW5nXTogc3RyaW5nO1xuICB9XG4gIGludGVyZmFjZSBIYXNoTnVtYmVyIHtcbiAgICBba2V5OiBzdHJpbmddOiBudW1iZXI7XG4gIH1cblxuICBjb25zdCBfdG90YWxZOiBBcnJheTxudW1iZXI+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgX3RvdGFsWS5wdXNoKDApO1xuICAgICAgfVxuICB9XG5cbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgbGV0IGsgPSAwO1xuICAgICAgICAgIGZvciAoY29uc3QgaiBpbiBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlKSB7XG4gICAgICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlLmhhc093blByb3BlcnR5KGopKSB7XG4gICAgICAgICAgICAgICAgICBfdG90YWxZW2srK10gKz0gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS55O1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgfVxuICB9XG4gIGxldCBfbWF4WCA9IDA7XG4gIGxldCBfbWF4WSA9IDA7XG4gIF9tYXhZID0gZDMubWF4KF90b3RhbFkpO1xuICBfbWF4WCA9IDEwMDtcbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcblxuICBjb25zdCBfY29sb3IgPSBjZHQuZGVmYXVsdENvbG9yRnVuYztcbiAgY29uc3QgX2NvbHVtbk51bSA9ICBkYXRhU2V0SnNvbi5kYXRhLmxlbmd0aDtcbiAgY29uc3QgX2JhcldpZHRoID0gKGNkdC5ncmFwaFdpZHRoIC8gX2NvbHVtbk51bSkgLSBjb25maWdEYXRhLm1hcmdpbi5iZXR3ZWVuO1xuICBjb25zdCBfY29sdW1uV2lkdGggPSAoY2R0LmdyYXBoV2lkdGggLyBfY29sdW1uTnVtKSA7XG4gIGNvbnN0IF9pbml0UG9zWCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfaW5pdFBvc1kgPSBjZHQuZ3JhcGhJbml0WVBvcztcbiAgY29uc3QgX2dyYXBoSGVpZ2h0ID0gY2R0LmdyYXBoSGVpZ2h0O1xuICBjb25zdCBfbWF4WVZhbHVlID0gY2R0Lm1heFlWYWx1ZTtcblxuICBjb25zdCBfb3BhY2l0eSA9IGNvbmZpZ0RhdGEuY29sb3Iub3BhY2l0eTtcbiAgY29uc3QgX2xlZ2VuZERpc3BsYXkgPSBjb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5O1xuICBjb25zdCBfZ3JpZFlEaXNwbGF5ID0gY29uZmlnRGF0YS5ncmlkLnkuZGlzcGxheTtcbiAgY29uc3QgX2dyaWRYRGlzcGxheSA9IGNvbmZpZ0RhdGEuZ3JpZC54LmRpc3BsYXk7XG4gIGNvbnN0IF9sYWJlbERpc3BsYXkgPSBjb25maWdEYXRhLmxhYmVsLmRpc3BsYXk7XG4gIGNvbnN0IF9hbmltYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5lbmFibGU7XG4gIGNvbnN0IF9hbmltYXRpb25EdXJhdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmR1cmF0aW9uO1xuXG4gIC8vICBHZXQgRGF0YSBOYW1lXG4gIGNvbnN0IF9zZXJpZXNEYXRlTmFtZSA9IGRhdGFTZXRKc29uLnNlcmllc1swXTtcblxuICAvLyAgR2V0IEtleXNcbiAgY29uc3QgX2tleUFycmF5OiBBcnJheTxzdHJpbmc+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGNvbnN0IF9rZXkgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWU7XG4gICAgICAgICAgY29uc3QgX3ZhbHVlID0gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVswXS55O1xuICAgICAgICAgIF9rZXlBcnJheS5wdXNoKF9rZXkpO1xuICAgICAgfVxuICB9XG5cbiAgLy8gIEdldCBEYXRlIFN0cmluZ1xuICBjb25zdCBfZGF0ZUFycmF5OiBBcnJheTxzdHJpbmc+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGNvbnN0IF94VmFsdWUgPSBkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlW2ldLng7XG4gICAgICAgICAgX2RhdGVBcnJheS5wdXNoKF94VmFsdWUpO1xuICAgICAgfVxuICB9XG5cbiAgY29uc3QgX2hhc2hBcnJheTogQXJyYXk8YW55PiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gX2RhdGVBcnJheSkge1xuICAgICAgaWYgKF9kYXRlQXJyYXkuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBjb25zdCBfZGF0ZVN0ID0gX2RhdGVBcnJheVtpXTtcbiAgICAgICAgICBjb25zdCBfaGFzaE51bWJlcjogSGFzaE51bWJlciA9IHsgfTtcbiAgICAgICAgICBmb3IgKGNvbnN0IGogaW4gX2tleUFycmF5KSB7XG4gICAgICAgICAgICAgIGlmIChfa2V5QXJyYXkuaGFzT3duUHJvcGVydHkoaikpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IF9rZXkgPSBfa2V5QXJyYXlbal07XG4gICAgICAgICAgICAgICAgICBjb25zdCBfdmFsdWUgPSBkYXRhU2V0SnNvbi5kYXRhW2pdLnZhbHVlW2ldLnk7XG4gICAgICAgICAgICAgICAgICBfaGFzaE51bWJlcltfa2V5XSAgPSBfdmFsdWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgX2hhc2hBcnJheS5wdXNoKF9oYXNoTnVtYmVyKTtcbiAgICAgIH1cbiAgfVxuXG4gIGNvbnN0IHlTY2FsZSA9IGQzLnNjYWxlTGluZWFyKClcbiAgICAgICAgICAgICAgICAgIC5kb21haW4oWzAsIF9tYXhZVmFsdWVdKVxuICAgICAgICAgICAgICAgICAgLnJhbmdlKFswLCBfZ3JhcGhIZWlnaHRdKTtcblxuXG4gIGNvbnN0IHN0YWNrID0gZDMuc3RhY2soKTtcbiAgY29uc3QgX3JlY3QgPSBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdnJylcbiAgICAgIC5kYXRhKHN0YWNrLmtleXMoX2tleUFycmF5KShfaGFzaEFycmF5KSlcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCdmaWxsJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIF9jb2xvcihpKTtcbiAgICAgIH0gKVxuICAgICAgLmF0dHIoJ2ZpbGwtb3BhY2l0eScsIF9vcGFjaXR5KVxuICAgICAgLnNlbGVjdEFsbCgncmVjdCcpXG4gICAgICAuZGF0YSgoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICByZXR1cm4gZDtcbiAgICAgIH0pXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgncmVjdCcpO1xuXG5cblxuICBpZiAoX2FuaW1hdGlvbikge1xuICAgICAgX3JlY3QuYXR0cigneCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgIHJldHVybiBfaW5pdFBvc1jDo8KAwoAgKyDDo8KAwoBpICogX2NvbHVtbldpZHRoO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCAgMClcbiAgICAgIC5hdHRyKCd5JywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgY29uc3Qgbm0gPSAnZC5kYXRhLicgKyBfa2V5QXJyYXlbaV07XG4gICAgICAgICAgY29uc3QgX3lWYWx1ZSA9IGV2YWwobm0pO1xuICAgICAgICAgIHJldHVybiBzdmdIZWlnaHQgLSBjb25maWdEYXRhLm1hcmdpbi5ib3R0b20gLSB5U2NhbGUoZFsxXSk7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ3dpZHRoJywgX2JhcldpZHRoKVxuICAgICAgLnRyYW5zaXRpb24oKVxuICAgICAgLmR1cmF0aW9uKF9hbmltYXRpb25EdXJhdGlvbilcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCAoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICByZXR1cm4geVNjYWxlKGRbMV0gLSBkWzBdKTtcbiAgICAgIH0pO1xuICB9IGVsc2Uge1xuICAgICAgX3JlY3QuYXR0cigneCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgIHJldHVybiBfaW5pdFBvc1ggKyAoaSAqIF9jb2x1bW5XaWR0aCk7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ3knLCAoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICBjb25zdCBubSA9ICdkLmRhdGEuJyArIF9rZXlBcnJheVtpXTtcbiAgICAgICAgICBjb25zdCBfeVZhbHVlID0gZXZhbChubSk7XG4gICAgICAgICAgcmV0dXJuIHN2Z0hlaWdodCAtIGNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbSAtIHlTY2FsZShkWzFdKTtcbiAgICAgIH0pXG4gICAgICAuYXR0cignd2lkdGgnLCBfYmFyV2lkdGgpXG4gICAgICAuYXR0cignaGVpZ2h0JywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIHlTY2FsZShkWzFdIC0gZFswXSk7XG4gICAgICB9KTtcbiAgfVxuXG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIHRoaXMuZHJhd1RpdGxlKGNkdCk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRBeGlzLS0tLS0tLS0tLS0tLS0tLS1cbiAgdGhpcy5idWlsZFlBeGlzKGNkdCk7XG5cbiAgdGhpcy5kcmF3WEJhc2VMaW5lKGNkdCk7XG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBkcmF3WEF4aXNMYWJlbC0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfbGFiZWxEaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGFiZWxBcnJheTogIEFycmF5PHN0cmluZz4gPSBuZXcgQXJyYXkoKTtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWUuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgX2xhYmVsQXJyYXkucHVzaChkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlW2ldLngpO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuZHJhd1hBeGlzTGFiZWwoY2R0LCBfbGFiZWxBcnJheSwgQ2hhcnRDb25zdC5TVEFDS19CQVJfQ0hBUlRfVFlQRV9OQU1FKTtcbiAgfVxuXG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBidWlsZExlZ2VuZC0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfbGVnZW5kRGlzcGxheSkge1xuICAgICAgY29uc3QgX2xlZ2VuZERhdGFTZXQ6IEFycmF5PE8yTGVnZW5kRGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgX2xlZ2VuZERhdGFTZXQucHVzaChuZXcgTzJMZWdlbmREYXRhKGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZSwgX2NvbG9yKGkpKSk7XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5idWlsZExlZ2VuZChjZHQsIF9sZWdlbmREYXRhU2V0KTtcbiAgfVxuXG4gIGlmIChfZ3JpZFlEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdZR3JpZChjZHQpO1xuICB9XG5cbn1cblxucHJpdmF0ZSBidWlsZFNjYXR0ZXJQbG90KHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ0luICBidWlsZFNjYXR0ZXJQbG90LS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IF9kYXRhU2V0OiBBcnJheTxPMlNjYXR0ZXJQbG90RGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgbGV0IF9tYXhYID0gMDtcbiAgbGV0IF9tYXhZID0gMDtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgZm9yIChjb25zdCBqIGluIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUpIHtcbiAgICAgICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUuaGFzT3duUHJvcGVydHkoaikpIHtcbiAgICAgICAgICAgICAgICAgIGlmIChfbWF4WCA8IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueCkge1xuICAgICAgICAgICAgICAgICAgICAgIF9tYXhYID0gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS54O1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgaWYgKF9tYXhZIDwgZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS55KSB7XG4gICAgICAgICAgICAgICAgICAgICAgX21heFkgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLnk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBjb25zdCBfc2NhdHRlclBsb3REYXRhID0gbmV3IE8yU2NhdHRlclBsb3REYXRhKFxuICAgICAgICAgICAgICAgICAgICAgIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueCxcbiAgICAgICAgICAgICAgICAgICAgICBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLnksXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS5yLFxuICAgICAgICAgICAgICAgICAgKSA7XG4gICAgICAgICAgICAgICAgICBfZGF0YVNldC5wdXNoKF9zY2F0dGVyUGxvdERhdGEpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgfVxuICB9XG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG5cbiAgY29uc3QgX2luaXRQb3NYID0gY2R0LmdyYXBoSW5pdFhQb3M7XG4gIGNvbnN0IF9pbml0UG9zWSA9IGNkdC5ncmFwaEluaXRZUG9zO1xuXG4gIGNvbnN0IF9zZXJpZXNOdW1iZXIgPSBkYXRhU2V0SnNvbi5zZXJpZXMubGVuZ3RoO1xuICBjb25zdCBfY29sb3IgPSBjZHQuZGVmYXVsdENvbG9yRnVuYztcbiAgY29uc3QgX29wYWNpdHkgPSBjb25maWdEYXRhLmNvbG9yLm9wYWNpdHk7XG4gIGNvbnN0IF9ncmlkWURpc3BsYXkgPSBjb25maWdEYXRhLmdyaWQueS5kaXNwbGF5O1xuICBjb25zdCBfZ3JpZFhEaXNwbGF5ID0gY29uZmlnRGF0YS5ncmlkLnguZGlzcGxheTtcbiAgY29uc3QgX3RpdGxlRGlzcGxheSA9IGNvbmZpZ0RhdGEudGl0bGUuZGlzcGxheTtcbiAgY29uc3QgX2xlZ2VuZERpc3BsYXkgPSBjb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5O1xuXG4gIGNvbnN0IF9jaXJjbGUgPSBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdjaXJjbGUnKVxuICAgICAgICAgIC5kYXRhKF9kYXRhU2V0KVxuICAgICAgICAgIC5lbnRlcigpXG4gICAgICAgICAgLmFwcGVuZCgnY2lyY2xlJylcbiAgICAgICAgICAuYXR0cignY3gnLCAoZDogTzJTY2F0dGVyUGxvdERhdGEsIGk6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiBfaW5pdFBvc1ggKyBkLng7XG4gICAgICAgICAgfSlcbiAgICAgICAgICAuYXR0cignY3knLCAoZDogTzJTY2F0dGVyUGxvdERhdGEsIGk6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiAoc3ZnSGVpZ2h0IC0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tIC0gZC55KTtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5hdHRyKCdyJywgKGQ6IE8yU2NhdHRlclBsb3REYXRhLCBpOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gZC5yO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICBjb25zdCBfY29sb3JOdW0gPSBpICUgX3Nlcmllc051bWJlcjtcbiAgICAgICAgICAgICAgcmV0dXJuIF9jb2xvcihfY29sb3JOdW0pO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmF0dHIoJ2ZpbGwtb3BhY2l0eScsICBfb3BhY2l0eSk7XG5cblxuICAvLyAtLS1DQUxMIGJ1aWxkVGl0bGUtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX3RpdGxlRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3VGl0bGUoY2R0KTtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF9sZWdlbmREaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkYXRhU2V0SnNvbi5zZXJpZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICBfbGVnZW5kRGF0YVNldC5wdXNoKG5ldyBPMkxlZ2VuZERhdGEoZGF0YVNldEpzb24uc2VyaWVzW2ldLCBfY29sb3IoaSkpKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG4gIH1cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRBeGlzLS0tLS0tLS0tLS0tLS0tLS1cbiAgdGhpcy5idWlsZFlBeGlzKGNkdCk7XG5cbiAgdGhpcy5idWlsZFhBeGlzKGNkdCk7XG5cbiAgaWYgKF9ncmlkWURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1lHcmlkKGNkdCk7XG4gIH1cbiAgaWYgKF9ncmlkWERpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1hHcmlkKGNkdCk7XG4gIH1cbn1cblxuXG5cbnByaXZhdGUgZHJhd1hHcmlkKG8yQ29tbW9uOiBhbnkpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRYR3JpZC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3QgY29uZmlnRGF0YSA9IGNkdC5jb25maWdEYXRhO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIGNvbnN0IF9zdGVwWCA9ICBjZHQuZ3JpZFhTdGVwO1xuXG4gIGNvbnN0IF9tYXhYID0gY2R0Lm1heFhWYWx1ZTtcbiAgY29uc3QgX2dyYXBoWVNjYWxlID0gY2R0LmdyYXBoWVNjYWxlO1xuICBjb25zdCBfZ3JhcGhYU2NhbGUgPSBjZHQuZ3JhcGhYU2NhbGU7XG4gIGNvbnN0IF9ncmFwaFdpZHRoID0gY2R0LmdyYXBoV2lkdGg7XG4gIGNvbnN0IF9ncmlkQ2xhc3NOYW1lID0gY29uZmlnRGF0YS5jbGFzc05hbWUuZ3JpZDtcbiAgY29uc3QgX2F4aXNYU2NhbGUgPSBkMy5zY2FsZUxpbmVhcigpXG4gICAgICAgICAgICAgICAgICAuZG9tYWluKFswLCBfbWF4WF0pXG4gICAgICAgICAgICAgICAgICAucmFuZ2UoWzAsIF9tYXhYICogX2dyYXBoWFNjYWxlXSk7XG4gIGNvbnN0IF9yYW5nZVggPSBkMy5yYW5nZShfc3RlcFggKiBfZ3JhcGhYU2NhbGUsXG4gICAgICAgICAgICAgICAgICBfbWF4WCAgKiBfZ3JhcGhYU2NhbGUsXG4gICAgICAgICAgICAgICAgICBfc3RlcFggKiBfZ3JhcGhYU2NhbGUpO1xuXG4gIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgLnNlbGVjdEFsbCgnbGluZS54JylcbiAgICAgIC5kYXRhKF9yYW5nZVgpXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgnbGluZScpXG4gICAgICAuYXR0cignY2xhc3MnLCBfZ3JpZENsYXNzTmFtZSlcbiAgICAgIC5hdHRyKCd4MScsIChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICBjb25zdCBfeDEgPSBjb25maWdEYXRhLm1hcmdpbi5sZWZ0ICArIGQ7XG4gICAgICAgICAgcmV0dXJuIF94MTtcbiAgICAgIH0pXG4gICAgICAuYXR0cigneTEnLCBjZHQuc3ZnSGVpZ2h0IC0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tKVxuICAgICAgLmF0dHIoJ3gyJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgIGNvbnN0IF94MiA9IGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQgICsgZDtcbiAgICAgICAgICByZXR1cm4gX3gyO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCd5MicsIGNvbmZpZ0RhdGEubWFyZ2luLnRvcCArIGNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0KTtcbn1cblxucHJpdmF0ZSBidWlsZFhBeGlzKG8yQ29tbW9uOiBhbnkpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRYQXhpcy0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3QgY29uZmlnRGF0YSA9IGNkdC5jb25maWdEYXRhO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIGNvbnN0IF9tYXhYID0gY2R0Lm1heFhWYWx1ZTtcbiAgY29uc3QgX2dyYXBoWFNjYWxlID0gY2R0LmdyYXBoWFNjYWxlO1xuXG4gIGNvbnN0IF9heGlzWFNjYWxlID0gZDMuc2NhbGVMaW5lYXIoKVxuICAgICAgICAgICAgICAgICAgLmRvbWFpbihbMCwgX21heFhdKVxuICAgICAgICAgICAgICAgICAgLnJhbmdlKFswLCBfbWF4WCAqIF9ncmFwaFhTY2FsZV0pO1xuXG4gIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgY2R0LmF4aXNDbGFzc05hbWUpXG4gICAgICAuYXR0cigndHJhbnNmb3JtJywgY2R0LmF4aXNYQm9yZGVyVHJhbnNsYXRlUG9zKVxuICAgICAgLmNhbGwoXG4gICAgICAgICAgICBkMy5heGlzQm90dG9tKF9heGlzWFNjYWxlKVxuICAgICAgKTtcbiAgICAgICAgICAgIC8vICAuc2NhbGUoKVxuICAgICAgICAgICAgLy8gIC5vcmllbnQoY2R0LmF4aXNYT3JpZW50KVxuICAgICAgICAgICAgLy8gICk7XG59XG5cblxuXG5wcml2YXRlIGJ1aWxkUGllKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ0luICBidWlsZFBpZS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfbWF4WCA9IDEwMDtcbiAgY29uc3QgX21heFkgPSAxMDA7XG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG5cbiAgY29uc3QgX2NvbG9yID0gY2R0LmRlZmF1bHRDb2xvckZ1bmM7XG4gIGNvbnN0IF9pbml0UG9zWCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfaW5pdFBvc1kgPSBjZHQuZ3JhcGhJbml0WVBvcztcbiAgY29uc3QgX2dyYXBoSGVpZ2h0ID0gY2R0LmdyYXBoSGVpZ2h0O1xuICBjb25zdCBfZ3JhcGhXaWR0aCA9IGNkdC5ncmFwaFdpZHRoO1xuXG4gIGNvbnN0IF9vcGFjaXR5ID0gY29uZmlnRGF0YS5jb2xvci5vcGFjaXR5O1xuICBjb25zdCBfdGl0bGVIZWlnaHQgPSBjb25maWdEYXRhLnRpdGxlLmhlaWdodDtcbiAgY29uc3QgX2xlZnRNYXJnaW4gPSBjb25maWdEYXRhLm1hcmdpbi5sZWZ0O1xuICBjb25zdCBfdG9wTWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4udG9wO1xuICBjb25zdCBfYm90dG9tTWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tO1xuICBjb25zdCBfYmV0d2Vlbk1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLmJldHdlZW47XG4gIGNvbnN0IF9pbm5lclJhZGl1c1BlcmNlbnQgPSBjZHQuaW5uZXJSYWRpdXNQZXJjZW50O1xuICBjb25zdCBfZ3JhcGhDZW50ZXJUcmFuc2xhdGVQb3MgPSBjZHQuZ3JhcGhDZW50ZXJUcmFuc2xhdGVQb3M7XG4gIGNvbnN0IF9waWVDbGFzc05hbWUgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5waWU7XG4gIGNvbnN0IF9waWVWYWx1ZUNsYXNzTmFtZSA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLnBpZU51bTtcbiAgY29uc3QgX3BpZUlubmVyVGl0bGVDbGFzc05hbWUgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5waWVJbm5lclRpdGxlO1xuICBjb25zdCBfaW5uZXJSYWRpdXNUaXRsZVRyYW5zbGF0ZVBvcyA9IGNkdC5pbm5lclJhZGl1c1RpdGxlVHJhbnNsYXRlUG9zO1xuICBjb25zdCBfaW5uZXJSYWRpdXNUaXRsZSA9IGNkdC5pbm5lclJhZGl1c1RpdGxlO1xuICBjb25zdCBfdGl0bGVEaXNwbGF5ID0gY29uZmlnRGF0YS50aXRsZS5kaXNwbGF5O1xuICBjb25zdCBfbGVnZW5kRGlzcGxheSA9IGNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXk7XG4gIGNvbnN0IF9sYWJlbERpc3BsYXkgPSBjb25maWdEYXRhLmxhYmVsLmRpc3BsYXk7XG4gIGNvbnN0IF92YWx1ZURpc3BsYXkgPSBjb25maWdEYXRhLnBpZS52YWx1ZS5kaXNwbGF5O1xuICBjb25zdCBfcGVyY2VudERpc3BsYXkgPSBjb25maWdEYXRhLnBpZS5wZXJjZW50LmRpc3BsYXk7XG4gIGNvbnN0IF9hbmltYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5lbmFibGU7XG4gIGNvbnN0IF9hbmltYXRpb25EdXJhdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmR1cmF0aW9uO1xuXG4gIGNvbnN0IHdpZHRoID0gc3ZnV2lkdGg7XG4gIGNvbnN0IGhlaWdodCA9IHN2Z0hlaWdodDtcblxuICBjb25zdCBkYXRhU2V0OiBBcnJheTxudW1iZXI+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSAgaW4gIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgY29uc3QgX251bSA9IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWU7XG4gICAgICAgICAgZGF0YVNldC5wdXNoKF9udW0pO1xuICAgICAgfVxuICB9XG5cbiAgY29uc3QgX3N1bSA9IGQzLnN1bShkYXRhU2V0KTtcbiAgY29uc3QgcGllID0gZDMucGllKCk7XG4gIGNvbnN0IGFyYyA9IGQzLmFyYygpXG4gICAgICAgICAgICAgIC5pbm5lclJhZGl1cyhfZ3JhcGhIZWlnaHQgKiBfaW5uZXJSYWRpdXNQZXJjZW50IC8gMTAwKVxuICAgICAgICAgICAgICAub3V0ZXJSYWRpdXMoX2dyYXBoSGVpZ2h0IC8gMik7XG5cbiAgY29uc3QgcGllRWxlbWVudHMgPSBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdwYXRoJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmRhdGEocGllKGRhdGFTZXQpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAuZW50ZXIoKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAuYXBwZW5kKCdnJylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIF9ncmFwaENlbnRlclRyYW5zbGF0ZVBvcyk7XG5cblxuICBjb25zdCBfbWFrZUNlbnRlclRpdGxlID0gKCk6IHN0cmluZyA9PiB7XG4gICAgICAgICAgaWYgKF92YWx1ZURpc3BsYXkgJiYgX3BlcmNlbnREaXNwbGF5KSB7XG4gICAgICAgICAgICAgIGNvbnN0IF9zdCA9IF9pbm5lclJhZGl1c1RpdGxlICsgJzonICsgX3N1bSArICAnICgxMDAlKSc7XG4gICAgICAgICAgICAgIHJldHVybiBfc3Q7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChfcGVyY2VudERpc3BsYXkpIHtcbiAgICAgICAgICAgICAgcmV0dXJuICcxMDAlJztcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKF92YWx1ZURpc3BsYXkpIHtcbiAgICAgICAgICAgICAgcmV0dXJuIF9pbm5lclJhZGl1c1RpdGxlICsgJzonICsgX3N1bTtcbiAgICAgICAgICB9XG4gIH07XG5cbiAgY29uc3QgdGV4dEVsZW1lbnRzID0gc3ZnQ29udGFpbmVyLmFwcGVuZCgndGV4dCcpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIF9waWVJbm5lclRpdGxlQ2xhc3NOYW1lKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgX2lubmVyUmFkaXVzVGl0bGVUcmFuc2xhdGVQb3MgKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAudGV4dChfbWFrZUNlbnRlclRpdGxlKTtcblxuICBjb25zdCBfYXJjID0gcGllRWxlbWVudHMuYXBwZW5kKCdwYXRoJylcbiAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgX3BpZUNsYXNzTmFtZSlcbiAgICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIF9jb2xvcihpKTtcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLmF0dHIoJ2ZpbGwtb3BhY2l0eScsIF9vcGFjaXR5KTtcblxuICAvLyAgRm9yIGQzVmVyc2lvbjQgYW5pbWF0aW9uIGlzIG5vdCBhdmFpbGFibGUgbm93XG4gIC8vICBpZiAoX2FuaW1hdGlvbikge1xuICAvLyAgICAgIF9hcmMudHJhbnNpdGlvbigpXG4gIC8vICAgICAgLmR1cmF0aW9uKF9hbmltYXRpb25EdXJhdGlvbilcbiAgLy8gICAgICAuZGVsYXkoKGQsaSk9PiB7XG4gIC8vICAgICAgICAgIHJldHVybiBpICoxMDAwO1xuICAvLyAgICAgIH0pXG4gIC8vICAgICAgLmF0dHJUd2VlbignZCcsKGQ6IGFueSxpOiBudW1iZXIpID0+ICB7XG4gIC8vICAgICAgICAgIGNvbnN0IF9pbnRlcnBvbGF0ZSA9IGQzLmludGVycG9sYXRlT2JqZWN0KFxuICAvLyAgICAgICAgICAgICAgeyBzdGFydEFuZ2xlOmQuc3RhcnRBbmdsZSxlbmRBbmdsZTpkLnN0YXJ0QW5nbGUgfVxuICAvLyAgICAgICAgICAgICAgeyBzdGFydEFuZ2xlOmQuc3RhcnRBbmdsZSxlbmRBbmdsZTpkLmVuZEFuZ2xlIH1cbiAgLy8gICAgICAgICAgKVxuICAvLyAgICAgICAgICByZXR1cm4gKHQpIHtcbiAgLy8gICAgICAgICAgICAgIHJldHVybiBhcmMoX2ludGVycG9sYXRlKHQpKTtcbiAgLy8gICAgICAgICAgfVxuICAvLyAgICAgIH0pXG4gIC8vICB9XG4gIC8vICBlbHNle1xuICAvLyAgICAgIF9hcmMuYXR0cignZCcsYXJjKTtcbiAgLy8gIH1cbiAgX2FyYy5hdHRyKCdkJywgYXJjKTtcblxuICBwaWVFbGVtZW50cy5hcHBlbmQoJ3RleHQnKVxuICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCBfcGllVmFsdWVDbGFzc05hbWUpXG4gICAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIGFyYy5jZW50cm9pZChkKSArICcpJztcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLnRleHQoKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgICAgICAgICBpZiAoX3ZhbHVlRGlzcGxheSAmJiBfcGVyY2VudERpc3BsYXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBfcGVyY2VudFN0ID0gU3RyaW5nKE1hdGguY2VpbChkLnZhbHVlIC8gX3N1bSAgKiAxMDApKTtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBfc3QgPSBTdHJpbmcoZC52YWx1ZSkgKyAnICgnICsgX3BlcmNlbnRTdCArICclKSc7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9zdDtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGlmIChfcGVyY2VudERpc3BsYXkpIHtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBfcGVyY2VudFN0ID0gU3RyaW5nKE1hdGguY2VpbChkLnZhbHVlIC8gX3N1bSAgKiAxMDApKTtcbiAgICAgICAgICAgICAgICAgICAgICBjb25zdCBfc3QgPSBfcGVyY2VudFN0ICsgJyUnO1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfc3Q7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBpZiAoX3ZhbHVlRGlzcGxheSkge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBkLnZhbHVlO1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICB9KTtcblxuICAvLyAtLS1DQUxMIGJ1aWxkVGl0bGUtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX3RpdGxlRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3VGl0bGUoY2R0KTtcbiAgfVxuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF9sZWdlbmREaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICAgICAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICBfbGVnZW5kRGF0YVNldC5wdXNoKG5ldyBPMkxlZ2VuZERhdGEoZGF0YVNldEpzb24uZGF0YVtpXS5uYW1lLCBfY29sb3IoaSkpKTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLmJ1aWxkTGVnZW5kKGNkdCwgX2xlZ2VuZERhdGFTZXQpO1xuICB9XG59XG5cblxuXG5wcml2YXRlIGJ1aWxkQmFyKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ0luICBidWlsZEJhci0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfeURhdGFTZXQ6IEFycmF5PG51bWJlcj4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgZm9yIChjb25zdCBqIGluIGRhdGFTZXRKc29uLmRhdGFbaV0ueSkge1xuICAgICAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YVtpXS55Lmhhc093blByb3BlcnR5KGopKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBfeSA9IGRhdGFTZXRKc29uLmRhdGFbaV0ueVtqXTtcbiAgICAgICAgICAgICAgICAgIF95RGF0YVNldC5wdXNoKF95KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgIH1cbiAgfVxuXG4gIGxldCBfbWF4WCA9IDA7XG4gIGxldCBfbWF4WSA9IDA7XG4gIF9tYXhZID0gZDMubWF4KF95RGF0YVNldCk7XG4gIF9tYXhYID0gMTAwO1xuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuXG4gIGNvbnN0IF9iYXJWYWx1ZUNsYXNzID0gY29uZmlnRGF0YS5jbGFzc05hbWUuYmFyVmFsdWU7XG4gIGNvbnN0IF9jb2xvciA9IGNkdC5kZWZhdWx0Q29sb3JGdW5jO1xuICBjb25zdCBfc2VyaWVzTnVtID0gIGRhdGFTZXRKc29uLnNlcmllcy5sZW5ndGg7XG4gIGNvbnN0IF9jb2x1bW5OdW0gPSAgX3lEYXRhU2V0Lmxlbmd0aDtcbiAgY29uc3QgX2luaXRQb3NYID0gY2R0LmdyYXBoSW5pdFhQb3M7XG4gIGNvbnN0IF9pbml0UG9zWSA9IGNkdC5ncmFwaEluaXRZUG9zO1xuICBjb25zdCBfZ3JhcGhIZWlnaHQgPSBjZHQuZ3JhcGhIZWlnaHQ7XG4gIGNvbnN0IF9ncmFwaFdpZHRoID0gY2R0LmdyYXBoV2lkdGg7XG4gIGNvbnN0IF9tYXhZVmFsdWUgPSBjZHQubWF4WVZhbHVlO1xuICBjb25zdCBfb3BhY2l0eSA9IGNvbmZpZ0RhdGEuY29sb3Iub3BhY2l0eTtcbiAgY29uc3QgX3RpdGxlSGVpZ2h0ID0gY29uZmlnRGF0YS50aXRsZS5oZWlnaHQ7XG4gIGNvbnN0IF90aXRsZURpc3BsYXkgPSBjb25maWdEYXRhLnRpdGxlLmRpc3BsYXk7XG4gIGNvbnN0IF9sZWZ0TWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4ubGVmdDtcbiAgY29uc3QgX3RvcE1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLnRvcDtcbiAgY29uc3QgX2JvdHRvbU1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbTtcbiAgY29uc3QgX2JldHdlZW5NYXJnaW4gPSBjb25maWdEYXRhLm1hcmdpbi5iZXR3ZWVuO1xuICBjb25zdCBfbGVnZW5kRGlzcGxheSA9IGNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXk7XG4gIGNvbnN0IF9sYWJlbERpc3BsYXkgPSBjb25maWdEYXRhLmxhYmVsLmRpc3BsYXk7XG4gIGNvbnN0IF9ncmlkWURpc3BsYXkgPSBjb25maWdEYXRhLmdyaWQueS5kaXNwbGF5O1xuICBjb25zdCBfYW5pbWF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZW5hYmxlO1xuICBjb25zdCBfYW5pbWF0aW9uRHVyYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5kdXJhdGlvbjtcblxuICBjb25zdCBfYmFyV2lkdGggPSAoX2dyYXBoV2lkdGggLSAoX2JldHdlZW5NYXJnaW4gKiBfY29sdW1uTnVtIC8gX3Nlcmllc051bSkpIC8gIF9jb2x1bW5OdW07XG4gIGNvbnN0IF9jb2x1bW5XaWR0aCA9IChfZ3JhcGhXaWR0aCAvIF9jb2x1bW5OdW0pIDtcblxuICBjb25zdCBfZ3JhcGhZU2NhbGUgPSBjZHQuZ3JhcGhZU2NhbGU7XG5cbiAgY29uc3QgeUJhclNjYWxlID0gZDMuc2NhbGVMaW5lYXIoKVxuICAgICAgICAgICAgICAgICAgLmRvbWFpbihbMCwgX21heFldKVxuICAgICAgICAgICAgICAgICAgLnJhbmdlKFtfbWF4WSAqIF9ncmFwaFlTY2FsZSwgMF0pO1xuXG4gIGNvbnN0IF9iYXJQYWRkaW5nID0gX2JldHdlZW5NYXJnaW47XG5cblxuXG5cbiAgY29uc3QgZ3JwR3JhcGggPSBzdmdDb250YWluZXIuc2VsZWN0QWxsKCdnJylcbiAgICAgIC5kYXRhKF95RGF0YVNldClcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZDogYW55LCBpOiBudW1iZXIpOiBzdHJpbmcgPT4ge1xuICAgICAgICAgIGNvbnN0IF9wYWRkaW5nID0gKChpICUgX3Nlcmllc051bSkgPT09IDApID8gX2JhclBhZGRpbmcgOiAwO1xuICAgICAgICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyAoX3BhZGRpbmcgKyBfY29sdW1uV2lkdGggKiBpKSArICcpJztcbiAgICAgIH0pXG4gICAgICAuc3R5bGUoJ2ZpbGwnLCAoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgY29uc3QgX3JlbW5hbnQgPSAoaSAlIF9zZXJpZXNOdW0pO1xuICAgICAgICAgIHJldHVybiBfY29sb3IoX3JlbW5hbnQpO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCdmaWxsLW9wYWNpdHknLCBfb3BhY2l0eSk7XG5cbiAgY29uc3QgX3JlY3QgPSAgZ3JwR3JhcGguYXBwZW5kKCdyZWN0Jyk7XG4gIGlmIChfYW5pbWF0aW9uKSB7XG4gICAgICBfcmVjdC5hdHRyKCd4JywgX2xlZnRNYXJnaW4pXG4gICAgICAuYXR0cignaGVpZ2h0JywgMClcbiAgICAgIC5hdHRyKCd5JywgKGQ6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgICAgcmV0dXJuIF9pbml0UG9zWTtcbiAgICAgIH0pXG4gICAgICAuYXR0cignd2lkdGgnLCBfYmFyV2lkdGggLSBfYmFyUGFkZGluZylcbiAgICAgIC50cmFuc2l0aW9uKClcbiAgICAgIC5kdXJhdGlvbihfYW5pbWF0aW9uRHVyYXRpb24pXG4gICAgICAuYXR0cigneScsIChkOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICAgIHJldHVybiB5QmFyU2NhbGUoZCkgKyBfaW5pdFBvc1k7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ2hlaWdodCcsIChkOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICAgIHJldHVybiBfZ3JhcGhIZWlnaHQgLSB5QmFyU2NhbGUoZCkgO1xuICAgICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgICBfcmVjdC5hdHRyKCd4JywgX2xlZnRNYXJnaW4pXG4gICAgICAuYXR0cigneScsIChkOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICAgIHJldHVybiB5QmFyU2NhbGUoZCkgKyBfaW5pdFBvc1k7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ3dpZHRoJywgX2JhcldpZHRoIC0gX2JhclBhZGRpbmcpXG4gICAgICAuYXR0cignaGVpZ2h0JywgKGQ6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgICAgcmV0dXJuIF9ncmFwaEhlaWdodCAtIHlCYXJTY2FsZShkKTtcbiAgICAgIH0pO1xuICB9XG5cbiAgY29uc3QgdGV4dEJhclZhbHVlID0gZ3JwR3JhcGguYXBwZW5kKCd0ZXh0Jyk7XG4gIHRleHRCYXJWYWx1ZVxuICAgICAgLmF0dHIoJ2NsYXNzJywgX2JhclZhbHVlQ2xhc3MpXG4gICAgICAuYXR0cigneCcsIF9sZWZ0TWFyZ2luKVxuICAgICAgLmF0dHIoJ3knLCAoZDogYW55KTogbnVtYmVyID0+IHtcbiAgICAgICAgcmV0dXJuIHlCYXJTY2FsZShkKSArIF9pbml0UG9zWTtcbiAgICAgIH0pXG4gICAgICAudGV4dCgoZDogYW55KTogc3RyaW5nID0+IHtcbiAgICAgICAgcmV0dXJuIGQgO1xuICAgICAgfSk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRBeGlzLS0tLS0tLS0tLS0tLS0tLS1cbiAgdGhpcy5idWlsZFlBeGlzKGNkdCk7XG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBkcmF3WEF4aXNMYWJlbC0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfbGFiZWxEaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGFiZWxBcnJheTogIEFycmF5PHN0cmluZz4gPSBuZXcgQXJyYXkoKTtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgX2xhYmVsQXJyYXkucHVzaChkYXRhU2V0SnNvbi5kYXRhW2ldLngpO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuZHJhd1hBeGlzTGFiZWwoY2R0LCBfbGFiZWxBcnJheSwgQ2hhcnRDb25zdC5CQVJfQ0hBUlRfVFlQRV9OQU1FKTtcbiAgfVxuXG4gIHRoaXMuZHJhd1hCYXNlTGluZShjZHQpO1xuXG4gIC8vICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gIC0tLUNBTEwgYnVpbGRMZWdlbmQtLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uc2VyaWVzKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uc2VyaWVzLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShkYXRhU2V0SnNvbi5zZXJpZXNbaV0sIF9jb2xvcihpKSkpO1xuICAgICAgfVxuICB9XG4gIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfdGl0bGVEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdUaXRsZShjZHQpO1xuICB9XG5cbiAgaWYgKF9ncmlkWURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1lHcmlkKGNkdCk7XG4gIH1cblxufVxuXG5cbnByaXZhdGUgYnVpbGRMaW5lKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkVGVzdC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfZ3JvdXBNYXhZOiBBcnJheTxudW1iZXI+ID0gbmV3IEFycmF5KCk7XG5cbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgbGV0IF9nTWF4WSA9IDA7XG4gICAgICAgICAgZm9yIChjb25zdCBqIGluIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUpIHtcbiAgICAgICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUuaGFzT3duUHJvcGVydHkoaikpIHtcbiAgICAgICAgICAgICAgICAgIGlmIChfZ01heFkgPCBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLnkpIHtcbiAgICAgICAgICAgICAgICAgICAgICBfZ01heFkgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLnk7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgX2dyb3VwTWF4WS5wdXNoKF9nTWF4WSkgO1xuICAgICAgfVxuICB9XG4gIGxldCBfbWF4WCA9IDA7XG4gIGxldCBfbWF4WSA9IDA7XG4gIF9tYXhZID0gZDMubWF4KF9ncm91cE1heFkpO1xuICBfbWF4WCA9IDEwMDtcblxuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuICBjb25zdCBfY29sb3IgPSBjZHQuZGVmYXVsdENvbG9yRnVuYztcblxuICBjb25zdCBfY29sdW1uTnVtID0gZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZS5sZW5ndGggO1xuICBjb25zdCBfY29sdW1uV2lkdGggPSBjZHQuZ3JhcGhXaWR0aCAvIF9jb2x1bW5OdW07XG5cbiAgY29uc29sZS5sb2coX2NvbHVtbldpZHRoKTtcblxuICBpZiAoY29uZmlnRGF0YS5ncmlkLnkuZGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3WUdyaWQoY2R0KTtcbiAgfVxuXG4gIC8vICBPMklkVmFsdWVEYXRhXG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGNvbnN0IF9saW5lQXJyYXk6IEFycmF5PE8ySWRWYWx1ZURhdGE+ID0gbmV3IEFycmF5KCk7XG4gICAgICAgICAgZm9yIChjb25zdCBqIGluIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUpIHtcbiAgICAgICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUuaGFzT3duUHJvcGVydHkoaikpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IGlkVmFsdWUgPSBuZXcgTzJJZFZhbHVlRGF0YShwYXJzZUludChqLCAxMCksIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueSk7XG4gICAgICAgICAgICAgICAgICBfbGluZUFycmF5LnB1c2goaWRWYWx1ZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc3QgbnVtID0gcGFyc2VJbnQoaSwgMTApO1xuICAgICAgICAgIHRoaXMuZHJhd1NpbmdsZUxpbmUoY2R0LCBfbGluZUFycmF5LCBudW0pO1xuICAgICAgfVxuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIHRoaXMuZHJhd1RpdGxlKGNkdCk7XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRBeGlzLS0tLS0tLS0tLS0tLS0tLS1cbiAgdGhpcy5idWlsZFlBeGlzKGNkdCk7XG5cbiAgdGhpcy5kcmF3WEJhc2VMaW5lKGNkdCk7XG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBkcmF3WEF4aXNMYWJlbC0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0IF9sYWJlbEFycmF5OiAgQXJyYXk8c3RyaW5nPiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWUuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBfbGFiZWxBcnJheS5wdXNoKGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWVbaV0ueCk7XG4gICAgICB9XG4gIH1cbiAgdGhpcy5kcmF3WEF4aXNMYWJlbChjZHQsIF9sYWJlbEFycmF5LCBDaGFydENvbnN0LkxJTkVfQ0hBUlRfVFlQRV9OQU1FKTtcblxuICAvLyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vICAtLS1DQUxMIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3QgX2xlZ2VuZERhdGFTZXQ6IEFycmF5PE8yTGVnZW5kRGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWUsIF9jb2xvcihpKSkpO1xuICAgICAgfVxuICB9XG4gIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG5cbn1cblxuXG5cblxucHJpdmF0ZSBkcmF3U2luZ2xlTGluZShvMkNvbW1vbjogYW55LCBkYXRhU2V0OiBhbnksIGxpbmVOdW06IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBkcmF3U2luZ2xlTGluZS0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zb2xlLmxvZyhkYXRhU2V0KTtcbiAgY29uc3QgY2R0ID0gbzJDb21tb247XG4gIGNvbnN0IGNvbmZpZ0RhdGEgPSBjZHQuY29uZmlnRGF0YTtcbiAgY29uc3Qgc3ZnQ29udGFpbmVyID0gY2R0LnN2Z0NvbnRhaW5lcjtcblxuICBjb25zdCBfbWF4WCA9IGNkdC5tYXhYVmFsdWU7XG4gIGNvbnN0IF9pbml0WFBvcyA9IGNkdC5heGlzWExhYmVsSW5pdFhQb3M7XG4gIGNvbnN0IF9pbml0WVBvcyA9IGNkdC5heGlzWExhYmVsSW5pdFlQb3M7XG4gIGNvbnN0IF9jb2x1bW5OdW0gPSBkYXRhU2V0Lmxlbmd0aDtcbiAgY29uc3QgX2NvbHVtbldpZHRoID0gY2R0LmdyYXBoV2lkdGggLyAoX2NvbHVtbk51bSAtIDEpO1xuICBjb25zdCBfY29sb3IgPSBkMy5zY2FsZU9yZGluYWwoZDMuc2NoZW1lQ2F0ZWdvcnkxMCk7XG5cbiAgY29uc3QgX2xpbmVDbGFzc05hbWUgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5tdWx0aUxpbmVQcmVmaXggKyBTdHJpbmcobGluZU51bSk7XG4gIGNvbnN0IF9sZWZ0TWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4ubGVmdDtcbiAgY29uc3QgX2JvdHRvbU1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbTtcblxuICBjb25zdCBfeVNjYWxlID0gY2R0LmdyYXBoWVNjYWxlO1xuXG5cbiAgY29uc3QgbGluZSA9IGQzLmxpbmUoKVxuICAgICAgLmN1cnZlKGQzLmN1cnZlTGluZWFyKVxuICAgICAgLngoIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gX2xlZnRNYXJnaW4gKyBkLmlkICogX2NvbHVtbldpZHRoO1xuICAgICAgfSlcbiAgICAgIC55KCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGNkdC5zdmdIZWlnaHQgLSBfYm90dG9tTWFyZ2luIC0gKCBkLnZhbHVlICogX3lTY2FsZSkgO1xuICAgICAgfSk7XG5cbiAgc3ZnQ29udGFpbmVyLmFwcGVuZCgncGF0aCcpXG4gICAgICAgICAgLmF0dHIoJ2NsYXNzJywgX2xpbmVDbGFzc05hbWUpXG4gICAgICAgICAgLmF0dHIoJ2QnLCBsaW5lKGRhdGFTZXQpKTtcbiAgICAgICAgICAvLyAgLmF0dHIoJ3RyYW5zZm9ybScsIGNkdC5heGlzVHJhbnNsYXRlUG9zKVxufVxuXG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gLS0tQnVpbGQgTGVnZW5kICAtLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbnByaXZhdGUgYnVpbGRMZWdlbmQobzJDb21tb246IGFueSwgX2xlZ2VuZERhdGFTZXQ6IGFueSk6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZExlZ2VuZC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICAvLyAgbWF4VmFsdWVzIGFyZSBtZWFuaW5nbGVzc1xuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3QgY29uZmlnRGF0YSA9IGNkdC5jb25maWdEYXRhO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuICAvLyAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKGNvbmZpZ0RhdGEsIDEwMCwgMTAwLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcbiAgY29uc3QgbGVnZW5kUmVjdFNpemUgPSBjb25maWdEYXRhLmxlZ2VuZC5yZWN0V2lkdGg7XG4gIGNvbnN0IGxlZ2VuZFNwYWNpbmcgPSAxMDtcbiAgY29uc3QgeVNwYWNpbmcgPSBjb25maWdEYXRhLmxlZ2VuZC55U3BhY2luZztcbiAgY29uc3QgaW5pdFBvc1ggPSBjZHQubGVnZW5kSW5pdFhQb3M7XG4gIGNvbnN0IGluaXRQb3NZID0gY2R0LmxlZ2VuZEluaXRZUG9zO1xuICBjb25zdCBvcGFjaXR5ID0gY29uZmlnRGF0YS5jb2xvci5vcGFjaXR5O1xuXG4gIGNvbnN0IGdycExlZ2VuZCA9IHN2Z0NvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgICAgICAgICAuc2VsZWN0QWxsKCdnJylcbiAgICAgICAgICAgICAgLmRhdGEoX2xlZ2VuZERhdGFTZXQpXG4gICAgICAgICAgICAgIC5lbnRlcigpXG4gICAgICAgICAgICAgIC5hcHBlbmQoJ2cnKVxuICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCAnbGVnZW5kJylcbiAgICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIChkOiBPMkxlZ2VuZERhdGEsIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgaGVpZ2h0ID0gbGVnZW5kUmVjdFNpemUgKyB5U3BhY2luZztcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHggPSBpbml0UG9zWDtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IHkgPSBpICogaGVpZ2h0ICsgaW5pdFBvc1kgO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIHggKyAnLCAnICsgeSArICcpJztcbiAgICAgICAgICAgICAgfSk7XG5cbiAgZ3JwTGVnZW5kLmFwcGVuZCgncmVjdCcpXG4gICAgICAuYXR0cignd2lkdGgnLCBsZWdlbmRSZWN0U2l6ZSlcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCBsZWdlbmRSZWN0U2l6ZSlcbiAgICAgIC5zdHlsZSgnZmlsbCcsIChkOiBPMkxlZ2VuZERhdGEpID0+IHtcbiAgICAgICAgICByZXR1cm4gZC5jb2xvcjtcbiAgICAgIH0pXG4gICAgICAuc3R5bGUoJ3N0cm9rZScsIChkOiBPMkxlZ2VuZERhdGEpID0+IHtcbiAgICAgICAgICByZXR1cm4gZC5jb2xvcjtcbiAgICAgIH0pXG4gICAgICAuYXR0cignZmlsbC1vcGFjaXR5Jywgb3BhY2l0eSk7XG5cbiAgZ3JwTGVnZW5kLmFwcGVuZCgndGV4dCcpXG4gICAgICAuYXR0cigneCcsIGxlZ2VuZFJlY3RTaXplICsgbGVnZW5kU3BhY2luZylcbiAgICAgIC5hdHRyKCd5JywgbGVnZW5kUmVjdFNpemUpXG4gICAgICAudGV4dCgoZDogTzJMZWdlbmREYXRhKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGQudGl0bGU7XG4gICAgICB9KTtcbn1cblxuXG5wcml2YXRlIGRyYXdYQXhpc0xhYmVsKG8yQ29tbW9uOiBhbnksIGxhYmVsRGF0YVNldDogYW55LCBjaGFydFR5cGU6IHN0cmluZyk6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBkcmF3WEF4aXNMYWJlbC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3QgY29uZmlnRGF0YSA9IGNkdC5jb25maWdEYXRhO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIC8vIGNvbnN0IF9tYXhYID0gY2R0Lm1heFhWYWx1ZTtcbiAgY29uc3QgX2luaXRYUG9zID0gY2R0LmF4aXNYTGFiZWxJbml0WFBvcztcbiAgY29uc3QgX2luaXRZUG9zID0gY2R0LmF4aXNYTGFiZWxJbml0WVBvcztcblxuICBjb25zdCBfY29sdW1uTnVtID0gbGFiZWxEYXRhU2V0Lmxlbmd0aDtcbiAgbGV0IF9jb2x1bW5XaWR0aCA9IGNkdC5ncmFwaFdpZHRoIC8gX2NvbHVtbk51bTtcbiAgaWYgKCBjaGFydFR5cGUgPT09IENoYXJ0Q29uc3QuTElORV9DSEFSVF9UWVBFX05BTUUpIHtcbiAgICAgIF9jb2x1bW5XaWR0aCA9IGNkdC5ncmFwaFdpZHRoIC8gKF9jb2x1bW5OdW0gLSAxKTtcbiAgfVxuXG4gIGNvbnN0IGdycExhYmVsID0gc3ZnQ29udGFpbmVyLmFwcGVuZCgnZycpXG4gICAgICAgICAgICAgIC5zZWxlY3RBbGwoJ2cnKVxuICAgICAgICAgICAgICAuZGF0YShsYWJlbERhdGFTZXQpXG4gICAgICAgICAgICAgIC5lbnRlcigpXG4gICAgICAgICAgICAgIC5hcHBlbmQoJ2cnKVxuICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCBjb25maWdEYXRhLmF4aXNYVGV4dClcbiAgICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX3ggPSBfaW5pdFhQb3MgKyBfY29sdW1uV2lkdGggKiBpO1xuICAgICAgICAgICAgICAgICAgY29uc3QgX3kgPSBfaW5pdFlQb3MgO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIF94ICsgJywgJyArIF95ICsgJyknO1xuICAgICAgICAgICAgICB9KTtcblxuICBncnBMYWJlbC5hcHBlbmQoJ3RleHQnKVxuICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCBjb25maWdEYXRhLmNsYXNzTmFtZS5heGlzWFRleHQpXG4gICAgICAgICAgICAgIC50ZXh0KChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGQ7XG4gICAgICAgICAgICAgIH0pO1xuXG5cbn1cblxuXG5wcml2YXRlIGRyYXdYQmFzZUxpbmUobzJDb21tb246IGFueSk6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBkcmF3WEJhc2VMaW5lLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IGNkdCA9IG8yQ29tbW9uO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ3JlY3QnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgY2R0LmF4aXNYQm9yZGVyTGluZUNsYXNzTmFtZSlcbiAgICAgIC5hdHRyKCd3aWR0aCcsIGNkdC5heGlzWEJvcmRlcldpZHRoKVxuICAgICAgLmF0dHIoJ2hlaWdodCcsIGNkdC5heGlzWEJvcmRlckxpbmVXaWR0aClcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBjZHQuYXhpc1hCb3JkZXJUcmFuc2xhdGVQb3MpO1xuXG59XG5cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS1CdWlsZCBBeGlzICAtLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbnByaXZhdGUgYnVpbGRZQXhpcyhvMkNvbW1vbjogYW55KTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkWUF4aXMtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgY2R0ID0gbzJDb21tb247XG4gIGNvbnN0IHN2Z0NvbnRhaW5lciA9IGNkdC5zdmdDb250YWluZXI7XG5cbiAgY29uc3QgX21heFkgPSBjZHQubWF4WVZhbHVlO1xuICBjb25zdCBfZ3JhcGhZU2NhbGUgPSBjZHQuZ3JhcGhZU2NhbGU7XG5cbiAgY29uc3QgX2F4aXNZU2NhbGUgPSBkMy5zY2FsZUxpbmVhcigpXG4gICAgICAgICAgICAgICAgICAuZG9tYWluKFswLCBfbWF4WV0pXG4gICAgICAgICAgICAgICAgICAucmFuZ2UoW19tYXhZICogX2dyYXBoWVNjYWxlLCAwXSk7XG5cbiAgc3ZnQ29udGFpbmVyLmFwcGVuZCgnZycpXG4gICAgICAuYXR0cignY2xhc3MnLCBjZHQuYXhpc0NsYXNzTmFtZSlcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBjZHQuYXhpc1RyYW5zbGF0ZVBvcylcbiAgICAgIC5jYWxsKFxuICAgICAgICAgICAgZDMuYXhpc0xlZnQoX2F4aXNZU2NhbGUpXG4gICAgICAgICAgICApO1xuXG59XG5cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0gZHJhd1RpdGxlLS0tLS0tLS0tLS0tLS0tLS1cbnByaXZhdGUgZHJhd1RpdGxlKG8yQ29tbW9uOiBhbnkpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gZHJhd1RpdGxlLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IGNkdCA9IG8yQ29tbW9uO1xuICBjb25zdCBjb25maWdEYXRhID0gY2R0LmNvbmZpZ0RhdGE7XG4gIGNvbnN0IHN2Z0NvbnRhaW5lciA9IGNkdC5zdmdDb250YWluZXI7XG5cbiAgY29uc3QgX3RpdGxlID0gY29uZmlnRGF0YS50aXRsZS5uYW1lO1xuICBjb25zdCBfeFBvcyA9IGNkdC50aXRsZUluaXRYUG9zO1xuICBjb25zdCBfeVBvcyA9IGNkdC50aXRsZUluaXRZUG9zO1xuICBjb25zdCBfdGl0bGVDbGFzc05hbWUgPSBjb25maWdEYXRhLnRpdGxlLmNsYXNzTmFtZTtcblxuICBzdmdDb250YWluZXIuYXBwZW5kKCd0ZXh0JylcbiAgICAgIC5hdHRyKCdjbGFzcycsIF90aXRsZUNsYXNzTmFtZSlcbiAgICAgIC5hdHRyKCd4JywgX3hQb3MpXG4gICAgICAuYXR0cigneScsIF95UG9zKVxuICAgICAgLnRleHQoX3RpdGxlKTtcbn1cblxuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIC0tLWRyYXdHcmlkICAtLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbnByaXZhdGUgZHJhd1lHcmlkKG8yQ29tbW9uOiBhbnkpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRZR3JpZC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3QgY29uZmlnRGF0YSA9IGNkdC5jb25maWdEYXRhO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIGNvbnN0IF9zdGVwWSA9ICBjZHQuZ3JpZFlTdGVwO1xuICBjb25zdCBfbWF4WSA9IGNkdC5tYXhZVmFsdWU7XG4gIGNvbnN0IF9ncmFwaFlTY2FsZSA9IGNkdC5ncmFwaFlTY2FsZTtcbiAgY29uc3QgX2dyaWRDbGFzc05hbWUgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5ncmlkO1xuICBjb25zdCBfcmFuZ2VZID0gZDMucmFuZ2UoX3N0ZXBZICogX2dyYXBoWVNjYWxlLFxuICAgICAgICAgICAgICAgICAgX21heFkgKiBfZ3JhcGhZU2NhbGUsXG4gICAgICAgICAgICAgICAgICBfc3RlcFkgKiBfZ3JhcGhZU2NhbGUpO1xuXG4gIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgLnNlbGVjdEFsbCgnbGluZS55JylcbiAgICAgIC5kYXRhKF9yYW5nZVkpXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgnbGluZScpXG4gICAgICAuYXR0cignY2xhc3MnLCBfZ3JpZENsYXNzTmFtZSlcbiAgICAgIC5hdHRyKCd4MScsIGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQpXG4gICAgICAuYXR0cigneTEnLCAoIGQ6IGFueSwgaTogbnVtYmVyICkgPT4gIHtcbiAgICAgICAgICBjb25zdCBfeTEgPSBjZHQuc3ZnSGVpZ2h0IC0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tIC0gZDtcbiAgICAgICAgICByZXR1cm4gX3kxO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCd4MicsIGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQgKyBjZHQuYXhpc1hCb3JkZXJXaWR0aClcbiAgICAgIC5hdHRyKCd5MicsICggZDogYW55LCBpOiBudW1iZXIgKSA9PiAge1xuICAgICAgICAgIGNvbnN0IF95MSA9IGNkdC5zdmdIZWlnaHQgLSBjb25maWdEYXRhLm1hcmdpbi5ib3R0b20gLSBkO1xuICAgICAgICAgIHJldHVybiBfeTE7XG4gICAgICB9KTtcbiAgfVxufSIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBOZzZPMkNoYXJ0Q29tcG9uZW50IH0gZnJvbSAnLi9uZzYtbzItY2hhcnQuY29tcG9uZW50JztcblxuQE5nTW9kdWxlKHtcbiAgaW1wb3J0czogW1xuICBdLFxuICBkZWNsYXJhdGlvbnM6IFtOZzZPMkNoYXJ0Q29tcG9uZW50XSxcbiAgZXhwb3J0czogW05nNk8yQ2hhcnRDb21wb25lbnRdXG59KVxuZXhwb3J0IGNsYXNzIE5nNk8yQ2hhcnRNb2R1bGUgeyB9XG4iXSwibmFtZXMiOlsiZDMuc2NhbGVPcmRpbmFsIiwiZDMuc2NoZW1lQ2F0ZWdvcnkyMCIsImQzLnNjaGVtZUNhdGVnb3J5MTAiLCJkMy5zZWxlY3QiLCJDaGFydENvbnN0LkxJTkVfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5CQVJfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5QSUVfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5TQ0FUVEVSX1BMT1RfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5ISVNUT0dSQU1fQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5TVEFDS19CQVJfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5HRU9fTUFQX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuR0VPX09SVEhPR1JBUEhJQ19DSEFSVF9UWVBFX05BTUUiLCJDaGFydENvbnN0LlRSRUVfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5QQUNLX0xBWU9VVF9DSEFSVF9UWVBFX05BTUUiLCJDaGFydENvbnN0LkNIT1JPUExFVEhfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5GT1JDRV9DSEFSVF9UWVBFX05BTUUiLCJDaGFydENvbnN0LlRSRUVfTUFQX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuU0FOS0VZX0NIQVJUX1RZUEVfTkFNRSIsImQzLmZvcm1hdCIsImQzLnNjYWxlTGluZWFyIiwiZDMuaGlzdG9ncmFtIiwiZDMubWF4IiwiZDMuZm9yY2VTaW11bGF0aW9uIiwiZDMuZm9yY2VMaW5rIiwiZDMuZm9yY2VNYW55Qm9keSIsImQzLmZvcmNlQ2VudGVyIiwiZDMuZHJhZyIsImQzLmV2ZW50IiwiZDMuaW50ZXJwb2xhdGVIc2wiLCJkMy5nZW9QYXRoIiwiZDMuZ2VvTWVyY2F0b3IiLCJkMy5qc29uIiwiZDMucGFjayIsImQzLmhpZXJhcmNoeSIsInBhY2siLCJ0cmVlIiwiZDMudHJlZSIsImQzLmdlb09ydGhvZ3JhcGhpYyIsImQzLnRpbWVyIiwic3RhY2siLCJkMy5zdGFjayIsImQzLnJhbmdlIiwiZDMuYXhpc0JvdHRvbSIsImQzLnN1bSIsInBpZSIsImQzLnBpZSIsImFyYyIsImQzLmFyYyIsImxpbmUiLCJkMy5saW5lIiwiZDMuY3VydmVMaW5lYXIiLCJkMy5heGlzTGVmdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUFBLHFCQUFhLG9CQUFvQixHQUFJLE1BQU0sQ0FBQztBQUM1QyxxQkFBYSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7QUFDekMscUJBQWEsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO0FBQ3pDLHFCQUFhLDRCQUE0QixHQUFHLGFBQWEsQ0FBQztBQUMxRCxxQkFBYSx5QkFBeUIsR0FBRyxXQUFXLENBQUM7QUFDckQscUJBQWEseUJBQXlCLEdBQUcsVUFBVSxDQUFDO0FBQ3BELHFCQUFhLHVCQUF1QixHQUFHLFFBQVEsQ0FBQztBQUNoRCxxQkFBYSxnQ0FBZ0MsR0FBRyxpQkFBaUIsQ0FBQztBQUNsRSxxQkFBYSx3QkFBd0IsR0FBRyxTQUFTLENBQUM7QUFDbEQscUJBQWEsMkJBQTJCLEdBQUcsWUFBWSxDQUFDO0FBQ3hELHFCQUFhLDBCQUEwQixHQUFHLFlBQVksQ0FBQztBQUN2RCxxQkFBYSxvQkFBb0IsR0FBRyxNQUFNLENBQUM7QUFDM0MscUJBQWEsc0JBQXNCLEdBQUcsUUFBUSxDQUFDO0FBQy9DLHFCQUFhLHFCQUFxQixHQUFHLE9BQU87Ozs7OztBQ2I1QyxBQUlBLElBQUE7SUFFSSxrQkFDVyxjQUNBLFlBQ0EsVUFDQSxVQUNBLFVBQ0E7UUFMQSxpQkFBWSxHQUFaLFlBQVk7UUFDWixlQUFVLEdBQVYsVUFBVTtRQUNWLGFBQVEsR0FBUixRQUFRO1FBQ1IsYUFBUSxHQUFSLFFBQVE7UUFDUixhQUFRLEdBQVIsUUFBUTtRQUNSLGNBQVMsR0FBVCxTQUFTO0tBQ2Y7MEJBS0UsbUNBQWE7Ozs7O1lBQ3BCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDOzs7OzswQkFHL0IsbUNBQWE7Ozs7O1lBQ3BCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDOzs7OzswQkFHL0IsOENBQXdCOzs7OztZQUMvQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQzs7Ozs7MEJBUXRDLCtCQUFTOzs7OztZQUNoQixxQkFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztZQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFO2dCQUNoQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO2FBQ3RDO1lBQ0QsT0FBTyxLQUFLLENBQUM7Ozs7OzBCQUdOLCtCQUFTOzs7OztZQUNoQixxQkFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztZQUMxQixJQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFO2dCQUNoQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO2FBQ3RDO1lBQ0QsT0FBTyxLQUFLLENBQUM7Ozs7OzBCQU1OLG1DQUFhOzs7OztZQUNwQixxQkFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1lBQ3hDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxPQUFPLEVBQUU7Z0JBQy9FLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO3NCQUNyQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7YUFDbkQ7WUFDRCxPQUFPLEtBQUssQ0FBQzs7Ozs7MEJBR04sbUNBQWE7Ozs7O1lBQ3BCLHFCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHO2tCQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7WUFDM0MsT0FBTyxLQUFLLENBQUM7Ozs7OzBCQUdOLGlDQUFXOzs7OztZQUNsQixPQUFPLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQzs7Ozs7MEJBR2xDLGlDQUFXOzs7OztZQUNsQixPQUFPLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQzs7Ozs7MEJBR2pDLGdDQUFVOzs7OztZQUNqQixxQkFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtrQkFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO1lBQzVDLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO2dCQUNoQyxPQUFPLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO2FBQ2hEO1lBRUQsT0FBTyxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQzs7Ozs7MEJBR3hCLGlDQUFXOzs7OztZQUNsQixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVM7a0JBQ1gsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtrQkFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztrQkFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO1lBQzVDLE9BQU8sRUFBRSxDQUFDOzs7OzswQkFHSCxvQ0FBYzs7Ozs7WUFDckIscUJBQU0sUUFBUSxHQUFrQixJQUFJLEtBQUssRUFBRSxDQUFDO1lBQzVDLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO2tCQUN4QixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztZQUNsQyxxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztrQkFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtrQkFDNUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUM7WUFDL0IsUUFBUSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztZQUNsQixRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ2xCLE9BQU8sUUFBUSxDQUFDOzs7OzswQkFHVCw2Q0FBdUI7Ozs7O1lBQzlCLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO2tCQUM1QixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztZQUM5QixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztrQkFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtrQkFDNUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUM7WUFDL0IsT0FBTyxZQUFZLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDOzs7OzswQkFHcEQsMkNBQXFCOzs7OztZQUM1QixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztZQUM5QixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztZQUM5QixPQUFPLFlBQVksR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUM7Ozs7OzBCQU1wRCx3Q0FBa0I7Ozs7O1lBQ3pCLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO2tCQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO1lBQ2pELE9BQU8sRUFBRSxDQUFDOzs7OzswQkFHSCx3Q0FBa0I7Ozs7O1lBQ3pCLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUztrQkFDZixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO1lBQ25ELE9BQU8sRUFBRSxDQUFDOzs7OzswQkFHSCxzQ0FBZ0I7Ozs7O1lBQ3ZCLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7WUFDdkMscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUc7a0JBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQztZQUN2QyxPQUFPLFlBQVksR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUM7Ozs7OzBCQUlwRCwwQ0FBb0I7Ozs7O1lBQzNCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDOzs7OzswQkFHckMsdUNBQWlCOzs7OztZQUN4QixxQkFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztrQkFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTTtrQkFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1lBQy9DLE9BQU8sSUFBSSxDQUFDLFNBQVMsR0FBRyxPQUFPLENBQUM7Ozs7OzBCQUd6QixzQ0FBZ0I7Ozs7O1lBQ3ZCLHFCQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO2tCQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7WUFDNUMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Z0JBQ2hDLE9BQU8sSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7YUFDaEQ7WUFDRCxPQUFPLElBQUksQ0FBQyxRQUFRLEdBQUcsT0FBTyxDQUFDOzs7OzswQkFHeEIsaUNBQVc7Ozs7O1lBQ2xCLE9BQU8sTUFBTSxDQUFDOzs7OzswQkFHUCxpQ0FBVzs7Ozs7WUFDbEIsT0FBTyxRQUFRLENBQUM7Ozs7OzBCQUVULDZDQUF1Qjs7Ozs7WUFDOUIscUJBQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1lBQ3JFLE9BQU8sWUFBWSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSyxHQUFHLEdBQUcsQ0FBQzs7Ozs7MEJBUWhFLHdDQUFrQjs7Ozs7WUFDekIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDOzs7OzswQkFHeEMsc0NBQWdCOzs7OztZQUN2QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7Ozs7OzBCQUd0QyxrREFBNEI7Ozs7O1lBQ25DLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO2tCQUN4QixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztZQUNsQyxxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztrQkFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtrQkFDNUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDO2tCQUNwQixDQUFDLENBQUM7WUFDWixPQUFPLFlBQVksR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUM7Ozs7OzBCQU1wRCxvQ0FBYzs7Ozs7WUFDckIscUJBQUksRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUk7a0JBQ3RCLElBQUksQ0FBQyxVQUFVO2tCQUNmLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBRTtZQUMvQyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsS0FBSyxPQUFPLEVBQUU7Z0JBQzdDLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO3NCQUN6QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUU7YUFDM0M7WUFDRCxPQUFPLEVBQUUsQ0FBQzs7Ozs7MEJBR0gsb0NBQWM7Ozs7O1lBQ3JCLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHO2tCQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNO2tCQUM1QixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7WUFDMUMsT0FBTyxFQUFFLENBQUM7Ozs7OzBCQU1ILCtCQUFTOzs7OztZQUNoQixxQkFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNuRCxxQkFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO1lBQ3BCLHFCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDckQsT0FBTyxLQUFLLENBQUM7Ozs7OzBCQUdOLCtCQUFTOzs7OztZQUNoQixxQkFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQztZQUNuRCxxQkFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO1lBQ3BCLHFCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxRQUFRLENBQUMsR0FBRyxRQUFRLENBQUM7WUFDckQsT0FBTyxLQUFLLENBQUM7Ozs7OzBCQU9OLG1DQUFhOzs7OztZQUNwQixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtrQkFDNUIsQ0FBQyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFVBQVUsSUFBSSxDQUFDO2tCQUN6RCxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7WUFDM0MsT0FBTyxFQUFFLENBQUM7Ozs7OzBCQUdILG1DQUFhOzs7OztZQUNwQixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztrQkFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtrQkFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDO1lBQzdDLE9BQU8sRUFBRSxDQUFDOzs7OzswQkFNSCxzQ0FBZ0I7Ozs7O1lBQ3ZCLHFCQUFJLE1BQVcsQ0FBQztZQUNoQixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUssRUFBRTtnQkFDN0IsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsS0FBSyxJQUFJLEVBQUU7b0JBQ25ELE1BQU0sR0FBR0EsWUFBZSxDQUFDQyxnQkFBbUIsQ0FBQyxDQUFDO2lCQUNqRDtxQkFBTTtvQkFDSCxNQUFNLEdBQUdELFlBQWUsQ0FBQ0UsZ0JBQW1CLENBQUMsQ0FBQztpQkFDakQ7YUFDSjtZQUNELE9BQU8sTUFBTSxDQUFDOzs7OzttQkE1UWxCO0lBOFFDLENBQUE7QUExUUQsQUFzUkEsSUFBQTtJQUNBLHNCQUNVLE9BQ0M7UUFERCxVQUFLLEdBQUwsS0FBSztRQUNKLFVBQUssR0FBTCxLQUFLO0tBQWM7dUJBN1I5QjtJQStSQyxDQUFBO0FBTEQsQUFPQSxJQUFBO0lBQ0EsMkJBQ1UsR0FDQSxHQUNBO1FBRkEsTUFBQyxHQUFELENBQUM7UUFDRCxNQUFDLEdBQUQsQ0FBQztRQUNELE1BQUMsR0FBRCxDQUFDO0tBQWM7NEJBclN6QjtJQXVTQyxDQUFBO0FBTkQsQUFnQkEsSUFBQTtJQUNBLHVCQUNVLElBQ0M7UUFERCxPQUFFLEdBQUYsRUFBRTtRQUNELFVBQUssR0FBTCxLQUFLO0tBQ1I7d0JBclRSO0lBdVRDLENBQUE7QUFORDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqVEE7SUFvQkUsNkJBQWEsVUFBc0I7UUFDakMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO1FBQ2pELHFCQUFNLEVBQUUsR0FBbUIsVUFBVSxDQUFDLGFBQWEsQ0FBQztRQUNwRCxJQUFJLENBQUMsSUFBSSxHQUFHQyxNQUFTLENBQUMsRUFBRSxDQUFDLENBQUM7S0FDN0I7Ozs7SUFFRCxzQ0FBUTs7O0lBQVI7S0FDQzs7Ozs7SUFFRCx5Q0FBVzs7OztJQUFYLFVBQVksT0FBK0M7UUFDekQscUJBQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQzdDLHFCQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUMvQyxxQkFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUMvQixxQkFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztRQUNuQyxxQkFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztRQUNqQyxxQkFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2FBQ2pDLElBQUksQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDO2FBQ3ZCLElBQUksQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFckMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUN2QixRQUFRLFNBQVM7WUFDZixLQUFLQyxvQkFBK0I7Z0JBQ2xDLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUN2RSxNQUFNO1lBQ1IsS0FBS0MsbUJBQThCO2dCQUNqQyxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQztnQkFDdkUsTUFBTTtZQUNSLEtBQUtDLG1CQUE4QjtnQkFDakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7Z0JBQ3ZFLE1BQU07WUFDUixLQUFLQyw0QkFBdUM7Z0JBQzFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7Z0JBQy9FLE1BQU07WUFDUixLQUFLQyx5QkFBb0M7Z0JBQ3ZDLElBQUksQ0FBQyxjQUFjLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO2dCQUM3RSxNQUFNO1lBQ1IsS0FBS0MseUJBQW9DO2dCQUN2QyxJQUFJLENBQUMsYUFBYSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQztnQkFDNUUsTUFBTTtZQUNSLEtBQUtDLHVCQUFrQztnQkFDckMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7Z0JBQzFFLE1BQU07WUFDUixLQUFLQyxnQ0FBMkM7Z0JBQzlDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7Z0JBQ25GLE1BQU07WUFDUixLQUFLQyxvQkFBK0I7Z0JBQ2xDLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO2dCQUN4RSxNQUFNO1lBQ1IsS0FBS0MsMkJBQXNDO2dCQUN6QyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQztnQkFDOUUsTUFBTTtZQUNSLEtBQUtDLDBCQUFxQztnQkFDeEMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7Z0JBQzlFLE1BQU07WUFDUixLQUFLQyxxQkFBZ0M7Z0JBQ25DLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO2dCQUN6RSxNQUFNO1lBQ1IsS0FBS0Msd0JBQW1DOztnQkFFdEMsTUFBTTtZQUNSLEtBQUtDLHNCQUFpQzs7Z0JBRXBDLE1BQU07WUFDUjtnQkFDRSxNQUFNO1NBQ1Q7S0FDRjs7Ozs7Ozs7O0lBSU8sNENBQWM7Ozs7Ozs7O2NBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBRTlHLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0NBQXNDLENBQUMsQ0FBQztRQUVwRCxxQkFBTSxPQUFPLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQztRQUNqQyxxQkFBTSxVQUFVLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBRS9DLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDbEIscUJBQU0sS0FBSyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkMscUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDdEYscUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7UUFDbkMscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7UUFHckMscUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7UUFDdEMscUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7UUFFdEMscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1FBQy9DLHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUMvQyxxQkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUN6RCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ2hELHFCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztRQUMzQyxxQkFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7UUFDekMscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDO1FBR3JELHFCQUFNLFFBQVEsR0FBa0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUM1QyxLQUFLLHFCQUFNLENBQUMsSUFBSSxPQUFPLEVBQUU7WUFDckIsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUMzQixxQkFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQztnQkFDaEMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN2QjtTQUNKO1FBRUQscUJBQU0sV0FBVyxHQUFHQyxNQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7UUFFdEMscUJBQU0sa0JBQWtCLEdBQUcsWUFBWTthQUN0QixNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ1gsSUFBSSxDQUFDLFdBQVcsRUFBRSxZQUFZLEdBQUcsV0FBVyxHQUFHLEdBQUcsR0FBRyxXQUFXLEdBQUcsR0FBRyxDQUFDLENBQUM7UUFFekYscUJBQU0sT0FBTyxHQUFHQyxXQUFjLEVBQUU7YUFDM0IsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUM7UUFFbEMscUJBQU0sSUFBSSxHQUFHQyxTQUFZLEVBQUU7YUFDdEIsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO2FBQ2QsVUFBVSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FDckMsUUFBUSxDQUFDLENBQUM7UUFHZixxQkFBTSxPQUFPLEdBQUdELFdBQWMsRUFBRTthQUMzQixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUVFLEdBQU0sQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFNO2dCQUM1QixPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUM7YUFDbkIsQ0FBQyxDQUFDLENBQUM7YUFDSCxLQUFLLENBQUMsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUU5QixxQkFBTSxHQUFHLEdBQUcsa0JBQWtCO2FBQ3pCLFNBQVMsQ0FBQyxNQUFNLENBQUM7YUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQzthQUNWLEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDWCxJQUFJLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQzthQUN6QixJQUFJLENBQUMsV0FBVyxFQUFFLFVBQUMsQ0FBTTtZQUN0QixPQUFPLFlBQVksR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUN2RSxDQUFDLENBQUM7UUFFUCxJQUFJLFVBQVUsRUFBRTtZQUNaLEdBQUcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2lCQUNiLElBQUksQ0FBQyxHQUFHLEVBQUcsQ0FBQyxDQUFDO2lCQUNiLElBQUksQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDNUQsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUM7aUJBQ2pCLFVBQVUsRUFBRTtpQkFDWixRQUFRLENBQUMsa0JBQWtCLENBQUM7aUJBQzVCLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBQyxDQUFNO2dCQUNuQixPQUFPLFlBQVksR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQzNDLENBQUMsQ0FBQztTQUNWO2FBQU07WUFDSCxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztpQkFDYixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztpQkFDWixJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQzVELElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBQyxDQUFNO2dCQUNuQixPQUFPLFlBQVksR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO2FBQzNDLENBQUMsQ0FBQztTQUNWO1FBRUQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDYixJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQzthQUNuQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzthQUNaLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO2FBQzFELElBQUksQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDO2FBQzdCLElBQUksQ0FBQyxVQUFDLENBQU07WUFDVCxPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDaEMsQ0FBQyxDQUFDOztRQUdQLElBQUksYUFBYSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2Qjs7O1FBR0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUVyQixJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXBCLElBQUksYUFBYSxFQUFFO1lBQ2hCLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDdkI7Ozs7Ozs7Ozs7SUFLSyx3Q0FBVTs7Ozs7Ozs7Y0FBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7UUFFMUcsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO1FBRTdDLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDbEIscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUNsQixxQkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUV0RixxQkFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLGdCQUFnQixDQUFDO1FBSXBDLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO1FBQ3JDLHFCQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBRW5DLHFCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztRQUMzQyxxQkFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7UUFHekMscUJBQU0sVUFBVSxHQUFHQyxlQUFrQixFQUFFO2FBQ2xDLEtBQUssQ0FBQyxNQUFNLEVBQUVDLFNBQVksRUFBRSxDQUFDLEVBQUUsQ0FBQyxVQUFDLENBQU07WUFDcEMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDO1NBQ2YsQ0FBQyxDQUFDO2FBQ0YsS0FBSyxDQUFDLFFBQVEsRUFBRUMsYUFBZ0IsRUFBRSxDQUFDO2FBQ25DLEtBQUssQ0FBQyxRQUFRLEVBQUVDLFdBQWMsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxFQUFFLFlBQVksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBR3hFLHFCQUFNLGVBQWUsR0FBRyxZQUFZO2FBQ2pDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDWCxJQUFJLENBQUMsV0FBVyxFQUNmLFlBQVksR0FBRyxXQUFXLEdBQUcsR0FBRyxHQUFHLFVBQVUsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUV6RCxxQkFBTSxJQUFJLEdBQUcsZUFBZSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDbkMsSUFBSSxDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7YUFDNUIsU0FBUyxDQUFDLE1BQU0sQ0FBQzthQUNqQixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQzthQUN2QixLQUFLLEVBQUU7YUFDUCxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ2QsSUFBSSxDQUFDLGNBQWMsRUFBRSxVQUFDLENBQU07WUFDekIsT0FBTyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUM3QixDQUFDLENBQUM7UUFFUCxxQkFBTSxJQUFJLEdBQUcsZUFBZSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDbkMsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUM7YUFDdEIsU0FBUyxDQUFDLFFBQVEsQ0FBQzthQUNuQixJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQzthQUN2QixLQUFLLEVBQUU7YUFDUCxNQUFNLENBQUMsUUFBUSxDQUFDO2FBQ2hCLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO2FBQ1osSUFBSSxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQU07WUFDakIsT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQzFCLENBQUM7YUFDRCxJQUFJLENBQUNDLElBQU8sRUFBRTthQUNWLEVBQUUsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDO2FBQ3hCLEVBQUUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDO2FBQ25CLEVBQUUsQ0FBQyxLQUFLLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQztRQUUzQixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzthQUNmLElBQUksQ0FBQyxVQUFDLENBQU07WUFDVCxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUM7U0FDZixDQUFDLENBQUM7UUFFWCxVQUFVO2FBQ0wsS0FBSyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7YUFDeEIsRUFBRSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztRQUV4QixxQkFBTSxVQUFVLEdBQVEsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUNqRCxVQUFVLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQzs7OztRQUVwQztZQUNJLElBQUk7aUJBQ0MsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFDLENBQU07Z0JBQ2hCLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7YUFBRSxDQUFDO2lCQUN2QixJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBTTtnQkFDakIsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQzthQUFFLENBQUM7aUJBQ3RCLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFNO2dCQUNoQixPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2FBQUUsQ0FBQztpQkFDdkIsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFDLENBQU07Z0JBQ2hCLE9BQU8sQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7YUFBRSxDQUFDLENBQUM7WUFFN0IsSUFBSTtpQkFDQyxJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBTTtnQkFDaEIsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQUUsQ0FBQztpQkFDaEIsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFDLENBQU07Z0JBQ2hCLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUFFLENBQUMsQ0FBQztTQUN6Qjs7Ozs7UUFFRCxxQkFBcUIsQ0FBTTtZQUN2QixJQUFJLENBQUNDLEtBQVEsQ0FBQyxNQUFNLEVBQUU7Z0JBQ2xCLFVBQVUsQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7YUFDekM7WUFDRCxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDWCxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDZDs7Ozs7UUFFRCxpQkFBaUIsQ0FBTTtZQUNuQixDQUFDLENBQUMsRUFBRSxHQUFHQSxLQUFRLENBQUMsQ0FBQyxDQUFDO1lBQ2xCLENBQUMsQ0FBQyxFQUFFLEdBQUdBLEtBQVEsQ0FBQyxDQUFDLENBQUM7U0FDckI7Ozs7O1FBRUQsbUJBQW1CLENBQU07WUFDckIsSUFBSSxDQUFDQSxLQUFRLENBQUMsTUFBTSxFQUFFO2dCQUNsQixVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzdCO1lBQ0QsQ0FBQyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUM7WUFDWixDQUFDLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQztTQUNmOzs7UUFJRCxxQkFBTSxjQUFjLEdBQXdCLElBQUksS0FBSyxFQUFFLENBQUM7UUFDeEQsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLE1BQU0sRUFBRTtZQUNoQyxJQUFJLFdBQVcsQ0FBQyxNQUFNLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUN0QyxxQkFBTSxHQUFHLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7Z0JBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNsRjtTQUNKO1FBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7Ozs7Ozs7Ozs7SUFPaEMsNkNBQWU7Ozs7Ozs7O2NBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBRS9HLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0NBQXdDLENBQUMsQ0FBQztRQUV0RCxxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDO1FBQ2xCLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDbEIscUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDdEYscUJBQU0sZUFBZSxHQUFHLEdBQUcsQ0FBQyxjQUFjLENBQUM7UUFLM0MscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1FBQy9DLHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUNqRCxxQkFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUM7UUFFaEQscUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO1FBQ3JDLHFCQUFNLFdBQVcsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUMvQyxxQkFBTSxZQUFZLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUM7UUFDakQscUJBQU0sUUFBUSxHQUFHLE9BQU8sR0FBRyxZQUFZLENBQUM7UUFDeEMscUJBQU0sY0FBYyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO1FBQ3RELHFCQUFNLFdBQVcsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUMvQyxxQkFBTSxTQUFTLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUM7UUFDM0MscUJBQU0sU0FBUyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO1FBQzlDLHFCQUFNLE9BQU8sR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztRQUN2QyxxQkFBTSxtQkFBbUIsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDO1FBQy9ELHFCQUFNLGVBQWUsR0FBRyxJQUFJLEdBQUcsbUJBQW1CLENBQUM7UUFFbkQscUJBQU0sS0FBSyxHQUFHQyxjQUFpQixDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUV4RCxxQkFBSSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDckMscUJBQUksSUFBSSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO1FBQ3JDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7WUFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDcEMsSUFBSSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7b0JBQ2xDLElBQUksR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztpQkFDcEM7Z0JBQ0QsSUFBSSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7b0JBQ2xDLElBQUksR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztpQkFDcEM7YUFDSjtTQUNKO1FBQ0QscUJBQU0sTUFBTSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7UUFDM0IscUJBQU0sS0FBSyxHQUFHLE1BQU0sSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFdkMscUJBQU0sY0FBYyxHQUFHLFVBQUMsRUFBVTtZQUM5QixLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO2dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNwQyxJQUFJLEVBQUUsS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTt3QkFDL0IscUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO3dCQUN6QyxxQkFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxJQUFJLElBQUksS0FBSyxDQUFDLENBQUM7d0JBQ2pELE9BQU8sS0FBSyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsQ0FBQztxQkFDOUI7aUJBQ0o7YUFDSjtTQUNKLENBQUM7UUFFRixxQkFBTSxJQUFJLEdBQUdDLE9BQVUsRUFBRTthQUNaLFVBQVUsQ0FDUEMsV0FBYyxFQUFFO2FBQ2YsTUFBTSxDQUFDLE9BQU8sQ0FBQzthQUNmLEtBQUssQ0FBQyxNQUFNLENBQUM7YUFDYixTQUFTLENBQUMsZUFBZSxDQUFDLENBQzlCLENBQUM7UUFFZEMsSUFBTyxDQUFDLGNBQWMsRUFBRSxVQUFDLEtBQUssRUFBRSxJQUFJO1lBQ2hDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2lCQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2lCQUNwQixLQUFLLEVBQUU7aUJBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQztpQkFDZCxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQztpQkFDZixLQUFLLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7Z0JBQzdCLHFCQUFNLEdBQUcsR0FBRyxjQUFjLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7Z0JBQ2xELE9BQU8sR0FBRyxDQUFDO2FBQ2QsQ0FBQyxDQUFDO1NBQ2QsQ0FBQyxDQUFDOzs7UUFJSCxJQUFJLGFBQWEsRUFBRTtZQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDdkI7OztRQUlELElBQUksY0FBYyxFQUFFO1lBQ2hCLHFCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUN4RCxLQUFLLHFCQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsRUFBRSxDQUFDLEVBQUUsRUFBRTtnQkFDaEMscUJBQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxJQUFJLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLEdBQUksS0FBSyxDQUFDO2dCQUNuRCxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLE1BQU0sRUFBRSxLQUFLLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNsRTtZQUNELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1NBQ3pDOzs7Ozs7Ozs7O0lBSUssNkNBQWU7Ozs7Ozs7O2NBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBRS9HLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztRQUUvQyxxQkFBTSxnQkFBZ0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFVBQVUsQ0FBQztRQUN6RCxxQkFBTSxxQkFBcUIsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQztRQUNuRSxxQkFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7UUFDL0MscUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7UUFDekQscUJBQU0sS0FBSyxHQUFHL0IsWUFBZSxDQUFDRSxnQkFBbUIsQ0FBQyxDQUFDOztRQUVuRCxxQkFBTSxNQUFNLEdBQUc4QixJQUFPLEVBQUU7YUFDUCxJQUFJLENBQUMsQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUMsQ0FBQztRQUU3QyxxQkFBTSxNQUFNLEdBQUdDLFNBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQztRQUV6QyxxQkFBTUMsT0FBSSxHQUFJLFlBQVksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO2FBQzVCLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDbEMsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNYLElBQUksQ0FBQyxXQUFXLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUztZQUNqQyxPQUFPLFlBQVksR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUMvQyxDQUFDLENBQUM7UUFFZixxQkFBTSxPQUFPLEdBQUdBLE9BQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdEMsSUFBSSxVQUFVLEVBQUU7WUFDWixPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7aUJBQ1gsVUFBVSxFQUFFO2lCQUNaLFFBQVEsQ0FBQyxVQUFDLENBQU0sRUFBRSxDQUFTO2dCQUN4QixPQUFPLENBQUMsQ0FBQyxLQUFLLEdBQUcsa0JBQWtCLEdBQUksR0FBRyxDQUFDO2FBQzlDLENBQUM7aUJBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU07Z0JBQ2QsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2QsQ0FBQztpQkFDRCxLQUFLLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQU07Z0JBQzFCLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ25CLENBQUMsQ0FBQztTQUNkO2FBQU07WUFDSCxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU07Z0JBQ2IsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2QsQ0FBQztpQkFDRCxLQUFLLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQU07Z0JBQzFCLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ25CLENBQUMsQ0FBQztTQUNkO1FBRUQscUJBQU0sS0FBSyxHQUFHQSxPQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNwQixJQUFJLENBQUMsT0FBTyxFQUFFLHFCQUFxQixDQUFDO2FBQ3BDLElBQUksQ0FBQyxVQUFDLENBQU0sRUFBRSxDQUFTO1lBQ3BCLElBQUksQ0FBQyxDQUFDLEtBQUssS0FBSyxDQUFDLEVBQUU7Z0JBQ2YsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzthQUN0QjtZQUNELE9BQU8sSUFBSSxDQUFDO1NBQ2YsQ0FBQyxDQUFDO1FBRWYsSUFBSSxVQUFVLEVBQUU7WUFDWixLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUM7aUJBQ3BCLFVBQVUsRUFBRTtpQkFDWixRQUFRLENBQUMsa0JBQWtCLENBQUM7aUJBQzVCLEtBQUssQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDLENBQUM7U0FDOUI7YUFBTTtZQUNILEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO1NBQy9COzs7Ozs7Ozs7O0lBSUssdUNBQVM7Ozs7Ozs7O2NBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBRXpHLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0JBQStCLENBQUMsQ0FBQztRQUU3QyxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQ2QscUJBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztRQUNkLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDWixLQUFLLEdBQUcsR0FBRyxDQUFDO1FBQ1oscUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFLdEYscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7UUFDckMscUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7UUFFbkMscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO1FBQy9DLHFCQUFNLGtCQUFrQixHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO1FBQ3pELHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQztRQUNuRCxxQkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQztRQUM3RCxxQkFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7UUFDM0MscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1FBR3pDLHFCQUFNQyxPQUFJLEdBQUdDLElBQU8sRUFBRTthQUNMLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBRW5ELHFCQUFNLE1BQU0sR0FBR0gsU0FBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1FBRXpDLHFCQUFNLEtBQUssR0FBR0UsT0FBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBRTNCLHFCQUFNLGNBQWMsR0FBRyxZQUFZO2FBQ2hDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDWCxJQUFJLENBQUMsV0FBVyxFQUNmLFlBQVksR0FBRyxXQUFXLEdBQUcsR0FBRyxHQUFHLFVBQVUsR0FBRyxHQUFHLENBQUMsQ0FBQztRQUV6RCxxQkFBTSxJQUFJLEdBQUcsY0FBYzthQUN0QixTQUFTLENBQUMsT0FBTyxDQUFDO2FBQ2xCLElBQUksQ0FBRSxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ25DLEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDZCxJQUFJLENBQUMsT0FBTyxFQUFFLGdCQUFnQixDQUFDO2FBQy9CLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxDQUFNO1lBQ2QsT0FBTyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7a0JBQ3RCLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztrQkFDeEMsR0FBRyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQztrQkFDaEQsR0FBRyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztTQUN6QyxDQUNKLENBQUM7UUFFTixxQkFBTSxJQUFJLEdBQUcsY0FBYzthQUN0QixTQUFTLENBQUMsT0FBTyxDQUFDO2FBQ2xCLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7YUFDekIsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNYLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBQyxDQUFNO1lBQ2xCLE9BQU8sV0FBVztpQkFDakIsQ0FBQyxDQUFDLFFBQVEsR0FBRyxXQUFXLEdBQUcsT0FBTyxDQUFDLENBQUM7U0FDeEMsQ0FBQzthQUNELElBQUksQ0FBQyxXQUFXLEVBQUUsVUFBQyxDQUFNO1lBQ3RCLE9BQU8sWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO1NBQy9DLENBQUMsQ0FBQztRQUVQLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO2FBQ2hCLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFbkIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDZCxJQUFJLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQzthQUNuQixJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTTtZQUNkLE9BQU8sQ0FBQyxDQUFDLFFBQVEsR0FBRyxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUM7U0FDaEMsQ0FBQzthQUNELEtBQUssQ0FBQyxhQUFhLEVBQUUsUUFBUSxDQUFDO2FBQzlCLElBQUksQ0FBQyxVQUFDLENBQU07WUFDVCxPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO1NBQ3RCLENBQUMsQ0FBQzs7Ozs7Ozs7OztJQU9ELGtEQUFvQjs7Ozs7Ozs7Y0FBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7UUFFcEgsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDO1FBRTNELHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDbEIscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUNsQixxQkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN0RixxQkFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLGNBQWMsQ0FBQztRQUkzQyxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDL0MscUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQ2pELHFCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztRQUVoRCxxQkFBTSxjQUFjLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7UUFDdEQscUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO1FBQ3JDLHFCQUFNLFdBQVcsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUMvQyxxQkFBTSxlQUFlLEdBQUcsSUFBSSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUM7UUFDbEUscUJBQU0sWUFBWSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO1FBQ2pELHFCQUFNLFFBQVEsR0FBRyxPQUFPLEdBQUcsWUFBWSxDQUFDO1FBQ3hDLHFCQUFNLFVBQVUsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUM3QyxxQkFBTSxRQUFRLEdBQUssV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO1FBQ3JELHFCQUFNLFFBQVEsR0FBSyxXQUFXLENBQUMsR0FBRyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7UUFDbkQscUJBQU0sV0FBVyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQy9DLHFCQUFNLGdCQUFnQixHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDO1FBQ3pELHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUMvQyxxQkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUN6RCxxQkFBSSxXQUFXLEdBQUcsQ0FBQyxDQUFDO1FBRXBCLHFCQUFNLGdCQUFnQixHQUFHLFVBQUMsSUFBWTtZQUNsQyxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO2dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNwQyxJQUFJLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRTt3QkFDbkMscUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO3dCQUN6QyxPQUFPLE1BQU0sQ0FBQztxQkFDakI7aUJBQ0o7YUFDSjtZQUNELE9BQU8sSUFBSSxDQUFDO1NBQ2YsQ0FBQztRQUVGLHFCQUFNLFVBQVUsR0FBR0UsZUFBa0IsRUFBRTthQUMxQixTQUFTLENBQUMsZUFBZSxDQUFDO2FBQzFCLFNBQVMsQ0FBQyxVQUFVLENBQUM7YUFDckIsS0FBSyxDQUFDLE1BQU0sQ0FBQzthQUNiLE1BQU0sQ0FBQyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBRTFDLHFCQUFNLElBQUksR0FBR1IsT0FBVSxFQUFFO2FBQ1osVUFBVSxDQUNQLFVBQVUsQ0FDYixDQUFDO1FBRWRFLElBQU8sQ0FBQyxjQUFjLEVBQUUsVUFBQyxLQUFLLEVBQUUsSUFBSTtZQUNoQyxZQUFZLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztpQkFDeEIsSUFBSSxDQUFDLElBQUksRUFBRSxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQzlCLElBQUksQ0FBQyxJQUFJLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUM5QixJQUFJLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQztpQkFDakIsS0FBSyxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQztZQUVoQyxxQkFBTSxTQUFTLEdBQUcsWUFBWSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7aUJBQzNDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQ3BCLEtBQUssRUFBRTtpQkFDUCxNQUFNLENBQUMsTUFBTSxDQUFDO2lCQUNkLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO2lCQUNmLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUztnQkFDN0IscUJBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFDMUMsSUFBSSxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsS0FBSyxJQUFJLEVBQUU7b0JBQ3hDLE9BQU8sZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3hDO2dCQUVELE9BQU8sTUFBTSxHQUFHLENBQUMsR0FBRyxXQUFXLENBQUM7YUFDbkMsQ0FBQyxDQUFDO1lBQ1AsSUFBSSxVQUFVLEVBQUU7Z0JBQ1pPLEtBQVEsQ0FBQztvQkFDTCxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsUUFBUSxHQUFHLFdBQVcsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO29CQUN0RCxXQUFXLElBQUksQ0FBQyxDQUFDO29CQUNqQixTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsQ0FBQztpQkFDN0IsQ0FBQyxDQUFDO2FBQ047U0FDSixDQUFDLENBQUM7OztRQUlILElBQUksYUFBYSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2QjtRQUVELElBQUksY0FBYyxFQUFFO1lBQ2hCLHFCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUN4RCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO2dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNwQyxxQkFBTSxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7b0JBQ3ZDLHFCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztvQkFDekMsSUFBSSxLQUFLLEtBQUssWUFBWSxFQUFFO3dCQUN4QixTQUFTO3FCQUNaO29CQUNELGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO2lCQUM5RjthQUNKO1lBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7U0FDekM7Ozs7Ozs7Ozs7SUFPSyx5Q0FBVzs7Ozs7Ozs7Y0FBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7UUFFM0csT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO1FBRWxELHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDbEIscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUNsQixxQkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN0RixxQkFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLGNBQWMsQ0FBQztRQUMzQyxxQkFBTSxjQUFjLEdBQUksV0FBVyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7UUFDdkQscUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDO1FBQ3JDLHFCQUFNLFlBQVksR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUNqRCxxQkFBTSxRQUFRLEdBQUcsT0FBTyxHQUFHLFlBQVksQ0FBQztRQUN4QyxxQkFBTSxlQUFlLEdBQUcsSUFBSSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUM7UUFDbEUscUJBQU0sZ0JBQWdCLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUM7UUFDekQscUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBRWpELHFCQUFNLElBQUksR0FBR1QsT0FBVSxFQUFFO2FBQ1osVUFBVSxDQUNQQyxXQUFjLEVBQUU7YUFDZixTQUFTLENBQUMsZUFBZSxDQUFDO2FBQzFCLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FDakIsQ0FBQztRQUVkLHFCQUFNLGdCQUFnQixHQUFHLFVBQUMsSUFBWTtZQUNsQyxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO2dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNwQyxJQUFJLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRTt3QkFDbkMscUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO3dCQUN6QyxPQUFPLE1BQU0sQ0FBQztxQkFDakI7aUJBQ0o7YUFDSjtZQUNELE9BQU8sSUFBSSxDQUFDO1NBQ2YsQ0FBQztRQUVGQyxJQUFPLENBQUMsY0FBYyxFQUFFLFVBQUMsS0FBSyxFQUFFLElBQUk7WUFDaEMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7aUJBQ3JCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7aUJBQ3BCLEtBQUssRUFBRTtpQkFDUCxNQUFNLENBQUMsTUFBTSxDQUFDO2lCQUNkLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO2lCQUNmLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUztnQkFDN0IscUJBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQztnQkFDMUMsSUFBSSxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsS0FBSyxJQUFJLEVBQUU7b0JBQ3hDLE9BQU8sZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7aUJBQ3hDO2dCQUNELE9BQU8sTUFBTSxHQUFHLENBQUMsR0FBRyxXQUFXLENBQUM7YUFDbkMsQ0FBQyxDQUFDO1NBQ1YsQ0FBQyxDQUFDOzs7UUFJUCxJQUFJLGNBQWMsRUFBRTtZQUNoQixxQkFBTSxjQUFjLEdBQXdCLElBQUksS0FBSyxFQUFFLENBQUM7WUFDeEQsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtnQkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDcEMscUJBQU0sS0FBSyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDO29CQUN2QyxxQkFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7b0JBQ3pDLElBQUksS0FBSyxLQUFLLFlBQVksRUFBRTt3QkFDeEIsU0FBUztxQkFDWjtvQkFDRCxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQztpQkFDOUY7YUFDSjtZQUNELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1NBQ3pDOzs7Ozs7Ozs7O0lBTUssMkNBQWE7Ozs7Ozs7O2NBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBRTdHLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLENBQUMsQ0FBQztRQVNuRCxxQkFBTSxPQUFPLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7UUFDM0MsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtZQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNyQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ2xCO1NBQ0o7UUFFRCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO1lBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3BDLHFCQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Z0JBQ1YsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7b0JBQ3ZDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUM3QyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ2xEO2lCQUNKO2FBQ0o7U0FDSjtRQUNELHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDZCxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsS0FBSyxHQUFHVixHQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDeEIsS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUNaLHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRXRGLHFCQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7UUFDcEMscUJBQU0sVUFBVSxHQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQzVDLHFCQUFNLFNBQVMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsVUFBVSxJQUFJLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQzVFLHFCQUFNLFlBQVksSUFBSSxHQUFHLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQyxDQUFFO1FBQ3BELHFCQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsYUFBYSxDQUFDO1FBRXBDLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO1FBQ3JDLHFCQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDO1FBRWpDLHFCQUFNLFFBQVEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUMxQyxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFDakQscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUNoRCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ2hELHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUMvQyxxQkFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7UUFDL0MscUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7O1FBR3pELHFCQUFNLGVBQWUsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDOztRQUc5QyxxQkFBTSxTQUFTLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7UUFDN0MsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtZQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNwQyxxQkFBTSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7Z0JBQ3RDLHFCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzlDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDeEI7U0FDSjs7UUFHRCxxQkFBTSxVQUFVLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7UUFDOUMsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7WUFDdkMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQzdDLHFCQUFNLE9BQU8sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQy9DLFVBQVUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7YUFDNUI7U0FDSjtRQUVELHFCQUFNLFVBQVUsR0FBZSxJQUFJLEtBQUssRUFBRSxDQUFDO1FBQzNDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFVBQVUsRUFBRTtZQUN4QixJQUFJLFVBQVUsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBRTlCLHFCQUFNLFdBQVcsR0FBZSxFQUFHLENBQUM7Z0JBQ3BDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFNBQVMsRUFBRTtvQkFDdkIsSUFBSSxTQUFTLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUM3QixxQkFBTSxJQUFJLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUMxQixxQkFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3dCQUM5QyxXQUFXLENBQUMsSUFBSSxDQUFDLEdBQUksTUFBTSxDQUFDO3FCQUMvQjtpQkFDSjtnQkFDRCxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDO2FBQ2hDO1NBQ0o7UUFFRCxxQkFBTSxNQUFNLEdBQUdGLFdBQWMsRUFBRTthQUNkLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQzthQUN2QixLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUcxQyxxQkFBTW9CLFFBQUssR0FBR0MsS0FBUSxFQUFFLENBQUM7UUFDekIscUJBQU0sS0FBSyxHQUFHLFlBQVksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO2FBQ3BDLElBQUksQ0FBQ0QsUUFBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQzthQUN2QyxLQUFLLEVBQUU7YUFDUCxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ1gsSUFBSSxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO1lBQzVCLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3BCLENBQUU7YUFDRixJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsQ0FBQzthQUM5QixTQUFTLENBQUMsTUFBTSxDQUFDO2FBQ2pCLElBQUksQ0FBQyxVQUFDLENBQU0sRUFBRSxDQUFTO1lBQ3BCLE9BQU8sQ0FBQyxDQUFDO1NBQ1osQ0FBQzthQUNELEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUlwQixJQUFJLFVBQVUsRUFBRTtZQUNaLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7Z0JBQzlCLE9BQU8sU0FBUyxHQUFLLENBQUMsR0FBRyxZQUFZLENBQUM7YUFDekMsQ0FBQztpQkFDRCxJQUFJLENBQUMsUUFBUSxFQUFHLENBQUMsQ0FBQztpQkFDbEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO2dCQUN6QixxQkFBTSxFQUFFLEdBQUcsU0FBUyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDcEMscUJBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztnQkFDekIsT0FBTyxTQUFTLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzlELENBQUM7aUJBQ0QsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUM7aUJBQ3hCLFVBQVUsRUFBRTtpQkFDWixRQUFRLENBQUMsa0JBQWtCLENBQUM7aUJBQzVCLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUztnQkFDOUIsT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzlCLENBQUMsQ0FBQztTQUNOO2FBQU07WUFDSCxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO2dCQUM5QixPQUFPLFNBQVMsSUFBSSxDQUFDLEdBQUcsWUFBWSxDQUFDLENBQUM7YUFDekMsQ0FBQztpQkFDRCxJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7Z0JBQ3pCLHFCQUFNLEVBQUUsR0FBRyxTQUFTLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNwQyxxQkFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUN6QixPQUFPLFNBQVMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDOUQsQ0FBQztpQkFDRCxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQztpQkFDeEIsSUFBSSxDQUFDLFFBQVEsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO2dCQUM5QixPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDOUIsQ0FBQyxDQUFDO1NBQ047OztRQUtELElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7OztRQUlwQixJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBRXJCLElBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLENBQUM7OztRQUl4QixJQUFJLGFBQWEsRUFBRTtZQUNmLHFCQUFNLFdBQVcsR0FBbUIsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUNoRCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtnQkFDdkMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQzdDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3BEO2FBQ0o7WUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUU5Qix5QkFBb0MsQ0FBQyxDQUFDO1NBQy9FOzs7UUFLRCxJQUFJLGNBQWMsRUFBRTtZQUNoQixxQkFBTSxjQUFjLEdBQXdCLElBQUksS0FBSyxFQUFFLENBQUM7WUFDeEQsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtnQkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDcEMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLFlBQVksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2lCQUM5RTthQUNKO1lBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7U0FDekM7UUFFRCxJQUFJLGFBQWEsRUFBRTtZQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDdkI7Ozs7Ozs7Ozs7SUFJSyw4Q0FBZ0I7Ozs7Ozs7O2NBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBRWhILE9BQU8sQ0FBQyxHQUFHLENBQUMsc0NBQXNDLENBQUMsQ0FBQztRQUVwRCxxQkFBTSxRQUFRLEdBQTZCLElBQUksS0FBSyxFQUFFLENBQUM7UUFDdkQscUJBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztRQUNkLHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDZCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO1lBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3BDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO29CQUN2QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDN0MsSUFBSSxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUN4QyxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUMxQzt3QkFDRCxJQUFJLEtBQUssR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7NEJBQ3hDLEtBQUssR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQzFDO3dCQUNELHFCQUFNLGdCQUFnQixHQUFHLElBQUksaUJBQWlCLENBQzFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFDOUIsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUM5QixXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQ2pDLENBQUU7d0JBQ0gsUUFBUSxDQUFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO3FCQUNuQztpQkFDSjthQUNKO1NBQ0o7UUFDRCxxQkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUV0RixxQkFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLGFBQWEsQ0FBQztRQUdwQyxxQkFBTSxhQUFhLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDaEQscUJBQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztRQUNwQyxxQkFBTSxRQUFRLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDMUMscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQztRQUNoRCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ2hELHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUMvQyxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFFakQscUJBQU0sT0FBTyxHQUFHLFlBQVksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO2FBQ3ZDLElBQUksQ0FBQyxRQUFRLENBQUM7YUFDZCxLQUFLLEVBQUU7YUFDUCxNQUFNLENBQUMsUUFBUSxDQUFDO2FBQ2hCLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFvQixFQUFFLENBQU07WUFDckMsT0FBTyxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUMxQixDQUFDO2FBQ0QsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFDLENBQW9CLEVBQUUsQ0FBTTtZQUNyQyxRQUFRLFNBQVMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFO1NBQ3ZELENBQUM7YUFDRCxJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBb0IsRUFBRSxDQUFNO1lBQ3BDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUNkLENBQUM7YUFDRCxLQUFLLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7WUFDN0IscUJBQU0sU0FBUyxHQUFHLENBQUMsR0FBRyxhQUFhLENBQUM7WUFDcEMsT0FBTyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7U0FDNUIsQ0FBQzthQUNELElBQUksQ0FBQyxjQUFjLEVBQUcsUUFBUSxDQUFDLENBQUM7O1FBSXpDLElBQUksYUFBYSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2Qjs7O1FBSUQsSUFBSSxjQUFjLEVBQUU7WUFDaEIscUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ3hELEtBQUsscUJBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7Z0JBQ2hELGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQzNFO1lBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7U0FDekM7OztRQUdELElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztRQUVyQixJQUFJLGFBQWEsRUFBRTtZQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDdkI7UUFDRCxJQUFJLGFBQWEsRUFBRTtZQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDdkI7Ozs7OztJQUtLLHVDQUFTOzs7O2NBQUMsUUFBYTtRQUU3QixPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7UUFFaEQscUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztRQUNyQixxQkFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUNsQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQztRQUV0QyxxQkFBTSxNQUFNLEdBQUksR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUU5QixxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUM1QixxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUNyQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUNyQyxxQkFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUNuQyxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7UUFDakQscUJBQU0sV0FBVyxHQUFHVSxXQUFjLEVBQUU7YUFDbkIsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQ2xCLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQztRQUNsRCxxQkFBTSxPQUFPLEdBQUdzQixLQUFRLENBQUMsTUFBTSxHQUFHLFlBQVksRUFDOUIsS0FBSyxHQUFJLFlBQVksRUFDckIsTUFBTSxHQUFHLFlBQVksQ0FBQyxDQUFDO1FBRXZDLFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ25CLFNBQVMsQ0FBQyxRQUFRLENBQUM7YUFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQzthQUNiLEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDZCxJQUFJLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQzthQUM3QixJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7WUFDMUIscUJBQU0sR0FBRyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxHQUFJLENBQUMsQ0FBQztZQUN4QyxPQUFPLEdBQUcsQ0FBQztTQUNkLENBQUM7YUFDRCxJQUFJLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQyxTQUFTLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDcEQsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO1lBQzFCLHFCQUFNLEdBQUcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksR0FBSSxDQUFDLENBQUM7WUFDeEMsT0FBTyxHQUFHLENBQUM7U0FDZCxDQUFDO2FBQ0QsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFDOzs7Ozs7SUFHM0Qsd0NBQVU7Ozs7Y0FBQyxRQUFhO1FBRTlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLENBQUMsQ0FBQztRQUVoRCxxQkFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDO1FBQ3JCLHFCQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO1FBQ2xDLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDO1FBRXRDLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDO1FBQzVCLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO1FBRXJDLHFCQUFNLFdBQVcsR0FBR3RCLFdBQWMsRUFBRTthQUNuQixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDbEIsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDO1FBRWxELFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ25CLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLGFBQWEsQ0FBQzthQUNoQyxJQUFJLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQzthQUM5QyxJQUFJLENBQ0N1QixVQUFhLENBQUMsV0FBVyxDQUFDLENBQy9CLENBQUM7Ozs7Ozs7Ozs7Ozs7SUFRQSxzQ0FBUTs7Ozs7Ozs7Y0FBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7UUFFeEcsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO1FBRTVDLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7UUFDbEIscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUNsQixxQkFBTSxHQUFHLEdBQUcsSUFBSSxRQUFRLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUV0RixxQkFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLGdCQUFnQixDQUFDO1FBR3BDLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO1FBR3JDLHFCQUFNLFFBQVEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUMxQyxxQkFBTSxZQUFZLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7UUFDN0MscUJBQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQzNDLHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztRQUN6QyxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7UUFDL0MscUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQ2pELHFCQUFNLG1CQUFtQixHQUFHLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztRQUNuRCxxQkFBTSx3QkFBd0IsR0FBRyxHQUFHLENBQUMsdUJBQXVCLENBQUM7UUFDN0QscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO1FBQy9DLHFCQUFNLGtCQUFrQixHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO1FBQ3ZELHFCQUFNLHVCQUF1QixHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDO1FBQ25FLHFCQUFNLDZCQUE2QixHQUFHLEdBQUcsQ0FBQyw0QkFBNEIsQ0FBQztRQUN2RSxxQkFBTSxpQkFBaUIsR0FBRyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7UUFDL0MscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO1FBQy9DLHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztRQUNqRCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDL0MscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUNuRCxxQkFBTSxlQUFlLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDO1FBQ3ZELHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUMvQyxxQkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUt6RCxxQkFBTSxPQUFPLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7UUFDM0MsS0FBSyxxQkFBTSxDQUFDLElBQU0sV0FBVyxDQUFDLElBQUksRUFBRTtZQUNoQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNwQyxxQkFBTSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ3ZDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7YUFDdEI7U0FDSjtRQUVELHFCQUFNLElBQUksR0FBR0MsR0FBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQzdCLHFCQUFNQyxNQUFHLEdBQUdDLEdBQU0sRUFBRSxDQUFDO1FBQ3JCLHFCQUFNQyxNQUFHLEdBQUdDLEdBQU0sRUFBRTthQUNQLFdBQVcsQ0FBQyxZQUFZLEdBQUcsbUJBQW1CLEdBQUcsR0FBRyxDQUFDO2FBQ3JELFdBQVcsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDLENBQUM7UUFFM0MscUJBQU0sV0FBVyxHQUFHLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2FBQ3pCLElBQUksQ0FBQ0gsTUFBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO2FBQ2xCLEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDWCxJQUFJLENBQUMsV0FBVyxFQUFFLHdCQUF3QixDQUFDLENBQUM7UUFHckUscUJBQU0sZ0JBQWdCLEdBQUc7WUFDakIsSUFBSSxhQUFhLElBQUksZUFBZSxFQUFFO2dCQUNsQyxxQkFBTSxHQUFHLEdBQUcsaUJBQWlCLEdBQUcsR0FBRyxHQUFHLElBQUksR0FBSSxTQUFTLENBQUM7Z0JBQ3hELE9BQU8sR0FBRyxDQUFDO2FBQ2Q7WUFDRCxJQUFJLGVBQWUsRUFBRTtnQkFDakIsT0FBTyxNQUFNLENBQUM7YUFDakI7WUFDRCxJQUFJLGFBQWEsRUFBRTtnQkFDZixPQUFPLGlCQUFpQixHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7YUFDekM7U0FDUixDQUFDO1FBRUYscUJBQU0sWUFBWSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ3ZCLElBQUksQ0FBQyxPQUFPLEVBQUUsdUJBQXVCLENBQUM7YUFDdEMsSUFBSSxDQUFDLFdBQVcsRUFBRSw2QkFBNkIsQ0FBRTthQUNqRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUVoRCxxQkFBTSxJQUFJLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDMUIsSUFBSSxDQUFDLE9BQU8sRUFBRSxhQUFhLENBQUM7YUFDNUIsS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO1lBQzdCLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3BCLENBQUM7YUFDRCxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7UUFzQjVDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFRSxNQUFHLENBQUMsQ0FBQztRQUVwQixXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNiLElBQUksQ0FBQyxPQUFPLEVBQUUsa0JBQWtCLENBQUM7YUFDakMsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO1lBQ3JDLE9BQU8sWUFBWSxHQUFHQSxNQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUMzQyxDQUFDO2FBQ0QsSUFBSSxDQUFDLFVBQUMsQ0FBTSxFQUFFLENBQVM7WUFDcEIsSUFBSSxhQUFhLElBQUksZUFBZSxFQUFFO2dCQUNsQyxxQkFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLEdBQUksR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDNUQscUJBQU0sR0FBRyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxHQUFHLFVBQVUsR0FBRyxJQUFJLENBQUM7Z0JBQ3ZELE9BQU8sR0FBRyxDQUFDO2FBQ2Q7WUFDRCxJQUFJLGVBQWUsRUFBRTtnQkFDakIscUJBQU0sVUFBVSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSSxHQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUM7Z0JBQzVELHFCQUFNLEdBQUcsR0FBRyxVQUFVLEdBQUcsR0FBRyxDQUFDO2dCQUM3QixPQUFPLEdBQUcsQ0FBQzthQUNkO1lBQ0QsSUFBSSxhQUFhLEVBQUU7Z0JBQ2YsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDO2FBQ2xCO1NBQ0osQ0FBQyxDQUFDOztRQUdmLElBQUksYUFBYSxFQUFFO1lBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztTQUN2Qjs7O1FBSUQsSUFBSSxjQUFjLEVBQUU7WUFDaEIscUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ3hELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7Z0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0JBQ3BDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDOUU7YUFDSjtZQUNELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1NBQ3pDOzs7Ozs7Ozs7O0lBS0ssc0NBQVE7Ozs7Ozs7O2NBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBRXhHLE9BQU8sQ0FBQyxHQUFHLENBQUMsOEJBQThCLENBQUMsQ0FBQztRQUU1QyxxQkFBTSxTQUFTLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7UUFDN0MsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtZQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNwQyxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQkFDbkMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3pDLHFCQUFNLEVBQUUsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDcEMsU0FBUyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztxQkFDdEI7aUJBQ0o7YUFDSjtTQUNKO1FBRUQscUJBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztRQUNkLHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7UUFDZCxLQUFLLEdBQUd6QixHQUFNLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDMUIsS0FBSyxHQUFHLEdBQUcsQ0FBQztRQUNaLHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRXRGLHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUNyRCxxQkFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLGdCQUFnQixDQUFDO1FBQ3BDLHFCQUFNLFVBQVUsR0FBSSxXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUM5QyxxQkFBTSxVQUFVLEdBQUksU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUVyQyxxQkFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLGFBQWEsQ0FBQztRQUNwQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUNyQyxxQkFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUVuQyxxQkFBTSxRQUFRLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7UUFDMUMscUJBQU0sWUFBWSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBQzdDLHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUMvQyxxQkFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7UUFDM0MscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1FBQ3pDLHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUMvQyxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFDakQscUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO1FBQ2pELHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUMvQyxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO1FBQ2hELHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztRQUMvQyxxQkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztRQUV6RCxxQkFBTSxTQUFTLEdBQUcsQ0FBQyxXQUFXLElBQUksY0FBYyxHQUFHLFVBQVUsR0FBRyxVQUFVLENBQUMsSUFBSyxVQUFVLENBQUM7UUFDM0YscUJBQU0sWUFBWSxJQUFJLFdBQVcsR0FBRyxVQUFVLENBQUMsQ0FBRTtRQUVqRCxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUVyQyxxQkFBTSxTQUFTLEdBQUdGLFdBQWMsRUFBRTthQUNqQixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7YUFDbEIsS0FBSyxDQUFDLENBQUMsS0FBSyxHQUFHLFlBQVksRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRWxELHFCQUFNLFdBQVcsR0FBRyxjQUFjLENBQUM7UUFLbkMscUJBQU0sUUFBUSxHQUFHLFlBQVksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO2FBQ3ZDLElBQUksQ0FBQyxTQUFTLENBQUM7YUFDZixLQUFLLEVBQUU7YUFDUCxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ1gsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO1lBQ2pDLHFCQUFNLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLFVBQVUsTUFBTSxDQUFDLElBQUksV0FBVyxHQUFHLENBQUMsQ0FBQztZQUM1RCxPQUFPLFlBQVksSUFBSSxRQUFRLEdBQUcsWUFBWSxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztTQUM3RCxDQUFDO2FBQ0QsS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO1lBQzdCLHFCQUFNLFFBQVEsSUFBSSxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUM7WUFDbEMsT0FBTyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7U0FDM0IsQ0FBQzthQUNELElBQUksQ0FBQyxjQUFjLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFFcEMscUJBQU0sS0FBSyxHQUFJLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDdkMsSUFBSSxVQUFVLEVBQUU7WUFDWixLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxXQUFXLENBQUM7aUJBQzNCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO2lCQUNqQixJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTTtnQkFDZCxPQUFPLFNBQVMsQ0FBQzthQUNwQixDQUFDO2lCQUNELElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxHQUFHLFdBQVcsQ0FBQztpQkFDdEMsVUFBVSxFQUFFO2lCQUNaLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQztpQkFDNUIsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU07Z0JBQ2QsT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDO2FBQ25DLENBQUM7aUJBQ0QsSUFBSSxDQUFDLFFBQVEsRUFBRSxVQUFDLENBQU07Z0JBQ25CLE9BQU8sWUFBWSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBRTthQUN2QyxDQUFDLENBQUM7U0FDTjthQUFNO1lBQ0gsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDO2lCQUMzQixJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTTtnQkFDZCxPQUFPLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUM7YUFDbkMsQ0FBQztpQkFDRCxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsR0FBRyxXQUFXLENBQUM7aUJBQ3RDLElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBQyxDQUFNO2dCQUNuQixPQUFPLFlBQVksR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDdEMsQ0FBQyxDQUFDO1NBQ047UUFFRCxxQkFBTSxZQUFZLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUM3QyxZQUFZO2FBQ1AsSUFBSSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUM7YUFDN0IsSUFBSSxDQUFDLEdBQUcsRUFBRSxXQUFXLENBQUM7YUFDdEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU07WUFDaEIsT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDO1NBQ2pDLENBQUM7YUFDRCxJQUFJLENBQUMsVUFBQyxDQUFNO1lBQ1gsT0FBTyxDQUFDLENBQUU7U0FDWCxDQUFDLENBQUM7OztRQUlQLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7OztRQUlyQixJQUFJLGFBQWEsRUFBRTtZQUNmLHFCQUFNLFdBQVcsR0FBbUIsSUFBSSxLQUFLLEVBQUUsQ0FBQztZQUNoRCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO2dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO29CQUNwQyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQzNDO2FBQ0o7WUFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUVkLG1CQUE4QixDQUFDLENBQUM7U0FDekU7UUFFRCxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7UUFJeEIscUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO1FBQ3hELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxNQUFNLEVBQUU7WUFDaEMsSUFBSSxXQUFXLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDeEMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLFlBQVksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDekU7U0FDSjtRQUNELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDOzs7UUFJdEMsSUFBSSxhQUFhLEVBQUU7WUFDZixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3ZCO1FBRUQsSUFBSSxhQUFhLEVBQUU7WUFDZixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1NBQ3ZCOzs7Ozs7Ozs7O0lBS0ssdUNBQVM7Ozs7Ozs7O2NBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO1FBRXpHLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztRQUUvQyxxQkFBTSxVQUFVLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7UUFFOUMsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtZQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNwQyxxQkFBSSxNQUFNLEdBQUcsQ0FBQyxDQUFDO2dCQUNmLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO29CQUN2QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDN0MsSUFBSSxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUN6QyxNQUFNLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUMzQztxQkFDSjtpQkFDSjtnQkFDRCxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFFO2FBQzVCO1NBQ0o7UUFDRCxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQ2QscUJBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztRQUNkLEtBQUssR0FBR2dCLEdBQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMzQixLQUFLLEdBQUcsR0FBRyxDQUFDO1FBRVoscUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFDdEYscUJBQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztRQUVwQyxxQkFBTSxVQUFVLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFFO1FBQ3JELHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztRQUVqRCxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBRTFCLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFO1lBQzNCLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7U0FDdkI7O1FBR0QsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtZQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dCQUNwQyxxQkFBTSxVQUFVLEdBQXlCLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQ3JELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO29CQUN2QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDN0MscUJBQU0sT0FBTyxHQUFHLElBQUksYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ25GLFVBQVUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7cUJBQzVCO2lCQUNKO2dCQUNELHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO2dCQUM1QixJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxVQUFVLEVBQUUsR0FBRyxDQUFDLENBQUM7YUFDN0M7U0FDSjs7O1FBSUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O1FBSXBCLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLENBQUM7UUFFckIsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O1FBSXhCLHFCQUFNLFdBQVcsR0FBbUIsSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUNoRCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtZQUN2QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQkFDN0MsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNwRDtTQUNKO1FBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFakIsb0JBQStCLENBQUMsQ0FBQzs7O1FBSXZFLHFCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztRQUN4RCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO1lBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0JBQ3RDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUM1RTtTQUNKO1FBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7Ozs7Ozs7O0lBT2hDLDRDQUFjOzs7Ozs7Y0FBQyxRQUFhLEVBQUUsT0FBWSxFQUFFLE9BQWU7UUFFakUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDO1FBRXBELE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDckIscUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztRQUNyQixxQkFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUNsQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQztRQUV0QyxxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUM1QixxQkFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLGtCQUFrQixDQUFDO1FBQ3pDLHFCQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsa0JBQWtCLENBQUM7UUFDekMscUJBQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7UUFDbEMscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxVQUFVLElBQUksVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDO1FBQ3ZELHFCQUFNLE1BQU0sR0FBR0osWUFBZSxDQUFDRSxnQkFBbUIsQ0FBQyxDQUFDO1FBRXBELHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDOUUscUJBQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO1FBQzNDLHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztRQUUvQyxxQkFBTSxPQUFPLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUdoQyxxQkFBTThDLE9BQUksR0FBR0MsSUFBTyxFQUFFO2FBQ2pCLEtBQUssQ0FBQ0MsV0FBYyxDQUFDO2FBQ3JCLENBQUMsQ0FBRSxVQUFDLENBQU07WUFDUCxPQUFPLFdBQVcsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLFlBQVksQ0FBQztTQUM1QyxDQUFDO2FBQ0QsQ0FBQyxDQUFFLFVBQUMsQ0FBTTtZQUNQLE9BQU8sR0FBRyxDQUFDLFNBQVMsR0FBRyxhQUFhLElBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBRTtTQUNoRSxDQUFDLENBQUM7UUFFUCxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUNsQixJQUFJLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQzthQUM3QixJQUFJLENBQUMsR0FBRyxFQUFFRixPQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7SUFRNUIseUNBQVc7Ozs7O2NBQUMsUUFBYSxFQUFFLGNBQW1CO1FBRXBELE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQzs7UUFHakQscUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztRQUNyQixxQkFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUNsQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQzs7UUFFdEMscUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDO1FBQ25ELHFCQUFNLGFBQWEsR0FBRyxFQUFFLENBQUM7UUFDekIscUJBQU0sUUFBUSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO1FBQzVDLHFCQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsY0FBYyxDQUFDO1FBQ3BDLHFCQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsY0FBYyxDQUFDO1FBQ3BDLHFCQUFNLE9BQU8sR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztRQUV6QyxxQkFBTSxTQUFTLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDN0IsU0FBUyxDQUFDLEdBQUcsQ0FBQzthQUNkLElBQUksQ0FBQyxjQUFjLENBQUM7YUFDcEIsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNYLElBQUksQ0FBQyxPQUFPLEVBQUUsUUFBUSxDQUFDO2FBQ3ZCLElBQUksQ0FBQyxXQUFXLEVBQUUsVUFBQyxDQUFlLEVBQUUsQ0FBUztZQUMxQyxxQkFBTSxNQUFNLEdBQUcsY0FBYyxHQUFHLFFBQVEsQ0FBQztZQUN6QyxxQkFBTSxDQUFDLEdBQUcsUUFBUSxDQUFDO1lBQ25CLHFCQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxHQUFHLFFBQVEsQ0FBRTtZQUNqQyxPQUFPLFlBQVksR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLENBQUMsR0FBRyxHQUFHLENBQUM7U0FDNUMsQ0FBQyxDQUFDO1FBRWYsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDbkIsSUFBSSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUM7YUFDN0IsSUFBSSxDQUFDLFFBQVEsRUFBRSxjQUFjLENBQUM7YUFDOUIsS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQWU7WUFDM0IsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDO1NBQ2xCLENBQUM7YUFDRCxLQUFLLENBQUMsUUFBUSxFQUFFLFVBQUMsQ0FBZTtZQUM3QixPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7U0FDbEIsQ0FBQzthQUNELElBQUksQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFFbkMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDbkIsSUFBSSxDQUFDLEdBQUcsRUFBRSxjQUFjLEdBQUcsYUFBYSxDQUFDO2FBQ3pDLElBQUksQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDO2FBQ3pCLElBQUksQ0FBQyxVQUFDLENBQWU7WUFDbEIsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDO1NBQ2xCLENBQUMsQ0FBQzs7Ozs7Ozs7SUFJRCw0Q0FBYzs7Ozs7O2NBQUMsUUFBYSxFQUFFLFlBQWlCLEVBQUUsU0FBaUI7UUFFeEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDO1FBRXBELHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7UUFDckIscUJBQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7UUFDbEMscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7O1FBR3RDLHFCQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsa0JBQWtCLENBQUM7UUFDekMscUJBQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztRQUV6QyxxQkFBTSxVQUFVLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQztRQUN2QyxxQkFBSSxZQUFZLEdBQUcsR0FBRyxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7UUFDL0MsSUFBSyxTQUFTLEtBQUs1QyxvQkFBK0IsRUFBRTtZQUNoRCxZQUFZLEdBQUcsR0FBRyxDQUFDLFVBQVUsSUFBSSxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUM7U0FDcEQ7UUFFRCxxQkFBTSxRQUFRLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7YUFDNUIsU0FBUyxDQUFDLEdBQUcsQ0FBQzthQUNkLElBQUksQ0FBQyxZQUFZLENBQUM7YUFDbEIsS0FBSyxFQUFFO2FBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNYLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLFNBQVMsQ0FBQzthQUNuQyxJQUFJLENBQUMsV0FBVyxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7WUFDakMscUJBQU0sRUFBRSxHQUFHLFNBQVMsR0FBRyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1lBQ3hDLHFCQUFNLEVBQUUsR0FBRyxTQUFTLENBQUU7WUFDdEIsT0FBTyxZQUFZLEdBQUcsRUFBRSxHQUFHLElBQUksR0FBRyxFQUFFLEdBQUcsR0FBRyxDQUFDO1NBQzlDLENBQUMsQ0FBQztRQUVmLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ1YsSUFBSSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQzthQUM3QyxJQUFJLENBQUMsVUFBQyxDQUFNLEVBQUUsQ0FBUztZQUNwQixPQUFPLENBQUMsQ0FBQztTQUNaLENBQUMsQ0FBQzs7Ozs7O0lBTVQsMkNBQWE7Ozs7Y0FBQyxRQUFhO1FBRWpDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLENBQUMsQ0FBQztRQUVuRCxxQkFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDO1FBQ3JCLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDO1FBRXRDLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2FBQ3RCLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLHdCQUF3QixDQUFDO2FBQzNDLElBQUksQ0FBQyxPQUFPLEVBQUUsR0FBRyxDQUFDLGdCQUFnQixDQUFDO2FBQ25DLElBQUksQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLG9CQUFvQixDQUFDO2FBQ3hDLElBQUksQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUM7Ozs7OztJQVE5Qyx3Q0FBVTs7OztjQUFDLFFBQWE7UUFFOUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO1FBRWhELHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7UUFDckIscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7UUFFdEMscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUM7UUFDNUIscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7UUFFckMscUJBQU0sV0FBVyxHQUFHZSxXQUFjLEVBQUU7YUFDbkIsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO2FBQ2xCLEtBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUVsRCxZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzthQUNuQixJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxhQUFhLENBQUM7YUFDaEMsSUFBSSxDQUFDLFdBQVcsRUFBRSxHQUFHLENBQUMsZ0JBQWdCLENBQUM7YUFDdkMsSUFBSSxDQUNDZ0MsUUFBVyxDQUFDLFdBQVcsQ0FBQyxDQUN2QixDQUFDOzs7Ozs7SUFPTix1Q0FBUzs7OztjQUFDLFFBQWE7UUFFN0IsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO1FBRS9DLHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7UUFDckIscUJBQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7UUFDbEMscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7UUFFdEMscUJBQU0sTUFBTSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO1FBQ3JDLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsYUFBYSxDQUFDO1FBQ2hDLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsYUFBYSxDQUFDO1FBQ2hDLHFCQUFNLGVBQWUsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQztRQUVuRCxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzthQUN0QixJQUFJLENBQUMsT0FBTyxFQUFFLGVBQWUsQ0FBQzthQUM5QixJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQzthQUNoQixJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQzthQUNoQixJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7Ozs7OztJQU9aLHVDQUFTOzs7O2NBQUMsUUFBYTtRQUU3QixPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7UUFFaEQscUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztRQUNyQixxQkFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztRQUNsQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQztRQUV0QyxxQkFBTSxNQUFNLEdBQUksR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUM5QixxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQztRQUM1QixxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztRQUNyQyxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUM7UUFDakQscUJBQU0sT0FBTyxHQUFHVixLQUFRLENBQUMsTUFBTSxHQUFHLFlBQVksRUFDOUIsS0FBSyxHQUFHLFlBQVksRUFDcEIsTUFBTSxHQUFHLFlBQVksQ0FBQyxDQUFDO1FBRXZDLFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2FBQ25CLFNBQVMsQ0FBQyxRQUFRLENBQUM7YUFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQzthQUNiLEtBQUssRUFBRTthQUNQLE1BQU0sQ0FBQyxNQUFNLENBQUM7YUFDZCxJQUFJLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQzthQUM3QixJQUFJLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO2FBQ2xDLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBRSxDQUFNLEVBQUUsQ0FBUztZQUMzQixxQkFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFDekQsT0FBTyxHQUFHLENBQUM7U0FDZCxDQUFDO2FBQ0QsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksR0FBRyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7YUFDekQsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFFLENBQU0sRUFBRSxDQUFTO1lBQzNCLHFCQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztZQUN6RCxPQUFPLEdBQUcsQ0FBQztTQUNkLENBQUMsQ0FBQzs7O2dCQWhxRFIsU0FBUyxTQUFDO29CQUNULFFBQVEsRUFBRSxnQkFBZ0I7b0JBQzFCLFFBQVEsRUFBRSxFQUFFO29CQUNaLE1BQU0sRUFBRSxFQUFFO2lCQUNYOzs7O2dCQVhvRCxVQUFVOzs7NEJBYTVELEtBQUs7MkJBQ0wsS0FBSzs0QkFDTCxLQUFLOzRCQUNMLEtBQUs7NkJBQ0wsS0FBSzs7OEJBakJSOzs7Ozs7O0FDQUE7Ozs7Z0JBR0MsUUFBUSxTQUFDO29CQUNSLE9BQU8sRUFBRSxFQUNSO29CQUNELFlBQVksRUFBRSxDQUFDLG1CQUFtQixDQUFDO29CQUNuQyxPQUFPLEVBQUUsQ0FBQyxtQkFBbUIsQ0FBQztpQkFDL0I7OzJCQVJEOzs7Ozs7Ozs7Ozs7Ozs7In0=