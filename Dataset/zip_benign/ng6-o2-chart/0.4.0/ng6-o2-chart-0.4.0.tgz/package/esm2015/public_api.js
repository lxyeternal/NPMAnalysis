/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/*
 * Public API Surface of ng6-o2-chart
 */
export { LINE_CHART_TYPE_NAME, BAR_CHART_TYPE_NAME, PIE_CHART_TYPE_NAME, SCATTER_PLOT_CHART_TYPE_NAME, HISTOGRAM_CHART_TYPE_NAME, STACK_BAR_CHART_TYPE_NAME, GEO_MAP_CHART_TYPE_NAME, GEO_ORTHOGRAPHIC_CHART_TYPE_NAME, TREE_MAP_CHART_TYPE_NAME, PACK_LAYOUT_CHART_TYPE_NAME, CHOROPLETH_CHART_TYPE_NAME, TREE_CHART_TYPE_NAME, SANKEY_CHART_TYPE_NAME, FORCE_CHART_TYPE_NAME } from './lib/shared/chart-const';
export { Ng6O2ChartComponent } from './lib/ng6-o2-chart.component';
export { Ng6O2ChartModule } from './lib/ng6-o2-chart.module';

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL25nNi1vMi1jaGFydC8iLCJzb3VyY2VzIjpbInB1YmxpY19hcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUdBLHNYQUFjLDBCQUEwQixDQUFDO0FBQ3pDLG9DQUFjLDhCQUE4QixDQUFDO0FBQzdDLGlDQUFjLDJCQUEyQixDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFB1YmxpYyBBUEkgU3VyZmFjZSBvZiBuZzYtbzItY2hhcnRcbiAqL1xuZXhwb3J0ICogZnJvbSAnLi9saWIvc2hhcmVkL2NoYXJ0LWNvbnN0JztcbmV4cG9ydCAqIGZyb20gJy4vbGliL25nNi1vMi1jaGFydC5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbmc2LW8yLWNoYXJ0Lm1vZHVsZSc7XG4iXX0=