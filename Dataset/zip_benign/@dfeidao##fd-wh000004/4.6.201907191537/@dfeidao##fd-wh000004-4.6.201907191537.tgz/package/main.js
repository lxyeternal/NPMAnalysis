define("index", ["require", "exports", "dot"], function (require, exports, dot_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    const no = 'fd-wh000004';
    const style = `
<style>
:host {
	z-index:-1;
	height:inherit;
	user-select: none;
}
</style>
`;
    const print = `
<style>
.mask_item {
	display: none;
}
@media print {
	.mask_item {
		display: block;
	}
}
</style>`;
    const c_tpl = `
{{~it.arr:v1:i}}
	{{~v1:v2:j}}
		<div class="mask_item" style="

		transform:rotate(-{{=it.settings['angle']}}deg);
		-webkit-transform:rotate(-{{=it.settings['angle']}}deg);
		-moz-transform:rotate(-{{=it.settings['angle']}}deg);
		-ms-transform:rotate(-{{=it.settings['angle']}}deg);
		-o-transform:rotate(-{{=it.settings['angle']}}deg);

		position:absolute;
		left:{{=it.settings['x'] + (it.settings['width'] + it.settings['x-space']) * j}}px;
		top:{{=it.settings['y'] + (it.settings['y-space'] + it.settings['height']) * i}}px;
		overflow:hidden;
		z-index:-1;
		opacity:{{=it.settings['alpha']}};
		font-size:{{=it.settings['fontsize']}};
		font-family:{{=it.settings['font']}};
		color:{{=it.settings['color']}};
		text-align=center;
		width:{{=it.settings['width']}}px;
		height:{{=it.settings['height']}}px;
		">{{=it.settings['txt']}}</div>
	{{~}}
{{~}}
`;
    class WaterMask extends HTMLElement {
        constructor() {
            super();
            const dom = this.dom = this.attachShadow({ mode: 'closed' });
            dom.innerHTML = style;
        }
        async connectedCallback() {
            this.refresh();
        }
        refresh() {
            const dom = this.dom;
            const settings = {
                'cols': 40,
                'rows': 20,
                'x': 40,
                'x-space': 0,
                'y': 0,
                'y-space': 0
            };
            const attrs = ['txt', 'color', 'alpha', 'fontsize', 'font', 'width', 'height', 'angle'];
            const complete = attrs.every((attr) => {
                const v = judge_number(this.getAttribute(attr));
                if (v === false) {
                    return false;
                }
                else {
                    settings[attr] = v;
                    return true;
                }
            });
            if (!complete) {
                throw new Error(`请检查属性是否齐全: ${attrs}`);
            }
            const full = get_boolean_attribute(this, 'full');
            const { width, height } = (() => {
                if (full) {
                    return { width: window.screen.width, height: window.screen.height };
                }
                else {
                    return this.getBoundingClientRect();
                }
            })();
            if (settings.cols === 0 || (settings.x + settings.width * settings.cols + settings['x-space'] * (settings.cols - 1) > width)) {
                settings.cols = (width - settings.x + settings['x-space']) / (settings.width + settings['x-space']);
                settings['x-space'] = (width - settings.x - settings.width * settings.cols) / (settings.cols - 1);
            }
            if (settings.rows === 0 || (settings.y + settings.height * settings.rows + settings['y-space'] * (settings.rows - 1) > height)) {
                settings.rows = (settings['y-space'] + height - settings.y) / (settings.height + settings['y-space']);
                settings['y-space'] = ((height - settings.y) - settings.height * settings.rows) / (settings.rows - 1);
            }
            const arr = new Array(Math.ceil(settings.rows)).fill(0).map(() => {
                return new Array(Math.ceil(settings.cols)).fill(0);
            });
            const p_data = { arr, settings };
            const renderedTpl = dot_1.template(c_tpl)(p_data);
            const _print = get_boolean_attribute(this, 'print');
            if (_print) {
                dom.innerHTML = style + print + renderedTpl;
            }
            else {
                dom.innerHTML = style + renderedTpl;
            }
        }
    }
    exports.default = WaterMask;
    function judge_number(str) {
        if (str === null) {
            return false;
        }
        const flag = /^(0|[1-9][0-9]*|-[1-9][0-9]*)$/.test(str);
        if (flag) {
            return parseInt(str, 10);
        }
        else {
            return str;
        }
    }
    function get_boolean_attribute(node, attribute) {
        if (node.hasAttribute(attribute)) {
            const value = node.getAttribute(attribute);
            if (value) {
                return value.toLocaleLowerCase() !== 'false';
            }
            else {
                return true;
            }
        }
        else {
            return false;
        }
    }
    if (!window.customElements.get(no)) {
        window.customElements.define(no, WaterMask);
    }
});
