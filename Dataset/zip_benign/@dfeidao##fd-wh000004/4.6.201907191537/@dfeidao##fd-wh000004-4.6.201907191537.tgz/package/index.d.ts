export default class WaterMask extends HTMLElement {
    private dom;
    constructor();
    connectedCallback(): Promise<void>;
    private refresh;
}
