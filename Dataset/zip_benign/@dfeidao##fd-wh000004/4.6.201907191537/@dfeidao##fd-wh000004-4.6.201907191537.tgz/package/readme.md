# 水印

<https://dfeidao.gitee.io/widgets/>

## `一、Installation`

```sh
yarn add --dev @dfeidao/fd-wh000004
```

## `二、配置`

gulpfile添加引用配置

```txt
{
	name: 'dot',
	location: './dot',
	main: 'doT.js'
},{
	name: '@dfeidao/fd-w000026',
	location: '@dfeidao/fd-w000026'
}
```

## `三、属性`

属性|默认值|类型|示例|描述
--|--|--|--|--
txt|-|string| txt='水印内容'  |水印文本内容
color|-|string| color='#a09696' |水印字体颜色
alpha|-| 0～1 | alpha='0.25' |水印透明度
fontsize|-|string| fontsize='20px' |水印字体大小
font|-| font-family | font='微软雅黑' |水印字体
width|-|number| width='300' |单个水印宽度
height|-|number| height='200' |单个水印长度
angle|-| 0～360 | angle='15' |水印倾斜度数
full|-| boolean | full=true |如果具有该属性，水印全屏显示
print|-| boolean | print=true |打印网页时显示水印

## `四、使用示例`

```html
<fd-w000026 data-feidao-id="widget" style="width: 600px;height:400px;position: absolute;top:0;left:0;" txt='飞道' color='red' alpha='0.5' fontsize='24px' font='宋体' width='100'
		height='100' angle='30' full print ></fd-w000026>
```

## ChangeLogs

## latest

修复全屏水印右侧空白过大问题

### 4.6.201907131632
