# zx-debug

Web移动端开发，模拟控制台。为公司的Hybrid而生...

Analog console, for Web mobile terminal development

## install

```
# 安装依赖
npm install
# 开发模式
npm run dev
# 生产模式
npm run build
```

```
// localhost可换成你本地ip地址
http://localhost:9000
```

![zx-debug](preview.png)

## USE

```
npm i zx-debug -D
```

#### ES6+

```
import { ZxDebug } from 'zx-debug'
```

#### browser

```
<script src="./dist/js/zx-debug.min.js"></script>
```


#### example

```
const zxDebug = new ZxDebug({
  // 固定位置，支持'top', 'bottom'
  position: 'top',
  // 偏移量，单位像素
  offset: 60,
  // debug高度，屏幕高度比例，范围(0, 1]
  // 大于1时, 将被作为像素处理，最小高度100
  height: 0.4,
  // debug标题
  title: 'Debug View',
  // 背景透明度
  opacity: 0.7,
  // 显示debug开关。
  // 为false时，可以通过其他点击事件调用show()/hide()方法，显示隐藏debug
  showSwitch: true
})

// log
zxDebug.log('title', 'message');

// warn
zxDebug.warn('message');

// error
zxDebug.error('title', 'message');
```

## methods

* log()

  日志输出

* warn()

  警告输出

* error()

  错误输出

* show()

  显示debug

* hide()

  隐藏debug

* clear()

  清空debug列表

## Copyright and license

Code and documentation copyright 2018. capricorncd. Code released under the MIT License.
