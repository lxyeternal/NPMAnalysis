export default {
  /**
   * 转换为整数
   * @param n
   * @returns {*}
   */
  int (n) {
    let num = parseInt(n)
    return isNaN(num) ? 0 : num
  },
  /**
   * 将伪数组，转换为数组
   * @param pseudoArray 伪数组
   * @returns {*}
   */
  slice (pseudoArray, index = 0) {
    if (pseudoArray.length && pseudoArray[0]) {
      return Array.prototype.slice.call(pseudoArray, index)
    }
    return []
  },
  /**
   * 判断o是否为对象{}
   * @param o
   * @returns {*|boolean}
   */
  isObject (o) {
    return o && typeof o === 'object' && !this.isArray(o)
  },

  /**
   * isArray
   * @param a array
   * @returns {*|boolean}
   */
  isArray (a) {
    return a && a instanceof Array
  }
}
