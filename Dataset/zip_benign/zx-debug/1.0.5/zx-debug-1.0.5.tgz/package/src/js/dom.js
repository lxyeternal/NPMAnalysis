import util from './util'
// Production steps of ECMA-262, Edition 5, 15.4.4.18
// Reference: http://es5.github.io/#x15.4.4.18
if (!Array.prototype.forEach) {

  Array.prototype.forEach = function(callback, thisArg) {

    let T, k

    if (this === null) {
      throw new TypeError(' this is null or not defined')
    }

    // 1. Let O be the result of calling toObject() passing the
    // |this| value as the argument.
    let O = Object(this)

    // 2. Let lenValue be the result of calling the Get() internal
    // method of O with the argument "length".
    // 3. Let len be toUint32(lenValue).
    let len = O.length >>> 0

    // 4. If isCallable(callback) is false, throw a TypeError exception.
    // See: http://es5.github.com/#x9.11
    if (typeof callback !== 'function') {
      throw new TypeError(callback + ' is not a function')
    }

    // 5. If thisArg was supplied, let T be thisArg; else let
    // T be undefined.
    if (arguments.length > 1) {
      T = thisArg
    }

    // 6. Let k be 0
    k = 0

    // 7. Repeat, while k < len
    while (k < len) {

      let kValue

      // a. Let Pk be ToString(k).
      //    This is implicit for LHS operands of the in operator
      // b. Let kPresent be the result of calling the HasProperty
      //    internal method of O with argument Pk.
      //    This step can be combined with c
      // c. If kPresent is true, then
      if (k in O) {

        // i. Let kValue be the result of calling the Get internal
        // method of O with argument Pk.
        kValue = O[k]

        // ii. Call the Call internal method of callback with T as
        // the this value and argument list containing kValue, k, and O.
        callback.call(T, kValue, k, O)
      }
      // d. Increase k by 1.
      k++
    }
    // 8. return undefined
  }
}

const d = document

export default {
  /**
   * 创建Vdom
   * @param vnode
   * @returns {*}
   */
  createVdom (vnode) {
    if (!vnode) return null
    if (typeof vnode === 'string') {
      return d.createTextNode(vnode)
    }
    let tag = vnode.tag
    let attrs = vnode.attrs
    let child = vnode.child
    if (!tag && !attrs && !child) return null
    // 创建dom
    const $el = this.createElm(vnode.tag || 'div', vnode.attrs)
    if (util.isArray(child) && child.length) {
      let $itemNode
      for (let i = 0; i < child.length; i++) {
        $itemNode = this.createVdom(child[i])
        if ($itemNode) $el.appendChild($itemNode)
      }
    } else if (child && typeof child === 'string') {
      $el.appendChild(d.createTextNode(child))
    }
    return $el
  },
  /**
   * 创建DOM元素
   * @param tag 标签名称
   * @param opts 标签属性
   * @returns {Element}
   */
  createElm (tag = 'div', opts) {
    let elm = d.createElement(tag)
    if (opts && opts instanceof Object) {
      for (let key in opts) {
        if (opts.hasOwnProperty(key)) {
          elm.setAttribute(key, opts[key])
        }
      }
    }
    return elm
  },
  /**
   * dom节点选择器
   * @param selector 元素id、class、属性等
   * @param context 作用域，默认为documet
   * @returns {*}
   */
  query (selector, context = d) {
    if (typeof d.querySelector === 'function') {
      return context.querySelector(selector)
    }
    const result = dom.queryAll(selector, context)
    return result.length > 0 ? result[0] : null
  },

  queryAll (selector, context = d) {
    if (typeof d.querySelectorAll === 'function') {
      return util.slice(context.querySelectorAll(selector))
    }
    // 查询结果
    let result = []
    // 被查找到的元素
    let $item
    // id选择器
    if (/^#\w+$/.test(selector)) {
      $item = context.getElementById(selector)
      if ($item) {
        result.push($item)
      }
    }
    // className, tag
    else {
      const nodes = context.getElementsByTagName('*')
      const len = nodes.length
      // className
      if (/^\.(\w+)$/.test(selector)) {
        let word = RegExp.$1
        for (let i = 0; i < len; i++) {
          $item = nodes[i]
          if ($item.nodeType === 1 && xmq.hasClass(word, $item)) {
            result.push($item)
          }
        }
      }
      // tag
      else {
        let tag = selector.toUpperCase()
        for (let j = 0; j < len; j++) {
          $item = nodes[j]
          if ($item.nodeName === tag) {
            result.push($item)
          }
        }
      }
    }
    return result
  },

  /**
   * 事件绑定
   * @param $el
   * @param eventName 事件名称
   * @param handler 事件处理函数
   * @param useCapture 是否在冒泡阶段
   */
  addEvent ($el, eventName, handler, useCapture = false) {
    if (!$el || !eventName || !handler) return
    if ($el.length) {
      for (let i = 0; i < $el.length; i++) {
        addEventListener($el[i], eventName, handler, useCapture)
      }
    } else {
      addEventListener($el, eventName, handler, useCapture)
    }
  },
  removeEvent ($el, eventName, handler, useCapture = false) {
    if (!$el || !eventName || !handler) return
    if ($el.length) {
      for (let i = 0; i < $el.length; i++) {
        removeEventListener($el[i], eventName, handler, useCapture)
      }
    } else {
      removeEventListener($el, eventName, handler, useCapture)
    }
  }
}

function addEventListener ($el, eventType, fn, useCapture) {
  if ($el.addEventListener) {
    $el.addEventListener(eventType, fn, useCapture)
  } else if ($el.attachEvent) {
    $el.attachEvent(eventType, fn)
  } else {
    $el[`on${eventType}`] = fn
  }
}

function removeEventListener ($el, eventType, fn, useCapture) {
  if ($el.removeEventListener) {
    $el.removeEventListener(eventType, fn, useCapture)
  } else if ($el.detachEvent) {
    $el.detachEvent(eventType, fn)
  } else {
    $el[`on${eventType}`] = null
  }
}
