'use strict';
const nodemark = require('nodemark');
const negotiated = require('.');
const Negotiator = require('negotiator');
const benchmark = (n, f) => console.log(`${n} x ${nodemark(f, typeof setup === 'function' ? setup : undefined).toString('nanoseconds')}`);

let result, header, request;
const sort = (a, b) => b.weight - a.weight;
const setup = () => {
	// header = Buffer.from('gzip, deflate, br').toString();
	// header = Buffer.from('en-US,en;q=0.9').toString();
	header = Buffer.from('text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8').toString();
	request = { headers: { 'accept': header } };
};

benchmark('ours', () => {
	result = [...negotiated.mediaTypes(header)].sort(sort);
});
benchmark('theirs', () => {
	result = new Negotiator(request).mediaTypes();
});
console.log(String(result).replace(/[^~]/g, ''));
