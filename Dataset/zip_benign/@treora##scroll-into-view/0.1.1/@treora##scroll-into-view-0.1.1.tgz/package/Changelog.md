# Changelog for scroll-into-view

## 0.1.1 (2019-02-06)

- Prevent module is undefined error from being thrown (thanks to adamreisnz)
- Take thickness of scrollbars into account. (thanks to vithmel)

## 0.1.0 (2016-03-10)

- Initial implementation.
