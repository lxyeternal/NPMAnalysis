# projmate-grunt-consolidate

Compiles templates using [consolidate](https://github.com/visionmedia/consolidate.js)
into HTML.


## Getting Started

If you haven't used [grunt](http://gruntjs.com/) before,
be sure to check out the [Getting Started][] guide.

To install this plugin

```shell
npm install projmate-grunt-consolidate --save-dev

```

You must also install any engine library, for example to use the `dust` engine

```shell
npm install dustjs-linkedin --save-dev
```

[grunt]: http://gruntjs.com/
[Getting Started]: https://github.com/gruntjs/grunt/blob/devel/docs/getting_started.md


## Tasks

This plugin registers all `consolidate` engines as `grunt` tasks.

Run any engine like so `grunt ENGINE`.

Files and options should be specified according to the [multi task][] documentation.

Version `0.4.x` of this plugin is compatible with Grunt `0.4.x`.

[multi task]: https://github.com/gruntjs/grunt/wiki/Configuring-tasks


### Usage Examples

Compile all dust files in `src/` to `generated/` using relative paths, excluding
files and directories that start with underscore character.

```js
grunt.initConfig({
  dust: {
    // Consolidate engine options
    options: {
      views: __dirname + 'test/fixtures',
    },

    compile: {
      files: [{
        expand: true,
        cwd: 'src/',
        src: ['**/*.dust'],
        dest: 'generated/',
        ext: '.html',

        // ignore underscored directories or files
        filter: function(srcFile) {
          return !/\/_/.test(srcFile);
        }
      }],

      // locals
      options: {
        data: {
          title: 'My Front Page'
        }
      }
    }
  }
});

```

## Release History

