/**
 * Copyright (c) 2013 Mario Gutierrez mario@mgutz.com
 */
'use strict';


/**
 * Gets all engines supported by consolidate.
 *
 * @param  {Object} consolidate The consolidate instance.
 * @return {Array[String]} The engine names.
 */
function getEngines(consolidate) {
  var engines = [];
  var val;
  Object.keys(consolidate).forEach(function(key) {
    val = consolidate[key];
    if (typeof val === 'function' && val.render) {
      engines.push(key);
    }
  });
  return engines;
}


/**
 * Registers a MultiTask for each engine.
 *
 * @param  {Object} grunt Grunt object.
 * @return {Undefined}
 */
module.exports = function(grunt) {
  var consolidate = require('consolidate');
  var async = grunt.util.async;
  var _ = grunt.util._;
  var eol = grunt.util.normalizelf(grunt.util.linefeed);
  var log = grunt.log;

  // Register each engine as a multi task
  Object.keys(consolidate).forEach(function(name) {
    var engine = consolidate[name];
    if (typeof engine === 'function' && engine.render) {
      grunt.registerMultiTask(name, 'Compiles ' + name +' template files into HTML.', consolidateTask(name));
    }
  });

  function consolidateTask(engine) {
    return function() {
      var options = this.options();
      var done = this.async();

      function compileFile(f, cb) {
        var output = null;

        // f.src is a getter which expands the original src into an array of files
        async.forEach(f.src, function(file, cb) {
          compile(file, options, function(err, result) {
            if (err) return cb(err);

            // add end of line between each line
            output = output ? (output + eol + result) : result;
            cb();
          })
        }, function(err) {
          if (err) return cb(err);

          if (!output || output.length < 1) {
            log.warn('Destination not written because compiled files were empty.');
          }
          else {
            grunt.file.write(f.dest, output);
            log.writeln('File ' + f.dest.cyan + ' created.');
          }
          cb();
        });
      }

      grunt.verbose.writeflags(options, 'Options');

      async.forEach(this.files, compileFile, function(err) {
        if (err) grunt.fail.warn(err);

        done(err);
      });
    };


    /**
     * Compile the file using current engine.
     *
     * @param srcFile
     * @param options
     * @param cb
     */
    function compile(srcFile, options, cb) {
      // consolidate expects locals and options to be combined which is LAME
      var locals = _.clone(options);
      delete locals.data;
      locals = _.extend(locals, options.data);

      consolidate[engine](srcFile, locals, function(err, result) {
        if (err) log.warn('Consolidate.' + engine + ' failed to compile: ' + srcFile);
        cb(err, result);
      });
    }
  }
};
