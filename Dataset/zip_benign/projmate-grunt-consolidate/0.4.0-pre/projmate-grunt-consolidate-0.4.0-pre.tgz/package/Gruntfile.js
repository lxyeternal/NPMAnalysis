/*
 * grunt-contrib-jade
 * http://gruntjs.com/
 *
 * Copyright (c) 2012 Eric Woroshow, contributors
 * Licensed under the MIT license.
 */

'use strict';

module.exports = function(grunt) {

  // break config into plugins, isolates typo errors
  var config = {};

  config.jshint = {
    all: [
      'Gruntfile.js',
      'tasks/*.js',
      '<%= nodeunit.tests %>'
    ],
    options: {
      jshintrc: '.jshintrc'
    }
  };

  // Before generating any new files, remove any previously-created files.
  config.clean = {
    test: ['tmp']
  };


  // Configuration to be run (and then tested).
  config.dust = {
    options: {
      views: __dirname + '/test/fixtures'
    },

    compile: {
      files: [{
        expand: true,
        cwd: 'test/fixtures/',
        src: ['**/*.dust'],
        dest: 'tmp/',
        ext: '.html',

        // ignore underscored directories or files
        filter: function(srcFile) {
          return !/\/_/.test(srcFile);
        }
      }],
      options: {
        data: {
          title: 'DUST!'
        }
      }
    }
  };

   // Configuration to be run (and then tested).
  config.jade = {
    compile: {
      files: {
        'tmp/jade.html': ['test/fixtures/jade.jade'],
        'tmp/jade2.html': ['test/fixtures/jade2.jade'],
        'tmp/jadeInclude.html': ['test/fixtures/jadeInclude.jade'],
        'tmp/jadeTemplate.html': ['test/fixtures/jadeTemplate.jade']
      },
      options: {
        data: {
          test: true,
          year: '<%= grunt.template.today("yyyy") %>'
        }
      }
    }
  };

  // Unit tests.
  config.nodeunit = {
    tests: ['test/*_test.js']
  };


  // Actually load this plugin's task(s).
  grunt.loadTasks('tasks');

  // These plugins provide necessary tasks.
  grunt.loadNpmTasks('grunt-contrib-clean');
  grunt.loadNpmTasks('grunt-contrib-jshint');
  grunt.loadNpmTasks('grunt-contrib-nodeunit');
  grunt.loadNpmTasks('grunt-contrib-internal');

  // Project configuration.
  grunt.initConfig(config);

  // Whenever the "test" task is run, first clean the "tmp" dir, then run this
  // plugin's task(s), then test the result.
  grunt.registerTask('test', ['clean', 'jade', 'dust', 'nodeunit']);

  // By default, lint and run all tests.
  grunt.registerTask('default', ['jshint', 'test', 'build-contrib']);

};
