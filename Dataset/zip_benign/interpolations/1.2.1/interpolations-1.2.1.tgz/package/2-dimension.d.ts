export declare abstract class I2DimensionalInterpolation {
    from: number;
    to: number;
    constructor(from?: number, to?: number);
    /**
     * Interpolates between ```from``` and ```to```, the values ```fromValue``` and ```toValue``` with the given derivations at start and end.
     *
     * @param {number} x between ```from``` and ```to```
     * @returns {number}
     * @memberof HermiteInterpolation
     */
    eval(x: number): number;
    /**
     * Transforms the input in a relative from 0 to 1 between the boundary's from and to.
     *
     * @private
     * @param {number} x
     * @returns {number}
     * @memberof HermiteInterpolation
     */
    protected transformInput(x: number): number;
    abstract evalRelative(x: number): number;
}
