/**
 * Interpolation with Lagrange. Provide different x,y pairs, which the interpolation should use as base points.
 *
 * @export
 * @class Lagrange
 */
export declare class Lagrange {
    x: number[];
    y: number[];
    constructor(x: number[], y: number[]);
    eval(x: number): number;
    private f;
    private l;
}
