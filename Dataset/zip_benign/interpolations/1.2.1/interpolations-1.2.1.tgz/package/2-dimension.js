"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var I2DimensionalInterpolation = /** @class */ (function () {
    function I2DimensionalInterpolation(from, to) {
        if (from === void 0) { from = 0; }
        if (to === void 0) { to = 1; }
        this.from = from;
        this.to = to;
    }
    /**
     * Interpolates between ```from``` and ```to```, the values ```fromValue``` and ```toValue``` with the given derivations at start and end.
     *
     * @param {number} x between ```from``` and ```to```
     * @returns {number}
     * @memberof HermiteInterpolation
     */
    I2DimensionalInterpolation.prototype.eval = function (x) {
        return this.evalRelative(this.transformInput(x));
    };
    /**
     * Transforms the input in a relative from 0 to 1 between the boundary's from and to.
     *
     * @private
     * @param {number} x
     * @returns {number}
     * @memberof HermiteInterpolation
     */
    I2DimensionalInterpolation.prototype.transformInput = function (x) {
        return (x - this.from) / (this.to - this.from);
    };
    return I2DimensionalInterpolation;
}());
exports.I2DimensionalInterpolation = I2DimensionalInterpolation;
