import { I2DimensionalInterpolation } from './2-dimension';
export declare function lerp(start: number, end: number, alpha: number): number;
export declare class LinearInterpolation extends I2DimensionalInterpolation {
    fromValue: number;
    toValue: number;
    constructor(from?: number, to?: number, fromValue?: number, toValue?: number);
    /**
     * Interpolates between 0 and 1, the values ```fromValue``` and ```toValue``` with the given derivations at start and end.
     *
     * @param {number} x between 0 and 1
     * @returns {number}
     * @memberof HermiteInterpolation
     */
    evalRelative(x: number): number;
}
