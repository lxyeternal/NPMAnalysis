"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var _2_dimension_1 = require("./2-dimension");
function lerp(start, end, alpha) {
    var interpolation = new LinearInterpolation(0, 1, start, end);
    return interpolation.eval(alpha);
}
exports.lerp = lerp;
var LinearInterpolation = /** @class */ (function (_super) {
    __extends(LinearInterpolation, _super);
    function LinearInterpolation(from, to, fromValue, toValue) {
        if (from === void 0) { from = 0; }
        if (to === void 0) { to = 1; }
        if (fromValue === void 0) { fromValue = 0; }
        if (toValue === void 0) { toValue = 1; }
        var _this = _super.call(this, from, to) || this;
        _this.fromValue = fromValue;
        _this.toValue = toValue;
        return _this;
    }
    /**
     * Interpolates between 0 and 1, the values ```fromValue``` and ```toValue``` with the given derivations at start and end.
     *
     * @param {number} x between 0 and 1
     * @returns {number}
     * @memberof HermiteInterpolation
     */
    LinearInterpolation.prototype.evalRelative = function (x) {
        var deltaY = this.toValue - this.fromValue;
        return this.fromValue + x * deltaY;
    };
    return LinearInterpolation;
}(_2_dimension_1.I2DimensionalInterpolation));
exports.LinearInterpolation = LinearInterpolation;
