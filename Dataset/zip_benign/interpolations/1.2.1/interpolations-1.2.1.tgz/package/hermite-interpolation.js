"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var _2_dimension_1 = require("./2-dimension");
function smoothstep(min, max, t) {
    var interpolation = new HermiteInterpolation(0, 1, min, max, 0, 0);
    return interpolation.eval(t > 1 ? 1 : t < 0 ? 0 : t);
}
exports.smoothstep = smoothstep;
// Shorthand for math.pow
var pow = function (x, y) { return Math.pow(x, y); };
// Determined part functions of hermite-interpolation through equation system. 
var H0 = function (x) { return (2 * pow(x, 3)) - (3 * pow(x, 2)) + 1; };
var H1 = function (x) { return (-2 * pow(x, 3)) + (3 * pow(x, 2)); };
var H2 = function (x) { return (pow(x, 3)) - (2 * pow(x, 2)) + x; };
var H3 = function (x) { return pow(x, 3) - pow(x, 2); };
// derives of part functions
var H_0 = function (x) { return (6 * pow(x, 2)) - (6 * x); };
var H_1 = function (x) { return (-6 * pow(x, 2)) + (6 * x); };
var H_2 = function (x) { return 3 * pow(x, 2) - (4 * x) + 1; };
var H_3 = function (x) { return (3 * pow(x, 2)) - (2 * x); };
var HermiteInterpolation = /** @class */ (function (_super) {
    __extends(HermiteInterpolation, _super);
    /**
     * Creates an instance of HermiteInterpolation.
     * @param {number} [from=0] x value where the interpolation should start
     * @param {number} [to=1] x value where the interpolation should end
     * @param {number} [fromValue=0] y value where the interpolation should start
     * @param {number} [toValue=1] y value where the interpolation should end
     * @param {number} [fromDerivate=0] derivation which the interpolation should have at the start
     * @param {number} [toDerivate=0] derivation which the interpolation should have at the end
     * @memberof HermiteInterpolation
     */
    function HermiteInterpolation(from, to, fromValue, toValue, fromDerivate, toDerivate) {
        if (from === void 0) { from = 0; }
        if (to === void 0) { to = 1; }
        if (fromValue === void 0) { fromValue = 0; }
        if (toValue === void 0) { toValue = 1; }
        if (fromDerivate === void 0) { fromDerivate = 0; }
        if (toDerivate === void 0) { toDerivate = 0; }
        var _this = _super.call(this, from, to) || this;
        _this.fromValue = fromValue;
        _this.toValue = toValue;
        _this.fromDerivate = fromDerivate;
        _this.toDerivate = toDerivate;
        return _this;
    }
    /**
     * Interpolates between 0 and 1, the values ```fromValue``` and ```toValue``` with the given derivations at start and end.
     *
     * @param {number} x between 0 and 1
     * @returns {number}
     * @memberof HermiteInterpolation
     */
    HermiteInterpolation.prototype.evalRelative = function (x) {
        var y0 = this.fromValue;
        var y1 = this.toValue;
        var y_0 = this.fromDerivate;
        var y_1 = this.toDerivate;
        return y0 * H0(x) + y1 * H1(x) + y_0 * H2(x) + y_1 * H3(x);
    };
    /**
     * Return the derivate value from the interpolation function of ```eval```
     *
     * @param {number} x between ```from``` and ```to```
     * @returns {number}
     * @memberof HermiteInterpolation
     */
    HermiteInterpolation.prototype.evalDerivate = function (x) {
        return this.evalDerivateRelative(this.transformInput(x));
    };
    /**
     * Return the derivate value from the interpolation function of ```evalRelative```
     *
     * @param {number} x between 0 and 1
     * @returns {number}
     * @memberof HermiteInterpolation
     */
    HermiteInterpolation.prototype.evalDerivateRelative = function (x) {
        var y0 = this.fromValue;
        var y1 = this.toValue;
        var y_0 = this.fromDerivate;
        var y_1 = this.toDerivate;
        return y0 * H_0(x) + y1 * H_1(x) + y_0 * H_2(x) + y_1 * H_3(x);
    };
    return HermiteInterpolation;
}(_2_dimension_1.I2DimensionalInterpolation));
exports.HermiteInterpolation = HermiteInterpolation;
