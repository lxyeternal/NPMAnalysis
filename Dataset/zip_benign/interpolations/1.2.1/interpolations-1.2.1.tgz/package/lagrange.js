"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Interpolation with Lagrange. Provide different x,y pairs, which the interpolation should use as base points.
 *
 * @export
 * @class Lagrange
 */
var Lagrange = /** @class */ (function () {
    function Lagrange(x, y) {
        this.x = x;
        this.y = y;
        if (x.length !== y.length) {
            throw new Error('x,y length does not match! Please provide x any y pairwise');
        }
    }
    Lagrange.prototype.eval = function (x) {
        return this.f(x);
    };
    Lagrange.prototype.f = function (x) {
        var result = 0;
        var n = this.x.length;
        for (var k = 0; k < n; k++) {
            result += this.y[k] * this.l(k, x);
        }
        return result;
    };
    Lagrange.prototype.l = function (k, x) {
        var result = 1;
        var n = this.x.length;
        for (var i = 0; i < n; i++) {
            if (i === k)
                continue;
            result *= (x - this.x[i]) / (this.x[k] - this.x[i]);
        }
        return result;
    };
    return Lagrange;
}());
exports.Lagrange = Lagrange;
