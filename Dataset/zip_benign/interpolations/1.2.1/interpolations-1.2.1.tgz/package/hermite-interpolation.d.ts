import { I2DimensionalInterpolation } from './2-dimension';
export declare function smoothstep(min: number, max: number, t: number): number;
export declare class HermiteInterpolation extends I2DimensionalInterpolation {
    fromValue: number;
    toValue: number;
    fromDerivate: number;
    toDerivate: number;
    /**
     * Creates an instance of HermiteInterpolation.
     * @param {number} [from=0] x value where the interpolation should start
     * @param {number} [to=1] x value where the interpolation should end
     * @param {number} [fromValue=0] y value where the interpolation should start
     * @param {number} [toValue=1] y value where the interpolation should end
     * @param {number} [fromDerivate=0] derivation which the interpolation should have at the start
     * @param {number} [toDerivate=0] derivation which the interpolation should have at the end
     * @memberof HermiteInterpolation
     */
    constructor(from?: number, to?: number, fromValue?: number, toValue?: number, fromDerivate?: number, toDerivate?: number);
    /**
     * Interpolates between 0 and 1, the values ```fromValue``` and ```toValue``` with the given derivations at start and end.
     *
     * @param {number} x between 0 and 1
     * @returns {number}
     * @memberof HermiteInterpolation
     */
    evalRelative(x: number): number;
    /**
     * Return the derivate value from the interpolation function of ```eval```
     *
     * @param {number} x between ```from``` and ```to```
     * @returns {number}
     * @memberof HermiteInterpolation
     */
    evalDerivate(x: number): number;
    /**
     * Return the derivate value from the interpolation function of ```evalRelative```
     *
     * @param {number} x between 0 and 1
     * @returns {number}
     * @memberof HermiteInterpolation
     */
    evalDerivateRelative(x: number): number;
}
