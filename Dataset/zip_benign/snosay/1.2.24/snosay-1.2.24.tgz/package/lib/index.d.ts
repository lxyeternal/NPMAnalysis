/**
 * @author Snowstar Miao <snomiao@gmail.com>
 */
export default function snosay({ text, voice, speed, output, list, }: {
    text?: string;
    voice?: string;
    speed?: number;
    output?: string;
    list?: boolean;
}): Promise<void>;
export declare function speak(text: string, voice?: string, speed?: number): Promise<void>;
export declare function stop(): Promise<void>;
export declare function getInstalledVoices(): Promise<string[]>;
export declare function exportFile(text: string, voice?: string, speed?: number, filePath?: string): Promise<void>;
