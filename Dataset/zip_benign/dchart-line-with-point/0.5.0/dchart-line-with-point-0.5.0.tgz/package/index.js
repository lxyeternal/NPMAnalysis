'use strict';
// var DataV = require('../../line');
var DataV = require('dchart-core/line/line');
// var _ = require('../../../util');
var _ = require('dchart-core/util');
var d3 = require('d3');
const { SERIES_INDEX, interactionHandlerSelector } = _;

function LineWithPoint(container, options) {
  var opt = {
    margin: {right: 20, left: 10, top: 10, bottom: 10, containLabel: true},
    xaxis: {
      type: 'category',
      padding: 0.2,
      dy: 10,
    },
    yaxis: {},
    point: {
      radius: 5
    },
    tooltip: {
      axisPointer: 'line'
    },
    legend: {
      show: true,
      margin: {top: 10, bottom: 20, left: 0, right: 0},
      legendLabels: [],
      customRender: function (label, pos, i) {
        this.attr({
          transform: 'translate(' + (pos.x) + ', ' + (pos.y + pos.height / 2) + ')'
        });
        var line, circle, text;
        if (!this.select('line')[0][0]) {
          line = this.append('line');
        } else {
          line = this.select('line');
        }
        if (!this.select('circle')[0][0]) {
          circle = this.append('circle');
        } else {
          circle = this.select('circle');
        }
        if (!this.select('text')[0][0]) {
          text = this.append('text');
        } else {
          text = this.select('text');
        }
        line.attr({
          x1: 5,
          y1: 5,
          x2: 25,
          y2: 5
        });

        circle.attr({
          cx: 15,
          cy: 5,
          r: 5
        });

        text.html(label).attr({
          x: 30,
          y: 5,
          dy: '.35em'
        });
      }
    },
    beforeLayout: {
      legend: {
        position: 'bottom',
        height: '50',
        width: '500'
      }
    },
    series: [{color: null, colorWidth: null, point: {color: null, frameColor: null, frameColorWidth: null, hide: null, radius: 4}, style: 'solid', dashed: '4 4'}]
  };
  opt = _.deepMerge(opt, options);
  DataV.call(this, container, opt);
}

LineWithPoint = DataV.extend(LineWithPoint, {
  beforeRender: function () {
    DataV.prototype.beforeRender.call(this);
    var self = this;
    var opt  = this.options;
    var xkey = opt.xaxis.key;
    var ykey = opt.yaxis.key;
    if (opt.legend && opt.legend.show) {
      var legend = this.legend = this.renderLegend('legend', this.el[0][0], this.options.legend);
      legend.el.selectAll('.legend-label')
        .on('click', function (d, i) {
          self.emit('legend-click', {index: i + 1, dom: this});
        });
    }
  },
  updateBeforeRender: function () {
    var opt = this.options;
    var data = this.data();
    var self = this;
    var xkey = opt.xaxis.key;
    var ykey = opt.yaxis.key;
    if (this.legend) {
      this.legend.update(data, opt.legend);
      this.legend.el.selectAll('.legend-label')
        .on('click', function (d, i) {
          self.emit('legend-click', {index: i + 1, dom: this});
        });
    } else if (opt.legend && opt.legend.show) {
      var legend = this.legend = this.renderLegend('legend', this.el[0][0], this.options.legend);
      legend.update(data, opt.legend);
      legend.el.selectAll('.legend-label')
        .on('click', function (d, i) {
          self.emit('legend-click', {index: i + 1, dom: this});
        });
    }
  },
  afterRender: function () {
    var opt = this.options;
    var data = this.data();
    var xAxis = this.getComs('axis', 'xaxis');
    var x = xAxis.getX();
    var yAxis = this.getComs('axis', 'yaxis');
    var y = yAxis.getX();
    var xkey = opt.xaxis.key;
    var ykey = opt.yaxis.key;
    var series = opt.isFirst ? this.svg.append('g')
      .attr({class: 'scatterplot-g series interaction-g', transform: this.svg.select('.series:not(.area-g)').attr('transform')}) :
      this.svg.select('.scatterplot-g').attr('transform', this.svg.select('.series:not(.area-g)').attr('transform'));
    var len = _.maxBy(data, function (n) {
      return n[ykey].length;
    })[ykey].length;
    var updateSeriesAttr = function (d, i, seriesIndex) {
      const yValue = d[ykey].value;
      var that = d3.select(this);
      if (opt.animation) {
        if (opt.isFirst) {
          that.attr({
            cx: function (d) {
              if (opt.hiddenEmptyData && d[ykey][seriesIndex].__isNull) return;
              return x(opt.xaxis.type === 'time' ? d3.time.format(xAxis.options.format).parse(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand() / 2 : 0);
            },
            cy: function (d) {
              if (opt.hiddenEmptyData && d[ykey][seriesIndex].__isNull) return;
              return y(_.isNumber(d[ykey][seriesIndex].value) ? +d[ykey][seriesIndex].value : yAxis.getMin());
            },
            r: 0
          });
        }
        that.transition()
          .duration(opt.animationDuration)
          .ease(opt.animationEasing);
      }
      var cfg = opt.series[seriesIndex] && opt.series[seriesIndex].point || opt.point;
      let itemValue = d[ykey][seriesIndex].value;
      _.isNumber(+itemValue) && that.attr({
        cx: function () {
          if (d[ykey][seriesIndex].__isNull && opt.hiddenEmptyData) return;
          return x(opt.xaxis.type === 'time' ? d3.time.format(xAxis.options.format).parse(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand() / 2 : 0);
        },
        cy: () => {
          if (d[ykey][seriesIndex].__isNull && opt.hiddenEmptyData) return;
          if (!+itemValue && d.isNull && opt.hiddenEmptyData) return y(yAxis.getMin());
          return y(+itemValue);
        },
        r: cfg.radius || 4
      }) || that.attr({
        cx: function () {
          if (d[ykey][seriesIndex].__isNull && opt.hiddenEmptyData) return;
          return x(opt.xaxis.type === 'time' ? d3.time.format(xAxis.options.format).parse(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand() / 2 : 0);
        },
        cy: function () {
          if (d[ykey][seriesIndex].__isNull && opt.hiddenEmptyData) return;
          return y(yAxis.getMin());
        },
        r: opt.hiddenEmptyData ? 0 : cfg.radius || 4
      });
      if (cfg && _.isObject(cfg)) {
        that.style({
          'fill': function () {
            return cfg.color;
          },
          'stroke': function () {
            return cfg.frameColor;
          },
          'stroke-width': function () {
            return cfg.frameColorWidth;
          },
          'display': ((opt.hiddenEmptyData && d[ykey][seriesIndex].__isNull) || cfg.hide) && 'none' || 'block'
        });
      }
    };
    series = series.selectAll('.series-group').data(data);

    this.enterSeries = series.enter()
      .append('g')
      .attr('class', 'series-group');
      
    for (var i = 0; i < len; i++) {
      this.enterSeries.append('circle')
        .attr('class', `${interactionHandlerSelector} serie serie${(i + 1)}`)
        .attr(SERIES_INDEX, i)
        .each(function (d, index) {
          updateSeriesAttr.call(this, d, index, i);
        });
      series.each(function (d, index) {
        var that = d3.select(this);
        var node = that.select('.serie' + (i + 1))[0][0] || (
          that.append('circle')
          .attr('class', `${interactionHandlerSelector} serie serie${(i + 1)}`)
          .attr(SERIES_INDEX, i)
        )[0][0];
        node && updateSeriesAttr.call(node, d, index, i);
      });
    }
    series.selectAll('.serie.serie' + len + ' ~ .serie').remove();
    series.exit().remove();
    if (this.legend) {
      var box = this.legend.select('.legend-label').node().getBBox();
      var w = box.width;
      var h = box.height;
      var count = data.length;
      var mw = opt.beforeLayout.legend.width;
      var mh = opt.beforeLayout.legend.height;
      if (count * w > mw) {
        var size = Math.floor(mw / w);
        if (Math.floor(count / size) * h > mh) {
          console.warn('请申请更大的空间放图例');
        }

        this.legend.selectAll('.legend-label')
          .attr({
            transform: function (d, i) {
              return 'translate(' + (i % size) * w  + ', ' + (parseInt(i / size) * h + h / 2) + ')';
            }
          });
      }
    }
    this.svg[0][0].appendChild(this.labels[0][0]);

    DataV.prototype.afterRender.call(this);
  },
  updateAfterRender: function () {
    LineWithPoint.prototype.afterRender.call(this);
  },
  hidden: function (index) {
    if (!index) {
      this.svg.selectAll('.serie').classed('hidden', true);
      this.legend && this.legend.selectAll('.legend-label').classed('disable', true);
    } else {
      this.svg.selectAll('.serie' + index).classed('hidden', true);
      this.legend && this.legend.selectAll('.legend' + index).classed('disable', true);
    }
    return this;
  },
  show: function (index) {
    if (!index) {
      this.svg.selectAll('.serie').classed('hidden', false);
      this.legend && this.legend.selectAll('.legend-label').classed('disable', false);
    } else {
      this.svg.selectAll('.serie' + index).classed('hidden', false);
      this.legend && this.legend.selectAll('.legend' + index).classed('disable', false);
    }
    return this;
  },
  getShowIndex: function () {
    var arr = [];
    this.legend && this.legend.selectAll('.legend-label').each(function (d, i) {
      if (!d3.select(this).classed('disable')) {
        arr.push(i + 1);
      }
    });
    return arr;
  }
});

module.exports = LineWithPoint;
