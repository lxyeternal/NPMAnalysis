import { ViewStyle } from 'react-native';
declare type ShaderProps = {
    source: string;
    uniforms: object;
    style: ViewStyle;
};
export declare const ShaderView: import("react-native").HostComponent<ShaderProps>;
export default ShaderView;
