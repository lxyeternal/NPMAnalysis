## [1.6.1](https://github.com/bestickley/random-variate-generators/compare/v1.6.0...v1.6.1) (2020-12-01)


### Bug Fixes

* **index:** final pr ([a15b221](https://github.com/bestickley/random-variate-generators/commit/a15b221d8fc2049685b16a5efb8b95fe21028add))
