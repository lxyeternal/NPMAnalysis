exports.carousalHandler = function (
  carousel,
  leftArrow,
  rightArrow,
  images,
  interval,
  dotSliders
) {
  let currentImgIndex = 0;
  //the argument causes the moveFow() to be called in userSelect
  //default interval start
  let carousalInterval = setInterval(userSelect, interval, {
    target: rightArrow,
  });

  carousel.addEventListener("click", (e) => {
    if (e.target.classList.contains("carousel-click")) {
      clearInterval(carousalInterval); //so that timer restarts when an image has been clicked
      userSelect(e);
      carousalInterval = setInterval(userSelect, interval, {
        target: rightArrow,
      });
    }
  });

  function userSelect(e) {
    classToggler(images[currentImgIndex]);
    toggleDotHighlight(currentImgIndex);
    if (e.target === rightArrow) moveFow();
    if (e.target === leftArrow) moveBack();
    if (e.target.dataset.index) currentImgIndex = +e.target.dataset.index;
    classToggler(images[currentImgIndex]);
    toggleDotHighlight(currentImgIndex);
  }

  function toggleDotHighlight(index) {
    var selectedDot = dotSliders.find((item) => {
      return +item.dataset.index === index;
    });

    selectedDot.classList.toggle("selected-dot");
  }

  function moveFow() {
    if (currentImgIndex === images.length - 1) {
      currentImgIndex = 0;
    } else {
      currentImgIndex += 1;
    }
  }

  function moveBack() {
    if (currentImgIndex === 0) {
      currentImgIndex = images.length - 1;
    } else {
      currentImgIndex -= 1;
    }
  }

  function classToggler(ele) {
    ele.classList.toggle("show-image");
  }
};
