export declare class Ng6UdmChartModule {
}
