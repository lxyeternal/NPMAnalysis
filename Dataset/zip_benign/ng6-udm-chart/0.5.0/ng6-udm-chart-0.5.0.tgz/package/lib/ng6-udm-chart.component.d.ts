import { OnInit, ElementRef } from '@angular/core';
import { OnChanges, SimpleChange } from '@angular/core';
export declare class Ng6UdmChartComponent implements OnInit, OnChanges {
    chartType: string;
    svgWidth: string;
    svgHeight: string;
    graphData: Array<number>;
    configData: any;
    root: any;
    constructor(elementRef: ElementRef);
    ngOnInit(): void;
    ngOnChanges(changes: {
        [propertyName: string]: SimpleChange;
    }): void;
    private buildHistogram(svgContainer, configData, dataSetJson, svgWidth, svgHeight);
    private buildForce(svgContainer, configData, dataSetJson, svgWidth, svgHeight);
    private buildChoropleth(svgContainer, configData, dataSetJson, svgWidth, svgHeight);
    private buildPackLayout(svgContainer, configData, dataSetJson, svgWidth, svgHeight);
    private buildTree(svgContainer, configData, dataSetJson, svgWidth, svgHeight);
    private buildGeoOrthographic(svgContainer, configData, dataSetJson, svgWidth, svgHeight);
    private buildGeoMap(svgContainer, configData, dataSetJson, svgWidth, svgHeight);
    private buildStackBar(svgContainer, configData, dataSetJson, svgWidth, svgHeight);
    private buildScatterPlot(svgContainer, configData, dataSetJson, svgWidth, svgHeight);
    private drawXGrid(o2Common);
    private buildXAxis(o2Common);
    private buildPie(svgContainer, configData, dataSetJson, svgWidth, svgHeight);
    private buildBar(svgContainer, configData, dataSetJson, svgWidth, svgHeight);
    private buildLine(svgContainer, configData, dataSetJson, svgWidth, svgHeight);
    private drawSingleLine(o2Common, dataSet, lineNum);
    private buildLegend(o2Common, _legendDataSet);
    private drawXAxisLabel(o2Common, labelDataSet, chartType);
    private drawXBaseLine(o2Common);
    private buildYAxis(o2Common);
    private drawTitle(o2Common);
    private drawYGrid(o2Common);
}
