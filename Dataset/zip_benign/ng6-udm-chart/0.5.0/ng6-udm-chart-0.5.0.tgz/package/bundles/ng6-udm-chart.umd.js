(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('d3'), require('@angular/core')) :
    typeof define === 'function' && define.amd ? define('ng6-udm-chart', ['exports', 'd3', '@angular/core'], factory) :
    (factory((global['ng6-udm-chart'] = {}),null,global.ng.core));
}(this, (function (exports,d3,core) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var /** @type {?} */ LINE_CHART_TYPE_NAME = 'line';
    var /** @type {?} */ BAR_CHART_TYPE_NAME = 'bar';
    var /** @type {?} */ PIE_CHART_TYPE_NAME = 'pie';
    var /** @type {?} */ SCATTER_PLOT_CHART_TYPE_NAME = 'scatterPlot';
    var /** @type {?} */ HISTOGRAM_CHART_TYPE_NAME = 'histogram';
    var /** @type {?} */ STACK_BAR_CHART_TYPE_NAME = 'stackBar';
    var /** @type {?} */ GEO_MAP_CHART_TYPE_NAME = 'geoMap';
    var /** @type {?} */ GEO_ORTHOGRAPHIC_CHART_TYPE_NAME = 'geoOrthographic';
    var /** @type {?} */ TREE_MAP_CHART_TYPE_NAME = 'treeMap';
    var /** @type {?} */ PACK_LAYOUT_CHART_TYPE_NAME = 'packLayout';
    var /** @type {?} */ CHOROPLETH_CHART_TYPE_NAME = 'choropleth';
    var /** @type {?} */ TREE_CHART_TYPE_NAME = 'tree';
    var /** @type {?} */ SANKEY_CHART_TYPE_NAME = 'sankey';
    var /** @type {?} */ FORCE_CHART_TYPE_NAME = 'force';

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var O2Common = (function () {
        function O2Common(svgContainer, configData, autoMaxX, autoMaxY, svgWidth, svgHeight) {
            this.svgContainer = svgContainer;
            this.configData = configData;
            this.autoMaxX = autoMaxX;
            this.autoMaxY = autoMaxY;
            this.svgWidth = svgWidth;
            this.svgHeight = svgHeight;
        }
        Object.defineProperty(O2Common.prototype, "axisClassName", {
            get: /**
             * @return {?}
             */ function () {
                return this.configData.className.axis;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "lineClassName", {
            get: /**
             * @return {?}
             */ function () {
                return this.configData.className.line;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXBorderLineClassName", {
            get: /**
             * @return {?}
             */ function () {
                return this.configData.className.axisXBorder;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "maxXValue", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _maxX = this.autoMaxX;
                if (!this.configData.maxValue.auto) {
                    _maxX = this.configData.maxValue.x;
                }
                return _maxX;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "maxYValue", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _maxY = this.autoMaxY;
                if (!this.configData.maxValue.auto) {
                    _maxY = this.configData.maxValue.y;
                }
                return _maxY;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphInitXPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _intX = this.configData.margin.left;
                if (this.configData.legend.display && this.configData.legend.position !== 'right') {
                    _intX = this.configData.margin.left
                        + this.configData.legend.totalWidth;
                }
                return _intX;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphInitYPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _intY = this.configData.margin.top
                    + this.configData.title.height;
                return _intY;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphYScale", {
            get: /**
             * @return {?}
             */ function () {
                return this.graphHeight / this.maxYValue;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphXScale", {
            get: /**
             * @return {?}
             */ function () {
                return this.graphWidth / this.maxXValue;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphWidth", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _margin = this.configData.margin.left
                    + this.configData.margin.right;
                if (this.configData.legend.display) {
                    _margin += this.configData.legend.totalWidth;
                }
                return this.svgWidth - _margin;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphHeight", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _h = this.svgHeight
                    - this.configData.title.height
                    - this.configData.margin.top
                    - this.configData.margin.bottom;
                return _h;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphCenterPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _xyArray = new Array();
                var /** @type {?} */ _x = this.configData.margin.left
                    + this.graphWidth / 2;
                var /** @type {?} */ _y = this.configData.margin.top
                    + this.configData.title.height
                    + this.graphHeight / 2;
                _xyArray.push(_x);
                _xyArray.push(_y);
                return _xyArray;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphCenterTranslatePos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.configData.margin.left
                    + this.graphWidth / 2;
                var /** @type {?} */ _y = this.configData.margin.top
                    + this.configData.title.height
                    + this.graphHeight / 2;
                return 'translate(' + String(_x) + ', ' + String(_y) + ')';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "graphInitTranslatePos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.graphInitXPos;
                var /** @type {?} */ _y = this.graphInitYPos;
                return 'translate(' + String(_x) + ', ' + String(_y) + ')';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXLabelInitXPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.configData.margin.left
                    + this.configData.axis.xLabel.leftMargin;
                return _x;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXLabelInitYPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _y = this.svgHeight
                    - this.configData.axis.xLabel.bottomMargin;
                return _y;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisTranslatePos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.configData.margin.left;
                var /** @type {?} */ _y = this.configData.margin.top
                    + this.configData.title.height;
                return 'translate(' + String(_x) + ', ' + String(_y) + ')';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXBorderLineWidth", {
            get: /**
             * @return {?}
             */ function () {
                return this.configData.axis.borderLineWidth;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisYBorderHeight", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _margin = this.configData.margin.top
                    + this.configData.margin.bottom
                    + this.configData.title.height;
                return this.svgHeight - _margin;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXBorderWidth", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _margin = this.configData.margin.left
                    + this.configData.margin.right;
                if (this.configData.legend.display) {
                    _margin += this.configData.legend.totalWidth;
                }
                return this.svgWidth - _margin;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisYOrient", {
            get: /**
             * @return {?}
             */ function () {
                return 'left';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXOrient", {
            get: /**
             * @return {?}
             */ function () {
                return 'bottom';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "axisXBorderTranslatePos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ sYpos = String(this.svgHeight - this.configData.margin.bottom);
                return 'translate(' + this.configData.margin.left + ', ' + sYpos + ')';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "innerRadiusPercent", {
            get: /**
             * @return {?}
             */ function () {
                return this.configData.pie.innerRadius.percent;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "innerRadiusTitle", {
            get: /**
             * @return {?}
             */ function () {
                return this.configData.pie.innerRadius.title;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "innerRadiusTitleTranslatePos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.configData.margin.left
                    + this.graphWidth / 2;
                var /** @type {?} */ _y = this.configData.margin.top
                    + this.configData.title.height
                    + this.graphHeight / 2
                    + 5;
                return 'translate(' + String(_x) + ', ' + String(_y) + ')';
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "legendInitXPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.configData.margin.left
                    + this.graphWidth
                    + this.configData.legend.initXPos;
                if (this.configData.legend.position !== 'right') {
                    _x = this.configData.margin.left
                        + this.configData.legend.initXPos;
                }
                return _x;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "legendInitYPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _y = this.configData.margin.top
                    + this.configData.title.height
                    + this.configData.legend.initYPos;
                return _y;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "gridYStep", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _maxY = Math.ceil(this.maxYValue / 100) * 10;
                var /** @type {?} */ _lineNum = 10;
                var /** @type {?} */ _step = Math.ceil(_maxY / _lineNum) * _lineNum;
                return _step;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "gridXStep", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _maxX = Math.ceil(this.maxXValue / 100) * 10;
                var /** @type {?} */ _lineNum = 10;
                var /** @type {?} */ _step = Math.ceil(_maxX / _lineNum) * _lineNum;
                return _step;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "titleInitXPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _x = this.configData.margin.left
                    + (this.graphWidth + this.configData.legend.totalWidth) / 2
                    + this.configData.title.leftMargin;
                return _x;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "titleInitYPos", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _y = this.configData.margin.top
                    + this.configData.title.height
                    - this.configData.title.bottomMargin;
                return _y;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(O2Common.prototype, "defaultColorFunc", {
            get: /**
             * @return {?}
             */ function () {
                var /** @type {?} */ _color;
                if (this.configData.color.auto) {
                    if (this.configData.color.defaultColorNumber === '20') {
                        _color = d3.scaleOrdinal(d3.schemeCategory20);
                    }
                    else {
                        _color = d3.scaleOrdinal(d3.schemeCategory10);
                    }
                }
                return _color;
            },
            enumerable: true,
            configurable: true
        });
        return O2Common;
    }());
    var O2LegendData = (function () {
        function O2LegendData(title, color) {
            this.title = title;
            this.color = color;
        }
        return O2LegendData;
    }());
    var O2ScatterPlotData = (function () {
        function O2ScatterPlotData(x, y, r) {
            this.x = x;
            this.y = y;
            this.r = r;
        }
        return O2ScatterPlotData;
    }());
    var O2IdValueData = (function () {
        function O2IdValueData(id, value) {
            this.id = id;
            this.value = value;
        }
        return O2IdValueData;
    }());
    // export class O2KeyValueData {
    //     constructor(
    //        public key: string,
    // 	   public value: number
    //        ) { }
    // }
    // export class O2DateKVArrayData {
    //     constructor(
    //        public date: Date,
    // 	   public kvArray: Array<O2KeyValueData>
    //        ) { }
    // }
    // export class O2DateStKVArrayData {
    //     constructor(
    //        public dateSt: string,
    // 	   public kvArray: Array<O2KeyValueData>
    //        ) { }
    // }

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Ng6UdmChartComponent = (function () {
        function Ng6UdmChartComponent(elementRef) {
            console.log('el:HTMLElement-------------------');
            var /** @type {?} */ el = elementRef.nativeElement;
            this.root = d3.select(el);
        }
        /**
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
            };
        /**
         * @param {?} changes
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.ngOnChanges = /**
         * @param {?} changes
         * @return {?}
         */
            function (changes) {
                var /** @type {?} */ svgWidth = parseInt(this.svgWidth, 10);
                var /** @type {?} */ svgHeight = parseInt(this.svgHeight, 10);
                var /** @type {?} */ dataSet = this.graphData;
                var /** @type {?} */ configData = this.configData;
                var /** @type {?} */ chartType = this.chartType;
                var /** @type {?} */ svgContainer = this.root.append('svg')
                    .attr('width', svgWidth)
                    .attr('height', svgHeight);
                console.log(chartType);
                switch (chartType) {
                    case LINE_CHART_TYPE_NAME:
                        this.buildLine(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case BAR_CHART_TYPE_NAME:
                        this.buildBar(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case PIE_CHART_TYPE_NAME:
                        this.buildPie(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case SCATTER_PLOT_CHART_TYPE_NAME:
                        this.buildScatterPlot(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case HISTOGRAM_CHART_TYPE_NAME:
                        this.buildHistogram(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case STACK_BAR_CHART_TYPE_NAME:
                        this.buildStackBar(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case GEO_MAP_CHART_TYPE_NAME:
                        this.buildGeoMap(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case GEO_ORTHOGRAPHIC_CHART_TYPE_NAME:
                        this.buildGeoOrthographic(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case TREE_CHART_TYPE_NAME:
                        this.buildTree(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case PACK_LAYOUT_CHART_TYPE_NAME:
                        this.buildPackLayout(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case CHOROPLETH_CHART_TYPE_NAME:
                        this.buildChoropleth(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case FORCE_CHART_TYPE_NAME:
                        this.buildForce(svgContainer, configData, dataSet, svgWidth, svgHeight);
                        break;
                    case TREE_MAP_CHART_TYPE_NAME:
                        //  this.buildTreeMap(svgContainer,configData, dataSet,svgWidth,svgHeight );
                        break;
                    case SANKEY_CHART_TYPE_NAME:
                        //  this.buildSankey(svgContainer,configData, dataSet,svgWidth,svgHeight );
                        break;
                    default:
                        break;
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildHistogram = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in buildHistogram-------------------');
                var /** @type {?} */ dataSet = dataSetJson.data;
                var /** @type {?} */ _binNumber = dataSetJson.bins.length - 1;
                var /** @type {?} */ _maxY = 300; // dummy number
                var /** @type {?} */ _maxX = dataSetJson.range[1];
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _graphWidth = cdt.graphWidth;
                var /** @type {?} */ _graphHeight = cdt.graphHeight;
                var /** @type {?} */ _graphInitX = cdt.graphInitXPos;
                var /** @type {?} */ _graphInitY = cdt.graphInitYPos;
                var /** @type {?} */ _titleDisplay = configData.title.display;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                var /** @type {?} */ _gridYDisplay = configData.grid.y.display;
                var /** @type {?} */ _marginLeft = configData.margin.left;
                var /** @type {?} */ _marginTop = configData.margin.top;
                var /** @type {?} */ _className = configData.className.histogramBar;
                var /** @type {?} */ _dataSet = new Array();
                for (var /** @type {?} */ i in dataSet) {
                    if (dataSet.hasOwnProperty(i)) {
                        var /** @type {?} */ _num = dataSet[i] / _maxX;
                        _dataSet.push(_num);
                    }
                }
                var /** @type {?} */ formatCount = d3.format(',.0f');
                var /** @type {?} */ _histgramContainer = svgContainer
                    .append('g')
                    .attr('transform', 'translate(' + _graphInitX + ',' + _graphInitY + ')');
                var /** @type {?} */ _xScale = d3.scaleLinear()
                    .rangeRound([0, _graphWidth]);
                var /** @type {?} */ bins = d3.histogram()
                    .domain([0, 1])
                    .thresholds(_xScale.ticks(_binNumber))(_dataSet);
                var /** @type {?} */ _yScale = d3.scaleLinear()
                    .domain([0, d3.max(bins, function (d) {
                        return d.length;
                    })])
                    .range([_graphHeight, 0]);
                var /** @type {?} */ bar = _histgramContainer
                    .selectAll('.bar')
                    .data(bins)
                    .enter()
                    .append('g')
                    .attr('class', _className)
                    .attr('transform', function (d) {
                    return 'translate(' + _xScale(d.x0) + ',' + _yScale(d.length) + ')';
                });
                if (_animation) {
                    bar.append('rect')
                        .attr('x', 1)
                        .attr('width', _xScale(bins[0].x1) - _xScale(bins[0].x0) - 1)
                        .attr('height', 0)
                        .transition()
                        .duration(_animationDuration)
                        .attr('height', function (d) {
                        return _graphHeight - _yScale(d.length);
                    });
                }
                else {
                    bar.append('rect')
                        .attr('x', 1)
                        .attr('width', _xScale(bins[0].x1) - _xScale(bins[0].x0) - 1)
                        .attr('height', function (d) {
                        return _graphHeight - _yScale(d.length);
                    });
                }
                bar.append('text')
                    .attr('dy', '.75em')
                    .attr('y', 6)
                    .attr('x', (_xScale(bins[0].x1) - _xScale(bins[0].x0)) / 2)
                    .attr('text-anchor', 'middle')
                    .text(function (d) {
                    return formatCount(d.length);
                });
                // ---CALL buildTitle-----------------
                if (_titleDisplay) {
                    this.drawTitle(cdt);
                }
                // ------------------------------------
                // ---CALL buildAxis-----------------
                this.buildYAxis(cdt);
                this.buildXAxis(cdt);
                if (_gridYDisplay) {
                    this.drawYGrid(cdt);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildForce = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('In  buildFoce----------------');
                var /** @type {?} */ _maxX = 100;
                var /** @type {?} */ _maxY = 100;
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _color = cdt.defaultColorFunc;
                var /** @type {?} */ _graphHeight = cdt.graphHeight;
                var /** @type {?} */ _graphWidth = cdt.graphWidth;
                var /** @type {?} */ _marginLeft = configData.margin.left;
                var /** @type {?} */ _marginTop = configData.margin.top;
                var /** @type {?} */ simulation = d3.forceSimulation()
                    .force('link', d3.forceLink().id(function (d) {
                    return d.id;
                }))
                    .force('charge', d3.forceManyBody())
                    .force('center', d3.forceCenter(_graphWidth / 2, _graphHeight / 2));
                var /** @type {?} */ _forceContainer = svgContainer
                    .append('g')
                    .attr('transform', 'translate(' + _marginLeft + ',' + _marginTop + ')');
                var /** @type {?} */ link = _forceContainer.append('g')
                    .attr('class', 'force-links')
                    .selectAll('line')
                    .data(dataSetJson.links)
                    .enter()
                    .append('line')
                    .attr('stroke-width', function (d) {
                    return Math.sqrt(d.value);
                });
                var /** @type {?} */ node = _forceContainer.append('g')
                    .attr('class', 'nodes')
                    .selectAll('circle')
                    .data(dataSetJson.nodes)
                    .enter()
                    .append('circle')
                    .attr('r', 5)
                    .attr('fill', function (d) {
                    return _color(d.group);
                })
                    .call(d3.drag()
                    .on('start', dragstarted)
                    .on('drag', dragged)
                    .on('end', dragended));
                node.append('title')
                    .text(function (d) {
                    return d.id;
                });
                simulation
                    .nodes(dataSetJson.nodes)
                    .on('tick', ticked);
                var /** @type {?} */ _forceLink = simulation.force('link');
                _forceLink.links(dataSetJson.links);
                /**
                 * @return {?}
                 */
                function ticked() {
                    link
                        .attr('x1', function (d) {
                        return d.source.x;
                    })
                        .attr('y1', function (d) {
                        return d.source.y;
                    })
                        .attr('x2', function (d) {
                        return d.target.x;
                    })
                        .attr('y2', function (d) {
                        return d.target.y;
                    });
                    node
                        .attr('cx', function (d) {
                        return d.x;
                    })
                        .attr('cy', function (d) {
                        return d.y;
                    });
                }
                /**
                 * @param {?} d
                 * @return {?}
                 */
                function dragstarted(d) {
                    if (!d3.event.active) {
                        simulation.alphaTarget(0.3).restart();
                    }
                    d.fx = d.x;
                    d.fy = d.y;
                }
                /**
                 * @param {?} d
                 * @return {?}
                 */
                function dragged(d) {
                    d.fx = d3.event.x;
                    d.fy = d3.event.y;
                }
                /**
                 * @param {?} d
                 * @return {?}
                 */
                function dragended(d) {
                    if (!d3.event.active) {
                        simulation.alphaTarget(0);
                    }
                    d.fx = null;
                    d.fy = null;
                }
                //  ------------------------------------
                //  ---CALL buildLegend-----------------
                var /** @type {?} */ _legendDataSet = new Array();
                for (var /** @type {?} */ i in dataSetJson.groups) {
                    if (dataSetJson.groups.hasOwnProperty(i)) {
                        var /** @type {?} */ _id = dataSetJson.groups[i].id;
                        _legendDataSet.push(new O2LegendData(dataSetJson.groups[i].name, _color(_id)));
                    }
                }
                this.buildLegend(cdt, _legendDataSet);
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildChoropleth = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in buildChoropleth -------------------');
                var /** @type {?} */ _maxX = 100; // any value
                var /** @type {?} */ _maxY = 100; // any value
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _graphCenterPos = cdt.graphCenterPos;
                var /** @type {?} */ _titleDisplay = configData.title.display;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ _focusColor = configData.color.focusColor;
                var /** @type {?} */ _scale = dataSetJson.map.scale;
                var /** @type {?} */ _targetName = dataSetJson.map.targetName;
                var /** @type {?} */ _keyDataName = dataSetJson.map.keyDataName;
                var /** @type {?} */ _keyName = 'data.' + _keyDataName;
                var /** @type {?} */ _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
                var /** @type {?} */ _startColor = dataSetJson.map.startColor;
                var /** @type {?} */ _endColor = dataSetJson.map.endColor;
                var /** @type {?} */ _colorNum = dataSetJson.map.colorNumber;
                var /** @type {?} */ _center = dataSetJson.map.center;
                var /** @type {?} */ _targetPropertyName = dataSetJson.map.targetPropertyName;
                var /** @type {?} */ _targetProperty = 'd.' + _targetPropertyName;
                var /** @type {?} */ color = d3.interpolateHsl(_startColor, _endColor);
                var /** @type {?} */ _max = dataSetJson.data[0].value;
                var /** @type {?} */ _min = dataSetJson.data[0].value;
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        if (_max < dataSetJson.data[i].value) {
                            _max = dataSetJson.data[i].value;
                        }
                        if (_min > dataSetJson.data[i].value) {
                            _min = dataSetJson.data[i].value;
                        }
                    }
                }
                var /** @type {?} */ _range = _max - _min;
                var /** @type {?} */ _step = _range / (_colorNum - 1);
                var /** @type {?} */ _findColorById = function (id) {
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            if (id === dataSetJson.data[i].id) {
                                var /** @type {?} */ _value = dataSetJson.data[i].value;
                                var /** @type {?} */ _rate = Math.ceil((_value - _min) / _step);
                                return color(_rate / _max);
                            }
                        }
                    }
                };
                var /** @type {?} */ path = d3.geoPath()
                    .projection(d3.geoMercator()
                    .center(_center)
                    .scale(_scale)
                    .translate(_graphCenterPos));
                d3.json(_geoMapDataUrl, function (error, data) {
                    svgContainer.selectAll('path')
                        .data(eval(_keyName))
                        .enter()
                        .append('path')
                        .attr('d', path)
                        .style('fill', function (d, i) {
                        var /** @type {?} */ _cl = _findColorById(eval(_targetProperty));
                        return _cl;
                    });
                });
                // ------------------------------------
                // ---CALL buildTitle-----------------
                if (_titleDisplay) {
                    this.drawTitle(cdt);
                }
                //  ------------------------------------
                //  ---CALL buildLegend-----------------
                if (_legendDisplay) {
                    var /** @type {?} */ _legendDataSet = new Array();
                    for (var /** @type {?} */ i = 0; i < _colorNum; i++) {
                        var /** @type {?} */ _label = String(_min + (i * _step)) + ' --';
                        _legendDataSet.push(new O2LegendData(_label, color(i / _max)));
                    }
                    this.buildLegend(cdt, _legendDataSet);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildPackLayout = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in PackLayout------------------');
                var /** @type {?} */ _packlayoutClass = configData.className.packlayout;
                var /** @type {?} */ _packlayoutLabelClass = configData.className.packlayoutLabel;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                var /** @type {?} */ color = d3.scaleOrdinal(d3.schemeCategory10);
                //  const color = d3.scale.category10();
                var /** @type {?} */ bubble = d3.pack()
                    .size([svgWidth, svgHeight]);
                var /** @type {?} */ nodes0 = d3.hierarchy(dataSetJson);
                var /** @type {?} */ pack = svgContainer.selectAll('g')
                    .data(bubble(nodes0).descendants())
                    .enter()
                    .append('g')
                    .attr('transform', function (d, i) {
                    return 'translate(' + d.x + ',' + d.y + ')';
                });
                var /** @type {?} */ _circle = pack.append('circle');
                if (_animation) {
                    _circle.attr('r', 0)
                        .transition()
                        .duration(function (d, i) {
                        return d.depth * _animationDuration + 500;
                    })
                        .attr('r', function (d) {
                        return d.r;
                    })
                        .style('fill', function (d, i) {
                        return color(i);
                    });
                }
                else {
                    _circle.attr('r', function (d) {
                        return d.r;
                    })
                        .style('fill', function (d, i) {
                        return color(i);
                    });
                }
                var /** @type {?} */ _text = pack.append('text')
                    .attr('class', _packlayoutLabelClass)
                    .text(function (d, i) {
                    if (d.depth === 1) {
                        return d.data.name;
                    }
                    return null;
                });
                if (_animation) {
                    _text.style('opacity', 0)
                        .transition()
                        .duration(_animationDuration)
                        .style('opacity', 1.0);
                }
                else {
                    _text.style('opacity', 1.0);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildTree = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('In  buildTree----------------');
                var /** @type {?} */ _maxX = 0;
                var /** @type {?} */ _maxY = 0;
                _maxY = 100;
                _maxX = 100;
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _graphHeight = cdt.graphHeight;
                var /** @type {?} */ _graphWidth = cdt.graphWidth;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                var /** @type {?} */ _treemapClass = configData.className.treemap;
                var /** @type {?} */ _treemapLabelClass = configData.className.treemapLabel;
                var /** @type {?} */ _marginLeft = configData.margin.left;
                var /** @type {?} */ _marginTop = configData.margin.top;
                var /** @type {?} */ tree = d3.tree()
                    .size([_graphWidth, _graphHeight]);
                var /** @type {?} */ nodes0 = d3.hierarchy(dataSetJson);
                var /** @type {?} */ nodes = tree(nodes0);
                var /** @type {?} */ _treeContainer = svgContainer
                    .append('g')
                    .attr('transform', 'translate(' + _marginLeft + ',' + _marginTop + ')');
                var /** @type {?} */ link = _treeContainer
                    .selectAll('.link')
                    .data(nodes.descendants().slice(1))
                    .enter()
                    .append('path')
                    .attr('class', 'tree-node-link')
                    .attr('d', function (d) {
                    return 'M' + d.x + ',' + d.y
                        + 'C' + d.x + ',' + (d.y + d.parent.y) / 2
                        + ' ' + d.parent.x + ',' + (d.y + d.parent.y) / 2
                        + ' ' + d.parent.x + ',' + d.parent.y;
                });
                var /** @type {?} */ node = _treeContainer
                    .selectAll('.node')
                    .data(nodes.descendants())
                    .enter()
                    .append('g')
                    .attr('class', function (d) {
                    return 'tree-node' +
                        (d.children ? '-internal' : '-leaf');
                })
                    .attr('transform', function (d) {
                    return 'translate(' + d.x + ',' + d.y + ')';
                });
                node.append('circle')
                    .attr('r', 10);
                node.append('text')
                    .attr('dy', '.35em')
                    .attr('y', function (d) {
                    return d.children ? -20 : 20;
                })
                    .style('text-anchor', 'middle')
                    .text(function (d) {
                    return d.data.name;
                });
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildGeoOrthographic = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in buildGeoOrthographic -------------------');
                var /** @type {?} */ _maxX = 100; // any value
                var /** @type {?} */ _maxY = 100; // any value
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _graphCenterPos = cdt.graphCenterPos;
                var /** @type {?} */ _titleDisplay = configData.title.display;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ _focusColor = configData.color.focusColor;
                var /** @type {?} */ _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
                var /** @type {?} */ _scale = dataSetJson.map.scale;
                var /** @type {?} */ _targetName = dataSetJson.map.targetName;
                var /** @type {?} */ _targetProperty = 'd.' + dataSetJson.map.targetPropertyName;
                var /** @type {?} */ _keyDataName = dataSetJson.map.keyDataName;
                var /** @type {?} */ _keyName = 'data.' + _keyDataName;
                var /** @type {?} */ _clipAngle = dataSetJson.map.clipAngle;
                var /** @type {?} */ _rotateH = dataSetJson.map.rotate.horizontal;
                var /** @type {?} */ _rotateV = dataSetJson.map.rotate.vertical;
                var /** @type {?} */ _oceanColor = dataSetJson.map.oceanColor;
                var /** @type {?} */ _antarcticaColor = dataSetJson.map.antarcticaColor;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                var /** @type {?} */ _animationH = 0;
                var /** @type {?} */ _findColorByName = function (name) {
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            if (name === dataSetJson.data[i].name) {
                                var /** @type {?} */ _color = dataSetJson.data[i].color;
                                return _color;
                            }
                        }
                    }
                    return null;
                };
                var /** @type {?} */ targetPath = d3.geoOrthographic()
                    .translate(_graphCenterPos)
                    .clipAngle(_clipAngle)
                    .scale(_scale)
                    .rotate([_rotateH, _rotateV]);
                var /** @type {?} */ path = d3.geoPath()
                    .projection(targetPath);
                d3.json(_geoMapDataUrl, function (error, data) {
                    svgContainer.append('circle')
                        .attr('cx', _graphCenterPos[0])
                        .attr('cy', _graphCenterPos[1])
                        .attr('r', _scale)
                        .style('fill', _oceanColor);
                    var /** @type {?} */ earthPath = svgContainer.selectAll('path')
                        .data(eval(_keyName))
                        .enter()
                        .append('path')
                        .attr('d', path)
                        .style('fill', function (d, i) {
                        var /** @type {?} */ _targetArea = eval(_targetProperty);
                        if (_findColorByName(_targetArea) !== null) {
                            return _findColorByName(_targetArea);
                        }
                        return 'hsl(' + i + ',80%,60%)';
                    });
                    if (_animation) {
                        d3.timer(function () {
                            targetPath.rotate([_rotateH + _animationH, _rotateV]);
                            _animationH += 2;
                            earthPath.attr('d', path);
                        });
                    }
                });
                // ------------------------------------
                // ---CALL buildTitle-----------------
                if (_titleDisplay) {
                    this.drawTitle(cdt);
                }
                if (_legendDisplay) {
                    var /** @type {?} */ _legendDataSet = new Array();
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            var /** @type {?} */ _name = dataSetJson.data[i].name;
                            var /** @type {?} */ _color = dataSetJson.data[i].color;
                            if (_name === 'Antarctica') {
                                continue;
                            }
                            _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, dataSetJson.data[i].color));
                        }
                    }
                    this.buildLegend(cdt, _legendDataSet);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildGeoMap = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in buildGeoMap -------------------');
                var /** @type {?} */ _maxX = 100; // any value
                var /** @type {?} */ _maxY = 100; // any value
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _graphCenterPos = cdt.graphCenterPos;
                var /** @type {?} */ _geoMapDataUrl = dataSetJson.map.baseGeoDataUrl;
                var /** @type {?} */ _scale = dataSetJson.map.scale;
                var /** @type {?} */ _keyDataName = dataSetJson.map.keyDataName;
                var /** @type {?} */ _keyName = 'data.' + _keyDataName;
                var /** @type {?} */ _targetProperty = 'd.' + dataSetJson.map.targetPropertyName;
                var /** @type {?} */ _antarcticaColor = dataSetJson.map.antarcticaColor;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ path = d3.geoPath()
                    .projection(d3.geoMercator()
                    .translate(_graphCenterPos)
                    .scale(_scale));
                var /** @type {?} */ _findColorByName = function (name) {
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            if (name === dataSetJson.data[i].name) {
                                var /** @type {?} */ _color = dataSetJson.data[i].color;
                                return _color;
                            }
                        }
                    }
                    return null;
                };
                d3.json(_geoMapDataUrl, function (error, data) {
                    svgContainer.selectAll('path')
                        .data(eval(_keyName))
                        .enter()
                        .append('path')
                        .attr('d', path)
                        .style('fill', function (d, i) {
                        var /** @type {?} */ _targetArea = eval(_targetProperty);
                        if (_findColorByName(_targetArea) !== null) {
                            return _findColorByName(_targetArea);
                        }
                        return 'hsl(' + i + ',80%,60%)';
                    });
                });
                //  ------------------------------------
                //  ---CALL buildLegend-----------------
                if (_legendDisplay) {
                    var /** @type {?} */ _legendDataSet = new Array();
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            var /** @type {?} */ _name = dataSetJson.data[i].name;
                            var /** @type {?} */ _color = dataSetJson.data[i].color;
                            if (_name === 'Antarctica') {
                                continue;
                            }
                            _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, dataSetJson.data[i].color));
                        }
                    }
                    this.buildLegend(cdt, _legendDataSet);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildStackBar = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in buildStackBar-------------------');
                var /** @type {?} */ _totalY = new Array();
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        _totalY.push(0);
                    }
                }
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        var /** @type {?} */ k = 0;
                        for (var /** @type {?} */ j in dataSetJson.data[i].value) {
                            if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                                _totalY[k++] += dataSetJson.data[i].value[j].y;
                            }
                        }
                    }
                }
                var /** @type {?} */ _maxX = 0;
                var /** @type {?} */ _maxY = 0;
                _maxY = d3.max(_totalY);
                _maxX = 100;
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _color = cdt.defaultColorFunc;
                var /** @type {?} */ _columnNum = dataSetJson.data.length;
                var /** @type {?} */ _barWidth = (cdt.graphWidth / _columnNum) - configData.margin.between;
                var /** @type {?} */ _columnWidth = (cdt.graphWidth / _columnNum);
                var /** @type {?} */ _initPosX = cdt.graphInitXPos;
                var /** @type {?} */ _graphHeight = cdt.graphHeight;
                var /** @type {?} */ _maxYValue = cdt.maxYValue;
                var /** @type {?} */ _opacity = configData.color.opacity;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ _gridYDisplay = configData.grid.y.display;
                var /** @type {?} */ _gridXDisplay = configData.grid.x.display;
                var /** @type {?} */ _labelDisplay = configData.label.display;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                //  Get Data Name
                var /** @type {?} */ _seriesDateName = dataSetJson.series[0];
                //  Get Keys
                var /** @type {?} */ _keyArray = new Array();
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        var /** @type {?} */ _key = dataSetJson.data[i].name;
                        var /** @type {?} */ _value = dataSetJson.data[i].value[0].y;
                        _keyArray.push(_key);
                    }
                }
                //  Get Date String
                var /** @type {?} */ _dateArray = new Array();
                for (var /** @type {?} */ i in dataSetJson.data[0].value) {
                    if (dataSetJson.data[0].value.hasOwnProperty(i)) {
                        var /** @type {?} */ _xValue = dataSetJson.data[0].value[i].x;
                        _dateArray.push(_xValue);
                    }
                }
                var /** @type {?} */ _hashArray = new Array();
                for (var /** @type {?} */ i in _dateArray) {
                    if (_dateArray.hasOwnProperty(i)) {
                        var /** @type {?} */ _hashNumber = {};
                        for (var /** @type {?} */ j in _keyArray) {
                            if (_keyArray.hasOwnProperty(j)) {
                                var /** @type {?} */ _key = _keyArray[j];
                                var /** @type {?} */ _value = dataSetJson.data[j].value[i].y;
                                _hashNumber[_key] = _value;
                            }
                        }
                        _hashArray.push(_hashNumber);
                    }
                }
                var /** @type {?} */ yScale = d3.scaleLinear()
                    .domain([0, _maxYValue])
                    .range([0, _graphHeight]);
                var /** @type {?} */ stack = d3.stack();
                var /** @type {?} */ _rect = svgContainer.selectAll('g')
                    .data(stack.keys(_keyArray)(_hashArray))
                    .enter()
                    .append('g')
                    .attr('fill', function (d, i) {
                    return _color(i);
                })
                    .attr('fill-opacity', _opacity)
                    .selectAll('rect')
                    .data(function (d, i) {
                    return d;
                })
                    .enter()
                    .append('rect');
                if (_animation) {
                    _rect.attr('x', function (d, i) {
                        return _initPosX + i * _columnWidth;
                    })
                        .attr('height', 0)
                        .attr('y', function (d, i) {
                        var /** @type {?} */ nm = 'd.data.' + _keyArray[i];
                        var /** @type {?} */ _yValue = eval(nm);
                        return svgHeight - configData.margin.bottom - yScale(d[1]);
                    })
                        .attr('width', _barWidth)
                        .transition()
                        .duration(_animationDuration)
                        .attr('height', function (d, i) {
                        return yScale(d[1] - d[0]);
                    });
                }
                else {
                    _rect.attr('x', function (d, i) {
                        return _initPosX + (i * _columnWidth);
                    })
                        .attr('y', function (d, i) {
                        var /** @type {?} */ nm = 'd.data.' + _keyArray[i];
                        var /** @type {?} */ _yValue = eval(nm);
                        return svgHeight - configData.margin.bottom - yScale(d[1]);
                    })
                        .attr('width', _barWidth)
                        .attr('height', function (d, i) {
                        return yScale(d[1] - d[0]);
                    });
                }
                // ------------------------------------
                // ---CALL buildTitle-----------------
                this.drawTitle(cdt);
                // ------------------------------------
                // ---CALL buildAxis-----------------
                this.buildYAxis(cdt);
                this.drawXBaseLine(cdt);
                //  ------------------------------------
                //  ---CALL drawXAxisLabel-----------------
                if (_labelDisplay) {
                    var /** @type {?} */ _labelArray = new Array();
                    for (var /** @type {?} */ i in dataSetJson.data[0].value) {
                        if (dataSetJson.data[0].value.hasOwnProperty(i)) {
                            _labelArray.push(dataSetJson.data[0].value[i].x);
                        }
                    }
                    this.drawXAxisLabel(cdt, _labelArray, STACK_BAR_CHART_TYPE_NAME);
                }
                //  ------------------------------------
                //  ---CALL buildLegend-----------------
                if (_legendDisplay) {
                    var /** @type {?} */ _legendDataSet = new Array();
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, _color(i)));
                        }
                    }
                    this.buildLegend(cdt, _legendDataSet);
                }
                if (_gridYDisplay) {
                    this.drawYGrid(cdt);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildScatterPlot = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('In  buildScatterPlot----------------');
                var /** @type {?} */ _dataSet = new Array();
                var /** @type {?} */ _maxX = 0;
                var /** @type {?} */ _maxY = 0;
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        for (var /** @type {?} */ j in dataSetJson.data[i].value) {
                            if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                                if (_maxX < dataSetJson.data[i].value[j].x) {
                                    _maxX = dataSetJson.data[i].value[j].x;
                                }
                                if (_maxY < dataSetJson.data[i].value[j].y) {
                                    _maxY = dataSetJson.data[i].value[j].y;
                                }
                                var /** @type {?} */ _scatterPlotData = new O2ScatterPlotData(dataSetJson.data[i].value[j].x, dataSetJson.data[i].value[j].y, dataSetJson.data[i].value[j].r);
                                _dataSet.push(_scatterPlotData);
                            }
                        }
                    }
                }
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _initPosX = cdt.graphInitXPos;
                var /** @type {?} */ _seriesNumber = dataSetJson.series.length;
                var /** @type {?} */ _color = cdt.defaultColorFunc;
                var /** @type {?} */ _opacity = configData.color.opacity;
                var /** @type {?} */ _gridYDisplay = configData.grid.y.display;
                var /** @type {?} */ _gridXDisplay = configData.grid.x.display;
                var /** @type {?} */ _titleDisplay = configData.title.display;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ _circle = svgContainer.selectAll('circle')
                    .data(_dataSet)
                    .enter()
                    .append('circle')
                    .attr('cx', function (d, i) {
                    return _initPosX + d.x;
                })
                    .attr('cy', function (d, i) {
                    return (svgHeight - configData.margin.bottom - d.y);
                })
                    .attr('r', function (d, i) {
                    return d.r;
                })
                    .style('fill', function (d, i) {
                    var /** @type {?} */ _colorNum = i % _seriesNumber;
                    return _color(_colorNum);
                })
                    .attr('fill-opacity', _opacity);
                // ---CALL buildTitle-----------------
                if (_titleDisplay) {
                    this.drawTitle(cdt);
                }
                // ------------------------------------
                // ---CALL buildLegend-----------------
                if (_legendDisplay) {
                    var /** @type {?} */ _legendDataSet = new Array();
                    for (var /** @type {?} */ i = 0; i < dataSetJson.series.length; i++) {
                        _legendDataSet.push(new O2LegendData(dataSetJson.series[i], _color(i)));
                    }
                    this.buildLegend(cdt, _legendDataSet);
                }
                // ------------------------------------
                // ---CALL buildAxis-----------------
                this.buildYAxis(cdt);
                this.buildXAxis(cdt);
                if (_gridYDisplay) {
                    this.drawYGrid(cdt);
                }
                if (_gridXDisplay) {
                    this.drawXGrid(cdt);
                }
            };
        /**
         * @param {?} o2Common
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.drawXGrid = /**
         * @param {?} o2Common
         * @return {?}
         */
            function (o2Common) {
                console.log('in buildXGrid-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                var /** @type {?} */ _stepX = cdt.gridXStep;
                var /** @type {?} */ _maxX = cdt.maxXValue;
                var /** @type {?} */ _graphYScale = cdt.graphYScale;
                var /** @type {?} */ _graphXScale = cdt.graphXScale;
                var /** @type {?} */ _graphWidth = cdt.graphWidth;
                var /** @type {?} */ _gridClassName = configData.className.grid;
                var /** @type {?} */ _axisXScale = d3.scaleLinear()
                    .domain([0, _maxX])
                    .range([0, _maxX * _graphXScale]);
                var /** @type {?} */ _rangeX = d3.range(_stepX * _graphXScale, _maxX * _graphXScale, _stepX * _graphXScale);
                svgContainer.append('g')
                    .selectAll('line.x')
                    .data(_rangeX)
                    .enter()
                    .append('line')
                    .attr('class', _gridClassName)
                    .attr('x1', function (d, i) {
                    var /** @type {?} */ _x1 = configData.margin.left + d;
                    return _x1;
                })
                    .attr('y1', cdt.svgHeight - configData.margin.bottom)
                    .attr('x2', function (d, i) {
                    var /** @type {?} */ _x2 = configData.margin.left + d;
                    return _x2;
                })
                    .attr('y2', configData.margin.top + configData.title.height);
            };
        /**
         * @param {?} o2Common
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildXAxis = /**
         * @param {?} o2Common
         * @return {?}
         */
            function (o2Common) {
                console.log('in buildXAxis-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                var /** @type {?} */ _maxX = cdt.maxXValue;
                var /** @type {?} */ _graphXScale = cdt.graphXScale;
                var /** @type {?} */ _axisXScale = d3.scaleLinear()
                    .domain([0, _maxX])
                    .range([0, _maxX * _graphXScale]);
                svgContainer.append('g')
                    .attr('class', cdt.axisClassName)
                    .attr('transform', cdt.axisXBorderTranslatePos)
                    .call(d3.axisBottom(_axisXScale));
                //  .scale()
                //  .orient(cdt.axisXOrient)
                //  );
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildPie = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('In  buildPie----------------');
                var /** @type {?} */ _maxX = 100;
                var /** @type {?} */ _maxY = 100;
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _color = cdt.defaultColorFunc;
                var /** @type {?} */ _graphHeight = cdt.graphHeight;
                var /** @type {?} */ _opacity = configData.color.opacity;
                var /** @type {?} */ _titleHeight = configData.title.height;
                var /** @type {?} */ _leftMargin = configData.margin.left;
                var /** @type {?} */ _topMargin = configData.margin.top;
                var /** @type {?} */ _bottomMargin = configData.margin.bottom;
                var /** @type {?} */ _betweenMargin = configData.margin.between;
                var /** @type {?} */ _innerRadiusPercent = cdt.innerRadiusPercent;
                var /** @type {?} */ _graphCenterTranslatePos = cdt.graphCenterTranslatePos;
                var /** @type {?} */ _pieClassName = configData.className.pie;
                var /** @type {?} */ _pieValueClassName = configData.className.pieNum;
                var /** @type {?} */ _pieInnerTitleClassName = configData.className.pieInnerTitle;
                var /** @type {?} */ _innerRadiusTitleTranslatePos = cdt.innerRadiusTitleTranslatePos;
                var /** @type {?} */ _innerRadiusTitle = cdt.innerRadiusTitle;
                var /** @type {?} */ _titleDisplay = configData.title.display;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ _labelDisplay = configData.label.display;
                var /** @type {?} */ _valueDisplay = configData.pie.value.display;
                var /** @type {?} */ _percentDisplay = configData.pie.percent.display;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                var /** @type {?} */ dataSet = new Array();
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        var /** @type {?} */ _num = dataSetJson.data[i].value;
                        dataSet.push(_num);
                    }
                }
                var /** @type {?} */ _sum = d3.sum(dataSet);
                var /** @type {?} */ pie = d3.pie();
                var /** @type {?} */ arc = d3.arc()
                    .innerRadius(_graphHeight * _innerRadiusPercent / 100)
                    .outerRadius(_graphHeight / 2);
                var /** @type {?} */ pieElements = svgContainer.selectAll('path')
                    .data(pie(dataSet))
                    .enter()
                    .append('g')
                    .attr('transform', _graphCenterTranslatePos);
                var /** @type {?} */ _makeCenterTitle = function () {
                    if (_valueDisplay && _percentDisplay) {
                        var /** @type {?} */ _st = _innerRadiusTitle + ':' + _sum + ' (100%)';
                        return _st;
                    }
                    if (_percentDisplay) {
                        return '100%';
                    }
                    if (_valueDisplay) {
                        return _innerRadiusTitle + ':' + _sum;
                    }
                };
                var /** @type {?} */ textElements = svgContainer.append('text')
                    .attr('class', _pieInnerTitleClassName)
                    .attr('transform', _innerRadiusTitleTranslatePos)
                    .text(_makeCenterTitle);
                var /** @type {?} */ _arc = pieElements.append('path')
                    .attr('class', _pieClassName)
                    .style('fill', function (d, i) {
                    return _color(i);
                })
                    .attr('fill-opacity', _opacity);
                //  For d3Version4 animation is not available now
                //  if (_animation) {
                //      _arc.transition()
                //      .duration(_animationDuration)
                //      .delay((d,i)=> {
                //          return i *1000;
                //      })
                //      .attrTween('d',(d: any,i: number) =>  {
                //          const _interpolate = d3.interpolateObject(
                //              { startAngle:d.startAngle,endAngle:d.startAngle }
                //              { startAngle:d.startAngle,endAngle:d.endAngle }
                //          )
                //          return (t) {
                //              return arc(_interpolate(t));
                //          }
                //      })
                //  }
                //  else{
                //      _arc.attr('d',arc);
                //  }
                _arc.attr('d', arc);
                pieElements.append('text')
                    .attr('class', _pieValueClassName)
                    .attr('transform', function (d, i) {
                    return 'translate(' + arc.centroid(d) + ')';
                })
                    .text(function (d, i) {
                    if (_valueDisplay && _percentDisplay) {
                        var /** @type {?} */ _percentSt = String(Math.ceil(d.value / _sum * 100));
                        var /** @type {?} */ _st = String(d.value) + ' (' + _percentSt + '%)';
                        return _st;
                    }
                    if (_percentDisplay) {
                        var /** @type {?} */ _percentSt = String(Math.ceil(d.value / _sum * 100));
                        var /** @type {?} */ _st = _percentSt + '%';
                        return _st;
                    }
                    if (_valueDisplay) {
                        return d.value;
                    }
                });
                // ---CALL buildTitle-----------------
                if (_titleDisplay) {
                    this.drawTitle(cdt);
                }
                // ------------------------------------
                // ---CALL buildLegend-----------------
                if (_legendDisplay) {
                    var /** @type {?} */ _legendDataSet = new Array();
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, _color(i)));
                        }
                    }
                    this.buildLegend(cdt, _legendDataSet);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildBar = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('In  buildBar----------------');
                var /** @type {?} */ _yDataSet = new Array();
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        for (var /** @type {?} */ j in dataSetJson.data[i].y) {
                            if (dataSetJson.data[i].y.hasOwnProperty(j)) {
                                var /** @type {?} */ _y = dataSetJson.data[i].y[j];
                                _yDataSet.push(_y);
                            }
                        }
                    }
                }
                var /** @type {?} */ _maxX = 0;
                var /** @type {?} */ _maxY = 0;
                _maxY = d3.max(_yDataSet);
                _maxX = 100;
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _barValueClass = configData.className.barValue;
                var /** @type {?} */ _color = cdt.defaultColorFunc;
                var /** @type {?} */ _seriesNum = dataSetJson.series.length;
                var /** @type {?} */ _columnNum = _yDataSet.length;
                var /** @type {?} */ _initPosY = cdt.graphInitYPos;
                var /** @type {?} */ _graphHeight = cdt.graphHeight;
                var /** @type {?} */ _graphWidth = cdt.graphWidth;
                var /** @type {?} */ _opacity = configData.color.opacity;
                var /** @type {?} */ _titleHeight = configData.title.height;
                var /** @type {?} */ _titleDisplay = configData.title.display;
                var /** @type {?} */ _leftMargin = configData.margin.left;
                var /** @type {?} */ _topMargin = configData.margin.top;
                var /** @type {?} */ _bottomMargin = configData.margin.bottom;
                var /** @type {?} */ _betweenMargin = configData.margin.between;
                var /** @type {?} */ _legendDisplay = configData.legend.display;
                var /** @type {?} */ _labelDisplay = configData.label.display;
                var /** @type {?} */ _gridYDisplay = configData.grid.y.display;
                var /** @type {?} */ _animation = configData.animation.enable;
                var /** @type {?} */ _animationDuration = configData.animation.duration;
                var /** @type {?} */ _barWidth = (_graphWidth - (_betweenMargin * _columnNum / _seriesNum)) / _columnNum;
                var /** @type {?} */ _columnWidth = (_graphWidth / _columnNum);
                var /** @type {?} */ _graphYScale = cdt.graphYScale;
                var /** @type {?} */ yBarScale = d3.scaleLinear()
                    .domain([0, _maxY])
                    .range([_maxY * _graphYScale, 0]);
                var /** @type {?} */ _barPadding = _betweenMargin;
                var /** @type {?} */ grpGraph = svgContainer.selectAll('g')
                    .data(_yDataSet)
                    .enter()
                    .append('g')
                    .attr('transform', function (d, i) {
                    var /** @type {?} */ _padding = ((i % _seriesNum) === 0) ? _barPadding : 0;
                    return 'translate(' + (_padding + _columnWidth * i) + ')';
                })
                    .style('fill', function (d, i) {
                    var /** @type {?} */ _remnant = (i % _seriesNum);
                    return _color(_remnant);
                })
                    .attr('fill-opacity', _opacity);
                var /** @type {?} */ _rect = grpGraph.append('rect');
                if (_animation) {
                    _rect.attr('x', _leftMargin)
                        .attr('height', 0)
                        .attr('y', function (d) {
                        return _initPosY;
                    })
                        .attr('width', _barWidth - _barPadding)
                        .transition()
                        .duration(_animationDuration)
                        .attr('y', function (d) {
                        return yBarScale(d) + _initPosY;
                    })
                        .attr('height', function (d) {
                        return _graphHeight - yBarScale(d);
                    });
                }
                else {
                    _rect.attr('x', _leftMargin)
                        .attr('y', function (d) {
                        return yBarScale(d) + _initPosY;
                    })
                        .attr('width', _barWidth - _barPadding)
                        .attr('height', function (d) {
                        return _graphHeight - yBarScale(d);
                    });
                }
                var /** @type {?} */ textBarValue = grpGraph.append('text');
                textBarValue
                    .attr('class', _barValueClass)
                    .attr('x', _leftMargin)
                    .attr('y', function (d) {
                    return yBarScale(d) + _initPosY;
                })
                    .text(function (d) {
                    return d;
                });
                // ------------------------------------
                // ---CALL buildAxis-----------------
                this.buildYAxis(cdt);
                //  ------------------------------------
                //  ---CALL drawXAxisLabel-----------------
                if (_labelDisplay) {
                    var /** @type {?} */ _labelArray = new Array();
                    for (var /** @type {?} */ i in dataSetJson.data) {
                        if (dataSetJson.data.hasOwnProperty(i)) {
                            _labelArray.push(dataSetJson.data[i].x);
                        }
                    }
                    this.drawXAxisLabel(cdt, _labelArray, BAR_CHART_TYPE_NAME);
                }
                this.drawXBaseLine(cdt);
                //  ------------------------------------
                //  ---CALL buildLegend-----------------
                var /** @type {?} */ _legendDataSet = new Array();
                for (var /** @type {?} */ i in dataSetJson.series) {
                    if (dataSetJson.series.hasOwnProperty(i)) {
                        _legendDataSet.push(new O2LegendData(dataSetJson.series[i], _color(i)));
                    }
                }
                this.buildLegend(cdt, _legendDataSet);
                // ------------------------------------
                // ---CALL buildTitle-----------------
                if (_titleDisplay) {
                    this.drawTitle(cdt);
                }
                if (_gridYDisplay) {
                    this.drawYGrid(cdt);
                }
            };
        /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildLine = /**
         * @param {?} svgContainer
         * @param {?} configData
         * @param {?} dataSetJson
         * @param {?} svgWidth
         * @param {?} svgHeight
         * @return {?}
         */
            function (svgContainer, configData, dataSetJson, svgWidth, svgHeight) {
                console.log('in buildTest-------------------');
                var /** @type {?} */ _groupMaxY = new Array();
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        var /** @type {?} */ _gMaxY = 0;
                        for (var /** @type {?} */ j in dataSetJson.data[i].value) {
                            if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                                if (_gMaxY < dataSetJson.data[i].value[j].y) {
                                    _gMaxY = dataSetJson.data[i].value[j].y;
                                }
                            }
                        }
                        _groupMaxY.push(_gMaxY);
                    }
                }
                var /** @type {?} */ _maxX = 0;
                var /** @type {?} */ _maxY = 0;
                _maxY = d3.max(_groupMaxY);
                _maxX = 100;
                var /** @type {?} */ cdt = new O2Common(svgContainer, configData, _maxX, _maxY, svgWidth, svgHeight);
                var /** @type {?} */ _color = cdt.defaultColorFunc;
                var /** @type {?} */ _columnNum = dataSetJson.data[0].value.length;
                var /** @type {?} */ _columnWidth = cdt.graphWidth / _columnNum;
                console.log(_columnWidth);
                if (configData.grid.y.display) {
                    this.drawYGrid(cdt);
                }
                //  O2IdValueData
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        var /** @type {?} */ _lineArray = new Array();
                        for (var /** @type {?} */ j in dataSetJson.data[i].value) {
                            if (dataSetJson.data[i].value.hasOwnProperty(j)) {
                                var /** @type {?} */ idValue = new O2IdValueData(parseInt(j, 10), dataSetJson.data[i].value[j].y);
                                _lineArray.push(idValue);
                            }
                        }
                        var /** @type {?} */ num = parseInt(i, 10);
                        this.drawSingleLine(cdt, _lineArray, num);
                    }
                }
                // ------------------------------------
                // ---CALL buildTitle-----------------
                this.drawTitle(cdt);
                // ------------------------------------
                // ---CALL buildAxis-----------------
                this.buildYAxis(cdt);
                this.drawXBaseLine(cdt);
                //  ------------------------------------
                //  ---CALL drawXAxisLabel-----------------
                var /** @type {?} */ _labelArray = new Array();
                for (var /** @type {?} */ i in dataSetJson.data[0].value) {
                    if (dataSetJson.data[0].value.hasOwnProperty(i)) {
                        _labelArray.push(dataSetJson.data[0].value[i].x);
                    }
                }
                this.drawXAxisLabel(cdt, _labelArray, LINE_CHART_TYPE_NAME);
                //  ------------------------------------
                //  ---CALL buildLegend-----------------
                var /** @type {?} */ _legendDataSet = new Array();
                for (var /** @type {?} */ i in dataSetJson.data) {
                    if (dataSetJson.data.hasOwnProperty(i)) {
                        _legendDataSet.push(new O2LegendData(dataSetJson.data[i].name, _color(i)));
                    }
                }
                this.buildLegend(cdt, _legendDataSet);
            };
        /**
         * @param {?} o2Common
         * @param {?} dataSet
         * @param {?} lineNum
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.drawSingleLine = /**
         * @param {?} o2Common
         * @param {?} dataSet
         * @param {?} lineNum
         * @return {?}
         */
            function (o2Common, dataSet, lineNum) {
                console.log('in drawSingleLine-------------------');
                console.log(dataSet);
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                var /** @type {?} */ _maxX = cdt.maxXValue;
                var /** @type {?} */ _initXPos = cdt.axisXLabelInitXPos;
                var /** @type {?} */ _initYPos = cdt.axisXLabelInitYPos;
                var /** @type {?} */ _columnNum = dataSet.length;
                var /** @type {?} */ _columnWidth = cdt.graphWidth / (_columnNum - 1);
                var /** @type {?} */ _color = d3.scaleOrdinal(d3.schemeCategory10);
                var /** @type {?} */ _lineClassName = configData.className.multiLinePrefix + String(lineNum);
                var /** @type {?} */ _leftMargin = configData.margin.left;
                var /** @type {?} */ _bottomMargin = configData.margin.bottom;
                var /** @type {?} */ _yScale = cdt.graphYScale;
                var /** @type {?} */ line = d3.line()
                    .curve(d3.curveLinear)
                    .x(function (d) {
                    return _leftMargin + d.id * _columnWidth;
                })
                    .y(function (d) {
                    return cdt.svgHeight - _bottomMargin - (d.value * _yScale);
                });
                svgContainer.append('path')
                    .attr('class', _lineClassName)
                    .attr('d', line(dataSet));
                //  .attr('transform', cdt.axisTranslatePos)
            };
        /**
         * @param {?} o2Common
         * @param {?} _legendDataSet
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildLegend = /**
         * @param {?} o2Common
         * @param {?} _legendDataSet
         * @return {?}
         */
            function (o2Common, _legendDataSet) {
                console.log('in buildLegend-------------------');
                //  maxValues are meaningless
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                //  const cdt = new O2Common(configData, 100, 100, svgWidth, svgHeight);
                var /** @type {?} */ legendRectSize = configData.legend.rectWidth;
                var /** @type {?} */ legendSpacing = 10;
                var /** @type {?} */ ySpacing = configData.legend.ySpacing;
                var /** @type {?} */ initPosX = cdt.legendInitXPos;
                var /** @type {?} */ initPosY = cdt.legendInitYPos;
                var /** @type {?} */ opacity = configData.color.opacity;
                var /** @type {?} */ grpLegend = svgContainer.append('g')
                    .selectAll('g')
                    .data(_legendDataSet)
                    .enter()
                    .append('g')
                    .attr('class', 'legend')
                    .attr('transform', function (d, i) {
                    var /** @type {?} */ height = legendRectSize + ySpacing;
                    var /** @type {?} */ x = initPosX;
                    var /** @type {?} */ y = i * height + initPosY;
                    return 'translate(' + x + ', ' + y + ')';
                });
                grpLegend.append('rect')
                    .attr('width', legendRectSize)
                    .attr('height', legendRectSize)
                    .style('fill', function (d) {
                    return d.color;
                })
                    .style('stroke', function (d) {
                    return d.color;
                })
                    .attr('fill-opacity', opacity);
                grpLegend.append('text')
                    .attr('x', legendRectSize + legendSpacing)
                    .attr('y', legendRectSize)
                    .text(function (d) {
                    return d.title;
                });
            };
        /**
         * @param {?} o2Common
         * @param {?} labelDataSet
         * @param {?} chartType
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.drawXAxisLabel = /**
         * @param {?} o2Common
         * @param {?} labelDataSet
         * @param {?} chartType
         * @return {?}
         */
            function (o2Common, labelDataSet, chartType) {
                console.log('in drawXAxisLabel-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                // const _maxX = cdt.maxXValue;
                var /** @type {?} */ _initXPos = cdt.axisXLabelInitXPos;
                var /** @type {?} */ _initYPos = cdt.axisXLabelInitYPos;
                var /** @type {?} */ _columnNum = labelDataSet.length;
                var /** @type {?} */ _columnWidth = cdt.graphWidth / _columnNum;
                if (chartType === LINE_CHART_TYPE_NAME) {
                    _columnWidth = cdt.graphWidth / (_columnNum - 1);
                }
                var /** @type {?} */ grpLabel = svgContainer.append('g')
                    .selectAll('g')
                    .data(labelDataSet)
                    .enter()
                    .append('g')
                    .attr('class', configData.axisXText)
                    .attr('transform', function (d, i) {
                    var /** @type {?} */ _x = _initXPos + _columnWidth * i;
                    var /** @type {?} */ _y = _initYPos;
                    return 'translate(' + _x + ', ' + _y + ')';
                });
                grpLabel.append('text')
                    .attr('class', configData.className.axisXText)
                    .text(function (d, i) {
                    return d;
                });
            };
        /**
         * @param {?} o2Common
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.drawXBaseLine = /**
         * @param {?} o2Common
         * @return {?}
         */
            function (o2Common) {
                console.log('in drawXBaseLine-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                svgContainer.append('rect')
                    .attr('class', cdt.axisXBorderLineClassName)
                    .attr('width', cdt.axisXBorderWidth)
                    .attr('height', cdt.axisXBorderLineWidth)
                    .attr('transform', cdt.axisXBorderTranslatePos);
            };
        /**
         * @param {?} o2Common
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.buildYAxis = /**
         * @param {?} o2Common
         * @return {?}
         */
            function (o2Common) {
                console.log('in buildYAxis-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                var /** @type {?} */ _maxY = cdt.maxYValue;
                var /** @type {?} */ _graphYScale = cdt.graphYScale;
                var /** @type {?} */ _axisYScale = d3.scaleLinear()
                    .domain([0, _maxY])
                    .range([_maxY * _graphYScale, 0]);
                svgContainer.append('g')
                    .attr('class', cdt.axisClassName)
                    .attr('transform', cdt.axisTranslatePos)
                    .call(d3.axisLeft(_axisYScale));
            };
        /**
         * @param {?} o2Common
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.drawTitle = /**
         * @param {?} o2Common
         * @return {?}
         */
            function (o2Common) {
                console.log('in drawTitle-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                var /** @type {?} */ _title = configData.title.name;
                var /** @type {?} */ _xPos = cdt.titleInitXPos;
                var /** @type {?} */ _yPos = cdt.titleInitYPos;
                var /** @type {?} */ _titleClassName = configData.title.className;
                svgContainer.append('text')
                    .attr('class', _titleClassName)
                    .attr('x', _xPos)
                    .attr('y', _yPos)
                    .text(_title);
            };
        /**
         * @param {?} o2Common
         * @return {?}
         */
        Ng6UdmChartComponent.prototype.drawYGrid = /**
         * @param {?} o2Common
         * @return {?}
         */
            function (o2Common) {
                console.log('in buildYGrid-------------------');
                var /** @type {?} */ cdt = o2Common;
                var /** @type {?} */ configData = cdt.configData;
                var /** @type {?} */ svgContainer = cdt.svgContainer;
                var /** @type {?} */ _stepY = cdt.gridYStep;
                var /** @type {?} */ _maxY = cdt.maxYValue;
                var /** @type {?} */ _graphYScale = cdt.graphYScale;
                var /** @type {?} */ _gridClassName = configData.className.grid;
                var /** @type {?} */ _rangeY = d3.range(_stepY * _graphYScale, _maxY * _graphYScale, _stepY * _graphYScale);
                svgContainer.append('g')
                    .selectAll('line.y')
                    .data(_rangeY)
                    .enter()
                    .append('line')
                    .attr('class', _gridClassName)
                    .attr('x1', configData.margin.left)
                    .attr('y1', function (d, i) {
                    var /** @type {?} */ _y1 = cdt.svgHeight - configData.margin.bottom - d;
                    return _y1;
                })
                    .attr('x2', configData.margin.left + cdt.axisXBorderWidth)
                    .attr('y2', function (d, i) {
                    var /** @type {?} */ _y1 = cdt.svgHeight - configData.margin.bottom - d;
                    return _y1;
                });
            };
        Ng6UdmChartComponent.decorators = [
            { type: core.Component, args: [{
                        selector: 'lib-Ng6UdmChart',
                        template: "",
                        styles: []
                    },] },
        ];
        /** @nocollapse */
        Ng6UdmChartComponent.ctorParameters = function () {
            return [
                { type: core.ElementRef, },
            ];
        };
        Ng6UdmChartComponent.propDecorators = {
            "chartType": [{ type: core.Input },],
            "svgWidth": [{ type: core.Input },],
            "svgHeight": [{ type: core.Input },],
            "graphData": [{ type: core.Input },],
            "configData": [{ type: core.Input },],
        };
        return Ng6UdmChartComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var Ng6UdmChartModule = (function () {
        function Ng6UdmChartModule() {
        }
        Ng6UdmChartModule.decorators = [
            { type: core.NgModule, args: [{
                        imports: [],
                        declarations: [Ng6UdmChartComponent],
                        exports: [Ng6UdmChartComponent]
                    },] },
        ];
        return Ng6UdmChartModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    exports.LINE_CHART_TYPE_NAME = LINE_CHART_TYPE_NAME;
    exports.BAR_CHART_TYPE_NAME = BAR_CHART_TYPE_NAME;
    exports.PIE_CHART_TYPE_NAME = PIE_CHART_TYPE_NAME;
    exports.SCATTER_PLOT_CHART_TYPE_NAME = SCATTER_PLOT_CHART_TYPE_NAME;
    exports.HISTOGRAM_CHART_TYPE_NAME = HISTOGRAM_CHART_TYPE_NAME;
    exports.STACK_BAR_CHART_TYPE_NAME = STACK_BAR_CHART_TYPE_NAME;
    exports.GEO_MAP_CHART_TYPE_NAME = GEO_MAP_CHART_TYPE_NAME;
    exports.GEO_ORTHOGRAPHIC_CHART_TYPE_NAME = GEO_ORTHOGRAPHIC_CHART_TYPE_NAME;
    exports.TREE_MAP_CHART_TYPE_NAME = TREE_MAP_CHART_TYPE_NAME;
    exports.PACK_LAYOUT_CHART_TYPE_NAME = PACK_LAYOUT_CHART_TYPE_NAME;
    exports.CHOROPLETH_CHART_TYPE_NAME = CHOROPLETH_CHART_TYPE_NAME;
    exports.TREE_CHART_TYPE_NAME = TREE_CHART_TYPE_NAME;
    exports.SANKEY_CHART_TYPE_NAME = SANKEY_CHART_TYPE_NAME;
    exports.FORCE_CHART_TYPE_NAME = FORCE_CHART_TYPE_NAME;
    exports.Ng6UdmChartComponent = Ng6UdmChartComponent;
    exports.Ng6UdmChartModule = Ng6UdmChartModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibmc2LXVkbS1jaGFydC51bWQuanMubWFwIiwic291cmNlcyI6WyJuZzovL25nNi11ZG0tY2hhcnQvbGliL3NoYXJlZC9jaGFydC1jb25zdC50cyIsIm5nOi8vbmc2LXVkbS1jaGFydC9saWIvc2hhcmVkL28yY29tbW9uLnRzIiwibmc6Ly9uZzYtdWRtLWNoYXJ0L2xpYi9uZzYtdWRtLWNoYXJ0LmNvbXBvbmVudC50cyIsIm5nOi8vbmc2LXVkbS1jaGFydC9saWIvbmc2LXVkbS1jaGFydC5tb2R1bGUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNvbnN0IExJTkVfQ0hBUlRfVFlQRV9OQU1FICA9ICdsaW5lJztcclxuZXhwb3J0IGNvbnN0IEJBUl9DSEFSVF9UWVBFX05BTUUgPSAnYmFyJztcclxuZXhwb3J0IGNvbnN0IFBJRV9DSEFSVF9UWVBFX05BTUUgPSAncGllJztcclxuZXhwb3J0IGNvbnN0IFNDQVRURVJfUExPVF9DSEFSVF9UWVBFX05BTUUgPSAnc2NhdHRlclBsb3QnO1xyXG5leHBvcnQgY29uc3QgSElTVE9HUkFNX0NIQVJUX1RZUEVfTkFNRSA9ICdoaXN0b2dyYW0nO1xyXG5leHBvcnQgY29uc3QgU1RBQ0tfQkFSX0NIQVJUX1RZUEVfTkFNRSA9ICdzdGFja0Jhcic7XHJcbmV4cG9ydCBjb25zdCBHRU9fTUFQX0NIQVJUX1RZUEVfTkFNRSA9ICdnZW9NYXAnO1xyXG5leHBvcnQgY29uc3QgR0VPX09SVEhPR1JBUEhJQ19DSEFSVF9UWVBFX05BTUUgPSAnZ2VvT3J0aG9ncmFwaGljJztcclxuZXhwb3J0IGNvbnN0IFRSRUVfTUFQX0NIQVJUX1RZUEVfTkFNRSA9ICd0cmVlTWFwJztcclxuZXhwb3J0IGNvbnN0IFBBQ0tfTEFZT1VUX0NIQVJUX1RZUEVfTkFNRSA9ICdwYWNrTGF5b3V0JztcclxuZXhwb3J0IGNvbnN0IENIT1JPUExFVEhfQ0hBUlRfVFlQRV9OQU1FID0gJ2Nob3JvcGxldGgnO1xyXG5leHBvcnQgY29uc3QgVFJFRV9DSEFSVF9UWVBFX05BTUUgPSAndHJlZSc7XHJcbmV4cG9ydCBjb25zdCBTQU5LRVlfQ0hBUlRfVFlQRV9OQU1FID0gJ3NhbmtleSc7XHJcbmV4cG9ydCBjb25zdCBGT1JDRV9DSEFSVF9UWVBFX05BTUUgPSAnZm9yY2UnIDtcclxuIiwiaW1wb3J0ICogYXMgZDMgZnJvbSAnZDMnO1xyXG5cclxuXHJcblxyXG5leHBvcnQgY2xhc3MgTzJDb21tb24ge1xyXG5cclxuICAgIGNvbnN0cnVjdG9yKFxyXG4gICAgICAgIHB1YmxpYyBzdmdDb250YWluZXI6IGFueSxcclxuICAgICAgICBwdWJsaWMgY29uZmlnRGF0YTogYW55LFxyXG4gICAgICAgIHB1YmxpYyBhdXRvTWF4WDogbnVtYmVyLFxyXG4gICAgICAgIHB1YmxpYyBhdXRvTWF4WTogbnVtYmVyLFxyXG4gICAgICAgIHB1YmxpYyBzdmdXaWR0aDogbnVtYmVyLFxyXG4gICAgICAgIHB1YmxpYyBzdmdIZWlnaHQ6IG51bWJlclxyXG4gICAgKSB7IH1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLSAgQ0xBU1MgTkFNRSAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbnB1YmxpYyBnZXQgYXhpc0NsYXNzTmFtZSgpOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuIHRoaXMuY29uZmlnRGF0YS5jbGFzc05hbWUuYXhpcztcclxufVxyXG5cclxucHVibGljIGdldCBsaW5lQ2xhc3NOYW1lKCk6IHN0cmluZyB7XHJcbiAgICByZXR1cm4gdGhpcy5jb25maWdEYXRhLmNsYXNzTmFtZS5saW5lO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGF4aXNYQm9yZGVyTGluZUNsYXNzTmFtZSgpOiBzdHJpbmcge1xyXG4gICAgcmV0dXJuIHRoaXMuY29uZmlnRGF0YS5jbGFzc05hbWUuYXhpc1hCb3JkZXI7XHJcbn1cclxuXHJcblxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tICBNQVggVkFMVUUgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxucHVibGljIGdldCBtYXhYVmFsdWUoKTogbnVtYmVyIHtcclxuICAgIGxldCBfbWF4WCA9IHRoaXMuYXV0b01heFg7XHJcbiAgICBpZiAoIXRoaXMuY29uZmlnRGF0YS5tYXhWYWx1ZS5hdXRvKSB7XHJcbiAgICAgICAgX21heFggPSB0aGlzLmNvbmZpZ0RhdGEubWF4VmFsdWUueDtcclxuICAgIH1cclxuICAgIHJldHVybiBfbWF4WDtcclxufVxyXG5cclxucHVibGljIGdldCBtYXhZVmFsdWUoKTogbnVtYmVyIHtcclxuICAgIGxldCBfbWF4WSA9IHRoaXMuYXV0b01heFk7XHJcbiAgICBpZiAoIXRoaXMuY29uZmlnRGF0YS5tYXhWYWx1ZS5hdXRvKSB7XHJcbiAgICAgICAgX21heFkgPSB0aGlzLmNvbmZpZ0RhdGEubWF4VmFsdWUueTtcclxuICAgIH1cclxuICAgIHJldHVybiBfbWF4WTtcclxufVxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tICBHUkFQSCAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxucHVibGljIGdldCBncmFwaEluaXRYUG9zKCk6IG51bWJlciB7XHJcbiAgICBsZXQgX2ludFggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnQ7XHJcbiAgICBpZiAodGhpcy5jb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5ICYmIHRoaXMuY29uZmlnRGF0YS5sZWdlbmQucG9zaXRpb24gIT09ICdyaWdodCcpIHtcclxuICAgICAgICBfaW50WCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLmxlZ2VuZC50b3RhbFdpZHRoO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIF9pbnRYO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGdyYXBoSW5pdFlQb3MoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF9pbnRZID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi50b3BcclxuICAgICAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLnRpdGxlLmhlaWdodDtcclxuICAgIHJldHVybiBfaW50WTtcclxufVxyXG5cclxucHVibGljIGdldCBncmFwaFlTY2FsZSgpOiBudW1iZXIge1xyXG4gICAgcmV0dXJuIHRoaXMuZ3JhcGhIZWlnaHQgLyB0aGlzLm1heFlWYWx1ZTtcclxufVxyXG5cclxucHVibGljIGdldCBncmFwaFhTY2FsZSgpOiBudW1iZXIge1xyXG4gICAgcmV0dXJuIHRoaXMuZ3JhcGhXaWR0aCAvIHRoaXMubWF4WFZhbHVlO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGdyYXBoV2lkdGgoKTogbnVtYmVyIHtcclxuICAgIGxldCBfbWFyZ2luID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnJpZ2h0O1xyXG4gICAgaWYgKHRoaXMuY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheSkge1xyXG4gICAgICAgIF9tYXJnaW4gKz0gdGhpcy5jb25maWdEYXRhLmxlZ2VuZC50b3RhbFdpZHRoO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB0aGlzLnN2Z1dpZHRoIC0gX21hcmdpbjtcclxufVxyXG5cclxucHVibGljIGdldCBncmFwaEhlaWdodCgpOiBudW1iZXIge1xyXG4gICAgY29uc3QgX2ggPSB0aGlzLnN2Z0hlaWdodFxyXG4gICAgICAgICAgICAgICAgLSB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0XHJcbiAgICAgICAgICAgICAgICAtIHRoaXMuY29uZmlnRGF0YS5tYXJnaW4udG9wXHJcbiAgICAgICAgICAgICAgICAtIHRoaXMuY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tO1xyXG4gICAgcmV0dXJuIF9oO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGdyYXBoQ2VudGVyUG9zKCk6IGFueSB7XHJcbiAgICBjb25zdCBfeHlBcnJheTogQXJyYXk8bnVtYmVyPiA9IG5ldyBBcnJheSgpO1xyXG4gICAgY29uc3QgX3ggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgICAgICsgdGhpcy5ncmFwaFdpZHRoIC8gMjtcclxuICAgIGNvbnN0IF95ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi50b3BcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0XHJcbiAgICAgICAgICAgICsgdGhpcy5ncmFwaEhlaWdodCAvIDI7XHJcbiAgICBfeHlBcnJheS5wdXNoKF94KTtcclxuICAgIF94eUFycmF5LnB1c2goX3kpO1xyXG4gICAgcmV0dXJuIF94eUFycmF5O1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGdyYXBoQ2VudGVyVHJhbnNsYXRlUG9zKCk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBfeCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICArIHRoaXMuZ3JhcGhXaWR0aCAvIDI7XHJcbiAgICBjb25zdCBfeSA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4udG9wXHJcbiAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLnRpdGxlLmhlaWdodFxyXG4gICAgICAgICAgICArIHRoaXMuZ3JhcGhIZWlnaHQgLyAyO1xyXG4gICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIFN0cmluZyhfeCkgKyAnLCAnICsgU3RyaW5nKF95KSArICcpJztcclxufVxyXG5cclxucHVibGljIGdldCBncmFwaEluaXRUcmFuc2xhdGVQb3MoKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IF94ID0gdGhpcy5ncmFwaEluaXRYUG9zO1xyXG4gICAgY29uc3QgX3kgPSB0aGlzLmdyYXBoSW5pdFlQb3M7XHJcbiAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgU3RyaW5nKF94KSArICcsICcgKyBTdHJpbmcoX3kpICsgJyknO1xyXG59XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0gIEFYSVMgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5wdWJsaWMgZ2V0IGF4aXNYTGFiZWxJbml0WFBvcygpOiBudW1iZXIge1xyXG4gICAgY29uc3QgX3ggPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEuYXhpcy54TGFiZWwubGVmdE1hcmdpbjtcclxuICAgIHJldHVybiBfeDtcclxufVxyXG5cclxucHVibGljIGdldCBheGlzWExhYmVsSW5pdFlQb3MoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF95ID0gdGhpcy5zdmdIZWlnaHRcclxuICAgICAgICAgICAgLSB0aGlzLmNvbmZpZ0RhdGEuYXhpcy54TGFiZWwuYm90dG9tTWFyZ2luO1xyXG4gICAgcmV0dXJuIF95O1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGF4aXNUcmFuc2xhdGVQb3MoKTogc3RyaW5nIHtcclxuICAgIGNvbnN0IF94ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0O1xyXG4gICAgY29uc3QgX3kgPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHQ7XHJcbiAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgU3RyaW5nKF94KSArICcsICcgKyBTdHJpbmcoX3kpICsgJyknO1xyXG59XHJcblxyXG5cclxucHVibGljIGdldCBheGlzWEJvcmRlckxpbmVXaWR0aCgpOiBudW1iZXIge1xyXG4gICAgcmV0dXJuIHRoaXMuY29uZmlnRGF0YS5heGlzLmJvcmRlckxpbmVXaWR0aDtcclxufVxyXG5cclxucHVibGljIGdldCBheGlzWUJvcmRlckhlaWdodCgpOiBudW1iZXIge1xyXG4gICAgY29uc3QgX21hcmdpbiA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4udG9wXHJcbiAgICAgICAgICAgICAgICAgICAgKyB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbVxyXG4gICAgICAgICAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLnRpdGxlLmhlaWdodDtcclxuICAgIHJldHVybiB0aGlzLnN2Z0hlaWdodCAtIF9tYXJnaW47XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgYXhpc1hCb3JkZXJXaWR0aCgpOiBudW1iZXIge1xyXG4gICAgbGV0IF9tYXJnaW4gPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnRcclxuICAgICAgICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ucmlnaHQ7XHJcbiAgICBpZiAodGhpcy5jb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5KSB7XHJcbiAgICAgICAgX21hcmdpbiArPSB0aGlzLmNvbmZpZ0RhdGEubGVnZW5kLnRvdGFsV2lkdGg7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGhpcy5zdmdXaWR0aCAtIF9tYXJnaW47XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgYXhpc1lPcmllbnQoKTogc3RyaW5nIHtcclxuICAgIHJldHVybiAnbGVmdCc7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgYXhpc1hPcmllbnQoKTogc3RyaW5nIHtcclxuICAgIHJldHVybiAnYm90dG9tJztcclxufVxyXG5wdWJsaWMgZ2V0IGF4aXNYQm9yZGVyVHJhbnNsYXRlUG9zKCk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBzWXBvcyA9IFN0cmluZyh0aGlzLnN2Z0hlaWdodCAtIHRoaXMuY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tKTtcclxuICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLmxlZnQgKyAnLCAnICsgc1lwb3MgKyAnKSc7XHJcbn1cclxuXHJcblxyXG5cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tICBSQURJVVMgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5wdWJsaWMgZ2V0IGlubmVyUmFkaXVzUGVyY2VudCgpOiBudW1iZXIge1xyXG4gICAgcmV0dXJuIHRoaXMuY29uZmlnRGF0YS5waWUuaW5uZXJSYWRpdXMucGVyY2VudDtcclxufVxyXG5cclxucHVibGljIGdldCBpbm5lclJhZGl1c1RpdGxlKCk6IHN0cmluZyB7XHJcbiAgICByZXR1cm4gdGhpcy5jb25maWdEYXRhLnBpZS5pbm5lclJhZGl1cy50aXRsZTtcclxufVxyXG5cclxucHVibGljIGdldCBpbm5lclJhZGl1c1RpdGxlVHJhbnNsYXRlUG9zKCk6IHN0cmluZyB7XHJcbiAgICBjb25zdCBfeCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICAgICAgKyB0aGlzLmdyYXBoV2lkdGggLyAyO1xyXG4gICAgY29uc3QgX3kgPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHRcclxuICAgICAgICAgICAgKyB0aGlzLmdyYXBoSGVpZ2h0IC8gMlxyXG4gICAgICAgICAgICArIDU7XHJcbiAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgU3RyaW5nKF94KSArICcsICcgKyBTdHJpbmcoX3kpICsgJyknO1xyXG59XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0gIExFR0VORCAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbnB1YmxpYyBnZXQgbGVnZW5kSW5pdFhQb3MoKTogbnVtYmVyIHtcclxuICAgIGxldCBfeCA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4ubGVmdFxyXG4gICAgICAgICAgICAgICAgKyB0aGlzLmdyYXBoV2lkdGhcclxuICAgICAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLmxlZ2VuZC5pbml0WFBvcyA7XHJcbiAgICBpZiAodGhpcy5jb25maWdEYXRhLmxlZ2VuZC5wb3NpdGlvbiAhPT0gJ3JpZ2h0Jykge1xyXG4gICAgICAgIF94ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS5sZWdlbmQuaW5pdFhQb3MgO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIF94O1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGxlZ2VuZEluaXRZUG9zKCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfeSA9IHRoaXMuY29uZmlnRGF0YS5tYXJnaW4udG9wXHJcbiAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLnRpdGxlLmhlaWdodFxyXG4gICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS5sZWdlbmQuaW5pdFlQb3M7XHJcbiAgICByZXR1cm4gX3k7XHJcbn1cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLSAgR1JJRCAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbnB1YmxpYyBnZXQgZ3JpZFlTdGVwKCk6IG51bWJlciB7XHJcbiAgICBjb25zdCBfbWF4WSA9IE1hdGguY2VpbCh0aGlzLm1heFlWYWx1ZSAvIDEwMCkgKiAxMDtcclxuICAgIGNvbnN0IF9saW5lTnVtID0gMTA7XHJcbiAgICBjb25zdCBfc3RlcCA9IE1hdGguY2VpbChfbWF4WSAvIF9saW5lTnVtKSAqIF9saW5lTnVtO1xyXG4gICAgcmV0dXJuIF9zdGVwO1xyXG59XHJcblxyXG5wdWJsaWMgZ2V0IGdyaWRYU3RlcCgpOiBudW1iZXIge1xyXG4gICAgY29uc3QgX21heFggPSBNYXRoLmNlaWwodGhpcy5tYXhYVmFsdWUgLyAxMDApICogMTA7XHJcbiAgICBjb25zdCBfbGluZU51bSA9IDEwO1xyXG4gICAgY29uc3QgX3N0ZXAgPSBNYXRoLmNlaWwoX21heFggLyBfbGluZU51bSkgKiBfbGluZU51bTtcclxuICAgIHJldHVybiBfc3RlcDtcclxufVxyXG5cclxuXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLSAgVElUTEUgIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5wdWJsaWMgZ2V0IHRpdGxlSW5pdFhQb3MoKTogbnVtYmVyIHtcclxuICAgIGNvbnN0IF94ID0gdGhpcy5jb25maWdEYXRhLm1hcmdpbi5sZWZ0XHJcbiAgICAgICAgICAgICsgKHRoaXMuZ3JhcGhXaWR0aCArIHRoaXMuY29uZmlnRGF0YS5sZWdlbmQudG90YWxXaWR0aCkgLyAyXHJcbiAgICAgICAgICAgICsgdGhpcy5jb25maWdEYXRhLnRpdGxlLmxlZnRNYXJnaW47XHJcbiAgICByZXR1cm4gX3g7XHJcbn1cclxuXHJcbnB1YmxpYyBnZXQgdGl0bGVJbml0WVBvcygpOiBudW1iZXIge1xyXG4gICAgY29uc3QgX3kgPSB0aGlzLmNvbmZpZ0RhdGEubWFyZ2luLnRvcFxyXG4gICAgICAgICAgICArIHRoaXMuY29uZmlnRGF0YS50aXRsZS5oZWlnaHRcclxuICAgICAgICAgICAgLSB0aGlzLmNvbmZpZ0RhdGEudGl0bGUuYm90dG9tTWFyZ2luO1xyXG4gICAgcmV0dXJuIF95O1xyXG59XHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0gIENPTE9SICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxucHVibGljIGdldCBkZWZhdWx0Q29sb3JGdW5jKCk6IGFueSB7XHJcbiAgICBsZXQgX2NvbG9yOiBhbnk7XHJcbiAgICBpZiAodGhpcy5jb25maWdEYXRhLmNvbG9yLmF1dG8gKSB7XHJcbiAgICAgICAgaWYgKHRoaXMuY29uZmlnRGF0YS5jb2xvci5kZWZhdWx0Q29sb3JOdW1iZXIgPT09ICcyMCcpIHtcclxuICAgICAgICAgICAgX2NvbG9yID0gZDMuc2NhbGVPcmRpbmFsKGQzLnNjaGVtZUNhdGVnb3J5MjApO1xyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIF9jb2xvciA9IGQzLnNjYWxlT3JkaW5hbChkMy5zY2hlbWVDYXRlZ29yeTEwKTtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gX2NvbG9yO1xyXG59XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBPMkxpbmVEYXRhIHtcclxuY29uc3RydWN0b3IoXHJcbiAgICBwdWJsaWMgZGF0YTogQXJyYXk8bnVtYmVyPixcclxuICAgIHB1YmxpYyBjb2xvcjogc3RyaW5nLFxyXG4gICAgcHVibGljIGRhc2hlZEFycmF5OiBzdHJpbmcsXHJcbiAgICBwdWJsaWMgaW50ZXJwb2xhdGU6IHN0cmluZ1xyXG4gICAgKSB7IH1cclxufVxyXG5cclxuXHJcbmV4cG9ydCBjbGFzcyBPMkxlZ2VuZERhdGEge1xyXG5jb25zdHJ1Y3RvcihcclxuICAgcHVibGljIHRpdGxlOiBzdHJpbmcsXHJcbiAgICBwdWJsaWMgY29sb3I6IHN0cmluZyApIHsgfVxyXG5cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE8yU2NhdHRlclBsb3REYXRhIHtcclxuY29uc3RydWN0b3IoXHJcbiAgIHB1YmxpYyB4OiBudW1iZXIsXHJcbiAgIHB1YmxpYyB5OiBudW1iZXIsXHJcbiAgIHB1YmxpYyByOiBudW1iZXIgKSB7IH1cclxuXHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBPMlN0YWNrQmFyRGF0YSB7XHJcbmNvbnN0cnVjdG9yKFxyXG4gICBwdWJsaWMgeDogc3RyaW5nLFxyXG4gICBwdWJsaWMgeTogbnVtYmVyXHJcbiAgICkgeyB9XHJcblxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTzJJZFZhbHVlRGF0YSB7XHJcbmNvbnN0cnVjdG9yKFxyXG4gICBwdWJsaWMgaWQ6IG51bWJlcixcclxuICAgIHB1YmxpYyB2YWx1ZTogbnVtYmVyXHJcbiAgICkgeyB9XHJcblxyXG59XHJcblxyXG4vLyBleHBvcnQgY2xhc3MgTzJLZXlWYWx1ZURhdGEge1xyXG4vLyAgICAgY29uc3RydWN0b3IoXHJcbi8vICAgICAgICBwdWJsaWMga2V5OiBzdHJpbmcsXHJcbi8vIFx0ICAgcHVibGljIHZhbHVlOiBudW1iZXJcclxuLy8gICAgICAgICkgeyB9XHJcbi8vIH1cclxuLy8gZXhwb3J0IGNsYXNzIE8yRGF0ZUtWQXJyYXlEYXRhIHtcclxuLy8gICAgIGNvbnN0cnVjdG9yKFxyXG4vLyAgICAgICAgcHVibGljIGRhdGU6IERhdGUsXHJcbi8vIFx0ICAgcHVibGljIGt2QXJyYXk6IEFycmF5PE8yS2V5VmFsdWVEYXRhPlxyXG4vLyAgICAgICAgKSB7IH1cclxuLy8gfVxyXG4vLyBleHBvcnQgY2xhc3MgTzJEYXRlU3RLVkFycmF5RGF0YSB7XHJcbi8vICAgICBjb25zdHJ1Y3RvcihcclxuLy8gICAgICAgIHB1YmxpYyBkYXRlU3Q6IHN0cmluZyxcclxuLy8gXHQgICBwdWJsaWMga3ZBcnJheTogQXJyYXk8TzJLZXlWYWx1ZURhdGE+XHJcbi8vICAgICAgICApIHsgfVxyXG4vLyB9IiwiaW1wb3J0IHtDb21wb25lbnQsIERpcmVjdGl2ZSwgSW5wdXQsIE9uSW5pdCwgSW5qZWN0LCBFbGVtZW50UmVmIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge091dHB1dCwgT25DaGFuZ2VzLCBTaW1wbGVDaGFuZ2V9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtPMkNvbW1vbiwgTzJMZWdlbmREYXRhLCBPMlNjYXR0ZXJQbG90RGF0YSwgTzJTdGFja0JhckRhdGEsIE8yTGluZURhdGEsIE8ySWRWYWx1ZURhdGF9IGZyb20gJy4vc2hhcmVkL28yY29tbW9uJztcblxuaW1wb3J0ICogYXMgQ2hhcnRDb25zdCBmcm9tICcuL3NoYXJlZC9jaGFydC1jb25zdCc7XG5pbXBvcnQgKiBhcyBkMyBmcm9tICdkMyc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2xpYi1OZzZVZG1DaGFydCcsXG4gIHRlbXBsYXRlOiBgYCxcbiAgc3R5bGVzOiBbXVxufSlcbmV4cG9ydCBjbGFzcyBOZzZVZG1DaGFydENvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCAsIE9uQ2hhbmdlcyB7XG4gIEBJbnB1dCgpIGNoYXJ0VHlwZTogc3RyaW5nO1xuICBASW5wdXQoKSBzdmdXaWR0aDogc3RyaW5nO1xuICBASW5wdXQoKSBzdmdIZWlnaHQ6IHN0cmluZztcbiAgQElucHV0KCkgZ3JhcGhEYXRhOiBBcnJheTxudW1iZXI+O1xuICBASW5wdXQoKSBjb25maWdEYXRhOiBhbnk7XG5cbiAgcm9vdDogYW55O1xuXG4gIGNvbnN0cnVjdG9yKCBlbGVtZW50UmVmOiBFbGVtZW50UmVmICkge1xuICAgIGNvbnNvbGUubG9nKCdlbDpIVE1MRWxlbWVudC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcbiAgICBjb25zdCBlbDogSFRNTEVsZW1lbnQgICAgPSBlbGVtZW50UmVmLm5hdGl2ZUVsZW1lbnQ7XG4gICAgdGhpcy5yb290ID0gZDMuc2VsZWN0KGVsKTtcbn1cblxubmdPbkluaXQoKSB7XG59XG5cbm5nT25DaGFuZ2VzKGNoYW5nZXM6IHtbcHJvcGVydHlOYW1lOiBzdHJpbmddOiBTaW1wbGVDaGFuZ2V9KSB7XG4gIGNvbnN0IHN2Z1dpZHRoID0gcGFyc2VJbnQodGhpcy5zdmdXaWR0aCwgMTApO1xuICBjb25zdCBzdmdIZWlnaHQgPSBwYXJzZUludCh0aGlzLnN2Z0hlaWdodCwgMTApO1xuICBjb25zdCBkYXRhU2V0ID0gdGhpcy5ncmFwaERhdGE7XG4gIGNvbnN0IGNvbmZpZ0RhdGEgPSB0aGlzLmNvbmZpZ0RhdGE7XG4gIGNvbnN0IGNoYXJ0VHlwZSA9IHRoaXMuY2hhcnRUeXBlO1xuICBjb25zdCBzdmdDb250YWluZXIgPSB0aGlzLnJvb3QuYXBwZW5kKCdzdmcnKVxuICAgICAgICAgICAgLmF0dHIoJ3dpZHRoJywgc3ZnV2lkdGgpXG4gICAgICAgICAgICAuYXR0cignaGVpZ2h0Jywgc3ZnSGVpZ2h0KTtcblxuICBjb25zb2xlLmxvZyhjaGFydFR5cGUpO1xuICBzd2l0Y2ggKGNoYXJ0VHlwZSkge1xuICAgIGNhc2UgQ2hhcnRDb25zdC5MSU5FX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRMaW5lKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuQkFSX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRCYXIoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuUElFX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRQaWUoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuU0NBVFRFUl9QTE9UX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRTY2F0dGVyUGxvdChzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5ISVNUT0dSQU1fQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZEhpc3RvZ3JhbShzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5TVEFDS19CQVJfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZFN0YWNrQmFyKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LkdFT19NQVBfQ0hBUlRfVFlQRV9OQU1FOlxuICAgICAgdGhpcy5idWlsZEdlb01hcChzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5HRU9fT1JUSE9HUkFQSElDX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRHZW9PcnRob2dyYXBoaWMoc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBkYXRhU2V0LCBzdmdXaWR0aCwgc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuVFJFRV9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkVHJlZShzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5QQUNLX0xBWU9VVF9DSEFSVF9UWVBFX05BTUU6XG4gICAgICB0aGlzLmJ1aWxkUGFja0xheW91dChzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5DSE9ST1BMRVRIX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRDaG9yb3BsZXRoKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgZGF0YVNldCwgc3ZnV2lkdGgsIHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgY2FzZSBDaGFydENvbnN0LkZPUkNFX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIHRoaXMuYnVpbGRGb3JjZShzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIGRhdGFTZXQsIHN2Z1dpZHRoLCBzdmdIZWlnaHQgKTtcbiAgICAgIGJyZWFrO1xuICAgIGNhc2UgQ2hhcnRDb25zdC5UUkVFX01BUF9DSEFSVF9UWVBFX05BTUU6XG4gICAgICAvLyAgdGhpcy5idWlsZFRyZWVNYXAoc3ZnQ29udGFpbmVyLGNvbmZpZ0RhdGEsIGRhdGFTZXQsc3ZnV2lkdGgsc3ZnSGVpZ2h0ICk7XG4gICAgICBicmVhaztcbiAgICBjYXNlIENoYXJ0Q29uc3QuU0FOS0VZX0NIQVJUX1RZUEVfTkFNRTpcbiAgICAgIC8vICB0aGlzLmJ1aWxkU2Fua2V5KHN2Z0NvbnRhaW5lcixjb25maWdEYXRhLCBkYXRhU2V0LHN2Z1dpZHRoLHN2Z0hlaWdodCApO1xuICAgICAgYnJlYWs7XG4gICAgZGVmYXVsdDpcbiAgICAgIGJyZWFrO1xuICB9XG59XG5cblxuXG5wcml2YXRlIGJ1aWxkSGlzdG9ncmFtKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkSGlzdG9ncmFtLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IGRhdGFTZXQgPSBkYXRhU2V0SnNvbi5kYXRhO1xuICBjb25zdCBfYmluTnVtYmVyID0gZGF0YVNldEpzb24uYmlucy5sZW5ndGggLSAxO1xuXG4gIGNvbnN0IF9tYXhZID0gMzAwOyAvLyBkdW1teSBudW1iZXJcbiAgY29uc3QgX21heFggPSBkYXRhU2V0SnNvbi5yYW5nZVsxXTtcbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcbiAgY29uc3QgX2dyYXBoV2lkdGggPSBjZHQuZ3JhcGhXaWR0aDtcbiAgY29uc3QgX2dyYXBoSGVpZ2h0ID0gY2R0LmdyYXBoSGVpZ2h0O1xuICBjb25zdCBfbWF4WVZhbHVlID0gY2R0Lm1heFlWYWx1ZTtcbiAgY29uc3QgX2dyYXBoWFNjYWxlID0gY2R0LmdyYXBoWFNjYWxlO1xuICBjb25zdCBfZ3JhcGhJbml0WCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfZ3JhcGhJbml0WSA9IGNkdC5ncmFwaEluaXRZUG9zO1xuXG4gIGNvbnN0IF90aXRsZURpc3BsYXkgPSBjb25maWdEYXRhLnRpdGxlLmRpc3BsYXk7XG4gIGNvbnN0IF9hbmltYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5lbmFibGU7XG4gIGNvbnN0IF9hbmltYXRpb25EdXJhdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmR1cmF0aW9uO1xuICBjb25zdCBfZ3JpZFlEaXNwbGF5ID0gY29uZmlnRGF0YS5ncmlkLnkuZGlzcGxheTtcbiAgY29uc3QgX21hcmdpbkxlZnQgPSBjb25maWdEYXRhLm1hcmdpbi5sZWZ0O1xuICBjb25zdCBfbWFyZ2luVG9wID0gY29uZmlnRGF0YS5tYXJnaW4udG9wO1xuICBjb25zdCBfY2xhc3NOYW1lID0gY29uZmlnRGF0YS5jbGFzc05hbWUuaGlzdG9ncmFtQmFyO1xuXG5cbiAgY29uc3QgX2RhdGFTZXQ6IEFycmF5PG51bWJlcj4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXQpIHtcbiAgICAgIGlmIChkYXRhU2V0Lmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgY29uc3QgX251bSA9IGRhdGFTZXRbaV0gLyBfbWF4WDtcbiAgICAgICAgICBfZGF0YVNldC5wdXNoKF9udW0pO1xuICAgICAgfVxuICB9XG5cbiAgY29uc3QgZm9ybWF0Q291bnQgPSBkMy5mb3JtYXQoJywuMGYnKTtcblxuICBjb25zdCBfaGlzdGdyYW1Db250YWluZXIgPSBzdmdDb250YWluZXJcbiAgICAgICAgICAgICAgICAgIC5hcHBlbmQoJ2cnKVxuICAgICAgICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsICd0cmFuc2xhdGUoJyArIF9ncmFwaEluaXRYICsgJywnICsgX2dyYXBoSW5pdFkgKyAnKScpO1xuXG4gIGNvbnN0IF94U2NhbGUgPSBkMy5zY2FsZUxpbmVhcigpXG4gICAgICAucmFuZ2VSb3VuZChbMCwgX2dyYXBoV2lkdGhdKTtcblxuICBjb25zdCBiaW5zID0gZDMuaGlzdG9ncmFtKClcbiAgICAgIC5kb21haW4oWzAsIDFdKVxuICAgICAgLnRocmVzaG9sZHMoX3hTY2FsZS50aWNrcyhfYmluTnVtYmVyKSlcbiAgICAgIChfZGF0YVNldCk7XG5cblxuICBjb25zdCBfeVNjYWxlID0gZDMuc2NhbGVMaW5lYXIoKVxuICAgICAgLmRvbWFpbihbMCwgZDMubWF4KGJpbnMsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gZC5sZW5ndGg7XG4gICAgICB9KV0pXG4gICAgICAucmFuZ2UoW19ncmFwaEhlaWdodCwgMF0pO1xuXG4gIGNvbnN0IGJhciA9IF9oaXN0Z3JhbUNvbnRhaW5lclxuICAgICAgLnNlbGVjdEFsbCgnLmJhcicpXG4gICAgICAuZGF0YShiaW5zKVxuICAgICAgLmVudGVyKClcbiAgICAgIC5hcHBlbmQoJ2cnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgX2NsYXNzTmFtZSlcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIF94U2NhbGUoZC54MCkgKyAnLCcgKyBfeVNjYWxlKGQubGVuZ3RoKSArICcpJztcbiAgICAgIH0pO1xuXG4gIGlmIChfYW5pbWF0aW9uKSB7XG4gICAgICBiYXIuYXBwZW5kKCdyZWN0JylcbiAgICAgICAgICAuYXR0cigneCcsICAxKVxuICAgICAgICAgIC5hdHRyKCd3aWR0aCcsIF94U2NhbGUoYmluc1swXS54MSkgLSBfeFNjYWxlKGJpbnNbMF0ueDApIC0gMSlcbiAgICAgICAgICAuYXR0cignaGVpZ2h0JywgMClcbiAgICAgICAgICAudHJhbnNpdGlvbigpXG4gICAgICAgICAgLmR1cmF0aW9uKF9hbmltYXRpb25EdXJhdGlvbilcbiAgICAgICAgICAuYXR0cignaGVpZ2h0JywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gX2dyYXBoSGVpZ2h0IC0gX3lTY2FsZShkLmxlbmd0aCk7XG4gICAgICAgICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgICBiYXIuYXBwZW5kKCdyZWN0JylcbiAgICAgICAgICAuYXR0cigneCcsIDEpXG4gICAgICAgICAgLmF0dHIoJ3dpZHRoJywgX3hTY2FsZShiaW5zWzBdLngxKSAtIF94U2NhbGUoYmluc1swXS54MCkgLSAxKVxuICAgICAgICAgIC5hdHRyKCdoZWlnaHQnLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiBfZ3JhcGhIZWlnaHQgLSBfeVNjYWxlKGQubGVuZ3RoKTtcbiAgICAgICAgICB9KTtcbiAgfVxuXG4gIGJhci5hcHBlbmQoJ3RleHQnKVxuICAgICAgLmF0dHIoJ2R5JywgJy43NWVtJylcbiAgICAgIC5hdHRyKCd5JywgNilcbiAgICAgIC5hdHRyKCd4JywgKF94U2NhbGUoYmluc1swXS54MSkgLSBfeFNjYWxlKGJpbnNbMF0ueDApKSAvIDIpXG4gICAgICAuYXR0cigndGV4dC1hbmNob3InLCAnbWlkZGxlJylcbiAgICAgIC50ZXh0KChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gZm9ybWF0Q291bnQoZC5sZW5ndGgpO1xuICAgICAgfSk7XG5cbiAgLy8gLS0tQ0FMTCBidWlsZFRpdGxlLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF90aXRsZURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1RpdGxlKGNkdCk7XG4gIH1cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRBeGlzLS0tLS0tLS0tLS0tLS0tLS1cbiAgdGhpcy5idWlsZFlBeGlzKGNkdCk7XG5cbiAgdGhpcy5idWlsZFhBeGlzKGNkdCk7XG5cbiAgIGlmIChfZ3JpZFlEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdZR3JpZChjZHQpO1xuICB9XG59XG5cblxuXG5wcml2YXRlIGJ1aWxkRm9yY2Uoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnSW4gIGJ1aWxkRm9jZS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfbWF4WCA9IDEwMDtcbiAgY29uc3QgX21heFkgPSAxMDA7XG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG5cbiAgY29uc3QgX2NvbG9yID0gY2R0LmRlZmF1bHRDb2xvckZ1bmM7XG4gIGNvbnN0IF9pbml0UG9zWCA9IGNkdC5ncmFwaEluaXRYUG9zO1xuICBjb25zdCBfaW5pdFBvc1kgPSBjZHQuZ3JhcGhJbml0WVBvcztcbiAgY29uc3QgX2NlbnRlclBvcyA9IGNkdC5ncmFwaENlbnRlclBvcztcbiAgY29uc3QgX2dyYXBoSGVpZ2h0ID0gY2R0LmdyYXBoSGVpZ2h0O1xuICBjb25zdCBfZ3JhcGhXaWR0aCA9IGNkdC5ncmFwaFdpZHRoO1xuXG4gIGNvbnN0IF9tYXJnaW5MZWZ0ID0gY29uZmlnRGF0YS5tYXJnaW4ubGVmdDtcbiAgY29uc3QgX21hcmdpblRvcCA9IGNvbmZpZ0RhdGEubWFyZ2luLnRvcDtcblxuXG4gIGNvbnN0IHNpbXVsYXRpb24gPSBkMy5mb3JjZVNpbXVsYXRpb24oKVxuICAgICAgLmZvcmNlKCdsaW5rJywgZDMuZm9yY2VMaW5rKCkuaWQoKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiBkLmlkO1xuICAgICAgfSkpXG4gICAgICAuZm9yY2UoJ2NoYXJnZScsIGQzLmZvcmNlTWFueUJvZHkoKSlcbiAgICAgIC5mb3JjZSgnY2VudGVyJywgZDMuZm9yY2VDZW50ZXIoX2dyYXBoV2lkdGggLyAyLCBfZ3JhcGhIZWlnaHQgLyAyKSk7XG5cblxuICBjb25zdCBfZm9yY2VDb250YWluZXIgPSBzdmdDb250YWluZXJcbiAgICAuYXBwZW5kKCdnJylcbiAgICAuYXR0cigndHJhbnNmb3JtJyxcbiAgICAgICd0cmFuc2xhdGUoJyArIF9tYXJnaW5MZWZ0ICsgJywnICsgX21hcmdpblRvcCArICcpJyk7XG5cbiAgY29uc3QgbGluayA9IF9mb3JjZUNvbnRhaW5lci5hcHBlbmQoJ2cnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgJ2ZvcmNlLWxpbmtzJylcbiAgICAgIC5zZWxlY3RBbGwoJ2xpbmUnKVxuICAgICAgLmRhdGEoZGF0YVNldEpzb24ubGlua3MpXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgnbGluZScpXG4gICAgICAuYXR0cignc3Ryb2tlLXdpZHRoJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiBNYXRoLnNxcnQoZC52YWx1ZSk7XG4gICAgICB9KTtcblxuICBjb25zdCBub2RlID0gX2ZvcmNlQ29udGFpbmVyLmFwcGVuZCgnZycpXG4gICAgICAuYXR0cignY2xhc3MnLCAnbm9kZXMnKVxuICAgICAgLnNlbGVjdEFsbCgnY2lyY2xlJylcbiAgICAgIC5kYXRhKGRhdGFTZXRKc29uLm5vZGVzKVxuICAgICAgLmVudGVyKClcbiAgICAgIC5hcHBlbmQoJ2NpcmNsZScpXG4gICAgICAuYXR0cigncicsIDUpXG4gICAgICAuYXR0cignZmlsbCcsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gX2NvbG9yKGQuZ3JvdXApO1xuICAgICAgfSlcbiAgICAgIC5jYWxsKGQzLmRyYWcoKVxuICAgICAgICAgIC5vbignc3RhcnQnLCBkcmFnc3RhcnRlZClcbiAgICAgICAgICAub24oJ2RyYWcnLCBkcmFnZ2VkKVxuICAgICAgICAgIC5vbignZW5kJywgZHJhZ2VuZGVkKSk7XG5cbiAgICAgIG5vZGUuYXBwZW5kKCd0aXRsZScpXG4gICAgICAgICAgLnRleHQoKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gZC5pZDtcbiAgICAgICAgICB9KTtcblxuICBzaW11bGF0aW9uXG4gICAgICAubm9kZXMoZGF0YVNldEpzb24ubm9kZXMpXG4gICAgICAub24oJ3RpY2snLCB0aWNrZWQpO1xuXG4gIGNvbnN0IF9mb3JjZUxpbms6IGFueSA9IHNpbXVsYXRpb24uZm9yY2UoJ2xpbmsnKTtcbiAgX2ZvcmNlTGluay5saW5rcyhkYXRhU2V0SnNvbi5saW5rcyk7XG5cbiAgZnVuY3Rpb24gdGlja2VkKCkge1xuICAgICAgbGlua1xuICAgICAgICAgIC5hdHRyKCd4MScsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICByZXR1cm4gZC5zb3VyY2UueDsgfSlcbiAgICAgICAgICAuYXR0cigneTEnLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gZC5zb3VyY2UueTsgfSlcbiAgICAgICAgICAuYXR0cigneDInLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgICAgcmV0dXJuIGQudGFyZ2V0Lng7IH0pXG4gICAgICAgICAgLmF0dHIoJ3kyJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgIHJldHVybiBkLnRhcmdldC55OyB9KTtcblxuICAgICAgbm9kZVxuICAgICAgICAgIC5hdHRyKCdjeCcsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICByZXR1cm4gZC54OyB9KVxuICAgICAgICAgIC5hdHRyKCdjeScsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICByZXR1cm4gZC55OyB9KTtcbiAgfVxuXG4gIGZ1bmN0aW9uIGRyYWdzdGFydGVkKGQ6IGFueSkgIHtcbiAgICAgIGlmICghZDMuZXZlbnQuYWN0aXZlKSB7XG4gICAgICAgICAgc2ltdWxhdGlvbi5hbHBoYVRhcmdldCgwLjMpLnJlc3RhcnQoKTtcbiAgICAgIH1cbiAgICAgIGQuZnggPSBkLng7XG4gICAgICBkLmZ5ID0gZC55O1xuICB9XG5cbiAgZnVuY3Rpb24gZHJhZ2dlZChkOiBhbnkpICB7XG4gICAgICBkLmZ4ID0gZDMuZXZlbnQueDtcbiAgICAgIGQuZnkgPSBkMy5ldmVudC55O1xuICB9XG5cbiAgZnVuY3Rpb24gZHJhZ2VuZGVkKGQ6IGFueSkgIHtcbiAgICAgIGlmICghZDMuZXZlbnQuYWN0aXZlKSB7XG4gICAgICAgICAgc2ltdWxhdGlvbi5hbHBoYVRhcmdldCgwKTtcbiAgICAgIH1cbiAgICAgIGQuZnggPSBudWxsO1xuICAgICAgZC5meSA9IG51bGw7XG4gIH1cblxuICAvLyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vICAtLS1DQUxMIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3QgX2xlZ2VuZERhdGFTZXQ6IEFycmF5PE8yTGVnZW5kRGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmdyb3Vwcykge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmdyb3Vwcy5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGNvbnN0IF9pZCA9IGRhdGFTZXRKc29uLmdyb3Vwc1tpXS5pZDtcbiAgICAgICAgICBfbGVnZW5kRGF0YVNldC5wdXNoKG5ldyBPMkxlZ2VuZERhdGEoZGF0YVNldEpzb24uZ3JvdXBzW2ldLm5hbWUsIF9jb2xvcihfaWQpKSk7XG4gICAgICB9XG4gIH1cbiAgdGhpcy5idWlsZExlZ2VuZChjZHQsIF9sZWdlbmREYXRhU2V0KTtcblxuXG5cbn1cblxuXG5wcml2YXRlIGJ1aWxkQ2hvcm9wbGV0aChzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZENob3JvcGxldGggLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IF9tYXhYID0gMTAwOyAvLyBhbnkgdmFsdWVcbiAgY29uc3QgX21heFkgPSAxMDA7IC8vIGFueSB2YWx1ZVxuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuICBjb25zdCBfZ3JhcGhDZW50ZXJQb3MgPSBjZHQuZ3JhcGhDZW50ZXJQb3M7XG4gIGNvbnN0IF9ncmFwaEluaXRYID0gY2R0LmdyYXBoSW5pdFhQb3M7XG4gIGNvbnN0IF9ncmFwaEluaXRZID0gY2R0LmdyYXBoSW5pdFlQb3M7XG5cblxuICBjb25zdCBfdGl0bGVEaXNwbGF5ID0gY29uZmlnRGF0YS50aXRsZS5kaXNwbGF5O1xuICBjb25zdCBfbGVnZW5kRGlzcGxheSA9IGNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXk7XG4gIGNvbnN0IF9mb2N1c0NvbG9yID0gY29uZmlnRGF0YS5jb2xvci5mb2N1c0NvbG9yO1xuXG4gIGNvbnN0IF9zY2FsZSA9IGRhdGFTZXRKc29uLm1hcC5zY2FsZTtcbiAgY29uc3QgX3RhcmdldE5hbWUgPSBkYXRhU2V0SnNvbi5tYXAudGFyZ2V0TmFtZTtcbiAgY29uc3QgX2tleURhdGFOYW1lID0gZGF0YVNldEpzb24ubWFwLmtleURhdGFOYW1lO1xuICBjb25zdCBfa2V5TmFtZSA9ICdkYXRhLicgKyBfa2V5RGF0YU5hbWU7XG4gIGNvbnN0IF9nZW9NYXBEYXRhVXJsID0gZGF0YVNldEpzb24ubWFwLmJhc2VHZW9EYXRhVXJsO1xuICBjb25zdCBfc3RhcnRDb2xvciA9IGRhdGFTZXRKc29uLm1hcC5zdGFydENvbG9yO1xuICBjb25zdCBfZW5kQ29sb3IgPSBkYXRhU2V0SnNvbi5tYXAuZW5kQ29sb3I7XG4gIGNvbnN0IF9jb2xvck51bSA9IGRhdGFTZXRKc29uLm1hcC5jb2xvck51bWJlcjtcbiAgY29uc3QgX2NlbnRlciA9IGRhdGFTZXRKc29uLm1hcC5jZW50ZXI7XG4gIGNvbnN0IF90YXJnZXRQcm9wZXJ0eU5hbWUgPSBkYXRhU2V0SnNvbi5tYXAudGFyZ2V0UHJvcGVydHlOYW1lO1xuICBjb25zdCBfdGFyZ2V0UHJvcGVydHkgPSAnZC4nICsgX3RhcmdldFByb3BlcnR5TmFtZTtcblxuICBjb25zdCBjb2xvciA9IGQzLmludGVycG9sYXRlSHNsKF9zdGFydENvbG9yLCBfZW5kQ29sb3IpO1xuXG4gIGxldCBfbWF4ID0gZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZTtcbiAgbGV0IF9taW4gPSBkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBpZiAoX21heCA8IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUpIHtcbiAgICAgICAgICAgICAgX21heCA9IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWU7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChfbWluID4gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZSkge1xuICAgICAgICAgICAgICBfbWluID0gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gIH1cbiAgY29uc3QgX3JhbmdlID0gX21heCAtIF9taW47XG4gIGNvbnN0IF9zdGVwID0gX3JhbmdlIC8gKF9jb2xvck51bSAtIDEpO1xuXG4gIGNvbnN0IF9maW5kQ29sb3JCeUlkID0gKGlkOiBudW1iZXIpOiBzdHJpbmcgPT4ge1xuICAgICAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICBpZiAoaWQgPT09IGRhdGFTZXRKc29uLmRhdGFbaV0uaWQpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IF92YWx1ZSA9IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWU7XG4gICAgICAgICAgICAgICAgICBjb25zdCBfcmF0ZSA9IE1hdGguY2VpbCgoX3ZhbHVlIC0gX21pbikgLyBfc3RlcCk7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gY29sb3IoX3JhdGUgLyBfbWF4KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgIH1cbiAgfTtcblxuICBjb25zdCBwYXRoID0gZDMuZ2VvUGF0aCgpXG4gICAgICAgICAgICAgIC5wcm9qZWN0aW9uKFxuICAgICAgICAgICAgICAgICAgZDMuZ2VvTWVyY2F0b3IoKVxuICAgICAgICAgICAgICAgICAgLmNlbnRlcihfY2VudGVyKVxuICAgICAgICAgICAgICAgICAgLnNjYWxlKF9zY2FsZSlcbiAgICAgICAgICAgICAgICAgIC50cmFuc2xhdGUoX2dyYXBoQ2VudGVyUG9zKVxuICAgICAgICAgICAgICApO1xuXG4gIGQzLmpzb24oX2dlb01hcERhdGFVcmwsIChlcnJvciwgZGF0YSkgPT4ge1xuICAgICAgc3ZnQ29udGFpbmVyLnNlbGVjdEFsbCgncGF0aCcpXG4gICAgICAgICAgICAgIC5kYXRhKGV2YWwoX2tleU5hbWUpKVxuICAgICAgICAgICAgICAuZW50ZXIoKVxuICAgICAgICAgICAgICAuYXBwZW5kKCdwYXRoJylcbiAgICAgICAgICAgICAgLmF0dHIoJ2QnLCBwYXRoKVxuICAgICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBfY2wgPSBfZmluZENvbG9yQnlJZChldmFsKF90YXJnZXRQcm9wZXJ0eSkpO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIF9jbDtcbiAgICAgICAgICAgICAgfSk7XG4gIH0pO1xuXG4gIC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAtLS1DQUxMIGJ1aWxkVGl0bGUtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX3RpdGxlRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3VGl0bGUoY2R0KTtcbiAgfVxuXG4gIC8vICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gIC0tLUNBTEwgYnVpbGRMZWdlbmQtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX2xlZ2VuZERpc3BsYXkpIHtcbiAgICAgIGNvbnN0IF9sZWdlbmREYXRhU2V0OiBBcnJheTxPMkxlZ2VuZERhdGE+ID0gbmV3IEFycmF5KCk7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IF9jb2xvck51bTsgaSsrKSB7XG4gICAgICAgICAgY29uc3QgX2xhYmVsID0gU3RyaW5nKF9taW4gKyAoaSAqIF9zdGVwKSkgKyAgJyAtLSc7XG4gICAgICAgICAgX2xlZ2VuZERhdGFTZXQucHVzaChuZXcgTzJMZWdlbmREYXRhKF9sYWJlbCwgY29sb3IoaSAvIF9tYXgpKSk7XG4gICAgICB9XG4gICAgICB0aGlzLmJ1aWxkTGVnZW5kKGNkdCwgX2xlZ2VuZERhdGFTZXQpO1xuICB9XG5cbn1cblxucHJpdmF0ZSBidWlsZFBhY2tMYXlvdXQoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gUGFja0xheW91dC0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IF9wYWNrbGF5b3V0Q2xhc3MgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5wYWNrbGF5b3V0O1xuICBjb25zdCBfcGFja2xheW91dExhYmVsQ2xhc3MgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5wYWNrbGF5b3V0TGFiZWw7XG4gIGNvbnN0IF9hbmltYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5lbmFibGU7XG4gIGNvbnN0IF9hbmltYXRpb25EdXJhdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmR1cmF0aW9uO1xuICBjb25zdCBjb2xvciA9IGQzLnNjYWxlT3JkaW5hbChkMy5zY2hlbWVDYXRlZ29yeTEwKTtcbiAgLy8gIGNvbnN0IGNvbG9yID0gZDMuc2NhbGUuY2F0ZWdvcnkxMCgpO1xuICBjb25zdCBidWJibGUgPSBkMy5wYWNrKClcbiAgICAgICAgICAgICAgICAgIC5zaXplKFtzdmdXaWR0aCwgc3ZnSGVpZ2h0XSk7XG5cbiAgY29uc3Qgbm9kZXMwID0gZDMuaGllcmFyY2h5KGRhdGFTZXRKc29uKTtcblxuICBjb25zdCBwYWNrID0gIHN2Z0NvbnRhaW5lci5zZWxlY3RBbGwoJ2cnKVxuICAgICAgICAgICAgICAuZGF0YShidWJibGUobm9kZXMwKS5kZXNjZW5kYW50cygpKVxuICAgICAgICAgICAgICAuZW50ZXIoKVxuICAgICAgICAgICAgICAuYXBwZW5kKCdnJylcbiAgICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiAndHJhbnNsYXRlKCcgKyBkLnggKyAnLCcgKyBkLnkgKyAnKSc7XG4gICAgICAgICAgICAgIH0pO1xuXG4gIGNvbnN0IF9jaXJjbGUgPSBwYWNrLmFwcGVuZCgnY2lyY2xlJyk7XG4gIGlmIChfYW5pbWF0aW9uKSB7XG4gICAgICBfY2lyY2xlLmF0dHIoJ3InLCAwKVxuICAgICAgICAgICAgICAudHJhbnNpdGlvbigpXG4gICAgICAgICAgICAgIC5kdXJhdGlvbigoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gZC5kZXB0aCAqIF9hbmltYXRpb25EdXJhdGlvbiAgKyA1MDA7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC5hdHRyKCdyJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGQucjtcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IGFueSwgaTogYW55KSA9PiAge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIGNvbG9yKGkpO1xuICAgICAgICAgICAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICAgIF9jaXJjbGUuYXR0cigncicsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBkLnI7XG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIChkOiBhbnksIGk6IGFueSkgPT4gIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiBjb2xvcihpKTtcbiAgICAgICAgICAgICAgfSk7XG4gIH1cblxuICBjb25zdCBfdGV4dCA9IHBhY2suYXBwZW5kKCd0ZXh0JylcbiAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgX3BhY2tsYXlvdXRMYWJlbENsYXNzKVxuICAgICAgICAgICAgICAudGV4dCgoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgICAgICAgICBpZiAoZC5kZXB0aCA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBkLmRhdGEubmFtZTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICB9KTtcblxuICBpZiAoX2FuaW1hdGlvbikge1xuICAgICAgX3RleHQuc3R5bGUoJ29wYWNpdHknLCAwKVxuICAgICAgICAgIC50cmFuc2l0aW9uKClcbiAgICAgICAgICAuZHVyYXRpb24oX2FuaW1hdGlvbkR1cmF0aW9uKVxuICAgICAgICAgIC5zdHlsZSgnb3BhY2l0eScsIDEuMCk7XG4gIH0gZWxzZSB7XG4gICAgICBfdGV4dC5zdHlsZSgnb3BhY2l0eScsIDEuMCk7XG4gIH1cblxufVxuXG5wcml2YXRlIGJ1aWxkVHJlZShzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdJbiAgYnVpbGRUcmVlLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGxldCBfbWF4WCA9IDA7XG4gIGxldCBfbWF4WSA9IDA7XG4gIF9tYXhZID0gMTAwO1xuICBfbWF4WCA9IDEwMDtcbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcblxuICBjb25zdCBfY29sb3IgPSBjZHQuZGVmYXVsdENvbG9yRnVuYztcbiAgY29uc3QgX2luaXRQb3NYID0gY2R0LmdyYXBoSW5pdFhQb3M7XG4gIGNvbnN0IF9pbml0UG9zWSA9IGNkdC5ncmFwaEluaXRZUG9zO1xuICBjb25zdCBfZ3JhcGhIZWlnaHQgPSBjZHQuZ3JhcGhIZWlnaHQ7XG4gIGNvbnN0IF9ncmFwaFdpZHRoID0gY2R0LmdyYXBoV2lkdGg7XG5cbiAgY29uc3QgX2FuaW1hdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmVuYWJsZTtcbiAgY29uc3QgX2FuaW1hdGlvbkR1cmF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZHVyYXRpb247XG4gIGNvbnN0IF90cmVlbWFwQ2xhc3MgPSBjb25maWdEYXRhLmNsYXNzTmFtZS50cmVlbWFwO1xuICBjb25zdCBfdHJlZW1hcExhYmVsQ2xhc3MgPSBjb25maWdEYXRhLmNsYXNzTmFtZS50cmVlbWFwTGFiZWw7XG4gIGNvbnN0IF9tYXJnaW5MZWZ0ID0gY29uZmlnRGF0YS5tYXJnaW4ubGVmdDtcbiAgY29uc3QgX21hcmdpblRvcCA9IGNvbmZpZ0RhdGEubWFyZ2luLnRvcDtcblxuXG4gIGNvbnN0IHRyZWUgPSBkMy50cmVlKClcbiAgICAgICAgICAgICAgICAgIC5zaXplKFtfZ3JhcGhXaWR0aCwgX2dyYXBoSGVpZ2h0XSk7XG5cbiAgY29uc3Qgbm9kZXMwID0gZDMuaGllcmFyY2h5KGRhdGFTZXRKc29uKTtcblxuICBjb25zdCBub2RlcyA9IHRyZWUobm9kZXMwKTtcblxuICBjb25zdCBfdHJlZUNvbnRhaW5lciA9IHN2Z0NvbnRhaW5lclxuICAgIC5hcHBlbmQoJ2cnKVxuICAgIC5hdHRyKCd0cmFuc2Zvcm0nLFxuICAgICAgJ3RyYW5zbGF0ZSgnICsgX21hcmdpbkxlZnQgKyAnLCcgKyBfbWFyZ2luVG9wICsgJyknKTtcblxuICBjb25zdCBsaW5rID0gX3RyZWVDb250YWluZXJcbiAgICAgIC5zZWxlY3RBbGwoJy5saW5rJylcbiAgICAgIC5kYXRhKCBub2Rlcy5kZXNjZW5kYW50cygpLnNsaWNlKDEpKVxuICAgICAgLmVudGVyKClcbiAgICAgIC5hcHBlbmQoJ3BhdGgnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgJ3RyZWUtbm9kZS1saW5rJylcbiAgICAgIC5hdHRyKCdkJywgKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiAnTScgKyBkLnggKyAnLCcgKyBkLnlcbiAgICAgICAgICAgICAgKyAnQycgKyBkLnggKyAnLCcgKyAoZC55ICsgZC5wYXJlbnQueSkgLyAyXG4gICAgICAgICAgICAgICsgJyAnICsgZC5wYXJlbnQueCArICcsJyArICAoZC55ICsgZC5wYXJlbnQueSkgLyAyXG4gICAgICAgICAgICAgICsgJyAnICsgZC5wYXJlbnQueCArICcsJyArIGQucGFyZW50Lnk7XG4gICAgICAgICAgfVxuICAgICAgKTtcblxuICBjb25zdCBub2RlID0gX3RyZWVDb250YWluZXJcbiAgICAgIC5zZWxlY3RBbGwoJy5ub2RlJylcbiAgICAgIC5kYXRhKG5vZGVzLmRlc2NlbmRhbnRzKCkpXG4gICAgICAuZW50ZXIoKVxuICAgICAgLmFwcGVuZCgnZycpXG4gICAgICAuYXR0cignY2xhc3MnLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuICd0cmVlLW5vZGUnICtcbiAgICAgICAgICAoZC5jaGlsZHJlbiA/ICctaW50ZXJuYWwnIDogJy1sZWFmJyk7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgZC54ICsgJywnICsgZC55ICsgJyknO1xuICAgICAgfSk7XG5cbiAgbm9kZS5hcHBlbmQoJ2NpcmNsZScpXG4gICAgICAuYXR0cigncicsIDEwKTtcblxuICBub2RlLmFwcGVuZCgndGV4dCcpXG4gICAgICAuYXR0cignZHknLCAnLjM1ZW0nKVxuICAgICAgLmF0dHIoJ3knLCAoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGQuY2hpbGRyZW4gPyAtMjAgOiAyMDtcbiAgICAgIH0pXG4gICAgICAuc3R5bGUoJ3RleHQtYW5jaG9yJywgJ21pZGRsZScpXG4gICAgICAudGV4dCgoZDogYW55KSA9PiB7XG4gICAgICAgICAgcmV0dXJuIGQuZGF0YS5uYW1lO1xuICAgICAgfSk7XG5cblxufVxuXG5cblxucHJpdmF0ZSBidWlsZEdlb09ydGhvZ3JhcGhpYyhzdmdDb250YWluZXI6IGFueSwgY29uZmlnRGF0YTogYW55LCBkYXRhU2V0SnNvbjogYW55LCBzdmdXaWR0aDogbnVtYmVyLCBzdmdIZWlnaHQ6IG51bWJlcik6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZEdlb09ydGhvZ3JhcGhpYyAtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgX21heFggPSAxMDA7IC8vIGFueSB2YWx1ZVxuICBjb25zdCBfbWF4WSA9IDEwMDsgLy8gYW55IHZhbHVlXG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG4gIGNvbnN0IF9ncmFwaENlbnRlclBvcyA9IGNkdC5ncmFwaENlbnRlclBvcztcbiAgY29uc3QgX2dyYXBoSW5pdFggPSBjZHQuZ3JhcGhJbml0WFBvcztcbiAgY29uc3QgX2dyYXBoSW5pdFkgPSBjZHQuZ3JhcGhJbml0WVBvcztcblxuICBjb25zdCBfdGl0bGVEaXNwbGF5ID0gY29uZmlnRGF0YS50aXRsZS5kaXNwbGF5O1xuICBjb25zdCBfbGVnZW5kRGlzcGxheSA9IGNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXk7XG4gIGNvbnN0IF9mb2N1c0NvbG9yID0gY29uZmlnRGF0YS5jb2xvci5mb2N1c0NvbG9yO1xuXG4gIGNvbnN0IF9nZW9NYXBEYXRhVXJsID0gZGF0YVNldEpzb24ubWFwLmJhc2VHZW9EYXRhVXJsO1xuICBjb25zdCBfc2NhbGUgPSBkYXRhU2V0SnNvbi5tYXAuc2NhbGU7XG4gIGNvbnN0IF90YXJnZXROYW1lID0gZGF0YVNldEpzb24ubWFwLnRhcmdldE5hbWU7XG4gIGNvbnN0IF90YXJnZXRQcm9wZXJ0eSA9ICdkLicgKyBkYXRhU2V0SnNvbi5tYXAudGFyZ2V0UHJvcGVydHlOYW1lO1xuICBjb25zdCBfa2V5RGF0YU5hbWUgPSBkYXRhU2V0SnNvbi5tYXAua2V5RGF0YU5hbWU7XG4gIGNvbnN0IF9rZXlOYW1lID0gJ2RhdGEuJyArIF9rZXlEYXRhTmFtZTtcbiAgY29uc3QgX2NsaXBBbmdsZSA9IGRhdGFTZXRKc29uLm1hcC5jbGlwQW5nbGU7XG4gIGNvbnN0IF9yb3RhdGVIICAgPSBkYXRhU2V0SnNvbi5tYXAucm90YXRlLmhvcml6b250YWw7XG4gIGNvbnN0IF9yb3RhdGVWICAgPSBkYXRhU2V0SnNvbi5tYXAucm90YXRlLnZlcnRpY2FsO1xuICBjb25zdCBfb2NlYW5Db2xvciA9IGRhdGFTZXRKc29uLm1hcC5vY2VhbkNvbG9yO1xuICBjb25zdCBfYW50YXJjdGljYUNvbG9yID0gZGF0YVNldEpzb24ubWFwLmFudGFyY3RpY2FDb2xvcjtcbiAgY29uc3QgX2FuaW1hdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmVuYWJsZTtcbiAgY29uc3QgX2FuaW1hdGlvbkR1cmF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZHVyYXRpb247XG4gIGxldCBfYW5pbWF0aW9uSCA9IDA7XG5cbiAgY29uc3QgX2ZpbmRDb2xvckJ5TmFtZSA9IChuYW1lOiBzdHJpbmcpOiBzdHJpbmcgPT4ge1xuICAgICAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICBpZiAobmFtZSA9PT0gZGF0YVNldEpzb24uZGF0YVtpXS5uYW1lKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBfY29sb3IgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLmNvbG9yO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIF9jb2xvcjtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBudWxsO1xuICB9O1xuXG4gIGNvbnN0IHRhcmdldFBhdGggPSBkMy5nZW9PcnRob2dyYXBoaWMoKVxuICAgICAgICAgICAgICAudHJhbnNsYXRlKF9ncmFwaENlbnRlclBvcylcbiAgICAgICAgICAgICAgLmNsaXBBbmdsZShfY2xpcEFuZ2xlKVxuICAgICAgICAgICAgICAuc2NhbGUoX3NjYWxlKVxuICAgICAgICAgICAgICAucm90YXRlKFtfcm90YXRlSCwgX3JvdGF0ZVZdKTtcblxuICBjb25zdCBwYXRoID0gZDMuZ2VvUGF0aCgpXG4gICAgICAgICAgICAgIC5wcm9qZWN0aW9uKFxuICAgICAgICAgICAgICAgICAgdGFyZ2V0UGF0aFxuICAgICAgICAgICAgICApO1xuXG4gIGQzLmpzb24oX2dlb01hcERhdGFVcmwsIChlcnJvciwgZGF0YSkgPT4ge1xuICAgICAgc3ZnQ29udGFpbmVyLmFwcGVuZCgnY2lyY2xlJylcbiAgICAgICAgICAuYXR0cignY3gnLCBfZ3JhcGhDZW50ZXJQb3NbMF0pXG4gICAgICAgICAgLmF0dHIoJ2N5JywgX2dyYXBoQ2VudGVyUG9zWzFdKVxuICAgICAgICAgIC5hdHRyKCdyJywgX3NjYWxlKVxuICAgICAgICAgIC5zdHlsZSgnZmlsbCcsIF9vY2VhbkNvbG9yKTtcblxuICAgICAgY29uc3QgZWFydGhQYXRoID0gc3ZnQ29udGFpbmVyLnNlbGVjdEFsbCgncGF0aCcpXG4gICAgICAgICAgLmRhdGEoZXZhbChfa2V5TmFtZSkpXG4gICAgICAgICAgLmVudGVyKClcbiAgICAgICAgICAuYXBwZW5kKCdwYXRoJylcbiAgICAgICAgICAuYXR0cignZCcsIHBhdGgpXG4gICAgICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgICAgICBjb25zdCBfdGFyZ2V0QXJlYSA9IGV2YWwoX3RhcmdldFByb3BlcnR5KTtcbiAgICAgICAgICAgICAgaWYgKF9maW5kQ29sb3JCeU5hbWUoX3RhcmdldEFyZWEpICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gX2ZpbmRDb2xvckJ5TmFtZShfdGFyZ2V0QXJlYSk7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICByZXR1cm4gJ2hzbCgnICsgaSArICcsODAlLDYwJSknO1xuICAgICAgICAgIH0pO1xuICAgICAgaWYgKF9hbmltYXRpb24pIHtcbiAgICAgICAgICBkMy50aW1lcigoKSA9PiB7XG4gICAgICAgICAgICAgIHRhcmdldFBhdGgucm90YXRlKFtfcm90YXRlSCArIF9hbmltYXRpb25ILCBfcm90YXRlVl0pO1xuICAgICAgICAgICAgICBfYW5pbWF0aW9uSCArPSAyO1xuICAgICAgICAgICAgICBlYXJ0aFBhdGguYXR0cignZCcsIHBhdGgpO1xuICAgICAgICAgIH0pO1xuICAgICAgfVxuICB9KTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZFRpdGxlLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF90aXRsZURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1RpdGxlKGNkdCk7XG4gIH1cblxuICBpZiAoX2xlZ2VuZERpc3BsYXkpIHtcbiAgICAgIGNvbnN0IF9sZWdlbmREYXRhU2V0OiBBcnJheTxPMkxlZ2VuZERhdGE+ID0gbmV3IEFycmF5KCk7XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgIGNvbnN0IF9uYW1lID0gZGF0YVNldEpzb24uZGF0YVtpXS5uYW1lO1xuICAgICAgICAgICAgICBjb25zdCBfY29sb3IgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLmNvbG9yO1xuICAgICAgICAgICAgICBpZiAoX25hbWUgPT09ICdBbnRhcmN0aWNhJykge1xuICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgX2xlZ2VuZERhdGFTZXQucHVzaChuZXcgTzJMZWdlbmREYXRhKGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZSwgZGF0YVNldEpzb24uZGF0YVtpXS5jb2xvcikpO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG4gIH1cblxuXG59XG5cblxuXG5wcml2YXRlIGJ1aWxkR2VvTWFwKHN2Z0NvbnRhaW5lcjogYW55LCBjb25maWdEYXRhOiBhbnksIGRhdGFTZXRKc29uOiBhbnksIHN2Z1dpZHRoOiBudW1iZXIsIHN2Z0hlaWdodDogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkR2VvTWFwIC0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBfbWF4WCA9IDEwMDsgLy8gYW55IHZhbHVlXG4gIGNvbnN0IF9tYXhZID0gMTAwOyAvLyBhbnkgdmFsdWVcbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcbiAgY29uc3QgX2dyYXBoQ2VudGVyUG9zID0gY2R0LmdyYXBoQ2VudGVyUG9zO1xuICBjb25zdCBfZ2VvTWFwRGF0YVVybCA9ICBkYXRhU2V0SnNvbi5tYXAuYmFzZUdlb0RhdGFVcmw7XG4gIGNvbnN0IF9zY2FsZSA9IGRhdGFTZXRKc29uLm1hcC5zY2FsZTtcbiAgY29uc3QgX2tleURhdGFOYW1lID0gZGF0YVNldEpzb24ubWFwLmtleURhdGFOYW1lO1xuICBjb25zdCBfa2V5TmFtZSA9ICdkYXRhLicgKyBfa2V5RGF0YU5hbWU7XG4gIGNvbnN0IF90YXJnZXRQcm9wZXJ0eSA9ICdkLicgKyBkYXRhU2V0SnNvbi5tYXAudGFyZ2V0UHJvcGVydHlOYW1lO1xuICBjb25zdCBfYW50YXJjdGljYUNvbG9yID0gZGF0YVNldEpzb24ubWFwLmFudGFyY3RpY2FDb2xvcjtcbiAgY29uc3QgX2xlZ2VuZERpc3BsYXkgPSBjb25maWdEYXRhLmxlZ2VuZC5kaXNwbGF5O1xuXG4gIGNvbnN0IHBhdGggPSBkMy5nZW9QYXRoKClcbiAgICAgICAgICAgICAgLnByb2plY3Rpb24oXG4gICAgICAgICAgICAgICAgICBkMy5nZW9NZXJjYXRvcigpXG4gICAgICAgICAgICAgICAgICAudHJhbnNsYXRlKF9ncmFwaENlbnRlclBvcylcbiAgICAgICAgICAgICAgICAgIC5zY2FsZShfc2NhbGUpXG4gICAgICAgICAgICAgICk7XG5cbiAgY29uc3QgX2ZpbmRDb2xvckJ5TmFtZSA9IChuYW1lOiBzdHJpbmcpOiBzdHJpbmcgPT4ge1xuICAgICAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICBpZiAobmFtZSA9PT0gZGF0YVNldEpzb24uZGF0YVtpXS5uYW1lKSB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBfY29sb3IgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLmNvbG9yO1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIF9jb2xvcjtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiBudWxsO1xuICB9O1xuXG4gIGQzLmpzb24oX2dlb01hcERhdGFVcmwsIChlcnJvciwgZGF0YSkgPT4ge1xuICAgICAgc3ZnQ29udGFpbmVyLnNlbGVjdEFsbCgncGF0aCcpXG4gICAgICAgICAgICAgIC5kYXRhKGV2YWwoX2tleU5hbWUpKVxuICAgICAgICAgICAgICAuZW50ZXIoKVxuICAgICAgICAgICAgICAuYXBwZW5kKCdwYXRoJylcbiAgICAgICAgICAgICAgLmF0dHIoJ2QnLCBwYXRoKVxuICAgICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBfdGFyZ2V0QXJlYSA9IGV2YWwoX3RhcmdldFByb3BlcnR5KTtcbiAgICAgICAgICAgICAgICAgIGlmIChfZmluZENvbG9yQnlOYW1lKF90YXJnZXRBcmVhKSAhPT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfZmluZENvbG9yQnlOYW1lKF90YXJnZXRBcmVhKTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIHJldHVybiAnaHNsKCcgKyBpICsgJyw4MCUsNjAlKSc7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgfSk7XG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBidWlsZExlZ2VuZC0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfbGVnZW5kRGlzcGxheSkge1xuICAgICAgY29uc3QgX2xlZ2VuZERhdGFTZXQ6IEFycmF5PE8yTGVnZW5kRGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgICAgIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhKSB7XG4gICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICAgICAgY29uc3QgX25hbWUgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWU7XG4gICAgICAgICAgICAgIGNvbnN0IF9jb2xvciA9IGRhdGFTZXRKc29uLmRhdGFbaV0uY29sb3I7XG4gICAgICAgICAgICAgIGlmIChfbmFtZSA9PT0gJ0FudGFyY3RpY2EnKSB7XG4gICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBfbGVnZW5kRGF0YVNldC5wdXNoKG5ldyBPMkxlZ2VuZERhdGEoZGF0YVNldEpzb24uZGF0YVtpXS5uYW1lLCBkYXRhU2V0SnNvbi5kYXRhW2ldLmNvbG9yKSk7XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5idWlsZExlZ2VuZChjZHQsIF9sZWdlbmREYXRhU2V0KTtcbiAgfVxuXG59XG5cblxuXG5wcml2YXRlIGJ1aWxkU3RhY2tCYXIoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRTdGFja0Jhci0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBpbnRlcmZhY2UgSGFzaFN0cmluZyB7XG4gICAgW2luZGV4OiBzdHJpbmddOiBzdHJpbmc7XG4gIH1cbiAgaW50ZXJmYWNlIEhhc2hOdW1iZXIge1xuICAgIFtrZXk6IHN0cmluZ106IG51bWJlcjtcbiAgfVxuXG4gIGNvbnN0IF90b3RhbFk6IEFycmF5PG51bWJlcj4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICBfdG90YWxZLnB1c2goMCk7XG4gICAgICB9XG4gIH1cblxuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBsZXQgayA9IDA7XG4gICAgICAgICAgZm9yIChjb25zdCBqIGluIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUpIHtcbiAgICAgICAgICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWUuaGFzT3duUHJvcGVydHkoaikpIHtcbiAgICAgICAgICAgICAgICAgIF90b3RhbFlbaysrXSArPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLnk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gIH1cbiAgbGV0IF9tYXhYID0gMDtcbiAgbGV0IF9tYXhZID0gMDtcbiAgX21heFkgPSBkMy5tYXgoX3RvdGFsWSk7XG4gIF9tYXhYID0gMTAwO1xuICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oc3ZnQ29udGFpbmVyLCBjb25maWdEYXRhLCBfbWF4WCwgX21heFksIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuXG4gIGNvbnN0IF9jb2xvciA9IGNkdC5kZWZhdWx0Q29sb3JGdW5jO1xuICBjb25zdCBfY29sdW1uTnVtID0gIGRhdGFTZXRKc29uLmRhdGEubGVuZ3RoO1xuICBjb25zdCBfYmFyV2lkdGggPSAoY2R0LmdyYXBoV2lkdGggLyBfY29sdW1uTnVtKSAtIGNvbmZpZ0RhdGEubWFyZ2luLmJldHdlZW47XG4gIGNvbnN0IF9jb2x1bW5XaWR0aCA9IChjZHQuZ3JhcGhXaWR0aCAvIF9jb2x1bW5OdW0pIDtcbiAgY29uc3QgX2luaXRQb3NYID0gY2R0LmdyYXBoSW5pdFhQb3M7XG4gIGNvbnN0IF9pbml0UG9zWSA9IGNkdC5ncmFwaEluaXRZUG9zO1xuICBjb25zdCBfZ3JhcGhIZWlnaHQgPSBjZHQuZ3JhcGhIZWlnaHQ7XG4gIGNvbnN0IF9tYXhZVmFsdWUgPSBjZHQubWF4WVZhbHVlO1xuXG4gIGNvbnN0IF9vcGFjaXR5ID0gY29uZmlnRGF0YS5jb2xvci5vcGFjaXR5O1xuICBjb25zdCBfbGVnZW5kRGlzcGxheSA9IGNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXk7XG4gIGNvbnN0IF9ncmlkWURpc3BsYXkgPSBjb25maWdEYXRhLmdyaWQueS5kaXNwbGF5O1xuICBjb25zdCBfZ3JpZFhEaXNwbGF5ID0gY29uZmlnRGF0YS5ncmlkLnguZGlzcGxheTtcbiAgY29uc3QgX2xhYmVsRGlzcGxheSA9IGNvbmZpZ0RhdGEubGFiZWwuZGlzcGxheTtcbiAgY29uc3QgX2FuaW1hdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmVuYWJsZTtcbiAgY29uc3QgX2FuaW1hdGlvbkR1cmF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZHVyYXRpb247XG5cbiAgLy8gIEdldCBEYXRhIE5hbWVcbiAgY29uc3QgX3Nlcmllc0RhdGVOYW1lID0gZGF0YVNldEpzb24uc2VyaWVzWzBdO1xuXG4gIC8vICBHZXQgS2V5c1xuICBjb25zdCBfa2V5QXJyYXk6IEFycmF5PHN0cmluZz4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgY29uc3QgX2tleSA9IGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZTtcbiAgICAgICAgICBjb25zdCBfdmFsdWUgPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlWzBdLnk7XG4gICAgICAgICAgX2tleUFycmF5LnB1c2goX2tleSk7XG4gICAgICB9XG4gIH1cblxuICAvLyAgR2V0IERhdGUgU3RyaW5nXG4gIGNvbnN0IF9kYXRlQXJyYXk6IEFycmF5PHN0cmluZz4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWUpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgY29uc3QgX3hWYWx1ZSA9IGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWVbaV0ueDtcbiAgICAgICAgICBfZGF0ZUFycmF5LnB1c2goX3hWYWx1ZSk7XG4gICAgICB9XG4gIH1cblxuICBjb25zdCBfaGFzaEFycmF5OiBBcnJheTxhbnk+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBfZGF0ZUFycmF5KSB7XG4gICAgICBpZiAoX2RhdGVBcnJheS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIGNvbnN0IF9kYXRlU3QgPSBfZGF0ZUFycmF5W2ldO1xuICAgICAgICAgIGNvbnN0IF9oYXNoTnVtYmVyOiBIYXNoTnVtYmVyID0geyB9O1xuICAgICAgICAgIGZvciAoY29uc3QgaiBpbiBfa2V5QXJyYXkpIHtcbiAgICAgICAgICAgICAgaWYgKF9rZXlBcnJheS5oYXNPd25Qcm9wZXJ0eShqKSkge1xuICAgICAgICAgICAgICAgICAgY29uc3QgX2tleSA9IF9rZXlBcnJheVtqXTtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IF92YWx1ZSA9IGRhdGFTZXRKc29uLmRhdGFbal0udmFsdWVbaV0ueTtcbiAgICAgICAgICAgICAgICAgIF9oYXNoTnVtYmVyW19rZXldICA9IF92YWx1ZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBfaGFzaEFycmF5LnB1c2goX2hhc2hOdW1iZXIpO1xuICAgICAgfVxuICB9XG5cbiAgY29uc3QgeVNjYWxlID0gZDMuc2NhbGVMaW5lYXIoKVxuICAgICAgICAgICAgICAgICAgLmRvbWFpbihbMCwgX21heFlWYWx1ZV0pXG4gICAgICAgICAgICAgICAgICAucmFuZ2UoWzAsIF9ncmFwaEhlaWdodF0pO1xuXG5cbiAgY29uc3Qgc3RhY2sgPSBkMy5zdGFjaygpO1xuICBjb25zdCBfcmVjdCA9IHN2Z0NvbnRhaW5lci5zZWxlY3RBbGwoJ2cnKVxuICAgICAgLmRhdGEoc3RhY2sua2V5cyhfa2V5QXJyYXkpKF9oYXNoQXJyYXkpKVxuICAgICAgLmVudGVyKClcbiAgICAgIC5hcHBlbmQoJ2cnKVxuICAgICAgLmF0dHIoJ2ZpbGwnLCAoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICByZXR1cm4gX2NvbG9yKGkpO1xuICAgICAgfSApXG4gICAgICAuYXR0cignZmlsbC1vcGFjaXR5JywgX29wYWNpdHkpXG4gICAgICAuc2VsZWN0QWxsKCdyZWN0JylcbiAgICAgIC5kYXRhKChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgIHJldHVybiBkO1xuICAgICAgfSlcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdyZWN0Jyk7XG5cblxuXG4gIGlmIChfYW5pbWF0aW9uKSB7XG4gICAgICBfcmVjdC5hdHRyKCd4JywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIF9pbml0UG9zWMOjwoDCgCArIMOjwoDCgGkgKiBfY29sdW1uV2lkdGg7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ2hlaWdodCcsICAwKVxuICAgICAgLmF0dHIoJ3knLCAoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICBjb25zdCBubSA9ICdkLmRhdGEuJyArIF9rZXlBcnJheVtpXTtcbiAgICAgICAgICBjb25zdCBfeVZhbHVlID0gZXZhbChubSk7XG4gICAgICAgICAgcmV0dXJuIHN2Z0hlaWdodCAtIGNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbSAtIHlTY2FsZShkWzFdKTtcbiAgICAgIH0pXG4gICAgICAuYXR0cignd2lkdGgnLCBfYmFyV2lkdGgpXG4gICAgICAudHJhbnNpdGlvbigpXG4gICAgICAuZHVyYXRpb24oX2FuaW1hdGlvbkR1cmF0aW9uKVxuICAgICAgLmF0dHIoJ2hlaWdodCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgIHJldHVybiB5U2NhbGUoZFsxXSAtIGRbMF0pO1xuICAgICAgfSk7XG4gIH0gZWxzZSB7XG4gICAgICBfcmVjdC5hdHRyKCd4JywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgcmV0dXJuIF9pbml0UG9zWCArIChpICogX2NvbHVtbldpZHRoKTtcbiAgICAgIH0pXG4gICAgICAuYXR0cigneScsIChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgIGNvbnN0IG5tID0gJ2QuZGF0YS4nICsgX2tleUFycmF5W2ldO1xuICAgICAgICAgIGNvbnN0IF95VmFsdWUgPSBldmFsKG5tKTtcbiAgICAgICAgICByZXR1cm4gc3ZnSGVpZ2h0IC0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tIC0geVNjYWxlKGRbMV0pO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCd3aWR0aCcsIF9iYXJXaWR0aClcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCAoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICByZXR1cm4geVNjYWxlKGRbMV0gLSBkWzBdKTtcbiAgICAgIH0pO1xuICB9XG5cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZFRpdGxlLS0tLS0tLS0tLS0tLS0tLS1cbiAgdGhpcy5kcmF3VGl0bGUoY2R0KTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZEF4aXMtLS0tLS0tLS0tLS0tLS0tLVxuICB0aGlzLmJ1aWxkWUF4aXMoY2R0KTtcblxuICB0aGlzLmRyYXdYQmFzZUxpbmUoY2R0KTtcblxuICAvLyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vICAtLS1DQUxMIGRyYXdYQXhpc0xhYmVsLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF9sYWJlbERpc3BsYXkpIHtcbiAgICAgIGNvbnN0IF9sYWJlbEFycmF5OiAgQXJyYXk8c3RyaW5nPiA9IG5ldyBBcnJheSgpO1xuICAgICAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWUpIHtcbiAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICBfbGFiZWxBcnJheS5wdXNoKGRhdGFTZXRKc29uLmRhdGFbMF0udmFsdWVbaV0ueCk7XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5kcmF3WEF4aXNMYWJlbChjZHQsIF9sYWJlbEFycmF5LCBDaGFydENvbnN0LlNUQUNLX0JBUl9DSEFSVF9UWVBFX05BTUUpO1xuICB9XG5cblxuICAvLyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vICAtLS1DQUxMIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF9sZWdlbmREaXNwbGF5KSB7XG4gICAgICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICAgICAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICBfbGVnZW5kRGF0YVNldC5wdXNoKG5ldyBPMkxlZ2VuZERhdGEoZGF0YVNldEpzb24uZGF0YVtpXS5uYW1lLCBfY29sb3IoaSkpKTtcbiAgICAgICAgICB9XG4gICAgICB9XG4gICAgICB0aGlzLmJ1aWxkTGVnZW5kKGNkdCwgX2xlZ2VuZERhdGFTZXQpO1xuICB9XG5cbiAgaWYgKF9ncmlkWURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1lHcmlkKGNkdCk7XG4gIH1cblxufVxuXG5wcml2YXRlIGJ1aWxkU2NhdHRlclBsb3Qoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnSW4gIGJ1aWxkU2NhdHRlclBsb3QtLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgX2RhdGFTZXQ6IEFycmF5PE8yU2NhdHRlclBsb3REYXRhPiA9IG5ldyBBcnJheSgpO1xuICBsZXQgX21heFggPSAwO1xuICBsZXQgX21heFkgPSAwO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGogaW4gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZSkge1xuICAgICAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZS5oYXNPd25Qcm9wZXJ0eShqKSkge1xuICAgICAgICAgICAgICAgICAgaWYgKF9tYXhYIDwgZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS54KSB7XG4gICAgICAgICAgICAgICAgICAgICAgX21heFggPSBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLng7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICBpZiAoX21heFkgPCBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLnkpIHtcbiAgICAgICAgICAgICAgICAgICAgICBfbWF4WSA9IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGNvbnN0IF9zY2F0dGVyUGxvdERhdGEgPSBuZXcgTzJTY2F0dGVyUGxvdERhdGEoXG4gICAgICAgICAgICAgICAgICAgICAgZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS54LFxuICAgICAgICAgICAgICAgICAgICAgIGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueSxcbiAgICAgICAgICAgICAgICAgICAgICBkYXRhU2V0SnNvbi5kYXRhW2ldLnZhbHVlW2pdLnIsXG4gICAgICAgICAgICAgICAgICApIDtcbiAgICAgICAgICAgICAgICAgIF9kYXRhU2V0LnB1c2goX3NjYXR0ZXJQbG90RGF0YSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICB9XG4gIH1cbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcblxuICBjb25zdCBfaW5pdFBvc1ggPSBjZHQuZ3JhcGhJbml0WFBvcztcbiAgY29uc3QgX2luaXRQb3NZID0gY2R0LmdyYXBoSW5pdFlQb3M7XG5cbiAgY29uc3QgX3Nlcmllc051bWJlciA9IGRhdGFTZXRKc29uLnNlcmllcy5sZW5ndGg7XG4gIGNvbnN0IF9jb2xvciA9IGNkdC5kZWZhdWx0Q29sb3JGdW5jO1xuICBjb25zdCBfb3BhY2l0eSA9IGNvbmZpZ0RhdGEuY29sb3Iub3BhY2l0eTtcbiAgY29uc3QgX2dyaWRZRGlzcGxheSA9IGNvbmZpZ0RhdGEuZ3JpZC55LmRpc3BsYXk7XG4gIGNvbnN0IF9ncmlkWERpc3BsYXkgPSBjb25maWdEYXRhLmdyaWQueC5kaXNwbGF5O1xuICBjb25zdCBfdGl0bGVEaXNwbGF5ID0gY29uZmlnRGF0YS50aXRsZS5kaXNwbGF5O1xuICBjb25zdCBfbGVnZW5kRGlzcGxheSA9IGNvbmZpZ0RhdGEubGVnZW5kLmRpc3BsYXk7XG5cbiAgY29uc3QgX2NpcmNsZSA9IHN2Z0NvbnRhaW5lci5zZWxlY3RBbGwoJ2NpcmNsZScpXG4gICAgICAgICAgLmRhdGEoX2RhdGFTZXQpXG4gICAgICAgICAgLmVudGVyKClcbiAgICAgICAgICAuYXBwZW5kKCdjaXJjbGUnKVxuICAgICAgICAgIC5hdHRyKCdjeCcsIChkOiBPMlNjYXR0ZXJQbG90RGF0YSwgaTogYW55KTogbnVtYmVyID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIF9pbml0UG9zWCArIGQueDtcbiAgICAgICAgICB9KVxuICAgICAgICAgIC5hdHRyKCdjeScsIChkOiBPMlNjYXR0ZXJQbG90RGF0YSwgaTogYW55KTogbnVtYmVyID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIChzdmdIZWlnaHQgLSBjb25maWdEYXRhLm1hcmdpbi5ib3R0b20gLSBkLnkpO1xuICAgICAgICAgIH0pXG4gICAgICAgICAgLmF0dHIoJ3InLCAoZDogTzJTY2F0dGVyUGxvdERhdGEsIGk6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiBkLnI7XG4gICAgICAgICAgfSlcbiAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgICAgIGNvbnN0IF9jb2xvck51bSA9IGkgJSBfc2VyaWVzTnVtYmVyO1xuICAgICAgICAgICAgICByZXR1cm4gX2NvbG9yKF9jb2xvck51bSk7XG4gICAgICAgICAgfSlcbiAgICAgICAgICAuYXR0cignZmlsbC1vcGFjaXR5JywgIF9vcGFjaXR5KTtcblxuXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfdGl0bGVEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdUaXRsZShjZHQpO1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRMZWdlbmQtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX2xlZ2VuZERpc3BsYXkpIHtcbiAgICAgIGNvbnN0IF9sZWdlbmREYXRhU2V0OiBBcnJheTxPMkxlZ2VuZERhdGE+ID0gbmV3IEFycmF5KCk7XG4gICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRhdGFTZXRKc29uLnNlcmllcy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShkYXRhU2V0SnNvbi5zZXJpZXNbaV0sIF9jb2xvcihpKSkpO1xuICAgICAgfVxuICAgICAgdGhpcy5idWlsZExlZ2VuZChjZHQsIF9sZWdlbmREYXRhU2V0KTtcbiAgfVxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZEF4aXMtLS0tLS0tLS0tLS0tLS0tLVxuICB0aGlzLmJ1aWxkWUF4aXMoY2R0KTtcblxuICB0aGlzLmJ1aWxkWEF4aXMoY2R0KTtcblxuICBpZiAoX2dyaWRZRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3WUdyaWQoY2R0KTtcbiAgfVxuICBpZiAoX2dyaWRYRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3WEdyaWQoY2R0KTtcbiAgfVxufVxuXG5cblxucHJpdmF0ZSBkcmF3WEdyaWQobzJDb21tb246IGFueSk6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZFhHcmlkLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IGNkdCA9IG8yQ29tbW9uO1xuICBjb25zdCBjb25maWdEYXRhID0gY2R0LmNvbmZpZ0RhdGE7XG4gIGNvbnN0IHN2Z0NvbnRhaW5lciA9IGNkdC5zdmdDb250YWluZXI7XG5cbiAgY29uc3QgX3N0ZXBYID0gIGNkdC5ncmlkWFN0ZXA7XG5cbiAgY29uc3QgX21heFggPSBjZHQubWF4WFZhbHVlO1xuICBjb25zdCBfZ3JhcGhZU2NhbGUgPSBjZHQuZ3JhcGhZU2NhbGU7XG4gIGNvbnN0IF9ncmFwaFhTY2FsZSA9IGNkdC5ncmFwaFhTY2FsZTtcbiAgY29uc3QgX2dyYXBoV2lkdGggPSBjZHQuZ3JhcGhXaWR0aDtcbiAgY29uc3QgX2dyaWRDbGFzc05hbWUgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5ncmlkO1xuICBjb25zdCBfYXhpc1hTY2FsZSA9IGQzLnNjYWxlTGluZWFyKClcbiAgICAgICAgICAgICAgICAgIC5kb21haW4oWzAsIF9tYXhYXSlcbiAgICAgICAgICAgICAgICAgIC5yYW5nZShbMCwgX21heFggKiBfZ3JhcGhYU2NhbGVdKTtcbiAgY29uc3QgX3JhbmdlWCA9IGQzLnJhbmdlKF9zdGVwWCAqIF9ncmFwaFhTY2FsZSxcbiAgICAgICAgICAgICAgICAgIF9tYXhYICAqIF9ncmFwaFhTY2FsZSxcbiAgICAgICAgICAgICAgICAgIF9zdGVwWCAqIF9ncmFwaFhTY2FsZSk7XG5cbiAgc3ZnQ29udGFpbmVyLmFwcGVuZCgnZycpXG4gICAgICAuc2VsZWN0QWxsKCdsaW5lLngnKVxuICAgICAgLmRhdGEoX3JhbmdlWClcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdsaW5lJylcbiAgICAgIC5hdHRyKCdjbGFzcycsIF9ncmlkQ2xhc3NOYW1lKVxuICAgICAgLmF0dHIoJ3gxJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiAge1xuICAgICAgICAgIGNvbnN0IF94MSA9IGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQgICsgZDtcbiAgICAgICAgICByZXR1cm4gX3gxO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCd5MScsIGNkdC5zdmdIZWlnaHQgLSBjb25maWdEYXRhLm1hcmdpbi5ib3R0b20pXG4gICAgICAuYXR0cigneDInLCAoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgY29uc3QgX3gyID0gY29uZmlnRGF0YS5tYXJnaW4ubGVmdCAgKyBkO1xuICAgICAgICAgIHJldHVybiBfeDI7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ3kyJywgY29uZmlnRGF0YS5tYXJnaW4udG9wICsgY29uZmlnRGF0YS50aXRsZS5oZWlnaHQpO1xufVxuXG5wcml2YXRlIGJ1aWxkWEF4aXMobzJDb21tb246IGFueSk6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZFhBeGlzLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IGNkdCA9IG8yQ29tbW9uO1xuICBjb25zdCBjb25maWdEYXRhID0gY2R0LmNvbmZpZ0RhdGE7XG4gIGNvbnN0IHN2Z0NvbnRhaW5lciA9IGNkdC5zdmdDb250YWluZXI7XG5cbiAgY29uc3QgX21heFggPSBjZHQubWF4WFZhbHVlO1xuICBjb25zdCBfZ3JhcGhYU2NhbGUgPSBjZHQuZ3JhcGhYU2NhbGU7XG5cbiAgY29uc3QgX2F4aXNYU2NhbGUgPSBkMy5zY2FsZUxpbmVhcigpXG4gICAgICAgICAgICAgICAgICAuZG9tYWluKFswLCBfbWF4WF0pXG4gICAgICAgICAgICAgICAgICAucmFuZ2UoWzAsIF9tYXhYICogX2dyYXBoWFNjYWxlXSk7XG5cbiAgc3ZnQ29udGFpbmVyLmFwcGVuZCgnZycpXG4gICAgICAuYXR0cignY2xhc3MnLCBjZHQuYXhpc0NsYXNzTmFtZSlcbiAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBjZHQuYXhpc1hCb3JkZXJUcmFuc2xhdGVQb3MpXG4gICAgICAuY2FsbChcbiAgICAgICAgICAgIGQzLmF4aXNCb3R0b20oX2F4aXNYU2NhbGUpXG4gICAgICApO1xuICAgICAgICAgICAgLy8gIC5zY2FsZSgpXG4gICAgICAgICAgICAvLyAgLm9yaWVudChjZHQuYXhpc1hPcmllbnQpXG4gICAgICAgICAgICAvLyAgKTtcbn1cblxuXG5cbnByaXZhdGUgYnVpbGRQaWUoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnSW4gIGJ1aWxkUGllLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IF9tYXhYID0gMTAwO1xuICBjb25zdCBfbWF4WSA9IDEwMDtcbiAgY29uc3QgY2R0ID0gbmV3IE8yQ29tbW9uKHN2Z0NvbnRhaW5lciwgY29uZmlnRGF0YSwgX21heFgsIF9tYXhZLCBzdmdXaWR0aCwgc3ZnSGVpZ2h0KTtcblxuICBjb25zdCBfY29sb3IgPSBjZHQuZGVmYXVsdENvbG9yRnVuYztcbiAgY29uc3QgX2luaXRQb3NYID0gY2R0LmdyYXBoSW5pdFhQb3M7XG4gIGNvbnN0IF9pbml0UG9zWSA9IGNkdC5ncmFwaEluaXRZUG9zO1xuICBjb25zdCBfZ3JhcGhIZWlnaHQgPSBjZHQuZ3JhcGhIZWlnaHQ7XG4gIGNvbnN0IF9ncmFwaFdpZHRoID0gY2R0LmdyYXBoV2lkdGg7XG5cbiAgY29uc3QgX29wYWNpdHkgPSBjb25maWdEYXRhLmNvbG9yLm9wYWNpdHk7XG4gIGNvbnN0IF90aXRsZUhlaWdodCA9IGNvbmZpZ0RhdGEudGl0bGUuaGVpZ2h0O1xuICBjb25zdCBfbGVmdE1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLmxlZnQ7XG4gIGNvbnN0IF90b3BNYXJnaW4gPSBjb25maWdEYXRhLm1hcmdpbi50b3A7XG4gIGNvbnN0IF9ib3R0b21NYXJnaW4gPSBjb25maWdEYXRhLm1hcmdpbi5ib3R0b207XG4gIGNvbnN0IF9iZXR3ZWVuTWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4uYmV0d2VlbjtcbiAgY29uc3QgX2lubmVyUmFkaXVzUGVyY2VudCA9IGNkdC5pbm5lclJhZGl1c1BlcmNlbnQ7XG4gIGNvbnN0IF9ncmFwaENlbnRlclRyYW5zbGF0ZVBvcyA9IGNkdC5ncmFwaENlbnRlclRyYW5zbGF0ZVBvcztcbiAgY29uc3QgX3BpZUNsYXNzTmFtZSA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLnBpZTtcbiAgY29uc3QgX3BpZVZhbHVlQ2xhc3NOYW1lID0gY29uZmlnRGF0YS5jbGFzc05hbWUucGllTnVtO1xuICBjb25zdCBfcGllSW5uZXJUaXRsZUNsYXNzTmFtZSA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLnBpZUlubmVyVGl0bGU7XG4gIGNvbnN0IF9pbm5lclJhZGl1c1RpdGxlVHJhbnNsYXRlUG9zID0gY2R0LmlubmVyUmFkaXVzVGl0bGVUcmFuc2xhdGVQb3M7XG4gIGNvbnN0IF9pbm5lclJhZGl1c1RpdGxlID0gY2R0LmlubmVyUmFkaXVzVGl0bGU7XG4gIGNvbnN0IF90aXRsZURpc3BsYXkgPSBjb25maWdEYXRhLnRpdGxlLmRpc3BsYXk7XG4gIGNvbnN0IF9sZWdlbmREaXNwbGF5ID0gY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheTtcbiAgY29uc3QgX2xhYmVsRGlzcGxheSA9IGNvbmZpZ0RhdGEubGFiZWwuZGlzcGxheTtcbiAgY29uc3QgX3ZhbHVlRGlzcGxheSA9IGNvbmZpZ0RhdGEucGllLnZhbHVlLmRpc3BsYXk7XG4gIGNvbnN0IF9wZXJjZW50RGlzcGxheSA9IGNvbmZpZ0RhdGEucGllLnBlcmNlbnQuZGlzcGxheTtcbiAgY29uc3QgX2FuaW1hdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmVuYWJsZTtcbiAgY29uc3QgX2FuaW1hdGlvbkR1cmF0aW9uID0gY29uZmlnRGF0YS5hbmltYXRpb24uZHVyYXRpb247XG5cbiAgY29uc3Qgd2lkdGggPSBzdmdXaWR0aDtcbiAgY29uc3QgaGVpZ2h0ID0gc3ZnSGVpZ2h0O1xuXG4gIGNvbnN0IGRhdGFTZXQ6IEFycmF5PG51bWJlcj4gPSBuZXcgQXJyYXkoKTtcbiAgZm9yIChjb25zdCBpICBpbiAgZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBjb25zdCBfbnVtID0gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZTtcbiAgICAgICAgICBkYXRhU2V0LnB1c2goX251bSk7XG4gICAgICB9XG4gIH1cblxuICBjb25zdCBfc3VtID0gZDMuc3VtKGRhdGFTZXQpO1xuICBjb25zdCBwaWUgPSBkMy5waWUoKTtcbiAgY29uc3QgYXJjID0gZDMuYXJjKClcbiAgICAgICAgICAgICAgLmlubmVyUmFkaXVzKF9ncmFwaEhlaWdodCAqIF9pbm5lclJhZGl1c1BlcmNlbnQgLyAxMDApXG4gICAgICAgICAgICAgIC5vdXRlclJhZGl1cyhfZ3JhcGhIZWlnaHQgLyAyKTtcblxuICBjb25zdCBwaWVFbGVtZW50cyA9IHN2Z0NvbnRhaW5lci5zZWxlY3RBbGwoJ3BhdGgnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAuZGF0YShwaWUoZGF0YVNldCkpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5lbnRlcigpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5hcHBlbmQoJ2cnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgX2dyYXBoQ2VudGVyVHJhbnNsYXRlUG9zKTtcblxuXG4gIGNvbnN0IF9tYWtlQ2VudGVyVGl0bGUgPSAoKTogc3RyaW5nID0+IHtcbiAgICAgICAgICBpZiAoX3ZhbHVlRGlzcGxheSAmJiBfcGVyY2VudERpc3BsYXkpIHtcbiAgICAgICAgICAgICAgY29uc3QgX3N0ID0gX2lubmVyUmFkaXVzVGl0bGUgKyAnOicgKyBfc3VtICsgICcgKDEwMCUpJztcbiAgICAgICAgICAgICAgcmV0dXJuIF9zdDtcbiAgICAgICAgICB9XG4gICAgICAgICAgaWYgKF9wZXJjZW50RGlzcGxheSkge1xuICAgICAgICAgICAgICByZXR1cm4gJzEwMCUnO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAoX3ZhbHVlRGlzcGxheSkge1xuICAgICAgICAgICAgICByZXR1cm4gX2lubmVyUmFkaXVzVGl0bGUgKyAnOicgKyBfc3VtO1xuICAgICAgICAgIH1cbiAgfTtcblxuICBjb25zdCB0ZXh0RWxlbWVudHMgPSBzdmdDb250YWluZXIuYXBwZW5kKCd0ZXh0JylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLmF0dHIoJ2NsYXNzJywgX3BpZUlubmVyVGl0bGVDbGFzc05hbWUpXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC5hdHRyKCd0cmFuc2Zvcm0nLCBfaW5uZXJSYWRpdXNUaXRsZVRyYW5zbGF0ZVBvcyApXG4gICAgICAgICAgICAgICAgICAgICAgICAgIC50ZXh0KF9tYWtlQ2VudGVyVGl0bGUpO1xuXG4gIGNvbnN0IF9hcmMgPSBwaWVFbGVtZW50cy5hcHBlbmQoJ3BhdGgnKVxuICAgICAgICAgICAgICAuYXR0cignY2xhc3MnLCBfcGllQ2xhc3NOYW1lKVxuICAgICAgICAgICAgICAuc3R5bGUoJ2ZpbGwnLCAoZDogYW55LCBpOiBudW1iZXIpID0+ICB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gX2NvbG9yKGkpO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAuYXR0cignZmlsbC1vcGFjaXR5JywgX29wYWNpdHkpO1xuXG4gIC8vICBGb3IgZDNWZXJzaW9uNCBhbmltYXRpb24gaXMgbm90IGF2YWlsYWJsZSBub3dcbiAgLy8gIGlmIChfYW5pbWF0aW9uKSB7XG4gIC8vICAgICAgX2FyYy50cmFuc2l0aW9uKClcbiAgLy8gICAgICAuZHVyYXRpb24oX2FuaW1hdGlvbkR1cmF0aW9uKVxuICAvLyAgICAgIC5kZWxheSgoZCxpKT0+IHtcbiAgLy8gICAgICAgICAgcmV0dXJuIGkgKjEwMDA7XG4gIC8vICAgICAgfSlcbiAgLy8gICAgICAuYXR0clR3ZWVuKCdkJywoZDogYW55LGk6IG51bWJlcikgPT4gIHtcbiAgLy8gICAgICAgICAgY29uc3QgX2ludGVycG9sYXRlID0gZDMuaW50ZXJwb2xhdGVPYmplY3QoXG4gIC8vICAgICAgICAgICAgICB7IHN0YXJ0QW5nbGU6ZC5zdGFydEFuZ2xlLGVuZEFuZ2xlOmQuc3RhcnRBbmdsZSB9XG4gIC8vICAgICAgICAgICAgICB7IHN0YXJ0QW5nbGU6ZC5zdGFydEFuZ2xlLGVuZEFuZ2xlOmQuZW5kQW5nbGUgfVxuICAvLyAgICAgICAgICApXG4gIC8vICAgICAgICAgIHJldHVybiAodCkge1xuICAvLyAgICAgICAgICAgICAgcmV0dXJuIGFyYyhfaW50ZXJwb2xhdGUodCkpO1xuICAvLyAgICAgICAgICB9XG4gIC8vICAgICAgfSlcbiAgLy8gIH1cbiAgLy8gIGVsc2V7XG4gIC8vICAgICAgX2FyYy5hdHRyKCdkJyxhcmMpO1xuICAvLyAgfVxuICBfYXJjLmF0dHIoJ2QnLCBhcmMpO1xuXG4gIHBpZUVsZW1lbnRzLmFwcGVuZCgndGV4dCcpXG4gICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIF9waWVWYWx1ZUNsYXNzTmFtZSlcbiAgICAgICAgICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIChkOiBhbnksIGk6IG51bWJlcikgPT4ge1xuICAgICAgICAgICAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgYXJjLmNlbnRyb2lkKGQpICsgJyknO1xuICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAudGV4dCgoZDogYW55LCBpOiBudW1iZXIpID0+IHtcbiAgICAgICAgICAgICAgICAgIGlmIChfdmFsdWVEaXNwbGF5ICYmIF9wZXJjZW50RGlzcGxheSkge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IF9wZXJjZW50U3QgPSBTdHJpbmcoTWF0aC5jZWlsKGQudmFsdWUgLyBfc3VtICAqIDEwMCkpO1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IF9zdCA9IFN0cmluZyhkLnZhbHVlKSArICcgKCcgKyBfcGVyY2VudFN0ICsgJyUpJztcbiAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX3N0O1xuICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgaWYgKF9wZXJjZW50RGlzcGxheSkge1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IF9wZXJjZW50U3QgPSBTdHJpbmcoTWF0aC5jZWlsKGQudmFsdWUgLyBfc3VtICAqIDEwMCkpO1xuICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IF9zdCA9IF9wZXJjZW50U3QgKyAnJSc7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9zdDtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgIGlmIChfdmFsdWVEaXNwbGF5KSB7XG4gICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGQudmFsdWU7XG4gICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pO1xuXG4gIC8vIC0tLUNBTEwgYnVpbGRUaXRsZS0tLS0tLS0tLS0tLS0tLS0tXG4gIGlmIChfdGl0bGVEaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdUaXRsZShjZHQpO1xuICB9XG5cbiAgLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vIC0tLUNBTEwgYnVpbGRMZWdlbmQtLS0tLS0tLS0tLS0tLS0tLVxuICBpZiAoX2xlZ2VuZERpc3BsYXkpIHtcbiAgICAgIGNvbnN0IF9sZWdlbmREYXRhU2V0OiBBcnJheTxPMkxlZ2VuZERhdGE+ID0gbmV3IEFycmF5KCk7XG4gICAgICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgICAgIF9sZWdlbmREYXRhU2V0LnB1c2gobmV3IE8yTGVnZW5kRGF0YShkYXRhU2V0SnNvbi5kYXRhW2ldLm5hbWUsIF9jb2xvcihpKSkpO1xuICAgICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHRoaXMuYnVpbGRMZWdlbmQoY2R0LCBfbGVnZW5kRGF0YVNldCk7XG4gIH1cbn1cblxuXG5cbnByaXZhdGUgYnVpbGRCYXIoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnSW4gIGJ1aWxkQmFyLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IF95RGF0YVNldDogQXJyYXk8bnVtYmVyPiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBmb3IgKGNvbnN0IGogaW4gZGF0YVNldEpzb24uZGF0YVtpXS55KSB7XG4gICAgICAgICAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhW2ldLnkuaGFzT3duUHJvcGVydHkoaikpIHtcbiAgICAgICAgICAgICAgICAgIGNvbnN0IF95ID0gZGF0YVNldEpzb24uZGF0YVtpXS55W2pdO1xuICAgICAgICAgICAgICAgICAgX3lEYXRhU2V0LnB1c2goX3kpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgfVxuICB9XG5cbiAgbGV0IF9tYXhYID0gMDtcbiAgbGV0IF9tYXhZID0gMDtcbiAgX21heFkgPSBkMy5tYXgoX3lEYXRhU2V0KTtcbiAgX21heFggPSAxMDA7XG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG5cbiAgY29uc3QgX2JhclZhbHVlQ2xhc3MgPSBjb25maWdEYXRhLmNsYXNzTmFtZS5iYXJWYWx1ZTtcbiAgY29uc3QgX2NvbG9yID0gY2R0LmRlZmF1bHRDb2xvckZ1bmM7XG4gIGNvbnN0IF9zZXJpZXNOdW0gPSAgZGF0YVNldEpzb24uc2VyaWVzLmxlbmd0aDtcbiAgY29uc3QgX2NvbHVtbk51bSA9ICBfeURhdGFTZXQubGVuZ3RoO1xuICBjb25zdCBfaW5pdFBvc1ggPSBjZHQuZ3JhcGhJbml0WFBvcztcbiAgY29uc3QgX2luaXRQb3NZID0gY2R0LmdyYXBoSW5pdFlQb3M7XG4gIGNvbnN0IF9ncmFwaEhlaWdodCA9IGNkdC5ncmFwaEhlaWdodDtcbiAgY29uc3QgX2dyYXBoV2lkdGggPSBjZHQuZ3JhcGhXaWR0aDtcbiAgY29uc3QgX21heFlWYWx1ZSA9IGNkdC5tYXhZVmFsdWU7XG4gIGNvbnN0IF9vcGFjaXR5ID0gY29uZmlnRGF0YS5jb2xvci5vcGFjaXR5O1xuICBjb25zdCBfdGl0bGVIZWlnaHQgPSBjb25maWdEYXRhLnRpdGxlLmhlaWdodDtcbiAgY29uc3QgX3RpdGxlRGlzcGxheSA9IGNvbmZpZ0RhdGEudGl0bGUuZGlzcGxheTtcbiAgY29uc3QgX2xlZnRNYXJnaW4gPSBjb25maWdEYXRhLm1hcmdpbi5sZWZ0O1xuICBjb25zdCBfdG9wTWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4udG9wO1xuICBjb25zdCBfYm90dG9tTWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tO1xuICBjb25zdCBfYmV0d2Vlbk1hcmdpbiA9IGNvbmZpZ0RhdGEubWFyZ2luLmJldHdlZW47XG4gIGNvbnN0IF9sZWdlbmREaXNwbGF5ID0gY29uZmlnRGF0YS5sZWdlbmQuZGlzcGxheTtcbiAgY29uc3QgX2xhYmVsRGlzcGxheSA9IGNvbmZpZ0RhdGEubGFiZWwuZGlzcGxheTtcbiAgY29uc3QgX2dyaWRZRGlzcGxheSA9IGNvbmZpZ0RhdGEuZ3JpZC55LmRpc3BsYXk7XG4gIGNvbnN0IF9hbmltYXRpb24gPSBjb25maWdEYXRhLmFuaW1hdGlvbi5lbmFibGU7XG4gIGNvbnN0IF9hbmltYXRpb25EdXJhdGlvbiA9IGNvbmZpZ0RhdGEuYW5pbWF0aW9uLmR1cmF0aW9uO1xuXG4gIGNvbnN0IF9iYXJXaWR0aCA9IChfZ3JhcGhXaWR0aCAtIChfYmV0d2Vlbk1hcmdpbiAqIF9jb2x1bW5OdW0gLyBfc2VyaWVzTnVtKSkgLyAgX2NvbHVtbk51bTtcbiAgY29uc3QgX2NvbHVtbldpZHRoID0gKF9ncmFwaFdpZHRoIC8gX2NvbHVtbk51bSkgO1xuXG4gIGNvbnN0IF9ncmFwaFlTY2FsZSA9IGNkdC5ncmFwaFlTY2FsZTtcblxuICBjb25zdCB5QmFyU2NhbGUgPSBkMy5zY2FsZUxpbmVhcigpXG4gICAgICAgICAgICAgICAgICAuZG9tYWluKFswLCBfbWF4WV0pXG4gICAgICAgICAgICAgICAgICAucmFuZ2UoW19tYXhZICogX2dyYXBoWVNjYWxlLCAwXSk7XG5cbiAgY29uc3QgX2JhclBhZGRpbmcgPSBfYmV0d2Vlbk1hcmdpbjtcblxuXG5cblxuICBjb25zdCBncnBHcmFwaCA9IHN2Z0NvbnRhaW5lci5zZWxlY3RBbGwoJ2cnKVxuICAgICAgLmRhdGEoX3lEYXRhU2V0KVxuICAgICAgLmVudGVyKClcbiAgICAgIC5hcHBlbmQoJ2cnKVxuICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIChkOiBhbnksIGk6IG51bWJlcik6IHN0cmluZyA9PiB7XG4gICAgICAgICAgY29uc3QgX3BhZGRpbmcgPSAoKGkgJSBfc2VyaWVzTnVtKSA9PT0gMCkgPyBfYmFyUGFkZGluZyA6IDA7XG4gICAgICAgICAgcmV0dXJuICd0cmFuc2xhdGUoJyArIChfcGFkZGluZyArIF9jb2x1bW5XaWR0aCAqIGkpICsgJyknO1xuICAgICAgfSlcbiAgICAgIC5zdHlsZSgnZmlsbCcsIChkOiBhbnksIGk6IG51bWJlcikgPT4gIHtcbiAgICAgICAgICBjb25zdCBfcmVtbmFudCA9IChpICUgX3Nlcmllc051bSk7XG4gICAgICAgICAgcmV0dXJuIF9jb2xvcihfcmVtbmFudCk7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ2ZpbGwtb3BhY2l0eScsIF9vcGFjaXR5KTtcblxuICBjb25zdCBfcmVjdCA9ICBncnBHcmFwaC5hcHBlbmQoJ3JlY3QnKTtcbiAgaWYgKF9hbmltYXRpb24pIHtcbiAgICAgIF9yZWN0LmF0dHIoJ3gnLCBfbGVmdE1hcmdpbilcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCAwKVxuICAgICAgLmF0dHIoJ3knLCAoZDogYW55KTogbnVtYmVyID0+IHtcbiAgICAgICAgICByZXR1cm4gX2luaXRQb3NZO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCd3aWR0aCcsIF9iYXJXaWR0aCAtIF9iYXJQYWRkaW5nKVxuICAgICAgLnRyYW5zaXRpb24oKVxuICAgICAgLmR1cmF0aW9uKF9hbmltYXRpb25EdXJhdGlvbilcbiAgICAgIC5hdHRyKCd5JywgKGQ6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgICAgcmV0dXJuIHlCYXJTY2FsZShkKSArIF9pbml0UG9zWTtcbiAgICAgIH0pXG4gICAgICAuYXR0cignaGVpZ2h0JywgKGQ6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgICAgcmV0dXJuIF9ncmFwaEhlaWdodCAtIHlCYXJTY2FsZShkKSA7XG4gICAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICAgIF9yZWN0LmF0dHIoJ3gnLCBfbGVmdE1hcmdpbilcbiAgICAgIC5hdHRyKCd5JywgKGQ6IGFueSk6IG51bWJlciA9PiB7XG4gICAgICAgICAgcmV0dXJuIHlCYXJTY2FsZShkKSArIF9pbml0UG9zWTtcbiAgICAgIH0pXG4gICAgICAuYXR0cignd2lkdGgnLCBfYmFyV2lkdGggLSBfYmFyUGFkZGluZylcbiAgICAgIC5hdHRyKCdoZWlnaHQnLCAoZDogYW55KTogbnVtYmVyID0+IHtcbiAgICAgICAgICByZXR1cm4gX2dyYXBoSGVpZ2h0IC0geUJhclNjYWxlKGQpO1xuICAgICAgfSk7XG4gIH1cblxuICBjb25zdCB0ZXh0QmFyVmFsdWUgPSBncnBHcmFwaC5hcHBlbmQoJ3RleHQnKTtcbiAgdGV4dEJhclZhbHVlXG4gICAgICAuYXR0cignY2xhc3MnLCBfYmFyVmFsdWVDbGFzcylcbiAgICAgIC5hdHRyKCd4JywgX2xlZnRNYXJnaW4pXG4gICAgICAuYXR0cigneScsIChkOiBhbnkpOiBudW1iZXIgPT4ge1xuICAgICAgICByZXR1cm4geUJhclNjYWxlKGQpICsgX2luaXRQb3NZO1xuICAgICAgfSlcbiAgICAgIC50ZXh0KChkOiBhbnkpOiBzdHJpbmcgPT4ge1xuICAgICAgICByZXR1cm4gZCA7XG4gICAgICB9KTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZEF4aXMtLS0tLS0tLS0tLS0tLS0tLVxuICB0aGlzLmJ1aWxkWUF4aXMoY2R0KTtcblxuICAvLyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vICAtLS1DQUxMIGRyYXdYQXhpc0xhYmVsLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF9sYWJlbERpc3BsYXkpIHtcbiAgICAgIGNvbnN0IF9sYWJlbEFycmF5OiAgQXJyYXk8c3RyaW5nPiA9IG5ldyBBcnJheSgpO1xuICAgICAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgICAgICBfbGFiZWxBcnJheS5wdXNoKGRhdGFTZXRKc29uLmRhdGFbaV0ueCk7XG4gICAgICAgICAgfVxuICAgICAgfVxuICAgICAgdGhpcy5kcmF3WEF4aXNMYWJlbChjZHQsIF9sYWJlbEFycmF5LCBDaGFydENvbnN0LkJBUl9DSEFSVF9UWVBFX05BTUUpO1xuICB9XG5cbiAgdGhpcy5kcmF3WEJhc2VMaW5lKGNkdCk7XG5cbiAgLy8gIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuICAvLyAgLS0tQ0FMTCBidWlsZExlZ2VuZC0tLS0tLS0tLS0tLS0tLS0tXG4gIGNvbnN0IF9sZWdlbmREYXRhU2V0OiBBcnJheTxPMkxlZ2VuZERhdGE+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5zZXJpZXMpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5zZXJpZXMuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgX2xlZ2VuZERhdGFTZXQucHVzaChuZXcgTzJMZWdlbmREYXRhKGRhdGFTZXRKc29uLnNlcmllc1tpXSwgX2NvbG9yKGkpKSk7XG4gICAgICB9XG4gIH1cbiAgdGhpcy5idWlsZExlZ2VuZChjZHQsIF9sZWdlbmREYXRhU2V0KTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZFRpdGxlLS0tLS0tLS0tLS0tLS0tLS1cbiAgaWYgKF90aXRsZURpc3BsYXkpIHtcbiAgICAgIHRoaXMuZHJhd1RpdGxlKGNkdCk7XG4gIH1cblxuICBpZiAoX2dyaWRZRGlzcGxheSkge1xuICAgICAgdGhpcy5kcmF3WUdyaWQoY2R0KTtcbiAgfVxuXG59XG5cblxucHJpdmF0ZSBidWlsZExpbmUoc3ZnQ29udGFpbmVyOiBhbnksIGNvbmZpZ0RhdGE6IGFueSwgZGF0YVNldEpzb246IGFueSwgc3ZnV2lkdGg6IG51bWJlciwgc3ZnSGVpZ2h0OiBudW1iZXIpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRUZXN0LS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IF9ncm91cE1heFk6IEFycmF5PG51bWJlcj4gPSBuZXcgQXJyYXkoKTtcblxuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgICBsZXQgX2dNYXhZID0gMDtcbiAgICAgICAgICBmb3IgKGNvbnN0IGogaW4gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZSkge1xuICAgICAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZS5oYXNPd25Qcm9wZXJ0eShqKSkge1xuICAgICAgICAgICAgICAgICAgaWYgKF9nTWF4WSA8IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueSkge1xuICAgICAgICAgICAgICAgICAgICAgIF9nTWF4WSA9IGRhdGFTZXRKc29uLmRhdGFbaV0udmFsdWVbal0ueTtcbiAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBfZ3JvdXBNYXhZLnB1c2goX2dNYXhZKSA7XG4gICAgICB9XG4gIH1cbiAgbGV0IF9tYXhYID0gMDtcbiAgbGV0IF9tYXhZID0gMDtcbiAgX21heFkgPSBkMy5tYXgoX2dyb3VwTWF4WSk7XG4gIF9tYXhYID0gMTAwO1xuXG4gIGNvbnN0IGNkdCA9IG5ldyBPMkNvbW1vbihzdmdDb250YWluZXIsIGNvbmZpZ0RhdGEsIF9tYXhYLCBfbWF4WSwgc3ZnV2lkdGgsIHN2Z0hlaWdodCk7XG4gIGNvbnN0IF9jb2xvciA9IGNkdC5kZWZhdWx0Q29sb3JGdW5jO1xuXG4gIGNvbnN0IF9jb2x1bW5OdW0gPSBkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlLmxlbmd0aCA7XG4gIGNvbnN0IF9jb2x1bW5XaWR0aCA9IGNkdC5ncmFwaFdpZHRoIC8gX2NvbHVtbk51bTtcblxuICBjb25zb2xlLmxvZyhfY29sdW1uV2lkdGgpO1xuXG4gIGlmIChjb25maWdEYXRhLmdyaWQueS5kaXNwbGF5KSB7XG4gICAgICB0aGlzLmRyYXdZR3JpZChjZHQpO1xuICB9XG5cbiAgLy8gIE8ySWRWYWx1ZURhdGFcbiAgZm9yIChjb25zdCBpIGluIGRhdGFTZXRKc29uLmRhdGEpIHtcbiAgICAgIGlmIChkYXRhU2V0SnNvbi5kYXRhLmhhc093blByb3BlcnR5KGkpKSB7XG4gICAgICAgICAgY29uc3QgX2xpbmVBcnJheTogQXJyYXk8TzJJZFZhbHVlRGF0YT4gPSBuZXcgQXJyYXkoKTtcbiAgICAgICAgICBmb3IgKGNvbnN0IGogaW4gZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZSkge1xuICAgICAgICAgICAgICBpZiAoZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZS5oYXNPd25Qcm9wZXJ0eShqKSkge1xuICAgICAgICAgICAgICAgICAgY29uc3QgaWRWYWx1ZSA9IG5ldyBPMklkVmFsdWVEYXRhKHBhcnNlSW50KGosIDEwKSwgZGF0YVNldEpzb24uZGF0YVtpXS52YWx1ZVtqXS55KTtcbiAgICAgICAgICAgICAgICAgIF9saW5lQXJyYXkucHVzaChpZFZhbHVlKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgICBjb25zdCBudW0gPSBwYXJzZUludChpLCAxMCk7XG4gICAgICAgICAgdGhpcy5kcmF3U2luZ2xlTGluZShjZHQsIF9saW5lQXJyYXksIG51bSk7XG4gICAgICB9XG4gIH1cblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZFRpdGxlLS0tLS0tLS0tLS0tLS0tLS1cbiAgdGhpcy5kcmF3VGl0bGUoY2R0KTtcblxuICAvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gLS0tQ0FMTCBidWlsZEF4aXMtLS0tLS0tLS0tLS0tLS0tLVxuICB0aGlzLmJ1aWxkWUF4aXMoY2R0KTtcblxuICB0aGlzLmRyYXdYQmFzZUxpbmUoY2R0KTtcblxuICAvLyAgLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4gIC8vICAtLS1DQUxMIGRyYXdYQXhpc0xhYmVsLS0tLS0tLS0tLS0tLS0tLS1cbiAgY29uc3QgX2xhYmVsQXJyYXk6ICBBcnJheTxzdHJpbmc+ID0gbmV3IEFycmF5KCk7XG4gIGZvciAoY29uc3QgaSBpbiBkYXRhU2V0SnNvbi5kYXRhWzBdLnZhbHVlKSB7XG4gICAgICBpZiAoZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZS5oYXNPd25Qcm9wZXJ0eShpKSkge1xuICAgICAgICAgIF9sYWJlbEFycmF5LnB1c2goZGF0YVNldEpzb24uZGF0YVswXS52YWx1ZVtpXS54KTtcbiAgICAgIH1cbiAgfVxuICB0aGlzLmRyYXdYQXhpc0xhYmVsKGNkdCwgX2xhYmVsQXJyYXksIENoYXJ0Q29uc3QuTElORV9DSEFSVF9UWVBFX05BTUUpO1xuXG4gIC8vICAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbiAgLy8gIC0tLUNBTEwgYnVpbGRMZWdlbmQtLS0tLS0tLS0tLS0tLS0tLVxuICBjb25zdCBfbGVnZW5kRGF0YVNldDogQXJyYXk8TzJMZWdlbmREYXRhPiA9IG5ldyBBcnJheSgpO1xuICBmb3IgKGNvbnN0IGkgaW4gZGF0YVNldEpzb24uZGF0YSkge1xuICAgICAgaWYgKGRhdGFTZXRKc29uLmRhdGEuaGFzT3duUHJvcGVydHkoaSkpIHtcbiAgICAgICAgX2xlZ2VuZERhdGFTZXQucHVzaChuZXcgTzJMZWdlbmREYXRhKGRhdGFTZXRKc29uLmRhdGFbaV0ubmFtZSwgX2NvbG9yKGkpKSk7XG4gICAgICB9XG4gIH1cbiAgdGhpcy5idWlsZExlZ2VuZChjZHQsIF9sZWdlbmREYXRhU2V0KTtcblxufVxuXG5cblxuXG5wcml2YXRlIGRyYXdTaW5nbGVMaW5lKG8yQ29tbW9uOiBhbnksIGRhdGFTZXQ6IGFueSwgbGluZU51bTogbnVtYmVyKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGRyYXdTaW5nbGVMaW5lLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnNvbGUubG9nKGRhdGFTZXQpO1xuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3QgY29uZmlnRGF0YSA9IGNkdC5jb25maWdEYXRhO1xuICBjb25zdCBzdmdDb250YWluZXIgPSBjZHQuc3ZnQ29udGFpbmVyO1xuXG4gIGNvbnN0IF9tYXhYID0gY2R0Lm1heFhWYWx1ZTtcbiAgY29uc3QgX2luaXRYUG9zID0gY2R0LmF4aXNYTGFiZWxJbml0WFBvcztcbiAgY29uc3QgX2luaXRZUG9zID0gY2R0LmF4aXNYTGFiZWxJbml0WVBvcztcbiAgY29uc3QgX2NvbHVtbk51bSA9IGRhdGFTZXQubGVuZ3RoO1xuICBjb25zdCBfY29sdW1uV2lkdGggPSBjZHQuZ3JhcGhXaWR0aCAvIChfY29sdW1uTnVtIC0gMSk7XG4gIGNvbnN0IF9jb2xvciA9IGQzLnNjYWxlT3JkaW5hbChkMy5zY2hlbWVDYXRlZ29yeTEwKTtcblxuICBjb25zdCBfbGluZUNsYXNzTmFtZSA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLm11bHRpTGluZVByZWZpeCArIFN0cmluZyhsaW5lTnVtKTtcbiAgY29uc3QgX2xlZnRNYXJnaW4gPSBjb25maWdEYXRhLm1hcmdpbi5sZWZ0O1xuICBjb25zdCBfYm90dG9tTWFyZ2luID0gY29uZmlnRGF0YS5tYXJnaW4uYm90dG9tO1xuXG4gIGNvbnN0IF95U2NhbGUgPSBjZHQuZ3JhcGhZU2NhbGU7XG5cblxuICBjb25zdCBsaW5lID0gZDMubGluZSgpXG4gICAgICAuY3VydmUoZDMuY3VydmVMaW5lYXIpXG4gICAgICAueCggKGQ6IGFueSkgPT4ge1xuICAgICAgICAgIHJldHVybiBfbGVmdE1hcmdpbiArIGQuaWQgKiBfY29sdW1uV2lkdGg7XG4gICAgICB9KVxuICAgICAgLnkoIChkOiBhbnkpID0+IHtcbiAgICAgICAgICByZXR1cm4gY2R0LnN2Z0hlaWdodCAtIF9ib3R0b21NYXJnaW4gLSAoIGQudmFsdWUgKiBfeVNjYWxlKSA7XG4gICAgICB9KTtcblxuICBzdmdDb250YWluZXIuYXBwZW5kKCdwYXRoJylcbiAgICAgICAgICAuYXR0cignY2xhc3MnLCBfbGluZUNsYXNzTmFtZSlcbiAgICAgICAgICAuYXR0cignZCcsIGxpbmUoZGF0YVNldCkpO1xuICAgICAgICAgIC8vICAuYXR0cigndHJhbnNmb3JtJywgY2R0LmF4aXNUcmFuc2xhdGVQb3MpXG59XG5cblxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG4vLyAtLS1CdWlsZCBMZWdlbmQgIC0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxucHJpdmF0ZSBidWlsZExlZ2VuZChvMkNvbW1vbjogYW55LCBfbGVnZW5kRGF0YVNldDogYW55KTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGJ1aWxkTGVnZW5kLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIC8vICBtYXhWYWx1ZXMgYXJlIG1lYW5pbmdsZXNzXG4gIGNvbnN0IGNkdCA9IG8yQ29tbW9uO1xuICBjb25zdCBjb25maWdEYXRhID0gY2R0LmNvbmZpZ0RhdGE7XG4gIGNvbnN0IHN2Z0NvbnRhaW5lciA9IGNkdC5zdmdDb250YWluZXI7XG4gIC8vICBjb25zdCBjZHQgPSBuZXcgTzJDb21tb24oY29uZmlnRGF0YSwgMTAwLCAxMDAsIHN2Z1dpZHRoLCBzdmdIZWlnaHQpO1xuICBjb25zdCBsZWdlbmRSZWN0U2l6ZSA9IGNvbmZpZ0RhdGEubGVnZW5kLnJlY3RXaWR0aDtcbiAgY29uc3QgbGVnZW5kU3BhY2luZyA9IDEwO1xuICBjb25zdCB5U3BhY2luZyA9IGNvbmZpZ0RhdGEubGVnZW5kLnlTcGFjaW5nO1xuICBjb25zdCBpbml0UG9zWCA9IGNkdC5sZWdlbmRJbml0WFBvcztcbiAgY29uc3QgaW5pdFBvc1kgPSBjZHQubGVnZW5kSW5pdFlQb3M7XG4gIGNvbnN0IG9wYWNpdHkgPSBjb25maWdEYXRhLmNvbG9yLm9wYWNpdHk7XG5cbiAgY29uc3QgZ3JwTGVnZW5kID0gc3ZnQ29udGFpbmVyLmFwcGVuZCgnZycpXG4gICAgICAgICAgICAgIC5zZWxlY3RBbGwoJ2cnKVxuICAgICAgICAgICAgICAuZGF0YShfbGVnZW5kRGF0YVNldClcbiAgICAgICAgICAgICAgLmVudGVyKClcbiAgICAgICAgICAgICAgLmFwcGVuZCgnZycpXG4gICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsICdsZWdlbmQnKVxuICAgICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgKGQ6IE8yTGVnZW5kRGF0YSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBoZWlnaHQgPSBsZWdlbmRSZWN0U2l6ZSArIHlTcGFjaW5nO1xuICAgICAgICAgICAgICAgICAgY29uc3QgeCA9IGluaXRQb3NYO1xuICAgICAgICAgICAgICAgICAgY29uc3QgeSA9IGkgKiBoZWlnaHQgKyBpbml0UG9zWSA7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgeCArICcsICcgKyB5ICsgJyknO1xuICAgICAgICAgICAgICB9KTtcblxuICBncnBMZWdlbmQuYXBwZW5kKCdyZWN0JylcbiAgICAgIC5hdHRyKCd3aWR0aCcsIGxlZ2VuZFJlY3RTaXplKVxuICAgICAgLmF0dHIoJ2hlaWdodCcsIGxlZ2VuZFJlY3RTaXplKVxuICAgICAgLnN0eWxlKCdmaWxsJywgKGQ6IE8yTGVnZW5kRGF0YSkgPT4ge1xuICAgICAgICAgIHJldHVybiBkLmNvbG9yO1xuICAgICAgfSlcbiAgICAgIC5zdHlsZSgnc3Ryb2tlJywgKGQ6IE8yTGVnZW5kRGF0YSkgPT4ge1xuICAgICAgICAgIHJldHVybiBkLmNvbG9yO1xuICAgICAgfSlcbiAgICAgIC5hdHRyKCdmaWxsLW9wYWNpdHknLCBvcGFjaXR5KTtcblxuICBncnBMZWdlbmQuYXBwZW5kKCd0ZXh0JylcbiAgICAgIC5hdHRyKCd4JywgbGVnZW5kUmVjdFNpemUgKyBsZWdlbmRTcGFjaW5nKVxuICAgICAgLmF0dHIoJ3knLCBsZWdlbmRSZWN0U2l6ZSlcbiAgICAgIC50ZXh0KChkOiBPMkxlZ2VuZERhdGEpID0+IHtcbiAgICAgICAgICByZXR1cm4gZC50aXRsZTtcbiAgICAgIH0pO1xufVxuXG5cbnByaXZhdGUgZHJhd1hBeGlzTGFiZWwobzJDb21tb246IGFueSwgbGFiZWxEYXRhU2V0OiBhbnksIGNoYXJ0VHlwZTogc3RyaW5nKTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGRyYXdYQXhpc0xhYmVsLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IGNkdCA9IG8yQ29tbW9uO1xuICBjb25zdCBjb25maWdEYXRhID0gY2R0LmNvbmZpZ0RhdGE7XG4gIGNvbnN0IHN2Z0NvbnRhaW5lciA9IGNkdC5zdmdDb250YWluZXI7XG5cbiAgLy8gY29uc3QgX21heFggPSBjZHQubWF4WFZhbHVlO1xuICBjb25zdCBfaW5pdFhQb3MgPSBjZHQuYXhpc1hMYWJlbEluaXRYUG9zO1xuICBjb25zdCBfaW5pdFlQb3MgPSBjZHQuYXhpc1hMYWJlbEluaXRZUG9zO1xuXG4gIGNvbnN0IF9jb2x1bW5OdW0gPSBsYWJlbERhdGFTZXQubGVuZ3RoO1xuICBsZXQgX2NvbHVtbldpZHRoID0gY2R0LmdyYXBoV2lkdGggLyBfY29sdW1uTnVtO1xuICBpZiAoIGNoYXJ0VHlwZSA9PT0gQ2hhcnRDb25zdC5MSU5FX0NIQVJUX1RZUEVfTkFNRSkge1xuICAgICAgX2NvbHVtbldpZHRoID0gY2R0LmdyYXBoV2lkdGggLyAoX2NvbHVtbk51bSAtIDEpO1xuICB9XG5cbiAgY29uc3QgZ3JwTGFiZWwgPSBzdmdDb250YWluZXIuYXBwZW5kKCdnJylcbiAgICAgICAgICAgICAgLnNlbGVjdEFsbCgnZycpXG4gICAgICAgICAgICAgIC5kYXRhKGxhYmVsRGF0YVNldClcbiAgICAgICAgICAgICAgLmVudGVyKClcbiAgICAgICAgICAgICAgLmFwcGVuZCgnZycpXG4gICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIGNvbmZpZ0RhdGEuYXhpc1hUZXh0KVxuICAgICAgICAgICAgICAuYXR0cigndHJhbnNmb3JtJywgKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb25zdCBfeCA9IF9pbml0WFBvcyArIF9jb2x1bW5XaWR0aCAqIGk7XG4gICAgICAgICAgICAgICAgICBjb25zdCBfeSA9IF9pbml0WVBvcyA7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gJ3RyYW5zbGF0ZSgnICsgX3ggKyAnLCAnICsgX3kgKyAnKSc7XG4gICAgICAgICAgICAgIH0pO1xuXG4gIGdycExhYmVsLmFwcGVuZCgndGV4dCcpXG4gICAgICAgICAgICAgIC5hdHRyKCdjbGFzcycsIGNvbmZpZ0RhdGEuY2xhc3NOYW1lLmF4aXNYVGV4dClcbiAgICAgICAgICAgICAgLnRleHQoKGQ6IGFueSwgaTogbnVtYmVyKSA9PiB7XG4gICAgICAgICAgICAgICAgICByZXR1cm4gZDtcbiAgICAgICAgICAgICAgfSk7XG5cblxufVxuXG5cbnByaXZhdGUgZHJhd1hCYXNlTGluZShvMkNvbW1vbjogYW55KTogdm9pZCB7XG5cbiAgY29uc29sZS5sb2coJ2luIGRyYXdYQmFzZUxpbmUtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgY2R0ID0gbzJDb21tb247XG4gIGNvbnN0IHN2Z0NvbnRhaW5lciA9IGNkdC5zdmdDb250YWluZXI7XG5cbiAgc3ZnQ29udGFpbmVyLmFwcGVuZCgncmVjdCcpXG4gICAgICAuYXR0cignY2xhc3MnLCBjZHQuYXhpc1hCb3JkZXJMaW5lQ2xhc3NOYW1lKVxuICAgICAgLmF0dHIoJ3dpZHRoJywgY2R0LmF4aXNYQm9yZGVyV2lkdGgpXG4gICAgICAuYXR0cignaGVpZ2h0JywgY2R0LmF4aXNYQm9yZGVyTGluZVdpZHRoKVxuICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIGNkdC5heGlzWEJvcmRlclRyYW5zbGF0ZVBvcyk7XG5cbn1cblxuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIC0tLUJ1aWxkIEF4aXMgIC0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxucHJpdmF0ZSBidWlsZFlBeGlzKG8yQ29tbW9uOiBhbnkpOiB2b2lkIHtcblxuICBjb25zb2xlLmxvZygnaW4gYnVpbGRZQXhpcy0tLS0tLS0tLS0tLS0tLS0tLS0nKTtcblxuICBjb25zdCBjZHQgPSBvMkNvbW1vbjtcbiAgY29uc3Qgc3ZnQ29udGFpbmVyID0gY2R0LnN2Z0NvbnRhaW5lcjtcblxuICBjb25zdCBfbWF4WSA9IGNkdC5tYXhZVmFsdWU7XG4gIGNvbnN0IF9ncmFwaFlTY2FsZSA9IGNkdC5ncmFwaFlTY2FsZTtcblxuICBjb25zdCBfYXhpc1lTY2FsZSA9IGQzLnNjYWxlTGluZWFyKClcbiAgICAgICAgICAgICAgICAgIC5kb21haW4oWzAsIF9tYXhZXSlcbiAgICAgICAgICAgICAgICAgIC5yYW5nZShbX21heFkgKiBfZ3JhcGhZU2NhbGUsIDBdKTtcblxuICBzdmdDb250YWluZXIuYXBwZW5kKCdnJylcbiAgICAgIC5hdHRyKCdjbGFzcycsIGNkdC5heGlzQ2xhc3NOYW1lKVxuICAgICAgLmF0dHIoJ3RyYW5zZm9ybScsIGNkdC5heGlzVHJhbnNsYXRlUG9zKVxuICAgICAgLmNhbGwoXG4gICAgICAgICAgICBkMy5heGlzTGVmdChfYXhpc1lTY2FsZSlcbiAgICAgICAgICAgICk7XG5cbn1cblxuXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIC0tLSBkcmF3VGl0bGUtLS0tLS0tLS0tLS0tLS0tLVxucHJpdmF0ZSBkcmF3VGl0bGUobzJDb21tb246IGFueSk6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBkcmF3VGl0bGUtLS0tLS0tLS0tLS0tLS0tLS0tJyk7XG5cbiAgY29uc3QgY2R0ID0gbzJDb21tb247XG4gIGNvbnN0IGNvbmZpZ0RhdGEgPSBjZHQuY29uZmlnRGF0YTtcbiAgY29uc3Qgc3ZnQ29udGFpbmVyID0gY2R0LnN2Z0NvbnRhaW5lcjtcblxuICBjb25zdCBfdGl0bGUgPSBjb25maWdEYXRhLnRpdGxlLm5hbWU7XG4gIGNvbnN0IF94UG9zID0gY2R0LnRpdGxlSW5pdFhQb3M7XG4gIGNvbnN0IF95UG9zID0gY2R0LnRpdGxlSW5pdFlQb3M7XG4gIGNvbnN0IF90aXRsZUNsYXNzTmFtZSA9IGNvbmZpZ0RhdGEudGl0bGUuY2xhc3NOYW1lO1xuXG4gIHN2Z0NvbnRhaW5lci5hcHBlbmQoJ3RleHQnKVxuICAgICAgLmF0dHIoJ2NsYXNzJywgX3RpdGxlQ2xhc3NOYW1lKVxuICAgICAgLmF0dHIoJ3gnLCBfeFBvcylcbiAgICAgIC5hdHRyKCd5JywgX3lQb3MpXG4gICAgICAudGV4dChfdGl0bGUpO1xufVxuXG5cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxuLy8gLS0tZHJhd0dyaWQgIC0tLS0tLS0tLS0tLS0tLS0tLS1cbi8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxucHJpdmF0ZSBkcmF3WUdyaWQobzJDb21tb246IGFueSk6IHZvaWQge1xuXG4gIGNvbnNvbGUubG9nKCdpbiBidWlsZFlHcmlkLS0tLS0tLS0tLS0tLS0tLS0tLScpO1xuXG4gIGNvbnN0IGNkdCA9IG8yQ29tbW9uO1xuICBjb25zdCBjb25maWdEYXRhID0gY2R0LmNvbmZpZ0RhdGE7XG4gIGNvbnN0IHN2Z0NvbnRhaW5lciA9IGNkdC5zdmdDb250YWluZXI7XG5cbiAgY29uc3QgX3N0ZXBZID0gIGNkdC5ncmlkWVN0ZXA7XG4gIGNvbnN0IF9tYXhZID0gY2R0Lm1heFlWYWx1ZTtcbiAgY29uc3QgX2dyYXBoWVNjYWxlID0gY2R0LmdyYXBoWVNjYWxlO1xuICBjb25zdCBfZ3JpZENsYXNzTmFtZSA9IGNvbmZpZ0RhdGEuY2xhc3NOYW1lLmdyaWQ7XG4gIGNvbnN0IF9yYW5nZVkgPSBkMy5yYW5nZShfc3RlcFkgKiBfZ3JhcGhZU2NhbGUsXG4gICAgICAgICAgICAgICAgICBfbWF4WSAqIF9ncmFwaFlTY2FsZSxcbiAgICAgICAgICAgICAgICAgIF9zdGVwWSAqIF9ncmFwaFlTY2FsZSk7XG5cbiAgc3ZnQ29udGFpbmVyLmFwcGVuZCgnZycpXG4gICAgICAuc2VsZWN0QWxsKCdsaW5lLnknKVxuICAgICAgLmRhdGEoX3JhbmdlWSlcbiAgICAgIC5lbnRlcigpXG4gICAgICAuYXBwZW5kKCdsaW5lJylcbiAgICAgIC5hdHRyKCdjbGFzcycsIF9ncmlkQ2xhc3NOYW1lKVxuICAgICAgLmF0dHIoJ3gxJywgY29uZmlnRGF0YS5tYXJnaW4ubGVmdClcbiAgICAgIC5hdHRyKCd5MScsICggZDogYW55LCBpOiBudW1iZXIgKSA9PiAge1xuICAgICAgICAgIGNvbnN0IF95MSA9IGNkdC5zdmdIZWlnaHQgLSBjb25maWdEYXRhLm1hcmdpbi5ib3R0b20gLSBkO1xuICAgICAgICAgIHJldHVybiBfeTE7XG4gICAgICB9KVxuICAgICAgLmF0dHIoJ3gyJywgY29uZmlnRGF0YS5tYXJnaW4ubGVmdCArIGNkdC5heGlzWEJvcmRlcldpZHRoKVxuICAgICAgLmF0dHIoJ3kyJywgKCBkOiBhbnksIGk6IG51bWJlciApID0+ICB7XG4gICAgICAgICAgY29uc3QgX3kxID0gY2R0LnN2Z0hlaWdodCAtIGNvbmZpZ0RhdGEubWFyZ2luLmJvdHRvbSAtIGQ7XG4gICAgICAgICAgcmV0dXJuIF95MTtcbiAgICAgIH0pO1xuICB9XG59XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgTmc2VWRtQ2hhcnRDb21wb25lbnQgfSBmcm9tICcuL25nNi11ZG0tY2hhcnQuY29tcG9uZW50JztcblxuQE5nTW9kdWxlKHtcbiAgaW1wb3J0czogW1xuICBdLFxuICBkZWNsYXJhdGlvbnM6IFtOZzZVZG1DaGFydENvbXBvbmVudF0sXG4gIGV4cG9ydHM6IFtOZzZVZG1DaGFydENvbXBvbmVudF1cbn0pXG5leHBvcnQgY2xhc3MgTmc2VWRtQ2hhcnRNb2R1bGUgeyB9XG4iXSwibmFtZXMiOlsiZDMuc2NhbGVPcmRpbmFsIiwiZDMuc2NoZW1lQ2F0ZWdvcnkyMCIsImQzLnNjaGVtZUNhdGVnb3J5MTAiLCJkMy5zZWxlY3QiLCJDaGFydENvbnN0LkxJTkVfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5CQVJfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5QSUVfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5TQ0FUVEVSX1BMT1RfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5ISVNUT0dSQU1fQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5TVEFDS19CQVJfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5HRU9fTUFQX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuR0VPX09SVEhPR1JBUEhJQ19DSEFSVF9UWVBFX05BTUUiLCJDaGFydENvbnN0LlRSRUVfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5QQUNLX0xBWU9VVF9DSEFSVF9UWVBFX05BTUUiLCJDaGFydENvbnN0LkNIT1JPUExFVEhfQ0hBUlRfVFlQRV9OQU1FIiwiQ2hhcnRDb25zdC5GT1JDRV9DSEFSVF9UWVBFX05BTUUiLCJDaGFydENvbnN0LlRSRUVfTUFQX0NIQVJUX1RZUEVfTkFNRSIsIkNoYXJ0Q29uc3QuU0FOS0VZX0NIQVJUX1RZUEVfTkFNRSIsImQzLmZvcm1hdCIsImQzLnNjYWxlTGluZWFyIiwiZDMuaGlzdG9ncmFtIiwiZDMubWF4IiwiZDMuZm9yY2VTaW11bGF0aW9uIiwiZDMuZm9yY2VMaW5rIiwiZDMuZm9yY2VNYW55Qm9keSIsImQzLmZvcmNlQ2VudGVyIiwiZDMuZHJhZyIsImQzLmV2ZW50IiwiZDMuaW50ZXJwb2xhdGVIc2wiLCJkMy5nZW9QYXRoIiwiZDMuZ2VvTWVyY2F0b3IiLCJkMy5qc29uIiwiZDMucGFjayIsImQzLmhpZXJhcmNoeSIsImQzLnRyZWUiLCJkMy5nZW9PcnRob2dyYXBoaWMiLCJkMy50aW1lciIsImQzLnN0YWNrIiwiZDMucmFuZ2UiLCJkMy5heGlzQm90dG9tIiwiZDMuc3VtIiwiZDMucGllIiwiZDMuYXJjIiwiZDMubGluZSIsImQzLmN1cnZlTGluZWFyIiwiZDMuYXhpc0xlZnQiLCJDb21wb25lbnQiLCJFbGVtZW50UmVmIiwiSW5wdXQiLCJOZ01vZHVsZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBLHlCQUFhLG9CQUFvQixHQUFJLE1BQU0sQ0FBQztBQUM1Qyx5QkFBYSxtQkFBbUIsR0FBRyxLQUFLLENBQUM7QUFDekMseUJBQWEsbUJBQW1CLEdBQUcsS0FBSyxDQUFDO0FBQ3pDLHlCQUFhLDRCQUE0QixHQUFHLGFBQWEsQ0FBQztBQUMxRCx5QkFBYSx5QkFBeUIsR0FBRyxXQUFXLENBQUM7QUFDckQseUJBQWEseUJBQXlCLEdBQUcsVUFBVSxDQUFDO0FBQ3BELHlCQUFhLHVCQUF1QixHQUFHLFFBQVEsQ0FBQztBQUNoRCx5QkFBYSxnQ0FBZ0MsR0FBRyxpQkFBaUIsQ0FBQztBQUNsRSx5QkFBYSx3QkFBd0IsR0FBRyxTQUFTLENBQUM7QUFDbEQseUJBQWEsMkJBQTJCLEdBQUcsWUFBWSxDQUFDO0FBQ3hELHlCQUFhLDBCQUEwQixHQUFHLFlBQVksQ0FBQztBQUN2RCx5QkFBYSxvQkFBb0IsR0FBRyxNQUFNLENBQUM7QUFDM0MseUJBQWEsc0JBQXNCLEdBQUcsUUFBUSxDQUFDO0FBQy9DLHlCQUFhLHFCQUFxQixHQUFHLE9BQU87Ozs7OztBQ2I1QyxJQUlBLElBQUE7UUFFSSxrQkFDVyxjQUNBLFlBQ0EsVUFDQSxVQUNBLFVBQ0E7WUFMQSxpQkFBWSxHQUFaLFlBQVk7WUFDWixlQUFVLEdBQVYsVUFBVTtZQUNWLGFBQVEsR0FBUixRQUFRO1lBQ1IsYUFBUSxHQUFSLFFBQVE7WUFDUixhQUFRLEdBQVIsUUFBUTtZQUNSLGNBQVMsR0FBVCxTQUFTO1NBQ2Y7OEJBS0UsbUNBQWE7Ozs7Z0JBQ3BCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDOzs7Ozs4QkFHL0IsbUNBQWE7Ozs7Z0JBQ3BCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDOzs7Ozs4QkFHL0IsOENBQXdCOzs7O2dCQUMvQixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQzs7Ozs7OEJBUXRDLCtCQUFTOzs7O2dCQUNoQixxQkFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDMUIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRTtvQkFDaEMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztpQkFDdEM7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7Ozs7OzhCQUdOLCtCQUFTOzs7O2dCQUNoQixxQkFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDMUIsSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRTtvQkFDaEMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztpQkFDdEM7Z0JBQ0QsT0FBTyxLQUFLLENBQUM7Ozs7OzhCQU1OLG1DQUFhOzs7O2dCQUNwQixxQkFBSSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUN4QyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEtBQUssT0FBTyxFQUFFO29CQUMvRSxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTswQkFDckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDO2lCQUNuRDtnQkFDRCxPQUFPLEtBQUssQ0FBQzs7Ozs7OEJBR04sbUNBQWE7Ozs7Z0JBQ3BCLHFCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHO3NCQUMxQixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7Z0JBQzNDLE9BQU8sS0FBSyxDQUFDOzs7Ozs4QkFHTixpQ0FBVzs7OztnQkFDbEIsT0FBTyxJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7Ozs7OzhCQUdsQyxpQ0FBVzs7OztnQkFDbEIsT0FBTyxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7Ozs7OzhCQUdqQyxnQ0FBVTs7OztnQkFDakIscUJBQUksT0FBTyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUk7c0JBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztnQkFDNUMsSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7b0JBQ2hDLE9BQU8sSUFBSSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7aUJBQ2hEO2dCQUVELE9BQU8sSUFBSSxDQUFDLFFBQVEsR0FBRyxPQUFPLENBQUM7Ozs7OzhCQUd4QixpQ0FBVzs7OztnQkFDbEIscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxTQUFTO3NCQUNYLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU07c0JBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUc7c0JBQzFCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQkFDNUMsT0FBTyxFQUFFLENBQUM7Ozs7OzhCQUdILG9DQUFjOzs7O2dCQUNyQixxQkFBTSxRQUFRLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQzVDLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO3NCQUN4QixJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztnQkFDbEMscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUc7c0JBQzNCLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLE1BQU07c0JBQzVCLElBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFDO2dCQUMvQixRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNsQixRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNsQixPQUFPLFFBQVEsQ0FBQzs7Ozs7OEJBR1QsNkNBQXVCOzs7O2dCQUM5QixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtzQkFDNUIsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUM7Z0JBQzlCLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHO3NCQUMzQixJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNO3NCQUM1QixJQUFJLENBQUMsV0FBVyxHQUFHLENBQUMsQ0FBQztnQkFDL0IsT0FBTyxZQUFZLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDOzs7Ozs4QkFHcEQsMkNBQXFCOzs7O2dCQUM1QixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQztnQkFDOUIscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUM7Z0JBQzlCLE9BQU8sWUFBWSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLEdBQUcsQ0FBQzs7Ozs7OEJBTXBELHdDQUFrQjs7OztnQkFDekIscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUk7c0JBQzVCLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUM7Z0JBQ2pELE9BQU8sRUFBRSxDQUFDOzs7Ozs4QkFHSCx3Q0FBa0I7Ozs7Z0JBQ3pCLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsU0FBUztzQkFDZixJQUFJLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDO2dCQUNuRCxPQUFPLEVBQUUsQ0FBQzs7Ozs7OEJBR0gsc0NBQWdCOzs7O2dCQUN2QixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUN2QyxxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztzQkFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO2dCQUN2QyxPQUFPLFlBQVksR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsR0FBRyxHQUFHLENBQUM7Ozs7OzhCQUlwRCwwQ0FBb0I7Ozs7Z0JBQzNCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDOzs7Ozs4QkFHckMsdUNBQWlCOzs7O2dCQUN4QixxQkFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztzQkFDeEIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTTtzQkFDN0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO2dCQUMvQyxPQUFPLElBQUksQ0FBQyxTQUFTLEdBQUcsT0FBTyxDQUFDOzs7Ozs4QkFHekIsc0NBQWdCOzs7O2dCQUN2QixxQkFBSSxPQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSTtzQkFDMUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO2dCQUM1QyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtvQkFDaEMsT0FBTyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztpQkFDaEQ7Z0JBQ0QsT0FBTyxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU8sQ0FBQzs7Ozs7OEJBR3hCLGlDQUFXOzs7O2dCQUNsQixPQUFPLE1BQU0sQ0FBQzs7Ozs7OEJBR1AsaUNBQVc7Ozs7Z0JBQ2xCLE9BQU8sUUFBUSxDQUFDOzs7Ozs4QkFFVCw2Q0FBdUI7Ozs7Z0JBQzlCLHFCQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDckUsT0FBTyxZQUFZLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxHQUFHLElBQUksR0FBRyxLQUFLLEdBQUcsR0FBRyxDQUFDOzs7Ozs4QkFRaEUsd0NBQWtCOzs7O2dCQUN6QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUM7Ozs7OzhCQUd4QyxzQ0FBZ0I7Ozs7Z0JBQ3ZCLE9BQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQzs7Ozs7OEJBR3RDLGtEQUE0Qjs7OztnQkFDbkMscUJBQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUk7c0JBQ3hCLElBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO2dCQUNsQyxxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztzQkFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtzQkFDNUIsSUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDO3NCQUNwQixDQUFDLENBQUM7Z0JBQ1osT0FBTyxZQUFZLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxDQUFDOzs7Ozs4QkFNcEQsb0NBQWM7Ozs7Z0JBQ3JCLHFCQUFJLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO3NCQUN0QixJQUFJLENBQUMsVUFBVTtzQkFDZixJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUU7Z0JBQy9DLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsUUFBUSxLQUFLLE9BQU8sRUFBRTtvQkFDN0MsRUFBRSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUk7MEJBQ3pCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBRTtpQkFDM0M7Z0JBQ0QsT0FBTyxFQUFFLENBQUM7Ozs7OzhCQUdILG9DQUFjOzs7O2dCQUNyQixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztzQkFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtzQkFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDO2dCQUMxQyxPQUFPLEVBQUUsQ0FBQzs7Ozs7OEJBTUgsK0JBQVM7Ozs7Z0JBQ2hCLHFCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUNuRCxxQkFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO2dCQUNwQixxQkFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEdBQUcsUUFBUSxDQUFDO2dCQUNyRCxPQUFPLEtBQUssQ0FBQzs7Ozs7OEJBR04sK0JBQVM7Ozs7Z0JBQ2hCLHFCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUNuRCxxQkFBTSxRQUFRLEdBQUcsRUFBRSxDQUFDO2dCQUNwQixxQkFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEdBQUcsUUFBUSxDQUFDLEdBQUcsUUFBUSxDQUFDO2dCQUNyRCxPQUFPLEtBQUssQ0FBQzs7Ozs7OEJBT04sbUNBQWE7Ozs7Z0JBQ3BCLHFCQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJO3NCQUM1QixDQUFDLElBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsVUFBVSxJQUFJLENBQUM7c0JBQ3pELElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQztnQkFDM0MsT0FBTyxFQUFFLENBQUM7Ozs7OzhCQUdILG1DQUFhOzs7O2dCQUNwQixxQkFBTSxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRztzQkFDM0IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTTtzQkFDNUIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDO2dCQUM3QyxPQUFPLEVBQUUsQ0FBQzs7Ozs7OEJBTUgsc0NBQWdCOzs7O2dCQUN2QixxQkFBSSxNQUFXLENBQUM7Z0JBQ2hCLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsSUFBSyxFQUFFO29CQUM3QixJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLGtCQUFrQixLQUFLLElBQUksRUFBRTt3QkFDbkQsTUFBTSxHQUFHQSxlQUFlLENBQUNDLG1CQUFtQixDQUFDLENBQUM7cUJBQ2pEO3lCQUFNO3dCQUNILE1BQU0sR0FBR0QsZUFBZSxDQUFDRSxtQkFBbUIsQ0FBQyxDQUFDO3FCQUNqRDtpQkFDSjtnQkFDRCxPQUFPLE1BQU0sQ0FBQzs7Ozs7dUJBNVFsQjtRQThRQyxDQUFBO0FBMVFELElBc1JBLElBQUE7UUFDQSxzQkFDVSxPQUNDO1lBREQsVUFBSyxHQUFMLEtBQUs7WUFDSixVQUFLLEdBQUwsS0FBSztTQUFjOzJCQTdSOUI7UUErUkMsQ0FBQTtBQUxELElBT0EsSUFBQTtRQUNBLDJCQUNVLEdBQ0EsR0FDQTtZQUZBLE1BQUMsR0FBRCxDQUFDO1lBQ0QsTUFBQyxHQUFELENBQUM7WUFDRCxNQUFDLEdBQUQsQ0FBQztTQUFjO2dDQXJTekI7UUF1U0MsQ0FBQTtBQU5ELElBZ0JBLElBQUE7UUFDQSx1QkFDVSxJQUNDO1lBREQsT0FBRSxHQUFGLEVBQUU7WUFDRCxVQUFLLEdBQUwsS0FBSztTQUNSOzRCQXJUUjtRQXVUQyxDQUFBO0FBTkQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDalRBO1FBcUJFLDhCQUFhLFVBQXNCO1lBQ2pDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsQ0FBQztZQUNqRCxxQkFBTSxFQUFFLEdBQW1CLFVBQVUsQ0FBQyxhQUFhLENBQUM7WUFDcEQsSUFBSSxDQUFDLElBQUksR0FBR0MsU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQzdCOzs7O1FBRUQsdUNBQVE7OztZQUFSO2FBQ0M7Ozs7O1FBRUQsMENBQVc7Ozs7WUFBWCxVQUFZLE9BQStDO2dCQUN6RCxxQkFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7Z0JBQzdDLHFCQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFDL0MscUJBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7Z0JBQy9CLHFCQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDO2dCQUNuQyxxQkFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDakMscUJBQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztxQkFDakMsSUFBSSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUM7cUJBQ3ZCLElBQUksQ0FBQyxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBRXJDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7Z0JBQ3ZCLFFBQVEsU0FBUztvQkFDZixLQUFLQyxvQkFBK0I7d0JBQ2xDLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO3dCQUN2RSxNQUFNO29CQUNSLEtBQUtDLG1CQUE4Qjt3QkFDakMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7d0JBQ3ZFLE1BQU07b0JBQ1IsS0FBS0MsbUJBQThCO3dCQUNqQyxJQUFJLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQzt3QkFDdkUsTUFBTTtvQkFDUixLQUFLQyw0QkFBdUM7d0JBQzFDLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7d0JBQy9FLE1BQU07b0JBQ1IsS0FBS0MseUJBQW9DO3dCQUN2QyxJQUFJLENBQUMsY0FBYyxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQzt3QkFDN0UsTUFBTTtvQkFDUixLQUFLQyx5QkFBb0M7d0JBQ3ZDLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO3dCQUM1RSxNQUFNO29CQUNSLEtBQUtDLHVCQUFrQzt3QkFDckMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7d0JBQzFFLE1BQU07b0JBQ1IsS0FBS0MsZ0NBQTJDO3dCQUM5QyxJQUFJLENBQUMsb0JBQW9CLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO3dCQUNuRixNQUFNO29CQUNSLEtBQUtDLG9CQUErQjt3QkFDbEMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7d0JBQ3hFLE1BQU07b0JBQ1IsS0FBS0MsMkJBQXNDO3dCQUN6QyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxTQUFTLENBQUUsQ0FBQzt3QkFDOUUsTUFBTTtvQkFDUixLQUFLQywwQkFBcUM7d0JBQ3hDLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBRSxDQUFDO3dCQUM5RSxNQUFNO29CQUNSLEtBQUtDLHFCQUFnQzt3QkFDbkMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFFLENBQUM7d0JBQ3pFLE1BQU07b0JBQ1IsS0FBS0Msd0JBQW1DOzt3QkFFdEMsTUFBTTtvQkFDUixLQUFLQyxzQkFBaUM7O3dCQUVwQyxNQUFNO29CQUNSO3dCQUNFLE1BQU07aUJBQ1Q7YUFDRjs7Ozs7Ozs7O1FBSU8sNkNBQWM7Ozs7Ozs7O3NCQUFDLFlBQWlCLEVBQUUsVUFBZSxFQUFFLFdBQWdCLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtnQkFFOUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDO2dCQUVwRCxxQkFBTSxPQUFPLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQztnQkFDakMscUJBQU0sVUFBVSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztnQkFFL0MscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztnQkFDbEIscUJBQU0sS0FBSyxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ25DLHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUN0RixxQkFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztnQkFDbkMscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7Z0JBR3JDLHFCQUFNLFdBQVcsR0FBRyxHQUFHLENBQUMsYUFBYSxDQUFDO2dCQUN0QyxxQkFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLGFBQWEsQ0FBQztnQkFFdEMscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2dCQUMvQyxxQkFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7Z0JBQy9DLHFCQUFNLGtCQUFrQixHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDO2dCQUN6RCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDO2dCQUNoRCxxQkFBTSxXQUFXLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUM7Z0JBQzNDLHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztnQkFDekMscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDO2dCQUdyRCxxQkFBTSxRQUFRLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQzVDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLE9BQU8sRUFBRTtvQkFDckIsSUFBSSxPQUFPLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUMzQixxQkFBTSxJQUFJLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQzt3QkFDaEMsUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztxQkFDdkI7aUJBQ0o7Z0JBRUQscUJBQU0sV0FBVyxHQUFHQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBRXRDLHFCQUFNLGtCQUFrQixHQUFHLFlBQVk7cUJBQ3RCLE1BQU0sQ0FBQyxHQUFHLENBQUM7cUJBQ1gsSUFBSSxDQUFDLFdBQVcsRUFBRSxZQUFZLEdBQUcsV0FBVyxHQUFHLEdBQUcsR0FBRyxXQUFXLEdBQUcsR0FBRyxDQUFDLENBQUM7Z0JBRXpGLHFCQUFNLE9BQU8sR0FBR0MsY0FBYyxFQUFFO3FCQUMzQixVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUUsV0FBVyxDQUFDLENBQUMsQ0FBQztnQkFFbEMscUJBQU0sSUFBSSxHQUFHQyxZQUFZLEVBQUU7cUJBQ3RCLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztxQkFDZCxVQUFVLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUNyQyxRQUFRLENBQUMsQ0FBQztnQkFHZixxQkFBTSxPQUFPLEdBQUdELGNBQWMsRUFBRTtxQkFDM0IsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFRSxNQUFNLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBTTt3QkFDNUIsT0FBTyxDQUFDLENBQUMsTUFBTSxDQUFDO3FCQUNuQixDQUFDLENBQUMsQ0FBQztxQkFDSCxLQUFLLENBQUMsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFOUIscUJBQU0sR0FBRyxHQUFHLGtCQUFrQjtxQkFDekIsU0FBUyxDQUFDLE1BQU0sQ0FBQztxQkFDakIsSUFBSSxDQUFDLElBQUksQ0FBQztxQkFDVixLQUFLLEVBQUU7cUJBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDWCxJQUFJLENBQUMsT0FBTyxFQUFFLFVBQVUsQ0FBQztxQkFDekIsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFDLENBQU07b0JBQ3RCLE9BQU8sWUFBWSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsR0FBRyxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDO2lCQUN2RSxDQUFDLENBQUM7Z0JBRVAsSUFBSSxVQUFVLEVBQUU7b0JBQ1osR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7eUJBQ2IsSUFBSSxDQUFDLEdBQUcsRUFBRyxDQUFDLENBQUM7eUJBQ2IsSUFBSSxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDO3lCQUM1RCxJQUFJLENBQUMsUUFBUSxFQUFFLENBQUMsQ0FBQzt5QkFDakIsVUFBVSxFQUFFO3lCQUNaLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQzt5QkFDNUIsSUFBSSxDQUFDLFFBQVEsRUFBRSxVQUFDLENBQU07d0JBQ25CLE9BQU8sWUFBWSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7cUJBQzNDLENBQUMsQ0FBQztpQkFDVjtxQkFBTTtvQkFDSCxHQUFHLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQzt5QkFDYixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzt5QkFDWixJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUM7eUJBQzVELElBQUksQ0FBQyxRQUFRLEVBQUUsVUFBQyxDQUFNO3dCQUNuQixPQUFPLFlBQVksR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDO3FCQUMzQyxDQUFDLENBQUM7aUJBQ1Y7Z0JBRUQsR0FBRyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7cUJBQ2IsSUFBSSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7cUJBQ25CLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO3FCQUNaLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxDQUFDO3FCQUMxRCxJQUFJLENBQUMsYUFBYSxFQUFFLFFBQVEsQ0FBQztxQkFDN0IsSUFBSSxDQUFDLFVBQUMsQ0FBTTtvQkFDVCxPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUM7aUJBQ2hDLENBQUMsQ0FBQzs7Z0JBR1AsSUFBSSxhQUFhLEVBQUU7b0JBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDdkI7OztnQkFHRCxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVyQixJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVwQixJQUFJLGFBQWEsRUFBRTtvQkFDaEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDdkI7Ozs7Ozs7Ozs7UUFLSyx5Q0FBVTs7Ozs7Ozs7c0JBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO2dCQUUxRyxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixDQUFDLENBQUM7Z0JBRTdDLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBQ2xCLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBQ2xCLHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUV0RixxQkFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLGdCQUFnQixDQUFDO2dCQUlwQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFDckMscUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7Z0JBRW5DLHFCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDM0MscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2dCQUd6QyxxQkFBTSxVQUFVLEdBQUdDLGtCQUFrQixFQUFFO3FCQUNsQyxLQUFLLENBQUMsTUFBTSxFQUFFQyxZQUFZLEVBQUUsQ0FBQyxFQUFFLENBQUMsVUFBQyxDQUFNO29CQUNwQyxPQUFPLENBQUMsQ0FBQyxFQUFFLENBQUM7aUJBQ2YsQ0FBQyxDQUFDO3FCQUNGLEtBQUssQ0FBQyxRQUFRLEVBQUVDLGdCQUFnQixFQUFFLENBQUM7cUJBQ25DLEtBQUssQ0FBQyxRQUFRLEVBQUVDLGNBQWMsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxFQUFFLFlBQVksR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUd4RSxxQkFBTSxlQUFlLEdBQUcsWUFBWTtxQkFDakMsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDWCxJQUFJLENBQUMsV0FBVyxFQUNmLFlBQVksR0FBRyxXQUFXLEdBQUcsR0FBRyxHQUFHLFVBQVUsR0FBRyxHQUFHLENBQUMsQ0FBQztnQkFFekQscUJBQU0sSUFBSSxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUNuQyxJQUFJLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQztxQkFDNUIsU0FBUyxDQUFDLE1BQU0sQ0FBQztxQkFDakIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7cUJBQ3ZCLEtBQUssRUFBRTtxQkFDUCxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNkLElBQUksQ0FBQyxjQUFjLEVBQUUsVUFBQyxDQUFNO29CQUN6QixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUM3QixDQUFDLENBQUM7Z0JBRVAscUJBQU0sSUFBSSxHQUFHLGVBQWUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUNuQyxJQUFJLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQztxQkFDdEIsU0FBUyxDQUFDLFFBQVEsQ0FBQztxQkFDbkIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7cUJBQ3ZCLEtBQUssRUFBRTtxQkFDUCxNQUFNLENBQUMsUUFBUSxDQUFDO3FCQUNoQixJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztxQkFDWixJQUFJLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTTtvQkFDakIsT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO2lCQUMxQixDQUFDO3FCQUNELElBQUksQ0FBQ0MsT0FBTyxFQUFFO3FCQUNWLEVBQUUsQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDO3FCQUN4QixFQUFFLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQztxQkFDbkIsRUFBRSxDQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUUzQixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztxQkFDZixJQUFJLENBQUMsVUFBQyxDQUFNO29CQUNULE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQztpQkFDZixDQUFDLENBQUM7Z0JBRVgsVUFBVTtxQkFDTCxLQUFLLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztxQkFDeEIsRUFBRSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsQ0FBQztnQkFFeEIscUJBQU0sVUFBVSxHQUFRLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ2pELFVBQVUsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFDOzs7O2dCQUVwQztvQkFDSSxJQUFJO3lCQUNDLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFNO3dCQUNoQixPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO3FCQUFFLENBQUM7eUJBQ3ZCLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFNO3dCQUNqQixPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO3FCQUFFLENBQUM7eUJBQ3RCLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFNO3dCQUNoQixPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO3FCQUFFLENBQUM7eUJBQ3ZCLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFNO3dCQUNoQixPQUFPLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO3FCQUFFLENBQUMsQ0FBQztvQkFFN0IsSUFBSTt5QkFDQyxJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUMsQ0FBTTt3QkFDaEIsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUFFLENBQUM7eUJBQ2hCLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFNO3dCQUNoQixPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQUUsQ0FBQyxDQUFDO2lCQUN6Qjs7Ozs7Z0JBRUQscUJBQXFCLENBQU07b0JBQ3ZCLElBQUksQ0FBQ0MsUUFBUSxDQUFDLE1BQU0sRUFBRTt3QkFDbEIsVUFBVSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztxQkFDekM7b0JBQ0QsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDO29CQUNYLENBQUMsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDZDs7Ozs7Z0JBRUQsaUJBQWlCLENBQU07b0JBQ25CLENBQUMsQ0FBQyxFQUFFLEdBQUdBLFFBQVEsQ0FBQyxDQUFDLENBQUM7b0JBQ2xCLENBQUMsQ0FBQyxFQUFFLEdBQUdBLFFBQVEsQ0FBQyxDQUFDLENBQUM7aUJBQ3JCOzs7OztnQkFFRCxtQkFBbUIsQ0FBTTtvQkFDckIsSUFBSSxDQUFDQSxRQUFRLENBQUMsTUFBTSxFQUFFO3dCQUNsQixVQUFVLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUM3QjtvQkFDRCxDQUFDLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQztvQkFDWixDQUFDLENBQUMsRUFBRSxHQUFHLElBQUksQ0FBQztpQkFDZjs7O2dCQUlELHFCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDeEQsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLE1BQU0sRUFBRTtvQkFDaEMsSUFBSSxXQUFXLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDdEMscUJBQU0sR0FBRyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO3dCQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ2xGO2lCQUNKO2dCQUNELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDOzs7Ozs7Ozs7O1FBT2hDLDhDQUFlOzs7Ozs7OztzQkFBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7Z0JBRS9HLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0NBQXdDLENBQUMsQ0FBQztnQkFFdEQscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztnQkFDbEIscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztnQkFDbEIscUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQ3RGLHFCQUFNLGVBQWUsR0FBRyxHQUFHLENBQUMsY0FBYyxDQUFDO2dCQUszQyxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQy9DLHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFDakQscUJBQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDO2dCQUVoRCxxQkFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7Z0JBQ3JDLHFCQUFNLFdBQVcsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQztnQkFDL0MscUJBQU0sWUFBWSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO2dCQUNqRCxxQkFBTSxRQUFRLEdBQUcsT0FBTyxHQUFHLFlBQVksQ0FBQztnQkFDeEMscUJBQU0sY0FBYyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO2dCQUN0RCxxQkFBTSxXQUFXLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUM7Z0JBQy9DLHFCQUFNLFNBQVMsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQztnQkFDM0MscUJBQU0sU0FBUyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsV0FBVyxDQUFDO2dCQUM5QyxxQkFBTSxPQUFPLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUM7Z0JBQ3ZDLHFCQUFNLG1CQUFtQixHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUM7Z0JBQy9ELHFCQUFNLGVBQWUsR0FBRyxJQUFJLEdBQUcsbUJBQW1CLENBQUM7Z0JBRW5ELHFCQUFNLEtBQUssR0FBR0MsaUJBQWlCLENBQUMsV0FBVyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUV4RCxxQkFBSSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7Z0JBQ3JDLHFCQUFJLElBQUksR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQkFDckMsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtvQkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDcEMsSUFBSSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7NEJBQ2xDLElBQUksR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzt5QkFDcEM7d0JBQ0QsSUFBSSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7NEJBQ2xDLElBQUksR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzt5QkFDcEM7cUJBQ0o7aUJBQ0o7Z0JBQ0QscUJBQU0sTUFBTSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7Z0JBQzNCLHFCQUFNLEtBQUssR0FBRyxNQUFNLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDO2dCQUV2QyxxQkFBTSxjQUFjLEdBQUcsVUFBQyxFQUFVO29CQUM5QixLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO3dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUNwQyxJQUFJLEVBQUUsS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTtnQ0FDL0IscUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dDQUN6QyxxQkFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxJQUFJLElBQUksS0FBSyxDQUFDLENBQUM7Z0NBQ2pELE9BQU8sS0FBSyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsQ0FBQzs2QkFDOUI7eUJBQ0o7cUJBQ0o7aUJBQ0osQ0FBQztnQkFFRixxQkFBTSxJQUFJLEdBQUdDLFVBQVUsRUFBRTtxQkFDWixVQUFVLENBQ1BDLGNBQWMsRUFBRTtxQkFDZixNQUFNLENBQUMsT0FBTyxDQUFDO3FCQUNmLEtBQUssQ0FBQyxNQUFNLENBQUM7cUJBQ2IsU0FBUyxDQUFDLGVBQWUsQ0FBQyxDQUM5QixDQUFDO2dCQUVkQyxPQUFPLENBQUMsY0FBYyxFQUFFLFVBQUMsS0FBSyxFQUFFLElBQUk7b0JBQ2hDLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO3lCQUNyQixJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO3lCQUNwQixLQUFLLEVBQUU7eUJBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQzt5QkFDZCxJQUFJLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQzt5QkFDZixLQUFLLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7d0JBQzdCLHFCQUFNLEdBQUcsR0FBRyxjQUFjLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUM7d0JBQ2xELE9BQU8sR0FBRyxDQUFDO3FCQUNkLENBQUMsQ0FBQztpQkFDZCxDQUFDLENBQUM7OztnQkFJSCxJQUFJLGFBQWEsRUFBRTtvQkFDZixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUN2Qjs7O2dCQUlELElBQUksY0FBYyxFQUFFO29CQUNoQixxQkFBTSxjQUFjLEdBQXdCLElBQUksS0FBSyxFQUFFLENBQUM7b0JBQ3hELEtBQUsscUJBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxFQUFFLENBQUMsRUFBRSxFQUFFO3dCQUNoQyxxQkFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLElBQUksSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsR0FBSSxLQUFLLENBQUM7d0JBQ25ELGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsTUFBTSxFQUFFLEtBQUssQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNsRTtvQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxjQUFjLENBQUMsQ0FBQztpQkFDekM7Ozs7Ozs7Ozs7UUFJSyw4Q0FBZTs7Ozs7Ozs7c0JBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO2dCQUUvRyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxDQUFDLENBQUM7Z0JBRS9DLHFCQUFNLGdCQUFnQixHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDO2dCQUN6RCxxQkFBTSxxQkFBcUIsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FBQztnQkFDbkUscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2dCQUMvQyxxQkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztnQkFDekQscUJBQU0sS0FBSyxHQUFHL0IsZUFBZSxDQUFDRSxtQkFBbUIsQ0FBQyxDQUFDOztnQkFFbkQscUJBQU0sTUFBTSxHQUFHOEIsT0FBTyxFQUFFO3FCQUNQLElBQUksQ0FBQyxDQUFDLFFBQVEsRUFBRSxTQUFTLENBQUMsQ0FBQyxDQUFDO2dCQUU3QyxxQkFBTSxNQUFNLEdBQUdDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFFekMscUJBQU0sSUFBSSxHQUFJLFlBQVksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO3FCQUM1QixJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO3FCQUNsQyxLQUFLLEVBQUU7cUJBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDWCxJQUFJLENBQUMsV0FBVyxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7b0JBQ2pDLE9BQU8sWUFBWSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDO2lCQUMvQyxDQUFDLENBQUM7Z0JBRWYscUJBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3RDLElBQUksVUFBVSxFQUFFO29CQUNaLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQzt5QkFDWCxVQUFVLEVBQUU7eUJBQ1osUUFBUSxDQUFDLFVBQUMsQ0FBTSxFQUFFLENBQVM7d0JBQ3hCLE9BQU8sQ0FBQyxDQUFDLEtBQUssR0FBRyxrQkFBa0IsR0FBSSxHQUFHLENBQUM7cUJBQzlDLENBQUM7eUJBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU07d0JBQ2QsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNkLENBQUM7eUJBQ0QsS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFNO3dCQUMxQixPQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDbkIsQ0FBQyxDQUFDO2lCQUNkO3FCQUFNO29CQUNILE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTTt3QkFDYixPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ2QsQ0FBQzt5QkFDRCxLQUFLLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQU07d0JBQzFCLE9BQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNuQixDQUFDLENBQUM7aUJBQ2Q7Z0JBRUQscUJBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNwQixJQUFJLENBQUMsT0FBTyxFQUFFLHFCQUFxQixDQUFDO3FCQUNwQyxJQUFJLENBQUMsVUFBQyxDQUFNLEVBQUUsQ0FBUztvQkFDcEIsSUFBSSxDQUFDLENBQUMsS0FBSyxLQUFLLENBQUMsRUFBRTt3QkFDZixPQUFPLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO3FCQUN0QjtvQkFDRCxPQUFPLElBQUksQ0FBQztpQkFDZixDQUFDLENBQUM7Z0JBRWYsSUFBSSxVQUFVLEVBQUU7b0JBQ1osS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO3lCQUNwQixVQUFVLEVBQUU7eUJBQ1osUUFBUSxDQUFDLGtCQUFrQixDQUFDO3lCQUM1QixLQUFLLENBQUMsU0FBUyxFQUFFLEdBQUcsQ0FBQyxDQUFDO2lCQUM5QjtxQkFBTTtvQkFDSCxLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxHQUFHLENBQUMsQ0FBQztpQkFDL0I7Ozs7Ozs7Ozs7UUFJSyx3Q0FBUzs7Ozs7Ozs7c0JBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO2dCQUV6RyxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixDQUFDLENBQUM7Z0JBRTdDLHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7Z0JBQ2QscUJBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQkFDZCxLQUFLLEdBQUcsR0FBRyxDQUFDO2dCQUNaLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBQ1oscUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBS3RGLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO2dCQUNyQyxxQkFBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLFVBQVUsQ0FBQztnQkFFbkMscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2dCQUMvQyxxQkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztnQkFDekQscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDO2dCQUNuRCxxQkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQztnQkFDN0QscUJBQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUMzQyxxQkFBTSxVQUFVLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7Z0JBR3pDLHFCQUFNLElBQUksR0FBR0MsT0FBTyxFQUFFO3FCQUNMLElBQUksQ0FBQyxDQUFDLFdBQVcsRUFBRSxZQUFZLENBQUMsQ0FBQyxDQUFDO2dCQUVuRCxxQkFBTSxNQUFNLEdBQUdELFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQztnQkFFekMscUJBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFFM0IscUJBQU0sY0FBYyxHQUFHLFlBQVk7cUJBQ2hDLE1BQU0sQ0FBQyxHQUFHLENBQUM7cUJBQ1gsSUFBSSxDQUFDLFdBQVcsRUFDZixZQUFZLEdBQUcsV0FBVyxHQUFHLEdBQUcsR0FBRyxVQUFVLEdBQUcsR0FBRyxDQUFDLENBQUM7Z0JBRXpELHFCQUFNLElBQUksR0FBRyxjQUFjO3FCQUN0QixTQUFTLENBQUMsT0FBTyxDQUFDO3FCQUNsQixJQUFJLENBQUUsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDbkMsS0FBSyxFQUFFO3FCQUNQLE1BQU0sQ0FBQyxNQUFNLENBQUM7cUJBQ2QsSUFBSSxDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQztxQkFDL0IsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU07b0JBQ2QsT0FBTyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7MEJBQ3RCLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQzswQkFDeEMsR0FBRyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQzswQkFDaEQsR0FBRyxHQUFHLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztpQkFDekMsQ0FDSixDQUFDO2dCQUVOLHFCQUFNLElBQUksR0FBRyxjQUFjO3FCQUN0QixTQUFTLENBQUMsT0FBTyxDQUFDO3FCQUNsQixJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsRUFBRSxDQUFDO3FCQUN6QixLQUFLLEVBQUU7cUJBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDWCxJQUFJLENBQUMsT0FBTyxFQUFFLFVBQUMsQ0FBTTtvQkFDbEIsT0FBTyxXQUFXO3lCQUNqQixDQUFDLENBQUMsUUFBUSxHQUFHLFdBQVcsR0FBRyxPQUFPLENBQUMsQ0FBQztpQkFDeEMsQ0FBQztxQkFDRCxJQUFJLENBQUMsV0FBVyxFQUFFLFVBQUMsQ0FBTTtvQkFDdEIsT0FBTyxZQUFZLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7aUJBQy9DLENBQUMsQ0FBQztnQkFFUCxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztxQkFDaEIsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQztnQkFFbkIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7cUJBQ2QsSUFBSSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7cUJBQ25CLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxDQUFNO29CQUNkLE9BQU8sQ0FBQyxDQUFDLFFBQVEsR0FBRyxDQUFDLEVBQUUsR0FBRyxFQUFFLENBQUM7aUJBQ2hDLENBQUM7cUJBQ0QsS0FBSyxDQUFDLGFBQWEsRUFBRSxRQUFRLENBQUM7cUJBQzlCLElBQUksQ0FBQyxVQUFDLENBQU07b0JBQ1QsT0FBTyxDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztpQkFDdEIsQ0FBQyxDQUFDOzs7Ozs7Ozs7O1FBT0QsbURBQW9COzs7Ozs7OztzQkFBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7Z0JBRXBILE9BQU8sQ0FBQyxHQUFHLENBQUMsNkNBQTZDLENBQUMsQ0FBQztnQkFFM0QscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztnQkFDbEIscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQztnQkFDbEIscUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQ3RGLHFCQUFNLGVBQWUsR0FBRyxHQUFHLENBQUMsY0FBYyxDQUFDO2dCQUkzQyxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQy9DLHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFDakQscUJBQU0sV0FBVyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDO2dCQUVoRCxxQkFBTSxjQUFjLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxjQUFjLENBQUM7Z0JBQ3RELHFCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQztnQkFDckMscUJBQU0sV0FBVyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUMvQyxxQkFBTSxlQUFlLEdBQUcsSUFBSSxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsa0JBQWtCLENBQUM7Z0JBQ2xFLHFCQUFNLFlBQVksR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFDakQscUJBQU0sUUFBUSxHQUFHLE9BQU8sR0FBRyxZQUFZLENBQUM7Z0JBQ3hDLHFCQUFNLFVBQVUsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFNBQVMsQ0FBQztnQkFDN0MscUJBQU0sUUFBUSxHQUFLLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQztnQkFDckQscUJBQU0sUUFBUSxHQUFLLFdBQVcsQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQztnQkFDbkQscUJBQU0sV0FBVyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUMvQyxxQkFBTSxnQkFBZ0IsR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLGVBQWUsQ0FBQztnQkFDekQscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2dCQUMvQyxxQkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztnQkFDekQscUJBQUksV0FBVyxHQUFHLENBQUMsQ0FBQztnQkFFcEIscUJBQU0sZ0JBQWdCLEdBQUcsVUFBQyxJQUFZO29CQUNsQyxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO3dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUNwQyxJQUFJLElBQUksS0FBSyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRTtnQ0FDbkMscUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDO2dDQUN6QyxPQUFPLE1BQU0sQ0FBQzs2QkFDakI7eUJBQ0o7cUJBQ0o7b0JBQ0QsT0FBTyxJQUFJLENBQUM7aUJBQ2YsQ0FBQztnQkFFRixxQkFBTSxVQUFVLEdBQUdFLGtCQUFrQixFQUFFO3FCQUMxQixTQUFTLENBQUMsZUFBZSxDQUFDO3FCQUMxQixTQUFTLENBQUMsVUFBVSxDQUFDO3FCQUNyQixLQUFLLENBQUMsTUFBTSxDQUFDO3FCQUNiLE1BQU0sQ0FBQyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDO2dCQUUxQyxxQkFBTSxJQUFJLEdBQUdOLFVBQVUsRUFBRTtxQkFDWixVQUFVLENBQ1AsVUFBVSxDQUNiLENBQUM7Z0JBRWRFLE9BQU8sQ0FBQyxjQUFjLEVBQUUsVUFBQyxLQUFLLEVBQUUsSUFBSTtvQkFDaEMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7eUJBQ3hCLElBQUksQ0FBQyxJQUFJLEVBQUUsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUM5QixJQUFJLENBQUMsSUFBSSxFQUFFLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDOUIsSUFBSSxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUM7eUJBQ2pCLEtBQUssQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7b0JBRWhDLHFCQUFNLFNBQVMsR0FBRyxZQUFZLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQzt5QkFDM0MsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQzt5QkFDcEIsS0FBSyxFQUFFO3lCQUNQLE1BQU0sQ0FBQyxNQUFNLENBQUM7eUJBQ2QsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUM7eUJBQ2YsS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO3dCQUM3QixxQkFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFDO3dCQUMxQyxJQUFJLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxLQUFLLElBQUksRUFBRTs0QkFDeEMsT0FBTyxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsQ0FBQzt5QkFDeEM7d0JBRUQsT0FBTyxNQUFNLEdBQUcsQ0FBQyxHQUFHLFdBQVcsQ0FBQztxQkFDbkMsQ0FBQyxDQUFDO29CQUNQLElBQUksVUFBVSxFQUFFO3dCQUNaSyxRQUFRLENBQUM7NEJBQ0wsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLFFBQVEsR0FBRyxXQUFXLEVBQUUsUUFBUSxDQUFDLENBQUMsQ0FBQzs0QkFDdEQsV0FBVyxJQUFJLENBQUMsQ0FBQzs0QkFDakIsU0FBUyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDLENBQUM7eUJBQzdCLENBQUMsQ0FBQztxQkFDTjtpQkFDSixDQUFDLENBQUM7OztnQkFJSCxJQUFJLGFBQWEsRUFBRTtvQkFDZixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUN2QjtnQkFFRCxJQUFJLGNBQWMsRUFBRTtvQkFDaEIscUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO29CQUN4RCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO3dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUNwQyxxQkFBTSxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7NEJBQ3ZDLHFCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzs0QkFDekMsSUFBSSxLQUFLLEtBQUssWUFBWSxFQUFFO2dDQUN4QixTQUFTOzZCQUNaOzRCQUNELGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO3lCQUM5RjtxQkFDSjtvQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxjQUFjLENBQUMsQ0FBQztpQkFDekM7Ozs7Ozs7Ozs7UUFPSywwQ0FBVzs7Ozs7Ozs7c0JBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO2dCQUUzRyxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7Z0JBRWxELHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBQ2xCLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBQ2xCLHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUN0RixxQkFBTSxlQUFlLEdBQUcsR0FBRyxDQUFDLGNBQWMsQ0FBQztnQkFDM0MscUJBQU0sY0FBYyxHQUFJLFdBQVcsQ0FBQyxHQUFHLENBQUMsY0FBYyxDQUFDO2dCQUN2RCxxQkFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUM7Z0JBQ3JDLHFCQUFNLFlBQVksR0FBRyxXQUFXLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFDakQscUJBQU0sUUFBUSxHQUFHLE9BQU8sR0FBRyxZQUFZLENBQUM7Z0JBQ3hDLHFCQUFNLGVBQWUsR0FBRyxJQUFJLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztnQkFDbEUscUJBQU0sZ0JBQWdCLEdBQUcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUM7Z0JBQ3pELHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFFakQscUJBQU0sSUFBSSxHQUFHUCxVQUFVLEVBQUU7cUJBQ1osVUFBVSxDQUNQQyxjQUFjLEVBQUU7cUJBQ2YsU0FBUyxDQUFDLGVBQWUsQ0FBQztxQkFDMUIsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUNqQixDQUFDO2dCQUVkLHFCQUFNLGdCQUFnQixHQUFHLFVBQUMsSUFBWTtvQkFDbEMsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTt3QkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTs0QkFDcEMsSUFBSSxJQUFJLEtBQUssV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUU7Z0NBQ25DLHFCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztnQ0FDekMsT0FBTyxNQUFNLENBQUM7NkJBQ2pCO3lCQUNKO3FCQUNKO29CQUNELE9BQU8sSUFBSSxDQUFDO2lCQUNmLENBQUM7Z0JBRUZDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsVUFBQyxLQUFLLEVBQUUsSUFBSTtvQkFDaEMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7eUJBQ3JCLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7eUJBQ3BCLEtBQUssRUFBRTt5QkFDUCxNQUFNLENBQUMsTUFBTSxDQUFDO3lCQUNkLElBQUksQ0FBQyxHQUFHLEVBQUUsSUFBSSxDQUFDO3lCQUNmLEtBQUssQ0FBQyxNQUFNLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUzt3QkFDN0IscUJBQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsQ0FBQzt3QkFDMUMsSUFBSSxnQkFBZ0IsQ0FBQyxXQUFXLENBQUMsS0FBSyxJQUFJLEVBQUU7NEJBQ3hDLE9BQU8sZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUM7eUJBQ3hDO3dCQUNELE9BQU8sTUFBTSxHQUFHLENBQUMsR0FBRyxXQUFXLENBQUM7cUJBQ25DLENBQUMsQ0FBQztpQkFDVixDQUFDLENBQUM7OztnQkFJUCxJQUFJLGNBQWMsRUFBRTtvQkFDaEIscUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO29CQUN4RCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO3dCQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUNwQyxxQkFBTSxLQUFLLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7NEJBQ3ZDLHFCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQzs0QkFDekMsSUFBSSxLQUFLLEtBQUssWUFBWSxFQUFFO2dDQUN4QixTQUFTOzZCQUNaOzRCQUNELGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO3lCQUM5RjtxQkFDSjtvQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxjQUFjLENBQUMsQ0FBQztpQkFDekM7Ozs7Ozs7Ozs7UUFNSyw0Q0FBYTs7Ozs7Ozs7c0JBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO2dCQUU3RyxPQUFPLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7Z0JBU25ELHFCQUFNLE9BQU8sR0FBa0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDM0MsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtvQkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDckMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDbEI7aUJBQ0o7Z0JBRUQsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtvQkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDcEMscUJBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzt3QkFDVixLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTs0QkFDdkMsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7Z0NBQzdDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs2QkFDbEQ7eUJBQ0o7cUJBQ0o7aUJBQ0o7Z0JBQ0QscUJBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQkFDZCxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUNkLEtBQUssR0FBR1YsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUN4QixLQUFLLEdBQUcsR0FBRyxDQUFDO2dCQUNaLHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUV0RixxQkFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLGdCQUFnQixDQUFDO2dCQUNwQyxxQkFBTSxVQUFVLEdBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7Z0JBQzVDLHFCQUFNLFNBQVMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUcsVUFBVSxJQUFJLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO2dCQUM1RSxxQkFBTSxZQUFZLElBQUksR0FBRyxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUMsQ0FBRTtnQkFDcEQscUJBQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUM7Z0JBRXBDLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO2dCQUNyQyxxQkFBTSxVQUFVLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQztnQkFFakMscUJBQU0sUUFBUSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2dCQUMxQyxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Z0JBQ2pELHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7Z0JBQ2hELHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7Z0JBQ2hELHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFDL0MscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2dCQUMvQyxxQkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQzs7Z0JBR3pELHFCQUFNLGVBQWUsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDOztnQkFHOUMscUJBQU0sU0FBUyxHQUFrQixJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUM3QyxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO29CQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUNwQyxxQkFBTSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7d0JBQ3RDLHFCQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQzlDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3hCO2lCQUNKOztnQkFHRCxxQkFBTSxVQUFVLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQzlDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO29CQUN2QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDN0MscUJBQU0sT0FBTyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDL0MsVUFBVSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztxQkFDNUI7aUJBQ0o7Z0JBRUQscUJBQU0sVUFBVSxHQUFlLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQzNDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFVBQVUsRUFBRTtvQkFDeEIsSUFBSSxVQUFVLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUU5QixxQkFBTSxXQUFXLEdBQWUsRUFBRyxDQUFDO3dCQUNwQyxLQUFLLHFCQUFNLENBQUMsSUFBSSxTQUFTLEVBQUU7NEJBQ3ZCLElBQUksU0FBUyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQ0FDN0IscUJBQU0sSUFBSSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDMUIscUJBQU0sTUFBTSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQ0FDOUMsV0FBVyxDQUFDLElBQUksQ0FBQyxHQUFJLE1BQU0sQ0FBQzs2QkFDL0I7eUJBQ0o7d0JBQ0QsVUFBVSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQztxQkFDaEM7aUJBQ0o7Z0JBRUQscUJBQU0sTUFBTSxHQUFHRixjQUFjLEVBQUU7cUJBQ2QsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDO3FCQUN2QixLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsWUFBWSxDQUFDLENBQUMsQ0FBQztnQkFHMUMscUJBQU0sS0FBSyxHQUFHa0IsUUFBUSxFQUFFLENBQUM7Z0JBQ3pCLHFCQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztxQkFDcEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUM7cUJBQ3ZDLEtBQUssRUFBRTtxQkFDUCxNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUNYLElBQUksQ0FBQyxNQUFNLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUztvQkFDNUIsT0FBTyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ3BCLENBQUU7cUJBQ0YsSUFBSSxDQUFDLGNBQWMsRUFBRSxRQUFRLENBQUM7cUJBQzlCLFNBQVMsQ0FBQyxNQUFNLENBQUM7cUJBQ2pCLElBQUksQ0FBQyxVQUFDLENBQU0sRUFBRSxDQUFTO29CQUNwQixPQUFPLENBQUMsQ0FBQztpQkFDWixDQUFDO3FCQUNELEtBQUssRUFBRTtxQkFDUCxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBSXBCLElBQUksVUFBVSxFQUFFO29CQUNaLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7d0JBQzlCLE9BQU8sU0FBUyxHQUFLLENBQUMsR0FBRyxZQUFZLENBQUM7cUJBQ3pDLENBQUM7eUJBQ0QsSUFBSSxDQUFDLFFBQVEsRUFBRyxDQUFDLENBQUM7eUJBQ2xCLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUzt3QkFDekIscUJBQU0sRUFBRSxHQUFHLFNBQVMsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7d0JBQ3BDLHFCQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7d0JBQ3pCLE9BQU8sU0FBUyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDOUQsQ0FBQzt5QkFDRCxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQzt5QkFDeEIsVUFBVSxFQUFFO3lCQUNaLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQzt5QkFDNUIsSUFBSSxDQUFDLFFBQVEsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO3dCQUM5QixPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQzlCLENBQUMsQ0FBQztpQkFDTjtxQkFBTTtvQkFDSCxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO3dCQUM5QixPQUFPLFNBQVMsSUFBSSxDQUFDLEdBQUcsWUFBWSxDQUFDLENBQUM7cUJBQ3pDLENBQUM7eUJBQ0QsSUFBSSxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO3dCQUN6QixxQkFBTSxFQUFFLEdBQUcsU0FBUyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDcEMscUJBQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQzt3QkFDekIsT0FBTyxTQUFTLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUM5RCxDQUFDO3lCQUNELElBQUksQ0FBQyxPQUFPLEVBQUUsU0FBUyxDQUFDO3lCQUN4QixJQUFJLENBQUMsUUFBUSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7d0JBQzlCLE9BQU8sTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDOUIsQ0FBQyxDQUFDO2lCQUNOOzs7Z0JBS0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O2dCQUlwQixJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVyQixJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7Z0JBSXhCLElBQUksYUFBYSxFQUFFO29CQUNmLHFCQUFNLFdBQVcsR0FBbUIsSUFBSSxLQUFLLEVBQUUsQ0FBQztvQkFDaEQsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7d0JBQ3ZDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUM3QyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3lCQUNwRDtxQkFDSjtvQkFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUU1Qix5QkFBb0MsQ0FBQyxDQUFDO2lCQUMvRTs7O2dCQUtELElBQUksY0FBYyxFQUFFO29CQUNoQixxQkFBTSxjQUFjLEdBQXdCLElBQUksS0FBSyxFQUFFLENBQUM7b0JBQ3hELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7d0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7NEJBQ3BDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDOUU7cUJBQ0o7b0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7aUJBQ3pDO2dCQUVELElBQUksYUFBYSxFQUFFO29CQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3ZCOzs7Ozs7Ozs7O1FBSUssK0NBQWdCOzs7Ozs7OztzQkFBQyxZQUFpQixFQUFFLFVBQWUsRUFBRSxXQUFnQixFQUFFLFFBQWdCLEVBQUUsU0FBaUI7Z0JBRWhILE9BQU8sQ0FBQyxHQUFHLENBQUMsc0NBQXNDLENBQUMsQ0FBQztnQkFFcEQscUJBQU0sUUFBUSxHQUE2QixJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUN2RCxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUNkLHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7Z0JBQ2QsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtvQkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDcEMsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7NEJBQ3ZDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dDQUM3QyxJQUFJLEtBQUssR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0NBQ3hDLEtBQUssR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUNBQzFDO2dDQUNELElBQUksS0FBSyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRTtvQ0FDeEMsS0FBSyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztpQ0FDMUM7Z0NBQ0QscUJBQU0sZ0JBQWdCLEdBQUcsSUFBSSxpQkFBaUIsQ0FDMUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUM5QixXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQzlCLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FDakMsQ0FBRTtnQ0FDSCxRQUFRLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7NkJBQ25DO3lCQUNKO3FCQUNKO2lCQUNKO2dCQUNELHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUV0RixxQkFBTSxTQUFTLEdBQUcsR0FBRyxDQUFDLGFBQWEsQ0FBQztnQkFHcEMscUJBQU0sYUFBYSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2dCQUNoRCxxQkFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLGdCQUFnQixDQUFDO2dCQUNwQyxxQkFBTSxRQUFRLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQzFDLHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7Z0JBQ2hELHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7Z0JBQ2hELHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFDL0MscUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO2dCQUVqRCxxQkFBTSxPQUFPLEdBQUcsWUFBWSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7cUJBQ3ZDLElBQUksQ0FBQyxRQUFRLENBQUM7cUJBQ2QsS0FBSyxFQUFFO3FCQUNQLE1BQU0sQ0FBQyxRQUFRLENBQUM7cUJBQ2hCLElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBQyxDQUFvQixFQUFFLENBQU07b0JBQ3JDLE9BQU8sU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQzFCLENBQUM7cUJBQ0QsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFDLENBQW9CLEVBQUUsQ0FBTTtvQkFDckMsUUFBUSxTQUFTLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsRUFBRTtpQkFDdkQsQ0FBQztxQkFDRCxJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBb0IsRUFBRSxDQUFNO29CQUNwQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7aUJBQ2QsQ0FBQztxQkFDRCxLQUFLLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7b0JBQzdCLHFCQUFNLFNBQVMsR0FBRyxDQUFDLEdBQUcsYUFBYSxDQUFDO29CQUNwQyxPQUFPLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQztpQkFDNUIsQ0FBQztxQkFDRCxJQUFJLENBQUMsY0FBYyxFQUFHLFFBQVEsQ0FBQyxDQUFDOztnQkFJekMsSUFBSSxhQUFhLEVBQUU7b0JBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDdkI7OztnQkFJRCxJQUFJLGNBQWMsRUFBRTtvQkFDaEIscUJBQU0sY0FBYyxHQUF3QixJQUFJLEtBQUssRUFBRSxDQUFDO29CQUN4RCxLQUFLLHFCQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO3dCQUNoRCxjQUFjLENBQUMsSUFBSSxDQUFDLElBQUksWUFBWSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztxQkFDM0U7b0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7aUJBQ3pDOzs7Z0JBR0QsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFckIsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFFckIsSUFBSSxhQUFhLEVBQUU7b0JBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDdkI7Z0JBQ0QsSUFBSSxhQUFhLEVBQUU7b0JBQ2YsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDdkI7Ozs7OztRQUtLLHdDQUFTOzs7O3NCQUFDLFFBQWE7Z0JBRTdCLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLENBQUMsQ0FBQztnQkFFaEQscUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztnQkFDckIscUJBQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7Z0JBQ2xDLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDO2dCQUV0QyxxQkFBTSxNQUFNLEdBQUksR0FBRyxDQUFDLFNBQVMsQ0FBQztnQkFFOUIscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUM7Z0JBQzVCLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO2dCQUNyQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFDckMscUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7Z0JBQ25DLHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQztnQkFDakQscUJBQU0sV0FBVyxHQUFHVSxjQUFjLEVBQUU7cUJBQ25CLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztxQkFDbEIsS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssR0FBRyxZQUFZLENBQUMsQ0FBQyxDQUFDO2dCQUNsRCxxQkFBTSxPQUFPLEdBQUdtQixRQUFRLENBQUMsTUFBTSxHQUFHLFlBQVksRUFDOUIsS0FBSyxHQUFJLFlBQVksRUFDckIsTUFBTSxHQUFHLFlBQVksQ0FBQyxDQUFDO2dCQUV2QyxZQUFZLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDbkIsU0FBUyxDQUFDLFFBQVEsQ0FBQztxQkFDbkIsSUFBSSxDQUFDLE9BQU8sQ0FBQztxQkFDYixLQUFLLEVBQUU7cUJBQ1AsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDZCxJQUFJLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQztxQkFDN0IsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO29CQUMxQixxQkFBTSxHQUFHLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEdBQUksQ0FBQyxDQUFDO29CQUN4QyxPQUFPLEdBQUcsQ0FBQztpQkFDZCxDQUFDO3FCQUNELElBQUksQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDcEQsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO29CQUMxQixxQkFBTSxHQUFHLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEdBQUksQ0FBQyxDQUFDO29CQUN4QyxPQUFPLEdBQUcsQ0FBQztpQkFDZCxDQUFDO3FCQUNELElBQUksQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQzs7Ozs7O1FBRzNELHlDQUFVOzs7O3NCQUFDLFFBQWE7Z0JBRTlCLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLENBQUMsQ0FBQztnQkFFaEQscUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztnQkFDckIscUJBQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7Z0JBQ2xDLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDO2dCQUV0QyxxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQztnQkFDNUIscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7Z0JBRXJDLHFCQUFNLFdBQVcsR0FBR25CLGNBQWMsRUFBRTtxQkFDbkIsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUNsQixLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUM7Z0JBRWxELFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUNuQixJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxhQUFhLENBQUM7cUJBQ2hDLElBQUksQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLHVCQUF1QixDQUFDO3FCQUM5QyxJQUFJLENBQ0NvQixhQUFhLENBQUMsV0FBVyxDQUFDLENBQy9CLENBQUM7Ozs7Ozs7Ozs7Ozs7UUFRQSx1Q0FBUTs7Ozs7Ozs7c0JBQUMsWUFBaUIsRUFBRSxVQUFlLEVBQUUsV0FBZ0IsRUFBRSxRQUFnQixFQUFFLFNBQWlCO2dCQUV4RyxPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixDQUFDLENBQUM7Z0JBRTVDLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBQ2xCLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBQ2xCLHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUV0RixxQkFBTSxNQUFNLEdBQUcsR0FBRyxDQUFDLGdCQUFnQixDQUFDO2dCQUdwQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFHckMscUJBQU0sUUFBUSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2dCQUMxQyxxQkFBTSxZQUFZLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUM7Z0JBQzdDLHFCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDM0MscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2dCQUN6QyxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7Z0JBQy9DLHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFDakQscUJBQU0sbUJBQW1CLEdBQUcsR0FBRyxDQUFDLGtCQUFrQixDQUFDO2dCQUNuRCxxQkFBTSx3QkFBd0IsR0FBRyxHQUFHLENBQUMsdUJBQXVCLENBQUM7Z0JBQzdELHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztnQkFDL0MscUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUM7Z0JBQ3ZELHFCQUFNLHVCQUF1QixHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDO2dCQUNuRSxxQkFBTSw2QkFBNkIsR0FBRyxHQUFHLENBQUMsNEJBQTRCLENBQUM7Z0JBQ3ZFLHFCQUFNLGlCQUFpQixHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztnQkFDL0MscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2dCQUMvQyxxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Z0JBQ2pELHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFDL0MscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFDbkQscUJBQU0sZUFBZSxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQztnQkFDdkQscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO2dCQUMvQyxxQkFBTSxrQkFBa0IsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQztnQkFLekQscUJBQU0sT0FBTyxHQUFrQixJQUFJLEtBQUssRUFBRSxDQUFDO2dCQUMzQyxLQUFLLHFCQUFNLENBQUMsSUFBTSxXQUFXLENBQUMsSUFBSSxFQUFFO29CQUNoQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUNwQyxxQkFBTSxJQUFJLEdBQUcsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7d0JBQ3ZDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7cUJBQ3RCO2lCQUNKO2dCQUVELHFCQUFNLElBQUksR0FBR0MsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDO2dCQUM3QixxQkFBTSxHQUFHLEdBQUdDLE1BQU0sRUFBRSxDQUFDO2dCQUNyQixxQkFBTSxHQUFHLEdBQUdDLE1BQU0sRUFBRTtxQkFDUCxXQUFXLENBQUMsWUFBWSxHQUFHLG1CQUFtQixHQUFHLEdBQUcsQ0FBQztxQkFDckQsV0FBVyxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFFM0MscUJBQU0sV0FBVyxHQUFHLFlBQVksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO3FCQUN6QixJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3FCQUNsQixLQUFLLEVBQUU7cUJBQ1AsTUFBTSxDQUFDLEdBQUcsQ0FBQztxQkFDWCxJQUFJLENBQUMsV0FBVyxFQUFFLHdCQUF3QixDQUFDLENBQUM7Z0JBR3JFLHFCQUFNLGdCQUFnQixHQUFHO29CQUNqQixJQUFJLGFBQWEsSUFBSSxlQUFlLEVBQUU7d0JBQ2xDLHFCQUFNLEdBQUcsR0FBRyxpQkFBaUIsR0FBRyxHQUFHLEdBQUcsSUFBSSxHQUFJLFNBQVMsQ0FBQzt3QkFDeEQsT0FBTyxHQUFHLENBQUM7cUJBQ2Q7b0JBQ0QsSUFBSSxlQUFlLEVBQUU7d0JBQ2pCLE9BQU8sTUFBTSxDQUFDO3FCQUNqQjtvQkFDRCxJQUFJLGFBQWEsRUFBRTt3QkFDZixPQUFPLGlCQUFpQixHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUM7cUJBQ3pDO2lCQUNSLENBQUM7Z0JBRUYscUJBQU0sWUFBWSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUN2QixJQUFJLENBQUMsT0FBTyxFQUFFLHVCQUF1QixDQUFDO3FCQUN0QyxJQUFJLENBQUMsV0FBVyxFQUFFLDZCQUE2QixDQUFFO3FCQUNqRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztnQkFFaEQscUJBQU0sSUFBSSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUMxQixJQUFJLENBQUMsT0FBTyxFQUFFLGFBQWEsQ0FBQztxQkFDNUIsS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO29CQUM3QixPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztpQkFDcEIsQ0FBQztxQkFDRCxJQUFJLENBQUMsY0FBYyxFQUFFLFFBQVEsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0JBc0I1QyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztnQkFFcEIsV0FBVyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7cUJBQ2IsSUFBSSxDQUFDLE9BQU8sRUFBRSxrQkFBa0IsQ0FBQztxQkFDakMsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO29CQUNyQyxPQUFPLFlBQVksR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztpQkFDM0MsQ0FBQztxQkFDRCxJQUFJLENBQUMsVUFBQyxDQUFNLEVBQUUsQ0FBUztvQkFDcEIsSUFBSSxhQUFhLElBQUksZUFBZSxFQUFFO3dCQUNsQyxxQkFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLEdBQUksR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDNUQscUJBQU0sR0FBRyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLEdBQUcsSUFBSSxHQUFHLFVBQVUsR0FBRyxJQUFJLENBQUM7d0JBQ3ZELE9BQU8sR0FBRyxDQUFDO3FCQUNkO29CQUNELElBQUksZUFBZSxFQUFFO3dCQUNqQixxQkFBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJLEdBQUksR0FBRyxDQUFDLENBQUMsQ0FBQzt3QkFDNUQscUJBQU0sR0FBRyxHQUFHLFVBQVUsR0FBRyxHQUFHLENBQUM7d0JBQzdCLE9BQU8sR0FBRyxDQUFDO3FCQUNkO29CQUNELElBQUksYUFBYSxFQUFFO3dCQUNmLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQztxQkFDbEI7aUJBQ0osQ0FBQyxDQUFDOztnQkFHZixJQUFJLGFBQWEsRUFBRTtvQkFDZixJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO2lCQUN2Qjs7O2dCQUlELElBQUksY0FBYyxFQUFFO29CQUNoQixxQkFBTSxjQUFjLEdBQXdCLElBQUksS0FBSyxFQUFFLENBQUM7b0JBQ3hELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7d0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7NEJBQ3BDLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxZQUFZLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDOUU7cUJBQ0o7b0JBQ0QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDLENBQUM7aUJBQ3pDOzs7Ozs7Ozs7O1FBS0ssdUNBQVE7Ozs7Ozs7O3NCQUFDLFlBQWlCLEVBQUUsVUFBZSxFQUFFLFdBQWdCLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtnQkFFeEcsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFDO2dCQUU1QyxxQkFBTSxTQUFTLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBQzdDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7b0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3BDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFOzRCQUNuQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQ0FDekMscUJBQU0sRUFBRSxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dDQUNwQyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDOzZCQUN0Qjt5QkFDSjtxQkFDSjtpQkFDSjtnQkFFRCxxQkFBSSxLQUFLLEdBQUcsQ0FBQyxDQUFDO2dCQUNkLHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7Z0JBQ2QsS0FBSyxHQUFHckIsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO2dCQUMxQixLQUFLLEdBQUcsR0FBRyxDQUFDO2dCQUNaLHFCQUFNLEdBQUcsR0FBRyxJQUFJLFFBQVEsQ0FBQyxZQUFZLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUV0RixxQkFBTSxjQUFjLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7Z0JBQ3JELHFCQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7Z0JBQ3BDLHFCQUFNLFVBQVUsR0FBSSxXQUFXLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztnQkFDOUMscUJBQU0sVUFBVSxHQUFJLFNBQVMsQ0FBQyxNQUFNLENBQUM7Z0JBRXJDLHFCQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsYUFBYSxDQUFDO2dCQUNwQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFDckMscUJBQU0sV0FBVyxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7Z0JBRW5DLHFCQUFNLFFBQVEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztnQkFDMUMscUJBQU0sWUFBWSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDO2dCQUM3QyxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQy9DLHFCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDM0MscUJBQU0sVUFBVSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO2dCQUN6QyxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7Z0JBQy9DLHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQztnQkFDakQscUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDO2dCQUNqRCxxQkFBTSxhQUFhLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7Z0JBQy9DLHFCQUFNLGFBQWEsR0FBRyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUM7Z0JBQ2hELHFCQUFNLFVBQVUsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztnQkFDL0MscUJBQU0sa0JBQWtCLEdBQUcsVUFBVSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7Z0JBRXpELHFCQUFNLFNBQVMsR0FBRyxDQUFDLFdBQVcsSUFBSSxjQUFjLEdBQUcsVUFBVSxHQUFHLFVBQVUsQ0FBQyxJQUFLLFVBQVUsQ0FBQztnQkFDM0YscUJBQU0sWUFBWSxJQUFJLFdBQVcsR0FBRyxVQUFVLENBQUMsQ0FBRTtnQkFFakQscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxXQUFXLENBQUM7Z0JBRXJDLHFCQUFNLFNBQVMsR0FBR0YsY0FBYyxFQUFFO3FCQUNqQixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7cUJBQ2xCLEtBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFFbEQscUJBQU0sV0FBVyxHQUFHLGNBQWMsQ0FBQztnQkFLbkMscUJBQU0sUUFBUSxHQUFHLFlBQVksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO3FCQUN2QyxJQUFJLENBQUMsU0FBUyxDQUFDO3FCQUNmLEtBQUssRUFBRTtxQkFDUCxNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUNYLElBQUksQ0FBQyxXQUFXLEVBQUUsVUFBQyxDQUFNLEVBQUUsQ0FBUztvQkFDakMscUJBQU0sUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsVUFBVSxNQUFNLENBQUMsSUFBSSxXQUFXLEdBQUcsQ0FBQyxDQUFDO29CQUM1RCxPQUFPLFlBQVksSUFBSSxRQUFRLEdBQUcsWUFBWSxHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztpQkFDN0QsQ0FBQztxQkFDRCxLQUFLLENBQUMsTUFBTSxFQUFFLFVBQUMsQ0FBTSxFQUFFLENBQVM7b0JBQzdCLHFCQUFNLFFBQVEsSUFBSSxDQUFDLEdBQUcsVUFBVSxDQUFDLENBQUM7b0JBQ2xDLE9BQU8sTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO2lCQUMzQixDQUFDO3FCQUNELElBQUksQ0FBQyxjQUFjLEVBQUUsUUFBUSxDQUFDLENBQUM7Z0JBRXBDLHFCQUFNLEtBQUssR0FBSSxRQUFRLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUN2QyxJQUFJLFVBQVUsRUFBRTtvQkFDWixLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxXQUFXLENBQUM7eUJBQzNCLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQyxDQUFDO3lCQUNqQixJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTTt3QkFDZCxPQUFPLFNBQVMsQ0FBQztxQkFDcEIsQ0FBQzt5QkFDRCxJQUFJLENBQUMsT0FBTyxFQUFFLFNBQVMsR0FBRyxXQUFXLENBQUM7eUJBQ3RDLFVBQVUsRUFBRTt5QkFDWixRQUFRLENBQUMsa0JBQWtCLENBQUM7eUJBQzVCLElBQUksQ0FBQyxHQUFHLEVBQUUsVUFBQyxDQUFNO3dCQUNkLE9BQU8sU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQztxQkFDbkMsQ0FBQzt5QkFDRCxJQUFJLENBQUMsUUFBUSxFQUFFLFVBQUMsQ0FBTTt3QkFDbkIsT0FBTyxZQUFZLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFFO3FCQUN2QyxDQUFDLENBQUM7aUJBQ047cUJBQU07b0JBQ0gsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDO3lCQUMzQixJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTTt3QkFDZCxPQUFPLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUM7cUJBQ25DLENBQUM7eUJBQ0QsSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLEdBQUcsV0FBVyxDQUFDO3lCQUN0QyxJQUFJLENBQUMsUUFBUSxFQUFFLFVBQUMsQ0FBTTt3QkFDbkIsT0FBTyxZQUFZLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUN0QyxDQUFDLENBQUM7aUJBQ047Z0JBRUQscUJBQU0sWUFBWSxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQzdDLFlBQVk7cUJBQ1AsSUFBSSxDQUFDLE9BQU8sRUFBRSxjQUFjLENBQUM7cUJBQzdCLElBQUksQ0FBQyxHQUFHLEVBQUUsV0FBVyxDQUFDO3FCQUN0QixJQUFJLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBTTtvQkFDaEIsT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDO2lCQUNqQyxDQUFDO3FCQUNELElBQUksQ0FBQyxVQUFDLENBQU07b0JBQ1gsT0FBTyxDQUFDLENBQUU7aUJBQ1gsQ0FBQyxDQUFDOzs7Z0JBSVAsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O2dCQUlyQixJQUFJLGFBQWEsRUFBRTtvQkFDZixxQkFBTSxXQUFXLEdBQW1CLElBQUksS0FBSyxFQUFFLENBQUM7b0JBQ2hELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7d0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7NEJBQ3BDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzt5QkFDM0M7cUJBQ0o7b0JBQ0QsSUFBSSxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsV0FBVyxFQUFFZCxtQkFBOEIsQ0FBQyxDQUFDO2lCQUN6RTtnQkFFRCxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7Z0JBSXhCLHFCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDeEQsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLE1BQU0sRUFBRTtvQkFDaEMsSUFBSSxXQUFXLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDeEMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLFlBQVksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7cUJBQ3pFO2lCQUNKO2dCQUNELElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLGNBQWMsQ0FBQyxDQUFDOzs7Z0JBSXRDLElBQUksYUFBYSxFQUFFO29CQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3ZCO2dCQUVELElBQUksYUFBYSxFQUFFO29CQUNmLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3ZCOzs7Ozs7Ozs7O1FBS0ssd0NBQVM7Ozs7Ozs7O3NCQUFDLFlBQWlCLEVBQUUsVUFBZSxFQUFFLFdBQWdCLEVBQUUsUUFBZ0IsRUFBRSxTQUFpQjtnQkFFekcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFDO2dCQUUvQyxxQkFBTSxVQUFVLEdBQWtCLElBQUksS0FBSyxFQUFFLENBQUM7Z0JBRTlDLEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLEVBQUU7b0JBQzlCLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQyxDQUFDLEVBQUU7d0JBQ3BDLHFCQUFJLE1BQU0sR0FBRyxDQUFDLENBQUM7d0JBQ2YsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7NEJBQ3ZDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO2dDQUM3QyxJQUFJLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7b0NBQ3pDLE1BQU0sR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7aUNBQzNDOzZCQUNKO3lCQUNKO3dCQUNELFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUU7cUJBQzVCO2lCQUNKO2dCQUNELHFCQUFJLEtBQUssR0FBRyxDQUFDLENBQUM7Z0JBQ2QscUJBQUksS0FBSyxHQUFHLENBQUMsQ0FBQztnQkFDZCxLQUFLLEdBQUdnQixNQUFNLENBQUMsVUFBVSxDQUFDLENBQUM7Z0JBQzNCLEtBQUssR0FBRyxHQUFHLENBQUM7Z0JBRVoscUJBQU0sR0FBRyxHQUFHLElBQUksUUFBUSxDQUFDLFlBQVksRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLEtBQUssRUFBRSxRQUFRLEVBQUUsU0FBUyxDQUFDLENBQUM7Z0JBQ3RGLHFCQUFNLE1BQU0sR0FBRyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7Z0JBRXBDLHFCQUFNLFVBQVUsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUU7Z0JBQ3JELHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsVUFBVSxHQUFHLFVBQVUsQ0FBQztnQkFFakQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQztnQkFFMUIsSUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUU7b0JBQzNCLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7aUJBQ3ZCOztnQkFHRCxLQUFLLHFCQUFNLENBQUMsSUFBSSxXQUFXLENBQUMsSUFBSSxFQUFFO29CQUM5QixJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUNwQyxxQkFBTSxVQUFVLEdBQXlCLElBQUksS0FBSyxFQUFFLENBQUM7d0JBQ3JELEtBQUsscUJBQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFOzRCQUN2QyxJQUFJLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTtnQ0FDN0MscUJBQU0sT0FBTyxHQUFHLElBQUksYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLEVBQUUsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0NBQ25GLFVBQVUsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7NkJBQzVCO3lCQUNKO3dCQUNELHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO3dCQUM1QixJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxVQUFVLEVBQUUsR0FBRyxDQUFDLENBQUM7cUJBQzdDO2lCQUNKOzs7Z0JBSUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7O2dCQUlwQixJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDO2dCQUVyQixJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7Z0JBSXhCLHFCQUFNLFdBQVcsR0FBbUIsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDaEQsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7b0JBQ3ZDLElBQUksV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLENBQUMsQ0FBQyxFQUFFO3dCQUM3QyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUNwRDtpQkFDSjtnQkFDRCxJQUFJLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUVqQixvQkFBK0IsQ0FBQyxDQUFDOzs7Z0JBSXZFLHFCQUFNLGNBQWMsR0FBd0IsSUFBSSxLQUFLLEVBQUUsQ0FBQztnQkFDeEQsS0FBSyxxQkFBTSxDQUFDLElBQUksV0FBVyxDQUFDLElBQUksRUFBRTtvQkFDOUIsSUFBSSxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRTt3QkFDdEMsY0FBYyxDQUFDLElBQUksQ0FBQyxJQUFJLFlBQVksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO3FCQUM1RTtpQkFDSjtnQkFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxjQUFjLENBQUMsQ0FBQzs7Ozs7Ozs7UUFPaEMsNkNBQWM7Ozs7OztzQkFBQyxRQUFhLEVBQUUsT0FBWSxFQUFFLE9BQWU7Z0JBRWpFLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0NBQXNDLENBQUMsQ0FBQztnQkFFcEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDckIscUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztnQkFDckIscUJBQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7Z0JBQ2xDLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDO2dCQUV0QyxxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLFNBQVMsQ0FBQztnQkFDNUIscUJBQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztnQkFDekMscUJBQU0sU0FBUyxHQUFHLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQztnQkFDekMscUJBQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUM7Z0JBQ2xDLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsVUFBVSxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDdkQscUJBQU0sTUFBTSxHQUFHSixlQUFlLENBQUNFLG1CQUFtQixDQUFDLENBQUM7Z0JBRXBELHFCQUFNLGNBQWMsR0FBRyxVQUFVLENBQUMsU0FBUyxDQUFDLGVBQWUsR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQzlFLHFCQUFNLFdBQVcsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQztnQkFDM0MscUJBQU0sYUFBYSxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO2dCQUUvQyxxQkFBTSxPQUFPLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFHaEMscUJBQU0sSUFBSSxHQUFHeUMsT0FBTyxFQUFFO3FCQUNqQixLQUFLLENBQUNDLGNBQWMsQ0FBQztxQkFDckIsQ0FBQyxDQUFFLFVBQUMsQ0FBTTtvQkFDUCxPQUFPLFdBQVcsR0FBRyxDQUFDLENBQUMsRUFBRSxHQUFHLFlBQVksQ0FBQztpQkFDNUMsQ0FBQztxQkFDRCxDQUFDLENBQUUsVUFBQyxDQUFNO29CQUNQLE9BQU8sR0FBRyxDQUFDLFNBQVMsR0FBRyxhQUFhLElBQUssQ0FBQyxDQUFDLEtBQUssR0FBRyxPQUFPLENBQUMsQ0FBRTtpQkFDaEUsQ0FBQyxDQUFDO2dCQUVQLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNsQixJQUFJLENBQUMsT0FBTyxFQUFFLGNBQWMsQ0FBQztxQkFDN0IsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7UUFRNUIsMENBQVc7Ozs7O3NCQUFDLFFBQWEsRUFBRSxjQUFtQjtnQkFFcEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDOztnQkFHakQscUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztnQkFDckIscUJBQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7Z0JBQ2xDLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDOztnQkFFdEMscUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDO2dCQUNuRCxxQkFBTSxhQUFhLEdBQUcsRUFBRSxDQUFDO2dCQUN6QixxQkFBTSxRQUFRLEdBQUcsVUFBVSxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUM7Z0JBQzVDLHFCQUFNLFFBQVEsR0FBRyxHQUFHLENBQUMsY0FBYyxDQUFDO2dCQUNwQyxxQkFBTSxRQUFRLEdBQUcsR0FBRyxDQUFDLGNBQWMsQ0FBQztnQkFDcEMscUJBQU0sT0FBTyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO2dCQUV6QyxxQkFBTSxTQUFTLEdBQUcsWUFBWSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7cUJBQzdCLFNBQVMsQ0FBQyxHQUFHLENBQUM7cUJBQ2QsSUFBSSxDQUFDLGNBQWMsQ0FBQztxQkFDcEIsS0FBSyxFQUFFO3FCQUNQLE1BQU0sQ0FBQyxHQUFHLENBQUM7cUJBQ1gsSUFBSSxDQUFDLE9BQU8sRUFBRSxRQUFRLENBQUM7cUJBQ3ZCLElBQUksQ0FBQyxXQUFXLEVBQUUsVUFBQyxDQUFlLEVBQUUsQ0FBUztvQkFDMUMscUJBQU0sTUFBTSxHQUFHLGNBQWMsR0FBRyxRQUFRLENBQUM7b0JBQ3pDLHFCQUFNLENBQUMsR0FBRyxRQUFRLENBQUM7b0JBQ25CLHFCQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsTUFBTSxHQUFHLFFBQVEsQ0FBRTtvQkFDakMsT0FBTyxZQUFZLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLEdBQUcsR0FBRyxDQUFDO2lCQUM1QyxDQUFDLENBQUM7Z0JBRWYsU0FBUyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUM7cUJBQ25CLElBQUksQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO3FCQUM3QixJQUFJLENBQUMsUUFBUSxFQUFFLGNBQWMsQ0FBQztxQkFDOUIsS0FBSyxDQUFDLE1BQU0sRUFBRSxVQUFDLENBQWU7b0JBQzNCLE9BQU8sQ0FBQyxDQUFDLEtBQUssQ0FBQztpQkFDbEIsQ0FBQztxQkFDRCxLQUFLLENBQUMsUUFBUSxFQUFFLFVBQUMsQ0FBZTtvQkFDN0IsT0FBTyxDQUFDLENBQUMsS0FBSyxDQUFDO2lCQUNsQixDQUFDO3FCQUNELElBQUksQ0FBQyxjQUFjLEVBQUUsT0FBTyxDQUFDLENBQUM7Z0JBRW5DLFNBQVMsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNuQixJQUFJLENBQUMsR0FBRyxFQUFFLGNBQWMsR0FBRyxhQUFhLENBQUM7cUJBQ3pDLElBQUksQ0FBQyxHQUFHLEVBQUUsY0FBYyxDQUFDO3FCQUN6QixJQUFJLENBQUMsVUFBQyxDQUFlO29CQUNsQixPQUFPLENBQUMsQ0FBQyxLQUFLLENBQUM7aUJBQ2xCLENBQUMsQ0FBQzs7Ozs7Ozs7UUFJRCw2Q0FBYzs7Ozs7O3NCQUFDLFFBQWEsRUFBRSxZQUFpQixFQUFFLFNBQWlCO2dCQUV4RSxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxDQUFDLENBQUM7Z0JBRXBELHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7Z0JBQ3JCLHFCQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUNsQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQzs7Z0JBR3RDLHFCQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsa0JBQWtCLENBQUM7Z0JBQ3pDLHFCQUFNLFNBQVMsR0FBRyxHQUFHLENBQUMsa0JBQWtCLENBQUM7Z0JBRXpDLHFCQUFNLFVBQVUsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDO2dCQUN2QyxxQkFBSSxZQUFZLEdBQUcsR0FBRyxDQUFDLFVBQVUsR0FBRyxVQUFVLENBQUM7Z0JBQy9DLElBQUssU0FBUyxLQUFLeEMsb0JBQStCLEVBQUU7b0JBQ2hELFlBQVksR0FBRyxHQUFHLENBQUMsVUFBVSxJQUFJLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQztpQkFDcEQ7Z0JBRUQscUJBQU0sUUFBUSxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUM1QixTQUFTLENBQUMsR0FBRyxDQUFDO3FCQUNkLElBQUksQ0FBQyxZQUFZLENBQUM7cUJBQ2xCLEtBQUssRUFBRTtxQkFDUCxNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUNYLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLFNBQVMsQ0FBQztxQkFDbkMsSUFBSSxDQUFDLFdBQVcsRUFBRSxVQUFDLENBQU0sRUFBRSxDQUFTO29CQUNqQyxxQkFBTSxFQUFFLEdBQUcsU0FBUyxHQUFHLFlBQVksR0FBRyxDQUFDLENBQUM7b0JBQ3hDLHFCQUFNLEVBQUUsR0FBRyxTQUFTLENBQUU7b0JBQ3RCLE9BQU8sWUFBWSxHQUFHLEVBQUUsR0FBRyxJQUFJLEdBQUcsRUFBRSxHQUFHLEdBQUcsQ0FBQztpQkFDOUMsQ0FBQyxDQUFDO2dCQUVmLFFBQVEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNWLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBVSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUM7cUJBQzdDLElBQUksQ0FBQyxVQUFDLENBQU0sRUFBRSxDQUFTO29CQUNwQixPQUFPLENBQUMsQ0FBQztpQkFDWixDQUFDLENBQUM7Ozs7OztRQU1ULDRDQUFhOzs7O3NCQUFDLFFBQWE7Z0JBRWpDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUNBQXFDLENBQUMsQ0FBQztnQkFFbkQscUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztnQkFDckIscUJBQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUM7Z0JBRXRDLFlBQVksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUN0QixJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyx3QkFBd0IsQ0FBQztxQkFDM0MsSUFBSSxDQUFDLE9BQU8sRUFBRSxHQUFHLENBQUMsZ0JBQWdCLENBQUM7cUJBQ25DLElBQUksQ0FBQyxRQUFRLEVBQUUsR0FBRyxDQUFDLG9CQUFvQixDQUFDO3FCQUN4QyxJQUFJLENBQUMsV0FBVyxFQUFFLEdBQUcsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDOzs7Ozs7UUFROUMseUNBQVU7Ozs7c0JBQUMsUUFBYTtnQkFFOUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO2dCQUVoRCxxQkFBTSxHQUFHLEdBQUcsUUFBUSxDQUFDO2dCQUNyQixxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQztnQkFFdEMscUJBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxTQUFTLENBQUM7Z0JBQzVCLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsV0FBVyxDQUFDO2dCQUVyQyxxQkFBTSxXQUFXLEdBQUdlLGNBQWMsRUFBRTtxQkFDbkIsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDO3FCQUNsQixLQUFLLENBQUMsQ0FBQyxLQUFLLEdBQUcsWUFBWSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBRWxELFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUNuQixJQUFJLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxhQUFhLENBQUM7cUJBQ2hDLElBQUksQ0FBQyxXQUFXLEVBQUUsR0FBRyxDQUFDLGdCQUFnQixDQUFDO3FCQUN2QyxJQUFJLENBQ0MwQixXQUFXLENBQUMsV0FBVyxDQUFDLENBQ3ZCLENBQUM7Ozs7OztRQU9OLHdDQUFTOzs7O3NCQUFDLFFBQWE7Z0JBRTdCLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztnQkFFL0MscUJBQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQztnQkFDckIscUJBQU0sVUFBVSxHQUFHLEdBQUcsQ0FBQyxVQUFVLENBQUM7Z0JBQ2xDLHFCQUFNLFlBQVksR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDO2dCQUV0QyxxQkFBTSxNQUFNLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7Z0JBQ3JDLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsYUFBYSxDQUFDO2dCQUNoQyxxQkFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLGFBQWEsQ0FBQztnQkFDaEMscUJBQU0sZUFBZSxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDO2dCQUVuRCxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQztxQkFDdEIsSUFBSSxDQUFDLE9BQU8sRUFBRSxlQUFlLENBQUM7cUJBQzlCLElBQUksQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDO3FCQUNoQixJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssQ0FBQztxQkFDaEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDOzs7Ozs7UUFPWix3Q0FBUzs7OztzQkFBQyxRQUFhO2dCQUU3QixPQUFPLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxDQUFDLENBQUM7Z0JBRWhELHFCQUFNLEdBQUcsR0FBRyxRQUFRLENBQUM7Z0JBQ3JCLHFCQUFNLFVBQVUsR0FBRyxHQUFHLENBQUMsVUFBVSxDQUFDO2dCQUNsQyxxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQztnQkFFdEMscUJBQU0sTUFBTSxHQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUM7Z0JBQzlCLHFCQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsU0FBUyxDQUFDO2dCQUM1QixxQkFBTSxZQUFZLEdBQUcsR0FBRyxDQUFDLFdBQVcsQ0FBQztnQkFDckMscUJBQU0sY0FBYyxHQUFHLFVBQVUsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDO2dCQUNqRCxxQkFBTSxPQUFPLEdBQUdQLFFBQVEsQ0FBQyxNQUFNLEdBQUcsWUFBWSxFQUM5QixLQUFLLEdBQUcsWUFBWSxFQUNwQixNQUFNLEdBQUcsWUFBWSxDQUFDLENBQUM7Z0JBRXZDLFlBQVksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO3FCQUNuQixTQUFTLENBQUMsUUFBUSxDQUFDO3FCQUNuQixJQUFJLENBQUMsT0FBTyxDQUFDO3FCQUNiLEtBQUssRUFBRTtxQkFDUCxNQUFNLENBQUMsTUFBTSxDQUFDO3FCQUNkLElBQUksQ0FBQyxPQUFPLEVBQUUsY0FBYyxDQUFDO3FCQUM3QixJQUFJLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDO3FCQUNsQyxJQUFJLENBQUMsSUFBSSxFQUFFLFVBQUUsQ0FBTSxFQUFFLENBQVM7b0JBQzNCLHFCQUFNLEdBQUcsR0FBRyxHQUFHLENBQUMsU0FBUyxHQUFHLFVBQVUsQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztvQkFDekQsT0FBTyxHQUFHLENBQUM7aUJBQ2QsQ0FBQztxQkFDRCxJQUFJLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUMsSUFBSSxHQUFHLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQztxQkFDekQsSUFBSSxDQUFDLElBQUksRUFBRSxVQUFFLENBQU0sRUFBRSxDQUFTO29CQUMzQixxQkFBTSxHQUFHLEdBQUcsR0FBRyxDQUFDLFNBQVMsR0FBRyxVQUFVLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7b0JBQ3pELE9BQU8sR0FBRyxDQUFDO2lCQUNkLENBQUMsQ0FBQzs7O29CQWpxRFJRLGNBQVMsU0FBQzt3QkFDVCxRQUFRLEVBQUUsaUJBQWlCO3dCQUMzQixRQUFRLEVBQUUsRUFBRTt3QkFDWixNQUFNLEVBQUUsRUFBRTtxQkFDWDs7Ozs7d0JBWG9EQyxlQUFVOzs7O2tDQWE1REMsVUFBSztpQ0FDTEEsVUFBSztrQ0FDTEEsVUFBSztrQ0FDTEEsVUFBSzttQ0FDTEEsVUFBSzs7bUNBakJSOzs7Ozs7O0FDQUE7Ozs7b0JBR0NDLGFBQVEsU0FBQzt3QkFDUixPQUFPLEVBQUUsRUFDUjt3QkFDRCxZQUFZLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQzt3QkFDcEMsT0FBTyxFQUFFLENBQUMsb0JBQW9CLENBQUM7cUJBQ2hDOztnQ0FSRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7In0=