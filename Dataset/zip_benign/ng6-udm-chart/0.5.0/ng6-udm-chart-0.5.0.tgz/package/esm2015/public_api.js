/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
/*
 * Public API Surface of ng6-udm-chart
 */
export { LINE_CHART_TYPE_NAME, BAR_CHART_TYPE_NAME, PIE_CHART_TYPE_NAME, SCATTER_PLOT_CHART_TYPE_NAME, HISTOGRAM_CHART_TYPE_NAME, STACK_BAR_CHART_TYPE_NAME, GEO_MAP_CHART_TYPE_NAME, GEO_ORTHOGRAPHIC_CHART_TYPE_NAME, TREE_MAP_CHART_TYPE_NAME, PACK_LAYOUT_CHART_TYPE_NAME, CHOROPLETH_CHART_TYPE_NAME, TREE_CHART_TYPE_NAME, SANKEY_CHART_TYPE_NAME, FORCE_CHART_TYPE_NAME } from './lib/shared/chart-const';
export { Ng6UdmChartComponent } from './lib/ng6-udm-chart.component';
export { Ng6UdmChartModule } from './lib/ng6-udm-chart.module';

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL25nNi11ZG0tY2hhcnQvIiwic291cmNlcyI6WyJwdWJsaWNfYXBpLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7QUFHQSxzWEFBYywwQkFBMEIsQ0FBQztBQUN6QyxxQ0FBYywrQkFBK0IsQ0FBQztBQUM5QyxrQ0FBYyw0QkFBNEIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qXG4gKiBQdWJsaWMgQVBJIFN1cmZhY2Ugb2Ygbmc2LXVkbS1jaGFydFxuICovXG5leHBvcnQgKiBmcm9tICcuL2xpYi9zaGFyZWQvY2hhcnQtY29uc3QnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbmc2LXVkbS1jaGFydC5jb21wb25lbnQnO1xuZXhwb3J0ICogZnJvbSAnLi9saWIvbmc2LXVkbS1jaGFydC5tb2R1bGUnO1xuIl19