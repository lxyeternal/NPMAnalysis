export enum GameStatus {
    READY = 0,
    IN_PROGRESS = 1,
    TIMEDOUT = 2,
    COMPLETED = 3,
    PAUSED = 4
}

export type Nullable<T> = T | null;

export type GameStatusChangeEvent = {
    startTime: number | null;
    status: GameStatus;
    endTime: number | null;
    pausedAtTime: number | null;
    pauseTime: number;
};
