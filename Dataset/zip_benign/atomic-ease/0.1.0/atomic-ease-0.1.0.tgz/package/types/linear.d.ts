import type { Easing } from "./type";
declare const easeLinear: Easing;
export { easeLinear as linear };
