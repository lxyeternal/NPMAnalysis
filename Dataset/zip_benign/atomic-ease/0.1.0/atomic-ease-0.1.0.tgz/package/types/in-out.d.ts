import type { Easing } from "./type";
declare const easeInOutQuad: Easing;
declare const easeInOutCubic: Easing;
declare const easeInOutQuart: Easing;
declare const easeInOutExpo: Easing;
/** @returns New "easeInOutBack" function with `coefficient`. */
declare const createEaseInOutBack: (coefficient: number) => Easing;
/** "easeInOutBack" with coefficient `1.70158`. */
declare const easeInOutBack: Easing;
export {
  easeInOutQuad as quad,
  easeInOutCubic as cubic,
  easeInOutQuart as quart,
  easeInOutExpo as expo,
  easeInOutBack as back,
  createEaseInOutBack as createBack,
};
