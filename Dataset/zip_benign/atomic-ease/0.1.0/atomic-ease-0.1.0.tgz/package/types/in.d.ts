import type { Easing } from "./type";
declare const easeInQuad: Easing;
declare const easeInCubic: Easing;
declare const easeInQuart: Easing;
declare const easeInExpo: Easing;
/** @returns New "easeInBack" function with `coefficient`. */
declare const createEaseInBack: (coefficient: number) => Easing;
/** "easeInBack" with coefficient `1.70158`. */
declare const easeInBack: Easing;
export {
  easeInQuad as quad,
  easeInCubic as cubic,
  easeInQuart as quart,
  easeInExpo as expo,
  easeInBack as back,
  createEaseInBack as createBack,
};
