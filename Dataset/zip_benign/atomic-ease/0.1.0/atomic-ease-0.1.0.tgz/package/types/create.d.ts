import type { Easing } from "./type";
/**
 * Creates a new easing function by clipping and normalizing a specific range
 * from any 1-dimension numeric function.
 */
declare const createEasing: (
  func: (x: number) => number,
  xRange: {
    start: number;
    end: number;
  },
  yRange: {
    start: number;
    end: number;
  }
) => Easing;
/**
 * Concatenates two easing functions without normalization.
 * @param thresholdRatio - Defaults to `0.5`.
 * @returns New easing function.
 */
declare const concatenateEasing: (
  easingA: Easing,
  easingB: Easing,
  thresholdRatio?: number
) => Easing;
/**
 * Integrates two easing functions.
 * Both provided functions will be normalized depending on `thresholdRatio`.
 * @param thresholdRatio - Defaults to `0.5`.
 * @returns New easing function.
 */
declare const integrateEasing: (
  easingA: Easing,
  easingB: Easing,
  thresholdRatio?: number
) => Easing;
export {
  createEasing as from,
  concatenateEasing as concatenate,
  integrateEasing as integrate,
};
