export declare const secondPower: (x: number) => number;
export declare const thirdPower: (x: number) => number;
export declare const fourthPower: (x: number) => number;
