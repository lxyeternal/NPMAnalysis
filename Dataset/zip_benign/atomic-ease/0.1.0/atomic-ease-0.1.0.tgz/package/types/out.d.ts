import type { Easing } from "./type";
declare const easeOutQuad: Easing;
declare const easeOutCubic: Easing;
declare const easeOutQuart: Easing;
declare const easeOutExpo: Easing;
/** @returns New "easeOutBack" function with `coefficient`. */
declare const createEaseOutBack: (coefficient: number) => Easing;
/** "easeOutBack" with coefficient `1.70158`. */
declare const easeOutBack: Easing;
export {
  easeOutQuad as quad,
  easeOutCubic as cubic,
  easeOutQuart as quart,
  easeOutExpo as expo,
  easeOutBack as back,
  createEaseOutBack as createBack,
};
