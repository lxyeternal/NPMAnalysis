import type { Easing } from "./type";
declare const easeOutInQuad: Easing;
declare const easeOutInCubic: Easing;
declare const easeOutInQuart: Easing;
declare const easeOutInExpo: Easing;
/** @returns New "easeOutInBack" function with `coefficient`. */
declare const createEaseOutInBack: (coefficient: number) => Easing;
/** "easeOutInBack" with coefficient `1.70158`. */
declare const easeOutInBack: Easing;
export {
  easeOutInQuad as quad,
  easeOutInCubic as cubic,
  easeOutInQuart as quart,
  easeOutInExpo as expo,
  easeOutInBack as back,
  createEaseOutInBack as createBack,
};
