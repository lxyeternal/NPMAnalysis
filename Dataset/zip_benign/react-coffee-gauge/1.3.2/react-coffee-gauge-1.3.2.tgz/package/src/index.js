/**
* MIT License
*
* Copyright (c) 2019 
* 
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be included in all
* copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*/
/**
* MIT License
*
* Copyright (c) 2019 Emadema.com SRL
* 
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
* 
* The above copyright notice and this permission notice shall be included in all
* copies or substantial portions of the Software.
* 
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*/
import React from 'react';
class ReactCoffeeGauge extends React.Component {

    constructor(props) {
        super(props);

        var opts = {
          angle: 0, // The span of the gauge arc
          lineWidth: 0, // The line thickness
          radiusScale: 1, // Relative radius
          pointer: {
            length: 0.5, // // Relative to gauge radius
            strokeWidth: 0.024, // The thickness
            color: '#000000' // Fill color
          },
          renderTicks: {
              divisions: 5,
              divWidth: 0.8,
              divLength: 0.7,
              divColor: '#333333',
              subDivisions: 3,
              subLength: 0.5,
              subWidth: 0.6,
              subColor: '#666666'
          },
          lineWidth: 0.15, 
          limitMax: false,     // If false, max value increases automatically if value > maxValue
          limitMin: false,     // If true, the min value of the gauge will be fixed
          colorStart: '#6FADCF',   // Colors
          colorStop: '#8FC0DA',    // just experiment with them
          strokeColor: [[0.0, "#a9d70b" ], [0.50, "#f9c802"], [1.0, "#ff0000"]],  // to see which ones work best for you
          generateGradient: true,
          highDpiSupport: true,     // High resolution support
        };

        this.state = {
            value: (this.props.value?this.props.value:0),
            min: (this.props.min?this.props.min:0),
            max: (this.props.max?this.props.max:1000000000000),
            opts: (this.props.opts?this.props.opts:opts),
        };
    }

    componentWillReceiveProps(props){
        if( 
            (props.value && this.state.value != props.value) ||
            (props.max && this.state.max != props.max) ||
            (props.min && this.state.min != props.min)
        ){
            this.state.value = props.value;
            this.state.min= props.min;
            this.state.max= props.max;
            this.state.opts= (props.opts?props.opts:this.state.opts);

            this.setState({
                value: (props.value?props.value:this.state.value),
                min: (props.min?props.min:this.state.min),
                max: (props.max?props.max:this.state.max),
                opts: (props.opts?props.opts:this.state.opts),
            });
            this.loadGauge(this.state);
        }
    }

    componentDidMount() {
        this.loadGauge(this.props);
    }

    loadGauge(elem) {

        var value= elem.value;
        var min = elem.min;
        var max = elem.max;
        var opts = elem.opts;

        const script = document.createElement("script");
        script.src = "https://bernii.github.io/gauge.js/dist/gauge.min.js";
        script.async = true;
        document.body.appendChild(script);

        script.onload = () => {

            var target = document.getElementById('canvas-gauge-coffee'); // your canvas element
            var gauge = new Gauge(target).setOptions(opts); // create sexy gauge!
            //var gauge = new Gauge(target).setOptions(opts); // create sexy gauge!
            gauge.maxValue = max; // set max gauge value
            gauge.setMinValue(parseInt(min));  // Prefer setter over gauge.minValue = 0
            gauge.animationSpeed = 32; // set animation speed (32 is default value)
            gauge.set(parseInt(value)); // set actual value
        }
    }

    render() {
        const divStyle= {
            //right: 'blue',
            maxWidth: "100%"
        };
        return (
            <div className="gauge-coffee" style={divStyle}>
                <canvas id="canvas-gauge-coffee" style={divStyle}></canvas>
                <div><span style={{ float: 'left' }} className="left-elem"><b>Specific</b></span><span className="right-elem" style={{ float: 'right' }}><b>Large</b></span></div>
            </div>
        );
    }

}

export default ReactCoffeeGauge;
