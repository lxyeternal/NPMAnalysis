dchart-bar-with-line

符合dchart规范的折线柱状图

### 安装

```
npm install dchart-bar-with-line
```

### 用法
```
var Bar = require('dchart-bar-with-line');
var bar = new Bar(container, {
  xaxis: {
    padding: [0.9, 0.4],      //柱状子间的间距[innerPadding, outerPadding],默认[0.9, 0.4]
    groupPadding: [0.4, 0],   //组内柱子间的间距
    dy: 12,                   //位移
  },
  yaxis: {
    min: null                 //默认null会自动计算数据中的最小值
    max: null                 //默认null会自动计算数据中的最大值
  },
  line: {
    'circle-radius': 5        //折线上圆点的半径
  }
});
bar.render([
        {"x": "山东", "y": 100},
        {"x": "山西", "y": 52},
        {"x": "河北", "y": 49}
      ]);
```
