'use strict';
// var Bar = require('../bar-with-bg');
var Bar = require('dchart-bar-with-bg');
var d3 = require('d3');
// var _ = require('../../../util');
var _ = require('dchart-core/util');
const { animationController, SERIES_INDEX, AXIS_NAME, interactionHandlerSelector } = _;

function BarWithLine(container, options) {
  var opt = {
    margin: {top: 0, right: 0, bottom: 0, left: 0},
    xaxis: {
      'show': true,
      'type': 'category',
      'orient': 'bottom',
      'font-size': 12,
      'dy': 10,
      'color': '#fff',
      'padding': [0.6, 0.3],
      'assist-line': false
    },
    yaxis: {
      'show': true,
      'key': 'y',
      'orient': 'left',
      'font-size': 12,
      'dy': 10,
      'color': '#fff',
      'ticks': 5,
      'assist-line': false
    },
    zaxis: {
      'show': true,
      'key': 'z',
      'orient': 'right',
      'font-size': 12,
      'dy': 10,
      'color': '#fff',
      'ticks': 5,
      'assist-line': false
    },
    color: {
      style: 'single',
      value: '#79cbe8'
    },
    bg: {
      texture: null,
      color: {

      },
      show: true
    },
    line: {
      'color': {
        style: 'single',
        value: '#fff'
      },
      'style': 'solid',
      'point': {
        radius: 5,
        show: true,
        color: {
          style: 'single',
          value: '#fff'
        }
      },
      'stroke-width': 1,
      'dashed': '4 4'
    },
    label: {
      dy: '-1em'
    },
    series: []
  };
  opt = _.deepMerge(opt, options);
  Bar.call(this, container, opt);
}

BarWithLine = Bar.extend(BarWithLine, {
  data: function (data) {
    if (!data) return this._data;
    var opt = this.options;
    var ykey = opt.yaxis.key;
    var zkey = opt.zaxis.key;
    data.forEach(function (obj) {
      if (!_.isArray(obj[ykey])) {
        obj[ykey] = [obj[ykey]];
      }
      if (!_.isArray(obj[zkey])) {
        obj[zkey] = [obj[zkey]];
      }
      obj[ykey] = _.map(obj[ykey], function (n) {
        if (typeof n === 'string') {
          n = _.toNumber(n);
        }
        if (!n && !opt.hiddenEmptyData) {
          n = 0;
        }
        return n;
      });
      obj[zkey] = _.map(obj[zkey], function (n) {
        if (typeof n === 'string') {
          n = _.toNumber(n);
        }
        if (!n && !opt.hiddenEmptyData) {
          n = 0;
        }
        return n;
      });
    });
    this._data = data;
  },
  beforeRender: function () {
    Bar.prototype.beforeRender.call(this);
    this.dealColor(this.options, 'line.color');
    this.dealColor(this.options, 'line.point.color');
    var opt = this.options;
    var self = this;
    opt.series.length && opt.series.forEach(function (n, i) {
      self.dealColor(n, 'line.color');
      self.dealColor(n, 'line.point.color');
    });
  },
  updateBeforeRender: function () {
    Bar.prototype.updateBeforeRender.call(this);
    BarWithLine.prototype.beforeRender.call(this);
  },
  trans: function (d) {
    var opt = this.options;
    var data = [];
    var ykey = opt.yaxis.key;
    var xkey = opt.xaxis.key;
    var zkey = opt.zaxis.key;
    _.map(d[ykey], function (n) {
      var tmp = {};
      tmp[xkey] = d[xkey];
      tmp[ykey] = n;
      tmp[zkey] = d[zkey];
      data.push(tmp);
    });
    return data;
  },
  calLineData: function (d, index) {
    var opt = this.options;
    var xkey = opt.xaxis.key;
    var zkey = opt.zaxis.key;

    var result = [];
    d.length && d.forEach(function (n, i) {
      if (_.isNumber(+n[zkey][index].value)) {
        var tmp = {};
        tmp[xkey] = n[xkey];
        tmp[zkey] = +n[zkey][index].value;
        result.push(tmp);
      }
    });
    
    return result;
  },
  changeSeries: function () {
    var opt = this.options;
    var x = this.getComs('axis', 'xaxis').getX();
    var xkey = opt.xaxis.key;
    var z, zkey;
    var data = this._data;
    var zAxis = this.getComs('axis', 'zaxis');
    z = zAxis.getX();
    zkey = opt.zaxis.key;
    var len = _.maxBy(data, function (n) {
      return n[zkey].length;
    })[zkey].length;
    var self = this;
    var transform =  this.series.attr('transform');
    var lineG = this.lines.attr({transform: transform});
    this.labels.attr('transform', transform);

    var updateSerieAttr = function (d, index) {
      var line = this;
      var area = d3.svg
        .line().x(function (d) {
          if (opt.xaxis.type === 'time' && typeof d[xkey] === 'string') {
            return x(new Date(d[xkey])) + (x.rangeBand ?  x.rangeBand() / 2 : 0);
          }
          return x(d[xkey]) +
            (x.rangeBand ?  x.rangeBand() / 2 : 0);
        })
        .y(function (d) {
          return z(_.isNumber(d[zkey]) ? d[zkey] : zAxis.getMin());
        });

      var attr = opt.series[index] && opt.series[index].line;
      area.interpolate(attr && attr.interpolate || opt.interpolate || '');

       // clipPath  
       line.attr('clip-path', 'url(#' + self.clipPathId + ')');
       var {width, height} = opt;
       var resetFullClipPath = () => self.clipPath.attr('d', _.getRectPath(0, 0, width, height));
       
       var animationHandler = ({duration, ease}) => {
         if (opt.isFirst || !opt.animationUpdateFromPrevious) {
           line.attr({d: area});
           self.clipPath
           .transition()
           .duration(duration)
           .ease(ease)
           .attrTween('d', function () {
             var interpolator = d3.interpolate(0, width);
             return (t) => _.getRectPath(0, 0, interpolator(t), height);
           })
         } else {
           resetFullClipPath();
           line
           .transition()
           .duration(duration)
           .ease(ease)
           .attr('d', area);
         }
       }
 
       var notAnimationHandler = function () {
         resetFullClipPath();
         line.attr('d', area);
       }
       self.addResumeTween(notAnimationHandler);
       animationController({animationHandler, notAnimationHandler, options: opt});
 
      line.style({
        'stroke': function () {
          return attr && attr.color && attr.color.res || (opt.line.color && opt.line.color.res);
        },
        'stroke-width': function () {
          return attr && attr['stroke-width'] || opt.line['stroke-width'];
        },
        'stroke-dasharray': function () {
          return attr && attr.style === 'dashed' && (attr.dashed || 'none') || (opt.line.style === 'dashed' && opt.line.dashed || 'none');
        },
        'fill': 'none',
        'display': attr && typeof attr.show === 'boolean' ? attr.show && 'block' || 'none' : opt.line.show && 'block' || 'none'
      });
    };

    var updateLabelAttr = function (d, i, index) {
      const v = +(d[zkey][i].hasOwnProperty('value') ? d[zkey][i].value :  d[zkey][i]);

      if (d && (_.isNumber(v))) {
        var attr = opt.series[i] && opt.series[i].line && opt.series[i].line.label;
        this.attr({
          x: function () {
            return x(opt.xaxis.type === 'time' ? new Date(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand() / 2 : 0);
          },
          y: z(v),
          dx: function () {
            return attr && attr.dx || opt.label.dx || 0;
          },
          dy: function () {
            return attr && attr.dy || opt.label.dy || 0;
          },
        }).html(function () {
          var format = attr && attr.format || opt.label.format || null;
          return format ? format.call(self, d, i) : v;
        }).style({
          'text-anchor': function () {
            return attr && attr.anchor || opt.label.anchor || 'middle';
          },
          'display': function () {
            var show = (attr && typeof attr.show === 'boolean') ? attr.show : (typeof opt.label.show === 'boolean' ? opt.label.show : false);
            return show && _.isNumber(v) && 'block' || 'none';
          },
          'font-size': function () {
            return (attr && attr['fontSize'] || opt.label['fontSize'] || '10') + 'px';
          },
          'font-weight': function () {
            return attr && attr['fontWeight'] || opt.label['fontWeight'] || 'normal';
          },
          'fill': function () {
            return attr && attr.color || opt.label.color;
          },
          'stroke': function () {
            return opt.label.strokeWidth && attr && attr.color || opt.label.color || '#fff';
          },
          'stroke-width': opt.label.strokeWidth
        });
      }
    };

    var labels = this.labels.selectAll('.series-group').data(data);
    this.labelsEnter = labels.enter()
      .append('g')
      .attr('class', 'series-group');
    this.labelsExit = labels.exit().remove();

    for (var i = 0; i < len; i++) {
      var lineData = this.calLineData(data, i);

      var serie = lineG.select('.serie' + (i + 1))[0][0] ? lineG.select('.serie' + (i + 1)).datum(lineData) : lineG.append('path').datum(lineData)
        .attr({
          class: 'serie serie' + (i + 1),
          d: d3.svg.line().x(function (d) {
            if (opt.xaxis.type === 'time' && typeof d[xkey] === 'string') {
              return x(new Date(d[xkey])) + (x.rangeBand ?  x.rangeBand() / 2 : 0);
            }
            return x(d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand() / 2 : 0);
          })
            .y(z(zAxis.getMin()))
        });
      updateSerieAttr.call(serie, lineData, i);

      labels.each(function (d, index) {
        var that = d3.select(this);
        var label = that.select('.serie-label-' + (i + 1))[0][0] ? that.select('.serie-label-' + (i + 1)) :
          that.append('text').attr('class', 'serie-label serie-label-' + (i + 1));
        updateLabelAttr.call(label, data[index], i, index);
      });
    }
    lineG.selectAll('.serie.serie' + len + ' ~ .serie').remove();
  },
  renderSeries: function () {
    Bar.prototype.renderSeries.call(this);
    this.lines = this.svg.append('g').attr({class: 'line-g'});
    this.scatterplots = this.svg.append('g').attr({class: 'scatterplot-g interaction-g'});
    this.labels = this.svg.append('g').attr('class', 'series-labels');
    this.changeSeries();
  },
  updateSeries: function () {
    Bar.prototype.updateSeries.call(this);
    this.changeSeries();
  },
  afterRender: function () {
    Bar.prototype.afterRender.call(this);
    this.series.selectAll('.series-group')
    .selectAll('.serie-single')
    .each(function (d, i) {
      d3.select(this).selectAll('rect.serie')
      .attr('class', interactionHandlerSelector + ' serie serie' + (1 + i))
      .attr(SERIES_INDEX, i);
    });
    var opt = this.options;
    var x = this.getComs('axis', 'xaxis').getX();
    var zAxis = this.getComs('axis', 'zaxis');
    var z = zAxis.getX();
    var xkey = opt.xaxis.key;
    var zkey = opt.zaxis.key;
    var data = this.data();
    var self = this;

    var len = _.maxBy(data, function (n) {
      return n[zkey].length;
    })[zkey].length;
    var transform =  this.series.attr('transform');
    var series = this.scatterplots.attr('transform', transform);
    var barSeries = this.series.selectAll('.serie-single');

    var updateSeriesAttr = function (d, i, seriesIndex) {
      var that = d3.select(this);
      const zValue = d[zkey][seriesIndex].value;
      var cy = z(_.isNumber(+zValue) ? +zValue : zAxis.getMin());
      if (opt.animation) {
        if (opt.isFirst) {
          that.attr({
            cx: function (d) {
              return x(opt.xaxis.type === 'time' ? new Date(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand() / 2 : 0);
            },
            cy: cy,
            r: 0
          });
        }
      }

      var cfg = opt.series[seriesIndex] && opt.series[seriesIndex].line && opt.series[seriesIndex].line.point;
      (_.isNumber(+zValue)) && that.attr({
        cx: function () {
          return x(opt.xaxis.type === 'time' ? new Date(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand() / 2 : 0);
        },
        cy: cy,
        r: cfg && cfg.radius || (opt.line.point && opt.line.point.radius) || 4
      }) || that.attr({
        cx: function () {
          return x(opt.xaxis.type === 'time' ? new Date(d[xkey]) : d[xkey]) + (opt.xaxis.type === 'category' ? x.rangeBand() / 2 : 0);
        },
        cy: z(zAxis.getMin()),
        r: 0
      });
      that.style({
        'fill': function () {
          return cfg && cfg.color && cfg.color.res || (opt.line.point && opt.line.point.color && opt.line.point.color.res) || 'none';
        },
        'stroke': function () {
          return cfg && cfg.frameColor || (opt.line.point && opt.line.point.frameColor) || 'none';
        },
        'stroke-width': function () {
          return cfg && cfg.frameColorWidth || (opt.line.point && opt.line.point.frameColorWidth) || 0;
        },
        'display': cfg && typeof cfg.show === 'boolean' ? cfg.show && 'block' || 'none' : (opt.line.point && opt.line.point.show && 'block') || 'none'
      });
    };

    series = series.selectAll('.series-group').data(data);

    this.enterSeries = series.enter()
      .append('g')
      .attr('class', 'series-group');

    for (var i = 0; i < len; i++) {
      var show = (opt.series[i] && opt.series[i].bar && typeof opt.series[i].bar.show === 'boolean') ? opt.series[i].bar.show : true;
      barSeries.selectAll('.serie' + (i + 1)).style({
        'display': show ? 'block' : 'none'
      })
      this.enterSeries.selectAll('.serie circle').append('circle')
        .attr('class', interactionHandlerSelector + ' serie-single serie serie' + (i + 1))
        .attr(SERIES_INDEX, i)
        .attr(AXIS_NAME, 'z')
        .each(function (d, index) {
          updateSeriesAttr.call(this, d, index, i);
        });
      series.each(function (d, index) {
        var that = d3.select(this);
        var node = that.select('.serie' + (i + 1))[0][0] || (that.append('circle')
          .attr('class', interactionHandlerSelector + ' serie-single serie serie' + (i + 1))
          .attr(SERIES_INDEX, i)
          .attr(AXIS_NAME, 'z')
          )[0][0];
        node && updateSeriesAttr.call(node, d, index, i);
      });
    }
    series.selectAll('.serie.serie' + len + ' ~ .serie').remove();
    series.exit().remove();
    this.svg[0][0].appendChild(this.lines[0][0]);
    this.svg[0][0].appendChild(this.scatterplots[0][0]);
    this.svg[0][0].appendChild(this.labels[0][0]);
    var opt = this.options;
    var tooltip = this.getComs('tooltip', 'tooltip');
    tooltip && tooltip.updateEvent(this.getSelector.bind(this));
    if (opt.tooltip && !opt.tooltip.show) {
      tooltip && tooltip.clearListeners();
    }
  },
  updateAfterRender: function () {
    Bar.prototype.updateAfterRender.call(this);
    BarWithLine.prototype.afterRender.call(this);
  },
  getSelector () {
    return this.svg.selectAll('.series, .scatterplot-g').selectAll('.series-group').selectAll('.serie-single');
  },
  _beforeRender: function () {
    this.emit('start.beforerender');
    this.beforeRender();
    this.emit('before.render');
    var opt = this.options;
    if (opt.xaxis) {
      opt.xaxis = _.deepMerge(opt.xaxisDefault, opt.xaxis);
      var xaxis = this.renderXAxis('xaxis', this.svg[0][0], opt.xaxis);
    }
    if (opt.yaxis) {
      opt.yaxis = _.deepMerge(opt.yaxisDefault, opt.yaxis);
      var yaxis = this.renderYAxis('yaxis', this.svg[0][0], opt.yaxis);
    }
    if (opt.zaxis) {
      opt.zaxis = _.deepMerge(opt.yaxisDefault, opt.zaxis);
      var zaxis = this.renderAxis('zaxis', this.svg[0][0], opt.zaxis);
    }

    if (opt.margin.containLabel) {
      xaxis.options.__height = xaxis.el[0][0].getBBox().height - (opt.xaxis.net && xaxis.el.selectAll('.tick line')[0].length > 1 && opt.innerHeight || 0);
      yaxis.options.__width = yaxis.el[0][0].getBBox().width - (opt.yaxis.net && yaxis.el.selectAll('.tick line')[0].length > 1 && opt.innerWidth || 0);
      zaxis.options.__width = zaxis.el[0][0].getBBox().width - (opt.zaxis.net && zaxis.el.selectAll('.tick line')[0].length > 1 && opt.innerWidth || 0);
      var height = xaxis.options.__height + opt.xaxis.dy;
      var yWidth = yaxis.options.__width + opt.yaxis.dy;
      var zWidth = zaxis.options.__width + opt.zaxis.dy;
      opt._innerWidth = opt.innerWidth;
      opt._innerHeight = opt.innerHeight;
      opt.innerWidth -= (yWidth + zWidth);
      opt.innerHeight -= height;
      xaxis.update(null, _.deepMerge(opt.xaxis, {innerHeight: opt.innerHeight, innerWidth: opt.innerWidth}));
      yaxis.update(null, _.deepMerge(opt.yaxis, {innerHeight: opt.innerHeight, innerWidth: opt.innerWidth}));
      zaxis.update(null, _.deepMerge(opt.zaxis, {innerHeight: opt.innerHeight, innerWidth: opt.innerWidth}));
      if (opt.yaxis.orient === 'left') {
        yaxis.el.attr('transform', 'translate(' + yWidth + ',0)');
        zaxis.el.attr('transform', 'translate(' + (opt.innerWidth + yWidth) + ',0)');
        if (opt.xaxis.orient === 'bottom') {
          xaxis.el.attr('transform', 'translate(' + yWidth + ', ' + opt.innerHeight + ')');
          this.series.attr('transform', 'translate(' + yWidth + ', 0)');
        } else if (opt.xaxis.orient === 'top') {
          xaxis.el.attr('transform', 'translate(' + yWidth + ', 0)');
          this.series.attr('transform', 'translate(' + yWidth + ', ' + height + ')');
        }
      } else if (opt.yaxis.orient === 'right') {
        if (opt.xaxis.orient === 'bottom') {
          xaxis.el.attr('transform', 'translate(0, ' + opt.innerHeight + ')');
        } else if (opt.xaxis.orient === 'top') {
          this.series.attr('transform', 'translate(0, ' + height + ')');
        }
      }
    }
    if (!this.clipPathId) {
      this.clipPathId = 'ClipPath' + _.getUUID();
      this.clipPath = this.svg.append('defs')
        .append('clipPath')
        .attr('id', this.clipPathId)
        .append('path')
        .attr('fill', 'none')
        .attr('stroke', 'none');
    }
    if (opt.tooltip) {
      this.renderTooltip('tooltip', this.el[0][0], opt.tooltip);
    }
    this.emit('end.beforerender');
  },
  _updateBeforeRender: function () {
    this.updateBeforeRender();
    var opt = this.options;
    var tmp = {innerWidth: opt.innerWidth, innerHeight: opt.innerHeight};
    if (opt.xaxis) {
      var xaxis = this.getComs('axis', 'xaxis');
      xaxis.update(this._data, _.deepMerge(tmp, opt.xaxis));
    }
    if (opt.yaxis) {
      var yaxis = this.getComs('axis', 'yaxis');
      yaxis.update(this._data, _.deepMerge(tmp, opt.yaxis));
    }
    if (opt.zaxis) {
      var zaxis = this.getComs('axis', 'zaxis');
      zaxis.update(this._data, _.deepMerge(tmp, opt.zaxis));
    }

    if (opt.margin.containLabel) {
      xaxis.options.__height = xaxis.el[0][0].getBBox().height - (opt.xaxis.net && xaxis.el.selectAll('.tick line')[0].length > 1 && opt.innerHeight || 0);
      yaxis.options.__width = yaxis.el[0][0].getBBox().width - (opt.yaxis.net && yaxis.el.selectAll('.tick line')[0].length > 1 && opt.innerWidth || 0);
      zaxis.options.__width = zaxis.el[0][0].getBBox().width - (opt.zaxis.net && zaxis.el.selectAll('.tick line')[0].length > 1 && opt.innerWidth || 0);
      var height = xaxis.options.__height + opt.xaxis.dy;
      var yWidth = yaxis.options.__width + opt.yaxis.dy;
      var zWidth = zaxis.options.__width + opt.zaxis.dy;
      opt._innerWidth = opt.innerWidth;
      opt._innerHeight = opt.innerHeight;
      opt.innerWidth -= (yWidth + zWidth);
      opt.innerHeight -= height;
      xaxis.update(null, _.deepMerge(opt.xaxis, {innerHeight: opt.innerHeight, innerWidth: opt.innerWidth}));
      yaxis.update(null, _.deepMerge(opt.yaxis, {innerHeight: opt.innerHeight, innerWidth: opt.innerWidth}));
      zaxis.update(null, _.deepMerge(opt.zaxis, {innerHeight: opt.innerHeight, innerWidth: opt.innerWidth}));
      if (opt.yaxis.orient === 'left') {
        yaxis.el.attr('transform', 'translate(' + yWidth + ',0)');
        zaxis.el.attr('transform', 'translate(' + (opt.innerWidth + yWidth) + ',0)');
        if (opt.xaxis.orient === 'bottom') {
          xaxis.el.attr('transform', 'translate(' + yWidth + ', ' + opt.innerHeight + ')');
          this.series.attr('transform', 'translate(' + yWidth + ', 0)');
        } else if (opt.xaxis.orient === 'top') {
          xaxis.el.attr('transform', 'translate(' + yWidth + ', 0)');
          this.series.attr('transform', 'translate(' + yWidth + ', ' + height + ')');
        }
      } else if (opt.yaxis.orient === 'right') {
        if (opt.xaxis.orient === 'bottom') {
          xaxis.el.attr('transform', 'translate(0, ' + opt.innerHeight + ')');
        } else if (opt.xaxis.orient === 'top') {
          this.series.attr('transform', 'translate(0, ' + height + ')');
        }
      }
    }
  }
});

module.exports = BarWithLine;
