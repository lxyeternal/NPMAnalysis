## changelog

### 0.0.2

*2021-06-08*

#### Optimization

 - delete lib/assets directory gift image

### 0.0.1

*2021-06-08*

#### New features

 - add lottery component