# NodeJS and JavaScript SDK changelog

## Initial release
### Added
- Login method
- Publish method
- Subscribe method
- Refresh token method

## [0.1.5] - 2018-09-17
### Fixed
- Refresh token period set to 1 minute
- Publish and refresh methods include Authorization header

### Changed
- Enabled different callbacks for different subscriptions

### Removed
- Unsubscribe

## [0.2.0] - 2018-09-26
### Added
- Encrypt data on publish
- Decrypt data on subscribe

### Removed 
- npm unnecessary dependencies

## [0.2.1] - 2018-10-05
### Added
- Unsubscribe method

## [0.2.2] - 2018-10-10
### Changed
- SDK instance does not require any argument.

### Added 
- HTTPS connection

## [0.2.3] - 2018-10-15
### Changed
-Updated server URL

## [0.2.4] - 2018-11-08
### Added
- Set token method

## [0.3.0] - 2018-11-05
### Added
- Send Service Request method
- Subscribe to Service Request method
- Unsubscribe Service Request method
- Send Service Response method
- Subscribe to Service Response method
- Unsubscribe Service Response method

## [0.3.1] - 2018-11-27
### Changed
- Redefined unsubscribe datasource, service request and service response
- Disconnect socket returns error 410

## [0.3.2] - 2018-12-17
### Added
- Refresh token method

### Changed
- No auto refresh
- Instance option object argument

## [0.3.3] - 2019-02-22

### Changed
- Socket close on error to avoid useless clients

## [0.3.4] - 2019-02-27

### Changed
- Socket close on unsubscribe error
