### STAT GEN

 This app is intended to generate and maintain stats reports for Mixby applications
 A stat report is an object which contains relevant stat totals for a given beacon or place
 It requires a loopback app with a mongo database and the current mixby data model

 It typically looks like this:

    Stat = {
       beaconId: [objectId] id of the beacon this stat report relates to
       endDate: [date] end of day in utc relative to the location of the beacon (or the beacon's parent place)
        popularityIndex: [float] number indicating popularity of the beacon as a whole (measure of interactions + visits + time spent etc
        totalVisits: [int] how many times the beacon was entered
        totalUniqueVisits: [int] how many people visited the beacon
        averageTimeSpentInMinutes: [int] average minutes spent at the beacon
        totalArtifactsCollected: [int] total number of artifacts collected from this beacon
        totalArtifactsViewed: [int] total number of view stats for artifacts
        averageTimeSpentViewingArtifactsInMinutes: [int] average minutes spent viewing artifacts
        totalChallengesCollected: [int] total number of artifacts collected from this beacon
        totalChallengesViewed: [int] total number of view stats for artifacts
        totalChallengesCompleted: [int] total number of view stats for artifacts
        averageTimeSpentViewingChallengesInMinutes: [int] average minutes spent viewing artifacts
        totalExtrasCollected: [int] total number of artifacts collected from this beacon
        totalExtrasViewed: [int] total number of view stats for artifacts
        averageTimeSpentViewingArtifactsInMinutes: [int] average minutes spent viewing artifacts
        beaconsCameFrom: [array][obj] {beaconName: str, beaconId: objectId, count: int}
        beaconsWentTo: [array][obj] {beaconName: str, beaconId: objectId, count: int}
        mostPopularArtifacts: [array][obj] {artifactId: objectId, views: int, collections: int}
        mostPopularFunFacts: [array][obj] {funFactId: objectId, views: int, collections: int}
        mostPopularQuizzes: [array][obj] {quizId: objectId, views: int, collections: int, completions: int}

    }


### How To:

    npm install mxby-statgenerator
    (and all loopback server requirements)

    var app = require('../server')
    var SG = require('mxby-statgenerator')
    var sg = new SG(app)
    sg.generateDailyReport(beacon, Date, function(err, statsReport){
      statsReport is a statReport Object from the database
    })

### TODO:

* add methods to support reports for individual items - these methods should add stats to the object and save it to the database
* a beacon should only have 1 stat report per day -- the generator needs to check this first -- their should be a flag to set to override this
* helper methods to support retrieving beacon stats for a given time period -- though the idea is that you can do this with just a generic StatsReport query
