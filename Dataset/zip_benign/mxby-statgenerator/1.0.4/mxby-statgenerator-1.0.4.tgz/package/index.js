var Agenda, DailyStatReport, ItemReport, StatGen, _, async, moment, promiseWrapperForCollectionStatGen, promiseWrapperForStatGen,
  bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; },
  hasProp = {}.hasOwnProperty;

_ = require('lodash-node');

async = require('async');

moment = require('moment-timezone');

Agenda = require('agenda');


/*
*************************************
* This app is intended to generate and maintain stats reports for Mixby applications
* A stat report is an object which contains relevant stat totals for a given beacon or place
* It typically looks like this:
*
* Stat = {
*   beaconId: [objectId] id of the beacon this stat report relates to
*   endDate: [date] end of day in utc relative to the location of the beacon (or the beacon's parent place)
*   popularityIndex: [float] number indicating popularity of the beacon as a whole (measure of interactions + visits + time spent etc
*
*   totalVisits: [int] how many times the beacon was entered
*   totalUniqueVisits: [int] how many people visited the beacon
*   averageTimeSpentInMinutes: [int] average minutes spent at the beacon
*
*   totalArtifactsCollected: [int] total number of artifacts collected from this beacon
*   totalArtifactsViewed: [int] total number of view stats for artifacts
*   averageTimeSpentViewingArtifactsInMinutes: [int] average minutes spent viewing artifacts
*
*   totalChallengesCollected: [int] total number of artifacts collected from this beacon
*   totalChallengesViewed: [int] total number of view stats for artifacts
*   totalChallengesCompleted: [int] total number of view stats for artifacts
*   averageTimeSpentViewingChallengesInMinutes: [int] average minutes spent viewing artifacts
*
*   totalExtrasCollected: [int] total number of artifacts collected from this beacon
*   totalExtrasViewed: [int] total number of view stats for artifacts
*   averageTimeSpentViewingArtifactsInMinutes: [int] average minutes spent viewing artifacts
*
*   beaconsCameFrom: [array][obj] {beaconName: str, beaconId: objectId, count: int}
*   beaconsWentTo: [array][obj] {beaconName: str, beaconId: objectId, count: int}
*
*   mostPopularArtifacts: [array][obj] {artifactId: objectId, views: int, collections: int}
*   mostPopularFunFacts: [array][obj] {funFactId: objectId, views: int, collections: int}
*   mostPopularQuizzes: [array][obj] {quizId: objectId, views: int, collections: int, completions: int}
*
* }
*
* *************************************
 */

String.prototype.capitalize = function() {
  return this.charAt(0).toUpperCase() + this.slice(1);
};

DailyStatReport = (function() {
  function DailyStatReport(beacon1, between1, app) {
    this.beacon = beacon1;
    this.between = between1;
    this.app = app;
    this.fetchAllTimeStatsForChildItems = bind(this.fetchAllTimeStatsForChildItems, this);
    this.getPopularityIndex = bind(this.getPopularityIndex, this);
    this.getVisitorStats = bind(this.getVisitorStats, this);
    this.getTrafficStats = bind(this.getTrafficStats, this);
    this.cameFromStat = bind(this.cameFromStat, this);
    this.wentToStat = bind(this.wentToStat, this);
    this.getCollectionStats = bind(this.getCollectionStats, this);
    this.averageTimeSpent = bind(this.averageTimeSpent, this);
    this.returnStats = bind(this.returnStats, this);
    this.beaconId = this.beacon.id;
    this.endDate = this.between[1];
    this.date = moment(this.endDate).format("MMM Do YYYY");
    this.month = moment(this.endDate).format("MMM-YY");
    this.popularityIndex = 0;
    this.totalVisits = 0;
    this.totalUniqueVisits = 0;
    this.averageTimeSpentInMinutes = 0;
    this.totalArtifactsCollected = 0;
    this.totalArtifactsViewed = 0;
    this.averageTimeSpentViewingArtifactsInMinutes = 0;
    this.totalFunFactsCollected = 0;
    this.totalFunFactsViewed = 0;
    this.averageTimeSpentViewingFunFactsInMinutes = 0;
    this.totalQuizzesCollected = 0;
    this.totalQuizzesViewed = 0;
    this.averageTimeSpentViewingQuizzesInMinutes = 0;
    this.beaconsCameFrom = [];
    this.beaconsWentTo = [];
    this.mostPopularArtifacts = [];
    this.mostPopularQuizzes = [];
    this.mostPopularFunFacts = [];
  }

  DailyStatReport.prototype.returnStats = function() {
    var key, prop, props;
    props = {};
    for (key in this) {
      if (!hasProp.call(this, key)) continue;
      prop = this[key];
      if (!(prop instanceof Function) && key !== "beacon") {
        props[key] = this[key];
      }
    }
    return props;
  };

  DailyStatReport.prototype.averageTimeSpent = function(arrayOfStats) {
    var i, len, stat, timespent;
    timespent = 0;
    if (!arrayOfStats || arrayOfStats.length === 0) {
      return 0;
    } else {
      for (i = 0, len = arrayOfStats.length; i < len; i++) {
        stat = arrayOfStats[i];
        if (!stat.stopTime) {
          stat.stopTime = stat.timestamp;
        }
        timespent += new Date(stat.stopTime).getTime() - new Date(stat.timestamp).getTime();
      }
      return (timespent / arrayOfStats.length) / 1000 / 60;
    }
  };

  DailyStatReport.prototype.getCollectionStats = function(collectionName, foreignKey, item) {
    return (function(_this) {
      return function(cb) {
        var collection, i, ids, len, query, statReportAverageTimeKey, statReportCollectedKey, statReportViewKey;
        collection = _this.beacon.__data[collectionName];
        if (!collection) {
          cb(null);
        } else {
          ids = [];
          for (i = 0, len = collection.length; i < len; i++) {
            item = collection[i];
            ids.push(item.id.toString());
          }
          statReportViewKey = "total" + (collectionName.capitalize()) + "Viewed";
          statReportCollectedKey = "total" + (collectionName.capitalize()) + "Collected";
          statReportAverageTimeKey = "averageTimeSpentViewing" + (collectionName.capitalize()) + "InMinutes";
          query = {
            where: {
              key: {
                inq: ['viewed', 'addedToMemento']
              }
            },
            timestamp: {
              between: _this.between
            }
          };
          query.where[foreignKey] = {
            inq: ids
          };
          _this.app.models.Stat.find(query, function(err, stats) {
            var collections, j, len1, stat, views;
            views = [];
            collections = [];
            for (j = 0, len1 = stats.length; j < len1; j++) {
              stat = stats[j];
              if (stat.key === "viewed") {
                views.push(stat);
              }
              if (stat.key === "addedToMemento") {
                collections.push(stat);
              }
            }
            _this[statReportViewKey] += views ? views.length : 0;
            _this[statReportCollectedKey] += collections ? collections.length : 0;
            _this[statReportAverageTimeKey] += _this.averageTimeSpent(views);
            return cb(err);
          });
        }
      };
    })(this);
  };

  DailyStatReport.prototype.wentToStat = function(stat) {
    return (function(_this) {
      return function(cb) {
        var query;
        query = {
          where: {
            userId: stat.userId,
            beaconId: {
              neq: _this.beaconId
            },
            key: "enteredBeacon",
            timestamp: {
              gt: stat.timestamp
            }
          },
          limit: 1,
          include: ['beacon']
        };
        _this.app.models.Stat.find(query, function(err, res) {
          if (res.length) {
            cb(err, res[0]);
          } else {
            cb(err);
          }
        });
      };
    })(this);
  };

  DailyStatReport.prototype.cameFromStat = function(stat) {
    return (function(_this) {
      return function(cb) {
        var query;
        query = {
          where: {
            userId: stat.userId,
            beaconId: {
              neq: _this.beaconId
            },
            key: "enteredBeacon",
            timestamp: {
              lt: stat.timestamp
            }
          },
          limit: 1,
          include: ['beacon']
        };
        _this.app.models.Stat.find(query, function(err, res) {
          if (res.length) {
            cb(err, res[0]);
          } else {
            cb(err);
          }
        });
      };
    })(this);
  };

  DailyStatReport.prototype.getTrafficStats = function() {
    return (function(_this) {
      return function(cb) {
        var query;
        query = {
          where: {
            beaconId: _this.beaconId,
            timestamp: {
              between: _this.between
            },
            key: "enteredBeacon"
          }
        };
        return _this.app.models.Stat.find(query, function(err, stats) {
          var cameFromCalls, i, len, stat, wentToCalls;
          wentToCalls = [];
          cameFromCalls = [];
          for (i = 0, len = stats.length; i < len; i++) {
            stat = stats[i];
            wentToCalls.push(_this.wentToStat(stat));
            cameFromCalls.push(_this.cameFromStat(stat));
          }
          return async.parallel(wentToCalls, function(err, wentToResults) {
            _this.beaconsWentTo = _.countBy(_.compact(wentToResults), function(res) {
              return res.__data.beacon.name;
            });
            return async.parallel(cameFromCalls, function(err, cameFromResults) {
              _this.beaconsCameFrom = _.countBy(_.compact(cameFromResults), function(res) {
                return res.__data.beacon.name;
              });
              return cb();
            });
          });
        });
      };
    })(this);
  };

  DailyStatReport.prototype.getVisitorStats = function() {
    return (function(_this) {
      return function(cb) {
        var query;
        query = {
          where: {
            timestamp: {
              between: _this.between
            },
            beaconId: _this.beaconId,
            key: "enteredBeacon"
          }
        };
        return _this.app.models.Stat.find(query, function(err, stats) {
          _this.totalVisits = stats.length;
          _this.totalUniqueVisits = _.uniq(_.pluck(stats, "userId"));
          _this.averageTimeSpentInMinutes = _this.averageTimeSpent(stats);
          cb();
        });
      };
    })(this);
  };

  DailyStatReport.prototype.getPopularityIndex = function() {
    return function(cb) {
      this.popularityIndex = 0;
      return cb(null);
    };
  };

  DailyStatReport.prototype.fetchAllTimeStatsForChildItems = function(collection, foreignKey) {
    return (function(_this) {
      return function(cb) {
        var calls, i, item, len, sr;
        calls = [];
        for (i = 0, len = collection.length; i < len; i++) {
          item = collection[i];
          sr = new ItemReport(_this.app, foreignKey, item, null);
          calls.push(sr.getStats());
        }
        async.waterfall(calls, function(err) {
          return cb(err);
        });
      };
    })(this);
  };

  return DailyStatReport;

})();

ItemReport = (function() {
  function ItemReport(app, foreignKey1, item1, between1) {
    this.app = app;
    this.foreignKey = foreignKey1;
    this.item = item1;
    this.between = between1;
    this.getStats = bind(this.getStats, this);
    this.stats = bind(this.stats, this);
    this.totalViews = 0;
    this.totalCollection = 0;
    this.weight = 0;
    this.item.statsReport = {
      views: 0,
      collections: 0
    };
    if (this.item.constructor.modelName === "Quiz") {
      this.item.statsReport.completions = 0;
    }
  }

  ItemReport.prototype.stats = function(key, countKey) {
    return (function(_this) {
      return function(cb) {
        var viewQuery;
        viewQuery = {
          where: {
            key: key
          }
        };
        viewQuery.where[_this.foreignKey] = _this.item.id;
        if (_this.between) {
          viewQuery.where.timestamp = {
            between: _this.between
          };
        }
        _this.app.models.Stat.find(viewQuery, function(err, res) {
          _this.item.__data.statsReport[countKey] = res.length;
          return cb(err);
        });
      };
    })(this);
  };

  ItemReport.prototype.getStats = function() {
    return (function(_this) {
      return function(cb) {
        var calls;
        console.log('getting stats for collection', _this.item.constructor.modelName);
        calls = [];
        calls.push(_this.stats('viewed', 'views'));
        calls.push(_this.stats('addedToMemento', 'collections'));
        if (_this.item.constructor.modelName === "Quiz") {
          calls.push(_this.stats('completedQuiz', 'completions'));
        }
        async.waterfall(calls, function(err, res) {
          _this.item.weight = (_this.item.__data.statsReport.views * 1) + (_this.item.__data.statsReport.collections * 6);
          return _this.item.save(cb(err));
        });
      };
    })(this);
  };

  return ItemReport;

})();

promiseWrapperForStatGen = function(beacon, date, sg) {
  return (function(_this) {
    return function(cb) {
      return sg.generateDailyReport(beacon, date, function(err, res) {
        console.log("report generated for " + beacon.name);
        return cb();
      });
    };
  })(this);
};

promiseWrapperForCollectionStatGen = function(beacon, date, sg) {
  return (function(_this) {
    return function(cb) {
      return sg.generateDailyReport(beacon, date, function(err, res) {
        console.log("report generated for " + beacon.name);
        return cb();
      });
    };
  })(this);
};

StatGen = (function() {
  function StatGen(app, datasource) {
    this.app = app;
    if (!datasource) {
      datasource = 'memento';
    }
    this.agenda = new Agenda({
      db: {
        address: this.app.datasources[datasource].connector.settings.url
      }
    });
    this.startedJob = false;
    this.startBeaconStatCollection();
  }

  StatGen.prototype.generateDailyReport = function(beacon, date, cb) {
    var between, calls, endDate, sr, startDate;
    startDate = moment(date).tz(beacon.timeZone).startOf('day').toDate();
    endDate = moment(date).tz(beacon.timeZone).endOf('day').toDate();
    between = [startDate, endDate];
    sr = new DailyStatReport(beacon, between, this.app);
    calls = [];
    calls.push(sr.getVisitorStats());
    calls.push(sr.getCollectionStats('artifacts', "artifactId"));
    calls.push(sr.getCollectionStats('funFacts', "funFactId"));
    calls.push(sr.getCollectionStats('quizzes', "quizId"));
    if (beacon.__data.artifacts) {
      calls.push(sr.fetchAllTimeStatsForChildItems(beacon.__data.artifacts, 'artifactId'));
    }
    if (beacon.__data.quizzes) {
      calls.push(sr.fetchAllTimeStatsForChildItems(beacon.__data.quizzes, 'quizId'));
    }
    if (beacon.__data.funFacts) {
      calls.push(sr.fetchAllTimeStatsForChildItems(beacon.__data.funFacts, 'funFactId'));
    }
    calls.push(sr.getTrafficStats());
    calls.push(sr.getPopularityIndex());
    return async.waterfall(calls, (function(_this) {
      return function(err) {
        return _this.app.models.StatsReport.findOne({
          where: {
            beaconId: beacon.id,
            endDate: endDate
          }
        }, function(err, report) {
          var statReport;
          statReport = sr.returnStats();
          if (report) {
            statReport.id = report.id;
          }
          return _this.app.models.StatsReport.upsert(statReport, function(err, res) {
            return cb(err, res);
          });
        });
      };
    })(this));
  };

  StatGen.prototype.collectStats = function() {
    return this.app.models.Beacon.find({
      include: ["artifacts", "funFacts", "quizzes"]
    }, (function(_this) {
      return function(err, beacons) {
        var beacon, calls, i, len;
        calls = [];
        for (i = 0, len = beacons.length; i < len; i++) {
          beacon = beacons[i];
          calls.push(promiseWrapperForStatGen(beacon, Date.now(), _this));
        }
        return async.waterfall(calls, function(err, res) {
          return console.log('stat generation job complete');
        });
      };
    })(this));
  };

  StatGen.prototype.startBeaconStatCollection = function() {
    this.agenda.define('beacon stat report job', (function(_this) {
      return function(job, done) {
        console.log('starting stat report job');
        return _this.app.models.Beacon.find({
          include: ["artifacts", "funFacts", "quizzes"]
        }, function(err, beacons) {
          var beacon, calls, i, len;
          calls = [];
          for (i = 0, len = beacons.length; i < len; i++) {
            beacon = beacons[i];
            calls.push(promiseWrapperForStatGen(beacon, Date.now(), _this));
          }
          return async.waterfall(calls, function(err, res) {
            return console.log('stat generation job complete');
          });
        });
      };
    })(this));
    this.agenda.every('1 hour', 'beacon stat report job');
    this.agenda.start();
    return console.log("agenda started");
  };

  StatGen.prototype.startArtifactStatCollection = function() {
    this.agenda.define('artifact stat report job', (function(_this) {
      return function(job, done) {
        console.log('starting stat report job');
        _this.startedJob = true;
        return _this.collectStats();
      };
    })(this));
    this.agenda.every('1 hour', 'beacon stat report job');
    this.agenda.start();
    return console.log("agenda started");
  };

  return StatGen;

})();

module.exports = StatGen;
