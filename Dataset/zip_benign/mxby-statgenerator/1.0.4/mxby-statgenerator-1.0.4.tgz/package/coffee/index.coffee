_ = require('lodash-node')
async = require('async')
moment = require('moment-timezone')
Agenda = require('agenda')

###
*************************************
* This app is intended to generate and maintain stats reports for Mixby applications
* A stat report is an object which contains relevant stat totals for a given beacon or place
* It typically looks like this:
*
* Stat = {
*   beaconId: [objectId] id of the beacon this stat report relates to
*   endDate: [date] end of day in utc relative to the location of the beacon (or the beacon's parent place)
*   popularityIndex: [float] number indicating popularity of the beacon as a whole (measure of interactions + visits + time spent etc
*
*   totalVisits: [int] how many times the beacon was entered
*   totalUniqueVisits: [int] how many people visited the beacon
*   averageTimeSpentInMinutes: [int] average minutes spent at the beacon
*
*   totalArtifactsCollected: [int] total number of artifacts collected from this beacon
*   totalArtifactsViewed: [int] total number of view stats for artifacts
*   averageTimeSpentViewingArtifactsInMinutes: [int] average minutes spent viewing artifacts
*
*   totalChallengesCollected: [int] total number of artifacts collected from this beacon
*   totalChallengesViewed: [int] total number of view stats for artifacts
*   totalChallengesCompleted: [int] total number of view stats for artifacts
*   averageTimeSpentViewingChallengesInMinutes: [int] average minutes spent viewing artifacts
*
*   totalExtrasCollected: [int] total number of artifacts collected from this beacon
*   totalExtrasViewed: [int] total number of view stats for artifacts
*   averageTimeSpentViewingArtifactsInMinutes: [int] average minutes spent viewing artifacts
*
*   beaconsCameFrom: [array][obj] {beaconName: str, beaconId: objectId, count: int}
*   beaconsWentTo: [array][obj] {beaconName: str, beaconId: objectId, count: int}
*
*   mostPopularArtifacts: [array][obj] {artifactId: objectId, views: int, collections: int}
*   mostPopularFunFacts: [array][obj] {funFactId: objectId, views: int, collections: int}
*   mostPopularQuizzes: [array][obj] {quizId: objectId, views: int, collections: int, completions: int}
*
* }
*
* *************************************
###


String::capitalize = ->
  this.charAt(0).toUpperCase() + this.slice(1)


#  TODO: add methods for individual artifacts / funfacts / quizzes to update their total views / collections

class DailyStatReport
  constructor: (@beacon, @between, @app) ->
    @beaconId = @beacon.id
    @endDate = @between[1]
    @date = moment(@endDate).format("MMM Do YYYY")
    @month = moment(@endDate).format("MMM-YY")
    @popularityIndex = 0
    @totalVisits = 0
    @totalUniqueVisits = 0
    @averageTimeSpentInMinutes = 0
    @totalArtifactsCollected = 0
    @totalArtifactsViewed = 0
    @averageTimeSpentViewingArtifactsInMinutes = 0
    @totalFunFactsCollected = 0
    @totalFunFactsViewed = 0
    @averageTimeSpentViewingFunFactsInMinutes = 0
    @totalQuizzesCollected = 0
    @totalQuizzesViewed = 0
    @averageTimeSpentViewingQuizzesInMinutes = 0
    @beaconsCameFrom = []
    @beaconsWentTo = []
    @mostPopularArtifacts = []
    @mostPopularQuizzes = []
    @mostPopularFunFacts = []

  returnStats: ()=>
    props = {}
    for own key, prop of this
      if prop not instanceof Function and key isnt "beacon" then props[key] = @[key]
    return props

  averageTimeSpent: (arrayOfStats) =>
    timespent = 0
    if not arrayOfStats or arrayOfStats.length is 0
      return 0
    else
      for stat in arrayOfStats
        if not stat.stopTime then stat.stopTime = stat.timestamp
        timespent += new Date(stat.stopTime).getTime() - new Date(stat.timestamp).getTime()
      return (timespent / arrayOfStats.length ) / 1000 / 60

  getCollectionStats: (collectionName, foreignKey, item) =>
#		NOTE: THIS ASSUMES THE BEACONS COLLECTION HAS BEEN FILLED OUT IT DOES NOT FETCH COLLECTION
    (cb) =>
      collection = @beacon.__data[collectionName]
      if not collection
        cb null
        return
      else
        ids = []

        for item in collection
          ids.push(item.id.toString())

        statReportViewKey = "total#{collectionName.capitalize()}Viewed"
        statReportCollectedKey = "total#{collectionName.capitalize()}Collected"
        statReportAverageTimeKey = "averageTimeSpentViewing#{collectionName.capitalize()}InMinutes"
        query = {where: {key: {inq: ['viewed', 'addedToMemento']}}, timestamp: {between: @between}}
        query.where[foreignKey] = {inq: ids}
        @app.models.Stat.find query, (err, stats) =>
            views = []
            collections = []
            for stat in stats
              if stat.key is "viewed"
                views.push(stat)
              if stat.key is "addedToMemento"
                collections.push(stat)
            @[statReportViewKey] += if views then views.length else 0
            @[statReportCollectedKey] += if collections then collections.length else 0
            @[statReportAverageTimeKey] += @averageTimeSpent(views)
            cb err
        return


  wentToStat: (stat) =>
    (cb) =>
      query = {where: {userId: stat.userId, beaconId: {neq: @beaconId}, key: "enteredBeacon", timestamp: {gt: stat.timestamp}}, limit: 1, include: ['beacon']}
      @app.models.Stat.find(query,
        (err, res)=>
          if res.length
            cb err, res[0]
          else cb err
          return
      )
      return

  cameFromStat: (stat) =>
    (cb) =>
      query = {where: {userId: stat.userId, beaconId: {neq: @beaconId}, key: "enteredBeacon", timestamp: {lt: stat.timestamp}}, limit: 1, include: ['beacon']}
      @app.models.Stat.find(query,
        (err, res)=>
          if res.length
            cb err, res[0]
          else cb err
          return
      )
      return


  getTrafficStats: () =>
    return (cb) =>
      query = {where: {beaconId: @beaconId, timestamp: {between: @between}, key: "enteredBeacon"}}
      @app.models.Stat.find(query,
        (err, stats) =>
          wentToCalls = []
          cameFromCalls = []
          for stat in stats
            wentToCalls.push(@wentToStat(stat))
            cameFromCalls.push(@cameFromStat(stat))
          async.parallel(wentToCalls,
            (err, wentToResults) =>
              @beaconsWentTo = _.countBy(_.compact(wentToResults), (res) -> return res.__data.beacon.name)
              async.parallel(cameFromCalls,
                (err, cameFromResults) =>
                  @beaconsCameFrom = _.countBy(_.compact(cameFromResults), (res) -> return res.__data.beacon.name)
                  cb()
              )
          )
      )

  getVisitorStats: ()=>
    return (cb) =>
      query = {where: {timestamp: {between: @between}, beaconId: @beaconId, key: "enteredBeacon"}}
      @app.models.Stat.find(query,
        (err, stats) =>
          @totalVisits = stats.length
          @totalUniqueVisits = _.uniq(_.pluck(stats, "userId"))
          @averageTimeSpentInMinutes = @averageTimeSpent(stats)
          cb()
          return
      )

  getPopularityIndex: () =>
    (cb) ->
      @popularityIndex = 0
      cb null

  fetchAllTimeStatsForChildItems: (collection, foreignKey) =>
    (cb) =>
      calls = []
      for item in collection
        sr = new ItemReport(@app, foreignKey, item, null)
        calls.push(sr.getStats())
      async.waterfall(calls, (err) -> cb(err))
      return

# END STAT REPORT CLASS



# Class Item Report

class ItemReport
  constructor: (@app, @foreignKey, @item, @between) ->
    @totalViews = 0
    @totalCollection = 0
    @weight = 0
    @item.statsReport = {views: 0, collections: 0}
    if @item.constructor.modelName is "Quiz" then @item.statsReport.completions = 0

  stats: (key, countKey) =>
    (cb) =>
      viewQuery = {where: {key: key}}
      viewQuery.where[@foreignKey] = @item.id
      if @between then viewQuery.where.timestamp = {between: @between}
      @app.models.Stat.find(viewQuery,
        (err, res)=>
          @item.statsReport[countKey] = res.length
          cb err
      )
      return

  getStats: () =>
    (cb) =>
      console.log('getting stats for collection', @item.constructor.modelName)
      calls = []
      calls.push(@stats('viewed', 'views'))
      calls.push(@stats('addedToMemento', 'collections'))
      if @item.constructor.modelName is "Quiz" then calls.push(@stats('completedQuiz', 'completions'))
      async.waterfall(calls, (err, res) =>
#       TODO: Determine weight
        @item.weight = (@item.statsReport.views * 1) + (@item.statsReport.collections * 6)
        @item.save(cb err)
      )
      return


promiseWrapperForStatGen = (beacon, date, sg) ->
  (cb) =>
    sg.generateDailyReport(beacon, date, (err, res) =>
      console.log("report generated for #{beacon.name}")
      cb()
    )
    
promiseWrapperForCollectionStatGen = (beacon, date, sg) ->
  (cb) =>
    sg.generateDailyReport(beacon, date, (err, res) =>
      console.log("report generated for #{beacon.name}")
      cb()
    )
  
class StatGen
  constructor: (@app, datasource) ->
    if not datasource then datasource = 'memento'
    @agenda = new Agenda({db: {address: @app.datasources[datasource].connector.settings.url}})
    @startedJob = false;
    @startBeaconStatCollection()

  generateDailyReport: (beacon, date, cb) ->
    startDate = moment(date).tz(beacon.timeZone).startOf('day').toDate()
    endDate = moment(date).tz(beacon.timeZone).endOf('day').toDate()
    between = [startDate, endDate]

    sr = new DailyStatReport(beacon, between, this.app)

    calls = []
    calls.push(sr.getVisitorStats())
    calls.push(sr.getCollectionStats('artifacts', "artifactId"))
    calls.push(sr.getCollectionStats('funFacts', "funFactId"))
    calls.push(sr.getCollectionStats('quizzes', "quizId"))
    if beacon.__data.artifacts then calls.push(sr.fetchAllTimeStatsForChildItems(beacon.__data.artifacts, 'artifactId'))
    if beacon.__data.quizzes then calls.push(sr.fetchAllTimeStatsForChildItems(beacon.__data.quizzes, 'quizId'))
    if beacon.__data.funFacts then calls.push(sr.fetchAllTimeStatsForChildItems(beacon.__data.funFacts, 'funFactId'))
    calls.push(sr.getTrafficStats())
    calls.push(sr.getPopularityIndex())

    async.waterfall(calls,
      (err) =>
        @app.models.StatsReport.findOne({where: {beaconId: beacon.id, endDate: endDate}}, (err, report) =>
          statReport = sr.returnStats()
          if report then statReport.id = report.id
          @app.models.StatsReport.upsert(statReport, (err, res) =>
            cb(err, res)
          )
        )
    )

  collectStats: () ->
    @app.models.Beacon.find({include: ["artifacts", "funFacts", "quizzes"]}, (err, beacons) =>
      calls = []
      for beacon in beacons
        calls.push(promiseWrapperForStatGen(beacon, Date.now(), this))
      async.waterfall(calls, (err, res) =>
        console.log('stat generation job complete')
      )
    )

  startBeaconStatCollection: ()->
    @agenda.define('beacon stat report job', (job, done) =>
      console.log('starting stat report job')
      @app.models.Beacon.find({include: ["artifacts", "funFacts", "quizzes"]}, (err, beacons) =>
        calls = []
        for beacon in beacons
          calls.push(promiseWrapperForStatGen(beacon, Date.now(), this))
        async.waterfall(calls, (err, res) =>
          console.log('stat generation job complete')
        )
      )
    )
    @agenda.every('1 hour', 'beacon stat report job')
    @agenda.start()
    console.log("agenda started")
  
  startArtifactStatCollection: ()->
    @agenda.define('artifact stat report job', (job, done) =>
      console.log('starting stat report job')
      @startedJob = true
      @collectStats()
    )
    @agenda.every('1 hour', 'beacon stat report job')
    @agenda.start()
    console.log("agenda started")


module.exports = StatGen

