var gulp = require('gulp');
var coffee = require('gulp-coffee');

gulp.task('default', ['watch']);


gulp.task('coffee', function(){
  gulp.src('coffee/**.coffee')
    .pipe(coffee({bare: true}))
    .pipe(gulp.dest(''))
});


gulp.task('watch', ['coffee'], function(){
  gulp.watch('**/*.coffee', ['coffee']);
});
