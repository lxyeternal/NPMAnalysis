declare const Brightness: {
    /**
     * Sets the screen brightness.
     * @param brightness - A value between 0 and 1 representing the brightness level
     * @param durationMs - Duration in milliseconds for which the brightness transition should occur
     */
    setBrightness: (brightness: number, durationMs?: number) => Promise<void>;
    /**
     * Gets the current screen brightness.
     * @returns A promise that resolves the current brightness level (0 to 1)
     */
    getBrightness: () => Promise<number>;
    /**
     * The method is responsible for determining whether the user's original brightness
     * should be restored when the application is minimized
     *
     * @param isNeedRestoreBrightness - If `true`, restores original brightness upon app minimization (initial value is "true")
     * @platform ios
     */
    setIsNeedRestoreBrightness: (isNeedRestoreBrightness: boolean) => void;
};
export default Brightness;
//# sourceMappingURL=index.d.ts.map