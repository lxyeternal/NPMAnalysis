import MediaScene from "./index";
export default MediaScene;
