import Scene, { SceneItem } from "scenejs";
import { MediaInfo } from "./types";
export default class Media extends Scene {
    url: string;
    private isPlayMedia;
    private mediaItem;
    constructor(url: string | HTMLMediaElement);
    getMediaItem(): SceneItem;
    getVolume(): number;
    setVolume(volume: number): this;
    setPlaySpeed(playSpeed: number): this;
    seek(fromTime: number, toTime: number): this;
    setElement(element: HTMLMediaElement): this;
    getMediaElement(): HTMLMediaElement;
    getInfo(): MediaInfo;
    private init;
}
