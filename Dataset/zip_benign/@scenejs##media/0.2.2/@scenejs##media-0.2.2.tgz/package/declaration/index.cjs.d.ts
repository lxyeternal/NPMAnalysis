import MediaScene from "./index";
export * from "./index";
export default MediaScene;
