const {performance} = require('perf_hooks');
var colors = require('colors');
class Test {
   static fullError = true
   static tabs = 3
   static equal = (expected,result) => expected == result ? true : false
   static notEqual = (expected,result) => expected !== result ? true : false
   static includes = (expected,result) => result.includes(expected) ? true : false
   static notIncludes = (expected,result) => result.includes(expected) ? false : true
   static greater = (expected,result) => expected > result ? true : false
   static $greater = (expected,result) => expected >= result ? true : false
   static smaller = (expected,result) => expected < result ? true : false
   static $smaller = (expected,result) => expected <= result ? true : false

   static isAsync = (fn) => (fn.constructor.name === 'AsyncFunction') ? true : false
   static isFn = (fn) => (typeof fn == 'function') ? true : false
   static mesureTime(fn,t=0) {
      let {isAsync,isFn} = Test
      if(isFn(fn)) {
         if(isAsync) return async function(vars) {
            let t = performance.now()
            await fn(vars)
            return performance.now() - t
         } 
         else return function(vars) {
            let t = performance.now()
            fn(vars)
            return performance.now() - t
         }
      } else return function() {
         console.log('fn is not a function'.red)
         return null
      }
   }
   static delay = ms => new Promise(res => setTimeout(res, ms));

   static async run(title,tests=[],vars) {
      console.log(`\n\r${title}`.bgBlue)
      for(let test of tests) {
         test.category = title
         await test.run(vars)
      }
   }

   static outcome() {
      let all = Test.tests.map(test=> {return {[test.title]:test.outcome()}})
      let errors = Test.tests.map(test=> Test.filter(null,test.tests))
      let passed = Test.tests.map(test=> Test.filter(true,test.tests))
      let failed = Test.tests.map(test=> Test.filter(false,test.tests))
      let notPassed = Test.tests.map(test => {return {
         [test.title]:test.tests.filter(
            obj => (obj.outcome && obj.action) ? obj.outcome.passed === false || obj.outcome.passed == null : false
         )}
      })
      return {all,errors,passed,failed,notPassed}
   }

   static report(title,passed,failed,errored,done,space,titleSpace,testTime) {
      console.log(titleSpace+`Report for ${title}`.underline.cyan)
      let result = `${space}☰  Passed: ${(passed).toString().green}`
      +`  Failed: ${(failed).toString().magenta}`
      +`  Errors: ${(errored).toString().red}`
      +`  Done: ${(done).toString().yellow}\n\r`
      console.log(`${space}🕒 Test time: ${Test.buildTime(testTime)}`.gray)
      console.log(result)
      console.log('\n\r\n\r'.white.underline)
   }

   static buildTime(ms) {
      let min = Math.floor(ms / 60000);
      let sec = ((ms % 60000) / 1000).toFixed(0);
      ms = (ms - min*60000 - sec*1000).toFixed(2)
      return `${min>0 ? min+'m ' :''}${sec>0 ? sec+'s ' :''}${ms>0 ? ms+'ms' :''}` 
   }

   static summary() {
      let passed,failed,errored,done,testTime
      passed=failed=errored=done=testTime=0
      Test.tests.forEach((test,index) => {
         passed += Test.filter(true,test.tests).length
         failed += Test.filter(false,test.tests).length
         errored += Test.filter(null,test.tests).length
         done += Test.filter(undefined,test.tests).length
      })
      testTime = Test.tests.reduce((acc,cur)=>acc+cur.testTime,testTime)
      Test.report('Summary of tests',passed,failed,errored,done,'','',testTime)
   }
   static filter(pass,tests) {
      return tests.filter(test => (test.outcome) ? test.outcome.passed === pass : false)
   }

   static tests = []
   constructor(title='No title',tests=[],category) {
      this.terminate = false
      this.title = title
      this.tests = tests
      this.vars = {}
      this.category = category
      this.performance = {}
      this.testTime
   }
   outcome() {return this.tests.map(obj => obj.outcome)}

   getSpace() {
      let tabs=Test.tabs
      let space = Array.from(Array(tabs).keys()).map(n => ' ').join('')
      let titleSpace = ''
      if(this.category) {
         titleSpace = space
         space = space+space
      }
      this.titleSpace = titleSpace
      this.space = space
   }

   async run(vars={}) {
      let t1 = performance.now()
      this.getSpace()
      for(let varName in vars) {this.vars[varName] = vars[varName]}
      Test.tests.push(this)
      let {isAsync,isFn} = Test
      let {tests,title} = this
      console.log(`\n\r${this.titleSpace}${title.underline.cyan} \n\r`)
      if(Array.isArray(tests)) {
         for(let i=0; i<tests.length; i++) {
            let obj = tests[i]
            if(typeof obj == 'object') {
               let time
               let {title,expected,result,action,interval=1000,times,wait} = obj
               try {
                  if(isFn(expected)) {
                     expected = expected.bind(this)
                     if(isAsync(expected)) expected = await expected(this.vars)
                     else expected = expected(this.vars)
                  }
                  if(isFn(result)) {
                     if(wait) {
                        if(typeof wait == 'number') {
                           console.log(`Waiting ${wait}ms...`.gray)
                           await Test.delay(wait)
                        }
                     }
                     result = result.bind(this)
                     if(times) {
                        result = await this.repeat(result,times,interval,action,expected)
                        console.log('\n')
                     } else {
                        time = performance.now()
                        if(isAsync(result)) result = await result(this.vars)
                        else result = result(this.vars)
                        time = (performance.now() - time)
                     }
                  }
                  this.check({title,result,expected,action,time},i)
               } catch(error) {
                  this.errorMsg(error,title,i)
               }
            }
            if(this.terminate) {
               console.log(this.space+'Last action has terminated next tests'.yellow)
               break;
            }
         }
         this.testTime = performance.now() - t1
         this.report()
      }
      else console.error('Parameter is not array.Test not performed.')
   }

   report() {
      Test.report(
         this.title,
         Test.filter(true,this.tests).length,
         Test.filter(false,this.tests).length,
         Test.filter(null,this.tests).length,
         Test.filter(undefined,this.tests).length,
         this.space,
         this.titleSpace,
         this.testTime
      )
   }
   
   errorMsg(error,title,i,space=this.space) {
      let err = `${space}${'\u0021 '.red.bold} ${title}. \n${space+space}error: ${error.gray}\n`
      if(Test.fullError) console.log(error)
      this.tests[i].outcome = {title,error,err,passed:null}
      return null
   }

   check({title,result,expected,action,time},i,space=this.space,t='') {
      if(action == undefined && result == undefined && expected == undefined) {
         console.log('\u2690'.brightGreen +' ' + title.gray.italic+'\n')
         return
      }
      if(time > 0) {
         t = ` (${Test.buildTime(time)})`
         this.performance[title] = time
      }
      if(result instanceof Error) return this.errorMsg(result.message,title,i)
      else if(action == undefined || typeof action !== 'function') {
         if(expected === undefined) {
            let astrix = `\u2731`.yellow.bold
            this.tests[i].outcome = {title,result}
            console.log(`${space}${astrix}  ${title}${t}`)
            console.log(`${space+space}Done:${result}\n`)
            return
         } else return this.errorMsg('Action is missing',title,i)
      } 
      let passed = action(expected,result)
      expected = this.checkValue(expected)
      result = this.checkValue(result)
      this.tests[i].outcome = {title,passed,expected,result,action:action.name}
      let msg = `\n${space+space}Expected: ${expected.toString().gray}, result: ${result.toString().gray}, action: ${action.name.toString().gray}.\n`
      let v = '\u2713 '.green.bold  // ✔
      let x = '✘ '.magenta.bold
      if(passed) console.log(`${space}${v} ${title} ${'passed'.underline}${t}. ${msg}`)
      else console.log(`${space}${x} ${title} ${'failed'.underline}${t}. ${msg}`)
      return passed
   }

   checkValue = (value) => (value === null) ? 'null' : (value === undefined) ? 'undefined' : value

   async repeat(fn,times,interval=1000,action,expected) {
      let result,passed
      for(let i=0; i<times; i++) {
         if (Test.isAsync(fn)) result = await fn(this.vars)
         else result = fn(this.vars)
         passed = action(expected,result)
         console.log(`Try ${i+1}: ${passed ? 'passed' : 'failed'}`.grey)
         if(passed) return result
         else await Test.delay(interval)
      }
      return result
   }
}

module.exports = Test