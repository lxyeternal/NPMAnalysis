import {onTouchSwipe} from './dist/index.js';


const $wrapper = document.querySelector('#wrapper');

onTouchSwipe(document.documentElement, {
    callbacks: {
        left: (e) => console.log('swipe left', e.direction, e.type, e.deltaX, e.deltaY),
        right: (e) => console.log('swipe right', e.direction, e.type, e.deltaX, e.deltaY),
        up: (e) => console.log('swipe up', e.direction, e.type, e.deltaX, e.deltaY),
        down: (e) => console.log('swipe down', e.direction, e.type, e.deltaX, e.deltaY),
        start: (e) => console.log('swipe start', e.direction, e.type, e.deltaX, e.deltaY),
        move: (e) => console.log('swipe move', e.direction, e.type, e.deltaX, e.deltaY),
        end: (e) => console.log('swipe end', e.direction, e.type, e.deltaX, e.deltaY),
        cancel: (e) => console.log('swipe cancel', e.direction, e.type, e.deltaX, e.deltaY),
    }
});
