# formula
A formula parser and excutor for project proxima.
## 开发
```
yarn && yarn prepare
yarn dev
```
## 文法（忽略同一级运算符的优先级）
```
expression -> +expression
expression -> -expression
expression -> expression + term
expression -> expression - term
expression -> expression = term
expression -> expression > term
expression -> expression < term
expression -> expression >= term
expression -> expression <= term
expression -> expression && term
expression -> expression || term
expression -> term
term -> func
term -> term * factor
term -> term / factor
term -> factor
func -> _id(params)
params -> params, factor
params -> factor
params -> expression
params -> func
factor -> (expression)
factor -> num
factor -> id
```

## 用法
```JavaScript
const { parseAndExcute, parseAST } = require('@projectproxima/formula');
parseAndExcute('0.1 + 0.2') // 0.3
parseAST('0.1 + 0.2') // {"type":"BinaryExpression","operator":"+","left":{"type":"Literal","value":0.1,"raw":"0.1"},"right":{"type":"Literal","value":0.2,"raw":"0.2"}}
```
## 注意事项
1. 新增函数能力请在 `src/formulas.ts` 文件中书写，每个函数必须在 `FUNCTION_ARGUMENTS_LIMIT` 中维护一份函数名和参数数量的映射，用于校验公式是否存在及公式参数数量是否符合预期。需要注意函数对返回值的处理，不合法的值一律返回 `undefined`，避免一堆无效的值写入数据库中（写入前只会过滤 `undefined`）。

