import { RefObject } from 'react';
declare type onDragCb<T> = (e: {
    el: T;
    last: boolean;
    first: boolean;
    deltaX: number;
    deltaY: number;
    offsetX: number;
    offsetY: number;
    clientX: number;
    clientY: number;
}) => void;
export declare function useEventCallback<T extends (...args: any[]) => any>(fn: T, dependencies?: Array<any>): T;
export declare const useDragsEvent: unique symbol;
export default function useDragged<T extends HTMLElement>(elRef: RefObject<T>, onDrag: onDragCb<T>): void;
export {};
