/*!
 * MIT License
 * 
 * Copyright (c) 2024 wangruikang
 * 
 * 许可人特此授权任何获得本软件和相关文档文件（“软件”）的个人或团体， 
 * 免费使用本软件，包括但不限于使用、复制、修改、合并、出版、发行、 
 * 复制、分发和/或出售软件的副本，以及软件的使用权， 
 * 并在软件的副本或部分中包含以上版权声明和本许可声明。
 * 
 * 本软件是按“现状”提供的，不附带任何明示或暗示的担保， 
 * 包括但不限于对适销性、特定目的适用性及非侵权的担保。
 * 
 * 在任何情况下，作者或版权所有者对因使用本软件或其他交易而产生的任何 
 * 索赔、损害或其他责任（无论是合同诉讼、侵权诉讼或其他诉讼）概不负责。
 */

/**
 * 大数类，用于处理高精度数学运算
 */
class BigNumber {
    constructor(value) {
        // 构造函数，支持数字和字符串
        if (typeof value === 'number') {
            if (!isNaN(value)) {
                this.value = value.toString(); // 将数字转换为字符串
            } else {
                throw new Error(`输入类型无效: ${value}`); // 抛出错误并包含输入值
            }
        } else if (typeof value === 'string') {
            if (value.trim() !== '') {
                this.value = value; // 如果是字符串且非空，直接赋值
            } else {
                throw new Error(`输入类型无效: ${value}`); // 抛出错误并包含输入值
            }
        } else {
            throw new Error(`输入类型无效: ${value}`); // 抛出错误并包含输入值
        }
    }

    // 获取整数和小数部分
    getParts() {
        const parts = this.value.split('.');
        return {
            integer: parts[0] || '0', // 整数部分
            decimal: parts[1] || '0',  // 小数部分
        };
    }

    // 加法
    plus(other) {
        return this._operate(other, 'plus');
    }

    // 减法
    minus(other) {
        return this._operate(other, 'minus');
    }

    // 乘法
    times(other) {
        return this._operate(other, 'times');
    }

    // 除法
    div(other) {
        return this._operate(other, 'div');
    }

    // 进行基本运算的私有方法
    _operate(other, operation) {
        const a = this.getParts(); // 当前对象的整数和小数部分
        
        const b = (other instanceof BigNumber) ? other : new BigNumber(other);
        const bParts = b.getParts(); // 另一个 BigNumber 对象的整数和小数部分

        const maxDecimalLength = Math.max(a.decimal.length, bParts.decimal.length); // 确定小数部分的最大长度
        const aInt = a.integer + a.decimal.padEnd(maxDecimalLength, '0'); // 对齐小数部分
        const bInt = bParts.integer + bParts.decimal.padEnd(maxDecimalLength, '0'); // 对齐小数部分

        let result; // 结果变量

        // 根据操作类型执行相应的运算
        switch (operation) {
            case 'plus':
                result = (BigInt(aInt) + BigInt(bInt)).toString(); // 加法
                break;
            case 'minus':
                result = (BigInt(aInt) - BigInt(bInt)).toString(); // 减法
                break;
            case 'times':
                const product = (BigInt(aInt) * BigInt(bInt)).toString(); // 乘法
                const decimalPlaces = a.decimal.length + bParts.decimal.length; // 计算小数位数
                result = product.slice(0, product.length - decimalPlaces) + '.' + product.slice(product.length - decimalPlaces);
                break;
            case 'div':
                const divisor = BigInt(bInt); // 被除数
                if (divisor === BigInt(0)) {
                    throw new Error('除以零'); // 检查除数是否为零
                }
                const quotient = (BigInt(aInt) * BigInt(10 ** bParts.decimal.length)) / divisor; // 除法
                result = quotient.toString() + '0'.repeat(bParts.decimal.length); // 补零以维持小数位数
                break;
            default:
                throw new Error('不支持的操作'); // 抛出无效操作错误
        }

        // 返回结果
        return new BigNumber(result.slice(0, result.length - maxDecimalLength) + '.' + result.slice(result.length - maxDecimalLength));
    }

    // 返回数值的字符串表示
    toString() {
        return this.value;
    }
}

/**
 * 计算器类，提供简单的计算接口
 */
class BigCalc {
    // 静态方法，执行计算
    static calculate(a, operator, b) {
        const num1 = new BigNumber(a); // 创建第一个大数对象
        const num2 = new BigNumber(b); // 创建第二个大数对象

        // 根据操作符执行相应的计算
        switch (operator) {
            case '+':
                return num1.plus(num2).toString(); // 加法
            case '-':
                return num1.minus(num2).toString(); // 减法
            case '*':
                return num1.times(num2).toString(); // 乘法
            case '/':
                return num1.div(num2).toString(); // 除法
            default:
                throw new Error('无效的运算符。使用 +, -, *, 或 /.'); // 抛出无效运算符错误
        }
    }
}

// 导出模块（支持 CommonJS 和 ES6 导出）
if (typeof module !== 'undefined' && typeof module.exports !== 'undefined') {
    module.exports = BigCalc; // CommonJS 导出
} else if (typeof define === 'function' && define.amd) {
    define([], function() {
        return BigCalc; // AMD 导出
    });
} else {
    window.BigCalc = BigCalc; // 支持浏览器环境
}

// ES6 导出
export default BigCalc;
