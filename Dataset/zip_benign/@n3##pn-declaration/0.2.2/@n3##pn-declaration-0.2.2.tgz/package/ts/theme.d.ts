import type { CSSObject } from 'styled-components';
export declare type BreakpointsType = {
    mobile: number;
    tablet: number;
    desktop: number;
};
export declare type ConditionsType = Record<keyof BreakpointsType, string>;
export declare type FontSourceType = (fontFamily: string, conditions: ConditionsType) => CSSObject;
export declare type FontSourcesType = {
    h1: FontSourceType;
    h2: FontSourceType;
    h3: FontSourceType;
    h4: FontSourceType;
    body: FontSourceType;
    caption: FontSourceType;
};
export declare type FontsType = Record<keyof FontSourcesType, CSSObject>;
export declare type ColorsType = {
    gradient: string;
    primary: string;
    primaryLight: string;
    secondary: string;
    white: string;
    dark: string;
    gray: string;
    middleGray: string;
    lightGray: string;
    error: string;
    success: string;
};
export declare type DistancesType = {
    /**
     * Высота стандартных полей ввода и кнопок
     */
    fieldHeightDefault: number;
    /**
     * Высота маленьких полей ввода и кнопок
     */
    fieldHeightSmall: number;
    /**
     * Закругление полей ввода и кнопок
     */
    fieldBorderRadius: number;
    /**
     * Ширина иконки поля ввода
     */
    fieldIconWidth: number;
    /**
     * Закругление выпадающих подсказок
     */
    tooltipBorderRadius: number;
    /**
     * Максимальная ширина выпадающих подсказок
     */
    tooltipMaxWidth: number;
    /**
     * Отступы внутри выпадающих подсказок
     */
    tooltipPadding: string | number;
    /**
     * Вертикальный отступ от всплывающей подсказки до элемента
     */
    tooltipVerticalOffset: number;
};
export declare type ThemeType = {
    fontFamily: string;
    breakpoints: BreakpointsType;
    fontSources: FontSourcesType;
    colors: ColorsType;
    distances: DistancesType;
};
export declare type ContextThemeType = ThemeType & {
    fonts: FontsType;
    conditions: ConditionsType;
};
