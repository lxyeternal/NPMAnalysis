import type { ReactNode } from 'react';
import type { ButtonColor } from '../components/common';
export declare type ConfirmParams = {
    /**
     * Заголовок
     */
    title?: string;
    /**
     * Текст
     */
    content?: ReactNode;
    /**
     * Асинхронная функция подтверждения, может закончиться с исключением ConfirmError({ message })
     */
    approve?: () => void | Promise<void>;
    /**
     * Текст кнопки отмены
     */
    cancelButtonText?: ReactNode;
    /**
     * Текст кнопки подтвеждения
     */
    approveButtonText?: ReactNode;
    /**
     * Цвет кнопки подтверждения
     */
    approveButtonColor?: ButtonColor;
    /**
     * Скрыть кнопку отмены (для использования как alert)
     */
    hideCancelButton?: boolean;
};
export declare type ConfirmErrorParams = {
    message?: ReactNode;
};
