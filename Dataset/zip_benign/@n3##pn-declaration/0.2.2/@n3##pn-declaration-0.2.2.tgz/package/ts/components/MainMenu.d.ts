import type { ComponentType } from 'react';
import type { MainMenuTopBlockProps } from './MainMenuTopBlock';
import { MainMenuGroupType } from './common';
export declare type MainMenuProps = MainMenuTopBlockProps & {
    groups: MainMenuGroupType[];
};
export declare type MainMenu = ComponentType<MainMenuProps>;
