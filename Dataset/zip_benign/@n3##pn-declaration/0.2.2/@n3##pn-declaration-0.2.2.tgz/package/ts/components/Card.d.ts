import type { ComponentType, ReactElement, ReactNode } from 'react';
import type { CardInfo, CardInfoProps } from './CardInfo';
import type { CardButtonWithCounterType } from './CardButtonsWithCounters';
import type { CardSizeType } from './common';
export declare type CardProps = {
    /**
     * Размер
     */
    size?: CardSizeType;
    /**
     * Ссылка
     */
    linkTo?: string;
    /**
     * Фоновое изображение
     */
    bgImage?: string;
    /**
     * Большое изображение (выводится слева)
     */
    image?: string;
    /**
     * Маленькое изображение (выводится рядом с заголовком)
     */
    logo?: string;
    /**
     * Заголовок
     */
    title?: ReactNode;
    /**
     * Подзаголовок
     */
    subtitle?: ReactNode;
    /**
     * Блоки информации с иконками
     */
    info?: ReactElement<CardInfoProps, CardInfo>;
    /**
     * Блок кнопок со счётчиками
     */
    buttonsWithCounters?: CardButtonWithCounterType[];
    /**
     * Информация внизу блока
     */
    bottomInfo?: ReactNode[];
    /**
     * Опубликовано/не опубликовано. Не выводится, если undefined
     */
    isPublished?: boolean;
    /**
     * Блок действий (выводится справа)
     */
    actions?: ReactNode;
};
export declare type Card = ComponentType<CardProps>;
