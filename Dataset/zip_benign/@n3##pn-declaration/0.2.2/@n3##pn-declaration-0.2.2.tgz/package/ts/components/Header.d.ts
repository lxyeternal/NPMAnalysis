import type { ComponentType } from 'react';
import { MainMenuGroupType } from './common';
export declare type HeaderProps = {
    hasSearchInput: boolean;
    isAuthDisabled?: boolean;
    isAuthorized: boolean;
    onSearchSubmit: (searchValue: string) => void;
    groups: MainMenuGroupType[];
};
export declare type Header = ComponentType<HeaderProps>;
