import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type DetailSectionTitle = StyledComponent<'div', ContextThemeType, {}, never>;
