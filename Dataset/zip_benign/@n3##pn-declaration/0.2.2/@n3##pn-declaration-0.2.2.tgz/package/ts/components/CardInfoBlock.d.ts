import type { ComponentType, ReactNode } from 'react';
export declare type CardInfoBlockProps = {
    icon?: ReactNode;
    isDarkBackground?: boolean;
    children?: ReactNode;
};
export declare type CardInfoBlock = ComponentType<CardInfoBlockProps>;
