import type { ComponentType } from 'react';
export declare type HeaderMenuButtonProps = {
    menuIsOpen: boolean;
    setMenuIsOpen: (nextValue: boolean) => void;
};
export declare type HeaderMenuButton = ComponentType<HeaderMenuButtonProps>;
