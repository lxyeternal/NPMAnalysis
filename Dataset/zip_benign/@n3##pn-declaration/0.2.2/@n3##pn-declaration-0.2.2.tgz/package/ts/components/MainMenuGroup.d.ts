import type { ComponentType } from 'react';
import { MainMenuGroupType } from './common';
export declare type MainMenuGroupProps = {
    group: MainMenuGroupType;
};
export declare type MainMenuGroup = ComponentType<MainMenuGroupProps>;
