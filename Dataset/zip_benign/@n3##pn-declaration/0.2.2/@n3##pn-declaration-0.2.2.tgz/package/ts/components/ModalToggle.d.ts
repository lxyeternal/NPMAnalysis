import type { ComponentType, ReactNode } from 'react';
import type { ModalProps } from './Modal';
export declare type ModalToggleRenderProps = {
    show: boolean;
    onClick: () => void;
};
export declare type ModalToggleProps = {
    renderToggle: (renderProps: ModalToggleRenderProps) => ReactNode;
    renderModal: (modalRenderProps: {
        onHide: () => void;
    }) => ReactNode;
    modalProps?: ModalProps;
};
export declare type ModalToggle = ComponentType<ModalToggleProps>;
