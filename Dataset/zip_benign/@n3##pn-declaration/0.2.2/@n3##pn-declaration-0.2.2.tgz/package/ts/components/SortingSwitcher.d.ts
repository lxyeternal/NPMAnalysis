import type { ComponentType, ReactNode } from 'react';
export declare type SortingSwitcherProps = {
    children?: ReactNode;
    param: string;
    isCurrent?: boolean;
    isAsc?: boolean;
    onSortChange?: (param: string, isAsc: boolean) => void;
};
export declare type SortingSwitcher = ComponentType<SortingSwitcherProps>;
