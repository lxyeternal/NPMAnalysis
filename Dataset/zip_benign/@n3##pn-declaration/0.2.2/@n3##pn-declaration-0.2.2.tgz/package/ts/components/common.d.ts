import type { ReactNode } from 'react';
export declare type ButtonColor = 'gradient' | 'primary' | 'primary-bordered' | 'dark-bordered' | 'success' | 'success-bordered' | 'danger' | 'danger-bordered';
export declare type SizeType = 'default' | 'small';
export declare type CardSizeType = 'default' | 'small';
export declare type MainMenuLinkType = {
    label: ReactNode;
    url: string;
    isSimpleLink?: boolean;
    target?: string;
};
export declare type MainMenuGroupType = {
    icon: string;
    label: ReactNode;
    links: MainMenuLinkType[];
};
