import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type MainMenuWrapper = StyledComponent<'div', ContextThemeType, {}, never>;
