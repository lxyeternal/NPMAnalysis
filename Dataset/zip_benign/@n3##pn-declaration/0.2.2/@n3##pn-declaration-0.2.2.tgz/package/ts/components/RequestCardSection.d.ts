import type { ReactNode, ComponentType, PropsWithChildren } from 'react';
export declare type RequestCardSectionProps = PropsWithChildren<{
    title?: ReactNode;
}>;
export declare type RequestCardSection = ComponentType<RequestCardSectionProps>;
