import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type MainMenuLinksGrid = StyledComponent<'div', ContextThemeType, {}, never>;
