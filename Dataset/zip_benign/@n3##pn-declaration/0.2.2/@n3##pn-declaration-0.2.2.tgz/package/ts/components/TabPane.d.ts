import type { ComponentType } from 'react';
import type { TabPaneProps } from 'rc-tabs';
export type { TabPaneProps, };
export declare type TabPane = ComponentType<TabPaneProps>;
