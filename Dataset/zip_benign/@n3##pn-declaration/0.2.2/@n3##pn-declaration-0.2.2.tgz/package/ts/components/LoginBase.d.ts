import type { ComponentType, ReactNode } from 'react';
export declare type LoginBaseProps = {
    className?: string;
    children?: ReactNode;
};
export declare type LoginBase = ComponentType<LoginBaseProps>;
