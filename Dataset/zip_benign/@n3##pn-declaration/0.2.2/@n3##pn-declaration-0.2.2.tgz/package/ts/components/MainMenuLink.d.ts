import type { ComponentType } from 'react';
import { MainMenuLinkType } from './common';
export declare type MainMenuLinkProps = {
    link: MainMenuLinkType;
};
export declare type MainMenuLink = ComponentType<MainMenuLinkProps>;
