import type { ComponentType } from 'react';
import type { TabsProps } from 'rc-tabs';
export type { TabsProps, };
export declare type Tabs = ComponentType<TabsProps>;
