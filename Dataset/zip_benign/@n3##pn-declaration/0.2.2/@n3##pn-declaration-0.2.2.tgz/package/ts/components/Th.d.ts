import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type Th = StyledComponent<'th', ContextThemeType, {}, never>;
