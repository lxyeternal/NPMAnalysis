import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type ListPlaceholder = StyledComponent<'div', ContextThemeType, {}, never>;
