import type { ComponentType, ReactNode } from 'react';
export declare type CardBottomInfoProps = {
    info: ReactNode[];
};
export declare type CardBottomInfo = ComponentType<CardBottomInfoProps>;
