import type { ComponentType, ReactNode } from 'react';
export declare type CardInfoProps = {
    children?: ReactNode;
};
export declare type CardInfo = ComponentType<CardInfoProps>;
