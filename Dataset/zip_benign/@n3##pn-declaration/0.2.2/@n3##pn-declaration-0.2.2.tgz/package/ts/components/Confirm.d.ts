import type { ComponentType, ReactNode } from 'react';
import type { ButtonColor } from './common';
export declare type ConfirmProps = {
    /**
     * Заголовок
     */
    title?: string;
    /**
     * Текст
     */
    content?: ReactNode;
    /**
     * Ошибка подтверждения
     */
    error?: ReactNode;
    /**
     * Текст кнопки отмены
     */
    cancelButtonText?: ReactNode;
    /**
     * Текст кнопки подтвеждения
     */
    approveButtonText?: ReactNode;
    /**
     * Цвет кнопки подтверждения
     */
    approveButtonColor?: ButtonColor;
    /**
     * Скрыть кнопку отмены (для использования как alert)
     */
    hideCancelButton?: boolean;
    /**
     * Кнопки выключены (в случае асинхронного подтверждения)
     */
    isButtonsDisabled: boolean;
    onApproveClick: () => void;
    onCancelClick: () => void;
};
export declare type Confirm = ComponentType<ConfirmProps>;
