import type { ComponentType, ReactNode } from 'react';
export declare type DetailHeaderProps = {
    backTitle?: ReactNode;
    backTo?: string;
    backgroundImage?: string;
    isBackgroundFull?: boolean;
    children?: ReactNode;
    actionsBlock?: ReactNode;
};
export declare type DetailHeader = ComponentType<DetailHeaderProps>;
