import type { ComponentType, ReactNode } from 'react';
export declare type CardButtonWithCounterType = {
    button: ReactNode;
    counter?: ReactNode;
};
export declare type CardButtonsWithCountersProps = {
    items: CardButtonWithCounterType[];
};
export declare type CardButtonsWithCounters = ComponentType<CardButtonsWithCountersProps>;
