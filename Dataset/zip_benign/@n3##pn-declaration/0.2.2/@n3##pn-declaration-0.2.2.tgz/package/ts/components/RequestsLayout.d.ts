import type { ComponentType, ReactNode } from 'react';
export declare type RequestsLayoutProps = {
    sidebar?: ReactNode;
    filters?: ReactNode;
    detail?: ReactNode;
};
export declare type RequestsLayout = ComponentType<RequestsLayoutProps>;
