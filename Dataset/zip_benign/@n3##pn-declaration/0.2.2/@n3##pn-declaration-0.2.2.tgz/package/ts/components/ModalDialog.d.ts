import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type ModalDialog = StyledComponent<'div', ContextThemeType, {}, never>;
