import type { ComponentType, ReactNode } from 'react';
export declare type ListHeaderProps = {
    backTitle?: ReactNode;
    backTo?: string;
    title: ReactNode;
    isFavorite?: boolean;
    isShowOnMap?: boolean;
    canToggleFavorite?: boolean;
    canShowOnMap?: boolean;
    onChangeIsFavorite?: (nextValue: boolean) => void;
    onChangeShowOnMap?: (nextValue: boolean) => void;
    mapBlock?: ReactNode;
};
export declare type ListHeader = ComponentType<ListHeaderProps>;
