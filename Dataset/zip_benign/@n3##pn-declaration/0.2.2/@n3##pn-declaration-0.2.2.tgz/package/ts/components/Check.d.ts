import type { ComponentType } from 'react';
export declare type CheckProps = {
    checked?: boolean;
};
export declare type Check = ComponentType<CheckProps>;
