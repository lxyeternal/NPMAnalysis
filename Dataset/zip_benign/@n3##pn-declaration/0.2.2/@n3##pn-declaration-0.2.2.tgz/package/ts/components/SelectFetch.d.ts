import type { ReactElement } from 'react';
import type { GroupBase } from 'react-select';
import type { ComponentProps } from 'react-select-async-paginate';
import type { UseSelectFetchParams } from 'react-select-fetch';
import type { SelectProps } from './Select';
export declare type SelectFetchProps<OptionType, Group extends GroupBase<OptionType>, IsMulti extends boolean> = SelectProps<OptionType, IsMulti, Group> & UseSelectFetchParams<OptionType, Group> & ComponentProps<OptionType, Group, IsMulti>;
export declare type SelectFetch = <OptionType, Group extends GroupBase<OptionType>, IsMulti extends boolean = false>(props: SelectFetchProps<OptionType, Group, IsMulti>) => ReactElement;
