import type { StyledComponent } from 'styled-components';
import type { SizeType } from './common';
import type { ContextThemeType } from '../theme';
export declare type InputProps = {
    $size?: SizeType;
    $hasError?: boolean;
    $hasLeftIcon?: boolean;
    $hasRightIcon?: boolean;
};
export declare type Input = StyledComponent<'input', ContextThemeType, InputProps, never>;
