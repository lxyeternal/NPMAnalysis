import type { HTMLProps, ComponentType } from 'react';
import type { SizeType } from './common';
export declare type SearchInputProps = Omit<HTMLProps<HTMLInputElement>, 'ref' | 'as'> & {
    $size?: SizeType;
    onClear?: () => void;
};
export declare type SearchInput = ComponentType<SearchInputProps>;
