import type { ComponentType } from 'react';
import type { SidebarItemContentProps } from './SidebarItemContent';
import type { SidebarItemWrapperProps } from './SidebarItemWrapper';
export declare type SidebarItemProps = SidebarItemWrapperProps & SidebarItemContentProps & {
    href?: string;
    to?: string;
    target?: string;
    onClick?: () => void;
};
export declare type SidebarItem = ComponentType<SidebarItemProps>;
