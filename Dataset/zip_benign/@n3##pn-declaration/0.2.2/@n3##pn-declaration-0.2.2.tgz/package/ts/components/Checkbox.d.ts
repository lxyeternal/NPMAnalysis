import type { ComponentType, HTMLProps, ReactNode } from 'react';
export declare type CheckboxProps = Omit<HTMLProps<HTMLInputElement>, 'ref' | 'as'> & {
    renderBox?: (renderProps: {
        checked: boolean;
    }) => ReactNode;
    children?: ReactNode;
};
export declare type Checkbox = ComponentType<CheckboxProps>;
