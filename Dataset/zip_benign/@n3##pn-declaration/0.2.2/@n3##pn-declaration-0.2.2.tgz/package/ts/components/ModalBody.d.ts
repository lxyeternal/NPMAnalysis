import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type ModalBody = StyledComponent<'div', ContextThemeType, {}, never>;
