import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type RequestCardTitle = StyledComponent<'div', ContextThemeType, {}, never>;
