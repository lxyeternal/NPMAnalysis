import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type RequestCardWrapper = StyledComponent<'div', ContextThemeType, {}, never>;
