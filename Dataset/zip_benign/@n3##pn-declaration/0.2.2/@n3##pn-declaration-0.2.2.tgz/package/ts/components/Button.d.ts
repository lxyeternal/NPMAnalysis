import type { StyledComponent } from 'styled-components';
import type { ButtonColor, SizeType } from './common';
import type { ContextThemeType } from '../theme';
export declare type ButtonProps = {
    $block?: boolean;
    $color?: ButtonColor;
    $size?: SizeType;
};
export declare type Button = StyledComponent<'button', ContextThemeType, ButtonProps, never>;
