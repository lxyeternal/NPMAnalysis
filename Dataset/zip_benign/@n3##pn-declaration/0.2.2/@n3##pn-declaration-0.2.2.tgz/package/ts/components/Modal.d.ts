import type { ComponentType } from 'react';
import type { ModalProps as BaseModalProps } from 'react-overlays/Modal';
export declare type ModalProps = BaseModalProps & {
    hasCloseButton?: boolean;
    isHideOnBackdropClick?: boolean;
};
export declare type Modal = ComponentType<ModalProps>;
