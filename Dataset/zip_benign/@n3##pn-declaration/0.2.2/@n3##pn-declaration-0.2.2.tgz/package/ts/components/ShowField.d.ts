import type { ReactNode, ComponentType, PropsWithChildren } from 'react';
export declare type ShowFieldProps = PropsWithChildren<{
    label?: ReactNode;
}>;
export declare type ShowField = ComponentType<ShowFieldProps>;
