import type { ComponentType, ReactNode } from 'react';
export declare type LogoutBaseProps = {
    className?: string;
    children?: ReactNode;
};
export declare type LogoutBase = ComponentType<LogoutBaseProps>;
