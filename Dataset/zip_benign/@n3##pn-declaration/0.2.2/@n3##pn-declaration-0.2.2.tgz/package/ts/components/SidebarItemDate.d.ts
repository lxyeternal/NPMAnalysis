import type { ComponentType, PropsWithChildren } from 'react';
export declare type SidebarItemDateProps = PropsWithChildren;
export declare type SidebarItemDate = ComponentType<SidebarItemDateProps>;
