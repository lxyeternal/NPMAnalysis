import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type LogoLink = StyledComponent<'a', ContextThemeType, {}, never>;
