import type { ComponentType, ReactNode } from 'react';
export declare type HeaderInnerWrapperProps = {
    logo: ReactNode;
    controls: ReactNode;
};
export declare type HeaderInnerWrapper = ComponentType<HeaderInnerWrapperProps>;
