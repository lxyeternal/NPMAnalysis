import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type ListGrid = StyledComponent<'div', ContextThemeType, {}, never>;
