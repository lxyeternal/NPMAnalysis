import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type ButtonToolbar = StyledComponent<'div', ContextThemeType, {}, never>;
