import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type SidebarItemsWrapper = StyledComponent<'div', ContextThemeType, {}, never>;
