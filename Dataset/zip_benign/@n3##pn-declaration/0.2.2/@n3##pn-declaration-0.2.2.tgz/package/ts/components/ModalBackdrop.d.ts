import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type ModalBackdrop = StyledComponent<'div', ContextThemeType, {}, never>;
