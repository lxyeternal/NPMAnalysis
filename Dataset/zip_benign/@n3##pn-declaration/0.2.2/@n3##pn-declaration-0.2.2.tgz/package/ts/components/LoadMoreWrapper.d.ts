import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type LoadMoreWrapper = StyledComponent<'div', ContextThemeType, {}, never>;
