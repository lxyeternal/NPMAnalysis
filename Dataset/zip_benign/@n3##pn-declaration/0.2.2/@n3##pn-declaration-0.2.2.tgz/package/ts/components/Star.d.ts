import type { ComponentType } from 'react';
export declare type StarProps = {
    checked?: boolean;
};
export declare type Star = ComponentType<StarProps>;
