import type { ComponentType, ComponentProps, ReactNode } from 'react';
import type { Button } from './Button';
import type { ModalProps } from './Modal';
export declare type ModalButtonProps = ComponentProps<Button> & {
    renderModal: (modalRenderProps: {
        onHide: () => void;
    }) => ReactNode;
    modalProps?: ModalProps;
};
export declare type ModalButton = ComponentType<ModalButtonProps>;
