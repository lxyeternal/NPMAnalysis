import type { ComponentType } from 'react';
import type { TooltipProps } from './Tooltip';
export declare type HintProps = Omit<TooltipProps, 'children'> & {
    className?: string;
};
export declare type Hint = ComponentType<HintProps>;
