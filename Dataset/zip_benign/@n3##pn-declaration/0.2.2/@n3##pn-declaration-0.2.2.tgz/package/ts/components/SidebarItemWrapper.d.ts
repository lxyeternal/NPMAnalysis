import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type SidebarItemWrapperProps = {
    $isActive: boolean;
};
export declare type SidebarItemWrapper = StyledComponent<'div', ContextThemeType, SidebarItemWrapperProps, never>;
