import type { GlobalStyleComponent } from 'styled-components';
import type { ColorsType, ContextThemeType } from '../theme';
export declare type BodyBgColorProps = {
    $bgColor: keyof ColorsType;
    theme: ContextThemeType;
};
export declare type BodyBgColor = GlobalStyleComponent<BodyBgColorProps, ContextThemeType>;
