import type { ComponentType } from 'react';
import type { PaginatorProps } from '@vtaits/react-paginator';
export { PaginatorProps };
export declare type Paginator = ComponentType<PaginatorProps>;
