import type { ComponentType } from 'react';
export declare type HeaderLogo = ComponentType;
