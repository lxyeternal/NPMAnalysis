import type { ComponentType } from 'react';
export declare type PublishedIndicatorProps = {
    /**
     * Сущность опубликована
     */
    isPublished: boolean;
};
export declare type PublishedIndicator = ComponentType<PublishedIndicatorProps>;
