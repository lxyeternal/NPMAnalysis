import type { ComponentType } from 'react';
export declare type PhoneLinkProps = {
    phone: string;
    className?: string;
};
export declare type PhoneLink = ComponentType<PhoneLinkProps>;
