import type { ComponentType } from 'react';
export declare type ModalCloseButtonProps = {
    onClick: () => void;
};
export declare type ModalCloseButton = ComponentType<ModalCloseButtonProps>;
