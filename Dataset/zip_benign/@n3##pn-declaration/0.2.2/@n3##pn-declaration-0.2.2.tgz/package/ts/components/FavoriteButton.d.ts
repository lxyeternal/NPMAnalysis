import type { ComponentType, ReactNode } from 'react';
export declare type FavoriteButtonSettings = {
    /**
     * Заголовок кнопки, когда элемент добавлен в избранное
     */
    addedLabel: ReactNode;
    /**
     * Заголовок кнопки, когда элемент не добавлен в избранное
     */
    notAddedLabel: ReactNode;
};
export declare type FavoriteButtonProps = {
    isAdded: boolean;
    disabled?: boolean;
    onChange: (nextValue: boolean) => void;
};
export declare type FavoriteButton = ComponentType<FavoriteButtonProps>;
