import type { ComponentType, PropsWithChildren } from 'react';
import type { CardSizeType } from './common';
export declare type CardWrapperProps = PropsWithChildren<{
    /**
     * Ссылка
     */
    linkTo?: string;
    /**
     * Размер
     */
    size?: CardSizeType;
    /**
     * Фоновое изображение
     */
    backgroundImage?: string;
}>;
export declare type CardWrapper = ComponentType<CardWrapperProps>;
