import type { ComponentType, ReactNode } from 'react';
export declare type SidebarItemContentProps = {
    date?: ReactNode;
    status?: ReactNode;
    statusColor?: string;
    title?: ReactNode;
    description?: ReactNode;
};
export declare type SidebarItemContent = ComponentType<SidebarItemContentProps>;
