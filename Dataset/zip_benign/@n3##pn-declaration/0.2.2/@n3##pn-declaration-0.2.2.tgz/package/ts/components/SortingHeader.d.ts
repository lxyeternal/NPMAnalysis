import type { ComponentType, ReactNode } from 'react';
export declare type SortingHeaderProps = {
    children?: ReactNode;
    param?: string;
    isSortable?: boolean;
    isCurrent?: boolean;
    isAsc?: boolean;
    onSortChange?: (param: string, isAsc: boolean) => void;
};
export declare type SortingHeader = ComponentType<SortingHeaderProps>;
