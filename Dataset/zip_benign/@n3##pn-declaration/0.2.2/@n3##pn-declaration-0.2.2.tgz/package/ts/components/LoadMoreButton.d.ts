import type { ComponentType } from 'react';
export declare type LoadMoreButtonProps = {
    onClick?: () => void;
    disabled?: boolean;
    totalCount?: number;
    loadedCount?: number;
    pageSize?: number;
};
export declare type LoadMoreButton = ComponentType<LoadMoreButtonProps>;
