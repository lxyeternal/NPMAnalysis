import type { ReactElement } from 'react';
import type { GroupBase } from 'react-select';
import type { ComponentProps, UseAsyncPaginateParams } from 'react-select-async-paginate';
import type { SelectProps } from './Select';
export declare type AsyncPaginateProps<OptionType, Group extends GroupBase<OptionType>, Additional, IsMulti extends boolean> = SelectProps<OptionType, IsMulti, Group> & UseAsyncPaginateParams<OptionType, Group, Additional> & ComponentProps<OptionType, Group, IsMulti>;
export declare type SelectAsyncPaginate = <OptionType, Group extends GroupBase<OptionType>, Additional, IsMulti extends boolean = false>(props: AsyncPaginateProps<OptionType, Group, Additional, IsMulti>) => ReactElement;
