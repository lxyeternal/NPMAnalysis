import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type HeaderWrapperProps = {
    $menuIsOpen: boolean;
};
export declare type HeaderWrapper = StyledComponent<'header', ContextThemeType, HeaderWrapperProps, never>;
