import type { ReactElement } from 'react';
import type { GroupBase, Props as BaseSelectProps } from 'react-select';
import type { SizeType } from './common';
export interface SelectProps<OptionType, IsMulti extends boolean, Group extends GroupBase<OptionType>> extends BaseSelectProps<OptionType, IsMulti, Group> {
    valueKey?: string;
    labelKey?: string;
    $size?: SizeType;
    $hasError?: boolean;
}
export declare type Select = <OptionType, IsMulti extends boolean = false, Group extends GroupBase<OptionType> = GroupBase<OptionType>>(props: SelectProps<OptionType, IsMulti, Group>) => ReactElement;
