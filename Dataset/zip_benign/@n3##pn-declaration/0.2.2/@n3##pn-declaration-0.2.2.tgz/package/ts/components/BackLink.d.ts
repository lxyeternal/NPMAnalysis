import type { ComponentProps, ComponentType } from 'react';
import { Link } from 'react-router-dom';
export declare type BackLink = ComponentType<ComponentProps<Link>>;
