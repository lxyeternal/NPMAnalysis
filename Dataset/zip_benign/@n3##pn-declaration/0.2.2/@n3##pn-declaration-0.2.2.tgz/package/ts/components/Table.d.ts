import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type Table = StyledComponent<'table', ContextThemeType, {}, never>;
