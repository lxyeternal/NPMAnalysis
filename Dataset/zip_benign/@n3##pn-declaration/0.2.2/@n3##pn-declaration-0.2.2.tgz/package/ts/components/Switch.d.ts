import type { ComponentType } from 'react';
export declare type SwitchProps = {
    checked?: boolean;
};
export declare type Switch = ComponentType<SwitchProps>;
