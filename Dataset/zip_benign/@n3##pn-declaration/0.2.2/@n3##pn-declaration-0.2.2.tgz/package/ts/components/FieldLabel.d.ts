import type { ComponentType, ReactNode } from 'react';
export declare type FieldLabelProps = {
    className?: string;
    htmlFor?: string;
    hint?: ReactNode;
    children?: ReactNode;
};
export declare type FieldLabel = ComponentType<FieldLabelProps>;
