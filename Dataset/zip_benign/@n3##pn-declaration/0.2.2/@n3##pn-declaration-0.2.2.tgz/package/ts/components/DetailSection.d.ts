import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type DetailSection = StyledComponent<'div', ContextThemeType, {}, never>;
