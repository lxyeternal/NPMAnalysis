import type { ComponentType, CSSProperties, HTMLProps, ReactNode, Ref } from 'react';
import type { Options, Placement } from '@popperjs/core';
export declare type TooltipRenderProps = {
    innerProps: HTMLProps<HTMLDivElement>;
    isOpen: boolean;
    ref: Ref<HTMLElement>;
};
export declare type TooltipProps = {
    /**
     * Контент тултипа
     */
    tooltip: ReactNode;
    /**
     * Расположение popper-компонента
     */
    placement?: Placement;
    /**
     * Дополнительные стили popper-компонента
     */
    popperStyle?: CSSProperties;
    /**
     * Дополнительные опции popper-компонента
     */
    popperProps?: Partial<Omit<Options, 'placement' | 'modifiers'>>;
    /**
     * Функция рендера тултипа
     * @param {Object} renderProps
     * @param {Object} renderProps.ref - ref dom-элемента, открывающего тултип
     * @param {Object} renderProps.innerProps - props, которые должны переданы
     * dom-элементу, открывающему тултип
     * @param {boolean} renderProps.isOpen - открыт ли тултип
     */
    children: (renderProps: TooltipRenderProps) => ReactNode;
};
export declare type Tooltip = ComponentType<TooltipProps>;
