import type { ReactElement } from 'react';
import type { GroupBase } from 'react-select';
import type { CreatableProps as BaseCreatableProps } from 'react-select/creatable';
import type { SizeType } from './common';
export interface CreatableProps<OptionType, IsMulti extends boolean, Group extends GroupBase<OptionType>> extends BaseCreatableProps<OptionType, IsMulti, Group> {
    valueKey?: string;
    labelKey?: string;
    $size?: SizeType;
    $hasError?: boolean;
}
export declare type Creatable = <OptionType, IsMulti extends boolean = false, Group extends GroupBase<OptionType> = GroupBase<OptionType>>(props: CreatableProps<OptionType, IsMulti, Group>) => ReactElement;
