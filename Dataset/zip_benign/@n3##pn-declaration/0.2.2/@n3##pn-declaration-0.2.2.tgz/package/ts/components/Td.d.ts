import type { StyledComponent } from 'styled-components';
import type { ContextThemeType } from '../theme';
export declare type Td = StyledComponent<'td', ContextThemeType, {}, never>;
