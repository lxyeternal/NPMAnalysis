import type { ComponentType, ReactElement } from 'react';
import type Filterlist from '@vtaits/filterlist';
import type { ListState } from '@vtaits/filterlist';
declare type AdditionalType = {
    hasMore: boolean;
    count?: number;
};
export declare type RequestsListViewProps<SidebarItemType> = {
    baseUrl: string;
    selectedRequestId?: string | number;
    pageSize?: number;
    listState: ListState<SidebarItemType, AdditionalType, unknown>;
    filterlist: Filterlist<SidebarItemType, AdditionalType, unknown>;
    sidebarItemComponent: ComponentType<{
        request: SidebarItemType;
        isCurrent: boolean;
    }>;
    detailComponent: ComponentType<{
        requestId: string | number;
        reloadList: () => void;
    }>;
    getRequestId?: (request: SidebarItemType) => string | number;
};
declare function RequestsListViewComponent<SidebarItemType>(props: RequestsListViewProps<SidebarItemType>): ReactElement;
export declare type RequestsListView = typeof RequestsListViewComponent;
export {};
