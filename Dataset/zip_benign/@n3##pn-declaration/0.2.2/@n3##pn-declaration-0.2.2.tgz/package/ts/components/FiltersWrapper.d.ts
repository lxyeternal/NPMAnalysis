import type { ComponentType, ReactNode } from 'react';
export declare type FiltersWrapperProps = {
    children?: ReactNode;
};
export declare type FiltersWrapper = ComponentType<FiltersWrapperProps>;
