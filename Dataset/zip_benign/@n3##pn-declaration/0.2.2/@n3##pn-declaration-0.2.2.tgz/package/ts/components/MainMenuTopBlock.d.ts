import type { ChangeEventHandler, ComponentType, SyntheticEvent } from 'react';
export declare type MainMenuTopBlockProps = {
    hasSearchInput: boolean;
    searchValue: string;
    onSearchChange: ChangeEventHandler<HTMLInputElement>;
    onSearchSubmit: (event: SyntheticEvent) => void;
    isAuthorized: boolean;
};
export declare type MainMenuTopBlock = ComponentType<MainMenuTopBlockProps>;
