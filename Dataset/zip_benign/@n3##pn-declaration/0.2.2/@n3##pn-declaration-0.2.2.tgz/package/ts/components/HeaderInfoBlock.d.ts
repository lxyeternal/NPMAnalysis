import type { ComponentType, ReactNode } from 'react';
export declare type HeaderInfoBlockProps = {
    icon?: ReactNode;
    children?: ReactNode;
};
export declare type HeaderInfoBlock = ComponentType<HeaderInfoBlockProps>;
