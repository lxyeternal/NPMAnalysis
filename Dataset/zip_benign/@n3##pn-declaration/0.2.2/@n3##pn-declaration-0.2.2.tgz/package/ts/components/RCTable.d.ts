import type { ReactElement } from 'react';
import type { TableProps } from 'rc-table/lib/Table';
import type { ColumnType, ColumnGroupType } from 'rc-table/lib/interface';
export declare type ExtendedColumnType<RecordType> = ColumnType<RecordType> & {
    canSort?: boolean;
};
export declare type ExtendedColumnsType<RecordType = unknown> = readonly (ColumnGroupType<RecordType> | ExtendedColumnType<RecordType>)[];
export declare type RCTableProps<RecordType> = Omit<TableProps<RecordType>, 'columns'> & {
    columns: ExtendedColumnsType<RecordType>;
    sortParam?: string;
    isSortAsc?: boolean;
    onSortChange?: (param: string, isAsc: boolean) => void;
};
declare function RCTableComponent<RecordType>(props: RCTableProps<RecordType>): ReactElement;
export declare type RCTable = typeof RCTableComponent;
export {};
