export declare type AuthSettings = {
    loginUrl: string;
    logoutUrl: string;
};
