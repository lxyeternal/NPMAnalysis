import type { ReactNode } from 'react';
export declare type ConfirmSettings = {
    defaultApproveButtonText: ReactNode;
    defaultCancelButtonText: ReactNode;
};
