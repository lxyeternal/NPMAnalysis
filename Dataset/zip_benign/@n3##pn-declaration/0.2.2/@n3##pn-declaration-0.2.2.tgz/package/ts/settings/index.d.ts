import type { FavoriteButtonSettings } from '../components/FavoriteButton';
import { AuthSettings } from './auth';
import { ConfirmSettings } from './confirm';
import { HeaderSettings } from './header';
import { UrlsSettings } from './urls';
export declare type Settings = {
    /**
     * Настройки авторизации
     */
    auth: AuthSettings;
    /**
     * Настройки окна подтверждения
     */
    confirm: ConfirmSettings;
    /**
     * Настройки компонента FavoriteButton
     */
    FavoriteButton: FavoriteButtonSettings;
    /**
     * Настройки шапки
     */
    header: HeaderSettings;
    /**
     * Адреса основных страниц
     */
    urls: UrlsSettings;
};
