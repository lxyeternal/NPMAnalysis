export declare type UrlsSettings = {
    /**
     * Личный кабинет
     */
    cabinet: string;
};
