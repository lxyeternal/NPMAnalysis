import type { ReactNode } from 'react';
export declare type HeaderSettings = {
    logoDesktop?: string;
    logoMobile?: string;
    logoTitle?: string;
    cabinetLabel?: ReactNode;
};
