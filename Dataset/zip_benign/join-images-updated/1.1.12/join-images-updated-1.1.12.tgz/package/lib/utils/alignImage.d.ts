export default function alignImage(total: any, size: any, align: any): number;
