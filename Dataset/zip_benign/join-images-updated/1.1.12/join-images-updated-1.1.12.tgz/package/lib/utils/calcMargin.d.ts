interface Dim {
    top?: number;
    right?: number;
    bottom?: number;
    left?: number;
}
export default function calcMargin(obj?: Dim | string | number): Dim;
export {};
