# tailwind-lite

Still working in progress...

<hr />

- import pure css, no postcss or sass needed
- customizable via css variables
- compatible with no-browser environment, such as *wechat miniprogram*

## Installation

```
npm i tailwind-lite
```

## Usage

```ts
import 'tailwind-lite'

// begin your magic
```

## Note

Currently, all the `/` in class names should be replaced by  `o`, and all the `.` should be replaced by `p` for some reasons,for example:

```html
<!-- won't work -->
<div class="w-1/2"></div>
<div class="gap-0.5"></div>
```

should be written like this:

```html
<!-- will work -->
<div class="w-1o2"></div>
<div class="gap-0p5"></div>
```