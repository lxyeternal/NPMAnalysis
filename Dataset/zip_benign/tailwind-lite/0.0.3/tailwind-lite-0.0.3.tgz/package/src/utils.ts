export function getComment(comment: string) {
    return `\n/* ${comment} */\n\n`
}

export function getOneLineRule(propertyName: string, propertyValue: string | number, options: Options = {}) {
    const className = getClassName(propertyName, propertyValue, options)
    const styleLine = getStyleLine(propertyName, propertyValue)

    return `.${className} {\n\t${styleLine}}\n`
}

export function getOneLineRules(propertyName: string, propertyValues: string[], options: Options = {}) {
    return propertyValues.map(propertyValue => {
        return getOneLineRule(propertyName, propertyValue, options)
    }).join('')
}

// private functions

interface Options {
    propertyNameInClassName?: string,
    propertyValueInClassName?: string | ((propertyValue: string | number) => string)
}

function getClassName(propertyName: string, propertyValue: string | number, options: Options = {}) {
    let propertyValueInClassName = ''
    const propertyNameInClassName = 'propertyNameInClassName' in options ? options.propertyNameInClassName : propertyName

    if ('propertyValueInClassName' in options) {
        if (typeof options.propertyValueInClassName === 'string') propertyValueInClassName = options.propertyValueInClassName
        if (typeof options.propertyValueInClassName === 'function')
            propertyValueInClassName = options.propertyValueInClassName(propertyValue)
    } else {
        if (typeof propertyValue === 'string')
            propertyValueInClassName = propertyValue.replace(/ /g, '-')
        else
            propertyValueInClassName = propertyValue.toString()
    }

    return `${propertyNameInClassName}${propertyNameInClassName === '' ? '' : '-'}${propertyValueInClassName}`
}

function getStyleLines(propertyName: string, propertyValues: string[]) {
    return propertyValues.map(propertyValue => {
        return getStyleLine(propertyName, propertyValue)
    }).join('')
}

function getStyleLine(propertyName: string, propertyValue: string | number) {
    return `${propertyName}: ${propertyValue};\n`
}