import * as fs from 'fs';
import * as path from 'path';
import { getComment, getOneLineRules, getOneLineRule } from './utils';


const filePath = path.join(__dirname, '../dist/layout.css')

let rules = ''

rules += getComment('Container')
rules += getOneLineRule('width', '100%', { propertyNameInClassName: '', propertyValueInClassName: 'container' })

rules += getComment('Box Sizing')
rules += getOneLineRule('box-sizing', 'border-box', { propertyNameInClassName: 'box', propertyValueInClassName: 'border' })
rules += getOneLineRule('box-sizing', 'content-box', { propertyNameInClassName: 'box', propertyValueInClassName: 'content' })

rules += getComment('Display')
rules += getOneLineRules('display', ['block', 'inline-block', 'inline', 'flex', 'inline-flex', 'table', 'table-caption', 'table-cell', 'table-column', 'table-column-group', 'table-footer-group', 'table-header-group', 'table-row-group', 'table-row', 'flow-root', 'grid', 'inline-grid', 'contents'], { propertyNameInClassName: '' })
rules += getOneLineRule('display', 'none', { propertyNameInClassName: '', propertyValueInClassName: 'hidden' })

rules += getComment('Floats')
rules += getOneLineRules('float', ['right', 'left', 'none'])

rules += getComment('Clear')
rules += getOneLineRules('clear', ['right', 'left', 'both', 'none'])

rules += getComment('Object Fit')
rules += getOneLineRules('object-fit', ['contain', 'cover', 'fill', 'none', 'scale-down'], { propertyNameInClassName: 'object' })

rules += getComment('Object Position')
rules += getOneLineRules('object-position', ['bottom', 'center', 'left', 'left bottom', 'left top', 'right', 'right bottom', 'right top', 'top'], { propertyNameInClassName: 'object' })

rules += getComment('Overflow')
rules += getOneLineRules('overflow', ['auto', 'hidden', 'visible', 'scroll'])
rules += getOneLineRules('overflow-x', ['auto', 'hidden', 'visible', 'scroll'])
rules += getOneLineRules('overflow-y', ['auto', 'hidden', 'visible', 'scroll'])

rules += getComment('Overscroll Behavior')
rules += getOneLineRules('overscroll-behavior', ['auto', 'contain', 'none'], { propertyNameInClassName: 'overscroll' })
rules += getOneLineRules('overscroll-behavior-x', ['auto', 'contain', 'none'], { propertyNameInClassName: 'overscroll-x' })
rules += getOneLineRules('overscroll-behavior-y', ['auto', 'contain', 'none'], { propertyNameInClassName: 'overscroll-y' })

rules += getComment('Position')
rules += getOneLineRules('position', ['static', 'fixed', 'absolute', 'relative', 'sticky'], { propertyNameInClassName: '' })

rules += getComment('Top/Right/Bottom/Left')
const propertyValues = ['0px']
for (let i = 1; i <= 192;) {
    propertyValues.push(0.125 * i + 'rem')
    if (i < 8) {
        i++
    } else if (i < 24) {
        i += 2
    } else if (i < 32) {
        i += 4
    } else if (i < 128) {
        i += 8
    } else if (i < 160) {
        i += 16
    } else if (i < 192) {
        i += 32
    } else {
        break
    }
}
let propertyValueInClassName = propertyValue => ((parseFloat(propertyValue) * 4).toString().replace('.', 'p'))
rules += getOneLineRules('top', propertyValues, { propertyValueInClassName })
rules += getOneLineRules('right', propertyValues, { propertyValueInClassName })
rules += getOneLineRules('bottom', propertyValues, { propertyValueInClassName })
rules += getOneLineRules('left', propertyValues, { propertyValueInClassName })

rules += getComment('Visibility')
rules += getOneLineRule('visibility', 'visible', { propertyNameInClassName: '' })
rules += getOneLineRule('visibility', 'hidden', { propertyNameInClassName: '', propertyValueInClassName: 'invisible' })

rules += getComment('Z-Index')
for (let i = 0; i <= 50; i += 10) {
    rules += getOneLineRule('z-index', i, { propertyNameInClassName: 'z' })

}
rules += getOneLineRule('z-index', 'auto', { propertyNameInClassName: 'z' })

fs.writeFileSync(filePath, rules)