export * from "./lib/image-resizer-cropper.component";
export * from "./lib/image-resizer-cropper.module";
