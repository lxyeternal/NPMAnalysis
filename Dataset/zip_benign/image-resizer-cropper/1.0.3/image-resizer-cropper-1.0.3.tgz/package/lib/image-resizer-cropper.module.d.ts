export declare class ImageResizerCropperModule {
}
