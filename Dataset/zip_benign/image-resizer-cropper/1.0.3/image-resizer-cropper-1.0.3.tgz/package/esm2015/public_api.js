/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/*
 * Public API Surface of image-resizer-cropper
 */
export { ImageResizerCropperComponent } from "./lib/image-resizer-cropper.component";
export { ImageResizerCropperModule } from "./lib/image-resizer-cropper.module";

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHVibGljX2FwaS5qcyIsInNvdXJjZVJvb3QiOiJuZzovL2ltYWdlLXJlc2l6ZXItY3JvcHBlci8iLCJzb3VyY2VzIjpbInB1YmxpY19hcGkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUlBLDZDQUFjLHVDQUF1QyxDQUFDO0FBQ3RELDBDQUFjLG9DQUFvQyxDQUFDIiwic291cmNlc0NvbnRlbnQiOlsiLypcbiAqIFB1YmxpYyBBUEkgU3VyZmFjZSBvZiBpbWFnZS1yZXNpemVyLWNyb3BwZXJcbiAqL1xuXG5leHBvcnQgKiBmcm9tIFwiLi9saWIvaW1hZ2UtcmVzaXplci1jcm9wcGVyLmNvbXBvbmVudFwiO1xuZXhwb3J0ICogZnJvbSBcIi4vbGliL2ltYWdlLXJlc2l6ZXItY3JvcHBlci5tb2R1bGVcIjtcbiJdfQ==