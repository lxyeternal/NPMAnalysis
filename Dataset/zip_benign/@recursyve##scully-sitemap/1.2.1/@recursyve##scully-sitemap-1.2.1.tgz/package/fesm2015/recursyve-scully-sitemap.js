import { __awaiter } from 'tslib';
import { scullyConfig, getPluginConfig, registerPlugin, setPluginConfig } from '@scullyio/scully';
import { pathToRegexp } from 'path-to-regexp';
import { XMLParser } from 'fast-xml-parser';
import * as builder from 'xmlbuilder';
import * as path from 'path';
import * as fs from 'fs';

/**
 * The sitemap configuration options.
 */
class SitemapRoute {
}
/**
 * The sitemap configuration options.
 */
class SitemapConfig {
}
/**
 * The default configuration
 */
const defaultSitemapConfig = {
    urlPrefix: 'http://localhost',
    sitemapFilename: 'sitemap.xml',
    createRobotsFile: false,
    merge: false,
    changeFreq: 'monthly',
    priority: '0.5',
    suppressLog: false,
    trailingSlash: false
};

const SitemapPlugin = 'SitemapGenerator';
const today = new Date();
const xmlParser = new XMLParser();
const mergePaths = (base, urlPath) => {
    if (base.endsWith('/') && urlPath.startsWith('/')) {
        return `${base}${urlPath.substring(1)}`;
    }
    if (!base.endsWith('/') && !urlPath.startsWith('/')) {
        return `${base}/${urlPath}`;
    }
    return `${base}${urlPath}`;
};
const priorityForLocation = (loc, config) => {
    if (typeof config.priority === 'string' || config.priority instanceof String) {
        return config.priority;
    }
    else if (Array.isArray(config.priority)) {
        const segments = loc.split('/');
        return config.priority[segments.length - 1];
    }
    else {
        return '0.5';
    }
};
const pluralizer = (num, singular, plural) => {
    return num === 1 ? singular : plural;
};
const configForRoute = (config, route) => {
    if (config.routes) {
        // tslint:disable-next-line:forin
        for (const routePath in config.routes) {
            const routeConfig = config.routes[routePath];
            if (!!routeConfig.regexp && route.route.match(routeConfig.regexp)) {
                return {
                    route: route.route,
                    urlPrefix: routeConfig.urlPrefix || config.urlPrefix,
                    trailingSlash: routeConfig.trailingSlash || config.trailingSlash,
                    sitemapFilename: routeConfig.sitemapFilename || config.sitemapFilename,
                    merge: routeConfig.merge || config.merge,
                    changeFreq: routeConfig.changeFreq || config.changeFreq,
                    priority: routeConfig.priority || config.priority
                };
            }
        }
    }
    return {
        route: route.route,
        urlPrefix: config.urlPrefix,
        trailingSlash: config.trailingSlash,
        sitemapFilename: config.sitemapFilename,
        merge: config.merge,
        changeFreq: config.changeFreq,
        priority: config.priority
    };
};
const getSitemapFile = (filename) => {
    var _a;
    return path.join((_a = scullyConfig.outDir) !== null && _a !== void 0 ? _a : "./", filename);
};
const getRobotsFile = () => {
    var _a;
    return path.join((_a = scullyConfig.outDir) !== null && _a !== void 0 ? _a : "./", "robots.txt");
};
const loadMap = (filename) => {
    const file = getSitemapFile(filename);
    if (fs.existsSync(file)) {
        const xmlString = fs.readFileSync(file, { encoding: 'utf8', flag: 'r' });
        const xml = parseXml(xmlString);
        // build url object
        const map = {};
        for (const mappedUrl of xml.urlset.url) {
            // @ts-ignore
            map[mappedUrl.loc] = mappedUrl;
        }
        return map;
    }
    else {
        return null;
    }
};
const saveMap = (map, filename) => {
    const file = getSitemapFile(filename);
    const rootElement = builder.create('urlset').att('xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9');
    for (const route of Object.values(map)) {
        const urlElement = rootElement.ele('url');
        urlElement.ele('loc', route.loc);
        urlElement.ele('changefreq', route.changefreq);
        urlElement.ele('lastmod', route.lastmod);
        urlElement.ele('priority', route.priority);
    }
    const xml = rootElement.end({ pretty: true });
    fs.writeFileSync(file, xml);
    return rootElement;
};
const generateRobotsFile = (config) => {
    var _a, _b;
    let prefix = (_a = config.urlPrefix) !== null && _a !== void 0 ? _a : defaultSitemapConfig.urlPrefix;
    if (prefix.endsWith("/")) {
        prefix = prefix.substring(0, prefix.length - 2);
    }
    const sitemapUri = `${prefix}/${(_b = config.sitemapFilename) !== null && _b !== void 0 ? _b : defaultSitemapConfig.sitemapFilename}`;
    // TODO: Remplacer par des rules (pour supporter plusieurs directives allow / disallow).
    const allowAllGroup = [
        "User-agent: *",
        "Allow: /"
    ];
    const groups = [allowAllGroup.join("\n"), `Sitemap: ${sitemapUri}`];
    fs.writeFileSync(getRobotsFile(), groups.join("\n\n"));
};
const parseXml = (xmlString) => {
    return xmlParser.parse(xmlString);
};
const getMapForRoute = (maps, routeConfig) => {
    let map = maps[routeConfig.sitemapFilename];
    if (!map && routeConfig.merge) {
        map = loadMap(routeConfig.sitemapFilename);
    }
    if (!map) {
        map = {};
    }
    maps[routeConfig.sitemapFilename] = map;
    return map;
};
const sitemapPlugin = (routes) => __awaiter(void 0, void 0, void 0, function* () {
    const config = Object.assign({}, defaultSitemapConfig, getPluginConfig(SitemapPlugin));
    const log = (message, ...optionalParams) => {
        if (!config.suppressLog) {
            console.log(message, ...optionalParams);
        }
    };
    log(`Started @recursyve/scully-sitemap`);
    if (!routes) {
        log(`No routes were returned by Scully`);
        return;
    }
    log(`Generating sitemaps for ${routes.length} ${pluralizer(routes.length, 'route', 'routes')}.`);
    // parse route configurations
    if (config.routes) {
        Object.keys(config.routes).forEach(key => {
            // @ts-ignore
            config.routes[key].regexp = pathToRegexp(key);
        });
    }
    const maps = {};
    routes.forEach((route) => {
        var _a;
        if (config.ignoredRoutes && config.ignoredRoutes.includes(route.route)) {
            return;
        }
        const routeConfig = configForRoute(config, route);
        const map = getMapForRoute(maps, routeConfig);
        const prefix = (_a = routeConfig.urlPrefix) !== null && _a !== void 0 ? _a : defaultSitemapConfig.urlPrefix;
        let loc = mergePaths(prefix, route.route);
        if (routeConfig.trailingSlash && !loc.endsWith('/')) {
            loc = loc + '/';
        }
        map[loc] = {
            loc,
            changefreq: routeConfig.changeFreq,
            lastmod: today.toISOString(),
            priority: priorityForLocation(route.route, routeConfig)
        };
    });
    // tslint:disable-next-line: forin
    for (const filename in maps) {
        // @ts-ignore
        const rootElement = saveMap(maps[filename], filename);
        const routeCount = rootElement.children.length;
        log(`Wrote ${routeCount} ${pluralizer(routeCount, 'route', 'routes')} to ${filename}`);
    }
    if (config.createRobotsFile) {
        log('Generating robots.txt file');
        generateRobotsFile(config);
        log('Wrote robots.txt file');
    }
    log(`Finished @recursyve/scully-sitemap`);
});
const validator = () => __awaiter(void 0, void 0, void 0, function* () { return []; });
const useSitemapPlugin = (config) => {
    registerPlugin('routeDiscoveryDone', SitemapPlugin, sitemapPlugin, validator);
    setPluginConfig(SitemapPlugin, config);
};

/*
 * Public API Surface of scully-sitemap
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SitemapConfig, SitemapRoute, useSitemapPlugin };
//# sourceMappingURL=recursyve-scully-sitemap.js.map
