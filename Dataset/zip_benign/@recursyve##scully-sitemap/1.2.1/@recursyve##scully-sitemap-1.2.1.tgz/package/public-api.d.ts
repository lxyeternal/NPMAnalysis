export { useSitemapPlugin } from './lib/index';
export { SitemapConfig, SitemapRoute } from './lib/sitemap-config';
