(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@scullyio/scully'), require('path-to-regexp'), require('fast-xml-parser'), require('xmlbuilder'), require('path'), require('fs')) :
    typeof define === 'function' && define.amd ? define('@recursyve/scully-sitemap', ['exports', '@scullyio/scully', 'path-to-regexp', 'fast-xml-parser', 'xmlbuilder', 'path', 'fs'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global.recursyve = global.recursyve || {}, global.recursyve["scully-sitemap"] = {}), global.scully, global.pathToRegexp, global.fastXmlParser, global.builder, global.path, global.fs));
})(this, (function (exports, scully, pathToRegexp, fastXmlParser, builder, path, fs) { 'use strict';

    function _interopNamespace(e) {
        if (e && e.__esModule) return e;
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () { return e[k]; }
                    });
                }
            });
        }
        n["default"] = e;
        return Object.freeze(n);
    }

    var builder__namespace = /*#__PURE__*/_interopNamespace(builder);
    var path__namespace = /*#__PURE__*/_interopNamespace(path);
    var fs__namespace = /*#__PURE__*/_interopNamespace(fs);

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (Object.prototype.hasOwnProperty.call(b, p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        Object.defineProperty(o, k2, { enumerable: true, get: function () { return m[k]; } });
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, o) {
        for (var p in m)
            if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
                __createBinding(o, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    /** @deprecated */
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    /** @deprecated */
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    function __spreadArray(to, from, pack) {
        if (pack || arguments.length === 2)
            for (var i = 0, l = from.length, ar; i < l; i++) {
                if (ar || !(i in from)) {
                    if (!ar)
                        ar = Array.prototype.slice.call(from, 0, i);
                    ar[i] = from[i];
                }
            }
        return to.concat(ar || Array.prototype.slice.call(from));
    }
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n])
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k in mod)
                if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                    __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, state, kind, f) {
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a getter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot read private member from an object whose class did not declare it");
        return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
    }
    function __classPrivateFieldSet(receiver, state, value, kind, f) {
        if (kind === "m")
            throw new TypeError("Private method is not writable");
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a setter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot write private member to an object whose class did not declare it");
        return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
    }

    /**
     * The sitemap configuration options.
     */
    var SitemapRoute = /** @class */ (function () {
        function SitemapRoute() {
        }
        return SitemapRoute;
    }());
    /**
     * The sitemap configuration options.
     */
    var SitemapConfig = /** @class */ (function () {
        function SitemapConfig() {
        }
        return SitemapConfig;
    }());
    /**
     * The default configuration
     */
    var defaultSitemapConfig = {
        urlPrefix: 'http://localhost',
        sitemapFilename: 'sitemap.xml',
        createRobotsFile: false,
        merge: false,
        changeFreq: 'monthly',
        priority: '0.5',
        suppressLog: false,
        trailingSlash: false
    };

    var SitemapPlugin = 'SitemapGenerator';
    var today = new Date();
    var xmlParser = new fastXmlParser.XMLParser();
    var mergePaths = function (base, urlPath) {
        if (base.endsWith('/') && urlPath.startsWith('/')) {
            return "" + base + urlPath.substring(1);
        }
        if (!base.endsWith('/') && !urlPath.startsWith('/')) {
            return base + "/" + urlPath;
        }
        return "" + base + urlPath;
    };
    var priorityForLocation = function (loc, config) {
        if (typeof config.priority === 'string' || config.priority instanceof String) {
            return config.priority;
        }
        else if (Array.isArray(config.priority)) {
            var segments = loc.split('/');
            return config.priority[segments.length - 1];
        }
        else {
            return '0.5';
        }
    };
    var pluralizer = function (num, singular, plural) {
        return num === 1 ? singular : plural;
    };
    var configForRoute = function (config, route) {
        if (config.routes) {
            // tslint:disable-next-line:forin
            for (var routePath in config.routes) {
                var routeConfig = config.routes[routePath];
                if (!!routeConfig.regexp && route.route.match(routeConfig.regexp)) {
                    return {
                        route: route.route,
                        urlPrefix: routeConfig.urlPrefix || config.urlPrefix,
                        trailingSlash: routeConfig.trailingSlash || config.trailingSlash,
                        sitemapFilename: routeConfig.sitemapFilename || config.sitemapFilename,
                        merge: routeConfig.merge || config.merge,
                        changeFreq: routeConfig.changeFreq || config.changeFreq,
                        priority: routeConfig.priority || config.priority
                    };
                }
            }
        }
        return {
            route: route.route,
            urlPrefix: config.urlPrefix,
            trailingSlash: config.trailingSlash,
            sitemapFilename: config.sitemapFilename,
            merge: config.merge,
            changeFreq: config.changeFreq,
            priority: config.priority
        };
    };
    var getSitemapFile = function (filename) {
        var _a;
        return path__namespace.join((_a = scully.scullyConfig.outDir) !== null && _a !== void 0 ? _a : "./", filename);
    };
    var getRobotsFile = function () {
        var _a;
        return path__namespace.join((_a = scully.scullyConfig.outDir) !== null && _a !== void 0 ? _a : "./", "robots.txt");
    };
    var loadMap = function (filename) {
        var e_1, _c;
        var file = getSitemapFile(filename);
        if (fs__namespace.existsSync(file)) {
            var xmlString = fs__namespace.readFileSync(file, { encoding: 'utf8', flag: 'r' });
            var xml = parseXml(xmlString);
            // build url object
            var map = {};
            try {
                for (var _d = __values(xml.urlset.url), _e = _d.next(); !_e.done; _e = _d.next()) {
                    var mappedUrl = _e.value;
                    // @ts-ignore
                    map[mappedUrl.loc] = mappedUrl;
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_e && !_e.done && (_c = _d.return)) _c.call(_d);
                }
                finally { if (e_1) throw e_1.error; }
            }
            return map;
        }
        else {
            return null;
        }
    };
    var saveMap = function (map, filename) {
        var e_2, _c;
        var file = getSitemapFile(filename);
        var rootElement = builder__namespace.create('urlset').att('xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9');
        try {
            for (var _d = __values(Object.values(map)), _e = _d.next(); !_e.done; _e = _d.next()) {
                var route = _e.value;
                var urlElement = rootElement.ele('url');
                urlElement.ele('loc', route.loc);
                urlElement.ele('changefreq', route.changefreq);
                urlElement.ele('lastmod', route.lastmod);
                urlElement.ele('priority', route.priority);
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (_e && !_e.done && (_c = _d.return)) _c.call(_d);
            }
            finally { if (e_2) throw e_2.error; }
        }
        var xml = rootElement.end({ pretty: true });
        fs__namespace.writeFileSync(file, xml);
        return rootElement;
    };
    var generateRobotsFile = function (config) {
        var _a, _b;
        var prefix = (_a = config.urlPrefix) !== null && _a !== void 0 ? _a : defaultSitemapConfig.urlPrefix;
        if (prefix.endsWith("/")) {
            prefix = prefix.substring(0, prefix.length - 2);
        }
        var sitemapUri = prefix + "/" + ((_b = config.sitemapFilename) !== null && _b !== void 0 ? _b : defaultSitemapConfig.sitemapFilename);
        // TODO: Remplacer par des rules (pour supporter plusieurs directives allow / disallow).
        var allowAllGroup = [
            "User-agent: *",
            "Allow: /"
        ];
        var groups = [allowAllGroup.join("\n"), "Sitemap: " + sitemapUri];
        fs__namespace.writeFileSync(getRobotsFile(), groups.join("\n\n"));
    };
    var parseXml = function (xmlString) {
        return xmlParser.parse(xmlString);
    };
    var getMapForRoute = function (maps, routeConfig) {
        var map = maps[routeConfig.sitemapFilename];
        if (!map && routeConfig.merge) {
            map = loadMap(routeConfig.sitemapFilename);
        }
        if (!map) {
            map = {};
        }
        maps[routeConfig.sitemapFilename] = map;
        return map;
    };
    var sitemapPlugin = function (routes) { return __awaiter(void 0, void 0, void 0, function () {
        var config, log, maps, filename, rootElement, routeCount;
        return __generator(this, function (_c) {
            config = Object.assign({}, defaultSitemapConfig, scully.getPluginConfig(SitemapPlugin));
            log = function (message) {
                var optionalParams = [];
                for (var _i = 1; _i < arguments.length; _i++) {
                    optionalParams[_i - 1] = arguments[_i];
                }
                if (!config.suppressLog) {
                    console.log.apply(console, __spreadArray([message], __read(optionalParams)));
                }
            };
            log("Started @recursyve/scully-sitemap");
            if (!routes) {
                log("No routes were returned by Scully");
                return [2 /*return*/];
            }
            log("Generating sitemaps for " + routes.length + " " + pluralizer(routes.length, 'route', 'routes') + ".");
            // parse route configurations
            if (config.routes) {
                Object.keys(config.routes).forEach(function (key) {
                    // @ts-ignore
                    config.routes[key].regexp = pathToRegexp.pathToRegexp(key);
                });
            }
            maps = {};
            routes.forEach(function (route) {
                var _a;
                if (config.ignoredRoutes && config.ignoredRoutes.includes(route.route)) {
                    return;
                }
                var routeConfig = configForRoute(config, route);
                var map = getMapForRoute(maps, routeConfig);
                var prefix = (_a = routeConfig.urlPrefix) !== null && _a !== void 0 ? _a : defaultSitemapConfig.urlPrefix;
                var loc = mergePaths(prefix, route.route);
                if (routeConfig.trailingSlash && !loc.endsWith('/')) {
                    loc = loc + '/';
                }
                map[loc] = {
                    loc: loc,
                    changefreq: routeConfig.changeFreq,
                    lastmod: today.toISOString(),
                    priority: priorityForLocation(route.route, routeConfig)
                };
            });
            // tslint:disable-next-line: forin
            for (filename in maps) {
                rootElement = saveMap(maps[filename], filename);
                routeCount = rootElement.children.length;
                log("Wrote " + routeCount + " " + pluralizer(routeCount, 'route', 'routes') + " to " + filename);
            }
            if (config.createRobotsFile) {
                log('Generating robots.txt file');
                generateRobotsFile(config);
                log('Wrote robots.txt file');
            }
            log("Finished @recursyve/scully-sitemap");
            return [2 /*return*/];
        });
    }); };
    var validator = function () { return __awaiter(void 0, void 0, void 0, function () { return __generator(this, function (_c) {
        return [2 /*return*/, []];
    }); }); };
    var useSitemapPlugin = function (config) {
        scully.registerPlugin('routeDiscoveryDone', SitemapPlugin, sitemapPlugin, validator);
        scully.setPluginConfig(SitemapPlugin, config);
    };

    /*
     * Public API Surface of scully-sitemap
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.SitemapConfig = SitemapConfig;
    exports.SitemapRoute = SitemapRoute;
    exports.useSitemapPlugin = useSitemapPlugin;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=recursyve-scully-sitemap.umd.js.map
