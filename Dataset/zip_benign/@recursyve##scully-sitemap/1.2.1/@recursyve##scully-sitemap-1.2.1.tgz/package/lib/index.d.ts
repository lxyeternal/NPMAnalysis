import { HandledRoute } from '@scullyio/scully';
import { SitemapConfig } from './sitemap-config';
export declare const sitemapPlugin: (routes?: HandledRoute[]) => Promise<void>;
export declare const useSitemapPlugin: (config: SitemapConfig) => void;
