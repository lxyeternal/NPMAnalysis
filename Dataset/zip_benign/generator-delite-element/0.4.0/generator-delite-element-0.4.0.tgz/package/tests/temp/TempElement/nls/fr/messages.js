define({
	title: "titre"
});