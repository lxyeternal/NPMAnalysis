# Change Log

## 2.0.4

### Patch Changes

- Updated dependencies
  [[`c11743b47`](https://github.com/teste-ui/teste-ui/commit/c11743b47f38f8f38a21b120add3a9cf765b81ee)]:
  - @teste-ui/utils@2.0.4

## 2.0.3

### Patch Changes

- Updated dependencies
  [[`36ef37d58`](https://github.com/teste-ui/teste-ui/commit/36ef37d58220dffc4b8e35c31fdcc57042e9a859),
  [`6c15ec2c2`](https://github.com/teste-ui/teste-ui/commit/6c15ec2c2a32a36ecc2d169308379a6825619543)]:
  - @teste-ui/utils@2.0.3

## 2.0.2

### Patch Changes

- [`06f29f8cd`](https://github.com/teste-ui/teste-ui/commit/06f29f8cdbb10ff1da523e0d0e958b9990d041e1)
  Thanks [@segunadebayo](https://github.com/segunadebayo)! - Bump all packages
  to resolve deps issues

- Updated dependencies
  [[`06f29f8cd`](https://github.com/teste-ui/teste-ui/commit/06f29f8cdbb10ff1da523e0d0e958b9990d041e1)]:
  - @teste-ui/react-utils@2.0.1
  - @teste-ui/utils@2.0.2

## 2.0.1

### Patch Changes

- Updated dependencies
  [[`f77e3c98f`](https://github.com/teste-ui/teste-ui/commit/f77e3c98f72fa17353e9fdad4c51810e83d9cb1c)]:
  - @teste-ui/utils@2.0.1

## 2.0.0

### Major Changes

- [#5879](https://github.com/teste-ui/teste-ui/pull/5879)
  [`c390af485`](https://github.com/teste-ui/teste-ui/commit/c390af4859bcbcf12c982c677492cd6d4960889f)
  Thanks [@TimKolberger](https://github.com/TimKolberger)! - Bump all packages
  to next major for Chakra UI version 2.

* [#5989](https://github.com/teste-ui/teste-ui/pull/5989)
  [`ed692c0ae`](https://github.com/teste-ui/teste-ui/commit/ed692c0ae670bcac92b3da50d141afc6e233dee7)
  Thanks [@TimKolberger](https://github.com/TimKolberger)! - Omit `src`
  directory from being published to npm

- [#5882](https://github.com/teste-ui/teste-ui/pull/5882)
  [`41b3119f5`](https://github.com/teste-ui/teste-ui/commit/41b3119f59226f7c70942d6fd0f46480f9bcf196)
  Thanks [@TimKolberger](https://github.com/TimKolberger)! - Bump peer
  dependency to React and ReactDOM to >=18

### Patch Changes

- Updated dependencies
  [[`c390af485`](https://github.com/teste-ui/teste-ui/commit/c390af4859bcbcf12c982c677492cd6d4960889f),
  [`ed692c0ae`](https://github.com/teste-ui/teste-ui/commit/ed692c0ae670bcac92b3da50d141afc6e233dee7),
  [`41b3119f5`](https://github.com/teste-ui/teste-ui/commit/41b3119f59226f7c70942d6fd0f46480f9bcf196)]:
  - @teste-ui/react-utils@2.0.0
  - @teste-ui/utils@2.0.0

## 2.0.0-next.2

### Major Changes

- [#5989](https://github.com/teste-ui/teste-ui/pull/5989)
  [`ed692c0ae`](https://github.com/teste-ui/teste-ui/commit/ed692c0ae670bcac92b3da50d141afc6e233dee7)
  Thanks [@TimKolberger](https://github.com/TimKolberger)! - Omit `src`
  directory from being published to npm

### Patch Changes

- Updated dependencies
  [[`ed692c0ae`](https://github.com/teste-ui/teste-ui/commit/ed692c0ae670bcac92b3da50d141afc6e233dee7)]:
  - @teste-ui/react-utils@2.0.0-next.2
  - @teste-ui/utils@2.0.0-next.2

## 2.0.0-next.1

### Major Changes

- [#5882](https://github.com/teste-ui/teste-ui/pull/5882)
  [`41b3119f5`](https://github.com/teste-ui/teste-ui/commit/41b3119f59226f7c70942d6fd0f46480f9bcf196)
  Thanks [@TimKolberger](https://github.com/TimKolberger)! - Bump peer
  depencency to React and ReactDOM to >=18

### Patch Changes

- Updated dependencies
  [[`41b3119f5`](https://github.com/teste-ui/teste-ui/commit/41b3119f59226f7c70942d6fd0f46480f9bcf196)]:
  - @teste-ui/react-utils@2.0.0-next.1
  - @teste-ui/utils@2.0.0-next.1

## 2.0.0-next.0

### Major Changes

- [#5879](https://github.com/teste-ui/teste-ui/pull/5879)
  [`c390af485`](https://github.com/teste-ui/teste-ui/commit/c390af4859bcbcf12c982c677492cd6d4960889f)
  Thanks [@TimKolberger](https://github.com/TimKolberger)! - Bump all packages
  to next major for Chakra UI version 2.

### Patch Changes

- Updated dependencies
  [[`c390af485`](https://github.com/teste-ui/teste-ui/commit/c390af4859bcbcf12c982c677492cd6d4960889f)]:
  - @teste-ui/react-utils@2.0.0-next.0
  - @teste-ui/utils@2.0.0-next.0

## 1.2.6

### Patch Changes

- [`e1fe48cbe`](https://github.com/teste-ui/teste-ui/commit/e1fe48cbe37324744cfe6184d785c093cda1125e)
  Thanks [@TimKolberger](https://github.com/TimKolberger)! - Bumped patch
  version for every package to fix release process. Root cause was a bug in our
  CI configuration.
- Updated dependencies
  [[`e1fe48cbe`](https://github.com/teste-ui/teste-ui/commit/e1fe48cbe37324744cfe6184d785c093cda1125e)]:
  - @teste-ui/react-utils@1.2.3
  - @teste-ui/utils@1.10.4

## 1.2.5

### Patch Changes

- Updated dependencies
  [[`a870e6b94`](https://github.com/teste-ui/teste-ui/commit/a870e6b94367b7c6448d5c5c5aa8577e33e15e3a)]:
  - @teste-ui/utils@1.10.3

## 1.2.4

### Patch Changes

- [#5536](https://github.com/teste-ui/teste-ui/pull/5536)
  [`a503acabe`](https://github.com/teste-ui/teste-ui/commit/a503acabefcaea86cb7f40a6305830f09d2d6083)
  Thanks [@TimKolberger](https://github.com/TimKolberger)! - Bumped patch
  version for every package to fix release process.

- Updated dependencies
  [[`a503acabe`](https://github.com/teste-ui/teste-ui/commit/a503acabefcaea86cb7f40a6305830f09d2d6083)]:
  - @teste-ui/react-utils@1.2.2
  - @teste-ui/utils@1.10.2

## 1.2.3

### Patch Changes

- Updated dependencies
  [[`24b4333d0`](https://github.com/teste-ui/teste-ui/commit/24b4333d008d149380785f87f4891e28584ff89b)]:
  - @teste-ui/utils@1.10.1

## 1.2.2

### Patch Changes

- Updated dependencies
  [[`1537a725f`](https://github.com/teste-ui/teste-ui/commit/1537a725fbc7f84979e374f546bda625fc685ac3)]:
  - @teste-ui/utils@1.10.0

## 1.2.1

### Patch Changes

- [#5075](https://github.com/teste-ui/teste-ui/pull/5075)
  [`b28142946`](https://github.com/teste-ui/teste-ui/commit/b281429462a099b7fd7f9352e837cd28d1a2da0e)
  Thanks [@cschroeter](https://github.com/cschroeter)! - Update babel config to
  transpile soruces for older browsers. This fixes issues with CRA and
  Storybook.
- Updated dependencies
  [[`b28142946`](https://github.com/teste-ui/teste-ui/commit/b281429462a099b7fd7f9352e837cd28d1a2da0e)]:
  - @teste-ui/react-utils@1.2.1
  - @teste-ui/utils@1.9.1

## 1.2.0

### Minor Changes

- [#4991](https://github.com/teste-ui/teste-ui/pull/4991)
  [`6095eaf9a`](https://github.com/teste-ui/teste-ui/commit/6095eaf9ac64a7e4d9f934bcb530bae2a92111a6)
  Thanks [@segunadebayo](https://github.com/segunadebayo)! - Update build system
  we use from a custom babel cli setup to
  [preconstruct](https://preconstruct.tools/).

  The previous build system transpiles the code in `src` directory to `dist/esm`
  and `dist/cjs` keeping the same file structure. The new build system merges
  all files in `src` and transpiles to a single `esm` and `cjs` file.

  **Potential Breaking Change:** The side effect of this is that, if you
  imported any function, component or hook using the **undocumented** approach
  like
  `import { useOutsideClick } from "@teste-ui/hooks/dist/use-outside-click"`,
  you'll notice that the this doesn't work anymore.

  Here's how to resolve it:

  ```jsx live=false
  // Won't work 🎇
  import { useOutsideClick } from "@teste-ui/hooks/dist/use-outside-click"

  // Works ✅
  import { useOutsideClick } from "@teste-ui/hooks"
  ```

  If this affected your project, we recommend that you import hooks, functions
  or components the way it's shown in the documentation. This will help keep
  your project future-proof.

### Patch Changes

- Updated dependencies
  [[`6095eaf9a`](https://github.com/teste-ui/teste-ui/commit/6095eaf9ac64a7e4d9f934bcb530bae2a92111a6)]:
  - @teste-ui/react-utils@1.2.0
  - @teste-ui/utils@1.9.0

## 1.1.9

### Patch Changes

- Updated dependencies
  [[`cd0893c56`](https://github.com/teste-ui/teste-ui/commit/cd0893c561d8c72b69db7c03d10adae752468a4f)]:
  - @teste-ui/utils@1.8.4

## 1.1.8

### Patch Changes

- Updated dependencies
  [[`c06d242c6`](https://github.com/teste-ui/teste-ui/commit/c06d242c672a10f93fab4dc2321143beae2db669),
  [`5b4d8ef24`](https://github.com/teste-ui/teste-ui/commit/5b4d8ef24017dab1d69aeb5016b53366bdb3bcfd)]:
  - @teste-ui/utils@1.8.3

## 1.1.7

### Patch Changes

- Updated dependencies
  [[`4c1071969`](https://github.com/teste-ui/teste-ui/commit/4c1071969a9b41a952b374f9990ac0bb89d24fa0),
  [`43f66097b`](https://github.com/teste-ui/teste-ui/commit/43f66097b39f1c37a4627dd6ca8a85555f35b95c)]:
  - @teste-ui/utils@1.8.2

## 1.1.6

### Patch Changes

- Updated dependencies
  [[`4a1e4d93b`](https://github.com/teste-ui/teste-ui/commit/4a1e4d93b0a07df7266d40bb66039385b158d3d1)]:
  - @teste-ui/utils@1.8.1

## 1.1.5

### Patch Changes

- Updated dependencies
  [[`d0f50a46e`](https://github.com/teste-ui/teste-ui/commit/d0f50a46ea6c2bcf06d8cad8b9b3994fd934be01),
  [`b479ff22e`](https://github.com/teste-ui/teste-ui/commit/b479ff22ea10c1a1393224c37c36aa6ceabc4aab),
  [`07d15eab4`](https://github.com/teste-ui/teste-ui/commit/07d15eab480724f8fee1a09b7cecdf1e968d9ddd)]:
  - @teste-ui/utils@1.8.0

## 1.1.4

### Patch Changes

- Updated dependencies
  [[`82f08867f`](https://github.com/teste-ui/teste-ui/commit/82f08867fa4825d647a3b9cc805220d9364f2f3f),
  [`e9ac4cc76`](https://github.com/teste-ui/teste-ui/commit/e9ac4cc7629cd79efc753b4e3353bacdad46cd7d)]:
  - @teste-ui/react-utils@1.1.2
  - @teste-ui/utils@1.7.0

## 1.1.3

### Patch Changes

- Updated dependencies
  [[`0974e547c`](https://github.com/teste-ui/teste-ui/commit/0974e547c29e4efc1ba4d1eb1507d0dad7d7a77a),
  [`59ea894a7`](https://github.com/teste-ui/teste-ui/commit/59ea894a7e03d16cd7a1b89d00816eafa9fab65d)]:
  - @teste-ui/utils@1.6.0

## 1.1.2

### Patch Changes

- [`a73198529`](https://github.com/teste-ui/teste-ui/commit/a7319852908f68596600da799ef08a0e7dbb468e)
  [#3775](https://github.com/teste-ui/teste-ui/pull/3775) Thanks
  [@tomchentw](https://github.com/tomchentw)! - Add missing dependency issue of
  `@teste-ui/react-utils`

- Updated dependencies
  [[`8b5eb9654`](https://github.com/teste-ui/teste-ui/commit/8b5eb9654affe562795d38a19f732f84732a949d)]:
  - @teste-ui/utils@1.5.2

## 1.1.1

### Patch Changes

- [`1a04a41bd`](https://github.com/teste-ui/teste-ui/commit/1a04a41bd2285069011a738fff422ba1a6fcce94)
  Thanks [@segunadebayo](https://github.com/segunadebayo)! - Update import of
  shared utils from `react-utils` to `utils`

- Updated dependencies
  [[`1a04a41bd`](https://github.com/teste-ui/teste-ui/commit/1a04a41bd2285069011a738fff422ba1a6fcce94),
  [`e481ba491`](https://github.com/teste-ui/teste-ui/commit/e481ba4914a7f163d93d4c22e2e457f1afb08721)]:
  - @teste-ui/utils@1.5.1

## 1.1.0

### Minor Changes

- [`b724a9dd9`](https://github.com/teste-ui/teste-ui/commit/b724a9dd9429d02c0b2c7f7deac66d3553100bdc)
  [#3674](https://github.com/teste-ui/teste-ui/pull/3674) Thanks
  [@codebender828](https://github.com/codebender828)! - Extract all React based
  utilities and types into `@teste-ui/react-utils`

### Patch Changes

- Updated dependencies
  [[`a58b724e9`](https://github.com/teste-ui/teste-ui/commit/a58b724e9c8656044f866b658f378662f2a44b46),
  [`b724a9dd9`](https://github.com/teste-ui/teste-ui/commit/b724a9dd9429d02c0b2c7f7deac66d3553100bdc)]:
  - @teste-ui/utils@1.5.0

## 1.0.6

### Patch Changes

- Updated dependencies
  [[`e748219f3`](https://github.com/teste-ui/teste-ui/commit/e748219f300f0c51b0eb304fce38b014d7bcbc86),
  [`91ef14839`](https://github.com/teste-ui/teste-ui/commit/91ef148397187010804eb8f30307d2ec94c32c5b)]:
  - @teste-ui/utils@1.4.0

## 1.0.5

### Patch Changes

- Updated dependencies
  [[`87cc23e14`](https://github.com/teste-ui/teste-ui/commit/87cc23e14814e02cbbfc9737c2356cef682ddd5d)]:
  - @teste-ui/utils@1.3.0

## 1.0.4

### Patch Changes

- Updated dependencies
  [[`ff4a36bca`](https://github.com/teste-ui/teste-ui/commit/ff4a36bca11cc177830f6f1da13700acd1e3a087),
  [`483687237`](https://github.com/teste-ui/teste-ui/commit/483687237f2c4fed05dc6a79693f307c601c1285),
  [`61962345c`](https://github.com/teste-ui/teste-ui/commit/61962345c5b1c862445c16c586e304b28c376c9a)]:
  - @teste-ui/utils@1.2.0

## 1.0.3

### Patch Changes

- Updated dependencies
  [[`8b87406c`](https://github.com/teste-ui/teste-ui/commit/8b87406c3132586be3393117eef80d47ec82fc54)]:
  - @teste-ui/utils@1.1.0

## 1.0.2

### Patch Changes

- Updated dependencies
  [[`e73878ee`](https://github.com/teste-ui/teste-ui/commit/e73878ee686c11d3f94ad6ac61b19ae9508d75a5)]:
  - @teste-ui/utils@1.0.2

## 1.0.1

### Patch Changes

- Updated dependencies
  [[`5c482483`](https://github.com/teste-ui/teste-ui/commit/5c482483ce24fc798540c9792a15e06772eae213)]:
  - @teste-ui/utils@1.0.1

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0 (2020-11-13)

**Note:** Version bump only for package @teste-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-rc.8 (2020-10-29)

### Bug Fixes

- **toast:** allow custom render in update
  ([eb8bff9](https://github.com/teste-ui/teste-ui/commit/eb8bff911e6ec9de0165ab1e8f5ca10d5e022459)),
  closes [#2362](https://github.com/teste-ui/teste-ui/issues/2362)

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-rc.7 (2020-10-25)

**Note:** Version bump only for package @teste-ui/clickable

# 1.0.0-rc.6 (2020-10-25)

**Note:** Version bump only for package @teste-ui/clickable

# 1.0.0-rc.5 (2020-09-27)

**Note:** Version bump only for package @teste-ui/clickable

# 1.0.0-rc.4 (2020-09-25)

**Note:** Version bump only for package @teste-ui/clickable

# 1.0.0-rc.3 (2020-08-30)

**Note:** Version bump only for package @teste-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-rc.2 (2020-08-09)

**Note:** Version bump only for package @teste-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-rc.1](https://github.com/teste-ui/teste-ui/compare/@teste-ui/clickable@1.0.0-rc.0...@teste-ui/clickable@1.0.0-rc.1) (2020-08-06)

**Note:** Version bump only for package @teste-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-rc.0](https://github.com/teste-ui/teste-ui/compare/@teste-ui/clickable@1.0.0-next.7...@teste-ui/clickable@1.0.0-rc.0) (2020-07-26)

**Note:** Version bump only for package @teste-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-next.7](https://github.com/teste-ui/teste-ui/compare/@teste-ui/clickable@1.0.0-next.6...@teste-ui/clickable@1.0.0-next.7) (2020-07-26)

### Bug Fixes

- prevent issue where right click triggers active css state
  ([4ea9b88](https://github.com/teste-ui/teste-ui/commit/4ea9b8872599168f7a6ecb078b62f3473a25b4d8))
- types issue in use-tabs
  ([c388927](https://github.com/teste-ui/teste-ui/commit/c38892760257b9bbf1b63c05f7f9ccf1684a90b0))

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-next.6](https://github.com/teste-ui/teste-ui/compare/@teste-ui/clickable@1.0.0-next.5...@teste-ui/clickable@1.0.0-next.6) (2020-07-15)

**Note:** Version bump only for package @teste-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# [1.0.0-next.5](https://github.com/teste-ui/teste-ui/compare/@teste-ui/clickable@1.0.0-next.4...@teste-ui/clickable@1.0.0-next.5) (2020-07-15)

**Note:** Version bump only for package @teste-ui/clickable

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-next.4 (2020-07-01)

### Bug Fixes

- [#891](https://github.com/teste-ui/teste-ui/issues/891)
  ([e107acc](https://github.com/teste-ui/teste-ui/commit/e107acc8487898a965b0d695c1da71f46fc56d5e))
- ts issue with sx prop
  ([d3b1340](https://github.com/teste-ui/teste-ui/commit/d3b1340cb255937927b4d4c56ce218141570b951))

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-next.3 (2020-06-28)

### Bug Fixes

- [#891](https://github.com/teste-ui/teste-ui/issues/891)
  ([e107acc](https://github.com/teste-ui/teste-ui/commit/e107acc8487898a965b0d695c1da71f46fc56d5e))
- ts issue with sx prop
  ([d3b1340](https://github.com/teste-ui/teste-ui/commit/d3b1340cb255937927b4d4c56ce218141570b951))

# Change Log

All notable changes to this project will be documented in this file. See
[Conventional Commits](https://conventionalcommits.org) for commit guidelines.

# 1.0.0-next.2 (2020-06-21)

### Bug Fixes

- [#891](https://github.com/teste-ui/teste-ui/issues/891)
  ([e107acc](https://github.com/teste-ui/teste-ui/commit/e107acc8487898a965b0d695c1da71f46fc56d5e))
