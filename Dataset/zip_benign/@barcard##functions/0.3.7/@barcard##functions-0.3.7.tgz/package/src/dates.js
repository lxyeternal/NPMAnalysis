// Gets a string formatted hours text from a number of minutes.
// minutes:number => Number of minutes in the day.
// toMilitary:Bool => If true, returns time out of 24 hours. Otherwise, uses AM and PM.
// Returns the dayNum as a string.
export function getMinutesAsString(minutes, toMilitary = false) {
  let hours = Math.floor(minutes / 60)
  let minutesOfSixty = minutes % 60
  let isPM = hours >= 12 && hours < 24
  if (!toMilitary && hours > 12) {
    hours = hours % 12
    if (hours == 0) {
      hours = 12
    }
  } else if (toMilitary && hours > 24) {
    hours = hours % 24
  }
  return `${hours}:${minutesOfSixty < 10 ? '0' : ''}${minutesOfSixty}${
    toMilitary ? '' : ` ${isPM ? 'P' : 'A'}M`
  }`
}
