export function toTitleCase(str) {
  // lowercase the string
  str = str.toLowerCase()

  // split the string into an array of strings
  str = str.split(' ')

  // loop through capitalizing the first letter of each word
  for (var i = 0; i < str.length; i++) {
    str[i] = str[i].charAt(0).toUpperCase() + str[i].slice(1)
  }

  // return the output as a single string
  return str.join(' ')
}

/* converts hex string to rgba string */
export function hexToRgba(hex, opacity) {
  const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex)
  return result
    ? // prettier-ignore
      `rgba(${parseInt(result[1], 16)},${parseInt(result[2], 16)},${parseInt(result[3], 16)},${opacity})`
    : null
}

// showZeroes: true => 15.00 / 14.99
// showZeroes: false => 15 / 14.99
export function toCurrency(float) {
  return float.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,')
}

/* creates a hashmap from an array */
export function hashMap(arr, key) {
  const res = arr.reduce((newObj, obj) => {
    if (obj[key] !== undefined) {
      newObj[obj[key]] = obj
      return newObj
    } else {
      return newObj
    }
  }, {})
  return res
}

/* returns the url of the given image */
export function getImgUrl(handle) {
  return `https://cdn.filestackcontent.com/resize=w:650/compress/${handle}`
}
