import { Dimensions, Platform, StatusBar } from 'react-native'

const STATUS_BAR_HEIGHT =
  Platform.OS === 'android' ? StatusBar.currentHeight : 20

const { width, height } = Dimensions.get('window')

const deviceWidth = width
const deviceHeight = height

const HIT_SLOP = { top: 8, left: 8, right: 8, bottom: 8 }

export { deviceWidth, deviceHeight, STATUS_BAR_HEIGHT, HIT_SLOP }
