import {
  deviceWidth,
  deviceHeight,
  STATUS_BAR_HEIGHT,
  HIT_SLOP,
} from './constants'
import { getMinutesAsString } from './dates'
import {
  toTitleCase,
  hexToRgba,
  toCurrency,
  hashMap,
  getImgUrl,
} from './helpers'
import { scale, scaleFont, verticalScale, moderateScale } from './scale'
import { fonts, newColors, colors } from './styles'

export {
  deviceWidth,
  deviceHeight,
  STATUS_BAR_HEIGHT,
  HIT_SLOP,
  getMinutesAsString,
  toTitleCase,
  hexToRgba,
  toCurrency,
  hashMap,
  getImgUrl,
  scale,
  scaleFont,
  verticalScale,
  moderateScale,
  fonts,
  newColors,
  colors,
}
