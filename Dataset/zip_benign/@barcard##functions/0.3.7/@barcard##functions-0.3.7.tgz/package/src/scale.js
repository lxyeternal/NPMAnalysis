/* 
  http://www.kylejlarson.com/blog/iphone-6-screen-size-web-design-tips/
  https://blog.solutotlv.com/size-matters/
  https://stackoverflow.com/questions/33628677/react-native-responsive-font-size
*/
import { Dimensions, PixelRatio, Platform } from 'react-native'
const { width, height } = Dimensions.get('window')

// Guideline sizes are based on standard ~5" screen mobile device
// const guidelineBaseWidth = 350;
// const guidelineBaseHeight = 680;

// Guideline sizes are based on some android bullshit, 667px
const guidelineBaseWidth = 414
// const guidelineBaseHeight = 559;
const guidelineBaseHeight = 736

const scale = size => {
  // doing this for now, need to device a better strategy (and also do the same for the scaleFont function)
  return Platform.OS === 'web'
    ? size
    : PixelRatio.roundToNearestPixel((width / guidelineBaseWidth) * size)
}
const verticalScale = size =>
  PixelRatio.roundToNearestPixel((height / guidelineBaseHeight) * size)
const moderateScale = (size, factor = 0.5) =>
  PixelRatio.roundToNearestPixel(size + (scale(size) - size) * factor)

const scaleFont = size =>
  width < 375
    ? PixelRatio.roundToNearestPixel(size * 0.8)
    : PixelRatio.roundToNearestPixel(size)
export { scale, scaleFont, verticalScale, moderateScale }

/* 

If you want to scale a View with 300dp width, on the iPhone 7 you will get:

  scale(300) = 320
  moderateScale(300) = 310
  moderateScale(300, 0.25) = 305

On the Galaxy Tab Tablet:

  scale(300) = 300 + 360 = 660
  moderateScale(300) = 300 + 360/2 = 480
  moderateScale(300, 0.25) = 300 + 360/4 = 390

*/
