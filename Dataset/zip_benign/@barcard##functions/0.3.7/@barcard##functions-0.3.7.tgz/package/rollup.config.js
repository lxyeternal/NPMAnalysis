import babel from 'rollup-plugin-babel'
import commonjs from 'rollup-plugin-commonjs'
import resolve from 'rollup-plugin-node-resolve'
import { sizeSnapshot } from 'rollup-plugin-size-snapshot'

// const extensions = ['.js', '.jsx', '.md', '.mdx', '.json']

// should really just write a function that pulls this automatically
const external = ['react', 'react-dom', 'react-native', 'react-native-web']

const babelConfig = {
  babelrc: false,
  sourceMap: true,
  comments: false,
  // runtimeHelpers: true, // set to true when using @babel/plugin-transform-runtime
  externalHelpers: true, // If you do not wish the babel helpers to be included in your bundle at all (but instead reference the global babelHelpers object), you may set the externalHelpers option to true
  exclude: '**/node_modules/**',
  presets: [
    ['@babel/preset-env', { loose: true, modules: false }],
    ['@babel/preset-react'],
  ],
  plugins: [
    ['@babel/proposal-class-properties', { loose: true }],
    ['@babel/plugin-proposal-object-rest-spread', { loose: true }],
    [
      'module-resolver',
      {
        alias: {
          '^react-native$': 'react-native-web',
        },
      },
    ],
  ],
}

const commonjsConfig = {
  include: '**/node_modules/**',
  namedExports: {
    // '../../node_modules/react/index.js': [
    //   'cloneElement',
    //   'createElement',
    //   'Children',
    //   'Component',
    //   'PropTypes',
    //   'React',
    // ],
  },
}

export default () => {
  return [
    {
      input: 'src/index.js',
      output: { file: 'dist/index.js', format: 'esm', sourcemap: true },
      plugins: [
        resolve(),
        babel(babelConfig),
        commonjs(commonjsConfig),
        sizeSnapshot(),
      ],
      external,
    },
    {
      input: 'src/index.js',
      output: { file: 'dist/index.cjs.js', format: 'cjs', sourcemap: true },
      plugins: [
        resolve(),
        babel(babelConfig),
        commonjs(commonjsConfig),
        sizeSnapshot(),
      ],
      external,
    },
  ]
}
