type ListWithNullable<T extends unknown[]> = {
    [key in keyof T]: T[key] | undefined | null;
};
export declare function run<T extends unknown[], U>(runnable: (...args: T) => U): {
    wif: (...args: ListWithNullable<T>) => (() => U | undefined) & {
        else<S>(alsoRunnable: () => S): U | S;
    };
};
export {};
