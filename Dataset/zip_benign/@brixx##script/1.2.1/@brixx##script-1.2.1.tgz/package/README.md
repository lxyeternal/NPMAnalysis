# Brixx-Script

Brixx-Script is a free JavaScript library for creating independent web components. **Smart Web Components** (brixx) for websites and web applications can be created with Brixx-Script. This reduces the programming effort and project complexity for a **low-code development** to a minimum. **Brixx web components** are created with [JSX (JavaScript XML)](<https://en.wikipedia.org/wiki/JSX_(JavaScript)>) and can be used as Brixx HTML elements in HTML documents or Brixx script components in JavaScript applications and frameworks. JSX was introduced in 2014 with [React](<https://en.wikipedia.org/wiki/React_(JavaScript_library)>) and has the same syntax as [E4X (EcmaScript for XML)](https://en.wikipedia.org/wiki/ECMAScript_for_XML) for integrating XML into JavaScript. Brixx-Script has its origins in 1998 as LaSSiE as a platform-independent web development and was expanded in 2005 with E4X. Coinciding with the advent of JSX, E4X was marked as deprecated by the Mozilla Foundation in 2014 and consequently replaced by JSX in LaSSiE as well. LaSSiE was initially used as an integrated building block system in other libraries, but due to the great popularity and spread of JSX, it was released in December 2022 as a free JavaScript library **Brixx-Script** for creating Brixx web components. Brixx-Script is primarily used to create a building block oriented project architecture, but it can also be a lightweight alternative to other frameworks and libraries.

# Installation

You can install the package with npm.

    npm i @brixx/script

# Import

You can import the package as module.

    import { Brixx } from '@brixx/script'

# Usage

Brixx web component in the Brixx script component file `brixx-animal-list.js`

    const animals = ["Dog", "Cat", "Mouse"];

    Brixx.element = (
    <div>
      <h2>Animals</h2>
      <ul>
        {animals.map((animal) => (
          <li>
            <h3>{animal}</h3>
          </li>
        ))}
      </ul>
    </div>
    );

    Brixx.registerElement({ name: "animal-list" });

Brixx HTML element in the HTML file `index.html`

    <!DOCTYPE html>
    <html>
      <head>
        <!-- Load Brixx-Script standalone for development -->
        <script src="https://brixx.it/@brixx/standalone/brixx.min.js"></script>
        <!-- Include the Brixx script component files for development -->
        <script type="text/babel" src="./brixx-animal-list.js" data-presets="brixx"></script>
      </head>

      <body>
        <!-- Add the Brixx HTML element -->
        <brixx-animal-list></brixx-animal-list>
      </body>
    </html>

# Documentation

### See [BRIXX.it documentation repository](https://github.com/BietSoft/brixx.docs/blob/main/brixx-script/README.md)
