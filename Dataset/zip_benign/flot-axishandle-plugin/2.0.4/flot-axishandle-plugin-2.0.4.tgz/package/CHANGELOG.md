# Changelog
All notable changes to this project will be documented in this file.

## [2.0.0]

### Changes ###
- do not bundle the [thumb plugin](https://www.npmjs.com/package/flot-thumb-plugin) in the distribution file. The user needs to install flot-thumb-plugin
- add fill in the option to allow the user to configure the handle fill color
- add absolutePosition in the option to allow the user to specify the position relative to the axis coordinate
- fix some bugs

## [1.3.0]

### Changes ###
- add horizontalHandleConstrain, verticalHandleConstrain properties to let the users describe the constraint of the handle movement
- add thumb related events including thumbCreated, thumbWillBeRemoved, thumbVisibilityChanged, thumbIntoRange, thumbOutOfRange

## [1.2.1]

### Changes ###
- make sure that changing properties work at runtime by using setAxisHandle method

## [1.2.0]

### Changes ###
- fix the issue where an empty label will cause an exception
- add the selected axis handle as the parameter of pan events
- expose handleClassList property

## [1.1.0]

### Changes ###
- fix a sync issue when changing the position property
- fire axisHandleUpdates event when an axis handle is added/changed/removed/moved

[2.0.0]: https://github.com/ni-kismet/flot-axishandle-plugin/compare/v1.3.0...v2.0.0
[1.3.0]: https://github.com/ni-kismet/flot-axishandle-plugin/compare/v1.2.1...v1.3.0
[1.2.1]: https://github.com/ni-kismet/flot-axishandle-plugin/compare/v1.2.0...v1.2.1
[1.2.0]: https://github.com/ni-kismet/flot-axishandle-plugin/compare/v1.1.0...v1.2.0
[1.1.0]: https://github.com/ni-kismet/flot-axishandle-plugin/compare/v1.0.0...v1.1.0
