# `tidyverse`

`tidyverse` aims at easing data manipulation with javascript. It is inspired by Hadley Wickham's [tidyverse](https://www.tidyverse.org/packages/) `R` package and reproduces its API.

So far, one function is implemented:
- `pivot_longer`: converts an array of objects from a wider format to a longer format.
  - `data`: the array to pivot
  - `cols`: an array of field names
  - `name_to`: name of the added field

The returned objects will also have an added property `value` with the value of the pivoted fields.

## Wider and Longer data table


**Wider data table**

In the mock data table below, years are used as column names, when they actually belong to the same dimension "year". The rows contains several values (one for each year).

| name      | gender | 2017  | 2018 | 2019  |
|-----------|--------|-------|------|-------|
| Argentina | female | 34    | 7    | 3     |
| Armenia   | female | 14\.6 | 12   | 19\.8 |
| Argentina | male   | 54    | 32   | 60    |
| Armenia   | male   | 43    | 12   | 25    |


**Longer Data table**

This longer data table contains the same information, but the years are stored in a unique column. The values are also stored in a newly created column "values". Each row contains a single observation.

| name      | gender | year | value |
|-----------|--------|------|-------|
| Argentina | female | 2017 | 34    |
| Armenia   | female | 2017 | 14\.6 |
| Argentina | male   | 2017 | 54    |
| Armenia   | male   | 2017 | 43    |
| Argentina | female | 2018 | 7     |
| Armenia   | female | 2018 | 12    |
| Argentina | male   | 2018 | 32    |
| Armenia   | male   | 2018 | 12    |
| Argentina | female | 2019 | 3     |
| Armenia   | female | 2019 | 19\.8 |
| Argentina | male   | 2019 | 60    |


`pivot_longer` converts a data table from the wider format to the longer format.


## Example

```
import { pivot_longer } from "tidyverse";

const wider = [
  {
    country: "Argentina",
    gender: "female",
    2015: 0.3,
    2016: 0.7,
    2017: 0.7
  },
  {
    country: "Armenia",
    gender: "female",
    2015: 7.2,
    2016: 7.7,
    2017: 7.6
  }
];

const longer = pivot_longer({
  data: wider,
  cols: [2015, 2016, 2017],
  name_to: "year"
})

console.log(longer);
// [
//   {
//     "country": "Argentina",
//     "gender": "female",
//     "year": 2015,
//     "value": 0.3
//   },
//   {
//     "country": "Armenia",
//     "gender": "female",
//     "year": 2015,
//     "value": 7.2
//   },
//   {
//     "country": "Argentina",
//     "gender": "female",
//     "year": 2016,
//     "value": 0.7
//   },
//   {
//     "country": "Armenia",
//     "gender": "female",
//     "year": 2016,
//     "value": 7.7
//   },
//   {
//     "country": "Argentina",
//     "gender": "female",
//     "year": 2017,
//     "value": 0.7
//   },
//   {
//     "country": "Armenia",
//     "gender": "female",
//     "year": 2017,
//     "value": 7.6
//   }
//  ]

```