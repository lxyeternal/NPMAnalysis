<script>
	export let style = '';
</script>

<p class='source' {style}>
	<slot />
</p>

<style lang='scss'>
	.source {
		font: 0.8rem 'Source Sans Pro', sans-serif;
		text-transform: uppercase;
		margin: 0.5rem 0;
	}
</style>