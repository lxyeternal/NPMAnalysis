<script>
	export let style = '';
</script>

<h3 class='subtitle' {style}>
	<slot />
</h3>

<style lang='scss'>
	.subtitle {
		font: bold 1.1rem 'Source Sans Pro', sans-serif;
		margin: 0;
	}
</style>