<script>
	export let style = '';
</script>

<h2 class='title' {style}>
	<slot />
</h2>

<style lang='scss'>
	.title {
		font: bold 1.5rem 'SuecaSlab', serif;
		margin: 0;
	}
</style>