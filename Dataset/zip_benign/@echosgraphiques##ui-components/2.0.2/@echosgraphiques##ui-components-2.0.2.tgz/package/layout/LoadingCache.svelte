<script>
	export let hidden = false;
</script>

<div id='loading-cache' class:hidden={hidden}>
	<div id='loader' />
	<img id='logo' src='https://media.lesechos.fr/infographie/logos/logo-white.png' alt='' />
</div>

<style lang='scss'>
	#loading-cache {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100vh;
		background: $black;
		z-index: 101;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		padding-top: 4rem;

		&.hidden {
			display: none;
		}

		#loader {
			box-sizing: content-box;
			width: 30px;
			height: 30px;
			border: 10px solid #f3f3f3;
			border-top: 10px solid transparent;
			border-radius: 50%;
			animation: spin 1s linear infinite;
			margin: 0 0 0.5rem;
		}

		#logo {
			display: block;
			width: 10rem;
			padding: 0.5rem;
		}
	}

	@keyframes spin {
		from {
			transform: rotate(0deg);
		}
		to {
			transform: rotate(360deg)
		}
	}
</style>