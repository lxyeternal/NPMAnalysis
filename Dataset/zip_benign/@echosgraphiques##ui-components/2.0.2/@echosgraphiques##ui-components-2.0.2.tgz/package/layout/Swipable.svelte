<script>
	import { createEventDispatcher, onMount } from 'svelte';

	export let direction = 'horizontal';

	let swipable;
	let start;

	const dispatch = createEventDispatcher();

	onMount(() => {
		const isInDirection = (dx, dy) => {
			if (direction === 'both') return true;
			return (direction === 'horizontal' && Math.abs(dx) > Math.abs(dy))
				|| (direction === 'vertical' && Math.abs(dy) > Math.abs(dx));
		}

		const unify = (e) => e.changedTouches ? e.changedTouches[0] : e;

		swipable.addEventListener('touchstart', e => {
			start = {
				x: unify(e).clientX,
				y: unify(e).clientY
			};
		});

		swipable.addEventListener('touchmove', e => {
			const dx = unify(e).clientX - start.x;
			const dy = unify(e).clientY - start.y;
			if (isInDirection(dx, dy)) e.preventDefault();
		});

		swipable.addEventListener('touchend', e => {
			const dx = unify(e).clientX - start.x;
			const dy = unify(e).clientY - start.y;

			if (dx === 0 && dy === 0) return;
			
			if (isInDirection(dx, dy)) {
				switch (direction) {
					case 'horizontal':
						dispatch(dx > 0 ? 'swipeleft' : 'swiperight');
						break;
					case 'vertical':
						dispatch(dy > 0 ? 'swipedown' : 'swipeup');
						break;
					case 'both':
						if (Math.abs(dx) > Math.abs(dy)) {
							dispatch(dx > 0 ? 'swipeleft' : 'swiperight');
						}
						else {
							dispatch(dy > 0 ? 'swipedown' : 'swipeup');
						}
				}
				dispatch('swipe');
			}
		});
	})
</script>

<div bind:this={swipable} class='swipable'>
	<slot />
</div>
