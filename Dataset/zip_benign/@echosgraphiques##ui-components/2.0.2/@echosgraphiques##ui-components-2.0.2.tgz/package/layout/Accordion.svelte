<script>
	import { createEventDispatcher } from 'svelte';

	export let visible = false;
	export let duration = 0.4;

	let content;
	let height;

	const dispatch = createEventDispatcher();

	const setHeight = () => height = content && content.scrollHeight;

	const toggleContent = () => {
		visible = !visible;
		if (visible) {
			dispatch('open');
		}
		else {
			dispatch('close');
		}
		height = content.scrollHeight;
	}

	$: visible && setHeight();
</script>

<div class='accordion' class:visible>
	<div on:click={toggleContent}>
		<slot name='header'></slot>
	</div>
	<div class='content' bind:this={content} style='--duration: {duration}s; --height: {height}px;'>
		<slot name='content'></slot>
	</div>
</div>

<style lang='scss'>
	.accordion {
		position: relative;
		height: auto;

		.content {
			overflow: hidden;
			transition: var(--duration);
			max-height: 0;
		}

		&.visible {
			.content {
				max-height: var(--height);
			}
		}
	}
</style>
