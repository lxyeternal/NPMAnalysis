<script>
	export let style = '';
</script>

<div class='layout'>
	<div class='content' {style}>
		<slot />
	</div>
	<div class='footer'>
		<img src='https://media.lesechos.fr/infographie/logos/logo.png' alt='' />
	</div>
</div>

<style lang='scss'>
	.layout {
		width: 100%;
		max-width: 680px;
		height: 100%;
		padding: 1rem 1.5rem 3rem;
		background-color: white;
		position: relative;

		.content {
			width: 100%;
			display: flex;
			flex-direction: column;
			gap: 0.5rem;
		}

		.footer {
			position: absolute;
			bottom: 0;
			left: 0;
			background-color: white;
			width: 100%;
			height: 3rem;
			display: flex;
			align-items: center;
			padding-left: 1.5rem;

			img {
				height: 1.6rem;
			}
		}
	}
</style>