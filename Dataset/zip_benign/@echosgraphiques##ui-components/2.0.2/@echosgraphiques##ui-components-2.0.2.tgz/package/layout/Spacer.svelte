<script>
	export let height;
</script>

<div class='spacer' style='height: {height}rem;'></div>

<style>
	.spacer {
		width: 100%;
	}
</style>
