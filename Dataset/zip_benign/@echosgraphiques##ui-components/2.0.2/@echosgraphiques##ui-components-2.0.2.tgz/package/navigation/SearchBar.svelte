<script>
	import Fuse from 'fuse.js';
	import { debounce } from 'lodash-es';

	export let key;
	export let items;
	export let selected;
	export let placeholder = 'Rechercher';
	export let formatter = (item) => item[key];

	let isFocused = false;
	let matches = [];
	let value = null;
	let highlightedIndex = null;

	const fuse = new Fuse(items, {
		threshold: 0,
		ignoreLocation: true,
		keys: [key]
	});

	const handleInput = debounce((e) => {
		const value = e.target.value;
		if (!value) {
			selected = null;
			matches = [];
		}
		else {
			matches = fuse.search(value);
		}
		
		highlightedIndex = null;
	}, 300);

	const selectItem = ({ item }) => {
		value = formatter(item);
		selected = item;
		matches = [];
		highlightedIndex = null;
	}

	const reset = () => {
		value = null;
		selected = null;
	}

	window.addEventListener('keydown', (e) => {
		if (e.key === 'ArrowDown') {
			highlightedIndex = highlightedIndex !== null
				? (highlightedIndex + 1) % Math.min(matches.length, 10)
				: 0;
		}
		else if (e.key === 'ArrowUp') {
			highlightedIndex = highlightedIndex !== null
				? (Math.min(matches.length, 10) + highlightedIndex - 1) % Math.min(matches.length, 10)
				: Math.min(matches.length - 1, 9);
		}
		else if (e.key === 'Enter') {
			if (highlightedIndex !== null && matches.length > highlightedIndex) {
				selectItem(matches[highlightedIndex]);
			}
		}
	});
</script>

<div class='search-bar' class:has-matches={isFocused && matches.length > 0}>
	<input
		type='text'
		{placeholder}
		on:input={handleInput}
		on:focus={() => isFocused = true}
		on:blur={() => isFocused = false}
		bind:value />
	{#if !!selected}
		<button class='reset' on:click={reset}>
			<i class='fi fi-close-a'></i>
		</button>
	{/if}
	<ul class='matches'>
		{#each matches.slice(0, 10) as match, i}
			<li class:highlighted={highlightedIndex === i}>
				<button on:mousedown|preventDefault on:click={() => selectItem(match)}>
					{formatter(match.item)}
				</button>
			</li>
		{/each}
	</ul>
</div>

<style lang='scss'>
	.search-bar {
		margin: 0.5rem 0;
		width: 100%;
		position: relative;
		z-index: 42;
		font-size: 0.9rem;
		max-width: 24rem;

		input {
			width: 100%;
			margin: 0;
			border: 1px solid $grey;
			height: 40px;
			border-radius: 20px;
			padding-inline: 40px;

			&:focus{
				border-color: $black;
				outline: none;
			}
		}

		&::before {
			content: "\eb1e";
			font-family: 'fontisto';
			position: absolute;
			top: 20px;
			left: 16px;
			transform: translateY(-50%);
		}

		.reset {
			all: unset;
			cursor: pointer;
			position: absolute;
			top: 20px;
			right: 16px;
			transform: translateY(-50%);
		}

		.matches {
			position: absolute;
			top: 100%;
			left: 0;
			width: 100%;
			list-style-type: none;
			padding: 0;
			margin: 0;
			border: 1px solid $black;
			border-top: none;
			border-radius: 0 0 10px 10px;
			opacity: 0;
			pointer-events: none;

			li {
				background: white;
				border-top: 1px solid $lightgrey;
				overflow: hidden;

				button {
					all: unset;
					width: 100%;
					cursor: pointer;
					padding: 10px;
				}

				&:hover {
					background: whitesmoke;
				}

				&.highlighted {
					color: white;
					background-color: $black;
				}

				&:last-child {
					border-radius: 0 0 10px 10px;
				}
			}
		}

		&.has-matches {
			input {
				border-radius: 20px 20px 0 0;
				border-bottom-color: transparent;
			}

			.matches {
				opacity: 1;
				pointer-events: all;
			}
		}
	}
</style>