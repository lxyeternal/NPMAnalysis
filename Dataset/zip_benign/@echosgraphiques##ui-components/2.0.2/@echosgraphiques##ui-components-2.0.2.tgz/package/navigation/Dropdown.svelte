<script>
	export let options;
	export let selected;
	export let style = '';
</script>

<div class='dropdown' {style}>
	<select bind:value={selected} on:change>
		{#each options as option}
			<option value={Array.isArray(option) ? option[0] : option}>
				{Array.isArray(option) ? option[1] : option}
			</option>
		{/each}
	</select>
</div>

<style lang='scss'>
	.dropdown {
		height: 40px;
		position: relative;
		width: fit-content;

		select {
			display: block;
			margin: 0;
			appearance: none;
			background: white;
			border: 1px solid $grey;
			height: 40px;
			border-radius: 20px;
			padding-inline: 1rem 2.5rem;
			overflow: hidden;
			text-overflow: ellipsis;
			cursor: pointer;
		}

		&::after {
			content: '\e97c';
			position: absolute;
			top: 50%;
			right: 1rem;
			transform: translateY(-50%);
			font-family: inherit;
			font-size: 0.9rem;
			pointer-events: none;
			font-family: 'fontisto';
		}
	}
</style>