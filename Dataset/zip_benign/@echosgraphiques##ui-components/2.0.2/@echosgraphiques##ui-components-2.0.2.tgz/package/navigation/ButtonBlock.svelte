<script>
	export let options;
	export let selected;
	export let grid = false;
</script>

<div class='buttons' class:grid>
	{#each options as option}
		<button
			class:selected={selected === (Array.isArray(option) ? option[0] : option)}
			on:click={() => selected = (Array.isArray(option) ? option[0] : option)}
		>
			{Array.isArray(option) ? option[1] : option}
		</button>
	{/each}
</div>

<style lang='scss'>
	.buttons {
		margin: 0;
		font-size: 0.9rem;

		button {
			all: unset;
			text-align: center;
			padding: 0.5rem 2rem;
			background: #F0F0F0;
			cursor: pointer;
			transition: all 0.2s;

			&:hover, &.selected {
				color: white;
				background: $black;
			}
		}

		&:not(.grid) {
			display: flex;
			flex-wrap: wrap;

			button {
				&:first-child {
					border-radius: 6px 0 0 6px;
				}

				&:last-child {
					border-radius: 0 6px 6px 0;
				}
			}

			@include sm {
				flex-direction: column;
				justify-content: flex-start;
				align-items: center;

				button {
					width: 50%;

					&:first-child {
						border-radius: 6px 6px 0 0;
					}

					&:last-child {
						border-radius: 0 0 6px 6px;
					}
				}
			}
		}

		&.grid {
			display: grid;
			grid-template-columns: repeat(2, 1fr);

			button {
				&:first-child {
					border-radius: 6px 0 0 0;
				}

				&:nth-child(2) {
					border-radius: 0 6px 0 0;
				}

				&:nth-last-child(2) {
					border-radius: 0 0 0 6px;
				}

				&:last-child {
					border-radius: 0 0 6px 0;
				}
			}
		}
	}
</style>
