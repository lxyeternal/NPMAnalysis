<script>
	import { createEventDispatcher } from 'svelte';

	export let color = 'black';
	export let direction = 'down';
	export let size = '2rem';
	export let width = '0.5rem';
	export let animated = false;
	export let disabled = false;
	export let hidden = false;

	let angle;

	$: {
		switch (direction) {
			case 'down':
				angle = 135;
				break;
			case 'left':
				angle = -135;
				break;
			case 'up':
				angle = -45;
				break;
			case 'right':
				angle = 45;
		}
	}

	const dispatch = createEventDispatcher();
</script>

<button
	class='arrow'
	class:hidden
	class:disabled
	class:animated
	style='width: {size}; height: {size}; border-color: {color}; --angle: {angle}deg; --width: {width};'
	on:click={() => !disabled && !hidden && dispatch('click')} />

<style lang='scss'>
	@keyframes bounce {
		0% {
			transform: rotate(var(--angle)) translate(0);
		}
		5% {
			transform: rotate(var(--angle)) translate(-4px, 4px);
		}
		10% {
			transform: rotate(var(--angle)) translate(0);
		}
		15% {
			transform: rotate(var(--angle)) translate(-4px, 4px);
		}
		20% {
			transform: rotate(var(--angle)) translate(0);
		}
		100% {
			transform: rotate(var(--angle)) translate(0);
		}
	}

	.arrow {
		all: unset;
		display: inline-block;
		margin: 0.5rem;
		transform-origin: 50% 50%;
		border-top: solid var(--width) $red;
		border-right: solid var(--width) $red;
		transform: rotate(var(--angle));
		cursor: pointer;

		&.animated {
			animation: bounce 2s ease infinite;
		}

		&.disabled {
			opacity: 0.5;
			cursor: not-allowed;
			animation: none;
		}

		&.hidden {
			pointer-events: none;
			visibility: hidden;
		}
	}
</style>
