<script>
	export let checked = false;
	export let label;
</script>

<div class='checkbox' class:checked>
	<label>
		<input type='checkbox' bind:checked />
		{label}
	</label>
</div>

<style lang='scss'>
	.checkbox {
		position: relative;
		display: table;
		max-width: 90%;

		[type="checkbox"] {
			position: absolute;
			left: 0;
			opacity: 0.01;
			cursor: pointer;
		}

		label {
			position: relative;
			padding-left: 1.5rem;
			font-size: inherit;
			user-select: none;

			&::before {
				content: '';
				position: absolute;
				left: 0;
				top: 50%;
				transform: translateY(-50%);
				width: 1rem;
				height: 1rem;
				border: 1px solid lightgrey;
				border-radius: 0.25rem;
				transition: all .3s;
				cursor: pointer;
				background: #FFF;
			}
		}

		&.checked {
			label::before {
				background: black;
			}
		}
	}
</style>
