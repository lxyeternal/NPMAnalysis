    var colums = {
        keyword: {
            name              : 'Keyword',
            isDimension       : true  ,
            type              : 'str' ,
            notEmpty          : false ,
            summaryAggregator : aggregators.unicCount,
            createAggregators(dims,cols){
                var res           = {}; 
                res.keywords     = aggregators.unicCount;
                if(dims.url !==-1 || dims.url){
                    res.top_keyword  = aggregators._first(cols);
                    res.all_keywords = aggregators.arrUnicJoin;
                }
                return res;
            }
        },
        position: {
            name              : 'Keyword',
            isDimension       : true  ,
            type              : 'int' ,
            notEmpty          : false ,
            summaryAggregator : aggregators.cast.position('region_queries_count'),
            weightCol         : 'region_queries_count',
            createAggregators(dims,cols){
                return {
                    saPosition: aggregators.cast.position(),
                    qaPosition: aggregators.cast.position('region_queries_count'),
                    res.taPosition = aggregators.cast.position('traff')
                }; 
            }
        },
        _se: {
            name              : 'Region',
            isDimension       : true  ,
            type              : 'str' ,
            notEmpty          : false ,
            summaryAggregator : aggregators.unicCount
        },
        url: {
            name              : 'URL',
            isDimension       : true  ,
            type              : 'str' ,
            notEmpty          : false ,
            summaryAggregator : aggregators.unicCount
        },
        subdomain: {
            name              : 'Subdomain',
            isDimension       : true  ,
            type              : 'str' ,
            notEmpty          : false ,
            summaryAggregator : aggregators.unicCount
        },
        domain: {
            name              : 'Domain',
            isDimension       : true  ,
            type              : 'str' ,
            notEmpty          : false ,
            summaryAggregator : aggregators.unicCount
        },
        
        
        
        found_results:{
            type       : 'int',
            aggregator : aggregators.MAX,
            dimensions : ['_se','keyword']
        }, 
        cost:{
            type       : 'float',
            aggregator : aggregators.WAV,
            weightCol  : 'region_queries_count',
            dimensions : ['_se','keyword'],
            isMoney    : true
        }, 
        concurrency:{
            type       : 'float',
            aggregator : aggregators.WAV,
            weightCol  : 'region_queries_count',
            dimensions : ['_se','keyword']
        }, 
        difficulty:{
            type         : 'float',
            aggregator   : aggregators.WAV,
            weightCol    : 'region_queries_count',
            dimensions   : ['_se','keyword']
        }, 
        region_queries_count:{
            type         : 'int',
            aggregator   : aggregators.SUM,
            dimensions   : ['_se','keyword'],
            isMainMetric : true
        }, 
        region_queries_count_wide:{
            type         : 'int',
            subtype      : 'region_queries_count',
            aggregator   : aggregators.SUM,
            dimensions   : ['_se','keyword'],
            isMainMetric : true
        }, 
        region_queries_count_last:{
            type         : 'int',
            subtype      : 'region_queries_count',
            aggregator   : aggregators.SUM,
            dimensions   : ['_se','keyword'],
            isMainMetric : true
        }, 
        keyword_length:{
            type             : 'int',
            lowUnic          : true,
            aggregator       : aggregators.AVG,
            dimensions       : ['keyword'],
            isStrictPositive : true
        }, 
        geo_names:{
            type            : 'arr',
            lowUnic         : true,
            aggregator      : aggregators.ARR_UNIC_SUM,
            dimensions      : ['_se','keyword'],
            defCompareValue : []
        },
        types:{
            type            : 'arr',
            lowUnic         : true,
            aggregator      : aggregators.ARR_UNIC_SUM,
            dimensions      : ['_se','keyword'],
            defCompareValue : []
        },
        social_domains:{
            type            : 'arr',
            lowUnic         : true,
            aggregator      : aggregators.ARR_UNIC_SUM,
            dimensions      : ['_se','keyword'],
            defCompareValue : []
        },
        keyword_id:{
            type              : 'id',
            dimensions        : ['_se','keyword'],
            defCompareValue   : '',
            aggregator        : null
        },
        right_spelling:{
            type            : 'str',
            aggregator      : aggregators.PART_OF_NOT_NULL,
            dimensions      : ['keyword'],
            defCompareValue : ''
        },
        lang:{
            type            : 'str',
            aggregator      : aggregators.ARR_UNIC_SUM,
            dimensions      : ['keyword'],
            defCompareValue : ''
        }
        
    


    TODO position min 
         2 files
         
    var aggregators = {
        MAX              : function AGGR_MAX(vals,rows){
            ...
        },
        MIN              : function AGGR_MIN(vals,rows){
            ...
        },
        SUM              : function AGGR_SUM(vals,rows){
            ...
        },
        ARR_UNIC_SUM     : function AGGR_ARR_UNIC_SUM(vals,rows){
            ...
        },
        PART_OF_NOT_NULL : function AGGR_PART_OF_NOT_NULL(vals,rows){
            ...
        },
        WAVG             : function AGGR_WAV(vals,rows){
            ...  
        },
        UNIC_COUNT       : function UNIC_COUNT(vals,rows){
            ...  
        },
    };
    aggregators.WAVG.sqlCode  = function(expression,col){
        return ' (SUM('+expression+'*`'+col.weightCol+'`)/SUM(`'+col.weightCol+'`)) ';
    }
    var genSqlCode = function(expression,col){
        return ' '+this.name + '('+expression+')'+' ';
    }
    for(let name in aggregators) if(aggregators.hasOwnProperty(name)){
        aggregators[name].name     = aggregators[name].name    || name;
        aggregators[name].sqlCode  = aggregators[name].sqlCode || genSqlCode;
    }    
    var defaultColumn : {
        isDimension       : false,
        isMainMetric      : false,
        lowUnic           : false,
        dimensions        : [],   
        isStrongDimension : false,
        type              : 'string',
        subtype           : 'string',
        notEmpty          : false,
        canBeNull         : false,
        isStrictPositive  : false,
        aggregator        : aggregators.SUM,
        isSet             : function(val, row){
            if(typeof(val)==='undefined'){
                return false;
            }
            if(!this.canBeNull && val === null){
                return false;
            }
            if(this.notEmpty   && val === ''){
                return false;
            }
            if(this.isStrictPositive && val <= 0){
                return false;
            }
            return true;
        },
        valueForCompare(val, row){
            return this.isSet(val) ? val : this.defCompareValue;
        },
        createAggregators(dimensions,isSummary){
            var res = {}; 
            if(this.isDimension){
                if(isSummary){
                    res[this.name] = aggregators.UNIC_COUNT;            
                } 
            } else if(this.aggregator){
                res[this.name] = this.aggregator;
            }
            return res;
        }
    };
    TODO: column.name
    var colums = {
        keyword: {
            isDimension : true  ,
            type        : 'str' ,
            notEmpty    : false ,
            createAggregators(dimensions,isSummary){
                var res = {};
                if(isSummary){
                    res[this.name] = aggregators.UNIC_COUNT;            
                } else {
                    for(var p=0; p<1; p++){
                        var prefix        = p ? 'my_' : '';
                        var haveUrl       = dimensions.indexOf(prefix+'url')!==-1;
                        var haveDomain    = dimensions.indexOf(prefix+'domain')!==-1;
                        var haveSubDomain = dimensions.indexOf(prefix+'subdomain')!==-1;
                        if(haveUrl || haveDomain || haveSubDomain){
                            res[prefix + 'top_keyword'] = function(vals,rows){
                                var col = 'traff';
                                
                                /*var maxKey  = '';
                                var maxFreq = 0;
                                var col     = 'region_queries_count';
                                if( dimensions.indexOf('my_url')!==-1 ||  dimensions.indexOf('my_domain')!==-1 ||  dimensions.indexOf('my_subdomain')!==-1){
                                    col = 'my_traff';
                                } else if(dimensions.indexOf('url')!==-1 ||  dimensions.indexOf('domain')!==-1 ||  dimensions.indexOf('subdomain')!==-1){
                                }
                                for(var i=0;i<vals.length;i++){
                                    if(rows[i][col] && maxFreq < rows[i][col]){
                                        maxFreq = rows[i][col]
                                        maxKey  = val[i];
                                    }
                                }
                                */
                            };
                        }
                        
                        
                    }
                    if(dimensions.indexOf('my_url')===-1 || dimensions.indexOf('url')===-1){
                        res.[(dimensions.indexOf('my_url')===-1 ? 'my_' :'')+'all_keywords'] = function(vals,rows){
                            var keys = {};
                            for(var i=0;i<vals.length;i++){
                                keys[vals[i]]=true;
                            }
                            return Object.keys(keys);
                        };
                        
                        for(var i=0;i<vals.length;i++){
                            if(rows[i][col] && maxFreq < rows[i][col]){
                                maxFreq = rows[i][col]
                                maxKey  = val[i];
                            }
                        }*/
                    }
                }
                /*
                
                    top_keyword : function(){
                        
                    },
                };
                */
            }
            //aggregateTo : function(dimensions){
            //    return (dimensions.indexOf('url') !== -1) ? 'sum_' : false;
            //}
        },

    };
    for(let i =-1; i<10; i++){
        let preffix = i===-1 ? 'my_' : '';
        let affix   = i>0    ? ''+i  : '';
        
        colums[preffix + 'url' + affix] = {
            isDimension       : true     , //Deleting dimension column can reduce rows count in table
            type              : 'str'    , 
            subtype           : 'url'    ,
            notEmpty          : true
        };
        
        let dcol = preffix + 'domain' + affix;
        colums[preffix + 'subdomain' + affix] = {
            isDimension     : true       ,
            type            : 'str'      ,
            subtype         : 'subdomain',
            lowUnic         : true       ,
            canBeNull       : true       ,
            valueForCompare : function(val, row){
                var domain = row[dcol];
                if(val || !domain){
                    return val||'';
                }
                return [val||'', domain];
            }
        };
        colums[preffix + 'domain' + affix] = {
            isDimension : true,
            type        : 'str',
            subtype     : 'domain',
            lowUnic     : true,
            notEmpty    : true
        };
        colums[preffix + 'position' + affix] = {
            isDimension       : true       , 
            type              : 'int'      ,
            subtype           : 'position' ,
            isStrictPositive  : true       ,   
            notEmpty          : true       ,
            defCompareValue   : 101        ,
            dimensions        : dimensions            
        };
        dimensions = [
            '_se','keyword',
            preffix + 'url' + affix,
            preffix + 'domain' + affix,
            preffix + 'subdomain' + affix
        ];
        colums[preffix + 'dynamic' + affix] = {
            type              : 'int'     ,
            subtype           : 'dynamic' ,
            canBeNegative     : true      ,
            notEmpty          : true      ,
            defCompareValue   : 0,
            dimensions        : dimensions            
        };
        colums[preffix + 'traff' + affix] = {
            type              : 'float' ,
            subtype           : 'traff' ,
            canBeNegative     : false   ,
            notEmpty          : true    ,
            dimensions        : dimensions,
            defCompareValue   : 0           
        };
        colums[preffix + 'sum_traff_cost' + affix] = {
            type              : 'float' ,
            subtype           : 'traff_cost',
            isMoney           : true    , 
            canBeNegative     : false   ,
            notEmpty          : true    ,
            dimensions        : dimensions,
            defCompareValue   : 0           
        };
        colums[preffix + 'av_traff_cost' + affix] = {
            type              : 'float' ,
            subtype           : 'traff_cost',
            isMoney           : true    , 
            canBeNegative     : false   ,
            notEmpty          : true    ,
            dimensions        : dimensions,
            defCompareValue   : 0           
        };
    };