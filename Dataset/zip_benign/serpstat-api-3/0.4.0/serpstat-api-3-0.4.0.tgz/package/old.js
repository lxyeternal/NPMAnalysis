            groupBy(dims){
                if(this.compressed){
                    throw new Error('groupBy() not impliments on compressed tables');
                }
                if(!this.dimensions){
                    throw new Error('This table does not hace dimensions');
                }
                if(typeof(dimensions) === 'string'){
                    dims = dimensions.trim()
                                .split(' ').join(',')
                                .split('\n').join(',')
                                .split('\r').join(',')
                                .split('\t').join(',')
                                .split(',,').join(',')
                                .split(',,').join(',')
                                .split(',,').join(',')
                                .split(',');
                }
                if(Array.isArray(dims)){
                    var tmp = {};
                    for(var i =0;i<dims.length;i++){
                        var cur = dims[i]
                        if(cur && cur.trim()){
                            tmp[cur.trim()] = 1;
                        }
                    }
                    dims = tmp;
                }
                for(var dim in dims) if(dims.hasOwnProperty(dim)){
                    if(typeof(this.cols[dim]) !== 'undefined'){
                        throw new Error('Table does not have col `'+dim+'`');
                    }
                }
                var arr = Object.keys(dims);
                var index = {};
                for(var i=0;i<this.length;i++){
                    var cs  = [];
                    var row = this[i];
                    for(var j=0;j<arr.length;j++){
                        cs.push(row[arr[j]]);
                    }
                    cs = cs.join(',');
                    index[cs] = index[cs] || [];
                    index[cs].push(row);
                }
                
                var keySumMetrixs = [];
                if(typeof(this.cols.region_queries_count) !== 'undefined'){
                    keySumMetrixs.push('region_queries_count');
                }
                if(typeof(this.cols.region_queries_count) !== 'undefined'){
                    keySumMetrixs.push('region_queries_count_wide');
                }
                if(typeof(this.cols.region_queries_count_last) !== 'undefined'){
                    keySumMetrixs.push('region_queries_count_last');
                }
                for(var cs in index) if(index.hasOwnProperty(cs)){
                    var rows   = index[cs];
                    var resRow = {};
                    for(var j=0;j<arr.length;j++){
                        resRow[arr[j]] = row[arr[j]];
                    }
                    for(var j=0;j<keySumMetrixs.length;j++){
                        resRow[keySumMetrixs[j]] = 0;
                    }
                    var keyword_length_sum = 0;
                    var nKeys              = 0;
                    if(typeof(this.cols.keyword) !== 'undefined'){
                        var keys = {};
                        for(var i=0;i<rows.length;i++){
                            var row = rows[i];
                            var key = [];
                            key.push(row.keyword);
                            if(typeof(this.cols._se) !== 'undefined'){
                                key.push(row._se);
                            }
                            key = key.join(',');
                            keys[key] = keys[key] || [];
                            keys[key].push(row);
                        }
                        if(keySumMetrixs.length){
                            for(var key in keys) if(key.hasOwnProperty(key)){
                                var rows2   = keys[key];
                                for(var i=0;i<rows2.length;i++){
                                    var row = rows2[i];
                                    for(var j=0;j<keySumMetrixs.length;j++){
                                        var col = keySumMetrixs[j];
                                        if(row[col]){
                                            resRow[col] += row[col]; 
                                        }
                                    }
                                    keyword_length_sum += row.keyword_length;
                                    nKeys              += 1;
                                    if(row[keySumMetrixs[0]]){
                                        break;
                                    }
                                }
                            }
                        }
                    } else {
                        for(var i=0;i<rows.length;i++){
                            var row = rows[i];
                            keyword_length_sum += row.keyword_length;
                            nKeys              += 1;
                            for(var j=0;j<keySumMetrixs.length;j++){
                                var col = keySumMetrixs[j];
                                if(row[col]){
                                    resRow[col] += row[col]; 
                                }
                            }
                        }
                    }
                    if(typeof(this.cols.keyword_length) !== 'undefined'){
                        row.keyword_length = keyword_length_sum/nKeys;
                    }
                }
            }
            //region_queries_count region_queries_count_wide region_queries_count_last 
            //found_results keyword_length
,
		csv:{
			encodeCell: function serpstatCSVEncodeCell(val,opts){
				if(typeof(val)==='undefined'){
					val = opts.undefinedText
				} else if(typeof(val)!=='string'){
					var val0 = val;
					val = val+'';
					//digit separator. Example 1.234 => 1,234 
					if(typeof(val0) === 'number' && opts.digitSeparator!=='.' && val.indexOf('.')!==-1){
						val.split('.').join(opts.digitSeparator);
					}
				}
				var quoted = false;
				if(val.indexOf('"')!==-1){
					val = val.split('"').join('""');//double-quote  must be represented by a pair of double-quote characters.
					quoted = true;//Fields with double-quote characters must be quoted.
				} else if(val.indexOf(opts.cellSeparator)!==-1 || val.indexOf("\n")!==-1){
					quoted = true; //Fields with commas characters must be quoted.
				}
				if(quoted){
					val = '"'+val+'"';
				}
				return val;
			},
			getCols: function serpstatCSVGetCols(data,opts){
				cols = cols || [];
				var was  = {};
				for(var i=0;i<cols.length;i++){
					was[cols[i]] = 1;
				}
				for(var i=0;i<data.length;i++){
					var row = data[i];
					for(var col in row) if(row.hasOwnProperty(col)){
						if(!was[col]){
							cols.push(col);
							was[col] = 1;
						}
					}
				}
				return cols;
			},
			encode: function serpstatCSVEncode(data,opts,cols,skipHeader,skipBody){//cols = undefined,skipHeader = undefined,skipBody = undefined
				opts                = opts                || {};
				opts.rowSeparator   = opts.rowSeparator   || "\r\n";
				opts.cellSeparator  = opts.cellSeparator  || "\t";
				opts.digitSeparator = opts.digitSeparator || ".";
				opts.undefinedText  = opts.undefinedText  || "";

				if(opts.rowSeparator==='unix'||opts.rowSeparator==='\\n'){
					opts.rowSeparator = '\n';
				} else if(opts.rowSeparator==='win'||opts.rowSeparator==='windows'||opts.rowSeparator==='\\r\\n'){
					opts.rowSeparator = '\r\n';
				}
				if(opts.cellSeparator==='tab'||opts.rowSeparator==='\\t'){
					opts.rowSeparator = '\t';
				}
				skipBody   = typeof(skipBody)   == 'undefined' ? opts.skipBody   : skipBody;
				skipHeader = typeof(skipHeader) == 'undefined' ? opts.skipHeader : skipHeader;
				cols       = typeof(cols)       == 'undefined' ? opts.cols       : cols;
				
				if(!cols){
					cols = utils.csv.getCols(data,opts)
				}
				var res = [];
				if(!skipHeader){
					var arr = [];
					for(var j=0;j<cols.length;j++){
						arr.push(utils.csv.encodeCell(cols[j],opts));
					}
					res.push(arr.join(opts.cellSeparator));
				}
				if(skipBody){
					return res[0];
				}
				for(var i=0;i<data.length;i++){
					var row = data[i];
					var arr = [];
					for(var j=0;j<cols.length;j++){
						arr.push(utils.csv.encodeCell(row[cols[j]],opts));
					}
					res.push(arr.join(opts.cellSeparator));
				}
				return res.join(opts.rowSeparator)+opts.rowSeparator;
			},
		},