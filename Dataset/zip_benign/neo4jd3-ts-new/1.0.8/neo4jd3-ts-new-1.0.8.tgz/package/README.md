# Typescript wrapper for [neo4jd3.js](https://www.npmjs.com/package/neo4jd3?activeTab=readme)


## getting started 

```
npm i neo4jd3-ts-new
```

## import 

```js
import createNeoChart, {NeoDatatoChartData} from "neo4jd3-ts"
```

### Data Format Reference

For details on the data format, please refer to the documentation of [neo4jd3.js](https://www.npmjs.com/package/neo4jd3?activeTab=readme).

### create chart 

```js

const c = createNeoChart("#select", {
  neo4jData: NeoDatatoChartData(data),
    nodeRadius:25,
  minCollision: 0.5,
})
```
## Interface

```js
 createNeoChart(parentElement: string | Node, options: Record<any,any>)


 // options -  [neo4jd3.js](https://www.npmjs.com/package/neo4jd3?activeTab=readme)
```
