import createNeoChart, { NeoDatatoChartData } from "./neoChart";
export { NeoDatatoChartData };
export default createNeoChart;
//# sourceMappingURL=index.d.ts.map