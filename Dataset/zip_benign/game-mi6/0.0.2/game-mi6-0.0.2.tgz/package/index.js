Component({
  mixins: [],
  data: {
    boxId: ""
  },
  props: {},
  didMount() {
    this.destroy();
    this.parFun("onRef", this);
    this.setData({
      boxId: `f_${this.uniId()}`
    }, () => {
      this.componentInit();
    })
  },
  didUpdate() { },
  didUnmount() {
    this.destroy();
  },
  methods: {
    destroy() {
      this.gameStatus = false;
      clearTimeout(this.timer);
    },
    uniId: function () {
      return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
    },
    //读取节点信息
    dom(className) {
      return new Promise(function (resolve, reject) {
        let result = {};
        my.createSelectorQuery()
          .select(className)
          .boundingClientRect()
          .exec(([ret]) => {
            if (ret) {
              result.success = true;
              result.data = ret;
            } else {
              result.success = false;
            }
            resolve(result);
          })
      })
    },
    parFun(funName, options) {
      let bl = false;
      try {
        // 判断组件是否有传入事件，如果没有，则再判断页面上是否有指定事件
        this.props[funName](options);
      } catch (e) {
        bl = true;
      }
      if (bl) {
        try {
          // 判断组件是否有传入事件，如果没有，则再判断页面上是否有指定事件
          this.$page[funName](options);
        } catch (e) {
          bl = true;
        }
      }
      if (bl) {
        console.log(`页面和组件传递都没有找到方法：${funName}`)
      }
    },
    random: function (options) {
      let opt = Object.assign({ min: 0, max: 0, isFloat: false, noNum: [] }, options);
      let tempNum;
      do {
        let num = Math.random() * (opt.max - opt.min) + opt.min;
        tempNum = !!opt.isFloat ? num : parseInt(num);
      } while (opt.noNum.includes(tempNum));
      return tempNum;
    },
    getRandomImg: function (images, opsFilter) {
      let filter = Object.assign({ not: {}, is: {} }, opsFilter);
      let isArr = Object.keys(filter.is);
      let notArr = Object.keys(filter.not);
      images.forEach(item => { item.del = false; })

      images.forEach(item => {
        isArr.forEach(isName => {
          if (item[isName] != filter.is[isName]) {
            item.del = true;
          }
        })
        notArr.forEach(isName => {
          if (item[isName] == filter.not[isName]) {
            item.del = true;
          }
        })
      })
      let arr = [];
      images.forEach(item => {
        if (!item.del) {
          arr.push(item);
        }
      })
      let totalProbability = 0;
      arr.forEach(item => {
        item.maxProbability = totalProbability + (item.probability || 1);
        totalProbability = item.maxProbability;
      });
      arr.forEach(item => {
        item.totalProbability = totalProbability;
      });

      let imgObj;
      let idx = 0;
      if (arr.length > 1) {
        idx = this.random({ max: totalProbability });
      }

      arr.forEach(item => {
        if (!imgObj && idx < item.maxProbability) {
          imgObj = item;
        }
      });
      return imgObj;
    },
    randomArray: function (arr) {
      return arr.sort(() => Math.random() - 0.5);
    },
    async componentInit() {
      let domData = await this.dom(`#${this.data.boxId}`);
      this.winW = domData.data.width;
      this.winH = domData.data.height;


      let gameData = this.props.gameSource;
      try {
        gameData = JSON.parse(gameData);
      } catch (e) { }
      this.gameData = gameData;
      let padding = Object.assign({
        left: 0,
        top: 0,
        right: 0,
        bottom: 0
      }, gameData.padding);
      this.setData({
        gameData,
        rotateTime: gameData.rotateTime || 0.5,
        padding
      })

      this.parFun("onInitDone", this);
    },
    async initGame(row, col, callback) {
      let _col = parseInt(col);
      let _row = parseInt(row);

      let totalNum = (_col * _row);
      let imgs = this.gameData.items;
      let curArr = [];
      let i = 0;
      imgs.forEach(img => {
        if (img.minShow) {
          for (let j = 0; j < img.minShow; j++) {
            if (curArr.length < totalNum) {
              curArr.push(img);
              i++;
            }
          }
        }
      })
      for (; i < totalNum; i++) {
        let img = this.getRandomImg(imgs);
        if (curArr.length < totalNum) {
          curArr.push(img);
        }
      }
      if (this.gameData.isRandom) {
        this.randomArray(curArr);
      }
      this.gameStatus = false;

      this.setData({
        singleW: this.winW / col,
        singleH: this.winH / row,
        row,
        col,
        images: curArr
      }, () => {
        !!callback && callback();
      })
    },
    clickFun(e) {
      let { currentTarget: { dataset: { index, item } } } = e;
      if (!this.gameStatus) { return false; }
      let obj = { success: false, item, index, curIdx: this.lightIdx };
      if (index == this.lightIdx) {
        // 点中了
        obj.success = true;
      } else {
        // 失败了
      }
      if (!(!!this.gameData.errStop && !obj.success)) {
        this.randomLight();
      }
      this.parFun("onUpdate", obj);
      if (!obj.success) {
        my.alert({ content: `${index}-${this.lightIdx}` })
      }
    },
    randomIdx() {
    },
    randomLight() {
      clearTimeout(this.timer);
      if (!this.gameStatus) { return false; }
      let cur = +new Date();
      let lastTime = this.lastTime || cur;
      let diff = cur - lastTime;
      if (diff >= (this.gameData.reduceCount || 1)) {
        this.timeNum -= (this.gameData.reduceTimeNum || 0.1);
        this.lastTime = cur;
      }
      this.timeNum = Math.max((this.gameData.minTimeNum, 0.5), this.timeNum);
      let idx = this.random({ min: 0, max: this.data.images.length, noNum: [(this.lightIdx || 0)] });
      this.setData({
        lightIdx: idx
      }, () => {
        this.lightIdx = idx;
        this.timer = setTimeout(() => {
          this.randomLight();
        }, this.timeNum * 1000)
      })
    },
    start() {
      if (this.gameStatus) { return false; }
      this.timeNum = this.gameData.timeNum || 2;
      this.lastTime = +new Date();

      /* timeNum: 2,//初始间隔时间
      minTimeNum: 0.5,//最小时间
      reduceCount: 1,//间隔多久递减
      reduceTimeNum: 0.1,//递减时间 */
      this.gameStatus = true;
      this.randomLight();
    },
    stop() {
      this.gameStatus = false;
      this.destroy();
    },
  },
});