# game-mi6

# 游戏

##### 安装

```
npm install game-mi6
```

##### 使用
- json

```
{
    "usingComponents": {
        "game": "game-mi6/index"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "game-mi6"
  ]
}
```

- js

```
Page({
  data: {
    gameSource: {
      padding: {
        left: 8,
        right: 8,
        top: 8,
        bottom: 8
      },
      errStop: true,//点错了就不更新了
      timeNum: 2,//初始间隔时间
      minTimeNum: 0.5,//最小时间
      reduceCount: 1,//间隔多久递减
      reduceTimeNum: 0.1,//递减时间
      isRandom: false,//打乱顺序
      items: [
        { active: { "url": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01zXZQyL1EUdMPXBp3H_!!2185320355.png" }, minShow: 3, "width": "177", "height": "221", "def": { "url": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01hY3hWi1EUdMOhfE9S_!!2185320355.png" } },
        { active: { "url": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01T09jtd1EUdMGGCUQ7_!!2185320355.png" }, minShow: 3, "width": "177", "height": "221", "def": { "url": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01H98l8u1EUdMMkgllm_!!2185320355.png" } },
        { active: { "url": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01pwxfK21EUdMGBAJMi_!!2185320355.png" }, minShow: 3, "width": "177", "height": "221", "def": { "url": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01sHBP671EUdMDpTNLy_!!2185320355.png" } },
      ],
    }
  },
  onLoad(query) {
    console.log('page onLoad', query)
  },
  onShow() { },
  // 开始游戏
  startFun() {
    this.gameComponent.start();
  },
  // 结束游戏
  stopFun() {
    this.gameComponent.stop();
  },

  onRef(ref) {
    this.gameComponent = ref;
  },
  onInitDone() {
    // 组件初始化完成
    this.initGame();
  },
  initGame() {
    // 渲染游戏
    // row:行,col:列
    this.gameComponent.initGame(3, 3, () => {
      // 游戏初始化完成 调用游戏开始在这个位置之后调用=================
    });
  },
  onUpdate(obj) {
    /* obj: {
      success: true,//true：点中了，false:没有点中
      item:点中对象
    } */
    if (!obj.success) {
      this.stopFun();
    }
    console.log(obj);
  }
})
```

- xaml

```
  <view class="pageBox">
    <game gameSource="{{gameSource}}" onRef="onRef" onInitDone="onInitDone" onUpdate="onUpdate" />
  </view>
  <view style="margin-top: 150rpx;">
    <view onTap="startFun">开始游戏</view>
    <view onTap="stopFun">结束游戏</view>
  </view>
```
- acss

```
.pageBox {
  position: absolute;
  left: 75rpx;
  top: 20vh;
  width: 576rpx;
  height: 708rpx;
  /* background-color: #ccc; */
}
```