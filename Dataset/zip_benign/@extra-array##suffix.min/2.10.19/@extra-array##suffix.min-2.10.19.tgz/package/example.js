const array = require("extra-array");

var x = [1, 2, 3];
array.suffix(x);

array.suffix(x, 1);

array.suffix(x, -1, 0.5);
