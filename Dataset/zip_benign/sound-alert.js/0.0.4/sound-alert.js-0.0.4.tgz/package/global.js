window.playAlert = require('./');
