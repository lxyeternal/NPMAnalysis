export declare class LiteSpotifyEmbed extends HTMLElement {
    private $wrapper;
    private $btnPlay;
    private content;
    private contentType;
    private tokenId;
    private _bgColor;
    private isIntersected;
    private isFrameFakePlaceHolderLoaded;
    private static _domains;
    private static _assets;
    private static isPrefetch;
    [key: string]: any;
    constructor();
    get bgColor(): string;
    set bgColor(val: string);
    private checkAttributteAndFetch;
    private static insertGlobalStyles;
    private setDOM;
    private fetchSpotify;
    private updateBgColor;
    private initFrameFakePlaceHolder;
    private addIframe;
    private setObserver;
    private static addPrefetch;
    private static warnConnections;
    static get observedAttributes(): string[];
    connectedCallback(): void;
    attributeChangedCallback(property: string, oldValue: string | number | undefined, newValue: string | number | undefined): void;
}
declare global {
    interface Window {
        liteSpotifyEmbedNonce: string;
    }
}
