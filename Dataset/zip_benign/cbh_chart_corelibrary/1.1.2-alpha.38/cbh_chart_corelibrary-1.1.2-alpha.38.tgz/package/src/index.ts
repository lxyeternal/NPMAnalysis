// browserify ./src/index.ts -p [ tsify --noImplicitAny ] > chart-bundle.js

import {Chart} from './classes/Chart';
export {Chart};

import {Ticks} from './classes/Ticks';
export {Ticks};

import {Legend} from './classes/Legend';
export {Legend};

import {Point} from './classes/Point';
export {Point};

import {Rectangle} from './classes/Rectangle';
export {Rectangle};


//@ts-ignore
window['Chart'] = Chart;
//@ts-ignore
window['Ticks'] = Ticks;
//@ts-ignore
window['Point'] = Point;
//@ts-ignore
window['Legend'] = Legend;
//@ts-ignore
window['Rectangle'] = Rectangle;
