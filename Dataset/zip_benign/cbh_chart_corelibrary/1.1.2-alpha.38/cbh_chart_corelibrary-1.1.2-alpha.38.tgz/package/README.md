# CBH-CHART-CORELIBRARY
### Version
v1.1.1

## Description
Chart library.  
This package can be used both as **npm dependecy** and as a **bundle**.

## Usage
Run command: `lerna add cbh_chart_corelibrary --scope=<direct-module-name>`   
to add this package as a dependency.  
  
Running: `lerna run --scope cbh_chart_corelibrary build-bundle`  
will create a `corelib-bundle.js` file, which can be added as:
`<script src="./corelib-bundle.js"></script>` into your `index.html`.

## Instancies
- `Chart`
- `Ticks`
- `Point`
- `Legend`
- `Rectangle`

## Current bundle:
You can download the current package file from the following link 📩: [coreLibrary-bundle](https://bitbucket.org/ch_rnd_lab/cbh-charts/src/master/packages/coreLibrary/corelib-bundle.js) 

## Last Features:
- Plot type **text**: `setTextLineOptions` method - enables setting cursor line paddings, length and rotation angle  
  usage example:  
```javascript
      // configuring Plot
      chart.addPlot('plotID', 'text', 1, '#000000') // plotID, plot type, lineWidth, lineColor
        .setTextLineOptions(20, 35, 20, -45) // padding before, line length, padding after, rotation angle deg
```
  ![example](/assets/plotLabel.png){width=640 height=480}

- Plot: `setLineWidthMediaQueries` method - enables setting lineWidth depending on mediaQuery  
  usage example:  
```javascript
      // configuring Plot
      const plotLineWidthList = [0.5, 1, 2]; // plot line width list
      const queryList = ['(min-width:320px) and (max-width:480px)', '(min-width:480px) and (max-width:768px)', '(min-width: 768px)']; // media queries list
      chart.addPlot('black_line', 'line', 1, '#000000', [], 'round') //set plot with common options
        .setLineWidthMediaQueries(plotLineWidthList, queryList); // set plot lineWidth for each media query
```