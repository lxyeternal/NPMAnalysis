'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.hpl = exports.hsl = exports.hpluv = exports.hsluv = undefined;

var _hsluv = require('hsluv');

const hsluv = exports.hsluv = (h, s, l, a) => {
    if (typeof a !== 'number') {
        return (0, _hsluv.hsluvToHex)([h, s, l]);
    } else {
        return `rgba(${(0, _hsluv.hsluvToRgb)([h, s, l]).map(x => Math.floor(x * 0xff)).join(',')},${a})`;
    }
};

const hpluv = exports.hpluv = (h, s, l, a) => {
    if (typeof a !== 'number') {
        return (0, _hsluv.hpluvToHex)([h, s, l]);
    } else {
        return `rgba(${(0, _hsluv.hpluvToRgb)([h, s, l]).map(x => Math.floor(x * 0xff)).join(',')},${a})`;
    }
};

const hsl = exports.hsl = hsluv;
const hpl = exports.hpl = hpluv;

exports.default = hsluv;

//# sourceMappingURL=index.js.map