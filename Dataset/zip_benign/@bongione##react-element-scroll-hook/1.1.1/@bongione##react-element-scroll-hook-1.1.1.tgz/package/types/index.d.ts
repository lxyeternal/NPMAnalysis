import { RefObject } from "react";
interface IDimensionScrollInfo {
    percentage: number | null;
    value: number;
    total: number;
    className: string;
    direction: number;
}
export interface IScrollInfo {
    x: Partial<IDimensionScrollInfo>;
    y: Partial<IDimensionScrollInfo>;
}
export declare type UseScrollInfoProps = [IScrollInfo, (element: HTMLElement) => void, RefObject<HTMLElement>];
declare function useScrollInfo(): UseScrollInfoProps;
export default useScrollInfo;
