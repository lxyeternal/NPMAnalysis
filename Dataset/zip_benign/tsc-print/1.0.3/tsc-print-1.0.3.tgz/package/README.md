# tsc-print

## 前言
本插件基于 `typescript` 开发，目的在于解决公司正在使用的 `MA2400P打印机` 的前端本地打印需求。插件对 `MA2400P打印机` 内部的初始化、连接、打印机全局命令、常用打印快捷命令、打印方法、websocket打印等方法封装，插件内部需要异步的接口均使用Promise封装，争取做到简单易用。

## 代码地址
[仓库地址](https://gitlab.yunjingtech.cn:10010/frontend/components/tsc-print)


## 快速使用
```js
import tscPrint from 'tsc-print'

const tsc = new tscPrint({
  width: 60,
  height: 40,
  gapHeight: 2.65
})

// 添加条形码
tsc.addBarCode({
  x: 10,
  y: 1,
  height: 20, 
  narrow: 0.5, 
  wide: 0.5, 
  code: '123456'
})

// 添加二维码
tsc.addQrCode({
  x: 10,
  y: 10,
  cellWidth: 8, 
  content: '爱我中华'
})

// 添加文字
tsc.addFont({
  x: 10,
  y: 1,
  fontheight: 10, 
  text: '爱我中华'
})

// 开始打印
tsc.startPrint().then(res => {
  console.log(res)
}).catch(_ => {
  console.log('打印失败', _)
})
```

## API列表

### > new tscPrint()

使用 `new tscPrint()` 方法创建一个打印对象，反回打印机常用方法以及本地usb打印机列表usbPrintList，后续所有打印操作都在此对象上进行。`paper` 参数为纸张相关信息，部分字段必填，`connection` 参数为连接信息，一般本地启动的socket服务的默认信息不用改，当改变了本地的连接信息后，如 端口，需要传入此项参数，或者配置了网络打印机的情况下，需要配置此参数。
```ts
const tsc = new tscPrint(paper: Paper, connection?: Connection)

// 打印机纸张信息
interface Paper {
  width: number // 标签宽度(单位mm)
  height: number // 标签高度(单位mm)
  gapHeight: number // 间隙高度(单位mm)
  speed?: number // 打印速度(单位mm) 默认 8
  density?: number // 打印浓度 0~15 默认为 8
  sensor?: sensorEnum // 标签类型["0":GAP, "1":BLINE] 默认GAP模式
  gapOffset?: number // 间隙偏移(单位mm) 默认 0
}

// 连接信息（可选）
interface Connection {
  printType?: printTypeEnum // 打印类型 默认为 0，网络打印机请填1
  socketIp?: string // socket Ip 默认 127.0.0.1
  socketPort?: string // socket 端口 默认 8888
  networkIp?: string // 网络打印Ip 无，当选择为网络打印时必填
  networkPort?: string // 网络打印端口 无，当选择为网络打印时必填
}

// 打印类型枚举
enum printTypeEnum {
  USB, // usb打印
  NETWORK // 网络打印
}

// 标签类型枚举
enum sensorEnum {
  GAP,
  BLINE
}
```

### > tsc.getSelfTest(usbPath?: string):Promise<object []>
打印自检页。
```ts
/**
 * 打印自检页
 * @param usbPath  可选，usb打印机path，不传默认为第一台，网络打印可不填
 * @return Promise<string>
 */
// 示例
tsc.getSelfTest().then(res => {
  console.log(res)
})
```

### > tsc.getUsbPrintList():Promise<object []>
获取usb打印机列表。
```ts
/**
 * 获取usb打印设备列表
 * @return Promise<object []>
 */
// 示例
tsc.getUsbPrintList().then(res => {
  console.log(res)
})
```

### > tsc.getPrintState(usbPath?: string):Promise<object []>
获取打印机状态。
```ts
/**
 * 获取usb打印机状态
 * @param usbPath 可选，usb打印机path，不传默认为第一台，网络打印可不填
 * @return Promise<object []>
 */
// 示例
tsc.getPrintState().then(res => {
  // { printerstatus: '' } // 状态
  // { printername: '' } // 名称
  // { printerserial: '' } // 打印机序号
})
```


### > tsc.resetDot(dot: number):void
重置插件内部dot，dot用于内部计算统一单位所用，部分api用的参数不是mm, 而是dot, 插件内部通过dot来转换的，默认为1 mm = 8 dots， 一般情况不用修改，如果外部设备DPI有变，调用此方法即可重置。
- 200 DPI : 1 mm = 8 dots
- 300 DPI : 1mm = 12 dots
```ts
/**
 * 重置插件内部dot
 * @param usbPath 可选，usb打印机path，不传默认为第一台，网络打印可不填
 */
// 示例
tsc.resetDot(12)
```

### > tsc.clearCmd():void
用于清空已经添加到内部缓存区的命令，清空完后可以重新添加，而不用再重新new一个对象，ps:调用打印方法后会自动清空缓存区内容，不用手动调用此方法，仅针对添加了错误命令的情况。
```ts
// 示例
tsc.clearCmd()
```

### > setCustomCmd(cmd: object):void
向缓存区尾部添加自定义命令，用于添加一些插件内部不能满足的自定义命令。
```ts
 /**
 * 在缓存区尾部添加自定义命令
 * @param cmd: object
 * @return void 
 */
// 示例
tsc.setCustomCmd({ printername: '' })
```

### > setCustomCmdUnShift(cmd: object):void
向缓存区头部添加自定义命令。
```ts
 /**
 * 在缓存区尾部添加自定义命令
 * @param cmd: object
 * @return void 
 */
// 示例
tsc.setCustomCmdUnShift({ printername: '' })
```

### > commandCrlf(cmd: string):void
向缓存区添加sendcommand_crlf命令。
```ts
 /**
 * 在缓存区尾部添加sendcommand_crlf命令
 * @param cmd: object
 * @return void 
 */
// 示例
tsc.commandCrlf('QRCODE 0,0,Q,10,A,0,M2,S7,"content"') // 打印二维码
// or
tsc.setCustomCmd({ sendcommand_crlf: 'QRCODE 0,0,Q,10,A,0,M2,S7,"content"' })
```


### > sendUint8Array(uint8_arr: Uint8Array):void
向缓存区添加uint8_arr命令。
```ts
/**
 * 添加元组数据到缓存区
 * @param uint8_arr 
 * @return void 
 */
// 示例
const u8 = new Uint8Array([12, 10])
tsc.sendUint8Array(u8)
```


### > addBarCode(bc: BarCodeModel):void
向缓存区添加条形码。
```ts
/**
 * 添加条形码到缓存区
 * @param BarCodeModel 
 * @return void 
 */
// 条形码信息
interface BarCodeModel {
  x: number		// 条码x轴座标(单位mm)
  y: number		// 条码y轴座标(单位mm)
  height: number		// 条码高度(单位mm)
  narrow: number		// 条码窄元件宽度[详见TSPL手册BARCODE条目](单位mm)
  wide: number			// 条码宽元件宽度[详见TSPL手册BARCODE条目](单位mm)
  code: string			// 条码内容
  type?: string		// 条码类型["128", "128M", "EAN128", "25", "25C", "39", "39C", "93", "EAN13", "EAN13+2", "EAN13+5", "EAN8", "EAN8+2", "EAN8+5", "CODA", "POST", "UPCA", "UPCA+2", "UPCA+5", "UPCE", "UPCE+2", "UPCE+5", "CPOST", "MSI", "MSIC", "PLESSEY", "ITF14", "EAN14", "11", "TELEPEN", "TELEPENN", "PLANET", "CODE49", "DPI", "DPL"] 默认 128
  readable?: number		// 条码码文位置["0":无, "1":置左, "2":置中, "3":置右] 默认 2
  rotation?: number		// 条码旋转["0":无, "90":90度, "180":180度, "270":270度] 默认 0
}

// 示例
tsc.addBarCode({
  x: 10,
  y: 1,
  height: 20, 
  narrow: 0.5, 
  wide: 0.5, 
  code: '123456'
})
```


### > addQrCode(q: QrCodeModel):void
向缓存区添加二维码。
```ts
/**
 * 添加二维码到缓存区
 * @param QrCodeModel 
 * @return void 
 */

// 二维码信息
interface QrCodeModel {
  x: number		// 二维码x轴座标(单位mm)
  y: number		// 二维码y轴座标(单位mm)
  cellWidth: number		// 二维码宽度 1~10
  content: string			// 二维码内容
  mask?: string			// S0~S8, 默认为 S7
  eccLevel?: string		// 纠错等级 L : 7% M : 15% Q : 25% H : 30% 默认 Q
  mode?: string		// 自动 / 手动编码 A : 自动  M : 手动 默认 A
  rotation?: number		// 条码旋转["0":无, "90":90度, "180":180度, "270":270度] 默认 0
  model?: string		// M1: , 原始版本 M2: 扩大版本 (大部分的智能手机支持此版本) 默认 M2
}

// 示例
tsc.addQrCode({
  x: 10,
  y: 10,
  cellWidth: 8, 
  content: '爱我中华'
})
```


### > addFont(q: FontModel):void
向缓存区添加文字信息。
```ts
/**
 * 添加文字到缓存区
 * @param FontModel 
 * @return void 
 */

// 文字信息
interface FontModel {
  x: number		// 文字x轴座标(单位mm)
  y: number		// 文字y轴座标(单位mm)
  fontheight: number		// 文字大小
  text: string			// 需要打印的文字
  rotation?: number		// 文字旋转["0":无, "90":90度, "180":180度, "270":270度] 默认 0
  fontstyle?: number		// 文字样式["0":无, "1":斜体, "2":粗体, "3":斜体+粗体] 默认 0
  fontunderline?: number // 文字底线["0":无, "1":底线] 默认 0
  szFaceName?: string		// 字型名称[例:"Arial"] 默认 Arial
}

// 示例
tsc.addFont({
  x: 10,
  y: 1,
  fontheight: 10, 
  text: '爱我中华'
})
```




### > tsc.startPrint(usbPath?: string[, lq?: LabelQuantity]):Promise<>
开始打印，打印后会自动清理缓存区，下次再打印时不必手动清理缓存区内容。
```ts
/**
 * 开始打印
 * @param usbPath 如果是usb打印，多台打印机的情况，可以传入usbPath来指定打印机，不传默认为第一台，网络打印可为空
 * @param LabelQuantity 
 * @returns  Promise<string>
 */

// 打印数量
interface LabelQuantity {
  sets: number // 打印份数 默认 1份
  copies?: number // 打印张数 默认 1
}

// 示例
tsc.startPrint().then(res => {
})
```

#### > Q&A一些常见问题
```
1. webSocket连接服务在哪里？
  答: tsc提供了一个windows的安装包，启动即可在本地启动webSocket服务，不管是使用网络打印方式还是本地打印机打印方式，均需在本地安装此软件（如果有远程服务器，在远程上安装了安装包，也可以连接远程的服务）。

2. 为什么网络打印还是需要连接本地webSocket服务？
  答：所有的打印api都在本地的webSocket服务中，由本地服务向打印机发送消息，安装包在代码仓库根目录。

3. 本地多台打印机的情况怎么办？
  答：本插件所有关于打印相关的接口均支持传打印机path，tsc对象里有usbList列表，打印时尽量带上usbPath路径打印，否则当本地有多台打印机时程序将会变得不可控。

4. 打印机还支持那些打印？
  答：打印机支持的打印内容还比较多，比如打印图片(但是非常难用，需要使用本地文件系统的文件地址，前端不能实现，除非手动将图片地址复制进去，可以使用DiagTool_V1.54.exe软件先上传到打印机后再打印)，设置字体，或者其他更多的内容，详见PSCL.pdf文档。

5. 怎么添加文档里没有的内容，比如打印图片？
  答：可以使用 setCustomCmd(cmd: object) 方法和 setCustomCmdUnShift(cmd: object) 添加自定义命令到缓存区。
```