/* tslint:disable */
/* eslint-disable */
/**
* @param {any} network_output
* @param {any} alphabet
* @param {number} beam_size
* @param {number} beam_cut_threshold
* @param {boolean} collapse_repeats
* @param {any} shape
* @returns {any}
*/
export function js_beam_search(network_output: any, alphabet: any, beam_size: number, beam_cut_threshold: number, collapse_repeats: boolean, shape: any): any;
/**
* @param {any} network_output
* @param {any} alphabet
* @param {boolean} qstring
* @param {number} qscale
* @param {number} qbias
* @param {boolean} collapse_repeats
* @param {any} shape
* @returns {any}
*/
export function js_viterbi_search(network_output: any, alphabet: any, qstring: boolean, qscale: number, qbias: number, collapse_repeats: boolean, shape: any): any;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly js_beam_search: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
  readonly js_viterbi_search: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => number;
  readonly __wbindgen_malloc: (a: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number) => number;
}

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {InitInput | Promise<InitInput>} module_or_path
*
* @returns {Promise<InitOutput>}
*/
export default function init (module_or_path?: InitInput | Promise<InitInput>): Promise<InitOutput>;
