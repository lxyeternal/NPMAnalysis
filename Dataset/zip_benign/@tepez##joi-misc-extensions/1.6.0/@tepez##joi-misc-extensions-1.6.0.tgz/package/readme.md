# joi-misc-extensions
> Various hapijs/joi extensions

[![npm version](https://badge.fury.io/js/%40tepez%2Fjoi-misc-extensions.svg)](https://badge.fury.io/js/%40tepez%2Fjoi-misc-extensions)
[![Build Status](https://secure.travis-ci.org/tepez/joi-misc-extensions.svg?branch=master)](http://travis-ci.org/tepez/joi-misc-extensions)

## Install

```
npm install --save @tepez/joi-misc-extensions
```

| Version |  [Joi](https://github.com/sideway/joi) |
| ------- |  ------------------------------------- |
| `0.4.x`  |  `14 joi`                             |

## Usage

### Extensions

```typescript
import * as Joi from 'joi'
import { 
    numberLuhnExtension, 
    numberRegexExtension, 
    stringConvertible, 
    jsonObjectExtension,
    jsonArrayExtension,
    StringConvertibleExtended
} from '@tepez/joi-misc-extensions'

export const ExtendedJoi: typeof Joi & StringConvertibleExtended = Joi.extend(
    numberLuhnExtension,
    numberRegexExtension,
    stringConvertible,
    jsonObjectExtension,
    jsonArrayExtension,
);

const luhnSchema = ExtendedJoi.number().luhn();

const regexSchema = ExtendedJoi.number().regex(/^\d{3}$/);

const stringConvertible = ExtendedJoi.stringConvertible();

ExtendedJoi.object().decodeJson().validate(`{ "foo": "bar" }`);

ExtendedJoi.array().decodeJson().validate(`[1,2,3]`);
```

### Schemas

#### Validation of Typescript enums

* enumSchema
* enumValueOrAutoLabelSchema
* enumOrEmptySchema
* arrayEnumSchema

#### Utility functions for object().fork()

* makeRequired
* makeOptional
* makeForbidden

```typescript
import * as Joi from 'joi'
import { makeForbidden } from '@tepez/joi-misc-extensions';

const obj = Joi.object().keys({
    a: Joi.string(),
    b: Joi.string(),
});

obj.fork([
    a,
    b,
], makeRequired)

obj.fork([
    a,
    b,
], makeOptional)

obj.fork([
    a,
    b,
], makeForbidden)
```

#### Misc

* typedValid

```typescript
import * as Joi from 'joi'
import { typedValid } from '@tepez/joi-misc-extensions';

type Type = 
    | 'aaa'
    | 'bbb'
    | 'ccc';

typedValid<Type>('aaa', 'bbb', 'ccc');
```