#!/usr/bin/env node
import { runCLI } from '@josselinbuils/tsoa-cli';

if (require.main === module) runCLI();
