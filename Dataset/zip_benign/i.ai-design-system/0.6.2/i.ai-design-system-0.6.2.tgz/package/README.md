# i.AI Design System

The i.AI Design System is based on [gov.uk design system](https://design-system.service.gov.uk/), customised for the i.AI brand and with additional components.



## Legacy version of i.AI Design System

The previous version of the i.AI Design System has been moved to the `version-0.5.x` branch.



## Installation

1. Install the i.AI design system using `npm install --save i.ai-design-system`
2. Import the CSS into your main CSS file, e.g. `@import "./node_modules/i.ai-design-system/dist/iai-design-system.css";`
3. Add the iai-design-system.js script to your base HTML template



## Documentation

The long-term plan is to host all the documentation online. For now, this can be viewed locally by running:
```
npm install
npm run build
npm run docs
```



## Contributing
To run the build:
```
npm install
npm run build
```

To publish to NPM, first update the version in `package.json`. Then login and run:
```
npm publish
```
