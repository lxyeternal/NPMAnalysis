import * as i0 from "@angular/core";
import * as i1 from "./components/vm-burger/vm-burger.component";
import * as i2 from "./directives/vm-button.directive";
export declare class VmButtonModule {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<VmButtonModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VmButtonModule, [typeof i1.VmBurgerComponent, typeof i2.VmButtonDirective], never, [typeof i1.VmBurgerComponent, typeof i2.VmButtonDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VmButtonModule>;
}
