export declare enum VmBurgerModes {
    STATIC_ALL = "static-all",
    STATIC_LEFT = "static-left",
    STATIC_RIGHT = "static-right",
    DYNAMIC_ALL = "dynamic-all",
    DYNAMIC_LEFT = "dynamic-left",
    DYNAMIC_RIGHT = "dynamic-right",
    ADVANCED_LEFT = "advanced-left",
    ADVANCED_RIGHT = "advanced-right"
}
