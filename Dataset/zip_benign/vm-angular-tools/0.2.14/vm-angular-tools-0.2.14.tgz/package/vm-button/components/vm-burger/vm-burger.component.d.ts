import { ElementRef, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { VmBurgerModes } from '../../enums/vm-burger-modes';
import * as i0 from "@angular/core";
export declare class VmBurgerComponent implements OnChanges {
    private elRef;
    private state;
    click: EventEmitter<MouseEvent>;
    getState: EventEmitter<boolean>;
    setState: boolean;
    mode: VmBurgerModes;
    color: string;
    cursor: string;
    constructor(elRef: ElementRef);
    ngOnChanges(changes: SimpleChanges): void;
    onBurger(event: MouseEvent): void;
    private getOpen;
    private getClose;
    static ɵfac: i0.ɵɵFactoryDeclaration<VmBurgerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VmBurgerComponent, "vm-burger", never, { "setState": "setState"; "mode": "mode"; }, { "click": "click"; "getState": "getState"; }, never, never, false, never>;
}
