import { ElementRef } from '@angular/core';
import * as i0 from "@angular/core";
export declare class VmButtonDirective {
    private elRef;
    private focus_visible;
    private styles;
    private readonly font_size;
    private readonly locker;
    constructor(elRef: ElementRef);
    private onMouseDown;
    private onMouseUp;
    private onActive;
    static ɵfac: i0.ɵɵFactoryDeclaration<VmButtonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<VmButtonDirective, "[vm-button]", never, {}, {}, never, never, false, never>;
}
