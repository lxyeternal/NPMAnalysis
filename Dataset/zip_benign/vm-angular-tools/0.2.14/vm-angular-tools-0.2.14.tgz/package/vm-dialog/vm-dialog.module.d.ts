import * as i0 from "@angular/core";
import * as i1 from "./components/vm-overlay/vm-overlay.component";
import * as i2 from "@angular/platform-browser/animations";
export declare class VmDialogModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<VmDialogModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VmDialogModule, [typeof i1.VmOverlayComponent], [typeof i2.BrowserAnimationsModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VmDialogModule>;
}
