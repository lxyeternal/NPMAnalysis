import { AfterViewInit, ChangeDetectorRef, ComponentRef, Type, ViewContainerRef } from '@angular/core';
import { IDialogOptions } from '../../interfaces/vm-dialog-interface';
import { AnimationBuilder, AnimationPlayer, AnimationStyleMetadata } from '@angular/animations';
import { VmDialogService } from '../../services/vm-dialog.service';
import * as i0 from "@angular/core";
export declare class VmOverlayComponent implements AfterViewInit {
    private dialogService;
    private animBuilder;
    private changeDetectorRef;
    dialogContainerRef: ViewContainerRef;
    options: IDialogOptions;
    component: Type<any>;
    private overlayRef;
    private dialogWrapperRef;
    componentRef: ComponentRef<any>;
    overlayColor: string;
    animationPlayer: AnimationPlayer;
    constructor(dialogService: VmDialogService, animBuilder: AnimationBuilder, changeDetectorRef: ChangeDetectorRef);
    ngAfterViewInit(): void;
    onOverlayClick(): void;
    createAnimationPlayer(currentState: AnimationStyleMetadata, newState: AnimationStyleMetadata, duration: number): void;
    onDialogClick(event: MouseEvent): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<VmOverlayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<VmOverlayComponent, "vm-dialog-vm-overlay", never, { "options": "options"; "component": "component"; }, {}, never, never, false, never>;
}
