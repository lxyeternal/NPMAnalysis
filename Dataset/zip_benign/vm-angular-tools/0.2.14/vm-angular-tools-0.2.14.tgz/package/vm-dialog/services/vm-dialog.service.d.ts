import { ApplicationRef, Type } from '@angular/core';
import { Observable } from 'rxjs';
import { IDialogClosingOptions, IDialogOptions } from '../interfaces/vm-dialog-interface';
import * as i0 from "@angular/core";
export declare class VmDialogService {
    private appRef;
    private overlayRefs;
    private subscribers;
    private animLocker;
    constructor(appRef: ApplicationRef);
    open<T>(component: Type<T>, options?: IDialogOptions): Observable<any>;
    close<T>(responseData?: T, closingOptions?: IDialogClosingOptions): void;
    getData(): any;
    private closeWithAnim;
    private closeWithoutAnim;
    static ɵfac: i0.ɵɵFactoryDeclaration<VmDialogService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<VmDialogService>;
}
