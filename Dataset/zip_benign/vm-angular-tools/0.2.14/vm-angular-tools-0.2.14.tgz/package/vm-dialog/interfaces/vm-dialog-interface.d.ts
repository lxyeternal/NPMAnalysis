import { AnimationStyleMetadata } from '@angular/animations';
export interface IDialogOptions {
    overlayClick: boolean;
    overlayColor?: string;
    animation?: IDialogAnimationOptions;
    data?: any;
}
export interface IDialogAnimationOptions {
    initStyleState: () => AnimationStyleMetadata;
    openedStyleState: () => AnimationStyleMetadata;
    closedStyleState: () => AnimationStyleMetadata;
    openingDuration: number;
    closingDuration: number;
}
export interface IDialogClosingOptions {
    closedStyleState: () => AnimationStyleMetadata;
    closingDuration: number;
}
export interface IDialogAnimStyles {
    top?: string;
    right?: string;
    bottom?: string;
    left?: string;
    width?: string;
    height?: string;
    transform?: string;
    opacity?: string;
}
