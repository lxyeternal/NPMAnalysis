import { AnimationStyleMetadata } from '@angular/animations';
import { IDialogAnimStyles } from '../interfaces/vm-dialog-interface';
export declare class VmDialogStyleStates {
    static rightX_centerY_hidden(): AnimationStyleMetadata;
    static leftX_centerY_hidden(): AnimationStyleMetadata;
    static centerX_bottomY_hidden(): AnimationStyleMetadata;
    static centerX_topY_hidden(): AnimationStyleMetadata;
    static centerX_centerY_hidden(): AnimationStyleMetadata;
    static centerX_centerY_visible(): AnimationStyleMetadata;
    static customState(styles: IDialogAnimStyles): () => AnimationStyleMetadata;
}
