import { Injectable, ViewContainerRef } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { VmOverlayComponent } from '../components/vm-overlay/vm-overlay.component';
import * as i0 from "@angular/core";
export class VmDialogService {
    constructor(appRef) {
        this.appRef = appRef;
        this.overlayRefs = [];
        this.subscribers = [];
        this.animLocker = false;
    }
    open(component, options) {
        const rootComponentType = this.appRef.componentTypes[0];
        const rootComponentRef = this.appRef.components.find((comp) => {
            return comp.componentType === rootComponentType;
        });
        if (rootComponentRef) {
            const viewContainerRef = rootComponentRef.injector.get(ViewContainerRef);
            this.overlayRefs.push(viewContainerRef.createComponent(VmOverlayComponent));
            this.overlayRefs[this.overlayRefs.length - 1].setInput('options', options);
            this.overlayRefs[this.overlayRefs.length - 1].setInput('component', component);
        }
        return new Observable((subscriber) => {
            this.subscribers.push(subscriber);
        }).pipe(tap(() => {
            if (this.overlayRefs.length) {
                const overlayRef = this.overlayRefs[this.overlayRefs.length - 1];
                const overlay = overlayRef.instance;
                const animation = overlay.options?.animation;
                this.closeWithAnim(overlayRef, overlay, animation);
                this.closeWithoutAnim(overlayRef, overlay, animation);
            }
        }));
    }
    close(responseData, closingOptions) {
        if (this.subscribers.length && !this.animLocker) {
            const animation = this.overlayRefs[this.overlayRefs.length - 1].instance.options?.animation;
            if (animation && closingOptions) {
                animation.closedStyleState = closingOptions.closedStyleState;
                animation.closingDuration = closingOptions.closingDuration;
            }
            this.subscribers[this.subscribers.length - 1].next(responseData);
        }
    }
    getData() {
        if (this.subscribers.length) {
            const overlay = this.overlayRefs[this.overlayRefs.length - 1].instance;
            if (overlay.options?.data) {
                return overlay.options.data;
            }
        }
        return null;
    }
    closeWithAnim(overlayRef, overlay, animation) {
        if (animation) {
            this.animLocker = true;
            overlay.createAnimationPlayer(animation.openedStyleState(), animation.closedStyleState(), animation.closingDuration);
            overlay.animationPlayer.play();
            setTimeout(() => {
                overlay.componentRef.destroy();
                overlayRef.destroy();
                this.subscribers.pop();
                this.overlayRefs.pop();
                this.animLocker = false;
            }, overlay.options.animation?.closingDuration);
        }
    }
    closeWithoutAnim(overlayRef, overlay, animation) {
        if (!animation) {
            overlay.componentRef.destroy();
            overlayRef.destroy();
            this.subscribers.pop();
            this.overlayRefs.pop();
        }
    }
}
VmDialogService.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmDialogService, deps: [{ token: i0.ApplicationRef }], target: i0.ɵɵFactoryTarget.Injectable });
VmDialogService.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmDialogService });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmDialogService, decorators: [{
            type: Injectable
        }], ctorParameters: function () { return [{ type: i0.ApplicationRef }]; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidm0tZGlhbG9nLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy92bS1hbmd1bGFyLXRvb2xzL3NyYy92bS1kaWFsb2cvc2VydmljZXMvdm0tZGlhbG9nLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUErQixVQUFVLEVBQVEsZ0JBQWdCLEVBQUMsTUFBTSxlQUFlLENBQUM7QUFDL0YsT0FBTyxFQUFDLFVBQVUsRUFBYyxHQUFHLEVBQUMsTUFBTSxNQUFNLENBQUM7QUFDakQsT0FBTyxFQUFDLGtCQUFrQixFQUFDLE1BQU0sK0NBQStDLENBQUM7O0FBSWpGLE1BQU0sT0FBTyxlQUFlO0lBSzFCLFlBQW9CLE1BQXNCO1FBQXRCLFdBQU0sR0FBTixNQUFNLENBQWdCO1FBSmxDLGdCQUFXLEdBQXVDLEVBQUUsQ0FBQztRQUNyRCxnQkFBVyxHQUFzQixFQUFFLENBQUM7UUFDcEMsZUFBVSxHQUFZLEtBQUssQ0FBQztJQUVVLENBQUM7SUFFeEMsSUFBSSxDQUFJLFNBQWtCLEVBQUUsT0FBd0I7UUFDekQsTUFBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUN4RCxNQUFNLGdCQUFnQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLElBQXVCLEVBQUUsRUFBRTtZQUMvRSxPQUFPLElBQUksQ0FBQyxhQUFhLEtBQUssaUJBQWlCLENBQUE7UUFDakQsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJLGdCQUFnQixFQUFFO1lBQ3BCLE1BQU0sZ0JBQWdCLEdBQUcsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1lBQ3pFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUM7WUFDNUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBQzNFLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxTQUFTLENBQUMsQ0FBQztTQUNoRjtRQUNELE9BQU8sSUFBSSxVQUFVLENBQU0sQ0FBQyxVQUEyQixFQUFFLEVBQUU7WUFDekQsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7UUFDcEMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUU7WUFDZixJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFO2dCQUMzQixNQUFNLFVBQVUsR0FBc0IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQztnQkFDcEYsTUFBTSxPQUFPLEdBQXVCLFVBQVUsQ0FBQyxRQUFRLENBQUM7Z0JBQ3hELE1BQU0sU0FBUyxHQUF3QyxPQUFPLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQztnQkFDbEYsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLEVBQUUsT0FBTyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2dCQUNuRCxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxFQUFFLE9BQU8sRUFBRSxTQUFTLENBQUMsQ0FBQzthQUN2RDtRQUNILENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDTixDQUFDO0lBRU0sS0FBSyxDQUFJLFlBQWdCLEVBQUUsY0FBc0M7UUFDdEUsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sSUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUU7WUFDL0MsTUFBTSxTQUFTLEdBQ2IsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLFNBQVMsQ0FBQztZQUM1RSxJQUFJLFNBQVMsSUFBSSxjQUFjLEVBQUU7Z0JBQy9CLFNBQVMsQ0FBQyxnQkFBZ0IsR0FBRyxjQUFjLENBQUMsZ0JBQWdCLENBQUM7Z0JBQzdELFNBQVMsQ0FBQyxlQUFlLEdBQUcsY0FBYyxDQUFDLGVBQWUsQ0FBQzthQUM1RDtZQUNELElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1NBQ2xFO0lBQ0gsQ0FBQztJQUVNLE9BQU87UUFDWixJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxFQUFFO1lBQzNCLE1BQU0sT0FBTyxHQUF1QixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztZQUMzRixJQUFJLE9BQU8sQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFO2dCQUN6QixPQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO2FBQzdCO1NBQ0Y7UUFDRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFFTyxhQUFhLENBQ25CLFVBQTRDLEVBQzVDLE9BQTJCLEVBQzNCLFNBQThDO1FBRTlDLElBQUksU0FBUyxFQUFFO1lBQ2IsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7WUFDdkIsT0FBTyxDQUFDLHFCQUFxQixDQUMzQixTQUFTLENBQUMsZ0JBQWdCLEVBQUUsRUFDNUIsU0FBUyxDQUFDLGdCQUFnQixFQUFFLEVBQzVCLFNBQVMsQ0FBQyxlQUFlLENBQUMsQ0FBQTtZQUM1QixPQUFPLENBQUMsZUFBZSxDQUFDLElBQUksRUFBRSxDQUFDO1lBQy9CLFVBQVUsQ0FBQyxHQUFHLEVBQUU7Z0JBQ2QsT0FBTyxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDL0IsVUFBVSxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUN2QixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDO2dCQUN2QixJQUFJLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztZQUMxQixDQUFDLEVBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsZUFBZSxDQUFDLENBQUM7U0FDaEQ7SUFDSCxDQUFDO0lBRU8sZ0JBQWdCLENBQ3RCLFVBQTRDLEVBQzVDLE9BQTJCLEVBQzNCLFNBQThDO1FBRTlDLElBQUksQ0FBQyxTQUFTLEVBQUU7WUFDZCxPQUFPLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQy9CLFVBQVUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ3ZCLElBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxFQUFFLENBQUM7U0FDeEI7SUFDSCxDQUFDOzs0R0F0RlUsZUFBZTtnSEFBZixlQUFlOzJGQUFmLGVBQWU7a0JBRDNCLFVBQVUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0FwcGxpY2F0aW9uUmVmLCBDb21wb25lbnRSZWYsIEluamVjdGFibGUsIFR5cGUsIFZpZXdDb250YWluZXJSZWZ9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHtPYnNlcnZhYmxlLCBTdWJzY3JpYmVyLCB0YXB9IGZyb20gJ3J4anMnO1xuaW1wb3J0IHtWbU92ZXJsYXlDb21wb25lbnR9IGZyb20gJy4uL2NvbXBvbmVudHMvdm0tb3ZlcmxheS92bS1vdmVybGF5LmNvbXBvbmVudCc7XG5pbXBvcnQge0lEaWFsb2dBbmltYXRpb25PcHRpb25zLCBJRGlhbG9nQ2xvc2luZ09wdGlvbnMsIElEaWFsb2dPcHRpb25zfSBmcm9tICcuLi9pbnRlcmZhY2VzL3ZtLWRpYWxvZy1pbnRlcmZhY2UnO1xuXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgVm1EaWFsb2dTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBvdmVybGF5UmVmczogQ29tcG9uZW50UmVmPFZtT3ZlcmxheUNvbXBvbmVudD5bXSA9IFtdO1xuICBwcml2YXRlIHN1YnNjcmliZXJzOiBTdWJzY3JpYmVyPGFueT5bXSA9IFtdO1xuICBwcml2YXRlIGFuaW1Mb2NrZXI6IGJvb2xlYW4gPSBmYWxzZTtcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIGFwcFJlZjogQXBwbGljYXRpb25SZWYpIHsgfVxuXG4gIHB1YmxpYyBvcGVuPFQ+KGNvbXBvbmVudDogVHlwZTxUPiwgb3B0aW9ucz86IElEaWFsb2dPcHRpb25zKTogT2JzZXJ2YWJsZTxhbnk+IHtcbiAgICBjb25zdCByb290Q29tcG9uZW50VHlwZSA9IHRoaXMuYXBwUmVmLmNvbXBvbmVudFR5cGVzWzBdO1xuICAgIGNvbnN0IHJvb3RDb21wb25lbnRSZWYgPSB0aGlzLmFwcFJlZi5jb21wb25lbnRzLmZpbmQoKGNvbXA6IENvbXBvbmVudFJlZjxhbnk+KSA9PiB7XG4gICAgICByZXR1cm4gY29tcC5jb21wb25lbnRUeXBlID09PSByb290Q29tcG9uZW50VHlwZVxuICAgIH0pO1xuICAgIGlmIChyb290Q29tcG9uZW50UmVmKSB7XG4gICAgICBjb25zdCB2aWV3Q29udGFpbmVyUmVmID0gcm9vdENvbXBvbmVudFJlZi5pbmplY3Rvci5nZXQoVmlld0NvbnRhaW5lclJlZik7XG4gICAgICB0aGlzLm92ZXJsYXlSZWZzLnB1c2godmlld0NvbnRhaW5lclJlZi5jcmVhdGVDb21wb25lbnQoVm1PdmVybGF5Q29tcG9uZW50KSk7XG4gICAgICB0aGlzLm92ZXJsYXlSZWZzW3RoaXMub3ZlcmxheVJlZnMubGVuZ3RoIC0gMV0uc2V0SW5wdXQoJ29wdGlvbnMnLCBvcHRpb25zKTtcbiAgICAgIHRoaXMub3ZlcmxheVJlZnNbdGhpcy5vdmVybGF5UmVmcy5sZW5ndGggLSAxXS5zZXRJbnB1dCgnY29tcG9uZW50JywgY29tcG9uZW50KTtcbiAgICB9XG4gICAgcmV0dXJuIG5ldyBPYnNlcnZhYmxlPGFueT4oKHN1YnNjcmliZXI6IFN1YnNjcmliZXI8YW55PikgPT4ge1xuICAgICAgdGhpcy5zdWJzY3JpYmVycy5wdXNoKHN1YnNjcmliZXIpO1xuICAgIH0pLnBpcGUodGFwKCgpID0+IHtcbiAgICAgIGlmICh0aGlzLm92ZXJsYXlSZWZzLmxlbmd0aCkge1xuICAgICAgICBjb25zdCBvdmVybGF5UmVmOiBDb21wb25lbnRSZWY8YW55PiA9IHRoaXMub3ZlcmxheVJlZnNbdGhpcy5vdmVybGF5UmVmcy5sZW5ndGggLSAxXTtcbiAgICAgICAgY29uc3Qgb3ZlcmxheTogVm1PdmVybGF5Q29tcG9uZW50ID0gb3ZlcmxheVJlZi5pbnN0YW5jZTtcbiAgICAgICAgY29uc3QgYW5pbWF0aW9uOiBJRGlhbG9nQW5pbWF0aW9uT3B0aW9ucyB8IHVuZGVmaW5lZCA9IG92ZXJsYXkub3B0aW9ucz8uYW5pbWF0aW9uO1xuICAgICAgICB0aGlzLmNsb3NlV2l0aEFuaW0ob3ZlcmxheVJlZiwgb3ZlcmxheSwgYW5pbWF0aW9uKTtcbiAgICAgICAgdGhpcy5jbG9zZVdpdGhvdXRBbmltKG92ZXJsYXlSZWYsIG92ZXJsYXksIGFuaW1hdGlvbik7XG4gICAgICB9XG4gICAgfSkpO1xuICB9XG5cbiAgcHVibGljIGNsb3NlPFQ+KHJlc3BvbnNlRGF0YT86IFQsIGNsb3NpbmdPcHRpb25zPzogSURpYWxvZ0Nsb3NpbmdPcHRpb25zKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuc3Vic2NyaWJlcnMubGVuZ3RoICYmICF0aGlzLmFuaW1Mb2NrZXIpIHtcbiAgICAgIGNvbnN0IGFuaW1hdGlvbjogSURpYWxvZ0FuaW1hdGlvbk9wdGlvbnMgfCB1bmRlZmluZWQgPVxuICAgICAgICB0aGlzLm92ZXJsYXlSZWZzW3RoaXMub3ZlcmxheVJlZnMubGVuZ3RoIC0gMV0uaW5zdGFuY2Uub3B0aW9ucz8uYW5pbWF0aW9uO1xuICAgICAgaWYgKGFuaW1hdGlvbiAmJiBjbG9zaW5nT3B0aW9ucykge1xuICAgICAgICBhbmltYXRpb24uY2xvc2VkU3R5bGVTdGF0ZSA9IGNsb3NpbmdPcHRpb25zLmNsb3NlZFN0eWxlU3RhdGU7XG4gICAgICAgIGFuaW1hdGlvbi5jbG9zaW5nRHVyYXRpb24gPSBjbG9zaW5nT3B0aW9ucy5jbG9zaW5nRHVyYXRpb247XG4gICAgICB9XG4gICAgICB0aGlzLnN1YnNjcmliZXJzW3RoaXMuc3Vic2NyaWJlcnMubGVuZ3RoIC0gMV0ubmV4dChyZXNwb25zZURhdGEpO1xuICAgIH1cbiAgfVxuXG4gIHB1YmxpYyBnZXREYXRhKCk6IGFueSB7XG4gICAgaWYgKHRoaXMuc3Vic2NyaWJlcnMubGVuZ3RoKSB7XG4gICAgICBjb25zdCBvdmVybGF5OiBWbU92ZXJsYXlDb21wb25lbnQgPSB0aGlzLm92ZXJsYXlSZWZzW3RoaXMub3ZlcmxheVJlZnMubGVuZ3RoIC0gMV0uaW5zdGFuY2U7XG4gICAgICBpZiAob3ZlcmxheS5vcHRpb25zPy5kYXRhKSB7XG4gICAgICAgIHJldHVybiBvdmVybGF5Lm9wdGlvbnMuZGF0YTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICBwcml2YXRlIGNsb3NlV2l0aEFuaW0oXG4gICAgb3ZlcmxheVJlZjogQ29tcG9uZW50UmVmPFZtT3ZlcmxheUNvbXBvbmVudD4sXG4gICAgb3ZlcmxheTogVm1PdmVybGF5Q29tcG9uZW50LFxuICAgIGFuaW1hdGlvbjogSURpYWxvZ0FuaW1hdGlvbk9wdGlvbnMgfCB1bmRlZmluZWRcbiAgKTogdm9pZCB7XG4gICAgaWYgKGFuaW1hdGlvbikge1xuICAgICAgdGhpcy5hbmltTG9ja2VyID0gdHJ1ZTtcbiAgICAgIG92ZXJsYXkuY3JlYXRlQW5pbWF0aW9uUGxheWVyKFxuICAgICAgICBhbmltYXRpb24ub3BlbmVkU3R5bGVTdGF0ZSgpLFxuICAgICAgICBhbmltYXRpb24uY2xvc2VkU3R5bGVTdGF0ZSgpLFxuICAgICAgICBhbmltYXRpb24uY2xvc2luZ0R1cmF0aW9uKVxuICAgICAgb3ZlcmxheS5hbmltYXRpb25QbGF5ZXIucGxheSgpO1xuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIG92ZXJsYXkuY29tcG9uZW50UmVmLmRlc3Ryb3koKTtcbiAgICAgICAgb3ZlcmxheVJlZi5kZXN0cm95KCk7XG4gICAgICAgIHRoaXMuc3Vic2NyaWJlcnMucG9wKCk7XG4gICAgICAgIHRoaXMub3ZlcmxheVJlZnMucG9wKCk7XG4gICAgICAgIHRoaXMuYW5pbUxvY2tlciA9IGZhbHNlO1xuICAgICAgfSwgb3ZlcmxheS5vcHRpb25zLmFuaW1hdGlvbj8uY2xvc2luZ0R1cmF0aW9uKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGNsb3NlV2l0aG91dEFuaW0oXG4gICAgb3ZlcmxheVJlZjogQ29tcG9uZW50UmVmPFZtT3ZlcmxheUNvbXBvbmVudD4sXG4gICAgb3ZlcmxheTogVm1PdmVybGF5Q29tcG9uZW50LFxuICAgIGFuaW1hdGlvbjogSURpYWxvZ0FuaW1hdGlvbk9wdGlvbnMgfCB1bmRlZmluZWRcbiAgKTogdm9pZCB7XG4gICAgaWYgKCFhbmltYXRpb24pIHtcbiAgICAgIG92ZXJsYXkuY29tcG9uZW50UmVmLmRlc3Ryb3koKTtcbiAgICAgIG92ZXJsYXlSZWYuZGVzdHJveSgpO1xuICAgICAgdGhpcy5zdWJzY3JpYmVycy5wb3AoKTtcbiAgICAgIHRoaXMub3ZlcmxheVJlZnMucG9wKCk7XG4gICAgfVxuICB9XG59XG4iXX0=