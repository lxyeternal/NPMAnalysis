import { style } from '@angular/animations';
export class VmDialogStyleStates {
    static rightX_centerY_hidden() {
        return style({
            position: 'fixed',
            top: '50%',
            left: '100%',
            transform: 'translateY(-50%)',
            opacity: '0'
        });
    }
    static leftX_centerY_hidden() {
        return style({
            position: 'fixed',
            top: '50%',
            left: '0',
            transform: 'translateX(-100%) translateY(-50%)',
            opacity: '0'
        });
    }
    static centerX_bottomY_hidden() {
        return style({
            position: 'fixed',
            top: '100%',
            left: '50%',
            transform: 'translateX(-50%)',
            opacity: '0'
        });
    }
    static centerX_topY_hidden() {
        return style({
            position: 'fixed',
            top: '0',
            left: '50%',
            transform: 'translateX(-50%) translateY(-100%)',
            opacity: '0'
        });
    }
    static centerX_centerY_hidden() {
        return style({
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translateX(-50%) translateY(-50%)',
            opacity: '0'
        });
    }
    static centerX_centerY_visible() {
        return style({
            position: 'fixed',
            top: '50%',
            left: '50%',
            transform: 'translateX(-50%) translateY(-50%)',
            opacity: '1'
        });
    }
    static customState(styles) {
        return () => {
            return style({
                position: 'fixed',
                ...styles
            });
        };
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidm0tZGlhbG9nLXN0eWxlLXN0YXRlcy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL3ZtLWFuZ3VsYXItdG9vbHMvc3JjL3ZtLWRpYWxvZy9jbGFzc2VzL3ZtLWRpYWxvZy1zdHlsZS1zdGF0ZXMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUF5QixLQUFLLEVBQUMsTUFBTSxxQkFBcUIsQ0FBQztBQUdsRSxNQUFNLE9BQU8sbUJBQW1CO0lBRXZCLE1BQU0sQ0FBQyxxQkFBcUI7UUFDakMsT0FBTyxLQUFLLENBQUM7WUFDWCxRQUFRLEVBQUUsT0FBTztZQUNqQixHQUFHLEVBQUUsS0FBSztZQUNWLElBQUksRUFBRSxNQUFNO1lBQ1osU0FBUyxFQUFFLGtCQUFrQjtZQUM3QixPQUFPLEVBQUUsR0FBRztTQUNiLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFTSxNQUFNLENBQUMsb0JBQW9CO1FBQ2hDLE9BQU8sS0FBSyxDQUFDO1lBQ1gsUUFBUSxFQUFFLE9BQU87WUFDakIsR0FBRyxFQUFFLEtBQUs7WUFDVixJQUFJLEVBQUUsR0FBRztZQUNULFNBQVMsRUFBRSxvQ0FBb0M7WUFDL0MsT0FBTyxFQUFFLEdBQUc7U0FDYixDQUFDLENBQUE7SUFDSixDQUFDO0lBRU0sTUFBTSxDQUFDLHNCQUFzQjtRQUNsQyxPQUFPLEtBQUssQ0FBQztZQUNYLFFBQVEsRUFBRSxPQUFPO1lBQ2pCLEdBQUcsRUFBRSxNQUFNO1lBQ1gsSUFBSSxFQUFFLEtBQUs7WUFDWCxTQUFTLEVBQUUsa0JBQWtCO1lBQzdCLE9BQU8sRUFBRSxHQUFHO1NBQ2IsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVNLE1BQU0sQ0FBQyxtQkFBbUI7UUFDL0IsT0FBTyxLQUFLLENBQUM7WUFDWCxRQUFRLEVBQUUsT0FBTztZQUNqQixHQUFHLEVBQUUsR0FBRztZQUNSLElBQUksRUFBRSxLQUFLO1lBQ1gsU0FBUyxFQUFFLG9DQUFvQztZQUMvQyxPQUFPLEVBQUUsR0FBRztTQUNiLENBQUMsQ0FBQTtJQUNKLENBQUM7SUFDTSxNQUFNLENBQUMsc0JBQXNCO1FBQ2xDLE9BQU8sS0FBSyxDQUFDO1lBQ1gsUUFBUSxFQUFFLE9BQU87WUFDakIsR0FBRyxFQUFFLEtBQUs7WUFDVixJQUFJLEVBQUUsS0FBSztZQUNYLFNBQVMsRUFBRSxtQ0FBbUM7WUFDOUMsT0FBTyxFQUFFLEdBQUc7U0FDYixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRU0sTUFBTSxDQUFDLHVCQUF1QjtRQUNuQyxPQUFPLEtBQUssQ0FBQztZQUNYLFFBQVEsRUFBRSxPQUFPO1lBQ2pCLEdBQUcsRUFBRSxLQUFLO1lBQ1YsSUFBSSxFQUFFLEtBQUs7WUFDWCxTQUFTLEVBQUUsbUNBQW1DO1lBQzlDLE9BQU8sRUFBRSxHQUFHO1NBQ2IsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVNLE1BQU0sQ0FBQyxXQUFXLENBQUMsTUFBeUI7UUFDakQsT0FBTyxHQUFHLEVBQUU7WUFDVixPQUFPLEtBQUssQ0FBQztnQkFDWCxRQUFRLEVBQUUsT0FBTztnQkFDakIsR0FBRyxNQUFNO2FBQ1YsQ0FBQyxDQUFDO1FBQ0wsQ0FBQyxDQUFBO0lBQ0gsQ0FBQztDQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtBbmltYXRpb25TdHlsZU1ldGFkYXRhLCBzdHlsZX0gZnJvbSAnQGFuZ3VsYXIvYW5pbWF0aW9ucyc7XG5pbXBvcnQge0lEaWFsb2dBbmltU3R5bGVzfSBmcm9tICcuLi9pbnRlcmZhY2VzL3ZtLWRpYWxvZy1pbnRlcmZhY2UnO1xuXG5leHBvcnQgY2xhc3MgVm1EaWFsb2dTdHlsZVN0YXRlcyB7XG5cbiAgcHVibGljIHN0YXRpYyByaWdodFhfY2VudGVyWV9oaWRkZW4oKTogQW5pbWF0aW9uU3R5bGVNZXRhZGF0YSB7XG4gICAgcmV0dXJuIHN0eWxlKHtcbiAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgICAgdG9wOiAnNTAlJyxcbiAgICAgIGxlZnQ6ICcxMDAlJyxcbiAgICAgIHRyYW5zZm9ybTogJ3RyYW5zbGF0ZVkoLTUwJSknLFxuICAgICAgb3BhY2l0eTogJzAnXG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgc3RhdGljIGxlZnRYX2NlbnRlcllfaGlkZGVuKCk6IEFuaW1hdGlvblN0eWxlTWV0YWRhdGEge1xuICAgIHJldHVybiBzdHlsZSh7XG4gICAgICBwb3NpdGlvbjogJ2ZpeGVkJyxcbiAgICAgIHRvcDogJzUwJScsXG4gICAgICBsZWZ0OiAnMCcsXG4gICAgICB0cmFuc2Zvcm06ICd0cmFuc2xhdGVYKC0xMDAlKSB0cmFuc2xhdGVZKC01MCUpJyxcbiAgICAgIG9wYWNpdHk6ICcwJ1xuICAgIH0pXG4gIH1cblxuICBwdWJsaWMgc3RhdGljIGNlbnRlclhfYm90dG9tWV9oaWRkZW4oKTogQW5pbWF0aW9uU3R5bGVNZXRhZGF0YSB7XG4gICAgcmV0dXJuIHN0eWxlKHtcbiAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxuICAgICAgdG9wOiAnMTAwJScsXG4gICAgICBsZWZ0OiAnNTAlJyxcbiAgICAgIHRyYW5zZm9ybTogJ3RyYW5zbGF0ZVgoLTUwJSknLFxuICAgICAgb3BhY2l0eTogJzAnXG4gICAgfSlcbiAgfVxuXG4gIHB1YmxpYyBzdGF0aWMgY2VudGVyWF90b3BZX2hpZGRlbigpOiBBbmltYXRpb25TdHlsZU1ldGFkYXRhIHtcbiAgICByZXR1cm4gc3R5bGUoe1xuICAgICAgcG9zaXRpb246ICdmaXhlZCcsXG4gICAgICB0b3A6ICcwJyxcbiAgICAgIGxlZnQ6ICc1MCUnLFxuICAgICAgdHJhbnNmb3JtOiAndHJhbnNsYXRlWCgtNTAlKSB0cmFuc2xhdGVZKC0xMDAlKScsXG4gICAgICBvcGFjaXR5OiAnMCdcbiAgICB9KVxuICB9XG4gIHB1YmxpYyBzdGF0aWMgY2VudGVyWF9jZW50ZXJZX2hpZGRlbigpOiBBbmltYXRpb25TdHlsZU1ldGFkYXRhIHtcbiAgICByZXR1cm4gc3R5bGUoe1xuICAgICAgcG9zaXRpb246ICdmaXhlZCcsXG4gICAgICB0b3A6ICc1MCUnLFxuICAgICAgbGVmdDogJzUwJScsXG4gICAgICB0cmFuc2Zvcm06ICd0cmFuc2xhdGVYKC01MCUpIHRyYW5zbGF0ZVkoLTUwJSknLFxuICAgICAgb3BhY2l0eTogJzAnXG4gICAgfSk7XG4gIH1cblxuICBwdWJsaWMgc3RhdGljIGNlbnRlclhfY2VudGVyWV92aXNpYmxlKCk6IEFuaW1hdGlvblN0eWxlTWV0YWRhdGEge1xuICAgIHJldHVybiBzdHlsZSh7XG4gICAgICBwb3NpdGlvbjogJ2ZpeGVkJyxcbiAgICAgIHRvcDogJzUwJScsXG4gICAgICBsZWZ0OiAnNTAlJyxcbiAgICAgIHRyYW5zZm9ybTogJ3RyYW5zbGF0ZVgoLTUwJSkgdHJhbnNsYXRlWSgtNTAlKScsXG4gICAgICBvcGFjaXR5OiAnMSdcbiAgICB9KTtcbiAgfVxuXG4gIHB1YmxpYyBzdGF0aWMgY3VzdG9tU3RhdGUoc3R5bGVzOiBJRGlhbG9nQW5pbVN0eWxlcyk6ICgpID0+IEFuaW1hdGlvblN0eWxlTWV0YWRhdGEge1xuICAgIHJldHVybiAoKSA9PiB7XG4gICAgICByZXR1cm4gc3R5bGUoe1xuICAgICAgICBwb3NpdGlvbjogJ2ZpeGVkJyxcbiAgICAgICAgLi4uc3R5bGVzXG4gICAgICB9KTtcbiAgICB9XG4gIH1cbn1cbiJdfQ==