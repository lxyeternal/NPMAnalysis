import { Component, Input, ViewChild, ViewContainerRef } from '@angular/core';
import { animate } from '@angular/animations';
import * as i0 from "@angular/core";
import * as i1 from "../../services/vm-dialog.service";
import * as i2 from "@angular/animations";
export class VmOverlayComponent {
    constructor(dialogService, animBuilder, changeDetectorRef) {
        this.dialogService = dialogService;
        this.animBuilder = animBuilder;
        this.changeDetectorRef = changeDetectorRef;
        this.overlayColor = 'rgba(0, 0, 0, 0.5)';
    }
    ngAfterViewInit() {
        this.componentRef = this.dialogContainerRef.createComponent(this.component);
        if (this.options?.overlayColor) {
            this.overlayColor = this.options.overlayColor;
        }
        if (this.options?.animation) {
            this.createAnimationPlayer(this.options.animation.initStyleState(), this.options.animation.openedStyleState(), this.options.animation.openingDuration);
            this.animationPlayer.play();
        }
        this.changeDetectorRef.detectChanges();
    }
    onOverlayClick() {
        if (this.options?.overlayClick) {
            this.dialogService.close(null);
        }
    }
    createAnimationPlayer(currentState, newState, duration) {
        if (this.animationPlayer) {
            this.animationPlayer.destroy();
        }
        const animationFactory = this.animBuilder.build([currentState, animate(duration, newState)]);
        this.animationPlayer = animationFactory.create(this.dialogWrapperRef.nativeElement);
    }
    onDialogClick(event) {
        event.stopPropagation();
        event.preventDefault();
    }
}
VmOverlayComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmOverlayComponent, deps: [{ token: i1.VmDialogService }, { token: i2.AnimationBuilder }, { token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
VmOverlayComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "15.2.2", type: VmOverlayComponent, selector: "vm-dialog-vm-overlay", inputs: { options: "options", component: "component" }, viewQueries: [{ propertyName: "dialogContainerRef", first: true, predicate: ["dialogContainer"], descendants: true, read: ViewContainerRef }, { propertyName: "overlayRef", first: true, predicate: ["overlay"], descendants: true }, { propertyName: "dialogWrapperRef", first: true, predicate: ["dialogWrapper"], descendants: true }], ngImport: i0, template: "<div #overlay\n     class=\"overlay\"\n     [style.background-color]=\"overlayColor\"\n     (click)=\"onOverlayClick()\">\n  <div #dialogWrapper class=\"dialog-wrapper\" (click)=\"onDialogClick($event)\">\n    <ng-container #dialogContainer></ng-container>\n  </div>\n</div>\n", styles: [":host .overlay{position:fixed;top:0;left:0;width:100%;height:100%;display:flex;justify-content:center;align-items:center;overflow:hidden;background-color:#00000080;z-index:5000}:host .dialog-wrapper{overflow:hidden}\n"] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmOverlayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'vm-dialog-vm-overlay', template: "<div #overlay\n     class=\"overlay\"\n     [style.background-color]=\"overlayColor\"\n     (click)=\"onOverlayClick()\">\n  <div #dialogWrapper class=\"dialog-wrapper\" (click)=\"onDialogClick($event)\">\n    <ng-container #dialogContainer></ng-container>\n  </div>\n</div>\n", styles: [":host .overlay{position:fixed;top:0;left:0;width:100%;height:100%;display:flex;justify-content:center;align-items:center;overflow:hidden;background-color:#00000080;z-index:5000}:host .dialog-wrapper{overflow:hidden}\n"] }]
        }], ctorParameters: function () { return [{ type: i1.VmDialogService }, { type: i2.AnimationBuilder }, { type: i0.ChangeDetectorRef }]; }, propDecorators: { dialogContainerRef: [{
                type: ViewChild,
                args: ['dialogContainer', { read: ViewContainerRef }]
            }], options: [{
                type: Input
            }], component: [{
                type: Input
            }], overlayRef: [{
                type: ViewChild,
                args: ['overlay']
            }], dialogWrapperRef: [{
                type: ViewChild,
                args: ['dialogWrapper']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidm0tb3ZlcmxheS5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi8uLi9wcm9qZWN0cy92bS1hbmd1bGFyLXRvb2xzL3NyYy92bS1kaWFsb2cvY29tcG9uZW50cy92bS1vdmVybGF5L3ZtLW92ZXJsYXkuY29tcG9uZW50LnRzIiwiLi4vLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvdm0tYW5ndWxhci10b29scy9zcmMvdm0tZGlhbG9nL2NvbXBvbmVudHMvdm0tb3ZlcmxheS92bS1vdmVybGF5LmNvbXBvbmVudC5odG1sIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFHTCxTQUFTLEVBR1QsS0FBSyxFQUVMLFNBQVMsRUFDVCxnQkFBZ0IsRUFDakIsTUFBTSxlQUFlLENBQUM7QUFFdkIsT0FBTyxFQUFDLE9BQU8sRUFBNEQsTUFBTSxxQkFBcUIsQ0FBQzs7OztBQVF2RyxNQUFNLE9BQU8sa0JBQWtCO0lBVTdCLFlBQW9CLGFBQThCLEVBQzlCLFdBQTZCLEVBQzdCLGlCQUFvQztRQUZwQyxrQkFBYSxHQUFiLGFBQWEsQ0FBaUI7UUFDOUIsZ0JBQVcsR0FBWCxXQUFXLENBQWtCO1FBQzdCLHNCQUFpQixHQUFqQixpQkFBaUIsQ0FBbUI7UUFMakQsaUJBQVksR0FBVyxvQkFBb0IsQ0FBQztJQU1uRCxDQUFDO0lBRU0sZUFBZTtRQUNwQixJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQzVFLElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxZQUFZLEVBQUU7WUFDOUIsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQztTQUMvQztRQUNELElBQUksSUFBSSxDQUFDLE9BQU8sRUFBRSxTQUFTLEVBQUU7WUFDM0IsSUFBSSxDQUFDLHFCQUFxQixDQUN4QixJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxjQUFjLEVBQUUsRUFDdkMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsZ0JBQWdCLEVBQUUsRUFDekMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsZUFBZSxDQUN2QyxDQUFDO1lBQ0YsSUFBSSxDQUFDLGVBQWUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUM3QjtRQUNELElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxhQUFhLEVBQUUsQ0FBQztJQUN6QyxDQUFDO0lBRU0sY0FBYztRQUNuQixJQUFJLElBQUksQ0FBQyxPQUFPLEVBQUUsWUFBWSxFQUFFO1lBQzlCLElBQUksQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFPLElBQUksQ0FBQyxDQUFDO1NBQ3RDO0lBQ0gsQ0FBQztJQUVNLHFCQUFxQixDQUMxQixZQUFvQyxFQUNwQyxRQUFnQyxFQUNoQyxRQUFnQjtRQUNoQixJQUFJLElBQUksQ0FBQyxlQUFlLEVBQUU7WUFDeEIsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztTQUNoQztRQUNELE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLFFBQVEsRUFBRSxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDN0YsSUFBSSxDQUFDLGVBQWUsR0FBRyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ3RGLENBQUM7SUFFTSxhQUFhLENBQUMsS0FBaUI7UUFDcEMsS0FBSyxDQUFDLGVBQWUsRUFBRSxDQUFDO1FBQ3hCLEtBQUssQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUN6QixDQUFDOzsrR0FuRFUsa0JBQWtCO21HQUFsQixrQkFBa0Isc05BQ1EsZ0JBQWdCLHlOQ3JCdkQsc1JBUUE7MkZEWWEsa0JBQWtCO2tCQUw5QixTQUFTOytCQUNFLHNCQUFzQjtxS0FLK0Isa0JBQWtCO3NCQUFoRixTQUFTO3VCQUFDLGlCQUFpQixFQUFFLEVBQUMsSUFBSSxFQUFFLGdCQUFnQixFQUFDO2dCQUN0QyxPQUFPO3NCQUF0QixLQUFLO2dCQUNVLFNBQVM7c0JBQXhCLEtBQUs7Z0JBQ3dCLFVBQVU7c0JBQXZDLFNBQVM7dUJBQUMsU0FBUztnQkFDZ0IsZ0JBQWdCO3NCQUFuRCxTQUFTO3VCQUFDLGVBQWUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge1xuICBBZnRlclZpZXdJbml0LFxuICBDaGFuZ2VEZXRlY3RvclJlZixcbiAgQ29tcG9uZW50LFxuICBDb21wb25lbnRSZWYsXG4gIEVsZW1lbnRSZWYsXG4gIElucHV0LFxuICBUeXBlLFxuICBWaWV3Q2hpbGQsXG4gIFZpZXdDb250YWluZXJSZWZcbn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge0lEaWFsb2dPcHRpb25zfSBmcm9tICcuLi8uLi9pbnRlcmZhY2VzL3ZtLWRpYWxvZy1pbnRlcmZhY2UnO1xuaW1wb3J0IHthbmltYXRlLCBBbmltYXRpb25CdWlsZGVyLCBBbmltYXRpb25QbGF5ZXIsIEFuaW1hdGlvblN0eWxlTWV0YWRhdGF9IGZyb20gJ0Bhbmd1bGFyL2FuaW1hdGlvbnMnO1xuaW1wb3J0IHtWbURpYWxvZ1NlcnZpY2V9IGZyb20gJy4uLy4uL3NlcnZpY2VzL3ZtLWRpYWxvZy5zZXJ2aWNlJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAndm0tZGlhbG9nLXZtLW92ZXJsYXknLFxuICB0ZW1wbGF0ZVVybDogJy4vdm0tb3ZlcmxheS5jb21wb25lbnQuaHRtbCcsXG4gIHN0eWxlVXJsczogWycuL3ZtLW92ZXJsYXkuY29tcG9uZW50LnNjc3MnXVxufSlcbmV4cG9ydCBjbGFzcyBWbU92ZXJsYXlDb21wb25lbnQgaW1wbGVtZW50cyBBZnRlclZpZXdJbml0IHtcbiAgQFZpZXdDaGlsZCgnZGlhbG9nQ29udGFpbmVyJywge3JlYWQ6IFZpZXdDb250YWluZXJSZWZ9KSBwdWJsaWMgZGlhbG9nQ29udGFpbmVyUmVmITogVmlld0NvbnRhaW5lclJlZjtcbiAgQElucHV0KCkgcHVibGljIG9wdGlvbnMhOiBJRGlhbG9nT3B0aW9ucztcbiAgQElucHV0KCkgcHVibGljIGNvbXBvbmVudCE6IFR5cGU8YW55PjtcbiAgQFZpZXdDaGlsZCgnb3ZlcmxheScpIHByaXZhdGUgb3ZlcmxheVJlZiE6IEVsZW1lbnRSZWY7XG4gIEBWaWV3Q2hpbGQoJ2RpYWxvZ1dyYXBwZXInKSBwcml2YXRlIGRpYWxvZ1dyYXBwZXJSZWYhOiBFbGVtZW50UmVmO1xuICBwdWJsaWMgY29tcG9uZW50UmVmITogQ29tcG9uZW50UmVmPGFueT47XG4gIHB1YmxpYyBvdmVybGF5Q29sb3I6IHN0cmluZyA9ICdyZ2JhKDAsIDAsIDAsIDAuNSknO1xuICBwdWJsaWMgYW5pbWF0aW9uUGxheWVyITogQW5pbWF0aW9uUGxheWVyO1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgZGlhbG9nU2VydmljZTogVm1EaWFsb2dTZXJ2aWNlLFxuICAgICAgICAgICAgICBwcml2YXRlIGFuaW1CdWlsZGVyOiBBbmltYXRpb25CdWlsZGVyLFxuICAgICAgICAgICAgICBwcml2YXRlIGNoYW5nZURldGVjdG9yUmVmOiBDaGFuZ2VEZXRlY3RvclJlZikge1xuICB9XG5cbiAgcHVibGljIG5nQWZ0ZXJWaWV3SW5pdCgpOiB2b2lkIHtcbiAgICB0aGlzLmNvbXBvbmVudFJlZiA9IHRoaXMuZGlhbG9nQ29udGFpbmVyUmVmLmNyZWF0ZUNvbXBvbmVudCh0aGlzLmNvbXBvbmVudCk7XG4gICAgaWYgKHRoaXMub3B0aW9ucz8ub3ZlcmxheUNvbG9yKSB7XG4gICAgICB0aGlzLm92ZXJsYXlDb2xvciA9IHRoaXMub3B0aW9ucy5vdmVybGF5Q29sb3I7XG4gICAgfVxuICAgIGlmICh0aGlzLm9wdGlvbnM/LmFuaW1hdGlvbikge1xuICAgICAgdGhpcy5jcmVhdGVBbmltYXRpb25QbGF5ZXIoXG4gICAgICAgIHRoaXMub3B0aW9ucy5hbmltYXRpb24uaW5pdFN0eWxlU3RhdGUoKSxcbiAgICAgICAgdGhpcy5vcHRpb25zLmFuaW1hdGlvbi5vcGVuZWRTdHlsZVN0YXRlKCksXG4gICAgICAgIHRoaXMub3B0aW9ucy5hbmltYXRpb24ub3BlbmluZ0R1cmF0aW9uXG4gICAgICApO1xuICAgICAgdGhpcy5hbmltYXRpb25QbGF5ZXIucGxheSgpO1xuICAgIH1cbiAgICB0aGlzLmNoYW5nZURldGVjdG9yUmVmLmRldGVjdENoYW5nZXMoKTtcbiAgfVxuXG4gIHB1YmxpYyBvbk92ZXJsYXlDbGljaygpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5vcHRpb25zPy5vdmVybGF5Q2xpY2spIHtcbiAgICAgIHRoaXMuZGlhbG9nU2VydmljZS5jbG9zZTxudWxsPihudWxsKTtcbiAgICB9XG4gIH1cblxuICBwdWJsaWMgY3JlYXRlQW5pbWF0aW9uUGxheWVyKFxuICAgIGN1cnJlbnRTdGF0ZTogQW5pbWF0aW9uU3R5bGVNZXRhZGF0YSxcbiAgICBuZXdTdGF0ZTogQW5pbWF0aW9uU3R5bGVNZXRhZGF0YSxcbiAgICBkdXJhdGlvbjogbnVtYmVyKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuYW5pbWF0aW9uUGxheWVyKSB7XG4gICAgICB0aGlzLmFuaW1hdGlvblBsYXllci5kZXN0cm95KCk7XG4gICAgfVxuICAgIGNvbnN0IGFuaW1hdGlvbkZhY3RvcnkgPSB0aGlzLmFuaW1CdWlsZGVyLmJ1aWxkKFtjdXJyZW50U3RhdGUsIGFuaW1hdGUoZHVyYXRpb24sIG5ld1N0YXRlKV0pO1xuICAgIHRoaXMuYW5pbWF0aW9uUGxheWVyID0gYW5pbWF0aW9uRmFjdG9yeS5jcmVhdGUodGhpcy5kaWFsb2dXcmFwcGVyUmVmLm5hdGl2ZUVsZW1lbnQpO1xuICB9XG5cbiAgcHVibGljIG9uRGlhbG9nQ2xpY2soZXZlbnQ6IE1vdXNlRXZlbnQpOiB2b2lkIHtcbiAgICBldmVudC5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICB9XG59XG4iLCI8ZGl2ICNvdmVybGF5XG4gICAgIGNsYXNzPVwib3ZlcmxheVwiXG4gICAgIFtzdHlsZS5iYWNrZ3JvdW5kLWNvbG9yXT1cIm92ZXJsYXlDb2xvclwiXG4gICAgIChjbGljayk9XCJvbk92ZXJsYXlDbGljaygpXCI+XG4gIDxkaXYgI2RpYWxvZ1dyYXBwZXIgY2xhc3M9XCJkaWFsb2ctd3JhcHBlclwiIChjbGljayk9XCJvbkRpYWxvZ0NsaWNrKCRldmVudClcIj5cbiAgICA8bmctY29udGFpbmVyICNkaWFsb2dDb250YWluZXI+PC9uZy1jb250YWluZXI+XG4gIDwvZGl2PlxuPC9kaXY+XG4iXX0=