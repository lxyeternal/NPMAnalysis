import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { VmDialogService } from './services/vm-dialog.service';
import { VmOverlayComponent } from './components/vm-overlay/vm-overlay.component';
import * as i0 from "@angular/core";
export class VmDialogModule {
}
VmDialogModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmDialogModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
VmDialogModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.2", ngImport: i0, type: VmDialogModule, declarations: [VmOverlayComponent], imports: [BrowserAnimationsModule] });
VmDialogModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmDialogModule, providers: [VmDialogService], imports: [BrowserAnimationsModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmDialogModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [VmOverlayComponent],
                    imports: [BrowserAnimationsModule],
                    providers: [VmDialogService]
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidm0tZGlhbG9nLm1vZHVsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL3ZtLWFuZ3VsYXItdG9vbHMvc3JjL3ZtLWRpYWxvZy92bS1kaWFsb2cubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBQyxRQUFRLEVBQUMsTUFBTSxlQUFlLENBQUM7QUFDdkMsT0FBTyxFQUFDLHVCQUF1QixFQUFDLE1BQU0sc0NBQXNDLENBQUM7QUFDN0UsT0FBTyxFQUFDLGVBQWUsRUFBQyxNQUFNLDhCQUE4QixDQUFDO0FBQzdELE9BQU8sRUFBQyxrQkFBa0IsRUFBQyxNQUFNLDhDQUE4QyxDQUFDOztBQU9oRixNQUFNLE9BQU8sY0FBYzs7MkdBQWQsY0FBYzs0R0FBZCxjQUFjLGlCQUpWLGtCQUFrQixhQUN2Qix1QkFBdUI7NEdBR3RCLGNBQWMsYUFGZCxDQUFDLGVBQWUsQ0FBQyxZQURsQix1QkFBdUI7MkZBR3RCLGNBQWM7a0JBTDFCLFFBQVE7bUJBQUM7b0JBQ1IsWUFBWSxFQUFFLENBQUMsa0JBQWtCLENBQUM7b0JBQ2xDLE9BQU8sRUFBRSxDQUFDLHVCQUF1QixDQUFDO29CQUNsQyxTQUFTLEVBQUUsQ0FBQyxlQUFlLENBQUM7aUJBQzdCIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHtOZ01vZHVsZX0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQge0Jyb3dzZXJBbmltYXRpb25zTW9kdWxlfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyL2FuaW1hdGlvbnMnO1xuaW1wb3J0IHtWbURpYWxvZ1NlcnZpY2V9IGZyb20gJy4vc2VydmljZXMvdm0tZGlhbG9nLnNlcnZpY2UnO1xuaW1wb3J0IHtWbU92ZXJsYXlDb21wb25lbnR9IGZyb20gJy4vY29tcG9uZW50cy92bS1vdmVybGF5L3ZtLW92ZXJsYXkuY29tcG9uZW50JztcblxuQE5nTW9kdWxlKHtcbiAgZGVjbGFyYXRpb25zOiBbVm1PdmVybGF5Q29tcG9uZW50XSxcbiAgaW1wb3J0czogW0Jyb3dzZXJBbmltYXRpb25zTW9kdWxlXSxcbiAgcHJvdmlkZXJzOiBbVm1EaWFsb2dTZXJ2aWNlXVxufSlcbmV4cG9ydCBjbGFzcyBWbURpYWxvZ01vZHVsZSB7XG59XG4iXX0=