import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VmInputComponent } from './components/vm-input/vm-input.component';
import { StyleSheets } from '../vm-styles/classes/style-sheets';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import * as i0 from "@angular/core";
export class VmFormModule {
    constructor() {
        StyleSheets.initFormModule();
    }
}
VmFormModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmFormModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
VmFormModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.2", ngImport: i0, type: VmFormModule, declarations: [VmInputComponent], imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule], exports: [FormsModule,
        ReactiveFormsModule,
        VmInputComponent] });
VmFormModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmFormModule, imports: [CommonModule,
        FormsModule,
        ReactiveFormsModule, FormsModule,
        ReactiveFormsModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmFormModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        VmInputComponent
                    ],
                    imports: [
                        CommonModule,
                        FormsModule,
                        ReactiveFormsModule
                    ],
                    exports: [
                        FormsModule,
                        ReactiveFormsModule,
                        VmInputComponent
                    ]
                }]
        }], ctorParameters: function () { return []; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidm0tZm9ybS5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9wcm9qZWN0cy92bS1hbmd1bGFyLXRvb2xzL3NyYy92bS1mb3JtL3ZtLWZvcm0ubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDekMsT0FBTyxFQUFFLFlBQVksRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQy9DLE9BQU8sRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLDBDQUEwQyxDQUFDO0FBQzVFLE9BQU8sRUFBQyxXQUFXLEVBQUMsTUFBTSxtQ0FBbUMsQ0FBQztBQUM5RCxPQUFPLEVBQUMsV0FBVyxFQUFFLG1CQUFtQixFQUFDLE1BQU0sZ0JBQWdCLENBQUM7O0FBbUJoRSxNQUFNLE9BQU8sWUFBWTtJQUN2QjtRQUNFLFdBQVcsQ0FBQyxjQUFjLEVBQUUsQ0FBQztJQUMvQixDQUFDOzt5R0FIVSxZQUFZOzBHQUFaLFlBQVksaUJBYnJCLGdCQUFnQixhQUdoQixZQUFZO1FBQ1osV0FBVztRQUNYLG1CQUFtQixhQUduQixXQUFXO1FBQ1gsbUJBQW1CO1FBQ25CLGdCQUFnQjswR0FHUCxZQUFZLFlBVnJCLFlBQVk7UUFDWixXQUFXO1FBQ1gsbUJBQW1CLEVBR25CLFdBQVc7UUFDWCxtQkFBbUI7MkZBSVYsWUFBWTtrQkFmeEIsUUFBUTttQkFBQztvQkFDUixZQUFZLEVBQUU7d0JBQ1osZ0JBQWdCO3FCQUNqQjtvQkFDRCxPQUFPLEVBQUU7d0JBQ1AsWUFBWTt3QkFDWixXQUFXO3dCQUNYLG1CQUFtQjtxQkFDcEI7b0JBQ0QsT0FBTyxFQUFFO3dCQUNQLFdBQVc7d0JBQ1gsbUJBQW1CO3dCQUNuQixnQkFBZ0I7cUJBQ2pCO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IENvbW1vbk1vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvbW1vbic7XG5pbXBvcnQgeyBWbUlucHV0Q29tcG9uZW50IH0gZnJvbSAnLi9jb21wb25lbnRzL3ZtLWlucHV0L3ZtLWlucHV0LmNvbXBvbmVudCc7XG5pbXBvcnQge1N0eWxlU2hlZXRzfSBmcm9tICcuLi92bS1zdHlsZXMvY2xhc3Nlcy9zdHlsZS1zaGVldHMnO1xuaW1wb3J0IHtGb3Jtc01vZHVsZSwgUmVhY3RpdmVGb3Jtc01vZHVsZX0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuXG5cblxuQE5nTW9kdWxlKHtcbiAgZGVjbGFyYXRpb25zOiBbXG4gICAgVm1JbnB1dENvbXBvbmVudFxuICBdLFxuICBpbXBvcnRzOiBbXG4gICAgQ29tbW9uTW9kdWxlLFxuICAgIEZvcm1zTW9kdWxlLFxuICAgIFJlYWN0aXZlRm9ybXNNb2R1bGVcbiAgXSxcbiAgZXhwb3J0czogW1xuICAgIEZvcm1zTW9kdWxlLFxuICAgIFJlYWN0aXZlRm9ybXNNb2R1bGUsXG4gICAgVm1JbnB1dENvbXBvbmVudFxuICBdXG59KVxuZXhwb3J0IGNsYXNzIFZtRm9ybU1vZHVsZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIFN0eWxlU2hlZXRzLmluaXRGb3JtTW9kdWxlKCk7XG4gIH1cbn1cbiJdfQ==