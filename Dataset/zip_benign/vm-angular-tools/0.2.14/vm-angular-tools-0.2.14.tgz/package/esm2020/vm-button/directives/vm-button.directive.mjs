import { Directive, HostBinding, HostListener } from '@angular/core';
import * as i0 from "@angular/core";
export class VmButtonDirective {
    constructor(elRef) {
        this.elRef = elRef;
        this.focus_visible = true;
        this.font_size = '14px';
        this.locker = true;
        const button = elRef.nativeElement;
        this.locker = !(button instanceof HTMLButtonElement);
        if (!this.locker) {
            this.styles = button.style;
            this.styles.boxSizing = 'border-box';
            this.styles.display = 'flex';
            this.styles.justifyContent = 'center';
            this.styles.alignItems = 'center';
            this.styles.padding = '0';
            this.styles.whiteSpace = 'nowrap';
            this.styles.textOverflow = 'ellipsis';
            this.styles.textDecoration = 'none';
            this.styles.userSelect = 'none';
            this.styles.outline = 'none';
            this.styles.border = 'none';
            this.styles.overflow = 'hidden';
            this.styles.cursor = 'pointer';
            const declaration = window.getComputedStyle(elRef.nativeElement);
            this.font_size = declaration.getPropertyValue('font-size');
        }
    }
    onMouseDown() {
        if (!this.locker) {
            this.onActive(true);
        }
    }
    onMouseUp() {
        if (!this.locker) {
            this.onActive(false);
        }
    }
    onActive(flag) {
        this.styles.fontSize = (flag) ? `calc(${this.font_size} - 1px)` : this.font_size;
    }
}
VmButtonDirective.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmButtonDirective, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Directive });
VmButtonDirective.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "15.2.2", type: VmButtonDirective, selector: "[vm-button]", host: { listeners: { "mousedown": "onMouseDown()", "mouseup": "onMouseUp()" }, properties: { "class.vm-button-focus": "this.focus_visible" } }, ngImport: i0 });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmButtonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[vm-button]'
                }]
        }], ctorParameters: function () { return [{ type: i0.ElementRef }]; }, propDecorators: { focus_visible: [{
                type: HostBinding,
                args: ['class.vm-button-focus']
            }], onMouseDown: [{
                type: HostListener,
                args: ['mousedown']
            }], onMouseUp: [{
                type: HostListener,
                args: ['mouseup']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidm0tYnV0dG9uLmRpcmVjdGl2ZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Byb2plY3RzL3ZtLWFuZ3VsYXItdG9vbHMvc3JjL3ZtLWJ1dHRvbi9kaXJlY3RpdmVzL3ZtLWJ1dHRvbi5kaXJlY3RpdmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFDLFNBQVMsRUFBYyxXQUFXLEVBQUUsWUFBWSxFQUFDLE1BQU0sZUFBZSxDQUFDOztBQUsvRSxNQUFNLE9BQU8saUJBQWlCO0lBTzVCLFlBQW9CLEtBQWlCO1FBQWpCLFVBQUssR0FBTCxLQUFLLENBQVk7UUFOUyxrQkFBYSxHQUFHLElBQUksQ0FBQztRQUVsRCxjQUFTLEdBQVcsTUFBTSxDQUFDO1FBQzNCLFdBQU0sR0FBWSxJQUFJLENBQUM7UUFJdEMsTUFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLGFBQWEsQ0FBQTtRQUNsQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxNQUFNLFlBQVksaUJBQWlCLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQyxLQUFLLENBQUM7WUFDM0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEdBQUcsWUFBWSxDQUFDO1lBQ3JDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLE1BQU0sQ0FBQztZQUM3QixJQUFJLENBQUMsTUFBTSxDQUFDLGNBQWMsR0FBRyxRQUFRLENBQUM7WUFDdEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDO1lBQ2xDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLEdBQUcsQ0FBQztZQUMxQixJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUM7WUFDbEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEdBQUcsVUFBVSxDQUFDO1lBQ3RDLElBQUksQ0FBQyxNQUFNLENBQUMsY0FBYyxHQUFHLE1BQU0sQ0FBQztZQUNwQyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUM7WUFDaEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEdBQUcsTUFBTSxDQUFDO1lBQzdCLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztZQUM1QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7WUFDaEMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFDO1lBQy9CLE1BQU0sV0FBVyxHQUF3QixNQUFNLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDLGFBQWEsQ0FBQyxDQUFDO1lBQ3RGLElBQUksQ0FBQyxTQUFTLEdBQUcsV0FBVyxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQzVEO0lBQ0gsQ0FBQztJQUdPLFdBQVc7UUFDakIsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQztTQUNyQjtJQUNILENBQUM7SUFHTyxTQUFTO1FBQ2YsSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUU7WUFDaEIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQztTQUN0QjtJQUNILENBQUM7SUFFTyxRQUFRLENBQUMsSUFBYTtRQUM1QixJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLElBQUksQ0FBQyxTQUFTLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztJQUNuRixDQUFDOzs4R0E5Q1UsaUJBQWlCO2tHQUFqQixpQkFBaUI7MkZBQWpCLGlCQUFpQjtrQkFIN0IsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsYUFBYTtpQkFDeEI7aUdBRStDLGFBQWE7c0JBQTFELFdBQVc7dUJBQUMsdUJBQXVCO2dCQThCNUIsV0FBVztzQkFEbEIsWUFBWTt1QkFBQyxXQUFXO2dCQVFqQixTQUFTO3NCQURoQixZQUFZO3VCQUFDLFNBQVMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0RpcmVjdGl2ZSwgRWxlbWVudFJlZiwgSG9zdEJpbmRpbmcsIEhvc3RMaXN0ZW5lcn0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ1t2bS1idXR0b25dJ1xufSlcbmV4cG9ydCBjbGFzcyBWbUJ1dHRvbkRpcmVjdGl2ZSB7XG4gIEBIb3N0QmluZGluZygnY2xhc3Mudm0tYnV0dG9uLWZvY3VzJykgcHJpdmF0ZSBmb2N1c192aXNpYmxlID0gdHJ1ZTtcbiAgcHJpdmF0ZSBzdHlsZXMhOiBhbnk7XG4gIHByaXZhdGUgcmVhZG9ubHkgZm9udF9zaXplOiBzdHJpbmcgPSAnMTRweCc7XG4gIHByaXZhdGUgcmVhZG9ubHkgbG9ja2VyOiBib29sZWFuID0gdHJ1ZTtcblxuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgZWxSZWY6IEVsZW1lbnRSZWYpIHtcbiAgICBjb25zdCBidXR0b24gPSBlbFJlZi5uYXRpdmVFbGVtZW50XG4gICAgdGhpcy5sb2NrZXIgPSAhKGJ1dHRvbiBpbnN0YW5jZW9mIEhUTUxCdXR0b25FbGVtZW50KTtcbiAgICBpZiAoIXRoaXMubG9ja2VyKSB7XG4gICAgICB0aGlzLnN0eWxlcyA9IGJ1dHRvbi5zdHlsZTtcbiAgICAgIHRoaXMuc3R5bGVzLmJveFNpemluZyA9ICdib3JkZXItYm94JztcbiAgICAgIHRoaXMuc3R5bGVzLmRpc3BsYXkgPSAnZmxleCc7XG4gICAgICB0aGlzLnN0eWxlcy5qdXN0aWZ5Q29udGVudCA9ICdjZW50ZXInO1xuICAgICAgdGhpcy5zdHlsZXMuYWxpZ25JdGVtcyA9ICdjZW50ZXInO1xuICAgICAgdGhpcy5zdHlsZXMucGFkZGluZyA9ICcwJztcbiAgICAgIHRoaXMuc3R5bGVzLndoaXRlU3BhY2UgPSAnbm93cmFwJztcbiAgICAgIHRoaXMuc3R5bGVzLnRleHRPdmVyZmxvdyA9ICdlbGxpcHNpcyc7XG4gICAgICB0aGlzLnN0eWxlcy50ZXh0RGVjb3JhdGlvbiA9ICdub25lJztcbiAgICAgIHRoaXMuc3R5bGVzLnVzZXJTZWxlY3QgPSAnbm9uZSc7XG4gICAgICB0aGlzLnN0eWxlcy5vdXRsaW5lID0gJ25vbmUnO1xuICAgICAgdGhpcy5zdHlsZXMuYm9yZGVyID0gJ25vbmUnO1xuICAgICAgdGhpcy5zdHlsZXMub3ZlcmZsb3cgPSAnaGlkZGVuJztcbiAgICAgIHRoaXMuc3R5bGVzLmN1cnNvciA9ICdwb2ludGVyJztcbiAgICAgIGNvbnN0IGRlY2xhcmF0aW9uOiBDU1NTdHlsZURlY2xhcmF0aW9uID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUoZWxSZWYubmF0aXZlRWxlbWVudCk7XG4gICAgICB0aGlzLmZvbnRfc2l6ZSA9IGRlY2xhcmF0aW9uLmdldFByb3BlcnR5VmFsdWUoJ2ZvbnQtc2l6ZScpO1xuICAgIH1cbiAgfVxuXG4gIEBIb3N0TGlzdGVuZXIoJ21vdXNlZG93bicpXG4gIHByaXZhdGUgb25Nb3VzZURvd24oKTogdm9pZCB7XG4gICAgaWYgKCF0aGlzLmxvY2tlcikge1xuICAgICAgdGhpcy5vbkFjdGl2ZSh0cnVlKTtcbiAgICB9XG4gIH1cblxuICBASG9zdExpc3RlbmVyKCdtb3VzZXVwJylcbiAgcHJpdmF0ZSBvbk1vdXNlVXAoKTogdm9pZCB7XG4gICAgaWYgKCF0aGlzLmxvY2tlcikge1xuICAgICAgdGhpcy5vbkFjdGl2ZShmYWxzZSk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBvbkFjdGl2ZShmbGFnOiBib29sZWFuKTogdm9pZCB7XG4gICAgdGhpcy5zdHlsZXMuZm9udFNpemUgPSAoZmxhZykgPyBgY2FsYygke3RoaXMuZm9udF9zaXplfSAtIDFweClgIDogdGhpcy5mb250X3NpemU7XG4gIH1cbn1cbiJdfQ==