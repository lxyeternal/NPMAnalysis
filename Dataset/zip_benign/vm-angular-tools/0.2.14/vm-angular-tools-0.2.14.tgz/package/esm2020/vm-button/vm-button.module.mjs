import { NgModule } from '@angular/core';
import { VmBurgerComponent } from './components/vm-burger/vm-burger.component';
import { VmButtonDirective } from './directives/vm-button.directive';
import { StyleSheets } from '../vm-styles/classes/style-sheets';
import * as i0 from "@angular/core";
export class VmButtonModule {
    constructor() {
        StyleSheets.initButtonModule();
    }
}
VmButtonModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmButtonModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
VmButtonModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "15.2.2", ngImport: i0, type: VmButtonModule, declarations: [VmBurgerComponent,
        VmButtonDirective], exports: [VmBurgerComponent,
        VmButtonDirective] });
VmButtonModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmButtonModule });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "15.2.2", ngImport: i0, type: VmButtonModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [
                        VmBurgerComponent,
                        VmButtonDirective
                    ],
                    exports: [
                        VmBurgerComponent,
                        VmButtonDirective
                    ]
                }]
        }], ctorParameters: function () { return []; } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidm0tYnV0dG9uLm1vZHVsZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Byb2plY3RzL3ZtLWFuZ3VsYXItdG9vbHMvc3JjL3ZtLWJ1dHRvbi92bS1idXR0b24ubW9kdWxlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxRQUFRLEVBQUUsTUFBTSxlQUFlLENBQUM7QUFDekMsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sNENBQTRDLENBQUM7QUFDL0UsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sa0NBQWtDLENBQUM7QUFDckUsT0FBTyxFQUFFLFdBQVcsRUFBQyxNQUFNLG1DQUFtQyxDQUFDOztBQWEvRCxNQUFNLE9BQU8sY0FBYztJQUN6QjtRQUNFLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQ2pDLENBQUM7OzJHQUhVLGNBQWM7NEdBQWQsY0FBYyxpQkFSdkIsaUJBQWlCO1FBQ2pCLGlCQUFpQixhQUdqQixpQkFBaUI7UUFDakIsaUJBQWlCOzRHQUdSLGNBQWM7MkZBQWQsY0FBYztrQkFWMUIsUUFBUTttQkFBQztvQkFDUixZQUFZLEVBQUU7d0JBQ1osaUJBQWlCO3dCQUNqQixpQkFBaUI7cUJBQ2xCO29CQUNELE9BQU8sRUFBRTt3QkFDUCxpQkFBaUI7d0JBQ2pCLGlCQUFpQjtxQkFDbEI7aUJBQ0YiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgVm1CdXJnZXJDb21wb25lbnQgfSBmcm9tICcuL2NvbXBvbmVudHMvdm0tYnVyZ2VyL3ZtLWJ1cmdlci5jb21wb25lbnQnO1xuaW1wb3J0IHsgVm1CdXR0b25EaXJlY3RpdmUgfSBmcm9tICcuL2RpcmVjdGl2ZXMvdm0tYnV0dG9uLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBTdHlsZVNoZWV0c30gZnJvbSAnLi4vdm0tc3R5bGVzL2NsYXNzZXMvc3R5bGUtc2hlZXRzJztcblxuXG5ATmdNb2R1bGUoe1xuICBkZWNsYXJhdGlvbnM6IFtcbiAgICBWbUJ1cmdlckNvbXBvbmVudCxcbiAgICBWbUJ1dHRvbkRpcmVjdGl2ZVxuICBdLFxuICBleHBvcnRzOiBbXG4gICAgVm1CdXJnZXJDb21wb25lbnQsXG4gICAgVm1CdXR0b25EaXJlY3RpdmVcbiAgXVxufSlcbmV4cG9ydCBjbGFzcyBWbUJ1dHRvbk1vZHVsZSB7XG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIFN0eWxlU2hlZXRzLmluaXRCdXR0b25Nb2R1bGUoKTtcbiAgfVxufVxuIl19