export class StyleSheets {
    static initButtonModule() {
        document.styleSheets[0].insertRule('.vm-button-focus:focus-visible { box-shadow: 0 0 3px 1px rgba(0, 0, 0, 0.4); filter: brightness(1.3); }');
    }
    static initFormModule() {
        document.styleSheets[0].insertRule('.vm-input-focus { box-shadow: 0 0 3px 1px rgba(0, 0, 0, 0.4); filter: brightness(1.3); }');
    }
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3R5bGUtc2hlZXRzLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vcHJvamVjdHMvdm0tYW5ndWxhci10b29scy9zcmMvdm0tc3R5bGVzL2NsYXNzZXMvc3R5bGUtc2hlZXRzLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE1BQU0sT0FBTyxXQUFXO0lBQ2YsTUFBTSxDQUFDLGdCQUFnQjtRQUM1QixRQUFRLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FDaEMseUdBQXlHLENBQzFHLENBQUM7SUFDSixDQUFDO0lBQ00sTUFBTSxDQUFDLGNBQWM7UUFDMUIsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQ2hDLDBGQUEwRixDQUMzRixDQUFDO0lBQ0osQ0FBQztDQUNGIiwic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGNsYXNzIFN0eWxlU2hlZXRzIHtcbiAgcHVibGljIHN0YXRpYyBpbml0QnV0dG9uTW9kdWxlKCk6IHZvaWQge1xuICAgIGRvY3VtZW50LnN0eWxlU2hlZXRzWzBdLmluc2VydFJ1bGUoXG4gICAgICAnLnZtLWJ1dHRvbi1mb2N1czpmb2N1cy12aXNpYmxlIHsgYm94LXNoYWRvdzogMCAwIDNweCAxcHggcmdiYSgwLCAwLCAwLCAwLjQpOyBmaWx0ZXI6IGJyaWdodG5lc3MoMS4zKTsgfSdcbiAgICApO1xuICB9XG4gIHB1YmxpYyBzdGF0aWMgaW5pdEZvcm1Nb2R1bGUoKTogdm9pZCB7XG4gICAgZG9jdW1lbnQuc3R5bGVTaGVldHNbMF0uaW5zZXJ0UnVsZShcbiAgICAgICcudm0taW5wdXQtZm9jdXMgeyBib3gtc2hhZG93OiAwIDAgM3B4IDFweCByZ2JhKDAsIDAsIDAsIDAuNCk7IGZpbHRlcjogYnJpZ2h0bmVzcygxLjMpOyB9J1xuICAgICk7XG4gIH1cbn1cbiJdfQ==