/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="vm-angular-tools" />
export * from './public-api';
