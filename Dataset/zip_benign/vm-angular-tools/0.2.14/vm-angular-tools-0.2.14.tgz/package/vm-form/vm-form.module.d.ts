import * as i0 from "@angular/core";
import * as i1 from "./components/vm-input/vm-input.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/forms";
export declare class VmFormModule {
    constructor();
    static ɵfac: i0.ɵɵFactoryDeclaration<VmFormModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<VmFormModule, [typeof i1.VmInputComponent], [typeof i2.CommonModule, typeof i3.FormsModule, typeof i3.ReactiveFormsModule], [typeof i3.FormsModule, typeof i3.ReactiveFormsModule, typeof i1.VmInputComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<VmFormModule>;
}
