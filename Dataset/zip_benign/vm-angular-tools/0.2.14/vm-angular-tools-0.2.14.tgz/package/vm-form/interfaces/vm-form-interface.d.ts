export interface IVmInputStyles {
    front_padding: string;
    input_padding: string;
    content_padding_right: string;
    back_border: string;
    back_border_width: string;
    back_border_color: string;
    back_border_radius: string;
    front_border_radius: string;
    front_border: string;
    front_background: string;
    front_background_buffer: string;
    width: string;
    color: string;
    font: string;
    cursor: string;
}
