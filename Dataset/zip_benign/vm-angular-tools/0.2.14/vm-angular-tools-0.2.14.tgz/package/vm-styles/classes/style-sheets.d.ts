export declare class StyleSheets {
    static initButtonModule(): void;
    static initFormModule(): void;
}
