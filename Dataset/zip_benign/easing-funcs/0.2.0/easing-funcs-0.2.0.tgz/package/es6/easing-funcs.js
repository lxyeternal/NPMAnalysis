export var linear = function linear(t) {
  return t;
};

export var easeIn = function easeIn(power) {
  return function (t) {
    return t ** power;
  };
};

export var easeOut = function easeOut(power) {
  return function (t) {
    return 1 - Math.abs((t - 1) ** power);
  };
};

export var easeInOut = function easeInOut(power) {
  return function (t) {
    return t < 0.5 ? easeIn(power)(t * 2) * 0.5 : easeOut(power)(t * 2 - 1) * 0.5 + 0.5;
  };
};

export var easeInSine = function easeInSine(t) {
  return -1 * Math.cos(t * Math.PI * 0.5) + 1;
};

export var easeOutSine = function easeOutSine(t) {
  return Math.sin(t * Math.PI * 0.5);
};

export var easeInOutSine = function easeInOutSine(t) {
  return -0.5 * (Math.cos(t * Math.PI) - 1);
};

export var easeInQuad = easeIn(2);

export var easeOutQuad = easeOut(2);

export var easeInOutQuad = easeInOut(2);

export var easeInCubic = easeIn(3);

export var easeOutCubic = easeOut(3);

export var easeInOutCubic = easeInOut(3);

export var easeInQuart = easeIn(4);

export var easeOutQuart = easeOut(4);

export var easeInOutQuart = easeInOut(4);

export var easeInQuint = easeIn(5);

export var easeOutQuint = easeOut(5);

export var easeInOutQuint = easeInOut(5);