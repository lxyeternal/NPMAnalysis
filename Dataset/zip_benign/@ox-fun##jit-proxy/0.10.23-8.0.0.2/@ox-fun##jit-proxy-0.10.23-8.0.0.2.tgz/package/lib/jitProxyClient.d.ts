/// <reference types="bn.js" />
import { BN, DriftClient, MakerInfo, MarketType, PostOnlyParams, ReferrerInfo, TxParams, UserAccount } from '@ox-fun/drift-sdk';
import { PublicKey, TransactionInstruction } from '@solana/web3.js';
import { TxSigAndSlot } from '@ox-fun/drift-sdk/lib/tx/types';
export type JitIxParams = {
    takerKey: PublicKey;
    takerStatsKey: PublicKey;
    taker: UserAccount;
    takerOrderId: number;
    maxPosition: BN;
    minPosition: BN;
    bid: BN;
    ask: BN;
    postOnly: PostOnlyParams | null;
    priceType?: PriceType;
    referrerInfo?: ReferrerInfo;
    subAccountId?: number;
};
export declare class PriceType {
    static readonly LIMIT: {
        limit: {};
    };
    static readonly ORACLE: {
        oracle: {};
    };
}
export type OrderConstraint = {
    maxPosition: BN;
    minPosition: BN;
    marketIndex: number;
    marketType: MarketType;
};
export declare class JitProxyClient {
    private driftClient;
    private program;
    constructor({ driftClient, programId, }: {
        driftClient: DriftClient;
        programId: PublicKey;
    });
    jit(params: JitIxParams, txParams?: TxParams): Promise<TxSigAndSlot>;
    getJitIx({ takerKey, takerStatsKey, taker, takerOrderId, maxPosition, minPosition, bid, ask, postOnly, priceType, referrerInfo, subAccountId, }: JitIxParams): Promise<TransactionInstruction>;
    getCheckOrderConstraintIx({ subAccountId, orderConstraints, }: {
        subAccountId: number;
        orderConstraints: OrderConstraint[];
    }): Promise<TransactionInstruction>;
    arbPerp(params: {
        makerInfos: MakerInfo[];
        marketIndex: number;
    }, txParams?: TxParams): Promise<TxSigAndSlot>;
    getArbPerpIx({ makerInfos, marketIndex, referrerInfo, }: {
        makerInfos: MakerInfo[];
        marketIndex: number;
        referrerInfo?: ReferrerInfo;
    }): Promise<TransactionInstruction>;
}
