export declare class NgxSignaturePadService {
    constructor();
}
