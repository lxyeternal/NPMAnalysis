import { AfterViewInit, ElementRef, OnChanges, SimpleChanges } from '@angular/core';
import { IPointGroup, SignaturePadOptions } from './models/signaturePadOptions';
export declare class NgxSignaturePadComponent implements OnChanges, AfterViewInit {
    config: SignaturePadOptions;
    signaturePadElement: ElementRef;
    signaturePadContainerElement: ElementRef;
    private signaturePad;
    constructor();
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    private setCanvasSize;
    clear(): void;
    fromDataURL(dataUrl: string, options?: {
        ratio?: number;
        width?: number;
        height?: number;
    }, callback?: (error?: ErrorEvent) => void): void;
    toDataURL(type?: string, encoderOptions?: number): string;
    on(): void;
    off(): void;
    isEmpty(): boolean;
    fromData(pointGroups: IPointGroup[]): void;
    toData(): IPointGroup[];
    forceUpdate(): void;
}
