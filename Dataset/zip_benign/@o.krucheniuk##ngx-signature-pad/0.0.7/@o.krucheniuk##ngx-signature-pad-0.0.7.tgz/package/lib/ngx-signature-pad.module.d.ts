export declare class NgxSignaturePadModule {
}
