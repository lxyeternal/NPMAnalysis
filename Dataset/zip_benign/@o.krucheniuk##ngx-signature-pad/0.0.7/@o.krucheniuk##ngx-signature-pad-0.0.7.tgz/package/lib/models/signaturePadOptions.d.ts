import { Options } from 'signature_pad';
export interface SignaturePadOptions extends Options {
    test?: string;
}
export interface IPointGroup {
    color: string;
    points: IBasicPoint[];
}
export interface IBasicPoint {
    x: number;
    y: number;
    time: number;
}
