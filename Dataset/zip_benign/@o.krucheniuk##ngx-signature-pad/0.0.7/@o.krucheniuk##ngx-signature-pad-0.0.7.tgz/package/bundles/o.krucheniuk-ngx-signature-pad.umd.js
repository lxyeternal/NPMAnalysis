(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('signature_pad')) :
    typeof define === 'function' && define.amd ? define('@o.krucheniuk/ngx-signature-pad', ['exports', '@angular/core', 'signature_pad'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global.o = global.o || {}, global.o.krucheniuk = global.o.krucheniuk || {}, global.o.krucheniuk['ngx-signature-pad'] = {}), global.ng.core, global.signature_pad));
}(this, (function (exports, i0, SignaturePad) { 'use strict';

    function _interopDefaultLegacy (e) { return e && typeof e === 'object' && 'default' in e ? e : { 'default': e }; }

    var SignaturePad__default = /*#__PURE__*/_interopDefaultLegacy(SignaturePad);

    var NgxSignaturePadService = /** @class */ (function () {
        function NgxSignaturePadService() {
        }
        return NgxSignaturePadService;
    }());
    NgxSignaturePadService.ɵprov = i0.ɵɵdefineInjectable({ factory: function NgxSignaturePadService_Factory() { return new NgxSignaturePadService(); }, token: NgxSignaturePadService, providedIn: "root" });
    NgxSignaturePadService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    NgxSignaturePadService.ctorParameters = function () { return []; };

    var NgxSignaturePadComponent = /** @class */ (function () {
        function NgxSignaturePadComponent() {
        }
        NgxSignaturePadComponent.prototype.ngOnChanges = function (changes) {
            var _this = this;
            if (!changes.config.firstChange) {
                Object.keys(changes.config.currentValue).map(function (key) {
                    _this.signaturePad[key] = changes.config.currentValue[key];
                });
            }
        };
        NgxSignaturePadComponent.prototype.ngAfterViewInit = function () {
            this.setCanvasSize();
            this.signaturePad = new SignaturePad__default['default'](this.signaturePadElement.nativeElement, this.config);
        };
        NgxSignaturePadComponent.prototype.setCanvasSize = function () {
            var _a = this.signaturePadContainerElement.nativeElement, offsetWidth = _a.offsetWidth, offsetHeight = _a.offsetHeight;
            this.signaturePadElement.nativeElement.width = offsetWidth;
            this.signaturePadElement.nativeElement.height = offsetHeight;
        };
        NgxSignaturePadComponent.prototype.clear = function () {
            this.signaturePad.clear();
        };
        NgxSignaturePadComponent.prototype.fromDataURL = function (dataUrl, options, callback) {
            this.signaturePad.fromDataURL(dataUrl, options, callback);
        };
        NgxSignaturePadComponent.prototype.toDataURL = function (type, encoderOptions) {
            return this.signaturePad.toDataURL(type, encoderOptions);
        };
        NgxSignaturePadComponent.prototype.on = function () {
            this.signaturePad.on();
        };
        NgxSignaturePadComponent.prototype.off = function () {
            this.signaturePad.off();
        };
        NgxSignaturePadComponent.prototype.isEmpty = function () {
            return this.signaturePad ? this.signaturePad.isEmpty() : true;
        };
        NgxSignaturePadComponent.prototype.fromData = function (pointGroups) {
            this.signaturePad.fromData(pointGroups);
        };
        NgxSignaturePadComponent.prototype.toData = function () {
            return this.signaturePad.toData();
        };
        NgxSignaturePadComponent.prototype.forceUpdate = function () {
            this.setCanvasSize();
            this.signaturePad = new SignaturePad__default['default'](this.signaturePadElement.nativeElement, this.config);
        };
        return NgxSignaturePadComponent;
    }());
    NgxSignaturePadComponent.decorators = [
        { type: i0.Component, args: [{
                    selector: 'ngx-signature-pad',
                    template: "\n    <div #signaturePadContainer>\n      <canvas #signaturePad></canvas>\n    </div>\n  "
                },] }
    ];
    NgxSignaturePadComponent.ctorParameters = function () { return []; };
    NgxSignaturePadComponent.propDecorators = {
        config: [{ type: i0.Input }],
        signaturePadElement: [{ type: i0.ViewChild, args: ['signaturePad', { static: false },] }],
        signaturePadContainerElement: [{ type: i0.ViewChild, args: ['signaturePadContainer', { static: false },] }]
    };

    var NgxSignaturePadModule = /** @class */ (function () {
        function NgxSignaturePadModule() {
        }
        return NgxSignaturePadModule;
    }());
    NgxSignaturePadModule.decorators = [
        { type: i0.NgModule, args: [{
                    declarations: [NgxSignaturePadComponent],
                    imports: [],
                    exports: [NgxSignaturePadComponent]
                },] }
    ];

    /*
     * Public API Surface of ngx-signature-pad
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.NgxSignaturePadComponent = NgxSignaturePadComponent;
    exports.NgxSignaturePadModule = NgxSignaturePadModule;
    exports.NgxSignaturePadService = NgxSignaturePadService;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=o.krucheniuk-ngx-signature-pad.umd.js.map
