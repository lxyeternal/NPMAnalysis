import { ɵɵdefineInjectable, Injectable, Component, Input, ViewChild, NgModule } from '@angular/core';
import SignaturePad from 'signature_pad';

class NgxSignaturePadService {
    constructor() { }
}
NgxSignaturePadService.ɵprov = ɵɵdefineInjectable({ factory: function NgxSignaturePadService_Factory() { return new NgxSignaturePadService(); }, token: NgxSignaturePadService, providedIn: "root" });
NgxSignaturePadService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
NgxSignaturePadService.ctorParameters = () => [];

class NgxSignaturePadComponent {
    constructor() {
    }
    ngOnChanges(changes) {
        if (!changes.config.firstChange) {
            Object.keys(changes.config.currentValue).map(key => {
                this.signaturePad[key] = changes.config.currentValue[key];
            });
        }
    }
    ngAfterViewInit() {
        this.setCanvasSize();
        this.signaturePad = new SignaturePad(this.signaturePadElement.nativeElement, this.config);
    }
    setCanvasSize() {
        const { offsetWidth, offsetHeight } = this.signaturePadContainerElement.nativeElement;
        this.signaturePadElement.nativeElement.width = offsetWidth;
        this.signaturePadElement.nativeElement.height = offsetHeight;
    }
    clear() {
        this.signaturePad.clear();
    }
    fromDataURL(dataUrl, options, callback) {
        this.signaturePad.fromDataURL(dataUrl, options, callback);
    }
    toDataURL(type, encoderOptions) {
        return this.signaturePad.toDataURL(type, encoderOptions);
    }
    on() {
        this.signaturePad.on();
    }
    off() {
        this.signaturePad.off();
    }
    isEmpty() {
        return this.signaturePad ? this.signaturePad.isEmpty() : true;
    }
    fromData(pointGroups) {
        this.signaturePad.fromData(pointGroups);
    }
    toData() {
        return this.signaturePad.toData();
    }
    forceUpdate() {
        this.setCanvasSize();
        this.signaturePad = new SignaturePad(this.signaturePadElement.nativeElement, this.config);
    }
}
NgxSignaturePadComponent.decorators = [
    { type: Component, args: [{
                selector: 'ngx-signature-pad',
                template: `
    <div #signaturePadContainer>
      <canvas #signaturePad></canvas>
    </div>
  `
            },] }
];
NgxSignaturePadComponent.ctorParameters = () => [];
NgxSignaturePadComponent.propDecorators = {
    config: [{ type: Input }],
    signaturePadElement: [{ type: ViewChild, args: ['signaturePad', { static: false },] }],
    signaturePadContainerElement: [{ type: ViewChild, args: ['signaturePadContainer', { static: false },] }]
};

class NgxSignaturePadModule {
}
NgxSignaturePadModule.decorators = [
    { type: NgModule, args: [{
                declarations: [NgxSignaturePadComponent],
                imports: [],
                exports: [NgxSignaturePadComponent]
            },] }
];

/*
 * Public API Surface of ngx-signature-pad
 */

/**
 * Generated bundle index. Do not edit.
 */

export { NgxSignaturePadComponent, NgxSignaturePadModule, NgxSignaturePadService };
//# sourceMappingURL=o.krucheniuk-ngx-signature-pad.js.map
