module.exports = {
  ripple: {
    unbind(el, bind) {
      let handlers = bind._handlers;
      for (let handler in handlers) {
        el.removeEventListener(handler, handlers[handler]);
      }
    },
    bind(el, binding) {
      let _lastElement = null;
      binding["_handlers"] = {
        mousedown,
        mouseup,
        mouseout
      };
      el.style.setProperty("overflow", "hidden");
      requestAnimationFrame(() => {
        let pos = window.getComputedStyle(el).getPropertyValue("position");
        if (pos === "static") {
          el.style.setProperty("position", "relative");
        }
      });

      function addStylings(ripple, e, width, height, offsetLeft, offsetTop) {
        let halfWidth = width / 2;
        let halfHeight = height / 2;
        ripple.style.setProperty("top", e.y - halfHeight - offsetTop + "px");
        ripple.style.setProperty("left", e.x - halfWidth - offsetLeft + "px");
        ripple.style.setProperty("transform", "scale(3)");
      }
      function removeElement(e, element) {
        if (e.propertyName !== "opacity") return;
        element.parentElement.removeChild(element);
      }
      function mousedown(e) {
        let ripple = document.createElement("div");
        let rect = el.getBoundingClientRect();
        let maxLenght = rect.width > rect.height ? rect.width : rect.height;
        let selectedColor = "black";

        let selectedTime = 750;

        let color = window
          .getComputedStyle(el)
          .getPropertyValue("background-color");
        let ar = color.match(/[+-]?([0-9]+([.][0-9]*)?|[.][0-9]+)/g);
        let [red, green, blue, opacity] = ar;

        if (opacity < 0.5) {
          selectedColor = `rgba(${red}, ${green}, ${blue})`;
        }
        if ("value" in binding) {
          if ("color" in binding.value) {
            selectedColor = binding.value["color"];
          }

          if ("time" in binding.value) {
            selectedTime = binding.value["time"];
          }
        }
        ripple.style.cssText = `;pointer-events: none;width: ${maxLenght}px; position: absolute; transition: ${selectedTime}ms; height: ${maxLenght}px; background: ${selectedColor}; border-radius: 50%; opacity: 0.3;transform: scale(0.4) `;
        el.appendChild(ripple);
        _lastElement = ripple;
        window.requestAnimationFrame(() => {
          addStylings(ripple, e, maxLenght, maxLenght, rect.left, rect.top);
        });
      }
      function mouseup(e) {
        if (_lastElement === null) return;
        let element = _lastElement;
        _lastElement = null;
        element.style.setProperty("opacity", 0);
        element.addEventListener("transitionend", e =>
          removeElement.call(this, e, element)
        );
      }
      function mouseout(e) {
        if (_lastElement === null) return;
        let element = _lastElement;
        _lastElement = null;
        element.style.setProperty("opacity", 0);
        element.addEventListener("transitionend", e =>
          removeElement.call(this, e, element)
        );
      }
      el.addEventListener("mousedown", mousedown);
      el.addEventListener("mouseup", mouseup);
      el.addEventListener("mouseout", mouseout);
    }
  }
};
