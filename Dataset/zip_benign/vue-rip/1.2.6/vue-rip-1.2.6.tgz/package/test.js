let getAuthToken = () => {
  return new Promise((res, rej) => {
    let authToken;
    var options = {
      method: "GET",
      url: "https://<apiURL>/V1/auth_token",
      headers: {
        Authorization: "Basic <token>"
      }
    };
    request(options, (error, response) => {
      if (error) {
        rej(error);
      } else {
        authToken = JSON.parse(response.body);
        res(authToken);
      }
    });
  });
};
