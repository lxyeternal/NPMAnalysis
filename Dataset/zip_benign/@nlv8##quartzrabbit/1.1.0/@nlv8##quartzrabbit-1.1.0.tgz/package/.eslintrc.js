module.exports = {
	"parserOptions": {
		"ecmaVersion": 9,
		"sourceType": "module"
	},
	"env": {
		"es6": true,
		"node": true,
		"mongo": true,
		"mocha": true,
		"browser": true
	},
	"rules": {
		"arrow-parens": [2, "as-needed"],
		"arrow-body-style": [2, "as-needed"],
		"arrow-spacing": [2, {
			"before": true,
			"after": true
		}],
		"block-spacing": [2, "always"],
		"comma-dangle": [2, "never"],
		"comma-spacing": [2, {
			"before": false,
			"after": true
		}],
		"comma-style": [2, "last"],
		"dot-location": [2, "property"],
		"eol-last": 2,
		"eqeqeq": [2, "allow-null"],
		"generator-star-spacing": [2, {
			"before": true,
			"after": true
		}],
		"handle-callback-err": [2, "^(err|error)$"],
		"indent": [2, "tab"],
		"jsx-quotes": [2, "prefer-single"],
		"key-spacing": [2, {
			"beforeColon": false,
			"afterColon": true
		}],
		"keyword-spacing": [2, {
			"before": true,
			"after": true
		}],
		"new-cap": [2, {
			"newIsCap": true,
			"capIsNew": false
		}],
		"new-parens": 2,
		"no-caller": 2,
		"no-cond-assign": 2,
		"no-const-assign": 2,
		"no-debugger": 2,
		"no-delete-var": 2,
		"no-dupe-args": 2,
		"no-dupe-keys": 2,
		"no-duplicate-case": 2,
		"no-empty-character-class": 2,
		"no-empty-pattern": 2,
		"no-eval": 2,
		"no-ex-assign": 2,
		"no-extra-bind": 2,
		"no-extra-boolean-cast": 2,
		"no-extra-parens": [2, "functions"],
		"no-fallthrough": 2,
		"no-floating-decimal": 2,
		"no-func-assign": 2,
		"no-implied-eval": 2,
		"no-inner-declarations": [2, "functions"],
		"no-invalid-regexp": 2,
		"no-irregular-whitespace": 2,
		"no-label-var": 2,
		"no-labels": [2, {
			"allowLoop": true,
			"allowSwitch": false
		}],
		"no-lone-blocks": 2,
		"no-mixed-spaces-and-tabs": 2,
		"no-multi-spaces": 2,
		"no-multi-str": 2,
		"no-global-assign": 2,
		"no-unsafe-negation": 2,
		"no-new": 2,
		"no-new-object": 2,
		"no-new-require": 2,
		"no-new-symbol": 2,
		"no-new-wrappers": 2,
		"no-obj-calls": 2,
		"no-octal": 2,
		"no-octal-escape": 2,
		"no-path-concat": 2,
		"no-proto": 2,
		"no-redeclare": 2,
		"no-regex-spaces": 2,
		"no-return-assign": [2, "except-parens"],
		"no-self-assign": 2,
		"no-self-compare": 2,
		"no-shadow-restricted-names": 2,
		"func-call-spacing": [2, 'never'],
		"no-sparse-arrays": 2,
		"no-throw-literal": 2,
		"no-trailing-spaces": 2,
		"no-undef": 2,
		"no-undef-init": 2,
		"no-unneeded-ternary": [2, {
			"defaultAssignment": false
		}],
		"no-unreachable": 2,
		"no-unused-vars": [2, {
			"vars": "all",
			"args": "none"
		}],
		"no-useless-call": 2,
		"no-with": 2,
		"operator-linebreak": [2, "before"],
		"quotes": [2, "single", "avoid-escape"],
		"semi": [2, "never"],
		"semi-spacing": [2, {
			"before": false,
			"after": true
		}],
		"space-before-blocks": [2, "always"],
		"space-before-function-paren": [2, "always"],
		"space-infix-ops": 2,
		"space-unary-ops": [2, {
			"words": true,
			"nonwords": false
		}],
		"spaced-comment": [2, "always", {
			"markers": ["global", "globals", "eslint", "eslint-disable", "*package", "!", ","]
		}],
		"template-curly-spacing": [2, "never"],
		"use-isnan": 2,
		"valid-typeof": 2,
		"wrap-iife": [2, "inside"],
		"yield-star-spacing": [2, "both"],
		"yoda": [2, "never"]
	}
}
