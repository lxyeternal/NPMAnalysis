# Quartz Rabbit

<!-- ![QuartzRabbit Logo](./quartzrabbit.png) -->

## Options

### Version

Key: `version`

Values: `asd`

Default: `-1`

### Mode

Key: `mode`

Values: `numeric`, `alphanumeric`, `octet`

Default: `-1`

By default, the module check the value, what is the best mode for the provided data.

### Error correction level

Key: `ecclevel`

Values: `L`, `M`, `Q`, `H`

Default: `L`

### Mask

Key: `mask`

Values: `0`, `1`, `2`, `3`, `4`, `5`, `6`, `7`, `8`

Default: `-1`

By default, the module doesn't use mask.

### Background color

Key: `fillcolor`

Value type: HEXACOLOR

Default: `#FFFFFF`

### QR color

Key: `textcolor`

Value type: HEXACOLOR

Default: `#000000`

### Rounded

Key: `rounded`

Value type: boolean

Default: `false`

### Module size

Key: `modulesize`

Value type: Number

Default: `5`

The module size has a minimum of 0.5. If you provide a smaller number, then the module will use 0.5 for module size...

### Margin size

Key: `margin`

Value type: Number

Default: `4`

The module size has a minimum of 0.0. If you provide a smaller number, then the module will use 0.0 for margin size...

## Example

```javascript
let qr = require('./lib/qr')
let u = "Sample text goes here. Ahoy!!"
let s = qr.generateSVG(u, {
	ecclevel: qr.ECCLEVELS.M,
	fillcolor: {
		type: qr.COLOR_TYPES.SIMPLE,
		color: '#'
	},
	textcolor: "#D13438",
	margin: 4,
	modulesize: 4
})
```