export declare const init: (apiKey: string, options: import("./typings/session-replay").SessionReplayOptions) => import("@amplitude/analytics-types").AmplitudeReturn<void>, setSessionId: (sessionId: string | number, deviceId?: string | undefined) => import("@amplitude/analytics-types").AmplitudeReturn<void>, getSessionId: () => string | number | undefined, getSessionReplayProperties: () => {
    [key: string]: string | boolean | null;
}, flush: (useRetry: boolean) => Promise<void>, shutdown: () => void;
export { SessionReplayOptions, StoreType } from './typings/session-replay';
export { SafeLoggerProvider } from './logger';
//# sourceMappingURL=index.d.ts.map