import { Events, EventsStore, SendingSequencesReturn } from '../typings/session-replay';
import { Logger } from '@amplitude/analytics-types';
export type InstanceArgs = {
    loggerProvider: Logger;
    minInterval?: number;
    maxInterval?: number;
    maxPersistedEventsSize?: number;
};
export declare abstract class BaseEventsStore<KeyType> implements EventsStore<KeyType> {
    protected readonly loggerProvider: Logger;
    private minInterval;
    private maxInterval;
    private maxPersistedEventsSize;
    private interval;
    private _timeAtLastSplit;
    get timeAtLastSplit(): number;
    constructor(args: InstanceArgs);
    abstract addEventToCurrentSequence(sessionId: string | number, event: string): Promise<SendingSequencesReturn<KeyType> | undefined>;
    abstract getSequencesToSend(): Promise<SendingSequencesReturn<KeyType>[] | undefined>;
    abstract storeCurrentSequence(sessionId: number): Promise<SendingSequencesReturn<KeyType> | undefined>;
    abstract storeSendingEvents(sessionId: string | number, events: Events): Promise<KeyType | undefined>;
    abstract cleanUpSessionEventsStore(sessionId: number, sequenceId: KeyType): Promise<void>;
    /**
     * Determines whether to send the events list to the backend and start a new
     * empty events list, based on the size of the list as well as the last time sent
     * @param nextEventString
     * @returns boolean
     */
    shouldSplitEventsList: (events: Events, nextEventString: string) => boolean;
}
//# sourceMappingURL=base-events-store.d.ts.map