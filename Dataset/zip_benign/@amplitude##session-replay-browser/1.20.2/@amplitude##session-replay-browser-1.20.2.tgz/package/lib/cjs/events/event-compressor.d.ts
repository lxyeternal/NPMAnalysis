import type { eventWithTime } from '@amplitude/rrweb-types';
import { SessionReplayJoinedConfig } from 'src/config/types';
import { SessionReplayEventsManager } from 'src/typings/session-replay';
interface TaskQueue {
    event: eventWithTime;
    sessionId: string | number;
}
export declare class EventCompressor {
    taskQueue: TaskQueue[];
    isProcessing: boolean;
    eventsManager?: SessionReplayEventsManager<'replay' | 'interaction', string>;
    config: SessionReplayJoinedConfig;
    deviceId: string | undefined;
    canUseIdleCallback: boolean | undefined;
    timeout: number;
    worker?: Worker;
    constructor(eventsManager: SessionReplayEventsManager<'replay' | 'interaction', string>, config: SessionReplayJoinedConfig, deviceId: string | undefined, workerScriptInternal?: string);
    scheduleIdleProcessing(): void;
    enqueueEvent(event: eventWithTime, sessionId: string | number): void;
    processQueue(idleDeadline: IdleDeadline): void;
    compressEvent: (event: eventWithTime) => string;
    private addCompressedEventToManager;
    addCompressedEvent: (event: eventWithTime, sessionId: string | number) => void;
    terminate: () => void;
}
export {};
//# sourceMappingURL=event-compressor.d.ts.map