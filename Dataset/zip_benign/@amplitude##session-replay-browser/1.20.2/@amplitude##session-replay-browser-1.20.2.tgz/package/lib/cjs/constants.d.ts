import { ServerZone } from '@amplitude/analytics-types';
export declare const DEFAULT_EVENT_PROPERTY_PREFIX = "[Amplitude]";
export declare const DEFAULT_SESSION_REPLAY_PROPERTY: string;
export declare const DEFAULT_SESSION_START_EVENT = "session_start";
export declare const DEFAULT_SESSION_END_EVENT = "session_end";
export declare const DEFAULT_SAMPLE_RATE = 0;
export declare const DEFAULT_SERVER_ZONE = ServerZone.US;
export declare const SESSION_REPLAY_DEBUG_PROPERTY: string;
export declare const BLOCK_CLASS = "amp-block";
export declare const MASK_TEXT_CLASS = "amp-mask";
export declare const UNMASK_TEXT_CLASS = "amp-unmask";
export declare const SESSION_REPLAY_SERVER_URL = "https://api-sr.amplitude.com/sessions/v2/track";
export declare const SESSION_REPLAY_EU_URL = "https://api-sr.eu.amplitude.com/sessions/v2/track";
export declare const SESSION_REPLAY_STAGING_URL = "https://api-sr.stag2.amplitude.com/sessions/v2/track";
export declare const STORAGE_PREFIX: string;
export declare const MAX_EVENT_LIST_SIZE_IN_BYTES: number;
export declare const INTERACTION_MIN_INTERVAL = 30000;
export declare const INTERACTION_MAX_INTERVAL = 60000;
export declare const MIN_INTERVAL = 500;
export declare const MAX_INTERVAL: number;
export declare const MAX_IDB_STORAGE_LENGTH: number;
export declare const KB_SIZE = 1024;
export declare const MAX_URL_LENGTH = 1000;
export declare enum CustomRRwebEvent {
    GET_SR_PROPS = "get-sr-props",
    DEBUG_INFO = "debug-info",
    FETCH_REQUEST = "fetch-request"
}
//# sourceMappingURL=constants.d.ts.map