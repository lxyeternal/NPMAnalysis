export declare const compressionOnMessage: (this: Window, ev: MessageEvent<any>) => any;
//# sourceMappingURL=compression.d.ts.map