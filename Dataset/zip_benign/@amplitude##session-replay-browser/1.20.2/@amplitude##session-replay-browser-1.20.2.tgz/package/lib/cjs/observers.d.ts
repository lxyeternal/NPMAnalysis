export interface NetworkRequestEvent {
    timestamp: number;
    type: 'fetch';
    method: string;
    url: string;
    status?: number;
    duration?: number;
    requestHeaders?: Record<string, string>;
    responseHeaders?: Record<string, string>;
    error?: {
        name: string;
        message: string;
    };
}
export type NetworkEventCallback = (event: NetworkRequestEvent) => void;
export declare class NetworkObservers {
    private fetchObserver;
    private eventCallback?;
    start(eventCallback: NetworkEventCallback): void;
    stop(): void;
    protected notifyEvent(event: NetworkRequestEvent): void;
    private observeFetch;
}
//# sourceMappingURL=observers.d.ts.map