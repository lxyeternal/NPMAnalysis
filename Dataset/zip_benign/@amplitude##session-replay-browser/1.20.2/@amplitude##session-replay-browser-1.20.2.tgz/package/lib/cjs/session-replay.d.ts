import { Logger as ILogger } from '@amplitude/analytics-types';
import { record } from '@amplitude/rrweb';
import { LoggingConfig, SessionReplayJoinedConfig, SessionReplayJoinedConfigGenerator } from './config/types';
import { CustomRRwebEvent } from './constants';
import { AmplitudeSessionReplay, SessionReplayEventsManager as AmplitudeSessionReplayEventsManager, SessionIdentifiers as ISessionIdentifiers, SessionReplayOptions } from './typings/session-replay';
import { EventCompressor } from './events/event-compressor';
type PageLeaveFn = (e: PageTransitionEvent | Event) => void;
export declare class SessionReplay implements AmplitudeSessionReplay {
    name: string;
    config: SessionReplayJoinedConfig | undefined;
    joinedConfigGenerator: SessionReplayJoinedConfigGenerator | undefined;
    identifiers: ISessionIdentifiers | undefined;
    eventsManager?: AmplitudeSessionReplayEventsManager<'replay' | 'interaction', string>;
    loggerProvider: ILogger;
    recordCancelCallback: ReturnType<typeof record> | null;
    eventCount: number;
    eventCompressor: EventCompressor | undefined;
    pageLeaveFns: PageLeaveFn[];
    private scrollHook?;
    private networkObservers?;
    constructor();
    init(apiKey: string, options: SessionReplayOptions): import("@amplitude/analytics-types").AmplitudeReturn<void>;
    private teardownEventListeners;
    protected _init(apiKey: string, options: SessionReplayOptions): Promise<void>;
    setSessionId(sessionId: string | number, deviceId?: string): import("@amplitude/analytics-types").AmplitudeReturn<void>;
    asyncSetSessionId(sessionId: string | number, deviceId?: string): Promise<void>;
    getSessionReplayProperties(): {
        [key: string]: string | null;
    };
    blurListener: () => void;
    focusListener: () => void;
    /**
     * This is an instance member so that if init is called multiple times
     * it doesn't add another listener to the page leave event. This is to
     * prevent duplicate listener actions from firing.
     */
    private pageLeaveListener;
    sendEvents(sessionId?: string | number): void;
    initialize(shouldSendStoredEvents?: boolean): void;
    shouldOptOut(): boolean | undefined;
    getShouldRecord(): boolean;
    getBlockSelectors(): string | string[] | undefined;
    getMaskTextSelectors(): string | undefined;
    getRecordingPlugins(loggingConfig: LoggingConfig | undefined): import("@amplitude/rrweb-types").RecordPlugin<unknown>[] | undefined;
    recordEvents(): void;
    addCustomRRWebEvent: (eventName: CustomRRwebEvent, eventData?: {
        [key: string]: any;
    }, addStorageInfo?: boolean) => Promise<void>;
    stopRecordingEvents: () => void;
    getDeviceId(): string | undefined;
    getSessionId(): string | number | undefined;
    flush(useRetry?: boolean): Promise<void | undefined>;
    shutdown(): void;
}
export {};
//# sourceMappingURL=session-replay.d.ts.map