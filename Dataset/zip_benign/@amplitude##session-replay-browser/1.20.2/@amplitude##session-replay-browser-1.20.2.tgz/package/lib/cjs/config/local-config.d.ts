import { FetchTransport } from '@amplitude/analytics-client-common';
import { Config, Logger } from '@amplitude/analytics-core';
import { LogLevel } from '@amplitude/analytics-types';
import { SessionReplayOptions, StoreType } from '../typings/session-replay';
import { SessionReplayLocalConfig as ISessionReplayLocalConfig, InteractionConfig, PrivacyConfig, SessionReplayPerformanceConfig, SessionReplayVersion } from './types';
export declare const getDefaultConfig: () => {
    flushMaxRetries: number;
    logLevel: LogLevel;
    loggerProvider: Logger;
    transportProvider: FetchTransport;
};
export declare class SessionReplayLocalConfig extends Config implements ISessionReplayLocalConfig {
    apiKey: string;
    sampleRate: number;
    privacyConfig?: PrivacyConfig;
    interactionConfig?: InteractionConfig;
    debugMode?: boolean;
    configServerUrl?: string;
    trackServerUrl?: string;
    shouldInlineStylesheet?: boolean;
    version?: SessionReplayVersion;
    storeType: StoreType;
    performanceConfig?: SessionReplayPerformanceConfig;
    experimental?: {
        useWebWorker: boolean;
    };
    constructor(apiKey: string, options: SessionReplayOptions);
}
//# sourceMappingURL=local-config.d.ts.map