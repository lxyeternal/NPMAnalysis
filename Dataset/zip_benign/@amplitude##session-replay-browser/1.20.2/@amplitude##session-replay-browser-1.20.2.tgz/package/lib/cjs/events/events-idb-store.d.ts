import { DBSchema, IDBPDatabase } from 'idb';
import { EventType, Events, SendingSequencesReturn } from '../typings/session-replay';
import { BaseEventsStore, InstanceArgs as BaseInstanceArgs } from './base-events-store';
export declare const currentSequenceKey = "sessionCurrentSequence";
export declare const sequencesToSendKey = "sequencesToSend";
export declare const remoteConfigKey = "remoteConfig";
export interface SessionReplayDB extends DBSchema {
    sessionCurrentSequence: {
        key: number;
        value: Omit<SendingSequencesReturn<number>, 'sequenceId'>;
    };
    sequencesToSend: {
        key: number;
        value: Omit<SendingSequencesReturn<number>, 'sequenceId'>;
        indexes: {
            sessionId: string | number;
        };
    };
}
export declare const keyValDatabaseExists: () => Promise<IDBDatabase | void>;
export declare const defineObjectStores: (db: IDBPDatabase<SessionReplayDB>) => {
    sequencesStore: import("idb").IDBPObjectStore<SessionReplayDB, ArrayLike<"sessionCurrentSequence" | "sequencesToSend">, "sequencesToSend", "versionchange"> | undefined;
    currentSequenceStore: import("idb").IDBPObjectStore<SessionReplayDB, ArrayLike<"sessionCurrentSequence" | "sequencesToSend">, "sessionCurrentSequence", "versionchange"> | undefined;
};
export declare const createStore: (dbName: string) => Promise<IDBPDatabase<SessionReplayDB>>;
type InstanceArgs = {
    apiKey: string;
    db: IDBPDatabase<SessionReplayDB>;
} & BaseInstanceArgs;
export declare class SessionReplayEventsIDBStore extends BaseEventsStore<number> {
    private readonly apiKey;
    private readonly db;
    constructor(args: InstanceArgs);
    static new(type: EventType, args: Omit<InstanceArgs, 'db'>, sessionId?: string | number): Promise<SessionReplayEventsIDBStore | undefined>;
    getCurrentSequenceEvents(sessionId?: number): Promise<Omit<SendingSequencesReturn<number>, "sequenceId">[] | undefined>;
    getSequencesToSend: () => Promise<SendingSequencesReturn<number>[] | undefined>;
    storeCurrentSequence: (sessionId: number) => Promise<{
        sessionId: number;
        sequenceId: number;
        events: Events;
    } | undefined>;
    addEventToCurrentSequence: (sessionId: number, event: string) => Promise<{
        events: Events;
        sessionId: number;
        sequenceId: number;
    } | undefined>;
    storeSendingEvents: (sessionId: number, events: Events) => Promise<number | undefined>;
    cleanUpSessionEventsStore: (_sessionId: number, sequenceId?: number) => Promise<void>;
    transitionFromKeyValStore: (sessionId?: string | number) => Promise<void>;
}
export {};
//# sourceMappingURL=events-idb-store.d.ts.map