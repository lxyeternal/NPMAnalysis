export declare const VERSION = "1.20.2";
//# sourceMappingURL=version.d.ts.map