import { LogConfig } from '@amplitude/analytics-types';
import { SessionReplay } from './session-replay';
import { AmplitudeSessionReplay } from './typings/session-replay';
export declare const getLogConfig: (sessionReplay: SessionReplay) => () => LogConfig;
declare const _default: AmplitudeSessionReplay;
export default _default;
//# sourceMappingURL=session-replay-factory.d.ts.map