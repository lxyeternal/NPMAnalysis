import { mouseInteractionCallBack } from '@amplitude/rrweb-types';
import { SessionReplayEventsManager as AmplitudeSessionReplayEventsManager } from '../typings/session-replay';
import { PayloadBatcher } from 'src/track-destination';
import type { Logger } from '@amplitude/analytics-types';
export type ClickEvent = {
    timestamp: number;
    x: number;
    y: number;
    viewportWidth: number;
    viewportHeight: number;
    pageUrl: string;
    selector?: string;
    type: 'click';
};
export type ClickEventWithCount = ClickEvent & {
    count: number;
};
type Options = {
    sessionId: string | number;
    deviceIdFn: () => string | undefined;
    eventsManager: AmplitudeSessionReplayEventsManager<'interaction', string>;
};
export declare const clickNonBatcher: PayloadBatcher;
export declare const clickBatcher: PayloadBatcher;
export declare const clickHook: (logger: Logger, options: Options) => mouseInteractionCallBack;
export {};
//# sourceMappingURL=click.d.ts.map