export declare const UNEXPECTED_ERROR_MESSAGE = "Unexpected error occurred";
export declare const UNEXPECTED_NETWORK_ERROR_MESSAGE = "Network error occurred, event batch rejected";
export declare const MAX_RETRIES_EXCEEDED_MESSAGE = "Session replay event batch rejected due to exceeded retry count";
export declare const STORAGE_FAILURE = "Failed to store session replay events in IndexedDB";
export declare const MISSING_DEVICE_ID_MESSAGE = "Session replay event batch not sent due to missing device ID";
export declare const MISSING_API_KEY_MESSAGE = "Session replay event batch not sent due to missing api key";
//# sourceMappingURL=messages.d.ts.map