import { scrollCallback, scrollPosition } from '@amplitude/rrweb-types';
import { BeaconTransport } from '../beacon-transport';
import { SessionReplayJoinedConfig } from '../config/types';
import { SessionReplayDestinationSessionMetadata } from '../typings/session-replay';
export type ScrollEvent = {
    timestamp: number;
    maxScrollX: number;
    maxScrollY: number;
    maxScrollHeight: number;
    maxScrollWidth: number;
    viewportWidth: number;
    viewportHeight: number;
    pageUrl: string;
    type: 'scroll';
};
export type ScrollEventPayload = {
    version: number;
    events: ScrollEvent[];
};
/**
 * This is intended to watch and update max scroll activity when loaded for a particular page.
 * A new instance should be created if the page URL changes, since by default it does not reset
 * it's max scroll state. It is intended to send very few and very small events utilizing the
 * Beacon API.
 * @see {@link BeaconTransport} for more details on Beacon API usage.
 */
export declare class ScrollWatcher {
    private timestamp;
    private _maxScrollX;
    private _maxScrollY;
    private _maxScrollWidth;
    private _maxScrollHeight;
    private readonly transport;
    static default(context: Omit<SessionReplayDestinationSessionMetadata, 'deviceId'>, config: SessionReplayJoinedConfig): ScrollWatcher;
    constructor(transport: BeaconTransport<ScrollEventPayload>);
    get maxScrollX(): number;
    get maxScrollY(): number;
    get maxScrollWidth(): number;
    get maxScrollHeight(): number;
    update(e: scrollPosition): void;
    hook: scrollCallback;
    send: (deviceIdFn: () => string | undefined) => (_: PageTransitionEvent | Event) => void;
}
//# sourceMappingURL=scroll.d.ts.map