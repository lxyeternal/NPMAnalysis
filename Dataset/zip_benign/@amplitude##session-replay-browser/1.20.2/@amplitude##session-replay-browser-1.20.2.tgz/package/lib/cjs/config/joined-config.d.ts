import { RemoteConfigFetch } from '@amplitude/analytics-remote-config';
import { Logger } from '@amplitude/analytics-types';
import { SessionReplayOptions } from '../typings/session-replay';
import { SessionReplayLocalConfig as ISessionReplayLocalConfig, PrivacyConfig, SessionReplayJoinedConfig, SessionReplayRemoteConfig } from './types';
export declare const removeInvalidSelectorsFromPrivacyConfig: (privacyConfig: PrivacyConfig, loggerProvider: Logger) => PrivacyConfig;
export declare class SessionReplayJoinedConfigGenerator {
    private readonly localConfig;
    private readonly remoteConfigFetch;
    constructor(remoteConfigFetch: RemoteConfigFetch<SessionReplayRemoteConfig>, localConfig: ISessionReplayLocalConfig);
    generateJoinedConfig(sessionId?: string | number): Promise<SessionReplayJoinedConfig>;
}
export declare const createSessionReplayJoinedConfigGenerator: (apiKey: string, options: SessionReplayOptions) => Promise<SessionReplayJoinedConfigGenerator>;
//# sourceMappingURL=joined-config.d.ts.map