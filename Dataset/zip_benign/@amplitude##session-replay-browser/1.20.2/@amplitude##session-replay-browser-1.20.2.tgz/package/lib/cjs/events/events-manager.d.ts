import { SessionReplayEventsManager as AmplitudeSessionReplayEventsManager, EventType, StoreType } from '../typings/session-replay';
import { SessionReplayJoinedConfig } from '../config/types';
import { PayloadBatcher } from '../track-destination';
export declare const createEventsManager: <Type extends EventType>({ config, sessionId, minInterval, maxInterval, type, payloadBatcher, storeType, }: {
    config: SessionReplayJoinedConfig;
    type: Type;
    minInterval?: number | undefined;
    maxInterval?: number | undefined;
    sessionId?: string | number | undefined;
    payloadBatcher?: PayloadBatcher | undefined;
    storeType: StoreType;
}) => Promise<AmplitudeSessionReplayEventsManager<Type, string>>;
//# sourceMappingURL=events-manager.d.ts.map