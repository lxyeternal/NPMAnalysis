import { Logger as ILogger } from '@amplitude/analytics-types';
import { SessionReplayTrackDestination as AmplitudeSessionReplayTrackDestination, SessionReplayDestination, SessionReplayDestinationContext } from './typings/session-replay';
export type PayloadBatcher = ({ version, events }: {
    version: number;
    events: string[];
}) => {
    version: number;
    events: unknown[];
};
export declare class SessionReplayTrackDestination implements AmplitudeSessionReplayTrackDestination {
    loggerProvider: ILogger;
    storageKey: string;
    trackServerUrl?: string;
    retryTimeout: number;
    private scheduled;
    payloadBatcher: PayloadBatcher;
    queue: SessionReplayDestinationContext[];
    constructor({ trackServerUrl, loggerProvider, payloadBatcher, }: {
        trackServerUrl?: string;
        loggerProvider: ILogger;
        payloadBatcher?: PayloadBatcher;
    });
    sendEventsList(destinationData: SessionReplayDestination): void;
    addToQueue(...list: SessionReplayDestinationContext[]): void;
    schedule(timeout: number): void;
    flush(useRetry?: boolean): Promise<void>;
    send(context: SessionReplayDestinationContext, useRetry?: boolean): Promise<void>;
    handleReponse(status: number, context: SessionReplayDestinationContext): void;
    handleSuccessResponse(context: SessionReplayDestinationContext): void;
    handleOtherResponse(context: SessionReplayDestinationContext): void;
    completeRequest({ context, err, success, }: {
        context: SessionReplayDestinationContext;
        err?: string;
        success?: string;
    }): void;
}
//# sourceMappingURL=track-destination.d.ts.map