module.exports = {
  env: {
    browser: true,
    es6: true,
  },
  extends: 'airbnb-base',
  globals: {
    Atomics: 'readonly',
    SharedArrayBuffer: 'readonly',
  },
  parser: 'babel-eslint',
  parserOptions: {
    ecmaVersion: 2018,
    sourceType: 'module',
    allowImportExportEverywhere: true,
  },
  rules: {
    'no-restricted-syntax': 0,
    'no-unused-expressions': [2, { allowTernary: true, allowShortCircuit: true }],
    'no-console': 'off',
    'object-curly-newline': 'off',
    'no-param-reassign': 'off',
    'global-require': 'off',
    'consistent-return': 'off',
    'max-len': 'off',
  },
};
