const postcss = require('postcss');
const themeConfig = require('./lib/themeConfig.js');

let defaults = {
  function: 'themeSwitch',
  themeConfig
};

/**
 * 十六进制转RGB值
 * @param hex
 * @returns {string|*}
 */
const hexToRgb = (hex) => {
  // 无对应规范色返回空
  if (!hex) return ''
  // 去除可能存在的 # 号
  hex = hex.replace('#', '');
  // 如果是三位十六进制颜色值，扩展为六位
  if (hex.length === 3) {
    hex = hex[0] + hex[0] + hex[1] + hex[1] + hex[2] + hex[2];
  }
  // 提取红、绿、蓝分量的十六进制值
  const r = parseInt(hex.substring(0, 2), 16);
  const g = parseInt(hex.substring(2, 4), 16);
  const b = parseInt(hex.substring(4, 6), 16);
  // 返回 RGB 值
  return `${r}, ${g}, ${b}`;
}

/**
 * 计算最终色值
 * @param options
 * @param theme
 * @param group
 * @param defaultValue
 * @returns {string|*}
 */
const resolveColor = (options, theme, themeKey) => {
  const [key, opacity] = themeKey.split(',');
  const color = opacity ? `rgba(${hexToRgb(options.themeConfig[theme][key])},${opacity})` : options.themeConfig[theme][key] // 有透明度转为RGB值
  const defaultValue = options.themeConfig['day'][key] // 默认是日间模式
  return color || defaultValue;
};

module.exports = postcss.plugin('postcss-theme-colors', options => {
  if (options && options.customThemeConfig) {
    defaults.themeConfig = Object.assign(defaults.themeConfig, options.customThemeConfig)
  }
  const curOptions = { ...defaults }

  const reGroup = new RegExp(`${curOptions.function}\\((\\w+)\\)`, 'g');

  return function (root) {
    // 获取最终 CSS 值
    const getValue = (value, theme) =>
      value.replace(reGroup, (_match, themeKey) =>
        resolveColor(curOptions, theme, themeKey)
      );
    // 遍历 CSS 声明
    root.walkDecls(decl => {
      const { value } = decl;

      // 如果不含有色值函数调用，则提前退出
      if (!value || !reGroup.test(value)) {
        return;
      }

      Reflect.ownKeys(defaults.themeConfig).forEach(function (key) {
        const themeValue = getValue(value, key)
        const themeDecl = decl.clone({ value: themeValue });
        const themeRule = postcss.rule({
          selector: `:root[data-theme=${key}] ${decl.parent.selector}`, // decl.parent.selector：所属class类名
        });
        // 添加 theme 样式到目标 HTML 节点中
        themeRule.append(themeDecl);
        // 添加到parent节点后，防止嵌套css导致部分机型样式失效
        decl.parent.after(themeRule);
      })

      // 基础样式
      const dayValue = getValue(value, 'day');
      const defaultDecl = decl.clone({ value: dayValue });
      decl.replaceWith(defaultDecl);
    });
  };
});

module.exports.postcss = true;
