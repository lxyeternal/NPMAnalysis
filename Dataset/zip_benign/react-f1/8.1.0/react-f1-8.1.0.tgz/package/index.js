'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _extends = Object.assign || function (target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }return target;
};

var React = require('react');
var f1DOM = require('f1-dom');
var merge = require('deep-extend');

var ReactF1 = function (_React$Component) {
  _inherits(ReactF1, _React$Component);

  function ReactF1(props) {
    _classCallCheck(this, ReactF1);

    var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(ReactF1).call(this, props));

    _this.hasMounted = false;
    _this.f1 = null;
    _this.f1States = null;

    _this.state = {};
    return _this;
  }

  _createClass(ReactF1, [{
    key: 'setupFromProps',
    value: function setupFromProps(props) {
      if (!this.f1) {
        this.initFromProps(props);
      } else {
        this.updateFromProps(props);
      }
    }
  }, {
    key: 'initFromProps',
    value: function initFromProps(props) {
      if (this.hasMounted && !this.f1 && props.go && props.states && props.transitions) {

        this.f1States = merge({}, props.states);

        var f1 = this.f1 = f1DOM({
          el: this.el,
          states: this.f1States,
          transitions: props.transitions,
          targets: props.targets,
          parsers: props.parsers
        });

        f1.on('state', this.handleState.bind(this));
        f1.on('update', this.handleUpdate.bind(this));
        this.updateListenersFromProps(props);

        f1.init(props.go);
      }
    }
  }, {
    key: 'updateFromProps',
    value: function updateFromProps(props) {
      var states;

      if (this.f1) {
        // if we've received new states then just mege into current states
        if (props.states) {
          merge(this.f1States, props.states);
        }

        // if we've received targets then reset them
        if (props.targets) {
          this.f1.targets(props.targets);
        }

        // call update to ensure everything looks right and is in its calculated state
        if (props.states || props.targets) {
          this.f1.update();
        }

        if (props.go) {
          this.f1.go(props.go, props.onComplete);
        }
      }

      this.updateListenersFromProps(props);
    }
  }, {
    key: 'updateListenersFromProps',
    value: function updateListenersFromProps(props) {
      this.setState({
        onUpdate: props.onUpdate,
        onState: props.onState
      });
    }
  }, {
    key: 'handleUpdate',
    value: function handleUpdate() {
      if (this.state.onUpdate) {
        this.state.onUpdate.apply(undefined, arguments);
      }
    }
  }, {
    key: 'handleState',
    value: function handleState() {
      if (this.state.onState) {
        this.state.onState.apply(undefined, arguments);
      }
    }
  }, {
    key: 'componentWillReceiveProps',
    value: function componentWillReceiveProps(nextProps) {
      this.setupFromProps(nextProps);
    }
  }, {
    key: 'componentDidMount',
    value: function componentDidMount() {
      this.hasMounted = true;
      this.setupFromProps(this.props);
    }
  }, {
    key: 'componentWillUnmount',
    value: function componentWillUnmount() {
      if (this.f1) {
        this.f1.destroy();
      }
    }
  }, {
    key: 'cleanProps',
    value: function cleanProps(props) {
      delete props.go;
      delete props.transitions;
      delete props.states;
      delete props.onComplete;
      delete props.onUpdate;
      delete props.component;
      return props;
    }
  }, {
    key: 'getElement',
    value: function getElement(el) {
      this.el = el;
    }
  }, {
    key: 'render',
    value: function render() {
      var style = merge({
        perspective: '1000px'
      }, this.props.style);

      if (!this.f1) {
        style = merge({}, this.props.style, {
          display: 'none'
        });
      }

      var props = _extends({}, this.props, {
        style: style,
        ref: this.getElement.bind(this)
      });

      return React.createElement(this.props.component || 'div', this.cleanProps(props), this.props.children);
    }
  }]);

  return ReactF1;
}(React.Component);

module.exports = ReactF1;