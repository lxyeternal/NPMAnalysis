'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _extends = Object.assign || function (target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }return target;
};

var React = require('react');
var f1Chief = require('f1/chief');
var merge = require('deep-extend');
var chiefBridge = function chiefBridge(target, onUpdate) {

  target.state = null;
  target.onComplete = null;

  return {
    isInitialized: false,

    init: function init(state) {
      this.isInitialized = true;
      target.go = state;
      onUpdate();
    },

    go: function go(state, onComplete) {
      target.go = state;
      target.onComplete = onComplete;
      onUpdate();
    }
  };
};

var Chief = function (_React$Component) {
  _inherits(Chief, _React$Component);

  function Chief(props) {
    _classCallCheck(this, Chief);

    var _this = _possibleConstructorReturn(this, Object.getPrototypeOf(Chief).call(this, props));

    _this.handleUpdate = _this.handleUpdate.bind(_this);

    _this.chief = null;
    _this.chiefStates = null;
    _this.state = {};
    return _this;
  }

  _createClass(Chief, [{
    key: 'componentWillMount',
    value: function componentWillMount() {
      this.chief = f1Chief({
        transitions: this.props.transitions,
        states: this.props.states,
        targets: this.getTargetsFromStates(this.props.states),
        onUpdate: function () {
          this.props.onUpdate.apply(undefined, arguments);
        }.bind(this)
      });
    }
  }, {
    key: 'componentWillUnMount',
    value: function componentWillUnMount() {
      if (this.chief) {
        this.chief.destroy();
      }
    }
  }, {
    key: 'componentDidMount',
    value: function componentDidMount() {
      this.chief.init(this.props.go);
    }
  }, {
    key: 'componentWillReceiveProps',
    value: function componentWillReceiveProps(nextProps) {

      var goState = nextProps.go;

      if (goState && (this.state.propsState !== goState || this.state.propsOnComplete !== nextProps.onComplete)) {
        this.chief.go(goState, nextProps.onComplete);

        this.setState({
          propsState: goState,
          propsOnComplete: nextProps.onComplete
        });
      }
    }
  }, {
    key: 'handleUpdate',
    value: function handleUpdate() {
      this.setState({
        chiefStates: this.chiefStates
      });
    }
  }, {
    key: 'getTargetsFromStates',
    value: function getTargetsFromStates(states) {
      var stateName = Object.keys(states)[0];
      var targets = {};
      var chiefState;

      this.chiefStates = {};

      for (var targetName in states[stateName]) {
        chiefState = {};
        this.chiefStates[targetName] = chiefState;

        targets[targetName] = chiefBridge(chiefState, this.handleUpdate);
      }

      return targets;
    }
  }, {
    key: 'getChildrenFromFunction',
    value: function getChildrenFromFunction(chiefState) {
      return this.props.children(chiefState);
    }
  }, {
    key: 'cleanProps',
    value: function cleanProps(props) {
      delete props.go;
      delete props.transitions;
      delete props.states;
      delete props.onComplete;
      delete props.onUpdate;
      delete props.component;
      return props;
    }
  }, {
    key: 'render',
    value: function render() {

      var chiefState = this.state.chiefStates;
      var children;

      if (chiefState) {

        if (typeof this.props.children === 'function') {
          children = this.getChildrenFromFunction(chiefState);
        } else {
          throw new Error('props.children should be a function that accepts chief states');
        }
      } else {
        children = this.props.children;
      }

      var props = _extends({}, this.props);

      return React.createElement(this.props.component || 'div', this.cleanProps(props), children);
    }
  }]);

  return Chief;
}(React.Component);

;

Chief.defaultProps = {
  onUpdate: function onUpdate() {}, // this.props.onUpdate(state, this.props.go);
  onComplete: function onComplete() {}
};

module.exports = Chief;