import math

def confidence(ups, downs):
    n = ups + downs

    if n == 0:
        return 0

    z = 1.96 # 95% confidence
    p = ups / n

    left = p + 1/(2*n)*z*z
    right = z*math.sqrt(p*(1-p)/n + z*z/(4*n*n))
    under = 1+1/n*z*z

    return (left - right) / under

print(confidence(10, 10))
print(confidence(10, 0))
print(confidence(0, 10))
print(confidence(100, 50))
print(confidence(50, 100))
print(confidence(1, 0))
