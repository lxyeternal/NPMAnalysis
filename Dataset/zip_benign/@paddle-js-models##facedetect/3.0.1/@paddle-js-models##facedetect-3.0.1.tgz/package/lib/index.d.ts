import { Runner } from '@paddlejs/paddlejs-core';

export declare function createImage(imgPath: string): Promise<HTMLImageElement>;

export declare class FaceDetector {
    modelConfig: ModelConfig;
    feedShape: FeedShape;
    runner: Runner;
    inputSize: NaturalSize;
    scale: number | undefined;
    constructor(modeConfig?: ModelConfig);
    init(): Promise<void>;
    detect(input: HTMLImageElement, opts?: any): Promise<any>;
    preprocess(input: HTMLImageElement, shrink: number): any;
    postprocessor(dataOut: any, threshold: number): any;
    transformData(data: Array<number>): TransformData;
}

declare interface FeedShape {
    fw: number;
    fh: number;
}

export declare interface ModelConfig {
    modelPath?: string;
    mean?: number[];
    std?: number[];
    feedShape?: FeedShape;
}

declare interface NaturalSize {
    naturalWidth: number;
    naturalHeight: number;
}

export declare interface TransformData {
    left: number;
    width: number;
    top: number;
    height: number;
    confidence: number;
}

export { }
