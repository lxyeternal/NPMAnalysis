let math = require("./lib/math");

// math.jia(1,2)

console.log(math.jia(1, 2)); //3
console.log(math.jian(1, 2)); //-1
console.log(math.chu(1, 2)); //0.5
console.log(math.cheng(1, 2)); //2
