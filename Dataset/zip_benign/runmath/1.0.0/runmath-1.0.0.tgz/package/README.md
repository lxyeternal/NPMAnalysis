安装

```js
 npm install runmath
```



说明

```js
let math=require('runmath')
math.jia(1,2) //3
math.jian(1,2) //-1
math.cheng(1,2)//2
math.chu(1,2)//0.5
```

