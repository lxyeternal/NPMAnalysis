export default function cssGradient2SVG(cssGradient: string): string | undefined;
