import { OnChanges, SimpleChanges, ElementRef, NgZone } from '@angular/core';
import { ScrollDispatcher, ViewportRuler } from '@angular/cdk/scrolling';
import { AnimateConfig } from './animate.config';
import { AnimateService } from './animate.service';
export declare class AnimateDirective extends AnimateService implements OnChanges {
    private elref;
    constructor(elref: ElementRef<HTMLElement>, scroll: ScrollDispatcher, port: ViewportRuler, zone: NgZone, config?: AnimateConfig);
    /** When true instructs the directive to use the element's bounding rect as the animation view */
    useElement: boolean;
    /** Optional top offset */
    top: number;
    /** Optional left offset */
    left: number;
    /** Optional bottom offset */
    bottom: number;
    /** Optional right offset */
    right: number;
    ngOnChanges(changes: SimpleChanges): void;
}
