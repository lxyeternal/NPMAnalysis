import { AnimateConfig } from './animate.config';
import { ElementRef, NgZone } from '@angular/core';
import { ScrollDispatcher, ViewportRuler } from '@angular/cdk/scrolling';
import { OperatorFunction } from 'rxjs';
/** Configures alternative containers for AOS triggering */
export interface AnimateOptions {
    root?: Element;
    left?: number;
    top?: number;
    right?: number;
    bottom?: number;
}
export declare class AnimateService {
    private scroll;
    private viewPort;
    private zone;
    private config?;
    private options$;
    private view$;
    /** True when the trigger is provided using the IntersectionObserver API */
    get useIntersectionObserver(): boolean;
    /** True when the trigger is provided using cdk/scrolling package */
    get useScrolling(): boolean;
    /** Applies the given options to the triggering service */
    setup(options: AnimateOptions): void;
    constructor(scroll: ScrollDispatcher, viewPort: ViewportRuler, zone: NgZone, config?: AnimateConfig);
    trigger(elm: ElementRef<HTMLElement>, threshold: number): OperatorFunction<boolean, boolean>;
    private intersecting;
    /** Builds an Obsevable out of the IntersectionObserver API */
    private observe;
    private scrolling;
    private visibility;
}
