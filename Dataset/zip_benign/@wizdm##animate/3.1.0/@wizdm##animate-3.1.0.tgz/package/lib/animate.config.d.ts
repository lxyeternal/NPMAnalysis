import { InjectionToken } from '@angular/core';
/** Global configuration for Animate */
export interface AnimateConfig {
    triggerMode: 'scrolling' | 'intersectionObserver' | 'auto';
    offsetTop?: number;
    offsetRight?: number;
    offsetBottom?: number;
    offsetLeft?: number;
}
/** Animate config token */
export declare const ANIMATE_CONFIG: InjectionToken<AnimateConfig>;
/** Builds the config object checking whenever the Browser support the IntersectionObserver API */
export declare function animateConfigFactory(value?: AnimateConfig): AnimateConfig;
