import { ModuleWithProviders } from '@angular/core';
import { AnimateConfig } from './animate.config';
export declare class AnimateModule {
    static init(config: AnimateConfig): ModuleWithProviders<AnimateModule>;
}
