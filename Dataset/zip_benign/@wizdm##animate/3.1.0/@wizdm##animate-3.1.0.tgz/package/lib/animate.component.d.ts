import { OnInit, OnDestroy, EventEmitter, ElementRef, Renderer2 } from '@angular/core';
import { AnimateService } from './animate.service';
export declare type wmAnimateSpeed = 'slower' | 'slow' | 'normal' | 'fast' | 'faster';
export declare type wmAnimations = 'beat' | 'bounce' | 'flip' | 'headShake' | 'heartBeat' | 'jello' | 'pulse' | 'rubberBand' | 'shake' | 'swing' | 'tada' | 'wobble' | 'bumpIn' | 'bounceIn' | 'bounceInDown' | 'bounceInLeft' | 'bounceInUp' | 'bounceInRight' | 'fadeIn' | 'fadeInRight' | 'fadeInLeft' | 'fadeInUp' | 'fadeInDown' | 'flipInX' | 'flipInY' | 'jackInTheBox' | 'landing' | 'rollIn' | 'zoomIn' | 'zoomInDown' | 'zoomInLeft' | 'zoomInUp' | 'zoomInRight' | 'bounceOut' | 'bounceOutDown' | 'bounceOutUp' | 'bounceOutRight' | 'bounceOutLeft' | 'fadeOut' | 'fadeOutRight' | 'fadeOutLeft' | 'fadeOutDown' | 'fadeOutUp' | 'hinge' | 'rollOut' | 'zoomOut' | 'zoomOutDown' | 'zoomOutRight' | 'zoomOutUp' | 'zoomOutLeft' | 'none';
export declare class AnimateComponent implements OnInit, OnDestroy {
    private elm;
    private scroll;
    private renderer;
    private replay$;
    private sub;
    private timing;
    private delay;
    animating: boolean;
    animated: boolean;
    constructor(elm: ElementRef, scroll: AnimateService, renderer: Renderer2);
    trigger: any;
    private get idle();
    private get play();
    /** Selects the animation to be played */
    animate: wmAnimations;
    /** Speeds up or slows down the animation */
    set speed(speed: wmAnimateSpeed);
    /** Delays the animation */
    set postpone(delay: string);
    /** Disables the animation */
    set disableAnimation(value: boolean);
    disabled: boolean;
    /** Emits at the end of the animation */
    start: EventEmitter<void>;
    animationStart(): void;
    /** Emits at the end of the animation */
    done: EventEmitter<void>;
    animationDone(): void;
    /** When true, keeps the animation idle until the next replay triggers */
    set pauseAnimation(value: boolean);
    paused: boolean;
    /** When defined, triggers the animation on element scrolling in the viewport by the specified amount. Amount defaults to 50% when not specified */
    set enableAOS(value: number);
    private threshold;
    /** When true, triggers the animation on element scrolling in the viewport */
    set aosOnce(value: boolean);
    once: boolean;
    /** Replays the animation */
    set replay(replay: any);
    ngOnInit(): void;
    ngOnDestroy(): void;
}
