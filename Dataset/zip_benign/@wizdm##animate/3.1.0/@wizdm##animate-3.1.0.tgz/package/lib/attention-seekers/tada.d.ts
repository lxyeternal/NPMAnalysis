export declare const tada: import("@angular/animations").AnimationTransitionMetadata[];
