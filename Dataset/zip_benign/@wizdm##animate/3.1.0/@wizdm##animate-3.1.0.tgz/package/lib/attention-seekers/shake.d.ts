export declare const shake: import("@angular/animations").AnimationTransitionMetadata[];
