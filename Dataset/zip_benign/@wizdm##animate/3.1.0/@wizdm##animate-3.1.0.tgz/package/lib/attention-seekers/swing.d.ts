export declare const swing: import("@angular/animations").AnimationTransitionMetadata[];
