export declare const beat: import("@angular/animations").AnimationTransitionMetadata[];
