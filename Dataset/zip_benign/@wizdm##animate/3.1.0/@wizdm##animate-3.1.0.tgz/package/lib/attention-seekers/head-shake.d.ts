export declare const headShake: import("@angular/animations").AnimationTransitionMetadata[];
