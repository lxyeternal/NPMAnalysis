export declare const rubberBand: import("@angular/animations").AnimationTransitionMetadata[];
