export declare const jello: import("@angular/animations").AnimationTransitionMetadata[];
