export declare const bounce: import("@angular/animations").AnimationTransitionMetadata[];
