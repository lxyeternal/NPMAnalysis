export declare const pulse: import("@angular/animations").AnimationTransitionMetadata[];
