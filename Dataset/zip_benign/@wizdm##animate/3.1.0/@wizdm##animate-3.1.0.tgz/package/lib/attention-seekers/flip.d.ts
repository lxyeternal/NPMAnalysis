export declare const flip: import("@angular/animations").AnimationTransitionMetadata[];
