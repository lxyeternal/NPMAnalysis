export declare const wobble: import("@angular/animations").AnimationTransitionMetadata[];
