export declare const heartBeat: import("@angular/animations").AnimationTransitionMetadata[];
