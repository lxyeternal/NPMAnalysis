export declare const hinge: (import("@angular/animations").AnimationStateMetadata | import("@angular/animations").AnimationTransitionMetadata)[];
