export declare const bounceIn: (import("@angular/animations").AnimationStateMetadata | import("@angular/animations").AnimationTransitionMetadata)[];
