export declare const landing: (import("@angular/animations").AnimationStateMetadata | import("@angular/animations").AnimationTransitionMetadata)[];
