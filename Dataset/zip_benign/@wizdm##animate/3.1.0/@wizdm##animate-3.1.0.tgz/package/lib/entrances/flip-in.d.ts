export declare const flipIn: (import("@angular/animations").AnimationStateMetadata | import("@angular/animations").AnimationTransitionMetadata)[];
