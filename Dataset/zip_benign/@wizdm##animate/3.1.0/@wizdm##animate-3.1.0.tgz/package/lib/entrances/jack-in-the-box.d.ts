export declare const jackInTheBox: (import("@angular/animations").AnimationStateMetadata | import("@angular/animations").AnimationTransitionMetadata)[];
