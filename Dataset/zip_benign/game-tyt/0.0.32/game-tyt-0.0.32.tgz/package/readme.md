# tyt

# 游戏

##### 安装

```
npm install game-tyt
```

##### 使用
```
必须开启 "enableSkia": "true"
```
- json

```
{
    "usingComponents": {
        "game": "game-tyt/tyt"
    }
}
```

- mini.project.json
```
{
  "node_modules_es6_whitelist": [
    "common-game"
  ]
}
```

- js

```
Page({
  data: {
    gameSource: {
      direction: "bottom",//方向 bottom：从上往下走 其他值：从下往上走
      tytVal: 200,//弹一弹距离
      angule: 30,//角度
      beginX: 750 - 180,//开始第一个元素X轴坐标
      minBottomY: 400,//最下元素距离底部距离
      autoStart: true,//自动开始游戏
      stepVal: { min: -200, max: 200 },//元素间隔值 随机
      maxEqualCount: 2,//同一个方向连续出现的最大个数
      helpLine: !true,//帮助线
      jumpLine: !!true,//跳跃辅助线
      jumpLineOps: {
        color: "#60537c",//辅助线颜色
        alpha: 1,//辅助线透明度
        r: 1.5,//辅助线圆半径
        count: 50,//辅助线圆点个数
        offsetY: 0,//最高点偏移（值越大，辅助线幅度越高，这个只做参考，与实际跳跃无关）
        endOffsetX: 50,//水平偏移值
      },
      zIndex: true,//true:后生成元素显示在上面 false:后生成的元素显示在下面
      boxRenderOps: {
        time: 2.5,
        ease: "linear-",
      },
      box: [
        // mustShow：开始必现元素
        // checkRect:异形坐标点
        // bringOffset:{x:0,y:0}:复活偏移量
        // touchObj:点击盒子压缩对象 {height:压缩高度，downTime:下压时间,upTime:回弹时间}
        {
          "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01kr5oNw1EUdMy9DUOx_!!2185320355.png", bringOffset: { x: 16, y: 6 }, "val": "0", "width": "296", "height": "434", probability: 1, padding: { left: 120, right: 120 }, anchor: { x: 0.5, y: 0.2 }, checkRect: { points: [{ x: 12, y: 84 }, { x: 152, y: 6 }, { x: 282, y: 84 }, { x: 142, y: 160 }] },
          boxTipArr: [
            { src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01uxtZRl1EUdMsZnvs3_!!2185320355.png" },
            { src: "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01uM4ESB1EUdMqkeSAi_!!2185320355.png" },
            { src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01MyPiWi1EUdMoJD1zB_!!2185320355.png" },
          ],
          boomAni: {
            srcArr: [
              { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01zxGvJQ1EUdMvN3e7v_!!2185320355.png", "name": "合成 1_00000.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01XuGt9t1EUdMzQz4wZ_!!2185320355.png", "name": "合成 1_00001.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01z1FUTa1EUdMqp4pWH_!!2185320355.png", "name": "合成 1_00002.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01NycjCy1EUdMm5hd56_!!2185320355.png", "name": "合成 1_00003.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01O0PUOt1EUdMzQx4Ap_!!2185320355.png", "name": "合成 1_00004.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN012vIlus1EUdMt7DlxR_!!2185320355.png", "name": "合成 1_00005.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01lo3iKT1EUdMzQx01A_!!2185320355.png", "name": "合成 1_00006.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01yyHLQo1EUdMt7Eynx_!!2185320355.png", "name": "合成 1_00007.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01DnSNZC1EUdMm5k2mc_!!2185320355.png", "name": "合成 1_00008.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01zEK8aM1EUdMyDdvoK_!!2185320355.png", "name": "合成 1_00009.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01Ququo51EUdMzQwSkK_!!2185320355.png", "name": "合成 1_00010.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN016zBBmo1EUdMuR068a_!!2185320355.png", "name": "合成 1_00011.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01mdOrUJ1EUdMzQz0mV_!!2185320355.png", "name": "合成 1_00012.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01byGgOt1EUdMzQzLac_!!2185320355.png", "name": "合成 1_00013.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01Kxefn21EUdMhCOcEo_!!2185320355.png", "name": "合成 1_00014.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01NNbzsS1EUdMrXanTz_!!2185320355.png", "name": "合成 1_00015.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01ab7ORt1EUdMt7D2Gs_!!2185320355.png", "name": "合成 1_00016.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN011fZmqd1EUdMvN2m6d_!!2185320355.png", "name": "合成 1_00017.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01MOUPDA1EUdMyDd3mv_!!2185320355.png", "name": "合成 1_00018.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01f6LXbM1EUdMneIkwb_!!2185320355.png", "name": "合成 1_00019.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01NqK6gM1EUdMoNh2BU_!!2185320355.png", "name": "合成 1_00020.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01TRHdJ61EUdMneKAHy_!!2185320355.png", "name": "合成 1_00021.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01plrbbD1EUdN0HuPcU_!!2185320355.png", "name": "合成 1_00022.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01FwcpoR1EUdMyDbaK6_!!2185320355.png", "name": "合成 1_00023.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN012ZRfT61EUdMhCR1xm_!!2185320355.png", "name": "合成 1_00024.png", "width": "287", "height": "207" },
              { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01J84bW21EUdMoNg1q8_!!2185320355.png", "name": "合成 1_00025.png", "width": "287", "height": "207" },
            ],
            type: "animate",
            imgType: "max",
            width: 287 * 26,
            height: 207,
            fWidth: 287,
            fHeight: 207,
            count: 26,
            boomSpeed: 0.35,
            offset: {
              x: -70,
              y: 100
            },
            loop: !true,
          },
          showPlayer: {
            name: "left",
            offset:{
              x: 150,
              y: 100
            }
          },
        },
      ],
      pen: {
        probability: 500,//笔的概率，以1000为基准
        arr: [
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01xl29TI1EUdMqmvAPp_!!2185320355.png", probability: 1, anchor: { x: 0.5, y: 0.8 }, val: 1 },
        ],
      },
      playTipScore: [
        // val:分数 per:百分比区间 offsetLeft:左侧分数偏移 offsetRight:右侧分数偏移 checkVal:匹配当前获得分数（不会计入总分数）
        { src: "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01g6TRjA1EUdMh7ohjj_!!2185320355.png", val: 1, checkVal: true, per: { min: 0, max: 100 }, offsetLeft: { x: -60, y: -80 }, offsetRight: { x: 0, y: -80 } },
      ],
      player: {
        left: { src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01z6SzSW1EUdMm17W49_!!2185320355.png", checkRect: { points: [{ x: 74, y: 170 }, { x: 84, y: 170 }, { x: 84, y: 180 }, { x: 74, y: 180 }] }, anchor: { x: 0.5, y: 0.9 }, jump: { src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01z6SzSW1EUdMm17W49_!!2185320355.png", anchor: { x: 0.5, y: 0.9 } } },
        right: { src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01z6SzSW1EUdMm17W49_!!2185320355.png", checkRect: { points: [{ x: 74, y: 170 }, { x: 84, y: 170 }, { x: 84, y: 180 }, { x: 74, y: 180 }] }, anchor: { x: 0.5, y: 0.9 }, jump: { src: "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01z6SzSW1EUdMm17W49_!!2185320355.png", anchor: { x: 0.5, y: 0.9 } } }
      },
      jumpOps: {
        jumpHeight: 50,//跳跃高度
        jumpTime: 0.5,//跳跃时间
        sensitivity: 800,//灵敏度 按1s跳跃的距离
        min: 10,//单次跳跃最小值
        max: 700,//单词跳跃最大值
        maxDunzi: 3,//同时显示的墩子个数
        life: 1,//生命数（星星显示的数量未life-1）
        autoBringBack: true,//自动复活
        autoBringBackTime: 1.5,//自动复活的时间
        tipScoreShowTime: 0.5,//分数显示时间
      },
      dieOps: {
        // 游戏结束配置
        moveDown: 0,//下层高度
        opa: 1,//透明度
        rotation: 0,//角度
        duration: 0.5,//过度时间
      },
      audioObj: {
        // // 长按音乐
        // tap: { url: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/qxNm4EfReGhkXUWsivc?auth_key=1653721700-0-0-3941404c99ae739e4a91a7d59a95f4f2&w=0&h=0&e=sd&t=212cbe7e16534625000436350ea09c&b=tb_rcpaasm&p=tb_rcpaasm_miniapp_cloud", loop: false },
        // // 长按播放完还按住的音乐
        // tapend: { url: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/QH14te0PgTX29Arnjpo?auth_key=1653721857-0-0-a584e5d09a855129abd2902d15807301&w=0&h=0&e=sd&t=212cbe7e16534626570472657ea09c&b=tb_rcpaasm&p=tb_rcpaasm_miniapp_cloud", loop: true },
        // 落地普通音乐
        doneDef: { url: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/QH14te0PgTX29Arnjpo?auth_key=1653721857-0-0-a584e5d09a855129abd2902d15807301&w=0&h=0&e=sd&t=212cbe7e16534626570472657ea09c&b=tb_rcpaasm&p=tb_rcpaasm_miniapp_cloud", loop: false },
        // 落地完美音乐
        donePerfect: { url: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/qxNm4EfReGhkXUWsivc?auth_key=1653721700-0-0-3941404c99ae739e4a91a7d59a95f4f2&w=0&h=0&e=sd&t=212cbe7e16534625000436350ea09c&b=tb_rcpaasm&p=tb_rcpaasm_miniapp_cloud", loop: false },
        // 落到格子上有物品时的音效
        doneHasPen: { url: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/qxNm4EfReGhkXUWsivc?auth_key=1653721700-0-0-3941404c99ae739e4a91a7d59a95f4f2&w=0&h=0&e=sd&t=212cbe7e16534625000436350ea09c&b=tb_rcpaasm&p=tb_rcpaasm_miniapp_cloud", loop: false },
        // 落地失败音乐
        doneError: { url: "http://isv-vod.alibabausercontent.com/RGjZJMdpNgKGVQeEyw8/qxNm4EfReGhkXUWsivc?auth_key=1653721700-0-0-3941404c99ae739e4a91a7d59a95f4f2&w=0&h=0&e=sd&t=212cbe7e16534625000436350ea09c&b=tb_rcpaasm&p=tb_rcpaasm_miniapp_cloud", loop: false },
      },
      // 玩家头部提示
      userTipImg: {
        "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01h7lGqy1EUdMxRg92p_!!2185320355.png", "name": "提示.png", "width": "212", "height": "106", offset: { x: 81, y: -10 }, anchor: { x: 0.5, y: 1 }, randomTime: { min: 3, max: 6 }, showTime: 1
      },
      endAni: {
        renderCount: 20,//生成个数
        aniTime: { min: 0.8, max: 3 },//动画时间范围
        setpTime: 0.1,//间隔时间
        arr: [
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN017Ct9Z81EUdMyEWa38_!!2185320355.png", "name": "喜默因Q版1.png", "width": "500", "height": "500", scaleRange: { min: 0, max: 0.5 }, },
          { "src": "https://img.alicdn.com/imgextra/i2/2185320355/O1CN01ksx3TI1EUdMsfCOhO_!!2185320355.png", "name": "喜默因Q版2.png", "width": "500", "height": "500", scaleRange: { min: 0, max: 0.5 }, },
          { "src": "https://img.alicdn.com/imgextra/i3/2185320355/O1CN01HNBQ8K1EUdMm6aLL3_!!2185320355.png", "name": "喜默因Q版3.png", "width": "500", "height": "500", scaleRange: { min: 0, max: 0.5 }, },
          { "src": "https://img.alicdn.com/imgextra/i4/2185320355/O1CN01p5wKis1EUdMxRh18Z_!!2185320355.png", "name": "喜默因Q版4.png", "width": "500", "height": "500", scaleRange: { min: 0, max: 0.5 }, },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01NVaPn01EUdMzRohsB_!!2185320355.png", "name": "喜默因Q版5.png", "width": "500", "height": "500", scaleRange: { min: 0, max: 0.5 }, },
          { "src": "https://img.alicdn.com/imgextra/i1/2185320355/O1CN01bdgMSa1EUdN0IgLQS_!!2185320355.png", "name": "喜默因Q版6.png", "width": "500", "height": "500", scaleRange: { min: 0, max: 0.5 }, },
        ]
      }
    },
    showGame: true,
  },
  onLoad() {
  },
  changeFun() {
    this.setData({
      showGame: !this.data.showGame
    })
  },
  // 组件主动公开方法----------
  beginFun() {
    // 开始游戏
    this.gameComponent.onEvent("start");
  },
  stopFun() {
    // 结束游戏
    this.gameComponent.onEvent("stop");
  },
  resetFun() {
    // 重置游戏
    /* this.gameComponent.game.GameData.jumpLine = false;
    this.gameComponent.game.GameData.jumpOps.life = 1; */
    this.gameComponent.onEvent("reset");
  },
  bringBackFun() {
    // 复活
    this.gameComponent.onEvent("bringBack");
  },
  endAniFun() {
    // 播放结束动画
    this.gameComponent.onEvent("endAniFun");
  },
  muteFun() {
    // 静音
    this.gameComponent.onEvent("mute");
  },
  playFun() {
    // 播放
    this.gameComponent.onEvent("play");
  },

  // 组件回调方法------------------
  onRef(game) {
    this.gameComponent = game;
    console.log("进入游戏")
  },
  onInitDone() {
    // my.alert({
    //   content: "游戏初始化完成"
    // })
  },
  onUpdate(ops) {
    // ops: {centerv:人物和方块中心点距离,curScore:当前踩中的方块分数,totalScore:当局总分数,imgObj:踩中的方块对象,penImg:踩中的物品对象,}
    // { totalScore: 0, imgObj: { } }
    console.log(ops)
  },
  onGameOver(totalScore) {
    console.log(totalScore)
  },
  onClickProgressFun(ops) {//点击时长回调，百分比
    console.log(ops)
    this.setData({ per: ops.per })
  },
  onJumpDone() {//跳跃完成
    this.setData({ per: 0 })
  },
  onEndAniCallback() {
    console.error("结束动画执行完成")
  }
});
```

- xaml

```
  <view class="pageBox">
    <view class="gameBox">
      <game gameSource="{{gameSource}}" a:if="{{showGame}}" onRef="onRef" onInitDone="onInitDone" onUpdate="onUpdate" onGameOver="onGameOver" 
        onClickProgressFun="onClickProgressFun" onJumpDone="onJumpDone" onEndAniCallback="onEndAniCallback" />
    </view>
    <view>百分比：{{per||0}}%</view>
    <view onTap="beginFun" style="position:relative;z-index: 10;">开始</view>
    <view onTap="stopFun" style="position:relative;z-index: 10;">结束</view>
    <view onTap="resetFun" style="position:relative;z-index: 10;">重置</view>
    <view onTap="bringBackFun" style="position:relative;z-index: 10;">复活</view>
    <view onTap="changeFun" style="position:relative;z-index: 10;">切换</view>
    <view onTap="endAniFun" style="position:relative;z-index: 10;">结束动画</view>
    <view onTap="muteFun" style="position:relative;z-index: 10;">静音</view>
    <view onTap="playFun" style="position:relative;z-index: 10;">播放</view>
  </view>
```