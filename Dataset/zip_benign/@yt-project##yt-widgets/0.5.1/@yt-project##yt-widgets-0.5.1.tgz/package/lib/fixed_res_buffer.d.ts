import { DOMWidgetModel, ISerializers } from '@jupyter-widgets/base';
import { VariableMeshModel } from './variable_mesh';
import { FixedResolutionBuffer } from './utils';
export interface IFRBViewBounds {
    x_low: number;
    x_high: number;
    y_low: number;
    y_high: number;
}
export declare class FRBModel extends DOMWidgetModel {
    defaults(): any;
    initialize(attributes: any, options: any): void;
    static serializers: ISerializers;
    sizeChanged(): void;
    calculateViewBounds(): IFRBViewBounds;
    depositDataBuffer(variable_mesh_model: VariableMeshModel, current_field: string): Promise<Float64Array>;
    frb: FixedResolutionBuffer;
    variable_mesh_model: VariableMeshModel;
    data_buffer: Float64Array;
    width: number;
    height: number;
    view_center: [number, number];
    view_width: [number, number];
    static model_name: string;
    static model_module: any;
    static model_module_version: any;
}
