import { DOMWidgetModel, ISerializers } from '@jupyter-widgets/base';
import { VariableMesh } from './utils';
export declare class FieldArrayModel extends DOMWidgetModel {
    defaults(): any;
    initialize(attributes: any, options: any): void;
    static serializers: ISerializers;
    field_name: string;
    array: Float64Array;
    static model_name: string;
    static model_module: any;
    static model_module_version: any;
}
export declare class VariableMeshModel extends DOMWidgetModel {
    defaults(): any;
    initialize(attributes: any, options: any): void;
    updateFieldValues(): void;
    static serializers: ISerializers;
    px: Float64Array;
    pdx: Float64Array;
    py: Float64Array;
    pdy: Float64Array;
    field_values: Array<FieldArrayModel>;
    variable_mesh: VariableMesh;
    static model_name: string;
    static model_module: any;
    static model_module_version: any;
}
