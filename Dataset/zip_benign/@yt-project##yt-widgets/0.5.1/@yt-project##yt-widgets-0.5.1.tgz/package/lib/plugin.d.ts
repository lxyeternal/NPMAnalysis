import { JupyterFrontEndPlugin } from '@jupyterlab/application';
declare const widgytsPlugin: JupyterFrontEndPlugin<void>;
export default widgytsPlugin;
