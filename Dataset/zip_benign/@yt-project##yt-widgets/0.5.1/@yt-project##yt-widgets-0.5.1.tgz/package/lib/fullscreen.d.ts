import { RenderableModel } from 'jupyter-threejs';
import { ISerializers, DOMWidgetModel, DOMWidgetView } from '@jupyter-widgets/base';
export declare class FullscreenButtonModel extends DOMWidgetModel {
    defaults(): any;
    static serializers: ISerializers;
    renderer: RenderableModel;
    disabled: boolean;
    static view_name: string;
    static view_module: any;
    static view_module_version: any;
    static model_name: string;
    static model_module: any;
    static model_module_version: any;
}
export declare class FullscreenButtonView extends DOMWidgetView {
    /**
     * Called when view is rendered.
     */
    render(): void;
    /**
     * Update the contents of this view
     *
     * Called when the model is changed. The model may have been
     * changed by another view or by a state update from the back-end.
     */
    update(): void;
    /**
     * Dictionary of events and handlers
     */
    events(): {
        [e: string]: string;
    };
    /**
     * Handles when the button is clicked.
     */
    _handle_click(event: MouseEvent): void;
    oldRendererWidth: number;
    oldRendererHeight: number;
    /**
     * The default tag name.
     *
     * #### Notes
     * This is a read-only attribute.
     */
    el: HTMLButtonElement;
}
