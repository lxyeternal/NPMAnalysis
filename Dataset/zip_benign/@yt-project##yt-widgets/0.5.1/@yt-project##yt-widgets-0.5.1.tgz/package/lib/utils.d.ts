export { VariableMesh, Colormap, ColormapCollection, FixedResolutionBuffer } from '@data-exp-lab/yt-tools';
export declare const yt_tools: {
    default: typeof import("@data-exp-lab/yt-tools");
    set_panic_hook(): void;
    Colormap: typeof import("@data-exp-lab/yt-tools").Colormap;
    ColormapCollection: typeof import("@data-exp-lab/yt-tools").ColormapCollection;
    FixedResolutionBuffer: typeof import("@data-exp-lab/yt-tools").FixedResolutionBuffer;
    RGBAValue: typeof import("@data-exp-lab/yt-tools").RGBAValue;
    VariableMesh: typeof import("@data-exp-lab/yt-tools").VariableMesh;
};
export declare function serializeArray<T extends ArrayBufferView>(array: T): DataView;
export declare function arrayDeserializerFactory<T>(type: {
    new (v: ArrayBuffer): T;
}): (a: DataView | null) => T | null;
export interface IArraySerializers {
    serialize: (array: ArrayBufferView) => DataView;
    deserialize: (buffer: DataView | null) => ArrayBufferView;
}
export declare const f32Serializer: IArraySerializers;
export declare const f64Serializer: IArraySerializers;
export declare const u8Serializer: IArraySerializers;
export declare const u64Serializer: IArraySerializers;
