import { WidgetModel } from '@jupyter-widgets/base';
import { ColormapCollection } from './utils';
export declare class ColormapContainerModel extends WidgetModel {
    defaults(): any;
    initialize(attributes: any, options: any): void;
    normalize(colormap_name: string, data_array: Float64Array, output_array: Uint8ClampedArray, min_val: number, max_val: number, take_log: boolean): Promise<void>;
    private setupColormaps;
    colormap_values: unknown;
    colormaps: ColormapCollection;
    _initialized: boolean;
    static model_name: string;
    static model_module: any;
    static model_module_version: any;
}
