declare type StringSoupMatch = {
    knownString: string;
    score: number;
};
declare type StringSoupMatchResult = {
    token: string;
    match: StringSoupMatch;
};
declare type StringSoupResult = {
    best: StringSoupMatchResult;
    all: StringSoupMatchResult[];
};
declare class StringSoup {
    private knownStrings;
    constructor(knownStrings: string[]);
    static sanitize: (soup: string) => string;
    static tokenize: (soup: string) => string[];
    static scoreString: (known: string, guess: string) => number;
    static StringSoupMatchResultComparator: (result1: StringSoupMatchResult, result2: StringSoupMatchResult) => number;
    matchToken: (token: string) => StringSoupMatch;
    matchSoup: (soup: string) => {
        best: StringSoupMatchResult;
        all: StringSoupMatchResult[];
    };
}
export { StringSoup, StringSoupResult, StringSoupMatchResult };
