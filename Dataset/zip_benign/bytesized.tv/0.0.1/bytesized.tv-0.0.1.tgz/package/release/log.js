"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
/*   _______________
 *  |.-------------.|
 *  ||~$[byte-sized||
 *  ||   .tv]>     ||
 * _|-_____________-|_
 * \_________________/
 * 
 * This project is a part of the “Byte-Sized JavaScript” videocast.
 *
 * You can watch “Byte-Sized JavaScript” at: https://bit.ly/bytesized
 *
 * MIT Licensed — See LICENSE.md
 *
 * Send your comments, suggestions, and feedback to me@volkan.io
 */

var trace = function trace() {
  var _console;

  return (_console = console).trace.apply(_console, arguments);
};
var debug = function debug() {
  var _console2;

  return (_console2 = console).log.apply(_console2, arguments);
};
var info = function info() {
  var _console3;

  return (_console3 = console).info.apply(_console3, arguments);
};
var warn = function warn() {
  var _console4;

  return (_console4 = console).warn.apply(_console4, arguments);
};
var error = function error() {
  var _console5;

  return (_console5 = console).error.apply(_console5, arguments);
};

exports.trace = trace;
exports.debug = debug;
exports.info = info;
exports.warn = warn;
exports.error = error;