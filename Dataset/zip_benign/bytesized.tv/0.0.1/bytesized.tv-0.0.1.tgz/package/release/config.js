'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.paths = exports.api = undefined;

var _path = require('path');

var API_KEY = process.env.YOUTUBE_API_KEY;
var API_ROOT = 'https://www.googleapis.com/youtube/v3';
var CHANNEL_ID = 'UC8OLZSlFO8cwRo9M30v-TkA';

var TIMESTAMP_PATH = (0, _path.join)(__dirname, '../data/.timestamp');
var VIDEOS_DATA_PATH = (0, _path.join)(__dirname, '../data/videos.json');
var TAGS_DATA_PATH = (0, _path.join)(__dirname, '../data/tags.json');

var api = {
    KEY: API_KEY,
    ROOT: API_ROOT,
    CHANNEL_ID: CHANNEL_ID
};

var paths = {
    TIMESTAMP: TIMESTAMP_PATH,
    VIDEOS_DATA: VIDEOS_DATA_PATH,
    TAGS_DATA: TAGS_DATA_PATH
};

exports.api = api;
exports.paths = paths;