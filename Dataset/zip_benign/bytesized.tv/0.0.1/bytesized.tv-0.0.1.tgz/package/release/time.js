'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.now = undefined;

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var now = function now() {
  return (0, _moment2.default)().format('YYYY-MM-DD') + 'T00:00:00Z';
}; /*   _______________
    *  |.-------------.|
    *  ||~$[byte-sized||
    *  ||   .tv]>     ||
    * _|-_____________-|_
    * \_________________/
    *
    * This project is a part of the “Byte-Sized JavaScript” videocast.
    *
    * You can watch “Byte-Sized JavaScript” at: https://bit.ly/bytesized
    *
    * MIT Licensed — See LICENSE.md
    *
    * Send your comments, suggestions, and feedback to me@volkan.io
    */

exports.now = now;