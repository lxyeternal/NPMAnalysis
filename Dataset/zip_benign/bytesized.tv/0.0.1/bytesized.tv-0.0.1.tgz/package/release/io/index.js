'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.persistTimestamp = exports.persistTags = exports.persistVideos = exports.fetchLastUpdateTimestamp = exports.fetchVideosFromCache = undefined;

var _config = require('../config');

var _core = require('./core');

var _time = require('../time');

var fetchVideosFromCache = function fetchVideosFromCache() {
  return (0, _core.readFile)(_config.paths.VIDEOS_DATA, true, []);
}; /*   _______________
    *  |.-------------.|
    *  ||~$[byte-sized||
    *  ||   .tv]>     ||
    * _|-_____________-|_
    * \_________________/
    *
    * This project is a part of the “Byte-Sized JavaScript” videocast.
    *
    * You can watch “Byte-Sized JavaScript” at: https://bit.ly/bytesized
    *
    * MIT Licensed — See LICENSE.md
    *
    * Send your comments, suggestions, and feedback to me@volkan.io
    */

var fetchLastUpdateTimestamp = function fetchLastUpdateTimestamp() {
  return (0, _core.readFile)(_config.paths.TIMESTAMP, false, (0, _time.now)());
};
var persistVideos = function persistVideos(videos) {
  return (0, _core.writeFile)(_config.paths.VIDEOS_DATA, videos);
};
var persistTags = function persistTags(tags) {
  return (0, _core.writeFile)(_config.paths.TAGS_DATA, tags);
};
var persistTimestamp = function persistTimestamp() {
  return (0, _core.writeFile)(_config.paths.TIMESTAMP, (0, _time.now)(), false);
};

exports.fetchVideosFromCache = fetchVideosFromCache;
exports.fetchLastUpdateTimestamp = fetchLastUpdateTimestamp;
exports.persistVideos = persistVideos;
exports.persistTags = persistTags;
exports.persistTimestamp = persistTimestamp;