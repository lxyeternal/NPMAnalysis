'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.writeFile = exports.readFile = undefined;

var _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) { return typeof obj; } : function (obj) { return obj && typeof Symbol === "function" && obj.constructor === Symbol ? "symbol" : typeof obj; }; /*   _______________
                                                                                                                                                                                                                                                   *  |.-------------.|
                                                                                                                                                                                                                                                   *  ||~$[byte-sized||
                                                                                                                                                                                                                                                   *  ||   .tv]>     ||
                                                                                                                                                                                                                                                   * _|-_____________-|_
                                                                                                                                                                                                                                                   * \_________________/
                                                                                                                                                                                                                                                   *
                                                                                                                                                                                                                                                   * This project is a part of the “Byte-Sized JavaScript” videocast.
                                                                                                                                                                                                                                                   *
                                                                                                                                                                                                                                                   * You can watch “Byte-Sized JavaScript” at: https://bit.ly/bytesized
                                                                                                                                                                                                                                                   *
                                                                                                                                                                                                                                                   * MIT Licensed — See LICENSE.md
                                                                                                                                                                                                                                                   *
                                                                                                                                                                                                                                                   * Send your comments, suggestions, and feedback to me@volkan.io
                                                                                                                                                                                                                                                   */

var _log = require('../log');

var _fs = require('fs');

var readFile = function readFile(path) {
    var isJson = arguments.length <= 1 || arguments[1] === undefined ? true : arguments[1];
    var seed = arguments[2];
    return new Promise(function (resolve, reject) {
        return (0, _fs.readFile)(path, { encoding: 'utf8' }, function (err, data) {
            if (err) {
                if (err.code === 'ENOENT') {
                    (0, _log.error)('File does not exist');
                    (0, _log.info)('Please create ' + path);
                }

                reject(err);

                return;
            }

            if (data.trim() === '') {
                resolve(seed);

                return;
            }

            resolve(isJson ? JSON.parse(data) : ('' + data).trim());
        });
    });
};

var writeFile = function writeFile(path, data) {
    var isJson = arguments.length <= 2 || arguments[2] === undefined ? true : arguments[2];
    return new Promise(function (resolve, reject) {
        return (0, _fs.writeFile)(path, (isJson && (typeof data === 'undefined' ? 'undefined' : _typeof(data)) === 'object' ? JSON.stringify(data) : data).trim(), { encoding: 'utf8' }, function (err) {
            if (err) {
                (0, _log.error)('Unable to write to path: “' + path + '”.');
                reject(err);

                return;
            }

            resolve(data);
        });
    });
};

exports.readFile = readFile;
exports.writeFile = writeFile;