'use strict';

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }(); /*   _______________
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          *  |.-------------.|
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          *  ||~$[byte-sized||
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          *  ||   .tv]>     ||
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          * _|-_____________-|_
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          * \_________________/
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          *
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          * This project is a part of the “Byte-Sized JavaScript” videocast.
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          *
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          * You can watch “Byte-Sized JavaScript” at: https://bit.ly/bytesized
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          *
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          * MIT Licensed — See LICENSE.md
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          *
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          * Send your comments, suggestions, and feedback to me@volkan.io
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          */

var _youtube = require('./provider/youtube');

var _io = require('./io');

var _log = require('./log');

var run = function run() {
    return Promise.all([(0, _io.fetchVideosFromCache)(), (0, _io.fetchLastUpdateTimestamp)()]).then(function (_ref) {
        var _ref2 = _slicedToArray(_ref, 2);

        var videos = _ref2[0];
        var timestamp = _ref2[1];
        return (0, _youtube.getVideos)(timestamp).then(function (newVideos) {
            return { existingVideos: videos, newVideos: newVideos };
        });
    }).then(function (_ref3) {
        var existingVideos = _ref3.existingVideos;
        var newVideos = _ref3.newVideos;

        var promises = [];
        var videos = existingVideos.map(function (x) {
            return x;
        });

        newVideos.forEach(function (video) {
            return promises.push((0, _youtube.getVideo)(video.id.videoId));
        });

        Promise.all(promises).then(function (results) {
            results.forEach(function (result) {
                return videos.push(result.items[0]);
            });

            var tags = {};

            videos.forEach(function (video) {
                video.snippet.tags.forEach(function (tag) {
                    tags[tag] = tags[tag] || {};
                    tags[tag][video.id] = video;
                });
            });

            return Promise.all([(0, _io.persistVideos)(videos), (0, _io.persistTags)(tags), (0, _io.persistTimestamp)()]);
        });
    }).catch(function (reason) {
        (0, _log.info)('Oh poop!');
        (0, _log.error)(reason);
    });
};

run();