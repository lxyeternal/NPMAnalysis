'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getVideo = exports.getVideos = undefined;

var _config = require('../../config');

var _request = require('request');

var _request2 = _interopRequireDefault(_request);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*   _______________
 *  |.-------------.|
 *  ||~$[byte-sized||
 *  ||   .tv]>     ||
 * _|-_____________-|_
 * \_________________/
 *
 * This project is a part of the “Byte-Sized JavaScript” videocast.
 *
 * You can watch “Byte-Sized JavaScript” at: https://bit.ly/bytesized
 *
 * MIT Licensed — See LICENSE.md
 *
 * Send your comments, suggestions, and feedback to me@volkan.io
 */

var url = {
    videosUrl: function videosUrl(token, timestamp) {
        return '' + _config.api.ROOT + '/search?part=snippet' + ('&channelId=' + _config.api.CHANNEL_ID) + '&fields=items/id,nextPageToken' + '&order=date' + ('&pageToken=' + (token || '')) + ('&publishedAfter=' + timestamp.trim()) + ('&key=' + _config.api.KEY);
    },

    videoUrl: function videoUrl(videoId) {
        return _config.api.ROOT + '/videos?key=' + _config.api.KEY + '&part=snippet&id=' + videoId;
    }
};

var getVideosSince = function getVideosSince(timestamp) {
    var token = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];
    var accumulator = arguments.length <= 2 || arguments[2] === undefined ? [] : arguments[2];
    return new Promise(function (resolve, reject) {
        return (0, _request2.default)(url.videosUrl(token, timestamp), function (error, response, body) {
            if (error) {
                reject(error);

                return;
            }

            var videos = JSON.parse(body);

            if (!videos || !videos.items) {
                resolve([]);

                return;
            }

            var items = videos.items.filter(function (item) {
                return item.id.kind === 'youtube#video';
            });

            accumulator = accumulator.concat(items);

            if (videos.nextPageToken) {
                resolve(getVideosSince(timestamp, videos.nextPageToken, accumulator));

                return;
            }

            resolve(accumulator);
        });
    });
};

var getVideo = function getVideo(videoId) {
    return new Promise(function (resolve, reject) {
        return (0, _request2.default)(url.videoUrl(videoId), function (error, response, body) {
            if (error) {
                reject(error);

                return;
            }

            resolve(JSON.parse(body));
        });
    });
};

var getVideos = function getVideos(sinceWhen) {
    return getVideosSince(sinceWhen);
};

exports.getVideos = getVideos;
exports.getVideo = getVideo;