# bytesized.tv
Byte-Sized JavaScript Website

00) write mocha tests for youtube api.
Use nock for youtube responses: https://github.com/node-nock/nock
(what are the disadvantages; versus advantages: advantage makes tests reliable and deterministic)
01)

Create a universal hello-world app.
1) create a App react component
2) save the rendered output as HTML
3) whenever a new video is published, that html should be rerendered too.

universal app:
https://github.com/DavidWells/isomorphic-react-example


later:
- test backend methods using Mocha (the json generators and stuff)
- test front-end components using Karma and mocha

TODO:
1. Generate an index.html from videos.json that lists the videos embeds a player etc.
it should also have dynamic functionality:

- tapping a specific tag will show only the videos related to that tag.
- the page will display all videos with thumbnails and a play icon which will dynamically start the play / embed youtube player etc.
- add sorting for fun: sort by date created, popularity, alphabetically