#!/usr/bin/env bash
export YOUTUBE_API_KEY=AIzaSyDFZ-lOsCogOSLWn58-0Hk6d8o_sAg4rjc
