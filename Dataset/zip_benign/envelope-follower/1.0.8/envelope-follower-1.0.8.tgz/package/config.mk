USER = bot
SERVER = smallcatlabs
APPDIR = /usr/share/nginx/html/jimkang.com/envelope-follower
