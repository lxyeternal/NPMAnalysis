import { BaseAnimation } from "./base-animation";
export declare class Loop extends BaseAnimation {
    private readonly interval;
    private readonly callback;
    private nextCall;
    private readonly initialDelay;
    constructor(interval: number, callback: () => void, initialDelay?: number);
    reversed(): BaseAnimation;
    cycle(elapsed: number): void;
    set duration(duration: number);
    get duration(): number;
}
