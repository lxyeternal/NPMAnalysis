import { BaseAnimation } from "./base-animation";
export declare class DynamicTimeline extends BaseAnimation {
    duration: number;
    private readonly buildFunc;
    private built;
    constructor(duration: number, buildFunc: () => BaseAnimation);
    reversed(): BaseAnimation;
    cycle(elapsed: number): void;
    skip(): void;
    get size(): number;
    get finished(): boolean;
}
