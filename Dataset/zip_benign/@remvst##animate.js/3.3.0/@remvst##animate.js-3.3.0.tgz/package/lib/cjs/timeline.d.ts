import { BaseAnimation } from "./base-animation";
export declare class Timeline extends BaseAnimation {
    private readonly children;
    private readonly runningChildren;
    private _duration;
    private readonly breakpoints;
    reversed(): BaseAnimation;
    addBreakpointAt(time: number): this;
    addBreakpoint(): this;
    append(animation: BaseAnimation | (() => void)): this;
    add(delay: number, animation: BaseAnimation | (() => void)): this;
    wait(delay: number): this;
    cycle(elapsed: number): void;
    private startChild;
    skip(): this;
    cancel(): void;
    set duration(duration: number);
    get duration(): number;
    get size(): number;
    get finished(): boolean;
}
