import { BaseAnimation } from "./base-animation";
export declare class InterpolationPool {
    private _interpolations;
    private _mainTimeline;
    cycle(elapsed: number): void;
    add(interpolation: BaseAnimation): void;
    skip(): void;
    delay(delay: number, animation: BaseAnimation | (() => void)): void;
    setMainTimeline(timeline: BaseAnimation): void;
    clear(): void;
    get size(): number;
}
