import { InterpolationPool } from "./interpolation-pool";
export type OnCycleCallback = (elapsed: number) => void;
export declare abstract class BaseAnimation {
    protected cancelled: boolean;
    elapsed: number;
    protected actualElapsed: number;
    protected _onCycle: OnCycleCallback;
    get finished(): boolean;
    skip(): void;
    cancel(): void;
    onCycle(func: OnCycleCallback): this;
    onProgress(func: OnCycleCallback): this;
    run(pool: InterpolationPool): this;
    runAsMain(pool: InterpolationPool): this;
    cycle(elapsed: number): void;
    abstract get duration(): number;
    abstract set duration(duration: number);
    get size(): number;
    abstract reversed(): BaseAnimation;
}
