import { BaseAnimation } from "./base-animation";
export declare class Action extends BaseAnimation {
    private readonly callback;
    private called;
    constructor(callback: () => void);
    cycle(elapsed: number): void;
    get finished(): boolean;
    get duration(): number;
    set duration(duration: number);
    reversed(): BaseAnimation;
}
