declare module 'optimization-js';
