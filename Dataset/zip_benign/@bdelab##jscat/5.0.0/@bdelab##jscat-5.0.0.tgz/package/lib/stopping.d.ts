import { Cat } from './cat';
import { CatMap } from './type';
/**
 * Interface for input parameters to EarlyStopping classes.
 */
export interface EarlyStoppingInput {
    /** The logical operation to use to evaluate multiple stopping conditions */
    logicalOperation?: 'and' | 'or' | 'only' | 'AND' | 'OR' | 'ONLY';
}
export interface StopAfterNItemsInput extends EarlyStoppingInput {
    /** Number of items to require before stopping */
    requiredItems: CatMap<number>;
}
export interface StopOnSEMeasurementPlateauInput extends EarlyStoppingInput {
    /** Number of items to wait for before triggering early stopping */
    patience: CatMap<number>;
    /** Tolerance for standard error of measurement drop */
    tolerance?: CatMap<number>;
}
export interface StopIfSEMeasurementBelowThresholdInput extends EarlyStoppingInput {
    /** Stop if the standard error of measurement drops below this level */
    seMeasurementThreshold: CatMap<number>;
    /** Number of items to wait for before triggering early stopping */
    patience?: CatMap<number>;
    /** Tolerance for standard error of measurement drop */
    tolerance?: CatMap<number>;
}
/**
 * Abstract class for early stopping strategies.
 */
export declare abstract class EarlyStopping {
    protected _earlyStop: boolean;
    protected _nItems: CatMap<number>;
    protected _seMeasurements: CatMap<number[]>;
    protected _logicalOperation: 'and' | 'or' | 'only';
    constructor({ logicalOperation }: EarlyStoppingInput);
    abstract get evaluationCats(): string[];
    get earlyStop(): boolean;
    get nItems(): CatMap<number>;
    get seMeasurements(): CatMap<number[]>;
    get logicalOperation(): "and" | "or" | "only";
    /**
     * Update the internal state of the early stopping strategy based on the provided cats.
     * @param {CatMap<Cat>}cats - A map of cats to update.
     */
    protected _updateCats(cats: CatMap<Cat>): void;
    /**
     * Abstract method to be implemented by subclasses to evaluate a single stopping condition.
     * @param {string} catToEvaluate - The name of the cat to evaluate for early stopping.
     */
    protected abstract _evaluateStoppingCondition(catToEvaluate: string): boolean;
    /**
     * Abstract method to be implemented by subclasses to update the early stopping strategy.
     * @param {CatMap<Cat>} cats - A map of cats to update.
     */
    update(cats: CatMap<Cat>, catToSelect?: string): void;
}
/**
 * Class implementing early stopping based on a plateau in standard error of measurement.
 */
export declare class StopOnSEMeasurementPlateau extends EarlyStopping {
    protected _patience: CatMap<number>;
    protected _tolerance: CatMap<number>;
    constructor(input: StopOnSEMeasurementPlateauInput);
    get evaluationCats(): string[];
    get patience(): CatMap<number>;
    get tolerance(): CatMap<number>;
    protected _evaluateStoppingCondition(catToEvaluate: string): boolean;
}
/**
 * Class implementing early stopping after a certain number of items.
 */
export declare class StopAfterNItems extends EarlyStopping {
    protected _requiredItems: CatMap<number>;
    constructor(input: StopAfterNItemsInput);
    get requiredItems(): CatMap<number>;
    get evaluationCats(): string[];
    protected _evaluateStoppingCondition(catToEvaluate: string): boolean;
}
/**
 * Class implementing early stopping if the standard error of measurement drops below a certain threshold.
 */
export declare class StopIfSEMeasurementBelowThreshold extends EarlyStopping {
    protected _patience: CatMap<number>;
    protected _tolerance: CatMap<number>;
    protected _seMeasurementThreshold: CatMap<number>;
    constructor(input: StopIfSEMeasurementBelowThresholdInput);
    get patience(): CatMap<number>;
    get tolerance(): CatMap<number>;
    get seMeasurementThreshold(): CatMap<number>;
    get evaluationCats(): string[];
    protected _evaluateStoppingCondition(catToEvaluate: string): boolean;
}
