export declare type ZetaSymbolic = {
    a: number;
    b: number;
    c: number;
    d: number;
};
export interface Zeta {
    a?: number;
    b?: number;
    c?: number;
    d?: number;
    discrimination?: number;
    difficulty?: number;
    guessing?: number;
    slipping?: number;
}
export interface Stimulus extends Zeta {
    [key: string]: any;
}
export declare type ZetaCatMap = {
    cats: string[];
    zeta: Zeta;
};
export interface MultiZetaStimulus {
    zetas: ZetaCatMap[];
    [key: string]: any;
}
export declare type CatMap<T> = {
    [name: string]: T;
};
