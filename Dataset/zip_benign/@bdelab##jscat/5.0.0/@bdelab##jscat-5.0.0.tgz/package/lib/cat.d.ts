import { Stimulus, Zeta } from './type';
export interface CatInput {
    method?: string;
    itemSelect?: string;
    nStartItems?: number;
    startSelect?: string;
    theta?: number;
    minTheta?: number;
    maxTheta?: number;
    prior?: number[][];
    randomSeed?: string | null;
}
export declare class Cat {
    method: string;
    itemSelect: string;
    minTheta: number;
    maxTheta: number;
    prior: number[][];
    private readonly _zetas;
    private readonly _resps;
    private _theta;
    private _seMeasurement;
    nStartItems: number;
    startSelect: string;
    private readonly _rng;
    /**
     * Create a Cat object. This expects an single object parameter with the following keys
     * @param {{method: string, itemSelect: string, nStartItems: number, startSelect:string, theta: number, minTheta: number, maxTheta: number, prior: number[][]}=} destructuredParam
     *     method: ability estimator, e.g. MLE or EAP, default = 'MLE'
     *     itemSelect: the method of item selection, e.g. "MFI", "random", "closest", default method = 'MFI'
     *     nStartItems: first n trials to keep non-adaptive selection
     *     startSelect: rule to select first n trials
     *     theta: initial theta estimate
     *     minTheta: lower bound of theta
     *     maxTheta: higher bound of theta
     *     prior:  the prior distribution
     *     randomSeed: set a random seed to trace the simulation
     */
    constructor({ method, itemSelect, nStartItems, startSelect, theta, minTheta, maxTheta, prior, randomSeed, }?: CatInput);
    get theta(): number;
    get seMeasurement(): number;
    /**
     * Return the number of items that have been observed so far.
     */
    get nItems(): number;
    get resps(): (0 | 1)[];
    get zetas(): Zeta[];
    private static validateMethod;
    private static validateItemSelect;
    private static validateStartSelect;
    /**
     * use previous response patterns and item params to calculate the estimate ability based on a defined method
     * @param zeta - last item param
     * @param answer - last response pattern
     * @param method
     */
    updateAbilityEstimate(zeta: Zeta | Zeta[], answer: (0 | 1) | (0 | 1)[], method?: string): void;
    private estimateAbilityEAP;
    private estimateAbilityMLE;
    private negLikelihood;
    private likelihood;
    /**
     * calculate the standard error of ability estimation
     */
    private calculateSE;
    /**
     * find the next available item from an input array of stimuli based on a selection method
     *
     * remainingStimuli is sorted by fisher information to reduce the computation complexity for future item selection
     * @param stimuli - an array of stimulus
     * @param itemSelect - the item selection method
     * @param deepCopy - default deepCopy = true
     * @returns {nextStimulus: Stimulus, remainingStimuli: Array<Stimulus>}
     */
    findNextItem(stimuli: Stimulus[], itemSelect?: string, deepCopy?: boolean): {
        nextStimulus: Stimulus | undefined;
        remainingStimuli: Stimulus[];
    };
    private selectorMFI;
    private selectorMiddle;
    private selectorClosest;
    private selectorRandom;
    /**
     * Picks the next item in line from the given list of stimuli.
     * It grabs the first item from the list, removes it, and then returns it along with the rest of the list.
     *
     * @param arr - The list of stimuli to choose from.
     * @returns {Object} - An object with the next item and the updated list.
     * @returns {Stimulus} return.nextStimulus - The item that was picked from the list.
     * @returns {Stimulus[]} return.remainingStimuli - The list of what's left after picking the item.
     */
    private selectorFixed;
    /**
     * return a random integer between min and max
     * @param min - The minimum of the random number range (include)
     * @param max - The maximum of the random number range (include)
     * @returns {number} - random integer within the range
     */
    private randomInteger;
}
