import { Observable } from 'rxjs';
import { getTestScheduler } from './scheduler';
import { TestScheduler } from 'rxjs/testing';
import { HotObservable } from 'rxjs/internal/testing/HotObservable';
import { ColdObservable } from 'rxjs/internal/testing/ColdObservable';
export class TestColdObservable extends Observable {
    constructor(marbles, values, error) {
        super();
        this.marbles = marbles;
        this.values = values;
        this.error = error;
        const scheduler = getTestScheduler();
        const messages = TestScheduler.parseMarbles(marbles, values, error, undefined, true);
        const cold = new ColdObservable(messages, scheduler);
        this.source = cold;
        scheduler.coldObservables.push(cold);
    }
    getSubscriptions() {
        return this.source['subscriptions'];
    }
}
export class TestHotObservable extends Observable {
    constructor(marbles, values, error) {
        super();
        this.marbles = marbles;
        this.values = values;
        this.error = error;
        const scheduler = getTestScheduler();
        const messages = TestScheduler.parseMarbles(marbles, values, error, undefined, true);
        const hot = new HotObservable(messages, scheduler);
        this.source = hot;
        scheduler.hotObservables.push(hot);
    }
    getSubscriptions() {
        return this.source['subscriptions'];
    }
}
//# sourceMappingURL=test-observables.js.map