import {
  AddressLookupTableAccount,
  type BlockhashWithExpiryBlockHeight,
  Connection,
  PublicKey,
  type TransactionError,
  TransactionExpiredBlockheightExceededError,
  TransactionMessage,
  VersionedTransaction,
} from '@solana/web3.js';
import axios, { type AxiosRequestConfig } from 'axios';
import bs58 from 'bs58';
import type { SimulateBundleOptions, SimulateBundleResponse } from '../types/index.js';
import { compareAddresses } from '../utils/address.js';
import { getSolanaProvider } from '../utils/rpc.js';
import { RPCS, SOLANA_CHAIN_ID } from '../config/chains.js';

type TransactionSenderAndConfirmationWaiterArgs = {
  connection: Connection;
  serializedTransaction: Buffer;
  blockhashWithExpiryBlockHeight?: BlockhashWithExpiryBlockHeight;
};

const SEND_OPTIONS = { skipPreflight: true };
const MAX_RETRIES = 20;
const RETRY_DELAY = 200; // 200ms
export const SLIPPAGE_ERROR_CODE = 6001;
type SolanaError =
  | { InstructionError: [number, { Custom?: number }] } //
  | string
  | TransactionError
  | null;
type ConfirmResult = {
  success: boolean;
  error?: string;
  isTimeout?: boolean;
  slot?: number;
  transactionResponse?: {
    transactionHash: string;
    slot: number;
  };
};

export const sendTransactionUsingJito = async (transactionBase64: string): Promise<string> => {
  try {
    console.log('Sending transaction to Jito via backend proxy...');

    const response = await axios.post(`/api/jito/transaction`, {
      transaction: transactionBase64,
    });

    if (!response.data || response.data.error) {
      console.error('>>> JITO ERROR', response.data?.error);
      throw new Error('Jito sendTransaction request failed');
    }

    console.log('>>> JITO RESULT', response.data.result);
    return response.data.result;
  } catch (error) {
    console.error('Error in sendTransactionUsingJito:', error);
    throw error;
  }
};
export const sendBundleUsingJito = async (transactionBase64Array: string[]) => {
  try {
    console.log('Sending bundle to Jito via backend proxy...');

    const response = await axios.post(`/api/jito/bundle`, {
      transactions: transactionBase64Array,
    });

    if (!response.data || response.data.error) {
      throw new Error('Jito sendBundle request failed');
    }

    return response.data.result;
  } catch (error) {
    console.error('Error in sendBundleUsingJito:', error);
    throw error;
  }
};
export function isValidSolanaSignature(signature: string): boolean {
  try {
    // Check if the signature is a string
    if (typeof signature !== 'string') {
      return false;
    }

    // Decode the base58 string
    const decoded = bs58.decode(signature);

    // Solana signatures are always 64 bytes (512 bits) long
    return decoded.length === 64;
  } catch (error: unknown) {
    console.log({ error });
    return false;
  }
}
export const confirmTransaction = async (
  transactionHash: string,
  options: {
    maxRetries?: number;
    commitment?: 'processed' | 'confirmed' | 'finalized';
    checkInterval?: number;
  } = {},
): Promise<ConfirmResult> => {
  const { maxRetries = 10, commitment = 'confirmed', checkInterval = 200 } = options;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      if (attempt === 0) {
        await new Promise((resolve) => setTimeout(resolve, 2000));
      }
      const solanaProvider = await getSolanaProvider();

      const status = await solanaProvider.getSignatureStatus(transactionHash);

      if (!status?.value) {
        console.log('Transaction status check: Transaction not found, retrying...');
        await new Promise((resolve) => setTimeout(resolve, checkInterval));
        continue;
      }

      if (status.value.err) {
        const errorDetails = status.value.err;
        return {
          success: false,
          error: parseInstructionError(errorDetails as SolanaError),
          slot: status.context.slot,
        };
      }

      const confirmationLevel = status.value.confirmationStatus ?? 'unknown';
      if (!['processed', 'confirmed', 'finalized'].includes(confirmationLevel)) {
        console.warn(`Unknown confirmation level: ${confirmationLevel}`);
        continue;
      }

      const isConfirmed =
        (commitment === 'processed' && confirmationLevel !== 'unknown') ||
        (commitment === 'confirmed' && ['confirmed', 'finalized'].includes(confirmationLevel)) ||
        (commitment === 'finalized' && confirmationLevel === 'finalized');

      if (isConfirmed) {
        return {
          success: true,
          transactionResponse: {
            transactionHash,
            slot: status.context.slot,
          },
        };
      }

      console.warn(`Attempt ${attempt + 1} waiting for ${commitment} confirmation`);

      const backoffTime = Math.min(1000 * Math.pow(2, attempt), 10000);
      await new Promise((resolve) => setTimeout(resolve, backoffTime));
    } catch (error) {
      console.warn(`Attempt ${attempt + 1} failed:`, error);

      if (attempt >= maxRetries - 1) {
        return {
          success: false,
          error: error instanceof Error ? error.message : 'Unknown error',
        };
      }
    }
  }

  return {
    success: false,
    error: 'Max retries exceeded',
    isTimeout: true,
  };
};

export const parseInstructionError = (err: SolanaError): string => {
  try {
    if (err && typeof err === 'object' && 'InstructionError' in err && Array.isArray(err.InstructionError)) {
      const [index, details] = err.InstructionError;

      // Check for slippage tolerance error
      if (index === 1 && details?.Custom === SLIPPAGE_ERROR_CODE) {
        return 'Slippage tolerance exceeded';
      }
    }
    return JSON.stringify(err);
  } catch (error) {
    return 'Unknown instruction error';
  }
};
export async function checkTransactionConfirmation(
  signature: string,
  maxAttempts = 100,
  initialDelay = 500,
): Promise<boolean> {
  let delay = initialDelay;
  let consecutiveErrors = 0;
  const MAX_CONSECUTIVE_ERRORS = 3;
  const solanaProvider = await getSolanaProvider();
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const { value: status } = await solanaProvider.getSignatureStatus(signature, {
        searchTransactionHistory: true,
      });

      // Reset consecutive errors on successful RPC call
      consecutiveErrors = 0;

      if (status?.err) {
        console.error(`Transaction failed: ${JSON.stringify(status.err)}`);
        return false;
      }

      if (status?.confirmationStatus === 'confirmed' || status?.confirmationStatus === 'finalized') {
        console.log(`Transaction confirmed (${status.confirmationStatus}): ${signature}`);
        return true;
      }

      if (attempt % 5 === 0) {
        console.log(`Attempt ${attempt}/${maxAttempts}: Transaction pending...`);
      }

      const jitter = Math.random() * 100;
      await wait(delay + jitter);
      delay = Math.min(delay * 1.5, 500);
    } catch (error) {
      consecutiveErrors++;

      if (consecutiveErrors >= MAX_CONSECUTIVE_ERRORS) {
        console.error(`Too many consecutive errors (${consecutiveErrors}), aborting confirmation check`);
        return false;
      }

      if (isRetryableError(error)) {
        console.warn(`Attempt ${attempt}: Retryable error, continuing...`, error);
        await wait(delay * 2); // Double delay on errors
        continue;
      }

      console.error(`Unexpected error during confirmation check:`, error);
    }
  }

  console.error(`Transaction confirmation timeout after ${maxAttempts} attempts: ${signature}`);
  return false;
}
const RPC_ERROR_CODES = {
  SERVICE_UNAVAILABLE: 503,
  RATE_LIMITED: 429,
  BAD_GATEWAY: 502,
};
const isRetryableError = (error: unknown): boolean => {
  if (error instanceof Error) {
    // Check for specific error codes in the error message
    const statusCode = error.message.match(/(\d{3})/)?.[1];
    if (statusCode) {
      return [RPC_ERROR_CODES.SERVICE_UNAVAILABLE, RPC_ERROR_CODES.RATE_LIMITED, RPC_ERROR_CODES.BAD_GATEWAY].includes(
        Number(statusCode),
      );
    }
    // Check for common network error messages
    return (
      error.message.includes('Service Unavailable') ||
      error.message.includes('Failed to fetch') ||
      error.message.includes('network error') ||
      error.message.includes('timeout')
    );
  }
  return false;
};

export const wait = (time: number) => new Promise((resolve) => setTimeout(resolve, time));

export async function transactionSenderAndConfirmationWaiter({
  connection,
  serializedTransaction,
}: TransactionSenderAndConfirmationWaiterArgs): Promise<string | null> {
  for (let attempt = 0; attempt < MAX_RETRIES; attempt++) {
    try {
      const txid = await connection.sendRawTransaction(serializedTransaction, SEND_OPTIONS);
      const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash();
      const controller = new AbortController();
      const abortSignal = controller.signal;

      // Start resending in parallel, abortable when confirmed
      const abortableResender = async () => {
        let attempts = 0;
        const maxAttempts = 2;
        while (!abortSignal.aborted && attempts < maxAttempts) {
          await wait(200); // Adjust this dynamically if needed
          try {
            await connection.sendRawTransaction(serializedTransaction, SEND_OPTIONS);
            console.log(`Transaction resent for txid: ${txid}`);
          } catch (e) {
            if (e instanceof Error) {
              console.warn(`Failed to resend transaction: ${e.message}`);
            } else {
              console.warn(`Failed to resend transaction:`, e);
            }
          }
          attempts++;
        }
      };

      await abortableResender();

      // Check confirmation and status concurrently
      const confirmationPromise = connection.confirmTransaction(
        { signature: txid, blockhash, lastValidBlockHeight },
        'processed',
      );

      const statusCheckerPromise = (async () => {
        let attempts = 0;
        const maxAttempts = 10;
        while (!abortSignal.aborted && attempts < maxAttempts) {
          await wait(200);
          const txStatus = await connection.getSignatureStatus(txid, {
            searchTransactionHistory: false,
          });
          if (txStatus?.value?.confirmationStatus === 'confirmed') {
            console.log(`Transaction confirmed for txid: ${txid}`);
            controller.abort(); // Stop resending immediately
            return;
          }
          attempts++;
        }
      })();

      // Use Promise.race to resolve faster between confirmation and status checking
      await Promise.race([confirmationPromise, statusCheckerPromise]);

      // Verify transaction confirmation and return txid if successful
      const transactionConfirmed = await checkTransactionConfirmation(txid);
      if (transactionConfirmed) return txid;

      console.error('Failed to get transaction after multiple attempts');
      return null;
    } catch (e) {
      if (e instanceof TransactionExpiredBlockheightExceededError) {
        console.warn(`Transaction expired on attempt ${attempt + 1}. Retrying...`);
        if (attempt < MAX_RETRIES - 1) {
          await wait(RETRY_DELAY);
          continue;
        }
        console.error('Max retries reached. Transaction repeatedly expired.');
        return null;
      }

      // Handle retryable RPC errors
      if (isRetryableError(e)) {
        const backoffDelay = Math.min(RETRY_DELAY * Math.pow(2, attempt), 5000); // Exponential backoff capped at 5s
        console.warn(`RPC error on attempt ${attempt + 1}, retrying in ${backoffDelay}ms:`, e);
        if (attempt < MAX_RETRIES - 1) {
          await wait(backoffDelay);
          continue;
        }
      }

      console.error('Error confirming transaction:', e);
    }
  }
  return null;
}

export const WRAPPED_SOL_MINT = 'So11111111111111111111111111111111111111112';
export const NATIVE_SOL_MINT = 'So11111111111111111111111111111111111111111';

export const getNormalizedSolanaToken = (address: string): string => {
  return compareAddresses(address, NATIVE_SOL_MINT) ? WRAPPED_SOL_MINT : address;
};

export interface SimulationResult {
  preBalances?: Record<string, bigint>;
  postBalances?: Record<string, bigint>;
  success: boolean;
}

export async function simulateBundle({ encodedTransactions }: SimulateBundleOptions): Promise<SimulationResult | null> {
  const endpoint = RPCS[SOLANA_CHAIN_ID]?.rpc[0];
  if (!endpoint) {
    throw new Error('JITO_RPC Missing for simulateBundle');
  }

  const config: AxiosRequestConfig = {
    headers: {
      'Content-Type': 'application/json',
    },
  };

  const data = {
    jsonrpc: '2.0',
    id: 1,
    method: 'simulateBundle',
    params: [
      {
        encodedTransactions,
        config: {
          sigVerify: false,
          replaceRecentBlockhash: true,
          commitment: 'confirmed',
        },
      },
    ],
  };

  try {
    const response = await axios.post<SimulateBundleResponse>(endpoint, data, config);

    console.log('response', response.data);
    if (!response.data?.result?.value) {
      return null;
    }

    const result: any = response.data.result.value;

    // Extract pre and post balances from accounts
    const preBalances: Record<string, bigint> = {};
    const postBalances: Record<string, bigint> = {};

    if (result.preTokenBalances) {
      result.preTokenBalances.forEach((balance: any) => {
        if (balance?.account && balance?.uiTokenAmount?.amount) {
          preBalances[balance.account] = BigInt(balance.uiTokenAmount.amount);
        }
      });
    }

    if (result.postTokenBalances) {
      result.postTokenBalances.forEach((balance: any) => {
        if (balance?.account && balance?.uiTokenAmount?.amount) {
          postBalances[balance.account] = BigInt(balance.uiTokenAmount.amount);
        }
      });
    }

    // Also include SOL balances if available
    if (result.preBalances) {
      Object.entries(result.preBalances).forEach(([address, balance]: [string, any]) => {
        preBalances[address] = BigInt(balance);
      });
    }

    if (result.postBalances) {
      Object.entries(result.postBalances).forEach(([address, balance]: [string, any]) => {
        postBalances[address] = BigInt(balance);
      });
    }

    return {
      success: result.summary === 'succeeded',
      preBalances,
      postBalances,
    };
  } catch (error) {
    console.error('Error simulating bundle:', error);
    return null;
  }
}

export async function processTransactionsWithFeePayer(
  input: { data: string }[] | VersionedTransaction,
  connection: Connection,
  senderAddressString: string,
  feePayerAddressString: string,
): Promise<VersionedTransaction[]> {
  const senderAddress = new PublicKey(senderAddressString);
  const feePayerAddress = new PublicKey(feePayerAddressString);
  const transactions: VersionedTransaction[] = [];

  async function processSingleTransaction(tx: VersionedTransaction): Promise<VersionedTransaction> {
    // Resolve any address lookup tables.
    const addressTableLookups = tx.message.addressTableLookups;
    const lookupTableAccounts: AddressLookupTableAccount[] =
      addressTableLookups.length > 0
        ? await Promise.all(
            addressTableLookups.map(async (lookup) => {
              const response = await connection.getAccountInfo(lookup.accountKey);
              if (response === null) {
                throw new Error(`Address lookup table account not found: ${lookup.accountKey.toBase58()}`);
              }
              return new AddressLookupTableAccount({
                key: lookup.accountKey,
                state: AddressLookupTableAccount.deserialize(response.data),
              });
            }),
          )
        : [];

    // Decompile the transaction message.
    const message = TransactionMessage.decompile(tx.message, {
      addressLookupTableAccounts: lookupTableAccounts,
    });
    // Override fee payer instructions.
    overrideFeePayerInMsgInstructions(message, senderAddress, feePayerAddress);
    // Set the payer key to fee payer.
    message.payerKey = feePayerAddress;
    // Update the blockhash.
    const { blockhash } = await connection.getLatestBlockhash();
    message.recentBlockhash = blockhash;
    // Recompile the message.
    const compiledMessage = message.compileToV0Message(lookupTableAccounts);
    return new VersionedTransaction(compiledMessage);
  }

  if (Array.isArray(input)) {
    // Process an array of calldatas.
    for (const calldata of input) {
      const messageBuffer = Buffer.from(calldata.data, 'base64');
      const originalTransaction = VersionedTransaction.deserialize(messageBuffer);
      const newTx = await processSingleTransaction(originalTransaction);
      transactions.push(newTx);
    }
  } else {
    // Input is a single VersionedTransaction.
    const newTx = await processSingleTransaction(input);
    transactions.push(newTx);
  }

  return transactions;
}

function overrideFeePayerInMsgInstructions(
  message: TransactionMessage,
  senderAddress: PublicKey,
  feePayerAddress: PublicKey,
): void {
  const SYSTEM_PROGRAM_ID = new PublicKey('11111111111111111111111111111111');
  const ATA_PROGRAM_ID = new PublicKey('ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL');

  message.instructions = message.instructions.map((instruction) => {
    // For System Program instructions (e.g. Jito tip)
    if (instruction.programId.equals(SYSTEM_PROGRAM_ID)) {
      instruction.keys = instruction.keys.map((key, index) => {
        if (index === 0 && key.isSigner && key.pubkey.equals(senderAddress)) {
          return { ...key, pubkey: feePayerAddress };
        }
        return key;
      });
    }
    // For ATA creation instructions
    if (instruction.programId.equals(ATA_PROGRAM_ID)) {
      instruction.keys = instruction.keys.map((key, index) => {
        if (index === 0 && key.isSigner && key.pubkey.equals(senderAddress)) {
          return { ...key, pubkey: feePayerAddress };
        }
        return key;
      });
    }
    return instruction;
  });
}
