import axios, { AxiosError } from 'axios';
import { isSolanaChain } from '../config/chains.js';
import type { QuoteTypes } from '../types/index.js';
import type { QuoteParams } from '../utils/quote.js';
import { processSolana } from './jito.js';

export const getQuote = async (api: { key: string; url: string }, params: QuoteParams, signal?: AbortSignal) => {
  try {
    const { data } = await axios.get<QuoteTypes>(`${api.url}/v2/quote`, {
      params: params,
      headers: {
        'x-api-key': api.key,
      },
      signal,
    });
    if (isSolanaChain(params.srcChain)) {
      return await processSolana(data);
    } else {
      return data;
    }
  } catch (error) {
    if (error instanceof AxiosError) {
      throw Error(error.response?.data.error ?? error);
    }
    return undefined;
  }
};
