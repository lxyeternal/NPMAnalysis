export const ETHEREUM_NETWORK = 'ethereum';
export const BASE_NETWORK = 'base';
export const ARBITRUM_NETWORK = 'arbitrum';
export const SOLANA_NETWORK = 'solana';
export const BSC_NETWORK = 'bsc';
export const BERACHAIN_NETWORK = 'berachain';
export const SONIC_NETWORK = 'sonic';

export const ETHEREUM_CHAIN_ID = 1;
export const ARBITRUM_CHAIN_ID = 42161;
export const BASE_CHAIN_ID = 8453;
export const BSC_CHAIN_ID = 56;
export const BERA_CHAIN_ID = 80094;
export const SOLANA_CHAIN_ID = 7565164;
export const SONIC_CHAIN_ID = 146;

export const SupportedChainIds = [
  ETHEREUM_CHAIN_ID,
  BASE_CHAIN_ID,
  ARBITRUM_CHAIN_ID,
  BSC_CHAIN_ID,
  BERA_CHAIN_ID,
  SOLANA_CHAIN_ID,
  SONIC_CHAIN_ID,
] as const;

export type SupportedChainId = (typeof SupportedChainIds)[number];

export const SOLANA_BRIDGE_FEE_TOKEN = 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'; // USDC

export interface ChainConfig {
  id: number;
  name: string;
  icon: string;
  isEVM: boolean;
  nativeCurrency?: {
    name: string;
    symbol: string;
    decimals: number;
  };
  wrapped?: string;
  symbol: string;
  decimals: number;
}

export const NetworkById: Record<number, SupportedNetwork> = {
  1: ETHEREUM_NETWORK,
  8453: BASE_NETWORK,
  42161: ARBITRUM_NETWORK,
  56: BSC_NETWORK,
  80094: BERACHAIN_NETWORK,
  7565164: SOLANA_NETWORK,
  146: SONIC_NETWORK,
};

export const SupportedNetworks = [
  ETHEREUM_NETWORK,
  BASE_NETWORK,
  ARBITRUM_NETWORK,
  SOLANA_NETWORK,
  BSC_NETWORK,
  BERACHAIN_NETWORK,
  SONIC_NETWORK,
] as const;

export const NetworkIds = Object.keys(NetworkById).map(Number);
export type NetworkId = (typeof NetworkIds)[number];

export enum Networks {
  ETHEREUM = 1,
  ARBITRUM = 42161,
  BASE = 8453,
  BSC = 56,
  SOLANA = 7565164,
  BERACHAIN = 80094,
  SONIC = 146,
}

export type SupportedNetwork = (typeof SupportedNetworks)[number];

export enum CodexNetworks {
  ETHEREUM = 1,
  ARBITRUM = 42161,
  BASE = 8453,
  BSC = 56,
  SOLANA = 1399811149,
  BERACHAIN = 80094,
  SONIC = 146,
}

export const getNetworkId = (network: SupportedNetwork) => {
  const chainMap = {
    [ETHEREUM_NETWORK]: CodexNetworks.ETHEREUM.valueOf(),
    [ARBITRUM_NETWORK]: CodexNetworks.ARBITRUM.valueOf(),
    [BASE_NETWORK]: CodexNetworks.BASE.valueOf(),
    [BSC_NETWORK]: CodexNetworks.BSC.valueOf(),
    [SOLANA_NETWORK]: CodexNetworks.SOLANA.valueOf(),
    [BERACHAIN_NETWORK]: CodexNetworks.BERACHAIN.valueOf(),
    [SONIC_NETWORK]: CodexNetworks.SONIC.valueOf(),
  };
  return chainMap[network]
    ? [chainMap[network]]
    : [
        CodexNetworks.ETHEREUM.valueOf(),
        CodexNetworks.ARBITRUM.valueOf(),
        CodexNetworks.BASE.valueOf(),
        CodexNetworks.BSC.valueOf(),
        CodexNetworks.SOLANA.valueOf(),
        CodexNetworks.BERACHAIN.valueOf(),
        CodexNetworks.SONIC.valueOf(),
      ];
};

export const NATIVE_CURRENCY_EMV = { name: 'Ether', symbol: 'ETH', decimals: 18 };

export const RPCS: { [key: string]: { rpc: string[] } } = {
  1: {
    rpc: [
      'https://cool-cold-arm.quiknode.pro/521ae1daa82040600422f6784102aab64f757b67',
      'https://eth.meowrpc.com',
    ],
  },
  8453: {
    rpc: [
      'https://dimensional-little-mountain.base-mainnet.quiknode.pro/3f8041d253bd98a961432eeb086f98ecd3346812',
      'https://base.blockpi.network/v1/rpc/public',
    ],
  },
  42161: {
    rpc: [
      'https://delicate-newest-cherry.arbitrum-mainnet.quiknode.pro/eed02f9e50b9743314e68dc38827fb6c638cae16',
      'https://arbitrum.meowrpc.com',
      'https://arbitrum.blockpi.network/v1/rpc/public',
    ],
  },
  80094: {
    rpc: [
      'https://fittest-late-tree.bera-mainnet.quiknode.pro/65c85893f5788545a7be46cd442d724e544a8a62',
      'https://rpc.berachain.com',
    ],
  },
  56: {
    rpc: [
      'https://blue-dark-flower.bsc.quiknode.pro/80da84d456b6c2b5840cdf70a85c7d056944c848',
      'https://bsc-dataseed.defibit.io',
      'https://bsc-dataseed.nariox.org',
      'https://bsc.nodereal.io',
    ],
  },
  [SOLANA_CHAIN_ID]: {
    rpc: [
      'https://crimson-convincing-vineyard.solana-mainnet.quiknode.pro/4814e7162e9b4ca1e58593e8da5cfd8dde6dc5c6',
      'https://allys-hpupdc-fast-mainnet.helius-rpc.com',
      'https://damp-morning-sun.solana-mainnet.quiknode.pro/7566b76e796469dc95123d5922ec8420b70ca635',
      'https://api.mainnet-beta.solana.com',
      'https://solana-mainnet.rpc.extrnode.com',
      'https://solana.public-rpc.com',
    ],
  },
  146: {
    rpc: ['https://sonic-mainnet.g.alchemy.com/v2/q_3VoGSx6z9OWEbaQKmWAqreJn4Ngk6M'],
  },
};
// End of Selection
export const CHAIN_CONFIGS: ChainConfig[] = [
  {
    id: 1,
    name: 'Ethereum',
    icon: `/svgs/eth.svg`,
    isEVM: true,
    nativeCurrency: NATIVE_CURRENCY_EMV,
    wrapped: '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2',
    symbol: 'ETH',
    decimals: 18,
  },
  {
    id: 8453,
    name: 'Base',
    icon: `/svgs/eth.svg`,
    isEVM: true,
    nativeCurrency: NATIVE_CURRENCY_EMV,
    wrapped: '0x4200000000000000000000000000000000000006',
    symbol: 'ETH',
    decimals: 18,
  },
  {
    id: 42161,
    name: 'Arbitrum',
    icon: `/svgs/eth.svg`,
    isEVM: true,
    nativeCurrency: NATIVE_CURRENCY_EMV,
    wrapped: '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1',
    symbol: 'ETH',
    decimals: 18,
  },
  {
    id: 80094,
    name: 'Berachain',
    icon: `/svgs/bera.png`,
    isEVM: true,
    nativeCurrency: {
      decimals: 18,
      name: 'BERA Token',
      symbol: 'BERA',
    },
    wrapped: '0x6969696969696969696969696969696969696969', // Using for price calculation for native asset
    symbol: 'BERA',
    decimals: 18,
  },
  {
    id: 56,
    name: 'BSC',
    icon: `/svgs/56.svg`,
    isEVM: true,
    nativeCurrency: {
      decimals: 18,
      name: 'BNB',
      symbol: 'BNB',
    },
    wrapped: '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c', // Using for price calculation for native asset
    symbol: 'BNB',
    decimals: 18,
  },
  {
    id: SOLANA_CHAIN_ID,
    name: 'Solana',
    icon: '/svgs/sol.svg',
    nativeCurrency: {
      name: 'SOLANA',
      symbol: 'SOL',
      decimals: 9,
    },
    isEVM: false,
    wrapped: 'So11111111111111111111111111111111111111112',
    symbol: 'SOL',
    decimals: 9,
  },
  {
    id: 146,
    name: 'Sonic',
    icon: `/svgs/146.svg`,
    isEVM: true,
    nativeCurrency: {
      decimals: 18,
      name: 'Sonic',
      symbol: 'S',
    },
    wrapped: '0x039e2fB66102314Ce7b64Ce5Ce3E5183bc94aD38',
    symbol: 'SONIC',
    decimals: 18,
  },
];

export const SUPPORTED_CHAIN_IDS = CHAIN_CONFIGS.map((chain) => chain.id);
export const EVM_CHAIN_IDS = CHAIN_CONFIGS.filter((chain) => chain.isEVM).map((chain) => chain.id);
export const NON_EVM_CHAIN_IDS = CHAIN_CONFIGS.filter((chain) => !chain.isEVM).map((chain) => chain.id);

export const CHAIN_MAP: Record<number, ChainConfig> = CHAIN_CONFIGS.reduce(
  (acc, chain) => {
    acc[chain.id] = chain;
    return acc;
  },
  {} as Record<number, ChainConfig>,
);

export const isEVMChain = (chainId: number): boolean => {
  return EVM_CHAIN_IDS.includes(chainId);
};

export const isEVMChainExcludingBera = (chainId: number): boolean => {
  return EVM_CHAIN_IDS.some((id) => id !== 80094 && id === chainId);
};

export const isBeraChain = (chainId: number) => {
  return chainId === 80094;
};
export const isSolanaChain = (chainId: number): boolean => {
  return SOLANA_CHAIN_ID === chainId;
};
export const getChainConfig = (chainId: number): ChainConfig | undefined => {
  return CHAIN_MAP[chainId];
};

export const WRAPPED_NATIVE_ADDRESSES = Object.values(CHAIN_MAP).map((chain) => {
  return chain.wrapped?.toLowerCase() || '';
});

export const isWrappedNativeAddress = (tokenAddress: string): boolean => {
  return !!tokenAddress && WRAPPED_NATIVE_ADDRESSES.includes(tokenAddress.toLowerCase());
};

export const getWrappedNativeTokenByChainId = (chainId: SupportedChainId) => {
  return CHAIN_MAP[chainId]?.wrapped;
};
