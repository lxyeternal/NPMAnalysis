import { arbitrum, base, berachain, bsc, mainnet, sonic } from 'viem/chains';
import type { Token } from '../types/index.js';
import { SOLANA_CHAIN_ID } from './chains.js';

export const STABLECOINS: {
  [key: number]: {
    [key: string]: Token;
  };
} = {
  [mainnet.id]: {
    USDC: {
      name: 'USD Coin',
      symbol: 'USDC',
      address: '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48',
      decimals: 6,
      chainId: mainnet.id,
      image: '/svgs/usdc.svg',
    },
    USDT: {
      name: 'Tether USD',
      symbol: 'USDT',
      address: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
      decimals: 6,
      chainId: mainnet.id,
      image: '/svgs/usdt.svg',
    },
    DAI: {
      name: 'Dai Stablecoin',
      symbol: 'DAI',
      address: '0x6b175474e89094c44da98b954eedeac495271d0f',
      decimals: 18,
      chainId: mainnet.id,
      image: '/svgs/dai.svg',
    },
  },
  [base.id]: {
    USDC: {
      name: 'USD Coin',
      symbol: 'USDC',
      address: '0x833589fcd6edb6e08f4c7c32d4f71b54bda02913',
      decimals: 6,
      chainId: base.id,
      image: '/svgs/usdc.svg',
    },
    USDT: {
      name: 'Tether USD',
      symbol: 'USDT',
      address: '0xfde4C96c8593536E31F229EA8f37b2ADa2699bb2',
      decimals: 6,
      chainId: base.id,
      image: '/svgs/usdt.svg',
    },
    DAI: {
      name: 'Dai Stablecoin',
      symbol: 'DAI',
      address: '0x50c5725949a6f0c72e6c4a641f24049a917db0cb',
      decimals: 18,
      chainId: base.id,
      image: '/svgs/dai.svg',
    },
  },
  [arbitrum.id]: {
    USDC: {
      name: 'USD Coin',
      symbol: 'USDC',
      address: '0xaf88d065e77c8cc2239327c5edb3a432268e5831',
      decimals: 6,
      chainId: arbitrum.id,
      image: '/svgs/usdc.svg',
    },
    USDT: {
      name: 'Tether USD',
      symbol: 'USDT',
      address: '0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9',
      decimals: 6,
      chainId: arbitrum.id,
      image: '/svgs/usdt.svg',
    },
    DAI: {
      name: 'Dai Stablecoin',
      symbol: 'DAI',
      address: '0xda10009cbd5d07dd0cecc66161fc93d7c9000da1',
      decimals: 18,
      chainId: arbitrum.id,
      image: '/svgs/dai.svg',
    },
  },
  [bsc.id]: {
    USDC: {
      name: 'USD Coin',
      symbol: 'USDC',
      address: '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d',
      decimals: 18,
      chainId: bsc.id,
      image: '/svgs/usdc.svg',
    },
    USDT: {
      name: 'Tether USD',
      symbol: 'USDT',
      address: '0x55d398326f99059fF775485246999027B3197955',
      decimals: 18,
      chainId: bsc.id,
      image: '/svgs/usdt.svg',
    },
    DAI: {
      name: 'Dai Stablecoin',
      symbol: 'DAI',
      address: '0x1AF3F329e8BE154074D8769D1FFa4eE058B1DBc3',
      decimals: 18,
      chainId: bsc.id,
      image: '/svgs/dai.svg',
    },
  },
  [SOLANA_CHAIN_ID]: {
    USDC: {
      name: 'USD Coin',
      symbol: 'USDC',
      address: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
      decimals: 6,
      chainId: SOLANA_CHAIN_ID,
      image: '/svgs/usdc.svg',
    },
    USDT: {
      name: 'Tether USD',
      symbol: 'USDT',
      address: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
      decimals: 6,
      chainId: SOLANA_CHAIN_ID,
      image: '/svgs/usdt.svg',
    },
  },
  [berachain.id]: {
    USDC: {
      name: 'USD Coin',
      symbol: 'USDC',
      decimals: 6,
      address: '0x549943e04f40284185054145c6E4e9568C1D3241',
      chainId: berachain.id,
      image: '/svgs/usdc.svg',
    },
    HONEY: {
      name: 'Honey',
      symbol: 'HONEY',
      address: '0xfcbd14dc51f0a4d49d5e53c2e0950e0bc26d0dce',
      decimals: 18,
      chainId: berachain.id,
      image: '/tokens/honey.webp',
    },
  },
  [sonic.id]: {
    USDC: {
      name: 'USD Coin',
      symbol: 'USDC',
      address: '0x29219dd400f2Bf60E5a23d13Be72B486D4038894',
      decimals: 6,
      chainId: sonic.id,
      image: '/svgs/usdc.svg',
    },
    USDT: {
      name: 'Tether USD',
      symbol: 'USDT',
      address: '0x6047828dc181963ba44974801FF68e538dA5eaF9',
      decimals: 6,
      chainId: sonic.id,
      image: '/svgs/usdt.svg',
    },
  },
};
