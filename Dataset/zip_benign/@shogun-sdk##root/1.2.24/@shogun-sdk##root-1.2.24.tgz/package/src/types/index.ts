import { NATIVE_TOKEN } from '../utils/address.js';

export type WalletType = 'evm' | 'solana';

export type NativeTokenKey = keyof typeof NATIVE_TOKEN;

export interface QuoteTypes {
  routes: Route[];
  inputAmount: InputAmount;
  outputAmount: InputAmount;
  calldatas: Calldatas[] | Calldatas;
  bridgeFee: BridgeFee;
  jitoTipsTotal?: bigint;
  forBera?: QuoteTypes[];
}

export interface BridgeFee {
  token: string;
  chainId: number;
  amount: string;
}

export interface Calldatas {
  chainId: number;
  from: string;
  value: string;
  data: string;
  to: string;
  label?: string;
}

export interface InputAmount {
  address: string;
  decimals: number;
  name: string;
  symbol: string;
  value: string;
  chainId: number;
  receiver?: string;
}

export type OutputAmount = InputAmount;

export interface Route {
  path: string[];
  amountIn: InputAmount;
  amountOut: InputAmount;
}

export interface TokenBalanceResults {
  tokenAddress: string;
  symbol: string;
  name: string;
  decimals: number;
  balance: string;
  logo: string;
  balanceFormatted: string;
  totalSupply: string;
  mcap: string;
  usdPrice: number;
  usdPrice1hrPercentChange: number;
  usdPrice4hrPercentChange: number;
  usdPrice12hrPercentChange: number;
  usdPrice24hrPercentChange: number;
  usdValue: number;
  nativeToken: boolean;
  walletAddress: string;
  network: number;
}
export interface BalanceProps {
  amount: bigint | null;
  symbol: string;
  isLoading: boolean;
}

export interface TokenPrice {
  address: string;
  confidence?: number | null;
  networkId: number;
  poolAddress: string;
  priceUsd: number;
  timestamp?: number;
}

export type Token = {
  symbol: string;
  address: string;
  decimals: number;
  chainId: number;
  image?: string; // Optional image field
  name?: string;
  mcap?: string;
  isHardcoded?: boolean;
  balanceData?: {
    chainId: number;
    balance?: string;
    usdValue?: number;
  };
  isVerified?: boolean;
};

export type MultiChainToken = {
  symbol: string;
  // address: string;
  addressMap: { [chainId: number]: string };
  decimals: number;
  chainIds: number[];
  image?: string;
  name?: string;
  tokens: Token[];
  isVerified?: boolean;
  isHardcoded?: boolean;
};
export interface RpcTokenAccount {
  mint: string;
  amount: string;
}

export interface SimulateBundleResponse {
  jsonrpc: string;
  result: {
    context: {
      apiVersion: string;
      slot: number;
    };
    value: {
      summary: string;
      transactionResults: Array<{
        err: any;
        logs: string[];
        postExecutionAccounts: any;
        preExecutionAccounts: any;
        returnData: any;
        unitsConsumed: number;
      }>;
    };
  };
}

export interface SimulateBundleOptions {
  encodedTransactions: string[];
}

export interface GasRefuelCalculationParams {
  srcChainId: number;
  amountIn: number;
  amountInWei: bigint | undefined;
  tokenIn: TokenBalanceResults | undefined;
  destChainId: number;
  srcNativeToken: TokenBalanceResults | undefined;
  decimals: number;
}

export interface RecommendedGasRefuelResponse {
  recommendedGasRefuel: string;
  expectedGasRefuelUsdValue: number;
  bridgeFeeIsSubtractedFromAmountIn: boolean;
  expectedBridgeFee: {
    token: string;
    name: string;
    symbol: string;
    decimals: number;
    chainId: number;
    amount: string;
    amountDecimal: number;
    bridgeFeeUsdValue: number;
  };
  expectedBridgeFeeWithGasRefuel: {
    token: string;
    name: string;
    symbol: string;
    decimals: number;
    chainId: number;
    amount: string;
    amountDecimal: number;
    bridgeFeeUsdValue: number;
  };
}

export interface IDextraBridgeEstimate {
  bridgeInfo: RecommendedGasRefuelResponse;
  minimumAmountInUsdValue: number;
  minimumNativeBalanceUsdValue: number;
}

export interface FallbackTokens {
  tokenIn?: Token | null;
  tokenOut?: Token | null;
}
