import { CHAIN_MAP, SOLANA_CHAIN_ID } from '../config/chains.js';
import type { TokenBalanceResults } from '../types/index.js';
import { NATIVE_TOKEN } from '../utils/address.js';
import { buildInsufficientFundsWebAppError } from '../utils/errors.js';
import { fromWei } from '../utils/eth.js';
import { excludeAffiliateFee } from '../utils/fee.js';
import { AffiliateFeeService } from './AffiliateFeeService.js';

export interface InsufficientFundsErrorBuilderProps {
  nativeTotalBalance?: number;
  sourceNetwork: number;
  destinationNetwork: number;
  isTransfer: boolean;
  balances: TokenBalanceResults[];
  tokenInAddress: string;
  tokenOutAddress: string;
  amountInput: string;
  systemFeePercent: number;
  errorBuilder?: (network: string, minUsdValue?: number) => string;
}

export class InsufficientFundsErrorBuilder {
  private props: InsufficientFundsErrorBuilderProps;

  constructor(props: InsufficientFundsErrorBuilderProps) {
    this.props = props;
  }

  build(): string {
    const {
      balances,
      nativeTotalBalance = 0,
      sourceNetwork,
      isTransfer,
      amountInput,
      tokenInAddress,
      tokenOutAddress,
      destinationNetwork,
      systemFeePercent,
      errorBuilder = buildInsufficientFundsWebAppError,
    } = this.props;

    if (!nativeTotalBalance || nativeTotalBalance === 0) {
      return errorBuilder(CHAIN_MAP[sourceNetwork]?.name ?? '');
    }

    // it is swap
    const excludeFee = excludeAffiliateFee({
      srcToken: tokenInAddress,
      destToken: tokenOutAddress,
      srcChainId: sourceNetwork,
      destChainId: destinationNetwork,
    });

    const nativeAddress = sourceNetwork === SOLANA_CHAIN_ID ? NATIVE_TOKEN.SOL : NATIVE_TOKEN.ETH;

    const sourceNativeUsd =
      balances.find((x) => x.tokenAddress === nativeAddress && x.network === sourceNetwork)?.usdValue || 0;
    const matchingToken = balances.find((x) => x.tokenAddress === tokenInAddress && x.network === sourceNetwork);
    const sourceUsdValue = matchingToken ? Number(matchingToken?.balanceFormatted) * matchingToken?.usdPrice || 0 : 0;
    const minUsdValue = AffiliateFeeService.calculateMinAllowedUsdValue(systemFeePercent, sourceNetwork, excludeFee);

    // if source and dest networks are the same, we need to check:
    if (sourceNetwork === destinationNetwork) {
      if (sourceNativeUsd < minUsdValue) {
        return errorBuilder(CHAIN_MAP[sourceNetwork]?.name ?? '');
      }
    } else if (sourceUsdValue < minUsdValue) {
      return errorBuilder(CHAIN_MAP[sourceNetwork]?.name ?? '');
    }

    return InsufficientFundsErrorBuilder.buildAffiliateFeeErrorMsg(
      amountInput,
      balances,
      excludeFee,
      tokenInAddress,
      sourceNetwork,
      isTransfer,
      systemFeePercent,
      errorBuilder,
    );
  }

  static buildAffiliateFeeErrorMsg(
    amountInput: string,
    balances: TokenBalanceResults[],
    excludeFee: boolean,
    tokenInAddress: string,
    sourceNetwork: number,
    isTransfer: boolean,
    systemFeePercent: number,
    errorBuilder: (network: string, minUsdValue?: number) => string,
  ): string {
    // We are not checking affiliate fee for transfers
    if (isTransfer) {
      return '';
    }

    const { tokenUsdPrice, decimals = 18 } =
      AffiliateFeeService.getAffiliateFeeTokenForQuote(balances, tokenInAddress, sourceNetwork) || {};

    if (!tokenUsdPrice || !amountInput || amountInput === '0') {
      return '';
    }

    const minUsdValue = AffiliateFeeService.calculateMinAllowedUsdValue(systemFeePercent, sourceNetwork, excludeFee);

    const amount = fromWei(amountInput, decimals);
    const amountUsd = +amount * tokenUsdPrice;

    if (amountUsd !== 0 && amountUsd <= minUsdValue) {
      return errorBuilder(CHAIN_MAP[sourceNetwork]?.name ?? '', minUsdValue);
    }

    return '';
  }
}
