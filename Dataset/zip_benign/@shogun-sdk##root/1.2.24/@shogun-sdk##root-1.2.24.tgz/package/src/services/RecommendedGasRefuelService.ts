import axios from 'axios';
import { base, berachain } from 'viem/chains';
import type {
  GasRefuelCalculationParams,
  IDextraBridgeEstimate,
  RecommendedGasRefuelResponse,
  TokenBalanceResults,
} from '../types/index.js';
import { compareAddresses, NATIVE_TOKEN } from '../utils/address.js';
import { makeNotEnoughFundsUsdCrosschainErrorMsg } from '../utils/errors.js';
import { fromWei } from '../utils/eth.js';
import { getNativeBalanceRpc, MIN_NATIVE_TOKEN_BALANCE } from '../utils/rpc.js';

/**
 * Service for calculating and fetching recommended gas refuel amounts for cross-chain bridges
 */
export class RecommendedGasRefuelService {
  /**
   * Creates parameters for gas refuel calculation
   */
  public static getCalculationParams(
    tokens: TokenBalanceResults[],
    tokenInAddress: string,
    srcChainId: number,
    destChainId: number,
    amountIn: string,
    amountInWei: string,
    decimals: number,
  ): GasRefuelCalculationParams {
    const tokenIn = tokens.find(
      (token) => compareAddresses(token.tokenAddress, tokenInAddress) && token.network === srcChainId,
    );

    const srcNativeToken = tokens.find((token) => token.network === srcChainId && token.nativeToken);

    return {
      srcChainId,
      destChainId,
      amountIn: Number(amountIn),
      amountInWei: amountInWei ? BigInt(amountInWei) : undefined,
      tokenIn: tokenIn,
      srcNativeToken: srcNativeToken,
      decimals,
    };
  }

  /**
   * Fetches recommended gas refuel amount from the bridge info endpoint
   * @param gasRefuelParams Parameters for gas refuel calculation
   * @param signal AbortSignal for request cancellation
   * @returns Recommended gas refuel amount response
   */
  public async fetchRecommendedAmount(
    api: { key: string; url: string },
    gasRefuelParams: GasRefuelCalculationParams,
    signal: AbortSignal,
  ): Promise<RecommendedGasRefuelResponse | null> {
    const { srcChainId, destChainId } = gasRefuelParams;
    const url = `${api.url}/v2/bridge-info?srcChain=${srcChainId}&destChain=${destChainId}`;

    try {
      console.log('>>> Fetching recommended gas refuel amount from:', url);

      const response = await axios.get(url, {
        headers: {
          'x-api-key': api.key,
        },
        signal,
      });

      console.log('>>> Recommended gas refuel amount:', response.data);
      return response.data;
    } catch (error) {
      console.error('Failed to fetch recommended gas refuel amount:', error);
      return null;
    }
  }

  async handleGasRefuel(
    api: { key: string; url: string },
    gasRefuelParams: GasRefuelCalculationParams,
    destToken: string,
    destChainId: number,
    srcChainId: number,
    destinationAddress: string,
    isSolana: boolean,
    signal?: AbortSignal,
  ): Promise<{
    gasRefuelAmount: bigint;
    error?: string;
    bridgeInfo?: IDextraBridgeEstimate;
    bridgeFeeIsSubtractedFromAmountIn: boolean;
  }> {
    let bridgeFeeIsSubtractedFromAmountIn = false;
    let gasRefuelAmount = BigInt(0);
    let needGasRefuel = false;
    let minimumAmountInUsdValue = 0;
    let minimumNativeBalanceUsdValue = 0;

    if (!gasRefuelParams || !destinationAddress) {
      return { gasRefuelAmount, bridgeFeeIsSubtractedFromAmountIn };
    }

    const minimumBalanceThreshold = MIN_NATIVE_TOKEN_BALANCE[destChainId];

    const isNativeToken = isSolana
      ? ['so11111111111111111111111111111111111111111', NATIVE_TOKEN.ETH].includes(destToken.toLowerCase())
      : compareAddresses(destToken, NATIVE_TOKEN.ETH);

    console.log('>>>> isNativeToken:', isNativeToken);

    let gasRefuel: RecommendedGasRefuelResponse | null = null;

    if (
      !isNativeToken &&
      destChainId !== srcChainId &&
      srcChainId !== berachain.id &&
      destChainId !== berachain.id &&
      destChainId !== base.id
    ) {
      const destNativeBalance = await getNativeBalanceRpc(destinationAddress, destChainId);

      console.log('>>>> destNativeBalance:', destNativeBalance, minimumBalanceThreshold);

      needGasRefuel = destNativeBalance < (minimumBalanceThreshold ?? 0);

      console.log('>>>> destNativeBalance <= minimumBalanceThreshold ... fetching gas refuel');

      gasRefuel = await this.fetchRecommendedAmount(api, gasRefuelParams, signal || new AbortSignal());

      bridgeFeeIsSubtractedFromAmountIn = gasRefuel?.bridgeFeeIsSubtractedFromAmountIn || false;
      if (!gasRefuel) {
        return {
          gasRefuelAmount: BigInt(0),
          bridgeFeeIsSubtractedFromAmountIn: bridgeFeeIsSubtractedFromAmountIn,
        };
      }

      console.log('>>>> gasRefuel response:', gasRefuel);

      const tokenIn = gasRefuelParams.tokenIn;

      if (!tokenIn) {
        console.log('>>>> Warning: Unable to calculate amount in USD ... skipping gas refuel, tokenIn is undefined');
        return {
          gasRefuelAmount: BigInt(gasRefuel.recommendedGasRefuel),
          bridgeInfo: {
            bridgeInfo: gasRefuel,
            minimumAmountInUsdValue,
            minimumNativeBalanceUsdValue,
          },
          bridgeFeeIsSubtractedFromAmountIn: bridgeFeeIsSubtractedFromAmountIn,
        };
      }

      const amountInUsd = gasRefuelParams.amountInWei
        ? +fromWei(gasRefuelParams.amountInWei.toString(), gasRefuelParams.decimals) * (tokenIn.usdPrice || 0)
        : 0;

      if (!amountInUsd) {
        console.log('>>>> Warning: Unable to calculate amount in USD ... skipping gas refuel, price is 0');
        return {
          gasRefuelAmount: BigInt(gasRefuel.recommendedGasRefuel),
          bridgeInfo: {
            bridgeInfo: gasRefuel,
            minimumAmountInUsdValue,
            minimumNativeBalanceUsdValue,
          },
          bridgeFeeIsSubtractedFromAmountIn: bridgeFeeIsSubtractedFromAmountIn,
        };
      }

      // using estimations depending on gas refuel requirement
      const expectedBridgeFee = needGasRefuel ? gasRefuel.expectedBridgeFeeWithGasRefuel : gasRefuel.expectedBridgeFee;

      if (needGasRefuel) {
        console.log('>> need gas refuel', gasRefuel.recommendedGasRefuel);
        // gasRefuel will always be subtracted from amount In or during swap
        minimumAmountInUsdValue += gasRefuel.expectedGasRefuelUsdValue;

        if (tokenIn.nativeToken) {
          minimumNativeBalanceUsdValue += gasRefuel.expectedGasRefuelUsdValue;
        }

        gasRefuelAmount = BigInt(gasRefuel.recommendedGasRefuel);
      }

      if (bridgeFeeIsSubtractedFromAmountIn) {
        minimumAmountInUsdValue += expectedBridgeFee.bridgeFeeUsdValue;

        if (tokenIn.nativeToken) {
          minimumNativeBalanceUsdValue += expectedBridgeFee.bridgeFeeUsdValue;
        }
      } else {
        if (tokenIn.nativeToken) {
          minimumAmountInUsdValue += expectedBridgeFee.bridgeFeeUsdValue;
        }

        minimumNativeBalanceUsdValue += expectedBridgeFee.bridgeFeeUsdValue;
      }

      console.log('>>>> minimumAmountInUsdValue:', minimumAmountInUsdValue, amountInUsd);
      const notEnoughTokenIn = minimumAmountInUsdValue > amountInUsd;
      if (notEnoughTokenIn) {
        console.log('>>>> notEnoughTokenIn:', notEnoughTokenIn, {
          amountInUsd,
          bridgeFeeUsdValue: expectedBridgeFee.bridgeFeeUsdValue,
          tokenIn,
        });

        return {
          gasRefuelAmount: gasRefuelAmount,
          error: makeNotEnoughFundsUsdCrosschainErrorMsg(minimumAmountInUsdValue, tokenIn.symbol, tokenIn.network),
          bridgeFeeIsSubtractedFromAmountIn: bridgeFeeIsSubtractedFromAmountIn,
        };
      }

      // If token IN is native token we would still have take expectedGasRefuelUsdValue into account
      // But this case has to be covered with previous `notEnoughTokenIn` check
      // So `notEnoughNativeBalance` only checks for the case when token IN is not native

      const srcNativeToken = gasRefuelParams.srcNativeToken;

      if (srcNativeToken) {
        console.log('>>>> srcNativeToken:', srcNativeToken.symbol);
        const srcNativeBalanceUsd = srcNativeToken.usdValue || 0;

        const notEnoughNativeBalance = minimumNativeBalanceUsdValue > +srcNativeBalanceUsd;

        console.log('>>>> notEnoughNativeBalance:', notEnoughNativeBalance, srcNativeBalanceUsd);

        if (notEnoughNativeBalance) {
          console.log('------> CHECKING NOT ENOUGH!');
          return {
            gasRefuelAmount: gasRefuelAmount,
            error: makeNotEnoughFundsUsdCrosschainErrorMsg(
              minimumNativeBalanceUsdValue,
              srcNativeToken.symbol,
              srcNativeToken.network,
            ),
            bridgeFeeIsSubtractedFromAmountIn: gasRefuel.bridgeFeeIsSubtractedFromAmountIn,
          };
        }
      }
    }

    console.log('>>>> gasRefuelAmount:', gasRefuelAmount);

    return {
      gasRefuelAmount,
      // @ts-ignore
      bridgeInfo: { bridgeInfo: gasRefuel, minimumAmountInUsdValue, minimumNativeBalanceUsdValue },
      bridgeFeeIsSubtractedFromAmountIn: bridgeFeeIsSubtractedFromAmountIn,
    };
  }
}
