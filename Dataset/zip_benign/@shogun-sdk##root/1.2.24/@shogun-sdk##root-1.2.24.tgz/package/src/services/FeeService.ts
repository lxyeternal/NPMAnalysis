import { Connection, VersionedTransaction } from '@solana/web3.js';
import { SOLANA_CHAIN_ID } from '../config/chains.js';
import { DEFAULT_JITO_TIP } from '../lib/jito.js';
import type { EVMPublicClient } from '../types/client.js';
import type { Calldatas, QuoteTypes } from '../types/index.js';
import { isNativeToken, isWrappedAddress } from '../utils/address.js';
import { getInsufficientFundsWebAppError } from '../utils/errors.js';
import { formatEthDecimal } from '../utils/format-eth-decimals.js';
import { estimateEvmTransaction, getNativeBalanceRpc, getQuoteNativeBridgeFee, getSolanaProvider } from '../utils/rpc.js';

export interface ICollectedFees {
  totalTxCost: bigint;
  gasLimit?: bigint;
  maxFeePerGas?: bigint;
  maxPriorityFeePerGas?: bigint;
  estimatedFees?: bigint;
  bridgeFee?: bigint;
}

// TODO: make dynamic calulation of fee
const TODO_BRIDGE_FEE = BigInt(30000000); // 0.03 SOL in lamports

export interface ISolanaFeeEstimation {
  fees: bigint;
  preBalances?: Record<string, bigint>;
  postBalances?: Record<string, bigint>;
}

// 150000 lamports is typical minimum fee for swap
const MIN_SOLANA_FEE = 150000;

const decodeSolanaTransactions = (calldatas: Calldatas[]): VersionedTransaction[] => {
  return calldatas?.map((calldata) => {
    const messageBuffer = Buffer.from(calldata.data, 'base64');
    return VersionedTransaction.deserialize(messageBuffer);
  });
};

export class FeeService {
  public async estimateSolanaTransactionFees(
    provider: Connection,
    transactions: VersionedTransaction[],
  ): Promise<ISolanaFeeEstimation> {
    try {
      // Estimate fees using existing method
      const fees = await Promise.all(
        transactions.map(async (tx) => {
          try {
            const feeResponse = await provider.getFeeForMessage(tx.message, 'processed');
            if (!feeResponse?.value) {
              return BigInt(MIN_SOLANA_FEE);
            }
            return BigInt(feeResponse.value);
          } catch (err) {
            console.error('Error getting fee for message:', err);
            return BigInt(MIN_SOLANA_FEE);
          }
        }),
      );

      const totalFee = fees.reduce((acc, fee) => acc + fee, BigInt(0));
      // Not possible to simulate bundle for solana https://intensitylabsgroup.slack.com/archives/C06MTL2GR42/p1739272343867779?thread_ts=1739266229.767679&cid=C06MTL2GR42
      /*
      // Simulate bundle to get balance changes
      try {
        const simulationResult = await simulateBundle({ encodedTransactions:  });

        // Extract pre and post balances from simulation
        if (simulationResult) {
          // Return both fees and balance changes

          console.log('simulationResult', simulationResult);
         
          return {
            fees: totalFee,
            preBalances: simulationResult.preBalances,
            postBalances: simulationResult.postBalances,
          };
        }
      } catch (err) {
        console.warn('Failed to simulate bundle for balance changes:', err);
      } */

      // Return just fees if simulation fails
      return { fees: totalFee };
    } catch (err) {
      console.error('Failed to estimate Solana transaction fees:', err);
      // Return minimum fee * number of transactions as fallback
      return {
        fees: BigInt(MIN_SOLANA_FEE * transactions.length),
      };
    }
  }

  // TODO https://intensitylabsgroup.slack.com/archives/C06MTL2GR42/p1739266229767679
  // TODO: make dynamic calulation of fee
  public static getConstSolanaBridgeCostFee = (quote: QuoteTypes) => {
    const hasBridgeCallata = (quote.calldatas as Calldatas[]).find((tx) => tx.label === 'bridge');

    return hasBridgeCallata ? TODO_BRIDGE_FEE : BigInt(0);
  };

  async checkHasSufficientBalanceForGas(
    senderAddress: string,
    srcNetwork: number,
    quote: QuoteTypes,
    setSuggestedSlippage?: (slippage: number) => void,
  ): Promise<{
    fees: ICollectedFees;
    error?: string;
    provider: EVMPublicClient | Connection | null;
  }> {
    const nativeBalance = await getNativeBalanceRpc(senderAddress, srcNetwork);

    try {
      if (srcNetwork === SOLANA_CHAIN_ID) {
        const provider = await getSolanaProvider();

        const transactions = decodeSolanaTransactions(quote.calldatas as Calldatas[]);

        const estimatedFees =
          (await this.estimateSolanaTransactionFees(provider, transactions)).fees +
          (quote.jitoTipsTotal ?? BigInt(DEFAULT_JITO_TIP)) +
          FeeService.getConstSolanaBridgeCostFee(quote);

        const isWrapped = isWrappedAddress(quote.inputAmount?.address);
        const isNative = isNativeToken(quote.inputAmount?.address);

        const nativeBalanceUsed = isWrapped || isNative ? BigInt(quote.inputAmount.value) : BigInt(0);

        const bridgeFee = getQuoteNativeBridgeFee(quote);

        const minimumNativeBalance = estimatedFees + nativeBalanceUsed; // not adding bridgeFee, because it's already included in the quote.inputAmount.value from dextra

        const isEnoughBalance = BigInt(nativeBalance) >= minimumNativeBalance;
        console.log('>> Solana estimatedFees: ', estimatedFees);
        console.log('>> Solana minimumNativeBalance: ', minimumNativeBalance);
        console.log('>> Solana isEnoughBalance: ', isEnoughBalance);
        console.log('>> Solana nativeBalance: ', nativeBalance);
        console.log('>> Solana nativeBalanceUsed: ', nativeBalanceUsed);
        console.log('>> Solana bridgeFee: ', bridgeFee);

        return {
          fees: {
            totalTxCost: minimumNativeBalance,
            estimatedFees: estimatedFees,
            bridgeFee,
          },
          error: isEnoughBalance ? undefined : getInsufficientFundsWebAppError(estimatedFees + bridgeFee, srcNetwork),
          provider: provider as unknown as Connection,
        };
      } else {
        const {
          maxFeePerGas,
          maxPriorityFeePerGas,
          gasLimit,
          estimatedFees,
          minimumNativeBalance,
          provider,
          bridgeFee,
        } = await estimateEvmTransaction(srcNetwork, quote, senderAddress);

        const isEnoughBalance = BigInt(nativeBalance) >= minimumNativeBalance;
        console.log('>> EVM estimatedFees: ', estimatedFees, formatEthDecimal(estimatedFees, 6));
        console.log('>> EVM nativeBalance: ', nativeBalance, formatEthDecimal(nativeBalance, 6));
        console.log('>> EVM minimumNativeBalance: ', minimumNativeBalance, formatEthDecimal(minimumNativeBalance, 6));
        console.log('>> EVM isEnoughBalance: ', isEnoughBalance);
        console.log('>> EVM bridgeFee: ', bridgeFee, formatEthDecimal(bridgeFee, 6));

        /* 
          https://dextra-node-935187426877.us-central1.run.app/v2/quote?srcChain=80094&destChain=7565164&srcT[…]n7K6c98trrompsjKtWqXMKyM6nVEN29&affiliateFee=0
            input amount is 3130000000000000000 (BERA)
            But calldata returns 3150000000000000000
            Increased  +20000000000000000. Looks like a bridge fee and also need to retuce it from max input amount
        */
        return {
          fees: {
            maxPriorityFeePerGas,
            maxFeePerGas,
            gasLimit,
            totalTxCost: minimumNativeBalance,
            estimatedFees,
            bridgeFee,
          },
          provider,
          error: isEnoughBalance ? undefined : getInsufficientFundsWebAppError(estimatedFees + bridgeFee, srcNetwork),
        };
      }
    } catch (error: any) {
      setSuggestedSlippage?.(error.suggestedSlippageValue);

      return {
        fees: {
          totalTxCost: BigInt(0),
        },
        provider: null,
        error: error.message,
      };
    }
  }
}
