import VerifiedListData from './verified.json' with { type: 'json' };

export const VerifiedList = VerifiedListData;

export const LEGO_API = 'https://zaps-825534211396.us-central1.run.app';
