import { type Commitment, Connection, PublicKey } from '@solana/web3.js';
import { type Chain, createPublicClient, fallback, type FeeValuesEIP1559, http, parseEther } from 'viem';
import { arbitrum, avalanche, base, berachain, bsc, mainnet, sonic } from 'viem/chains';
import { isEVMChain, RPCS, SOLANA_CHAIN_ID } from '../config/chains.js';
import type { EVMPublicClient } from '../types/client.js';
import type { Calldatas, QuoteTypes } from '../types/index.js';
import { compareAddresses, isWrappedAddress, NATIVE_TOKEN } from './address.js';
import { returnErrorDuringEstimationGas } from './errors.js';
import { convertToIntegerMultiplier } from './eth.js';
import { formatEthDecimal } from './format-eth-decimals.js';
import { max } from './math.js';

// you can set those differently
export const MIN_NATIVE_TOKEN_BALANCE: { [chainId: number]: bigint } = {
  [mainnet.id]: BigInt(500000000000000), // 0.0005 ETH
  [base.id]: BigInt(500000000000000), // 0.0005 ETH
  [arbitrum.id]: BigInt(100000000000000), // 0.0001 ETH
  [bsc.id]: BigInt(100000000000000), // 0.0001 ETH
  [SOLANA_CHAIN_ID]: BigInt(1000000), // 0.001 SOL
  [berachain.id]: BigInt(100000000000000), // 0.0001 ETH
  [avalanche.id]: BigInt(100000000000000), // 0.0001 ETH
  [sonic.id]: BigInt(100000000000000), // 0.0001 ETH
};

export const MIN_BRIDGE_FEE_NATIVE_TOKEN: { [chainId: number]: bigint } = {
  [mainnet.id]: BigInt(500000000000000), // 0.0005 ETH
  [base.id]: BigInt(500000000000000), // 0.0005 ETH
  [arbitrum.id]: BigInt(100000000000000), // 0.0001 ETH
  [bsc.id]: BigInt(100000000000000), // 0.0001 ETH
  [SOLANA_CHAIN_ID]: BigInt(1000000), // 0.001 SOL
  [berachain.id]: BigInt(100000000000000), // 0.0001 ETH
  [avalanche.id]: BigInt(100000000000000), // 0.0001 ETH
  [sonic.id]: BigInt(100000000000000), // 0.0001 ETH
};

export const getEthChainViem = (network: number): Chain => {
  const chainMap: Record<number, Chain> = {
    [mainnet.id]: mainnet,
    [arbitrum.id]: arbitrum,
    [base.id]: base,
    [bsc.id]: bsc,
    [berachain.id]: berachain,
  };

  if (network === SOLANA_CHAIN_ID) {
    throw new Error(`Network "${network}" is not supported in EVM chain configuration.`);
  }

  return chainMap[network] ?? base;
};

export const getEvmJsonRpcProvider = (network: number): ReturnType<typeof createPublicClient> => {
  const rpcUrls = RPCS[network];
  const chainViem = getEthChainViem(network);

  const transports = rpcUrls?.rpc.slice(0, 1).map((url: string) => http(url));

  return createPublicClient({
    chain: chainViem,
    transport: fallback(transports ?? [], {
      rank: true,
      retryCount: 5,
    }),
  });
};

/**
 * Calculates gasLimit based on estimated transaction gas cost.
 * Increasing gasLimit to cover unexpected expenses
 * @param estimatedGas Estimated transaction gas cost
 */
export const getAdjustedGasLimit = (network: number, estimatedGas: bigint | number): bigint => {
  if (network === arbitrum.id) {
    return BigInt(Math.ceil(Number(estimatedGas) * GAS_LIMIT_MULTIPLIER_ARBITRUM));
  }

  return BigInt(Math.ceil(Number(estimatedGas) * GAS_LIMIT_MULTIPLIER));
};

/**
 * Calculates adjusted `maxFeePerGas` and `maxPriorityFeePerGas` based on gas multiplier
 * @param provider EVM viem provider
 * @param gasMultiplier Gas price priority multiplier
 */
export const getAdjustedFeesPerGas = async (
  provider: EVMPublicClient,
  gasMultiplier: number,
): Promise<{ maxFeePerGas: bigint; maxPriorityFeePerGas: bigint }> => {
  const fees: FeeValuesEIP1559 = await provider.estimateFeesPerGas();

  // Define minimum values (in wei)
  const MIN_PRIORITY_FEE = BigInt(100000000); // 0.1 gwei

  const integerMultiplier = convertToIntegerMultiplier(gasMultiplier, Number(GAS_PRICE_SCALE));

  // Calculate adjusted priority fee with minimum check
  const adjustedMaxPriorityFeePerGas = max(
    (BigInt(fees.maxPriorityFeePerGas) * integerMultiplier) / GAS_PRICE_SCALE,
    MIN_PRIORITY_FEE,
  );

  const baseFeePerGas = BigInt(fees.maxFeePerGas) - BigInt(fees.maxPriorityFeePerGas);
  const adjustedMaxFeePerGas = max(
    baseFeePerGas + adjustedMaxPriorityFeePerGas,
    adjustedMaxPriorityFeePerGas * BigInt(2), // Ensure maxFeePerGas is always higher
  );

  return {
    maxFeePerGas: adjustedMaxFeePerGas,
    maxPriorityFeePerGas: adjustedMaxPriorityFeePerGas,
  };
};

/*
 * Calculates adjusted maxFeePerGas based on estimated maxFeePerGas and gas multiplier
 * @param maxFeePerGas Estimated maxFeePerGas
 * @param gasMultiplier Gas price priority multiplier
 */
export const getAdjustedMaxFeePerGas = (maxFeePerGas: bigint | number, gasMultiplier: number): bigint => {
  const integerMultiplier = convertToIntegerMultiplier(gasMultiplier, Number(GAS_PRICE_SCALE));
  return (BigInt(maxFeePerGas) * integerMultiplier) / GAS_PRICE_SCALE;
};

const GAS_LIMIT_MULTIPLIER = 1.2; // +20% to gas estimation
export const GAS_LIMIT_MULTIPLIER_ARBITRUM = 3; // +300% to gas estimation for Arbitrum
const GAS_PRICE_SCALE = BigInt(10000000000);

export const fetchProviderEstimation = async (provider: EVMPublicClient, quote: QuoteTypes, from?: string) => {
  const transaction = quote.calldatas as Calldatas;

  try {
    if (quote.inputAmount.chainId === sonic.id) {
      return await provider.estimateGas({
        to: transaction.to,
        data: transaction.data,
        value: BigInt(transaction.value),
        account: from,
      });
    }

    return await provider.estimateGas({
      to: transaction.to,
      data: transaction.data,
      value: BigInt(transaction.value),
      account: from,
      blockTag: 'latest',
      stateOverride: [
        {
          address: from,
          balance: parseEther('1000000000'),
        },
      ],
    });
  } catch (error: any) {
    const blockNumber = await provider.getBlockNumber();
    console.log(
      `>> fetchProviderEstimation error for block ${blockNumber} with token ${quote.inputAmount?.address} ${quote.inputAmount?.chainId} for token ${quote.outputAmount?.address} ${quote.outputAmount?.chainId} with value ${quote.inputAmount?.value}:`,
      error.message,
    );
    returnErrorDuringEstimationGas(quote, error);
    return BigInt(0);
  }
};

export const getQuoteNativeBridgeFee = (quote: QuoteTypes) => {
  let bridgeFee = MIN_NATIVE_TOKEN_BALANCE[quote.inputAmount.chainId] ?? BigInt(0);

  if (quote?.bridgeFee) {
    if (isWrappedAddress(quote?.bridgeFee?.token)) {
      console.log('>> Bridge fee is wrapped token');
      bridgeFee += BigInt(quote?.bridgeFee?.amount);
    } else if (compareAddresses(quote?.bridgeFee?.token, NATIVE_TOKEN.SOL)) {
      console.log('>> Bridge fee is SOL token');
      bridgeFee += BigInt(quote?.bridgeFee?.amount);
    } else if (compareAddresses(quote?.bridgeFee?.token, NATIVE_TOKEN.ETH)) {
      console.log('>> Bridge fee is ETH');
      bridgeFee += BigInt(quote?.bridgeFee?.amount);
    }
  }

  return bridgeFee;
};

export const estimateEvmTransaction = async (
  network: number,
  quote: QuoteTypes,
  from: string,
  gasMultiplier: number = 1.2,
): Promise<{
  // maxFeePerGas to use in transaction
  maxFeePerGas: bigint;
  // maxPriorityFeePerGas to use in transaction
  maxPriorityFeePerGas: bigint;
  // gasLimit to use in transaction
  gasLimit: bigint;
  // transaction fees in native tokens wei
  estimatedFees: bigint;
  // minimum required balance to execute transaction
  minimumNativeBalance: bigint;
  // provider used to estimate gas
  provider: EVMPublicClient;
  // transaction value
  value: bigint;
  // bridge fee
  bridgeFee: bigint;
}> => {
  const provider = getEvmJsonRpcProvider(network);
  const transaction = quote.calldatas as Calldatas;
  // Get gas price and estimated transaction gas cost in parallel
  const [{ maxFeePerGas, maxPriorityFeePerGas }, gasEstimate] = await Promise.all([
    getAdjustedFeesPerGas(provider as any, gasMultiplier),
    // Estimate gas usage for the transaction
    fetchProviderEstimation(provider as any, quote, from),
  ]);

  // Increasing gasLimit by `GAS_LIMIT_MULTIPLIER` in case unpredictable gas spending occurs
  const gasLimit = getAdjustedGasLimit(network, gasEstimate);

  const bridgeFee = getQuoteNativeBridgeFee(quote);

  // Calculate total gas cost in Wei
  const totalGasCostInWei = BigInt(gasLimit) * maxFeePerGas;
  const minimumNativeBalance = totalGasCostInWei + BigInt(transaction.value); // not adding bridgeFee, because it's already included in the quote.inputAmount.value from dextra

  console.log('>> Gas gasLimit: ', gasLimit, ' from ', gasEstimate);
  console.log('>> Gas maxFeePerGas: ', maxFeePerGas);
  console.log('>> Value: ', transaction.value, formatEthDecimal(transaction.value, 6));
  console.log('>> Gas maxPriorityFeePerGas: ', maxPriorityFeePerGas);
  console.log('>> Gas estimatedFees: ', totalGasCostInWei, formatEthDecimal(totalGasCostInWei, 6));
  console.log('>> Gas minimumNativeBalance: ', minimumNativeBalance, formatEthDecimal(minimumNativeBalance, 6));

  // Return the result
  return {
    maxFeePerGas,
    maxPriorityFeePerGas,
    gasLimit,
    value: transaction.value ? BigInt(transaction.value) : BigInt(0),
    estimatedFees: totalGasCostInWei,
    minimumNativeBalance,
    provider: provider as unknown as EVMPublicClient,
    bridgeFee,
  };
};

/**
 * Creates a Solana connection with fallback RPC URLs.
 * Attempts to connect to each RPC URL in order until a working connection is established.
 * @returns Promise<Connection> A working Solana connection
 * @throws Error if no RPC URLs are defined or if all connections fail
 */
export const getSolanaProviderWithFallback = async (): Promise<Connection> => {
  const rpcUrls = RPCS[SOLANA_CHAIN_ID]?.rpc;

  if (!rpcUrls?.length) {
    throw new Error('No RPC URLs defined for Solana network');
  }

  const commitment: Commitment = 'confirmed';

  for (const url of rpcUrls) {
    try {
      const connection = new Connection(url, { commitment });
      await connection.getEpochInfo(); // Verify connection works
      return connection;
    } catch (error) {
      console.warn(`Failed to connect to RPC URL: ${url}`, error);
    }
  }

  throw new Error('All Solana RPC connections failed');
};

export const getSolanaProvider = async (): Promise<Connection> => {
  return getSolanaProviderWithFallback();
};

export const getNativeBalanceRpc = async (walletAddress: string, network: number): Promise<bigint> => {
  let balance = BigInt(0);

  if (network === SOLANA_CHAIN_ID) {
    const provider = await getSolanaProvider();
    balance = BigInt(await provider.getBalance(new PublicKey(walletAddress)));
  } else if (isEVMChain(network)) {
    const provider = getEvmJsonRpcProvider(network);
    balance = await provider.getBalance({
      address: walletAddress as `0x${string}`,
      //   ...(txReceipt
      //     ? {
      //         blockNumber: (txReceipt as EthTransactionResponse).blockNumber,
      //       }
      //     : {}),
    });
  }

  return BigInt(balance);
};
