import { berachain } from 'viem/chains';
import { compareAddresses } from './address.js';

const BERA_USDC = '0x549943e04f40284185054145c6e4e9568c1d3241';
const BERA_ETH = '0x2f6f07cdcf3588944bf4c42ac74ff24bf56e7590';

const normalizeBeraAddress = (tokenA: string, tokenB?: string) => {
  if (tokenB && compareAddresses(tokenB, BERA_USDC)) {
    return BERA_ETH;
  }
  return compareAddresses(tokenA, BERA_USDC) ? tokenA : BERA_USDC;
};

const BERA_CHAIN_ID = berachain.id;

export { BERA_CHAIN_ID, BERA_ETH, BERA_USDC, normalizeBeraAddress };

