export const max = (a: bigint, b: bigint): bigint => (a > b ? a : b);
