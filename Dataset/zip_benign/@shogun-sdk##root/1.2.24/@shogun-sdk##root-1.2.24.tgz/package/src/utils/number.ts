export const numberRegex = /^\d*\.?\d*$/;

export function formatNumberWithDecimalPlaces(num: number) {
  if (Math.abs(num) < 0.0001) {
    return '0';
  }

  return num.toFixed(4).replace(/\.?0*$/, '');
}

export function autoDecimalValue(value: number, threshold = 0.01, sigFigs = 2, decimals = 2) {
  if (value === 0) return '0';

  return Math.abs(value) < threshold
    ? parseFloat(value.toPrecision(sigFigs)) // Use significant figures for very small values
    : parseFloat(value?.toFixed(decimals) ?? '0'); // Use fixed decimals otherwise
}

export function applySlippage(amount: number | bigint, percentage: number): string {
  const bigIntAmount = BigInt(amount);
  const slippage = (bigIntAmount * BigInt(Math.round(percentage * 100))) / BigInt(10000);
  return (bigIntAmount - slippage).toString();
}
