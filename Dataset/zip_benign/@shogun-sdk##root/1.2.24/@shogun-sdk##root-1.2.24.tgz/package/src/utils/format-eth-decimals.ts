import { type BigNumberish } from 'ethers';
import { formatNumber } from './formatter.js';

export function formatUnits(value: string, decimals: number) {
  let display = value.toString();

  const negative = display.startsWith('-');
  if (negative) display = display.slice(1);

  display = display.padStart(decimals, '0');

  const integer = display.slice(0, display.length - decimals);

  let fraction = display.slice(display.length - decimals);
  fraction = fraction.replace(/(0+)$/, '');
  return `${negative ? '-' : ''}${integer || '0'}${fraction ? `.${fraction}` : ''}`;
}

export const SOLANA_LAMPORTS_DECIMALS = 9;

export function formatEthDecimal(value: bigint | BigNumberish, precision = 2, decimals = 18) {
  const data = Number(formatUnits(value.toString(), decimals));

  if (data > 1) {
    return formatNumber(data);
  }

  // Convert to string and remove trailing zeros after decimal point
  const fixed = data.toFixed(precision);
  return fixed.replace(/\.?0+$/, '');
}

export function numberWithCommas(value: number, precision: number) {
  const fixedNumber = value.toFixed(precision);
  const parts = fixedNumber.split('.');

  const withCommas = (parts[0] || '0').replace(/\B(?=(\d{3})+(?!\d))/g, ',');

  return parts[1] ? withCommas + '.' + parts[1] : withCommas;
}

export function formatCmpctNumber(number: number): string {
  // Only apply compact formatting for numbers 1 million or greater
  if (Math.abs(number) >= 1_000_000) {
    const usFormatter = new Intl.NumberFormat('en-US', {
      notation: 'compact',
      compactDisplay: 'short',
      maximumFractionDigits: 2, // Limit to one decimal place
    });
    return usFormatter.format(number);
  }

  // Return numbers below 1 million without compact notation, with comma formatting
  return number.toLocaleString('en-US');
}
