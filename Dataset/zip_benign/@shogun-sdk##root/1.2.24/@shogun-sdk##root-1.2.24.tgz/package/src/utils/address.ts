import { mainnet } from 'viem/chains';
import type { SupportedChainId } from '../config/chains.js';
import { CHAIN_MAP, getWrappedNativeTokenByChainId, isSolanaChain } from '../config/chains.js';
import type { NativeTokenKey, Token } from '../types/index.js';

/**
 * Truncates an Ethereum or Sui address for better readability.
 * @param address - The address to truncate.
 * @param length - Number of characters to preserve at the start and end. Default is 6.
 * @returns A truncated address string.
 */
export function truncateAddress(address: string, length: number = 6): string {
  if (address.length <= 2 * length) {
    return address; // No truncation needed if the address is short enough.
  }
  const start = address.slice(0, length);
  const end = address.slice(-length);
  return `${start}...${end}`;
}

export const SOL_NATIVE = 'So11111111111111111111111111111111111111111';
export const NATIVE_TOKEN = {
  ETH: '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE',
  SOL: 'So11111111111111111111111111111111111111112',
};
// Sometimes `11111111111111111111111111111111` is SOLANA_NATIVE_TOKEN
export const isMatchingTokens = (tokenA: string, tokenB: string): boolean => {
  return !!tokenA && !!tokenB && tokenA.toLowerCase().endsWith(tokenB.toLowerCase());
};

export const normalizeNativeAddresses = (tokenAddress: string, networkId: number) => {
  const nativeAddresses = [
    '0x0000000000000000000000000000000000000000',
    '0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee',
    'So11111111111111111111111111111111111111111',
  ];

  if (nativeAddresses.some((nativeAddress) => compareAddresses(nativeAddress, tokenAddress))) {
    return getWrappedNativeTokenByChainId(networkId as SupportedChainId);
  }

  return tokenAddress;
};

export function isNativeToken(address: string): address is (typeof NATIVE_TOKEN)[NativeTokenKey] {
  const normalizedAddress = address.toLowerCase();
  return Object.values(NATIVE_TOKEN).some((token) => token.toLowerCase() === normalizedAddress);
}

export const isValidEVMAddress = (address: string): boolean => {
  return /^0x[a-fA-F0-9]{40}$/.test(address);
};

export const isValidSolanaOrEVMAddress = (address: string): boolean => {
  const evmAddressRegex = /^0x[a-fA-F0-9]{40}$/;
  const solanaAddressRegex = /^[1-9A-HJ-NP-Za-km-z]{32,44}$/;
  return evmAddressRegex.test(address) || solanaAddressRegex.test(address);
};

export const compareAddresses = (firstAddress?: string, secondAddress?: string): boolean => {
  return !!firstAddress && !!secondAddress && firstAddress.toLowerCase() === secondAddress.toLowerCase();
};

export const compareChains = (firstChain: number | string, secondChain: number | string): boolean => {
  return !!firstChain && !!secondChain && +firstChain === +secondChain;
};

export const dummyAddressForQuote = {
  EVM: '0x9917487EE9646802be9cDCC009C0Ee21f7F76376',
  SOL: 'HW6a4ahNZh6JtQ513VMQPfnNJaGkLXA1hf1BikR3ERFZ',
};

export const getDummyAddress = (chainId: number) =>
  isSolanaChain(chainId) ? dummyAddressForQuote.SOL : dummyAddressForQuote.EVM;

export function isMatchingDummyAddress(address: string): boolean {
  // Convert input address to lowercase
  const normalizedAddress = address.toLowerCase();

  // Check against normalized dummy addresses
  return Object.values(dummyAddressForQuote).some((dummyAddress) => dummyAddress.toLowerCase() === normalizedAddress);
}

export const areTokensEqual = (tokenA: Token, tokenB: Token): boolean => {
  const normalize = (token: Token) => `${token.address}_${token.chainId}`.toLowerCase();

  return normalize(tokenA) === normalize(tokenB);
};

const chains = Object.keys(CHAIN_MAP).map((chain) => parseInt(chain));

export const WRAPPED_ADDRESSES = chains.map((chain: number) => {
  if (chain === mainnet.id) {
    return NATIVE_TOKEN.ETH;
  }
  return CHAIN_MAP[chain]?.wrapped?.toLowerCase() ?? '';
});

export const isWrappedAddress = (tokenAddress: string): boolean => {
  return !!tokenAddress && WRAPPED_ADDRESSES.includes(tokenAddress.toLowerCase());
};
