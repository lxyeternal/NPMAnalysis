import { formatUnits } from 'ethers';

// convert wei to UI amount
export const fromWei = (weiAmount: string, decimals: number) => {
  return formatUnits(weiAmount, decimals);
};

export function convertToIntegerMultiplier(floatMultiplier: number, scale: number = 10): bigint {
  return BigInt(Math.round(floatMultiplier * scale));
}
