import { CHAIN_MAP } from '../config/chains.js';
import { STABLECOINS } from '../config/stablecoins.js';
import { compareAddresses, isNativeToken } from './address.js';

export interface PrepareAffiliateFeeParams {
  srcToken: string;
  destToken: string;
  srcChainId: number;
  destChainId: number;
}

// true if we need to exclude affiliate fee
export const excludeAffiliateFee = ({ srcToken, destToken, srcChainId, destChainId }: PrepareAffiliateFeeParams) => {
  // true if we need to exclude affiliate fee

  if (!srcChainId || !destChainId) {
    return false;
  }

  const srcChain = CHAIN_MAP[srcChainId];
  const destChain = CHAIN_MAP[destChainId];

  if (!srcChain || !destChain) {
    return false;
  }

  if (!srcToken || !destToken) {
    return false;
  }

  // Case 1: Cross-chain swap and both src and dest are native assets
  if (srcChainId !== destChainId && isNativeToken(srcToken) && isNativeToken(destToken)) {
    return true;
  }

  // Case 2: src asset is native and dest asset is USDC (or vice versa)
  const srcIsNative = isNativeToken(srcToken);
  const destIsNative = isNativeToken(destToken);

  const srcIsUSD =
    STABLECOINS[srcChainId]?.USDC?.address &&
    STABLECOINS[srcChainId]?.USDT?.address &&
    (compareAddresses(srcToken, STABLECOINS[srcChainId]?.USDC?.address) ||
      compareAddresses(srcToken, STABLECOINS[srcChainId]?.USDT?.address));

  const destIsUSD =
    STABLECOINS[destChainId]?.USDC?.address &&
    STABLECOINS[destChainId]?.USDT?.address &&
    (compareAddresses(destToken, STABLECOINS[destChainId]?.USDC?.address) ||
      compareAddresses(destToken, STABLECOINS[destChainId]?.USDT?.address));

  if ((srcIsNative && destIsUSD) || (srcIsUSD && destIsNative)) {
    return true;
  }

  // Case 3: Both src and dest are USDC (any chain)
  if (srcIsUSD && destIsUSD) {
    return true;
  }

  return false;
};
