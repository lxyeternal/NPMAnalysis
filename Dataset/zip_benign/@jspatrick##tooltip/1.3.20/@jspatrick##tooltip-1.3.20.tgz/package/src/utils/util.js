export const isType = function (type, target){
	const Tag = `[object ${type}]`;
	return Object.prototype.toString.call(target) === Tag
};

export function getConstructorName(objClass) {
	if ( objClass && objClass.constructor ) {
		var strFun = objClass.constructor.toString();
		var className = strFun.substr(0, strFun.indexOf('('));
		className = className.replace('function', '');
		return className.replace(/(^\s*)|(\s*$)/ig, '');
	}
	return typeof(objClass);
}

export function mixinsOptions(source, target) {
	if(isType('Object',target)){
		for(let i in target){
			if(target.hasOwnProperty(i)&&target[i]!==undefined){
				if(isType('Object',target[i])){
					if(!isType('Object',source[i])){
						source[i] = {}
					}
					mixinsOptions(source[i],target[i])
				}else{
					source[i] = target[i]
				}
			}
		}
	}
}
