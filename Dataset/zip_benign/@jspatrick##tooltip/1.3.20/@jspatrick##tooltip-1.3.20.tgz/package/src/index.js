import { version } from "../package.json";
import Mask from 'components/Mask';
import {isType,getConstructorName} from "./utils/util";

let vue,store,router,WindowBox;

WindowBox = {
	boxchain:{
		normal:[]
	},
	push(pop,options){
		if(options.monopoly){
			let type = options.monopoly.toString();
			this.monopoly(pop,type);
		}else{
			this.boxchain.normal.unshift(pop);
		}
		return pop;
	},
	monopoly(pop,type){
		if(this.boxchain[type]?.$children[0]?.close) {
			this.boxchain[type]?.$children[0]?.close();
		}
		this.boxchain[type] = pop;
	},
	destory(root,monopoly) {

	},
};

const install = function (Vue, Options) {
	vue = Vue;
	store = Options?.store;
	router = Options?.router;
	this._vue = vue;
	this._store = store;
	this._router = router;
	Vue.prototype.$popup = renderPopup;
};

const use = function (args) {
	if(isType('Array',args)){
		for(let item of args){
			let name = getConstructorName(item);
			if(name === 'VueRouter'){
				router = item;
				this._router = router;
			}else if(name === 'Store'){
				store = item;
				this._store = store;
			}
		}
	}
};


class Ptpopup {
	constructor(){
		this.version = version;
		this.install = install;
		this.use = use;
		this._vue = null;
		this._store = null;
		this._router = null;
		this.config = {
			zIndex: 999999
		};
	}
}

let pop = new Ptpopup();


function renderPopup(options) {
	let self = this;
	let div = document.createElement('div');
	document.body.appendChild(div);
	if(options.props){
		options.props.parent = self;
	}else{
		options.props = {
			parent:self
		}
	}

	const maskConfig = {
		configs:{
			background: options.background,
			blur: options.blur,
			closeImg: options.closeImg,
			closeImgParams: options.closeImgParams,
			defaultConfig: pop.config,
			mask: options.mask,
			maskAlpha: options.maskAlpha,
			monopoly:options.monopoly,
			onclose: options.onclose,
			onopen: options.onopen,
			outline: options.outline,
			position: options.position,
			trackMouse: options.trackMouse,
			transitionName: options.transitionName,
			zIndex: options.zIndex,
		}
	};
	const MaskConstructor = vue.extend(div);
	const component = options.component||options.render;
	return WindowBox.push(new MaskConstructor({
		store,
		router,
		// propsData:maskConfig,
		render: function(h) {
			return h( Mask, {
				props: maskConfig,
				on: {
					destory: WindowBox.destory
				}
			}, [
				h(component,{
					props: options.props
				}, this.$slots.default)
			] )
		}
	}).$mount(div),options);
}



export default pop
