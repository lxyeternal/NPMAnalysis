import Cornerimg from './Cornerimg.vue'
export default Cornerimg
