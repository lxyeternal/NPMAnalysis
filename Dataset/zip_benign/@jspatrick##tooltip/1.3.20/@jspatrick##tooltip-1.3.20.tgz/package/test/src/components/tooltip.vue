<template>
    <div class="xixi" v-ani="xixi">123</div>
</template>

<script>
	export default {
		name: "tooltip",
        data: function(){
            return {
                xixi: {
                	haha: 123
                }
            }
        },
        mounted(){
		    console.log(this);
        },
        beforeDestroy() {

        }
	}
</script>

<style scoped>
.xixi{
    display: flex;
    height: 200px;
    width: 200px;
    /*background: burlywood;*/
    justify-content: center;
    align-items: center;
    font-size: 36px;
}
</style>
