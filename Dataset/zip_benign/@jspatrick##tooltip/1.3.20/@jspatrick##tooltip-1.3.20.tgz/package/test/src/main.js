import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import popup from 'ptpopup'
import 'ptpopup/dist/popup.css'

Vue.use(popup);
Vue.directive('ani',{
	bind(...args){
		console.log('bind:',args);
	},
	inserted(...args){
		console.log('inserted:',args);
	},
	update(...args){
		console.log('update:',args);
	},
	componentUpdated(...args){
		console.log('componentUpdated:',args);
	},
	unbind(...args){
		console.log('unbind:',args);
	}
})

popup.use([store,router]);
popup.config.zIndex = 15

Vue.config.productionTip = false

new Vue({
	router,
	store,
	render: h => h(App)
}).$mount('#app');
