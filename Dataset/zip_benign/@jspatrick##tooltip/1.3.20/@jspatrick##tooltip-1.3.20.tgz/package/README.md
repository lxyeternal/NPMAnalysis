## A vue component Popupwindow Plug

~~~
npm install @jspatrick/tooltip --save
~~~

~~~javascript
// main.js
import Popup from '@jspatrick/tooltip'
import '@jspatrick/tooltip/dist/popup.css'
Vue.use( Popup, { router, vuex } )

// component
this.$popup({
    render: component,
    mask: Mask,
    blur: false,    // 弹窗背景虚化
    background: `background: rgba(12, 49, 70, 0.5);
        box-shadow: 0px -1px 5px 2px rgba(2, 13, 20, 0.69);`, // 背景css
    outline: {  // 框线和四个角的样式
        mode:'1234',
        color:'#25d4ff',
        size:'15',
        margin:'-24',
        showBorder: true,
        border:'1px solid #25d4ff'
    },
    trackMouse: false,  // 弹窗是否追随鼠标位置
    position:{      // 弹窗位置
        left: 0,
        top: 0	
    },
    closeImg: null, // 关闭图标
    zIndex: null,       // 层级
})
~~~
