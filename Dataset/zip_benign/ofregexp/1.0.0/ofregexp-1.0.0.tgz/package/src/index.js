//去掉字符中所有空隔
export const regRemoveAllS = function(p){ 
  p = p.toString();
  p = p.replace(/\s*/g,"");
  return p;
}
//去掉首字符空隔
export const regRemoveFS = function(p){ 
  p = p.toString();
  p = p.replace(/^\s*/,"");
  return p;
}
//去掉首尾字符空隔
export const regRemoveFES = function(p){ 
  p = p.toString();
  p = p.replace(/^\s*|\s*$/g,"");
  return p;
}

//限制只能输入小数
export const regBaseNum = function( p ) {
  p = p.toString(); 
  p = p.replace(/[^\d.]/g,'');                    //去除非数字，只留下数字和'.' 
  p = p.replace(/^\./,'');                        //不能以点开头
  p = p.replace(/(^0)(\d*)(\.*\d*)/,'$1$3');      //0开头后面不能再是0
  p = p.replace(/\.{2,}/g,'.');                   //1..连续输入，点只能输入一个
  p = p.replace(/(\d+)(\.)(\d+)(\.)/g,'$1$2$3');  //1.2.3 去除隔断输入‘.’
  return p;
}
export const regFloat = function( p , w ){
let n = w || '';
  p = regBaseNum(p);
  if(n){//限制小数点后的位数 
      let reg = new RegExp("(\\d+)(.\\d{0,"+n+"})(\\d*)$");
      p = p.replace(reg,"$1$2");    
  }
  return p;
}
//整数/浮点数，非0开头小数（p > 1），第二参数控制小数点后位数
export const regFloatGtZero = function( p , w ){
let n = w || '';
  p = regFloat(p,n);
  p = p.replace(/^0*/,'');   //非0开头
  return p;
}
//可以是零开头整数，第二参数控制输入整数的位数
export const regZeroInt = function(p , w ){
let n = w || '';
  p = regBaseNum(p);
  p = p.replace(/(\d+)(\.\d*)/g,'$1'); //去除小数点及以后的数字
  if(n){
      let reg = new RegExp("(\\d{0,"+n+"})$");
      p = p.replace(reg,"$1");  
  }
  return p;
}

//非零开头整数，第二参数控制输入整数的位数
export const regInt = function (p , w ){
let n = w || '';
  p = regZeroInt(p,n);
  p = p.replace(/^0*/,'');  //非0开头
  return p;
}