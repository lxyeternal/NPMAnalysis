import p5 from "p5"
export {generalCoordinatesType} from "../Game/types";

export type spaceSettingsType = {
    placer: boolean,
    selectable: boolean
}

export interface IElement{
    movementPoint: p5.Vector|null
    position: p5.Vector
    movable: boolean
    selectable: boolean
    placer: boolean
    draw():void
    update():void
    defineDrawFn(drawFn: Function): void
    getId(): string,
    setUniqueId(id: string): void
    defineUpdateFn(updateFn: Function):void
    mouseClicked(mX:number, mY:number): void
    mouseMoved(mX:number, mY:number): void
    defineMouseCliced(mcFn: Function):void
    defineMouseMoved(mmFn: Function):void
    defineUnMovedFn(unMovedFn: Function):void
    getCurrentLayer(): number
    setCurrentLayer(layer: number): void
    setVariable(key: string, value: any): void
    setSpaceSettings(settings: spaceSettingsType):void
    updateVariables():void
    move(target: p5.Vector):void
    haveMovementPoint(): boolean
    letBePlacer():IElement
    letBeSelectable(): IElement
    letBeMovable(): IElement
}