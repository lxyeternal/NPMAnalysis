"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.P5Element = void 0;
const p5_1 = __importDefault(require("p5"));
class P5Element {
    constructor(p5, variables = { x: 0, y: 0 }) {
        this.id = String(Math.floor(Math.random() * 100000));
        this.drawFn = null;
        this.layer = 1;
        this.p5 = p5;
        this.updateFn = null;
        this.mouseClFn = null;
        this.mouseMovedFn = null;
        this.unMovedFn = null;
        this.alreadyUnmoved = true;
        this.variablesChangesFn = null;
        this.position = p5.createVector(variables.x, variables.y);
        this.velocity = p5.createVector(0, 0);
        this.accumulate = p5.createVector(0, 0);
        this.velLimit = 0;
        this.variables = variables;
        this.placer = false;
        this.selectable = false;
        this.selected = false;
        this.movementPoint = null;
        this.movable = false;
    }
    letBePlacer() {
        this.placer = true;
        return this;
    }
    letBeSelectable() {
        this.selectable = true;
        return this;
    }
    letBeMovable() {
        this.movable = true;
        return this;
    }
    haveMovementPoint() {
        return Boolean(this.movementPoint);
    }
    move(target = this.movementPoint) {
        if (this.movementPoint === null) {
            return;
        }
        if (this.p5.dist(target.x, target.y, this.position.x, this.position.y) <= this.velLimit) {
            this.position.x = target.x;
            this.position.y = target.y;
            this.velocity.set(0, 0);
            this.movementPoint = null;
            return;
        }
        let path = p5_1.default.Vector.sub(target, this.position);
        path.setMag(this.velLimit);
        let force = p5_1.default.Vector.sub(path, this.velocity);
        this.applyForce(force);
        return;
    }
    setSelected(value) {
        this.selected = value;
        return;
    }
    setVelLimit(limit) {
        this.velLimit = limit;
        return this;
    }
    /**
         * Применяет силу к объекту, чтобы заставить его меняться
         *
         * @param force  the P5 Vector created by static method.
    */
    applyForce(force) {
        this.accumulate.add(force);
    }
    updateVariables() {
        this.variables.x = this.position.x;
        this.variables.y = this.position.y;
        if (this.variablesChangesFn) {
            this.variablesChangesFn(this);
        }
        return;
    }
    defineUpdateVariablesFn(fn) {
        this.variablesChangesFn = fn;
    }
    getCurrentLayer() {
        return this.layer;
    }
    setCurrentLayer(layer) {
        this.layer = layer;
        return this;
    }
    defineUpdateFn(updateFn) {
        this.updateFn = updateFn;
        return this;
    }
    defineUnMovedFn(unMovedFn) {
        this.unMovedFn = unMovedFn;
        return this;
    }
    setUniqueId(id) {
        this.id = id;
        return;
    }
    getId() {
        return this.id;
    }
    /**
     * Определяет уникальную для объекта функцию отрисовки
     * @param drawFn Функция, описывающая отрисовку с использованием p5.js
     *               и возможность принимать аргумент variables
     * @returns Объект элемента
     */
    defineDrawFn(drawFn) {
        this.drawFn = drawFn;
        return this;
    }
    getCurrentVariables() {
        return Object.assign(Object.assign({}, this.variables), { x: this.position.x, y: this.position.y });
    }
    draw() {
        if (this.drawFn) {
            this.drawFn(this.getCurrentVariables());
        }
    }
    classicUpdate() {
        this.velocity.add(this.accumulate);
        this.velocity.limit(this.velLimit);
        this.position.add(this.velocity);
        this.accumulate.set(0, 0);
    }
    update() {
        this.updateVariables();
        this.classicUpdate();
        if (this.updateFn) {
            this.updateFn(this.getCurrentVariables());
        }
    }
    mouseClicked(mX, mY) {
        if (this.isItMe(mX, mY)) {
            if (this.id === 'selectAccepter') {
                console.log('i am here');
            }
            if (this.mouseClFn) {
                this.mouseClFn(this.getCurrentVariables());
                return true;
            }
        }
    }
    mouseMoved(mX, mY) {
        if (this.isItMe(mX, mY)) {
            if (this.mouseMovedFn) {
                this.alreadyUnmoved = false;
                this.mouseMovedFn(this.getCurrentVariables());
            }
        }
        else {
            this.unMove();
        }
    }
    unMove() {
        if (this.alreadyUnmoved === false) {
            this.alreadyUnmoved = true;
            if (this.unMovedFn) {
                this.unMovedFn(this.getCurrentVariables());
            }
        }
    }
    setUnMoveFn(unmFn) { }
    defineMouseCliced(mcFn) {
        this.mouseClFn = mcFn;
        return this;
    }
    defineMouseMoved(mmFn) {
        this.mouseMovedFn = mmFn;
        return this;
    }
    isItMe(x, y) {
        if (this.getCurrentVariables().width) {
            // Стоит указывать тип отрисовки угла, чтобы подстраивать просчёт клика
            if (this.getCurrentVariables().cornerType) {
                if ((x < this.getCurrentVariables().x + this.getCurrentVariables().width) && (x > this.getCurrentVariables().x) && (y > this.getCurrentVariables().y) && (y < this.getCurrentVariables().y + this.getCurrentVariables().height)) {
                    return true;
                }
                return false;
            }
            let realX = this.getCurrentVariables().x - this.getCurrentVariables().width / 2;
            let realY = this.getCurrentVariables().y - this.getCurrentVariables().height / 2;
            if ((x < realX + this.getCurrentVariables().width) && (x > realX) && (y > realY) && (y < realY + this.getCurrentVariables().height)) {
                return true;
            }
            return false;
        }
        return false;
    }
    setVariable(key, value) {
        this.variables[key] = value;
        return;
    }
    setSpaceSettings(settings = { placer: false, selectable: false }) {
        this.placer = settings.placer;
        this.selectable = settings.selectable;
        return;
    }
}
exports.P5Element = P5Element;
