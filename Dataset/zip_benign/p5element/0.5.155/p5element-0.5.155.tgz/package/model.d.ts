import p5 from "p5";
import { IElement, spaceSettingsType, generalCoordinatesType } from "./interface";
export declare class P5Element<variablesType extends {
    [key: string]: any;
}> implements IElement {
    drawFn: Function | null;
    updateFn: Function | null;
    mouseClFn: Function | null;
    mouseMovedFn: Function | null;
    unMovedFn: Function | null;
    variablesChangesFn: Function | null;
    layer: number;
    id: string;
    p5: p5;
    variables: generalCoordinatesType & variablesType;
    alreadyUnmoved: boolean;
    position: p5.Vector;
    velocity: p5.Vector;
    accumulate: p5.Vector;
    placer: boolean;
    selectable: boolean;
    selected: boolean;
    velLimit: number;
    movementPoint: p5.Vector | null;
    movable: boolean;
    constructor(p5: p5, variables?: (generalCoordinatesType & variablesType));
    letBePlacer(): this;
    letBeSelectable(): this;
    letBeMovable(): this;
    haveMovementPoint(): boolean;
    move(target?: p5.Vector): void;
    setSelected(value: boolean): void;
    setVelLimit(limit: number): this;
    /**
         * Применяет силу к объекту, чтобы заставить его меняться
         *
         * @param force  the P5 Vector created by static method.
    */
    applyForce(force: p5.Vector): void;
    updateVariables(): void;
    defineUpdateVariablesFn(fn: Function): void;
    getCurrentLayer(): number;
    setCurrentLayer(layer: number): P5Element<variablesType>;
    defineUpdateFn(updateFn: Function): P5Element<variablesType>;
    defineUnMovedFn(unMovedFn: Function): this;
    setUniqueId(id: string): void;
    getId(): string;
    /**
     * Определяет уникальную для объекта функцию отрисовки
     * @param drawFn Функция, описывающая отрисовку с использованием p5.js
     *               и возможность принимать аргумент variables
     * @returns Объект элемента
     */
    defineDrawFn(drawFn: Function): P5Element<variablesType>;
    getCurrentVariables(): variablesType;
    draw(): void;
    classicUpdate(): void;
    update(): void;
    mouseClicked(mX: number, mY: number): true | undefined;
    mouseMoved(mX: number, mY: number): void;
    unMove(): void;
    setUnMoveFn(unmFn: Function): void;
    defineMouseCliced(mcFn: Function): P5Element<variablesType>;
    defineMouseMoved(mmFn: Function): P5Element<variablesType>;
    private isItMe;
    setVariable(key: "x" | "y" | keyof variablesType, value: any): void;
    setSpaceSettings(settings?: spaceSettingsType): void;
}
