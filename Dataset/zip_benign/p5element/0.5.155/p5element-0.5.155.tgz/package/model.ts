import p5 from "p5";
import { IElement, spaceSettingsType, generalCoordinatesType } from "./interface";

export class P5Element<variablesType extends {[key: string]: any}> implements IElement {
    drawFn: Function|null
    updateFn: Function|null
    mouseClFn: Function|null
    mouseMovedFn: Function|null
    unMovedFn: Function|null
    variablesChangesFn: Function |null
    layer: number
    id: string
    p5: p5
    variables: generalCoordinatesType & variablesType
    alreadyUnmoved: boolean
    position: p5.Vector
    velocity: p5.Vector
    accumulate: p5.Vector
    placer: boolean
    selectable: boolean
    selected: boolean
    velLimit: number
    movementPoint: p5.Vector|null
    movable: boolean
    constructor(p5: p5, variables: (generalCoordinatesType & variablesType) = {x: 0, y:0} as generalCoordinatesType & variablesType){
        this.id = String(Math.floor(Math.random() * 100000))
        this.drawFn = null
        this.layer = 1
        this.p5 = p5
        this.updateFn = null
        this.mouseClFn = null
        this.mouseMovedFn = null
        this.unMovedFn = null
        this.alreadyUnmoved = true
        this.variablesChangesFn = null
        this.position = p5.createVector(variables.x, variables.y)
        this.velocity = p5.createVector(0, 0)
        this.accumulate = p5.createVector(0,0)
        this.velLimit = 0
        this.variables = variables
        this.placer = false
        this.selectable = false
        this.selected = false
        this.movementPoint = null
        this.movable = false
    }
    letBePlacer(){
        this.placer = true
        return this
    }
    letBeSelectable(){
        this.selectable = true
        return this
    }
    letBeMovable(){
        this.movable = true
        return this
    }
    haveMovementPoint(){
        return Boolean(this.movementPoint)
    }
    move(target:p5.Vector = this.movementPoint as p5.Vector){
        if (this.movementPoint === null){
            return
        }
        if (this.p5.dist(target.x, target.y, this.position.x, this.position.y) <= this.velLimit){
        this.position.x = target.x
        this.position.y = target.y
          this.velocity.set(0, 0)
          this.movementPoint = null
          return
        }
        let path = p5.Vector.sub(target, this.position)
        path.setMag(this.velLimit)
        let force = p5.Vector.sub(path, this.velocity)
        this.applyForce(force)
        return
      }
    setSelected(value: boolean){
        this.selected = value
        return
    }
    setVelLimit(limit: number){
        this.velLimit = limit
        return this
    }
    /**
         * Применяет силу к объекту, чтобы заставить его меняться
         *
         * @param force  the P5 Vector created by static method.
    */
    applyForce(force: p5.Vector){
        this.accumulate.add(force)
    }
    updateVariables(): void {
        this.variables.x = this.position.x
        this.variables.y = this.position.y
        if (this.variablesChangesFn){
            this.variablesChangesFn(this)
        }
        return
    }
    defineUpdateVariablesFn(fn: Function){
        this.variablesChangesFn = fn
    }
    getCurrentLayer(): number {
       return this.layer
    }
    setCurrentLayer(layer: number): P5Element<variablesType> {
        this.layer = layer
        return this
    }
    defineUpdateFn(updateFn: Function): P5Element<variablesType> {
        this.updateFn = updateFn
        return this
    }
    defineUnMovedFn(unMovedFn: Function){
        this.unMovedFn = unMovedFn
        return this
    }
    setUniqueId(id: string){
        this.id = id
        return
    }
    getId(){
        return this.id
    }
    /**
     * Определяет уникальную для объекта функцию отрисовки
     * @param drawFn Функция, описывающая отрисовку с использованием p5.js
     *               и возможность принимать аргумент variables
     * @returns Объект элемента
     */
    defineDrawFn(drawFn: Function): P5Element<variablesType> {
        this.drawFn = drawFn
        return this
    }
    getCurrentVariables():variablesType{
        return {
            ...this.variables,
            x: this.position.x,
            y: this.position.y
        }
    }
    draw(): void {
        if(this.drawFn){
            this.drawFn(this.getCurrentVariables())
        }
    }
    classicUpdate(){
        this.velocity.add(this.accumulate)
        this.velocity.limit(this.velLimit)
        this.position.add(this.velocity)
        this.accumulate.set(0,0)
    }
    update():void {
        this.updateVariables()
        this.classicUpdate()
        if(this.updateFn){
            this.updateFn(this.getCurrentVariables())
        }
    }
    mouseClicked(mX:number, mY:number){
        if (this.isItMe(mX, mY)){
            if(this.id === 'selectAccepter'){
                console.log('i am here')
            }
            if(this.mouseClFn){
                this.mouseClFn(this.getCurrentVariables())
                return true
             }
        }
    }
    mouseMoved(mX:number, mY:number){
        if (this.isItMe(mX, mY)){
            if(this.mouseMovedFn){
                this.alreadyUnmoved = false
                this.mouseMovedFn(this.getCurrentVariables())
            }
        }
        else {
            this.unMove()
        }
    }
    unMove(){
        if (this.alreadyUnmoved === false){
            this.alreadyUnmoved = true
            if (this.unMovedFn){
                this.unMovedFn(this.getCurrentVariables())
            }
        }
    }
    setUnMoveFn(unmFn: Function){}
    defineMouseCliced(mcFn: Function): P5Element<variablesType> {
        this.mouseClFn = mcFn
        return this
    }
    defineMouseMoved(mmFn: Function): P5Element<variablesType>{
        this.mouseMovedFn = mmFn
        return this
    }
    private isItMe(x: number, y: number): boolean {
        if (this.getCurrentVariables().width){
            // Стоит указывать тип отрисовки угла, чтобы подстраивать просчёт клика
            if (this.getCurrentVariables().cornerType){
                if ((x < this.getCurrentVariables().x + this.getCurrentVariables().width) &&(x > this.getCurrentVariables().x) &&(y > this.getCurrentVariables().y) && (y < this.getCurrentVariables().y + this.getCurrentVariables().height)){
                    return true
                }
                return false
            }
            let realX = this.getCurrentVariables().x - this.getCurrentVariables().width/2
            let realY =  this.getCurrentVariables().y - this.getCurrentVariables().height/2
            if ((x < realX + this.getCurrentVariables().width) &&(x > realX) &&(y > realY) && (y < realY + this.getCurrentVariables().height)){
                return true
            }
            return false
        }
        return false
    }
    setVariable(key: "x"|"y"|keyof variablesType, value: any): void {
        this.variables[key] = value
        return
    }
    setSpaceSettings(settings: spaceSettingsType = {placer: false, selectable: false}): void {
        this.placer = settings.placer
        this.selectable = settings.selectable
        return
    }
}