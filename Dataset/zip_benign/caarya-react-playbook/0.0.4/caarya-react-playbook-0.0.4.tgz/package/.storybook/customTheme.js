import { create } from "@storybook/theming/create";

export default create({
  base: "dark",

  // colorPrimary: "#bb86fc",
  // colorSecondary: "#03dac5",

  // // UI
  // appBg: "black",
  // appContentBg: "white",
  // appBorderColor: "grey",
  // appBorderRadius: 4,

  // // Typography
  // fontBase: '"Open Sans", sans-serif',
  // fontCode: "monospace",

  // // Text colors
  // textColor: "white",
  // textInverseColor: "rgba(0,0,0,0.9)",

  // // Toolbar default and active colors
  // barTextColor: "whitesmoke",
  // barSelectedColor: "white",
  // barBg: "#03dac5",

  // // Form colors
  // inputBg: "white",
  // inputBorder: "silver",
  // inputTextColor: "black",
  // inputBorderRadius: 4,

  brandTitle: "The Caarya React Playbook",
  brandUrl: "https://playbook.caarya.in", 
  brandImage: undefined,
});
