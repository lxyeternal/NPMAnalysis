import { addons } from '@storybook/addons';
import { themes } from '@storybook/theming';
import custom from './customTheme';

addons.setConfig({
    theme: custom,
});