import { addParameters } from '@storybook/react';
import { configure } from '@storybook/react';

addParameters({
  options: {
    /**
     * display the top-level grouping as a "root" in the sidebar
     * @type {Boolean}
     */
    showRoots: true,
  },
});

/**
 * Load order 
   - Overview 
   - Guides
   - Atoms
   - Molecules
   - Organisms
   - Templates
 */


configure(
  [
    require.context('../stories/overview', true, /\.stories\.(js|mdx)$/),
    require.context('../stories/guides', true, /\.stories\.mdx$/),
    require.context('../stories/atoms', true, /\.stories\.mdx$/),
    require.context('../stories/molecules', true, /\.stories\.mdx$/),
    require.context('../stories/organisms', true, /\.stories\.mdx$/),
    require.context('../stories/templates' , true, /\.stories\.(js|mdx)$/)
  ],
  module
);