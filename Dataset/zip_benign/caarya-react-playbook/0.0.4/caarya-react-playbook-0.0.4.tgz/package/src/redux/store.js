import { createStore, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import rootReducer from './index';

const logger = (store) => (next) => (action) => {
    console.log("Dispatch Action\n", action);
    const result = next(action);
    console.log("Next State\n", store.getState());
    return result;
};

export default applyMiddleware(thunk, logger)(createStore)(rootReducer);