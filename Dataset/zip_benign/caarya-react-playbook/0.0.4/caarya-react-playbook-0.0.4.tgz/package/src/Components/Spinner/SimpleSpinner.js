import React from 'react';
import './style.scss';

export default function (props) {
    return (
        <div className="simple-spinner" style={{width: props.width,height: props.height,...props.style}} />
    );
}