import React from "react";

export default function (props) {
  return (
    <nav>
      <ul>
          <li>Home</li>
      </ul>
    </nav>
  );
}
