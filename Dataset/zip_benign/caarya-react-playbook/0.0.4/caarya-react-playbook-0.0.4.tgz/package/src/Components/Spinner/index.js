import SimpleSpinner from './SimpleSpinner';

export { SimpleSpinner };