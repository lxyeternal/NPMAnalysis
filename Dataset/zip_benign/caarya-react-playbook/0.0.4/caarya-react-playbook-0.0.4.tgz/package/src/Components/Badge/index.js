import React from 'react';
import './style.css';

export default function (props) {
    return (
        <p className="badge" style={{backgroundColor: props.color}}>{props.title}</p>
    );
}