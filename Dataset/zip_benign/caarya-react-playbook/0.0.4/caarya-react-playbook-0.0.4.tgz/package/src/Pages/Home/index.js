import React from 'react';
import NavBar from '../../Components/NavBar';



function Home (props) {
    return (
        <div className="home">
            <NavBar />

            Home
        </div>
    );
}

export default Home;

