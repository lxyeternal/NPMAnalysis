import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Home from './Pages/Home';
import './App.scss';
import './SassyCaarya/master.sass';


function App() {
  return (
    <div className="app">
      <Router>
        <Switch>
          <Route exact path="/" render={() => <Home/>} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;
