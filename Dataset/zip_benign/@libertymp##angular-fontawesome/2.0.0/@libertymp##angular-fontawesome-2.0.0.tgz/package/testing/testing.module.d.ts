import { ModuleWithProviders } from '@angular/core';
import { FaTestingConfig } from './config';
import * as i0 from "@angular/core";
import * as i1 from "@fortawesome/angular-fontawesome";
export declare class FontAwesomeTestingModule {
    /**
     * Use this method to configure the module’s behaviour when trying to add icons
     * and icon packs to the mock icon library.
     */
    static forRoot(config?: Partial<FaTestingConfig>): ModuleWithProviders<FontAwesomeTestingModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FontAwesomeTestingModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FontAwesomeTestingModule, never, never, [typeof i1.FontAwesomeModule]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FontAwesomeTestingModule>;
}
