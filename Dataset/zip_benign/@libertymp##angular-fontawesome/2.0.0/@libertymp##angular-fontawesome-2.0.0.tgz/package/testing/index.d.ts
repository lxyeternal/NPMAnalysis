/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@libertymp/angular-fontawesome/testing" />
export * from './public_api';
