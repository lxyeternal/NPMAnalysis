import { FaIconLibraryInterface, IconDefinition, IconName, IconPrefix } from '@fortawesome/angular-fontawesome';
import { FaTestingConfig } from '../config';
import * as i0 from "@angular/core";
export declare const dummyIcon: IconDefinition;
export declare const ADD_ICON_MESSAGE = "Attempt to add an icon to the MockFaIconLibrary.";
export declare class MockFaIconLibrary implements FaIconLibraryInterface {
    private config;
    constructor(config: FaTestingConfig);
    addIcons(): void;
    addIconPacks(): void;
    getIconDefinition(prefix: IconPrefix, name: IconName): IconDefinition;
    static ɵfac: i0.ɵɵFactoryDeclaration<MockFaIconLibrary, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<MockFaIconLibrary>;
}
