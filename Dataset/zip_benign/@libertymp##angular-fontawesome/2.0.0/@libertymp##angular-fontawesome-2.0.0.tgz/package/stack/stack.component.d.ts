import { ElementRef, OnChanges, OnInit, Renderer2, SimpleChanges } from '@angular/core';
import { SizeProp } from '@fortawesome/fontawesome-svg-core';
import * as i0 from "@angular/core";
export declare class FaStackComponent implements OnInit, OnChanges {
    private renderer;
    private elementRef;
    /**
     * Size of the stacked icon.
     * Note that stacked icon is by default 2 times bigger, than non-stacked icon.
     * You'll need to set size using custom CSS to align stacked icon with a
     * simple one. E.g. `fa-stack { font-size: 0.5em; }`.
     */
    size?: SizeProp;
    constructor(renderer: Renderer2, elementRef: ElementRef);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FaStackComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaStackComponent, "fa-stack", never, { "size": { "alias": "size"; "required": false; }; }, {}, never, ["*"], true, never>;
}
