import { OnChanges, SimpleChanges } from '@angular/core';
import * as i0 from "@angular/core";
export declare class FaStackItemSizeDirective implements OnChanges {
    /**
     * Specify whether icon inside {@link FaStackComponent} should be rendered in
     * regular size (1x) or as a larger icon (2x).
     */
    stackItemSize: '1x' | '2x';
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FaStackItemSizeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FaStackItemSizeDirective, "fa-icon[stackItemSize],fa-duotone-icon[stackItemSize]", never, { "stackItemSize": { "alias": "stackItemSize"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}
