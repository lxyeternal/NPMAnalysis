import { IconLookup } from '../../types';
export declare const faWarnIfIconDefinitionMissing: (iconSpec: IconLookup) => never;
