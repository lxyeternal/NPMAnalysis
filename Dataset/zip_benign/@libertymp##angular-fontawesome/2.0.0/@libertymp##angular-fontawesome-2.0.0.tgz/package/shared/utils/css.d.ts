import { FaConfig } from '../../config';
export declare const autoCssId = "fa-auto-css";
/**
 * Ensure that Font Awesome CSS is inserted into the page.
 *
 * SVG Core has the same logic to insert the same styles into the page, however
 * it's not aware of Angular SSR and therefore styles won't be added in that
 * context leading to https://github.com/FortAwesome/angular-fontawesome/issues/48.
 * That's why the same logic is duplicated here.
 *
 * @param document - Document.
 * @param config - Font Awesome configuration.
 */
export declare function ensureCss(document: Document, config: FaConfig): void;
