import { IconDefinition, IconLookup, IconPrefix, IconProp } from '../../types';
/**
 * Normalizing icon spec.
 */
export declare const faNormalizeIconSpec: (iconSpec: IconProp | IconDefinition, defaultPrefix: IconPrefix) => IconLookup | IconDefinition;
