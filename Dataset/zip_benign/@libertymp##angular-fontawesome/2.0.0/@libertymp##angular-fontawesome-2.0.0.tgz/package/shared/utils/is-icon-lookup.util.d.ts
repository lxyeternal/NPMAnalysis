import { IconLookup, IconProp } from '../../types';
/**
 * Returns if is IconLookup or not.
 */
export declare const isIconLookup: (i: IconProp) => i is IconLookup;
