/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@libertymp/angular-fontawesome" />
export * from './public_api';
