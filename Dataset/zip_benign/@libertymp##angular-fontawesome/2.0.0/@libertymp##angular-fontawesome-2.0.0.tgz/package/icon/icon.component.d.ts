import { OnChanges, SimpleChanges } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { FaSymbol, FlipProp, IconDefinition as CoreIconDefinition, IconParams, PullProp, RotateProp, SizeProp, Transform } from '@fortawesome/fontawesome-svg-core';
import { FaConfig } from '../config';
import { FaIconLibrary } from '../icon-library';
import { AnimationProp } from '../shared/models/props.model';
import { FaStackItemSizeDirective } from '../stack/stack-item-size.directive';
import { FaStackComponent } from '../stack/stack.component';
import { IconDefinition, IconProp } from '../types';
import * as i0 from "@angular/core";
export declare class FaIconComponent implements OnChanges {
    private sanitizer;
    private config;
    private iconLibrary;
    private stackItem;
    icon: IconProp;
    /**
     * Specify a title for the icon.
     *
     * This text will be displayed in a tooltip on hover and presented to the
     * screen readers.
     */
    title?: string;
    /**
     * Icon animation.
     *
     * Most of the animations are only available when using Font Awesome 6. With
     * Font Awesome 5, only 'spin' and 'spin-pulse' are supported.
     */
    animation?: AnimationProp;
    mask?: IconProp;
    flip?: FlipProp;
    size?: SizeProp;
    pull?: PullProp;
    border?: boolean;
    inverse?: boolean;
    symbol?: FaSymbol;
    rotate?: RotateProp;
    fixedWidth?: boolean;
    transform?: string | Transform;
    /**
     * Specify the `role` attribute for the rendered <svg> element.
     *
     * @default 'img'
     */
    a11yRole: string;
    /**
     * Specify the `id` attribute for the rendered <svg> element.
     *
     */
    svgId: string;
    renderedIconHTML: SafeHtml;
    private document;
    constructor(sanitizer: DomSanitizer, config: FaConfig, iconLibrary: FaIconLibrary, stackItem: FaStackItemSizeDirective, stack: FaStackComponent);
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Programmatically trigger rendering of the icon.
     *
     * This method is useful, when creating {@link FaIconComponent} dynamically or
     * changing its inputs programmatically as in these cases icon won't be
     * re-rendered automatically.
     */
    render(): void;
    protected findIconDefinition(i: IconProp | IconDefinition): CoreIconDefinition | null;
    protected buildParams(): IconParams;
    static ɵfac: i0.ɵɵFactoryDeclaration<FaIconComponent, [null, null, null, { optional: true; }, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaIconComponent, "fa-icon", never, { "icon": { "alias": "icon"; "required": false; }; "title": { "alias": "title"; "required": false; }; "animation": { "alias": "animation"; "required": false; }; "mask": { "alias": "mask"; "required": false; }; "flip": { "alias": "flip"; "required": false; }; "size": { "alias": "size"; "required": false; }; "pull": { "alias": "pull"; "required": false; }; "border": { "alias": "border"; "required": false; }; "inverse": { "alias": "inverse"; "required": false; }; "symbol": { "alias": "symbol"; "required": false; }; "rotate": { "alias": "rotate"; "required": false; }; "fixedWidth": { "alias": "fixedWidth"; "required": false; }; "transform": { "alias": "transform"; "required": false; }; "a11yRole": { "alias": "a11yRole"; "required": false; }; "svgId": { "alias": "svgId"; "required": false; }; }, {}, never, never, true, never>;
}
