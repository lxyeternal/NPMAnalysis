import { IconDefinition as CoreIconDefinition, IconParams } from '@fortawesome/fontawesome-svg-core';
import { IconDefinition, IconProp } from '../types';
import { FaIconComponent } from './icon.component';
import * as i0 from "@angular/core";
export declare class FaDuotoneIconComponent extends FaIconComponent {
    /**
     * Swap the default opacity of each duotone icon’s layers. This will make an
     * icon’s primary layer have the default opacity of 40% rather than its
     * secondary layer.
     *
     * @default false
     */
    swapOpacity?: 'true' | 'false' | boolean;
    /**
     * Customize the opacity of the primary icon layer.
     * Valid values are in range [0, 1.0].
     *
     * @default 1.0
     */
    primaryOpacity?: string | number;
    /**
     * Customize the opacity of the secondary icon layer.
     * Valid values are in range [0, 1.0].
     *
     * @default 0.4
     */
    secondaryOpacity?: string | number;
    /**
     * Customize the color of the primary icon layer.
     * Accepts any valid CSS color value.
     *
     * @default CSS inherited color
     */
    primaryColor?: string;
    /**
     * Customize the color of the secondary icon layer.
     * Accepts any valid CSS color value.
     *
     * @default CSS inherited color
     */
    secondaryColor?: string;
    protected findIconDefinition(i: IconProp | IconDefinition): CoreIconDefinition | null;
    protected buildParams(): IconParams;
    static ɵfac: i0.ɵɵFactoryDeclaration<FaDuotoneIconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaDuotoneIconComponent, "fa-duotone-icon", never, { "swapOpacity": { "alias": "swapOpacity"; "required": false; }; "primaryOpacity": { "alias": "primaryOpacity"; "required": false; }; "secondaryOpacity": { "alias": "secondaryOpacity"; "required": false; }; "primaryColor": { "alias": "primaryColor"; "required": false; }; "secondaryColor": { "alias": "secondaryColor"; "required": false; }; }, {}, never, never, true, never>;
}
