import { IconDefinition, IconName, IconPack, IconPrefix } from './types';
import * as i0 from "@angular/core";
export interface FaIconLibraryInterface {
    addIcons(...icons: IconDefinition[]): void;
    addIconPacks(...packs: IconPack[]): void;
    getIconDefinition(prefix: IconPrefix, name: IconName): IconDefinition | null;
}
export declare class FaIconLibrary implements FaIconLibraryInterface {
    private definitions;
    addIcons(...icons: IconDefinition[]): void;
    addIconPacks(...packs: IconPack[]): void;
    getIconDefinition(prefix: IconPrefix, name: IconName): IconDefinition | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<FaIconLibrary, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<FaIconLibrary>;
}
