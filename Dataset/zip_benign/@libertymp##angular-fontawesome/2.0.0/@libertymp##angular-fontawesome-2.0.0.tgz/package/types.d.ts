import { IconName as CoreIconName, IconPrefix as CoreIconPrefix } from '@fortawesome/fontawesome-svg-core';
export type IconPrefix = CoreIconPrefix | (string & {});
export type IconName = CoreIconName | (string & {});
export interface IconLookup {
    prefix: IconPrefix;
    iconName: IconName;
}
export interface IconDefinition {
    prefix: IconPrefix;
    iconName: IconName;
    icon: [
        number,
        number,
        string[],
        string,
        // unicode
        string | string[]
    ];
}
export interface IconPack {
    [key: string]: IconDefinition;
}
export type IconProp = IconName | [IconPrefix, IconName] | IconLookup;
