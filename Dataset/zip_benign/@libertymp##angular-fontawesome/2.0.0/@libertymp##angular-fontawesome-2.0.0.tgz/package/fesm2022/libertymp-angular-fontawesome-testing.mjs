import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import { FaIconLibrary, FontAwesomeModule } from '@fortawesome/angular-fontawesome';

class FaTestingConfig {
    constructor() {
        /**
         * What to do when `addIcons()` or `addIconPacks()` is invoked on
         * the FaIconLibrary provided by the FontAwesomeTestingModule.
         *
         * Possible values are:
         * - `'throwError'` -  Throw an error.
         * - `'logWarning'` - Write a warning to the console.
         * - `'noop'` - Do nothing.
         *
         * Note that in any case the icon will not be added to the library.
         *
         * @default 'throwError'
         */
        this.whenAddingIcons = 'throwError';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaTestingConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaTestingConfig, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaTestingConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });

const dummyIcon = {
    prefix: 'fad',
    iconName: 'dummy',
    icon: [512, 512, [], '', 'M50 50 H462 V462 H50 Z'],
};
const ADD_ICON_MESSAGE = 'Attempt to add an icon to the MockFaIconLibrary.';
class MockFaIconLibrary {
    constructor(config) {
        this.config = config;
    }
    addIcons() {
        if (this.config.whenAddingIcons === 'throwError') {
            throw new Error(ADD_ICON_MESSAGE);
        }
        if (this.config.whenAddingIcons === 'logWarning') {
            console.warn(ADD_ICON_MESSAGE);
        }
    }
    addIconPacks() {
        if (this.config.whenAddingIcons === 'throwError') {
            throw new Error(ADD_ICON_MESSAGE);
        }
        if (this.config.whenAddingIcons === 'logWarning') {
            console.warn(ADD_ICON_MESSAGE);
        }
    }
    getIconDefinition(prefix, name) {
        return dummyIcon;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: MockFaIconLibrary, deps: [{ token: FaTestingConfig }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: MockFaIconLibrary, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: MockFaIconLibrary, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: FaTestingConfig }] });

class FontAwesomeTestingModule {
    /**
     * Use this method to configure the module’s behaviour when trying to add icons
     * and icon packs to the mock icon library.
     */
    static forRoot(config = {}) {
        return {
            ngModule: FontAwesomeTestingModule,
            providers: [
                {
                    provide: FaIconLibrary,
                    useExisting: MockFaIconLibrary,
                },
                {
                    provide: FaTestingConfig,
                    useFactory: () => Object.assign(new FaTestingConfig(), config),
                },
            ],
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FontAwesomeTestingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.8", ngImport: i0, type: FontAwesomeTestingModule, exports: [FontAwesomeModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FontAwesomeTestingModule, providers: [{ provide: FaIconLibrary, useExisting: MockFaIconLibrary }], imports: [FontAwesomeModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FontAwesomeTestingModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [FontAwesomeModule],
                    providers: [{ provide: FaIconLibrary, useExisting: MockFaIconLibrary }],
                }]
        }] });

/**
 * Generated bundle index. Do not edit.
 */

export { FaTestingConfig, FontAwesomeTestingModule, MockFaIconLibrary };
//# sourceMappingURL=libertymp-angular-fontawesome-testing.mjs.map
