import { ElementRef, OnChanges, OnInit, Renderer2, SimpleChanges } from '@angular/core';
import { SizeProp } from '@fortawesome/fontawesome-svg-core';
import { FaConfig } from '../config';
import * as i0 from "@angular/core";
/**
 * Fontawesome layers.
 */
export declare class FaLayersComponent implements OnInit, OnChanges {
    private renderer;
    private elementRef;
    private config;
    size?: SizeProp;
    fixedWidth?: boolean;
    private document;
    constructor(renderer: Renderer2, elementRef: ElementRef, config: FaConfig);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FaLayersComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaLayersComponent, "fa-layers", never, { "size": { "alias": "size"; "required": false; }; "fixedWidth": { "alias": "fixedWidth"; "required": false; }; }, {}, never, ["*"], true, never>;
}
