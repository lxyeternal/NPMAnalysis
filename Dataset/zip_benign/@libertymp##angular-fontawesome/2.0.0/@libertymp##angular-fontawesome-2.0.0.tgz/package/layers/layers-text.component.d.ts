import { OnChanges, SimpleChanges } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { FlipProp, PullProp, RotateProp, SizeProp, TextParams, Transform } from '@fortawesome/fontawesome-svg-core';
import { FaLayersComponent } from './layers.component';
import * as i0 from "@angular/core";
export declare class FaLayersTextComponent implements OnChanges {
    private parent;
    private sanitizer;
    content: string;
    title?: string;
    flip?: FlipProp;
    size?: SizeProp;
    pull?: PullProp;
    border?: boolean;
    inverse?: boolean;
    rotate?: RotateProp;
    fixedWidth?: boolean;
    transform?: string | Transform;
    renderedHTML: SafeHtml;
    private document;
    private config;
    constructor(parent: FaLayersComponent, sanitizer: DomSanitizer);
    ngOnChanges(changes: SimpleChanges): void;
    /**
     * Updating params by component props.
     */
    protected buildParams(): TextParams;
    private updateContent;
    static ɵfac: i0.ɵɵFactoryDeclaration<FaLayersTextComponent, [{ optional: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaLayersTextComponent, "fa-layers-text", never, { "content": { "alias": "content"; "required": false; }; "title": { "alias": "title"; "required": false; }; "flip": { "alias": "flip"; "required": false; }; "size": { "alias": "size"; "required": false; }; "pull": { "alias": "pull"; "required": false; }; "border": { "alias": "border"; "required": false; }; "inverse": { "alias": "inverse"; "required": false; }; "rotate": { "alias": "rotate"; "required": false; }; "fixedWidth": { "alias": "fixedWidth"; "required": false; }; "transform": { "alias": "transform"; "required": false; }; }, {}, never, never, true, never>;
}
