import { OnChanges, SimpleChanges } from '@angular/core';
import { DomSanitizer, SafeHtml } from '@angular/platform-browser';
import { CounterParams } from '@fortawesome/fontawesome-svg-core';
import { FaLayersComponent } from './layers.component';
import * as i0 from "@angular/core";
export declare class FaLayersCounterComponent implements OnChanges {
    private parent;
    private sanitizer;
    content: string;
    title?: string;
    position?: 'bottom-right' | 'bottom-left' | 'top-right' | 'top-left';
    renderedHTML: SafeHtml;
    private document;
    private config;
    constructor(parent: FaLayersComponent, sanitizer: DomSanitizer);
    ngOnChanges(changes: SimpleChanges): void;
    protected buildParams(): CounterParams;
    private updateContent;
    static ɵfac: i0.ɵɵFactoryDeclaration<FaLayersCounterComponent, [{ optional: true; }, null]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FaLayersCounterComponent, "fa-layers-counter", never, { "content": { "alias": "content"; "required": false; }; "title": { "alias": "title"; "required": false; }; "position": { "alias": "position"; "required": false; }; }, {}, never, never, true, never>;
}
