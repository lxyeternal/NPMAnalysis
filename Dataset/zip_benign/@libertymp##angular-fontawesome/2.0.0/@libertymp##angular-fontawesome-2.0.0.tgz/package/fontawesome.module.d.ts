import * as i0 from "@angular/core";
import * as i1 from "./icon/icon.component";
import * as i2 from "./icon/duotone-icon.component";
import * as i3 from "./layers/layers.component";
import * as i4 from "./layers/layers-text.component";
import * as i5 from "./layers/layers-counter.component";
import * as i6 from "./stack/stack.component";
import * as i7 from "./stack/stack-item-size.directive";
export declare class FontAwesomeModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FontAwesomeModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FontAwesomeModule, never, [typeof i1.FaIconComponent, typeof i2.FaDuotoneIconComponent, typeof i3.FaLayersComponent, typeof i4.FaLayersTextComponent, typeof i5.FaLayersCounterComponent, typeof i6.FaStackComponent, typeof i7.FaStackItemSizeDirective], [typeof i1.FaIconComponent, typeof i2.FaDuotoneIconComponent, typeof i3.FaLayersComponent, typeof i4.FaLayersTextComponent, typeof i5.FaLayersCounterComponent, typeof i6.FaStackComponent, typeof i7.FaStackItemSizeDirective]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FontAwesomeModule>;
}
