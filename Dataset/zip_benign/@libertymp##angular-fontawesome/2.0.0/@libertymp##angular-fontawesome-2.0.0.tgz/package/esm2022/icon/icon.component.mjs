import { DOCUMENT } from '@angular/common';
import { Component, HostBinding, inject, Input, Optional } from '@angular/core';
import { icon, parse, } from '@fortawesome/fontawesome-svg-core';
import { faWarnIfIconDefinitionMissing } from '../shared/errors/warn-if-icon-html-missing';
import { faWarnIfIconSpecMissing } from '../shared/errors/warn-if-icon-spec-missing';
import { faClassList } from '../shared/utils/classlist.util';
import { ensureCss } from '../shared/utils/css';
import { faNormalizeIconSpec } from '../shared/utils/normalize-icon-spec.util';
import * as i0 from "@angular/core";
import * as i1 from "@angular/platform-browser";
import * as i2 from "../config";
import * as i3 from "../icon-library";
import * as i4 from "../stack/stack-item-size.directive";
import * as i5 from "../stack/stack.component";
export class FaIconComponent {
    constructor(sanitizer, config, iconLibrary, stackItem, stack) {
        this.sanitizer = sanitizer;
        this.config = config;
        this.iconLibrary = iconLibrary;
        this.stackItem = stackItem;
        this.document = inject(DOCUMENT);
        if (stack != null && stackItem == null) {
            console.error('FontAwesome: fa-icon and fa-duotone-icon elements must specify stackItemSize attribute when wrapped into ' +
                'fa-stack. Example: <fa-icon stackItemSize="2x"></fa-icon>.');
        }
    }
    ngOnChanges(changes) {
        if (this.icon == null && this.config.fallbackIcon == null) {
            faWarnIfIconSpecMissing();
            return;
        }
        if (changes) {
            const iconDefinition = this.findIconDefinition(this.icon ?? this.config.fallbackIcon);
            if (iconDefinition != null) {
                const params = this.buildParams();
                ensureCss(this.document, this.config);
                const renderedIcon = icon(iconDefinition, params);
                this.renderedIconHTML = this.sanitizer.bypassSecurityTrustHtml(renderedIcon.html.join('\n'));
            }
        }
    }
    /**
     * Programmatically trigger rendering of the icon.
     *
     * This method is useful, when creating {@link FaIconComponent} dynamically or
     * changing its inputs programmatically as in these cases icon won't be
     * re-rendered automatically.
     */
    render() {
        this.ngOnChanges({});
    }
    findIconDefinition(i) {
        const lookup = faNormalizeIconSpec(i, this.config.defaultPrefix);
        if ('icon' in lookup) {
            return lookup;
        }
        const definition = this.iconLibrary.getIconDefinition(lookup.prefix, lookup.iconName);
        if (definition != null) {
            return definition;
        }
        faWarnIfIconDefinitionMissing(lookup);
        return null;
    }
    buildParams() {
        const classOpts = {
            flip: this.flip,
            animation: this.animation,
            border: this.border,
            inverse: this.inverse,
            size: this.size || null,
            pull: this.pull || null,
            rotate: this.rotate || null,
            fixedWidth: typeof this.fixedWidth === 'boolean' ? this.fixedWidth : this.config.fixedWidth,
            stackItemSize: this.stackItem != null ? this.stackItem.stackItemSize : null,
        };
        const parsedTransform = typeof this.transform === 'string' ? parse.transform(this.transform) : this.transform;
        return {
            title: this.title,
            transform: parsedTransform,
            classes: faClassList(classOpts),
            mask: this.mask != null ? this.findIconDefinition(this.mask) : null,
            symbol: this.symbol,
            attributes: {
                role: this.a11yRole,
                id: this.svgId,
            },
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaIconComponent, deps: [{ token: i1.DomSanitizer }, { token: i2.FaConfig }, { token: i3.FaIconLibrary }, { token: i4.FaStackItemSizeDirective, optional: true }, { token: i5.FaStackComponent, optional: true }], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: FaIconComponent, isStandalone: true, selector: "fa-icon", inputs: { icon: "icon", title: "title", animation: "animation", mask: "mask", flip: "flip", size: "size", pull: "pull", border: "border", inverse: "inverse", symbol: "symbol", rotate: "rotate", fixedWidth: "fixedWidth", transform: "transform", a11yRole: "a11yRole", svgId: "svgId" }, host: { properties: { "attr.title": "title", "innerHTML": "this.renderedIconHTML" }, classAttribute: "ng-fa-icon" }, usesOnChanges: true, ngImport: i0, template: ``, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'fa-icon',
                    standalone: true,
                    template: ``,
                    host: {
                        class: 'ng-fa-icon',
                        '[attr.title]': 'title',
                    },
                }]
        }], ctorParameters: () => [{ type: i1.DomSanitizer }, { type: i2.FaConfig }, { type: i3.FaIconLibrary }, { type: i4.FaStackItemSizeDirective, decorators: [{
                    type: Optional
                }] }, { type: i5.FaStackComponent, decorators: [{
                    type: Optional
                }] }], propDecorators: { icon: [{
                type: Input
            }], title: [{
                type: Input
            }], animation: [{
                type: Input
            }], mask: [{
                type: Input
            }], flip: [{
                type: Input
            }], size: [{
                type: Input
            }], pull: [{
                type: Input
            }], border: [{
                type: Input
            }], inverse: [{
                type: Input
            }], symbol: [{
                type: Input
            }], rotate: [{
                type: Input
            }], fixedWidth: [{
                type: Input
            }], transform: [{
                type: Input
            }], a11yRole: [{
                type: Input
            }], svgId: [{
                type: Input
            }], renderedIconHTML: [{
                type: HostBinding,
                args: ['innerHTML']
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbi5jb21wb25lbnQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvbGliL2ljb24vaWNvbi5jb21wb25lbnQudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGlCQUFpQixDQUFDO0FBQzNDLE9BQU8sRUFBRSxTQUFTLEVBQUUsV0FBVyxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQWEsUUFBUSxFQUFpQixNQUFNLGVBQWUsQ0FBQztBQUUxRyxPQUFPLEVBR0wsSUFBSSxFQUdKLEtBQUssR0FLTixNQUFNLG1DQUFtQyxDQUFDO0FBRzNDLE9BQU8sRUFBRSw2QkFBNkIsRUFBRSxNQUFNLDRDQUE0QyxDQUFDO0FBQzNGLE9BQU8sRUFBRSx1QkFBdUIsRUFBRSxNQUFNLDRDQUE0QyxDQUFDO0FBRXJGLE9BQU8sRUFBRSxXQUFXLEVBQUUsTUFBTSxnQ0FBZ0MsQ0FBQztBQUM3RCxPQUFPLEVBQUUsU0FBUyxFQUFFLE1BQU0scUJBQXFCLENBQUM7QUFDaEQsT0FBTyxFQUFFLG1CQUFtQixFQUFFLE1BQU0sMENBQTBDLENBQUM7Ozs7Ozs7QUFjL0UsTUFBTSxPQUFPLGVBQWU7SUErQzFCLFlBQ1UsU0FBdUIsRUFDdkIsTUFBZ0IsRUFDaEIsV0FBMEIsRUFDZCxTQUFtQyxFQUMzQyxLQUF1QjtRQUozQixjQUFTLEdBQVQsU0FBUyxDQUFjO1FBQ3ZCLFdBQU0sR0FBTixNQUFNLENBQVU7UUFDaEIsZ0JBQVcsR0FBWCxXQUFXLENBQWU7UUFDZCxjQUFTLEdBQVQsU0FBUyxDQUEwQjtRQU5qRCxhQUFRLEdBQUcsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBU2xDLElBQUksS0FBSyxJQUFJLElBQUksSUFBSSxTQUFTLElBQUksSUFBSSxFQUFFLENBQUM7WUFDdkMsT0FBTyxDQUFDLEtBQUssQ0FDWCwyR0FBMkc7Z0JBQ3pHLDREQUE0RCxDQUMvRCxDQUFDO1FBQ0osQ0FBQztJQUNILENBQUM7SUFFRCxXQUFXLENBQUMsT0FBc0I7UUFDaEMsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUMxRCx1QkFBdUIsRUFBRSxDQUFDO1lBQzFCLE9BQU87UUFDVCxDQUFDO1FBRUQsSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNaLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDdEYsSUFBSSxjQUFjLElBQUksSUFBSSxFQUFFLENBQUM7Z0JBQzNCLE1BQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDbEMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDO2dCQUN0QyxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsY0FBYyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2dCQUNsRCxJQUFJLENBQUMsZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQy9GLENBQUM7UUFDSCxDQUFDO0lBQ0gsQ0FBQztJQUVEOzs7Ozs7T0FNRztJQUNILE1BQU07UUFDSixJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3ZCLENBQUM7SUFFUyxrQkFBa0IsQ0FBQyxDQUE0QjtRQUN2RCxNQUFNLE1BQU0sR0FBRyxtQkFBbUIsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUNqRSxJQUFJLE1BQU0sSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUNyQixPQUFPLE1BQTRCLENBQUM7UUFDdEMsQ0FBQztRQUVELE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsaUJBQWlCLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDdEYsSUFBSSxVQUFVLElBQUksSUFBSSxFQUFFLENBQUM7WUFDdkIsT0FBTyxVQUFnQyxDQUFDO1FBQzFDLENBQUM7UUFFRCw2QkFBNkIsQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUN0QyxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFFUyxXQUFXO1FBQ25CLE1BQU0sU0FBUyxHQUFZO1lBQ3pCLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSTtZQUNmLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztZQUN6QixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbkIsT0FBTyxFQUFFLElBQUksQ0FBQyxPQUFPO1lBQ3JCLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUk7WUFDdkIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSTtZQUN2QixNQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJO1lBQzNCLFVBQVUsRUFBRSxPQUFPLElBQUksQ0FBQyxVQUFVLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVU7WUFDM0YsYUFBYSxFQUFFLElBQUksQ0FBQyxTQUFTLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUMsSUFBSTtTQUM1RSxDQUFDO1FBRUYsTUFBTSxlQUFlLEdBQUcsT0FBTyxJQUFJLENBQUMsU0FBUyxLQUFLLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7UUFFOUcsT0FBTztZQUNMLEtBQUssRUFBRSxJQUFJLENBQUMsS0FBSztZQUNqQixTQUFTLEVBQUUsZUFBZTtZQUMxQixPQUFPLEVBQUUsV0FBVyxDQUFDLFNBQVMsQ0FBQztZQUMvQixJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7WUFDbkUsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNO1lBQ25CLFVBQVUsRUFBRTtnQkFDVixJQUFJLEVBQUUsSUFBSSxDQUFDLFFBQVE7Z0JBQ25CLEVBQUUsRUFBRSxJQUFJLENBQUMsS0FBSzthQUNmO1NBQ0YsQ0FBQztJQUNKLENBQUM7OEdBbklVLGVBQWU7a0dBQWYsZUFBZSx5ZUFOaEIsRUFBRTs7MkZBTUQsZUFBZTtrQkFUM0IsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsU0FBUztvQkFDbkIsVUFBVSxFQUFFLElBQUk7b0JBQ2hCLFFBQVEsRUFBRSxFQUFFO29CQUNaLElBQUksRUFBRTt3QkFDSixLQUFLLEVBQUUsWUFBWTt3QkFDbkIsY0FBYyxFQUFFLE9BQU87cUJBQ3hCO2lCQUNGOzswQkFvREksUUFBUTs7MEJBQ1IsUUFBUTt5Q0FuREYsSUFBSTtzQkFBWixLQUFLO2dCQVFHLEtBQUs7c0JBQWIsS0FBSztnQkFRRyxTQUFTO3NCQUFqQixLQUFLO2dCQUVHLElBQUk7c0JBQVosS0FBSztnQkFDRyxJQUFJO3NCQUFaLEtBQUs7Z0JBQ0csSUFBSTtzQkFBWixLQUFLO2dCQUNHLElBQUk7c0JBQVosS0FBSztnQkFDRyxNQUFNO3NCQUFkLEtBQUs7Z0JBQ0csT0FBTztzQkFBZixLQUFLO2dCQUNHLE1BQU07c0JBQWQsS0FBSztnQkFDRyxNQUFNO3NCQUFkLEtBQUs7Z0JBQ0csVUFBVTtzQkFBbEIsS0FBSztnQkFDRyxTQUFTO3NCQUFqQixLQUFLO2dCQU9HLFFBQVE7c0JBQWhCLEtBQUs7Z0JBTUcsS0FBSztzQkFBYixLQUFLO2dCQUVvQixnQkFBZ0I7c0JBQXpDLFdBQVc7dUJBQUMsV0FBVyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IERPQ1VNRU5UIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcbmltcG9ydCB7IENvbXBvbmVudCwgSG9zdEJpbmRpbmcsIGluamVjdCwgSW5wdXQsIE9uQ2hhbmdlcywgT3B0aW9uYWwsIFNpbXBsZUNoYW5nZXMgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IERvbVNhbml0aXplciwgU2FmZUh0bWwgfSBmcm9tICdAYW5ndWxhci9wbGF0Zm9ybS1icm93c2VyJztcbmltcG9ydCB7XG4gIEZhU3ltYm9sLFxuICBGbGlwUHJvcCxcbiAgaWNvbixcbiAgSWNvbkRlZmluaXRpb24gYXMgQ29yZUljb25EZWZpbml0aW9uLFxuICBJY29uUGFyYW1zLFxuICBwYXJzZSxcbiAgUHVsbFByb3AsXG4gIFJvdGF0ZVByb3AsXG4gIFNpemVQcm9wLFxuICBUcmFuc2Zvcm0sXG59IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1zdmctY29yZSc7XG5pbXBvcnQgeyBGYUNvbmZpZyB9IGZyb20gJy4uL2NvbmZpZyc7XG5pbXBvcnQgeyBGYUljb25MaWJyYXJ5IH0gZnJvbSAnLi4vaWNvbi1saWJyYXJ5JztcbmltcG9ydCB7IGZhV2FybklmSWNvbkRlZmluaXRpb25NaXNzaW5nIH0gZnJvbSAnLi4vc2hhcmVkL2Vycm9ycy93YXJuLWlmLWljb24taHRtbC1taXNzaW5nJztcbmltcG9ydCB7IGZhV2FybklmSWNvblNwZWNNaXNzaW5nIH0gZnJvbSAnLi4vc2hhcmVkL2Vycm9ycy93YXJuLWlmLWljb24tc3BlYy1taXNzaW5nJztcbmltcG9ydCB7IEFuaW1hdGlvblByb3AsIEZhUHJvcHMgfSBmcm9tICcuLi9zaGFyZWQvbW9kZWxzL3Byb3BzLm1vZGVsJztcbmltcG9ydCB7IGZhQ2xhc3NMaXN0IH0gZnJvbSAnLi4vc2hhcmVkL3V0aWxzL2NsYXNzbGlzdC51dGlsJztcbmltcG9ydCB7IGVuc3VyZUNzcyB9IGZyb20gJy4uL3NoYXJlZC91dGlscy9jc3MnO1xuaW1wb3J0IHsgZmFOb3JtYWxpemVJY29uU3BlYyB9IGZyb20gJy4uL3NoYXJlZC91dGlscy9ub3JtYWxpemUtaWNvbi1zcGVjLnV0aWwnO1xuaW1wb3J0IHsgRmFTdGFja0l0ZW1TaXplRGlyZWN0aXZlIH0gZnJvbSAnLi4vc3RhY2svc3RhY2staXRlbS1zaXplLmRpcmVjdGl2ZSc7XG5pbXBvcnQgeyBGYVN0YWNrQ29tcG9uZW50IH0gZnJvbSAnLi4vc3RhY2svc3RhY2suY29tcG9uZW50JztcbmltcG9ydCB7IEljb25EZWZpbml0aW9uLCBJY29uUHJvcCB9IGZyb20gJy4uL3R5cGVzJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAnZmEtaWNvbicsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHRlbXBsYXRlOiBgYCxcbiAgaG9zdDoge1xuICAgIGNsYXNzOiAnbmctZmEtaWNvbicsXG4gICAgJ1thdHRyLnRpdGxlXSc6ICd0aXRsZScsXG4gIH0sXG59KVxuZXhwb3J0IGNsYXNzIEZhSWNvbkNvbXBvbmVudCBpbXBsZW1lbnRzIE9uQ2hhbmdlcyB7XG4gIEBJbnB1dCgpIGljb246IEljb25Qcm9wO1xuXG4gIC8qKlxuICAgKiBTcGVjaWZ5IGEgdGl0bGUgZm9yIHRoZSBpY29uLlxuICAgKlxuICAgKiBUaGlzIHRleHQgd2lsbCBiZSBkaXNwbGF5ZWQgaW4gYSB0b29sdGlwIG9uIGhvdmVyIGFuZCBwcmVzZW50ZWQgdG8gdGhlXG4gICAqIHNjcmVlbiByZWFkZXJzLlxuICAgKi9cbiAgQElucHV0KCkgdGl0bGU/OiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIEljb24gYW5pbWF0aW9uLlxuICAgKlxuICAgKiBNb3N0IG9mIHRoZSBhbmltYXRpb25zIGFyZSBvbmx5IGF2YWlsYWJsZSB3aGVuIHVzaW5nIEZvbnQgQXdlc29tZSA2LiBXaXRoXG4gICAqIEZvbnQgQXdlc29tZSA1LCBvbmx5ICdzcGluJyBhbmQgJ3NwaW4tcHVsc2UnIGFyZSBzdXBwb3J0ZWQuXG4gICAqL1xuICBASW5wdXQoKSBhbmltYXRpb24/OiBBbmltYXRpb25Qcm9wO1xuXG4gIEBJbnB1dCgpIG1hc2s/OiBJY29uUHJvcDtcbiAgQElucHV0KCkgZmxpcD86IEZsaXBQcm9wO1xuICBASW5wdXQoKSBzaXplPzogU2l6ZVByb3A7XG4gIEBJbnB1dCgpIHB1bGw/OiBQdWxsUHJvcDtcbiAgQElucHV0KCkgYm9yZGVyPzogYm9vbGVhbjtcbiAgQElucHV0KCkgaW52ZXJzZT86IGJvb2xlYW47XG4gIEBJbnB1dCgpIHN5bWJvbD86IEZhU3ltYm9sO1xuICBASW5wdXQoKSByb3RhdGU/OiBSb3RhdGVQcm9wO1xuICBASW5wdXQoKSBmaXhlZFdpZHRoPzogYm9vbGVhbjtcbiAgQElucHV0KCkgdHJhbnNmb3JtPzogc3RyaW5nIHwgVHJhbnNmb3JtO1xuXG4gIC8qKlxuICAgKiBTcGVjaWZ5IHRoZSBgcm9sZWAgYXR0cmlidXRlIGZvciB0aGUgcmVuZGVyZWQgPHN2Zz4gZWxlbWVudC5cbiAgICpcbiAgICogQGRlZmF1bHQgJ2ltZydcbiAgICovXG4gIEBJbnB1dCgpIGExMXlSb2xlOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIFNwZWNpZnkgdGhlIGBpZGAgYXR0cmlidXRlIGZvciB0aGUgcmVuZGVyZWQgPHN2Zz4gZWxlbWVudC5cbiAgICpcbiAgICovXG4gIEBJbnB1dCgpIHN2Z0lkOiBzdHJpbmc7XG5cbiAgQEhvc3RCaW5kaW5nKCdpbm5lckhUTUwnKSByZW5kZXJlZEljb25IVE1MOiBTYWZlSHRtbDtcblxuICBwcml2YXRlIGRvY3VtZW50ID0gaW5qZWN0KERPQ1VNRU5UKTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHNhbml0aXplcjogRG9tU2FuaXRpemVyLFxuICAgIHByaXZhdGUgY29uZmlnOiBGYUNvbmZpZyxcbiAgICBwcml2YXRlIGljb25MaWJyYXJ5OiBGYUljb25MaWJyYXJ5LFxuICAgIEBPcHRpb25hbCgpIHByaXZhdGUgc3RhY2tJdGVtOiBGYVN0YWNrSXRlbVNpemVEaXJlY3RpdmUsXG4gICAgQE9wdGlvbmFsKCkgc3RhY2s6IEZhU3RhY2tDb21wb25lbnQsXG4gICkge1xuICAgIGlmIChzdGFjayAhPSBudWxsICYmIHN0YWNrSXRlbSA9PSBudWxsKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICAnRm9udEF3ZXNvbWU6IGZhLWljb24gYW5kIGZhLWR1b3RvbmUtaWNvbiBlbGVtZW50cyBtdXN0IHNwZWNpZnkgc3RhY2tJdGVtU2l6ZSBhdHRyaWJ1dGUgd2hlbiB3cmFwcGVkIGludG8gJyArXG4gICAgICAgICAgJ2ZhLXN0YWNrLiBFeGFtcGxlOiA8ZmEtaWNvbiBzdGFja0l0ZW1TaXplPVwiMnhcIj48L2ZhLWljb24+LicsXG4gICAgICApO1xuICAgIH1cbiAgfVxuXG4gIG5nT25DaGFuZ2VzKGNoYW5nZXM6IFNpbXBsZUNoYW5nZXMpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5pY29uID09IG51bGwgJiYgdGhpcy5jb25maWcuZmFsbGJhY2tJY29uID09IG51bGwpIHtcbiAgICAgIGZhV2FybklmSWNvblNwZWNNaXNzaW5nKCk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKGNoYW5nZXMpIHtcbiAgICAgIGNvbnN0IGljb25EZWZpbml0aW9uID0gdGhpcy5maW5kSWNvbkRlZmluaXRpb24odGhpcy5pY29uID8/IHRoaXMuY29uZmlnLmZhbGxiYWNrSWNvbik7XG4gICAgICBpZiAoaWNvbkRlZmluaXRpb24gIT0gbnVsbCkge1xuICAgICAgICBjb25zdCBwYXJhbXMgPSB0aGlzLmJ1aWxkUGFyYW1zKCk7XG4gICAgICAgIGVuc3VyZUNzcyh0aGlzLmRvY3VtZW50LCB0aGlzLmNvbmZpZyk7XG4gICAgICAgIGNvbnN0IHJlbmRlcmVkSWNvbiA9IGljb24oaWNvbkRlZmluaXRpb24sIHBhcmFtcyk7XG4gICAgICAgIHRoaXMucmVuZGVyZWRJY29uSFRNTCA9IHRoaXMuc2FuaXRpemVyLmJ5cGFzc1NlY3VyaXR5VHJ1c3RIdG1sKHJlbmRlcmVkSWNvbi5odG1sLmpvaW4oJ1xcbicpKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUHJvZ3JhbW1hdGljYWxseSB0cmlnZ2VyIHJlbmRlcmluZyBvZiB0aGUgaWNvbi5cbiAgICpcbiAgICogVGhpcyBtZXRob2QgaXMgdXNlZnVsLCB3aGVuIGNyZWF0aW5nIHtAbGluayBGYUljb25Db21wb25lbnR9IGR5bmFtaWNhbGx5IG9yXG4gICAqIGNoYW5naW5nIGl0cyBpbnB1dHMgcHJvZ3JhbW1hdGljYWxseSBhcyBpbiB0aGVzZSBjYXNlcyBpY29uIHdvbid0IGJlXG4gICAqIHJlLXJlbmRlcmVkIGF1dG9tYXRpY2FsbHkuXG4gICAqL1xuICByZW5kZXIoKSB7XG4gICAgdGhpcy5uZ09uQ2hhbmdlcyh7fSk7XG4gIH1cblxuICBwcm90ZWN0ZWQgZmluZEljb25EZWZpbml0aW9uKGk6IEljb25Qcm9wIHwgSWNvbkRlZmluaXRpb24pOiBDb3JlSWNvbkRlZmluaXRpb24gfCBudWxsIHtcbiAgICBjb25zdCBsb29rdXAgPSBmYU5vcm1hbGl6ZUljb25TcGVjKGksIHRoaXMuY29uZmlnLmRlZmF1bHRQcmVmaXgpO1xuICAgIGlmICgnaWNvbicgaW4gbG9va3VwKSB7XG4gICAgICByZXR1cm4gbG9va3VwIGFzIENvcmVJY29uRGVmaW5pdGlvbjtcbiAgICB9XG5cbiAgICBjb25zdCBkZWZpbml0aW9uID0gdGhpcy5pY29uTGlicmFyeS5nZXRJY29uRGVmaW5pdGlvbihsb29rdXAucHJlZml4LCBsb29rdXAuaWNvbk5hbWUpO1xuICAgIGlmIChkZWZpbml0aW9uICE9IG51bGwpIHtcbiAgICAgIHJldHVybiBkZWZpbml0aW9uIGFzIENvcmVJY29uRGVmaW5pdGlvbjtcbiAgICB9XG5cbiAgICBmYVdhcm5JZkljb25EZWZpbml0aW9uTWlzc2luZyhsb29rdXApO1xuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgcHJvdGVjdGVkIGJ1aWxkUGFyYW1zKCk6IEljb25QYXJhbXMge1xuICAgIGNvbnN0IGNsYXNzT3B0czogRmFQcm9wcyA9IHtcbiAgICAgIGZsaXA6IHRoaXMuZmxpcCxcbiAgICAgIGFuaW1hdGlvbjogdGhpcy5hbmltYXRpb24sXG4gICAgICBib3JkZXI6IHRoaXMuYm9yZGVyLFxuICAgICAgaW52ZXJzZTogdGhpcy5pbnZlcnNlLFxuICAgICAgc2l6ZTogdGhpcy5zaXplIHx8IG51bGwsXG4gICAgICBwdWxsOiB0aGlzLnB1bGwgfHwgbnVsbCxcbiAgICAgIHJvdGF0ZTogdGhpcy5yb3RhdGUgfHwgbnVsbCxcbiAgICAgIGZpeGVkV2lkdGg6IHR5cGVvZiB0aGlzLmZpeGVkV2lkdGggPT09ICdib29sZWFuJyA/IHRoaXMuZml4ZWRXaWR0aCA6IHRoaXMuY29uZmlnLmZpeGVkV2lkdGgsXG4gICAgICBzdGFja0l0ZW1TaXplOiB0aGlzLnN0YWNrSXRlbSAhPSBudWxsID8gdGhpcy5zdGFja0l0ZW0uc3RhY2tJdGVtU2l6ZSA6IG51bGwsXG4gICAgfTtcblxuICAgIGNvbnN0IHBhcnNlZFRyYW5zZm9ybSA9IHR5cGVvZiB0aGlzLnRyYW5zZm9ybSA9PT0gJ3N0cmluZycgPyBwYXJzZS50cmFuc2Zvcm0odGhpcy50cmFuc2Zvcm0pIDogdGhpcy50cmFuc2Zvcm07XG5cbiAgICByZXR1cm4ge1xuICAgICAgdGl0bGU6IHRoaXMudGl0bGUsXG4gICAgICB0cmFuc2Zvcm06IHBhcnNlZFRyYW5zZm9ybSxcbiAgICAgIGNsYXNzZXM6IGZhQ2xhc3NMaXN0KGNsYXNzT3B0cyksXG4gICAgICBtYXNrOiB0aGlzLm1hc2sgIT0gbnVsbCA/IHRoaXMuZmluZEljb25EZWZpbml0aW9uKHRoaXMubWFzaykgOiBudWxsLFxuICAgICAgc3ltYm9sOiB0aGlzLnN5bWJvbCxcbiAgICAgIGF0dHJpYnV0ZXM6IHtcbiAgICAgICAgcm9sZTogdGhpcy5hMTF5Um9sZSxcbiAgICAgICAgaWQ6IHRoaXMuc3ZnSWQsXG4gICAgICB9LFxuICAgIH07XG4gIH1cbn1cbiJdfQ==