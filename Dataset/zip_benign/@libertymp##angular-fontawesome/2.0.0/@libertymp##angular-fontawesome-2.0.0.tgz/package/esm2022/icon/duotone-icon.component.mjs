import { Component, Input } from '@angular/core';
import { FaIconComponent } from './icon.component';
import * as i0 from "@angular/core";
export class FaDuotoneIconComponent extends FaIconComponent {
    findIconDefinition(i) {
        const definition = super.findIconDefinition(i);
        if (definition != null && !Array.isArray(definition.icon[4])) {
            throw new Error('The specified icon does not appear to be a Duotone icon. ' +
                'Check that you specified the correct style: ' +
                `<fa-duotone-icon [icon]="['fad', '${definition.iconName}']"></fa-duotone-icon> ` +
                `or use: <fa-icon icon="${definition.iconName}"></fa-icon> instead.`);
        }
        return definition;
    }
    buildParams() {
        const params = super.buildParams();
        if (this.swapOpacity === true || this.swapOpacity === 'true') {
            if (Array.isArray(params.classes)) {
                params.classes.push('fa-swap-opacity');
            }
            else if (typeof params.classes === 'string') {
                params.classes = [params.classes, 'fa-swap-opacity'];
            }
            else {
                params.classes = ['fa-swap-opacity'];
            }
        }
        if (params.styles == null) {
            params.styles = {};
        }
        if (this.primaryOpacity != null) {
            params.styles['--fa-primary-opacity'] = this.primaryOpacity.toString();
        }
        if (this.secondaryOpacity != null) {
            params.styles['--fa-secondary-opacity'] = this.secondaryOpacity.toString();
        }
        if (this.primaryColor != null) {
            params.styles['--fa-primary-color'] = this.primaryColor;
        }
        if (this.secondaryColor != null) {
            params.styles['--fa-secondary-color'] = this.secondaryColor;
        }
        return params;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaDuotoneIconComponent, deps: null, target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "18.2.8", type: FaDuotoneIconComponent, isStandalone: true, selector: "fa-duotone-icon", inputs: { swapOpacity: "swapOpacity", primaryOpacity: "primaryOpacity", secondaryOpacity: "secondaryOpacity", primaryColor: "primaryColor", secondaryColor: "secondaryColor" }, usesInheritance: true, ngImport: i0, template: ``, isInline: true }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaDuotoneIconComponent, decorators: [{
            type: Component,
            args: [{
                    selector: 'fa-duotone-icon',
                    standalone: true,
                    template: ``,
                }]
        }], propDecorators: { swapOpacity: [{
                type: Input
            }], primaryOpacity: [{
                type: Input
            }], secondaryOpacity: [{
                type: Input
            }], primaryColor: [{
                type: Input
            }], secondaryColor: [{
                type: Input
            }] } });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHVvdG9uZS1pY29uLmNvbXBvbmVudC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9saWIvaWNvbi9kdW90b25lLWljb24uY29tcG9uZW50LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLE1BQU0sZUFBZSxDQUFDO0FBR2pELE9BQU8sRUFBRSxlQUFlLEVBQUUsTUFBTSxrQkFBa0IsQ0FBQzs7QUFPbkQsTUFBTSxPQUFPLHNCQUF1QixTQUFRLGVBQWU7SUEwQy9DLGtCQUFrQixDQUFDLENBQTRCO1FBQ3ZELE1BQU0sVUFBVSxHQUFHLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUUvQyxJQUFJLFVBQVUsSUFBSSxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO1lBQzdELE1BQU0sSUFBSSxLQUFLLENBQ2IsMkRBQTJEO2dCQUN6RCw4Q0FBOEM7Z0JBQzlDLHFDQUFxQyxVQUFVLENBQUMsUUFBUSx5QkFBeUI7Z0JBQ2pGLDBCQUEwQixVQUFVLENBQUMsUUFBUSx1QkFBdUIsQ0FDdkUsQ0FBQztRQUNKLENBQUM7UUFFRCxPQUFPLFVBQVUsQ0FBQztJQUNwQixDQUFDO0lBRVMsV0FBVztRQUNuQixNQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFbkMsSUFBSSxJQUFJLENBQUMsV0FBVyxLQUFLLElBQUksSUFBSSxJQUFJLENBQUMsV0FBVyxLQUFLLE1BQU0sRUFBRSxDQUFDO1lBQzdELElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQztnQkFDbEMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUN6QyxDQUFDO2lCQUFNLElBQUksT0FBTyxNQUFNLENBQUMsT0FBTyxLQUFLLFFBQVEsRUFBRSxDQUFDO2dCQUM5QyxNQUFNLENBQUMsT0FBTyxHQUFHLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxpQkFBaUIsQ0FBQyxDQUFDO1lBQ3ZELENBQUM7aUJBQU0sQ0FBQztnQkFDTixNQUFNLENBQUMsT0FBTyxHQUFHLENBQUMsaUJBQWlCLENBQUMsQ0FBQztZQUN2QyxDQUFDO1FBQ0gsQ0FBQztRQUVELElBQUksTUFBTSxDQUFDLE1BQU0sSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUMxQixNQUFNLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQztRQUNyQixDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsY0FBYyxJQUFJLElBQUksRUFBRSxDQUFDO1lBQ2hDLE1BQU0sQ0FBQyxNQUFNLENBQUMsc0JBQXNCLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQ3pFLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUNsQyxNQUFNLENBQUMsTUFBTSxDQUFDLHdCQUF3QixDQUFDLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFFBQVEsRUFBRSxDQUFDO1FBQzdFLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksSUFBSSxFQUFFLENBQUM7WUFDOUIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDMUQsQ0FBQztRQUNELElBQUksSUFBSSxDQUFDLGNBQWMsSUFBSSxJQUFJLEVBQUUsQ0FBQztZQUNoQyxNQUFNLENBQUMsTUFBTSxDQUFDLHNCQUFzQixDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQztRQUM5RCxDQUFDO1FBRUQsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQzs4R0F2RlUsc0JBQXNCO2tHQUF0QixzQkFBc0Isa1JBRnZCLEVBQUU7OzJGQUVELHNCQUFzQjtrQkFMbEMsU0FBUzttQkFBQztvQkFDVCxRQUFRLEVBQUUsaUJBQWlCO29CQUMzQixVQUFVLEVBQUUsSUFBSTtvQkFDaEIsUUFBUSxFQUFFLEVBQUU7aUJBQ2I7OEJBU1UsV0FBVztzQkFBbkIsS0FBSztnQkFRRyxjQUFjO3NCQUF0QixLQUFLO2dCQVFHLGdCQUFnQjtzQkFBeEIsS0FBSztnQkFRRyxZQUFZO3NCQUFwQixLQUFLO2dCQVFHLGNBQWM7c0JBQXRCLEtBQUsiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJY29uRGVmaW5pdGlvbiBhcyBDb3JlSWNvbkRlZmluaXRpb24sIEljb25QYXJhbXMgfSBmcm9tICdAZm9ydGF3ZXNvbWUvZm9udGF3ZXNvbWUtc3ZnLWNvcmUnO1xuaW1wb3J0IHsgSWNvbkRlZmluaXRpb24sIEljb25Qcm9wIH0gZnJvbSAnLi4vdHlwZXMnO1xuaW1wb3J0IHsgRmFJY29uQ29tcG9uZW50IH0gZnJvbSAnLi9pY29uLmNvbXBvbmVudCc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ2ZhLWR1b3RvbmUtaWNvbicsXG4gIHN0YW5kYWxvbmU6IHRydWUsXG4gIHRlbXBsYXRlOiBgYCxcbn0pXG5leHBvcnQgY2xhc3MgRmFEdW90b25lSWNvbkNvbXBvbmVudCBleHRlbmRzIEZhSWNvbkNvbXBvbmVudCB7XG4gIC8qKlxuICAgKiBTd2FwIHRoZSBkZWZhdWx0IG9wYWNpdHkgb2YgZWFjaCBkdW90b25lIGljb27igJlzIGxheWVycy4gVGhpcyB3aWxsIG1ha2UgYW5cbiAgICogaWNvbuKAmXMgcHJpbWFyeSBsYXllciBoYXZlIHRoZSBkZWZhdWx0IG9wYWNpdHkgb2YgNDAlIHJhdGhlciB0aGFuIGl0c1xuICAgKiBzZWNvbmRhcnkgbGF5ZXIuXG4gICAqXG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICBASW5wdXQoKSBzd2FwT3BhY2l0eT86ICd0cnVlJyB8ICdmYWxzZScgfCBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBDdXN0b21pemUgdGhlIG9wYWNpdHkgb2YgdGhlIHByaW1hcnkgaWNvbiBsYXllci5cbiAgICogVmFsaWQgdmFsdWVzIGFyZSBpbiByYW5nZSBbMCwgMS4wXS5cbiAgICpcbiAgICogQGRlZmF1bHQgMS4wXG4gICAqL1xuICBASW5wdXQoKSBwcmltYXJ5T3BhY2l0eT86IHN0cmluZyB8IG51bWJlcjtcblxuICAvKipcbiAgICogQ3VzdG9taXplIHRoZSBvcGFjaXR5IG9mIHRoZSBzZWNvbmRhcnkgaWNvbiBsYXllci5cbiAgICogVmFsaWQgdmFsdWVzIGFyZSBpbiByYW5nZSBbMCwgMS4wXS5cbiAgICpcbiAgICogQGRlZmF1bHQgMC40XG4gICAqL1xuICBASW5wdXQoKSBzZWNvbmRhcnlPcGFjaXR5Pzogc3RyaW5nIHwgbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBDdXN0b21pemUgdGhlIGNvbG9yIG9mIHRoZSBwcmltYXJ5IGljb24gbGF5ZXIuXG4gICAqIEFjY2VwdHMgYW55IHZhbGlkIENTUyBjb2xvciB2YWx1ZS5cbiAgICpcbiAgICogQGRlZmF1bHQgQ1NTIGluaGVyaXRlZCBjb2xvclxuICAgKi9cbiAgQElucHV0KCkgcHJpbWFyeUNvbG9yPzogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBDdXN0b21pemUgdGhlIGNvbG9yIG9mIHRoZSBzZWNvbmRhcnkgaWNvbiBsYXllci5cbiAgICogQWNjZXB0cyBhbnkgdmFsaWQgQ1NTIGNvbG9yIHZhbHVlLlxuICAgKlxuICAgKiBAZGVmYXVsdCBDU1MgaW5oZXJpdGVkIGNvbG9yXG4gICAqL1xuICBASW5wdXQoKSBzZWNvbmRhcnlDb2xvcj86IHN0cmluZztcblxuICBwcm90ZWN0ZWQgZmluZEljb25EZWZpbml0aW9uKGk6IEljb25Qcm9wIHwgSWNvbkRlZmluaXRpb24pOiBDb3JlSWNvbkRlZmluaXRpb24gfCBudWxsIHtcbiAgICBjb25zdCBkZWZpbml0aW9uID0gc3VwZXIuZmluZEljb25EZWZpbml0aW9uKGkpO1xuXG4gICAgaWYgKGRlZmluaXRpb24gIT0gbnVsbCAmJiAhQXJyYXkuaXNBcnJheShkZWZpbml0aW9uLmljb25bNF0pKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdUaGUgc3BlY2lmaWVkIGljb24gZG9lcyBub3QgYXBwZWFyIHRvIGJlIGEgRHVvdG9uZSBpY29uLiAnICtcbiAgICAgICAgICAnQ2hlY2sgdGhhdCB5b3Ugc3BlY2lmaWVkIHRoZSBjb3JyZWN0IHN0eWxlOiAnICtcbiAgICAgICAgICBgPGZhLWR1b3RvbmUtaWNvbiBbaWNvbl09XCJbJ2ZhZCcsICcke2RlZmluaXRpb24uaWNvbk5hbWV9J11cIj48L2ZhLWR1b3RvbmUtaWNvbj4gYCArXG4gICAgICAgICAgYG9yIHVzZTogPGZhLWljb24gaWNvbj1cIiR7ZGVmaW5pdGlvbi5pY29uTmFtZX1cIj48L2ZhLWljb24+IGluc3RlYWQuYCxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGRlZmluaXRpb247XG4gIH1cblxuICBwcm90ZWN0ZWQgYnVpbGRQYXJhbXMoKTogSWNvblBhcmFtcyB7XG4gICAgY29uc3QgcGFyYW1zID0gc3VwZXIuYnVpbGRQYXJhbXMoKTtcblxuICAgIGlmICh0aGlzLnN3YXBPcGFjaXR5ID09PSB0cnVlIHx8IHRoaXMuc3dhcE9wYWNpdHkgPT09ICd0cnVlJykge1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkocGFyYW1zLmNsYXNzZXMpKSB7XG4gICAgICAgIHBhcmFtcy5jbGFzc2VzLnB1c2goJ2ZhLXN3YXAtb3BhY2l0eScpO1xuICAgICAgfSBlbHNlIGlmICh0eXBlb2YgcGFyYW1zLmNsYXNzZXMgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHBhcmFtcy5jbGFzc2VzID0gW3BhcmFtcy5jbGFzc2VzLCAnZmEtc3dhcC1vcGFjaXR5J107XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwYXJhbXMuY2xhc3NlcyA9IFsnZmEtc3dhcC1vcGFjaXR5J107XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHBhcmFtcy5zdHlsZXMgPT0gbnVsbCkge1xuICAgICAgcGFyYW1zLnN0eWxlcyA9IHt9O1xuICAgIH1cbiAgICBpZiAodGhpcy5wcmltYXJ5T3BhY2l0eSAhPSBudWxsKSB7XG4gICAgICBwYXJhbXMuc3R5bGVzWyctLWZhLXByaW1hcnktb3BhY2l0eSddID0gdGhpcy5wcmltYXJ5T3BhY2l0eS50b1N0cmluZygpO1xuICAgIH1cbiAgICBpZiAodGhpcy5zZWNvbmRhcnlPcGFjaXR5ICE9IG51bGwpIHtcbiAgICAgIHBhcmFtcy5zdHlsZXNbJy0tZmEtc2Vjb25kYXJ5LW9wYWNpdHknXSA9IHRoaXMuc2Vjb25kYXJ5T3BhY2l0eS50b1N0cmluZygpO1xuICAgIH1cbiAgICBpZiAodGhpcy5wcmltYXJ5Q29sb3IgIT0gbnVsbCkge1xuICAgICAgcGFyYW1zLnN0eWxlc1snLS1mYS1wcmltYXJ5LWNvbG9yJ10gPSB0aGlzLnByaW1hcnlDb2xvcjtcbiAgICB9XG4gICAgaWYgKHRoaXMuc2Vjb25kYXJ5Q29sb3IgIT0gbnVsbCkge1xuICAgICAgcGFyYW1zLnN0eWxlc1snLS1mYS1zZWNvbmRhcnktY29sb3InXSA9IHRoaXMuc2Vjb25kYXJ5Q29sb3I7XG4gICAgfVxuXG4gICAgcmV0dXJuIHBhcmFtcztcbiAgfVxufVxuIl19