import { NgModule } from '@angular/core';
import { FaIconLibrary, FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { FaTestingConfig } from './config';
import { MockFaIconLibrary } from './icon/mock-icon-library.service';
import * as i0 from "@angular/core";
export class FontAwesomeTestingModule {
    /**
     * Use this method to configure the module’s behaviour when trying to add icons
     * and icon packs to the mock icon library.
     */
    static forRoot(config = {}) {
        return {
            ngModule: FontAwesomeTestingModule,
            providers: [
                {
                    provide: FaIconLibrary,
                    useExisting: MockFaIconLibrary,
                },
                {
                    provide: FaTestingConfig,
                    useFactory: () => Object.assign(new FaTestingConfig(), config),
                },
            ],
        };
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FontAwesomeTestingModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.8", ngImport: i0, type: FontAwesomeTestingModule, exports: [FontAwesomeModule] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FontAwesomeTestingModule, providers: [{ provide: FaIconLibrary, useExisting: MockFaIconLibrary }], imports: [FontAwesomeModule] }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FontAwesomeTestingModule, decorators: [{
            type: NgModule,
            args: [{
                    exports: [FontAwesomeModule],
                    providers: [{ provide: FaIconLibrary, useExisting: MockFaIconLibrary }],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGVzdGluZy5tb2R1bGUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi90ZXN0aW5nL3NyYy90ZXN0aW5nLm1vZHVsZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQXVCLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUM5RCxPQUFPLEVBQUUsYUFBYSxFQUFFLGlCQUFpQixFQUFFLE1BQU0sa0NBQWtDLENBQUM7QUFDcEYsT0FBTyxFQUFFLGVBQWUsRUFBRSxNQUFNLFVBQVUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxrQ0FBa0MsQ0FBQzs7QUFNckUsTUFBTSxPQUFPLHdCQUF3QjtJQUNuQzs7O09BR0c7SUFDSCxNQUFNLENBQUMsT0FBTyxDQUFDLFNBQW1DLEVBQUU7UUFDbEQsT0FBTztZQUNMLFFBQVEsRUFBRSx3QkFBd0I7WUFDbEMsU0FBUyxFQUFFO2dCQUNUO29CQUNFLE9BQU8sRUFBRSxhQUFhO29CQUN0QixXQUFXLEVBQUUsaUJBQWlCO2lCQUMvQjtnQkFDRDtvQkFDRSxPQUFPLEVBQUUsZUFBZTtvQkFDeEIsVUFBVSxFQUFFLEdBQUcsRUFBRSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxlQUFlLEVBQUUsRUFBRSxNQUFNLENBQUM7aUJBQy9EO2FBQ0Y7U0FDRixDQUFDO0lBQ0osQ0FBQzs4R0FuQlUsd0JBQXdCOytHQUF4Qix3QkFBd0IsWUFIekIsaUJBQWlCOytHQUdoQix3QkFBd0IsYUFGeEIsQ0FBQyxFQUFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsV0FBVyxFQUFFLGlCQUFpQixFQUFFLENBQUMsWUFEN0QsaUJBQWlCOzsyRkFHaEIsd0JBQXdCO2tCQUpwQyxRQUFRO21CQUFDO29CQUNSLE9BQU8sRUFBRSxDQUFDLGlCQUFpQixDQUFDO29CQUM1QixTQUFTLEVBQUUsQ0FBQyxFQUFFLE9BQU8sRUFBRSxhQUFhLEVBQUUsV0FBVyxFQUFFLGlCQUFpQixFQUFFLENBQUM7aUJBQ3hFIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9kdWxlV2l0aFByb3ZpZGVycywgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZhSWNvbkxpYnJhcnksIEZvbnRBd2Vzb21lTW9kdWxlIH0gZnJvbSAnQGZvcnRhd2Vzb21lL2FuZ3VsYXItZm9udGF3ZXNvbWUnO1xuaW1wb3J0IHsgRmFUZXN0aW5nQ29uZmlnIH0gZnJvbSAnLi9jb25maWcnO1xuaW1wb3J0IHsgTW9ja0ZhSWNvbkxpYnJhcnkgfSBmcm9tICcuL2ljb24vbW9jay1pY29uLWxpYnJhcnkuc2VydmljZSc7XG5cbkBOZ01vZHVsZSh7XG4gIGV4cG9ydHM6IFtGb250QXdlc29tZU1vZHVsZV0sXG4gIHByb3ZpZGVyczogW3sgcHJvdmlkZTogRmFJY29uTGlicmFyeSwgdXNlRXhpc3Rpbmc6IE1vY2tGYUljb25MaWJyYXJ5IH1dLFxufSlcbmV4cG9ydCBjbGFzcyBGb250QXdlc29tZVRlc3RpbmdNb2R1bGUge1xuICAvKipcbiAgICogVXNlIHRoaXMgbWV0aG9kIHRvIGNvbmZpZ3VyZSB0aGUgbW9kdWxl4oCZcyBiZWhhdmlvdXIgd2hlbiB0cnlpbmcgdG8gYWRkIGljb25zXG4gICAqIGFuZCBpY29uIHBhY2tzIHRvIHRoZSBtb2NrIGljb24gbGlicmFyeS5cbiAgICovXG4gIHN0YXRpYyBmb3JSb290KGNvbmZpZzogUGFydGlhbDxGYVRlc3RpbmdDb25maWc+ID0ge30pOiBNb2R1bGVXaXRoUHJvdmlkZXJzPEZvbnRBd2Vzb21lVGVzdGluZ01vZHVsZT4ge1xuICAgIHJldHVybiB7XG4gICAgICBuZ01vZHVsZTogRm9udEF3ZXNvbWVUZXN0aW5nTW9kdWxlLFxuICAgICAgcHJvdmlkZXJzOiBbXG4gICAgICAgIHtcbiAgICAgICAgICBwcm92aWRlOiBGYUljb25MaWJyYXJ5LFxuICAgICAgICAgIHVzZUV4aXN0aW5nOiBNb2NrRmFJY29uTGlicmFyeSxcbiAgICAgICAgfSxcbiAgICAgICAge1xuICAgICAgICAgIHByb3ZpZGU6IEZhVGVzdGluZ0NvbmZpZyxcbiAgICAgICAgICB1c2VGYWN0b3J5OiAoKSA9PiBPYmplY3QuYXNzaWduKG5ldyBGYVRlc3RpbmdDb25maWcoKSwgY29uZmlnKSxcbiAgICAgICAgfSxcbiAgICAgIF0sXG4gICAgfTtcbiAgfVxufVxuIl19