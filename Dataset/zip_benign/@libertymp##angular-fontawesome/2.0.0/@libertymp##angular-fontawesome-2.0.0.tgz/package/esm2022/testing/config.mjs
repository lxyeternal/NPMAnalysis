import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class FaTestingConfig {
    constructor() {
        /**
         * What to do when `addIcons()` or `addIconPacks()` is invoked on
         * the FaIconLibrary provided by the FontAwesomeTestingModule.
         *
         * Possible values are:
         * - `'throwError'` -  Throw an error.
         * - `'logWarning'` - Write a warning to the console.
         * - `'noop'` - Do nothing.
         *
         * Note that in any case the icon will not be added to the library.
         *
         * @default 'throwError'
         */
        this.whenAddingIcons = 'throwError';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaTestingConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaTestingConfig, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaTestingConfig, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vdGVzdGluZy9zcmMvY29uZmlnLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sRUFBRSxVQUFVLEVBQUUsTUFBTSxlQUFlLENBQUM7O0FBSzNDLE1BQU0sT0FBTyxlQUFlO0lBSDVCO1FBSUU7Ozs7Ozs7Ozs7OztXQVlHO1FBQ0gsb0JBQWUsR0FBeUMsWUFBWSxDQUFDO0tBQ3RFOzhHQWZZLGVBQWU7a0hBQWYsZUFBZSxjQUZkLE1BQU07OzJGQUVQLGVBQWU7a0JBSDNCLFVBQVU7bUJBQUM7b0JBQ1YsVUFBVSxFQUFFLE1BQU07aUJBQ25CIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgSW5qZWN0YWJsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgRmFUZXN0aW5nQ29uZmlnIHtcbiAgLyoqXG4gICAqIFdoYXQgdG8gZG8gd2hlbiBgYWRkSWNvbnMoKWAgb3IgYGFkZEljb25QYWNrcygpYCBpcyBpbnZva2VkIG9uXG4gICAqIHRoZSBGYUljb25MaWJyYXJ5IHByb3ZpZGVkIGJ5IHRoZSBGb250QXdlc29tZVRlc3RpbmdNb2R1bGUuXG4gICAqXG4gICAqIFBvc3NpYmxlIHZhbHVlcyBhcmU6XG4gICAqIC0gYCd0aHJvd0Vycm9yJ2AgLSAgVGhyb3cgYW4gZXJyb3IuXG4gICAqIC0gYCdsb2dXYXJuaW5nJ2AgLSBXcml0ZSBhIHdhcm5pbmcgdG8gdGhlIGNvbnNvbGUuXG4gICAqIC0gYCdub29wJ2AgLSBEbyBub3RoaW5nLlxuICAgKlxuICAgKiBOb3RlIHRoYXQgaW4gYW55IGNhc2UgdGhlIGljb24gd2lsbCBub3QgYmUgYWRkZWQgdG8gdGhlIGxpYnJhcnkuXG4gICAqXG4gICAqIEBkZWZhdWx0ICd0aHJvd0Vycm9yJ1xuICAgKi9cbiAgd2hlbkFkZGluZ0ljb25zOiAndGhyb3dFcnJvcicgfCAnbG9nV2FybmluZycgfCAnbm9vcCcgPSAndGhyb3dFcnJvcic7XG59XG4iXX0=