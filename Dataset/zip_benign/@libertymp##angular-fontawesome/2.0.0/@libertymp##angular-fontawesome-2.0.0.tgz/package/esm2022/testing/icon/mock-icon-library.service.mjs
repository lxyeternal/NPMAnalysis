import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
import * as i1 from "../config";
export const dummyIcon = {
    prefix: 'fad',
    iconName: 'dummy',
    icon: [512, 512, [], '', 'M50 50 H462 V462 H50 Z'],
};
export const ADD_ICON_MESSAGE = 'Attempt to add an icon to the MockFaIconLibrary.';
export class MockFaIconLibrary {
    constructor(config) {
        this.config = config;
    }
    addIcons() {
        if (this.config.whenAddingIcons === 'throwError') {
            throw new Error(ADD_ICON_MESSAGE);
        }
        if (this.config.whenAddingIcons === 'logWarning') {
            console.warn(ADD_ICON_MESSAGE);
        }
    }
    addIconPacks() {
        if (this.config.whenAddingIcons === 'throwError') {
            throw new Error(ADD_ICON_MESSAGE);
        }
        if (this.config.whenAddingIcons === 'logWarning') {
            console.warn(ADD_ICON_MESSAGE);
        }
    }
    getIconDefinition(prefix, name) {
        return dummyIcon;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: MockFaIconLibrary, deps: [{ token: i1.FaTestingConfig }], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: MockFaIconLibrary, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: MockFaIconLibrary, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [{ type: i1.FaTestingConfig }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9jay1pY29uLWxpYnJhcnkuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3Rlc3Rpbmcvc3JjL2ljb24vbW9jay1pY29uLWxpYnJhcnkuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLEVBQUUsVUFBVSxFQUFFLE1BQU0sZUFBZSxDQUFDOzs7QUFJM0MsTUFBTSxDQUFDLE1BQU0sU0FBUyxHQUFtQjtJQUN2QyxNQUFNLEVBQUUsS0FBSztJQUNiLFFBQVEsRUFBRSxPQUFPO0lBQ2pCLElBQUksRUFBRSxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSx3QkFBd0IsQ0FBQztDQUNuRCxDQUFDO0FBRUYsTUFBTSxDQUFDLE1BQU0sZ0JBQWdCLEdBQUcsa0RBQWtELENBQUM7QUFLbkYsTUFBTSxPQUFPLGlCQUFpQjtJQUM1QixZQUFvQixNQUF1QjtRQUF2QixXQUFNLEdBQU4sTUFBTSxDQUFpQjtJQUFHLENBQUM7SUFFL0MsUUFBUTtRQUNOLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxlQUFlLEtBQUssWUFBWSxFQUFFLENBQUM7WUFDakQsTUFBTSxJQUFJLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO1FBQ3BDLENBQUM7UUFDRCxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxLQUFLLFlBQVksRUFBRSxDQUFDO1lBQ2pELE9BQU8sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUNqQyxDQUFDO0lBQ0gsQ0FBQztJQUVELFlBQVk7UUFDVixJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsZUFBZSxLQUFLLFlBQVksRUFBRSxDQUFDO1lBQ2pELE1BQU0sSUFBSSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUNwQyxDQUFDO1FBQ0QsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLGVBQWUsS0FBSyxZQUFZLEVBQUUsQ0FBQztZQUNqRCxPQUFPLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDakMsQ0FBQztJQUNILENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxNQUFrQixFQUFFLElBQWM7UUFDbEQsT0FBTyxTQUFTLENBQUM7SUFDbkIsQ0FBQzs4R0F2QlUsaUJBQWlCO2tIQUFqQixpQkFBaUIsY0FGaEIsTUFBTTs7MkZBRVAsaUJBQWlCO2tCQUg3QixVQUFVO21CQUFDO29CQUNWLFVBQVUsRUFBRSxNQUFNO2lCQUNuQiIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZhSWNvbkxpYnJhcnlJbnRlcmZhY2UsIEljb25EZWZpbml0aW9uLCBJY29uTmFtZSwgSWNvblByZWZpeCB9IGZyb20gJ0Bmb3J0YXdlc29tZS9hbmd1bGFyLWZvbnRhd2Vzb21lJztcbmltcG9ydCB7IEZhVGVzdGluZ0NvbmZpZyB9IGZyb20gJy4uL2NvbmZpZyc7XG5cbmV4cG9ydCBjb25zdCBkdW1teUljb246IEljb25EZWZpbml0aW9uID0ge1xuICBwcmVmaXg6ICdmYWQnLFxuICBpY29uTmFtZTogJ2R1bW15JyxcbiAgaWNvbjogWzUxMiwgNTEyLCBbXSwgJycsICdNNTAgNTAgSDQ2MiBWNDYyIEg1MCBaJ10sXG59O1xuXG5leHBvcnQgY29uc3QgQUREX0lDT05fTUVTU0FHRSA9ICdBdHRlbXB0IHRvIGFkZCBhbiBpY29uIHRvIHRoZSBNb2NrRmFJY29uTGlicmFyeS4nO1xuXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290Jyxcbn0pXG5leHBvcnQgY2xhc3MgTW9ja0ZhSWNvbkxpYnJhcnkgaW1wbGVtZW50cyBGYUljb25MaWJyYXJ5SW50ZXJmYWNlIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBjb25maWc6IEZhVGVzdGluZ0NvbmZpZykge31cblxuICBhZGRJY29ucygpIHtcbiAgICBpZiAodGhpcy5jb25maWcud2hlbkFkZGluZ0ljb25zID09PSAndGhyb3dFcnJvcicpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihBRERfSUNPTl9NRVNTQUdFKTtcbiAgICB9XG4gICAgaWYgKHRoaXMuY29uZmlnLndoZW5BZGRpbmdJY29ucyA9PT0gJ2xvZ1dhcm5pbmcnKSB7XG4gICAgICBjb25zb2xlLndhcm4oQUREX0lDT05fTUVTU0FHRSk7XG4gICAgfVxuICB9XG5cbiAgYWRkSWNvblBhY2tzKCkge1xuICAgIGlmICh0aGlzLmNvbmZpZy53aGVuQWRkaW5nSWNvbnMgPT09ICd0aHJvd0Vycm9yJykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKEFERF9JQ09OX01FU1NBR0UpO1xuICAgIH1cbiAgICBpZiAodGhpcy5jb25maWcud2hlbkFkZGluZ0ljb25zID09PSAnbG9nV2FybmluZycpIHtcbiAgICAgIGNvbnNvbGUud2FybihBRERfSUNPTl9NRVNTQUdFKTtcbiAgICB9XG4gIH1cblxuICBnZXRJY29uRGVmaW5pdGlvbihwcmVmaXg6IEljb25QcmVmaXgsIG5hbWU6IEljb25OYW1lKTogSWNvbkRlZmluaXRpb24ge1xuICAgIHJldHVybiBkdW1teUljb247XG4gIH1cbn1cbiJdfQ==