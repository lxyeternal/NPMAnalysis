import { Injectable } from '@angular/core';
import { config } from '@fortawesome/fontawesome-svg-core';
import * as i0 from "@angular/core";
export class FaConfig {
    constructor() {
        /**
         * Default prefix to use, when one is not provided with the icon name.
         *
         * @default 'fas'
         */
        this.defaultPrefix = 'fas';
        /**
         * Provides a fallback icon to use whilst main icon is being loaded asynchronously.
         * When value is null, then fa-icon component will throw an error if icon input is missing.
         * When value is not null, then the provided icon will be used as a fallback icon if icon input is missing.
         *
         * @default null
         */
        this.fallbackIcon = null;
        this._autoAddCss = true;
    }
    /**
     * Automatically add Font Awesome styles to the document when icon is rendered.
     *
     * For the majority of the cases the automatically added CSS is sufficient,
     * please refer to the linked guide for more information on when to disable
     * this feature.
     *
     * @see {@link: https://github.com/FortAwesome/angular-fontawesome/blob/main/docs/guide/adding-css.md}
     * @default true
     */
    set autoAddCss(value) {
        config.autoAddCss = value;
        this._autoAddCss = value;
    }
    get autoAddCss() {
        return this._autoAddCss;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaConfig, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaConfig, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaConfig, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2xpYi9jb25maWcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUMzQyxPQUFPLEVBQUUsTUFBTSxFQUFFLE1BQU0sbUNBQW1DLENBQUM7O0FBSTNELE1BQU0sT0FBTyxRQUFRO0lBRHJCO1FBRUU7Ozs7V0FJRztRQUNILGtCQUFhLEdBQWUsS0FBSyxDQUFDO1FBRWxDOzs7Ozs7V0FNRztRQUNILGlCQUFZLEdBQW1CLElBQUksQ0FBQztRQTZCNUIsZ0JBQVcsR0FBRyxJQUFJLENBQUM7S0FDNUI7SUFwQkM7Ozs7Ozs7OztPQVNHO0lBQ0gsSUFBSSxVQUFVLENBQUMsS0FBYztRQUMzQixNQUFNLENBQUMsVUFBVSxHQUFHLEtBQUssQ0FBQztRQUMxQixJQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssQ0FBQztJQUMzQixDQUFDO0lBRUQsSUFBSSxVQUFVO1FBQ1osT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDO0lBQzFCLENBQUM7OEdBMUNVLFFBQVE7a0hBQVIsUUFBUSxjQURLLE1BQU07OzJGQUNuQixRQUFRO2tCQURwQixVQUFVO21CQUFDLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IGNvbmZpZyB9IGZyb20gJ0Bmb3J0YXdlc29tZS9mb250YXdlc29tZS1zdmctY29yZSc7XG5pbXBvcnQgeyBJY29uRGVmaW5pdGlvbiwgSWNvblByZWZpeCB9IGZyb20gJy4vdHlwZXMnO1xuXG5ASW5qZWN0YWJsZSh7IHByb3ZpZGVkSW46ICdyb290JyB9KVxuZXhwb3J0IGNsYXNzIEZhQ29uZmlnIHtcbiAgLyoqXG4gICAqIERlZmF1bHQgcHJlZml4IHRvIHVzZSwgd2hlbiBvbmUgaXMgbm90IHByb3ZpZGVkIHdpdGggdGhlIGljb24gbmFtZS5cbiAgICpcbiAgICogQGRlZmF1bHQgJ2ZhcydcbiAgICovXG4gIGRlZmF1bHRQcmVmaXg6IEljb25QcmVmaXggPSAnZmFzJztcblxuICAvKipcbiAgICogUHJvdmlkZXMgYSBmYWxsYmFjayBpY29uIHRvIHVzZSB3aGlsc3QgbWFpbiBpY29uIGlzIGJlaW5nIGxvYWRlZCBhc3luY2hyb25vdXNseS5cbiAgICogV2hlbiB2YWx1ZSBpcyBudWxsLCB0aGVuIGZhLWljb24gY29tcG9uZW50IHdpbGwgdGhyb3cgYW4gZXJyb3IgaWYgaWNvbiBpbnB1dCBpcyBtaXNzaW5nLlxuICAgKiBXaGVuIHZhbHVlIGlzIG5vdCBudWxsLCB0aGVuIHRoZSBwcm92aWRlZCBpY29uIHdpbGwgYmUgdXNlZCBhcyBhIGZhbGxiYWNrIGljb24gaWYgaWNvbiBpbnB1dCBpcyBtaXNzaW5nLlxuICAgKlxuICAgKiBAZGVmYXVsdCBudWxsXG4gICAqL1xuICBmYWxsYmFja0ljb246IEljb25EZWZpbml0aW9uID0gbnVsbDtcblxuICAvKipcbiAgICogU2V0IGljb25zIHRvIHRoZSBzYW1lIGZpeGVkIHdpZHRoLlxuICAgKlxuICAgKiBAc2VlIHtAbGluazogaHR0cHM6Ly9mb250YXdlc29tZS5jb20vaG93LXRvLXVzZS9vbi10aGUtd2ViL3N0eWxpbmcvZml4ZWQtd2lkdGgtaWNvbnN9XG4gICAqIEBkZWZhdWx0IGZhbHNlXG4gICAqL1xuICBmaXhlZFdpZHRoPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogQXV0b21hdGljYWxseSBhZGQgRm9udCBBd2Vzb21lIHN0eWxlcyB0byB0aGUgZG9jdW1lbnQgd2hlbiBpY29uIGlzIHJlbmRlcmVkLlxuICAgKlxuICAgKiBGb3IgdGhlIG1ham9yaXR5IG9mIHRoZSBjYXNlcyB0aGUgYXV0b21hdGljYWxseSBhZGRlZCBDU1MgaXMgc3VmZmljaWVudCxcbiAgICogcGxlYXNlIHJlZmVyIHRvIHRoZSBsaW5rZWQgZ3VpZGUgZm9yIG1vcmUgaW5mb3JtYXRpb24gb24gd2hlbiB0byBkaXNhYmxlXG4gICAqIHRoaXMgZmVhdHVyZS5cbiAgICpcbiAgICogQHNlZSB7QGxpbms6IGh0dHBzOi8vZ2l0aHViLmNvbS9Gb3J0QXdlc29tZS9hbmd1bGFyLWZvbnRhd2Vzb21lL2Jsb2IvbWFpbi9kb2NzL2d1aWRlL2FkZGluZy1jc3MubWR9XG4gICAqIEBkZWZhdWx0IHRydWVcbiAgICovXG4gIHNldCBhdXRvQWRkQ3NzKHZhbHVlOiBib29sZWFuKSB7XG4gICAgY29uZmlnLmF1dG9BZGRDc3MgPSB2YWx1ZTtcbiAgICB0aGlzLl9hdXRvQWRkQ3NzID0gdmFsdWU7XG4gIH1cblxuICBnZXQgYXV0b0FkZENzcygpIHtcbiAgICByZXR1cm4gdGhpcy5fYXV0b0FkZENzcztcbiAgfVxuXG4gIHByaXZhdGUgX2F1dG9BZGRDc3MgPSB0cnVlO1xufVxuIl19