import { Injectable } from '@angular/core';
import * as i0 from "@angular/core";
export class FaIconLibrary {
    constructor() {
        this.definitions = {};
    }
    addIcons(...icons) {
        for (const icon of icons) {
            if (!(icon.prefix in this.definitions)) {
                this.definitions[icon.prefix] = {};
            }
            this.definitions[icon.prefix][icon.iconName] = icon;
            for (const alias of icon.icon[2]) {
                if (typeof alias === 'string') {
                    this.definitions[icon.prefix][alias] = icon;
                }
            }
        }
    }
    addIconPacks(...packs) {
        for (const pack of packs) {
            const icons = Object.keys(pack).map((key) => pack[key]);
            this.addIcons(...icons);
        }
    }
    getIconDefinition(prefix, name) {
        if (prefix in this.definitions && name in this.definitions[prefix]) {
            return this.definitions[prefix][name];
        }
        return null;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaIconLibrary, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaIconLibrary, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FaIconLibrary, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaWNvbi1saWJyYXJ5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2xpYi9pY29uLWxpYnJhcnkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFVBQVUsRUFBRSxNQUFNLGVBQWUsQ0FBQzs7QUFVM0MsTUFBTSxPQUFPLGFBQWE7SUFEMUI7UUFFVSxnQkFBVyxHQUE2RCxFQUFFLENBQUM7S0E2QnBGO0lBM0JDLFFBQVEsQ0FBQyxHQUFHLEtBQXVCO1FBQ2pDLEtBQUssTUFBTSxJQUFJLElBQUksS0FBSyxFQUFFLENBQUM7WUFDekIsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLE1BQU0sSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQztnQkFDdkMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQ3JDLENBQUM7WUFDRCxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBSSxDQUFDO1lBQ3BELEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDO2dCQUNqQyxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRSxDQUFDO29CQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxJQUFJLENBQUM7Z0JBQzlDLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztJQUNILENBQUM7SUFFRCxZQUFZLENBQUMsR0FBRyxLQUFpQjtRQUMvQixLQUFLLE1BQU0sSUFBSSxJQUFJLEtBQUssRUFBRSxDQUFDO1lBQ3pCLE1BQU0sS0FBSyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztZQUN4RCxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7UUFDMUIsQ0FBQztJQUNILENBQUM7SUFFRCxpQkFBaUIsQ0FBQyxNQUFrQixFQUFFLElBQWM7UUFDbEQsSUFBSSxNQUFNLElBQUksSUFBSSxDQUFDLFdBQVcsSUFBSSxJQUFJLElBQUksSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1lBQ25FLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN4QyxDQUFDO1FBQ0QsT0FBTyxJQUFJLENBQUM7SUFDZCxDQUFDOzhHQTdCVSxhQUFhO2tIQUFiLGFBQWEsY0FEQSxNQUFNOzsyRkFDbkIsYUFBYTtrQkFEekIsVUFBVTttQkFBQyxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBJY29uRGVmaW5pdGlvbiwgSWNvbk5hbWUsIEljb25QYWNrLCBJY29uUHJlZml4IH0gZnJvbSAnLi90eXBlcyc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgRmFJY29uTGlicmFyeUludGVyZmFjZSB7XG4gIGFkZEljb25zKC4uLmljb25zOiBJY29uRGVmaW5pdGlvbltdKTogdm9pZDtcbiAgYWRkSWNvblBhY2tzKC4uLnBhY2tzOiBJY29uUGFja1tdKTogdm9pZDtcbiAgZ2V0SWNvbkRlZmluaXRpb24ocHJlZml4OiBJY29uUHJlZml4LCBuYW1lOiBJY29uTmFtZSk6IEljb25EZWZpbml0aW9uIHwgbnVsbDtcbn1cblxuQEluamVjdGFibGUoeyBwcm92aWRlZEluOiAncm9vdCcgfSlcbmV4cG9ydCBjbGFzcyBGYUljb25MaWJyYXJ5IGltcGxlbWVudHMgRmFJY29uTGlicmFyeUludGVyZmFjZSB7XG4gIHByaXZhdGUgZGVmaW5pdGlvbnM6IHsgW3ByZWZpeDogc3RyaW5nXTogeyBbbmFtZTogc3RyaW5nXTogSWNvbkRlZmluaXRpb24gfSB9ID0ge307XG5cbiAgYWRkSWNvbnMoLi4uaWNvbnM6IEljb25EZWZpbml0aW9uW10pIHtcbiAgICBmb3IgKGNvbnN0IGljb24gb2YgaWNvbnMpIHtcbiAgICAgIGlmICghKGljb24ucHJlZml4IGluIHRoaXMuZGVmaW5pdGlvbnMpKSB7XG4gICAgICAgIHRoaXMuZGVmaW5pdGlvbnNbaWNvbi5wcmVmaXhdID0ge307XG4gICAgICB9XG4gICAgICB0aGlzLmRlZmluaXRpb25zW2ljb24ucHJlZml4XVtpY29uLmljb25OYW1lXSA9IGljb247XG4gICAgICBmb3IgKGNvbnN0IGFsaWFzIG9mIGljb24uaWNvblsyXSkge1xuICAgICAgICBpZiAodHlwZW9mIGFsaWFzID09PSAnc3RyaW5nJykge1xuICAgICAgICAgIHRoaXMuZGVmaW5pdGlvbnNbaWNvbi5wcmVmaXhdW2FsaWFzXSA9IGljb247XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBhZGRJY29uUGFja3MoLi4ucGFja3M6IEljb25QYWNrW10pIHtcbiAgICBmb3IgKGNvbnN0IHBhY2sgb2YgcGFja3MpIHtcbiAgICAgIGNvbnN0IGljb25zID0gT2JqZWN0LmtleXMocGFjaykubWFwKChrZXkpID0+IHBhY2tba2V5XSk7XG4gICAgICB0aGlzLmFkZEljb25zKC4uLmljb25zKTtcbiAgICB9XG4gIH1cblxuICBnZXRJY29uRGVmaW5pdGlvbihwcmVmaXg6IEljb25QcmVmaXgsIG5hbWU6IEljb25OYW1lKTogSWNvbkRlZmluaXRpb24gfCBudWxsIHtcbiAgICBpZiAocHJlZml4IGluIHRoaXMuZGVmaW5pdGlvbnMgJiYgbmFtZSBpbiB0aGlzLmRlZmluaXRpb25zW3ByZWZpeF0pIHtcbiAgICAgIHJldHVybiB0aGlzLmRlZmluaXRpb25zW3ByZWZpeF1bbmFtZV07XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG59XG4iXX0=