import { NgModule } from '@angular/core';
import { FaDuotoneIconComponent } from './icon/duotone-icon.component';
import { FaIconComponent } from './icon/icon.component';
import { FaLayersCounterComponent } from './layers/layers-counter.component';
import { FaLayersTextComponent } from './layers/layers-text.component';
import { FaLayersComponent } from './layers/layers.component';
import { FaStackItemSizeDirective } from './stack/stack-item-size.directive';
import { FaStackComponent } from './stack/stack.component';
import * as i0 from "@angular/core";
export class FontAwesomeModule {
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FontAwesomeModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule }); }
    static { this.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "18.2.8", ngImport: i0, type: FontAwesomeModule, imports: [FaIconComponent,
            FaDuotoneIconComponent,
            FaLayersComponent,
            FaLayersTextComponent,
            FaLayersCounterComponent,
            FaStackComponent,
            FaStackItemSizeDirective], exports: [FaIconComponent,
            FaDuotoneIconComponent,
            FaLayersComponent,
            FaLayersTextComponent,
            FaLayersCounterComponent,
            FaStackComponent,
            FaStackItemSizeDirective] }); }
    static { this.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FontAwesomeModule }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "18.2.8", ngImport: i0, type: FontAwesomeModule, decorators: [{
            type: NgModule,
            args: [{
                    imports: [
                        FaIconComponent,
                        FaDuotoneIconComponent,
                        FaLayersComponent,
                        FaLayersTextComponent,
                        FaLayersCounterComponent,
                        FaStackComponent,
                        FaStackItemSizeDirective,
                    ],
                    exports: [
                        FaIconComponent,
                        FaDuotoneIconComponent,
                        FaLayersComponent,
                        FaLayersTextComponent,
                        FaLayersCounterComponent,
                        FaStackComponent,
                        FaStackItemSizeDirective,
                    ],
                }]
        }] });
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZm9udGF3ZXNvbWUubW9kdWxlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2xpYi9mb250YXdlc29tZS5tb2R1bGUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsT0FBTyxFQUFFLFFBQVEsRUFBRSxNQUFNLGVBQWUsQ0FBQztBQUN6QyxPQUFPLEVBQUUsc0JBQXNCLEVBQUUsTUFBTSwrQkFBK0IsQ0FBQztBQUN2RSxPQUFPLEVBQUUsZUFBZSxFQUFFLE1BQU0sdUJBQXVCLENBQUM7QUFDeEQsT0FBTyxFQUFFLHdCQUF3QixFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDN0UsT0FBTyxFQUFFLHFCQUFxQixFQUFFLE1BQU0sZ0NBQWdDLENBQUM7QUFDdkUsT0FBTyxFQUFFLGlCQUFpQixFQUFFLE1BQU0sMkJBQTJCLENBQUM7QUFDOUQsT0FBTyxFQUFFLHdCQUF3QixFQUFFLE1BQU0sbUNBQW1DLENBQUM7QUFDN0UsT0FBTyxFQUFFLGdCQUFnQixFQUFFLE1BQU0seUJBQXlCLENBQUM7O0FBc0IzRCxNQUFNLE9BQU8saUJBQWlCOzhHQUFqQixpQkFBaUI7K0dBQWpCLGlCQUFpQixZQWxCMUIsZUFBZTtZQUNmLHNCQUFzQjtZQUN0QixpQkFBaUI7WUFDakIscUJBQXFCO1lBQ3JCLHdCQUF3QjtZQUN4QixnQkFBZ0I7WUFDaEIsd0JBQXdCLGFBR3hCLGVBQWU7WUFDZixzQkFBc0I7WUFDdEIsaUJBQWlCO1lBQ2pCLHFCQUFxQjtZQUNyQix3QkFBd0I7WUFDeEIsZ0JBQWdCO1lBQ2hCLHdCQUF3QjsrR0FHZixpQkFBaUI7OzJGQUFqQixpQkFBaUI7a0JBcEI3QixRQUFRO21CQUFDO29CQUNSLE9BQU8sRUFBRTt3QkFDUCxlQUFlO3dCQUNmLHNCQUFzQjt3QkFDdEIsaUJBQWlCO3dCQUNqQixxQkFBcUI7d0JBQ3JCLHdCQUF3Qjt3QkFDeEIsZ0JBQWdCO3dCQUNoQix3QkFBd0I7cUJBQ3pCO29CQUNELE9BQU8sRUFBRTt3QkFDUCxlQUFlO3dCQUNmLHNCQUFzQjt3QkFDdEIsaUJBQWlCO3dCQUNqQixxQkFBcUI7d0JBQ3JCLHdCQUF3Qjt3QkFDeEIsZ0JBQWdCO3dCQUNoQix3QkFBd0I7cUJBQ3pCO2lCQUNGIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTmdNb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7IEZhRHVvdG9uZUljb25Db21wb25lbnQgfSBmcm9tICcuL2ljb24vZHVvdG9uZS1pY29uLmNvbXBvbmVudCc7XG5pbXBvcnQgeyBGYUljb25Db21wb25lbnQgfSBmcm9tICcuL2ljb24vaWNvbi5jb21wb25lbnQnO1xuaW1wb3J0IHsgRmFMYXllcnNDb3VudGVyQ29tcG9uZW50IH0gZnJvbSAnLi9sYXllcnMvbGF5ZXJzLWNvdW50ZXIuY29tcG9uZW50JztcbmltcG9ydCB7IEZhTGF5ZXJzVGV4dENvbXBvbmVudCB9IGZyb20gJy4vbGF5ZXJzL2xheWVycy10ZXh0LmNvbXBvbmVudCc7XG5pbXBvcnQgeyBGYUxheWVyc0NvbXBvbmVudCB9IGZyb20gJy4vbGF5ZXJzL2xheWVycy5jb21wb25lbnQnO1xuaW1wb3J0IHsgRmFTdGFja0l0ZW1TaXplRGlyZWN0aXZlIH0gZnJvbSAnLi9zdGFjay9zdGFjay1pdGVtLXNpemUuZGlyZWN0aXZlJztcbmltcG9ydCB7IEZhU3RhY2tDb21wb25lbnQgfSBmcm9tICcuL3N0YWNrL3N0YWNrLmNvbXBvbmVudCc7XG5cbkBOZ01vZHVsZSh7XG4gIGltcG9ydHM6IFtcbiAgICBGYUljb25Db21wb25lbnQsXG4gICAgRmFEdW90b25lSWNvbkNvbXBvbmVudCxcbiAgICBGYUxheWVyc0NvbXBvbmVudCxcbiAgICBGYUxheWVyc1RleHRDb21wb25lbnQsXG4gICAgRmFMYXllcnNDb3VudGVyQ29tcG9uZW50LFxuICAgIEZhU3RhY2tDb21wb25lbnQsXG4gICAgRmFTdGFja0l0ZW1TaXplRGlyZWN0aXZlLFxuICBdLFxuICBleHBvcnRzOiBbXG4gICAgRmFJY29uQ29tcG9uZW50LFxuICAgIEZhRHVvdG9uZUljb25Db21wb25lbnQsXG4gICAgRmFMYXllcnNDb21wb25lbnQsXG4gICAgRmFMYXllcnNUZXh0Q29tcG9uZW50LFxuICAgIEZhTGF5ZXJzQ291bnRlckNvbXBvbmVudCxcbiAgICBGYVN0YWNrQ29tcG9uZW50LFxuICAgIEZhU3RhY2tJdGVtU2l6ZURpcmVjdGl2ZSxcbiAgXSxcbn0pXG5leHBvcnQgY2xhc3MgRm9udEF3ZXNvbWVNb2R1bGUge31cbiJdfQ==