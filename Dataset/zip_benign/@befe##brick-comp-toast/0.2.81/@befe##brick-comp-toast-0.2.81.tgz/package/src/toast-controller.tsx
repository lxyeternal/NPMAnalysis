import {ReactNode, isValidElement} from 'react'
import {ConfigContextValueOffBoard} from '@befe/brick-core'

import {TOAST_TYPES} from './toast'
import {
    CreateToasterOptions,
    ToastItem,
    getToaster,
    removeToast,
} from './toaster'

/**
 * @public
 */
export type ToastOptions = Partial<ToastItem> & CreateToasterOptions

interface ToastMethod {
    (content: ReactNode, option?: Partial<ToastOptions>): ToastObject
    (headline: ReactNode, content?: ReactNode | ToastOptions, option?: Partial<ToastOptions>): ToastObject
}

type BaseToastController = {
    bivarianceHack(options: ToastOptions): ToastObject
}['bivarianceHack']

/**
 * @docgen-skip
 */
export interface ToastController {
    (options: ToastOptions): ToastObject

    success: ToastMethod
    info: ToastMethod
    warning: ToastMethod
    error: ToastMethod
    loading: ToastMethod
}

export interface ToastObject {
    id: string
    remove: () => void
}

let seed = 0
const now = +new Date()
export function getUniqueId() {
    return `TOAST_OBJ_${now}_${seed++}`
}

function toastController(options: ToastOptions) {
    const {headline, content, id = getUniqueId()} = options
    if (content || headline) {
        void getToaster(options).then(toaster => {
            toaster.toast({
                id,
                ...options,
            })
        })
    }

    return {
        id,
        remove: () => removeToast(id),
    }
}

export function createTypedToast(type: Required<ToastOptions['type']>, controller = toastController) {
    return (p1: ReactNode, p2?: ReactNode | ToastOptions, p3?: ToastOptions) => {
        let headline: ReactNode
        let content: ReactNode
        let opt: ToastItem

        const options: ToastOptions = {
            type,
        }

        // p2 is ReactNode
        if (
            typeof p2 === 'number'
            || (p2 && typeof p2 === 'string')
            || isValidElement(p2)
        ) {
            headline = p1
            content = p2
            opt = p3 as ToastItem
        } else {
            content = p1
            opt = p2 as ToastItem
        }

        Object.assign(options, {
            headline,
            content,
        }, opt)

        return controller(options)
    }
}

export function createToast<T = ToastController>(
    configContext: ConfigContextValueOffBoard = {},
    controller: BaseToastController = toastController
) {
    const toastControllerWithConfigContext = (options: ToastOptions) => controller({
        configContext,
        ...options,
    })
    const toastSet: Record<string, ToastMethod> = {}
    TOAST_TYPES.forEach(type => {
        toastSet[type] = createTypedToast(type, toastControllerWithConfigContext)
    })

    Object.assign(toastControllerWithConfigContext, toastSet)
    return toastControllerWithConfigContext as T
}
export const toast = createToast()
