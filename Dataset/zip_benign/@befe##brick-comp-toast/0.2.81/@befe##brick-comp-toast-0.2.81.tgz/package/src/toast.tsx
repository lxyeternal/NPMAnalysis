import {Component, ReactNode} from 'react'
// import * as PropTypes from 'prop-types'
import c from 'classnames'
import {
    codeWarning,
    createDelayHandler,
    pick,
    safeInvoke,
} from '@befe/brick-utils'
import {
    ALERT_TYPES,
    AlertType,
} from '@befe/brick-core'

import {Alert, AlertProps} from '@befe/brick-comp-alert'
import {isUndefined} from 'lodash-es'
import {SvgLoading} from '@befe/brick-icon'
import {TypeTimeout} from '@befe/brick-comp-date-picker/src/module-defs/common-types'

export const TOAST_TYPES = [...ALERT_TYPES, 'loading'] as const

// min 理解为可以适宜阅读的最短时间，而对于最普遍的适用情况，认为"如无必要，不需驻留更长时间"
// 故认为 default 与 min 一致
export const TOAST_DURATION_MIN = 3000
export const TOAST_DURATION_DEFAULT = TOAST_DURATION_MIN

type PropsFromAlert = Pick<AlertProps, 'headline' | 'content' | 'icon'>

export interface ToastProps extends PropsFromAlert {
    /**
     * 自定义 class
     */
    className?: string

    /**
     * 类型
     *
     * @default 'info'
     */
    type?: (typeof TOAST_TYPES)[number]

    /**
     * 标题
     */
    headline?: ReactNode

    /**
     * 内容
     */
    content?: ReactNode

    /**
     * 显示时长
     * - <= 0 表示不自动关闭
     * - <= minDuration 的正值将自动修正为 minDuration
     * - minDuration 是设计规范上定义的常量，不可配置
     * - 目前 minDuration === default === 3s
     *
     * @default 3000
     */
    duration?: number

    /**
     * 关闭回调
     */
    onClose?: () => void

    /**
     * 是否可手动关闭（关闭小叉）
     *
     * @default false
     */
    manualClose?: boolean
}

export const CODE_MSG_DURATION_MIN = [
    `[Toast] \`props.duration\` must greater than \`TOAST_DURATION_MIN\` which is ${TOAST_DURATION_MIN} ms.`,
    'It has been corrected automatically.',
].join(' ')

export const CODE_MSG_DURATION_ZERO = [
    '[Toast] `props.duration` must be not less than `0`.',
    'It has been corrected to `0`, which means no auto-closing.',
].join(' ')

export const CODE_MSG_DURATION_NUMBER = [
    '[Toast] `props.duration` must be `number`.',
    'It has been ignored, and fallback to `TOAST_DURATION_DEFAULT` instead',
].join(' ')

export const CODE_MSG_DURATION_MANUAL_CLOSE = [
    '[Toast] `props.manualClose` has been reset to `true`, while `props.duration` not grater than `0`',
].join('')

// 略大于 animation 的 duration
export const FADE_IN_SLIDE_DURATION = 300

type ToastPropsWithDefaults = ToastProps & Required<Pick<ToastProps, keyof typeof Toast.defaultProps>>

interface ToastState {
    slideIn: boolean
    slideOut: boolean
}

/**
 * @docgen-skip
 */
export class Toast extends Component<ToastProps, ToastState> {
    static displayName = 'Toast'
    // static propTypes = {
    // }
    static defaultProps = {
        className: '',
        duration: TOAST_DURATION_DEFAULT,
        manualClose: false,
        type: 'info',
    }

    state = {
        slideIn: true,
        slideOut: false,
    }

    closeTimer = createDelayHandler(() => {
        this.close()
    }, this.duration)

    slideInTimeout?: TypeTimeout
    slideOutTimeout?: TypeTimeout

    get className() {
        const {className, type} = this.props as ToastPropsWithDefaults
        return c(
            'brick-toast',
            this.state.slideIn && 'brick-toast-slide-in',
            this.state.slideOut && 'brick-toast-slide-out',
            `brick-toast-type-${type}`,
            className
        )
    }

    get duration() {
        const {duration} = this.props

        codeWarning(typeof duration === 'number', CODE_MSG_DURATION_NUMBER)
        if (typeof duration !== 'number') {
            return TOAST_DURATION_DEFAULT
        }

        codeWarning(duration >= 0, CODE_MSG_DURATION_ZERO)
        if (duration <= 0) {
            return 0
        }


        codeWarning(duration >= TOAST_DURATION_MIN, CODE_MSG_DURATION_MIN)
        return Math.max(TOAST_DURATION_MIN, duration)
    }

    get manualClose() {
        if (!this.props.manualClose && this.duration <= 0) {
            codeWarning(false, CODE_MSG_DURATION_MANUAL_CLOSE)
            return true
        }
        return this.props.manualClose
    }

    get alertProps() {
        const {icon, type} = this.props
        const alertProps: AlertProps = pick(this.props, [
            'headline',
            'content',
        ])
        alertProps.icon = icon

        if (this.manualClose) {
            alertProps.onClose = this.close
        }

        if (ALERT_TYPES.includes(type as AlertType)) {
            alertProps.type = type as AlertType
        }

        if (isUndefined(alertProps.icon)) {
            alertProps.icon = type === 'loading'
                ? SvgLoading
                : true
        }

        return alertProps
    }

    handleMouseEnter = () => {
        this.closeTimer.clear()
    }

    handleMouseLeave = () => {
        this.startDelayClose()
    }

    close = () => {
        this.closeTimer.clear()
        safeInvoke(this.props.onClose)
    }

    startDelayClose() {
        if (this.duration) {
            this.closeTimer()
        }
    }

    slideIn() {
        this.slideInTimeout = setTimeout(() => {
            this.setState({
                slideIn: false,
            })
        }, FADE_IN_SLIDE_DURATION)
    }

    slideOut(callback: () => void) {
        this.setState({
            slideOut: true,
        }, () => {
            this.slideOutTimeout = setTimeout(callback, FADE_IN_SLIDE_DURATION)
        })
    }

    componentDidMount(): void {
        this.slideIn()
        this.startDelayClose()
    }

    componentWillUnmount(): void {
        this.closeTimer.clear()
        this.slideInTimeout && clearTimeout(this.slideInTimeout)
        this.slideOutTimeout && clearTimeout(this.slideOutTimeout)
    }

    render() {
        return (
            <div
                className={this.className}
                onMouseEnter={this.handleMouseEnter}
                onMouseLeave={this.handleMouseLeave}
            >
                <Alert {...this.alertProps} />
            </div>
        )
    }
}
