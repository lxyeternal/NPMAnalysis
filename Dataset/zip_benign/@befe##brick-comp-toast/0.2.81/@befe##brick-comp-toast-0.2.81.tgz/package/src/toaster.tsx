import {Component, RefObject, createRef} from 'react'
import {render, unmountComponentAtNode} from 'react-dom'
// import * as PropTypes from 'prop-types'
import c from 'classnames'
import {forceRedraw, safeInvoke} from '@befe/brick-utils'
import {ConfigContextValueOffBoard} from '@befe/brick-core'
import {ConfigProvider} from '@befe/brick-comp-config-provider'
import {kebabCase} from 'lodash-es'

import {Toast, ToastProps} from './toast'

export interface ToastItem extends ToastProps {
    /**
     * 自定义 id
     */
    id: string
}

export interface ToasterProps {
    /**
     * 自定义 class
     */
    className?: string

    /**
     * 位置
     *
     * @default 'top-center'
     */
    placement?: 'top-center' | 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left'
}

export interface CreateToasterOptions extends ToasterProps {
    /**
     * configContext 配置
     *
     * 由于 confirm() 是在页面上另行取 root 进行 render 的，
     * 而 configContext 中除了 `theme`, `i18n` 指向的是模块单例，其他通过 ConfigProvider 配置的值，在不同的 root 间是访问不到的，
     * 不同 root 间的组件向上访问 context 只能访问到 context 的默认值。
     *
     * 所以用于样式隔离方案 `wrapClassName 需要另行提供（相应一样的）配置。
     * @private
     */
    configContext?: ConfigContextValueOffBoard
}


interface ToasterState {
    toastList: ToastItem[]
}

type ToasterPropsWithDefaults = ToasterProps & Required<Pick<ToasterProps, keyof typeof Toaster.defaultProps>>

export class Toaster extends Component<ToasterProps, ToasterState> {
    static displayName = 'Toaster'
    // static propTypes = {}
    static defaultProps = {
        className: '',
        placement: 'top-center',
    }

    refToaster = createRef<HTMLDivElement>()
    state = {
        toastList: [],
    }

    refToast: Record<string, RefObject<Toast>> = {}

    get className() {
        const {className, placement} = this.props as ToasterPropsWithDefaults
        return c(
            'brick-toaster',
            `brick-toaster-placement-${placement}`,
            className
        )
    }

    add(toast: ToastItem) {
        if (!this.refToast[toast.id]) {
            this.refToast[toast.id] = createRef<Toast>()
        }

        this.setState(prevState => {
            const {toastList} = prevState
            if (!toastList.some(t => t.id === toast.id)) {
                return {
                    toastList: toastList.concat(toast),
                }
            }

            return null
        }, () => {
            const toaster = this.refToaster.current

            // @todo: 待验证 并加上限制条件 （safari mac 10.12 ？）
            toaster && forceRedraw(toaster)
        })
    }

    remove(id: string) {
        this.refToast[id]?.current?.slideOut(() => {
            this.setState(prevState => {
                return {
                    toastList: prevState.toastList.filter(t => t.id !== id),
                }
            })
            delete this.refToast[id]
        })
    }

    renderToast(toast: ToastItem) {
        const {id, onClose, ...toastProps} = toast
        return (
            <Toast
                key={id}
                ref={this.refToast[id]}
                onClose={() => {
                    this.remove(id)
                    safeInvoke(onClose)
                }}
                {...toastProps}
            />
        )
    }

    render() {
        const {toastList} = this.state
        return (
            <div className={this.className} ref={this.refToaster}>
                {toastList.map(item => this.renderToast(item))}
            </div>
        )
    }
}

export interface ToasterObject {
    toast: (toast: ToastItem) => void
    remove: (key: string) => void
    destroy: () => void
}

export const DEFAULT_CLASSNAME_TOASTER_CONTAINER = 'brick-toaster-container'
const DEFAULT_TOASTER_PLACEMENT = 'top-center'

function getExistingToasterContainer(containerClassName = DEFAULT_CLASSNAME_TOASTER_CONTAINER) {
    return document.body.querySelector(`.${containerClassName}`)
}

export function isToasterContainerExist(containerClassName = DEFAULT_CLASSNAME_TOASTER_CONTAINER) {
    return !!getExistingToasterContainer(containerClassName)
}

function getPlacementClassName(placement = DEFAULT_TOASTER_PLACEMENT) {
    return `${DEFAULT_CLASSNAME_TOASTER_CONTAINER}-placement-${placement}`
}

function getToasterIdClassName(options: CreateToasterOptions = {}) {
    const {placement = DEFAULT_TOASTER_PLACEMENT, configContext = {}} = options
    const keyOptionNames: Array<keyof ConfigContextValueOffBoard> = ['wrapClassName']
    const configContextValues = keyOptionNames.map((name) => {
        const value = configContext[name]
        return value ? `${kebabCase(name)}-${value}` : ''
    }).filter(Boolean)

    return [
        `placement-${placement}`,
        ...configContextValues,
    ].join('_')
}


export function getToastContainer(options: CreateToasterOptions = {}) {
    const {placement = DEFAULT_TOASTER_PLACEMENT} = options
    const idClassName = getToasterIdClassName(options)

    let container = getExistingToasterContainer(idClassName)
    if (!container) {
        container = document.createElement('div')
        container.className = c(
            DEFAULT_CLASSNAME_TOASTER_CONTAINER,
            getPlacementClassName(placement),
            idClassName
        )
        document.body.appendChild(container)
    }
    return container
}

// 某些情况下，toasterObject.toast() 的调用会抢先于 <Toaster /> 的挂载
// 比如 `useEffect(() => { toast.warning() }, [])`
// createToaster 改为异步的得更严谨，在 <Toaster /> 挂载后 resolve
export function createToaster(options: CreateToasterOptions = {}): Promise<ToasterObject> {
    return new Promise((resolve) => {
        const container = getToastContainer(options)
        const refToaster = createRef<Toaster>()

        const toaster = (
            <ConfigProvider {...options.configContext} isRoot={false}>
                <Toaster ref={refToaster} {...options} />
            </ConfigProvider>
        )

        const renderCallback = () => {
            resolve({
                toast(toast: ToastItem) {
                    refToaster.current?.add(toast)
                },
                remove(key: string) {
                    refToaster.current?.remove(key)
                },
                destroy() {
                    const idClassName = getToasterIdClassName(options)
                    if (!getExistingToasterContainer(idClassName)) {
                        return
                    }
                    unmountComponentAtNode(container)
                    document.body.removeChild(container)
                },
            })
        }

        render(toaster, container, renderCallback)
    })

}

const toasterPromiseMap: Record<string, Promise<ToasterObject>> = {}
export function getToaster(props: ToasterProps) {
    const idClassName = getToasterIdClassName(props)
    toasterPromiseMap[idClassName] = (isToasterContainerExist() && toasterPromiseMap[idClassName])
        || createToaster(props)
    return toasterPromiseMap[idClassName]
}

export function resetToaster() {
    Object.keys(toasterPromiseMap).forEach(key => {
        const toasterPromise = toasterPromiseMap[key]
        void toasterPromise.then(toaster => {
            toaster.destroy()
            delete toasterPromiseMap[key]
        })
    })
}

export function removeToast(id: string) {
    if (id) {
        Object.keys(toasterPromiseMap).forEach(key => {
            void toasterPromiseMap[key].then(toaster => {
                toaster.remove(id)
            })
        })
    }
}
