# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.2.81](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.80...%40befe%2Fbrick-comp-toast%400.2.81) (2025-02-19)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.80](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.79...%40befe%2Fbrick-comp-toast%400.2.80) (2025-02-18)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.79](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.78...%40befe%2Fbrick-comp-toast%400.2.79) (2025-01-21)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.78](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.77...%40befe%2Fbrick-comp-toast%400.2.78) (2024-11-26)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.77](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.76...%40befe%2Fbrick-comp-toast%400.2.77) (2024-11-04)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.76](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.75...%40befe%2Fbrick-comp-toast%400.2.76) (2024-10-15)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.75](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.74...%40befe%2Fbrick-comp-toast%400.2.75) (2024-09-04)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.74](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.73...%40befe%2Fbrick-comp-toast%400.2.74) (2024-09-03)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.73](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.72...%40befe%2Fbrick-comp-toast%400.2.73) (2024-08-14)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.72](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.71...%40befe%2Fbrick-comp-toast%400.2.72) (2024-07-15)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.71](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.70...%40befe%2Fbrick-comp-toast%400.2.71) (2024-07-12)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.70](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.69...%40befe%2Fbrick-comp-toast%400.2.70) (2024-06-18)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.69](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.68...%40befe%2Fbrick-comp-toast%400.2.69) (2024-06-07)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.68](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.67...%40befe%2Fbrick-comp-toast%400.2.68) (2024-05-22)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.67](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.66...%40befe%2Fbrick-comp-toast%400.2.67) (2024-05-17)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.66](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.65...%40befe%2Fbrick-comp-toast%400.2.66) (2024-03-25)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.65](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.64...%40befe%2Fbrick-comp-toast%400.2.65) (2024-03-15)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.64](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.63...%40befe%2Fbrick-comp-toast%400.2.64) (2023-12-18)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.63](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.62...%40befe%2Fbrick-comp-toast%400.2.63) (2023-12-07)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.62](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.151...%40befe%2Fbrick-comp-toast%400.2.62) (2023-12-01)


### Features

* **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))
* **toast:** 提供 `createToast()` 用以应用样式隔离方案时进行 configContext 配置 ([0621f2c](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/0621f2c69901149d412c7840eb3587dfd232897f))





## [0.2.61](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.60...%40befe%2Fbrick-comp-toast%400.2.61) (2023-11-20)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.60](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.59...%40befe%2Fbrick-comp-toast%400.2.60) (2023-11-16)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.59](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.58...%40befe%2Fbrick-comp-toast%400.2.59) (2023-11-09)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.58](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.57...%40befe%2Fbrick-comp-toast%400.2.58) (2023-11-03)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.57](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.56...%40befe%2Fbrick-comp-toast%400.2.57) (2023-10-11)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.56](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.55...%40befe%2Fbrick-comp-toast%400.2.56) (2023-09-25)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.55](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.54...%40befe%2Fbrick-comp-toast%400.2.55) (2023-09-12)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.54](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.53...%40befe%2Fbrick-comp-toast%400.2.54) (2023-08-16)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.53](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.52...%40befe%2Fbrick-comp-toast%400.2.53) (2023-08-15)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.52](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.150...%40befe%2Fbrick-comp-toast%400.2.52) (2023-06-19)


### Features

* **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))
* **toast:** 提供 `createToast()` 用以应用样式隔离方案时进行 configContext 配置 ([0621f2c](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/0621f2c69901149d412c7840eb3587dfd232897f))





## [0.2.51](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.50...%40befe%2Fbrick-comp-toast%400.2.51) (2023-06-07)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.50](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.49...%40befe%2Fbrick-comp-toast%400.2.50) (2023-04-11)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.49](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.149...%40befe%2Fbrick-comp-toast%400.2.49) (2023-03-20)


### Features

* **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))
* **toast:** 提供 `createToast()` 用以应用样式隔离方案时进行 configContext 配置 ([0621f2c](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/0621f2c69901149d412c7840eb3587dfd232897f))





## [0.2.48](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.47...%40befe%2Fbrick-comp-toast%400.2.48) (2023-03-16)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.47](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.148...%40befe%2Fbrick-comp-toast%400.2.47) (2023-03-16)


### Features

* **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))
* **toast:** 提供 `createToast()` 用以应用样式隔离方案时进行 configContext 配置 ([0621f2c](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/0621f2c69901149d412c7840eb3587dfd232897f))





## [0.2.46](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.147...%40befe%2Fbrick-comp-toast%400.2.46) (2023-03-15)


### Features

* **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))
* **toast:** 提供 `createToast()` 用以应用样式隔离方案时进行 configContext 配置 ([0621f2c](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/0621f2c69901149d412c7840eb3587dfd232897f))





## [0.2.45](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.145...%40befe%2Fbrick-comp-toast%400.2.45) (2023-03-01)


### Features

* **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))
* **toast:** 提供 `createToast()` 用以应用样式隔离方案时进行 configContext 配置 ([0621f2c](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/0621f2c69901149d412c7840eb3587dfd232897f))





## [0.2.44](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.144...%40befe%2Fbrick-comp-toast%400.2.44) (2023-02-27)


### Features

* **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))
* **toast:** 提供 `createToast()` 用以应用样式隔离方案时进行 configContext 配置 ([0621f2c](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/0621f2c69901149d412c7840eb3587dfd232897f))





## [0.2.43](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.42...%40befe%2Fbrick-comp-toast%400.2.43) (2023-02-16)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.42](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.41...%40befe%2Fbrick-comp-toast%400.2.42) (2023-02-15)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.41](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.40...%40befe%2Fbrick-comp-toast%400.2.41) (2023-01-30)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.40](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.39...%40befe%2Fbrick-comp-toast%400.2.40) (2023-01-13)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.39](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.38...%40befe%2Fbrick-comp-toast%400.2.39) (2023-01-12)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.38](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.37...%40befe%2Fbrick-comp-toast%400.2.38) (2023-01-11)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.37](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.142...%40befe%2Fbrick-comp-toast%400.2.37) (2023-01-05)


### Features

* **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))
* **toast:** 提供 `createToast()` 用以应用样式隔离方案时进行 configContext 配置 ([0621f2c](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/0621f2c69901149d412c7840eb3587dfd232897f))





## [0.2.36](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.35...%40befe%2Fbrick-comp-toast%400.2.36) (2022-12-22)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.35](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.141...%40befe%2Fbrick-comp-toast%400.2.35) (2022-12-21)


### Features

* **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))





## [0.2.34](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.140...%40befe%2Fbrick-comp-toast%400.2.34) (2022-12-06)


### Features

* **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))





## [0.2.33](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.32...%40befe%2Fbrick-comp-toast%400.2.33) (2022-11-22)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.32](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.139...%40befe%2Fbrick-comp-toast%400.2.32) (2022-11-18)


### Features

* **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))





## [0.2.31](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.30...%40befe%2Fbrick-comp-toast%400.2.31) (2022-11-10)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.30](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.29...%40befe%2Fbrick-comp-toast%400.2.30) (2022-11-08)

**Note:** Version bump only for package @befe/brick-comp-toast





## [0.2.29](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.137...%40befe%2Fbrick-comp-toast%400.2.29) (2022-11-04)

### Features

- **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))

## [0.2.28](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.27...%40befe%2Fbrick-comp-toast%400.2.28) (2022-10-26)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.27](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.26...%40befe%2Fbrick-comp-toast%400.2.27) (2022-10-24)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.26](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.135...%40befe%2Fbrick-comp-toast%400.2.26) (2022-10-21)

### Features

- **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))

## [0.2.25](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.134...%40befe%2Fbrick-comp-toast%400.2.25) (2022-09-29)

### Features

- **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))

## [0.2.24](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.133...%40befe%2Fbrick-comp-toast%400.2.24) (2022-09-20)

### Features

- **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))

## [0.2.23](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.22...%40befe%2Fbrick-comp-toast%400.2.23) (2022-09-08)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.22](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.21...%40befe%2Fbrick-comp-toast%400.2.22) (2022-09-07)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.21](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.132...%40befe%2Fbrick-comp-toast%400.2.21) (2022-09-02)

### Features

- **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))

## [0.2.20](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.19...%40befe%2Fbrick-comp-toast%400.2.20) (2022-08-17)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.19](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.130...%40befe%2Fbrick-comp-toast%400.2.19) (2022-08-15)

### Features

- **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))

## [0.2.18](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.17...%40befe%2Fbrick-comp-toast%400.2.18) (2022-08-08)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.17](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.16...%40befe%2Fbrick-comp-toast%400.2.17) (2022-07-22)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.16](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.129...%40befe%2Fbrick-comp-toast%400.2.16) (2022-06-30)

### Features

- **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))

## [0.2.15](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.14...%40befe%2Fbrick-comp-toast%400.2.15) (2022-06-23)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.14](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.13...%40befe%2Fbrick-comp-toast%400.2.14) (2022-06-17)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.13](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.12...%40befe%2Fbrick-comp-toast%400.2.13) (2022-06-14)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.12](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.128...%40befe%2Fbrick-comp-toast%400.2.12) (2022-06-14)

### Features

- **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))

## [0.2.11](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.10...%40befe%2Fbrick-comp-toast%400.2.11) (2022-06-07)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.10](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.9...%40befe%2Fbrick-comp-toast%400.2.10) (2022-06-07)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.9](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.8...%40befe%2Fbrick-comp-toast%400.2.9) (2022-05-27)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.8](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.7...%40befe%2Fbrick-comp-toast%400.2.8) (2022-05-18)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.7](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.6...%40befe%2Fbrick-comp-toast%400.2.7) (2022-05-11)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.6](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.5...%40befe%2Fbrick-comp-toast%400.2.6) (2022-05-09)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.5](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.2.4...%40befe%2Fbrick-comp-toast%400.2.5) (2022-04-22)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.4](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.126...%40befe%2Fbrick-comp-toast%400.2.4) (2022-04-19)

### Features

- **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))

## [0.2.3](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.2...%40befe%2Fbrick-comp-toast%400.2.3) (2022-04-01)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.2](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.1...%40befe%2Fbrick-comp-toast%400.2.2) (2022-03-30)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.2.1](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.2.0...%40befe%2Fbrick-comp-toast%400.2.1) (2022-03-29)

**Note:** Version bump only for package @befe/brick-comp-toast

# [0.2.0](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.125...%40befe%2Fbrick-comp-toast%400.2.0) (2022-03-29)

### Features

- **toast:** toaster 加入 placement 支持 ([2d9e4b0](https://icode.baidu.com/repos/baidu/be-fe/brick/commits/2d9e4b09d3f1a17a48c71f3e837e2847d40e8f9e))

## [0.1.125](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.124...%40befe%2Fbrick-comp-toast%400.1.125) (2022-02-17)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.124](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.123...%40befe%2Fbrick-comp-toast%400.1.124) (2022-02-14)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.123](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.122...%40befe%2Fbrick-comp-toast%400.1.123) (2022-01-26)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.122](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.121...%40befe%2Fbrick-comp-toast%400.1.122) (2021-12-13)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.121](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.120...%40befe%2Fbrick-comp-toast%400.1.121) (2021-12-07)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.120](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.119...%40befe%2Fbrick-comp-toast%400.1.120) (2021-11-30)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.119](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.118...%40befe%2Fbrick-comp-toast%400.1.119) (2021-10-28)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.118](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.117...%40befe%2Fbrick-comp-toast%400.1.118) (2021-10-22)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.117](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.116...%40befe%2Fbrick-comp-toast%400.1.117) (2021-10-19)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.116](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.115...%40befe%2Fbrick-comp-toast%400.1.116) (2021-10-12)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.115](https://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.114...%40befe%2Fbrick-comp-toast%400.1.115) (2021-09-15)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.114](https://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.113...%40befe%2Fbrick-comp-toast%400.1.114) (2021-08-18)

**Note:** Version bump only for package @befe/brick-comp-toast

## 0.1.113 (2021-07-01)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.112](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.111...%40befe%2Fbrick-comp-toast%400.1.112) (2021-06-17)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.111](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.110...%40befe%2Fbrick-comp-toast%400.1.111) (2021-06-01)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.110](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.109...%40befe%2Fbrick-comp-toast%400.1.110) (2021-05-13)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.109](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.108...%40befe%2Fbrick-comp-toast%400.1.109) (2021-04-20)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.108](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.107...%40befe%2Fbrick-comp-toast%400.1.108) (2021-04-01)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.107](http://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.106...%40befe%2Fbrick-comp-toast%400.1.107) (2021-03-29)

### Bug Fixes

- 修正各组件 peerDependecy `mobx` 的版本号 ([321ed47](http://icode.baidu.com/repos/baidu/be-fe/brick/commits/321ed4704f2bd53449c6c71f1a340db427d4c656))

## [0.1.106](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.105...%40befe%2Fbrick-comp-toast%400.1.106) (2021-03-29)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.105](http://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.104...%40befe%2Fbrick-comp-toast%400.1.105) (2021-03-23)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.104](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.103...%40befe%2Fbrick-comp-toast%400.1.104) (2021-03-16)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.103](http://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.102...%40befe%2Fbrick-comp-toast%400.1.103) (2021-02-22)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.102](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.101...%40befe%2Fbrick-comp-toast%400.1.102) (2021-02-09)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.101](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.100...%40befe%2Fbrick-comp-toast%400.1.101) (2021-02-08)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.100](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.99...%40befe%2Fbrick-comp-toast%400.1.100) (2021-02-07)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.99](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.98...%40befe%2Fbrick-comp-toast%400.1.99) (2021-01-19)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.98](http://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.97...%40befe%2Fbrick-comp-toast%400.1.98) (2021-01-18)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.97](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.96...%40befe%2Fbrick-comp-toast%400.1.97) (2020-12-17)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.96](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.95...%40befe%2Fbrick-comp-toast%400.1.96) (2020-12-09)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.95](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.94...%40befe%2Fbrick-comp-toast%400.1.95) (2020-12-03)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.94](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.93...%40befe%2Fbrick-comp-toast%400.1.94) (2020-11-23)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.93](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.92...%40befe%2Fbrick-comp-toast%400.1.93) (2020-11-17)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.92](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.91...%40befe%2Fbrick-comp-toast%400.1.92) (2020-11-09)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.91](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.90...%40befe%2Fbrick-comp-toast%400.1.91) (2020-10-27)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.90](http://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.89...%40befe%2Fbrick-comp-toast%400.1.90) (2020-10-19)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.89](http://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.88...%40befe%2Fbrick-comp-toast%400.1.89) (2020-09-17)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.88](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.87...%40befe%2Fbrick-comp-toast%400.1.88) (2020-09-07)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.87](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.86...%40befe%2Fbrick-comp-toast%400.1.87) (2020-08-28)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.86](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.85...%40befe%2Fbrick-comp-toast%400.1.86) (2020-08-17)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.85](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.84...%40befe%2Fbrick-comp-toast%400.1.85) (2020-08-06)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.84](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.83...%40befe%2Fbrick-comp-toast%400.1.84) (2020-08-05)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.83](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.82...%40befe%2Fbrick-comp-toast%400.1.83) (2020-08-04)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.82](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.81...%40befe%2Fbrick-comp-toast%400.1.82) (2020-08-03)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.81](http://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.80...%40befe%2Fbrick-comp-toast%400.1.81) (2020-07-31)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.80](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.79...%40befe%2Fbrick-comp-toast%400.1.80) (2020-07-27)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.79](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.78...%40befe%2Fbrick-comp-toast%400.1.79) (2020-07-22)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.78](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.77...%40befe%2Fbrick-comp-toast%400.1.78) (2020-07-21)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.77](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.76...%40befe%2Fbrick-comp-toast%400.1.77) (2020-07-20)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.76](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.75...%40befe%2Fbrick-comp-toast%400.1.76) (2020-07-16)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.75](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.74...%40befe%2Fbrick-comp-toast%400.1.75) (2020-07-16)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.74](http://icode.baidu.com:8235/baidu/be-fe/brick//%40befe%2Fbrick-comp-toast%400.1.73...%40befe%2Fbrick-comp-toast%400.1.74) (2020-07-16)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.73](http://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.72...%40befe%2Fbrick-comp-toast%400.1.73) (2020-07-15)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.72](http://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.71...%40befe%2Fbrick-comp-toast%400.1.72) (2020-07-06)

**Note:** Version bump only for package @befe/brick-comp-toast

## [0.1.71](http://icode.baidu.com/repos/baidu/be-fe/brick/merge/%40befe%2Fbrick-comp-toast%400.1.71...%40befe%2Fbrick-comp-toast%400.1.71) (2020-07-05)

### Bug Fixes

- **core:** 修正 type 名 AlertType ([8ab1fa7](http://icode.baidu.com/repos/baidu/be-fe/brick/commits/8ab1fa7b9651ee8935aa822a891b580604109048))
- **toast:** import 依赖组件的样式，并清理多余的依赖项 ([83e769e](http://icode.baidu.com/repos/baidu/be-fe/brick/commits/83e769e506d7447a2ce8128623ca46706a3bd202))
- **toast:** 修正 z-index 修饰，保证 toast 不被 dialog 盖住 ([e084a66](http://icode.baidu.com/repos/baidu/be-fe/brick/commits/e084a66740f7d01f3225b66751625ba27b09a4c9))
- 修复各组件的 index.scss 中对依赖组件样式的引用，应引用依赖 index.scss ([b7c32eb](http://icode.baidu.com/repos/baidu/be-fe/brick/commits/b7c32eb53b575d6cbd92cf5b01e8e1cbd44ab2ba))
- **toast:** 尝试 toaster.add 后进行 forceRedraw ([9c3cdbf](http://icode.baidu.com/repos/baidu/be-fe/brick/commits/9c3cdbf6b8cb19427f6ded02573fa0ec4adcda2a))

### Features

- **toast:** 加入手工关闭功能 ([14cac85](http://icode.baidu.com/repos/baidu/be-fe/brick/commits/14cac857d2eb5bd6366b127011d1da280342ce8d))
