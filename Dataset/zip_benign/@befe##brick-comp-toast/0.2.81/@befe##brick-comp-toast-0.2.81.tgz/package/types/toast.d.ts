import { Component, ReactNode } from 'react';
import { AlertProps } from '@befe/brick-comp-alert';
import { TypeTimeout } from '@befe/brick-comp-date-picker/src/module-defs/common-types';
export declare const TOAST_TYPES: readonly ["info", "success", "warning", "error", "loading"];
export declare const TOAST_DURATION_MIN = 3000;
export declare const TOAST_DURATION_DEFAULT = 3000;
type PropsFromAlert = Pick<AlertProps, 'headline' | 'content' | 'icon'>;
export interface ToastProps extends PropsFromAlert {
    /**
     * 自定义 class
     */
    className?: string;
    /**
     * 类型
     *
     * @default 'info'
     */
    type?: (typeof TOAST_TYPES)[number];
    /**
     * 标题
     */
    headline?: ReactNode;
    /**
     * 内容
     */
    content?: ReactNode;
    /**
     * 显示时长
     * - <= 0 表示不自动关闭
     * - <= minDuration 的正值将自动修正为 minDuration
     * - minDuration 是设计规范上定义的常量，不可配置
     * - 目前 minDuration === default === 3s
     *
     * @default 3000
     */
    duration?: number;
    /**
     * 关闭回调
     */
    onClose?: () => void;
    /**
     * 是否可手动关闭（关闭小叉）
     *
     * @default false
     */
    manualClose?: boolean;
}
export declare const CODE_MSG_DURATION_MIN: string;
export declare const CODE_MSG_DURATION_ZERO: string;
export declare const CODE_MSG_DURATION_NUMBER: string;
export declare const CODE_MSG_DURATION_MANUAL_CLOSE: string;
export declare const FADE_IN_SLIDE_DURATION = 300;
interface ToastState {
    slideIn: boolean;
    slideOut: boolean;
}
/**
 * @docgen-skip
 */
export declare class Toast extends Component<ToastProps, ToastState> {
    static displayName: string;
    static defaultProps: {
        className: string;
        duration: number;
        manualClose: boolean;
        type: string;
    };
    state: {
        slideIn: boolean;
        slideOut: boolean;
    };
    closeTimer: import("@befe/brick-utils").DelayHandler<[], void>;
    slideInTimeout?: TypeTimeout;
    slideOutTimeout?: TypeTimeout;
    get className(): string;
    get duration(): number;
    get manualClose(): boolean | undefined;
    get alertProps(): AlertProps;
    handleMouseEnter: () => void;
    handleMouseLeave: () => void;
    close: () => void;
    startDelayClose(): void;
    slideIn(): void;
    slideOut(callback: () => void): void;
    componentDidMount(): void;
    componentWillUnmount(): void;
    render(): JSX.Element;
}
export {};
