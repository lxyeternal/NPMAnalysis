import { Component, RefObject } from 'react';
import { ConfigContextValueOffBoard } from '@befe/brick-core';
import { Toast, ToastProps } from './toast';
export interface ToastItem extends ToastProps {
    /**
     * 自定义 id
     */
    id: string;
}
export interface ToasterProps {
    /**
     * 自定义 class
     */
    className?: string;
    /**
     * 位置
     *
     * @default 'top-center'
     */
    placement?: 'top-center' | 'top-right' | 'top-left' | 'bottom-right' | 'bottom-left';
}
export interface CreateToasterOptions extends ToasterProps {
    /**
     * configContext 配置
     *
     * 由于 confirm() 是在页面上另行取 root 进行 render 的，
     * 而 configContext 中除了 `theme`, `i18n` 指向的是模块单例，其他通过 ConfigProvider 配置的值，在不同的 root 间是访问不到的，
     * 不同 root 间的组件向上访问 context 只能访问到 context 的默认值。
     *
     * 所以用于样式隔离方案 `wrapClassName 需要另行提供（相应一样的）配置。
     * @private
     */
    configContext?: ConfigContextValueOffBoard;
}
interface ToasterState {
    toastList: ToastItem[];
}
export declare class Toaster extends Component<ToasterProps, ToasterState> {
    static displayName: string;
    static defaultProps: {
        className: string;
        placement: string;
    };
    refToaster: RefObject<HTMLDivElement>;
    state: {
        toastList: never[];
    };
    refToast: Record<string, RefObject<Toast>>;
    get className(): string;
    add(toast: ToastItem): void;
    remove(id: string): void;
    renderToast(toast: ToastItem): JSX.Element;
    render(): JSX.Element;
}
export interface ToasterObject {
    toast: (toast: ToastItem) => void;
    remove: (key: string) => void;
    destroy: () => void;
}
export declare const DEFAULT_CLASSNAME_TOASTER_CONTAINER = "brick-toaster-container";
export declare function isToasterContainerExist(containerClassName?: string): boolean;
export declare function getToastContainer(options?: CreateToasterOptions): Element;
export declare function createToaster(options?: CreateToasterOptions): Promise<ToasterObject>;
export declare function getToaster(props: ToasterProps): Promise<ToasterObject>;
export declare function resetToaster(): void;
export declare function removeToast(id: string): void;
export {};
