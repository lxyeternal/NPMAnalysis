import { ReactNode } from 'react';
import { ConfigContextValueOffBoard } from '@befe/brick-core';
import { CreateToasterOptions, ToastItem } from './toaster';
/**
 * @public
 */
export type ToastOptions = Partial<ToastItem> & CreateToasterOptions;
interface ToastMethod {
    (content: ReactNode, option?: Partial<ToastOptions>): ToastObject;
    (headline: ReactNode, content?: ReactNode | ToastOptions, option?: Partial<ToastOptions>): ToastObject;
}
type BaseToastController = {
    bivarianceHack(options: ToastOptions): ToastObject;
}['bivarianceHack'];
/**
 * @docgen-skip
 */
export interface ToastController {
    (options: ToastOptions): ToastObject;
    success: ToastMethod;
    info: ToastMethod;
    warning: ToastMethod;
    error: ToastMethod;
    loading: ToastMethod;
}
export interface ToastObject {
    id: string;
    remove: () => void;
}
export declare function getUniqueId(): string;
declare function toastController(options: ToastOptions): {
    id: string;
    remove: () => void;
};
export declare function createTypedToast(type: Required<ToastOptions['type']>, controller?: typeof toastController): (p1: ReactNode, p2?: ReactNode | ToastOptions, p3?: ToastOptions) => {
    id: string;
    remove: () => void;
};
export declare function createToast<T = ToastController>(configContext?: ConfigContextValueOffBoard, controller?: BaseToastController): T;
export declare const toast: ToastController;
export {};
