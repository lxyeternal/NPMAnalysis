# lightningchart 版曲线图表

@castianta/chart-line-lc

曲线图表

## API

| 参数名      | 说明                                                                                               | 必填 | 类型                                                                 | 默认值                                                      | 备注                                                                                                        |
| ----------- | -------------------------------------------------------------------------------------------------- | ---- | -------------------------------------------------------------------- | ----------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------- |
| card        | 面板                                                                                               | 否   | [ProCardProps](https://procomponents.ant.design/components/list#api) | `-`                                                         | `-`                                                                                                         |
| dataSource  | 数据源                                                                                             | 否   | Object[DataSourceProps]                                              | `-`                                                         | `见下`                                                                                                      |
| legend      | 图例                                                                                               | 否   | LegendProps                                                          | `-`                                                         | `见下`                                                                                                      |
| init        | 初始化图表配置参数                                                                                 | 否   | InitProps                                                            | `-`                                                         | `见下`                                                                                                      |
| chart3D     | 2D 3D 切换                                                                                         | 否   | Boolean                                                              | `false`                                                     | `-`                                                                                                         |
| xAxis       | 默认 x 轴配置                                                                                      | 否   | AxisProps                                                            | `-`                                                         | `见下`                                                                                                      |
| yAxis       | 默认 y 轴配置                                                                                      | 否   | AxisProps                                                            | `-`                                                         | `见下`                                                                                                      |
| chartRender | 自定义渲染方式，此方法开启默认渲染方式不渲染，chart 图表实例，config 配置参数，dataSource 传入数据 | 否   | Function                                                             | (chart,config:{line:Function,axis:Function},dataSource)=>{} | `config.line = ({line,list:dataSource[index],index})=>line , config.axis = ({axis,config:AxisProps})=>axis` |

### InitProps

| 参数名      | 说明            | 必填 | 类型                                                                                                  | 默认值              | 备注 |
| ----------- | --------------- | ---- | ----------------------------------------------------------------------------------------------------- | ------------------- | ---- |
| width       | 图表宽度        | 否   | Number 或 undefined                                                                                   | `undefined`         | `-`  |
| height      | 图表高度        | 否   | Number 或 undefined                                                                                   | `400`               | `-`  |
| title       | 图表标题        | 否   | String                                                                                                | `-`                 | `-`  |
| theme       | 皮肤            | 否   | [ThemesProps](https://www.arction.com/lightningchart-js-api-documentation/v3.0.0/globals.html#themes) | `-`                 | `-`  |
| emptyFill   | title 空置状态  | 否   | Boolean                                                                                               | `false`             | `-`  |
| titleColor  | title 填充色    | 否   | String                                                                                                | `#000`              | `-`  |
| boundingBox | 3D 视图盒子大小 | 否   | Object                                                                                                | `{x:1,y:0.5,z:0.4}` | `-`  |

### DataSourceProps

| 参数名    | 说明     | 必填 | 类型     | 默认值    | 备注 |
| --------- | -------- | ---- | -------- | --------- | ---- |
| name      | 曲线名称 | 是   | String   | `-`       | `-`  |
| data      | 曲线数据 | 是   | Object[] | `{x,y,z}` | `-`  |
| color     | 线条颜色 | 否   | String   | `#000`    | `-`  |
| thickness | 线条厚度 | 否   | Number   | `1`       | `-`  |

### LegendProps

| 参数名     | 说明                                               | 必填 | 类型                                                                                                                                                                                                    | 默认值            | 备注                              |
| ---------- | -------------------------------------------------- | ---- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------- | --------------------------------- |
| show       | 显隐                                               | 否   | Boolean                                                                                                                                                                                                 | `false`           | `-`                               |
| title      | 标题                                               | 否   | String                                                                                                                                                                                                  | `legend`          | `-`                               |
| emptyFill  | title 空置状态                                     | 否   | Boolean                                                                                                                                                                                                 | `false`           | `-`                               |
| titleColor | title 填充色                                       | 否   | String                                                                                                                                                                                                  | `#000`            | `-`                               |
| position   | 位置 disable 为 false 默认系统配置 true 自定义位置 | 否   | Object                                                                                                                                                                                                  | `#000`            | `{dislabe:false,point:{x:0,y:0}}` |
| direction  | 条目排列方向                                       | 否   | `'vertical' 或 'horizontal'`                                                                                                                                                                            | `vertical`        | `-`                               |
| entries    | 使用回调函数设置 LegendBoxEntries 的样式           | 否   | [(entry, component) => entry.setTextFillStyle(new SolidFill({ color: ColorRGBA(255, 0, 0) }))](https://www.arction.com/lightningchart-js-api-documentation/v3.0.0/interfaces/legendbox.html#setentries) | `() => undefined` | `-`                               |

### AxisProps

| 参数名             | 说明         | 必填 | 类型                                                                                                                                         | 默认值      | 备注                                                                                                            |
| ------------------ | ------------ | ---- | -------------------------------------------------------------------------------------------------------------------------------------------- | ----------- | --------------------------------------------------------------------------------------------------------------- |
| title              | 轴名称       | 否   | String                                                                                                                                       | `-`         | `-`                                                                                                             |
| scrollStrategy     | 滚动策略     | 否   | `fitting 或 expansion 或 progressive 或 regressive`                                                                                          | `fitting`   | `-`                                                                                                             |
| tickStrategy       | 刻度策略     | 否   | `Empty 或 Numeric 或 DateTime 或 Time`                                                                                                       | `Numeric`   | `-`                                                                                                             |
| tickStrategyStyler | 刻度策略回调 | 否   | [(TickStrategyStyler)=>tickStrategy](https://www.arction.com/lightningchart-js-api-documentation/v3.0.0/classes/axis3d.html#settickstrategy) | `-`         | `-`                                                                                                             |
| animationScroll    | 动画滚动     | 否   | `boolean 或 undefined`                                                                                                                       | `undefined` | `-`                                                                                                             |
| interval           | 轴刻度间隔   | 否   | [Array](https://www.arction.com/lightningchart-js-api-documentation/v3.0.0/classes/axis3d.html#setinterval)                                  | `undefined` | `[start: number, end: number, animate: number 或 boolean 或 undefined, disableScrolling: boolean 或 undefined]` |
