---
title: 基础用法
order: 1
---

配置功能演示

```jsx
<DemoCode src="../../src/demo/line.jsx" />
```
