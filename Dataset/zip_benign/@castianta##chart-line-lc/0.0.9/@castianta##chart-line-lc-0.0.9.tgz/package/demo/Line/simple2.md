---
title: 自定义渲染
order: 2
---

自定义多维轴曲线 3D 模式不可用

```jsx
<DemoCode src="../../src/demo/lineRender.jsx" />
```
