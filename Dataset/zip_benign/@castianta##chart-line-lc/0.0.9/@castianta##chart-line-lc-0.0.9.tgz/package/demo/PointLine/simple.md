---
title: 点曲线
order: 1
---

演示

```jsx
<DemoCode src="../../src/demo/pointLine.jsx" />
```
