import { NodeEditor } from "rete";
export declare class Background {
    constructor(editor: NodeEditor, element: HTMLElement | true);
}
