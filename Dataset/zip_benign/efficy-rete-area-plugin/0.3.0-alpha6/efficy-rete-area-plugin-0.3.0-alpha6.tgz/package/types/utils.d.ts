import { Node, NodeEditor } from "rete";
export declare function nodesBBox(editor: NodeEditor, nodes: Node[]): {
    left: number;
    right: number;
    top: number;
    bottom: number;
    width: number;
    height: number;
    getCenter: () => number[];
};
