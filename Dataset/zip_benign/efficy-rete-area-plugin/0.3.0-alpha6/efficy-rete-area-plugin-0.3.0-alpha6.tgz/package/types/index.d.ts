import './style.sass';
import { NodeEditor } from 'rete';
declare const _default: {
    name: string;
    install: (context: any, options?: any) => void;
    zoomAt: (editor: NodeEditor, nodes?: import("rete").Node[]) => void;
};
export default _default;
