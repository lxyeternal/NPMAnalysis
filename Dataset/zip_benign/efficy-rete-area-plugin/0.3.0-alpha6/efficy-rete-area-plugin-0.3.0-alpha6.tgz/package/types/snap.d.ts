import { Node, NodeEditor } from "rete";
export declare type SnapParam = {
    size: number;
    dynamic: boolean;
};
export declare class SnapGrid {
    editor: NodeEditor;
    size: number;
    constructor(editor: NodeEditor, params: SnapParam);
    onTranslate(data: {
        node: Node;
        x: number;
        y: number;
    }): void;
    onDrag(node: Node): void;
    snap(value: number): number;
}
