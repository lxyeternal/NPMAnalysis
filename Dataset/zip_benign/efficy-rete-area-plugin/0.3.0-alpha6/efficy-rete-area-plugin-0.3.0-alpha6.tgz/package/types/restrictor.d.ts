import { NodeEditor } from "rete";
export declare type ScaleExtentType = {
    min: number;
    max: number;
};
export declare type TranslateExtentType = {
    width: number;
    height: number;
};
declare type TranslateParam = {
    x: number;
    y: number;
    transform: {
        k: number;
    };
};
declare type ZoomParam = {
    zoom: number;
};
export declare class Restrictor {
    editor: NodeEditor;
    scaleExtent: ScaleExtentType | undefined;
    translateExtent: TranslateExtentType | undefined;
    constructor(editor: NodeEditor, scaleExtent: ScaleExtentType | undefined | boolean, translateExtent: TranslateExtentType | undefined | boolean);
    restrictZoom(data: ZoomParam): void;
    restrictTranslate(data: TranslateParam): void;
}
export {};
