import { NodeEditor, Node } from "rete";
export declare const zoomAt: (editor: NodeEditor, nodes?: Node[]) => void;
