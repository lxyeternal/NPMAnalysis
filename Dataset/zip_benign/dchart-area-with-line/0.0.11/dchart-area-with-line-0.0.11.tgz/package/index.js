require('./theme.css');
//var Area = require('../../area');
var Area = require('dchart-core/area/area');
var d3 = require('d3');
var _ = require('dchart-core/util');

function AreaLine(container, options) {
  var opt = {
    gradientColors : {
      from: 'RGBA(0, 180, 255, .7)',
      to: 'rgba(255,255,255, .01)',
      orient: 'vertical',
    },
    tooltip: {
      axisPointer: 'line'
    }
  }
  opt = _.deepMerge(opt, options);
  this.ids = [];
  Area.call(this, container, opt);
}

AreaLine = Area.extend(AreaLine, {
  calOrient : function (orient) {
    if (orient === 'vertical') {
      return 'x1="0%" y1="0%" x2="0%" y2="100%"';
    }
    if (orient === 'horizental') {
      return 'x1="0%" y1="0%" x2="100%" y2="0%"';
    }
    return null;
  },
  beforeRender : function () {
    var opt = this.options;
    if (!opt.gradientColors.length) {
      opt.gradientColors = [opt.gradientColors];
    }
  },
  updateBeforeRender : function () {
    this.beforeRender();
  },
  renderSeries : function () {
    Area.prototype.renderSeries.call(this);
    var opt = this.options;
    var data = this.data();
    var x = this.getComs('axis', 'xaxis').getX();
    var yAxis = this.getComs('axis', 'yaxis');
    var y = yAxis.getX();
    var xkey = opt.xaxis.key;
    var ykey = opt.yaxis.key;

    var len = _.maxBy(data, function (n) {
      return n[ykey].length
    })[ykey].length
    var svg = this.svg.append('g')
      .attr('class', 'line-g')
      .datum(data);

    for (var i = 0; i < len; i++) {
      var line = d3.svg.line()
        .x(function(d) {
          return x(opt.xaxis.type === 'time' ? new Date(d[xkey]) : d[xkey]) +
            (x.rangeBand ?  x.rangeBand() / 2 : 0) })
        .y(function(d) { return y(d[ykey][i] || yAxis.getMin()); });

      if (opt.interpolate) {
        line.interpolate(opt.interpolate);
      }
      svg.append('path')
        .attr({
          "class": "serie serie" + (i+1),
          "d": line
        });
    }
  },
  afterRender: function () {
    Area.prototype.afterRender.call(this);
    var opt = this.options;
    var self = this;
    opt.gradientColors.forEach(function (color, i) {
      if (!self.ids[i]) {
        var id = 'linear' + Math.random().toString(36).substr(2)
        self.ids.push(id);
        self.svg.append('defs')
          .html('<linearGradient id="' + id + '" ' + self.calOrient(color.orient) + '>\
        <stop offset="0%" style="stop-color:' + color.from + ';\
        stop-opacity:1"/>\
        <stop offset="100%" style="stop-color:' + color.to + ';\
        stop-opacity:1"/>\
        </linearGradient>')
      } else {
        var gradient = self.svg.selectAll('#' + self.ids[i]);
        gradient.select('stop[offset="0%"]').style('stop-color', color.from)
        gradient.select('stop[offset="100%"]').style('stop-color', color.to)
      }
    });
    for (var i = 1; i <= opt.gradientColors.length; i++) {
      this.series.selectAll('.serie' + i).style('fill', 'url(#' + this.ids[i-1] + ')')
    }
    this.svg[0][0].appendChild(this.svg.select('.line-g')[0][0])
  },
  updateAfterRender: function () {
    AreaLine.prototype.afterRender.call(this);
  },
  updateSeries : function () {
    Area.prototype.updateSeries.call(this);
    var opt = this.options;
    var xkey = opt.xaxis.key;
    var ykey = opt.yaxis.key;
    var data = this.data();
    var x = this.getComs('axis', 'xaxis').getX();
    var yAxis = this.getComs('axis', 'yaxis');
    var y = yAxis.getX();

    var len = _.maxBy(data, function (n) {
      return n[ykey].length
    })[ykey].length

    var series = this.svg.select('.line-g').datum(data);
    for (var i = 0; i < len; i++) {
      var line = d3.svg.line()
        .x(function(d) {
          return x(opt.xaxis.type === 'time' ? new Date(d[xkey]) : d[xkey]) +
            (x.rangeBand ?  x.rangeBand() / 2 : 0) })
        .y(function(d) { return y(d[ykey][i] || yAxis.getMin()); });

      if (opt.interpolate) {
        line.interpolate(opt.interpolate);
      }

      series.select('.serie.serie' + (i+1))
        .attr({"d": line});
    }

    series.selectAll('.serie.serie' + len + ' ~ .serie').remove();
  }
});

module.exports = AreaLine;