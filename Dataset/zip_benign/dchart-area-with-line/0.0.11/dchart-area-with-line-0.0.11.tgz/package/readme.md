dchart-area-with-line

符合dchart规范的区域折线图

### 安装

```
npm install dchart-area-with-line
```

### 用法
```
var Area = require('dchart-area-with-line');
var area = new Area(container, {
  xaxis: {
    type: 'time',           //轴类型
    format: '%Y/%m/%d %H:%M:%S',  //数据中的时间格式
    tickFormat: d3.time.format('%H:%M'),  //刻度上显示的时间格式化
    padding: [0.3, 0],      //柱状子间的间距[innerPadding, outerPadding],默认[0.9, 0.4]
    dy: 40,                 //位移
  },
  yaxis: {
    min: null,                 //默认null会自动计算数据中的最小值
    max: null,                 //默认null会自动计算数据中的最大值
    tickFormat: function () {},
    ticks: 4                   //显示4个刻度
  },
  gradientColors: {
    from: 'RGBA(0, 180, 255, .7)',     //渐变色起始值
    to: 'rgba(255,255,255, .01)',      //渐变色终止值
    orient: 'vertical',
  }
});
area.render([
        {"x": "2010/01/01 00:00:00", "y": [100, 66]},
        {"x": "2010/01/02 00:00:00", "y": [52, 99]},
        {"x": "2010/01/03 00:00:00", "y": [49, 78]}
      ]);
```
