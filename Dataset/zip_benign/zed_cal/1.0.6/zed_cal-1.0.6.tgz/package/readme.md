**加减乘除四则运算**
`输入：`
`{
    //公式
    formula: '(x+y)*z',
    //参数
    data: {
        x: 0.1,
        y: 0.2,
        z: 1
    }
}`
`输出：`
0.3

**使用**
const cal = require('zed_cal');
const result = cal.cal(' {formula: '(x+y)*z',data: { x: 0.1, y: 0.2, z: 1 } }');
