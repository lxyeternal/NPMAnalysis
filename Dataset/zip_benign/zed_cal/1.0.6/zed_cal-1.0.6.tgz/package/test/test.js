/**
 * Created by Zed on 2021/6/13
 */

const cal = require('zed_cal');

const result = cal.cal({formula: '(x + y) * z', data: {x: 0.1, y: 0.2, z: 1}});
console.log(result);


