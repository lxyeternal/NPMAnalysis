/* tslint:disable */
/* eslint-disable */
/**
* @param {Float64Array} pts
* @param {number | undefined} num_of_segments
* @param {number | undefined} tension
* @param {Float64Array | undefined} custom_tensions
* @param {number | undefined} invert_x_with_width
* @param {number | undefined} invert_y_with_height
* @param {Float64Array | undefined} hidden_point_at_start
* @param {Float64Array | undefined} hidden_point_at_end
* @returns {Float64Array}
*/
export function getCurvePoints(pts: Float64Array, num_of_segments?: number, tension?: number, custom_tensions?: Float64Array, invert_x_with_width?: number, invert_y_with_height?: number, hidden_point_at_start?: Float64Array, hidden_point_at_end?: Float64Array): Float64Array;
