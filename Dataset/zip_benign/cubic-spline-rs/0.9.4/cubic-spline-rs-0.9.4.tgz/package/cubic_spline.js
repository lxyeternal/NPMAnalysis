import * as wasm from "./cubic_spline_bg.wasm";
export * from "./cubic_spline_bg.js";