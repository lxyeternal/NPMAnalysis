(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@scullyio/scully')) :
    typeof define === 'function' && define.amd ? define('@gammastream/scully-plugin-sitemap', ['exports', '@scullyio/scully'], factory) :
    (global = global || self, factory((global.gammastream = global.gammastream || {}, global.gammastream['scully-plugin-sitemap'] = {}), global.scully));
}(this, (function (exports, scully) { 'use strict';

    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (Object.prototype.hasOwnProperty.call(b, p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (_)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        Object.defineProperty(o, k2, { enumerable: true, get: function () { return m[k]; } });
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, o) {
        for (var p in m)
            if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
                __createBinding(o, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    ;
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n])
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: n === "return" } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k in mod)
                if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                    __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, privateMap) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to get private field on non-instance");
        }
        return privateMap.get(receiver);
    }
    function __classPrivateFieldSet(receiver, privateMap, value) {
        if (!privateMap.has(receiver)) {
            throw new TypeError("attempted to set private field on non-instance");
        }
        privateMap.set(receiver, value);
        return value;
    }

    /**
     * The sitemap configuration options.
     */
    var SitemapRoute = /** @class */ (function () {
        function SitemapRoute() {
        }
        return SitemapRoute;
    }());
    /**
     * The sitemap configuration options.
     */
    var SitemapConfig = /** @class */ (function () {
        function SitemapConfig() {
        }
        return SitemapConfig;
    }());
    /**
     * The default configuration
     */
    var defaultSitemapConfig = {
        urlPrefix: 'http://localhost',
        sitemapFilename: 'sitemap.xml',
        merge: false,
        changeFreq: 'monthly',
        priority: '0.5',
        suppressLog: false,
        trailingSlash: false
    };

    var fs = require('fs');
    var path = require('path');
    var builder = require('xmlbuilder');
    var pathToRegexp = require('path-to-regexp');
    var xmlParser = require('fast-xml-parser');
    var today = new Date();
    var mergePaths = function (base, path) {
        if (base.endsWith('/') && path.startsWith('/')) {
            return "" + base + path.substr(1);
        }
        if (!base.endsWith('/') && !path.startsWith('/')) {
            return base + "/" + path;
        }
        return "" + base + path;
    };
    var ɵ0 = mergePaths;
    var priorityForLocation = function (loc, config) {
        if (typeof config.priority === 'string' || config.priority instanceof String) {
            return config.priority;
        }
        else if (Array.isArray(config.priority)) {
            var segments = loc.split('/');
            return config.priority[segments.length - 1];
        }
        else {
            return '0.5';
        }
    };
    var ɵ1 = priorityForLocation;
    var pluralizer = function (num, singular, plural) {
        return num === 1 ? singular : plural;
    };
    var ɵ2 = pluralizer;
    var configForRoute = function (config, route) {
        if (config.routes) {
            // tslint:disable-next-line: forin
            for (var routePath in config.routes) {
                var routeConfig = config.routes[routePath];
                if (route.route.match(routeConfig.regexp)) {
                    return {
                        route: route.route,
                        urlPrefix: routeConfig.urlPrefix || config.urlPrefix,
                        trailingSlash: routeConfig.trailingSlash || config.trailingSlash,
                        sitemapFilename: routeConfig.sitemapFilename || config.sitemapFilename,
                        merge: routeConfig.merge || config.merge,
                        changeFreq: routeConfig.changeFreq || config.changeFreq,
                        priority: routeConfig.priority || config.priority
                    };
                }
            }
        }
        return {
            route: route.route,
            urlPrefix: config.urlPrefix,
            trailingSlash: config.trailingSlash,
            sitemapFilename: config.sitemapFilename,
            merge: config.merge,
            changeFreq: config.changeFreq,
            priority: config.priority
        };
    };
    var ɵ3 = configForRoute;
    var getSitemapFile = function (filename) {
        return path.join(scully.scullyConfig.outDir, filename);
    };
    var ɵ4 = getSitemapFile;
    var loadMap = function (filename) {
        var e_1, _a;
        var file = getSitemapFile(filename);
        if (fs.existsSync(file)) {
            var xmlString = fs.readFileSync(file, { encoding: 'utf8', flag: 'r' });
            var xml = parseXml(xmlString);
            // build url object
            var map = {};
            try {
                for (var _b = __values(xml.urlset.url), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var mappedUrl = _c.value;
                    map[mappedUrl.loc] = mappedUrl;
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
            return map;
        }
        else {
            return null;
        }
    };
    var ɵ5 = loadMap;
    var saveMap = function (map, filename) {
        var e_2, _a;
        var file = getSitemapFile(filename);
        var rootElement = builder.create('urlset').att('xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9');
        try {
            for (var _b = __values(Object.values(map)), _c = _b.next(); !_c.done; _c = _b.next()) {
                var route = _c.value;
                var urlElement = rootElement.ele('url');
                urlElement.ele('loc', route.loc);
                urlElement.ele('changefreq', route.changefreq);
                urlElement.ele('lastmod', route.lastmod);
                urlElement.ele('priority', route.priority);
            }
        }
        catch (e_2_1) { e_2 = { error: e_2_1 }; }
        finally {
            try {
                if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
            }
            finally { if (e_2) throw e_2.error; }
        }
        var xml = rootElement.end({ pretty: true });
        fs.writeFileSync(file, xml);
        return rootElement;
    };
    var ɵ6 = saveMap;
    var parseXml = function (xmlString) {
        return xmlParser.parse(xmlString);
    };
    var ɵ7 = parseXml;
    var getMapForRoute = function (maps, routeConfig) {
        var map = maps[routeConfig.sitemapFilename];
        if (!map && routeConfig.merge) {
            map = loadMap(routeConfig.sitemapFilename);
        }
        if (!map) {
            map = {};
        }
        maps[routeConfig.sitemapFilename] = map;
        return map;
    };
    var ɵ8 = getMapForRoute;
    var sitemapPlugin = function (routes) { return __awaiter(void 0, void 0, void 0, function () {
        var config, log, maps, filename, rootElement, routeCount;
        return __generator(this, function (_a) {
            config = Object.assign({}, defaultSitemapConfig, scully.getPluginConfig(SitemapPlugin));
            log = function (message) {
                var optionalParams = [];
                for (var _i = 1; _i < arguments.length; _i++) {
                    optionalParams[_i - 1] = arguments[_i];
                }
                if (!config.suppressLog) {
                    console.log.apply(console, __spread([message], optionalParams));
                }
            };
            log("Started @gammastream/scully-plugin-sitemap");
            log("Generating sitemaps for " + routes.length + " " + pluralizer(routes.length, 'route', 'routes') + ".");
            // parse route configurations
            if (config.routes) {
                Object.keys(config.routes).forEach(function (key) {
                    config.routes[key].regexp = pathToRegexp(key);
                });
            }
            maps = {};
            routes.forEach(function (route) {
                if (config.ignoredRoutes && config.ignoredRoutes.includes(route.route)) {
                    return;
                }
                var routeConfig = configForRoute(config, route);
                var map = getMapForRoute(maps, routeConfig);
                var loc = mergePaths(routeConfig.urlPrefix, route.route);
                if (routeConfig.trailingSlash && !loc.endsWith('/')) {
                    loc = loc + '/';
                }
                map[loc] = {
                    loc: loc,
                    changefreq: routeConfig.changeFreq,
                    lastmod: today.toISOString(),
                    priority: priorityForLocation(route.route, routeConfig)
                };
            });
            // tslint:disable-next-line: forin
            for (filename in maps) {
                rootElement = saveMap(maps[filename], filename);
                routeCount = rootElement.children.length;
                log("Wrote " + routeCount + " " + pluralizer(routeCount, 'route', 'routes') + " to " + filename);
            }
            log("Finished @gammastream/scully-plugin-sitemap");
            return [2 /*return*/];
        });
    }); };
    var SitemapPlugin = 'sitemap';
    var validator = function (conf) { return __awaiter(void 0, void 0, void 0, function () { return __generator(this, function (_a) {
        return [2 /*return*/, []];
    }); }); };
    var ɵ9 = validator;
    scully.registerPlugin('routeDiscoveryDone', SitemapPlugin, sitemapPlugin, validator);
    var getSitemapPlugin = function () { return SitemapPlugin; };

    /*
     * Public API Surface of scully-plugin-sitemap
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.SitemapConfig = SitemapConfig;
    exports.SitemapRoute = SitemapRoute;
    exports.getSitemapPlugin = getSitemapPlugin;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
//# sourceMappingURL=gammastream-scully-plugin-sitemap.umd.js.map
