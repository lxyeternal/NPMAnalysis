import { __awaiter } from 'tslib';
import { scullyConfig, getPluginConfig, registerPlugin } from '@scullyio/scully';

/**
 * The sitemap configuration options.
 */
class SitemapRoute {
}
/**
 * The sitemap configuration options.
 */
class SitemapConfig {
}
/**
 * The default configuration
 */
const defaultSitemapConfig = {
    urlPrefix: 'http://localhost',
    sitemapFilename: 'sitemap.xml',
    merge: false,
    changeFreq: 'monthly',
    priority: '0.5',
    suppressLog: false,
    trailingSlash: false
};

const fs = require('fs');
const path = require('path');
const builder = require('xmlbuilder');
const pathToRegexp = require('path-to-regexp');
const xmlParser = require('fast-xml-parser');
const today = new Date();
const mergePaths = (base, path) => {
    if (base.endsWith('/') && path.startsWith('/')) {
        return `${base}${path.substr(1)}`;
    }
    if (!base.endsWith('/') && !path.startsWith('/')) {
        return `${base}/${path}`;
    }
    return `${base}${path}`;
};
const ɵ0 = mergePaths;
const priorityForLocation = (loc, config) => {
    if (typeof config.priority === 'string' || config.priority instanceof String) {
        return config.priority;
    }
    else if (Array.isArray(config.priority)) {
        const segments = loc.split('/');
        return config.priority[segments.length - 1];
    }
    else {
        return '0.5';
    }
};
const ɵ1 = priorityForLocation;
const pluralizer = (num, singular, plural) => {
    return num === 1 ? singular : plural;
};
const ɵ2 = pluralizer;
const configForRoute = (config, route) => {
    if (config.routes) {
        // tslint:disable-next-line: forin
        for (const routePath in config.routes) {
            const routeConfig = config.routes[routePath];
            if (route.route.match(routeConfig.regexp)) {
                return {
                    route: route.route,
                    urlPrefix: routeConfig.urlPrefix || config.urlPrefix,
                    trailingSlash: routeConfig.trailingSlash || config.trailingSlash,
                    sitemapFilename: routeConfig.sitemapFilename || config.sitemapFilename,
                    merge: routeConfig.merge || config.merge,
                    changeFreq: routeConfig.changeFreq || config.changeFreq,
                    priority: routeConfig.priority || config.priority
                };
            }
        }
    }
    return {
        route: route.route,
        urlPrefix: config.urlPrefix,
        trailingSlash: config.trailingSlash,
        sitemapFilename: config.sitemapFilename,
        merge: config.merge,
        changeFreq: config.changeFreq,
        priority: config.priority
    };
};
const ɵ3 = configForRoute;
const getSitemapFile = (filename) => {
    return path.join(scullyConfig.outDir, filename);
};
const ɵ4 = getSitemapFile;
const loadMap = (filename) => {
    const file = getSitemapFile(filename);
    if (fs.existsSync(file)) {
        const xmlString = fs.readFileSync(file, { encoding: 'utf8', flag: 'r' });
        const xml = parseXml(xmlString);
        // build url object
        const map = {};
        for (const mappedUrl of xml.urlset.url) {
            map[mappedUrl.loc] = mappedUrl;
        }
        return map;
    }
    else {
        return null;
    }
};
const ɵ5 = loadMap;
const saveMap = (map, filename) => {
    const file = getSitemapFile(filename);
    const rootElement = builder.create('urlset').att('xmlns', 'http://www.sitemaps.org/schemas/sitemap/0.9');
    for (const route of Object.values(map)) {
        const urlElement = rootElement.ele('url');
        urlElement.ele('loc', route.loc);
        urlElement.ele('changefreq', route.changefreq);
        urlElement.ele('lastmod', route.lastmod);
        urlElement.ele('priority', route.priority);
    }
    const xml = rootElement.end({ pretty: true });
    fs.writeFileSync(file, xml);
    return rootElement;
};
const ɵ6 = saveMap;
const parseXml = (xmlString) => {
    return xmlParser.parse(xmlString);
};
const ɵ7 = parseXml;
const getMapForRoute = (maps, routeConfig) => {
    let map = maps[routeConfig.sitemapFilename];
    if (!map && routeConfig.merge) {
        map = loadMap(routeConfig.sitemapFilename);
    }
    if (!map) {
        map = {};
    }
    maps[routeConfig.sitemapFilename] = map;
    return map;
};
const ɵ8 = getMapForRoute;
const sitemapPlugin = (routes) => __awaiter(void 0, void 0, void 0, function* () {
    const config = Object.assign({}, defaultSitemapConfig, getPluginConfig(SitemapPlugin));
    const log = (message, ...optionalParams) => {
        if (!config.suppressLog) {
            console.log(message, ...optionalParams);
        }
    };
    log(`Started @gammastream/scully-plugin-sitemap`);
    log(`Generating sitemaps for ${routes.length} ${pluralizer(routes.length, 'route', 'routes')}.`);
    // parse route configurations
    if (config.routes) {
        Object.keys(config.routes).forEach(key => {
            config.routes[key].regexp = pathToRegexp(key);
        });
    }
    const maps = {};
    routes.forEach((route) => {
        if (config.ignoredRoutes && config.ignoredRoutes.includes(route.route)) {
            return;
        }
        const routeConfig = configForRoute(config, route);
        const map = getMapForRoute(maps, routeConfig);
        let loc = mergePaths(routeConfig.urlPrefix, route.route);
        if (routeConfig.trailingSlash && !loc.endsWith('/')) {
            loc = loc + '/';
        }
        map[loc] = {
            loc,
            changefreq: routeConfig.changeFreq,
            lastmod: today.toISOString(),
            priority: priorityForLocation(route.route, routeConfig)
        };
    });
    // tslint:disable-next-line: forin
    for (const filename in maps) {
        const rootElement = saveMap(maps[filename], filename);
        const routeCount = rootElement.children.length;
        log(`Wrote ${routeCount} ${pluralizer(routeCount, 'route', 'routes')} to ${filename}`);
    }
    log(`Finished @gammastream/scully-plugin-sitemap`);
});
const SitemapPlugin = 'sitemap';
const validator = (conf) => __awaiter(void 0, void 0, void 0, function* () { return []; });
const ɵ9 = validator;
registerPlugin('routeDiscoveryDone', SitemapPlugin, sitemapPlugin, validator);
const getSitemapPlugin = () => SitemapPlugin;

/*
 * Public API Surface of scully-plugin-sitemap
 */

/**
 * Generated bundle index. Do not edit.
 */

export { SitemapConfig, SitemapRoute, getSitemapPlugin };
//# sourceMappingURL=gammastream-scully-plugin-sitemap.js.map
