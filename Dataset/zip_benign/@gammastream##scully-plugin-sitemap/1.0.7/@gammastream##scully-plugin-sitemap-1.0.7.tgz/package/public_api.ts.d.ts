export { getSitemapPlugin } from './lib/index';
export { SitemapConfig, SitemapRoute } from './lib/sitemap-config';
