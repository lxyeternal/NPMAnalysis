import { HandledRoute } from '@scullyio/scully';
export declare const sitemapPlugin: (routes: HandledRoute[]) => Promise<void>;
export declare const getSitemapPlugin: () => string;
