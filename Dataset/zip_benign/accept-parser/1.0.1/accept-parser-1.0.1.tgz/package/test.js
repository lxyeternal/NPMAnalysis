var ap = require('./accept-parser');
var http = require('http');
var util = require('util');

var server = http.createServer(function (req, res){

	res.write('============ ACCEPT ============\n\n');
	res.write(req.headers['accept'] + '\n\n');
	res.write(util.inspect(ap.parse(req.headers['accept'])));
	res.write('\n\n\n====== ACCEPT-LANGUAGE =======\n\n');
	res.write(req.headers['accept-language'] + '\n\n');
	res.write(util.inspect(ap.parse(req.headers['accept-language'])));
	res.write('\n\n\n====== ACCEPT-ENCODING =======\n\n');
	res.write(req.headers['accept-encoding'] + '\n\n');
	res.write(util.inspect(ap.parse(req.headers['accept-encoding'])));

	res.end();
}).listen(1337);

console.log('To access http://127.0.0.1:1337/ testing...');

