exports.parse = function parser(accept){
	accept = accept || '';
	var map = [];

	accept.split(',').forEach(function (item){
		var tmp = item.split(';q=');
		var o = {item:item,q:1000};

		if(tmp.length == 2){
			o.item = tmp[0];
			o.q = parseInt(tmp[1] * 1000);
		}

		map.push(o);
	});
	sort(map);
	return map;

}

function sort(map){
	map.sort(function (v1, v2){
		return v1.q < v2.q ? 1 : -1;
	});
}

