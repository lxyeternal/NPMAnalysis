```
var ap = require('accept-parser');
```

## ACCEPT
```
ap.parse('text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8');
/*
[
	{ item: 'text/html', q: 1000 },
	{ item: 'application/xhtml+xml', q: 1000 },
	{ item: 'application/xml', q: 900 },
	{ item: '*/*', q: 800 }
]
*/
```

## ACCEPT-LANGUAGE
```
ap.parse('zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3')
/*
[
	{ item: 'zh-CN', q: 1000 },
	{ item: 'zh', q: 800 },
	{ item: 'en-US', q: 500 },
	{ item: 'en', q: 300 }
]
 */
```

##  ACCEPT-ENCODING
```
ap.parse('gzip, deflate')
/*
[
	{ item: 'gzip', q: 1000 },
	{ item: ' deflate', q: 1000 }
]
*/
```