export { initMap } from './InitMap';
