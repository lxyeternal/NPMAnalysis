import LavaLampBubbles from "../lava-lamp.js";

onload = () => {
    new LavaLampBubbles("canvas", 0.5, "#CA3E8C", "#840470").start();
};