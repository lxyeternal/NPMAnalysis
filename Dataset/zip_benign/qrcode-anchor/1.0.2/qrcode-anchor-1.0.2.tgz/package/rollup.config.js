import typescript from 'rollup-plugin-typescript2';
import resolve from '@rollup/plugin-node-resolve';
import commonjs from '@rollup/plugin-commonjs';
import replace from '@rollup/plugin-replace';

const isProduction = process.env.NODE_ENV === 'production';

export default {
  input: 'src/index.ts',
  output: [
    {
      file: 'dist/index.cjs.js', // CommonJS (Node.js)
      format: 'cjs',
      exports: 'named'
    },
    {
      file: 'dist/index.esm.js', // ES Module (modern bundlers, browsers)
      format: 'esm'
    },
    {
      file: 'dist/index.umd.js', // UMD (browser compatibility)
      format: 'umd',
      name: 'QRCodeAnchor', // Global variable name for browsers
      globals: {} // Add any global variables if needed
    }
  ],
  plugins: [
    resolve({
      browser: true, // Resolves browser-compatible modules
      preferBuiltins: true // Node.js built-ins
    }),
    commonjs(), // Converts CommonJS modules to ES6
    typescript(), // Compiles TypeScript
    replace({
      'process.env.NODE_ENV': JSON.stringify(isProduction ? 'production' : 'development'),
      preventAssignment: true
    })
  ],
  external: ['fs', 'path'], // Mark Node.js built-ins as external
};
