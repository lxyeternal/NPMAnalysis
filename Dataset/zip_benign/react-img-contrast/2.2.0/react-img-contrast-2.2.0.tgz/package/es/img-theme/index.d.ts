import { CreatePixelArrayParams, GetPaletteParams } from '../interface';
/**
 * 整理有效像素数组
 * @param param0
 * @returns
 */
export declare const createPixelArray: ({ imgData, pixelCount, quality }: CreatePixelArrayParams) => number[][];
/**
 * 获取图片主题色板
 * @param param0
 * @returns
 * Use the median cut algorithm provided by quantize.js to cluster similar colors.
 *
 * Function does not always return the requested amount of colors. It can be +/- 2
 *
 * quality is an optional argument. It needs to be an integer. 1 is the highest quality settings.
 * 10 is the default. There is a trade-off between quality and speed. The bigger the number, the
 * faster the palette generation but the greater the likelihood that colors will be missed.
 */
export declare const getPalette: ({ imgSrc, colorCount, quality }: GetPaletteParams) => Promise<any>;
/**
 * 获取图片主题色
 * @param param0
 * @returns
 */
export declare const getColor: ({ imgSrc, quality }: Omit<GetPaletteParams, 'colorCount'>) => Promise<any>;
