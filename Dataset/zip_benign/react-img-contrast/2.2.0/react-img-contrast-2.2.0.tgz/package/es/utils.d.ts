import { GetImgDataParams, GetImgDataRes } from './interface';
/**
 * 创建一个Img标签
 * @param url 图片地址
 * @returns
 */
export declare const createImage: (url: string) => Promise<HTMLImageElement>;
/**
 * 获取图片信息（像素数组、尺寸）
 * @param params
 * @returns
 */
export declare const getImgData: (params: GetImgDataParams) => Promise<GetImgDataRes>;
/**
 * 16进制颜色转rgb色值
 * @param hexColor
 * @returns
 */
export declare const hexToRgb: (hexColor: string) => number[];
/**
 * rgb转16进制颜色
 * @param rgbColor
 * @returns
 */
export declare const rgbToHex: (rgbColor: number[]) => string;
