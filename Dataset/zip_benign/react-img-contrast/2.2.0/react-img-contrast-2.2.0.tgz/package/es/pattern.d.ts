export declare const hexReg: RegExp;
