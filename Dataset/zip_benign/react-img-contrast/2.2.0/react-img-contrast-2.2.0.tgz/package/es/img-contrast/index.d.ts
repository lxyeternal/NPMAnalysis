import { GetImgDataParams, GetImgDataRes } from '../interface';
/**
 * 生成rgb色值对应的YIQ值，并返回文字颜色
 * @param r
 * @param g
 * @param b
 * @returns 黑或白
 */
export declare const getContrastYIQ: (r: number, g: number, b: number) => "black" | "white";
/**
 * 获取图片平均色值
 * @param params
 * @returns
 */
export declare const getAverageColor: (params: GetImgDataRes) => number[];
/**
 * 根据图片平均色值获取文字最佳展示颜色
 * @param params
 * @returns
 */
export declare const getImgContrast: (params: GetImgDataParams) => Promise<'white' | 'black'>;
/**
 * 根据十六进制颜色获取文字最佳展示颜色
 * @param color
 * @returns
 */
export declare const getColorContrast: (color: string) => "black" | "white";
