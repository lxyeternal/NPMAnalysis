export * from './src/xg-short-video'
export * from './src/xg-video'

