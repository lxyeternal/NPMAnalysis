import { decode } from './decode';

export function getUri(token, host, params = {}) {
  try {
    token = JSON.parse(decode(token));
  } catch (e) {
    throw new Error(`base64 decode error: ${e.message}`);
  }
  // if(token.Version === 'v1') {
  let _data = [];
  for (let k in params) {
    _data.push(`${k}=${params[k]}`);
  }
  let url = `${/^http/.test(host) ? host : '//' + host}?${
    token.GetPlayInfoToken
  }&ssl=true`;
  if (_data.length > 0) {
    url += `&${_data.join('&')}`;
  }

  return url;
}
