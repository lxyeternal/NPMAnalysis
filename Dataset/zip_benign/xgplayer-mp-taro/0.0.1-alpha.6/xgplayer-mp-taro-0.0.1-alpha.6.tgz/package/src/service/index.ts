import { request as TaroRequest } from '@tarojs/taro'
import { getUri } from './uri/uri'

export async function ServiceRequest(token: string, host: string, params?: { [prop: string]: any }) {
  if (token && host) {
    let url

    try {
      url = getUri(token, host, params)
    } catch (e) {
      return Promise.reject(e.message)
    }

    if (/^\/\//.test(url)) {
      url = 'https:' + url
    }

    const { data, statusCode } = await TaroRequest({
      dataType: 'json',
      method: 'GET',
      url
    })

    if (statusCode === 200 || statusCode === 206) {
      if (data) {
        if (typeof data === 'string') {
          return JSON.parse(data)['Result']
        } else if (typeof data === 'object') {
          return data.Result
        } else {
          return data
        }
      } else {
        return Promise.reject("vid, host and token can't be empty")
      }
    } else {
      return Promise.reject(`statusCode: ${statusCode}`)
    }
  } else {
    return Promise.reject("vid, host and token can't be empty")
  }
}
