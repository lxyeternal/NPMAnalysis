import { VideoProps } from '@tarojs/components/types/Video'

export interface XgVideoProps extends Omit<VideoProps, 'src'> {
  /**
   * 要播放视频的资源地址
   * @supported weapp, h5, swan, alipay, tt, rn
   */
  src?: string

  /**
   * 是否显示平台原生播放控件（播放/暂停按钮、播放进度、时间）
   * @default false
   */
  nativeControls?: boolean

  /**
   * 1. playDomain签发参考 https://www.volcengine.com/docs/4/65644
   * 2. 当 src 属性指定时，playDomain会被忽略
   * @default null
   */
  playDomain?: string

  /**
   * 1. playAuthToken签发参考 https://www.volcengine.com/docs/4/65644
   * 2. 当 src 属性指定时，playAuthToken会被忽略
   * @default null
   */
  playAuthToken?: string

  /**
   * @default null
   */
  description?: string

  /**
   * 播放器UI展示模式
   */
  mode?: 'small' /* 小视频 */ | 'short' /* 短视频 */

  /**
   * 播放器倍速列表
   */
  playbackRateList?: number[]

  /**
   * 播放器清晰度默认值
   */
  definition?: IDefinition['quality']

  /**
   * 播放器清晰度列表
   */
  definitionList?: IDefinition[]
}

export interface IDefinition {
  url: string
  quality: number
  text:
    | string
    | {
        [propName: string]: any
      }
  iconText?:
    | string
    | {
        [propName: string]: any
      }
}
