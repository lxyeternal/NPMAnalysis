import { Block, Video } from '@tarojs/components'
import { VideoProps } from '@tarojs/components/types/Video'
import { createVideoContext, Events, VideoContext as TaroVideoContext } from '@tarojs/taro'
import { generateUppercaseUid, XgInternalEvents } from 'xgplayer-mp-taro-core'
import { Loading, MiddleButton, Progress, UnderOverlay } from 'xgplayer-mp-taro-ui'
import { useEffect, useMemo, useState } from 'react'
import { ControlOverlay } from './components/shortControlOverlay'
import { VideoDescription } from './components/smallVideoDescription'
import { ServiceRequest } from './service'
import { IDefinition, XgVideoProps } from './types/xg-video'
import { defaultVideoContext, VideoContext, XGVideoContext } from './xg-video-context'
import './xg-video.scss'

export function XgVideo(props: XgVideoProps) {
  const {
    id,
    src,
    style,
    mode,
    poster,
    controls,
    nativeControls,
    description,
    definition = -1,
    definitionList,
    playDomain,
    playAuthToken,
    ...videoProps
  } = props
  const uniqueId = id || generateUppercaseUid()
  const eventCenter = useMemo(() => new Events(), [])
  const [videoId] = useState(uniqueId)
  const [paused, setPaused] = useState(true)
  const [seeking, setSeeking] = useState(false)
  const [loadedMeta, setLoadedMeta] = useState(false)
  const [ended, setEnded] = useState(false)
  const [toggleCtrlOverLayer, setToggleCtrlOverLayer] = useState(true)
  const [buffer, setBuffer] = useState(0)
  const [playbackPercent, setPlaybackPercent] = useState(0)
  const [playbackDuration, setPlaybackDuration] = useState(0)
  const [playbackRate, setPlaybackRate] = useState(1)
  const [playbackCurrentTime, setPlaybackCurrentTime] = useState(0)
  const [playbackCtx, setPlaybackCtx] = useState<TaroVideoContext>()
  const [isFullScreen, setIsFullScreen] = useState(false)
  const [videoSourceUrl, setVideoSourceUrl] = useState<string>()
  const [definitionChangePoint, setDefinitionChangePoint] = useState<number>()
  const [playbackDefinition, setPlaybackDefinition] = useState(definition)
  const [playbackDefinitionList, setPlaybackDefinitionList] = useState<Array<IDefinition>>()
  const showLoading = !loadedMeta || (seeking && !paused)

  const localContext: VideoContext = {
    ...defaultVideoContext,
    ctx: playbackCtx,
    eventCenter,
    showLoading,
    buffer,
    loadedMeta,
    isFullScreen,
    playbackRate,
    seeking,
    paused,
    definition: playbackDefinition,
    definitionList: playbackDefinitionList,
    percent: playbackPercent,
    duration: playbackDuration,
    currentTime: playbackCurrentTime
  }

  // Create VideoContext
  useEffect(() => {
    const ctx = createVideoContext(videoId)
    const proxyCTX = new Proxy(ctx, {
      get(target, prop, receiver) {
        if (prop === 'seek') {
          // 利用proxy劫持seek方法，设置seeking状态变化
          setSeeking(true)
        }
        return Reflect.get(target, prop, receiver)
      }
    })

    setPlaybackCtx(proxyCTX)

    // setTimeout(() => {
    //   setIsFullScreen(true)
    // }, 1000)
  }, [videoId])

  // EventCenter subscription
  useEffect(() => {
    function onPlaybackRateChanged(val: number) {
      setPlaybackRate(val)
    }
    function onPlaybackQualityChange(to: IDefinition, from: IDefinition, context: VideoContext) {
      setLoadedMeta(false)
      setPlaybackDefinition(to.quality)
      setVideoSourceUrl(to.url)
      setDefinitionChangePoint(context.currentTime)
    }
    const evMap = [
      [XgInternalEvents.PlaybackRateChanged, onPlaybackRateChanged],
      [XgInternalEvents.PlaybackQualityChange, onPlaybackQualityChange]
    ]
    evMap.forEach(([ev, cb]: [XgInternalEvents, () => void]) => {
      eventCenter.on(ev, cb)
    })

    return () => {
      evMap.forEach(([ev, cb]: [XgInternalEvents, () => void]) => {
        eventCenter.off(ev, cb)
      })
    }
  }, [eventCenter])

  // playAuthToken
  useEffect(() => {
    if (src) {
      if (Array.isArray(definitionList) && definitionList.length > 0) {
        setPlaybackDefinitionList(definitionList)
      }
    } else if (playAuthToken && playDomain) {
      ServiceRequest(playAuthToken, playDomain).then((res) => {
        const defaultDef = res.Data.PlayInfoList[0]
        const qualityList = res.Data.PlayInfoList.sort((a, b) => b.Bitrate - a.Bitrate).map((item) => {
          const def: IDefinition = {
            text: item.Definition,
            url: item.MainPlayUrl,
            quality: item.Bitrate
          }
          return def
        })

        setVideoSourceUrl(defaultDef.MainPlayUrl)

        if (qualityList.length > 0) {
          setPlaybackDefinition(defaultDef.Bitrate)
          setPlaybackDefinitionList(qualityList)
        }
      })
    }
  }, [src, definitionList, playAuthToken, playDomain])

  function onPlay() {
    setPaused(false)
    setEnded(false)
  }
  function onPause() {
    setPaused(true)
  }
  function onTimeupdate(e) {
    const { currentTime, duration } = e.detail as VideoProps.onTimeUpdateEventDetail

    if (seeking) {
      /* 开发工具中不会触发onSeekComplete */
      setSeeking(false)
    }
    setPlaybackCurrentTime(currentTime)
    setPlaybackPercent(Math.floor((currentTime / duration) * 100))
    setPlaybackDuration(duration)
  }
  function onLoadedMetadata(e) {
    const { duration, height, width } = e.detail

    setLoadedMeta(true)
    setPlaybackDuration(duration)

    if (definitionChangePoint) {
      setDefinitionChangePoint(undefined)
      playbackCtx?.seek(definitionChangePoint)
    }
  }
  function onSeeked() {
    setSeeking(false)
  }
  function onEnded() {
    if (seeking) {
      setSeeking(false)
    }
    setEnded(true)
  }
  function onProgress(e) {
    const { buffered } = e.detail as VideoProps.onProgressEventDetail

    setBuffer(buffered)
  }
  function onFullscreenChange(e) {
    const { fullScreen, direction } = e.detail as VideoProps.onFullscreenChangeEventDetail

    setIsFullScreen(fullScreen as boolean)
  }
  function onClick() {
    if (mode === 'small') {
      const ctx = createVideoContext(videoId)

      if (loadedMeta) {
        if (paused) {
          ctx.play()
        } else {
          ctx.pause()
        }
      }
    }
  }

  function onUnderOverlayClick() {
    setToggleCtrlOverLayer(!toggleCtrlOverLayer)
  }
  function onProgressSeeked(percent) {
    const target = playbackDuration * percent
    playbackCtx?.seek(target)
  }

  const propsClassNames = videoProps.className?.split(' ') || []
  const classNames = [
    // use Set to filter duplicate string item in Array
    ...new Set(['xg-video', isFullScreen ? ' xg-video-fullscreen' : '', ...propsClassNames])
  ].filter((item) => !!item)
  const showCtrlOverlay = (loadedMeta && toggleCtrlOverLayer) || ended

  return (
    <Video
      id={videoId}
      src={videoSourceUrl || src || ''}
      controls={!!nativeControls}
      showCenterPlayBtn={!!nativeControls}
      onTimeUpdate={onTimeupdate}
      onPause={onPause}
      onPlay={onPlay}
      onLoadedMetaData={onLoadedMetadata}
      onSeekComplete={onSeeked}
      onEnded={onEnded}
      onProgress={onProgress}
      onFullscreenChange={onFullscreenChange}
      onClick={onClick}
      {...videoProps}
      className={classNames.join(' ')}
    >
      <XGVideoContext.Provider value={localContext}>
        {mode === 'small' ? (
          <Block>
            <Loading status={showLoading ? 'show' : 'hide'}></Loading>
            <MiddleButton size='big' status={loadedMeta && paused ? 'show' : 'hide'}></MiddleButton>
            <Progress
              className='progress-bar'
              value={playbackPercent}
              buffer={buffer}
              ctx={localContext.ctx}
              size={4}
              onSeeked={onProgressSeeked}
            ></Progress>
            <VideoDescription>{description}</VideoDescription>
          </Block>
        ) : mode === 'short' ? (
          <Block>
            <UnderOverlay onClick={onUnderOverlayClick}></UnderOverlay>
            <Loading status={showLoading ? 'show' : 'hide'}></Loading>

            {loadedMeta ? (
              showCtrlOverlay ? (
                <ControlOverlay {...props}></ControlOverlay>
              ) : (
                <Progress
                  className='progress-bar progress-bar-mini'
                  value={playbackPercent}
                  buffer={buffer}
                  onSeeked={onProgressSeeked}
                  draggable={false}
                ></Progress>
              )
            ) : (
              <Block></Block>
            )}
          </Block>
        ) : (
          <Block></Block>
        )}
      </XGVideoContext.Provider>
    </Video>
  )
}
