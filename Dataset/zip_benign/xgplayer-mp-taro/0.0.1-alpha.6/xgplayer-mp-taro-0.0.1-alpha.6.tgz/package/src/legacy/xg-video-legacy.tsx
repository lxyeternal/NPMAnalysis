// import withWeapp from '@tarojs/with-weapp'

// @withWeapp({
//   properties: {
//     src: {
//       type: String,
//       value: '',
//       observer(newVal, oldVal, changedPath) {
//         console.log('src:', newVal, oldVal)
//         this.setData({ src: newVal })
//       }
//     },
//     defnitionUrls: {
//       type: Array,
//       value: [],
//       observer(newVal, oldVal, changedPath) {
//         console.log('defnitionUrls:', newVal, oldVal)
//         this.setData({ defnitionUrls: newVal })
//       }
//     },
//     autoplay: {
//       type: Boolean,
//       value: false
//     },
//     controls: {
//       type: Boolean,
//       value: false
//     }
//   },

//   data: {
//     id: `xgVideo${new Date()}`,
//     playbackrates: [0.5, 0.8, 1.0, 1.25, 1.5, 2],
//     playbackRateIndex: 2,
//     playPercent: 0,
//     duration: 0,
//     currentTime: 0,
//     definitionChangeTime: null,
//   },

//   ready() {
//     this.videoContext = Taro.createVideoContext('xgVideo', this)
//     console.log('ready:', this.videoContext)
//   },

//   methods: {
//     play() {
//       console.log('invokePlay', this.videoContext)
//       this.videoContext.play()
//       // .then(() => {
//       //   console.log('play success')
//       // }, (e) => {
//       //   console.error('play error', e)
//       // })
//     },
//     pause() {
//       console.log('invokePause', this.videoContext)
//       this.videoContext.pause()
//     },
//     enterFullscreen() {
//       console.log('requestFullScreen', this.videoContext)
//       this.videoContext.requestFullScreen()
//     },
//     exitFullscreen() {
//       console.log('requestFullScreen', this.videoContext)
//       this.videoContext.exitFullScreen()
//     },
//     invokeStatusBar(dom) {
//       let action = dom.target.dataset.action

//       switch (action) {
//         case 'show':
//           this.videoContext.showStatusBar()
//           break
//         case 'hide':
//           this.videoContext.hideStatusBar()
//           break
//       }
//       console.log('invokeStatusBar', action, this.videoContext)
//     },
//     bindDefinitionChange(e) {
//       console.log(e.detail)
//       let index = e.detail.value
//       let url = this.data.defnitionUrls[index].url
//       this.setData({
//         src: url,
//         definitionChangeTime: this.data.currentTime
//       })

//       // this.src = url;
//     },

//     bindPlaybackRatePickerChange(e) {
//       let index = e.detail.value
//       console.log('picker发送选择改变，携带值为', index)
//       this.setData({
//         playbackRateIndex: index
//       })

//       this.videoContext.playbackRate(this.data.playbackrates[index])
//     },
//     bindProgressbarSliderChange(event) {
//       const { value } = event.detail
//       const { duration } = this.data
//       const seekTime = (value / 100) * duration

//       console.log(`seek to: `, seekTime, value, duration)
//       this.videoContext.seek(seekTime)
//     },
//     bindTimeupdate(event) {
//       let { currentTime, duration } = event.detail
//       // console.log(currentTime / duration * 100, event.detail)

//       this.setData({
//         currentTime,
//         playPercent: (currentTime / duration) * 100
//       })
//     },
//     bindLoadedMetadata(event) {
//       const { definitionChangeTime } = this.data

//       if (!Number.isNaN(definitionChangeTime)) {
//         this.videoContext.seek(definitionChangeTime)
//       }
//       this.setData({
//         duration: event.detail.duration,
//         definitionChangeTime: null
//       })
//     }
//   }

//   //   behaviors: ["wx://component-export"],
//   //   export() {
//   //     let component = this;
//   //     return {
//   //       setDefitionUrls(urlArr) {
//   //         component.setData({
//   //           defnitionUrls: urlArr,
//   //         });
//   //       },
//   //     };
//   //   },
// })



// <View className='info-panel'>
//   <View>{src}</View>
//   <View>{'currentTime: ' + state.currentTime}</View>
//   <View>{'duration: ' + state.duration}</View>
// </View>
// <View className='xg-control'>
//   <View>
//     <Button
//       style='margin: 30rpx auto'
//       onClick={play}
//       className='page-body-button'
//       type='primary'
//       size='mini'
//       formType='submit'
//     >
//       播放
//     </Button>
//     <Button
//       style='margin: 30rpx auto'
//       onClick={pause}
//       className='page-body-button'
//       type='primary'
//       size='mini'
//       formType='submit'
//     >
//       暂停
//     </Button>
//     <Button
//       style='margin: 30rpx auto'
//       onClick={enterFullscreen}
//       className='page-body-button'
//       type='primary'
//       size='mini'
//       formType='submit'
//     >
//       进入全屏
//     </Button>
//     <Button
//       style='margin: 30rpx auto'
//       onClick={exitFullscreen}
//       className='page-body-button'
//       type='primary'
//       size='mini'
//       formType='submit'
//     >
//       退出全屏
//     </Button>
//     <Picker
//       className='picker-view'
//       onChange={onPlaybackRatePickerChange}
//       value={playbackRateIndex}
//       range={playbackRates}
//     >
//       <Button
//         style='margin: 30rpx auto'
//         className='page-body-button'
//         type='primary'
//         size='mini'
//         formType='submit'
//       >
//         {'倍速(' + playbackRates[playbackRateIndex] + ')'}
//       </Button>
//     </Picker>
//     {/*  <button style="margin: 30rpx auto" bindtap="invokeStatusBar" data-action="show" class="page-body-button" type="primary" size="mini" formType="submit">显示状态栏(仅IOS)</button>
//                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         <button style="margin: 30rpx auto" bindtap="invokeStatusBar" data-action="hide" class="page-body-button" type="primary" size="mini" formType="submit">隐藏状态栏(仅IOS)</button>  */}
//     <Picker className='picker-view' onChange={onDefinitionChange} rangeKey='quality' range={defnitionUrls}>
//       <Button
//         style='margin: 30rpx auto'
//         className='page-body-button'
//         type='primary'
//         size='mini'
//         formType='submit'
//       >
//         切清晰度
//       </Button>
//     </Picker>
//   </View>
//   <View className='progress-bar'>
//     {/* <Slider
//     onChange={onProgressbarSliderChange}
//     leftIcon="cancel"
//     rightIcon="success_no_circle"
//     activeColor="#e31106"
//     value={playPercent}
//   ></Slider> */}
//   </View>
// </View>
