import { View, ViewProps } from '@tarojs/components'
import { formatTime } from 'xgplayer-mp-taro-ui'
import './index.scss'

interface ThumbnailDurationProps extends ViewProps {
  value: number
}

export function ThumbnailDuration({ value }: ThumbnailDurationProps) {
  return <View className='thumbnail-duration'>{formatTime(value)}</View>
}
