import { View, ViewProps } from '@tarojs/components'
import { ReactNode } from 'react'
import './index.scss'

interface TopTitleProps extends ViewProps {
  children?: ReactNode
}

export function TopTitle({ children }: TopTitleProps) {
  return <View className='top-title'>{children}</View>
}
