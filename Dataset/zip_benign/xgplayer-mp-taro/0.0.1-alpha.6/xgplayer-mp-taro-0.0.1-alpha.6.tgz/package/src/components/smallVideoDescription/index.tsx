import { View, ViewProps } from '@tarojs/components'
import { ReactNode } from 'react'
import './index.scss'

interface VideoDescriptionProps extends ViewProps {
  children?: ReactNode
}

export function VideoDescription({ children }: VideoDescriptionProps) {
  return <View className='video-description'>{children}</View>
}
