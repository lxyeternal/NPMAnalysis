import { View } from '@tarojs/components'
import { DEBUG } from 'xgplayer-mp-taro-core'
import { MiddleButton, Thumbnail, Top } from 'xgplayer-mp-taro-ui'
import { CSSProperties, useState } from 'react'
import { TopTitle } from './components/shortTopTitle'
import { ThumbnailDuration } from './components/thumbnailDuration'
import { XgVideoProps } from './types/xg-video'
import './xg-short-video.scss'
import { XgVideo } from './xg-video'

export interface XgVideoShortProps extends XgVideoProps {
  duration?: number
}

export function XgShortVideo(props: XgVideoShortProps) {
  const { duration, src, playAuthToken, playDomain, ...videoProps } = props
  const [videoSourceData, setVideoSourceData] = useState<Pick<XgVideoProps, 'src' | 'playAuthToken' | 'playDomain'>>({})
  const [style, setStyle] = useState<CSSProperties>({})

  function onThumbnailClick() {
    if (src || (playAuthToken && playDomain)) {
      setStyle({
        display: 'none'
      })

      if (src) {
        setVideoSourceData({
          src
        })
      } else {
        setVideoSourceData({
          playAuthToken,
          playDomain
        })
      }
    } else {
      DEBUG.logWarn('player src is not specified!')
    }
  }

  return (
    <View className='xg-short-video-container'>
      <XgVideo {...videoSourceData} autoplay {...videoProps}></XgVideo>

      <Thumbnail poster={props.poster} onClick={onThumbnailClick} style={style}>
        <Top
          style={{
            zIndex: 1
          }}
        >
          <TopTitle>{videoProps.title}</TopTitle>
        </Top>
        <MiddleButton size='small' status='show'></MiddleButton>
        {duration && <ThumbnailDuration value={duration}></ThumbnailDuration>}
      </Thumbnail>
    </View>
  )
}
