import { Events } from '@tarojs/runtime'
import { VideoContext as TaroVideoContext, eventCenter } from '@tarojs/taro'
import React from 'react'
import { XgVideoProps } from './types/xg-video'

export interface VideoContext extends XgVideoProps {
  ctx?: TaroVideoContext
  eventCenter: Events
  buffer: number
  loadedMeta: boolean
  percent: number
  currentTime: number
  duration: number
  videoWidth: number
  videoHeight: number
  isFullScreen: boolean
  playbackRate: number
  paused: boolean
  seeking: boolean
  showLoading: boolean
}

export const defaultVideoContext: VideoContext = {
  ctx: undefined,
  eventCenter: eventCenter /* 先用全局站位 */,
  loadedMeta: false,
  paused: true,
  buffer: 0,
  percent: 0,
  currentTime: 0,
  duration: 0,
  videoHeight: 0,
  videoWidth: 0,
  isFullScreen: false,
  seeking: false,
  showLoading: false,
  playbackRate: 1,
  definitionList: []
}

export const XGVideoContext = React.createContext(defaultVideoContext)

XGVideoContext.displayName = 'XgVideoContext'
