import "../xg-video.scss"
