# AddDec()
The AddDec NPM package fixes the issue of `0.1 + 0.2` = `0.30000000000000004`.

## Example:
```
let addDec = require('adddecimal');

console.log(addDec(.1, .2)); // 0.3

console.log(addDec(0.1, 0.2)); // 0.3
```

thats literally it.