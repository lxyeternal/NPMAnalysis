# Установка с npm

Совмещение реалий с мануалом автора npm.

## 1. Создание .npmrc
Файл настроек npm. В `bin` добавится `npm`, в `.node_libraries` будут ставиться пакеты.

    cat >>~/.npmrc <<NPMRC
    root = ~/.node_libraries
    binroot = ~/bin
    manroot = ~/share/man
    NPMRC
## 2. PATH
Если `~/bin` не в `PATH`, добавить:

    echo 'export PATH=$HOME/bin:$PATH' >> ~/.bashrc

## 3. Поставить npm
Наиболее простой путь установки:

    curl http://npmjs.org/install.sh | sh

## 4. Поставить mjoe
Установка mjoe npm-пакетом:

    npm install mjoe

