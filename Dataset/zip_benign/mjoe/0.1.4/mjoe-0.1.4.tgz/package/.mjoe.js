// временная мера
var MJ_CREATE = 1,
    MJ_DELETE = 2,
    MJ_MODIFY = 4,
    MJ_STATS_CHANGED = 8;

exports.config = {
    exclude: [
        '*.svn'
    ],
    workers: [
            {
                matcher: function(event) { return true; },
                callbacks: echo
            }
        ]
};

function echo(e) {
    console.log(e);
};

