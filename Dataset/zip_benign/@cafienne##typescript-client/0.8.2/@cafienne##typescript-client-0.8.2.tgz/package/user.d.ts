import UserInformation from './tenant/userinformation';
export default class User {
    id: string;
    /**
     * A user without an id, i.e. id is an empty string.
     */
    static NONE: User;
    private token_property;
    /**
     * Information about the user as known within the case service
     * Is only available upon login of the user
     */
    userInformation?: UserInformation;
    /**
     *
     * @param id Id of the user, with which is must be registered within the case system
     */
    constructor(id: string);
    toString(): string;
    /**
     * Login the user in 2 steps:
     * - first fetch a token from the token service,
     * - then invoke tenant service to retrieve the user information.
     *
     * The second call fails if the user is not (yet) registered in the case system.
     */
    login(): Promise<this>;
    set token(newToken: string);
    /**
     * Current user token. Is available upon login of the user.
     */
    get token(): string;
    /**
     * Clear current token of user.
     */
    clearToken(): void;
    /**
     * Technical method to get/refresh a token for this user.
     */
    refreshToken(): Promise<string>;
    /**
     * Refresh the user information with latest from case engine.
     */
    refreshUserInformation(): Promise<UserInformation>;
}
