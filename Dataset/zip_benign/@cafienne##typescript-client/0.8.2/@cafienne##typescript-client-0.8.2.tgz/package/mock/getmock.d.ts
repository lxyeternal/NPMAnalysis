import MockURL from "./mockurl";
export default class GetMock extends MockURL {
    addRoute(): void;
}
