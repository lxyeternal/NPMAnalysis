"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MockInvocation = void 0;
const config_1 = __importDefault(require("../config"));
const logger_1 = __importDefault(require("../logger"));
class MockURL {
    constructor(mockServer, url, callback, timeout = 5000) {
        this.mockServer = mockServer;
        this.url = url;
        this.callback = callback;
        this.timeout = timeout;
        this.calls = new CallHistory();
        this.mockServer.mocks.push(this);
    }
    untilCallInvoked(millis = this.timeout) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.calls.awaitCall(this, millis);
        });
    }
    /**
     *
     * @param response
     */
    syncPromise(response) {
        // TODO: make sure that MockInvocation and Call are (somehow) merged...
        this.calls.syncPromise(this, response);
    }
    register() {
        if (config_1.default.MockService.registration) {
            logger_1.default.info(`Registering mock on ${this.method} ${this.url}`);
        }
        // const expressFunction = this.method.toLowerCase();
        this.addRoute();
    }
    get method() {
        return this.constructor.name.substring(0, this.constructor.name.length - 4).toUpperCase();
    }
    handleRoute(req, res, next) {
        if (config_1.default.MockService.log) {
            logger_1.default.info(`Mock ${this.method} ${this.url}: handling call on url "${req.url}"`, true);
        }
        this.callback(new MockInvocation(req, res, next, this));
        logger_1.default.endGroup();
    }
    addRoute() {
        throw new Error('This method must be implemented in ' + this.constructor.name);
    }
}
exports.default = MockURL;
class MockInvocation {
    constructor(req, res, next, mock) {
        this.req = req;
        this.res = res;
        this.next = next;
        this.mock = mock;
        this.__syncMessage = undefined;
    }
    /**
     * Sets the sync message that will be returned for calls to untilCallInvoked on the Mock endpoint
     * @param msg
     */
    setSyncMessage(msg) {
        this.mock.syncPromise(msg);
    }
    writeHead(statusCode, headers) {
        this.res.writeHead(statusCode, headers);
    }
    onContent(callback) {
        let body = '';
        this.req.on('data', data => body += data);
        this.req.on('end', () => {
            callback(body);
        });
    }
    onJSONContent(callback) {
        this.onContent((body) => callback(JSON.parse(body)));
    }
    write(content) {
        this.res.write(content);
    }
    fail(statusCode, content) {
        this.res.status(statusCode).write(content);
        this.res.end();
    }
    json(content) {
        this.res.json(content);
        this.res.end();
    }
    end() {
        this.res.end();
    }
}
exports.MockInvocation = MockInvocation;
class CallHistory {
    constructor() {
        this.urlList = [];
    }
    awaitCall(mock, waitTime) {
        return __awaiter(this, void 0, void 0, function* () {
            return this.getCall(mock, 'waiterAvailable').awaitResponse(waitTime);
        });
    }
    getCall(mock, booleanField) {
        const existingCall = this.urlList.find(call => call.isPendingOn(booleanField));
        if (existingCall) {
            return existingCall;
        }
        else {
            const newCall = new Call(mock);
            this.urlList.push(newCall);
            return newCall;
        }
    }
    syncPromise(mock, response) {
        this.getCall(mock, 'responseAvailable').registerResponse(response);
    }
}
class Call {
    constructor(mock) {
        this.mock = mock;
        this.waiterAvailable = false;
        this.resolver = () => { console.log("I am not the right done function"); };
        this.response = undefined;
        this.responseAvailable = false;
        if (config_1.default.MockService.log) {
            logger_1.default.debug(`Creating Call Matcher on URL ${mock.url}`);
        }
    }
    isPendingOn(flag) {
        if (flag === 'waiterAvailable')
            return !this.waiterAvailable;
        if (flag === 'responseAvailable')
            return !this.responseAvailable;
        throw new Error(`Unknown flag ${flag}`);
    }
    awaitResponse(timeout) {
        if (config_1.default.MockService.log) {
            logger_1.default.debug(`${this.mock.url}: Awaiting response for ${timeout} milliseconds`);
        }
        const promise = new Promise((resolve, reject) => {
            this.resolver = resolve;
            if (this.responseAvailable)
                this.resolver(this.response);
            setTimeout(() => {
                // Only reject if the response has not yet arrived.
                if (!this.responseAvailable) {
                    if (config_1.default.MockService.log) {
                        logger_1.default.debug(`${this.mock.url}: Raising timeout after ${timeout} milliseconds`);
                    }
                    reject(new Error(`The url ${this.mock.url} was not invoked within ${timeout} milliseconds`));
                }
            }, timeout);
        });
        this.waiterAvailable = true;
        return promise;
    }
    registerResponse(response) {
        if (config_1.default.MockService.log) {
            if (config_1.default.MockService.response) {
                logger_1.default.debug(`${this.mock.url}: Received response: ` + JSON.stringify(response, undefined, 2));
            }
            else {
                logger_1.default.info(`${this.mock.url}: Received response`);
            }
        }
        this.response = response;
        this.responseAvailable = true;
        if (this.waiterAvailable)
            this.resolver(this.response);
    }
}
