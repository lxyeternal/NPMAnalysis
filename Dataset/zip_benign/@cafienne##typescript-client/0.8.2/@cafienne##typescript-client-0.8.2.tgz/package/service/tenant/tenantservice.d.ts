import User from '../../user';
import Tenant from '../../tenant/tenant';
import TenantUser from '../../tenant/tenantuser';
/**
 * Connection to the /tenant APIs of Cafienne
 */
export default class TenantService {
    /**
     * Return a list of the current owners of the tenant. Can only be invoked by users that are owner of the tenant.
     * @param user Must be a tenant owner
     * @param tenant
     * @param expectedStatusCode
     */
    static getTenantOwners(user: User, tenant: Tenant | string, expectedStatusCode?: number, msg?: string): Promise<any>;
    /**
     * Returns a list of the tenant users
     * @param user Must be a valid user in the tenant
     * @param tenant
     * @param expectedStatusCode
     */
    static getTenantUsers(user: User, tenant: Tenant | string, expectedStatusCode?: number, msg?: string): Promise<any>;
    /**
     * Returns a list of the tenant users
     * @param user Must be a valid user in the tenant
     * @param tenant
     * @param expectedStatusCode
     */
    static getDisabledUserAccounts(user: User, tenant: Tenant | string, expectedStatusCode?: number, msg?: string): Promise<any>;
    /**
     * Retrieve information about a specific tenant user
     * @param user Must be a tenant user
     * @param tenant
     * @param tenantUserId
     * @param expectedStatusCode
     */
    static getTenantUser(user: User, tenant: Tenant | string, tenantUserId: TenantUser | string, expectedStatusCode?: number, msg?: string): Promise<any>;
    /**
     * Adds or replaces the tenant user
     * @param user Must be a tenant owner
     * @param tenant
     * @param newTenantUser
     * @param expectedStatusCode
     */
    static setTenantUser(user: User, tenant: Tenant | string, newTenantUser: TenantUser, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Remove the user from the tenant
     * @param user Must be a tenant owner
     * @param tenant
     * @param newTenantUser
     * @param expectedStatusCode
     */
    static removeTenantUser(user: User, tenant: Tenant | string, tenantUser: TenantUser | string, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Replaces the tenant users (in one API call, bulk replace)
     * @param user
     * @param tenant
     * @param expectedStatusCode
     */
    static replaceTenant(user: User, tenant: Tenant, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
}
