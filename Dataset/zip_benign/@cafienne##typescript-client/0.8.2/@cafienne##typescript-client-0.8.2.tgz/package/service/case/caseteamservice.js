"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const caseteam_1 = __importDefault(require("../../cmmn/team/caseteam"));
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
class CaseTeamService {
    /**
     * Get the CaseTeam of the specified case instance
     * @param caseInstance
     * @param user
     * @returns CaseTeam
     */
    static getCaseTeam(user, caseId, expectedStatusCode = 200, msg = `GetCaseTeam is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get(`/cases/${caseId}/caseteam`, user);
            const caseTeam = yield response_1.checkJSONResponse(response, msg, expectedStatusCode, caseteam_1.default);
            return caseTeam;
        });
    }
    /**
     * Assign the specified team to the case
     * @param Case
     * @param user
     * @param team
     */
    static setCaseTeam(user, caseId, team, expectedStatusCode = 200, msg = `SetCaseTeam is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/caseteam`, user, team);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Add or update a case team member.
     * @param Case
     * @param user
     * @param caseTeamUser
     */
    static setUser(user, caseId, caseTeamUser, expectedStatusCode = 200, msg = `SetCaseTeamUser(${caseTeamUser}) is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/caseteam/users`, user, caseTeamUser);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Delete the specified member from the case team.
     * @param Case
     * @param user
     * @param member
     */
    static removeUser(user, caseId, userId, expectedStatusCode = 200, msg = `RemoveCaseTeamUser(${userId}) is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.delete(`/cases/${caseId}/caseteam/users/${userId}`, user);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Add or update a case team member.
     * @param Case
     * @param user
     * @param group
     */
    static setGroup(user, caseId, group, expectedStatusCode = 200, msg = `SetCaseTeamGroup(${group}) is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/caseteam/groups`, user, group);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Delete the specified member from the case team.
     * @param Case
     * @param user
     * @param group
     */
    static removeGroup(user, caseId, groupId, expectedStatusCode = 200, msg = `RemoveCaseTeamGroup(${groupId}) is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.delete(`/cases/${caseId}/caseteam/groups/${groupId}`, user);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Add or update a case team member.
     * @param Case
     * @param user
     * @param tenantRole
     */
    static setTenantRole(user, caseId, tenantRole, expectedStatusCode = 200, msg = `SetCaseTeamTenantRole(${tenantRole}) is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/caseteam/tenant-roles`, user, tenantRole);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Delete the specified member from the case team.
     * @param Case
     * @param user
     * @param tenantRole
     */
    static removeTenantRole(user, caseId, tenantRoleName, expectedStatusCode = 200, msg = `RemoveCaseTeamTenantRole(${tenantRoleName}) is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.delete(`/cases/${caseId}/caseteam/tenant-roles/${tenantRoleName}`, user);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
}
exports.default = CaseTeamService;
