import User from "../../user";
import Case from "../../cmmn/case";
import PlanItemHistory from "../../cmmn/planitemhistory";
export default class CaseHistoryService {
    /**
     * Get the history of all plan items in the case
     * @param Case
     * @param user
     */
    static getCasePlanHistory(user: User, caseId: Case | string, expectedStatusCode?: number, msg?: string): Promise<Array<PlanItemHistory>>;
    /**
     * Get the history of the plan item
     * @param Case
     * @param user
     * @param planItemId
     */
    static getPlanItemHistory(user: User, caseId: Case | string, planItemId: string, expectedStatusCode?: number, msg?: string): Promise<Array<PlanItemHistory>>;
}
