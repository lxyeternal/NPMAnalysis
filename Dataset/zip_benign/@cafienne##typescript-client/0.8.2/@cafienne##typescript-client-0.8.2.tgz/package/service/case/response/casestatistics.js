"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CaseStatistics = void 0;
class CaseStatistics {
    constructor(definition, totalInstances, numActive, numCompleted, numTerminated, numSuspended, numFailed, numClosed, numWithFailures) {
        this.definition = definition;
        this.totalInstances = totalInstances;
        this.numActive = numActive;
        this.numCompleted = numCompleted;
        this.numTerminated = numTerminated;
        this.numSuspended = numSuspended;
        this.numFailed = numFailed;
        this.numClosed = numClosed;
        this.numWithFailures = numWithFailures;
    }
    toString() {
        return `definition[${this.definition}]: total = ${this.totalInstances} active = ${this.numActive} closed = ${this.numClosed} completed = ${this.numCompleted} failed = ${this.numFailed} suspended = ${this.numSuspended} terminated = ${this.numTerminated} withFailures = ${this.numWithFailures}`;
    }
}
exports.CaseStatistics = CaseStatistics;
