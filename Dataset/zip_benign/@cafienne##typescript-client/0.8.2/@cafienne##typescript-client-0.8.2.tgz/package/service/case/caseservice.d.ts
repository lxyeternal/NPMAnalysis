import User from '../../user';
import Case from '../../cmmn/case';
import CaseFilter from './casefilter';
import StartCase from './startcase';
import StatisticsFilter from './statisticsfilter';
import DiscretionaryItem from '../../cmmn/discretionaryitem';
import { DiscretionaryItemsResponse } from './response/discretionaryitemsresponse';
import { CaseStatistics } from './response/casestatistics';
export default class CaseService {
    static startCase(user: User, command: StartCase, expectedStatusCode?: number, msg?: string): Promise<Case>;
    /**
     * Fetches and refreshes the case information from the backend
     * @param caseId
     * @param user
     */
    static getCase(user: User, caseId: Case | string, expectedStatusCode?: number, msg?: string): Promise<Case>;
    /**
     * Fetches the XML file with the CaseDefinition of the case instance.
     * @param Case
     * @param user
     */
    static getDefinition(user: User, caseId: Case | string, expectedStatusCode?: number): Promise<Document>;
    /**
     * Fetch cases for the user (optionally matching the filter)
     * @param filter
     * @param user
     */
    static getCases(user: User, filter?: CaseFilter, expectedStatusCode?: number, msg?: string): Promise<Array<Case>>;
    /**
     * Retrieves the list of discretionary items of the case instance
     * @param Case
     * @param user
     */
    static getDiscretionaryItems(user: User, caseId: Case | string, expectedStatusCode?: number, msg?: string): Promise<DiscretionaryItemsResponse>;
    /**
     * Add a discretionary item to the case plan.
     * @param Case
     * @param user User planning the item
     * @param item Item to be planned.
     * @param planItemId Optional id for the plan item resulting of the planning. If not specified, server will generate one.
     * @returns The id of the newly planned item
     */
    static planDiscretionaryItem(user: User, caseId: Case | string, item: DiscretionaryItem, planItemId?: string, expectedStatusCode?: number, msg?: string): Promise<string>;
    /**
     * Fetch statistics of cases across the system.
     * @param user
     * @param filter
     */
    static getCaseStatistics(user: User, filter?: StatisticsFilter, expectedStatusCode?: number, msg?: string): Promise<Array<CaseStatistics>>;
    /**
     * Enable or disable debug mode in the specified Case instance
     * @param Case
     * @param user
     * @param debugEnabled
     */
    static changeDebugMode(user: User, caseId: Case | string, debugEnabled: boolean, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
}
