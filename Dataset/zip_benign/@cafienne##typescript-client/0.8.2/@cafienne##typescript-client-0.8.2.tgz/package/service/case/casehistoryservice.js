"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
const planitemhistory_1 = __importDefault(require("../../cmmn/planitemhistory"));
class CaseHistoryService {
    /**
     * Get the history of all plan items in the case
     * @param Case
     * @param user
     */
    static getCasePlanHistory(user, caseId, expectedStatusCode = 200, msg = `GetCasePlanHistory is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get(`/cases/${caseId}/history/planitems`, user);
            return response_1.checkJSONResponse(response, msg, expectedStatusCode, [planitemhistory_1.default]);
        });
    }
    /**
     * Get the history of the plan item
     * @param Case
     * @param user
     * @param planItemId
     */
    static getPlanItemHistory(user, caseId, planItemId, expectedStatusCode = 200, msg = `GetPlanItemHistory is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get(`/cases/${caseId}/history/planitems/${planItemId}`, user);
            return response_1.checkJSONResponse(response, msg, expectedStatusCode, [planitemhistory_1.default]);
        });
    }
}
exports.default = CaseHistoryService;
