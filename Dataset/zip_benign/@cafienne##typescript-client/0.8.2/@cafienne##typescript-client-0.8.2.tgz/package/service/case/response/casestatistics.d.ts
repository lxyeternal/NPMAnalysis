export declare class CaseStatistics {
    definition: string;
    totalInstances: number;
    numActive: number;
    numCompleted: number;
    numTerminated: number;
    numSuspended: number;
    numFailed: number;
    numClosed: number;
    numWithFailures: number;
    constructor(definition: string, totalInstances: number, numActive: number, numCompleted: number, numTerminated: number, numSuspended: number, numFailed: number, numClosed: number, numWithFailures: number);
    toString(): string;
}
