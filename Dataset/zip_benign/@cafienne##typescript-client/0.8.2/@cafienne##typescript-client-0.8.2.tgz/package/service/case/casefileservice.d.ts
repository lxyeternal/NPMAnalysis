import User from "../../user";
import Case from "../../cmmn/case";
import CaseFileItemDocumentation from "../../cmmn/casefileitemdocumentation";
export default class CaseFileService {
    /**
     * Get the CaseFile of the specified case instance
     * @param Case
     * @param user
     */
    static getCaseFile(user: User, caseId: Case | string, expectedStatusCode?: number, msg?: string): Promise<any>;
    /**
     * Get the plan item's documentation
     * @param Case
     * @param user
     * @param planItemId
     */
    static getCaseFileDocumentation(user: User, caseId: Case | string, expectedStatusCode?: number, msg?: string): Promise<Array<CaseFileItemDocumentation>>;
    /**
     * Create case file item contents in the specified path
     * @param Case
     * @param user
     * @param path
     * @param data Any json structure matching the case file definition
     */
    static createCaseFileItem(user: User, caseId: Case | string, path: string, data: object, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Update case file item contents
     * @param Case
     * @param user
     * @param path
     * @param data
     */
    static updateCaseFileItem(user: User, caseId: Case | string, path: string, data: any, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Replace case file item contents
     * @param Case
     * @param user
     * @param path
     * @param data
     */
    static replaceCaseFileItem(user: User, caseId: Case | string, path: string, data: object, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Delete a case file item
     * @param Case
     * @param user
     * @param path
     */
    static deleteCaseFileItem(user: User, caseId: Case | string, path: string, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Create case file contents
     * @param Case
     * @param user
     * @param path
     * @param data Any json structure matching the case file definition
     */
    static createCaseFile(user: User, caseId: Case | string, data: object, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Update case file contents
     * @param Case
     * @param user
     * @param path
     * @param data
     */
    static updateCaseFile(user: User, caseId: Case | string, data: any, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Replace case file
     * @param Case
     * @param user
     * @param path
     * @param data
     */
    static replaceCaseFile(user: User, caseId: Case | string, data: object, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Delete entire case file
     * @param Case
     * @param user
     * @param path
     */
    static deleteCaseFile(user: User, caseId: Case | string, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
}
