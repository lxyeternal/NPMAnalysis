"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
class DebugService {
    /**
     * Retrieve model events from the backend for a specific ModelActor
     * @param model Id of the model to retrieve events from
     * @param user
     */
    static getEvents(model, user) {
        return __awaiter(this, void 0, void 0, function* () {
            const json = yield cafienneservice_1.default.get('/debug/' + model, user);
            return json;
        });
    }
    static getParsedEvents(model, user) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield this.getEvents(model, user);
            return response_1.checkJSONResponse(response, 'Expecting model events', 200, [Object]);
        });
    }
    static forceRecovery(user, modelId) {
        return __awaiter(this, void 0, void 0, function* () {
            return yield cafienneservice_1.default.patch(user, `/debug/force-recovery/${modelId}`);
        });
    }
}
exports.default = DebugService;
