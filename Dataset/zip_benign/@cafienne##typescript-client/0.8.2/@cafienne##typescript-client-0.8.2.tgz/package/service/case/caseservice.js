"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const case_1 = __importDefault(require("../../cmmn/case"));
const response_1 = require("../response");
const discretionaryitemsresponse_1 = require("./response/discretionaryitemsresponse");
const casestatistics_1 = require("./response/casestatistics");
const caseteam_1 = __importDefault(require("../../cmmn/team/caseteam"));
class CaseService {
    static startCase(user, command, expectedStatusCode = 200, msg = `StartCase is not expected to succeed for user ${user ? user.id : 'anonymous'}`) {
        var _a, _b;
        return __awaiter(this, void 0, void 0, function* () {
            if (!user) {
                // throw new Error("User must be specified");
            }
            console.log("Creating Case[" + command.definition + "] in tenant " + command.tenant);
            const url = '/cases';
            const caseInstanceId = command.caseInstanceId ? command.caseInstanceId : undefined;
            const debug = command.debug !== undefined ? command.debug : undefined;
            const request = {
                inputs: command.inputs,
                caseTeam: command.caseTeam,
                definition: (_a = command.definition) === null || _a === void 0 ? void 0 : _a.toString(),
                tenant: (_b = command.tenant) === null || _b === void 0 ? void 0 : _b.toString(),
                caseInstanceId,
                debug
            };
            const response = yield cafienneservice_1.default.post(url, user, request);
            const json = yield response_1.checkJSONResponse(response, msg, expectedStatusCode, case_1.default);
            // Hack: copy "StartCaseResponse.caseInstanceId" to "Case.id" in the json prior to instantiating Case.
            // TODO: consider whether it is better to work with a "StartCaseResponse" object instead
            if (response.ok) {
                json.id = json.caseInstanceId;
                console.log(`Created case instance with id: \t${json.id}`);
            }
            return json;
        });
    }
    /**
     * Fetches and refreshes the case information from the backend
     * @param caseId
     * @param user
     */
    static getCase(user, caseId, expectedStatusCode = 200, msg = `GetCase is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const convertCaseTeamFormat = (json) => {
                if (json.team && !(json.team.members || json.team.users || json.team.tenantRoles || json.team.groups))
                    json.team = new caseteam_1.default(json.team);
                return json;
            };
            const response = yield cafienneservice_1.default.get(`/cases/${caseId}`, user);
            return response_1.checkJSONResponse(response, msg, expectedStatusCode, case_1.default).then(convertCaseTeamFormat);
        });
    }
    /**
     * Fetches the XML file with the CaseDefinition of the case instance.
     * @param Case
     * @param user
     */
    static getDefinition(user, caseId, expectedStatusCode = 200) {
        return __awaiter(this, void 0, void 0, function* () {
            return cafienneservice_1.default.getXml(`/cases/${caseId}/definition`, user);
        });
    }
    /**
     * Fetch cases for the user (optionally matching the filter)
     * @param filter
     * @param user
     */
    static getCases(user, filter, expectedStatusCode = 200, msg = `GetCases is not expected to succeed for user ${user}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get('/cases', user, filter);
            return response_1.checkJSONResponse(response, msg, expectedStatusCode, [case_1.default]);
        });
    }
    /**
     * Retrieves the list of discretionary items of the case instance
     * @param Case
     * @param user
     */
    static getDiscretionaryItems(user, caseId, expectedStatusCode = 200, msg = `GetDiscretionaryItems is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get(`/cases/${caseId}/discretionaryitems`, user);
            return yield response_1.checkJSONResponse(response, msg, expectedStatusCode, discretionaryitemsresponse_1.DiscretionaryItemsResponse);
        });
    }
    /**
     * Add a discretionary item to the case plan.
     * @param Case
     * @param user User planning the item
     * @param item Item to be planned.
     * @param planItemId Optional id for the plan item resulting of the planning. If not specified, server will generate one.
     * @returns The id of the newly planned item
     */
    static planDiscretionaryItem(user, caseId, item, planItemId, expectedStatusCode = 200, msg = `PlanDiscretionaryItem is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const itemToPlan = { name: item.name, parentId: item.parentId, definitionId: item.definitionId, planItemId };
            const response = yield cafienneservice_1.default.post(`/cases/${caseId}/discretionaryitems/plan`, user, itemToPlan);
            const json = yield response_1.checkJSONResponse(response, msg, expectedStatusCode);
            return json.planItemId;
        });
    }
    /**
     * Fetch statistics of cases across the system.
     * @param user
     * @param filter
     */
    static getCaseStatistics(user, filter, expectedStatusCode = 200, msg = `GetCaseStatistics is not expected to succeed for user ${user}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get('/cases/stats', user, filter);
            return response_1.checkJSONResponse(response, msg, expectedStatusCode, [casestatistics_1.CaseStatistics]);
        });
    }
    /**
     * Enable or disable debug mode in the specified Case instance
     * @param Case
     * @param user
     * @param debugEnabled
     */
    static changeDebugMode(user, caseId, debugEnabled, expectedStatusCode = 200, msg = `ChangeDebugMode is not expected to succeed for user ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.put(`/cases/${caseId}/debug/${debugEnabled}`, user);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
}
exports.default = CaseService;
