import Case from "../../cmmn/case";
import CaseTeam from "../../cmmn/team/caseteam";
import CaseTeamGroup from "../../cmmn/team/caseteamgroup";
import CaseTeamUser from "../../cmmn/team/caseteamuser";
import CaseTeamTenantRole from "../../cmmn/team/caseteamtenantrole";
import User from "../../user";
export default class CaseTeamService {
    /**
     * Get the CaseTeam of the specified case instance
     * @param caseInstance
     * @param user
     * @returns CaseTeam
     */
    static getCaseTeam(user: User, caseId: Case | string, expectedStatusCode?: number, msg?: string): Promise<CaseTeam>;
    /**
     * Assign the specified team to the case
     * @param Case
     * @param user
     * @param team
     */
    static setCaseTeam(user: User, caseId: Case | string, team: CaseTeam, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Add or update a case team member.
     * @param Case
     * @param user
     * @param caseTeamUser
     */
    static setUser(user: User, caseId: Case | string, caseTeamUser: CaseTeamUser, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Delete the specified member from the case team.
     * @param Case
     * @param user
     * @param member
     */
    static removeUser(user: User, caseId: Case | string, userId: User | CaseTeamUser | string, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Add or update a case team member.
     * @param Case
     * @param user
     * @param group
     */
    static setGroup(user: User, caseId: Case | string, group: CaseTeamGroup, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Delete the specified member from the case team.
     * @param Case
     * @param user
     * @param group
     */
    static removeGroup(user: User, caseId: Case | string, groupId: CaseTeamGroup | string, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Add or update a case team member.
     * @param Case
     * @param user
     * @param tenantRole
     */
    static setTenantRole(user: User, caseId: Case | string, tenantRole: CaseTeamTenantRole, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Delete the specified member from the case team.
     * @param Case
     * @param user
     * @param tenantRole
     */
    static removeTenantRole(user: User, caseId: Case | string, tenantRoleName: CaseTeamTenantRole | string, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
}
