"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DefinitionMigration = void 0;
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
class CaseMigrationService {
    /**
     * Get the history of all plan items in the case
     * @param Case
     * @param user
     */
    static migrateDefinition(user, Case, migration, expectedStatusCode = 200) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.post(`/cases/${Case.id}/migrate-definition`, user, {
                newDefinition: migration.newDefinition.toString(),
                newTeam: migration.newTeam,
            });
            const msg = `MigrateDefinition is not expected to succeed for user ${user.id} in case ${Case.id}`;
            return response_1.checkJSONResponse(response, msg, expectedStatusCode);
        });
    }
}
exports.default = CaseMigrationService;
class DefinitionMigration {
    constructor(newDefinition, newTeam) {
        this.newDefinition = newDefinition;
        this.newTeam = newTeam;
    }
}
exports.DefinitionMigration = DefinitionMigration;
