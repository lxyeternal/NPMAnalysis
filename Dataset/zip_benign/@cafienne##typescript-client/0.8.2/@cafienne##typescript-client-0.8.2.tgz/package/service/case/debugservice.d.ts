import User from '../../user';
export default class DebugService {
    /**
     * Retrieve model events from the backend for a specific ModelActor
     * @param model Id of the model to retrieve events from
     * @param user
     */
    static getEvents(model: string, user?: User): Promise<import("../response").default>;
    static getParsedEvents(model: string, user?: User): Promise<any>;
    static forceRecovery(user: User, modelId: string): Promise<import("../response").default>;
}
