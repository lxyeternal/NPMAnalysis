import User from '../../user';
import Task from '../../cmmn/task';
import Case from '../../cmmn/case';
import TaskFilter from './taskfilter';
import PlanItem from '../../cmmn/planitem';
/**
 * Base class for invoking the Cafienne Tasks API (http://localhost:2027/tasks)
 */
export default class TaskService {
    /**
     * Claims the task on behalf of this user
     * @param task Task to claim
     * @param user User claiming the task
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static claimTask(user: User, task: Task | PlanItem | string, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Revokes the task on behalf of this user
     * @param task Task to revoke
     * @param user User revoking the task
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static revokeTask(user: User, task: Task | PlanItem | string, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Assigns the task to the specified user
     * @param task Task to assign
     * @param user User assigning the task
     * @param assignee User to which the task is assigned
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static assignTask(user: User, task: Task | PlanItem | string, assignee: User, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Delegates the task on behalf of this user
     * @param task Task to delegate
     * @param user User delegating the task
     * @param assignee User to which the task is delegated
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static delegateTask(user: User, task: Task | PlanItem | string, assignee: User, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Completes the task on behalf of the user, with the optional task output.
     * @param task
     * @param user
     * @param taskOutput
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static completeTask(user: User, task: Task | PlanItem | string, taskOutput?: {}, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Validates whether the given output is acceptable for the task.
     * @param task Task to validate output against
     * @param user User trying to validate the task output
     * @param taskOutput Task output to validate
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static validateTaskOutput(user: User, task: Task | PlanItem | string, taskOutput?: {}, expectedStatusCode?: number, msg?: string): Promise<any>;
    /**
     * Save the task output on behalf of the user
     * @param task Task to save the output in
     * @param user User saving the task output
     * @param taskOutput Task output to save
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static saveTaskOutput(user: User, task: Task | PlanItem | string, taskOutput?: {}, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Fetches and refreshes the task information from the backend
     * Note: returns a fresh instance of Task
     * @param task
     * @param user
     */
    static getTask(user: User, task: Task | PlanItem | string, expectedStatusCode?: number, msg?: string): Promise<Task>;
    /**
     * Fetches all tasks from the specified case instance from the backend
     * @param Case
     * @param user
     */
    static getCaseTasks(user: User, caseId: Case | string, expectedStatusCode?: number, msg?: string): Promise<Array<Task>>;
    /**
     * Fetches all tasks from the specified case instance from the backend and searches within that list for the one that
     * matches the task parameter (either task id or task name can be given).
     * @param Case
     * @param user
     * @param task
     */
    static getCaseTask(user: User, caseId: Case | string, task: Task | PlanItem | string): Promise<Task>;
    /**
     * Returns all tasks from case instances with the specified definition
     * @param user
     * @param definition
     */
    static getTasksOfCaseType(user: User, definition: string, expectedStatusCode?: number): Promise<Array<Task>>;
    /**
     * Fetches all tasks to which the user has access, with an optional filter
     * @param user User fetching the task list
     * @param filter Optional filter for the tasks (e.g., to get only Active tasks)
     */
    static getTasks(user: User, filter?: TaskFilter, expectedStatusCode?: number, msg?: string): Promise<Array<Task>>;
    /**
     * Counts the number of tasks that the user has access to.
     * Returns the count of assigned and unassigned tasks.
     * @param user
     * @param filter
     */
    static countTasks(user: User, filter?: TaskFilter, expectedStatusCode?: number, msg?: string): Promise<TaskCount>;
}
export interface TaskCount {
    claimed: number;
    unclaimed: number;
}
