"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const task_1 = __importDefault(require("../../cmmn/task"));
const response_1 = require("../response");
/**
 * Base class for invoking the Cafienne Tasks API (http://localhost:2027/tasks)
 */
class TaskService {
    /**
     * Claims the task on behalf of this user
     * @param task Task to claim
     * @param user User claiming the task
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static claimTask(user, task, expectedStatusCode = 202, msg = '') {
        return __awaiter(this, void 0, void 0, function* () {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task '${taskName}' with id ${taskId} was claimed succesfully, but this was not expected`;
            }
            if (!msg) {
                msg = msg;
            }
            const response = yield cafienneservice_1.default.put(`tasks/${taskId}/claim`, user);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Revokes the task on behalf of this user
     * @param task Task to revoke
     * @param user User revoking the task
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static revokeTask(user, task, expectedStatusCode = 202, msg = '') {
        return __awaiter(this, void 0, void 0, function* () {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task '${taskName}' with id ${taskId} was revoked succesfully, but this was not expected`;
            }
            const response = yield cafienneservice_1.default.put(`tasks/${taskId}/revoke`, user);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Assigns the task to the specified user
     * @param task Task to assign
     * @param user User assigning the task
     * @param assignee User to which the task is assigned
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static assignTask(user, task, assignee, expectedStatusCode = 202, msg = '') {
        return __awaiter(this, void 0, void 0, function* () {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task '${taskName}' with id ${taskId} was assigned successfully, but this was not expected`;
            }
            const response = yield cafienneservice_1.default.put(`tasks/${taskId}/assign`, user, { assignee: assignee.id });
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Delegates the task on behalf of this user
     * @param task Task to delegate
     * @param user User delegating the task
     * @param assignee User to which the task is delegated
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static delegateTask(user, task, assignee, expectedStatusCode = 202, msg = '') {
        return __awaiter(this, void 0, void 0, function* () {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task '${taskName}' with id ${taskId} was delegated succesfully, but this was not expected`;
            }
            const response = yield cafienneservice_1.default.put(`tasks/${taskId}/delegate`, user, { assignee: assignee.id });
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Completes the task on behalf of the user, with the optional task output.
     * @param task
     * @param user
     * @param taskOutput
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static completeTask(user, task, taskOutput = {}, expectedStatusCode = 202, msg = '') {
        return __awaiter(this, void 0, void 0, function* () {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task '${taskName}' with id ${taskId} was completed succesfully, but this was not expected`;
            }
            const response = yield cafienneservice_1.default.post(`tasks/${taskId}/complete`, user, taskOutput);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Validates whether the given output is acceptable for the task.
     * @param task Task to validate output against
     * @param user User trying to validate the task output
     * @param taskOutput Task output to validate
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static validateTaskOutput(user, task, taskOutput = {}, expectedStatusCode = 202, msg = '') {
        return __awaiter(this, void 0, void 0, function* () {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task output for '${taskName}' with id ${taskId} was validated succesfully, but this was not expected`;
            }
            const response = yield cafienneservice_1.default.post(`tasks/${taskId}`, user, taskOutput);
            const res = yield response_1.checkResponse(response, msg, expectedStatusCode);
            if (response.ok) {
                const json = yield response.json();
                return json;
            }
            else {
                const text = yield response.text();
                return text;
            }
        });
    }
    /**
     * Save the task output on behalf of the user
     * @param task Task to save the output in
     * @param user User saving the task output
     * @param taskOutput Task output to save
     * @param expectedStatusCode defaults to true; if false is specified, then a failure is expected in the invocation.
     */
    static saveTaskOutput(user, task, taskOutput = {}, expectedStatusCode = 202, msg = '') {
        return __awaiter(this, void 0, void 0, function* () {
            const taskId = getTaskId(task);
            const taskName = getTaskName(task);
            if (!msg) {
                msg = `Task output for '${taskName}' with id ${taskId} was saved succesfully, but this was not expected`;
            }
            const response = yield cafienneservice_1.default.put(`tasks/${taskId}`, user, taskOutput);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Fetches and refreshes the task information from the backend
     * Note: returns a fresh instance of Task
     * @param task
     * @param user
     */
    static getTask(user, task, expectedStatusCode = 200, msg = '') {
        return __awaiter(this, void 0, void 0, function* () {
            const taskId = getTaskId(task);
            if (!msg) {
                msg = `GetTask is not expected to succeed for user ${user} on task ${taskId}`;
            }
            const response = yield cafienneservice_1.default.get(`tasks/${taskId}`, user);
            return yield response_1.checkJSONResponse(response, msg, expectedStatusCode, task_1.default);
        });
    }
    /**
     * Fetches all tasks from the specified case instance from the backend
     * @param Case
     * @param user
     */
    static getCaseTasks(user, caseId, expectedStatusCode = 200, msg = `GetCaseTasks is not expected to succeed for member ${user} in case ${caseId}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get(`/tasks/case/${caseId}`, user);
            return yield response_1.checkJSONResponse(response, msg, expectedStatusCode, [task_1.default]);
        });
    }
    /**
     * Fetches all tasks from the specified case instance from the backend and searches within that list for the one that
     * matches the task parameter (either task id or task name can be given).
     * @param Case
     * @param user
     * @param task
     */
    static getCaseTask(user, caseId, task) {
        return __awaiter(this, void 0, void 0, function* () {
            const taskId = getTaskId(task);
            const tasks = yield this.getCaseTasks(user, caseId);
            const responseTask = tasks.find(task => task.id === taskId || task.taskName === taskId);
            if (!responseTask) {
                throw new Error(`Cannot find task ${taskId} in case ${caseId}; tasks are ${tasks.map(t => t.taskName).join('\'')}`);
            }
            else {
                return responseTask;
            }
        });
    }
    /**
     * Returns all tasks from case instances with the specified definition
     * @param user
     * @param definition
     */
    static getTasksOfCaseType(user, definition, expectedStatusCode = 200) {
        return __awaiter(this, void 0, void 0, function* () {
            throw new Error('Not yet implemented');
        });
    }
    /**
     * Fetches all tasks to which the user has access, with an optional filter
     * @param user User fetching the task list
     * @param filter Optional filter for the tasks (e.g., to get only Active tasks)
     */
    static getTasks(user, filter, expectedStatusCode = 200, msg = `GetTasks is not expected to succeed for member ${user}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get('/tasks', user, filter);
            return yield response_1.checkJSONResponse(response, msg, expectedStatusCode, [task_1.default]);
        });
    }
    /**
     * Counts the number of tasks that the user has access to.
     * Returns the count of assigned and unassigned tasks.
     * @param user
     * @param filter
     */
    static countTasks(user, filter, expectedStatusCode = 200, msg = `CountTasks is not expected to succeed for member ${user}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get('/tasks/user/count', user, filter);
            return yield response_1.checkJSONResponse(response, msg, expectedStatusCode);
        });
    }
}
exports.default = TaskService;
function getTaskId(task) {
    return (typeof (task) === 'string') ? task : task.id;
}
function getTaskName(task) {
    return (typeof (task) === 'string') ? task : task instanceof task_1.default ? task.taskName : task.name;
}
