"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
class CaseIdentifierService {
    /**
     * Fetch identifiers for the user (optionally matching the filter)
     * @param filter
     * @param user
     */
    static getIdentifiers(user, filter, expectedStatusCode = 200, msg = `GetIdentifiers is not expected to succeed for user ${user}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get('/identifiers', user, filter);
            return response_1.checkJSONResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Fetch identifiers for the user (optionally matching the filter)
     * @param filter
     * @param user
     */
    static getIdentifierNames(user, filter, expectedStatusCode = 200, msg = `GetIdentifiers is not expected to succeed for user ${user}`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get('/identifiers/names', user, filter);
            return response_1.checkJSONResponse(response, msg, expectedStatusCode);
        });
    }
}
exports.default = CaseIdentifierService;
