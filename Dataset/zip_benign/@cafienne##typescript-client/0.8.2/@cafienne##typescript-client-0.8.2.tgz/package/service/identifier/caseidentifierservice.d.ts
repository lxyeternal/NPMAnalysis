import User from '../../user';
import IdentifierFilter from './identifierfilter';
export default class CaseIdentifierService {
    /**
     * Fetch identifiers for the user (optionally matching the filter)
     * @param filter
     * @param user
     */
    static getIdentifiers(user: User, filter?: IdentifierFilter, expectedStatusCode?: number, msg?: string): Promise<Array<any>>;
    /**
     * Fetch identifiers for the user (optionally matching the filter)
     * @param filter
     * @param user
     */
    static getIdentifierNames(user: User, filter?: IdentifierFilter, expectedStatusCode?: number, msg?: string): Promise<Array<any>>;
}
