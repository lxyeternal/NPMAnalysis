"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = __importDefault(require("../../config"));
const logger_1 = __importDefault(require("../../logger"));
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
const consentgroup_1 = __importDefault(require("./consentgroup"));
const consentgroupmember_1 = __importDefault(require("./consentgroupmember"));
/**
 * Connection to the /consent-group APIs of Cafienne
 */
class ConsentGroupService {
    /**
     * Creates the consent group
     * @param user
     * @param tenant
     * @param group
     * @param expectedStatusCode
     * @returns
     */
    static createGroup(user, tenant, group, expectedStatusCode = 200) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.post(`/tenant/${tenant}/consent-groups`, user, group.toJson());
            if (response.status === 400 && expectedStatusCode === 200) {
                const msg = yield response.text();
                if (msg === 'Consent group already exists' || msg.indexOf('Failure while handling message CreateConsentGroup') >= 0) {
                    // Tenant already exists is ok.
                    if (config_1.default.PlatformService.log)
                        logger_1.default.debug(`Consent group ${group} already exists.'`);
                    return response;
                }
            }
            const msg = `CreateConsentGroup is not expected to succeed for user ${user.id} in ${tenant}`;
            return response_1.checkJSONResponse(response, msg, expectedStatusCode).then(json => {
                // After getting a succesful response we silently set the group id if not available
                //  (typical use case: the server generated it instead the client passing it)
                if (!group.id && json.groupId) {
                    group.id = json.groupId;
                }
            });
        });
    }
    /**
     * Retrieve a consent group with it's members
     * @param user Must be a valid user in the group
     * @param groupId
     * @param expectedStatusCode
     */
    static getGroup(user, groupId, expectedStatusCode = 200) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get(`/consent-group/${groupId}`, user);
            const msg = `GetGroup is not expected to succeed for user ${user.id} in group ${groupId}`;
            return response_1.checkJSONResponse(response, msg, expectedStatusCode, consentgroup_1.default);
        });
    }
    /**
     * Replaces the consent group
     * @param user
     * @param tenant
     * @param group
     * @param expectedStatusCode
     * @returns
     */
    static replaceGroup(user, group, expectedStatusCode = 202) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.post(`/consent-group/${group}`, user, group.toJson());
            const msg = `ReplaceConsentGroup is not expected to succeed for user ${user.id} in ${group}`;
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Retrieve information about a specific user in the group
     * @param user Must be a group user
     * @param groupId
     * @param userId User or Id of the user to retrieve the information for
     * @param expectedStatusCode
     */
    static getGroupMember(user, groupId, userId, expectedStatusCode = 200) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.get(`/consent-group/${groupId}/members/${userId}`, user);
            const msg = `GetGroupMember(${userId}) is not expected to succeed for user ${user.id} in group ${groupId}`;
            return response_1.checkJSONResponse(response, msg, expectedStatusCode, consentgroupmember_1.default);
        });
    }
    /**
     * Add or replace a user in the group
     * @param user Must be a group owner
     * @param groupId Group in which to add/replace the member.
     * @param newUser The new user information that will be updated
     * @param expectedStatusCode
     */
    static setGroupMember(user, groupId, newUser, expectedStatusCode = 202) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.post(`/consent-group/${groupId}/members`, user, newUser.toJson());
            const msg = `SetGroupMember is not expected to succeed for user ${user.id} in consent group ${groupId}`;
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     *
     * @param user Must be a group owner
     * @param groupId Group to remove the member from
     * @param userId User or id of user to be removed from the group.
     * @param expectedStatusCode
     * @returns
     */
    static removeGroupMember(user, groupId, userId, expectedStatusCode = 202) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.delete(`/consent-group/${groupId}/members/${userId}`, user);
            const msg = `RemoveGroupMember ${userId} from group ${groupId} is not expected to succeed for user ${user.id}`;
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
}
exports.default = ConsentGroupService;
