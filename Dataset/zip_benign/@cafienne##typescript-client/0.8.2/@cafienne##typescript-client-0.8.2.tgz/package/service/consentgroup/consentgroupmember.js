"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConsentGroupOwner = void 0;
const user_1 = __importDefault(require("../../user"));
class ConsentGroupMember extends user_1.default {
    /**
     * Simple wrapper for a ConsentGroup member.
     * It needs a userId, which must match the 'sub' inside the JWT token sent to the case engine.
     * The class User has an id, and this id is put inside the 'sub' of the token when the user logs in.
     *
     * @param userId Typically filled from User.id.
     * @param roles Set of strings containing the names of the roles the user has within the tenant.
     * @param isOwner Optional flag to indicate that this user is a tenant owner
     */
    constructor(userId, roles = [], isOwner = false) {
        super(userId);
        this.userId = userId;
        this.roles = roles;
        this.isOwner = isOwner;
    }
    toJson() {
        return { userId: this.userId, roles: this.roles, isOwner: this.isOwner };
    }
    /**
     * Copies this user info, with overwriting the ownership with the given value
     * @param isOwner
     * @returns
     */
    withOwnership(isOwner) {
        return new ConsentGroupMember(this.userId, this.roles, isOwner);
    }
    /**
     * Copies this user info, with overwriting the roles with the new set
     * @param roles
     * @returns
     */
    withRoles(...roles) {
        return new ConsentGroupMember(this.userId, roles, this.isOwner);
    }
    withExtraRoles(...roles) {
        return new ConsentGroupMember(this.userId, [...this.roles, ...roles], this.isOwner);
    }
}
exports.default = ConsentGroupMember;
class ConsentGroupOwner extends ConsentGroupMember {
    constructor(userId, roles = []) {
        super(userId, roles, true);
        this.userId = userId;
        this.roles = roles;
    }
}
exports.ConsentGroupOwner = ConsentGroupOwner;
