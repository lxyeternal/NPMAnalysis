import User from '../../user';
export default class TokenService {
    /**
     * Fetches a token for the user that has the given validity period (defaults to 2 days from now).
     *
     * @param user
     * @param issuedAt
     * @param expiresAt
     */
    static getToken(user: User, issuer?: string, issuedAt?: Date, expiresAt?: Date): Promise<string>;
    static fetchToken(claims: object): Promise<string>;
}
/**
 * Converts a date to seconds (instead of milliseconds).
 * Is needed for JWT tokens.
 * @param date
 */
export declare function dateAsSeconds(date?: Date): number | undefined;
