"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const userinformation_1 = __importDefault(require("../../tenant/userinformation"));
const config_1 = __importDefault(require("../../config"));
const response_1 = require("../response");
const logger_1 = __importDefault(require("../../logger"));
/**
 * Connection to the /registration APIs of Cafienne
 */
class PlatformService {
    /**
     * Creates the tenant on behalf of the user. User must be a platform owner.
     * @param user
     * @param tenant
     * @param expectedStatusCode
     */
    static createTenant(user, tenant, expectedStatusCode = 204, errorMsg = `CreateTenant is not expected to succeed for user ${user} in tenant ${tenant}`) {
        return __awaiter(this, void 0, void 0, function* () {
            if (config_1.default.PlatformService.log)
                logger_1.default.debug(`Creating Tenant ${tenant.name}`);
            const response = yield cafienneservice_1.default.post('/platform', user, tenant.toJson());
            if (response.status === 400 && expectedStatusCode === 204) {
                const msg = yield response.text();
                if (msg === 'Tenant already exists' || msg.indexOf('Failure while handling message CreateTenant') >= 0) {
                    // Tenant already exists is ok.
                    if (config_1.default.PlatformService.log)
                        logger_1.default.debug(`Tenant ${tenant.name} already exists.'`);
                    return response;
                }
            }
            return response_1.checkResponse(response, errorMsg, expectedStatusCode);
        });
    }
    /**
     * Disable a tenant.
     * @param user Must be a platform owner
     * @param tenant
     * @param expectedStatusCode
     */
    static disableTenant(user, tenant, expectedStatusCode = 204, msg = `Disabling the tenant ${tenant} was not expected to succeed`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.put(`/platform/${tenant}/disable`, user);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    /**
     * Enable a tenant.
     * @param user Must be a platform owner
     * @param tenant
     * @param expectedStatusCode
     */
    static enableTenant(user, tenant, expectedStatusCode = 204, msg = `Enabling the tenant ${tenant} was not expected to succeed`) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield cafienneservice_1.default.put(`/platform/${tenant}/enable`, user);
            return response_1.checkResponse(response, msg, expectedStatusCode);
        });
    }
    static getDisabledTenants(user, expectedStatusCode = 200) {
        return __awaiter(this, void 0, void 0, function* () {
            throw new Error('Not yet implemented in the server side');
        });
    }
    /**
     * Fetches all information the case engine has on this user.
     * Can only be invoked by the user itself.
     * @param user
     */
    static getUserInformation(user) {
        return __awaiter(this, void 0, void 0, function* () {
            const url = '/platform/user';
            const response = yield cafienneservice_1.default.get(url, user);
            return response_1.checkJSONResponse(response, 'Expected valid user information', 200, userinformation_1.default);
        });
    }
    /**
     * Returns a json with the platform health
     */
    static getHealth() {
        return __awaiter(this, void 0, void 0, function* () {
            const url = '/health';
            const response = yield cafienneservice_1.default.get(url, undefined);
            return response_1.checkJSONResponse(response, 'Expected proper health information', 200);
        });
    }
    /**
     * Returns a json with the platform version
     */
    static getVersion() {
        return __awaiter(this, void 0, void 0, function* () {
            const url = '/version';
            const response = yield cafienneservice_1.default.get(url, undefined);
            return response_1.checkJSONResponse(response, 'Expected proper version information', 200);
        });
    }
}
exports.default = PlatformService;
