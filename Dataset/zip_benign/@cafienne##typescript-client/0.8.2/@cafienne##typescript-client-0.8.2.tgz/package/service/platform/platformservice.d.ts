import User from '../../user';
import Tenant from '../../tenant/tenant';
import UserInformation from '../../tenant/userinformation';
/**
 * Connection to the /registration APIs of Cafienne
 */
export default class PlatformService {
    /**
     * Creates the tenant on behalf of the user. User must be a platform owner.
     * @param user
     * @param tenant
     * @param expectedStatusCode
     */
    static createTenant(user: User, tenant: Tenant, expectedStatusCode?: number, errorMsg?: string): Promise<import("../response").default>;
    /**
     * Disable a tenant.
     * @param user Must be a platform owner
     * @param tenant
     * @param expectedStatusCode
     */
    static disableTenant(user: User, tenant: Tenant | string, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    /**
     * Enable a tenant.
     * @param user Must be a platform owner
     * @param tenant
     * @param expectedStatusCode
     */
    static enableTenant(user: User, tenant: Tenant | string, expectedStatusCode?: number, msg?: string): Promise<import("../response").default>;
    static getDisabledTenants(user: User, expectedStatusCode?: number): Promise<void>;
    /**
     * Fetches all information the case engine has on this user.
     * Can only be invoked by the user itself.
     * @param user
     */
    static getUserInformation(user: User): Promise<UserInformation>;
    /**
     * Returns a json with the platform health
     */
    static getHealth(): Promise<any>;
    /**
     * Returns a json with the platform version
     */
    static getVersion(): Promise<any>;
}
