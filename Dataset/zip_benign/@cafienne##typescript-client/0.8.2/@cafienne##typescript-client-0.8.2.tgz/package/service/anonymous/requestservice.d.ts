import Case from '../../cmmn/case';
export default class RequestService {
    static requestCase(casePath: string | undefined, inputs: any, caseInstanceId?: string, debug?: boolean, expectedStatusCode?: number): Promise<Case>;
}
