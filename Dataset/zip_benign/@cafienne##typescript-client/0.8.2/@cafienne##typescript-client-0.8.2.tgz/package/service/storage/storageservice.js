"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const config_1 = __importDefault(require("../../config"));
const logger_1 = __importDefault(require("../../logger"));
const cafienneservice_1 = __importDefault(require("../cafienneservice"));
const response_1 = require("../response");
/**
 * Connection to the /storage APIs of Cafienne
 */
class StorageService {
    /**
     * Deletes the case on behalf of the user. User must be a tenant owner.
     * @param user
     * @param caseInstance
     * @param expectedStatusCode
     */
    static archiveCase(user, caseInstance, expectedStatusCode = 202, errorMsg = `ArchiveCase is not expected to succeed for user ${user} on case ${caseInstance}`) {
        return __awaiter(this, void 0, void 0, function* () {
            if (config_1.default.PlatformService.log)
                logger_1.default.debug(`Archiving case ${caseInstance}`);
            const response = yield cafienneservice_1.default.put(`/storage/case/${caseInstance}/archive`, user);
            return response_1.checkResponse(response, errorMsg, expectedStatusCode);
        });
    }
    /**
     * Deletes the case on behalf of the user. User must be a tenant owner.
     * @param user
     * @param caseInstance
     * @param expectedStatusCode
     */
    static restoreCase(user, caseInstance, expectedStatusCode = 202, errorMsg = `RestoreCase is not expected to succeed for user ${user} on case ${caseInstance}`) {
        return __awaiter(this, void 0, void 0, function* () {
            if (config_1.default.PlatformService.log)
                logger_1.default.debug(`Restoring case ${caseInstance}`);
            const response = yield cafienneservice_1.default.put(`/storage/case/${caseInstance}/restore`, user);
            return response_1.checkResponse(response, errorMsg, expectedStatusCode);
        });
    }
    /**
     * Deletes the case on behalf of the user. User must be a tenant owner.
     * @param user
     * @param caseInstance
     * @param expectedStatusCode
     */
    static deleteCase(user, caseInstance, expectedStatusCode = 202, errorMsg = `DeleteCase is not expected to succeed for user ${user} on case ${caseInstance}`) {
        return __awaiter(this, void 0, void 0, function* () {
            if (config_1.default.PlatformService.log)
                logger_1.default.debug(`Deleting case ${caseInstance}`);
            const response = yield cafienneservice_1.default.delete(`/storage/case/${caseInstance}`, user);
            return response_1.checkResponse(response, errorMsg, expectedStatusCode);
        });
    }
    /**
     * Deletes the tenant on behalf of the user. User must be a tenant owner.
     * @param user
     * @param tenant
     * @param expectedStatusCode
     */
    static deleteTenant(user, tenant, expectedStatusCode = 202, errorMsg = `DeleteTenant is not expected to succeed for user ${user} on tenant ${tenant}`) {
        return __awaiter(this, void 0, void 0, function* () {
            if (config_1.default.PlatformService.log)
                logger_1.default.debug(`Deleting Tenant ${tenant}`);
            const response = yield cafienneservice_1.default.delete(`/storage/tenant/${tenant}`, user);
            return response_1.checkResponse(response, errorMsg, expectedStatusCode);
        });
    }
}
exports.default = StorageService;
