declare const Config: {
    Log: {
        level: string;
        color: {
            debug: string;
            info: string;
            warn: string;
            error: string;
        };
    };
    CafienneService: {
        url: string;
        log: {
            url: boolean;
            request: {
                headers: boolean;
                body: boolean;
            };
            response: {
                status: boolean;
                headers: boolean;
                body: boolean;
                error: boolean;
            };
        };
        cqrsWaitTime: number;
    };
    TokenService: {
        url: string;
        issuer: string;
        log: boolean;
    };
    MockService: {
        log: boolean;
        registration: boolean;
        response: boolean;
    };
    PlatformService: {
        log: boolean;
    };
    RepositoryService: {
        log: boolean;
        repository_folder: string;
    };
    TestCase: {
        log: boolean;
        polltimeout: number;
    };
};
export default Config;
