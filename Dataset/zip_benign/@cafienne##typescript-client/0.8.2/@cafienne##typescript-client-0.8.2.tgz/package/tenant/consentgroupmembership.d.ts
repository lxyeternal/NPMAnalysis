export default class ConsentGroupMembership {
    groupId?: string;
    roles: Array<string>;
    isOwner?: boolean;
}
