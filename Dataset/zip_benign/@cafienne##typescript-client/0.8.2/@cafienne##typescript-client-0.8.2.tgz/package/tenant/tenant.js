"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Tenant {
    /**
     * Simple wrapper class for Tenant.
     * @param name Name (and id) of the tenant.
     * @param users List of Tenant Users in the tenant.
     */
    constructor(name, users) {
        this.name = name;
        this.users = users;
    }
    /**
     * Returns the tenant users that are owner.
     */
    getOwners() {
        return this.users.filter(user => user.isOwner);
    }
    toJson() {
        return { name: this.name, users: this.users.map(user => user.toJson ? user.toJson() : user) };
    }
    toString() {
        return this.name;
    }
}
exports.default = Tenant;
