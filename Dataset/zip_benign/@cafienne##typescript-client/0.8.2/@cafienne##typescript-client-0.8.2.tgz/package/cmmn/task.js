"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cmmnbaseclass_1 = __importDefault(require("./cmmnbaseclass"));
class Task extends cmmnbaseclass_1.default {
    constructor(id, taskName, taskState, assignee, owner, caseInstanceId, tenant, role, lastModified, modifiedBy, dueDate, createdOn, createdBy, input, output, taskModel) {
        super();
        this.id = id;
        this.taskName = taskName;
        this.taskState = taskState;
        this.assignee = assignee;
        this.owner = owner;
        this.caseInstanceId = caseInstanceId;
        this.tenant = tenant;
        this.role = role;
        this.lastModified = lastModified;
        this.modifiedBy = modifiedBy;
        this.dueDate = dueDate;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.input = input;
        this.output = output;
        this.taskModel = taskModel;
    }
    toString() {
        return `${this.taskName}[${this.id}]`;
    }
    summary() {
        return this.toString() + ` - ${this.taskState}`;
    }
    isCompleted() {
        return this.taskState === 'Completed';
    }
    isAssigned() {
        return this.taskState === 'Assigned';
    }
    isActive() {
        return this.taskState !== 'Completed' && this.taskState !== 'Terminated';
    }
    /**
     * Returns true for Delegated, Unassigned and Assigned tasks.
     */
    static isActive(task) {
        return task && task.isActive();
    }
}
exports.default = Task;
