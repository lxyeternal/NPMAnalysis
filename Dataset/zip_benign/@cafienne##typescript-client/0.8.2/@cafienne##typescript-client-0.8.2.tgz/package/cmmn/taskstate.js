"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Base class to expose possible TaskStates of plan items and case file items.
 */
class TaskState {
    constructor(value) {
        this.value = value;
    }
    static of(value) {
        var _a;
        if (value instanceof TaskState)
            return value;
        for (const state of TaskState.states) {
            if (((_a = state.value) === null || _a === void 0 ? void 0 : _a.toLowerCase()) === value.toLowerCase()) {
                return state;
            }
        }
        throw new Error(`${value} is not a valid TaskState`);
    }
    is(other) {
        if (!other)
            return false;
        return this.value.toLowerCase() === other.toString().toLowerCase();
    }
    toString() {
        return this.value;
    }
}
exports.default = TaskState;
TaskState.Null = new TaskState('Null');
TaskState.Unassigned = new TaskState('Unassigned');
TaskState.Assigned = new TaskState('Assigned');
TaskState.Delegated = new TaskState('Delegated');
TaskState.Completed = new TaskState('Completed');
TaskState.Suspended = new TaskState('Suspended');
TaskState.Terminated = new TaskState('Terminated');
TaskState.states = [TaskState.Null, TaskState.Unassigned, TaskState.Assigned, TaskState.Delegated, TaskState.Completed, TaskState.Suspended, TaskState.Terminated];
