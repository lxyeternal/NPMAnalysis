/**
 * Base class to expose possible states of plan items and case file items.
 */
export default class State {
    readonly value: string;
    static readonly Null: State;
    static readonly Active: State;
    static readonly Available: State;
    static readonly Closed: State;
    static readonly Completed: State;
    static readonly Disabled: State;
    static readonly Discarded: State;
    static readonly Enabled: State;
    static readonly Failed: State;
    static readonly Suspended: State;
    static readonly Terminated: State;
    private static states;
    static of(value: string | State): State;
    private constructor();
    is(other: string | State | undefined | null): boolean;
    toString(): string;
}
