/**
 * Fixed list of all possible transitions that can be invoked on a plan item.
 */
export default class Transition {
    readonly value: string;
    static readonly Close: Transition;
    static readonly Complete: Transition;
    static readonly Create: Transition;
    static readonly Disable: Transition;
    static readonly Enable: Transition;
    static readonly Exit: Transition;
    static readonly Fault: Transition;
    static readonly ManualStart: Transition;
    static readonly None: Transition;
    static readonly Occur: Transition;
    static readonly ParentResume: Transition;
    static readonly ParentSuspend: Transition;
    static readonly ParentTerminate: Transition;
    static readonly Reactivate: Transition;
    static readonly Reenable: Transition;
    static readonly Resume: Transition;
    static readonly Start: Transition;
    static readonly Suspend: Transition;
    static readonly Terminate: Transition;
    private static transitions;
    static of(value: string | Transition): Transition;
    private constructor();
    is(other: string | Transition | undefined | null): boolean;
    toString(): string;
}
