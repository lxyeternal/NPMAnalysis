/**
 * Generic wrapper for case file json.
 * Should probably become a class with some handy methods.
 */
export default interface CaseFile {
}
/**
 * Read a case file item from case file based on the path.
 * E.g. /Greeting/From or Order/Lines[3]/Item
 * @param caseFile
 * @param path
 */
export declare function pathReader(caseFile: any, path: string): any;
