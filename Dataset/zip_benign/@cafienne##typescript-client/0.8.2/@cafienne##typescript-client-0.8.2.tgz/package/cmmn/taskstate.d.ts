/**
 * Base class to expose possible TaskStates of plan items and case file items.
 */
export default class TaskState {
    readonly value: string;
    static readonly Null: TaskState;
    static readonly Unassigned: TaskState;
    static readonly Assigned: TaskState;
    static readonly Delegated: TaskState;
    static readonly Completed: TaskState;
    static readonly Suspended: TaskState;
    static readonly Terminated: TaskState;
    private static states;
    static of(value: string | TaskState): TaskState;
    private constructor();
    is(other: string | TaskState | undefined | null): boolean;
    toString(): string;
}
