"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * JSON Wrapper for plan items in a case instance
 */
class PlanItemHistory {
    /**
     *
     * @param id Plan item id
     * @param sequenceNr The occurence within the history list (0 was first change, then 1, etc.)
     * @param name Plan item name
     * @param eventType A string with the java class name of the event that caused this plan item history record
     * @param stageId Id of the stage to which this plan item belongs, or empty if it is the CasePlan itself.
     * @param type Type of plan item. E.g. HumanTask, Milestone, Stage, TimerEvent, UserEvent, ProcessTask, CaseTask, CasePlan.
     * @param currentState Current state of plan item. E.g. Available, Active, Completed, Terminated, Suspended, Failed
     * @param historyState Previous state of the plan item
     * @param transition Transition through which the plan item reached current state. E.g., create, start, complete, fault, exit, etc.
     * @param isRequired Indicates whether this plan item is required in order for it's parent stage to be able to complete
     * @param isRepeating Indicates whether a new instance of this plan item must be created when this one completes or terminates.
     * @param index If a plan item repeats, index gives the instance version, starting off 0
     * @param lastModified Timestamp when the plan item was last modified
     * @param modifiedBy Id of user that caused last modification on the plan item.
     */
    constructor(id, sequenceNr, name, stageId, type, currentState, historyState, transition, isRequired, isRepeating, index, eventType, lastModified, modifiedBy) {
        this.id = id;
        this.sequenceNr = sequenceNr;
        this.name = name;
        this.stageId = stageId;
        this.type = type;
        this.currentState = currentState;
        this.historyState = historyState;
        this.transition = transition;
        this.isRequired = isRequired;
        this.isRepeating = isRepeating;
        this.index = index;
        this.eventType = eventType;
        this.lastModified = lastModified;
        this.modifiedBy = modifiedBy;
    }
    toString() {
        return JSON.stringify(this, undefined, 2);
    }
}
exports.default = PlanItemHistory;
