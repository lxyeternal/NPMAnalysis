"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cmmnbaseclass_1 = __importDefault(require("./cmmnbaseclass"));
/**
 * Wrapper for json response of Cafienne Service for a single case instance.
 */
class Case extends cmmnbaseclass_1.default {
    /**
     *
     * @param id ID of the case
     * @param tenant Tenant in which the case resides
     * @param caseName Name of the case (taken from the definition)
     * @param state State of the case (taken from case plan)
     * @param failures Number of failures (plan items in state Failed) in this case
     * @param parentCaseId Id of parent case; is null or empty if there is no parent case
     * @param rootCaseId Id of the top most ancestor case. Is equal to the case id if there is no parent case
     * @param createdOn Timestamp of case creation
     * @param createdBy Id of user that created the case
     * @param lastModified Timestamp of last modification to the case
     * @param modifiedBy Id of user that last modified the case
     * @param team Array of members that form the case team
     * @param planitems List of all planitems created (or planned) inside the case
     * @param file JSON structor of the case file
     */
    constructor(id, tenant, caseName, state, failures, parentCaseId, rootCaseId, createdOn, createdBy, lastModified, modifiedBy, 
    // Apparently input and output parameters of a case are not stored yet?!
    // public inputs: object,
    // public outputs: object,
    team, planitems, file) {
        super();
        this.id = id;
        this.tenant = tenant;
        this.caseName = caseName;
        this.state = state;
        this.failures = failures;
        this.parentCaseId = parentCaseId;
        this.rootCaseId = rootCaseId;
        this.createdOn = createdOn;
        this.createdBy = createdBy;
        this.lastModified = lastModified;
        this.modifiedBy = modifiedBy;
        this.team = team;
        this.planitems = planitems;
        this.file = file;
    }
    toString() {
        return this.id;
    }
}
exports.default = Case;
