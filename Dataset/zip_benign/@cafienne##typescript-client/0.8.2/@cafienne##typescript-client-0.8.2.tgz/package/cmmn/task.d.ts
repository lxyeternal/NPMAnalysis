import CMMNBaseClass from "./cmmnbaseclass";
export default class Task extends CMMNBaseClass {
    id: string;
    taskName: string;
    taskState: string;
    assignee: string;
    owner: string;
    caseInstanceId: string;
    tenant: string;
    role: string;
    lastModified: string;
    modifiedBy: string;
    dueDate: string;
    createdOn: string;
    createdBy: string;
    input: any;
    output: any;
    taskModel: any;
    constructor(id: string, taskName: string, taskState: string, assignee: string, owner: string, caseInstanceId: string, tenant: string, role: string, lastModified: string, modifiedBy: string, dueDate: string, createdOn: string, createdBy: string, input: any, output: any, taskModel: any);
    toString(): string;
    summary(): string;
    isCompleted(): boolean;
    isAssigned(): boolean;
    isActive(): boolean;
    /**
     * Returns true for Delegated, Unassigned and Assigned tasks.
     */
    static isActive(task: Task): boolean;
}
