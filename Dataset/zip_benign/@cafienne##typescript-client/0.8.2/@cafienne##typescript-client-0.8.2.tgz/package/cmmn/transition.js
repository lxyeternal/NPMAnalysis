"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Fixed list of all possible transitions that can be invoked on a plan item.
 */
class Transition {
    constructor(value) {
        this.value = value;
    }
    static of(value) {
        if (value instanceof Transition)
            return value;
        for (const transition of Transition.transitions) {
            if (transition.value.toLowerCase() === value.toLowerCase()) {
                return transition;
            }
        }
        throw new Error(`${value} is not a valid State`);
    }
    is(other) {
        if (!other)
            return false;
        return this.value.toLowerCase() === other.toString().toLowerCase();
    }
    toString() {
        return this.value;
    }
}
exports.default = Transition;
Transition.Close = new Transition('close');
Transition.Complete = new Transition('complete');
Transition.Create = new Transition('create');
Transition.Disable = new Transition('disable');
Transition.Enable = new Transition('enable');
Transition.Exit = new Transition('exit');
Transition.Fault = new Transition('fault');
Transition.ManualStart = new Transition('manualStart');
Transition.None = new Transition('');
Transition.Occur = new Transition('occur');
Transition.ParentResume = new Transition('parentResume');
Transition.ParentSuspend = new Transition('parentSuspend');
Transition.ParentTerminate = new Transition('parentTerminate');
Transition.Reactivate = new Transition('reactivate');
Transition.Reenable = new Transition('reenable');
Transition.Resume = new Transition('resume');
Transition.Start = new Transition('start');
Transition.Suspend = new Transition('suspend');
Transition.Terminate = new Transition('terminate');
Transition.transitions = [Transition.Close, Transition.Complete, Transition.Create, Transition.Disable, Transition.Enable, Transition.Exit, Transition.Fault, Transition.ManualStart, Transition.None, Transition.Occur, Transition.ParentResume, Transition.ParentSuspend, Transition.ParentTerminate, Transition.Reactivate, Transition.Reenable, Transition.Resume, Transition.Start, Transition.Suspend, Transition.Terminate];
