"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const cmmnbaseclass_1 = __importDefault(require("./cmmnbaseclass"));
/**
 * JSON Wrapper for case file item documentation in a case instance
 */
class CaseFileItemDocumentation extends cmmnbaseclass_1.default {
    /**
     *
     * @param path Plan item id
     * @param documentation Plan item name
     */
    constructor(path, documentation) {
        super();
        this.path = path;
        this.documentation = documentation;
    }
}
exports.default = CaseFileItemDocumentation;
