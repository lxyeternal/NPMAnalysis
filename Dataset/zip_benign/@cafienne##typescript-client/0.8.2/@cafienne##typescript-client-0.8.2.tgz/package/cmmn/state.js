"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Base class to expose possible states of plan items and case file items.
 */
class State {
    constructor(value) {
        this.value = value;
    }
    static of(value) {
        if (value instanceof State)
            return value;
        for (const state of State.states) {
            if (state.value.toLowerCase() === value.toLowerCase()) {
                return state;
            }
        }
        throw new Error(`${value} is not a valid State`);
    }
    is(other) {
        if (!other)
            return false;
        return this.value.toLowerCase() === other.toString().toLowerCase();
    }
    toString() {
        return this.value;
    }
}
exports.default = State;
State.Null = new State('Null');
State.Active = new State('Active');
State.Available = new State('Available');
State.Closed = new State('Closed');
State.Completed = new State('Completed');
State.Disabled = new State('Disabled');
State.Discarded = new State('Discarded'); // Special case for case file item
State.Enabled = new State('Enabled');
State.Failed = new State('Failed');
State.Suspended = new State('Suspended');
State.Terminated = new State('Terminated');
State.states = [State.Null, State.Active, State.Available, State.Closed, State.Completed, State.Disabled, State.Discarded, State.Enabled, State.Failed, State.Suspended, State.Terminated];
