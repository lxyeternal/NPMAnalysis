/**
* Simple helper method to wait some time.
* @param millis Number of milliseconds to wait
* @param msg Optional message shown in debug information
*/
export declare function SomeTime(millis: number, msg?: string): Promise<void>;
/**
 * Await server side processing of commands. Takes the default option time from the Config setting Config.CafienneService.cqrsWaitTime.
 * @param millis
 * @param msg
 */
export declare function ServerSideProcessing(msg?: string): Promise<void>;
/**
 * Run the action more than once until a success comes
 * @param action
 * @param msg
 * @param timeout
 * @param interval
 * @param backoffFactor
 * @returns
 */
export declare function PollUntilSuccess(action: any, msg?: string, timeout?: number, interval?: number, backoffFactor?: number): Promise<any>;
