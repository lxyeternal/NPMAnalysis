import Case from "../cmmn/case";
import PlanItem from "../cmmn/planitem";
import State from "../cmmn/state";
import User from "../user";
export declare class ActorIdentifier {
    user: User;
    type: string;
    parentCase?: CaseHierarchy | undefined;
    events: Array<any>;
    id: string;
    name: string;
    state: State;
    constructor(user: User, item: PlanItem, type?: string, parentCase?: CaseHierarchy | undefined);
    mustBeArchived(user?: User): Promise<void>;
    assertArchived(): Promise<any>;
    protected hasArchiveEvent(archiveEventName: string): boolean;
    isArchived(): boolean;
    loadEvents(user?: User): Promise<void>;
    print(indent: string): string;
    description(indent: string): string;
    printEvents(indent: string): string;
    get totalEventCount(): number;
}
export declare class ProcessIdentifier extends ActorIdentifier {
    parentCase: CaseHierarchy;
    constructor(item: PlanItem, parentCase: CaseHierarchy);
    isArchived(): boolean;
    assertState(state: State): Promise<PlanItem>;
}
/**
 * CaseHierarchy enables building a hierarchy of a case with it's CaseTasks and ProcessTasks.
 */
export default class CaseHierarchy extends ActorIdentifier {
    user: User;
    parentCase?: CaseHierarchy | undefined;
    static from(user: User, caseInstance: Case): CaseHierarchy;
    cases: Array<CaseHierarchy>;
    processes: Array<ProcessIdentifier>;
    private constructor();
    load(): Promise<void>;
    addCase(subCase: PlanItem): CaseHierarchy;
    findItem(name: string, type?: string): ActorIdentifier | undefined;
    findProcessTask(name: string): ProcessIdentifier | undefined;
    private collect;
    print(indent?: string): string;
    printEvents(indent?: string): string;
    loadEventHierarchy(): Promise<void>;
    get totalEventCount(): number;
    hasArchivedHierarchy(): boolean;
    isArchived(): boolean;
    assertRestored(): Promise<any>;
    toString(): string;
}
