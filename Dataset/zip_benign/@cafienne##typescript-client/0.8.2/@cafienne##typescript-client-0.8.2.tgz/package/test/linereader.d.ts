/**
 * Simplistic utility to read a line from console.
 *
 */
export default class LineReader {
    enabled: boolean;
    question(msg: string, enabled?: boolean): string;
}
