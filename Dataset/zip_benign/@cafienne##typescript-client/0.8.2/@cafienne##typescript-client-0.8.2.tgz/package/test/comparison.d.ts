export default class Comparison {
    /**
     * Compare the stringified JSON version of both objects and return true if they are the same.
     * @param obj1
     * @param obj2
     */
    static sameJSON(obj1: any, obj2: any, withLogging?: boolean): boolean;
    /**
     * Compare two XML trees to see if they are the same or not
     * @param tree1
     * @param tree2
     */
    static sameXML(tree1: Node, tree2: Node): boolean;
    /**
     * Checks whether the arrays have equal content.
     * Based on == comparison of array elements.
     * @param array1
     * @param array2
     */
    static sameArray(array1?: Array<any>, array2?: Array<any>): boolean;
}
