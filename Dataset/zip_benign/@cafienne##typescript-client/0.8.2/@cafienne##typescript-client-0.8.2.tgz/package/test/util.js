"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Few simple util functions
 */
class Util {
    /**
     * Simple deep-cloner for an object
     * @param object
     */
    static clone(object) {
        return JSON.parse(JSON.stringify(object));
    }
    /**
     * Generate a random id
     * @returns
     */
    static get randomString() {
        return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    }
    /**
     * Generate a random id, with a optional prefix and postfix
     * @param prefix
     * @param postfix
     * @returns
     */
    static generateString(prefix = '', postfix = '') {
        return prefix + Util.randomString + postfix;
    }
}
exports.default = Util;
