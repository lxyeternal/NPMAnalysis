"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PollUntilSuccess = exports.ServerSideProcessing = exports.SomeTime = void 0;
const config_1 = __importDefault(require("../config"));
const logger_1 = __importDefault(require("../logger"));
const poll_until_promise_1 = require("poll-until-promise");
/**
* Simple helper method to wait some time.
* @param millis Number of milliseconds to wait
* @param msg Optional message shown in debug information
*/
function SomeTime(millis, msg = `Waiting ${millis} milliseconds`) {
    return __awaiter(this, void 0, void 0, function* () {
        yield new Promise(resolve => {
            if (config_1.default.TestCase.log) {
                logger_1.default.debug(msg);
            }
            setTimeout(resolve, millis);
        });
    });
}
exports.SomeTime = SomeTime;
/**
 * Await server side processing of commands. Takes the default option time from the Config setting Config.CafienneService.cqrsWaitTime.
 * @param millis
 * @param msg
 */
function ServerSideProcessing(msg = `Awaiting async server processing for ${config_1.default.CafienneService.cqrsWaitTime} milliseconds`) {
    return __awaiter(this, void 0, void 0, function* () {
        yield SomeTime(config_1.default.CafienneService.cqrsWaitTime, msg);
    });
}
exports.ServerSideProcessing = ServerSideProcessing;
/**
 * Run the action more than once until a success comes
 * @param action
 * @param msg
 * @param timeout
 * @param interval
 * @param backoffFactor
 * @returns
 */
function PollUntilSuccess(action, msg, timeout = config_1.default.TestCase.polltimeout, interval = 500, backoffFactor = 1.5) {
    return __awaiter(this, void 0, void 0, function* () {
        const message = msg ? msg : `Failed after retrying for ${timeout} ms`;
        return yield new poll_until_promise_1.PollUntil({ interval, timeout, backoffFactor, message }).execute(action);
    });
}
exports.PollUntilSuccess = PollUntilSuccess;
