"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const linereader_1 = __importDefault(require("./linereader"));
/**
 * Extremely simple generic TestCase class.
 */
class TestCase {
    /**
     * Create a new TestCase with the given name.
     * The name can be used for logging purposes.
     */
    constructor() {
        this.reader = new linereader_1.default();
        /**
         * Enable or disable line reading in this test case
         */
        this.lineReaderEnabled = false;
        this.name = this.constructor.name;
        this.isDefaultTest = true;
        /**
         * Identifiers will be printed in the test summary if any.
         * They can be string, or be an object that has an id field (returned from the toString() method)
         */
        this.identifiers = [];
    }
    /**
     * Add an identifier for the test results summary.
     */
    addIdentifier(identifier) {
        this.identifiers.push(identifier);
    }
    /**
     * Hook that can be implemented to setup information inside the TestCase before the run method is being invoked.
     */
    onPrepareTest() {
        return __awaiter(this, void 0, void 0, function* () {
        });
    }
    /**
     * Run method must be implemented inside the test case
     */
    run() {
        return __awaiter(this, void 0, void 0, function* () {
            throw new Error('The method run must be implemented in class ' + this.constructor.name);
        });
    }
    /**
     * Hook that can be implemented to cleanup information after the run method has been invoked.
     */
    onCloseTest() {
        return __awaiter(this, void 0, void 0, function* () {
        });
    }
    /**
     * Simplistic mechanism to enable manual breakpoints and user inputs while running tests
     * @param question String to be printed on console
     * @returns
     */
    readLine(question = 'Press enter to continue') {
        return this.reader.question(question, this.lineReaderEnabled);
    }
}
exports.default = TestCase;
