/**
 * Few simple util functions
 */
export default class Util {
    /**
     * Simple deep-cloner for an object
     * @param object
     */
    static clone(object: any): any;
    /**
     * Generate a random id
     * @returns
     */
    static get randomString(): string;
    /**
     * Generate a random id, with a optional prefix and postfix
     * @param prefix
     * @param postfix
     * @returns
     */
    static generateString(prefix?: string, postfix?: string): string;
}
