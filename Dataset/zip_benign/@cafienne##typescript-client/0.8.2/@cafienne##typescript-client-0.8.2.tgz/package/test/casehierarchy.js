"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProcessIdentifier = exports.ActorIdentifier = void 0;
const planitem_1 = __importDefault(require("../cmmn/planitem"));
const state_1 = __importDefault(require("../cmmn/state"));
const caseservice_1 = __importDefault(require("../service/case/caseservice"));
const debugservice_1 = __importDefault(require("../service/case/debugservice"));
const plan_1 = require("./caseassertions/plan");
const time_1 = require("./time");
class ActorIdentifier {
    constructor(user, item, type = item.type, parentCase) {
        this.user = user;
        this.type = type;
        this.parentCase = parentCase;
        this.events = [];
        this.id = item.id;
        this.name = item.name;
        this.state = state_1.default.of(item.currentState);
    }
    mustBeArchived(user = this.user) {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.loadEvents(user);
            if (!this.isArchived()) {
                console.log("Found unexpected events: " + JSON.stringify(this.events, undefined, 2));
                throw new Error(`${this.type} ${this.id} is not found in archived state`);
            }
        });
    }
    assertArchived() {
        return __awaiter(this, void 0, void 0, function* () {
            return yield time_1.PollUntilSuccess(() => __awaiter(this, void 0, void 0, function* () {
                console.log("Checking that we're archived ...");
                yield this.mustBeArchived();
            }));
        });
    }
    hasArchiveEvent(archiveEventName) {
        // Note: a sub case or sub process is archived when it is active.
        //  If it was in Available state, then there was no need to archive it, 
        //  and then there will not be any events (i.e. events.length === 0)
        if (this.events.length === 0) {
            return true;
        }
        else if (this.events.length === 1 && this.events[0].type === archiveEventName) {
            //  If archived, then there must be exactly one event, with the given event name.
            return true;
        }
        else {
            // So, it is not (yet?) archived ...
            return false;
        }
    }
    isArchived() {
        throw new Error(`This method must be implemented in ${this.constructor.name}`);
    }
    loadEvents(user = this.user) {
        return __awaiter(this, void 0, void 0, function* () {
            const response = yield debugservice_1.default.getEvents(this.id, user).then(data => data.asJSON());
            if (!response.body) {
                console.log('Expected a response with a body, but received something else', response);
                throw new Error('Expected a response with a body, but received something else');
            }
            this.events = [];
            this.events.push(...response.body);
        });
    }
    print(indent) {
        return this.description(indent);
    }
    description(indent) {
        if (this.parentCase) {
            return `${indent} - ${this.type}['${this.name}' - ${this.state}] - ${this.id}`;
        }
        else {
            return `${this.type}['${this.name}' - ${this.state}] - ${this.id}`;
        }
    }
    printEvents(indent) {
        const eventDescriber = (event) => `${event.type}`;
        const list = () => {
            if (this.events.length === 1) {
                return eventDescriber(this.events[0]);
            }
            else if (this.events.length) {
                return this.events.map(eventDescriber).join(', ');
            }
            else {
                return '';
            }
        };
        return `${this.description(indent)}\n${indent}   events: [${list()}]`;
    }
    get totalEventCount() {
        return this.events.length;
    }
}
exports.ActorIdentifier = ActorIdentifier;
class ProcessIdentifier extends ActorIdentifier {
    constructor(item, parentCase) {
        super(parentCase.user, item, 'Process', parentCase);
        this.parentCase = parentCase;
    }
    isArchived() {
        return this.hasArchiveEvent('ProcessArchived');
    }
    assertState(state) {
        return __awaiter(this, void 0, void 0, function* () {
            return plan_1.assertPlanItem(this.user, this.parentCase.id, this.id, undefined, state);
        });
    }
}
exports.ProcessIdentifier = ProcessIdentifier;
/**
 * CaseHierarchy enables building a hierarchy of a case with it's CaseTasks and ProcessTasks.
 */
class CaseHierarchy extends ActorIdentifier {
    constructor(user, item, parentCase) {
        super(user, item, 'Case', parentCase);
        this.user = user;
        this.parentCase = parentCase;
        this.cases = [];
        this.processes = [];
    }
    static from(user, caseInstance) {
        const fakedItem = new planitem_1.default(caseInstance.id, caseInstance.caseName, '', 'CaseTask', caseInstance.state, '', '', false, false, 0, caseInstance.lastModified, caseInstance.createdBy);
        return new CaseHierarchy(user, fakedItem);
    }
    load() {
        return __awaiter(this, void 0, void 0, function* () {
            // reset state of children.
            this.cases = [];
            this.processes = [];
            if (this.state.is(state_1.default.Available)) {
                return; // no need to load more details, as the plan item is not yet active
            }
            const caseInstance = yield plan_1.assertCasePlan(this.user, this.id, this.state);
            // Add sub cases
            const caseTasks = caseInstance.planitems.filter(item => item.type === 'CaseTask');
            for (const subCase of caseTasks) {
                yield this.addCase(subCase).load();
            }
            // Now add process tasks to the list
            caseInstance.planitems.filter(item => item.type === 'ProcessTask').map(item => this.processes.push(new ProcessIdentifier(item, this)));
        });
    }
    addCase(subCase) {
        const subCaseHierarchy = new CaseHierarchy(this.user, subCase, this);
        this.cases.push(subCaseHierarchy);
        return subCaseHierarchy;
    }
    findItem(name, type) {
        const matches = (task) => task.name === name && (!type || task.type === type);
        // Check if we ourselves match.
        if (matches(this))
            return this;
        // Check if one of our process tasks matches
        const processTask = this.processes.find(matches);
        if (processTask)
            return processTask;
        // Search the item in our sub cases
        for (const subCase of this.cases) {
            const task = subCase.findItem(name, type);
            if (task)
                return task;
        }
    }
    findProcessTask(name) {
        const task = this.findItem(name, 'Process');
        console.log("Foudn task named " + name + ": " + (task === null || task === void 0 ? void 0 : task.constructor.name));
        if (task && task instanceof ProcessIdentifier)
            return task;
        return undefined;
    }
    collect(collector) {
        const list = [];
        list.push(...this.cases.map(collector));
        list.push(...this.processes.map(collector));
        return list;
    }
    print(indent = '') {
        const list = this.collect(c => c.print(indent + ' '));
        return `${super.print(indent)}${list.length ? '\n' + list.join('\n') : ''}`;
    }
    printEvents(indent = '') {
        const list = this.collect(c => c.printEvents(indent + ' '));
        return `${super.printEvents(indent)}${list.length ? `\n${list.join('\n')}` : ''}`;
    }
    loadEventHierarchy() {
        const _super = Object.create(null, {
            loadEvents: { get: () => super.loadEvents }
        });
        return __awaiter(this, void 0, void 0, function* () {
            yield _super.loadEvents.call(this);
            for (const subCase of this.cases) {
                yield subCase.loadEventHierarchy();
            }
            for (const subProcess of this.processes) {
                yield subProcess.loadEvents();
            }
        });
    }
    get totalEventCount() {
        return super.totalEventCount + this.collect(t => t.totalEventCount).reduce((sum, count) => sum + count, 0);
    }
    hasArchivedHierarchy() {
        if (!this.isArchived()) {
            return false;
        }
        if (this.cases.find(c => !c.hasArchivedHierarchy()))
            return false;
        return this.processes.find(p => !p.isArchived()) === undefined;
    }
    isArchived() {
        return this.hasArchiveEvent('CaseArchived');
    }
    assertRestored() {
        return __awaiter(this, void 0, void 0, function* () {
            return yield time_1.PollUntilSuccess(() => __awaiter(this, void 0, void 0, function* () {
                console.log("Checking that we're restored ...");
                yield caseservice_1.default.getDiscretionaryItems(this.user, this.id);
            }));
        });
    }
    toString() {
        return this.print('');
    }
}
exports.default = CaseHierarchy;
