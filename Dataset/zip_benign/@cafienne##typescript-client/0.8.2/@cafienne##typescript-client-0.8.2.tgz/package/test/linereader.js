"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const readline_sync_1 = __importDefault(require("readline-sync"));
/**
 * Simplistic utility to read a line from console.
 *
 */
class LineReader {
    constructor() {
        this.enabled = false;
    }
    question(msg, enabled = this.enabled) {
        return enabled ? readline_sync_1.default.question(msg) : '';
    }
}
exports.default = LineReader;
