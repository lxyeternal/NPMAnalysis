import ConsentGroup from "../../service/consentgroup/consentgroup";
import User from "../../user";
export default function assertSameGroup(user: User, expectedGroup: ConsentGroup): Promise<void>;
export declare function assertMemberRole(user: User, group: ConsentGroup, member: User | string, expectedRole: string): Promise<void>;
export declare function assertMemberHasNoRoles(user: User, group: ConsentGroup, member: User | string): Promise<void>;
