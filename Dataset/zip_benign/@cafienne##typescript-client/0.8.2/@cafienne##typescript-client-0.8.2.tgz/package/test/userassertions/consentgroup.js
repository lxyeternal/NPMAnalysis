"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertMemberHasNoRoles = exports.assertMemberRole = void 0;
const consentgroupservice_1 = __importDefault(require("../../service/consentgroup/consentgroupservice"));
const comparison_1 = __importDefault(require("../comparison"));
function assertSameGroup(user, expectedGroup) {
    return __awaiter(this, void 0, void 0, function* () {
        const actualGroup = yield consentgroupservice_1.default.getGroup(user, expectedGroup);
        if (!actualGroup) {
            throw new Error(`Cannot find a consent group ${expectedGroup}`);
        }
        sameProperty(expectedGroup, actualGroup, 'name');
        sameProperty(expectedGroup, actualGroup, 'description');
        const expectedUserIds = expectedGroup.members.map(m => m.userId);
        const actualUserIds = actualGroup.members.map(m => m.userId);
        const missingUserIds = expectedUserIds.filter(expectedUserId => !actualUserIds.find(id => id === expectedUserId));
        const tooManyUserIds = actualUserIds.filter(actualUserId => !expectedUserIds.find(id => id === actualUserId));
        if (missingUserIds.length > 0 || tooManyUserIds.length > 0) {
            const msg1 = missingUserIds.length > 0 ? 'Missing user ids: ' + missingUserIds.join(',') : '';
            const msg2 = missingUserIds.length > 0 ? 'Unexpected user ids: ' + tooManyUserIds.join(',') : '';
            throw new Error(`Consent group members mismatch:\n\t${msg1}\n\t${msg2}`);
        }
        expectedGroup.members.forEach(expectedMember => {
            const actualMember = actualGroup.members.find(member => member.userId === expectedMember.userId);
            if (!actualMember) {
                throw new Error(`Surprisingly we cannot find member ${expectedMember.userId} in the actual consent group`);
            }
            sameProperty(expectedMember, actualMember, 'isOwner');
            comparison_1.default.sameArray(expectedMember.roles, actualMember.roles);
        });
    });
}
exports.default = assertSameGroup;
function assertMemberRole(user, group, member, expectedRole) {
    return __awaiter(this, void 0, void 0, function* () {
        return consentgroupservice_1.default.getGroupMember(user, group, member).then(actualMember => {
            if (!actualMember.roles.find(r => r === expectedRole)) {
                throw new Error(`Expected to find role '${expectedRole}' in member ${member}, but found roles [${actualMember.roles.join(',')}]`);
            }
        });
    });
}
exports.assertMemberRole = assertMemberRole;
function assertMemberHasNoRoles(user, group, member) {
    return __awaiter(this, void 0, void 0, function* () {
        return consentgroupservice_1.default.getGroupMember(user, group, member).then(actualMember => {
            if (actualMember.roles.length > 0) {
                throw new Error(`Expected member ${member} in group ${group} to have no roles, but found roles [${actualMember.roles.join(',')}]`);
            }
        });
    });
}
exports.assertMemberHasNoRoles = assertMemberHasNoRoles;
function sameProperty(expected, actual, propertyName) {
    if (expected[propertyName] !== actual[propertyName]) {
        throw new Error(`Expected ${expected.constructor.name} ${expected} to have ${propertyName} '${expected[propertyName]}' but found '${actual[propertyName]}'`);
    }
}
