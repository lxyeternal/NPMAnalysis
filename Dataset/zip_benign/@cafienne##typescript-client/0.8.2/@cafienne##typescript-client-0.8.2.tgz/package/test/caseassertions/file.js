"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const comparison_1 = __importDefault(require("../comparison"));
const casefileservice_1 = __importDefault(require("../../service/case/casefileservice"));
const casefile_1 = require("../../cmmn/casefile");
const config_1 = __importDefault(require("../../config"));
const logger_1 = __importDefault(require("../../logger"));
const time_1 = require("../time");
/**
 * Read the case instance's case file on behalf of the user and verify that the element at the end of the path matches the expectedContent.
 * Path can be something like /Greeting/
 *
 * @param caseId
 * @param user
 * @param path
 * @param expectedContent
 */
function assertCaseFileContent(user, caseId, path, expectedContent, log = false) {
    return __awaiter(this, void 0, void 0, function* () {
        yield time_1.PollUntilSuccess(function () {
            return __awaiter(this, void 0, void 0, function* () {
                yield casefileservice_1.default.getCaseFile(user, caseId).then(casefile => {
                    if (config_1.default.TestCase.log) {
                        logger_1.default.debug(`Case File for reading path ${path}:${JSON.stringify(casefile, undefined, 2)}`);
                    }
                    const readCaseFileItem = (caseFile) => {
                        const item = casefile_1.pathReader(caseFile, path);
                        if (!item && caseFile.file) { // Temporary backwards compatibility; casefile.file will be dropped in 1.1.5
                            return casefile_1.pathReader(caseFile.file, path);
                        }
                        return item;
                    };
                    const actualCaseFileItem = readCaseFileItem(casefile);
                    if (!comparison_1.default.sameJSON(actualCaseFileItem, expectedContent, log)) {
                        throw new Error(`Case File [${path}] is expected to match: ${JSON.stringify(expectedContent, undefined, 2)}\nActual: ${JSON.stringify(actualCaseFileItem, undefined, 2)}`);
                    }
                    return actualCaseFileItem;
                });
            });
        });
    });
}
exports.default = assertCaseFileContent;
