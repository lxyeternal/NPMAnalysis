"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.assertCasePlan = exports.assertPlanItem = void 0;
const caseservice_1 = __importDefault(require("../../service/case/caseservice"));
const time_1 = require("../time");
const config_1 = __importDefault(require("../../config"));
const logger_1 = __importDefault(require("../../logger"));
const state_1 = __importDefault(require("../../cmmn/state"));
/**
 * Retrieves the plan items of the case and asserts that the plan item has the expected state.
 * Optionally runs repeated loops to await the plan item to reach the expected state.
 * Handy to use for ProcessTask and CaseTasks and their potential follow-ups, as these tasks run asynchronously in the backend.
 * @param caseId
 * @param user
 * @param planItemIdentifier
 * @param planItemIndex
 * @param expectedState
 * @param maxAttempts
 * @param waitTimeBetweenAttempts
 * @returns {Promise<PlanItem>} the plan item if it is found
 * @throws {Error} if the plan item is not found after so many attempts
 */
function assertPlanItem(user, caseId, planItemIdentifier, planItemIndex = -1, expectedState) {
    return __awaiter(this, void 0, void 0, function* () {
        return yield time_1.PollUntilSuccess(() => __awaiter(this, void 0, void 0, function* () {
            const freshCase = yield caseservice_1.default.getCase(user, caseId);
            if (config_1.default.TestCase.log) {
                const longestNameLength = Math.max(...freshCase.planitems.map(item => item.name.length));
                const longestState = Math.max(...freshCase.planitems.map(item => item.currentState.length));
                logger_1.default.debug(' Current Plan Items\n' + (freshCase.planitems.map(item => ` ${item.name.padStart(longestNameLength)}.${item.index} ==> ${item.currentState.padEnd(longestState)} (id: ${item.id})`)).join('\n'));
            }
            const nameFilter = (item) => item.name === planItemIdentifier || item.id === planItemIdentifier;
            const indexFilter = (item) => planItemIndex >= 0 ? item.index === planItemIndex : true;
            const stateFilter = (item) => expectedState ? state_1.default.of(item.currentState).is(expectedState) : true;
            const matchers = freshCase.planitems.filter(item => nameFilter(item) && indexFilter(item));
            const item = matchers.find(stateFilter);
            if (item) {
                return item;
            }
            const currentMsg = !matchers.length ? 'not (yet) found in the case plan' : `in state ${matchers[matchers.length - 1].currentState}`;
            throw new Error(`Did not find the plan item '${planItemIdentifier}.${planItemIndex}' in state ${expectedState}`);
        }));
    });
}
exports.assertPlanItem = assertPlanItem;
/**
 * Asserts the state of the case plan
 * @param caseId
 * @param user
 * @param expectedState
 */
function assertCasePlan(user, caseId, expectedState) {
    return __awaiter(this, void 0, void 0, function* () {
        return yield time_1.PollUntilSuccess(() => __awaiter(this, void 0, void 0, function* () {
            const tryGetCase = () => __awaiter(this, void 0, void 0, function* () {
                try {
                    // Get case details
                    return yield caseservice_1.default.getCase(user, caseId);
                }
                catch (error) {
                    // ignore the error
                }
            });
            // Get case details
            const freshCase = yield tryGetCase();
            if (freshCase && (!expectedState || state_1.default.of(freshCase.state).is(expectedState))) {
                return freshCase;
            }
            throw new Error(`Did not find the case ${caseId} in state ${expectedState}`);
        }));
    });
}
exports.assertCasePlan = assertCasePlan;
