import Task from '../../cmmn/task';
import User from '../../user';
import TaskState from '../../cmmn/taskstate';
/**
 * Asserts that the task has expected state, assignee, and owner
 * @param task
 * @param user
 * @param action
 * @param expectedState
 * @param expectedAssignee
 * @param expectedOwner
 */
export declare function assertTask(user: User, task: Task | string, action: string, expectedState: TaskState, expectedAssignee?: User, expectedOwner?: User, expectedLastModifiedBy?: User): Promise<Task>;
/**
 * Verifies whether task's input is same as that of expected input
 * @param task
 * @param taskInput expected input
 */
export declare function verifyTaskInput(task: Task, taskInput: any): void;
/**
 * Finds and returns a particular task with in list of tasks
 * and throws an error if it does not exist
 * @param tasks
 * @param taskName
 */
export declare function findTask(tasks: Task[], taskName: string): Task;
/**
 * Asserts the number of tasks that have specified state with expected count
 * @param tasks
 * @param state
 * @param expectedCount
 */
export declare function assertTaskCount(tasks: Task[], state: string, expectedCount: Number): void;
