import User from '../../user';
import Case from '../../cmmn/case';
/**
 * Read the case instance's case file on behalf of the user and verify that the element at the end of the path matches the expectedContent.
 * Path can be something like /Greeting/
 *
 * @param caseId
 * @param user
 * @param path
 * @param expectedContent
 */
export default function assertCaseFileContent(user: User, caseId: Case | string, path: string, expectedContent: any, log?: boolean): Promise<void>;
