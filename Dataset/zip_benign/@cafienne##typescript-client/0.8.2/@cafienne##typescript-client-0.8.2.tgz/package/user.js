"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const tokenservice_1 = __importDefault(require("./service/platform/tokenservice"));
const platformservice_1 = __importDefault(require("./service/platform/platformservice"));
const config_1 = __importDefault(require("./config"));
const logger_1 = __importDefault(require("./logger"));
class User {
    /**
     *
     * @param id Id of the user, with which is must be registered within the case system
     */
    constructor(id) {
        this.id = id;
        this.token_property = '';
    }
    toString() {
        return this.id;
    }
    /**
     * Login the user in 2 steps:
     * - first fetch a token from the token service,
     * - then invoke tenant service to retrieve the user information.
     *
     * The second call fails if the user is not (yet) registered in the case system.
     */
    login() {
        return __awaiter(this, void 0, void 0, function* () {
            yield this.refreshToken();
            yield this.refreshUserInformation();
            return this;
        });
    }
    set token(newToken) {
        if (config_1.default.TokenService.log) {
            if (this.token !== newToken) {
                if (!this.token) {
                    logger_1.default.debug(`Setting token for user ${this.id} to ${newToken}`);
                }
                else {
                    logger_1.default.debug(`Updating token for user ${this.id} to ${newToken}`);
                }
            }
            else {
                logger_1.default.debug(`New token for user ${this.id} is same as before`);
            }
        }
        this.token_property = newToken;
    }
    /**
     * Current user token. Is available upon login of the user.
     */
    get token() {
        return this.token_property;
    }
    /**
     * Clear current token of user.
     */
    clearToken() {
        if (config_1.default.TokenService.log) {
            logger_1.default.debug(`Clearing token for user ${this.id}`);
        }
        this.token_property = '';
    }
    /**
     * Technical method to get/refresh a token for this user.
     */
    refreshToken() {
        return __awaiter(this, void 0, void 0, function* () {
            const newToken = yield tokenservice_1.default.getToken(this);
            this.token = newToken;
            return newToken;
        });
    }
    /**
     * Refresh the user information with latest from case engine.
     */
    refreshUserInformation() {
        return __awaiter(this, void 0, void 0, function* () {
            const user = this;
            return platformservice_1.default.getUserInformation(this).then(info => {
                user.userInformation = info;
                return info;
            });
        });
    }
}
exports.default = User;
/**
 * A user without an id, i.e. id is an empty string.
 */
User.NONE = new User('');
