const contentInfo = new SpeechSynthesisUtterance({
  lang: 'zh-cmn',
  rate: 1
})


function speakSomething(text, options = {}) {
  Object.assign(contentInfo, {
    text,
    ...options
  })

  window.speechSynthesis.cancel()
  window.speechSynthesis.speak(contentInfo)
}

module.exports = {
  speakSomething
}