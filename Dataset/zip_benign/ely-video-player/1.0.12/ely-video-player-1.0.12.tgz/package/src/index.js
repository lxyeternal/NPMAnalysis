import ElyVideoPlayer from "./components/ElyVideoPlayer";
import CustomSlider from "./components/CustomSlider";

export { CustomSlider };
export default ElyVideoPlayer;
