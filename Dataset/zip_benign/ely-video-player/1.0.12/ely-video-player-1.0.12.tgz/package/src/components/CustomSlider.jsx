import React from "react";
import {
  View,
  StyleSheet,
  Dimensions,
  TouchableWithoutFeedback,
} from "react-native";

const CustomSlider = ({
  currentTime = 0,
  duration = 0,
  onSeek = () => {},
  markers = [],
  controlsVisible = true,
  progress = 0,
  fullScreen = false,
}) => {
  const screenWidth = Dimensions.get("window").width;
  const screenHeight = Dimensions.get("window").height;

  // Calculer la largeur du slider en fonction du mode d'affichage
  const sliderWidth = fullScreen ? screenWidth * 0.8 : screenWidth;

  const handleMarkerPress = (time) => {
    if (typeof onSeek === "function") {
      onSeek(time);
    }
  };

  const handleTrackPress = (evt) => {
    if (!duration || !onSeek) return;

    const position = evt.nativeEvent.locationX;
    const newTime = (position / screenWidth) * duration;
    onSeek(newTime);
  };

  // Fonction pour générer les segments
  const renderSegments = (isMinimal = false) => {
    // Créer un tableau de segments qui inclut le début de la vidéo
    const allSegments = [
      { startTime: 0 }, // Ajouter le début de la vidéo comme premier point
      ...markers,
    ];

    return allSegments.map((marker, index) => {
      const startPosition = (marker.startTime / duration) * 100;
      const nextMarker = allSegments[index + 1];
      const endPosition = nextMarker
        ? (nextMarker.startTime / duration) * 100
        : 100;
      const width = endPosition - startPosition;

      // Calculer le pourcentage de remplissage du segment actuel
      const segmentStartTime = marker.startTime;
      const segmentEndTime = nextMarker ? nextMarker.startTime : duration;
      const segmentDuration = segmentEndTime - segmentStartTime;
      const segmentProgress = Math.max(
        0,
        Math.min(currentTime - segmentStartTime, segmentDuration)
      );
      const fillPercentage = (segmentProgress / segmentDuration) * 100;

      // Déterminer si le segment est actif ou terminé
      const isActive =
        currentTime >= segmentStartTime && currentTime < segmentEndTime;
      const isCompleted = currentTime >= segmentEndTime;

      return (
        <View
          key={index}
          style={[
            isMinimal ? styles.minimalSegment : styles.segment,
            {
              left: `${startPosition}%`,
              width: `${width}%`,
              backgroundColor: "#ccc",
              overflow: "hidden",
            },
          ]}
        >
          <View
            style={[
              isMinimal ? styles.minimalFill : styles.fill,
              {
                width: isCompleted
                  ? "100%"
                  : isActive
                  ? `${fillPercentage}%`
                  : "0%",
                backgroundColor: "#f07289",
              },
            ]}
          />
        </View>
      );
    });
  };

  // Si les contrôles ne sont pas visibles, afficher une barre de progression mince
  if (!controlsVisible) {
    return (
      <View
        style={[
          styles.minimalSliderContainer,
          fullScreen && {
            width: "100%",
            position: "absolute",
          },
        ]}
      >
        <View style={styles.minimalTrack}>{renderSegments(true)}</View>
      </View>
    );
  }

  // Version complète du slider avec contrôles visibles
  return (
    <TouchableWithoutFeedback onPress={handleTrackPress}>
      <View
        style={[
          styles.sliderContainer,
          fullScreen && {
            width: "100%",
            position: "absolute",
            bottom: 5,
          },
        ]}
      >
        <View style={styles.track}>{renderSegments()}</View>
      </View>
    </TouchableWithoutFeedback>
  );
};

const styles = StyleSheet.create({
  sliderContainer: {
    width: "100%",
    height: 40,
    justifyContent: "center",
    position: "relative",
    zIndex: 1000,
  },
  track: {
    height: 10,
    width: "100%",
    position: "absolute",
    flexDirection: "row",
  },
  segment: {
    height: 10,
    position: "absolute",
    borderRadius: 5,
  },
  fill: {
    position: "absolute",
    height: "100%",
    borderRadius: 5,
  },
  // Styles pour la barre de progression minimale
  minimalSliderContainer: {
    width: "100%",
    height: "35%",
    justifyContent: "center",
    position: "relative",
    zIndex: 1000,
  },
  minimalTrack: {
    height: 5,
    width: "100%",
    position: "absolute",
    flexDirection: "row",
  },
  minimalSegment: {
    height: 5,
    position: "absolute",
    borderRadius: 2.5,
  },
  minimalFill: {
    position: "absolute",
    height: "100%",
    borderRadius: 2.5,
  },
});

export default CustomSlider;
