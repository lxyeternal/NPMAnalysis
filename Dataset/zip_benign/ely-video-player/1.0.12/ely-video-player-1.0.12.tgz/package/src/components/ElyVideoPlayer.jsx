import React, {
  useEffect,
  useCallback,
  forwardRef,
  useState,
  useRef,
} from "react";
import {
  Animated,
  Easing,
  Text,
  View,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
  Pressable,
  Platform,
  AppState,
  Modal,
} from "react-native";
import Video from "react-native-video";
import Orientation from "react-native-orientation-locker";
import { FontAwesomeIcon } from "@fortawesome/react-native-fontawesome";
import {
  faChevronLeft,
  faPlay,
  faPause,
  faExpand,
  faCompress,
  faCog,
  faBackward,
  faForward,
  faVolumeUp,
  faVolumeMute,
  faTimes,
} from "@fortawesome/free-solid-svg-icons";
import { formatTime } from "../utils/formatTime";
import { convertTimeToSeconds } from "../utils/convertTimeToSeconds";
import CustomSlider from "./CustomSlider";

let CastButton, useRemoteMediaClient, CastContext;
try {
  const GoogleCast = require("react-native-google-cast");
  CastButton = GoogleCast.CastButton;
  useRemoteMediaClient = GoogleCast.useRemoteMediaClient;
  CastContext = GoogleCast.CastContext;
} catch (e) {
  CastButton = null;
  useRemoteMediaClient = () => null;
  CastContext = { useCastContext: () => null };
}

const screenHeight = Dimensions.get("window").height;
const screenWidth = Dimensions.get("window").width;

const ElyVideoPlayer = forwardRef(
  (
    {
      // Props de base
      source,
      poster,
      style,
      onProgress,
      onEnd,
      onLoad,
      onPlay,
      onPause,
      onSeek,
      onFullScreenChange,

      // Props de personnalisation
      controlsConfig = {
        showPlayPause: true,
        showFullscreen: true,
        showQuality: true,
        showCast: false,
        showBackButton: true,
        showTime: true,
        showSlider: true,
        showFastForward: true,
        showRewind: true,
      },

      // Props de style
      theme = {
        primaryColor: "#f0738a",
        backgroundColor: "rgba(0, 0, 0, 0.5)",
        controlsBackground: "rgba(255, 255, 255, 0.3)",
        textColor: "#ffffff",
      },

      // Props de configuration
      bufferConfig = {
        minBufferMs: 15000,
        maxBufferMs: 50000,
        bufferForPlaybackMs: 2500,
        bufferForPlaybackAfterRebufferMs: 5000,
      },

      // Props de fonctionnalités
      chapters = [],
      qualities = [],
      initialPosition = 0,
      autoPlay = false,
      repeat = false,
      resizeMode = "cover",
      maxBitRate = 5000000,
      progressUpdateInterval = 250,

      // Props de callback
      onChapterChange,
      onQualityChange,
      onControlsVisibilityChange,

      // Nouvelles props pour la personnalisation avancée
      gestureConfig = {
        enableDoubleTap: true,
        enableSwipe: true,
        doubleTapInterval: 800,
        swipeThreshold: 50,
      },

      // Props pour la gestion de la progression
      progressConfig = {
        saveProgress: true,
        saveInterval: 5000,
        onProgressSave: null,
      },

      // Props pour la gestion des chapitres
      chapterConfig = {
        showChapterMarkers: true,
        chapterStyle: {
          markerColor: "#f0738a",
          markerWidth: 2,
        },
      },

      // Props pour la gestion de l'état de l'application
      appStateConfig = {
        pauseOnBackground: true,
        resumeOnForeground: false,
      },

      // Nouvelle prop pour les icônes personnalisées
      icons = {
        play: faPlay,
        pause: faPause,
        fullscreen: faExpand,
        exitFullscreen: faCompress,
        settings: faCog,
        rewind: faBackward,
        forward: faForward,
        volume: faVolumeUp,
        mute: faVolumeMute,
        close: faTimes,
        back: faChevronLeft,
      },

      // Props de callback
      onBack,
    },
    ref
  ) => {
    const [fullScreen, setFullScreen] = useState(false);
    const [showPoster, setShowPoster] = useState(true);
    const [controlsVisible, setControlsVisible] = useState(true);
    const [paused, setPaused] = useState(!autoPlay);
    const [progress, setProgress] = useState({
      currentTime: 0,
      seekableDuration: 0,
    });
    const [currentQuality, setCurrentQuality] = useState("auto");
    const [rate, setRate] = useState(1.0);
    const [isRewinding, setIsRewinding] = useState(false);
    const [isForwarding, setIsForwarding] = useState(false);
    const [showQualityMenu, setShowQualityMenu] = useState(false);
    const [showCenterControls, setShowCenterControls] = useState(true);

    // Refs
    const videoRef = useRef(null);
    const positionBeforeFullScreen = useRef(null);
    const isTransitioning = useRef(false);
    const controlsTimeoutRef = useRef(null);

    // Nouveaux états pour les gestes
    const [tapCount, setTapCount] = useState(0);
    const [lastTapTime, setLastTapTime] = useState(0);
    const [tapDirection, setTapDirection] = useState(null);
    const [showTapIndicator, setShowTapIndicator] = useState(false);
    const tapTimeoutRef = useRef(null);
    const [isTapMode, setIsTapMode] = useState(false);

    // Modifier la gestion du Cast
    const client = controlsConfig.showCast ? useRemoteMediaClient?.() : null;
    const castContext = controlsConfig.showCast
      ? CastContext?.useCastContext?.()
      : null;

    // Gestion du mode plein écran
    const toggleFullScreen = useCallback(() => {
      if (isTransitioning.current) return;
      isTransitioning.current = true;

      positionBeforeFullScreen.current = progress.currentTime;

      if (Platform.OS === "ios") {
        if (fullScreen) {
          Orientation.lockToPortrait();
        } else {
          Orientation.lockToLandscape();
        }
      }

      setFullScreen(!fullScreen);
      onFullScreenChange?.(!fullScreen);

      setTimeout(() => {
        isTransitioning.current = false;
      }, 100);
    }, [fullScreen, progress.currentTime, onFullScreenChange]);

    // Gestion de la lecture/pause
    const handlePlayPauseToggle = useCallback(() => {
      const newPausedState = !paused;
      setPaused(newPausedState);
      setControlsVisible(true);

      if (showPoster) {
        setShowPoster(false);
      }

      if (!newPausedState) {
        setRate(1.0);
        setIsRewinding(false);
        setIsForwarding(false);
      }

      if (newPausedState) {
        onPause?.();
      } else {
        onPlay?.();
      }
    }, [paused, showPoster, onPlay, onPause]);

    // Gestion de la progression
    const handleProgress = useCallback(
      (data) => {
        setProgress(data);
        onProgress?.(data);
      },
      [onProgress]
    );

    // Gestion du chargement
    const handleLoad = useCallback(
      (data) => {
        const targetPosition =
          positionBeforeFullScreen.current ?? initialPosition;

        if (targetPosition > 0) {
          requestAnimationFrame(() => {
            if (videoRef?.current) {
              videoRef.current.seek(targetPosition);
              setProgress((prev) => ({
                ...prev,
                currentTime: targetPosition,
                seekableDuration: data.duration,
              }));
            }
          });
        }

        positionBeforeFullScreen.current = null;
        setShowPoster(false);
        onLoad?.(data);
      },
      [initialPosition, onLoad]
    );

    // Gestion de la visibilité des contrôles
    useEffect(() => {
      if (!paused && controlsVisible) {
        controlsTimeoutRef.current = setTimeout(() => {
          setControlsVisible(false);
          onControlsVisibilityChange?.(false);
        }, 3000);
      }
      return () => clearTimeout(controlsTimeoutRef.current);
    }, [paused, controlsVisible, onControlsVisibilityChange]);

    // Gestion des doubles-taps
    const handleDoubleTap = useCallback(
      (direction) => {
        if (!gestureConfig.enableDoubleTap || isRewinding || isForwarding)
          return;

        const now = Date.now();
        const TAP_TIMEOUT = gestureConfig.doubleTapInterval;

        if (now - lastTapTime > TAP_TIMEOUT || tapDirection !== direction) {
          setTapCount(1);
          setTapDirection(direction);
          setLastTapTime(now);
        } else {
          const newTapCount = tapCount + 1;
          setTapCount(newTapCount);

          if (newTapCount === 2) {
            setIsTapMode(true);
            setControlsVisible(false);
          }

          const baseSeconds = 10;
          const seconds = baseSeconds * (newTapCount - 1);

          if (direction === "forward") {
            const newTime = Math.min(
              progress.currentTime + seconds,
              progress.seekableDuration
            );
            videoRef.current?.seek(newTime);
            setProgress((prev) => ({ ...prev, currentTime: newTime }));
          } else {
            const newTime = Math.max(progress.currentTime - seconds, 0);
            videoRef.current?.seek(newTime);
            setProgress((prev) => ({ ...prev, currentTime: newTime }));
          }

          setShowTapIndicator(true);
          clearTimeout(tapTimeoutRef.current);
          tapTimeoutRef.current = setTimeout(() => {
            setShowTapIndicator(false);
            setIsTapMode(false);
          }, 800);
        }
      },
      [
        gestureConfig.enableDoubleTap,
        isRewinding,
        isForwarding,
        lastTapTime,
        tapDirection,
        tapCount,
        progress,
      ]
    );

    // Gestion de l'état de l'application
    useEffect(() => {
      const subscription = AppState.addEventListener(
        "change",
        (nextAppState) => {
          if (
            appState.current.match(/active/) &&
            nextAppState.match(/inactive|background/)
          ) {
            if (appStateConfig.pauseOnBackground) {
              setPaused(true);
              onPause?.();
            }
          } else if (
            appState.current.match(/inactive|background/) &&
            nextAppState === "active"
          ) {
            if (appStateConfig.resumeOnForeground) {
              setPaused(false);
              onPlay?.();
            }
          }
          appState.current = nextAppState;
        }
      );

      return () => {
        subscription.remove();
      };
    }, [
      appStateConfig.pauseOnBackground,
      appStateConfig.resumeOnForeground,
      onPlay,
      onPause,
    ]);

    // Sauvegarde de la progression
    useEffect(() => {
      if (!progressConfig.saveProgress) return;

      const saveInterval = setInterval(() => {
        if (progress.currentTime > 0) {
          progressConfig.onProgressSave?.({
            currentTime: progress.currentTime,
            duration: progress.seekableDuration,
            progress: (progress.currentTime / progress.seekableDuration) * 100,
          });
        }
      }, progressConfig.saveInterval);

      return () => clearInterval(saveInterval);
    }, [
      progressConfig.saveProgress,
      progressConfig.saveInterval,
      progressConfig.onProgressSave,
      progress,
    ]);

    // Rendu des contrôles
    const renderControls = () => {
      if (!controlsVisible) return null;

      return (
        <View
          style={[styles.controls, { backgroundColor: theme.backgroundColor }]}
        >
          {/* Top Controls */}
          <View style={styles.topControls}>
            {controlsConfig.showBackButton && (
              <TouchableOpacity
                style={styles.backButton}
                onPress={() => onBack?.()}
              >
                <FontAwesomeIcon
                  icon={icons.back}
                  size={24}
                  color={theme.textColor}
                />
              </TouchableOpacity>
            )}
            {controlsConfig.showCast && CastButton && (
              <CastButton style={styles.castButton} color={theme.textColor} />
            )}
          </View>

          {/* Center Controls */}
          <View style={styles.centerControls}>
            {controlsConfig.showRewind && (
              <TouchableOpacity
                style={styles.controlButton}
                onPress={() =>
                  videoRef.current?.seek(progress.currentTime - 10)
                }
              >
                <FontAwesomeIcon
                  icon={icons.rewind}
                  size={24}
                  color={theme.textColor}
                />
              </TouchableOpacity>
            )}

            {controlsConfig.showPlayPause && (
              <TouchableOpacity
                style={styles.playPauseButton}
                onPress={handlePlayPauseToggle}
              >
                <FontAwesomeIcon
                  icon={paused ? icons.play : icons.pause}
                  size={32}
                  color={theme.textColor}
                />
              </TouchableOpacity>
            )}

            {controlsConfig.showFastForward && (
              <TouchableOpacity
                style={styles.controlButton}
                onPress={() =>
                  videoRef.current?.seek(progress.currentTime + 10)
                }
              >
                <FontAwesomeIcon
                  icon={icons.forward}
                  size={24}
                  color={theme.textColor}
                />
              </TouchableOpacity>
            )}
          </View>

          {/* Bottom Controls */}
          <View style={styles.bottomControls}>
            {controlsConfig.showTime && (
              <Text style={[styles.timeText, { color: theme.textColor }]}>
                {formatTime(progress.currentTime)} /{" "}
                {formatTime(progress.seekableDuration)}
              </Text>
            )}

            {controlsConfig.showQuality && (
              <TouchableOpacity
                style={styles.settingsButton}
                onPress={() => setShowQualityMenu(true)}
              >
                <FontAwesomeIcon
                  icon={icons.settings}
                  size={20}
                  color={theme.textColor}
                />
              </TouchableOpacity>
            )}

            {controlsConfig.showFullscreen && (
              <TouchableOpacity
                style={styles.fullscreenButton}
                onPress={toggleFullScreen}
              >
                <FontAwesomeIcon
                  icon={fullScreen ? icons.exitFullscreen : icons.fullscreen}
                  size={20}
                  color={theme.textColor}
                />
              </TouchableOpacity>
            )}
          </View>

          {controlsConfig.showSlider && (
            <CustomSlider
              value={progress.currentTime}
              maximumValue={progress.seekableDuration}
              onValueChange={(value) => {
                // Implement the logic to handle slider value change
              }}
              onSlidingComplete={onSeek}
              minimumTrackTintColor={theme.primaryColor}
              maximumTrackTintColor={theme.controlsBackground}
              thumbTintColor={theme.primaryColor}
            />
          )}
        </View>
      );
    };

    // Rendu du menu de qualité
    const renderQualityMenu = () => {
      if (!showQualityMenu) return null;

      return (
        <View
          style={[
            styles.qualityMenu,
            { backgroundColor: theme.controlsBackground },
          ]}
        >
          <Text style={[styles.qualityTitle, { color: theme.primaryColor }]}>
            Qualité
          </Text>
          {qualities.map((quality) => (
            <TouchableOpacity
              key={quality.value}
              style={[
                styles.qualityOption,
                currentQuality === quality.value && {
                  backgroundColor: `${theme.primaryColor}80`,
                },
              ]}
              onPress={() => {
                setCurrentQuality(quality.value);
                setShowQualityMenu(false);
                onQualityChange?.(quality.value);
              }}
            >
              <Text style={[styles.qualityText, { color: theme.primaryColor }]}>
                {quality.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
      );
    };

    // Rendu du slider
    const renderSlider = () => {
      if (!controlsConfig.showSlider) return null;

      return (
        <CustomSlider
          currentTime={progress.currentTime}
          duration={progress.seekableDuration}
          markers={chapters.map((chapter) => ({
            startTime: convertTimeToSeconds(chapter.time_start),
          }))}
          onSeek={onSeek}
          controlsVisible={controlsVisible}
          progress={progress.currentTime / progress.seekableDuration}
          fullScreen={fullScreen}
          theme={theme}
        />
      );
    };

    // Rendu des indicateurs de tap
    const renderTapIndicator = () => {
      if (!showTapIndicator) return null;

      return (
        <View
          style={[
            styles.tapIndicator,
            tapDirection === "forward"
              ? styles.tapIndicatorRight
              : styles.tapIndicatorLeft,
          ]}
          pointerEvents="none"
        >
          <View style={styles.tapIndicatorContent}>
            <FontAwesomeIcon
              icon={tapDirection === "forward" ? icons.forward : icons.rewind}
              size={40}
              color={theme.textColor}
              style={styles.tapIndicatorIcon}
            />
            <Text
              style={[styles.tapIndicatorText, { color: theme.primaryColor }]}
            >
              {tapDirection === "forward" ? "+" : "-"}
              {10 * (tapCount - 1)}s
            </Text>
          </View>
        </View>
      );
    };

    return (
      <View style={[styles.container, style]}>
        <Pressable
          style={[
            styles.videoContainer,
            fullScreen ? styles.fullScreenContainer : styles.normalContainer,
          ]}
          onPress={() => {
            if (
              !controlsVisible &&
              !isRewinding &&
              !isForwarding &&
              !isTapMode
            ) {
              setControlsVisible(true);
              onControlsVisibilityChange?.(true);
            }
          }}
        >
          {showPoster && (
            <FontAwesomeIcon
              icon={icons.close}
              size={screenWidth * 0.8}
              color={theme.textColor}
            />
          )}

          <Video
            source={source}
            style={[
              styles.video,
              fullScreen ? styles.fullScreenVideo : styles.normalVideo,
            ]}
            resizeMode={resizeMode}
            paused={paused}
            rate={rate}
            ref={videoRef}
            onProgress={handleProgress}
            onSeek={onSeek}
            onEnd={onEnd}
            onLoad={handleLoad}
            onPlay={() => {
              setShowPoster(false);
              onPlay?.();
            }}
            onPause={onPause}
            bufferConfig={bufferConfig}
            maxBitRate={maxBitRate}
            progressUpdateInterval={progressUpdateInterval}
            repeat={repeat}
          />

          {renderControls()}
          {renderQualityMenu()}
          {renderSlider()}

          {/* Ajout des zones de tap */}
          {!paused && !showPoster && (
            <View style={styles.tapZones} pointerEvents="box-none">
              <Pressable
                style={[styles.tapZone, isTapMode && styles.invisibleTapZone]}
                onPress={() => handleDoubleTap("backward")}
              />
              <Pressable
                style={[styles.tapZone, isTapMode && styles.invisibleTapZone]}
                onPress={() => handleDoubleTap("forward")}
              />
            </View>
          )}

          {renderTapIndicator()}
        </Pressable>
      </View>
    );
  }
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "black",
  },
  videoContainer: {
    flex: 1,
    width: "100%",
    height: "100%",
    justifyContent: "center",
    alignItems: "center",
    position: "relative",
  },
  video: {
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  poster: {
    width: "100%",
    height: "100%",
    position: "absolute",
  },
  controls: {
    position: "absolute",
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "space-between",
  },
  topControls: {
    flexDirection: "row",
    alignItems: "center",
  },
  backButton: {
    padding: 10,
  },
  centerControls: {
    flexDirection: "row",
    alignItems: "center",
  },
  controlButton: {
    padding: 10,
    marginHorizontal: 5,
  },
  playPauseButton: {
    padding: 15,
    marginHorizontal: 10,
  },
  bottomControls: {
    flexDirection: "row",
    alignItems: "center",
  },
  timeText: {
    fontSize: 14,
    fontWeight: "500",
  },
  qualityMenu: {
    position: "absolute",
    right: 0,
    bottom: 80,
    padding: 15,
    borderRadius: 10,
    width: 150,
  },
  qualityTitle: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 10,
  },
  qualityOption: {
    padding: 8,
    borderRadius: 5,
  },
  qualityText: {
    fontSize: 14,
  },
  settingsButton: {
    padding: 10,
    marginLeft: 10,
  },
  fullscreenButton: {
    padding: 10,
    marginLeft: 10,
  },
  fullScreenContainer: {
    height: screenHeight,
    width: screenWidth,
  },
  fullScreenVideo: {
    height: "100%",
    width: "100%",
  },
  normalContainer: {
    height: screenHeight / 2.5,
    width: "100%",
  },
  normalVideo: {
    height: "100%",
    width: "100%",
  },
  tapZones: {
    position: "absolute",
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: "row",
    justifyContent: "space-between",
  },
  tapZone: {
    flex: 1,
    height: "100%",
  },
  invisibleTapZone: {
    backgroundColor: "transparent",
  },
  tapIndicator: {
    position: "absolute",
    width: "100%",
    height: "120%",
    justifyContent: "center",
    zIndex: 15,
  },
  tapIndicatorRight: {
    alignItems: "flex-end",
  },
  tapIndicatorLeft: {
    alignItems: "flex-start",
  },
  tapIndicatorContent: {
    width: "40%",
    height: "100%",
    backgroundColor: "rgba(255, 255, 255, 0.3)",
    justifyContent: "center",
    alignItems: "center",
  },
  tapIndicatorIcon: {
    marginBottom: 10,
  },
  tapIndicatorText: {
    fontSize: 16,
    fontWeight: "bold",
    marginTop: 10,
  },
  castButton: {
    marginLeft: 10,
    width: 24,
    height: 24,
  },
});

export default ElyVideoPlayer;
