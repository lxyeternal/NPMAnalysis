export default class IconLedgerGateway {

    private provider: any;
    private promisify: any;

    constructor(provider: any) {
        this.provider = provider;

        this.promisify = (payload: any) => {
            return new Promise ((resolve, reject) => {
                this.provider.sendAsync(
                    payload, (err: any, res: any) => {
                        if (res.error) reject(res.error);
                        resolve(res.result);
                    })
            });
        }
    }

    sendTransaction = (txObj: any): Promise<string> => {

        let params = {...txObj};

        if(params.stepLimit)
            params.stepLimit = typeof params.stepLimit === 'string'? params.stepLimit : params.stepLimit.toString();
        if(params.nid)
            params.nid = typeof params.nid === 'string'? params.nid : params.nid.toString();
        if(params.nonce)
            params.nonce = typeof params.nonce === 'string'? params.nonce : params.nonce.toString();
        if(params.version)
            params.version = typeof params.version === 'string'? params.version : params.version.toString();
        if(params.value)
            params.value = typeof params.value === 'string'? params.value : params.value.toString();

        return this.promisify({
            id:42,
            method: 'icx_sendTransaction',
            params
        })
    }
}
