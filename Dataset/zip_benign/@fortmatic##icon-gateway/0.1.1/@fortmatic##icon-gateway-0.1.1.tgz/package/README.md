# icon-gateway

## Installation
```bash
npm i @fortmatic/icon-gateway fortmatic icon-sdk-js
```
## Setup
```js
import IconExtension from '@fortmatic/icon-gateway'
import Fortmatic from 'fortmatic';

export const fmPhantom = new Fortmatic.Phantom('YOUR_API_KEY',{
    rpcUrl: 'https://bicon.net.solidwallet.io/api/v3',
    chainId: 2,
    chainType: 'ICON'
});
const phantomProvider = fmPhantom.getProvider();

const fmIconService = new IconExtension(phantomProvider);
```

## Whitelabel SDK method
Please go to fortmatic doc (https://docs.fortmatic.com/whitelabel-sdk/client-js-sdk) to check Whitelabel SDK method like 
User Authentication and Get User Metadata


## Usage

Build the transaction object using builder class.

```js
    /* Build `IcxTransaction` instance for sending ICX. */
    const txObj = new IconBuilder.IcxTransactionBuilder()
                .from("hxe4837d3b902dcaf9abe529f5584489c28d8b4621")
                .to("hxe4837d3b902dcaf9abe529f5584489c28d8b4621")
                .value(IconAmount.of(0.5, IconAmount.Unit.ICX).toLoop())
                .stepLimit(IconConverter.toBigNumber(100000))
                .nid(IconConverter.toBigNumber(3))
                .nonce(IconConverter.toBigNumber(1))
                .version(IconConverter.toBigNumber(3))
                .timestamp((new Date()).getTime() * 1000)
                .build();
    
    /* Build `MessageTransaction` instance for sending data. */
    const txObj = new IconBuilder.MessageTransactionBuilder()
                  .from('hxe4837d3b902dcaf9abe529f5584489c28d8b4621')
                  .to('hxe4837d3b902dcaf9abe529f5584489c28d8b4621')
                  .stepLimit(IconConverter.toBigNumber(1000000))
                  .nid(IconConverter.toBigNumber(3))
                  .nonce(IconConverter.toBigNumber(1))
                  .version(IconConverter.toBigNumber(3))
                  .timestamp((new Date()).getTime() * 1000)
                  .data(IconConverter.fromUtf8('Hello'))
                  .build();
           
    /* Build `DeployTransaction` instance for deploying SCORE. */
    const txObj = new DeployTransactionBuilder()
                .from('hxe4837d3b902dcaf9abe529f5584489c28d8b4621')
                .to('cx0000000000000000000000000000000000000000')
                .stepLimit(IconConverter.toBigNumber(2100000000))
                .nid(IconConverter.toBigNumber(3))
                .nonce(IconConverter.toBigNumber(1))
                .version(IconConverter.toBigNumber(3))
                .timestamp((new Date()).getTime() * 1000)
                .contentType('application/zip')
                .content(`0x${content}`)
                .params({
                    initialSupply: IconConverter.toHex('100000000000'),
                    decimals: IconConverter.toHex(18),
                    name: 'StandardToken',
                    symbol: 'ST',
                })
                .build();
    
    /* Build `CallTransaction` instance for executing SCORE function. */
    const txObj = new IconBuilder.CallTransactionBuilder()
                .from('hxe4837d3b902dcaf9abe529f5584489c28d8b4621')
                .to('cxd1602bde1d4b2b4facc8673c661c5e59e6ac20b4')
                .stepLimit(IconConverter.toBigNumber('2000000'))
                .nid(IconConverter.toBigNumber('3'))
                .nonce(IconConverter.toBigNumber('1'))
                .version(IconConverter.toBigNumber('3'))
                .timestamp((new Date()).getTime() * 1000)
                .method('hello')
                .params({})

```
By passing txObj instance to fmIconService.sendTransaction() method, it will automatically sign the transaction with current user and
 generate transaction object including signature, and send to ICON node.
```js
    const txhash = await fmIconService.sendTransaction(txObj);

    console.log('transaction result', txhash);
    window.open(`https://bicon.tracker.solidwallet.io/transaction/${txhash}`)
```