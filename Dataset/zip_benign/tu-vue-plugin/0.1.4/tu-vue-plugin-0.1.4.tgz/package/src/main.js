import { createApp } from 'vue'
import App from './App.vue'
import plugin from './plugins/index.js'

createApp(App).use(plugin).mount('#app')
