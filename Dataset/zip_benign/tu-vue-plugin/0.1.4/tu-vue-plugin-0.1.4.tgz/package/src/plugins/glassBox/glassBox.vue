<template>
  <div :style="';width:'+width+'!important;height:'+height+'!important;border-radius:'+border+'!important;text-align:'+align+';'" ref="box">
    <div class="tu-glass" :style="';border-radius:'+border+'!important;'">
      <div class="tu-glass-bloack" :style="';border-radius:'+border+'!important;'+blockUrl? 'background:url('+blockUrl+');background-size: 100% 100%;':''">
        <div class="tu-glass-content" :style="';color:'+color+';font-size'+size+';border-radius:'+border+'!important;background:'+background+'!important;'">
          <div :class="[{'content':border==='50%'},{'content-size': border}]" :style="'width:'+cWidth+';height:'+cHeight+';overflow:hidden;'"><slot></slot></div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { defineComponent } from 'vue'

export default defineComponent({
  name:'tu-glassbox',
  props: {
    width: {
      type: String,
      default: '200px'
    },
    height: {
      type: String,
      default: '300px'
    },
    color: {
      type: String,
      default: 'white'
    },
    border: {
      type: String,
      default: ''
    },
    align: {
      type: String,
      default: 'left'
    },
    background: {
      type: String,
      default: 'rgba(0, 0, 0, 0.8)'
    },
    cWidth: {
      type: String,
      default: '100%'
    },
    cHeight: {
      type: String,
      default: '100%'
    },
    blockUrl: {
      type: String,
      default: ''
    },
    size: {
      type: String,
      default: '1rem'
    }
  }
})

</script>
<style scoped>
  .tu-glass {
    overflow: hidden;
    width: 100%;
    height: 100%;
    background:rgb(226, 226, 226)
  }

  .tu-glass-bloack {
    width: 100%;
    height: 100%;
  }

  .tu-glass-content {
    position: relative;
    width: 100%;
    height: 100%;
    top: 100%;
    transition: 0.2s;
  }

  .tu-glass:hover .tu-glass-content {
    top: 0;
    transition: 0.5s;
  }
  
  .tu-glass:hover {
    cursor: pointer;
  }

  .content-size {
    margin: 0 auto;
    position: relative;
    top: 50%;
    transform: translateY(-50%);
  }
  
  .content {
    width: 75%;
    height: 60%;
    margin: 0 auto;
    position: inherit;
    top: 20%;
  }
</style>