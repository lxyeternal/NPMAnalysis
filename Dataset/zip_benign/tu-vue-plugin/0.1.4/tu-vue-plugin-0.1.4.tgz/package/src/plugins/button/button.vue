<template>
  <div :style="';width:'+width+'!important;height:'+height+'!important;float:'+float+'!important;'">
    <button :class="[`tu-button-${type}`,'box',
    {'is-plain':plain,'is-disabled':disabled}]"
    :style="+round?('border-radius:'+height+';'):('border-radius:'+border+'!important;')+'font-size:'+fontSize+';'"
    @click="router(to)"
    >
      <span v-if="value">{{ value }}</span>
      <span v-else-if="$slots.default">
        <slot></slot>
      </span>
    </button>
    <br>
  </div>
</template>
<script>
import { defineComponent } from 'vue'

export default defineComponent({
  name:'tu-button',
  datd() {
    return {
    }
  },
  methods: {
    router(to) {
      if (!this.route || !to) {
        return
      }
      this.$router.push(to)
    }
  },
  props: {
    type: {
      type: String,
      default: 'default'
    },
    fontSize: {
      type: String,
      default: '14px'
    },
    plain: {
      type: Boolean,
      default: false
    },
    width: {
      type: String,
      default: '100px'
    },
    height: {
      type: String,
      default: '40px'
    },
    value: {
      type: String,
      default: ''
    },
    float: {
      type: String,
      default: 'left'
    },
    border: {
      type: String,
      default: '5px'
    },
    // style: {
    //   type: Object,
    //   default: null
    // },
    round: {
      type: Boolean,
      default: false
    },
    disabled: {
      type: Boolean,
      default: false
    },
    to: {
      type: String,
      default: ''
    },
    route: {
      type: Boolean,
      default: false
    }
  }
})
</script>
<style scoped>
  .box {
    width: 90%;
    height: 100%;
    outline: none;
    margin: 0 auto;
    line-height: 2.5;
    white-space: nowrap;
    cursor: pointer;
    -webkit-appearance: none;
    box-sizing: border-box;
    text-align: center;
    transition:  0.1s;
    font-weight: 600;
    -moz-user-select: none;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-slelect: none;
    position: relative;
  }

/* default */
  .tu-button-,
  .tu-button-default {
    background: #ffff;
    border: 3px solid rgba(46, 44, 42, 0.8);
    color: rgba(46, 44, 42, 0.9);
  }
  .tu-button-:hover,
  .tu-button-default:hover {
    border-color: rgba(104, 104, 104, 0.7);
    color: rgb(104, 104, 104);
  }
  .tu-button-:active,
  .tu-button-default:active {
    box-shadow: inset 0 0 10px rgba(61, 61, 61, 0.8);
    border-color: rgba(46, 44, 42, 0.4);
  }
  .tu-button-.is-disabled,
  .tu-button-default.is-disabled,
  .tu-button-.is-disabled:hover,
  .tu-button-default.is-disabled:hover,
  .tu-button-.is-disabled:active,
  .tu-button-default.is-disabled:active {
    opacity: 0.7;
    background: #ffffff;
    color: #606266;
    border-color: rgba(104, 104, 104, 0.7);
    cursor: no-drop;
    box-shadow: none;
  }


/* primary */
  .tu-button-primary {
    color: white;
    background: #00beee;
    border-style: none;
  }
  .tu-button-primary:hover {
    background: #47daff;
  }
  .tu-button-primary:active {
    box-shadow: inset 0 0 10px rgba(61, 61, 61, 0.5);
  }
  .tu-button-primary.is-plain,
  .tu-button-primary.is-plain:active {
    transition: 0.5s;
    color: #47daff;
    background: white;
    border: 3px solid #47daff;
    box-shadow: none;
  }
  .tu-button-primary.is-plain:focus {
    transition: 0.7s;
    color: white !important;
    background: #47daff !important;
    border-color: #47daff !important;
    border-style: dotted;
  }
  .tu-button-primary.is-disabled,
  .tu-button-primary.is-disabled:hover,
  .tu-button-primary.is-disabled:active {
    opacity: 0.7;
    color: white;
    background: #47daff;
    border-style: none;
    cursor: no-drop;
    box-shadow: none;
  }
  .tu-button-primary.is-plain.is-disabled,
  .tu-button-primary.is-plain.is-disabled:hover,
  .tu-button-primary.is-plain.is-disabled:active
  .tu-button-primary.is-plain.is-disabled:focus {
    opacity: 0.7;
    color: #47daff !important;
    background: white !important;
    border: 3px solid #47daff !important;
    box-shadow: none;
    cursor: no-drop;
    box-shadow: none;
  }

/* success */
  .tu-button-success {
    color: white;
    background: #32CD32;
    border-style: none;
  }
  .tu-button-success:hover {
    background: #38ec50;
  }
  .tu-button-success:active {
    box-shadow: inset 0 0 10px rgba(61, 61, 61, 0.5);
  }
  .tu-button-success.is-plain,
  .tu-button-success.is-plain:active {
    transition: 0.5s;
    color: #38ec50;
    background: white;
    border: 3px solid #38ec50;
    box-shadow: none;
  }
  .tu-button-success.is-plain:focus {
    transition: 0.7s;
    color: white !important;
    background: #38ec50 !important;
    border-color: #38ec50 !important;
    border-style: dotted;
  }
  .tu-button-success.is-disabled,
  .tu-button-success.is-disabled:hover,
  .tu-button-success.is-disabled:active {
    opacity: 0.7;
    color: white;
    background: #38ec50;
    border-style: none;
    cursor: no-drop;
    box-shadow: none;
  }
  .tu-button-success.is-plain.is-disabled,
  .tu-button-success.is-plain.is-disabled:hover,
  .tu-button-success.is-plain.is-disabled:active
  .tu-button-success.is-plain.is-disabled:focus {
    opacity: 0.7;
    color: #38ec50 !important;
    background: white !important;
    border: 3px solid #38ec50 !important;
    box-shadow: none;
    cursor: no-drop;
    box-shadow: none;
  }

/* info */
  .tu-button-info {
    color: white;
    background: rgb(153, 153, 153);
    border-style: none;
  }
  .tu-button-info:hover {
    background: rgb(189, 189, 189);
  }
  .tu-button-info:active {
    box-shadow: inset 0 0 10px rgba(61, 61, 61, 0.5);
  }
  .tu-button-info.is-plain,
  .tu-button-info.is-plain:active {
    transition: 0.5s;
    color: rgb(189, 189, 189);
    background: white;
    border: 3px solid rgb(189, 189, 189);
    box-shadow: none;
  }
  .tu-button-info.is-plain:focus {
    transition: 0.7s;
    color: white !important;
    background: rgb(189, 189, 189) !important;
    border-color: rgb(189, 189, 189) !important;
    border-style: dotted;
  }
  .tu-button-info.is-disabled,
  .tu-button-info.is-disabled:hover,
  .tu-button-info.is-disabled:active {
    opacity: 0.7;
    color: white;
    background: rgb(189, 189, 189);
    border-style: none;
    cursor: no-drop;
    box-shadow: none;
  }
  .tu-button-info.is-plain.is-disabled,
  .tu-button-info.is-plain.is-disabled:hover,
  .tu-button-info.is-plain.is-disabled:active
  .tu-button-info.is-plain.is-disabled:focus {
    opacity: 0.7;
    color: rgb(189, 189, 189) !important;
    background: white !important;
    border: 3px solid rgb(189, 189, 189) !important;
    box-shadow: none;
    cursor: no-drop;
    box-shadow: none;
  }
  

/* warning */
  .tu-button-warning {
    color: white;
    background: rgb(252, 168, 12);
    border-style: none;
  }
  .tu-button-warning:hover {
    background: rgb(255, 197, 90);
  }
  .tu-button-warning:active {
    box-shadow: inset 0 0 10px rgba(61, 61, 61, 0.5);
  }
  .tu-button-warning.is-plain,
  .tu-button-warning.is-plain:active {
    transition: 0.5s;
    color: rgb(255, 197, 90);
    background: white;
    border: 3px solid rgb(255, 197, 90);
    box-shadow: none;
  }
  .tu-button-warning.is-plain:focus {
    transition: 0.7s;
    color: white !important;
    background: rgb(255, 197, 90) !important;
    border-color: rgb(255, 197, 90) !important;
    border-style: dotted;
  }
  .tu-button-warning.is-disabled,
  .tu-button-warning.is-disabled:hover,
  .tu-button-warning.is-disabled:active {
    opacity: 0.7;
    color: white;
    background: rgb(255, 197, 90);
    border-style: none;
    cursor: no-drop;
    box-shadow: none;
  }
  .tu-button-warning.is-plain.is-disabled,
  .tu-button-warning.is-plain.is-disabled:hover,
  .tu-button-warning.is-plain.is-disabled:active
  .tu-button-warning.is-plain.is-disabled:focus {
    opacity: 0.7;
    color: rgb(255, 197, 90) !important;
    background: white !important;
    border: 3px solid rgb(255, 197, 90) !important;
    box-shadow: none;
    cursor: no-drop;
    box-shadow: none;
  }

/* danger */
  .tu-button-danger {
    color: white;
    background: #ee3838;
    border-style: none;
  }
  .tu-button-danger:hover {
    background: #ff6666;
  }
  .tu-button-danger:active {
    box-shadow: inset 0 0 10px rgba(61, 61, 61, 0.5);
  }
  .tu-button-danger.is-plain,
  .tu-button-danger.is-plain:active {
    transition: 0.5s;
    color: #ff6666;
    background: white;
    border: 3px solid #ff7b7b;
    box-shadow: none;
  }
  .tu-button-danger.is-plain:focus {
    transition: 0.7s;
    color: white !important;
    background: #ff6666 !important;
    border-color: #ff6666 !important;
    border-style: dotted;
  }
  .tu-button-danger.is-disabled,
  .tu-button-danger.is-disabled:hover,
  .tu-button-danger.is-disabled:active {
    opacity: 0.7;
    color: white;
    background: #ff6666;
    border-style: none;
    cursor: no-drop;
    box-shadow: none;
  }
  .tu-button-danger.is-plain.is-disabled,
  .tu-button-danger.is-plain.is-disabled:hover,
  .tu-button-danger.is-plain.is-disabled:active
  .tu-button-danger.is-plain.is-disabled:focus {
    opacity: 0.7;
    color: #ff6666 !important;
    background: white !important;
    border: 3px solid #ff6666 !important;
    box-shadow: none;
    cursor: no-drop;
    box-shadow: none;
  }

/* text */
  .tu-button-text {
    color: rgb(59, 160, 255);
    background: transparent;
    border-style: none;
  }
  .tu-button-text:active {
    color: rgb(4, 104, 218);
  }
  .tu-button-text.is-plain {
    color: rgb(59, 160, 255);
    background: transparent;
    border-style: none;
  }
  .tu-button-text.is-plain:active {
    color: rgb(4, 104, 218);
  }
  .tu-button-text.is-disabled,
  .tu-button-text.is-disabled:hover,
  .tu-button-text.is-disabled:active,
  .tu-button-text.is-plain.is-disabled,
  .tu-button-text.is-plain.is-disabled:hover,
  .tu-button-text.is-plain.is-disabled:active {
    opacity: 0.7;
    color: rgb(59, 160, 255);
    background: transparent;
    border-style: none;
    box-shadow: none;
    cursor: no-drop;
    box-shadow: none;
  }
</style>