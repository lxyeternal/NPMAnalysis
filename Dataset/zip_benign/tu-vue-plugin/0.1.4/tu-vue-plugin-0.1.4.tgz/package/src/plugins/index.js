// 插件入口

const components = require.context('./', true, /\.vue$/)

const install = Vue => {
  if (install.installed) return install.installed
  components.keys().forEach(file => {
    let config = components(file)
    let name = config.default.name || config
    Vue.component(name, config.default || config)
  })

  Vue.directive('focus', {
    inserted: (el) => {
      el.focus()
    }
  })
}

if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue)
}

export default {
  install
}