<template>
  <div>
    <!-- <tu-glassbox blockUrl="https://img0.baidu.com/it/u=2270135799,2267720206&fm=26&fmt=auto&gp=0.jpg">
      asdsad
    </tu-glassbox> -->
    <tu-button>按钮</tu-button>
  </div>
</template>

<script>
export default {
  name: 'App',
  components: {
  }
}
</script>
<style>
  #app {
    padding: 0;
    margin: 0;
    left: 0;
    top: 0;
    width: 100%;
  }
</style>
