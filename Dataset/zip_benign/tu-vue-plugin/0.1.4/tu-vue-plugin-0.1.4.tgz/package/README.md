### 当前版本功能拉胯
```
  组件列表
  .tu-glassbox   可暂时图片和信息功能的组件
  .tu-button     参照各大ui库写的按钮组件
```

### tu-glassbox 组件api
```
暂不支持更改弹窗框的动画时间
包含宽度大小等计量参数需要加上‘px’，‘%’等单位，不加可能导致参数无效

接受参数:
  .color          ---- 弹窗出文字颜色 默认(white)
  .size           ---- 弹出窗文字大小 默认(1rem)
  ·width          ---- 整体外壳的宽度(默认为200px)，会影响内容区域宽度    如width="100px"
  .height         ---- 整体外壳的高度(默认为300px)，会影响内容区域高度    如width="200px"
  .align          ---- 弹窗框内容的排列水平对其方式     如align="center"
  .background     ---- 弹出窗背景颜色，需设置背景色透明度，不然会完全遮挡背景图片     如background="rgb(0, 0, 0, 0.5)"
  .cWidth         ---- 弹出窗的文字区域宽度
  .cHeight        ---- 弹出窗的文字区域高度
  .blockUrl       ---- 盒子的背景图片  续传入图片地址url
```
### tu-button 组件api
```

接收参数:
  .type     类型-String     值-default, parimary, success, info, warning, danger, text
  .plain    类型-Boolean    值-true/false 默认false
  .width    类型-String     值-(传参时需要单位:px/rem/vw/%)   默认为100px;
  .height   类型-String     值-(传参时需要单位:px/rem/vh/%)   默认为40px;
  .fontSize 类型-String     值-需跟单位   默认为14px
  .value    类型-String     值-按钮文字(可以不用穿value), 通过插槽插入，如：<tu-button><template>按钮文字</template></tu-button>如需传入标签，则可考虑插槽方式
  .float    类型-String     值-按钮整块的float属性，  默认为'left'
  .border   类型-String     值-需跟单位，如果border和round同时出现，则生效的是round
  .round    类型-Boolean    值-true/false, 使按钮左右为圆角   默认false
  .disabled 类型-Boolean    值-true/false, 禁用,   默认为flase
  .to       类型-String     值-path字符串, route传值为true时生效 最基础的跳转路由, (暂不支持传参, 之后封装)
  .route    类型-Boolean    值-true/false, 开启路由跳转，需先安装并正确配置路由(vue-router)   默认值为false

```