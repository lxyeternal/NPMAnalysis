module.exports = function(api) {
    api.extendPackage({
        dependencies:{
            'moralis': '0.0.54'
        },   
    })
}