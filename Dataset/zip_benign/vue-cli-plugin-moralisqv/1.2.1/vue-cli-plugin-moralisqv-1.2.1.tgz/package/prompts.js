module.exports = [
{
    name: 'verbouse',
    type: 'confirm',
    message: 'Moralis-SDK + Polyfill and all dependancies will be installed. Continue:(Y/N)?',
    default: true,
}
]