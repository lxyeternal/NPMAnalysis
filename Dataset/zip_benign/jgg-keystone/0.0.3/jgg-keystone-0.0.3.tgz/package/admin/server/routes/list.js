var keystone = require('../../../');
var _ = require('lodash');

module.exports = function (req, res) {

	var viewLocals = {
		validationErrors: {},
		showCreateForm: _.has(req.query, 'new'),
	};
	var appName = keystone.get('name') || 'Keystone';
	var renderView = function () {
		var section = {
			lists: [],
			label: keystone.nav.by.list[req.list.key].label,
			key: keystone.nav.by.list[req.list.key].key
		};
		if (_.isArray(req.permissions) && req.permissions.length) {
			var models = _.map(req.permissions, 'model');
			_.forEach(keystone.nav.by.list[req.list.key].lists, function(list, key) {
				if (_.indexOf(models, list.key) != -1) {
					section.lists.push(list);
				}
			});
		} else {
			section = keystone.nav.by.list[req.list.key];
		}
		keystone.render(req, res, 'list', _.extend(viewLocals, {
			section: section || {},
			title: appName + ': ' + req.list.plural,
			page: 'list',
			list: req.list,
			submitted: req.body || {},
		}));
	};

	var checkCSRF = function () {
		var pass = keystone.security.csrf.validate(req);
		if (!pass) {
			console.error('CSRF failure');
			req.flash('error', 'There was a problem with your request, please try again.');
		}
		return pass;
	};

	var checkPermissions = function () {
		var permissions = req.permissions;
		var hasPermission = true;
		if (permissions.length) {
			hasPermission = false;
			_.forEach(permissions, function (permission) {
				if (req.list.key == permission.model && permission.add) {
					hasPermission = true;
				}
			});
			if (!hasPermission) {
				req.flash('error', '当前账号没有权限');
			}
		}
		return hasPermission;
	}

	var item;
	if (!req.list.get('nocreate') && req.list.get('autocreate') && _.has(req.query, 'new')) {

		if (!checkCSRF()) return renderView();

		item = new req.list.model();
		item.save(function (err) {
			if (err) {
				console.log('There was an error creating the new ' + req.list.singular + ':');
				console.error(err);
				req.flash('error', 'There was an error creating the new ' + req.list.singular + '.');
				renderView();
			} else {
				req.flash('success', 'New ' + req.list.singular + ' ' + req.list.getDocumentName(item) + ' created.');
				return res.redirect('/' + keystone.get('admin path') + '/' + req.list.path + '/' + item.id);
			}
		});

	} else if (!req.list.get('nocreate') && req.method === 'POST' && req.body.action === 'create') {

		if (!checkCSRF()) return renderView();
		if (!checkPermissions()) return renderView();

		item = new req.list.model();
		var updateHandler = item.getUpdateHandler(req);

		viewLocals.showCreateForm = true; // always show the create form after a create. success will redirect.

		var processUpdateHandler = function () {
			updateHandler.process(req.body, {
				// flashErrors: true,
				logErrors: true,
				fields: req.list.initialFields,
			}, function (err) {
				if (err) {
					viewLocals.createErrors = err;
					return renderView();
				}
				req.flash('success', 'New ' + req.list.singular + ' ' + req.list.getDocumentName(item) + ' created.');
				return res.redirect('/' + keystone.get('admin path') + '/' + req.list.path + '/' + item.id);
			});
		};

		if (req.list.nameIsInitial) {
			if (!req.list.nameField.inputIsValid(req.body, true, item)) {
				updateHandler.addValidationError(req.list.nameField.path, req.list.nameField.label + ' is required.');
			}
			req.list.nameField.updateItem(item, req.body, processUpdateHandler);
		} else {
			processUpdateHandler();
		}

	} else {
		renderView();
	}
};
