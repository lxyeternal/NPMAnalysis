var _ = require('lodash');

module.exports = function(keystone) {
	return function (op) {
		return function (req, res, next) {
			var permissions = req.permissions;
			if (permissions.length) {
				var hasPermission = false;
				_.forEach(permissions, function (permission) {
					if (req.list.key == permission.model && permission[op]) {
						hasPermission = true;
					}
				});
				if (!hasPermission) {
					if (req.headers.accept === 'application/json') {
						return res.status(403).json({error: 'Sorry, it\'s not allowed'});
					}
					req.flash('error', '当前账号没有权限');
					return res.apiError('当前账号没有权限');
					// return res.status(403).send(keystone.wrapHTMLError('Sorry, it\'s not allowed'));
				}
			}
			next();
		};
	};
};
