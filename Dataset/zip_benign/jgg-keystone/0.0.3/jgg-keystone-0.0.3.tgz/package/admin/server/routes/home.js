var keystone = require('../../../');
var _ = require('lodash');

module.exports = function (req, res) {

	var orphanedLists = [];
	if (_.isArray(req.permissions) && req.permissions.length) {
		var models = _.map(req.permissions, 'model');
		_.forEach(keystone.getOrphanedLists(), function (list, key) {
			if (_.indexOf(models, list.key) != -1) {
				orphanedLists.push(list);
			}
		});
	} else {
		orphanedLists = keystone.getOrphanedLists();
	}

	keystone.render(req, res, 'home', {
		section: 'home',
		page: 'home',
		title: keystone.get('name') || 'Keystone',
		orphanedLists: orphanedLists,
	});

};
