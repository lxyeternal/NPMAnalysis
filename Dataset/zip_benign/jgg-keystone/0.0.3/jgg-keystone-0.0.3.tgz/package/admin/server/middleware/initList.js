var _ = require('lodash');

module.exports = function (keystone) {
	return function (respectHiddenOption) {
		return function (req, res, next) {
			req.list = keystone.list(req.params.list);
			if (!req.list || (respectHiddenOption && req.list.get('hidden'))) {
				if (req.headers.accept === 'application/json') {
					return res.status(404).json({ error: 'invalid list path' });
				}
				req.flash('error', 'List ' + req.params.list + ' could not be found.');
				return res.redirect('/' + keystone.get('admin path'));
			}
			if (respectHiddenOption && (_.isArray(req.permissions) && req.permissions.length)) {
				var models = _.map(req.permissions, 'model');
				if (_.indexOf(models, req.list.key) == -1) {
					if (req.headers.accept === 'application/json') {
						return res.status(403).json({ error: 'not allowed' });
					}
					req.flash('error', 'List ' + req.params.list + ' could not be found.');
					return res.status(403).send(keystone.wrapHTMLError('Sorry, it\'s not allowed'));
				}
			}
			next();
		};
	};
};
