import React from 'react';
import CurrentListStore from '../../stores/CurrentListStore';
import Popout from '../Popout';
import PopoutList from '../Popout/PopoutList';
import {Button, Checkbox, Form, FormField, InputGroup, SegmentedControl} from 'elemental';

const FileUpload = require('react-fileupload');

var ListUploadForm = React.createClass({
  
  layerFunc(layer) {
    var style= {
      'background-color': 'rgba(0,0,0,0.7)',
      'position': 'absolute',
      'z-index': 10,
      'width': '110px',
      'height': '40px',
      'line-height': '42px',
      'left': '47%',
      'text-align': 'center',
      'font-size': '18px',
      'top': '45%',
      'border': '0px solid',
      'border-radius': '5px',
      'color': '#fff',
    }
    for(var i in style){
      layer.style[i]=style[i];
    }
    if(document.getElementById("layer")==null) {
      document.body.appendChild(layer);
      setTimeout("document.body.removeChild(layer);window.location.reload()",2000);
    }
  },

  render () {
    var key = CurrentListStore.getList().key;
    var that = this;
    const options = {
      baseUrl: '/upload',
      param: {
        key: key
      },
      fileFieldName: 'excelFile',
      chooseAndUpload: true,
      
      doUpload: function (files, mill) {
        console.log('you just uploaded', typeof files == 'string' ? files : files[0].name)
      },
      uploading: function (progress) {
        console.log('loading...', progress.loaded / progress.total + '%')
      },
      uploadSuccess: function (resp) {
        console.log('upload success..!', resp);
        if (resp.status == 0) {
          var layer=document.createElement("div");
          layer.id="layer";
          layer.innerHTML=resp.data;
          that.layerFunc(layer);
        } else {
          alert(resp.data);
        }
      },
      uploadError: function (err) {
        console.log(err.message)
      },
      uploadFail: function (resp) {
        console.log(resp)
      }
    }
    if (key == 'Place') {
      return (
        <div style={{paddingLeft: '.75em', paddingRight: '.75em',}}>
          <FileUpload options={options} ref="fileUpload">
            <Button ref="chooseAndUpload">Upload</Button>
          </FileUpload>
        </div>
      );
    } else {
      return (
        <div style={{paddingLeft: '.75em'}}></div>
      );
    }
  },
});

module.exports = ListUploadForm;
