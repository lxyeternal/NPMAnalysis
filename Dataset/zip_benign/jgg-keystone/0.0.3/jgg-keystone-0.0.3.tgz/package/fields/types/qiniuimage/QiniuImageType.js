var _ = require('lodash');
var assign = require('object-assign');
var keystone = require('../../../');
var super_ = require('../Type');
var util = require('util');
var utils = require('keystone-utils');
var qiniu = require('jgg-qiniu');
var Promise = require('promise');
var sizeOf = require('image-size');
var url = require('url');

function getEmptyValue() {
	return {
      public_id: '',
      version: 0,
      originalname: '',
      extension: '',
      hash: '',
      format: '',
      mimetype: '',
      width: 0,
      height: 0,
      size: 0,
      url: '',
      thumb_url: '',
      secure_url: '',
      secure_thumb_url: ''
    };
}

/**
 * QiniuImage FieldType Constructor
 * @extends Field
 * @api public
 */
function qiniuimage (list, path, options) {

	this._underscoreMethods = ['format'];
	this._fixedSize = 'full';
	this._properties = ['prefix', 'select', 'selectPrefix', 'autoCleanup', 'publicID', 'folder', 'filenameAsPublicID'];

	// TODO: implement filtering, usage disabled for now
	options.nofilter = true;

	qiniuimage.super_.call(this, list, path, options);

	// validate qiniu config
	if (!keystone.get('qiniu config')) {
		throw new Error(
			'Invalid Configuration\n\n'
			+ 'QiniuImage fields (' + list.key + '.' + this.path + ') require the "qiniu config" option to be set.\n\n'
			+ 'See http://keystonejs.com/docs/configuration/#services-qiniu for more information.\n'
		);
	}

}

/*!
 * Inherit from Field
 */

util.inherits(qiniuimage, super_);

/**
 * Registers the field on the List's Mongoose Schema.
 *
 * @api public
 */

qiniuimage.prototype.addToSchema = function () {

	var field = this;
	var schema = this.list.schema;

	var paths = this.paths = {
		// qiniu fields
		public_id: this._path.append('.public_id'),
		version: this._path.append('.version'),
		signature: this._path.append('.signature'),
		format: this._path.append('.format'),
		resource_type: this._path.append('.resource_type'),
		url: this._path.append('.url'),
		width: this._path.append('.width'),
		height: this._path.append('.height'),
		secure_url: this._path.append('.secure_url'),
		// virtuals
		exists: this._path.append('.exists'),
		folder: this._path.append('.folder'),
		// form paths
		upload: this._path.append('_upload'),
		action: this._path.append('_action'),
		select: this._path.append('_select'),
	};

	var schemaPaths = this._path.addTo({}, {
    public_id:     String,
    version:       Number,
    originalname:  String,
    extension:     String,
    hash:          String,
    format:        String,
    mimetype:      String,
    width:         Number,
    height:        Number,
    size:          Number,
    url:           String,
    thumb_url:     String,
    secure_url:    String,
    secure_thumb_url: String,
	});

	schema.add(schemaPaths);

	var exists = function (item) {
		return (item.get(paths.public_id) ? true : false);
	};

	// The .exists virtual indicates whether an image is stored
	schema.virtual(paths.exists).get(function () {
		return schemaMethods.exists.apply(this);
	});

	// The .folder virtual returns the qiniu folder used to upload/select images
	schema.virtual(paths.folder).get(function () {
		return schemaMethods.folder.apply(this);
	});

	var src = function (item, options) {

		if (!exists(item)) {
			return '';
		}

		options = (typeof options === 'object') ? options : {};

		if (!('fetch_format' in options) && keystone.get('qiniu webp') !== false) {
			options.fetch_format = 'auto';
		}

		if (!('progressive' in options) && keystone.get('qiniu progressive') !== false) {
			options.progressive = true;
		}

		if (!('secure' in options) && keystone.get('qiniu secure')) {
			options.secure = true;
		}

		options.version = item.get(paths.version);

		return qiniu.url(item.get(paths.public_id) + '.' + item.get(paths.format), options);

	};

	var reset = function (item) {
		item.set(field.path, getEmptyValue());
	};

	var addSize = function (options, width, height, other) {
		if (width) options.width = width;
		if (height) options.height = height;
		if (typeof other === 'object') {
			assign(options, other);
		}
		return options;
	};

	var schemaMethods = {
		exists: function () {
			return exists(this);
		},
    bucket: function() {
      return field.options.bucket;
    },
    prefix: function() {
      return field.options.prefix;
    },
    src: function(options) {
      return src(this, options);
    },
		/**
		 * Resets the value of the field
		 *
		 * @api public
		 */
		reset: function () {
			reset(this);
		},
		/**
		 * Deletes the image from Qiniu and resets the field
		 *
		 * @api public
		 */
		delete: function () {
			var _this = this;
			var promise = new Promise(function(resolve) {
				var config = keystone.get('qiniu config');
				qiniu.conf.ACCESS_KEY = config.access_key;
				qiniu.conf.SECRET_KEY = config.secret_key;

				var bucketName = field.options.bucket;
				var fileName = _this.get(paths.public_id);
				var client = new qiniu.rs.Client();
				client.remove(bucketName, fileName, function(err, result) {
					if (err && err.code !== 612) {
						reject(err);
					} else {
						resolve(result);
					}
				});
			});
			reset(this);
			return promise;
		},
		/**
		 * Uploads the image to qiniu
		 *
		 * @api public
		 */
		upload: function (file, options) {
			var promise = new Promise(function (resolve) {

				var config = keystone.get('qiniu config');
				qiniu.conf.ACCESS_KEY = config.access_key;
				qiniu.conf.SECRET_KEY = config.secret_key;

				var bucketName = field.options.bucket;
				var fileName = options.public_id;

				var putPolicy = new qiniu.rs.PutPolicy();
				putPolicy.scope = bucketName + ':' + fileName;
				var token = putPolicy.token();

				var params = {
					originalname: options.originalname
				};
				var putExtra = new qiniu.io.PutExtra(params);
				if (options.mimetype) {
					putExtra.mimeType = options.mimetype;
				}
				putExtra.check_crc = check_crc = 1;
				qiniu.io.putFile(token, fileName, file, putExtra, function(err, result) {
					console.log('upload qiniu result = ', result);
					if (err) {
						reject(result);
					} else {
						resolve(result);
					}
				});
			});

			return promise;
		}
	};

	_.forEach(schemaMethods, function (fn, key) {
		field.underscoreMethod(key, fn);
	});

	// expose a method on the field to call schema methods
	this.apply = function (item, method) {
		return schemaMethods[method].apply(item, Array.prototype.slice.call(arguments, 2));
	};

	this.bindUnderscoreMethods();
};

/**
 * Formats the field value
 *
 * @api public
 */
qiniuimage.prototype.format = function (item) {
	return item.get(this.paths.url);
};

/**
 * Detects whether the field has been modified
 *
 * @api public
 */
qiniuimage.prototype.isModified = function (item) {
	return item.isModified(this.paths.public_id);
};


qiniuimage.prototype.validateInput = function(data) {//eslint-disable-line no-unused-vars
  // TODO - how should image field input be validated?
  return true;
};

/**
 * Updates the value for this field in the item from a data object
 *
 * @api public
 */

qiniuimage.prototype.updateItem = function(item, data, callback) {

	var cloudinary = require('cloudinary');
	var field = this;
	var value = this.getValueFromData(data);

	// Allow value to be retrieved from the legacy `_upload` path if it is undefined
	if (value === undefined) {
		value = this.getValueFromData(data, '_upload');
	}

	// Allow field value reset
	if (value === '' || value === 'null' || (typeof value === 'object' && !Object.keys(value).length)) {
		item.set(this.path, getEmptyValue());
		return process.nextTick(callback);
	}

	// When the value is a string, assume it's base64 data or a remote URL and
	// upload it to cloudinary as a file path. More logic could be added here to
	// detect/prevent invalid uploads
	if (typeof value === 'string') {
		value = { path: value };
	}

	if (typeof value === 'object' && 'public_id' in value) {
		// Cloudinary Image data provided
		if (value.public_id) {
			var v = assign(getEmptyValue(), value);
			item.set(this.path, v);
		} else {
			item.set(this.path, getEmptyValue());
		}
		return process.nextTick(callback);
	} else if (typeof value === 'object' && value.path) {
		// File provided - upload it
		var tagPrefix = keystone.get('cloudinary prefix') || '';
		var uploadOptions = {
			tags: [],
		};
		if (tagPrefix.length) {
			uploadOptions.tags.push(tagPrefix);
			tagPrefix += '_';
		}
		uploadOptions.tags.push(tagPrefix + field.list.path + '_' + field.path);
		if (keystone.get('env') !== 'production') {
			uploadOptions.tags.push(tagPrefix + 'dev');
		}
		var folder = this.getFolder();
		if (folder) {
			uploadOptions.folder = folder;
		}
		// NOTE: field.options.publicID has been deprecated (tbc)
		if (field.options.filenameAsPublicID && value.originalname && typeof value.originalname === 'string') {
			uploadOptions.public_id = value.originalname.substring(0, value.originalname.lastIndexOf('.'));
		}

		// TODO: implement autoCleanup; should delete existing images before uploading
		var config = keystone.get('qiniu config');
		qiniu.conf.ACCESS_KEY = config.access_key;
		qiniu.conf.SECRET_KEY = config.secret_key;

		var bucketName = field.options.bucket;
		var fileName = updateOptions.public_id;

		var putPolicy = new qiniu.rs.PutPolicy();
		putPolicy.scope = bucketName + ':' + fileName;
		var token = putPolicy.token();

		var params = {
			originalname: updateOptions.originalname
		};
		var putExtra = new qiniu.io.PutExtra(params);
		if (updateOptions.mimetype) {
			putExtra.mimeType = updateOptions.mimetype;
		}
		putExtra.check_crc = check_crc = 1;
		qiniu.io.putFile(token, fileName, file, putExtra, function(err, result) {
			if (err) {
				console.log('qiniu upload error = ', err);
				callback(err);
			} else {
				item.set(field.path, result);
				return callback();
			}
		});
	} else {
		// Nothing to do
		return process.nextTick(callback);
	}
};


/**
 * Returns a callback that handles a standard form submission for the field
 *
 * Expected form parts are
 * - `field.paths.action` in `req.body` (`clear` or `delete`)
 * - `field.paths.upload` in `req.files` (uploads the image to qiniu)
 *
 * @api public
 */
qiniuimage.prototype.getRequestHandler = function (item, req, paths, callback) {

	var field = this;

	if (utils.isFunction(paths)) {
		callback = paths;
		paths = field.paths;
	} else if (!paths) {
		paths = field.paths;
	}

	callback = callback || function () {};

	return function () {

		if (req.body) {
			var action = req.body[paths.action];

			if (/^(delete|reset)$/.test(action)) {
				field.apply(item, action);
			}
		}

		if (req.files && req.files[paths.upload] && req.files[paths.upload].size) {
 			var prefix = field.options.prefix || '';
 			var imageDelete;

			if (prefix.length) {
				prefix += '_';
			}

			var uploadOptions = {};
			var fileInfo = req.files[paths.upload];

			if (field.options.publicID) {
				// using the value from another field as image id
				var publicIdValue = item.get(field.options.publicID);
				if (publicIdValue) {
					uploadOptions.public_id = publicIdValue;
				}
			} else if (field.options.filenameAsPublicID) {
				uploadOptions.public_id = fileInfo.originalname.substring(0, fileInfo.originalname.lastIndexOf('.'));
			} else {
				// default id(UUID) is generated by file uploader (multer)
				uploadOptions.public_id = req.files[paths.upload].name;
			}

			uploadOptions.public_id = prefix + uploadOptions.public_id;
			uploadOptions.originalname = fileInfo.originalname;
			uploadOptions.mimetype = fileInfo.mimetype;

			if (field.options.autoCleanup && item.get(field.paths.exists)) {
				// capture image delete promise
				imageDelete = field.apply(item, 'delete');
			}

			// callback to be called upon completion of the 'upload' method
			var uploadComplete = function(result) {
				sizeOf(fileInfo.path, function(err, dimensions) {
					if (err) {
						callback(err);
					} else {
						var config = keystone.get('qiniu config');

						result.width = dimensions.width;
						result.height = dimensions.height;
						result.public_id = uploadOptions.public_id;
						result.originalname = fileInfo.originalname;
						result.extension = fileInfo.extension;
						result.mimetype = fileInfo.mimetype;
						result.size = fileInfo.size;
						result.url = url.resolve(config.host, uploadOptions.public_id);

						var imageView = new qiniu.fop.ImageView();
						imageView.width = 128;
						imageView.height = 128;
						result.thumb_url = imageView.makeRequest(result.url);
						if (config.secure_host) {
							result.secure_url = url.resolve(config.secure_host, uploadOptions.public_id);
							result.secure_thumb_url = imageView.makeRequest(result.secure_url);
						}
						item.set(field.path, result);
						callback();
					}
				});
			};

			if (typeof imageDelete === 'undefined') {
				field.apply(item, 'upload', req.files[paths.upload].path, uploadOptions).then(uploadComplete);
			} else {
				imageDelete.then(function() {
					return field.apply(item, 'upload', req.files[paths.upload].path, uploadOptions).then(uploadComplete);
				});
			}

		} else {
			callback();
		}
	};
};

/**
 * Immediately handles a standard form submission for the field (see `getRequestHandler()`)
 *
 * @api public
 */
qiniuimage.prototype.handleRequest = function (item, req, paths, callback) {
	this.getRequestHandler(item, req, paths, callback)();
};

/*!
 * Export class
 */
module.exports = qiniuimage;
