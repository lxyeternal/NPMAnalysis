/*!
 * Module dependencies.
 */

var util = require('util'),
	keystone = require('../../../');
	FieldType = require('../Type');

/**
 * TextArray FieldType Constructor
 * @extends Field
 * @api public
 */

function objectarray(list, path, options) {
	objectarray.super_.call(this, list, path, options);
}

/*!
 * Inherit from Field
 */

util.inherits(objectarray, FieldType);

objectarray.prototype.addToSchema = function() {
	var subListName = '_' + this.list.key.toLowerCase() + '.' + this.path;
	var sublist = this.subList = new keystone.List(subListName, { schema: '', hidden: true });

	sublist.add(this.options.nestedFields);
	sublist.register();

	this.list.schema.path(this.path, [sublist.schema]);
	this.bindUnderscoreMethods();
};

objectarray.prototype.updateItem = function(item, data, callback) {
	var value = this.getValueFromData(data);
	if (value !== undefined && value != item.get(this.path)) {
		item.set(this.path, value);
	}
	if (value == undefined ) {
		value = [];
		item.set(this.path, value);
	}
	process.nextTick(callback);
};

/*!
 * Export class
 */

module.exports = objectarray;
