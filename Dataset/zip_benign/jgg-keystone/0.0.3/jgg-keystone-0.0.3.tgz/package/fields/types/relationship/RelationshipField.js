import async from 'async';
import Lists from '../../../admin/client/stores/Lists';
import Field from '../Field';
import React from 'react';
import Select from 'react-select';
import xhr from 'xhr';
import { Button, InputGroup } from 'elemental';

function compareValues (current, next) {
	const currentLength = current ? current.length : 0;
	const nextLength = next ? next.length : 0;
	if (currentLength !== nextLength) return false;
	for (let i = 0; i < currentLength; i++) {
		if (current[i] !== next[i]) return false;
	}
	return true;
}

module.exports = Field.create({

	displayName: 'RelationshipField',

	getInitialState () {
		return {
			loading: false,
			value: null,
			createIsOpen: false,
			options: []
		};
	},

	getDefaultProps () {
		return {
			loadingPlaceholder: 'Loading...',
			minimumInput: 0,
			searchingText: 'Searching...',
			searchPromptText: 'Type to search',
		};
	},

	componentDidMount () {
		this._itemsCache = {};
		this.loadValue(this.props.value);
		this.loadOptions('');
	},

	componentWillReceiveProps (nextProps) {
		if (nextProps.value === this.props.value || nextProps.many && compareValues(this.props.value, nextProps.value)) return;
		this.loadValue(nextProps.value);
	},

	shouldCollapse () {
		if (this.props.many) {
			// many:true relationships have an Array for a value
			return this.props.collapse && !this.props.value.length;
		}
		return this.props.collapse && !this.props.value;
	},

	getFilters () {
		var filters = {};

		_.forEach(this.props.filters, (value, key) => {
			if (_.isString(value) && value[0] == ':') { // eslint-disable-line eqeqeq
				var fieldName = value.slice(1);

				console.log('values = ', this.props.values);

				var val = this.props.values[fieldName];
				if (val) {
					filters[key] = val;
					return;
				}

				// check if filtering by id and item was already saved
				if (fieldName === ':_id' && Keystone.item) {
					filters[key] = Keystone.item.id;
					return;
				}
			} else {
				filters[key] = value;
			}
		}, this);

		return filters;
	},

	buildFilters () {
		var parts = [];
		var filters = this.getFilters();

		_.forEach(filters, function (val, key) {
			parts.push('filters[' + key + '][value]=' + encodeURIComponent(val));
		});

		return parts.join('&');
	},

	cacheItem (item) {
		item.href = Keystone.adminPath + '/' + this.props.refList.path + '/' + item.id;
		this._itemsCache[item.id] = item;
	},

	loadValue (values) {
		if (!values) {
			return this.setState({
				loading: false,
				value: null,
			});
		};
		values = Array.isArray(values) ? values : values.split(',');
		const cachedValues = values.map(i => this._itemsCache[i]).filter(i => i);
		if (cachedValues.length === values.length) {
			this.setState({
				loading: false,
				value: this.props.many ? cachedValues : cachedValues[0],
			});
			return;
		}
		this.setState({
			loading: true,
			value: null,
		});
		async.map(values, (value, done) => {
			xhr({
				url: Keystone.adminPath + '/api/' + this.props.refList.path + '/' + value + (!this.props.populate ? '?basic' : ''),
				responseType: 'json',
			}, (err, resp, data) => {
				if (err || !data) return done(err);
				this.cacheItem(data);
				done(err, data);
			});
		}, (err, expanded) => {
			if (!this.isMounted()) return;
			this.setState({
				loading: false,
				value: this.props.many ? expanded : expanded[0],
			});
			if (!this.props.many && this.props.populate) this.populateFields(expanded[0]);
		});
	},

	// NOTE: this seems like the wrong way to add options to the Select
	loadOptionsCallback: {},
	loadOptions (input) {
		// NOTE: this seems like the wrong way to add options to the Select
		const filters = this.buildFilters();
		xhr({
			//url: Keystone.adminPath + '/api/' + this.props.refList.path + '?basic&search=' + input + '&' + filters,
			url: Keystone.adminPath + '/api/' + this.props.refList.path + '?basic&search=' + input,
			responseType: 'json',
		}, (err, resp, data) => {
			if (err) {
				console.error('Error loading items:', err);
				this.setState({
					options: []
				});
				return;
			}
			data.results.forEach(this.cacheItem);

			this.setState({
				options: data.results,
			});
		});
	},

	valueChanged (value) {
		this.props.onChange({
			path: this.props.path,
			value: value,
		}, function () {
			if (this.props.populate) {
				this.populateFields(value);
			}
		}.bind(this));
	},

	populateFields (value) {
		var id = value;

		if (typeof value !== 'string') {
			if (!value.id) return;
			id = value.id;
		}

		var options = this.props.populate;
		var cachedValue = Object.assign({}, this._itemsCache[id]);

		if (!cachedValue.fields[options.mapField]) return;

		var subFields = cachedValue.fields[options.mapField];
		this.props.onChange({ path: options.field, value: typeof value === 'string' ? [] : value, subFields: subFields });
	},

	toggleCreate (visible) {
		this.setState({
			createIsOpen: visible,
		});
	},

	onCreate (item) {
		this.cacheItem(item);
		if (Array.isArray(this.state.value)) {
			// For many relationships, append the new item to the end
			const values = this.state.value.map((item) => item.id);
			values.push(item.id);
			this.valueChanged(values.join(','));
		} else {
			this.valueChanged(item.id);
		}

		// NOTE: this seems like the wrong way to add options to the Select
		this.loadOptionsCallback(null, {
			complete: true,
			options: Object.keys(this._itemsCache).map((k) => this._itemsCache[k]),
		});
		this.toggleCreate(false);
	},

	renderSelect (noedit) {
		var fieldName = this.props.path;
      var filters = this.getFilters();
		var options = [];
		if (!_.isEmpty(filters)) {
			for (let i = 0; i < this.state.options.length; i++) {
				_.forEach(filters, (value, key) => {
					if (this.props.values[key] == this.state.options[i].fields[key]) {
						options.push(this.state.options[i]);
					}
				}, this);
			}
		} else {
			options = this.state.options;
		}

		if (this.props.nested) fieldName = this.props.nested + '.' + this.props.path + '_' + this.props._id;

		var loading = this.state.loading;
		let placeholder = loading ? this.props.loadingPlaceholder : this.props.placeholder;
		let { noResultsText } = this.props;
		if (!options.length) {
			if (loading) {
				noResultsText = this.props.searchingText;
			} else {
				noResultsText = this.props.searchPromptText;
			}
		}

		return (
			<Select
				multi={this.props.many}
				disabled={noedit}
				labelKey="name"
				name={fieldName}
				onChange={this.valueChanged}
				simpleValue
				value={this.state.value}
				valueKey="id"
				ref="select"
				isLoading={loading}
				onInputChange={this.loadOptions}
				options={options}
				noResultsText={noResultsText}
				placeholder={placeholder}
			/>
		);
	},

	renderInputGroup () {
		// TODO: find better solution
		//   when importing the CreateForm using: import CreateForm from '../../../admin/client/components/CreateForm';
		//   CreateForm was imported as a blank object. This stack overflow post suggested lazilly requiring it:
		// http://stackoverflow.com/questions/29807664/cyclic-dependency-returns-empty-object-in-react-native
		const CreateForm = require('../../../admin/client/components/Forms/CreateForm');
		return (
			<InputGroup>
				<InputGroup.Section grow>
					{this.renderSelect()}
				</InputGroup.Section>
				<InputGroup.Section>
					<Button onClick={() => this.toggleCreate(true)} type="success">+</Button>
				</InputGroup.Section>
				<CreateForm
					list={Lists[this.props.refList.key]}
					isOpen={this.state.createIsOpen}
					onCreate={(data) => this.onCreate(data)}
					onCancel={() => this.toggleCreate(false)} />
			</InputGroup>
		);
	},

	renderValue () {
		return this.renderSelect(true);
	},

	renderField () {
		if (this.props.createInline) {
			return this.renderInputGroup();
		} else {
			return this.renderSelect();
		}
	},

});
