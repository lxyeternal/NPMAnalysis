var _ = require('lodash');
var assign = require('object-assign');
var async = require('async');
var keystone = require('../../../');
var super_ = require('../Type');
var util = require('util');
var utils = require('keystone-utils');
var qiniu = require('jgg-qiniu');
var sizeOf = require('image-size');
var url = require('url');

function getEmptyValue () {
	return {
		public_id: '',
		version: 0,
		originalname: '',
		extension: '',
		hash: '',
		format: '',
		mimetype: '',
		width: 0,
		height: 0,
		size: 0,
		url: '',
		thumb_url: '',
		secure_url: '',
		secure_thumb_url: ''
	};
}

function truthy (value) {
	return value;
}

/**
 * QiniuImages FieldType Constructor
 * @extends Field
 * @api public
 */
function qiniuimages (list, path, options) {

	this._underscoreMethods = ['format'];
	this._fixedSize = 'full';
	this._properties = ['select', 'selectPrefix', 'autoCleanup', 'publicID', 'folder', 'filenameAsPublicID'];

	// TODO: implement filtering, usage disabled for now
	options.nofilter = true;
	// TODO: implement initial form, usage disabled for now
	if (options.initial) {
		throw new Error('Invalid Configuration\n\n'
			+ 'QiniuImages fields (' + list.key + '.' + path + ') do not currently support being used as initial fields.\n');
	}

	qiniuimages.super_.call(this, list, path, options);

	// validate qiniu config
	if (!keystone.get('qiniu config')) {
		throw new Error('Invalid Configuration\n\n'
			+ 'QiniuImages fields (' + list.key + '.' + this.path + ') require the "qiniu config" option to be set.\n\n'
			+ 'See http://keystonejs.com/docs/configuration/#services-qiniu for more information.\n');
	}

}

/*!
 * Inherit from Field
 */
util.inherits(qiniuimages, super_);

/**
 * Gets the folder for images in this field
 */
qiniuimages.prototype.getFolder = function () {
	var folder = null;

	if (keystone.get('qiniu folders') || this.options.folder) {
		if (typeof this.options.folder === 'string') {
			folder = this.options.folder;
		} else {
			var folderList = keystone.get('qiniu prefix') ? [keystone.get('qiniu prefix')] : [];
			folderList.push(this.list.path);
			folderList.push(this.path);
			folder = folderList.join('/');
		}
	}

	return folder;
};

/**
 * Registers the field on the List's Mongoose Schema.
 *
 * @api public
 */
qiniuimages.prototype.addToSchema = function () {

	var mongoose = keystone.mongoose;
	var field = this;
	var schema = this.list.schema;

	this.paths = {
		// virtuals
		folder: this._path.append('.folder'),
		// form paths
		upload: this._path.append('_upload'),
		uploads: this._path.append('_uploads'),
		action: this._path.append('_action'),
		order: this._path.append('_order'),
	};

	var ImageSchema = new mongoose.Schema({
		public_id:     String,
		version:       Number,
		originalname:  String,
		extension:     String,
		hash:          String,
		format:        String,
		mimetype:      String,
		width:         Number,
		height:        Number,
		size:          Number,
		url:           String,
		thumb_url:     String,
		secure_url:    String,
		secure_thumb_url: String,
	});

	// Generate qiniu folder used to upload/select images
	var folder = function (item) { // eslint-disable-line no-unused-vars
		var folderValue = '';

		if (keystone.get('qiniu folders')) {
			if (field.options.folder) {
				folderValue = field.options.folder;
			} else {
				var folderList = keystone.get('qiniu prefix') ? [keystone.get('qiniu prefix')] : [];
				folderList.push(field.list.path);
				folderList.push(field.path);
				folderValue = folderList.join('/');
			}
		}

		return folderValue;
	};

	// The .folder virtual returns the qiniu folder used to upload/select images
	schema.virtual(field.paths.folder).get(function () {
		return folder(this);
	});

	var src = function (img, options) {
		if (keystone.get('qiniu secure')) {
			options = options || {};
			options.secure = true;
		}
		return img.public_id ? qiniu.url(img.public_id + '.' + img.format, options) : '';
	};

	var addSize = function (options, width, height, other) {
		if (width) options.width = width;
		if (height) options.height = height;
		if (typeof other === 'object') {
			assign(options, other);
		}
		return options;
	};

	ImageSchema.method('src', function (options) {
		return src(this, options);
	});

	ImageSchema.method('scale', function (width, height, options) {
		return src(this, addSize({ crop: 'scale' }, width, height, options));
	});

	ImageSchema.method('fill', function (width, height, options) {
		return src(this, addSize({ crop: 'fill', gravity: 'faces' }, width, height, options));
	});

	ImageSchema.method('lfill', function (width, height, options) {
		return src(this, addSize({ crop: 'lfill', gravity: 'faces' }, width, height, options));
	});

	ImageSchema.method('fit', function (width, height, options) {
		return src(this, addSize({ crop: 'fit' }, width, height, options));
	});

	ImageSchema.method('limit', function (width, height, options) {
		return src(this, addSize({ crop: 'limit' }, width, height, options));
	});

	ImageSchema.method('pad', function (width, height, options) {
		return src(this, addSize({ crop: 'pad' }, width, height, options));
	});

	ImageSchema.method('lpad', function (width, height, options) {
		return src(this, addSize({ crop: 'lpad' }, width, height, options));
	});

	ImageSchema.method('crop', function (width, height, options) {
		return src(this, addSize({ crop: 'crop', gravity: 'faces' }, width, height, options));
	});

	ImageSchema.method('thumbnail', function (width, height, options) {
		return src(this, addSize({ crop: 'thumb', gravity: 'faces' }, width, height, options));
	});

	schema.add(this._path.addTo({}, [ImageSchema]));

	this.removeImage = function (item, id, method, callback) {
		var images = item.get(field.path);
		if (typeof id !== 'number') {
			for (var i = 0; i < images.length; i++) {
				if (images[i].public_id === id) {
					id = i;
					break;
				}
			}
		}
		var img = images[id];
		if (!img) return;
		if (method === 'delete') {
			qiniu.uploader.destroy(img.public_id, function () {});
		}
		images.splice(id, 1);
		if (callback) {
			item.save((typeof callback !== 'function') ? callback : undefined);
		}
	};

	this.underscoreMethod('remove', function (id, callback) {
		field.removeImage(this, id, 'remove', callback);
	});

	this.underscoreMethod('delete', function (id, callback) {
		field.removeImage(this, id, 'delete', callback);
	});

	this.bindUnderscoreMethods();
};

/**
 * Formats the field value
 *
 * @api public
 */
qiniuimages.prototype.format = function (item) {
	return _.map(item.get(this.path), function (img) {
		return img.src();
	}).join(', ');
};

/**
 * Validates that a value for this field has been provided in a data object
 *
 * Deprecated
 */
qiniuimages.prototype.inputIsValid = function (data) { // eslint-disable-line no-unused-vars
	// TODO - how should image field input be validated?
	return true;
};

/**
 * Updates the value for this field in the item from a data object
 *
 * @api public
 */
qiniuimages.prototype.updateItem = function (item, data, callback) {

	var field = this;
	var values = this.getValueFromData(data);

	// Early exit path: reset value when falsy, or bail if no value was provided
	if (!values || values === 'null') {
		if (values !== undefined) {
			item.set(field.path, []);
		}
		return process.nextTick(callback);
	}

	// When the value exists, but isn't an array, turn it into one (this just
	// means a single field was submitted in the formdata)
	if (!Array.isArray(values)) {
		values = [values];
	}

	// Precalc these options, it's inefficient when not uploading images but
	// avoids recalculating them on each iteration in the map below
	// TODO: is this worth optimising?
	var tagPrefix = keystone.get('qiniu prefix') || '';
	var uploadOptions = {
		tags: [],
	};
	if (tagPrefix.length) {
		uploadOptions.tags.push(tagPrefix);
		tagPrefix += '_';
	}
	uploadOptions.tags.push(tagPrefix + field.list.path + '_' + field.path);
	if (keystone.get('env') !== 'production') {
		uploadOptions.tags.push(tagPrefix + 'dev');
	}
	var folder = this.getFolder();
	if (folder) {
		uploadOptions.folder = folder;
	}

	async.map(values, function (value, next) {
		// When the value is a string, it may be JSON serialised data. If so, parse
		// it. Otherwiser, we assume it's base64 data or a remote URL and upload it
		// to qiniu as a file path. More logic could be added here to
		// detect/prevent invalid uploads (as per qiniuimage field)
		if (typeof value === 'string') {
			if (value.charAt(0) === '{' && value.charAt(value.length - 1) === '}') {
				try {
					value = JSON.parse(value);
				} catch (e) {
					// value isn't JSON
				}
			} else {
				value = { path: value };
			}
		}
		if (typeof value === 'object' && value.uploadFromKey) {
			value = data[value.uploadFromKey];
		}
		if (typeof value === 'object' && 'public_id' in value) {
			// Qiniu Image data provided
			if (value.public_id) {
				var v = assign(getEmptyValue(), value);
				return next(null, v);
			} else {
				return next(null);
			}
		} else if (typeof value === 'object' && value.path) {
			// File provided - upload it
			// NOTE: field.options.publicID has been deprecated (tbc)
			if (field.options.filenameAsPublicID && value.originalname && typeof value.originalname === 'string') {
				uploadOptions = assign({}, uploadOptions, {
					public_id: value.originalname.substring(0, value.originalname.lastIndexOf('.')),
				});
			}

			// TODO: implement autoCleanup; should delete existing images before uploading
			var config = keystone.get('qiniu config');
			qiniu.conf.ACCESS_KEY = config.access_key;
			qiniu.conf.SECRET_KEY = config.secret_key;

			var bucketName = field.options.bucket;
			var fileName = value.public_id;

			var putPolicy = new qiniu.rs.PutPolicy();
			putPolicy.scope = bucketName + ':' + fileName;
			var token = putPolicy.token();

			var params = {
				originalname: value.originalname
			};
			var putExtra = new qiniu.io.PutExtra(params);
			if (value.mimetype) {
				putExtra.mimeType = value.mimetype;
			}
			putExtra.check_crc = check_crc = 1;
			qiniu.io.putFile(token, fileName, file, putExtra, function(err, result) {
				if (err) {
					console.log('qiniu upload error = ', err);
					next(err);
				} else {
					item.set(field.path, result);
					next(null, result);
				}
			});

		} else {
			// Nothing to do
			return next();
		}
	}, function (err, result) {
		if (err) return callback(err);
		result = result.filter(truthy);
		item.set(field.path, result);
		return callback();
	});
};

/**
 * Returns a callback that handles a standard form submission for the field
 *
 * Expected form parts are
 * - `field.paths.action` in `req.body` in syntax `delete:public_id,public_id|remove:public_id,public_id`
 * - `field.paths.upload` in `req.files` (uploads the images to qiniu)
 *
 * @api public
 */
qiniuimages.prototype.getRequestHandler = function (item, req, paths, callback) {

	var field = this;

	if (utils.isFunction(paths)) {
		callback = paths;
		paths = field.paths;
	} else if (!paths) {
		paths = field.paths;
	}

	callback = callback || function () {};

	return function () {

		// Order
		if (req.body[paths.order]) {
			var images = item.get(field.path);
			var newOrder = req.body[paths.order].split(',');

			images.sort(function (a, b) {
				return (newOrder.indexOf(a.public_id) > newOrder.indexOf(b.public_id)) ? 1 : -1;
			});
		}

		// Removals & Deletes
		if (req.body && req.body[paths.action]) {
			var actions = req.body[paths.action].split('|');

			actions.forEach(function (action) {
				action = action.split(':');
				var method = action[0];
				var ids = action[1];

				if (!method.match(/^(remove|delete)$/) || !ids) return;

				ids.split(',').forEach(function (id) {
					field.removeImage(item, id, method);
				});
			});
		}

		// Upload References (direct uploading)
		if (req.body[paths.uploads]) {
			var uploads = JSON.parse(req.body[paths.uploads]);

			uploads.forEach(function (file) {
				item.get(field.path).push(file);
			});
		}

		// Upload Data (form submissions)
		if (req.files && req.files[paths.upload]) {
			var files = [].concat(req.files[paths.upload]);

			var tp = keystone.get('qiniu prefix') || '';

			if (tp.length) {
				tp += '_';
			}

			var uploadOptions = {
				tags: [tp + field.list.path + '_' + field.path, tp + field.list.path + '_' + field.path + '_' + item.id],
			};

			if (keystone.get('qiniu folders')) {
				uploadOptions.folder = item.get(paths.folder);
			}

			if (keystone.get('qiniu prefix')) {
				uploadOptions.tags.push(keystone.get('qiniu prefix'));
			}

			if (keystone.get('env') !== 'production') {
				uploadOptions.tags.push(tp + 'dev');
			}


			async.each(files, function (file, next) {

				if (!file.size) return next();

				var prefix = field.options.prefix || '';

				if (field.options.publicID) {
        			// using the value from another filed as image id
					var publicIdValue = item.get(field.options.publicID);
					if (publicIdValue) {
						uploadOptions.public_id = publicIdValue;
					}
				} else if (field.options.filenameAsPublicID) {
					uploadOptions.public_id = file.originalname.substring(0, file.originalname.lastIndexOf('.'));
				} else {
					// default id(UUID) is generated by file uploader (multer)
					uploadOptions.public_id = file.name;
				}
				uploadOptions.public_id = prefix + uploadOptions.public_id;
				console.log('uploadOptions = ', uploadOptions);
				//if (field.options.filenameAsPublicID) {
				//	uploadOptions.public_id = file.originalname.substring(0, file.originalname.lastIndexOf('.'));
				//}
				uploadOptions.originalname = file.originalname;
				uploadOptions.mimetype = file.mimetype;

				var config = keystone.get('qiniu config');
				qiniu.conf.ACCESS_KEY = config.access_key;
				qiniu.conf.SECRET_KEY = config.secret_key;

				var bucketName = field.options.bucket;
				var fileName = uploadOptions.public_id;

				var putPolicy = new qiniu.rs.PutPolicy();
				putPolicy.scope = bucketName + ':' + fileName;
				var token = putPolicy.token();

				var params = {
					originalname: uploadOptions.originalname
				};
				var putExtra = new qiniu.io.PutExtra(params);
				if (uploadOptions.mimetype) {
					putExtra.mimeType = uploadOptions.mimetype;
				}
				putExtra.check_crc = check_crc = 1;
				qiniu.io.putFile(token, fileName, file.path, putExtra, function(err, result) {
					if (err) {
						console.log('qiniu upload error = ', err);
						return next(err);
					}
					console.log('result = ', result);
					sizeOf(file.path, function(err, dimensions) {
						result.width = dimensions.width;
						result.height = dimensions.height;
						result.public_id = fileName;
						result.originalname = file.originalname;
						result.extension = file.extension;
						result.mimetype = file.mimetype;
						result.size = file.size;
						result.url = url.resolve(config.host, fileName);

						var imageView = new qiniu.fop.ImageView();
						imageView.width = 128;
						imageView.height = 128;
						result.thumb_url = imageView.makeRequest(result.url);
						if (config.secure_host) {
							result.secure_url = url.resolve(config.secure_host, fileName);
							result.secure_thumb_url = imageView.makeRequest(result.secure_url);
						}
						item.get(field.path).push(result);
						return next();
					});
				});

			}, function (err) {
				return callback(err);
			});
		} else {
			return callback();
		}
	};
};

/**
 * Immediately handles a standard form submission for the field (see `getRequestHandler()`)
 *
 * @api public
 */
qiniuimages.prototype.handleRequest = function (item, req, paths, callback) {
	this.getRequestHandler(item, req, paths, callback)();
};

/*!
 * Export class
 */
module.exports = qiniuimages;
