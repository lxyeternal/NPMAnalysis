'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

var _gsap = require('gsap');

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Animate = function () {
    function Animate(obj) {
        var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

        _classCallCheck(this, Animate);

        this.obj = obj;
        this.time = options.time ? options.time : 0.6;
        this.delay = options.delay ? options.delay : 0;
        this.onComplete = options.onComplete ? options.onComplete : '';
        this.type = options.type || 'zoomIn';
        this.setAnimation(this.type, this.onComplete);
    }

    _createClass(Animate, [{
        key: 'setAnimation',
        value: function setAnimation(type, callback) {
            var _this = this;

            switch (type) {
                case 'bounceInDown':
                    var animateSlideDown = new _gsap.TimelineMax();
                    this.obj.alpha = 0;
                    animateSlideDown.to(this.obj, 0.1, {
                        delay: this.delay,
                        y: this.obj.y - 3000
                    });
                    animateSlideDown.to(this.obj, this.time * 0.6, {
                        y: this.obj.y + 25,
                        alpha: 1
                    });
                    animateSlideDown.to(this.obj, this.time * 0.15, {
                        y: this.obj.y - 10
                    });
                    animateSlideDown.to(this.obj, this.time * 0.15, {
                        y: this.obj.y + 5
                    });
                    animateSlideDown.to(this.obj, this.time * 0.1, {
                        y: this.obj.y,
                        onComplete: function onComplete() {
                            if (_this.onComplete) {
                                callback();
                            }
                        }
                    });
                    break;
                case 'bounceOutDown':

                    var animateSlideOutDown = new _gsap.TimelineMax();
                    animateSlideOutDown.to(this.obj, this.time * 0.2, {
                        delay: this.delay,
                        ease: 'Quad',
                        y: this.obj.y + 10
                    });
                    animateSlideOutDown.to(this.obj, this.time * 0.25, {
                        y: this.obj.y - 20,
                        ease: 'Quad'
                    });
                    animateSlideOutDown.to(this.obj, this.time * 0.45, {
                        y: this.obj.y + 2000,
                        ease: 'Quad',
                        alpha: 0,
                        onComplete: function onComplete() {
                            if (_this.onComplete) {
                                callback();
                            }
                        }
                    });
                    break;
                case 'bounceInUp':
                    var animateBounceInUp = new _gsap.TimelineMax();
                    this.obj.alpha = 0;
                    animateBounceInUp.to(this.obj, this.time * 0.1, {
                        delay: this.delay,
                        y: this.obj.y + 3000
                    });
                    animateBounceInUp.to(this.obj, this.time * 0.6, {
                        y: this.obj.y - 20,
                        alpha: 1
                    });
                    animateBounceInUp.to(this.obj, this.time * 0.15, {
                        y: this.obj.y + 10
                    });
                    animateBounceInUp.to(this.obj, this.time * 0.15, {
                        y: this.obj.y - 5
                    });
                    animateBounceInUp.to(this.obj, this.time * 0.1, {
                        y: this.obj.y,
                        onComplete: function onComplete() {
                            if (_this.onComplete) {
                                callback();
                            }
                        }
                    });
                    break;
                case 'bounceIn':
                    var animateBounceIn = new _gsap.TimelineMax();
                    this.obj.alpha = 0;
                    animateBounceIn.to(this.obj, 0, {
                        delay: this.delay,
                        width: this.obj.width * 0.75,
                        height: this.obj.height * 0.75
                    });
                    this.obj.alpha = 1;
                    animateBounceIn.to(this.obj, this.time * 0.2, {
                        width: this.obj.width * 1.1,
                        height: this.obj.height * 1.1
                    });
                    animateBounceIn.to(this.obj, this.time * 0.2, {
                        width: this.obj.width * 0.95,
                        height: this.obj.height * 0.95
                    });
                    animateBounceIn.to(this.obj, this.time * 0.2, {
                        width: this.obj.width * 1.03,
                        height: this.obj.height * 1.03
                    });
                    animateBounceIn.to(this.obj, this.time * 0.2, {
                        width: this.obj.width * 0.97,
                        height: this.obj.height * 0.97
                    });
                    animateBounceIn.to(this.obj, this.time * 0.2, {
                        width: this.obj.width * 1,
                        height: this.obj.height * 1,
                        onComplete: function onComplete() {
                            if (_this.onComplete) {
                                callback();
                            }
                        }
                    });
                    break;
                case 'zoomIn':
                    this.obj.alpha = 1;
                    this.obj.width = this.obj.width * 0.5;
                    this.obj.height = this.obj.height * 0.5;
                    _gsap.TweenMax.to(this.obj, this.time * 0.5, {
                        width: this.obj.width * 2,
                        height: this.obj.height * 2,
                        delay: this.delay,
                        onComplete: function onComplete() {
                            if (_this.onComplete) {
                                callback();
                            }
                        }
                    });
                    break;
                case 'zoomOut':
                    this.obj.alpha = 1;
                    this.obj.width = this.obj.width * 1;
                    this.obj.height = this.obj.height * 1;
                    _gsap.TweenMax.to(this.obj, this.time * 0.5, {
                        width: this.obj.width * 0,
                        height: this.obj.height * 0,
                        delay: this.delay,
                        onComplete: function onComplete() {
                            if (_this.onComplete) {
                                callback();
                            }
                        }
                    });
                    break;
                case 'fadeIn':
                    this.obj.alpha = 0;
                    _gsap.TweenMax.to(this.obj, this.time, {
                        alpha: 1,
                        delay: this.delay,
                        onComplete: function onComplete() {
                            if (_this.onComplete) {
                                callback();
                            }
                        }
                    });
                    break;
                case 'fadeOut':
                    this.obj.alpha = 1;
                    _gsap.TweenMax.to(this.obj, this.time, {
                        alpha: 0,
                        delay: this.delay,
                        onComplete: function onComplete() {
                            if (_this.onComplete) {
                                callback();
                            }
                        }
                    });
                    break;
                case 'leftAndRight':
                    var animateLeftAndRight = new _gsap.TimelineMax();
                    animateLeftAndRight.to(this.obj, 0.05, {
                        x: this.obj.x - 10,
                        ease: 'linear'
                    });
                    animateLeftAndRight.to(this.obj, 0.1, {
                        x: this.obj.x + 10,
                        ease: 'linear'
                    });
                    animateLeftAndRight.to(this.obj, 0.1, {
                        x: this.obj.x - 10,
                        ease: 'linear'
                    });
                    animateLeftAndRight.to(this.obj, 0.1, {
                        x: this.obj.x + 10,
                        ease: 'linear'
                    });
                    animateLeftAndRight.to(this.obj, 0.1, {
                        x: this.obj.x - 10,
                        ease: 'linear'
                    });
                    animateLeftAndRight.to(this.obj, 0.1, {
                        x: this.obj.x + 10,
                        ease: 'linear'
                    });
                    animateLeftAndRight.to(this.obj, 0.05, {
                        x: this.obj.x,
                        ease: 'linear',
                        onComplete: function onComplete() {
                            if (_this.onComplete) {
                                callback();
                            }
                        }
                    });
                    break;
                case 'upAndDown':
                    var animateUpAndDown = new _gsap.TimelineMax();
                    animateUpAndDown.to(this.obj, 0.05, {
                        y: this.obj.y - 10,
                        ease: 'linear'
                    });
                    animateUpAndDown.to(this.obj, 0.1, {
                        y: this.obj.y + 10,
                        ease: 'linear'
                    });
                    animateUpAndDown.to(this.obj, 0.1, {
                        y: this.obj.y - 10,
                        ease: 'linear'
                    });
                    animateUpAndDown.to(this.obj, 0.1, {
                        y: this.obj.y + 10,
                        ease: 'linear'
                    });
                    animateUpAndDown.to(this.obj, 0.1, {
                        y: this.obj.y - 10,
                        ease: 'linear'
                    });
                    animateUpAndDown.to(this.obj, 0.1, {
                        y: this.obj.y + 10,
                        ease: 'linear'
                    });
                    animateUpAndDown.to(this.obj, 0.05, {
                        y: this.obj.y,
                        ease: 'linear',
                        onComplete: function onComplete() {
                            if (_this.onComplete) {
                                callback();
                            }
                        }
                    });
                    break;
                case 'redFlicker':
                    console.log(this.time, "TIME");
                    var animateRedFlicker = new _gsap.TimelineMax();
                    animateRedFlicker.to(this.obj, this.time * 0.15, {
                        alpha: 0.6,
                        ease: 'linear'
                    });
                    animateRedFlicker.to(this.obj, this.time * 0.15, {
                        alpha: 1,
                        ease: 'linear'
                    });
                    animateRedFlicker.to(this.obj, this.time * 0.15, {
                        alpha: 0.6,
                        ease: 'linear'
                    });
                    animateRedFlicker.to(this.obj, this.time * 0.15, {
                        alpha: 1,
                        ease: 'linear'
                    });
                    animateRedFlicker.to(this.obj, this.time * 0.15, {
                        alpha: 0.6,
                        ease: 'linear'
                    });
                    animateRedFlicker.to(this.obj, this.time * 0.15, {
                        alpha: 1,
                        ease: 'linear',
                        onComplete: function onComplete() {
                            if (_this.onComplete) {
                                callback();
                            }
                        }
                    });
                    break;
                case 'bomb':
                    var bombAndDown = new _gsap.TimelineMax();
                    this.obj.dataWidth = this.obj.width;
                    this.obj.dataHeight = this.obj.height;
                    bombAndDown.to(this.obj, 0.12, {
                        width: this.obj.dataWidth * 1.05,
                        height: this.obj.dataHeight * 0.96,
                        ease: 'linear'
                    });
                    bombAndDown.to(this.obj, 0.12, {
                        width: this.obj.dataWidth * 0.97,
                        height: this.obj.dataHeight * 1.03,
                        ease: 'linear'
                    });
                    bombAndDown.to(this.obj, 0.12, {
                        width: this.obj.dataWidth * 1.02,
                        height: this.obj.dataHeight * 0.98,
                        ease: 'linear'
                    });
                    bombAndDown.to(this.obj, 0.12, {
                        width: this.obj.dataWidth * 0.99,
                        height: this.obj.dataHeight * 1.01,
                        ease: 'linear'
                    });
                    bombAndDown.to(this.obj, 0.12, {
                        width: this.obj.dataWidth * 1,
                        height: this.obj.dataHeight * 1,
                        ease: 'linear',
                        onComplete: function onComplete() {
                            if (_this.onComplete) {
                                callback();
                            }
                        }
                    });
                    break;
                default:
                    break;
            }
        }
    }]);

    return Animate;
}();

exports.default = Animate;
