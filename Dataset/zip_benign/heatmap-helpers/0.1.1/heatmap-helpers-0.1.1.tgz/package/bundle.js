"use strict";
(() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __commonJS = (cb, mod) => function __require() {
    return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));

  // node_modules/.pnpm/heatmap-values@1.0.3/node_modules/heatmap-values/dist/index.js
  var require_dist = __commonJS({
    "node_modules/.pnpm/heatmap-values@1.0.3/node_modules/heatmap-values/dist/index.js"(exports) {
      "use strict";
      Object.defineProperty(exports, "__esModule", { value: true });
      exports.heatmap_schemes = void 0;
      exports.generate_heatmap_values = generate_heatmap_values2;
      exports.heatmap_schemes = {
        red_green_blue: {
          low: [0, 0, 255, 1],
          middle: [0, 255, 0, 1],
          high: [255, 0, 0, 1]
        },
        red_transparent_blue: {
          low: [0, 0, 255, 1],
          middle: [0, 0, 0, 0],
          high: [255, 0, 0, 1]
        },
        hot_only: {
          low: [0, 0, 255, 0],
          middle: [0, 0, 0, 0],
          high: [255, 0, 0, 1]
        },
        cold_only: {
          low: [0, 0, 255, 1],
          middle: [0, 0, 0, 0],
          high: [255, 0, 0, 0]
        }
      };
      function generate_heatmap_values2(scheme = exports.heatmap_schemes.red_transparent_blue) {
        let values = new Array(256);
        for (let i = 0; i < 256; i++) {
          let value = i / 255;
          let color = [0, 0, 0, 0];
          let is_transparent = scheme.middle[3] == 0;
          for (let i2 = 0; i2 < 4; i2++) {
            if (value < 0.5) {
              let low = 1 - value * 2;
              let middle = 1 - low;
              let c = is_transparent && i2 != 3 ? scheme.low[i2] : scheme.low[i2] * low + scheme.middle[i2] * middle;
              color[i2] = i2 == 3 ? c : Math.floor(c);
            } else {
              let high = 2 * (value - 0.5);
              let middle = 1 - high;
              let c = is_transparent && i2 != 3 ? scheme.high[i2] : scheme.high[i2] * high + scheme.middle[i2] * middle;
              color[i2] = i2 == 3 ? c : Math.floor(c);
            }
          }
          values[i] = color;
        }
        return values;
      }
    }
  });

  // index.ts
  var heatmap_helpers_exports = {};
  __export(heatmap_helpers_exports, {
    build_heatmap: () => build_heatmap,
    calc_mean_color: () => calc_mean_color,
    occlude_rect: () => occlude_rect,
    pick_occlusion_color: () => pick_occlusion_color,
    restore_rect: () => restore_rect,
    sleep: () => sleep,
    xy_to_offset: () => xy_to_offset
  });
  var import_heatmap_values = __toESM(require_dist());
  var heatmap_values = (0, import_heatmap_values.generate_heatmap_values)(
    import_heatmap_values.heatmap_schemes.red_transparent_blue
  );
  for (let i = 0; i < 256; i++) {
    heatmap_values[i][3] *= 255;
  }
  var { abs, round, floor, ceil, max } = Math;
  function xy_to_offset(rect, x, y) {
    return (y * rect.width + x) * 4;
  }
  function calc_mean_color(imageData, x, y, w, h) {
    let r = 0;
    let g = 0;
    let b = 0;
    let offset = xy_to_offset(imageData, x, y);
    for (let i = 0; i < h; i++) {
      for (let j = 0; j < w; j++) {
        r += imageData.data[offset + 0];
        g += imageData.data[offset + 1];
        b += imageData.data[offset + 2];
        offset += 4;
      }
      offset = offset - w * 4 + imageData.width * 4;
    }
    let n = w * h;
    r = floor(r / n);
    g = floor(g / n);
    b = floor(b / n);
    return [r, g, b];
  }
  function pick_occlusion_color(mean_color) {
    let black_dist = mean_color[0] ** 2 + mean_color[1] ** 2 + mean_color[2] ** 2;
    let white_dist = (255 - mean_color[0]) ** 2 + (255 - mean_color[1]) ** 2 + (255 - mean_color[2]) ** 2;
    let gray_dist = (127 - mean_color[0]) ** 2 + (127 - mean_color[1]) ** 2 + (127 - mean_color[2]) ** 2;
    if (black_dist > white_dist && black_dist > gray_dist) {
      return 0;
    }
    if (white_dist > black_dist && white_dist > gray_dist) {
      return 255;
    }
    return 127;
  }
  var occlusion_weights = [];
  function get_occlusion_weights(w, h) {
    if (!(w in occlusion_weights)) {
      occlusion_weights[w] = [];
    }
    let h_weights = occlusion_weights[w];
    if (h in h_weights) {
      return h_weights[h];
    }
    let weights = new Array(w * h);
    let h_2 = h / 2;
    let w_2 = w / 2;
    let i = 0;
    for (let dy = 0; dy < h; dy++) {
      let weight_y = ((dy - h_2) / h_2) ** 2;
      for (let dx = 0; dx < w; dx++) {
        let weight_x = ((dx - w_2) / w_2) ** 2;
        let weight = 1 - max(weight_x, weight_y);
        weights[i] = weight;
        i++;
      }
    }
    h_weights[h] = weights;
    return weights;
  }
  function occlude_rect(imageData, occlusion_weights2, x, y, w, h) {
    let mean_color = calc_mean_color(imageData, x, y, w, h);
    let occlusion_color = pick_occlusion_color(mean_color);
    let offset = xy_to_offset(imageData, x, y);
    let backup = imageData.data.slice(
      offset,
      offset + imageData.width * imageData.height * 4
    );
    let offset_by_line = -w * 4 + imageData.width * 4;
    let backup_offset = 0;
    let weight_offset = 0;
    for (let dy = 0; dy < h; dy++) {
      for (let dx = 0; dx < w; dx++) {
        let weight = occlusion_weights2[weight_offset];
        for (let i = 0; i < 3; i++) {
          let value = imageData.data[offset + i];
          backup[backup_offset + i] = value;
          imageData.data[offset + i] = floor(
            weight * occlusion_color + (1 - weight) * value
          );
        }
        offset += 4;
        backup_offset += 4;
        weight_offset++;
      }
      offset += offset_by_line;
    }
    return backup;
  }
  function restore_rect(imageData, backup, x, y, w, h) {
    let offset = xy_to_offset(imageData, x, y);
    let offset_by_line = -w * 4 + imageData.width * 4;
    let backup_offset = 0;
    for (let i = 0; i < h; i++) {
      for (let j = 0; j < w; j++) {
        imageData.data[offset + 0] = backup[backup_offset + 0];
        imageData.data[offset + 1] = backup[backup_offset + 1];
        imageData.data[offset + 2] = backup[backup_offset + 2];
        offset += 4;
        backup_offset += 4;
      }
      offset += offset_by_line;
    }
  }
  function calc_slide(total_size, slide) {
    slide = ceil(slide);
    let count = ceil((total_size - slide) / slide);
    slide = ceil((total_size - slide) / count);
    return slide;
  }
  var slide_interval = 0;
  async function build_heatmap(args) {
    let { calc_score, should_zoom } = args;
    let slide_ratio = args.slide_ratio || 0.5;
    let min_grid_width = args.min_grid_width || 5;
    let min_grid_height = args.min_grid_height || 5;
    let image_canvas = args.image_canvas;
    let image_context = image_canvas.getContext("2d");
    let image_data = image_context.getImageData(
      0,
      0,
      image_canvas.width,
      image_canvas.height
    );
    let heatmap_canvas = args.heatmap_canvas;
    let heatmap_context = heatmap_canvas.getContext("2d");
    let heatmap_data = heatmap_context.getImageData(
      0,
      0,
      heatmap_canvas.width,
      heatmap_canvas.height
    );
    heatmap_data.data.fill(255);
    let heatmap_buffer_canvas = document.createElement("canvas");
    let heatmap_buffer_context = heatmap_buffer_canvas.getContext("2d");
    let context = {
      canvas: image_canvas,
      context: image_context,
      image_data
    };
    async function loop_region(left, top, width, height, w2, h2) {
      let occlusion_weights2 = get_occlusion_weights(w2, h2);
      heatmap_buffer_canvas.width = w2;
      heatmap_buffer_canvas.height = h2;
      let heatmap_buffer_image_data = heatmap_buffer_context.getImageData(
        0,
        0,
        w2,
        h2
      );
      function add_heatmap_sample(sample) {
        let { x, y, w: w3, h: h3, score } = sample;
        let weights = get_occlusion_weights(w3, h3);
        if (score) {
        }
        let offset = 0;
        let offset_by_line = -w3 * 4 + heatmap_buffer_image_data.width * 4;
        let i = 0;
        for (let dy = 0; dy < h3; dy++) {
          for (let dx = 0; dx < w3; dx++) {
            let weight = weights[i];
            let value = round(score * 255);
            let color = heatmap_values[value];
            heatmap_buffer_image_data.data[offset + 0] = color[0];
            heatmap_buffer_image_data.data[offset + 1] = color[1];
            heatmap_buffer_image_data.data[offset + 2] = color[2];
            heatmap_buffer_image_data.data[offset + 3] = color[3] * weight;
            i++;
            offset += 4;
          }
          offset += offset_by_line;
        }
        heatmap_buffer_context.putImageData(heatmap_buffer_image_data, 0, 0);
        heatmap_context.drawImage(heatmap_buffer_canvas, x, y, w3, h3);
      }
      async function tick(x, y) {
        let backup = occlude_rect(image_data, occlusion_weights2, x, y, w2, h2);
        image_context.putImageData(image_data, 0, 0);
        let score = await calc_score(context);
        add_heatmap_sample({ x, y, w: w2, h: h2, score });
        let new_width = w2;
        let new_height = h2;
        let new_w = ceil(new_width / 2);
        let new_h = ceil(new_height / 2);
        if (new_w >= min_grid_width && new_h >= min_grid_height && new_w != w2 && new_h != h2 && should_zoom(score)) {
          add_region([x, y, new_width, new_height, new_w, new_h]);
        }
        await sleep(slide_interval);
        restore_rect(image_data, backup, x, y, w2, h2);
        image_context.putImageData(image_data, 0, 0);
      }
      async function loop_x(y) {
        for (let x = left; x - left + w2 <= width; ) {
          await tick(x, y);
          x += x_slide;
          if (x - left == width) {
            break;
          }
          if (x - left + w2 > width) {
            x = left + width - w2;
            await tick(x, y);
            break;
          }
        }
      }
      let y_slide = calc_slide(height, h2 * slide_ratio);
      let x_slide = calc_slide(width, w2 * slide_ratio);
      for (let y = top; y - top + h2 <= height; ) {
        await loop_x(y);
        y += y_slide;
        if (y - top == height) {
          break;
        }
        if (y - top + h2 > height) {
          y = top + height - h2;
          await loop_x(y);
          break;
        }
      }
    }
    let w = ceil(args.max_grid_height || image_canvas.width / 2);
    let h = ceil(args.max_grid_width || image_canvas.height / 2);
    let regions = [
      [0, 0, image_canvas.width, image_canvas.height, w, h]
    ];
    function add_region(region) {
      regions.push(region);
    }
    for (; ; ) {
      let [region] = regions.splice(0, 1);
      if (!region) break;
      let [x, y, width, height, w2, h2] = region;
      await loop_region(x, y, width, height, w2, h2);
      image_data = image_context.getImageData(
        0,
        0,
        image_canvas.width,
        image_canvas.height
      );
      await sleep(1);
    }
  }
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  // browser.ts
  Object.assign(window, { heatmap_helpers: heatmap_helpers_exports });
})();
