'use strict';

var _require = require('acolor'),
    rotate = _require.rotate;

var Color = require('color');
/**
 * Get rotated colors for color
 * @memberof module:@the-/util-color
 * @function rotatedColorsFor
 * @param {string} [base='#38E'] - Base color
 * @param {Object} [options={}] - Optional settings
 * @param {number} [options.count=12] - Count of colors
 * @param {boolean} [options.sort=false] - Should sort result by hue
 * @returns {string[]} Colors
 */


function rotatedColorsFor() {
  var base = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : '#38E';
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var _options$count = options.count,
      count = _options$count === void 0 ? 12 : _options$count,
      _options$sort = options.sort,
      sort = _options$sort === void 0 ? false : _options$sort;
  var colors = new Array(count).fill(null).map(function (_, i, arr) {
    return rotate(base, parseInt(360 * i / arr.length), {
      lch: true
    });
  });

  if (sort) {
    return colors.sort(function (a, b) {
      return Color(a).hue() - Color(b).hue();
    });
  }

  return colors;
}

module.exports = rotatedColorsFor;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInJvdGF0ZWRDb2xvcnNGb3IuanMiXSwibmFtZXMiOlsicmVxdWlyZSIsInJvdGF0ZSIsIkNvbG9yIiwicm90YXRlZENvbG9yc0ZvciIsImJhc2UiLCJvcHRpb25zIiwiY291bnQiLCJzb3J0IiwiY29sb3JzIiwiQXJyYXkiLCJmaWxsIiwibWFwIiwiXyIsImkiLCJhcnIiLCJwYXJzZUludCIsImxlbmd0aCIsImxjaCIsImEiLCJiIiwiaHVlIiwibW9kdWxlIiwiZXhwb3J0cyJdLCJtYXBwaW5ncyI6IkFBQUE7O2VBRW1CQSxPQUFPLENBQUMsUUFBRCxDO0lBQWxCQyxNLFlBQUFBLE07O0FBQ1IsSUFBTUMsS0FBSyxHQUFHRixPQUFPLENBQUMsT0FBRCxDQUFyQjtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDQSxTQUFTRyxnQkFBVCxHQUF1RDtBQUFBLE1BQTdCQyxJQUE2Qix1RUFBdEIsTUFBc0I7QUFBQSxNQUFkQyxPQUFjLHVFQUFKLEVBQUk7QUFBQSx1QkFDaEJBLE9BRGdCLENBQzdDQyxLQUQ2QztBQUFBLE1BQzdDQSxLQUQ2QywrQkFDckMsRUFEcUM7QUFBQSxzQkFDaEJELE9BRGdCLENBQ2pDRSxJQURpQztBQUFBLE1BQ2pDQSxJQURpQyw4QkFDMUIsS0FEMEI7QUFFckQsTUFBTUMsTUFBTSxHQUFHLElBQUlDLEtBQUosQ0FBVUgsS0FBVixFQUFpQkksSUFBakIsQ0FBc0IsSUFBdEIsRUFBNEJDLEdBQTVCLENBQWdDLFVBQUNDLENBQUQsRUFBSUMsQ0FBSixFQUFPQyxHQUFQO0FBQUEsV0FDN0NiLE1BQU0sQ0FBQ0csSUFBRCxFQUFPVyxRQUFRLENBQUUsTUFBTUYsQ0FBUCxHQUFZQyxHQUFHLENBQUNFLE1BQWpCLENBQWYsRUFBeUM7QUFDN0NDLE1BQUFBLEdBQUcsRUFBRTtBQUR3QyxLQUF6QyxDQUR1QztBQUFBLEdBQWhDLENBQWY7O0FBS0EsTUFBSVYsSUFBSixFQUFVO0FBQ1IsV0FBT0MsTUFBTSxDQUFDRCxJQUFQLENBQVksVUFBQ1csQ0FBRCxFQUFJQyxDQUFKO0FBQUEsYUFBVWpCLEtBQUssQ0FBQ2dCLENBQUQsQ0FBTCxDQUFTRSxHQUFULEtBQWlCbEIsS0FBSyxDQUFDaUIsQ0FBRCxDQUFMLENBQVNDLEdBQVQsRUFBM0I7QUFBQSxLQUFaLENBQVA7QUFDRDs7QUFFRCxTQUFPWixNQUFQO0FBQ0Q7O0FBRURhLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQm5CLGdCQUFqQiIsInNvdXJjZVJvb3QiOiIuLi9saWIiLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIHN0cmljdCdcblxuY29uc3QgeyByb3RhdGUgfSA9IHJlcXVpcmUoJ2Fjb2xvcicpXG5jb25zdCBDb2xvciA9IHJlcXVpcmUoJ2NvbG9yJylcblxuLyoqXG4gKiBHZXQgcm90YXRlZCBjb2xvcnMgZm9yIGNvbG9yXG4gKiBAbWVtYmVyb2YgbW9kdWxlOkB0aGUtL3V0aWwtY29sb3JcbiAqIEBmdW5jdGlvbiByb3RhdGVkQ29sb3JzRm9yXG4gKiBAcGFyYW0ge3N0cmluZ30gW2Jhc2U9JyMzOEUnXSAtIEJhc2UgY29sb3JcbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucz17fV0gLSBPcHRpb25hbCBzZXR0aW5nc1xuICogQHBhcmFtIHtudW1iZXJ9IFtvcHRpb25zLmNvdW50PTEyXSAtIENvdW50IG9mIGNvbG9yc1xuICogQHBhcmFtIHtib29sZWFufSBbb3B0aW9ucy5zb3J0PWZhbHNlXSAtIFNob3VsZCBzb3J0IHJlc3VsdCBieSBodWVcbiAqIEByZXR1cm5zIHtzdHJpbmdbXX0gQ29sb3JzXG4gKi9cbmZ1bmN0aW9uIHJvdGF0ZWRDb2xvcnNGb3IoYmFzZSA9ICcjMzhFJywgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHsgY291bnQgPSAxMiwgc29ydCA9IGZhbHNlIH0gPSBvcHRpb25zXG4gIGNvbnN0IGNvbG9ycyA9IG5ldyBBcnJheShjb3VudCkuZmlsbChudWxsKS5tYXAoKF8sIGksIGFycikgPT5cbiAgICByb3RhdGUoYmFzZSwgcGFyc2VJbnQoKDM2MCAqIGkpIC8gYXJyLmxlbmd0aCksIHtcbiAgICAgIGxjaDogdHJ1ZSxcbiAgICB9KSxcbiAgKVxuICBpZiAoc29ydCkge1xuICAgIHJldHVybiBjb2xvcnMuc29ydCgoYSwgYikgPT4gQ29sb3IoYSkuaHVlKCkgLSBDb2xvcihiKS5odWUoKSlcbiAgfVxuXG4gIHJldHVybiBjb2xvcnNcbn1cblxubW9kdWxlLmV4cG9ydHMgPSByb3RhdGVkQ29sb3JzRm9yXG4iXX0=