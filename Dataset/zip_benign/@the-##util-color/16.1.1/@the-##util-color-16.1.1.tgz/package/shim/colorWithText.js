'use strict';

var _require = require('acolor'),
    rotate = _require.rotate;
/**
 * Get color with text
 * @memberof module:@the-/util-color
 * @function colorWithText
 * @param {string} text - Text
 * @param {Object} [options={}] - Optional settings
 * @returns {string} Color
 */


function colorWithText(text) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var _options$base = options.base,
      base = _options$base === void 0 ? '#38E' : _options$base;
  var value = String(text).split('').map(function (letter) {
    return letter.charCodeAt(0);
  }).reduce(function (result, value) {
    return result + value;
  }, 0);
  return rotate(base, parseInt(value % 360.0), {
    lch: true
  });
}

colorWithText.of = function colorWithTextOf(base) {
  var cache = {};
  return function bound(text) {
    var cached = cache[text];

    if (cached) {
      return cached;
    }

    var generated = colorWithText(text, {
      base: base
    });
    cache[text] = generated;
    return generated;
  };
};

module.exports = colorWithText;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbG9yV2l0aFRleHQuanMiXSwibmFtZXMiOlsicmVxdWlyZSIsInJvdGF0ZSIsImNvbG9yV2l0aFRleHQiLCJ0ZXh0Iiwib3B0aW9ucyIsImJhc2UiLCJ2YWx1ZSIsIlN0cmluZyIsInNwbGl0IiwibWFwIiwibGV0dGVyIiwiY2hhckNvZGVBdCIsInJlZHVjZSIsInJlc3VsdCIsInBhcnNlSW50IiwibGNoIiwib2YiLCJjb2xvcldpdGhUZXh0T2YiLCJjYWNoZSIsImJvdW5kIiwiY2FjaGVkIiwiZ2VuZXJhdGVkIiwibW9kdWxlIiwiZXhwb3J0cyJdLCJtYXBwaW5ncyI6IkFBQUE7O2VBRW1CQSxPQUFPLENBQUMsUUFBRCxDO0lBQWxCQyxNLFlBQUFBLE07QUFFUjs7Ozs7Ozs7OztBQVFBLFNBQVNDLGFBQVQsQ0FBdUJDLElBQXZCLEVBQTJDO0FBQUEsTUFBZEMsT0FBYyx1RUFBSixFQUFJO0FBQUEsc0JBQ2ZBLE9BRGUsQ0FDakNDLElBRGlDO0FBQUEsTUFDakNBLElBRGlDLDhCQUMxQixNQUQwQjtBQUV6QyxNQUFNQyxLQUFLLEdBQUdDLE1BQU0sQ0FBQ0osSUFBRCxDQUFOLENBQ1hLLEtBRFcsQ0FDTCxFQURLLEVBRVhDLEdBRlcsQ0FFUCxVQUFDQyxNQUFEO0FBQUEsV0FBWUEsTUFBTSxDQUFDQyxVQUFQLENBQWtCLENBQWxCLENBQVo7QUFBQSxHQUZPLEVBR1hDLE1BSFcsQ0FHSixVQUFDQyxNQUFELEVBQVNQLEtBQVQ7QUFBQSxXQUFtQk8sTUFBTSxHQUFHUCxLQUE1QjtBQUFBLEdBSEksRUFHK0IsQ0FIL0IsQ0FBZDtBQUlBLFNBQU9MLE1BQU0sQ0FBQ0ksSUFBRCxFQUFPUyxRQUFRLENBQUNSLEtBQUssR0FBRyxLQUFULENBQWYsRUFBZ0M7QUFDM0NTLElBQUFBLEdBQUcsRUFBRTtBQURzQyxHQUFoQyxDQUFiO0FBR0Q7O0FBRURiLGFBQWEsQ0FBQ2MsRUFBZCxHQUFtQixTQUFTQyxlQUFULENBQXlCWixJQUF6QixFQUErQjtBQUNoRCxNQUFNYSxLQUFLLEdBQUcsRUFBZDtBQUNBLFNBQU8sU0FBU0MsS0FBVCxDQUFlaEIsSUFBZixFQUFxQjtBQUMxQixRQUFNaUIsTUFBTSxHQUFHRixLQUFLLENBQUNmLElBQUQsQ0FBcEI7O0FBQ0EsUUFBSWlCLE1BQUosRUFBWTtBQUNWLGFBQU9BLE1BQVA7QUFDRDs7QUFFRCxRQUFNQyxTQUFTLEdBQUduQixhQUFhLENBQUNDLElBQUQsRUFBTztBQUFFRSxNQUFBQSxJQUFJLEVBQUpBO0FBQUYsS0FBUCxDQUEvQjtBQUNBYSxJQUFBQSxLQUFLLENBQUNmLElBQUQsQ0FBTCxHQUFja0IsU0FBZDtBQUNBLFdBQU9BLFNBQVA7QUFDRCxHQVREO0FBVUQsQ0FaRDs7QUFjQUMsTUFBTSxDQUFDQyxPQUFQLEdBQWlCckIsYUFBakIiLCJzb3VyY2VSb290IjoiLi4vbGliIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IHsgcm90YXRlIH0gPSByZXF1aXJlKCdhY29sb3InKVxuXG4vKipcbiAqIEdldCBjb2xvciB3aXRoIHRleHRcbiAqIEBtZW1iZXJvZiBtb2R1bGU6QHRoZS0vdXRpbC1jb2xvclxuICogQGZ1bmN0aW9uIGNvbG9yV2l0aFRleHRcbiAqIEBwYXJhbSB7c3RyaW5nfSB0ZXh0IC0gVGV4dFxuICogQHBhcmFtIHtPYmplY3R9IFtvcHRpb25zPXt9XSAtIE9wdGlvbmFsIHNldHRpbmdzXG4gKiBAcmV0dXJucyB7c3RyaW5nfSBDb2xvclxuICovXG5mdW5jdGlvbiBjb2xvcldpdGhUZXh0KHRleHQsIG9wdGlvbnMgPSB7fSkge1xuICBjb25zdCB7IGJhc2UgPSAnIzM4RScgfSA9IG9wdGlvbnNcbiAgY29uc3QgdmFsdWUgPSBTdHJpbmcodGV4dClcbiAgICAuc3BsaXQoJycpXG4gICAgLm1hcCgobGV0dGVyKSA9PiBsZXR0ZXIuY2hhckNvZGVBdCgwKSlcbiAgICAucmVkdWNlKChyZXN1bHQsIHZhbHVlKSA9PiByZXN1bHQgKyB2YWx1ZSwgMClcbiAgcmV0dXJuIHJvdGF0ZShiYXNlLCBwYXJzZUludCh2YWx1ZSAlIDM2MC4wKSwge1xuICAgIGxjaDogdHJ1ZSxcbiAgfSlcbn1cblxuY29sb3JXaXRoVGV4dC5vZiA9IGZ1bmN0aW9uIGNvbG9yV2l0aFRleHRPZihiYXNlKSB7XG4gIGNvbnN0IGNhY2hlID0ge31cbiAgcmV0dXJuIGZ1bmN0aW9uIGJvdW5kKHRleHQpIHtcbiAgICBjb25zdCBjYWNoZWQgPSBjYWNoZVt0ZXh0XVxuICAgIGlmIChjYWNoZWQpIHtcbiAgICAgIHJldHVybiBjYWNoZWRcbiAgICB9XG5cbiAgICBjb25zdCBnZW5lcmF0ZWQgPSBjb2xvcldpdGhUZXh0KHRleHQsIHsgYmFzZSB9KVxuICAgIGNhY2hlW3RleHRdID0gZ2VuZXJhdGVkXG4gICAgcmV0dXJuIGdlbmVyYXRlZFxuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gY29sb3JXaXRoVGV4dFxuIl19