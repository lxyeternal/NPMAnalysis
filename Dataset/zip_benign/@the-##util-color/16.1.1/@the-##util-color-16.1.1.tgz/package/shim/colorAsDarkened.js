'use strict';

var _require = require('acolor'),
    darken = _require.darken,
    isDark = _require.isDark;
/**
 * Make sure a color is dark enough to work with while
 * @param {string} color
 * @param {Object} [options={}] - Optional settings
 * @returns {?string}
 */


function colorAsDarkened(color) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var _options$tryAmount = options.tryAmount,
      tryAmount = _options$tryAmount === void 0 ? 0.05 : _options$tryAmount,
      _options$tryMaxCount = options.tryMaxCount,
      tryMaxCount = _options$tryMaxCount === void 0 ? 10 : _options$tryMaxCount;

  if (!color) {
    return null;
  }

  for (var i = 0; i < tryMaxCount; i++) {
    var enough = isDark(color);

    if (enough) {
      return color;
    }

    color = darken(color, tryAmount);
  }

  return color;
}

module.exports = colorAsDarkened;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbG9yQXNEYXJrZW5lZC5qcyJdLCJuYW1lcyI6WyJyZXF1aXJlIiwiZGFya2VuIiwiaXNEYXJrIiwiY29sb3JBc0RhcmtlbmVkIiwiY29sb3IiLCJvcHRpb25zIiwidHJ5QW1vdW50IiwidHJ5TWF4Q291bnQiLCJpIiwiZW5vdWdoIiwibW9kdWxlIiwiZXhwb3J0cyJdLCJtYXBwaW5ncyI6IkFBQUE7O2VBRTJCQSxPQUFPLENBQUMsUUFBRCxDO0lBQTFCQyxNLFlBQUFBLE07SUFBUUMsTSxZQUFBQSxNO0FBRWhCOzs7Ozs7OztBQU1BLFNBQVNDLGVBQVQsQ0FBeUJDLEtBQXpCLEVBQThDO0FBQUEsTUFBZEMsT0FBYyx1RUFBSixFQUFJO0FBQUEsMkJBQ0dBLE9BREgsQ0FDcENDLFNBRG9DO0FBQUEsTUFDcENBLFNBRG9DLG1DQUN4QixJQUR3QjtBQUFBLDZCQUNHRCxPQURILENBQ2xCRSxXQURrQjtBQUFBLE1BQ2xCQSxXQURrQixxQ0FDSixFQURJOztBQUU1QyxNQUFJLENBQUNILEtBQUwsRUFBWTtBQUNWLFdBQU8sSUFBUDtBQUNEOztBQUVELE9BQUssSUFBSUksQ0FBQyxHQUFHLENBQWIsRUFBZ0JBLENBQUMsR0FBR0QsV0FBcEIsRUFBaUNDLENBQUMsRUFBbEMsRUFBc0M7QUFDcEMsUUFBTUMsTUFBTSxHQUFHUCxNQUFNLENBQUNFLEtBQUQsQ0FBckI7O0FBQ0EsUUFBSUssTUFBSixFQUFZO0FBQ1YsYUFBT0wsS0FBUDtBQUNEOztBQUVEQSxJQUFBQSxLQUFLLEdBQUdILE1BQU0sQ0FBQ0csS0FBRCxFQUFRRSxTQUFSLENBQWQ7QUFDRDs7QUFDRCxTQUFPRixLQUFQO0FBQ0Q7O0FBRURNLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQlIsZUFBakIiLCJzb3VyY2VSb290IjoiLi4vbGliIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IHsgZGFya2VuLCBpc0RhcmsgfSA9IHJlcXVpcmUoJ2Fjb2xvcicpXG5cbi8qKlxuICogTWFrZSBzdXJlIGEgY29sb3IgaXMgZGFyayBlbm91Z2ggdG8gd29yayB3aXRoIHdoaWxlXG4gKiBAcGFyYW0ge3N0cmluZ30gY29sb3JcbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucz17fV0gLSBPcHRpb25hbCBzZXR0aW5nc1xuICogQHJldHVybnMgez9zdHJpbmd9XG4gKi9cbmZ1bmN0aW9uIGNvbG9yQXNEYXJrZW5lZChjb2xvciwgb3B0aW9ucyA9IHt9KSB7XG4gIGNvbnN0IHsgdHJ5QW1vdW50ID0gMC4wNSwgdHJ5TWF4Q291bnQgPSAxMCB9ID0gb3B0aW9uc1xuICBpZiAoIWNvbG9yKSB7XG4gICAgcmV0dXJuIG51bGxcbiAgfVxuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgdHJ5TWF4Q291bnQ7IGkrKykge1xuICAgIGNvbnN0IGVub3VnaCA9IGlzRGFyayhjb2xvcilcbiAgICBpZiAoZW5vdWdoKSB7XG4gICAgICByZXR1cm4gY29sb3JcbiAgICB9XG5cbiAgICBjb2xvciA9IGRhcmtlbihjb2xvciwgdHJ5QW1vdW50KVxuICB9XG4gIHJldHVybiBjb2xvclxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGNvbG9yQXNEYXJrZW5lZFxuIl19