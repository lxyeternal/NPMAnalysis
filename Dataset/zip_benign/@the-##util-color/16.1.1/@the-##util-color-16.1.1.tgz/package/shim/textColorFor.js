'use strict';

var _require = require('acolor'),
    isDark = _require.isDark;
/**
 * Get text color for background color
 * @memberof module:@the-/util-color
 * @function textColorFor
 * @param {string} backgroundColor
 * @param {Object} [options={}]
 * @returns {?string} Text color
 */


function textColorFor(backgroundColor) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  if (!backgroundColor) {
    return null;
  }

  var _options$forDark = options.forDark,
      forDark = _options$forDark === void 0 ? '#FFFFFF' : _options$forDark,
      _options$forLight = options.forLight,
      forLight = _options$forLight === void 0 ? '#333333' : _options$forLight;

  try {
    return isDark(backgroundColor) ? forDark : forLight;
  } catch (e) {
    return forLight;
  }
}

module.exports = textColorFor;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRleHRDb2xvckZvci5qcyJdLCJuYW1lcyI6WyJyZXF1aXJlIiwiaXNEYXJrIiwidGV4dENvbG9yRm9yIiwiYmFja2dyb3VuZENvbG9yIiwib3B0aW9ucyIsImZvckRhcmsiLCJmb3JMaWdodCIsImUiLCJtb2R1bGUiLCJleHBvcnRzIl0sIm1hcHBpbmdzIjoiQUFBQTs7ZUFFbUJBLE9BQU8sQ0FBQyxRQUFELEM7SUFBbEJDLE0sWUFBQUEsTTtBQUVSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUNBLFNBQVNDLFlBQVQsQ0FBc0JDLGVBQXRCLEVBQXFEO0FBQUEsTUFBZEMsT0FBYyx1RUFBSixFQUFJOztBQUNuRCxNQUFJLENBQUNELGVBQUwsRUFBc0I7QUFDcEIsV0FBTyxJQUFQO0FBQ0Q7O0FBSGtELHlCQUtHQyxPQUxILENBSzNDQyxPQUwyQztBQUFBLE1BSzNDQSxPQUwyQyxpQ0FLakMsU0FMaUM7QUFBQSwwQkFLR0QsT0FMSCxDQUt0QkUsUUFMc0I7QUFBQSxNQUt0QkEsUUFMc0Isa0NBS1gsU0FMVzs7QUFPbkQsTUFBSTtBQUNGLFdBQU9MLE1BQU0sQ0FBQ0UsZUFBRCxDQUFOLEdBQTBCRSxPQUExQixHQUFvQ0MsUUFBM0M7QUFDRCxHQUZELENBRUUsT0FBT0MsQ0FBUCxFQUFVO0FBQ1YsV0FBT0QsUUFBUDtBQUNEO0FBQ0Y7O0FBRURFLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQlAsWUFBakIiLCJzb3VyY2VSb290IjoiLi4vbGliIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBzdHJpY3QnXG5cbmNvbnN0IHsgaXNEYXJrIH0gPSByZXF1aXJlKCdhY29sb3InKVxuXG4vKipcbiAqIEdldCB0ZXh0IGNvbG9yIGZvciBiYWNrZ3JvdW5kIGNvbG9yXG4gKiBAbWVtYmVyb2YgbW9kdWxlOkB0aGUtL3V0aWwtY29sb3JcbiAqIEBmdW5jdGlvbiB0ZXh0Q29sb3JGb3JcbiAqIEBwYXJhbSB7c3RyaW5nfSBiYWNrZ3JvdW5kQ29sb3JcbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9ucz17fV1cbiAqIEByZXR1cm5zIHs/c3RyaW5nfSBUZXh0IGNvbG9yXG4gKi9cbmZ1bmN0aW9uIHRleHRDb2xvckZvcihiYWNrZ3JvdW5kQ29sb3IsIG9wdGlvbnMgPSB7fSkge1xuICBpZiAoIWJhY2tncm91bmRDb2xvcikge1xuICAgIHJldHVybiBudWxsXG4gIH1cblxuICBjb25zdCB7IGZvckRhcmsgPSAnI0ZGRkZGRicsIGZvckxpZ2h0ID0gJyMzMzMzMzMnIH0gPSBvcHRpb25zXG5cbiAgdHJ5IHtcbiAgICByZXR1cm4gaXNEYXJrKGJhY2tncm91bmRDb2xvcikgPyBmb3JEYXJrIDogZm9yTGlnaHRcbiAgfSBjYXRjaCAoZSkge1xuICAgIHJldHVybiBmb3JMaWdodFxuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gdGV4dENvbG9yRm9yXG4iXX0=