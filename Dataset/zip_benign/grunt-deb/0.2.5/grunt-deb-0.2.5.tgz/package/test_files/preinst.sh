echo "Before installation"
