export const binName = 'svm'
