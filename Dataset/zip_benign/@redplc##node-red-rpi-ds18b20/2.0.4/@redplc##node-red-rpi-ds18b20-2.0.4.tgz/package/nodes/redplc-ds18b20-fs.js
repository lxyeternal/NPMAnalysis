/**
 * Copyright 2023 Ocean (iot.redplc@gmail.com).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 **/

"use strict";

module.exports = function(RED) {
    const syslib = require("./lib/syslib.js");
    const sysmodule = syslib.LoadModule("rpi_ds18b20");
    const NDEVICE = 64;

    RED.nodes.registerType("redplc-ds18b20-fs", function(n) {
        var node = this;
        RED.nodes.createNode(node, n);

        node.tupdate = n.tupdate;
        node.fahrenheit = n.fahrenheit;
        node.tofix = n.tofix;

        node.varname = "IA" + n.address;
        node.name = "redplc-ds18b20-fs";
        node.onwork = false;
        node.iserror = false;
        node.ctxvar = new Array(NDEVICE).fill(node.fahrenheit ? -67 : -55);

        if (sysmodule === undefined)
            node.iserror = syslib.outError(node, "driver error", "driver not load, wrong os or not Raspi");
        else if (sysmodule.isused())
            node.iserror = syslib.outError(node, "already used", "node already used");
        else if (!sysmodule.init_fs())
            node.iserror = syslib.outError(node, "init 1-wire error", "init 1-wire error, no 1-wire setup");
        else {
            if (!syslib.createVariable(node, node.varname, node.ctxvar))
                node.iserror = syslib.outError(node, node.varname + " duplicate", node.varname + " duplicate");
            else
                syslib.setStatus(node, node.varname, "grey");
        }

        function update(readval, ndevice) {
            if (readval === undefined)
                syslib.outError(node, "1-wire error");
            else {
                syslib.setStatus(node, node.varname);
                for (var i = 0; i < NDEVICE; i++) {
                    if (i < ndevice)
                        node.ctxvar[i] = syslib.toFixed(readval[i], node.tofix);
                    else
                        node.ctxvar[i] = node.fahrenheit ? -67 : -55;
                }
            }

            node.onwork = false;
        }

        node.on("input", function (msg) {
            if (node.iserror || node.onwork || (msg.payload !== true)) {
                node.send(msg);
                return;
            }    

            node.onwork = true;

            node.id_timeout = setTimeout(function() {
                sysmodule.get_temperatur_fs(node.fahrenheit, update);
            }, node.tupdate * 1000);

            node.send(msg);
        });

        node.on('close', function () {
            sysmodule.deinit();
            clearTimeout(node.id_timeout);
            syslib.deleteVariable(node, node.varname);
        });
    });

    RED.httpAdmin.get('/sensorlist', function(req, res) {
        sysmodule.get_list_fs(function(sensorlist) {
            res.send(sensorlist);
        });
    });
}
