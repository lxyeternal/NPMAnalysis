2.0.2
- Initial Release

2.0.3
- Reformat source

2.0.4
- Add license for binary files
- Add comment to README.md