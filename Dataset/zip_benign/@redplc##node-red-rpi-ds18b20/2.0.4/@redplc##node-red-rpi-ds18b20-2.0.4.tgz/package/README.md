# @redplc/node-red-rpi-ds18b20

[![platform](https://img.shields.io/badge/platform-Node--RED-red)](https://nodered.org)
[![platform](https://img.shields.io/badge/platform-redPlc-ffa500)](https://flows.nodered.org/node/@redplc/node-red-redplc/)
[![platform](https://img.shields.io/badge/platform-Raspberry--Pi-ff69b4)](https://www.raspberrypi.com/)

Node-RED node for [ds18b20](https://www.analog.com/en/products/ds18b20.html#product-overview) temperature sensor using with [redPlc](https://www.npmjs.com/package/@redplc/node-red-redplc/) nodes

## ds18b20 digital temperature sensor
- 9..12bit resolution.
- Conversion time 93.75..750ms.
- Measure range -55°C .. +125°C.
- On range -10°C .. +85°C is accuracy ±0,5°C.
- 1-Wire connection.
- Power supply 3..5.5V external or over bus (parasite power).
- Each sensor has a 64-Bit ID.

## Usage
- Install [redPlc](https://www.npmjs.com/package/@redplc/node-red-redplc/) nodes.
- Use redPlc s-inject node for trigger update.
- Connect to first output on s-inject node.
- For logical operations use redPlc nodes. 
- Data is exchanged with global context variable arrays.
- Array index depends on the order of the sensors.
- If you add/remove sensors, array index can be change.
- This node works on Raspberry Pi with 32bit or 64bit OS.
- The temperature values are in °C or °F.
- To prevents locks only one node is allowed.
- Enable 1-wire with raspi-config.
- Default 1-wire pin on Raspberry pi is GPIO4. 

## Delay with reading multiple ds18b20 digital temperature sensor
The ds18b20 digital temperature sensor needs to read temperature:<br>
9-bit resolution -> 93.75ms.<br>
10-bit resolution -> 187.5ms.<br>
11-bit resolution -> 375ms.<br>
12-bit resolution -> 750ms. (default factory set)<br>
Because the accuracy is ±0.5°C in the range from -10°C to +85°C,<br>
I recommend operating the sensor with 9-bit resolution.<br>
Please note that the times apply to one sensor.<br>
This means 10x750ms (7.5s) for 10 sensors with 12bit resolution.<br>
There is a way to read multiple sensors more quickly.<br>
The 1-Wire drivers from RPi Linux are not used for this,<br>
but the sensors are addressed with their 1-Wire protocol.<br>
In the further version I will implement this 1-Wire protocol.<br>

## Set Sensor Resolution
You can change the sensor resolution with tool in subfolder **setSensor**.<br>
File **readme.txt** describes how the tool is used.<br>
