import React, { Component } from "react";
import "./slide.banner.css";

class SlideBanner extends Component {
  constructor(props) {
    super(props);
    this.state = {
      activeItem: 0
    };
    this.autoplay = props.autoplay || false;
    this.dots = !props.dots ? (props.dots === false ? false : true) : true;
    this.easing = props.easing || "linear";
    this.autoplaySpeed = this.props.autoplaySpeed || 3000;
    if (props.touchMove) {
      this.onTouchStart = this.onTouchStart.bind(this);
      this.onTouchEnd = this.onTouchEnd.bind(this);
    }
  }

  componentDidMount() {
    this.autoPlay();
    if (this.props.touchMove) {
      this.refs.slide_banner.addEventListener(
        "touchstart",
        this.onTouchStart,
        false
      );
      this.refs.slide_banner.addEventListener(
        "touchend",
        this.onTouchEnd,
        false
      );
    }
  }

  componentWillUnmount() {
    this.timeID && clearInterval(this.timeID);
    if (this.props.touchMove) {
      this.refs.slide_banner.removeEventListener(
        "touchstart",
        this.onTouchStart,
        false
      );
      this.refs.slide_banner.removeEventListener(
        "touchend",
        this.onTouchEnd,
        false
      );
    }
  }

  onTouchStart(event) {
    event.preventDefault();
    this.startX = event.changedTouches[0].pageX;
    this.startY = event.changedTouches[0].pageY;
  }

  onTouchEnd(event) {
    event.preventDefault();
    let endX = event.changedTouches[0].pageX;
    let endY = event.changedTouches[0].pageY;
    let X = endX - this.startX;
    let Y = endY - this.startY;

    if (X > 0 && Math.abs(X) > Math.abs(Y)) {
      this.slidePrev();
    } else if (X < 0 && Math.abs(X) > Math.abs(Y)) {
      this.slideNext();
    }
  }

  changeItem(index) {
    if (this.state.activeItem !== index) {
      this.props.afterChange && this.props.afterChange(index);
      this.props.beforeChange &&
        this.props.beforeChange(this.state.activeItem, index);
      this.setState({ activeItem: index });
      this.autoPlay();
    }
  }

  slideNext() {
    if (this.props.children && this.props.children.length !== 0) {
      if (this.state.activeItem === this.props.children.length - 1) {
        this.setState({ activeItem: 0 });
      } else {
        let activeItem = this.state.activeItem;
        this.setState({ activeItem: ++activeItem });
      }
      this.autoPlay();
    }
  }

  slidePrev() {
    if (this.props.children && this.props.children.length !== 0) {
      if (this.state.activeItem === 0) {
        this.setState({ activeItem: this.props.children.length - 1 });
      } else {
        let activeItem = this.state.activeItem;
        this.setState({ activeItem: --activeItem });
      }
      this.autoPlay();
    }
  }

  slideGoTo(slideNumber) {
    if (this.props.children && this.props.children.length !== 0) {
      if (slideNumber < this.props.children.length) {
        this.setState({ activeItem: parseInt(slideNumber, 10) });
        this.autoPlay();
      }
    }
  }

  autoPlay() {
    this.timeID && clearInterval(this.timeID);
    this.timeID =
      this.props.autoplay &&
      setInterval(() => {
        let activeItem = this.state.activeItem + 1;
        if (activeItem === this.props.children.length) {
          activeItem = 0;
        }
        this.props.afterChange && this.props.afterChange(activeItem);
        this.props.beforeChange &&
          this.props.beforeChange(this.state.activeItem, activeItem);
        this.setState({ activeItem: activeItem });
      }, this.autoplaySpeed);
  }

  render() {
    return (
      <div className="slider-banner" ref="slide_banner">
        <div
          style={{
            opacity: 1,
            height: "100%",
            width: "100" * this.props.children.length + "%"
          }}
        >
          {React.Children.map(this.props.children, (child, index) => {
            return React.cloneElement(child, {
              style: {
                opacity: this.state.activeItem === index ? 1 : 0,
                display: "inline-block",
                position: "absolute",
                transition: "opacity 500ms " + this.easing
              }
            });
          })}
          {this.dots && (
            <ul className="slider-dots-decorator">
              {React.Children.map(this.props.children, (child, index) => {
                return (
                  <li
                    key={index}
                    className="slider-dots-wrap"
                    onClick={() => {
                      this.changeItem(index);
                    }}
                  >
                    <button
                      className={
                        this.state.activeItem === index
                          ? this.props.dotActiveStyle ||
                            "slider-dots-wrap-item-active"
                          : this.props.dotStyle || "slider-dots-wrap-item"
                      }
                    />
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </div>
    );
  }
}

export default SlideBanner;
