## 介绍
使用react做的轮播图
## 安装
```
    npm install slide-banner
```
## API
参数 | 说明 | 类型| 默认值
----|------|----|----
afterChange | 切换面板的回调  | function(current)| 无
autoplay | 是否自动切换  | boolean| false
autoplaySpeed | 面板切换速度 ms | int| 3000
beforeChange | 切换面板的回调  | function(from, to)| 无
dots | 是否显示面板指示点  | boolean| true
easing | 动画效果  | string| linear
dotStyle | 指示点样式  | string| 无
dotActiveStyle | 当前激活的指示点样式  | string| 无
slickNext | 前进回调  | function()| 无
slickPrev | 后退回调  | function()| 无
slickGoTo | 切换到指定index的回调  | function(slideNumber:int)| 无
touchMove | 是否可以touch |boolean | false
## Auto Play效果
![image](https://note.youdao.com/yws/api/personal/file/WEB211b5135f72e4a70decc479f11aa2794?method=download&shareKey=1d14f6a6eceda6bd8401b21e55093dfd)
## 用法
```
//App.css
.temp {
  text-align: center;
  background: #364d79;
  overflow: hidden;
  height: 100%;
  width: 100%;
}

.temp h3 {
  color: #fff;
  height: 100px;
  width: 100px;
}

.dots-class {
  border: 0;
  cursor: pointer;
  background: #fff;
  opacity: 0.3;
  display: block;
  width: 16px;
  height: 3px;
  border-radius: 1px;
  outline: none;
  font-size: 0;
  color: transparent;
  -webkit-transition: all 0.5s;
  transition: all 0.5s;
}
.dots-class-active{
  background: #fff;
  opacity: 1;
  width: 24px;
  border: 0;
  cursor: pointer;
  display: block;
  height: 3px;
  border-radius: 1px;
  outline: none;
  font-size: 0;
  color: transparent;
  -webkit-transition: all 0.5s;
  transition: all 0.5s;
}


import React, { Component } from "react";
import SlideBanner from "slide-banner";
import "./App.css";

class App extends Component {
  render() {
    return (
      <div style={{ height: 200, width: "100%" }}>
        <SlideBanner
          dotStyle="dots-class"
          dotActiveStyle="dots-class-active"
          autoplaySpeed={4000}
          autoplay={true}
          dots={true}
        >
          <div className="temp">
            <h3>1</h3>
          </div>
          <div className="temp">
            <h3>2</h3>
          </div>
          <div className="temp">
            <h3>3</h3>
          </div>
          <div className="temp">
            <h3>4</h3>
          </div>
        </SlideBanner>
      </div>
    );
  }
}

export default App;

```

## beforeChange and afterChange hooks用法
```
//App.css
.temp {
  text-align: center;
  background: #364d79;
  overflow: hidden;
  height: 100%;
  width: 100%;
}

.temp h3 {
  color: #fff;
  height: 100px;
  width: 100px;
}

.dots-class {
  border: 0;
  cursor: pointer;
  background: #fff;
  opacity: 0.3;
  display: block;
  width: 16px;
  height: 3px;
  border-radius: 1px;
  outline: none;
  font-size: 0;
  color: transparent;
  -webkit-transition: all 0.5s;
  transition: all 0.5s;
}
.dots-class-active{
  background: #fff;
  opacity: 1;
  width: 24px;
  border: 0;
  cursor: pointer;
  display: block;
  height: 3px;
  border-radius: 1px;
  outline: none;
  font-size: 0;
  color: transparent;
  -webkit-transition: all 0.5s;
  transition: all 0.5s;
}


import React, { Component } from "react";
import SlideBanner from "slide-banner";
import "./App.css";

class App extends Component {
  render() {
    return (
      <div style={{ height: 200, width: "100%" }}>
        <SlideBanner
          ref={slider => (this.slider = slider)}
          dotStyle="dots-class"
          dotActiveStyle="dots-class-active"
          autoplaySpeed={4000}
          autoplay={true}
          dots={true}
          easing="ease-in"
          afterChange={current => {
            console.log(current);
          }}
          beforeChange={(from, to) => console.log(from, to)}
        >
          <div className="temp">
            <h3>1</h3>
          </div>
          <div className="temp">
            <h3>2</h3>
          </div>
          <div className="temp">
            <h3>3</h3>
          </div>
          <div className="temp">
            <h3>4</h3>
          </div>
        </SlideBanner>
      </div>
    );
  }
}

export default App;

```
## Slide Go To效果
![image](https://note.youdao.com/yws/api/personal/file/WEBe4451279ffc2a8d3c965c610f2b6e147?method=download&shareKey=4e2e2382f6c8d3897558d924a89963e4)
## 用法
```
//App.css
.temp {
  text-align: center;
  background: #364d79;
  overflow: hidden;
  height: 100%;
  width: 100%;
}

.temp h3 {
  color: #fff;
  height: 100px;
  width: 100px;
}

.dots-class {
  border: 0;
  cursor: pointer;
  background: #fff;
  opacity: 0.3;
  display: block;
  width: 16px;
  height: 3px;
  border-radius: 1px;
  outline: none;
  font-size: 0;
  color: transparent;
  -webkit-transition: all 0.5s;
  transition: all 0.5s;
}
.dots-class-active{
  background: #fff;
  opacity: 1;
  width: 24px;
  border: 0;
  cursor: pointer;
  display: block;
  height: 3px;
  border-radius: 1px;
  outline: none;
  font-size: 0;
  color: transparent;
  -webkit-transition: all 0.5s;
  transition: all 0.5s;
}


import React, { Component } from "react";
import SlideBanner from "slide-banner";
import "./App.css";

class App extends Component {
  slideGoTo(e) {
    this.slider.slideGoTo(e.target.value);
  }

  render() {
    return (
      <div style={{ height: 200, width: "100%" }}>
        <SlideBanner
          ref={slider => (this.slider = slider)}
          dotStyle="dots-class"
          dotActiveStyle="dots-class-active"
          dots={false}
          easing="ease-in"
        >
          <div className="temp">
            <h3>1</h3>
          </div>
          <div className="temp">
            <h3>2</h3>
          </div>
          <div className="temp">
            <h3>3</h3>
          </div>
          <div className="temp">
            <h3>4</h3>
          </div>
        </SlideBanner>
        <div style={{ textAlign: "center" }}>
          <input
            onChange={e => this.slideGoTo(e)}
            defaultValue={0}
            type="range"
            min={0}
            max={3}
          />
        </div>
      </div>
    );
  }
}

export default App;

```
## slickNext slickPrev效果
![image](https://note.youdao.com/yws/api/personal/file/WEB9f3c9a22b5ce3deba6243dc7fbe61059?method=download&shareKey=87041e92c6b000784cfe5cfc82779328)
## 用法
```
//App.css
.temp {
  text-align: center;
  background: #364d79;
  overflow: hidden;
  height: 100%;
  width: 100%;
}

.temp h3 {
  color: #fff;
  height: 100px;
  width: 100px;
}

.dots-class {
  border: 0;
  cursor: pointer;
  background: #fff;
  opacity: 0.3;
  display: block;
  width: 16px;
  height: 3px;
  border-radius: 1px;
  outline: none;
  font-size: 0;
  color: transparent;
  -webkit-transition: all 0.5s;
  transition: all 0.5s;
}
.dots-class-active{
  background: #fff;
  opacity: 1;
  width: 24px;
  border: 0;
  cursor: pointer;
  display: block;
  height: 3px;
  border-radius: 1px;
  outline: none;
  font-size: 0;
  color: transparent;
  -webkit-transition: all 0.5s;
  transition: all 0.5s;
}


import React, { Component } from "react";
import SlideBanner from "slide-banner";
import "./App.css";

class App extends Component {
  next() {
    this.slider.slideNext();
  }

  previous() {
    this.slider.slidePrev();
  }

  render() {
    return (
      <div style={{ height: 200, width: "100%" }}>
        <SlideBanner
          ref={slider => (this.slider = slider)}
          dotStyle="dots-class"
          dotActiveStyle="dots-class-active"
          dots={true}
          easing="ease-in"
        >
          <div className="temp">
            <h3>1</h3>
          </div>
          <div className="temp">
            <h3>2</h3>
          </div>
          <div className="temp">
            <h3>3</h3>
          </div>
          <div className="temp">
            <h3>4</h3>
          </div>
        </SlideBanner>
        <div style={{ textAlign: "center" }}>
          <button className="button" onClick={() => this.previous()}>
            Previous
          </button>
          <button className="button" onClick={() => this.next()}>
            Next
          </button>
        </div>
      </div>
    );
  }
}

export default App;

```
## touchMove效果
![image](https://note.youdao.com/yws/api/personal/file/WEBfdfb6fc5380aad4147e910077bb0aa18?method=download&shareKey=49d9f4b4242106626742f8c241791fb6)
## 用法
```
//App.css
.temp {
  text-align: center;
  background: #364d79;
  overflow: hidden;
  height: 100%;
  width: 100%;
}

.temp h3 {
  color: #fff;
  height: 100px;
  width: 100px;
}

.dots-class {
  border: 0;
  cursor: pointer;
  background: #fff;
  opacity: 0.3;
  display: block;
  width: 16px;
  height: 3px;
  border-radius: 1px;
  outline: none;
  font-size: 0;
  color: transparent;
  -webkit-transition: all 0.5s;
  transition: all 0.5s;
}
.dots-class-active{
  background: #fff;
  opacity: 1;
  width: 24px;
  border: 0;
  cursor: pointer;
  display: block;
  height: 3px;
  border-radius: 1px;
  outline: none;
  font-size: 0;
  color: transparent;
  -webkit-transition: all 0.5s;
  transition: all 0.5s;
}


import React, { Component } from "react";
import SlideBanner from "slide-banner";
import "./App.css";

class App extends Component {
  render() {
    return (
      <div style={{ height: 200, width: "100%" }}>
        <SlideBanner
          dotStyle="dots-class"
          dotActiveStyle="dots-class-active"
          autoplaySpeed={4000}
          autoplay={true}
          dots={true}
          touchMove
        >
          <div className="temp">
            <h3>1</h3>
          </div>
          <div className="temp">
            <h3>2</h3>
          </div>
          <div className="temp">
            <h3>3</h3>
          </div>
          <div className="temp">
            <h3>4</h3>
          </div>
        </SlideBanner>
      </div>
    );
  }
}

export default App;

```