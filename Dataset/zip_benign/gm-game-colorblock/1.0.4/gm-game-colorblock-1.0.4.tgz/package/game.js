let lastFrameTime = 0;
function Game(ctx, options) {
    this.ctx = ctx;
    this.width = options.width;
    this.height = options.height;
    this.options = options;
    this.tempImgSource = JSON.stringify(options.imgs || []);
    this.imgSource = options.imgs || [];//方块图片数组

    this.updateFun(options);
    this.init();
}
Game.prototype.updateFun = function (data) {
    let { checkprobability, checkstr, imgs } = data;

    this.imgSource = imgs;//JSON.parse(this.tempImgSource);
    let total = 0;
    let str = checkstr.split("=");
    this.imgSource.forEach((item, index) => {
        if (item[str[0]] == str[1] && !!checkprobability) {
            item.probability = checkprobability;
        }
        if (!!item.probability) {
            item.max = total + item.probability;
            total = item.max;
        }
    })
    this.maxRandom = total;
    this.options.checkstr = checkstr;
}
Game.prototype.util = {
    random(options) {
        let opt = Object.assign({ min: 0, max: 0, isFloat: false, noNum: [] }, options);
        let tempNum;
        do {
            let num = Math.random() * (opt.max - opt.min) + opt.min;
            tempNum = !!opt.isFloat ? num : parseInt(num);
        } while (opt.noNum.includes(tempNum));
        return tempNum;
    },
    // 模拟 requestAnimationFrame
    doAnimationFrame(callback) {
        var currTime = new Date().getTime();
        var timeToCall = Math.max(0, 16 - (currTime - (lastFrameTime || 0)));
        lastFrameTime = currTime + timeToCall;
        this.timerId = setTimeout(function () { callback(lastFrameTime); }, timeToCall);
    },
    // 模拟 cancelAnimationFrame
    abortAnimationFrame(id) {
        clearTimeout(id || this.timerId)
    },
};
// 初始化
Game.prototype.init = function (tempData) {
    let defaultData = tempData || {};
    this.util.abortAnimationFrame();

    this.iStop = false;//是否结束 默认未结束状态
    this.speed = 0.3;
    this.blocks = defaultData.blocks || new Map();// 方块块

    this.firstEnter = true;
    this.drawFun();
}
// 清空画布
Game.prototype.clear = function () {
    this.ctx.clearRect(0, 0, this.width, this.height);
}
// 绘图
Game.prototype.drawFun = function () {
    this.addBlock();
    this.clear();
    this.ctx.save();

    for (let [key, img] of this.blocks) {
        if (img.y <= -img.height || !!img.over) {
            this.blocks.delete(key);
        } else {
            this.ctx.drawImage(img.src, img.x, img.y, img.width, img.height);
            img.x += img.speedX;
            if (img.x >= this.width - img.width || img.x <= 0) {
                img.speedX = -1 * img.speedX;
            }
            img.y -= img.speedY;
        }
    }

    this.ctx.draw();
    this.ctx.restore();
}
// 添加障碍物
Game.prototype.addBlock = function () {
    // 默认方块图片
    let tempIndex = this.util.random({ max: this.maxRandom });
    let defaultImg;
    this.imgSource.forEach(item => {
        if (!defaultImg && item.max > tempIndex) {
            defaultImg = item;
        }
    })
    // 缩放比例
    let scale = this.util.random({
        min: this.options.scalemin || 0.5,
        max: this.options.scalemax || 1,
        isFloat: true
    });
    let width = defaultImg.width * scale,
        height = defaultImg.height * scale;
    let ty = height;
    let endBlock = this.blocks.get(`block_${this.endIndex}`);//最后一块方块
    if (!!endBlock) {
        ty = this.height - endBlock.y - endBlock.height;
    }
    let y = this.height - height;
    if (!!this.firstEnter) {
        y = this.height - height;
    } else {
        y = this.height;
    }

    if (ty - height / 2 >= 0) {
        // col=0;
        let block = Object.assign({}, defaultImg, {
            x: this.util.random({ max: this.width - width }),
            y: y,
            width: width,
            height: height,
            speedX: this.util.random({ min: this.options.speedminx || 0, max: this.options.speedmaxx || 2, isFloat: true }),
            speedY: this.util.random({ min: this.options.speedminy || 3, max: this.options.speedmaxy || 4, isFloat: true }),
        });
        this.endIndex = (this.endIndex || 0) + 1;
        this.blocks.set(`block_${this.endIndex}`, block);
    }
}
// 游戏结束
Game.prototype.gameOver = function () {
    try {
        this.options.overFun();
    } catch (e) { }
    this.iStop = true;
    this.util.abortAnimationFrame();
}
Game.prototype.start = function () {
    this.util.abortAnimationFrame();
    this.firstEnter = false;
    // 绘图
    this.drawFun();
    if (this.iStop) {
        // 游戏结束
        this.gameOver();
    } else {
        // 静态渲染完后重新绘画，连贯成动画
        this.util.doAnimationFrame(() => {
            this.start();
        })
    }
}
Game.prototype.clickFun = function (x, y) {
    if (this.iStop || this.firstEnter) {
        console.log("游戏已经结束了...")
        return false;
    }
    for (let [key, img] of this.blocks) {
        let minX = img.x, maxX = img.x + img.width;
        let minY = img.y, maxY = img.y + img.height;
        if (minX <= x && x <= maxX && minY <= y && y <= maxY && img.speedX != 0 && img.speedY != 0) {
            // 点击中了元素
            if (!img.over) {
                let str = this.options.checkstr.split("=");
                if (img[str[0]] == str[1]) {
                    img.speedX = 0;
                    img.speedY = 0;

                    setTimeout(() => {
                        img.over = true;
                    }, this.options.fadetime || 0)
                }
                try {
                    this.options.changeFun(img, str[1]);
                } catch (e) { }
            }
        }
    }
}

module.exports = {
    Game
}