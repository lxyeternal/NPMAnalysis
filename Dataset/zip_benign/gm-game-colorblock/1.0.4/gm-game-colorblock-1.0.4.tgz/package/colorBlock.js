import { Game } from "./game"

Component({
  mixins: [],
  data: {},
  props: {},
  didMount() {
    let self = this;

    this.componentInitFun();

    this.$page.colorBlockGameComponent = this;
  },
  didUpdate() {
    try {
      this.colorBlockGame.updateFun(this.props);
    } catch (e) { }
  },
  didUnmount() { },
  methods: {
    componentInitFun() {
      let gameCanvas = my.createCanvasContext("colorCanvas");

      my.createSelectorQuery()
        .select("#colorBlockBox")
        .boundingClientRect()
        .exec(ret => {
          let width = parseInt(ret[0].width);
          let height = parseInt(ret[0].height);

          this.colorBlockGame = new Game(gameCanvas, Object.assign({}, this.props, {
            width: width,
            height: height,
            imgs: this.props.imgs || [],
            changeFun: (item, checkstr) => {
              this.parFun("onChange", item, checkstr);
            },
            overFun: () => {
              this.parFun("onStop");
            }
          }));

          this.parFun("onRender");
        });
    },
    start() {
      // 开始游戏
      console.log("开始游戏")
      this.parFun("onStart");
      this.colorBlockGame.iStop = false;
      this.colorBlockGame.init();
      this.colorBlockGame.start();
    },
    stop() {
      // 停止游戏
      console.log("停止游戏")
      this.colorBlockGame.gameOver();
    },
    restartGame() {
      // 重置游戏
    },
    parFun(funName, options, options1) {
      let bl = true;
      console.log("回调方法：" + funName, options, options1)
      if (!!bl) {
        try {
          // 判断组件是否有传入事件，如果没有，则再判断页面上是否有指定事件
          this.props[funName](options, options1);
          bl = false;
          console.log(funName + "组件传递回调方法");
        } catch (e) {
          bl = true;
        }
      }
      if (!!bl) {
        try {
          this.$page[funName](options, options1);
          bl = false;
          console.log(funName + "页面查找回调方法");
        } catch (e) {
          bl = true;
        }
      }
      if (!!bl) {
        console.log(funName + "组件没有传递该方法，页面也没有找到该方法")
      }
    },
    clickFun(e) {
      this.colorBlockGame.clickFun(e.detail.x, e.detail.y)
    }
  },
});