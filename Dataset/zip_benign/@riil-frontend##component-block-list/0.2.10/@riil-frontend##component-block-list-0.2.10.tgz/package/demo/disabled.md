---
title: 禁用模式
order: 3
---

<!-- prettier-ignore -->
````jsx

import React,{useState} from 'react';
import ReactDOM from 'react-dom';
import BlockList,{selectMode} from '@riil-frontend/component-block-list';
import { Checkbox } from '@alifd/next';

const length = 256;
const dataSource = [];
for (let i = 0; i < length; i++) {
	dataSource.push({ id: `${i}`,label:`${i}`,color:'rgba(255, 235, 82, 1)' });
}

function App() {
	const [disabled,setDisabled] = useState(false);
	const [disabledOdd,setDisabledOdd] = useState(false);
	const [disabled5,setDisabled5] = useState(false);

	const ds = dataSource.map((item,index) => ({...item, disabled: disabledOdd && index % 2 !== 0}));

	const onBlockChange = (keys) => console.log('onBlockChange',keys)
	
	return (
		<div>
			<div style={{marginBottom:8}}>
				<Checkbox checked={disabled} onChange={setDisabled} style={{marginRight:16}}>全局禁用</Checkbox>
				<Checkbox checked={disabledOdd} onChange={setDisabledOdd} style={{marginRight:16}}>禁用奇数色块</Checkbox>
				<Checkbox checked={disabled5} onChange={setDisabled5}>禁用5</Checkbox>
			</div>
		<BlockList disabled={disabled} dataSource={ds} disabledRender={disabled5 ? (block)=>block.id === '5' : undefined} onSelect={onBlockChange}/></div>
	);
}

ReactDOM.render(<App />, mountNode);


````
