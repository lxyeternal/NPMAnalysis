---
title: 简单展示
order: 1
---

<!-- prettier-ignore -->
````jsx

import React from 'react';
import ReactDOM from 'react-dom';
import BlockList from '@riil-frontend/component-block-list';

const length = 256;
const dataSource = [];
for (let i = 0; i < length; i++) {
	dataSource.push({ id: `${i}`,color:'rgba(255, 235, 82, 1)' });
}

function App() {
	const onSelect = (selectedKeys) => {
		console.log('selectedKeys',selectedKeys);
	}
	return (
		<div>
		<BlockList dataSource={dataSource} labelRender={(block) => block.id} onSelect={onSelect}/></div>
	);
}

ReactDOM.render(<App />, mountNode);


````
