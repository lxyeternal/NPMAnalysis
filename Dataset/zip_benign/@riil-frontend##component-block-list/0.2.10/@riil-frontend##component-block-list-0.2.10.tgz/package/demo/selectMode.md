---
title: 多种选择模式
order: 3
---

<!-- prettier-ignore -->
````jsx

import React,{useState} from 'react';
import ReactDOM from 'react-dom';
import BlockList,{ selectMode } from '@riil-frontend/component-block-list';
import { Select } from '@alifd/next';

const length = 256;
const dataSource = [];
for (let i = 0; i < length; i++) {
	dataSource.push({ id: `${i}`,color:'rgba(255, 235, 82, 1)' });
}

function App() {
	const [mode,setMode] = useState();
	const onSelect = (selectedKeys) => {
		console.log('selectedKeys',selectedKeys);
	}
	const onModeChange = (value) => setMode(value);
	return (
		<div>
		<Select dataSource={[{ label: '滑选', value: selectMode.SLIDE }]} value={mode} onChange={onModeChange} style={{marginBottom:8}}></Select>
		<BlockList dataSource={dataSource} labelRender={(block) => block.id} onSelect={onSelect} selectMode={mode}/></div>
	);
}

ReactDOM.render(<App />, mountNode);


````
