---
title: 受控展示
order: 2
---

<!-- prettier-ignore -->
````jsx

import React, { useState } from 'react';
import ReactDOM from 'react-dom';
import BlockList from '@riil-frontend/component-block-list';
import { Select, Search, Button } from '@alifd/next';

const statusDs = [
	{ label: '已分配', value: '0', color: 'rgba(67, 209, 152, 1)' },
	{ label: '未分配', value: '1', color: 'rgba(228, 233, 238, 1)' },
	{ label: '预留地址', value: '2', color: 'rgba(255, 235, 82, 1)' },
	{ label: '网管地址', value: '3', color: 'rgba(228, 233, 238, 1)' },
	{ label: '不可用', value: '4', color: 'rgba(228, 233, 238, 1)',disabled:true },
];
const length = 256;
let dataSource = [];
for (let i = 0; i < length; i++) {
	dataSource.push({ ip: `${i}`, status: `${Math.floor(Math.random() * statusDs.length)}` });
}
dataSource = dataSource.map((item) => {
	const myStatus = statusDs.find((status) => status.value === item.status);
	return { ...item, color: myStatus.color, disabled: myStatus.disabled }
});
const primaryKey = 'ip';

function App() {
	const [status, setStatus] = useState('all');
	const [keyword, setKeyword] = useState('');
	const [selectedKeys,setSelectedKeys] = useState([]);
	const [highlightKeys, setHighlightKeys] = useState([]);
	const onStatusChange = (value) => {
		setStatus(value);
		const filterResult = value === 'all' ? dataSource : dataSource.filter((item) => item.status === value);
		const searchResult = filterResult.filter((item) => item[primaryKey].includes(keyword));
		setHighlightKeys(searchResult.map((item) => item[primaryKey]));
	};
	const onKeywordChange = (value) => {
		setKeyword(value);
	};
	const onSearch = (value) => {
		const filterResult = status === 'all' ? dataSource : dataSource.filter((item) => item.status === status);
		const searchResult = filterResult.filter((item) => item[primaryKey].includes(value));
		setHighlightKeys(searchResult.map((item) => item[primaryKey]));
	};

	const onBlockSelect = (keys) => {
		console.log('selectedKeys',keys);
		setSelectedKeys(keys);
	}

	const onClear = () => {
		setSelectedKeys([]);
	}

	const isSearch = keyword.length > 0 || status!=='all';

	return (
		<div>
			<Select dataSource={[{ label: '全部状态', value: 'all' }, ...statusDs]} value={status} onChange={onStatusChange} style={{ marginRight: 8 }}></Select>
			<Search shape="simple" value={keyword} onChange={onKeywordChange} onSearch={onSearch} />
			<Button onClick={onClear}>清空选中</Button>
			<div style={{ display: 'flex', height: 40 }}>
				{statusDs.map((item) => (
					<div style={{ display: 'flex', alignItems: 'center' }} key={item.value}>
						<span style={{ display: 'inline-block', height: 12, width: 12, backgroundColor: item.color, marginRight: 4 }} />
						<span style={{ marginRight: 16 }}>{item.label}</span>
					</div>
				))}
			</div>
			<BlockList dataSource={dataSource} primaryKey="ip" labelRender={(block) => block.ip} isSearch={isSearch} highlightKeys={highlightKeys} onSelect={onBlockSelect} selectedKeys={selectedKeys}/>
		</div>
	);
}

ReactDOM.render(<App />, mountNode);




````
