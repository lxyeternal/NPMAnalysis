---
title: 色块大小展示
order: 3
---

<!-- prettier-ignore -->
````jsx

import React,{useState} from 'react';
import ReactDOM from 'react-dom';
import BlockList,{ size } from '@riil-frontend/component-block-list';
import { Select, NumberPicker } from '@alifd/next';

const length = 256;
const dataSource = [];
for (let i = 0; i < length; i++) {
	dataSource.push({ id: `${i}`,color:'rgba(255, 235, 82, 1)' });
}

function App() {
	const [selectedSize,setSelectedSize] = useState();
	const onSizeChange = (value) => setSelectedSize(value);
	const onNumberChange = (value) => setSelectedSize(value);
	return (
		<div>
			<div style={{display:'flex', alignItems:'center',marginBottom:8} }>
				<span style={{marginRight:8}}>内置大小</span><Select dataSource={[{ label: 'small', value: size.SMALL }, { label: 'medium', value: size.MEDIUM },{ label: 'large', value: size.LARGE }]}  onChange={onSizeChange} style={{marginRight:16}}></Select>
				<span style={{marginRight:8}}>自定义大小</span><NumberPicker onChange={onNumberChange}></NumberPicker>
			</div>
		<BlockList dataSource={dataSource} labelRender={(block) => block.id} size={selectedSize}/></div>
	);
}

ReactDOM.render(<App />, mountNode);


````
