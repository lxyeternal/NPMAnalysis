---
title: 背景图标展示
order: 6
---

<!-- prettier-ignore -->
````jsx

import React from 'react';
import ReactDOM from 'react-dom';
import BlockList from '@riil-frontend/component-block-list';

const length = 256;
const dataSource = [];
for (let i = 0; i < length; i++) {
	dataSource.push({ 
		id: `${i}`, 
		color: 'rgba(255, 235, 82, 1)', 
		backIconType: (i === 0 && 'rii_forbidden') ||
		 (i === 1 && 'IP_legend_icon_gateway') || 
		 (i === 71 && 'IP_legend_icon_recent') ,
		 disabled:i === 0 }
	);
}

function App() {
	const onSelect = (selectedKeys) => {
		console.log('selectedKeys',selectedKeys);
	}
	return (
		<div>
		<BlockList dataSource={dataSource} labelRender={(block) => block.id} onSelect={onSelect}/></div>
	);
}

ReactDOM.render(<App />, mountNode);


````
