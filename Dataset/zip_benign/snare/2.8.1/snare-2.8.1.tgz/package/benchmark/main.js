var Snare = require('../index');

var liveContext = new AudioContext();

var ct = 16;
var duration = 0.4;

var context = new OfflineAudioContext(1, ct * duration * 44100, 44100);

var snare = Snare(context);

for (var i = 0; i < ct; i++) {
  var snareNode = snare();
  snareNode.duration = duration;
  snareNode.connect(context.destination);
  snareNode.start(duration * i / 2);
}

var startTime = Date.now();
context.startRendering().then(function(buffer) {
  console.log((Date.now() - startTime) / 1000);
  console.log(buffer);
  var source = liveContext.createBufferSource();
  source.buffer = buffer;
  source.connect(liveContext.destination);
  source.start(liveContext.currentTime);
});

