COW: deployment/tool

[![pipeline status](http://gitlab.ceng.metu.edu.tr/Group3/infrastructure/badges/master/pipeline.svg)](http://gitlab.ceng.metu.edu.tr/Group3/infrastructure/commits/master)
[![coverage report](http://gitlab.ceng.metu.edu.tr/Group3/infrastructure/badges/master/coverage.svg)](http://gitlab.ceng.metu.edu.tr/Group3/infrastructure/commits/master)

### How to use

#### Installation 
```bash
npm i -g @cow/infrastructure
```

#### Connect to a server in cluster
Example is given below for MongoDB, other services can be accessed via similar mechanism
```bash
    ssh username@setupserver -L <targetport>:localhost:27017 # The port is the port you want your localhost to be exposed to
    cow expose mongo
```
### Deployment

There shall be a cow.yml file committed in your repository. If you have it then you can deploy any version of it with command:
```bash
cow deploy -v <version> -f cow.yml # (or any other path) 
```

### cow.yml structure
```yaml
meta:
    component: <specific component like core, newsgroup etc...>
    subservice: <specific service of that component like endpoint, scheduler etc...>
type: <the type of the deployment currently supported are `backend-npm` and `frontend-npm`>
spec: <type specific specifications>

```
#### backend-docker type
The spec requirements are as follows:
```yaml
replicaCount: <how many copies of the machine shall be created>
mapPorts:
  - from: <port that is exposed from code>
    to: <in-cluster access port>
    public: <if true then from port will be exposed publicly at /component-subservice/ with HTTPS>
resource:
    request:
        cpu: <minimum CPU requirement per time interval like 0.3 0.6>
        memory: <minimum RAM requirement specify like 300Mi 1Gi>
    limit:
        cpu: <maximum amount of CPU per time interval like 0.6 1.0>
        memory: <max RAM requirement, same syntax as requests>
readyAfterSeconds: <how many seconds shall I wait before it starts>
envs: <array of env values to be used>
injections:
- targetService: <the service that cow should inject content to>
  type: <a unique key that identifies the injection type, determined by target service>
  id: <a unique name that you give in your config file for this injection, this is not to be used by target service>
  content: < configuration content, target service has probably documented on what should go into this>
mounts:
- path: < where to add the persistent storage (all content in here will be wiped in the image, directories will be created> 
  size: < size of persistent storage, express in units of Mi, Gi >
  id: < a unique name that you give to this mounted disk >

```

Other types are deprecated.

