#!/usr/bin/env node

const path = require('path');
const filename = path.join(__dirname, 'dist', 'index.js');
require(filename);

