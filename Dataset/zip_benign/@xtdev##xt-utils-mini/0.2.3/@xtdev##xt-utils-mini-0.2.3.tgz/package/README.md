
## 项目启动：
``` bash
# install dependencies
npm install

# 编译sdk命令
npm run build
```

## 快速使用：
###  urlTools 工具集
页面地址和参数相关集合

####    getParams 
**用法：** 获取路径及参数，分别返回页面路径path和参数(JSON) params
**示例：**
```
import { urlTools } from '@xtdev/xt-utils-mini';
let url = '/pages/mine/mine?school=gongda&hobby=skating&number=3'
let result = urlTools.getParams(url)
console.log(result);
输出：
{
    path: '/pages/mine/mine',
    params: {
        school: 'gongda',
        hobby: 'skaing',
        number: '3'
    }
}
```

####   getQueryString
**用法：** 直接取url中的某个参数
**示例1：**
```
import { urlTools } from '@xtdev/xt-utils-mini';
let url = '/pages/mine/mine?school=gongda&hobby=skating&number=3'
let result = urlTools.getQueryString('school', url)
console.log(result);
输出：
gongda
```
**示例2：**
```
import { urlTools } from '@xtdev/xt-utils-mini';
let url = 'school=gongda&hobby=skating&number=3'
let result = urlTools.getQueryString('hobby', url)
console.log(result);
输出：
skating
```
**示例3：**
```
import { urlTools } from '@xtdev/xt-utils-mini';
let url = '/pages/mine/mine'
let result = urlTools.getQueryString('school', url)
console.log(result);
输出：
""
```

####   queryToObj
**用法：** 将url的传参参数形式的字符串转化为json对象格式。⚠️：页面path不会转换
**示例：**
```
import { urlTools } from '@xtdev/xt-utils-mini';
let param = 'school=gongda&hobby=skating&number=3'
let result = urlTools.queryToObj(param)
console.log(result);
输出：
{
    school: 'gongda',
    hobby: 'skaing',
    number: '3'
}
```

####   toQueryString
**用法：** 对象转字符串
**示例：**
```
import { urlTools } from '@xtdev/xt-utils-mini';
const param = { a: 1, b: 2 }
const result =urlTools.toQueryString(param)
console.log(result);
输出：
"a=1&b=2"
```

####    setUrl 
**用法：** 将页面path和参数转换成url链接，params中的参数会替换掉原来的同名参数
**示例1：**
```
import { urlTools } from '@xtdev/xt-utils-mini';
const params = { a: 1, b: 2 }
let result = urlTools.setUrl(params, '/pages/mine/mine')
console.log(result);
输出：
'/pages/mine/mine?a=1&b=2'
```

**示例2：**
```
import { urlTools } from '@xtdev/xt-utils-mini';
const params = { a: 1, b: 2 }
let result = urlTools.setUrl(params, '/pages/mine/mine?a=4')
console.log(result);
输出：
'/pages/mine/mine?a=1&b=2'
```

### String 工具集
主要是提供字符串长度计算，随机字符串，手机/身份证信息脱敏等
#### wordLen 
计算字符串长度，区分中英文。type：1是按照当前字符串长度返回, 2:是按照字符数的长度返回[一个汉字长度是2个字符], 3:是按照汉字数的长度返回[一个字符长度是0.5个汉字])


**示例：**
```
import { strTools } from '@xtdev/xt-utils-mini';
var result = strTools.wordLen('哈哈哈123', 1)
console.log(result);
输出： 6

var result = strTools.wordLen('哈哈哈123', 2)
console.log(result);
输出： 9

var result = strTools.wordLen('哈哈哈123', 3)
console.log(result);
输出：4.5
```

#### getRandomString
通过输入规则，产生相应的随机数，目前包括大小写字符，数字，以及其组合。代码中会替换规则中的 * 、d 和 s。其他原样输出。
默认规则：'****-****-****-****'


**示例：**
```
import { strTools } from '@xtdev/xt-utils-mini';
var result = strTools.getRandomString()
console.log(result);
输出： '27wx-9AkP-MPYj-ERfx'

var result = strTools.getRandomString('dddd-dddd-dddd')
console.log(result);
输出： '5238-3191-0062'

var result = strTools.getRandomString('sss_sss_sss')
console.log(result);
输出：'TDP_pQR_xWQ'

var result = strTools.getRandomString('****@****.com')
console.log(result);
输出：'TXyQ@xYe7.com'
```

#### desensitization
字符串脱敏，参数说明：
|说明|类型|示例|
|--|--|--|
|str|数字、字符串|123456789 |
|beginLen|数字| 起始位置 从1开始 |
|endLen|数字| 结束位置 从 -1 开始|


**示例：**
```
import { strTools } from '@xtdev/xt-utils-mini';
var result = strTools.desensitization(123456789,3,-3 )
console.log(result);
输出：'123***789'

var result = strTools.desensitization("123456789",4,-4 )
console.log(result);
输出： '1234*6789'

var result = strTools.desensitization(123456789,3,-4 )
console.log(result);
输出：'123**6789'
```

### 数字工具集
#### toPriceYuan

单位分转换为元
```
    import {numTools} from '@xtdev/xt-utils-mini';
    numTools.toPriceYuan(valueFen,decimal);
```
|入参|类型|示例|
|--|--|--|
|valueFen|数字|45756 |
|decimal|数字| 默认值为2，保留2位小数 |
**返回：** decimal位小数的金额(元)，最后一位四舍五入
**示例：**
```
     numTools.toPriceYuan(12345);
     // => 123.45
     numTools.toPriceYuan(12345,1);
     // => 123.5
     numTools.toPriceYuan('12345',3);
     // => 12.35
```

<!-- #### toPercent

单位百分比转换为折
```
    import {numTools} from '@xtdev/xt-utils-mini';
    numTools.toPercent(value);
```
|入参|类型|示例|
|--|--|--|
|value|数字|45756 |
**返回：** decimal位小数的金额(元)，最后一位四舍五入
**示例：**
```
     numTools.toPercent(12345);
     // => 123.45
``` -->

### 地理位置工具集
#### distance

输入经纬度 返回两点之间的距离（km）
```
    import { location } from '@xtdev/xt-utils-mini';
    location.distance(lat1,lng1,lat2,lng2);
```
|入参|类型|示例|
|--|--|--|
|lat1|数字| 位置1 纬度 |
|lng1|数字| 位置1 经度 |
|lat2|数字| 位置2 纬度 |
|lng2|数字| 位置2 经度 |
**返回：** 计算两点之间的距离，返回数据以 KM为单位
**示例：**
```
     numTools.distance(34.446754,113.041725, 34.39403,113.0349);
     // => 5.9026
     
```

#### distanceOfMeter

输入经纬度 返回两点之间的距离 m 位单位
```
    import { location } from '@xtdev/xt-utils-mini';
    location.distanceOfMeter(lat1,lng1,lat2,lng2);
```
|入参|类型|示例|
|--|--|--|
|lat1|数字| 位置1 纬度 |
|lng1|数字| 位置1 经度 |
|lat2|数字| 位置2 纬度 |
|lng2|数字| 位置2 经度 |
**返回：** 计算两点之间的距离，返回数据以 米 为单位
**示例：**
```
     numTools.distanceOfMeter(34.446754,113.041725, 34.39403,113.0349);
     // => 5902.5761
     
```

#### distanceFriendly

输入经纬度 返回两点之间的距离，返回单位根据距离判断，参数支持两种类型
```
    import { location } from '@xtdev/xt-utils-mini';
    location.distanceFriendly(lat1,lng1,lat2,lng2);
```
**入参1：** 
|入参|类型|示例|
|--|--|--|
|lat1|数字| 位置1 纬度 |
|lng1|数字| 位置1 经度 |
|lat2|数字| 位置2 纬度 |
|lng2|数字| 位置2 经度 |
**返回：** 计算两点之间的距离，超过1000米 以 km为单位，否则以 m 为单位
**示例：**
```
     numTools.distanceFriendly(34.446754,113.041725, 34.39403,113.0349);
     // => '5.9km'
     
```
**入参2：** 
|入参|类型|示例|
|--|--|--|
|位置1|对象| { lat: 34.446754, lng: 113.041725 } |
|位置2|对象| { lat: 34.39403, lng: 113.0349 } |
**返回：** 计算两点之间的距离，超过1000米 以 km为单位，否则以 m 为单位
**示例：**
```
    let address1 = { lat: 34.446754, lng: 113.041725 }
    let address2 = { lat: 34.39403, lng: 113.0349 }
     numTools.distanceFriendly( address1, address2);
     // => '5.9km'
     
```

### 编码相关工具集
在crypto-js的基础上做了一些基础封装
#### aesEncode

AES 加密
```
    import { crypto } from '@xtdev/xt-utils-mini';
    crypto.aesEncode(data);
```
|入参|类型|示例|
|--|--|--|
|data|字符串/对象/数组等 | 需要加密的原始内容 |
|str|字符串| 需要加密的原始字符 |
|defaultSecretKey|字符串| 加密key 默认 xtUtils |

**返回：** 加密后的AES字符串，每次加密后的结果都不一样
**示例：**
```
     crypto.aesEncode("Hellow World");
     // => U2FsdGVkX18cKbHMh36EZgef+0tYrQUDjlIpwOLfwz/ig3UN2rrk3I92EKT1+St5K6G+BRRm9tUOFKHWsDGhkg== 不唯一
     
```

#### aesEncode

AES 解密
```
    import { crypto } from '@xtdev/xt-utils-mini';
    crypto.aesEncode(str);
```
|入参|类型|示例|
|--|--|--|
|str|字符串| 需要解密的原始字符 |

**返回：** 原始字符串
**示例：**
```
     crypto.aesEncode("U2FsdGVkX18cKbHMh36EZgef+0tYrQUDjlIpwOLfwz/ig3UN2rrk3I92EKT1+St5K6G+BRRm9tUOFKHWsDGhkg==");
     // =>   "Hellow World"
     
```
#### md5
MD5 加密
```
    import { crypto } from '@xtdev/xt-utils-mini';
    crypto.md5(data);
```
|入参|类型|示例|
|--|--|--|
|data|字符串/对象/数组等 | 需要加密的原始内容 |


**返回：** MD5 加密，包括16位大写/16位小写/32位大写/32位小写。 默认返回32位小写
**示例：**
```
     crypto.md5(123456);
     // => e10adc3949ba59abbe56e057f20f883e
     
```

#### sha1

#### sha256

#### base64Encode
base64 加密, 输入内容转换成字符串，然后再编码
```
    import { crypto } from '@xtdev/xt-utils-mini';
    crypto.base64Encode(data);
```
|入参|类型|示例|
|--|--|--|
|data|字符串/对象/数组等 | 需要加密的原始内容 |


**返回：** base64 编码后的字符串
**示例：**
```
     crypto.base64Encode('12345678');
     // => 'MTIzNDU2Nzg='
     
```

#### base64Decode
base64 解码
```
    import { crypto } from '@xtdev/xt-utils-mini';
    crypto.base64Decode(data);
```
|入参|类型|示例|
|--|--|--|
|data|字符串/对象/数组等 | 需要加密的原始内容 |


**返回：** base64 解码后尝试转化成JSON对象，如果转化失败，返回解码后字符串
**示例：**
```
     crypto.base64Decode('eyJuYW1lIjoieGluZ2RpYW4ifQ==');
     // => 'MTIzNDU2Nzg='
     
```

#### jwtDecode
JWT 解码
```
    import { crypto } from '@xtdev/xt-utils-mini';
    crypto.jwtDecode(data);
```
|入参|类型|示例|
|--|--|--|
|data|字符串 | 需要解析的JWT信息 |


**返回：** 通过base64 解析JWT 中间部分内容，从而提取其中的用户信息，并且尝试JSON序列化
**示例：**
```
     crypto.jwtDecode('eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJsb2dpblR5cGUiOiJsb2dpbiIsImxvZ2luSWQiOjE1NTYwODA3ODQyNzg3MzI4MCwicm5TdHIiOiJlczFlNEdpdFh6NEYyMEI4SzRVVFExdk45cFNwSkJBRSIsInNlc3Npb25fa2V5IjoiY2thMG9Fc1dpN3Y1aFBrdFFOUEhmQT09Iiwib3BlbmlkIjoibzRJV3E1VTdjTHZuTmhna1FVdGR0czdxMFZCYyIsInVuaW9uaWQiOiJvcFUtRDBrWmhMbkFrMnlmTUNuSHBXcWhKdGFRIiwiYXV0aFRva2VuQm8iOnsicGxhdGZvcm1Vc2VySWQiOjE1NTYwODA3ODQyNzg3MzI4MCwiYXBwQ29kZSI6IkNMT1VEX1NIT1AiLCJwbGF0Zm9ybUNsaWVudFR5cGUiOiJXRUNIQVRfQVBQTEVUUyIsInBsYXRmb3JtQ2xpZW50Q29kZSI6IldFQ0hBVF9XUF9UQU5fSklVX0NMT1VEX0JVU0lORVNTIiwidGVuYW50SWQiOjF9fQ.sfTcHrlPXmssEZ80NI6tttB_pz3_KvR_4cDgsr1fpFo');
     // => {loginId: 155608078427873280, ...}
     
```

### wxApi 微信小程序相关

#### getCurrentPage 
获取当前页面路径及参数等信息，取 getCurrentPages() 数组的最后一个元素返回。
**入参：** 无
**返回：** 【JSON】当前路径信息
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    wxApi.getCurrentPage();
    // => {route: "pages/home/home", ...}
```
#### getCurrentPath 
获取当前页面路径，不包含参数
**入参：** 无
**返回：** 【字符串】当前路径信息，提取getCurrentPage返回信息，前面加上 "/" 
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    wxApi.getCurrentPath();
    // => /pages/mine/mine
```


#### getCurrentParams 
获取当前页面参数
**入参：** 无
**返回：** 【JSON】获取当前页面的链接参数，以JSON格式返回来 
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    wxApi.getCurrentParams();
    // => {id : 9876, type: 30}
```

#### rpxToPx 
根据屏幕分辨率 rpx 转 实际px，以 750 为标准。
|入参|必传|类型|示例|
|--|--|--|--|
|rpx|是|字符串、数字 | 375 |
**返回：** 【数字】实际占用屏幕的物理像素
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    wxApi.rpxToPx(375);
    // => 187.5
```

#### querySelector

根据元素id或者class 获取元素在页面上展示的实际信息。封装了小程序 boundingClientRect 和 scrollOffset 两个接口返回的数据统一返回。
|入参|必传|类型|示例|
|--|--|--|--|
|element|是|字符串、数字 | 'shop_item_box' |
**返回：** 【Promise】包含元素width,height,scrollTop等信息
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    // 当元素不存在的时候
    const shopItem = await wxApi.querySelector('.shop_item_box');
    // => { id: "",scrollHeight: 715,scrollLeft: 0,scrollTop: 0,scrollWidth: 375 }

    // 当元素存在的时候
    const shopItem = await wxApi.querySelector('.bg-box');
    // => { bottom: 240, height: 240, id: "" ,left: 0,right: 375, scrollHeight: 715,scrollLeft: 0,scrollTop: 0 ,scrollWidth: 375 ,top: 0 ,width: 375 }

```

#### requestSubscribeMessage

订阅消息封装成 Promise 返回，当调用失败时会提示：消息订阅失败
|入参|说明|必传|类型|示例|
|--|--|--|--|--|
|tmplIds|模版id 或者 模版id列表|是|字符串、数组 | qYROeXBwTiPGAYj3ldDVddGytmp0KZ8VLl8W1yCMM6k |
**返回：** 【Promise】接口调用成功时errMsg值为 'requestSubscribeMessage:ok' 
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    await wxApi.requestSubscribeMessage('qYROeXBwTiPGAYj3ldDVddGytmp0KZ8VLl8W1yCMM6k');
    // => { errMsg: 'requestSubscribeMessage:ok'  }

```

####  showModal

打开询问弹窗，封装wx.showModal。传入参数可以是简单的字符串，也可以是wx.showModal 相关的配置对象，当传入字符串时标题默认为“提示”。返回Promise 对象。
|入参|说明|必传|类型|示例|
|--|--|--|--|--|
|info|消息内容|是|字符串、原始配置对象 | "这是一条提示信息" |
**返回：** 【Promise】接口调用成功时confirm值为 true
**示例1：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    const result = await wxApi.showModal("你确定要删除该项目么？");
    // 点击取消 => {errMsg: "showModal:ok", cancel: true, confirm: false}
    // 点击确定 => {errMsg: "showModal:ok", cancel: false, confirm: true, content: null}
    console.log(result.confirm);
```
**示例2：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    const result = await wxApi.showModal({
        title: '删除提示',
        content: "你确定要删除该项目么？"
    });
    // 点击取消 => {errMsg: "showModal:ok", cancel: true, confirm: false}
    // 点击确定 => {errMsg: "showModal:ok", cancel: false, confirm: true, content: null}
```
####  showToast

消息提示弹窗，封装wx.showToast。传入参数可以是简单的字符串，也可以是wx.showToast 相关的配置对象，返回Promise 对象。
|入参|说明|必传|类型|示例|
|--|--|--|--|--|
|info|消息内容|是|字符串、原始配置对象 | "这是一条提示信息" |
|delay|是否等待 | 否|布尔| 如果设置为true，则promise 会在duration(默认3s)时间后再返回|
**返回：** 【Promise】接口调用成功时confirm值为 true
**示例1：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    await wxApi.showToast("你暂无权限参加活动", true);
    // => console.log 会在3秒后再执行
    console.log('toast执行完毕，之行后续动作');
```

**示例2：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    await wxApi.showToast({title, icon, duration,mask}, true);
    // => console.log 会在3秒后再执行
    console.log('toast执行完毕，之行后续动作');
```


#### openSetting

打开系统权限设置，在使用图片保存和地理位置授权时，如果用户拒绝了可以设置唤起设置。⚠️ 只能通过页面点击触发
**入参：** 无
**返回：** 【Promise】接口调用成功时confirm值为 true
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    await wxApi.openSetting();
```


#### makePhoneCall

拨打电话，封装wx.makePhoneCall函数，返回Promise对象。
|入参|说明|必传|类型|示例|
|--|--|--|--|--|
|phoneNumber|电话号码|是|字符串、数字 | 400 9917979 |
**返回：** 【Promise】确认拨打电话时为true，否则为false
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    const result =  await wxApi.makePhoneCall('400 9917979');
    // => true 或者 false
```

#### getPlatform

获取当前平台信息，根据getSystemInfoSync 返回相应结果。
**入参：** 无
**返回：** 【字符串】wechat (微信小程序) 或者 wxwork(企业微信小程序)
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    const platform = wxApi.getPlatform();
    // => 'wechat' 或者 'wxwork'
```

#### getSetting
获取授权信息设置，封装wx.getSetting， 返回Promise对象。
|入参|说明|必传|类型|示例|
|--|--|--|--|--|
|auth|权限名称|否|字符串|userLocation|
**返回：** 【Promise】如果传入auth , 则返回 系统是否授权了auth权限，可自动识别传入字符串中是否带有scope，自动补齐。
如果没有传auth，返回所有的系统设置
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    var result =  await wxApi.getSetting('userLocation');
    // => true

    var result = await wxApi.getSetting();
    // => { scope.address: true,
    //        scope.invoice: true,
    //        scope.invoiceTitle: true,
    //        scope.userInfo: true,
    //        scope.userLocation: true,
    //     }
```

#### authorize

唤起授权弹窗，封装wx.authorize函数，返回Promise对象。申请的权限通常包括： userLocation/userLocationBackground 位置信息，werun 运动步数,record 麦克风，camera 摄像头，writePhotosAlbum 相册权限
当没相册权限时会提示：'授权失败，请前往设置打开[位置/运动步数/麦克风/摄像头/相册]权限'。
|入参|说明|必传|类型|示例|
|--|--|--|--|--|
|authorize|图片地址|是|字符串|userLocation|
|showSetting|失败时引导跳转设置页面|是|布尔|默认 false，推荐值：true|
**返回：** 【Promise】返回授权结果。
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    const result = await wxApi.authorize('userLocation');
    // 成功时 => {errMsg: "authorize:ok"}
    // 拒绝时 => Promise reject 

    const result1 = await wxApi.authorize('userLocation', true);
    // 拒绝时 => Promise reject, showModal 弹窗询问是否打开设置页面。
```

#### downloadFile

下载文件到本地缓存，封装wx.downloadFile函数，返回Promise对象。当保存失败时会提示："保存失败，请于设置打开微信相关权限"。
|入参|说明|必传|类型|示例|
|--|--|--|--|--|
|url|图片(文件)url地址|是|字符串|https://img.tanjiu.cn/home/6hs5WCPA77KCMxDzckdch5wt63KHmAfP.png|
**返回：** 【Promise】返回图片在本地的临时地址，方便后续保存到相册等。
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    const tempUrl =  await wxApi.downloadFile('https://img.tanjiu.cn/home/6hs5WCPA77KCMxDzckdch5wt63KHmAfP.png');
    // => http://tmp/nA1Xaq3BizL84f9e10a77c5582d5a130fa5f3df549f6.png
```

#### saveImage

文件保存到相册，封装wx.downloadFile 和 wx.saveImageToPhotosAlbum 函数，返回Promise对象。
当没相册权限时会提示：'请打开"保存到相册"权限'。
当保存失败时会提示：'保存到手机相册出错, 请重试'
|入参|说明|必传|类型|示例|
|--|--|--|--|--|
|url|图片地址|是|字符串|https://img.tanjiu.cn/home/6hs5WCPA77KCMxDzckdch5wt63KHmAfP.png|
**返回：** 【Promise】返回保存结果。
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    await wxApi.saveImage('https://img.tanjiu.cn/home/6hs5WCPA77KCMxDzckdch5wt63KHmAfP.png');
    // 成功时 => {errMsg: "saveImageToPhotosAlbum:ok"}
    // 取消时 => 抛出异常 '保存到手机相册出错, 请重试'
```

#### getLocation

获取地理位置，封装wx.getLocation函数，返回Promise对象。
当保存失败时会提示：'请检查定位权限'，默认使用 gcj02 坐标系，默认开启高精度。
**返回：** 无。
**返回：** 【Promise】返回当前位置的经纬度信息，以及速度等。
**示例：**
```javascript
    import { wxApi } from '@xtdev/xt-utils-mini';
    await wxApi.getLocation();
    // 成功时 => {latitude: 35.92, longitude: 116.46, speed: -1, accuracy: 65, verticalAccuracy: 65, …}
    // 失败时 => toast 提示 请检查定位权限， Promise reject
```
