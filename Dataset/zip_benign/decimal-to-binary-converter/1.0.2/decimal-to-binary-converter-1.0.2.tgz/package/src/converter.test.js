import { expect } from 'chai'
import { converter, convertFloatToBinary, convertIntegerToBinary } from './converter'

describe('Converter', () => {
  it('should convert decimal 8 to binary 1000', () => {
    expect(convertIntegerToBinary(8)).to.equal('1000')
  })

  it('should convert decimal 0.125 to binary 0.001', () => {
    expect(convertFloatToBinary(0.125)).to.equal('0.001')
  })

  it('should convert decimal 12.875 to binary 1100.111', () => {
    expect(converter(12.875)).to.equal('1100.111')
  })
})
