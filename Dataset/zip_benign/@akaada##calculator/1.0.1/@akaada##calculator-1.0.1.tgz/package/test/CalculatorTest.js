const cal = require('../Calculator');
const assert = require('assert');

describe('test1', () => {
    it('test1', () => {
        assert.equal(cal({
            //公式
            formula: '(x+y)*z',
            //参数
            data: {
                x: 0.1,
                y: 0.2,
                z: 1
            }
        }), 0.3);
    })
});

describe('test2', () => {
    it('test2', () => {
        assert.equal(cal({
            //公式
            formula: '(a+b)*c/d+e',
            //参数
            data: {
                a: 1,
                b: 2,
                c: 3,
                d: 4,
                e: 5
            }
        }), 7.25);
    })
});

describe('test3', () => {
    it('test3', () => {
        assert.equal(cal({
            //公式
            formula: '(a+b)*c/d+e',
            //参数
            data: {
                a: 1,
                b: -2,
                c: 3,
                d: 4,
                e: 5
            }
        }), 4.25);
    })
});

describe('test4', () => {
    it('test4', () => {
        assert.equal(cal({
            //公式
            formula: 'a+b',
            //参数
            data: {
                a: 1,
                b: 2,
            }
        }), 3);
    })
});

describe('test5', () => {
    it('test5', () => {
        assert.equal(cal({
            //公式
            formula: 'a*(b-(c+d)*e-f)*(g-h*(i-j)/(k+l))/(m-n*o)',
            //参数
            data: {
                a: 34,
                b: 23,
                c: 1,
                d: 23,
                e: 4,
                f: 324,
                g: 23,
                h: 32,
                i: 23,
                j: 324,
                k: 34,
                l: 34,
                m: 43,
                n: 45,
                o: 343
            }
        }), 144.3870841995842);
    })
});

describe('test6', () => {
    it('test6', () => {
        assert.equal(cal({
            //公式
            formula: 'a-b-c',
            //参数
            data: {
                a: 1,
                b: 2,
                c: 3
            }
        }), -4);
    })
});

describe('test7', () => {
    it('test7', () => {
        assert.equal(cal({
            //公式
            formula: 'a-(b/(c*(d/(e+f))))',
            //参数
            data: {
                a: -34,
                b: -21,
                c: 7,
                d: 21,
                e: -4,
                f: -10
            }
        }), -36);
    })
});