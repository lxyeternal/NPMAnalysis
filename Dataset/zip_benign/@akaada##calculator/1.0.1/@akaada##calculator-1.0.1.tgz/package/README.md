# Calculator
## 介绍
四则运算计算器，支持四则混合运算(含括号)公式的解析执行。

## 安装
```shell
$ npm install @akaada/calculator
```

## 使用
```javascript
const cal = require('@akaada/calculator');

// print 0.3
console.log(cal({
    //公式
    formula: '(x+y)*z',
    //参数
    data: {
        x: 0.1,
        y: 0.2,
        z: 1
    }
}));
```

## 测试
```shell
$ npm run test
```