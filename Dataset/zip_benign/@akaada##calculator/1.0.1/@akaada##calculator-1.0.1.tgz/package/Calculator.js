const Decimal = require('decimal.js');

// 简单的函数
const isOperand = (element) => !isNaN(element) && !isNaN(parseFloat(element));
const isOperator = (element) => /^\+|-|\*|\/$/.test(element);

/**
 * 四则运算计算入口
 *
 * @param {string} obj - 计算对象
 * @return {number} 计算结果
 * @author robin.lee
 */
function cal(obj) {
    // 对公式进行词法分析
    let tokens = parseToken(obj.formula);
    // 填充数据
    fillInData(tokens, obj.data);
    // 中缀转后缀表达式
    tokens = infixToPostFix(tokens);
    // 计算后缀表达式
    return calPostFixExp(tokens);
}

/**
 * 简单的词法分析：将计算公式分割成数组，同时去除空白元素
 *
 * @param {string} str - 计算公式
 * @return {array} 词元数组
 * @author robin.lee
 */
function parseToken(str) {
    return str.replaceAll(" ", "").split("");
}

/**
 * 填充数据
 *
 * @param {array} tokens - 词元数组
 * @param {object} data - 数据对象
 * @author robin.lee
 */
function fillInData(tokens, data) {
    tokens.forEach((token, index) => {
        if (token in data) {
            tokens[index] = data[token];
        }
    })
}

/**
 * 中缀表达式转后缀表达式
 *
 * @param {array} infixExp - 中缀表达式数组
 * @return {array} 后缀表达式数组
 * @author robin.lee
 */
function infixToPostFix(infixExp) {
    const stack1 = [];  // 运算符栈
    const stack2 = [];  // 操作数栈，目的栈
    const isLevelHigher = (op1, op2) => ['*', '/'].includes(op1) && ['+', '-'].includes(op2); // op1是否比op2优先级高
    const topElement = (stack) => stack[stack.length - 1]; // 获取栈顶元素
    const isEmpty = (stack) => stack.length === 0;

    for (let token of infixExp) {
        if (isOperand(token)) {
            stack2.push(token);
        } else if (isOperator(token)) {
            while (!isEmpty(stack1) && topElement(stack1) !== '(' && !isLevelHigher(token, topElement(stack1))) {
                // 将高级别或同级别运算符压到目的栈
                stack2.push(stack1.pop());
            }
            stack1.push(token);
        } else if (token === '(') {
            stack1.push(token);
        } else if (token === ')') {
            while (!isEmpty(stack1) && (topOp = stack1.pop()) !== '(') {
                stack2.push(topOp);
            }
        } else {
            console.error("unsupported token", token);
        }
    }

    while (!(stack1.length === 0)) {
        stack2.push(stack1.pop());
    }

    return stack2;
}

/**
 * 计算后缀表达式的值
 *
 * @param {array} postFixExp - 后缀表达式数组
 * @return {number} 表达式计算值
 * @author robin.lee
 */
function calPostFixExp(postFixExp) {
    const stack = [];

    const calculate = {
        '+': (v1, v2) => new Decimal(v1).add(new Decimal(v2)).toNumber(),
        '-': (v1, v2) => new Decimal(v1).sub(new Decimal(v2)).toNumber(),
        '*': (v1, v2) => new Decimal(v1).mul(new Decimal(v2)).toNumber(),
        '/': (v1, v2) => new Decimal(v1).div(new Decimal(v2)).toNumber()
    }

    for (let token of postFixExp) {
        if (isOperand(token)) {
            stack.push(token);
        } else if (isOperator(token)) {
            let v1 = stack.pop();
            let v2 = stack.pop();
            stack.push(calculate[token](v2, v1));
        }
    }

    return stack.pop();
}

module.exports = cal;