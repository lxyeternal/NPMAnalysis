export class ZComponent {
  static install(app: any): void
  disabled: boolean
  placeholder: string | string[]
}
