import { ZComponent } from "./ZComponent";

declare class ZMap extends ZComponent {
  value: string
  type: 'like' | 'ne' | 'ge' | 'le'
  trim: boolean
}

export default ZMap
