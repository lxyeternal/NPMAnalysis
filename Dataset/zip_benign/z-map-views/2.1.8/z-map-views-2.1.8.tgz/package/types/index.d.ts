import ZMap from "./ZMap";
import type Vue from 'vue'

export function install(vue: typeof Vue): void;

type ZMapViews = {
  install,
}
export default ZMapViews

export {
  ZMap
}
