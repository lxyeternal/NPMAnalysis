'use strict';
function value(x, r = Math.random()) {
    var i = Math.floor(r * x.length);
    return x[i];
}
module.exports = value;
