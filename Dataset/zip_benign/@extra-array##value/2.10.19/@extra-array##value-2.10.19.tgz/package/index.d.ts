declare module "@extra-array/value" {
/**
 * Picks an arbitrary value.
 * @param x an array
 * @param r random seed 0->1
 */
declare function value<T>(x: T[], r?: number): T;
export = value;
//# sourceMappingURL=value.d.ts.map}
