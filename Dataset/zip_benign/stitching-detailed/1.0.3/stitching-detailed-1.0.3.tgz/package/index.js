var childproc = require('child_process'),
    EventEmitter = require('events').EventEmitter;

var glob = require('glob');


function exec2(file, args /*, options, callback */) {
  var options = { encoding: 'utf8'
                , timeout: 0
                , maxBuffer: 500*1024
                , killSignal: 'SIGKILL'
                , output: null
                };

  var callback = arguments[arguments.length-1];
  if ('function' != typeof callback) callback = null;

  if (typeof arguments[2] == 'object') {
    var keys = Object.keys(options);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (arguments[2][k] !== undefined) options[k] = arguments[2][k];
    }
  }

  var child = childproc.spawn(file, args);
  var killed = false;
  var timedOut = false;

  var Wrapper = function(proc) {
    this.proc = proc;
    this.stderr = new Accumulator();
    proc.emitter = new EventEmitter();
    proc.on = proc.emitter.on.bind(proc.emitter);
    this.out = proc.emitter.emit.bind(proc.emitter, 'data');
    this.err = this.stderr.out.bind(this.stderr);
    this.errCurrent = this.stderr.current.bind(this.stderr);
  };
  Wrapper.prototype.finish = function(err) {
    this.proc.emitter.emit('end', err, this.errCurrent());
  };

  var Accumulator = function(cb) {
    this.stdout = {contents: ""};
    this.stderr = {contents: ""};
    this.callback = cb;

    var limitedWrite = function(stream) {
      return function(chunk) {
        stream.contents += chunk;
        if (!killed && stream.contents.length > options.maxBuffer) {
          child.kill(options.killSignal);
          killed = true;
        }
      };
    };
    this.out = limitedWrite(this.stdout);
    this.err = limitedWrite(this.stderr);
  };
  Accumulator.prototype.current = function() { return this.stdout.contents; };
  Accumulator.prototype.errCurrent = function() { return this.stderr.contents; };
  Accumulator.prototype.finish = function(err) { this.callback(err, this.stdout.contents, this.stderr.contents); };

  var std = callback ? new Accumulator(callback) : new Wrapper(child);

  var timeoutId;
  if (options.timeout > 0) {
    timeoutId = setTimeout(function () {
      if (!killed) {
        child.kill(options.killSignal);
        timedOut = true;
        killed = true;
        timeoutId = null;
      }
    }, options.timeout);
  }

  child.stdout.setEncoding(options.encoding);
  child.stderr.setEncoding(options.encoding);

  child.stdout.on("data", function (chunk) { std.out(chunk, options.encoding); });
  child.stderr.on("data", function (chunk) { std.err(chunk, options.encoding); });

  var version = process.versions.node.split('.');
  child.on(version[0] == 0 && version[1] < 7 ? "exit" : "close", function (code, signal) {
    if (timeoutId) clearTimeout(timeoutId);
    if (code === 0 && signal === null) {
      std.finish(null);
    } else {
      var e = new Error("Command "+(timedOut ? "timed out" : "failed")+": " + std.errCurrent());
      e.timedOut = timedOut;
      e.killed = killed;
      e.code = code;
      e.signal = signal;
      std.finish(e);
    }
  });

  return child;
};

function spawn(file, args /*, options, callback */) {
  var options = { encoding: 'utf8'
                , timeout: 0
                , maxBuffer: 500*1024
                , killSignal: 'SIGKILL'
                , output: null
                };

  var callback = arguments[arguments.length-1];
  if ('function' != typeof callback) callback = null;

  if (typeof arguments[2] == 'object') {
    var keys = Object.keys(options);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      if (arguments[2][k] !== undefined) options[k] = arguments[2][k];
    }
  }

  var child = childproc.spawn(file, args);
  var killed = false;
  var timedOut = false;

  var std = callback ? callback : function(){};
  var current = {};

  var timeoutId;
  if (options.timeout > 0) {
    timeoutId = setTimeout(function () {
      if (!killed) {
        child.kill(options.killSignal);
        timedOut = true;
        killed = true;
        timeoutId = null;
      }
    }, options.timeout);
  }

  child.stdout.setEncoding(options.encoding);
  child.stderr.setEncoding(options.encoding);

  child.stdout.on("data", function (chunk) { std({status: "data", message: chunk}); current = chunk;});
  child.stderr.on("data", function (chunk) { std({status: "data", message: chunk}); current = chunk;});

  var version = process.versions.node.split('.');
  child.on(version[0] == 0 && version[1] < 7 ? "exit" : "close", function (code, signal) {
    if (timeoutId) clearTimeout(timeoutId);
    if (code === 0 && signal === null) {
      std({status: "success", message: ""});
    } else {
      std({status: "fail", message: timedOut ? "timed out" : current});
    }
  });

  return child;
};

var combineCall = function(t, callback) {
  var proc = exports.stitch(t.args, callback);
  return proc;
}

exports.combine = function(options, callback) {
  var t = exports.combineArgs(options);
  return combineCall(t, callback)
}

exports.stitch = function(args, callback) {
  return spawn(exports.stitch.path, args, callback);
}
exports.stitch.path = 'cpp-example-stitching_detailed';

exports.combineArgs = function(options) {
  var opt = {
    img_path: null,
    preview: null,
    try_cuda: 'no',
    work_megapix: '1.0',
    seam_megapix: '0.1',
    compose_megapix: '-1',
    conf_thresh: '1.0',
    features: 'orb',
    matcher: 'homography',
    estimator: 'homography',
    ba: 'ray',
    ba_refine_mask: 'xxxxx',
    wave_correct: 'horiz',
    save_graph: null,
    warp: 'spherical',
    expos_comp: 'gain_blocks',
    match_conf: '0.3',
    seam: 'gc_color',
    blend: 'multiband',
    timelapse: null,
    blend_strength: '5',
    output: 'result.jpg',
    rangewidth: '-1'
  }

  // check options
  if (typeof options !== 'object')
    throw new Error('first argument must be an object');
  for (var k in opt) if (k in options) opt[k] = options[k];
  opt.img_path = opt.img_path+'/*';
  var args = glob.sync(opt.img_path, {nodir:true});

  // build args
  if (opt.preview) {
    args.push('--preview');
  }
  if (opt.try_cuda) {
    args.push('--try_cuda');
    args.push(opt.try_cuda);
  }
  if (opt.work_megapix) {
    args.push('--work_megapix');
    args.push(opt.work_megapix);
  }
  if (opt.seam_megapix) {
    args.push('--seam_megapix');
    args.push(opt.seam_megapix);
  }
  if (opt.compose_megapix) {
    args.push('--compose_megapix');
    args.push(opt.compose_megapix);
  }
  if (opt.conf_thresh) {
    args.push('--conf_thresh');
    args.push(opt.conf_thresh);
  }
  if (opt.features) {
    args.push('--features');
    args.push(opt.features);
  }
  if (opt.matcher) {
    args.push('--matcher');
    args.push(opt.matcher);
  }
  if (opt.estimator) {
    args.push('--estimator');
    args.push(opt.estimator);
  }
  if (opt.ba) {
    args.push('--ba');
    args.push(opt.ba);
  }
  if (opt.ba_refine_mask) {
    args.push('--ba_refine_mask');
    args.push(opt.ba_refine_mask);
  }
  if (opt.wave_correct) {
    args.push('--wave_correct');
    args.push(opt.wave_correct);
  }
  if (opt.save_graph) {
    args.push('--save_graph');
    args.push(opt.save_graph);
  }
  if (opt.warp) {
    args.push('--warp');
    args.push(opt.warp);
  }
  if (opt.expos_comp) {
    args.push('--expos_comp');
    args.push(opt.expos_comp);
  }
  if (opt.match_conf) {
    args.push('--match_conf');
    args.push(opt.match_conf);
  }
  if (opt.seam) {
    args.push('--seam');
    args.push(opt.seam);
  }
  if (opt.blend) {
    args.push('--blend');
    args.push(opt.blend);
  }
  if (opt.timelapse) {
    args.push('--timelapse');
    args.push(opt.timelapse);
  }
  if (opt.blend_strength) {
    args.push('--blend_strength');
    args.push(opt.blend_strength);
  }
  if (opt.output) {
    args.push('--output');
    args.push(opt.output);
  }
  if (opt.rangewidth) {
    args.push('--rangewidth');
    args.push(opt.rangewidth);
  }
  return {opt:opt, args:args};
}
