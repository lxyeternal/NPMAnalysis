# stitching-detailed

[opencv](http://opencv.org/) samples:stitching_detailed module for [Node](http://nodejs.org/).

You can install this module using [npm](http://github.com/isaacs/npm):

    npm install stitching-detailed

Requires opencv:stitching_detailed to be installed.

## Usage

Install with npm

```
npm install stitching-detailed
```

```javascript
var stitchingDetailed = require("stitching-detailed")

// options is optional
stitchingDetailed.combine({
    img_path: 'images'
}, function (result){
  console.log(result.status + ":" +result.message);
})
```

## API

### combine(options, callback(err, stdout, stderr))

Convenience function for combining images, modelled on top of `stitch`.

The `options` argument have the following default values:

```javascript
{
    img_path: null,
    preview: null,
    try_cuda: 'no',
    work_megapix: '1.0',
    seam_megapix: '0.1',
    compose_megapix: '-1',
    conf_thresh: '1.0',
    features: 'orb',
    matcher: 'homography',
    estimator: 'homography',
    ba: 'ray',
    ba_refine_mask: 'xxxxx',
    wave_correct: 'horiz',
    save_graph: null,
    warp: 'spherical',
    expos_comp: 'gain_blocks',
    match_conf: '0.3',
    seam: 'gc_color',
    blend: 'multiband',
    timelapse: null,
    blend_strength: '5',
    output: 'result.jpg',
    rangewidth: '-1'
}
