declare const LunaShaderToyPlayer: import("vue").DefineComponent<import("vue").ExtractPropTypes<{
    style: {
        type: ObjectConstructor;
        default: () => {};
    };
    controls: {
        type: BooleanConstructor;
        default: boolean;
    };
    renderPass: {
        type: ArrayConstructor;
    };
}>, () => import("vue").VNode<import("vue").RendererNode, import("vue").RendererElement, {
    [key: string]: any;
}>, {}, {}, {}, import("vue").ComponentOptionsMixin, import("vue").ComponentOptionsMixin, "create"[], "create", import("vue").PublicProps, Readonly<import("vue").ExtractPropTypes<{
    style: {
        type: ObjectConstructor;
        default: () => {};
    };
    controls: {
        type: BooleanConstructor;
        default: boolean;
    };
    renderPass: {
        type: ArrayConstructor;
    };
}>> & Readonly<{
    onCreate?: ((...args: any[]) => any) | undefined;
}>, {
    style: Record<string, any>;
    controls: boolean;
}, {}, {}, {}, string, import("vue").ComponentProvideOptions, true, {}, any>;
export default LunaShaderToyPlayer;
