declare function piRenderer(): {};
declare function piIsMobile(): boolean;
declare function piCreateGlContext(cv: any, useAlpha: any, useDepth: any, usePreserveBuffer: any, useSupersampling: any): any;
declare function piCreateAudioContext(): any;
declare function piCreateFPSCounter(): {
    Reset: (time: any) => void;
    Count: (time: any) => boolean;
    GetFPS: () => any;
};
export { piCreateAudioContext, piIsMobile, piCreateGlContext, piRenderer, piCreateFPSCounter, };
