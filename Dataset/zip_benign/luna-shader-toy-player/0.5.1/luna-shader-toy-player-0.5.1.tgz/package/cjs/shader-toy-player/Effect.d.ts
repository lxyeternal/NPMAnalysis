declare function Effect(vr: any, ac: any, canvas: any, callback: any, obj: any, forceMuted: any, forcePaused: any, resizeCallback: any, crashCallback: any): void;
export default Effect;
