import Emitter from 'licia/Emitter';
import $ from 'licia/$';
interface IOptions {
    compName: string;
}
export interface IComponentOptions {
    theme?: string;
}
export default class Component<Options extends IComponentOptions = any> extends Emitter {
    c: (name: string) => string;
    container: HTMLElement;
    $container: $.$;
    private subComponents;
    private compName;
    private theme;
    protected options: Required<Options>;
    constructor(container: Element, { compName }: IOptions, { theme: t }?: IComponentOptions);
    destroy(): void;
    setOption(name: string | Partial<Options>, val?: any): void;
    getOption(name: string): any;
    addSubComponent(component: Component): void;
    removeSubComponent(component: Component): void;
    destroySubComponents(): void;
    protected initOptions(options: Options, defs?: any): void;
    protected find(selector: string): $.$;
    private setTheme;
    private onThemeChange;
}
export {};
