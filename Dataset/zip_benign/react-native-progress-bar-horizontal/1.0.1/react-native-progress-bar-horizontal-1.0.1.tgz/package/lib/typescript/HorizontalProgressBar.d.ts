import { FunctionComponent } from 'react';
import type { HorizontalProgressBarProps } from './types';
declare const HorizontalProgressBar: FunctionComponent<HorizontalProgressBarProps>;
export default HorizontalProgressBar;
