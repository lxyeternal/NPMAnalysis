declare const styles: {
    container: {
        width: string;
        overflow: "hidden";
    };
    progress: {
        height: string;
        width: string;
    };
};
export { styles };
