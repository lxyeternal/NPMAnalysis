import { CSSProperties, HTMLProps } from 'react';
declare type MeterColor = {
    stop: number;
    color: CSSProperties['color'];
};
export declare type AudioSpectrumProps = {
    id: string;
    width: number;
    height: number;
    audioId?: string;
    audioEle?: HTMLAudioElement;
    capColor: CSSProperties['color'];
    capHeight: number;
    meterWidth: number;
    meterCount: number;
    meterColor: string | MeterColor[];
    gap: number;
} & HTMLProps<HTMLCanvasElement>;
export default function AudioSpectrum({ width, height, capColor, capHeight, meterWidth, meterCount, meterColor, gap, id, audioEle: propsAudioEl, audioId, ...restProps }: AudioSpectrumProps): JSX.Element;
export {};
