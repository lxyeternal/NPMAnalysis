declare module "@extra-array/permutation-update" {
/**
 * Picks an arbitrary permutation.
 * @param x an array (updated)
 * @param n number of values (-1 => any)
 * @param r random seed 0->1
 * @returns x
 */
declare function permutation$<T>(x: T[], n?: number, r?: number): T[];
export = permutation$;
//# sourceMappingURL=permutation$.d.ts.map}
