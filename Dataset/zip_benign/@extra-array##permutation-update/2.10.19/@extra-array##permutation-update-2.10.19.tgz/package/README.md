Picks an arbitrary permutation.
[:package:](https://www.npmjs.com/package/@extra-array/permutation-update)
[:smiley_cat:](https://github.com/orgs/nodef/packages?repo_name=extra-array)
[:running:](https://npm.runkit.com/@extra-array/permutation-update)
[:vhs:](https://asciinema.org/a/332104)
[:moon:](https://www.npmjs.com/package/@extra-array/permutation-update.min)
[:scroll:](https://unpkg.com/@extra-array/permutation-update/)
[:newspaper:](https://nodef.github.io/extra-array/)
[:blue_book:](https://github.com/nodef/extra-array/wiki/)

> Alternatives: [permutation], [permutation$].<br>
> Similar: [permutation], [permutations], [hasPermutation].

> This is part of package [extra-array].

[extra-array]: https://www.npmjs.com/package/extra-array

<br>

```javascript
array.permutation$(x, [n], [r]);
// x: an array (updated)
// n: number of values (-1 => any)
// r: random seed 0->1
// → x
```

```javascript
const array = require("extra-array");

var x = [1, 2, 3, 4, 5];
array.permutation$(x, 5);
// [ 2, 4, 5, 1, 3 ]

x;
// [ 2, 4, 5, 1, 3 ]

var x = [1, 2, 3, 4, 5];
array.permutation$(x, 5, 0.3);
// [ 5, 3, 1, 2, 4 ]

var x = [1, 2, 3, 4, 5];
array.permutation$(x, 3, 0.3);
// [ 5, 3, 1 ]
```

<br>
<br>


## References

- [shuffle: PHP](https://www.php.net/manual/en/function.shuffle.php)
- [Array.shuffle: sugarjs](https://sugarjs.com/docs/#/Array/shuffle)
- [shuffle-seed: @webcaetano](https://www.npmjs.com/package/shuffle-seed)
- [shuffle-array: @pazguille](https://www.npmjs.com/package/shuffle-array)
- [Seeding the random number generator in Javascript](https://stackoverflow.com/a/47593316/1413259)

[permutation]: https://github.com/nodef/extra-array/wiki/permutation
[permutation$]: https://github.com/nodef/extra-array/wiki/permutation$
[permutations]: https://github.com/nodef/extra-array/wiki/permutations
[hasPermutation]: https://github.com/nodef/extra-array/wiki/hasPermutation
