var Vue = require('vue/dist/vue.js');
var DragResize = require('./src/dragresize/dragresize');

Vue.directive('dragresize', DragResize);

new Vue({
    el : '#app',
    data : function(){
        return {
            name : "ddd"
        };
    },
    methods : {
        resize : function(store, type, el){
            switch(type){
                case 'mousemove':
                    el.style.height = store.rectangle.height + 'px';
                    el.style.width = store.rectangle.width + 'px';
                    break;
            }
        }
    }

});
