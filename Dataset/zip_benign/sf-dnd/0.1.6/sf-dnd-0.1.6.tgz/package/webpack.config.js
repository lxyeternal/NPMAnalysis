module.exports =  {
    entry: "./index.js",
    output: {
        path: "./docs",
        filename: "dist.js"
    },
	//devtool: "source-map",
    resolve:{
        extensions: ['', '.js', '.vue']
    },
    module: {
        loaders: [
            {test: /\.html/, exclude : /node_modules/, loader: 'html'},
			{test: /\.scss$/, exclude : /node_modules/, loader: "style!css!sass" }
        ]
    }
};
