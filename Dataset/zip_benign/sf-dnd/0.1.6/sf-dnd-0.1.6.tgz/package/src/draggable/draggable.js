/**
 * draggable 可拖动容器
 *
 * @author:   波比(｡･∀･)ﾉﾞ
 * @date:     2016-10-15  下午5:27
 */

var dom = require('../dom');
var manage = require('../manage');
var _ = require('lodash');
var dnd = require('../draganddrop');

module.exports = {
	name : 'sf-draggable',
	template : require('./draggable.html'),
	props : {
		axis : {
			type : String,
			default : 'both'
		},
		mode : {
			type : String,
			default : 'inside'
		},
		name : {
			type : String,
			default : ''
		},
		clone : {
			type : Boolean,
			default : false
		}
	},
	computed : {
		classEx : function(){
			return this.name == '' ? this.name : 'm-draggable-'+this.name
		}
	},

	mounted : function(){
		this.$el.setAttribute('data-name', this.name);
	},
	/**
	 * 拖拽数据状态
	 *
	 * @returns {Object} data				- 拖拽数据
	 * 			{String} data.dragState 	- 拽的状态集 underStart, beforeStart, start, process, beforeLeave, leave,
	 * 			{String} data.proxy			- 代理元素
	 * 			{String} data.proxyIndex	- 代理数据偏移量
	 * 			{String} data.proxyData		- 代理数据
	 */
	data : function(){
		return _.merge({}, manage.dragData, {source : null})
	},
	methods : _.merge({},dnd.methods, {
		/**
		 * @override
		 */
		mousedown : function(event){
			event.preventDefault();
			var source = dom.findSuitableNode(this.$el, this.name);
			_.merge(this.$data, {
				proxy : dom.initProxyNode(source),
				source : source
			});

			this.initSourceNodePosition(source);

			if(this.dragState == 'underStart'){
				this.dragState = 'beforeStart';

				// 防止事件引用错误
				this.__mousemoveEvent =  this.mousemove.bind(this);
				this.__mouseupEvent = this.mouseup.bind(this);

				window.addEventListener('mousemove', this.__mousemoveEvent);
				window.addEventListener('mouseup', this.__mouseupEvent);
			}

			var position = dom.getPosition(source);
			this.updatePositionProps({
				clientX : event.clientX,
				clientY : event.clientY,
				startX : event.clientX,
				startY : event.clientY,
				dragX : 0,
				dragY : 0,
				left : position.left,
				top : position.top,
				startLeft : position.left,
				startTop : position.top
			});
		},
		/**
		 * @override
		 */
		mouseup: function(event){
			this.dragState = 'underStart';
			window.removeEventListener('mousemove', this.__mousemoveEvent);
			window.removeEventListener('mouseup', this.__mouseupEvent);
		},
		/**
		 * @override
		 */
		dragstart : function(event){
			if(this.clone){
				dom.appendProxy(this.proxy, 'outside');
			}
		},
		/**
		 * @override
		 */
		dragging : function(event){
			event.preventDefault();
			
			var position = this.position;
			this.updatePositionProps({
				clientX : event.clientX,
				clientY : event.clientY,
				dragX : event.clientX - position.startX,
				dragY : event.clientY - position.startY,
				left : position.startLeft + event.clientX - position.startX,
				top : position.startTop + event.clientY - position.startY
			});
			
			this.nodeMoving(this.clone ? this.proxy : this.source, this.position);
		},
		/**
		 * @override
		 */
		restrict : function(position){
			var axis = this.axis,
				curPosition = {
					left : position.left,
					top  : position.top
				};


			switch(axis){
				case 'x':
				case 'horizontal' :
					curPosition = {
						left : position.left,
						top : position.startTop
					};

					_.merge(position, curPosition);
					break;

				case 'y':
				case 'vertical' :
					curPosition = {
						top : position.top,
						left : position.startLeft
					};

					_.merge(position, curPosition);
					break;

			}

			return curPosition;
		},

		initSourceNodePosition : function(node){
			if(!this.clone){
				dom.setProxyFixed(node, dom.getPosition(node), dom.getSize(node));
			}
		}
	})
};