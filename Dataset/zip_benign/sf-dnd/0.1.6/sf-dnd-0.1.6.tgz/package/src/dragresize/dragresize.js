/**
 * v-dragresize
 *
 * @author:   波比(｡･∀･)ﾉﾞ
 * @date:     2017-02-25  下午7:44
 */
var _ = require('lodash');


function getOffsetSum(elm) {
	var top=0, left=0;
	while(elm) {
		top = top + parseInt(elm.offsetTop);
		left = left + parseInt(elm.offsetLeft);
		elm = elm.offsetParent;
	}
	return {top: top, left: left};
}

var createHandlebar = function(el, className){
	var bar = document.createElement('div');
	bar.className = 'sf-dragresize sf-dragresize--'+className;
	el.parentNode.insertBefore(bar, el);
	bar.style.height = '100%';
	bar.style.width = '10px';
	bar.style.position = 'absolute';
	switch(className){
		case 'w':
			bar.style.cursor = "w-resize";
			break;
		case 'e':
			bar.style.cursor = "e-resize";
			break;
		case 'we':
		case 'ew':
			bar.style.cursor = "ew-resize";
			break;
		case 'n':
			bar.style.cursor = "n-resize";
			break;
		case 's':
			bar.style.cursor = "s-resize";
			break;
		case 'ns':
		case 'sn':
			bar.style.cursor = "ns-resize";
			break;
	}
	return bar;
};

var  configProperty = function(el, store, position){
	var height = el.offsetHeight,
		width = el.offsetWidth;


	var offset = getOffsetSum(store.bar);

	_.merge(store, {
		node : el,
		width : width,
		rectangle : {
			width : width,
			height : height
		},
		height : height,
		top : offset.top,
		left : offset.left
	});



	return store;
};

var checkPosition = function(options, target, store){
	var left = store.left,
		top = store.top,
		clientX = target.clientX,
		clientY = target.clientY;

	var ret = {
		height : store.height,
		width  : store.width
	};


	switch(options){
		case 'w' :
			if(left - clientX > 0){
				store.rectangle.width = store.width + left - clientX;
			}
			break;
		case 'e' :
			if(clientX - left > 0){
				store.rectangle.width = store.width + clientX - left;
			}
			break;
		case 'we' :
		case 'ew' :
				store.rectangle.width = store.width + clientX - left;
			break;
		case 'n' :
			if(top - clientY > 0){
				store.rectangle.height = store.height + top - clientY;
			}
			break;
		case 's' :
			if(clientY - top > 0){
				store.rectangle.height = store.width + clientY - top;
			}
			break;
		case 'sn' :
		case 'ns' :
			store.rectangle.height = store.height + clientY - top;
			break;
	}
};


var scaleDragBar = function(bar){
	bar.style.width = '100%';
	bar.style.zIndex = "9999";
	bar.style.opacity = '0';
	bar.style.transform = "translate(50%)";
};

var resetDragBar = function(bar, position){
	bar.style.width = "10px";
};


module.exports =  {
	inserted: function(el, binding, vnode){

		var bar = createHandlebar(el, binding.arg);
		// set default property
		var store = configProperty(el, _.merge({
			bar : bar
		}, store), binding.arg);

		bar.addEventListener('mousedown',(evt) => {
			if(bar !== evt.target){
				return;
			}

			scaleDragBar(store.bar);

			_.merge(store, {
				resize : true
			});

			vnode.context[binding.expression](store, 'mousedown', store.node);

			var mousemove = function(evt){
				evt.stopPropagation();
				if(store.resize == false){
					return;
				}

				checkPosition(binding.arg, evt, store);
				vnode.context[binding.expression](store, 'mousemove', store.node);
			};

			var mouseup = function(evt){
				evt.stopPropagation();
				_.merge(store, {
					resize : false
				});
				resetDragBar(store.bar);

				vnode.context[binding.expression](store, 'mouseup', store.node);

				window.removeEventListener('mousemove', mousemove);
				window.removeEventListener('mouseup', mouseup);
			};

			// bind event
			window.addEventListener('mousemove', mousemove);
			window.addEventListener('mouseup', mouseup);


		});
	}
};
