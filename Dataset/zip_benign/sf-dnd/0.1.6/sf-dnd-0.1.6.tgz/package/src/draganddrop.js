/**
 * draganddrop 拖拽容器组件
 *
 * @author:   波比(｡･∀･)ﾉﾞ
 * @date:     2016-10-11  下午2:59
 *
 * @props {Boolean} drop			- 可否放置
 * @props {Boolean} drag			- 可否拉起
 * @props {String}  from			- 可接受的数据别名
 * @props {String}  to 				- 可到达的数据别名
 * @props {String} 	name			- DND名称
 * @props {String}	tag				- 容器标签
 * @props {Array}	source			- 数据源
 *
 */

var dom = require('./dom');
var manage = require('./manage');
var _ = require('lodash');

module.exports = {
	name : 'sf-dnd',
	template : require('./draganddrop.html'),
	props : {
		from : {
			type : String,
			default : ''
		},
		source : {
			type : Array,
			default : []
		},
		name : {
			type : String,
			default : ''
		},
		tag : {
			type : String,
			default : 'div'
		}
	},
	computed : {
		classEx : function(){
			return this.name == '' ? this.name : 'sf-dnd-'+this.name
		}
	},
	/**
	 * 拖拽数据状态
	 *
	 * @returns {Object} data				- 拖拽数据
	 * 			{String} data.dragState 	- 拽的状态集 underStart, beforeStart, start, process, beforeLeave, leave,
	 * 			{String} data.proxy			- 代理元素
	 * 			{String} data.proxyIndex	- 代理数据偏移量
	 * 			{String} data.proxyData		- 代理数据
	 */
	data: function(){
		return _.merge({}, manage.dragData)
	},
	mounted : function(){
		this.initNodeProps();
	},
	updated : function(){
		this.initNodeProps();
	},
	methods : {
		/**
		 *
		 * 初始化DND节点属性 data-name, data-from, data-id
		 *
		 */
		initNodeProps : function(){
			var that = this,
				name = this.name;

			clearTimeout(this.__mountTimer);
			that.__mountTimer = setTimeout(function(){
				var vNodes = that.$slots.default,
					elm = null;
				vNodes.forEach(function(itm, index){
					if(itm.elm){
						itm.elm.setAttribute('data-id', itm.key);
						itm.elm.setAttribute('data-name', that.name);
						itm.elm.setAttribute('data-from', that.from);
					}else{
						if(itm.children && itm.children[0].elm){
							var elm =  itm.children[0].elm.parentNode;
							elm.setAttribute('data-id', itm.key);
							elm.setAttribute('data-name', that.name);
							elm.setAttribute('data-from', that.from);
						}
					}

				})
				that.removeAllNodesSliding('is-sliding')
			}, 0)
		},


		/**
		 * 鼠标按下事件
		 *
		 * @event {DOMEvent} event
		 *
		 * @private
		 */
		mousedown : function(event){
			var vNodes = this.$slots.default,
				source = dom.findOfSource(vNodes, event.target);



			event.preventDefault();

			if(source.index == -1) return;



			_.merge(this.$data, {
				proxyData : this.source[source.index],
				proxyIndex : source.index,
				proxy : dom.initProxyNode(dom.findSuitableNode(source.node, this.name), this.name)
			});

			// copy className from source to proxy
			this.proxy.className = source.node.className;
			this.proxy.sourceName = this.name;

			if(this.dragState == 'underStart'){
				this.dragState = 'beforeStart';

				// 防止事件引用错误
				this.__mousemoveEvent =  this.mousemove.bind(this);
				this.__mouseupEvent = this.mouseup.bind(this);

				window.addEventListener('mousemove', this.__mousemoveEvent);
				window.addEventListener('mouseup', this.__mouseupEvent);
			}

			var position = dom.getPosition(source.node);

			this.updatePositionProps({
				clientX : event.clientX,
				clientY : event.clientY,
				startX : event.clientX,
				startY : event.clientY,
				dragX : 0,
				dragY : 0,
				left : position.left,
				top : position.top,
				startLeft : position.left,
				startTop : position.top
			});
		},

		/**
		 * 鼠标放开事件
		 *
		 * @event {DOMEvent} event
		 *
		 * @private
		 */
		mouseup : function(event){
			if(this.dragState == 'process'){
				this.dragend(event);
			}

			
			if(this.dragState != 'underStart'){
				this.dragcancel();
			}



			window.removeEventListener('mousemove', this.__mousemoveEvent);
			window.removeEventListener('mouseup', this.__mouseupEvent);
		},

		/**
		 * 鼠标移动事件
		 *
		 * @event {DOMEvent} event
		 *
		 * @private
		 */
		mousemove : function(event){
			switch(this.dragState){
				case 'beforeStart' :
					this.dragState = 'start';
					this.dragstart(event);
					break;

				case 'start' :
				case 'process':
 					this.dragging(event);
					this.dragState = 'process';
					break;
			}
		},

		/**
		 * 拽开始
		 *
		 * @param {Event} event				- 原生鼠标事件
		 *
		 * @private
		 */
		dragstart : function(event){
			dom.appendProxy(this.proxy, 'inside', this.$el);
		},

		/**
		 * 拽过程中
		 *
		 * @param {Event} event				- 原生鼠标事件
		 *
		 * @private
		 */
		dragging : function(event){
			var position = this.position;

			event.preventDefault();
			this.updatePositionProps({
				clientX : event.clientX,
				clientY : event.clientY,
				dragX : event.clientX - position.startX,
				dragY : event.clientY - position.startY,
				left : position.startLeft + event.clientX - position.startX,
				top : position.startTop + event.clientY - position.startY
			});

			this.nodeMoving(this.proxy, this.position);

			this.slidingNode(event);

		},

		/**
		 * 拽结束
		 *
		 * @param {Event} event			- 原生鼠标事件
		 *
		 * @private
		 */
		dragend : function(event){
			var source = this.proxyPassNode(event.clientX, event.clientY);


			if(source.index != -1){
				if(source.from){
					this.spliceOfIndex(this.proxyIndex, source.index, source.from);
				}else{
					this.swapOfIndex(this.proxyIndex, source.index);
				}

				this.$emit('change', this.source);
			};
		},

		/**
		 * 中途取消拖拽
		 *
		 * @private
		 */
		dragcancel : function(){

			// 重置代理节点
			if(this.proxy && this.proxy.parentElement){
				this.proxy.parentElement.removeChild(this.proxy);
			}

			// 重置数据
			this.updatePositionProps(manage.resPostition);
			this.updateDragData(manage.resDragData);

		},

		/**
		 * 代理节点移动
		 *
		 * @private
		 */
		nodeMoving : function(proxy, position){
			// 位置约束
			var curPosition = this.restrict(position);

			proxy.style.left = curPosition.left + 'px';
			proxy.style.top = curPosition.top + 'px';


		},

		/**
		 * 代理元素途经节点, 判断是否是自己的
		 *
		 * @private
		 */
		proxyPassNode : function(left, top){

			this.proxy.style.display = 'none';

			var node = document.elementFromPoint(left, top),
				vNodes = this.$slots.default,
				source = null;

			if(dom.checkProxyNode(node, this.proxy)){
				source = this.findOfTarget(node)
			}else{
				source = dom.findOfSource(vNodes, node);
			}

			this.proxy.style.display = '';

			return source;
		},

		/**
		 * 找寻目标节点
		 *
		 * @param {Dom}    node			-  节点
		 *
		 * @private
		 */
		findOfTarget : function(node){
			var id = node.getAttribute('data-id'),
				name = node.getAttribute('data-name')

			return {
				index : manage.findDndOfIndex(name, id),
				node : node,
				from : name
			}
		},

		/**
		 * 滑动过的节点
		 *
		 */
		slidingNode : (function(){
			var slideNode = {
				index : -1,
				node : null
			};

			return function(event){
				var source = this.proxyPassNode(event.clientX, event.clientY);

				if(source.index == -1 ) return;

				if(source.node !== slideNode.node){
					slideNode.node ?
						dom.removeClassName(slideNode.node, 'is-sliding')
						:
						dom.removeClassName(source.node, 'is-sliding')
				}

				dom.addClassName(source.node, 'is-sliding');

				slideNode = source;

			}
		})(),

		/**
		 *
		 * 更新拖拽位置属性
		 *
		 * @private
		 */
		updatePositionProps : function(props){
			_.merge(this.position, props);
		},

		/**
		 *
		 * 批量更新拽数据
		 *
		 * @private
		 */
		updateDragData : function(data){
			_.merge(this.$data, data);
		},

		/**
		 *
		 * 更新代理数据
		 *
		 * @param {Node} 	proxy 			- 代理数据
		 * @param {Number}  proxyIndex		- 代理索引
		 * @param {Object}	proxyData		- 代理数据
		 *
		 * @private
		 */
		updateProxyData : function(data){
			_.merge(this.$data, data)
		},

		/**
		 * 移除所有vNode的中间样式
		 *
		 * @param {String} clazz			- 中间样式
		 *
		 * @private
		 */
		removeAllNodesSliding : function(clazz){
			var vNodes = this.$slots.default;

			vNodes.forEach(function(itm){
				if(itm.children && itm.children[0].elm){
					var elm =  itm.children[0].elm.parentNode;
					dom.removeClassName(elm, clazz)
				}
			})
		},

		/**
		 *
		 * 检查边界区域
		 *
		 * @private
		 */
		restrict : function(position){

			_.merge(position, {
				left : position.left,
				top  : position.top
			})

			
			return {
				left : position.left,
				top  : position.top
			}
		},

		/**
		 * 根据索引值交换数据
		 *
		 * @param {Number}	source			- 原始索引
		 * @param {Number}  target			- 目标索引
		 *
		 * @private
		 */
		swapOfIndex : function(source, target){
			var list = this.source;
			list[target] = list.splice(source, 1, list[target])[0]
		},

		/**
		 * 不同组里交换数据
		 *
		 * @param source
		 * @param target
		 * @param name
		 *
		 * @private
		 */
		spliceOfIndex : function(source, target, name){
			var elem = this.source.splice(source, 1)[0];
			window.sfDND[name].splice(target, 0, elem);
		}
	}
}