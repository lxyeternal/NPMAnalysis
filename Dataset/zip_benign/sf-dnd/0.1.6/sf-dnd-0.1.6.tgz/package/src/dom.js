/**
 * mixin
 *
 * @author:   波比(｡･∀･)ﾉﾞ
 * @date:     2016-10-12  下午5:12
 *
 * @function {Function} getPosition				- 获取位置
 * @function {Function} getSize					- 获取节点大小
 * @function {Function}	findOfIndex				- 节点于查找数据员的索引(DOM -- DATA)
 *
 */


var dom =  {
	getPosition : function(elem){
		var doc = elem && elem.ownerDocument,
			docElem = doc.documentElement,
			body = doc.body;

		var box = elem.getBoundingClientRect ? elem.getBoundingClientRect() : { left: 0, top: 0 },
			clientLeft = docElem.clientLeft || body.clientLeft || 0,
			clientTop = docElem.clientTop || body.clientTop || 0;

		return { left: box.left - clientLeft, top: box.top - clientTop };
	},
	getSize : function(elem, mode){
		mode = mode || 'outside';
		switch(mode) {
			case 'outside' :
				return {width: elem.offsetWidth, height: elem.offsetHeight};
			case 'inside' :
				return {width: elem.clientWidth, height: elem.clientHeight};
			case 'center' :
				return {
					width: (elem.clientWidth + elem.offsetWidth) / 2,
					height: (elem.offsetHeight + elem.clientHeight) / 2
				};
		}
	},
	getDimension : function(elem, mode){
		return Object.assign(dom.getSize(elem, mode), dom.getPosition(elem));
	},
	findOfSource : function(vNodes, node){
		var index = -1,
			proxy = null;
		while(node){
			for(var i =0; i<vNodes.length; i++){
				if(vNodes[i].children[0].elm.parentNode === node){
					index = i;
					proxy = vNodes[i].children[0].elm.parentNode;
				}
			}
			if(index > -1)
				break;
			else
				node = node.parentElement
		}

		return {
			index : index,
			node : proxy
		}
	},
	initProxyNode: function(source, name){
		var proxy = source.cloneNode(true);
		proxy.setAttribute('data-name', name);

		dom.setProxyFixed(proxy, dom.getPosition(source), dom.getSize(source));
		return proxy
	},
	setProxyFixed : function(proxy, position, size){
		proxy.style.zIndex = '9999';
		proxy.style.position = 'fixed';
		proxy.style.display = '';

		proxy.style.left = (position.left || 0) + 'px';
		proxy.style.top = (position.top || 0) + 'px';

		proxy.style.width = size.width + 'px';
		proxy.style.height = size.height + 'px';


	},
	appendProxy: function(proxy, mode, parent){
		mode = mode || 'outside';
		switch(mode){
			case 'inside' :
				parent.appendChild(proxy);
				break;
			case 'outside':
				document.body.appendChild(proxy);
				break;
		}
	},
	getComputedStyle : function(node, property){
		var computedStyle = elem.currentStyle || window.getComputedStyle(elem, null);
		return property ? computedStyle[property] : computedStyle;
	},
	removeClassName : function(node, clazz){
		var reg = new RegExp(clazz, 'ig');
		node.className = node.className.replace(reg, '');
	},

	addClassName : function(node, clazz){

		if(node.className == null) return;

		var classNames = node.className.split(' ');
		if(classNames.indexOf(clazz) > -1){
			return;
		}
		classNames.push(clazz);
		node.className = classNames.join(' ');
	},

	checkProxyNode : function(node, proxy){
		return node.getAttribute('data-from') == proxy.getAttribute('data-name')
	},

	findOfTargetById : function(list, id){
		return list.indexOf(id);
	},
	/**
	 * 找到适当的节点
	 *
	 * @param node
	 * @param name
	 */
	findSuitableNode : function(node, name){
		var attr = null;
		while(node){
			attr = node.getAttribute('data-name');
			if(name == attr) {
				return node;
			}

			node = node.parentElement();
		}

	}
}

module.exports = dom;
