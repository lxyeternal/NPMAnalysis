/**
 * manage 数据层
 *
 * @author:   波比(｡･∀･)ﾉﾞ
 * @date:     2016-10-15  下午5:06
 */
var _ = require('lodash');
var position = {
	startX : 0,				// 鼠标开始X坐标
	startY : 0,				// 鼠标开始Y坐标
	startLeft : 0,			// 拖动元素开始X位置
	startTop  : 0,			// 拖动元素开始Y位置
	
	dragX : 0,				// 拖动X轴上偏移
	dragY : 0,				// 拖动Y轴上偏移
	clientX : 0,			// 鼠标当前X坐标
	clientY : 0,			// 鼠标当前Y坐标
	left : 0,  				// 拖动元素当前X位置 startLeft + dragX
	top : 0					// 拖动元素当前Y位置 startTop	+ dragY
};

var resPostition = _.merge({}, position);

var dragData = {
	dragState : 'underStart',
	dropState : 'underStart',
	proxy : null,
	proxyIndex:-1,
	proxyData : null,
	position : position
};

var resDragData = _.merge({}, dragData);


var findDndofIndex = function(source, id){
	var name = window.sfDND.id;

	var list = window.sfDND[source],
		index = -1,
		params = name ? name.split('.') : [],
		iter = null;

	for(var i=0; i<list.length; i++){
		if(!name){
			if(list[i] == id){
				index = i;
				break;
			}
		}else{
			params.forEach(function(sn){
				iter = iter ? iter[sn] : list[i][sn];
			});

			if(iter == id){
				index = i;
				break;
			}
			iter = null
		}


	}

	return index;
}


module.exports = {
	position : position,
	resPosition : resPostition,
	dragData : dragData,
	resDragData : resDragData,
	findDndOfIndex : findDndofIndex
};