let Calculator = require('./modules/Calculator.js');

const result = Calculator.calculate('123.3^(0.5+(2+3))+4+5+6+7+8+99');

console.log(result);