class Stack {
    constructor()
    {
        this.dataArray = [];
    }

    push(pObject)
    {
        this.dataArray.unshift(pObject);
    }

    top()
    {
        return this.dataArray[0];
    }

    pop()
    {
        this.dataArray.shift();
    }

    toString()
    {
        return this.dataArray.join(', ');
    }

    isEmpty()
    {
        return (this.dataArray.length == 0);
    }
}

module.exports = Stack;