class Operand {
    constructor(pValue)
    {
        this.value = pValue;
    }

    getValue()
    {
        return this.value;
    }
}

module.exports = Operand;