const Stack = require('../classes/Stack');
const Operand = require('../classes/Operand');
class Calculator
{
    constructor(){}

    shuntingYard(pInputString)
    {
        const output = [];
        let operatorStack = new Stack;

        let index = 0;
        while(index < pInputString.length)
        {
            let char = pInputString.charAt(index);

            if(Number.isInteger(parseInt(char)))
            {
                let numberString = '';
                do{
                    numberString += char;
                    index++;
                    char = pInputString.charAt(index);
                } while(Number.isInteger(parseInt(char)) || char == '.')

                output.push(new Operand(parseFloat(numberString)));
            } else
            {
                switch(char)
                {
                    case '(':
                        operatorStack.push(char);
                        break;

                    case ')':
                        while(operatorStack.top() != '(')
                        {
                            output.push(operatorStack.top());
                            operatorStack.pop();
                        }
                        operatorStack.pop();
                        break;

                    default:
                        if(this.isSecondOperatorHigherOrEqual(char, operatorStack.top()))
                        {
                            output.push(operatorStack.top());
                            operatorStack.pop();
                        }

                        operatorStack.push(char);
                        break;
                }
                index++;
            }
        }

        while(!operatorStack.isEmpty())
        {
            output.push(operatorStack.top());
            operatorStack.pop();
        }

        return output;
    }

    isOperand(pPotentialOperand)
    {
        if(pPotentialOperand instanceof Operand)
        {
            return true;
        }

        return false;
    }


    isSecondOperatorHigherOrEqual(pOperator1, pOperator2)
    {
        if((pOperator1 == '+' || pOperator1 == '-') && (pOperator2 == '+' || pOperator2 == '-'))
        {
            return true;
        }

        if((pOperator1 == '+' || pOperator1 == '-') && (pOperator2 == '*' || pOperator2 == '/'))
        {
            return true;
        }

        if((pOperator1 == '*' || pOperator1 == '/') && (pOperator2 == '*' || pOperator2 == '/'))
        {
            return true;
        }

        if(pOperator2 == '^')
        {
            return true;
        }

        return false;
    }

    calculate(pInput)
    {
        let shuntingYarded = this.shuntingYard(pInput);
        let operandsStack = new Stack;

        for(let index = 0; index < shuntingYarded.length; index++)
        {
            let char = shuntingYarded[index];

            if(this.isOperand(char))
            {
                operandsStack.push(char);
                continue;
            }

            let secondOperand = operandsStack.top();
            operandsStack.pop();
            let firstOperand = operandsStack.top();
            operandsStack.pop();
        
            operandsStack.push(new Operand(this.calculateOperands(firstOperand, secondOperand, char)));
        }    

        return operandsStack.top().getValue();
    }

    calculateOperands(pFirstOperand, pSecondOperand, pOperator)
    {
        switch(pOperator){
            case '+':
                return pFirstOperand.getValue() + pSecondOperand.getValue();
                
            case '-':
                return pFirstOperand.getValue() - pSecondOperand.getValue();

            case '*':
                return pFirstOperand.getValue() * pSecondOperand.getValue();

            case '/':
                return pFirstOperand.getValue() / pSecondOperand.getValue();

            case '^':
                return Math.pow(pFirstOperand.getValue(), pSecondOperand.getValue());                
        }
    }
}

module.exports = new Calculator;