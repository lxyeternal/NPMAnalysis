## Usage

Just look at this example, self-explanatory (i hope)

```javascript

const Calculator = require('mathstringparse.js');

const expressionString = '123.3^(0.5+(2+3))+4+5+6+7+8+99';

const result = Calculator.calculate(expressionString);

console.log(result); // 316444040725.5883..

```