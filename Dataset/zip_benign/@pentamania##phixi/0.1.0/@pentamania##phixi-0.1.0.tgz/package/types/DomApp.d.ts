import { Mouse as MouseInput, Touch, TouchList, Keyboard, Pointer } from 'phina.js';
import { BaseApp, BaseAppOptions } from './BaseApp';
/**
 * phina.app.DomAppクラスに相当
 * domElement(renderer.view)に各種Inputクラスを付与する
 * ただしaccelerometerはない
 */
export declare class DomApp extends BaseApp {
    mouse: MouseInput;
    touch: Touch;
    touchList: TouchList;
    keyboard: Keyboard;
    pointer: Pointer;
    pointers: Pointer[];
    constructor(params?: BaseAppOptions);
    mount(element: Element): this;
}
