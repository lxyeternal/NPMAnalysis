import { Container } from 'pixi.js';
import { BaseApp } from './BaseApp';
export declare class Updater {
    app: BaseApp;
    constructor(app: BaseApp);
    /**
     * This method will
     *
     * - let object emit "enterframe" event
     * - run object's "onUpdate" method when it is defined
     *
     * and recursively apply same method against child elements.
     *
     * If object's "awake" prop is set to false, these processes will be skipped.
     *
     * @param obj
     */
    updateElement(obj: Container): void;
}
