/**
 * 16進カラー文字列(ex. #FF0033)を16進数に変換
 * すでにnumberの場合はそのまま引数を返す
 *
 * @param strOrNum (ex. "#FF0033", "FF0033", 0xFF0033)
 */
export declare function toHex(strOrNum: string | number): number;
/**
 * 指定数字を指定範囲内に収める
 * @param target
 * @param min
 * @param max
 */
export declare function clamp(target: number, min: number, max: number): number;
/**
 * Event stop helper
 * @param e
 */
export declare const stopEvent: (e: Event) => void;
