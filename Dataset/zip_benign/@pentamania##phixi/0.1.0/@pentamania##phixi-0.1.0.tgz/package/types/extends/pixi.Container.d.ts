declare module 'pixi.js' {
    interface Container {
        /**
         * Sets anchor or pivot of the object.
         *
         * This method is usually for setting `anchor` (in Sprite and it's subclasses),
         * but will try to pretend same for objects that doesn't have `anchor` prop (i.e Graphics class)
         * by updating `pivot` using `width` & `height` props.
         *
         * If neither `anchor` nor `pivot` don't exist, it will do nothing.
         *
         * Chainable
         *
         * @param x origin point x: anchor.x or pivot.x will be updated
         * @param y origin point y: anchor.y or pivot.y will be updated
         * @returns Returns itself.
         */
        setOrigin(x: number, y: number): this;
        /**
         * Set the parent Container of this DisplayObject.
         * Similar to 'setParent', but this method returns itself, which means chainable
         *
         * @param {PIXI.Container} parent - The Container which is added
         * @returns Returns itself.
         */
        addChildTo(parent: PIXI.Container): this;
        /**
         * Remove itself from it's parent.
         *
         * @returns {this} Returns itself.
         */
        remove(): this;
    }
}
export {};
