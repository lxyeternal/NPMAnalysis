import { Accessory, Tweener } from 'phina.js';
declare module 'pixi.js' {
    interface DisplayObject {
        /**
         * Attach phina.accessory
         * @param accessory - phina.accessory.Accessory instance to attach
         */
        attach(accessory: Accessory): this;
        /**
         * Remove attached phina.accessory
         * @param accessory - phina.accessory.Accessory instance to detach
         */
        detach(accessory: Accessory): this;
        /**
         * Private tweener
         */
        _tweener?: Tweener;
        /**
         * Getter for phina.accessory.Tweener
         */
        tweener: Tweener;
        /**
         * Array of phina.accessory.Accessory
         */
        accessories?: Accessory[];
        /**
         * Updating flag of the object.
         *
         * When this property to set to `true`,
         * core app's `Updater` will let this object
         * emit "enterframe" event and tries to run 'onUpdate' method every frame.
         *
         * Recursive update of children objects will be affected too.
         *
         * @default true
         */
        awake: boolean;
        /**
         * App-class driven update function.
         * Run by Updater if defined
         */
        onUpdate?(app?: any): any;
        /**
         * **(phixi extended: only active when phixi.forcePhinaStyle is executed)**
         *
         * App-class driven update function.
         * Run by Updater if defined
         */
        update?(app?: any): any;
        /**
         * Chainable object position setting method
         */
        setPosition(x?: number, y?: number): this;
        /**
         * Chainable object scale setting method
         */
        setScale(x: number, y?: number): this;
        /**
         * Chainable object rotation setting method
         */
        setRotation(v: number): this;
        /**
         * Chainable object alpha setting method
         */
        setAlpha(alpha: number): this;
        /**
         * Chainable object visibility setting method
         */
        setVisible(flag: boolean): this;
        /**
         * Chainable object interactivity setting method
         */
        setInteractive(flag: boolean): this;
        /**
         * Accessor for scale.x
         */
        scaleX: number;
        /**
         * Accessor for scale.y
         */
        scaleY: number;
    }
}
