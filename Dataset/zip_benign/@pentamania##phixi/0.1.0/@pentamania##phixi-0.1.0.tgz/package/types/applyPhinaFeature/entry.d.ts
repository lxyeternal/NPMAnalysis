import { StyleOption } from './styleOption';
/**
 * Apply phina.js style
 *
 * - Override "rotation" to degree base
 * - Enable executing Element "update" method
 *   + Refuge original "update" funcs used in pixi objects
 *
 * @caveats
 * This feature is experimental
 *
 */
export declare function applyPhinaFeature(options: Partial<StyleOption>): void;
