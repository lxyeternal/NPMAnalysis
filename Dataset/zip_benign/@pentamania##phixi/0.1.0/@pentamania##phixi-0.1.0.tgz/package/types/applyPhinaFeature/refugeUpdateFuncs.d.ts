/**
 * This will override AnimatedSprite methods to
 * avoid messing original "update" method by library user
 * defining their custom "update" method,
 * which is common in phina.js-style.
 *
 * @see https://pixijs.download/dev/docs/PIXI.AnimatedSprite.html#update
 */
export declare function refugeAnimatedSpriteUpdate(): void;
