import { utils, Ticker as PixiTicker, Renderer } from 'pixi.js';
import { Ticker as PhinaTicker } from 'phina.js';
import { Updater } from './Updater';
import { Scene } from './Scene';
import { RendererOptions } from './types';
export interface BaseAppOptions extends RendererOptions {
    fps?: number;
}
/**
 * @class BaseApp
 */
export declare class BaseApp extends utils.EventEmitter {
    renderer: Renderer;
    updater: Updater;
    ticker: PhinaTicker;
    drawTicker: PixiTicker;
    private _scenes;
    private _sceneIndex;
    /**
     * @param params
     */
    constructor(params?: BaseAppOptions);
    /**
     * updateループ
     */
    private _loop;
    /**
     * 任意ループ用
     */
    loop(): void;
    /**
     * 描画命令（基本ループ）
     * Sceneスタックを順番にscene描画を行う
     */
    draw(): void;
    run(): void;
    stop(): void;
    replaceScene(scene: Scene): this;
    /**
     * scenesスタックにsceneを追加し、それをcurrentSceneとする
     * - push前のsceneは保持され、popSceneメソッドで容易に戻ることが可能
     * - ポーズやオブション画面など一時的なSceneに使用
     *
     * @param scene
     */
    pushScene(scene: Scene): this;
    /**
     * scenesスタックから現在のsceneを取り出す（取り除く）
     * ポーズやオブション画面など一時的なSceneに対して使用
     */
    popScene(): Scene | undefined;
    /**
     * App本体のcanvas要素を返します
     * @alias domElement
     */
    get view(): HTMLCanvasElement;
    /**
     * App本体のcanvas要素を返します
     * @alias view
     */
    get domElement(): HTMLCanvasElement;
    get currentScene(): Scene;
    set currentScene(v: Scene);
    get frame(): number;
    /**
     * fps設定を返す
     * tweenerの設定によっては必須
     * @see https://runstant.com/pentamania/projects/64c0f4ab
     */
    get fps(): number;
    set backgroundColor(v: number | string);
}
