export declare const LibConfig: {
    enableUpdateFunc: boolean;
    setRotationAsDegree: boolean;
};
