import { Sprite as PixiSprite, Rectangle, Texture as PixiTexture } from 'pixi.js';
declare type PixiTextureOrKey = PixiTexture | string;
/**
 * PIXI.Sprite+α class
 * 文字列keyでの指定ができるなど、phina.js Spriteクラスの特徴を追加
 * textureはframe更新処理のため、cloneする
 */
export declare class Sprite extends PixiSprite {
    _frameIndex: number;
    /**
     * @param texture Texture will be cloned
     * @returns
     */
    constructor(texture: PixiTextureOrKey);
    setTexture(texture: PixiTextureOrKey): this;
    /**
     * @param index Index of frame. Number loops when it exceeds max index
     * @param frameWidth
     * @param frameHeight
     * @returns
     */
    setFrameIndex(index: number, frameWidth?: number, frameHeight?: number): this;
    get srcRect(): Rectangle;
    static getTextureByKey(key: string): PixiTexture;
    static from(source: string | PixiTexture | HTMLCanvasElement | HTMLVideoElement): PixiSprite;
}
export {};
