/**
 * @param row 行
 * @param column 列
 */
declare class Position {
    row: number;
    column: number;
    constructor(row: number, column: number);
}

/**
 * 解析template,生成 tokenTree
 * @param template html字符串
 */
declare class parseTemplate {
    template: string;
    startIndex: number;
    endIndex: number;
    row: number;
    column: number;
    root: Array<Element>;
    elements: Array<any>;
    errors: Array<any>;
    constructor();
    parse(template: string): Element[];
    init(template: string): void;
    linkParentChild(element: any): void;
    insert(element: any): void;
    filterWhiteSpace(container: Array<string>, str: string): void;
    nextEffectiveChar(index: number): {
        nextIndex: number;
        char: string;
    };
    closedElement(tagName: string): void;
    attemptClosedElement(): void;
    attempText(): void;
    attemptValue(start: number): number;
    attemptOpenTag(): void;
    attempNotes(): void;
    /**
     * 替代 indexOf函数【需要统计 row，column】
     *
     * @param str 查找的目标字符
     * @param from 起始点
     * @param column 行
     * @param row 列
     * @returns  index 目标索引; nextRow:行; nextColumn:列; offset: 下一个起始点
     *
     */
    matchString(str: string, from?: number, column?: number, row?: number): false | {
        index: number;
        nextRow: number;
        nextColumn: number;
    };
    position(row?: number, column?: number): Position;
    crossWhiteSpace(start: number, row: number, column: number): {
        nextFrom: number;
        nextRow: number;
        nextColumn: number;
    };
}

export { parseTemplate };
