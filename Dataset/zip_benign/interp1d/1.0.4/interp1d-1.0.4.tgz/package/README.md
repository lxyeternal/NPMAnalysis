# interp1d

### Install:
```
npm install interp1d
```
## Examples / API
```
const interp1d = require('interp1d');

const x = [0, 0.5, 1];
const y = [20, 40, 70];

const f = interp1d(x, y, 2);
let ys = f([0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1]);

console.log(ys); // [19.999999999999996,24.0625,28.750000000000004,34.06250000000001,40,46.562500000000014,53.75,61.5625,70]

```

