const math = require('mathjs');


function interp1d(x, y) {
  const n = x.length;
  const order = 2;
  //const X = new Float64Array(n * (order + 1));
  const X = math.zeros([n, order + 1]);
  const Y = math.matrix(y).reshape([n, 1]);

  for (let i = 0; i < n; i++) {
    for (let j = 0; j <= order; j++) {
      X[i][j] = Math.pow(x[i], j);
    }
  }

  const Xt = math.transpose(X);
  const XtX = math.multiply(Xt, X);
  const XtY = math.multiply(Xt, Y);

  const beta = math.lusolve(XtX, XtY);

  return X => {
    const Y = X.slice();
    for (let t = 0; t < X.length; t++) {
      let y = 0;
      for (let i = 0; i <= order; i++) {
        y += beta[i] * Math.pow(X[t], i);
      }
      Y[t] = y;
    }
    return Y;
  };
}
module.exports = interp1d;