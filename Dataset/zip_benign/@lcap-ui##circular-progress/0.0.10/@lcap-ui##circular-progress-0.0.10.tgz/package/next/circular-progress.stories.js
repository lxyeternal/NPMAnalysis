import React from 'react';
import { storiesOf } from '@storybook/react';
import { CircularProgress } from './';
import { Button } from '../button';
import { List, SimpleListItem } from '../list';
storiesOf('Progress', module).add('CircularProgress', function () { return (React.createElement("div", null,
    React.createElement("div", null,
        React.createElement(CircularProgress, { progress: 0.3 })),
    React.createElement("div", null,
        React.createElement(CircularProgress, { size: "xsmall" }),
        React.createElement(CircularProgress, { size: "small" }),
        React.createElement(CircularProgress, { size: "medium" }),
        React.createElement(CircularProgress, { size: "large" }),
        React.createElement(CircularProgress, { size: "xlarge" }),
        React.createElement(CircularProgress, { size: 72 })),
    React.createElement("div", null,
        React.createElement(React.Fragment, null,
            React.createElement(Button, { icon: React.createElement(CircularProgress, { theme: "secondary" }), text: "Cookies" }),
            React.createElement(List, null,
                React.createElement(SimpleListItem, { graphic: React.createElement(CircularProgress, null), text: "Pizza" }),
                React.createElement(SimpleListItem, { graphic: "favorite", text: "Icecream" })))))); });
