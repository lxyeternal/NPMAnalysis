"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Config = void 0;
const event_1 = require("bdsx/event");
const launcher_1 = require("bdsx/launcher");
const gamerules_1 = require("bdsx/bds/gamerules");
const fs_1 = require("fs");
const path_1 = require("path");
/*
    These should probably never be changed. Unexpected things may happen.

    BASE_DAY_LENGTH is the Minecraft daytime ticks: 24000.
    REAL_MS_IN_DAY is the real miliseconds in a day: 86400000.
*/
const BASE_DAY_LENGTH = 24000;
const REAL_MS_IN_DAY = 86400000;
const pName = "NotoriousPyro's Real Time Day Cycle Plugin";
const logger = (message) => console.log('[plugin:' + pName + '] ' + message);
class Options {
    constructor() {
        this['enabled'] = true;
        this['recalculation-interval'] = 1000;
        this['timecycle-multiplier'] = 1.0;
        this['reference-date'] = new Date().toISOString();
    }
}
class Config {
    constructor() {
        this.rootConfigPath = (0, path_1.join)(process.cwd(), '..', 'config');
        this.configPath = (0, path_1.join)(this.rootConfigPath, 'RealTimeDayCycle');
        this.filename = (0, path_1.join)(this.configPath, 'config.json');
        this.existsOrMkdir(this.rootConfigPath);
        this.existsOrMkdir(this.configPath);
        logger('Loading config from ' + this.filename);
        this.load();
    }
    existsOrMkdir(path) {
        if (!(0, fs_1.existsSync)(path))
            (0, fs_1.mkdirSync)(path);
    }
    load() {
        try {
            this.options = JSON.parse((0, fs_1.readFileSync)(this.filename, 'utf8'));
            const optionsModel = new Options;
            let modified = false;
            for (const prop in optionsModel) {
                if (!this.options.hasOwnProperty(prop)) {
                    this.options[prop] = optionsModel[prop];
                    modified = true;
                }
            }
            if (modified)
                this.save();
        }
        catch (_a) {
            if (!this.options) {
                this.options = new Options;
                this.save();
            }
        }
    }
    save() {
        const SAVE_RETRY = setInterval(() => this.save(), 5000);
        if (this.lock) {
            logger(this.filename + ' is currently locked. Will retry in 5 seconds.');
            return;
        }
        clearInterval(SAVE_RETRY);
        this.lock = true;
        try {
            (0, fs_1.writeFileSync)(this.filename, JSON.stringify(this.options, null, ' '));
        }
        catch (_a) { }
        finally {
            this.lock = false;
        }
    }
}
exports.Config = Config;
const calculateTime = () => {
    const delta = Math.abs(new Date()[Symbol.toPrimitive]('number') - new Date(config.options['reference-date'])[Symbol.toPrimitive]('number'));
    return Math.abs(((delta / REAL_MS_IN_DAY) * BASE_DAY_LENGTH) * config.options['timecycle-multiplier']) | 0;
};
const config = new Config();
// We only want to register an interval once, when the level starts ticking over.
event_1.events.levelTick.once(() => {
    if (!config.options.enabled) {
        logger('Not starting because the mod currently is disabled by configuration file.');
        return;
    }
    logger('Starting up.');
    const SET_TIME_INTERVAL = setInterval(() => launcher_1.bedrockServer.level.setTime(calculateTime()), config.options['recalculation-interval']);
    event_1.events.serverStop.on(() => {
        logger('Shutting down.');
        clearInterval(SET_TIME_INTERVAL); // without this code, bdsx does not end even after BDS closed
    });
});
event_1.events.serverOpen.on(() => {
    logger('Disabling built-in daylight cycle.');
    launcher_1.bedrockServer.gameRules.setRule(gamerules_1.GameRuleId.DoDaylightCycle, false);
});
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyJpbmRleC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFDQSxzQ0FBb0M7QUFDcEMsNENBQThDO0FBQzlDLGtEQUFnRDtBQUNoRCwyQkFBd0U7QUFDeEUsK0JBQTRCO0FBRTVCOzs7OztFQUtFO0FBQ0YsTUFBTSxlQUFlLEdBQUcsS0FBSyxDQUFDO0FBQzlCLE1BQU0sY0FBYyxHQUFHLFFBQVEsQ0FBQztBQUVoQyxNQUFNLEtBQUssR0FBRyw0Q0FBNEMsQ0FBQztBQUMzRCxNQUFNLE1BQU0sR0FBRyxDQUFDLE9BQWUsRUFBRSxFQUFFLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLEdBQUMsS0FBSyxHQUFDLElBQUksR0FBRyxPQUFPLENBQUMsQ0FBQztBQUVqRixNQUFNLE9BQU87SUFBYjtRQUNJLGVBQVMsR0FBRyxJQUFJLENBQUM7UUFDakIsOEJBQXdCLEdBQUcsSUFBSSxDQUFDO1FBQ2hDLDRCQUFzQixHQUFHLEdBQUcsQ0FBQztRQUM3QixzQkFBZ0IsR0FBRyxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFDO0lBQ2hELENBQUM7Q0FBQTtBQUNELE1BQWEsTUFBTTtJQU9mO1FBSmlCLG1CQUFjLEdBQVcsSUFBQSxXQUFJLEVBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQTtRQUM1RCxlQUFVLEdBQVcsSUFBQSxXQUFJLEVBQUMsSUFBSSxDQUFDLGNBQWMsRUFBRSxrQkFBa0IsQ0FBQyxDQUFBO1FBQ2xFLGFBQVEsR0FBVyxJQUFBLFdBQUksRUFBQyxJQUFJLENBQUMsVUFBVSxFQUFFLGFBQWEsQ0FBQyxDQUFBO1FBR3BFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO1FBQ3hDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQ3BDLE1BQU0sQ0FBQyxzQkFBc0IsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDL0MsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO0lBQ2hCLENBQUM7SUFFTyxhQUFhLENBQUMsSUFBWTtRQUM5QixJQUFJLENBQUMsSUFBQSxlQUFVLEVBQUMsSUFBSSxDQUFDO1lBQUUsSUFBQSxjQUFTLEVBQUMsSUFBSSxDQUFDLENBQUM7SUFDM0MsQ0FBQztJQUVPLElBQUk7UUFDUixJQUFJO1lBQ0EsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUEsaUJBQVksRUFBQyxJQUFJLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7WUFDL0QsTUFBTSxZQUFZLEdBQUcsSUFBSSxPQUFPLENBQUM7WUFDakMsSUFBSSxRQUFRLEdBQUcsS0FBSyxDQUFDO1lBQ3JCLEtBQUssTUFBTSxJQUFJLElBQUksWUFBWSxFQUFFO2dCQUM3QixJQUFJLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUU7b0JBQ25DLElBQUksQ0FBQyxPQUFlLENBQUMsSUFBSSxDQUFDLEdBQUksWUFBb0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDMUQsUUFBUSxHQUFHLElBQUksQ0FBQztpQkFDbkI7YUFDSjtZQUNELElBQUksUUFBUTtnQkFBRSxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUM7U0FDN0I7UUFBQyxXQUFNO1lBQ0osSUFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUU7Z0JBQ2YsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLE9BQU8sQ0FBQztnQkFDM0IsSUFBSSxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ2Y7U0FDSjtJQUNMLENBQUM7SUFFTyxJQUFJO1FBQ1IsTUFBTSxVQUFVLEdBQUcsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBRSxJQUFJLENBQUMsQ0FBQztRQUN4RCxJQUFJLElBQUksQ0FBQyxJQUFJLEVBQUU7WUFDWCxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxnREFBZ0QsQ0FBQyxDQUFDO1lBQ3pFLE9BQU87U0FDVjtRQUNELGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUMxQixJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztRQUNqQixJQUFJO1lBQ0EsSUFBQSxrQkFBYSxFQUFDLElBQUksQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLElBQUksRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDO1NBQ3pFO1FBQ0QsV0FBTSxHQUFFO2dCQUNBO1lBQ0osSUFBSSxDQUFDLElBQUksR0FBRyxLQUFLLENBQUM7U0FDckI7SUFDTCxDQUFDO0NBQ0o7QUF0REQsd0JBc0RDO0FBRUQsTUFBTSxhQUFhLEdBQUcsR0FBRyxFQUFFO0lBQ3ZCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBUSxDQUFDLEdBQUcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7SUFDNUksT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsY0FBYyxDQUFDLEdBQUcsZUFBZSxDQUFDLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQy9HLENBQUMsQ0FBQTtBQUVELE1BQU0sTUFBTSxHQUFHLElBQUksTUFBTSxFQUFFLENBQUM7QUFFNUIsaUZBQWlGO0FBQ2pGLGNBQU0sQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRTtJQUN2QixJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUU7UUFDekIsTUFBTSxDQUFDLDJFQUEyRSxDQUFDLENBQUE7UUFDbkYsT0FBTztLQUNWO0lBQ0QsTUFBTSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQ3ZCLE1BQU0saUJBQWlCLEdBQUcsV0FBVyxDQUFDLEdBQUcsRUFBRSxDQUFDLHdCQUFhLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxhQUFhLEVBQUUsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUMsd0JBQXdCLENBQUMsQ0FBQyxDQUFDO0lBQ3BJLGNBQU0sQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLEdBQUcsRUFBRTtRQUN0QixNQUFNLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztRQUN6QixhQUFhLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLDZEQUE2RDtJQUNuRyxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUMsQ0FBQyxDQUFDO0FBRUgsY0FBTSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFO0lBQ3RCLE1BQU0sQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO0lBQzdDLHdCQUFhLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxzQkFBVSxDQUFDLGVBQWUsRUFBRSxLQUFLLENBQUMsQ0FBQztBQUN2RSxDQUFDLENBQUMsQ0FBQyJ9