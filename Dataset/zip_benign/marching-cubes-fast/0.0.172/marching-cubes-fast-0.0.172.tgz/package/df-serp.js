//serp fractal df ported from https://www.fractalforums.com/sierpinski-gasket/kaleidoscopic-(escape-time-ifs)/
//posted by knightly [https://www.fractalforums.com/index.php?action=profile;u=932]

const scale = 2;
const bailout = 1000;

function sierpinski3(x, y, z) {
    let r = x * x + y * y + z * z;
    let i;
    for(i = 0; i < 10 && r < bailout; i++) {
        // Folding... These are some of the symmetry planes of the tetrahedron
        if(x + y < 0) {
            let x1 = -y;
            y = -x;
            x = x1;
        }
        if(x + z < 0) {
            let x1 = -z;
            z = -x;
            x = x1;
        }
        if(y + z < 0) {
            let y1 = -z;
            z = -y;
            y = y1;
        }

        // Stretche about the point [1,1,1]*(scale-1)/scale; The "(scale-1)/scale" is here in order to keep the size of the fractal constant wrt scale
        x = scale * x - (scale - 1);
        y = scale * y - (scale - 1);
        z = scale * z - (scale - 1);
        r = x * x + y * y + z * z;
    }
    return (Math.sqrt(r) - 2) * Math.pow(scale, -i); // the estimated distance
}

module.exports = {sierpinski3}