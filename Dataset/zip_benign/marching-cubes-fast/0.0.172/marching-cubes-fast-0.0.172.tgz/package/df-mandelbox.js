// Global parameters
const scale = 2; // Usually 2 for Mandelbox, but you can adjust
const bailout = 1000;
const MI = 3; // Maximum iterations, you can adjust based on desired detail
const BOX_MIN = -1; // Define this based on your needs
const BOX_MAX = 1; // Define this based on your needs

function MandelboxDistance(x, y, z) {
    let dr = 1.0; // Derivative
    let r = 0;
    let i;

    // Initial point
    let cx = x;
    let cy = y;
    let cz = z;

    for (i = 0; i < MI && r < bailout; i++) {
        // Box fold
        if (x > BOX_MAX) x = 2 * BOX_MAX - x;
        else if (x < BOX_MIN) x = 2 * BOX_MIN - x;

        if (y > BOX_MAX) y = 2 * BOX_MAX - y;
        else if (y < BOX_MIN) y = 2 * BOX_MIN - y;

        if (z > BOX_MAX) z = 2 * BOX_MAX - z;
        else if (z < BOX_MIN) z = 2 * BOX_MIN - z;

        // Sphere fold
        r = x * x + y * y + z * z;
        if (r < 0.25) {
            x *= 4;
            y *= 4;
            z *= 4;
            dr *= 4;
        } else if (r < 1) {
            const tempScale = 2 / r;
            x *= tempScale;
            y *= tempScale;
            z *= tempScale;
            dr *= tempScale;
        }

        // Scale and translate
        x = x * scale + cx;
        y = y * scale + cy;
        z = z * scale + cz;
        dr = dr * scale + 1.0;
    }

    return 0.5 * Math.log(r) * Math.sqrt(r) / dr;
}

module.exports = {MandelboxDistance};

// Example usage:
// console.log(MandelboxDistance(1, 1, 1));
