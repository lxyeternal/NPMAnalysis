var mcf = require('./index.js');


//create a signed distance function - here we have 3d simplex noise

// var {SimplexNoise} = require('simplex-noise');
// var simplex = new SimplexNoise(1004);
// var dfSimplex3d = function(x,y,z){
//     var s = 20.0
//     return simplex.noise3D(x/s,y/s,z/s)+0.5;
// }

var dfSerp = require('./df-serp.js').sierpinski3;
var dfMeng = require('./df-menger.js').Menger3;
var dfMandelBox = require('./df-mandelbox.js').MandelboxDistance;
var dfMandelBulb = require('./df-mandelbulb.js').MandelbulbDistance;


//polygonize the field - convert it to triangles with marching cubes

var resolution = 256; //scanning resolution, must be a power of 2
var s = 3;
var scanBounds = [[-s,-s,-s],[s,s,s]]; //bounding box to scan over

var outputName = "./meng2.stl";
var doPrintProgress = true;
// var result = mcf.marchingCubesSlow(resolution, dfSerp, scanBounds,doPrintProgress); //version that goes through ALL cubes, slow
var result = mcf.marchingCubes(resolution, dfMeng, scanBounds,doPrintProgress);

//console.log(result);

// {
//     positions: [  //vertices
//         [ 0.2039299646182391, 1, 0 ],
//         [ 0, 0.7943976862618888, 0 ],
//         [ 0, 1, 0.8012346044071122 ],
//          ...
//     cells: [      //faces
//         [ 1, 0, 2 ],       [ 3, 4, 5 ],
//         [ 14, 12, 13 ],    [ 14, 13, 10 ],
//         [ 16, 18, 15 ],    [ 19, 21, 20 ],
//         ...

var ti = require('triangles-index');

var tris1 = ti.deindexTriangles_meshView(result);

var {colorsByBoundingBlockRelativePosition, rescaleTrisForLargestDimSize} = require('./rescale-tris.js');

tris1 = rescaleTrisForLargestDimSize(tris1,10);
var colors = colorsByBoundingBlockRelativePosition(tris1);

// var config = {
//     tris:tris1,
//     triangleColors: colors,
//     resolution: 64,
//     aspectRatio: 1.0,
//     mouseControl:false,
//     cameraPos: [22,29,-12],
//     cameraRot: [2.2,-4.4]
// }
// require('ascii-raytracer').runScene(config);

//save the result...
var stl = require('stl');
var objectToSave = require('./triangles2Object.js').convertTrianglesToObject(tris1, "desc for " + outputName);
var isBinary = true;
require('fs').writeFileSync(outputName, stl.fromObject(objectToSave, isBinary));
