function ptsRelativeToBb(pts,bb){
    var bbDimsPt = bbDims(bb);
    return pts.map(function(pt){
        return lu.scalePtByPtInv(lu.ptDiff(pt,bb[0]),bbDimsPt)
    });
}

function trisRelativeToBb(tris,bb){
    return tris.map(function(tri){
        return ptsRelativeToBb(tri,bb);
    });
}

function bbDims(bb){
    return lu.ptDiff(bb[1],bb[0])
}

function getPtInBb(ptRelative,bb){
    var bbDimsPt = bbDims(bb);
    return lu.addPts(bb[0],lu.scalePtByPt(ptRelative,bbDimsPt));
}

function bbLongestDim(bb){
    return Math.max(...bbDims(bb));
}

var bbt = require('./bb-tris.js');
const lu = require("./line-utils-basic");
function rescaleTrianglesToBb(tris,bbDesired){
    var trisBb = bbt(tris);
    var trisR = trisRelativeToBb(tris, trisBb);
    return trisR.map(function(tri){
        return tri.map(function(pt){
            return getPtInBb(pt,bbDesired);
        });
    });
}

function rescaleTrisForLargestDimSize(tris,size=10){
    var desiredMaxDim = size;
    var bl = bbLongestDim(bbt(tris));
    return rescaleTrianglesToBb(tris, [[0,0,0],lu.scalePtByPt([desiredMaxDim/bl,desiredMaxDim/bl,desiredMaxDim/bl], bbDims(bbt(tris)))]);
}

function averagePts3(p0, p1, p2){
    return [(p0[0]+p1[0]+p2[0])/3, (p0[1]+p1[1]+p2[1])/3, (p0[2]+p1[2]+p2[2])/3];
}

function colorsByBoundingBlockRelativePosition(tris){
    var trisBb = bbt(tris);
    return trisRelativeToBb(tris, trisBb).map(t=>averagePts3(t[0],t[1],t[2]))
}

module.exports = {colorsByBoundingBlockRelativePosition, ptsRelativeToBb, bbDims, getPtInBb, bbLongestDim, rescaleTrianglesToBb, rescaleTrisForLargestDimSize};