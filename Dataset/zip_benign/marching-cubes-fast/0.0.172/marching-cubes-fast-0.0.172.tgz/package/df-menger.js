//menger fractal df ported from https://www.fractalforums.com/sierpinski-gasket/kaleidoscopic-(escape-time-ifs)/
//posted by knightly [https://www.fractalforums.com/index.php?action=profile;u=932]

const MI = 5;        // Define MI value -- max iters
var bailout = 1000;   // Define bailout value
const scale = 3;     // Define scale value
const CX = 1;        // Define CX value
const CY = 1;        // Define CY value
const CZ = 1;        // Define CZ value

//guess at rotate1 and rotate2 functions
const theta = 90 * Math.PI / 180;
const phi = 90 * Math.PI / 180;

function rotate1(x, y, z) {
    // Rotate around the X-axis by theta
    let newY = y * Math.cos(theta) - z * Math.sin(theta);
    let newZ = y * Math.sin(theta) + z * Math.cos(theta);
    y = newY;
    z = newZ;
}

function rotate2(x, y, z) {
    // Rotate around the Y-axis by phi
    let newX = z * Math.sin(phi) + x * Math.cos(phi);
    let newZ = z * Math.cos(phi) - x * Math.sin(phi);
    x = newX;
    z = newZ;
}


function Menger3(x, y, z) {
    let r = x * x + y * y + z * z;
    let i=0;

    for(i = 0; i < MI && r < bailout; i++) {

        rotate1(x, y, z);

        x = Math.abs(x);
        y = Math.abs(y);
        z = Math.abs(z);

        if(x - y < 0) {
            let x1 = y;
            y = x;
            x = x1;
        }
        if(x - z < 0) {
            let x1 = z;
            z = x;
            x = x1;
        }
        if(y - z < 0) {
            let y1 = z;
            z = y;
            y = y1;
        }

        rotate2(x, y, z);

        x = scale * x - CX * (scale - 1);
        y = scale * y - CY * (scale - 1);
        z = scale * z;
        if(z > 0.5 * CZ * (scale - 1)) {
            z -= CZ * (scale - 1);
        }

        r = x * x + y * y + z * z;
    }
    return (Math.sqrt(x * x + y * y + z * z) - 2) * Math.pow(scale, -i);
}

module.exports = {Menger3}