var fmcvl = require('./fast-marching-cubes-voxel-list.js');
var dfsb = require('./df-sub-blocks.js');

function powerOfTwo(x) {
    return (Math.log(x)/Math.log(2)) % 1 === 0;
}

function marchingCubesFast(RES, POTENTIAL, WORLD_BOUNDS, printProgress=false){
    if(!powerOfTwo(RES)){
        throw 'resolution must be power of 2';
    }
    var ITERS = Math.floor(Math.log2(RES)-1);
    if(printProgress){console.log('marching cubes: getting sub-blocks...');}
    var blocks = dfsb.getSubBlocksForBlockIteratedDFunc_edgesOnly(WORLD_BOUNDS, ITERS, POTENTIAL);
    if(printProgress){console.log(`marching cubes: got ${blocks.length} sub-blocks.`);}
    var tris = fmcvl.marchingCubes(POTENTIAL, blocks, printProgress); //{faces, vertices}
    return tris;
}

function marchingCubesSlow(RES, POTENTIAL, WORLD_BOUNDS, printProgress=false){
    if(!powerOfTwo(RES)){
        throw 'resolution must be power of 2';
    }
    var ITERS = Math.floor(Math.log2(RES)-1);
    if(printProgress){console.log('marching cubes: getting sub-blocks...');}
    var blocks = dfsb.getSubBlocksForBlockIteratedDFunc_edgesOnly(WORLD_BOUNDS, ITERS, function(){return 0});
    if(printProgress){console.log(`marching cubes: got ${blocks.length} sub-blocks.`);}
    var tris = fmcvl.marchingCubes(POTENTIAL, blocks, printProgress); //{faces, vertices}
    return tris;
}

//TODO maybe calculate hausdorff dimension ?

module.exports = {
    getSubBlocksRecursive: dfsb.getSubBlocksForBlockIteratedDFunc_edgesOnly,
    getSubBlocksRecursiveIncVolume: dfsb.getSubBlocksForBlockIteratedDFunc_includeVolume,
    marchingCubes: marchingCubesFast,
    marchingCubesVoxelList: fmcvl.marchingCubes,
    marchingCubesSlow
}