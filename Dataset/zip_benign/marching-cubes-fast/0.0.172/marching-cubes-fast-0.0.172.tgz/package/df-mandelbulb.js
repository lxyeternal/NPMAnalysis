// Global parameters
const POWER = 8; // This is the 'n' in the formula r^n. 8 is a common value for the Mandelbulb.
const MI = 10; // Maximum iterations, adjust based on desired detail
const bailout = 4;
const BAILOUT_RADIUS = Math.sqrt(bailout);

function MandelbulbDistance(x, y, z) {
    let zx = x;
    let zy = y;
    let zz = z;

    let dr = 1.0;
    let r = 0.0;

    for (let i = 0; i < MI && r < bailout; i++) {
        r = Math.sqrt(zx * zx + zy * zy + zz * zz);
        let theta = Math.acos(zz / r);
        let phi = Math.atan2(zy, zx);
        dr = Math.pow(r, POWER - 1) * POWER * dr + 1.0;

        let zr = Math.pow(r, POWER);
        theta = theta * POWER;
        phi = phi * POWER;

        zx = zr * Math.sin(theta) * Math.cos(phi) + x;
        zy = zr * Math.sin(theta) * Math.sin(phi) + y;
        zz = zr * Math.cos(theta) + z;
    }

    return 0.5 * Math.log(r) * r / dr;
}

module.exports = {MandelbulbDistance}