import { ComponentRender } from '@zeedhi/common';
import { ICalendar, CalendarEvents, ICalendarEvents } from './interfaces';
export declare class Calendar extends ComponentRender implements ICalendar {
    title?: string;
    showHeader?: boolean;
    categories?: string | [];
    categoryDays?: number | string;
    categoryForInvalid?: string;
    categoryHideDynamic?: boolean | string;
    categoryShowAll?: boolean | string;
    categoryText?: string | Function;
    contentHeight?: number | string;
    color?: string;
    dayFormat?: Function | null;
    end?: string | number | Date;
    eventCategory?: string | Function;
    eventColor?: string | Function;
    eventEnd?: string;
    eventHeight?: number;
    eventMarginBottom?: number;
    eventMore?: boolean;
    eventMoreText?: string;
    eventName?: string | Function;
    eventOverlapMode?: string | Function;
    eventOverlapThreshold?: string | number;
    eventStart?: string;
    eventTextColor?: string | Function;
    eventTimed?: string | Function;
    calendarEvents?: CalendarEvents[];
    fillHeight: boolean;
    firstInterval?: number | string;
    firstTime?: number | string | object;
    height?: string | number;
    hideHeader?: boolean;
    intervalCount?: number | string;
    intervalFormat?: Function | null;
    intervalHeight?: number | string;
    intervalMinutes?: number | string;
    intervalStyle?: Function | null;
    dayStyle?: ((date: string) => object | string) | null;
    intervalWidth?: number | string;
    locale?: string;
    localeFirstDayOfYear?: number | string;
    maxDays?: number;
    minWeeks?: any;
    monthFormat?: Function | null;
    now?: string;
    shortIntervals?: boolean;
    shortMonths?: boolean;
    shortWeekDays?: boolean;
    showIntervalLabel?: Function | null;
    showMonthOnFirst?: boolean;
    showWeek?: boolean;
    start?: string | number | Date;
    type?: string;
    value?: string | number | Date;
    weekdayFormat?: Function | null;
    weekdays?: string | string[] | number[];
    selectTypeData?: {};
    canEditEvent?: ((event: CalendarEvents) => boolean) | boolean;
    canDeleteEvent?: ((event: CalendarEvents) => boolean) | boolean;
    /**
   * Events registered to the calendar
   */
    events: ICalendarEvents;
    constructor(props: ICalendar);
    goToToday(element?: any, event?: Event): void;
    beforeNext(element: any, event?: Event): void;
    /**
     * Event triggered when the current slide changes.
     * @param event Event that triggered the next button event
     * @param element Calendar element
     */
    next(element: any, event?: Event): void;
    beforePrevious(element: any, event?: Event): void;
    /**
     * Event triggered when the current slide changes.
     * @param event Event that triggered the previous button event
     * @param element Calendar element
     */
    previous(element: any, event?: Event): void;
    addCalendarEvents(events: CalendarEvents[]): void;
    updateCalendarEvent(events: CalendarEvents[]): void;
    clearCalendarEvents(): void;
    removeCalendarEvents(events: CalendarEvents[]): void;
    clickDate(element: any, event: Event): void;
    clickMore(element: any, event: Event): void;
    clickDay(element: any, event: Event): void;
    clickEvent(calendarEvent: CalendarEvents, element: any, event: Event): void;
    clickDeleteEvent(calendarEvent: CalendarEvents, element: any, event: Event): void;
    clickEditEvent(calendarEvent: CalendarEvents, element: any, event: Event): void;
    clickDayCategory(element: any, event: Event): void;
    clickInterval(element: any, event: Event): void;
    clickTime(element: any, event: Event): void;
    clickTimeCategory(element: any, event: Event): void;
    moved(element: any, event: Event): void;
}
