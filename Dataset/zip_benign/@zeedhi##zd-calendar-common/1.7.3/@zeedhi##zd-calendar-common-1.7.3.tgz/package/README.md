# Componente Calendar para Zeedhi

<center>
<p>
  <a href="#instalação">Instalação</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#uso-básico">Uso Básico</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#propriedades">Propriedades</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
  <a href="#metodos">Métodos</a>&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;
</p>
</center>

<p>O component zd-calendar renderizar um calendar onde pode ser adicionado eventos.</p>

<p align="center">
  <img alt="zd-calendar" src="./img/calendar.jpg" width="100%">
</p>

## Instalação

Para instalar o pacote basta rodar o seguinte comando:\
`npm i @zeedhi/zd-calendar`\
Com isso, dois pacotes serão instalados: o @zeedhi/zd-calendar-common e o @zeedhi/zd-calendar-vue.\
Após a instalação, é necessário que você importe o pacote @zeedhi/zd-calendar-vue dentro de seu arquivo de configuração `zeedhi.ts`

```
import ZdCalendar from '@zeedhi/zd-calendar-vue';

Vue.component('ZdCalendar', ZdCalendar);
```

Já o pacote @zeedhi/zd-calendar-common deve ser importado no arquivo controller do componente.

## Uso Básico

Para usar, defina a propriedade component como 'ZdCalendar'.

```
{
  "name": "calendar-example",
  "component": "ZdCalendar"
}
```

## Propriedades

<table>
  <thead>
    <tr>
      <th>Nome</th>
      <th>Tipo</th>
      <th>Default</th>
      <th>Descrição</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>categories</td>
      <td>array | string</td>
      <td>undefined</td>
      <td>Especifica quais categorias exibir na exibição de categorias. Isso também controla a ordem das categorias. Se o calendário usar eventos, quaisquer categorias especificadas nesses eventos não especificados neste valor serão renderizadas dinamicamente na visualização, a menos que categoryHideDynamic seja true.</td>
    </tr>
    <tr>
      <td>categoryDays</td>
      <td>number | string</td>
      <td>1</td>
      <td>O número de dias para renderizar na exibição de categoria.</td>
    </tr>
    <tr>
      <td>categoryForInvalid</td>
      <td>string</td>
      <td>undefined</td>
      <td>A categoria para colocar eventos que têm categorias inválidas. Uma categoria é inválida quando não é uma string. Por padrão, eventos sem categoria não são exibidos até que esse valor seja especificado</td>
    </tr>
    <tr>
      <td>categoryHideDynamic</td>
      <td>boolean</td>
      <td>false</td>
      <td>Define se as categorias especificadas em um evento devem ser ocultadas se não estiverem definidas nas categorias.</td>
    </tr>
    <tr>
      <td>categoryShowAll</td>
      <td>boolean</td>
      <td>false</td>
      <td>Defina se a exibição de categoria deve mostrar todas as categorias definidas, mesmo que não haja eventos para uma categoria.</td>
    </tr>
    <tr>
      <td>categoryText</td>
      <td>string | function</td>
      <td>undefined</td>
      <td>Reduz a largura máxima do conteúdo para 70%.</td>
    </tr>
    <tr>
      <td>color</td>
      <td>string</td>
      <td>undefined</td>
      <td>Aplica a cor especificada ao controle - pode ser o nome da cor do material (por exemplo, success ou purple) ou cor css (#033 ou rgba(255, 0, 0, 0.5)). Você pode encontrar uma lista de classes internas na <a href="https://vuetifyjs.com/en/styles/colors/#material-colors" target="_blank"> página de cores.</a></td>
    </tr>
    <tr>
      <td>dark</td>
      <td>boolean</td>
      <td>false</td>
      <td>
				Aplica o tema dark ao calendar
			</td>
    </tr>
    <tr>
      <td>dayFormat</td>
      <td>function</td>
      <td>null</td>
      <td>Formata a string do dia do mês que aparece em um dia para uma localidade especificada</td>
    </tr>
    <tr>
      <td>end</td>
      <td>string | number | date</td>
      <td>undefined</td>
      <td>A data de término no calendário (inclusive) no formato AAAA-MM-DD. Isso pode ser ignorado dependendo do tipo de calendário.</td>
    </tr>
    <tr>
      <td>eventColor</td>
      <td>string | function</td>
      <td>primary</td>
      <td><p>Defina a propriedade da categoria do evento.</p>
      <p>Em vez de uma propriedade pode ser dada uma função que recebe um evento e retorna a categoria.</p></td>
    </tr>
    <tr>
      <td>eventColor</td>
      <td>string | function</td>
      <td>primary</td>
      <td>Uma cor de fundo para todos os eventos ou uma função que aceita um objeto de evento passado para o calendário para retornar uma cor.</td>
    </tr>
    <tr>
      <td>eventEnd</td>
      <td>string</td>
      <td>end</td>
      <td>Defina a propriedade timestamp de término dos eventos.</td>
    </tr>
    <tr>
      <td>eventHeight</td>
      <td>number</td>
      <td>20</td>
      <td>A altura de um evento em pixels na visualização do mês e na parte superior das visualizações do dia.</td>
    </tr>
    <tr>
      <td>eventMarginBottom</td>
      <td>number</td>
      <td>1</td>
      <td>Margem inferior para evento</td>
    </tr>
    <tr>
      <td>eventMore</td>
      <td>boolean</td>
      <td>true</td>
      <td>Mostra o botão mais eventos</td>
    </tr>
    <tr>
      <td>eventMoreText</td>
      <td>string</td>
      <td>CALENDAR_MORE</td>
      <td>Define o texto do botão mais calendarEvent</td>
    </tr>
    <tr>
      <td>eventName</td>
      <td>string | function</td>
      <td>name</td>
      <td>Defina a propriedade do nome exibido do evento, ou uma função que aceita um objeto de evento passado para o calendário como o primeiro argumento e um sinalizador sinalizando se o nome é para um evento cronometrado (true) ou um evento durante um dia.</td>
    </tr>
    <tr>
      <td>eventOverlapMode</td>
      <td>string</td>
      <td>stack</td>
      <td>Define o modo como o calendarEvent sera exibido <code>stack</code> <code>column</code><td>
    </tr>
    <tr>
      <td>eventOverlapThreshold</td>
      <td>string | number</td>
      <td>60</td>
      <td>Um valor em minutos que é usado para determinar se dois eventos cronometrados devem ser colocados na coluna um ao lado do outro ou devem ser tratados como eventos levemente sobrepostos.</td>
    </tr>
    <tr>
      <td>eventStart</td>
      <td>string | function</td>
      <td>start</td>
      <td>Defina a propriedade timestamp de início dos eventos.</td>
    </tr>
    <tr>
      <td>eventTextColor</td>
      <td>string | function</td>
      <td>white</td>
      <td>Define a cor do texto do evento calendar</td>
    </tr>
    <tr>
      <td>eventTimed</td>
      <td>string | function</td>
      <td>timed</td>
      <td>Se Datas ou milissegundos são usados como timestamp inicial ou final de um evento, essa propriedade pode ser uma string para uma propriedade no evento que é verdadeira se o evento for um evento cronometrado ou uma função que recebe o evento e retorna um valor verdadeiro se o evento for um evento cronometrado.</td>
    </tr>
    <tr>
      <td>eventsCalendar</td>
      <td>array</td>
      <td>CalendarEvents[]</td>
      <td>Define um array de object de CalendarEvents</td>
    </tr>
    <tr>
      <td>firstInterval</td>
      <td>number | string</td>
      <td>0</td>
      <td>O primeiro intervalo a ser exibido na exibição do dia. Se intervalMinutes for definido como 60 e for definido como 9:00, a primeira vez na exibição será às 9h.</td>
    </tr>
    <tr>
      <td>firstTime</td>
      <td>number | string | object</td>
      <td>undefined</td>
      <td>A primeira vez a ser exibida na visualização diurna. Se especificado, isso substitui qualquer valor de firstInterval especificado. Este pode ser o número de minutos desde a meia-noite, uma string no formato HH:mm ou um objeto com propriedades numéricas hora e minuto.</td>
    </tr>
    <tr>
      <td>hideHeader</td>
      <td>boolean</td>
      <td>false</td>
      <td>Se o cabeçalho na parte superior da visualização do dia deve estar visível.</td>
    </tr>
    <tr>
      <td>intervalCount</td>
      <td>number | string</td>
      <td>24</td>
      <td>O número de intervalos a serem exibidos na exibição do dia.</td>
    </tr>
    <tr>
      <td>intervalFormat</td>
      <td>function</td>
      <td>null</td>
      <td>Formata a sequência de hora do dia que aparece na medianiz de intervalo da exibição de dia e semana para a localidade especificada</td>
    </tr>
    <tr>
      <td>intervalHeight</td>
      <td>number | string</td>
      <td>48</td>
      <td>A altura de um intervalo em pixels na visualização do dia.</td>
    </tr>
    <tr>
      <td>intervalMinutes</td>
      <td>number | string</td>
      <td>60</td>
      <td>O número de minutos que os intervalos estão na exibição do dia. Um intervalo comum é de 60 minutos, então os intervalos são de uma hora.</td>
    </tr>
    <tr>
      <td>intervalStyle</td>
      <td>function</td>
      <td>null</td>
      <td>Retorna um estilo de CSS a ser aplicado ao intervalo.</td>
    </tr>
    <tr>
      <td>intervalWidth</td>
      <td>number | string</td>
      <td>60</td>
      <td>Define a largura do <code>gutter</code> ao lado esquerdo na visualização dia.</td>
    </tr>
    <tr>
      <td>ligth</td>
      <td>boolean</td>
      <td>false</td>
      <td>Define o tema ligth ao componente</td>
    </tr>
    <tr>
      <td>locale</td>
      <td>string</td>
      <td>pt-BR</td>
      <td>Define a localidade do calendário</td>
    </tr>
    <tr>
      <td>localeFirstDayOfYear</td>
      <td>string | number</td>
      <td>0</td>
      <td>Define o dia que determina a primeira semana do ano, começando com 0 para domingo. Para ISO 8601, isso deve ser 4.</td>
    </tr>
    <tr>
      <td>maxDays</td>
      <td>number</td>
      <td>7</td>
      <td>O número máximo de dias a serem exibidos no calendário personalizado se um dia de término não for definido.</td>
    </tr>
    <tr>
      <td>minWeek</td>
      <td>any</td>
      <td>1</td>
      <td>O número mínimo de semanas a serem exibidas na exibição de mês ou semana.</td>
    </tr>
    <tr>
      <td>monthFormat</td>
      <td>function</td>
      <td>null</td>
      <td>Formata a string do mês que aparece em um dia para a localidade especificada</td>
    </tr>
    <tr>
      <td>now</td>
      <td>string</td>
      <td>undefined</td>
      <td>Substitui o dia e a hora que são considerados agora. Está no formato YYYY-MM-DD hh:mm:ss. O calendário é estilizado de acordo com <code>now</code>.</td>
    </tr>
    <tr>
      <td>selectTypeData</td>
      <td>object</td>
      <td>undefined</td>
      <td>Define uma data ao componente select com os tipos de visualizção do calendário.</td>
    </tr>
    <tr>
      <td>shortIntervals</td>
      <td>boolean</td>
      <td>true</td>
      <td>Os intervalos na visualização do dia serão 9h, em vez de 09h.</td>
    </tr>
    <tr>
      <td>shortMonths</td>
      <td>boolean</td>
      <td>true</td>
      <td>Se as versões curtas de um mês devem ser usadas (jan vs janeiro).</td>
    </tr>
    <tr>
      <td>shortWeekday</td>
      <td>boolean</td>
      <td>true</td>
      <td>Se as versões curtas de um dia da semana devem ser usadas (seg vs segunda-feira).</td>
    </tr>
    <tr>
      <td>shortIntervalsLabel</td>
      <td>boolean</td>
      <td>true</td>
      <td>Verifica se um determinado dia e hora devem ser exibidos no <code>gutter</code> de intervalo da visualização do dia.</td>
    </tr>
    <tr>
      <td>showHeader</td>
      <td>boolean</td>
      <td>true</td>
      <td>Mostra o cabeçalho do calendário com opções de navegação e trocar o modo de visualização</td>
    </tr>
    <tr>
      <td>showMonthOnFirst</td>
      <td>boolean</td>
      <td>true</td>
      <td>Se o nome do mês deve ser exibido no primeiro dia do mês.</td>
    </tr>
    <tr>
      <td>showWeek</td>
      <td>boolean</td>
      <td>false</td>
      <td>Se os números da semana devem ser exibidos ao usar a visualização do mês.</td>
    </tr>
    <tr>
      <td>start</td>
      <td>string | number | date</td>
      <td>new Date()</td>
      <td>A data de início no calendário (inclusive) no formato YYYY-MM-DD. Isso pode ser ignorado dependendo do tipo de calendário.</td>
    </tr>
    <tr>
      <td>title</td>
      <td>string</td>
      <td></td>
      <td>Define um titulo para o calendário, é exibido se showHeader for true</td>
    </tr>
    <tr>
      <td>type</td>
      <td>string</td>
      <td>month</td>
      <td>Uma string que pode ser month, week, day, 4day, custom-weekly, custom-daily ou category. Os tipos personalizados analisam as datas de início e término passadas para o componente em oposição ao valor.</td>
    </tr>
    <tr>
      <td>value</td>
      <td>string | number | date</td>
      <td>undefined</td>
      <td>Uma data no formato YYYY-MM-DD que determina o intervalo de tempo do calendário.</td>
    </tr>
    <tr>
      <td>weekdayFormat</td>
      <td>function</td>
      <td>null</td>
      <td>Formata a string do dia da semana que aparece no cabeçalho para a localidade especificada</td>
    </tr>
    <tr>
      <td>weekdays</td>
      <td>array | string</td>
      <td>[0, 1, 2, 3, 4, 5, 6]</td>
      <td>Especifica quais dias da semana serão exibir. Para exibir somente de segunda a sexta-feira, um valor de [1, 2, 3, 4, 5] pode ser usado. Para exibir uma semana começando na segunda-feira, um valor de [1, 2, 3, 4, 5, 6, 0] pode ser usado.</td>
    </tr>
  </tbody>
</table>

<hr>

## Métodos

<table>
  <thead>
    <tr>
      <th>Nome</th>
      <th>Propriedades</th>
      <th>Descrição</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>addCalendarEvents</td>
      <td>CalendarEvents[]</td>
      <td>Adicionar novos calendarEvent ao calendar</td>
    </tr>
    <tr>
      <td>updateCalendarEvent</td>
      <td>CalendarEvents[]</td>
      <td>Atualizar um calendarEvent ao calendar</td>
    </tr>
    <tr>
      <td>clearCalendarEvents</td>
      <td></td>
      <td>Remove todos os calendarEvent do calendar</td>
    </tr>
    <tr>
      <td>removeCalendarEvents</td>
      <td>CalendarEvents[]</td>
      <td>Remove um calendarEvents do calendar</td>
    </tr>
  </tbody>
</table>

<hr>

## CalendarEvents

```
type CalendarEvents = {
  id: string | number;
  name: string;
  start: string | Date;
  end: string | Date;
  description?: string;
  color?: string;
  timed?: boolean;
  category?: string;
};

```