import { ModuleWithProviders } from '@angular/core';
import { WebsiteCallConfig } from './website-call.component';
import * as i0 from "@angular/core";
import * as i1 from "./website-call.component";
import * as i2 from "@angular/common";
import * as i3 from "@angular/router";
import * as i4 from "@fortawesome/angular-fontawesome";
export declare class WebsiteCallModule {
    static forRoot(config: WebsiteCallConfig): ModuleWithProviders<WebsiteCallModule>;
    static ɵfac: i0.ɵɵFactoryDeclaration<WebsiteCallModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<WebsiteCallModule, [typeof i1.WebsiteCallComponent], [typeof i2.CommonModule, typeof i3.RouterModule, typeof i4.FontAwesomeModule], [typeof i1.WebsiteCallComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<WebsiteCallModule>;
}
