import { IconDefinition } from '@fortawesome/free-solid-svg-icons';
import * as i0 from "@angular/core";
export declare class WebsiteCallComponent {
    phone: string;
    animation: boolean;
    icon: IconDefinition;
    constructor(moduleConfig?: WebsiteCallConfig);
    static ɵfac: i0.ɵɵFactoryDeclaration<WebsiteCallComponent, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<WebsiteCallComponent, "website-call", never, { "phone": "phone"; "animation": "animation"; "icon": "icon"; }, {}, never, never, false>;
}
export declare class WebsiteCallConfig {
    phone: string;
    animation: boolean;
    icon: IconDefinition | null;
}
