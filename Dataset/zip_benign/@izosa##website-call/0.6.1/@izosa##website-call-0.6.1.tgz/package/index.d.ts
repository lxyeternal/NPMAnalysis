/**
 * Generated bundle index. Do not edit.
 */
/// <amd-module name="@izosa/website-call" />
export * from './public-api';
