<table>
    <tr>
        <td><img src="https://www.static.izosa.com/website/logo.svg" width="100" height="100"></td>
        <td>
        <h2> Call</h2>
        Website component for call button</td>
    </tr>
</table>

## Properties

<table>
    <tr>
        <th>Name</th>
        <th>Type</th>
        <th>Options</th>
        <th>Default</th>
    </tr>
    <tr>
        <td>phone</td>
        <td>string</td>
        <td>✅⚙️</td>
        <td>-</td>
    </tr>
    <tr>
        <td>animation</td>
        <td>boolean</td>
        <td>☑️⚙️</td>
        <td>true</td>
    </tr>
    <tr>
        <td>icon</td>
        <td>IconDefinition</td>
        <td>☑️⚙️</td>
        <td>faPhone</td>
    </tr>
</table>

<hr>

```
<website-call [url]="'+3598888888888'"></website-call>
```

## CSS Properties

<table>
    <tr>
        <th>Name</th>
        <th>Default Value</th>
    </tr>
    <tr>
        <td>--size:</td>
        <td>3.75rem</td>
    </tr>
    <tr>
        <td>--margin:</td>
        <td>1.25rem</td>
    </tr>
    <tr>
        <td>--background:</td>
        <td>#3bb91b</td>
    </tr>
    <tr>
        <td>--background-hover:</td>
        <td>#{darken($background, 5%)}</td>
    </tr>
        <tr>
        <td>--background-shadow:</td>
        <td>#{rgba($background, 0.3)}</td>
    </tr>
    <tr>
        <td>--color:</td>
        <td>#ffffff</td>
    </tr>
    <tr>
        <td>--animation-duration:</td>
        <td>2s</td>
    </tr>
        <tr>
        <td>--animation-repeat:</td>
        <td>5</td>
    </tr>
        <tr>
        <td>--animation-delay:</td>
        <td>2s</td>
    </tr>
</table>

<hr>

```
website-call{
    $background: #ee9012;
    --background: #{$background};
    --background-hover: #{darken($background, 5%)};
    --background-shadow: #{rgba($background, 0.3)};
    --color: #ffffff;
    --margin: 1.25rem;
    --size: 3.75rem;
    --animation-duration: 2s;
    --animation-repeat: 5;
    --animation-delay: 2s;
}
```
