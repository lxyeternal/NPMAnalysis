import * as i0 from '@angular/core';
import { Component, ChangeDetectionStrategy, Optional, Input, NgModule } from '@angular/core';
import { faPhone } from '@fortawesome/free-solid-svg-icons';
import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i2 from '@fortawesome/angular-fontawesome';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { RouterModule } from '@angular/router';

class WebsiteCallComponent {
    constructor(moduleConfig) {
        this.phone = '';
        this.animation = true;
        this.icon = faPhone;
        if (moduleConfig) {
            this.phone = moduleConfig.phone;
            this.animation = moduleConfig.animation;
            this.icon = moduleConfig.icon !== null ? moduleConfig.icon : this.icon;
        }
    }
}
WebsiteCallComponent.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.2.12", ngImport: i0, type: WebsiteCallComponent, deps: [{ token: WebsiteCallConfig, optional: true }], target: i0.ɵɵFactoryTarget.Component });
WebsiteCallComponent.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "14.2.12", type: WebsiteCallComponent, selector: "website-call", inputs: { phone: "phone", animation: "animation", icon: "icon" }, ngImport: i0, template: "<a\n  *ngIf=\"phone !== ''\"\n  class=\"circle\"\n  [ngClass]=\"{animation: animation}\"\n  href=\"tel:{{ phone }}\"\n  [attr.aria-label]=\"phone\"\n  ><fa-icon [icon]=\"icon\"></fa-icon\n></a>\n", styles: [".circle{position:fixed;bottom:var(--margin, 1.25rem);right:var(--margin, 1.25rem);width:var(--size, 3.75rem);height:var(--size, 3.75rem);line-height:var(--size, 3.75rem);font-size:calc(var(--size, 3.75rem) / 2 - 2px);border-radius:50%;text-align:center;background:var(--background, #3bb91b);color:var(--color, #ffffff);cursor:pointer;box-shadow:0 4px 10px 0 var(--background-shadow, rgba(59, 185, 27, .3))}.circle:hover{background:var(--background-hover, #34a318)}.circle.animation{animation:pulse var(--animation-duration, 2s) var(--animation-repeat, 5) var(--animation-delay, 2s) cubic-bezier(.25,0,0,1)}@keyframes pulse{to{box-shadow:0 0 0 18px transparent}}\n"], dependencies: [{ kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "component", type: i2.FaIconComponent, selector: "fa-icon", inputs: ["icon", "title", "spin", "pulse", "mask", "styles", "flip", "size", "pull", "border", "inverse", "symbol", "rotate", "fixedWidth", "classes", "transform", "a11yRole"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.2.12", ngImport: i0, type: WebsiteCallComponent, decorators: [{
            type: Component,
            args: [{ selector: 'website-call', changeDetection: ChangeDetectionStrategy.OnPush, template: "<a\n  *ngIf=\"phone !== ''\"\n  class=\"circle\"\n  [ngClass]=\"{animation: animation}\"\n  href=\"tel:{{ phone }}\"\n  [attr.aria-label]=\"phone\"\n  ><fa-icon [icon]=\"icon\"></fa-icon\n></a>\n", styles: [".circle{position:fixed;bottom:var(--margin, 1.25rem);right:var(--margin, 1.25rem);width:var(--size, 3.75rem);height:var(--size, 3.75rem);line-height:var(--size, 3.75rem);font-size:calc(var(--size, 3.75rem) / 2 - 2px);border-radius:50%;text-align:center;background:var(--background, #3bb91b);color:var(--color, #ffffff);cursor:pointer;box-shadow:0 4px 10px 0 var(--background-shadow, rgba(59, 185, 27, .3))}.circle:hover{background:var(--background-hover, #34a318)}.circle.animation{animation:pulse var(--animation-duration, 2s) var(--animation-repeat, 5) var(--animation-delay, 2s) cubic-bezier(.25,0,0,1)}@keyframes pulse{to{box-shadow:0 0 0 18px transparent}}\n"] }]
        }], ctorParameters: function () { return [{ type: WebsiteCallConfig, decorators: [{
                    type: Optional
                }] }]; }, propDecorators: { phone: [{
                type: Input
            }], animation: [{
                type: Input
            }], icon: [{
                type: Input
            }] } });
class WebsiteCallConfig {
}

class WebsiteCallModule {
    static forRoot(config) {
        return {
            ngModule: WebsiteCallModule,
            providers: [{ provide: WebsiteCallConfig, useValue: config }],
        };
    }
}
WebsiteCallModule.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "14.2.12", ngImport: i0, type: WebsiteCallModule, deps: [], target: i0.ɵɵFactoryTarget.NgModule });
WebsiteCallModule.ɵmod = i0.ɵɵngDeclareNgModule({ minVersion: "14.0.0", version: "14.2.12", ngImport: i0, type: WebsiteCallModule, declarations: [WebsiteCallComponent], imports: [CommonModule, RouterModule, FontAwesomeModule], exports: [WebsiteCallComponent] });
WebsiteCallModule.ɵinj = i0.ɵɵngDeclareInjector({ minVersion: "12.0.0", version: "14.2.12", ngImport: i0, type: WebsiteCallModule, imports: [CommonModule, RouterModule, FontAwesomeModule] });
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "14.2.12", ngImport: i0, type: WebsiteCallModule, decorators: [{
            type: NgModule,
            args: [{
                    declarations: [WebsiteCallComponent],
                    imports: [CommonModule, RouterModule, FontAwesomeModule],
                    exports: [WebsiteCallComponent],
                }]
        }] });

/*
 * Public API Surface of website-call
 */

/**
 * Generated bundle index. Do not edit.
 */

export { WebsiteCallComponent, WebsiteCallConfig, WebsiteCallModule };
//# sourceMappingURL=izosa-website-call.mjs.map
