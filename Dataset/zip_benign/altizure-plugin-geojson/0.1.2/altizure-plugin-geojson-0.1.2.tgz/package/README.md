# altizure-plugin-geojson

The GeoJson plugin for Altizure Javascript SDK.

___
## usage
This plugin needs `altizure` defined. 

### in js
This plugin has to be used together with the `altizure` module. Make sure `altizure` is in your dependencies (or devDependencies) list in `package.json` file.

```
import {Sandbox} from 'altizure'
import {queryGeoJsonForAltizureProjectMarker, polygonsFromGeoJson} from 'altizure-plugin-geojson'

let options = {
  altizureApi:{
    key: your key here...
  }
}
let sandbox = new Sandbox('page-content', options)

let projectMarkerID = '572e2668ad5ed4204d2f8e5a'
sandbox.add('AltizureProjectMarker', {pid: projectMarkerID})
.then((m) => {
  // lookat the AltizureProjectMarker
  sandbox.camera.lookAt(m, 0, 0, undefined)
  // query for geojson for this AltizureProjectMarker
  queryGeoJsonForAltizureProjectMarker(m).then((res) => {
    let polygons = polygonsFromGeoJson(res.geojson, sandbox, {top: 80, bottom: 10, color: 0x0000ff, opacity: 0.3})
  })
})
```

### in html
Include `altizure-sdk.min.js` before this plugin.

```
<head>
  <script type="text/javascript" src="https://unpkg.com/altizure/release/altizure-sdk.min.js"></script>
  <script type="text/javascript" src="https://unpkg.com/altizure-plugin-geojson"></script>
</head>
<body>
  <div id="page-content" />
  <script>
    let options = {
      altizureApi:{
        key: your key here...
      }
    }
    let sandbox = new altizure.Sandbox('page-content', options)

    let projectMarkerID = '572e2668ad5ed4204d2f8e5a'
    sandbox.add('AltizureProjectMarker', {pid: projectMarkerID})
    .then((m) => {
      // lookat the AltizureProjectMarker
      sandbox.camera.lookAt(m, 0, 0, undefined)
      // query for geojson for this AltizureProjectMarker
      if (altizure.GeoJson) {
        altizure.GeoJson.queryGeoJsonForAltizureProjectMarker(m).then((res) => {
          let polygons = altizure.GeoJson.polygonsFromGeoJson(res.geojson, sandbox, {top: 80, bottom: 10, color: 0x0000ff, opacity: 0.3})
        })
      }
    })
  </script>
</body>

```