export declare class Layers {
    static readonly ALL_LAYER = 0;
}
