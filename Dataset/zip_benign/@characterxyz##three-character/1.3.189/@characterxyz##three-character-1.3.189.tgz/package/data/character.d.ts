import { Character as CharacterDataModel, VisualStyle } from '../types';
import { APIRequestResult, FetchCharacterInput } from '../types';
export declare function getCharacterData(slug: string | undefined, visualStyle: VisualStyle | undefined): Promise<APIRequestResult<CharacterDataModel>>;
export declare function getCharactersData(fetchCharacaterInputs: FetchCharacterInput[]): Promise<APIRequestResult<Record<string, Partial<CharacterDataModel>>>>;
