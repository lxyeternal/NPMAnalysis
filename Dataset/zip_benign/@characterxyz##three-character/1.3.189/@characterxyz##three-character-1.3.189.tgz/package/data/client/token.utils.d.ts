export declare const AUTH_TOKEN_KEY: string;
export declare const getAuthToken: () => string | null | undefined;
export declare function setAuthToken(token: string): void;
export declare function removeAuthToken(): void;
export declare function checkHasAuthToken(): boolean;
