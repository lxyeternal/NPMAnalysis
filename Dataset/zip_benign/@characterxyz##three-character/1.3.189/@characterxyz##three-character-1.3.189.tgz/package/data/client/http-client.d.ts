import { AxiosError } from 'axios';
export declare class HttpClient {
    static requestWithRetry<T>(requestFunc: () => Promise<{
        data: T;
    }>, retry?: boolean): Promise<T>;
    static isAxiosError(error: any): error is AxiosError;
    static get<T>(url: string, params?: unknown, options?: any): Promise<T>;
    static post<T>(url: string, data: unknown, options?: any): Promise<T>;
    static patch<T>(url: string, data: unknown, options?: any): Promise<T>;
    static put<T>(url: string, data: unknown): Promise<T>;
    static delete<T>(url: string, data?: unknown): Promise<T>;
}
