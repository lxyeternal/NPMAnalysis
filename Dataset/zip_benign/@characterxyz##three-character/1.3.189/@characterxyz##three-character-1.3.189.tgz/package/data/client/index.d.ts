import { APIRequestResult, Character, FetchCharacterInput, FetchCharactersInput } from '../../types';
declare class Client {
    characters: {
        getOneBySlug: (data: FetchCharacterInput) => Promise<APIRequestResult<Character>>;
        getMultiple: (data: FetchCharactersInput[]) => Promise<APIRequestResult<Record<string, Partial<Character>>>>;
    };
}
declare const _default: Client;
export default _default;
