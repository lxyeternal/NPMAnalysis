export declare const API_ENDPOINTS: {
    CHARACTERS_SLUG: string;
    CHARACTERS_MULTIPLE: string;
};
