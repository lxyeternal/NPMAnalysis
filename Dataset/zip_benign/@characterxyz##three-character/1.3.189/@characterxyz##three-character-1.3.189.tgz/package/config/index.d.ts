export declare const ConfigValue: {
    CHARACTERXYZ_API_KEY: string | undefined;
    PUBLIC_REST_API_ENDPOINT: string;
    PUBLIC_WEBSITE_URL: string;
    AUTH_TOKEN_KEY: string;
};
