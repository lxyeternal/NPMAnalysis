import ri, { Component as vh } from "react";
import Wl from "react-dom";
import ql from "path";
import Gl from "os";
import Kl from "crypto";
import { jsx as Ia, Fragment as Yl } from "react/jsx-runtime";
/**
 * @license
 * Copyright 2010-2023 Three.js Authors
 * SPDX-License-Identifier: MIT
 */
const Ah = "157", Dn = 0, Xl = 1, Jl = 2, Ca = 1, Zl = 100, Ql = 204, tc = 205, ec = 3, ic = 0, Mh = 300, Ri = 1e3, vi = 1001, er = 1002, ir = 1003, nc = 1004, sc = 1005, kr = 1006, rc = 1007, zr = 1008, ac = 1009, Eh = 1015, Th = 1023, oc = 2200, Sh = 2201, hc = 2202, Pi = 2300, ei = 2301, es = 2302, Ye = 2400, Xe = 2401, Bn = 2402, Ur = 2500, lc = 2501, cc = 0, Rh = 1, nr = 2, uc = 3e3, is = 3001, dc = 0, In = "", st = "srgb", St = "srgb-linear", fc = "display-p3", Ph = "display-p3-linear", sr = "linear", Oa = "srgb", Na = "rec709", La = "p3", ns = 7680, pc = 519, rr = 35044, Me = 2e3, ar = 2001;
class Ci {
  addEventListener(t, e) {
    this._listeners === void 0 && (this._listeners = {});
    const i = this._listeners;
    i[t] === void 0 && (i[t] = []), i[t].indexOf(e) === -1 && i[t].push(e);
  }
  hasEventListener(t, e) {
    if (this._listeners === void 0)
      return !1;
    const i = this._listeners;
    return i[t] !== void 0 && i[t].indexOf(e) !== -1;
  }
  removeEventListener(t, e) {
    if (this._listeners === void 0)
      return;
    const n = this._listeners[t];
    if (n !== void 0) {
      const s = n.indexOf(e);
      s !== -1 && n.splice(s, 1);
    }
  }
  dispatchEvent(t) {
    if (this._listeners === void 0)
      return;
    const i = this._listeners[t.type];
    if (i !== void 0) {
      t.target = this;
      const n = i.slice(0);
      for (let s = 0, r = n.length; s < r; s++)
        n[s].call(this, t);
      t.target = null;
    }
  }
}
const it = ["00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "0a", "0b", "0c", "0d", "0e", "0f", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "1a", "1b", "1c", "1d", "1e", "1f", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "2a", "2b", "2c", "2d", "2e", "2f", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "3a", "3b", "3c", "3d", "3e", "3f", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "4a", "4b", "4c", "4d", "4e", "4f", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59", "5a", "5b", "5c", "5d", "5e", "5f", "60", "61", "62", "63", "64", "65", "66", "67", "68", "69", "6a", "6b", "6c", "6d", "6e", "6f", "70", "71", "72", "73", "74", "75", "76", "77", "78", "79", "7a", "7b", "7c", "7d", "7e", "7f", "80", "81", "82", "83", "84", "85", "86", "87", "88", "89", "8a", "8b", "8c", "8d", "8e", "8f", "90", "91", "92", "93", "94", "95", "96", "97", "98", "99", "9a", "9b", "9c", "9d", "9e", "9f", "a0", "a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9", "aa", "ab", "ac", "ad", "ae", "af", "b0", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "ba", "bb", "bc", "bd", "be", "bf", "c0", "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "ca", "cb", "cc", "cd", "ce", "cf", "d0", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "da", "db", "dc", "dd", "de", "df", "e0", "e1", "e2", "e3", "e4", "e5", "e6", "e7", "e8", "e9", "ea", "eb", "ec", "ed", "ee", "ef", "f0", "f1", "f2", "f3", "f4", "f5", "f6", "f7", "f8", "f9", "fa", "fb", "fc", "fd", "fe", "ff"];
let Da = 1234567;
const Mi = Math.PI / 180, Ii = 180 / Math.PI;
function Mt() {
  const a = Math.random() * 4294967295 | 0, t = Math.random() * 4294967295 | 0, e = Math.random() * 4294967295 | 0, i = Math.random() * 4294967295 | 0;
  return (it[a & 255] + it[a >> 8 & 255] + it[a >> 16 & 255] + it[a >> 24 & 255] + "-" + it[t & 255] + it[t >> 8 & 255] + "-" + it[t >> 16 & 15 | 64] + it[t >> 24 & 255] + "-" + it[e & 63 | 128] + it[e >> 8 & 255] + "-" + it[e >> 16 & 255] + it[e >> 24 & 255] + it[i & 255] + it[i >> 8 & 255] + it[i >> 16 & 255] + it[i >> 24 & 255]).toLowerCase();
}
function rt(a, t, e) {
  return Math.max(t, Math.min(e, a));
}
function jr(a, t) {
  return (a % t + t) % t;
}
function mc(a, t, e, i, n) {
  return i + (a - t) * (n - i) / (e - t);
}
function yc(a, t, e) {
  return a !== t ? (e - a) / (t - a) : 0;
}
function Ei(a, t, e) {
  return (1 - e) * a + e * t;
}
function gc(a, t, e, i) {
  return Ei(a, t, 1 - Math.exp(-e * i));
}
function _c(a, t = 1) {
  return t - Math.abs(jr(a, t * 2) - t);
}
function xc(a, t, e) {
  return a <= t ? 0 : a >= e ? 1 : (a = (a - t) / (e - t), a * a * (3 - 2 * a));
}
function wc(a, t, e) {
  return a <= t ? 0 : a >= e ? 1 : (a = (a - t) / (e - t), a * a * a * (a * (a * 6 - 15) + 10));
}
function bc(a, t) {
  return a + Math.floor(Math.random() * (t - a + 1));
}
function vc(a, t) {
  return a + Math.random() * (t - a);
}
function Ac(a) {
  return a * (0.5 - Math.random());
}
function Mc(a) {
  a !== void 0 && (Da = a);
  let t = Da += 1831565813;
  return t = Math.imul(t ^ t >>> 15, t | 1), t ^= t + Math.imul(t ^ t >>> 7, t | 61), ((t ^ t >>> 14) >>> 0) / 4294967296;
}
function Ec(a) {
  return a * Mi;
}
function Tc(a) {
  return a * Ii;
}
function Sc(a) {
  return (a & a - 1) === 0 && a !== 0;
}
function Ih(a) {
  return Math.pow(2, Math.ceil(Math.log(a) / Math.LN2));
}
function Rc(a) {
  return Math.pow(2, Math.floor(Math.log(a) / Math.LN2));
}
function Pc(a, t, e, i, n) {
  const s = Math.cos, r = Math.sin, o = s(e / 2), h = r(e / 2), l = s((t + i) / 2), c = r((t + i) / 2), u = s((t - i) / 2), d = r((t - i) / 2), f = s((i - t) / 2), p = r((i - t) / 2);
  switch (n) {
    case "XYX":
      a.set(o * c, h * u, h * d, o * l);
      break;
    case "YZY":
      a.set(h * d, o * c, h * u, o * l);
      break;
    case "ZXZ":
      a.set(h * u, h * d, o * c, o * l);
      break;
    case "XZX":
      a.set(o * c, h * p, h * f, o * l);
      break;
    case "YXY":
      a.set(h * f, o * c, h * p, o * l);
      break;
    case "ZYZ":
      a.set(h * p, h * f, o * c, o * l);
      break;
    default:
      console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: " + n);
  }
}
function Ct(a, t) {
  switch (t.constructor) {
    case Float32Array:
      return a;
    case Uint32Array:
      return a / 4294967295;
    case Uint16Array:
      return a / 65535;
    case Uint8Array:
      return a / 255;
    case Int32Array:
      return Math.max(a / 2147483647, -1);
    case Int16Array:
      return Math.max(a / 32767, -1);
    case Int8Array:
      return Math.max(a / 127, -1);
    default:
      throw new Error("Invalid component type.");
  }
}
function H(a, t) {
  switch (t.constructor) {
    case Float32Array:
      return a;
    case Uint32Array:
      return Math.round(a * 4294967295);
    case Uint16Array:
      return Math.round(a * 65535);
    case Uint8Array:
      return Math.round(a * 255);
    case Int32Array:
      return Math.round(a * 2147483647);
    case Int16Array:
      return Math.round(a * 32767);
    case Int8Array:
      return Math.round(a * 127);
    default:
      throw new Error("Invalid component type.");
  }
}
const Hr = {
  DEG2RAD: Mi,
  RAD2DEG: Ii,
  generateUUID: Mt,
  clamp: rt,
  euclideanModulo: jr,
  mapLinear: mc,
  inverseLerp: yc,
  lerp: Ei,
  damp: gc,
  pingpong: _c,
  smoothstep: xc,
  smootherstep: wc,
  randInt: bc,
  randFloat: vc,
  randFloatSpread: Ac,
  seededRandom: Mc,
  degToRad: Ec,
  radToDeg: Tc,
  isPowerOfTwo: Sc,
  ceilPowerOfTwo: Ih,
  floorPowerOfTwo: Rc,
  setQuaternionFromProperEuler: Pc,
  normalize: H,
  denormalize: Ct
};
class G {
  constructor(t = 0, e = 0) {
    G.prototype.isVector2 = !0, this.x = t, this.y = e;
  }
  get width() {
    return this.x;
  }
  set width(t) {
    this.x = t;
  }
  get height() {
    return this.y;
  }
  set height(t) {
    this.y = t;
  }
  set(t, e) {
    return this.x = t, this.y = e, this;
  }
  setScalar(t) {
    return this.x = t, this.y = t, this;
  }
  setX(t) {
    return this.x = t, this;
  }
  setY(t) {
    return this.y = t, this;
  }
  setComponent(t, e) {
    switch (t) {
      case 0:
        this.x = e;
        break;
      case 1:
        this.y = e;
        break;
      default:
        throw new Error("index is out of range: " + t);
    }
    return this;
  }
  getComponent(t) {
    switch (t) {
      case 0:
        return this.x;
      case 1:
        return this.y;
      default:
        throw new Error("index is out of range: " + t);
    }
  }
  clone() {
    return new this.constructor(this.x, this.y);
  }
  copy(t) {
    return this.x = t.x, this.y = t.y, this;
  }
  add(t) {
    return this.x += t.x, this.y += t.y, this;
  }
  addScalar(t) {
    return this.x += t, this.y += t, this;
  }
  addVectors(t, e) {
    return this.x = t.x + e.x, this.y = t.y + e.y, this;
  }
  addScaledVector(t, e) {
    return this.x += t.x * e, this.y += t.y * e, this;
  }
  sub(t) {
    return this.x -= t.x, this.y -= t.y, this;
  }
  subScalar(t) {
    return this.x -= t, this.y -= t, this;
  }
  subVectors(t, e) {
    return this.x = t.x - e.x, this.y = t.y - e.y, this;
  }
  multiply(t) {
    return this.x *= t.x, this.y *= t.y, this;
  }
  multiplyScalar(t) {
    return this.x *= t, this.y *= t, this;
  }
  divide(t) {
    return this.x /= t.x, this.y /= t.y, this;
  }
  divideScalar(t) {
    return this.multiplyScalar(1 / t);
  }
  applyMatrix3(t) {
    const e = this.x, i = this.y, n = t.elements;
    return this.x = n[0] * e + n[3] * i + n[6], this.y = n[1] * e + n[4] * i + n[7], this;
  }
  min(t) {
    return this.x = Math.min(this.x, t.x), this.y = Math.min(this.y, t.y), this;
  }
  max(t) {
    return this.x = Math.max(this.x, t.x), this.y = Math.max(this.y, t.y), this;
  }
  clamp(t, e) {
    return this.x = Math.max(t.x, Math.min(e.x, this.x)), this.y = Math.max(t.y, Math.min(e.y, this.y)), this;
  }
  clampScalar(t, e) {
    return this.x = Math.max(t, Math.min(e, this.x)), this.y = Math.max(t, Math.min(e, this.y)), this;
  }
  clampLength(t, e) {
    const i = this.length();
    return this.divideScalar(i || 1).multiplyScalar(Math.max(t, Math.min(e, i)));
  }
  floor() {
    return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this;
  }
  ceil() {
    return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this;
  }
  round() {
    return this.x = Math.round(this.x), this.y = Math.round(this.y), this;
  }
  roundToZero() {
    return this.x = Math.trunc(this.x), this.y = Math.trunc(this.y), this;
  }
  negate() {
    return this.x = -this.x, this.y = -this.y, this;
  }
  dot(t) {
    return this.x * t.x + this.y * t.y;
  }
  cross(t) {
    return this.x * t.y - this.y * t.x;
  }
  lengthSq() {
    return this.x * this.x + this.y * this.y;
  }
  length() {
    return Math.sqrt(this.x * this.x + this.y * this.y);
  }
  manhattanLength() {
    return Math.abs(this.x) + Math.abs(this.y);
  }
  normalize() {
    return this.divideScalar(this.length() || 1);
  }
  angle() {
    return Math.atan2(-this.y, -this.x) + Math.PI;
  }
  angleTo(t) {
    const e = Math.sqrt(this.lengthSq() * t.lengthSq());
    if (e === 0)
      return Math.PI / 2;
    const i = this.dot(t) / e;
    return Math.acos(rt(i, -1, 1));
  }
  distanceTo(t) {
    return Math.sqrt(this.distanceToSquared(t));
  }
  distanceToSquared(t) {
    const e = this.x - t.x, i = this.y - t.y;
    return e * e + i * i;
  }
  manhattanDistanceTo(t) {
    return Math.abs(this.x - t.x) + Math.abs(this.y - t.y);
  }
  setLength(t) {
    return this.normalize().multiplyScalar(t);
  }
  lerp(t, e) {
    return this.x += (t.x - this.x) * e, this.y += (t.y - this.y) * e, this;
  }
  lerpVectors(t, e, i) {
    return this.x = t.x + (e.x - t.x) * i, this.y = t.y + (e.y - t.y) * i, this;
  }
  equals(t) {
    return t.x === this.x && t.y === this.y;
  }
  fromArray(t, e = 0) {
    return this.x = t[e], this.y = t[e + 1], this;
  }
  toArray(t = [], e = 0) {
    return t[e] = this.x, t[e + 1] = this.y, t;
  }
  fromBufferAttribute(t, e) {
    return this.x = t.getX(e), this.y = t.getY(e), this;
  }
  rotateAround(t, e) {
    const i = Math.cos(e), n = Math.sin(e), s = this.x - t.x, r = this.y - t.y;
    return this.x = s * i - r * n + t.x, this.y = s * n + r * i + t.y, this;
  }
  random() {
    return this.x = Math.random(), this.y = Math.random(), this;
  }
  *[Symbol.iterator]() {
    yield this.x, yield this.y;
  }
}
class Gt {
  constructor(t, e, i, n, s, r, o, h, l) {
    Gt.prototype.isMatrix3 = !0, this.elements = [
      1,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      1
    ], t !== void 0 && this.set(t, e, i, n, s, r, o, h, l);
  }
  set(t, e, i, n, s, r, o, h, l) {
    const c = this.elements;
    return c[0] = t, c[1] = n, c[2] = o, c[3] = e, c[4] = s, c[5] = h, c[6] = i, c[7] = r, c[8] = l, this;
  }
  identity() {
    return this.set(
      1,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      1
    ), this;
  }
  copy(t) {
    const e = this.elements, i = t.elements;
    return e[0] = i[0], e[1] = i[1], e[2] = i[2], e[3] = i[3], e[4] = i[4], e[5] = i[5], e[6] = i[6], e[7] = i[7], e[8] = i[8], this;
  }
  extractBasis(t, e, i) {
    return t.setFromMatrix3Column(this, 0), e.setFromMatrix3Column(this, 1), i.setFromMatrix3Column(this, 2), this;
  }
  setFromMatrix4(t) {
    const e = t.elements;
    return this.set(
      e[0],
      e[4],
      e[8],
      e[1],
      e[5],
      e[9],
      e[2],
      e[6],
      e[10]
    ), this;
  }
  multiply(t) {
    return this.multiplyMatrices(this, t);
  }
  premultiply(t) {
    return this.multiplyMatrices(t, this);
  }
  multiplyMatrices(t, e) {
    const i = t.elements, n = e.elements, s = this.elements, r = i[0], o = i[3], h = i[6], l = i[1], c = i[4], u = i[7], d = i[2], f = i[5], p = i[8], y = n[0], m = n[3], _ = n[6], b = n[1], A = n[4], g = n[7], x = n[2], v = n[5], M = n[8];
    return s[0] = r * y + o * b + h * x, s[3] = r * m + o * A + h * v, s[6] = r * _ + o * g + h * M, s[1] = l * y + c * b + u * x, s[4] = l * m + c * A + u * v, s[7] = l * _ + c * g + u * M, s[2] = d * y + f * b + p * x, s[5] = d * m + f * A + p * v, s[8] = d * _ + f * g + p * M, this;
  }
  multiplyScalar(t) {
    const e = this.elements;
    return e[0] *= t, e[3] *= t, e[6] *= t, e[1] *= t, e[4] *= t, e[7] *= t, e[2] *= t, e[5] *= t, e[8] *= t, this;
  }
  determinant() {
    const t = this.elements, e = t[0], i = t[1], n = t[2], s = t[3], r = t[4], o = t[5], h = t[6], l = t[7], c = t[8];
    return e * r * c - e * o * l - i * s * c + i * o * h + n * s * l - n * r * h;
  }
  invert() {
    const t = this.elements, e = t[0], i = t[1], n = t[2], s = t[3], r = t[4], o = t[5], h = t[6], l = t[7], c = t[8], u = c * r - o * l, d = o * h - c * s, f = l * s - r * h, p = e * u + i * d + n * f;
    if (p === 0)
      return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0);
    const y = 1 / p;
    return t[0] = u * y, t[1] = (n * l - c * i) * y, t[2] = (o * i - n * r) * y, t[3] = d * y, t[4] = (c * e - n * h) * y, t[5] = (n * s - o * e) * y, t[6] = f * y, t[7] = (i * h - l * e) * y, t[8] = (r * e - i * s) * y, this;
  }
  transpose() {
    let t;
    const e = this.elements;
    return t = e[1], e[1] = e[3], e[3] = t, t = e[2], e[2] = e[6], e[6] = t, t = e[5], e[5] = e[7], e[7] = t, this;
  }
  getNormalMatrix(t) {
    return this.setFromMatrix4(t).invert().transpose();
  }
  transposeIntoArray(t) {
    const e = this.elements;
    return t[0] = e[0], t[1] = e[3], t[2] = e[6], t[3] = e[1], t[4] = e[4], t[5] = e[7], t[6] = e[2], t[7] = e[5], t[8] = e[8], this;
  }
  setUvTransform(t, e, i, n, s, r, o) {
    const h = Math.cos(s), l = Math.sin(s);
    return this.set(
      i * h,
      i * l,
      -i * (h * r + l * o) + r + t,
      -n * l,
      n * h,
      -n * (-l * r + h * o) + o + e,
      0,
      0,
      1
    ), this;
  }
  //
  scale(t, e) {
    return this.premultiply(ss.makeScale(t, e)), this;
  }
  rotate(t) {
    return this.premultiply(ss.makeRotation(-t)), this;
  }
  translate(t, e) {
    return this.premultiply(ss.makeTranslation(t, e)), this;
  }
  // for 2D Transforms
  makeTranslation(t, e) {
    return t.isVector2 ? this.set(
      1,
      0,
      t.x,
      0,
      1,
      t.y,
      0,
      0,
      1
    ) : this.set(
      1,
      0,
      t,
      0,
      1,
      e,
      0,
      0,
      1
    ), this;
  }
  makeRotation(t) {
    const e = Math.cos(t), i = Math.sin(t);
    return this.set(
      e,
      -i,
      0,
      i,
      e,
      0,
      0,
      0,
      1
    ), this;
  }
  makeScale(t, e) {
    return this.set(
      t,
      0,
      0,
      0,
      e,
      0,
      0,
      0,
      1
    ), this;
  }
  //
  equals(t) {
    const e = this.elements, i = t.elements;
    for (let n = 0; n < 9; n++)
      if (e[n] !== i[n])
        return !1;
    return !0;
  }
  fromArray(t, e = 0) {
    for (let i = 0; i < 9; i++)
      this.elements[i] = t[i + e];
    return this;
  }
  toArray(t = [], e = 0) {
    const i = this.elements;
    return t[e] = i[0], t[e + 1] = i[1], t[e + 2] = i[2], t[e + 3] = i[3], t[e + 4] = i[4], t[e + 5] = i[5], t[e + 6] = i[6], t[e + 7] = i[7], t[e + 8] = i[8], t;
  }
  clone() {
    return new this.constructor().fromArray(this.elements);
  }
}
const ss = /* @__PURE__ */ new Gt();
function Ic(a) {
  for (let t = a.length - 1; t >= 0; --t)
    if (a[t] >= 65535)
      return !0;
  return !1;
}
function or(a) {
  return document.createElementNS("http://www.w3.org/1999/xhtml", a);
}
const Ba = {};
function rs(a) {
  a in Ba || (Ba[a] = !0, console.warn(a));
}
const Fa = /* @__PURE__ */ new Gt().set(
  0.8224621,
  0.177538,
  0,
  0.0331941,
  0.9668058,
  0,
  0.0170827,
  0.0723974,
  0.9105199
), ka = /* @__PURE__ */ new Gt().set(
  1.2249401,
  -0.2249404,
  0,
  -0.0420569,
  1.0420571,
  0,
  -0.0196376,
  -0.0786361,
  1.0982735
), Xi = {
  [St]: {
    transfer: sr,
    primaries: Na,
    toReference: (a) => a,
    fromReference: (a) => a
  },
  [st]: {
    transfer: Oa,
    primaries: Na,
    toReference: (a) => a.convertSRGBToLinear(),
    fromReference: (a) => a.convertLinearToSRGB()
  },
  [Ph]: {
    transfer: sr,
    primaries: La,
    toReference: (a) => a.applyMatrix3(ka),
    fromReference: (a) => a.applyMatrix3(Fa)
  },
  [fc]: {
    transfer: Oa,
    primaries: La,
    toReference: (a) => a.convertSRGBToLinear().applyMatrix3(ka),
    fromReference: (a) => a.applyMatrix3(Fa).convertLinearToSRGB()
  }
}, Cc = /* @__PURE__ */ new Set([St, Ph]), mt = {
  enabled: !0,
  _workingColorSpace: St,
  get legacyMode() {
    return console.warn("THREE.ColorManagement: .legacyMode=false renamed to .enabled=true in r150."), !this.enabled;
  },
  set legacyMode(a) {
    console.warn("THREE.ColorManagement: .legacyMode=false renamed to .enabled=true in r150."), this.enabled = !a;
  },
  get workingColorSpace() {
    return this._workingColorSpace;
  },
  set workingColorSpace(a) {
    if (!Cc.has(a))
      throw new Error(`Unsupported working color space, "${a}".`);
    this._workingColorSpace = a;
  },
  convert: function(a, t, e) {
    if (this.enabled === !1 || t === e || !t || !e)
      return a;
    const i = Xi[t].toReference, n = Xi[e].fromReference;
    return n(i(a));
  },
  fromWorkingColorSpace: function(a, t) {
    return this.convert(a, this._workingColorSpace, t);
  },
  toWorkingColorSpace: function(a, t) {
    return this.convert(a, t, this._workingColorSpace);
  },
  getPrimaries: function(a) {
    return Xi[a].primaries;
  },
  getTransfer: function(a) {
    return a === In ? sr : Xi[a].transfer;
  }
};
function Je(a) {
  return a < 0.04045 ? a * 0.0773993808 : Math.pow(a * 0.9478672986 + 0.0521327014, 2.4);
}
function as(a) {
  return a < 31308e-7 ? a * 12.92 : 1.055 * Math.pow(a, 0.41666) - 0.055;
}
let Ie;
class Oc {
  static getDataURL(t) {
    if (/^data:/i.test(t.src) || typeof HTMLCanvasElement > "u")
      return t.src;
    let e;
    if (t instanceof HTMLCanvasElement)
      e = t;
    else {
      Ie === void 0 && (Ie = or("canvas")), Ie.width = t.width, Ie.height = t.height;
      const i = Ie.getContext("2d");
      t instanceof ImageData ? i.putImageData(t, 0, 0) : i.drawImage(t, 0, 0, t.width, t.height), e = Ie;
    }
    return e.width > 2048 || e.height > 2048 ? (console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons", t), e.toDataURL("image/jpeg", 0.6)) : e.toDataURL("image/png");
  }
  static sRGBToLinear(t) {
    if (typeof HTMLImageElement < "u" && t instanceof HTMLImageElement || typeof HTMLCanvasElement < "u" && t instanceof HTMLCanvasElement || typeof ImageBitmap < "u" && t instanceof ImageBitmap) {
      const e = or("canvas");
      e.width = t.width, e.height = t.height;
      const i = e.getContext("2d");
      i.drawImage(t, 0, 0, t.width, t.height);
      const n = i.getImageData(0, 0, t.width, t.height), s = n.data;
      for (let r = 0; r < s.length; r++)
        s[r] = Je(s[r] / 255) * 255;
      return i.putImageData(n, 0, 0), e;
    } else if (t.data) {
      const e = t.data.slice(0);
      for (let i = 0; i < e.length; i++)
        e instanceof Uint8Array || e instanceof Uint8ClampedArray ? e[i] = Math.floor(Je(e[i] / 255) * 255) : e[i] = Je(e[i]);
      return {
        data: e,
        width: t.width,
        height: t.height
      };
    } else
      return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."), t;
  }
}
let Nc = 0;
class Lc {
  constructor(t = null) {
    this.isSource = !0, Object.defineProperty(this, "id", { value: Nc++ }), this.uuid = Mt(), this.data = t, this.version = 0;
  }
  set needsUpdate(t) {
    t === !0 && this.version++;
  }
  toJSON(t) {
    const e = t === void 0 || typeof t == "string";
    if (!e && t.images[this.uuid] !== void 0)
      return t.images[this.uuid];
    const i = {
      uuid: this.uuid,
      url: ""
    }, n = this.data;
    if (n !== null) {
      let s;
      if (Array.isArray(n)) {
        s = [];
        for (let r = 0, o = n.length; r < o; r++)
          n[r].isDataTexture ? s.push(os(n[r].image)) : s.push(os(n[r]));
      } else
        s = os(n);
      i.url = s;
    }
    return e || (t.images[this.uuid] = i), i;
  }
}
function os(a) {
  return typeof HTMLImageElement < "u" && a instanceof HTMLImageElement || typeof HTMLCanvasElement < "u" && a instanceof HTMLCanvasElement || typeof ImageBitmap < "u" && a instanceof ImageBitmap ? Oc.getDataURL(a) : a.data ? {
    data: Array.from(a.data),
    width: a.width,
    height: a.height,
    type: a.data.constructor.name
  } : (console.warn("THREE.Texture: Unable to serialize Texture."), {});
}
let Dc = 0;
class Et extends Ci {
  constructor(t = Et.DEFAULT_IMAGE, e = Et.DEFAULT_MAPPING, i = vi, n = vi, s = kr, r = zr, o = Th, h = ac, l = Et.DEFAULT_ANISOTROPY, c = In) {
    super(), this.isTexture = !0, Object.defineProperty(this, "id", { value: Dc++ }), this.uuid = Mt(), this.name = "", this.source = new Lc(t), this.mipmaps = [], this.mapping = e, this.channel = 0, this.wrapS = i, this.wrapT = n, this.magFilter = s, this.minFilter = r, this.anisotropy = l, this.format = o, this.internalFormat = null, this.type = h, this.offset = new G(0, 0), this.repeat = new G(1, 1), this.center = new G(0, 0), this.rotation = 0, this.matrixAutoUpdate = !0, this.matrix = new Gt(), this.generateMipmaps = !0, this.premultiplyAlpha = !1, this.flipY = !0, this.unpackAlignment = 4, typeof c == "string" ? this.colorSpace = c : (rs("THREE.Texture: Property .encoding has been replaced by .colorSpace."), this.colorSpace = c === is ? st : In), this.userData = {}, this.version = 0, this.onUpdate = null, this.isRenderTargetTexture = !1, this.needsPMREMUpdate = !1;
  }
  get image() {
    return this.source.data;
  }
  set image(t = null) {
    this.source.data = t;
  }
  updateMatrix() {
    this.matrix.setUvTransform(this.offset.x, this.offset.y, this.repeat.x, this.repeat.y, this.rotation, this.center.x, this.center.y);
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    return this.name = t.name, this.source = t.source, this.mipmaps = t.mipmaps.slice(0), this.mapping = t.mapping, this.channel = t.channel, this.wrapS = t.wrapS, this.wrapT = t.wrapT, this.magFilter = t.magFilter, this.minFilter = t.minFilter, this.anisotropy = t.anisotropy, this.format = t.format, this.internalFormat = t.internalFormat, this.type = t.type, this.offset.copy(t.offset), this.repeat.copy(t.repeat), this.center.copy(t.center), this.rotation = t.rotation, this.matrixAutoUpdate = t.matrixAutoUpdate, this.matrix.copy(t.matrix), this.generateMipmaps = t.generateMipmaps, this.premultiplyAlpha = t.premultiplyAlpha, this.flipY = t.flipY, this.unpackAlignment = t.unpackAlignment, this.colorSpace = t.colorSpace, this.userData = JSON.parse(JSON.stringify(t.userData)), this.needsUpdate = !0, this;
  }
  toJSON(t) {
    const e = t === void 0 || typeof t == "string";
    if (!e && t.textures[this.uuid] !== void 0)
      return t.textures[this.uuid];
    const i = {
      metadata: {
        version: 4.6,
        type: "Texture",
        generator: "Texture.toJSON"
      },
      uuid: this.uuid,
      name: this.name,
      image: this.source.toJSON(t).uuid,
      mapping: this.mapping,
      channel: this.channel,
      repeat: [this.repeat.x, this.repeat.y],
      offset: [this.offset.x, this.offset.y],
      center: [this.center.x, this.center.y],
      rotation: this.rotation,
      wrap: [this.wrapS, this.wrapT],
      format: this.format,
      internalFormat: this.internalFormat,
      type: this.type,
      colorSpace: this.colorSpace,
      minFilter: this.minFilter,
      magFilter: this.magFilter,
      anisotropy: this.anisotropy,
      flipY: this.flipY,
      generateMipmaps: this.generateMipmaps,
      premultiplyAlpha: this.premultiplyAlpha,
      unpackAlignment: this.unpackAlignment
    };
    return Object.keys(this.userData).length > 0 && (i.userData = this.userData), e || (t.textures[this.uuid] = i), i;
  }
  dispose() {
    this.dispatchEvent({ type: "dispose" });
  }
  transformUv(t) {
    if (this.mapping !== Mh)
      return t;
    if (t.applyMatrix3(this.matrix), t.x < 0 || t.x > 1)
      switch (this.wrapS) {
        case Ri:
          t.x = t.x - Math.floor(t.x);
          break;
        case vi:
          t.x = t.x < 0 ? 0 : 1;
          break;
        case er:
          Math.abs(Math.floor(t.x) % 2) === 1 ? t.x = Math.ceil(t.x) - t.x : t.x = t.x - Math.floor(t.x);
          break;
      }
    if (t.y < 0 || t.y > 1)
      switch (this.wrapT) {
        case Ri:
          t.y = t.y - Math.floor(t.y);
          break;
        case vi:
          t.y = t.y < 0 ? 0 : 1;
          break;
        case er:
          Math.abs(Math.floor(t.y) % 2) === 1 ? t.y = Math.ceil(t.y) - t.y : t.y = t.y - Math.floor(t.y);
          break;
      }
    return this.flipY && (t.y = 1 - t.y), t;
  }
  set needsUpdate(t) {
    t === !0 && (this.version++, this.source.needsUpdate = !0);
  }
  get encoding() {
    return rs("THREE.Texture: Property .encoding has been replaced by .colorSpace."), this.colorSpace === st ? is : uc;
  }
  set encoding(t) {
    rs("THREE.Texture: Property .encoding has been replaced by .colorSpace."), this.colorSpace = t === is ? st : In;
  }
}
Et.DEFAULT_IMAGE = null;
Et.DEFAULT_MAPPING = Mh;
Et.DEFAULT_ANISOTROPY = 1;
class _t {
  constructor(t = 0, e = 0, i = 0, n = 1) {
    _t.prototype.isVector4 = !0, this.x = t, this.y = e, this.z = i, this.w = n;
  }
  get width() {
    return this.z;
  }
  set width(t) {
    this.z = t;
  }
  get height() {
    return this.w;
  }
  set height(t) {
    this.w = t;
  }
  set(t, e, i, n) {
    return this.x = t, this.y = e, this.z = i, this.w = n, this;
  }
  setScalar(t) {
    return this.x = t, this.y = t, this.z = t, this.w = t, this;
  }
  setX(t) {
    return this.x = t, this;
  }
  setY(t) {
    return this.y = t, this;
  }
  setZ(t) {
    return this.z = t, this;
  }
  setW(t) {
    return this.w = t, this;
  }
  setComponent(t, e) {
    switch (t) {
      case 0:
        this.x = e;
        break;
      case 1:
        this.y = e;
        break;
      case 2:
        this.z = e;
        break;
      case 3:
        this.w = e;
        break;
      default:
        throw new Error("index is out of range: " + t);
    }
    return this;
  }
  getComponent(t) {
    switch (t) {
      case 0:
        return this.x;
      case 1:
        return this.y;
      case 2:
        return this.z;
      case 3:
        return this.w;
      default:
        throw new Error("index is out of range: " + t);
    }
  }
  clone() {
    return new this.constructor(this.x, this.y, this.z, this.w);
  }
  copy(t) {
    return this.x = t.x, this.y = t.y, this.z = t.z, this.w = t.w !== void 0 ? t.w : 1, this;
  }
  add(t) {
    return this.x += t.x, this.y += t.y, this.z += t.z, this.w += t.w, this;
  }
  addScalar(t) {
    return this.x += t, this.y += t, this.z += t, this.w += t, this;
  }
  addVectors(t, e) {
    return this.x = t.x + e.x, this.y = t.y + e.y, this.z = t.z + e.z, this.w = t.w + e.w, this;
  }
  addScaledVector(t, e) {
    return this.x += t.x * e, this.y += t.y * e, this.z += t.z * e, this.w += t.w * e, this;
  }
  sub(t) {
    return this.x -= t.x, this.y -= t.y, this.z -= t.z, this.w -= t.w, this;
  }
  subScalar(t) {
    return this.x -= t, this.y -= t, this.z -= t, this.w -= t, this;
  }
  subVectors(t, e) {
    return this.x = t.x - e.x, this.y = t.y - e.y, this.z = t.z - e.z, this.w = t.w - e.w, this;
  }
  multiply(t) {
    return this.x *= t.x, this.y *= t.y, this.z *= t.z, this.w *= t.w, this;
  }
  multiplyScalar(t) {
    return this.x *= t, this.y *= t, this.z *= t, this.w *= t, this;
  }
  applyMatrix4(t) {
    const e = this.x, i = this.y, n = this.z, s = this.w, r = t.elements;
    return this.x = r[0] * e + r[4] * i + r[8] * n + r[12] * s, this.y = r[1] * e + r[5] * i + r[9] * n + r[13] * s, this.z = r[2] * e + r[6] * i + r[10] * n + r[14] * s, this.w = r[3] * e + r[7] * i + r[11] * n + r[15] * s, this;
  }
  divideScalar(t) {
    return this.multiplyScalar(1 / t);
  }
  setAxisAngleFromQuaternion(t) {
    this.w = 2 * Math.acos(t.w);
    const e = Math.sqrt(1 - t.w * t.w);
    return e < 1e-4 ? (this.x = 1, this.y = 0, this.z = 0) : (this.x = t.x / e, this.y = t.y / e, this.z = t.z / e), this;
  }
  setAxisAngleFromRotationMatrix(t) {
    let e, i, n, s;
    const h = t.elements, l = h[0], c = h[4], u = h[8], d = h[1], f = h[5], p = h[9], y = h[2], m = h[6], _ = h[10];
    if (Math.abs(c - d) < 0.01 && Math.abs(u - y) < 0.01 && Math.abs(p - m) < 0.01) {
      if (Math.abs(c + d) < 0.1 && Math.abs(u + y) < 0.1 && Math.abs(p + m) < 0.1 && Math.abs(l + f + _ - 3) < 0.1)
        return this.set(1, 0, 0, 0), this;
      e = Math.PI;
      const A = (l + 1) / 2, g = (f + 1) / 2, x = (_ + 1) / 2, v = (c + d) / 4, M = (u + y) / 4, T = (p + m) / 4;
      return A > g && A > x ? A < 0.01 ? (i = 0, n = 0.707106781, s = 0.707106781) : (i = Math.sqrt(A), n = v / i, s = M / i) : g > x ? g < 0.01 ? (i = 0.707106781, n = 0, s = 0.707106781) : (n = Math.sqrt(g), i = v / n, s = T / n) : x < 0.01 ? (i = 0.707106781, n = 0.707106781, s = 0) : (s = Math.sqrt(x), i = M / s, n = T / s), this.set(i, n, s, e), this;
    }
    let b = Math.sqrt((m - p) * (m - p) + (u - y) * (u - y) + (d - c) * (d - c));
    return Math.abs(b) < 1e-3 && (b = 1), this.x = (m - p) / b, this.y = (u - y) / b, this.z = (d - c) / b, this.w = Math.acos((l + f + _ - 1) / 2), this;
  }
  min(t) {
    return this.x = Math.min(this.x, t.x), this.y = Math.min(this.y, t.y), this.z = Math.min(this.z, t.z), this.w = Math.min(this.w, t.w), this;
  }
  max(t) {
    return this.x = Math.max(this.x, t.x), this.y = Math.max(this.y, t.y), this.z = Math.max(this.z, t.z), this.w = Math.max(this.w, t.w), this;
  }
  clamp(t, e) {
    return this.x = Math.max(t.x, Math.min(e.x, this.x)), this.y = Math.max(t.y, Math.min(e.y, this.y)), this.z = Math.max(t.z, Math.min(e.z, this.z)), this.w = Math.max(t.w, Math.min(e.w, this.w)), this;
  }
  clampScalar(t, e) {
    return this.x = Math.max(t, Math.min(e, this.x)), this.y = Math.max(t, Math.min(e, this.y)), this.z = Math.max(t, Math.min(e, this.z)), this.w = Math.max(t, Math.min(e, this.w)), this;
  }
  clampLength(t, e) {
    const i = this.length();
    return this.divideScalar(i || 1).multiplyScalar(Math.max(t, Math.min(e, i)));
  }
  floor() {
    return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this.z = Math.floor(this.z), this.w = Math.floor(this.w), this;
  }
  ceil() {
    return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this.z = Math.ceil(this.z), this.w = Math.ceil(this.w), this;
  }
  round() {
    return this.x = Math.round(this.x), this.y = Math.round(this.y), this.z = Math.round(this.z), this.w = Math.round(this.w), this;
  }
  roundToZero() {
    return this.x = Math.trunc(this.x), this.y = Math.trunc(this.y), this.z = Math.trunc(this.z), this.w = Math.trunc(this.w), this;
  }
  negate() {
    return this.x = -this.x, this.y = -this.y, this.z = -this.z, this.w = -this.w, this;
  }
  dot(t) {
    return this.x * t.x + this.y * t.y + this.z * t.z + this.w * t.w;
  }
  lengthSq() {
    return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
  }
  length() {
    return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
  }
  manhattanLength() {
    return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z) + Math.abs(this.w);
  }
  normalize() {
    return this.divideScalar(this.length() || 1);
  }
  setLength(t) {
    return this.normalize().multiplyScalar(t);
  }
  lerp(t, e) {
    return this.x += (t.x - this.x) * e, this.y += (t.y - this.y) * e, this.z += (t.z - this.z) * e, this.w += (t.w - this.w) * e, this;
  }
  lerpVectors(t, e, i) {
    return this.x = t.x + (e.x - t.x) * i, this.y = t.y + (e.y - t.y) * i, this.z = t.z + (e.z - t.z) * i, this.w = t.w + (e.w - t.w) * i, this;
  }
  equals(t) {
    return t.x === this.x && t.y === this.y && t.z === this.z && t.w === this.w;
  }
  fromArray(t, e = 0) {
    return this.x = t[e], this.y = t[e + 1], this.z = t[e + 2], this.w = t[e + 3], this;
  }
  toArray(t = [], e = 0) {
    return t[e] = this.x, t[e + 1] = this.y, t[e + 2] = this.z, t[e + 3] = this.w, t;
  }
  fromBufferAttribute(t, e) {
    return this.x = t.getX(e), this.y = t.getY(e), this.z = t.getZ(e), this.w = t.getW(e), this;
  }
  random() {
    return this.x = Math.random(), this.y = Math.random(), this.z = Math.random(), this.w = Math.random(), this;
  }
  *[Symbol.iterator]() {
    yield this.x, yield this.y, yield this.z, yield this.w;
  }
}
class Q {
  constructor(t = 0, e = 0, i = 0, n = 1) {
    this.isQuaternion = !0, this._x = t, this._y = e, this._z = i, this._w = n;
  }
  static slerpFlat(t, e, i, n, s, r, o) {
    let h = i[n + 0], l = i[n + 1], c = i[n + 2], u = i[n + 3];
    const d = s[r + 0], f = s[r + 1], p = s[r + 2], y = s[r + 3];
    if (o === 0) {
      t[e + 0] = h, t[e + 1] = l, t[e + 2] = c, t[e + 3] = u;
      return;
    }
    if (o === 1) {
      t[e + 0] = d, t[e + 1] = f, t[e + 2] = p, t[e + 3] = y;
      return;
    }
    if (u !== y || h !== d || l !== f || c !== p) {
      let m = 1 - o;
      const _ = h * d + l * f + c * p + u * y, b = _ >= 0 ? 1 : -1, A = 1 - _ * _;
      if (A > Number.EPSILON) {
        const x = Math.sqrt(A), v = Math.atan2(x, _ * b);
        m = Math.sin(m * v) / x, o = Math.sin(o * v) / x;
      }
      const g = o * b;
      if (h = h * m + d * g, l = l * m + f * g, c = c * m + p * g, u = u * m + y * g, m === 1 - o) {
        const x = 1 / Math.sqrt(h * h + l * l + c * c + u * u);
        h *= x, l *= x, c *= x, u *= x;
      }
    }
    t[e] = h, t[e + 1] = l, t[e + 2] = c, t[e + 3] = u;
  }
  static multiplyQuaternionsFlat(t, e, i, n, s, r) {
    const o = i[n], h = i[n + 1], l = i[n + 2], c = i[n + 3], u = s[r], d = s[r + 1], f = s[r + 2], p = s[r + 3];
    return t[e] = o * p + c * u + h * f - l * d, t[e + 1] = h * p + c * d + l * u - o * f, t[e + 2] = l * p + c * f + o * d - h * u, t[e + 3] = c * p - o * u - h * d - l * f, t;
  }
  get x() {
    return this._x;
  }
  set x(t) {
    this._x = t, this._onChangeCallback();
  }
  get y() {
    return this._y;
  }
  set y(t) {
    this._y = t, this._onChangeCallback();
  }
  get z() {
    return this._z;
  }
  set z(t) {
    this._z = t, this._onChangeCallback();
  }
  get w() {
    return this._w;
  }
  set w(t) {
    this._w = t, this._onChangeCallback();
  }
  set(t, e, i, n) {
    return this._x = t, this._y = e, this._z = i, this._w = n, this._onChangeCallback(), this;
  }
  clone() {
    return new this.constructor(this._x, this._y, this._z, this._w);
  }
  copy(t) {
    return this._x = t.x, this._y = t.y, this._z = t.z, this._w = t.w, this._onChangeCallback(), this;
  }
  setFromEuler(t, e) {
    const i = t._x, n = t._y, s = t._z, r = t._order, o = Math.cos, h = Math.sin, l = o(i / 2), c = o(n / 2), u = o(s / 2), d = h(i / 2), f = h(n / 2), p = h(s / 2);
    switch (r) {
      case "XYZ":
        this._x = d * c * u + l * f * p, this._y = l * f * u - d * c * p, this._z = l * c * p + d * f * u, this._w = l * c * u - d * f * p;
        break;
      case "YXZ":
        this._x = d * c * u + l * f * p, this._y = l * f * u - d * c * p, this._z = l * c * p - d * f * u, this._w = l * c * u + d * f * p;
        break;
      case "ZXY":
        this._x = d * c * u - l * f * p, this._y = l * f * u + d * c * p, this._z = l * c * p + d * f * u, this._w = l * c * u - d * f * p;
        break;
      case "ZYX":
        this._x = d * c * u - l * f * p, this._y = l * f * u + d * c * p, this._z = l * c * p - d * f * u, this._w = l * c * u + d * f * p;
        break;
      case "YZX":
        this._x = d * c * u + l * f * p, this._y = l * f * u + d * c * p, this._z = l * c * p - d * f * u, this._w = l * c * u - d * f * p;
        break;
      case "XZY":
        this._x = d * c * u - l * f * p, this._y = l * f * u - d * c * p, this._z = l * c * p + d * f * u, this._w = l * c * u + d * f * p;
        break;
      default:
        console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: " + r);
    }
    return e !== !1 && this._onChangeCallback(), this;
  }
  setFromAxisAngle(t, e) {
    const i = e / 2, n = Math.sin(i);
    return this._x = t.x * n, this._y = t.y * n, this._z = t.z * n, this._w = Math.cos(i), this._onChangeCallback(), this;
  }
  setFromRotationMatrix(t) {
    const e = t.elements, i = e[0], n = e[4], s = e[8], r = e[1], o = e[5], h = e[9], l = e[2], c = e[6], u = e[10], d = i + o + u;
    if (d > 0) {
      const f = 0.5 / Math.sqrt(d + 1);
      this._w = 0.25 / f, this._x = (c - h) * f, this._y = (s - l) * f, this._z = (r - n) * f;
    } else if (i > o && i > u) {
      const f = 2 * Math.sqrt(1 + i - o - u);
      this._w = (c - h) / f, this._x = 0.25 * f, this._y = (n + r) / f, this._z = (s + l) / f;
    } else if (o > u) {
      const f = 2 * Math.sqrt(1 + o - i - u);
      this._w = (s - l) / f, this._x = (n + r) / f, this._y = 0.25 * f, this._z = (h + c) / f;
    } else {
      const f = 2 * Math.sqrt(1 + u - i - o);
      this._w = (r - n) / f, this._x = (s + l) / f, this._y = (h + c) / f, this._z = 0.25 * f;
    }
    return this._onChangeCallback(), this;
  }
  setFromUnitVectors(t, e) {
    let i = t.dot(e) + 1;
    return i < Number.EPSILON ? (i = 0, Math.abs(t.x) > Math.abs(t.z) ? (this._x = -t.y, this._y = t.x, this._z = 0, this._w = i) : (this._x = 0, this._y = -t.z, this._z = t.y, this._w = i)) : (this._x = t.y * e.z - t.z * e.y, this._y = t.z * e.x - t.x * e.z, this._z = t.x * e.y - t.y * e.x, this._w = i), this.normalize();
  }
  angleTo(t) {
    return 2 * Math.acos(Math.abs(rt(this.dot(t), -1, 1)));
  }
  rotateTowards(t, e) {
    const i = this.angleTo(t);
    if (i === 0)
      return this;
    const n = Math.min(1, e / i);
    return this.slerp(t, n), this;
  }
  identity() {
    return this.set(0, 0, 0, 1);
  }
  invert() {
    return this.conjugate();
  }
  conjugate() {
    return this._x *= -1, this._y *= -1, this._z *= -1, this._onChangeCallback(), this;
  }
  dot(t) {
    return this._x * t._x + this._y * t._y + this._z * t._z + this._w * t._w;
  }
  lengthSq() {
    return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w;
  }
  length() {
    return Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w);
  }
  normalize() {
    let t = this.length();
    return t === 0 ? (this._x = 0, this._y = 0, this._z = 0, this._w = 1) : (t = 1 / t, this._x = this._x * t, this._y = this._y * t, this._z = this._z * t, this._w = this._w * t), this._onChangeCallback(), this;
  }
  multiply(t) {
    return this.multiplyQuaternions(this, t);
  }
  premultiply(t) {
    return this.multiplyQuaternions(t, this);
  }
  multiplyQuaternions(t, e) {
    const i = t._x, n = t._y, s = t._z, r = t._w, o = e._x, h = e._y, l = e._z, c = e._w;
    return this._x = i * c + r * o + n * l - s * h, this._y = n * c + r * h + s * o - i * l, this._z = s * c + r * l + i * h - n * o, this._w = r * c - i * o - n * h - s * l, this._onChangeCallback(), this;
  }
  slerp(t, e) {
    if (e === 0)
      return this;
    if (e === 1)
      return this.copy(t);
    const i = this._x, n = this._y, s = this._z, r = this._w;
    let o = r * t._w + i * t._x + n * t._y + s * t._z;
    if (o < 0 ? (this._w = -t._w, this._x = -t._x, this._y = -t._y, this._z = -t._z, o = -o) : this.copy(t), o >= 1)
      return this._w = r, this._x = i, this._y = n, this._z = s, this;
    const h = 1 - o * o;
    if (h <= Number.EPSILON) {
      const f = 1 - e;
      return this._w = f * r + e * this._w, this._x = f * i + e * this._x, this._y = f * n + e * this._y, this._z = f * s + e * this._z, this.normalize(), this._onChangeCallback(), this;
    }
    const l = Math.sqrt(h), c = Math.atan2(l, o), u = Math.sin((1 - e) * c) / l, d = Math.sin(e * c) / l;
    return this._w = r * u + this._w * d, this._x = i * u + this._x * d, this._y = n * u + this._y * d, this._z = s * u + this._z * d, this._onChangeCallback(), this;
  }
  slerpQuaternions(t, e, i) {
    return this.copy(t).slerp(e, i);
  }
  random() {
    const t = Math.random(), e = Math.sqrt(1 - t), i = Math.sqrt(t), n = 2 * Math.PI * Math.random(), s = 2 * Math.PI * Math.random();
    return this.set(
      e * Math.cos(n),
      i * Math.sin(s),
      i * Math.cos(s),
      e * Math.sin(n)
    );
  }
  equals(t) {
    return t._x === this._x && t._y === this._y && t._z === this._z && t._w === this._w;
  }
  fromArray(t, e = 0) {
    return this._x = t[e], this._y = t[e + 1], this._z = t[e + 2], this._w = t[e + 3], this._onChangeCallback(), this;
  }
  toArray(t = [], e = 0) {
    return t[e] = this._x, t[e + 1] = this._y, t[e + 2] = this._z, t[e + 3] = this._w, t;
  }
  fromBufferAttribute(t, e) {
    return this._x = t.getX(e), this._y = t.getY(e), this._z = t.getZ(e), this._w = t.getW(e), this;
  }
  toJSON() {
    return this.toArray();
  }
  _onChange(t) {
    return this._onChangeCallback = t, this;
  }
  _onChangeCallback() {
  }
  *[Symbol.iterator]() {
    yield this._x, yield this._y, yield this._z, yield this._w;
  }
}
class w {
  constructor(t = 0, e = 0, i = 0) {
    w.prototype.isVector3 = !0, this.x = t, this.y = e, this.z = i;
  }
  set(t, e, i) {
    return i === void 0 && (i = this.z), this.x = t, this.y = e, this.z = i, this;
  }
  setScalar(t) {
    return this.x = t, this.y = t, this.z = t, this;
  }
  setX(t) {
    return this.x = t, this;
  }
  setY(t) {
    return this.y = t, this;
  }
  setZ(t) {
    return this.z = t, this;
  }
  setComponent(t, e) {
    switch (t) {
      case 0:
        this.x = e;
        break;
      case 1:
        this.y = e;
        break;
      case 2:
        this.z = e;
        break;
      default:
        throw new Error("index is out of range: " + t);
    }
    return this;
  }
  getComponent(t) {
    switch (t) {
      case 0:
        return this.x;
      case 1:
        return this.y;
      case 2:
        return this.z;
      default:
        throw new Error("index is out of range: " + t);
    }
  }
  clone() {
    return new this.constructor(this.x, this.y, this.z);
  }
  copy(t) {
    return this.x = t.x, this.y = t.y, this.z = t.z, this;
  }
  add(t) {
    return this.x += t.x, this.y += t.y, this.z += t.z, this;
  }
  addScalar(t) {
    return this.x += t, this.y += t, this.z += t, this;
  }
  addVectors(t, e) {
    return this.x = t.x + e.x, this.y = t.y + e.y, this.z = t.z + e.z, this;
  }
  addScaledVector(t, e) {
    return this.x += t.x * e, this.y += t.y * e, this.z += t.z * e, this;
  }
  sub(t) {
    return this.x -= t.x, this.y -= t.y, this.z -= t.z, this;
  }
  subScalar(t) {
    return this.x -= t, this.y -= t, this.z -= t, this;
  }
  subVectors(t, e) {
    return this.x = t.x - e.x, this.y = t.y - e.y, this.z = t.z - e.z, this;
  }
  multiply(t) {
    return this.x *= t.x, this.y *= t.y, this.z *= t.z, this;
  }
  multiplyScalar(t) {
    return this.x *= t, this.y *= t, this.z *= t, this;
  }
  multiplyVectors(t, e) {
    return this.x = t.x * e.x, this.y = t.y * e.y, this.z = t.z * e.z, this;
  }
  applyEuler(t) {
    return this.applyQuaternion(za.setFromEuler(t));
  }
  applyAxisAngle(t, e) {
    return this.applyQuaternion(za.setFromAxisAngle(t, e));
  }
  applyMatrix3(t) {
    const e = this.x, i = this.y, n = this.z, s = t.elements;
    return this.x = s[0] * e + s[3] * i + s[6] * n, this.y = s[1] * e + s[4] * i + s[7] * n, this.z = s[2] * e + s[5] * i + s[8] * n, this;
  }
  applyNormalMatrix(t) {
    return this.applyMatrix3(t).normalize();
  }
  applyMatrix4(t) {
    const e = this.x, i = this.y, n = this.z, s = t.elements, r = 1 / (s[3] * e + s[7] * i + s[11] * n + s[15]);
    return this.x = (s[0] * e + s[4] * i + s[8] * n + s[12]) * r, this.y = (s[1] * e + s[5] * i + s[9] * n + s[13]) * r, this.z = (s[2] * e + s[6] * i + s[10] * n + s[14]) * r, this;
  }
  applyQuaternion(t) {
    const e = this.x, i = this.y, n = this.z, s = t.x, r = t.y, o = t.z, h = t.w, l = h * e + r * n - o * i, c = h * i + o * e - s * n, u = h * n + s * i - r * e, d = -s * e - r * i - o * n;
    return this.x = l * h + d * -s + c * -o - u * -r, this.y = c * h + d * -r + u * -s - l * -o, this.z = u * h + d * -o + l * -r - c * -s, this;
  }
  project(t) {
    return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix);
  }
  unproject(t) {
    return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld);
  }
  transformDirection(t) {
    const e = this.x, i = this.y, n = this.z, s = t.elements;
    return this.x = s[0] * e + s[4] * i + s[8] * n, this.y = s[1] * e + s[5] * i + s[9] * n, this.z = s[2] * e + s[6] * i + s[10] * n, this.normalize();
  }
  divide(t) {
    return this.x /= t.x, this.y /= t.y, this.z /= t.z, this;
  }
  divideScalar(t) {
    return this.multiplyScalar(1 / t);
  }
  min(t) {
    return this.x = Math.min(this.x, t.x), this.y = Math.min(this.y, t.y), this.z = Math.min(this.z, t.z), this;
  }
  max(t) {
    return this.x = Math.max(this.x, t.x), this.y = Math.max(this.y, t.y), this.z = Math.max(this.z, t.z), this;
  }
  clamp(t, e) {
    return this.x = Math.max(t.x, Math.min(e.x, this.x)), this.y = Math.max(t.y, Math.min(e.y, this.y)), this.z = Math.max(t.z, Math.min(e.z, this.z)), this;
  }
  clampScalar(t, e) {
    return this.x = Math.max(t, Math.min(e, this.x)), this.y = Math.max(t, Math.min(e, this.y)), this.z = Math.max(t, Math.min(e, this.z)), this;
  }
  clampLength(t, e) {
    const i = this.length();
    return this.divideScalar(i || 1).multiplyScalar(Math.max(t, Math.min(e, i)));
  }
  floor() {
    return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this.z = Math.floor(this.z), this;
  }
  ceil() {
    return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this.z = Math.ceil(this.z), this;
  }
  round() {
    return this.x = Math.round(this.x), this.y = Math.round(this.y), this.z = Math.round(this.z), this;
  }
  roundToZero() {
    return this.x = Math.trunc(this.x), this.y = Math.trunc(this.y), this.z = Math.trunc(this.z), this;
  }
  negate() {
    return this.x = -this.x, this.y = -this.y, this.z = -this.z, this;
  }
  dot(t) {
    return this.x * t.x + this.y * t.y + this.z * t.z;
  }
  // TODO lengthSquared?
  lengthSq() {
    return this.x * this.x + this.y * this.y + this.z * this.z;
  }
  length() {
    return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
  }
  manhattanLength() {
    return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z);
  }
  normalize() {
    return this.divideScalar(this.length() || 1);
  }
  setLength(t) {
    return this.normalize().multiplyScalar(t);
  }
  lerp(t, e) {
    return this.x += (t.x - this.x) * e, this.y += (t.y - this.y) * e, this.z += (t.z - this.z) * e, this;
  }
  lerpVectors(t, e, i) {
    return this.x = t.x + (e.x - t.x) * i, this.y = t.y + (e.y - t.y) * i, this.z = t.z + (e.z - t.z) * i, this;
  }
  cross(t) {
    return this.crossVectors(this, t);
  }
  crossVectors(t, e) {
    const i = t.x, n = t.y, s = t.z, r = e.x, o = e.y, h = e.z;
    return this.x = n * h - s * o, this.y = s * r - i * h, this.z = i * o - n * r, this;
  }
  projectOnVector(t) {
    const e = t.lengthSq();
    if (e === 0)
      return this.set(0, 0, 0);
    const i = t.dot(this) / e;
    return this.copy(t).multiplyScalar(i);
  }
  projectOnPlane(t) {
    return hs.copy(this).projectOnVector(t), this.sub(hs);
  }
  reflect(t) {
    return this.sub(hs.copy(t).multiplyScalar(2 * this.dot(t)));
  }
  angleTo(t) {
    const e = Math.sqrt(this.lengthSq() * t.lengthSq());
    if (e === 0)
      return Math.PI / 2;
    const i = this.dot(t) / e;
    return Math.acos(rt(i, -1, 1));
  }
  distanceTo(t) {
    return Math.sqrt(this.distanceToSquared(t));
  }
  distanceToSquared(t) {
    const e = this.x - t.x, i = this.y - t.y, n = this.z - t.z;
    return e * e + i * i + n * n;
  }
  manhattanDistanceTo(t) {
    return Math.abs(this.x - t.x) + Math.abs(this.y - t.y) + Math.abs(this.z - t.z);
  }
  setFromSpherical(t) {
    return this.setFromSphericalCoords(t.radius, t.phi, t.theta);
  }
  setFromSphericalCoords(t, e, i) {
    const n = Math.sin(e) * t;
    return this.x = n * Math.sin(i), this.y = Math.cos(e) * t, this.z = n * Math.cos(i), this;
  }
  setFromCylindrical(t) {
    return this.setFromCylindricalCoords(t.radius, t.theta, t.y);
  }
  setFromCylindricalCoords(t, e, i) {
    return this.x = t * Math.sin(e), this.y = i, this.z = t * Math.cos(e), this;
  }
  setFromMatrixPosition(t) {
    const e = t.elements;
    return this.x = e[12], this.y = e[13], this.z = e[14], this;
  }
  setFromMatrixScale(t) {
    const e = this.setFromMatrixColumn(t, 0).length(), i = this.setFromMatrixColumn(t, 1).length(), n = this.setFromMatrixColumn(t, 2).length();
    return this.x = e, this.y = i, this.z = n, this;
  }
  setFromMatrixColumn(t, e) {
    return this.fromArray(t.elements, e * 4);
  }
  setFromMatrix3Column(t, e) {
    return this.fromArray(t.elements, e * 3);
  }
  setFromEuler(t) {
    return this.x = t._x, this.y = t._y, this.z = t._z, this;
  }
  setFromColor(t) {
    return this.x = t.r, this.y = t.g, this.z = t.b, this;
  }
  equals(t) {
    return t.x === this.x && t.y === this.y && t.z === this.z;
  }
  fromArray(t, e = 0) {
    return this.x = t[e], this.y = t[e + 1], this.z = t[e + 2], this;
  }
  toArray(t = [], e = 0) {
    return t[e] = this.x, t[e + 1] = this.y, t[e + 2] = this.z, t;
  }
  fromBufferAttribute(t, e) {
    return this.x = t.getX(e), this.y = t.getY(e), this.z = t.getZ(e), this;
  }
  random() {
    return this.x = Math.random(), this.y = Math.random(), this.z = Math.random(), this;
  }
  randomDirection() {
    const t = (Math.random() - 0.5) * 2, e = Math.random() * Math.PI * 2, i = Math.sqrt(1 - t ** 2);
    return this.x = i * Math.cos(e), this.y = i * Math.sin(e), this.z = t, this;
  }
  *[Symbol.iterator]() {
    yield this.x, yield this.y, yield this.z;
  }
}
const hs = /* @__PURE__ */ new w(), za = /* @__PURE__ */ new Q();
class Kt {
  constructor(t = new w(1 / 0, 1 / 0, 1 / 0), e = new w(-1 / 0, -1 / 0, -1 / 0)) {
    this.isBox3 = !0, this.min = t, this.max = e;
  }
  set(t, e) {
    return this.min.copy(t), this.max.copy(e), this;
  }
  setFromArray(t) {
    this.makeEmpty();
    for (let e = 0, i = t.length; e < i; e += 3)
      this.expandByPoint(Ut.fromArray(t, e));
    return this;
  }
  setFromBufferAttribute(t) {
    this.makeEmpty();
    for (let e = 0, i = t.count; e < i; e++)
      this.expandByPoint(Ut.fromBufferAttribute(t, e));
    return this;
  }
  setFromPoints(t) {
    this.makeEmpty();
    for (let e = 0, i = t.length; e < i; e++)
      this.expandByPoint(t[e]);
    return this;
  }
  setFromCenterAndSize(t, e) {
    const i = Ut.copy(e).multiplyScalar(0.5);
    return this.min.copy(t).sub(i), this.max.copy(t).add(i), this;
  }
  setFromObject(t, e = !1) {
    return this.makeEmpty(), this.expandByObject(t, e);
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    return this.min.copy(t.min), this.max.copy(t.max), this;
  }
  makeEmpty() {
    return this.min.x = this.min.y = this.min.z = 1 / 0, this.max.x = this.max.y = this.max.z = -1 / 0, this;
  }
  isEmpty() {
    return this.max.x < this.min.x || this.max.y < this.min.y || this.max.z < this.min.z;
  }
  getCenter(t) {
    return this.isEmpty() ? t.set(0, 0, 0) : t.addVectors(this.min, this.max).multiplyScalar(0.5);
  }
  getSize(t) {
    return this.isEmpty() ? t.set(0, 0, 0) : t.subVectors(this.max, this.min);
  }
  expandByPoint(t) {
    return this.min.min(t), this.max.max(t), this;
  }
  expandByVector(t) {
    return this.min.sub(t), this.max.add(t), this;
  }
  expandByScalar(t) {
    return this.min.addScalar(-t), this.max.addScalar(t), this;
  }
  expandByObject(t, e = !1) {
    if (t.updateWorldMatrix(!1, !1), t.boundingBox !== void 0)
      t.boundingBox === null && t.computeBoundingBox(), Ce.copy(t.boundingBox), Ce.applyMatrix4(t.matrixWorld), this.union(Ce);
    else {
      const n = t.geometry;
      if (n !== void 0)
        if (e && n.attributes !== void 0 && n.attributes.position !== void 0) {
          const s = n.attributes.position;
          for (let r = 0, o = s.count; r < o; r++)
            Ut.fromBufferAttribute(s, r).applyMatrix4(t.matrixWorld), this.expandByPoint(Ut);
        } else
          n.boundingBox === null && n.computeBoundingBox(), Ce.copy(n.boundingBox), Ce.applyMatrix4(t.matrixWorld), this.union(Ce);
    }
    const i = t.children;
    for (let n = 0, s = i.length; n < s; n++)
      this.expandByObject(i[n], e);
    return this;
  }
  containsPoint(t) {
    return !(t.x < this.min.x || t.x > this.max.x || t.y < this.min.y || t.y > this.max.y || t.z < this.min.z || t.z > this.max.z);
  }
  containsBox(t) {
    return this.min.x <= t.min.x && t.max.x <= this.max.x && this.min.y <= t.min.y && t.max.y <= this.max.y && this.min.z <= t.min.z && t.max.z <= this.max.z;
  }
  getParameter(t, e) {
    return e.set(
      (t.x - this.min.x) / (this.max.x - this.min.x),
      (t.y - this.min.y) / (this.max.y - this.min.y),
      (t.z - this.min.z) / (this.max.z - this.min.z)
    );
  }
  intersectsBox(t) {
    return !(t.max.x < this.min.x || t.min.x > this.max.x || t.max.y < this.min.y || t.min.y > this.max.y || t.max.z < this.min.z || t.min.z > this.max.z);
  }
  intersectsSphere(t) {
    return this.clampPoint(t.center, Ut), Ut.distanceToSquared(t.center) <= t.radius * t.radius;
  }
  intersectsPlane(t) {
    let e, i;
    return t.normal.x > 0 ? (e = t.normal.x * this.min.x, i = t.normal.x * this.max.x) : (e = t.normal.x * this.max.x, i = t.normal.x * this.min.x), t.normal.y > 0 ? (e += t.normal.y * this.min.y, i += t.normal.y * this.max.y) : (e += t.normal.y * this.max.y, i += t.normal.y * this.min.y), t.normal.z > 0 ? (e += t.normal.z * this.min.z, i += t.normal.z * this.max.z) : (e += t.normal.z * this.max.z, i += t.normal.z * this.min.z), e <= -t.constant && i >= -t.constant;
  }
  intersectsTriangle(t) {
    if (this.isEmpty())
      return !1;
    this.getCenter(fi), Ji.subVectors(this.max, fi), Oe.subVectors(t.a, fi), Ne.subVectors(t.b, fi), Le.subVectors(t.c, fi), Zt.subVectors(Ne, Oe), Qt.subVectors(Le, Ne), ye.subVectors(Oe, Le);
    let e = [
      0,
      -Zt.z,
      Zt.y,
      0,
      -Qt.z,
      Qt.y,
      0,
      -ye.z,
      ye.y,
      Zt.z,
      0,
      -Zt.x,
      Qt.z,
      0,
      -Qt.x,
      ye.z,
      0,
      -ye.x,
      -Zt.y,
      Zt.x,
      0,
      -Qt.y,
      Qt.x,
      0,
      -ye.y,
      ye.x,
      0
    ];
    return !ls(e, Oe, Ne, Le, Ji) || (e = [1, 0, 0, 0, 1, 0, 0, 0, 1], !ls(e, Oe, Ne, Le, Ji)) ? !1 : (Zi.crossVectors(Zt, Qt), e = [Zi.x, Zi.y, Zi.z], ls(e, Oe, Ne, Le, Ji));
  }
  clampPoint(t, e) {
    return e.copy(t).clamp(this.min, this.max);
  }
  distanceToPoint(t) {
    return this.clampPoint(t, Ut).distanceTo(t);
  }
  getBoundingSphere(t) {
    return this.isEmpty() ? t.makeEmpty() : (this.getCenter(t.center), t.radius = this.getSize(Ut).length() * 0.5), t;
  }
  intersect(t) {
    return this.min.max(t.min), this.max.min(t.max), this.isEmpty() && this.makeEmpty(), this;
  }
  union(t) {
    return this.min.min(t.min), this.max.max(t.max), this;
  }
  applyMatrix4(t) {
    return this.isEmpty() ? this : (zt[0].set(this.min.x, this.min.y, this.min.z).applyMatrix4(t), zt[1].set(this.min.x, this.min.y, this.max.z).applyMatrix4(t), zt[2].set(this.min.x, this.max.y, this.min.z).applyMatrix4(t), zt[3].set(this.min.x, this.max.y, this.max.z).applyMatrix4(t), zt[4].set(this.max.x, this.min.y, this.min.z).applyMatrix4(t), zt[5].set(this.max.x, this.min.y, this.max.z).applyMatrix4(t), zt[6].set(this.max.x, this.max.y, this.min.z).applyMatrix4(t), zt[7].set(this.max.x, this.max.y, this.max.z).applyMatrix4(t), this.setFromPoints(zt), this);
  }
  translate(t) {
    return this.min.add(t), this.max.add(t), this;
  }
  equals(t) {
    return t.min.equals(this.min) && t.max.equals(this.max);
  }
}
const zt = [
  /* @__PURE__ */ new w(),
  /* @__PURE__ */ new w(),
  /* @__PURE__ */ new w(),
  /* @__PURE__ */ new w(),
  /* @__PURE__ */ new w(),
  /* @__PURE__ */ new w(),
  /* @__PURE__ */ new w(),
  /* @__PURE__ */ new w()
], Ut = /* @__PURE__ */ new w(), Ce = /* @__PURE__ */ new Kt(), Oe = /* @__PURE__ */ new w(), Ne = /* @__PURE__ */ new w(), Le = /* @__PURE__ */ new w(), Zt = /* @__PURE__ */ new w(), Qt = /* @__PURE__ */ new w(), ye = /* @__PURE__ */ new w(), fi = /* @__PURE__ */ new w(), Ji = /* @__PURE__ */ new w(), Zi = /* @__PURE__ */ new w(), ge = /* @__PURE__ */ new w();
function ls(a, t, e, i, n) {
  for (let s = 0, r = a.length - 3; s <= r; s += 3) {
    ge.fromArray(a, s);
    const o = n.x * Math.abs(ge.x) + n.y * Math.abs(ge.y) + n.z * Math.abs(ge.z), h = t.dot(ge), l = e.dot(ge), c = i.dot(ge);
    if (Math.max(-Math.max(h, l, c), Math.min(h, l, c)) > o)
      return !1;
  }
  return !0;
}
const Bc = /* @__PURE__ */ new Kt(), pi = /* @__PURE__ */ new w(), cs = /* @__PURE__ */ new w();
class Lt {
  constructor(t = new w(), e = -1) {
    this.center = t, this.radius = e;
  }
  set(t, e) {
    return this.center.copy(t), this.radius = e, this;
  }
  setFromPoints(t, e) {
    const i = this.center;
    e !== void 0 ? i.copy(e) : Bc.setFromPoints(t).getCenter(i);
    let n = 0;
    for (let s = 0, r = t.length; s < r; s++)
      n = Math.max(n, i.distanceToSquared(t[s]));
    return this.radius = Math.sqrt(n), this;
  }
  copy(t) {
    return this.center.copy(t.center), this.radius = t.radius, this;
  }
  isEmpty() {
    return this.radius < 0;
  }
  makeEmpty() {
    return this.center.set(0, 0, 0), this.radius = -1, this;
  }
  containsPoint(t) {
    return t.distanceToSquared(this.center) <= this.radius * this.radius;
  }
  distanceToPoint(t) {
    return t.distanceTo(this.center) - this.radius;
  }
  intersectsSphere(t) {
    const e = this.radius + t.radius;
    return t.center.distanceToSquared(this.center) <= e * e;
  }
  intersectsBox(t) {
    return t.intersectsSphere(this);
  }
  intersectsPlane(t) {
    return Math.abs(t.distanceToPoint(this.center)) <= this.radius;
  }
  clampPoint(t, e) {
    const i = this.center.distanceToSquared(t);
    return e.copy(t), i > this.radius * this.radius && (e.sub(this.center).normalize(), e.multiplyScalar(this.radius).add(this.center)), e;
  }
  getBoundingBox(t) {
    return this.isEmpty() ? (t.makeEmpty(), t) : (t.set(this.center, this.center), t.expandByScalar(this.radius), t);
  }
  applyMatrix4(t) {
    return this.center.applyMatrix4(t), this.radius = this.radius * t.getMaxScaleOnAxis(), this;
  }
  translate(t) {
    return this.center.add(t), this;
  }
  expandByPoint(t) {
    if (this.isEmpty())
      return this.center.copy(t), this.radius = 0, this;
    pi.subVectors(t, this.center);
    const e = pi.lengthSq();
    if (e > this.radius * this.radius) {
      const i = Math.sqrt(e), n = (i - this.radius) * 0.5;
      this.center.addScaledVector(pi, n / i), this.radius += n;
    }
    return this;
  }
  union(t) {
    return t.isEmpty() ? this : this.isEmpty() ? (this.copy(t), this) : (this.center.equals(t.center) === !0 ? this.radius = Math.max(this.radius, t.radius) : (cs.subVectors(t.center, this.center).setLength(t.radius), this.expandByPoint(pi.copy(t.center).add(cs)), this.expandByPoint(pi.copy(t.center).sub(cs))), this);
  }
  equals(t) {
    return t.center.equals(this.center) && t.radius === this.radius;
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
const jt = /* @__PURE__ */ new w(), us = /* @__PURE__ */ new w(), Qi = /* @__PURE__ */ new w(), te = /* @__PURE__ */ new w(), ds = /* @__PURE__ */ new w(), tn = /* @__PURE__ */ new w(), fs = /* @__PURE__ */ new w();
class Oi {
  constructor(t = new w(), e = new w(0, 0, -1)) {
    this.origin = t, this.direction = e;
  }
  set(t, e) {
    return this.origin.copy(t), this.direction.copy(e), this;
  }
  copy(t) {
    return this.origin.copy(t.origin), this.direction.copy(t.direction), this;
  }
  at(t, e) {
    return e.copy(this.origin).addScaledVector(this.direction, t);
  }
  lookAt(t) {
    return this.direction.copy(t).sub(this.origin).normalize(), this;
  }
  recast(t) {
    return this.origin.copy(this.at(t, jt)), this;
  }
  closestPointToPoint(t, e) {
    e.subVectors(t, this.origin);
    const i = e.dot(this.direction);
    return i < 0 ? e.copy(this.origin) : e.copy(this.origin).addScaledVector(this.direction, i);
  }
  distanceToPoint(t) {
    return Math.sqrt(this.distanceSqToPoint(t));
  }
  distanceSqToPoint(t) {
    const e = jt.subVectors(t, this.origin).dot(this.direction);
    return e < 0 ? this.origin.distanceToSquared(t) : (jt.copy(this.origin).addScaledVector(this.direction, e), jt.distanceToSquared(t));
  }
  distanceSqToSegment(t, e, i, n) {
    us.copy(t).add(e).multiplyScalar(0.5), Qi.copy(e).sub(t).normalize(), te.copy(this.origin).sub(us);
    const s = t.distanceTo(e) * 0.5, r = -this.direction.dot(Qi), o = te.dot(this.direction), h = -te.dot(Qi), l = te.lengthSq(), c = Math.abs(1 - r * r);
    let u, d, f, p;
    if (c > 0)
      if (u = r * h - o, d = r * o - h, p = s * c, u >= 0)
        if (d >= -p)
          if (d <= p) {
            const y = 1 / c;
            u *= y, d *= y, f = u * (u + r * d + 2 * o) + d * (r * u + d + 2 * h) + l;
          } else
            d = s, u = Math.max(0, -(r * d + o)), f = -u * u + d * (d + 2 * h) + l;
        else
          d = -s, u = Math.max(0, -(r * d + o)), f = -u * u + d * (d + 2 * h) + l;
      else
        d <= -p ? (u = Math.max(0, -(-r * s + o)), d = u > 0 ? -s : Math.min(Math.max(-s, -h), s), f = -u * u + d * (d + 2 * h) + l) : d <= p ? (u = 0, d = Math.min(Math.max(-s, -h), s), f = d * (d + 2 * h) + l) : (u = Math.max(0, -(r * s + o)), d = u > 0 ? s : Math.min(Math.max(-s, -h), s), f = -u * u + d * (d + 2 * h) + l);
    else
      d = r > 0 ? -s : s, u = Math.max(0, -(r * d + o)), f = -u * u + d * (d + 2 * h) + l;
    return i && i.copy(this.origin).addScaledVector(this.direction, u), n && n.copy(us).addScaledVector(Qi, d), f;
  }
  intersectSphere(t, e) {
    jt.subVectors(t.center, this.origin);
    const i = jt.dot(this.direction), n = jt.dot(jt) - i * i, s = t.radius * t.radius;
    if (n > s)
      return null;
    const r = Math.sqrt(s - n), o = i - r, h = i + r;
    return h < 0 ? null : o < 0 ? this.at(h, e) : this.at(o, e);
  }
  intersectsSphere(t) {
    return this.distanceSqToPoint(t.center) <= t.radius * t.radius;
  }
  distanceToPlane(t) {
    const e = t.normal.dot(this.direction);
    if (e === 0)
      return t.distanceToPoint(this.origin) === 0 ? 0 : null;
    const i = -(this.origin.dot(t.normal) + t.constant) / e;
    return i >= 0 ? i : null;
  }
  intersectPlane(t, e) {
    const i = this.distanceToPlane(t);
    return i === null ? null : this.at(i, e);
  }
  intersectsPlane(t) {
    const e = t.distanceToPoint(this.origin);
    return e === 0 || t.normal.dot(this.direction) * e < 0;
  }
  intersectBox(t, e) {
    let i, n, s, r, o, h;
    const l = 1 / this.direction.x, c = 1 / this.direction.y, u = 1 / this.direction.z, d = this.origin;
    return l >= 0 ? (i = (t.min.x - d.x) * l, n = (t.max.x - d.x) * l) : (i = (t.max.x - d.x) * l, n = (t.min.x - d.x) * l), c >= 0 ? (s = (t.min.y - d.y) * c, r = (t.max.y - d.y) * c) : (s = (t.max.y - d.y) * c, r = (t.min.y - d.y) * c), i > r || s > n || ((s > i || isNaN(i)) && (i = s), (r < n || isNaN(n)) && (n = r), u >= 0 ? (o = (t.min.z - d.z) * u, h = (t.max.z - d.z) * u) : (o = (t.max.z - d.z) * u, h = (t.min.z - d.z) * u), i > h || o > n) || ((o > i || i !== i) && (i = o), (h < n || n !== n) && (n = h), n < 0) ? null : this.at(i >= 0 ? i : n, e);
  }
  intersectsBox(t) {
    return this.intersectBox(t, jt) !== null;
  }
  intersectTriangle(t, e, i, n, s) {
    ds.subVectors(e, t), tn.subVectors(i, t), fs.crossVectors(ds, tn);
    let r = this.direction.dot(fs), o;
    if (r > 0) {
      if (n)
        return null;
      o = 1;
    } else if (r < 0)
      o = -1, r = -r;
    else
      return null;
    te.subVectors(this.origin, t);
    const h = o * this.direction.dot(tn.crossVectors(te, tn));
    if (h < 0)
      return null;
    const l = o * this.direction.dot(ds.cross(te));
    if (l < 0 || h + l > r)
      return null;
    const c = -o * te.dot(fs);
    return c < 0 ? null : this.at(c / r, s);
  }
  applyMatrix4(t) {
    return this.origin.applyMatrix4(t), this.direction.transformDirection(t), this;
  }
  equals(t) {
    return t.origin.equals(this.origin) && t.direction.equals(this.direction);
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
class F {
  constructor(t, e, i, n, s, r, o, h, l, c, u, d, f, p, y, m) {
    F.prototype.isMatrix4 = !0, this.elements = [
      1,
      0,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      1
    ], t !== void 0 && this.set(t, e, i, n, s, r, o, h, l, c, u, d, f, p, y, m);
  }
  set(t, e, i, n, s, r, o, h, l, c, u, d, f, p, y, m) {
    const _ = this.elements;
    return _[0] = t, _[4] = e, _[8] = i, _[12] = n, _[1] = s, _[5] = r, _[9] = o, _[13] = h, _[2] = l, _[6] = c, _[10] = u, _[14] = d, _[3] = f, _[7] = p, _[11] = y, _[15] = m, this;
  }
  identity() {
    return this.set(
      1,
      0,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      1
    ), this;
  }
  clone() {
    return new F().fromArray(this.elements);
  }
  copy(t) {
    const e = this.elements, i = t.elements;
    return e[0] = i[0], e[1] = i[1], e[2] = i[2], e[3] = i[3], e[4] = i[4], e[5] = i[5], e[6] = i[6], e[7] = i[7], e[8] = i[8], e[9] = i[9], e[10] = i[10], e[11] = i[11], e[12] = i[12], e[13] = i[13], e[14] = i[14], e[15] = i[15], this;
  }
  copyPosition(t) {
    const e = this.elements, i = t.elements;
    return e[12] = i[12], e[13] = i[13], e[14] = i[14], this;
  }
  setFromMatrix3(t) {
    const e = t.elements;
    return this.set(
      e[0],
      e[3],
      e[6],
      0,
      e[1],
      e[4],
      e[7],
      0,
      e[2],
      e[5],
      e[8],
      0,
      0,
      0,
      0,
      1
    ), this;
  }
  extractBasis(t, e, i) {
    return t.setFromMatrixColumn(this, 0), e.setFromMatrixColumn(this, 1), i.setFromMatrixColumn(this, 2), this;
  }
  makeBasis(t, e, i) {
    return this.set(
      t.x,
      e.x,
      i.x,
      0,
      t.y,
      e.y,
      i.y,
      0,
      t.z,
      e.z,
      i.z,
      0,
      0,
      0,
      0,
      1
    ), this;
  }
  extractRotation(t) {
    const e = this.elements, i = t.elements, n = 1 / De.setFromMatrixColumn(t, 0).length(), s = 1 / De.setFromMatrixColumn(t, 1).length(), r = 1 / De.setFromMatrixColumn(t, 2).length();
    return e[0] = i[0] * n, e[1] = i[1] * n, e[2] = i[2] * n, e[3] = 0, e[4] = i[4] * s, e[5] = i[5] * s, e[6] = i[6] * s, e[7] = 0, e[8] = i[8] * r, e[9] = i[9] * r, e[10] = i[10] * r, e[11] = 0, e[12] = 0, e[13] = 0, e[14] = 0, e[15] = 1, this;
  }
  makeRotationFromEuler(t) {
    const e = this.elements, i = t.x, n = t.y, s = t.z, r = Math.cos(i), o = Math.sin(i), h = Math.cos(n), l = Math.sin(n), c = Math.cos(s), u = Math.sin(s);
    if (t.order === "XYZ") {
      const d = r * c, f = r * u, p = o * c, y = o * u;
      e[0] = h * c, e[4] = -h * u, e[8] = l, e[1] = f + p * l, e[5] = d - y * l, e[9] = -o * h, e[2] = y - d * l, e[6] = p + f * l, e[10] = r * h;
    } else if (t.order === "YXZ") {
      const d = h * c, f = h * u, p = l * c, y = l * u;
      e[0] = d + y * o, e[4] = p * o - f, e[8] = r * l, e[1] = r * u, e[5] = r * c, e[9] = -o, e[2] = f * o - p, e[6] = y + d * o, e[10] = r * h;
    } else if (t.order === "ZXY") {
      const d = h * c, f = h * u, p = l * c, y = l * u;
      e[0] = d - y * o, e[4] = -r * u, e[8] = p + f * o, e[1] = f + p * o, e[5] = r * c, e[9] = y - d * o, e[2] = -r * l, e[6] = o, e[10] = r * h;
    } else if (t.order === "ZYX") {
      const d = r * c, f = r * u, p = o * c, y = o * u;
      e[0] = h * c, e[4] = p * l - f, e[8] = d * l + y, e[1] = h * u, e[5] = y * l + d, e[9] = f * l - p, e[2] = -l, e[6] = o * h, e[10] = r * h;
    } else if (t.order === "YZX") {
      const d = r * h, f = r * l, p = o * h, y = o * l;
      e[0] = h * c, e[4] = y - d * u, e[8] = p * u + f, e[1] = u, e[5] = r * c, e[9] = -o * c, e[2] = -l * c, e[6] = f * u + p, e[10] = d - y * u;
    } else if (t.order === "XZY") {
      const d = r * h, f = r * l, p = o * h, y = o * l;
      e[0] = h * c, e[4] = -u, e[8] = l * c, e[1] = d * u + y, e[5] = r * c, e[9] = f * u - p, e[2] = p * u - f, e[6] = o * c, e[10] = y * u + d;
    }
    return e[3] = 0, e[7] = 0, e[11] = 0, e[12] = 0, e[13] = 0, e[14] = 0, e[15] = 1, this;
  }
  makeRotationFromQuaternion(t) {
    return this.compose(Fc, t, kc);
  }
  lookAt(t, e, i) {
    const n = this.elements;
    return dt.subVectors(t, e), dt.lengthSq() === 0 && (dt.z = 1), dt.normalize(), ee.crossVectors(i, dt), ee.lengthSq() === 0 && (Math.abs(i.z) === 1 ? dt.x += 1e-4 : dt.z += 1e-4, dt.normalize(), ee.crossVectors(i, dt)), ee.normalize(), en.crossVectors(dt, ee), n[0] = ee.x, n[4] = en.x, n[8] = dt.x, n[1] = ee.y, n[5] = en.y, n[9] = dt.y, n[2] = ee.z, n[6] = en.z, n[10] = dt.z, this;
  }
  multiply(t) {
    return this.multiplyMatrices(this, t);
  }
  premultiply(t) {
    return this.multiplyMatrices(t, this);
  }
  multiplyMatrices(t, e) {
    const i = t.elements, n = e.elements, s = this.elements, r = i[0], o = i[4], h = i[8], l = i[12], c = i[1], u = i[5], d = i[9], f = i[13], p = i[2], y = i[6], m = i[10], _ = i[14], b = i[3], A = i[7], g = i[11], x = i[15], v = n[0], M = n[4], T = n[8], I = n[12], E = n[1], R = n[5], S = n[9], C = n[13], O = n[2], L = n[6], P = n[10], $ = n[14], D = n[3], k = n[7], W = n[11], ht = n[15];
    return s[0] = r * v + o * E + h * O + l * D, s[4] = r * M + o * R + h * L + l * k, s[8] = r * T + o * S + h * P + l * W, s[12] = r * I + o * C + h * $ + l * ht, s[1] = c * v + u * E + d * O + f * D, s[5] = c * M + u * R + d * L + f * k, s[9] = c * T + u * S + d * P + f * W, s[13] = c * I + u * C + d * $ + f * ht, s[2] = p * v + y * E + m * O + _ * D, s[6] = p * M + y * R + m * L + _ * k, s[10] = p * T + y * S + m * P + _ * W, s[14] = p * I + y * C + m * $ + _ * ht, s[3] = b * v + A * E + g * O + x * D, s[7] = b * M + A * R + g * L + x * k, s[11] = b * T + A * S + g * P + x * W, s[15] = b * I + A * C + g * $ + x * ht, this;
  }
  multiplyScalar(t) {
    const e = this.elements;
    return e[0] *= t, e[4] *= t, e[8] *= t, e[12] *= t, e[1] *= t, e[5] *= t, e[9] *= t, e[13] *= t, e[2] *= t, e[6] *= t, e[10] *= t, e[14] *= t, e[3] *= t, e[7] *= t, e[11] *= t, e[15] *= t, this;
  }
  determinant() {
    const t = this.elements, e = t[0], i = t[4], n = t[8], s = t[12], r = t[1], o = t[5], h = t[9], l = t[13], c = t[2], u = t[6], d = t[10], f = t[14], p = t[3], y = t[7], m = t[11], _ = t[15];
    return p * (+s * h * u - n * l * u - s * o * d + i * l * d + n * o * f - i * h * f) + y * (+e * h * f - e * l * d + s * r * d - n * r * f + n * l * c - s * h * c) + m * (+e * l * u - e * o * f - s * r * u + i * r * f + s * o * c - i * l * c) + _ * (-n * o * c - e * h * u + e * o * d + n * r * u - i * r * d + i * h * c);
  }
  transpose() {
    const t = this.elements;
    let e;
    return e = t[1], t[1] = t[4], t[4] = e, e = t[2], t[2] = t[8], t[8] = e, e = t[6], t[6] = t[9], t[9] = e, e = t[3], t[3] = t[12], t[12] = e, e = t[7], t[7] = t[13], t[13] = e, e = t[11], t[11] = t[14], t[14] = e, this;
  }
  setPosition(t, e, i) {
    const n = this.elements;
    return t.isVector3 ? (n[12] = t.x, n[13] = t.y, n[14] = t.z) : (n[12] = t, n[13] = e, n[14] = i), this;
  }
  invert() {
    const t = this.elements, e = t[0], i = t[1], n = t[2], s = t[3], r = t[4], o = t[5], h = t[6], l = t[7], c = t[8], u = t[9], d = t[10], f = t[11], p = t[12], y = t[13], m = t[14], _ = t[15], b = u * m * l - y * d * l + y * h * f - o * m * f - u * h * _ + o * d * _, A = p * d * l - c * m * l - p * h * f + r * m * f + c * h * _ - r * d * _, g = c * y * l - p * u * l + p * o * f - r * y * f - c * o * _ + r * u * _, x = p * u * h - c * y * h - p * o * d + r * y * d + c * o * m - r * u * m, v = e * b + i * A + n * g + s * x;
    if (v === 0)
      return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    const M = 1 / v;
    return t[0] = b * M, t[1] = (y * d * s - u * m * s - y * n * f + i * m * f + u * n * _ - i * d * _) * M, t[2] = (o * m * s - y * h * s + y * n * l - i * m * l - o * n * _ + i * h * _) * M, t[3] = (u * h * s - o * d * s - u * n * l + i * d * l + o * n * f - i * h * f) * M, t[4] = A * M, t[5] = (c * m * s - p * d * s + p * n * f - e * m * f - c * n * _ + e * d * _) * M, t[6] = (p * h * s - r * m * s - p * n * l + e * m * l + r * n * _ - e * h * _) * M, t[7] = (r * d * s - c * h * s + c * n * l - e * d * l - r * n * f + e * h * f) * M, t[8] = g * M, t[9] = (p * u * s - c * y * s - p * i * f + e * y * f + c * i * _ - e * u * _) * M, t[10] = (r * y * s - p * o * s + p * i * l - e * y * l - r * i * _ + e * o * _) * M, t[11] = (c * o * s - r * u * s - c * i * l + e * u * l + r * i * f - e * o * f) * M, t[12] = x * M, t[13] = (c * y * n - p * u * n + p * i * d - e * y * d - c * i * m + e * u * m) * M, t[14] = (p * o * n - r * y * n - p * i * h + e * y * h + r * i * m - e * o * m) * M, t[15] = (r * u * n - c * o * n + c * i * h - e * u * h - r * i * d + e * o * d) * M, this;
  }
  scale(t) {
    const e = this.elements, i = t.x, n = t.y, s = t.z;
    return e[0] *= i, e[4] *= n, e[8] *= s, e[1] *= i, e[5] *= n, e[9] *= s, e[2] *= i, e[6] *= n, e[10] *= s, e[3] *= i, e[7] *= n, e[11] *= s, this;
  }
  getMaxScaleOnAxis() {
    const t = this.elements, e = t[0] * t[0] + t[1] * t[1] + t[2] * t[2], i = t[4] * t[4] + t[5] * t[5] + t[6] * t[6], n = t[8] * t[8] + t[9] * t[9] + t[10] * t[10];
    return Math.sqrt(Math.max(e, i, n));
  }
  makeTranslation(t, e, i) {
    return t.isVector3 ? this.set(
      1,
      0,
      0,
      t.x,
      0,
      1,
      0,
      t.y,
      0,
      0,
      1,
      t.z,
      0,
      0,
      0,
      1
    ) : this.set(
      1,
      0,
      0,
      t,
      0,
      1,
      0,
      e,
      0,
      0,
      1,
      i,
      0,
      0,
      0,
      1
    ), this;
  }
  makeRotationX(t) {
    const e = Math.cos(t), i = Math.sin(t);
    return this.set(
      1,
      0,
      0,
      0,
      0,
      e,
      -i,
      0,
      0,
      i,
      e,
      0,
      0,
      0,
      0,
      1
    ), this;
  }
  makeRotationY(t) {
    const e = Math.cos(t), i = Math.sin(t);
    return this.set(
      e,
      0,
      i,
      0,
      0,
      1,
      0,
      0,
      -i,
      0,
      e,
      0,
      0,
      0,
      0,
      1
    ), this;
  }
  makeRotationZ(t) {
    const e = Math.cos(t), i = Math.sin(t);
    return this.set(
      e,
      -i,
      0,
      0,
      i,
      e,
      0,
      0,
      0,
      0,
      1,
      0,
      0,
      0,
      0,
      1
    ), this;
  }
  makeRotationAxis(t, e) {
    const i = Math.cos(e), n = Math.sin(e), s = 1 - i, r = t.x, o = t.y, h = t.z, l = s * r, c = s * o;
    return this.set(
      l * r + i,
      l * o - n * h,
      l * h + n * o,
      0,
      l * o + n * h,
      c * o + i,
      c * h - n * r,
      0,
      l * h - n * o,
      c * h + n * r,
      s * h * h + i,
      0,
      0,
      0,
      0,
      1
    ), this;
  }
  makeScale(t, e, i) {
    return this.set(
      t,
      0,
      0,
      0,
      0,
      e,
      0,
      0,
      0,
      0,
      i,
      0,
      0,
      0,
      0,
      1
    ), this;
  }
  makeShear(t, e, i, n, s, r) {
    return this.set(
      1,
      i,
      s,
      0,
      t,
      1,
      r,
      0,
      e,
      n,
      1,
      0,
      0,
      0,
      0,
      1
    ), this;
  }
  compose(t, e, i) {
    const n = this.elements, s = e._x, r = e._y, o = e._z, h = e._w, l = s + s, c = r + r, u = o + o, d = s * l, f = s * c, p = s * u, y = r * c, m = r * u, _ = o * u, b = h * l, A = h * c, g = h * u, x = i.x, v = i.y, M = i.z;
    return n[0] = (1 - (y + _)) * x, n[1] = (f + g) * x, n[2] = (p - A) * x, n[3] = 0, n[4] = (f - g) * v, n[5] = (1 - (d + _)) * v, n[6] = (m + b) * v, n[7] = 0, n[8] = (p + A) * M, n[9] = (m - b) * M, n[10] = (1 - (d + y)) * M, n[11] = 0, n[12] = t.x, n[13] = t.y, n[14] = t.z, n[15] = 1, this;
  }
  decompose(t, e, i) {
    const n = this.elements;
    let s = De.set(n[0], n[1], n[2]).length();
    const r = De.set(n[4], n[5], n[6]).length(), o = De.set(n[8], n[9], n[10]).length();
    this.determinant() < 0 && (s = -s), t.x = n[12], t.y = n[13], t.z = n[14], xt.copy(this);
    const l = 1 / s, c = 1 / r, u = 1 / o;
    return xt.elements[0] *= l, xt.elements[1] *= l, xt.elements[2] *= l, xt.elements[4] *= c, xt.elements[5] *= c, xt.elements[6] *= c, xt.elements[8] *= u, xt.elements[9] *= u, xt.elements[10] *= u, e.setFromRotationMatrix(xt), i.x = s, i.y = r, i.z = o, this;
  }
  makePerspective(t, e, i, n, s, r, o = Me) {
    const h = this.elements, l = 2 * s / (e - t), c = 2 * s / (i - n), u = (e + t) / (e - t), d = (i + n) / (i - n);
    let f, p;
    if (o === Me)
      f = -(r + s) / (r - s), p = -2 * r * s / (r - s);
    else if (o === ar)
      f = -r / (r - s), p = -r * s / (r - s);
    else
      throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: " + o);
    return h[0] = l, h[4] = 0, h[8] = u, h[12] = 0, h[1] = 0, h[5] = c, h[9] = d, h[13] = 0, h[2] = 0, h[6] = 0, h[10] = f, h[14] = p, h[3] = 0, h[7] = 0, h[11] = -1, h[15] = 0, this;
  }
  makeOrthographic(t, e, i, n, s, r, o = Me) {
    const h = this.elements, l = 1 / (e - t), c = 1 / (i - n), u = 1 / (r - s), d = (e + t) * l, f = (i + n) * c;
    let p, y;
    if (o === Me)
      p = (r + s) * u, y = -2 * u;
    else if (o === ar)
      p = s * u, y = -1 * u;
    else
      throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: " + o);
    return h[0] = 2 * l, h[4] = 0, h[8] = 0, h[12] = -d, h[1] = 0, h[5] = 2 * c, h[9] = 0, h[13] = -f, h[2] = 0, h[6] = 0, h[10] = y, h[14] = -p, h[3] = 0, h[7] = 0, h[11] = 0, h[15] = 1, this;
  }
  equals(t) {
    const e = this.elements, i = t.elements;
    for (let n = 0; n < 16; n++)
      if (e[n] !== i[n])
        return !1;
    return !0;
  }
  fromArray(t, e = 0) {
    for (let i = 0; i < 16; i++)
      this.elements[i] = t[i + e];
    return this;
  }
  toArray(t = [], e = 0) {
    const i = this.elements;
    return t[e] = i[0], t[e + 1] = i[1], t[e + 2] = i[2], t[e + 3] = i[3], t[e + 4] = i[4], t[e + 5] = i[5], t[e + 6] = i[6], t[e + 7] = i[7], t[e + 8] = i[8], t[e + 9] = i[9], t[e + 10] = i[10], t[e + 11] = i[11], t[e + 12] = i[12], t[e + 13] = i[13], t[e + 14] = i[14], t[e + 15] = i[15], t;
  }
}
const De = /* @__PURE__ */ new w(), xt = /* @__PURE__ */ new F(), Fc = /* @__PURE__ */ new w(0, 0, 0), kc = /* @__PURE__ */ new w(1, 1, 1), ee = /* @__PURE__ */ new w(), en = /* @__PURE__ */ new w(), dt = /* @__PURE__ */ new w(), Ua = /* @__PURE__ */ new F(), ja = /* @__PURE__ */ new Q();
class Ni {
  constructor(t = 0, e = 0, i = 0, n = Ni.DEFAULT_ORDER) {
    this.isEuler = !0, this._x = t, this._y = e, this._z = i, this._order = n;
  }
  get x() {
    return this._x;
  }
  set x(t) {
    this._x = t, this._onChangeCallback();
  }
  get y() {
    return this._y;
  }
  set y(t) {
    this._y = t, this._onChangeCallback();
  }
  get z() {
    return this._z;
  }
  set z(t) {
    this._z = t, this._onChangeCallback();
  }
  get order() {
    return this._order;
  }
  set order(t) {
    this._order = t, this._onChangeCallback();
  }
  set(t, e, i, n = this._order) {
    return this._x = t, this._y = e, this._z = i, this._order = n, this._onChangeCallback(), this;
  }
  clone() {
    return new this.constructor(this._x, this._y, this._z, this._order);
  }
  copy(t) {
    return this._x = t._x, this._y = t._y, this._z = t._z, this._order = t._order, this._onChangeCallback(), this;
  }
  setFromRotationMatrix(t, e = this._order, i = !0) {
    const n = t.elements, s = n[0], r = n[4], o = n[8], h = n[1], l = n[5], c = n[9], u = n[2], d = n[6], f = n[10];
    switch (e) {
      case "XYZ":
        this._y = Math.asin(rt(o, -1, 1)), Math.abs(o) < 0.9999999 ? (this._x = Math.atan2(-c, f), this._z = Math.atan2(-r, s)) : (this._x = Math.atan2(d, l), this._z = 0);
        break;
      case "YXZ":
        this._x = Math.asin(-rt(c, -1, 1)), Math.abs(c) < 0.9999999 ? (this._y = Math.atan2(o, f), this._z = Math.atan2(h, l)) : (this._y = Math.atan2(-u, s), this._z = 0);
        break;
      case "ZXY":
        this._x = Math.asin(rt(d, -1, 1)), Math.abs(d) < 0.9999999 ? (this._y = Math.atan2(-u, f), this._z = Math.atan2(-r, l)) : (this._y = 0, this._z = Math.atan2(h, s));
        break;
      case "ZYX":
        this._y = Math.asin(-rt(u, -1, 1)), Math.abs(u) < 0.9999999 ? (this._x = Math.atan2(d, f), this._z = Math.atan2(h, s)) : (this._x = 0, this._z = Math.atan2(-r, l));
        break;
      case "YZX":
        this._z = Math.asin(rt(h, -1, 1)), Math.abs(h) < 0.9999999 ? (this._x = Math.atan2(-c, l), this._y = Math.atan2(-u, s)) : (this._x = 0, this._y = Math.atan2(o, f));
        break;
      case "XZY":
        this._z = Math.asin(-rt(r, -1, 1)), Math.abs(r) < 0.9999999 ? (this._x = Math.atan2(d, l), this._y = Math.atan2(o, s)) : (this._x = Math.atan2(-c, f), this._y = 0);
        break;
      default:
        console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: " + e);
    }
    return this._order = e, i === !0 && this._onChangeCallback(), this;
  }
  setFromQuaternion(t, e, i) {
    return Ua.makeRotationFromQuaternion(t), this.setFromRotationMatrix(Ua, e, i);
  }
  setFromVector3(t, e = this._order) {
    return this.set(t.x, t.y, t.z, e);
  }
  reorder(t) {
    return ja.setFromEuler(this), this.setFromQuaternion(ja, t);
  }
  equals(t) {
    return t._x === this._x && t._y === this._y && t._z === this._z && t._order === this._order;
  }
  fromArray(t) {
    return this._x = t[0], this._y = t[1], this._z = t[2], t[3] !== void 0 && (this._order = t[3]), this._onChangeCallback(), this;
  }
  toArray(t = [], e = 0) {
    return t[e] = this._x, t[e + 1] = this._y, t[e + 2] = this._z, t[e + 3] = this._order, t;
  }
  _onChange(t) {
    return this._onChangeCallback = t, this;
  }
  _onChangeCallback() {
  }
  *[Symbol.iterator]() {
    yield this._x, yield this._y, yield this._z, yield this._order;
  }
}
Ni.DEFAULT_ORDER = "XYZ";
class Ch {
  constructor() {
    this.mask = 1;
  }
  set(t) {
    this.mask = (1 << t | 0) >>> 0;
  }
  enable(t) {
    this.mask |= 1 << t | 0;
  }
  enableAll() {
    this.mask = -1;
  }
  toggle(t) {
    this.mask ^= 1 << t | 0;
  }
  disable(t) {
    this.mask &= ~(1 << t | 0);
  }
  disableAll() {
    this.mask = 0;
  }
  test(t) {
    return (this.mask & t.mask) !== 0;
  }
  isEnabled(t) {
    return (this.mask & (1 << t | 0)) !== 0;
  }
}
let zc = 0;
const Ha = /* @__PURE__ */ new w(), Be = /* @__PURE__ */ new Q(), Ht = /* @__PURE__ */ new F(), nn = /* @__PURE__ */ new w(), mi = /* @__PURE__ */ new w(), Uc = /* @__PURE__ */ new w(), jc = /* @__PURE__ */ new Q(), $a = /* @__PURE__ */ new w(1, 0, 0), Va = /* @__PURE__ */ new w(0, 1, 0), Wa = /* @__PURE__ */ new w(0, 0, 1), Hc = { type: "added" }, $c = { type: "removed" };
class q extends Ci {
  constructor() {
    super(), this.isObject3D = !0, Object.defineProperty(this, "id", { value: zc++ }), this.uuid = Mt(), this.name = "", this.type = "Object3D", this.parent = null, this.children = [], this.up = q.DEFAULT_UP.clone();
    const t = new w(), e = new Ni(), i = new Q(), n = new w(1, 1, 1);
    function s() {
      i.setFromEuler(e, !1);
    }
    function r() {
      e.setFromQuaternion(i, void 0, !1);
    }
    e._onChange(s), i._onChange(r), Object.defineProperties(this, {
      position: {
        configurable: !0,
        enumerable: !0,
        value: t
      },
      rotation: {
        configurable: !0,
        enumerable: !0,
        value: e
      },
      quaternion: {
        configurable: !0,
        enumerable: !0,
        value: i
      },
      scale: {
        configurable: !0,
        enumerable: !0,
        value: n
      },
      modelViewMatrix: {
        value: new F()
      },
      normalMatrix: {
        value: new Gt()
      }
    }), this.matrix = new F(), this.matrixWorld = new F(), this.matrixAutoUpdate = q.DEFAULT_MATRIX_AUTO_UPDATE, this.matrixWorldNeedsUpdate = !1, this.matrixWorldAutoUpdate = q.DEFAULT_MATRIX_WORLD_AUTO_UPDATE, this.layers = new Ch(), this.visible = !0, this.castShadow = !1, this.receiveShadow = !1, this.frustumCulled = !0, this.renderOrder = 0, this.animations = [], this.userData = {};
  }
  onBeforeRender() {
  }
  onAfterRender() {
  }
  applyMatrix4(t) {
    this.matrixAutoUpdate && this.updateMatrix(), this.matrix.premultiply(t), this.matrix.decompose(this.position, this.quaternion, this.scale);
  }
  applyQuaternion(t) {
    return this.quaternion.premultiply(t), this;
  }
  setRotationFromAxisAngle(t, e) {
    this.quaternion.setFromAxisAngle(t, e);
  }
  setRotationFromEuler(t) {
    this.quaternion.setFromEuler(t, !0);
  }
  setRotationFromMatrix(t) {
    this.quaternion.setFromRotationMatrix(t);
  }
  setRotationFromQuaternion(t) {
    this.quaternion.copy(t);
  }
  rotateOnAxis(t, e) {
    return Be.setFromAxisAngle(t, e), this.quaternion.multiply(Be), this;
  }
  rotateOnWorldAxis(t, e) {
    return Be.setFromAxisAngle(t, e), this.quaternion.premultiply(Be), this;
  }
  rotateX(t) {
    return this.rotateOnAxis($a, t);
  }
  rotateY(t) {
    return this.rotateOnAxis(Va, t);
  }
  rotateZ(t) {
    return this.rotateOnAxis(Wa, t);
  }
  translateOnAxis(t, e) {
    return Ha.copy(t).applyQuaternion(this.quaternion), this.position.add(Ha.multiplyScalar(e)), this;
  }
  translateX(t) {
    return this.translateOnAxis($a, t);
  }
  translateY(t) {
    return this.translateOnAxis(Va, t);
  }
  translateZ(t) {
    return this.translateOnAxis(Wa, t);
  }
  localToWorld(t) {
    return this.updateWorldMatrix(!0, !1), t.applyMatrix4(this.matrixWorld);
  }
  worldToLocal(t) {
    return this.updateWorldMatrix(!0, !1), t.applyMatrix4(Ht.copy(this.matrixWorld).invert());
  }
  lookAt(t, e, i) {
    t.isVector3 ? nn.copy(t) : nn.set(t, e, i);
    const n = this.parent;
    this.updateWorldMatrix(!0, !1), mi.setFromMatrixPosition(this.matrixWorld), this.isCamera || this.isLight ? Ht.lookAt(mi, nn, this.up) : Ht.lookAt(nn, mi, this.up), this.quaternion.setFromRotationMatrix(Ht), n && (Ht.extractRotation(n.matrixWorld), Be.setFromRotationMatrix(Ht), this.quaternion.premultiply(Be.invert()));
  }
  add(t) {
    if (arguments.length > 1) {
      for (let e = 0; e < arguments.length; e++)
        this.add(arguments[e]);
      return this;
    }
    return t === this ? (console.error("THREE.Object3D.add: object can't be added as a child of itself.", t), this) : (t && t.isObject3D ? (t.parent !== null && t.parent.remove(t), t.parent = this, this.children.push(t), t.dispatchEvent(Hc)) : console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.", t), this);
  }
  remove(t) {
    if (arguments.length > 1) {
      for (let i = 0; i < arguments.length; i++)
        this.remove(arguments[i]);
      return this;
    }
    const e = this.children.indexOf(t);
    return e !== -1 && (t.parent = null, this.children.splice(e, 1), t.dispatchEvent($c)), this;
  }
  removeFromParent() {
    const t = this.parent;
    return t !== null && t.remove(this), this;
  }
  clear() {
    return this.remove(...this.children);
  }
  attach(t) {
    return this.updateWorldMatrix(!0, !1), Ht.copy(this.matrixWorld).invert(), t.parent !== null && (t.parent.updateWorldMatrix(!0, !1), Ht.multiply(t.parent.matrixWorld)), t.applyMatrix4(Ht), this.add(t), t.updateWorldMatrix(!1, !0), this;
  }
  getObjectById(t) {
    return this.getObjectByProperty("id", t);
  }
  getObjectByName(t) {
    return this.getObjectByProperty("name", t);
  }
  getObjectByProperty(t, e) {
    if (this[t] === e)
      return this;
    for (let i = 0, n = this.children.length; i < n; i++) {
      const r = this.children[i].getObjectByProperty(t, e);
      if (r !== void 0)
        return r;
    }
  }
  getObjectsByProperty(t, e) {
    let i = [];
    this[t] === e && i.push(this);
    for (let n = 0, s = this.children.length; n < s; n++) {
      const r = this.children[n].getObjectsByProperty(t, e);
      r.length > 0 && (i = i.concat(r));
    }
    return i;
  }
  getWorldPosition(t) {
    return this.updateWorldMatrix(!0, !1), t.setFromMatrixPosition(this.matrixWorld);
  }
  getWorldQuaternion(t) {
    return this.updateWorldMatrix(!0, !1), this.matrixWorld.decompose(mi, t, Uc), t;
  }
  getWorldScale(t) {
    return this.updateWorldMatrix(!0, !1), this.matrixWorld.decompose(mi, jc, t), t;
  }
  getWorldDirection(t) {
    this.updateWorldMatrix(!0, !1);
    const e = this.matrixWorld.elements;
    return t.set(e[8], e[9], e[10]).normalize();
  }
  raycast() {
  }
  traverse(t) {
    t(this);
    const e = this.children;
    for (let i = 0, n = e.length; i < n; i++)
      e[i].traverse(t);
  }
  traverseVisible(t) {
    if (this.visible === !1)
      return;
    t(this);
    const e = this.children;
    for (let i = 0, n = e.length; i < n; i++)
      e[i].traverseVisible(t);
  }
  traverseAncestors(t) {
    const e = this.parent;
    e !== null && (t(e), e.traverseAncestors(t));
  }
  updateMatrix() {
    this.matrix.compose(this.position, this.quaternion, this.scale), this.matrixWorldNeedsUpdate = !0;
  }
  updateMatrixWorld(t) {
    this.matrixAutoUpdate && this.updateMatrix(), (this.matrixWorldNeedsUpdate || t) && (this.parent === null ? this.matrixWorld.copy(this.matrix) : this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix), this.matrixWorldNeedsUpdate = !1, t = !0);
    const e = this.children;
    for (let i = 0, n = e.length; i < n; i++) {
      const s = e[i];
      (s.matrixWorldAutoUpdate === !0 || t === !0) && s.updateMatrixWorld(t);
    }
  }
  updateWorldMatrix(t, e) {
    const i = this.parent;
    if (t === !0 && i !== null && i.matrixWorldAutoUpdate === !0 && i.updateWorldMatrix(!0, !1), this.matrixAutoUpdate && this.updateMatrix(), this.parent === null ? this.matrixWorld.copy(this.matrix) : this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix), e === !0) {
      const n = this.children;
      for (let s = 0, r = n.length; s < r; s++) {
        const o = n[s];
        o.matrixWorldAutoUpdate === !0 && o.updateWorldMatrix(!1, !0);
      }
    }
  }
  toJSON(t) {
    const e = t === void 0 || typeof t == "string", i = {};
    e && (t = {
      geometries: {},
      materials: {},
      textures: {},
      images: {},
      shapes: {},
      skeletons: {},
      animations: {},
      nodes: {}
    }, i.metadata = {
      version: 4.6,
      type: "Object",
      generator: "Object3D.toJSON"
    });
    const n = {};
    n.uuid = this.uuid, n.type = this.type, this.name !== "" && (n.name = this.name), this.castShadow === !0 && (n.castShadow = !0), this.receiveShadow === !0 && (n.receiveShadow = !0), this.visible === !1 && (n.visible = !1), this.frustumCulled === !1 && (n.frustumCulled = !1), this.renderOrder !== 0 && (n.renderOrder = this.renderOrder), Object.keys(this.userData).length > 0 && (n.userData = this.userData), n.layers = this.layers.mask, n.matrix = this.matrix.toArray(), n.up = this.up.toArray(), this.matrixAutoUpdate === !1 && (n.matrixAutoUpdate = !1), this.isInstancedMesh && (n.type = "InstancedMesh", n.count = this.count, n.instanceMatrix = this.instanceMatrix.toJSON(), this.instanceColor !== null && (n.instanceColor = this.instanceColor.toJSON()));
    function s(o, h) {
      return o[h.uuid] === void 0 && (o[h.uuid] = h.toJSON(t)), h.uuid;
    }
    if (this.isScene)
      this.background && (this.background.isColor ? n.background = this.background.toJSON() : this.background.isTexture && (n.background = this.background.toJSON(t).uuid)), this.environment && this.environment.isTexture && this.environment.isRenderTargetTexture !== !0 && (n.environment = this.environment.toJSON(t).uuid);
    else if (this.isMesh || this.isLine || this.isPoints) {
      n.geometry = s(t.geometries, this.geometry);
      const o = this.geometry.parameters;
      if (o !== void 0 && o.shapes !== void 0) {
        const h = o.shapes;
        if (Array.isArray(h))
          for (let l = 0, c = h.length; l < c; l++) {
            const u = h[l];
            s(t.shapes, u);
          }
        else
          s(t.shapes, h);
      }
    }
    if (this.isSkinnedMesh && (n.bindMode = this.bindMode, n.bindMatrix = this.bindMatrix.toArray(), this.skeleton !== void 0 && (s(t.skeletons, this.skeleton), n.skeleton = this.skeleton.uuid)), this.material !== void 0)
      if (Array.isArray(this.material)) {
        const o = [];
        for (let h = 0, l = this.material.length; h < l; h++)
          o.push(s(t.materials, this.material[h]));
        n.material = o;
      } else
        n.material = s(t.materials, this.material);
    if (this.children.length > 0) {
      n.children = [];
      for (let o = 0; o < this.children.length; o++)
        n.children.push(this.children[o].toJSON(t).object);
    }
    if (this.animations.length > 0) {
      n.animations = [];
      for (let o = 0; o < this.animations.length; o++) {
        const h = this.animations[o];
        n.animations.push(s(t.animations, h));
      }
    }
    if (e) {
      const o = r(t.geometries), h = r(t.materials), l = r(t.textures), c = r(t.images), u = r(t.shapes), d = r(t.skeletons), f = r(t.animations), p = r(t.nodes);
      o.length > 0 && (i.geometries = o), h.length > 0 && (i.materials = h), l.length > 0 && (i.textures = l), c.length > 0 && (i.images = c), u.length > 0 && (i.shapes = u), d.length > 0 && (i.skeletons = d), f.length > 0 && (i.animations = f), p.length > 0 && (i.nodes = p);
    }
    return i.object = n, i;
    function r(o) {
      const h = [];
      for (const l in o) {
        const c = o[l];
        delete c.metadata, h.push(c);
      }
      return h;
    }
  }
  clone(t) {
    return new this.constructor().copy(this, t);
  }
  copy(t, e = !0) {
    if (this.name = t.name, this.up.copy(t.up), this.position.copy(t.position), this.rotation.order = t.rotation.order, this.quaternion.copy(t.quaternion), this.scale.copy(t.scale), this.matrix.copy(t.matrix), this.matrixWorld.copy(t.matrixWorld), this.matrixAutoUpdate = t.matrixAutoUpdate, this.matrixWorldNeedsUpdate = t.matrixWorldNeedsUpdate, this.matrixWorldAutoUpdate = t.matrixWorldAutoUpdate, this.layers.mask = t.layers.mask, this.visible = t.visible, this.castShadow = t.castShadow, this.receiveShadow = t.receiveShadow, this.frustumCulled = t.frustumCulled, this.renderOrder = t.renderOrder, this.animations = t.animations.slice(), this.userData = JSON.parse(JSON.stringify(t.userData)), e === !0)
      for (let i = 0; i < t.children.length; i++) {
        const n = t.children[i];
        this.add(n.clone());
      }
    return this;
  }
}
q.DEFAULT_UP = /* @__PURE__ */ new w(0, 1, 0);
q.DEFAULT_MATRIX_AUTO_UPDATE = !0;
q.DEFAULT_MATRIX_WORLD_AUTO_UPDATE = !0;
const wt = /* @__PURE__ */ new w(), $t = /* @__PURE__ */ new w(), ps = /* @__PURE__ */ new w(), Vt = /* @__PURE__ */ new w(), Fe = /* @__PURE__ */ new w(), ke = /* @__PURE__ */ new w(), qa = /* @__PURE__ */ new w(), ms = /* @__PURE__ */ new w(), ys = /* @__PURE__ */ new w(), gs = /* @__PURE__ */ new w();
let sn = !1;
class vt {
  constructor(t = new w(), e = new w(), i = new w()) {
    this.a = t, this.b = e, this.c = i;
  }
  static getNormal(t, e, i, n) {
    n.subVectors(i, e), wt.subVectors(t, e), n.cross(wt);
    const s = n.lengthSq();
    return s > 0 ? n.multiplyScalar(1 / Math.sqrt(s)) : n.set(0, 0, 0);
  }
  // static/instance method to calculate barycentric coordinates
  // based on: http://www.blackpawn.com/texts/pointinpoly/default.html
  static getBarycoord(t, e, i, n, s) {
    wt.subVectors(n, e), $t.subVectors(i, e), ps.subVectors(t, e);
    const r = wt.dot(wt), o = wt.dot($t), h = wt.dot(ps), l = $t.dot($t), c = $t.dot(ps), u = r * l - o * o;
    if (u === 0)
      return s.set(-2, -1, -1);
    const d = 1 / u, f = (l * h - o * c) * d, p = (r * c - o * h) * d;
    return s.set(1 - f - p, p, f);
  }
  static containsPoint(t, e, i, n) {
    return this.getBarycoord(t, e, i, n, Vt), Vt.x >= 0 && Vt.y >= 0 && Vt.x + Vt.y <= 1;
  }
  static getUV(t, e, i, n, s, r, o, h) {
    return sn === !1 && (console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."), sn = !0), this.getInterpolation(t, e, i, n, s, r, o, h);
  }
  static getInterpolation(t, e, i, n, s, r, o, h) {
    return this.getBarycoord(t, e, i, n, Vt), h.setScalar(0), h.addScaledVector(s, Vt.x), h.addScaledVector(r, Vt.y), h.addScaledVector(o, Vt.z), h;
  }
  static isFrontFacing(t, e, i, n) {
    return wt.subVectors(i, e), $t.subVectors(t, e), wt.cross($t).dot(n) < 0;
  }
  set(t, e, i) {
    return this.a.copy(t), this.b.copy(e), this.c.copy(i), this;
  }
  setFromPointsAndIndices(t, e, i, n) {
    return this.a.copy(t[e]), this.b.copy(t[i]), this.c.copy(t[n]), this;
  }
  setFromAttributeAndIndices(t, e, i, n) {
    return this.a.fromBufferAttribute(t, e), this.b.fromBufferAttribute(t, i), this.c.fromBufferAttribute(t, n), this;
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    return this.a.copy(t.a), this.b.copy(t.b), this.c.copy(t.c), this;
  }
  getArea() {
    return wt.subVectors(this.c, this.b), $t.subVectors(this.a, this.b), wt.cross($t).length() * 0.5;
  }
  getMidpoint(t) {
    return t.addVectors(this.a, this.b).add(this.c).multiplyScalar(1 / 3);
  }
  getNormal(t) {
    return vt.getNormal(this.a, this.b, this.c, t);
  }
  getPlane(t) {
    return t.setFromCoplanarPoints(this.a, this.b, this.c);
  }
  getBarycoord(t, e) {
    return vt.getBarycoord(t, this.a, this.b, this.c, e);
  }
  getUV(t, e, i, n, s) {
    return sn === !1 && (console.warn("THREE.Triangle.getUV() has been renamed to THREE.Triangle.getInterpolation()."), sn = !0), vt.getInterpolation(t, this.a, this.b, this.c, e, i, n, s);
  }
  getInterpolation(t, e, i, n, s) {
    return vt.getInterpolation(t, this.a, this.b, this.c, e, i, n, s);
  }
  containsPoint(t) {
    return vt.containsPoint(t, this.a, this.b, this.c);
  }
  isFrontFacing(t) {
    return vt.isFrontFacing(this.a, this.b, this.c, t);
  }
  intersectsBox(t) {
    return t.intersectsTriangle(this);
  }
  closestPointToPoint(t, e) {
    const i = this.a, n = this.b, s = this.c;
    let r, o;
    Fe.subVectors(n, i), ke.subVectors(s, i), ms.subVectors(t, i);
    const h = Fe.dot(ms), l = ke.dot(ms);
    if (h <= 0 && l <= 0)
      return e.copy(i);
    ys.subVectors(t, n);
    const c = Fe.dot(ys), u = ke.dot(ys);
    if (c >= 0 && u <= c)
      return e.copy(n);
    const d = h * u - c * l;
    if (d <= 0 && h >= 0 && c <= 0)
      return r = h / (h - c), e.copy(i).addScaledVector(Fe, r);
    gs.subVectors(t, s);
    const f = Fe.dot(gs), p = ke.dot(gs);
    if (p >= 0 && f <= p)
      return e.copy(s);
    const y = f * l - h * p;
    if (y <= 0 && l >= 0 && p <= 0)
      return o = l / (l - p), e.copy(i).addScaledVector(ke, o);
    const m = c * p - f * u;
    if (m <= 0 && u - c >= 0 && f - p >= 0)
      return qa.subVectors(s, n), o = (u - c) / (u - c + (f - p)), e.copy(n).addScaledVector(qa, o);
    const _ = 1 / (m + y + d);
    return r = y * _, o = d * _, e.copy(i).addScaledVector(Fe, r).addScaledVector(ke, o);
  }
  equals(t) {
    return t.a.equals(this.a) && t.b.equals(this.b) && t.c.equals(this.c);
  }
}
let Vc = 0;
class Ee extends Ci {
  constructor() {
    super(), this.isMaterial = !0, Object.defineProperty(this, "id", { value: Vc++ }), this.uuid = Mt(), this.name = "", this.type = "Material", this.blending = Ca, this.side = Dn, this.vertexColors = !1, this.opacity = 1, this.transparent = !1, this.alphaHash = !1, this.blendSrc = Ql, this.blendDst = tc, this.blendEquation = Zl, this.blendSrcAlpha = null, this.blendDstAlpha = null, this.blendEquationAlpha = null, this.depthFunc = ec, this.depthTest = !0, this.depthWrite = !0, this.stencilWriteMask = 255, this.stencilFunc = pc, this.stencilRef = 0, this.stencilFuncMask = 255, this.stencilFail = ns, this.stencilZFail = ns, this.stencilZPass = ns, this.stencilWrite = !1, this.clippingPlanes = null, this.clipIntersection = !1, this.clipShadows = !1, this.shadowSide = null, this.colorWrite = !0, this.precision = null, this.polygonOffset = !1, this.polygonOffsetFactor = 0, this.polygonOffsetUnits = 0, this.dithering = !1, this.alphaToCoverage = !1, this.premultipliedAlpha = !1, this.forceSinglePass = !1, this.visible = !0, this.toneMapped = !0, this.userData = {}, this.version = 0, this._alphaTest = 0;
  }
  get alphaTest() {
    return this._alphaTest;
  }
  set alphaTest(t) {
    this._alphaTest > 0 != t > 0 && this.version++, this._alphaTest = t;
  }
  onBuild() {
  }
  onBeforeRender() {
  }
  onBeforeCompile() {
  }
  customProgramCacheKey() {
    return this.onBeforeCompile.toString();
  }
  setValues(t) {
    if (t !== void 0)
      for (const e in t) {
        const i = t[e];
        if (i === void 0) {
          console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);
          continue;
        }
        const n = this[e];
        if (n === void 0) {
          console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);
          continue;
        }
        n && n.isColor ? n.set(i) : n && n.isVector3 && i && i.isVector3 ? n.copy(i) : this[e] = i;
      }
  }
  toJSON(t) {
    const e = t === void 0 || typeof t == "string";
    e && (t = {
      textures: {},
      images: {}
    });
    const i = {
      metadata: {
        version: 4.6,
        type: "Material",
        generator: "Material.toJSON"
      }
    };
    i.uuid = this.uuid, i.type = this.type, this.name !== "" && (i.name = this.name), this.color && this.color.isColor && (i.color = this.color.getHex()), this.roughness !== void 0 && (i.roughness = this.roughness), this.metalness !== void 0 && (i.metalness = this.metalness), this.sheen !== void 0 && (i.sheen = this.sheen), this.sheenColor && this.sheenColor.isColor && (i.sheenColor = this.sheenColor.getHex()), this.sheenRoughness !== void 0 && (i.sheenRoughness = this.sheenRoughness), this.emissive && this.emissive.isColor && (i.emissive = this.emissive.getHex()), this.emissiveIntensity && this.emissiveIntensity !== 1 && (i.emissiveIntensity = this.emissiveIntensity), this.specular && this.specular.isColor && (i.specular = this.specular.getHex()), this.specularIntensity !== void 0 && (i.specularIntensity = this.specularIntensity), this.specularColor && this.specularColor.isColor && (i.specularColor = this.specularColor.getHex()), this.shininess !== void 0 && (i.shininess = this.shininess), this.clearcoat !== void 0 && (i.clearcoat = this.clearcoat), this.clearcoatRoughness !== void 0 && (i.clearcoatRoughness = this.clearcoatRoughness), this.clearcoatMap && this.clearcoatMap.isTexture && (i.clearcoatMap = this.clearcoatMap.toJSON(t).uuid), this.clearcoatRoughnessMap && this.clearcoatRoughnessMap.isTexture && (i.clearcoatRoughnessMap = this.clearcoatRoughnessMap.toJSON(t).uuid), this.clearcoatNormalMap && this.clearcoatNormalMap.isTexture && (i.clearcoatNormalMap = this.clearcoatNormalMap.toJSON(t).uuid, i.clearcoatNormalScale = this.clearcoatNormalScale.toArray()), this.iridescence !== void 0 && (i.iridescence = this.iridescence), this.iridescenceIOR !== void 0 && (i.iridescenceIOR = this.iridescenceIOR), this.iridescenceThicknessRange !== void 0 && (i.iridescenceThicknessRange = this.iridescenceThicknessRange), this.iridescenceMap && this.iridescenceMap.isTexture && (i.iridescenceMap = this.iridescenceMap.toJSON(t).uuid), this.iridescenceThicknessMap && this.iridescenceThicknessMap.isTexture && (i.iridescenceThicknessMap = this.iridescenceThicknessMap.toJSON(t).uuid), this.anisotropy !== void 0 && (i.anisotropy = this.anisotropy), this.anisotropyRotation !== void 0 && (i.anisotropyRotation = this.anisotropyRotation), this.anisotropyMap && this.anisotropyMap.isTexture && (i.anisotropyMap = this.anisotropyMap.toJSON(t).uuid), this.map && this.map.isTexture && (i.map = this.map.toJSON(t).uuid), this.matcap && this.matcap.isTexture && (i.matcap = this.matcap.toJSON(t).uuid), this.alphaMap && this.alphaMap.isTexture && (i.alphaMap = this.alphaMap.toJSON(t).uuid), this.lightMap && this.lightMap.isTexture && (i.lightMap = this.lightMap.toJSON(t).uuid, i.lightMapIntensity = this.lightMapIntensity), this.aoMap && this.aoMap.isTexture && (i.aoMap = this.aoMap.toJSON(t).uuid, i.aoMapIntensity = this.aoMapIntensity), this.bumpMap && this.bumpMap.isTexture && (i.bumpMap = this.bumpMap.toJSON(t).uuid, i.bumpScale = this.bumpScale), this.normalMap && this.normalMap.isTexture && (i.normalMap = this.normalMap.toJSON(t).uuid, i.normalMapType = this.normalMapType, i.normalScale = this.normalScale.toArray()), this.displacementMap && this.displacementMap.isTexture && (i.displacementMap = this.displacementMap.toJSON(t).uuid, i.displacementScale = this.displacementScale, i.displacementBias = this.displacementBias), this.roughnessMap && this.roughnessMap.isTexture && (i.roughnessMap = this.roughnessMap.toJSON(t).uuid), this.metalnessMap && this.metalnessMap.isTexture && (i.metalnessMap = this.metalnessMap.toJSON(t).uuid), this.emissiveMap && this.emissiveMap.isTexture && (i.emissiveMap = this.emissiveMap.toJSON(t).uuid), this.specularMap && this.specularMap.isTexture && (i.specularMap = this.specularMap.toJSON(t).uuid), this.specularIntensityMap && this.specularIntensityMap.isTexture && (i.specularIntensityMap = this.specularIntensityMap.toJSON(t).uuid), this.specularColorMap && this.specularColorMap.isTexture && (i.specularColorMap = this.specularColorMap.toJSON(t).uuid), this.envMap && this.envMap.isTexture && (i.envMap = this.envMap.toJSON(t).uuid, this.combine !== void 0 && (i.combine = this.combine)), this.envMapIntensity !== void 0 && (i.envMapIntensity = this.envMapIntensity), this.reflectivity !== void 0 && (i.reflectivity = this.reflectivity), this.refractionRatio !== void 0 && (i.refractionRatio = this.refractionRatio), this.gradientMap && this.gradientMap.isTexture && (i.gradientMap = this.gradientMap.toJSON(t).uuid), this.transmission !== void 0 && (i.transmission = this.transmission), this.transmissionMap && this.transmissionMap.isTexture && (i.transmissionMap = this.transmissionMap.toJSON(t).uuid), this.thickness !== void 0 && (i.thickness = this.thickness), this.thicknessMap && this.thicknessMap.isTexture && (i.thicknessMap = this.thicknessMap.toJSON(t).uuid), this.attenuationDistance !== void 0 && this.attenuationDistance !== 1 / 0 && (i.attenuationDistance = this.attenuationDistance), this.attenuationColor !== void 0 && (i.attenuationColor = this.attenuationColor.getHex()), this.size !== void 0 && (i.size = this.size), this.shadowSide !== null && (i.shadowSide = this.shadowSide), this.sizeAttenuation !== void 0 && (i.sizeAttenuation = this.sizeAttenuation), this.blending !== Ca && (i.blending = this.blending), this.side !== Dn && (i.side = this.side), this.vertexColors === !0 && (i.vertexColors = !0), this.opacity < 1 && (i.opacity = this.opacity), this.transparent === !0 && (i.transparent = !0), i.depthFunc = this.depthFunc, i.depthTest = this.depthTest, i.depthWrite = this.depthWrite, i.colorWrite = this.colorWrite, i.stencilWrite = this.stencilWrite, i.stencilWriteMask = this.stencilWriteMask, i.stencilFunc = this.stencilFunc, i.stencilRef = this.stencilRef, i.stencilFuncMask = this.stencilFuncMask, i.stencilFail = this.stencilFail, i.stencilZFail = this.stencilZFail, i.stencilZPass = this.stencilZPass, this.rotation !== void 0 && this.rotation !== 0 && (i.rotation = this.rotation), this.polygonOffset === !0 && (i.polygonOffset = !0), this.polygonOffsetFactor !== 0 && (i.polygonOffsetFactor = this.polygonOffsetFactor), this.polygonOffsetUnits !== 0 && (i.polygonOffsetUnits = this.polygonOffsetUnits), this.linewidth !== void 0 && this.linewidth !== 1 && (i.linewidth = this.linewidth), this.dashSize !== void 0 && (i.dashSize = this.dashSize), this.gapSize !== void 0 && (i.gapSize = this.gapSize), this.scale !== void 0 && (i.scale = this.scale), this.dithering === !0 && (i.dithering = !0), this.alphaTest > 0 && (i.alphaTest = this.alphaTest), this.alphaHash === !0 && (i.alphaHash = !0), this.alphaToCoverage === !0 && (i.alphaToCoverage = !0), this.premultipliedAlpha === !0 && (i.premultipliedAlpha = !0), this.forceSinglePass === !0 && (i.forceSinglePass = !0), this.wireframe === !0 && (i.wireframe = !0), this.wireframeLinewidth > 1 && (i.wireframeLinewidth = this.wireframeLinewidth), this.wireframeLinecap !== "round" && (i.wireframeLinecap = this.wireframeLinecap), this.wireframeLinejoin !== "round" && (i.wireframeLinejoin = this.wireframeLinejoin), this.flatShading === !0 && (i.flatShading = !0), this.visible === !1 && (i.visible = !1), this.toneMapped === !1 && (i.toneMapped = !1), this.fog === !1 && (i.fog = !1), Object.keys(this.userData).length > 0 && (i.userData = this.userData);
    function n(s) {
      const r = [];
      for (const o in s) {
        const h = s[o];
        delete h.metadata, r.push(h);
      }
      return r;
    }
    if (e) {
      const s = n(t.textures), r = n(t.images);
      s.length > 0 && (i.textures = s), r.length > 0 && (i.images = r);
    }
    return i;
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    this.name = t.name, this.blending = t.blending, this.side = t.side, this.vertexColors = t.vertexColors, this.opacity = t.opacity, this.transparent = t.transparent, this.blendSrc = t.blendSrc, this.blendDst = t.blendDst, this.blendEquation = t.blendEquation, this.blendSrcAlpha = t.blendSrcAlpha, this.blendDstAlpha = t.blendDstAlpha, this.blendEquationAlpha = t.blendEquationAlpha, this.depthFunc = t.depthFunc, this.depthTest = t.depthTest, this.depthWrite = t.depthWrite, this.stencilWriteMask = t.stencilWriteMask, this.stencilFunc = t.stencilFunc, this.stencilRef = t.stencilRef, this.stencilFuncMask = t.stencilFuncMask, this.stencilFail = t.stencilFail, this.stencilZFail = t.stencilZFail, this.stencilZPass = t.stencilZPass, this.stencilWrite = t.stencilWrite;
    const e = t.clippingPlanes;
    let i = null;
    if (e !== null) {
      const n = e.length;
      i = new Array(n);
      for (let s = 0; s !== n; ++s)
        i[s] = e[s].clone();
    }
    return this.clippingPlanes = i, this.clipIntersection = t.clipIntersection, this.clipShadows = t.clipShadows, this.shadowSide = t.shadowSide, this.colorWrite = t.colorWrite, this.precision = t.precision, this.polygonOffset = t.polygonOffset, this.polygonOffsetFactor = t.polygonOffsetFactor, this.polygonOffsetUnits = t.polygonOffsetUnits, this.dithering = t.dithering, this.alphaTest = t.alphaTest, this.alphaHash = t.alphaHash, this.alphaToCoverage = t.alphaToCoverage, this.premultipliedAlpha = t.premultipliedAlpha, this.forceSinglePass = t.forceSinglePass, this.visible = t.visible, this.toneMapped = t.toneMapped, this.userData = JSON.parse(JSON.stringify(t.userData)), this;
  }
  dispose() {
    this.dispatchEvent({ type: "dispose" });
  }
  set needsUpdate(t) {
    t === !0 && this.version++;
  }
}
const Oh = {
  aliceblue: 15792383,
  antiquewhite: 16444375,
  aqua: 65535,
  aquamarine: 8388564,
  azure: 15794175,
  beige: 16119260,
  bisque: 16770244,
  black: 0,
  blanchedalmond: 16772045,
  blue: 255,
  blueviolet: 9055202,
  brown: 10824234,
  burlywood: 14596231,
  cadetblue: 6266528,
  chartreuse: 8388352,
  chocolate: 13789470,
  coral: 16744272,
  cornflowerblue: 6591981,
  cornsilk: 16775388,
  crimson: 14423100,
  cyan: 65535,
  darkblue: 139,
  darkcyan: 35723,
  darkgoldenrod: 12092939,
  darkgray: 11119017,
  darkgreen: 25600,
  darkgrey: 11119017,
  darkkhaki: 12433259,
  darkmagenta: 9109643,
  darkolivegreen: 5597999,
  darkorange: 16747520,
  darkorchid: 10040012,
  darkred: 9109504,
  darksalmon: 15308410,
  darkseagreen: 9419919,
  darkslateblue: 4734347,
  darkslategray: 3100495,
  darkslategrey: 3100495,
  darkturquoise: 52945,
  darkviolet: 9699539,
  deeppink: 16716947,
  deepskyblue: 49151,
  dimgray: 6908265,
  dimgrey: 6908265,
  dodgerblue: 2003199,
  firebrick: 11674146,
  floralwhite: 16775920,
  forestgreen: 2263842,
  fuchsia: 16711935,
  gainsboro: 14474460,
  ghostwhite: 16316671,
  gold: 16766720,
  goldenrod: 14329120,
  gray: 8421504,
  green: 32768,
  greenyellow: 11403055,
  grey: 8421504,
  honeydew: 15794160,
  hotpink: 16738740,
  indianred: 13458524,
  indigo: 4915330,
  ivory: 16777200,
  khaki: 15787660,
  lavender: 15132410,
  lavenderblush: 16773365,
  lawngreen: 8190976,
  lemonchiffon: 16775885,
  lightblue: 11393254,
  lightcoral: 15761536,
  lightcyan: 14745599,
  lightgoldenrodyellow: 16448210,
  lightgray: 13882323,
  lightgreen: 9498256,
  lightgrey: 13882323,
  lightpink: 16758465,
  lightsalmon: 16752762,
  lightseagreen: 2142890,
  lightskyblue: 8900346,
  lightslategray: 7833753,
  lightslategrey: 7833753,
  lightsteelblue: 11584734,
  lightyellow: 16777184,
  lime: 65280,
  limegreen: 3329330,
  linen: 16445670,
  magenta: 16711935,
  maroon: 8388608,
  mediumaquamarine: 6737322,
  mediumblue: 205,
  mediumorchid: 12211667,
  mediumpurple: 9662683,
  mediumseagreen: 3978097,
  mediumslateblue: 8087790,
  mediumspringgreen: 64154,
  mediumturquoise: 4772300,
  mediumvioletred: 13047173,
  midnightblue: 1644912,
  mintcream: 16121850,
  mistyrose: 16770273,
  moccasin: 16770229,
  navajowhite: 16768685,
  navy: 128,
  oldlace: 16643558,
  olive: 8421376,
  olivedrab: 7048739,
  orange: 16753920,
  orangered: 16729344,
  orchid: 14315734,
  palegoldenrod: 15657130,
  palegreen: 10025880,
  paleturquoise: 11529966,
  palevioletred: 14381203,
  papayawhip: 16773077,
  peachpuff: 16767673,
  peru: 13468991,
  pink: 16761035,
  plum: 14524637,
  powderblue: 11591910,
  purple: 8388736,
  rebeccapurple: 6697881,
  red: 16711680,
  rosybrown: 12357519,
  royalblue: 4286945,
  saddlebrown: 9127187,
  salmon: 16416882,
  sandybrown: 16032864,
  seagreen: 3050327,
  seashell: 16774638,
  sienna: 10506797,
  silver: 12632256,
  skyblue: 8900331,
  slateblue: 6970061,
  slategray: 7372944,
  slategrey: 7372944,
  snow: 16775930,
  springgreen: 65407,
  steelblue: 4620980,
  tan: 13808780,
  teal: 32896,
  thistle: 14204888,
  tomato: 16737095,
  turquoise: 4251856,
  violet: 15631086,
  wheat: 16113331,
  white: 16777215,
  whitesmoke: 16119285,
  yellow: 16776960,
  yellowgreen: 10145074
}, ie = { h: 0, s: 0, l: 0 }, rn = { h: 0, s: 0, l: 0 };
function _s(a, t, e) {
  return e < 0 && (e += 1), e > 1 && (e -= 1), e < 1 / 6 ? a + (t - a) * 6 * e : e < 1 / 2 ? t : e < 2 / 3 ? a + (t - a) * 6 * (2 / 3 - e) : a;
}
class J {
  constructor(t, e, i) {
    return this.isColor = !0, this.r = 1, this.g = 1, this.b = 1, this.set(t, e, i);
  }
  set(t, e, i) {
    if (e === void 0 && i === void 0) {
      const n = t;
      n && n.isColor ? this.copy(n) : typeof n == "number" ? this.setHex(n) : typeof n == "string" && this.setStyle(n);
    } else
      this.setRGB(t, e, i);
    return this;
  }
  setScalar(t) {
    return this.r = t, this.g = t, this.b = t, this;
  }
  setHex(t, e = st) {
    return t = Math.floor(t), this.r = (t >> 16 & 255) / 255, this.g = (t >> 8 & 255) / 255, this.b = (t & 255) / 255, mt.toWorkingColorSpace(this, e), this;
  }
  setRGB(t, e, i, n = mt.workingColorSpace) {
    return this.r = t, this.g = e, this.b = i, mt.toWorkingColorSpace(this, n), this;
  }
  setHSL(t, e, i, n = mt.workingColorSpace) {
    if (t = jr(t, 1), e = rt(e, 0, 1), i = rt(i, 0, 1), e === 0)
      this.r = this.g = this.b = i;
    else {
      const s = i <= 0.5 ? i * (1 + e) : i + e - i * e, r = 2 * i - s;
      this.r = _s(r, s, t + 1 / 3), this.g = _s(r, s, t), this.b = _s(r, s, t - 1 / 3);
    }
    return mt.toWorkingColorSpace(this, n), this;
  }
  setStyle(t, e = st) {
    function i(s) {
      s !== void 0 && parseFloat(s) < 1 && console.warn("THREE.Color: Alpha component of " + t + " will be ignored.");
    }
    let n;
    if (n = /^(\w+)\(([^\)]*)\)/.exec(t)) {
      let s;
      const r = n[1], o = n[2];
      switch (r) {
        case "rgb":
        case "rgba":
          if (s = /^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))
            return i(s[4]), this.setRGB(
              Math.min(255, parseInt(s[1], 10)) / 255,
              Math.min(255, parseInt(s[2], 10)) / 255,
              Math.min(255, parseInt(s[3], 10)) / 255,
              e
            );
          if (s = /^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))
            return i(s[4]), this.setRGB(
              Math.min(100, parseInt(s[1], 10)) / 100,
              Math.min(100, parseInt(s[2], 10)) / 100,
              Math.min(100, parseInt(s[3], 10)) / 100,
              e
            );
          break;
        case "hsl":
        case "hsla":
          if (s = /^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))
            return i(s[4]), this.setHSL(
              parseFloat(s[1]) / 360,
              parseFloat(s[2]) / 100,
              parseFloat(s[3]) / 100,
              e
            );
          break;
        default:
          console.warn("THREE.Color: Unknown color model " + t);
      }
    } else if (n = /^\#([A-Fa-f\d]+)$/.exec(t)) {
      const s = n[1], r = s.length;
      if (r === 3)
        return this.setRGB(
          parseInt(s.charAt(0), 16) / 15,
          parseInt(s.charAt(1), 16) / 15,
          parseInt(s.charAt(2), 16) / 15,
          e
        );
      if (r === 6)
        return this.setHex(parseInt(s, 16), e);
      console.warn("THREE.Color: Invalid hex color " + t);
    } else if (t && t.length > 0)
      return this.setColorName(t, e);
    return this;
  }
  setColorName(t, e = st) {
    const i = Oh[t.toLowerCase()];
    return i !== void 0 ? this.setHex(i, e) : console.warn("THREE.Color: Unknown color " + t), this;
  }
  clone() {
    return new this.constructor(this.r, this.g, this.b);
  }
  copy(t) {
    return this.r = t.r, this.g = t.g, this.b = t.b, this;
  }
  copySRGBToLinear(t) {
    return this.r = Je(t.r), this.g = Je(t.g), this.b = Je(t.b), this;
  }
  copyLinearToSRGB(t) {
    return this.r = as(t.r), this.g = as(t.g), this.b = as(t.b), this;
  }
  convertSRGBToLinear() {
    return this.copySRGBToLinear(this), this;
  }
  convertLinearToSRGB() {
    return this.copyLinearToSRGB(this), this;
  }
  getHex(t = st) {
    return mt.fromWorkingColorSpace(nt.copy(this), t), Math.round(rt(nt.r * 255, 0, 255)) * 65536 + Math.round(rt(nt.g * 255, 0, 255)) * 256 + Math.round(rt(nt.b * 255, 0, 255));
  }
  getHexString(t = st) {
    return ("000000" + this.getHex(t).toString(16)).slice(-6);
  }
  getHSL(t, e = mt.workingColorSpace) {
    mt.fromWorkingColorSpace(nt.copy(this), e);
    const i = nt.r, n = nt.g, s = nt.b, r = Math.max(i, n, s), o = Math.min(i, n, s);
    let h, l;
    const c = (o + r) / 2;
    if (o === r)
      h = 0, l = 0;
    else {
      const u = r - o;
      switch (l = c <= 0.5 ? u / (r + o) : u / (2 - r - o), r) {
        case i:
          h = (n - s) / u + (n < s ? 6 : 0);
          break;
        case n:
          h = (s - i) / u + 2;
          break;
        case s:
          h = (i - n) / u + 4;
          break;
      }
      h /= 6;
    }
    return t.h = h, t.s = l, t.l = c, t;
  }
  getRGB(t, e = mt.workingColorSpace) {
    return mt.fromWorkingColorSpace(nt.copy(this), e), t.r = nt.r, t.g = nt.g, t.b = nt.b, t;
  }
  getStyle(t = st) {
    mt.fromWorkingColorSpace(nt.copy(this), t);
    const e = nt.r, i = nt.g, n = nt.b;
    return t !== st ? `color(${t} ${e.toFixed(3)} ${i.toFixed(3)} ${n.toFixed(3)})` : `rgb(${Math.round(e * 255)},${Math.round(i * 255)},${Math.round(n * 255)})`;
  }
  offsetHSL(t, e, i) {
    return this.getHSL(ie), this.setHSL(ie.h + t, ie.s + e, ie.l + i);
  }
  add(t) {
    return this.r += t.r, this.g += t.g, this.b += t.b, this;
  }
  addColors(t, e) {
    return this.r = t.r + e.r, this.g = t.g + e.g, this.b = t.b + e.b, this;
  }
  addScalar(t) {
    return this.r += t, this.g += t, this.b += t, this;
  }
  sub(t) {
    return this.r = Math.max(0, this.r - t.r), this.g = Math.max(0, this.g - t.g), this.b = Math.max(0, this.b - t.b), this;
  }
  multiply(t) {
    return this.r *= t.r, this.g *= t.g, this.b *= t.b, this;
  }
  multiplyScalar(t) {
    return this.r *= t, this.g *= t, this.b *= t, this;
  }
  lerp(t, e) {
    return this.r += (t.r - this.r) * e, this.g += (t.g - this.g) * e, this.b += (t.b - this.b) * e, this;
  }
  lerpColors(t, e, i) {
    return this.r = t.r + (e.r - t.r) * i, this.g = t.g + (e.g - t.g) * i, this.b = t.b + (e.b - t.b) * i, this;
  }
  lerpHSL(t, e) {
    this.getHSL(ie), t.getHSL(rn);
    const i = Ei(ie.h, rn.h, e), n = Ei(ie.s, rn.s, e), s = Ei(ie.l, rn.l, e);
    return this.setHSL(i, n, s), this;
  }
  setFromVector3(t) {
    return this.r = t.x, this.g = t.y, this.b = t.z, this;
  }
  applyMatrix3(t) {
    const e = this.r, i = this.g, n = this.b, s = t.elements;
    return this.r = s[0] * e + s[3] * i + s[6] * n, this.g = s[1] * e + s[4] * i + s[7] * n, this.b = s[2] * e + s[5] * i + s[8] * n, this;
  }
  equals(t) {
    return t.r === this.r && t.g === this.g && t.b === this.b;
  }
  fromArray(t, e = 0) {
    return this.r = t[e], this.g = t[e + 1], this.b = t[e + 2], this;
  }
  toArray(t = [], e = 0) {
    return t[e] = this.r, t[e + 1] = this.g, t[e + 2] = this.b, t;
  }
  fromBufferAttribute(t, e) {
    return this.r = t.getX(e), this.g = t.getY(e), this.b = t.getZ(e), this;
  }
  toJSON() {
    return this.getHex();
  }
  *[Symbol.iterator]() {
    yield this.r, yield this.g, yield this.b;
  }
}
const nt = /* @__PURE__ */ new J();
J.NAMES = Oh;
class ce extends Ee {
  constructor(t) {
    super(), this.isMeshBasicMaterial = !0, this.type = "MeshBasicMaterial", this.color = new J(16777215), this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.specularMap = null, this.alphaMap = null, this.envMap = null, this.combine = ic, this.reflectivity = 1, this.refractionRatio = 0.98, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.fog = !0, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.specularMap = t.specularMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.combine = t.combine, this.reflectivity = t.reflectivity, this.refractionRatio = t.refractionRatio, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.fog = t.fog, this;
  }
}
const K = /* @__PURE__ */ new w(), an = /* @__PURE__ */ new G();
class Tt {
  constructor(t, e, i = !1) {
    if (Array.isArray(t))
      throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");
    this.isBufferAttribute = !0, this.name = "", this.array = t, this.itemSize = e, this.count = t !== void 0 ? t.length / e : 0, this.normalized = i, this.usage = rr, this.updateRange = { offset: 0, count: -1 }, this.gpuType = Eh, this.version = 0;
  }
  onUploadCallback() {
  }
  set needsUpdate(t) {
    t === !0 && this.version++;
  }
  setUsage(t) {
    return this.usage = t, this;
  }
  copy(t) {
    return this.name = t.name, this.array = new t.array.constructor(t.array), this.itemSize = t.itemSize, this.count = t.count, this.normalized = t.normalized, this.usage = t.usage, this.gpuType = t.gpuType, this;
  }
  copyAt(t, e, i) {
    t *= this.itemSize, i *= e.itemSize;
    for (let n = 0, s = this.itemSize; n < s; n++)
      this.array[t + n] = e.array[i + n];
    return this;
  }
  copyArray(t) {
    return this.array.set(t), this;
  }
  applyMatrix3(t) {
    if (this.itemSize === 2)
      for (let e = 0, i = this.count; e < i; e++)
        an.fromBufferAttribute(this, e), an.applyMatrix3(t), this.setXY(e, an.x, an.y);
    else if (this.itemSize === 3)
      for (let e = 0, i = this.count; e < i; e++)
        K.fromBufferAttribute(this, e), K.applyMatrix3(t), this.setXYZ(e, K.x, K.y, K.z);
    return this;
  }
  applyMatrix4(t) {
    for (let e = 0, i = this.count; e < i; e++)
      K.fromBufferAttribute(this, e), K.applyMatrix4(t), this.setXYZ(e, K.x, K.y, K.z);
    return this;
  }
  applyNormalMatrix(t) {
    for (let e = 0, i = this.count; e < i; e++)
      K.fromBufferAttribute(this, e), K.applyNormalMatrix(t), this.setXYZ(e, K.x, K.y, K.z);
    return this;
  }
  transformDirection(t) {
    for (let e = 0, i = this.count; e < i; e++)
      K.fromBufferAttribute(this, e), K.transformDirection(t), this.setXYZ(e, K.x, K.y, K.z);
    return this;
  }
  set(t, e = 0) {
    return this.array.set(t, e), this;
  }
  getComponent(t, e) {
    let i = this.array[t * this.itemSize + e];
    return this.normalized && (i = Ct(i, this.array)), i;
  }
  setComponent(t, e, i) {
    return this.normalized && (i = H(i, this.array)), this.array[t * this.itemSize + e] = i, this;
  }
  getX(t) {
    let e = this.array[t * this.itemSize];
    return this.normalized && (e = Ct(e, this.array)), e;
  }
  setX(t, e) {
    return this.normalized && (e = H(e, this.array)), this.array[t * this.itemSize] = e, this;
  }
  getY(t) {
    let e = this.array[t * this.itemSize + 1];
    return this.normalized && (e = Ct(e, this.array)), e;
  }
  setY(t, e) {
    return this.normalized && (e = H(e, this.array)), this.array[t * this.itemSize + 1] = e, this;
  }
  getZ(t) {
    let e = this.array[t * this.itemSize + 2];
    return this.normalized && (e = Ct(e, this.array)), e;
  }
  setZ(t, e) {
    return this.normalized && (e = H(e, this.array)), this.array[t * this.itemSize + 2] = e, this;
  }
  getW(t) {
    let e = this.array[t * this.itemSize + 3];
    return this.normalized && (e = Ct(e, this.array)), e;
  }
  setW(t, e) {
    return this.normalized && (e = H(e, this.array)), this.array[t * this.itemSize + 3] = e, this;
  }
  setXY(t, e, i) {
    return t *= this.itemSize, this.normalized && (e = H(e, this.array), i = H(i, this.array)), this.array[t + 0] = e, this.array[t + 1] = i, this;
  }
  setXYZ(t, e, i, n) {
    return t *= this.itemSize, this.normalized && (e = H(e, this.array), i = H(i, this.array), n = H(n, this.array)), this.array[t + 0] = e, this.array[t + 1] = i, this.array[t + 2] = n, this;
  }
  setXYZW(t, e, i, n, s) {
    return t *= this.itemSize, this.normalized && (e = H(e, this.array), i = H(i, this.array), n = H(n, this.array), s = H(s, this.array)), this.array[t + 0] = e, this.array[t + 1] = i, this.array[t + 2] = n, this.array[t + 3] = s, this;
  }
  onUpload(t) {
    return this.onUploadCallback = t, this;
  }
  clone() {
    return new this.constructor(this.array, this.itemSize).copy(this);
  }
  toJSON() {
    const t = {
      itemSize: this.itemSize,
      type: this.array.constructor.name,
      array: Array.from(this.array),
      normalized: this.normalized
    };
    return this.name !== "" && (t.name = this.name), this.usage !== rr && (t.usage = this.usage), (this.updateRange.offset !== 0 || this.updateRange.count !== -1) && (t.updateRange = this.updateRange), t;
  }
}
class Wc extends Tt {
  constructor(t, e, i) {
    super(new Uint16Array(t), e, i);
  }
}
class qc extends Tt {
  constructor(t, e, i) {
    super(new Uint32Array(t), e, i);
  }
}
class Nt extends Tt {
  constructor(t, e, i) {
    super(new Float32Array(t), e, i);
  }
}
let Gc = 0;
const yt = /* @__PURE__ */ new F(), xs = /* @__PURE__ */ new q(), ze = /* @__PURE__ */ new w(), ft = /* @__PURE__ */ new Kt(), yi = /* @__PURE__ */ new Kt(), Y = /* @__PURE__ */ new w();
class Dt extends Ci {
  constructor() {
    super(), this.isBufferGeometry = !0, Object.defineProperty(this, "id", { value: Gc++ }), this.uuid = Mt(), this.name = "", this.type = "BufferGeometry", this.index = null, this.attributes = {}, this.morphAttributes = {}, this.morphTargetsRelative = !1, this.groups = [], this.boundingBox = null, this.boundingSphere = null, this.drawRange = { start: 0, count: 1 / 0 }, this.userData = {};
  }
  getIndex() {
    return this.index;
  }
  setIndex(t) {
    return Array.isArray(t) ? this.index = new (Ic(t) ? qc : Wc)(t, 1) : this.index = t, this;
  }
  getAttribute(t) {
    return this.attributes[t];
  }
  setAttribute(t, e) {
    return this.attributes[t] = e, this;
  }
  deleteAttribute(t) {
    return delete this.attributes[t], this;
  }
  hasAttribute(t) {
    return this.attributes[t] !== void 0;
  }
  addGroup(t, e, i = 0) {
    this.groups.push({
      start: t,
      count: e,
      materialIndex: i
    });
  }
  clearGroups() {
    this.groups = [];
  }
  setDrawRange(t, e) {
    this.drawRange.start = t, this.drawRange.count = e;
  }
  applyMatrix4(t) {
    const e = this.attributes.position;
    e !== void 0 && (e.applyMatrix4(t), e.needsUpdate = !0);
    const i = this.attributes.normal;
    if (i !== void 0) {
      const s = new Gt().getNormalMatrix(t);
      i.applyNormalMatrix(s), i.needsUpdate = !0;
    }
    const n = this.attributes.tangent;
    return n !== void 0 && (n.transformDirection(t), n.needsUpdate = !0), this.boundingBox !== null && this.computeBoundingBox(), this.boundingSphere !== null && this.computeBoundingSphere(), this;
  }
  applyQuaternion(t) {
    return yt.makeRotationFromQuaternion(t), this.applyMatrix4(yt), this;
  }
  rotateX(t) {
    return yt.makeRotationX(t), this.applyMatrix4(yt), this;
  }
  rotateY(t) {
    return yt.makeRotationY(t), this.applyMatrix4(yt), this;
  }
  rotateZ(t) {
    return yt.makeRotationZ(t), this.applyMatrix4(yt), this;
  }
  translate(t, e, i) {
    return yt.makeTranslation(t, e, i), this.applyMatrix4(yt), this;
  }
  scale(t, e, i) {
    return yt.makeScale(t, e, i), this.applyMatrix4(yt), this;
  }
  lookAt(t) {
    return xs.lookAt(t), xs.updateMatrix(), this.applyMatrix4(xs.matrix), this;
  }
  center() {
    return this.computeBoundingBox(), this.boundingBox.getCenter(ze).negate(), this.translate(ze.x, ze.y, ze.z), this;
  }
  setFromPoints(t) {
    const e = [];
    for (let i = 0, n = t.length; i < n; i++) {
      const s = t[i];
      e.push(s.x, s.y, s.z || 0);
    }
    return this.setAttribute("position", new Nt(e, 3)), this;
  }
  computeBoundingBox() {
    this.boundingBox === null && (this.boundingBox = new Kt());
    const t = this.attributes.position, e = this.morphAttributes.position;
    if (t && t.isGLBufferAttribute) {
      console.error('THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box. Alternatively set "mesh.frustumCulled" to "false".', this), this.boundingBox.set(
        new w(-1 / 0, -1 / 0, -1 / 0),
        new w(1 / 0, 1 / 0, 1 / 0)
      );
      return;
    }
    if (t !== void 0) {
      if (this.boundingBox.setFromBufferAttribute(t), e)
        for (let i = 0, n = e.length; i < n; i++) {
          const s = e[i];
          ft.setFromBufferAttribute(s), this.morphTargetsRelative ? (Y.addVectors(this.boundingBox.min, ft.min), this.boundingBox.expandByPoint(Y), Y.addVectors(this.boundingBox.max, ft.max), this.boundingBox.expandByPoint(Y)) : (this.boundingBox.expandByPoint(ft.min), this.boundingBox.expandByPoint(ft.max));
        }
    } else
      this.boundingBox.makeEmpty();
    (isNaN(this.boundingBox.min.x) || isNaN(this.boundingBox.min.y) || isNaN(this.boundingBox.min.z)) && console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.', this);
  }
  computeBoundingSphere() {
    this.boundingSphere === null && (this.boundingSphere = new Lt());
    const t = this.attributes.position, e = this.morphAttributes.position;
    if (t && t.isGLBufferAttribute) {
      console.error('THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere. Alternatively set "mesh.frustumCulled" to "false".', this), this.boundingSphere.set(new w(), 1 / 0);
      return;
    }
    if (t) {
      const i = this.boundingSphere.center;
      if (ft.setFromBufferAttribute(t), e)
        for (let s = 0, r = e.length; s < r; s++) {
          const o = e[s];
          yi.setFromBufferAttribute(o), this.morphTargetsRelative ? (Y.addVectors(ft.min, yi.min), ft.expandByPoint(Y), Y.addVectors(ft.max, yi.max), ft.expandByPoint(Y)) : (ft.expandByPoint(yi.min), ft.expandByPoint(yi.max));
        }
      ft.getCenter(i);
      let n = 0;
      for (let s = 0, r = t.count; s < r; s++)
        Y.fromBufferAttribute(t, s), n = Math.max(n, i.distanceToSquared(Y));
      if (e)
        for (let s = 0, r = e.length; s < r; s++) {
          const o = e[s], h = this.morphTargetsRelative;
          for (let l = 0, c = o.count; l < c; l++)
            Y.fromBufferAttribute(o, l), h && (ze.fromBufferAttribute(t, l), Y.add(ze)), n = Math.max(n, i.distanceToSquared(Y));
        }
      this.boundingSphere.radius = Math.sqrt(n), isNaN(this.boundingSphere.radius) && console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.', this);
    }
  }
  computeTangents() {
    const t = this.index, e = this.attributes;
    if (t === null || e.position === void 0 || e.normal === void 0 || e.uv === void 0) {
      console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");
      return;
    }
    const i = t.array, n = e.position.array, s = e.normal.array, r = e.uv.array, o = n.length / 3;
    this.hasAttribute("tangent") === !1 && this.setAttribute("tangent", new Tt(new Float32Array(4 * o), 4));
    const h = this.getAttribute("tangent").array, l = [], c = [];
    for (let E = 0; E < o; E++)
      l[E] = new w(), c[E] = new w();
    const u = new w(), d = new w(), f = new w(), p = new G(), y = new G(), m = new G(), _ = new w(), b = new w();
    function A(E, R, S) {
      u.fromArray(n, E * 3), d.fromArray(n, R * 3), f.fromArray(n, S * 3), p.fromArray(r, E * 2), y.fromArray(r, R * 2), m.fromArray(r, S * 2), d.sub(u), f.sub(u), y.sub(p), m.sub(p);
      const C = 1 / (y.x * m.y - m.x * y.y);
      isFinite(C) && (_.copy(d).multiplyScalar(m.y).addScaledVector(f, -y.y).multiplyScalar(C), b.copy(f).multiplyScalar(y.x).addScaledVector(d, -m.x).multiplyScalar(C), l[E].add(_), l[R].add(_), l[S].add(_), c[E].add(b), c[R].add(b), c[S].add(b));
    }
    let g = this.groups;
    g.length === 0 && (g = [{
      start: 0,
      count: i.length
    }]);
    for (let E = 0, R = g.length; E < R; ++E) {
      const S = g[E], C = S.start, O = S.count;
      for (let L = C, P = C + O; L < P; L += 3)
        A(
          i[L + 0],
          i[L + 1],
          i[L + 2]
        );
    }
    const x = new w(), v = new w(), M = new w(), T = new w();
    function I(E) {
      M.fromArray(s, E * 3), T.copy(M);
      const R = l[E];
      x.copy(R), x.sub(M.multiplyScalar(M.dot(R))).normalize(), v.crossVectors(T, R);
      const C = v.dot(c[E]) < 0 ? -1 : 1;
      h[E * 4] = x.x, h[E * 4 + 1] = x.y, h[E * 4 + 2] = x.z, h[E * 4 + 3] = C;
    }
    for (let E = 0, R = g.length; E < R; ++E) {
      const S = g[E], C = S.start, O = S.count;
      for (let L = C, P = C + O; L < P; L += 3)
        I(i[L + 0]), I(i[L + 1]), I(i[L + 2]);
    }
  }
  computeVertexNormals() {
    const t = this.index, e = this.getAttribute("position");
    if (e !== void 0) {
      let i = this.getAttribute("normal");
      if (i === void 0)
        i = new Tt(new Float32Array(e.count * 3), 3), this.setAttribute("normal", i);
      else
        for (let d = 0, f = i.count; d < f; d++)
          i.setXYZ(d, 0, 0, 0);
      const n = new w(), s = new w(), r = new w(), o = new w(), h = new w(), l = new w(), c = new w(), u = new w();
      if (t)
        for (let d = 0, f = t.count; d < f; d += 3) {
          const p = t.getX(d + 0), y = t.getX(d + 1), m = t.getX(d + 2);
          n.fromBufferAttribute(e, p), s.fromBufferAttribute(e, y), r.fromBufferAttribute(e, m), c.subVectors(r, s), u.subVectors(n, s), c.cross(u), o.fromBufferAttribute(i, p), h.fromBufferAttribute(i, y), l.fromBufferAttribute(i, m), o.add(c), h.add(c), l.add(c), i.setXYZ(p, o.x, o.y, o.z), i.setXYZ(y, h.x, h.y, h.z), i.setXYZ(m, l.x, l.y, l.z);
        }
      else
        for (let d = 0, f = e.count; d < f; d += 3)
          n.fromBufferAttribute(e, d + 0), s.fromBufferAttribute(e, d + 1), r.fromBufferAttribute(e, d + 2), c.subVectors(r, s), u.subVectors(n, s), c.cross(u), i.setXYZ(d + 0, c.x, c.y, c.z), i.setXYZ(d + 1, c.x, c.y, c.z), i.setXYZ(d + 2, c.x, c.y, c.z);
      this.normalizeNormals(), i.needsUpdate = !0;
    }
  }
  normalizeNormals() {
    const t = this.attributes.normal;
    for (let e = 0, i = t.count; e < i; e++)
      Y.fromBufferAttribute(t, e), Y.normalize(), t.setXYZ(e, Y.x, Y.y, Y.z);
  }
  toNonIndexed() {
    function t(o, h) {
      const l = o.array, c = o.itemSize, u = o.normalized, d = new l.constructor(h.length * c);
      let f = 0, p = 0;
      for (let y = 0, m = h.length; y < m; y++) {
        o.isInterleavedBufferAttribute ? f = h[y] * o.data.stride + o.offset : f = h[y] * c;
        for (let _ = 0; _ < c; _++)
          d[p++] = l[f++];
      }
      return new Tt(d, c, u);
    }
    if (this.index === null)
      return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."), this;
    const e = new Dt(), i = this.index.array, n = this.attributes;
    for (const o in n) {
      const h = n[o], l = t(h, i);
      e.setAttribute(o, l);
    }
    const s = this.morphAttributes;
    for (const o in s) {
      const h = [], l = s[o];
      for (let c = 0, u = l.length; c < u; c++) {
        const d = l[c], f = t(d, i);
        h.push(f);
      }
      e.morphAttributes[o] = h;
    }
    e.morphTargetsRelative = this.morphTargetsRelative;
    const r = this.groups;
    for (let o = 0, h = r.length; o < h; o++) {
      const l = r[o];
      e.addGroup(l.start, l.count, l.materialIndex);
    }
    return e;
  }
  toJSON() {
    const t = {
      metadata: {
        version: 4.6,
        type: "BufferGeometry",
        generator: "BufferGeometry.toJSON"
      }
    };
    if (t.uuid = this.uuid, t.type = this.type, this.name !== "" && (t.name = this.name), Object.keys(this.userData).length > 0 && (t.userData = this.userData), this.parameters !== void 0) {
      const h = this.parameters;
      for (const l in h)
        h[l] !== void 0 && (t[l] = h[l]);
      return t;
    }
    t.data = { attributes: {} };
    const e = this.index;
    e !== null && (t.data.index = {
      type: e.array.constructor.name,
      array: Array.prototype.slice.call(e.array)
    });
    const i = this.attributes;
    for (const h in i) {
      const l = i[h];
      t.data.attributes[h] = l.toJSON(t.data);
    }
    const n = {};
    let s = !1;
    for (const h in this.morphAttributes) {
      const l = this.morphAttributes[h], c = [];
      for (let u = 0, d = l.length; u < d; u++) {
        const f = l[u];
        c.push(f.toJSON(t.data));
      }
      c.length > 0 && (n[h] = c, s = !0);
    }
    s && (t.data.morphAttributes = n, t.data.morphTargetsRelative = this.morphTargetsRelative);
    const r = this.groups;
    r.length > 0 && (t.data.groups = JSON.parse(JSON.stringify(r)));
    const o = this.boundingSphere;
    return o !== null && (t.data.boundingSphere = {
      center: o.center.toArray(),
      radius: o.radius
    }), t;
  }
  clone() {
    return new this.constructor().copy(this);
  }
  copy(t) {
    this.index = null, this.attributes = {}, this.morphAttributes = {}, this.groups = [], this.boundingBox = null, this.boundingSphere = null;
    const e = {};
    this.name = t.name;
    const i = t.index;
    i !== null && this.setIndex(i.clone(e));
    const n = t.attributes;
    for (const l in n) {
      const c = n[l];
      this.setAttribute(l, c.clone(e));
    }
    const s = t.morphAttributes;
    for (const l in s) {
      const c = [], u = s[l];
      for (let d = 0, f = u.length; d < f; d++)
        c.push(u[d].clone(e));
      this.morphAttributes[l] = c;
    }
    this.morphTargetsRelative = t.morphTargetsRelative;
    const r = t.groups;
    for (let l = 0, c = r.length; l < c; l++) {
      const u = r[l];
      this.addGroup(u.start, u.count, u.materialIndex);
    }
    const o = t.boundingBox;
    o !== null && (this.boundingBox = o.clone());
    const h = t.boundingSphere;
    return h !== null && (this.boundingSphere = h.clone()), this.drawRange.start = t.drawRange.start, this.drawRange.count = t.drawRange.count, this.userData = t.userData, this;
  }
  dispose() {
    this.dispatchEvent({ type: "dispose" });
  }
}
const Ga = /* @__PURE__ */ new F(), _e = /* @__PURE__ */ new Oi(), on = /* @__PURE__ */ new Lt(), Ka = /* @__PURE__ */ new w(), Ue = /* @__PURE__ */ new w(), je = /* @__PURE__ */ new w(), He = /* @__PURE__ */ new w(), ws = /* @__PURE__ */ new w(), hn = /* @__PURE__ */ new w(), ln = /* @__PURE__ */ new G(), cn = /* @__PURE__ */ new G(), un = /* @__PURE__ */ new G(), Ya = /* @__PURE__ */ new w(), Xa = /* @__PURE__ */ new w(), Ja = /* @__PURE__ */ new w(), dn = /* @__PURE__ */ new w(), fn = /* @__PURE__ */ new w();
class Se extends q {
  constructor(t = new Dt(), e = new ce()) {
    super(), this.isMesh = !0, this.type = "Mesh", this.geometry = t, this.material = e, this.updateMorphTargets();
  }
  copy(t, e) {
    return super.copy(t, e), t.morphTargetInfluences !== void 0 && (this.morphTargetInfluences = t.morphTargetInfluences.slice()), t.morphTargetDictionary !== void 0 && (this.morphTargetDictionary = Object.assign({}, t.morphTargetDictionary)), this.material = Array.isArray(t.material) ? t.material.slice() : t.material, this.geometry = t.geometry, this;
  }
  updateMorphTargets() {
    const e = this.geometry.morphAttributes, i = Object.keys(e);
    if (i.length > 0) {
      const n = e[i[0]];
      if (n !== void 0) {
        this.morphTargetInfluences = [], this.morphTargetDictionary = {};
        for (let s = 0, r = n.length; s < r; s++) {
          const o = n[s].name || String(s);
          this.morphTargetInfluences.push(0), this.morphTargetDictionary[o] = s;
        }
      }
    }
  }
  getVertexPosition(t, e) {
    const i = this.geometry, n = i.attributes.position, s = i.morphAttributes.position, r = i.morphTargetsRelative;
    e.fromBufferAttribute(n, t);
    const o = this.morphTargetInfluences;
    if (s && o) {
      hn.set(0, 0, 0);
      for (let h = 0, l = s.length; h < l; h++) {
        const c = o[h], u = s[h];
        c !== 0 && (ws.fromBufferAttribute(u, t), r ? hn.addScaledVector(ws, c) : hn.addScaledVector(ws.sub(e), c));
      }
      e.add(hn);
    }
    return e;
  }
  raycast(t, e) {
    const i = this.geometry, n = this.material, s = this.matrixWorld;
    n !== void 0 && (i.boundingSphere === null && i.computeBoundingSphere(), on.copy(i.boundingSphere), on.applyMatrix4(s), _e.copy(t.ray).recast(t.near), !(on.containsPoint(_e.origin) === !1 && (_e.intersectSphere(on, Ka) === null || _e.origin.distanceToSquared(Ka) > (t.far - t.near) ** 2)) && (Ga.copy(s).invert(), _e.copy(t.ray).applyMatrix4(Ga), !(i.boundingBox !== null && _e.intersectsBox(i.boundingBox) === !1) && this._computeIntersections(t, e, _e)));
  }
  _computeIntersections(t, e, i) {
    let n;
    const s = this.geometry, r = this.material, o = s.index, h = s.attributes.position, l = s.attributes.uv, c = s.attributes.uv1, u = s.attributes.normal, d = s.groups, f = s.drawRange;
    if (o !== null)
      if (Array.isArray(r))
        for (let p = 0, y = d.length; p < y; p++) {
          const m = d[p], _ = r[m.materialIndex], b = Math.max(m.start, f.start), A = Math.min(o.count, Math.min(m.start + m.count, f.start + f.count));
          for (let g = b, x = A; g < x; g += 3) {
            const v = o.getX(g), M = o.getX(g + 1), T = o.getX(g + 2);
            n = pn(this, _, t, i, l, c, u, v, M, T), n && (n.faceIndex = Math.floor(g / 3), n.face.materialIndex = m.materialIndex, e.push(n));
          }
        }
      else {
        const p = Math.max(0, f.start), y = Math.min(o.count, f.start + f.count);
        for (let m = p, _ = y; m < _; m += 3) {
          const b = o.getX(m), A = o.getX(m + 1), g = o.getX(m + 2);
          n = pn(this, r, t, i, l, c, u, b, A, g), n && (n.faceIndex = Math.floor(m / 3), e.push(n));
        }
      }
    else if (h !== void 0)
      if (Array.isArray(r))
        for (let p = 0, y = d.length; p < y; p++) {
          const m = d[p], _ = r[m.materialIndex], b = Math.max(m.start, f.start), A = Math.min(h.count, Math.min(m.start + m.count, f.start + f.count));
          for (let g = b, x = A; g < x; g += 3) {
            const v = g, M = g + 1, T = g + 2;
            n = pn(this, _, t, i, l, c, u, v, M, T), n && (n.faceIndex = Math.floor(g / 3), n.face.materialIndex = m.materialIndex, e.push(n));
          }
        }
      else {
        const p = Math.max(0, f.start), y = Math.min(h.count, f.start + f.count);
        for (let m = p, _ = y; m < _; m += 3) {
          const b = m, A = m + 1, g = m + 2;
          n = pn(this, r, t, i, l, c, u, b, A, g), n && (n.faceIndex = Math.floor(m / 3), e.push(n));
        }
      }
  }
}
function Kc(a, t, e, i, n, s, r, o) {
  let h;
  if (t.side === Xl ? h = i.intersectTriangle(r, s, n, !0, o) : h = i.intersectTriangle(n, s, r, t.side === Dn, o), h === null)
    return null;
  fn.copy(o), fn.applyMatrix4(a.matrixWorld);
  const l = e.ray.origin.distanceTo(fn);
  return l < e.near || l > e.far ? null : {
    distance: l,
    point: fn.clone(),
    object: a
  };
}
function pn(a, t, e, i, n, s, r, o, h, l) {
  a.getVertexPosition(o, Ue), a.getVertexPosition(h, je), a.getVertexPosition(l, He);
  const c = Kc(a, t, e, i, Ue, je, He, dn);
  if (c) {
    n && (ln.fromBufferAttribute(n, o), cn.fromBufferAttribute(n, h), un.fromBufferAttribute(n, l), c.uv = vt.getInterpolation(dn, Ue, je, He, ln, cn, un, new G())), s && (ln.fromBufferAttribute(s, o), cn.fromBufferAttribute(s, h), un.fromBufferAttribute(s, l), c.uv1 = vt.getInterpolation(dn, Ue, je, He, ln, cn, un, new G()), c.uv2 = c.uv1), r && (Ya.fromBufferAttribute(r, o), Xa.fromBufferAttribute(r, h), Ja.fromBufferAttribute(r, l), c.normal = vt.getInterpolation(dn, Ue, je, He, Ya, Xa, Ja, new w()), c.normal.dot(i.direction) > 0 && c.normal.multiplyScalar(-1));
    const u = {
      a: o,
      b: h,
      c: l,
      normal: new w(),
      materialIndex: 0
    };
    vt.getNormal(Ue, je, He, u.normal), c.face = u;
  }
  return c;
}
class Nh extends q {
  constructor() {
    super(), this.isCamera = !0, this.type = "Camera", this.matrixWorldInverse = new F(), this.projectionMatrix = new F(), this.projectionMatrixInverse = new F(), this.coordinateSystem = Me;
  }
  copy(t, e) {
    return super.copy(t, e), this.matrixWorldInverse.copy(t.matrixWorldInverse), this.projectionMatrix.copy(t.projectionMatrix), this.projectionMatrixInverse.copy(t.projectionMatrixInverse), this.coordinateSystem = t.coordinateSystem, this;
  }
  getWorldDirection(t) {
    return super.getWorldDirection(t).negate();
  }
  updateMatrixWorld(t) {
    super.updateMatrixWorld(t), this.matrixWorldInverse.copy(this.matrixWorld).invert();
  }
  updateWorldMatrix(t, e) {
    super.updateWorldMatrix(t, e), this.matrixWorldInverse.copy(this.matrixWorld).invert();
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
class Un extends Nh {
  constructor(t = 50, e = 1, i = 0.1, n = 2e3) {
    super(), this.isPerspectiveCamera = !0, this.type = "PerspectiveCamera", this.fov = t, this.zoom = 1, this.near = i, this.far = n, this.focus = 10, this.aspect = e, this.view = null, this.filmGauge = 35, this.filmOffset = 0, this.updateProjectionMatrix();
  }
  copy(t, e) {
    return super.copy(t, e), this.fov = t.fov, this.zoom = t.zoom, this.near = t.near, this.far = t.far, this.focus = t.focus, this.aspect = t.aspect, this.view = t.view === null ? null : Object.assign({}, t.view), this.filmGauge = t.filmGauge, this.filmOffset = t.filmOffset, this;
  }
  /**
   * Sets the FOV by focal length in respect to the current .filmGauge.
   *
   * The default film gauge is 35, so that the focal length can be specified for
   * a 35mm (full frame) camera.
   *
   * Values for focal length and film gauge must have the same unit.
   */
  setFocalLength(t) {
    const e = 0.5 * this.getFilmHeight() / t;
    this.fov = Ii * 2 * Math.atan(e), this.updateProjectionMatrix();
  }
  /**
   * Calculates the focal length from the current .fov and .filmGauge.
   */
  getFocalLength() {
    const t = Math.tan(Mi * 0.5 * this.fov);
    return 0.5 * this.getFilmHeight() / t;
  }
  getEffectiveFOV() {
    return Ii * 2 * Math.atan(
      Math.tan(Mi * 0.5 * this.fov) / this.zoom
    );
  }
  getFilmWidth() {
    return this.filmGauge * Math.min(this.aspect, 1);
  }
  getFilmHeight() {
    return this.filmGauge / Math.max(this.aspect, 1);
  }
  /**
   * Sets an offset in a larger frustum. This is useful for multi-window or
   * multi-monitor/multi-machine setups.
   *
   * For example, if you have 3x2 monitors and each monitor is 1920x1080 and
   * the monitors are in grid like this
   *
   *   +---+---+---+
   *   | A | B | C |
   *   +---+---+---+
   *   | D | E | F |
   *   +---+---+---+
   *
   * then for each monitor you would call it like this
   *
   *   const w = 1920;
   *   const h = 1080;
   *   const fullWidth = w * 3;
   *   const fullHeight = h * 2;
   *
   *   --A--
   *   camera.setViewOffset( fullWidth, fullHeight, w * 0, h * 0, w, h );
   *   --B--
   *   camera.setViewOffset( fullWidth, fullHeight, w * 1, h * 0, w, h );
   *   --C--
   *   camera.setViewOffset( fullWidth, fullHeight, w * 2, h * 0, w, h );
   *   --D--
   *   camera.setViewOffset( fullWidth, fullHeight, w * 0, h * 1, w, h );
   *   --E--
   *   camera.setViewOffset( fullWidth, fullHeight, w * 1, h * 1, w, h );
   *   --F--
   *   camera.setViewOffset( fullWidth, fullHeight, w * 2, h * 1, w, h );
   *
   *   Note there is no reason monitors have to be the same size or in a grid.
   */
  setViewOffset(t, e, i, n, s, r) {
    this.aspect = t / e, this.view === null && (this.view = {
      enabled: !0,
      fullWidth: 1,
      fullHeight: 1,
      offsetX: 0,
      offsetY: 0,
      width: 1,
      height: 1
    }), this.view.enabled = !0, this.view.fullWidth = t, this.view.fullHeight = e, this.view.offsetX = i, this.view.offsetY = n, this.view.width = s, this.view.height = r, this.updateProjectionMatrix();
  }
  clearViewOffset() {
    this.view !== null && (this.view.enabled = !1), this.updateProjectionMatrix();
  }
  updateProjectionMatrix() {
    const t = this.near;
    let e = t * Math.tan(Mi * 0.5 * this.fov) / this.zoom, i = 2 * e, n = this.aspect * i, s = -0.5 * n;
    const r = this.view;
    if (this.view !== null && this.view.enabled) {
      const h = r.fullWidth, l = r.fullHeight;
      s += r.offsetX * n / h, e -= r.offsetY * i / l, n *= r.width / h, i *= r.height / l;
    }
    const o = this.filmOffset;
    o !== 0 && (s += t * o / this.getFilmWidth()), this.projectionMatrix.makePerspective(s, s + n, e, e - i, t, this.far, this.coordinateSystem), this.projectionMatrixInverse.copy(this.projectionMatrix).invert();
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.object.fov = this.fov, e.object.zoom = this.zoom, e.object.near = this.near, e.object.far = this.far, e.object.focus = this.focus, e.object.aspect = this.aspect, this.view !== null && (e.object.view = Object.assign({}, this.view)), e.object.filmGauge = this.filmGauge, e.object.filmOffset = this.filmOffset, e;
  }
}
const bs = /* @__PURE__ */ new w(), Yc = /* @__PURE__ */ new w(), Xc = /* @__PURE__ */ new Gt();
class $e {
  constructor(t = new w(1, 0, 0), e = 0) {
    this.isPlane = !0, this.normal = t, this.constant = e;
  }
  set(t, e) {
    return this.normal.copy(t), this.constant = e, this;
  }
  setComponents(t, e, i, n) {
    return this.normal.set(t, e, i), this.constant = n, this;
  }
  setFromNormalAndCoplanarPoint(t, e) {
    return this.normal.copy(t), this.constant = -e.dot(this.normal), this;
  }
  setFromCoplanarPoints(t, e, i) {
    const n = bs.subVectors(i, e).cross(Yc.subVectors(t, e)).normalize();
    return this.setFromNormalAndCoplanarPoint(n, t), this;
  }
  copy(t) {
    return this.normal.copy(t.normal), this.constant = t.constant, this;
  }
  normalize() {
    const t = 1 / this.normal.length();
    return this.normal.multiplyScalar(t), this.constant *= t, this;
  }
  negate() {
    return this.constant *= -1, this.normal.negate(), this;
  }
  distanceToPoint(t) {
    return this.normal.dot(t) + this.constant;
  }
  distanceToSphere(t) {
    return this.distanceToPoint(t.center) - t.radius;
  }
  projectPoint(t, e) {
    return e.copy(t).addScaledVector(this.normal, -this.distanceToPoint(t));
  }
  intersectLine(t, e) {
    const i = t.delta(bs), n = this.normal.dot(i);
    if (n === 0)
      return this.distanceToPoint(t.start) === 0 ? e.copy(t.start) : null;
    const s = -(t.start.dot(this.normal) + this.constant) / n;
    return s < 0 || s > 1 ? null : e.copy(t.start).addScaledVector(i, s);
  }
  intersectsLine(t) {
    const e = this.distanceToPoint(t.start), i = this.distanceToPoint(t.end);
    return e < 0 && i > 0 || i < 0 && e > 0;
  }
  intersectsBox(t) {
    return t.intersectsPlane(this);
  }
  intersectsSphere(t) {
    return t.intersectsPlane(this);
  }
  coplanarPoint(t) {
    return t.copy(this.normal).multiplyScalar(-this.constant);
  }
  applyMatrix4(t, e) {
    const i = e || Xc.getNormalMatrix(t), n = this.coplanarPoint(bs).applyMatrix4(t), s = this.normal.applyMatrix3(i).normalize();
    return this.constant = -n.dot(s), this;
  }
  translate(t) {
    return this.constant -= t.dot(this.normal), this;
  }
  equals(t) {
    return t.normal.equals(this.normal) && t.constant === this.constant;
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
const xe = /* @__PURE__ */ new Lt(), mn = /* @__PURE__ */ new w();
class Jc {
  constructor(t = new $e(), e = new $e(), i = new $e(), n = new $e(), s = new $e(), r = new $e()) {
    this.planes = [t, e, i, n, s, r];
  }
  set(t, e, i, n, s, r) {
    const o = this.planes;
    return o[0].copy(t), o[1].copy(e), o[2].copy(i), o[3].copy(n), o[4].copy(s), o[5].copy(r), this;
  }
  copy(t) {
    const e = this.planes;
    for (let i = 0; i < 6; i++)
      e[i].copy(t.planes[i]);
    return this;
  }
  setFromProjectionMatrix(t, e = Me) {
    const i = this.planes, n = t.elements, s = n[0], r = n[1], o = n[2], h = n[3], l = n[4], c = n[5], u = n[6], d = n[7], f = n[8], p = n[9], y = n[10], m = n[11], _ = n[12], b = n[13], A = n[14], g = n[15];
    if (i[0].setComponents(h - s, d - l, m - f, g - _).normalize(), i[1].setComponents(h + s, d + l, m + f, g + _).normalize(), i[2].setComponents(h + r, d + c, m + p, g + b).normalize(), i[3].setComponents(h - r, d - c, m - p, g - b).normalize(), i[4].setComponents(h - o, d - u, m - y, g - A).normalize(), e === Me)
      i[5].setComponents(h + o, d + u, m + y, g + A).normalize();
    else if (e === ar)
      i[5].setComponents(o, u, y, A).normalize();
    else
      throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: " + e);
    return this;
  }
  intersectsObject(t) {
    if (t.boundingSphere !== void 0)
      t.boundingSphere === null && t.computeBoundingSphere(), xe.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);
    else {
      const e = t.geometry;
      e.boundingSphere === null && e.computeBoundingSphere(), xe.copy(e.boundingSphere).applyMatrix4(t.matrixWorld);
    }
    return this.intersectsSphere(xe);
  }
  intersectsSprite(t) {
    return xe.center.set(0, 0, 0), xe.radius = 0.7071067811865476, xe.applyMatrix4(t.matrixWorld), this.intersectsSphere(xe);
  }
  intersectsSphere(t) {
    const e = this.planes, i = t.center, n = -t.radius;
    for (let s = 0; s < 6; s++)
      if (e[s].distanceToPoint(i) < n)
        return !1;
    return !0;
  }
  intersectsBox(t) {
    const e = this.planes;
    for (let i = 0; i < 6; i++) {
      const n = e[i];
      if (mn.x = n.normal.x > 0 ? t.max.x : t.min.x, mn.y = n.normal.y > 0 ? t.max.y : t.min.y, mn.z = n.normal.z > 0 ? t.max.z : t.min.z, n.distanceToPoint(mn) < 0)
        return !1;
    }
    return !0;
  }
  containsPoint(t) {
    const e = this.planes;
    for (let i = 0; i < 6; i++)
      if (e[i].distanceToPoint(t) < 0)
        return !1;
    return !0;
  }
  clone() {
    return new this.constructor().copy(this);
  }
}
class Lh extends Nh {
  constructor(t = -1, e = 1, i = 1, n = -1, s = 0.1, r = 2e3) {
    super(), this.isOrthographicCamera = !0, this.type = "OrthographicCamera", this.zoom = 1, this.view = null, this.left = t, this.right = e, this.top = i, this.bottom = n, this.near = s, this.far = r, this.updateProjectionMatrix();
  }
  copy(t, e) {
    return super.copy(t, e), this.left = t.left, this.right = t.right, this.top = t.top, this.bottom = t.bottom, this.near = t.near, this.far = t.far, this.zoom = t.zoom, this.view = t.view === null ? null : Object.assign({}, t.view), this;
  }
  setViewOffset(t, e, i, n, s, r) {
    this.view === null && (this.view = {
      enabled: !0,
      fullWidth: 1,
      fullHeight: 1,
      offsetX: 0,
      offsetY: 0,
      width: 1,
      height: 1
    }), this.view.enabled = !0, this.view.fullWidth = t, this.view.fullHeight = e, this.view.offsetX = i, this.view.offsetY = n, this.view.width = s, this.view.height = r, this.updateProjectionMatrix();
  }
  clearViewOffset() {
    this.view !== null && (this.view.enabled = !1), this.updateProjectionMatrix();
  }
  updateProjectionMatrix() {
    const t = (this.right - this.left) / (2 * this.zoom), e = (this.top - this.bottom) / (2 * this.zoom), i = (this.right + this.left) / 2, n = (this.top + this.bottom) / 2;
    let s = i - t, r = i + t, o = n + e, h = n - e;
    if (this.view !== null && this.view.enabled) {
      const l = (this.right - this.left) / this.view.fullWidth / this.zoom, c = (this.top - this.bottom) / this.view.fullHeight / this.zoom;
      s += l * this.view.offsetX, r = s + l * this.view.width, o -= c * this.view.offsetY, h = o - c * this.view.height;
    }
    this.projectionMatrix.makeOrthographic(s, r, o, h, this.near, this.far, this.coordinateSystem), this.projectionMatrixInverse.copy(this.projectionMatrix).invert();
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.object.zoom = this.zoom, e.object.left = this.left, e.object.right = this.right, e.object.top = this.top, e.object.bottom = this.bottom, e.object.near = this.near, e.object.far = this.far, this.view !== null && (e.object.view = Object.assign({}, this.view)), e;
  }
}
class vs extends q {
  constructor() {
    super(), this.isGroup = !0, this.type = "Group";
  }
}
class Zc {
  constructor(t, e) {
    this.isInterleavedBuffer = !0, this.array = t, this.stride = e, this.count = t !== void 0 ? t.length / e : 0, this.usage = rr, this.updateRange = { offset: 0, count: -1 }, this.version = 0, this.uuid = Mt();
  }
  onUploadCallback() {
  }
  set needsUpdate(t) {
    t === !0 && this.version++;
  }
  setUsage(t) {
    return this.usage = t, this;
  }
  copy(t) {
    return this.array = new t.array.constructor(t.array), this.count = t.count, this.stride = t.stride, this.usage = t.usage, this;
  }
  copyAt(t, e, i) {
    t *= this.stride, i *= e.stride;
    for (let n = 0, s = this.stride; n < s; n++)
      this.array[t + n] = e.array[i + n];
    return this;
  }
  set(t, e = 0) {
    return this.array.set(t, e), this;
  }
  clone(t) {
    t.arrayBuffers === void 0 && (t.arrayBuffers = {}), this.array.buffer._uuid === void 0 && (this.array.buffer._uuid = Mt()), t.arrayBuffers[this.array.buffer._uuid] === void 0 && (t.arrayBuffers[this.array.buffer._uuid] = this.array.slice(0).buffer);
    const e = new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]), i = new this.constructor(e, this.stride);
    return i.setUsage(this.usage), i;
  }
  onUpload(t) {
    return this.onUploadCallback = t, this;
  }
  toJSON(t) {
    return t.arrayBuffers === void 0 && (t.arrayBuffers = {}), this.array.buffer._uuid === void 0 && (this.array.buffer._uuid = Mt()), t.arrayBuffers[this.array.buffer._uuid] === void 0 && (t.arrayBuffers[this.array.buffer._uuid] = Array.from(new Uint32Array(this.array.buffer))), {
      uuid: this.uuid,
      buffer: this.array.buffer._uuid,
      type: this.array.constructor.name,
      stride: this.stride
    };
  }
}
const at = /* @__PURE__ */ new w();
class $r {
  constructor(t, e, i, n = !1) {
    this.isInterleavedBufferAttribute = !0, this.name = "", this.data = t, this.itemSize = e, this.offset = i, this.normalized = n;
  }
  get count() {
    return this.data.count;
  }
  get array() {
    return this.data.array;
  }
  set needsUpdate(t) {
    this.data.needsUpdate = t;
  }
  applyMatrix4(t) {
    for (let e = 0, i = this.data.count; e < i; e++)
      at.fromBufferAttribute(this, e), at.applyMatrix4(t), this.setXYZ(e, at.x, at.y, at.z);
    return this;
  }
  applyNormalMatrix(t) {
    for (let e = 0, i = this.count; e < i; e++)
      at.fromBufferAttribute(this, e), at.applyNormalMatrix(t), this.setXYZ(e, at.x, at.y, at.z);
    return this;
  }
  transformDirection(t) {
    for (let e = 0, i = this.count; e < i; e++)
      at.fromBufferAttribute(this, e), at.transformDirection(t), this.setXYZ(e, at.x, at.y, at.z);
    return this;
  }
  setX(t, e) {
    return this.normalized && (e = H(e, this.array)), this.data.array[t * this.data.stride + this.offset] = e, this;
  }
  setY(t, e) {
    return this.normalized && (e = H(e, this.array)), this.data.array[t * this.data.stride + this.offset + 1] = e, this;
  }
  setZ(t, e) {
    return this.normalized && (e = H(e, this.array)), this.data.array[t * this.data.stride + this.offset + 2] = e, this;
  }
  setW(t, e) {
    return this.normalized && (e = H(e, this.array)), this.data.array[t * this.data.stride + this.offset + 3] = e, this;
  }
  getX(t) {
    let e = this.data.array[t * this.data.stride + this.offset];
    return this.normalized && (e = Ct(e, this.array)), e;
  }
  getY(t) {
    let e = this.data.array[t * this.data.stride + this.offset + 1];
    return this.normalized && (e = Ct(e, this.array)), e;
  }
  getZ(t) {
    let e = this.data.array[t * this.data.stride + this.offset + 2];
    return this.normalized && (e = Ct(e, this.array)), e;
  }
  getW(t) {
    let e = this.data.array[t * this.data.stride + this.offset + 3];
    return this.normalized && (e = Ct(e, this.array)), e;
  }
  setXY(t, e, i) {
    return t = t * this.data.stride + this.offset, this.normalized && (e = H(e, this.array), i = H(i, this.array)), this.data.array[t + 0] = e, this.data.array[t + 1] = i, this;
  }
  setXYZ(t, e, i, n) {
    return t = t * this.data.stride + this.offset, this.normalized && (e = H(e, this.array), i = H(i, this.array), n = H(n, this.array)), this.data.array[t + 0] = e, this.data.array[t + 1] = i, this.data.array[t + 2] = n, this;
  }
  setXYZW(t, e, i, n, s) {
    return t = t * this.data.stride + this.offset, this.normalized && (e = H(e, this.array), i = H(i, this.array), n = H(n, this.array), s = H(s, this.array)), this.data.array[t + 0] = e, this.data.array[t + 1] = i, this.data.array[t + 2] = n, this.data.array[t + 3] = s, this;
  }
  clone(t) {
    if (t === void 0) {
      console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");
      const e = [];
      for (let i = 0; i < this.count; i++) {
        const n = i * this.data.stride + this.offset;
        for (let s = 0; s < this.itemSize; s++)
          e.push(this.data.array[n + s]);
      }
      return new Tt(new this.array.constructor(e), this.itemSize, this.normalized);
    } else
      return t.interleavedBuffers === void 0 && (t.interleavedBuffers = {}), t.interleavedBuffers[this.data.uuid] === void 0 && (t.interleavedBuffers[this.data.uuid] = this.data.clone(t)), new $r(t.interleavedBuffers[this.data.uuid], this.itemSize, this.offset, this.normalized);
  }
  toJSON(t) {
    if (t === void 0) {
      console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");
      const e = [];
      for (let i = 0; i < this.count; i++) {
        const n = i * this.data.stride + this.offset;
        for (let s = 0; s < this.itemSize; s++)
          e.push(this.data.array[n + s]);
      }
      return {
        itemSize: this.itemSize,
        type: this.array.constructor.name,
        array: e,
        normalized: this.normalized
      };
    } else
      return t.interleavedBuffers === void 0 && (t.interleavedBuffers = {}), t.interleavedBuffers[this.data.uuid] === void 0 && (t.interleavedBuffers[this.data.uuid] = this.data.toJSON(t)), {
        isInterleavedBufferAttribute: !0,
        itemSize: this.itemSize,
        data: this.data.uuid,
        offset: this.offset,
        normalized: this.normalized
      };
  }
}
const Za = /* @__PURE__ */ new w(), Qa = /* @__PURE__ */ new _t(), to = /* @__PURE__ */ new _t(), Qc = /* @__PURE__ */ new w(), eo = /* @__PURE__ */ new F(), Ve = /* @__PURE__ */ new w(), As = /* @__PURE__ */ new Lt(), io = /* @__PURE__ */ new F(), Ms = /* @__PURE__ */ new Oi();
class tu extends Se {
  constructor(t, e) {
    super(t, e), this.isSkinnedMesh = !0, this.type = "SkinnedMesh", this.bindMode = "attached", this.bindMatrix = new F(), this.bindMatrixInverse = new F(), this.boundingBox = null, this.boundingSphere = null;
  }
  computeBoundingBox() {
    const t = this.geometry;
    this.boundingBox === null && (this.boundingBox = new Kt()), this.boundingBox.makeEmpty();
    const e = t.getAttribute("position");
    for (let i = 0; i < e.count; i++)
      Ve.fromBufferAttribute(e, i), this.applyBoneTransform(i, Ve), this.boundingBox.expandByPoint(Ve);
  }
  computeBoundingSphere() {
    const t = this.geometry;
    this.boundingSphere === null && (this.boundingSphere = new Lt()), this.boundingSphere.makeEmpty();
    const e = t.getAttribute("position");
    for (let i = 0; i < e.count; i++)
      Ve.fromBufferAttribute(e, i), this.applyBoneTransform(i, Ve), this.boundingSphere.expandByPoint(Ve);
  }
  copy(t, e) {
    return super.copy(t, e), this.bindMode = t.bindMode, this.bindMatrix.copy(t.bindMatrix), this.bindMatrixInverse.copy(t.bindMatrixInverse), this.skeleton = t.skeleton, t.boundingBox !== null && (this.boundingBox = t.boundingBox.clone()), t.boundingSphere !== null && (this.boundingSphere = t.boundingSphere.clone()), this;
  }
  raycast(t, e) {
    const i = this.material, n = this.matrixWorld;
    i !== void 0 && (this.boundingSphere === null && this.computeBoundingSphere(), As.copy(this.boundingSphere), As.applyMatrix4(n), t.ray.intersectsSphere(As) !== !1 && (io.copy(n).invert(), Ms.copy(t.ray).applyMatrix4(io), !(this.boundingBox !== null && Ms.intersectsBox(this.boundingBox) === !1) && this._computeIntersections(t, e, Ms)));
  }
  getVertexPosition(t, e) {
    return super.getVertexPosition(t, e), this.applyBoneTransform(t, e), e;
  }
  bind(t, e) {
    this.skeleton = t, e === void 0 && (this.updateMatrixWorld(!0), this.skeleton.calculateInverses(), e = this.matrixWorld), this.bindMatrix.copy(e), this.bindMatrixInverse.copy(e).invert();
  }
  pose() {
    this.skeleton.pose();
  }
  normalizeSkinWeights() {
    const t = new _t(), e = this.geometry.attributes.skinWeight;
    for (let i = 0, n = e.count; i < n; i++) {
      t.fromBufferAttribute(e, i);
      const s = 1 / t.manhattanLength();
      s !== 1 / 0 ? t.multiplyScalar(s) : t.set(1, 0, 0, 0), e.setXYZW(i, t.x, t.y, t.z, t.w);
    }
  }
  updateMatrixWorld(t) {
    super.updateMatrixWorld(t), this.bindMode === "attached" ? this.bindMatrixInverse.copy(this.matrixWorld).invert() : this.bindMode === "detached" ? this.bindMatrixInverse.copy(this.bindMatrix).invert() : console.warn("THREE.SkinnedMesh: Unrecognized bindMode: " + this.bindMode);
  }
  applyBoneTransform(t, e) {
    const i = this.skeleton, n = this.geometry;
    Qa.fromBufferAttribute(n.attributes.skinIndex, t), to.fromBufferAttribute(n.attributes.skinWeight, t), Za.copy(e).applyMatrix4(this.bindMatrix), e.set(0, 0, 0);
    for (let s = 0; s < 4; s++) {
      const r = to.getComponent(s);
      if (r !== 0) {
        const o = Qa.getComponent(s);
        eo.multiplyMatrices(i.bones[o].matrixWorld, i.boneInverses[o]), e.addScaledVector(Qc.copy(Za).applyMatrix4(eo), r);
      }
    }
    return e.applyMatrix4(this.bindMatrixInverse);
  }
  boneTransform(t, e) {
    return console.warn("THREE.SkinnedMesh: .boneTransform() was renamed to .applyBoneTransform() in r151."), this.applyBoneTransform(t, e);
  }
}
class Dh extends q {
  constructor() {
    super(), this.isBone = !0, this.type = "Bone";
  }
}
class eu extends Et {
  constructor(t = null, e = 1, i = 1, n, s, r, o, h, l = ir, c = ir, u, d) {
    super(null, r, o, h, l, c, n, s, u, d), this.isDataTexture = !0, this.image = { data: t, width: e, height: i }, this.generateMipmaps = !1, this.flipY = !1, this.unpackAlignment = 1;
  }
}
const no = /* @__PURE__ */ new F(), iu = /* @__PURE__ */ new F();
class Vr {
  constructor(t = [], e = []) {
    this.uuid = Mt(), this.bones = t.slice(0), this.boneInverses = e, this.boneMatrices = null, this.boneTexture = null, this.boneTextureSize = 0, this.init();
  }
  init() {
    const t = this.bones, e = this.boneInverses;
    if (this.boneMatrices = new Float32Array(t.length * 16), e.length === 0)
      this.calculateInverses();
    else if (t.length !== e.length) {
      console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."), this.boneInverses = [];
      for (let i = 0, n = this.bones.length; i < n; i++)
        this.boneInverses.push(new F());
    }
  }
  calculateInverses() {
    this.boneInverses.length = 0;
    for (let t = 0, e = this.bones.length; t < e; t++) {
      const i = new F();
      this.bones[t] && i.copy(this.bones[t].matrixWorld).invert(), this.boneInverses.push(i);
    }
  }
  pose() {
    for (let t = 0, e = this.bones.length; t < e; t++) {
      const i = this.bones[t];
      i && i.matrixWorld.copy(this.boneInverses[t]).invert();
    }
    for (let t = 0, e = this.bones.length; t < e; t++) {
      const i = this.bones[t];
      i && (i.parent && i.parent.isBone ? (i.matrix.copy(i.parent.matrixWorld).invert(), i.matrix.multiply(i.matrixWorld)) : i.matrix.copy(i.matrixWorld), i.matrix.decompose(i.position, i.quaternion, i.scale));
    }
  }
  update() {
    const t = this.bones, e = this.boneInverses, i = this.boneMatrices, n = this.boneTexture;
    for (let s = 0, r = t.length; s < r; s++) {
      const o = t[s] ? t[s].matrixWorld : iu;
      no.multiplyMatrices(o, e[s]), no.toArray(i, s * 16);
    }
    n !== null && (n.needsUpdate = !0);
  }
  clone() {
    return new Vr(this.bones, this.boneInverses);
  }
  computeBoneTexture() {
    let t = Math.sqrt(this.bones.length * 4);
    t = Ih(t), t = Math.max(t, 4);
    const e = new Float32Array(t * t * 4);
    e.set(this.boneMatrices);
    const i = new eu(e, t, t, Th, Eh);
    return i.needsUpdate = !0, this.boneMatrices = e, this.boneTexture = i, this.boneTextureSize = t, this;
  }
  getBoneByName(t) {
    for (let e = 0, i = this.bones.length; e < i; e++) {
      const n = this.bones[e];
      if (n.name === t)
        return n;
    }
  }
  dispose() {
    this.boneTexture !== null && (this.boneTexture.dispose(), this.boneTexture = null);
  }
  fromJSON(t, e) {
    this.uuid = t.uuid;
    for (let i = 0, n = t.bones.length; i < n; i++) {
      const s = t.bones[i];
      let r = e[s];
      r === void 0 && (console.warn("THREE.Skeleton: No bone found with UUID:", s), r = new Dh()), this.bones.push(r), this.boneInverses.push(new F().fromArray(t.boneInverses[i]));
    }
    return this.init(), this;
  }
  toJSON() {
    const t = {
      metadata: {
        version: 4.6,
        type: "Skeleton",
        generator: "Skeleton.toJSON"
      },
      bones: [],
      boneInverses: []
    };
    t.uuid = this.uuid;
    const e = this.bones, i = this.boneInverses;
    for (let n = 0, s = e.length; n < s; n++) {
      const r = e[n];
      t.bones.push(r.uuid);
      const o = i[n];
      t.boneInverses.push(o.toArray());
    }
    return t;
  }
}
class so extends Tt {
  constructor(t, e, i, n = 1) {
    super(t, e, i), this.isInstancedBufferAttribute = !0, this.meshPerAttribute = n;
  }
  copy(t) {
    return super.copy(t), this.meshPerAttribute = t.meshPerAttribute, this;
  }
  toJSON() {
    const t = super.toJSON();
    return t.meshPerAttribute = this.meshPerAttribute, t.isInstancedBufferAttribute = !0, t;
  }
}
const We = /* @__PURE__ */ new F(), ro = /* @__PURE__ */ new F(), yn = [], ao = /* @__PURE__ */ new Kt(), nu = /* @__PURE__ */ new F(), gi = /* @__PURE__ */ new Se(), _i = /* @__PURE__ */ new Lt();
class su extends Se {
  constructor(t, e, i) {
    super(t, e), this.isInstancedMesh = !0, this.instanceMatrix = new so(new Float32Array(i * 16), 16), this.instanceColor = null, this.count = i, this.boundingBox = null, this.boundingSphere = null;
    for (let n = 0; n < i; n++)
      this.setMatrixAt(n, nu);
  }
  computeBoundingBox() {
    const t = this.geometry, e = this.count;
    this.boundingBox === null && (this.boundingBox = new Kt()), t.boundingBox === null && t.computeBoundingBox(), this.boundingBox.makeEmpty();
    for (let i = 0; i < e; i++)
      this.getMatrixAt(i, We), ao.copy(t.boundingBox).applyMatrix4(We), this.boundingBox.union(ao);
  }
  computeBoundingSphere() {
    const t = this.geometry, e = this.count;
    this.boundingSphere === null && (this.boundingSphere = new Lt()), t.boundingSphere === null && t.computeBoundingSphere(), this.boundingSphere.makeEmpty();
    for (let i = 0; i < e; i++)
      this.getMatrixAt(i, We), _i.copy(t.boundingSphere).applyMatrix4(We), this.boundingSphere.union(_i);
  }
  copy(t, e) {
    return super.copy(t, e), this.instanceMatrix.copy(t.instanceMatrix), t.instanceColor !== null && (this.instanceColor = t.instanceColor.clone()), this.count = t.count, t.boundingBox !== null && (this.boundingBox = t.boundingBox.clone()), t.boundingSphere !== null && (this.boundingSphere = t.boundingSphere.clone()), this;
  }
  getColorAt(t, e) {
    e.fromArray(this.instanceColor.array, t * 3);
  }
  getMatrixAt(t, e) {
    e.fromArray(this.instanceMatrix.array, t * 16);
  }
  raycast(t, e) {
    const i = this.matrixWorld, n = this.count;
    if (gi.geometry = this.geometry, gi.material = this.material, gi.material !== void 0 && (this.boundingSphere === null && this.computeBoundingSphere(), _i.copy(this.boundingSphere), _i.applyMatrix4(i), t.ray.intersectsSphere(_i) !== !1))
      for (let s = 0; s < n; s++) {
        this.getMatrixAt(s, We), ro.multiplyMatrices(i, We), gi.matrixWorld = ro, gi.raycast(t, yn);
        for (let r = 0, o = yn.length; r < o; r++) {
          const h = yn[r];
          h.instanceId = s, h.object = this, e.push(h);
        }
        yn.length = 0;
      }
  }
  setColorAt(t, e) {
    this.instanceColor === null && (this.instanceColor = new so(new Float32Array(this.instanceMatrix.count * 3), 3)), e.toArray(this.instanceColor.array, t * 3);
  }
  setMatrixAt(t, e) {
    e.toArray(this.instanceMatrix.array, t * 16);
  }
  updateMorphTargets() {
  }
  dispose() {
    this.dispatchEvent({ type: "dispose" });
  }
}
class jn extends Ee {
  constructor(t) {
    super(), this.isLineBasicMaterial = !0, this.type = "LineBasicMaterial", this.color = new J(16777215), this.map = null, this.linewidth = 1, this.linecap = "round", this.linejoin = "round", this.fog = !0, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.linewidth = t.linewidth, this.linecap = t.linecap, this.linejoin = t.linejoin, this.fog = t.fog, this;
  }
}
const oo = /* @__PURE__ */ new w(), ho = /* @__PURE__ */ new w(), lo = /* @__PURE__ */ new F(), Es = /* @__PURE__ */ new Oi(), gn = /* @__PURE__ */ new Lt();
class Li extends q {
  constructor(t = new Dt(), e = new jn()) {
    super(), this.isLine = !0, this.type = "Line", this.geometry = t, this.material = e, this.updateMorphTargets();
  }
  copy(t, e) {
    return super.copy(t, e), this.material = Array.isArray(t.material) ? t.material.slice() : t.material, this.geometry = t.geometry, this;
  }
  computeLineDistances() {
    const t = this.geometry;
    if (t.index === null) {
      const e = t.attributes.position, i = [0];
      for (let n = 1, s = e.count; n < s; n++)
        oo.fromBufferAttribute(e, n - 1), ho.fromBufferAttribute(e, n), i[n] = i[n - 1], i[n] += oo.distanceTo(ho);
      t.setAttribute("lineDistance", new Nt(i, 1));
    } else
      console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");
    return this;
  }
  raycast(t, e) {
    const i = this.geometry, n = this.matrixWorld, s = t.params.Line.threshold, r = i.drawRange;
    if (i.boundingSphere === null && i.computeBoundingSphere(), gn.copy(i.boundingSphere), gn.applyMatrix4(n), gn.radius += s, t.ray.intersectsSphere(gn) === !1)
      return;
    lo.copy(n).invert(), Es.copy(t.ray).applyMatrix4(lo);
    const o = s / ((this.scale.x + this.scale.y + this.scale.z) / 3), h = o * o, l = new w(), c = new w(), u = new w(), d = new w(), f = this.isLineSegments ? 2 : 1, p = i.index, m = i.attributes.position;
    if (p !== null) {
      const _ = Math.max(0, r.start), b = Math.min(p.count, r.start + r.count);
      for (let A = _, g = b - 1; A < g; A += f) {
        const x = p.getX(A), v = p.getX(A + 1);
        if (l.fromBufferAttribute(m, x), c.fromBufferAttribute(m, v), Es.distanceSqToSegment(l, c, d, u) > h)
          continue;
        d.applyMatrix4(this.matrixWorld);
        const T = t.ray.origin.distanceTo(d);
        T < t.near || T > t.far || e.push({
          distance: T,
          // What do we want? intersection point on the ray or on the segment??
          // point: raycaster.ray.at( distance ),
          point: u.clone().applyMatrix4(this.matrixWorld),
          index: A,
          face: null,
          faceIndex: null,
          object: this
        });
      }
    } else {
      const _ = Math.max(0, r.start), b = Math.min(m.count, r.start + r.count);
      for (let A = _, g = b - 1; A < g; A += f) {
        if (l.fromBufferAttribute(m, A), c.fromBufferAttribute(m, A + 1), Es.distanceSqToSegment(l, c, d, u) > h)
          continue;
        d.applyMatrix4(this.matrixWorld);
        const v = t.ray.origin.distanceTo(d);
        v < t.near || v > t.far || e.push({
          distance: v,
          // What do we want? intersection point on the ray or on the segment??
          // point: raycaster.ray.at( distance ),
          point: u.clone().applyMatrix4(this.matrixWorld),
          index: A,
          face: null,
          faceIndex: null,
          object: this
        });
      }
    }
  }
  updateMorphTargets() {
    const e = this.geometry.morphAttributes, i = Object.keys(e);
    if (i.length > 0) {
      const n = e[i[0]];
      if (n !== void 0) {
        this.morphTargetInfluences = [], this.morphTargetDictionary = {};
        for (let s = 0, r = n.length; s < r; s++) {
          const o = n[s].name || String(s);
          this.morphTargetInfluences.push(0), this.morphTargetDictionary[o] = s;
        }
      }
    }
  }
}
const co = /* @__PURE__ */ new w(), uo = /* @__PURE__ */ new w();
class ru extends Li {
  constructor(t, e) {
    super(t, e), this.isLineSegments = !0, this.type = "LineSegments";
  }
  computeLineDistances() {
    const t = this.geometry;
    if (t.index === null) {
      const e = t.attributes.position, i = [];
      for (let n = 0, s = e.count; n < s; n += 2)
        co.fromBufferAttribute(e, n), uo.fromBufferAttribute(e, n + 1), i[n] = n === 0 ? 0 : i[n - 1], i[n + 1] = i[n] + co.distanceTo(uo);
      t.setAttribute("lineDistance", new Nt(i, 1));
    } else
      console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");
    return this;
  }
}
class au extends Li {
  constructor(t, e) {
    super(t, e), this.isLineLoop = !0, this.type = "LineLoop";
  }
}
class Bh extends Ee {
  constructor(t) {
    super(), this.isPointsMaterial = !0, this.type = "PointsMaterial", this.color = new J(16777215), this.map = null, this.alphaMap = null, this.size = 1, this.sizeAttenuation = !0, this.fog = !0, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.color.copy(t.color), this.map = t.map, this.alphaMap = t.alphaMap, this.size = t.size, this.sizeAttenuation = t.sizeAttenuation, this.fog = t.fog, this;
  }
}
const fo = /* @__PURE__ */ new F(), hr = /* @__PURE__ */ new Oi(), _n = /* @__PURE__ */ new Lt(), xn = /* @__PURE__ */ new w();
class ou extends q {
  constructor(t = new Dt(), e = new Bh()) {
    super(), this.isPoints = !0, this.type = "Points", this.geometry = t, this.material = e, this.updateMorphTargets();
  }
  copy(t, e) {
    return super.copy(t, e), this.material = Array.isArray(t.material) ? t.material.slice() : t.material, this.geometry = t.geometry, this;
  }
  raycast(t, e) {
    const i = this.geometry, n = this.matrixWorld, s = t.params.Points.threshold, r = i.drawRange;
    if (i.boundingSphere === null && i.computeBoundingSphere(), _n.copy(i.boundingSphere), _n.applyMatrix4(n), _n.radius += s, t.ray.intersectsSphere(_n) === !1)
      return;
    fo.copy(n).invert(), hr.copy(t.ray).applyMatrix4(fo);
    const o = s / ((this.scale.x + this.scale.y + this.scale.z) / 3), h = o * o, l = i.index, u = i.attributes.position;
    if (l !== null) {
      const d = Math.max(0, r.start), f = Math.min(l.count, r.start + r.count);
      for (let p = d, y = f; p < y; p++) {
        const m = l.getX(p);
        xn.fromBufferAttribute(u, m), po(xn, m, h, n, t, e, this);
      }
    } else {
      const d = Math.max(0, r.start), f = Math.min(u.count, r.start + r.count);
      for (let p = d, y = f; p < y; p++)
        xn.fromBufferAttribute(u, p), po(xn, p, h, n, t, e, this);
    }
  }
  updateMorphTargets() {
    const e = this.geometry.morphAttributes, i = Object.keys(e);
    if (i.length > 0) {
      const n = e[i[0]];
      if (n !== void 0) {
        this.morphTargetInfluences = [], this.morphTargetDictionary = {};
        for (let s = 0, r = n.length; s < r; s++) {
          const o = n[s].name || String(s);
          this.morphTargetInfluences.push(0), this.morphTargetDictionary[o] = s;
        }
      }
    }
  }
}
function po(a, t, e, i, n, s, r) {
  const o = hr.distanceSqToPoint(a);
  if (o < e) {
    const h = new w();
    hr.closestPointToPoint(a, h), h.applyMatrix4(i);
    const l = n.ray.origin.distanceTo(h);
    if (l < n.near || l > n.far)
      return;
    s.push({
      distance: l,
      distanceToRay: Math.sqrt(o),
      point: h,
      index: t,
      face: null,
      object: r
    });
  }
}
class Wr extends Dt {
  constructor(t = 1, e = 1, i = 1, n = 32, s = 1, r = !1, o = 0, h = Math.PI * 2) {
    super(), this.type = "CylinderGeometry", this.parameters = {
      radiusTop: t,
      radiusBottom: e,
      height: i,
      radialSegments: n,
      heightSegments: s,
      openEnded: r,
      thetaStart: o,
      thetaLength: h
    };
    const l = this;
    n = Math.floor(n), s = Math.floor(s);
    const c = [], u = [], d = [], f = [];
    let p = 0;
    const y = [], m = i / 2;
    let _ = 0;
    b(), r === !1 && (t > 0 && A(!0), e > 0 && A(!1)), this.setIndex(c), this.setAttribute("position", new Nt(u, 3)), this.setAttribute("normal", new Nt(d, 3)), this.setAttribute("uv", new Nt(f, 2));
    function b() {
      const g = new w(), x = new w();
      let v = 0;
      const M = (e - t) / i;
      for (let T = 0; T <= s; T++) {
        const I = [], E = T / s, R = E * (e - t) + t;
        for (let S = 0; S <= n; S++) {
          const C = S / n, O = C * h + o, L = Math.sin(O), P = Math.cos(O);
          x.x = R * L, x.y = -E * i + m, x.z = R * P, u.push(x.x, x.y, x.z), g.set(L, M, P).normalize(), d.push(g.x, g.y, g.z), f.push(C, 1 - E), I.push(p++);
        }
        y.push(I);
      }
      for (let T = 0; T < n; T++)
        for (let I = 0; I < s; I++) {
          const E = y[I][T], R = y[I + 1][T], S = y[I + 1][T + 1], C = y[I][T + 1];
          c.push(E, R, C), c.push(R, S, C), v += 6;
        }
      l.addGroup(_, v, 0), _ += v;
    }
    function A(g) {
      const x = p, v = new G(), M = new w();
      let T = 0;
      const I = g === !0 ? t : e, E = g === !0 ? 1 : -1;
      for (let S = 1; S <= n; S++)
        u.push(0, m * E, 0), d.push(0, E, 0), f.push(0.5, 0.5), p++;
      const R = p;
      for (let S = 0; S <= n; S++) {
        const O = S / n * h + o, L = Math.cos(O), P = Math.sin(O);
        M.x = I * P, M.y = m * E, M.z = I * L, u.push(M.x, M.y, M.z), d.push(0, E, 0), v.x = L * 0.5 + 0.5, v.y = P * 0.5 * E + 0.5, f.push(v.x, v.y), p++;
      }
      for (let S = 0; S < n; S++) {
        const C = x + S, O = R + S;
        g === !0 ? c.push(O, O + 1, C) : c.push(O + 1, O, C), T += 3;
      }
      l.addGroup(_, T, g === !0 ? 1 : 2), _ += T;
    }
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new Wr(t.radiusTop, t.radiusBottom, t.height, t.radialSegments, t.heightSegments, t.openEnded, t.thetaStart, t.thetaLength);
  }
}
class qr extends Dt {
  constructor(t = 1, e = 32, i = 16, n = 0, s = Math.PI * 2, r = 0, o = Math.PI) {
    super(), this.type = "SphereGeometry", this.parameters = {
      radius: t,
      widthSegments: e,
      heightSegments: i,
      phiStart: n,
      phiLength: s,
      thetaStart: r,
      thetaLength: o
    }, e = Math.max(3, Math.floor(e)), i = Math.max(2, Math.floor(i));
    const h = Math.min(r + o, Math.PI);
    let l = 0;
    const c = [], u = new w(), d = new w(), f = [], p = [], y = [], m = [];
    for (let _ = 0; _ <= i; _++) {
      const b = [], A = _ / i;
      let g = 0;
      _ === 0 && r === 0 ? g = 0.5 / e : _ === i && h === Math.PI && (g = -0.5 / e);
      for (let x = 0; x <= e; x++) {
        const v = x / e;
        u.x = -t * Math.cos(n + v * s) * Math.sin(r + A * o), u.y = t * Math.cos(r + A * o), u.z = t * Math.sin(n + v * s) * Math.sin(r + A * o), p.push(u.x, u.y, u.z), d.copy(u).normalize(), y.push(d.x, d.y, d.z), m.push(v + g, 1 - A), b.push(l++);
      }
      c.push(b);
    }
    for (let _ = 0; _ < i; _++)
      for (let b = 0; b < e; b++) {
        const A = c[_][b + 1], g = c[_][b], x = c[_ + 1][b], v = c[_ + 1][b + 1];
        (_ !== 0 || r > 0) && f.push(A, g, v), (_ !== i - 1 || h < Math.PI) && f.push(g, x, v);
      }
    this.setIndex(f), this.setAttribute("position", new Nt(p, 3)), this.setAttribute("normal", new Nt(y, 3)), this.setAttribute("uv", new Nt(m, 2));
  }
  copy(t) {
    return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
  }
  static fromJSON(t) {
    return new qr(t.radius, t.widthSegments, t.heightSegments, t.phiStart, t.phiLength, t.thetaStart, t.thetaLength);
  }
}
class Gr extends Ee {
  constructor(t) {
    super(), this.isMeshStandardMaterial = !0, this.defines = { STANDARD: "" }, this.type = "MeshStandardMaterial", this.color = new J(16777215), this.roughness = 1, this.metalness = 0, this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.emissive = new J(0), this.emissiveIntensity = 1, this.emissiveMap = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = dc, this.normalScale = new G(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.roughnessMap = null, this.metalnessMap = null, this.alphaMap = null, this.envMap = null, this.envMapIntensity = 1, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.flatShading = !1, this.fog = !0, this.setValues(t);
  }
  copy(t) {
    return super.copy(t), this.defines = { STANDARD: "" }, this.color.copy(t.color), this.roughness = t.roughness, this.metalness = t.metalness, this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.emissive.copy(t.emissive), this.emissiveMap = t.emissiveMap, this.emissiveIntensity = t.emissiveIntensity, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.roughnessMap = t.roughnessMap, this.metalnessMap = t.metalnessMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.envMapIntensity = t.envMapIntensity, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.flatShading = t.flatShading, this.fog = t.fog, this;
  }
}
class de extends Gr {
  constructor(t) {
    super(), this.isMeshPhysicalMaterial = !0, this.defines = {
      STANDARD: "",
      PHYSICAL: ""
    }, this.type = "MeshPhysicalMaterial", this.anisotropyRotation = 0, this.anisotropyMap = null, this.clearcoatMap = null, this.clearcoatRoughness = 0, this.clearcoatRoughnessMap = null, this.clearcoatNormalScale = new G(1, 1), this.clearcoatNormalMap = null, this.ior = 1.5, Object.defineProperty(this, "reflectivity", {
      get: function() {
        return rt(2.5 * (this.ior - 1) / (this.ior + 1), 0, 1);
      },
      set: function(e) {
        this.ior = (1 + 0.4 * e) / (1 - 0.4 * e);
      }
    }), this.iridescenceMap = null, this.iridescenceIOR = 1.3, this.iridescenceThicknessRange = [100, 400], this.iridescenceThicknessMap = null, this.sheenColor = new J(0), this.sheenColorMap = null, this.sheenRoughness = 1, this.sheenRoughnessMap = null, this.transmissionMap = null, this.thickness = 0, this.thicknessMap = null, this.attenuationDistance = 1 / 0, this.attenuationColor = new J(1, 1, 1), this.specularIntensity = 1, this.specularIntensityMap = null, this.specularColor = new J(1, 1, 1), this.specularColorMap = null, this._anisotropy = 0, this._clearcoat = 0, this._iridescence = 0, this._sheen = 0, this._transmission = 0, this.setValues(t);
  }
  get anisotropy() {
    return this._anisotropy;
  }
  set anisotropy(t) {
    this._anisotropy > 0 != t > 0 && this.version++, this._anisotropy = t;
  }
  get clearcoat() {
    return this._clearcoat;
  }
  set clearcoat(t) {
    this._clearcoat > 0 != t > 0 && this.version++, this._clearcoat = t;
  }
  get iridescence() {
    return this._iridescence;
  }
  set iridescence(t) {
    this._iridescence > 0 != t > 0 && this.version++, this._iridescence = t;
  }
  get sheen() {
    return this._sheen;
  }
  set sheen(t) {
    this._sheen > 0 != t > 0 && this.version++, this._sheen = t;
  }
  get transmission() {
    return this._transmission;
  }
  set transmission(t) {
    this._transmission > 0 != t > 0 && this.version++, this._transmission = t;
  }
  copy(t) {
    return super.copy(t), this.defines = {
      STANDARD: "",
      PHYSICAL: ""
    }, this.anisotropy = t.anisotropy, this.anisotropyRotation = t.anisotropyRotation, this.anisotropyMap = t.anisotropyMap, this.clearcoat = t.clearcoat, this.clearcoatMap = t.clearcoatMap, this.clearcoatRoughness = t.clearcoatRoughness, this.clearcoatRoughnessMap = t.clearcoatRoughnessMap, this.clearcoatNormalMap = t.clearcoatNormalMap, this.clearcoatNormalScale.copy(t.clearcoatNormalScale), this.ior = t.ior, this.iridescence = t.iridescence, this.iridescenceMap = t.iridescenceMap, this.iridescenceIOR = t.iridescenceIOR, this.iridescenceThicknessRange = [...t.iridescenceThicknessRange], this.iridescenceThicknessMap = t.iridescenceThicknessMap, this.sheen = t.sheen, this.sheenColor.copy(t.sheenColor), this.sheenColorMap = t.sheenColorMap, this.sheenRoughness = t.sheenRoughness, this.sheenRoughnessMap = t.sheenRoughnessMap, this.transmission = t.transmission, this.transmissionMap = t.transmissionMap, this.thickness = t.thickness, this.thicknessMap = t.thicknessMap, this.attenuationDistance = t.attenuationDistance, this.attenuationColor.copy(t.attenuationColor), this.specularIntensity = t.specularIntensity, this.specularIntensityMap = t.specularIntensityMap, this.specularColor.copy(t.specularColor), this.specularColorMap = t.specularColorMap, this;
  }
}
function wn(a, t, e) {
  return !a || // let 'undefined' and 'null' pass
  !e && a.constructor === t ? a : typeof t.BYTES_PER_ELEMENT == "number" ? new t(a) : Array.prototype.slice.call(a);
}
function hu(a) {
  return ArrayBuffer.isView(a) && !(a instanceof DataView);
}
function lu(a) {
  function t(n, s) {
    return a[n] - a[s];
  }
  const e = a.length, i = new Array(e);
  for (let n = 0; n !== e; ++n)
    i[n] = n;
  return i.sort(t), i;
}
function mo(a, t, e) {
  const i = a.length, n = new a.constructor(i);
  for (let s = 0, r = 0; r !== i; ++s) {
    const o = e[s] * t;
    for (let h = 0; h !== t; ++h)
      n[r++] = a[o + h];
  }
  return n;
}
function Fh(a, t, e, i) {
  let n = 1, s = a[0];
  for (; s !== void 0 && s[i] === void 0; )
    s = a[n++];
  if (s === void 0)
    return;
  let r = s[i];
  if (r !== void 0)
    if (Array.isArray(r))
      do
        r = s[i], r !== void 0 && (t.push(s.time), e.push.apply(e, r)), s = a[n++];
      while (s !== void 0);
    else if (r.toArray !== void 0)
      do
        r = s[i], r !== void 0 && (t.push(s.time), r.toArray(e, e.length)), s = a[n++];
      while (s !== void 0);
    else
      do
        r = s[i], r !== void 0 && (t.push(s.time), e.push(r)), s = a[n++];
      while (s !== void 0);
}
class Di {
  constructor(t, e, i, n) {
    this.parameterPositions = t, this._cachedIndex = 0, this.resultBuffer = n !== void 0 ? n : new e.constructor(i), this.sampleValues = e, this.valueSize = i, this.settings = null, this.DefaultSettings_ = {};
  }
  evaluate(t) {
    const e = this.parameterPositions;
    let i = this._cachedIndex, n = e[i], s = e[i - 1];
    t: {
      e: {
        let r;
        i: {
          n:
            if (!(t < n)) {
              for (let o = i + 2; ; ) {
                if (n === void 0) {
                  if (t < s)
                    break n;
                  return i = e.length, this._cachedIndex = i, this.copySampleValue_(i - 1);
                }
                if (i === o)
                  break;
                if (s = n, n = e[++i], t < n)
                  break e;
              }
              r = e.length;
              break i;
            }
          if (!(t >= s)) {
            const o = e[1];
            t < o && (i = 2, s = o);
            for (let h = i - 2; ; ) {
              if (s === void 0)
                return this._cachedIndex = 0, this.copySampleValue_(0);
              if (i === h)
                break;
              if (n = s, s = e[--i - 1], t >= s)
                break e;
            }
            r = i, i = 0;
            break i;
          }
          break t;
        }
        for (; i < r; ) {
          const o = i + r >>> 1;
          t < e[o] ? r = o : i = o + 1;
        }
        if (n = e[i], s = e[i - 1], s === void 0)
          return this._cachedIndex = 0, this.copySampleValue_(0);
        if (n === void 0)
          return i = e.length, this._cachedIndex = i, this.copySampleValue_(i - 1);
      }
      this._cachedIndex = i, this.intervalChanged_(i, s, n);
    }
    return this.interpolate_(i, s, t, n);
  }
  getSettings_() {
    return this.settings || this.DefaultSettings_;
  }
  copySampleValue_(t) {
    const e = this.resultBuffer, i = this.sampleValues, n = this.valueSize, s = t * n;
    for (let r = 0; r !== n; ++r)
      e[r] = i[s + r];
    return e;
  }
  // Template methods for derived classes:
  interpolate_() {
    throw new Error("call to abstract method");
  }
  intervalChanged_() {
  }
}
class cu extends Di {
  constructor(t, e, i, n) {
    super(t, e, i, n), this._weightPrev = -0, this._offsetPrev = -0, this._weightNext = -0, this._offsetNext = -0, this.DefaultSettings_ = {
      endingStart: Ye,
      endingEnd: Ye
    };
  }
  intervalChanged_(t, e, i) {
    const n = this.parameterPositions;
    let s = t - 2, r = t + 1, o = n[s], h = n[r];
    if (o === void 0)
      switch (this.getSettings_().endingStart) {
        case Xe:
          s = t, o = 2 * e - i;
          break;
        case Bn:
          s = n.length - 2, o = e + n[s] - n[s + 1];
          break;
        default:
          s = t, o = i;
      }
    if (h === void 0)
      switch (this.getSettings_().endingEnd) {
        case Xe:
          r = t, h = 2 * i - e;
          break;
        case Bn:
          r = 1, h = i + n[1] - n[0];
          break;
        default:
          r = t - 1, h = e;
      }
    const l = (i - e) * 0.5, c = this.valueSize;
    this._weightPrev = l / (e - o), this._weightNext = l / (h - i), this._offsetPrev = s * c, this._offsetNext = r * c;
  }
  interpolate_(t, e, i, n) {
    const s = this.resultBuffer, r = this.sampleValues, o = this.valueSize, h = t * o, l = h - o, c = this._offsetPrev, u = this._offsetNext, d = this._weightPrev, f = this._weightNext, p = (i - e) / (n - e), y = p * p, m = y * p, _ = -d * m + 2 * d * y - d * p, b = (1 + d) * m + (-1.5 - 2 * d) * y + (-0.5 + d) * p + 1, A = (-1 - f) * m + (1.5 + f) * y + 0.5 * p, g = f * m - f * y;
    for (let x = 0; x !== o; ++x)
      s[x] = _ * r[c + x] + b * r[l + x] + A * r[h + x] + g * r[u + x];
    return s;
  }
}
class kh extends Di {
  constructor(t, e, i, n) {
    super(t, e, i, n);
  }
  interpolate_(t, e, i, n) {
    const s = this.resultBuffer, r = this.sampleValues, o = this.valueSize, h = t * o, l = h - o, c = (i - e) / (n - e), u = 1 - c;
    for (let d = 0; d !== o; ++d)
      s[d] = r[l + d] * u + r[h + d] * c;
    return s;
  }
}
class uu extends Di {
  constructor(t, e, i, n) {
    super(t, e, i, n);
  }
  interpolate_(t) {
    return this.copySampleValue_(t - 1);
  }
}
class Bt {
  constructor(t, e, i, n) {
    if (t === void 0)
      throw new Error("THREE.KeyframeTrack: track name is undefined");
    if (e === void 0 || e.length === 0)
      throw new Error("THREE.KeyframeTrack: no keyframes in track named " + t);
    this.name = t, this.times = wn(e, this.TimeBufferType), this.values = wn(i, this.ValueBufferType), this.setInterpolation(n || this.DefaultInterpolation);
  }
  // Serialization (in static context, because of constructor invocation
  // and automatic invocation of .toJSON):
  static toJSON(t) {
    const e = t.constructor;
    let i;
    if (e.toJSON !== this.toJSON)
      i = e.toJSON(t);
    else {
      i = {
        name: t.name,
        times: wn(t.times, Array),
        values: wn(t.values, Array)
      };
      const n = t.getInterpolation();
      n !== t.DefaultInterpolation && (i.interpolation = n);
    }
    return i.type = t.ValueTypeName, i;
  }
  InterpolantFactoryMethodDiscrete(t) {
    return new uu(this.times, this.values, this.getValueSize(), t);
  }
  InterpolantFactoryMethodLinear(t) {
    return new kh(this.times, this.values, this.getValueSize(), t);
  }
  InterpolantFactoryMethodSmooth(t) {
    return new cu(this.times, this.values, this.getValueSize(), t);
  }
  setInterpolation(t) {
    let e;
    switch (t) {
      case Pi:
        e = this.InterpolantFactoryMethodDiscrete;
        break;
      case ei:
        e = this.InterpolantFactoryMethodLinear;
        break;
      case es:
        e = this.InterpolantFactoryMethodSmooth;
        break;
    }
    if (e === void 0) {
      const i = "unsupported interpolation for " + this.ValueTypeName + " keyframe track named " + this.name;
      if (this.createInterpolant === void 0)
        if (t !== this.DefaultInterpolation)
          this.setInterpolation(this.DefaultInterpolation);
        else
          throw new Error(i);
      return console.warn("THREE.KeyframeTrack:", i), this;
    }
    return this.createInterpolant = e, this;
  }
  getInterpolation() {
    switch (this.createInterpolant) {
      case this.InterpolantFactoryMethodDiscrete:
        return Pi;
      case this.InterpolantFactoryMethodLinear:
        return ei;
      case this.InterpolantFactoryMethodSmooth:
        return es;
    }
  }
  getValueSize() {
    return this.values.length / this.times.length;
  }
  // move all keyframes either forwards or backwards in time
  shift(t) {
    if (t !== 0) {
      const e = this.times;
      for (let i = 0, n = e.length; i !== n; ++i)
        e[i] += t;
    }
    return this;
  }
  // scale all keyframe times by a factor (useful for frame <-> seconds conversions)
  scale(t) {
    if (t !== 1) {
      const e = this.times;
      for (let i = 0, n = e.length; i !== n; ++i)
        e[i] *= t;
    }
    return this;
  }
  // removes keyframes before and after animation without changing any values within the range [startTime, endTime].
  // IMPORTANT: We do not shift around keys to the start of the track time, because for interpolated keys this will change their values
  trim(t, e) {
    const i = this.times, n = i.length;
    let s = 0, r = n - 1;
    for (; s !== n && i[s] < t; )
      ++s;
    for (; r !== -1 && i[r] > e; )
      --r;
    if (++r, s !== 0 || r !== n) {
      s >= r && (r = Math.max(r, 1), s = r - 1);
      const o = this.getValueSize();
      this.times = i.slice(s, r), this.values = this.values.slice(s * o, r * o);
    }
    return this;
  }
  // ensure we do not get a GarbageInGarbageOut situation, make sure tracks are at least minimally viable
  validate() {
    let t = !0;
    const e = this.getValueSize();
    e - Math.floor(e) !== 0 && (console.error("THREE.KeyframeTrack: Invalid value size in track.", this), t = !1);
    const i = this.times, n = this.values, s = i.length;
    s === 0 && (console.error("THREE.KeyframeTrack: Track is empty.", this), t = !1);
    let r = null;
    for (let o = 0; o !== s; o++) {
      const h = i[o];
      if (typeof h == "number" && isNaN(h)) {
        console.error("THREE.KeyframeTrack: Time is not a valid number.", this, o, h), t = !1;
        break;
      }
      if (r !== null && r > h) {
        console.error("THREE.KeyframeTrack: Out of order keys.", this, o, h, r), t = !1;
        break;
      }
      r = h;
    }
    if (n !== void 0 && hu(n))
      for (let o = 0, h = n.length; o !== h; ++o) {
        const l = n[o];
        if (isNaN(l)) {
          console.error("THREE.KeyframeTrack: Value is not a valid number.", this, o, l), t = !1;
          break;
        }
      }
    return t;
  }
  // removes equivalent sequential keys as common in morph target sequences
  // (0,0,0,0,1,1,1,0,0,0,0,0,0,0) --> (0,0,1,1,0,0)
  optimize() {
    const t = this.times.slice(), e = this.values.slice(), i = this.getValueSize(), n = this.getInterpolation() === es, s = t.length - 1;
    let r = 1;
    for (let o = 1; o < s; ++o) {
      let h = !1;
      const l = t[o], c = t[o + 1];
      if (l !== c && (o !== 1 || l !== t[0]))
        if (n)
          h = !0;
        else {
          const u = o * i, d = u - i, f = u + i;
          for (let p = 0; p !== i; ++p) {
            const y = e[u + p];
            if (y !== e[d + p] || y !== e[f + p]) {
              h = !0;
              break;
            }
          }
        }
      if (h) {
        if (o !== r) {
          t[r] = t[o];
          const u = o * i, d = r * i;
          for (let f = 0; f !== i; ++f)
            e[d + f] = e[u + f];
        }
        ++r;
      }
    }
    if (s > 0) {
      t[r] = t[s];
      for (let o = s * i, h = r * i, l = 0; l !== i; ++l)
        e[h + l] = e[o + l];
      ++r;
    }
    return r !== t.length ? (this.times = t.slice(0, r), this.values = e.slice(0, r * i)) : (this.times = t, this.values = e), this;
  }
  clone() {
    const t = this.times.slice(), e = this.values.slice(), i = this.constructor, n = new i(this.name, t, e);
    return n.createInterpolant = this.createInterpolant, n;
  }
}
Bt.prototype.TimeBufferType = Float32Array;
Bt.prototype.ValueBufferType = Float32Array;
Bt.prototype.DefaultInterpolation = ei;
class ai extends Bt {
}
ai.prototype.ValueTypeName = "bool";
ai.prototype.ValueBufferType = Array;
ai.prototype.DefaultInterpolation = Pi;
ai.prototype.InterpolantFactoryMethodLinear = void 0;
ai.prototype.InterpolantFactoryMethodSmooth = void 0;
class zh extends Bt {
}
zh.prototype.ValueTypeName = "color";
class ii extends Bt {
}
ii.prototype.ValueTypeName = "number";
class du extends Di {
  constructor(t, e, i, n) {
    super(t, e, i, n);
  }
  interpolate_(t, e, i, n) {
    const s = this.resultBuffer, r = this.sampleValues, o = this.valueSize, h = (i - e) / (n - e);
    let l = t * o;
    for (let c = l + o; l !== c; l += 4)
      Q.slerpFlat(s, 0, r, l - o, r, l, h);
    return s;
  }
}
class Te extends Bt {
  InterpolantFactoryMethodLinear(t) {
    return new du(this.times, this.values, this.getValueSize(), t);
  }
}
Te.prototype.ValueTypeName = "quaternion";
Te.prototype.DefaultInterpolation = ei;
Te.prototype.InterpolantFactoryMethodSmooth = void 0;
class oi extends Bt {
}
oi.prototype.ValueTypeName = "string";
oi.prototype.ValueBufferType = Array;
oi.prototype.DefaultInterpolation = Pi;
oi.prototype.InterpolantFactoryMethodLinear = void 0;
oi.prototype.InterpolantFactoryMethodSmooth = void 0;
class ni extends Bt {
}
ni.prototype.ValueTypeName = "vector";
class lr {
  constructor(t, e = -1, i, n = Ur) {
    this.name = t, this.tracks = i, this.duration = e, this.blendMode = n, this.uuid = Mt(), this.duration < 0 && this.resetDuration();
  }
  static parse(t) {
    const e = [], i = t.tracks, n = 1 / (t.fps || 1);
    for (let r = 0, o = i.length; r !== o; ++r)
      e.push(pu(i[r]).scale(n));
    const s = new this(t.name, t.duration, e, t.blendMode);
    return s.uuid = t.uuid, s;
  }
  static toJSON(t) {
    const e = [], i = t.tracks, n = {
      name: t.name,
      duration: t.duration,
      tracks: e,
      uuid: t.uuid,
      blendMode: t.blendMode
    };
    for (let s = 0, r = i.length; s !== r; ++s)
      e.push(Bt.toJSON(i[s]));
    return n;
  }
  static CreateFromMorphTargetSequence(t, e, i, n) {
    const s = e.length, r = [];
    for (let o = 0; o < s; o++) {
      let h = [], l = [];
      h.push(
        (o + s - 1) % s,
        o,
        (o + 1) % s
      ), l.push(0, 1, 0);
      const c = lu(h);
      h = mo(h, 1, c), l = mo(l, 1, c), !n && h[0] === 0 && (h.push(s), l.push(l[0])), r.push(
        new ii(
          ".morphTargetInfluences[" + e[o].name + "]",
          h,
          l
        ).scale(1 / i)
      );
    }
    return new this(t, -1, r);
  }
  static findByName(t, e) {
    let i = t;
    if (!Array.isArray(t)) {
      const n = t;
      i = n.geometry && n.geometry.animations || n.animations;
    }
    for (let n = 0; n < i.length; n++)
      if (i[n].name === e)
        return i[n];
    return null;
  }
  static CreateClipsFromMorphTargetSequences(t, e, i) {
    const n = {}, s = /^([\w-]*?)([\d]+)$/;
    for (let o = 0, h = t.length; o < h; o++) {
      const l = t[o], c = l.name.match(s);
      if (c && c.length > 1) {
        const u = c[1];
        let d = n[u];
        d || (n[u] = d = []), d.push(l);
      }
    }
    const r = [];
    for (const o in n)
      r.push(this.CreateFromMorphTargetSequence(o, n[o], e, i));
    return r;
  }
  // parse the animation.hierarchy format
  static parseAnimation(t, e) {
    if (!t)
      return console.error("THREE.AnimationClip: No animation in JSONLoader data."), null;
    const i = function(u, d, f, p, y) {
      if (f.length !== 0) {
        const m = [], _ = [];
        Fh(f, m, _, p), m.length !== 0 && y.push(new u(d, m, _));
      }
    }, n = [], s = t.name || "default", r = t.fps || 30, o = t.blendMode;
    let h = t.length || -1;
    const l = t.hierarchy || [];
    for (let u = 0; u < l.length; u++) {
      const d = l[u].keys;
      if (!(!d || d.length === 0))
        if (d[0].morphTargets) {
          const f = {};
          let p;
          for (p = 0; p < d.length; p++)
            if (d[p].morphTargets)
              for (let y = 0; y < d[p].morphTargets.length; y++)
                f[d[p].morphTargets[y]] = -1;
          for (const y in f) {
            const m = [], _ = [];
            for (let b = 0; b !== d[p].morphTargets.length; ++b) {
              const A = d[p];
              m.push(A.time), _.push(A.morphTarget === y ? 1 : 0);
            }
            n.push(new ii(".morphTargetInfluence[" + y + "]", m, _));
          }
          h = f.length * r;
        } else {
          const f = ".bones[" + e[u].name + "]";
          i(
            ni,
            f + ".position",
            d,
            "pos",
            n
          ), i(
            Te,
            f + ".quaternion",
            d,
            "rot",
            n
          ), i(
            ni,
            f + ".scale",
            d,
            "scl",
            n
          );
        }
    }
    return n.length === 0 ? null : new this(s, h, n, o);
  }
  resetDuration() {
    const t = this.tracks;
    let e = 0;
    for (let i = 0, n = t.length; i !== n; ++i) {
      const s = this.tracks[i];
      e = Math.max(e, s.times[s.times.length - 1]);
    }
    return this.duration = e, this;
  }
  trim() {
    for (let t = 0; t < this.tracks.length; t++)
      this.tracks[t].trim(0, this.duration);
    return this;
  }
  validate() {
    let t = !0;
    for (let e = 0; e < this.tracks.length; e++)
      t = t && this.tracks[e].validate();
    return t;
  }
  optimize() {
    for (let t = 0; t < this.tracks.length; t++)
      this.tracks[t].optimize();
    return this;
  }
  clone() {
    const t = [];
    for (let e = 0; e < this.tracks.length; e++)
      t.push(this.tracks[e].clone());
    return new this.constructor(this.name, this.duration, t, this.blendMode);
  }
  toJSON() {
    return this.constructor.toJSON(this);
  }
}
function fu(a) {
  switch (a.toLowerCase()) {
    case "scalar":
    case "double":
    case "float":
    case "number":
    case "integer":
      return ii;
    case "vector":
    case "vector2":
    case "vector3":
    case "vector4":
      return ni;
    case "color":
      return zh;
    case "quaternion":
      return Te;
    case "bool":
    case "boolean":
      return ai;
    case "string":
      return oi;
  }
  throw new Error("THREE.KeyframeTrack: Unsupported typeName: " + a);
}
function pu(a) {
  if (a.type === void 0)
    throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");
  const t = fu(a.type);
  if (a.times === void 0) {
    const e = [], i = [];
    Fh(a.keys, e, i, "value"), a.times = e, a.values = i;
  }
  return t.parse !== void 0 ? t.parse(a) : new t(a.name, a.times, a.values, a.interpolation);
}
const si = {
  enabled: !1,
  files: {},
  add: function(a, t) {
    this.enabled !== !1 && (this.files[a] = t);
  },
  get: function(a) {
    if (this.enabled !== !1)
      return this.files[a];
  },
  remove: function(a) {
    delete this.files[a];
  },
  clear: function() {
    this.files = {};
  }
};
class mu {
  constructor(t, e, i) {
    const n = this;
    let s = !1, r = 0, o = 0, h;
    const l = [];
    this.onStart = void 0, this.onLoad = t, this.onProgress = e, this.onError = i, this.itemStart = function(c) {
      o++, s === !1 && n.onStart !== void 0 && n.onStart(c, r, o), s = !0;
    }, this.itemEnd = function(c) {
      r++, n.onProgress !== void 0 && n.onProgress(c, r, o), r === o && (s = !1, n.onLoad !== void 0 && n.onLoad());
    }, this.itemError = function(c) {
      n.onError !== void 0 && n.onError(c);
    }, this.resolveURL = function(c) {
      return h ? h(c) : c;
    }, this.setURLModifier = function(c) {
      return h = c, this;
    }, this.addHandler = function(c, u) {
      return l.push(c, u), this;
    }, this.removeHandler = function(c) {
      const u = l.indexOf(c);
      return u !== -1 && l.splice(u, 2), this;
    }, this.getHandler = function(c) {
      for (let u = 0, d = l.length; u < d; u += 2) {
        const f = l[u], p = l[u + 1];
        if (f.global && (f.lastIndex = 0), f.test(c))
          return p;
      }
      return null;
    };
  }
}
const yu = /* @__PURE__ */ new mu();
class hi {
  constructor(t) {
    this.manager = t !== void 0 ? t : yu, this.crossOrigin = "anonymous", this.withCredentials = !1, this.path = "", this.resourcePath = "", this.requestHeader = {};
  }
  load() {
  }
  loadAsync(t, e) {
    const i = this;
    return new Promise(function(n, s) {
      i.load(t, n, e, s);
    });
  }
  parse() {
  }
  setCrossOrigin(t) {
    return this.crossOrigin = t, this;
  }
  setWithCredentials(t) {
    return this.withCredentials = t, this;
  }
  setPath(t) {
    return this.path = t, this;
  }
  setResourcePath(t) {
    return this.resourcePath = t, this;
  }
  setRequestHeader(t) {
    return this.requestHeader = t, this;
  }
}
hi.DEFAULT_MATERIAL_NAME = "__DEFAULT";
const Wt = {};
class gu extends Error {
  constructor(t, e) {
    super(t), this.response = e;
  }
}
class Uh extends hi {
  constructor(t) {
    super(t);
  }
  load(t, e, i, n) {
    t === void 0 && (t = ""), this.path !== void 0 && (t = this.path + t), t = this.manager.resolveURL(t);
    const s = si.get(t);
    if (s !== void 0)
      return this.manager.itemStart(t), setTimeout(() => {
        e && e(s), this.manager.itemEnd(t);
      }, 0), s;
    if (Wt[t] !== void 0) {
      Wt[t].push({
        onLoad: e,
        onProgress: i,
        onError: n
      });
      return;
    }
    Wt[t] = [], Wt[t].push({
      onLoad: e,
      onProgress: i,
      onError: n
    });
    const r = new Request(t, {
      headers: new Headers(this.requestHeader),
      credentials: this.withCredentials ? "include" : "same-origin"
      // An abort controller could be added within a future PR
    }), o = this.mimeType, h = this.responseType;
    fetch(r).then((l) => {
      if (l.status === 200 || l.status === 0) {
        if (l.status === 0 && console.warn("THREE.FileLoader: HTTP Status 0 received."), typeof ReadableStream > "u" || l.body === void 0 || l.body.getReader === void 0)
          return l;
        const c = Wt[t], u = l.body.getReader(), d = l.headers.get("Content-Length") || l.headers.get("X-File-Size"), f = d ? parseInt(d) : 0, p = f !== 0;
        let y = 0;
        const m = new ReadableStream({
          start(_) {
            b();
            function b() {
              u.read().then(({ done: A, value: g }) => {
                if (A)
                  _.close();
                else {
                  y += g.byteLength;
                  const x = new ProgressEvent("progress", { lengthComputable: p, loaded: y, total: f });
                  for (let v = 0, M = c.length; v < M; v++) {
                    const T = c[v];
                    T.onProgress && T.onProgress(x);
                  }
                  _.enqueue(g), b();
                }
              });
            }
          }
        });
        return new Response(m);
      } else
        throw new gu(`fetch for "${l.url}" responded with ${l.status}: ${l.statusText}`, l);
    }).then((l) => {
      switch (h) {
        case "arraybuffer":
          return l.arrayBuffer();
        case "blob":
          return l.blob();
        case "document":
          return l.text().then((c) => new DOMParser().parseFromString(c, o));
        case "json":
          return l.json();
        default:
          if (o === void 0)
            return l.text();
          {
            const u = /charset="?([^;"\s]*)"?/i.exec(o), d = u && u[1] ? u[1].toLowerCase() : void 0, f = new TextDecoder(d);
            return l.arrayBuffer().then((p) => f.decode(p));
          }
      }
    }).then((l) => {
      si.add(t, l);
      const c = Wt[t];
      delete Wt[t];
      for (let u = 0, d = c.length; u < d; u++) {
        const f = c[u];
        f.onLoad && f.onLoad(l);
      }
    }).catch((l) => {
      const c = Wt[t];
      if (c === void 0)
        throw this.manager.itemError(t), l;
      delete Wt[t];
      for (let u = 0, d = c.length; u < d; u++) {
        const f = c[u];
        f.onError && f.onError(l);
      }
      this.manager.itemError(t);
    }).finally(() => {
      this.manager.itemEnd(t);
    }), this.manager.itemStart(t);
  }
  setResponseType(t) {
    return this.responseType = t, this;
  }
  setMimeType(t) {
    return this.mimeType = t, this;
  }
}
class _u extends hi {
  constructor(t) {
    super(t);
  }
  load(t, e, i, n) {
    this.path !== void 0 && (t = this.path + t), t = this.manager.resolveURL(t);
    const s = this, r = si.get(t);
    if (r !== void 0)
      return s.manager.itemStart(t), setTimeout(function() {
        e && e(r), s.manager.itemEnd(t);
      }, 0), r;
    const o = or("img");
    function h() {
      c(), si.add(t, this), e && e(this), s.manager.itemEnd(t);
    }
    function l(u) {
      c(), n && n(u), s.manager.itemError(t), s.manager.itemEnd(t);
    }
    function c() {
      o.removeEventListener("load", h, !1), o.removeEventListener("error", l, !1);
    }
    return o.addEventListener("load", h, !1), o.addEventListener("error", l, !1), t.slice(0, 5) !== "data:" && this.crossOrigin !== void 0 && (o.crossOrigin = this.crossOrigin), s.manager.itemStart(t), o.src = t, o;
  }
}
class jh extends hi {
  constructor(t) {
    super(t);
  }
  load(t, e, i, n) {
    const s = new Et(), r = new _u(this.manager);
    return r.setCrossOrigin(this.crossOrigin), r.setPath(this.path), r.load(t, function(o) {
      s.image = o, s.needsUpdate = !0, e !== void 0 && e(s);
    }, i, n), s;
  }
}
class Kr extends q {
  constructor(t, e = 1) {
    super(), this.isLight = !0, this.type = "Light", this.color = new J(t), this.intensity = e;
  }
  dispose() {
  }
  copy(t, e) {
    return super.copy(t, e), this.color.copy(t.color), this.intensity = t.intensity, this;
  }
  toJSON(t) {
    const e = super.toJSON(t);
    return e.object.color = this.color.getHex(), e.object.intensity = this.intensity, this.groundColor !== void 0 && (e.object.groundColor = this.groundColor.getHex()), this.distance !== void 0 && (e.object.distance = this.distance), this.angle !== void 0 && (e.object.angle = this.angle), this.decay !== void 0 && (e.object.decay = this.decay), this.penumbra !== void 0 && (e.object.penumbra = this.penumbra), this.shadow !== void 0 && (e.object.shadow = this.shadow.toJSON()), e;
  }
}
const Ts = /* @__PURE__ */ new F(), yo = /* @__PURE__ */ new w(), go = /* @__PURE__ */ new w();
class Yr {
  constructor(t) {
    this.camera = t, this.bias = 0, this.normalBias = 0, this.radius = 1, this.blurSamples = 8, this.mapSize = new G(512, 512), this.map = null, this.mapPass = null, this.matrix = new F(), this.autoUpdate = !0, this.needsUpdate = !1, this._frustum = new Jc(), this._frameExtents = new G(1, 1), this._viewportCount = 1, this._viewports = [
      new _t(0, 0, 1, 1)
    ];
  }
  getViewportCount() {
    return this._viewportCount;
  }
  getFrustum() {
    return this._frustum;
  }
  updateMatrices(t) {
    const e = this.camera, i = this.matrix;
    yo.setFromMatrixPosition(t.matrixWorld), e.position.copy(yo), go.setFromMatrixPosition(t.target.matrixWorld), e.lookAt(go), e.updateMatrixWorld(), Ts.multiplyMatrices(e.projectionMatrix, e.matrixWorldInverse), this._frustum.setFromProjectionMatrix(Ts), i.set(
      0.5,
      0,
      0,
      0.5,
      0,
      0.5,
      0,
      0.5,
      0,
      0,
      0.5,
      0.5,
      0,
      0,
      0,
      1
    ), i.multiply(Ts);
  }
  getViewport(t) {
    return this._viewports[t];
  }
  getFrameExtents() {
    return this._frameExtents;
  }
  dispose() {
    this.map && this.map.dispose(), this.mapPass && this.mapPass.dispose();
  }
  copy(t) {
    return this.camera = t.camera.clone(), this.bias = t.bias, this.radius = t.radius, this.mapSize.copy(t.mapSize), this;
  }
  clone() {
    return new this.constructor().copy(this);
  }
  toJSON() {
    const t = {};
    return this.bias !== 0 && (t.bias = this.bias), this.normalBias !== 0 && (t.normalBias = this.normalBias), this.radius !== 1 && (t.radius = this.radius), (this.mapSize.x !== 512 || this.mapSize.y !== 512) && (t.mapSize = this.mapSize.toArray()), t.camera = this.camera.toJSON(!1).object, delete t.camera.matrix, t;
  }
}
class xu extends Yr {
  constructor() {
    super(new Un(50, 1, 0.5, 500)), this.isSpotLightShadow = !0, this.focus = 1;
  }
  updateMatrices(t) {
    const e = this.camera, i = Ii * 2 * t.angle * this.focus, n = this.mapSize.width / this.mapSize.height, s = t.distance || e.far;
    (i !== e.fov || n !== e.aspect || s !== e.far) && (e.fov = i, e.aspect = n, e.far = s, e.updateProjectionMatrix()), super.updateMatrices(t);
  }
  copy(t) {
    return super.copy(t), this.focus = t.focus, this;
  }
}
class wu extends Kr {
  constructor(t, e, i = 0, n = Math.PI / 3, s = 0, r = 2) {
    super(t, e), this.isSpotLight = !0, this.type = "SpotLight", this.position.copy(q.DEFAULT_UP), this.updateMatrix(), this.target = new q(), this.distance = i, this.angle = n, this.penumbra = s, this.decay = r, this.map = null, this.shadow = new xu();
  }
  get power() {
    return this.intensity * Math.PI;
  }
  set power(t) {
    this.intensity = t / Math.PI;
  }
  dispose() {
    this.shadow.dispose();
  }
  copy(t, e) {
    return super.copy(t, e), this.distance = t.distance, this.angle = t.angle, this.penumbra = t.penumbra, this.decay = t.decay, this.target = t.target.clone(), this.shadow = t.shadow.clone(), this;
  }
}
const _o = /* @__PURE__ */ new F(), xi = /* @__PURE__ */ new w(), Ss = /* @__PURE__ */ new w();
class bu extends Yr {
  constructor() {
    super(new Un(90, 1, 0.5, 500)), this.isPointLightShadow = !0, this._frameExtents = new G(4, 2), this._viewportCount = 6, this._viewports = [
      // These viewports map a cube-map onto a 2D texture with the
      // following orientation:
      //
      //  xzXZ
      //   y Y
      //
      // X - Positive x direction
      // x - Negative x direction
      // Y - Positive y direction
      // y - Negative y direction
      // Z - Positive z direction
      // z - Negative z direction
      // positive X
      new _t(2, 1, 1, 1),
      // negative X
      new _t(0, 1, 1, 1),
      // positive Z
      new _t(3, 1, 1, 1),
      // negative Z
      new _t(1, 1, 1, 1),
      // positive Y
      new _t(3, 0, 1, 1),
      // negative Y
      new _t(1, 0, 1, 1)
    ], this._cubeDirections = [
      new w(1, 0, 0),
      new w(-1, 0, 0),
      new w(0, 0, 1),
      new w(0, 0, -1),
      new w(0, 1, 0),
      new w(0, -1, 0)
    ], this._cubeUps = [
      new w(0, 1, 0),
      new w(0, 1, 0),
      new w(0, 1, 0),
      new w(0, 1, 0),
      new w(0, 0, 1),
      new w(0, 0, -1)
    ];
  }
  updateMatrices(t, e = 0) {
    const i = this.camera, n = this.matrix, s = t.distance || i.far;
    s !== i.far && (i.far = s, i.updateProjectionMatrix()), xi.setFromMatrixPosition(t.matrixWorld), i.position.copy(xi), Ss.copy(i.position), Ss.add(this._cubeDirections[e]), i.up.copy(this._cubeUps[e]), i.lookAt(Ss), i.updateMatrixWorld(), n.makeTranslation(-xi.x, -xi.y, -xi.z), _o.multiplyMatrices(i.projectionMatrix, i.matrixWorldInverse), this._frustum.setFromProjectionMatrix(_o);
  }
}
class vu extends Kr {
  constructor(t, e, i = 0, n = 2) {
    super(t, e), this.isPointLight = !0, this.type = "PointLight", this.distance = i, this.decay = n, this.shadow = new bu();
  }
  get power() {
    return this.intensity * 4 * Math.PI;
  }
  set power(t) {
    this.intensity = t / (4 * Math.PI);
  }
  dispose() {
    this.shadow.dispose();
  }
  copy(t, e) {
    return super.copy(t, e), this.distance = t.distance, this.decay = t.decay, this.shadow = t.shadow.clone(), this;
  }
}
class Au extends Yr {
  constructor() {
    super(new Lh(-5, 5, 5, -5, 0.5, 500)), this.isDirectionalLightShadow = !0;
  }
}
class Mu extends Kr {
  constructor(t, e) {
    super(t, e), this.isDirectionalLight = !0, this.type = "DirectionalLight", this.position.copy(q.DEFAULT_UP), this.updateMatrix(), this.target = new q(), this.shadow = new Au();
  }
  dispose() {
    this.shadow.dispose();
  }
  copy(t) {
    return super.copy(t), this.target = t.target.clone(), this.shadow = t.shadow.clone(), this;
  }
}
class cr {
  static decodeText(t) {
    if (typeof TextDecoder < "u")
      return new TextDecoder().decode(t);
    let e = "";
    for (let i = 0, n = t.length; i < n; i++)
      e += String.fromCharCode(t[i]);
    try {
      return decodeURIComponent(escape(e));
    } catch {
      return e;
    }
  }
  static extractUrlBase(t) {
    const e = t.lastIndexOf("/");
    return e === -1 ? "./" : t.slice(0, e + 1);
  }
  static resolveURL(t, e) {
    return typeof t != "string" || t === "" ? "" : (/^https?:\/\//i.test(e) && /^\//.test(t) && (e = e.replace(/(^https?:\/\/[^\/]+).*/i, "$1")), /^(https?:)?\/\//i.test(t) || /^data:.*,.*$/i.test(t) || /^blob:.*$/i.test(t) ? t : e + t);
  }
}
class Eu extends hi {
  constructor(t) {
    super(t), this.isImageBitmapLoader = !0, typeof createImageBitmap > "u" && console.warn("THREE.ImageBitmapLoader: createImageBitmap() not supported."), typeof fetch > "u" && console.warn("THREE.ImageBitmapLoader: fetch() not supported."), this.options = { premultiplyAlpha: "none" };
  }
  setOptions(t) {
    return this.options = t, this;
  }
  load(t, e, i, n) {
    t === void 0 && (t = ""), this.path !== void 0 && (t = this.path + t), t = this.manager.resolveURL(t);
    const s = this, r = si.get(t);
    if (r !== void 0)
      return s.manager.itemStart(t), setTimeout(function() {
        e && e(r), s.manager.itemEnd(t);
      }, 0), r;
    const o = {};
    o.credentials = this.crossOrigin === "anonymous" ? "same-origin" : "include", o.headers = this.requestHeader, fetch(t, o).then(function(h) {
      return h.blob();
    }).then(function(h) {
      return createImageBitmap(h, Object.assign(s.options, { colorSpaceConversion: "none" }));
    }).then(function(h) {
      si.add(t, h), e && e(h), s.manager.itemEnd(t);
    }).catch(function(h) {
      n && n(h), s.manager.itemError(t), s.manager.itemEnd(t);
    }), s.manager.itemStart(t);
  }
}
class Hh {
  constructor(t = !0) {
    this.autoStart = t, this.startTime = 0, this.oldTime = 0, this.elapsedTime = 0, this.running = !1;
  }
  start() {
    this.startTime = xo(), this.oldTime = this.startTime, this.elapsedTime = 0, this.running = !0;
  }
  stop() {
    this.getElapsedTime(), this.running = !1, this.autoStart = !1;
  }
  getElapsedTime() {
    return this.getDelta(), this.elapsedTime;
  }
  getDelta() {
    let t = 0;
    if (this.autoStart && !this.running)
      return this.start(), 0;
    if (this.running) {
      const e = xo();
      t = (e - this.oldTime) / 1e3, this.oldTime = e, this.elapsedTime += t;
    }
    return t;
  }
}
function xo() {
  return (typeof performance > "u" ? Date : performance).now();
}
class Tu {
  constructor(t, e, i) {
    this.binding = t, this.valueSize = i;
    let n, s, r;
    switch (e) {
      case "quaternion":
        n = this._slerp, s = this._slerpAdditive, r = this._setAdditiveIdentityQuaternion, this.buffer = new Float64Array(i * 6), this._workIndex = 5;
        break;
      case "string":
      case "bool":
        n = this._select, s = this._select, r = this._setAdditiveIdentityOther, this.buffer = new Array(i * 5);
        break;
      default:
        n = this._lerp, s = this._lerpAdditive, r = this._setAdditiveIdentityNumeric, this.buffer = new Float64Array(i * 5);
    }
    this._mixBufferRegion = n, this._mixBufferRegionAdditive = s, this._setIdentity = r, this._origIndex = 3, this._addIndex = 4, this.cumulativeWeight = 0, this.cumulativeWeightAdditive = 0, this.useCount = 0, this.referenceCount = 0;
  }
  // accumulate data in the 'incoming' region into 'accu<i>'
  accumulate(t, e) {
    const i = this.buffer, n = this.valueSize, s = t * n + n;
    let r = this.cumulativeWeight;
    if (r === 0) {
      for (let o = 0; o !== n; ++o)
        i[s + o] = i[o];
      r = e;
    } else {
      r += e;
      const o = e / r;
      this._mixBufferRegion(i, s, 0, o, n);
    }
    this.cumulativeWeight = r;
  }
  // accumulate data in the 'incoming' region into 'add'
  accumulateAdditive(t) {
    const e = this.buffer, i = this.valueSize, n = i * this._addIndex;
    this.cumulativeWeightAdditive === 0 && this._setIdentity(), this._mixBufferRegionAdditive(e, n, 0, t, i), this.cumulativeWeightAdditive += t;
  }
  // apply the state of 'accu<i>' to the binding when accus differ
  apply(t) {
    const e = this.valueSize, i = this.buffer, n = t * e + e, s = this.cumulativeWeight, r = this.cumulativeWeightAdditive, o = this.binding;
    if (this.cumulativeWeight = 0, this.cumulativeWeightAdditive = 0, s < 1) {
      const h = e * this._origIndex;
      this._mixBufferRegion(
        i,
        n,
        h,
        1 - s,
        e
      );
    }
    r > 0 && this._mixBufferRegionAdditive(i, n, this._addIndex * e, 1, e);
    for (let h = e, l = e + e; h !== l; ++h)
      if (i[h] !== i[h + e]) {
        o.setValue(i, n);
        break;
      }
  }
  // remember the state of the bound property and copy it to both accus
  saveOriginalState() {
    const t = this.binding, e = this.buffer, i = this.valueSize, n = i * this._origIndex;
    t.getValue(e, n);
    for (let s = i, r = n; s !== r; ++s)
      e[s] = e[n + s % i];
    this._setIdentity(), this.cumulativeWeight = 0, this.cumulativeWeightAdditive = 0;
  }
  // apply the state previously taken via 'saveOriginalState' to the binding
  restoreOriginalState() {
    const t = this.valueSize * 3;
    this.binding.setValue(this.buffer, t);
  }
  _setAdditiveIdentityNumeric() {
    const t = this._addIndex * this.valueSize, e = t + this.valueSize;
    for (let i = t; i < e; i++)
      this.buffer[i] = 0;
  }
  _setAdditiveIdentityQuaternion() {
    this._setAdditiveIdentityNumeric(), this.buffer[this._addIndex * this.valueSize + 3] = 1;
  }
  _setAdditiveIdentityOther() {
    const t = this._origIndex * this.valueSize, e = this._addIndex * this.valueSize;
    for (let i = 0; i < this.valueSize; i++)
      this.buffer[e + i] = this.buffer[t + i];
  }
  // mix functions
  _select(t, e, i, n, s) {
    if (n >= 0.5)
      for (let r = 0; r !== s; ++r)
        t[e + r] = t[i + r];
  }
  _slerp(t, e, i, n) {
    Q.slerpFlat(t, e, t, e, t, i, n);
  }
  _slerpAdditive(t, e, i, n, s) {
    const r = this._workIndex * s;
    Q.multiplyQuaternionsFlat(t, r, t, e, t, i), Q.slerpFlat(t, e, t, e, t, r, n);
  }
  _lerp(t, e, i, n, s) {
    const r = 1 - n;
    for (let o = 0; o !== s; ++o) {
      const h = e + o;
      t[h] = t[h] * r + t[i + o] * n;
    }
  }
  _lerpAdditive(t, e, i, n, s) {
    for (let r = 0; r !== s; ++r) {
      const o = e + r;
      t[o] = t[o] + t[i + r] * n;
    }
  }
}
const Xr = "\\[\\]\\.:\\/", Su = new RegExp("[" + Xr + "]", "g"), Jr = "[^" + Xr + "]", Ru = "[^" + Xr.replace("\\.", "") + "]", Pu = /* @__PURE__ */ /((?:WC+[\/:])*)/.source.replace("WC", Jr), Iu = /* @__PURE__ */ /(WCOD+)?/.source.replace("WCOD", Ru), Cu = /* @__PURE__ */ /(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC", Jr), Ou = /* @__PURE__ */ /\.(WC+)(?:\[(.+)\])?/.source.replace("WC", Jr), Nu = new RegExp(
  "^" + Pu + Iu + Cu + Ou + "$"
), Lu = ["material", "materials", "bones", "map"];
class Du {
  constructor(t, e, i) {
    const n = i || j.parseTrackName(e);
    this._targetGroup = t, this._bindings = t.subscribe_(e, n);
  }
  getValue(t, e) {
    this.bind();
    const i = this._targetGroup.nCachedObjects_, n = this._bindings[i];
    n !== void 0 && n.getValue(t, e);
  }
  setValue(t, e) {
    const i = this._bindings;
    for (let n = this._targetGroup.nCachedObjects_, s = i.length; n !== s; ++n)
      i[n].setValue(t, e);
  }
  bind() {
    const t = this._bindings;
    for (let e = this._targetGroup.nCachedObjects_, i = t.length; e !== i; ++e)
      t[e].bind();
  }
  unbind() {
    const t = this._bindings;
    for (let e = this._targetGroup.nCachedObjects_, i = t.length; e !== i; ++e)
      t[e].unbind();
  }
}
class j {
  constructor(t, e, i) {
    this.path = e, this.parsedPath = i || j.parseTrackName(e), this.node = j.findNode(t, this.parsedPath.nodeName), this.rootNode = t, this.getValue = this._getValue_unbound, this.setValue = this._setValue_unbound;
  }
  static create(t, e, i) {
    return t && t.isAnimationObjectGroup ? new j.Composite(t, e, i) : new j(t, e, i);
  }
  /**
   * Replaces spaces with underscores and removes unsupported characters from
   * node names, to ensure compatibility with parseTrackName().
   *
   * @param {string} name Node name to be sanitized.
   * @return {string}
   */
  static sanitizeNodeName(t) {
    return t.replace(/\s/g, "_").replace(Su, "");
  }
  static parseTrackName(t) {
    const e = Nu.exec(t);
    if (e === null)
      throw new Error("PropertyBinding: Cannot parse trackName: " + t);
    const i = {
      // directoryName: matches[ 1 ], // (tschw) currently unused
      nodeName: e[2],
      objectName: e[3],
      objectIndex: e[4],
      propertyName: e[5],
      // required
      propertyIndex: e[6]
    }, n = i.nodeName && i.nodeName.lastIndexOf(".");
    if (n !== void 0 && n !== -1) {
      const s = i.nodeName.substring(n + 1);
      Lu.indexOf(s) !== -1 && (i.nodeName = i.nodeName.substring(0, n), i.objectName = s);
    }
    if (i.propertyName === null || i.propertyName.length === 0)
      throw new Error("PropertyBinding: can not parse propertyName from trackName: " + t);
    return i;
  }
  static findNode(t, e) {
    if (e === void 0 || e === "" || e === "." || e === -1 || e === t.name || e === t.uuid)
      return t;
    if (t.skeleton) {
      const i = t.skeleton.getBoneByName(e);
      if (i !== void 0)
        return i;
    }
    if (t.children) {
      const i = function(s) {
        for (let r = 0; r < s.length; r++) {
          const o = s[r];
          if (o.name === e || o.uuid === e)
            return o;
          const h = i(o.children);
          if (h)
            return h;
        }
        return null;
      }, n = i(t.children);
      if (n)
        return n;
    }
    return null;
  }
  // these are used to "bind" a nonexistent property
  _getValue_unavailable() {
  }
  _setValue_unavailable() {
  }
  // Getters
  _getValue_direct(t, e) {
    t[e] = this.targetObject[this.propertyName];
  }
  _getValue_array(t, e) {
    const i = this.resolvedProperty;
    for (let n = 0, s = i.length; n !== s; ++n)
      t[e++] = i[n];
  }
  _getValue_arrayElement(t, e) {
    t[e] = this.resolvedProperty[this.propertyIndex];
  }
  _getValue_toArray(t, e) {
    this.resolvedProperty.toArray(t, e);
  }
  // Direct
  _setValue_direct(t, e) {
    this.targetObject[this.propertyName] = t[e];
  }
  _setValue_direct_setNeedsUpdate(t, e) {
    this.targetObject[this.propertyName] = t[e], this.targetObject.needsUpdate = !0;
  }
  _setValue_direct_setMatrixWorldNeedsUpdate(t, e) {
    this.targetObject[this.propertyName] = t[e], this.targetObject.matrixWorldNeedsUpdate = !0;
  }
  // EntireArray
  _setValue_array(t, e) {
    const i = this.resolvedProperty;
    for (let n = 0, s = i.length; n !== s; ++n)
      i[n] = t[e++];
  }
  _setValue_array_setNeedsUpdate(t, e) {
    const i = this.resolvedProperty;
    for (let n = 0, s = i.length; n !== s; ++n)
      i[n] = t[e++];
    this.targetObject.needsUpdate = !0;
  }
  _setValue_array_setMatrixWorldNeedsUpdate(t, e) {
    const i = this.resolvedProperty;
    for (let n = 0, s = i.length; n !== s; ++n)
      i[n] = t[e++];
    this.targetObject.matrixWorldNeedsUpdate = !0;
  }
  // ArrayElement
  _setValue_arrayElement(t, e) {
    this.resolvedProperty[this.propertyIndex] = t[e];
  }
  _setValue_arrayElement_setNeedsUpdate(t, e) {
    this.resolvedProperty[this.propertyIndex] = t[e], this.targetObject.needsUpdate = !0;
  }
  _setValue_arrayElement_setMatrixWorldNeedsUpdate(t, e) {
    this.resolvedProperty[this.propertyIndex] = t[e], this.targetObject.matrixWorldNeedsUpdate = !0;
  }
  // HasToFromArray
  _setValue_fromArray(t, e) {
    this.resolvedProperty.fromArray(t, e);
  }
  _setValue_fromArray_setNeedsUpdate(t, e) {
    this.resolvedProperty.fromArray(t, e), this.targetObject.needsUpdate = !0;
  }
  _setValue_fromArray_setMatrixWorldNeedsUpdate(t, e) {
    this.resolvedProperty.fromArray(t, e), this.targetObject.matrixWorldNeedsUpdate = !0;
  }
  _getValue_unbound(t, e) {
    this.bind(), this.getValue(t, e);
  }
  _setValue_unbound(t, e) {
    this.bind(), this.setValue(t, e);
  }
  // create getter / setter pair for a property in the scene graph
  bind() {
    let t = this.node;
    const e = this.parsedPath, i = e.objectName, n = e.propertyName;
    let s = e.propertyIndex;
    if (t || (t = j.findNode(this.rootNode, e.nodeName), this.node = t), this.getValue = this._getValue_unavailable, this.setValue = this._setValue_unavailable, !t) {
      console.warn("THREE.PropertyBinding: No target node found for track: " + this.path + ".");
      return;
    }
    if (i) {
      let l = e.objectIndex;
      switch (i) {
        case "materials":
          if (!t.material) {
            console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.", this);
            return;
          }
          if (!t.material.materials) {
            console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.", this);
            return;
          }
          t = t.material.materials;
          break;
        case "bones":
          if (!t.skeleton) {
            console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.", this);
            return;
          }
          t = t.skeleton.bones;
          for (let c = 0; c < t.length; c++)
            if (t[c].name === l) {
              l = c;
              break;
            }
          break;
        case "map":
          if ("map" in t) {
            t = t.map;
            break;
          }
          if (!t.material) {
            console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.", this);
            return;
          }
          if (!t.material.map) {
            console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.", this);
            return;
          }
          t = t.material.map;
          break;
        default:
          if (t[i] === void 0) {
            console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.", this);
            return;
          }
          t = t[i];
      }
      if (l !== void 0) {
        if (t[l] === void 0) {
          console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.", this, t);
          return;
        }
        t = t[l];
      }
    }
    const r = t[n];
    if (r === void 0) {
      const l = e.nodeName;
      console.error("THREE.PropertyBinding: Trying to update property for track: " + l + "." + n + " but it wasn't found.", t);
      return;
    }
    let o = this.Versioning.None;
    this.targetObject = t, t.needsUpdate !== void 0 ? o = this.Versioning.NeedsUpdate : t.matrixWorldNeedsUpdate !== void 0 && (o = this.Versioning.MatrixWorldNeedsUpdate);
    let h = this.BindingType.Direct;
    if (s !== void 0) {
      if (n === "morphTargetInfluences") {
        if (!t.geometry) {
          console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.", this);
          return;
        }
        if (!t.geometry.morphAttributes) {
          console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.", this);
          return;
        }
        t.morphTargetDictionary[s] !== void 0 && (s = t.morphTargetDictionary[s]);
      }
      h = this.BindingType.ArrayElement, this.resolvedProperty = r, this.propertyIndex = s;
    } else
      r.fromArray !== void 0 && r.toArray !== void 0 ? (h = this.BindingType.HasFromToArray, this.resolvedProperty = r) : Array.isArray(r) ? (h = this.BindingType.EntireArray, this.resolvedProperty = r) : this.propertyName = n;
    this.getValue = this.GetterByBindingType[h], this.setValue = this.SetterByBindingTypeAndVersioning[h][o];
  }
  unbind() {
    this.node = null, this.getValue = this._getValue_unbound, this.setValue = this._setValue_unbound;
  }
}
j.Composite = Du;
j.prototype.BindingType = {
  Direct: 0,
  EntireArray: 1,
  ArrayElement: 2,
  HasFromToArray: 3
};
j.prototype.Versioning = {
  None: 0,
  NeedsUpdate: 1,
  MatrixWorldNeedsUpdate: 2
};
j.prototype.GetterByBindingType = [
  j.prototype._getValue_direct,
  j.prototype._getValue_array,
  j.prototype._getValue_arrayElement,
  j.prototype._getValue_toArray
];
j.prototype.SetterByBindingTypeAndVersioning = [
  [
    // Direct
    j.prototype._setValue_direct,
    j.prototype._setValue_direct_setNeedsUpdate,
    j.prototype._setValue_direct_setMatrixWorldNeedsUpdate
  ],
  [
    // EntireArray
    j.prototype._setValue_array,
    j.prototype._setValue_array_setNeedsUpdate,
    j.prototype._setValue_array_setMatrixWorldNeedsUpdate
  ],
  [
    // ArrayElement
    j.prototype._setValue_arrayElement,
    j.prototype._setValue_arrayElement_setNeedsUpdate,
    j.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate
  ],
  [
    // HasToFromArray
    j.prototype._setValue_fromArray,
    j.prototype._setValue_fromArray_setNeedsUpdate,
    j.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate
  ]
];
class Bu {
  constructor(t, e, i = null, n = e.blendMode) {
    this._mixer = t, this._clip = e, this._localRoot = i, this.blendMode = n;
    const s = e.tracks, r = s.length, o = new Array(r), h = {
      endingStart: Ye,
      endingEnd: Ye
    };
    for (let l = 0; l !== r; ++l) {
      const c = s[l].createInterpolant(null);
      o[l] = c, c.settings = h;
    }
    this._interpolantSettings = h, this._interpolants = o, this._propertyBindings = new Array(r), this._cacheIndex = null, this._byClipCacheIndex = null, this._timeScaleInterpolant = null, this._weightInterpolant = null, this.loop = Sh, this._loopCount = -1, this._startTime = null, this.time = 0, this.timeScale = 1, this._effectiveTimeScale = 1, this.weight = 1, this._effectiveWeight = 1, this.repetitions = 1 / 0, this.paused = !1, this.enabled = !0, this.clampWhenFinished = !1, this.zeroSlopeAtStart = !0, this.zeroSlopeAtEnd = !0;
  }
  // State & Scheduling
  play() {
    return this._mixer._activateAction(this), this;
  }
  stop() {
    return this._mixer._deactivateAction(this), this.reset();
  }
  reset() {
    return this.paused = !1, this.enabled = !0, this.time = 0, this._loopCount = -1, this._startTime = null, this.stopFading().stopWarping();
  }
  isRunning() {
    return this.enabled && !this.paused && this.timeScale !== 0 && this._startTime === null && this._mixer._isActiveAction(this);
  }
  // return true when play has been called
  isScheduled() {
    return this._mixer._isActiveAction(this);
  }
  startAt(t) {
    return this._startTime = t, this;
  }
  setLoop(t, e) {
    return this.loop = t, this.repetitions = e, this;
  }
  // Weight
  // set the weight stopping any scheduled fading
  // although .enabled = false yields an effective weight of zero, this
  // method does *not* change .enabled, because it would be confusing
  setEffectiveWeight(t) {
    return this.weight = t, this._effectiveWeight = this.enabled ? t : 0, this.stopFading();
  }
  // return the weight considering fading and .enabled
  getEffectiveWeight() {
    return this._effectiveWeight;
  }
  fadeIn(t) {
    return this._scheduleFading(t, 0, 1);
  }
  fadeOut(t) {
    return this._scheduleFading(t, 1, 0);
  }
  crossFadeFrom(t, e, i) {
    if (t.fadeOut(e), this.fadeIn(e), i) {
      const n = this._clip.duration, s = t._clip.duration, r = s / n, o = n / s;
      t.warp(1, r, e), this.warp(o, 1, e);
    }
    return this;
  }
  crossFadeTo(t, e, i) {
    return t.crossFadeFrom(this, e, i);
  }
  stopFading() {
    const t = this._weightInterpolant;
    return t !== null && (this._weightInterpolant = null, this._mixer._takeBackControlInterpolant(t)), this;
  }
  // Time Scale Control
  // set the time scale stopping any scheduled warping
  // although .paused = true yields an effective time scale of zero, this
  // method does *not* change .paused, because it would be confusing
  setEffectiveTimeScale(t) {
    return this.timeScale = t, this._effectiveTimeScale = this.paused ? 0 : t, this.stopWarping();
  }
  // return the time scale considering warping and .paused
  getEffectiveTimeScale() {
    return this._effectiveTimeScale;
  }
  setDuration(t) {
    return this.timeScale = this._clip.duration / t, this.stopWarping();
  }
  syncWith(t) {
    return this.time = t.time, this.timeScale = t.timeScale, this.stopWarping();
  }
  halt(t) {
    return this.warp(this._effectiveTimeScale, 0, t);
  }
  warp(t, e, i) {
    const n = this._mixer, s = n.time, r = this.timeScale;
    let o = this._timeScaleInterpolant;
    o === null && (o = n._lendControlInterpolant(), this._timeScaleInterpolant = o);
    const h = o.parameterPositions, l = o.sampleValues;
    return h[0] = s, h[1] = s + i, l[0] = t / r, l[1] = e / r, this;
  }
  stopWarping() {
    const t = this._timeScaleInterpolant;
    return t !== null && (this._timeScaleInterpolant = null, this._mixer._takeBackControlInterpolant(t)), this;
  }
  // Object Accessors
  getMixer() {
    return this._mixer;
  }
  getClip() {
    return this._clip;
  }
  getRoot() {
    return this._localRoot || this._mixer._root;
  }
  // Interna
  _update(t, e, i, n) {
    if (!this.enabled) {
      this._updateWeight(t);
      return;
    }
    const s = this._startTime;
    if (s !== null) {
      const h = (t - s) * i;
      h < 0 || i === 0 ? e = 0 : (this._startTime = null, e = i * h);
    }
    e *= this._updateTimeScale(t);
    const r = this._updateTime(e), o = this._updateWeight(t);
    if (o > 0) {
      const h = this._interpolants, l = this._propertyBindings;
      switch (this.blendMode) {
        case lc:
          for (let c = 0, u = h.length; c !== u; ++c)
            h[c].evaluate(r), l[c].accumulateAdditive(o);
          break;
        case Ur:
        default:
          for (let c = 0, u = h.length; c !== u; ++c)
            h[c].evaluate(r), l[c].accumulate(n, o);
      }
    }
  }
  _updateWeight(t) {
    let e = 0;
    if (this.enabled) {
      e = this.weight;
      const i = this._weightInterpolant;
      if (i !== null) {
        const n = i.evaluate(t)[0];
        e *= n, t > i.parameterPositions[1] && (this.stopFading(), n === 0 && (this.enabled = !1));
      }
    }
    return this._effectiveWeight = e, e;
  }
  _updateTimeScale(t) {
    let e = 0;
    if (!this.paused) {
      e = this.timeScale;
      const i = this._timeScaleInterpolant;
      if (i !== null) {
        const n = i.evaluate(t)[0];
        e *= n, t > i.parameterPositions[1] && (this.stopWarping(), e === 0 ? this.paused = !0 : this.timeScale = e);
      }
    }
    return this._effectiveTimeScale = e, e;
  }
  _updateTime(t) {
    const e = this._clip.duration, i = this.loop;
    let n = this.time + t, s = this._loopCount;
    const r = i === hc;
    if (t === 0)
      return s === -1 ? n : r && (s & 1) === 1 ? e - n : n;
    if (i === oc) {
      s === -1 && (this._loopCount = 0, this._setEndings(!0, !0, !1));
      t: {
        if (n >= e)
          n = e;
        else if (n < 0)
          n = 0;
        else {
          this.time = n;
          break t;
        }
        this.clampWhenFinished ? this.paused = !0 : this.enabled = !1, this.time = n, this._mixer.dispatchEvent({
          type: "finished",
          action: this,
          direction: t < 0 ? -1 : 1
        });
      }
    } else {
      if (s === -1 && (t >= 0 ? (s = 0, this._setEndings(!0, this.repetitions === 0, r)) : this._setEndings(this.repetitions === 0, !0, r)), n >= e || n < 0) {
        const o = Math.floor(n / e);
        n -= e * o, s += Math.abs(o);
        const h = this.repetitions - s;
        if (h <= 0)
          this.clampWhenFinished ? this.paused = !0 : this.enabled = !1, n = t > 0 ? e : 0, this.time = n, this._mixer.dispatchEvent({
            type: "finished",
            action: this,
            direction: t > 0 ? 1 : -1
          });
        else {
          if (h === 1) {
            const l = t < 0;
            this._setEndings(l, !l, r);
          } else
            this._setEndings(!1, !1, r);
          this._loopCount = s, this.time = n, this._mixer.dispatchEvent({
            type: "loop",
            action: this,
            loopDelta: o
          });
        }
      } else
        this.time = n;
      if (r && (s & 1) === 1)
        return e - n;
    }
    return n;
  }
  _setEndings(t, e, i) {
    const n = this._interpolantSettings;
    i ? (n.endingStart = Xe, n.endingEnd = Xe) : (t ? n.endingStart = this.zeroSlopeAtStart ? Xe : Ye : n.endingStart = Bn, e ? n.endingEnd = this.zeroSlopeAtEnd ? Xe : Ye : n.endingEnd = Bn);
  }
  _scheduleFading(t, e, i) {
    const n = this._mixer, s = n.time;
    let r = this._weightInterpolant;
    r === null && (r = n._lendControlInterpolant(), this._weightInterpolant = r);
    const o = r.parameterPositions, h = r.sampleValues;
    return o[0] = s, h[0] = e, o[1] = s + t, h[1] = i, this;
  }
}
const Fu = new Float32Array(1);
class ku extends Ci {
  constructor(t) {
    super(), this._root = t, this._initMemoryManager(), this._accuIndex = 0, this.time = 0, this.timeScale = 1;
  }
  _bindAction(t, e) {
    const i = t._localRoot || this._root, n = t._clip.tracks, s = n.length, r = t._propertyBindings, o = t._interpolants, h = i.uuid, l = this._bindingsByRootAndName;
    let c = l[h];
    c === void 0 && (c = {}, l[h] = c);
    for (let u = 0; u !== s; ++u) {
      const d = n[u], f = d.name;
      let p = c[f];
      if (p !== void 0)
        ++p.referenceCount, r[u] = p;
      else {
        if (p = r[u], p !== void 0) {
          p._cacheIndex === null && (++p.referenceCount, this._addInactiveBinding(p, h, f));
          continue;
        }
        const y = e && e._propertyBindings[u].binding.parsedPath;
        p = new Tu(
          j.create(i, f, y),
          d.ValueTypeName,
          d.getValueSize()
        ), ++p.referenceCount, this._addInactiveBinding(p, h, f), r[u] = p;
      }
      o[u].resultBuffer = p.buffer;
    }
  }
  _activateAction(t) {
    if (!this._isActiveAction(t)) {
      if (t._cacheIndex === null) {
        const i = (t._localRoot || this._root).uuid, n = t._clip.uuid, s = this._actionsByClip[n];
        this._bindAction(
          t,
          s && s.knownActions[0]
        ), this._addInactiveAction(t, n, i);
      }
      const e = t._propertyBindings;
      for (let i = 0, n = e.length; i !== n; ++i) {
        const s = e[i];
        s.useCount++ === 0 && (this._lendBinding(s), s.saveOriginalState());
      }
      this._lendAction(t);
    }
  }
  _deactivateAction(t) {
    if (this._isActiveAction(t)) {
      const e = t._propertyBindings;
      for (let i = 0, n = e.length; i !== n; ++i) {
        const s = e[i];
        --s.useCount === 0 && (s.restoreOriginalState(), this._takeBackBinding(s));
      }
      this._takeBackAction(t);
    }
  }
  // Memory manager
  _initMemoryManager() {
    this._actions = [], this._nActiveActions = 0, this._actionsByClip = {}, this._bindings = [], this._nActiveBindings = 0, this._bindingsByRootAndName = {}, this._controlInterpolants = [], this._nActiveControlInterpolants = 0;
    const t = this;
    this.stats = {
      actions: {
        get total() {
          return t._actions.length;
        },
        get inUse() {
          return t._nActiveActions;
        }
      },
      bindings: {
        get total() {
          return t._bindings.length;
        },
        get inUse() {
          return t._nActiveBindings;
        }
      },
      controlInterpolants: {
        get total() {
          return t._controlInterpolants.length;
        },
        get inUse() {
          return t._nActiveControlInterpolants;
        }
      }
    };
  }
  // Memory management for AnimationAction objects
  _isActiveAction(t) {
    const e = t._cacheIndex;
    return e !== null && e < this._nActiveActions;
  }
  _addInactiveAction(t, e, i) {
    const n = this._actions, s = this._actionsByClip;
    let r = s[e];
    if (r === void 0)
      r = {
        knownActions: [t],
        actionByRoot: {}
      }, t._byClipCacheIndex = 0, s[e] = r;
    else {
      const o = r.knownActions;
      t._byClipCacheIndex = o.length, o.push(t);
    }
    t._cacheIndex = n.length, n.push(t), r.actionByRoot[i] = t;
  }
  _removeInactiveAction(t) {
    const e = this._actions, i = e[e.length - 1], n = t._cacheIndex;
    i._cacheIndex = n, e[n] = i, e.pop(), t._cacheIndex = null;
    const s = t._clip.uuid, r = this._actionsByClip, o = r[s], h = o.knownActions, l = h[h.length - 1], c = t._byClipCacheIndex;
    l._byClipCacheIndex = c, h[c] = l, h.pop(), t._byClipCacheIndex = null;
    const u = o.actionByRoot, d = (t._localRoot || this._root).uuid;
    delete u[d], h.length === 0 && delete r[s], this._removeInactiveBindingsForAction(t);
  }
  _removeInactiveBindingsForAction(t) {
    const e = t._propertyBindings;
    for (let i = 0, n = e.length; i !== n; ++i) {
      const s = e[i];
      --s.referenceCount === 0 && this._removeInactiveBinding(s);
    }
  }
  _lendAction(t) {
    const e = this._actions, i = t._cacheIndex, n = this._nActiveActions++, s = e[n];
    t._cacheIndex = n, e[n] = t, s._cacheIndex = i, e[i] = s;
  }
  _takeBackAction(t) {
    const e = this._actions, i = t._cacheIndex, n = --this._nActiveActions, s = e[n];
    t._cacheIndex = n, e[n] = t, s._cacheIndex = i, e[i] = s;
  }
  // Memory management for PropertyMixer objects
  _addInactiveBinding(t, e, i) {
    const n = this._bindingsByRootAndName, s = this._bindings;
    let r = n[e];
    r === void 0 && (r = {}, n[e] = r), r[i] = t, t._cacheIndex = s.length, s.push(t);
  }
  _removeInactiveBinding(t) {
    const e = this._bindings, i = t.binding, n = i.rootNode.uuid, s = i.path, r = this._bindingsByRootAndName, o = r[n], h = e[e.length - 1], l = t._cacheIndex;
    h._cacheIndex = l, e[l] = h, e.pop(), delete o[s], Object.keys(o).length === 0 && delete r[n];
  }
  _lendBinding(t) {
    const e = this._bindings, i = t._cacheIndex, n = this._nActiveBindings++, s = e[n];
    t._cacheIndex = n, e[n] = t, s._cacheIndex = i, e[i] = s;
  }
  _takeBackBinding(t) {
    const e = this._bindings, i = t._cacheIndex, n = --this._nActiveBindings, s = e[n];
    t._cacheIndex = n, e[n] = t, s._cacheIndex = i, e[i] = s;
  }
  // Memory management of Interpolants for weight and time scale
  _lendControlInterpolant() {
    const t = this._controlInterpolants, e = this._nActiveControlInterpolants++;
    let i = t[e];
    return i === void 0 && (i = new kh(
      new Float32Array(2),
      new Float32Array(2),
      1,
      Fu
    ), i.__cacheIndex = e, t[e] = i), i;
  }
  _takeBackControlInterpolant(t) {
    const e = this._controlInterpolants, i = t.__cacheIndex, n = --this._nActiveControlInterpolants, s = e[n];
    t.__cacheIndex = n, e[n] = t, s.__cacheIndex = i, e[i] = s;
  }
  // return an action for a clip optionally using a custom root target
  // object (this method allocates a lot of dynamic memory in case a
  // previously unknown clip/root combination is specified)
  clipAction(t, e, i) {
    const n = e || this._root, s = n.uuid;
    let r = typeof t == "string" ? lr.findByName(n, t) : t;
    const o = r !== null ? r.uuid : t, h = this._actionsByClip[o];
    let l = null;
    if (i === void 0 && (r !== null ? i = r.blendMode : i = Ur), h !== void 0) {
      const u = h.actionByRoot[s];
      if (u !== void 0 && u.blendMode === i)
        return u;
      l = h.knownActions[0], r === null && (r = l._clip);
    }
    if (r === null)
      return null;
    const c = new Bu(this, r, e, i);
    return this._bindAction(c, l), this._addInactiveAction(c, o, s), c;
  }
  // get an existing action
  existingAction(t, e) {
    const i = e || this._root, n = i.uuid, s = typeof t == "string" ? lr.findByName(i, t) : t, r = s ? s.uuid : t, o = this._actionsByClip[r];
    return o !== void 0 && o.actionByRoot[n] || null;
  }
  // deactivates all previously scheduled actions
  stopAllAction() {
    const t = this._actions, e = this._nActiveActions;
    for (let i = e - 1; i >= 0; --i)
      t[i].stop();
    return this;
  }
  // advance the time and update apply the animation
  update(t) {
    t *= this.timeScale;
    const e = this._actions, i = this._nActiveActions, n = this.time += t, s = Math.sign(t), r = this._accuIndex ^= 1;
    for (let l = 0; l !== i; ++l)
      e[l]._update(n, t, s, r);
    const o = this._bindings, h = this._nActiveBindings;
    for (let l = 0; l !== h; ++l)
      o[l].apply(r);
    return this;
  }
  // Allows you to seek to a specific time in an animation.
  setTime(t) {
    this.time = 0;
    for (let e = 0; e < this._actions.length; e++)
      this._actions[e].time = 0;
    return this.update(t);
  }
  // return this mixer's root target object
  getRoot() {
    return this._root;
  }
  // free all resources specific to a particular clip
  uncacheClip(t) {
    const e = this._actions, i = t.uuid, n = this._actionsByClip, s = n[i];
    if (s !== void 0) {
      const r = s.knownActions;
      for (let o = 0, h = r.length; o !== h; ++o) {
        const l = r[o];
        this._deactivateAction(l);
        const c = l._cacheIndex, u = e[e.length - 1];
        l._cacheIndex = null, l._byClipCacheIndex = null, u._cacheIndex = c, e[c] = u, e.pop(), this._removeInactiveBindingsForAction(l);
      }
      delete n[i];
    }
  }
  // free all resources specific to a particular root target object
  uncacheRoot(t) {
    const e = t.uuid, i = this._actionsByClip;
    for (const r in i) {
      const o = i[r].actionByRoot, h = o[e];
      h !== void 0 && (this._deactivateAction(h), this._removeInactiveAction(h));
    }
    const n = this._bindingsByRootAndName, s = n[e];
    if (s !== void 0)
      for (const r in s) {
        const o = s[r];
        o.restoreOriginalState(), this._removeInactiveBinding(o);
      }
  }
  // remove a targeted clip from the cache
  uncacheAction(t, e) {
    const i = this.existingAction(t, e);
    i !== null && (this._deactivateAction(i), this._removeInactiveAction(i));
  }
}
class zu {
  constructor(t, e, i = 0, n = 1 / 0) {
    this.ray = new Oi(t, e), this.near = i, this.far = n, this.camera = null, this.layers = new Ch(), this.params = {
      Mesh: {},
      Line: { threshold: 1 },
      LOD: {},
      Points: { threshold: 1 },
      Sprite: {}
    };
  }
  set(t, e) {
    this.ray.set(t, e);
  }
  setFromCamera(t, e) {
    e.isPerspectiveCamera ? (this.ray.origin.setFromMatrixPosition(e.matrixWorld), this.ray.direction.set(t.x, t.y, 0.5).unproject(e).sub(this.ray.origin).normalize(), this.camera = e) : e.isOrthographicCamera ? (this.ray.origin.set(t.x, t.y, (e.near + e.far) / (e.near - e.far)).unproject(e), this.ray.direction.set(0, 0, -1).transformDirection(e.matrixWorld), this.camera = e) : console.error("THREE.Raycaster: Unsupported camera type: " + e.type);
  }
  intersectObject(t, e = !0, i = []) {
    return ur(t, this, i, e), i.sort(wo), i;
  }
  intersectObjects(t, e = !0, i = []) {
    for (let n = 0, s = t.length; n < s; n++)
      ur(t[n], this, i, e);
    return i.sort(wo), i;
  }
}
function wo(a, t) {
  return a.distance - t.distance;
}
function ur(a, t, e, i) {
  if (a.layers.test(t.layers) && a.raycast(t, e), i === !0) {
    const n = a.children;
    for (let s = 0, r = n.length; s < r; s++)
      ur(n[s], t, e, !0);
  }
}
const bo = /* @__PURE__ */ new w();
let bn, Rs;
class Uu extends q {
  // dir is assumed to be normalized
  constructor(t = new w(0, 0, 1), e = new w(0, 0, 0), i = 1, n = 16776960, s = i * 0.2, r = s * 0.2) {
    super(), this.type = "ArrowHelper", bn === void 0 && (bn = new Dt(), bn.setAttribute("position", new Nt([0, 0, 0, 0, 1, 0], 3)), Rs = new Wr(0, 0.5, 1, 5, 1), Rs.translate(0, -0.5, 0)), this.position.copy(e), this.line = new Li(bn, new jn({ color: n, toneMapped: !1 })), this.line.matrixAutoUpdate = !1, this.add(this.line), this.cone = new Se(Rs, new ce({ color: n, toneMapped: !1 })), this.cone.matrixAutoUpdate = !1, this.add(this.cone), this.setDirection(t), this.setLength(i, s, r);
  }
  setDirection(t) {
    if (t.y > 0.99999)
      this.quaternion.set(0, 0, 0, 1);
    else if (t.y < -0.99999)
      this.quaternion.set(1, 0, 0, 0);
    else {
      bo.set(t.z, 0, -t.x).normalize();
      const e = Math.acos(t.y);
      this.quaternion.setFromAxisAngle(bo, e);
    }
  }
  setLength(t, e = t * 0.2, i = e * 0.2) {
    this.line.scale.set(1, Math.max(1e-4, t - e), 1), this.line.updateMatrix(), this.cone.scale.set(i, e, i), this.cone.position.y = t, this.cone.updateMatrix();
  }
  setColor(t) {
    this.line.material.color.set(t), this.cone.material.color.set(t);
  }
  copy(t) {
    return super.copy(t, !1), this.line.copy(t.line), this.cone.copy(t.cone), this;
  }
  dispose() {
    this.line.geometry.dispose(), this.line.material.dispose(), this.cone.geometry.dispose(), this.cone.material.dispose();
  }
}
typeof __THREE_DEVTOOLS__ < "u" && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register", { detail: {
  revision: Ah
} }));
typeof window < "u" && (window.__THREE__ ? console.warn("WARNING: Multiple instances of Three.js being imported.") : window.__THREE__ = Ah);
var Fn = /* @__PURE__ */ ((a) => (a.DETAILED = "detailed", a.MINIFIED = "minified", a.VOXELIZED = "voxelized", a))(Fn || {});
function vo(a, t) {
  if (t === cc)
    return console.warn("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Geometry already defined as triangles."), a;
  if (t === nr || t === Rh) {
    let e = a.getIndex();
    if (e === null) {
      const r = [], o = a.getAttribute("position");
      if (o !== void 0) {
        for (let h = 0; h < o.count; h++)
          r.push(h);
        a.setIndex(r), e = a.getIndex();
      } else
        return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Undefined position attribute. Processing not possible."), a;
    }
    const i = e.count - 2, n = [];
    if (t === nr)
      for (let r = 1; r <= i; r++)
        n.push(e.getX(0)), n.push(e.getX(r)), n.push(e.getX(r + 1));
    else
      for (let r = 0; r < i; r++)
        r % 2 === 0 ? (n.push(e.getX(r)), n.push(e.getX(r + 1)), n.push(e.getX(r + 2))) : (n.push(e.getX(r + 2)), n.push(e.getX(r + 1)), n.push(e.getX(r)));
    n.length / 3 !== i && console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unable to generate correct amount of triangles.");
    const s = a.clone();
    return s.setIndex(n), s.clearGroups(), s;
  } else
    return console.error("THREE.BufferGeometryUtils.toTrianglesDrawMode(): Unknown draw mode:", t), a;
}
class $h extends hi {
  constructor(t) {
    super(t), this.dracoLoader = null, this.ktx2Loader = null, this.meshoptDecoder = null, this.pluginCallbacks = [], this.register(function(e) {
      return new Wu(e);
    }), this.register(function(e) {
      return new Qu(e);
    }), this.register(function(e) {
      return new td(e);
    }), this.register(function(e) {
      return new ed(e);
    }), this.register(function(e) {
      return new Gu(e);
    }), this.register(function(e) {
      return new Ku(e);
    }), this.register(function(e) {
      return new Yu(e);
    }), this.register(function(e) {
      return new Xu(e);
    }), this.register(function(e) {
      return new Vu(e);
    }), this.register(function(e) {
      return new Ju(e);
    }), this.register(function(e) {
      return new qu(e);
    }), this.register(function(e) {
      return new Zu(e);
    }), this.register(function(e) {
      return new Hu(e);
    }), this.register(function(e) {
      return new id(e);
    }), this.register(function(e) {
      return new nd(e);
    });
  }
  load(t, e, i, n) {
    const s = this;
    let r;
    this.resourcePath !== "" ? r = this.resourcePath : this.path !== "" ? r = this.path : r = cr.extractUrlBase(t), this.manager.itemStart(t);
    const o = function(l) {
      n ? n(l) : console.error(l), s.manager.itemError(t), s.manager.itemEnd(t);
    }, h = new Uh(this.manager);
    h.setPath(this.path), h.setResponseType("arraybuffer"), h.setRequestHeader(this.requestHeader), h.setWithCredentials(this.withCredentials), h.load(t, function(l) {
      try {
        s.parse(l, r, function(c) {
          e(c), s.manager.itemEnd(t);
        }, o);
      } catch (c) {
        o(c);
      }
    }, i, o);
  }
  setDRACOLoader(t) {
    return this.dracoLoader = t, this;
  }
  setDDSLoader() {
    throw new Error(
      'THREE.GLTFLoader: "MSFT_texture_dds" no longer supported. Please update to "KHR_texture_basisu".'
    );
  }
  setKTX2Loader(t) {
    return this.ktx2Loader = t, this;
  }
  setMeshoptDecoder(t) {
    return this.meshoptDecoder = t, this;
  }
  register(t) {
    return this.pluginCallbacks.indexOf(t) === -1 && this.pluginCallbacks.push(t), this;
  }
  unregister(t) {
    return this.pluginCallbacks.indexOf(t) !== -1 && this.pluginCallbacks.splice(this.pluginCallbacks.indexOf(t), 1), this;
  }
  parse(t, e, i, n) {
    let s;
    const r = {}, o = {}, h = new TextDecoder();
    if (typeof t == "string")
      s = JSON.parse(t);
    else if (t instanceof ArrayBuffer)
      if (h.decode(new Uint8Array(t, 0, 4)) === Vh) {
        try {
          r[B.KHR_BINARY_GLTF] = new sd(t);
        } catch (u) {
          n && n(u);
          return;
        }
        s = JSON.parse(r[B.KHR_BINARY_GLTF].content);
      } else
        s = JSON.parse(h.decode(t));
    else
      s = t;
    if (s.asset === void 0 || s.asset.version[0] < 2) {
      n && n(new Error("THREE.GLTFLoader: Unsupported asset. glTF versions >=2.0 are supported."));
      return;
    }
    const l = new gd(s, {
      path: e || this.resourcePath || "",
      crossOrigin: this.crossOrigin,
      requestHeader: this.requestHeader,
      manager: this.manager,
      ktx2Loader: this.ktx2Loader,
      meshoptDecoder: this.meshoptDecoder
    });
    l.fileLoader.setRequestHeader(this.requestHeader);
    for (let c = 0; c < this.pluginCallbacks.length; c++) {
      const u = this.pluginCallbacks[c](l);
      o[u.name] = u, r[u.name] = !0;
    }
    if (s.extensionsUsed)
      for (let c = 0; c < s.extensionsUsed.length; ++c) {
        const u = s.extensionsUsed[c], d = s.extensionsRequired || [];
        switch (u) {
          case B.KHR_MATERIALS_UNLIT:
            r[u] = new $u();
            break;
          case B.KHR_DRACO_MESH_COMPRESSION:
            r[u] = new rd(s, this.dracoLoader);
            break;
          case B.KHR_TEXTURE_TRANSFORM:
            r[u] = new ad();
            break;
          case B.KHR_MESH_QUANTIZATION:
            r[u] = new od();
            break;
          default:
            d.indexOf(u) >= 0 && o[u] === void 0 && console.warn('THREE.GLTFLoader: Unknown extension "' + u + '".');
        }
      }
    l.setExtensions(r), l.setPlugins(o), l.parse(i, n);
  }
  parseAsync(t, e) {
    const i = this;
    return new Promise(function(n, s) {
      i.parse(t, e, n, s);
    });
  }
}
function ju() {
  let a = {};
  return {
    get: function(t) {
      return a[t];
    },
    add: function(t, e) {
      a[t] = e;
    },
    remove: function(t) {
      delete a[t];
    },
    removeAll: function() {
      a = {};
    }
  };
}
const B = {
  KHR_BINARY_GLTF: "KHR_binary_glTF",
  KHR_DRACO_MESH_COMPRESSION: "KHR_draco_mesh_compression",
  KHR_LIGHTS_PUNCTUAL: "KHR_lights_punctual",
  KHR_MATERIALS_CLEARCOAT: "KHR_materials_clearcoat",
  KHR_MATERIALS_IOR: "KHR_materials_ior",
  KHR_MATERIALS_SHEEN: "KHR_materials_sheen",
  KHR_MATERIALS_SPECULAR: "KHR_materials_specular",
  KHR_MATERIALS_TRANSMISSION: "KHR_materials_transmission",
  KHR_MATERIALS_IRIDESCENCE: "KHR_materials_iridescence",
  KHR_MATERIALS_ANISOTROPY: "KHR_materials_anisotropy",
  KHR_MATERIALS_UNLIT: "KHR_materials_unlit",
  KHR_MATERIALS_VOLUME: "KHR_materials_volume",
  KHR_TEXTURE_BASISU: "KHR_texture_basisu",
  KHR_TEXTURE_TRANSFORM: "KHR_texture_transform",
  KHR_MESH_QUANTIZATION: "KHR_mesh_quantization",
  KHR_MATERIALS_EMISSIVE_STRENGTH: "KHR_materials_emissive_strength",
  EXT_TEXTURE_WEBP: "EXT_texture_webp",
  EXT_TEXTURE_AVIF: "EXT_texture_avif",
  EXT_MESHOPT_COMPRESSION: "EXT_meshopt_compression",
  EXT_MESH_GPU_INSTANCING: "EXT_mesh_gpu_instancing"
};
class Hu {
  constructor(t) {
    this.parser = t, this.name = B.KHR_LIGHTS_PUNCTUAL, this.cache = { refs: {}, uses: {} };
  }
  _markDefs() {
    const t = this.parser, e = this.parser.json.nodes || [];
    for (let i = 0, n = e.length; i < n; i++) {
      const s = e[i];
      s.extensions && s.extensions[this.name] && s.extensions[this.name].light !== void 0 && t._addNodeRef(this.cache, s.extensions[this.name].light);
    }
  }
  _loadLight(t) {
    const e = this.parser, i = "light:" + t;
    let n = e.cache.get(i);
    if (n)
      return n;
    const s = e.json, h = ((s.extensions && s.extensions[this.name] || {}).lights || [])[t];
    let l;
    const c = new J(16777215);
    h.color !== void 0 && c.setRGB(h.color[0], h.color[1], h.color[2], St);
    const u = h.range !== void 0 ? h.range : 0;
    switch (h.type) {
      case "directional":
        l = new Mu(c), l.target.position.set(0, 0, -1), l.add(l.target);
        break;
      case "point":
        l = new vu(c), l.distance = u;
        break;
      case "spot":
        l = new wu(c), l.distance = u, h.spot = h.spot || {}, h.spot.innerConeAngle = h.spot.innerConeAngle !== void 0 ? h.spot.innerConeAngle : 0, h.spot.outerConeAngle = h.spot.outerConeAngle !== void 0 ? h.spot.outerConeAngle : Math.PI / 4, l.angle = h.spot.outerConeAngle, l.penumbra = 1 - h.spot.innerConeAngle / h.spot.outerConeAngle, l.target.position.set(0, 0, -1), l.add(l.target);
        break;
      default:
        throw new Error("THREE.GLTFLoader: Unexpected light type: " + h.type);
    }
    return l.position.set(0, 0, 0), l.decay = 2, se(l, h), h.intensity !== void 0 && (l.intensity = h.intensity), l.name = e.createUniqueName(h.name || "light_" + t), n = Promise.resolve(l), e.cache.add(i, n), n;
  }
  getDependency(t, e) {
    if (t === "light")
      return this._loadLight(e);
  }
  createNodeAttachment(t) {
    const e = this, i = this.parser, s = i.json.nodes[t], o = (s.extensions && s.extensions[this.name] || {}).light;
    return o === void 0 ? null : this._loadLight(o).then(function(h) {
      return i._getNodeRef(e.cache, o, h);
    });
  }
}
class $u {
  constructor() {
    this.name = B.KHR_MATERIALS_UNLIT;
  }
  getMaterialType() {
    return ce;
  }
  extendParams(t, e, i) {
    const n = [];
    t.color = new J(1, 1, 1), t.opacity = 1;
    const s = e.pbrMetallicRoughness;
    if (s) {
      if (Array.isArray(s.baseColorFactor)) {
        const r = s.baseColorFactor;
        t.color.setRGB(r[0], r[1], r[2], St), t.opacity = r[3];
      }
      s.baseColorTexture !== void 0 && n.push(i.assignTexture(t, "map", s.baseColorTexture, st));
    }
    return Promise.all(n);
  }
}
class Vu {
  constructor(t) {
    this.parser = t, this.name = B.KHR_MATERIALS_EMISSIVE_STRENGTH;
  }
  extendMaterialParams(t, e) {
    const n = this.parser.json.materials[t];
    if (!n.extensions || !n.extensions[this.name])
      return Promise.resolve();
    const s = n.extensions[this.name].emissiveStrength;
    return s !== void 0 && (e.emissiveIntensity = s), Promise.resolve();
  }
}
class Wu {
  constructor(t) {
    this.parser = t, this.name = B.KHR_MATERIALS_CLEARCOAT;
  }
  getMaterialType(t) {
    const i = this.parser.json.materials[t];
    return !i.extensions || !i.extensions[this.name] ? null : de;
  }
  extendMaterialParams(t, e) {
    const i = this.parser, n = i.json.materials[t];
    if (!n.extensions || !n.extensions[this.name])
      return Promise.resolve();
    const s = [], r = n.extensions[this.name];
    if (r.clearcoatFactor !== void 0 && (e.clearcoat = r.clearcoatFactor), r.clearcoatTexture !== void 0 && s.push(i.assignTexture(e, "clearcoatMap", r.clearcoatTexture)), r.clearcoatRoughnessFactor !== void 0 && (e.clearcoatRoughness = r.clearcoatRoughnessFactor), r.clearcoatRoughnessTexture !== void 0 && s.push(i.assignTexture(e, "clearcoatRoughnessMap", r.clearcoatRoughnessTexture)), r.clearcoatNormalTexture !== void 0 && (s.push(i.assignTexture(e, "clearcoatNormalMap", r.clearcoatNormalTexture)), r.clearcoatNormalTexture.scale !== void 0)) {
      const o = r.clearcoatNormalTexture.scale;
      e.clearcoatNormalScale = new G(o, o);
    }
    return Promise.all(s);
  }
}
class qu {
  constructor(t) {
    this.parser = t, this.name = B.KHR_MATERIALS_IRIDESCENCE;
  }
  getMaterialType(t) {
    const i = this.parser.json.materials[t];
    return !i.extensions || !i.extensions[this.name] ? null : de;
  }
  extendMaterialParams(t, e) {
    const i = this.parser, n = i.json.materials[t];
    if (!n.extensions || !n.extensions[this.name])
      return Promise.resolve();
    const s = [], r = n.extensions[this.name];
    return r.iridescenceFactor !== void 0 && (e.iridescence = r.iridescenceFactor), r.iridescenceTexture !== void 0 && s.push(i.assignTexture(e, "iridescenceMap", r.iridescenceTexture)), r.iridescenceIor !== void 0 && (e.iridescenceIOR = r.iridescenceIor), e.iridescenceThicknessRange === void 0 && (e.iridescenceThicknessRange = [100, 400]), r.iridescenceThicknessMinimum !== void 0 && (e.iridescenceThicknessRange[0] = r.iridescenceThicknessMinimum), r.iridescenceThicknessMaximum !== void 0 && (e.iridescenceThicknessRange[1] = r.iridescenceThicknessMaximum), r.iridescenceThicknessTexture !== void 0 && s.push(i.assignTexture(e, "iridescenceThicknessMap", r.iridescenceThicknessTexture)), Promise.all(s);
  }
}
class Gu {
  constructor(t) {
    this.parser = t, this.name = B.KHR_MATERIALS_SHEEN;
  }
  getMaterialType(t) {
    const i = this.parser.json.materials[t];
    return !i.extensions || !i.extensions[this.name] ? null : de;
  }
  extendMaterialParams(t, e) {
    const i = this.parser, n = i.json.materials[t];
    if (!n.extensions || !n.extensions[this.name])
      return Promise.resolve();
    const s = [];
    e.sheenColor = new J(0, 0, 0), e.sheenRoughness = 0, e.sheen = 1;
    const r = n.extensions[this.name];
    if (r.sheenColorFactor !== void 0) {
      const o = r.sheenColorFactor;
      e.sheenColor.setRGB(o[0], o[1], o[2], St);
    }
    return r.sheenRoughnessFactor !== void 0 && (e.sheenRoughness = r.sheenRoughnessFactor), r.sheenColorTexture !== void 0 && s.push(i.assignTexture(e, "sheenColorMap", r.sheenColorTexture, st)), r.sheenRoughnessTexture !== void 0 && s.push(i.assignTexture(e, "sheenRoughnessMap", r.sheenRoughnessTexture)), Promise.all(s);
  }
}
class Ku {
  constructor(t) {
    this.parser = t, this.name = B.KHR_MATERIALS_TRANSMISSION;
  }
  getMaterialType(t) {
    const i = this.parser.json.materials[t];
    return !i.extensions || !i.extensions[this.name] ? null : de;
  }
  extendMaterialParams(t, e) {
    const i = this.parser, n = i.json.materials[t];
    if (!n.extensions || !n.extensions[this.name])
      return Promise.resolve();
    const s = [], r = n.extensions[this.name];
    return r.transmissionFactor !== void 0 && (e.transmission = r.transmissionFactor), r.transmissionTexture !== void 0 && s.push(i.assignTexture(e, "transmissionMap", r.transmissionTexture)), Promise.all(s);
  }
}
class Yu {
  constructor(t) {
    this.parser = t, this.name = B.KHR_MATERIALS_VOLUME;
  }
  getMaterialType(t) {
    const i = this.parser.json.materials[t];
    return !i.extensions || !i.extensions[this.name] ? null : de;
  }
  extendMaterialParams(t, e) {
    const i = this.parser, n = i.json.materials[t];
    if (!n.extensions || !n.extensions[this.name])
      return Promise.resolve();
    const s = [], r = n.extensions[this.name];
    e.thickness = r.thicknessFactor !== void 0 ? r.thicknessFactor : 0, r.thicknessTexture !== void 0 && s.push(i.assignTexture(e, "thicknessMap", r.thicknessTexture)), e.attenuationDistance = r.attenuationDistance || 1 / 0;
    const o = r.attenuationColor || [1, 1, 1];
    return e.attenuationColor = new J().setRGB(o[0], o[1], o[2], St), Promise.all(s);
  }
}
class Xu {
  constructor(t) {
    this.parser = t, this.name = B.KHR_MATERIALS_IOR;
  }
  getMaterialType(t) {
    const i = this.parser.json.materials[t];
    return !i.extensions || !i.extensions[this.name] ? null : de;
  }
  extendMaterialParams(t, e) {
    const n = this.parser.json.materials[t];
    if (!n.extensions || !n.extensions[this.name])
      return Promise.resolve();
    const s = n.extensions[this.name];
    return e.ior = s.ior !== void 0 ? s.ior : 1.5, Promise.resolve();
  }
}
class Ju {
  constructor(t) {
    this.parser = t, this.name = B.KHR_MATERIALS_SPECULAR;
  }
  getMaterialType(t) {
    const i = this.parser.json.materials[t];
    return !i.extensions || !i.extensions[this.name] ? null : de;
  }
  extendMaterialParams(t, e) {
    const i = this.parser, n = i.json.materials[t];
    if (!n.extensions || !n.extensions[this.name])
      return Promise.resolve();
    const s = [], r = n.extensions[this.name];
    e.specularIntensity = r.specularFactor !== void 0 ? r.specularFactor : 1, r.specularTexture !== void 0 && s.push(i.assignTexture(e, "specularIntensityMap", r.specularTexture));
    const o = r.specularColorFactor || [1, 1, 1];
    return e.specularColor = new J().setRGB(o[0], o[1], o[2], St), r.specularColorTexture !== void 0 && s.push(i.assignTexture(e, "specularColorMap", r.specularColorTexture, st)), Promise.all(s);
  }
}
class Zu {
  constructor(t) {
    this.parser = t, this.name = B.KHR_MATERIALS_ANISOTROPY;
  }
  getMaterialType(t) {
    const i = this.parser.json.materials[t];
    return !i.extensions || !i.extensions[this.name] ? null : de;
  }
  extendMaterialParams(t, e) {
    const i = this.parser, n = i.json.materials[t];
    if (!n.extensions || !n.extensions[this.name])
      return Promise.resolve();
    const s = [], r = n.extensions[this.name];
    return r.anisotropyStrength !== void 0 && (e.anisotropy = r.anisotropyStrength), r.anisotropyRotation !== void 0 && (e.anisotropyRotation = r.anisotropyRotation), r.anisotropyTexture !== void 0 && s.push(i.assignTexture(e, "anisotropyMap", r.anisotropyTexture)), Promise.all(s);
  }
}
class Qu {
  constructor(t) {
    this.parser = t, this.name = B.KHR_TEXTURE_BASISU;
  }
  loadTexture(t) {
    const e = this.parser, i = e.json, n = i.textures[t];
    if (!n.extensions || !n.extensions[this.name])
      return null;
    const s = n.extensions[this.name], r = e.options.ktx2Loader;
    if (!r) {
      if (i.extensionsRequired && i.extensionsRequired.indexOf(this.name) >= 0)
        throw new Error("THREE.GLTFLoader: setKTX2Loader must be called before loading KTX2 textures");
      return null;
    }
    return e.loadTextureImage(t, s.source, r);
  }
}
class td {
  constructor(t) {
    this.parser = t, this.name = B.EXT_TEXTURE_WEBP, this.isSupported = null;
  }
  loadTexture(t) {
    const e = this.name, i = this.parser, n = i.json, s = n.textures[t];
    if (!s.extensions || !s.extensions[e])
      return null;
    const r = s.extensions[e], o = n.images[r.source];
    let h = i.textureLoader;
    if (o.uri) {
      const l = i.options.manager.getHandler(o.uri);
      l !== null && (h = l);
    }
    return this.detectSupport().then(function(l) {
      if (l)
        return i.loadTextureImage(t, r.source, h);
      if (n.extensionsRequired && n.extensionsRequired.indexOf(e) >= 0)
        throw new Error("THREE.GLTFLoader: WebP required by asset but unsupported.");
      return i.loadTexture(t);
    });
  }
  detectSupport() {
    return this.isSupported || (this.isSupported = new Promise(function(t) {
      const e = new Image();
      e.src = "data:image/webp;base64,UklGRiIAAABXRUJQVlA4IBYAAAAwAQCdASoBAAEADsD+JaQAA3AAAAAA", e.onload = e.onerror = function() {
        t(e.height === 1);
      };
    })), this.isSupported;
  }
}
class ed {
  constructor(t) {
    this.parser = t, this.name = B.EXT_TEXTURE_AVIF, this.isSupported = null;
  }
  loadTexture(t) {
    const e = this.name, i = this.parser, n = i.json, s = n.textures[t];
    if (!s.extensions || !s.extensions[e])
      return null;
    const r = s.extensions[e], o = n.images[r.source];
    let h = i.textureLoader;
    if (o.uri) {
      const l = i.options.manager.getHandler(o.uri);
      l !== null && (h = l);
    }
    return this.detectSupport().then(function(l) {
      if (l)
        return i.loadTextureImage(t, r.source, h);
      if (n.extensionsRequired && n.extensionsRequired.indexOf(e) >= 0)
        throw new Error("THREE.GLTFLoader: AVIF required by asset but unsupported.");
      return i.loadTexture(t);
    });
  }
  detectSupport() {
    return this.isSupported || (this.isSupported = new Promise(function(t) {
      const e = new Image();
      e.src = "data:image/avif;base64,AAAAIGZ0eXBhdmlmAAAAAGF2aWZtaWYxbWlhZk1BMUIAAADybWV0YQAAAAAAAAAoaGRscgAAAAAAAAAAcGljdAAAAAAAAAAAAAAAAGxpYmF2aWYAAAAADnBpdG0AAAAAAAEAAAAeaWxvYwAAAABEAAABAAEAAAABAAABGgAAABcAAAAoaWluZgAAAAAAAQAAABppbmZlAgAAAAABAABhdjAxQ29sb3IAAAAAamlwcnAAAABLaXBjbwAAABRpc3BlAAAAAAAAAAEAAAABAAAAEHBpeGkAAAAAAwgICAAAAAxhdjFDgQAMAAAAABNjb2xybmNseAACAAIABoAAAAAXaXBtYQAAAAAAAAABAAEEAQKDBAAAAB9tZGF0EgAKCBgABogQEDQgMgkQAAAAB8dSLfI=", e.onload = e.onerror = function() {
        t(e.height === 1);
      };
    })), this.isSupported;
  }
}
class id {
  constructor(t) {
    this.name = B.EXT_MESHOPT_COMPRESSION, this.parser = t;
  }
  loadBufferView(t) {
    const e = this.parser.json, i = e.bufferViews[t];
    if (i.extensions && i.extensions[this.name]) {
      const n = i.extensions[this.name], s = this.parser.getDependency("buffer", n.buffer), r = this.parser.options.meshoptDecoder;
      if (!r || !r.supported) {
        if (e.extensionsRequired && e.extensionsRequired.indexOf(this.name) >= 0)
          throw new Error("THREE.GLTFLoader: setMeshoptDecoder must be called before loading compressed files");
        return null;
      }
      return s.then(function(o) {
        const h = n.byteOffset || 0, l = n.byteLength || 0, c = n.count, u = n.byteStride, d = new Uint8Array(o, h, l);
        return r.decodeGltfBufferAsync ? r.decodeGltfBufferAsync(c, u, d, n.mode, n.filter).then(function(f) {
          return f.buffer;
        }) : r.ready.then(function() {
          const f = new ArrayBuffer(c * u);
          return r.decodeGltfBuffer(new Uint8Array(f), c, u, d, n.mode, n.filter), f;
        });
      });
    } else
      return null;
  }
}
class nd {
  constructor(t) {
    this.name = B.EXT_MESH_GPU_INSTANCING, this.parser = t;
  }
  createNodeMesh(t) {
    const e = this.parser.json, i = e.nodes[t];
    if (!i.extensions || !i.extensions[this.name] || i.mesh === void 0)
      return null;
    const n = e.meshes[i.mesh];
    for (const l of n.primitives)
      if (l.mode !== gt.TRIANGLES && l.mode !== gt.TRIANGLE_STRIP && l.mode !== gt.TRIANGLE_FAN && l.mode !== void 0)
        return null;
    const r = i.extensions[this.name].attributes, o = [], h = {};
    for (const l in r)
      o.push(this.parser.getDependency("accessor", r[l]).then((c) => (h[l] = c, h[l])));
    return o.length < 1 ? null : (o.push(this.parser.createNodeMesh(t)), Promise.all(o).then((l) => {
      const c = l.pop(), u = c.isGroup ? c.children : [c], d = l[0].count, f = [];
      for (const p of u) {
        const y = new F(), m = new w(), _ = new Q(), b = new w(1, 1, 1), A = new su(p.geometry, p.material, d);
        for (let g = 0; g < d; g++)
          h.TRANSLATION && m.fromBufferAttribute(h.TRANSLATION, g), h.ROTATION && _.fromBufferAttribute(h.ROTATION, g), h.SCALE && b.fromBufferAttribute(h.SCALE, g), A.setMatrixAt(g, y.compose(m, _, b));
        for (const g in h)
          g !== "TRANSLATION" && g !== "ROTATION" && g !== "SCALE" && p.geometry.setAttribute(g, h[g]);
        q.prototype.copy.call(A, p), this.parser.assignFinalMaterial(A), f.push(A);
      }
      return c.isGroup ? (c.clear(), c.add(...f), c) : f[0];
    }));
  }
}
const Vh = "glTF", wi = 12, Ao = { JSON: 1313821514, BIN: 5130562 };
class sd {
  constructor(t) {
    this.name = B.KHR_BINARY_GLTF, this.content = null, this.body = null;
    const e = new DataView(t, 0, wi), i = new TextDecoder();
    if (this.header = {
      magic: i.decode(new Uint8Array(t.slice(0, 4))),
      version: e.getUint32(4, !0),
      length: e.getUint32(8, !0)
    }, this.header.magic !== Vh)
      throw new Error("THREE.GLTFLoader: Unsupported glTF-Binary header.");
    if (this.header.version < 2)
      throw new Error("THREE.GLTFLoader: Legacy binary file detected.");
    const n = this.header.length - wi, s = new DataView(t, wi);
    let r = 0;
    for (; r < n; ) {
      const o = s.getUint32(r, !0);
      r += 4;
      const h = s.getUint32(r, !0);
      if (r += 4, h === Ao.JSON) {
        const l = new Uint8Array(t, wi + r, o);
        this.content = i.decode(l);
      } else if (h === Ao.BIN) {
        const l = wi + r;
        this.body = t.slice(l, l + o);
      }
      r += o;
    }
    if (this.content === null)
      throw new Error("THREE.GLTFLoader: JSON content not found.");
  }
}
class rd {
  constructor(t, e) {
    if (!e)
      throw new Error("THREE.GLTFLoader: No DRACOLoader instance provided.");
    this.name = B.KHR_DRACO_MESH_COMPRESSION, this.json = t, this.dracoLoader = e, this.dracoLoader.preload();
  }
  decodePrimitive(t, e) {
    const i = this.json, n = this.dracoLoader, s = t.extensions[this.name].bufferView, r = t.extensions[this.name].attributes, o = {}, h = {}, l = {};
    for (const c in r) {
      const u = dr[c] || c.toLowerCase();
      o[u] = r[c];
    }
    for (const c in t.attributes) {
      const u = dr[c] || c.toLowerCase();
      if (r[c] !== void 0) {
        const d = i.accessors[t.attributes[c]], f = Ze[d.componentType];
        l[u] = f.name, h[u] = d.normalized === !0;
      }
    }
    return e.getDependency("bufferView", s).then(function(c) {
      return new Promise(function(u) {
        n.decodeDracoFile(c, function(d) {
          for (const f in d.attributes) {
            const p = d.attributes[f], y = h[f];
            y !== void 0 && (p.normalized = y);
          }
          u(d);
        }, o, l);
      });
    });
  }
}
class ad {
  constructor() {
    this.name = B.KHR_TEXTURE_TRANSFORM;
  }
  extendTexture(t, e) {
    return (e.texCoord === void 0 || e.texCoord === t.channel) && e.offset === void 0 && e.rotation === void 0 && e.scale === void 0 || (t = t.clone(), e.texCoord !== void 0 && (t.channel = e.texCoord), e.offset !== void 0 && t.offset.fromArray(e.offset), e.rotation !== void 0 && (t.rotation = e.rotation), e.scale !== void 0 && t.repeat.fromArray(e.scale), t.needsUpdate = !0), t;
  }
}
class od {
  constructor() {
    this.name = B.KHR_MESH_QUANTIZATION;
  }
}
class Wh extends Di {
  constructor(t, e, i, n) {
    super(t, e, i, n);
  }
  copySampleValue_(t) {
    const e = this.resultBuffer, i = this.sampleValues, n = this.valueSize, s = t * n * 3 + n;
    for (let r = 0; r !== n; r++)
      e[r] = i[s + r];
    return e;
  }
  interpolate_(t, e, i, n) {
    const s = this.resultBuffer, r = this.sampleValues, o = this.valueSize, h = o * 2, l = o * 3, c = n - e, u = (i - e) / c, d = u * u, f = d * u, p = t * l, y = p - l, m = -2 * f + 3 * d, _ = f - d, b = 1 - m, A = _ - d + u;
    for (let g = 0; g !== o; g++) {
      const x = r[y + g + o], v = r[y + g + h] * c, M = r[p + g + o], T = r[p + g] * c;
      s[g] = b * x + A * v + m * M + _ * T;
    }
    return s;
  }
}
const hd = new Q();
class ld extends Wh {
  interpolate_(t, e, i, n) {
    const s = super.interpolate_(t, e, i, n);
    return hd.fromArray(s).normalize().toArray(s), s;
  }
}
const gt = {
  FLOAT: 5126,
  //FLOAT_MAT2: 35674,
  FLOAT_MAT3: 35675,
  FLOAT_MAT4: 35676,
  FLOAT_VEC2: 35664,
  FLOAT_VEC3: 35665,
  FLOAT_VEC4: 35666,
  LINEAR: 9729,
  REPEAT: 10497,
  SAMPLER_2D: 35678,
  POINTS: 0,
  LINES: 1,
  LINE_LOOP: 2,
  LINE_STRIP: 3,
  TRIANGLES: 4,
  TRIANGLE_STRIP: 5,
  TRIANGLE_FAN: 6,
  UNSIGNED_BYTE: 5121,
  UNSIGNED_SHORT: 5123
}, Ze = {
  5120: Int8Array,
  5121: Uint8Array,
  5122: Int16Array,
  5123: Uint16Array,
  5125: Uint32Array,
  5126: Float32Array
}, Mo = {
  9728: ir,
  9729: kr,
  9984: nc,
  9985: rc,
  9986: sc,
  9987: zr
}, Eo = {
  33071: vi,
  33648: er,
  10497: Ri
}, Ps = {
  SCALAR: 1,
  VEC2: 2,
  VEC3: 3,
  VEC4: 4,
  MAT2: 4,
  MAT3: 9,
  MAT4: 16
}, dr = {
  POSITION: "position",
  NORMAL: "normal",
  TANGENT: "tangent",
  TEXCOORD_0: "uv",
  TEXCOORD_1: "uv1",
  TEXCOORD_2: "uv2",
  TEXCOORD_3: "uv3",
  COLOR_0: "color",
  WEIGHTS_0: "skinWeight",
  JOINTS_0: "skinIndex"
}, ne = {
  scale: "scale",
  translation: "position",
  rotation: "quaternion",
  weights: "morphTargetInfluences"
}, cd = {
  CUBICSPLINE: void 0,
  // We use a custom interpolant (GLTFCubicSplineInterpolation) for CUBICSPLINE tracks. Each
  // keyframe track will be initialized with a default interpolation type, then modified.
  LINEAR: ei,
  STEP: Pi
}, Is = {
  OPAQUE: "OPAQUE",
  MASK: "MASK",
  BLEND: "BLEND"
};
function ud(a) {
  return a.DefaultMaterial === void 0 && (a.DefaultMaterial = new Gr({
    color: 16777215,
    emissive: 0,
    metalness: 1,
    roughness: 1,
    transparent: !1,
    depthTest: !0,
    side: Dn
  })), a.DefaultMaterial;
}
function we(a, t, e) {
  for (const i in e.extensions)
    a[i] === void 0 && (t.userData.gltfExtensions = t.userData.gltfExtensions || {}, t.userData.gltfExtensions[i] = e.extensions[i]);
}
function se(a, t) {
  t.extras !== void 0 && (typeof t.extras == "object" ? Object.assign(a.userData, t.extras) : console.warn("THREE.GLTFLoader: Ignoring primitive type .extras, " + t.extras));
}
function dd(a, t, e) {
  let i = !1, n = !1, s = !1;
  for (let l = 0, c = t.length; l < c; l++) {
    const u = t[l];
    if (u.POSITION !== void 0 && (i = !0), u.NORMAL !== void 0 && (n = !0), u.COLOR_0 !== void 0 && (s = !0), i && n && s)
      break;
  }
  if (!i && !n && !s)
    return Promise.resolve(a);
  const r = [], o = [], h = [];
  for (let l = 0, c = t.length; l < c; l++) {
    const u = t[l];
    if (i) {
      const d = u.POSITION !== void 0 ? e.getDependency("accessor", u.POSITION) : a.attributes.position;
      r.push(d);
    }
    if (n) {
      const d = u.NORMAL !== void 0 ? e.getDependency("accessor", u.NORMAL) : a.attributes.normal;
      o.push(d);
    }
    if (s) {
      const d = u.COLOR_0 !== void 0 ? e.getDependency("accessor", u.COLOR_0) : a.attributes.color;
      h.push(d);
    }
  }
  return Promise.all([
    Promise.all(r),
    Promise.all(o),
    Promise.all(h)
  ]).then(function(l) {
    const c = l[0], u = l[1], d = l[2];
    return i && (a.morphAttributes.position = c), n && (a.morphAttributes.normal = u), s && (a.morphAttributes.color = d), a.morphTargetsRelative = !0, a;
  });
}
function fd(a, t) {
  if (a.updateMorphTargets(), t.weights !== void 0)
    for (let e = 0, i = t.weights.length; e < i; e++)
      a.morphTargetInfluences[e] = t.weights[e];
  if (t.extras && Array.isArray(t.extras.targetNames)) {
    const e = t.extras.targetNames;
    if (a.morphTargetInfluences.length === e.length) {
      a.morphTargetDictionary = {};
      for (let i = 0, n = e.length; i < n; i++)
        a.morphTargetDictionary[e[i]] = i;
    } else
      console.warn("THREE.GLTFLoader: Invalid extras.targetNames length. Ignoring names.");
  }
}
function pd(a) {
  let t;
  const e = a.extensions && a.extensions[B.KHR_DRACO_MESH_COMPRESSION];
  if (e ? t = "draco:" + e.bufferView + ":" + e.indices + ":" + Cs(e.attributes) : t = a.indices + ":" + Cs(a.attributes) + ":" + a.mode, a.targets !== void 0)
    for (let i = 0, n = a.targets.length; i < n; i++)
      t += ":" + Cs(a.targets[i]);
  return t;
}
function Cs(a) {
  let t = "";
  const e = Object.keys(a).sort();
  for (let i = 0, n = e.length; i < n; i++)
    t += e[i] + ":" + a[e[i]] + ";";
  return t;
}
function fr(a) {
  switch (a) {
    case Int8Array:
      return 1 / 127;
    case Uint8Array:
      return 1 / 255;
    case Int16Array:
      return 1 / 32767;
    case Uint16Array:
      return 1 / 65535;
    default:
      throw new Error("THREE.GLTFLoader: Unsupported normalized accessor component type.");
  }
}
function md(a) {
  return a.search(/\.jpe?g($|\?)/i) > 0 || a.search(/^data\:image\/jpeg/) === 0 ? "image/jpeg" : a.search(/\.webp($|\?)/i) > 0 || a.search(/^data\:image\/webp/) === 0 ? "image/webp" : "image/png";
}
const yd = new F();
class gd {
  constructor(t = {}, e = {}) {
    this.json = t, this.extensions = {}, this.plugins = {}, this.options = e, this.cache = new ju(), this.associations = /* @__PURE__ */ new Map(), this.primitiveCache = {}, this.nodeCache = {}, this.meshCache = { refs: {}, uses: {} }, this.cameraCache = { refs: {}, uses: {} }, this.lightCache = { refs: {}, uses: {} }, this.sourceCache = {}, this.textureCache = {}, this.nodeNamesUsed = {};
    let i = !1, n = !1, s = -1;
    typeof navigator < "u" && (i = /^((?!chrome|android).)*safari/i.test(navigator.userAgent) === !0, n = navigator.userAgent.indexOf("Firefox") > -1, s = n ? navigator.userAgent.match(/Firefox\/([0-9]+)\./)[1] : -1), typeof createImageBitmap > "u" || i || n && s < 98 ? this.textureLoader = new jh(this.options.manager) : this.textureLoader = new Eu(this.options.manager), this.textureLoader.setCrossOrigin(this.options.crossOrigin), this.textureLoader.setRequestHeader(this.options.requestHeader), this.fileLoader = new Uh(this.options.manager), this.fileLoader.setResponseType("arraybuffer"), this.options.crossOrigin === "use-credentials" && this.fileLoader.setWithCredentials(!0);
  }
  setExtensions(t) {
    this.extensions = t;
  }
  setPlugins(t) {
    this.plugins = t;
  }
  parse(t, e) {
    const i = this, n = this.json, s = this.extensions;
    this.cache.removeAll(), this.nodeCache = {}, this._invokeAll(function(r) {
      return r._markDefs && r._markDefs();
    }), Promise.all(this._invokeAll(function(r) {
      return r.beforeRoot && r.beforeRoot();
    })).then(function() {
      return Promise.all([
        i.getDependencies("scene"),
        i.getDependencies("animation"),
        i.getDependencies("camera")
      ]);
    }).then(function(r) {
      const o = {
        scene: r[0][n.scene || 0],
        scenes: r[0],
        animations: r[1],
        cameras: r[2],
        asset: n.asset,
        parser: i,
        userData: {}
      };
      return we(s, o, n), se(o, n), Promise.all(i._invokeAll(function(h) {
        return h.afterRoot && h.afterRoot(o);
      })).then(function() {
        t(o);
      });
    }).catch(e);
  }
  /**
   * Marks the special nodes/meshes in json for efficient parse.
   */
  _markDefs() {
    const t = this.json.nodes || [], e = this.json.skins || [], i = this.json.meshes || [];
    for (let n = 0, s = e.length; n < s; n++) {
      const r = e[n].joints;
      for (let o = 0, h = r.length; o < h; o++)
        t[r[o]].isBone = !0;
    }
    for (let n = 0, s = t.length; n < s; n++) {
      const r = t[n];
      r.mesh !== void 0 && (this._addNodeRef(this.meshCache, r.mesh), r.skin !== void 0 && (i[r.mesh].isSkinnedMesh = !0)), r.camera !== void 0 && this._addNodeRef(this.cameraCache, r.camera);
    }
  }
  /**
   * Counts references to shared node / Object3D resources. These resources
   * can be reused, or "instantiated", at multiple nodes in the scene
   * hierarchy. Mesh, Camera, and Light instances are instantiated and must
   * be marked. Non-scenegraph resources (like Materials, Geometries, and
   * Textures) can be reused directly and are not marked here.
   *
   * Example: CesiumMilkTruck sample model reuses "Wheel" meshes.
   */
  _addNodeRef(t, e) {
    e !== void 0 && (t.refs[e] === void 0 && (t.refs[e] = t.uses[e] = 0), t.refs[e]++);
  }
  /** Returns a reference to a shared resource, cloning it if necessary. */
  _getNodeRef(t, e, i) {
    if (t.refs[e] <= 1)
      return i;
    const n = i.clone(), s = (r, o) => {
      const h = this.associations.get(r);
      h != null && this.associations.set(o, h);
      for (const [l, c] of r.children.entries())
        s(c, o.children[l]);
    };
    return s(i, n), n.name += "_instance_" + t.uses[e]++, n;
  }
  _invokeOne(t) {
    const e = Object.values(this.plugins);
    e.push(this);
    for (let i = 0; i < e.length; i++) {
      const n = t(e[i]);
      if (n)
        return n;
    }
    return null;
  }
  _invokeAll(t) {
    const e = Object.values(this.plugins);
    e.unshift(this);
    const i = [];
    for (let n = 0; n < e.length; n++) {
      const s = t(e[n]);
      s && i.push(s);
    }
    return i;
  }
  /**
   * Requests the specified dependency asynchronously, with caching.
   * @param {string} type
   * @param {number} index
   * @return {Promise<Object3D|Material|THREE.Texture|AnimationClip|ArrayBuffer|Object>}
   */
  getDependency(t, e) {
    const i = t + ":" + e;
    let n = this.cache.get(i);
    if (!n) {
      switch (t) {
        case "scene":
          n = this.loadScene(e);
          break;
        case "node":
          n = this._invokeOne(function(s) {
            return s.loadNode && s.loadNode(e);
          });
          break;
        case "mesh":
          n = this._invokeOne(function(s) {
            return s.loadMesh && s.loadMesh(e);
          });
          break;
        case "accessor":
          n = this.loadAccessor(e);
          break;
        case "bufferView":
          n = this._invokeOne(function(s) {
            return s.loadBufferView && s.loadBufferView(e);
          });
          break;
        case "buffer":
          n = this.loadBuffer(e);
          break;
        case "material":
          n = this._invokeOne(function(s) {
            return s.loadMaterial && s.loadMaterial(e);
          });
          break;
        case "texture":
          n = this._invokeOne(function(s) {
            return s.loadTexture && s.loadTexture(e);
          });
          break;
        case "skin":
          n = this.loadSkin(e);
          break;
        case "animation":
          n = this._invokeOne(function(s) {
            return s.loadAnimation && s.loadAnimation(e);
          });
          break;
        case "camera":
          n = this.loadCamera(e);
          break;
        default:
          if (n = this._invokeOne(function(s) {
            return s != this && s.getDependency && s.getDependency(t, e);
          }), !n)
            throw new Error("Unknown type: " + t);
          break;
      }
      this.cache.add(i, n);
    }
    return n;
  }
  /**
   * Requests all dependencies of the specified type asynchronously, with caching.
   * @param {string} type
   * @return {Promise<Array<Object>>}
   */
  getDependencies(t) {
    let e = this.cache.get(t);
    if (!e) {
      const i = this, n = this.json[t + (t === "mesh" ? "es" : "s")] || [];
      e = Promise.all(n.map(function(s, r) {
        return i.getDependency(t, r);
      })), this.cache.add(t, e);
    }
    return e;
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#buffers-and-buffer-views
   * @param {number} bufferIndex
   * @return {Promise<ArrayBuffer>}
   */
  loadBuffer(t) {
    const e = this.json.buffers[t], i = this.fileLoader;
    if (e.type && e.type !== "arraybuffer")
      throw new Error("THREE.GLTFLoader: " + e.type + " buffer type is not supported.");
    if (e.uri === void 0 && t === 0)
      return Promise.resolve(this.extensions[B.KHR_BINARY_GLTF].body);
    const n = this.options;
    return new Promise(function(s, r) {
      i.load(cr.resolveURL(e.uri, n.path), s, void 0, function() {
        r(new Error('THREE.GLTFLoader: Failed to load buffer "' + e.uri + '".'));
      });
    });
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#buffers-and-buffer-views
   * @param {number} bufferViewIndex
   * @return {Promise<ArrayBuffer>}
   */
  loadBufferView(t) {
    const e = this.json.bufferViews[t];
    return this.getDependency("buffer", e.buffer).then(function(i) {
      const n = e.byteLength || 0, s = e.byteOffset || 0;
      return i.slice(s, s + n);
    });
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#accessors
   * @param {number} accessorIndex
   * @return {Promise<BufferAttribute|InterleavedBufferAttribute>}
   */
  loadAccessor(t) {
    const e = this, i = this.json, n = this.json.accessors[t];
    if (n.bufferView === void 0 && n.sparse === void 0) {
      const r = Ps[n.type], o = Ze[n.componentType], h = n.normalized === !0, l = new o(n.count * r);
      return Promise.resolve(new Tt(l, r, h));
    }
    const s = [];
    return n.bufferView !== void 0 ? s.push(this.getDependency("bufferView", n.bufferView)) : s.push(null), n.sparse !== void 0 && (s.push(this.getDependency("bufferView", n.sparse.indices.bufferView)), s.push(this.getDependency("bufferView", n.sparse.values.bufferView))), Promise.all(s).then(function(r) {
      const o = r[0], h = Ps[n.type], l = Ze[n.componentType], c = l.BYTES_PER_ELEMENT, u = c * h, d = n.byteOffset || 0, f = n.bufferView !== void 0 ? i.bufferViews[n.bufferView].byteStride : void 0, p = n.normalized === !0;
      let y, m;
      if (f && f !== u) {
        const _ = Math.floor(d / f), b = "InterleavedBuffer:" + n.bufferView + ":" + n.componentType + ":" + _ + ":" + n.count;
        let A = e.cache.get(b);
        A || (y = new l(o, _ * f, n.count * f / c), A = new Zc(y, f / c), e.cache.add(b, A)), m = new $r(A, h, d % f / c, p);
      } else
        o === null ? y = new l(n.count * h) : y = new l(o, d, n.count * h), m = new Tt(y, h, p);
      if (n.sparse !== void 0) {
        const _ = Ps.SCALAR, b = Ze[n.sparse.indices.componentType], A = n.sparse.indices.byteOffset || 0, g = n.sparse.values.byteOffset || 0, x = new b(r[1], A, n.sparse.count * _), v = new l(r[2], g, n.sparse.count * h);
        o !== null && (m = new Tt(m.array.slice(), m.itemSize, m.normalized));
        for (let M = 0, T = x.length; M < T; M++) {
          const I = x[M];
          if (m.setX(I, v[M * h]), h >= 2 && m.setY(I, v[M * h + 1]), h >= 3 && m.setZ(I, v[M * h + 2]), h >= 4 && m.setW(I, v[M * h + 3]), h >= 5)
            throw new Error("THREE.GLTFLoader: Unsupported itemSize in sparse BufferAttribute.");
        }
      }
      return m;
    });
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#textures
   * @param {number} textureIndex
   * @return {Promise<THREE.Texture|null>}
   */
  loadTexture(t) {
    const e = this.json, i = this.options, s = e.textures[t].source, r = e.images[s];
    let o = this.textureLoader;
    if (r.uri) {
      const h = i.manager.getHandler(r.uri);
      h !== null && (o = h);
    }
    return this.loadTextureImage(t, s, o);
  }
  loadTextureImage(t, e, i) {
    const n = this, s = this.json, r = s.textures[t], o = s.images[e], h = (o.uri || o.bufferView) + ":" + r.sampler;
    if (this.textureCache[h])
      return this.textureCache[h];
    const l = this.loadImageSource(e, i).then(function(c) {
      c.flipY = !1, c.name = r.name || o.name || "", c.name === "" && typeof o.uri == "string" && o.uri.startsWith("data:image/") === !1 && (c.name = o.uri);
      const d = (s.samplers || {})[r.sampler] || {};
      return c.magFilter = Mo[d.magFilter] || kr, c.minFilter = Mo[d.minFilter] || zr, c.wrapS = Eo[d.wrapS] || Ri, c.wrapT = Eo[d.wrapT] || Ri, n.associations.set(c, { textures: t }), c;
    }).catch(function() {
      return null;
    });
    return this.textureCache[h] = l, l;
  }
  loadImageSource(t, e) {
    const i = this, n = this.json, s = this.options;
    if (this.sourceCache[t] !== void 0)
      return this.sourceCache[t].then((u) => u.clone());
    const r = n.images[t], o = self.URL || self.webkitURL;
    let h = r.uri || "", l = !1;
    if (r.bufferView !== void 0)
      h = i.getDependency("bufferView", r.bufferView).then(function(u) {
        l = !0;
        const d = new Blob([u], { type: r.mimeType });
        return h = o.createObjectURL(d), h;
      });
    else if (r.uri === void 0)
      throw new Error("THREE.GLTFLoader: Image " + t + " is missing URI and bufferView");
    const c = Promise.resolve(h).then(function(u) {
      return new Promise(function(d, f) {
        let p = d;
        e.isImageBitmapLoader === !0 && (p = function(y) {
          const m = new Et(y);
          m.needsUpdate = !0, d(m);
        }), e.load(cr.resolveURL(u, s.path), p, void 0, f);
      });
    }).then(function(u) {
      return l === !0 && o.revokeObjectURL(h), u.userData.mimeType = r.mimeType || md(r.uri), u;
    }).catch(function(u) {
      throw console.error("THREE.GLTFLoader: Couldn't load texture", h), u;
    });
    return this.sourceCache[t] = c, c;
  }
  /**
   * Asynchronously assigns a texture to the given material parameters.
   * @param {Object} materialParams
   * @param {string} mapName
   * @param {Object} mapDef
   * @return {Promise<Texture>}
   */
  assignTexture(t, e, i, n) {
    const s = this;
    return this.getDependency("texture", i.index).then(function(r) {
      if (!r)
        return null;
      if (i.texCoord !== void 0 && i.texCoord > 0 && (r = r.clone(), r.channel = i.texCoord), s.extensions[B.KHR_TEXTURE_TRANSFORM]) {
        const o = i.extensions !== void 0 ? i.extensions[B.KHR_TEXTURE_TRANSFORM] : void 0;
        if (o) {
          const h = s.associations.get(r);
          r = s.extensions[B.KHR_TEXTURE_TRANSFORM].extendTexture(r, o), s.associations.set(r, h);
        }
      }
      return n !== void 0 && (r.colorSpace = n), t[e] = r, r;
    });
  }
  /**
   * Assigns final material to a Mesh, Line, or Points instance. The instance
   * already has a material (generated from the glTF material options alone)
   * but reuse of the same glTF material may require multiple threejs materials
   * to accommodate different primitive types, defines, etc. New materials will
   * be created if necessary, and reused from a cache.
   * @param  {Object3D} mesh Mesh, Line, or Points instance.
   */
  assignFinalMaterial(t) {
    const e = t.geometry;
    let i = t.material;
    const n = e.attributes.tangent === void 0, s = e.attributes.color !== void 0, r = e.attributes.normal === void 0;
    if (t.isPoints) {
      const o = "PointsMaterial:" + i.uuid;
      let h = this.cache.get(o);
      h || (h = new Bh(), Ee.prototype.copy.call(h, i), h.color.copy(i.color), h.map = i.map, h.sizeAttenuation = !1, this.cache.add(o, h)), i = h;
    } else if (t.isLine) {
      const o = "LineBasicMaterial:" + i.uuid;
      let h = this.cache.get(o);
      h || (h = new jn(), Ee.prototype.copy.call(h, i), h.color.copy(i.color), h.map = i.map, this.cache.add(o, h)), i = h;
    }
    if (n || s || r) {
      let o = "ClonedMaterial:" + i.uuid + ":";
      n && (o += "derivative-tangents:"), s && (o += "vertex-colors:"), r && (o += "flat-shading:");
      let h = this.cache.get(o);
      h || (h = i.clone(), s && (h.vertexColors = !0), r && (h.flatShading = !0), n && (h.normalScale && (h.normalScale.y *= -1), h.clearcoatNormalScale && (h.clearcoatNormalScale.y *= -1)), this.cache.add(o, h), this.associations.set(h, this.associations.get(i))), i = h;
    }
    t.material = i;
  }
  getMaterialType() {
    return Gr;
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#materials
   * @param {number} materialIndex
   * @return {Promise<Material>}
   */
  loadMaterial(t) {
    const e = this, i = this.json, n = this.extensions, s = i.materials[t];
    let r;
    const o = {}, h = s.extensions || {}, l = [];
    if (h[B.KHR_MATERIALS_UNLIT]) {
      const u = n[B.KHR_MATERIALS_UNLIT];
      r = u.getMaterialType(), l.push(u.extendParams(o, s, e));
    } else {
      const u = s.pbrMetallicRoughness || {};
      if (o.color = new J(1, 1, 1), o.opacity = 1, Array.isArray(u.baseColorFactor)) {
        const d = u.baseColorFactor;
        o.color.setRGB(d[0], d[1], d[2], St), o.opacity = d[3];
      }
      u.baseColorTexture !== void 0 && l.push(e.assignTexture(o, "map", u.baseColorTexture, st)), o.metalness = u.metallicFactor !== void 0 ? u.metallicFactor : 1, o.roughness = u.roughnessFactor !== void 0 ? u.roughnessFactor : 1, u.metallicRoughnessTexture !== void 0 && (l.push(e.assignTexture(o, "metalnessMap", u.metallicRoughnessTexture)), l.push(e.assignTexture(o, "roughnessMap", u.metallicRoughnessTexture))), r = this._invokeOne(function(d) {
        return d.getMaterialType && d.getMaterialType(t);
      }), l.push(Promise.all(this._invokeAll(function(d) {
        return d.extendMaterialParams && d.extendMaterialParams(t, o);
      })));
    }
    s.doubleSided === !0 && (o.side = Jl);
    const c = s.alphaMode || Is.OPAQUE;
    if (c === Is.BLEND ? (o.transparent = !0, o.depthWrite = !1) : (o.transparent = !1, c === Is.MASK && (o.alphaTest = s.alphaCutoff !== void 0 ? s.alphaCutoff : 0.5)), s.normalTexture !== void 0 && r !== ce && (l.push(e.assignTexture(o, "normalMap", s.normalTexture)), o.normalScale = new G(1, 1), s.normalTexture.scale !== void 0)) {
      const u = s.normalTexture.scale;
      o.normalScale.set(u, u);
    }
    if (s.occlusionTexture !== void 0 && r !== ce && (l.push(e.assignTexture(o, "aoMap", s.occlusionTexture)), s.occlusionTexture.strength !== void 0 && (o.aoMapIntensity = s.occlusionTexture.strength)), s.emissiveFactor !== void 0 && r !== ce) {
      const u = s.emissiveFactor;
      o.emissive = new J().setRGB(u[0], u[1], u[2], St);
    }
    return s.emissiveTexture !== void 0 && r !== ce && l.push(e.assignTexture(o, "emissiveMap", s.emissiveTexture, st)), Promise.all(l).then(function() {
      const u = new r(o);
      return s.name && (u.name = s.name), se(u, s), e.associations.set(u, { materials: t }), s.extensions && we(n, u, s), u;
    });
  }
  /** When Object3D instances are targeted by animation, they need unique names. */
  createUniqueName(t) {
    const e = j.sanitizeNodeName(t || "");
    return e in this.nodeNamesUsed ? e + "_" + ++this.nodeNamesUsed[e] : (this.nodeNamesUsed[e] = 0, e);
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#geometry
   *
   * Creates BufferGeometries from primitives.
   *
   * @param {Array<GLTF.Primitive>} primitives
   * @return {Promise<Array<BufferGeometry>>}
   */
  loadGeometries(t) {
    const e = this, i = this.extensions, n = this.primitiveCache;
    function s(o) {
      return i[B.KHR_DRACO_MESH_COMPRESSION].decodePrimitive(o, e).then(function(h) {
        return To(h, o, e);
      });
    }
    const r = [];
    for (let o = 0, h = t.length; o < h; o++) {
      const l = t[o], c = pd(l), u = n[c];
      if (u)
        r.push(u.promise);
      else {
        let d;
        l.extensions && l.extensions[B.KHR_DRACO_MESH_COMPRESSION] ? d = s(l) : d = To(new Dt(), l, e), n[c] = { primitive: l, promise: d }, r.push(d);
      }
    }
    return Promise.all(r);
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/blob/master/specification/2.0/README.md#meshes
   * @param {number} meshIndex
   * @return {Promise<Group|Mesh|SkinnedMesh>}
   */
  loadMesh(t) {
    const e = this, i = this.json, n = this.extensions, s = i.meshes[t], r = s.primitives, o = [];
    for (let h = 0, l = r.length; h < l; h++) {
      const c = r[h].material === void 0 ? ud(this.cache) : this.getDependency("material", r[h].material);
      o.push(c);
    }
    return o.push(e.loadGeometries(r)), Promise.all(o).then(function(h) {
      const l = h.slice(0, h.length - 1), c = h[h.length - 1], u = [];
      for (let f = 0, p = c.length; f < p; f++) {
        const y = c[f], m = r[f];
        let _;
        const b = l[f];
        if (m.mode === gt.TRIANGLES || m.mode === gt.TRIANGLE_STRIP || m.mode === gt.TRIANGLE_FAN || m.mode === void 0)
          _ = s.isSkinnedMesh === !0 ? new tu(y, b) : new Se(y, b), _.isSkinnedMesh === !0 && _.normalizeSkinWeights(), m.mode === gt.TRIANGLE_STRIP ? _.geometry = vo(_.geometry, Rh) : m.mode === gt.TRIANGLE_FAN && (_.geometry = vo(_.geometry, nr));
        else if (m.mode === gt.LINES)
          _ = new ru(y, b);
        else if (m.mode === gt.LINE_STRIP)
          _ = new Li(y, b);
        else if (m.mode === gt.LINE_LOOP)
          _ = new au(y, b);
        else if (m.mode === gt.POINTS)
          _ = new ou(y, b);
        else
          throw new Error("THREE.GLTFLoader: Primitive mode unsupported: " + m.mode);
        Object.keys(_.geometry.morphAttributes).length > 0 && fd(_, s), _.name = e.createUniqueName(s.name || "mesh_" + t), se(_, s), m.extensions && we(n, _, m), e.assignFinalMaterial(_), u.push(_);
      }
      for (let f = 0, p = u.length; f < p; f++)
        e.associations.set(u[f], {
          meshes: t,
          primitives: f
        });
      if (u.length === 1)
        return s.extensions && we(n, u[0], s), u[0];
      const d = new vs();
      s.extensions && we(n, d, s), e.associations.set(d, { meshes: t });
      for (let f = 0, p = u.length; f < p; f++)
        d.add(u[f]);
      return d;
    });
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#cameras
   * @param {number} cameraIndex
   * @return {Promise<THREE.Camera>}
   */
  loadCamera(t) {
    let e;
    const i = this.json.cameras[t], n = i[i.type];
    if (!n) {
      console.warn("THREE.GLTFLoader: Missing camera parameters.");
      return;
    }
    return i.type === "perspective" ? e = new Un(Hr.radToDeg(n.yfov), n.aspectRatio || 1, n.znear || 1, n.zfar || 2e6) : i.type === "orthographic" && (e = new Lh(-n.xmag, n.xmag, n.ymag, -n.ymag, n.znear, n.zfar)), i.name && (e.name = this.createUniqueName(i.name)), se(e, i), Promise.resolve(e);
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#skins
   * @param {number} skinIndex
   * @return {Promise<Skeleton>}
   */
  loadSkin(t) {
    const e = this.json.skins[t], i = [];
    for (let n = 0, s = e.joints.length; n < s; n++)
      i.push(this._loadNodeShallow(e.joints[n]));
    return e.inverseBindMatrices !== void 0 ? i.push(this.getDependency("accessor", e.inverseBindMatrices)) : i.push(null), Promise.all(i).then(function(n) {
      const s = n.pop(), r = n, o = [], h = [];
      for (let l = 0, c = r.length; l < c; l++) {
        const u = r[l];
        if (u) {
          o.push(u);
          const d = new F();
          s !== null && d.fromArray(s.array, l * 16), h.push(d);
        } else
          console.warn('THREE.GLTFLoader: Joint "%s" could not be found.', e.joints[l]);
      }
      return new Vr(o, h);
    });
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#animations
   * @param {number} animationIndex
   * @return {Promise<AnimationClip>}
   */
  loadAnimation(t) {
    const e = this.json, i = this, n = e.animations[t], s = n.name ? n.name : "animation_" + t, r = [], o = [], h = [], l = [], c = [];
    for (let u = 0, d = n.channels.length; u < d; u++) {
      const f = n.channels[u], p = n.samplers[f.sampler], y = f.target, m = y.node, _ = n.parameters !== void 0 ? n.parameters[p.input] : p.input, b = n.parameters !== void 0 ? n.parameters[p.output] : p.output;
      y.node !== void 0 && (r.push(this.getDependency("node", m)), o.push(this.getDependency("accessor", _)), h.push(this.getDependency("accessor", b)), l.push(p), c.push(y));
    }
    return Promise.all([
      Promise.all(r),
      Promise.all(o),
      Promise.all(h),
      Promise.all(l),
      Promise.all(c)
    ]).then(function(u) {
      const d = u[0], f = u[1], p = u[2], y = u[3], m = u[4], _ = [];
      for (let b = 0, A = d.length; b < A; b++) {
        const g = d[b], x = f[b], v = p[b], M = y[b], T = m[b];
        if (g === void 0)
          continue;
        g.updateMatrix && g.updateMatrix();
        const I = i._createAnimationTracks(g, x, v, M, T);
        if (I)
          for (let E = 0; E < I.length; E++)
            _.push(I[E]);
      }
      return new lr(s, void 0, _);
    });
  }
  createNodeMesh(t) {
    const e = this.json, i = this, n = e.nodes[t];
    return n.mesh === void 0 ? null : i.getDependency("mesh", n.mesh).then(function(s) {
      const r = i._getNodeRef(i.meshCache, n.mesh, s);
      return n.weights !== void 0 && r.traverse(function(o) {
        if (o.isMesh)
          for (let h = 0, l = n.weights.length; h < l; h++)
            o.morphTargetInfluences[h] = n.weights[h];
      }), r;
    });
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#nodes-and-hierarchy
   * @param {number} nodeIndex
   * @return {Promise<Object3D>}
   */
  loadNode(t) {
    const e = this.json, i = this, n = e.nodes[t], s = i._loadNodeShallow(t), r = [], o = n.children || [];
    for (let l = 0, c = o.length; l < c; l++)
      r.push(i.getDependency("node", o[l]));
    const h = n.skin === void 0 ? Promise.resolve(null) : i.getDependency("skin", n.skin);
    return Promise.all([
      s,
      Promise.all(r),
      h
    ]).then(function(l) {
      const c = l[0], u = l[1], d = l[2];
      d !== null && c.traverse(function(f) {
        f.isSkinnedMesh && f.bind(d, yd);
      });
      for (let f = 0, p = u.length; f < p; f++)
        c.add(u[f]);
      return c;
    });
  }
  // ._loadNodeShallow() parses a single node.
  // skin and child nodes are created and added in .loadNode() (no '_' prefix).
  _loadNodeShallow(t) {
    const e = this.json, i = this.extensions, n = this;
    if (this.nodeCache[t] !== void 0)
      return this.nodeCache[t];
    const s = e.nodes[t], r = s.name ? n.createUniqueName(s.name) : "", o = [], h = n._invokeOne(function(l) {
      return l.createNodeMesh && l.createNodeMesh(t);
    });
    return h && o.push(h), s.camera !== void 0 && o.push(n.getDependency("camera", s.camera).then(function(l) {
      return n._getNodeRef(n.cameraCache, s.camera, l);
    })), n._invokeAll(function(l) {
      return l.createNodeAttachment && l.createNodeAttachment(t);
    }).forEach(function(l) {
      o.push(l);
    }), this.nodeCache[t] = Promise.all(o).then(function(l) {
      let c;
      if (s.isBone === !0 ? c = new Dh() : l.length > 1 ? c = new vs() : l.length === 1 ? c = l[0] : c = new q(), c !== l[0])
        for (let u = 0, d = l.length; u < d; u++)
          c.add(l[u]);
      if (s.name && (c.userData.name = s.name, c.name = r), se(c, s), s.extensions && we(i, c, s), s.matrix !== void 0) {
        const u = new F();
        u.fromArray(s.matrix), c.applyMatrix4(u);
      } else
        s.translation !== void 0 && c.position.fromArray(s.translation), s.rotation !== void 0 && c.quaternion.fromArray(s.rotation), s.scale !== void 0 && c.scale.fromArray(s.scale);
      return n.associations.has(c) || n.associations.set(c, {}), n.associations.get(c).nodes = t, c;
    }), this.nodeCache[t];
  }
  /**
   * Specification: https://github.com/KhronosGroup/glTF/tree/master/specification/2.0#scenes
   * @param {number} sceneIndex
   * @return {Promise<Group>}
   */
  loadScene(t) {
    const e = this.extensions, i = this.json.scenes[t], n = this, s = new vs();
    i.name && (s.name = n.createUniqueName(i.name)), se(s, i), i.extensions && we(e, s, i);
    const r = i.nodes || [], o = [];
    for (let h = 0, l = r.length; h < l; h++)
      o.push(n.getDependency("node", r[h]));
    return Promise.all(o).then(function(h) {
      for (let c = 0, u = h.length; c < u; c++)
        s.add(h[c]);
      const l = (c) => {
        const u = /* @__PURE__ */ new Map();
        for (const [d, f] of n.associations)
          (d instanceof Ee || d instanceof Et) && u.set(d, f);
        return c.traverse((d) => {
          const f = n.associations.get(d);
          f != null && u.set(d, f);
        }), u;
      };
      return n.associations = l(s), s;
    });
  }
  _createAnimationTracks(t, e, i, n, s) {
    const r = [], o = t.name ? t.name : t.uuid, h = [];
    ne[s.path] === ne.weights ? t.traverse(function(d) {
      d.morphTargetInfluences && h.push(d.name ? d.name : d.uuid);
    }) : h.push(o);
    let l;
    switch (ne[s.path]) {
      case ne.weights:
        l = ii;
        break;
      case ne.rotation:
        l = Te;
        break;
      case ne.position:
      case ne.scale:
        l = ni;
        break;
      default:
        switch (i.itemSize) {
          case 1:
            l = ii;
            break;
          case 2:
          case 3:
          default:
            l = ni;
            break;
        }
        break;
    }
    const c = n.interpolation !== void 0 ? cd[n.interpolation] : ei, u = this._getArrayFromAccessor(i);
    for (let d = 0, f = h.length; d < f; d++) {
      const p = new l(
        h[d] + "." + ne[s.path],
        e.array,
        u,
        c
      );
      n.interpolation === "CUBICSPLINE" && this._createCubicSplineTrackInterpolant(p), r.push(p);
    }
    return r;
  }
  _getArrayFromAccessor(t) {
    let e = t.array;
    if (t.normalized) {
      const i = fr(e.constructor), n = new Float32Array(e.length);
      for (let s = 0, r = e.length; s < r; s++)
        n[s] = e[s] * i;
      e = n;
    }
    return e;
  }
  _createCubicSplineTrackInterpolant(t) {
    t.createInterpolant = function(i) {
      const n = this instanceof Te ? ld : Wh;
      return new n(this.times, this.values, this.getValueSize() / 3, i);
    }, t.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline = !0;
  }
}
function _d(a, t, e) {
  const i = t.attributes, n = new Kt();
  if (i.POSITION !== void 0) {
    const o = e.json.accessors[i.POSITION], h = o.min, l = o.max;
    if (h !== void 0 && l !== void 0) {
      if (n.set(
        new w(h[0], h[1], h[2]),
        new w(l[0], l[1], l[2])
      ), o.normalized) {
        const c = fr(Ze[o.componentType]);
        n.min.multiplyScalar(c), n.max.multiplyScalar(c);
      }
    } else {
      console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");
      return;
    }
  } else
    return;
  const s = t.targets;
  if (s !== void 0) {
    const o = new w(), h = new w();
    for (let l = 0, c = s.length; l < c; l++) {
      const u = s[l];
      if (u.POSITION !== void 0) {
        const d = e.json.accessors[u.POSITION], f = d.min, p = d.max;
        if (f !== void 0 && p !== void 0) {
          if (h.setX(Math.max(Math.abs(f[0]), Math.abs(p[0]))), h.setY(Math.max(Math.abs(f[1]), Math.abs(p[1]))), h.setZ(Math.max(Math.abs(f[2]), Math.abs(p[2]))), d.normalized) {
            const y = fr(Ze[d.componentType]);
            h.multiplyScalar(y);
          }
          o.max(h);
        } else
          console.warn("THREE.GLTFLoader: Missing min/max properties for accessor POSITION.");
      }
    }
    n.expandByVector(o);
  }
  a.boundingBox = n;
  const r = new Lt();
  n.getCenter(r.center), r.radius = n.min.distanceTo(n.max) / 2, a.boundingSphere = r;
}
function To(a, t, e) {
  const i = t.attributes, n = [];
  function s(r, o) {
    return e.getDependency("accessor", r).then(function(h) {
      a.setAttribute(o, h);
    });
  }
  for (const r in i) {
    const o = dr[r] || r.toLowerCase();
    o in a.attributes || n.push(s(i[r], o));
  }
  if (t.indices !== void 0 && !a.index) {
    const r = e.getDependency("accessor", t.indices).then(function(o) {
      a.setIndex(o);
    });
    n.push(r);
  }
  return mt.workingColorSpace !== St && "COLOR_0" in i && console.warn(`THREE.GLTFLoader: Converting vertex colors from "srgb-linear" to "${mt.workingColorSpace}" not supported.`), se(a, t), _d(a, t, e), Promise.all(n).then(function() {
    return t.targets !== void 0 ? dd(a, t.targets, e) : a;
  });
}
function xd(a, t) {
  new $h().load(a, (i) => {
    if (i.scene.children.length > 0) {
      const n = i.scene.children[0];
      t(n);
    }
  });
}
function wd({
  cloudMaterials: a,
  onComplete: t
}) {
  const e = {}, i = async (s) => new Promise((r, o) => {
    new jh().load(
      s,
      (l) => {
        r(l);
      },
      void 0,
      (l) => {
        o(l);
      }
    );
  });
  (async () => {
    const s = Object.entries(a).map(
      async ([r, o]) => {
        const h = {
          name: r,
          loadedTextures: {}
        }, l = [
          {
            config: o.color_map_config,
            key: "colorMap"
          },
          {
            config: o.emissive_map_config,
            key: "emissiveMap"
          },
          {
            config: o.metallic_map_config,
            key: "metallicMap"
          },
          {
            config: o.roughness_map_config,
            key: "roughnessMap"
          },
          {
            config: o.ambientocclusion_map_config,
            key: "ambientOcclusionMap"
          },
          {
            config: o.height_map_config,
            key: "heightMap"
          },
          {
            config: o.normal_map_config,
            key: "normalMap"
          },
          {
            config: o.alpha_map_config,
            key: "alphaMap"
          }
        ];
        for (const { config: c, key: u } of l)
          if (c != null && c.texture_map) {
            const d = typeof c.texture_map == "object" && "high" in c.texture_map ? c.texture_map.high : c.texture_map, f = await i(d);
            h.loadedTextures[u] = {
              texture: f
            }, h.loadedTextures[u].texture.flipY = c.flipY || !1;
          }
        e[r] = h;
      }
    );
    await Promise.all(s), t && t(e);
  })();
}
class bd {
  constructor() {
    this.meshInstance = null, this.animationClipsInstance = null, this.animationMixer = null, this.animationActions = {}, this.isInitialized = !1, this.currentAnimation = null;
  }
  init(t, e) {
    if (this.isInitialized) {
      console.warn("AnimationPlayer is already initialized.");
      return;
    }
    this.meshInstance = t, this.animationClipsInstance = e, this.createAnimationActions(), this.isInitialized = !0;
  }
  initAndPlayDefault(t, e) {
    this.init(t, e), this.playDefault();
  }
  createAnimationActions() {
    const t = this.meshInstance, e = this.animationClipsInstance || {};
    this.animationMixer || !t || Object.keys(e).length <= 0 || (this.animationMixer = new ku(t), Object.entries(e).forEach(([i, n]) => {
      const s = this.animationMixer.clipAction(n);
      s.loop = Sh, s.clampWhenFinished = !0, this.animationActions[i] || (this.animationActions[i] = []), this.animationActions[i].push(s);
    }));
  }
  update(t) {
    this.animationMixer && this.animationMixer.update(t);
  }
  playDefault() {
    const t = "idle", e = this.animationActions[t];
    e && (e.forEach((i) => {
      i.play();
    }), this.currentAnimation = t);
  }
  play(t, e = 0.25) {
    if (this.currentAnimation === t)
      return;
    const i = this.animationActions[t] || [];
    i.forEach((n) => {
      n.reset(), n.play();
    }), this.currentAnimation && (this.animationActions[this.currentAnimation] || []).forEach((s, r) => {
      const o = i[r];
      o && s.crossFadeTo(
        o,
        e,
        !0
      );
    }), this.currentAnimation = t;
  }
  stop(t) {
    (this.animationActions[t] || []).forEach((i) => {
      i.stop();
    });
  }
  getCurrentAnimation() {
    return this.currentAnimation;
  }
}
function vd({
  scene: a,
  mesh: t,
  position: e,
  onComplete: i
}) {
  if (!t) {
    console.warn("Mesh is null in CXYZSkeletalMeshSpawner.");
    return;
  }
  t.position.copy(e), a.add(t), i && i(t);
}
function Ad({
  meshInstance: a,
  materialsInstance: t,
  onComplete: e
}) {
  const i = () => {
    const s = a, r = t;
    r && Object.keys(r).length > 0 && s && s.traverse((o) => {
      if (o instanceof Se) {
        const h = o.material.name, l = r[h];
        l && n(l, o.material);
      }
    });
  }, n = (s, r) => {
    s.loadedTextures.colorMap && (r.map = s.loadedTextures.colorMap.texture), s.loadedTextures.emissiveMap && (r.emissiveMap = s.loadedTextures.emissiveMap.texture), s.loadedTextures.metallicMap && (r.metalnessMap = s.loadedTextures.metallicMap.texture), s.loadedTextures.roughnessMap && (r.roughnessMap = s.loadedTextures.roughnessMap.texture), s.loadedTextures.ambientOcclusionMap && (r.aoMap = s.loadedTextures.ambientOcclusionMap.texture), s.loadedTextures.heightMap && (r.displacementMap = s.loadedTextures.heightMap.texture), s.loadedTextures.normalMap && (r.normalMap = s.loadedTextures.normalMap.texture), s.loadedTextures.alphaMap && (r.alphaMap = s.loadedTextures.alphaMap.texture, r.transparent = !0);
  };
  return i(), e && e(), null;
}
const So = {
  CHARACTERS_SLUG: "/characters/slug",
  CHARACTERS_MULTIPLE: "/characters/multiple"
};
function Zr(a) {
  return a && a.__esModule && Object.prototype.hasOwnProperty.call(a, "default") ? a.default : a;
}
function Md(a) {
  if (a.__esModule)
    return a;
  var t = a.default;
  if (typeof t == "function") {
    var e = function i() {
      return this instanceof i ? Reflect.construct(t, arguments, this.constructor) : t.apply(this, arguments);
    };
    e.prototype = t.prototype;
  } else
    e = {};
  return Object.defineProperty(e, "__esModule", { value: !0 }), Object.keys(a).forEach(function(i) {
    var n = Object.getOwnPropertyDescriptor(a, i);
    Object.defineProperty(e, i, n.get ? n : {
      enumerable: !0,
      get: function() {
        return a[i];
      }
    });
  }), e;
}
var Qr = { exports: {} }, qh = function(t, e) {
  return function() {
    for (var n = new Array(arguments.length), s = 0; s < n.length; s++)
      n[s] = arguments[s];
    return t.apply(e, n);
  };
}, Ed = qh, fe = Object.prototype.toString;
function ta(a) {
  return Array.isArray(a);
}
function pr(a) {
  return typeof a > "u";
}
function Td(a) {
  return a !== null && !pr(a) && a.constructor !== null && !pr(a.constructor) && typeof a.constructor.isBuffer == "function" && a.constructor.isBuffer(a);
}
function Gh(a) {
  return fe.call(a) === "[object ArrayBuffer]";
}
function Sd(a) {
  return fe.call(a) === "[object FormData]";
}
function Rd(a) {
  var t;
  return typeof ArrayBuffer < "u" && ArrayBuffer.isView ? t = ArrayBuffer.isView(a) : t = a && a.buffer && Gh(a.buffer), t;
}
function Pd(a) {
  return typeof a == "string";
}
function Id(a) {
  return typeof a == "number";
}
function Kh(a) {
  return a !== null && typeof a == "object";
}
function Cn(a) {
  if (fe.call(a) !== "[object Object]")
    return !1;
  var t = Object.getPrototypeOf(a);
  return t === null || t === Object.prototype;
}
function Cd(a) {
  return fe.call(a) === "[object Date]";
}
function Od(a) {
  return fe.call(a) === "[object File]";
}
function Nd(a) {
  return fe.call(a) === "[object Blob]";
}
function Yh(a) {
  return fe.call(a) === "[object Function]";
}
function Ld(a) {
  return Kh(a) && Yh(a.pipe);
}
function Dd(a) {
  return fe.call(a) === "[object URLSearchParams]";
}
function Bd(a) {
  return a.trim ? a.trim() : a.replace(/^\s+|\s+$/g, "");
}
function Fd() {
  return typeof navigator < "u" && (navigator.product === "ReactNative" || navigator.product === "NativeScript" || navigator.product === "NS") ? !1 : typeof window < "u" && typeof document < "u";
}
function ea(a, t) {
  if (!(a === null || typeof a > "u"))
    if (typeof a != "object" && (a = [a]), ta(a))
      for (var e = 0, i = a.length; e < i; e++)
        t.call(null, a[e], e, a);
    else
      for (var n in a)
        Object.prototype.hasOwnProperty.call(a, n) && t.call(null, a[n], n, a);
}
function mr() {
  var a = {};
  function t(n, s) {
    Cn(a[s]) && Cn(n) ? a[s] = mr(a[s], n) : Cn(n) ? a[s] = mr({}, n) : ta(n) ? a[s] = n.slice() : a[s] = n;
  }
  for (var e = 0, i = arguments.length; e < i; e++)
    ea(arguments[e], t);
  return a;
}
function kd(a, t, e) {
  return ea(t, function(n, s) {
    e && typeof n == "function" ? a[s] = Ed(n, e) : a[s] = n;
  }), a;
}
function zd(a) {
  return a.charCodeAt(0) === 65279 && (a = a.slice(1)), a;
}
var ut = {
  isArray: ta,
  isArrayBuffer: Gh,
  isBuffer: Td,
  isFormData: Sd,
  isArrayBufferView: Rd,
  isString: Pd,
  isNumber: Id,
  isObject: Kh,
  isPlainObject: Cn,
  isUndefined: pr,
  isDate: Cd,
  isFile: Od,
  isBlob: Nd,
  isFunction: Yh,
  isStream: Ld,
  isURLSearchParams: Dd,
  isStandardBrowserEnv: Fd,
  forEach: ea,
  merge: mr,
  extend: kd,
  trim: Bd,
  stripBOM: zd
}, qe = ut;
function Ro(a) {
  return encodeURIComponent(a).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
}
var Xh = function(t, e, i) {
  if (!e)
    return t;
  var n;
  if (i)
    n = i(e);
  else if (qe.isURLSearchParams(e))
    n = e.toString();
  else {
    var s = [];
    qe.forEach(e, function(h, l) {
      h === null || typeof h > "u" || (qe.isArray(h) ? l = l + "[]" : h = [h], qe.forEach(h, function(u) {
        qe.isDate(u) ? u = u.toISOString() : qe.isObject(u) && (u = JSON.stringify(u)), s.push(Ro(l) + "=" + Ro(u));
      }));
    }), n = s.join("&");
  }
  if (n) {
    var r = t.indexOf("#");
    r !== -1 && (t = t.slice(0, r)), t += (t.indexOf("?") === -1 ? "?" : "&") + n;
  }
  return t;
}, Ud = ut;
function Hn() {
  this.handlers = [];
}
Hn.prototype.use = function(t, e, i) {
  return this.handlers.push({
    fulfilled: t,
    rejected: e,
    synchronous: i ? i.synchronous : !1,
    runWhen: i ? i.runWhen : null
  }), this.handlers.length - 1;
};
Hn.prototype.eject = function(t) {
  this.handlers[t] && (this.handlers[t] = null);
};
Hn.prototype.forEach = function(t) {
  Ud.forEach(this.handlers, function(i) {
    i !== null && t(i);
  });
};
var jd = Hn, Hd = ut, $d = function(t, e) {
  Hd.forEach(t, function(n, s) {
    s !== e && s.toUpperCase() === e.toUpperCase() && (t[e] = n, delete t[s]);
  });
}, Jh = function(t, e, i, n, s) {
  return t.config = e, i && (t.code = i), t.request = n, t.response = s, t.isAxiosError = !0, t.toJSON = function() {
    return {
      // Standard
      message: this.message,
      name: this.name,
      // Microsoft
      description: this.description,
      number: this.number,
      // Mozilla
      fileName: this.fileName,
      lineNumber: this.lineNumber,
      columnNumber: this.columnNumber,
      stack: this.stack,
      // Axios
      config: this.config,
      code: this.code,
      status: this.response && this.response.status ? this.response.status : null
    };
  }, t;
}, Os, Po;
function Zh() {
  if (Po)
    return Os;
  Po = 1;
  var a = Jh;
  return Os = function(e, i, n, s, r) {
    var o = new Error(e);
    return a(o, i, n, s, r);
  }, Os;
}
var Ns, Io;
function Vd() {
  if (Io)
    return Ns;
  Io = 1;
  var a = Zh();
  return Ns = function(e, i, n) {
    var s = n.config.validateStatus;
    !n.status || !s || s(n.status) ? e(n) : i(a(
      "Request failed with status code " + n.status,
      n.config,
      null,
      n.request,
      n
    ));
  }, Ns;
}
var Ls, Co;
function Wd() {
  if (Co)
    return Ls;
  Co = 1;
  var a = ut;
  return Ls = a.isStandardBrowserEnv() ? (
    // Standard browser envs support document.cookie
    function() {
      return {
        write: function(i, n, s, r, o, h) {
          var l = [];
          l.push(i + "=" + encodeURIComponent(n)), a.isNumber(s) && l.push("expires=" + new Date(s).toGMTString()), a.isString(r) && l.push("path=" + r), a.isString(o) && l.push("domain=" + o), h === !0 && l.push("secure"), document.cookie = l.join("; ");
        },
        read: function(i) {
          var n = document.cookie.match(new RegExp("(^|;\\s*)(" + i + ")=([^;]*)"));
          return n ? decodeURIComponent(n[3]) : null;
        },
        remove: function(i) {
          this.write(i, "", Date.now() - 864e5);
        }
      };
    }()
  ) : (
    // Non standard browser env (web workers, react-native) lack needed support.
    function() {
      return {
        write: function() {
        },
        read: function() {
          return null;
        },
        remove: function() {
        }
      };
    }()
  ), Ls;
}
var Ds, Oo;
function qd() {
  return Oo || (Oo = 1, Ds = function(t) {
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(t);
  }), Ds;
}
var Bs, No;
function Gd() {
  return No || (No = 1, Bs = function(t, e) {
    return e ? t.replace(/\/+$/, "") + "/" + e.replace(/^\/+/, "") : t;
  }), Bs;
}
var Fs, Lo;
function Kd() {
  if (Lo)
    return Fs;
  Lo = 1;
  var a = qd(), t = Gd();
  return Fs = function(i, n) {
    return i && !a(n) ? t(i, n) : n;
  }, Fs;
}
var ks, Do;
function Yd() {
  if (Do)
    return ks;
  Do = 1;
  var a = ut, t = [
    "age",
    "authorization",
    "content-length",
    "content-type",
    "etag",
    "expires",
    "from",
    "host",
    "if-modified-since",
    "if-unmodified-since",
    "last-modified",
    "location",
    "max-forwards",
    "proxy-authorization",
    "referer",
    "retry-after",
    "user-agent"
  ];
  return ks = function(i) {
    var n = {}, s, r, o;
    return i && a.forEach(i.split(`
`), function(l) {
      if (o = l.indexOf(":"), s = a.trim(l.substr(0, o)).toLowerCase(), r = a.trim(l.substr(o + 1)), s) {
        if (n[s] && t.indexOf(s) >= 0)
          return;
        s === "set-cookie" ? n[s] = (n[s] ? n[s] : []).concat([r]) : n[s] = n[s] ? n[s] + ", " + r : r;
      }
    }), n;
  }, ks;
}
var zs, Bo;
function Xd() {
  if (Bo)
    return zs;
  Bo = 1;
  var a = ut;
  return zs = a.isStandardBrowserEnv() ? (
    // Standard browser envs have full support of the APIs needed to test
    // whether the request URL is of the same origin as current location.
    function() {
      var e = /(msie|trident)/i.test(navigator.userAgent), i = document.createElement("a"), n;
      function s(r) {
        var o = r;
        return e && (i.setAttribute("href", o), o = i.href), i.setAttribute("href", o), {
          href: i.href,
          protocol: i.protocol ? i.protocol.replace(/:$/, "") : "",
          host: i.host,
          search: i.search ? i.search.replace(/^\?/, "") : "",
          hash: i.hash ? i.hash.replace(/^#/, "") : "",
          hostname: i.hostname,
          port: i.port,
          pathname: i.pathname.charAt(0) === "/" ? i.pathname : "/" + i.pathname
        };
      }
      return n = s(window.location.href), function(o) {
        var h = a.isString(o) ? s(o) : o;
        return h.protocol === n.protocol && h.host === n.host;
      };
    }()
  ) : (
    // Non standard browser envs (web workers, react-native) lack needed support.
    function() {
      return function() {
        return !0;
      };
    }()
  ), zs;
}
var Us, Fo;
function $n() {
  if (Fo)
    return Us;
  Fo = 1;
  function a(t) {
    this.message = t;
  }
  return a.prototype.toString = function() {
    return "Cancel" + (this.message ? ": " + this.message : "");
  }, a.prototype.__CANCEL__ = !0, Us = a, Us;
}
var js, ko;
function zo() {
  if (ko)
    return js;
  ko = 1;
  var a = ut, t = Vd(), e = Wd(), i = Xh, n = Kd(), s = Yd(), r = Xd(), o = Zh(), h = Vn(), l = $n();
  return js = function(u) {
    return new Promise(function(f, p) {
      var y = u.data, m = u.headers, _ = u.responseType, b;
      function A() {
        u.cancelToken && u.cancelToken.unsubscribe(b), u.signal && u.signal.removeEventListener("abort", b);
      }
      a.isFormData(y) && delete m["Content-Type"];
      var g = new XMLHttpRequest();
      if (u.auth) {
        var x = u.auth.username || "", v = u.auth.password ? unescape(encodeURIComponent(u.auth.password)) : "";
        m.Authorization = "Basic " + btoa(x + ":" + v);
      }
      var M = n(u.baseURL, u.url);
      g.open(u.method.toUpperCase(), i(M, u.params, u.paramsSerializer), !0), g.timeout = u.timeout;
      function T() {
        if (g) {
          var E = "getAllResponseHeaders" in g ? s(g.getAllResponseHeaders()) : null, R = !_ || _ === "text" || _ === "json" ? g.responseText : g.response, S = {
            data: R,
            status: g.status,
            statusText: g.statusText,
            headers: E,
            config: u,
            request: g
          };
          t(function(O) {
            f(O), A();
          }, function(O) {
            p(O), A();
          }, S), g = null;
        }
      }
      if ("onloadend" in g ? g.onloadend = T : g.onreadystatechange = function() {
        !g || g.readyState !== 4 || g.status === 0 && !(g.responseURL && g.responseURL.indexOf("file:") === 0) || setTimeout(T);
      }, g.onabort = function() {
        g && (p(o("Request aborted", u, "ECONNABORTED", g)), g = null);
      }, g.onerror = function() {
        p(o("Network Error", u, null, g)), g = null;
      }, g.ontimeout = function() {
        var R = u.timeout ? "timeout of " + u.timeout + "ms exceeded" : "timeout exceeded", S = u.transitional || h.transitional;
        u.timeoutErrorMessage && (R = u.timeoutErrorMessage), p(o(
          R,
          u,
          S.clarifyTimeoutError ? "ETIMEDOUT" : "ECONNABORTED",
          g
        )), g = null;
      }, a.isStandardBrowserEnv()) {
        var I = (u.withCredentials || r(M)) && u.xsrfCookieName ? e.read(u.xsrfCookieName) : void 0;
        I && (m[u.xsrfHeaderName] = I);
      }
      "setRequestHeader" in g && a.forEach(m, function(R, S) {
        typeof y > "u" && S.toLowerCase() === "content-type" ? delete m[S] : g.setRequestHeader(S, R);
      }), a.isUndefined(u.withCredentials) || (g.withCredentials = !!u.withCredentials), _ && _ !== "json" && (g.responseType = u.responseType), typeof u.onDownloadProgress == "function" && g.addEventListener("progress", u.onDownloadProgress), typeof u.onUploadProgress == "function" && g.upload && g.upload.addEventListener("progress", u.onUploadProgress), (u.cancelToken || u.signal) && (b = function(E) {
        g && (p(!E || E && E.type ? new l("canceled") : E), g.abort(), g = null);
      }, u.cancelToken && u.cancelToken.subscribe(b), u.signal && (u.signal.aborted ? b() : u.signal.addEventListener("abort", b))), y || (y = null), g.send(y);
    });
  }, js;
}
var Hs, Uo;
function Vn() {
  if (Uo)
    return Hs;
  Uo = 1;
  var a = ut, t = $d, e = Jh, i = {
    "Content-Type": "application/x-www-form-urlencoded"
  };
  function n(h, l) {
    !a.isUndefined(h) && a.isUndefined(h["Content-Type"]) && (h["Content-Type"] = l);
  }
  function s() {
    var h;
    return (typeof XMLHttpRequest < "u" || typeof process < "u" && Object.prototype.toString.call(process) === "[object process]") && (h = zo()), h;
  }
  function r(h, l, c) {
    if (a.isString(h))
      try {
        return (l || JSON.parse)(h), a.trim(h);
      } catch (u) {
        if (u.name !== "SyntaxError")
          throw u;
      }
    return (c || JSON.stringify)(h);
  }
  var o = {
    transitional: {
      silentJSONParsing: !0,
      forcedJSONParsing: !0,
      clarifyTimeoutError: !1
    },
    adapter: s(),
    transformRequest: [function(l, c) {
      return t(c, "Accept"), t(c, "Content-Type"), a.isFormData(l) || a.isArrayBuffer(l) || a.isBuffer(l) || a.isStream(l) || a.isFile(l) || a.isBlob(l) ? l : a.isArrayBufferView(l) ? l.buffer : a.isURLSearchParams(l) ? (n(c, "application/x-www-form-urlencoded;charset=utf-8"), l.toString()) : a.isObject(l) || c && c["Content-Type"] === "application/json" ? (n(c, "application/json"), r(l)) : l;
    }],
    transformResponse: [function(l) {
      var c = this.transitional || o.transitional, u = c && c.silentJSONParsing, d = c && c.forcedJSONParsing, f = !u && this.responseType === "json";
      if (f || d && a.isString(l) && l.length)
        try {
          return JSON.parse(l);
        } catch (p) {
          if (f)
            throw p.name === "SyntaxError" ? e(p, this, "E_JSON_PARSE") : p;
        }
      return l;
    }],
    /**
     * A timeout in milliseconds to abort a request. If set to 0 (default) a
     * timeout is not created.
     */
    timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    validateStatus: function(l) {
      return l >= 200 && l < 300;
    },
    headers: {
      common: {
        Accept: "application/json, text/plain, */*"
      }
    }
  };
  return a.forEach(["delete", "get", "head"], function(l) {
    o.headers[l] = {};
  }), a.forEach(["post", "put", "patch"], function(l) {
    o.headers[l] = a.merge(i);
  }), Hs = o, Hs;
}
var Jd = ut, Zd = Vn(), Qd = function(t, e, i) {
  var n = this || Zd;
  return Jd.forEach(i, function(r) {
    t = r.call(n, t, e);
  }), t;
}, $s, jo;
function Qh() {
  return jo || (jo = 1, $s = function(t) {
    return !!(t && t.__CANCEL__);
  }), $s;
}
var Ho = ut, Vs = Qd, tf = Qh(), ef = Vn(), nf = $n();
function Ws(a) {
  if (a.cancelToken && a.cancelToken.throwIfRequested(), a.signal && a.signal.aborted)
    throw new nf("canceled");
}
var sf = function(t) {
  Ws(t), t.headers = t.headers || {}, t.data = Vs.call(
    t,
    t.data,
    t.headers,
    t.transformRequest
  ), t.headers = Ho.merge(
    t.headers.common || {},
    t.headers[t.method] || {},
    t.headers
  ), Ho.forEach(
    ["delete", "get", "head", "post", "put", "patch", "common"],
    function(n) {
      delete t.headers[n];
    }
  );
  var e = t.adapter || ef.adapter;
  return e(t).then(function(n) {
    return Ws(t), n.data = Vs.call(
      t,
      n.data,
      n.headers,
      t.transformResponse
    ), n;
  }, function(n) {
    return tf(n) || (Ws(t), n && n.response && (n.response.data = Vs.call(
      t,
      n.response.data,
      n.response.headers,
      t.transformResponse
    ))), Promise.reject(n);
  });
}, pt = ut, tl = function(t, e) {
  e = e || {};
  var i = {};
  function n(c, u) {
    return pt.isPlainObject(c) && pt.isPlainObject(u) ? pt.merge(c, u) : pt.isPlainObject(u) ? pt.merge({}, u) : pt.isArray(u) ? u.slice() : u;
  }
  function s(c) {
    if (pt.isUndefined(e[c])) {
      if (!pt.isUndefined(t[c]))
        return n(void 0, t[c]);
    } else
      return n(t[c], e[c]);
  }
  function r(c) {
    if (!pt.isUndefined(e[c]))
      return n(void 0, e[c]);
  }
  function o(c) {
    if (pt.isUndefined(e[c])) {
      if (!pt.isUndefined(t[c]))
        return n(void 0, t[c]);
    } else
      return n(void 0, e[c]);
  }
  function h(c) {
    if (c in e)
      return n(t[c], e[c]);
    if (c in t)
      return n(void 0, t[c]);
  }
  var l = {
    url: r,
    method: r,
    data: r,
    baseURL: o,
    transformRequest: o,
    transformResponse: o,
    paramsSerializer: o,
    timeout: o,
    timeoutMessage: o,
    withCredentials: o,
    adapter: o,
    responseType: o,
    xsrfCookieName: o,
    xsrfHeaderName: o,
    onUploadProgress: o,
    onDownloadProgress: o,
    decompress: o,
    maxContentLength: o,
    maxBodyLength: o,
    transport: o,
    httpAgent: o,
    httpsAgent: o,
    cancelToken: o,
    socketPath: o,
    responseEncoding: o,
    validateStatus: h
  };
  return pt.forEach(Object.keys(t).concat(Object.keys(e)), function(u) {
    var d = l[u] || s, f = d(u);
    pt.isUndefined(f) && d !== h || (i[u] = f);
  }), i;
}, qs, $o;
function el() {
  return $o || ($o = 1, qs = {
    version: "0.26.0"
  }), qs;
}
var rf = el().version, ia = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach(function(a, t) {
  ia[a] = function(i) {
    return typeof i === a || "a" + (t < 1 ? "n " : " ") + a;
  };
});
var Vo = {};
ia.transitional = function(t, e, i) {
  function n(s, r) {
    return "[Axios v" + rf + "] Transitional option '" + s + "'" + r + (i ? ". " + i : "");
  }
  return function(s, r, o) {
    if (t === !1)
      throw new Error(n(r, " has been removed" + (e ? " in " + e : "")));
    return e && !Vo[r] && (Vo[r] = !0, console.warn(
      n(
        r,
        " has been deprecated since v" + e + " and will be removed in the near future"
      )
    )), t ? t(s, r, o) : !0;
  };
};
function af(a, t, e) {
  if (typeof a != "object")
    throw new TypeError("options must be an object");
  for (var i = Object.keys(a), n = i.length; n-- > 0; ) {
    var s = i[n], r = t[s];
    if (r) {
      var o = a[s], h = o === void 0 || r(o, s, a);
      if (h !== !0)
        throw new TypeError("option " + s + " must be " + h);
      continue;
    }
    if (e !== !0)
      throw Error("Unknown option " + s);
  }
}
var of = {
  assertOptions: af,
  validators: ia
}, il = ut, hf = Xh, Wo = jd, qo = sf, Wn = tl, nl = of, Ge = nl.validators;
function Bi(a) {
  this.defaults = a, this.interceptors = {
    request: new Wo(),
    response: new Wo()
  };
}
Bi.prototype.request = function(t, e) {
  typeof t == "string" ? (e = e || {}, e.url = t) : e = t || {}, e = Wn(this.defaults, e), e.method ? e.method = e.method.toLowerCase() : this.defaults.method ? e.method = this.defaults.method.toLowerCase() : e.method = "get";
  var i = e.transitional;
  i !== void 0 && nl.assertOptions(i, {
    silentJSONParsing: Ge.transitional(Ge.boolean),
    forcedJSONParsing: Ge.transitional(Ge.boolean),
    clarifyTimeoutError: Ge.transitional(Ge.boolean)
  }, !1);
  var n = [], s = !0;
  this.interceptors.request.forEach(function(f) {
    typeof f.runWhen == "function" && f.runWhen(e) === !1 || (s = s && f.synchronous, n.unshift(f.fulfilled, f.rejected));
  });
  var r = [];
  this.interceptors.response.forEach(function(f) {
    r.push(f.fulfilled, f.rejected);
  });
  var o;
  if (!s) {
    var h = [qo, void 0];
    for (Array.prototype.unshift.apply(h, n), h = h.concat(r), o = Promise.resolve(e); h.length; )
      o = o.then(h.shift(), h.shift());
    return o;
  }
  for (var l = e; n.length; ) {
    var c = n.shift(), u = n.shift();
    try {
      l = c(l);
    } catch (d) {
      u(d);
      break;
    }
  }
  try {
    o = qo(l);
  } catch (d) {
    return Promise.reject(d);
  }
  for (; r.length; )
    o = o.then(r.shift(), r.shift());
  return o;
};
Bi.prototype.getUri = function(t) {
  return t = Wn(this.defaults, t), hf(t.url, t.params, t.paramsSerializer).replace(/^\?/, "");
};
il.forEach(["delete", "get", "head", "options"], function(t) {
  Bi.prototype[t] = function(e, i) {
    return this.request(Wn(i || {}, {
      method: t,
      url: e,
      data: (i || {}).data
    }));
  };
});
il.forEach(["post", "put", "patch"], function(t) {
  Bi.prototype[t] = function(e, i, n) {
    return this.request(Wn(n || {}, {
      method: t,
      url: e,
      data: i
    }));
  };
});
var lf = Bi, Gs, Go;
function cf() {
  if (Go)
    return Gs;
  Go = 1;
  var a = $n();
  function t(e) {
    if (typeof e != "function")
      throw new TypeError("executor must be a function.");
    var i;
    this.promise = new Promise(function(r) {
      i = r;
    });
    var n = this;
    this.promise.then(function(s) {
      if (n._listeners) {
        var r, o = n._listeners.length;
        for (r = 0; r < o; r++)
          n._listeners[r](s);
        n._listeners = null;
      }
    }), this.promise.then = function(s) {
      var r, o = new Promise(function(h) {
        n.subscribe(h), r = h;
      }).then(s);
      return o.cancel = function() {
        n.unsubscribe(r);
      }, o;
    }, e(function(r) {
      n.reason || (n.reason = new a(r), i(n.reason));
    });
  }
  return t.prototype.throwIfRequested = function() {
    if (this.reason)
      throw this.reason;
  }, t.prototype.subscribe = function(i) {
    if (this.reason) {
      i(this.reason);
      return;
    }
    this._listeners ? this._listeners.push(i) : this._listeners = [i];
  }, t.prototype.unsubscribe = function(i) {
    if (this._listeners) {
      var n = this._listeners.indexOf(i);
      n !== -1 && this._listeners.splice(n, 1);
    }
  }, t.source = function() {
    var i, n = new t(function(r) {
      i = r;
    });
    return {
      token: n,
      cancel: i
    };
  }, Gs = t, Gs;
}
var Ks, Ko;
function uf() {
  return Ko || (Ko = 1, Ks = function(t) {
    return function(i) {
      return t.apply(null, i);
    };
  }), Ks;
}
var Ys, Yo;
function df() {
  if (Yo)
    return Ys;
  Yo = 1;
  var a = ut;
  return Ys = function(e) {
    return a.isObject(e) && e.isAxiosError === !0;
  }, Ys;
}
var Xo = ut, ff = qh, On = lf, pf = tl, mf = Vn();
function sl(a) {
  var t = new On(a), e = ff(On.prototype.request, t);
  return Xo.extend(e, On.prototype, t), Xo.extend(e, t), e.create = function(n) {
    return sl(pf(a, n));
  }, e;
}
var Ft = sl(mf);
Ft.Axios = On;
Ft.Cancel = $n();
Ft.CancelToken = cf();
Ft.isCancel = Qh();
Ft.VERSION = el().version;
Ft.all = function(t) {
  return Promise.all(t);
};
Ft.spread = uf();
Ft.isAxiosError = df();
Qr.exports = Ft;
Qr.exports.default = Ft;
var yf = Qr.exports, gf = yf;
const _f = /* @__PURE__ */ Zr(gf);
var vn = { exports: {} }, Yt = {};
Object.defineProperty(Yt, "__esModule", {
  value: !0
});
Yt.default = xf;
function xf(a) {
  return a && a.__esModule ? a : {
    default: a
  };
}
var Xt = {}, qn = {};
Object.defineProperty(qn, "__esModule", {
  value: !0
});
qn.default = wf;
function wf(a) {
  return function() {
    var t = this, e = arguments;
    return new Promise(function(i, n) {
      var s = a.apply(t, e);
      function r(h) {
        Jo(s, i, n, r, o, "next", h);
      }
      function o(h) {
        Jo(s, i, n, r, o, "throw", h);
      }
      r(void 0);
    });
  };
}
function Jo(a, t, e, i, n, s, r) {
  try {
    var o = a[s](r), h = o.value;
  } catch (l) {
    e(l);
    return;
  }
  o.done ? t(h) : Promise.resolve(h).then(i, n);
}
var Re = {};
Object.defineProperty(Re, "__esModule", {
  value: !0
});
Re.default = bf;
function bf() {
  return yr.apply(this, arguments);
}
function yr() {
  return yr = Object.assign || function(a) {
    for (var t = 1; t < arguments.length; t++) {
      var e = arguments[t];
      for (var i in e)
        Object.prototype.hasOwnProperty.call(e, i) && (a[i] = e[i]);
    }
    return a;
  }, yr.apply(this, arguments);
}
var Fi = {};
Object.defineProperty(Fi, "__esModule", {
  value: !0
});
Fi.default = vf;
function vf(a, t) {
  if (!t && a && a.__esModule)
    return a;
  if (a === null || typeof a != "object" && typeof a != "function")
    return {
      default: a
    };
  var e = rl(t);
  if (e && e.has(a))
    return e.get(a);
  var i = {}, n = Object.defineProperty && Object.getOwnPropertyDescriptor;
  for (var s in a)
    if (s !== "default" && Object.prototype.hasOwnProperty.call(a, s)) {
      var r = n ? Object.getOwnPropertyDescriptor(a, s) : null;
      r && (r.get || r.set) ? Object.defineProperty(i, s, r) : i[s] = a[s];
    }
  return i.default = a, e && e.set(a, i), i;
}
function rl(a) {
  if (typeof WeakMap != "function")
    return null;
  var t = /* @__PURE__ */ new WeakMap(), e = /* @__PURE__ */ new WeakMap();
  return (rl = function(i) {
    return i ? e : t;
  })(a);
}
var gr = { exports: {} }, Pe = {};
Object.defineProperty(Pe, "__esModule", {
  value: !0
});
Pe.removeTrailingSlash = Af;
function Af(a) {
  return a.replace(/\/$/, "") || "/";
}
var pe = {};
Object.defineProperty(pe, "__esModule", {
  value: !0
});
pe.parsePath = Mf;
function Mf(a) {
  const t = a.indexOf("#"), e = a.indexOf("?"), i = e > -1 && (t < 0 || e < t);
  return i || t > -1 ? {
    pathname: a.substring(0, i ? e : t),
    query: i ? a.substring(e, t > -1 ? t : void 0) : "",
    hash: t > -1 ? a.slice(t) : ""
  } : {
    pathname: a,
    query: "",
    hash: ""
  };
}
(function(a, t) {
  Object.defineProperty(t, "__esModule", {
    value: !0
  }), t.normalizePathTrailingSlash = void 0;
  var e = Pe, i = pe;
  const n = (s) => {
    if (!s.startsWith("/"))
      return s;
    const { pathname: r, query: o, hash: h } = i.parsePath(s);
    return process.env.__NEXT_TRAILING_SLASH ? /\.[^/]+\/?$/.test(r) ? `${e.removeTrailingSlash(r)}${o}${h}` : r.endsWith("/") ? `${r}${o}${h}` : `${r}/${o}${h}` : `${e.removeTrailingSlash(r)}${o}${h}`;
  };
  t.normalizePathTrailingSlash = n, (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
})(gr, gr.exports);
var na = gr.exports, _r = { exports: {} }, sa = {};
Object.defineProperty(sa, "__esModule", {
  value: !0
});
sa.default = Ef;
function Ef(a, t = "") {
  return (a === "/" ? "/index" : /^\/index(\/|$)/.test(a) ? `/index${a}` : `${a}`) + t;
}
var xr = { exports: {} };
(function(a, t) {
  Object.defineProperty(t, "__esModule", {
    value: !0
  }), t.__unsafeCreateTrustedScriptURL = n;
  let e;
  function i() {
    if (typeof e > "u" && typeof window < "u") {
      var s;
      e = ((s = window.trustedTypes) == null ? void 0 : s.createPolicy("nextjs", {
        createHTML: (r) => r,
        createScript: (r) => r,
        createScriptURL: (r) => r
      })) || null;
    }
    return e;
  }
  function n(s) {
    var r;
    return ((r = i()) == null ? void 0 : r.createScriptURL(s)) || s;
  }
  (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
})(xr, xr.exports);
var Tf = xr.exports, wr = { exports: {} };
(function(a, t) {
  Object.defineProperty(t, "__esModule", {
    value: !0
  }), t.cancelIdleCallback = t.requestIdleCallback = void 0;
  const e = typeof self < "u" && self.requestIdleCallback && self.requestIdleCallback.bind(window) || function(n) {
    let s = Date.now();
    return setTimeout(function() {
      n({
        didTimeout: !1,
        timeRemaining: function() {
          return Math.max(0, 50 - (Date.now() - s));
        }
      });
    }, 1);
  };
  t.requestIdleCallback = e;
  const i = typeof self < "u" && self.cancelIdleCallback && self.cancelIdleCallback.bind(window) || function(n) {
    return clearTimeout(n);
  };
  t.cancelIdleCallback = i, (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
})(wr, wr.exports);
var al = wr.exports;
(function(a, t) {
  Object.defineProperty(t, "__esModule", {
    value: !0
  }), t.markAssetError = d, t.isAssetError = f, t.getClientBuildManifest = _, t.createRouteLoader = A;
  var e = Yt.default, i = e(sa), n = Tf, s = al;
  const r = 3800;
  function o(g, x, v) {
    let M = x.get(g);
    if (M)
      return "future" in M ? M.future : Promise.resolve(M);
    let T;
    const I = new Promise((E) => {
      T = E;
    });
    return x.set(g, M = {
      resolve: T,
      future: I
    }), v ? v().then((E) => (T(E), E)).catch((E) => {
      throw x.delete(g), E;
    }) : I;
  }
  function h(g) {
    try {
      return g = document.createElement("link"), // detect IE11 since it supports prefetch but isn't detected
      // with relList.support
      !!window.MSInputMethodContext && !!document.documentMode || g.relList.supports("prefetch");
    } catch {
      return !1;
    }
  }
  const l = h();
  function c(g, x, v) {
    return new Promise((M, T) => {
      const I = `
      link[rel="prefetch"][href^="${g}"],
      link[rel="preload"][href^="${g}"],
      script[src^="${g}"]`;
      if (document.querySelector(I))
        return M();
      v = document.createElement("link"), x && (v.as = x), v.rel = "prefetch", v.crossOrigin = process.env.__NEXT_CROSS_ORIGIN, v.onload = M, v.onerror = T, v.href = g, document.head.appendChild(v);
    });
  }
  const u = Symbol("ASSET_LOAD_ERROR");
  function d(g) {
    return Object.defineProperty(g, u, {});
  }
  function f(g) {
    return g && u in g;
  }
  function p(g, x) {
    return new Promise((v, M) => {
      x = document.createElement("script"), x.onload = v, x.onerror = () => M(d(new Error(`Failed to load script: ${g}`))), x.crossOrigin = process.env.__NEXT_CROSS_ORIGIN, x.src = g, document.body.appendChild(x);
    });
  }
  let y;
  function m(g, x, v) {
    return new Promise((M, T) => {
      let I = !1;
      g.then((E) => {
        I = !0, M(E);
      }).catch(T), process.env.NODE_ENV === "development" && (y || Promise.resolve()).then(() => {
        s.requestIdleCallback(() => setTimeout(() => {
          I || T(v);
        }, x));
      }), process.env.NODE_ENV !== "development" && s.requestIdleCallback(() => setTimeout(() => {
        I || T(v);
      }, x));
    });
  }
  function _() {
    if (self.__BUILD_MANIFEST)
      return Promise.resolve(self.__BUILD_MANIFEST);
    const g = new Promise((x) => {
      const v = self.__BUILD_MANIFEST_CB;
      self.__BUILD_MANIFEST_CB = () => {
        x(self.__BUILD_MANIFEST), v && v();
      };
    });
    return m(g, r, d(new Error("Failed to load client build manifest")));
  }
  function b(g, x) {
    if (process.env.NODE_ENV === "development") {
      const v = g + "/_next/static/chunks/pages" + encodeURI(i.default(x, ".js"));
      return Promise.resolve({
        scripts: [
          n.__unsafeCreateTrustedScriptURL(v)
        ],
        // Styles are handled by `style-loader` in development:
        css: []
      });
    }
    return _().then((v) => {
      if (!(x in v))
        throw d(new Error(`Failed to lookup route: ${x}`));
      const M = v[x].map((T) => g + "/_next/" + encodeURI(T));
      return {
        scripts: M.filter((T) => T.endsWith(".js")).map((T) => n.__unsafeCreateTrustedScriptURL(T)),
        css: M.filter((T) => T.endsWith(".css"))
      };
    });
  }
  function A(g) {
    const x = /* @__PURE__ */ new Map(), v = /* @__PURE__ */ new Map(), M = /* @__PURE__ */ new Map(), T = /* @__PURE__ */ new Map();
    function I(R) {
      if (process.env.NODE_ENV !== "development") {
        let S = v.get(R.toString());
        return S || (document.querySelector(`script[src^="${R}"]`) ? Promise.resolve() : (v.set(R.toString(), S = p(R)), S));
      } else
        return p(R);
    }
    function E(R) {
      let S = M.get(R);
      return S || (M.set(R, S = fetch(R).then((C) => {
        if (!C.ok)
          throw new Error(`Failed to load stylesheet: ${R}`);
        return C.text().then((O) => ({
          href: R,
          content: O
        }));
      }).catch((C) => {
        throw d(C);
      })), S);
    }
    return {
      whenEntrypoint(R) {
        return o(R, x);
      },
      onEntrypoint(R, S) {
        (S ? Promise.resolve().then(() => S()).then((C) => ({
          component: C && C.default || C,
          exports: C
        }), (C) => ({
          error: C
        })) : Promise.resolve(void 0)).then((C) => {
          const O = x.get(R);
          O && "resolve" in O ? C && (x.set(R, C), O.resolve(C)) : (C ? x.set(R, C) : x.delete(R), T.delete(R));
        });
      },
      loadRoute(R, S) {
        return o(R, T, () => {
          let C;
          return process.env.NODE_ENV === "development" && (y = new Promise((O) => {
            C = O;
          })), m(b(g, R).then(({ scripts: O, css: L }) => Promise.all([
            x.has(R) ? [] : Promise.all(O.map(I)),
            Promise.all(L.map(E))
          ])).then((O) => this.whenEntrypoint(R).then((L) => ({
            entrypoint: L,
            styles: O[1]
          }))), r, d(new Error(`Route did not complete loading: ${R}`))).then(({ entrypoint: O, styles: L }) => {
            const P = Object.assign({
              styles: L
            }, O);
            return "error" in O ? O : P;
          }).catch((O) => {
            if (S)
              throw O;
            return {
              error: O
            };
          }).finally(() => C == null ? void 0 : C());
        });
      },
      prefetch(R) {
        let S;
        return (S = navigator.connection) && (S.saveData || /2g/.test(S.effectiveType)) ? Promise.resolve() : b(g, R).then((C) => Promise.all(l ? C.scripts.map((O) => c(O.toString(), "script")) : [])).then(() => {
          s.requestIdleCallback(() => this.loadRoute(R, !0).catch(() => {
          }));
        }).catch(
          // swallow prefetch errors
          () => {
          }
        );
      }
    };
  }
  (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
})(_r, _r.exports);
var Sf = _r.exports, br = { exports: {} }, ra = {};
Object.defineProperty(ra, "__esModule", {
  value: !0
});
ra.default = Rf;
function Rf(a, t) {
  if (a == null)
    return {};
  var e = {}, i = Object.keys(a), n, s;
  for (s = 0; s < i.length; s++)
    n = i[s], !(t.indexOf(n) >= 0) && (e[n] = a[n]);
  return e;
}
var Gn = {};
Object.defineProperty(Gn, "__esModule", {
  value: !0
});
Gn.HeadManagerContext = void 0;
var Pf = Yt.default, If = Pf(ri);
const ol = If.default.createContext({});
Gn.HeadManagerContext = ol;
process.env.NODE_ENV !== "production" && (ol.displayName = "HeadManagerContext");
var vr = { exports: {} };
(function(a, t) {
  Object.defineProperty(t, "__esModule", {
    value: !0
  }), t.default = e, t.isEqualNode = s, t.DOMAttributeNames = void 0;
  function e() {
    return {
      mountedInstances: /* @__PURE__ */ new Set(),
      updateHead: (o) => {
        const h = {};
        o.forEach((u) => {
          if (
            // If the font tag is loaded only on client navigation
            // it won't be inlined. In this case revert to the original behavior
            u.type === "link" && u.props["data-optimized-fonts"]
          ) {
            if (document.querySelector(`style[data-href="${u.props["data-href"]}"]`))
              return;
            u.props.href = u.props["data-href"], u.props["data-href"] = void 0;
          }
          const d = h[u.type] || [];
          d.push(u), h[u.type] = d;
        });
        const l = h.title ? h.title[0] : null;
        let c = "";
        if (l) {
          const { children: u } = l.props;
          c = typeof u == "string" ? u : Array.isArray(u) ? u.join("") : "";
        }
        c !== document.title && (document.title = c), [
          "meta",
          "base",
          "link",
          "style",
          "script"
        ].forEach((u) => {
          r(u, h[u] || []);
        });
      }
    };
  }
  const i = {
    acceptCharset: "accept-charset",
    className: "class",
    htmlFor: "for",
    httpEquiv: "http-equiv",
    noModule: "noModule"
  };
  t.DOMAttributeNames = i;
  function n({ type: o, props: h }) {
    const l = document.createElement(o);
    for (const d in h) {
      if (!h.hasOwnProperty(d) || d === "children" || d === "dangerouslySetInnerHTML" || h[d] === void 0)
        continue;
      const f = i[d] || d.toLowerCase();
      o === "script" && (f === "async" || f === "defer" || f === "noModule") ? l[f] = !!h[d] : l.setAttribute(f, h[d]);
    }
    const { children: c, dangerouslySetInnerHTML: u } = h;
    return u ? l.innerHTML = u.__html || "" : c && (l.textContent = typeof c == "string" ? c : Array.isArray(c) ? c.join("") : ""), l;
  }
  function s(o, h) {
    if (o instanceof HTMLElement && h instanceof HTMLElement) {
      const l = h.getAttribute("nonce");
      if (l && !o.getAttribute("nonce")) {
        const c = h.cloneNode(!0);
        return c.setAttribute("nonce", ""), c.nonce = l, l === o.nonce && o.isEqualNode(c);
      }
    }
    return o.isEqualNode(h);
  }
  function r(o, h) {
    const l = document.getElementsByTagName("head")[0], c = l.querySelector("meta[name=next-head-count]");
    if (process.env.NODE_ENV !== "production" && !c) {
      console.error("Warning: next-head-count is missing. https://nextjs.org/docs/messages/next-head-count-missing");
      return;
    }
    const u = Number(c.content), d = [];
    for (let y = 0, m = c.previousElementSibling; y < u; y++, m = (m == null ? void 0 : m.previousElementSibling) || null) {
      var f;
      (m == null || (f = m.tagName) == null ? void 0 : f.toLowerCase()) === o && d.push(m);
    }
    const p = h.map(n).filter((y) => {
      for (let m = 0, _ = d.length; m < _; m++) {
        const b = d[m];
        if (s(b, y))
          return d.splice(m, 1), !1;
      }
      return !0;
    });
    d.forEach((y) => {
      var m;
      return (m = y.parentNode) == null ? void 0 : m.removeChild(y);
    }), p.forEach((y) => l.insertBefore(y, c)), c.content = (u - d.length + p.length).toString();
  }
  (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
})(vr, vr.exports);
var Cf = vr.exports;
(function(a, t) {
  "use client";
  Object.defineProperty(t, "__esModule", {
    value: !0
  }), t.handleClientScriptLoad = y, t.initScriptLoader = b, t.default = void 0;
  var e = Re.default, i = Yt.default, n = Fi.default, s = ra.default, r = i(Wl), o = n(ri), h = Gn, l = Cf, c = al;
  const u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Set(), f = [
    "onLoad",
    "onReady",
    "dangerouslySetInnerHTML",
    "children",
    "onError",
    "strategy"
  ], p = (x) => {
    const { src: v, id: M, onLoad: T = () => {
    }, onReady: I = null, dangerouslySetInnerHTML: E, children: R = "", strategy: S = "afterInteractive", onError: C } = x, O = M || v;
    if (O && d.has(O))
      return;
    if (u.has(v)) {
      d.add(O), u.get(v).then(T, C);
      return;
    }
    const L = () => {
      I && I(), d.add(O);
    }, P = document.createElement("script"), $ = new Promise((D, k) => {
      P.addEventListener("load", function(W) {
        D(), T && T.call(this, W), L();
      }), P.addEventListener("error", function(W) {
        k(W);
      });
    }).catch(function(D) {
      C && C(D);
    });
    E ? (P.innerHTML = E.__html || "", L()) : R ? (P.textContent = typeof R == "string" ? R : Array.isArray(R) ? R.join("") : "", L()) : v && (P.src = v, u.set(v, $));
    for (const [D, k] of Object.entries(x)) {
      if (k === void 0 || f.includes(D))
        continue;
      const W = l.DOMAttributeNames[D] || D.toLowerCase();
      P.setAttribute(W, k);
    }
    S === "worker" && P.setAttribute("type", "text/partytown"), P.setAttribute("data-nscript", S), document.body.appendChild(P);
  };
  function y(x) {
    const { strategy: v = "afterInteractive" } = x;
    v === "lazyOnload" ? window.addEventListener("load", () => {
      c.requestIdleCallback(() => p(x));
    }) : p(x);
  }
  function m(x) {
    document.readyState === "complete" ? c.requestIdleCallback(() => p(x)) : window.addEventListener("load", () => {
      c.requestIdleCallback(() => p(x));
    });
  }
  function _() {
    [
      ...document.querySelectorAll('[data-nscript="beforeInteractive"]'),
      ...document.querySelectorAll('[data-nscript="beforePageRender"]')
    ].forEach((v) => {
      const M = v.id || v.getAttribute("src");
      d.add(M);
    });
  }
  function b(x) {
    x.forEach(y), _();
  }
  function A(x) {
    const { id: v, src: M = "", onLoad: T = () => {
    }, onReady: I = null, strategy: E = "afterInteractive", onError: R } = x, S = s(x, [
      "id",
      "src",
      "onLoad",
      "onReady",
      "strategy",
      "onError"
    ]), { updateScripts: C, scripts: O, getIsSsr: L, appDir: P, nonce: $ } = o.useContext(h.HeadManagerContext), D = o.useRef(!1);
    o.useEffect(() => {
      const W = v || M;
      D.current || (I && W && d.has(W) && I(), D.current = !0);
    }, [
      I,
      v,
      M
    ]);
    const k = o.useRef(!1);
    if (o.useEffect(() => {
      k.current || (E === "afterInteractive" ? p(x) : E === "lazyOnload" && m(x), k.current = !0);
    }, [
      x,
      E
    ]), (E === "beforeInteractive" || E === "worker") && (C ? (O[E] = (O[E] || []).concat([
      e({
        id: v,
        src: M,
        onLoad: T,
        onReady: I,
        onError: R
      }, S)
    ]), C(O)) : L && L() ? d.add(v || M) : L && !L() && p(x)), P) {
      if (E === "beforeInteractive")
        return M ? (r.default.preload(M, S.integrity ? {
          as: "script",
          integrity: S.integrity
        } : {
          as: "script"
        }), /* @__PURE__ */ o.default.createElement("script", {
          nonce: $,
          dangerouslySetInnerHTML: {
            __html: `(self.__next_s=self.__next_s||[]).push(${JSON.stringify([
              M
            ])})`
          }
        })) : (S.dangerouslySetInnerHTML && (S.children = S.dangerouslySetInnerHTML.__html, delete S.dangerouslySetInnerHTML), /* @__PURE__ */ o.default.createElement("script", {
          nonce: $,
          dangerouslySetInnerHTML: {
            __html: `(self.__next_s=self.__next_s||[]).push(${JSON.stringify([
              0,
              e({}, S)
            ])})`
          }
        }));
      E === "afterInteractive" && M && r.default.preload(M, S.integrity ? {
        as: "script",
        integrity: S.integrity
      } : {
        as: "script"
      });
    }
    return null;
  }
  Object.defineProperty(A, "__nextScript", {
    value: !0
  });
  var g = A;
  t.default = g, (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
})(br, br.exports);
var Of = br.exports, ki = {}, Kn = {};
Object.defineProperty(Kn, "__esModule", {
  value: !0
});
Kn.getObjectClassLabel = hl;
Kn.isPlainObject = Nf;
function hl(a) {
  return Object.prototype.toString.call(a);
}
function Nf(a) {
  if (hl(a) !== "[object Object]")
    return !1;
  const t = Object.getPrototypeOf(a);
  return t === null || t.hasOwnProperty("isPrototypeOf");
}
Object.defineProperty(ki, "__esModule", {
  value: !0
});
ki.default = ll;
ki.getProperError = Df;
var Lf = Kn;
function ll(a) {
  return typeof a == "object" && a !== null && "name" in a && "message" in a;
}
function Df(a) {
  if (ll(a))
    return a;
  if (process.env.NODE_ENV === "development") {
    if (typeof a > "u")
      return new Error("An undefined error was thrown, see here for more info: https://nextjs.org/docs/messages/threw-undefined");
    if (a === null)
      return new Error("A null error was thrown, see here for more info: https://nextjs.org/docs/messages/threw-undefined");
  }
  return new Error(Lf.isPlainObject(a) ? JSON.stringify(a) : a + "");
}
var aa = {}, cl = {}, oa = {};
Object.defineProperty(oa, "__esModule", {
  value: !0
});
oa.getSortedRoutes = Bf;
class ha {
  insert(t) {
    this._insert(t.split("/").filter(Boolean), [], !1);
  }
  smoosh() {
    return this._smoosh();
  }
  _smoosh(t = "/") {
    const e = [
      ...this.children.keys()
    ].sort();
    this.slugName !== null && e.splice(e.indexOf("[]"), 1), this.restSlugName !== null && e.splice(e.indexOf("[...]"), 1), this.optionalRestSlugName !== null && e.splice(e.indexOf("[[...]]"), 1);
    const i = e.map((n) => this.children.get(n)._smoosh(`${t}${n}/`)).reduce((n, s) => [
      ...n,
      ...s
    ], []);
    if (this.slugName !== null && i.push(...this.children.get("[]")._smoosh(`${t}[${this.slugName}]/`)), !this.placeholder) {
      const n = t === "/" ? "/" : t.slice(0, -1);
      if (this.optionalRestSlugName != null)
        throw new Error(`You cannot define a route with the same specificity as a optional catch-all route ("${n}" and "${n}[[...${this.optionalRestSlugName}]]").`);
      i.unshift(n);
    }
    return this.restSlugName !== null && i.push(...this.children.get("[...]")._smoosh(`${t}[...${this.restSlugName}]/`)), this.optionalRestSlugName !== null && i.push(...this.children.get("[[...]]")._smoosh(`${t}[[...${this.optionalRestSlugName}]]/`)), i;
  }
  _insert(t, e, i) {
    if (t.length === 0) {
      this.placeholder = !1;
      return;
    }
    if (i)
      throw new Error("Catch-all must be the last part of the URL.");
    let n = t[0];
    if (n.startsWith("[") && n.endsWith("]")) {
      let o = function(h, l) {
        if (h !== null && h !== l)
          throw new Error(`You cannot use different slug names for the same dynamic path ('${h}' !== '${l}').`);
        e.forEach((c) => {
          if (c === l)
            throw new Error(`You cannot have the same slug name "${l}" repeat within a single dynamic path`);
          if (c.replace(/\W/g, "") === n.replace(/\W/g, ""))
            throw new Error(`You cannot have the slug names "${c}" and "${l}" differ only by non-word symbols within a single dynamic path`);
        }), e.push(l);
      }, s = n.slice(1, -1), r = !1;
      if (s.startsWith("[") && s.endsWith("]") && (s = s.slice(1, -1), r = !0), s.startsWith("...") && (s = s.substring(3), i = !0), s.startsWith("[") || s.endsWith("]"))
        throw new Error(`Segment names may not start or end with extra brackets ('${s}').`);
      if (s.startsWith("."))
        throw new Error(`Segment names may not start with erroneous periods ('${s}').`);
      if (i)
        if (r) {
          if (this.restSlugName != null)
            throw new Error(`You cannot use both an required and optional catch-all route at the same level ("[...${this.restSlugName}]" and "${t[0]}" ).`);
          o(this.optionalRestSlugName, s), this.optionalRestSlugName = s, n = "[[...]]";
        } else {
          if (this.optionalRestSlugName != null)
            throw new Error(`You cannot use both an optional and required catch-all route at the same level ("[[...${this.optionalRestSlugName}]]" and "${t[0]}").`);
          o(this.restSlugName, s), this.restSlugName = s, n = "[...]";
        }
      else {
        if (r)
          throw new Error(`Optional route parameters are not yet supported ("${t[0]}").`);
        o(this.slugName, s), this.slugName = s, n = "[]";
      }
    }
    this.children.has(n) || this.children.set(n, new ha()), this.children.get(n)._insert(t.slice(1), e, i);
  }
  constructor() {
    this.placeholder = !0, this.children = /* @__PURE__ */ new Map(), this.slugName = null, this.restSlugName = null, this.optionalRestSlugName = null;
  }
}
function Bf(a) {
  const t = new ha();
  return a.forEach((e) => t.insert(e)), t.smoosh();
}
var Yn = {};
Object.defineProperty(Yn, "__esModule", {
  value: !0
});
Yn.isDynamicRoute = kf;
const Ff = /\/\[[^/]+?\](?=\/|$)/;
function kf(a) {
  return Ff.test(a);
}
(function(a) {
  Object.defineProperty(a, "__esModule", {
    value: !0
  }), Object.defineProperty(a, "getSortedRoutes", {
    enumerable: !0,
    get: function() {
      return t.getSortedRoutes;
    }
  }), Object.defineProperty(a, "isDynamicRoute", {
    enumerable: !0,
    get: function() {
      return e.isDynamicRoute;
    }
  });
  var t = oa, e = Yn;
})(cl);
var la = {};
Object.defineProperty(la, "__esModule", {
  value: !0
});
la.normalizePathSep = zf;
function zf(a) {
  return a.replace(/\\/g, "/");
}
Object.defineProperty(aa, "__esModule", {
  value: !0
});
aa.denormalizePagePath = Hf;
var Uf = cl, jf = la;
function Hf(a) {
  let t = jf.normalizePathSep(a);
  return t.startsWith("/index/") && !Uf.isDynamicRoute(t) ? t.slice(6) : t !== "/index" ? t : "/";
}
var zi = {};
Object.defineProperty(zi, "__esModule", {
  value: !0
});
zi.normalizeLocalePath = $f;
function $f(a, t) {
  let e;
  const i = a.split("/");
  return (t || []).some((n) => i[1] && i[1].toLowerCase() === n.toLowerCase() ? (e = n, i.splice(1, 1), a = i.join("/") || "/", !0) : !1), {
    pathname: a,
    detectedLocale: e
  };
}
var ca = {};
Object.defineProperty(ca, "__esModule", {
  value: !0
});
ca.default = Vf;
function Vf() {
  const a = /* @__PURE__ */ Object.create(null);
  return {
    on(t, e) {
      (a[t] || (a[t] = [])).push(e);
    },
    off(t, e) {
      a[t] && a[t].splice(a[t].indexOf(e) >>> 0, 1);
    },
    emit(t, ...e) {
      (a[t] || []).slice().map((i) => {
        i(...e);
      });
    }
  };
}
var V = {};
Object.defineProperty(V, "__esModule", {
  value: !0
});
V.execOnce = Gf;
V.getLocationOrigin = ul;
V.getURL = Xf;
V.getDisplayName = Nn;
V.isResSent = dl;
V.normalizeRepeatedSlashes = Jf;
V.loadGetInitialProps = fl;
V.ST = V.SP = V.warnOnce = V.isAbsoluteUrl = V.WEB_VITALS = void 0;
var Wf = qn.default;
const qf = [
  "CLS",
  "FCP",
  "FID",
  "INP",
  "LCP",
  "TTFB"
];
V.WEB_VITALS = qf;
function Gf(a) {
  let t = !1, e;
  return (...i) => (t || (t = !0, e = a(...i)), e);
}
const Kf = /^[a-zA-Z][a-zA-Z\d+\-.]*?:/, Yf = (a) => Kf.test(a);
V.isAbsoluteUrl = Yf;
function ul() {
  const { protocol: a, hostname: t, port: e } = window.location;
  return `${a}//${t}${e ? ":" + e : ""}`;
}
function Xf() {
  const { href: a } = window.location, t = ul();
  return a.substring(t.length);
}
function Nn(a) {
  return typeof a == "string" ? a : a.displayName || a.name || "Unknown";
}
function dl(a) {
  return a.finished || a.headersSent;
}
function Jf(a) {
  const t = a.split("?");
  return t[0].replace(/\\/g, "/").replace(/\/\/+/g, "/") + (t[1] ? `?${t.slice(1).join("?")}` : "");
}
function fl(a, t) {
  return Ar.apply(this, arguments);
}
function Ar() {
  return Ar = Wf(function* (a, t) {
    if (process.env.NODE_ENV !== "production") {
      var e;
      if ((e = a.prototype) != null && e.getInitialProps) {
        const s = `"${Nn(a)}.getInitialProps()" is defined as an instance method - visit https://nextjs.org/docs/messages/get-initial-props-as-an-instance-method for more information.`;
        throw new Error(s);
      }
    }
    const i = t.res || t.ctx && t.ctx.res;
    if (!a.getInitialProps)
      return t.ctx && t.Component ? {
        pageProps: yield fl(t.Component, t.ctx)
      } : {};
    const n = yield a.getInitialProps(t);
    if (i && dl(i))
      return n;
    if (!n) {
      const s = `"${Nn(a)}.getInitialProps()" should resolve to an object. But found "${n}" instead.`;
      throw new Error(s);
    }
    return process.env.NODE_ENV !== "production" && Object.keys(n).length === 0 && !t.ctx && console.warn(`${Nn(a)} returned an empty object from \`getInitialProps\`. This de-optimizes and prevents automatic static optimization. https://nextjs.org/docs/messages/empty-object-getInitialProps`), n;
  }), Ar.apply(this, arguments);
}
let pl = (a) => {
};
if (process.env.NODE_ENV !== "production") {
  const a = /* @__PURE__ */ new Set();
  V.warnOnce = pl = (t) => {
    a.has(t) || console.warn(t), a.add(t);
  };
}
const ml = typeof performance < "u";
V.SP = ml;
const Zf = ml && [
  "mark",
  "measure",
  "getEntriesByName"
].every((a) => typeof performance[a] == "function");
V.ST = Zf;
class Qf extends Error {
}
V.DecodeError = Qf;
class tp extends Error {
}
V.NormalizeError = tp;
class ep extends Error {
  constructor(t) {
    super(), this.code = "ENOENT", this.message = `Cannot find module for page: ${t}`;
  }
}
V.PageNotFoundError = ep;
class ip extends Error {
  constructor(t, e) {
    super(), this.message = `Failed to load static file for page: ${t} ${e}`;
  }
}
V.MissingStaticPage = ip;
class np extends Error {
  constructor() {
    super(), this.code = "ENOENT", this.message = "Cannot find the middleware module";
  }
}
V.MiddlewareNotFoundError = np;
V.warnOnce = pl;
var Ui = {}, me = {};
Object.defineProperty(me, "__esModule", {
  value: !0
});
me.searchParamsToUrlQuery = sp;
me.urlQueryToSearchParams = rp;
me.assign = ap;
function sp(a) {
  const t = {};
  return a.forEach((e, i) => {
    typeof t[i] > "u" ? t[i] = e : Array.isArray(t[i]) ? t[i].push(e) : t[i] = [
      t[i],
      e
    ];
  }), t;
}
function Zo(a) {
  return typeof a == "string" || typeof a == "number" && !isNaN(a) || typeof a == "boolean" ? String(a) : "";
}
function rp(a) {
  const t = new URLSearchParams();
  return Object.entries(a).forEach(([e, i]) => {
    Array.isArray(i) ? i.forEach((n) => t.append(e, Zo(n))) : t.set(e, Zo(i));
  }), t;
}
function ap(a, ...t) {
  return t.forEach((e) => {
    Array.from(e.keys()).forEach((i) => a.delete(i)), e.forEach((i, n) => a.append(n, i));
  }), a;
}
Object.defineProperty(Ui, "__esModule", {
  value: !0
});
Ui.parseRelativeUrl = lp;
var op = V, hp = me;
function lp(a, t) {
  const e = new URL(typeof window > "u" ? "http://n" : op.getLocationOrigin()), i = t ? new URL(t, e) : a.startsWith(".") ? new URL(typeof window > "u" ? "http://n" : window.location.href) : e, { pathname: n, searchParams: s, search: r, hash: o, href: h, origin: l } = new URL(a, i);
  if (l !== e.origin)
    throw new Error(`invariant: invalid relative URL, router received ${a}`);
  return {
    pathname: n,
    query: hp.searchParamsToUrlQuery(s),
    search: r,
    hash: o,
    href: h.slice(e.origin.length)
  };
}
var ua = {}, da = {}, kt = {};
Object.defineProperty(kt, "__esModule", { value: !0 });
function cp(a) {
  for (var t = [], e = 0; e < a.length; ) {
    var i = a[e];
    if (i === "*" || i === "+" || i === "?") {
      t.push({ type: "MODIFIER", index: e, value: a[e++] });
      continue;
    }
    if (i === "\\") {
      t.push({ type: "ESCAPED_CHAR", index: e++, value: a[e++] });
      continue;
    }
    if (i === "{") {
      t.push({ type: "OPEN", index: e, value: a[e++] });
      continue;
    }
    if (i === "}") {
      t.push({ type: "CLOSE", index: e, value: a[e++] });
      continue;
    }
    if (i === ":") {
      for (var n = "", s = e + 1; s < a.length; ) {
        var r = a.charCodeAt(s);
        if (
          // `0-9`
          r >= 48 && r <= 57 || // `A-Z`
          r >= 65 && r <= 90 || // `a-z`
          r >= 97 && r <= 122 || // `_`
          r === 95
        ) {
          n += a[s++];
          continue;
        }
        break;
      }
      if (!n)
        throw new TypeError("Missing parameter name at " + e);
      t.push({ type: "NAME", index: e, value: n }), e = s;
      continue;
    }
    if (i === "(") {
      var o = 1, h = "", s = e + 1;
      if (a[s] === "?")
        throw new TypeError('Pattern cannot start with "?" at ' + s);
      for (; s < a.length; ) {
        if (a[s] === "\\") {
          h += a[s++] + a[s++];
          continue;
        }
        if (a[s] === ")") {
          if (o--, o === 0) {
            s++;
            break;
          }
        } else if (a[s] === "(" && (o++, a[s + 1] !== "?"))
          throw new TypeError("Capturing groups are not allowed at " + s);
        h += a[s++];
      }
      if (o)
        throw new TypeError("Unbalanced pattern at " + e);
      if (!h)
        throw new TypeError("Missing pattern at " + e);
      t.push({ type: "PATTERN", index: e, value: h }), e = s;
      continue;
    }
    t.push({ type: "CHAR", index: e, value: a[e++] });
  }
  return t.push({ type: "END", index: e, value: "" }), t;
}
function fa(a, t) {
  t === void 0 && (t = {});
  for (var e = cp(a), i = t.prefixes, n = i === void 0 ? "./" : i, s = "[^" + Ke(t.delimiter || "/#?") + "]+?", r = [], o = 0, h = 0, l = "", c = function(v) {
    if (h < e.length && e[h].type === v)
      return e[h++].value;
  }, u = function(v) {
    var M = c(v);
    if (M !== void 0)
      return M;
    var T = e[h], I = T.type, E = T.index;
    throw new TypeError("Unexpected " + I + " at " + E + ", expected " + v);
  }, d = function() {
    for (var v = "", M; M = c("CHAR") || c("ESCAPED_CHAR"); )
      v += M;
    return v;
  }; h < e.length; ) {
    var f = c("CHAR"), p = c("NAME"), y = c("PATTERN");
    if (p || y) {
      var m = f || "";
      n.indexOf(m) === -1 && (l += m, m = ""), l && (r.push(l), l = ""), r.push({
        name: p || o++,
        prefix: m,
        suffix: "",
        pattern: y || s,
        modifier: c("MODIFIER") || ""
      });
      continue;
    }
    var _ = f || c("ESCAPED_CHAR");
    if (_) {
      l += _;
      continue;
    }
    l && (r.push(l), l = "");
    var b = c("OPEN");
    if (b) {
      var m = d(), A = c("NAME") || "", g = c("PATTERN") || "", x = d();
      u("CLOSE"), r.push({
        name: A || (g ? o++ : ""),
        pattern: A && !g ? s : g,
        prefix: m,
        suffix: x,
        modifier: c("MODIFIER") || ""
      });
      continue;
    }
    u("END");
  }
  return r;
}
kt.parse = fa;
function up(a, t) {
  return yl(fa(a, t), t);
}
kt.compile = up;
function yl(a, t) {
  t === void 0 && (t = {});
  var e = pa(t), i = t.encode, n = i === void 0 ? function(h) {
    return h;
  } : i, s = t.validate, r = s === void 0 ? !0 : s, o = a.map(function(h) {
    if (typeof h == "object")
      return new RegExp("^(?:" + h.pattern + ")$", e);
  });
  return function(h) {
    for (var l = "", c = 0; c < a.length; c++) {
      var u = a[c];
      if (typeof u == "string") {
        l += u;
        continue;
      }
      var d = h ? h[u.name] : void 0, f = u.modifier === "?" || u.modifier === "*", p = u.modifier === "*" || u.modifier === "+";
      if (Array.isArray(d)) {
        if (!p)
          throw new TypeError('Expected "' + u.name + '" to not repeat, but got an array');
        if (d.length === 0) {
          if (f)
            continue;
          throw new TypeError('Expected "' + u.name + '" to not be empty');
        }
        for (var y = 0; y < d.length; y++) {
          var m = n(d[y], u);
          if (r && !o[c].test(m))
            throw new TypeError('Expected all "' + u.name + '" to match "' + u.pattern + '", but got "' + m + '"');
          l += u.prefix + m + u.suffix;
        }
        continue;
      }
      if (typeof d == "string" || typeof d == "number") {
        var m = n(String(d), u);
        if (r && !o[c].test(m))
          throw new TypeError('Expected "' + u.name + '" to match "' + u.pattern + '", but got "' + m + '"');
        l += u.prefix + m + u.suffix;
        continue;
      }
      if (!f) {
        var _ = p ? "an array" : "a string";
        throw new TypeError('Expected "' + u.name + '" to be ' + _);
      }
    }
    return l;
  };
}
kt.tokensToFunction = yl;
function dp(a, t) {
  var e = [], i = ma(a, e, t);
  return gl(i, e, t);
}
kt.match = dp;
function gl(a, t, e) {
  e === void 0 && (e = {});
  var i = e.decode, n = i === void 0 ? function(s) {
    return s;
  } : i;
  return function(s) {
    var r = a.exec(s);
    if (!r)
      return !1;
    for (var o = r[0], h = r.index, l = /* @__PURE__ */ Object.create(null), c = function(d) {
      if (r[d] === void 0)
        return "continue";
      var f = t[d - 1];
      f.modifier === "*" || f.modifier === "+" ? l[f.name] = r[d].split(f.prefix + f.suffix).map(function(p) {
        return n(p, f);
      }) : l[f.name] = n(r[d], f);
    }, u = 1; u < r.length; u++)
      c(u);
    return { path: o, index: h, params: l };
  };
}
kt.regexpToFunction = gl;
function Ke(a) {
  return a.replace(/([.+*?=^!:${}()[\]|/\\])/g, "\\$1");
}
function pa(a) {
  return a && a.sensitive ? "" : "i";
}
function fp(a, t) {
  if (!t)
    return a;
  var e = a.source.match(/\((?!\?)/g);
  if (e)
    for (var i = 0; i < e.length; i++)
      t.push({
        name: i,
        prefix: "",
        suffix: "",
        modifier: "",
        pattern: ""
      });
  return a;
}
function pp(a, t, e) {
  var i = a.map(function(n) {
    return ma(n, t, e).source;
  });
  return new RegExp("(?:" + i.join("|") + ")", pa(e));
}
function mp(a, t, e) {
  return _l(fa(a, e), t, e);
}
function _l(a, t, e) {
  e === void 0 && (e = {});
  for (var i = e.strict, n = i === void 0 ? !1 : i, s = e.start, r = s === void 0 ? !0 : s, o = e.end, h = o === void 0 ? !0 : o, l = e.encode, c = l === void 0 ? function(v) {
    return v;
  } : l, u = "[" + Ke(e.endsWith || "") + "]|$", d = "[" + Ke(e.delimiter || "/#?") + "]", f = r ? "^" : "", p = 0, y = a; p < y.length; p++) {
    var m = y[p];
    if (typeof m == "string")
      f += Ke(c(m));
    else {
      var _ = Ke(c(m.prefix)), b = Ke(c(m.suffix));
      if (m.pattern)
        if (t && t.push(m), _ || b)
          if (m.modifier === "+" || m.modifier === "*") {
            var A = m.modifier === "*" ? "?" : "";
            f += "(?:" + _ + "((?:" + m.pattern + ")(?:" + b + _ + "(?:" + m.pattern + "))*)" + b + ")" + A;
          } else
            f += "(?:" + _ + "(" + m.pattern + ")" + b + ")" + m.modifier;
        else
          f += "(" + m.pattern + ")" + m.modifier;
      else
        f += "(?:" + _ + b + ")" + m.modifier;
    }
  }
  if (h)
    n || (f += d + "?"), f += e.endsWith ? "(?=" + u + ")" : "$";
  else {
    var g = a[a.length - 1], x = typeof g == "string" ? d.indexOf(g[g.length - 1]) > -1 : (
      // tslint:disable-next-line
      g === void 0
    );
    n || (f += "(?:" + d + "(?=" + u + "))?"), x || (f += "(?=" + d + "|" + u + ")");
  }
  return new RegExp(f, pa(e));
}
kt.tokensToRegexp = _l;
function ma(a, t, e) {
  return a instanceof RegExp ? fp(a, t) : Array.isArray(a) ? pp(a, t, e) : mp(a, t, e);
}
kt.pathToRegexp = ma;
Object.defineProperty(da, "__esModule", {
  value: !0
});
da.getPathMatch = gp;
var yp = Re.default, Qo = kt;
function gp(a, t) {
  const e = [], i = Qo.pathToRegexp(a, e, {
    delimiter: "/",
    sensitive: !1,
    strict: t == null ? void 0 : t.strict
  }), n = Qo.regexpToFunction(t != null && t.regexModifier ? new RegExp(t.regexModifier(i.source), i.flags) : i, e);
  return (s, r) => {
    const o = s == null ? !1 : n(s);
    if (!o)
      return !1;
    if (t != null && t.removeUnnamedParams)
      for (const h of e)
        typeof h.name == "number" && delete o.params[h.name];
    return yp({}, r, o.params);
  };
}
var ji = {}, Xn = {};
Object.defineProperty(Xn, "__esModule", {
  value: !0
});
Xn.escapeStringRegexp = wp;
const _p = /[|\\{}()[\]^$+*?.-]/, xp = /[|\\{}()[\]^$+*?.-]/g;
function wp(a) {
  return _p.test(a) ? a.replace(xp, "\\$&") : a;
}
var ya = {};
Object.defineProperty(ya, "__esModule", {
  value: !0
});
ya.parseUrl = Ap;
var bp = me, vp = Ui;
function Ap(a) {
  if (a.startsWith("/"))
    return vp.parseRelativeUrl(a);
  const t = new URL(a);
  return {
    hash: t.hash,
    hostname: t.hostname,
    href: t.href,
    pathname: t.pathname,
    port: t.port,
    protocol: t.protocol,
    query: bp.searchParamsToUrlQuery(t.searchParams),
    search: t.search
  };
}
Object.defineProperty(ji, "__esModule", {
  value: !0
});
ji.matchHas = Rp;
ji.compileNonPath = Mr;
ji.prepareDestination = Pp;
var th = Re.default, Ai = kt, Mp = Xn, Ep = ya;
function Tp(a) {
  let t = "";
  for (let e = 0; e < a.length; e++) {
    const i = a.charCodeAt(e);
    (i > 64 && i < 91 || i > 96 && i < 123) && (t += a[e]);
  }
  return t;
}
function Sp(a, t) {
  return a.replace(new RegExp(`:${Mp.escapeStringRegexp(t)}`, "g"), `__ESC_COLON_${t}`);
}
function An(a) {
  return a.replace(/__ESC_COLON_/gi, ":");
}
function Rp(a, t, e) {
  const i = {};
  return t.every((s) => {
    let r, o = s.key;
    switch (s.type) {
      case "header": {
        o = o.toLowerCase(), r = a.headers[o];
        break;
      }
      case "cookie": {
        r = a.cookies[s.key];
        break;
      }
      case "query": {
        r = e[o];
        break;
      }
      case "host": {
        const { host: h } = (a == null ? void 0 : a.headers) || {};
        r = h == null ? void 0 : h.split(":")[0].toLowerCase();
        break;
      }
    }
    if (!s.value && r)
      return i[Tp(o)] = r, !0;
    if (r) {
      const h = new RegExp(`^${s.value}$`), l = Array.isArray(r) ? r.slice(-1)[0].match(h) : r.match(h);
      if (l)
        return Array.isArray(l) && (l.groups ? Object.keys(l.groups).forEach((c) => {
          i[c] = l.groups[c];
        }) : s.type === "host" && l[0] && (i.host = l[0])), !0;
    }
    return !1;
  }) ? i : !1;
}
function Mr(a, t) {
  if (!a.includes(":"))
    return a;
  for (const e of Object.keys(t))
    a.includes(`:${e}`) && (a = a.replace(new RegExp(`:${e}\\*`, "g"), `:${e}--ESCAPED_PARAM_ASTERISKS`).replace(new RegExp(`:${e}\\?`, "g"), `:${e}--ESCAPED_PARAM_QUESTION`).replace(new RegExp(`:${e}\\+`, "g"), `:${e}--ESCAPED_PARAM_PLUS`).replace(new RegExp(`:${e}(?!\\w)`, "g"), `--ESCAPED_PARAM_COLON${e}`));
  return a = a.replace(/(:|\*|\?|\+|\(|\)|\{|\})/g, "\\$1").replace(/--ESCAPED_PARAM_PLUS/g, "+").replace(/--ESCAPED_PARAM_COLON/g, ":").replace(/--ESCAPED_PARAM_QUESTION/g, "?").replace(/--ESCAPED_PARAM_ASTERISKS/g, "*"), Ai.compile(`/${a}`, {
    validate: !1
  })(t).slice(1);
}
function Pp(a) {
  const t = Object.assign({}, a.query);
  delete t.__nextLocale, delete t.__nextDefaultLocale, delete t.__nextDataReq;
  let e = a.destination;
  for (const p of Object.keys(th({}, a.params, t)))
    e = Sp(e, p);
  const i = Ep.parseUrl(e), n = i.query, s = An(`${i.pathname}${i.hash || ""}`), r = An(i.hostname || ""), o = [], h = [];
  Ai.pathToRegexp(s, o), Ai.pathToRegexp(r, h);
  const l = [];
  o.forEach((p) => l.push(p.name)), h.forEach((p) => l.push(p.name));
  const c = Ai.compile(
    s,
    // we don't validate while compiling the destination since we should
    // have already validated before we got to this point and validating
    // breaks compiling destinations with named pattern params from the source
    // e.g. /something:hello(.*) -> /another/:hello is broken with validation
    // since compile validation is meant for reversing and not for inserting
    // params from a separate path-regex into another
    {
      validate: !1
    }
  ), u = Ai.compile(r, {
    validate: !1
  });
  for (const [p, y] of Object.entries(n))
    Array.isArray(y) ? n[p] = y.map((m) => Mr(An(m), a.params)) : typeof y == "string" && (n[p] = Mr(An(y), a.params));
  let d = Object.keys(a.params).filter((p) => p !== "nextInternalLocale");
  if (a.appendParamsToQuery && !d.some((p) => l.includes(p)))
    for (const p of d)
      p in n || (n[p] = a.params[p]);
  let f;
  try {
    f = c(a.params);
    const [p, y] = f.split("#");
    i.hostname = u(a.params), i.pathname = p, i.hash = `${y ? "#" : ""}${y || ""}`, delete i.search;
  } catch (p) {
    throw p.message.match(/Expected .*? to not repeat, but got an array/) ? new Error("To use a multi-match in the destination you must add `*` at the end of the param name to signify it should repeat. https://nextjs.org/docs/messages/invalid-multi-match") : p;
  }
  return i.query = th({}, t, i.query), {
    newUrl: f,
    destQuery: n,
    parsedDestination: i
  };
}
var Er = { exports: {} }, Tr = { exports: {} }, li = {};
Object.defineProperty(li, "__esModule", {
  value: !0
});
li.pathHasPrefix = Cp;
var Ip = pe;
function Cp(a, t) {
  if (typeof a != "string")
    return !1;
  const { pathname: e } = Ip.parsePath(a);
  return e === t || e.startsWith(t + "/");
}
(function(a, t) {
  Object.defineProperty(t, "__esModule", {
    value: !0
  }), t.hasBasePath = n;
  var e = li;
  const i = process.env.__NEXT_ROUTER_BASEPATH || "";
  function n(s) {
    return e.pathHasPrefix(s, i);
  }
  (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
})(Tr, Tr.exports);
var xl = Tr.exports;
(function(a, t) {
  Object.defineProperty(t, "__esModule", {
    value: !0
  }), t.removeBasePath = n;
  var e = xl;
  const i = process.env.__NEXT_ROUTER_BASEPATH || "";
  function n(s) {
    return process.env.__NEXT_MANUAL_CLIENT_BASE_PATH && !e.hasBasePath(s) || (s = s.slice(i.length), s.startsWith("/") || (s = `/${s}`)), s;
  }
  (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
})(Er, Er.exports);
var wl = Er.exports;
Object.defineProperty(ua, "__esModule", {
  value: !0
});
ua.default = Lp;
var Op = da, eh = ji, ih = Pe, nh = zi, sh = wl, Np = Ui;
function Lp(a, t, e, i, n, s) {
  let r = !1, o = !1, h = Np.parseRelativeUrl(a), l = ih.removeTrailingSlash(nh.normalizeLocalePath(sh.removeBasePath(h.pathname), s).pathname), c;
  const u = (f) => {
    let y = Op.getPathMatch(f.source + (process.env.__NEXT_TRAILING_SLASH ? "(/)?" : ""), {
      removeUnnamedParams: !0,
      strict: !0
    })(h.pathname);
    if (f.has && y) {
      const m = eh.matchHas({
        headers: {
          host: document.location.hostname
        },
        cookies: document.cookie.split("; ").reduce((_, b) => {
          const [A, ...g] = b.split("=");
          return _[A] = g.join("="), _;
        }, {})
      }, f.has, h.query);
      m ? Object.assign(y, m) : y = !1;
    }
    if (y) {
      if (!f.destination)
        return o = !0, !0;
      const m = eh.prepareDestination({
        appendParamsToQuery: !0,
        destination: f.destination,
        params: y,
        query: i
      });
      if (h = m.parsedDestination, a = m.newUrl, Object.assign(i, m.parsedDestination.query), l = ih.removeTrailingSlash(nh.normalizeLocalePath(sh.removeBasePath(a), s).pathname), t.includes(l))
        return r = !0, c = l, !0;
      if (c = n(l), c !== a && t.includes(c))
        return r = !0, !0;
    }
  };
  let d = !1;
  for (let f = 0; f < e.beforeFiles.length; f++)
    u(e.beforeFiles[f]);
  if (r = t.includes(l), !r) {
    if (!d) {
      for (let f = 0; f < e.afterFiles.length; f++)
        if (u(e.afterFiles[f])) {
          d = !0;
          break;
        }
    }
    if (d || (c = n(l), r = t.includes(c), d = r), !d) {
      for (let f = 0; f < e.fallback.length; f++)
        if (u(e.fallback[f])) {
          d = !0;
          break;
        }
    }
  }
  return {
    asPath: a,
    parsedAs: h,
    matchedPage: r,
    resolvedHref: c,
    externalDest: o
  };
}
var ga = {};
Object.defineProperty(ga, "__esModule", {
  value: !0
});
ga.getRouteMatcher = Bp;
var Dp = V;
function Bp({ re: a, groups: t }) {
  return (e) => {
    const i = a.exec(e);
    if (!i)
      return !1;
    const n = (r) => {
      try {
        return decodeURIComponent(r);
      } catch {
        throw new Dp.DecodeError("failed to decode param");
      }
    }, s = {};
    return Object.keys(t).forEach((r) => {
      const o = t[r], h = i[o.pos];
      h !== void 0 && (s[r] = ~h.indexOf("/") ? h.split("/").map((l) => n(l)) : o.repeat ? [
        n(h)
      ] : n(h));
    }), s;
  };
}
var Hi = {};
Object.defineProperty(Hi, "__esModule", {
  value: !0
});
Hi.getRouteRegex = El;
Hi.getNamedRouteRegex = zp;
Hi.getNamedMiddlewareRegex = Up;
var Fp = Re.default, bl = Xn, vl = Pe;
function Al(a) {
  const t = a.startsWith("[") && a.endsWith("]");
  t && (a = a.slice(1, -1));
  const e = a.startsWith("...");
  return e && (a = a.slice(3)), {
    key: a,
    repeat: e,
    optional: t
  };
}
function Ml(a) {
  const t = vl.removeTrailingSlash(a).slice(1).split("/"), e = {};
  let i = 1;
  return {
    parameterizedRoute: t.map((n) => {
      if (n.startsWith("[") && n.endsWith("]")) {
        const { key: s, optional: r, repeat: o } = Al(n.slice(1, -1));
        return e[s] = {
          pos: i++,
          repeat: o,
          optional: r
        }, o ? r ? "(?:/(.+?))?" : "/(.+?)" : "/([^/]+?)";
      } else
        return `/${bl.escapeStringRegexp(n)}`;
    }).join(""),
    groups: e
  };
}
function El(a) {
  const { parameterizedRoute: t, groups: e } = Ml(a);
  return {
    re: new RegExp(`^${t}(?:/)?$`),
    groups: e
  };
}
function kp() {
  let a = 97, t = 1;
  return () => {
    let e = "";
    for (let i = 0; i < t; i++)
      e += String.fromCharCode(a), a++, a > 122 && (t++, a = 97);
    return e;
  };
}
function Tl(a) {
  const t = vl.removeTrailingSlash(a).slice(1).split("/"), e = kp(), i = {};
  return {
    namedParameterizedRoute: t.map((n) => {
      if (n.startsWith("[") && n.endsWith("]")) {
        const { key: s, optional: r, repeat: o } = Al(n.slice(1, -1));
        let h = s.replace(/\W/g, ""), l = !1;
        return (h.length === 0 || h.length > 30) && (l = !0), isNaN(parseInt(h.slice(0, 1))) || (l = !0), l && (h = e()), i[h] = s, o ? r ? `(?:/(?<${h}>.+?))?` : `/(?<${h}>.+?)` : `/(?<${h}>[^/]+?)`;
      } else
        return `/${bl.escapeStringRegexp(n)}`;
    }).join(""),
    routeKeys: i
  };
}
function zp(a) {
  const t = Tl(a);
  return Fp({}, El(a), {
    namedRegex: `^${t.namedParameterizedRoute}(?:/)?$`,
    routeKeys: t.routeKeys
  });
}
function Up(a, t) {
  const { parameterizedRoute: e } = Ml(a), { catchAll: i = !0 } = t;
  if (e === "/")
    return {
      namedRegex: `^/${i ? ".*" : ""}$`
    };
  const { namedParameterizedRoute: n } = Tl(a);
  return {
    namedRegex: `^${n}${i ? "(?:(/.*)?)" : ""}$`
  };
}
var ci = {};
Object.defineProperty(ci, "__esModule", {
  value: !0
});
ci.formatUrl = Sl;
ci.formatWithValidation = Vp;
ci.urlObjectKeys = void 0;
var jp = Fi.default, Hp = jp(me);
const $p = /https?|ftp|gopher|file/;
function Sl(a) {
  let { auth: t, hostname: e } = a, i = a.protocol || "", n = a.pathname || "", s = a.hash || "", r = a.query || "", o = !1;
  t = t ? encodeURIComponent(t).replace(/%3A/i, ":") + "@" : "", a.host ? o = t + a.host : e && (o = t + (~e.indexOf(":") ? `[${e}]` : e), a.port && (o += ":" + a.port)), r && typeof r == "object" && (r = String(Hp.urlQueryToSearchParams(r)));
  let h = a.search || r && `?${r}` || "";
  return i && !i.endsWith(":") && (i += ":"), a.slashes || (!i || $p.test(i)) && o !== !1 ? (o = "//" + (o || ""), n && n[0] !== "/" && (n = "/" + n)) : o || (o = ""), s && s[0] !== "#" && (s = "#" + s), h && h[0] !== "?" && (h = "?" + h), n = n.replace(/[?#]/g, encodeURIComponent), h = h.replace("#", "%23"), `${i}${o}${n}${h}${s}`;
}
const Rl = [
  "auth",
  "hash",
  "host",
  "hostname",
  "href",
  "path",
  "pathname",
  "port",
  "protocol",
  "query",
  "search",
  "slashes"
];
ci.urlObjectKeys = Rl;
function Vp(a) {
  return process.env.NODE_ENV === "development" && a !== null && typeof a == "object" && Object.keys(a).forEach((t) => {
    Rl.indexOf(t) === -1 && console.warn(`Unknown key passed via urlObject into url.format: ${t}`);
  }), Sl(a);
}
var Sr = { exports: {} }, Mn = {}, rh;
function Wp() {
  if (rh)
    return Mn;
  rh = 1, Object.defineProperty(Mn, "__esModule", {
    value: !0
  }), Mn.detectDomainLocale = a;
  function a(t, e, i) {
    let n;
    if (t) {
      i && (i = i.toLowerCase());
      for (const o of t) {
        var s, r;
        const h = (s = o.domain) == null ? void 0 : s.split(":")[0].toLowerCase();
        if (e === h || i === o.defaultLocale.toLowerCase() || (r = o.locales) != null && r.some((l) => l.toLowerCase() === i)) {
          n = o;
          break;
        }
      }
    }
    return n;
  }
  return Mn;
}
(function(a, t) {
  Object.defineProperty(t, "__esModule", {
    value: !0
  }), t.detectDomainLocale = void 0;
  const e = (...i) => {
    if (process.env.__NEXT_I18N_SUPPORT)
      return Wp().detectDomainLocale(...i);
  };
  t.detectDomainLocale = e, (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
})(Sr, Sr.exports);
var qp = Sr.exports, Rr = { exports: {} }, Jn = {}, $i = {};
Object.defineProperty($i, "__esModule", {
  value: !0
});
$i.addPathPrefix = Kp;
var Gp = pe;
function Kp(a, t) {
  if (!a.startsWith("/") || !t)
    return a;
  const { pathname: e, query: i, hash: n } = Gp.parsePath(a);
  return `${t}${e}${i}${n}`;
}
Object.defineProperty(Jn, "__esModule", {
  value: !0
});
Jn.addLocale = Xp;
var Yp = $i, ah = li;
function Xp(a, t, e, i) {
  return t && t !== e && (i || !ah.pathHasPrefix(a.toLowerCase(), `/${t.toLowerCase()}`) && !ah.pathHasPrefix(a.toLowerCase(), "/api")) ? Yp.addPathPrefix(a, `/${t}`) : a;
}
(function(a, t) {
  Object.defineProperty(t, "__esModule", {
    value: !0
  }), t.addLocale = void 0;
  var e = na;
  const i = (n, ...s) => process.env.__NEXT_I18N_SUPPORT ? e.normalizePathTrailingSlash(Jn.addLocale(n, ...s)) : n;
  t.addLocale = i, (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
})(Rr, Rr.exports);
var Jp = Rr.exports, Pr = { exports: {} };
(function(a, t) {
  Object.defineProperty(t, "__esModule", {
    value: !0
  }), t.removeLocale = i;
  var e = pe;
  function i(n, s) {
    if (process.env.__NEXT_I18N_SUPPORT) {
      const { pathname: r } = e.parsePath(n), o = r.toLowerCase(), h = s == null ? void 0 : s.toLowerCase();
      return s && (o.startsWith(`/${h}/`) || o === `/${h}`) ? `${r.length === s.length + 1 ? "/" : ""}${n.slice(s.length + 1)}` : n;
    }
    return n;
  }
  (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
})(Pr, Pr.exports);
var Zp = Pr.exports, Ir = { exports: {} };
(function(a, t) {
  Object.defineProperty(t, "__esModule", {
    value: !0
  }), t.addBasePath = s;
  var e = $i, i = na;
  const n = process.env.__NEXT_ROUTER_BASEPATH || "";
  function s(r, o) {
    return process.env.__NEXT_MANUAL_CLIENT_BASE_PATH && !o ? r : i.normalizePathTrailingSlash(e.addPathPrefix(r, n));
  }
  (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
})(Ir, Ir.exports);
var Qp = Ir.exports, _a = {}, xa = {};
Object.defineProperty(xa, "__esModule", {
  value: !0
});
xa.removePathPrefix = em;
var tm = li;
function em(a, t) {
  if (tm.pathHasPrefix(a, t)) {
    const e = a.slice(t.length);
    return e.startsWith("/") ? e : `/${e}`;
  }
  return a;
}
Object.defineProperty(_a, "__esModule", {
  value: !0
});
_a.getNextPathnameInfo = rm;
var im = zi, nm = xa, sm = li;
function rm(a, t) {
  var e;
  const { basePath: i, i18n: n, trailingSlash: s } = (e = t.nextConfig) != null ? e : {}, r = {
    pathname: a,
    trailingSlash: a !== "/" ? a.endsWith("/") : s
  };
  if (i && sm.pathHasPrefix(r.pathname, i) && (r.pathname = nm.removePathPrefix(r.pathname, i), r.basePath = i), t.parseData === !0 && r.pathname.startsWith("/_next/data/") && r.pathname.endsWith(".json")) {
    const o = r.pathname.replace(/^\/_next\/data\//, "").replace(/\.json$/, "").split("/"), h = o[0];
    r.pathname = o[1] !== "index" ? `/${o.slice(1).join("/")}` : "/", r.buildId = h;
  }
  if (n) {
    const o = im.normalizeLocalePath(r.pathname, n.locales);
    r.locale = o == null ? void 0 : o.detectedLocale, r.pathname = (o == null ? void 0 : o.pathname) || r.pathname;
  }
  return r;
}
var wa = {}, ba = {};
Object.defineProperty(ba, "__esModule", {
  value: !0
});
ba.addPathSuffix = om;
var am = pe;
function om(a, t) {
  if (!a.startsWith("/") || !t)
    return a;
  const { pathname: e, query: i, hash: n } = am.parsePath(a);
  return `${e}${t}${i}${n}`;
}
Object.defineProperty(wa, "__esModule", {
  value: !0
});
wa.formatNextPathnameInfo = lm;
var oh = Pe, hh = $i, lh = ba, hm = Jn;
function lm(a) {
  let t = hm.addLocale(a.pathname, a.locale, a.buildId ? void 0 : a.defaultLocale, a.ignorePrefix);
  return (a.buildId || !a.trailingSlash) && (t = oh.removeTrailingSlash(t)), a.buildId && (t = lh.addPathSuffix(hh.addPathPrefix(t, `/_next/data/${a.buildId}`), a.pathname === "/" ? "index.json" : ".json")), t = hh.addPathPrefix(t, a.basePath), !a.buildId && a.trailingSlash ? t.endsWith("/") ? t : lh.addPathSuffix(t, "/") : oh.removeTrailingSlash(t);
}
var va = {};
Object.defineProperty(va, "__esModule", {
  value: !0
});
va.compareRouterStates = cm;
function cm(a, t) {
  const e = Object.keys(a);
  if (e.length !== Object.keys(t).length)
    return !1;
  for (let i = e.length; i--; ) {
    const n = e[i];
    if (n === "query") {
      const s = Object.keys(a.query);
      if (s.length !== Object.keys(t.query).length)
        return !1;
      for (let r = s.length; r--; ) {
        const o = s[r];
        if (!t.query.hasOwnProperty(o) || a.query[o] !== t.query[o])
          return !1;
      }
    } else if (!t.hasOwnProperty(n) || a[n] !== t[n])
      return !1;
  }
  return !0;
}
var Aa = {};
Object.defineProperty(Aa, "__esModule", {
  value: !0
});
Aa.isBot = um;
function um(a) {
  return /Googlebot|Mediapartners-Google|AdsBot-Google|googleweblight|Storebot-Google|Google-PageRenderer|Bingbot|BingPreview|Slurp|DuckDuckBot|baiduspider|yandex|sogou|LinkedInBot|bitlybot|tumblr|vkShare|quora link preview|facebookexternalhit|facebookcatalog|Twitterbot|applebot|redditbot|Slackbot|Discordbot|WhatsApp|SkypeUriPreview|ia_archiver/i.test(a);
}
var En = { exports: {} }, z = {};
/**
 * @license React
 * react-is.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var ch;
function dm() {
  if (ch)
    return z;
  ch = 1;
  var a = Symbol.for("react.element"), t = Symbol.for("react.portal"), e = Symbol.for("react.fragment"), i = Symbol.for("react.strict_mode"), n = Symbol.for("react.profiler"), s = Symbol.for("react.provider"), r = Symbol.for("react.context"), o = Symbol.for("react.server_context"), h = Symbol.for("react.forward_ref"), l = Symbol.for("react.suspense"), c = Symbol.for("react.suspense_list"), u = Symbol.for("react.memo"), d = Symbol.for("react.lazy"), f = Symbol.for("react.offscreen"), p;
  p = Symbol.for("react.module.reference");
  function y(m) {
    if (typeof m == "object" && m !== null) {
      var _ = m.$$typeof;
      switch (_) {
        case a:
          switch (m = m.type, m) {
            case e:
            case n:
            case i:
            case l:
            case c:
              return m;
            default:
              switch (m = m && m.$$typeof, m) {
                case o:
                case r:
                case h:
                case d:
                case u:
                case s:
                  return m;
                default:
                  return _;
              }
          }
        case t:
          return _;
      }
    }
  }
  return z.ContextConsumer = r, z.ContextProvider = s, z.Element = a, z.ForwardRef = h, z.Fragment = e, z.Lazy = d, z.Memo = u, z.Portal = t, z.Profiler = n, z.StrictMode = i, z.Suspense = l, z.SuspenseList = c, z.isAsyncMode = function() {
    return !1;
  }, z.isConcurrentMode = function() {
    return !1;
  }, z.isContextConsumer = function(m) {
    return y(m) === r;
  }, z.isContextProvider = function(m) {
    return y(m) === s;
  }, z.isElement = function(m) {
    return typeof m == "object" && m !== null && m.$$typeof === a;
  }, z.isForwardRef = function(m) {
    return y(m) === h;
  }, z.isFragment = function(m) {
    return y(m) === e;
  }, z.isLazy = function(m) {
    return y(m) === d;
  }, z.isMemo = function(m) {
    return y(m) === u;
  }, z.isPortal = function(m) {
    return y(m) === t;
  }, z.isProfiler = function(m) {
    return y(m) === n;
  }, z.isStrictMode = function(m) {
    return y(m) === i;
  }, z.isSuspense = function(m) {
    return y(m) === l;
  }, z.isSuspenseList = function(m) {
    return y(m) === c;
  }, z.isValidElementType = function(m) {
    return typeof m == "string" || typeof m == "function" || m === e || m === n || m === i || m === l || m === c || m === f || typeof m == "object" && m !== null && (m.$$typeof === d || m.$$typeof === u || m.$$typeof === s || m.$$typeof === r || m.$$typeof === h || m.$$typeof === p || m.getModuleId !== void 0);
  }, z.typeOf = y, z;
}
var U = {};
/**
 * @license React
 * react-is.development.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var uh;
function fm() {
  return uh || (uh = 1, process.env.NODE_ENV !== "production" && function() {
    var a = Symbol.for("react.element"), t = Symbol.for("react.portal"), e = Symbol.for("react.fragment"), i = Symbol.for("react.strict_mode"), n = Symbol.for("react.profiler"), s = Symbol.for("react.provider"), r = Symbol.for("react.context"), o = Symbol.for("react.server_context"), h = Symbol.for("react.forward_ref"), l = Symbol.for("react.suspense"), c = Symbol.for("react.suspense_list"), u = Symbol.for("react.memo"), d = Symbol.for("react.lazy"), f = Symbol.for("react.offscreen"), p = !1, y = !1, m = !1, _ = !1, b = !1, A;
    A = Symbol.for("react.module.reference");
    function g(N) {
      return !!(typeof N == "string" || typeof N == "function" || N === e || N === n || b || N === i || N === l || N === c || _ || N === f || p || y || m || typeof N == "object" && N !== null && (N.$$typeof === d || N.$$typeof === u || N.$$typeof === s || N.$$typeof === r || N.$$typeof === h || // This needs to include all possible module reference object
      // types supported by any Flight configuration anywhere since
      // we don't know which Flight build this will end up being used
      // with.
      N.$$typeof === A || N.getModuleId !== void 0));
    }
    function x(N) {
      if (typeof N == "object" && N !== null) {
        var ts = N.$$typeof;
        switch (ts) {
          case a:
            var Yi = N.type;
            switch (Yi) {
              case e:
              case n:
              case i:
              case l:
              case c:
                return Yi;
              default:
                var Pa = Yi && Yi.$$typeof;
                switch (Pa) {
                  case o:
                  case r:
                  case h:
                  case d:
                  case u:
                  case s:
                    return Pa;
                  default:
                    return ts;
                }
            }
          case t:
            return ts;
        }
      }
    }
    var v = r, M = s, T = a, I = h, E = e, R = d, S = u, C = t, O = n, L = i, P = l, $ = c, D = !1, k = !1;
    function W(N) {
      return D || (D = !0, console.warn("The ReactIs.isAsyncMode() alias has been deprecated, and will be removed in React 18+.")), !1;
    }
    function ht(N) {
      return k || (k = !0, console.warn("The ReactIs.isConcurrentMode() alias has been deprecated, and will be removed in React 18+.")), !1;
    }
    function ui(N) {
      return x(N) === r;
    }
    function Vi(N) {
      return x(N) === s;
    }
    function Qn(N) {
      return typeof N == "object" && N !== null && N.$$typeof === a;
    }
    function Wi(N) {
      return x(N) === h;
    }
    function qi(N) {
      return x(N) === e;
    }
    function Ra(N) {
      return x(N) === d;
    }
    function tt(N) {
      return x(N) === u;
    }
    function et(N) {
      return x(N) === t;
    }
    function Pt(N) {
      return x(N) === n;
    }
    function di(N) {
      return x(N) === i;
    }
    function Gi(N) {
      return x(N) === l;
    }
    function Ki(N) {
      return x(N) === c;
    }
    U.ContextConsumer = v, U.ContextProvider = M, U.Element = T, U.ForwardRef = I, U.Fragment = E, U.Lazy = R, U.Memo = S, U.Portal = C, U.Profiler = O, U.StrictMode = L, U.Suspense = P, U.SuspenseList = $, U.isAsyncMode = W, U.isConcurrentMode = ht, U.isContextConsumer = ui, U.isContextProvider = Vi, U.isElement = Qn, U.isForwardRef = Wi, U.isFragment = qi, U.isLazy = Ra, U.isMemo = tt, U.isPortal = et, U.isProfiler = Pt, U.isStrictMode = di, U.isSuspense = Gi, U.isSuspenseList = Ki, U.isValidElementType = g, U.typeOf = x;
  }()), U;
}
var dh;
function pm() {
  return dh || (dh = 1, process.env.NODE_ENV === "production" ? En.exports = dm() : En.exports = fm()), En.exports;
}
Object.defineProperty(Xt, "__esModule", {
  value: !0
});
Xt.matchesMiddleware = kn;
Xt.isLocalURL = zn;
Xt.interpolateAs = Ma;
Xt.resolveHref = Nr;
Xt.createKey = Lr;
Xt.default = void 0;
var be = qn.default, ve = Re.default, Pl = Yt.default, mm = Fi.default, ym = na, oe = Pe, Ti = Sf, gm = Of, Tn = mm(ki), _m = aa, re = zi, xm = Pl(ca), Ot = V, ue = Yn, qt = Ui, wm = me, Cr = Pl(ua), Si = ga, Qe = Hi, ot = ci, fh = qp, ti = pe, he = Jp, Xs = Zp, ct = wl, X = Qp, ae = xl, Sn = _a, ph = wa, bm = va, vm = Aa;
function mh() {
  return Object.assign(new Error("Route Cancelled"), {
    cancelled: !0
  });
}
function kn(a) {
  return Or.apply(this, arguments);
}
function Or() {
  return Or = be(function* (a) {
    const t = yield Promise.resolve(a.router.pageLoader.getMiddleware());
    if (!t)
      return !1;
    const { pathname: e } = ti.parsePath(a.asPath), i = ae.hasBasePath(e) ? ct.removeBasePath(e) : e, n = X.addBasePath(he.addLocale(i, a.locale));
    return t.some((s) => new RegExp(s.regexp).test(n));
  }), Or.apply(this, arguments);
}
function Js(a) {
  const t = Ot.getLocationOrigin();
  return a.startsWith(t) ? a.substring(t.length) : a;
}
function Il(a, t) {
  const e = {};
  return Object.keys(a).forEach((i) => {
    t.includes(i) || (e[i] = a[i]);
  }), e;
}
function zn(a) {
  if (!Ot.isAbsoluteUrl(a))
    return !0;
  try {
    const t = Ot.getLocationOrigin(), e = new URL(a, t);
    return e.origin === t && ae.hasBasePath(e.pathname);
  } catch {
    return !1;
  }
}
function Ma(a, t, e) {
  let i = "";
  const n = Qe.getRouteRegex(a), s = n.groups, r = (
    // Try to match the dynamic route against the asPath
    (t !== a ? Si.getRouteMatcher(n)(t) : "") || // Fall back to reading the values from the href
    // TODO: should this take priority; also need to change in the router.
    e
  );
  i = a;
  const o = Object.keys(s);
  return o.every((h) => {
    let l = r[h] || "";
    const { repeat: c, optional: u } = s[h];
    let d = `[${c ? "..." : ""}${h}]`;
    return u && (d = `${l ? "" : "/"}[${d}]`), c && !Array.isArray(l) && (l = [
      l
    ]), (u || h in r) && // Interpolate group into data URL if present
    (i = i.replace(d, c ? l.map(
      // these values should be fully encoded instead of just
      // path delimiter escaped since they are being inserted
      // into the URL and we expect URL encoded segments
      // when parsing dynamic route params
      (f) => encodeURIComponent(f)
    ).join("/") : encodeURIComponent(l)) || "/");
  }) || (i = ""), {
    params: o,
    result: i
  };
}
function Nr(a, t, e) {
  let i, n = typeof t == "string" ? t : ot.formatWithValidation(t);
  const s = n.match(/^[a-zA-Z]{1,}:\/\//), r = s ? n.slice(s[0].length) : n;
  if ((r.split("?")[0] || "").match(/(\/\/|\\)/)) {
    console.error(`Invalid href passed to next/router: ${n}, repeated forward-slashes (//) or backslashes \\ are not valid in the href`);
    const h = Ot.normalizeRepeatedSlashes(r);
    n = (s ? s[0] : "") + h;
  }
  if (!zn(n))
    return e ? [
      n
    ] : n;
  try {
    i = new URL(n.startsWith("#") ? a.asPath : a.pathname, "http://n");
  } catch {
    i = new URL("/", "http://n");
  }
  try {
    const h = new URL(n, i);
    h.pathname = ym.normalizePathTrailingSlash(h.pathname);
    let l = "";
    if (ue.isDynamicRoute(h.pathname) && h.searchParams && e) {
      const u = wm.searchParamsToUrlQuery(h.searchParams), { result: d, params: f } = Ma(h.pathname, h.pathname, u);
      d && (l = ot.formatWithValidation({
        pathname: d,
        hash: h.hash,
        query: Il(u, f)
      }));
    }
    const c = h.origin === i.origin ? h.href.slice(h.origin.length) : h.href;
    return e ? [
      c,
      l || c
    ] : c;
  } catch {
    return e ? [
      n
    ] : n;
  }
}
function Zs(a, t, e) {
  let [i, n] = Nr(a, t, !0);
  const s = Ot.getLocationOrigin(), r = i.startsWith(s), o = n && n.startsWith(s);
  i = Js(i), n = n && Js(n);
  const h = r ? i : X.addBasePath(i), l = e ? Js(Nr(a, e)) : n || i;
  return {
    url: h,
    as: o ? l : X.addBasePath(l)
  };
}
function le(a, t) {
  const e = oe.removeTrailingSlash(_m.denormalizePagePath(a));
  return e === "/404" || e === "/_error" ? a : (t.includes(e) || t.some((i) => {
    if (ue.isDynamicRoute(i) && Qe.getRouteRegex(i).re.test(e))
      return a = i, !0;
  }), oe.removeTrailingSlash(a));
}
function Am(a, t, e) {
  const i = {
    basePath: e.router.basePath,
    i18n: {
      locales: e.router.locales
    },
    trailingSlash: !!process.env.__NEXT_TRAILING_SLASH
  }, n = t.headers.get("x-nextjs-rewrite");
  let s = n || t.headers.get("x-nextjs-matched-path");
  const r = t.headers.get("x-matched-path");
  if (r && !s && !r.includes("__next_data_catchall") && !r.includes("/_error") && !r.includes("/404") && (s = r), s) {
    if (s.startsWith("/")) {
      const c = qt.parseRelativeUrl(s), u = Sn.getNextPathnameInfo(c.pathname, {
        nextConfig: i,
        parseData: !0
      });
      let d = oe.removeTrailingSlash(u.pathname);
      return Promise.all([
        e.router.pageLoader.getPageList(),
        Ti.getClientBuildManifest()
      ]).then(([f, { __rewrites: p }]) => {
        let y = he.addLocale(u.pathname, u.locale);
        if (ue.isDynamicRoute(y) || !n && f.includes(re.normalizeLocalePath(ct.removeBasePath(y), e.router.locales).pathname)) {
          const _ = Sn.getNextPathnameInfo(qt.parseRelativeUrl(a).pathname, {
            parseData: !0
          });
          y = X.addBasePath(_.pathname), c.pathname = y;
        }
        if (process.env.__NEXT_HAS_REWRITES) {
          const _ = Cr.default(y, f, p, c.query, (b) => le(b, f), e.router.locales);
          _.matchedPage && (c.pathname = _.parsedAs.pathname, y = c.pathname, Object.assign(c.query, _.parsedAs.query));
        } else if (!f.includes(d)) {
          const _ = le(d, f);
          _ !== d && (d = _);
        }
        const m = f.includes(d) ? d : le(re.normalizeLocalePath(ct.removeBasePath(c.pathname), e.router.locales).pathname, f);
        if (ue.isDynamicRoute(m)) {
          const _ = Si.getRouteMatcher(Qe.getRouteRegex(m))(y);
          Object.assign(c.query, _ || {});
        }
        return {
          type: "rewrite",
          parsedAs: c,
          resolvedHref: m
        };
      });
    }
    const h = ti.parsePath(a), l = ph.formatNextPathnameInfo(ve({}, Sn.getNextPathnameInfo(h.pathname, {
      nextConfig: i,
      parseData: !0
    }), {
      defaultLocale: e.router.defaultLocale,
      buildId: ""
    }));
    return Promise.resolve({
      type: "redirect-external",
      destination: `${l}${h.query}${h.hash}`
    });
  }
  const o = t.headers.get("x-nextjs-redirect");
  if (o) {
    if (o.startsWith("/")) {
      const h = ti.parsePath(o), l = ph.formatNextPathnameInfo(ve({}, Sn.getNextPathnameInfo(h.pathname, {
        nextConfig: i,
        parseData: !0
      }), {
        defaultLocale: e.router.defaultLocale,
        buildId: ""
      }));
      return Promise.resolve({
        type: "redirect-internal",
        newAs: `${l}${h.query}${h.hash}`,
        newUrl: `${l}${h.query}${h.hash}`
      });
    }
    return Promise.resolve({
      type: "redirect-external",
      destination: o
    });
  }
  return Promise.resolve({
    type: "next"
  });
}
function Mm(a) {
  return kn(a).then((t) => t && a.fetchData ? a.fetchData().then((e) => Am(e.dataHref, e.response, a).then((i) => ({
    dataHref: e.dataHref,
    cacheKey: e.cacheKey,
    json: e.json,
    response: e.response,
    text: e.text,
    effect: i
  }))).catch((e) => null) : null);
}
const Qs = process.env.__NEXT_SCROLL_RESTORATION && typeof window < "u" && "scrollRestoration" in window.history && !!function() {
  try {
    let a = "__next";
    return sessionStorage.setItem(a, a), sessionStorage.removeItem(a), !0;
  } catch {
  }
}(), Cl = Symbol("SSG_DATA_NOT_FOUND");
function Ol(a, t, e) {
  return fetch(a, {
    // Cookies are required to be present for Next.js' SSG "Preview Mode".
    // Cookies may also be required for `getServerSideProps`.
    //
    // > `fetch` won’t send cookies, unless you set the credentials init
    // > option.
    // https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
    //
    // > For maximum browser compatibility when it comes to sending &
    // > receiving cookies, always supply the `credentials: 'same-origin'`
    // > option instead of relying on the default.
    // https://github.com/github/fetch#caveats
    credentials: "same-origin",
    method: e.method || "GET",
    headers: Object.assign({}, e.headers, {
      "x-nextjs-data": "1"
    })
  }).then((i) => !i.ok && t > 1 && i.status >= 500 ? Ol(a, t - 1, e) : i);
}
const Em = {};
function tr(a) {
  const t = document.documentElement, e = t.style.scrollBehavior;
  t.style.scrollBehavior = "auto", a(), t.style.scrollBehavior = e;
}
function yh(a) {
  try {
    return JSON.parse(a);
  } catch {
    return null;
  }
}
function bi({ dataHref: a, inflightCache: t, isPrefetch: e, hasMiddleware: i, isServerRender: n, parseJSON: s, persistCache: r, isBackground: o, unstable_skipClientCache: h }) {
  const { href: l } = new URL(a, window.location.href);
  var c;
  const u = (d) => Ol(a, n ? 3 : 1, {
    headers: e ? {
      purpose: "prefetch"
    } : {},
    method: (c = d == null ? void 0 : d.method) != null ? c : "GET"
  }).then((f) => f.ok && (d == null ? void 0 : d.method) === "HEAD" ? {
    dataHref: a,
    response: f,
    text: "",
    json: {},
    cacheKey: l
  } : f.text().then((p) => {
    if (!f.ok) {
      if (i && [
        301,
        302,
        307,
        308
      ].includes(f.status))
        return {
          dataHref: a,
          response: f,
          text: p,
          json: {},
          cacheKey: l
        };
      if (!i && f.status === 404) {
        var y;
        if ((y = yh(p)) != null && y.notFound)
          return {
            dataHref: a,
            json: {
              notFound: Cl
            },
            response: f,
            text: p,
            cacheKey: l
          };
      }
      const m = new Error("Failed to load static props");
      throw n || Ti.markAssetError(m), m;
    }
    return {
      dataHref: a,
      json: s ? yh(p) : null,
      response: f,
      text: p,
      cacheKey: l
    };
  })).then((f) => ((!r || process.env.NODE_ENV !== "production" || f.response.headers.get("x-middleware-cache") === "no-cache") && delete t[l], f)).catch((f) => {
    throw delete t[l], f;
  });
  return h && r ? u({}).then((d) => (t[l] = Promise.resolve(d), d)) : t[l] !== void 0 ? t[l] : t[l] = u(o ? {
    method: "HEAD"
  } : {});
}
function Lr() {
  return Math.random().toString(36).slice(2, 10);
}
function It({ url: a, router: t }) {
  if (a === X.addBasePath(he.addLocale(t.asPath, t.locale)))
    throw new Error(`Invariant: attempted to hard navigate to the same URL ${a} ${location.href}`);
  window.location.href = a;
}
const gh = ({ route: a, router: t }) => {
  let e = !1;
  const i = t.clc = () => {
    e = !0;
  };
  return () => {
    if (e) {
      const s = new Error(`Abort fetching component for route: "${a}"`);
      throw s.cancelled = !0, s;
    }
    i === t.clc && (t.clc = null);
  };
};
let Nl = class bt {
  reload() {
    window.location.reload();
  }
  /**
  * Go back in history
  */
  back() {
    window.history.back();
  }
  /**
  * Performs a `pushState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */
  push(t, e, i = {}) {
    if (process.env.__NEXT_SCROLL_RESTORATION && Qs)
      try {
        sessionStorage.setItem("__next_scroll_" + this._key, JSON.stringify({
          x: self.pageXOffset,
          y: self.pageYOffset
        }));
      } catch {
      }
    return { url: t, as: e } = Zs(this, t, e), this.change("pushState", t, e, i);
  }
  /**
  * Performs a `replaceState` with arguments
  * @param url of the route
  * @param as masks `url` for the browser
  * @param options object you can define `shallow` and other options
  */
  replace(t, e, i = {}) {
    return { url: t, as: e } = Zs(this, t, e), this.change("replaceState", t, e, i);
  }
  change(t, e, i, n, s) {
    var r = this;
    return be(function* () {
      if (!zn(e))
        return It({
          url: e,
          router: r
        }), !1;
      const o = n._h;
      let h = o || n._shouldResolveHref || ti.parsePath(e).pathname === ti.parsePath(i).pathname;
      const l = ve({}, r.state), c = r.isReady !== !0;
      r.isReady = !0;
      const u = r.isSsr;
      if (o || (r.isSsr = !1), o && r.clc)
        return !1;
      const d = l.locale;
      if (process.env.__NEXT_I18N_SUPPORT) {
        l.locale = n.locale === !1 ? r.defaultLocale : n.locale || l.locale, typeof n.locale > "u" && (n.locale = l.locale);
        const P = qt.parseRelativeUrl(ae.hasBasePath(i) ? ct.removeBasePath(i) : i), $ = re.normalizeLocalePath(P.pathname, r.locales);
        $.detectedLocale && (l.locale = $.detectedLocale, P.pathname = X.addBasePath(P.pathname), i = ot.formatWithValidation(P), e = X.addBasePath(re.normalizeLocalePath(ae.hasBasePath(e) ? ct.removeBasePath(e) : e, r.locales).pathname));
        let D = !1;
        if (process.env.__NEXT_I18N_SUPPORT) {
          var f;
          (f = r.locales) != null && f.includes(l.locale) || (P.pathname = he.addLocale(P.pathname, l.locale), It({
            url: ot.formatWithValidation(P),
            router: r
          }), D = !0);
        }
        const k = fh.detectDomainLocale(r.domainLocales, void 0, l.locale);
        if (process.env.__NEXT_I18N_SUPPORT && !D && k && r.isLocaleDomain && self.location.hostname !== k.domain) {
          const W = ct.removeBasePath(i);
          It({
            url: `http${k.http ? "" : "s"}://${k.domain}${X.addBasePath(`${l.locale === k.defaultLocale ? "" : `/${l.locale}`}${W === "/" ? "" : W}` || "/")}`,
            router: r
          }), D = !0;
        }
        if (D)
          return new Promise(() => {
          });
      }
      Ot.ST && performance.mark("routeChange");
      const { shallow: p = !1, scroll: y = !0 } = n, m = {
        shallow: p
      };
      r._inFlightRoute && r.clc && (u || bt.events.emit("routeChangeError", mh(), r._inFlightRoute, m), r.clc(), r.clc = null), i = X.addBasePath(he.addLocale(ae.hasBasePath(i) ? ct.removeBasePath(i) : i, n.locale, r.defaultLocale));
      const _ = Xs.removeLocale(ae.hasBasePath(i) ? ct.removeBasePath(i) : i, l.locale);
      r._inFlightRoute = i;
      const b = d !== l.locale;
      if (!o && r.onlyAHashChange(_) && !b) {
        l.asPath = _, bt.events.emit("hashChangeStart", i, m), r.changeState(t, e, i, ve({}, n, {
          scroll: !1
        })), y && r.scrollToHash(_);
        try {
          yield r.set(l, r.components[l.route], null);
        } catch (P) {
          throw Tn.default(P) && P.cancelled && bt.events.emit("routeChangeError", P, _, m), P;
        }
        return bt.events.emit("hashChangeComplete", i, m), !0;
      }
      let A = qt.parseRelativeUrl(e), { pathname: g, query: x } = A, v, M;
      try {
        [v, { __rewrites: M }] = yield Promise.all([
          r.pageLoader.getPageList(),
          Ti.getClientBuildManifest(),
          r.pageLoader.getMiddleware()
        ]);
      } catch {
        return It({
          url: i,
          router: r
        }), !1;
      }
      !r.urlIsNew(_) && !b && (t = "replaceState");
      let T = i;
      g = g && oe.removeTrailingSlash(ct.removeBasePath(g));
      const I = yield kn({
        asPath: i,
        locale: l.locale,
        router: r
      });
      if (n.shallow && I && (g = r.pathname), o && I && (h = !1), h && g !== "/_error")
        if (n._shouldResolveHref = !0, process.env.__NEXT_HAS_REWRITES && i.startsWith("/")) {
          const P = Cr.default(X.addBasePath(he.addLocale(_, l.locale), !0), v, M, x, ($) => le($, v), r.locales);
          if (P.externalDest)
            return It({
              url: i,
              router: r
            }), !0;
          I || (T = P.asPath), P.matchedPage && P.resolvedHref && (g = P.resolvedHref, A.pathname = X.addBasePath(g), I || (e = ot.formatWithValidation(A)));
        } else
          A.pathname = le(g, v), A.pathname !== g && (g = A.pathname, A.pathname = X.addBasePath(g), I || (e = ot.formatWithValidation(A)));
      if (!zn(i)) {
        if (process.env.NODE_ENV !== "production")
          throw new Error(`Invalid href: "${e}" and as: "${i}", received relative href and external as
See more info: https://nextjs.org/docs/messages/invalid-relative-url-external-as`);
        return It({
          url: i,
          router: r
        }), !1;
      }
      T = Xs.removeLocale(ct.removeBasePath(T), l.locale);
      let E = oe.removeTrailingSlash(g), R = !1;
      if (ue.isDynamicRoute(E)) {
        const P = qt.parseRelativeUrl(T), $ = P.pathname, D = Qe.getRouteRegex(E);
        R = Si.getRouteMatcher(D)($);
        const k = E === $, W = k ? Ma(E, $, x) : {};
        if (!R || k && !W.result) {
          const ht = Object.keys(D.groups).filter((ui) => !x[ui]);
          if (ht.length > 0 && !I)
            throw process.env.NODE_ENV !== "production" && console.warn(`${k ? "Interpolating href" : "Mismatching `as` and `href`"} failed to manually provide the params: ${ht.join(", ")} in the \`href\`'s \`query\``), new Error((k ? `The provided \`href\` (${e}) value is missing query values (${ht.join(", ")}) to be interpolated properly. ` : `The provided \`as\` value (${$}) is incompatible with the \`href\` value (${E}). `) + `Read more: https://nextjs.org/docs/messages/${k ? "href-interpolation-failed" : "incompatible-href-as"}`);
        } else
          k ? i = ot.formatWithValidation(Object.assign({}, P, {
            pathname: W.result,
            query: Il(x, W.params)
          })) : Object.assign(x, R);
      }
      o || bt.events.emit("routeChangeStart", i, m);
      try {
        var S, C;
        let P = yield r.getRouteInfo({
          route: E,
          pathname: g,
          query: x,
          as: i,
          resolvedAs: T,
          routeProps: m,
          locale: l.locale,
          isPreview: l.isPreview,
          hasMiddleware: I,
          unstable_skipClientCache: n.unstable_skipClientCache,
          isQueryUpdating: o && !r.isFallback
        });
        if ("route" in P && I) {
          g = P.route || E, E = g, m.shallow || (x = Object.assign({}, P.query || {}, x));
          const tt = ae.hasBasePath(A.pathname) ? ct.removeBasePath(A.pathname) : A.pathname;
          if (R && g !== tt && Object.keys(R).forEach((et) => {
            R && x[et] === R[et] && delete x[et];
          }), ue.isDynamicRoute(g)) {
            let Pt = !m.shallow && P.resolvedAs ? P.resolvedAs : X.addBasePath(he.addLocale(new URL(i, location.href).pathname, l.locale), !0);
            if (ae.hasBasePath(Pt) && (Pt = ct.removeBasePath(Pt)), process.env.__NEXT_I18N_SUPPORT) {
              const Ki = re.normalizeLocalePath(Pt, r.locales);
              l.locale = Ki.detectedLocale || l.locale, Pt = Ki.pathname;
            }
            const di = Qe.getRouteRegex(g), Gi = Si.getRouteMatcher(di)(new URL(Pt, location.href).pathname);
            Gi && Object.assign(x, Gi);
          }
        }
        if ("type" in P)
          return P.type === "redirect-internal" ? r.change(t, P.newUrl, P.newAs, n) : (It({
            url: P.destination,
            router: r
          }), new Promise(() => {
          }));
        let { error: $, props: D, __N_SSG: k, __N_SSP: W } = P;
        const ht = P.Component;
        if (ht && ht.unstable_scriptLoader && [].concat(ht.unstable_scriptLoader()).forEach((et) => {
          gm.handleClientScriptLoad(et.props);
        }), (k || W) && D) {
          if (D.pageProps && D.pageProps.__N_REDIRECT) {
            n.locale = !1;
            const tt = D.pageProps.__N_REDIRECT;
            if (tt.startsWith("/") && D.pageProps.__N_REDIRECT_BASE_PATH !== !1) {
              const et = qt.parseRelativeUrl(tt);
              et.pathname = le(et.pathname, v);
              const { url: Pt, as: di } = Zs(r, tt, tt);
              return r.change(t, Pt, di, n);
            }
            return It({
              url: tt,
              router: r
            }), new Promise(() => {
            });
          }
          if (l.isPreview = !!D.__N_PREVIEW, D.notFound === Cl) {
            let tt;
            try {
              yield r.fetchComponent("/404"), tt = "/404";
            } catch {
              tt = "/_error";
            }
            if (P = yield r.getRouteInfo({
              route: tt,
              pathname: tt,
              query: x,
              as: i,
              resolvedAs: T,
              routeProps: {
                shallow: !1
              },
              locale: l.locale,
              isPreview: l.isPreview
            }), "type" in P)
              throw new Error("Unexpected middleware effect on /404");
          }
        }
        bt.events.emit("beforeHistoryChange", i, m), r.changeState(t, e, i, n), o && g === "/_error" && ((S = self.__NEXT_DATA__.props) == null || (C = S.pageProps) == null ? void 0 : C.statusCode) === 500 && (D != null && D.pageProps) && (D.pageProps.statusCode = 500);
        var O;
        const ui = n.shallow && l.route === ((O = P.route) != null ? O : E);
        var L;
        const Vi = (L = n.scroll) != null ? L : !n._h && !ui, Qn = Vi ? {
          x: 0,
          y: 0
        } : null, Wi = ve({}, l, {
          route: E,
          pathname: g,
          query: x,
          asPath: _,
          isFallback: !1
        }), qi = s ?? Qn;
        if (!(n._h && !qi && !c && !b && bm.compareRouterStates(Wi, r.state))) {
          if (yield r.set(Wi, P, qi).catch((et) => {
            if (et.cancelled)
              $ = $ || et;
            else
              throw et;
          }), $)
            throw o || bt.events.emit("routeChangeError", $, _, m), $;
          process.env.__NEXT_I18N_SUPPORT && l.locale && (document.documentElement.lang = l.locale), o || bt.events.emit("routeChangeComplete", i, m), Vi && /#.+$/.test(i) && r.scrollToHash(i);
        }
        return !0;
      } catch (P) {
        if (Tn.default(P) && P.cancelled)
          return !1;
        throw P;
      }
    })();
  }
  changeState(t, e, i, n = {}) {
    if (process.env.NODE_ENV !== "production") {
      if (typeof window.history > "u") {
        console.error("Warning: window.history is not available.");
        return;
      }
      if (typeof window.history[t] > "u") {
        console.error(`Warning: window.history.${t} is not available`);
        return;
      }
    }
    (t !== "pushState" || Ot.getURL() !== i) && (this._shallow = n.shallow, window.history[t](
      {
        url: e,
        as: i,
        options: n,
        __N: !0,
        key: this._key = t !== "pushState" ? this._key : Lr()
      },
      // Most browsers currently ignores this parameter, although they may use it in the future.
      // Passing the empty string here should be safe against future changes to the method.
      // https://developer.mozilla.org/en-US/docs/Web/API/History/replaceState
      "",
      i
    ));
  }
  handleRouteInfoError(t, e, i, n, s, r) {
    var o = this;
    return be(function* () {
      if (console.error(t), t.cancelled)
        throw t;
      if (Ti.isAssetError(t) || r)
        throw bt.events.emit("routeChangeError", t, n, s), It({
          url: n,
          router: o
        }), mh();
      try {
        let h;
        const { page: l, styleSheets: c } = yield o.fetchComponent("/_error"), u = {
          props: h,
          Component: l,
          styleSheets: c,
          err: t,
          error: t
        };
        if (!u.props)
          try {
            u.props = yield o.getInitialProps(l, {
              err: t,
              pathname: e,
              query: i
            });
          } catch (d) {
            console.error("Error in error page `getInitialProps`: ", d), u.props = {};
          }
        return u;
      } catch (h) {
        return o.handleRouteInfoError(Tn.default(h) ? h : new Error(h + ""), e, i, n, s, !0);
      }
    })();
  }
  getRouteInfo({ route: t, pathname: e, query: i, as: n, resolvedAs: s, routeProps: r, locale: o, hasMiddleware: h, isPreview: l, unstable_skipClientCache: c, isQueryUpdating: u }) {
    var d = this;
    return be(function* () {
      let f = t;
      try {
        var p, y, m;
        const _ = gh({
          route: f,
          router: d
        });
        let b = d.components[f];
        if (r.shallow && b && d.route === f)
          return b;
        h && (b = void 0);
        let A = b && !("initial" in b) && process.env.NODE_ENV !== "development" ? b : void 0;
        const g = {
          dataHref: d.pageLoader.getDataHref({
            href: ot.formatWithValidation({
              pathname: e,
              query: i
            }),
            skipInterpolation: !0,
            asPath: s,
            locale: o
          }),
          hasMiddleware: !0,
          isServerRender: d.isSsr,
          parseJSON: !0,
          inflightCache: d.sdc,
          persistCache: !l,
          isPrefetch: !1,
          unstable_skipClientCache: c,
          isBackground: u
        }, x = u ? {} : yield Mm({
          fetchData: () => bi(g),
          asPath: s,
          locale: o,
          router: d
        });
        if (u && x && (x.json = self.__NEXT_DATA__.props), _(), (x == null || (p = x.effect) == null ? void 0 : p.type) === "redirect-internal" || (x == null || (y = x.effect) == null ? void 0 : y.type) === "redirect-external")
          return x.effect;
        if ((x == null || (m = x.effect) == null ? void 0 : m.type) === "rewrite" && (f = oe.removeTrailingSlash(x.effect.resolvedHref), e = x.effect.resolvedHref, i = ve({}, i, x.effect.parsedAs.query), s = ct.removeBasePath(re.normalizeLocalePath(x.effect.parsedAs.pathname, d.locales).pathname), b = d.components[f], r.shallow && b && d.route === f && !h))
          return ve({}, b, {
            route: f
          });
        if (f === "/api" || f.startsWith("/api/"))
          return It({
            url: n,
            router: d
          }), new Promise(() => {
          });
        const v = A || (yield d.fetchComponent(f).then((E) => ({
          Component: E.page,
          styleSheets: E.styleSheets,
          __N_SSG: E.mod.__N_SSG,
          __N_SSP: E.mod.__N_SSP
        })));
        if (process.env.NODE_ENV !== "production") {
          const { isValidElementType: E } = pm();
          if (!E(v.Component))
            throw new Error(`The default export is not a React Component in page: "${e}"`);
        }
        const M = v.__N_SSG || v.__N_SSP, { props: T, cacheKey: I } = yield d._getData(be(function* () {
          if (M) {
            const { json: E, cacheKey: R } = x != null && x.json ? x : yield bi({
              dataHref: d.pageLoader.getDataHref({
                href: ot.formatWithValidation({
                  pathname: e,
                  query: i
                }),
                asPath: s,
                locale: o
              }),
              isServerRender: d.isSsr,
              parseJSON: !0,
              inflightCache: d.sdc,
              persistCache: !l,
              isPrefetch: !1,
              unstable_skipClientCache: c
            });
            return {
              cacheKey: R,
              props: E || {}
            };
          }
          return {
            headers: {},
            cacheKey: "",
            props: yield d.getInitialProps(
              v.Component,
              // we provide AppTree later so this needs to be `any`
              {
                pathname: e,
                query: i,
                asPath: n,
                locale: o,
                locales: d.locales,
                defaultLocale: d.defaultLocale
              }
            )
          };
        }));
        return v.__N_SSP && g.dataHref && delete d.sdc[I], !d.isPreview && v.__N_SSG && process.env.NODE_ENV !== "development" && !u && bi(Object.assign({}, g, {
          isBackground: !0,
          persistCache: !1,
          inflightCache: Em
        })).catch(() => {
        }), T.pageProps = Object.assign({}, T.pageProps), v.props = T, v.route = f, v.query = i, v.resolvedAs = s, d.components[f] = v, v;
      } catch (_) {
        return d.handleRouteInfoError(Tn.getProperError(_), e, i, n, r);
      }
    })();
  }
  set(t, e, i) {
    return this.state = t, this.sub(e, this.components["/_app"].Component, i);
  }
  /**
  * Callback to execute before replacing router state
  * @param cb callback to be executed
  */
  beforePopState(t) {
    this._bps = t;
  }
  onlyAHashChange(t) {
    if (!this.asPath)
      return !1;
    const [e, i] = this.asPath.split("#"), [n, s] = t.split("#");
    return s && e === n && i === s ? !0 : e !== n ? !1 : i !== s;
  }
  scrollToHash(t) {
    const [, e = ""] = t.split("#");
    if (e === "" || e === "top") {
      tr(() => window.scrollTo(0, 0));
      return;
    }
    const i = decodeURIComponent(e), n = document.getElementById(i);
    if (n) {
      tr(() => n.scrollIntoView());
      return;
    }
    const s = document.getElementsByName(i)[0];
    s && tr(() => s.scrollIntoView());
  }
  urlIsNew(t) {
    return this.asPath !== t;
  }
  /**
  * Prefetch page code, you may wait for the data during page rendering.
  * This feature only works in production!
  * @param url the href of prefetched page
  * @param asPath the as path of the prefetched page
  */
  prefetch(t, e = t, i = {}) {
    var n = this;
    return be(function* () {
      if (typeof window < "u" && vm.isBot(window.navigator.userAgent))
        return;
      let s = qt.parseRelativeUrl(t), { pathname: r, query: o } = s;
      if (process.env.__NEXT_I18N_SUPPORT && i.locale === !1) {
        r = re.normalizeLocalePath(r, n.locales).pathname, s.pathname = r, t = ot.formatWithValidation(s);
        let d = qt.parseRelativeUrl(e);
        const f = re.normalizeLocalePath(d.pathname, n.locales);
        d.pathname = f.pathname, i.locale = f.detectedLocale || n.defaultLocale, e = ot.formatWithValidation(d);
      }
      const h = yield n.pageLoader.getPageList();
      let l = e;
      const c = typeof i.locale < "u" ? i.locale || void 0 : n.locale;
      if (process.env.__NEXT_HAS_REWRITES && e.startsWith("/")) {
        let d;
        ({ __rewrites: d } = yield Ti.getClientBuildManifest());
        const f = Cr.default(X.addBasePath(he.addLocale(e, n.locale), !0), h, d, s.query, (p) => le(p, h), n.locales);
        if (f.externalDest)
          return;
        l = Xs.removeLocale(ct.removeBasePath(f.asPath), n.locale), f.matchedPage && f.resolvedHref && (r = f.resolvedHref, s.pathname = r, t = ot.formatWithValidation(s));
      }
      if (s.pathname = le(s.pathname, h), ue.isDynamicRoute(s.pathname) && (r = s.pathname, s.pathname = r, Object.assign(o, Si.getRouteMatcher(Qe.getRouteRegex(s.pathname))(ti.parsePath(e).pathname) || {}), t = ot.formatWithValidation(s)), process.env.NODE_ENV !== "production")
        return;
      const u = oe.removeTrailingSlash(r);
      yield Promise.all([
        n.pageLoader._isSsg(u).then((d) => d ? bi({
          dataHref: n.pageLoader.getDataHref({
            href: t,
            asPath: l,
            locale: c
          }),
          isServerRender: !1,
          parseJSON: !0,
          inflightCache: n.sdc,
          persistCache: !n.isPreview,
          isPrefetch: !0,
          unstable_skipClientCache: i.unstable_skipClientCache || i.priority && !!process.env.__NEXT_OPTIMISTIC_CLIENT_CACHE
        }).then(() => !1) : !1),
        n.pageLoader[i.priority ? "loadPage" : "prefetch"](u)
      ]);
    })();
  }
  fetchComponent(t) {
    var e = this;
    return be(function* () {
      const i = gh({
        route: t,
        router: e
      });
      try {
        const n = yield e.pageLoader.loadPage(t);
        return i(), n;
      } catch (n) {
        throw i(), n;
      }
    })();
  }
  _getData(t) {
    let e = !1;
    const i = () => {
      e = !0;
    };
    return this.clc = i, t().then((n) => {
      if (i === this.clc && (this.clc = null), e) {
        const s = new Error("Loading initial props cancelled");
        throw s.cancelled = !0, s;
      }
      return n;
    });
  }
  _getFlightData(t) {
    return bi({
      dataHref: t,
      isServerRender: !0,
      parseJSON: !1,
      inflightCache: this.sdc,
      persistCache: !1,
      isPrefetch: !1
    }).then(({ text: e }) => ({
      data: e
    }));
  }
  getInitialProps(t, e) {
    const { Component: i } = this.components["/_app"], n = this._wrapApp(i);
    return e.AppTree = n, Ot.loadGetInitialProps(i, {
      AppTree: n,
      Component: t,
      router: this,
      ctx: e
    });
  }
  get route() {
    return this.state.route;
  }
  get pathname() {
    return this.state.pathname;
  }
  get query() {
    return this.state.query;
  }
  get asPath() {
    return this.state.asPath;
  }
  get locale() {
    return this.state.locale;
  }
  get isFallback() {
    return this.state.isFallback;
  }
  get isPreview() {
    return this.state.isPreview;
  }
  constructor(t, e, i, { initialProps: n, pageLoader: s, App: r, wrapApp: o, Component: h, err: l, subscription: c, isFallback: u, locale: d, locales: f, defaultLocale: p, domainLocales: y, isPreview: m }) {
    this.sdc = {}, this.isFirstPopStateEvent = !0, this._key = Lr(), this.onPopState = (A) => {
      const { isFirstPopStateEvent: g } = this;
      this.isFirstPopStateEvent = !1;
      const x = A.state;
      if (!x) {
        const { pathname: S, query: C } = this;
        this.changeState("replaceState", ot.formatWithValidation({
          pathname: X.addBasePath(S),
          query: C
        }), Ot.getURL());
        return;
      }
      if (x.__NA) {
        window.location.reload();
        return;
      }
      if (!x.__N || g && this.locale === x.options.locale && x.as === this.asPath)
        return;
      let v;
      const { url: M, as: T, options: I, key: E } = x;
      if (process.env.__NEXT_SCROLL_RESTORATION && Qs && this._key !== E) {
        try {
          sessionStorage.setItem("__next_scroll_" + this._key, JSON.stringify({
            x: self.pageXOffset,
            y: self.pageYOffset
          }));
        } catch {
        }
        try {
          const S = sessionStorage.getItem("__next_scroll_" + E);
          v = JSON.parse(S);
        } catch {
          v = {
            x: 0,
            y: 0
          };
        }
      }
      this._key = E;
      const { pathname: R } = qt.parseRelativeUrl(M);
      this.isSsr && T === X.addBasePath(this.asPath) && R === X.addBasePath(this.pathname) || this._bps && !this._bps(x) || this.change("replaceState", M, T, Object.assign({}, I, {
        shallow: I.shallow && this._shallow,
        locale: I.locale || this.defaultLocale,
        // @ts-ignore internal value not exposed on types
        _h: 0
      }), v);
    };
    const _ = oe.removeTrailingSlash(t);
    this.components = {}, t !== "/_error" && (this.components[_] = {
      Component: h,
      initial: !0,
      props: n,
      err: l,
      __N_SSG: n && n.__N_SSG,
      __N_SSP: n && n.__N_SSP
    }), this.components["/_app"] = {
      Component: r,
      styleSheets: []
    }, this.events = bt.events, this.pageLoader = s;
    const b = ue.isDynamicRoute(t) && self.__NEXT_DATA__.autoExport;
    if (this.basePath = process.env.__NEXT_ROUTER_BASEPATH || "", this.sub = c, this.clc = null, this._wrapApp = o, this.isSsr = !0, this.isLocaleDomain = !1, this.isReady = !!(self.__NEXT_DATA__.gssp || self.__NEXT_DATA__.gip || self.__NEXT_DATA__.appGip && !self.__NEXT_DATA__.gsp || !b && !self.location.search && !process.env.__NEXT_HAS_REWRITES), process.env.__NEXT_I18N_SUPPORT && (this.locales = f, this.defaultLocale = p, this.domainLocales = y, this.isLocaleDomain = !!fh.detectDomainLocale(y, self.location.hostname)), this.state = {
      route: _,
      pathname: t,
      query: e,
      asPath: b ? t : i,
      isPreview: !!m,
      locale: process.env.__NEXT_I18N_SUPPORT ? d : void 0,
      isFallback: u
    }, this._initialMatchesMiddlewarePromise = Promise.resolve(!1), typeof window < "u") {
      if (!i.startsWith("//")) {
        const A = {
          locale: d
        }, g = Ot.getURL();
        this._initialMatchesMiddlewarePromise = kn({
          router: this,
          locale: d,
          asPath: g
        }).then((x) => (A._shouldResolveHref = i !== t, this.changeState("replaceState", x ? g : ot.formatWithValidation({
          pathname: X.addBasePath(t),
          query: e
        }), g, A), x));
      }
      window.addEventListener("popstate", this.onPopState), process.env.__NEXT_SCROLL_RESTORATION && Qs && (window.history.scrollRestoration = "manual");
    }
  }
};
Nl.events = xm.default();
Xt.default = Nl;
var Zn = {};
Object.defineProperty(Zn, "__esModule", {
  value: !0
});
Zn.RouterContext = void 0;
var Tm = Yt.default, Sm = Tm(ri);
const Ll = Sm.default.createContext(null);
Zn.RouterContext = Ll;
process.env.NODE_ENV !== "production" && (Ll.displayName = "RouterContext");
var Rn = { exports: {} }, _h;
function Rm() {
  return _h || (_h = 1, function(a, t) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), t.default = s;
    var e = Yt.default, i = e(ri), n = Dl();
    function s(r) {
      function o(h) {
        return /* @__PURE__ */ i.default.createElement(r, Object.assign({
          router: n.useRouter()
        }, h));
      }
      if (o.getInitialProps = r.getInitialProps, o.origGetInitialProps = r.origGetInitialProps, process.env.NODE_ENV !== "production") {
        const h = r.displayName || r.name || "Unknown";
        o.displayName = `withRouter(${h})`;
      }
      return o;
    }
    (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
  }(Rn, Rn.exports)), Rn.exports;
}
var xh;
function Dl() {
  return xh || (xh = 1, function(a, t) {
    Object.defineProperty(t, "__esModule", {
      value: !0
    }), Object.defineProperty(t, "Router", {
      enumerable: !0,
      get: function() {
        return n.default;
      }
    }), Object.defineProperty(t, "withRouter", {
      enumerable: !0,
      get: function() {
        return o.default;
      }
    }), t.useRouter = p, t.createRouter = y, t.makePublicRouterInstance = m, t.default = void 0;
    var e = Yt.default, i = e(ri), n = e(Xt), s = Zn, r = e(ki), o = e(Rm());
    const h = {
      router: null,
      readyCallbacks: [],
      ready(_) {
        if (this.router)
          return _();
        typeof window < "u" && this.readyCallbacks.push(_);
      }
    }, l = [
      "pathname",
      "route",
      "query",
      "asPath",
      "components",
      "isFallback",
      "basePath",
      "locale",
      "locales",
      "defaultLocale",
      "isReady",
      "isPreview",
      "isLocaleDomain",
      "domainLocales"
    ], c = [
      "routeChangeStart",
      "beforeHistoryChange",
      "routeChangeComplete",
      "routeChangeError",
      "hashChangeStart",
      "hashChangeComplete"
    ], u = [
      "push",
      "replace",
      "reload",
      "back",
      "prefetch",
      "beforePopState"
    ];
    Object.defineProperty(h, "events", {
      get() {
        return n.default.events;
      }
    });
    function d() {
      if (!h.router) {
        const _ = `No router instance found.
You should only use "next/router" on the client side of your app.
`;
        throw new Error(_);
      }
      return h.router;
    }
    l.forEach((_) => {
      Object.defineProperty(h, _, {
        get() {
          return d()[_];
        }
      });
    }), u.forEach((_) => {
      h[_] = (...b) => d()[_](...b);
    }), c.forEach((_) => {
      h.ready(() => {
        n.default.events.on(_, (...b) => {
          const A = `on${_.charAt(0).toUpperCase()}${_.substring(1)}`, g = h;
          if (g[A])
            try {
              g[A](...b);
            } catch (x) {
              console.error(`Error when running the Router event: ${A}`), console.error(r.default(x) ? `${x.message}
${x.stack}` : x + "");
            }
        });
      });
    });
    var f = h;
    t.default = f;
    function p() {
      return i.default.useContext(s.RouterContext);
    }
    function y(..._) {
      return h.router = new n.default(..._), h.readyCallbacks.forEach((b) => b()), h.readyCallbacks = [], h.router;
    }
    function m(_) {
      const b = _, A = {};
      for (const g of l) {
        if (typeof b[g] == "object") {
          A[g] = Object.assign(Array.isArray(b[g]) ? [] : {}, b[g]);
          continue;
        }
        A[g] = b[g];
      }
      return A.events = n.default.events, u.forEach((g) => {
        A[g] = (...x) => b[g](...x);
      }), A;
    }
    (typeof t.default == "function" || typeof t.default == "object" && t.default !== null) && typeof t.default.__esModule > "u" && (Object.defineProperty(t.default, "__esModule", { value: !0 }), Object.assign(t.default, t), a.exports = t.default);
  }(vn, vn.exports)), vn.exports;
}
var Pm = Dl();
const Im = /* @__PURE__ */ Zr(Pm);
/*! js-cookie v3.0.5 | MIT */
function Pn(a) {
  for (var t = 1; t < arguments.length; t++) {
    var e = arguments[t];
    for (var i in e)
      a[i] = e[i];
  }
  return a;
}
var Cm = {
  read: function(a) {
    return a[0] === '"' && (a = a.slice(1, -1)), a.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent);
  },
  write: function(a) {
    return encodeURIComponent(a).replace(
      /%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g,
      decodeURIComponent
    );
  }
};
function Dr(a, t) {
  function e(n, s, r) {
    if (!(typeof document > "u")) {
      r = Pn({}, t, r), typeof r.expires == "number" && (r.expires = new Date(Date.now() + r.expires * 864e5)), r.expires && (r.expires = r.expires.toUTCString()), n = encodeURIComponent(n).replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent).replace(/[()]/g, escape);
      var o = "";
      for (var h in r)
        r[h] && (o += "; " + h, r[h] !== !0 && (o += "=" + r[h].split(";")[0]));
      return document.cookie = n + "=" + a.write(s, n) + o;
    }
  }
  function i(n) {
    if (!(typeof document > "u" || arguments.length && !n)) {
      for (var s = document.cookie ? document.cookie.split("; ") : [], r = {}, o = 0; o < s.length; o++) {
        var h = s[o].split("="), l = h.slice(1).join("=");
        try {
          var c = decodeURIComponent(h[0]);
          if (r[c] = a.read(l, c), n === c)
            break;
        } catch {
        }
      }
      return n ? r[n] : r;
    }
  }
  return Object.create(
    {
      set: e,
      get: i,
      remove: function(n, s) {
        e(
          n,
          "",
          Pn({}, s, {
            expires: -1
          })
        );
      },
      withAttributes: function(n) {
        return Dr(this.converter, Pn({}, this.attributes, n));
      },
      withConverter: function(n) {
        return Dr(Pn({}, this.converter, n), this.attributes);
      }
    },
    {
      attributes: { value: Object.freeze(t) },
      converter: { value: Object.freeze(a) }
    }
  );
}
var Bl = Dr(Cm, { path: "/" }), Jt = { exports: {} };
const Om = {}, Nm = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Om
}, Symbol.toStringTag, { value: "Module" })), Lm = /* @__PURE__ */ Md(Nm), Dm = "dotenv", Bm = "16.3.1", Fm = "Loads environment variables from .env file", km = "lib/main.js", zm = "lib/main.d.ts", Um = {
  ".": {
    types: "./lib/main.d.ts",
    require: "./lib/main.js",
    default: "./lib/main.js"
  },
  "./config": "./config.js",
  "./config.js": "./config.js",
  "./lib/env-options": "./lib/env-options.js",
  "./lib/env-options.js": "./lib/env-options.js",
  "./lib/cli-options": "./lib/cli-options.js",
  "./lib/cli-options.js": "./lib/cli-options.js",
  "./package.json": "./package.json"
}, jm = {
  "dts-check": "tsc --project tests/types/tsconfig.json",
  lint: "standard",
  "lint-readme": "standard-markdown",
  pretest: "npm run lint && npm run dts-check",
  test: "tap tests/*.js --100 -Rspec",
  prerelease: "npm test",
  release: "standard-version"
}, Hm = {
  type: "git",
  url: "git://github.com/motdotla/dotenv.git"
}, $m = "https://github.com/motdotla/dotenv?sponsor=1", Vm = [
  "dotenv",
  "env",
  ".env",
  "environment",
  "variables",
  "config",
  "settings"
], Wm = "README.md", qm = "BSD-2-Clause", Gm = {
  "@definitelytyped/dtslint": "^0.0.133",
  "@types/node": "^18.11.3",
  decache: "^4.6.1",
  sinon: "^14.0.1",
  standard: "^17.0.0",
  "standard-markdown": "^7.1.0",
  "standard-version": "^9.5.0",
  tap: "^16.3.0",
  tar: "^6.1.11",
  typescript: "^4.8.4"
}, Km = {
  node: ">=12"
}, Ym = {
  fs: !1
}, Xm = {
  name: Dm,
  version: Bm,
  description: Fm,
  main: km,
  types: zm,
  exports: Um,
  scripts: jm,
  repository: Hm,
  funding: $m,
  keywords: Vm,
  readmeFilename: Wm,
  license: qm,
  devDependencies: Gm,
  engines: Km,
  browser: Ym
}, Fl = Lm, Ea = ql, Jm = Gl, Zm = Kl, Qm = Xm, Ta = Qm.version, ty = /(?:^|^)\s*(?:export\s+)?([\w.-]+)(?:\s*=\s*?|:\s+?)(\s*'(?:\\'|[^'])*'|\s*"(?:\\"|[^"])*"|\s*`(?:\\`|[^`])*`|[^#\r\n]+)?\s*(?:#.*)?(?:$|$)/mg;
function ey(a) {
  const t = {};
  let e = a.toString();
  e = e.replace(/\r\n?/mg, `
`);
  let i;
  for (; (i = ty.exec(e)) != null; ) {
    const n = i[1];
    let s = i[2] || "";
    s = s.trim();
    const r = s[0];
    s = s.replace(/^(['"`])([\s\S]*)\1$/mg, "$2"), r === '"' && (s = s.replace(/\\n/g, `
`), s = s.replace(/\\r/g, "\r")), t[n] = s;
  }
  return t;
}
function iy(a) {
  const t = zl(a), e = Z.configDotenv({ path: t });
  if (!e.parsed)
    throw new Error(`MISSING_DATA: Cannot parse ${t} for an unknown reason`);
  const i = kl(a).split(","), n = i.length;
  let s;
  for (let r = 0; r < n; r++)
    try {
      const o = i[r].trim(), h = ry(e, o);
      s = Z.decrypt(h.ciphertext, h.key);
      break;
    } catch (o) {
      if (r + 1 >= n)
        throw o;
    }
  return Z.parse(s);
}
function ny(a) {
  console.log(`[dotenv@${Ta}][INFO] ${a}`);
}
function sy(a) {
  console.log(`[dotenv@${Ta}][WARN] ${a}`);
}
function Br(a) {
  console.log(`[dotenv@${Ta}][DEBUG] ${a}`);
}
function kl(a) {
  return a && a.DOTENV_KEY && a.DOTENV_KEY.length > 0 ? a.DOTENV_KEY : process.env.DOTENV_KEY && process.env.DOTENV_KEY.length > 0 ? process.env.DOTENV_KEY : "";
}
function ry(a, t) {
  let e;
  try {
    e = new URL(t);
  } catch (o) {
    throw o.code === "ERR_INVALID_URL" ? new Error("INVALID_DOTENV_KEY: Wrong format. Must be in valid uri format like dotenv://:key_1234@dotenv.org/vault/.env.vault?environment=development") : o;
  }
  const i = e.password;
  if (!i)
    throw new Error("INVALID_DOTENV_KEY: Missing key part");
  const n = e.searchParams.get("environment");
  if (!n)
    throw new Error("INVALID_DOTENV_KEY: Missing environment part");
  const s = `DOTENV_VAULT_${n.toUpperCase()}`, r = a.parsed[s];
  if (!r)
    throw new Error(`NOT_FOUND_DOTENV_ENVIRONMENT: Cannot locate environment ${s} in your .env.vault file.`);
  return { ciphertext: r, key: i };
}
function zl(a) {
  let t = Ea.resolve(process.cwd(), ".env");
  return a && a.path && a.path.length > 0 && (t = a.path), t.endsWith(".vault") ? t : `${t}.vault`;
}
function ay(a) {
  return a[0] === "~" ? Ea.join(Jm.homedir(), a.slice(1)) : a;
}
function oy(a) {
  ny("Loading env from encrypted .env.vault");
  const t = Z._parseVault(a);
  let e = process.env;
  return a && a.processEnv != null && (e = a.processEnv), Z.populate(e, t, a), { parsed: t };
}
function hy(a) {
  let t = Ea.resolve(process.cwd(), ".env"), e = "utf8";
  const i = !!(a && a.debug);
  a && (a.path != null && (t = ay(a.path)), a.encoding != null && (e = a.encoding));
  try {
    const n = Z.parse(Fl.readFileSync(t, { encoding: e }));
    let s = process.env;
    return a && a.processEnv != null && (s = a.processEnv), Z.populate(s, n, a), { parsed: n };
  } catch (n) {
    return i && Br(`Failed to load ${t} ${n.message}`), { error: n };
  }
}
function ly(a) {
  const t = zl(a);
  return kl(a).length === 0 ? Z.configDotenv(a) : Fl.existsSync(t) ? Z._configVault(a) : (sy(`You set DOTENV_KEY but you are missing a .env.vault file at ${t}. Did you forget to build it?`), Z.configDotenv(a));
}
function cy(a, t) {
  const e = Buffer.from(t.slice(-64), "hex");
  let i = Buffer.from(a, "base64");
  const n = i.slice(0, 12), s = i.slice(-16);
  i = i.slice(12, -16);
  try {
    const r = Zm.createDecipheriv("aes-256-gcm", e, n);
    return r.setAuthTag(s), `${r.update(i)}${r.final()}`;
  } catch (r) {
    const o = r instanceof RangeError, h = r.message === "Invalid key length", l = r.message === "Unsupported state or unable to authenticate data";
    if (o || h) {
      const c = "INVALID_DOTENV_KEY: It must be 64 characters long (or more)";
      throw new Error(c);
    } else if (l) {
      const c = "DECRYPTION_FAILED: Please check your DOTENV_KEY";
      throw new Error(c);
    } else
      throw console.error("Error: ", r.code), console.error("Error: ", r.message), r;
  }
}
function uy(a, t, e = {}) {
  const i = !!(e && e.debug), n = !!(e && e.override);
  if (typeof t != "object")
    throw new Error("OBJECT_REQUIRED: Please check the processEnv argument being passed to populate");
  for (const s of Object.keys(t))
    Object.prototype.hasOwnProperty.call(a, s) ? (n === !0 && (a[s] = t[s]), i && Br(n === !0 ? `"${s}" is already defined and WAS overwritten` : `"${s}" is already defined and was NOT overwritten`)) : a[s] = t[s];
}
const Z = {
  configDotenv: hy,
  _configVault: oy,
  _parseVault: iy,
  config: ly,
  decrypt: cy,
  parse: ey,
  populate: uy
};
Jt.exports.configDotenv = Z.configDotenv;
Jt.exports._configVault = Z._configVault;
Jt.exports._parseVault = Z._parseVault;
Jt.exports.config = Z.config;
Jt.exports.decrypt = Z.decrypt;
Jt.exports.parse = Z.parse;
Jt.exports.populate = Z.populate;
Jt.exports = Z;
var dy = Jt.exports;
const fy = /* @__PURE__ */ Zr(dy);
fy.config();
const py = {
  CHARACTERXYZ_API_KEY: process.env.CHARACTERXYZ_API_KEY,
  PUBLIC_REST_API_ENDPOINT: "https://us-central1-characterxyz-production.cloudfunctions.net/server/api",
  PUBLIC_WEBSITE_URL: "https://www.character.xyz/",
  AUTH_TOKEN_KEY: "characterxyz-auth-token"
}, Ul = py.AUTH_TOKEN_KEY, my = () => typeof window === void 0 ? null : Bl.get(Ul);
function yy() {
  Bl.remove(Ul);
}
const gy = "https://us-central1-characterxyz-production.cloudfunctions.net/server/api", Ae = _f.create({
  baseURL: gy,
  timeout: 1e4,
  headers: {
    "Content-Type": "application/json"
  }
});
Ae.interceptors.request.use(
  (a) => {
    const t = my();
    return a.headers = {
      Authorization: `Bearer ${t || ""}`,
      ...a.headers
    }, a;
  },
  (a) => Promise.reject(a)
);
Ae.interceptors.response.use(
  (a) => a,
  (a) => ((a.response && a.response.status === 401 || a.response && a.response.status === 403 || a.response && a.response.data.message === "NOT_AUTHORIZED") && (yy(), Im.reload()), Promise.reject(a))
);
class wh {
  static async requestWithRetry(t, e = !0) {
    try {
      return (await t()).data;
    } catch (i) {
      if (this.isAxiosError(i) && i.code === "ECONNABORTED" && e)
        return await this.requestWithRetry(t, !1);
      throw i;
    }
  }
  static isAxiosError(t) {
    return t && t.isAxiosError;
  }
  static async get(t, e, i) {
    return this.requestWithRetry(() => Ae.get(t, { ...i, params: e }));
  }
  static async post(t, e, i) {
    return this.requestWithRetry(() => Ae.post(t, e, i));
  }
  static async patch(t, e, i) {
    return this.requestWithRetry(() => Ae.patch(t, e, i));
  }
  static async put(t, e) {
    return this.requestWithRetry(() => Ae.put(t, e));
  }
  static async delete(t, e) {
    return this.requestWithRetry(() => Ae.delete(t, { data: e }));
  }
}
class _y {
  constructor() {
    this.characters = {
      getOneBySlug: (t) => {
        const { slug: e, query: i } = t, n = So.CHARACTERS_SLUG + `/${e}`;
        return wh.get(n, i);
      },
      getMultiple: (t) => {
        const e = So.CHARACTERS_MULTIPLE;
        return wh.post(e, t);
      }
    };
  }
}
const jl = new _y();
async function xy(a, t) {
  try {
    const e = {
      slug: "Tamashi-TiAJWr3sWxh79UKd1UDU",
      query: { visual_style: t || Fn.DETAILED }
    }, i = await jl.characters.getOneBySlug(e);
    return Promise.resolve(i);
  } catch (e) {
    return console.error("Error fetching character data:", e), Promise.reject(e);
  }
}
async function wy(a) {
  try {
    const t = await jl.characters.getMultiple(a);
    return Promise.resolve(t);
  } catch (t) {
    return console.error("Error fetching characters data:", t), Promise.reject(t);
  }
}
function by({
  animationsToLoad: a,
  animationsAvailable: t,
  onComplete: e
}) {
  const i = async () => {
    const s = [];
    a.forEach((h) => {
      const l = t[h];
      l && s.push(
        n(l.asset.glb, h)
      );
    });
    const r = (await Promise.all(s)).filter(
      (h) => h !== null
    ), o = {};
    r.forEach(([h, l]) => {
      l && (o[h] = l);
    }), e(o);
  }, n = async (s, r) => {
    try {
      return await new Promise(
        (o) => {
          new $h().load(
            s,
            (l) => {
              const c = l.animations;
              c.length > 0 ? o([r, c[0]]) : (console.error(
                `No animations found in GLTF for ${r}.`
              ), o([r, null]));
            },
            void 0,
            (l) => {
              console.error(`Error loading animation ${r}:`, l), o([r, null]);
            }
          );
        }
      );
    } catch (o) {
      return console.error(`Error loading animation ${r}:`, o), null;
    }
  };
  i();
}
const Rt = class lt {
  constructor(t) {
    this.velocity = new w(), this.acceleration = new w(), this.gravity = new w(0, -9.8, 0), this.airResistance = 0.02, this.runCooldown = 0, this.jumpBufferDuration = 0.5, this.jumpBufferTimer = 0, this.angularVelocity = new w(), this.torque = new w(), this.jumpForce = 12, this.jumpCount = 0, this.maxJumps = 2, this.isRunning = !1, this.isJumping = !1, this.isGrounded = !0, this.groundLayer = 1, this.groundLayer = (t == null ? void 0 : t.groundLayer) || 1, this.debugDraw = (t == null ? void 0 : t.debugDraw) || !1, this.debugDraw && (this.debugLineMaterial = new jn({ color: 16711680 }), this.debugLineGeometry = new Dt(), this.debugLine = new Li(
      this.debugLineGeometry,
      this.debugLineMaterial
    ), this.debugLine.raycast = () => {
    });
  }
  move(t, e = 1) {
    const i = t.multiplyScalar(e);
    this.applyForce(i);
  }
  applyForce(t) {
    this.acceleration.add(t);
  }
  applyTorque(t) {
    this.torque.add(t);
  }
  isInRunCooldown() {
    return this.runCooldown;
  }
  toggleRun(t) {
    t ? (this.isRunning = !0, this.runCooldown = 0) : this.runCooldown = lt.RUN_COOLDOWN_DURATION;
  }
  resetRunningFlags() {
    this.isRunning = !1;
  }
  jump() {
    this.jumpCount < this.maxJumps && this.isGrounded && (this.jumpCount++, this.isJumping = !0, this.isGrounded = !1, this.velocity.y += this.jumpForce, this.jumpBufferTimer = this.jumpBufferDuration);
  }
  land() {
    this.isJumping = !1, this.isGrounded = !0, this.jumpCount = 0, this.velocity.y = 0, this.acceleration.y = 0;
  }
  getVelocity() {
    return this.velocity.clone();
  }
  getIsJumping() {
    return this.isJumping;
  }
  getIsRunning() {
    return this.isRunning;
  }
  applyGravity(t) {
    if (!this.isGrounded) {
      const e = this.gravity.clone().multiplyScalar(t);
      this.velocity.add(e);
    }
  }
  applyAirResistance() {
    const t = this.velocity.clone().multiplyScalar(-this.airResistance);
    this.acceleration.add(t);
  }
  applyDamping() {
    const t = this.isRunning ? lt.RUNNING_DAMPING : lt.WALKING_DAMPING;
    if (this.isGrounded) {
      this.velocity.multiplyScalar(t);
      const e = this.isRunning ? lt.MAX_RUN_SPEED : lt.MAX_WALK_SPEED;
      this.velocity.length() > e && this.velocity.normalize().multiplyScalar(e);
      const i = this.isRunning ? lt.RUNNING_VELOCITY_THRESHOLD : lt.WALKING_VELOCITY_THRESHOLD;
      this.velocity.length() < i && this.velocity.set(0, this.velocity.y, 0);
    } else {
      const e = this.isRunning ? lt.RUNNING_DAMPING : lt.WALKING_DAMPING;
      this.isJumping ? (this.velocity.x *= lt.JUMPING_FORWARD_DAMPING, this.velocity.z *= lt.JUMPING_FORWARD_DAMPING) : (this.velocity.x *= e, this.velocity.z *= e), this.velocity.y *= lt.AIRBORNE_DAMPING;
    }
  }
  checkGroundCollision(t, e) {
    if (this.jumpBufferTimer > 0)
      return;
    const i = t.clone().add(new w(0, lt.RAYCAST_OFFSET, 0)), n = t, s = n.clone().sub(i).normalize(), r = i.distanceTo(n), o = new zu(i, s, 0, r);
    o.layers.set(this.groundLayer);
    const h = o.intersectObjects(e.children, !0);
    this.debugDraw && this.debugLineGeometry && this.debugLine && (this.debugLineGeometry.setFromPoints([i, n]), e.children.includes(this.debugLine) || e.add(this.debugLine)), h.length > 0 && this.velocity.y <= 0 && this.land();
  }
  updateRotation(t, e) {
    const i = this.torque.clone().multiplyScalar(t);
    this.angularVelocity.add(i);
    const n = new Q();
    n.setFromAxisAngle(
      new w(0, 1, 0),
      this.torque.y
    ), e.applyQuaternion(n);
  }
  update(t, e, i) {
    this.velocity.add(this.acceleration), this.acceleration.set(0, 0, 0), this.applyGravity(e), this.applyAirResistance(), this.applyDamping(), this.checkGroundCollision(t.position, i), this.updateRotation(e, t);
    const n = this.velocity.clone().multiplyScalar(e);
    t.applyMovement(n);
    const s = new Q();
    s.setFromAxisAngle(
      new w(0, 1, 0),
      this.angularVelocity.y
    ), t.applyQuaternion(s), this.runCooldown > 0 && (this.runCooldown -= e, this.runCooldown <= 0 && (this.isRunning = !1, this.runCooldown = 0)), this.jumpBufferTimer = Math.max(0, this.jumpBufferTimer - e);
  }
};
Rt.WALKING_DAMPING = 0.92;
Rt.RUNNING_DAMPING = 0.92;
Rt.AIRBORNE_DAMPING = 0.99;
Rt.JUMPING_FORWARD_DAMPING = 0.82;
Rt.WALKING_VELOCITY_THRESHOLD = 0.5;
Rt.RUNNING_VELOCITY_THRESHOLD = 0.1;
Rt.MAX_WALK_SPEED = 0.75;
Rt.MAX_RUN_SPEED = 4;
Rt.RAYCAST_OFFSET = 1.5;
Rt.RUN_COOLDOWN_DURATION = 1;
let vy = Rt;
class Ln {
  constructor() {
    this.position = new w(), this.rotation = new Q(), this.scale = new w(1, 1, 1);
  }
  applyMovement(t) {
    this.position.add(t);
  }
  setRotation(t) {
    this.rotation.copy(t);
  }
  distanceTo(t) {
    return this.position.distanceTo(t);
  }
  dot(t) {
    return this.position.dot(t);
  }
  cross(t) {
    return this.position.clone().cross(t);
  }
  applyQuaternion(t) {
    this.rotation.multiplyQuaternions(this.rotation, t);
  }
  setPosition(t, e, i) {
    t instanceof w ? this.position.copy(t) : typeof t == "number" && e !== void 0 && i !== void 0 && this.position.set(t, e, i);
  }
  translate(t, e, i) {
    this.position.add(new w(t, e, i));
  }
  rotateOnAxis(t, e) {
    this.rotation.setFromAxisAngle(t, e);
  }
  scaleUniform(t) {
    this.scale.set(t, t, t);
  }
  setScale(t, e, i) {
    this.scale.set(t, e, i);
  }
  getForwardVector() {
    return new w(0, 0, 1).clone().applyQuaternion(this.rotation).normalize();
  }
}
class Hl {
  constructor() {
    this.characterInstance = null, this.animationsToLoad = [], this.debugDraw = !1;
  }
  // Initialization methods --------------------------
  initialize(t) {
    this.characterInstance = t, t && (this.animationPlayer = t.getAnimationPlayer(), this.movementComponent = t.getMovementComponent());
  }
  // Base class utility methods ----------------------
  isCharacterJumping() {
    var t;
    return ((t = this.movementComponent) == null ? void 0 : t.getIsJumping()) ?? !1;
  }
  isCharacterMoving() {
    var t;
    return (((t = this.movementComponent) == null ? void 0 : t.getVelocity().length()) ?? 0) > 0;
  }
  // Getters -----------------------------------------
  getAnimations() {
    return this.animationsToLoad;
  }
}
const At = {
  // Alphabets
  KEYBOARD_A: "a",
  KEYBOARD_B: "b",
  KEYBOARD_C: "c",
  KEYBOARD_D: "d",
  KEYBOARD_E: "e",
  KEYBOARD_F: "f",
  KEYBOARD_G: "g",
  KEYBOARD_H: "h",
  KEYBOARD_I: "i",
  KEYBOARD_J: "j",
  KEYBOARD_K: "k",
  KEYBOARD_L: "l",
  KEYBOARD_M: "m",
  KEYBOARD_N: "n",
  KEYBOARD_O: "o",
  KEYBOARD_P: "p",
  KEYBOARD_Q: "q",
  KEYBOARD_R: "r",
  KEYBOARD_S: "s",
  KEYBOARD_T: "t",
  KEYBOARD_U: "u",
  KEYBOARD_V: "v",
  KEYBOARD_W: "w",
  KEYBOARD_X: "x",
  KEYBOARD_Y: "y",
  KEYBOARD_Z: "z",
  // Numbers
  KEYBOARD_ZERO: "0",
  KEYBOARD_ONE: "1",
  KEYBOARD_TWO: "2",
  KEYBOARD_THREE: "3",
  KEYBOARD_FOUR: "4",
  KEYBOARD_FIVE: "5",
  KEYBOARD_SIX: "6",
  KEYBOARD_SEVEN: "7",
  KEYBOARD_EIGHT: "8",
  KEYBOARD_NINE: "9",
  // Arrow Keys
  KEYBOARD_UP_ARROW: "arrowup",
  KEYBOARD_DOWN_ARROW: "arrowdown",
  KEYBOARD_LEFT_ARROW: "arrowleft",
  KEYBOARD_RIGHT_ARROW: "arrowright",
  // Special Keys
  KEYBOARD_SPACEBAR: " ",
  KEYBOARD_SHIFT: "shift",
  KEYBOARD_ENTER: "enter",
  KEYBOARD_ESC: "esc",
  KEYBOARD_TAB: "tab",
  // Mouse
  MOUSE_MOVE: "mousemove",
  MOUSE_LEFT_CLICK: "mouseleftclick",
  MOUSE_RIGHT_CLICK: "mouserightclick",
  MOUSE_MIDDLE_CLICK: "mousemiddleclick",
  // Gamepad
  GAMEPAD_BUTTON_A: "gamepadbuttona",
  GAMEPAD_BUTTON_B: "gamepadbuttonb",
  GAMEPAD_BUTTON_X: "gamepadbuttonx",
  GAMEPAD_BUTTON_Y: "gamepadbuttony",
  GAMEPAD_LEFT_STICK: "gamepadleftstick",
  GAMEPAD_RIGHT_STICK: "gamepadrightstick"
}, Ay = {
  moveForward: At.KEYBOARD_W,
  leftTurn: At.KEYBOARD_A,
  rightTurn: At.KEYBOARD_D,
  Jump: At.KEYBOARD_SPACEBAR,
  toggleRun: At.KEYBOARD_SHIFT
}, My = 3;
class Ey extends Hl {
  constructor(t) {
    super(), this.wasShiftPressed = !1, this.keyMapping = t || Ay;
  }
  initialize(t) {
    super.initialize(t), this.animationsToLoad = [
      "idle",
      "walkfwd",
      "runfwd",
      "jumpstart",
      "jumpinair",
      "jumpend"
    ];
  }
  update() {
    !this.animationPlayer || !this.movementComponent || (this.isCharacterJumping() ? this.handleJumpingAnimation() : this.isCharacterMoving() ? this.handleWalkingOrRunningAnimation() : this.animationPlayer.getCurrentAnimation() !== "idle" && this.animationPlayer.play("idle"));
  }
  handleInput(t) {
    this.movementComponent && (this.handleRunToggle(t), this.handleMovement(t));
  }
  handleRunToggle(t) {
    this.movementComponent && (t[this.keyMapping.toggleRun] ? this.wasShiftPressed || (this.movementComponent.toggleRun(!0), this.wasShiftPressed = !0) : this.wasShiftPressed && (this.movementComponent.toggleRun(!1), this.wasShiftPressed = !1));
  }
  handleMovement(t) {
    var n, s, r;
    if (!this.movementComponent)
      return;
    const e = this.movementComponent.getIsRunning() ? 2 : 1;
    if (t[this.keyMapping.moveForward]) {
      const o = new w(0, 0, 1), h = (n = this.characterInstance) == null ? void 0 : n.getRotation();
      h && o.applyQuaternion(h), this.movementComponent.move(o, e);
    }
    const i = Hr.degToRad(5);
    if (t[this.keyMapping.leftTurn]) {
      const o = new Q().setFromAxisAngle(
        new w(0, 1, 0),
        i
      );
      (s = this.characterInstance) == null || s.applyRotation(o);
    }
    if (t[this.keyMapping.rightTurn]) {
      const o = new Q().setFromAxisAngle(
        new w(0, 1, 0),
        -i
      );
      (r = this.characterInstance) == null || r.applyRotation(o);
    }
    t[this.keyMapping.Jump] && this.movementComponent.jump();
  }
  handleJumpingAnimation() {
    var e, i, n, s;
    const t = ((e = this.movementComponent) == null ? void 0 : e.getVelocity().y) ?? 0;
    t > 0 ? (i = this.animationPlayer) == null || i.play("jumpstart") : t < 0 ? (n = this.animationPlayer) == null || n.play("jumpinair") : (s = this.animationPlayer) == null || s.play("jumpend");
  }
  handleWalkingOrRunningAnimation() {
    var e, i, n, s;
    ((e = this.movementComponent) == null ? void 0 : e.getIsRunning()) && (((i = this.movementComponent) == null ? void 0 : i.getVelocity().length()) ?? 0) > My ? (n = this.animationPlayer) == null || n.play("runfwd") : (s = this.animationPlayer) == null || s.play("walkfwd");
  }
  cleanup() {
  }
}
class Sa {
  constructor() {
    this.characterInstance = null, this.behaviorModules = [];
  }
  possessCharacter(t) {
    t && (this.characterInstance = t, this.intializeBehaviorModules(t));
  }
  registerModule(t) {
    this.behaviorModules.push(t);
  }
  update(t) {
    for (const e of this.behaviorModules)
      e.update(t);
  }
  cleanup() {
    for (const t of this.behaviorModules)
      t.cleanup();
  }
  intializeBehaviorModules(t) {
    for (const e of this.behaviorModules)
      e.initialize(t);
  }
  getAnimations() {
    const t = [];
    for (const e of this.behaviorModules) {
      const i = e.getAnimations();
      Array.isArray(i) && t.push(...i);
    }
    return [...new Set(t)];
  }
}
function $l() {
  const a = Object.keys(At).filter((i) => i.startsWith("KEYBOARD_")).reduce((i, n) => (i[At[n]] = !1, i), {}), t = {
    mouseX: 0,
    mouseY: 0,
    ...Object.keys(At).filter((i) => i.startsWith("MOUSE_")).reduce((i, n) => (i[At[n]] = !1, i), {})
  }, e = Object.keys(At).filter((i) => i.startsWith("GAMEPAD_")).reduce((i, n) => (i[At[n]] = !1, i), {});
  return {
    ...a,
    ...t,
    ...e,
    reset: function() {
      Object.assign(this, $l());
    }
  };
}
class Ty extends Sa {
  constructor() {
    super(), this.userInput = $l();
  }
  update(t) {
    for (const e of this.behaviorModules)
      e.handleInput(this.userInput), e.update(t);
  }
  possessCharacter(t) {
    super.possessCharacter(t), this.setupEventListeners();
  }
  setupEventListeners() {
    window.addEventListener("keydown", this.handleKeyDown.bind(this)), window.addEventListener("keyup", this.handleKeyUp.bind(this));
  }
  handleKeyDown(t) {
    this.userInput[t.key.toLowerCase()] = !0;
  }
  handleKeyUp(t) {
    this.userInput[t.key.toLowerCase()] = !1;
  }
}
class bh extends q {
  constructor() {
    super();
  }
  attachToParent(...t) {
    this.add(...t);
  }
}
const Vl = class Fr extends vh {
  constructor(t) {
    super(t), this.clock = new Hh(), this.animationFrameId = null, this.transform = new Ln(), this.meshInstance = null, this.materialsInstance = null, this.animationClipsInstance = null, this.groundLayer = 1, this.useDefaultPlayerController = !1, this.debugDraw = !1, this.componentGroup = new q(), this.components = [], this.update = () => {
      var u;
      const l = this.clock.getDelta();
      this.componentGroup.position.copy(this.transform.position);
      const c = new Ni();
      c.setFromQuaternion(this.transform.rotation), this.componentGroup.rotation.copy(c), this.componentGroup.scale.copy(this.transform.scale), this.movementComponent.update(
        this.transform,
        l,
        this.props.config.scene
      ), this.updateComponents(l), this.meshInstance && (this.meshInstance.position.copy(this.transform.position), this.meshInstance.quaternion.copy(this.transform.rotation), this.meshInstance.scale.copy(this.transform.scale)), this.debugDraw && this.arrowHelper && (this.arrowHelper.setDirection(this.getForwardVector()), this.arrowHelper.position.copy(
        this.transform.position.clone().add(new w(0, Fr.DEBUG_DRAW_FWD_VECTOR_Y_OFFSET, 0))
      )), this.animationPlayer.update(l), (u = this.controller) == null || u.update(l), this.animationFrameId = requestAnimationFrame(this.update);
    }, this.tryApplyingMaterials = () => {
      if (this.meshInstance && this.materialsInstance) {
        const { scene: l } = this.props.config;
        Ad({
          meshInstance: this.meshInstance,
          materialsInstance: this.materialsInstance,
          onComplete: () => {
            vd({
              scene: l,
              mesh: this.meshInstance,
              position: new w(0, 0, 0)
            });
          }
        });
      }
    };
    const { config: e } = t, {
      groundLayer: i,
      useDefaultPlayerController: n,
      components: s,
      debugDraw: r,
      scene: o,
      position: h = new w(0, 0, 0)
    } = e;
    this.transform.setPosition(h), this.groundLayer = i || 1, this.useDefaultPlayerController = n || !1, this.debugDraw = r || !1, this.animationPlayer = new bd(), this.movementComponent = new vy({
      groundLayer: this.groundLayer,
      debugDraw: this.debugDraw
    }), this.components = s || [], this.scene = o;
  }
  componentDidMount() {
    const { slug: t, scene: e, controller: i, debugDraw: n, data: s } = this.props.config;
    if (e.add(this.componentGroup), i)
      this.controller = i;
    else if (this.useDefaultPlayerController) {
      const o = new Ty();
      o.registerModule(new Ey()), this.controller = o;
    } else
      this.controller = new Sa();
    this.controller && this.controller.possessCharacter(this);
    const r = this.props.config.visualStyle || Fn.DETAILED;
    s ? this.initializeCharacter(s) : xy(t, r).then((o) => {
      const h = o.response;
      this.initializeCharacter(h);
    }).catch((o) => {
      console.error("Error fetching character data:", o);
    }), this.debugDraw && this.debugDrawForwardDirection(), this.initComponents(), this.update();
  }
  initializeCharacter(t) {
    var s, r, o, h;
    const e = this.props.config.visualStyle || Fn.DETAILED, i = (s = t.skin_groups) == null ? void 0 : s[e], n = (r = i == null ? void 0 : i.skins) == null ? void 0 : r[0];
    this.props.config.slug, n && (xd((o = n.skinned_mesh) == null ? void 0 : o.glb, (l) => {
      this.meshInstance = l, l && (this.tryApplyingMaterials(), this.tryInitAnimPlayerAndPlayDefaultAnimation());
    }), wd({
      cloudMaterials: n.skin_variations[0].materials,
      onComplete: (l) => {
        this.materialsInstance = l, this.tryApplyingMaterials();
      }
    }), by({
      animationsToLoad: ((h = this.controller) == null ? void 0 : h.getAnimations()) || ["idle"],
      animationsAvailable: n.animations,
      onComplete: (l) => {
        this.animationClipsInstance = l, this.tryInitAnimPlayerAndPlayDefaultAnimation();
      }
    }));
  }
  componentWillUnmount() {
    this.animationFrameId !== null && cancelAnimationFrame(this.animationFrameId);
  }
  render() {
    return null;
  }
  addComponent(t) {
    this.componentGroup.add(t);
  }
  initComponents() {
    this.components.forEach((t) => {
      t instanceof bh && (t.init(), this.addComponent(t));
    });
  }
  updateComponents(t) {
    this.components.forEach((e) => {
      e instanceof bh && e.update(t);
    });
  }
  tryInitAnimPlayerAndPlayDefaultAnimation() {
    this.meshInstance && this.animationClipsInstance && this.animationPlayer && this.animationPlayer.initAndPlayDefault(
      this.meshInstance,
      this.animationClipsInstance
    );
  }
  debugDrawForwardDirection() {
    const t = this.getForwardVector(), e = new w(0, Fr.DEBUG_DRAW_FWD_VECTOR_Y_OFFSET, 0), i = 1, n = 65280;
    this.arrowHelper = new Uu(t, e, i, n), this.props.config.scene.add(this.arrowHelper);
  }
  // Getters/Setters -----------------------------
  getAnimationPlayer() {
    return this.animationPlayer;
  }
  getMovementComponent() {
    return this.movementComponent;
  }
  getForwardVector() {
    return this.transform.getForwardVector();
  }
  getTransform() {
    return this.transform;
  }
  getRotation() {
    return this.transform.rotation;
  }
  getPosition() {
    return this.transform.position;
  }
  getScale() {
    return this.transform.scale;
  }
  getMeshInstance() {
    return this.meshInstance;
  }
  getScene() {
    return this.scene;
  }
  getIsDebugDraw() {
    return this.debugDraw;
  }
  applyRotation(t) {
    this.transform.applyQuaternion(t);
  }
  lookAt(t) {
    const e = new w().subVectors(t, this.transform.position).normalize(), i = new Q().setFromUnitVectors(
      new w(0, 0, 1),
      e
    );
    this.transform.rotation.copy(i);
  }
};
Vl.DEBUG_DRAW_FWD_VECTOR_Y_OFFSET = 1.5;
let Sy = Vl;
class Ly extends vh {
  constructor(t) {
    super(t), this.charactersData = {}, this.prepareCharactersRequestData = () => {
      const e = /* @__PURE__ */ new Set(), i = [];
      return this.props.configs.forEach((n) => {
        const s = n.slug || "Tamashi-TiAJWr3sWxh79UKd1UDU", r = n.visualStyle, o = `${s}_${r}`;
        e.has(o) || (e.add(o), i.push({
          slug: s,
          visual_style: r
        }));
      }), i;
    }, this.fetchCharactersData = ({ onComplete: e }) => {
      const i = this.prepareCharactersRequestData();
      wy(i).then((n) => {
        this.charactersData = n.response, e();
      }).catch((n) => {
        console.error("Error fetching characters data:", n);
      });
    };
  }
  componentDidMount() {
    this.fetchCharactersData({
      onComplete: () => {
        this.forceUpdate();
      }
    });
  }
  render() {
    return Object.keys(this.charactersData).length === 0 ? null : /* @__PURE__ */ Ia(Yl, { children: this.props.configs.map((t, e) => /* @__PURE__ */ Ia(
      Sy,
      {
        config: {
          scene: t.scene,
          slug: t.slug,
          visualStyle: t.visualStyle,
          position: t.position,
          controller: t.controller,
          useDefaultPlayerController: t.useDefaultPlayerController,
          components: t.components,
          groundLayer: t.groundLayer,
          data: this.charactersData[t.slug] ?? null,
          debugDraw: t.debugDraw
        }
      },
      e
    )) });
  }
}
class Dy extends Sa {
  possessCharacter(t) {
    super.possessCharacter(t);
  }
}
class By extends Hl {
  constructor(t, e = !1) {
    super(), this.patrolPoints = [], this.currentPatrolIndex = 0, this.directionToNextPatrolPoint = new w(), this.waitingTime = 0, this.debugSpheres = [], this.patrolPoints = t, this.debugDraw = e;
  }
  // Lifecycle Methods ---------------------------------
  initialize(t) {
    super.initialize(t), this.animationsToLoad = ["idle", "walkfwd"], t && (this.moveToNextPatrolPoint(), this.debugDrawPatrolPoints());
  }
  update() {
    this.characterInstance && (this.isCharacterAtCurrentPatrolPoint() ? this.handleCharacterAtPatrolPoint() : this.moveCharacterTowardsPatrolPoint());
  }
  handleInput(t) {
  }
  cleanup() {
    this.removeDebugDrawPatrolPoints();
  }
  // Patrol Point Logic ---------------------------------
  isCharacterAtCurrentPatrolPoint() {
    return this.characterInstance ? this.characterInstance.getPosition().distanceTo(this.patrolPoints[this.currentPatrolIndex].position) < 0.5 : !1;
  }
  handleCharacterAtPatrolPoint() {
    var t;
    this.waitingTime <= 0 ? this.moveToNextPatrolPoint() : (this.waitingTime -= 1 / 60, (t = this.animationPlayer) == null || t.play("idle"));
  }
  moveToNextPatrolPoint() {
    const t = this.patrolPoints[this.currentPatrolIndex];
    t.canRandomlySkip && Math.random() > 0.5 ? this.incrementPatrolPointIndex() : (this.waitingTime = this.calculateRandomWaitTime(t), this.incrementPatrolPointIndex()), this.updateDirectionToNextPatrolPoint(), this.rotateCharacterTowardsDirection(this.directionToNextPatrolPoint);
  }
  calculateRandomWaitTime(t) {
    return Hr.randFloat(
      t.minWaitTime,
      t.maxWaitTime
    );
  }
  incrementPatrolPointIndex() {
    this.currentPatrolIndex = (this.currentPatrolIndex + 1) % this.patrolPoints.length;
  }
  // Movement and Rotation ---------------------------------
  moveCharacterTowardsPatrolPoint() {
    var i;
    if (!this.movementComponent)
      return;
    const t = 1, e = this.directionToNextPatrolPoint.clone();
    this.movementComponent.move(e, t), (i = this.animationPlayer) == null || i.play("walkfwd");
  }
  updateDirectionToNextPatrolPoint() {
    const t = this.patrolPoints[this.currentPatrolIndex].position;
    this.characterInstance && this.directionToNextPatrolPoint.copy(t).sub(this.characterInstance.getPosition()).normalize();
  }
  rotateCharacterTowardsDirection(t) {
    var i, n;
    const e = new w().copy(t).add(((i = this.characterInstance) == null ? void 0 : i.getPosition()) || new w());
    (n = this.characterInstance) == null || n.lookAt(e);
  }
  // Debug Drawing ---------------------------------
  debugDrawPatrolPoints() {
    if (this.debugDraw) {
      const t = new qr(0.5), e = new ce({ color: 255 });
      this.patrolPoints.forEach((i) => {
        var s;
        const n = new Se(t, e);
        n.position.copy(i.position), (s = this.characterInstance) == null || s.getScene().add(n), this.debugSpheres.push(n);
      });
    }
  }
  removeDebugDrawPatrolPoints() {
    this.debugDraw && (this.debugSpheres.forEach((t) => {
      var e;
      (e = this.characterInstance) == null || e.getScene().remove(t);
    }), this.debugSpheres = []);
  }
}
class Fy extends ri.Component {
  constructor(t) {
    super(t), this.clock = new Hh(), this.groundLayer = 1, this.isMouseDown = !1, this.lastMousePosition = { x: 0, y: 0 }, this.accumulatedDeltaX = 0, this.accumulatedDeltaY = 0, this.updateFrameId = null, this.handleMouseDown = () => {
      this.isMouseDown = !0;
    }, this.handleMouseUp = () => {
      this.isMouseDown = !1;
    }, this.handleMouseMove = (e) => {
      this.isMouseDown && (this.accumulatedDeltaX += e.clientX - this.lastMousePosition.x, this.accumulatedDeltaY += e.clientY - this.lastMousePosition.y, this.lastMousePosition.x = e.clientX, this.lastMousePosition.y = e.clientY);
    }, this.update = () => {
      if (this.clock.getDelta(), !this.targetTransform)
        return;
      const e = 2e-3, i = 2e-3;
      this.cameraTransform.rotateOnAxis(
        new w(0, 1, 0),
        this.accumulatedDeltaX * e
      ), this.cameraTransform.rotateOnAxis(
        new w(1, 0, 0),
        this.accumulatedDeltaY * i
      ), this.accumulatedDeltaX = 0, this.accumulatedDeltaY = 0;
      const n = this.targetTransform.getForwardVector(), s = 5, r = n.multiplyScalar(-s);
      r.y += 3;
      const o = this.targetTransform.position.clone().add(r);
      this.cameraTransform.position.lerp(o, 0.05), this.camera.position.copy(this.cameraTransform.position), this.camera.rotation.setFromQuaternion(this.cameraTransform.rotation);
      const h = this.targetTransform.position.clone().add(new w(0, 3, 0));
      this.camera.lookAt(h), this.camera.matrixWorldNeedsUpdate = !0, this.updateFrameId = requestAnimationFrame(this.update);
    }, this.cameraTransform = new Ln(), this.targetTransform = t.target || new Ln(), this.groundLayer = t.groundLayer || 1, this.camera = t.camera || new Un(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      1e3
    ), this.cameraTransform.position.set(0, 5, 10), this.camera.layers.enable(this.groundLayer), this.props.onCameraCreated && this.props.onCameraCreated(this.camera);
  }
  componentDidMount() {
    window.addEventListener("mousedown", this.handleMouseDown), window.addEventListener("mouseup", this.handleMouseUp), window.addEventListener("mousemove", this.handleMouseMove), this.update();
  }
  componentWillUnmount() {
    window.removeEventListener("mousedown", this.handleMouseDown), window.removeEventListener("mouseup", this.handleMouseUp), window.removeEventListener("mousemove", this.handleMouseMove), this.updateFrameId !== null && cancelAnimationFrame(this.updateFrameId);
  }
  componentDidUpdate(t) {
    this.props.target !== t.target && (this.targetTransform = this.props.target || new Ln());
  }
  render() {
    return null;
  }
}
export {
  Sy as Character,
  bh as CharacterComponent,
  Ly as Characters,
  At as InputCodes,
  Ey as LocomotionBehaviorModule,
  Dy as NPCController,
  By as NPCPatrolBehaviorModule,
  Ty as PlayerController,
  Fy as ThirdPersonCamera,
  Fn as VisualStyle
};
