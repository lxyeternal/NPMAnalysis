import { UserInput } from '../inputs/user-input';
import { BehaviorModule } from './behavior-module';
import { Character } from '../character/cxyz-character';
export type LocomotionBehaviorInputMapping = {
    moveForward: string;
    toggleRun: string;
    Jump: string;
    leftTurn: string;
    rightTurn: string;
};
export declare class LocomotionBehaviorModule extends BehaviorModule {
    private wasShiftPressed;
    private keyMapping;
    constructor(customKeyMapping?: LocomotionBehaviorInputMapping);
    initialize(characterInstance: Character | null): void;
    update(): void;
    handleInput(input: UserInput): void;
    private handleRunToggle;
    private handleMovement;
    private handleJumpingAnimation;
    private handleWalkingOrRunningAnimation;
    cleanup(): void;
}
