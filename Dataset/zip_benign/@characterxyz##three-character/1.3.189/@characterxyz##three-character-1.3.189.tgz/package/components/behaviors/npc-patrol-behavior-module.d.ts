import { UserInput } from '../inputs/user-input';
import { BehaviorModule } from './behavior-module';
import { Character } from '../character/cxyz-character';
import { PatrolPoint } from '../../types';
export declare class NPCPatrolBehaviorModule extends BehaviorModule {
    private patrolPoints;
    private currentPatrolIndex;
    private directionToNextPatrolPoint;
    private waitingTime;
    private debugSpheres;
    constructor(patrolPoints: PatrolPoint[], debugDraw?: boolean);
    initialize(characterInstance: Character | null): void;
    update(): void;
    handleInput(input: UserInput): void;
    cleanup(): void;
    private isCharacterAtCurrentPatrolPoint;
    private handleCharacterAtPatrolPoint;
    private moveToNextPatrolPoint;
    private calculateRandomWaitTime;
    private incrementPatrolPointIndex;
    private moveCharacterTowardsPatrolPoint;
    private updateDirectionToNextPatrolPoint;
    private rotateCharacterTowardsDirection;
    private debugDrawPatrolPoints;
    private removeDebugDrawPatrolPoints;
}
