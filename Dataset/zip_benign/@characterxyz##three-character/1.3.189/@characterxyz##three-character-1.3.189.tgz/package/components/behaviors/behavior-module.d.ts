import { UserInput } from '../inputs/user-input';
import { Character } from '../character/cxyz-character';
import { AnimationPlayer } from '../character/core/animation-player';
import { MovementComponent } from '../mechanics/movement-component';
export declare abstract class BehaviorModule {
    protected characterInstance: Character | null;
    protected animationPlayer?: AnimationPlayer;
    protected movementComponent?: MovementComponent;
    protected animationsToLoad: string[];
    protected debugDraw: boolean;
    constructor();
    initialize(characterInstance: Character | null): void;
    abstract update(deltaTime: number): void;
    abstract handleInput(input: UserInput): void;
    abstract cleanup(): void;
    protected isCharacterJumping(): boolean;
    protected isCharacterMoving(): boolean;
    getAnimations(): string[];
}
