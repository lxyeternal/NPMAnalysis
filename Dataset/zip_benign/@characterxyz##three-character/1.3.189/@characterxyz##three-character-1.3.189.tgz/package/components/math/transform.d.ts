import * as THREE from 'three';
export declare class Transform {
    position: THREE.Vector3;
    scale: THREE.Vector3;
    rotation: THREE.Quaternion;
    constructor();
    applyMovement(acceleration: THREE.Vector3): void;
    setRotation(rotation: THREE.Quaternion): void;
    distanceTo(point: THREE.Vector3): number;
    dot(vector: THREE.Vector3): number;
    cross(vector: THREE.Vector3): THREE.Vector3;
    applyQuaternion(quaternion: THREE.Quaternion): void;
    setPosition(position: THREE.Vector3): void;
    setPosition(x: number, y: number, z: number): void;
    translate(x: number, y: number, z: number): void;
    rotateOnAxis(axis: THREE.Vector3, angle: number): void;
    scaleUniform(scale: number): void;
    setScale(x: number, y: number, z: number): void;
    getForwardVector(): THREE.Vector3;
}
