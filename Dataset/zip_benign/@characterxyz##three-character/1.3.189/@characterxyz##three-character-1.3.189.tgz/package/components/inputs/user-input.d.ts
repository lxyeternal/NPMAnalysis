export interface UserInput {
    mouseX: number;
    mouseY: number;
    [key: string]: boolean | number | (() => void);
    reset: () => void;
}
export declare function createDefaultUserInput(): UserInput;
