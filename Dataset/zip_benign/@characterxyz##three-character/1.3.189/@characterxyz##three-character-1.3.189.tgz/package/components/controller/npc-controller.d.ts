import Character from '../character/cxyz-character';
import { CharacterController } from './character-controller';
export declare class NPCController extends CharacterController {
    possessCharacter(characterInstance: Character): void;
}
