import Character from '../character/cxyz-character';
import { CharacterController } from './character-controller';
export declare class PlayerController extends CharacterController {
    private userInput;
    constructor();
    update(deltaTime: number): void;
    possessCharacter(characterInstance: Character): void;
    private setupEventListeners;
    private handleKeyDown;
    private handleKeyUp;
}
