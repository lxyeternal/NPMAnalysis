import { BehaviorModule } from '../behaviors/behavior-module';
import Character from '../character/cxyz-character';
export declare class CharacterController {
    protected characterInstance: Character | null;
    protected behaviorModules: BehaviorModule[];
    constructor();
    possessCharacter(characterInstance: Character): void;
    registerModule(behavior: BehaviorModule): void;
    update(deltaTime: number): void;
    cleanup(): void;
    protected intializeBehaviorModules(characterInstance: Character): void;
    getAnimations(): string[];
}
