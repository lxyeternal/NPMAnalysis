import * as THREE from 'three';
type MeshImportCallback = (mesh: THREE.Mesh) => void;
export declare function importMesh(cloudMesh: string, onComplete: MeshImportCallback): void;
export {};
