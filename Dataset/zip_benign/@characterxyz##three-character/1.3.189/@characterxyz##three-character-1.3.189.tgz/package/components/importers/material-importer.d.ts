import * as THREE from 'three';
import { Material } from '../../types';
type ImportMaterialsCallback = (loadedMaterials: Record<string, LoadedMaterial>) => void;
export interface LoadedTexture {
    texture: THREE.Texture;
    intensity?: number;
    color?: string;
}
export interface LoadedMaterial {
    name: string;
    loadedTextures: Record<string, LoadedTexture>;
}
interface ImportMaterialsProps {
    cloudMaterials: Record<string, Material>;
    onComplete?: ImportMaterialsCallback;
}
export declare function importMaterials({ cloudMaterials, onComplete, }: ImportMaterialsProps): void;
export {};
