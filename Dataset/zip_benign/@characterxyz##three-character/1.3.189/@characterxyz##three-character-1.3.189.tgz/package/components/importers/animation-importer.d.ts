import * as THREE from 'three';
import { AnimationAsset } from '../../types';
interface ImportAnimationsProps {
    animationsToLoad: string[];
    animationsAvailable: Record<string, AnimationAsset>;
    onComplete: (clips: Record<string, THREE.AnimationClip>) => void;
}
export declare function importAnimations({ animationsToLoad, animationsAvailable, onComplete, }: ImportAnimationsProps): void;
export {};
