import * as THREE from 'three';
export declare class AnimationPlayer {
    private meshInstance;
    private animationClipsInstance;
    private animationMixer;
    private animationActions;
    private isInitialized;
    private currentAnimation;
    constructor();
    init(meshInstance: THREE.Mesh | null, animationClipsInstance: Record<string, THREE.AnimationClip> | null): void;
    initAndPlayDefault(meshInstance: THREE.Mesh | null, animationClipsInstance: Record<string, THREE.AnimationClip> | null): void;
    private createAnimationActions;
    update(deltaTime: number): void;
    playDefault(): void;
    play(animationName: string, blendDuration?: number): void;
    stop(animationName: string): void;
    getCurrentAnimation(): string | null;
}
