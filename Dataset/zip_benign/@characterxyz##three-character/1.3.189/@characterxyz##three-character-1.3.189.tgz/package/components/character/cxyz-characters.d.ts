import React, { Component } from 'react';
import { VisualStyle, FetchCharactersInput } from '../../types';
import { Vector3, Scene } from 'three';
import { CharacterController } from '../controller/character-controller';
import CharacterComponent from './character-component';
export interface CharacterConfig {
    scene: Scene;
    slug: string;
    visualStyle?: VisualStyle;
    position?: Vector3;
    controller?: CharacterController;
    useDefaultPlayerController?: boolean;
    components?: CharacterComponent[];
    groundLayer?: number;
    debugDraw?: boolean;
}
interface CharactersProps {
    configs: CharacterConfig[];
}
export declare class Characters extends Component<CharactersProps> {
    private charactersData;
    constructor(props: CharactersProps);
    prepareCharactersRequestData: () => FetchCharactersInput[];
    fetchCharactersData: ({ onComplete }: {
        onComplete: () => void;
    }) => void;
    componentDidMount(): void;
    render(): React.JSX.Element | null;
}
export default Characters;
