import * as THREE from 'three';
import { LoadedMaterial } from '../../importers/material-importer';
type MaterialMixerCallback = () => void;
interface MaterialMixerProps {
    meshInstance: THREE.Mesh | null;
    materialsInstance: Record<string, LoadedMaterial> | null;
    onComplete?: MaterialMixerCallback;
}
export declare function mixMaterials({ meshInstance, materialsInstance, onComplete, }: MaterialMixerProps): null;
export {};
