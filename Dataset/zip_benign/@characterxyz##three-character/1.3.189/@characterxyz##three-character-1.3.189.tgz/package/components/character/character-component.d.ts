import { Object3D } from 'three';
export declare abstract class CharacterComponent extends Object3D {
    constructor();
    abstract init(): void;
    abstract update(deltaTime: number): void;
    protected attachToParent(...object: Object3D[]): void;
}
export default CharacterComponent;
