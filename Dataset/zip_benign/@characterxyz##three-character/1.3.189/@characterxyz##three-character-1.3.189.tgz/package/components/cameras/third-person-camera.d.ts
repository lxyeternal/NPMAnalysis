import * as THREE from 'three';
import { Transform } from '../math/transform';
import React from 'react';
interface ThirdPersonCameraProps {
    target: Transform | null | undefined;
    groundLayer?: number;
    camera?: THREE.PerspectiveCamera;
    onCameraCreated?: (camera: THREE.PerspectiveCamera) => void;
}
export declare class ThirdPersonCamera extends React.Component<ThirdPersonCameraProps> {
    private clock;
    private cameraTransform;
    private targetTransform;
    private camera;
    private groundLayer;
    private isMouseDown;
    private lastMousePosition;
    private accumulatedDeltaX;
    private accumulatedDeltaY;
    private updateFrameId;
    constructor(props: ThirdPersonCameraProps);
    componentDidMount(): void;
    componentWillUnmount(): void;
    componentDidUpdate(prevProps: Readonly<ThirdPersonCameraProps>): void;
    handleMouseDown: () => void;
    handleMouseUp: () => void;
    handleMouseMove: (event: MouseEvent) => void;
    update: () => void;
    render(): React.ReactNode | null;
}
export {};
