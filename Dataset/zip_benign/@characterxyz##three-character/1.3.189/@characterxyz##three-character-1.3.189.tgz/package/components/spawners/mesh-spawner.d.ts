import * as THREE from 'three';
type MeshSpawnCallback = (mesh: THREE.Mesh) => void;
interface SpawnMeshProps {
    scene: THREE.Scene;
    mesh: THREE.Mesh | null;
    position: THREE.Vector3;
    onComplete?: MeshSpawnCallback;
}
export declare function spawnMesh({ scene, mesh, position, onComplete, }: SpawnMeshProps): void;
export {};
