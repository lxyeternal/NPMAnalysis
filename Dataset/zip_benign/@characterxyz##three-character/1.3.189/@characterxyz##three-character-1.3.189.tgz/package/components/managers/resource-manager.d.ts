import { LoadedMaterial } from '../importers/material-importer';
import { Material, VisualStyle } from '../../types';
type OnCompleteCallback = (loadedMaterials: Record<string, LoadedMaterial> | undefined) => void;
declare class ResourceManager {
    materialCache: {
        [key: string]: {
            [visualStyle in VisualStyle]?: Record<string, LoadedMaterial>;
        };
    };
    requestQueue: {
        [key: string]: {
            [visualStyle in VisualStyle]?: Promise<Record<string, LoadedMaterial> | undefined>;
        };
    };
    importAndCacheMaterials({ slug, visualStyle, cloudMaterials, onComplete, forceImport, }: {
        slug: string;
        visualStyle: VisualStyle;
        cloudMaterials: Record<string, Material>;
        onComplete?: OnCompleteCallback;
        forceImport?: boolean;
    }): Promise<Record<string, LoadedMaterial> | undefined>;
    getMaterials(slug: string, visualStyle: VisualStyle): Promise<Record<string, LoadedMaterial> | undefined>;
}
declare const resourceManager: ResourceManager;
export default resourceManager;
