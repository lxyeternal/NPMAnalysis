export interface APIRequestResult<T> {
    status: number;
    message: string;
    response: T;
}
export declare enum VisualStyle {
    DETAILED = "detailed",
    MINIFIED = "minified",
    VOXELIZED = "voxelized"
}
export declare enum TerrestrialLocomotionType {
    BIPEDAL = "bipedal",
    QUADRUPEDAL = "quadrupedal",
    TRIPEDAL = "tripedal",
    HEXAPEDAL = "hexapedal",
    OCTOPEDAL = "octopedal",
    DECAPEDAL = "decapedal",
    CENTIPEDES = "centipedes",
    MILLIPEDES = "millipedes",
    NOPEDAL = "nopedal",
    BRACHIATOR = "brachiator",
    FOSSORIAL = "fossorial",
    AQUATIC = "aquatic",
    ABROREAL = "abroreal",
    AVIAN = "avian"
}
export declare enum CharacterSize {
    SMALL = "small",
    NORMAL = "normal",
    LARGE = "large",
    GIANT = "giant",
    MASSIVE = "massive"
}
export interface ImageAttachment {
    original: string;
    thumbnail: string;
}
export interface Cover {
    render_3d_image: ImageAttachment;
    render_3d_motion_image: string;
    render_3d_video: string;
}
export interface Mesh {
    fbx: string;
    glb: string;
    obj: string;
    vox: string;
}
export interface LOD {
    low: string;
    medium: string;
    high: string;
}
export interface ThreeDimensionalAsset {
    fbx: string;
    glb: string;
    obj: string;
}
export interface ColorMapConfig {
    texture_map: LOD;
    flipX: boolean;
    flipY: boolean;
}
export interface EmissiveMapConfig {
    texture_map: string;
    flipX: boolean;
    flipY: boolean;
    emissive_color: string;
    emissive_intensity: number;
}
export interface MetallicMapConfig {
    texture_map: string;
    flipX: boolean;
    flipY: boolean;
    metallicness: number;
}
export interface RoughnessMapConfig {
    texture_map: string;
    flipX: boolean;
    flipY: boolean;
    roughness: number;
}
export interface HeightMapConfig {
    texture_map: string;
    intensity: number;
    flipX: boolean;
    flipY: boolean;
}
export interface AmbientOcclusionMapConfig {
    texture_map: string;
    intensity: number;
    flipX: boolean;
    flipY: boolean;
}
export interface NormalMapConfig {
    texture_map: string;
    flipX: boolean;
    flipY: boolean;
}
export interface AlphaMapConfig {
    texture_map: string;
    flipX: boolean;
    flipY: boolean;
}
export interface Material {
    name: string;
    color_map_config: ColorMapConfig;
    emissive_map_config: EmissiveMapConfig;
    metallic_map_config: MetallicMapConfig;
    roughness_map_config: RoughnessMapConfig;
    ambientocclusion_map_config: AmbientOcclusionMapConfig;
    height_map_config: HeightMapConfig;
    normal_map_config: NormalMapConfig;
    alpha_map_config: AlphaMapConfig;
}
export interface SkinVariation {
    name: string;
    dominant_color: string;
    materials: Record<string, Material>;
}
export interface AnimationAsset {
    name: string;
    asset: ThreeDimensionalAsset;
}
export interface Skin {
    name: string;
    image?: string;
    skinned_mesh: Mesh;
    sockets: Record<string, string>;
    skin_variations: SkinVariation[];
    animations: Record<string, AnimationAsset>;
    poster: ImageAttachment;
}
export interface SkinGroup {
    name: string;
    skins: Skin[];
}
export declare enum AgeUsageStandard {
    EVERYONE = "everyone",
    EARLY_CHILDHOOD = "early_childhood",
    EVERYONE_TEN_PLUS = "everyone_ten_plus",
    TEEN = "teen",
    ADULT = "adult"
}
export interface IPUsageRequirements {
    age_usage_standard: AgeUsageStandard;
    weapons_allowed: boolean;
    blood_allowed: boolean;
}
export declare enum CharacterGeneration {
    I = "1",
    II = "2",
    III = "3",
    IV = "4"
}
export declare enum CharacterStandard {
    CXYZ_CHAR_1 = "cxyz_char_1"
}
export interface FetchCharacterInput {
    slug: string;
    query?: Partial<CharacterQueryOptions>;
}
export interface FetchCharactersInput {
    slug: string;
    visual_style?: VisualStyle;
}
export interface CharacterQueryOptions {
    visual_style?: VisualStyle;
}
export interface Character {
    slug: string;
    name: string;
    class: string;
    terrestrial_locomotion: TerrestrialLocomotionType;
    tags: string[];
    cover: Cover;
    skin_groups: Record<VisualStyle, SkinGroup>;
    character_size: CharacterSize;
    ip_usage_requirements: IPUsageRequirements;
    generation: CharacterGeneration;
    standard: CharacterStandard;
    intellectual_property: string[];
}
export interface PatrolPoint {
    position: THREE.Vector3;
    minWaitTime: number;
    maxWaitTime: number;
    canRandomlySkip: boolean;
}
