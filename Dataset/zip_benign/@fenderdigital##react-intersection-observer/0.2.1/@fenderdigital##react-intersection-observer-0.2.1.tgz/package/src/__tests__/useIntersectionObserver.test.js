import { renderHook } from '@testing-library/react-hooks';
import useIntersectionObserver, {
  defaultOptions,
} from '../useIntersectionObserver';

global.IntersectionObserver = jest.fn();

describe('useIntersectionObserver', () => {
  const element = document.createElement('div');
  element.style.cssText = 'width: 200px; height: 200px';
  const mockTarget = {
    current: element,
  };
  it('should exist', () => expect(useIntersectionObserver).toBeDefined());
  it('should return false', () => {
    IntersectionObserver.mockImplementation(() => ({
      observe: () => {},
      unobserve: () => {},
    }));
    const { result } = renderHook(() =>
      useIntersectionObserver(defaultOptions, mockTarget),
    );
    const { current } = result;
    const [value] = current;
    expect(value).toBe(false);
  });
});
