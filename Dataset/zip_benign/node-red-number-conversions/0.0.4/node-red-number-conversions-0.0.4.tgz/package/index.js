exports.Num = {
	...require("./fn/scale.js"),
	...require("./fn/normalize.js"),
};
