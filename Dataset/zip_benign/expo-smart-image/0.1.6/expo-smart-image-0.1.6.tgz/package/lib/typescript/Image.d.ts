/// <reference types="react" />
import { ImageSourcePropType, ImageURISource, Animated as RNAnimated } from 'react-native';
import type { DownloadOptions } from './CacheManager';
interface LoadingIndicatorStyle {
    backgroundStrokeColor: string;
    strokeColor: string;
    strokeWidth: number;
    size: number;
}
interface ImageProps {
    style?: AdditionalImageStyle;
    loadingIndicatorStyle?: LoadingIndicatorStyle;
    defaultSource?: ImageURISource | number;
    preview?: ImageSourcePropType;
    options?: DownloadOptions;
    uri: string;
    transitionDuration?: number;
    tint?: 'dark' | 'light';
    intensity?: RNAnimated.Value;
    enableZoom?: boolean;
    enableLoadingIndicator?: boolean;
    onError?: (error: {
        nativeEvent: {
            error: Error;
        };
    }) => void;
}
interface AdditionalImageStyle {
    width?: number;
    height?: number;
}
declare const Image: ({ uri, preview, enableZoom, enableLoadingIndicator, loadingIndicatorStyle, style, transitionDuration, intensity, tint, }: ImageProps) => JSX.Element;
export default Image;
