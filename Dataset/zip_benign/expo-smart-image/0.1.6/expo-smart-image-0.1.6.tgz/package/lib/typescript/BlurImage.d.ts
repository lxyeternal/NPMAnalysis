import * as React from 'react';
import { Animated, ImageStyle, ImageURISource, ImageSourcePropType } from 'react-native';
import { DownloadOptions } from './CacheManager';
interface LoadingIndicatorStyle {
    backgroundStrokeColor: string;
    strokeColor: string;
    strokeWidth: number;
    size: number;
}
interface ImageProps {
    style?: ImageStyle;
    defaultSource?: ImageURISource | number;
    preview?: ImageSourcePropType;
    options?: DownloadOptions;
    uri: string | undefined;
    enableLoadingIndicator: boolean;
    loadingIndicatorStyle?: LoadingIndicatorStyle;
    transitionDuration?: number;
    tint?: 'dark' | 'light' | string;
    onError: (error: {
        nativeEvent: {
            error: unknown;
        };
    }) => void;
    intensity?: Animated.Value;
    loadingIndicatorCX?: number;
    loadingIndicatorCY?: number;
}
interface ImageState {
    uri: string | undefined;
    loadProgress: number;
}
export default class BlurImage extends React.Component<ImageProps, ImageState> {
    mounted: boolean;
    static defaultProps: {
        transitionDuration: number;
        tint: string;
        onError: () => void;
    };
    state: {
        uri: undefined;
        intensity: Animated.Value;
        loadProgress: number;
    };
    componentDidMount(): void;
    componentDidUpdate(prevProps: ImageProps, prevState: ImageState): void;
    componentWillUnmount(): void;
    load({ uri, options, onError }: ImageProps): Promise<void>;
    render(): JSX.Element;
}
export {};
