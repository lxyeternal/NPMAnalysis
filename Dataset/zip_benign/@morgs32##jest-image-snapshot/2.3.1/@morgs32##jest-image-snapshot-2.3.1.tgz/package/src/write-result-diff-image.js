/*
 * Copyright (c) 2018 American Express Travel Related Services Company, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

const { PNG } = require('pngjs-nozlib');
const fs = require('fs');
const getStdin = require('get-stdin');

getStdin.buffer().then((buffer) => {
  try {
    const input = JSON.parse(buffer);
    const { imagePath, image } = input;

    image.data = Buffer.from(image.data);

    const pngBuffer = PNG.sync.write(image);
    fs.writeFileSync(imagePath, pngBuffer);
    process.exit(0);
  } catch (error) {
    console.error(error); // eslint-disable-line no-console
    process.exit(1);
  }
});
