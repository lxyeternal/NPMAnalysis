import { AbstractControl, ValidationErrors, Validator, ValidatorFn } from '@angular/forms';
import { OnChanges, SimpleChanges } from '@angular/core';
import { NgbDateStruct } from './ngb-date-struct';
import { NgbCalendar } from './ngb-calendar';
/**
 * A class containing factories for datepicker validator functions:
 * * `NgbDateValidators.minDate(minDate: NgbDateStruct)` - checks that the date is after the min date
 * * `NgbDateValidators.maxDate(maxDate: NgbDateStruct)` - checks that the date is before the max date
 * * `NgbDateValidators.invalidDate(calendar: NgbCalendar)` - checks that the date is valid
 *
 * @since 4.2.0
 */
export declare class NgbDateValidators {
    static minDate(minDate: NgbDateStruct): ValidatorFn;
    static maxDate(maxDate: NgbDateStruct): ValidatorFn;
    static invalidDate(calendar: NgbCalendar): ValidatorFn;
}
/**
 * A directive that adds date validation to all NgbInputDatepicker controls. The directive is provided with the
 * `NG_VALIDATORS` multi-provider list.
 *
 * @since 4.2.0
 */
export declare class NgbInvalidDateValidator implements Validator {
    private _calendar;
    private readonly _validator;
    private _onChange;
    constructor(_calendar: NgbCalendar);
    validate(control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
}
/**
 * A directive that adds min date validation to all NgbInputDatepicker controls with the `minDate` attribute. The
 * directive is provided with the `NG_VALIDATORS` multi-provider list.
 *
 * @since 4.2.0
 */
export declare class NgbMinDateValidator implements Validator, OnChanges {
    private _validator;
    private _onChange;
    minDate: NgbDateStruct;
    ngOnChanges(changes: SimpleChanges): void;
    validate(control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    private _createValidator;
}
/**
 * A directive that adds max date validation to all NgbInputDatepicker controls with the `maxDate` attribute. The
 * directive is provided with the `NG_VALIDATORS` multi-provider list.
 *
 * @since 4.2.0
 */
export declare class NgbMaxDateValidator implements Validator, OnChanges {
    private _validator;
    private _onChange;
    maxDate: NgbDateStruct;
    ngOnChanges(changes: SimpleChanges): void;
    validate(control: AbstractControl): ValidationErrors | null;
    registerOnValidatorChange(fn: () => void): void;
    private _createValidator;
}
