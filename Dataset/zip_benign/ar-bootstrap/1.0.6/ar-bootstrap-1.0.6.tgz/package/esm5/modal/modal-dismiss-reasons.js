/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
/** @enum {number} */
var ModalDismissReasons = {
    BACKDROP_CLICK: 0,
    ESC: 1,
};
export { ModalDismissReasons };
ModalDismissReasons[ModalDismissReasons.BACKDROP_CLICK] = 'BACKDROP_CLICK';
ModalDismissReasons[ModalDismissReasons.ESC] = 'ESC';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibW9kYWwtZGlzbWlzcy1yZWFzb25zLmpzIiwic291cmNlUm9vdCI6Im5nOi8vYXItYm9vdHN0cmFwLyIsInNvdXJjZXMiOlsibW9kYWwvbW9kYWwtZGlzbWlzcy1yZWFzb25zLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7OztJQUNFLGlCQUFjO0lBQ2QsTUFBRyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBlbnVtIE1vZGFsRGlzbWlzc1JlYXNvbnMge1xuICBCQUNLRFJPUF9DTElDSyxcbiAgRVNDXG59XG4iXX0=