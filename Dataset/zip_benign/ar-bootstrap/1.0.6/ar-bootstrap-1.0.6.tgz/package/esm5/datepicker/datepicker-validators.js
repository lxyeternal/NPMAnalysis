/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes,extraRequire,uselessCode} checked by tsc
 */
import { NG_VALIDATORS } from '@angular/forms';
import { Directive, forwardRef, Input } from '@angular/core';
import { NgbDate } from './ngb-date';
import { NgbCalendar } from './ngb-calendar';
/**
 * @param {?} value
 * @return {?}
 */
function isNgbDateStruct(value) {
    return value && value.day && value.month && value.year;
}
/**
 * A class containing factories for datepicker validator functions:
 * * `NgbDateValidators.minDate(minDate: NgbDateStruct)` - checks that the date is after the min date
 * * `NgbDateValidators.maxDate(maxDate: NgbDateStruct)` - checks that the date is before the max date
 * * `NgbDateValidators.invalidDate(calendar: NgbCalendar)` - checks that the date is valid
 *
 * \@since 4.2.0
 */
// @dynamic
var /**
 * A class containing factories for datepicker validator functions:
 * * `NgbDateValidators.minDate(minDate: NgbDateStruct)` - checks that the date is after the min date
 * * `NgbDateValidators.maxDate(maxDate: NgbDateStruct)` - checks that the date is before the max date
 * * `NgbDateValidators.invalidDate(calendar: NgbCalendar)` - checks that the date is valid
 *
 * \@since 4.2.0
 */
// @dynamic
NgbDateValidators = /** @class */ (function () {
    function NgbDateValidators() {
    }
    /**
     * @param {?} minDate
     * @return {?}
     */
    NgbDateValidators.minDate = /**
     * @param {?} minDate
     * @return {?}
     */
    function (minDate) {
        return function (control) {
            if (!isNgbDateStruct(control.value) || !isNgbDateStruct(minDate)) {
                return null;
            }
            /** @type {?} */
            var ngbDate = NgbDate.from(control.value);
            return ngbDate.before(NgbDate.from(minDate)) ? { 'ngbDate': { requiredBefore: minDate } } : null;
        };
    };
    /**
     * @param {?} maxDate
     * @return {?}
     */
    NgbDateValidators.maxDate = /**
     * @param {?} maxDate
     * @return {?}
     */
    function (maxDate) {
        return function (control) {
            if (!isNgbDateStruct(control.value) || !isNgbDateStruct(maxDate)) {
                return null;
            }
            /** @type {?} */
            var ngbDate = NgbDate.from(control.value);
            return ngbDate.after(NgbDate.from(maxDate)) ? { 'ngbDate': { requiredAfter: maxDate } } : null;
        };
    };
    /**
     * @param {?} calendar
     * @return {?}
     */
    NgbDateValidators.invalidDate = /**
     * @param {?} calendar
     * @return {?}
     */
    function (calendar) {
        return function (control) { return calendar.isValid(control.value) ? null : { 'ngbDate': { invalid: control.value } }; };
    };
    return NgbDateValidators;
}());
/**
 * A class containing factories for datepicker validator functions:
 * * `NgbDateValidators.minDate(minDate: NgbDateStruct)` - checks that the date is after the min date
 * * `NgbDateValidators.maxDate(maxDate: NgbDateStruct)` - checks that the date is before the max date
 * * `NgbDateValidators.invalidDate(calendar: NgbCalendar)` - checks that the date is valid
 *
 * \@since 4.2.0
 */
// @dynamic
export { NgbDateValidators };
/**
 * A provider which adds `NgbInvalidDateValidator` to the `NG_VALIDATORS` multi-provider list.
 * @type {?}
 */
var NGB_INVALID_DATE_VALIDATOR = {
    provide: NG_VALIDATORS,
    useExisting: forwardRef(function () { return NgbInvalidDateValidator; }),
    multi: true
};
/**
 * A directive that adds date validation to all NgbInputDatepicker controls. The directive is provided with the
 * `NG_VALIDATORS` multi-provider list.
 *
 * \@since 4.2.0
 */
var NgbInvalidDateValidator = /** @class */ (function () {
    function NgbInvalidDateValidator(_calendar) {
        this._calendar = _calendar;
        this._validator = NgbDateValidators.invalidDate(this._calendar);
    }
    /**
     * @param {?} control
     * @return {?}
     */
    NgbInvalidDateValidator.prototype.validate = /**
     * @param {?} control
     * @return {?}
     */
    function (control) {
        return control.value == null ? null : this._validator(control);
    };
    /**
     * @param {?} fn
     * @return {?}
     */
    NgbInvalidDateValidator.prototype.registerOnValidatorChange = /**
     * @param {?} fn
     * @return {?}
     */
    function (fn) { this._onChange = fn; };
    NgbInvalidDateValidator.decorators = [
        { type: Directive, args: [{
                    selector: 'input[ngbDatepicker][formControlName],input[ngbDatepicker][formControl],input[ngbDatepicker][ngModel]',
                    providers: [NGB_INVALID_DATE_VALIDATOR]
                },] }
    ];
    /** @nocollapse */
    NgbInvalidDateValidator.ctorParameters = function () { return [
        { type: NgbCalendar }
    ]; };
    return NgbInvalidDateValidator;
}());
export { NgbInvalidDateValidator };
if (false) {
    /** @type {?} */
    NgbInvalidDateValidator.prototype._validator;
    /** @type {?} */
    NgbInvalidDateValidator.prototype._onChange;
    /** @type {?} */
    NgbInvalidDateValidator.prototype._calendar;
}
/**
 * A provider which adds `NgbMinDateValidator` to the `NG_VALIDATORS` multi-provider list.
 * @type {?}
 */
var NGB_MIN_DATE_VALIDATOR = {
    provide: NG_VALIDATORS,
    useExisting: forwardRef(function () { return NgbMinDateValidator; }),
    multi: true
};
/**
 * A directive that adds min date validation to all NgbInputDatepicker controls with the `minDate` attribute. The
 * directive is provided with the `NG_VALIDATORS` multi-provider list.
 *
 * \@since 4.2.0
 */
var NgbMinDateValidator = /** @class */ (function () {
    function NgbMinDateValidator() {
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    NgbMinDateValidator.prototype.ngOnChanges = /**
     * @param {?} changes
     * @return {?}
     */
    function (changes) {
        if ('minDate' in changes) {
            this._createValidator();
            if (this._onChange) {
                this._onChange();
            }
        }
    };
    /**
     * @param {?} control
     * @return {?}
     */
    NgbMinDateValidator.prototype.validate = /**
     * @param {?} control
     * @return {?}
     */
    function (control) {
        return this.minDate == null ? null : this._validator(control);
    };
    /**
     * @param {?} fn
     * @return {?}
     */
    NgbMinDateValidator.prototype.registerOnValidatorChange = /**
     * @param {?} fn
     * @return {?}
     */
    function (fn) { this._onChange = fn; };
    /**
     * @return {?}
     */
    NgbMinDateValidator.prototype._createValidator = /**
     * @return {?}
     */
    function () { this._validator = NgbDateValidators.minDate(this.minDate); };
    NgbMinDateValidator.decorators = [
        { type: Directive, args: [{
                    selector: 'input[ngbDatepicker][minDate][formControlName],input[ngbDatepicker][minDate][formControl],input[ngbDatepicker][minDate][ngModel]',
                    providers: [NGB_MIN_DATE_VALIDATOR]
                },] }
    ];
    NgbMinDateValidator.propDecorators = {
        minDate: [{ type: Input }]
    };
    return NgbMinDateValidator;
}());
export { NgbMinDateValidator };
if (false) {
    /** @type {?} */
    NgbMinDateValidator.prototype._validator;
    /** @type {?} */
    NgbMinDateValidator.prototype._onChange;
    /** @type {?} */
    NgbMinDateValidator.prototype.minDate;
}
/**
 * A provider which adds `NgbMaxDateValidator` to the `NG_VALIDATORS` multi-provider list.
 * @type {?}
 */
var NGB_MAX_DATE_VALIDATOR = {
    provide: NG_VALIDATORS,
    useExisting: forwardRef(function () { return NgbMaxDateValidator; }),
    multi: true
};
/**
 * A directive that adds max date validation to all NgbInputDatepicker controls with the `maxDate` attribute. The
 * directive is provided with the `NG_VALIDATORS` multi-provider list.
 *
 * \@since 4.2.0
 */
var NgbMaxDateValidator = /** @class */ (function () {
    function NgbMaxDateValidator() {
    }
    /**
     * @param {?} changes
     * @return {?}
     */
    NgbMaxDateValidator.prototype.ngOnChanges = /**
     * @param {?} changes
     * @return {?}
     */
    function (changes) {
        if ('maxDate' in changes) {
            this._createValidator();
            if (this._onChange) {
                this._onChange();
            }
        }
    };
    /**
     * @param {?} control
     * @return {?}
     */
    NgbMaxDateValidator.prototype.validate = /**
     * @param {?} control
     * @return {?}
     */
    function (control) {
        return this.maxDate == null ? null : this._validator(control);
    };
    /**
     * @param {?} fn
     * @return {?}
     */
    NgbMaxDateValidator.prototype.registerOnValidatorChange = /**
     * @param {?} fn
     * @return {?}
     */
    function (fn) { this._onChange = fn; };
    /**
     * @return {?}
     */
    NgbMaxDateValidator.prototype._createValidator = /**
     * @return {?}
     */
    function () { this._validator = NgbDateValidators.maxDate(this.maxDate); };
    NgbMaxDateValidator.decorators = [
        { type: Directive, args: [{
                    selector: 'input[ngbDatepicker][maxDate][formControlName],input[ngbDatepicker][maxDate][formControl],input[ngbDatepicker][maxDate][ngModel]',
                    providers: [NGB_MAX_DATE_VALIDATOR]
                },] }
    ];
    NgbMaxDateValidator.propDecorators = {
        maxDate: [{ type: Input }]
    };
    return NgbMaxDateValidator;
}());
export { NgbMaxDateValidator };
if (false) {
    /** @type {?} */
    NgbMaxDateValidator.prototype._validator;
    /** @type {?} */
    NgbMaxDateValidator.prototype._onChange;
    /** @type {?} */
    NgbMaxDateValidator.prototype.maxDate;
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZGF0ZXBpY2tlci12YWxpZGF0b3JzLmpzIiwic291cmNlUm9vdCI6Im5nOi8vYXItYm9vdHN0cmFwLyIsInNvdXJjZXMiOlsiZGF0ZXBpY2tlci9kYXRlcGlja2VyLXZhbGlkYXRvcnMudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7OztBQUFBLE9BQU8sRUFBa0IsYUFBYSxFQUEyQyxNQUFNLGdCQUFnQixDQUFDO0FBQ3hHLE9BQU8sRUFBQyxTQUFTLEVBQUUsVUFBVSxFQUFFLEtBQUssRUFBMkMsTUFBTSxlQUFlLENBQUM7QUFFckcsT0FBTyxFQUFDLE9BQU8sRUFBQyxNQUFNLFlBQVksQ0FBQztBQUNuQyxPQUFPLEVBQUMsV0FBVyxFQUFDLE1BQU0sZ0JBQWdCLENBQUM7Ozs7O0FBRTNDLFNBQVMsZUFBZSxDQUFDLEtBQVU7SUFDakMsT0FBTyxLQUFLLElBQUksS0FBSyxDQUFDLEdBQUcsSUFBSSxLQUFLLENBQUMsS0FBSyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDekQsQ0FBQzs7Ozs7Ozs7OztBQVdEOzs7Ozs7Ozs7O0lBQUE7SUF1QkEsQ0FBQzs7Ozs7SUF0QlEseUJBQU87Ozs7SUFBZCxVQUFlLE9BQXNCO1FBQ25DLE9BQU8sVUFBQyxPQUF3QjtZQUM5QixJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsRUFBRTtnQkFDaEUsT0FBTyxJQUFJLENBQUM7YUFDYjs7Z0JBQ0ssT0FBTyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQztZQUMzQyxPQUFPLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFDLFNBQVMsRUFBRSxFQUFDLGNBQWMsRUFBRSxPQUFPLEVBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDL0YsQ0FBQyxDQUFDO0lBQ0osQ0FBQzs7Ozs7SUFDTSx5QkFBTzs7OztJQUFkLFVBQWUsT0FBc0I7UUFDbkMsT0FBTyxVQUFDLE9BQXdCO1lBQzlCLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUNoRSxPQUFPLElBQUksQ0FBQzthQUNiOztnQkFDSyxPQUFPLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFDO1lBQzNDLE9BQU8sT0FBTyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsU0FBUyxFQUFFLEVBQUMsYUFBYSxFQUFFLE9BQU8sRUFBQyxFQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUM3RixDQUFDLENBQUM7SUFDSixDQUFDOzs7OztJQUNNLDZCQUFXOzs7O0lBQWxCLFVBQW1CLFFBQXFCO1FBQ3RDLE9BQU8sVUFBQyxPQUF3QixJQUNsQixPQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUMsU0FBUyxFQUFFLEVBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQyxLQUFLLEVBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3pHLENBQUM7SUFDSCx3QkFBQztBQUFELENBQUMsQUF2QkQsSUF1QkM7Ozs7Ozs7Ozs7Ozs7OztJQUtLLDBCQUEwQixHQUFtQjtJQUNqRCxPQUFPLEVBQUUsYUFBYTtJQUN0QixXQUFXLEVBQUUsVUFBVSxDQUFDLGNBQU0sT0FBQSx1QkFBdUIsRUFBdkIsQ0FBdUIsQ0FBQztJQUN0RCxLQUFLLEVBQUUsSUFBSTtDQUNaOzs7Ozs7O0FBUUQ7SUFPRSxpQ0FBb0IsU0FBc0I7UUFBdEIsY0FBUyxHQUFULFNBQVMsQ0FBYTtRQUFJLElBQUksQ0FBQyxVQUFVLEdBQUcsaUJBQWlCLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUFDLENBQUM7Ozs7O0lBRWhILDBDQUFROzs7O0lBQVIsVUFBUyxPQUF3QjtRQUMvQixPQUFPLE9BQU8sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDakUsQ0FBQzs7Ozs7SUFFRCwyREFBeUI7Ozs7SUFBekIsVUFBMEIsRUFBYyxJQUFVLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQzs7Z0JBYnpFLFNBQVMsU0FBQztvQkFDVCxRQUFRLEVBQUUsdUdBQXVHO29CQUNqSCxTQUFTLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQztpQkFDeEM7Ozs7Z0JBMURPLFdBQVc7O0lBcUVuQiw4QkFBQztDQUFBLEFBZEQsSUFjQztTQVZZLHVCQUF1Qjs7O0lBQ2xDLDZDQUF5Qzs7SUFDekMsNENBQThCOztJQUNsQiw0Q0FBOEI7Ozs7OztJQVl0QyxzQkFBc0IsR0FBbUI7SUFDN0MsT0FBTyxFQUFFLGFBQWE7SUFDdEIsV0FBVyxFQUFFLFVBQVUsQ0FBQyxjQUFNLE9BQUEsbUJBQW1CLEVBQW5CLENBQW1CLENBQUM7SUFDbEQsS0FBSyxFQUFFLElBQUk7Q0FDWjs7Ozs7OztBQVFEO0lBQUE7SUEwQkEsQ0FBQzs7Ozs7SUFoQkMseUNBQVc7Ozs7SUFBWCxVQUFZLE9BQXNCO1FBQ2hDLElBQUksU0FBUyxJQUFJLE9BQU8sRUFBRTtZQUN4QixJQUFJLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUN4QixJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7Z0JBQ2xCLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQzthQUNsQjtTQUNGO0lBQ0gsQ0FBQzs7Ozs7SUFFRCxzQ0FBUTs7OztJQUFSLFVBQVMsT0FBd0I7UUFDL0IsT0FBTyxJQUFJLENBQUMsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO0lBQ2hFLENBQUM7Ozs7O0lBRUQsdURBQXlCOzs7O0lBQXpCLFVBQTBCLEVBQWMsSUFBVSxJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUM7Ozs7SUFFaEUsOENBQWdCOzs7SUFBeEIsY0FBbUMsSUFBSSxDQUFDLFVBQVUsR0FBRyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Z0JBekJoRyxTQUFTLFNBQUM7b0JBQ1QsUUFBUSxFQUNKLGtJQUFrSTtvQkFDdEksU0FBUyxFQUFFLENBQUMsc0JBQXNCLENBQUM7aUJBQ3BDOzs7MEJBS0UsS0FBSzs7SUFpQlIsMEJBQUM7Q0FBQSxBQTFCRCxJQTBCQztTQXJCWSxtQkFBbUI7OztJQUU5Qix5Q0FBZ0M7O0lBQ2hDLHdDQUE4Qjs7SUFDOUIsc0NBQWdDOzs7Ozs7SUFzQjVCLHNCQUFzQixHQUFtQjtJQUM3QyxPQUFPLEVBQUUsYUFBYTtJQUN0QixXQUFXLEVBQUUsVUFBVSxDQUFDLGNBQU0sT0FBQSxtQkFBbUIsRUFBbkIsQ0FBbUIsQ0FBQztJQUNsRCxLQUFLLEVBQUUsSUFBSTtDQUNaOzs7Ozs7O0FBUUQ7SUFBQTtJQTBCQSxDQUFDOzs7OztJQWhCQyx5Q0FBVzs7OztJQUFYLFVBQVksT0FBc0I7UUFDaEMsSUFBSSxTQUFTLElBQUksT0FBTyxFQUFFO1lBQ3hCLElBQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3hCLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtnQkFDbEIsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDO2FBQ2xCO1NBQ0Y7SUFDSCxDQUFDOzs7OztJQUVELHNDQUFROzs7O0lBQVIsVUFBUyxPQUF3QjtRQUMvQixPQUFPLElBQUksQ0FBQyxPQUFPLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDaEUsQ0FBQzs7Ozs7SUFFRCx1REFBeUI7Ozs7SUFBekIsVUFBMEIsRUFBYyxJQUFVLElBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQzs7OztJQUVoRSw4Q0FBZ0I7OztJQUF4QixjQUFtQyxJQUFJLENBQUMsVUFBVSxHQUFHLGlCQUFpQixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDOztnQkF6QmhHLFNBQVMsU0FBQztvQkFDVCxRQUFRLEVBQ0osa0lBQWtJO29CQUN0SSxTQUFTLEVBQUUsQ0FBQyxzQkFBc0IsQ0FBQztpQkFDcEM7OzswQkFLRSxLQUFLOztJQWlCUiwwQkFBQztDQUFBLEFBMUJELElBMEJDO1NBckJZLG1CQUFtQjs7O0lBRTlCLHlDQUFnQzs7SUFDaEMsd0NBQThCOztJQUM5QixzQ0FBZ0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQge0Fic3RyYWN0Q29udHJvbCwgTkdfVkFMSURBVE9SUywgVmFsaWRhdGlvbkVycm9ycywgVmFsaWRhdG9yLCBWYWxpZGF0b3JGbn0gZnJvbSAnQGFuZ3VsYXIvZm9ybXMnO1xuaW1wb3J0IHtEaXJlY3RpdmUsIGZvcndhcmRSZWYsIElucHV0LCBPbkNoYW5nZXMsIFNpbXBsZUNoYW5nZXMsIFN0YXRpY1Byb3ZpZGVyfSBmcm9tICdAYW5ndWxhci9jb3JlJztcbmltcG9ydCB7TmdiRGF0ZVN0cnVjdH0gZnJvbSAnLi9uZ2ItZGF0ZS1zdHJ1Y3QnO1xuaW1wb3J0IHtOZ2JEYXRlfSBmcm9tICcuL25nYi1kYXRlJztcbmltcG9ydCB7TmdiQ2FsZW5kYXJ9IGZyb20gJy4vbmdiLWNhbGVuZGFyJztcblxuZnVuY3Rpb24gaXNOZ2JEYXRlU3RydWN0KHZhbHVlOiBhbnkpOiBib29sZWFuIHtcbiAgcmV0dXJuIHZhbHVlICYmIHZhbHVlLmRheSAmJiB2YWx1ZS5tb250aCAmJiB2YWx1ZS55ZWFyO1xufVxuXG4vKipcbiAqIEEgY2xhc3MgY29udGFpbmluZyBmYWN0b3JpZXMgZm9yIGRhdGVwaWNrZXIgdmFsaWRhdG9yIGZ1bmN0aW9uczpcbiAqICogYE5nYkRhdGVWYWxpZGF0b3JzLm1pbkRhdGUobWluRGF0ZTogTmdiRGF0ZVN0cnVjdClgIC0gY2hlY2tzIHRoYXQgdGhlIGRhdGUgaXMgYWZ0ZXIgdGhlIG1pbiBkYXRlXG4gKiAqIGBOZ2JEYXRlVmFsaWRhdG9ycy5tYXhEYXRlKG1heERhdGU6IE5nYkRhdGVTdHJ1Y3QpYCAtIGNoZWNrcyB0aGF0IHRoZSBkYXRlIGlzIGJlZm9yZSB0aGUgbWF4IGRhdGVcbiAqICogYE5nYkRhdGVWYWxpZGF0b3JzLmludmFsaWREYXRlKGNhbGVuZGFyOiBOZ2JDYWxlbmRhcilgIC0gY2hlY2tzIHRoYXQgdGhlIGRhdGUgaXMgdmFsaWRcbiAqXG4gKiBAc2luY2UgNC4yLjBcbiAqL1xuLy8gQGR5bmFtaWNcbmV4cG9ydCBjbGFzcyBOZ2JEYXRlVmFsaWRhdG9ycyB7XG4gIHN0YXRpYyBtaW5EYXRlKG1pbkRhdGU6IE5nYkRhdGVTdHJ1Y3QpOiBWYWxpZGF0b3JGbiB7XG4gICAgcmV0dXJuIChjb250cm9sOiBBYnN0cmFjdENvbnRyb2wpOiBWYWxpZGF0aW9uRXJyb3JzIHwgbnVsbCA9PiB7XG4gICAgICBpZiAoIWlzTmdiRGF0ZVN0cnVjdChjb250cm9sLnZhbHVlKSB8fCAhaXNOZ2JEYXRlU3RydWN0KG1pbkRhdGUpKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgY29uc3QgbmdiRGF0ZSA9IE5nYkRhdGUuZnJvbShjb250cm9sLnZhbHVlKTtcbiAgICAgIHJldHVybiBuZ2JEYXRlLmJlZm9yZShOZ2JEYXRlLmZyb20obWluRGF0ZSkpID8geyduZ2JEYXRlJzoge3JlcXVpcmVkQmVmb3JlOiBtaW5EYXRlfX0gOiBudWxsO1xuICAgIH07XG4gIH1cbiAgc3RhdGljIG1heERhdGUobWF4RGF0ZTogTmdiRGF0ZVN0cnVjdCk6IFZhbGlkYXRvckZuIHtcbiAgICByZXR1cm4gKGNvbnRyb2w6IEFic3RyYWN0Q29udHJvbCk6IFZhbGlkYXRpb25FcnJvcnMgfCBudWxsID0+IHtcbiAgICAgIGlmICghaXNOZ2JEYXRlU3RydWN0KGNvbnRyb2wudmFsdWUpIHx8ICFpc05nYkRhdGVTdHJ1Y3QobWF4RGF0ZSkpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICBjb25zdCBuZ2JEYXRlID0gTmdiRGF0ZS5mcm9tKGNvbnRyb2wudmFsdWUpO1xuICAgICAgcmV0dXJuIG5nYkRhdGUuYWZ0ZXIoTmdiRGF0ZS5mcm9tKG1heERhdGUpKSA/IHsnbmdiRGF0ZSc6IHtyZXF1aXJlZEFmdGVyOiBtYXhEYXRlfX0gOiBudWxsO1xuICAgIH07XG4gIH1cbiAgc3RhdGljIGludmFsaWREYXRlKGNhbGVuZGFyOiBOZ2JDYWxlbmRhcik6IFZhbGlkYXRvckZuIHtcbiAgICByZXR1cm4gKGNvbnRyb2w6IEFic3RyYWN0Q29udHJvbCk6IFZhbGlkYXRpb25FcnJvcnMgfFxuICAgICAgICBudWxsID0+IHsgcmV0dXJuIGNhbGVuZGFyLmlzVmFsaWQoY29udHJvbC52YWx1ZSkgPyBudWxsIDogeyduZ2JEYXRlJzoge2ludmFsaWQ6IGNvbnRyb2wudmFsdWV9fTsgfTtcbiAgfVxufVxuXG4vKipcbiAqIEEgcHJvdmlkZXIgd2hpY2ggYWRkcyBgTmdiSW52YWxpZERhdGVWYWxpZGF0b3JgIHRvIHRoZSBgTkdfVkFMSURBVE9SU2AgbXVsdGktcHJvdmlkZXIgbGlzdC5cbiAqL1xuY29uc3QgTkdCX0lOVkFMSURfREFURV9WQUxJREFUT1I6IFN0YXRpY1Byb3ZpZGVyID0ge1xuICBwcm92aWRlOiBOR19WQUxJREFUT1JTLFxuICB1c2VFeGlzdGluZzogZm9yd2FyZFJlZigoKSA9PiBOZ2JJbnZhbGlkRGF0ZVZhbGlkYXRvciksXG4gIG11bHRpOiB0cnVlXG59O1xuXG4vKipcbiAqIEEgZGlyZWN0aXZlIHRoYXQgYWRkcyBkYXRlIHZhbGlkYXRpb24gdG8gYWxsIE5nYklucHV0RGF0ZXBpY2tlciBjb250cm9scy4gVGhlIGRpcmVjdGl2ZSBpcyBwcm92aWRlZCB3aXRoIHRoZVxuICogYE5HX1ZBTElEQVRPUlNgIG11bHRpLXByb3ZpZGVyIGxpc3QuXG4gKlxuICogQHNpbmNlIDQuMi4wXG4gKi9cbkBEaXJlY3RpdmUoe1xuICBzZWxlY3RvcjogJ2lucHV0W25nYkRhdGVwaWNrZXJdW2Zvcm1Db250cm9sTmFtZV0saW5wdXRbbmdiRGF0ZXBpY2tlcl1bZm9ybUNvbnRyb2xdLGlucHV0W25nYkRhdGVwaWNrZXJdW25nTW9kZWxdJyxcbiAgcHJvdmlkZXJzOiBbTkdCX0lOVkFMSURfREFURV9WQUxJREFUT1JdXG59KVxuZXhwb3J0IGNsYXNzIE5nYkludmFsaWREYXRlVmFsaWRhdG9yIGltcGxlbWVudHMgVmFsaWRhdG9yIHtcbiAgcHJpdmF0ZSByZWFkb25seSBfdmFsaWRhdG9yOiBWYWxpZGF0b3JGbjtcbiAgcHJpdmF0ZSBfb25DaGFuZ2U6ICgpID0+IHZvaWQ7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgX2NhbGVuZGFyOiBOZ2JDYWxlbmRhcikgeyB0aGlzLl92YWxpZGF0b3IgPSBOZ2JEYXRlVmFsaWRhdG9ycy5pbnZhbGlkRGF0ZSh0aGlzLl9jYWxlbmRhcik7IH1cblxuICB2YWxpZGF0ZShjb250cm9sOiBBYnN0cmFjdENvbnRyb2wpOiBWYWxpZGF0aW9uRXJyb3JzIHwgbnVsbCB7XG4gICAgcmV0dXJuIGNvbnRyb2wudmFsdWUgPT0gbnVsbCA/IG51bGwgOiB0aGlzLl92YWxpZGF0b3IoY29udHJvbCk7XG4gIH1cblxuICByZWdpc3Rlck9uVmFsaWRhdG9yQ2hhbmdlKGZuOiAoKSA9PiB2b2lkKTogdm9pZCB7IHRoaXMuX29uQ2hhbmdlID0gZm47IH1cbn1cblxuLyoqXG4gKiBBIHByb3ZpZGVyIHdoaWNoIGFkZHMgYE5nYk1pbkRhdGVWYWxpZGF0b3JgIHRvIHRoZSBgTkdfVkFMSURBVE9SU2AgbXVsdGktcHJvdmlkZXIgbGlzdC5cbiAqL1xuY29uc3QgTkdCX01JTl9EQVRFX1ZBTElEQVRPUjogU3RhdGljUHJvdmlkZXIgPSB7XG4gIHByb3ZpZGU6IE5HX1ZBTElEQVRPUlMsXG4gIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IE5nYk1pbkRhdGVWYWxpZGF0b3IpLFxuICBtdWx0aTogdHJ1ZVxufTtcblxuLyoqXG4gKiBBIGRpcmVjdGl2ZSB0aGF0IGFkZHMgbWluIGRhdGUgdmFsaWRhdGlvbiB0byBhbGwgTmdiSW5wdXREYXRlcGlja2VyIGNvbnRyb2xzIHdpdGggdGhlIGBtaW5EYXRlYCBhdHRyaWJ1dGUuIFRoZVxuICogZGlyZWN0aXZlIGlzIHByb3ZpZGVkIHdpdGggdGhlIGBOR19WQUxJREFUT1JTYCBtdWx0aS1wcm92aWRlciBsaXN0LlxuICpcbiAqIEBzaW5jZSA0LjIuMFxuICovXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6XG4gICAgICAnaW5wdXRbbmdiRGF0ZXBpY2tlcl1bbWluRGF0ZV1bZm9ybUNvbnRyb2xOYW1lXSxpbnB1dFtuZ2JEYXRlcGlja2VyXVttaW5EYXRlXVtmb3JtQ29udHJvbF0saW5wdXRbbmdiRGF0ZXBpY2tlcl1bbWluRGF0ZV1bbmdNb2RlbF0nLFxuICBwcm92aWRlcnM6IFtOR0JfTUlOX0RBVEVfVkFMSURBVE9SXVxufSlcbmV4cG9ydCBjbGFzcyBOZ2JNaW5EYXRlVmFsaWRhdG9yIGltcGxlbWVudHMgVmFsaWRhdG9yLFxuICAgIE9uQ2hhbmdlcyB7XG4gIHByaXZhdGUgX3ZhbGlkYXRvcjogVmFsaWRhdG9yRm47XG4gIHByaXZhdGUgX29uQ2hhbmdlOiAoKSA9PiB2b2lkO1xuICBASW5wdXQoKSBtaW5EYXRlOiBOZ2JEYXRlU3RydWN0O1xuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XG4gICAgaWYgKCdtaW5EYXRlJyBpbiBjaGFuZ2VzKSB7XG4gICAgICB0aGlzLl9jcmVhdGVWYWxpZGF0b3IoKTtcbiAgICAgIGlmICh0aGlzLl9vbkNoYW5nZSkge1xuICAgICAgICB0aGlzLl9vbkNoYW5nZSgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHZhbGlkYXRlKGNvbnRyb2w6IEFic3RyYWN0Q29udHJvbCk6IFZhbGlkYXRpb25FcnJvcnMgfCBudWxsIHtcbiAgICByZXR1cm4gdGhpcy5taW5EYXRlID09IG51bGwgPyBudWxsIDogdGhpcy5fdmFsaWRhdG9yKGNvbnRyb2wpO1xuICB9XG5cbiAgcmVnaXN0ZXJPblZhbGlkYXRvckNoYW5nZShmbjogKCkgPT4gdm9pZCk6IHZvaWQgeyB0aGlzLl9vbkNoYW5nZSA9IGZuOyB9XG5cbiAgcHJpdmF0ZSBfY3JlYXRlVmFsaWRhdG9yKCk6IHZvaWQgeyB0aGlzLl92YWxpZGF0b3IgPSBOZ2JEYXRlVmFsaWRhdG9ycy5taW5EYXRlKHRoaXMubWluRGF0ZSk7IH1cbn1cblxuLyoqXG4gKiBBIHByb3ZpZGVyIHdoaWNoIGFkZHMgYE5nYk1heERhdGVWYWxpZGF0b3JgIHRvIHRoZSBgTkdfVkFMSURBVE9SU2AgbXVsdGktcHJvdmlkZXIgbGlzdC5cbiAqL1xuY29uc3QgTkdCX01BWF9EQVRFX1ZBTElEQVRPUjogU3RhdGljUHJvdmlkZXIgPSB7XG4gIHByb3ZpZGU6IE5HX1ZBTElEQVRPUlMsXG4gIHVzZUV4aXN0aW5nOiBmb3J3YXJkUmVmKCgpID0+IE5nYk1heERhdGVWYWxpZGF0b3IpLFxuICBtdWx0aTogdHJ1ZVxufTtcblxuLyoqXG4gKiBBIGRpcmVjdGl2ZSB0aGF0IGFkZHMgbWF4IGRhdGUgdmFsaWRhdGlvbiB0byBhbGwgTmdiSW5wdXREYXRlcGlja2VyIGNvbnRyb2xzIHdpdGggdGhlIGBtYXhEYXRlYCBhdHRyaWJ1dGUuIFRoZVxuICogZGlyZWN0aXZlIGlzIHByb3ZpZGVkIHdpdGggdGhlIGBOR19WQUxJREFUT1JTYCBtdWx0aS1wcm92aWRlciBsaXN0LlxuICpcbiAqIEBzaW5jZSA0LjIuMFxuICovXG5ARGlyZWN0aXZlKHtcbiAgc2VsZWN0b3I6XG4gICAgICAnaW5wdXRbbmdiRGF0ZXBpY2tlcl1bbWF4RGF0ZV1bZm9ybUNvbnRyb2xOYW1lXSxpbnB1dFtuZ2JEYXRlcGlja2VyXVttYXhEYXRlXVtmb3JtQ29udHJvbF0saW5wdXRbbmdiRGF0ZXBpY2tlcl1bbWF4RGF0ZV1bbmdNb2RlbF0nLFxuICBwcm92aWRlcnM6IFtOR0JfTUFYX0RBVEVfVkFMSURBVE9SXVxufSlcbmV4cG9ydCBjbGFzcyBOZ2JNYXhEYXRlVmFsaWRhdG9yIGltcGxlbWVudHMgVmFsaWRhdG9yLFxuICAgIE9uQ2hhbmdlcyB7XG4gIHByaXZhdGUgX3ZhbGlkYXRvcjogVmFsaWRhdG9yRm47XG4gIHByaXZhdGUgX29uQ2hhbmdlOiAoKSA9PiB2b2lkO1xuICBASW5wdXQoKSBtYXhEYXRlOiBOZ2JEYXRlU3RydWN0O1xuICBuZ09uQ2hhbmdlcyhjaGFuZ2VzOiBTaW1wbGVDaGFuZ2VzKTogdm9pZCB7XG4gICAgaWYgKCdtYXhEYXRlJyBpbiBjaGFuZ2VzKSB7XG4gICAgICB0aGlzLl9jcmVhdGVWYWxpZGF0b3IoKTtcbiAgICAgIGlmICh0aGlzLl9vbkNoYW5nZSkge1xuICAgICAgICB0aGlzLl9vbkNoYW5nZSgpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHZhbGlkYXRlKGNvbnRyb2w6IEFic3RyYWN0Q29udHJvbCk6IFZhbGlkYXRpb25FcnJvcnMgfCBudWxsIHtcbiAgICByZXR1cm4gdGhpcy5tYXhEYXRlID09IG51bGwgPyBudWxsIDogdGhpcy5fdmFsaWRhdG9yKGNvbnRyb2wpO1xuICB9XG5cbiAgcmVnaXN0ZXJPblZhbGlkYXRvckNoYW5nZShmbjogKCkgPT4gdm9pZCk6IHZvaWQgeyB0aGlzLl9vbkNoYW5nZSA9IGZuOyB9XG5cbiAgcHJpdmF0ZSBfY3JlYXRlVmFsaWRhdG9yKCk6IHZvaWQgeyB0aGlzLl92YWxpZGF0b3IgPSBOZ2JEYXRlVmFsaWRhdG9ycy5tYXhEYXRlKHRoaXMubWF4RGF0ZSk7IH1cbn1cbiJdfQ==