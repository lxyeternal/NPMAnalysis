class BigSet {
    constructor(options = {}) {
        const { setSizeLimit = 14000000 } = options;
        this._sets = [new Set()];
        this._perSetSizeLimit = setSizeLimit;
        this.size = 0;
    }

    has(key) {
        for (const set of this._sets) {
            if (set.has(key)) {
                return true;
            }
        }
        return false;
    }

    add(key) {
        for (const set of this._sets) {
            if (set.has(key)) {
                return this;
            }
        }
        let set = this._sets[this._sets.length - 1];
        if (set.size >= this._perSetSizeLimit) {
            set = new Set();
            this._sets.push(set);
        }
        set.add(key);
        this.size++;
        return this;
    }

    keys() {
        let total = [];
        for (const set of this._sets) {
            for (const key of set) {
                total.push(key)
            }
        }
        return total;
    }
}

module.exports = BigSet;