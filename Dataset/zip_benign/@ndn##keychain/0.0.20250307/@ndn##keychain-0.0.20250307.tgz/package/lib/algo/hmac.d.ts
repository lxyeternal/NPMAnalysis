import type { SigningAlgorithm } from "../key/mod.js";
/** HmacWithSha256 signing algorithm. */
export declare const HMAC: SigningAlgorithm<{}, false, HMAC.GenParams>;
export declare namespace HMAC {
    /** Key generation parameters. */
    interface GenParams {
        /** Import raw key bits instead of generating. */
        importRaw?: Uint8Array;
    }
}
