import type { SigningAlgorithm } from "../key/mod.js";
/** Key generation parameters. */
interface EdGenParams {
    /** Import PKCS#8 private key and SPKI public key instead of generating. */
    importPkcs8?: [pkcs8: Uint8Array, spki: Uint8Array];
}
/** Ed25519 signing algorithm. */
export declare const Ed25519: SigningAlgorithm<{}, true, {}>;
export declare namespace Ed25519 {
    type GenParams = EdGenParams;
}
export {};
