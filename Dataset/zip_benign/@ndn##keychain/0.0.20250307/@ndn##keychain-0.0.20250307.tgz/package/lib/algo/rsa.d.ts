import type { SigningAlgorithm } from "../key/mod.js";
import { type RsaModulusLength } from "./rsa-common.js";
/** Sha256WithRsa signing algorithm. */
export declare const RSA: SigningAlgorithm<{}, true, RSA.GenParams>;
export declare namespace RSA {
    interface GenParams {
        modulusLength?: RsaModulusLength;
        /** Import PKCS#8 private key and SPKI public key instead of generating. */
        importPkcs8?: [pkcs8: Uint8Array, spki: Uint8Array];
    }
}
