import { type AesEncryption, type AesGenParams } from "./aes-common.js";
/**
 * AES-CBC encryption algorithm.
 *
 * @remarks
 * Initialization Vectors must be 16 octets.
 * During encryption, if IV is unspecified, it is randomly generated.
 * During decryption, quality of IV is not checked.
 */
export declare const AESCBC: AesEncryption<{}, AESCBC.GenParams>;
export declare namespace AESCBC {
    interface GenParams extends AesGenParams {
    }
}
