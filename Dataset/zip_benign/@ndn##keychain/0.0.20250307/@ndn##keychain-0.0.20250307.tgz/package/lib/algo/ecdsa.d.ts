import * as asn1 from "@yoursunny/asn1";
import type { SigningAlgorithm } from "../key/mod.js";
declare const PointSizes: {
    readonly "P-256": 32;
    readonly "P-384": 48;
    readonly "P-521": 66;
};
export type EcCurve = keyof typeof PointSizes;
export declare namespace EcCurve {
    const Default: EcCurve;
    const Choices: readonly EcCurve[];
    /** Detect EcCurve from SubjectPublicKeyInfo. */
    function detectFromSpki(der: asn1.ElementBuffer): EcCurve;
}
/** Sha256WithEcdsa signing algorithm. */
export declare const ECDSA: SigningAlgorithm<ECDSA.Info, true, ECDSA.GenParams>;
export declare namespace ECDSA {
    /** Key generation parameters. */
    interface GenParams {
        /**
         * EC curve.
         *
         * @defaultValue
         * During key generation when {@link importPkcs8} is absent, the default is "P-256".
         * During key import when {@link importPkcs8} is specified, this is auto-detected from SPKI.
         */
        curve?: EcCurve;
        /**
         * Import PKCS#8 private key and SPKI public key instead of generating.
         *
         * If {@link curve} is also specified, it must match the SPKI public key.
         */
        importPkcs8?: [pkcs8: Uint8Array, spki: Uint8Array];
    }
    interface Info {
        curve: EcCurve;
    }
}
export {};
