import type { EncryptionAlgorithm } from "../key/mod.js";
import type { RSA } from "./rsa.js";
/** RSA-OAEP encryption algorithm. */
export declare const RSAOAEP: EncryptionAlgorithm<{}, true, RSA.GenParams>;
