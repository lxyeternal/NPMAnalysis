import { Component, type Name } from "@ndn/packet";
/** 'KEY' component. */
export declare const KEY: Component;
/** Default issuerId. */
export declare const ISSUER_DEFAULT: Component;
/** Self-signed issuerId. */
export declare const ISSUER_SELF: Component;
export interface KeyNameFields {
    subjectName: Name;
    keyId: Component;
}
export interface CertNameFields extends KeyNameFields {
    issuerId: Component;
    version: Component;
    keyName: Name;
}
/** Get subject name from subject name, key name, or certificate name. */
export declare function toSubjectName(name: Name): Name;
/** Determine whether the name is a key name. */
export declare function isKeyName(name: Name): boolean;
/**
 * Parse a key name into fields.
 * @param name - Must be a key name.
 */
export declare function parseKeyName(name: Name): KeyNameFields;
/**
 * Get key name from key name or certificate name.
 *
 * @throws Error
 * Thrown if `name` is neither a key name nor a certificate name.
 */
export declare function toKeyName(name: Name): Name;
/**
 * Create key name from subject name, key name, or certificate name.
 * @param name - Subject name, key name, or certificate name.
 *
 * @remarks
 * If `name` is a subject name, it's concatenated with additional components to make a key name:
 * - *KeyId* component is set to `.opts.keyId`.
 *   If unset, it defaults to TimestampNameComponent of the current timestamp.
 *
 * If `name` is a key name, it is returned unchanged.
 *
 * If `name` is a certificate name, its key name portion is returned.
 */
export declare function makeKeyName(name: Name, opts?: Partial<Pick<KeyNameFields, "keyId">>): Name;
/** Determine whether the name is a certificate name. */
export declare function isCertName(name: Name): boolean;
/**
 * Parse a certificate name into fields.
 * @param name - Must be a certificate name.
 */
export declare function parseCertName(name: Name): CertNameFields;
/**
 * Create certificate name from subject name, key name, or certificate name.
 * @param name - Subject name, key name, or certificate name.
 *
 * @remarks
 * If `name` is a subject name, it's concatenated with additional components to make a certificate name:
 * - *KeyId* component is set to `.opts.keyId`.
 *   If unset, it defaults to the current timestamp.
 *
 * If `name` is a key name, it's concatenated with additional components to make a certificate name:
 * - *KeyId* component is set to `.opts.keyId`.
 *   If unset, it defaults to TimestampNameComponent of the current timestamp.
 * - *IssuerId* component is set to `.opts.issuerId`.
 *   If unset, it defaults to "NDNts".
 * - *Version* component is set to `.opts.version`.
 *   If unset, it defaults to VersionNameComponent of the current timestamp in milliseconds.
 *
 * If `name` is a certificate name, it is returned unchanged.
 */
export declare function makeCertName(name: Name, opts?: Partial<Pick<CertNameFields, "keyId" | "issuerId" | "version">>): Name;
