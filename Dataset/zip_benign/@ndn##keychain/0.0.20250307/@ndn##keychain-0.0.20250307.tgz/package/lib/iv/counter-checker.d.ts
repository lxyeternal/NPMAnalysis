import { IvChecker } from "./checker.js";
import { type CounterIvOptions } from "./counter-common.js";
/**
 * Check Initialization Vectors of fixed+random+counter structure for duplication.
 * @see {@link CounterIvOptions} for expected IV structure.
 */
export declare class CounterIvChecker extends IvChecker {
    constructor(opts: CounterIvChecker.Options);
    private readonly fixedMask;
    private readonly randomMask;
    private readonly counterMask;
    private readonly fixed;
    private readonly requireSameRandom;
    private lastRandom?;
    private readonly ci;
    extract(iv: Uint8Array): {
        fixed: bigint;
        random: bigint;
        counter: bigint;
    };
    protected check(iv: Uint8Array, plaintextLength: number, ciphertextLength: number): void;
}
export declare namespace CounterIvChecker {
    interface Options extends CounterIvOptions {
        /**
         * If true, all IVs must have the same bits in the random portion.
         * @defaultValue false
         */
        requireSameRandom?: boolean;
    }
}
