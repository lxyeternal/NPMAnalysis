import type { NameLike } from "@ndn/packet";
import type { KeyChain } from "../store/mod.js";
import { type NamedSigner, type NamedVerifier, type SigningAlgorithm } from "./types.js";
type SigningOptG<I, Asym extends boolean, G> = {} extends G ? [
    SigningAlgorithm<I, Asym, G>,
    G?
] : [
    SigningAlgorithm<I, Asym, G>,
    G
];
/**
 * Generate a pair of signer and verifier with the default ECDSA signing algorithm.
 * @param name - Key name (used as-is) or subject name (forming key name with random *KeyId*).
 */
export declare function generateSigningKey(name: NameLike): Promise<[NamedSigner.PrivateKey, NamedVerifier.PublicKey]>;
/**
 * Generate a pair of signer and verifier with the default ECDSA signing algorithm, and save to KeyChain.
 * @param keyChain - Target KeyChain.
 * @param name - Key name (used as-is) or subject name (forming key name with random *KeyId*).
 */
export declare function generateSigningKey(keyChain: KeyChain, name: NameLike): Promise<[NamedSigner.PrivateKey, NamedVerifier.PublicKey]>;
/**
 * Generate a pair of signer and verifier.
 * @param name - Key name (used as-is) or subject name (forming key name with random *KeyId*).
 * @param a - Signing algorithm and key generation options.
 */
export declare function generateSigningKey<I, Asym extends boolean, G>(name: NameLike, ...a: SigningOptG<I, Asym, G>): Promise<[NamedSigner<Asym>, NamedVerifier<Asym>]>;
/**
 * Generate a pair of signer and verifier, and save to KeyChain.
 * @param keyChain - Target KeyChain.
 * @param name - Key name (used as-is) or subject name (forming key name with random *KeyId*).
 * @param a - Signing algorithm and key generation options.
 */
export declare function generateSigningKey<I, Asym extends boolean, G>(keyChain: KeyChain, name: NameLike, ...a: SigningOptG<I, Asym, G>): Promise<[NamedSigner<Asym>, NamedVerifier<Asym>]>;
export {};
