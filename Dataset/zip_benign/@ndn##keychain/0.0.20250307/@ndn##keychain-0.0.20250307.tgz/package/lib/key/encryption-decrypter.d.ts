import type { LLDecrypt, Name } from "@ndn/packet";
import { type CryptoAlgorithm, type EncryptionAlgorithm, type NamedDecrypter } from "./types.js";
/**
 * Create a plain decrypter from crypto key.
 * @param algo - Encryption algorithm.
 * @param key - Private key or secret key, which must match `algo`.
 */
export declare function createDecrypter<I>(algo: EncryptionAlgorithm<I>, key: CryptoAlgorithm.PrivateSecretKey<I>): LLDecrypt.Key;
/**
 * Create a named decrypter from crypto key.
 * @param name - Key name.
 * @param algo - Encryption algorithm.
 * @param key - Private key or secret key, which must match `algo`.
 */
export declare function createDecrypter<I, Asym extends boolean>(name: Name, algo: EncryptionAlgorithm<I, Asym>, key: CryptoAlgorithm.PrivateSecretKey<I>): NamedDecrypter<Asym>;
