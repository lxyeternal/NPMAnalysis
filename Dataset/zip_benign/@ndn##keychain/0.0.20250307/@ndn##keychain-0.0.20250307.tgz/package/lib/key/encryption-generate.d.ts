import type { NameLike } from "@ndn/packet";
import type { KeyChain } from "../store/mod.js";
import { type EncryptionAlgorithm, type NamedDecrypter, type NamedEncrypter } from "./types.js";
type EncryptionOptG<I, Asym extends boolean, G> = {} extends G ? [
    EncryptionAlgorithm<I, Asym, G>,
    G?
] : [
    EncryptionAlgorithm<I, Asym, G>,
    G
];
/**
 * Generate a pair of encrypter and decrypter.
 * @param name - Key name (used as-is) or subject name (forming key name with random *KeyId*).
 * @param a - Encryption algorithm and key generation options.
 */
export declare function generateEncryptionKey<I, Asym extends boolean, G>(name: NameLike, ...a: EncryptionOptG<I, Asym, G>): Promise<[NamedEncrypter<Asym>, NamedDecrypter<Asym>]>;
/**
 * Generate a pair of encrypter and decrypter, and save to KeyChain.
 * @param keyChain - Target KeyChain.
 * @param name - Key name (used as-is) or subject name (forming key name with random *KeyId*).
 * @param a - Encryption algorithm and key generation options.
 */
export declare function generateEncryptionKey<I, Asym extends boolean, G>(keyChain: KeyChain, name: NameLike, ...a: EncryptionOptG<I, Asym, G>): Promise<[NamedEncrypter<Asym>, NamedDecrypter<Asym>]>;
export {};
