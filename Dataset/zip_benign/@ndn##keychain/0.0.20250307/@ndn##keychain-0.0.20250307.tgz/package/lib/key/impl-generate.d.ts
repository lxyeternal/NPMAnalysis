import { Name } from "@ndn/packet";
import type { CryptoAlgorithm } from "./types.js";
/**
 * Implementation detail of {@link generateSigningKey} and {@link generateEncryptionKey}.
 * @param defaultAlgo - Default algorithm, required if algorithm may be omitted in `a`.
 * @param a - Tuple of [keyChain?: KeyChain, keyName: NameLike, algo?: Algorithm, genParams?: I].
 */
export declare function generateKeyInternal<Algo extends CryptoAlgorithm>(defaultAlgo: Algo, a: unknown[]): Promise<[Name, Algo, CryptoAlgorithm.GeneratedKeyPair | CryptoAlgorithm.GeneratedSecretKey]>;
