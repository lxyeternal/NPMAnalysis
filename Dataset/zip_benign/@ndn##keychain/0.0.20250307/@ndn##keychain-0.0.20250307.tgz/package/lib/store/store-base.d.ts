import { Name } from "@ndn/packet";
import type { Promisable } from "type-fest";
/**
 * KV store provider where each key is a string.
 *
 * @remarks
 * Function calls are serialized. This does not have to be thread safe.
 */
export interface StoreProvider<T> {
    /**
     * Indicate whether the store provider supports the structured clone algorithm.
     * If false, values must be JSON serializable.
     */
    readonly canSClone: boolean;
    /** List keys. */
    list: () => Promisable<string[]>;
    /** Retrieve value by key. */
    get: (key: string) => Promisable<T>;
    /** Insert key and value. */
    insert: (key: string, value: T) => Promisable<void>;
    /** Erase key. */
    erase: (key: string) => Promisable<void>;
}
/** Memory based KV store provider. */
export declare class MemoryStoreProvider<T> implements StoreProvider<T> {
    readonly canSClone: boolean;
    record: Record<string, T>;
    list(): string[];
    get(key: string): T;
    insert(key: string, value: T): void;
    erase(key: string): void;
}
/**
 * KV store where each key is a Name.
 *
 * @remarks
 * Function calls are serialized. This does not have to be thread safe.
 */
export declare abstract class StoreBase<T> {
    private readonly provider;
    constructor(provider: StoreProvider<T>);
    get canSClone(): boolean;
    /** List item names. */
    list(): Promise<Name[]>;
    /** Erase item by name. */
    erase(name: Name): Promise<void>;
    protected getValue(name: Name): Promise<T>;
    protected insertValue(name: Name, value: T): Promise<void>;
    protected bufferToStorable(input: Uint8Array | string): Uint8Array | string;
}
export declare namespace StoreBase {
    function bufferFromStorable(input: Uint8Array | string): Uint8Array;
}
