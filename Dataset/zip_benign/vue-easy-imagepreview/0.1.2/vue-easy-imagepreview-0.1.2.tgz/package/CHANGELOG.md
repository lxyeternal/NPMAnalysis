# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.1.2](https://github.com/eson-fan/vue-easy-ImagePreview/compare/v0.1.1...v0.1.2) (2021-08-18)


### Features

* 项目初始化 ([56e5dd7](https://github.com/eson-fan/vue-easy-ImagePreview/commit/56e5dd7a2c38ec06f653fc9b61fa127687838f4a))

### 0.1.1 (2021-08-16)
