export declare class RestaurantManagerModule {
}
