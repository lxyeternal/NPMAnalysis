import { JWTTokenInterface, User, UserRegister } from '../restaurant-manager.models';
import { ApiService } from './api.service';
import { BehaviorSubject, Observable } from 'rxjs';
export declare class UserService {
    protected apiService: ApiService;
    static userLogged: BehaviorSubject<boolean>;
    constructor(apiService: ApiService);
    static loadUser(): void;
    private static saveUser;
    private static saveToken;
    update(user: User): Observable<User>;
    assignCompany(companyCode: string): Observable<User>;
    unlinkCompany(): Observable<User>;
    adminLogin(email: string, password: string, deviceId?: string): Observable<JWTTokenInterface>;
    adminLoginAndMe(email: string, password: string, deviceId?: string): Promise<User>;
    loginAndMe(email: string, password: string): Promise<User>;
    registerLoginAndMe(userRegister: UserRegister): Promise<User>;
    logoutAndUnlinkUserLicence(): Promise<any>;
    me(): Observable<User>;
    private login;
    register(userRegister: UserRegister): Observable<User>;
    isLogged(): boolean;
    isLoggedAsProUser(): boolean;
    getUser(): User;
    getUserById(id: string): Observable<User>;
    logout(): void;
}
