import { ApiService } from './api.service';
import { Company } from '../restaurant-manager.models';
import { Observable } from 'rxjs';
export declare class CompanyService {
    private apiService;
    constructor(apiService: ApiService);
    search(searchedCompany: string): Observable<Company[]>;
    get(companyId: string): Observable<Company>;
}
