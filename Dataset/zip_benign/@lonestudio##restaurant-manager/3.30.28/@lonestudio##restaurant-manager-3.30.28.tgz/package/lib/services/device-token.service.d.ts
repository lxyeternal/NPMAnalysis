import { ApiService } from './api.service';
export declare class DeviceTokenService {
    private apiService;
    constructor(apiService: ApiService);
    add(t: string, restaurantId: string): import("rxjs").Observable<any>;
    setDeviceToken(t: string): import("rxjs").Observable<any>;
}
