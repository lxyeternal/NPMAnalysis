import { Observable } from 'rxjs';
import { Product, ProductChoiceGroup } from '../restaurant-manager.models';
import { ApiService } from './api.service';
import { RestaurantService } from './restaurant.service';
export declare class ProductService {
    private apiService;
    private restaurantService;
    constructor(apiService: ApiService, restaurantService: RestaurantService);
    getChoices(restaurantId: string): Observable<ProductChoiceGroup[]>;
    get(productId: string): Observable<Product>;
}
