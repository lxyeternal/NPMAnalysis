import { RestaurantService } from './restaurant.service';
import { ApiService } from './api.service';
import { Session } from '../restaurant-manager.models';
import { Observable } from 'rxjs';
export declare class SessionService {
    protected apiService: ApiService;
    protected restaurantService: RestaurantService;
    constructor(apiService: ApiService, restaurantService: RestaurantService);
    getLastSessionHashes(): Observable<any>;
    openSession(restaurantId: string): Observable<Session>;
    closeSession(restaurantId: string, data: any): Observable<Session>;
    getSessionHash(sessionId: string): Observable<string>;
    getOpenedSession(restaurantId: string): Observable<Session>;
}
