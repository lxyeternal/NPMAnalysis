import { ApiService } from './api.service';
import { PaginatedResult } from '../restaurant-manager.models';
import { Observable } from 'rxjs';
export declare class EntityService {
    private apiService;
    constructor(apiService: ApiService);
    private static convertParams;
    list<T>(entity: string, params: any, type: new (obj: any) => T): Observable<PaginatedResult<T>>;
    getAll<T>(entity: string, params: any, type: new (obj: any) => T): Observable<T[]>;
    getById<T>(entity: string, id: string, type: new (obj: any) => T): Observable<T>;
    update<T>(entity: string, data: any, type: new (obj: any) => T): Observable<T>;
    add<T>(entity: string, data: any, type: new (obj: any) => T): Observable<T>;
    remove(entity: string, id: string): Observable<any>;
    reorder(data: any): Observable<any>;
}
