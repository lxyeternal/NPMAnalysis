import { ApiService } from './api.service';
import { Address } from '../restaurant-manager.models';
import { Observable } from 'rxjs';
export declare class AddressService {
    private apiService;
    constructor(apiService: ApiService);
    update(address: Address): Observable<Address>;
    add(address: Address): Observable<Address>;
    remove(address: Address): Observable<boolean>;
    list(): Observable<Address[]>;
}
