import { Observable } from 'rxjs';
import { AppVersion, ManagerVersion } from '../restaurant-manager.models';
import { ApiService } from './api.service';
export declare class VersionService {
    private apiService;
    constructor(apiService: ApiService);
    getLastAppVersion(): Observable<AppVersion>;
    getLastManagerVersion(): Observable<ManagerVersion>;
}
