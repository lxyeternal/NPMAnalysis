import { ApiService } from './api.service';
export declare class ContactService {
    private apiService;
    constructor(apiService: ApiService);
    sendMessage(contact: any): any;
}
