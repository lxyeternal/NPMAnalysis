import { ApiService } from './api.service';
import { DeliverySlots, NextDeliverySlots, Restaurant } from '../restaurant-manager.models';
import { Observable } from 'rxjs';
export declare class DeliverySlotService {
    private apiService;
    constructor(apiService: ApiService);
    next(restaurant: Restaurant): Observable<NextDeliverySlots>;
    list(restaurant: Restaurant): Observable<DeliverySlots>;
    listStatuses(restaurant: Restaurant): Observable<DeliverySlots>;
    update(deliverySlotId: string, isOpen: boolean): Observable<boolean>;
}
