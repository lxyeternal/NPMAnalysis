import { ApiService } from './api.service';
import { Observable } from 'rxjs';
export declare class StockService {
    private apiService;
    constructor(apiService: ApiService);
    update(data: any): Observable<any>;
}
