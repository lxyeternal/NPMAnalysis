import { Observable } from 'rxjs';
import { ApiService } from './api.service';
import { Widget } from '../restaurant-manager.models';
export declare class WidgetService {
    private apiService;
    constructor(apiService: ApiService);
    getWidgetByRestaurant(restaurantId: string, widgetSlug: string): Observable<Widget>;
}
