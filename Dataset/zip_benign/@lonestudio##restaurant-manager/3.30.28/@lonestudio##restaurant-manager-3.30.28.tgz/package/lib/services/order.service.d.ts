import { ApiService } from './api.service';
import { Order, PaginatedResult, PlaceOrder, Restaurant } from '../restaurant-manager.models';
import { Observable } from 'rxjs';
export declare class OrderService {
    protected apiService: ApiService;
    constructor(apiService: ApiService);
    place(order: PlaceOrder): Observable<Order>;
    assign(id: string): Observable<Order>;
    assigned(): Observable<Order[]>;
    print(ids: string[]): Observable<any>;
    changeOrderStatus(order: Order, status: string): Observable<Order>;
    findCurrentByRestaurant(restaurant: Restaurant, deliverySlot?: string): Observable<Order[]>;
    getOrderById(id: string): Observable<Order>;
    getOrderByRef(ref: string): Observable<Order>;
    getOrdersByIds(restaurantId: string, ids: string[]): Observable<Order[]>;
    getOrdersByRestaurant(restaurantId: string, date: string, page: number, perPage?: number, sessionDate?: string): Observable<PaginatedResult<Order>>;
    list(): Observable<Order[]>;
    getNextSlotsOrders(restaurantId: string, statuses: string[]): Observable<number>;
    getExportData(params: any): Observable<{
        [key: string]: string;
    }[]>;
}
