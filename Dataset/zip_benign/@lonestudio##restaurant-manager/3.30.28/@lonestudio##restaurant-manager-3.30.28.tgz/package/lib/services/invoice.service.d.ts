import { Observable } from 'rxjs';
import { ApiService } from './api.service';
import { InvoiceData } from '../restaurant-manager.models';
export declare class InvoiceService {
    private apiService;
    constructor(apiService: ApiService);
    generate(restaurantId: string, data: InvoiceData): Observable<any>;
}
