import { ApiService } from './api.service';
import { Observable } from 'rxjs';
import { ProductIngredient } from '../restaurant-manager.models';
export declare class IngredientService {
    private apiService;
    constructor(apiService: ApiService);
    list(): Observable<ProductIngredient[]>;
}
