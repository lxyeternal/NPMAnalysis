import { ApiService } from './api.service';
import { License } from '../restaurant-manager.models';
import { Observable } from 'rxjs';
export declare class LicenseService {
    private apiService;
    constructor(apiService: ApiService);
    get(): Observable<License>;
    getById(id: string): Observable<License>;
}
