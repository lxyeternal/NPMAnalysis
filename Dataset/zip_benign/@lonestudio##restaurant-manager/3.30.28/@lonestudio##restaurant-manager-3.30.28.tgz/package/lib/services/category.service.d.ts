import { Category, Restaurant } from '../restaurant-manager.models';
import { Observable } from 'rxjs';
import { RestaurantService } from './restaurant.service';
import { ApiService } from './api.service';
import { MenuDataInterface } from './sync.service';
export declare class CategoryService {
    private apiService;
    private restaurantService;
    private shoppingCart;
    constructor(apiService: ApiService, restaurantService: RestaurantService);
    list(): Observable<Category[]>;
    first(): Observable<Category>;
    buildCategoriesFromMenuData(data: MenuDataInterface, restaurant: Restaurant): Category[];
}
