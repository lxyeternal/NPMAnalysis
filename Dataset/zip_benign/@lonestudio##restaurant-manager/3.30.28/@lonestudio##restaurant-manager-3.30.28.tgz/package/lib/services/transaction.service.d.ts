import { ApiService } from './api.service';
import { Observable } from 'rxjs';
import { Transaction } from '../restaurant-manager.models';
export declare class TransactionService {
    protected apiService: ApiService;
    constructor(apiService: ApiService);
    getTransactionById(id: string): Observable<Transaction>;
    getLatestTransactionByOrderId(id: string): Observable<Transaction>;
    markAsPaid(data: string[]): Observable<any>;
}
