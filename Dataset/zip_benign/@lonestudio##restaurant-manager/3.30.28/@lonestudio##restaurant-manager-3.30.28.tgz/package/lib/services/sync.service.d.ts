import { Menu, Product, ProductChoiceGroup, Stock } from './../restaurant-manager.models';
import { ApiService } from './api.service';
import { Category, Order, Tag, VatRate } from '../restaurant-manager.models';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
export interface MenuDataInterface {
    categories: Category[];
    menus: Menu[];
    products: Product[];
    choices: ProductChoiceGroup[];
    stocks: Stock[];
}
export declare class SyncService {
    private apiService;
    private http;
    constructor(apiService: ApiService, http: HttpClient);
    syncTags(): Observable<Tag[]>;
    syncVats(): Observable<VatRate[]>;
    syncCategories(restaurantId: string): Observable<Category[]>;
    syncMenu(restaurantId: string, filterBy?: 'menu' | 'pos' | 'web'): Promise<MenuDataInterface>;
    syncOrders(orders: Order[], restaurantId: string): Observable<Order[]>;
    getSessionUploadParameters(sessionId: string): Observable<any>;
    uploadSession(url: string, data: any): Observable<Order>;
}
