import { ApiService } from './api.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { NextDeliverySlots, Product, Restaurant, RestaurantStats, Team } from '../restaurant-manager.models';
export declare class RestaurantService {
    protected apiService: ApiService;
    selectedRestaurant: BehaviorSubject<Restaurant>;
    constructor(apiService: ApiService);
    static getFromLocalStorage(): Restaurant;
    save(): void;
    list(): Observable<Restaurant[]>;
    isProductAvailable(product: Product): boolean;
    selectRestaurant(restaurant: Restaurant): void;
    update(restaurantId: string, data: any): Observable<Restaurant>;
    changeStock(restaurantId: string, productId: string, hasStock: boolean): Observable<Restaurant[]>;
    getStats(restaurantId: string, date: string): Observable<RestaurantStats>;
    generateSlots(restaurantId: string): Observable<NextDeliverySlots>;
    /**
    * @deprecated The method should not be used
    */
    getTeams(): Observable<Team[]>;
}
