import { ApiService } from './api.service';
import { Observable } from 'rxjs';
export declare class PasswordService {
    private apiService;
    constructor(apiService: ApiService);
    reset(email: string, method?: string): Observable<any>;
    resetByCode(code: string, password: string): Observable<any>;
    resetPut(id: string, password: string): Observable<any>;
    change(oldPassword: string, newPassword: string): Observable<any>;
}
