import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from '../restaurant-manager.models';
export interface LibConfigurationOptions {
    apiBaseUrl: string;
    imageBaseUrl: string;
    client: string | null;
    platform: string;
}
export declare class LibConfiguration {
    static configuration: LibConfigurationOptions;
    static baseUrl: string;
    static version: string;
    static client: string;
    static conf(configuration: LibConfigurationOptions): void;
    static setClient(client: string): void;
    static apiBaseUrl(): string;
    static imageBaseUrl(): string;
    static imageUrlFromPath(path: string): string;
    static generatePaymentLink(orderId: string): string;
    static generateOrdersPaymentLink(orderIds: string[], paymentMethod: string): string;
}
export declare class ApiService {
    private http;
    static logged: boolean;
    static user: User;
    static token: string;
    constructor(http: HttpClient);
    get<T>(url: string, authenticated?: boolean, client?: boolean): Observable<T>;
    put<T>(url: string, body: any, authenticated?: boolean, client?: boolean): Observable<T>;
    delete<T>(url: string, authenticated?: boolean, client?: boolean): Observable<T>;
    post<T>(url: string, body: any, authenticated?: boolean, client?: boolean): Observable<T>;
}
