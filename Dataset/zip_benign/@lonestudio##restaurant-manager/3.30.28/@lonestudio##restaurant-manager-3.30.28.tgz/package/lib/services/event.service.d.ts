import { ApiService } from './api.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { Event, EventRestaurant } from '../restaurant-manager.models';
export declare class EventService {
    private apiService;
    selectedEvent: BehaviorSubject<Event>;
    constructor(apiService: ApiService);
    static getFromLocalStorage(): Event;
    save(): void;
    list(): Observable<Event[]>;
    selectEvent(event: Event): void;
    getEventRestaurantByRestaurantId(id: string): EventRestaurant;
}
