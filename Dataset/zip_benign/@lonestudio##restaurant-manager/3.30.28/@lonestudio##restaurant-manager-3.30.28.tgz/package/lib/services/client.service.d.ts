import { ApiService } from './api.service';
import { Client, ClientBilling, ClientConfig } from '../restaurant-manager.models';
import { Observable } from 'rxjs';
export declare class ClientService {
    protected apiService: ApiService;
    constructor(apiService: ApiService);
    get(): Observable<Client>;
    getConfig(): Observable<ClientConfig>;
    getBilling(): Observable<ClientBilling>;
}
