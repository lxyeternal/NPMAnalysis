export declare class Extension {
    static readonly EVENTS = "events";
    static readonly GROUPED_PAYMENTS = "grouped_payments";
    static readonly POS = "pos";
    static readonly DELIVERY_TRACKER = "delivery_tracker";
    static readonly SLOTS = "slots";
    static readonly STOCKS = "stocks";
    static readonly CLICK_COLLECT = "click_collect";
    static readonly KITCHEN_PRODUCTION = "kitchen_production";
    static readonly MENU = "menu";
}
export declare abstract class Sortable {
    position: number;
}
export declare const ZONE_OBJECT_TYPES: {
    flowers_pot: {
        slug: string;
        label: string;
        image: string;
    };
    wc: {
        slug: string;
        label: string;
        image: string;
    };
};
export declare const PAYMENT_METHODS: {
    rticket: {
        slug: string;
        label: string;
        shortLabel: string;
        icon: string;
    };
    cash: {
        slug: string;
        label: string;
        shortLabel: string;
        icon: string;
    };
    card: {
        slug: string;
        label: string;
        shortLabel: string;
        icon: string;
    };
    check: {
        slug: string;
        label: string;
        shortLabel: string;
        icon: string;
    };
    account: {
        slug: string;
        label: string;
        shortLabel: string;
        icon: string;
    };
    other: {
        slug: string;
        label: string;
        shortLabel: string;
        icon: string;
    };
};
export declare const ORDER_STATUS: {
    pending: {
        slug: string;
        label: string;
    };
    confirmed: {
        slug: string;
        label: string;
    };
    preparing: {
        slug: string;
        label: string;
    };
    delivering: {
        slug: string;
        label: string;
    };
    done: {
        slug: string;
        label: string;
    };
    cancelled: {
        slug: string;
        label: string;
    };
};
export declare const ORDER_CANCELLATION_REASONS: {
    typing_error: {
        slug: string;
        label: string;
    };
    client_issue: {
        slug: string;
        label: string;
    };
    product_non_available: {
        slug: string;
        label: string;
    };
    other: {
        slug: string;
        label: string;
    };
};
export declare const PERMISSIONS: {
    team: {
        cancel_order: {
            slug: string;
            label: string;
        };
        cancel_transaction: {
            slug: string;
            label: string;
        };
        apply_discount: {
            slug: string;
            label: string;
        };
        show_stats: {
            slug: string;
            label: string;
        };
    };
};
export declare const PRODUCT_DIMENSION_TYPES: {
    unit: {
        slug: string;
        label: string;
    };
    kg: {
        slug: string;
        label: string;
    };
    m: {
        slug: string;
        label: string;
    };
};
export declare const POS_REPORT_ACTIONS: {
    create_order: {
        slug: string;
        label: string;
    };
    cancel_order: {
        slug: string;
        label: string;
    };
    close_order: {
        slug: string;
        label: string;
    };
    cancel_partial_order: {
        slug: string;
        label: string;
    };
    add_order_item: {
        slug: string;
        label: string;
    };
    delete_order_item: {
        slug: string;
        label: string;
    };
    create_transaction: {
        slug: string;
        label: string;
    };
    cancel_transaction: {
        slug: string;
        label: string;
    };
    apply_discount: {
        slug: string;
        label: string;
    };
    cancel_discount: {
        slug: string;
        label: string;
    };
    print_order_ticket: {
        slug: string;
        label: string;
    };
    print_transaction_ticket: {
        slug: string;
        label: string;
    };
    create_z_ticket: {
        slug: string;
        label: string;
    };
    print_z_ticket: {
        slug: string;
        label: string;
    };
    login_employee: {
        slug: string;
        label: string;
    };
    logout_employee: {
        slug: string;
        label: string;
    };
    open_session: {
        slug: string;
        label: string;
    };
    close_session: {
        slug: string;
        label: string;
    };
    open_drawer: {
        slug: string;
        label: string;
    };
    open_table: {
        slug: string;
        label: string;
    };
    close_table: {
        slug: string;
        label: string;
    };
};
export declare const ORDER_STATUS_INFORMATIONS: {
    ROLE_USER: {
        pending: string;
        confirmed: string;
        preparing: string;
        delivering: string;
        picking: string;
        done: string;
        cancelled: string;
    };
    ROLE_DELIVERY: {
        pending: string;
        confirmed: string;
        preparing: string;
        delivering: string;
        done: string;
    };
};
export declare const TRANSACTION_STATUS: {
    pending: {
        slug: string;
        label: string;
    };
    paid: {
        slug: string;
        label: string;
    };
    paid_account: {
        slug: string;
        label: string;
    };
    refused: {
        slug: string;
        label: string;
    };
    cancelled: {
        slug: string;
        label: string;
    };
    refunded: {
        slug: string;
        label: string;
    };
};
export declare const TRANSACTION_STATUS_INFORMATIONS: {
    pending: string;
    paid: string;
    refused: string;
    cancelled: string;
    refunded: string;
};
export declare const USER_ROLES: {
    ROLE_OWNER: string;
    ROLE_SALE: string;
    ROLE_ACCOUNTANT: string;
    ROLE_USER: string;
    ROLE_PRO: string;
    ROLE_DELIVERY: string;
    ROLE_ADMIN: string;
    ROLE_SUPER_ADMIN: string;
    ROLE_CASHIER: string;
};
export declare class AppVersion {
    ios: {
        id: string;
        currentVersion: string;
        requiredVersion: string;
    };
    android: {
        id: string;
        currentVersion: string;
        requiredVersion: string;
    };
    constructor(obj?: any);
}
export declare class ManagerVersion {
    ios: {
        id: string;
        version: string;
    };
    android: {
        id: string;
        version: string;
    };
    constructor(obj?: any);
}
export declare class PaginatedResult<T> {
    items: T[];
    total: number;
    page: number;
    perPage: number;
    pages: number;
    constructor(obj: any, type: new (obj: any) => T);
}
export declare class OrderError {
    static readonly ERROR_NOT_USER = "not_user";
    static readonly ERROR_PRODUCT_STOCK = "product_stock";
    static readonly ERROR_INGREDIENT_STOCK = "ingredient_stock";
    static readonly ERROR_CHOICE_STOCK = "choice_stock";
    static readonly ERROR_DELIVERY_SLOT_INVALID = "delivery_slot_invalid";
    static readonly ERROR_SC_OPTION_STOCK = "sc_option_stock";
    static readonly ERROR_CHOICE_GROUP = "choice_group";
    static readonly ERROR_DELIVERY_NOT_SUPPORTED = "delivery_not_supported";
    static readonly ERROR_PICKUP_NOT_SUPPORTED = "pickup_not_supported";
    static readonly ERROR_MIN_AMOUNT_NOT_REACHED = "min_amount_not_reached";
    code: number;
    error: string;
    message: '';
    data: any;
    products: string[];
    constructor(obj?: any);
}
export declare class Restaurant {
    id: string;
    ref: string;
    name: string;
    address: Address;
    deliveryMinimum: number;
    deliveryPrice: number;
    allowDelivery: boolean;
    allowPickup: boolean;
    minimumTimeBeforeDelivery: number;
    minimumTimeBeforePickup: number;
    deliverySlotDuration: number;
    pickupSlotDuration: number;
    message: any;
    image: string;
    logo: string;
    description: string;
    deliveryZone: {
        lat: number;
        lng: number;
    }[];
    openingHours: Hour[];
    deliveryHours: Hour[];
    orderLimitPerSlot: number;
    phone: string;
    deliverySlotsGenerateDays: number;
    manageStocks: boolean;
    mode: 'test' | 'production';
    constructor(obj?: any);
    toString(): string;
    imageFullUrl(): string;
    logoFullUrl(): string;
}
export declare class RestaurantClosure {
    id: string;
    startsAt: string;
    endsAt: string;
    restaurant: Restaurant;
    constructor(obj?: any);
    formattedStartDate(): string;
    formattedEndDate(): string;
    formattedStartTime(): string;
    formattedEndTime(): string;
}
export declare class RestaurantStats {
    ordersCount: number;
    ordersAmount: number;
    constructor(obj?: any);
}
export declare class Company {
    id: string;
    name: string;
    code: string;
    registrationNumber: string;
    description: string;
    events: EventCompany[];
    address: Address;
    constructor(obj?: any);
    getEventCompany(eventId: string): EventCompany;
}
export declare class Table {
    id: string;
    position: number;
    name: string;
    guestCount: number;
    x: number;
    y: number;
    zone: string;
    constructor(obj?: any);
}
export declare class TableManagement {
    id: string;
    table: string;
    orders: string[];
    order: string;
    guestCount: number;
    open: boolean;
    enabled: boolean;
    constructor(obj?: any);
}
export declare class Zone {
    id: string;
    position: number;
    name: string;
    restaurant: Restaurant;
    tables: Table[];
    objects: ZoneObject[];
    constructor(obj?: any);
}
export declare class ZoneObject {
    type: string;
    x: number;
    y: number;
    constructor(obj?: any);
}
export declare class Employee {
    id: string;
    firstname: string;
    lastname: string;
    pin: string;
    team: Team;
    constructor(obj?: any);
}
export declare class Team {
    id: string;
    name: string;
    permissions: string[];
    restaurant: Restaurant;
    employees: Employee[];
    constructor(obj?: any);
}
export declare class PosReport {
    id: string;
    session: Session | string;
    items: PosReportItem[];
    constructor(obj?: any);
}
export declare class PosReportItem {
    id: string;
    action: string;
    employee: string;
    originEmployee: Employee;
    data: string;
    createdAt: string;
    hash: string;
    constructor(obj?: any);
}
export declare class Tag {
    id: string;
    name: string;
    slug: string;
    constructor(obj?: any);
}
export declare class Address {
    id: string;
    name: string;
    company: string;
    line1: string;
    line2: string;
    zip: string;
    city: string;
    details: string;
    constructor(obj?: any);
    toString(): string;
}
export declare class UserRegister {
    firstname: string;
    lastname: string;
    mobilePhone: string;
    email: string;
    plainPassword: string;
    plainPasswordConfirmation: string;
    companyCode: string;
    constructor();
}
export declare class ClientConfig {
    id: string;
    ticketLogo: string;
    ticketLogoWidth: number;
    ticketLogoHeight: number;
    /** @deprecated */
    appConfiguration: AppConfiguration;
    /** @deprecated */
    websiteConfiguration: WebsiteConfiguration;
    configuration: Configuration;
    cssConfiguration: string;
    termsHtml: string;
    /** @deprecated */
    logo: string;
    /** @deprecated */
    pattern: string;
    constructor(obj?: any);
}
export declare class Configuration {
    banner: {
        text: string;
    };
    extensions: string[];
    shoppingCart: {
        infos: string;
    };
    legalUrl: string;
    paymentMethods: [
        {
            name: string;
            ref: string;
            paymentReturnURL: string;
        }
    ];
    stores: {
        playStore: {
            link: string;
            package: string;
        };
        appStore: {
            link: string;
            package: string;
        };
    };
    socials: [
        {
            link: string;
            icon: string;
        }
    ];
    deliveryInformations: string;
    contact: {
        map: {
            zoom: number;
            center: {
                lat: number;
                lng: number;
            };
            markers: [
                {
                    lat: number;
                    lng: number;
                },
                {
                    lat: number;
                    lng: number;
                }
            ];
        };
    };
    app: {
        statusBarStyle: string;
    };
    website: {
        gtagId: string;
        footer: {
            widget1: string;
            widget2: string;
            photoCredits: {
                link: string;
                name: string;
            };
        };
    };
    gtagId: string;
    constructor(obj?: any);
}
export declare class AppConfiguration extends Configuration {
    headerTheme: string;
    constructor(obj?: any);
}
export declare class WebsiteConfiguration extends Configuration {
    footer: {
        widget1: string;
        widget2: string;
        photoCredits: {
            link: string;
            name: string;
        };
    };
    contact: {
        map: {
            zoom: number;
            center: {
                lat: number;
                lng: number;
            };
            markers: [
                {
                    lat: number;
                    lng: number;
                },
                {
                    lat: number;
                    lng: number;
                }
            ];
        };
    };
    gtagId: string;
    constructor(obj?: any);
}
export declare class Client {
    id: string;
    name: string;
    isActive: boolean;
    ref: string;
    extensions: string[];
    logo: string;
    publicUrl: string;
    paymentMethods: string[];
    vatNumber: string;
    companyNumber: string;
    constructor(obj?: any);
    logoFullUrl(): string;
}
export declare class ClientBilling {
    mmcv: number;
    constructor(obj?: any);
}
export declare class User {
    static roles: {
        [key: string]: any;
    };
    id: string;
    firstname: string;
    lastname: string;
    apiKey: string;
    addresses: Address[];
    mobilePhone: string;
    email: string;
    role: string;
    client: Client;
    company: Company;
    restaurants: Restaurant[];
    plainPassword: string;
    notifyOnRegister: boolean;
    constructor(obj?: any);
    isProUser(): boolean;
    formattedRole(): string;
}
export declare class OrderItemChoice {
    id: string;
    name: string;
    price: number;
    quantity: number;
    constructor(obj?: any);
}
export declare class OrderItemChoiceGroup {
    id: string;
    name: string;
    choices: OrderItemChoice[];
    constructor(obj?: any);
    isSame(cg: OrderItemChoiceGroup): boolean;
}
export declare class Menu {
    id: string;
    name: string;
    price: number;
    restaurants: string[];
    category: string;
    groups: MenuGroup[];
    position: number;
    constructor(obj?: any);
    hasProduct(id: string): boolean;
}
export declare class MenuGroup {
    id: string;
    name: string;
    items: MenuGroupItem[];
    position: number;
    constructor(obj?: any);
    hasProduct(id: string): boolean;
}
export declare class MenuGroupItem {
    id: string;
    price: number;
    product: string;
    position: number;
    constructor(obj?: any);
}
export declare class OrderItem {
    id: string;
    type: 'product' | 'menu' | 'menu_item';
    name: string;
    quantity: number;
    price: number;
    menuItemPrice: number;
    total: number;
    vat: number;
    vatRate: VatRate;
    kitchenItem: boolean;
    choiceGroups: OrderItemChoiceGroup[];
    category: string;
    product: string;
    menu: string;
    originCategory: Category;
    originProduct: Product;
    originMenu: Menu;
    discount: OrderDiscount;
    items: OrderItem[];
    vats: OrderVat[];
    dimensionValue: number;
    dimensionType: string;
    productionNote: string;
    constructor(obj?: any);
    applyDiscount(value: string | number): void;
    removeDiscount(): void;
    recalculateTotals(): void;
    hasTags(): boolean;
    isSame(i: OrderItem): boolean;
    hasSameItems(items: OrderItem[]): boolean;
    hasSameChoiceGroups(choiceGroups: OrderItemChoiceGroup[]): boolean;
}
export declare class OrderOption {
    id: string;
    name: string;
    price: number;
    vat: number;
    quantity: number;
    total: number;
    constructor(obj?: any);
}
export declare class Collection {
    id: string;
    order: string;
    items: CollectionItem[];
    operations: CollectionOperation[];
    transactions: CollectionTransaction[];
    constructor(obj?: any);
    reorderItems(items: OrderItem[]): void;
}
export declare class CollectionItem {
    id: string;
    name: string;
    total: number;
    quantity: number;
    orderItem: OrderItem;
    group: string;
    constructor(obj?: any);
    update(orderItem: OrderItem): void;
}
export declare class CollectionOperation {
    id: string;
    name: string;
    total: number;
    quantity: number;
    type: string;
    orderItems?: OrderItem[];
    group: string;
    division: number;
    constructor(obj?: any);
    hasOrderItem(id: string): boolean;
    hasOrderItemWithDiscount(): boolean;
}
export declare class CollectionTransaction {
    id: string;
    externalId: string;
    ref: string;
    total: number;
    type: string;
    operations: CollectionOperation[];
    status: string;
    constructor(obj?: any);
    hasOrderItem(id: string): boolean;
}
export declare class Production {
    id: string;
    order: string;
    lastAction: string;
    items: ProductionItem[];
    itemsToSend: ProductionItem[];
    itemsComing: ProductionItem[];
    tickets: ProductionTicket[];
    topPriority: number;
    mode: 'auto' | 'manual';
    constructor(obj?: any);
    getLastTicket(exception?: 'itemsToSend' | 'itemsComing' | 'itemsToCancel'): ProductionTicket;
    durationSinceLastAction(): number;
    setOrderItems(items: OrderItem[]): void;
    clearItemLists(): void;
    getTopPriority(): number;
}
export declare class ProductionItem {
    id: string;
    name: string;
    quantity: number;
    orderItem: string;
    originOrderItem: OrderItem;
    constructor(obj?: any);
}
export interface ProductionOrderDataInterface {
    id: string;
    source: string;
    name: string;
    number: string;
    ref: string;
    table: string;
    details: string;
    deliveryMethod: string;
    deliverySlot: string;
    guestCount: number;
}
export declare class ProductionTicket {
    id: string;
    number: string;
    createdAt: string;
    itemsToSend: ProductionItem[];
    itemsComing: ProductionItem[];
    itemsToCancel: ProductionItem[];
    order: string;
    orderData: ProductionOrderDataInterface;
    printer: string;
    copy: boolean;
    constructor(obj?: any);
    formattedType(): string;
    formattedCreatedAt(format?: string): string;
    setOrderItems(items: OrderItem[]): void;
}
export declare class Session {
    id: string;
    openedAt: string;
    closedAt: string;
    type: 'pos';
    hashKey: string;
    firstOrderNumber: number;
    lastOrderNumber: number;
    previousSessionLastOrderNumber: number;
    firstInvoiceNumber: number;
    lastInvoiceNumber: number;
    previousSessionLastInvoiceNumber: number;
    previousSessionLastHash: string;
    uploaded: boolean;
    constructor(obj?: any);
    getNextOrderNumber(): number;
    setOrderNumbers(n: number): void;
    getNextInvoiceNumber(): number;
    setInvoiceNumbers(n: number): void;
    openedAtFormatted(): string;
}
export declare class License {
    id: string;
    ref: string;
    createdAt: string;
    expiresAt: string;
    isEnabled: boolean;
    constructor(obj?: any);
    isValid(): boolean;
    expiresAtFormatted(): string;
}
export declare class TransactionPayment {
    id: string;
    label: string;
    type: string;
    amount: number;
    cashback: number;
    constructor(obj?: any);
    formattedType(): any;
    icon(): any;
}
export declare class Hashes {
    orders: {
        [key: string]: Hash;
    };
    transactions: {
        [key: string]: Hash;
    };
    reportItems: {
        [key: string]: Hash;
    };
    lastOrderHash: Hash;
    lastTransactionHash: Hash;
    lastReportItemHash: Hash;
    constructor(obj?: any);
}
export declare class Hash {
    objectId: string;
    value: string;
    rawValue: string;
    createdAt: string;
    type: 'order' | 'transaction' | 'report_item';
    constructor(obj?: any);
}
export declare class TransactionVat {
    id: string;
    rate: number;
    amount: number;
    baseTotal: number;
    constructor(obj?: any);
}
export declare class TransactionPart {
    id: string;
    amount: number;
    mealsCount: number;
    constructor(obj?: any);
}
export declare class InvoiceData {
    mode: 'send' | 'file';
    customerData?: string;
    transactions: Transaction[];
    details?: boolean;
    mealsCount?: number;
    email: string;
    constructor(obj?: any);
}
export declare class Transaction {
    id: string;
    ref: string;
    number: string;
    externalId: string;
    status: string;
    /**
    * @deprecated
    */
    amount: number;
    currency: number;
    paid: boolean;
    refunded: boolean;
    error: string;
    platform: string;
    items: TransactionItem[];
    paymentMethod: string;
    payments: TransactionPayment[];
    cancellationReason: string;
    createdAt: string;
    vatTotal: number;
    total: number;
    vats: TransactionVat[];
    originalTransaction: string;
    printed: boolean;
    printCount: number;
    order: string;
    invoiceNumber: number;
    invoiceCustomerData: string;
    parts: TransactionPart[];
    user: User;
    note: string;
    constructor(obj?: any);
    formattedStatusInformations(): string;
    formattedCancellationReason(): any;
    statusIcon(): string;
    formattedStatus(): string;
    cancel(): void;
    formattedCreatedAt(format?: string): string;
    recalculateTotals(): void;
    getTotal(): number;
    getPartsTotal(): number;
    canAddPart(amount: number): boolean;
}
export declare class TransactionItem {
    id: string;
    type: string;
    description: string;
    vat: number;
    total: number;
    vats: TransactionVat[];
    price: number;
    quantity: number;
    constructor(obj?: any);
}
export declare class OrderVat {
    id: string;
    rate: number;
    amount: number;
    baseTotal: number;
    constructor(obj?: any);
}
export declare class Order {
    id: string;
    user: string;
    clientEmail: string;
    clientFirstname: string;
    clientLastname: string;
    clientPhoneNumber: string;
    cardDetails: string;
    createdAt: string;
    updatedAt: string;
    billingAddress: Address;
    deliveryAddress: Address;
    deliveryMethod: string;
    deliverySlot: string;
    hasKitchenItems: boolean;
    items: OrderItem[];
    number: string;
    options: OrderOption[];
    paymentStatus: string;
    ref: string;
    restaurant: Restaurant | string;
    status: string;
    total: number;
    transactions: Transaction[];
    vatTotal: number;
    deliveredBy: User;
    paymentMethod: string;
    pickupStall: EventStall;
    deliveryStall: EventStall;
    printed: boolean;
    printCount: number;
    details: string;
    cancellationReason: string;
    vats: OrderVat[];
    source: 'website' | 'app' | 'pos';
    session: string | Session;
    employee: string;
    originEmployee: Employee;
    discount: OrderDiscount;
    synchronized: boolean;
    name: string;
    itemQuantity: number;
    table: string;
    originTable: Table;
    guestCount: number;
    transactionNote: string;
    constructor(obj?: any);
    setItemQuantity(): void;
    formattedCreatedAt(format?: string): string;
    formattedShortCreatedAt(): string;
    formattedTimeCreatedAt(): string;
    formattedDeliverySlot(format?: string): string;
    formattedShortDeliverySlot(): string;
    deliveryTime(): string;
    shortClientName(): string;
    formattedStatus(): string;
    formattedStatusInformations(role?: string): string;
    formatStatus(status: string): string;
    previousStatus(formatted?: boolean): string;
    nextStatus(formatted?: boolean): string;
    statusIcon(): string;
    getPaymentLink(): string;
    getKitchenItems(): OrderItem[];
    canBePaid(): boolean;
    canAddItem(): boolean;
    formattedSource(): string;
    recalculateTotals(): void;
    transactionsTotal(): number;
    totalRemaining(): number;
    getNextTransactionNumber(): string;
    canClose(): boolean;
    canCancel(): boolean;
    hasItemsWithTags(): boolean;
    findCloneItems(item: OrderItem): OrderItem[];
    durationSinceOrderTaken(): number;
}
export declare class OrderDiscount {
    id: string;
    type: 'percent' | 'fixed';
    rate: number;
    amount: number;
    constructor(obj?: any);
}
export declare class PlaceOrder {
    source: string;
    paymentMethod: string;
    deliveryMethod: string;
    deliverySlot: string;
    items: any[];
    options: PlaceOrderOption[];
    restaurant: string;
    details: string;
    billingAddress: string;
    deliveryAddress: string;
    event: string;
    client: PlaceOrderClient;
    constructor(obj?: any);
}
export declare class PlaceOrderOption {
    id: string;
    quantity: number;
    constructor(obj?: any);
}
export declare class PlaceOrderClient {
    firstname: string;
    lastname: string;
    phoneNumber: string;
    email: string;
    billingAddress: Address;
    deliveryAddress: Address;
}
export declare class VatRate {
    id: string;
    name: string;
    rate: number;
    constructor(obj?: any);
}
export declare class ContactModel {
    name: string;
    message: string;
    email: string;
}
export declare class DeliverySlot {
    label: string;
    id: string;
    startsAt: string;
    endsAt: string;
    isOpen: boolean;
    duration: number;
    method: string;
    constructor(obj?: any);
    toString(): string;
    dayFormatted(): string;
    shortDayFormatted(): string;
    fullDateFormatted(): string;
}
export declare class NextDeliverySlots {
    shop: DeliverySlot;
    delivery: DeliverySlot;
    constructor(obj?: any);
}
export declare class DeliverySlots {
    shop: {
        [day: string]: DeliverySlot[];
    };
    delivery: {
        [day: string]: DeliverySlot[];
    };
    constructor(obj?: any);
}
export declare class Hour {
    id: string;
    day: number;
    closingTime: string;
    openingTime: string;
    /**
     * @deprecated Use only closingTime and openingTime on newest versions
     */
    midDayClosingTime: string;
    /**
     * @deprecated Use only closingTime and openingTime on newest versions
     */
    midDayOpeningTime: string;
    constructor(obj?: any);
    getFormattedSlot(format?: string): string;
}
export declare class HourGroup {
    hours: Hour[];
    publicName: string;
    publicDescription: string;
    constructor(obj?: any);
}
export declare class Category {
    id: string;
    name: string;
    slug: string;
    kitchen: boolean;
    products: Product[];
    menus: Menu[];
    ingredients: ProductIngredient[];
    hours: HourGroup[];
    isEnabled: true;
    color: string;
    units: number;
    tags: Tag[];
    productionPriority: number;
    availableOnPos: boolean;
    availableOnWeb: boolean;
    availableOnMenu: boolean;
    vatRate: VatRate;
    canCreateProductOnPos: boolean;
    constructor(obj?: any);
    toString(): string;
    removableIngredients(): ProductIngredient[];
    addableIngredients(): ProductIngredient[];
}
export declare class Stock {
    id: string;
    restaurant: Restaurant;
    hasStock: boolean;
    isEnabled: boolean;
    currentQuantity: number;
    entity: string;
    constructor(obj?: any);
}
export declare class ProductChoice extends Sortable {
    static readonly PRODUCT_CHOICE_TYPE_CUSTOM = "custom";
    static readonly PRODUCT_CHOICE_TYPE_INGREDIENT = "ingredient";
    id: string;
    name: string;
    price: number;
    type: string;
    isEnabled: boolean;
    stocks: Stock[];
    ingredient: ProductIngredient;
    isDefault: boolean;
    constructor(obj?: any);
}
export declare class ProductChoiceGroup extends Sortable {
    id: string;
    name: string;
    maxChoices: number;
    required: boolean;
    minChoices: number;
    useQuantitySelector: boolean;
    choices: ProductChoice[];
    selectorType: string;
    product: string;
    constructor(obj?: any);
}
export declare class ProductIngredient {
    id: string;
    name: string;
    price: number;
    vatRate: VatRate;
    stocks: Stock[];
    isRemovable: boolean;
    isAddable: boolean;
    productCategories: Category[];
    constructor(obj?: any);
}
export declare class ProductAllergen {
    id: string;
    name: string;
    constructor(obj?: any);
}
export declare class Product {
    id: string;
    ref: string;
    name: string;
    image: string;
    description: string;
    price: number;
    vatRate: VatRate;
    allergens: ProductAllergen[];
    stocks: Stock[];
    choiceGroups: ProductChoiceGroup[];
    ingredients: ProductIngredient[];
    canRemoveIngredients: boolean;
    canAddIngredients: boolean;
    category: string;
    originCategory: Category;
    isEnabled: boolean;
    tags: Tag[];
    productionPriority: number;
    position: number;
    availableOnPos: boolean;
    availableOnWeb: boolean;
    availableOnMenu: boolean;
    dimensionType: 'unit' | 'kg' | 'm';
    isOption: boolean;
    color: string;
    constructor(obj?: any);
    formattedName(): string;
    formattedPrice(): number;
    removableIngredients(): ProductIngredient[];
    imageFullUrl(): string;
    hasRequiredConfiguration(): boolean;
    dimensionTypeFormatted(): string;
}
export declare class ShoppingCartOption {
    id: string;
    name: string;
    price: number;
    type: 'quantity' | 'checkbox';
    vatRate: VatRate;
    isEnabled: boolean;
    stocks: Stock[];
    restaurants: Restaurant[];
    maxChoices: number;
    constructor(obj?: any);
}
export declare class ShoppingCartItemProductChoices {
    base: ProductChoiceGroup;
    choices: {
        choice: ProductChoice;
        quantity: number;
    }[];
}
export declare class ShoppingCart {
    id: string;
    items: ShoppingCartItem[];
    unvalidItems: string[];
    createdAt: string;
    constructor(obj?: any);
}
export declare class ShoppingCartItem {
    id: string;
    base: {
        product: Product;
        category: Category;
        quantity: number;
    };
    choiceGroups: {
        [id: string]: ShoppingCartItemProductChoices;
    };
    ingredientsToRemove: ProductIngredient[];
    ingredientsToAdd: ProductIngredient[];
    constructor(obj?: any);
    total(): number;
    vat(): number;
    setQuantity(quantity: number): void;
    getChoiceGroups(): ShoppingCartItemProductChoices[];
}
export interface JWTTokenInterface {
    token: string;
    client?: string;
    tabletId?: string;
}
export interface ErrorInterface {
    message: string;
    error: string;
    code: number;
}
export declare class Widget {
    id: string;
    slug: string;
    type: 'gallery' | 'custom';
    title: string;
    items: WidgetGalleryItem[] | WidgetCustomItem[];
    restaurants: Restaurant[];
    constructor(obj?: any);
}
export declare class WidgetItem {
    id: string;
    image: string;
    position: number;
    constructor(obj?: any);
    imageFullUrl(): string;
}
export declare class WidgetGalleryItem extends WidgetItem {
    type: 'text' | 'image';
    size: 's' | 'm' | 'l';
    constructor(obj?: any);
}
export declare class WidgetGalleryImageItem extends WidgetGalleryItem {
    constructor(obj?: any);
}
export declare class WidgetGalleryTextItem extends WidgetGalleryItem {
    title: string;
    text: string;
    constructor(obj?: any);
}
export declare class WidgetCustomItem extends WidgetItem {
    type: 'custom' | 'product' | 'category';
    title: string;
    text: string;
    constructor(obj?: any);
}
export declare class WidgetCustomCustomItem extends WidgetCustomItem {
    action: 'menu' | null;
    file: string;
    constructor(obj?: any);
    fileFullUrl(): string;
}
export declare class WidgetCustomCategoryItem extends WidgetCustomItem {
    category: Category;
    constructor(obj?: any);
}
export declare class WidgetCustomProductItem extends WidgetCustomItem {
    product: Product;
    constructor(obj?: any);
}
export declare class Event {
    id: string;
    ref: string;
    name: string;
    description: string;
    startsAt: string;
    endsAt: string;
    location: EventLocation;
    eventRestaurants: EventRestaurant[];
    halls: EventHall[];
    image: string;
    logo: string;
    companies: EventCompany[];
    constructor(obj?: any);
    getEventRestaurantByRestaurantId(restaurantId: string): EventRestaurant;
    getEventRestaurantsByHallId(hallId: string): EventRestaurant[];
    formattedDates(): string;
    formattedStartDate(): string;
    formattedEndDate(): string;
    imageFullUrl(): string;
    logoFullUrl(): string;
}
export declare class EventLocation {
    id: string;
    name: string;
    halls: EventHall[];
    constructor(obj?: any);
}
export declare class EventHall {
    id: string;
    name: string;
    constructor(obj?: any);
}
export declare class EventStall {
    id: string;
    hall: EventHall;
    aisle: string;
    number: string;
    constructor(obj?: any);
}
export declare class EventRestaurant {
    id: string;
    restaurant: Restaurant;
    stall: EventStall;
    constructor(obj?: any);
}
export declare class EventCompany {
    id: string;
    event: Event;
    stall: EventStall;
    billedLater: boolean;
    company: Company;
    constructor(obj?: any);
}
