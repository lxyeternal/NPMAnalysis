export declare class Utils {
    static generateId(length: number, timestamp?: boolean): string;
    static combineURLs(urls: string[]): string;
    static getTodayAsString(): string;
    static getDateAsString(date: any): string;
    static toFullDateTime(d: string): string;
    static toShortDateTime(d: string): string;
    static toMediumDate(d: string, format?: string): string;
    static toTime(d: string): string;
    static semanticVersionToNumber(version: string): number;
    static isNumber(value: string | number): boolean;
    static isFloat(value: string | number): boolean;
    static isValidPercent(value: string | number): boolean;
    static camelize(value: string): string;
    static capitalizeFirstLetter(str: string): string;
    static merge(target: any, source: any): any;
}
