import { AbstractControl, FormGroup } from '@angular/forms';
export declare class FormHelper {
    static errors: {
        [key: string]: string;
    };
    static getFirstInvalidControlError(form: FormGroup): string;
    static checkPasswords(plainPassword: AbstractControl, plainPasswordConfirmation: AbstractControl): any;
    static checkFieldValidity(control: AbstractControl, condition: boolean): any;
}
