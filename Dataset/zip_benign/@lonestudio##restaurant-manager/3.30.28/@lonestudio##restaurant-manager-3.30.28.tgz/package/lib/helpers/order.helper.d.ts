export declare class OrderHelper {
    static orderStatuses: {
        [key: string]: any;
    };
    static orderStatusTimeline: string[];
    static getNextTimelineStatuses(status: string): string[];
    static getPreviousTimelineStatuses(status: string): string[];
}
