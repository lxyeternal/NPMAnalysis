import * as moment_ from 'moment';
import * as i1 from '@angular/common/http';
import { HttpHeaders, HttpClient, HttpClientModule } from '@angular/common/http';
import * as i0 from '@angular/core';
import { Injectable, NgModule } from '@angular/core';
import { v4 } from 'uuid';
import { map } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';
import { __awaiter } from 'tslib';
import { CommonModule } from '@angular/common';

const moment$2 = moment_;
class Utils {
    static generateId(length, timestamp = false) {
        let result = '';
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        const charactersLength = characters.length;
        for (let i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        if (timestamp) {
            result += '-' + Date.now().toString(36);
        }
        return result;
    }
    static combineURLs(urls) {
        return urls.join('/').replace(new RegExp('([^:]\\/)\\/+', 'g'), '$1');
    }
    static getTodayAsString() {
        const m = moment$2(new Date());
        return m.format('YYYY-MM-DD');
    }
    static getDateAsString(date) {
        const m = moment$2(date);
        return m.format('YYYY-MM-DD');
    }
    static toFullDateTime(d) {
        const m = moment$2(d);
        return `${m.format('dddd DD MMMM YYYY')} à ${m.format('HH')}h${m.format('mm')}`;
    }
    static toShortDateTime(d) {
        const m = moment$2(d);
        return `${m.format('DD-MM-YYYY')} à ${m.format('HH')}h${m.format('mm')}`;
    }
    static toMediumDate(d, format) {
        return moment$2(d, format).format('dddd DD MMMM');
    }
    static toTime(d) {
        const m = moment$2(d);
        return `${m.format('HH')}h${m.format('mm')}`;
    }
    static semanticVersionToNumber(version) {
        const p = version.split('.');
        return (+p[0] || 0) * 1000000 + (+p[1] || 0) * 10000 + (+p[2] || 0) * 100;
    }
    static isNumber(value) {
        return (new RegExp('^[0-9]+$')).test(value.toString());
    }
    static isFloat(value) {
        return (new RegExp('^([0-9]*[.])?[0-9]+$')).test(value.toString());
    }
    static isValidPercent(value) {
        return (new RegExp('^([0-9]*[.])?[0-9]+%$')).test(value.toString());
    }
    static camelize(value) {
        value = value.replace(/[-_\s.]+(.)?/g, (_, c) => c ? c.toUpperCase() : '');
        return value.substr(0, 1).toLowerCase() + value.substr(1);
    }
    static capitalizeFirstLetter(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
    static merge(target, source) {
        for (const key of Object.keys(source)) {
            if (source[key] instanceof Object) {
                Object.assign(source[key], Utils.merge(target[key], source[key]));
            }
        }
        Object.assign(target || {}, source);
        return target;
    }
}

class LibConfiguration {
    static conf(configuration) {
        LibConfiguration.configuration = configuration;
        LibConfiguration.configuration.client = configuration.client || LibConfiguration.client;
        LibConfiguration.configuration.platform = configuration.platform ? configuration.platform : 'undefined';
        LibConfiguration.baseUrl = configuration.apiBaseUrl.replace('/api', '');
    }
    static setClient(client) {
        LibConfiguration.client = client;
        if (LibConfiguration.configuration) {
            LibConfiguration.configuration.client = client;
        }
    }
    static apiBaseUrl() {
        return Utils.combineURLs([LibConfiguration.configuration.apiBaseUrl, LibConfiguration.configuration.client]);
    }
    static imageBaseUrl() {
        return LibConfiguration.configuration.imageBaseUrl;
    }
    static imageUrlFromPath(path) {
        if (path) {
            return Utils.combineURLs([LibConfiguration.imageBaseUrl(), path]);
        }
        return null;
    }
    static generatePaymentLink(orderId) {
        return Utils.combineURLs([LibConfiguration.apiBaseUrl(), 'orders', orderId, 'pay']);
    }
    static generateOrdersPaymentLink(orderIds, paymentMethod) {
        return Utils.combineURLs([LibConfiguration.apiBaseUrl(), 'payments?orderIds=' + orderIds.join('%3B') + '&paymentMethod=' + paymentMethod]);
    }
}
LibConfiguration.configuration = null;
LibConfiguration.baseUrl = '';
LibConfiguration.version = '3.30.28';
LibConfiguration.client = null;
class ApiService {
    constructor(http) {
        this.http = http;
        const version = localStorage.getItem('rm_version');
        if (LibConfiguration.version !== version) {
            localStorage.setItem('rm_version', LibConfiguration.version);
        }
    }
    get(url, authenticated = false, client = true) {
        let headers = new HttpHeaders();
        if (authenticated && ApiService.logged) {
            headers = headers.append('Authorization', 'Bearer ' + ApiService.token);
        }
        headers = headers.append('Client-Platform', LibConfiguration.configuration.platform);
        const baseUrl = client ? LibConfiguration.apiBaseUrl() : LibConfiguration.baseUrl;
        return this.http.get(Utils.combineURLs([baseUrl, url]), { headers });
    }
    put(url, body, authenticated = false, client = true) {
        let headers = new HttpHeaders();
        if (authenticated && ApiService.logged) {
            headers = headers.append('Authorization', 'Bearer ' + ApiService.token);
        }
        headers = headers.append('Client-Platform', LibConfiguration.configuration.platform);
        const baseUrl = client ? LibConfiguration.apiBaseUrl() : LibConfiguration.baseUrl;
        return this.http.put(Utils.combineURLs([baseUrl, url]), body, { headers });
    }
    delete(url, authenticated = false, client = true) {
        let headers = new HttpHeaders();
        if (authenticated && ApiService.logged) {
            headers = headers.append('Authorization', 'Bearer ' + ApiService.token);
        }
        headers = headers.append('Client-Platform', LibConfiguration.configuration.platform);
        const baseUrl = client ? LibConfiguration.apiBaseUrl() : LibConfiguration.baseUrl;
        return this.http.delete(Utils.combineURLs([baseUrl, url]), { headers });
    }
    post(url, body, authenticated = false, client = true) {
        let headers = new HttpHeaders();
        if (authenticated && ApiService.logged) {
            headers = headers.append('Authorization', 'Bearer ' + ApiService.token);
        }
        headers = headers.append('Client-Platform', LibConfiguration.configuration.platform);
        const baseUrl = client ? LibConfiguration.apiBaseUrl() : LibConfiguration.baseUrl;
        return this.http.post(Utils.combineURLs([baseUrl, url]), body, { headers });
    }
}
ApiService.logged = false;
ApiService.user = null;
ApiService.token = null;
ApiService.ɵprov = i0.ɵɵdefineInjectable({ factory: function ApiService_Factory() { return new ApiService(i0.ɵɵinject(i1.HttpClient)); }, token: ApiService, providedIn: "root" });
ApiService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ApiService.ctorParameters = () => [
    { type: HttpClient }
];

const moment$1 = moment_;
class Extension {
}
Extension.EVENTS = 'events';
Extension.GROUPED_PAYMENTS = 'grouped_payments';
Extension.POS = 'pos';
Extension.DELIVERY_TRACKER = 'delivery_tracker';
Extension.SLOTS = 'slots';
Extension.STOCKS = 'stocks';
Extension.CLICK_COLLECT = "click_collect";
Extension.KITCHEN_PRODUCTION = "kitchen_production";
Extension.MENU = 'menu';
class Sortable {
}
const ZONE_OBJECT_TYPES = {
    flowers_pot: {
        slug: 'flowers_pot',
        label: 'Pot de fleurs',
        image: 'flower1'
    },
    wc: {
        slug: 'wc',
        label: 'WC',
        image: 'badge-wc'
    }
};
const PAYMENT_METHODS = {
    rticket: {
        slug: 'rticket',
        label: 'Ticket restaurant',
        shortLabel: 'Ticket R',
        icon: 'receipt'
    },
    cash: {
        slug: 'cash',
        label: 'Espèces',
        shortLabel: 'Espèces',
        icon: 'coin'
    },
    card: {
        slug: 'card',
        label: 'Carte bancaire',
        shortLabel: 'Carte',
        icon: 'credit-card'
    },
    check: {
        slug: 'check',
        label: 'Chèque',
        shortLabel: 'Chèque',
        icon: 'credit-card-2-front'
    },
    account: {
        slug: 'account',
        label: 'Mise en compte',
        shortLabel: 'Compte',
        icon: 'person'
    },
    other: {
        slug: 'other',
        label: 'Autre',
        shortLabel: 'Autre',
        icon: 'three-dots'
    }
};
const ORDER_STATUS = {
    pending: {
        slug: 'pending',
        label: 'En attente de paiement'
    },
    confirmed: {
        slug: 'confirmed',
        label: 'Confirmée'
    },
    preparing: {
        slug: 'preparing',
        label: 'En cours de préparation'
    },
    delivering: {
        slug: 'delivering',
        label: 'En cours de livraison'
    },
    done: {
        slug: 'done',
        label: 'Terminée'
    },
    cancelled: {
        slug: 'cancelled',
        label: 'Annulée'
    }
};
const ORDER_CANCELLATION_REASONS = {
    typing_error: {
        slug: 'typing_error',
        label: 'Erreur saisie'
    },
    client_issue: {
        slug: 'client_issue',
        label: 'Problème client'
    },
    product_non_available: {
        slug: 'product_non_available',
        label: 'Produit indisponible'
    },
    other: {
        slug: 'other',
        label: 'Autre'
    }
};
const PERMISSIONS = {
    team: {
        cancel_order: {
            slug: 'cancel_order',
            label: 'Annulation commande'
        },
        cancel_transaction: {
            slug: 'cancel_transaction',
            label: 'Annulation transaction'
        },
        apply_discount: {
            slug: 'apply_discount',
            label: 'Application de remise'
        },
        show_stats: {
            slug: 'show_stats',
            label: 'Affichage des statistiques'
        }
    }
};
const PRODUCT_DIMENSION_TYPES = {
    unit: {
        slug: 'unit',
        label: 'Produit à l\'unité'
    },
    kg: {
        slug: 'kg',
        label: 'Produit au poids'
    },
    m: {
        slug: 'unit',
        label: 'Produit au mètre'
    }
};
const POS_REPORT_ACTIONS = {
    create_order: {
        slug: 'create_order',
        label: 'a crée une commande'
    },
    cancel_order: {
        slug: 'cancel_order',
        label: 'a annulé une commande'
    },
    close_order: {
        slug: 'close_order',
        label: 'a clôturé une commande'
    },
    cancel_partial_order: {
        slug: 'cancel_partial_order',
        label: 'a annulé les produits de la commande'
    },
    add_order_item: {
        slug: 'add_order_product',
        label: 'a ajouté un produit'
    },
    delete_order_item: {
        slug: 'delete_order_item',
        label: 'a supprimé un produit'
    },
    create_transaction: {
        slug: 'create_transaction',
        label: 'a crée une transaction'
    },
    cancel_transaction: {
        slug: 'cancel_transaction',
        label: 'a annulé une transaction'
    },
    apply_discount: {
        slug: 'apply_discount',
        label: 'a appliqué une remise'
    },
    cancel_discount: {
        slug: 'cancel_discount',
        label: 'a retiré une remise'
    },
    print_order_ticket: {
        slug: 'print_order_ticket',
        label: 'a imprimé un ticket de commande'
    },
    print_transaction_ticket: {
        slug: 'print_transaction_ticket',
        label: 'a imprimé un ticket de transaction'
    },
    create_z_ticket: {
        slug: 'create_z_ticket',
        label: 'a crée un ticket Z'
    },
    print_z_ticket: {
        slug: 'print_z_ticket',
        label: 'a imprimé un ticket Z'
    },
    login_employee: {
        slug: 'login_employee',
        label: 's\est connecté'
    },
    logout_employee: {
        slug: 'logout_employee',
        label: 's\est déconnecté'
    },
    open_session: {
        slug: 'open_session',
        label: 'a ouvert une session'
    },
    close_session: {
        slug: 'close_session',
        label: 'a clôturé une session'
    },
    open_drawer: {
        slug: 'open_drawer',
        label: 'a ouvert le tiroir caisse'
    },
    open_table: {
        slug: 'open_table',
        label: 'a ouvert une table'
    },
    close_table: {
        slug: 'close_table',
        label: 'a fermé une table'
    }
};
const ORDER_STATUS_INFORMATIONS = {
    ROLE_USER: {
        pending: 'Votre commande n\'est pas validée et est en attente de règlement. Vous pouvez à tout moment la payer au bas de cette page.',
        confirmed: 'Votre commande est validée et va être prise en charge par nos équipes. Merci !',
        preparing: 'Il y a le feu en cuisine. Vous recevrez prochainement une notification quand votre commande sera prête.',
        delivering: 'Votre commande est prête. Vous serez livré dans les prochaines minutes, encore un peu de patience !',
        picking: 'Votre commande est prête. Vous pouvez dès à présent la retirer sur place, encore un petit effort !',
        done: 'Votre commande a été délivrée. Nous espérons que tout s\'est bien passé. Au plaisir de vous revoir.',
        cancelled: 'Votre commande a été annulée.'
    },
    ROLE_DELIVERY: {
        pending: 'La commande n\'est pas validée et est en attente de règlement. Vous ne pouvez actuellement pas la prendre en charge.',
        confirmed: 'La commande est validée et a été envoyée en cuisine. Vous ne pouvez actuellement pas la prendre en charge',
        preparing: 'La commande est en cours de préparation, il y a le feu en cuisine. Tenez-vous prêt pour une prise en charge !',
        delivering: 'Le client a été notifié, on compte sur vous pour une livraison express !',
        done: 'La commande a été annulée'
    }
};
const TRANSACTION_STATUS = {
    pending: {
        slug: 'pending',
        label: 'En attente de paiement'
    },
    paid: {
        slug: 'paid',
        label: 'Paiement effectué'
    },
    paid_account: {
        slug: 'paid_account',
        label: 'Paiement mis en compte'
    },
    refused: {
        slug: 'refused',
        label: 'Paiement refusé'
    },
    cancelled: {
        slug: 'cancelled',
        label: 'Paiement annulé'
    },
    refunded: {
        slug: 'refunded',
        label: 'Paiement remboursé'
    }
};
const TRANSACTION_STATUS_INFORMATIONS = {
    pending: 'Il semblerait que vous ayez quitté le processus de paiement trop tôt. Nous vous recommandons de vérifier une potentielle confirmation dans vos emails (y compris vos spams).',
    paid: 'Merci ! Votre règlement a bien été effectué. Votre commande est désormais validée et va être traitée par nos équipes.',
    refused: 'Ho non ! Votre paiement a échoué. Nous vous recommandons de ressayer une nouvelle fois. Si le problème persiste, veuillez contacter votre banque pour obtenir le motif du refus.',
    cancelled: 'Votre transaction a été annulée.',
    refunded: 'Votre transaction a été remboursée.'
};
const USER_ROLES = {
    ROLE_OWNER: 'ROLE_OWNER',
    ROLE_SALE: 'ROLE_SALE',
    ROLE_ACCOUNTANT: 'ROLE_ACCOUNTANT',
    ROLE_USER: 'ROLE_USER',
    ROLE_PRO: 'ROLE_PRO',
    ROLE_DELIVERY: 'ROLE_DELIVERY',
    ROLE_ADMIN: 'ROLE_ADMIN',
    ROLE_SUPER_ADMIN: 'ROLE_SUPER_ADMIN',
    ROLE_CASHIER: 'ROLE_CASHIER'
};
class AppVersion {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class ManagerVersion {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class PaginatedResult {
    constructor(obj, type) {
        var _a;
        Object.assign(this, obj);
        this.items = (_a = obj.items) === null || _a === void 0 ? void 0 : _a.map(i => new type(i));
    }
}
class OrderError {
    constructor(obj = {}) {
        this.code = null;
        this.error = '';
        this.data = null;
        this.products = [];
        Object.assign(this, obj);
    }
}
OrderError.ERROR_NOT_USER = 'not_user';
OrderError.ERROR_PRODUCT_STOCK = 'product_stock';
OrderError.ERROR_INGREDIENT_STOCK = 'ingredient_stock';
OrderError.ERROR_CHOICE_STOCK = 'choice_stock';
OrderError.ERROR_DELIVERY_SLOT_INVALID = 'delivery_slot_invalid';
OrderError.ERROR_SC_OPTION_STOCK = 'sc_option_stock';
OrderError.ERROR_CHOICE_GROUP = 'choice_group';
OrderError.ERROR_DELIVERY_NOT_SUPPORTED = 'delivery_not_supported';
OrderError.ERROR_PICKUP_NOT_SUPPORTED = 'pickup_not_supported';
OrderError.ERROR_MIN_AMOUNT_NOT_REACHED = 'min_amount_not_reached';
class Restaurant {
    constructor(obj = {}) {
        this.name = '';
        this.deliveryMinimum = 0;
        this.deliveryPrice = 0;
        this.allowDelivery = false;
        this.allowPickup = false;
        this.minimumTimeBeforeDelivery = 0;
        this.minimumTimeBeforePickup = 0;
        this.deliverySlotDuration = 0;
        this.pickupSlotDuration = 0;
        this.message = null;
        this.mode = 'production';
        Object.assign(this, obj);
        this.address = new Address(obj.address);
        this.openingHours = ((obj === null || obj === void 0 ? void 0 : obj.openingHours) || []).map(o => new Hour(o));
        this.deliveryHours = ((obj === null || obj === void 0 ? void 0 : obj.deliveryHours) || []).map(o => new Hour(o));
    }
    toString() {
        return this.name;
    }
    imageFullUrl() {
        return LibConfiguration.imageUrlFromPath(this.image);
    }
    logoFullUrl() {
        return LibConfiguration.imageUrlFromPath(this.logo);
    }
}
class RestaurantClosure {
    constructor(obj = {}) {
        Object.assign(this, obj);
        this.restaurant = obj.restaurant ? new Restaurant(obj.restaurant) : null;
    }
    formattedStartDate() {
        return moment$1(this.startsAt).format('D MMMM YYYY');
    }
    formattedEndDate() {
        return moment$1(this.endsAt).format('D MMMM YYYY');
    }
    formattedStartTime() {
        return moment$1(this.startsAt).format('HH:mm');
    }
    formattedEndTime() {
        return moment$1(this.endsAt).format('HH:mm');
    }
}
class RestaurantStats {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class Company {
    constructor(obj = {}) {
        var _a;
        Object.assign(this, obj);
        this.events = ((_a = obj === null || obj === void 0 ? void 0 : obj.events) === null || _a === void 0 ? void 0 : _a.map(a => new EventCompany(a))) || [];
        this.address = obj.address ? new Address(obj.address) : null;
    }
    getEventCompany(eventId) {
        return this.events.find(e => e.event.id === eventId);
    }
}
class Table {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class TableManagement {
    constructor(obj = {}) {
        this.orders = [];
        this.open = false;
        this.enabled = true;
        Object.assign(this, obj);
    }
}
class Zone {
    constructor(obj = {}) {
        var _a, _b;
        Object.assign(this, obj);
        this.tables = ((_a = obj === null || obj === void 0 ? void 0 : obj.tables) === null || _a === void 0 ? void 0 : _a.map(t => new Table(t))) || [];
        this.objects = ((_b = obj === null || obj === void 0 ? void 0 : obj.objects) === null || _b === void 0 ? void 0 : _b.map(o => new ZoneObject(o))) || [];
        this.restaurant = obj.restaurant ? new Restaurant(obj.restaurant) : null;
    }
}
class ZoneObject {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class Employee {
    constructor(obj = {}) {
        Object.assign(this, obj);
        if (obj === null || obj === void 0 ? void 0 : obj.hasOwnProperty('team')) {
            this.team = new Team(obj.team);
        }
    }
}
class Team {
    constructor(obj = {}) {
        var _a;
        Object.assign(this, obj);
        this.restaurant = (obj === null || obj === void 0 ? void 0 : obj.restaurant) ? new Restaurant(obj.restaurant) : null;
        this.employees = ((_a = obj === null || obj === void 0 ? void 0 : obj.employees) === null || _a === void 0 ? void 0 : _a.map(e => new Employee(e))) || [];
    }
}
class PosReport {
    constructor(obj = {}) {
        var _a;
        Object.assign(this, obj);
        this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(i => new PosReportItem(i))) || [];
        if (obj === null || obj === void 0 ? void 0 : obj.hasOwnProperty('session')) {
            this.session = typeof obj.session === 'string' ? obj.session : new Session(obj.session);
        }
    }
}
class PosReportItem {
    constructor(obj = {}) {
        Object.assign(this, obj);
        if (obj === null || obj === void 0 ? void 0 : obj.hasOwnProperty('originEmployee')) {
            this.originEmployee = typeof obj.originEmployee === 'string' ? obj.originEmployee : new Employee(obj.originEmployee);
        }
    }
}
class Tag {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class Address {
    constructor(obj) {
        if (obj) {
            Object.assign(this, obj);
        }
    }
    toString() {
        return this.name;
    }
}
class UserRegister {
    constructor() { }
}
class ClientConfig {
    constructor(obj = {}) {
        Object.assign(this, obj);
        if (obj.hasOwnProperty('appConfiguration')) {
            this.appConfiguration = new AppConfiguration(obj.appConfiguration);
        }
        if (obj.hasOwnProperty('websiteConfiguration')) {
            this.websiteConfiguration = new WebsiteConfiguration(obj.websiteConfiguration);
        }
        if (obj.hasOwnProperty('configuration')) {
            this.configuration = new Configuration(obj.configuration);
        }
    }
}
class Configuration {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class AppConfiguration extends Configuration {
    constructor(obj = {}) {
        super(obj);
    }
}
class WebsiteConfiguration extends Configuration {
    constructor(obj = {}) {
        super(obj);
    }
}
class Client {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
    logoFullUrl() {
        return LibConfiguration.imageUrlFromPath(this.logo);
    }
}
class ClientBilling {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class User {
    constructor(obj = {}) {
        var _a, _b;
        this.notifyOnRegister = true;
        Object.assign(this, obj);
        this.addresses = (_a = obj.addresses) === null || _a === void 0 ? void 0 : _a.map(a => new Address(a));
        if (obj.hasOwnProperty('client')) {
            this.client = new Client(obj.client);
        }
        if (obj.hasOwnProperty('company') && typeof obj.company !== 'string' && obj.company !== null) {
            this.company = new Company(obj.company);
        }
        this.restaurants = (_b = obj.restaurants) === null || _b === void 0 ? void 0 : _b.map(r => new Restaurant(r));
    }
    isProUser() {
        return this.role === USER_ROLES.ROLE_PRO;
    }
    formattedRole() {
        return User.roles[this.role].label;
    }
}
User.roles = {
    ROLE_OWNER: {
        slug: 'ROLE_OWNER',
        label: 'Propriétaire'
    },
    ROLE_SALE: {
        slug: 'ROLE_SALE',
        label: 'Commercial'
    },
    ROLE_ACCOUNTANT: {
        slug: 'ROLE_ACCOUNTANT',
        label: 'Comptable'
    },
    ROLE_USER: {
        slug: 'ROLE_USER',
        label: 'Utilisateur'
    },
    ROLE_PRO: {
        slug: 'ROLE_PRO',
        label: 'Professionnel'
    },
    ROLE_DELIVERY: {
        slug: 'ROLE_DELIVERY',
        label: 'Livreur'
    },
    ROLE_ADMIN: {
        slug: 'ROLE_ADMIN',
        label: 'Admin'
    },
    ROLE_SUPER_ADMIN: {
        slug: 'ROLE_SUPER_ADMIN',
        label: 'Super admin'
    },
    ROLE_CASHIER: {
        slug: 'ROLE_CASHIER',
        label: 'Caissier'
    }
};
class OrderItemChoice {
    constructor(obj = {}) {
        this.id = '';
        this.name = '';
        this.price = 0;
        this.quantity = 0;
        Object.assign(this, obj);
    }
}
class OrderItemChoiceGroup {
    constructor(obj = {}) {
        var _a;
        this.id = '';
        this.name = '';
        this.choices = [];
        Object.assign(this, obj);
        this.choices = (_a = obj.choices) === null || _a === void 0 ? void 0 : _a.map(c => new OrderItemChoice(c));
    }
    isSame(cg) {
        var _a, _b;
        if (cg.name !== this.name || ((_a = cg.choices) === null || _a === void 0 ? void 0 : _a.length) !== ((_b = this.choices) === null || _b === void 0 ? void 0 : _b.length)) {
            return false;
        }
        for (const c of this.choices) {
            const sameChoice = cg.choices.findIndex(i => i.name === c.name && i.price === c.price && i.quantity === c.quantity) !== -1;
            if (!sameChoice) {
                return false;
            }
        }
        return true;
    }
}
class Menu {
    constructor(obj = {}) {
        Object.assign(this, obj);
        this.groups = (obj.groups || []).map(g => new MenuGroup(g));
    }
    hasProduct(id) {
        for (const g of this.groups) {
            if (g.hasProduct(id)) {
                return true;
            }
        }
        return false;
    }
}
class MenuGroup {
    constructor(obj = {}) {
        Object.assign(this, obj);
        this.items = (obj.items || []).map(i => new MenuGroupItem(i));
    }
    hasProduct(id) {
        return this.items.findIndex(i => i.product === id) !== -1;
    }
}
class MenuGroupItem {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class OrderItem {
    constructor(obj = {}) {
        var _a;
        this.quantity = 0;
        this.price = 0;
        this.menuItemPrice = 0;
        this.total = 0;
        this.vat = 0;
        this.kitchenItem = false;
        this.choiceGroups = [];
        Object.assign(this, obj);
        this.choiceGroups = ((_a = obj === null || obj === void 0 ? void 0 : obj.choiceGroups) === null || _a === void 0 ? void 0 : _a.map(cg => new OrderItemChoiceGroup(cg))) || [];
        this.originCategory = obj.originCategory ? new Category(obj.originCategory) : null;
        this.originProduct = obj.originProduct ? new Product(obj.originProduct) : null;
        this.originMenu = obj.originMenu ? new Menu(obj.originMenu) : null;
        this.vatRate = obj.vatRate ? new VatRate(obj.vatRate) : null;
        this.discount = obj.discount ? new OrderDiscount(obj.discount) : null;
        this.items = (obj.items || []).map(i => new OrderItem(i));
        this.vats = (obj.vats || []).map(i => new OrderVat(i));
    }
    applyDiscount(value) {
        this.discount = null;
        this.recalculateTotals();
        const discountType = value.toString().indexOf('%') !== -1 ? 'percent' : 'fixed';
        let rate;
        let amount;
        if (discountType === 'percent') {
            rate = +(value.toString().split('%')[0]) / 100;
            amount = Math.round(this.total * rate);
        }
        if (discountType === 'fixed') {
            amount = +value * 100;
            rate = amount / this.total;
        }
        if (amount > this.total || amount < 0) {
            return;
        }
        if (amount === 0) {
            this.discount = null;
        }
        else {
            this.discount = new OrderDiscount({
                id: v4(),
                type: discountType,
                rate,
                amount
            });
        }
        this.recalculateTotals();
    }
    removeDiscount() {
        if (!this.discount) {
            return;
        }
        this.discount = null;
        this.recalculateTotals();
    }
    recalculateTotals() {
        let choicesPrice = 0;
        let menuItemsPrice = 0;
        for (const i of this.items) {
            i.recalculateTotals();
            menuItemsPrice += i.menuItemPrice;
            for (const cg of i.choiceGroups) {
                for (const c of cg.choices) {
                    if (c.quantity > 0) {
                        choicesPrice += c.price * c.quantity;
                    }
                }
            }
        }
        for (const cg of this.choiceGroups) {
            for (const c of cg.choices) {
                if (c.quantity > 0) {
                    choicesPrice += c.price * c.quantity;
                }
            }
        }
        this.total = (choicesPrice + menuItemsPrice + this.price) * this.quantity;
        if (this.discount) {
            this.discount.amount = Math.round(this.total * this.discount.rate);
            this.total -= this.discount.amount;
        }
        if (this.type === 'menu') {
            // Menu vats
            this.vat = 0;
            this.vats = [];
            let originalTotal = 0;
            for (const i of this.items) {
                i.recalculateTotals();
                originalTotal += i.total + i.menuItemPrice;
            }
            for (const i of this.items) {
                const part = ((i.total + i.menuItemPrice) / originalTotal) * 100;
                const menuItemTotal = (this.total / 100) * part;
                const vat = Math.round(menuItemTotal - (menuItemTotal / (1 + i.vatRate.rate)));
                if (!vat || vat === 0) {
                    continue;
                }
                this.vat += vat;
                const vatIndex = this.vats.findIndex(v => v.rate === i.vatRate.rate);
                if (vatIndex === -1) {
                    this.vats.push(new OrderVat({
                        id: v4(),
                        amount: vat,
                        rate: i.vatRate.rate,
                        baseTotal: menuItemTotal - vat
                    }));
                }
                else {
                    this.vats[vatIndex].amount += vat;
                    this.vats[vatIndex].baseTotal += menuItemTotal - vat;
                }
            }
            this.vats.sort((a, b) => a.rate > b.rate ? 1 : -1);
        }
        if (this.type !== 'menu') {
            // Product and MenuItem vat
            this.vat = Math.round(this.total - (this.total / (1 + this.vatRate.rate)));
            this.vats = [new OrderVat({
                    id: v4(),
                    amount: this.vat,
                    rate: this.vatRate.rate,
                    baseTotal: this.total - this.vat
                })];
        }
    }
    hasTags() {
        var _a, _b, _c, _d;
        return ((_b = (_a = this.originProduct) === null || _a === void 0 ? void 0 : _a.tags) === null || _b === void 0 ? void 0 : _b.length) > 0 || ((_d = (_c = this.originCategory) === null || _c === void 0 ? void 0 : _c.tags) === null || _d === void 0 ? void 0 : _d.length) > 0;
    }
    isSame(i) {
        var _a, _b;
        if (this.items.length !== i.items.length) {
            return false;
        }
        if (this.items.length > 0) {
            return this.hasSameItems(i.items);
        }
        else {
            // For Divers Products
            if (i.type === 'product' && this.type === 'product' && !i.originProduct && !this.originProduct) {
                if (i.originCategory.id === this.originCategory.id && i.price === this.price) {
                    return true;
                }
                else {
                    return false;
                }
            }
            // For Standard Products
            if (((_a = i.originProduct) === null || _a === void 0 ? void 0 : _a.id) !== ((_b = this.originProduct) === null || _b === void 0 ? void 0 : _b.id) || i.price !== this.price) {
                return false;
            }
            return this.hasSameChoiceGroups(i.choiceGroups);
        }
    }
    hasSameItems(items) {
        for (const i of items) {
            const sameItem = this.items.find(s => s.isSame(i));
            if (sameItem === undefined) {
                return false;
            }
        }
        return true;
    }
    hasSameChoiceGroups(choiceGroups) {
        var _a;
        if (((_a = this.choiceGroups) === null || _a === void 0 ? void 0 : _a.length) !== (choiceGroups === null || choiceGroups === void 0 ? void 0 : choiceGroups.length)) {
            return false;
        }
        for (const cg of choiceGroups) {
            const sameChoiceGroup = this.choiceGroups.find(s => s.isSame(cg));
            if (sameChoiceGroup === undefined) {
                return false;
            }
        }
        return true;
    }
}
class OrderOption {
    constructor(obj = {}) {
        this.id = '';
        this.name = '';
        this.price = 0;
        this.vat = 0;
        this.quantity = 0;
        this.total = 0;
        Object.assign(this, obj);
    }
}
class Collection {
    constructor(obj = {}) {
        var _a, _b, _c;
        Object.assign(this, obj);
        this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(i => new CollectionItem(i))) || [];
        this.operations = ((_b = obj === null || obj === void 0 ? void 0 : obj.operations) === null || _b === void 0 ? void 0 : _b.map(i => new CollectionOperation(i))) || [];
        this.transactions = ((_c = obj === null || obj === void 0 ? void 0 : obj.transactions) === null || _c === void 0 ? void 0 : _c.map(i => new CollectionTransaction(i))) || [];
    }
    reorderItems(items) {
        const filteredItems = items.filter(i => this.items.findIndex(oi => oi.orderItem.id === i.id) !== -1);
        const itemsByItems = {};
        for (const fi of filteredItems) {
            itemsByItems[fi.id] = this.items.filter(s => s.orderItem.id === fi.id);
        }
        const itemsReordered = [];
        for (const value of Object.values(itemsByItems)) {
            for (const i of value) {
                itemsReordered.push(i);
            }
        }
        this.items = itemsReordered;
    }
}
class CollectionItem {
    constructor(obj = {}) {
        Object.assign(this, obj);
        if (obj.hasOwnProperty('orderItem') && obj.orderItem !== null) {
            this.orderItem = new OrderItem(obj.orderItem);
        }
    }
    update(orderItem) {
        this.name = orderItem.name;
        this.total = orderItem.total;
        this.quantity = orderItem.quantity;
        this.orderItem = orderItem;
    }
}
class CollectionOperation {
    constructor(obj = {}) {
        var _a;
        Object.assign(this, obj);
        this.orderItems = ((_a = obj === null || obj === void 0 ? void 0 : obj.orderItems) === null || _a === void 0 ? void 0 : _a.map(i => new OrderItem(i))) || [];
    }
    hasOrderItem(id) {
        return this.orderItems && this.orderItems.findIndex(s => s.id === id) !== -1;
    }
    hasOrderItemWithDiscount() {
        return this.orderItems && this.orderItems.filter(i => i.discount).length > 0;
    }
}
class CollectionTransaction {
    constructor(obj = {}) {
        var _a;
        Object.assign(this, obj);
        this.operations = ((_a = obj === null || obj === void 0 ? void 0 : obj.operations) === null || _a === void 0 ? void 0 : _a.map(i => new CollectionOperation(i))) || [];
    }
    hasOrderItem(id) {
        return this.operations && this.operations.findIndex(s => s.hasOrderItem(id)) !== -1;
    }
}
class Production {
    constructor(obj = {}) {
        var _a, _b, _c, _d;
        this.topPriority = null;
        this.mode = 'auto';
        Object.assign(this, obj);
        this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(i => new ProductionItem(i))) || [];
        this.itemsToSend = ((_b = obj === null || obj === void 0 ? void 0 : obj.itemsToSend) === null || _b === void 0 ? void 0 : _b.map(i => new ProductionItem(i))) || [];
        this.itemsComing = ((_c = obj === null || obj === void 0 ? void 0 : obj.itemsComing) === null || _c === void 0 ? void 0 : _c.map(i => new ProductionItem(i))) || [];
        this.tickets = ((_d = obj === null || obj === void 0 ? void 0 : obj.tickets) === null || _d === void 0 ? void 0 : _d.map(i => new ProductionTicket(i))) || [];
    }
    getLastTicket(exception = null) {
        var _a;
        let ticket = null;
        if (!exception) {
            return this.tickets.length > 0 ? this.tickets[0] : null;
        }
        for (const i of this.tickets) {
            if (((_a = i[exception]) === null || _a === void 0 ? void 0 : _a.length) > 0) {
                continue;
            }
            return i;
        }
        return ticket;
    }
    durationSinceLastAction() {
        return moment$1().diff(moment$1(this.lastAction), 'minutes');
    }
    setOrderItems(items) {
        const itemsById = {};
        for (const i of items) {
            itemsById[i.id] = i;
            for (const mi of i.items) {
                itemsById[i.id] = mi;
            }
        }
        for (let i of this.itemsToSend) {
            if (itemsById[i.orderItem]) {
                i.originOrderItem = itemsById[i.orderItem];
            }
        }
        for (let i of this.itemsComing) {
            if (itemsById[i.orderItem]) {
                i.originOrderItem = itemsById[i.orderItem];
            }
        }
        for (let i of this.tickets) {
            i.setOrderItems(items);
        }
    }
    clearItemLists() {
        this.items = [];
        this.itemsToSend = [];
        this.itemsComing = [];
    }
    getTopPriority() {
        var _a, _b, _c, _d;
        let priority = 1;
        for (const t of this.tickets.filter(t => t.itemsToCancel.length === 0)) {
            const itemsToSend = t.itemsToSend;
            const itemsComing = t.itemsComing;
            let p = 1;
            if (itemsComing.length > 0) {
                for (const i of t.itemsComing) {
                    const itemPriority = (_b = (_a = i.originOrderItem) === null || _a === void 0 ? void 0 : _a.originCategory) === null || _b === void 0 ? void 0 : _b.productionPriority;
                    if (itemPriority > p) {
                        p = itemPriority;
                    }
                }
            }
            if (itemsToSend.length > 0) {
                for (const i of t.itemsToSend) {
                    const itemPriority = (_d = (_c = i.originOrderItem) === null || _c === void 0 ? void 0 : _c.originCategory) === null || _d === void 0 ? void 0 : _d.productionPriority;
                    if (itemPriority > priority) {
                        p = itemPriority;
                    }
                }
            }
            priority = p;
        }
        return priority;
    }
}
class ProductionItem {
    constructor(obj = {}) {
        Object.assign(this, obj);
        if (obj.hasOwnProperty('originOrderItem') && obj.originOrderItem !== null) {
            this.originOrderItem = new OrderItem(obj.originOrderItem);
        }
    }
}
class ProductionTicket {
    constructor(obj = {}) {
        var _a, _b, _c;
        this.copy = false;
        Object.assign(this, obj);
        this.itemsToSend = ((_a = obj === null || obj === void 0 ? void 0 : obj.itemsToSend) === null || _a === void 0 ? void 0 : _a.map(i => new ProductionItem(i))) || [];
        this.itemsComing = ((_b = obj === null || obj === void 0 ? void 0 : obj.itemsComing) === null || _b === void 0 ? void 0 : _b.map(i => new ProductionItem(i))) || [];
        this.itemsToCancel = ((_c = obj === null || obj === void 0 ? void 0 : obj.itemsToCancel) === null || _c === void 0 ? void 0 : _c.map(i => new ProductionItem(i))) || [];
    }
    formattedType() {
        var _a;
        return ((_a = this.itemsToCancel) === null || _a === void 0 ? void 0 : _a.length) === 0 ? 'Ticket de production' : 'Ticket d\'annulation';
    }
    formattedCreatedAt(format) {
        return moment$1(this.createdAt).format(format || 'dddd DD MMMM YYYY à HH:mm');
    }
    setOrderItems(items) {
        const itemsById = {};
        for (const i of items) {
            itemsById[i.id] = i;
            for (const mi of i.items) {
                itemsById[i.id] = mi;
            }
        }
        for (let i of this.itemsToSend) {
            if (itemsById[i.orderItem]) {
                i.originOrderItem = itemsById[i.orderItem];
            }
        }
        for (let i of this.itemsComing) {
            if (itemsById[i.orderItem]) {
                i.originOrderItem = itemsById[i.orderItem];
            }
        }
        for (let i of this.itemsToCancel) {
            if (itemsById[i.orderItem]) {
                i.originOrderItem = itemsById[i.orderItem];
            }
        }
    }
}
class Session {
    constructor(obj = {}) {
        this.uploaded = false;
        Object.assign(this, obj);
    }
    getNextOrderNumber() {
        if (this.firstOrderNumber) {
            return this.lastOrderNumber + 1;
        }
        else {
            return (this.previousSessionLastOrderNumber || 0) + 1;
        }
    }
    setOrderNumbers(n) {
        this.lastOrderNumber = n;
        if (!this.firstOrderNumber) {
            this.firstOrderNumber = n;
        }
    }
    getNextInvoiceNumber() {
        if (this.firstInvoiceNumber) {
            return this.lastInvoiceNumber + 1;
        }
        else {
            return (this.previousSessionLastInvoiceNumber || 0) + 1;
        }
    }
    setInvoiceNumbers(n) {
        this.lastInvoiceNumber = n;
        if (!this.firstInvoiceNumber) {
            this.firstInvoiceNumber = n;
        }
    }
    openedAtFormatted() {
        return moment$1(this.openedAt).format('D MMM à HH:mm');
    }
}
class License {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
    isValid() {
        return moment$1(this.expiresAt).isAfter(moment$1()) && this.isEnabled;
    }
    expiresAtFormatted() {
        return moment$1(this.expiresAt).format('D MMMM YYYY');
    }
}
class TransactionPayment {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
    formattedType() {
        return PAYMENT_METHODS[this.type].label;
    }
    icon() {
        return PAYMENT_METHODS[this.type].icon;
    }
}
class Hashes {
    constructor(obj = {}) {
        Object.assign(this, obj);
        if (Object.keys(obj.orders).length > 0) {
            for (const [key, value] of Object.entries(obj.orders)) {
                this.orders[key] = new Hash(value);
            }
        }
        if (Object.keys(obj.transactions).length > 0) {
            for (const [key, value] of Object.entries(obj.transactions)) {
                this.transactions[key] = new Hash(value);
            }
        }
        if (Object.keys(obj.reportItems).length > 0) {
            for (const [key, value] of Object.entries(obj.reportItems)) {
                this.reportItems[key] = new Hash(value);
            }
        }
    }
}
class Hash {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class TransactionVat {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class TransactionPart {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class InvoiceData {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class Transaction {
    constructor(obj = {}) {
        var _a, _b, _c, _d;
        this.printed = false;
        this.printCount = 0;
        this.parts = [];
        Object.assign(this, obj);
        this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(i => new TransactionItem(i))) || [];
        this.payments = ((_b = obj === null || obj === void 0 ? void 0 : obj.payments) === null || _b === void 0 ? void 0 : _b.map(p => new TransactionPayment(p))) || [];
        this.vats = ((_c = obj === null || obj === void 0 ? void 0 : obj.vats) === null || _c === void 0 ? void 0 : _c.map(v => new TransactionVat(v))) || [];
        this.parts = ((_d = obj === null || obj === void 0 ? void 0 : obj.parts) === null || _d === void 0 ? void 0 : _d.map(p => new TransactionPart(p))) || [];
        this.user = (obj === null || obj === void 0 ? void 0 : obj.user) ? new User(obj.user) : null;
    }
    formattedStatusInformations() {
        return TRANSACTION_STATUS_INFORMATIONS[this.status];
    }
    formattedCancellationReason() {
        return ORDER_CANCELLATION_REASONS[this.cancellationReason].label;
    }
    statusIcon() {
        switch (this.status) {
            case TRANSACTION_STATUS.paid.slug:
                return 'checkmark-circle';
            default:
                return 'alert-circle';
        }
    }
    formattedStatus() {
        var _a;
        return (_a = TRANSACTION_STATUS[this.status]) === null || _a === void 0 ? void 0 : _a.label;
    }
    cancel() {
        this.status = ORDER_STATUS.cancelled.slug;
    }
    formattedCreatedAt(format) {
        return moment$1(this.createdAt).format(format || 'dddd DD MMMM YYYY à HH:mm');
    }
    recalculateTotals() {
        this.total = 0;
        this.vatTotal = 0;
        this.vats = [];
        for (const i of this.items) {
            this.total += i.total;
            this.vatTotal += i.vat;
            for (const v of i.vats) {
                const vatIndex = this.vats.findIndex(s => s.rate === v.rate);
                if (vatIndex === -1) {
                    this.vats.push(new TransactionVat({
                        id: v4(),
                        amount: v.amount,
                        rate: v.rate,
                        baseTotal: v.baseTotal
                    }));
                }
                else {
                    this.vats[vatIndex].amount += v.amount;
                    this.vats[vatIndex].baseTotal += v.baseTotal;
                }
            }
            this.vats.sort((a, b) => a.rate > b.rate ? 1 : -1);
        }
    }
    getTotal() {
        return this.total ? this.total : this.amount;
    }
    getPartsTotal() {
        let partsTotal = 0;
        for (const p of this.parts) {
            partsTotal += p.amount;
        }
        return partsTotal;
    }
    canAddPart(amount) {
        return (this.status === TRANSACTION_STATUS.paid.slug || this.status === TRANSACTION_STATUS.paid_account.slug)
            && !this.originalTransaction
            && amount >= 0
            && (this.getPartsTotal() + amount) <= this.total;
    }
}
class TransactionItem {
    constructor(obj = {}) {
        var _a;
        Object.assign(this, obj);
        this.vats = ((_a = obj === null || obj === void 0 ? void 0 : obj.vats) === null || _a === void 0 ? void 0 : _a.map(v => new TransactionVat(v))) || [];
    }
}
class OrderVat {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class Order {
    constructor(obj = {}) {
        var _a, _b, _c, _d;
        this.hasKitchenItems = false;
        this.items = [];
        this.options = [];
        this.total = 0;
        this.transactions = [];
        this.vatTotal = 0;
        this.printed = false;
        this.printCount = 0;
        this.vats = [];
        Object.assign(this, obj);
        this.deliveryAddress = (obj === null || obj === void 0 ? void 0 : obj.deliveryAddress) ? new Address(obj.deliveryAddress) : null;
        this.billingAddress = (obj === null || obj === void 0 ? void 0 : obj.billingAddress) ? new Address(obj.billingAddress) : null;
        this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(i => new OrderItem(i))) || [];
        this.options = ((_b = obj === null || obj === void 0 ? void 0 : obj.options) === null || _b === void 0 ? void 0 : _b.map(o => new OrderOption(o))) || [];
        this.restaurant = (obj === null || obj === void 0 ? void 0 : obj.restaurant) ? (typeof obj.restaurant === 'string' ? obj.restaurant : new Restaurant(obj.restaurant)) : null;
        this.transactions = ((_c = obj === null || obj === void 0 ? void 0 : obj.transactions) === null || _c === void 0 ? void 0 : _c.map(t => {
            const transaction = new Transaction(t);
            transaction.order = this.id;
            return transaction;
        })) || [];
        this.deliveredBy = (obj === null || obj === void 0 ? void 0 : obj.deliveredBy) ? new User(obj.deliveredBy) : null;
        this.pickupStall = (obj === null || obj === void 0 ? void 0 : obj.pickupStall) ? new EventStall(obj.pickupStall) : null;
        this.deliveryStall = (obj === null || obj === void 0 ? void 0 : obj.deliveryStall) ? new EventStall(obj.deliveryStall) : null;
        this.vats = ((_d = obj === null || obj === void 0 ? void 0 : obj.vats) === null || _d === void 0 ? void 0 : _d.map(v => new OrderVat(v))) || [];
        this.discount = (obj === null || obj === void 0 ? void 0 : obj.discount) ? new OrderDiscount(obj.discount) : null;
        this.originEmployee = (obj === null || obj === void 0 ? void 0 : obj.originEmployee) ? new Employee(obj.originEmployee) : null;
        this.session = (obj === null || obj === void 0 ? void 0 : obj.session) ? (typeof obj.session === 'string' ? obj.session : new Session(obj.session)) : null;
        this.originTable = (obj === null || obj === void 0 ? void 0 : obj.originTable) ? new Table(obj.originTable) : null;
        this.setItemQuantity();
    }
    setItemQuantity() {
        let qt = 0;
        for (const i of this.items) {
            qt += i.quantity;
        }
        this.itemQuantity = qt;
    }
    formattedCreatedAt(format) {
        return moment$1(this.createdAt).format(format || 'dddd DD MMMM YYYY à HH:mm');
    }
    formattedShortCreatedAt() {
        return Utils.toShortDateTime(this.createdAt);
    }
    formattedTimeCreatedAt() {
        return Utils.toTime(this.createdAt);
    }
    formattedDeliverySlot(format) {
        return moment$1(this.deliverySlot).format(format || 'dddd DD MMMM YYYY à HH:mm');
    }
    formattedShortDeliverySlot() {
        return Utils.toShortDateTime(this.deliverySlot);
    }
    deliveryTime() {
        return Utils.toTime(this.deliverySlot);
    }
    shortClientName() {
        return this.clientFirstname + ' ' + this.clientLastname.charAt(0).toUpperCase() + '.';
    }
    formattedStatus() {
        return this.formatStatus(this.status);
    }
    formattedStatusInformations(role = USER_ROLES.ROLE_USER) {
        if (this.status === 'delivering') {
            return this.deliveryMethod === 'delivery' ? ORDER_STATUS_INFORMATIONS[role].delivering : ORDER_STATUS_INFORMATIONS[role].picking;
        }
        else {
            return ORDER_STATUS_INFORMATIONS[role][this.status];
        }
    }
    formatStatus(status) {
        switch (status) {
            case 'pending':
                return 'En attente de paiement';
            case 'confirmed':
                return 'Confirmée';
            case 'preparing':
                return 'En cours de préparation';
            case 'delivering':
                return this.deliveryMethod === 'delivery' ? 'En cours de livraison' : 'En attente de retrait';
            case 'done':
                return 'Terminée';
            case 'cancelled':
                return 'Annulée';
        }
        return null;
    }
    previousStatus(formatted = false) {
        switch (this.status) {
            case 'confirmed':
                return formatted ? this.formatStatus('pending') : 'pending';
            case 'preparing':
                return formatted ? this.formatStatus('confirmed') : 'confirmed';
            case 'delivering':
                return formatted ? this.formatStatus('preparing') : 'preparing';
            case 'done':
                return formatted ? this.formatStatus('delivering') : 'delivering';
        }
        return null;
    }
    nextStatus(formatted = false) {
        switch (this.status) {
            case 'confirmed':
                return formatted ? this.formatStatus('preparing') : 'preparing';
            case 'preparing':
                return formatted ? this.formatStatus('delivering') : 'delivering';
            case 'delivering':
                return formatted ? this.formatStatus('done') : 'done';
        }
        return null;
    }
    statusIcon() {
        switch (this.status) {
            case 'confirmed':
                return 'checkmark-circle-outline';
            case 'preparing':
                return 'flask';
            case 'delivering':
                return this.deliveryMethod === 'delivery' ? 'bicycle' : 'flag';
            case 'done':
                return 'checkmark-circle';
            default:
                return 'hourglass';
        }
    }
    getPaymentLink() {
        return LibConfiguration.generatePaymentLink(this.id);
    }
    getKitchenItems() {
        return this.items.filter((n) => n.kitchenItem).sort((n1, n2) => {
            if (n1.name > n2.name) {
                return 1;
            }
            if (n1.name < n2.name) {
                return -1;
            }
            return 0;
        });
    }
    canBePaid() {
        return this.status === 'pending' && moment$1().diff(moment$1(this.createdAt), 'minutes') <= 30;
    }
    canAddItem() {
        return this.source === 'pos' && this.status === 'pending';
    }
    formattedSource() {
        switch (this.source) {
            case 'website':
                return 'Site web';
            case 'app':
                return 'Application';
            case 'pos':
                return 'Point de vente';
            default:
                return 'Source inconnue';
        }
    }
    recalculateTotals() {
        var _a, _b;
        this.total = 0;
        this.vatTotal = 0;
        this.vats = [];
        for (const i of this.items) {
            i.recalculateTotals();
            this.total += i.total;
            if (((_a = i.items) === null || _a === void 0 ? void 0 : _a.length) === 0) {
                if ((!i.vat || i.vat === 0)) {
                    continue;
                }
                this.vatTotal += i.vat;
                const vatIndex = this.vats.findIndex(v => v.rate === i.vatRate.rate);
                if (vatIndex === -1 && i.vat > 0) {
                    this.vats.push(new OrderVat({
                        id: v4(),
                        amount: i.vat,
                        rate: i.vatRate.rate,
                        baseTotal: i.total - i.vat
                    }));
                }
                else {
                    this.vats[vatIndex].amount += i.vat;
                    this.vats[vatIndex].baseTotal += i.total - i.vat;
                }
            }
            if (((_b = i.items) === null || _b === void 0 ? void 0 : _b.length) > 0) {
                for (const vat of i.vats) {
                    this.vatTotal += vat.amount;
                    const vatIndex = this.vats.findIndex(v => v.rate === vat.rate);
                    if (vatIndex === -1) {
                        this.vats.push(new OrderVat({
                            id: v4(),
                            amount: vat.amount,
                            rate: vat.rate,
                            baseTotal: vat.baseTotal
                        }));
                    }
                    else {
                        this.vats[vatIndex].amount += vat.amount;
                        this.vats[vatIndex].baseTotal += vat.baseTotal;
                    }
                }
            }
        }
        this.vats.sort((a, b) => a.rate > b.rate ? 1 : -1);
        this.setItemQuantity();
    }
    transactionsTotal() {
        let total = 0;
        for (const t of this.transactions) {
            total += t.amount;
        }
        return total;
    }
    totalRemaining() {
        return this.total - this.transactionsTotal();
    }
    getNextTransactionNumber() {
        let c = this.transactions.length + 1;
        let n = ('' + c).padStart(3, '0');
        while (this.transactions.findIndex(t => t.number === n) !== -1) {
            c += 1;
            n = ('' + c).padStart(3, '0');
        }
        return n;
    }
    canClose() {
        const transactionsTotal = this.transactionsTotal();
        return this.source === 'pos'
            && this.status === ORDER_STATUS.pending.slug
            && transactionsTotal === this.total;
    }
    canCancel() {
        return this.source === 'pos' && !this.synchronized && this.status !== ORDER_STATUS.cancelled.slug;
    }
    hasItemsWithTags() {
        return this.items.filter(i => i.hasTags()).length > 0;
    }
    findCloneItems(item) {
        var _a;
        return (_a = this.items) === null || _a === void 0 ? void 0 : _a.filter(i => i.isSame(item));
    }
    durationSinceOrderTaken() {
        return moment$1().diff(moment$1(this.createdAt), 'minutes');
    }
}
class OrderDiscount {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class PlaceOrder {
    constructor(obj = {}) {
        Object.assign(this, obj);
        this.options = (obj === null || obj === void 0 ? void 0 : obj.options.map(o => new PlaceOrderOption(o))) || [];
    }
}
class PlaceOrderOption {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class PlaceOrderClient {
    constructor() {
        this.firstname = null;
        this.lastname = null;
        this.phoneNumber = null;
        this.email = null;
        this.billingAddress = null;
        this.deliveryAddress = null;
    }
}
class VatRate {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class ContactModel {
    constructor() {
        this.name = '';
        this.message = '';
        this.email = '';
    }
}
class DeliverySlot {
    constructor(obj = {}) {
        this.label = '';
        this.id = '';
        this.startsAt = '';
        this.endsAt = '';
        this.isOpen = true;
        Object.assign(this, obj);
    }
    toString() {
        return this.label;
    }
    dayFormatted() {
        return moment$1(this.startsAt).format('dddd D MMMM');
    }
    shortDayFormatted() {
        return moment$1(this.startsAt).format('ddd D MMM');
    }
    fullDateFormatted() {
        const today = moment$1().isSame(this.startsAt, 'day');
        return today ? 'Aujourd\'hui, ' + this.label : moment$1(this.startsAt).format('dddd D MMM, ') + this.label;
    }
}
class NextDeliverySlots {
    constructor(obj = {}) {
        this.shop = null;
        this.delivery = null;
        Object.assign(this, obj);
        if (obj.hasOwnProperty('shop') && obj.shop !== null) {
            this.shop = new DeliverySlot(obj.shop);
        }
        if (obj.hasOwnProperty('delivery') && obj.delivery !== null) {
            this.delivery = new DeliverySlot(obj.delivery);
        }
    }
}
class DeliverySlots {
    constructor(obj = {}) {
        Object.assign(this, obj);
        if (this.shop) {
            this.shop = {};
            for (const [key, value] of Object.entries(obj.shop)) {
                this.shop[key] = value.map(d => new DeliverySlot(d));
            }
        }
        if (this.delivery) {
            this.delivery = {};
            for (const [key, value] of Object.entries(obj.delivery)) {
                this.delivery[key] = value.map(d => new DeliverySlot(d));
            }
        }
    }
}
class Hour {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
    getFormattedSlot(format = 'HH:mm') {
        return moment$1(this.openingTime).format(format) + ' - ' + moment$1(this.closingTime).format(format);
    }
}
class HourGroup {
    constructor(obj = {}) {
        var _a;
        Object.assign(this, obj);
        this.hours = (_a = obj === null || obj === void 0 ? void 0 : obj.hours) === null || _a === void 0 ? void 0 : _a.map(h => new Hour(h));
    }
}
class Category {
    constructor(obj = {}) {
        var _a, _b, _c, _d, _e;
        this.kitchen = false;
        this.products = [];
        this.menus = [];
        this.ingredients = [];
        this.productionPriority = 0;
        this.availableOnPos = true;
        this.availableOnWeb = true;
        this.availableOnMenu = true;
        this.canCreateProductOnPos = false;
        Object.assign(this, obj);
        this.products = ((_a = obj === null || obj === void 0 ? void 0 : obj.products) === null || _a === void 0 ? void 0 : _a.map(p => new Product(p))) || [];
        this.menus = ((_b = obj === null || obj === void 0 ? void 0 : obj.menus) === null || _b === void 0 ? void 0 : _b.map(m => new Menu(m))) || [];
        this.ingredients = ((_c = obj === null || obj === void 0 ? void 0 : obj.ingredients) === null || _c === void 0 ? void 0 : _c.map(i => new ProductIngredient(i))) || [];
        this.hours = ((_d = obj === null || obj === void 0 ? void 0 : obj.hours) === null || _d === void 0 ? void 0 : _d.map(h => new HourGroup(h))) || [];
        this.tags = ((_e = obj === null || obj === void 0 ? void 0 : obj.tags) === null || _e === void 0 ? void 0 : _e.map(t => new Tag(t))) || [];
        this.vatRate = (obj === null || obj === void 0 ? void 0 : obj.vatRate) ? new VatRate(obj.vatRate) : null;
    }
    toString() {
        return this.name;
    }
    removableIngredients() {
        return this.ingredients.filter(i => i.isRemovable);
    }
    addableIngredients() {
        return this.ingredients.filter(i => i.isAddable);
    }
}
class Stock {
    constructor(obj = {}) {
        Object.assign(this, obj);
        if (obj === null || obj === void 0 ? void 0 : obj.restaurant) {
            this.restaurant = new Restaurant({
                id: obj.restaurant.id
            });
        }
    }
}
class ProductChoice extends Sortable {
    constructor(obj = {}) {
        var _a;
        super();
        this.type = ProductChoice.PRODUCT_CHOICE_TYPE_CUSTOM;
        this.isDefault = false;
        Object.assign(this, obj);
        if (this.type === ProductChoice.PRODUCT_CHOICE_TYPE_CUSTOM) {
            this.stocks = ((_a = obj === null || obj === void 0 ? void 0 : obj.stocks) === null || _a === void 0 ? void 0 : _a.map(s => new Stock(s))) || [];
        }
        else {
            this.ingredient = new ProductIngredient(obj.ingredient);
            this.stocks = this.ingredient.stocks;
        }
        this.price = this.type === ProductChoice.PRODUCT_CHOICE_TYPE_CUSTOM ? obj.price : this.ingredient.price;
        this.name = this.type === ProductChoice.PRODUCT_CHOICE_TYPE_CUSTOM ? obj.name : this.ingredient.name;
    }
}
ProductChoice.PRODUCT_CHOICE_TYPE_CUSTOM = 'custom';
ProductChoice.PRODUCT_CHOICE_TYPE_INGREDIENT = 'ingredient';
class ProductChoiceGroup extends Sortable {
    constructor(obj = {}) {
        var _a;
        super();
        this.selectorType = null;
        Object.assign(this, obj);
        this.choices = ((_a = obj === null || obj === void 0 ? void 0 : obj.choices) === null || _a === void 0 ? void 0 : _a.map(c => new ProductChoice(c))) || [];
        if (this.minChoices === 1 && this.maxChoices === 1) {
            this.selectorType = 'radio';
        }
        else if (this.useQuantitySelector === false) {
            this.selectorType = 'checkbox';
        }
        else {
            this.selectorType = 'quantity';
        }
    }
}
class ProductIngredient {
    constructor(obj = {}) {
        var _a, _b;
        Object.assign(this, obj);
        if (obj.hasOwnProperty('vatRate')) {
            this.vatRate = new VatRate(obj.vatRate);
        }
        this.stocks = ((_a = obj === null || obj === void 0 ? void 0 : obj.stocks) === null || _a === void 0 ? void 0 : _a.map(s => new Stock(s))) || [];
        this.productCategories = ((_b = obj === null || obj === void 0 ? void 0 : obj.productCategories) === null || _b === void 0 ? void 0 : _b.map(c => new Category(c))) || [];
    }
}
class ProductAllergen {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class Product {
    constructor(obj = {}) {
        var _a, _b, _c, _d, _e;
        this.availableOnPos = true;
        this.availableOnWeb = true;
        this.availableOnMenu = true;
        this.isOption = false;
        Object.assign(this, obj);
        this.vatRate = (obj === null || obj === void 0 ? void 0 : obj.vatRate) ? new VatRate(obj.vatRate) : null;
        this.stocks = ((_a = obj === null || obj === void 0 ? void 0 : obj.stocks) === null || _a === void 0 ? void 0 : _a.map(s => new Stock(s))) || [];
        this.choiceGroups = ((_b = obj === null || obj === void 0 ? void 0 : obj.choiceGroups) === null || _b === void 0 ? void 0 : _b.map(cg => new ProductChoiceGroup(cg))) || [];
        this.ingredients = ((_c = obj === null || obj === void 0 ? void 0 : obj.ingredients) === null || _c === void 0 ? void 0 : _c.map(i => new ProductIngredient(i))) || [];
        this.tags = ((_d = obj === null || obj === void 0 ? void 0 : obj.tags) === null || _d === void 0 ? void 0 : _d.map(i => new Tag(i))) || [];
        this.allergens = ((_e = obj === null || obj === void 0 ? void 0 : obj.allergens) === null || _e === void 0 ? void 0 : _e.map(i => new ProductAllergen(i))) || [];
        this.originCategory = (obj === null || obj === void 0 ? void 0 : obj.originCategory) ? new Category(obj.originCategory) : null;
    }
    formattedName() {
        return this.name;
    }
    formattedPrice() {
        return this.price / 100;
    }
    removableIngredients() {
        return this.ingredients.filter(i => i.isRemovable);
    }
    imageFullUrl() {
        return LibConfiguration.imageUrlFromPath(this.image);
    }
    hasRequiredConfiguration() {
        var _a;
        return ((_a = this.choiceGroups) === null || _a === void 0 ? void 0 : _a.filter(cg => cg.required).length) > 0;
    }
    dimensionTypeFormatted() {
        return PRODUCT_DIMENSION_TYPES[this.dimensionType].label;
    }
}
class ShoppingCartOption {
    constructor(obj = {}) {
        var _a, _b;
        Object.assign(this, obj);
        this.vatRate = (obj === null || obj === void 0 ? void 0 : obj.vatRate) ? new VatRate(obj.vatRate) : null;
        this.stocks = ((_a = obj === null || obj === void 0 ? void 0 : obj.stocks) === null || _a === void 0 ? void 0 : _a.map(s => new Stock(s))) || [];
        this.restaurants = ((_b = obj === null || obj === void 0 ? void 0 : obj.restaurants) === null || _b === void 0 ? void 0 : _b.map(r => new Restaurant(r))) || [];
    }
}
class ShoppingCartItemProductChoices {
}
class ShoppingCart {
    constructor(obj = {}) {
        var _a;
        this.id = null;
        this.items = [];
        this.unvalidItems = [];
        Object.assign(this, obj);
        this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(i => new ShoppingCartItem(i))) || [];
    }
}
class ShoppingCartItem {
    constructor(obj = {}) {
        var _a, _b, _c, _d;
        this.id = null;
        Object.assign(this, obj);
        this.base.product = ((_a = obj.base) === null || _a === void 0 ? void 0 : _a.product) ? new Product(obj.base.product) : null;
        this.base.category = ((_b = obj.base) === null || _b === void 0 ? void 0 : _b.category) ? new Category(obj.base.category) : null;
        this.ingredientsToRemove = ((_c = obj === null || obj === void 0 ? void 0 : obj.ingredientsToRemove) === null || _c === void 0 ? void 0 : _c.map(i => new ProductIngredient(i))) || [];
        this.ingredientsToAdd = ((_d = obj === null || obj === void 0 ? void 0 : obj.ingredientsToAdd) === null || _d === void 0 ? void 0 : _d.map(i => new ProductIngredient(i))) || [];
    }
    total() {
        let choicesTotalPrice = 0;
        let ingredientsToAddTotalPrice = 0;
        for (const [key, value] of Object.entries(this.choiceGroups)) {
            for (const c of value.choices) {
                choicesTotalPrice += c.choice.price * c.quantity;
            }
        }
        for (const i of this.ingredientsToAdd) {
            ingredientsToAddTotalPrice += i.price;
        }
        return ((this.base.product.price + choicesTotalPrice + ingredientsToAddTotalPrice) * this.base.quantity);
    }
    vat() {
        return this.total() - (this.total() / (1 + this.base.product.vatRate.rate));
    }
    setQuantity(quantity) {
        this.base.quantity = quantity;
    }
    getChoiceGroups() {
        const choiceGroups = [];
        for (const [key, value] of Object.entries(this.choiceGroups)) {
            choiceGroups.push(value);
        }
        return choiceGroups;
    }
}
/* WIDGET */
class Widget {
    constructor(obj = {}) {
        var _a, _b, _c;
        Object.assign(this, obj);
        if (obj.type === 'gallery') {
            this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(i => i.type === 'image' ? new WidgetGalleryImageItem(i) : new WidgetGalleryTextItem(i))) || [];
        }
        if (obj.type === 'custom') {
            this.items = ((_b = obj === null || obj === void 0 ? void 0 : obj.items) === null || _b === void 0 ? void 0 : _b.map(i => {
                if (i.type === 'custom') {
                    return new WidgetCustomCustomItem(i);
                }
                if (i.type === 'category') {
                    return new WidgetCustomCategoryItem(i);
                }
                if (i.type === 'product') {
                    return new WidgetCustomProductItem(i);
                }
            })) || [];
        }
        this.restaurants = ((_c = obj === null || obj === void 0 ? void 0 : obj.restaurants) === null || _c === void 0 ? void 0 : _c.map(r => new Restaurant(r))) || [];
    }
}
class WidgetItem {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
    imageFullUrl() {
        return LibConfiguration.imageUrlFromPath(this.image);
    }
}
class WidgetGalleryItem extends WidgetItem {
    constructor(obj = {}) {
        super(obj);
    }
}
class WidgetGalleryImageItem extends WidgetGalleryItem {
    constructor(obj = {}) {
        super(obj);
    }
}
class WidgetGalleryTextItem extends WidgetGalleryItem {
    constructor(obj = {}) {
        super(obj);
    }
}
class WidgetCustomItem extends WidgetItem {
    constructor(obj = {}) {
        super(obj);
    }
}
class WidgetCustomCustomItem extends WidgetCustomItem {
    constructor(obj = {}) {
        super(obj);
    }
    fileFullUrl() {
        return LibConfiguration.imageUrlFromPath(this.file);
    }
}
class WidgetCustomCategoryItem extends WidgetCustomItem {
    constructor(obj = {}) {
        super(obj);
        this.category = obj.hasOwnProperty('category') && obj.category ? new Category(obj.category) : null;
    }
}
class WidgetCustomProductItem extends WidgetCustomItem {
    constructor(obj = {}) {
        super(obj);
        this.product = obj.hasOwnProperty('product') && obj.product ? new Product(obj.product) : null;
    }
}
/* EVENTS */
class Event {
    constructor(obj = {}) {
        var _a, _b, _c;
        this.eventRestaurants = null;
        this.halls = null;
        this.companies = null;
        Object.assign(this, obj);
        this.eventRestaurants = ((_a = obj === null || obj === void 0 ? void 0 : obj.eventRestaurants) === null || _a === void 0 ? void 0 : _a.map(er => new EventRestaurant(er))) || [];
        this.halls = ((_b = obj === null || obj === void 0 ? void 0 : obj.halls) === null || _b === void 0 ? void 0 : _b.map(h => new EventHall(h))) || [];
        this.companies = ((_c = obj === null || obj === void 0 ? void 0 : obj.companies) === null || _c === void 0 ? void 0 : _c.map(c => new EventCompany(c))) || [];
        this.location = (obj === null || obj === void 0 ? void 0 : obj.location) ? new EventLocation(obj.location) : null;
    }
    getEventRestaurantByRestaurantId(restaurantId) {
        return this.eventRestaurants.find(er => er.restaurant.id === restaurantId);
    }
    getEventRestaurantsByHallId(hallId) {
        return this.eventRestaurants.filter(er => er.stall.hall.id === hallId);
    }
    formattedDates() {
        return moment$1(this.startsAt).format('DD.MM.YYYY') + ' - ' + moment$1(this.endsAt).format('DD.MM.YYYY');
    }
    formattedStartDate() {
        return moment$1(this.startsAt).format('D MMMM');
    }
    formattedEndDate() {
        return moment$1(this.endsAt).format('D MMMM');
    }
    imageFullUrl() {
        return LibConfiguration.imageUrlFromPath(this.image);
    }
    logoFullUrl() {
        return LibConfiguration.imageUrlFromPath(this.logo);
    }
}
class EventLocation {
    constructor(obj = {}) {
        var _a;
        Object.assign(this, obj);
        this.halls = ((_a = obj === null || obj === void 0 ? void 0 : obj.halls) === null || _a === void 0 ? void 0 : _a.map(h => new EventHall(h))) || [];
    }
}
class EventHall {
    constructor(obj = {}) {
        Object.assign(this, obj);
    }
}
class EventStall {
    constructor(obj = {}) {
        this.hall = null;
        Object.assign(this, obj);
        if (obj.hasOwnProperty('hall')) {
            this.hall = new EventHall(obj.hall);
        }
    }
}
class EventRestaurant {
    constructor(obj = {}) {
        this.restaurant = null;
        this.stall = null;
        Object.assign(this, obj);
        if (obj.hasOwnProperty('restaurant')) {
            this.restaurant = new Restaurant(obj.restaurant);
        }
        if (obj.hasOwnProperty('EventStall')) {
            this.stall = new EventStall(obj.stall);
        }
    }
}
class EventCompany {
    constructor(obj = {}) {
        this.billedLater = false;
        Object.assign(this, obj);
        if (obj.hasOwnProperty('event')) {
            this.stall = new EventStall(obj.stall);
        }
        if (obj.hasOwnProperty('stall')) {
            this.stall = new EventStall(obj.stall);
        }
        if (obj.hasOwnProperty('company')) {
            this.company = new Company(obj.company);
        }
    }
}

class FormHelper {
    static getFirstInvalidControlError(form) {
        const controls = form.controls;
        for (const name in controls) {
            if (controls[name].invalid) {
                return FormHelper.errors.hasOwnProperty(name) ? FormHelper.errors[name] : 'Un champ semble invalide, vérifier le formulaire et ressayez.';
            }
        }
        return null;
    }
    static checkPasswords(plainPassword, plainPasswordConfirmation) {
        const hasError = plainPasswordConfirmation.value !== plainPassword.value;
        const error = hasError ? { incorrect: true } : null;
        plainPasswordConfirmation.setErrors(error);
        return error;
    }
    static checkFieldValidity(control, condition) {
        const error = condition === false ? { incorrect: true } : null;
        control.setErrors(error);
        return error;
    }
}
FormHelper.errors = {
    firstname: 'La valeur du champ Prénom semble incorrecte.',
    lastname: 'La valeur du champ Nom semble incorrecte.',
    code: 'Le code que vous avez entré semble invalide. Il se comporte de 6 chiffres',
    email: 'La valeur du champ Email semble incorrecte.',
    mobilePhone: 'La valeur du champ Téléphone semble incorrecte.',
    message: 'La valeur du champ Message semble incorrecte.',
    oldPassword: 'La valeur du champ Ancien mot de passe semble incorrecte. Le mot de passe doit comporter au moins 5 caractères alpha-numériques.',
    plainPassword: 'La valeur du champ Mot de passe semble incorrecte. Le mot de passe doit comporter au moins 5 caractères alpha-numériques.',
    plainPasswordConfirmation: 'Les mots de passe ne correspondent pas, vérifiez qu\'ils soient bien identiques.',
    companyCode: 'Le code que vous avez entré semble incorrect.',
    reference: 'La référence de commande que vous avez entrée semble incorrecte.',
    serverIP: 'La valeur du champ IP semble incorrecte.'
};

class OrderHelper {
    static getNextTimelineStatuses(status) {
        const index = OrderHelper.orderStatusTimeline.indexOf(status);
        const statuses = [];
        let i = 0;
        for (const s of OrderHelper.orderStatusTimeline) {
            if (s !== status && i > index) {
                statuses.push(s);
            }
            ++i;
        }
        return statuses;
    }
    static getPreviousTimelineStatuses(status) {
        const index = OrderHelper.orderStatusTimeline.indexOf(status);
        const statuses = [];
        let i = 0;
        for (const s of OrderHelper.orderStatusTimeline) {
            if (s !== status && i < index) {
                statuses.push(s);
            }
            ++i;
        }
        return statuses;
    }
}
OrderHelper.orderStatuses = {
    pending: {
        slug: 'pending',
        formatted: 'En attente de paiement'
    },
    confirmed: {
        slug: 'confirmed',
        formatted: 'Confirmée'
    },
    preparing: {
        slug: 'preparing',
        formatted: 'Préparation'
    },
    delivering: {
        slug: 'delivering',
        formatted: 'Livraison'
    },
    done: {
        slug: 'done',
        formatted: 'Terminée'
    }
};
OrderHelper.orderStatusTimeline = ['pending', 'confirmed', 'preparing', 'delivering', 'done'];

class VersionService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    getLastAppVersion() {
        return this.apiService.get('/version', false).pipe(map(result => new AppVersion(result)));
    }
    getLastManagerVersion() {
        return this.apiService.get('/api/manager/version', false, false).pipe(map(result => new ManagerVersion(result)));
    }
}
VersionService.ɵprov = i0.ɵɵdefineInjectable({ factory: function VersionService_Factory() { return new VersionService(i0.ɵɵinject(ApiService)); }, token: VersionService, providedIn: "root" });
VersionService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
VersionService.ctorParameters = () => [
    { type: ApiService }
];

class RestaurantService {
    constructor(apiService) {
        this.apiService = apiService;
        this.selectedRestaurant = new BehaviorSubject(null);
        this.selectedRestaurant.next(RestaurantService.getFromLocalStorage());
    }
    static getFromLocalStorage() {
        const restaurant = JSON.parse(localStorage.getItem('selected_restaurant'));
        return restaurant ? new Restaurant(restaurant) : null;
    }
    save() {
        localStorage.setItem('selected_restaurant', JSON.stringify(this.selectedRestaurant.value));
    }
    list() {
        return this.apiService.get('/restaurants', false).pipe(map((result) => {
            const restaurants = result.map(r => new Restaurant(r));
            if (restaurants.length > 0) {
                if (this.selectedRestaurant.value) {
                    const restaurant = restaurants.find(r => r.id === RestaurantService.getFromLocalStorage().id);
                    if (restaurant) {
                        this.selectRestaurant(restaurant);
                    }
                    else {
                        this.selectRestaurant(null);
                    }
                }
            }
            return restaurants;
        }));
    }
    isProductAvailable(product) {
        for (const stock of product.stocks) {
            if (this.selectedRestaurant.value && stock.restaurant.id === this.selectedRestaurant.value.id) {
                return stock.hasStock;
            }
        }
        return true;
    }
    selectRestaurant(restaurant) {
        this.selectedRestaurant.next(restaurant);
        this.save();
    }
    update(restaurantId, data) {
        return this.apiService.put('/restaurants/' + restaurantId, data, true);
    }
    changeStock(restaurantId, productId, hasStock) {
        return this.apiService.put('/restaurant-stocks', {
            restaurant: restaurantId,
            product: productId,
            stock: hasStock
        }, true);
    }
    getStats(restaurantId, date) {
        return this
            .apiService.get('/restaurants/' + restaurantId + '/stats?date=' + date, true)
            .pipe(map(result => new RestaurantStats(result)));
    }
    generateSlots(restaurantId) {
        return this.apiService.post('/delivery/restaurant/' + restaurantId + '/generate', {}, true).pipe(map(nextSlots => {
            return new NextDeliverySlots(nextSlots);
        }));
    }
    /**
    * @deprecated The method should not be used
    */
    getTeams() {
        return this.apiService.get('/restaurants/' + this.selectedRestaurant.value.id + '/teams', true).pipe(map((teams) => {
            return teams.map(t => new Team(t));
        }));
    }
}
RestaurantService.ɵprov = i0.ɵɵdefineInjectable({ factory: function RestaurantService_Factory() { return new RestaurantService(i0.ɵɵinject(ApiService)); }, token: RestaurantService, providedIn: "root" });
RestaurantService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
RestaurantService.ctorParameters = () => [
    { type: ApiService }
];

class SessionService {
    constructor(apiService, restaurantService) {
        this.apiService = apiService;
        this.restaurantService = restaurantService;
    }
    getLastSessionHashes() {
        return this.apiService.get('/restaurants/' + this.restaurantService.selectedRestaurant.value.id + '/hashes/last', true).pipe(map((hashes) => {
            return hashes;
        }));
    }
    openSession(restaurantId) {
        return this.apiService.post('/sessions/restaurants/' + restaurantId + '/open', {}, true).pipe(map(s => {
            return new Session(s);
        }));
    }
    closeSession(restaurantId, data) {
        return this.apiService.post('/sessions/restaurants/' + restaurantId + '/close', data, true).pipe(map(s => {
            return new Session(s);
        }));
    }
    getSessionHash(sessionId) {
        return this.apiService.get('/sessions/' + sessionId + '/hash-key', true);
    }
    getOpenedSession(restaurantId) {
        return this.apiService.get('/sessions/restaurants/' + restaurantId + '/opened', true).pipe(map(s => {
            return (s === null || s === void 0 ? void 0 : s.id) ? new Session(s) : null;
        }));
    }
}
SessionService.ɵprov = i0.ɵɵdefineInjectable({ factory: function SessionService_Factory() { return new SessionService(i0.ɵɵinject(ApiService), i0.ɵɵinject(RestaurantService)); }, token: SessionService, providedIn: "root" });
SessionService.decorators = [
    { type: Injectable, args: [{ providedIn: 'root' },] }
];
SessionService.ctorParameters = () => [
    { type: ApiService },
    { type: RestaurantService }
];

class EventService {
    constructor(apiService) {
        this.apiService = apiService;
        this.selectedEvent = new BehaviorSubject(null);
        this.selectedEvent.next(EventService.getFromLocalStorage());
    }
    static getFromLocalStorage() {
        const event = JSON.parse(localStorage.getItem('selected_event'));
        return event ? new Event(event) : null;
    }
    save() {
        localStorage.setItem('selected_event', JSON.stringify(this.selectedEvent.value));
    }
    list() {
        return this.apiService.get('/events', false).pipe(map((result) => {
            const events = result.map(r => new Event(r));
            if (events.length > 0) {
                if (this.selectedEvent.value) {
                    const event = events.find(e => e.id === EventService.getFromLocalStorage().id);
                    if (event) {
                        this.selectEvent(event);
                    }
                    else {
                        this.selectEvent(null);
                    }
                }
            }
            return events;
        }));
    }
    selectEvent(event) {
        this.selectedEvent.next(event);
        this.save();
    }
    getEventRestaurantByRestaurantId(id) {
        return this.selectedEvent.value.eventRestaurants.find(r => r.restaurant.id === id);
    }
}
EventService.ɵprov = i0.ɵɵdefineInjectable({ factory: function EventService_Factory() { return new EventService(i0.ɵɵinject(ApiService)); }, token: EventService, providedIn: "root" });
EventService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
EventService.ctorParameters = () => [
    { type: ApiService }
];

class ClientService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    get() {
        return this.apiService.get('', true).pipe(map((client) => {
            return (client === null || client === void 0 ? void 0 : client.id) ? new Client(client) : null;
        }));
    }
    getConfig() {
        return this.apiService.get('/config', true).pipe(map((clientConfig) => {
            return (clientConfig === null || clientConfig === void 0 ? void 0 : clientConfig.id) ? new ClientConfig(clientConfig) : null;
        }));
    }
    getBilling() {
        return this.apiService.get('/billing', true).pipe(map((clientBilling) => {
            return new ClientBilling(clientBilling);
        }));
    }
}
ClientService.ɵprov = i0.ɵɵdefineInjectable({ factory: function ClientService_Factory() { return new ClientService(i0.ɵɵinject(ApiService)); }, token: ClientService, providedIn: "root" });
ClientService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ClientService.ctorParameters = () => [
    { type: ApiService }
];

class CompanyService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    search(searchedCompany) {
        return this.apiService.get('/companies/search?q=' + searchedCompany, true).pipe(map((companies) => {
            return companies.map(c => new Company(c));
        }));
    }
    get(companyId) {
        return this.apiService.get('/companies/' + companyId, true).pipe(map((company) => {
            return new Company(company);
        }));
    }
}
CompanyService.ɵprov = i0.ɵɵdefineInjectable({ factory: function CompanyService_Factory() { return new CompanyService(i0.ɵɵinject(ApiService)); }, token: CompanyService, providedIn: "root" });
CompanyService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
CompanyService.ctorParameters = () => [
    { type: ApiService }
];

class CategoryService {
    constructor(apiService, restaurantService) {
        this.apiService = apiService;
        this.restaurantService = restaurantService;
        this.shoppingCart = null;
    }
    list() {
        return this.apiService.get('/restaurants/' + this.restaurantService.selectedRestaurant.value.id + '/products', false).pipe(map((categories) => {
            return categories.map(c => new Category(c));
        }));
    }
    first() {
        return this.apiService.get('/restaurants/' + this.restaurantService.selectedRestaurant.value.id + '/product-categories/first', false).pipe(map((category) => {
            return new Category(category);
        }));
    }
    buildCategoriesFromMenuData(data, restaurant) {
        var _a, _b;
        const categories = data.categories;
        for (let c of categories) {
            const menus = (_a = data.menus) === null || _a === void 0 ? void 0 : _a.filter(m => m.category === c.id);
            const products = (_b = data.products) === null || _b === void 0 ? void 0 : _b.filter(p => p.category === c.id);
            const lightRestaurant = new Restaurant({
                id: restaurant.id
            });
            if ((menus === null || menus === void 0 ? void 0 : menus.length) > 0) {
                c.menus = menus;
            }
            if ((products === null || products === void 0 ? void 0 : products.length) > 0) {
                c.products = products;
                for (let i of c.ingredients) {
                    i.stocks = data.stocks.filter((s) => s.entity === i.id);
                    for (let s of i.stocks) {
                        s.restaurant = lightRestaurant;
                    }
                }
                for (let p of c.products) {
                    p.choiceGroups = data.choices.filter((c) => c.product === p.id);
                    p.stocks = data.stocks.filter((s) => s.entity === p.id);
                    for (let s of p.stocks) {
                        s.restaurant = lightRestaurant;
                    }
                    for (let i of p.ingredients) {
                        i.stocks = data.stocks.filter((s) => s.entity === i.id);
                        for (let s of i.stocks) {
                            s.restaurant = lightRestaurant;
                        }
                    }
                    for (let cg of p.choiceGroups) {
                        for (let c of cg.choices) {
                            c.stocks = data.stocks.filter((s) => s.entity === c.id);
                            for (let s of c.stocks) {
                                s.restaurant = lightRestaurant;
                            }
                            if (c.ingredient) {
                                c.ingredient.stocks = data.stocks.filter((s) => s.entity === c.ingredient.id);
                                for (let s of c.ingredient.stocks) {
                                    s.restaurant = lightRestaurant;
                                }
                            }
                        }
                    }
                }
            }
        }
        return categories.map(c => new Category(c)).filter(c => { var _a, _b; return ((_a = c.products) === null || _a === void 0 ? void 0 : _a.length) > 0 || ((_b = c.menus) === null || _b === void 0 ? void 0 : _b.length) > 0 || c.canCreateProductOnPos; });
    }
}
CategoryService.ɵprov = i0.ɵɵdefineInjectable({ factory: function CategoryService_Factory() { return new CategoryService(i0.ɵɵinject(ApiService), i0.ɵɵinject(RestaurantService)); }, token: CategoryService, providedIn: "root" });
CategoryService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
CategoryService.ctorParameters = () => [
    { type: ApiService },
    { type: RestaurantService }
];

class ProductService {
    constructor(apiService, restaurantService) {
        this.apiService = apiService;
        this.restaurantService = restaurantService;
    }
    getChoices(restaurantId) {
        return this.apiService.get('/sync2/restaurants/' + restaurantId + '/choices', true).pipe(map((choices) => {
            return choices.map(c => new ProductChoiceGroup(c));
        }));
    }
    get(productId) {
        return this.apiService.get('/products/' + productId, false).pipe(map((product) => {
            return new Product(product);
        }));
    }
}
ProductService.ɵprov = i0.ɵɵdefineInjectable({ factory: function ProductService_Factory() { return new ProductService(i0.ɵɵinject(ApiService), i0.ɵɵinject(RestaurantService)); }, token: ProductService, providedIn: "root" });
ProductService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ProductService.ctorParameters = () => [
    { type: ApiService },
    { type: RestaurantService }
];

const moment = moment_;
class ShoppingCartService {
    constructor(apiService, restaurantService) {
        this.apiService = apiService;
        this.restaurantService = restaurantService;
        this.shoppingCart = null;
        const shoppingCart = JSON.parse(localStorage.getItem('shopping_cart'));
        if ((shoppingCart === null || shoppingCart === void 0 ? void 0 : shoppingCart.createdAt) && moment().diff(moment(shoppingCart.createdAt), 'hours') < 24) {
            this.shoppingCart = new ShoppingCart(shoppingCart);
            return;
        }
        this.createNewShoppingCart();
    }
    createNewShoppingCart() {
        this.shoppingCart = new ShoppingCart({ createdAt: moment().format() });
        this.save();
    }
    getOptions() {
        return this.apiService.get('/shopping-cart-options').pipe(map(options => {
            return options.map(o => new ShoppingCartOption(o));
        }));
    }
    getOptionsByRestaurant(restaurantId) {
        return this.apiService.get('/restaurants/' + restaurantId + '/shopping-cart-options').pipe(map(options => {
            return options.map(o => new ShoppingCartOption(o));
        }));
    }
    count() {
        return this.shoppingCart ? this.shoppingCart.items.length : 0;
    }
    save() {
        localStorage.setItem('shopping_cart', JSON.stringify(this.shoppingCart));
    }
    set(shoppingCartItems) {
        this.shoppingCart.items = shoppingCartItems;
        this.save();
    }
    add(shoppingCartItem) {
        shoppingCartItem.id = v4();
        this.shoppingCart.items.push(shoppingCartItem);
        this.save();
    }
    reorderItemsByCategories(categories) {
        const filteredCategories = categories.filter(c => this.shoppingCart.items.findIndex(sc => sc.base.category.id === c.id) !== -1);
        const shoppingCartItemsOrderedByCategories = {};
        for (const c of filteredCategories) {
            shoppingCartItemsOrderedByCategories[c.id] = this.shoppingCart.items.filter(sc => sc.base.category.id === c.id);
        }
        const shoppingCartItemsReordered = [];
        for (const value of Object.values(shoppingCartItemsOrderedByCategories)) {
            for (const i of value) {
                shoppingCartItemsReordered.push(i);
            }
        }
        if (shoppingCartItemsReordered.length !== this.shoppingCart.items.length) {
            return;
        }
        this.set(shoppingCartItemsReordered);
    }
    update(shoppingCartItem) {
        const index = this.shoppingCart.items.findIndex(i => i.id === shoppingCartItem.id);
        this.shoppingCart.items[index] = shoppingCartItem;
        const unvalidItemIndex = this.shoppingCart.unvalidItems.findIndex(i => i === shoppingCartItem.id);
        if (unvalidItemIndex !== -1) {
            this.shoppingCart.unvalidItems.splice(unvalidItemIndex, 1);
        }
        this.save();
    }
    remove(shoppingCartItem) {
        const index = this.shoppingCart.items.findIndex(i => i.id === shoppingCartItem.id);
        this.shoppingCart.items.splice(index, 1);
        this.save();
    }
    getCountByProductId(productId) {
        let count = 0;
        for (const i of this.shoppingCart.items) {
            if (i.base.product.id === productId) {
                count += i.base.quantity;
            }
        }
        return count;
    }
    getItems() {
        return this.shoppingCart.items;
    }
    total() {
        let total = 0;
        for (const item of this.shoppingCart.items) {
            total += item.total();
        }
        return total;
    }
    vat() {
        let vat = 0;
        for (const item of this.shoppingCart.items) {
            vat += item.vat() * item.base.quantity;
        }
        return vat;
    }
    emptyCart() {
        this.createNewShoppingCart();
        this.save();
    }
    convertToOrderItem(item, type = 'product') {
        var _a, _b;
        const choiceGroups = [];
        for (const cg of Object.values(item.choiceGroups)) {
            const choices = [];
            for (const c of cg.choices) {
                choices.push(new OrderItemChoice({
                    id: v4(),
                    name: c.choice.name,
                    price: c.choice.price,
                    quantity: c.quantity,
                    total: c.choice.price * c.quantity
                }));
            }
            if (choices.length > 0) {
                choiceGroups.push(new OrderItemChoiceGroup({
                    id: v4(),
                    name: cg.base.name,
                    choices
                }));
            }
        }
        if (((_a = item.ingredientsToAdd) === null || _a === void 0 ? void 0 : _a.length) > 0) {
            const choices = [];
            for (const i of Object.values(item.ingredientsToAdd)) {
                choices.push(new OrderItemChoice({
                    id: v4(),
                    name: i.name,
                    price: i.price,
                    quantity: 1,
                    total: i.price
                }));
            }
            if (choices.length > 0) {
                choiceGroups.push(new OrderItemChoiceGroup({
                    id: v4(),
                    name: 'Suppléments',
                    choices
                }));
            }
        }
        if (((_b = item.ingredientsToRemove) === null || _b === void 0 ? void 0 : _b.length) > 0) {
            const choices = [];
            for (const i of Object.values(item.ingredientsToRemove)) {
                choices.push(new OrderItemChoice({
                    id: v4(),
                    name: i.name,
                    price: i.price,
                    quantity: 1,
                    total: i.price
                }));
            }
            if (choices.length > 0) {
                choiceGroups.push(new OrderItemChoiceGroup({
                    id: v4(),
                    name: 'Retirer',
                    choices
                }));
            }
        }
        return new OrderItem({
            id: v4(),
            type,
            name: item.base.product.name,
            category: item.base.category.name,
            originCategory: new Category({
                id: item.base.category.id,
                name: item.base.category.name,
                tags: item.base.category.tags,
                productionPriority: item.base.category.productionPriority
            }),
            product: item.base.product.name,
            originProduct: new Product({
                id: item.base.product.id,
                name: item.base.product.name,
                productionPriority: item.base.product.productionPriority,
                tags: item.base.product.tags
            }),
            quantity: item.base.quantity,
            price: item.base.product.price,
            vat: Math.round(item.vat()),
            vatRate: {
                id: item.base.product.vatRate.id,
                name: item.base.product.vatRate.name,
                rate: item.base.product.vatRate.rate
            },
            choiceGroups
        });
    }
    isEnabled(c) {
        return c.stocks.find(s => s.isEnabled && s.restaurant.id === this.restaurantService.selectedRestaurant.value.id) !== undefined;
    }
    enabledChoices(choices) {
        return choices.filter(c => this.isEnabled(c));
    }
    availableChoices(cg) {
        const choices = [];
        for (const c of cg.choices) {
            if (this.hasStocks(c) && this.isEnabled(c)) {
                choices.push(c);
            }
        }
        return choices;
    }
    hasStocks(c) {
        if (c.stocks.length === 0) {
            return false;
        }
        return c.stocks.findIndex(s => s.hasStock && s.restaurant.id === this.restaurantService.selectedRestaurant.value.id) !== -1;
    }
    createShoppingCartItem(product, category, quantity = 1) {
        const choiceGroups = {};
        for (const cg of product.choiceGroups) {
            /*
            let choices = [];
            if (cg.required) {
                const availableChoices = this.availableChoices(cg);
                if (availableChoices?.length > 0) {
                    let defaultChoice = availableChoices.find(c => c.isDefault);
                    if (!defaultChoice) {
                        defaultChoice = availableChoices[0];
                    }
                    choices = [{ choice: defaultChoice, quantity: cg.minChoices > 0 ? cg.minChoices : 1 }];
                }
            }
            */
            choiceGroups[cg.id] = { base: cg, choices: [] };
        }
        return new ShoppingCartItem({
            base: {
                product,
                category,
                quantity
            },
            choiceGroups,
            ingredientsToRemove: [],
            ingredientsToAdd: []
        });
    }
}
ShoppingCartService.ɵprov = i0.ɵɵdefineInjectable({ factory: function ShoppingCartService_Factory() { return new ShoppingCartService(i0.ɵɵinject(ApiService), i0.ɵɵinject(RestaurantService)); }, token: ShoppingCartService, providedIn: "root" });
ShoppingCartService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ShoppingCartService.ctorParameters = () => [
    { type: ApiService },
    { type: RestaurantService }
];

class UserService {
    constructor(apiService) {
        this.apiService = apiService;
        UserService.loadUser();
    }
    static loadUser() {
        const user = localStorage.getItem('rm_user');
        const token = localStorage.getItem('rm_jwt_token');
        if (token && user) {
            ApiService.user = new User(JSON.parse(user));
            ApiService.token = token;
            ApiService.logged = true;
        }
        const client = localStorage.getItem('rm_client');
        if (client) {
            LibConfiguration.setClient(client);
        }
        UserService.userLogged.next(user !== null || false);
    }
    static saveUser(user) {
        ApiService.user = user;
        localStorage.setItem('rm_user', JSON.stringify(user));
    }
    static saveToken(token) {
        ApiService.logged = true;
        ApiService.token = token.token;
        localStorage.setItem('rm_jwt_token', token.token);
        if (token.hasOwnProperty('client') && token.client) {
            LibConfiguration.setClient(token.client);
            localStorage.setItem('rm_client', token.client);
        }
    }
    update(user) {
        return this.apiService
            .put('/users/' + user.id, user, true)
            .pipe(map((u) => {
            UserService.saveUser(u);
            return new User(u);
        }));
    }
    assignCompany(companyCode) {
        return this.apiService.post('/companies/assign', { code: companyCode }, true).pipe(map((user) => {
            return new User(user);
        }));
    }
    unlinkCompany() {
        return this.apiService.post('/companies/unlink', {}, true).pipe(map((user) => {
            return new User(user);
        }));
    }
    adminLogin(email, password, deviceId = null) {
        return this.apiService
            .post('/api/login', { email, password, deviceId }, false, false)
            .pipe(map((token) => {
            UserService.saveToken(token);
            return token;
        }));
    }
    adminLoginAndMe(email, password, deviceId = null) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                this.adminLogin(email, password, deviceId).subscribe((response) => {
                    this.me().subscribe(user => {
                        resolve(user);
                    }, err => {
                        reject(err);
                    });
                }, err => {
                    reject(err);
                });
            });
        });
    }
    loginAndMe(email, password) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                this.login(email, password).subscribe(token => {
                    this.me().subscribe(user => {
                        resolve(user);
                    }, err => {
                        reject(err);
                    });
                }, err => {
                    reject(err);
                });
            });
        });
    }
    registerLoginAndMe(userRegister) {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => {
                this.register(userRegister).subscribe((user) => __awaiter(this, void 0, void 0, function* () {
                    this.loginAndMe(userRegister.email, userRegister.plainPassword).then((loggedUser) => {
                        resolve(loggedUser);
                    }, err => {
                        reject(err);
                    });
                }), err => {
                    reject(err);
                });
            });
        });
    }
    logoutAndUnlinkUserLicence() {
        return __awaiter(this, void 0, void 0, function* () {
            return new Promise((resolve, reject) => __awaiter(this, void 0, void 0, function* () {
                this.apiService.post('/api/unlink-user-license', {}, true, false).subscribe((result) => {
                    this.logout();
                    resolve(result);
                }, err => {
                    reject(err);
                });
            }));
        });
    }
    me() {
        return this.apiService.get('/me', true).pipe(map(user => {
            UserService.saveUser(new User(user));
            UserService.userLogged.next(true);
            return new User(user);
        }));
    }
    login(email, password) {
        return this.apiService.post('/login', { email, password }).pipe(map((token) => {
            UserService.saveToken(token);
            return token;
        }));
    }
    register(userRegister) {
        return this.apiService.post('/register', userRegister).pipe(map((user) => {
            return new User(user);
        }));
    }
    isLogged() {
        return ApiService.logged && this.getUser() !== null;
    }
    isLoggedAsProUser() {
        return this.isLogged() && this.getUser() !== null && this.getUser().role === USER_ROLES.ROLE_PRO;
    }
    getUser() {
        return ApiService.user;
    }
    getUserById(id) {
        return this
            .apiService.get('/users/' + id, true)
            .pipe(map(result => new User(result)));
    }
    logout() {
        ApiService.logged = false;
        ApiService.user = null;
        ApiService.token = null;
        localStorage.removeItem('rm_user');
        localStorage.removeItem('rm_jwt_token');
        localStorage.removeItem('rm_client');
        UserService.userLogged.next(false);
    }
}
UserService.userLogged = new BehaviorSubject(false);
UserService.ɵprov = i0.ɵɵdefineInjectable({ factory: function UserService_Factory() { return new UserService(i0.ɵɵinject(ApiService)); }, token: UserService, providedIn: "root" });
UserService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
UserService.ctorParameters = () => [
    { type: ApiService }
];

class AddressService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    update(address) {
        return this.apiService
            .put('/addresses/' + address.id, address, true)
            .pipe(map(a => new Address(a)));
    }
    add(address) {
        return this.apiService
            .post('/addresses', address, true)
            .pipe(map(a => new Address(a)));
    }
    remove(address) {
        return this.apiService.delete('/addresses/' + address.id, true);
    }
    list() {
        return this.apiService
            .get('/addresses', true)
            .pipe(map(addr => addr.map(a => new Address(a))));
    }
}
AddressService.ɵprov = i0.ɵɵdefineInjectable({ factory: function AddressService_Factory() { return new AddressService(i0.ɵɵinject(ApiService)); }, token: AddressService, providedIn: "root" });
AddressService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
AddressService.ctorParameters = () => [
    { type: ApiService }
];

class DeliverySlotService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    next(restaurant) {
        return this.apiService.get('/delivery/restaurant/' + restaurant.id + '/next').pipe(map(nextSlots => {
            return new NextDeliverySlots(nextSlots);
        }));
    }
    list(restaurant) {
        return this.apiService
            .get('/delivery/restaurant/' + restaurant.id)
            .pipe(map(result => new DeliverySlots(result)));
    }
    listStatuses(restaurant) {
        return this.apiService
            .get('/delivery/restaurant/' + restaurant.id + '/statuses', true)
            .pipe(map(result => new DeliverySlots(result)));
    }
    update(deliverySlotId, isOpen) {
        return this.apiService
            .put('/delivery/' + deliverySlotId, { isOpen }, true);
    }
}
DeliverySlotService.ɵprov = i0.ɵɵdefineInjectable({ factory: function DeliverySlotService_Factory() { return new DeliverySlotService(i0.ɵɵinject(ApiService)); }, token: DeliverySlotService, providedIn: "root" });
DeliverySlotService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
DeliverySlotService.ctorParameters = () => [
    { type: ApiService }
];

class OrderService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    place(order) {
        return this
            .apiService.post('/orders', order, true)
            .pipe(map((result) => {
            return new Order(result);
        }));
    }
    assign(id) {
        return this.apiService
            .post('/orders/' + id + '/assign', {}, true)
            .pipe(map(r => new Order(r)));
    }
    assigned() {
        return this.apiService
            .get('/orders/assigned', true)
            .pipe(map(r => r.map(o => new Order(o))));
    }
    print(ids) {
        return this.apiService.post('/orders/print', { orders: ids }, true);
    }
    changeOrderStatus(order, status) {
        return this
            .apiService
            .put('/orders/' + order.id + '/status', { status }, true)
            .pipe(map(r => new Order(r)));
    }
    findCurrentByRestaurant(restaurant, deliverySlot = null) {
        return this
            .apiService
            .get('/orders/restaurant/' + restaurant.id + '/current?deliverySlot=' + deliverySlot, true)
            .pipe(map(orders => orders.map(o => new Order(o))));
    }
    getOrderById(id) {
        return this
            .apiService.get('/orders/' + id, true)
            .pipe(map(result => new Order(result)));
    }
    getOrderByRef(ref) {
        return this
            .apiService.get('/orders/ref/' + ref, true)
            .pipe(map(result => new Order(result)));
    }
    getOrdersByIds(restaurantId, ids) {
        return this
            .apiService
            .get('/restaurants/' + restaurantId + '/orders?ids=' + ids.join(','), true)
            .pipe(map(orders => orders.map(o => new Order(o))));
    }
    getOrdersByRestaurant(restaurantId, date, page, perPage = 100, sessionDate = null) {
        let route = '/restaurants/' + restaurantId + '/orders?date=' + date + '&page=' + page + '&perPage=' + perPage;
        if (sessionDate) {
            route += '&sessionDate=' + sessionDate;
        }
        return this
            .apiService
            .get(route, true)
            .pipe(map(p => new PaginatedResult(p, Order)));
    }
    list() {
        return this
            .apiService.get('/orders', true)
            .pipe(map(orders => orders.map(o => new Order(o))));
    }
    getNextSlotsOrders(restaurantId, statuses) {
        return this.apiService.get('/restaurants/' + restaurantId + '/next-slot/orders?statuses=' + statuses.join(','), true);
    }
    getExportData(params) {
        return this.apiService.get('/exports/orders?params=' + btoa(JSON.stringify(params)), true);
    }
}
OrderService.ɵprov = i0.ɵɵdefineInjectable({ factory: function OrderService_Factory() { return new OrderService(i0.ɵɵinject(ApiService)); }, token: OrderService, providedIn: "root" });
OrderService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
OrderService.ctorParameters = () => [
    { type: ApiService }
];

class TransactionService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    getTransactionById(id) {
        return this
            .apiService.get('/transactions/' + id, true)
            .pipe(map(result => new Transaction(result)));
    }
    getLatestTransactionByOrderId(id) {
        return this
            .apiService.get('/transactions/orders/' + id + '/latest', true)
            .pipe(map(result => new Transaction(result)));
    }
    markAsPaid(data) {
        return this.apiService.put('/transactions/pay', { ids: data }, true);
    }
}
TransactionService.ɵprov = i0.ɵɵdefineInjectable({ factory: function TransactionService_Factory() { return new TransactionService(i0.ɵɵinject(ApiService)); }, token: TransactionService, providedIn: "root" });
TransactionService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
TransactionService.ctorParameters = () => [
    { type: ApiService }
];

class PasswordService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    reset(email, method = 'link') {
        return this.apiService.post('/password/reset', { email, method }, false);
    }
    resetByCode(code, password) {
        return this.apiService.put('/password/reset/by-code', { code, password }, false);
    }
    resetPut(id, password) {
        return this.apiService.put('/password/reset/' + id, { password }, false);
    }
    change(oldPassword, newPassword) {
        return this.apiService.put('/password/change', { oldPassword, newPassword }, true);
    }
}
PasswordService.ɵprov = i0.ɵɵdefineInjectable({ factory: function PasswordService_Factory() { return new PasswordService(i0.ɵɵinject(ApiService)); }, token: PasswordService, providedIn: "root" });
PasswordService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
PasswordService.ctorParameters = () => [
    { type: ApiService }
];

class ContactService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    sendMessage(contact) {
        return this.apiService.post('/contact', contact);
    }
}
ContactService.ɵprov = i0.ɵɵdefineInjectable({ factory: function ContactService_Factory() { return new ContactService(i0.ɵɵinject(ApiService)); }, token: ContactService, providedIn: "root" });
ContactService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
ContactService.ctorParameters = () => [
    { type: ApiService }
];

class StockService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    update(data) {
        return this.apiService.put('/stocks/batch-update', data, true);
    }
}
StockService.ɵprov = i0.ɵɵdefineInjectable({ factory: function StockService_Factory() { return new StockService(i0.ɵɵinject(ApiService)); }, token: StockService, providedIn: "root" });
StockService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
StockService.ctorParameters = () => [
    { type: ApiService }
];

class IngredientService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    list() {
        return this.apiService.get('/ingredients').pipe(map(ingredients => {
            return ingredients.map(i => new ProductIngredient(i));
        }));
    }
}
IngredientService.ɵprov = i0.ɵɵdefineInjectable({ factory: function IngredientService_Factory() { return new IngredientService(i0.ɵɵinject(ApiService)); }, token: IngredientService, providedIn: "root" });
IngredientService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
IngredientService.ctorParameters = () => [
    { type: ApiService }
];

class DeviceTokenService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    add(t, restaurantId) {
        return this.apiService.post('/device-tokens/restaurants/' + restaurantId, { token: t }, true);
    }
    setDeviceToken(t) {
        return this.apiService.post('/device-tokens', { token: t }, true);
    }
}
DeviceTokenService.ɵprov = i0.ɵɵdefineInjectable({ factory: function DeviceTokenService_Factory() { return new DeviceTokenService(i0.ɵɵinject(ApiService)); }, token: DeviceTokenService, providedIn: "root" });
DeviceTokenService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
DeviceTokenService.ctorParameters = () => [
    { type: ApiService }
];

class WidgetService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    getWidgetByRestaurant(restaurantId, widgetSlug) {
        return this.apiService.get('/restaurants/' + restaurantId + '/widgets/' + widgetSlug, false).pipe(map((widget) => {
            return widget ? new Widget(widget) : null;
        }));
    }
}
WidgetService.ɵprov = i0.ɵɵdefineInjectable({ factory: function WidgetService_Factory() { return new WidgetService(i0.ɵɵinject(ApiService)); }, token: WidgetService, providedIn: "root" });
WidgetService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
WidgetService.ctorParameters = () => [
    { type: ApiService }
];

class RestaurantManagerModule {
}
RestaurantManagerModule.decorators = [
    { type: NgModule, args: [{
                imports: [
                    CommonModule,
                    HttpClientModule
                ]
            },] }
];

class EntityService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    static convertParams(params) {
        return btoa(JSON.stringify(params));
    }
    list(entity, params, type) {
        return this
            .apiService
            .get('/entities/' + entity + '?params=' + EntityService.convertParams(params), true)
            .pipe(map(p => new PaginatedResult(p, type)));
    }
    getAll(entity, params, type) {
        return this
            .apiService
            .get('/entities/' + entity + '?params=' + EntityService.convertParams(params), true)
            .pipe(map(result => result.map(e => new type(e))));
    }
    getById(entity, id, type) {
        return this
            .apiService.get('/entities/' + entity + '/' + id, true)
            .pipe(map(result => new type(result)));
    }
    update(entity, data, type) {
        const id = data.id;
        delete data.id;
        return this
            .apiService.put('/entities/' + entity + '/' + id, data, true)
            .pipe(map(result => new type(result)));
    }
    add(entity, data, type) {
        return this
            .apiService.post('/entities/' + entity, data, true)
            .pipe(map(result => new type(result)));
    }
    remove(entity, id) {
        return this.apiService.delete('/entities/' + entity + '/' + id, true);
    }
    reorder(data) {
        return this
            .apiService.post('/sort-entities', data, true)
            .pipe(map(result => result));
    }
}
EntityService.ɵprov = i0.ɵɵdefineInjectable({ factory: function EntityService_Factory() { return new EntityService(i0.ɵɵinject(ApiService)); }, token: EntityService, providedIn: "root" });
EntityService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
EntityService.ctorParameters = () => [
    { type: ApiService }
];

class SyncService {
    constructor(apiService, http) {
        this.apiService = apiService;
        this.http = http;
    }
    syncTags() {
        return this.apiService.get('/tags', true).pipe(map((tags) => {
            return tags.map(t => new Tag(t));
        }));
    }
    syncVats() {
        return this.apiService.get('/vats', true).pipe(map((vats) => {
            return vats.map(t => new VatRate(t));
        }));
    }
    syncCategories(restaurantId) {
        return this.apiService.get('/sync/restaurants/' + restaurantId + '/categories', true).pipe(map((categories) => {
            return categories.map(c => new Category(c));
        }));
    }
    syncMenu(restaurantId, filterBy = null) {
        return __awaiter(this, void 0, void 0, function* () {
            const filter = filterBy ? '?filter=' + filterBy : '';
            let [categories, menus, products, choices, stocks] = yield Promise.all([
                this.apiService.get('/sync2/restaurants/' + restaurantId + '/categories' + filter, true).toPromise(),
                this.apiService.get('/sync2/restaurants/' + restaurantId + '/menus' + filter, true).toPromise(),
                this.apiService.get('/sync2/restaurants/' + restaurantId + '/products' + filter, true).toPromise(),
                this.apiService.get('/sync2/restaurants/' + restaurantId + '/choices', true).toPromise(),
                this.apiService.get('/sync2/restaurants/' + restaurantId + '/stocks', true).toPromise()
            ]);
            // Map entities
            categories = categories.map(c => new Category(c));
            menus = menus.map(m => new Menu(m));
            products = products.map(p => new Product(p));
            choices = choices.map(c => new ProductChoiceGroup(c));
            stocks = stocks.map(s => new Stock(s));
            // Rebuild products with originCategory
            for (const p of products) {
                const c = categories.find(c => c.id === p.category);
                if (c) {
                    p.originCategory = new Category({
                        id: c.id,
                        slug: c.slug,
                        name: c.name,
                        productionPriority: c.productionPriority
                    });
                }
            }
            return {
                categories,
                menus,
                products,
                choices,
                stocks
            };
        });
    }
    syncOrders(orders, restaurantId) {
        return this.apiService.post('/sync/restaurants/' + restaurantId + '/orders', orders, true).pipe(map((orders) => {
            return orders.map(o => new Order(o));
        }));
    }
    getSessionUploadParameters(sessionId) {
        return this.apiService.get('/sync/sessions/' + sessionId + '/upload-url', true).pipe(map((result) => {
            return result;
        }));
    }
    uploadSession(url, data) {
        let headers = new HttpHeaders();
        headers = headers.append('Content-Type', 'multipart/form-data');
        return this.http.put(url, data, { headers });
    }
}
SyncService.ɵprov = i0.ɵɵdefineInjectable({ factory: function SyncService_Factory() { return new SyncService(i0.ɵɵinject(ApiService), i0.ɵɵinject(i1.HttpClient)); }, token: SyncService, providedIn: "root" });
SyncService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
SyncService.ctorParameters = () => [
    { type: ApiService },
    { type: HttpClient }
];

class LicenseService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    get() {
        return this.apiService.get('/my-license', true).pipe(map(result => (result === null || result === void 0 ? void 0 : result.id) ? new License(result) : null));
    }
    getById(id) {
        return this.apiService.get('/licenses/' + id, true).pipe(map(result => (result === null || result === void 0 ? void 0 : result.id) ? new License(result) : null));
    }
}
LicenseService.ɵprov = i0.ɵɵdefineInjectable({ factory: function LicenseService_Factory() { return new LicenseService(i0.ɵɵinject(ApiService)); }, token: LicenseService, providedIn: "root" });
LicenseService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
LicenseService.ctorParameters = () => [
    { type: ApiService }
];

class InvoiceService {
    constructor(apiService) {
        this.apiService = apiService;
    }
    generate(restaurantId, data) {
        return this.apiService.post('/restaurants/' + restaurantId + '/invoice', data, true).pipe(map((result) => {
            return result;
        }));
    }
}
InvoiceService.ɵprov = i0.ɵɵdefineInjectable({ factory: function InvoiceService_Factory() { return new InvoiceService(i0.ɵɵinject(ApiService)); }, token: InvoiceService, providedIn: "root" });
InvoiceService.decorators = [
    { type: Injectable, args: [{
                providedIn: 'root'
            },] }
];
InvoiceService.ctorParameters = () => [
    { type: ApiService }
];

const PRODUCT_DEFAULT_THUMB = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdYAAAHWCAYAAADKGqhaAAAABHNCSVQICAgIfAhkiAAAHvZJREFUeF7t3TuvZkl1BuCDISDAvwiJCAkCAqQZW05IMLJDy//EcuaAcUAyFiAREIBESsyfISDAl33GfWZO93R3rW+vtWvX5WnpwGhm7dpVz1pfvfPNBb7x5BcBAgQIECBQJvCNspUsRIAAAQIECDwJVkNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM/BRgf99evr0KPjk+PnJMSx/xUVgV4Hjs/Ct4+y/OH5+fXwWfrWrg3O3BQRr22jbiuMieQ7Uz4+f5wvl+SL5h2Ng/ntbEAffVuD4LHzzzWfh+U80n/8E80fHZ+H324I4+EcFBKsBea/AcZH84PgDv30Tqi81wtW8bCfwTqi+nP8vx2/8WLhuNw6hAwvWENNeRW9C9TfHqb/9npML173GYevTfiBUhevWU9E+vGBtG21VcVwk3z0O/IcPhKpvrltNw96HbYTq63D9/nGR/nFvLad/LSBYzcOXAm9C9XfH7/hOgMU31wCSkjkFgqH6crg/H7/xQ+E6Z6+v2LVgvUJ1wjUfDFXfXCfssS3HBB4M1dfh+r3jQv1T7C2qVhYQrCt394GzHZfJfxzl//TAI1+G6zFEf3fiOY8QGFLg+Cz88tjY8z/9++ivfzs+C//66EPq1xMQrOv19NSJTv5Zum+up7Q9NKJA8jPw2XGmnx0X6rGMX7sLCNbdJ+DV+ZMXi7/napamFUjOvlCdtvPXbFywXuM67arJC0a4Ttv5fTeenHmhuu/ofPDkgtVQfE0gedEIVzM1jUBy1oXqNJ3uu1HB2td7mrclLxzhOk2n991ocsaF6r6j0zy5YG0S7VuQvHiE676jM/zJk7MtVIfv8L0bFKz3+g//9uQFJFyH7/B+G0zOtFDdb2QePrFgfZhsvweSF5Fw3W9khj1xcpaF6rCdHWtjgnWsfgy7m+SFJFyH7ew+G0vOsFDdZ1TSJxWsacJ9FkheTMJ1n1EZ7qTJ2RWqw3V07A0J1rH7M9zukheUcB2uo+tvKDmzQnX9ESk/oWAtJ11/weRFJVzXH5FhTpicVaE6TCfn2ohgnatfw+w2eWEJ12E6ue5GkjMqVNcdjctPJlgvJ173BcmLS7iuOxq3nyw5m0L19g7OvQHBOnf/bt998gITrrd3cL0NJGdSqK43Et1PJFi7k6/3wuRFJlzXG4nbTpScRaF6W+fWerFgXauft50meaEJ19s6t86LkzMoVNcZhdtPIlhvb8E6G0hebMJ1nVHofpLk7AnV7h1b+4WCde3+dj9d8oITrt07Nv8LkzMnVOcfgeFOIFiHa8n8G0pedMJ1/hHodoLkrAnVbp3a60WCda9+dztt8sITrt06Ne+LkjMmVOdt/fA7F6zDt2jeDSYvPuE6b+sv33lytoTq5R3a+wWCde/+X3765AUoXC/v0HwvSM6UUJ2v5dPtWLBO17L5Npy8CIXrfC2/bMfJWRKql3XGwq8FBKt56CKQvBCFa5cujf2S5AwJ1bHbu9TuBOtS7Rz7MMmLUbiO3d5Ld5ecHaF6aXcs/q6AYDUTXQWSF6Rw7dqtMV6WnBmhOkYbt9qFYN2q3WMcNnlRCtcx2thlF8lZEapduuQlvrGagSEEkhemcB2ii9duIjkjQvXa9lj9IwK+sRqP2wSSF6dwva1z1784ORtC9foWeYNgNQOjCiQvUOE6amMT+0rOhFBN2Hu0RsA31hpHqyQEkhepcE3Yj/ZochaE6mgN3XQ/gnXTxo927OSFKlxHa+iJ/SRnQKieMPfINQKC9RpXq54QSF6swvWE+SiPJHsvVEdppH18ISBYDcJQAskLVrgO1c3YZpI9F6oxZlUdBQRrR2yvigkkL1rhGmMeoirZa6E6RBdt4l0BwWomhhRIXrjCdciuvr2pZI+F6gQ93nWLgnXXzk9w7uTFK1wH7nGyt0J14N7amr/HagYGF0hewMJ1wP4meypUB+ypLb0t4BuriRheIHkRC9eBOpzspVAdqJe28mEBwWo6phBIXsjCdYAuJ3soVAfooS3EBARrzEnVAALJi1m43tjDZO+E6o298+rHBQTr42aeuFEgeUEL1xt6l+yZUL2hZ16ZExCsOT9P3yCQvKiFa8eeJXslVDv2yqvqBARrnaWVOgokL2zh2qFXyR4J1Q498oprBATrNa5W7SCQvLiF64U9SvZGqF7YG0tfLyBYrzf2hgsFkhe4cL2gN8meCNULemLJvgKCta+3t10gkLzIhWthT5K9EKqFvbDUfQKC9T57by4USF7owrWgF8keCNWCHlhiDAHBOkYf7KJAIHmxC9dED5L2QjVh79HxBATreD2xo4RA8oIXrifsk+ZC9YS5R8YWEKxj98fuTggkL3rh+oB50lqoPmCtdB4BwTpPr+z0AYHkhS9cA9ZJY6EaMFYyp4BgnbNvdh0QSF78wvUjxklboRqYXyXzCgjWeXtn5wGBZAAI1/cYJ02FamBulcwtIFjn7p/dBwSSQSBcXxknLYVqYF6VzC8gWOfvoRMEBJKBIFwP46ShUA3MqZI1BATrGn10ioBAMhi2DteknVANzKeSdQQE6zq9dJKAQDIgtgzXpJlQDcylkrUEBOta/XSagEAyKLYK16SVUA3Mo5L1BATrej11ooBAMjC2CNekkVANzKGSNQUE65p9daqAQDI4lg7XpI1QDcyfknUFBOu6vXWygEAyQJYM16SJUA3MnZK1BQTr2v11uoBAMkiWCtekhVANzJuS9QUE6/o9dsKAQDJQlgjXpIFQDcyZkj0EBOsefXbKgEAyWKYO1+TZhWpgvpTsIyBY9+m1kwYEkgEzZbgmzyxUA3OlZC8BwbpXv502IJAMmqnCNXlWoRqYJyX7CQjW/XruxAGBZOBMEa7JMwrVwBwp2VNAsO7Zd6cOCCSDZ+hwTZ5NqAbmR8m+AoJ13947eUAgGUBDhmvyTEI1MDdK9hYQrHv33+kDAskgGipck2cRqoF5UUJAsJoBAgGBZCANEa7JMwjVwJwoIfAsIFjNAYGgQDKYbg3X5N6FanBGlBEQrGaAwIMCyYC6JVyTexaqD86IcgK+sZoBAg8KJIOqa7gm9ypUH5wN5QR8YzUDBE4KJAOrS7gm9yhUT86Gxwj4xmoGCJwUSAbXc7j+/fEBPJap/5Xcm1Ctb4kVNxIQrBs121HrBUYMsBH3VC9vRQLjCgjWcXtjZ5MIjBRkI+1lkvbZJoFyAcFaTmrBHQVGCLQR9rBj752ZwLsCgtVMECgSuDPY7nx3EZ9lCCwjIFiXaaWDjCBwR8Dd8c4RrO2BwKgCgnXUztjXtAI9g67nu6ZtiI0T6CwgWDuDe90eAj0Cr8c79uiWUxKoFRCstZ5WI/ClwJXBd+XaWkiAQE5AsOb8PE3gowJXBOAVa2ojAQJ1AoK1ztJKBN4rUBmElWtpFwEC1wgI1mtcrUrgLYGKQDwW/Jvj5/Pj59MTvP5nCk+geYTAGQHBekbNMwROCCTD9T+PV/6tUD0B7xECnQUEa2dwr9tbIBmuZ/B8Uz2j5hkCCQHBmsDzKIEzAh3DVaieaZBnCCQFBGsS0OMEzgh0CFeheqYxniFQICBYCxAtQeCMwIXhKlTPNMQzBIoEBGsRpGUInBG4IFyF6plGeIZAoYBgLcS0FIEzAoXhKlTPNMAzBIoFBGsxqOUInBF4E67/dTz7yZnnj2eE6kk4jxGoFhCs1aLWI3BCQLCeQPMIgUEFBOugjbGtfQT8peB9eu2kewgI1j367JSDChSG6ssJ/SXhQXttW/sICNZ9eu2kgwlcEKrCdbAe286eAoJ1z7479c0CF4aqcL25t15PQLCaAQKdBTqEqnDt3FOvI/BaQLCaBwIdBTqGqnDt2FevIiBYzQCBGwSSoer/Nu6GnnklgTMCvrGeUfMMgQcFkqH6xT/pe/z4Pzp/0F05gTsEBOsd6t65lUBFqB4f1GOZL/7jm8d/fX78fHoC0b+KcwLNIwQeFRCsj4qpJ/CAwBVBeMWaDxxJKQECDQHBakQIXCRwZQBeufZFHJYlsI2AYN2m1Q7aU6BH8PV4R08z7yKwioBgXaWTzjGMQM/A6/muYYBthMDgAoJ18AbZ3lwCdwTdHe+cqyt2S6CvgGDt6+1tCwvcGXB3vnvhljoagVMCgvUUm4cIvC0wQrCNsAdzQYDA05NgNQUEkgIjBdpIe0myepzAtAKCddrW2fgIAiMG2Yh7GqFX9kCgl4Bg7SXtPcsJjBxgI+9tuUFwIALvCAhWI0HghMAMwTXDHk/Qe4TA8AKCdfgW2eBoAjMF1kx7Ha3P9kPgrIBgPSvnuS0FZgyqGfe85XA59DICgnWZVjrI1QIzB9TMe7+6r9YnUC0gWKtFrbekwArBtMIZlhwuh1pOQLAu11IHqhZYKZBWOkt1n61HoEpAsFZJWmdJgRWDaMUzLTl8DjWtgGCdtnU2frXAygG08tmungvrE2gJCNaWkD++pcAOwbPDGbccXoe+XUCw3t4CGxhNYKfA2emso82Z/awrIFjX7a2TnRDYMWh2PPOJ0fAIgbCAYA1TKVxdYOeA2fnsq8+18/UXEKz9zb1xQAHB8vTEYMDBtKUpBQTrlG2z6UoBgfKVJovKybLWrgKCddfOO/cXAoLk64PAxIeDQE5AsOb8PD2xgAD5cPPYTDzYtn67gGC9vQU2cIeA4GirM2obqSDwPgHBai62ExAY8ZazilupJPAiIFjNwlYCguLxdjN73MwTewsI1r37v9XpBcT5drM7b+fJ/QQE63493/LEgiHfdoZ5QyvsISBY9+jz1qcUCHXtZ1lnaaV1BQTrur11skNAENSPAdN6UyuuJSBY1+qn07wSEADXjQPb62ytPL+AYJ2/h07wHgEX//Vjwfh6Y2+YU0Cwztk3u/6IgAu/33iw7mftTfMICNZ5emWnAQEXfQCpuIR5MajlphcQrNO30AFeBFzw980C+/vsvXk8AcE6Xk/s6ISAi/0EWvEjelAMarlpBQTrtK2zcd9Ux5sB4TpeT+yov4Bg7W/ujYUCLvJCzKKl9KQI0jLTCgjWaVtn4y7wcWdAb8btjZ1dLyBYrzf2hgsEXNwXoBYvqUfFoJabRkCwTtMqG/X3VOebAeE6X8/sOC8gWPOGVugo4KLuiF30Kj0rgrTMNAKCdZpW2agLet4Z0Lt5e2fnjwsI1sfNPHGDgIv5BvTiV+phMajlhhUQrMO2xsb8PdX1ZkC4rtdTJ/q6gGA1FUMLuIiHbs+pzenpKTYPTSQgWCdq1m5bdQGv23G9Xbe3Tvb0JFhNwZACLt4h21K6KT0u5bTYQAKCdaBm2Mr/C7hw95kEvd6n1zudVLDu1O0JzuqinaBJxVvU82JQy90uIFhvb4ENvAi4YPedBb3ft/crnlywrtjVCc/kYp2wacVbNgPFoJa7TUCw3kbvxb6pmoF3BYSrmVhBQLCu0MWJz+Ainbh5F23dTFwEa9luAoK1G7UX+XZiBqICwjUqpW5EAcE6Ylc22JOLc4MmJ49oRpKAHr9NQLDeRr/vi12Y+/b+0ZOblUfF1I8gIFhH6MJGe3BRbtTsoqOamSJIy3QTEKzdqL3IBWkGzgqYnbNynrtDQLDeob7hO12MGza9+MhmqBjUcpcJCNbLaC38IuBCNAtVAmapStI6VwoI1it1re1/UN8MlAsI13JSCxYLCNZiUMt9JeACNA1XCZitq2StWyEgWCsUrfE1ARefobhawIxdLWz9swKC9ayc5z4o4MIzHL0EzFovae95RECwPqKltingomsSKSgWMHPFoJZLCwjWNKEFXgRccGbhLgGzd5e8975PQLCaixIBF1sJo0USAmYwgefRUgHBWsq552IutD37PuKpzeKIXdlvT4J1v56XnthFVsppsQIBM1mAaImUgGBN8e39sAts7/6PfHqzOXJ31t+bYF2/x5ec0MV1CatFCwXMaCGmpR4SEKwPcSl+FnBhmYNZBMzqLJ1aa5+Cda1+Xn4aF9XlxF5QLGBmi0Et1xQQrE0iBS8CLiizMKuA2Z21c3PuW7DO2bfuu3YxdSf3wmIBM1wMarkPCghWw9EUcCE1iRRMImCWJ2nU5NsUrJM38Ortu4iuFrZ+bwEz3Vt8v/cJ1v16Hj6xCyhMpXAyAbM9WcMm265gnaxhvbbr4ukl7T13CZjxu+TXf69gXb/HD5/QhfMwmQcmFTDrkzZu8G0L1sEb1Ht7Lpre4t53t4CZv7sD671fsK7X09MncsGcpvPg5AJmf/IGDrZ9wTpYQ+7ajovlLnnvHUXAZ2CUTsy/D8E6fw9LTnBcKj8/FvrpicU+O4boH0885xECQwocn4VfHhv79MTm/v34LPzLiec8spiAYF2soWePc1wm3z2e/d3x850H1vjsqP3ZMUTH434RWEPg5DfXPx+n/+HxWfjjGgpOkREQrBm9xZ59MFyF6mL9d5yvBB4MV6FqeN4SEKwG4i2BN+H6h+N3fvsjNELV3CwvEAzXvxwQ3/dNdflxeOiAgvUhrj2KjwvlB8dJf/OBcBWqe4yBUx4CjXB9DtUfH5fo72EReC0gWM3DewXehOtvjz/4rVcFQtW8bCfwgXAVqttNQvzAgjVutV3lcaF8chz68zfhKlS3mwAHfhF4J1z/evz+H/mmaj4+JCBYzcZHBY4L5flfO3j+S8P/fAzL/+AisKvA8Vl4/qs3vzh+fn18Fn61q4NztwUEa9tIBQECBAgQCAsI1jCVQgIECBAg0BYQrG0jFQQIECBAICwgWMNUCgkQIECAQFtAsLaNVBAgQIAAgbCAYA1TKSRAgAABAm0Bwdo2UkGAAAECBMICgjVMpZAAAQIECLQFBGvbSAUBAgQIEAgLCNYwlUICBAgQINAWEKxtIxUECBAgQCAsIFjDVAoJECBAgEBbQLC2jVQQIECAAIGwgGANUykkQIAAAQJtAcHaNlJBgAABAgTCAoI1TKWQAAECBAi0BQRr20gFAQIECBAICwjWMJVCAgQIECDQFhCsbSMVBAgQIEAgLCBYw1QKCRAgQIBAW0Cwto1UECBAgACBsIBgDVMpJECAAAECbQHB2jZSQYAAAQIEwgKCNUylkAABAgQItAUEa9tIBQECBAgQCAsI1jCVQgIECBAg0BYQrG0jFQQIECBAICwgWMNUCgkQIECAQFtAsLaNVBAgQIAAgbCAYA1TKSRAgAABAm0Bwdo2UkGAAAECBMICgjVMpZAAAQIECLQFBGvbSAUBAgQIEAgLCNYwlUICBAgQINAWEKxtIxUECBAgQCAsIFjDVAoJECBAgEBbQLC2jVQQIECAAIGwgGANUykkQIAAAQJtAcHaNlJBgAABAgTCAoI1TKWQAAECBAi0BQRr20gFAQIECBAICwjWMJVCAgQIECDQFhCsbSMVBAgQIEAgLCBYw1QKCRAgQIBAW0Cwto1UECBAgACBsIBgDVMpJECAAAECbQHB2jZSQYAAAQIEwgKCNUylkAABAgQItAUEa9tIBQECBAgQCAsI1jCVQgIECBAg0BYQrG0jFQQIECBAICwgWMNUCgkQIECAQFtAsLaNVBAgQIAAgbCAYA1TKSRAgAABAm0Bwdo2UkGAAAECBMICgjVMpZAAAQIECLQFBGvbSAUBAgQIEAgLCNYwlUICBAgQINAWEKxtIxUECBAgQCAsIFjDVAoJECBAgEBbQLC2jVQQIECAAIGwgGANUykkQIAAAQJtAcHaNlJBgAABAgTCAoI1TKWQAAECBAi0BQRr20gFAQIECBAICwjWMJVCAgQIECDQFhCsbSMVBAgQIEAgLCBYw1QKCRAgQIBAW0Cwto1UECBAgACBsIBgDVMpJECAAAECbQHB2jZSQYAAAQIEwgKCNUylkAABAgQItAUEa9tIBQECBAgQCAsI1jCVQgIECBAg0BYQrG0jFQQIECBAICwgWMNUCgkQIECAQFtAsLaNVBAgQIAAgbCAYA1TKSRAgAABAm0Bwdo2UkGAAAECBMICgjVMpZAAAQIECLQFBGvbSAUBAgQIEAgLCNYwlUICBAgQINAWEKxtIxUECBAgQCAsIFjDVAoJECBAgEBbQLC2jVQQIECAAIGwgGANUykkQIAAAQJtAcHaNlJBgAABAgTCAoI1TKWQAAECBAi0BQRr20gFAQIECBAICwjWMJVCAgQIECDQFhCsbSMVBAgQIEAgLCBYw1QKCRAgQIBAW0Cwto1UECBAgACBsIBgDVMpJECAAAECbQHB2jZSQYAAAQIEwgKCNUylkAABAgQItAUEa9tIBQECBAgQCAsI1jCVQgIECBAg0BYQrG0jFQQIECBAICwgWMNUCgkQIECAQFtAsLaNVBAgQIAAgbCAYA1TKSRAgAABAm0Bwdo2UkGAAAECBMICgjVMpZAAAQIECLQFBGvbSAUBAgQIEAgLCNYwlUICBAgQINAWEKxtIxUECBAgQCAsIFjDVAoJECBAgEBbQLC2jVQQIECAAIGwgGANUykkQIAAAQJtAcHaNlJBgAABAgTCAoI1TKWQAAECBAi0BQRr20gFAQIECBAICwjWMJVCAgQIECDQFhCsbSMVBAgQIEAgLCBYw1QKCRAgQIBAW0Cwto1UECBAgACBsIBgDVMpJECAAAECbQHB2jZSQYAAAQIEwgKCNUylkAABAgQItAUEa9tIBQECBAgQCAsI1jCVQgIECBAg0BYQrG0jFQQIECBAICwgWMNUCgkQIECAQFtAsLaNVBAgQIAAgbCAYA1TKSRAgAABAm0Bwdo2UkGAAAECBMICgjVMpZAAAQIECLQFBGvbSAUBAgQIEAgLCNYwlUICBAgQINAW+D+Nukgxp8OHrwAAAABJRU5ErkJggg==';

/*
 * Public API Surface of restaurant-manager
 */

/**
 * Generated bundle index. Do not edit.
 */

export { Address, AddressService, ApiService, AppConfiguration, AppVersion, Category, CategoryService, Client, ClientBilling, ClientConfig, ClientService, Collection, CollectionItem, CollectionOperation, CollectionTransaction, Company, CompanyService, Configuration, ContactModel, ContactService, DeliverySlot, DeliverySlotService, DeliverySlots, DeviceTokenService, Employee, EntityService, Event, EventCompany, EventHall, EventLocation, EventRestaurant, EventService, EventStall, Extension, FormHelper, Hash, Hashes, Hour, HourGroup, IngredientService, InvoiceData, InvoiceService, LibConfiguration, License, LicenseService, ManagerVersion, Menu, MenuGroup, MenuGroupItem, NextDeliverySlots, ORDER_CANCELLATION_REASONS, ORDER_STATUS, ORDER_STATUS_INFORMATIONS, Order, OrderDiscount, OrderError, OrderHelper, OrderItem, OrderItemChoice, OrderItemChoiceGroup, OrderOption, OrderService, OrderVat, PAYMENT_METHODS, PERMISSIONS, POS_REPORT_ACTIONS, PRODUCT_DEFAULT_THUMB, PRODUCT_DIMENSION_TYPES, PaginatedResult, PasswordService, PlaceOrder, PlaceOrderClient, PlaceOrderOption, PosReport, PosReportItem, Product, ProductAllergen, ProductChoice, ProductChoiceGroup, ProductIngredient, ProductService, Production, ProductionItem, ProductionTicket, Restaurant, RestaurantClosure, RestaurantManagerModule, RestaurantService, RestaurantStats, Session, SessionService, ShoppingCart, ShoppingCartItem, ShoppingCartItemProductChoices, ShoppingCartOption, ShoppingCartService, Sortable, Stock, StockService, SyncService, TRANSACTION_STATUS, TRANSACTION_STATUS_INFORMATIONS, Table, TableManagement, Tag, Team, Transaction, TransactionItem, TransactionPart, TransactionPayment, TransactionService, TransactionVat, USER_ROLES, User, UserRegister, UserService, Utils, VatRate, VersionService, WebsiteConfiguration, Widget, WidgetCustomCategoryItem, WidgetCustomCustomItem, WidgetCustomItem, WidgetCustomProductItem, WidgetGalleryImageItem, WidgetGalleryItem, WidgetGalleryTextItem, WidgetItem, WidgetService, ZONE_OBJECT_TYPES, Zone, ZoneObject };
//# sourceMappingURL=lonestudio-restaurant-manager.js.map
