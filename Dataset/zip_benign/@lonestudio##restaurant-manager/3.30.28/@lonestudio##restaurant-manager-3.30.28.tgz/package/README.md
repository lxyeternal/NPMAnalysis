# Restaurant Manager

Simple Restaurant management system

## Changelog

### Version 1.0.0
* Is now production ready

### Version 0.6.x
* Password reset and change
* Add link to payment
* Remove shoppinh cart line by id
* Change order status (admin only)

### Version 0.5.x
* Add order management app calls

### Version 0.4.x
* Address API calls
* Get delivery slots
* Place order
* Add default image for products
* Add Moment.js for date and time display

### Version 0.3.x
* User service :
  * Login
  * Register
  * Update profile
* Address model

### Version 0.2.x
* Improve API results : convert JSON results to camelCase objects
* Fix vat issues
* Add price component
* Prefix lib components with `lib-rm-`
* Add Restaurant availability

### Version 0.1.x
* Product Component to list product
* Implement Shopping Cart

### Version 0.0.x
* Proof of concept
* Models
* Basic API Services

## Copyright

Made by [Lone Studio](https://lone.studio)
