(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('moment'), require('@angular/common/http'), require('@angular/core'), require('uuid'), require('rxjs/operators'), require('rxjs'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('@lonestudio/restaurant-manager', ['exports', 'moment', '@angular/common/http', '@angular/core', 'uuid', 'rxjs/operators', 'rxjs', '@angular/common'], factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, factory((global.lonestudio = global.lonestudio || {}, global.lonestudio["restaurant-manager"] = {}), global.moment, global.ng.common.http, global.ng.core, global.uuid, global.rxjs.operators, global.rxjs, global.ng.common));
})(this, (function (exports, moment_, i1, i0, uuid, operators, rxjs, common) { 'use strict';

    function _interopNamespace(e) {
        if (e && e.__esModule) return e;
        var n = Object.create(null);
        if (e) {
            Object.keys(e).forEach(function (k) {
                if (k !== 'default') {
                    var d = Object.getOwnPropertyDescriptor(e, k);
                    Object.defineProperty(n, k, d.get ? d : {
                        enumerable: true,
                        get: function () { return e[k]; }
                    });
                }
            });
        }
        n["default"] = e;
        return Object.freeze(n);
    }

    var moment___namespace = /*#__PURE__*/_interopNamespace(moment_);
    var i1__namespace = /*#__PURE__*/_interopNamespace(i1);
    var i0__namespace = /*#__PURE__*/_interopNamespace(i0);

    /******************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
    /* global Reflect, Promise */
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b)
                if (Object.prototype.hasOwnProperty.call(b, p))
                    d[p] = b[p]; };
        return extendStatics(d, b);
    };
    function __extends(d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }
    var __assign = function () {
        __assign = Object.assign || function __assign(t) {
            for (var s, i = 1, n = arguments.length; i < n; i++) {
                s = arguments[i];
                for (var p in s)
                    if (Object.prototype.hasOwnProperty.call(s, p))
                        t[p] = s[p];
            }
            return t;
        };
        return __assign.apply(this, arguments);
    };
    function __rest(s, e) {
        var t = {};
        for (var p in s)
            if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
                t[p] = s[p];
        if (s != null && typeof Object.getOwnPropertySymbols === "function")
            for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
                if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
                    t[p[i]] = s[p[i]];
            }
        return t;
    }
    function __decorate(decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function")
            r = Reflect.decorate(decorators, target, key, desc);
        else
            for (var i = decorators.length - 1; i >= 0; i--)
                if (d = decorators[i])
                    r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    }
    function __param(paramIndex, decorator) {
        return function (target, key) { decorator(target, key, paramIndex); };
    }
    function __esDecorate(ctor, descriptorIn, decorators, contextIn, initializers, extraInitializers) {
        function accept(f) { if (f !== void 0 && typeof f !== "function")
            throw new TypeError("Function expected"); return f; }
        var kind = contextIn.kind, key = kind === "getter" ? "get" : kind === "setter" ? "set" : "value";
        var target = !descriptorIn && ctor ? contextIn["static"] ? ctor : ctor.prototype : null;
        var descriptor = descriptorIn || (target ? Object.getOwnPropertyDescriptor(target, contextIn.name) : {});
        var _, done = false;
        for (var i = decorators.length - 1; i >= 0; i--) {
            var context = {};
            for (var p in contextIn)
                context[p] = p === "access" ? {} : contextIn[p];
            for (var p in contextIn.access)
                context.access[p] = contextIn.access[p];
            context.addInitializer = function (f) { if (done)
                throw new TypeError("Cannot add initializers after decoration has completed"); extraInitializers.push(accept(f || null)); };
            var result = (0, decorators[i])(kind === "accessor" ? { get: descriptor.get, set: descriptor.set } : descriptor[key], context);
            if (kind === "accessor") {
                if (result === void 0)
                    continue;
                if (result === null || typeof result !== "object")
                    throw new TypeError("Object expected");
                if (_ = accept(result.get))
                    descriptor.get = _;
                if (_ = accept(result.set))
                    descriptor.set = _;
                if (_ = accept(result.init))
                    initializers.push(_);
            }
            else if (_ = accept(result)) {
                if (kind === "field")
                    initializers.push(_);
                else
                    descriptor[key] = _;
            }
        }
        if (target)
            Object.defineProperty(target, contextIn.name, descriptor);
        done = true;
    }
    ;
    function __runInitializers(thisArg, initializers, value) {
        var useValue = arguments.length > 2;
        for (var i = 0; i < initializers.length; i++) {
            value = useValue ? initializers[i].call(thisArg, value) : initializers[i].call(thisArg);
        }
        return useValue ? value : void 0;
    }
    ;
    function __propKey(x) {
        return typeof x === "symbol" ? x : "".concat(x);
    }
    ;
    function __setFunctionName(f, name, prefix) {
        if (typeof name === "symbol")
            name = name.description ? "[".concat(name.description, "]") : "";
        return Object.defineProperty(f, "name", { configurable: true, value: prefix ? "".concat(prefix, " ", name) : name });
    }
    ;
    function __metadata(metadataKey, metadataValue) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function")
            return Reflect.metadata(metadataKey, metadataValue);
    }
    function __awaiter(thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try {
                step(generator.next(value));
            }
            catch (e) {
                reject(e);
            } }
            function rejected(value) { try {
                step(generator["throw"](value));
            }
            catch (e) {
                reject(e);
            } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    }
    function __generator(thisArg, body) {
        var _ = { label: 0, sent: function () { if (t[0] & 1)
                throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function () { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f)
                throw new TypeError("Generator is already executing.");
            while (g && (g = 0, op[0] && (_ = 0)), _)
                try {
                    if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done)
                        return t;
                    if (y = 0, t)
                        op = [op[0] & 2, t.value];
                    switch (op[0]) {
                        case 0:
                        case 1:
                            t = op;
                            break;
                        case 4:
                            _.label++;
                            return { value: op[1], done: false };
                        case 5:
                            _.label++;
                            y = op[1];
                            op = [0];
                            continue;
                        case 7:
                            op = _.ops.pop();
                            _.trys.pop();
                            continue;
                        default:
                            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                                _ = 0;
                                continue;
                            }
                            if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) {
                                _.label = op[1];
                                break;
                            }
                            if (op[0] === 6 && _.label < t[1]) {
                                _.label = t[1];
                                t = op;
                                break;
                            }
                            if (t && _.label < t[2]) {
                                _.label = t[2];
                                _.ops.push(op);
                                break;
                            }
                            if (t[2])
                                _.ops.pop();
                            _.trys.pop();
                            continue;
                    }
                    op = body.call(thisArg, _);
                }
                catch (e) {
                    op = [6, e];
                    y = 0;
                }
                finally {
                    f = t = 0;
                }
            if (op[0] & 5)
                throw op[1];
            return { value: op[0] ? op[1] : void 0, done: true };
        }
    }
    var __createBinding = Object.create ? (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        var desc = Object.getOwnPropertyDescriptor(m, k);
        if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
            desc = { enumerable: true, get: function () { return m[k]; } };
        }
        Object.defineProperty(o, k2, desc);
    }) : (function (o, m, k, k2) {
        if (k2 === undefined)
            k2 = k;
        o[k2] = m[k];
    });
    function __exportStar(m, o) {
        for (var p in m)
            if (p !== "default" && !Object.prototype.hasOwnProperty.call(o, p))
                __createBinding(o, m, p);
    }
    function __values(o) {
        var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
        if (m)
            return m.call(o);
        if (o && typeof o.length === "number")
            return {
                next: function () {
                    if (o && i >= o.length)
                        o = void 0;
                    return { value: o && o[i++], done: !o };
                }
            };
        throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
    }
    function __read(o, n) {
        var m = typeof Symbol === "function" && o[Symbol.iterator];
        if (!m)
            return o;
        var i = m.call(o), r, ar = [], e;
        try {
            while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
                ar.push(r.value);
        }
        catch (error) {
            e = { error: error };
        }
        finally {
            try {
                if (r && !r.done && (m = i["return"]))
                    m.call(i);
            }
            finally {
                if (e)
                    throw e.error;
            }
        }
        return ar;
    }
    /** @deprecated */
    function __spread() {
        for (var ar = [], i = 0; i < arguments.length; i++)
            ar = ar.concat(__read(arguments[i]));
        return ar;
    }
    /** @deprecated */
    function __spreadArrays() {
        for (var s = 0, i = 0, il = arguments.length; i < il; i++)
            s += arguments[i].length;
        for (var r = Array(s), k = 0, i = 0; i < il; i++)
            for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++)
                r[k] = a[j];
        return r;
    }
    function __spreadArray(to, from, pack) {
        if (pack || arguments.length === 2)
            for (var i = 0, l = from.length, ar; i < l; i++) {
                if (ar || !(i in from)) {
                    if (!ar)
                        ar = Array.prototype.slice.call(from, 0, i);
                    ar[i] = from[i];
                }
            }
        return to.concat(ar || Array.prototype.slice.call(from));
    }
    function __await(v) {
        return this instanceof __await ? (this.v = v, this) : new __await(v);
    }
    function __asyncGenerator(thisArg, _arguments, generator) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var g = generator.apply(thisArg, _arguments || []), i, q = [];
        return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i;
        function verb(n) { if (g[n])
            i[n] = function (v) { return new Promise(function (a, b) { q.push([n, v, a, b]) > 1 || resume(n, v); }); }; }
        function resume(n, v) { try {
            step(g[n](v));
        }
        catch (e) {
            settle(q[0][3], e);
        } }
        function step(r) { r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r); }
        function fulfill(value) { resume("next", value); }
        function reject(value) { resume("throw", value); }
        function settle(f, v) { if (f(v), q.shift(), q.length)
            resume(q[0][0], q[0][1]); }
    }
    function __asyncDelegator(o) {
        var i, p;
        return i = {}, verb("next"), verb("throw", function (e) { throw e; }), verb("return"), i[Symbol.iterator] = function () { return this; }, i;
        function verb(n, f) { i[n] = o[n] ? function (v) { return (p = !p) ? { value: __await(o[n](v)), done: false } : f ? f(v) : v; } : f; }
    }
    function __asyncValues(o) {
        if (!Symbol.asyncIterator)
            throw new TypeError("Symbol.asyncIterator is not defined.");
        var m = o[Symbol.asyncIterator], i;
        return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () { return this; }, i);
        function verb(n) { i[n] = o[n] && function (v) { return new Promise(function (resolve, reject) { v = o[n](v), settle(resolve, reject, v.done, v.value); }); }; }
        function settle(resolve, reject, d, v) { Promise.resolve(v).then(function (v) { resolve({ value: v, done: d }); }, reject); }
    }
    function __makeTemplateObject(cooked, raw) {
        if (Object.defineProperty) {
            Object.defineProperty(cooked, "raw", { value: raw });
        }
        else {
            cooked.raw = raw;
        }
        return cooked;
    }
    ;
    var __setModuleDefault = Object.create ? (function (o, v) {
        Object.defineProperty(o, "default", { enumerable: true, value: v });
    }) : function (o, v) {
        o["default"] = v;
    };
    function __importStar(mod) {
        if (mod && mod.__esModule)
            return mod;
        var result = {};
        if (mod != null)
            for (var k in mod)
                if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k))
                    __createBinding(result, mod, k);
        __setModuleDefault(result, mod);
        return result;
    }
    function __importDefault(mod) {
        return (mod && mod.__esModule) ? mod : { default: mod };
    }
    function __classPrivateFieldGet(receiver, state, kind, f) {
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a getter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot read private member from an object whose class did not declare it");
        return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
    }
    function __classPrivateFieldSet(receiver, state, value, kind, f) {
        if (kind === "m")
            throw new TypeError("Private method is not writable");
        if (kind === "a" && !f)
            throw new TypeError("Private accessor was defined without a setter");
        if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver))
            throw new TypeError("Cannot write private member to an object whose class did not declare it");
        return (kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value)), value;
    }
    function __classPrivateFieldIn(state, receiver) {
        if (receiver === null || (typeof receiver !== "object" && typeof receiver !== "function"))
            throw new TypeError("Cannot use 'in' operator on non-object");
        return typeof state === "function" ? receiver === state : state.has(receiver);
    }

    var moment$2 = moment___namespace;
    var Utils = /** @class */ (function () {
        function Utils() {
        }
        Utils.generateId = function (length, timestamp) {
            if (timestamp === void 0) { timestamp = false; }
            var result = '';
            var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            var charactersLength = characters.length;
            for (var i = 0; i < length; i++) {
                result += characters.charAt(Math.floor(Math.random() * charactersLength));
            }
            if (timestamp) {
                result += '-' + Date.now().toString(36);
            }
            return result;
        };
        Utils.combineURLs = function (urls) {
            return urls.join('/').replace(new RegExp('([^:]\\/)\\/+', 'g'), '$1');
        };
        Utils.getTodayAsString = function () {
            var m = moment$2(new Date());
            return m.format('YYYY-MM-DD');
        };
        Utils.getDateAsString = function (date) {
            var m = moment$2(date);
            return m.format('YYYY-MM-DD');
        };
        Utils.toFullDateTime = function (d) {
            var m = moment$2(d);
            return m.format('dddd DD MMMM YYYY') + " \u00E0 " + m.format('HH') + "h" + m.format('mm');
        };
        Utils.toShortDateTime = function (d) {
            var m = moment$2(d);
            return m.format('DD-MM-YYYY') + " \u00E0 " + m.format('HH') + "h" + m.format('mm');
        };
        Utils.toMediumDate = function (d, format) {
            return moment$2(d, format).format('dddd DD MMMM');
        };
        Utils.toTime = function (d) {
            var m = moment$2(d);
            return m.format('HH') + "h" + m.format('mm');
        };
        Utils.semanticVersionToNumber = function (version) {
            var p = version.split('.');
            return (+p[0] || 0) * 1000000 + (+p[1] || 0) * 10000 + (+p[2] || 0) * 100;
        };
        Utils.isNumber = function (value) {
            return (new RegExp('^[0-9]+$')).test(value.toString());
        };
        Utils.isFloat = function (value) {
            return (new RegExp('^([0-9]*[.])?[0-9]+$')).test(value.toString());
        };
        Utils.isValidPercent = function (value) {
            return (new RegExp('^([0-9]*[.])?[0-9]+%$')).test(value.toString());
        };
        Utils.camelize = function (value) {
            value = value.replace(/[-_\s.]+(.)?/g, function (_, c) { return c ? c.toUpperCase() : ''; });
            return value.substr(0, 1).toLowerCase() + value.substr(1);
        };
        Utils.capitalizeFirstLetter = function (str) {
            return str.charAt(0).toUpperCase() + str.slice(1);
        };
        Utils.merge = function (target, source) {
            var e_1, _a;
            try {
                for (var _b = __values(Object.keys(source)), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var key = _c.value;
                    if (source[key] instanceof Object) {
                        Object.assign(source[key], Utils.merge(target[key], source[key]));
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
            Object.assign(target || {}, source);
            return target;
        };
        return Utils;
    }());

    var LibConfiguration = /** @class */ (function () {
        function LibConfiguration() {
        }
        LibConfiguration.conf = function (configuration) {
            LibConfiguration.configuration = configuration;
            LibConfiguration.configuration.client = configuration.client || LibConfiguration.client;
            LibConfiguration.configuration.platform = configuration.platform ? configuration.platform : 'undefined';
            LibConfiguration.baseUrl = configuration.apiBaseUrl.replace('/api', '');
        };
        LibConfiguration.setClient = function (client) {
            LibConfiguration.client = client;
            if (LibConfiguration.configuration) {
                LibConfiguration.configuration.client = client;
            }
        };
        LibConfiguration.apiBaseUrl = function () {
            return Utils.combineURLs([LibConfiguration.configuration.apiBaseUrl, LibConfiguration.configuration.client]);
        };
        LibConfiguration.imageBaseUrl = function () {
            return LibConfiguration.configuration.imageBaseUrl;
        };
        LibConfiguration.imageUrlFromPath = function (path) {
            if (path) {
                return Utils.combineURLs([LibConfiguration.imageBaseUrl(), path]);
            }
            return null;
        };
        LibConfiguration.generatePaymentLink = function (orderId) {
            return Utils.combineURLs([LibConfiguration.apiBaseUrl(), 'orders', orderId, 'pay']);
        };
        LibConfiguration.generateOrdersPaymentLink = function (orderIds, paymentMethod) {
            return Utils.combineURLs([LibConfiguration.apiBaseUrl(), 'payments?orderIds=' + orderIds.join('%3B') + '&paymentMethod=' + paymentMethod]);
        };
        return LibConfiguration;
    }());
    LibConfiguration.configuration = null;
    LibConfiguration.baseUrl = '';
    LibConfiguration.version = '3.30.28';
    LibConfiguration.client = null;
    var ApiService = /** @class */ (function () {
        function ApiService(http) {
            this.http = http;
            var version = localStorage.getItem('rm_version');
            if (LibConfiguration.version !== version) {
                localStorage.setItem('rm_version', LibConfiguration.version);
            }
        }
        ApiService.prototype.get = function (url, authenticated, client) {
            if (authenticated === void 0) { authenticated = false; }
            if (client === void 0) { client = true; }
            var headers = new i1.HttpHeaders();
            if (authenticated && ApiService.logged) {
                headers = headers.append('Authorization', 'Bearer ' + ApiService.token);
            }
            headers = headers.append('Client-Platform', LibConfiguration.configuration.platform);
            var baseUrl = client ? LibConfiguration.apiBaseUrl() : LibConfiguration.baseUrl;
            return this.http.get(Utils.combineURLs([baseUrl, url]), { headers: headers });
        };
        ApiService.prototype.put = function (url, body, authenticated, client) {
            if (authenticated === void 0) { authenticated = false; }
            if (client === void 0) { client = true; }
            var headers = new i1.HttpHeaders();
            if (authenticated && ApiService.logged) {
                headers = headers.append('Authorization', 'Bearer ' + ApiService.token);
            }
            headers = headers.append('Client-Platform', LibConfiguration.configuration.platform);
            var baseUrl = client ? LibConfiguration.apiBaseUrl() : LibConfiguration.baseUrl;
            return this.http.put(Utils.combineURLs([baseUrl, url]), body, { headers: headers });
        };
        ApiService.prototype.delete = function (url, authenticated, client) {
            if (authenticated === void 0) { authenticated = false; }
            if (client === void 0) { client = true; }
            var headers = new i1.HttpHeaders();
            if (authenticated && ApiService.logged) {
                headers = headers.append('Authorization', 'Bearer ' + ApiService.token);
            }
            headers = headers.append('Client-Platform', LibConfiguration.configuration.platform);
            var baseUrl = client ? LibConfiguration.apiBaseUrl() : LibConfiguration.baseUrl;
            return this.http.delete(Utils.combineURLs([baseUrl, url]), { headers: headers });
        };
        ApiService.prototype.post = function (url, body, authenticated, client) {
            if (authenticated === void 0) { authenticated = false; }
            if (client === void 0) { client = true; }
            var headers = new i1.HttpHeaders();
            if (authenticated && ApiService.logged) {
                headers = headers.append('Authorization', 'Bearer ' + ApiService.token);
            }
            headers = headers.append('Client-Platform', LibConfiguration.configuration.platform);
            var baseUrl = client ? LibConfiguration.apiBaseUrl() : LibConfiguration.baseUrl;
            return this.http.post(Utils.combineURLs([baseUrl, url]), body, { headers: headers });
        };
        return ApiService;
    }());
    ApiService.logged = false;
    ApiService.user = null;
    ApiService.token = null;
    ApiService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function ApiService_Factory() { return new ApiService(i0__namespace.ɵɵinject(i1__namespace.HttpClient)); }, token: ApiService, providedIn: "root" });
    ApiService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    ApiService.ctorParameters = function () { return [
        { type: i1.HttpClient }
    ]; };

    var moment$1 = moment___namespace;
    var Extension = /** @class */ (function () {
        function Extension() {
        }
        return Extension;
    }());
    Extension.EVENTS = 'events';
    Extension.GROUPED_PAYMENTS = 'grouped_payments';
    Extension.POS = 'pos';
    Extension.DELIVERY_TRACKER = 'delivery_tracker';
    Extension.SLOTS = 'slots';
    Extension.STOCKS = 'stocks';
    Extension.CLICK_COLLECT = "click_collect";
    Extension.KITCHEN_PRODUCTION = "kitchen_production";
    Extension.MENU = 'menu';
    var Sortable = /** @class */ (function () {
        function Sortable() {
        }
        return Sortable;
    }());
    var ZONE_OBJECT_TYPES = {
        flowers_pot: {
            slug: 'flowers_pot',
            label: 'Pot de fleurs',
            image: 'flower1'
        },
        wc: {
            slug: 'wc',
            label: 'WC',
            image: 'badge-wc'
        }
    };
    var PAYMENT_METHODS = {
        rticket: {
            slug: 'rticket',
            label: 'Ticket restaurant',
            shortLabel: 'Ticket R',
            icon: 'receipt'
        },
        cash: {
            slug: 'cash',
            label: 'Espèces',
            shortLabel: 'Espèces',
            icon: 'coin'
        },
        card: {
            slug: 'card',
            label: 'Carte bancaire',
            shortLabel: 'Carte',
            icon: 'credit-card'
        },
        check: {
            slug: 'check',
            label: 'Chèque',
            shortLabel: 'Chèque',
            icon: 'credit-card-2-front'
        },
        account: {
            slug: 'account',
            label: 'Mise en compte',
            shortLabel: 'Compte',
            icon: 'person'
        },
        other: {
            slug: 'other',
            label: 'Autre',
            shortLabel: 'Autre',
            icon: 'three-dots'
        }
    };
    var ORDER_STATUS = {
        pending: {
            slug: 'pending',
            label: 'En attente de paiement'
        },
        confirmed: {
            slug: 'confirmed',
            label: 'Confirmée'
        },
        preparing: {
            slug: 'preparing',
            label: 'En cours de préparation'
        },
        delivering: {
            slug: 'delivering',
            label: 'En cours de livraison'
        },
        done: {
            slug: 'done',
            label: 'Terminée'
        },
        cancelled: {
            slug: 'cancelled',
            label: 'Annulée'
        }
    };
    var ORDER_CANCELLATION_REASONS = {
        typing_error: {
            slug: 'typing_error',
            label: 'Erreur saisie'
        },
        client_issue: {
            slug: 'client_issue',
            label: 'Problème client'
        },
        product_non_available: {
            slug: 'product_non_available',
            label: 'Produit indisponible'
        },
        other: {
            slug: 'other',
            label: 'Autre'
        }
    };
    var PERMISSIONS = {
        team: {
            cancel_order: {
                slug: 'cancel_order',
                label: 'Annulation commande'
            },
            cancel_transaction: {
                slug: 'cancel_transaction',
                label: 'Annulation transaction'
            },
            apply_discount: {
                slug: 'apply_discount',
                label: 'Application de remise'
            },
            show_stats: {
                slug: 'show_stats',
                label: 'Affichage des statistiques'
            }
        }
    };
    var PRODUCT_DIMENSION_TYPES = {
        unit: {
            slug: 'unit',
            label: 'Produit à l\'unité'
        },
        kg: {
            slug: 'kg',
            label: 'Produit au poids'
        },
        m: {
            slug: 'unit',
            label: 'Produit au mètre'
        }
    };
    var POS_REPORT_ACTIONS = {
        create_order: {
            slug: 'create_order',
            label: 'a crée une commande'
        },
        cancel_order: {
            slug: 'cancel_order',
            label: 'a annulé une commande'
        },
        close_order: {
            slug: 'close_order',
            label: 'a clôturé une commande'
        },
        cancel_partial_order: {
            slug: 'cancel_partial_order',
            label: 'a annulé les produits de la commande'
        },
        add_order_item: {
            slug: 'add_order_product',
            label: 'a ajouté un produit'
        },
        delete_order_item: {
            slug: 'delete_order_item',
            label: 'a supprimé un produit'
        },
        create_transaction: {
            slug: 'create_transaction',
            label: 'a crée une transaction'
        },
        cancel_transaction: {
            slug: 'cancel_transaction',
            label: 'a annulé une transaction'
        },
        apply_discount: {
            slug: 'apply_discount',
            label: 'a appliqué une remise'
        },
        cancel_discount: {
            slug: 'cancel_discount',
            label: 'a retiré une remise'
        },
        print_order_ticket: {
            slug: 'print_order_ticket',
            label: 'a imprimé un ticket de commande'
        },
        print_transaction_ticket: {
            slug: 'print_transaction_ticket',
            label: 'a imprimé un ticket de transaction'
        },
        create_z_ticket: {
            slug: 'create_z_ticket',
            label: 'a crée un ticket Z'
        },
        print_z_ticket: {
            slug: 'print_z_ticket',
            label: 'a imprimé un ticket Z'
        },
        login_employee: {
            slug: 'login_employee',
            label: 's\est connecté'
        },
        logout_employee: {
            slug: 'logout_employee',
            label: 's\est déconnecté'
        },
        open_session: {
            slug: 'open_session',
            label: 'a ouvert une session'
        },
        close_session: {
            slug: 'close_session',
            label: 'a clôturé une session'
        },
        open_drawer: {
            slug: 'open_drawer',
            label: 'a ouvert le tiroir caisse'
        },
        open_table: {
            slug: 'open_table',
            label: 'a ouvert une table'
        },
        close_table: {
            slug: 'close_table',
            label: 'a fermé une table'
        }
    };
    var ORDER_STATUS_INFORMATIONS = {
        ROLE_USER: {
            pending: 'Votre commande n\'est pas validée et est en attente de règlement. Vous pouvez à tout moment la payer au bas de cette page.',
            confirmed: 'Votre commande est validée et va être prise en charge par nos équipes. Merci !',
            preparing: 'Il y a le feu en cuisine. Vous recevrez prochainement une notification quand votre commande sera prête.',
            delivering: 'Votre commande est prête. Vous serez livré dans les prochaines minutes, encore un peu de patience !',
            picking: 'Votre commande est prête. Vous pouvez dès à présent la retirer sur place, encore un petit effort !',
            done: 'Votre commande a été délivrée. Nous espérons que tout s\'est bien passé. Au plaisir de vous revoir.',
            cancelled: 'Votre commande a été annulée.'
        },
        ROLE_DELIVERY: {
            pending: 'La commande n\'est pas validée et est en attente de règlement. Vous ne pouvez actuellement pas la prendre en charge.',
            confirmed: 'La commande est validée et a été envoyée en cuisine. Vous ne pouvez actuellement pas la prendre en charge',
            preparing: 'La commande est en cours de préparation, il y a le feu en cuisine. Tenez-vous prêt pour une prise en charge !',
            delivering: 'Le client a été notifié, on compte sur vous pour une livraison express !',
            done: 'La commande a été annulée'
        }
    };
    var TRANSACTION_STATUS = {
        pending: {
            slug: 'pending',
            label: 'En attente de paiement'
        },
        paid: {
            slug: 'paid',
            label: 'Paiement effectué'
        },
        paid_account: {
            slug: 'paid_account',
            label: 'Paiement mis en compte'
        },
        refused: {
            slug: 'refused',
            label: 'Paiement refusé'
        },
        cancelled: {
            slug: 'cancelled',
            label: 'Paiement annulé'
        },
        refunded: {
            slug: 'refunded',
            label: 'Paiement remboursé'
        }
    };
    var TRANSACTION_STATUS_INFORMATIONS = {
        pending: 'Il semblerait que vous ayez quitté le processus de paiement trop tôt. Nous vous recommandons de vérifier une potentielle confirmation dans vos emails (y compris vos spams).',
        paid: 'Merci ! Votre règlement a bien été effectué. Votre commande est désormais validée et va être traitée par nos équipes.',
        refused: 'Ho non ! Votre paiement a échoué. Nous vous recommandons de ressayer une nouvelle fois. Si le problème persiste, veuillez contacter votre banque pour obtenir le motif du refus.',
        cancelled: 'Votre transaction a été annulée.',
        refunded: 'Votre transaction a été remboursée.'
    };
    var USER_ROLES = {
        ROLE_OWNER: 'ROLE_OWNER',
        ROLE_SALE: 'ROLE_SALE',
        ROLE_ACCOUNTANT: 'ROLE_ACCOUNTANT',
        ROLE_USER: 'ROLE_USER',
        ROLE_PRO: 'ROLE_PRO',
        ROLE_DELIVERY: 'ROLE_DELIVERY',
        ROLE_ADMIN: 'ROLE_ADMIN',
        ROLE_SUPER_ADMIN: 'ROLE_SUPER_ADMIN',
        ROLE_CASHIER: 'ROLE_CASHIER'
    };
    var AppVersion = /** @class */ (function () {
        function AppVersion(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return AppVersion;
    }());
    var ManagerVersion = /** @class */ (function () {
        function ManagerVersion(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return ManagerVersion;
    }());
    var PaginatedResult = /** @class */ (function () {
        function PaginatedResult(obj, type) {
            var _a;
            Object.assign(this, obj);
            this.items = (_a = obj.items) === null || _a === void 0 ? void 0 : _a.map(function (i) { return new type(i); });
        }
        return PaginatedResult;
    }());
    var OrderError = /** @class */ (function () {
        function OrderError(obj) {
            if (obj === void 0) { obj = {}; }
            this.code = null;
            this.error = '';
            this.data = null;
            this.products = [];
            Object.assign(this, obj);
        }
        return OrderError;
    }());
    OrderError.ERROR_NOT_USER = 'not_user';
    OrderError.ERROR_PRODUCT_STOCK = 'product_stock';
    OrderError.ERROR_INGREDIENT_STOCK = 'ingredient_stock';
    OrderError.ERROR_CHOICE_STOCK = 'choice_stock';
    OrderError.ERROR_DELIVERY_SLOT_INVALID = 'delivery_slot_invalid';
    OrderError.ERROR_SC_OPTION_STOCK = 'sc_option_stock';
    OrderError.ERROR_CHOICE_GROUP = 'choice_group';
    OrderError.ERROR_DELIVERY_NOT_SUPPORTED = 'delivery_not_supported';
    OrderError.ERROR_PICKUP_NOT_SUPPORTED = 'pickup_not_supported';
    OrderError.ERROR_MIN_AMOUNT_NOT_REACHED = 'min_amount_not_reached';
    var Restaurant = /** @class */ (function () {
        function Restaurant(obj) {
            if (obj === void 0) { obj = {}; }
            this.name = '';
            this.deliveryMinimum = 0;
            this.deliveryPrice = 0;
            this.allowDelivery = false;
            this.allowPickup = false;
            this.minimumTimeBeforeDelivery = 0;
            this.minimumTimeBeforePickup = 0;
            this.deliverySlotDuration = 0;
            this.pickupSlotDuration = 0;
            this.message = null;
            this.mode = 'production';
            Object.assign(this, obj);
            this.address = new Address(obj.address);
            this.openingHours = ((obj === null || obj === void 0 ? void 0 : obj.openingHours) || []).map(function (o) { return new Hour(o); });
            this.deliveryHours = ((obj === null || obj === void 0 ? void 0 : obj.deliveryHours) || []).map(function (o) { return new Hour(o); });
        }
        Restaurant.prototype.toString = function () {
            return this.name;
        };
        Restaurant.prototype.imageFullUrl = function () {
            return LibConfiguration.imageUrlFromPath(this.image);
        };
        Restaurant.prototype.logoFullUrl = function () {
            return LibConfiguration.imageUrlFromPath(this.logo);
        };
        return Restaurant;
    }());
    var RestaurantClosure = /** @class */ (function () {
        function RestaurantClosure(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
            this.restaurant = obj.restaurant ? new Restaurant(obj.restaurant) : null;
        }
        RestaurantClosure.prototype.formattedStartDate = function () {
            return moment$1(this.startsAt).format('D MMMM YYYY');
        };
        RestaurantClosure.prototype.formattedEndDate = function () {
            return moment$1(this.endsAt).format('D MMMM YYYY');
        };
        RestaurantClosure.prototype.formattedStartTime = function () {
            return moment$1(this.startsAt).format('HH:mm');
        };
        RestaurantClosure.prototype.formattedEndTime = function () {
            return moment$1(this.endsAt).format('HH:mm');
        };
        return RestaurantClosure;
    }());
    var RestaurantStats = /** @class */ (function () {
        function RestaurantStats(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return RestaurantStats;
    }());
    var Company = /** @class */ (function () {
        function Company(obj) {
            if (obj === void 0) { obj = {}; }
            var _a;
            Object.assign(this, obj);
            this.events = ((_a = obj === null || obj === void 0 ? void 0 : obj.events) === null || _a === void 0 ? void 0 : _a.map(function (a) { return new EventCompany(a); })) || [];
            this.address = obj.address ? new Address(obj.address) : null;
        }
        Company.prototype.getEventCompany = function (eventId) {
            return this.events.find(function (e) { return e.event.id === eventId; });
        };
        return Company;
    }());
    var Table = /** @class */ (function () {
        function Table(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return Table;
    }());
    var TableManagement = /** @class */ (function () {
        function TableManagement(obj) {
            if (obj === void 0) { obj = {}; }
            this.orders = [];
            this.open = false;
            this.enabled = true;
            Object.assign(this, obj);
        }
        return TableManagement;
    }());
    var Zone = /** @class */ (function () {
        function Zone(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b;
            Object.assign(this, obj);
            this.tables = ((_a = obj === null || obj === void 0 ? void 0 : obj.tables) === null || _a === void 0 ? void 0 : _a.map(function (t) { return new Table(t); })) || [];
            this.objects = ((_b = obj === null || obj === void 0 ? void 0 : obj.objects) === null || _b === void 0 ? void 0 : _b.map(function (o) { return new ZoneObject(o); })) || [];
            this.restaurant = obj.restaurant ? new Restaurant(obj.restaurant) : null;
        }
        return Zone;
    }());
    var ZoneObject = /** @class */ (function () {
        function ZoneObject(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return ZoneObject;
    }());
    var Employee = /** @class */ (function () {
        function Employee(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
            if (obj === null || obj === void 0 ? void 0 : obj.hasOwnProperty('team')) {
                this.team = new Team(obj.team);
            }
        }
        return Employee;
    }());
    var Team = /** @class */ (function () {
        function Team(obj) {
            if (obj === void 0) { obj = {}; }
            var _a;
            Object.assign(this, obj);
            this.restaurant = (obj === null || obj === void 0 ? void 0 : obj.restaurant) ? new Restaurant(obj.restaurant) : null;
            this.employees = ((_a = obj === null || obj === void 0 ? void 0 : obj.employees) === null || _a === void 0 ? void 0 : _a.map(function (e) { return new Employee(e); })) || [];
        }
        return Team;
    }());
    var PosReport = /** @class */ (function () {
        function PosReport(obj) {
            if (obj === void 0) { obj = {}; }
            var _a;
            Object.assign(this, obj);
            this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(function (i) { return new PosReportItem(i); })) || [];
            if (obj === null || obj === void 0 ? void 0 : obj.hasOwnProperty('session')) {
                this.session = typeof obj.session === 'string' ? obj.session : new Session(obj.session);
            }
        }
        return PosReport;
    }());
    var PosReportItem = /** @class */ (function () {
        function PosReportItem(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
            if (obj === null || obj === void 0 ? void 0 : obj.hasOwnProperty('originEmployee')) {
                this.originEmployee = typeof obj.originEmployee === 'string' ? obj.originEmployee : new Employee(obj.originEmployee);
            }
        }
        return PosReportItem;
    }());
    var Tag = /** @class */ (function () {
        function Tag(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return Tag;
    }());
    var Address = /** @class */ (function () {
        function Address(obj) {
            if (obj) {
                Object.assign(this, obj);
            }
        }
        Address.prototype.toString = function () {
            return this.name;
        };
        return Address;
    }());
    var UserRegister = /** @class */ (function () {
        function UserRegister() {
        }
        return UserRegister;
    }());
    var ClientConfig = /** @class */ (function () {
        function ClientConfig(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
            if (obj.hasOwnProperty('appConfiguration')) {
                this.appConfiguration = new AppConfiguration(obj.appConfiguration);
            }
            if (obj.hasOwnProperty('websiteConfiguration')) {
                this.websiteConfiguration = new WebsiteConfiguration(obj.websiteConfiguration);
            }
            if (obj.hasOwnProperty('configuration')) {
                this.configuration = new Configuration(obj.configuration);
            }
        }
        return ClientConfig;
    }());
    var Configuration = /** @class */ (function () {
        function Configuration(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return Configuration;
    }());
    var AppConfiguration = /** @class */ (function (_super) {
        __extends(AppConfiguration, _super);
        function AppConfiguration(obj) {
            if (obj === void 0) { obj = {}; }
            return _super.call(this, obj) || this;
        }
        return AppConfiguration;
    }(Configuration));
    var WebsiteConfiguration = /** @class */ (function (_super) {
        __extends(WebsiteConfiguration, _super);
        function WebsiteConfiguration(obj) {
            if (obj === void 0) { obj = {}; }
            return _super.call(this, obj) || this;
        }
        return WebsiteConfiguration;
    }(Configuration));
    var Client = /** @class */ (function () {
        function Client(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        Client.prototype.logoFullUrl = function () {
            return LibConfiguration.imageUrlFromPath(this.logo);
        };
        return Client;
    }());
    var ClientBilling = /** @class */ (function () {
        function ClientBilling(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return ClientBilling;
    }());
    var User = /** @class */ (function () {
        function User(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b;
            this.notifyOnRegister = true;
            Object.assign(this, obj);
            this.addresses = (_a = obj.addresses) === null || _a === void 0 ? void 0 : _a.map(function (a) { return new Address(a); });
            if (obj.hasOwnProperty('client')) {
                this.client = new Client(obj.client);
            }
            if (obj.hasOwnProperty('company') && typeof obj.company !== 'string' && obj.company !== null) {
                this.company = new Company(obj.company);
            }
            this.restaurants = (_b = obj.restaurants) === null || _b === void 0 ? void 0 : _b.map(function (r) { return new Restaurant(r); });
        }
        User.prototype.isProUser = function () {
            return this.role === USER_ROLES.ROLE_PRO;
        };
        User.prototype.formattedRole = function () {
            return User.roles[this.role].label;
        };
        return User;
    }());
    User.roles = {
        ROLE_OWNER: {
            slug: 'ROLE_OWNER',
            label: 'Propriétaire'
        },
        ROLE_SALE: {
            slug: 'ROLE_SALE',
            label: 'Commercial'
        },
        ROLE_ACCOUNTANT: {
            slug: 'ROLE_ACCOUNTANT',
            label: 'Comptable'
        },
        ROLE_USER: {
            slug: 'ROLE_USER',
            label: 'Utilisateur'
        },
        ROLE_PRO: {
            slug: 'ROLE_PRO',
            label: 'Professionnel'
        },
        ROLE_DELIVERY: {
            slug: 'ROLE_DELIVERY',
            label: 'Livreur'
        },
        ROLE_ADMIN: {
            slug: 'ROLE_ADMIN',
            label: 'Admin'
        },
        ROLE_SUPER_ADMIN: {
            slug: 'ROLE_SUPER_ADMIN',
            label: 'Super admin'
        },
        ROLE_CASHIER: {
            slug: 'ROLE_CASHIER',
            label: 'Caissier'
        }
    };
    var OrderItemChoice = /** @class */ (function () {
        function OrderItemChoice(obj) {
            if (obj === void 0) { obj = {}; }
            this.id = '';
            this.name = '';
            this.price = 0;
            this.quantity = 0;
            Object.assign(this, obj);
        }
        return OrderItemChoice;
    }());
    var OrderItemChoiceGroup = /** @class */ (function () {
        function OrderItemChoiceGroup(obj) {
            if (obj === void 0) { obj = {}; }
            var _a;
            this.id = '';
            this.name = '';
            this.choices = [];
            Object.assign(this, obj);
            this.choices = (_a = obj.choices) === null || _a === void 0 ? void 0 : _a.map(function (c) { return new OrderItemChoice(c); });
        }
        OrderItemChoiceGroup.prototype.isSame = function (cg) {
            var e_1, _f;
            var _a, _b;
            if (cg.name !== this.name || ((_a = cg.choices) === null || _a === void 0 ? void 0 : _a.length) !== ((_b = this.choices) === null || _b === void 0 ? void 0 : _b.length)) {
                return false;
            }
            var _loop_1 = function (c) {
                var sameChoice = cg.choices.findIndex(function (i) { return i.name === c.name && i.price === c.price && i.quantity === c.quantity; }) !== -1;
                if (!sameChoice) {
                    return { value: false };
                }
            };
            try {
                for (var _g = __values(this.choices), _h = _g.next(); !_h.done; _h = _g.next()) {
                    var c = _h.value;
                    var state_1 = _loop_1(c);
                    if (typeof state_1 === "object")
                        return state_1.value;
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_h && !_h.done && (_f = _g.return)) _f.call(_g);
                }
                finally { if (e_1) throw e_1.error; }
            }
            return true;
        };
        return OrderItemChoiceGroup;
    }());
    var Menu = /** @class */ (function () {
        function Menu(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
            this.groups = (obj.groups || []).map(function (g) { return new MenuGroup(g); });
        }
        Menu.prototype.hasProduct = function (id) {
            var e_2, _f;
            try {
                for (var _g = __values(this.groups), _h = _g.next(); !_h.done; _h = _g.next()) {
                    var g = _h.value;
                    if (g.hasProduct(id)) {
                        return true;
                    }
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (_h && !_h.done && (_f = _g.return)) _f.call(_g);
                }
                finally { if (e_2) throw e_2.error; }
            }
            return false;
        };
        return Menu;
    }());
    var MenuGroup = /** @class */ (function () {
        function MenuGroup(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
            this.items = (obj.items || []).map(function (i) { return new MenuGroupItem(i); });
        }
        MenuGroup.prototype.hasProduct = function (id) {
            return this.items.findIndex(function (i) { return i.product === id; }) !== -1;
        };
        return MenuGroup;
    }());
    var MenuGroupItem = /** @class */ (function () {
        function MenuGroupItem(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return MenuGroupItem;
    }());
    var OrderItem = /** @class */ (function () {
        function OrderItem(obj) {
            if (obj === void 0) { obj = {}; }
            var _a;
            this.quantity = 0;
            this.price = 0;
            this.menuItemPrice = 0;
            this.total = 0;
            this.vat = 0;
            this.kitchenItem = false;
            this.choiceGroups = [];
            Object.assign(this, obj);
            this.choiceGroups = ((_a = obj === null || obj === void 0 ? void 0 : obj.choiceGroups) === null || _a === void 0 ? void 0 : _a.map(function (cg) { return new OrderItemChoiceGroup(cg); })) || [];
            this.originCategory = obj.originCategory ? new Category(obj.originCategory) : null;
            this.originProduct = obj.originProduct ? new Product(obj.originProduct) : null;
            this.originMenu = obj.originMenu ? new Menu(obj.originMenu) : null;
            this.vatRate = obj.vatRate ? new VatRate(obj.vatRate) : null;
            this.discount = obj.discount ? new OrderDiscount(obj.discount) : null;
            this.items = (obj.items || []).map(function (i) { return new OrderItem(i); });
            this.vats = (obj.vats || []).map(function (i) { return new OrderVat(i); });
        }
        OrderItem.prototype.applyDiscount = function (value) {
            this.discount = null;
            this.recalculateTotals();
            var discountType = value.toString().indexOf('%') !== -1 ? 'percent' : 'fixed';
            var rate;
            var amount;
            if (discountType === 'percent') {
                rate = +(value.toString().split('%')[0]) / 100;
                amount = Math.round(this.total * rate);
            }
            if (discountType === 'fixed') {
                amount = +value * 100;
                rate = amount / this.total;
            }
            if (amount > this.total || amount < 0) {
                return;
            }
            if (amount === 0) {
                this.discount = null;
            }
            else {
                this.discount = new OrderDiscount({
                    id: uuid.v4(),
                    type: discountType,
                    rate: rate,
                    amount: amount
                });
            }
            this.recalculateTotals();
        };
        OrderItem.prototype.removeDiscount = function () {
            if (!this.discount) {
                return;
            }
            this.discount = null;
            this.recalculateTotals();
        };
        OrderItem.prototype.recalculateTotals = function () {
            var e_3, _f, e_4, _g, e_5, _h, e_6, _j, e_7, _k, e_8, _l, e_9, _m;
            var choicesPrice = 0;
            var menuItemsPrice = 0;
            try {
                for (var _o = __values(this.items), _p = _o.next(); !_p.done; _p = _o.next()) {
                    var i = _p.value;
                    i.recalculateTotals();
                    menuItemsPrice += i.menuItemPrice;
                    try {
                        for (var _q = (e_4 = void 0, __values(i.choiceGroups)), _r = _q.next(); !_r.done; _r = _q.next()) {
                            var cg = _r.value;
                            try {
                                for (var _s = (e_5 = void 0, __values(cg.choices)), _t = _s.next(); !_t.done; _t = _s.next()) {
                                    var c = _t.value;
                                    if (c.quantity > 0) {
                                        choicesPrice += c.price * c.quantity;
                                    }
                                }
                            }
                            catch (e_5_1) { e_5 = { error: e_5_1 }; }
                            finally {
                                try {
                                    if (_t && !_t.done && (_h = _s.return)) _h.call(_s);
                                }
                                finally { if (e_5) throw e_5.error; }
                            }
                        }
                    }
                    catch (e_4_1) { e_4 = { error: e_4_1 }; }
                    finally {
                        try {
                            if (_r && !_r.done && (_g = _q.return)) _g.call(_q);
                        }
                        finally { if (e_4) throw e_4.error; }
                    }
                }
            }
            catch (e_3_1) { e_3 = { error: e_3_1 }; }
            finally {
                try {
                    if (_p && !_p.done && (_f = _o.return)) _f.call(_o);
                }
                finally { if (e_3) throw e_3.error; }
            }
            try {
                for (var _u = __values(this.choiceGroups), _v = _u.next(); !_v.done; _v = _u.next()) {
                    var cg = _v.value;
                    try {
                        for (var _w = (e_7 = void 0, __values(cg.choices)), _x = _w.next(); !_x.done; _x = _w.next()) {
                            var c = _x.value;
                            if (c.quantity > 0) {
                                choicesPrice += c.price * c.quantity;
                            }
                        }
                    }
                    catch (e_7_1) { e_7 = { error: e_7_1 }; }
                    finally {
                        try {
                            if (_x && !_x.done && (_k = _w.return)) _k.call(_w);
                        }
                        finally { if (e_7) throw e_7.error; }
                    }
                }
            }
            catch (e_6_1) { e_6 = { error: e_6_1 }; }
            finally {
                try {
                    if (_v && !_v.done && (_j = _u.return)) _j.call(_u);
                }
                finally { if (e_6) throw e_6.error; }
            }
            this.total = (choicesPrice + menuItemsPrice + this.price) * this.quantity;
            if (this.discount) {
                this.discount.amount = Math.round(this.total * this.discount.rate);
                this.total -= this.discount.amount;
            }
            if (this.type === 'menu') {
                // Menu vats
                this.vat = 0;
                this.vats = [];
                var originalTotal = 0;
                try {
                    for (var _y = __values(this.items), _z = _y.next(); !_z.done; _z = _y.next()) {
                        var i = _z.value;
                        i.recalculateTotals();
                        originalTotal += i.total + i.menuItemPrice;
                    }
                }
                catch (e_8_1) { e_8 = { error: e_8_1 }; }
                finally {
                    try {
                        if (_z && !_z.done && (_l = _y.return)) _l.call(_y);
                    }
                    finally { if (e_8) throw e_8.error; }
                }
                var _loop_2 = function (i) {
                    var part = ((i.total + i.menuItemPrice) / originalTotal) * 100;
                    var menuItemTotal = (this_1.total / 100) * part;
                    var vat = Math.round(menuItemTotal - (menuItemTotal / (1 + i.vatRate.rate)));
                    if (!vat || vat === 0) {
                        return "continue";
                    }
                    this_1.vat += vat;
                    var vatIndex = this_1.vats.findIndex(function (v) { return v.rate === i.vatRate.rate; });
                    if (vatIndex === -1) {
                        this_1.vats.push(new OrderVat({
                            id: uuid.v4(),
                            amount: vat,
                            rate: i.vatRate.rate,
                            baseTotal: menuItemTotal - vat
                        }));
                    }
                    else {
                        this_1.vats[vatIndex].amount += vat;
                        this_1.vats[vatIndex].baseTotal += menuItemTotal - vat;
                    }
                };
                var this_1 = this;
                try {
                    for (var _0 = __values(this.items), _1 = _0.next(); !_1.done; _1 = _0.next()) {
                        var i = _1.value;
                        _loop_2(i);
                    }
                }
                catch (e_9_1) { e_9 = { error: e_9_1 }; }
                finally {
                    try {
                        if (_1 && !_1.done && (_m = _0.return)) _m.call(_0);
                    }
                    finally { if (e_9) throw e_9.error; }
                }
                this.vats.sort(function (a, b) { return a.rate > b.rate ? 1 : -1; });
            }
            if (this.type !== 'menu') {
                // Product and MenuItem vat
                this.vat = Math.round(this.total - (this.total / (1 + this.vatRate.rate)));
                this.vats = [new OrderVat({
                        id: uuid.v4(),
                        amount: this.vat,
                        rate: this.vatRate.rate,
                        baseTotal: this.total - this.vat
                    })];
            }
        };
        OrderItem.prototype.hasTags = function () {
            var _a, _b, _c, _d;
            return ((_b = (_a = this.originProduct) === null || _a === void 0 ? void 0 : _a.tags) === null || _b === void 0 ? void 0 : _b.length) > 0 || ((_d = (_c = this.originCategory) === null || _c === void 0 ? void 0 : _c.tags) === null || _d === void 0 ? void 0 : _d.length) > 0;
        };
        OrderItem.prototype.isSame = function (i) {
            var _a, _b;
            if (this.items.length !== i.items.length) {
                return false;
            }
            if (this.items.length > 0) {
                return this.hasSameItems(i.items);
            }
            else {
                // For Divers Products
                if (i.type === 'product' && this.type === 'product' && !i.originProduct && !this.originProduct) {
                    if (i.originCategory.id === this.originCategory.id && i.price === this.price) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                // For Standard Products
                if (((_a = i.originProduct) === null || _a === void 0 ? void 0 : _a.id) !== ((_b = this.originProduct) === null || _b === void 0 ? void 0 : _b.id) || i.price !== this.price) {
                    return false;
                }
                return this.hasSameChoiceGroups(i.choiceGroups);
            }
        };
        OrderItem.prototype.hasSameItems = function (items) {
            var e_10, _f;
            var _loop_3 = function (i) {
                var sameItem = this_2.items.find(function (s) { return s.isSame(i); });
                if (sameItem === undefined) {
                    return { value: false };
                }
            };
            var this_2 = this;
            try {
                for (var items_1 = __values(items), items_1_1 = items_1.next(); !items_1_1.done; items_1_1 = items_1.next()) {
                    var i = items_1_1.value;
                    var state_2 = _loop_3(i);
                    if (typeof state_2 === "object")
                        return state_2.value;
                }
            }
            catch (e_10_1) { e_10 = { error: e_10_1 }; }
            finally {
                try {
                    if (items_1_1 && !items_1_1.done && (_f = items_1.return)) _f.call(items_1);
                }
                finally { if (e_10) throw e_10.error; }
            }
            return true;
        };
        OrderItem.prototype.hasSameChoiceGroups = function (choiceGroups) {
            var e_11, _f;
            var _a;
            if (((_a = this.choiceGroups) === null || _a === void 0 ? void 0 : _a.length) !== (choiceGroups === null || choiceGroups === void 0 ? void 0 : choiceGroups.length)) {
                return false;
            }
            var _loop_4 = function (cg) {
                var sameChoiceGroup = this_3.choiceGroups.find(function (s) { return s.isSame(cg); });
                if (sameChoiceGroup === undefined) {
                    return { value: false };
                }
            };
            var this_3 = this;
            try {
                for (var choiceGroups_1 = __values(choiceGroups), choiceGroups_1_1 = choiceGroups_1.next(); !choiceGroups_1_1.done; choiceGroups_1_1 = choiceGroups_1.next()) {
                    var cg = choiceGroups_1_1.value;
                    var state_3 = _loop_4(cg);
                    if (typeof state_3 === "object")
                        return state_3.value;
                }
            }
            catch (e_11_1) { e_11 = { error: e_11_1 }; }
            finally {
                try {
                    if (choiceGroups_1_1 && !choiceGroups_1_1.done && (_f = choiceGroups_1.return)) _f.call(choiceGroups_1);
                }
                finally { if (e_11) throw e_11.error; }
            }
            return true;
        };
        return OrderItem;
    }());
    var OrderOption = /** @class */ (function () {
        function OrderOption(obj) {
            if (obj === void 0) { obj = {}; }
            this.id = '';
            this.name = '';
            this.price = 0;
            this.vat = 0;
            this.quantity = 0;
            this.total = 0;
            Object.assign(this, obj);
        }
        return OrderOption;
    }());
    var Collection = /** @class */ (function () {
        function Collection(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b, _c;
            Object.assign(this, obj);
            this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(function (i) { return new CollectionItem(i); })) || [];
            this.operations = ((_b = obj === null || obj === void 0 ? void 0 : obj.operations) === null || _b === void 0 ? void 0 : _b.map(function (i) { return new CollectionOperation(i); })) || [];
            this.transactions = ((_c = obj === null || obj === void 0 ? void 0 : obj.transactions) === null || _c === void 0 ? void 0 : _c.map(function (i) { return new CollectionTransaction(i); })) || [];
        }
        Collection.prototype.reorderItems = function (items) {
            var e_12, _f, e_13, _g, e_14, _h;
            var _this = this;
            var filteredItems = items.filter(function (i) { return _this.items.findIndex(function (oi) { return oi.orderItem.id === i.id; }) !== -1; });
            var itemsByItems = {};
            var _loop_5 = function (fi) {
                itemsByItems[fi.id] = this_4.items.filter(function (s) { return s.orderItem.id === fi.id; });
            };
            var this_4 = this;
            try {
                for (var filteredItems_1 = __values(filteredItems), filteredItems_1_1 = filteredItems_1.next(); !filteredItems_1_1.done; filteredItems_1_1 = filteredItems_1.next()) {
                    var fi = filteredItems_1_1.value;
                    _loop_5(fi);
                }
            }
            catch (e_12_1) { e_12 = { error: e_12_1 }; }
            finally {
                try {
                    if (filteredItems_1_1 && !filteredItems_1_1.done && (_f = filteredItems_1.return)) _f.call(filteredItems_1);
                }
                finally { if (e_12) throw e_12.error; }
            }
            var itemsReordered = [];
            try {
                for (var _j = __values(Object.values(itemsByItems)), _k = _j.next(); !_k.done; _k = _j.next()) {
                    var value = _k.value;
                    try {
                        for (var value_1 = (e_14 = void 0, __values(value)), value_1_1 = value_1.next(); !value_1_1.done; value_1_1 = value_1.next()) {
                            var i = value_1_1.value;
                            itemsReordered.push(i);
                        }
                    }
                    catch (e_14_1) { e_14 = { error: e_14_1 }; }
                    finally {
                        try {
                            if (value_1_1 && !value_1_1.done && (_h = value_1.return)) _h.call(value_1);
                        }
                        finally { if (e_14) throw e_14.error; }
                    }
                }
            }
            catch (e_13_1) { e_13 = { error: e_13_1 }; }
            finally {
                try {
                    if (_k && !_k.done && (_g = _j.return)) _g.call(_j);
                }
                finally { if (e_13) throw e_13.error; }
            }
            this.items = itemsReordered;
        };
        return Collection;
    }());
    var CollectionItem = /** @class */ (function () {
        function CollectionItem(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
            if (obj.hasOwnProperty('orderItem') && obj.orderItem !== null) {
                this.orderItem = new OrderItem(obj.orderItem);
            }
        }
        CollectionItem.prototype.update = function (orderItem) {
            this.name = orderItem.name;
            this.total = orderItem.total;
            this.quantity = orderItem.quantity;
            this.orderItem = orderItem;
        };
        return CollectionItem;
    }());
    var CollectionOperation = /** @class */ (function () {
        function CollectionOperation(obj) {
            if (obj === void 0) { obj = {}; }
            var _a;
            Object.assign(this, obj);
            this.orderItems = ((_a = obj === null || obj === void 0 ? void 0 : obj.orderItems) === null || _a === void 0 ? void 0 : _a.map(function (i) { return new OrderItem(i); })) || [];
        }
        CollectionOperation.prototype.hasOrderItem = function (id) {
            return this.orderItems && this.orderItems.findIndex(function (s) { return s.id === id; }) !== -1;
        };
        CollectionOperation.prototype.hasOrderItemWithDiscount = function () {
            return this.orderItems && this.orderItems.filter(function (i) { return i.discount; }).length > 0;
        };
        return CollectionOperation;
    }());
    var CollectionTransaction = /** @class */ (function () {
        function CollectionTransaction(obj) {
            if (obj === void 0) { obj = {}; }
            var _a;
            Object.assign(this, obj);
            this.operations = ((_a = obj === null || obj === void 0 ? void 0 : obj.operations) === null || _a === void 0 ? void 0 : _a.map(function (i) { return new CollectionOperation(i); })) || [];
        }
        CollectionTransaction.prototype.hasOrderItem = function (id) {
            return this.operations && this.operations.findIndex(function (s) { return s.hasOrderItem(id); }) !== -1;
        };
        return CollectionTransaction;
    }());
    var Production = /** @class */ (function () {
        function Production(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b, _c, _d;
            this.topPriority = null;
            this.mode = 'auto';
            Object.assign(this, obj);
            this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(function (i) { return new ProductionItem(i); })) || [];
            this.itemsToSend = ((_b = obj === null || obj === void 0 ? void 0 : obj.itemsToSend) === null || _b === void 0 ? void 0 : _b.map(function (i) { return new ProductionItem(i); })) || [];
            this.itemsComing = ((_c = obj === null || obj === void 0 ? void 0 : obj.itemsComing) === null || _c === void 0 ? void 0 : _c.map(function (i) { return new ProductionItem(i); })) || [];
            this.tickets = ((_d = obj === null || obj === void 0 ? void 0 : obj.tickets) === null || _d === void 0 ? void 0 : _d.map(function (i) { return new ProductionTicket(i); })) || [];
        }
        Production.prototype.getLastTicket = function (exception) {
            var e_15, _f;
            if (exception === void 0) { exception = null; }
            var _a;
            var ticket = null;
            if (!exception) {
                return this.tickets.length > 0 ? this.tickets[0] : null;
            }
            try {
                for (var _g = __values(this.tickets), _h = _g.next(); !_h.done; _h = _g.next()) {
                    var i = _h.value;
                    if (((_a = i[exception]) === null || _a === void 0 ? void 0 : _a.length) > 0) {
                        continue;
                    }
                    return i;
                }
            }
            catch (e_15_1) { e_15 = { error: e_15_1 }; }
            finally {
                try {
                    if (_h && !_h.done && (_f = _g.return)) _f.call(_g);
                }
                finally { if (e_15) throw e_15.error; }
            }
            return ticket;
        };
        Production.prototype.durationSinceLastAction = function () {
            return moment$1().diff(moment$1(this.lastAction), 'minutes');
        };
        Production.prototype.setOrderItems = function (items) {
            var e_16, _f, e_17, _g, e_18, _h, e_19, _j, e_20, _k;
            var itemsById = {};
            try {
                for (var items_2 = __values(items), items_2_1 = items_2.next(); !items_2_1.done; items_2_1 = items_2.next()) {
                    var i = items_2_1.value;
                    itemsById[i.id] = i;
                    try {
                        for (var _l = (e_17 = void 0, __values(i.items)), _m = _l.next(); !_m.done; _m = _l.next()) {
                            var mi = _m.value;
                            itemsById[i.id] = mi;
                        }
                    }
                    catch (e_17_1) { e_17 = { error: e_17_1 }; }
                    finally {
                        try {
                            if (_m && !_m.done && (_g = _l.return)) _g.call(_l);
                        }
                        finally { if (e_17) throw e_17.error; }
                    }
                }
            }
            catch (e_16_1) { e_16 = { error: e_16_1 }; }
            finally {
                try {
                    if (items_2_1 && !items_2_1.done && (_f = items_2.return)) _f.call(items_2);
                }
                finally { if (e_16) throw e_16.error; }
            }
            try {
                for (var _o = __values(this.itemsToSend), _p = _o.next(); !_p.done; _p = _o.next()) {
                    var i = _p.value;
                    if (itemsById[i.orderItem]) {
                        i.originOrderItem = itemsById[i.orderItem];
                    }
                }
            }
            catch (e_18_1) { e_18 = { error: e_18_1 }; }
            finally {
                try {
                    if (_p && !_p.done && (_h = _o.return)) _h.call(_o);
                }
                finally { if (e_18) throw e_18.error; }
            }
            try {
                for (var _q = __values(this.itemsComing), _r = _q.next(); !_r.done; _r = _q.next()) {
                    var i = _r.value;
                    if (itemsById[i.orderItem]) {
                        i.originOrderItem = itemsById[i.orderItem];
                    }
                }
            }
            catch (e_19_1) { e_19 = { error: e_19_1 }; }
            finally {
                try {
                    if (_r && !_r.done && (_j = _q.return)) _j.call(_q);
                }
                finally { if (e_19) throw e_19.error; }
            }
            try {
                for (var _s = __values(this.tickets), _t = _s.next(); !_t.done; _t = _s.next()) {
                    var i = _t.value;
                    i.setOrderItems(items);
                }
            }
            catch (e_20_1) { e_20 = { error: e_20_1 }; }
            finally {
                try {
                    if (_t && !_t.done && (_k = _s.return)) _k.call(_s);
                }
                finally { if (e_20) throw e_20.error; }
            }
        };
        Production.prototype.clearItemLists = function () {
            this.items = [];
            this.itemsToSend = [];
            this.itemsComing = [];
        };
        Production.prototype.getTopPriority = function () {
            var e_21, _f, e_22, _g, e_23, _h;
            var _a, _b, _c, _d;
            var priority = 1;
            try {
                for (var _j = __values(this.tickets.filter(function (t) { return t.itemsToCancel.length === 0; })), _k = _j.next(); !_k.done; _k = _j.next()) {
                    var t = _k.value;
                    var itemsToSend = t.itemsToSend;
                    var itemsComing = t.itemsComing;
                    var p = 1;
                    if (itemsComing.length > 0) {
                        try {
                            for (var _l = (e_22 = void 0, __values(t.itemsComing)), _m = _l.next(); !_m.done; _m = _l.next()) {
                                var i = _m.value;
                                var itemPriority = (_b = (_a = i.originOrderItem) === null || _a === void 0 ? void 0 : _a.originCategory) === null || _b === void 0 ? void 0 : _b.productionPriority;
                                if (itemPriority > p) {
                                    p = itemPriority;
                                }
                            }
                        }
                        catch (e_22_1) { e_22 = { error: e_22_1 }; }
                        finally {
                            try {
                                if (_m && !_m.done && (_g = _l.return)) _g.call(_l);
                            }
                            finally { if (e_22) throw e_22.error; }
                        }
                    }
                    if (itemsToSend.length > 0) {
                        try {
                            for (var _o = (e_23 = void 0, __values(t.itemsToSend)), _p = _o.next(); !_p.done; _p = _o.next()) {
                                var i = _p.value;
                                var itemPriority = (_d = (_c = i.originOrderItem) === null || _c === void 0 ? void 0 : _c.originCategory) === null || _d === void 0 ? void 0 : _d.productionPriority;
                                if (itemPriority > priority) {
                                    p = itemPriority;
                                }
                            }
                        }
                        catch (e_23_1) { e_23 = { error: e_23_1 }; }
                        finally {
                            try {
                                if (_p && !_p.done && (_h = _o.return)) _h.call(_o);
                            }
                            finally { if (e_23) throw e_23.error; }
                        }
                    }
                    priority = p;
                }
            }
            catch (e_21_1) { e_21 = { error: e_21_1 }; }
            finally {
                try {
                    if (_k && !_k.done && (_f = _j.return)) _f.call(_j);
                }
                finally { if (e_21) throw e_21.error; }
            }
            return priority;
        };
        return Production;
    }());
    var ProductionItem = /** @class */ (function () {
        function ProductionItem(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
            if (obj.hasOwnProperty('originOrderItem') && obj.originOrderItem !== null) {
                this.originOrderItem = new OrderItem(obj.originOrderItem);
            }
        }
        return ProductionItem;
    }());
    var ProductionTicket = /** @class */ (function () {
        function ProductionTicket(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b, _c;
            this.copy = false;
            Object.assign(this, obj);
            this.itemsToSend = ((_a = obj === null || obj === void 0 ? void 0 : obj.itemsToSend) === null || _a === void 0 ? void 0 : _a.map(function (i) { return new ProductionItem(i); })) || [];
            this.itemsComing = ((_b = obj === null || obj === void 0 ? void 0 : obj.itemsComing) === null || _b === void 0 ? void 0 : _b.map(function (i) { return new ProductionItem(i); })) || [];
            this.itemsToCancel = ((_c = obj === null || obj === void 0 ? void 0 : obj.itemsToCancel) === null || _c === void 0 ? void 0 : _c.map(function (i) { return new ProductionItem(i); })) || [];
        }
        ProductionTicket.prototype.formattedType = function () {
            var _a;
            return ((_a = this.itemsToCancel) === null || _a === void 0 ? void 0 : _a.length) === 0 ? 'Ticket de production' : 'Ticket d\'annulation';
        };
        ProductionTicket.prototype.formattedCreatedAt = function (format) {
            return moment$1(this.createdAt).format(format || 'dddd DD MMMM YYYY à HH:mm');
        };
        ProductionTicket.prototype.setOrderItems = function (items) {
            var e_24, _f, e_25, _g, e_26, _h, e_27, _j, e_28, _k;
            var itemsById = {};
            try {
                for (var items_3 = __values(items), items_3_1 = items_3.next(); !items_3_1.done; items_3_1 = items_3.next()) {
                    var i = items_3_1.value;
                    itemsById[i.id] = i;
                    try {
                        for (var _l = (e_25 = void 0, __values(i.items)), _m = _l.next(); !_m.done; _m = _l.next()) {
                            var mi = _m.value;
                            itemsById[i.id] = mi;
                        }
                    }
                    catch (e_25_1) { e_25 = { error: e_25_1 }; }
                    finally {
                        try {
                            if (_m && !_m.done && (_g = _l.return)) _g.call(_l);
                        }
                        finally { if (e_25) throw e_25.error; }
                    }
                }
            }
            catch (e_24_1) { e_24 = { error: e_24_1 }; }
            finally {
                try {
                    if (items_3_1 && !items_3_1.done && (_f = items_3.return)) _f.call(items_3);
                }
                finally { if (e_24) throw e_24.error; }
            }
            try {
                for (var _o = __values(this.itemsToSend), _p = _o.next(); !_p.done; _p = _o.next()) {
                    var i = _p.value;
                    if (itemsById[i.orderItem]) {
                        i.originOrderItem = itemsById[i.orderItem];
                    }
                }
            }
            catch (e_26_1) { e_26 = { error: e_26_1 }; }
            finally {
                try {
                    if (_p && !_p.done && (_h = _o.return)) _h.call(_o);
                }
                finally { if (e_26) throw e_26.error; }
            }
            try {
                for (var _q = __values(this.itemsComing), _r = _q.next(); !_r.done; _r = _q.next()) {
                    var i = _r.value;
                    if (itemsById[i.orderItem]) {
                        i.originOrderItem = itemsById[i.orderItem];
                    }
                }
            }
            catch (e_27_1) { e_27 = { error: e_27_1 }; }
            finally {
                try {
                    if (_r && !_r.done && (_j = _q.return)) _j.call(_q);
                }
                finally { if (e_27) throw e_27.error; }
            }
            try {
                for (var _s = __values(this.itemsToCancel), _t = _s.next(); !_t.done; _t = _s.next()) {
                    var i = _t.value;
                    if (itemsById[i.orderItem]) {
                        i.originOrderItem = itemsById[i.orderItem];
                    }
                }
            }
            catch (e_28_1) { e_28 = { error: e_28_1 }; }
            finally {
                try {
                    if (_t && !_t.done && (_k = _s.return)) _k.call(_s);
                }
                finally { if (e_28) throw e_28.error; }
            }
        };
        return ProductionTicket;
    }());
    var Session = /** @class */ (function () {
        function Session(obj) {
            if (obj === void 0) { obj = {}; }
            this.uploaded = false;
            Object.assign(this, obj);
        }
        Session.prototype.getNextOrderNumber = function () {
            if (this.firstOrderNumber) {
                return this.lastOrderNumber + 1;
            }
            else {
                return (this.previousSessionLastOrderNumber || 0) + 1;
            }
        };
        Session.prototype.setOrderNumbers = function (n) {
            this.lastOrderNumber = n;
            if (!this.firstOrderNumber) {
                this.firstOrderNumber = n;
            }
        };
        Session.prototype.getNextInvoiceNumber = function () {
            if (this.firstInvoiceNumber) {
                return this.lastInvoiceNumber + 1;
            }
            else {
                return (this.previousSessionLastInvoiceNumber || 0) + 1;
            }
        };
        Session.prototype.setInvoiceNumbers = function (n) {
            this.lastInvoiceNumber = n;
            if (!this.firstInvoiceNumber) {
                this.firstInvoiceNumber = n;
            }
        };
        Session.prototype.openedAtFormatted = function () {
            return moment$1(this.openedAt).format('D MMM à HH:mm');
        };
        return Session;
    }());
    var License = /** @class */ (function () {
        function License(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        License.prototype.isValid = function () {
            return moment$1(this.expiresAt).isAfter(moment$1()) && this.isEnabled;
        };
        License.prototype.expiresAtFormatted = function () {
            return moment$1(this.expiresAt).format('D MMMM YYYY');
        };
        return License;
    }());
    var TransactionPayment = /** @class */ (function () {
        function TransactionPayment(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        TransactionPayment.prototype.formattedType = function () {
            return PAYMENT_METHODS[this.type].label;
        };
        TransactionPayment.prototype.icon = function () {
            return PAYMENT_METHODS[this.type].icon;
        };
        return TransactionPayment;
    }());
    var Hashes = /** @class */ (function () {
        function Hashes(obj) {
            var e_29, _f, e_30, _g, e_31, _h;
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
            if (Object.keys(obj.orders).length > 0) {
                try {
                    for (var _j = __values(Object.entries(obj.orders)), _k = _j.next(); !_k.done; _k = _j.next()) {
                        var _l = __read(_k.value, 2), key = _l[0], value = _l[1];
                        this.orders[key] = new Hash(value);
                    }
                }
                catch (e_29_1) { e_29 = { error: e_29_1 }; }
                finally {
                    try {
                        if (_k && !_k.done && (_f = _j.return)) _f.call(_j);
                    }
                    finally { if (e_29) throw e_29.error; }
                }
            }
            if (Object.keys(obj.transactions).length > 0) {
                try {
                    for (var _m = __values(Object.entries(obj.transactions)), _o = _m.next(); !_o.done; _o = _m.next()) {
                        var _p = __read(_o.value, 2), key = _p[0], value = _p[1];
                        this.transactions[key] = new Hash(value);
                    }
                }
                catch (e_30_1) { e_30 = { error: e_30_1 }; }
                finally {
                    try {
                        if (_o && !_o.done && (_g = _m.return)) _g.call(_m);
                    }
                    finally { if (e_30) throw e_30.error; }
                }
            }
            if (Object.keys(obj.reportItems).length > 0) {
                try {
                    for (var _q = __values(Object.entries(obj.reportItems)), _r = _q.next(); !_r.done; _r = _q.next()) {
                        var _s = __read(_r.value, 2), key = _s[0], value = _s[1];
                        this.reportItems[key] = new Hash(value);
                    }
                }
                catch (e_31_1) { e_31 = { error: e_31_1 }; }
                finally {
                    try {
                        if (_r && !_r.done && (_h = _q.return)) _h.call(_q);
                    }
                    finally { if (e_31) throw e_31.error; }
                }
            }
        }
        return Hashes;
    }());
    var Hash = /** @class */ (function () {
        function Hash(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return Hash;
    }());
    var TransactionVat = /** @class */ (function () {
        function TransactionVat(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return TransactionVat;
    }());
    var TransactionPart = /** @class */ (function () {
        function TransactionPart(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return TransactionPart;
    }());
    var InvoiceData = /** @class */ (function () {
        function InvoiceData(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return InvoiceData;
    }());
    var Transaction = /** @class */ (function () {
        function Transaction(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b, _c, _d;
            this.printed = false;
            this.printCount = 0;
            this.parts = [];
            Object.assign(this, obj);
            this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(function (i) { return new TransactionItem(i); })) || [];
            this.payments = ((_b = obj === null || obj === void 0 ? void 0 : obj.payments) === null || _b === void 0 ? void 0 : _b.map(function (p) { return new TransactionPayment(p); })) || [];
            this.vats = ((_c = obj === null || obj === void 0 ? void 0 : obj.vats) === null || _c === void 0 ? void 0 : _c.map(function (v) { return new TransactionVat(v); })) || [];
            this.parts = ((_d = obj === null || obj === void 0 ? void 0 : obj.parts) === null || _d === void 0 ? void 0 : _d.map(function (p) { return new TransactionPart(p); })) || [];
            this.user = (obj === null || obj === void 0 ? void 0 : obj.user) ? new User(obj.user) : null;
        }
        Transaction.prototype.formattedStatusInformations = function () {
            return TRANSACTION_STATUS_INFORMATIONS[this.status];
        };
        Transaction.prototype.formattedCancellationReason = function () {
            return ORDER_CANCELLATION_REASONS[this.cancellationReason].label;
        };
        Transaction.prototype.statusIcon = function () {
            switch (this.status) {
                case TRANSACTION_STATUS.paid.slug:
                    return 'checkmark-circle';
                default:
                    return 'alert-circle';
            }
        };
        Transaction.prototype.formattedStatus = function () {
            var _a;
            return (_a = TRANSACTION_STATUS[this.status]) === null || _a === void 0 ? void 0 : _a.label;
        };
        Transaction.prototype.cancel = function () {
            this.status = ORDER_STATUS.cancelled.slug;
        };
        Transaction.prototype.formattedCreatedAt = function (format) {
            return moment$1(this.createdAt).format(format || 'dddd DD MMMM YYYY à HH:mm');
        };
        Transaction.prototype.recalculateTotals = function () {
            var e_32, _f, e_33, _g;
            this.total = 0;
            this.vatTotal = 0;
            this.vats = [];
            try {
                for (var _h = __values(this.items), _j = _h.next(); !_j.done; _j = _h.next()) {
                    var i = _j.value;
                    this.total += i.total;
                    this.vatTotal += i.vat;
                    var _loop_6 = function (v) {
                        var vatIndex = this_5.vats.findIndex(function (s) { return s.rate === v.rate; });
                        if (vatIndex === -1) {
                            this_5.vats.push(new TransactionVat({
                                id: uuid.v4(),
                                amount: v.amount,
                                rate: v.rate,
                                baseTotal: v.baseTotal
                            }));
                        }
                        else {
                            this_5.vats[vatIndex].amount += v.amount;
                            this_5.vats[vatIndex].baseTotal += v.baseTotal;
                        }
                    };
                    var this_5 = this;
                    try {
                        for (var _k = (e_33 = void 0, __values(i.vats)), _l = _k.next(); !_l.done; _l = _k.next()) {
                            var v = _l.value;
                            _loop_6(v);
                        }
                    }
                    catch (e_33_1) { e_33 = { error: e_33_1 }; }
                    finally {
                        try {
                            if (_l && !_l.done && (_g = _k.return)) _g.call(_k);
                        }
                        finally { if (e_33) throw e_33.error; }
                    }
                    this.vats.sort(function (a, b) { return a.rate > b.rate ? 1 : -1; });
                }
            }
            catch (e_32_1) { e_32 = { error: e_32_1 }; }
            finally {
                try {
                    if (_j && !_j.done && (_f = _h.return)) _f.call(_h);
                }
                finally { if (e_32) throw e_32.error; }
            }
        };
        Transaction.prototype.getTotal = function () {
            return this.total ? this.total : this.amount;
        };
        Transaction.prototype.getPartsTotal = function () {
            var e_34, _f;
            var partsTotal = 0;
            try {
                for (var _g = __values(this.parts), _h = _g.next(); !_h.done; _h = _g.next()) {
                    var p = _h.value;
                    partsTotal += p.amount;
                }
            }
            catch (e_34_1) { e_34 = { error: e_34_1 }; }
            finally {
                try {
                    if (_h && !_h.done && (_f = _g.return)) _f.call(_g);
                }
                finally { if (e_34) throw e_34.error; }
            }
            return partsTotal;
        };
        Transaction.prototype.canAddPart = function (amount) {
            return (this.status === TRANSACTION_STATUS.paid.slug || this.status === TRANSACTION_STATUS.paid_account.slug)
                && !this.originalTransaction
                && amount >= 0
                && (this.getPartsTotal() + amount) <= this.total;
        };
        return Transaction;
    }());
    var TransactionItem = /** @class */ (function () {
        function TransactionItem(obj) {
            if (obj === void 0) { obj = {}; }
            var _a;
            Object.assign(this, obj);
            this.vats = ((_a = obj === null || obj === void 0 ? void 0 : obj.vats) === null || _a === void 0 ? void 0 : _a.map(function (v) { return new TransactionVat(v); })) || [];
        }
        return TransactionItem;
    }());
    var OrderVat = /** @class */ (function () {
        function OrderVat(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return OrderVat;
    }());
    var Order = /** @class */ (function () {
        function Order(obj) {
            var _this = this;
            if (obj === void 0) { obj = {}; }
            var _a, _b, _c, _d;
            this.hasKitchenItems = false;
            this.items = [];
            this.options = [];
            this.total = 0;
            this.transactions = [];
            this.vatTotal = 0;
            this.printed = false;
            this.printCount = 0;
            this.vats = [];
            Object.assign(this, obj);
            this.deliveryAddress = (obj === null || obj === void 0 ? void 0 : obj.deliveryAddress) ? new Address(obj.deliveryAddress) : null;
            this.billingAddress = (obj === null || obj === void 0 ? void 0 : obj.billingAddress) ? new Address(obj.billingAddress) : null;
            this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(function (i) { return new OrderItem(i); })) || [];
            this.options = ((_b = obj === null || obj === void 0 ? void 0 : obj.options) === null || _b === void 0 ? void 0 : _b.map(function (o) { return new OrderOption(o); })) || [];
            this.restaurant = (obj === null || obj === void 0 ? void 0 : obj.restaurant) ? (typeof obj.restaurant === 'string' ? obj.restaurant : new Restaurant(obj.restaurant)) : null;
            this.transactions = ((_c = obj === null || obj === void 0 ? void 0 : obj.transactions) === null || _c === void 0 ? void 0 : _c.map(function (t) {
                var transaction = new Transaction(t);
                transaction.order = _this.id;
                return transaction;
            })) || [];
            this.deliveredBy = (obj === null || obj === void 0 ? void 0 : obj.deliveredBy) ? new User(obj.deliveredBy) : null;
            this.pickupStall = (obj === null || obj === void 0 ? void 0 : obj.pickupStall) ? new EventStall(obj.pickupStall) : null;
            this.deliveryStall = (obj === null || obj === void 0 ? void 0 : obj.deliveryStall) ? new EventStall(obj.deliveryStall) : null;
            this.vats = ((_d = obj === null || obj === void 0 ? void 0 : obj.vats) === null || _d === void 0 ? void 0 : _d.map(function (v) { return new OrderVat(v); })) || [];
            this.discount = (obj === null || obj === void 0 ? void 0 : obj.discount) ? new OrderDiscount(obj.discount) : null;
            this.originEmployee = (obj === null || obj === void 0 ? void 0 : obj.originEmployee) ? new Employee(obj.originEmployee) : null;
            this.session = (obj === null || obj === void 0 ? void 0 : obj.session) ? (typeof obj.session === 'string' ? obj.session : new Session(obj.session)) : null;
            this.originTable = (obj === null || obj === void 0 ? void 0 : obj.originTable) ? new Table(obj.originTable) : null;
            this.setItemQuantity();
        }
        Order.prototype.setItemQuantity = function () {
            var e_35, _f;
            var qt = 0;
            try {
                for (var _g = __values(this.items), _h = _g.next(); !_h.done; _h = _g.next()) {
                    var i = _h.value;
                    qt += i.quantity;
                }
            }
            catch (e_35_1) { e_35 = { error: e_35_1 }; }
            finally {
                try {
                    if (_h && !_h.done && (_f = _g.return)) _f.call(_g);
                }
                finally { if (e_35) throw e_35.error; }
            }
            this.itemQuantity = qt;
        };
        Order.prototype.formattedCreatedAt = function (format) {
            return moment$1(this.createdAt).format(format || 'dddd DD MMMM YYYY à HH:mm');
        };
        Order.prototype.formattedShortCreatedAt = function () {
            return Utils.toShortDateTime(this.createdAt);
        };
        Order.prototype.formattedTimeCreatedAt = function () {
            return Utils.toTime(this.createdAt);
        };
        Order.prototype.formattedDeliverySlot = function (format) {
            return moment$1(this.deliverySlot).format(format || 'dddd DD MMMM YYYY à HH:mm');
        };
        Order.prototype.formattedShortDeliverySlot = function () {
            return Utils.toShortDateTime(this.deliverySlot);
        };
        Order.prototype.deliveryTime = function () {
            return Utils.toTime(this.deliverySlot);
        };
        Order.prototype.shortClientName = function () {
            return this.clientFirstname + ' ' + this.clientLastname.charAt(0).toUpperCase() + '.';
        };
        Order.prototype.formattedStatus = function () {
            return this.formatStatus(this.status);
        };
        Order.prototype.formattedStatusInformations = function (role) {
            if (role === void 0) { role = USER_ROLES.ROLE_USER; }
            if (this.status === 'delivering') {
                return this.deliveryMethod === 'delivery' ? ORDER_STATUS_INFORMATIONS[role].delivering : ORDER_STATUS_INFORMATIONS[role].picking;
            }
            else {
                return ORDER_STATUS_INFORMATIONS[role][this.status];
            }
        };
        Order.prototype.formatStatus = function (status) {
            switch (status) {
                case 'pending':
                    return 'En attente de paiement';
                case 'confirmed':
                    return 'Confirmée';
                case 'preparing':
                    return 'En cours de préparation';
                case 'delivering':
                    return this.deliveryMethod === 'delivery' ? 'En cours de livraison' : 'En attente de retrait';
                case 'done':
                    return 'Terminée';
                case 'cancelled':
                    return 'Annulée';
            }
            return null;
        };
        Order.prototype.previousStatus = function (formatted) {
            if (formatted === void 0) { formatted = false; }
            switch (this.status) {
                case 'confirmed':
                    return formatted ? this.formatStatus('pending') : 'pending';
                case 'preparing':
                    return formatted ? this.formatStatus('confirmed') : 'confirmed';
                case 'delivering':
                    return formatted ? this.formatStatus('preparing') : 'preparing';
                case 'done':
                    return formatted ? this.formatStatus('delivering') : 'delivering';
            }
            return null;
        };
        Order.prototype.nextStatus = function (formatted) {
            if (formatted === void 0) { formatted = false; }
            switch (this.status) {
                case 'confirmed':
                    return formatted ? this.formatStatus('preparing') : 'preparing';
                case 'preparing':
                    return formatted ? this.formatStatus('delivering') : 'delivering';
                case 'delivering':
                    return formatted ? this.formatStatus('done') : 'done';
            }
            return null;
        };
        Order.prototype.statusIcon = function () {
            switch (this.status) {
                case 'confirmed':
                    return 'checkmark-circle-outline';
                case 'preparing':
                    return 'flask';
                case 'delivering':
                    return this.deliveryMethod === 'delivery' ? 'bicycle' : 'flag';
                case 'done':
                    return 'checkmark-circle';
                default:
                    return 'hourglass';
            }
        };
        Order.prototype.getPaymentLink = function () {
            return LibConfiguration.generatePaymentLink(this.id);
        };
        Order.prototype.getKitchenItems = function () {
            return this.items.filter(function (n) { return n.kitchenItem; }).sort(function (n1, n2) {
                if (n1.name > n2.name) {
                    return 1;
                }
                if (n1.name < n2.name) {
                    return -1;
                }
                return 0;
            });
        };
        Order.prototype.canBePaid = function () {
            return this.status === 'pending' && moment$1().diff(moment$1(this.createdAt), 'minutes') <= 30;
        };
        Order.prototype.canAddItem = function () {
            return this.source === 'pos' && this.status === 'pending';
        };
        Order.prototype.formattedSource = function () {
            switch (this.source) {
                case 'website':
                    return 'Site web';
                case 'app':
                    return 'Application';
                case 'pos':
                    return 'Point de vente';
                default:
                    return 'Source inconnue';
            }
        };
        Order.prototype.recalculateTotals = function () {
            var e_36, _f;
            var _a, _b;
            this.total = 0;
            this.vatTotal = 0;
            this.vats = [];
            var _loop_7 = function (i) {
                var e_37, _j;
                i.recalculateTotals();
                this_6.total += i.total;
                if (((_a = i.items) === null || _a === void 0 ? void 0 : _a.length) === 0) {
                    if ((!i.vat || i.vat === 0)) {
                        return "continue";
                    }
                    this_6.vatTotal += i.vat;
                    var vatIndex = this_6.vats.findIndex(function (v) { return v.rate === i.vatRate.rate; });
                    if (vatIndex === -1 && i.vat > 0) {
                        this_6.vats.push(new OrderVat({
                            id: uuid.v4(),
                            amount: i.vat,
                            rate: i.vatRate.rate,
                            baseTotal: i.total - i.vat
                        }));
                    }
                    else {
                        this_6.vats[vatIndex].amount += i.vat;
                        this_6.vats[vatIndex].baseTotal += i.total - i.vat;
                    }
                }
                if (((_b = i.items) === null || _b === void 0 ? void 0 : _b.length) > 0) {
                    var _loop_8 = function (vat) {
                        this_6.vatTotal += vat.amount;
                        var vatIndex = this_6.vats.findIndex(function (v) { return v.rate === vat.rate; });
                        if (vatIndex === -1) {
                            this_6.vats.push(new OrderVat({
                                id: uuid.v4(),
                                amount: vat.amount,
                                rate: vat.rate,
                                baseTotal: vat.baseTotal
                            }));
                        }
                        else {
                            this_6.vats[vatIndex].amount += vat.amount;
                            this_6.vats[vatIndex].baseTotal += vat.baseTotal;
                        }
                    };
                    try {
                        for (var _k = (e_37 = void 0, __values(i.vats)), _l = _k.next(); !_l.done; _l = _k.next()) {
                            var vat = _l.value;
                            _loop_8(vat);
                        }
                    }
                    catch (e_37_1) { e_37 = { error: e_37_1 }; }
                    finally {
                        try {
                            if (_l && !_l.done && (_j = _k.return)) _j.call(_k);
                        }
                        finally { if (e_37) throw e_37.error; }
                    }
                }
            };
            var this_6 = this;
            try {
                for (var _g = __values(this.items), _h = _g.next(); !_h.done; _h = _g.next()) {
                    var i = _h.value;
                    _loop_7(i);
                }
            }
            catch (e_36_1) { e_36 = { error: e_36_1 }; }
            finally {
                try {
                    if (_h && !_h.done && (_f = _g.return)) _f.call(_g);
                }
                finally { if (e_36) throw e_36.error; }
            }
            this.vats.sort(function (a, b) { return a.rate > b.rate ? 1 : -1; });
            this.setItemQuantity();
        };
        Order.prototype.transactionsTotal = function () {
            var e_38, _f;
            var total = 0;
            try {
                for (var _g = __values(this.transactions), _h = _g.next(); !_h.done; _h = _g.next()) {
                    var t = _h.value;
                    total += t.amount;
                }
            }
            catch (e_38_1) { e_38 = { error: e_38_1 }; }
            finally {
                try {
                    if (_h && !_h.done && (_f = _g.return)) _f.call(_g);
                }
                finally { if (e_38) throw e_38.error; }
            }
            return total;
        };
        Order.prototype.totalRemaining = function () {
            return this.total - this.transactionsTotal();
        };
        Order.prototype.getNextTransactionNumber = function () {
            var c = this.transactions.length + 1;
            var n = ('' + c).padStart(3, '0');
            while (this.transactions.findIndex(function (t) { return t.number === n; }) !== -1) {
                c += 1;
                n = ('' + c).padStart(3, '0');
            }
            return n;
        };
        Order.prototype.canClose = function () {
            var transactionsTotal = this.transactionsTotal();
            return this.source === 'pos'
                && this.status === ORDER_STATUS.pending.slug
                && transactionsTotal === this.total;
        };
        Order.prototype.canCancel = function () {
            return this.source === 'pos' && !this.synchronized && this.status !== ORDER_STATUS.cancelled.slug;
        };
        Order.prototype.hasItemsWithTags = function () {
            return this.items.filter(function (i) { return i.hasTags(); }).length > 0;
        };
        Order.prototype.findCloneItems = function (item) {
            var _a;
            return (_a = this.items) === null || _a === void 0 ? void 0 : _a.filter(function (i) { return i.isSame(item); });
        };
        Order.prototype.durationSinceOrderTaken = function () {
            return moment$1().diff(moment$1(this.createdAt), 'minutes');
        };
        return Order;
    }());
    var OrderDiscount = /** @class */ (function () {
        function OrderDiscount(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return OrderDiscount;
    }());
    var PlaceOrder = /** @class */ (function () {
        function PlaceOrder(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
            this.options = (obj === null || obj === void 0 ? void 0 : obj.options.map(function (o) { return new PlaceOrderOption(o); })) || [];
        }
        return PlaceOrder;
    }());
    var PlaceOrderOption = /** @class */ (function () {
        function PlaceOrderOption(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return PlaceOrderOption;
    }());
    var PlaceOrderClient = /** @class */ (function () {
        function PlaceOrderClient() {
            this.firstname = null;
            this.lastname = null;
            this.phoneNumber = null;
            this.email = null;
            this.billingAddress = null;
            this.deliveryAddress = null;
        }
        return PlaceOrderClient;
    }());
    var VatRate = /** @class */ (function () {
        function VatRate(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return VatRate;
    }());
    var ContactModel = /** @class */ (function () {
        function ContactModel() {
            this.name = '';
            this.message = '';
            this.email = '';
        }
        return ContactModel;
    }());
    var DeliverySlot = /** @class */ (function () {
        function DeliverySlot(obj) {
            if (obj === void 0) { obj = {}; }
            this.label = '';
            this.id = '';
            this.startsAt = '';
            this.endsAt = '';
            this.isOpen = true;
            Object.assign(this, obj);
        }
        DeliverySlot.prototype.toString = function () {
            return this.label;
        };
        DeliverySlot.prototype.dayFormatted = function () {
            return moment$1(this.startsAt).format('dddd D MMMM');
        };
        DeliverySlot.prototype.shortDayFormatted = function () {
            return moment$1(this.startsAt).format('ddd D MMM');
        };
        DeliverySlot.prototype.fullDateFormatted = function () {
            var today = moment$1().isSame(this.startsAt, 'day');
            return today ? 'Aujourd\'hui, ' + this.label : moment$1(this.startsAt).format('dddd D MMM, ') + this.label;
        };
        return DeliverySlot;
    }());
    var NextDeliverySlots = /** @class */ (function () {
        function NextDeliverySlots(obj) {
            if (obj === void 0) { obj = {}; }
            this.shop = null;
            this.delivery = null;
            Object.assign(this, obj);
            if (obj.hasOwnProperty('shop') && obj.shop !== null) {
                this.shop = new DeliverySlot(obj.shop);
            }
            if (obj.hasOwnProperty('delivery') && obj.delivery !== null) {
                this.delivery = new DeliverySlot(obj.delivery);
            }
        }
        return NextDeliverySlots;
    }());
    var DeliverySlots = /** @class */ (function () {
        function DeliverySlots(obj) {
            var e_39, _f, e_40, _g;
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
            if (this.shop) {
                this.shop = {};
                try {
                    for (var _h = __values(Object.entries(obj.shop)), _j = _h.next(); !_j.done; _j = _h.next()) {
                        var _k = __read(_j.value, 2), key = _k[0], value = _k[1];
                        this.shop[key] = value.map(function (d) { return new DeliverySlot(d); });
                    }
                }
                catch (e_39_1) { e_39 = { error: e_39_1 }; }
                finally {
                    try {
                        if (_j && !_j.done && (_f = _h.return)) _f.call(_h);
                    }
                    finally { if (e_39) throw e_39.error; }
                }
            }
            if (this.delivery) {
                this.delivery = {};
                try {
                    for (var _l = __values(Object.entries(obj.delivery)), _m = _l.next(); !_m.done; _m = _l.next()) {
                        var _o = __read(_m.value, 2), key = _o[0], value = _o[1];
                        this.delivery[key] = value.map(function (d) { return new DeliverySlot(d); });
                    }
                }
                catch (e_40_1) { e_40 = { error: e_40_1 }; }
                finally {
                    try {
                        if (_m && !_m.done && (_g = _l.return)) _g.call(_l);
                    }
                    finally { if (e_40) throw e_40.error; }
                }
            }
        }
        return DeliverySlots;
    }());
    var Hour = /** @class */ (function () {
        function Hour(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        Hour.prototype.getFormattedSlot = function (format) {
            if (format === void 0) { format = 'HH:mm'; }
            return moment$1(this.openingTime).format(format) + ' - ' + moment$1(this.closingTime).format(format);
        };
        return Hour;
    }());
    var HourGroup = /** @class */ (function () {
        function HourGroup(obj) {
            if (obj === void 0) { obj = {}; }
            var _a;
            Object.assign(this, obj);
            this.hours = (_a = obj === null || obj === void 0 ? void 0 : obj.hours) === null || _a === void 0 ? void 0 : _a.map(function (h) { return new Hour(h); });
        }
        return HourGroup;
    }());
    var Category = /** @class */ (function () {
        function Category(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b, _c, _d, _e;
            this.kitchen = false;
            this.products = [];
            this.menus = [];
            this.ingredients = [];
            this.productionPriority = 0;
            this.availableOnPos = true;
            this.availableOnWeb = true;
            this.availableOnMenu = true;
            this.canCreateProductOnPos = false;
            Object.assign(this, obj);
            this.products = ((_a = obj === null || obj === void 0 ? void 0 : obj.products) === null || _a === void 0 ? void 0 : _a.map(function (p) { return new Product(p); })) || [];
            this.menus = ((_b = obj === null || obj === void 0 ? void 0 : obj.menus) === null || _b === void 0 ? void 0 : _b.map(function (m) { return new Menu(m); })) || [];
            this.ingredients = ((_c = obj === null || obj === void 0 ? void 0 : obj.ingredients) === null || _c === void 0 ? void 0 : _c.map(function (i) { return new ProductIngredient(i); })) || [];
            this.hours = ((_d = obj === null || obj === void 0 ? void 0 : obj.hours) === null || _d === void 0 ? void 0 : _d.map(function (h) { return new HourGroup(h); })) || [];
            this.tags = ((_e = obj === null || obj === void 0 ? void 0 : obj.tags) === null || _e === void 0 ? void 0 : _e.map(function (t) { return new Tag(t); })) || [];
            this.vatRate = (obj === null || obj === void 0 ? void 0 : obj.vatRate) ? new VatRate(obj.vatRate) : null;
        }
        Category.prototype.toString = function () {
            return this.name;
        };
        Category.prototype.removableIngredients = function () {
            return this.ingredients.filter(function (i) { return i.isRemovable; });
        };
        Category.prototype.addableIngredients = function () {
            return this.ingredients.filter(function (i) { return i.isAddable; });
        };
        return Category;
    }());
    var Stock = /** @class */ (function () {
        function Stock(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
            if (obj === null || obj === void 0 ? void 0 : obj.restaurant) {
                this.restaurant = new Restaurant({
                    id: obj.restaurant.id
                });
            }
        }
        return Stock;
    }());
    var ProductChoice = /** @class */ (function (_super) {
        __extends(ProductChoice, _super);
        function ProductChoice(obj) {
            if (obj === void 0) { obj = {}; }
            var _this = this;
            var _a;
            _this = _super.call(this) || this;
            _this.type = ProductChoice.PRODUCT_CHOICE_TYPE_CUSTOM;
            _this.isDefault = false;
            Object.assign(_this, obj);
            if (_this.type === ProductChoice.PRODUCT_CHOICE_TYPE_CUSTOM) {
                _this.stocks = ((_a = obj === null || obj === void 0 ? void 0 : obj.stocks) === null || _a === void 0 ? void 0 : _a.map(function (s) { return new Stock(s); })) || [];
            }
            else {
                _this.ingredient = new ProductIngredient(obj.ingredient);
                _this.stocks = _this.ingredient.stocks;
            }
            _this.price = _this.type === ProductChoice.PRODUCT_CHOICE_TYPE_CUSTOM ? obj.price : _this.ingredient.price;
            _this.name = _this.type === ProductChoice.PRODUCT_CHOICE_TYPE_CUSTOM ? obj.name : _this.ingredient.name;
            return _this;
        }
        return ProductChoice;
    }(Sortable));
    ProductChoice.PRODUCT_CHOICE_TYPE_CUSTOM = 'custom';
    ProductChoice.PRODUCT_CHOICE_TYPE_INGREDIENT = 'ingredient';
    var ProductChoiceGroup = /** @class */ (function (_super) {
        __extends(ProductChoiceGroup, _super);
        function ProductChoiceGroup(obj) {
            if (obj === void 0) { obj = {}; }
            var _this = this;
            var _a;
            _this = _super.call(this) || this;
            _this.selectorType = null;
            Object.assign(_this, obj);
            _this.choices = ((_a = obj === null || obj === void 0 ? void 0 : obj.choices) === null || _a === void 0 ? void 0 : _a.map(function (c) { return new ProductChoice(c); })) || [];
            if (_this.minChoices === 1 && _this.maxChoices === 1) {
                _this.selectorType = 'radio';
            }
            else if (_this.useQuantitySelector === false) {
                _this.selectorType = 'checkbox';
            }
            else {
                _this.selectorType = 'quantity';
            }
            return _this;
        }
        return ProductChoiceGroup;
    }(Sortable));
    var ProductIngredient = /** @class */ (function () {
        function ProductIngredient(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b;
            Object.assign(this, obj);
            if (obj.hasOwnProperty('vatRate')) {
                this.vatRate = new VatRate(obj.vatRate);
            }
            this.stocks = ((_a = obj === null || obj === void 0 ? void 0 : obj.stocks) === null || _a === void 0 ? void 0 : _a.map(function (s) { return new Stock(s); })) || [];
            this.productCategories = ((_b = obj === null || obj === void 0 ? void 0 : obj.productCategories) === null || _b === void 0 ? void 0 : _b.map(function (c) { return new Category(c); })) || [];
        }
        return ProductIngredient;
    }());
    var ProductAllergen = /** @class */ (function () {
        function ProductAllergen(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return ProductAllergen;
    }());
    var Product = /** @class */ (function () {
        function Product(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b, _c, _d, _e;
            this.availableOnPos = true;
            this.availableOnWeb = true;
            this.availableOnMenu = true;
            this.isOption = false;
            Object.assign(this, obj);
            this.vatRate = (obj === null || obj === void 0 ? void 0 : obj.vatRate) ? new VatRate(obj.vatRate) : null;
            this.stocks = ((_a = obj === null || obj === void 0 ? void 0 : obj.stocks) === null || _a === void 0 ? void 0 : _a.map(function (s) { return new Stock(s); })) || [];
            this.choiceGroups = ((_b = obj === null || obj === void 0 ? void 0 : obj.choiceGroups) === null || _b === void 0 ? void 0 : _b.map(function (cg) { return new ProductChoiceGroup(cg); })) || [];
            this.ingredients = ((_c = obj === null || obj === void 0 ? void 0 : obj.ingredients) === null || _c === void 0 ? void 0 : _c.map(function (i) { return new ProductIngredient(i); })) || [];
            this.tags = ((_d = obj === null || obj === void 0 ? void 0 : obj.tags) === null || _d === void 0 ? void 0 : _d.map(function (i) { return new Tag(i); })) || [];
            this.allergens = ((_e = obj === null || obj === void 0 ? void 0 : obj.allergens) === null || _e === void 0 ? void 0 : _e.map(function (i) { return new ProductAllergen(i); })) || [];
            this.originCategory = (obj === null || obj === void 0 ? void 0 : obj.originCategory) ? new Category(obj.originCategory) : null;
        }
        Product.prototype.formattedName = function () {
            return this.name;
        };
        Product.prototype.formattedPrice = function () {
            return this.price / 100;
        };
        Product.prototype.removableIngredients = function () {
            return this.ingredients.filter(function (i) { return i.isRemovable; });
        };
        Product.prototype.imageFullUrl = function () {
            return LibConfiguration.imageUrlFromPath(this.image);
        };
        Product.prototype.hasRequiredConfiguration = function () {
            var _a;
            return ((_a = this.choiceGroups) === null || _a === void 0 ? void 0 : _a.filter(function (cg) { return cg.required; }).length) > 0;
        };
        Product.prototype.dimensionTypeFormatted = function () {
            return PRODUCT_DIMENSION_TYPES[this.dimensionType].label;
        };
        return Product;
    }());
    var ShoppingCartOption = /** @class */ (function () {
        function ShoppingCartOption(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b;
            Object.assign(this, obj);
            this.vatRate = (obj === null || obj === void 0 ? void 0 : obj.vatRate) ? new VatRate(obj.vatRate) : null;
            this.stocks = ((_a = obj === null || obj === void 0 ? void 0 : obj.stocks) === null || _a === void 0 ? void 0 : _a.map(function (s) { return new Stock(s); })) || [];
            this.restaurants = ((_b = obj === null || obj === void 0 ? void 0 : obj.restaurants) === null || _b === void 0 ? void 0 : _b.map(function (r) { return new Restaurant(r); })) || [];
        }
        return ShoppingCartOption;
    }());
    var ShoppingCartItemProductChoices = /** @class */ (function () {
        function ShoppingCartItemProductChoices() {
        }
        return ShoppingCartItemProductChoices;
    }());
    var ShoppingCart = /** @class */ (function () {
        function ShoppingCart(obj) {
            if (obj === void 0) { obj = {}; }
            var _a;
            this.id = null;
            this.items = [];
            this.unvalidItems = [];
            Object.assign(this, obj);
            this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(function (i) { return new ShoppingCartItem(i); })) || [];
        }
        return ShoppingCart;
    }());
    var ShoppingCartItem = /** @class */ (function () {
        function ShoppingCartItem(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b, _c, _d;
            this.id = null;
            Object.assign(this, obj);
            this.base.product = ((_a = obj.base) === null || _a === void 0 ? void 0 : _a.product) ? new Product(obj.base.product) : null;
            this.base.category = ((_b = obj.base) === null || _b === void 0 ? void 0 : _b.category) ? new Category(obj.base.category) : null;
            this.ingredientsToRemove = ((_c = obj === null || obj === void 0 ? void 0 : obj.ingredientsToRemove) === null || _c === void 0 ? void 0 : _c.map(function (i) { return new ProductIngredient(i); })) || [];
            this.ingredientsToAdd = ((_d = obj === null || obj === void 0 ? void 0 : obj.ingredientsToAdd) === null || _d === void 0 ? void 0 : _d.map(function (i) { return new ProductIngredient(i); })) || [];
        }
        ShoppingCartItem.prototype.total = function () {
            var e_41, _f, e_42, _g, e_43, _h;
            var choicesTotalPrice = 0;
            var ingredientsToAddTotalPrice = 0;
            try {
                for (var _j = __values(Object.entries(this.choiceGroups)), _k = _j.next(); !_k.done; _k = _j.next()) {
                    var _l = __read(_k.value, 2), key = _l[0], value = _l[1];
                    try {
                        for (var _m = (e_42 = void 0, __values(value.choices)), _o = _m.next(); !_o.done; _o = _m.next()) {
                            var c = _o.value;
                            choicesTotalPrice += c.choice.price * c.quantity;
                        }
                    }
                    catch (e_42_1) { e_42 = { error: e_42_1 }; }
                    finally {
                        try {
                            if (_o && !_o.done && (_g = _m.return)) _g.call(_m);
                        }
                        finally { if (e_42) throw e_42.error; }
                    }
                }
            }
            catch (e_41_1) { e_41 = { error: e_41_1 }; }
            finally {
                try {
                    if (_k && !_k.done && (_f = _j.return)) _f.call(_j);
                }
                finally { if (e_41) throw e_41.error; }
            }
            try {
                for (var _p = __values(this.ingredientsToAdd), _q = _p.next(); !_q.done; _q = _p.next()) {
                    var i = _q.value;
                    ingredientsToAddTotalPrice += i.price;
                }
            }
            catch (e_43_1) { e_43 = { error: e_43_1 }; }
            finally {
                try {
                    if (_q && !_q.done && (_h = _p.return)) _h.call(_p);
                }
                finally { if (e_43) throw e_43.error; }
            }
            return ((this.base.product.price + choicesTotalPrice + ingredientsToAddTotalPrice) * this.base.quantity);
        };
        ShoppingCartItem.prototype.vat = function () {
            return this.total() - (this.total() / (1 + this.base.product.vatRate.rate));
        };
        ShoppingCartItem.prototype.setQuantity = function (quantity) {
            this.base.quantity = quantity;
        };
        ShoppingCartItem.prototype.getChoiceGroups = function () {
            var e_44, _f;
            var choiceGroups = [];
            try {
                for (var _g = __values(Object.entries(this.choiceGroups)), _h = _g.next(); !_h.done; _h = _g.next()) {
                    var _j = __read(_h.value, 2), key = _j[0], value = _j[1];
                    choiceGroups.push(value);
                }
            }
            catch (e_44_1) { e_44 = { error: e_44_1 }; }
            finally {
                try {
                    if (_h && !_h.done && (_f = _g.return)) _f.call(_g);
                }
                finally { if (e_44) throw e_44.error; }
            }
            return choiceGroups;
        };
        return ShoppingCartItem;
    }());
    /* WIDGET */
    var Widget = /** @class */ (function () {
        function Widget(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b, _c;
            Object.assign(this, obj);
            if (obj.type === 'gallery') {
                this.items = ((_a = obj === null || obj === void 0 ? void 0 : obj.items) === null || _a === void 0 ? void 0 : _a.map(function (i) { return i.type === 'image' ? new WidgetGalleryImageItem(i) : new WidgetGalleryTextItem(i); })) || [];
            }
            if (obj.type === 'custom') {
                this.items = ((_b = obj === null || obj === void 0 ? void 0 : obj.items) === null || _b === void 0 ? void 0 : _b.map(function (i) {
                    if (i.type === 'custom') {
                        return new WidgetCustomCustomItem(i);
                    }
                    if (i.type === 'category') {
                        return new WidgetCustomCategoryItem(i);
                    }
                    if (i.type === 'product') {
                        return new WidgetCustomProductItem(i);
                    }
                })) || [];
            }
            this.restaurants = ((_c = obj === null || obj === void 0 ? void 0 : obj.restaurants) === null || _c === void 0 ? void 0 : _c.map(function (r) { return new Restaurant(r); })) || [];
        }
        return Widget;
    }());
    var WidgetItem = /** @class */ (function () {
        function WidgetItem(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        WidgetItem.prototype.imageFullUrl = function () {
            return LibConfiguration.imageUrlFromPath(this.image);
        };
        return WidgetItem;
    }());
    var WidgetGalleryItem = /** @class */ (function (_super) {
        __extends(WidgetGalleryItem, _super);
        function WidgetGalleryItem(obj) {
            if (obj === void 0) { obj = {}; }
            return _super.call(this, obj) || this;
        }
        return WidgetGalleryItem;
    }(WidgetItem));
    var WidgetGalleryImageItem = /** @class */ (function (_super) {
        __extends(WidgetGalleryImageItem, _super);
        function WidgetGalleryImageItem(obj) {
            if (obj === void 0) { obj = {}; }
            return _super.call(this, obj) || this;
        }
        return WidgetGalleryImageItem;
    }(WidgetGalleryItem));
    var WidgetGalleryTextItem = /** @class */ (function (_super) {
        __extends(WidgetGalleryTextItem, _super);
        function WidgetGalleryTextItem(obj) {
            if (obj === void 0) { obj = {}; }
            return _super.call(this, obj) || this;
        }
        return WidgetGalleryTextItem;
    }(WidgetGalleryItem));
    var WidgetCustomItem = /** @class */ (function (_super) {
        __extends(WidgetCustomItem, _super);
        function WidgetCustomItem(obj) {
            if (obj === void 0) { obj = {}; }
            return _super.call(this, obj) || this;
        }
        return WidgetCustomItem;
    }(WidgetItem));
    var WidgetCustomCustomItem = /** @class */ (function (_super) {
        __extends(WidgetCustomCustomItem, _super);
        function WidgetCustomCustomItem(obj) {
            if (obj === void 0) { obj = {}; }
            return _super.call(this, obj) || this;
        }
        WidgetCustomCustomItem.prototype.fileFullUrl = function () {
            return LibConfiguration.imageUrlFromPath(this.file);
        };
        return WidgetCustomCustomItem;
    }(WidgetCustomItem));
    var WidgetCustomCategoryItem = /** @class */ (function (_super) {
        __extends(WidgetCustomCategoryItem, _super);
        function WidgetCustomCategoryItem(obj) {
            if (obj === void 0) { obj = {}; }
            var _this = _super.call(this, obj) || this;
            _this.category = obj.hasOwnProperty('category') && obj.category ? new Category(obj.category) : null;
            return _this;
        }
        return WidgetCustomCategoryItem;
    }(WidgetCustomItem));
    var WidgetCustomProductItem = /** @class */ (function (_super) {
        __extends(WidgetCustomProductItem, _super);
        function WidgetCustomProductItem(obj) {
            if (obj === void 0) { obj = {}; }
            var _this = _super.call(this, obj) || this;
            _this.product = obj.hasOwnProperty('product') && obj.product ? new Product(obj.product) : null;
            return _this;
        }
        return WidgetCustomProductItem;
    }(WidgetCustomItem));
    /* EVENTS */
    var Event = /** @class */ (function () {
        function Event(obj) {
            if (obj === void 0) { obj = {}; }
            var _a, _b, _c;
            this.eventRestaurants = null;
            this.halls = null;
            this.companies = null;
            Object.assign(this, obj);
            this.eventRestaurants = ((_a = obj === null || obj === void 0 ? void 0 : obj.eventRestaurants) === null || _a === void 0 ? void 0 : _a.map(function (er) { return new EventRestaurant(er); })) || [];
            this.halls = ((_b = obj === null || obj === void 0 ? void 0 : obj.halls) === null || _b === void 0 ? void 0 : _b.map(function (h) { return new EventHall(h); })) || [];
            this.companies = ((_c = obj === null || obj === void 0 ? void 0 : obj.companies) === null || _c === void 0 ? void 0 : _c.map(function (c) { return new EventCompany(c); })) || [];
            this.location = (obj === null || obj === void 0 ? void 0 : obj.location) ? new EventLocation(obj.location) : null;
        }
        Event.prototype.getEventRestaurantByRestaurantId = function (restaurantId) {
            return this.eventRestaurants.find(function (er) { return er.restaurant.id === restaurantId; });
        };
        Event.prototype.getEventRestaurantsByHallId = function (hallId) {
            return this.eventRestaurants.filter(function (er) { return er.stall.hall.id === hallId; });
        };
        Event.prototype.formattedDates = function () {
            return moment$1(this.startsAt).format('DD.MM.YYYY') + ' - ' + moment$1(this.endsAt).format('DD.MM.YYYY');
        };
        Event.prototype.formattedStartDate = function () {
            return moment$1(this.startsAt).format('D MMMM');
        };
        Event.prototype.formattedEndDate = function () {
            return moment$1(this.endsAt).format('D MMMM');
        };
        Event.prototype.imageFullUrl = function () {
            return LibConfiguration.imageUrlFromPath(this.image);
        };
        Event.prototype.logoFullUrl = function () {
            return LibConfiguration.imageUrlFromPath(this.logo);
        };
        return Event;
    }());
    var EventLocation = /** @class */ (function () {
        function EventLocation(obj) {
            if (obj === void 0) { obj = {}; }
            var _a;
            Object.assign(this, obj);
            this.halls = ((_a = obj === null || obj === void 0 ? void 0 : obj.halls) === null || _a === void 0 ? void 0 : _a.map(function (h) { return new EventHall(h); })) || [];
        }
        return EventLocation;
    }());
    var EventHall = /** @class */ (function () {
        function EventHall(obj) {
            if (obj === void 0) { obj = {}; }
            Object.assign(this, obj);
        }
        return EventHall;
    }());
    var EventStall = /** @class */ (function () {
        function EventStall(obj) {
            if (obj === void 0) { obj = {}; }
            this.hall = null;
            Object.assign(this, obj);
            if (obj.hasOwnProperty('hall')) {
                this.hall = new EventHall(obj.hall);
            }
        }
        return EventStall;
    }());
    var EventRestaurant = /** @class */ (function () {
        function EventRestaurant(obj) {
            if (obj === void 0) { obj = {}; }
            this.restaurant = null;
            this.stall = null;
            Object.assign(this, obj);
            if (obj.hasOwnProperty('restaurant')) {
                this.restaurant = new Restaurant(obj.restaurant);
            }
            if (obj.hasOwnProperty('EventStall')) {
                this.stall = new EventStall(obj.stall);
            }
        }
        return EventRestaurant;
    }());
    var EventCompany = /** @class */ (function () {
        function EventCompany(obj) {
            if (obj === void 0) { obj = {}; }
            this.billedLater = false;
            Object.assign(this, obj);
            if (obj.hasOwnProperty('event')) {
                this.stall = new EventStall(obj.stall);
            }
            if (obj.hasOwnProperty('stall')) {
                this.stall = new EventStall(obj.stall);
            }
            if (obj.hasOwnProperty('company')) {
                this.company = new Company(obj.company);
            }
        }
        return EventCompany;
    }());

    var FormHelper = /** @class */ (function () {
        function FormHelper() {
        }
        FormHelper.getFirstInvalidControlError = function (form) {
            var controls = form.controls;
            for (var name in controls) {
                if (controls[name].invalid) {
                    return FormHelper.errors.hasOwnProperty(name) ? FormHelper.errors[name] : 'Un champ semble invalide, vérifier le formulaire et ressayez.';
                }
            }
            return null;
        };
        FormHelper.checkPasswords = function (plainPassword, plainPasswordConfirmation) {
            var hasError = plainPasswordConfirmation.value !== plainPassword.value;
            var error = hasError ? { incorrect: true } : null;
            plainPasswordConfirmation.setErrors(error);
            return error;
        };
        FormHelper.checkFieldValidity = function (control, condition) {
            var error = condition === false ? { incorrect: true } : null;
            control.setErrors(error);
            return error;
        };
        return FormHelper;
    }());
    FormHelper.errors = {
        firstname: 'La valeur du champ Prénom semble incorrecte.',
        lastname: 'La valeur du champ Nom semble incorrecte.',
        code: 'Le code que vous avez entré semble invalide. Il se comporte de 6 chiffres',
        email: 'La valeur du champ Email semble incorrecte.',
        mobilePhone: 'La valeur du champ Téléphone semble incorrecte.',
        message: 'La valeur du champ Message semble incorrecte.',
        oldPassword: 'La valeur du champ Ancien mot de passe semble incorrecte. Le mot de passe doit comporter au moins 5 caractères alpha-numériques.',
        plainPassword: 'La valeur du champ Mot de passe semble incorrecte. Le mot de passe doit comporter au moins 5 caractères alpha-numériques.',
        plainPasswordConfirmation: 'Les mots de passe ne correspondent pas, vérifiez qu\'ils soient bien identiques.',
        companyCode: 'Le code que vous avez entré semble incorrect.',
        reference: 'La référence de commande que vous avez entrée semble incorrecte.',
        serverIP: 'La valeur du champ IP semble incorrecte.'
    };

    var OrderHelper = /** @class */ (function () {
        function OrderHelper() {
        }
        OrderHelper.getNextTimelineStatuses = function (status) {
            var e_1, _a;
            var index = OrderHelper.orderStatusTimeline.indexOf(status);
            var statuses = [];
            var i = 0;
            try {
                for (var _b = __values(OrderHelper.orderStatusTimeline), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var s = _c.value;
                    if (s !== status && i > index) {
                        statuses.push(s);
                    }
                    ++i;
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
            return statuses;
        };
        OrderHelper.getPreviousTimelineStatuses = function (status) {
            var e_2, _a;
            var index = OrderHelper.orderStatusTimeline.indexOf(status);
            var statuses = [];
            var i = 0;
            try {
                for (var _b = __values(OrderHelper.orderStatusTimeline), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var s = _c.value;
                    if (s !== status && i < index) {
                        statuses.push(s);
                    }
                    ++i;
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_2) throw e_2.error; }
            }
            return statuses;
        };
        return OrderHelper;
    }());
    OrderHelper.orderStatuses = {
        pending: {
            slug: 'pending',
            formatted: 'En attente de paiement'
        },
        confirmed: {
            slug: 'confirmed',
            formatted: 'Confirmée'
        },
        preparing: {
            slug: 'preparing',
            formatted: 'Préparation'
        },
        delivering: {
            slug: 'delivering',
            formatted: 'Livraison'
        },
        done: {
            slug: 'done',
            formatted: 'Terminée'
        }
    };
    OrderHelper.orderStatusTimeline = ['pending', 'confirmed', 'preparing', 'delivering', 'done'];

    var VersionService = /** @class */ (function () {
        function VersionService(apiService) {
            this.apiService = apiService;
        }
        VersionService.prototype.getLastAppVersion = function () {
            return this.apiService.get('/version', false).pipe(operators.map(function (result) { return new AppVersion(result); }));
        };
        VersionService.prototype.getLastManagerVersion = function () {
            return this.apiService.get('/api/manager/version', false, false).pipe(operators.map(function (result) { return new ManagerVersion(result); }));
        };
        return VersionService;
    }());
    VersionService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function VersionService_Factory() { return new VersionService(i0__namespace.ɵɵinject(ApiService)); }, token: VersionService, providedIn: "root" });
    VersionService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    VersionService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var RestaurantService = /** @class */ (function () {
        function RestaurantService(apiService) {
            this.apiService = apiService;
            this.selectedRestaurant = new rxjs.BehaviorSubject(null);
            this.selectedRestaurant.next(RestaurantService.getFromLocalStorage());
        }
        RestaurantService.getFromLocalStorage = function () {
            var restaurant = JSON.parse(localStorage.getItem('selected_restaurant'));
            return restaurant ? new Restaurant(restaurant) : null;
        };
        RestaurantService.prototype.save = function () {
            localStorage.setItem('selected_restaurant', JSON.stringify(this.selectedRestaurant.value));
        };
        RestaurantService.prototype.list = function () {
            var _this = this;
            return this.apiService.get('/restaurants', false).pipe(operators.map(function (result) {
                var restaurants = result.map(function (r) { return new Restaurant(r); });
                if (restaurants.length > 0) {
                    if (_this.selectedRestaurant.value) {
                        var restaurant = restaurants.find(function (r) { return r.id === RestaurantService.getFromLocalStorage().id; });
                        if (restaurant) {
                            _this.selectRestaurant(restaurant);
                        }
                        else {
                            _this.selectRestaurant(null);
                        }
                    }
                }
                return restaurants;
            }));
        };
        RestaurantService.prototype.isProductAvailable = function (product) {
            var e_1, _a;
            try {
                for (var _b = __values(product.stocks), _c = _b.next(); !_c.done; _c = _b.next()) {
                    var stock = _c.value;
                    if (this.selectedRestaurant.value && stock.restaurant.id === this.selectedRestaurant.value.id) {
                        return stock.hasStock;
                    }
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
                }
                finally { if (e_1) throw e_1.error; }
            }
            return true;
        };
        RestaurantService.prototype.selectRestaurant = function (restaurant) {
            this.selectedRestaurant.next(restaurant);
            this.save();
        };
        RestaurantService.prototype.update = function (restaurantId, data) {
            return this.apiService.put('/restaurants/' + restaurantId, data, true);
        };
        RestaurantService.prototype.changeStock = function (restaurantId, productId, hasStock) {
            return this.apiService.put('/restaurant-stocks', {
                restaurant: restaurantId,
                product: productId,
                stock: hasStock
            }, true);
        };
        RestaurantService.prototype.getStats = function (restaurantId, date) {
            return this
                .apiService.get('/restaurants/' + restaurantId + '/stats?date=' + date, true)
                .pipe(operators.map(function (result) { return new RestaurantStats(result); }));
        };
        RestaurantService.prototype.generateSlots = function (restaurantId) {
            return this.apiService.post('/delivery/restaurant/' + restaurantId + '/generate', {}, true).pipe(operators.map(function (nextSlots) {
                return new NextDeliverySlots(nextSlots);
            }));
        };
        /**
        * @deprecated The method should not be used
        */
        RestaurantService.prototype.getTeams = function () {
            return this.apiService.get('/restaurants/' + this.selectedRestaurant.value.id + '/teams', true).pipe(operators.map(function (teams) {
                return teams.map(function (t) { return new Team(t); });
            }));
        };
        return RestaurantService;
    }());
    RestaurantService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function RestaurantService_Factory() { return new RestaurantService(i0__namespace.ɵɵinject(ApiService)); }, token: RestaurantService, providedIn: "root" });
    RestaurantService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    RestaurantService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var SessionService = /** @class */ (function () {
        function SessionService(apiService, restaurantService) {
            this.apiService = apiService;
            this.restaurantService = restaurantService;
        }
        SessionService.prototype.getLastSessionHashes = function () {
            return this.apiService.get('/restaurants/' + this.restaurantService.selectedRestaurant.value.id + '/hashes/last', true).pipe(operators.map(function (hashes) {
                return hashes;
            }));
        };
        SessionService.prototype.openSession = function (restaurantId) {
            return this.apiService.post('/sessions/restaurants/' + restaurantId + '/open', {}, true).pipe(operators.map(function (s) {
                return new Session(s);
            }));
        };
        SessionService.prototype.closeSession = function (restaurantId, data) {
            return this.apiService.post('/sessions/restaurants/' + restaurantId + '/close', data, true).pipe(operators.map(function (s) {
                return new Session(s);
            }));
        };
        SessionService.prototype.getSessionHash = function (sessionId) {
            return this.apiService.get('/sessions/' + sessionId + '/hash-key', true);
        };
        SessionService.prototype.getOpenedSession = function (restaurantId) {
            return this.apiService.get('/sessions/restaurants/' + restaurantId + '/opened', true).pipe(operators.map(function (s) {
                return (s === null || s === void 0 ? void 0 : s.id) ? new Session(s) : null;
            }));
        };
        return SessionService;
    }());
    SessionService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function SessionService_Factory() { return new SessionService(i0__namespace.ɵɵinject(ApiService), i0__namespace.ɵɵinject(RestaurantService)); }, token: SessionService, providedIn: "root" });
    SessionService.decorators = [
        { type: i0.Injectable, args: [{ providedIn: 'root' },] }
    ];
    SessionService.ctorParameters = function () { return [
        { type: ApiService },
        { type: RestaurantService }
    ]; };

    var EventService = /** @class */ (function () {
        function EventService(apiService) {
            this.apiService = apiService;
            this.selectedEvent = new rxjs.BehaviorSubject(null);
            this.selectedEvent.next(EventService.getFromLocalStorage());
        }
        EventService.getFromLocalStorage = function () {
            var event = JSON.parse(localStorage.getItem('selected_event'));
            return event ? new Event(event) : null;
        };
        EventService.prototype.save = function () {
            localStorage.setItem('selected_event', JSON.stringify(this.selectedEvent.value));
        };
        EventService.prototype.list = function () {
            var _this = this;
            return this.apiService.get('/events', false).pipe(operators.map(function (result) {
                var events = result.map(function (r) { return new Event(r); });
                if (events.length > 0) {
                    if (_this.selectedEvent.value) {
                        var event = events.find(function (e) { return e.id === EventService.getFromLocalStorage().id; });
                        if (event) {
                            _this.selectEvent(event);
                        }
                        else {
                            _this.selectEvent(null);
                        }
                    }
                }
                return events;
            }));
        };
        EventService.prototype.selectEvent = function (event) {
            this.selectedEvent.next(event);
            this.save();
        };
        EventService.prototype.getEventRestaurantByRestaurantId = function (id) {
            return this.selectedEvent.value.eventRestaurants.find(function (r) { return r.restaurant.id === id; });
        };
        return EventService;
    }());
    EventService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function EventService_Factory() { return new EventService(i0__namespace.ɵɵinject(ApiService)); }, token: EventService, providedIn: "root" });
    EventService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    EventService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var ClientService = /** @class */ (function () {
        function ClientService(apiService) {
            this.apiService = apiService;
        }
        ClientService.prototype.get = function () {
            return this.apiService.get('', true).pipe(operators.map(function (client) {
                return (client === null || client === void 0 ? void 0 : client.id) ? new Client(client) : null;
            }));
        };
        ClientService.prototype.getConfig = function () {
            return this.apiService.get('/config', true).pipe(operators.map(function (clientConfig) {
                return (clientConfig === null || clientConfig === void 0 ? void 0 : clientConfig.id) ? new ClientConfig(clientConfig) : null;
            }));
        };
        ClientService.prototype.getBilling = function () {
            return this.apiService.get('/billing', true).pipe(operators.map(function (clientBilling) {
                return new ClientBilling(clientBilling);
            }));
        };
        return ClientService;
    }());
    ClientService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function ClientService_Factory() { return new ClientService(i0__namespace.ɵɵinject(ApiService)); }, token: ClientService, providedIn: "root" });
    ClientService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    ClientService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var CompanyService = /** @class */ (function () {
        function CompanyService(apiService) {
            this.apiService = apiService;
        }
        CompanyService.prototype.search = function (searchedCompany) {
            return this.apiService.get('/companies/search?q=' + searchedCompany, true).pipe(operators.map(function (companies) {
                return companies.map(function (c) { return new Company(c); });
            }));
        };
        CompanyService.prototype.get = function (companyId) {
            return this.apiService.get('/companies/' + companyId, true).pipe(operators.map(function (company) {
                return new Company(company);
            }));
        };
        return CompanyService;
    }());
    CompanyService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function CompanyService_Factory() { return new CompanyService(i0__namespace.ɵɵinject(ApiService)); }, token: CompanyService, providedIn: "root" });
    CompanyService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    CompanyService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var CategoryService = /** @class */ (function () {
        function CategoryService(apiService, restaurantService) {
            this.apiService = apiService;
            this.restaurantService = restaurantService;
            this.shoppingCart = null;
        }
        CategoryService.prototype.list = function () {
            return this.apiService.get('/restaurants/' + this.restaurantService.selectedRestaurant.value.id + '/products', false).pipe(operators.map(function (categories) {
                return categories.map(function (c) { return new Category(c); });
            }));
        };
        CategoryService.prototype.first = function () {
            return this.apiService.get('/restaurants/' + this.restaurantService.selectedRestaurant.value.id + '/product-categories/first', false).pipe(operators.map(function (category) {
                return new Category(category);
            }));
        };
        CategoryService.prototype.buildCategoriesFromMenuData = function (data, restaurant) {
            var e_1, _c;
            var _a, _b;
            var categories = data.categories;
            var _loop_1 = function (c) {
                var e_2, _d, e_3, _e;
                var menus = (_a = data.menus) === null || _a === void 0 ? void 0 : _a.filter(function (m) { return m.category === c.id; });
                var products = (_b = data.products) === null || _b === void 0 ? void 0 : _b.filter(function (p) { return p.category === c.id; });
                var lightRestaurant = new Restaurant({
                    id: restaurant.id
                });
                if ((menus === null || menus === void 0 ? void 0 : menus.length) > 0) {
                    c.menus = menus;
                }
                if ((products === null || products === void 0 ? void 0 : products.length) > 0) {
                    c.products = products;
                    var _loop_2 = function (i) {
                        var e_4, _k;
                        i.stocks = data.stocks.filter(function (s) { return s.entity === i.id; });
                        try {
                            for (var _l = (e_4 = void 0, __values(i.stocks)), _m = _l.next(); !_m.done; _m = _l.next()) {
                                var s = _m.value;
                                s.restaurant = lightRestaurant;
                            }
                        }
                        catch (e_4_1) { e_4 = { error: e_4_1 }; }
                        finally {
                            try {
                                if (_m && !_m.done && (_k = _l.return)) _k.call(_l);
                            }
                            finally { if (e_4) throw e_4.error; }
                        }
                    };
                    try {
                        for (var _f = (e_2 = void 0, __values(c.ingredients)), _g = _f.next(); !_g.done; _g = _f.next()) {
                            var i = _g.value;
                            _loop_2(i);
                        }
                    }
                    catch (e_2_1) { e_2 = { error: e_2_1 }; }
                    finally {
                        try {
                            if (_g && !_g.done && (_d = _f.return)) _d.call(_f);
                        }
                        finally { if (e_2) throw e_2.error; }
                    }
                    var _loop_3 = function (p) {
                        var e_5, _o, e_6, _p, e_7, _q, e_8, _r;
                        p.choiceGroups = data.choices.filter(function (c) { return c.product === p.id; });
                        p.stocks = data.stocks.filter(function (s) { return s.entity === p.id; });
                        try {
                            for (var _s = (e_5 = void 0, __values(p.stocks)), _t = _s.next(); !_t.done; _t = _s.next()) {
                                var s = _t.value;
                                s.restaurant = lightRestaurant;
                            }
                        }
                        catch (e_5_1) { e_5 = { error: e_5_1 }; }
                        finally {
                            try {
                                if (_t && !_t.done && (_o = _s.return)) _o.call(_s);
                            }
                            finally { if (e_5) throw e_5.error; }
                        }
                        var _loop_4 = function (i) {
                            var e_9, _0;
                            i.stocks = data.stocks.filter(function (s) { return s.entity === i.id; });
                            try {
                                for (var _1 = (e_9 = void 0, __values(i.stocks)), _2 = _1.next(); !_2.done; _2 = _1.next()) {
                                    var s = _2.value;
                                    s.restaurant = lightRestaurant;
                                }
                            }
                            catch (e_9_1) { e_9 = { error: e_9_1 }; }
                            finally {
                                try {
                                    if (_2 && !_2.done && (_0 = _1.return)) _0.call(_1);
                                }
                                finally { if (e_9) throw e_9.error; }
                            }
                        };
                        try {
                            for (var _u = (e_6 = void 0, __values(p.ingredients)), _v = _u.next(); !_v.done; _v = _u.next()) {
                                var i = _v.value;
                                _loop_4(i);
                            }
                        }
                        catch (e_6_1) { e_6 = { error: e_6_1 }; }
                        finally {
                            try {
                                if (_v && !_v.done && (_p = _u.return)) _p.call(_u);
                            }
                            finally { if (e_6) throw e_6.error; }
                        }
                        try {
                            for (var _w = (e_7 = void 0, __values(p.choiceGroups)), _x = _w.next(); !_x.done; _x = _w.next()) {
                                var cg = _x.value;
                                var _loop_5 = function (c_1) {
                                    var e_10, _3, e_11, _4;
                                    c_1.stocks = data.stocks.filter(function (s) { return s.entity === c_1.id; });
                                    try {
                                        for (var _5 = (e_10 = void 0, __values(c_1.stocks)), _6 = _5.next(); !_6.done; _6 = _5.next()) {
                                            var s = _6.value;
                                            s.restaurant = lightRestaurant;
                                        }
                                    }
                                    catch (e_10_1) { e_10 = { error: e_10_1 }; }
                                    finally {
                                        try {
                                            if (_6 && !_6.done && (_3 = _5.return)) _3.call(_5);
                                        }
                                        finally { if (e_10) throw e_10.error; }
                                    }
                                    if (c_1.ingredient) {
                                        c_1.ingredient.stocks = data.stocks.filter(function (s) { return s.entity === c_1.ingredient.id; });
                                        try {
                                            for (var _7 = (e_11 = void 0, __values(c_1.ingredient.stocks)), _8 = _7.next(); !_8.done; _8 = _7.next()) {
                                                var s = _8.value;
                                                s.restaurant = lightRestaurant;
                                            }
                                        }
                                        catch (e_11_1) { e_11 = { error: e_11_1 }; }
                                        finally {
                                            try {
                                                if (_8 && !_8.done && (_4 = _7.return)) _4.call(_7);
                                            }
                                            finally { if (e_11) throw e_11.error; }
                                        }
                                    }
                                };
                                try {
                                    for (var _y = (e_8 = void 0, __values(cg.choices)), _z = _y.next(); !_z.done; _z = _y.next()) {
                                        var c_1 = _z.value;
                                        _loop_5(c_1);
                                    }
                                }
                                catch (e_8_1) { e_8 = { error: e_8_1 }; }
                                finally {
                                    try {
                                        if (_z && !_z.done && (_r = _y.return)) _r.call(_y);
                                    }
                                    finally { if (e_8) throw e_8.error; }
                                }
                            }
                        }
                        catch (e_7_1) { e_7 = { error: e_7_1 }; }
                        finally {
                            try {
                                if (_x && !_x.done && (_q = _w.return)) _q.call(_w);
                            }
                            finally { if (e_7) throw e_7.error; }
                        }
                    };
                    try {
                        for (var _h = (e_3 = void 0, __values(c.products)), _j = _h.next(); !_j.done; _j = _h.next()) {
                            var p = _j.value;
                            _loop_3(p);
                        }
                    }
                    catch (e_3_1) { e_3 = { error: e_3_1 }; }
                    finally {
                        try {
                            if (_j && !_j.done && (_e = _h.return)) _e.call(_h);
                        }
                        finally { if (e_3) throw e_3.error; }
                    }
                }
            };
            try {
                for (var categories_1 = __values(categories), categories_1_1 = categories_1.next(); !categories_1_1.done; categories_1_1 = categories_1.next()) {
                    var c = categories_1_1.value;
                    _loop_1(c);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (categories_1_1 && !categories_1_1.done && (_c = categories_1.return)) _c.call(categories_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            return categories.map(function (c) { return new Category(c); }).filter(function (c) { var _a, _b; return ((_a = c.products) === null || _a === void 0 ? void 0 : _a.length) > 0 || ((_b = c.menus) === null || _b === void 0 ? void 0 : _b.length) > 0 || c.canCreateProductOnPos; });
        };
        return CategoryService;
    }());
    CategoryService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function CategoryService_Factory() { return new CategoryService(i0__namespace.ɵɵinject(ApiService), i0__namespace.ɵɵinject(RestaurantService)); }, token: CategoryService, providedIn: "root" });
    CategoryService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    CategoryService.ctorParameters = function () { return [
        { type: ApiService },
        { type: RestaurantService }
    ]; };

    var ProductService = /** @class */ (function () {
        function ProductService(apiService, restaurantService) {
            this.apiService = apiService;
            this.restaurantService = restaurantService;
        }
        ProductService.prototype.getChoices = function (restaurantId) {
            return this.apiService.get('/sync2/restaurants/' + restaurantId + '/choices', true).pipe(operators.map(function (choices) {
                return choices.map(function (c) { return new ProductChoiceGroup(c); });
            }));
        };
        ProductService.prototype.get = function (productId) {
            return this.apiService.get('/products/' + productId, false).pipe(operators.map(function (product) {
                return new Product(product);
            }));
        };
        return ProductService;
    }());
    ProductService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function ProductService_Factory() { return new ProductService(i0__namespace.ɵɵinject(ApiService), i0__namespace.ɵɵinject(RestaurantService)); }, token: ProductService, providedIn: "root" });
    ProductService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    ProductService.ctorParameters = function () { return [
        { type: ApiService },
        { type: RestaurantService }
    ]; };

    var moment = moment___namespace;
    var ShoppingCartService = /** @class */ (function () {
        function ShoppingCartService(apiService, restaurantService) {
            this.apiService = apiService;
            this.restaurantService = restaurantService;
            this.shoppingCart = null;
            var shoppingCart = JSON.parse(localStorage.getItem('shopping_cart'));
            if ((shoppingCart === null || shoppingCart === void 0 ? void 0 : shoppingCart.createdAt) && moment().diff(moment(shoppingCart.createdAt), 'hours') < 24) {
                this.shoppingCart = new ShoppingCart(shoppingCart);
                return;
            }
            this.createNewShoppingCart();
        }
        ShoppingCartService.prototype.createNewShoppingCart = function () {
            this.shoppingCart = new ShoppingCart({ createdAt: moment().format() });
            this.save();
        };
        ShoppingCartService.prototype.getOptions = function () {
            return this.apiService.get('/shopping-cart-options').pipe(operators.map(function (options) {
                return options.map(function (o) { return new ShoppingCartOption(o); });
            }));
        };
        ShoppingCartService.prototype.getOptionsByRestaurant = function (restaurantId) {
            return this.apiService.get('/restaurants/' + restaurantId + '/shopping-cart-options').pipe(operators.map(function (options) {
                return options.map(function (o) { return new ShoppingCartOption(o); });
            }));
        };
        ShoppingCartService.prototype.count = function () {
            return this.shoppingCart ? this.shoppingCart.items.length : 0;
        };
        ShoppingCartService.prototype.save = function () {
            localStorage.setItem('shopping_cart', JSON.stringify(this.shoppingCart));
        };
        ShoppingCartService.prototype.set = function (shoppingCartItems) {
            this.shoppingCart.items = shoppingCartItems;
            this.save();
        };
        ShoppingCartService.prototype.add = function (shoppingCartItem) {
            shoppingCartItem.id = uuid.v4();
            this.shoppingCart.items.push(shoppingCartItem);
            this.save();
        };
        ShoppingCartService.prototype.reorderItemsByCategories = function (categories) {
            var e_1, _c, e_2, _d, e_3, _e;
            var _this = this;
            var filteredCategories = categories.filter(function (c) { return _this.shoppingCart.items.findIndex(function (sc) { return sc.base.category.id === c.id; }) !== -1; });
            var shoppingCartItemsOrderedByCategories = {};
            var _loop_1 = function (c) {
                shoppingCartItemsOrderedByCategories[c.id] = this_1.shoppingCart.items.filter(function (sc) { return sc.base.category.id === c.id; });
            };
            var this_1 = this;
            try {
                for (var filteredCategories_1 = __values(filteredCategories), filteredCategories_1_1 = filteredCategories_1.next(); !filteredCategories_1_1.done; filteredCategories_1_1 = filteredCategories_1.next()) {
                    var c = filteredCategories_1_1.value;
                    _loop_1(c);
                }
            }
            catch (e_1_1) { e_1 = { error: e_1_1 }; }
            finally {
                try {
                    if (filteredCategories_1_1 && !filteredCategories_1_1.done && (_c = filteredCategories_1.return)) _c.call(filteredCategories_1);
                }
                finally { if (e_1) throw e_1.error; }
            }
            var shoppingCartItemsReordered = [];
            try {
                for (var _f = __values(Object.values(shoppingCartItemsOrderedByCategories)), _g = _f.next(); !_g.done; _g = _f.next()) {
                    var value = _g.value;
                    try {
                        for (var value_1 = (e_3 = void 0, __values(value)), value_1_1 = value_1.next(); !value_1_1.done; value_1_1 = value_1.next()) {
                            var i = value_1_1.value;
                            shoppingCartItemsReordered.push(i);
                        }
                    }
                    catch (e_3_1) { e_3 = { error: e_3_1 }; }
                    finally {
                        try {
                            if (value_1_1 && !value_1_1.done && (_e = value_1.return)) _e.call(value_1);
                        }
                        finally { if (e_3) throw e_3.error; }
                    }
                }
            }
            catch (e_2_1) { e_2 = { error: e_2_1 }; }
            finally {
                try {
                    if (_g && !_g.done && (_d = _f.return)) _d.call(_f);
                }
                finally { if (e_2) throw e_2.error; }
            }
            if (shoppingCartItemsReordered.length !== this.shoppingCart.items.length) {
                return;
            }
            this.set(shoppingCartItemsReordered);
        };
        ShoppingCartService.prototype.update = function (shoppingCartItem) {
            var index = this.shoppingCart.items.findIndex(function (i) { return i.id === shoppingCartItem.id; });
            this.shoppingCart.items[index] = shoppingCartItem;
            var unvalidItemIndex = this.shoppingCart.unvalidItems.findIndex(function (i) { return i === shoppingCartItem.id; });
            if (unvalidItemIndex !== -1) {
                this.shoppingCart.unvalidItems.splice(unvalidItemIndex, 1);
            }
            this.save();
        };
        ShoppingCartService.prototype.remove = function (shoppingCartItem) {
            var index = this.shoppingCart.items.findIndex(function (i) { return i.id === shoppingCartItem.id; });
            this.shoppingCart.items.splice(index, 1);
            this.save();
        };
        ShoppingCartService.prototype.getCountByProductId = function (productId) {
            var e_4, _c;
            var count = 0;
            try {
                for (var _d = __values(this.shoppingCart.items), _e = _d.next(); !_e.done; _e = _d.next()) {
                    var i = _e.value;
                    if (i.base.product.id === productId) {
                        count += i.base.quantity;
                    }
                }
            }
            catch (e_4_1) { e_4 = { error: e_4_1 }; }
            finally {
                try {
                    if (_e && !_e.done && (_c = _d.return)) _c.call(_d);
                }
                finally { if (e_4) throw e_4.error; }
            }
            return count;
        };
        ShoppingCartService.prototype.getItems = function () {
            return this.shoppingCart.items;
        };
        ShoppingCartService.prototype.total = function () {
            var e_5, _c;
            var total = 0;
            try {
                for (var _d = __values(this.shoppingCart.items), _e = _d.next(); !_e.done; _e = _d.next()) {
                    var item = _e.value;
                    total += item.total();
                }
            }
            catch (e_5_1) { e_5 = { error: e_5_1 }; }
            finally {
                try {
                    if (_e && !_e.done && (_c = _d.return)) _c.call(_d);
                }
                finally { if (e_5) throw e_5.error; }
            }
            return total;
        };
        ShoppingCartService.prototype.vat = function () {
            var e_6, _c;
            var vat = 0;
            try {
                for (var _d = __values(this.shoppingCart.items), _e = _d.next(); !_e.done; _e = _d.next()) {
                    var item = _e.value;
                    vat += item.vat() * item.base.quantity;
                }
            }
            catch (e_6_1) { e_6 = { error: e_6_1 }; }
            finally {
                try {
                    if (_e && !_e.done && (_c = _d.return)) _c.call(_d);
                }
                finally { if (e_6) throw e_6.error; }
            }
            return vat;
        };
        ShoppingCartService.prototype.emptyCart = function () {
            this.createNewShoppingCart();
            this.save();
        };
        ShoppingCartService.prototype.convertToOrderItem = function (item, type) {
            var e_7, _c, e_8, _d, e_9, _e, e_10, _f;
            if (type === void 0) { type = 'product'; }
            var _a, _b;
            var choiceGroups = [];
            try {
                for (var _g = __values(Object.values(item.choiceGroups)), _h = _g.next(); !_h.done; _h = _g.next()) {
                    var cg = _h.value;
                    var choices = [];
                    try {
                        for (var _j = (e_8 = void 0, __values(cg.choices)), _k = _j.next(); !_k.done; _k = _j.next()) {
                            var c = _k.value;
                            choices.push(new OrderItemChoice({
                                id: uuid.v4(),
                                name: c.choice.name,
                                price: c.choice.price,
                                quantity: c.quantity,
                                total: c.choice.price * c.quantity
                            }));
                        }
                    }
                    catch (e_8_1) { e_8 = { error: e_8_1 }; }
                    finally {
                        try {
                            if (_k && !_k.done && (_d = _j.return)) _d.call(_j);
                        }
                        finally { if (e_8) throw e_8.error; }
                    }
                    if (choices.length > 0) {
                        choiceGroups.push(new OrderItemChoiceGroup({
                            id: uuid.v4(),
                            name: cg.base.name,
                            choices: choices
                        }));
                    }
                }
            }
            catch (e_7_1) { e_7 = { error: e_7_1 }; }
            finally {
                try {
                    if (_h && !_h.done && (_c = _g.return)) _c.call(_g);
                }
                finally { if (e_7) throw e_7.error; }
            }
            if (((_a = item.ingredientsToAdd) === null || _a === void 0 ? void 0 : _a.length) > 0) {
                var choices = [];
                try {
                    for (var _l = __values(Object.values(item.ingredientsToAdd)), _m = _l.next(); !_m.done; _m = _l.next()) {
                        var i = _m.value;
                        choices.push(new OrderItemChoice({
                            id: uuid.v4(),
                            name: i.name,
                            price: i.price,
                            quantity: 1,
                            total: i.price
                        }));
                    }
                }
                catch (e_9_1) { e_9 = { error: e_9_1 }; }
                finally {
                    try {
                        if (_m && !_m.done && (_e = _l.return)) _e.call(_l);
                    }
                    finally { if (e_9) throw e_9.error; }
                }
                if (choices.length > 0) {
                    choiceGroups.push(new OrderItemChoiceGroup({
                        id: uuid.v4(),
                        name: 'Suppléments',
                        choices: choices
                    }));
                }
            }
            if (((_b = item.ingredientsToRemove) === null || _b === void 0 ? void 0 : _b.length) > 0) {
                var choices = [];
                try {
                    for (var _o = __values(Object.values(item.ingredientsToRemove)), _p = _o.next(); !_p.done; _p = _o.next()) {
                        var i = _p.value;
                        choices.push(new OrderItemChoice({
                            id: uuid.v4(),
                            name: i.name,
                            price: i.price,
                            quantity: 1,
                            total: i.price
                        }));
                    }
                }
                catch (e_10_1) { e_10 = { error: e_10_1 }; }
                finally {
                    try {
                        if (_p && !_p.done && (_f = _o.return)) _f.call(_o);
                    }
                    finally { if (e_10) throw e_10.error; }
                }
                if (choices.length > 0) {
                    choiceGroups.push(new OrderItemChoiceGroup({
                        id: uuid.v4(),
                        name: 'Retirer',
                        choices: choices
                    }));
                }
            }
            return new OrderItem({
                id: uuid.v4(),
                type: type,
                name: item.base.product.name,
                category: item.base.category.name,
                originCategory: new Category({
                    id: item.base.category.id,
                    name: item.base.category.name,
                    tags: item.base.category.tags,
                    productionPriority: item.base.category.productionPriority
                }),
                product: item.base.product.name,
                originProduct: new Product({
                    id: item.base.product.id,
                    name: item.base.product.name,
                    productionPriority: item.base.product.productionPriority,
                    tags: item.base.product.tags
                }),
                quantity: item.base.quantity,
                price: item.base.product.price,
                vat: Math.round(item.vat()),
                vatRate: {
                    id: item.base.product.vatRate.id,
                    name: item.base.product.vatRate.name,
                    rate: item.base.product.vatRate.rate
                },
                choiceGroups: choiceGroups
            });
        };
        ShoppingCartService.prototype.isEnabled = function (c) {
            var _this = this;
            return c.stocks.find(function (s) { return s.isEnabled && s.restaurant.id === _this.restaurantService.selectedRestaurant.value.id; }) !== undefined;
        };
        ShoppingCartService.prototype.enabledChoices = function (choices) {
            var _this = this;
            return choices.filter(function (c) { return _this.isEnabled(c); });
        };
        ShoppingCartService.prototype.availableChoices = function (cg) {
            var e_11, _c;
            var choices = [];
            try {
                for (var _d = __values(cg.choices), _e = _d.next(); !_e.done; _e = _d.next()) {
                    var c = _e.value;
                    if (this.hasStocks(c) && this.isEnabled(c)) {
                        choices.push(c);
                    }
                }
            }
            catch (e_11_1) { e_11 = { error: e_11_1 }; }
            finally {
                try {
                    if (_e && !_e.done && (_c = _d.return)) _c.call(_d);
                }
                finally { if (e_11) throw e_11.error; }
            }
            return choices;
        };
        ShoppingCartService.prototype.hasStocks = function (c) {
            var _this = this;
            if (c.stocks.length === 0) {
                return false;
            }
            return c.stocks.findIndex(function (s) { return s.hasStock && s.restaurant.id === _this.restaurantService.selectedRestaurant.value.id; }) !== -1;
        };
        ShoppingCartService.prototype.createShoppingCartItem = function (product, category, quantity) {
            var e_12, _c;
            if (quantity === void 0) { quantity = 1; }
            var choiceGroups = {};
            try {
                for (var _d = __values(product.choiceGroups), _e = _d.next(); !_e.done; _e = _d.next()) {
                    var cg = _e.value;
                    /*
                    let choices = [];
                    if (cg.required) {
                        const availableChoices = this.availableChoices(cg);
                        if (availableChoices?.length > 0) {
                            let defaultChoice = availableChoices.find(c => c.isDefault);
                            if (!defaultChoice) {
                                defaultChoice = availableChoices[0];
                            }
                            choices = [{ choice: defaultChoice, quantity: cg.minChoices > 0 ? cg.minChoices : 1 }];
                        }
                    }
                    */
                    choiceGroups[cg.id] = { base: cg, choices: [] };
                }
            }
            catch (e_12_1) { e_12 = { error: e_12_1 }; }
            finally {
                try {
                    if (_e && !_e.done && (_c = _d.return)) _c.call(_d);
                }
                finally { if (e_12) throw e_12.error; }
            }
            return new ShoppingCartItem({
                base: {
                    product: product,
                    category: category,
                    quantity: quantity
                },
                choiceGroups: choiceGroups,
                ingredientsToRemove: [],
                ingredientsToAdd: []
            });
        };
        return ShoppingCartService;
    }());
    ShoppingCartService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function ShoppingCartService_Factory() { return new ShoppingCartService(i0__namespace.ɵɵinject(ApiService), i0__namespace.ɵɵinject(RestaurantService)); }, token: ShoppingCartService, providedIn: "root" });
    ShoppingCartService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    ShoppingCartService.ctorParameters = function () { return [
        { type: ApiService },
        { type: RestaurantService }
    ]; };

    var UserService = /** @class */ (function () {
        function UserService(apiService) {
            this.apiService = apiService;
            UserService.loadUser();
        }
        UserService.loadUser = function () {
            var user = localStorage.getItem('rm_user');
            var token = localStorage.getItem('rm_jwt_token');
            if (token && user) {
                ApiService.user = new User(JSON.parse(user));
                ApiService.token = token;
                ApiService.logged = true;
            }
            var client = localStorage.getItem('rm_client');
            if (client) {
                LibConfiguration.setClient(client);
            }
            UserService.userLogged.next(user !== null || false);
        };
        UserService.saveUser = function (user) {
            ApiService.user = user;
            localStorage.setItem('rm_user', JSON.stringify(user));
        };
        UserService.saveToken = function (token) {
            ApiService.logged = true;
            ApiService.token = token.token;
            localStorage.setItem('rm_jwt_token', token.token);
            if (token.hasOwnProperty('client') && token.client) {
                LibConfiguration.setClient(token.client);
                localStorage.setItem('rm_client', token.client);
            }
        };
        UserService.prototype.update = function (user) {
            return this.apiService
                .put('/users/' + user.id, user, true)
                .pipe(operators.map(function (u) {
                UserService.saveUser(u);
                return new User(u);
            }));
        };
        UserService.prototype.assignCompany = function (companyCode) {
            return this.apiService.post('/companies/assign', { code: companyCode }, true).pipe(operators.map(function (user) {
                return new User(user);
            }));
        };
        UserService.prototype.unlinkCompany = function () {
            return this.apiService.post('/companies/unlink', {}, true).pipe(operators.map(function (user) {
                return new User(user);
            }));
        };
        UserService.prototype.adminLogin = function (email, password, deviceId) {
            if (deviceId === void 0) { deviceId = null; }
            return this.apiService
                .post('/api/login', { email: email, password: password, deviceId: deviceId }, false, false)
                .pipe(operators.map(function (token) {
                UserService.saveToken(token);
                return token;
            }));
        };
        UserService.prototype.adminLoginAndMe = function (email, password, deviceId) {
            if (deviceId === void 0) { deviceId = null; }
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_a) {
                    return [2 /*return*/, new Promise(function (resolve, reject) {
                            _this.adminLogin(email, password, deviceId).subscribe(function (response) {
                                _this.me().subscribe(function (user) {
                                    resolve(user);
                                }, function (err) {
                                    reject(err);
                                });
                            }, function (err) {
                                reject(err);
                            });
                        })];
                });
            });
        };
        UserService.prototype.loginAndMe = function (email, password) {
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_a) {
                    return [2 /*return*/, new Promise(function (resolve, reject) {
                            _this.login(email, password).subscribe(function (token) {
                                _this.me().subscribe(function (user) {
                                    resolve(user);
                                }, function (err) {
                                    reject(err);
                                });
                            }, function (err) {
                                reject(err);
                            });
                        })];
                });
            });
        };
        UserService.prototype.registerLoginAndMe = function (userRegister) {
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_a) {
                    return [2 /*return*/, new Promise(function (resolve, reject) {
                            _this.register(userRegister).subscribe(function (user) { return __awaiter(_this, void 0, void 0, function () {
                                return __generator(this, function (_a) {
                                    this.loginAndMe(userRegister.email, userRegister.plainPassword).then(function (loggedUser) {
                                        resolve(loggedUser);
                                    }, function (err) {
                                        reject(err);
                                    });
                                    return [2 /*return*/];
                                });
                            }); }, function (err) {
                                reject(err);
                            });
                        })];
                });
            });
        };
        UserService.prototype.logoutAndUnlinkUserLicence = function () {
            return __awaiter(this, void 0, void 0, function () {
                var _this = this;
                return __generator(this, function (_a) {
                    return [2 /*return*/, new Promise(function (resolve, reject) { return __awaiter(_this, void 0, void 0, function () {
                            var _this = this;
                            return __generator(this, function (_a) {
                                this.apiService.post('/api/unlink-user-license', {}, true, false).subscribe(function (result) {
                                    _this.logout();
                                    resolve(result);
                                }, function (err) {
                                    reject(err);
                                });
                                return [2 /*return*/];
                            });
                        }); })];
                });
            });
        };
        UserService.prototype.me = function () {
            return this.apiService.get('/me', true).pipe(operators.map(function (user) {
                UserService.saveUser(new User(user));
                UserService.userLogged.next(true);
                return new User(user);
            }));
        };
        UserService.prototype.login = function (email, password) {
            return this.apiService.post('/login', { email: email, password: password }).pipe(operators.map(function (token) {
                UserService.saveToken(token);
                return token;
            }));
        };
        UserService.prototype.register = function (userRegister) {
            return this.apiService.post('/register', userRegister).pipe(operators.map(function (user) {
                return new User(user);
            }));
        };
        UserService.prototype.isLogged = function () {
            return ApiService.logged && this.getUser() !== null;
        };
        UserService.prototype.isLoggedAsProUser = function () {
            return this.isLogged() && this.getUser() !== null && this.getUser().role === USER_ROLES.ROLE_PRO;
        };
        UserService.prototype.getUser = function () {
            return ApiService.user;
        };
        UserService.prototype.getUserById = function (id) {
            return this
                .apiService.get('/users/' + id, true)
                .pipe(operators.map(function (result) { return new User(result); }));
        };
        UserService.prototype.logout = function () {
            ApiService.logged = false;
            ApiService.user = null;
            ApiService.token = null;
            localStorage.removeItem('rm_user');
            localStorage.removeItem('rm_jwt_token');
            localStorage.removeItem('rm_client');
            UserService.userLogged.next(false);
        };
        return UserService;
    }());
    UserService.userLogged = new rxjs.BehaviorSubject(false);
    UserService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function UserService_Factory() { return new UserService(i0__namespace.ɵɵinject(ApiService)); }, token: UserService, providedIn: "root" });
    UserService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    UserService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var AddressService = /** @class */ (function () {
        function AddressService(apiService) {
            this.apiService = apiService;
        }
        AddressService.prototype.update = function (address) {
            return this.apiService
                .put('/addresses/' + address.id, address, true)
                .pipe(operators.map(function (a) { return new Address(a); }));
        };
        AddressService.prototype.add = function (address) {
            return this.apiService
                .post('/addresses', address, true)
                .pipe(operators.map(function (a) { return new Address(a); }));
        };
        AddressService.prototype.remove = function (address) {
            return this.apiService.delete('/addresses/' + address.id, true);
        };
        AddressService.prototype.list = function () {
            return this.apiService
                .get('/addresses', true)
                .pipe(operators.map(function (addr) { return addr.map(function (a) { return new Address(a); }); }));
        };
        return AddressService;
    }());
    AddressService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function AddressService_Factory() { return new AddressService(i0__namespace.ɵɵinject(ApiService)); }, token: AddressService, providedIn: "root" });
    AddressService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    AddressService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var DeliverySlotService = /** @class */ (function () {
        function DeliverySlotService(apiService) {
            this.apiService = apiService;
        }
        DeliverySlotService.prototype.next = function (restaurant) {
            return this.apiService.get('/delivery/restaurant/' + restaurant.id + '/next').pipe(operators.map(function (nextSlots) {
                return new NextDeliverySlots(nextSlots);
            }));
        };
        DeliverySlotService.prototype.list = function (restaurant) {
            return this.apiService
                .get('/delivery/restaurant/' + restaurant.id)
                .pipe(operators.map(function (result) { return new DeliverySlots(result); }));
        };
        DeliverySlotService.prototype.listStatuses = function (restaurant) {
            return this.apiService
                .get('/delivery/restaurant/' + restaurant.id + '/statuses', true)
                .pipe(operators.map(function (result) { return new DeliverySlots(result); }));
        };
        DeliverySlotService.prototype.update = function (deliverySlotId, isOpen) {
            return this.apiService
                .put('/delivery/' + deliverySlotId, { isOpen: isOpen }, true);
        };
        return DeliverySlotService;
    }());
    DeliverySlotService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function DeliverySlotService_Factory() { return new DeliverySlotService(i0__namespace.ɵɵinject(ApiService)); }, token: DeliverySlotService, providedIn: "root" });
    DeliverySlotService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    DeliverySlotService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var OrderService = /** @class */ (function () {
        function OrderService(apiService) {
            this.apiService = apiService;
        }
        OrderService.prototype.place = function (order) {
            return this
                .apiService.post('/orders', order, true)
                .pipe(operators.map(function (result) {
                return new Order(result);
            }));
        };
        OrderService.prototype.assign = function (id) {
            return this.apiService
                .post('/orders/' + id + '/assign', {}, true)
                .pipe(operators.map(function (r) { return new Order(r); }));
        };
        OrderService.prototype.assigned = function () {
            return this.apiService
                .get('/orders/assigned', true)
                .pipe(operators.map(function (r) { return r.map(function (o) { return new Order(o); }); }));
        };
        OrderService.prototype.print = function (ids) {
            return this.apiService.post('/orders/print', { orders: ids }, true);
        };
        OrderService.prototype.changeOrderStatus = function (order, status) {
            return this
                .apiService
                .put('/orders/' + order.id + '/status', { status: status }, true)
                .pipe(operators.map(function (r) { return new Order(r); }));
        };
        OrderService.prototype.findCurrentByRestaurant = function (restaurant, deliverySlot) {
            if (deliverySlot === void 0) { deliverySlot = null; }
            return this
                .apiService
                .get('/orders/restaurant/' + restaurant.id + '/current?deliverySlot=' + deliverySlot, true)
                .pipe(operators.map(function (orders) { return orders.map(function (o) { return new Order(o); }); }));
        };
        OrderService.prototype.getOrderById = function (id) {
            return this
                .apiService.get('/orders/' + id, true)
                .pipe(operators.map(function (result) { return new Order(result); }));
        };
        OrderService.prototype.getOrderByRef = function (ref) {
            return this
                .apiService.get('/orders/ref/' + ref, true)
                .pipe(operators.map(function (result) { return new Order(result); }));
        };
        OrderService.prototype.getOrdersByIds = function (restaurantId, ids) {
            return this
                .apiService
                .get('/restaurants/' + restaurantId + '/orders?ids=' + ids.join(','), true)
                .pipe(operators.map(function (orders) { return orders.map(function (o) { return new Order(o); }); }));
        };
        OrderService.prototype.getOrdersByRestaurant = function (restaurantId, date, page, perPage, sessionDate) {
            if (perPage === void 0) { perPage = 100; }
            if (sessionDate === void 0) { sessionDate = null; }
            var route = '/restaurants/' + restaurantId + '/orders?date=' + date + '&page=' + page + '&perPage=' + perPage;
            if (sessionDate) {
                route += '&sessionDate=' + sessionDate;
            }
            return this
                .apiService
                .get(route, true)
                .pipe(operators.map(function (p) { return new PaginatedResult(p, Order); }));
        };
        OrderService.prototype.list = function () {
            return this
                .apiService.get('/orders', true)
                .pipe(operators.map(function (orders) { return orders.map(function (o) { return new Order(o); }); }));
        };
        OrderService.prototype.getNextSlotsOrders = function (restaurantId, statuses) {
            return this.apiService.get('/restaurants/' + restaurantId + '/next-slot/orders?statuses=' + statuses.join(','), true);
        };
        OrderService.prototype.getExportData = function (params) {
            return this.apiService.get('/exports/orders?params=' + btoa(JSON.stringify(params)), true);
        };
        return OrderService;
    }());
    OrderService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function OrderService_Factory() { return new OrderService(i0__namespace.ɵɵinject(ApiService)); }, token: OrderService, providedIn: "root" });
    OrderService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    OrderService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var TransactionService = /** @class */ (function () {
        function TransactionService(apiService) {
            this.apiService = apiService;
        }
        TransactionService.prototype.getTransactionById = function (id) {
            return this
                .apiService.get('/transactions/' + id, true)
                .pipe(operators.map(function (result) { return new Transaction(result); }));
        };
        TransactionService.prototype.getLatestTransactionByOrderId = function (id) {
            return this
                .apiService.get('/transactions/orders/' + id + '/latest', true)
                .pipe(operators.map(function (result) { return new Transaction(result); }));
        };
        TransactionService.prototype.markAsPaid = function (data) {
            return this.apiService.put('/transactions/pay', { ids: data }, true);
        };
        return TransactionService;
    }());
    TransactionService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function TransactionService_Factory() { return new TransactionService(i0__namespace.ɵɵinject(ApiService)); }, token: TransactionService, providedIn: "root" });
    TransactionService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    TransactionService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var PasswordService = /** @class */ (function () {
        function PasswordService(apiService) {
            this.apiService = apiService;
        }
        PasswordService.prototype.reset = function (email, method) {
            if (method === void 0) { method = 'link'; }
            return this.apiService.post('/password/reset', { email: email, method: method }, false);
        };
        PasswordService.prototype.resetByCode = function (code, password) {
            return this.apiService.put('/password/reset/by-code', { code: code, password: password }, false);
        };
        PasswordService.prototype.resetPut = function (id, password) {
            return this.apiService.put('/password/reset/' + id, { password: password }, false);
        };
        PasswordService.prototype.change = function (oldPassword, newPassword) {
            return this.apiService.put('/password/change', { oldPassword: oldPassword, newPassword: newPassword }, true);
        };
        return PasswordService;
    }());
    PasswordService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function PasswordService_Factory() { return new PasswordService(i0__namespace.ɵɵinject(ApiService)); }, token: PasswordService, providedIn: "root" });
    PasswordService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    PasswordService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var ContactService = /** @class */ (function () {
        function ContactService(apiService) {
            this.apiService = apiService;
        }
        ContactService.prototype.sendMessage = function (contact) {
            return this.apiService.post('/contact', contact);
        };
        return ContactService;
    }());
    ContactService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function ContactService_Factory() { return new ContactService(i0__namespace.ɵɵinject(ApiService)); }, token: ContactService, providedIn: "root" });
    ContactService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    ContactService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var StockService = /** @class */ (function () {
        function StockService(apiService) {
            this.apiService = apiService;
        }
        StockService.prototype.update = function (data) {
            return this.apiService.put('/stocks/batch-update', data, true);
        };
        return StockService;
    }());
    StockService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function StockService_Factory() { return new StockService(i0__namespace.ɵɵinject(ApiService)); }, token: StockService, providedIn: "root" });
    StockService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    StockService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var IngredientService = /** @class */ (function () {
        function IngredientService(apiService) {
            this.apiService = apiService;
        }
        IngredientService.prototype.list = function () {
            return this.apiService.get('/ingredients').pipe(operators.map(function (ingredients) {
                return ingredients.map(function (i) { return new ProductIngredient(i); });
            }));
        };
        return IngredientService;
    }());
    IngredientService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function IngredientService_Factory() { return new IngredientService(i0__namespace.ɵɵinject(ApiService)); }, token: IngredientService, providedIn: "root" });
    IngredientService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    IngredientService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var DeviceTokenService = /** @class */ (function () {
        function DeviceTokenService(apiService) {
            this.apiService = apiService;
        }
        DeviceTokenService.prototype.add = function (t, restaurantId) {
            return this.apiService.post('/device-tokens/restaurants/' + restaurantId, { token: t }, true);
        };
        DeviceTokenService.prototype.setDeviceToken = function (t) {
            return this.apiService.post('/device-tokens', { token: t }, true);
        };
        return DeviceTokenService;
    }());
    DeviceTokenService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function DeviceTokenService_Factory() { return new DeviceTokenService(i0__namespace.ɵɵinject(ApiService)); }, token: DeviceTokenService, providedIn: "root" });
    DeviceTokenService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    DeviceTokenService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var WidgetService = /** @class */ (function () {
        function WidgetService(apiService) {
            this.apiService = apiService;
        }
        WidgetService.prototype.getWidgetByRestaurant = function (restaurantId, widgetSlug) {
            return this.apiService.get('/restaurants/' + restaurantId + '/widgets/' + widgetSlug, false).pipe(operators.map(function (widget) {
                return widget ? new Widget(widget) : null;
            }));
        };
        return WidgetService;
    }());
    WidgetService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function WidgetService_Factory() { return new WidgetService(i0__namespace.ɵɵinject(ApiService)); }, token: WidgetService, providedIn: "root" });
    WidgetService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    WidgetService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var RestaurantManagerModule = /** @class */ (function () {
        function RestaurantManagerModule() {
        }
        return RestaurantManagerModule;
    }());
    RestaurantManagerModule.decorators = [
        { type: i0.NgModule, args: [{
                    imports: [
                        common.CommonModule,
                        i1.HttpClientModule
                    ]
                },] }
    ];

    var EntityService = /** @class */ (function () {
        function EntityService(apiService) {
            this.apiService = apiService;
        }
        EntityService.convertParams = function (params) {
            return btoa(JSON.stringify(params));
        };
        EntityService.prototype.list = function (entity, params, type) {
            return this
                .apiService
                .get('/entities/' + entity + '?params=' + EntityService.convertParams(params), true)
                .pipe(operators.map(function (p) { return new PaginatedResult(p, type); }));
        };
        EntityService.prototype.getAll = function (entity, params, type) {
            return this
                .apiService
                .get('/entities/' + entity + '?params=' + EntityService.convertParams(params), true)
                .pipe(operators.map(function (result) { return result.map(function (e) { return new type(e); }); }));
        };
        EntityService.prototype.getById = function (entity, id, type) {
            return this
                .apiService.get('/entities/' + entity + '/' + id, true)
                .pipe(operators.map(function (result) { return new type(result); }));
        };
        EntityService.prototype.update = function (entity, data, type) {
            var id = data.id;
            delete data.id;
            return this
                .apiService.put('/entities/' + entity + '/' + id, data, true)
                .pipe(operators.map(function (result) { return new type(result); }));
        };
        EntityService.prototype.add = function (entity, data, type) {
            return this
                .apiService.post('/entities/' + entity, data, true)
                .pipe(operators.map(function (result) { return new type(result); }));
        };
        EntityService.prototype.remove = function (entity, id) {
            return this.apiService.delete('/entities/' + entity + '/' + id, true);
        };
        EntityService.prototype.reorder = function (data) {
            return this
                .apiService.post('/sort-entities', data, true)
                .pipe(operators.map(function (result) { return result; }));
        };
        return EntityService;
    }());
    EntityService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function EntityService_Factory() { return new EntityService(i0__namespace.ɵɵinject(ApiService)); }, token: EntityService, providedIn: "root" });
    EntityService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    EntityService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var SyncService = /** @class */ (function () {
        function SyncService(apiService, http) {
            this.apiService = apiService;
            this.http = http;
        }
        SyncService.prototype.syncTags = function () {
            return this.apiService.get('/tags', true).pipe(operators.map(function (tags) {
                return tags.map(function (t) { return new Tag(t); });
            }));
        };
        SyncService.prototype.syncVats = function () {
            return this.apiService.get('/vats', true).pipe(operators.map(function (vats) {
                return vats.map(function (t) { return new VatRate(t); });
            }));
        };
        SyncService.prototype.syncCategories = function (restaurantId) {
            return this.apiService.get('/sync/restaurants/' + restaurantId + '/categories', true).pipe(operators.map(function (categories) {
                return categories.map(function (c) { return new Category(c); });
            }));
        };
        SyncService.prototype.syncMenu = function (restaurantId, filterBy) {
            if (filterBy === void 0) { filterBy = null; }
            return __awaiter(this, void 0, void 0, function () {
                var filter, _a, categories, menus, products, choices, stocks, _loop_1, products_1, products_1_1, p;
                var e_1, _b;
                return __generator(this, function (_c) {
                    switch (_c.label) {
                        case 0:
                            filter = filterBy ? '?filter=' + filterBy : '';
                            return [4 /*yield*/, Promise.all([
                                    this.apiService.get('/sync2/restaurants/' + restaurantId + '/categories' + filter, true).toPromise(),
                                    this.apiService.get('/sync2/restaurants/' + restaurantId + '/menus' + filter, true).toPromise(),
                                    this.apiService.get('/sync2/restaurants/' + restaurantId + '/products' + filter, true).toPromise(),
                                    this.apiService.get('/sync2/restaurants/' + restaurantId + '/choices', true).toPromise(),
                                    this.apiService.get('/sync2/restaurants/' + restaurantId + '/stocks', true).toPromise()
                                ])];
                        case 1:
                            _a = __read.apply(void 0, [_c.sent(), 5]), categories = _a[0], menus = _a[1], products = _a[2], choices = _a[3], stocks = _a[4];
                            // Map entities
                            categories = categories.map(function (c) { return new Category(c); });
                            menus = menus.map(function (m) { return new Menu(m); });
                            products = products.map(function (p) { return new Product(p); });
                            choices = choices.map(function (c) { return new ProductChoiceGroup(c); });
                            stocks = stocks.map(function (s) { return new Stock(s); });
                            _loop_1 = function (p) {
                                var c = categories.find(function (c) { return c.id === p.category; });
                                if (c) {
                                    p.originCategory = new Category({
                                        id: c.id,
                                        slug: c.slug,
                                        name: c.name,
                                        productionPriority: c.productionPriority
                                    });
                                }
                            };
                            try {
                                // Rebuild products with originCategory
                                for (products_1 = __values(products), products_1_1 = products_1.next(); !products_1_1.done; products_1_1 = products_1.next()) {
                                    p = products_1_1.value;
                                    _loop_1(p);
                                }
                            }
                            catch (e_1_1) { e_1 = { error: e_1_1 }; }
                            finally {
                                try {
                                    if (products_1_1 && !products_1_1.done && (_b = products_1.return)) _b.call(products_1);
                                }
                                finally { if (e_1) throw e_1.error; }
                            }
                            return [2 /*return*/, {
                                    categories: categories,
                                    menus: menus,
                                    products: products,
                                    choices: choices,
                                    stocks: stocks
                                }];
                    }
                });
            });
        };
        SyncService.prototype.syncOrders = function (orders, restaurantId) {
            return this.apiService.post('/sync/restaurants/' + restaurantId + '/orders', orders, true).pipe(operators.map(function (orders) {
                return orders.map(function (o) { return new Order(o); });
            }));
        };
        SyncService.prototype.getSessionUploadParameters = function (sessionId) {
            return this.apiService.get('/sync/sessions/' + sessionId + '/upload-url', true).pipe(operators.map(function (result) {
                return result;
            }));
        };
        SyncService.prototype.uploadSession = function (url, data) {
            var headers = new i1.HttpHeaders();
            headers = headers.append('Content-Type', 'multipart/form-data');
            return this.http.put(url, data, { headers: headers });
        };
        return SyncService;
    }());
    SyncService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function SyncService_Factory() { return new SyncService(i0__namespace.ɵɵinject(ApiService), i0__namespace.ɵɵinject(i1__namespace.HttpClient)); }, token: SyncService, providedIn: "root" });
    SyncService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    SyncService.ctorParameters = function () { return [
        { type: ApiService },
        { type: i1.HttpClient }
    ]; };

    var LicenseService = /** @class */ (function () {
        function LicenseService(apiService) {
            this.apiService = apiService;
        }
        LicenseService.prototype.get = function () {
            return this.apiService.get('/my-license', true).pipe(operators.map(function (result) { return (result === null || result === void 0 ? void 0 : result.id) ? new License(result) : null; }));
        };
        LicenseService.prototype.getById = function (id) {
            return this.apiService.get('/licenses/' + id, true).pipe(operators.map(function (result) { return (result === null || result === void 0 ? void 0 : result.id) ? new License(result) : null; }));
        };
        return LicenseService;
    }());
    LicenseService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function LicenseService_Factory() { return new LicenseService(i0__namespace.ɵɵinject(ApiService)); }, token: LicenseService, providedIn: "root" });
    LicenseService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    LicenseService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var InvoiceService = /** @class */ (function () {
        function InvoiceService(apiService) {
            this.apiService = apiService;
        }
        InvoiceService.prototype.generate = function (restaurantId, data) {
            return this.apiService.post('/restaurants/' + restaurantId + '/invoice', data, true).pipe(operators.map(function (result) {
                return result;
            }));
        };
        return InvoiceService;
    }());
    InvoiceService.ɵprov = i0__namespace.ɵɵdefineInjectable({ factory: function InvoiceService_Factory() { return new InvoiceService(i0__namespace.ɵɵinject(ApiService)); }, token: InvoiceService, providedIn: "root" });
    InvoiceService.decorators = [
        { type: i0.Injectable, args: [{
                    providedIn: 'root'
                },] }
    ];
    InvoiceService.ctorParameters = function () { return [
        { type: ApiService }
    ]; };

    var PRODUCT_DEFAULT_THUMB = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAdYAAAHWCAYAAADKGqhaAAAABHNCSVQICAgIfAhkiAAAHvZJREFUeF7t3TuvZkl1BuCDISDAvwiJCAkCAqQZW05IMLJDy//EcuaAcUAyFiAREIBESsyfISDAl33GfWZO93R3rW+vtWvX5WnpwGhm7dpVz1pfvfPNBb7x5BcBAgQIECBQJvCNspUsRIAAAQIECDwJVkNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM0CAAAECBAoFBGshpqUIECBAgIBgNQMECBAgQKBQQLAWYlqKAAECBAgIVjNAgAABAgQKBQRrIaalCBAgQICAYDUDBAgQIECgUECwFmJaigABAgQICFYzQIAAAQIECgUEayGmpQgQIECAgGA1AwQIECBAoFBAsBZiWooAAQIECAhWM/BRgf99evr0KPjk+PnJMSx/xUVgV4Hjs/Ct4+y/OH5+fXwWfrWrg3O3BQRr22jbiuMieQ7Uz4+f5wvl+SL5h2Ng/ntbEAffVuD4LHzzzWfh+U80n/8E80fHZ+H324I4+EcFBKsBea/AcZH84PgDv30Tqi81wtW8bCfwTqi+nP8vx2/8WLhuNw6hAwvWENNeRW9C9TfHqb/9npML173GYevTfiBUhevWU9E+vGBtG21VcVwk3z0O/IcPhKpvrltNw96HbYTq63D9/nGR/nFvLad/LSBYzcOXAm9C9XfH7/hOgMU31wCSkjkFgqH6crg/H7/xQ+E6Z6+v2LVgvUJ1wjUfDFXfXCfssS3HBB4M1dfh+r3jQv1T7C2qVhYQrCt394GzHZfJfxzl//TAI1+G6zFEf3fiOY8QGFLg+Cz88tjY8z/9++ivfzs+C//66EPq1xMQrOv19NSJTv5Zum+up7Q9NKJA8jPw2XGmnx0X6rGMX7sLCNbdJ+DV+ZMXi7/napamFUjOvlCdtvPXbFywXuM67arJC0a4Ttv5fTeenHmhuu/ofPDkgtVQfE0gedEIVzM1jUBy1oXqNJ3uu1HB2td7mrclLxzhOk2n991ocsaF6r6j0zy5YG0S7VuQvHiE676jM/zJk7MtVIfv8L0bFKz3+g//9uQFJFyH7/B+G0zOtFDdb2QePrFgfZhsvweSF5Fw3W9khj1xcpaF6rCdHWtjgnWsfgy7m+SFJFyH7ew+G0vOsFDdZ1TSJxWsacJ9FkheTMJ1n1EZ7qTJ2RWqw3V07A0J1rH7M9zukheUcB2uo+tvKDmzQnX9ESk/oWAtJ11/weRFJVzXH5FhTpicVaE6TCfn2ohgnatfw+w2eWEJ12E6ue5GkjMqVNcdjctPJlgvJ173BcmLS7iuOxq3nyw5m0L19g7OvQHBOnf/bt998gITrrd3cL0NJGdSqK43Et1PJFi7k6/3wuRFJlzXG4nbTpScRaF6W+fWerFgXauft50meaEJ19s6t86LkzMoVNcZhdtPIlhvb8E6G0hebMJ1nVHofpLk7AnV7h1b+4WCde3+dj9d8oITrt07Nv8LkzMnVOcfgeFOIFiHa8n8G0pedMJ1/hHodoLkrAnVbp3a60WCda9+dztt8sITrt06Ne+LkjMmVOdt/fA7F6zDt2jeDSYvPuE6b+sv33lytoTq5R3a+wWCde/+X3765AUoXC/v0HwvSM6UUJ2v5dPtWLBO17L5Npy8CIXrfC2/bMfJWRKql3XGwq8FBKt56CKQvBCFa5cujf2S5AwJ1bHbu9TuBOtS7Rz7MMmLUbiO3d5Ld5ecHaF6aXcs/q6AYDUTXQWSF6Rw7dqtMV6WnBmhOkYbt9qFYN2q3WMcNnlRCtcx2thlF8lZEapduuQlvrGagSEEkhemcB2ii9duIjkjQvXa9lj9IwK+sRqP2wSSF6dwva1z1784ORtC9foWeYNgNQOjCiQvUOE6amMT+0rOhFBN2Hu0RsA31hpHqyQEkhepcE3Yj/ZochaE6mgN3XQ/gnXTxo927OSFKlxHa+iJ/SRnQKieMPfINQKC9RpXq54QSF6swvWE+SiPJHsvVEdppH18ISBYDcJQAskLVrgO1c3YZpI9F6oxZlUdBQRrR2yvigkkL1rhGmMeoirZa6E6RBdt4l0BwWomhhRIXrjCdciuvr2pZI+F6gQ93nWLgnXXzk9w7uTFK1wH7nGyt0J14N7amr/HagYGF0hewMJ1wP4meypUB+ypLb0t4BuriRheIHkRC9eBOpzspVAdqJe28mEBwWo6phBIXsjCdYAuJ3soVAfooS3EBARrzEnVAALJi1m43tjDZO+E6o298+rHBQTr42aeuFEgeUEL1xt6l+yZUL2hZ16ZExCsOT9P3yCQvKiFa8eeJXslVDv2yqvqBARrnaWVOgokL2zh2qFXyR4J1Q498oprBATrNa5W7SCQvLiF64U9SvZGqF7YG0tfLyBYrzf2hgsFkhe4cL2gN8meCNULemLJvgKCta+3t10gkLzIhWthT5K9EKqFvbDUfQKC9T57by4USF7owrWgF8keCNWCHlhiDAHBOkYf7KJAIHmxC9dED5L2QjVh79HxBATreD2xo4RA8oIXrifsk+ZC9YS5R8YWEKxj98fuTggkL3rh+oB50lqoPmCtdB4BwTpPr+z0AYHkhS9cA9ZJY6EaMFYyp4BgnbNvdh0QSF78wvUjxklboRqYXyXzCgjWeXtn5wGBZAAI1/cYJ02FamBulcwtIFjn7p/dBwSSQSBcXxknLYVqYF6VzC8gWOfvoRMEBJKBIFwP46ShUA3MqZI1BATrGn10ioBAMhi2DteknVANzKeSdQQE6zq9dJKAQDIgtgzXpJlQDcylkrUEBOta/XSagEAyKLYK16SVUA3Mo5L1BATrej11ooBAMjC2CNekkVANzKGSNQUE65p9daqAQDI4lg7XpI1QDcyfknUFBOu6vXWygEAyQJYM16SJUA3MnZK1BQTr2v11uoBAMkiWCtekhVANzJuS9QUE6/o9dsKAQDJQlgjXpIFQDcyZkj0EBOsefXbKgEAyWKYO1+TZhWpgvpTsIyBY9+m1kwYEkgEzZbgmzyxUA3OlZC8BwbpXv502IJAMmqnCNXlWoRqYJyX7CQjW/XruxAGBZOBMEa7JMwrVwBwp2VNAsO7Zd6cOCCSDZ+hwTZ5NqAbmR8m+AoJ13947eUAgGUBDhmvyTEI1MDdK9hYQrHv33+kDAskgGipck2cRqoF5UUJAsJoBAgGBZCANEa7JMwjVwJwoIfAsIFjNAYGgQDKYbg3X5N6FanBGlBEQrGaAwIMCyYC6JVyTexaqD86IcgK+sZoBAg8KJIOqa7gm9ypUH5wN5QR8YzUDBE4KJAOrS7gm9yhUT86Gxwj4xmoGCJwUSAbXc7j+/fEBPJap/5Xcm1Ctb4kVNxIQrBs121HrBUYMsBH3VC9vRQLjCgjWcXtjZ5MIjBRkI+1lkvbZJoFyAcFaTmrBHQVGCLQR9rBj752ZwLsCgtVMECgSuDPY7nx3EZ9lCCwjIFiXaaWDjCBwR8Dd8c4RrO2BwKgCgnXUztjXtAI9g67nu6ZtiI0T6CwgWDuDe90eAj0Cr8c79uiWUxKoFRCstZ5WI/ClwJXBd+XaWkiAQE5AsOb8PE3gowJXBOAVa2ojAQJ1AoK1ztJKBN4rUBmElWtpFwEC1wgI1mtcrUrgLYGKQDwW/Jvj5/Pj59MTvP5nCk+geYTAGQHBekbNMwROCCTD9T+PV/6tUD0B7xECnQUEa2dwr9tbIBmuZ/B8Uz2j5hkCCQHBmsDzKIEzAh3DVaieaZBnCCQFBGsS0OMEzgh0CFeheqYxniFQICBYCxAtQeCMwIXhKlTPNMQzBIoEBGsRpGUInBG4IFyF6plGeIZAoYBgLcS0FIEzAoXhKlTPNMAzBIoFBGsxqOUInBF4E67/dTz7yZnnj2eE6kk4jxGoFhCs1aLWI3BCQLCeQPMIgUEFBOugjbGtfQT8peB9eu2kewgI1j367JSDChSG6ssJ/SXhQXttW/sICNZ9eu2kgwlcEKrCdbAe286eAoJ1z7479c0CF4aqcL25t15PQLCaAQKdBTqEqnDt3FOvI/BaQLCaBwIdBTqGqnDt2FevIiBYzQCBGwSSoer/Nu6GnnklgTMCvrGeUfMMgQcFkqH6xT/pe/z4Pzp/0F05gTsEBOsd6t65lUBFqB4f1GOZL/7jm8d/fX78fHoC0b+KcwLNIwQeFRCsj4qpJ/CAwBVBeMWaDxxJKQECDQHBakQIXCRwZQBeufZFHJYlsI2AYN2m1Q7aU6BH8PV4R08z7yKwioBgXaWTzjGMQM/A6/muYYBthMDgAoJ18AbZ3lwCdwTdHe+cqyt2S6CvgGDt6+1tCwvcGXB3vnvhljoagVMCgvUUm4cIvC0wQrCNsAdzQYDA05NgNQUEkgIjBdpIe0myepzAtAKCddrW2fgIAiMG2Yh7GqFX9kCgl4Bg7SXtPcsJjBxgI+9tuUFwIALvCAhWI0HghMAMwTXDHk/Qe4TA8AKCdfgW2eBoAjMF1kx7Ha3P9kPgrIBgPSvnuS0FZgyqGfe85XA59DICgnWZVjrI1QIzB9TMe7+6r9YnUC0gWKtFrbekwArBtMIZlhwuh1pOQLAu11IHqhZYKZBWOkt1n61HoEpAsFZJWmdJgRWDaMUzLTl8DjWtgGCdtnU2frXAygG08tmungvrE2gJCNaWkD++pcAOwbPDGbccXoe+XUCw3t4CGxhNYKfA2emso82Z/awrIFjX7a2TnRDYMWh2PPOJ0fAIgbCAYA1TKVxdYOeA2fnsq8+18/UXEKz9zb1xQAHB8vTEYMDBtKUpBQTrlG2z6UoBgfKVJovKybLWrgKCddfOO/cXAoLk64PAxIeDQE5AsOb8PD2xgAD5cPPYTDzYtn67gGC9vQU2cIeA4GirM2obqSDwPgHBai62ExAY8ZazilupJPAiIFjNwlYCguLxdjN73MwTewsI1r37v9XpBcT5drM7b+fJ/QQE63493/LEgiHfdoZ5QyvsISBY9+jz1qcUCHXtZ1lnaaV1BQTrur11skNAENSPAdN6UyuuJSBY1+qn07wSEADXjQPb62ytPL+AYJ2/h07wHgEX//Vjwfh6Y2+YU0Cwztk3u/6IgAu/33iw7mftTfMICNZ5emWnAQEXfQCpuIR5MajlphcQrNO30AFeBFzw980C+/vsvXk8AcE6Xk/s6ISAi/0EWvEjelAMarlpBQTrtK2zcd9Ux5sB4TpeT+yov4Bg7W/ujYUCLvJCzKKl9KQI0jLTCgjWaVtn4y7wcWdAb8btjZ1dLyBYrzf2hgsEXNwXoBYvqUfFoJabRkCwTtMqG/X3VOebAeE6X8/sOC8gWPOGVugo4KLuiF30Kj0rgrTMNAKCdZpW2agLet4Z0Lt5e2fnjwsI1sfNPHGDgIv5BvTiV+phMajlhhUQrMO2xsb8PdX1ZkC4rtdTJ/q6gGA1FUMLuIiHbs+pzenpKTYPTSQgWCdq1m5bdQGv23G9Xbe3Tvb0JFhNwZACLt4h21K6KT0u5bTYQAKCdaBm2Mr/C7hw95kEvd6n1zudVLDu1O0JzuqinaBJxVvU82JQy90uIFhvb4ENvAi4YPedBb3ft/crnlywrtjVCc/kYp2wacVbNgPFoJa7TUCw3kbvxb6pmoF3BYSrmVhBQLCu0MWJz+Ainbh5F23dTFwEa9luAoK1G7UX+XZiBqICwjUqpW5EAcE6Ylc22JOLc4MmJ49oRpKAHr9NQLDeRr/vi12Y+/b+0ZOblUfF1I8gIFhH6MJGe3BRbtTsoqOamSJIy3QTEKzdqL3IBWkGzgqYnbNynrtDQLDeob7hO12MGza9+MhmqBjUcpcJCNbLaC38IuBCNAtVAmapStI6VwoI1it1re1/UN8MlAsI13JSCxYLCNZiUMt9JeACNA1XCZitq2StWyEgWCsUrfE1ARefobhawIxdLWz9swKC9ayc5z4o4MIzHL0EzFovae95RECwPqKltingomsSKSgWMHPFoJZLCwjWNKEFXgRccGbhLgGzd5e8975PQLCaixIBF1sJo0USAmYwgefRUgHBWsq552IutD37PuKpzeKIXdlvT4J1v56XnthFVsppsQIBM1mAaImUgGBN8e39sAts7/6PfHqzOXJ31t+bYF2/x5ec0MV1CatFCwXMaCGmpR4SEKwPcSl+FnBhmYNZBMzqLJ1aa5+Cda1+Xn4aF9XlxF5QLGBmi0Et1xQQrE0iBS8CLiizMKuA2Z21c3PuW7DO2bfuu3YxdSf3wmIBM1wMarkPCghWw9EUcCE1iRRMImCWJ2nU5NsUrJM38Ortu4iuFrZ+bwEz3Vt8v/cJ1v16Hj6xCyhMpXAyAbM9WcMm265gnaxhvbbr4ukl7T13CZjxu+TXf69gXb/HD5/QhfMwmQcmFTDrkzZu8G0L1sEb1Ht7Lpre4t53t4CZv7sD671fsK7X09MncsGcpvPg5AJmf/IGDrZ9wTpYQ+7ajovlLnnvHUXAZ2CUTsy/D8E6fw9LTnBcKj8/FvrpicU+O4boH0885xECQwocn4VfHhv79MTm/v34LPzLiec8spiAYF2soWePc1wm3z2e/d3x850H1vjsqP3ZMUTH434RWEPg5DfXPx+n/+HxWfjjGgpOkREQrBm9xZ59MFyF6mL9d5yvBB4MV6FqeN4SEKwG4i2BN+H6h+N3fvsjNELV3CwvEAzXvxwQ3/dNdflxeOiAgvUhrj2KjwvlB8dJf/OBcBWqe4yBUx4CjXB9DtUfH5fo72EReC0gWM3DewXehOtvjz/4rVcFQtW8bCfwgXAVqttNQvzAgjVutV3lcaF8chz68zfhKlS3mwAHfhF4J1z/evz+H/mmaj4+JCBYzcZHBY4L5flfO3j+S8P/fAzL/+AisKvA8Vl4/qs3vzh+fn18Fn61q4NztwUEa9tIBQECBAgQCAsI1jCVQgIECBAg0BYQrG0jFQQIECBAICwgWMNUCgkQIECAQFtAsLaNVBAgQIAAgbCAYA1TKSRAgAABAm0Bwdo2UkGAAAECBMICgjVMpZAAAQIECLQFBGvbSAUBAgQIEAgLCNYwlUICBAgQINAWEKxtIxUECBAgQCAsIFjDVAoJECBAgEBbQLC2jVQQIECAAIGwgGANUykkQIAAAQJtAcHaNlJBgAABAgTCAoI1TKWQAAECBAi0BQRr20gFAQIECBAICwjWMJVCAgQIECDQFhCsbSMVBAgQIEAgLCBYw1QKCRAgQIBAW0Cwto1UECBAgACBsIBgDVMpJECAAAECbQHB2jZSQYAAAQIEwgKCNUylkAABAgQItAUEa9tIBQECBAgQCAsI1jCVQgIECBAg0BYQrG0jFQQIECBAICwgWMNUCgkQIECAQFtAsLaNVBAgQIAAgbCAYA1TKSRAgAABAm0Bwdo2UkGAAAECBMICgjVMpZAAAQIECLQFBGvbSAUBAgQIEAgLCNYwlUICBAgQINAWEKxtIxUECBAgQCAsIFjDVAoJECBAgEBbQLC2jVQQIECAAIGwgGANUykkQIAAAQJtAcHaNlJBgAABAgTCAoI1TKWQAAECBAi0BQRr20gFAQIECBAICwjWMJVCAgQIECDQFhCsbSMVBAgQIEAgLCBYw1QKCRAgQIBAW0Cwto1UECBAgACBsIBgDVMpJECAAAECbQHB2jZSQYAAAQIEwgKCNUylkAABAgQItAUEa9tIBQECBAgQCAsI1jCVQgIECBAg0BYQrG0jFQQIECBAICwgWMNUCgkQIECAQFtAsLaNVBAgQIAAgbCAYA1TKSRAgAABAm0Bwdo2UkGAAAECBMICgjVMpZAAAQIECLQFBGvbSAUBAgQIEAgLCNYwlUICBAgQINAWEKxtIxUECBAgQCAsIFjDVAoJECBAgEBbQLC2jVQQIECAAIGwgGANUykkQIAAAQJtAcHaNlJBgAABAgTCAoI1TKWQAAECBAi0BQRr20gFAQIECBAICwjWMJVCAgQIECDQFhCsbSMVBAgQIEAgLCBYw1QKCRAgQIBAW0Cwto1UECBAgACBsIBgDVMpJECAAAECbQHB2jZSQYAAAQIEwgKCNUylkAABAgQItAUEa9tIBQECBAgQCAsI1jCVQgIECBAg0BYQrG0jFQQIECBAICwgWMNUCgkQIECAQFtAsLaNVBAgQIAAgbCAYA1TKSRAgAABAm0Bwdo2UkGAAAECBMICgjVMpZAAAQIECLQFBGvbSAUBAgQIEAgLCNYwlUICBAgQINAWEKxtIxUECBAgQCAsIFjDVAoJECBAgEBbQLC2jVQQIECAAIGwgGANUykkQIAAAQJtAcHaNlJBgAABAgTCAoI1TKWQAAECBAi0BQRr20gFAQIECBAICwjWMJVCAgQIECDQFhCsbSMVBAgQIEAgLCBYw1QKCRAgQIBAW0Cwto1UECBAgACBsIBgDVMpJECAAAECbQHB2jZSQYAAAQIEwgKCNUylkAABAgQItAUEa9tIBQECBAgQCAsI1jCVQgIECBAg0BYQrG0jFQQIECBAICwgWMNUCgkQIECAQFtAsLaNVBAgQIAAgbCAYA1TKSRAgAABAm0Bwdo2UkGAAAECBMICgjVMpZAAAQIECLQFBGvbSAUBAgQIEAgLCNYwlUICBAgQINAWEKxtIxUECBAgQCAsIFjDVAoJECBAgEBbQLC2jVQQIECAAIGwgGANUykkQIAAAQJtAcHaNlJBgAABAgTCAoI1TKWQAAECBAi0BQRr20gFAQIECBAICwjWMJVCAgQIECDQFhCsbSMVBAgQIEAgLCBYw1QKCRAgQIBAW0Cwto1UECBAgACBsIBgDVMpJECAAAECbQHB2jZSQYAAAQIEwgKCNUylkAABAgQItAUEa9tIBQECBAgQCAsI1jCVQgIECBAg0BYQrG0jFQQIECBAICwgWMNUCgkQIECAQFtAsLaNVBAgQIAAgbCAYA1TKSRAgAABAm0Bwdo2UkGAAAECBMICgjVMpZAAAQIECLQFBGvbSAUBAgQIEAgLCNYwlUICBAgQINAW+D+Nukgxp8OHrwAAAABJRU5ErkJggg==';

    /*
     * Public API Surface of restaurant-manager
     */

    /**
     * Generated bundle index. Do not edit.
     */

    exports.Address = Address;
    exports.AddressService = AddressService;
    exports.ApiService = ApiService;
    exports.AppConfiguration = AppConfiguration;
    exports.AppVersion = AppVersion;
    exports.Category = Category;
    exports.CategoryService = CategoryService;
    exports.Client = Client;
    exports.ClientBilling = ClientBilling;
    exports.ClientConfig = ClientConfig;
    exports.ClientService = ClientService;
    exports.Collection = Collection;
    exports.CollectionItem = CollectionItem;
    exports.CollectionOperation = CollectionOperation;
    exports.CollectionTransaction = CollectionTransaction;
    exports.Company = Company;
    exports.CompanyService = CompanyService;
    exports.Configuration = Configuration;
    exports.ContactModel = ContactModel;
    exports.ContactService = ContactService;
    exports.DeliverySlot = DeliverySlot;
    exports.DeliverySlotService = DeliverySlotService;
    exports.DeliverySlots = DeliverySlots;
    exports.DeviceTokenService = DeviceTokenService;
    exports.Employee = Employee;
    exports.EntityService = EntityService;
    exports.Event = Event;
    exports.EventCompany = EventCompany;
    exports.EventHall = EventHall;
    exports.EventLocation = EventLocation;
    exports.EventRestaurant = EventRestaurant;
    exports.EventService = EventService;
    exports.EventStall = EventStall;
    exports.Extension = Extension;
    exports.FormHelper = FormHelper;
    exports.Hash = Hash;
    exports.Hashes = Hashes;
    exports.Hour = Hour;
    exports.HourGroup = HourGroup;
    exports.IngredientService = IngredientService;
    exports.InvoiceData = InvoiceData;
    exports.InvoiceService = InvoiceService;
    exports.LibConfiguration = LibConfiguration;
    exports.License = License;
    exports.LicenseService = LicenseService;
    exports.ManagerVersion = ManagerVersion;
    exports.Menu = Menu;
    exports.MenuGroup = MenuGroup;
    exports.MenuGroupItem = MenuGroupItem;
    exports.NextDeliverySlots = NextDeliverySlots;
    exports.ORDER_CANCELLATION_REASONS = ORDER_CANCELLATION_REASONS;
    exports.ORDER_STATUS = ORDER_STATUS;
    exports.ORDER_STATUS_INFORMATIONS = ORDER_STATUS_INFORMATIONS;
    exports.Order = Order;
    exports.OrderDiscount = OrderDiscount;
    exports.OrderError = OrderError;
    exports.OrderHelper = OrderHelper;
    exports.OrderItem = OrderItem;
    exports.OrderItemChoice = OrderItemChoice;
    exports.OrderItemChoiceGroup = OrderItemChoiceGroup;
    exports.OrderOption = OrderOption;
    exports.OrderService = OrderService;
    exports.OrderVat = OrderVat;
    exports.PAYMENT_METHODS = PAYMENT_METHODS;
    exports.PERMISSIONS = PERMISSIONS;
    exports.POS_REPORT_ACTIONS = POS_REPORT_ACTIONS;
    exports.PRODUCT_DEFAULT_THUMB = PRODUCT_DEFAULT_THUMB;
    exports.PRODUCT_DIMENSION_TYPES = PRODUCT_DIMENSION_TYPES;
    exports.PaginatedResult = PaginatedResult;
    exports.PasswordService = PasswordService;
    exports.PlaceOrder = PlaceOrder;
    exports.PlaceOrderClient = PlaceOrderClient;
    exports.PlaceOrderOption = PlaceOrderOption;
    exports.PosReport = PosReport;
    exports.PosReportItem = PosReportItem;
    exports.Product = Product;
    exports.ProductAllergen = ProductAllergen;
    exports.ProductChoice = ProductChoice;
    exports.ProductChoiceGroup = ProductChoiceGroup;
    exports.ProductIngredient = ProductIngredient;
    exports.ProductService = ProductService;
    exports.Production = Production;
    exports.ProductionItem = ProductionItem;
    exports.ProductionTicket = ProductionTicket;
    exports.Restaurant = Restaurant;
    exports.RestaurantClosure = RestaurantClosure;
    exports.RestaurantManagerModule = RestaurantManagerModule;
    exports.RestaurantService = RestaurantService;
    exports.RestaurantStats = RestaurantStats;
    exports.Session = Session;
    exports.SessionService = SessionService;
    exports.ShoppingCart = ShoppingCart;
    exports.ShoppingCartItem = ShoppingCartItem;
    exports.ShoppingCartItemProductChoices = ShoppingCartItemProductChoices;
    exports.ShoppingCartOption = ShoppingCartOption;
    exports.ShoppingCartService = ShoppingCartService;
    exports.Sortable = Sortable;
    exports.Stock = Stock;
    exports.StockService = StockService;
    exports.SyncService = SyncService;
    exports.TRANSACTION_STATUS = TRANSACTION_STATUS;
    exports.TRANSACTION_STATUS_INFORMATIONS = TRANSACTION_STATUS_INFORMATIONS;
    exports.Table = Table;
    exports.TableManagement = TableManagement;
    exports.Tag = Tag;
    exports.Team = Team;
    exports.Transaction = Transaction;
    exports.TransactionItem = TransactionItem;
    exports.TransactionPart = TransactionPart;
    exports.TransactionPayment = TransactionPayment;
    exports.TransactionService = TransactionService;
    exports.TransactionVat = TransactionVat;
    exports.USER_ROLES = USER_ROLES;
    exports.User = User;
    exports.UserRegister = UserRegister;
    exports.UserService = UserService;
    exports.Utils = Utils;
    exports.VatRate = VatRate;
    exports.VersionService = VersionService;
    exports.WebsiteConfiguration = WebsiteConfiguration;
    exports.Widget = Widget;
    exports.WidgetCustomCategoryItem = WidgetCustomCategoryItem;
    exports.WidgetCustomCustomItem = WidgetCustomCustomItem;
    exports.WidgetCustomItem = WidgetCustomItem;
    exports.WidgetCustomProductItem = WidgetCustomProductItem;
    exports.WidgetGalleryImageItem = WidgetGalleryImageItem;
    exports.WidgetGalleryItem = WidgetGalleryItem;
    exports.WidgetGalleryTextItem = WidgetGalleryTextItem;
    exports.WidgetItem = WidgetItem;
    exports.WidgetService = WidgetService;
    exports.ZONE_OBJECT_TYPES = ZONE_OBJECT_TYPES;
    exports.Zone = Zone;
    exports.ZoneObject = ZoneObject;

    Object.defineProperty(exports, '__esModule', { value: true });

}));
//# sourceMappingURL=lonestudio-restaurant-manager.umd.js.map
