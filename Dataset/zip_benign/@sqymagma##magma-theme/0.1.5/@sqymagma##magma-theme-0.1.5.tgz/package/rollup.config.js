import babel from "rollup-plugin-babel"
import commonjs from "rollup-plugin-commonjs"
import resolve from "rollup-plugin-node-resolve"
import replace from "rollup-plugin-replace"
import json from "rollup-plugin-json"

// const NODE_ENV = process.env.NODE_ENV || "development"
const NODE_ENV = "production"
const outputFile = NODE_ENV === "production" ? "./lib/prod.js" : "./lib/dev.js"

export default {
  input: "./src/index.js",
  output: {
    file: outputFile,
    format: "cjs"
  },
  plugins: [
    json({
      // All JSON files will be parsed by default,
      // but you can also specifically include/exclude files
      include: ["node_modules/**", "./src/**"],
      exclude: ["node_modules/foox/**", "node_modules/barx/**"],

      // for tree-shaking, properties will be declared as
      // variables, using either `var` or `const`
      preferConst: true, // Default: false

      // specify indentation for the generated default export —
      // defaults to '\t'
      indent: "  ",

      // ignores indent and generates the smallest code
      compact: true, // Default: false

      // generate a named export for every property of the JSON object
      namedExports: true // Default: true
    }),
    replace({
      "process.env.NODE_ENV": JSON.stringify(NODE_ENV)
    }),
    babel({
      exclude: "node_modules/**"
    }),
    resolve(),
    commonjs()
  ],
  external: ["styled-components", "react"]
}
