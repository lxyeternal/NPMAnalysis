const fs = require('fs');
const path = require('path');
const pkg = require('./package.json');
let today = new Date().toISOString();
today = today.substring(0, today.indexOf('T')).replace(/-/g,'.');

var greenbold = `\x1b[32m\x1b[1m`
var end = `\x1b[0m`

var prefix = ``
if (require('os').platform() == 'darwin') {
  prefix = `ℹ ｢ext｣:`
}
else {
  prefix = `i [ext]:`
}
var app =(`${greenbold}${prefix}${end} activate:`)
function boldRed(s) {
  var boldredcolor = `\x1b[31m\x1b[1m`
  var endmarker = `\x1b[0m`
  return (`${boldredcolor}${s}${endmarker}`)
}

console.log(`${app} ${pkg.name} v${pkg.sencha.version} installed`)

delete pkg.scripts.postinstall;  //does anyone have this?
fs.writeFileSync('./package.json', JSON.stringify(pkg, null, 2));
fs.unlinkSync('./activate.js');

console.log("package tier: " + pkg.sencha.extTier);

const activatorName = `@sencha/ext${(pkg.sencha.extTier === "pro" || pkg.sencha.extTier === "professional" || pkg.sencha.extTier === "standard") ? "" : "-enterprise"}-activator`;
var package = `${activatorName}@${pkg.version.replace(/-.+$/, '')}-${today}`
var command = `npm${/^win/.test(require('os').platform()) ? ".cmd" : ""}`

console.log("activator name: " + activatorName + " package: " + package);

var args = []
if (process.env.EXTGEN_VERBOSE == 'true') {
  args = ['install',package]
}
else {
  args = ['install','-s',package]
  // if (require('os').platform() == 'win32') {
  //   args = ['install','-s','>','NUL',package]
  // }
  // else {
  //   args = ['install','-s','>','/dev/null',package]
  // }
}
let options = {cwd: path.join(__dirname), stdio: 'inherit', encoding: 'utf-8'}
//  console.log(`${app} command: ${command}`)
if (process.env.EXTGEN_VERBOSE == 'true') {
  console.log(`${app} npm ${args.toString().replace(/,/g, " ")} started`)
}
let child = require('child_process').spawn(
  command, 
  args, 
  options
)
child.on('close', (code) => {
  if (code===0) {
    require(activatorName)(__dirname)
    if (process.env.EXTGEN_VERBOSE == 'true') {
      console.log(`${app} npm ${args.toString().replace(/,/g, " ")} completed`)
    }
  }
  else {
    if (process.env.EXTGEN_VERBOSE == 'true') {
      console.log(`${app} ${boldRed('[ERR]')} Closed with code ${code}`)
    }
    if (pkg.sencha.type === "framework") {
      console.log(`
Evaluation/Trial License
------------------------------------------------------------------------------------------
This version of Sencha Ext JS is licensed commercially for a limited period for evaluation
purposes only. Production use or use beyond the applicable evaluation period is prohibited
under this license.
See http://www.sencha.com/legal/sencha-sdk-software-license-agreement (Trial License)
for license terms.
------------------------------------------------------------------------------------------
`)
    }
  }
})
child.on('error', (error) => {
  var s = error.message ? error.message : error
  s = s.replace(/(\r\n\t|\n|\r\t)/gm,"");
  console.log(`${app} ${boldRed('[ERR]')} ${s}`)
})
child.on('data', (error) => {
  var s = error.message ? error.message : error
  s = s.replace(/(\r\n\t|\n|\r\t)/gm,"");
  console.log(`${app} ${boldRed('[DATA]')} ${s}`)
})

if (child.stdout) {
  child.stdout.on('data', (stdout) => {
    var s = stdout.toString()
    s = s.replace(/(\r\n\t|\n|\r\t)/gm,"");
    console.log(`${app} ${s}`)
  })
}
else {
//    var s = `no stdout`
//    console.log(`${app} ${boldRed("[ERR]")} ${s}`)
  }
if (child.stderr) {
  child.stderr.on('data', (stderr) => {
    var s = stderr.toString()
    s = s.replace(/(\r\n\t|\n|\r\t)/gm,"");
    console.log(`${app} ${boldRed('[ERR]')} ${s}`)
  })
}
else {
//  var s = `no stderr`
//  console.log(`${app} ${boldRed("[ERR]")} ${s}`)
}





      //console.log(`${app} current directory: ${__dirname}`)
//console.log(`${app} package.json: ${JSON.stringify(pkg, null, 2)}`)
//console.log(``)
//console.log(`${app} ${pkg.sencha.summary}`)
//console.log(`${app} Version: ${pkg.sencha.version}`)
//console.log(`${app} Summary: ${pkg.sencha.summary}`)
//console.log(`${app} Description: ${pkg.sencha.detailedDescription}`)
//console.log(`${app} React Tier: ${pkg.sencha.extTier}, activatorName: ${activatorName}`)
//console.log(`${app} activatorName: ${activatorName}`)





// require('child_process')
//     .exec([
//         `npm${/^win/.test(require('os').platform()) ? ".cmd" : ""}`,
//         'install',
//         `-s`,
//         `${activatorName}@${pkg.version.replace(/-.+$/, '')}-${today}`
//     ].join(' '), {
//         cwd: __dirname
//     }, (error, stdout, stderr) => {
//         try {
//             if (!error) {
//                 require(activatorName)(__dirname);
//             }
//             console.log(`stdout: ${stdout}`);
//             console.log(`stderr: ${stderr}`);
//         } catch (err) {
//             error = err;
//         } finally {
//             let loglevel = ["silent", "error", "warn", "http", "info", "verbose", "silly"].indexOf(process.env.npm_config_loglevel);
//             if (error) {
//               //  if (loglevel > 3) {
//                 var s = error.message ? error.message : error
//                 s = s.replace(/(\r\n\t|\n|\r\t)/gm,"");
//                 console.log(`${app} ${boldRed('[ERR]')} ${s}`)
//                 //console.log(`${app} [ERR] ${error.message ? error.message : error}`)
//                 //console.log(`> [activator][err]: ${error.message ? error.message : error}`);
//               //  }
//               //  if (loglevel > 4) {
//               //      console.log(`> [activation][err]: ${stderr}`);
//               //  }
//                 if (pkg.sencha.type === "framework") {
//                   console.log(`
// Evaluation/Trial License
// ------------------------------------------------------------------------------------------
// This version of Sencha Ext JS is licensed commercially for a limited period for evaluation
// purposes only. Production use or use beyond the applicable evaluation period is prohibited
// under this license.
// See http://www.sencha.com/legal/sencha-sdk-software-license-agreement (Trial License)
// for license terms.
// ------------------------------------------------------------------------------------------
// `)
//                 }
//             }
// //            if (loglevel > 3) {
// //                console.log(`> [activator]: ${stdout}`);
// //            }
//         }
//     });
