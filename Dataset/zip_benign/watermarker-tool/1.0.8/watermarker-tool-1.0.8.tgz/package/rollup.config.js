import resolve from '@rollup/plugin-node-resolve'
import { uglify } from 'rollup-plugin-uglify';
import serve from 'rollup-plugin-serve';
import livereload from 'rollup-plugin-livereload';

export default {
  input: "./src/index.js",
  output: {
    file: "./dist/watermarker.umd.js", 
    format: "umd",
    name: "watermarker",
  },
  plugins: [
    resolve(),
    // 压缩代码
    uglify(),
    // 热更新 默认监听根文件夹
    livereload(),
    // 本地服务器
    serve({
      open: true, // 自动打开页面
      port: 8000,
      openPage: '/example/index.html', // 打开的页面
      contentBase: ''
    })
  ]
} 