### 已实现功能
1. 根据传入的dom元素进行水印的渲染，无需额外配置
2. 可以为不同元素区域分别渲染水印
3. 实现水印防止篡改
4. 清除水印功能

### 使用方法
``` js
1. 安装
npm i watermarker-tool
2. 引入
import watermarker from "watermarker-tool";
3. 使用
const markerBody = document.createElement("div");
markerBody.innerHTML = "ihhuhiuh";
markerBody.className = "marker";
// 清除水印的函数
let clearBody
// 添加水印
watermarker(markerBody).then(val => clearBody = val)
// 清除水印
clearBody()
```
``` css
.marker {
  width: 200px;
  height: 200px;
  display: flex;
  align-items: center;
  justify-content: center;
  transform: rotate(-30deg);
  transform-origin: 50% 50%;
  color: red;
  font-size: 40px;
  opacity: 0.5;
}
```