export default class Point {
    constructor(id, obj) {
        this.id = id
        this.position = obj.position || { x: 0, y: 0, z: 0 }
        this.rotation = obj.rotation || null
        this.color = obj.color || 0xffffff
        this.opacity = obj.opacity || 1
        this.radius = obj.radius || 0.1
        this.scale = obj.scale || 0.5
        this.object = null
        this.onClick = null
        this.payload = obj.payload || null
        this.doubleSide = obj.doubleSide || true
    }

    setObject(object) {
        this.object = object
    }

    update(obj) {
        this.position = obj.position
        this.rotation = obj.rotation
        this.color = obj.color
        this.radius = obj.radius
        this.scale = obj.scale
    }
}
