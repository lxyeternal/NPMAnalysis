<template>
    <div class="gltf-viewer" ref="container"></div>
</template>

<script>
import Viewer from './viewer'
import * as dat from 'dat.gui'
import { mergeDeep } from './utils'

export default {
    name: 'gltf-viewer',
    props: {
        url: String,
        options: Object,
        points: Array,
        value: Object,
        urls: Array
    },
    data() {
        return {
            viewer: '',
            viewerEl: '',
            pointObjects: [],
            gui: null,
            selectedPoint: null,
            defaultOptions: {
                bgColor: 0xcccccc,
                bgAlpha: 1,
                lights: {
                    exposure: 2.0,
                    textureEncoding: 'sRGB',
                    ambientIntensity: 0.3,
                    ambientColor: 0xFFFFFF,
                    directIntensity: 0.8 * Math.PI,
                    directColor: 0xFFFFFF
                },
                editMode: false,
                controls: {
                    enabled: true,
                    minPolarAngle: 0,
                    maxPolarAngle: Math.PI,
                    minAzimuthAngle: -Infinity,
                    maxAzimuthAngle: Infinity,
                    minDistance: 0,
                    maxDistance: Infinity,
                    autoRotate: true,
                    autoRotateSpeed: -10,
                    enableZoom: true,
                    zoom: 1
                }
            }
        }
    },
    mounted() {
        if (this.url) {
            this.view(this.url)
        }
        if (this.urls) {
            this.urls.forEach(url => this.view(url))
        }
        if (this.options.editMode) {
            this.gui = new dat.GUI()
        }
    },
    methods: {
        /**
         * Sets up the view manager.
         * @return {Viewer}
         */
        createViewer() {
            this.viewerEl = document.createElement('div')
            this.viewerEl.classList.add('viewer')
            this.viewerEl.addEventListener('touchstart', this.onTouchStart, true)
            this.viewerEl.addEventListener('touchmove', this.onTouchMove, true)
            this.viewerEl.addEventListener('touchend', this.onTouchEnd, true)
            this.$refs.container.appendChild(this.viewerEl)
            this.viewer = new Viewer(this.viewerEl, mergeDeep(this.defaultOptions, this.options))
            this.viewer.addPointsScene()
            this.setupEventListeners()
            return this.viewer
        },
        /**
         * Passes a model to the viewer, given file and resources.
         * @param  {File|string} file
         */
        view(file) {
            // if (this.viewer) this.viewer.clear()
            const viewer = this.viewer || this.createViewer()

            viewer.load(file, new Map())
                .catch((e) => this.onError(e))
                .then((gltf) => {
                    this.$emit('object-loaded', { url: file, gltf })
                    if (this.points && this.points.length > 0) {
                        this.createPoints()
                    }
                })
        },
        moveCamera() {
            if (this.value && this.value.hasOwnProperty('x') && this.value.hasOwnProperty('y') && this.value.hasOwnProperty('z')) {
                this.viewer.moveCamera(this.value)
            }
        },
        /**
         * add all relevant event listeners so they don't get added twice
         */
        setupEventListeners() {
            this.viewer.on('camera-changed', pos => {
                this.$emit('input', { ...pos })
            })
            this.viewer.on('controls-start', () => {
                if (this.controlOptions.enabled) {
                    this.$emit('start-drag')
                }
            })
            this.viewer.on('controls-end', () => {
                if (this.controlOptions.enabled) {
                    this.$emit('end-drag')
                }
            })
            this.viewer.on('point-clicked', e => {
                this.$emit('point-clicked', e)
            })
            this.viewer.on('point-activated', e => {
                this.selectPoint(e)
            })
        },
        /**
         * @param  {Error} error
         */
        onError(error) {
            let message = (error || {}).message || error.toString()
            if (message.match(/ProgressEvent/)) {
                message = 'Unable to retrieve this file. Check JS console and browser network tab.'
            } else if (message.match(/Unexpected token/)) {
                message = `Unable to parse file content. Verify that this file is valid. Error: "${message}"`
            } else if (error && error.target && error.target instanceof Image) {
                error = 'Missing texture: ' + error.target.src.split('/').pop()
            }
            console.error(error)
        },

        /**
         * create new scene with points
         */
        createPoints() {
            this.pointObjects = []
            for (let i = 0; i < this.points.length; i++) {
                this.pointObjects.push(this.viewer.addPoint(i, this.points[i]))
            }
        },
        /**
         * selects a point for editing
         * @param {Point} point
         */
        selectPoint(point) {
            console.log(point)
            this.selectedPoint = this.pointObjects.find(p => p.id === point.id)
            if (!this.gui) {
                this.gui.add(this.selectedPoint, 'id')
                let guiGeometry = this.gui.addFolder('geometry')
                guiGeometry.addColor(this.selectedPoint, 'color')
                guiGeometry.add(this.selectedPoint, 'radius')
                guiGeometry.add(this.selectedPoint, 'scale')
                let guiPosition = this.gui.addFolder('position')
                guiPosition.add(this.selectedPoint.position, 'x')
                guiPosition.add(this.selectedPoint.position, 'y')
                guiPosition.add(this.selectedPoint.position, 'z')
                if (this.selectedPoint.rotation) {
                    let guiRotation = this.gui.addFolder('rotation')
                    guiRotation.add(this.selectedPoint.rotation, 'x')
                    guiRotation.add(this.selectedPoint.rotation, 'y')
                    guiRotation.add(this.selectedPoint.rotation, 'z')
                }
                for (let i = 0; i < this.gui.__folders.length; i++) {
                    for (let j = 0; j < this.gui.__folders[i].__controllers.length; j++) {
                        this.gui.__folders[i].__controllers[j].onChange(() => this.viewer.updatePoint(this.selectedPoint))
                    }
                }
            } else {
                for (let i = 0; i < this.gui.__folders.length; i++) {
                    for (let j = 0; j < this.gui.__folders[i].__controllers.length; j++) {
                        this.gui.__folders[i].__controllers[j].updateDisplay()
                    }
                }
            }
        },
        /**
         * propagate touch events
         */
        onTouchStart(e) {
            this.$emit('touchstart', e)
        },
        onTouchMove(e) {
            this.$emit('touchmove', e)
        },
        onTouchEnd(e) {
            this.$emit('touchend', e)
        }
    },
    computed: {
        controlOptions() {
            if (!this.options.controls) {
                return this.defaultOptions.controls
            } else {
                return mergeDeep(this.defaultOptions.controls, this.options.controls)
            }
        }
    },
    watch: {
        value() {
            if (!this.viewer.controls.autoRotate) {
                this.moveCamera()
            }
        },
        options: {
            deep: true,
            handler: function() {
                this.viewer.updateControls(this.controlOptions)
            }
        },
        points: {
            handler() {
                this.viewer.removePoints()
                this.createPoints()
            },
            deep: true
        }
    },
    /**
     * Clean up
     * tear down event handlers
     */
    beforeDestroy() {
        this.viewerEl.removeEventListener('touchstart', this.onTouchStart)
        this.viewerEl.removeEventListener('touchmove', this.onTouchMove)
        this.viewerEl.removeEventListener('touchend', this.onTouchEnd)
    }
}
</script>

<style lang="scss">
    .gltf-viewer {
        width: 100%;
        height: 100%;
        display: flex;
        flex-grow: 1;
        position: relative;

        .viewer {
            width: 100%;
            height: 100%;
            flex-grow: 1;
            flex-shrink: 1;
            position: absolute;
            top: 0;
        }

        .spinner {
            width: 40px;
            height: 40px;
            position: absolute;
            left: 50%;
            top: 50%;
            margin: -20px;

            background-color: #333;

            border-radius: 100%;
            -webkit-animation: sk-scaleout 1.0s infinite ease-in-out;
            animation: sk-scaleout 1.0s infinite ease-in-out;
        }

        @-webkit-keyframes sk-scaleout {
            0% {
                -webkit-transform: scale(0)
            }
            100% {
                -webkit-transform: scale(1.0);
                opacity: 0;
            }
        }

        @keyframes sk-scaleout {
            0% {
                -webkit-transform: scale(0);
                transform: scale(0);
            }
            100% {
                -webkit-transform: scale(1.0);
                transform: scale(1.0);
                opacity: 0;
            }
        }

    }
</style>
