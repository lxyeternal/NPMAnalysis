import { EventEmitter } from 'events'
import Point from './Point'

const THREE = window.THREE = require('three')
// const environments = require('../assets/environment/index')
// const createVignetteBackground = require('three-vignette-background')

require('three/examples/js/loaders/GLTFLoader')
require('three/examples/js/loaders/DRACOLoader')
require('three/examples/js/loaders/DDSLoader')
require('three/examples/js/controls/OrbitControls')
require('three/examples/js/loaders/RGBELoader')
require('three/examples/js/loaders/HDRCubeTextureLoader')
require('three/examples/js/loaders/SVGLoader')
require('three/examples/js/pmrem/PMREMGenerator')
require('three/examples/js/pmrem/PMREMCubeUVPacker')

THREE.DRACOLoader.setDecoderPath('lib/draco/')

const DEFAULT_CAMERA = '[default]'

// const IS_IOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream

// glTF texture types. `envMap` is deliberately omitted, as it's used internally
// by the loader but not part of the glTF format.
const MAP_NAMES = [
    'map',
    'aoMap',
    'emissiveMap',
    'glossinessMap',
    'metalnessMap',
    'normalMap',
    'roughnessMap',
    'specularMap'
]

const Preset = { ASSET_GENERATOR: 'assetgenerator' }

export default class Viewer extends EventEmitter {
    constructor(el, options) {
        super()
        this.el = el
        this.options = options

        this.lights = []
        this.content = null
        this.mixer = null

        this.state = {
            // environment: options.preset === Preset.ASSET_GENERATOR
            //     ? 'Footprint Court (HDR)'
            //     : environments[1].name,
            background: false,
            playbackSpeed: 1.0,
            actionStates: {},
            camera: DEFAULT_CAMERA,
            wireframe: false,
            skeleton: false,
            grid: false,

            // Lights
            addLights: true,
            exposure: options.lights.exposure || 1.0,
            textureEncoding: options.lights.textureEncoding || 'sRGB',
            ambientIntensity: options.lights.ambientIntensity || 0.3,
            ambientColor: options.lights.ambientColor || 0xFFFFFF,
            directIntensity: options.lights.directIntensity || 0.8 * Math.PI,
            directColor: options.lights.directColor || 0xFFFFFF,
            // bgColor1: '#ffffff',
            // bgColor2: '#353535'
            maxClickAngle: options.maxClickAngle || 25
        }

        this.prevTime = 0

        this.scene = new THREE.Scene()
        this.raycaster = null
        this.INTERSECTED = null

        const fov = options.preset === Preset.ASSET_GENERATOR
            ? 0.8 * 180 / Math.PI
            : 60
        this.defaultCamera = new THREE.PerspectiveCamera(fov, el.clientWidth / el.clientHeight, 0.01, 1000)
        this.defaultCamera.zoom = options.controls.zoom || 1
        this.activeCamera = this.defaultCamera
        this.scene.add(this.defaultCamera)

        this.renderer = window.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: options.bgAlpha < 1 })
        this.renderer.physicallyCorrectLights = true
        this.renderer.gammaOutput = true
        this.renderer.gammaFactor = 2.2
        this.renderer.setClearColor(options.bgColor || 0x000000, options.bgAlpha || 0)
        this.renderer.setPixelRatio(window.devicePixelRatio)
        this.renderer.setSize(el.clientWidth, el.clientHeight)

        this.controls = new THREE.OrbitControls(this.defaultCamera, this.renderer.domElement)
        this.controls.enabled = false
        this.controls.enableKeys = false
        this.controls.enablePan = false
        this.controls.screenSpacePanning = true
        this.controls.addEventListener('change', () => {
            this.emit('camera-changed', this.defaultCamera.position)
        })
        this.controls.addEventListener('start', () => {
            this.emit('controls-start')
        })
        this.controls.addEventListener('end', () => {
            this.emit('controls-end')
        })
        this.setupControls(options.controls)

        this.points = []
        // this.background = createVignetteBackground({
        //     aspect: this.defaultCamera.aspect,
        //     grainScale: IS_IOS ? 0 : 0.001, // mattdesl/three-vignette-background#1
        //     colors: [this.state.bgColor1, this.state.bgColor2]
        // })

        this.el.appendChild(this.renderer.domElement)

        this.skeletonHelpers = []
        this.gridHelper = null
        this.axesHelper = null

        this.animate = this.animate.bind(this)
        requestAnimationFrame(this.animate)
        window.addEventListener('resize', this.resize.bind(this), false)
    }

    setupControls(controlsOptions) {
        this.controls.reset()
        //
        this.controls.autoRotate = controlsOptions.autoRotate || false
        this.controls.autoRotateSpeed = controlsOptions.autoRotateSpeed || -10
        this.controls.enabled = controlsOptions.enabled || false
        this.controls.enableZoom = controlsOptions.enableZoom
        this.controls.enableKeys = controlsOptions.enableKeys || false

        this.controls.minPolarAngle = controlsOptions.minPolarAngle || 0
        this.controls.maxPolarAngle = controlsOptions.maxPolarAngle || Math.PI
        this.controls.minAzimuthAngle = controlsOptions.minAzimuthAngle || -Infinity
        this.controls.maxAzimuthAngle = controlsOptions.maxAzimuthAngle || Infinity
        this.controls.minDistance = controlsOptions.minDistance || 0
        this.controls.maxDistance = controlsOptions.maxDistance || Infinity
        this.controls.saveState()
    }

    updateControls(controlsOptions) {
        Object.keys(controlsOptions).forEach(option => {
            this.controls[option] = controlsOptions[option]
        })
    }

    animate(time) {
        requestAnimationFrame(this.animate)
        const dt = (time - this.prevTime) / 1000
        this.controls.update()
        this.mixer && this.mixer.update(dt)
        this.render()
        this.prevTime = time
    }

    render() {
        this.renderer.render(this.scene, this.activeCamera)
    }

    resize() {
        const { clientHeight, clientWidth } = this.el.parentElement
        this.defaultCamera.aspect = clientWidth / clientHeight
        this.defaultCamera.updateProjectionMatrix()
        this.background.style({ aspect: this.defaultCamera.aspect })
        this.renderer.setSize(clientWidth, clientHeight)
    }

    load(url, assetMap) {
        return new Promise((resolve, reject) => {
            const manager = new THREE.LoadingManager()

            // Intercept and override relative URLs.
            manager.setURLModifier((url, path) => {
                if (assetMap.has(url)) {
                    const blob = assetMap.get(url)
                    const blobURL = URL.createObjectURL(blob)
                    blobURLs.push(blobURL)
                    return blobURL
                }
                return (path || '') + url
            })

            const loader = new THREE.GLTFLoader(manager)
            loader.setCrossOrigin('anonymous')
            loader.setDRACOLoader(new THREE.DRACOLoader())
            const blobURLs = []

            loader.load(url, (gltf) => {
                const scene = gltf.scene || gltf.scenes[0]
                const clips = gltf.animations || []
                this.setContent(scene, clips)
                resolve(gltf)
            }, undefined, reject)
        })
    }

    /**
     * @param {THREE.Object3D} object
     * @param {Array<THREE.AnimationClip} clips
     */
    setContent(object, clips) {
        // this.clear()

        object.updateMatrixWorld()
        const box = new THREE.Box3().setFromObject(object)
        const size = box.getSize(new THREE.Vector3()).length()
        const center = box.getCenter(new THREE.Vector3())

        this.controls.reset()
        this.controls.mainistance = size * 0.75

        object.position.x += (object.position.x - center.x)
        object.position.y += (object.position.y - center.y)
        object.position.z += (object.position.z - center.z)
        object.rotation.x = 0
        object.rotation.y = 0
        object.rotation.z = 0
        this.defaultCamera.near = size / 100
        this.defaultCamera.far = size * 100
        this.defaultCamera.updateProjectionMatrix()

        if (this.options.cameraPosition) {
            this.defaultCamera.position.fromArray(this.options.cameraPosition)
            this.defaultCamera.lookAt(new THREE.Vector3())
        } else {
            this.defaultCamera.position.copy(center)
            this.defaultCamera.position.x += size / 2.0
            this.defaultCamera.position.y += size / 5.0
            this.defaultCamera.position.z += size / 2.0
            this.defaultCamera.lookAt(center)
        }

        this.setCamera(DEFAULT_CAMERA)

        this.controls.saveState()

        this.scene.add(object)
        this.content = object

        this.state.addLights = true
        this.content.traverse((node) => {
            if (node.isLight) {
                this.state.addLights = false
            }
        })

        this.setClips(clips)

        this.updateLights()
        this.updateTextureEncoding()
        this.updateDisplay()
        this.printGraph(this.content)
    }

    printGraph(node) {
        node.children.forEach((child) => this.printGraph(child))
        console.groupEnd()
    }

    /**
     * @param {Array<THREE.AnimationClip} clips
     */
    setClips(clips) {
        if (this.mixer) {
            this.mixer.stopAllAction()
            this.mixer.uncacheRoot(this.mixer.getRoot())
            this.mixer = null
        }

        clips.forEach((clip) => {
            if (clip.validate()) clip.optimize()
        })

        this.clips = clips
        if (!clips.length) return

        this.mixer = new THREE.AnimationMixer(this.content)
    }

    /**
     * @param {string} name
     */
    setCamera(name) {
        if (name === DEFAULT_CAMERA) {
            this.activeCamera = this.defaultCamera
        } else {
            this.content.traverse((node) => {
                if (node.isCamera && node.name === name) {
                    this.activeCamera = node
                }
            })
        }
    }

    updateTextureEncoding() {
        const encoding = this.state.textureEncoding === 'sRGB'
            ? THREE.sRGBEncoding
            : THREE.LinearEncoding
        traverseMaterials(this.content, (material) => {
            if (material.map) material.map.encoding = encoding
            if (material.emissiveMap) material.emissiveMap.encoding = encoding
            if (material.map || material.emissiveMap) material.needsUpdate = true
        })
    }

    updateLights() {
        const state = this.state
        const lights = this.lights

        if (state.addLights && !lights.length) {
            this.addLights()
        } else if (!state.addLights && lights.length) {
            this.removeLights()
        }

        this.renderer.toneMappingExposure = state.exposure

        if (lights.length === 2) {
            lights[0].intensity = state.ambientIntensity
            lights[0].color.setHex(state.ambientColor)
            lights[1].intensity = state.directIntensity
            lights[1].color.setHex(state.directColor)
        }
    }

    addLights() {
        const state = this.state

        if (this.options.preset === Preset.ASSET_GENERATOR) {
            const hemiLight = new THREE.HemisphereLight()
            hemiLight.name = 'hemi_light'
            this.scene.add(hemiLight)
            this.lights.push(hemiLight)
            return
        }

        const light1 = new THREE.AmbientLight(state.ambientColor, state.ambientIntensity)
        light1.name = 'ambient_light'
        this.defaultCamera.add(light1)

        const light2 = new THREE.DirectionalLight(state.directColor, state.directIntensity)
        light2.position.set(0.5, 0, 0.866) // ~60º
        light2.name = 'main_light'
        this.defaultCamera.add(light2)

        const light3 = new THREE.PointLight(state.directColor, state.directIntensity)
        light3.position.set(this.defaultCamera.position.x, this.defaultCamera.position.y, this.defaultCamera.position.z)
        this.defaultCamera.add(light3)
        this.lights.push(light1, light2, light3)
    }

    removeLights() {
        this.lights.forEach((light) => light.parent.remove(light))
        this.lights.length = 0
    }

    updateDisplay() {
        if (this.skeletonHelpers.length) {
            this.skeletonHelpers.forEach((helper) => this.scene.remove(helper))
        }

        traverseMaterials(this.content, (material) => {
            material.wireframe = this.state.wireframe
        })

        this.content.traverse((node) => {
            if (node.isMesh && node.skeleton && this.state.skeleton) {
                const helper = new THREE.SkeletonHelper(node.skeleton.bones[0].parent)
                helper.material.linewidth = 3
                this.scene.add(helper)
                this.skeletonHelpers.push(helper)
            }
        })

        if (this.state.grid !== Boolean(this.gridHelper)) {
            if (this.state.grid) {
                this.gridHelper = new THREE.GridHelper()
                this.axesHelper = new THREE.AxesHelper()
                this.axesHelper.renderOrder = 999
                this.axesHelper.onBeforeRender = (renderer) => renderer.clearDepth()
                this.scene.add(this.gridHelper)
                this.scene.add(this.axesHelper)
            } else {
                this.scene.remove(this.gridHelper)
                this.scene.remove(this.axesHelper)
                this.gridHelper = null
                this.axesHelper = null
            }
        }
    }

    updateBackground() {
        this.background.style({ colors: [this.state.bgColor1, this.state.bgColor2] })
    }

    clear() {
        if (!this.content) return

        this.scene.remove(this.content)

        // dispose geometry
        this.content.traverse((node) => {
            if (!node.isMesh) return

            node.geometry.dispose()
        })

        // dispose textures
        traverseMaterials(this.content, (material) => {
            MAP_NAMES.forEach((map) => {
                if (material[map]) material[map].dispose()
            })
        })
    }

    addPointsScene() {
        if (this.raycaster) return
        this.raycaster = new THREE.Raycaster()
        this.renderer.domElement.addEventListener('mouseup', event => this.onClick(event))
        this.renderer.domElement.addEventListener('touchend', event => this.onTouch(event))
    }

    addPoint(id, pointObj) {
        let point = new Point(id, pointObj)
        let outerPoint = new Point(id, pointObj)
        outerPoint.opacity *= 0.3
        point.radius *= 0.5
        let touchPoint = new Point(id, pointObj)
        touchPoint.opacity = 0
        let group = new THREE.Group() // this.createPointObject(touchPoint)
        group.add(this.createPointObject(point))
        group.add(this.createPointObject(outerPoint))

        group.position.x = point.position.x
        group.position.y = point.position.y
        group.position.z = point.position.z

        if (point.rotation) {
            group.rotation.x = point.rotation.x
            group.rotation.y = point.rotation.y
            group.rotation.z = point.rotation.z
        } else {
            group.frustumCulled = false
            group.onBeforeRender = (renderer, scene, camera) => {
                if (!this.points.find(p => p.object.uuid === group.uuid).rotation) {
                    group.quaternion.copy(camera.quaternion)
                }
            }
        }

        group.scale.x = point.scale
        group.scale.y = point.scale
        group.scale.z = point.scale

        point.setObject(group)
        this.points.push(point)
        this.scene.add(group)
        return point
    }

    createPointObject(point) {
        let geometry = new THREE.CircleBufferGeometry(point.radius, 32)
        let material = new THREE.MeshLambertMaterial({
            color: point.color,
            transparent: true,
            opacity: point.opacity,
            side: point.doubleSide ? THREE.DoubleSide : THREE.FrontSide
        })
        return new THREE.Mesh(geometry, material)
    }

    updatePoint(point) {
        let _point = this.points.find(p => p.id === point.id)
        _point.update(point)

        if (_point.object) {
            let object = _point.object

            let geometry = new THREE.CircleBufferGeometry(point.radius, 32)
            object.geometry = geometry
            // object.material.color = point.color
            // object.material.opacity = point.opacity

            object.position.x = point.position.x
            object.position.y = point.position.y
            object.position.z = point.position.z

            if (point.rotation) {
                object.rotation.x = point.rotation.x
                object.rotation.y = point.rotation.y
                object.rotation.z = point.rotation.z
                object.frustumCulled = true
                object.onBeforeRender = null
            } else {
                object.frustumCulled = false
                object.onBeforeRender = (renderer, scene, camera) => {
                    if (!this.points.find(p => p.object.uuid === object.uuid).rotation) {
                        object.quaternion.copy(camera.quaternion)
                    }
                }
            }

            object.scale.x = point.scale
            object.scale.y = point.scale
            object.scale.z = point.scale
        }
    }

    removePoint(id) {
        const point = this.points.find(p => p.id === id)
        point.object.onBeforeRender = null
        this.scene.remove(point.object)
        this.points.splice(this.points.findIndex(p => p.id === id), 1)
    }

    removePoints() {
        this.scene.remove(...this.points.map(p => p.object))
        this.points = []
    }

    onClick(event) {
        event.preventDefault()
        this.clickHandler(event.offsetX, event.offsetY, event.shiftKey)
    }

    onTouch(event) {
        event.preventDefault()
        this.clickHandler(event.changedTouches[0].clientX, event.changedTouches[0].clientY, event.shiftKey)
    }

    clickHandler(ex, ey, shift = false) {
        let size = new THREE.Vector2(0, 0)
        this.renderer.getSize(size)
        let x = (ex / size.width) * 2 - 1
        let y = -(ey / size.height) * 2 + 1
        this.raycaster.setFromCamera(new THREE.Vector2(x, y), this.activeCamera)
        let intersects = this.raycaster.intersectObjects(this.points.map(p => p.object.children[0]), true)
        if (intersects.length > 0) {
            this.INTERSECTED = intersects[0].object
            const point = this.points.find(x => x.object.children[0].uuid === this.INTERSECTED.uuid)
            if (!point) {
                this.INTERSECTED = null
                return
            }
            if (shift) {
                this.emit('point-activated', point)
            } else {
                let pointVector = new THREE.Vector3(0, 0, -1).applyQuaternion(point.object.quaternion)
                let cameraVector = new THREE.Vector3(0, 0, -1).applyQuaternion(this.activeCamera.quaternion)
                let angle = THREE.Math.radToDeg(pointVector.angleTo(cameraVector))
                console.log(angle)
                if (angle <= this.state.maxClickAngle || angle >= (180 - this.state.maxClickAngle)) {
                    this.emit('point-clicked', point)
                }
            }
        } else {
            this.INTERSECTED = null
        }
    }

    moveCamera(pos) {
        this.defaultCamera.position.set(pos.x, pos.y, pos.z)
        this.defaultCamera.lookAt(this.controls.target)
        this.controls.update()
    }
}

function traverseMaterials(object, callback) {
    object.traverse((node) => {
        if (!node.isMesh) return
        const materials = Array.isArray(node.material)
            ? node.material
            : [node.material]
        materials.forEach(callback)
    })
}
