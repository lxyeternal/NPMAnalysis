export declare const init: (apiKey: string, options: import("./typings/session-replay").SessionReplayOptions) => import("@amplitude/analytics-types").AmplitudeReturn<void>, setSessionId: (sessionId: number, deviceId?: string | undefined) => import("@amplitude/analytics-types").AmplitudeReturn<void>, getSessionId: () => number | undefined, getSessionReplayProperties: () => {
    [key: string]: string | boolean | null;
}, flush: (useRetry: boolean) => Promise<void>, shutdown: () => void;
//# sourceMappingURL=index.d.ts.map