import { SessionReplayEventsManager as AmplitudeSessionReplayEventsManager } from '../typings/session-replay';
import { SessionReplayJoinedConfig } from '../config/types';
export declare const createEventsManager: ({ config, sessionId, }: {
    config: SessionReplayJoinedConfig;
    sessionId?: number | undefined;
}) => Promise<AmplitudeSessionReplayEventsManager>;
//# sourceMappingURL=events-manager.d.ts.map