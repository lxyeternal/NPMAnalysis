import { SessionIdentifiers as ISessionIdentifiers } from './typings/session-replay';
export declare class SessionIdentifiers implements ISessionIdentifiers {
    deviceId?: string | undefined;
    sessionId?: number | undefined;
    sessionReplayId?: string | undefined;
    constructor({ sessionId, deviceId }: {
        sessionId?: number;
        deviceId?: string;
    });
}
//# sourceMappingURL=identifiers.d.ts.map