import { PrivacyConfig } from './config/types';
export declare const maskInputFn: (config?: PrivacyConfig) => (text: string, element: HTMLElement) => string;
export declare const maskTextFn: (config?: PrivacyConfig) => (text: string, element: HTMLElement | null) => string;
export declare const generateHashCode: (str: string) => number;
export declare const isSessionInSample: (sessionId: number, sampleRate: number) => boolean;
export declare const getCurrentUrl: () => string;
export declare const generateSessionReplayId: (sessionId: number, deviceId: string) => string;
//# sourceMappingURL=helpers.d.ts.map