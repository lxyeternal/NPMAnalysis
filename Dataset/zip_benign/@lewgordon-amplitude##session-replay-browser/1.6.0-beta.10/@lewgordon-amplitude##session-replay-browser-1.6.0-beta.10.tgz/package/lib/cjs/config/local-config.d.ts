import { FetchTransport } from '@amplitude/analytics-client-common';
import { Config, Logger } from '@amplitude/analytics-core';
import { LogLevel } from '@amplitude/analytics-types';
import { SessionReplayOptions } from '../typings/session-replay';
import { SessionReplayLocalConfig as ISessionReplayLocalConfig, PrivacyConfig } from './types';
export declare const getDefaultConfig: () => {
    flushMaxRetries: number;
    logLevel: LogLevel;
    loggerProvider: Logger;
    transportProvider: FetchTransport;
};
export declare class SessionReplayLocalConfig extends Config implements ISessionReplayLocalConfig {
    apiKey: string;
    sampleRate: number;
    privacyConfig?: PrivacyConfig;
    debugMode?: boolean;
    configEndpointUrl?: string;
    constructor(apiKey: string, options: SessionReplayOptions);
}
//# sourceMappingURL=local-config.d.ts.map