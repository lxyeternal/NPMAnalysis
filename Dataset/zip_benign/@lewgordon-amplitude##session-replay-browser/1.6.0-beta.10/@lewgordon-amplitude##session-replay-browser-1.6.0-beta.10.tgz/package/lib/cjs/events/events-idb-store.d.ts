import { Logger as ILogger } from '@amplitude/analytics-types';
import { DBSchema, IDBPDatabase } from 'idb';
import { SessionReplayEventsIDBStore as AmplitudeSessionReplayEventsIDBStore, Events, SendingSequencesIDBInput } from '../typings/session-replay';
export declare const currentSequenceKey = "sessionCurrentSequence";
export declare const sequencesToSendKey = "sequencesToSend";
export declare const remoteConfigKey = "remoteConfig";
export interface SessionReplayDB extends DBSchema {
    sessionCurrentSequence: {
        key: number;
        value: {
            sessionId: number;
            events: Events;
        };
    };
    sequencesToSend: {
        key: number;
        value: SendingSequencesIDBInput;
        indexes: {
            sessionId: number;
        };
    };
}
export declare const keyValDatabaseExists: () => Promise<IDBDatabase | void>;
export declare const defineObjectStores: (db: IDBPDatabase<SessionReplayDB>) => {
    sequencesStore: import("idb").IDBPObjectStore<SessionReplayDB, ArrayLike<"sessionCurrentSequence" | "sequencesToSend">, "sequencesToSend", "versionchange"> | undefined;
    currentSequenceStore: import("idb").IDBPObjectStore<SessionReplayDB, ArrayLike<"sessionCurrentSequence" | "sequencesToSend">, "sessionCurrentSequence", "versionchange"> | undefined;
};
export declare const createStore: (dbName: string) => Promise<IDBPDatabase<SessionReplayDB>>;
export declare class SessionReplayEventsIDBStore implements AmplitudeSessionReplayEventsIDBStore {
    apiKey: string;
    db: IDBPDatabase<SessionReplayDB> | undefined;
    loggerProvider: ILogger;
    storageKey: string;
    maxPersistedEventsSize: number;
    interval: number;
    timeAtLastSplit: number | null;
    constructor({ loggerProvider, apiKey }: {
        loggerProvider: ILogger;
        apiKey: string;
    });
    initialize(sessionId?: number): Promise<void>;
    /**
     * Determines whether to send the events list to the backend and start a new
     * empty events list, based on the size of the list as well as the last time sent
     * @param nextEventString
     * @returns boolean
     */
    shouldSplitEventsList: (events: Events, nextEventString: string) => boolean;
    getSequencesToSend: () => Promise<Required<SendingSequencesIDBInput>[] | undefined>;
    storeCurrentSequence: (sessionId: number) => Promise<{
        sessionId: number;
        sequenceId: number;
        events: Events;
    } | undefined>;
    addEventToCurrentSequence: (sessionId: number, event: string) => Promise<{
        events: Events;
        sessionId: number;
        sequenceId: number;
    } | undefined>;
    storeSendingEvents: (sessionId: number, events: Events) => Promise<number | undefined>;
    cleanUpSessionEventsStore: (sequenceId: number) => Promise<void>;
    transitionFromKeyValStore: (sessionId?: number) => Promise<void>;
}
export declare const createEventsIDBStore: ({ loggerProvider, apiKey, sessionId, }: {
    loggerProvider: ILogger;
    apiKey: string;
    sessionId?: number | undefined;
}) => Promise<SessionReplayEventsIDBStore>;
//# sourceMappingURL=events-idb-store.d.ts.map