import { Logger as ILogger, ServerZone } from '@amplitude/analytics-types';
import { SessionReplayTrackDestination as AmplitudeSessionReplayTrackDestination, SessionReplayDestination, SessionReplayDestinationContext } from './typings/session-replay';
export declare class SessionReplayTrackDestination implements AmplitudeSessionReplayTrackDestination {
    loggerProvider: ILogger;
    storageKey: string;
    retryTimeout: number;
    private scheduled;
    queue: SessionReplayDestinationContext[];
    constructor({ loggerProvider }: {
        loggerProvider: ILogger;
    });
    sendEventsList(destinationData: SessionReplayDestination): void;
    getServerUrl(serverZone?: keyof typeof ServerZone): "https://api-sr.amplitude.com/sessions/v2/track" | "https://api-sr.eu.amplitude.com/sessions/v2/track" | "https://api-sr.stag2.amplitude.com/sessions/v2/track";
    addToQueue(...list: SessionReplayDestinationContext[]): void;
    schedule(timeout: number): void;
    flush(useRetry?: boolean): Promise<void>;
    send(context: SessionReplayDestinationContext, useRetry?: boolean): Promise<void>;
    handleReponse(status: number, context: SessionReplayDestinationContext): void;
    handleSuccessResponse(context: SessionReplayDestinationContext): void;
    handleOtherResponse(context: SessionReplayDestinationContext): void;
    completeRequest({ context, err, success, }: {
        context: SessionReplayDestinationContext;
        err?: string;
        success?: string;
    }): void;
}
//# sourceMappingURL=track-destination.d.ts.map