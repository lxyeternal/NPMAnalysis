import { Logger as ILogger } from '@amplitude/analytics-types';
import { record } from '@amplitude/rrweb';
import { SessionReplayJoinedConfig, SessionReplayJoinedConfigGenerator } from './config/types';
import { AmplitudeSessionReplay, SessionReplayEventsManager as AmplitudeSessionReplayEventsManager, SessionIdentifiers as ISessionIdentifiers, SessionReplayOptions } from './typings/session-replay';
export declare class SessionReplay implements AmplitudeSessionReplay {
    name: string;
    config: SessionReplayJoinedConfig | undefined;
    joinedConfigGenerator: SessionReplayJoinedConfigGenerator | undefined;
    identifiers: ISessionIdentifiers | undefined;
    eventsManager: AmplitudeSessionReplayEventsManager | undefined;
    loggerProvider: ILogger;
    recordCancelCallback: ReturnType<typeof record> | null;
    constructor();
    init(apiKey: string, options: SessionReplayOptions): import("@amplitude/analytics-types").AmplitudeReturn<void>;
    protected _init(apiKey: string, options: SessionReplayOptions): Promise<void>;
    setSessionId(sessionId: number, deviceId?: string): import("@amplitude/analytics-types").AmplitudeReturn<void>;
    asyncSetSessionId(sessionId: number, deviceId?: string): Promise<void>;
    getSessionReplayDebugPropertyValue(): string;
    getSessionReplayProperties(): {
        [key: string]: string | null;
    };
    blurListener: () => void;
    focusListener: () => void;
    stopRecordingAndSendEvents(sessionId?: number): void;
    initialize(shouldSendStoredEvents?: boolean): void;
    shouldOptOut(): boolean | undefined;
    getShouldRecord(ignoreFocus?: boolean): boolean;
    getBlockSelectors(): string | string[] | undefined;
    getMaskTextSelectors(): string | undefined;
    recordEvents(): void;
    stopRecordingEvents: () => void;
    getDeviceId(): string | undefined;
    getSessionId(): number | undefined;
    flush(useRetry?: boolean): Promise<void>;
    shutdown(): void;
}
//# sourceMappingURL=session-replay.d.ts.map