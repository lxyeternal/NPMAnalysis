import { RemoteConfigFetch } from '@amplitude/analytics-remote-config';
import { SessionReplayOptions } from '../typings/session-replay';
import { SessionReplayLocalConfig as ISessionReplayLocalConfig, SessionReplayJoinedConfig, SessionReplayRemoteConfig } from './types';
export declare class SessionReplayJoinedConfigGenerator {
    localConfig: ISessionReplayLocalConfig;
    remoteConfigFetch: RemoteConfigFetch<SessionReplayRemoteConfig> | undefined;
    constructor(apiKey: string, options: SessionReplayOptions);
    initialize(): Promise<void>;
    generateJoinedConfig(sessionId?: number): Promise<SessionReplayJoinedConfig>;
}
export declare const createSessionReplayJoinedConfigGenerator: (apiKey: string, options: SessionReplayOptions) => Promise<SessionReplayJoinedConfigGenerator>;
//# sourceMappingURL=joined-config.d.ts.map