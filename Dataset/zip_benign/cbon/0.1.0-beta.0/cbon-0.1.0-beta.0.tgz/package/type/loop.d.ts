export declare const _continue: unique symbol;
export declare const _break: unique symbol;
