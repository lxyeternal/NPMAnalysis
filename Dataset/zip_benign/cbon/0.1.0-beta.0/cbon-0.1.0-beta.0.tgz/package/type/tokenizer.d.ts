import { Tokens } from "./token";
import { Errors } from "./type";
import { Canceller, AsyncCanceller } from "./canceller";
export declare type char_list = string | string[] | Iterable<string>;
export declare function tokenizer(code: char_list, config: {
    show_all_err?: boolean;
    iterable: true;
    async: true;
    cancel?: Canceller | AsyncCanceller;
}): AsyncGenerator<Tokens, Errors[] | undefined, unknown>;
export declare function tokenizer(code: char_list, config: {
    show_all_err?: boolean;
    iterable: false;
    async: true;
    cancel?: Canceller | AsyncCanceller;
}): Promise<{
    err?: Errors[];
    val: Tokens[];
}>;
export declare function tokenizer(code: char_list, config: {
    show_all_err?: boolean;
    iterable: true;
    async: false;
    cancel?: Canceller;
}): Generator<Tokens, Errors[] | undefined, unknown>;
export declare function tokenizer(code: char_list, config: {
    show_all_err?: boolean;
    iterable: false;
    async: false;
    cancel?: Canceller;
}): {
    err?: Errors[];
    val: Tokens[];
};
export declare function tokenizer(code: char_list, config?: {
    show_all_err?: boolean;
    cancel?: Canceller;
}): {
    err?: Errors[];
    val: Tokens[];
};
export declare function tokenizer(code: char_list, config?: {
    show_all_err?: boolean;
    iterable?: boolean;
    async?: boolean;
    cancel?: Canceller | AsyncCanceller;
}): AsyncGenerator<Tokens, Errors[] | undefined, unknown> | Generator<Tokens, Errors[] | undefined, unknown> | Promise<{
    err?: Errors[];
    val: Tokens[];
}> | {
    err?: Errors[];
    val: Tokens[];
};
