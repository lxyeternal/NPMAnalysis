import { Docs } from "./ast";
import { Tokens } from "./token";
import { Errors } from "./type";
import { Canceller, AsyncCanceller } from "./canceller";
export declare type token_list = Tokens[] | Iterable<Tokens> | Generator<Tokens, Errors[] | undefined>;
export declare type async_token_list = token_list | AsyncIterable<Tokens> | AsyncGenerator<Tokens, Errors[] | undefined>;
export declare function parser(code: async_token_list, config: {
    show_all_err?: boolean;
    async: true;
    cancel?: Canceller | AsyncCanceller;
}): Promise<{
    err?: Errors[];
    val: Docs;
}>;
export declare function parser(code: token_list, config: {
    show_all_err?: boolean;
    async: false;
    cancel?: Canceller;
}): {
    err?: Errors[];
    val: Docs;
};
export declare function parser(code: token_list, config?: {
    show_all_err?: boolean;
    cancel?: Canceller;
}): {
    err?: Errors[];
    val: Docs;
};
export declare function parser(code: async_token_list, config?: {
    show_all_err?: boolean;
    async?: boolean;
    cancel?: Canceller | AsyncCanceller;
}): Promise<{
    err?: Errors[];
    val: Docs;
}> | {
    err?: Errors[];
    val: Docs;
};
