export declare class TkPos {
    count: number;
    char: number;
    line: number;
    constructor(count: number, char: number, line: number);
}
export declare class TkRange {
    from: TkPos;
    to: TkPos;
    constructor(from: TkPos, to: TkPos);
}
