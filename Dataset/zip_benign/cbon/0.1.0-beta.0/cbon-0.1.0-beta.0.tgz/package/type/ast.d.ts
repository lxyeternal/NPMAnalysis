import { TkRange } from "./pos";
import { TComments } from "./token";
export declare abstract class Unit {
}
export declare abstract class Comment extends Unit {
}
export declare class LineComment extends Comment {
    items: (string | Comment)[];
    range: TkRange;
    constructor(range: TkRange, items: (string | TComments)[]);
    constructor(range: TkRange, items: (string | Comment)[]);
}
export declare class BlockComment extends Comment {
    items: (string | Comment)[];
    range: TkRange;
    constructor(range: TkRange, items: (string | TComments)[]);
    constructor(range: TkRange, items: (string | Comment)[]);
}
export declare class Comma extends Unit {
    range: TkRange;
    constructor(range: TkRange);
}
export declare class Null extends Unit {
    range: TkRange;
    constructor(range: TkRange);
}
export declare class Str extends Unit {
    val: string;
    col: '"' | "'" | null;
    range: TkRange;
    constructor(range: TkRange, val: string, col: '"' | "'" | null);
}
export declare class Num extends Unit {
    val: number;
    range: TkRange;
    constructor(range: TkRange, val: number);
}
export declare class Bool extends Unit {
    val: boolean;
    range: TkRange;
    constructor(range: TkRange, val: boolean);
}
export declare class Key {
    key: string | Str;
    range: TkRange;
    constructor(range: TkRange, key: string | Str);
}
export declare class Split {
    type: ':' | '=';
    range: TkRange;
    constructor(range: TkRange, type: ':' | '=');
}
export declare class KeyVal {
    key: Key;
    val: Units;
    split?: Split;
    constructor(key: Key, val: Units, split?: Split);
}
export declare class Block extends Unit {
    items: (KeyVal | Comma)[];
    begin: TkRange;
    end: TkRange;
    constructor(begin: TkRange, end: TkRange, items: (KeyVal | Comma)[]);
}
export declare class Arr extends Unit {
    items: Units[];
    begin: TkRange;
    end: TkRange;
    constructor(begin: TkRange, end: TkRange, items: Units[]);
}
export declare class Docs extends Unit {
    items: (Block | Arr | Comments)[];
    constructor(items: (Block | Arr | Comments)[]);
}
export declare type Comments = LineComment | BlockComment;
export declare type Asts = Block | Arr | Bool | Num | Str | Null;
export declare type Units = Asts | Comma | Comments;
