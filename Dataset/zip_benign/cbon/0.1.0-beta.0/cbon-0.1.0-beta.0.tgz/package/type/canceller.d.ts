export declare type Canceller = () => boolean;
export declare type AsyncCanceller = () => Promise<boolean>;
export declare function AlwaysFalse(): false;
