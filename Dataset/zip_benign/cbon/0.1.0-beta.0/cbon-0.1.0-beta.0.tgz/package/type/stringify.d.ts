export interface ToCbon {
    tocbon(): string;
}
export declare type StringifyFormat = {
    string?: '"' | "'";
    splitter?: null | ':' | '=';
    comma?: boolean;
    comma_when_only_one_line?: boolean;
    split_before_brackets?: boolean;
    strict_string?: boolean;
    strict_key?: boolean;
    tab: ' ' | '\t';
    tab_count: number;
};
export declare type FullStringifyFormat = Required<StringifyFormat>;
export declare const DefaultFormat: {
    readonly string: "'";
    readonly splitter: null;
    readonly comma: false;
    readonly comma_when_only_one_line: true;
    readonly split_before_brackets: false;
    readonly strict_string: false;
    readonly strict_key: false;
    readonly tab: " ";
    readonly tab_count: 2;
};
export declare const MinFormat: {
    readonly comma_when_only_one_line: false;
    readonly string: "'";
    readonly splitter: null;
    readonly comma: false;
    readonly split_before_brackets: false;
    readonly strict_string: false;
    readonly strict_key: false;
    readonly tab: " ";
    readonly tab_count: 2;
};
export declare const JsonFormat: {
    readonly string: "\"";
    readonly splitter: ":";
    readonly comma: true;
    readonly split_before_brackets: true;
    readonly strict_string: true;
    readonly strict_key: true;
    readonly comma_when_only_one_line: true;
    readonly tab: " ";
    readonly tab_count: 2;
};
export declare type StringifyStyle = 'min' | null | 'beautify';
export declare function styleFormat(style: 'min'): typeof MinFormat;
export declare function styleFormat(style?: null | 'beautify'): typeof DefaultFormat;
export declare function styleFormat(style?: StringifyStyle): FullStringifyFormat;
export declare function stringify(val: any, config?: {
    style?: StringifyStyle;
    format?: StringifyFormat;
}): string | undefined;
