import { Errors, TailParams } from "./type";
import { TkPos, TkRange } from "./pos";
export declare const ReDo: unique symbol;
export declare type BaseParserUnit<Char> = (c: Char) => void | typeof ReDo | ParserUnit<Char>;
export declare type ParserUnitFn<Char> = (ctx: Context<Char>, ...a: any[]) => BaseParserUnit<Char>;
export interface ParserUnit<Char> {
    fn: BaseParserUnit<Char>;
    ignoreFirst: boolean;
}
export declare class WhenError extends Error {
    err: Errors;
    constructor(err: Errors);
}
export declare class State<Char> {
    count: number;
    char: number;
    line: number;
    states: BaseParserUnit<Char>[];
    lines: number[];
    errors: Errors[];
    show_all_err: boolean;
    queue: (() => void)[];
    constructor(show_all_err: boolean);
    push(unit: BaseParserUnit<Char>): void;
    pop(): BaseParserUnit<Char> | undefined;
    call(c: Char): void;
    get pos(): TkPos;
    get lastPos(): TkPos;
}
export declare class Context<Char> {
    state: State<Char>;
    last_flag?: TkPos;
    constructor(state: State<Char>);
    end(): void;
    call<F extends ParserUnitFn<Char>>(f: F, ...p: TailParams<F>): ParserUnit<Char>;
    callNoFirst<F extends ParserUnitFn<Char>>(f: F, ...p: TailParams<F>): ParserUnit<Char>;
    flag(): void;
    range(last?: boolean): TkRange;
    error(range: TkRange, msg: string): void;
}
