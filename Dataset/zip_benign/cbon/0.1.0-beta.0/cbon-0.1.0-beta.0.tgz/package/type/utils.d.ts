import { Errors } from "./type";
export declare function isVoid(v: any): v is void;
export declare function getErrorsMsgs(errors: Errors[]): string[];
export declare function showErr(errmsg: string[]): never;
/**  == queueMicrotask */
export declare function next_micro_tick(): Promise<void>;
/** == setTimeout */
export declare function next_macro_tick(): Promise<void>;
export declare function delay(timeout?: number): Promise<void>;
export interface MaybeAsyncIterable<T> {
    [Symbol.iterator]?: () => Iterator<T>;
    [Symbol.asyncIterator]?: () => AsyncIterator<T>;
}
export declare function getIterator<T>(iter: AsyncIterable<T>): AsyncIterator<T>;
export declare function getIterator<T>(iter: Iterable<T>): Iterator<T>;
export declare function getIterator<T>(iter: MaybeAsyncIterable<T>): (AsyncIterator<T>) | (Iterator<T>);
