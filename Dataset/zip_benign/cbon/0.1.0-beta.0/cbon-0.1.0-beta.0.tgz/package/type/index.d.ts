import { CbonObj, CbonArr } from "./type";
import { Canceller, AsyncCanceller } from "./canceller";
export * from './stringify';
export declare function parser(code: string, config: {
    alwaysDocs?: false;
    show_all_err?: boolean;
    async: true;
    cancel?: Canceller | AsyncCanceller;
}): Promise<CbonObj | CbonArr>;
export declare function parser(code: string, config: {
    alwaysDocs: true;
    show_all_err?: boolean;
    async: true;
    cancel?: Canceller | AsyncCanceller;
}): Promise<(CbonObj | CbonArr)[]>;
export declare function parser(code: string, config?: {
    alwaysDocs?: false;
    show_all_err?: boolean;
    async?: false;
    cancel?: Canceller;
}): CbonObj | CbonArr;
export declare function parser(code: string, config: {
    alwaysDocs: true;
    show_all_err?: boolean;
    async?: false;
    cancel?: Canceller;
}): (CbonObj | CbonArr)[];
export declare function parser(code: string, config?: {
    alwaysDocs?: boolean;
    show_all_err?: boolean;
    async?: boolean;
    cancel?: Canceller | AsyncCanceller;
}): (CbonObj | CbonArr) | (CbonObj | CbonArr)[] | Promise<CbonObj | CbonArr> | Promise<(CbonObj | CbonArr)[]>;
