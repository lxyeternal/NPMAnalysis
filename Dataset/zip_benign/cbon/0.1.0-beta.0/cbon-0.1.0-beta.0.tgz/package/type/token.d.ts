import { TkRange } from "./pos";
export declare abstract class Token {
}
export declare class TEOF extends Token {
    range: TkRange;
    constructor(range: TkRange);
}
export declare abstract class TComment extends Token {
}
export declare class TLineComment extends TComment {
    items: (string | TComments)[];
    range: TkRange;
    constructor(range: TkRange, items: (string | TComments)[]);
}
export declare class TBlockComment extends TComment {
    items: (string | TComments)[];
    range: TkRange;
    constructor(range: TkRange, items: (string | TComments)[]);
}
export declare class TWord extends Token {
    val: string;
    range: TkRange;
    constructor(range: TkRange, val: string);
}
export declare class TStr extends Token {
    val: string;
    col: '"' | "'";
    range: TkRange;
    constructor(range: TkRange, val: string, col: '"' | "'");
}
export declare abstract class TSymbol<S extends ',' | ':' | '=' | '[' | ']' | '{' | '}'> extends Token {
    val: S;
    range: TkRange;
    constructor(range: TkRange, val: S);
}
export declare class TSComma extends TSymbol<','> {
}
export declare class TSSplit extends TSymbol<':' | '='> {
}
export declare class TSArrStart extends TSymbol<'['> {
}
export declare class TSArrEnd extends TSymbol<']'> {
}
export declare class TSObjStart extends TSymbol<'{'> {
}
export declare class TSObjEnd extends TSymbol<'}'> {
}
export declare function makeTSymbol(range: TkRange, val: ','): TSComma;
export declare function makeTSymbol(range: TkRange, val: ':' | '='): TSSplit;
export declare function makeTSymbol(range: TkRange, val: '['): TSArrStart;
export declare function makeTSymbol(range: TkRange, val: ']'): TSArrEnd;
export declare function makeTSymbol(range: TkRange, val: '{'): TSObjStart;
export declare function makeTSymbol(range: TkRange, val: '{'): TSObjEnd;
export declare function makeTSymbol(range: TkRange, val: ',' | ':' | '=' | '[' | ']' | '{' | '}'): TSComma | TSSplit | TSArrStart | TSArrEnd | TSObjStart | TSObjEnd;
export declare type TComments = TLineComment | TBlockComment;
export declare type Tokens = TEOF | TComments | TWord | TStr | TSComma | TSSplit | TSArrStart | TSArrEnd | TSObjStart | TSObjEnd;
