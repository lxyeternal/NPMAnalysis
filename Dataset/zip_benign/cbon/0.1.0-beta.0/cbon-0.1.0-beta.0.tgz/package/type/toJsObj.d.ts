import { Docs } from "./ast";
import { CbonObj, CbonArr } from "./type";
export declare function toJsObj(doc: Docs, config: {
    async: true;
}): Promise<(CbonObj | CbonArr)[]>;
export declare function toJsObj(doc: Docs, config?: {
    async?: false;
}): (CbonObj | CbonArr)[];
export declare function toJsObj(doc: Docs, config?: {
    async?: boolean;
}): Promise<(CbonObj | CbonArr)[]> | (CbonObj | CbonArr)[];
