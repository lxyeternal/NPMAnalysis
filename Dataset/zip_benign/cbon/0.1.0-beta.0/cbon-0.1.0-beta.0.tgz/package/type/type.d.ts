import { TkRange } from "./pos";
export declare type CbonVal = number | string | boolean | null | CbonObj | CbonArr;
export declare type CbonObj = {
    [key: string]: CbonVal;
};
export declare type CbonArr = CbonVal[];
export declare type TailParams<T extends (...a: any[]) => any> = T extends (_: any, ...a: infer L) => any ? L : never;
export declare type Errors = {
    range: TkRange;
    msg: string;
};
