# react背景彩带
## 使用方法
```
npm install pm-ribbon -S
```
### 引入pm-ribbon
```
import PmRibbon from 'pm-ribbon'
<PmRibbon clickChangeDom={document} />
```
### 支持传入以下属性
|属性|说明|类型|默认值|支持版本|
|:--|:--|:--|:--|:--|
|ribbonWidth|彩带宽度|number|100|>=2.0.0|
|globalAlpha|彩带透明度|number|0.5|>=2.0.0|
|zIndex|图层的z-index|number|0|>=2.0.0|
|canClickChange|图层点击重绘彩带|boolean|false|>=2.0.0|
|clickChangeDom|点击其他区域重绘彩带|DOM节点|null|>=2.0.0|
|drawSite|起始两点位置|number[y1, y2]|图层中点上下半个带宽|>=2.0.0|

----

## 更新说明：
### 2.4.0
1. 使用ts重构
### 3.0.0
1. 修改打包配置，编译后的文件不在包含react源码