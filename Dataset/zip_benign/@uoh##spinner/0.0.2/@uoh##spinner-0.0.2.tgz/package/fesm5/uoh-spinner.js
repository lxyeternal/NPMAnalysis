import { Injectable, NgModule, Component, Input, defineInjectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CommonModule } from '@angular/common';

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var SpinnerService = /** @class */ (function () {
    function SpinnerService() {
        this.loading = new BehaviorSubject(false);
    }
    /**
     * @return {?}
     */
    SpinnerService.prototype.show = /**
     * @return {?}
     */
    function () {
        this.loading.next(true);
    };
    /**
     * @return {?}
     */
    SpinnerService.prototype.hide = /**
     * @return {?}
     */
    function () {
        this.loading.next(false);
    };
    SpinnerService.decorators = [
        { type: Injectable, args: [{
                    providedIn: 'root'
                },] },
    ];
    /** @nocollapse */
    SpinnerService.ctorParameters = function () { return []; };
    /** @nocollapse */ SpinnerService.ngInjectableDef = defineInjectable({ factory: function SpinnerService_Factory() { return new SpinnerService(); }, token: SpinnerService, providedIn: "root" });
    return SpinnerService;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var SpinnerComponent = /** @class */ (function () {
    function SpinnerComponent(_loader) {
        this._loader = _loader;
        this.duration = 2000;
        this.fps = 60;
        this.minStrokeWidth = 15;
        this.maxStrokeWidth = 50;
        this.circle = { stop1: 0.35, stop2: 0.85 };
        this.path = 'M 0,101 120,0 180,50.5 240,0 300,50.5 360,0 360,59 335.05078,80 360,101 360,160 240,59 215.04883,80 240,101 240,160' +
            ' 180,109.5 120,160 120,101 144.95117,80 120,59 0,160 0,101 Z';
        this.visible = false;
        this._svgSize = { width: 360, height: 160 };
        this._defaultSize = { width: 180, height: 80 };
    }
    /**
     * @return {?}
     */
    SpinnerComponent.prototype.ngOnInit = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this.size = this.size ? this.calcSize(this.size, this._svgSize) : this._defaultSize;
        this.viewBox = "0 0 " + (this._svgSize.width + this.maxStrokeWidth) + " " + (this._svgSize.height + this.maxStrokeWidth);
        var /** @type {?} */ pos = this.maxStrokeWidth / 2;
        this.groupTransform = "translate(" + pos + ", " + pos + ")";
        this._frameInterval = 1000 / this.fps;
        this._points = this.parsePoints(this.path);
        this._perimeter = this.calcPerimeter(this._points);
        this._strokeInc = this.getStrokeIncrement(this.duration, this.circle, this.minStrokeWidth, this.maxStrokeWidth);
        this._loading$ = this._loader.loading.subscribe(function (loading) {
            if (loading) {
                _this.startAnimation();
            }
            else {
                _this.stopAnimation();
            }
        });
    };
    /**
     * @return {?}
     */
    SpinnerComponent.prototype.ngOnDestroy = /**
     * @return {?}
     */
    function () {
        if (this._loading$) {
            this._loading$.unsubscribe();
        }
    };
    /**
     * @return {?}
     */
    SpinnerComponent.prototype.startAnimation = /**
     * @return {?}
     */
    function () {
        var _this = this;
        this.resetParams();
        this._requestID = window.requestAnimationFrame(function (time) {
            var /** @type {?} */ startTime = _this.correctTime(time);
            _this.draw(startTime, startTime);
        });
        this.visible = true;
    };
    /**
     * @return {?}
     */
    SpinnerComponent.prototype.stopAnimation = /**
     * @return {?}
     */
    function () {
        this.visible = false;
        this.cancelRequestID();
    };
    /**
     * @return {?}
     */
    SpinnerComponent.prototype.resetParams = /**
     * @return {?}
     */
    function () {
        this.strokeWidth = this.maxStrokeWidth;
    };
    /**
     * @return {?}
     */
    SpinnerComponent.prototype.cancelRequestID = /**
     * @return {?}
     */
    function () {
        if (this._requestID !== undefined) {
            window.cancelAnimationFrame(this._requestID);
        }
    };
    /**
     * @param {?} time
     * @param {?} startTime
     * @return {?}
     */
    SpinnerComponent.prototype.draw = /**
     * @param {?} time
     * @param {?} startTime
     * @return {?}
     */
    function (time, startTime) {
        var _this = this;
        var /** @type {?} */ timeElapsed = time - startTime;
        var /** @type {?} */ percent = timeElapsed / this.duration;
        if (percent >= 1) {
            startTime = time;
            percent = 1;
        }
        if (percent >= this.circle.stop2) {
            this.strokeWidth =
                this.minStrokeWidth + (timeElapsed - this.duration * this.circle.stop2) * this._strokeInc.stop2;
        }
        else if (percent <= this.circle.stop1) {
            this.strokeWidth = this.maxStrokeWidth - timeElapsed * this._strokeInc.stop1;
        }
        var /** @type {?} */ loader = this.easeInOut(percent) * this._perimeter;
        this.dashArray = loader + "," + this._perimeter;
        this.dashOffset = (loader - 1) * -1;
        this._requestID = window.requestAnimationFrame(function (nextTime) {
            _this.draw(_this.correctTime(nextTime), startTime);
        });
    };
    /**
     * @param {?} time
     * @return {?}
     */
    SpinnerComponent.prototype.correctTime = /**
     * @param {?} time
     * @return {?}
     */
    function (time) {
        return time - (time % this._frameInterval);
    };
    /**
     * @param {?} currSize
     * @param {?} origSize
     * @return {?}
     */
    SpinnerComponent.prototype.calcSize = /**
     * @param {?} currSize
     * @param {?} origSize
     * @return {?}
     */
    function (currSize, origSize) {
        if (currSize.width) {
            currSize.height = (origSize.width / currSize.width) * origSize.height;
        }
        else {
            currSize.width = (origSize.height / currSize.height) * origSize.width;
        }
        return currSize;
    };
    /**
     * @param {?} points
     * @return {?}
     */
    SpinnerComponent.prototype.calcPerimeter = /**
     * @param {?} points
     * @return {?}
     */
    function (points) {
        return points.reduce(function (accum, currPoint, currIndex) {
            var /** @type {?} */ nextIndex = currIndex + 1 >= points.length ? 0 : currIndex + 1;
            var /** @type {?} */ nextPoint = points[nextIndex];
            var /** @type {?} */ diffX = currPoint.x - nextPoint.x;
            var /** @type {?} */ diffY = currPoint.y - nextPoint.y;
            return accum + Math.sqrt(diffX * diffX + diffY * diffY);
        }, 0);
    };
    /**
     * @param {?} path
     * @return {?}
     */
    SpinnerComponent.prototype.parsePoints = /**
     * @param {?} path
     * @return {?}
     */
    function (path) {
        return path
            .replace(/M\s|\sZ/g, '')
            .split(' ')
            .map(function (point) {
            var /** @type {?} */ coords = point.split(',');
            return { x: +coords[0], y: +coords[1] };
        });
    };
    /**
     * @param {?} duration
     * @param {?} stops
     * @param {?} min
     * @param {?} max
     * @return {?}
     */
    SpinnerComponent.prototype.getStrokeIncrement = /**
     * @param {?} duration
     * @param {?} stops
     * @param {?} min
     * @param {?} max
     * @return {?}
     */
    function (duration, stops, min, max) {
        var /** @type {?} */ steps1 = duration * stops.stop1;
        var /** @type {?} */ steps2 = duration * (1 - stops.stop2);
        var /** @type {?} */ increment1 = (max - min) / steps1;
        var /** @type {?} */ increment2 = (max - min) / steps2;
        return {
            stop1: increment1,
            stop2: increment2
        };
    };
    /**
     * @param {?} time
     * @return {?}
     */
    SpinnerComponent.prototype.easeInOut = /**
     * @param {?} time
     * @return {?}
     */
    function (time) {
        var /** @type {?} */ timeSqr = time * time;
        return timeSqr / (2 * (timeSqr - time) + 1);
    };
    SpinnerComponent.decorators = [
        { type: Component, args: [{
                    selector: 'uoh-spinner',
                    template: "<div *ngIf=\"visible\" [style.width.px]=\"size.width\" [style.height.px]=\"size.height\" class=\"wrapper\">\n  <svg xmlns:svg=\"http://www.w3.org/2000/svg\" xmlns=\"http://www.w3.org/2000/svg\" [attr.viewBox]=\"viewBox\" id=\"logo\" version=\"1.1\">\n    <svg:g id=\"loaderGroup\" [attr.transform]=\"groupTransform\">\n      <svg:path [style.stroke-dasharray]=\"dashArray\" [style.stroke-dashoffset]=\"dashOffset\" [style.stroke-width]=\"strokeWidth\"\n        style=\"fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-opacity:1\"\n        [attr.d]=\"path\" transform=\"translate(0,0)\" id=\"loaderPath\" />\n      <svg:path [style.stroke-width]=\"minStrokeWidth\" style=\"fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-opacity:1\"\n        [attr.d]=\"path\" transform=\"translate(0,0)\" id=\"bgPath\" />\n      </g>\n  </svg>\n</div>",
                    styles: ["@-webkit-keyframes scaling{0%,100%{-webkit-transform:scale(1);transform:scale(1)}50%{-webkit-transform:scale(.95);transform:scale(.95)}}@keyframes scaling{0%,100%{-webkit-transform:scale(1);transform:scale(1)}50%{-webkit-transform:scale(.95);transform:scale(.95)}}.wrapper{border:none;position:fixed;z-index:1000;margin:auto;top:0;left:0;bottom:0;right:0}.wrapper:before{content:'';display:block;position:fixed;overflow:hidden;top:0;left:0;width:100vw;height:100vh;text-align:center;background-color:rgba(0,0,0,.3)}#logo{position:absolute;width:100%;height:100%;top:0;left:0;-webkit-animation-name:scaling;animation-name:scaling;-webkit-animation-iteration-count:infinite;animation-iteration-count:infinite;-webkit-animation-duration:2s;animation-duration:2s;-webkit-animation-timing-function:ease-in-out;animation-timing-function:ease-in-out}#loaderPath{stroke:#d51111}#bgPath{stroke:rgba(213,17,17,.1)}"]
                },] },
    ];
    /** @nocollapse */
    SpinnerComponent.ctorParameters = function () { return [
        { type: SpinnerService }
    ]; };
    SpinnerComponent.propDecorators = {
        size: [{ type: Input }],
        duration: [{ type: Input }],
        fps: [{ type: Input }],
        minStrokeWidth: [{ type: Input }],
        maxStrokeWidth: [{ type: Input }],
        circle: [{ type: Input }],
        path: [{ type: Input }]
    };
    return SpinnerComponent;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */
var SpinnerModule = /** @class */ (function () {
    function SpinnerModule() {
    }
    SpinnerModule.decorators = [
        { type: NgModule, args: [{
                    imports: [CommonModule],
                    declarations: [SpinnerComponent],
                    exports: [SpinnerComponent]
                },] },
    ];
    return SpinnerModule;
}());

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

/**
 * @fileoverview added by tsickle
 * @suppress {checkTypes} checked by tsc
 */

export { SpinnerService, SpinnerComponent, SpinnerModule };

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidW9oLXNwaW5uZXIuanMubWFwIiwic291cmNlcyI6WyJuZzovL0B1b2gvc3Bpbm5lci9saWIvc3Bpbm5lci5zZXJ2aWNlLnRzIiwibmc6Ly9AdW9oL3NwaW5uZXIvbGliL3NwaW5uZXIuY29tcG9uZW50LnRzIiwibmc6Ly9AdW9oL3NwaW5uZXIvbGliL3NwaW5uZXIubW9kdWxlLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IEluamVjdGFibGUgfSBmcm9tICdAYW5ndWxhci9jb3JlJztcblxuaW1wb3J0IHsgQmVoYXZpb3JTdWJqZWN0IH0gZnJvbSAncnhqcyc7XG5cbkBJbmplY3RhYmxlKHtcbiAgcHJvdmlkZWRJbjogJ3Jvb3QnXG59KVxuZXhwb3J0IGNsYXNzIFNwaW5uZXJTZXJ2aWNlIHtcbiAgbG9hZGluZyA9IG5ldyBCZWhhdmlvclN1YmplY3Q8Ym9vbGVhbj4oZmFsc2UpO1xuXG4gIGNvbnN0cnVjdG9yKCkge31cblxuICBzaG93KCk6IHZvaWQge1xuICAgIHRoaXMubG9hZGluZy5uZXh0KHRydWUpO1xuICB9XG5cbiAgaGlkZSgpOiB2b2lkIHtcbiAgICB0aGlzLmxvYWRpbmcubmV4dChmYWxzZSk7XG4gIH1cbn1cbiIsImltcG9ydCB7IENvbXBvbmVudCwgSW5wdXQsIE9uSW5pdCwgT25EZXN0cm95IH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IFN1YnNjcmlwdGlvbiB9IGZyb20gJ3J4anMnO1xuXG5pbXBvcnQgeyBTcGlubmVyU2VydmljZSB9IGZyb20gJy4vc3Bpbm5lci5zZXJ2aWNlJztcbmltcG9ydCB7IFBvaW50LCBTaXplLCBTdG9wcyB9IGZyb20gJy4vbW9kZWxzJztcblxuQENvbXBvbmVudCh7XG4gIHNlbGVjdG9yOiAndW9oLXNwaW5uZXInLFxuICB0ZW1wbGF0ZTogYDxkaXYgKm5nSWY9XCJ2aXNpYmxlXCIgW3N0eWxlLndpZHRoLnB4XT1cInNpemUud2lkdGhcIiBbc3R5bGUuaGVpZ2h0LnB4XT1cInNpemUuaGVpZ2h0XCIgY2xhc3M9XCJ3cmFwcGVyXCI+XG4gIDxzdmcgeG1sbnM6c3ZnPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgW2F0dHIudmlld0JveF09XCJ2aWV3Qm94XCIgaWQ9XCJsb2dvXCIgdmVyc2lvbj1cIjEuMVwiPlxuICAgIDxzdmc6ZyBpZD1cImxvYWRlckdyb3VwXCIgW2F0dHIudHJhbnNmb3JtXT1cImdyb3VwVHJhbnNmb3JtXCI+XG4gICAgICA8c3ZnOnBhdGggW3N0eWxlLnN0cm9rZS1kYXNoYXJyYXldPVwiZGFzaEFycmF5XCIgW3N0eWxlLnN0cm9rZS1kYXNob2Zmc2V0XT1cImRhc2hPZmZzZXRcIiBbc3R5bGUuc3Ryb2tlLXdpZHRoXT1cInN0cm9rZVdpZHRoXCJcbiAgICAgICAgc3R5bGU9XCJmaWxsOm5vbmU7ZmlsbC1ydWxlOmV2ZW5vZGQ7c3Ryb2tlLWxpbmVjYXA6cm91bmQ7c3Ryb2tlLWxpbmVqb2luOnJvdW5kO3N0cm9rZS1taXRlcmxpbWl0OjQ7c3Ryb2tlLW9wYWNpdHk6MVwiXG4gICAgICAgIFthdHRyLmRdPVwicGF0aFwiIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgwLDApXCIgaWQ9XCJsb2FkZXJQYXRoXCIgLz5cbiAgICAgIDxzdmc6cGF0aCBbc3R5bGUuc3Ryb2tlLXdpZHRoXT1cIm1pblN0cm9rZVdpZHRoXCIgc3R5bGU9XCJmaWxsOm5vbmU7ZmlsbC1ydWxlOmV2ZW5vZGQ7c3Ryb2tlLWxpbmVjYXA6cm91bmQ7c3Ryb2tlLWxpbmVqb2luOnJvdW5kO3N0cm9rZS1taXRlcmxpbWl0OjQ7c3Ryb2tlLW9wYWNpdHk6MVwiXG4gICAgICAgIFthdHRyLmRdPVwicGF0aFwiIHRyYW5zZm9ybT1cInRyYW5zbGF0ZSgwLDApXCIgaWQ9XCJiZ1BhdGhcIiAvPlxuICAgICAgPC9nPlxuICA8L3N2Zz5cbjwvZGl2PmAsXG4gIHN0eWxlczogW2BALXdlYmtpdC1rZXlmcmFtZXMgc2NhbGluZ3swJSwxMDAley13ZWJraXQtdHJhbnNmb3JtOnNjYWxlKDEpO3RyYW5zZm9ybTpzY2FsZSgxKX01MCV7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUoLjk1KTt0cmFuc2Zvcm06c2NhbGUoLjk1KX19QGtleWZyYW1lcyBzY2FsaW5nezAlLDEwMCV7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUoMSk7dHJhbnNmb3JtOnNjYWxlKDEpfTUwJXstd2Via2l0LXRyYW5zZm9ybTpzY2FsZSguOTUpO3RyYW5zZm9ybTpzY2FsZSguOTUpfX0ud3JhcHBlcntib3JkZXI6bm9uZTtwb3NpdGlvbjpmaXhlZDt6LWluZGV4OjEwMDA7bWFyZ2luOmF1dG87dG9wOjA7bGVmdDowO2JvdHRvbTowO3JpZ2h0OjB9LndyYXBwZXI6YmVmb3Jle2NvbnRlbnQ6Jyc7ZGlzcGxheTpibG9jaztwb3NpdGlvbjpmaXhlZDtvdmVyZmxvdzpoaWRkZW47dG9wOjA7bGVmdDowO3dpZHRoOjEwMHZ3O2hlaWdodDoxMDB2aDt0ZXh0LWFsaWduOmNlbnRlcjtiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMCwwLDAsLjMpfSNsb2dve3Bvc2l0aW9uOmFic29sdXRlO3dpZHRoOjEwMCU7aGVpZ2h0OjEwMCU7dG9wOjA7bGVmdDowOy13ZWJraXQtYW5pbWF0aW9uLW5hbWU6c2NhbGluZzthbmltYXRpb24tbmFtZTpzY2FsaW5nOy13ZWJraXQtYW5pbWF0aW9uLWl0ZXJhdGlvbi1jb3VudDppbmZpbml0ZTthbmltYXRpb24taXRlcmF0aW9uLWNvdW50OmluZmluaXRlOy13ZWJraXQtYW5pbWF0aW9uLWR1cmF0aW9uOjJzO2FuaW1hdGlvbi1kdXJhdGlvbjoyczstd2Via2l0LWFuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246ZWFzZS1pbi1vdXQ7YW5pbWF0aW9uLXRpbWluZy1mdW5jdGlvbjplYXNlLWluLW91dH0jbG9hZGVyUGF0aHtzdHJva2U6I2Q1MTExMX0jYmdQYXRoe3N0cm9rZTpyZ2JhKDIxMywxNywxNywuMSl9YF1cbn0pXG5leHBvcnQgY2xhc3MgU3Bpbm5lckNvbXBvbmVudCBpbXBsZW1lbnRzIE9uSW5pdCwgT25EZXN0cm95IHtcbiAgQElucHV0KCkgc2l6ZTogU2l6ZTtcbiAgQElucHV0KCkgZHVyYXRpb24gPSAyMDAwO1xuICBASW5wdXQoKSBmcHMgPSA2MDtcbiAgQElucHV0KCkgbWluU3Ryb2tlV2lkdGggPSAxNTtcbiAgQElucHV0KCkgbWF4U3Ryb2tlV2lkdGggPSA1MDtcbiAgQElucHV0KCkgY2lyY2xlOiBTdG9wcyA9IHsgc3RvcDE6IDAuMzUsIHN0b3AyOiAwLjg1IH07XG4gIEBJbnB1dCgpXG4gIHBhdGggPVxuICAgICdNIDAsMTAxIDEyMCwwIDE4MCw1MC41IDI0MCwwIDMwMCw1MC41IDM2MCwwIDM2MCw1OSAzMzUuMDUwNzgsODAgMzYwLDEwMSAzNjAsMTYwIDI0MCw1OSAyMTUuMDQ4ODMsODAgMjQwLDEwMSAyNDAsMTYwJyArXG4gICAgJyAxODAsMTA5LjUgMTIwLDE2MCAxMjAsMTAxIDE0NC45NTExNyw4MCAxMjAsNTkgMCwxNjAgMCwxMDEgWic7XG4gIGRhc2hBcnJheTogc3RyaW5nO1xuICBkYXNoT2Zmc2V0OiBudW1iZXI7XG4gIHN0cm9rZVdpZHRoOiBudW1iZXI7XG4gIHZpZXdCb3g6IHN0cmluZztcbiAgZ3JvdXBUcmFuc2Zvcm06IHN0cmluZztcbiAgdmlzaWJsZSA9IGZhbHNlO1xuICBwcml2YXRlIF9mcmFtZUludGVydmFsOiBudW1iZXI7XG4gIHByaXZhdGUgX3N0cm9rZUluYzogU3RvcHM7XG4gIHByaXZhdGUgX3BvaW50czogUG9pbnRbXTtcbiAgcHJpdmF0ZSBfcGVyaW1ldGVyOiBudW1iZXI7XG4gIHByaXZhdGUgX3N2Z1NpemU6IFNpemUgPSB7IHdpZHRoOiAzNjAsIGhlaWdodDogMTYwIH07XG4gIHByaXZhdGUgX2RlZmF1bHRTaXplOiBTaXplID0geyB3aWR0aDogMTgwLCBoZWlnaHQ6IDgwIH07XG4gIHByaXZhdGUgX3JlcXVlc3RJRDogbnVtYmVyO1xuICBwcml2YXRlIF9sb2FkaW5nJDogU3Vic2NyaXB0aW9uO1xuXG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgX2xvYWRlcjogU3Bpbm5lclNlcnZpY2UpIHt9XG5cbiAgbmdPbkluaXQoKTogdm9pZCB7XG4gICAgdGhpcy5zaXplID0gdGhpcy5zaXplID8gdGhpcy5jYWxjU2l6ZSh0aGlzLnNpemUsIHRoaXMuX3N2Z1NpemUpIDogdGhpcy5fZGVmYXVsdFNpemU7XG4gICAgdGhpcy52aWV3Qm94ID0gYDAgMCAke3RoaXMuX3N2Z1NpemUud2lkdGggKyB0aGlzLm1heFN0cm9rZVdpZHRofSAke3RoaXMuX3N2Z1NpemUuaGVpZ2h0ICsgdGhpcy5tYXhTdHJva2VXaWR0aH1gO1xuICAgIGNvbnN0IHBvcyA9IHRoaXMubWF4U3Ryb2tlV2lkdGggLyAyO1xuICAgIHRoaXMuZ3JvdXBUcmFuc2Zvcm0gPSBgdHJhbnNsYXRlKCR7cG9zfSwgJHtwb3N9KWA7XG4gICAgdGhpcy5fZnJhbWVJbnRlcnZhbCA9IDEwMDAgLyB0aGlzLmZwcztcbiAgICB0aGlzLl9wb2ludHMgPSB0aGlzLnBhcnNlUG9pbnRzKHRoaXMucGF0aCk7XG4gICAgdGhpcy5fcGVyaW1ldGVyID0gdGhpcy5jYWxjUGVyaW1ldGVyKHRoaXMuX3BvaW50cyk7XG4gICAgdGhpcy5fc3Ryb2tlSW5jID0gdGhpcy5nZXRTdHJva2VJbmNyZW1lbnQodGhpcy5kdXJhdGlvbiwgdGhpcy5jaXJjbGUsIHRoaXMubWluU3Ryb2tlV2lkdGgsIHRoaXMubWF4U3Ryb2tlV2lkdGgpO1xuICAgIHRoaXMuX2xvYWRpbmckID0gdGhpcy5fbG9hZGVyLmxvYWRpbmcuc3Vic2NyaWJlKGxvYWRpbmcgPT4ge1xuICAgICAgaWYgKGxvYWRpbmcpIHtcbiAgICAgICAgdGhpcy5zdGFydEFuaW1hdGlvbigpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5zdG9wQW5pbWF0aW9uKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cblxuICBuZ09uRGVzdHJveSgpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5fbG9hZGluZyQpIHtcbiAgICAgIHRoaXMuX2xvYWRpbmckLnVuc3Vic2NyaWJlKCk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBzdGFydEFuaW1hdGlvbigpOiB2b2lkIHtcbiAgICB0aGlzLnJlc2V0UGFyYW1zKCk7XG4gICAgdGhpcy5fcmVxdWVzdElEID0gd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSh0aW1lID0+IHtcbiAgICAgIGNvbnN0IHN0YXJ0VGltZSA9IHRoaXMuY29ycmVjdFRpbWUodGltZSk7XG4gICAgICB0aGlzLmRyYXcoc3RhcnRUaW1lLCBzdGFydFRpbWUpO1xuICAgIH0pO1xuICAgIHRoaXMudmlzaWJsZSA9IHRydWU7XG4gIH1cblxuICBwcml2YXRlIHN0b3BBbmltYXRpb24oKTogdm9pZCB7XG4gICAgdGhpcy52aXNpYmxlID0gZmFsc2U7XG4gICAgdGhpcy5jYW5jZWxSZXF1ZXN0SUQoKTtcbiAgfVxuXG4gIHByaXZhdGUgcmVzZXRQYXJhbXMoKTogdm9pZCB7XG4gICAgdGhpcy5zdHJva2VXaWR0aCA9IHRoaXMubWF4U3Ryb2tlV2lkdGg7XG4gIH1cblxuICBwcml2YXRlIGNhbmNlbFJlcXVlc3RJRCgpOiB2b2lkIHtcbiAgICBpZiAodGhpcy5fcmVxdWVzdElEICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHdpbmRvdy5jYW5jZWxBbmltYXRpb25GcmFtZSh0aGlzLl9yZXF1ZXN0SUQpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgZHJhdyh0aW1lOiBudW1iZXIsIHN0YXJ0VGltZTogbnVtYmVyKTogdm9pZCB7XG4gICAgY29uc3QgdGltZUVsYXBzZWQgPSB0aW1lIC0gc3RhcnRUaW1lO1xuICAgIGxldCBwZXJjZW50ID0gdGltZUVsYXBzZWQgLyB0aGlzLmR1cmF0aW9uO1xuXG4gICAgaWYgKHBlcmNlbnQgPj0gMSkge1xuICAgICAgc3RhcnRUaW1lID0gdGltZTtcbiAgICAgIHBlcmNlbnQgPSAxO1xuICAgIH1cblxuICAgIGlmIChwZXJjZW50ID49IHRoaXMuY2lyY2xlLnN0b3AyKSB7XG4gICAgICB0aGlzLnN0cm9rZVdpZHRoID1cbiAgICAgICAgdGhpcy5taW5TdHJva2VXaWR0aCArICh0aW1lRWxhcHNlZCAtIHRoaXMuZHVyYXRpb24gKiB0aGlzLmNpcmNsZS5zdG9wMikgKiB0aGlzLl9zdHJva2VJbmMuc3RvcDI7XG4gICAgfSBlbHNlIGlmIChwZXJjZW50IDw9IHRoaXMuY2lyY2xlLnN0b3AxKSB7XG4gICAgICB0aGlzLnN0cm9rZVdpZHRoID0gdGhpcy5tYXhTdHJva2VXaWR0aCAtIHRpbWVFbGFwc2VkICogdGhpcy5fc3Ryb2tlSW5jLnN0b3AxO1xuICAgIH1cblxuICAgIGNvbnN0IGxvYWRlciA9IHRoaXMuZWFzZUluT3V0KHBlcmNlbnQpICogdGhpcy5fcGVyaW1ldGVyO1xuICAgIHRoaXMuZGFzaEFycmF5ID0gYCR7bG9hZGVyfSwke3RoaXMuX3BlcmltZXRlcn1gO1xuICAgIHRoaXMuZGFzaE9mZnNldCA9IChsb2FkZXIgLSAxKSAqIC0xO1xuXG4gICAgdGhpcy5fcmVxdWVzdElEID0gd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZShuZXh0VGltZSA9PiB7XG4gICAgICB0aGlzLmRyYXcodGhpcy5jb3JyZWN0VGltZShuZXh0VGltZSksIHN0YXJ0VGltZSk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGNvcnJlY3RUaW1lKHRpbWU6IG51bWJlcik6IG51bWJlciB7XG4gICAgcmV0dXJuIHRpbWUgLSAodGltZSAlIHRoaXMuX2ZyYW1lSW50ZXJ2YWwpO1xuICB9XG5cbiAgcHJpdmF0ZSBjYWxjU2l6ZShjdXJyU2l6ZTogU2l6ZSwgb3JpZ1NpemU6IFNpemUpOiBTaXplIHtcbiAgICBpZiAoY3VyclNpemUud2lkdGgpIHtcbiAgICAgIGN1cnJTaXplLmhlaWdodCA9IChvcmlnU2l6ZS53aWR0aCAvIGN1cnJTaXplLndpZHRoKSAqIG9yaWdTaXplLmhlaWdodDtcbiAgICB9IGVsc2Uge1xuICAgICAgY3VyclNpemUud2lkdGggPSAob3JpZ1NpemUuaGVpZ2h0IC8gY3VyclNpemUuaGVpZ2h0KSAqIG9yaWdTaXplLndpZHRoO1xuICAgIH1cblxuICAgIHJldHVybiBjdXJyU2l6ZTtcbiAgfVxuXG4gIHByaXZhdGUgY2FsY1BlcmltZXRlcihwb2ludHM6IFBvaW50W10pOiBudW1iZXIge1xuICAgIHJldHVybiBwb2ludHMucmVkdWNlKChhY2N1bSwgY3VyclBvaW50LCBjdXJySW5kZXgpID0+IHtcbiAgICAgIGNvbnN0IG5leHRJbmRleCA9IGN1cnJJbmRleCArIDEgPj0gcG9pbnRzLmxlbmd0aCA/IDAgOiBjdXJySW5kZXggKyAxO1xuICAgICAgY29uc3QgbmV4dFBvaW50ID0gcG9pbnRzW25leHRJbmRleF07XG4gICAgICBjb25zdCBkaWZmWCA9IGN1cnJQb2ludC54IC0gbmV4dFBvaW50Lng7XG4gICAgICBjb25zdCBkaWZmWSA9IGN1cnJQb2ludC55IC0gbmV4dFBvaW50Lnk7XG4gICAgICByZXR1cm4gYWNjdW0gKyBNYXRoLnNxcnQoZGlmZlggKiBkaWZmWCArIGRpZmZZICogZGlmZlkpO1xuICAgIH0sIDApO1xuICB9XG5cbiAgcHJpdmF0ZSBwYXJzZVBvaW50cyhwYXRoOiBzdHJpbmcpOiBQb2ludFtdIHtcbiAgICByZXR1cm4gcGF0aFxuICAgICAgLnJlcGxhY2UoL01cXHN8XFxzWi9nLCAnJylcbiAgICAgIC5zcGxpdCgnICcpXG4gICAgICAubWFwKHBvaW50ID0+IHtcbiAgICAgICAgY29uc3QgY29vcmRzID0gcG9pbnQuc3BsaXQoJywnKTtcbiAgICAgICAgcmV0dXJuIHsgeDogK2Nvb3Jkc1swXSwgeTogK2Nvb3Jkc1sxXSB9O1xuICAgICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGdldFN0cm9rZUluY3JlbWVudChkdXJhdGlvbjogbnVtYmVyLCBzdG9wczogU3RvcHMsIG1pbjogbnVtYmVyLCBtYXg6IG51bWJlcik6IFN0b3BzIHtcbiAgICBjb25zdCBzdGVwczEgPSBkdXJhdGlvbiAqIHN0b3BzLnN0b3AxO1xuICAgIGNvbnN0IHN0ZXBzMiA9IGR1cmF0aW9uICogKDEgLSBzdG9wcy5zdG9wMik7XG4gICAgY29uc3QgaW5jcmVtZW50MSA9IChtYXggLSBtaW4pIC8gc3RlcHMxO1xuICAgIGNvbnN0IGluY3JlbWVudDIgPSAobWF4IC0gbWluKSAvIHN0ZXBzMjtcblxuICAgIHJldHVybiB7XG4gICAgICBzdG9wMTogaW5jcmVtZW50MSxcbiAgICAgIHN0b3AyOiBpbmNyZW1lbnQyXG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgZWFzZUluT3V0KHRpbWU6IG51bWJlcik6IG51bWJlciB7XG4gICAgY29uc3QgdGltZVNxciA9IHRpbWUgKiB0aW1lO1xuICAgIHJldHVybiB0aW1lU3FyIC8gKDIgKiAodGltZVNxciAtIHRpbWUpICsgMSk7XG4gIH1cbn1cbiIsImltcG9ydCB7IE5nTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb21tb25Nb2R1bGUgfSBmcm9tICdAYW5ndWxhci9jb21tb24nO1xuXG5pbXBvcnQgeyBTcGlubmVyQ29tcG9uZW50IH0gZnJvbSAnLi9zcGlubmVyLmNvbXBvbmVudCc7XG5cbkBOZ01vZHVsZSh7XG4gIGltcG9ydHM6IFtDb21tb25Nb2R1bGVdLFxuICBkZWNsYXJhdGlvbnM6IFtTcGlubmVyQ29tcG9uZW50XSxcbiAgZXhwb3J0czogW1NwaW5uZXJDb21wb25lbnRdXG59KVxuZXhwb3J0IGNsYXNzIFNwaW5uZXJNb2R1bGUge31cbiJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBO0lBVUU7dUJBRlUsSUFBSSxlQUFlLENBQVUsS0FBSyxDQUFDO0tBRTdCOzs7O0lBRWhCLDZCQUFJOzs7SUFBSjtRQUNFLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQ3pCOzs7O0lBRUQsNkJBQUk7OztJQUFKO1FBQ0UsSUFBSSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7S0FDMUI7O2dCQWRGLFVBQVUsU0FBQztvQkFDVixVQUFVLEVBQUUsTUFBTTtpQkFDbkI7Ozs7O3lCQU5EOzs7Ozs7O0FDQUE7SUFnREUsMEJBQW9CLE9BQXVCO1FBQXZCLFlBQU8sR0FBUCxPQUFPLENBQWdCO3dCQXhCdkIsSUFBSTttQkFDVCxFQUFFOzhCQUNTLEVBQUU7OEJBQ0YsRUFBRTtzQkFDSCxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRTtvQkFHbkQscUhBQXFIO1lBQ3JILDhEQUE4RDt1QkFNdEQsS0FBSzt3QkFLVSxFQUFFLEtBQUssRUFBRSxHQUFHLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRTs0QkFDdkIsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxFQUFFLEVBQUU7S0FJUjs7OztJQUUvQyxtQ0FBUTs7O0lBQVI7UUFBQSxpQkFnQkM7UUFmQyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBQ3BGLElBQUksQ0FBQyxPQUFPLEdBQUcsVUFBTyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsY0FBYyxXQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUUsQ0FBQztRQUNoSCxxQkFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUM7UUFDcEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxlQUFhLEdBQUcsVUFBSyxHQUFHLE1BQUcsQ0FBQztRQUNsRCxJQUFJLENBQUMsY0FBYyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDO1FBQ3RDLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDM0MsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNuRCxJQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDLGNBQWMsRUFBRSxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7UUFDaEgsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsVUFBQSxPQUFPO1lBQ3JELElBQUksT0FBTyxFQUFFO2dCQUNYLEtBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQzthQUN2QjtpQkFBTTtnQkFDTCxLQUFJLENBQUMsYUFBYSxFQUFFLENBQUM7YUFDdEI7U0FDRixDQUFDLENBQUM7S0FDSjs7OztJQUVELHNDQUFXOzs7SUFBWDtRQUNFLElBQUksSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNsQixJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDO1NBQzlCO0tBQ0Y7Ozs7SUFFTyx5Q0FBYzs7Ozs7UUFDcEIsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLHFCQUFxQixDQUFDLFVBQUEsSUFBSTtZQUNqRCxxQkFBTSxTQUFTLEdBQUcsS0FBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUN6QyxLQUFJLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztTQUNqQyxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQzs7Ozs7SUFHZCx3Q0FBYTs7OztRQUNuQixJQUFJLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztRQUNyQixJQUFJLENBQUMsZUFBZSxFQUFFLENBQUM7Ozs7O0lBR2pCLHNDQUFXOzs7O1FBQ2pCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQzs7Ozs7SUFHakMsMENBQWU7Ozs7UUFDckIsSUFBSSxJQUFJLENBQUMsVUFBVSxLQUFLLFNBQVMsRUFBRTtZQUNqQyxNQUFNLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDO1NBQzlDOzs7Ozs7O0lBR0ssK0JBQUk7Ozs7O2NBQUMsSUFBWSxFQUFFLFNBQWlCOztRQUMxQyxxQkFBTSxXQUFXLEdBQUcsSUFBSSxHQUFHLFNBQVMsQ0FBQztRQUNyQyxxQkFBSSxPQUFPLEdBQUcsV0FBVyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7UUFFMUMsSUFBSSxPQUFPLElBQUksQ0FBQyxFQUFFO1lBQ2hCLFNBQVMsR0FBRyxJQUFJLENBQUM7WUFDakIsT0FBTyxHQUFHLENBQUMsQ0FBQztTQUNiO1FBRUQsSUFBSSxPQUFPLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDaEMsSUFBSSxDQUFDLFdBQVc7Z0JBQ2QsSUFBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO1NBQ25HO2FBQU0sSUFBSSxPQUFPLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7WUFDdkMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsY0FBYyxHQUFHLFdBQVcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztTQUM5RTtRQUVELHFCQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUM7UUFDekQsSUFBSSxDQUFDLFNBQVMsR0FBTSxNQUFNLFNBQUksSUFBSSxDQUFDLFVBQVksQ0FBQztRQUNoRCxJQUFJLENBQUMsVUFBVSxHQUFHLENBQUMsTUFBTSxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQztRQUVwQyxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQyxVQUFBLFFBQVE7WUFDckQsS0FBSSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1NBQ2xELENBQUMsQ0FBQzs7Ozs7O0lBR0csc0NBQVc7Ozs7Y0FBQyxJQUFZO1FBQzlCLE9BQU8sSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7Ozs7Ozs7SUFHckMsbUNBQVE7Ozs7O2NBQUMsUUFBYyxFQUFFLFFBQWM7UUFDN0MsSUFBSSxRQUFRLENBQUMsS0FBSyxFQUFFO1lBQ2xCLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLElBQUksUUFBUSxDQUFDLE1BQU0sQ0FBQztTQUN2RTthQUFNO1lBQ0wsUUFBUSxDQUFDLEtBQUssR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLE1BQU0sSUFBSSxRQUFRLENBQUMsS0FBSyxDQUFDO1NBQ3ZFO1FBRUQsT0FBTyxRQUFRLENBQUM7Ozs7OztJQUdWLHdDQUFhOzs7O2NBQUMsTUFBZTtRQUNuQyxPQUFPLE1BQU0sQ0FBQyxNQUFNLENBQUMsVUFBQyxLQUFLLEVBQUUsU0FBUyxFQUFFLFNBQVM7WUFDL0MscUJBQU0sU0FBUyxHQUFHLFNBQVMsR0FBRyxDQUFDLElBQUksTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsU0FBUyxHQUFHLENBQUMsQ0FBQztZQUNyRSxxQkFBTSxTQUFTLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBQ3BDLHFCQUFNLEtBQUssR0FBRyxTQUFTLENBQUMsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUM7WUFDeEMscUJBQU0sS0FBSyxHQUFHLFNBQVMsQ0FBQyxDQUFDLEdBQUcsU0FBUyxDQUFDLENBQUMsQ0FBQztZQUN4QyxPQUFPLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO1NBQ3pELEVBQUUsQ0FBQyxDQUFDLENBQUM7Ozs7OztJQUdBLHNDQUFXOzs7O2NBQUMsSUFBWTtRQUM5QixPQUFPLElBQUk7YUFDUixPQUFPLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQzthQUN2QixLQUFLLENBQUMsR0FBRyxDQUFDO2FBQ1YsR0FBRyxDQUFDLFVBQUEsS0FBSztZQUNSLHFCQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ2hDLE9BQU8sRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7U0FDekMsQ0FBQyxDQUFDOzs7Ozs7Ozs7SUFHQyw2Q0FBa0I7Ozs7Ozs7Y0FBQyxRQUFnQixFQUFFLEtBQVksRUFBRSxHQUFXLEVBQUUsR0FBVztRQUNqRixxQkFBTSxNQUFNLEdBQUcsUUFBUSxHQUFHLEtBQUssQ0FBQyxLQUFLLENBQUM7UUFDdEMscUJBQU0sTUFBTSxHQUFHLFFBQVEsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzVDLHFCQUFNLFVBQVUsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLElBQUksTUFBTSxDQUFDO1FBQ3hDLHFCQUFNLFVBQVUsR0FBRyxDQUFDLEdBQUcsR0FBRyxHQUFHLElBQUksTUFBTSxDQUFDO1FBRXhDLE9BQU87WUFDTCxLQUFLLEVBQUUsVUFBVTtZQUNqQixLQUFLLEVBQUUsVUFBVTtTQUNsQixDQUFDOzs7Ozs7SUFHSSxvQ0FBUzs7OztjQUFDLElBQVk7UUFDNUIscUJBQU0sT0FBTyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7UUFDNUIsT0FBTyxPQUFPLElBQUksQ0FBQyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQzs7O2dCQXBLL0MsU0FBUyxTQUFDO29CQUNULFFBQVEsRUFBRSxhQUFhO29CQUN2QixRQUFRLEVBQUUsdTZCQVVMO29CQUNMLE1BQU0sRUFBRSxDQUFDLDA0QkFBMDRCLENBQUM7aUJBQ3I1Qjs7OztnQkFqQlEsY0FBYzs7O3VCQW1CcEIsS0FBSzsyQkFDTCxLQUFLO3NCQUNMLEtBQUs7aUNBQ0wsS0FBSztpQ0FDTCxLQUFLO3lCQUNMLEtBQUs7dUJBQ0wsS0FBSzs7MkJBN0JSOzs7Ozs7O0FDQUE7Ozs7Z0JBS0MsUUFBUSxTQUFDO29CQUNSLE9BQU8sRUFBRSxDQUFDLFlBQVksQ0FBQztvQkFDdkIsWUFBWSxFQUFFLENBQUMsZ0JBQWdCLENBQUM7b0JBQ2hDLE9BQU8sRUFBRSxDQUFDLGdCQUFnQixDQUFDO2lCQUM1Qjs7d0JBVEQ7Ozs7Ozs7Ozs7Ozs7OzsifQ==