(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('@angular/core'), require('rxjs'), require('@angular/common')) :
    typeof define === 'function' && define.amd ? define('@uoh/spinner', ['exports', '@angular/core', 'rxjs', '@angular/common'], factory) :
    (factory((global.uoh = global.uoh || {}, global.uoh.spinner = {}),global.ng.core,global.rxjs,global.ng.common));
}(this, (function (exports,i0,rxjs,common) { 'use strict';

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var SpinnerService = (function () {
        function SpinnerService() {
            this.loading = new rxjs.BehaviorSubject(false);
        }
        /**
         * @return {?}
         */
        SpinnerService.prototype.show = /**
         * @return {?}
         */
            function () {
                this.loading.next(true);
            };
        /**
         * @return {?}
         */
        SpinnerService.prototype.hide = /**
         * @return {?}
         */
            function () {
                this.loading.next(false);
            };
        SpinnerService.decorators = [
            { type: i0.Injectable, args: [{
                        providedIn: 'root'
                    },] },
        ];
        /** @nocollapse */
        SpinnerService.ctorParameters = function () { return []; };
        /** @nocollapse */ SpinnerService.ngInjectableDef = i0.defineInjectable({ factory: function SpinnerService_Factory() { return new SpinnerService(); }, token: SpinnerService, providedIn: "root" });
        return SpinnerService;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var SpinnerComponent = (function () {
        function SpinnerComponent(_loader) {
            this._loader = _loader;
            this.duration = 2000;
            this.fps = 60;
            this.minStrokeWidth = 15;
            this.maxStrokeWidth = 50;
            this.circle = { stop1: 0.35, stop2: 0.85 };
            this.path = 'M 0,101 120,0 180,50.5 240,0 300,50.5 360,0 360,59 335.05078,80 360,101 360,160 240,59 215.04883,80 240,101 240,160' +
                ' 180,109.5 120,160 120,101 144.95117,80 120,59 0,160 0,101 Z';
            this.visible = false;
            this._svgSize = { width: 360, height: 160 };
            this._defaultSize = { width: 180, height: 80 };
        }
        /**
         * @return {?}
         */
        SpinnerComponent.prototype.ngOnInit = /**
         * @return {?}
         */
            function () {
                var _this = this;
                this.size = this.size ? this.calcSize(this.size, this._svgSize) : this._defaultSize;
                this.viewBox = "0 0 " + (this._svgSize.width + this.maxStrokeWidth) + " " + (this._svgSize.height + this.maxStrokeWidth);
                var /** @type {?} */ pos = this.maxStrokeWidth / 2;
                this.groupTransform = "translate(" + pos + ", " + pos + ")";
                this._frameInterval = 1000 / this.fps;
                this._points = this.parsePoints(this.path);
                this._perimeter = this.calcPerimeter(this._points);
                this._strokeInc = this.getStrokeIncrement(this.duration, this.circle, this.minStrokeWidth, this.maxStrokeWidth);
                this._loading$ = this._loader.loading.subscribe(function (loading) {
                    if (loading) {
                        _this.startAnimation();
                    }
                    else {
                        _this.stopAnimation();
                    }
                });
            };
        /**
         * @return {?}
         */
        SpinnerComponent.prototype.ngOnDestroy = /**
         * @return {?}
         */
            function () {
                if (this._loading$) {
                    this._loading$.unsubscribe();
                }
            };
        /**
         * @return {?}
         */
        SpinnerComponent.prototype.startAnimation = /**
         * @return {?}
         */
            function () {
                var _this = this;
                this.resetParams();
                this._requestID = window.requestAnimationFrame(function (time) {
                    var /** @type {?} */ startTime = _this.correctTime(time);
                    _this.draw(startTime, startTime);
                });
                this.visible = true;
            };
        /**
         * @return {?}
         */
        SpinnerComponent.prototype.stopAnimation = /**
         * @return {?}
         */
            function () {
                this.visible = false;
                this.cancelRequestID();
            };
        /**
         * @return {?}
         */
        SpinnerComponent.prototype.resetParams = /**
         * @return {?}
         */
            function () {
                this.strokeWidth = this.maxStrokeWidth;
            };
        /**
         * @return {?}
         */
        SpinnerComponent.prototype.cancelRequestID = /**
         * @return {?}
         */
            function () {
                if (this._requestID !== undefined) {
                    window.cancelAnimationFrame(this._requestID);
                }
            };
        /**
         * @param {?} time
         * @param {?} startTime
         * @return {?}
         */
        SpinnerComponent.prototype.draw = /**
         * @param {?} time
         * @param {?} startTime
         * @return {?}
         */
            function (time, startTime) {
                var _this = this;
                var /** @type {?} */ timeElapsed = time - startTime;
                var /** @type {?} */ percent = timeElapsed / this.duration;
                if (percent >= 1) {
                    startTime = time;
                    percent = 1;
                }
                if (percent >= this.circle.stop2) {
                    this.strokeWidth =
                        this.minStrokeWidth + (timeElapsed - this.duration * this.circle.stop2) * this._strokeInc.stop2;
                }
                else if (percent <= this.circle.stop1) {
                    this.strokeWidth = this.maxStrokeWidth - timeElapsed * this._strokeInc.stop1;
                }
                var /** @type {?} */ loader = this.easeInOut(percent) * this._perimeter;
                this.dashArray = loader + "," + this._perimeter;
                this.dashOffset = (loader - 1) * -1;
                this._requestID = window.requestAnimationFrame(function (nextTime) {
                    _this.draw(_this.correctTime(nextTime), startTime);
                });
            };
        /**
         * @param {?} time
         * @return {?}
         */
        SpinnerComponent.prototype.correctTime = /**
         * @param {?} time
         * @return {?}
         */
            function (time) {
                return time - (time % this._frameInterval);
            };
        /**
         * @param {?} currSize
         * @param {?} origSize
         * @return {?}
         */
        SpinnerComponent.prototype.calcSize = /**
         * @param {?} currSize
         * @param {?} origSize
         * @return {?}
         */
            function (currSize, origSize) {
                if (currSize.width) {
                    currSize.height = (origSize.width / currSize.width) * origSize.height;
                }
                else {
                    currSize.width = (origSize.height / currSize.height) * origSize.width;
                }
                return currSize;
            };
        /**
         * @param {?} points
         * @return {?}
         */
        SpinnerComponent.prototype.calcPerimeter = /**
         * @param {?} points
         * @return {?}
         */
            function (points) {
                return points.reduce(function (accum, currPoint, currIndex) {
                    var /** @type {?} */ nextIndex = currIndex + 1 >= points.length ? 0 : currIndex + 1;
                    var /** @type {?} */ nextPoint = points[nextIndex];
                    var /** @type {?} */ diffX = currPoint.x - nextPoint.x;
                    var /** @type {?} */ diffY = currPoint.y - nextPoint.y;
                    return accum + Math.sqrt(diffX * diffX + diffY * diffY);
                }, 0);
            };
        /**
         * @param {?} path
         * @return {?}
         */
        SpinnerComponent.prototype.parsePoints = /**
         * @param {?} path
         * @return {?}
         */
            function (path) {
                return path
                    .replace(/M\s|\sZ/g, '')
                    .split(' ')
                    .map(function (point) {
                    var /** @type {?} */ coords = point.split(',');
                    return { x: +coords[0], y: +coords[1] };
                });
            };
        /**
         * @param {?} duration
         * @param {?} stops
         * @param {?} min
         * @param {?} max
         * @return {?}
         */
        SpinnerComponent.prototype.getStrokeIncrement = /**
         * @param {?} duration
         * @param {?} stops
         * @param {?} min
         * @param {?} max
         * @return {?}
         */
            function (duration, stops, min, max) {
                var /** @type {?} */ steps1 = duration * stops.stop1;
                var /** @type {?} */ steps2 = duration * (1 - stops.stop2);
                var /** @type {?} */ increment1 = (max - min) / steps1;
                var /** @type {?} */ increment2 = (max - min) / steps2;
                return {
                    stop1: increment1,
                    stop2: increment2
                };
            };
        /**
         * @param {?} time
         * @return {?}
         */
        SpinnerComponent.prototype.easeInOut = /**
         * @param {?} time
         * @return {?}
         */
            function (time) {
                var /** @type {?} */ timeSqr = time * time;
                return timeSqr / (2 * (timeSqr - time) + 1);
            };
        SpinnerComponent.decorators = [
            { type: i0.Component, args: [{
                        selector: 'uoh-spinner',
                        template: "<div *ngIf=\"visible\" [style.width.px]=\"size.width\" [style.height.px]=\"size.height\" class=\"wrapper\">\n  <svg xmlns:svg=\"http://www.w3.org/2000/svg\" xmlns=\"http://www.w3.org/2000/svg\" [attr.viewBox]=\"viewBox\" id=\"logo\" version=\"1.1\">\n    <svg:g id=\"loaderGroup\" [attr.transform]=\"groupTransform\">\n      <svg:path [style.stroke-dasharray]=\"dashArray\" [style.stroke-dashoffset]=\"dashOffset\" [style.stroke-width]=\"strokeWidth\"\n        style=\"fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-opacity:1\"\n        [attr.d]=\"path\" transform=\"translate(0,0)\" id=\"loaderPath\" />\n      <svg:path [style.stroke-width]=\"minStrokeWidth\" style=\"fill:none;fill-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;stroke-miterlimit:4;stroke-opacity:1\"\n        [attr.d]=\"path\" transform=\"translate(0,0)\" id=\"bgPath\" />\n      </g>\n  </svg>\n</div>",
                        styles: ["@-webkit-keyframes scaling{0%,100%{-webkit-transform:scale(1);transform:scale(1)}50%{-webkit-transform:scale(.95);transform:scale(.95)}}@keyframes scaling{0%,100%{-webkit-transform:scale(1);transform:scale(1)}50%{-webkit-transform:scale(.95);transform:scale(.95)}}.wrapper{border:none;position:fixed;z-index:1000;margin:auto;top:0;left:0;bottom:0;right:0}.wrapper:before{content:'';display:block;position:fixed;overflow:hidden;top:0;left:0;width:100vw;height:100vh;text-align:center;background-color:rgba(0,0,0,.3)}#logo{position:absolute;width:100%;height:100%;top:0;left:0;-webkit-animation-name:scaling;animation-name:scaling;-webkit-animation-iteration-count:infinite;animation-iteration-count:infinite;-webkit-animation-duration:2s;animation-duration:2s;-webkit-animation-timing-function:ease-in-out;animation-timing-function:ease-in-out}#loaderPath{stroke:#d51111}#bgPath{stroke:rgba(213,17,17,.1)}"]
                    },] },
        ];
        /** @nocollapse */
        SpinnerComponent.ctorParameters = function () {
            return [
                { type: SpinnerService }
            ];
        };
        SpinnerComponent.propDecorators = {
            size: [{ type: i0.Input }],
            duration: [{ type: i0.Input }],
            fps: [{ type: i0.Input }],
            minStrokeWidth: [{ type: i0.Input }],
            maxStrokeWidth: [{ type: i0.Input }],
            circle: [{ type: i0.Input }],
            path: [{ type: i0.Input }]
        };
        return SpinnerComponent;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */
    var SpinnerModule = (function () {
        function SpinnerModule() {
        }
        SpinnerModule.decorators = [
            { type: i0.NgModule, args: [{
                        imports: [common.CommonModule],
                        declarations: [SpinnerComponent],
                        exports: [SpinnerComponent]
                    },] },
        ];
        return SpinnerModule;
    }());

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    /**
     * @fileoverview added by tsickle
     * @suppress {checkTypes} checked by tsc
     */

    exports.SpinnerService = SpinnerService;
    exports.SpinnerComponent = SpinnerComponent;
    exports.SpinnerModule = SpinnerModule;

    Object.defineProperty(exports, '__esModule', { value: true });

})));

//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidW9oLXNwaW5uZXIudW1kLmpzLm1hcCIsInNvdXJjZXMiOlsibmc6Ly9AdW9oL3NwaW5uZXIvbGliL3NwaW5uZXIuc2VydmljZS50cyIsIm5nOi8vQHVvaC9zcGlubmVyL2xpYi9zcGlubmVyLmNvbXBvbmVudC50cyIsIm5nOi8vQHVvaC9zcGlubmVyL2xpYi9zcGlubmVyLm1vZHVsZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5cbmltcG9ydCB7IEJlaGF2aW9yU3ViamVjdCB9IGZyb20gJ3J4anMnO1xuXG5ASW5qZWN0YWJsZSh7XG4gIHByb3ZpZGVkSW46ICdyb290J1xufSlcbmV4cG9ydCBjbGFzcyBTcGlubmVyU2VydmljZSB7XG4gIGxvYWRpbmcgPSBuZXcgQmVoYXZpb3JTdWJqZWN0PGJvb2xlYW4+KGZhbHNlKTtcblxuICBjb25zdHJ1Y3RvcigpIHt9XG5cbiAgc2hvdygpOiB2b2lkIHtcbiAgICB0aGlzLmxvYWRpbmcubmV4dCh0cnVlKTtcbiAgfVxuXG4gIGhpZGUoKTogdm9pZCB7XG4gICAgdGhpcy5sb2FkaW5nLm5leHQoZmFsc2UpO1xuICB9XG59XG4iLCJpbXBvcnQgeyBDb21wb25lbnQsIElucHV0LCBPbkluaXQsIE9uRGVzdHJveSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuXG5pbXBvcnQgeyBTdWJzY3JpcHRpb24gfSBmcm9tICdyeGpzJztcblxuaW1wb3J0IHsgU3Bpbm5lclNlcnZpY2UgfSBmcm9tICcuL3NwaW5uZXIuc2VydmljZSc7XG5pbXBvcnQgeyBQb2ludCwgU2l6ZSwgU3RvcHMgfSBmcm9tICcuL21vZGVscyc7XG5cbkBDb21wb25lbnQoe1xuICBzZWxlY3RvcjogJ3VvaC1zcGlubmVyJyxcbiAgdGVtcGxhdGU6IGA8ZGl2ICpuZ0lmPVwidmlzaWJsZVwiIFtzdHlsZS53aWR0aC5weF09XCJzaXplLndpZHRoXCIgW3N0eWxlLmhlaWdodC5weF09XCJzaXplLmhlaWdodFwiIGNsYXNzPVwid3JhcHBlclwiPlxuICA8c3ZnIHhtbG5zOnN2Zz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIFthdHRyLnZpZXdCb3hdPVwidmlld0JveFwiIGlkPVwibG9nb1wiIHZlcnNpb249XCIxLjFcIj5cbiAgICA8c3ZnOmcgaWQ9XCJsb2FkZXJHcm91cFwiIFthdHRyLnRyYW5zZm9ybV09XCJncm91cFRyYW5zZm9ybVwiPlxuICAgICAgPHN2ZzpwYXRoIFtzdHlsZS5zdHJva2UtZGFzaGFycmF5XT1cImRhc2hBcnJheVwiIFtzdHlsZS5zdHJva2UtZGFzaG9mZnNldF09XCJkYXNoT2Zmc2V0XCIgW3N0eWxlLnN0cm9rZS13aWR0aF09XCJzdHJva2VXaWR0aFwiXG4gICAgICAgIHN0eWxlPVwiZmlsbDpub25lO2ZpbGwtcnVsZTpldmVub2RkO3N0cm9rZS1saW5lY2FwOnJvdW5kO3N0cm9rZS1saW5lam9pbjpyb3VuZDtzdHJva2UtbWl0ZXJsaW1pdDo0O3N0cm9rZS1vcGFjaXR5OjFcIlxuICAgICAgICBbYXR0ci5kXT1cInBhdGhcIiB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoMCwwKVwiIGlkPVwibG9hZGVyUGF0aFwiIC8+XG4gICAgICA8c3ZnOnBhdGggW3N0eWxlLnN0cm9rZS13aWR0aF09XCJtaW5TdHJva2VXaWR0aFwiIHN0eWxlPVwiZmlsbDpub25lO2ZpbGwtcnVsZTpldmVub2RkO3N0cm9rZS1saW5lY2FwOnJvdW5kO3N0cm9rZS1saW5lam9pbjpyb3VuZDtzdHJva2UtbWl0ZXJsaW1pdDo0O3N0cm9rZS1vcGFjaXR5OjFcIlxuICAgICAgICBbYXR0ci5kXT1cInBhdGhcIiB0cmFuc2Zvcm09XCJ0cmFuc2xhdGUoMCwwKVwiIGlkPVwiYmdQYXRoXCIgLz5cbiAgICAgIDwvZz5cbiAgPC9zdmc+XG48L2Rpdj5gLFxuICBzdHlsZXM6IFtgQC13ZWJraXQta2V5ZnJhbWVzIHNjYWxpbmd7MCUsMTAwJXstd2Via2l0LXRyYW5zZm9ybTpzY2FsZSgxKTt0cmFuc2Zvcm06c2NhbGUoMSl9NTAley13ZWJraXQtdHJhbnNmb3JtOnNjYWxlKC45NSk7dHJhbnNmb3JtOnNjYWxlKC45NSl9fUBrZXlmcmFtZXMgc2NhbGluZ3swJSwxMDAley13ZWJraXQtdHJhbnNmb3JtOnNjYWxlKDEpO3RyYW5zZm9ybTpzY2FsZSgxKX01MCV7LXdlYmtpdC10cmFuc2Zvcm06c2NhbGUoLjk1KTt0cmFuc2Zvcm06c2NhbGUoLjk1KX19LndyYXBwZXJ7Ym9yZGVyOm5vbmU7cG9zaXRpb246Zml4ZWQ7ei1pbmRleDoxMDAwO21hcmdpbjphdXRvO3RvcDowO2xlZnQ6MDtib3R0b206MDtyaWdodDowfS53cmFwcGVyOmJlZm9yZXtjb250ZW50OicnO2Rpc3BsYXk6YmxvY2s7cG9zaXRpb246Zml4ZWQ7b3ZlcmZsb3c6aGlkZGVuO3RvcDowO2xlZnQ6MDt3aWR0aDoxMDB2dztoZWlnaHQ6MTAwdmg7dGV4dC1hbGlnbjpjZW50ZXI7YmFja2dyb3VuZC1jb2xvcjpyZ2JhKDAsMCwwLC4zKX0jbG9nb3twb3NpdGlvbjphYnNvbHV0ZTt3aWR0aDoxMDAlO2hlaWdodDoxMDAlO3RvcDowO2xlZnQ6MDstd2Via2l0LWFuaW1hdGlvbi1uYW1lOnNjYWxpbmc7YW5pbWF0aW9uLW5hbWU6c2NhbGluZzstd2Via2l0LWFuaW1hdGlvbi1pdGVyYXRpb24tY291bnQ6aW5maW5pdGU7YW5pbWF0aW9uLWl0ZXJhdGlvbi1jb3VudDppbmZpbml0ZTstd2Via2l0LWFuaW1hdGlvbi1kdXJhdGlvbjoyczthbmltYXRpb24tZHVyYXRpb246MnM7LXdlYmtpdC1hbmltYXRpb24tdGltaW5nLWZ1bmN0aW9uOmVhc2UtaW4tb3V0O2FuaW1hdGlvbi10aW1pbmctZnVuY3Rpb246ZWFzZS1pbi1vdXR9I2xvYWRlclBhdGh7c3Ryb2tlOiNkNTExMTF9I2JnUGF0aHtzdHJva2U6cmdiYSgyMTMsMTcsMTcsLjEpfWBdXG59KVxuZXhwb3J0IGNsYXNzIFNwaW5uZXJDb21wb25lbnQgaW1wbGVtZW50cyBPbkluaXQsIE9uRGVzdHJveSB7XG4gIEBJbnB1dCgpIHNpemU6IFNpemU7XG4gIEBJbnB1dCgpIGR1cmF0aW9uID0gMjAwMDtcbiAgQElucHV0KCkgZnBzID0gNjA7XG4gIEBJbnB1dCgpIG1pblN0cm9rZVdpZHRoID0gMTU7XG4gIEBJbnB1dCgpIG1heFN0cm9rZVdpZHRoID0gNTA7XG4gIEBJbnB1dCgpIGNpcmNsZTogU3RvcHMgPSB7IHN0b3AxOiAwLjM1LCBzdG9wMjogMC44NSB9O1xuICBASW5wdXQoKVxuICBwYXRoID1cbiAgICAnTSAwLDEwMSAxMjAsMCAxODAsNTAuNSAyNDAsMCAzMDAsNTAuNSAzNjAsMCAzNjAsNTkgMzM1LjA1MDc4LDgwIDM2MCwxMDEgMzYwLDE2MCAyNDAsNTkgMjE1LjA0ODgzLDgwIDI0MCwxMDEgMjQwLDE2MCcgK1xuICAgICcgMTgwLDEwOS41IDEyMCwxNjAgMTIwLDEwMSAxNDQuOTUxMTcsODAgMTIwLDU5IDAsMTYwIDAsMTAxIFonO1xuICBkYXNoQXJyYXk6IHN0cmluZztcbiAgZGFzaE9mZnNldDogbnVtYmVyO1xuICBzdHJva2VXaWR0aDogbnVtYmVyO1xuICB2aWV3Qm94OiBzdHJpbmc7XG4gIGdyb3VwVHJhbnNmb3JtOiBzdHJpbmc7XG4gIHZpc2libGUgPSBmYWxzZTtcbiAgcHJpdmF0ZSBfZnJhbWVJbnRlcnZhbDogbnVtYmVyO1xuICBwcml2YXRlIF9zdHJva2VJbmM6IFN0b3BzO1xuICBwcml2YXRlIF9wb2ludHM6IFBvaW50W107XG4gIHByaXZhdGUgX3BlcmltZXRlcjogbnVtYmVyO1xuICBwcml2YXRlIF9zdmdTaXplOiBTaXplID0geyB3aWR0aDogMzYwLCBoZWlnaHQ6IDE2MCB9O1xuICBwcml2YXRlIF9kZWZhdWx0U2l6ZTogU2l6ZSA9IHsgd2lkdGg6IDE4MCwgaGVpZ2h0OiA4MCB9O1xuICBwcml2YXRlIF9yZXF1ZXN0SUQ6IG51bWJlcjtcbiAgcHJpdmF0ZSBfbG9hZGluZyQ6IFN1YnNjcmlwdGlvbjtcblxuICBjb25zdHJ1Y3Rvcihwcml2YXRlIF9sb2FkZXI6IFNwaW5uZXJTZXJ2aWNlKSB7fVxuXG4gIG5nT25Jbml0KCk6IHZvaWQge1xuICAgIHRoaXMuc2l6ZSA9IHRoaXMuc2l6ZSA/IHRoaXMuY2FsY1NpemUodGhpcy5zaXplLCB0aGlzLl9zdmdTaXplKSA6IHRoaXMuX2RlZmF1bHRTaXplO1xuICAgIHRoaXMudmlld0JveCA9IGAwIDAgJHt0aGlzLl9zdmdTaXplLndpZHRoICsgdGhpcy5tYXhTdHJva2VXaWR0aH0gJHt0aGlzLl9zdmdTaXplLmhlaWdodCArIHRoaXMubWF4U3Ryb2tlV2lkdGh9YDtcbiAgICBjb25zdCBwb3MgPSB0aGlzLm1heFN0cm9rZVdpZHRoIC8gMjtcbiAgICB0aGlzLmdyb3VwVHJhbnNmb3JtID0gYHRyYW5zbGF0ZSgke3Bvc30sICR7cG9zfSlgO1xuICAgIHRoaXMuX2ZyYW1lSW50ZXJ2YWwgPSAxMDAwIC8gdGhpcy5mcHM7XG4gICAgdGhpcy5fcG9pbnRzID0gdGhpcy5wYXJzZVBvaW50cyh0aGlzLnBhdGgpO1xuICAgIHRoaXMuX3BlcmltZXRlciA9IHRoaXMuY2FsY1BlcmltZXRlcih0aGlzLl9wb2ludHMpO1xuICAgIHRoaXMuX3N0cm9rZUluYyA9IHRoaXMuZ2V0U3Ryb2tlSW5jcmVtZW50KHRoaXMuZHVyYXRpb24sIHRoaXMuY2lyY2xlLCB0aGlzLm1pblN0cm9rZVdpZHRoLCB0aGlzLm1heFN0cm9rZVdpZHRoKTtcbiAgICB0aGlzLl9sb2FkaW5nJCA9IHRoaXMuX2xvYWRlci5sb2FkaW5nLnN1YnNjcmliZShsb2FkaW5nID0+IHtcbiAgICAgIGlmIChsb2FkaW5nKSB7XG4gICAgICAgIHRoaXMuc3RhcnRBbmltYXRpb24oKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMuc3RvcEFuaW1hdGlvbigpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgbmdPbkRlc3Ryb3koKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuX2xvYWRpbmckKSB7XG4gICAgICB0aGlzLl9sb2FkaW5nJC51bnN1YnNjcmliZSgpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgc3RhcnRBbmltYXRpb24oKTogdm9pZCB7XG4gICAgdGhpcy5yZXNldFBhcmFtcygpO1xuICAgIHRoaXMuX3JlcXVlc3RJRCA9IHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUodGltZSA9PiB7XG4gICAgICBjb25zdCBzdGFydFRpbWUgPSB0aGlzLmNvcnJlY3RUaW1lKHRpbWUpO1xuICAgICAgdGhpcy5kcmF3KHN0YXJ0VGltZSwgc3RhcnRUaW1lKTtcbiAgICB9KTtcbiAgICB0aGlzLnZpc2libGUgPSB0cnVlO1xuICB9XG5cbiAgcHJpdmF0ZSBzdG9wQW5pbWF0aW9uKCk6IHZvaWQge1xuICAgIHRoaXMudmlzaWJsZSA9IGZhbHNlO1xuICAgIHRoaXMuY2FuY2VsUmVxdWVzdElEKCk7XG4gIH1cblxuICBwcml2YXRlIHJlc2V0UGFyYW1zKCk6IHZvaWQge1xuICAgIHRoaXMuc3Ryb2tlV2lkdGggPSB0aGlzLm1heFN0cm9rZVdpZHRoO1xuICB9XG5cbiAgcHJpdmF0ZSBjYW5jZWxSZXF1ZXN0SUQoKTogdm9pZCB7XG4gICAgaWYgKHRoaXMuX3JlcXVlc3RJRCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB3aW5kb3cuY2FuY2VsQW5pbWF0aW9uRnJhbWUodGhpcy5fcmVxdWVzdElEKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGRyYXcodGltZTogbnVtYmVyLCBzdGFydFRpbWU6IG51bWJlcik6IHZvaWQge1xuICAgIGNvbnN0IHRpbWVFbGFwc2VkID0gdGltZSAtIHN0YXJ0VGltZTtcbiAgICBsZXQgcGVyY2VudCA9IHRpbWVFbGFwc2VkIC8gdGhpcy5kdXJhdGlvbjtcblxuICAgIGlmIChwZXJjZW50ID49IDEpIHtcbiAgICAgIHN0YXJ0VGltZSA9IHRpbWU7XG4gICAgICBwZXJjZW50ID0gMTtcbiAgICB9XG5cbiAgICBpZiAocGVyY2VudCA+PSB0aGlzLmNpcmNsZS5zdG9wMikge1xuICAgICAgdGhpcy5zdHJva2VXaWR0aCA9XG4gICAgICAgIHRoaXMubWluU3Ryb2tlV2lkdGggKyAodGltZUVsYXBzZWQgLSB0aGlzLmR1cmF0aW9uICogdGhpcy5jaXJjbGUuc3RvcDIpICogdGhpcy5fc3Ryb2tlSW5jLnN0b3AyO1xuICAgIH0gZWxzZSBpZiAocGVyY2VudCA8PSB0aGlzLmNpcmNsZS5zdG9wMSkge1xuICAgICAgdGhpcy5zdHJva2VXaWR0aCA9IHRoaXMubWF4U3Ryb2tlV2lkdGggLSB0aW1lRWxhcHNlZCAqIHRoaXMuX3N0cm9rZUluYy5zdG9wMTtcbiAgICB9XG5cbiAgICBjb25zdCBsb2FkZXIgPSB0aGlzLmVhc2VJbk91dChwZXJjZW50KSAqIHRoaXMuX3BlcmltZXRlcjtcbiAgICB0aGlzLmRhc2hBcnJheSA9IGAke2xvYWRlcn0sJHt0aGlzLl9wZXJpbWV0ZXJ9YDtcbiAgICB0aGlzLmRhc2hPZmZzZXQgPSAobG9hZGVyIC0gMSkgKiAtMTtcblxuICAgIHRoaXMuX3JlcXVlc3RJRCA9IHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUobmV4dFRpbWUgPT4ge1xuICAgICAgdGhpcy5kcmF3KHRoaXMuY29ycmVjdFRpbWUobmV4dFRpbWUpLCBzdGFydFRpbWUpO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBjb3JyZWN0VGltZSh0aW1lOiBudW1iZXIpOiBudW1iZXIge1xuICAgIHJldHVybiB0aW1lIC0gKHRpbWUgJSB0aGlzLl9mcmFtZUludGVydmFsKTtcbiAgfVxuXG4gIHByaXZhdGUgY2FsY1NpemUoY3VyclNpemU6IFNpemUsIG9yaWdTaXplOiBTaXplKTogU2l6ZSB7XG4gICAgaWYgKGN1cnJTaXplLndpZHRoKSB7XG4gICAgICBjdXJyU2l6ZS5oZWlnaHQgPSAob3JpZ1NpemUud2lkdGggLyBjdXJyU2l6ZS53aWR0aCkgKiBvcmlnU2l6ZS5oZWlnaHQ7XG4gICAgfSBlbHNlIHtcbiAgICAgIGN1cnJTaXplLndpZHRoID0gKG9yaWdTaXplLmhlaWdodCAvIGN1cnJTaXplLmhlaWdodCkgKiBvcmlnU2l6ZS53aWR0aDtcbiAgICB9XG5cbiAgICByZXR1cm4gY3VyclNpemU7XG4gIH1cblxuICBwcml2YXRlIGNhbGNQZXJpbWV0ZXIocG9pbnRzOiBQb2ludFtdKTogbnVtYmVyIHtcbiAgICByZXR1cm4gcG9pbnRzLnJlZHVjZSgoYWNjdW0sIGN1cnJQb2ludCwgY3VyckluZGV4KSA9PiB7XG4gICAgICBjb25zdCBuZXh0SW5kZXggPSBjdXJySW5kZXggKyAxID49IHBvaW50cy5sZW5ndGggPyAwIDogY3VyckluZGV4ICsgMTtcbiAgICAgIGNvbnN0IG5leHRQb2ludCA9IHBvaW50c1tuZXh0SW5kZXhdO1xuICAgICAgY29uc3QgZGlmZlggPSBjdXJyUG9pbnQueCAtIG5leHRQb2ludC54O1xuICAgICAgY29uc3QgZGlmZlkgPSBjdXJyUG9pbnQueSAtIG5leHRQb2ludC55O1xuICAgICAgcmV0dXJuIGFjY3VtICsgTWF0aC5zcXJ0KGRpZmZYICogZGlmZlggKyBkaWZmWSAqIGRpZmZZKTtcbiAgICB9LCAwKTtcbiAgfVxuXG4gIHByaXZhdGUgcGFyc2VQb2ludHMocGF0aDogc3RyaW5nKTogUG9pbnRbXSB7XG4gICAgcmV0dXJuIHBhdGhcbiAgICAgIC5yZXBsYWNlKC9NXFxzfFxcc1ovZywgJycpXG4gICAgICAuc3BsaXQoJyAnKVxuICAgICAgLm1hcChwb2ludCA9PiB7XG4gICAgICAgIGNvbnN0IGNvb3JkcyA9IHBvaW50LnNwbGl0KCcsJyk7XG4gICAgICAgIHJldHVybiB7IHg6ICtjb29yZHNbMF0sIHk6ICtjb29yZHNbMV0gfTtcbiAgICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRTdHJva2VJbmNyZW1lbnQoZHVyYXRpb246IG51bWJlciwgc3RvcHM6IFN0b3BzLCBtaW46IG51bWJlciwgbWF4OiBudW1iZXIpOiBTdG9wcyB7XG4gICAgY29uc3Qgc3RlcHMxID0gZHVyYXRpb24gKiBzdG9wcy5zdG9wMTtcbiAgICBjb25zdCBzdGVwczIgPSBkdXJhdGlvbiAqICgxIC0gc3RvcHMuc3RvcDIpO1xuICAgIGNvbnN0IGluY3JlbWVudDEgPSAobWF4IC0gbWluKSAvIHN0ZXBzMTtcbiAgICBjb25zdCBpbmNyZW1lbnQyID0gKG1heCAtIG1pbikgLyBzdGVwczI7XG5cbiAgICByZXR1cm4ge1xuICAgICAgc3RvcDE6IGluY3JlbWVudDEsXG4gICAgICBzdG9wMjogaW5jcmVtZW50MlxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGVhc2VJbk91dCh0aW1lOiBudW1iZXIpOiBudW1iZXIge1xuICAgIGNvbnN0IHRpbWVTcXIgPSB0aW1lICogdGltZTtcbiAgICByZXR1cm4gdGltZVNxciAvICgyICogKHRpbWVTcXIgLSB0aW1lKSArIDEpO1xuICB9XG59XG4iLCJpbXBvcnQgeyBOZ01vZHVsZSB9IGZyb20gJ0Bhbmd1bGFyL2NvcmUnO1xuaW1wb3J0IHsgQ29tbW9uTW9kdWxlIH0gZnJvbSAnQGFuZ3VsYXIvY29tbW9uJztcblxuaW1wb3J0IHsgU3Bpbm5lckNvbXBvbmVudCB9IGZyb20gJy4vc3Bpbm5lci5jb21wb25lbnQnO1xuXG5ATmdNb2R1bGUoe1xuICBpbXBvcnRzOiBbQ29tbW9uTW9kdWxlXSxcbiAgZGVjbGFyYXRpb25zOiBbU3Bpbm5lckNvbXBvbmVudF0sXG4gIGV4cG9ydHM6IFtTcGlubmVyQ29tcG9uZW50XVxufSlcbmV4cG9ydCBjbGFzcyBTcGlubmVyTW9kdWxlIHt9XG4iXSwibmFtZXMiOlsiQmVoYXZpb3JTdWJqZWN0IiwiSW5qZWN0YWJsZSIsIkNvbXBvbmVudCIsIklucHV0IiwiTmdNb2R1bGUiLCJDb21tb25Nb2R1bGUiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQTtRQVVFOzJCQUZVLElBQUlBLG9CQUFlLENBQVUsS0FBSyxDQUFDO1NBRTdCOzs7O1FBRWhCLDZCQUFJOzs7WUFBSjtnQkFDRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzthQUN6Qjs7OztRQUVELDZCQUFJOzs7WUFBSjtnQkFDRSxJQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQzthQUMxQjs7b0JBZEZDLGFBQVUsU0FBQzt3QkFDVixVQUFVLEVBQUUsTUFBTTtxQkFDbkI7Ozs7OzZCQU5EOzs7Ozs7O0FDQUE7UUFnREUsMEJBQW9CLE9BQXVCO1lBQXZCLFlBQU8sR0FBUCxPQUFPLENBQWdCOzRCQXhCdkIsSUFBSTt1QkFDVCxFQUFFO2tDQUNTLEVBQUU7a0NBQ0YsRUFBRTswQkFDSCxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRTt3QkFHbkQscUhBQXFIO2dCQUNySCw4REFBOEQ7MkJBTXRELEtBQUs7NEJBS1UsRUFBRSxLQUFLLEVBQUUsR0FBRyxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUU7Z0NBQ3ZCLEVBQUUsS0FBSyxFQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFO1NBSVI7Ozs7UUFFL0MsbUNBQVE7OztZQUFSO2dCQUFBLGlCQWdCQztnQkFmQyxJQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO2dCQUNwRixJQUFJLENBQUMsT0FBTyxHQUFHLFVBQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGNBQWMsV0FBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFFLENBQUM7Z0JBQ2hILHFCQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsY0FBYyxHQUFHLENBQUMsQ0FBQztnQkFDcEMsSUFBSSxDQUFDLGNBQWMsR0FBRyxlQUFhLEdBQUcsVUFBSyxHQUFHLE1BQUcsQ0FBQztnQkFDbEQsSUFBSSxDQUFDLGNBQWMsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQztnQkFDdEMsSUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztnQkFDM0MsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztnQkFDbkQsSUFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO2dCQUNoSCxJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxVQUFBLE9BQU87b0JBQ3JELElBQUksT0FBTyxFQUFFO3dCQUNYLEtBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQztxQkFDdkI7eUJBQU07d0JBQ0wsS0FBSSxDQUFDLGFBQWEsRUFBRSxDQUFDO3FCQUN0QjtpQkFDRixDQUFDLENBQUM7YUFDSjs7OztRQUVELHNDQUFXOzs7WUFBWDtnQkFDRSxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUU7b0JBQ2xCLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLENBQUM7aUJBQzlCO2FBQ0Y7Ozs7UUFFTyx5Q0FBYzs7Ozs7Z0JBQ3BCLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztnQkFDbkIsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLENBQUMscUJBQXFCLENBQUMsVUFBQSxJQUFJO29CQUNqRCxxQkFBTSxTQUFTLEdBQUcsS0FBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQztvQkFDekMsS0FBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUM7aUJBQ2pDLENBQUMsQ0FBQztnQkFDSCxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQzs7Ozs7UUFHZCx3Q0FBYTs7OztnQkFDbkIsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7Z0JBQ3JCLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQzs7Ozs7UUFHakIsc0NBQVc7Ozs7Z0JBQ2pCLElBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQzs7Ozs7UUFHakMsMENBQWU7Ozs7Z0JBQ3JCLElBQUksSUFBSSxDQUFDLFVBQVUsS0FBSyxTQUFTLEVBQUU7b0JBQ2pDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUM7aUJBQzlDOzs7Ozs7O1FBR0ssK0JBQUk7Ozs7O3NCQUFDLElBQVksRUFBRSxTQUFpQjs7Z0JBQzFDLHFCQUFNLFdBQVcsR0FBRyxJQUFJLEdBQUcsU0FBUyxDQUFDO2dCQUNyQyxxQkFBSSxPQUFPLEdBQUcsV0FBVyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7Z0JBRTFDLElBQUksT0FBTyxJQUFJLENBQUMsRUFBRTtvQkFDaEIsU0FBUyxHQUFHLElBQUksQ0FBQztvQkFDakIsT0FBTyxHQUFHLENBQUMsQ0FBQztpQkFDYjtnQkFFRCxJQUFJLE9BQU8sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtvQkFDaEMsSUFBSSxDQUFDLFdBQVc7d0JBQ2QsSUFBSSxDQUFDLGNBQWMsR0FBRyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO2lCQUNuRztxQkFBTSxJQUFJLE9BQU8sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtvQkFDdkMsSUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsY0FBYyxHQUFHLFdBQVcsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztpQkFDOUU7Z0JBRUQscUJBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQztnQkFDekQsSUFBSSxDQUFDLFNBQVMsR0FBTSxNQUFNLFNBQUksSUFBSSxDQUFDLFVBQVksQ0FBQztnQkFDaEQsSUFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDLE1BQU0sR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7Z0JBRXBDLElBQUksQ0FBQyxVQUFVLEdBQUcsTUFBTSxDQUFDLHFCQUFxQixDQUFDLFVBQUEsUUFBUTtvQkFDckQsS0FBSSxDQUFDLElBQUksQ0FBQyxLQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxFQUFFLFNBQVMsQ0FBQyxDQUFDO2lCQUNsRCxDQUFDLENBQUM7Ozs7OztRQUdHLHNDQUFXOzs7O3NCQUFDLElBQVk7Z0JBQzlCLE9BQU8sSUFBSSxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLENBQUM7Ozs7Ozs7UUFHckMsbUNBQVE7Ozs7O3NCQUFDLFFBQWMsRUFBRSxRQUFjO2dCQUM3QyxJQUFJLFFBQVEsQ0FBQyxLQUFLLEVBQUU7b0JBQ2xCLFFBQVEsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxRQUFRLENBQUMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxLQUFLLElBQUksUUFBUSxDQUFDLE1BQU0sQ0FBQztpQkFDdkU7cUJBQU07b0JBQ0wsUUFBUSxDQUFDLEtBQUssR0FBRyxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUcsUUFBUSxDQUFDLE1BQU0sSUFBSSxRQUFRLENBQUMsS0FBSyxDQUFDO2lCQUN2RTtnQkFFRCxPQUFPLFFBQVEsQ0FBQzs7Ozs7O1FBR1Ysd0NBQWE7Ozs7c0JBQUMsTUFBZTtnQkFDbkMsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDLFVBQUMsS0FBSyxFQUFFLFNBQVMsRUFBRSxTQUFTO29CQUMvQyxxQkFBTSxTQUFTLEdBQUcsU0FBUyxHQUFHLENBQUMsSUFBSSxNQUFNLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxTQUFTLEdBQUcsQ0FBQyxDQUFDO29CQUNyRSxxQkFBTSxTQUFTLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO29CQUNwQyxxQkFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUN4QyxxQkFBTSxLQUFLLEdBQUcsU0FBUyxDQUFDLENBQUMsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDO29CQUN4QyxPQUFPLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLEdBQUcsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFDO2lCQUN6RCxFQUFFLENBQUMsQ0FBQyxDQUFDOzs7Ozs7UUFHQSxzQ0FBVzs7OztzQkFBQyxJQUFZO2dCQUM5QixPQUFPLElBQUk7cUJBQ1IsT0FBTyxDQUFDLFVBQVUsRUFBRSxFQUFFLENBQUM7cUJBQ3ZCLEtBQUssQ0FBQyxHQUFHLENBQUM7cUJBQ1YsR0FBRyxDQUFDLFVBQUEsS0FBSztvQkFDUixxQkFBTSxNQUFNLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztvQkFDaEMsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztpQkFDekMsQ0FBQyxDQUFDOzs7Ozs7Ozs7UUFHQyw2Q0FBa0I7Ozs7Ozs7c0JBQUMsUUFBZ0IsRUFBRSxLQUFZLEVBQUUsR0FBVyxFQUFFLEdBQVc7Z0JBQ2pGLHFCQUFNLE1BQU0sR0FBRyxRQUFRLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQztnQkFDdEMscUJBQU0sTUFBTSxHQUFHLFFBQVEsSUFBSSxDQUFDLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUM1QyxxQkFBTSxVQUFVLEdBQUcsQ0FBQyxHQUFHLEdBQUcsR0FBRyxJQUFJLE1BQU0sQ0FBQztnQkFDeEMscUJBQU0sVUFBVSxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsSUFBSSxNQUFNLENBQUM7Z0JBRXhDLE9BQU87b0JBQ0wsS0FBSyxFQUFFLFVBQVU7b0JBQ2pCLEtBQUssRUFBRSxVQUFVO2lCQUNsQixDQUFDOzs7Ozs7UUFHSSxvQ0FBUzs7OztzQkFBQyxJQUFZO2dCQUM1QixxQkFBTSxPQUFPLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQztnQkFDNUIsT0FBTyxPQUFPLElBQUksQ0FBQyxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQzs7O29CQXBLL0NDLFlBQVMsU0FBQzt3QkFDVCxRQUFRLEVBQUUsYUFBYTt3QkFDdkIsUUFBUSxFQUFFLHU2QkFVTDt3QkFDTCxNQUFNLEVBQUUsQ0FBQywwNEJBQTA0QixDQUFDO3FCQUNyNUI7Ozs7O3dCQWpCUSxjQUFjOzs7OzJCQW1CcEJDLFFBQUs7K0JBQ0xBLFFBQUs7MEJBQ0xBLFFBQUs7cUNBQ0xBLFFBQUs7cUNBQ0xBLFFBQUs7NkJBQ0xBLFFBQUs7MkJBQ0xBLFFBQUs7OytCQTdCUjs7Ozs7OztBQ0FBOzs7O29CQUtDQyxXQUFRLFNBQUM7d0JBQ1IsT0FBTyxFQUFFLENBQUNDLG1CQUFZLENBQUM7d0JBQ3ZCLFlBQVksRUFBRSxDQUFDLGdCQUFnQixDQUFDO3dCQUNoQyxPQUFPLEVBQUUsQ0FBQyxnQkFBZ0IsQ0FBQztxQkFDNUI7OzRCQVREOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OyJ9