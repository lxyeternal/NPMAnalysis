export declare class SpinnerModule {
}
