import { BehaviorSubject } from 'rxjs';
export declare class SpinnerService {
    loading: BehaviorSubject<boolean>;
    constructor();
    show(): void;
    hide(): void;
}
