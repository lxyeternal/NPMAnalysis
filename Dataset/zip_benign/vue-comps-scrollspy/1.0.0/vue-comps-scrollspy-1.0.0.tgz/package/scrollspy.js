var trim;

trim = function(str) {
  return str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
};

module.exports = {
  mixins: [require("vue-mixins/onWindowScroll"), require("vue-mixins/getViewportSize"), require("vue-mixins/onWindowResize"), require("vue-mixins/getDocumentHeight"), require("vue-mixins/class")],
  props: {
    "class": {
      "default": function() {
        return ["table-of-contents"];
      }
    },
    transition: {
      type: Function,
      "default": function(scrollBy, done) {
        if (typeof window !== "undefined" && window !== null) {
          if (typeof window.scrollBy === "function") {
            window.scrollBy(0, scrollBy);
          }
        }
        return setTimeout(done, 66);
      }
    },
    activeClass: {
      "default": "active",
      type: String
    },
    activeStyle: {
      "default": "",
      coerce: function(val) {
        var j, kv, len, obj, opt, ref;
        if (typeof val === 'string' || val instanceof String) {
          obj = {};
          ref = val.split(";");
          for (j = 0, len = ref.length; j < len; j++) {
            opt = ref[j];
            kv = opt.split(":");
            if (kv.length === 2) {
              obj[trim(kv[0])] = trim(kv[1]);
            }
          }
          return obj;
        }
        return obj;
      }
    }
  },
  methods: {
    processHeight: function() {
      this.vpHeight = this.getViewportSize().height;
      return this.processScroll();
    },
    activate: function(target) {
      var child, j, len, ref, results;
      if (target !== this.lastTarget) {
        this.lastTarget = target;
        ref = this.$children;
        results = [];
        for (j = 0, len = ref.length; j < len; j++) {
          child = ref[j];
          if (child.isScrollspyItem && (child.targetEl != null)) {
            if (child === target) {
              results.push(child.activate());
            } else {
              results.push(child.deactivate());
            }
          } else {
            results.push(void 0);
          }
        }
        return results;
      }
    },
    processScroll: function(e) {
      var area, body, bottom, child, coverage, docEl, i, indices, j, k, len, max, rect, ref, ref1, results, results1, top;
      if (!this.pause) {
        this.lastScrollTop = this.scrollTop;
        body = document.body;
        docEl = document.documentElement;
        this.scrollTop = window.pageYOffset || docEl.scrollTop || body.scrollTop;
        if (this.scrollTop + this.vpHeight - this.getDocumentHeight() > -40) {
          results = [];
          for (i = j = ref = this.$children.length - 1; ref <= 0 ? j <= 0 : j >= 0; i = ref <= 0 ? ++j : --j) {
            child = this.$children[i];
            if (child.isScrollspyItem && (child.targetEl != null)) {
              this.activate(child);
              break;
            } else {
              results.push(void 0);
            }
          }
          return results;
        } else {
          coverage = [];
          indices = [];
          ref1 = this.$children;
          results1 = [];
          for (i = k = 0, len = ref1.length; k < len; i = ++k) {
            child = ref1[i];
            if (child.isScrollspyItem && (child.targetEl != null)) {
              rect = child.targetEl.getBoundingClientRect();
              if (this.lastScrollTop === -1) {
                top = Math.max(0, rect.top);
                bottom = Math.min(this.vpHeight * 0.1, rect.bottom);
              } else if (this.lastScrollTop <= this.scrollTop) {
                top = Math.max(0 + this.vpHeight * 0.3, rect.top);
                bottom = Math.min(this.vpHeight * 0.4, rect.bottom);
              } else {
                top = Math.max(0 + this.vpHeight * 0.6, rect.top);
                bottom = Math.min(this.vpHeight * 0.7, rect.bottom);
              }
              area = bottom - top;
              if (area >= 0) {
                indices.push(i);
                coverage.push(area);
              }
            }
            max = coverage.reduce((function(iMax, x, i, a) {
              if (x > a[iMax]) {
                return i;
              } else {
                return iMax;
              }
            }), 0);
            results1.push(this.activate(this.$children[indices[max]]));
          }
          return results1;
        }
      }
    }
  },
  ready: function() {
    this.onWindowScroll(this.processScroll);
    this.onWindowResize(this.processHeight);
    this.scrollTop = -1;
    this.lastTarget = -1;
    return this.processHeight();
  }
};

if (module.exports.__esModule) module.exports = module.exports.default
;(typeof module.exports === "function"? module.exports.options: module.exports).template = "<ul v-bind:class=computedClass><slot></slot></ul>"
