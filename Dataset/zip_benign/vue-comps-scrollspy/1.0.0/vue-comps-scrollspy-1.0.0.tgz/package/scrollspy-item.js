module.exports = {
  props: {
    target: null
  },
  computed: {
    targetEl: function() {
      if (this.ready && typeof this.target === 'string' || this.target instanceof String) {
        return document.getElementById(this.target);
      }
      return this.target;
    },
    cClass: function() {
      if (this.active && this.targetEl) {
        return [this.$parent.activeClass];
      }
      return null;
    },
    cStyle: function() {
      var style;
      style = [];
      if (this.targetEl) {
        style.push({
          cursor: 'pointer'
        });
        if (this.active) {
          style.push(this.$parent.activeStyle);
        }
      }
      return style;
    }
  },
  data: function() {
    return {
      isScrollspyItem: true,
      active: false,
      ready: false
    };
  },
  methods: {
    scroll: function(e) {
      if (e != null) {
        if (e.defaultPrevented) {
          return;
        }
        e.preventDefault();
      }
      if (this.targetEl != null) {
        this.$parent.pause = true;
        return this.$parent.transition(this.targetEl.getBoundingClientRect().top, (function(_this) {
          return function() {
            _this.$parent.pause = false;
            return _this.$parent.activate(_this);
          };
        })(this));
      }
    },
    activate: function() {
      return this.active = true;
    },
    deactivate: function() {
      return this.active = false;
    }
  },
  ready: function() {
    return this.ready = true;
  }
};

if (module.exports.__esModule) module.exports = module.exports.default
;(typeof module.exports === "function"? module.exports.options: module.exports).template = "<li><a :class=cClass :style=cStyle @click=scroll><slot></slot></a>"
